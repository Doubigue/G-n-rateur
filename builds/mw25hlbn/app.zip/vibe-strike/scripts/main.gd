extends Node2D
## Vibe Strike — jeu de foot "trace ta trajectoire" (inspiré de Score! Hero)
## DL VIBE STUDIO — Godot 4.x
## Tout est dessiné en code (_draw) : aucun asset externe nécessaire.

const W := 720.0
const H := 1280.0
const GOAL_Y := 150.0
const GOAL_L := 250.0
const GOAL_R := 470.0
const BALL_R := 13.0
const PLAYER_R := 26.0
const SHOT_SPEED := 1350.0
const PASS_SPEED := 950.0
const PICK_RADIUS := 120.0
const SAVE_PATH := "user://vibe_strike.cfg"

const GOLD := Color(0.95, 0.76, 0.25)
const DARK := Color(0.07, 0.07, 0.09)
const TEAM_COL := Color(0.95, 0.76, 0.25)
const OPP_COL := Color(0.85, 0.18, 0.2)
const KEEPER_COL := Color(0.2, 0.75, 0.95)

enum Screen { MENU, LEVELS, GAME }
enum Phase { AIM, DRAW, FLIGHT, RESULT, END }

var font: Font
var screen: int = Screen.MENU
var phase: int = Phase.AIM
var levels: Array = []
var level_idx := 0
var unlocked := 1
var best_stars: Array = []
var total_score := 0

# --- état du niveau ---
var team: Array = []        # positions des coéquipiers (Vector2)
var defenders: Array = []   # {base, range, speed, ph, pos}
var holder := 0
var ball := Vector2.ZERO
var ball_rot := 0.0
var keeper_x := 360.0
var keeper_speed := 200.0
var keeper_react := 0.0
var attempts_left := 3
var attempts_max := 3
var passes := 0
var t := 0.0

var draw_pts := PackedVector2Array()
var flight_pts := PackedVector2Array()
var flight_cum := PackedFloat32Array()
var flight_dist := 0.0
var flight_speed := SHOT_SPEED
var flight_is_pass := false
var pass_target := -1
var curve_bonus := false
var prev_ball := Vector2.ZERO
var trail: Array = []

var msg := ""
var msg_color := Color.WHITE
var msg_timer := 0.0
var result_goal := false
var shake := 0.0
var net_wobble := 0.0
var particles: Array = []
var popups: Array = []
var end_win := false
var end_stars := 0
var end_score := 0
var buttons: Array = []     # {rect, id}

var sb_gold: StyleBoxFlat
var sb_dark: StyleBoxFlat
var sb_lock: StyleBoxFlat


func _ready() -> void:
	font = ThemeDB.fallback_font
	sb_gold = _make_sb(GOLD, DARK)
	sb_dark = _make_sb(Color(0, 0, 0, 0.55), GOLD)
	sb_lock = _make_sb(Color(0.15, 0.15, 0.17, 0.85), Color(0.35, 0.35, 0.38))
	_build_levels()
	best_stars.resize(levels.size())
	best_stars.fill(0)
	_load()


func _make_sb(bg: Color, border: Color) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.border_color = border
	sb.set_border_width_all(4)
	sb.set_corner_radius_all(22)
	return sb


# ------------------------------------------------------------------ NIVEAUX
func _lvl(name: String, team_pos: Array, defs: Array, keeper: float, attempts: int) -> Dictionary:
	return {"name": name, "team": team_pos, "def": defs, "keeper": keeper, "attempts": attempts}


func _build_levels() -> void:
	# défenseur = [position, amplitude de déplacement horizontal, vitesse]
	levels = [
		_lvl("Premier tir", [Vector2(360, 600)], [], 110.0, 3),
		_lvl("Une passe", [Vector2(200, 950), Vector2(480, 540)],
			[[Vector2(340, 760), 0.0, 0.0]], 150.0, 3),
		_lvl("Le mur", [Vector2(360, 660)],
			[[Vector2(300, 440), 0.0, 0.0], [Vector2(360, 440), 0.0, 0.0], [Vector2(420, 440), 0.0, 0.0]], 170.0, 3),
		_lvl("Le couloir", [Vector2(150, 1050), Vector2(560, 760), Vector2(360, 500)],
			[[Vector2(360, 880), 140.0, 1.5]], 190.0, 3),
		_lvl("Contre-attaque", [Vector2(360, 1080), Vector2(170, 760), Vector2(540, 520)],
			[[Vector2(300, 920), 110.0, 2.0], [Vector2(440, 640), 120.0, 1.6]], 210.0, 3),
		_lvl("Coup franc", [Vector2(400, 620)],
			[[Vector2(290, 450), 0.0, 0.0], [Vector2(345, 450), 0.0, 0.0], [Vector2(400, 450), 0.0, 0.0], [Vector2(455, 450), 0.0, 0.0]], 240.0, 3),
		_lvl("Triangle", [Vector2(560, 1060), Vector2(160, 800), Vector2(480, 540)],
			[[Vector2(360, 930), 150.0, 2.2], [Vector2(320, 660), 130.0, 1.8], [Vector2(400, 330), 60.0, 1.2]], 240.0, 3),
		_lvl("Angle fermé", [Vector2(620, 520)],
			[[Vector2(520, 340), 40.0, 1.0]], 270.0, 3),
		_lvl("Pressing", [Vector2(360, 1120), Vector2(190, 880), Vector2(530, 680), Vector2(300, 470)],
			[[Vector2(280, 1000), 90.0, 2.4], [Vector2(380, 780), 140.0, 2.0], [Vector2(420, 580), 120.0, 1.7], [Vector2(360, 320), 80.0, 1.4]], 280.0, 3),
		_lvl("Dernière minute", [Vector2(140, 1120), Vector2(560, 920), Vector2(180, 680), Vector2(520, 480)],
			[[Vector2(360, 1020), 160.0, 2.6], [Vector2(380, 800), 160.0, 2.3], [Vector2(330, 580), 150.0, 2.0], [Vector2(420, 390), 90.0, 1.8], [Vector2(300, 300), 60.0, 1.5]], 310.0, 2),
	]


func _start_level(i: int) -> void:
	level_idx = i
	var L: Dictionary = levels[i]
	attempts_max = int(L["attempts"])
	attempts_left = attempts_max
	keeper_speed = float(L["keeper"])
	screen = Screen.GAME
	particles.clear()
	popups.clear()
	_reset_attempt()


func _reset_attempt() -> void:
	var L: Dictionary = levels[level_idx]
	team = (L["team"] as Array).duplicate()
	defenders.clear()
	for d in L["def"]:
		var arr: Array = d
		defenders.append({"base": arr[0], "range": arr[1], "speed": arr[2], "ph": randf() * TAU, "pos": arr[0]})
	holder = 0
	passes = 0
	ball = _ball_at_owner()
	keeper_x = 360.0
	trail.clear()
	draw_pts.clear()
	flight_pts.clear()
	phase = Phase.AIM


func _ball_at_owner() -> Vector2:
	var p: Vector2 = team[holder]
	return p + Vector2(0, -PLAYER_R - BALL_R + 2)


# ------------------------------------------------------------------ BOUCLE
func _process(delta: float) -> void:
	t += delta
	shake = maxf(0.0, shake - delta * 2.5)
	net_wobble = maxf(0.0, net_wobble - delta * 1.5)
	_update_fx(delta)

	if screen == Screen.GAME:
		for d in defenders:
			var dd: Dictionary = d
			var base: Vector2 = dd["base"]
			dd["pos"] = base + Vector2(sin(t * float(dd["speed"]) + float(dd["ph"])) * float(dd["range"]), 0)

		match phase:
			Phase.AIM, Phase.DRAW:
				ball = _ball_at_owner()
				var idle_target: float = clampf(lerpf(360.0, ball.x, 0.35), GOAL_L + 25, GOAL_R - 25)
				keeper_x = move_toward(keeper_x, idle_target, keeper_speed * 0.4 * delta)
			Phase.FLIGHT:
				_update_flight(delta)
			Phase.RESULT:
				msg_timer -= delta
				if msg_timer <= 0.0:
					_after_result()
	queue_redraw()


func _update_flight(delta: float) -> void:
	prev_ball = ball
	flight_dist += flight_speed * delta
	ball_rot += delta * 18.0
	var total: float = flight_cum[flight_cum.size() - 1]
	if flight_dist >= total:
		flight_dist = total
		ball = flight_pts[flight_pts.size() - 1]
		if flight_is_pass:
			_receive_pass()
		else:
			_miss("Hors du terrain !")
		return
	ball = _point_at(flight_dist)
	trail.append(ball)
	if trail.size() > 14:
		trail.pop_front()

	# Interception par un défenseur
	if flight_dist > 30.0:
		for d in defenders:
			var dp: Vector2 = (d as Dictionary)["pos"]
			if ball.distance_to(dp) < PLAYER_R + BALL_R - 2:
				_miss("Intercepté !")
				return

	# Gardien : il lit la direction ACTUELLE du ballon (un tir enroulé le trompe)
	var v := ball - prev_ball
	if ball.y < 780.0:
		keeper_react -= delta
		if keeper_react <= 0.0 and v.y < -0.5:
			var frames := (ball.y - GOAL_Y) / -v.y
			var pred := ball.x + v.x * frames
			var target: float = clampf(pred, GOAL_L + 18, GOAL_R - 18)
			keeper_x = move_toward(keeper_x, target, keeper_speed * delta)
	var ky := GOAL_Y + 22.0
	if absf(ball.x - keeper_x) < 36.0 and absf(ball.y - ky) < 20.0:
		_miss("Arrêt du gardien !")
		return

	# Franchissement de la ligne de but
	if ball.y <= GOAL_Y and prev_ball.y > GOAL_Y:
		var k := (prev_ball.y - GOAL_Y) / maxf(0.001, prev_ball.y - ball.y)
		var cx: float = lerpf(prev_ball.x, ball.x, k)
		if cx > GOAL_L + BALL_R * 0.5 and cx < GOAL_R - BALL_R * 0.5:
			_goal()
		elif cx > GOAL_L - BALL_R and cx < GOAL_R + BALL_R:
			_miss("Poteau !")
		else:
			_miss("À côté !")
		return

	if ball.x < -20 or ball.x > W + 20 or ball.y > H + 40 or ball.y < 0:
		_miss("Hors du terrain !")


func _receive_pass() -> void:
	holder = pass_target
	passes += 1
	_popup(team[holder] + Vector2(0, -60), "Passe +150", Color.WHITE)
	trail.clear()
	phase = Phase.AIM


func _goal() -> void:
	result_goal = true
	shake = 1.0
	net_wobble = 1.0
	_burst(ball, 60)
	var used := attempts_max - attempts_left + 1
	end_stars = 3 if used == 1 else (2 if used == 2 else 1)
	end_score = 1000 + passes * 150 + (300 if curve_bonus else 0) + attempts_left * 100
	msg = "BUUUT !"
	if curve_bonus:
		msg = "BUT ENROULÉ !"
	msg_color = GOLD
	msg_timer = 1.6
	phase = Phase.RESULT


func _miss(text: String) -> void:
	result_goal = false
	attempts_left -= 1
	shake = 0.35
	msg = text
	msg_color = Color(1, 0.45, 0.45)
	msg_timer = 1.3
	phase = Phase.RESULT


func _after_result() -> void:
	if result_goal:
		end_win = true
		total_score += end_score
		if end_stars > int(best_stars[level_idx]):
			best_stars[level_idx] = end_stars
		unlocked = maxi(unlocked, mini(levels.size(), level_idx + 2))
		_save()
		phase = Phase.END
	elif attempts_left <= 0:
		end_win = false
		end_stars = 0
		phase = Phase.END
	else:
		_reset_attempt()


# ------------------------------------------------------------------ TRAJECTOIRE
func _launch() -> void:
	if draw_pts.size() < 3 or _poly_len(draw_pts) < 40.0:
		phase = Phase.AIM
		return
	var pts := _smooth(_resample(draw_pts, 14.0))
	var end_p: Vector2 = pts[pts.size() - 1]

	# Passe : la trajectoire se termine près d'un coéquipier
	pass_target = -1
	var best := 85.0
	for i in team.size():
		if i == holder:
			continue
		var d := end_p.distance_to(team[i])
		if d < best:
			best = d
			pass_target = i
	flight_is_pass = pass_target >= 0
	curve_bonus = false

	if flight_is_pass:
		pts[pts.size() - 1] = team[pass_target] + Vector2(0, -PLAYER_R - BALL_R + 2)
		flight_speed = PASS_SPEED
	else:
		# Tir : le ballon continue dans la dernière direction
		var dir := (pts[pts.size() - 1] - pts[pts.size() - 3]).normalized()
		var p := end_p
		for i in 60:
			p += dir * 30.0
			pts.append(p)
		flight_speed = SHOT_SPEED
		curve_bonus = _deviation(draw_pts) > 55.0

	flight_pts = pts
	flight_cum = PackedFloat32Array()
	flight_cum.append(0.0)
	for i in range(1, pts.size()):
		flight_cum.append(flight_cum[i - 1] + pts[i].distance_to(pts[i - 1]))
	flight_dist = 0.0
	prev_ball = ball
	keeper_react = 0.12
	trail.clear()
	phase = Phase.FLIGHT


func _point_at(d: float) -> Vector2:
	for i in range(1, flight_cum.size()):
		if flight_cum[i] >= d:
			var seg := flight_cum[i] - flight_cum[i - 1]
			var k := 0.0 if seg <= 0.0 else (d - flight_cum[i - 1]) / seg
			return flight_pts[i - 1].lerp(flight_pts[i], k)
	return flight_pts[flight_pts.size() - 1]


func _poly_len(p: PackedVector2Array) -> float:
	var l := 0.0
	for i in range(1, p.size()):
		l += p[i].distance_to(p[i - 1])
	return l


func _resample(p: PackedVector2Array, step: float) -> PackedVector2Array:
	var out := PackedVector2Array()
	out.append(p[0])
	var acc := 0.0
	for i in range(1, p.size()):
		var a := p[i - 1]
		var b := p[i]
		var seg := a.distance_to(b)
		while acc + seg >= step:
			var k := (step - acc) / seg
			a = a.lerp(b, k)
			out.append(a)
			seg = a.distance_to(b)
			acc = 0.0
		acc += seg
	out.append(p[p.size() - 1])
	return out


func _smooth(p: PackedVector2Array) -> PackedVector2Array:
	var cur := p
	for it in 2:
		if cur.size() < 3:
			break
		var out := PackedVector2Array()
		out.append(cur[0])
		for i in range(cur.size() - 1):
			out.append(cur[i].lerp(cur[i + 1], 0.25))
			out.append(cur[i].lerp(cur[i + 1], 0.75))
		out.append(cur[cur.size() - 1])
		cur = out
	return cur


func _deviation(p: PackedVector2Array) -> float:
	var a := p[0]
	var b := p[p.size() - 1]
	var ab := b - a
	if ab.length() < 1.0:
		return 0.0
	var n := Vector2(-ab.y, ab.x).normalized()
	var m := 0.0
	for q in p:
		m = maxf(m, absf((q - a).dot(n)))
	return m


# ------------------------------------------------------------------ ENTRÉES
func _input(event: InputEvent) -> void:
	var e := make_input_local(event)
	if e is InputEventMouseButton and (e as InputEventMouseButton).button_index == MOUSE_BUTTON_LEFT:
		var mb := e as InputEventMouseButton
		if mb.pressed:
			_on_press(mb.position)
		else:
			_on_release(mb.position)
	elif e is InputEventMouseMotion:
		_on_drag((e as InputEventMouseMotion).position)


func _on_press(pos: Vector2) -> void:
	for b in buttons:
		var r: Rect2 = (b as Dictionary)["rect"]
		if r.has_point(pos):
			_on_button(String((b as Dictionary)["id"]))
			return
	if screen == Screen.GAME and phase == Phase.AIM and pos.distance_to(ball) < PICK_RADIUS:
		draw_pts = PackedVector2Array([ball])
		phase = Phase.DRAW


func _on_drag(pos: Vector2) -> void:
	if screen == Screen.GAME and phase == Phase.DRAW:
		var last := draw_pts[draw_pts.size() - 1]
		if pos.distance_to(last) > 8.0 and _poly_len(draw_pts) < 1700.0:
			draw_pts.append(pos)


func _on_release(_pos: Vector2) -> void:
	if screen == Screen.GAME and phase == Phase.DRAW:
		_launch()


func _on_button(id: String) -> void:
	if id == "play":
		screen = Screen.LEVELS
	elif id == "back_menu":
		screen = Screen.MENU
	elif id == "levels":
		screen = Screen.LEVELS
	elif id == "retry":
		_start_level(level_idx)
	elif id == "next":
		_start_level(mini(level_idx + 1, levels.size() - 1))
	elif id == "pause":
		screen = Screen.LEVELS
	elif id.begins_with("lvl_"):
		var i := int(id.substr(4))
		if i < unlocked:
			_start_level(i)


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		if screen == Screen.GAME:
			screen = Screen.LEVELS
		elif screen == Screen.LEVELS:
			screen = Screen.MENU
		else:
			get_tree().quit()


# ------------------------------------------------------------------ EFFETS
func _burst(at: Vector2, n: int) -> void:
	var cols := [GOLD, Color.WHITE, Color(1, 0.4, 0.3), Color(0.4, 0.85, 1)]
	for i in n:
		var a := randf() * TAU
		var s := randf_range(150, 650)
		particles.append({"p": at, "v": Vector2(cos(a), sin(a)) * s, "c": cols[i % cols.size()], "life": randf_range(0.7, 1.4)})


func _popup(at: Vector2, text: String, col: Color) -> void:
	popups.append({"p": at, "text": text, "c": col, "life": 1.0})


func _update_fx(delta: float) -> void:
	for i in range(particles.size() - 1, -1, -1):
		var p: Dictionary = particles[i]
		p["life"] = float(p["life"]) - delta
		p["v"] = (p["v"] as Vector2) * 0.97 + Vector2(0, 600) * delta
		p["p"] = (p["p"] as Vector2) + (p["v"] as Vector2) * delta
		if float(p["life"]) <= 0.0:
			particles.remove_at(i)
	for i in range(popups.size() - 1, -1, -1):
		var q: Dictionary = popups[i]
		q["life"] = float(q["life"]) - delta
		q["p"] = (q["p"] as Vector2) + Vector2(0, -60) * delta
		if float(q["life"]) <= 0.0:
			popups.remove_at(i)


# ------------------------------------------------------------------ DESSIN
func _draw() -> void:
	buttons.clear()
	var off := Vector2.ZERO
	if shake > 0.0:
		off = Vector2(randf_range(-1, 1), randf_range(-1, 1)) * shake * 14.0
	draw_set_transform(off)
	_draw_pitch()
	match screen:
		Screen.MENU:
			draw_set_transform(Vector2.ZERO)
			_draw_menu()
		Screen.LEVELS:
			draw_set_transform(Vector2.ZERO)
			_draw_levels()
		Screen.GAME:
			_draw_game()
			draw_set_transform(Vector2.ZERO)
			_draw_hud()


func _draw_pitch() -> void:
	var vh := maxf(H, get_viewport_rect().size.y)
	draw_rect(Rect2(-40, -40, W + 80, vh + 80), Color(0.13, 0.45, 0.18))
	for i in 14:
		if i % 2 == 0:
			draw_rect(Rect2(0, i * 100.0, W, 100), Color(0.15, 0.5, 0.2))
	var lc := Color(1, 1, 1, 0.75)
	draw_rect(Rect2(30, GOAL_Y, W - 60, 1110), lc, false, 4.0)
	draw_rect(Rect2(130, GOAL_Y, 460, 280), lc, false, 4.0)
	draw_rect(Rect2(230, GOAL_Y, 260, 110), lc, false, 4.0)
	draw_circle(Vector2(360, 360), 5, lc)
	draw_arc(Vector2(360, 380), 110, deg_to_rad(30), deg_to_rad(150), 32, lc, 4.0)
	draw_line(Vector2(30, 1260), Vector2(690, 1260), lc, 4.0)
	draw_arc(Vector2(360, 1260), 130, PI, TAU, 40, lc, 4.0)
	# But + filet
	var wob := sin(t * 30.0) * 6.0 * net_wobble
	var net := Rect2(GOAL_L, GOAL_Y - 70 - wob, GOAL_R - GOAL_L, 70 + wob)
	draw_rect(net, Color(1, 1, 1, 0.08))
	var nc := Color(1, 1, 1, 0.35)
	var x := GOAL_L
	while x <= GOAL_R:
		draw_line(Vector2(x, GOAL_Y), Vector2(x, net.position.y), nc, 1.5)
		x += 18.0
	var y := net.position.y
	while y <= GOAL_Y:
		draw_line(Vector2(GOAL_L, y), Vector2(GOAL_R, y), nc, 1.5)
		y += 14.0
	draw_line(Vector2(GOAL_L, GOAL_Y), Vector2(GOAL_L, GOAL_Y - 72), Color.WHITE, 8.0)
	draw_line(Vector2(GOAL_R, GOAL_Y), Vector2(GOAL_R, GOAL_Y - 72), Color.WHITE, 8.0)
	draw_line(Vector2(GOAL_L - 4, GOAL_Y - 72), Vector2(GOAL_R + 4, GOAL_Y - 72), Color.WHITE, 8.0)


func _draw_player(p: Vector2, col: Color, num: String, highlight: bool) -> void:
	draw_circle(p + Vector2(4, 6), PLAYER_R, Color(0, 0, 0, 0.3))
	if highlight:
		var pulse := 6.0 + sin(t * 6.0) * 3.0
		draw_arc(p, PLAYER_R + pulse, 0, TAU, 32, Color(1, 1, 1, 0.8), 3.0)
	draw_circle(p, PLAYER_R, col)
	draw_arc(p, PLAYER_R, 0, TAU, 32, DARK, 3.0)
	draw_circle(p + Vector2(0, -6), 10, Color(0.36, 0.22, 0.14))
	_text(p + Vector2(0, 16), num, 18, DARK)


func _draw_ball(p: Vector2) -> void:
	draw_circle(p + Vector2(3, 5), BALL_R, Color(0, 0, 0, 0.35))
	draw_circle(p, BALL_R, Color.WHITE)
	for i in 5:
		var a := ball_rot + i * TAU / 5.0
		draw_circle(p + Vector2(cos(a), sin(a)) * 7.0, 3.2, DARK)
	draw_circle(p, 4.0, DARK)
	draw_arc(p, BALL_R, 0, TAU, 24, DARK, 1.5)


func _draw_game() -> void:
	# trajectoire en cours de tracé
	if phase == Phase.DRAW and draw_pts.size() > 1:
		var preview := _smooth(draw_pts)
		var acc := 0.0
		for i in range(1, preview.size()):
			acc += preview[i].distance_to(preview[i - 1])
			if int(acc / 22.0) % 2 == 0:
				draw_line(preview[i - 1], preview[i], Color(1, 1, 1, 0.9), 7.0)
		var e := draw_pts[draw_pts.size() - 1]
		var near_mate := false
		for i in team.size():
			if i != holder and e.distance_to(team[i]) < 85.0:
				near_mate = true
		draw_circle(e, 12, GOLD if near_mate else Color(1, 1, 1, 0.9))
	# trajectoire suivie (fantôme)
	if phase == Phase.FLIGHT and flight_pts.size() > 1:
		draw_polyline(flight_pts, Color(1, 1, 1, 0.12), 4.0)

	# coéquipiers
	for i in team.size():
		var hl := (phase == Phase.AIM and i != holder)
		_draw_player(team[i], TEAM_COL, str(i + 7), hl)
	# défenseurs
	for d in defenders:
		_draw_player((d as Dictionary)["pos"], OPP_COL, "", false)
	# gardien
	var kp := Vector2(keeper_x, GOAL_Y + 22)
	draw_rect(Rect2(kp.x - 36, kp.y - 8, 72, 16), KEEPER_COL.darkened(0.2))
	draw_circle(kp, 22, KEEPER_COL)
	draw_arc(kp, 22, 0, TAU, 28, DARK, 3.0)
	draw_circle(kp + Vector2(-38, 0), 8, Color(0.95, 0.95, 0.95))
	draw_circle(kp + Vector2(38, 0), 8, Color(0.95, 0.95, 0.95))

	# traînée + ballon
	for i in trail.size():
		var a := float(i) / maxi(1, trail.size())
		draw_circle(trail[i], BALL_R * a, Color(1, 1, 1, 0.35 * a))
	_draw_ball(ball)

	# indice de début
	if phase == Phase.AIM and passes == 0 and attempts_left == attempts_max:
		var a2 := 0.5 + 0.5 * sin(t * 4.0)
		_text(ball + Vector2(0, 110), "Glisse depuis le ballon", 26, Color(1, 1, 1, 0.5 + 0.5 * a2))

	# effets
	for p in particles:
		var pd: Dictionary = p
		var c: Color = pd["c"]
		c.a = clampf(float(pd["life"]), 0.0, 1.0)
		draw_rect(Rect2((pd["p"] as Vector2) - Vector2(5, 3), Vector2(10, 6)), c)
	for q in popups:
		var qd: Dictionary = q
		var c2: Color = qd["c"]
		c2.a = clampf(float(qd["life"]), 0.0, 1.0)
		_text(qd["p"], String(qd["text"]), 30, c2)


func _draw_hud() -> void:
	var L: Dictionary = levels[level_idx]
	draw_rect(Rect2(0, 0, W, 70), Color(0, 0, 0, 0.55))
	_button(Rect2(14, 10, 110, 50), "MENU", "pause", sb_dark, 22, GOLD)
	_text(Vector2(360, 46), "Niv. %d — %s" % [level_idx + 1, String(L["name"])], 26, Color.WHITE)
	# tentatives = ballons
	for i in attempts_max:
		var c := Color.WHITE if i < attempts_left else Color(1, 1, 1, 0.2)
		draw_circle(Vector2(W - 40 - i * 34, 35), 12, c)

	if phase == Phase.RESULT:
		var s := 1.0 + 0.15 * sin(t * 12.0)
		draw_rect(Rect2(0, 560, W, 150), Color(0, 0, 0, 0.5))
		_text(Vector2(360, 660), msg, int(72 * s), msg_color)

	if phase == Phase.END:
		_draw_end()


func _draw_end() -> void:
	draw_rect(Rect2(0, 0, W, maxf(H, get_viewport_rect().size.y)), Color(0, 0, 0, 0.6))
	var box := Rect2(70, 360, 580, 560)
	sb_dark.draw(get_canvas_item(), box)
	if end_win:
		_text(Vector2(360, 450), "VICTOIRE !", 64, GOLD)
		for i in 3:
			_star(Vector2(240 + i * 120, 560), 44.0, i < end_stars)
		_text(Vector2(360, 680), "Score : %d" % end_score, 34, Color.WHITE)
		_text(Vector2(360, 725), "Passes : %d" % passes, 24, Color(1, 1, 1, 0.7))
		if level_idx + 1 < levels.size():
			_button(Rect2(110, 780, 240, 90), "REJOUER", "retry", sb_dark, 28, GOLD)
			_button(Rect2(370, 780, 240, 90), "SUIVANT", "next", sb_gold, 30, DARK)
		else:
			_button(Rect2(110, 780, 240, 90), "REJOUER", "retry", sb_dark, 28, GOLD)
			_button(Rect2(370, 780, 240, 90), "NIVEAUX", "levels", sb_gold, 30, DARK)
	else:
		_text(Vector2(360, 470), "RATÉ...", 64, Color(1, 0.45, 0.45))
		_text(Vector2(360, 560), "Plus de tentatives.", 30, Color.WHITE)
		_text(Vector2(360, 610), "Astuce : courbe ta trajectoire", 24, Color(1, 1, 1, 0.7))
		_text(Vector2(360, 645), "pour tromper le gardien !", 24, Color(1, 1, 1, 0.7))
		_button(Rect2(110, 780, 240, 90), "NIVEAUX", "levels", sb_dark, 28, GOLD)
		_button(Rect2(370, 780, 240, 90), "REJOUER", "retry", sb_gold, 30, DARK)


func _draw_menu() -> void:
	var vh := maxf(H, get_viewport_rect().size.y)
	draw_rect(Rect2(0, 0, W, vh), Color(0, 0, 0, 0.45))
	_text(Vector2(360, 330), "VIBE", 120, GOLD)
	_text(Vector2(360, 450), "STRIKE", 120, Color.WHITE)
	_text(Vector2(360, 510), "Trace. Passe. Marque.", 30, Color(1, 1, 1, 0.75))
	var bounce := absf(sin(t * 3.0)) * 60.0
	ball_rot += 0.02
	_draw_ball(Vector2(360, 700 - bounce))
	draw_circle(Vector2(360, 716), 16 - bounce * 0.1, Color(0, 0, 0, 0.25))
	_button(Rect2(160, 820, 400, 110), "JOUER", "play", sb_gold, 44, DARK)
	_text(Vector2(360, 1000), "Score total : %d" % total_score, 28, Color.WHITE)
	_text(Vector2(360, 1200), "DL VIBE STUDIO", 26, GOLD)


func _draw_levels() -> void:
	var vh := maxf(H, get_viewport_rect().size.y)
	draw_rect(Rect2(0, 0, W, vh), Color(0, 0, 0, 0.5))
	_button(Rect2(20, 20, 130, 60), "RETOUR", "back_menu", sb_dark, 22, GOLD)
	_text(Vector2(360, 160), "NIVEAUX", 64, GOLD)
	var cols := 3
	for i in levels.size():
		var cx := i % cols
		var cy := i / cols
		var r := Rect2(70 + cx * 200, 230 + cy * 220, 180, 190)
		var open := i < unlocked
		_button(r, "", "lvl_%d" % i, sb_dark if open else sb_lock, 20, GOLD)
		if open:
			_text(r.position + Vector2(90, 95), str(i + 1), 64, Color.WHITE)
			for s in 3:
				_star(r.position + Vector2(45 + s * 45, 145), 16.0, s < int(best_stars[i]))
		else:
			# cadenas
			var c := r.get_center()
			draw_arc(c + Vector2(0, -12), 22, PI, TAU, 16, Color(0.6, 0.6, 0.6), 7.0)
			draw_rect(Rect2(c.x - 30, c.y - 12, 60, 46), Color(0.6, 0.6, 0.6))


# ------------------------------------------------------------------ OUTILS UI
func _text(center_baseline: Vector2, s: String, size: int, col: Color) -> void:
	var w := 1400.0
	draw_string(font, Vector2(center_baseline.x - w / 2.0, center_baseline.y), s,
		HORIZONTAL_ALIGNMENT_CENTER, w, size, col)


func _button(r: Rect2, label: String, id: String, sb: StyleBoxFlat, size: int, col: Color) -> void:
	sb.draw(get_canvas_item(), r)
	if label != "":
		_text(Vector2(r.get_center().x, r.get_center().y + size * 0.36), label, size, col)
	buttons.append({"rect": r, "id": id})


func _star(c: Vector2, r: float, filled: bool) -> void:
	var pts := PackedVector2Array()
	for i in 10:
		var rad := r if i % 2 == 0 else r * 0.45
		var a := -PI / 2.0 + i * PI / 5.0
		pts.append(c + Vector2(cos(a), sin(a)) * rad)
	if filled:
		draw_colored_polygon(pts, GOLD)
	else:
		draw_colored_polygon(pts, Color(1, 1, 1, 0.15))
	pts.append(pts[0])
	draw_polyline(pts, DARK, 2.0)


# ------------------------------------------------------------------ SAUVEGARDE
func _save() -> void:
	var cf := ConfigFile.new()
	cf.set_value("progress", "unlocked", unlocked)
	cf.set_value("progress", "stars", best_stars)
	cf.set_value("progress", "score", total_score)
	cf.save(SAVE_PATH)


func _load() -> void:
	var cf := ConfigFile.new()
	if cf.load(SAVE_PATH) != OK:
		return
	unlocked = int(cf.get_value("progress", "unlocked", 1))
	total_score = int(cf.get_value("progress", "score", 0))
	var s: Array = cf.get_value("progress", "stars", [])
	for i in mini(s.size(), best_stars.size()):
		best_stars[i] = int(s[i])
