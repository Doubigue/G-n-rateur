# Vibe Strike — DL VIBE STUDIO

Jeu de foot mobile Godot 4.3 inspiré de Score! Hero : on trace la trajectoire du ballon au doigt.

## Jouer
- Glisse depuis le ballon pour dessiner sa trajectoire.
- Termine le tracé sur un coéquipier (cercle doré) → **passe**.
- Sinon c'est un **tir** : le ballon suit ta courbe puis continue tout droit.
- Le gardien lit la direction du ballon : un tir **enroulé** le trompe (+300).
- Les défenseurs rouges interceptent tout ce qui passe sur eux.
- 10 niveaux, étoiles selon les tentatives utilisées, progression sauvegardée.

## Structure
- `project.godot` — portrait 720×1280, rendu Compatibilité (mobile)
- `scenes/main.tscn` + `scripts/main.gd` — tout le jeu (dessiné en code, aucun asset)
- `export_presets.cfg` — preset Android (com.dlvibestudio.vibestrike)

## Ajouter un niveau
Dans `_build_levels()` : `_lvl(nom, [positions coéquipiers], [[pos défenseur, amplitude, vitesse]], vitesse gardien, tentatives)`.
