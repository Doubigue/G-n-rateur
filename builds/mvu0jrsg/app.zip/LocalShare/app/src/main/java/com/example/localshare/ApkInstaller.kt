package com.example.localshare

import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.FileProvider
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipFile

/** Installation d'applications : .apk (installeur du système) et .apks / .xapk (session PackageInstaller). */
object ApkInstaller {
    private const val ACTION_RESULT = "com.example.localshare.INSTALL_RESULT"
    private val main = Handler(Looper.getMainLooper())

    fun install(ctx: Context, file: File) {
        if (Build.VERSION.SDK_INT >= 26 && !ctx.packageManager.canRequestPackageInstalls()) {
            askPermission(ctx, file)
            return
        }
        if (file.name.endsWith(".apk", ignoreCase = true)) viewInstall(ctx, file) else sessionInstall(ctx, file)
    }

    private fun askPermission(ctx: Context, file: File) {
        val settings = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (ctx is Activity && !ctx.isFinishing) {
            MaterialAlertDialogBuilder(ctx)
                .setTitle("Autoriser l'installation")
                .setMessage("Pour installer « ${file.name} », autorisez Local Share à installer des applications, puis revenez et touchez à nouveau le fichier.")
                .setPositiveButton("Autoriser") { _, _ -> safeStart(ctx, settings) }
                .setNegativeButton("Annuler", null)
                .show()
        } else {
            safeStart(ctx, settings)
        }
    }

    private fun safeStart(ctx: Context, i: Intent) {
        try {
            ctx.startActivity(i)
        } catch (_: Exception) {
            Toast.makeText(ctx, "Impossible d'ouvrir les réglages", Toast.LENGTH_LONG).show()
        }
    }

    private fun viewInstall(ctx: Context, file: File) {
        try {
            val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
            val i = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        } catch (_: Exception) {
            Toast.makeText(ctx, "Installation impossible pour ce fichier", Toast.LENGTH_LONG).show()
        }
    }

    private fun toast(app: Context, msg: String) = main.post { Toast.makeText(app, msg, Toast.LENGTH_LONG).show() }

    private fun pick(apks: List<ZipEntry>): List<ZipEntry> {
        val single = apks.firstOrNull {
            val n = it.name.lowercase()
            n == "universal.apk" || n.startsWith("standalones/")
        }
        return if (single != null) listOf(single) else apks
    }

    private fun sessionInstall(ctx: Context, file: File) {
        val app = ctx.applicationContext
        toast(app, "Préparation de l'installation…")
        Thread {
            try {
                val installer = app.packageManager.packageInstaller
                val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
                val id = installer.createSession(params)
                installer.openSession(id).use { session ->
                    ZipFile(file).use { zip ->
                        val apks = ArrayList<ZipEntry>()
                        val en = zip.entries()
                        while (en.hasMoreElements()) {
                            val e = en.nextElement()
                            if (!e.isDirectory && e.name.endsWith(".apk", ignoreCase = true)) apks.add(e)
                        }
                        val chosen = pick(apks)
                        if (chosen.isEmpty()) throw IllegalStateException("Aucun APK dans l'archive")
                        chosen.forEachIndexed { i, e ->
                            zip.getInputStream(e).use { input ->
                                session.openWrite("part_$i.apk", 0, e.size).use { out ->
                                    input.copyTo(out)
                                    session.fsync(out)
                                }
                            }
                        }
                    }
                    val intent = Intent(app, InstallResultReceiver::class.java).setAction(ACTION_RESULT)
                    val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                            (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
                    val pi = PendingIntent.getBroadcast(app, id, intent, flags)
                    session.commit(pi.intentSender)
                }
            } catch (e: Exception) {
                toast(app, "Installation impossible : ${e.message ?: "erreur"}")
            }
        }.start()
    }
}

/** Réponse du système : demande de confirmation, succès ou erreur. */
class InstallResultReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        when (intent.getIntExtra(PackageInstaller.EXTRA_STATUS, -1)) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                @Suppress("DEPRECATION")
                val confirm = if (Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableExtra(Intent.EXTRA_INTENT, Intent::class.java)
                } else {
                    intent.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                }
                try {
                    confirm?.let { ctx.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                } catch (_: Exception) {
                    Toast.makeText(ctx, "Confirmation d'installation impossible", Toast.LENGTH_LONG).show()
                }
            }
            PackageInstaller.STATUS_SUCCESS ->
                Toast.makeText(ctx, "Application installée", Toast.LENGTH_LONG).show()
            else -> {
                val msg = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: "erreur"
                Toast.makeText(ctx, "Installation échouée : $msg", Toast.LENGTH_LONG).show()
            }
        }
    }
}
