package com.example.localshare

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.io.File
import java.io.BufferedOutputStream
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import java.util.concurrent.Executor
import javax.crypto.SecretKey

class VaultActivity : AppCompatActivity() {
    private lateinit var state: TextView
    private lateinit var list: RecyclerView
    private lateinit var adapter: VaultAdapter
    private var vaultKey: SecretKey? = null
    private lateinit var executor: Executor

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null || vaultKey == null) return@registerForActivityResult
        try {
            val name = queryName(uri) ?: "fichier"
            val temp = File(cacheDir, "vault_import_${System.nanoTime()}_${Storage.safeName(name)}")
            contentResolver.openInputStream(uri)?.use { input -> temp.outputStream().use { output -> input.copyTo(output) } }
            VaultStore.importFile(this, vaultKey!!, temp)
            temp.delete()
            refresh()
            Toast.makeText(this, "Fichier ajouté au coffre-fort", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Impossible d'ajouter le fichier", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_vault)
        state = findViewById(R.id.vaultState)
        list = findViewById(R.id.vaultList)
        adapter = VaultAdapter(
            onOpen = { openItem(it) },
            onExport = { exportItem(it) },
            onDelete = { confirmDelete(it) }
        )
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter
        executor = ContextCompat.getMainExecutor(this)

        findViewById<Button>(R.id.btnVaultImport).setOnClickListener {
            picker.launch(arrayOf("*/*"))
        }
        findViewById<Button>(R.id.btnVaultBio).setOnClickListener { enableBiometric() }
        findViewById<Button>(R.id.btnVaultLock).setOnClickListener { lock() }

        if (!VaultStore.isConfigured(this)) setupVault() else askPinOrBiometric()
    }

    private fun setupVault() {
        val box = View.inflate(this, R.layout.dialog_vault_pin, null)
        val pin = box.findViewById<EditText>(R.id.pin)
        val confirm = box.findViewById<EditText>(R.id.pinConfirm)
        MaterialAlertDialogBuilder(this)
            .setTitle("Créer le coffre-fort")
            .setMessage("Choisissez un code PIN. Vos fichiers seront chiffrés localement.")
            .setView(box)
            .setCancelable(false)
            .setPositiveButton("Créer", null)
            .setNegativeButton("Annuler") { _, _ -> finish() }
            .create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(-1).setOnClickListener {
                        val a = pin.text.toString(); val b = confirm.text.toString()
                        if (a.length < 4 || a != b) {
                            confirm.error = "PIN invalide ou différent"
                            return@setOnClickListener
                        }
                        vaultKey = VaultStore.create(this, a.toCharArray())
                        dialog.dismiss(); unlocked()
                        MaterialAlertDialogBuilder(this)
                            .setTitle("Biométrie")
                            .setMessage("Voulez-vous autoriser l'empreinte ou la biométrie pour ouvrir le coffre plus rapidement ?")
                            .setPositiveButton("Activer") { _, _ -> enableBiometric() }
                            .setNegativeButton("Plus tard", null).show()
                    }
                }
            }.show()
    }

    private fun askPinOrBiometric() {
        if (VaultStore.hasBiometric(this)) {
            MaterialAlertDialogBuilder(this)
                .setTitle("Coffre-fort verrouillé")
                .setMessage("Déverrouillez avec votre biométrie ou votre PIN.")
                .setPositiveButton("Biométrie") { _, _ -> biometricUnlock() }
                .setNegativeButton("PIN") { _, _ -> pinDialog() }
                .setNeutralButton("Fermer") { _, _ -> finish() }
                .show()
        } else pinDialog()
    }

    private fun pinDialog() {
        val input = EditText(this).apply { inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD }
        MaterialAlertDialogBuilder(this)
            .setTitle("PIN du coffre-fort")
            .setView(input)
            .setPositiveButton("Déverrouiller", null)
            .setNegativeButton("Annuler") { _, _ -> finish() }
            .create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(-1).setOnClickListener {
                        val key = VaultStore.unlockWithPin(this, input.text.toString().toCharArray())
                        if (key == null) input.error = "PIN incorrect"
                        else { vaultKey = key; dialog.dismiss(); unlocked() }
                    }
                }
            }.show()
    }

    private fun biometricUnlock() {
        val cipher = VaultStore.biometricCipher(this)
        if (cipher == null) { pinDialog(); return }
        val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                val key = VaultStore.unlockWithBiometric(this@VaultActivity, result.cryptoObject?.cipher!!)
                if (key != null) { vaultKey = key; unlocked() } else pinDialog()
            }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { pinDialog() }
        })
        prompt.authenticate(BiometricPrompt.PromptInfo.Builder()
            .setTitle("Ouvrir le coffre-fort")
            .setSubtitle("Utilisez votre biométrie")
            .setNegativeButtonText("Utiliser le PIN")
            .build(), BiometricPrompt.CryptoObject(cipher))
    }

    private fun enableBiometric() {
        val key = vaultKey ?: return
        if (VaultStore.enableBiometric(this, key)) {
            Toast.makeText(this, "Biométrie activée", Toast.LENGTH_SHORT).show()
            findViewById<Button>(R.id.btnVaultBio).text = "Biométrie activée"
        } else Toast.makeText(this, "Biométrie indisponible sur cet appareil", Toast.LENGTH_LONG).show()
    }

    private fun unlocked() {
        state.text = "🔓 Coffre déverrouillé · fichiers chiffrés sur l'appareil"
        refresh()
        handleSecureFolderRequest()
    }

    /** Convertit le dossier source en archive temporaire privée, chiffre l'archive dans le coffre,
     * puis supprime l'original seulement si le chiffrement et l'import ont réussi. */
    private fun handleSecureFolderRequest() {
        val path = intent.getStringExtra(EXTRA_SECURE_FOLDER) ?: return
        intent.removeExtra(EXTRA_SECURE_FOLDER)
        val source = try { File(path).canonicalFile } catch (_: Exception) { null }
        if (source == null || !source.isDirectory || source == filesDir || source.path.startsWith(filesDir.path + File.separator)) {
            Toast.makeText(this, "Dossier source invalide", Toast.LENGTH_LONG).show(); return
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Chiffrer le dossier ?")
            .setMessage("${source.name} sera placé dans le coffre chiffré. Après vérification de l'import, l'original sera supprimé du stockage partagé pour qu'un autre explorateur ne puisse plus l'ouvrir. Le dossier sera conservé sous forme d'une archive ZIP chiffrée.")
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Chiffrer et déplacer") { _, _ -> secureFolder(source) }
            .show()
    }

    private fun secureFolder(source: File) {
        val key = vaultKey ?: return
        val archive = File(cacheDir, "secure_${System.nanoTime()}_${Storage.safeName(source.name)}.zip")
        try {
            ZipOutputStream(BufferedOutputStream(FileOutputStream(archive))).use { zip ->
                fun add(file: File, relative: String) {
                    if (file.isDirectory) {
                        val children = file.listFiles() ?: throw java.io.IOException("Lecture impossible: ${file.name}")
                        if (children.isEmpty() && relative.isNotEmpty()) { zip.putNextEntry(ZipEntry(if (relative.endsWith("/")) relative else "$relative/")); zip.closeEntry() }
                        children.forEach { child -> add(child, if (relative.isEmpty()) child.name else "$relative/${child.name}") }
                    } else {
                        zip.putNextEntry(ZipEntry(relative))
                        FileInputStream(file).use { it.copyTo(zip, 64 * 1024) }
                        zip.closeEntry()
                    }
                }
                add(source, "")
            }
            val vaultItem = VaultStore.importFile(this, key, archive)
            // Check the encrypted container can be read back before deleting any originals.
            if (!vaultItem.file.isFile || vaultItem.file.length() <= 12L) throw java.io.IOException("Vérification du coffre échouée")
            val deleted = source.deleteRecursively()
            if (deleted) {
                Toast.makeText(this, "Dossier chiffré dans le coffre. L'original n'est plus accessible aux autres explorateurs.", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Copie chiffrée créée, mais certains originaux n'ont pas pu être supprimés. Vérifiez le dossier source et supprimez les restes manuellement.", Toast.LENGTH_LONG).show()
            }
            refresh()
        } catch (e: Exception) {
            Toast.makeText(this, "Échec du chiffrement : l'original est conservé. ${e.message ?: ""}", Toast.LENGTH_LONG).show()
        } finally { archive.delete() }
    }

    companion object { const val EXTRA_SECURE_FOLDER = "com.example.localshare.EXTRA_SECURE_FOLDER" }

    private fun lock() { vaultKey = null; state.text = "🔒 Coffre verrouillé"; adapter.submitList(emptyList()); askPinOrBiometric() }

    private fun refresh() {
        val key = vaultKey ?: return
        val items = VaultStore.list(this, key)
        adapter.submitList(items)
        state.text = "🔓 ${items.size} fichier(s) protégé(s)"
    }

    private fun openItem(item: VaultStore.Item) {
        val key = vaultKey ?: return
        try {
            val target = VaultStore.exportTo(this, key, item, cacheDir)
            Storage.open(this, target)
        } catch (_: Exception) { Toast.makeText(this, "Impossible d'ouvrir le fichier", Toast.LENGTH_LONG).show() }
    }

    private fun exportItem(item: VaultStore.Item) {
        val key = vaultKey ?: return
        try {
            val dir = Storage.categoryDir(this, item.name)
            val file = VaultStore.exportTo(this, key, item, dir)
            Toast.makeText(this, "Exporté dans ${dir.name}", Toast.LENGTH_LONG).show()
            Storage.open(this, file)
        } catch (_: Exception) { Toast.makeText(this, "Export impossible", Toast.LENGTH_LONG).show() }
    }

    private fun confirmDelete(item: VaultStore.Item) {
        MaterialAlertDialogBuilder(this).setTitle("Supprimer du coffre ?")
            .setMessage(item.name).setNegativeButton("Annuler", null)
            .setPositiveButton("Supprimer") { _, _ -> VaultStore.delete(item); refresh() }.show()
    }

    private fun queryName(uri: android.net.Uri): String? {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0)
        }
        return uri.lastPathSegment?.substringAfterLast('/')
    }
}
