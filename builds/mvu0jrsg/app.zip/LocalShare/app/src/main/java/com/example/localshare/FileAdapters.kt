package com.example.localshare

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.card.MaterialCardView

class FileGridAdapter(
    private val onClick: (FileItem) -> Unit,
    private val onLongClick: ((FileItem) -> Unit)? = null
) : RecyclerView.Adapter<FileGridAdapter.H>() {
    class H(
        val card: MaterialCardView,
        val thumb: ImageView,
        val icon: TextView,
        val badge: TextView,
        val title: TextView,
        val sub: TextView
    ) : RecyclerView.ViewHolder(card)

    private var items = emptyList<FileItem>()
    data class FileItem(val file: java.io.File, val isDir: Boolean, val name: String, val size: Long, val modified: Long)

    fun submit(list: List<FileItem>) { items = list; notifyDataSetChanged() }

    /** Fichiers (hors dossiers) affichés : sert de liste de lecture / de photos. */
    fun files(): List<java.io.File> = items.filter { !it.isDir }.map { it.file }

    override fun onCreateViewHolder(p: ViewGroup, t: Int): H {
        val v = LayoutInflater.from(p.context).inflate(R.layout.item_file_grid, p, false)
        return H(
            v as MaterialCardView,
            v.findViewById(R.id.fileThumb), v.findViewById(R.id.fileIcon), v.findViewById(R.id.fileBadge),
            v.findViewById(R.id.fileTitle), v.findViewById(R.id.fileSub)
        )
    }

    override fun getItemCount() = items.size

    override fun onViewRecycled(h: H) {
        Thumbs.cancel(h.thumb)
        super.onViewRecycled(h)
    }

    override fun onBindViewHolder(h: H, pos: Int) {
        val x = items[pos]
        val kind = if (x.isDir) null else Explorer.kindOf(x.name)
        h.icon.text = (if (FolderLock.isLocked(h.card.context, x.file.path)) "🔑 " else "") + (if (x.isDir) "📁" else iconFor(x.name))
        h.icon.visibility = View.VISIBLE
        h.badge.visibility = if (kind == Explorer.VIDEOS) View.VISIBLE else View.GONE
        h.title.text = (if (FolderLock.isLocked(h.card.context, x.file.path)) "🔑 " else "") + x.name
        h.sub.text = if (x.isDir) "Dossier" else "${Fmt.bytes(x.size)} · ${Fmt.date(x.modified)}"
        if (x.isDir) {
            Thumbs.cancel(h.thumb)
            h.thumb.visibility = View.GONE
        } else {
            h.thumb.visibility = View.VISIBLE
            Thumbs.show(h.thumb, x.file, kind) { ok -> h.icon.visibility = if (ok) View.GONE else View.VISIBLE }
        }
        h.card.setOnClickListener { onClick(x) }
        h.card.setOnLongClickListener {
            val cb = onLongClick
            if (cb != null) { cb(x); true }
            else if (!x.isDir) { Storage.open(h.card.context, x.file, files()); true }
            else false
        }
    }

    private fun iconFor(n: String): String = when (Storage.categoryFor(n)) {
        Storage.VIDEO -> "🎬"
        Storage.MUSIC -> "🎵"
        Storage.APPLICATION -> "📦"
        Storage.DOCUMENTS -> "📄"
        else -> "🗂️"
    }
}

class CategoryAdapter(private val onClick: (String) -> Unit) : RecyclerView.Adapter<CategoryAdapter.H>() {
    data class Item(val name: String, val icon: String, val count: Int)
    data class H(val v: View, val icon: TextView, val title: TextView, val sub: TextView) : RecyclerView.ViewHolder(v)
    private var items = emptyList<Item>()
    fun submit(list: List<Item>) { items = list; notifyDataSetChanged() }
    override fun onCreateViewHolder(p: ViewGroup, t: Int): H {
        val v = LayoutInflater.from(p.context).inflate(R.layout.item_category, p, false)
        return H(v, v.findViewById(R.id.categoryIcon), v.findViewById(R.id.categoryTitle), v.findViewById(R.id.categorySub))
    }
    override fun getItemCount() = items.size
    override fun onBindViewHolder(h: H, pos: Int) {
        val x = items[pos]; h.icon.text=x.icon; h.title.text=x.name; h.sub.text="${x.count} élément(s)"
        h.v.setOnClickListener { onClick(x.name) }
    }
}
