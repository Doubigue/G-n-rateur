package com.example.localshare

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.ui.PlayerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.common.util.concurrent.ListenableFuture
import java.io.File

/** Liste de lecture / de photos transmise à l'écran suivant (évite la limite de taille des Intent). */
object MediaQueue {
    @Volatile var files: List<File> = emptyList()
    @Volatile var index: Int = 0
    @Volatile var pending: Boolean = false
}

/** Lecteur intégré : vidéo (plein écran) et musique (liste de lecture, arrière-plan, notification). */
class MediaActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PATH = "path"

        fun start(ctx: Context, files: List<File>, index: Int) {
            MediaQueue.files = files
            MediaQueue.index = index
            MediaQueue.pending = true
            val i = Intent(ctx, MediaActivity::class.java).putExtra(EXTRA_PATH, files[index].path)
            if (ctx !is Activity) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        }
    }

    private lateinit var playerView: PlayerView
    private lateinit var topBar: View
    private lateinit var tvTitle: TextView
    private var controller: MediaController? = null
    private var future: ListenableFuture<MediaController>? = null
    private var isVideo = false
    private var errorShown = false

    private val listener = object : Player.Listener {
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            errorShown = false
            updateTitle()
        }

        override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) = updateTitle()

        override fun onPlayerError(error: PlaybackException) = showUnsupported()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_media)
        playerView = findViewById(R.id.playerView)
        topBar = findViewById(R.id.topBar)
        tvTitle = findViewById(R.id.tvMediaTitle)
        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        playerView.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { v ->
            topBar.visibility = if (v == View.VISIBLE) View.VISIBLE else View.GONE
        })

        // Fichiers à lire : uniquement à l'ouverture depuis une liste (pas à la rotation / restauration).
        var items: List<File>? = null
        var start = 0
        val extra = intent.getStringExtra(EXTRA_PATH)
        if (savedInstanceState == null && extra != null) {
            if (MediaQueue.pending && MediaQueue.files.any { it.path == extra }) {
                items = MediaQueue.files
                start = MediaQueue.files.indexOfFirst { it.path == extra }.coerceAtLeast(0)
            } else {
                items = listOf(File(extra))
            }
            MediaQueue.pending = false
        }
        val playlist = items
        val startIndex = start
        if (playlist != null) applyMode(Explorer.kindOf(playlist[startIndex].name) == Explorer.VIDEOS)
        else applyMode(false)

        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val f = MediaController.Builder(this, token).buildAsync()
        future = f
        f.addListener({
            val c = try {
                f.get()
            } catch (_: Exception) {
                Toast.makeText(this, "Lecteur indisponible", Toast.LENGTH_LONG).show()
                finish()
                return@addListener
            }
            controller = c
            playerView.player = c
            c.addListener(listener)
            if (playlist != null) {
                c.setMediaItems(playlist.map { mediaItemOf(it) }, startIndex, 0L)
                c.prepare()
                c.play()
            } else {
                // Réouverture depuis la notification : on affiche ce qui joue déjà.
                val uri = c.currentMediaItem?.localConfiguration?.uri
                if (uri?.path != null) applyMode(Explorer.kindOf(uri.path!!) == Explorer.VIDEOS)
            }
            updateTitle()
        }, ContextCompat.getMainExecutor(this))
    }

    private fun mediaItemOf(f: File): MediaItem =
        MediaItem.Builder()
            .setUri(Uri.fromFile(f))
            .setMediaMetadata(MediaMetadata.Builder().setTitle(f.nameWithoutExtension).build())
            .build()

    private fun applyMode(video: Boolean) {
        isVideo = video
        if (video) {
            playerView.setControllerShowTimeoutMs(3000)
            playerView.setControllerHideOnTouch(true)
            val c = WindowCompat.getInsetsController(window, window.decorView)
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            // Musique : commandes toujours visibles, pochette ou icône au centre.
            playerView.setControllerShowTimeoutMs(0)
            playerView.setControllerHideOnTouch(false)
            ContextCompat.getDrawable(this, R.drawable.ex_audio)?.mutate()?.let {
                it.setTint(0xFFFFFFFF.toInt())
                playerView.setDefaultArtwork(it)
            }
            playerView.showController()
        }
    }

    private fun updateTitle() {
        val c = controller ?: return
        val t = c.mediaMetadata.title ?: c.currentMediaItem?.mediaMetadata?.title
        tvTitle.text = t?.toString().orEmpty()
    }

    private fun showUnsupported() {
        if (errorShown) return
        errorShown = true
        val path = controller?.currentMediaItem?.localConfiguration?.uri?.path
        val b = MaterialAlertDialogBuilder(this)
            .setTitle("Format non pris en charge")
            .setMessage("Le lecteur intégré ne peut pas lire ce fichier.")
            .setNegativeButton("Fermer", null)
        if (path != null) {
            b.setPositiveButton("Ouvrir avec une autre appli") { _, _ -> Storage.openExternal(this, File(path)) }
        }
        b.show()
    }

    override fun onStop() {
        // La vidéo se met en pause hors de l'écran ; la musique continue (service de lecture).
        if (isVideo && !isChangingConfigurations) controller?.pause()
        super.onStop()
    }

    override fun onDestroy() {
        playerView.player = null
        controller?.removeListener(listener)
        if (isFinishing && isVideo) {
            controller?.stop()
            controller?.clearMediaItems()
        }
        future?.let { MediaController.releaseFuture(it) }
        controller = null
        super.onDestroy()
    }
}
