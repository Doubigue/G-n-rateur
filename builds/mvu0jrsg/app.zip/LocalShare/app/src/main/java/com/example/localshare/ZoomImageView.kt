package com.example.localshare

import android.content.Context
import android.graphics.Matrix
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import androidx.appcompat.widget.AppCompatImageView

/** Image avec zoom par pincement, déplacement et double appui. */
class ZoomImageView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : AppCompatImageView(context, attrs) {

    private val m = Matrix()
    private val rect = RectF()
    private var scale = 1f
    private val maxScale = 6f

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            val target = (scale * detector.scaleFactor).coerceIn(1f, maxScale)
            val f = target / scale
            m.postScale(f, f, detector.focusX, detector.focusY)
            scale = target
            fix()
            imageMatrix = m
            return true
        }
    })

    private val gestures = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true

        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (scale > 1.01f) fit() else zoomTo(2.5f, e.x, e.y)
            return true
        }

        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
            if (scale <= 1.01f) return false
            m.postTranslate(-distanceX, -distanceY)
            fix()
            imageMatrix = m
            return true
        }
    })

    init {
        scaleType = ScaleType.MATRIX
    }

    fun setContent(d: Drawable?) {
        setImageDrawable(d)
        fit()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        fit()
    }

    private fun fit() {
        val d = drawable ?: return
        val dw = d.intrinsicWidth.toFloat()
        val dh = d.intrinsicHeight.toFloat()
        if (dw <= 0f || dh <= 0f || width == 0 || height == 0) return
        val s = minOf(width / dw, height / dh)
        m.reset()
        m.postScale(s, s)
        m.postTranslate((width - dw * s) / 2f, (height - dh * s) / 2f)
        scale = 1f
        imageMatrix = m
    }

    private fun zoomTo(target: Float, fx: Float, fy: Float) {
        val f = target / scale
        m.postScale(f, f, fx, fy)
        scale = target
        fix()
        imageMatrix = m
    }

    /** Garde l'image dans l'écran (centrée si plus petite que la vue). */
    private fun fix() {
        val d = drawable ?: return
        rect.set(0f, 0f, d.intrinsicWidth.toFloat(), d.intrinsicHeight.toFloat())
        m.mapRect(rect)
        var dx = 0f
        var dy = 0f
        if (rect.width() <= width) dx = (width - rect.width()) / 2f - rect.left
        else if (rect.left > 0f) dx = -rect.left
        else if (rect.right < width) dx = width - rect.right
        if (rect.height() <= height) dy = (height - rect.height()) / 2f - rect.top
        else if (rect.top > 0f) dy = -rect.top
        else if (rect.bottom < height) dy = height - rect.bottom
        m.postTranslate(dx, dy)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (drawable == null) return false
        scaleDetector.onTouchEvent(event)
        gestures.onTouchEvent(event)
        parent?.requestDisallowInterceptTouchEvent(scale > 1.01f || event.pointerCount > 1)
        return true
    }
}
