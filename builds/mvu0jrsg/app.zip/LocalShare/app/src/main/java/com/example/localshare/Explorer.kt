package com.example.localshare

import android.content.Context
import java.io.File
import java.util.PriorityQueue

/** Analyse du stockage pour l'écran d'accueil « explorateur » : catégories, tailles, fichiers récents. */
object Explorer {
    const val IMAGES = "images"
    const val VIDEOS = "videos"
    const val AUDIO = "audio"
    const val DOCUMENTS = "documents"
    const val APK = "apk"
    const val RECENT = "recent"
    const val FAVORITES = "favorites"

    private val IMG = setOf("jpg", "jpeg", "png", "gif", "webp", "heic", "heif", "bmp")
    private val VID = setOf("mp4", "mkv", "avi", "mov", "webm", "m4v", "3gp", "3g2", "ts", "mts", "m2ts")
    private val AUD = setOf("mp3", "wav", "flac", "ogg", "oga", "m4a", "aac", "opus", "wma", "amr")
    private val DOC = setOf(
        "pdf", "doc", "docx", "odt", "rtf", "txt", "csv",
        "xls", "xlsx", "ods", "ppt", "pptx", "odp", "epub", "md", "json", "xml"
    )
    private val APKS = setOf("apk", "xapk", "apks")

    fun kindOf(name: String): String? {
        val ext = name.substringAfterLast('.', "").lowercase()
        return when (ext) {
            in IMG -> IMAGES
            in VID -> VIDEOS
            in AUD -> AUDIO
            in DOC -> DOCUMENTS
            in APKS -> APK
            else -> null
        }
    }

    fun title(kind: String): String = when (kind) {
        IMAGES -> "Images"
        VIDEOS -> "Vidéos"
        AUDIO -> "Audio"
        DOCUMENTS -> "Documents"
        APK -> "Applications"
        RECENT -> "Récents"
        FAVORITES -> "Favoris"
        else -> "Fichiers"
    }

    class Scan(val sizes: Map<String, Long>, val downloads: Long, val recents: List<File>)

    private class Entry(val file: File, val modified: Long)

    private fun walk(root: File): Sequence<File> =
        root.walkTopDown()
            .onEnter { d ->
                d == root || (!d.name.startsWith(".") && !(d.parentFile == root && d.name == "Android"))
            }
            .filter { it.isFile && !it.name.startsWith(".") && !it.name.endsWith(".part") }

    /** Tailles par catégorie + 12 fichiers les plus récents. À appeler hors du thread principal. */
    fun scan(root: File): Scan {
        val sizes = HashMap<String, Long>()
        var downloads = 0L
        val dl = File(root, "Download").path + File.separator
        val heap = PriorityQueue<Entry>(16, compareBy<Entry> { it.modified })
        for (f in walk(root)) {
            val len = f.length()
            if (f.path.startsWith(dl)) downloads += len
            val k = kindOf(f.name) ?: continue
            sizes[k] = (sizes[k] ?: 0L) + len
            heap.offer(Entry(f, f.lastModified()))
            if (heap.size > 12) heap.poll()
        }
        return Scan(sizes, downloads, heap.sortedByDescending { it.modified }.map { it.file })
    }

    /** Les [limit] fichiers les plus récents qui satisfont [accept]. À appeler hors du thread principal. */
    fun scanFiles(root: File, limit: Int, accept: (File) -> Boolean): List<File> {
        val heap = PriorityQueue<Entry>(16, compareBy<Entry> { it.modified })
        for (f in walk(root)) {
            if (!accept(f)) continue
            heap.offer(Entry(f, f.lastModified()))
            if (heap.size > limit) heap.poll()
        }
        return heap.sortedByDescending { it.modified }.map { it.file }
    }
}

/** Fichiers favoris (étoile), mémorisés par chemin. */
object Favorites {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("favorites", Context.MODE_PRIVATE)

    fun all(ctx: Context): List<File> =
        (prefs(ctx).getStringSet("paths", emptySet()) ?: emptySet())
            .map { File(it) }
            .filter { it.exists() }

    fun isFavorite(ctx: Context, f: File): Boolean =
        prefs(ctx).getStringSet("paths", emptySet())?.contains(f.path) == true

    /** Retourne le nouvel état (true = désormais favori). */
    fun toggle(ctx: Context, f: File): Boolean {
        val set = HashSet(prefs(ctx).getStringSet("paths", emptySet()) ?: emptySet())
        val now = if (set.contains(f.path)) { set.remove(f.path); false } else { set.add(f.path); true }
        prefs(ctx).edit().putStringSet("paths", set).apply()
        return now
    }
}
