package com.example.localshare

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.pdf.PdfDocument
import android.media.ExifInterface
import android.net.Uri
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Scanner de documents.
 *  - Principal : scanner Google ML Kit (détection des bords, recadrage, plusieurs pages, import galerie) -> PDF.
 *    Aucune permission caméra n'est demandée : l'interface est fournie par Google Play Services.
 *  - Repli (téléphone sans Google Play Services) : photo avec l'appareil photo du système, convertie en PDF.
 * Le PDF est enregistré dans LocalShare/Documents (comme les fichiers reçus), puis on propose de l'envoyer ou de l'ouvrir.
 *
 * À créer comme propriété de l'activité (les lanceurs doivent être enregistrés avant le démarrage de l'écran) :
 *     private val docScanner = DocScanner(this)
 */
class DocScanner(private val a: ComponentActivity) {

    private val mlkitLauncher = a.registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            val uri = GmsDocumentScanningResult.fromActivityResultIntent(r.data)?.pdf?.uri
            if (uri != null) save { copyPdf(uri) } else toast("Aucun document scanné")
        }
    }

    private val cameraLauncher = a.registerForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { ok ->
        if (ok) save { photoToPdf(captureFile()) } else captureFile().delete()
    }

    /** Lance le scanner. */
    fun start() {
        val options = GmsDocumentScannerOptions.Builder()
            .setGalleryImportAllowed(true)
            .setPageLimit(30)
            .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_PDF)
            .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
            .build()
        try {
            GmsDocumentScanning.getClient(options).getStartScanIntent(a)
                .addOnSuccessListener { sender ->
                    mlkitLauncher.launch(IntentSenderRequest.Builder(sender).build())
                }
                .addOnFailureListener { startCamera() }
        } catch (_: Throwable) {
            startCamera()
        }
    }

    // ---------------------------------------------------------------- repli : appareil photo -> PDF
    private fun captureFile() = File(a.cacheDir, "scan_capture.jpg")

    private fun startCamera() {
        toast("Scanner Google indisponible : prenez le document en photo.")
        try {
            val f = captureFile()
            f.delete()
            val uri = FileProvider.getUriForFile(a, "${a.packageName}.fileprovider", f)
            cameraLauncher.launch(uri)
        } catch (_: Exception) {
            toast("Aucune application appareil photo disponible.")
        }
    }

    private fun photoToPdf(photo: File): File? {
        if (!photo.exists() || photo.length() == 0L) return null

        // Réduit la photo (≈ A4 à 150 dpi) pour garder un PDF léger.
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(photo.path, bounds)
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= 2000) sample *= 2
        var bmp = BitmapFactory.decodeFile(
            photo.path, BitmapFactory.Options().apply { inSampleSize = sample }
        ) ?: return null

        // Redresse la photo selon l'orientation EXIF.
        val orientation = try {
            ExifInterface(photo.path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        } catch (_: Exception) {
            ExifInterface.ORIENTATION_NORMAL
        }
        val degrees = when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (degrees != 0f) {
            val m = Matrix().apply { postRotate(degrees) }
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }

        val dest = newFile("pdf")
        val pageW = 595 // A4 : 595 pt de large
        val pageH = (pageW.toFloat() * bmp.height / bmp.width).toInt().coerceAtLeast(1)
        val pdf = PdfDocument()
        try {
            val page = pdf.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, 1).create())
            page.canvas.drawBitmap(bmp, null, Rect(0, 0, pageW, pageH), Paint(Paint.FILTER_BITMAP_FLAG))
            pdf.finishPage(page)
            FileOutputStream(dest).use { pdf.writeTo(it) }
        } finally {
            pdf.close()
            bmp.recycle()
            photo.delete()
        }
        return dest
    }

    // ---------------------------------------------------------------- enregistrement
    private fun copyPdf(src: Uri): File? {
        val dest = newFile("pdf")
        val input = a.contentResolver.openInputStream(src) ?: return null
        input.use { i -> FileOutputStream(dest).use { o -> i.copyTo(o) } }
        return dest
    }

    /** Scan_AAAAMMJJ_HHMMSS.pdf dans le sous-dossier automatique « Documents » de LocalShare. */
    private fun newFile(ext: String): File {
        val name = "Scan_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + "." + ext
        return Storage.uniqueFile(Storage.categoryDir(a, name), name)
    }

    private fun save(work: () -> File?) {
        a.lifecycleScope.launch {
            val f = withContext(Dispatchers.IO) {
                try {
                    work()
                } catch (_: Exception) {
                    null
                }
            }
            if (f != null) showDone(f) else toast("Échec de l’enregistrement du scan.")
        }
    }

    // ---------------------------------------------------------------- après le scan
    private fun showDone(f: File) {
        MaterialAlertDialogBuilder(a)
            .setTitle("Scan enregistré")
            .setMessage("${f.name}\n${Fmt.bytes(f.length())} · ${Storage.FOLDER}/${f.parentFile?.name ?: ""}")
            .setPositiveButton("Envoyer") { _, _ -> send(f) }
            .setNeutralButton("Ouvrir") { _, _ -> Storage.open(a, f) }
            .setNegativeButton("Fermer", null)
            .show()
    }

    /** Ajoute le PDF à la file d'envoi Local Share (envoyé dès qu'un appareil est connecté). */
    private fun send(f: File) {
        try {
            val uri = FileProvider.getUriForFile(a, "${a.packageName}.fileprovider", f)
            val i = Intent(Intent.ACTION_SEND)
                .setType("application/pdf")
                .putExtra(Intent.EXTRA_STREAM, uri)
            a.app.transfers.queueFromIntent(i)
            toast("Prêt à envoyer : touchez l’appareil destinataire.")
        } catch (_: Exception) {
            toast("Envoi impossible.")
        }
    }

    private fun toast(m: String) {
        Toast.makeText(a, m, Toast.LENGTH_LONG).show()
    }
}
