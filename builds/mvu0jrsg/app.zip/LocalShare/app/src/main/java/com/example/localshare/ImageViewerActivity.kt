package com.example.localshare

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Animatable
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Visionneuse de photos : défilement gauche/droite, zoom, GIF/WebP animés. */
class ImageViewerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PATH = "path"
        private const val STATE_PAGE = "page"

        fun start(ctx: Context, files: List<File>, index: Int) {
            MediaQueue.files = files
            MediaQueue.index = index
            MediaQueue.pending = true
            val i = Intent(ctx, ImageViewerActivity::class.java).putExtra(EXTRA_PATH, files[index].path)
            if (ctx !is Activity) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        }
    }

    private lateinit var files: List<File>
    private lateinit var pager: ViewPager2
    private lateinit var tvTitle: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_image_viewer)

        val extra = intent.getStringExtra(EXTRA_PATH)
        files = if (extra != null && MediaQueue.files.any { it.path == extra }) MediaQueue.files
        else listOfNotNull(extra?.let { File(it) })
        if (files.isEmpty()) {
            finish()
            return
        }
        val start = savedInstanceState?.getInt(STATE_PAGE)
            ?: files.indexOfFirst { it.path == extra }.coerceAtLeast(0)

        tvTitle = findViewById(R.id.tvImageTitle)
        pager = findViewById(R.id.pager)
        pager.adapter = PageAdapter()
        pager.setCurrentItem(start, false)
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) = updateTitle(position)
        })
        updateTitle(start)

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<View>(R.id.btnOpenWith).setOnClickListener {
            Storage.openExternal(this, files[pager.currentItem])
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        if (::pager.isInitialized) outState.putInt(STATE_PAGE, pager.currentItem)
    }

    private fun updateTitle(pos: Int) {
        tvTitle.text = "${pos + 1} / ${files.size} · ${files[pos].name}"
    }

    private inner class PageAdapter : RecyclerView.Adapter<ZoomHolder>() {
        override fun getItemCount() = files.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ZoomHolder {
            val v = ZoomImageView(parent.context)
            v.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            return ZoomHolder(v)
        }

        override fun onBindViewHolder(h: ZoomHolder, position: Int) {
            h.job?.cancel()
            h.view.setContent(null)
            val f = files[position]
            h.job = lifecycleScope.launch {
                val d = withContext(Dispatchers.IO) { Thumbs.loadFull(resources, f) }
                if (d != null) {
                    h.view.setContent(d)
                    (d as? Animatable)?.start()
                } else {
                    Toast.makeText(this@ImageViewerActivity, "Image illisible : ${f.name}", Toast.LENGTH_SHORT).show()
                }
            }
        }

        override fun onViewRecycled(h: ZoomHolder) {
            h.job?.cancel()
            (h.view.drawable as? Animatable)?.stop()
            h.view.setContent(null)
            super.onViewRecycled(h)
        }
    }
}

private class ZoomHolder(val view: ZoomImageView) : RecyclerView.ViewHolder(view) {
    var job: Job? = null
}
