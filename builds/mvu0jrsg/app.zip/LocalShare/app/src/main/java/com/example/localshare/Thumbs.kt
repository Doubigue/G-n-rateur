package com.example.localshare

import android.content.Context
import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.Animatable
import android.graphics.drawable.AnimationDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.media.MediaMetadataRetriever
import android.os.Build
import android.util.LruCache
import android.view.View
import android.widget.ImageView
import androidx.annotation.RequiresApi
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Vignettes des fichiers :
 *  - images : aperçu réel (GIF / WebP animés sur Android 9+),
 *  - vidéos : vraies images de la vidéo, qui défilent en boucle (aperçu animé),
 *  - musique : pochette intégrée au fichier,
 *  - APK : icône de l'application.
 * Le chargement se fait hors du thread principal ; une vue recyclée annule son chargement précédent.
 */
object Thumbs {
    private const val SIZE = 360
    private const val FRAME_MS = 800

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val gate = Semaphore(3)

    private val cache = object : LruCache<String, List<Bitmap>>(28 * 1024 * 1024) {
        override fun sizeOf(key: String, value: List<Bitmap>): Int =
            value.sumOf { it.byteCount }.coerceAtLeast(1)
    }

    fun placeholder(kind: String?): Int = when (kind) {
        Explorer.IMAGES -> R.drawable.ex_image
        Explorer.VIDEOS -> R.drawable.ex_video
        Explorer.AUDIO -> R.drawable.ex_audio
        Explorer.APK -> R.drawable.ex_apps
        else -> R.drawable.ex_doc
    }

    /** Annule le chargement en cours de [view] et la vide. */
    fun cancel(view: ImageView) {
        (view.getTag(R.id.thumb_job) as? Job)?.cancel()
        view.setTag(R.id.thumb_job, null)
        (view.drawable as? Animatable)?.stop()
        view.setImageDrawable(null)
    }

    /**
     * Affiche la vignette de [file] dans [view].
     * [onResult] est appelé avec false tout de suite (afficher l'icône de remplacement),
     * puis avec true dès qu'une vraie vignette est affichée.
     */
    fun show(view: ImageView, file: File, kind: String?, onResult: (Boolean) -> Unit = {}) {
        cancel(view)
        ensureAttachHook(view)
        view.scaleType = if (kind == Explorer.APK) ImageView.ScaleType.FIT_CENTER else ImageView.ScaleType.CENTER_CROP
        onResult(false)
        if (kind != Explorer.IMAGES && kind != Explorer.VIDEOS && kind != Explorer.AUDIO && kind != Explorer.APK) return

        val key = "${file.path}|${file.lastModified()}|${file.length()}"
        val cached = cache.get(key)
        if (cached != null && cached.isNotEmpty() && !(kind == Explorer.IMAGES && isAnimatedImage(file.name))) {
            apply(view, cached, onResult)
            if (kind == Explorer.VIDEOS && cached.size == 1) loadMoreFrames(view, file, key, cached, onResult)
            return
        }

        val job = scope.launch {
            try {
                if (kind == Explorer.IMAGES && Build.VERSION.SDK_INT >= 28 && isAnimatedImage(file.name)) {
                    val d = gate.withPermit { withContext(Dispatchers.IO) { animated(file) } }
                    if (d != null) {
                        view.setImageDrawable(d)
                        onResult(true)
                        if (view.isAttachedToWindow) (d as? Animatable)?.start()
                        return@launch
                    }
                }
                val first = gate.withPermit {
                    withContext(Dispatchers.IO) { firstFrame(view.context, file, kind) }
                } ?: return@launch
                cache.put(key, listOf(first))
                apply(view, listOf(first), onResult)
                if (kind == Explorer.VIDEOS) fetchMore(view, file, key, first, onResult)
            } catch (e: CancellationException) {
                throw e
            } catch (_: Throwable) {
                // vignette impossible : l'icône de remplacement reste affichée
            }
        }
        view.setTag(R.id.thumb_job, job)
    }

    private fun loadMoreFrames(view: ImageView, file: File, key: String, have: List<Bitmap>, onResult: (Boolean) -> Unit) {
        val job = scope.launch {
            try {
                fetchMore(view, file, key, have[0], onResult)
            } catch (e: CancellationException) {
                throw e
            } catch (_: Throwable) {
            }
        }
        view.setTag(R.id.thumb_job, job)
    }

    private suspend fun fetchMore(view: ImageView, file: File, key: String, first: Bitmap, onResult: (Boolean) -> Unit) {
        val more = gate.withPermit { withContext(Dispatchers.IO) { videoFrames(file, listOf(0.35f, 0.6f, 0.85f)) } }
        if (more.isNotEmpty()) {
            val all = listOf(first) + more
            cache.put(key, all)
            apply(view, all, onResult)
        }
    }

    private fun apply(view: ImageView, frames: List<Bitmap>, onResult: (Boolean) -> Unit) {
        (view.drawable as? Animatable)?.stop()
        if (frames.size == 1) {
            view.setImageBitmap(frames[0])
        } else {
            val anim = AnimationDrawable().apply {
                isOneShot = false
                frames.forEach { addFrame(BitmapDrawable(view.resources, it), FRAME_MS) }
            }
            view.setImageDrawable(anim)
            if (view.isAttachedToWindow) anim.start()
        }
        onResult(true)
    }

    /** Les animations ne tournent que pendant que la vue est visible à l'écran. */
    private fun ensureAttachHook(v: ImageView) {
        if (v.getTag(R.id.thumb_hook) != null) return
        v.setTag(R.id.thumb_hook, true)
        v.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(x: View) {
                ((x as ImageView).drawable as? Animatable)?.start()
            }

            override fun onViewDetachedFromWindow(x: View) {
                ((x as ImageView).drawable as? Animatable)?.stop()
            }
        })
    }

    // ------------------------------------------------------------------ décodage

    fun isAnimatedImage(name: String): Boolean {
        val ext = name.substringAfterLast('.', "").lowercase()
        return ext == "gif" || ext == "webp"
    }

    @RequiresApi(28)
    private fun animated(file: File): Drawable? = try {
        val d = ImageDecoder.decodeDrawable(ImageDecoder.createSource(file)) { dec, info, _ ->
            val s = maxOf(info.size.width, info.size.height) / SIZE
            if (s > 1) dec.setTargetSampleSize(s)
        }
        if (d is AnimatedImageDrawable) d.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
        d
    } catch (_: Throwable) {
        null
    }

    private fun firstFrame(ctx: Context, f: File, kind: String?): Bitmap? = try {
        when (kind) {
            Explorer.IMAGES -> decodeImage(f, SIZE)
            Explorer.VIDEOS -> videoFrames(f, listOf(0.1f)).firstOrNull()
            Explorer.AUDIO -> audioArt(f)
            Explorer.APK -> apkIcon(ctx, f)
            else -> null
        }
    } catch (_: Throwable) {
        null
    }

    /** Image décodée en réduisant la résolution (économie de mémoire) et remise à l'endroit (EXIF). */
    fun decodeImage(f: File, target: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= target && bounds.outHeight / (sample * 2) >= target) sample *= 2
        val bmp = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return null
        return rotateByExif(f, bmp)
    }

    private fun rotateByExif(f: File, bmp: Bitmap): Bitmap {
        val orientation = try {
            ExifInterface(f.path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        } catch (_: Throwable) {
            ExifInterface.ORIENTATION_NORMAL
        }
        val deg = when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (deg == 0f) return bmp
        return try {
            Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true)
        } catch (_: Throwable) {
            bmp
        }
    }

    /** Vraies images d'une vidéo, prises à [fractions] de sa durée. */
    private fun videoFrames(f: File, fractions: List<Float>): List<Bitmap> {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(f.path)
            val durMs = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val out = ArrayList<Bitmap>()
            for (fr in fractions) {
                val us = (durMs * 1000L * fr).toLong()
                val b = r.getFrameAtTime(us, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    ?: (if (out.isEmpty()) r.getFrameAtTime(0) else null)
                    ?: continue
                out += scaleDown(b)
            }
            out
        } catch (_: Throwable) {
            emptyList()
        } finally {
            try {
                r.release()
            } catch (_: Throwable) {
            }
        }
    }

    private fun scaleDown(b: Bitmap): Bitmap {
        val m = maxOf(b.width, b.height)
        if (m <= SIZE) return b
        val k = SIZE.toFloat() / m
        return Bitmap.createScaledBitmap(b, (b.width * k).toInt().coerceAtLeast(1), (b.height * k).toInt().coerceAtLeast(1), true)
    }

    private fun audioArt(f: File): Bitmap? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(f.path)
            val bytes = r.embeddedPicture ?: return null
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= SIZE && bounds.outHeight / (sample * 2) >= SIZE) sample *= 2
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
        } catch (_: Throwable) {
            null
        } finally {
            try {
                r.release()
            } catch (_: Throwable) {
            }
        }
    }

    private fun apkIcon(ctx: Context, f: File): Bitmap? {
        if (!f.name.endsWith(".apk", ignoreCase = true)) return null
        val pm = ctx.packageManager
        @Suppress("DEPRECATION")
        val info = pm.getPackageArchiveInfo(f.path, 0) ?: return null
        val ai = info.applicationInfo ?: return null
        ai.sourceDir = f.path
        ai.publicSourceDir = f.path
        val d = ai.loadIcon(pm) ?: return null
        val bmp = Bitmap.createBitmap(192, 192, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        d.setBounds(0, 0, 192, 192)
        d.draw(c)
        return bmp
    }

    /** Image plein écran pour la visionneuse (GIF / WebP animés sur Android 9+). À appeler hors du thread principal. */
    fun loadFull(res: Resources, f: File, maxDim: Int = 3000): Drawable? {
        if (Build.VERSION.SDK_INT >= 28) {
            try {
                val d = ImageDecoder.decodeDrawable(ImageDecoder.createSource(f)) { dec, info, _ ->
                    val s = maxOf(info.size.width, info.size.height) / maxDim
                    if (s > 1) dec.setTargetSampleSize(s)
                }
                if (d is AnimatedImageDrawable) d.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
                return d
            } catch (_: Throwable) {
            }
        }
        return try {
            decodeImage(f, maxDim)?.let { BitmapDrawable(res, it) }
        } catch (_: Throwable) {
            null
        }
    }
}
