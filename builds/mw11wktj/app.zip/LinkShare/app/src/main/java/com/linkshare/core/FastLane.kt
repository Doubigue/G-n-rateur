package com.linkshare.core

import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.EOFException
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.io.RandomAccessFile
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.nio.channels.ServerSocketChannel
import java.nio.channels.SocketChannel
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import kotlin.concurrent.thread
import kotlin.math.max
import kotlin.math.min

/*
 * ════════════════════ Voie rapide ════════════════════
 * Le HTTP (Ktor) sert à parcourir, afficher les miniatures et lire en streaming.
 * Les fichiers, eux, passent par un protocole TCP minimal, bien plus rapide :
 *  - côté envoi, FileChannel.transferTo → sendfile() du noyau : aucune copie dans l'appli ;
 *  - les gros fichiers sont coupés en 4 morceaux envoyés en parallèle sur 4 connexions ;
 *  - plusieurs fichiers partent en même temps (6 connexions au total au maximum).
 *
 * Robustesse (v0.7) :
 *  - chaque connexion sans aucun octet pendant [STALL_MS] est fermée : plus de connexion « fantôme »
 *    qui bloque une place pour toujours (c'était la cause du ralentissement progressif) ;
 *  - un morceau coupé reprend automatiquement là où il s'était arrêté (jusqu'à [TRIES] essais),
 *    au lieu d'annuler tout le fichier ;
 *  - les tampons de 1 Mo sont réutilisés (moins de travail pour le ramasse-miettes) ;
 *  - l'analyse des médias reçus est groupée.
 *
 * Trame : [int32 longueur][en-tête JSON] puis
 *  get  → le serveur répond [int64 taille du fichier][int64 octets qui suivent][données]
 *  put  → le client envoie les données, le serveur répond 1 octet (0 = OK).
 *  have → le serveur répond [int64 état][int64 octets déjà reçus pour ce morceau]
 *         (état 0 = en cours, 1 = fichier déjà complet, -404 = inconnu, -410 = annulé).
 */

/**
 * Tampons de socket : 2 Mo suffisent largement en Wi-Fi local (6 connexions = 12 Mo « en vol »).
 * Au-delà, les files d'attente gonflent, la latence explose et les petites requêtes (parcours, ping) expirent.
 */
private const val SOCK_BUF = 2 * 1024 * 1024
/** Taille d'un appel sendfile : petit pour que la détection de blocage voie la progression. */
private const val CHUNK = 1L * 1024 * 1024
/** À partir de cette taille, un fichier est coupé en morceaux parallèles. */
private const val PARALLEL_MIN = 16L * 1024 * 1024
private const val PARTS = 4
/** Connexion fermée si aucun octet ne passe pendant ce délai. */
private const val STALL_MS = 25_000L
/** Essais par morceau avant d'abandonner (remis à zéro dès que le transfert avance). */
private const val TRIES = 8

private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

@Serializable
internal data class FastReq(
    val t: String,
    val op: String,
    val path: String = "",
    val name: String = "",
    val off: Long = 0,
    val len: Long = -1,
    val total: Long = -1,
    val id: String = "",
    val app: Boolean = false,
    /** Lot (dossier, sélection) : le transfert est affiché comme une seule ligne des deux côtés. */
    val gid: String = "",
    val gname: String = "",
    val gtotal: Long = -1,
    val from: String = "",
    /** Début du morceau auquel appartient cet envoi (reprise) ; -1 = [off]. */
    val p: Long = -1,
)

/** Lot affiché comme une seule ligne (un fichier, un dossier entier ou une appli). */
data class Group(val id: String, val name: String, val total: Long)

/** Erreur définitive : inutile de réessayer (fichier absent, accès refusé, annulé par l'autre). */
private class FatalIO(msg: String) : IOException(msg)

private fun tune(s: Socket) {
    runCatching { s.sendBufferSize = SOCK_BUF }
    runCatching { s.receiveBufferSize = SOCK_BUF }
    runCatching { s.tcpNoDelay = true }
    runCatching { s.keepAlive = true }
    runCatching { s.trafficClass = 0x10 } // IPTOS_LOWDELAY : priorité au Wi-Fi « vidéo/voix » sur certains routeurs
}

private fun SocketChannel.readFully(b: ByteBuffer) {
    while (b.hasRemaining()) if (read(b) < 0) throw EOFException("Connexion fermée")
}

private fun SocketChannel.writeFully(b: ByteBuffer) {
    while (b.hasRemaining()) write(b)
}

private fun longs(a: Long, b: Long): ByteBuffer {
    val buf = ByteBuffer.allocate(16)
    buf.putLong(a); buf.putLong(b); buf.flip()
    return buf
}

private fun SocketChannel.sendHeader(r: FastReq) {
    val bytes = json.encodeToString(r).toByteArray()
    val b = ByteBuffer.allocate(4 + bytes.size).putInt(bytes.size).put(bytes)
    b.flip(); writeFully(b)
}

/** Tâches de fond de la voie rapide : surveillance des connexions, analyse des médias, ménage. */
private val bg = Executors.newSingleThreadScheduledExecutor { r -> Thread(r, "fastlane-bg").apply { isDaemon = true } }

/** Réserve de tampons directs de 1 Mo : avant, chaque fichier en allouait un nouveau (des centaines pour un dossier photo). */
private object Bufs {
    private val q = ConcurrentLinkedQueue<ByteBuffer>()
    fun take(): ByteBuffer = q.poll()?.also { it.clear() } ?: ByteBuffer.allocateDirect(BUF)
    fun give(b: ByteBuffer) { if (q.size < 16) q.offer(b) }
}

/**
 * Surveillance des connexions : une connexion qui ne fait passer aucun octet pendant [STALL_MS]
 * est fermée, ce qui débloque aussitôt le fil d'exécution (et la place qu'il occupe).
 * Sans ça, un téléphone qui sort de portée laissait des connexions bloquées pour toujours.
 */
private object Stall {
    class Watch(val ch: SocketChannel) {
        @Volatile var t = System.nanoTime()
        fun touch() { t = System.nanoTime() }
    }
    private val all: MutableSet<Watch> = ConcurrentHashMap.newKeySet()

    init {
        bg.scheduleWithFixedDelay({
            val now = System.nanoTime()
            for (w in all) {
                if (now - w.t > TimeUnit.MILLISECONDS.toNanos(STALL_MS)) {
                    all.remove(w)
                    runCatching { w.ch.close() }
                }
            }
        }, 2, 2, TimeUnit.SECONDS)
    }

    fun watch(ch: SocketChannel) = Watch(ch).also { all += it }
    fun done(w: Watch) { all.remove(w) }
}

/** Analyse des médias reçus, par paquets : un seul appel au lieu d'un par fichier. */
private object Scan {
    private val pending = ConcurrentLinkedQueue<String>()
    private val scheduled = AtomicBoolean(false)

    fun add(ctx: Context, f: File) {
        pending += f.path
        if (scheduled.compareAndSet(false, true)) {
            bg.schedule({
                scheduled.set(false)
                val paths = generateSequence { pending.poll() }.toList()
                if (paths.isNotEmpty()) runCatching { MediaScannerConnection.scanFile(ctx, paths.toTypedArray(), null, null) }
            }, 1500, TimeUnit.MILLISECONDS)
        }
    }
}

/** Dossier de réception commun : Download/LinkShare. */
fun receiveDir(): File =
    File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "LinkShare").apply { mkdirs() }

/** « photo.jpg » existe déjà → « photo (1).jpg ». */
fun uniqueFile(f: File): File {
    fun free(c: File) = !c.exists() && !File(c.parentFile, c.name + ".lspart").exists()
    if (free(f)) return f
    val base = f.nameWithoutExtension
    val ext = f.extension.let { if (it.isEmpty()) "" else ".$it" }
    var i = 1
    while (true) {
        val c = File(f.parentFile, "$base ($i)$ext")
        if (free(c)) return c
        i++
    }
}

// ═══════════════════════════════ Serveur ═══════════════════════════════

class FastServer(private val ctx: Context, private val port: Int = FAST_PORT) {
    private val root = SharedRoot(Environment.getExternalStorageDirectory())
    private var ss: ServerSocketChannel? = null
    private val pool = Executors.newCachedThreadPool { r -> Thread(r, "fastlane").apply { isDaemon = true } }

    /** Un morceau d'un fichier reçu : [pos] = fin de la partie déjà écrite (sans trou depuis [start]). */
    private class Part(val start: Long, val end: Long) {
        val pos = AtomicLong(start)
        @Volatile var ch: SocketChannel? = null

        /** Avance [pos] jusqu'à [to] ; renvoie les octets nouveaux (0 si déjà écrits par une tentative précédente). */
        fun advance(to: Long): Long {
            while (true) {
                val c = pos.get()
                if (to <= c) return 0
                if (pos.compareAndSet(c, to)) return to - c
            }
        }
    }

    /** Fichier reçu en morceaux : chaque morceau écrit à sa place dans « nom.lspart », renommé à la fin. */
    private class Incoming(val part: File, val final: File, val total: Long) {
        val parts = ConcurrentHashMap<Long, Part>()
        val finished = AtomicBoolean(false)
        @Volatile var touched = System.nanoTime()
        fun have(): Long = parts.values.sumOf { it.pos.get() - it.start }
    }
    private val incoming = ConcurrentHashMap<String, Incoming>()

    fun start() {
        val s = ServerSocketChannel.open()
        s.socket().reuseAddress = true
        runCatching { s.socket().receiveBufferSize = SOCK_BUF }
        s.socket().bind(InetSocketAddress(port), 32)
        ss = s
        thread(name = "fastlane-accept", isDaemon = true) {
            while (s.isOpen) {
                val ch = try { s.accept() } catch (e: Exception) { break }
                pool.execute { handle(ch) }
            }
        }
        // Ménage : fichiers partiels abandonnés depuis 15 min (l'autre n'a jamais repris)
        bg.scheduleWithFixedDelay({
            val limit = System.nanoTime() - TimeUnit.MINUTES.toNanos(15)
            incoming.entries.filter { it.value.touched < limit }.forEach { (k, inc) ->
                incoming.remove(k)
                if (!inc.finished.get()) runCatching { inc.part.delete() }
            }
        }, 1, 1, TimeUnit.MINUTES)
    }

    fun stop() {
        runCatching { ss?.close() }
        ss = null
        pool.shutdownNow()
    }

    private fun handle(ch: SocketChannel) {
        try {
            ch.use {
                tune(ch.socket())
                val lenBuf = ByteBuffer.allocate(4); ch.readFully(lenBuf); lenBuf.flip()
                val n = lenBuf.int
                if (n <= 0 || n > 64 * 1024) return
                val hb = ByteBuffer.allocate(n); ch.readFully(hb)
                val req = runCatching { json.decodeFromString<FastReq>(String(hb.array())) }.getOrNull() ?: return
                val token = ShareState.token
                if (!ShareState.open || token.isEmpty() || !MessageDigest.isEqual(req.t.toByteArray(), token.toByteArray())) {
                    ch.writeFully(longs(-401, 0))
                    return
                }
                when (req.op) {
                    "get" -> serveGet(ch, req)
                    "put" -> servePut(ch, req)
                    "have" -> serveHave(ch, req)
                }
            }
        } catch (_: Exception) {
            // Connexion coupée : le client reprendra ; sinon la fiche passe en échec après un délai (TransferHub)
        }
    }

    private fun appPaths(): Set<String> {
        val pm = ctx.packageManager
        return pm.getInstalledApplications(0).flatMap { ai ->
            listOf(ai.sourceDir) + (ai.splitSourceDirs?.toList() ?: emptyList())
        }.toSet()
    }

    private fun trackKey(req: FastReq) = "srv:" + req.gid.ifEmpty { req.id.ifEmpty { UUID.randomUUID().toString() } }

    private fun tracker(req: FastReq, fallbackName: String, fallbackTotal: Long, dir: Dir): Xfer {
        val name = req.gname.ifEmpty { fallbackName }
        val total = if (req.gtotal > 0) req.gtotal else fallbackTotal
        return TransferHub.track(trackKey(req), name, dir, total, req.from.ifEmpty { Session.peerName }, autoFinish = true)
    }

    private fun serveGet(ch: SocketChannel, req: FastReq) {
        val f: File? = if (req.app) File(req.path).takeIf { it.isFile && req.path in appPaths() }
        else root.resolve(req.path)?.takeIf { it.isFile }
        if (f == null) {
            ch.writeFully(longs(-404, 0))
            return
        }
        val size = f.length()
        val x = tracker(req, f.name, size, Dir.UP)
        if (x.state == XState.CANCELLED) { ch.writeFully(longs(-410, 0)); return }
        x.revive()
        val off = req.off.coerceIn(0, size)
        val len = if (req.len < 0) size - off else min(req.len, size - off)
        ch.writeFully(longs(size, len))
        x.links += ch
        val w = Stall.watch(ch)
        try {
            FileInputStream(f).channel.use { fc ->
                var pos = off
                val end = off + len
                while (pos < end) {
                    val sent = fc.transferTo(pos, min(CHUNK, end - pos), ch)
                    if (sent <= 0) throw IOException("Envoi interrompu")
                    pos += sent; x.add(sent); w.touch()
                }
            }
        } finally {
            Stall.done(w)
            x.links -= ch
        }
    }

    private fun incomingKey(req: FastReq) = req.id.ifEmpty { UUID.randomUUID().toString() } + "|" + req.name

    /** Reprise : combien d'octets de ce morceau sont déjà écrits ici ? */
    private fun serveHave(ch: SocketChannel, req: FastReq) {
        val x = TransferHub.find(trackKey(req))
        if (x?.state == XState.CANCELLED) { ch.writeFully(longs(-410, 0)); return }
        val inc = incoming[incomingKey(req)]
        when {
            inc == null -> ch.writeFully(longs(-404, 0))
            inc.finished.get() -> ch.writeFully(longs(1, 0))
            else -> {
                inc.touched = System.nanoTime()
                val part = inc.parts[req.p]
                // L'ancienne connexion de ce morceau est morte côté client : on la ferme ici aussi
                part?.ch?.let { runCatching { it.close() } }
                ch.writeFully(longs(0, part?.let { it.pos.get() - it.start } ?: 0))
            }
        }
    }

    private fun servePut(ch: SocketChannel, req: FastReq) {
        val uploads = SharedRoot(receiveDir())
        val key = incomingKey(req)
        val inc = synchronized(incoming) {
            incoming.getOrPut(key) {
                val dest = uploads.resolve(req.name)?.takeIf { it != uploads.dir } ?: throw IOException("Nom invalide")
                dest.parentFile?.mkdirs()
                val final = uniqueFile(dest)
                Incoming(File(final.parentFile, final.name + ".lspart"), final, req.total)
            }
        }
        if (inc.finished.get()) { ch.writeFully(ByteBuffer.wrap(byteArrayOf(0))); return }
        inc.touched = System.nanoTime()
        val x = tracker(req, inc.final.name, req.total, Dir.DOWN)
        if (x.state == XState.CANCELLED) return // fermeture → le client s'arrête (« have » lui dira pourquoi)
        x.revive()

        val pStart = if (req.p >= 0) req.p else req.off
        val part = inc.parts.getOrPut(pStart) { Part(pStart, if (req.len < 0) Long.MAX_VALUE else req.off + req.len) }
        part.ch?.takeIf { it !== ch }?.let { runCatching { it.close() } } // ancienne tentative encore ouverte
        part.ch = ch
        x.links += ch
        val w = Stall.watch(ch)
        val buf = Bufs.take()
        try {
            RandomAccessFile(inc.part, "rw").use { raf ->
                if (req.total > 0 && raf.length() < req.total) raf.setLength(req.total)
                val fc = raf.channel
                var pos = req.off
                var remaining = req.len
                while (remaining != 0L) {
                    buf.clear()
                    if (remaining in 1 until buf.capacity()) buf.limit(remaining.toInt())
                    val n = ch.read(buf)
                    if (n < 0) { if (req.len < 0) break else throw EOFException("Envoi interrompu") }
                    buf.flip()
                    while (buf.hasRemaining()) pos += fc.write(buf, pos)
                    if (remaining > 0) remaining -= n
                    x.add(part.advance(pos))
                    w.touch(); inc.touched = System.nanoTime()
                }
            }
        } finally {
            Bufs.give(buf)
            Stall.done(w)
            x.links -= ch
            if (part.ch === ch) part.ch = null
        }

        val complete = if (req.len < 0) true else inc.total >= 0 && inc.have() >= inc.total
        if (complete && inc.finished.compareAndSet(false, true)) {
            if (req.len < 0) RandomAccessFile(inc.part, "rw").use { it.setLength(part.pos.get() - part.start) }
            inc.part.renameTo(inc.final)
            Scan.add(ctx, inc.final)
            if (req.len < 0 && x.total <= 0) x.finish()
        }
        ch.writeFully(ByteBuffer.wrap(byteArrayOf(0)))
    }
}

// ═══════════════════════════════ Client ═══════════════════════════════

/** Source d'un envoi : un fichier (accès à tous les fichiers) ou un document choisi dans le sélecteur Android. */
sealed class Source {
    data class F(val file: File) : Source()
    data class U(val uri: Uri) : Source()
}

object FastClient {
    /** 6 connexions simultanées au maximum, tous transferts confondus. */
    private val streams = Semaphore(6)

    private fun open(c: Connection): SocketChannel {
        val ch = SocketChannel.open()
        tune(ch.socket())
        try {
            ch.socket().connect(InetSocketAddress(c.host, c.fastPort), 6000)
        } catch (e: Exception) {
            runCatching { ch.close() }
            throw IOException("Connexion impossible à ${c.name}")
        }
        return ch
    }

    private fun ranges(size: Long): List<Pair<Long, Long>> {
        if (size < PARALLEL_MIN) return listOf(0L to size)
        val part = size / PARTS
        return (0 until PARTS).map { i ->
            val off = i * part
            off to if (i == PARTS - 1) size - off else part
        }
    }

    /** Exécute un bloc bloquant ; l'annulation de la coroutine ferme le socket et l'interrompt aussitôt. */
    private suspend fun <T> io(block: () -> T): T = streams.withPermit { runInterruptible(Dispatchers.IO) { block() } }

    /**
     * Réessaie [attempt] après une coupure réseau, avec une petite pause (1 s, 2 s, 3 s, puis 4 s).
     * Le compteur d'essais repart à zéro dès que [progress] avance : seule une coupure durable fait échouer.
     */
    private suspend fun retrying(progress: () -> Long, attempt: suspend (n: Int) -> Unit) {
        var fails = 0
        var n = 0
        var last = progress()
        while (true) {
            try {
                attempt(n++)
                return
            } catch (e: CancellationException) {
                throw e
            } catch (e: FatalIO) {
                throw e
            } catch (e: IOException) {
                currentCoroutineContext().ensureActive()
                val p = progress()
                if (p > last) { last = p; fails = 0 }
                if (++fails >= TRIES) throw IOException(e.message ?: "Connexion perdue")
                delay(min(1000L * fails, 4000L))
            }
        }
    }

    private fun <T> connWatch(ch: SocketChannel, block: (Stall.Watch) -> T): T {
        val w = Stall.watch(ch)
        try { return block(w) } finally { Stall.done(w) }
    }

    /**
     * Télécharge [path] (taille [size]) dans [dest]. Les gros fichiers arrivent en 4 morceaux parallèles,
     * écrits directement à leur place dans un fichier temporaire « .lspart ». Un morceau coupé reprend
     * à l'octet près où il s'était arrêté.
     */
    suspend fun get(c: Connection, path: String, size: Long, dest: File, rec: Xfer, g: Group, app: Boolean = false): File {
        dest.parentFile?.mkdirs()
        val final = uniqueFile(dest)
        val part = File(final.parentFile, final.name + ".lspart")
        RandomAccessFile(part, "rw").use { if (size > 0) it.setLength(size) }
        val id = UUID.randomUUID().toString()
        try {
            coroutineScope {
                ranges(size).map { (off, len) ->
                    async {
                        val got = AtomicLong(0) // octets de ce morceau déjà écrits sur le disque
                        retrying(progress = { got.get() }) {
                            if (size > 0 && got.get() >= len) return@retrying
                            io {
                                open(c).use { ch ->
                                    connWatch(ch) { w ->
                                        val from = off + got.get()
                                        ch.sendHeader(
                                            FastReq(
                                                c.token, "get", path = path, off = from,
                                                len = if (size <= 0) -1 else len - got.get(),
                                                total = size, id = id, app = app, gid = g.id, gname = g.name, gtotal = g.total,
                                                from = Session.myName,
                                            )
                                        )
                                        val h = ByteBuffer.allocate(16); ch.readFully(h); h.flip()
                                        val real = h.long; var left = h.long
                                        if (real < 0) throw FatalIO(
                                            when (real) {
                                                -404L -> "Fichier introuvable"
                                                -410L -> "Annulé par ${c.name}"
                                                else -> "Accès refusé"
                                            }
                                        )
                                        if (size > 0 && real != size) throw FatalIO("Fichier modifié pendant l'envoi")
                                        val buf = Bufs.take()
                                        try {
                                            RandomAccessFile(part, "rw").use { raf ->
                                                val fc = raf.channel
                                                var pos = from
                                                while (left > 0) {
                                                    buf.clear()
                                                    if (left < buf.capacity()) buf.limit(left.toInt())
                                                    val n = ch.read(buf)
                                                    if (n < 0) throw EOFException("Connexion perdue")
                                                    buf.flip()
                                                    while (buf.hasRemaining()) pos += fc.write(buf, pos)
                                                    left -= n; got.addAndGet(n.toLong()); rec.add(n.toLong()); w.touch()
                                                }
                                            }
                                        } finally { Bufs.give(buf) }
                                    }
                                }
                            }
                        }
                    }
                }.awaitAll()
            }
        } catch (e: Throwable) {
            part.delete()
            throw e
        }
        if (!part.renameTo(final)) throw IOException("Enregistrement impossible : ${final.name}")
        return final
    }

    private class Opened(val channel: FileChannel?, val closer: () -> Unit, val stream: java.io.InputStream?)

    private fun openSource(ctx: Context, s: Source): Opened = when (s) {
        is Source.F -> FileInputStream(s.file).let { fis -> Opened(fis.channel, { fis.close() }, null) }
        is Source.U -> {
            val pfd: ParcelFileDescriptor? = runCatching { ctx.contentResolver.openFileDescriptor(s.uri, "r") }.getOrNull()
            if (pfd != null) {
                val fis = FileInputStream(pfd.fileDescriptor)
                Opened(fis.channel, { runCatching { fis.close() }; runCatching { pfd.close() } }, null)
            } else {
                val ins = ctx.contentResolver.openInputStream(s.uri) ?: throw IOException("Lecture impossible")
                Opened(null, { ins.close() }, ins)
            }
        }
    }

    fun sizeOf(ctx: Context, s: Source): Long = when (s) {
        is Source.F -> s.file.length()
        is Source.U -> runCatching {
            ctx.contentResolver.query(s.uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use {
                if (it.moveToFirst() && !it.isNull(0)) it.getLong(0) else -1L
            } ?: -1L
        }.getOrDefault(-1L)
    }

    /** Valeur de [have] : le fichier est déjà complet chez l'autre. */
    private const val COMPLETE = Long.MAX_VALUE

    /** Demande à l'autre téléphone combien d'octets du morceau [p] il a déjà écrits. */
    private fun have(c: Connection, id: String, name: String, p: Long, g: Group): Long =
        open(c).use { ch ->
            connWatch(ch) {
                ch.sendHeader(FastReq(c.token, "have", name = name, id = id, p = p, gid = g.id, from = Session.myName))
                val h = ByteBuffer.allocate(16); ch.readFully(h); h.flip()
                val status = h.long; val n = h.long
                when (status) {
                    0L -> n
                    1L -> COMPLETE
                    -404L -> 0L
                    -410L -> throw FatalIO("Annulé par ${c.name}")
                    else -> throw FatalIO("Accès refusé")
                }
            }
        }

    /** Envoie [src] vers Download/LinkShare/[name] de l'autre téléphone ([name] peut contenir des sous-dossiers). */
    suspend fun put(ctx: Context, c: Connection, src: Source, name: String, size: Long, rec: Xfer, g: Group) {
        val id = UUID.randomUUID().toString()
        val parts = if (size > 0) ranges(size) else listOf(0L to -1L)
        coroutineScope {
            parts.map { (off, len) ->
                async {
                    val confirmed = AtomicLong(0) // octets de ce morceau confirmés par l'autre téléphone
                    val counted = AtomicLong(0)   // octets de ce morceau déjà comptés dans le pourcentage
                    retrying(progress = { confirmed.get() }) { attempt ->
                        var from = 0L
                        if (attempt > 0) {
                            // Envoi de taille inconnue (flux non « seekable ») : impossible de reprendre au milieu
                            if (len < 0) throw FatalIO("Connexion perdue")
                            val h = io { have(c, id, name, off, g) }
                            if (h == COMPLETE) return@retrying
                            from = h.coerceIn(0, len)
                            confirmed.set(from)
                            rec.rollback(counted.get() - from)
                            counted.set(from)
                            if (from >= len) return@retrying
                        }
                        io {
                            val o = openSource(ctx, src)
                            try {
                                open(c).use { ch ->
                                    connWatch(ch) { w ->
                                        ch.sendHeader(
                                            FastReq(
                                                c.token, "put", name = name, off = off + from,
                                                len = if (len < 0) -1 else len - from, total = size, id = id,
                                                gid = g.id, gname = g.name, gtotal = g.total, from = Session.myName, p = off,
                                            )
                                        )
                                        val fc = o.channel
                                        if (fc != null && len >= 0) {
                                            var pos = off + from
                                            val end = off + len
                                            while (pos < end) {
                                                val sent = fc.transferTo(pos, min(CHUNK, end - pos), ch)
                                                if (sent <= 0) throw IOException("Lecture interrompue")
                                                pos += sent; rec.add(sent); counted.addAndGet(sent); w.touch()
                                            }
                                        } else {
                                            // Taille inconnue ou document non « seekable » : lecture en flux
                                            val ins = o.stream ?: java.nio.channels.Channels.newInputStream(fc ?: throw IOException("Lecture impossible"))
                                            // Flux relu depuis le début : on saute jusqu'au début de ce morceau (ou du point de reprise)
                                            var skip = if (len >= 0) off + from else 0L
                                            while (skip > 0) {
                                                val k = ins.skip(skip)
                                                if (k > 0) skip -= k
                                                else if (ins.read() >= 0) skip-- else throw IOException("Lecture interrompue")
                                            }
                                            val arr = ByteArray(BUF)
                                            var left = if (len >= 0) len else Long.MAX_VALUE
                                            while (left > 0) {
                                                val n = ins.read(arr, 0, min(arr.size.toLong(), left).toInt())
                                                if (n < 0) break
                                                ch.writeFully(ByteBuffer.wrap(arr, 0, n)); rec.add(n.toLong()); counted.addAndGet(n.toLong()); w.touch()
                                                left -= n
                                            }
                                            if (len < 0) ch.shutdownOutput()
                                        }
                                        val ack = ByteBuffer.allocate(1); ch.readFully(ack)
                                        if (ack.get(0).toInt() != 0) throw FatalIO("Refusé par ${c.name}")
                                        confirmed.set(max(confirmed.get(), if (len < 0) counted.get() else len))
                                    }
                                }
                            } finally { o.closer() }
                        }
                    }
                }
            }.awaitAll()
        }
    }
}
