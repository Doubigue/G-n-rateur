import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:audioplayers/audioplayers.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:timezone/data/latest_all.dart' as tzd;
import 'package:timezone/timezone.dart' as tz;
import 'data.dart';

const builtinSounds = {'ferme_cloche': 'Cloche de la ferme', 'ferme_coq': 'Chant du coq', 'ferme_sirene': 'Sirène', 'ferme_douce': 'Mélodie douce'};

class Notif {
  static final pl = FlutterLocalNotificationsPlugin();
  static final inbox = ValueNotifier<List<Map<String, dynamic>>>([]);
  static final player = AudioPlayer();
  static final _fired = <String>{};
  static String get sound => Repo.p.getString('sound') ?? 'ferme_cloche';
  static String? get customPath => Repo.p.getString('sound_custom');

  static Future<void> init() async {
    tzd.initializeTimeZones();
    tz.setLocalLocation(tz.getLocation(await FlutterTimezone.getLocalTimezone()));
    await pl.initialize(const InitializationSettings(android: AndroidInitializationSettings('@mipmap/ic_launcher')));
    final a = pl.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await a?.requestNotificationsPermission();
    await a?.requestExactAlarmsPermission();
    inbox.value = (jsonDecode(Repo.p.getString('inbox') ?? '[]') as List).cast<Map<String, dynamic>>();
    Timer.periodic(const Duration(seconds: 20), (_) => _tick());
  }

  // Quand l'appli est ouverte : range dans la boîte de notifications les rappels qui sonnent
  static void _tick() {
    final n = DateTime.now();
    final td = DateFormat('yyyy-MM-dd').format(n);
    for (final r in all()) {
      if (r['h'] != n.hour || r['m'] != n.minute) continue;
      if (r['date'] != null && r['date'] != td) continue;
      final key = '${r['id']}-$td-${n.hour}:${n.minute}';
      if (_fired.add(key)) log('${r['label']}', '${r['msg']}');
    }
  }

  static void log(String t, String b) {
    inbox.value = [{'t': t, 'b': b, 'ts': DateTime.now().toIso8601String(), 'r': false}, ...inbox.value].take(100).toList();
    Repo.p.setString('inbox', jsonEncode(inbox.value));
  }

  static void markAllRead() {
    inbox.value = [for (final e in inbox.value) {...e, 'r': true}];
    Repo.p.setString('inbox', jsonEncode(inbox.value));
  }

  static AndroidNotificationDetails _det(String msg) {
    final s = sound;
    AndroidNotificationSound? snd;
    var id = 'alarme_$s';
    if (s == 'custom' && customPath != null) {
      snd = UriAndroidNotificationSound(Uri.file(customPath!).toString());
      id = 'alarme_custom_${customPath.hashCode}';
    } else if (s.startsWith('ferme_')) {
      snd = RawResourceAndroidNotificationSound(s);
    }
    return AndroidNotificationDetails(id, 'Alarmes de la ferme',
        importance: Importance.max, priority: Priority.max, category: AndroidNotificationCategory.alarm,
        fullScreenIntent: true, playSound: true, sound: snd, audioAttributesUsage: AudioAttributesUsage.alarm,
        additionalFlags: Int32List.fromList([4]), styleInformation: BigTextStyleInformation(msg));
  }

  // Notification immédiate (ex : mortalité enregistrée)
  static Future<void> now(String title, String msg) async {
    log(title, msg);
    await pl.show(DateTime.now().millisecondsSinceEpoch ~/ 1000 % 100000 + 100000, '🚜 $title', msg, NotificationDetails(android: _det(msg)));
  }

  static List<Map<String, dynamic>> all() => (jsonDecode(Repo.p.getString('rem') ?? '[]') as List).cast<Map<String, dynamic>>();

  static Future<void> schedule(Map<String, dynamic> r) async {
    final now = tz.TZDateTime.now(tz.local);
    tz.TZDateTime t;
    if (r['date'] != null) {
      final d = DateTime.parse(r['date']);
      t = tz.TZDateTime(tz.local, d.year, d.month, d.day, r['h'], r['m']);
      if (t.isBefore(now)) return;
    } else {
      t = tz.TZDateTime(tz.local, now.year, now.month, now.day, r['h'], r['m']);
      if (t.isBefore(now)) t = t.add(const Duration(days: 1));
    }
    await pl.zonedSchedule(r['id'], '🚜 ${r['label']}', r['msg'], t, NotificationDetails(android: _det(r['msg'])),
        androidScheduleMode: AndroidScheduleMode.alarmClock,
        matchDateTimeComponents: r['date'] == null ? DateTimeComponents.time : null);
  }

  static Future<void> add(String label, String msg, TimeOfDay t, {DateTime? date}) async {
    final l = all();
    final r = {'id': DateTime.now().millisecondsSinceEpoch ~/ 1000, 'label': label, 'msg': msg, 'h': t.hour, 'm': t.minute,
      if (date != null) 'date': DateFormat('yyyy-MM-dd').format(date)};
    l.add(r);
    await Repo.p.setString('rem', jsonEncode(l));
    await schedule(r);
  }

  static Future<void> remove(int id) async {
    await pl.cancel(id);
    await Repo.p.setString('rem', jsonEncode(all()..removeWhere((e) => e['id'] == id)));
  }

  static Future<void> setSound(String s) async {
    await Repo.p.setString('sound', s);
    for (final r in all()) { await pl.cancel(r['id']); await schedule(r); } // les canaux gardent leur son : on reprogramme
  }

  static Future<void> preview(String s) async {
    await player.stop();
    if (s == 'custom' && customPath != null) { await player.play(DeviceFileSource(customPath!)); }
    else if (s.startsWith('ferme_')) { await player.play(AssetSource('sounds/$s.wav')); }
  }

  static Future<bool> pickCustom() async {
    final res = await FilePicker.platform.pickFiles(type: FileType.audio);
    final src = res?.files.single.path;
    if (src == null) return false;
    final dir = await getApplicationDocumentsDirectory();
    final ext = src.contains('.') ? src.split('.').last : 'mp3';
    final dst = '${dir.path}/sonnerie_${DateTime.now().millisecondsSinceEpoch}.$ext';
    await File(src).copy(dst);
    await Repo.p.setString('sound_custom', dst);
    await setSound('custom');
    return true;
  }
}

class NotifPage extends StatefulWidget {
  const NotifPage({super.key});
  @override
  State<NotifPage> createState() => _NotifPageState();
}

class _NotifPageState extends State<NotifPage> {
  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: const Text('Notifications'), actions: [IconButton(icon: const Icon(Icons.done_all), tooltip: 'Tout marquer lu', onPressed: Notif.markAllRead)]),
        body: ListView(padding: const EdgeInsets.all(12), children: [SoundCard(onChanged: () => setState(() {})),
          ValueListenableBuilder(valueListenable: Notif.inbox, builder: (_, l, __) => Column(children: [
            if (l.isEmpty) const Padding(padding: EdgeInsets.all(30), child: Text('Aucune notification pour le moment')),
            for (final e in l) ListTile(
              leading: Icon(e['r'] == true ? Icons.notifications_none : Icons.notifications_active, color: e['r'] == true ? null : Colors.orange),
              title: Text('${e['t']}', style: TextStyle(fontWeight: e['r'] == true ? FontWeight.normal : FontWeight.bold)),
              subtitle: Text('${e['b']}\n${DateFormat('dd/MM HH:mm').format(DateTime.parse(e['ts']))}'), isThreeLine: true),
          ])),
        ]),
      );
}

class SoundCard extends StatelessWidget {
  final VoidCallback onChanged;
  const SoundCard({super.key, required this.onChanged});
  @override
  Widget build(BuildContext c) {
    final cur = Notif.sound;
    Widget tile(String k, String label) => RadioListTile<String>(
          value: k, groupValue: cur, title: Text(label),
          secondary: k == 'systeme' ? null : IconButton(icon: const Icon(Icons.play_circle_outline), onPressed: () => Notif.preview(k)),
          onChanged: (v) async { await Notif.setSound(v!); onChanged(); });
    return Card(child: Column(children: [
      const ListTile(leading: Icon(Icons.music_note), title: Text('Sonnerie des alarmes', style: TextStyle(fontWeight: FontWeight.bold))),
      for (final e in builtinSounds.entries) tile(e.key, e.value),
      tile('systeme', 'Son par défaut du téléphone'),
      if (Notif.customPath != null) tile('custom', 'Ma sonnerie (${Notif.customPath!.split('/').last})'),
      Padding(padding: const EdgeInsets.all(8), child: OutlinedButton.icon(icon: const Icon(Icons.library_music), label: const Text('Ajouter ma propre sonnerie'),
          onPressed: () async { if (await Notif.pickCustom()) onChanged(); })),
    ]));
  }
}

class ReminderTab extends StatefulWidget {
  const ReminderTab({super.key});
  @override
  State<ReminderTab> createState() => _ReminderTabState();
}

class _ReminderTabState extends State<ReminderTab> {
  Animal a = animals.first; String type = 'Ramassage des œufs'; TimeOfDay t = const TimeOfDay(hour: 7, minute: 0);
  bool daily = true; DateTime date = DateTime.now();
  final types = ['Ramassage des œufs', 'Piqûre / vaccin', 'Alimentation', 'Traitement', 'Autre'];
  @override
  Widget build(BuildContext c) => ListView(padding: const EdgeInsets.all(16), children: [
        SoundCard(onChanged: () => setState(() {})),
        const SizedBox(height: 12),
        DropdownButtonFormField<Animal>(value: a, decoration: const InputDecoration(labelText: 'Animal', border: OutlineInputBorder()), items: [for (final x in animals) DropdownMenuItem(value: x, child: Text(x.name))], onChanged: (v) => setState(() => a = v!)),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(value: type, decoration: const InputDecoration(labelText: 'Type', border: OutlineInputBorder()), items: [for (final x in types) DropdownMenuItem(value: x, child: Text(x))], onChanged: (v) => setState(() => type = v!)),
        SwitchListTile(title: const Text('Répéter chaque jour'), value: daily, onChanged: (v) => setState(() => daily = v)),
        if (!daily) ListTile(leading: const Icon(Icons.event), title: Text(DateFormat('dd/MM/yyyy').format(date)), onTap: () async {
          final d = await showDatePicker(context: c, initialDate: date, firstDate: DateTime(2020), lastDate: DateTime(2100));
          if (d != null) setState(() => date = d);
        }),
        ListTile(leading: const Icon(Icons.alarm), title: Text('Heure : ${t.format(c)}'), onTap: () async { final v = await showTimePicker(context: c, initialTime: t); if (v != null) setState(() => t = v); }),
        FilledButton.icon(icon: const Icon(Icons.alarm_add), label: const Text('Programmer l\'alarme'), onPressed: () async {
          await Notif.add('$type - ${a.name}', 'C\'est l\'heure : $type (${a.name})', t, date: daily ? null : date);
          setState(() {}); if (c.mounted) ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content: Text('Alarme programmée')));
        }),
        const Divider(height: 32),
        for (final r in Notif.all()) ListTile(leading: const Icon(Icons.alarm_on), title: Text(r['label']),
            subtitle: Text('${r['date'] ?? 'Chaque jour'} à ${r['h'].toString().padLeft(2, '0')}:${r['m'].toString().padLeft(2, '0')}'),
            trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () async { await Notif.remove(r['id']); setState(() {}); })),
      ]);
}
