# Ma Ferme (Flutter) — package com.doubigue.ferme
Build via APK Studio (mode Flutter) : envoyez ce ZIP. Le dossier android/ est ignoré par le générateur,
la config Firebase Android est donc dans lib/main.dart (fbAndroid).
Remplacez .github/scripts/android_setup.py de votre dépôt APK Studio par la version fournie (alarmes),
cochez la permission « Notifications » dans APK Studio, paquet : com.doubigue.ferme.
Firebase Console : Authentication > Email/Mot de passe ; Firestore > Règles : contenu de firestore.rules.

## Mise à jour : lots, œufs, sons
- Images : assets/logos/ (déposez aussi nourriture.png et piqure.png ; sinon icônes par défaut).
- Sonneries intégrées : assets/sounds/ferme_*.wav. Pour qu'elles sonnent dans les notifications Android, copiez-les dans
  android/app/src/main/res/raw/ (à ajouter dans votre android_setup.py :
  `shutil.copytree('assets/sounds', 'android/app/src/main/res/raw', dirs_exist_ok=True)`).
- Nouveaux paquets : audioplayers, file_picker, path_provider.
