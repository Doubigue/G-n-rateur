package com.omnicode.editor

import android.content.ContentResolver
import android.net.Uri
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException

/** Mode « dépôt entier » : un onglet par type de fichier, puis les fichiers de ce type. */
data class ProjectUi(
    val name: String,
    val types: List<String>,
    val filesByType: Map<String, List<String>>,
    val selectedPath: String?,
    val modified: Set<String>,
    val skipped: Int
)

data class EditorUiState(
    val code: TextFieldValue = TextFieldValue(""),
    val language: String = "html",
    val showPreview: Boolean = false,
    val project: ProjectUi? = null,
    val busy: Boolean = false,
    val error: String? = null
)

@OptIn(FlowPreview::class)
class EditorViewModel : ViewModel() {

    private val _state = MutableStateFlow(EditorUiState())
    val state: StateFlow<EditorUiState> = _state.asStateFlow()

    var isLoaded = false
        private set

    @Volatile private var entries: List<ProjectEntry> = emptyList()
    @Volatile private var byPath: Map<String, ProjectEntry> = emptyMap()
    private val edits = HashMap<String, String>()

    var projectUri: Uri? = null
        private set

    /** HTML de l'aperçu, recalculé 300 ms après la dernière frappe. */
    val previewHtml: StateFlow<String> = _state
        .map { it.code.text to it.language }
        .distinctUntilChanged()
        .debounce(300)
        .map { (code, lang) -> PreviewBuilder.build(code, lang) }
        .flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.Eagerly, "")

    /** Un seul fichier (ACTION_EDIT_CODE). */
    fun load(code: String, language: String) {
        isLoaded = true
        projectUri = null
        entries = emptyList()
        byPath = emptyMap()
        edits.clear()
        _state.value = EditorUiState(TextFieldValue(code), language.lowercase())
    }

    /** Dépôt entier (ACTION_EDIT_PROJECT) : décompresse le ZIP et prépare les onglets. */
    fun loadProject(resolver: ContentResolver, uri: Uri, name: String) {
        if (projectUri == uri) return            // rotation / même demande : on garde le travail en cours
        projectUri = uri
        isLoaded = true
        edits.clear()
        _state.update { it.copy(busy = true, error = null, project = null) }
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val list = resolver.openInputStream(uri)?.use { ProjectZip.read(it) }
                    ?: throw IOException("Archive illisible.")
                val editable = list.filter { it.editable }
                if (editable.isEmpty()) throw IOException("Aucun fichier texte modifiable dans ce projet.")
                val groups = editable.groupBy { typeOf(it.path) }
                val types = groups.keys.sortedWith(
                    compareByDescending<String> { groups[it]?.size ?: 0 }.thenBy { it }
                )
                val filesByType = groups.mapValues { (_, v) -> v.map { it.path }.sorted() }
                val firstPath = editable.firstOrNull { it.path == "index.html" }?.path
                    ?: filesByType.getValue(types.first()).first()
                entries = list
                byPath = list.associateBy { it.path }
                _state.update {
                    it.copy(
                        busy = false,
                        code = TextFieldValue(byPath.getValue(firstPath).text.orEmpty()),
                        language = languageOf(firstPath),
                        project = ProjectUi(name, types, filesByType, firstPath, emptySet(), list.size - editable.size)
                    )
                }
            } catch (ex: Exception) {
                _state.update { it.copy(busy = false, error = ex.message ?: "Lecture du projet impossible.") }
            }
        }
    }

    fun selectFile(path: String) {
        val e = byPath[path] ?: return
        val text = edits[path] ?: e.text ?: return
        _state.update { s ->
            val p = s.project ?: return@update s
            s.copy(code = TextFieldValue(text), language = languageOf(path), project = p.copy(selectedPath = path))
        }
    }

    fun selectType(type: String) {
        _state.value.project?.filesByType?.get(type)?.firstOrNull()?.let { selectFile(it) }
    }

    fun onCodeChange(value: TextFieldValue) {
        _state.update { s ->
            val p = s.project
            val path = p?.selectedPath
            if (p != null && path != null) {
                edits[path] = value.text
                val changed = value.text != byPath[path]?.text
                val mod = if (changed) p.modified + path else p.modified - path
                s.copy(code = value, project = p.copy(modified = mod))
            } else {
                s.copy(code = value)
            }
        }
    }

    /** Réécrit le ZIP complet à l'URI reçue (même fichier que celui lu au départ). */
    fun saveProject(resolver: ContentResolver, onDone: (Throwable?) -> Unit) {
        val uri = projectUri
        if (uri == null) { onDone(IOException("Aucun projet ouvert.")); return }
        if (_state.value.busy) return
        _state.update { it.copy(busy = true) }
        val snapshot = HashMap(edits)
        viewModelScope.launch {
            val err = withContext(Dispatchers.IO) {
                try {
                    resolver.openOutputStream(uri, "wt")?.use { ProjectZip.write(entries, snapshot, it) }
                        ?: throw IOException("Écriture impossible.")
                    null
                } catch (ex: Exception) {
                    ex
                }
            }
            _state.update { it.copy(busy = false) }
            onDone(err)
        }
    }

    fun setPreview(show: Boolean) = _state.update { it.copy(showPreview = show) }

    /** Insère un symbole à la position du curseur (remplace la sélection). */
    fun insert(symbol: String) {
        val v = _state.value.code
        val start = v.selection.min
        val newText = v.text.replaceRange(start, v.selection.max, symbol)
        onCodeChange(TextFieldValue(newText, TextRange(start + symbol.length)))
    }
}
