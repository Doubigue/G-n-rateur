package com.omnicode.contract

/** Contrat partagé : à copier à l'identique dans l'app éditeur ET l'app partenaire. */
object OmniCodeContract {
    const val EDITOR_PACKAGE = "com.omnicode.editor"

    const val ACTION_EDIT_CODE = "com.omnicode.editor.ACTION_EDIT_CODE"

    /** Dépôt entier : le ZIP est transmis par URI (intent.data, droits lecture + écriture) et réécrit sur place. */
    const val ACTION_EDIT_PROJECT = "com.omnicode.editor.ACTION_EDIT_PROJECT"
    const val EXTRA_PROJECT_NAME = "com.omnicode.editor.extra.PROJECT_NAME"

    // Inbound
    const val EXTRA_CODE_CONTENT = "com.omnicode.editor.extra.CODE_CONTENT"
    const val EXTRA_FILE_LANGUAGE = "com.omnicode.editor.extra.FILE_LANGUAGE"
    const val EXTRA_API_KEY = "com.omnicode.editor.extra.API_KEY"

    // Outbound
    const val EXTRA_UPDATED_CODE = "com.omnicode.editor.extra.UPDATED_CODE"

    const val VALID_API_KEY = "OMNICODE_SECURE_KEY_2026"
}
