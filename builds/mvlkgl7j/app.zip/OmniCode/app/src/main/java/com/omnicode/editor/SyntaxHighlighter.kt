package com.omnicode.editor

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString

object SyntaxHighlighter {
    private val KEYWORD = Color(0xFF569CD6)
    private val STRING = Color(0xFFCE9178)
    private val NUMBER = Color(0xFFB5CEA8)
    private val COMMENT = Color(0xFF6A9955)
    private val TAG = Color(0xFF4EC9B0)
    private val ATTR = Color(0xFF9CDCFE)

    private fun words(vararg w: String) = """\b(${w.joinToString("|")})\b""".toRegex()

    private val STR = """\x22[^\x22\n]*\x22|'[^'\n]*'""".toRegex()
    private val NUM = """\b\d+(\.\d+)?\b""".toRegex()

    private val html = listOf(
        """</?[a-zA-Z][\w-]*|/?>""".toRegex() to TAG,
        """[\w-]+(?==)""".toRegex() to ATTR,
        STR to STRING,
        """<!--[\s\S]*?-->""".toRegex() to COMMENT
    )
    private val css = listOf(
        """[\w-]+(?=\s*:)""".toRegex() to ATTR,
        """#[0-9a-fA-F]{3,8}\b|\b\d+(\.\d+)?(px|em|rem|%|vh|vw|s|ms)?""".toRegex() to NUMBER,
        """@[\w-]+""".toRegex() to KEYWORD,
        STR to STRING,
        """/\*[\s\S]*?\*/""".toRegex() to COMMENT
    )
    private val js = listOf(
        NUM to NUMBER,
        words("const", "let", "var", "function", "return", "if", "else", "for", "while", "new",
            "class", "import", "export", "from", "async", "await", "try", "catch", "throw",
            "true", "false", "null", "undefined", "this", "switch", "case", "break") to KEYWORD,
        """\x22[^\x22\n]*\x22|'[^'\n]*'|`[^`]*`""".toRegex() to STRING,
        """//.*|/\*[\s\S]*?\*/""".toRegex() to COMMENT
    )
    private val python = listOf(
        NUM to NUMBER,
        words("def", "class", "return", "if", "elif", "else", "for", "while", "import", "from",
            "as", "try", "except", "finally", "with", "lambda", "pass", "break", "continue",
            "True", "False", "None", "and", "or", "not", "in", "is", "print") to KEYWORD,
        """\x22{3}[\s\S]*?\x22{3}|\x22[^\x22\n]*\x22|'[^'\n]*'""".toRegex() to STRING,
        """#.*""".toRegex() to COMMENT
    )
    private val clike = listOf(
        NUM to NUMBER,
        words("class", "interface", "object", "fun", "val", "var", "public", "private", "protected",
            "static", "final", "void", "int", "long", "double", "float", "boolean", "char", "byte",
            "short", "String", "return", "if", "else", "for", "while", "do", "new", "import", "package",
            "extends", "implements", "override", "when", "try", "catch", "finally", "throw", "throws",
            "null", "true", "false", "this", "super", "switch", "case", "break", "continue", "enum",
            "abstract", "const", "lateinit", "companion", "data", "sealed", "in", "is", "as", "struct",
            "func", "let", "mut", "impl", "use", "def") to KEYWORD,
        STR to STRING,
        """//.*|/\*[\s\S]*?\*/""".toRegex() to COMMENT
    )
    private val markdown = listOf(
        """(?m)^\s*([-*+]|\d+\.)\s""".toRegex() to KEYWORD,
        """\*\*[^*\n]+\*\*|\*[^*\n]+\*""".toRegex() to NUMBER,
        """\[[^\]\n]*]\([^)\n]*\)""".toRegex() to ATTR,
        """`[^`\n]+`""".toRegex() to STRING,
        """(?m)^#{1,6} .*""".toRegex() to TAG
    )

    private fun rules(lang: String) = when (lang.lowercase()) {
        "html", "htm", "svg", "xml" -> html
        "css" -> css
        "javascript", "js", "json", "jsx", "ts", "tsx" -> js
        "java", "kt", "kotlin", "c", "h", "cpp", "cs", "go", "rs", "dart", "gradle", "swift" -> clike
        "python", "py" -> python
        "markdown", "md" -> markdown
        else -> emptyList()
    }

    /** Les règles sont appliquées dans l'ordre : les dernières (chaînes, commentaires) l'emportent. */
    fun highlight(text: String, lang: String): AnnotatedString = buildAnnotatedString {
        append(text)
        if (text.length > 80_000) return@buildAnnotatedString // garde-fou performances
        for ((regex, color) in rules(lang)) {
            regex.findAll(text).forEach {
                addStyle(SpanStyle(color = color), it.range.first, it.range.last + 1)
            }
        }
    }
}
