package com.omnicode.editor

import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.CodingErrorAction
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

const val OTHER_TYPE = "autres"

/** Extension en minuscules, ou [OTHER_TYPE] (Dockerfile, .gitignore…). Sert d'onglet. */
fun typeOf(path: String): String {
    val name = path.substringAfterLast('/')
    val dot = name.lastIndexOf('.')
    return if (dot <= 0 || dot == name.length - 1) OTHER_TYPE else name.substring(dot + 1).lowercase()
}

/** Langage attendu par SyntaxHighlighter / PreviewBuilder. */
fun languageOf(path: String): String = when (val t = typeOf(path)) {
    "htm", "xhtml" -> "html"
    "mjs", "cjs" -> "javascript"
    "kts" -> "kt"
    "yml" -> "yaml"
    OTHER_TYPE -> "text"
    else -> t
}

/** Un fichier du projet. [text] vaut null s'il n'est pas éditable (binaire, non UTF-8, trop gros). */
class ProjectEntry(val path: String, val bytes: ByteArray) {
    var text: String? = null
        private set
    var eol: String = "\n"
        private set
    var bom: Boolean = false
        private set

    init {
        if (bytes.size <= ProjectZip.MAX_EDITABLE && !hasNul()) {
            try {
                val decoder = Charsets.UTF_8.newDecoder()
                    .onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT)
                var s = decoder.decode(ByteBuffer.wrap(bytes)).toString()
                if (s.startsWith("\uFEFF")) { s = s.substring(1); bom = true }
                if (s.contains("\r\n")) { eol = "\r\n"; s = s.replace("\r\n", "\n") }
                text = s
            } catch (e: CharacterCodingException) {
                // pas de l'UTF-8 : le fichier est conservé tel quel
            }
        }
    }

    val editable: Boolean get() = text != null

    private fun hasNul(): Boolean {
        val n = minOf(bytes.size, 8000)
        for (i in 0 until n) if (bytes[i] == 0.toByte()) return true
        return false
    }

    /** Ré-encode un texte édité avec les mêmes fins de ligne / BOM que l'original. */
    fun encode(edited: String): ByteArray {
        val s = if (eol == "\r\n") edited.replace("\n", "\r\n") else edited
        val body = s.toByteArray(Charsets.UTF_8)
        return if (bom) byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()) + body else body
    }
}

object ProjectZip {
    const val MAX_TOTAL = 80L * 1024 * 1024
    const val MAX_EDITABLE = 1_500_000

    fun read(input: InputStream): List<ProjectEntry> {
        val map = LinkedHashMap<String, ProjectEntry>()
        var total = 0L
        val buf = ByteArray(32 * 1024)
        ZipInputStream(input.buffered()).use { zin ->
            while (true) {
                val e = zin.nextEntry ?: break
                if (e.isDirectory) continue
                val name = e.name.replace('\\', '/').trimStart('/')
                val parts = name.split('/')
                // protection « zip-slip » + fichiers parasites
                if (name.isEmpty() || parts.any { it == ".." || it.isEmpty() } || name.startsWith("__MACOSX/")) continue
                val bos = ByteArrayOutputStream()
                while (true) {
                    val n = zin.read(buf)
                    if (n < 0) break
                    total += n
                    if (total > MAX_TOTAL) throw IOException("Projet trop volumineux (plus de 80 Mo).")
                    bos.write(buf, 0, n)
                }
                map[name] = ProjectEntry(name, bos.toByteArray())
            }
        }
        return map.values.toList()
    }

    /**
     * Réécrit tout le projet. Un fichier non modifié garde exactement ses octets d'origine
     * (APK Studio ne voit donc que les vraies modifications).
     */
    fun write(entries: List<ProjectEntry>, edits: Map<String, String>, out: OutputStream) {
        ZipOutputStream(out.buffered()).use { z ->
            for (e in entries) {
                val edited = edits[e.path]
                val data = if (edited != null && edited != e.text) e.encode(edited) else e.bytes
                z.putNextEntry(ZipEntry(e.path))
                z.write(data)
                z.closeEntry()
            }
        }
    }
}
