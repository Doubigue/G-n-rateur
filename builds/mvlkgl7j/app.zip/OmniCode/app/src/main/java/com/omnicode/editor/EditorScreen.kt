package com.omnicode.editor

import android.annotation.SuppressLint
import android.webkit.WebView
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

private val EditorBg = Color(0xFF1E1E1E)
private val GutterBg = Color(0xFF252526)
private val Fg = Color(0xFFD4D4D4)
private val GutterFg = Color(0xFF858585)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(
    vm: EditorViewModel,
    onValidate: (String) -> Unit,
    onValidateProject: () -> Unit,
    onCancel: () -> Unit
) {
    val state by vm.state.collectAsState()
    val html by vm.previewHtml.collectAsState()
    val project = state.project
    val error = state.error
    var askLeave by remember { mutableStateOf(false) }

    val leave: () -> Unit = {
        if (project != null && project.modified.isNotEmpty()) {
            askLeave = true
        } else {
            onCancel()
        }
    }
    BackHandler(onBack = leave)

    if (askLeave) {
        AlertDialog(
            onDismissRequest = { askLeave = false },
            title = { Text("Abandonner les modifications ?") },
            text = { Text("${project?.modified?.size ?: 0} fichier(s) modifié(s) ne seront pas renvoyés.") },
            confirmButton = { TextButton(onClick = { askLeave = false; onCancel() }) { Text("Abandonner") } },
            dismissButton = { TextButton(onClick = { askLeave = false }) { Text("Continuer") } }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    if (project != null) {
                        Column {
                            Text(project.name, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                            project.selectedPath?.let {
                                Text(it, style = MaterialTheme.typography.labelSmall, maxLines = 1)
                            }
                        }
                    } else {
                        Text(state.language.uppercase(), style = MaterialTheme.typography.titleMedium)
                    }
                },
                navigationIcon = { TextButton(onClick = leave) { Text("Annuler") } },
                actions = {
                    Button(
                        enabled = !state.busy,
                        onClick = { if (project != null) onValidateProject() else onValidate(state.code.text) }
                    ) { Text(if (project != null) "Valider & Renvoyer" else "Valider & Enregistrer") }
                    Spacer(Modifier.width(8.dp))
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().imePadding()) {
            if (state.busy && project == null) {
                // Décompression du ZIP en cours
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                return@Column
            }
            if (project == null && error != null) {
                Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                    Text(error, color = MaterialTheme.colorScheme.error)
                }
                return@Column
            }
            if (state.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            if (project != null) ProjectNav(project, onType = vm::selectType, onFile = vm::selectFile)

            TabRow(selectedTabIndex = if (state.showPreview) 1 else 0) {
                Tab(selected = !state.showPreview, onClick = { vm.setPreview(false) }, text = { Text("Éditeur") })
                Tab(selected = state.showPreview, onClick = { vm.setPreview(true) }, text = { Text("Preview") })
            }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (state.showPreview) {
                    PreviewWebView(html, Modifier.fillMaxSize())
                } else {
                    CodeEditor(state.code, state.language, vm::onCodeChange, Modifier.fillMaxSize())
                }
            }
            if (!state.showPreview) SymbolBar(onSymbol = vm::insert)
        }
    }
}

/** Onglets = types de fichier (.html, .py, .java…), puis les fichiers du type choisi. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProjectNav(p: ProjectUi, onType: (String) -> Unit, onFile: (String) -> Unit) {
    val selType = p.selectedPath?.let { typeOf(it) }
    val index = p.types.indexOf(selType).coerceAtLeast(0)
    ScrollableTabRow(selectedTabIndex = index, edgePadding = 8.dp) {
        p.types.forEach { t ->
            val files = p.filesByType[t].orEmpty()
            val dirty = files.any { it in p.modified }
            val label = (if (t == OTHER_TYPE) t else ".$t") + " (${files.size})" + if (dirty) " •" else ""
            Tab(selected = t == selType, onClick = { onType(t) }, text = { Text(label, maxLines = 1) })
        }
    }
    LazyRow(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        contentPadding = PaddingValues(horizontal = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(p.filesByType[selType].orEmpty()) { path ->
            FilterChip(
                selected = path == p.selectedPath,
                onClick = { onFile(path) },
                label = { Text(path + if (path in p.modified) " •" else "", maxLines = 1) }
            )
        }
    }
    if (p.skipped > 0) {
        Text(
            "${p.skipped} fichier(s) non modifiable(s) (binaires…) seront renvoyés tels quels.",
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
        )
    }
}

@Composable
fun CodeEditor(
    value: TextFieldValue,
    language: String,
    onChange: (TextFieldValue) -> Unit,
    modifier: Modifier = Modifier
) {
    val transformation = remember(language) {
        VisualTransformation { text ->
            TransformedText(SyntaxHighlighter.highlight(text.text, language), OffsetMapping.Identity)
        }
    }
    val mono = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 14.sp, lineHeight = 20.sp, color = Fg)
    val lineCount = remember(value.text) { value.text.count { it == '\n' } + 1 }

    BoxWithConstraints(modifier.background(EditorBg)) {
        val minH = maxHeight
        Row(Modifier.verticalScroll(rememberScrollState())) {
            Text(
                text = (1..lineCount).joinToString("\n"),
                style = mono.copy(color = GutterFg, textAlign = TextAlign.End),
                modifier = Modifier
                    .background(GutterBg)
                    .heightIn(min = minH)
                    .widthIn(min = 40.dp)
                    .padding(horizontal = 8.dp, vertical = 8.dp)
            )
            Box(Modifier.weight(1f).horizontalScroll(rememberScrollState())) {
                BasicTextField(
                    value = value,
                    onValueChange = onChange,
                    textStyle = mono,
                    cursorBrush = SolidColor(Color.White),
                    visualTransformation = transformation,
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.None,
                        autoCorrectEnabled = false,
                        keyboardType = KeyboardType.Text
                    ),
                    modifier = Modifier
                        .widthIn(min = 300.dp)
                        .heightIn(min = minH)
                        .padding(8.dp)
                )
            }
        }
    }
}

private val SYMBOLS = listOf(
    "Tab" to "  ", "{" to "{", "}" to "}", "<" to "<", ">" to ">", "/" to "/",
    "=" to "=", "[" to "[", "]" to "]", "\"" to "\"", "'" to "'"
)

@Composable
fun SymbolBar(onSymbol: (String) -> Unit) {
    Surface(tonalElevation = 4.dp) {
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            SYMBOLS.forEach { (label, insert) ->
                TextButton(
                    onClick = { onSymbol(insert) },
                    contentPadding = PaddingValues(horizontal = 14.dp)
                ) { Text(label, fontFamily = FontFamily.Monospace) }
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun PreviewWebView(html: String, modifier: Modifier = Modifier) {
    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            WebView(ctx).apply {
                settings.javaScriptEnabled = true
                settings.allowFileAccess = false      // pas d'accès au système de fichiers
                settings.allowContentAccess = false
                setBackgroundColor(android.graphics.Color.WHITE)
            }
        },
        update = { web ->
            if (web.tag != html) {                     // évite les rechargements inutiles
                web.tag = html
                web.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
            }
        },
        onRelease = { it.destroy() }
    )
}
