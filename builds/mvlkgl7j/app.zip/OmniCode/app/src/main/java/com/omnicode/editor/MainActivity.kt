package com.omnicode.editor

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import com.omnicode.contract.OmniCodeContract
import java.security.MessageDigest

class MainActivity : ComponentActivity() {

    private val vm: EditorViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        // Après rotation (savedInstanceState != null), le ViewModel garde déjà le code.
        if (savedInstanceState == null && !handleIntent(intent)) return

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                EditorScreen(
                    vm = vm,
                    onValidate = ::validateAndFinish,
                    onValidateProject = ::validateProject,
                    onCancel = ::cancelAndFinish
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun authorized(intent: Intent): Boolean {
        val key = intent.getStringExtra(OmniCodeContract.EXTRA_API_KEY)
        return key != null && MessageDigest.isEqual(
            key.toByteArray(), OmniCodeContract.VALID_API_KEY.toByteArray()
        )
    }

    private fun refuse(message: String): Boolean {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        setResult(RESULT_CANCELED)
        finish()
        return false
    }

    /** @return false si la demande est refusée (l'activité est alors fermée). */
    private fun handleIntent(intent: Intent?): Boolean {
        if (intent == null) {
            if (!vm.isLoaded) vm.load(SAMPLE_HTML, "html")
            return true
        }
        return when (intent.action) {
            OmniCodeContract.ACTION_EDIT_CODE -> {
                if (!authorized(intent)) return refuse("Accès refusé : clé API absente ou invalide.")
                vm.load(
                    code = intent.getStringExtra(OmniCodeContract.EXTRA_CODE_CONTENT).orEmpty(),
                    language = intent.getStringExtra(OmniCodeContract.EXTRA_FILE_LANGUAGE) ?: "html"
                )
                true
            }
            OmniCodeContract.ACTION_EDIT_PROJECT -> {
                if (!authorized(intent)) return refuse("Accès refusé : clé API absente ou invalide.")
                val uri = intent.data ?: return refuse("Projet absent : aucun ZIP reçu.")
                vm.loadProject(
                    applicationContext.contentResolver,
                    uri,
                    intent.getStringExtra(OmniCodeContract.EXTRA_PROJECT_NAME) ?: "Projet"
                )
                true
            }
            else -> {
                // Lancement autonome : exemple par défaut, sans écraser un travail en cours
                if (!vm.isLoaded) vm.load(SAMPLE_HTML, "html")
                true
            }
        }
    }

    private fun validateAndFinish(code: String) {
        val result = Intent().putExtra(OmniCodeContract.EXTRA_UPDATED_CODE, code)
        setResult(RESULT_OK, result)
        finish()
    }

    /** Dépôt entier : réécrit le ZIP complet dans le fichier partagé, puis rend la main. */
    private fun validateProject() {
        vm.saveProject(applicationContext.contentResolver) { err ->
            if (err == null) {
                setResult(RESULT_OK)
                finish()
            } else {
                Toast.makeText(this, "Échec de l'enregistrement : ${err.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun cancelAndFinish() {
        setResult(RESULT_CANCELED)
        finish()
    }

    private companion object {
        const val SAMPLE_HTML = """<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: sans-serif; text-align: center; }
    h1 { color: #6200ee; }
  </style>
</head>
<body>
  <h1>Hello OmniCode</h1>
  <button onclick="alert('Salut !')">Clique-moi</button>
</body>
</html>"""
    }
}
