package com.linguavibe.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linguavibe.app.data.Languages
import com.linguavibe.app.speech.NeuralVoice
import com.linguavibe.app.speech.NeuralVoices
import com.linguavibe.app.speech.VoiceSettings
import kotlinx.coroutines.launch

/** Phrases d'essai pour chaque langue. */
private val samples = listOf(
    "es" to "Hola, bienvenido a tu clase de español.",
    "en" to "Hello, welcome to your English lesson.",
    "pt" to "Olá, bem-vindo à sua aula de português.",
    "ru" to "Здравствуйте, добро пожаловать на урок.",
    "zh" to "你好，欢迎来上中文课。",
    "ar" to "مرحبا، أهلا بك في درس اللغة العربية."
)

/** Choix du moteur de voix, voix hors ligne (Kokoro, Piper) et essai des voix. */
@Composable
fun VoiceEngineSection() {
    val speaker = LocalSpeaker.current
    val settings = speaker.settings

    CardBox {
        Text("Voix utilisée pour lire les leçons", style = PosterTitle, fontSize = 17.sp, color = Ink)
        listOf(
            VoiceSettings.ENGINE_AUTO to "Automatique : ElevenLabs si configuré, sinon Kokoro, puis Piper, puis la voix du téléphone",
            VoiceSettings.ENGINE_KOKORO to "Kokoro en priorité (hors ligne)",
            VoiceSettings.ENGINE_PIPER to "Piper en priorité (hors ligne)",
            VoiceSettings.ENGINE_ELEVEN to "ElevenLabs en priorité (en ligne)",
            VoiceSettings.ENGINE_ANDROID to "Toujours la voix du téléphone"
        ).forEach { (id, label) ->
            val selected = settings.engine == id
            ChoiceRow(label, selected, Ruby) { settings.updateEngine(id) }
        }
        Text(
            "Si une voix manque pour une langue (Kokoro ne parle ni russe ni arabe, par exemple), " +
                "l'application passe automatiquement à la suivante.",
            fontSize = 12.sp, color = InkSoft
        )
    }

    CardBox {
        Text("Essayer les voix", style = PosterTitle, fontSize = 17.sp, color = Ink)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            samples.forEach { (code, sentence) ->
                val lang = Languages.byCode(code)
                Box(
                    Modifier.weight(1f).clickable { speaker.speak(sentence, lang.locale) },
                    contentAlignment = Alignment.Center
                ) { LangBadge(code, 42.dp) }
            }
        }
        if (NeuralVoices.loading) StatusLine("Chargement de la voix en mémoire…")
        if (speaker.lastEngine.isNotBlank()) {
            Text("Dernière phrase lue par : ${speaker.lastEngine}", fontSize = 13.sp, color = InkSoft)
        }
        speaker.lastError?.let { StatusLine(it, -1) }
    }
}

@Composable
fun OfflineVoicesSection() {
    val context = LocalContext.current
    val speaker = LocalSpeaker.current
    val settings = speaker.settings
    // Relit l'état des fichiers après chaque installation ou suppression.
    val version = NeuralVoices.version

    CardBox {
        Text("Voix hors ligne : Kokoro et Piper", style = PosterTitle, fontSize = 17.sp, color = Ink)
        Text(
            "Des voix neuronales naturelles qui fonctionnent sans connexion et sans clé. " +
                "Elles ne sont pas incluses dans l'application : téléchargez-les une seule fois ici " +
                "(en Wi-Fi de préférence), elles restent ensuite sur le téléphone.\n" +
                "• Kokoro : une installation pour 5 langues, la voix la plus naturelle.\n" +
                "• Piper : une petite voix par langue, plus légère ; la seule option hors ligne pour le russe et l'arabe.",
            fontSize = 14.sp, color = InkSoft
        )
    }

    CardBox {
        Text("Kokoro", style = PosterTitle, fontSize = 19.sp, color = Ruby)
        VoiceRow(NeuralVoices.kokoro, version)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (settings.kokoroMale) "Voix masculine" else "Voix féminine",
                color = Ink, modifier = Modifier.weight(1f)
            )
            Switch(checked = settings.kokoroMale, onCheckedChange = { settings.updateKokoroMale(it) })
        }
    }

    CardBox {
        Text("Piper", style = PosterTitle, fontSize = 19.sp, color = Ruby)
        Text("Une seule voix par langue suffit. La première installée de la liste est utilisée.", fontSize = 12.sp, color = InkSoft)
        NeuralVoices.piper.forEach { voice -> VoiceRow(voice, version) }
    }

    var cacheVersion by remember { mutableIntStateOf(0) }
    val cacheMb = remember(cacheVersion, version) { NeuralVoices.cacheSizeMb(context) }
    CardBox {
        Text("Phrases déjà calculées par les voix hors ligne : $cacheMb Mo", color = Ink, fontSize = 14.sp)
        TextButton(onClick = {
            speaker.stop()
            NeuralVoices.clearCache(context)
            cacheVersion++
        }) { LineIcon(Art.icTrash, Bad, 18.dp); Spacer(Modifier.width(6.dp)); Text("Vider", color = Bad) }
    }
}

@Composable
private fun VoiceRow(voice: NeuralVoice, version: Int) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val installed = remember(version, voice.id) { NeuralVoices.isInstalled(context, voice) }
    val size = remember(version, voice.id) { if (installed) NeuralVoices.sizeMb(context, voice) else 0 }
    val state = NeuralVoices.installing[voice.id]
    var confirmDelete by remember(voice.id) { mutableStateOf(false) }
    val flags = voice.langs.joinToString(" · ") { it.uppercase() }

    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(if (installed) Good.copy(alpha = 0.10f) else Paper)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(voice.label, fontWeight = FontWeight.SemiBold, color = Ink)
                Text(flags, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, color = Ruby)
                Text(
                    if (installed) "Installée · $size Mo" else "Taille : ${voice.size}",
                    fontSize = 12.sp, color = if (installed) Good else InkSoft
                )
            }
            when {
                state != null && state.error == null ->
                    TextButton(onClick = { NeuralVoices.cancel(voice) }) { Text("Annuler", color = Bad) }
                installed && confirmDelete -> Row {
                    TextButton(onClick = { confirmDelete = false }) { Text("Non") }
                    TextButton(onClick = {
                        confirmDelete = false
                        scope.launch { NeuralVoices.delete(context, voice) }
                    }) { Text("Supprimer", color = Bad) }
                }
                installed -> TextButton(onClick = { confirmDelete = true }) { LineIcon(Art.icTrash, Bad, 20.dp) }
                else -> PillButton("Installer", Art.icDownload, Ruby) { NeuralVoices.install(context, voice) }
            }
        }
        if (!installed && state == null) Text(voice.note, fontSize = 12.sp, color = InkSoft)
        if (state != null && state.error == null) {
            if (state.progress >= 0f) {
                LinearProgressIndicator(progress = { state.progress }, modifier = Modifier.fillMaxWidth(), color = Ruby)
            } else {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = Ruby)
            }
            Text(state.step, fontSize = 12.sp, color = InkSoft)
        }
        state?.error?.let { error ->
            StatusLine(error, -1)
            Row {
                TextButton(onClick = { NeuralVoices.install(context, voice) }) { Text("Réessayer") }
                TextButton(onClick = { NeuralVoices.clearError(voice) }) { Text("Fermer") }
            }
        }
    }
}
