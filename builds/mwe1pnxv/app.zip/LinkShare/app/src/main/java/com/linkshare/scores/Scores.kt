package com.linkshare.scores

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.OffsetDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/** Un championnat / une compétition suivie. [path] = chemin de l'API (sport/compétition). */
class League(val path: String, val label: String)

/** L'ordre de cette liste = l'ordre d'affichage des compétitions (puces et matchs). */
val LEAGUES = listOf(
    League("soccer/fifa.friendly", "Matchs amicaux"),
    League("soccer/uefa.nations", "Ligue des nations"),
    League("soccer/uefa.euroq", "Qualif. Euro"),
    League("soccer/caf.nations", "CAN"),
    League("soccer/caf.nations_qual", "Qualif. CAN"),
    League("soccer/fifa.world", "Coupe du monde"),
    League("soccer/fifa.worldq.caf", "Qualif. Mondial (Afrique)"),
    League("soccer/fifa.worldq.uefa", "Qualif. Mondial (Europe)"),
    League("soccer/fifa.worldq.conmebol", "Qualif. Mondial (Amérique du Sud)"),
    League("soccer/fifa.worldq.concacaf", "Qualif. Mondial (CONCACAF)"),
    League("soccer/fifa.worldq.afc", "Qualif. Mondial (Asie)"),
    League("soccer/esp.copa_del_rey", "Coupe du Roi"),
    League("soccer/fra.coupe_de_france", "Coupe de France"),
    League("soccer/eng.fa", "FA Cup"),
    League("soccer/uefa.champions", "Ligue des champions"),
    League("soccer/uefa.europa", "Ligue Europa"),
    League("soccer/fra.1", "Ligue 1"),
    League("soccer/fra.2", "Ligue 2"),
    League("soccer/eng.1", "Premier League"),
    League("soccer/esp.1", "LaLiga"),
    League("soccer/ita.1", "Serie A"),
    League("soccer/ger.1", "Bundesliga"),
    League("basketball/nba", "NBA"),
)

/** Rang d'une compétition dans [LEAGUES] (plus petit = affiché d'abord). */
fun leagueRank(path: String): Int = LEAGUES.indexOfFirst { it.path == path }.let { if (it < 0) Int.MAX_VALUE else it }

/**
 * Ordre d'affichage : en cours d'abord, puis les terminés (le plus récent d'abord), puis les matchs à venir
 * (le plus proche d'abord) ; à égalité, l'ordre des compétitions de [LEAGUES].
 */
val MATCH_ORDER: Comparator<Match> = Comparator { a, b ->
    val sa = when (a.state) { MatchState.LIVE -> 0; MatchState.POST -> 1; MatchState.PRE -> 2 }
    val sb = when (b.state) { MatchState.LIVE -> 0; MatchState.POST -> 1; MatchState.PRE -> 2 }
    if (sa != sb) return@Comparator sa.compareTo(sb)
    val r = leagueRank(a.leaguePath).compareTo(leagueRank(b.leaguePath))
    if (r != 0) return@Comparator r
    if (a.state == MatchState.POST) b.start.compareTo(a.start) else a.start.compareTo(b.start)
}

enum class MatchState { PRE, LIVE, POST }

/** Une ligne de statistiques : valeur de l'équipe à domicile et de l'équipe à l'extérieur. */
class StatRow(val label: String, val home: String, val away: String)

/** Temps fort : [kind] = goal, yellow, red, sub ; [home] = null si l'équipe est inconnue. */
class MatchEvent(val minute: String, val kind: String, val text: String, val home: Boolean?)

class MatchDetail(val stats: List<StatRow>, val events: List<MatchEvent>, val venue: String?, val attendance: Int?)

/** Un match : [homeScore] / [awayScore] sont null tant qu'il n'a pas commencé. */
data class Match(
    val id: String,
    val leaguePath: String,
    val league: String,
    val home: String,
    val away: String,
    val homeScore: Int?,
    val awayScore: Int?,
    val state: MatchState,
    val status: String,
    val start: Long,
) {
    val live get() = state == MatchState.LIVE
    val scoreText get() = if (state == MatchState.PRE || homeScore == null || awayScore == null) "–" else "$homeScore - $awayScore"
    val line get() = if (state == MatchState.PRE) "$home – $away · $status" else "$home $scoreText $away"

    fun toJson() = JSONObject().put("id", id).put("lp", leaguePath).put("l", league).put("h", home).put("a", away)
        .put("hs", homeScore ?: JSONObject.NULL).put("as", awayScore ?: JSONObject.NULL)
        .put("st", state.name).put("tx", status).put("t", start)

    companion object {
        fun fromJson(o: JSONObject) = Match(
            o.getString("id"), o.optString("lp"), o.optString("l"), o.optString("h"), o.optString("a"),
            if (o.isNull("hs")) null else o.optInt("hs"), if (o.isNull("as")) null else o.optInt("as"),
            runCatching { MatchState.valueOf(o.optString("st")) }.getOrDefault(MatchState.PRE),
            o.optString("tx"), o.optLong("t"),
        )
    }
}

object ScoresPrefs {
    private fun p(ctx: Context) = ctx.getSharedPreferences("linkshare", Context.MODE_PRIVATE)
    fun leagues(ctx: Context): Set<String> =
        p(ctx).getStringSet("scores_leagues", null)?.toSet() ?: setOf("soccer/fra.1", "soccer/uefa.champions")
    fun setLeagues(ctx: Context, s: Set<String>) { p(ctx).edit().putStringSet("scores_leagues", s.toSet()).apply() }
    fun notif(ctx: Context) = p(ctx).getBoolean("scores_notif", false)
    fun setNotif(ctx: Context, on: Boolean) { p(ctx).edit().putBoolean("scores_notif", on).apply() }
    internal fun cache(ctx: Context) = p(ctx).getString("scores_cache", null)
    internal fun setCache(ctx: Context, json: String, at: Long) { p(ctx).edit().putString("scores_cache", json).putLong("scores_cache_at", at).apply() }
    fun cacheAt(ctx: Context) = p(ctx).getLong("scores_cache_at", 0L)
}

/**
 * Scores en direct (source : API publique ESPN, sans clé). Les derniers résultats sont gardés en cache pour que
 * l'écran, la notification et le widget aient toujours quelque chose à afficher, même hors ligne.
 */
object ScoresRepo {
    private const val BASE = "https://site.api.espn.com/apis/site/v2/sports/"

    /** Derniers scores connus (sans réseau). */
    fun cached(ctx: Context): List<Match> = runCatching {
        val arr = JSONArray(ScoresPrefs.cache(ctx) ?: return emptyList())
        (0 until arr.length()).map { Match.fromJson(arr.getJSONObject(it)) }
    }.getOrDefault(emptyList())

    /** Télécharge les matchs d'hier, d'aujourd'hui et de demain (bloquant : à appeler hors du thread principal). */
    fun fetch(ctx: Context): List<Match> {
        val sorted = fetchFor(LEAGUES.filter { it.path in ScoresPrefs.leagues(ctx) })
        val arr = JSONArray(); sorted.forEach { arr.put(it.toJson()) }
        ScoresPrefs.setCache(ctx, arr.toString(), System.currentTimeMillis())
        return sorted
    }

    /** Tous les championnats (pour la recherche) ; ne touche pas au cache. */
    fun fetchAll(): List<Match> = fetchFor(LEAGUES)

    private fun fetchFor(wanted: List<League>): List<Match> {
        val fmt = DateTimeFormatter.BASIC_ISO_DATE
        val today = LocalDate.now()
        val range = today.minusDays(1).format(fmt) + "-" + today.plusDays(1).format(fmt)
        val out = ArrayList<Match>()
        var reached = false
        for (l in wanted) {
            val body = runCatching { httpGet("$BASE${l.path}/scoreboard?dates=$range&limit=100") }.getOrNull() ?: continue
            reached = true
            out += runCatching { parse(body, l) }.getOrDefault(emptyList())
        }
        if (wanted.isNotEmpty() && !reached) throw IOException("Réseau indisponible")
        return out.distinctBy { it.leaguePath + it.id }.sortedWith(MATCH_ORDER)
    }

    /** Statistiques et temps forts d'un match (bloquant). */
    fun fetchDetail(m: Match): MatchDetail {
        val root = JSONObject(httpGet("$BASE${m.leaguePath}/summary?event=${m.id}"))
        // Qui est « domicile » : d'après l'en-tête du match (id d'équipe → domicile ?)
        val isHome = HashMap<String, Boolean>()
        root.optJSONObject("header")?.optJSONArray("competitions")?.optJSONObject(0)?.optJSONArray("competitors")?.let { arr ->
            for (i in 0 until arr.length()) {
                val c = arr.optJSONObject(i) ?: continue
                val id = c.optString("id").ifBlank { c.optJSONObject("team")?.optString("id").orEmpty() }
                if (id.isNotBlank()) isHome[id] = c.optString("homeAway") == "home"
            }
        }
        var homeStats: JSONArray? = null; var awayStats: JSONArray? = null
        root.optJSONObject("boxscore")?.optJSONArray("teams")?.let { teams ->
            for (i in 0 until teams.length()) {
                val t = teams.optJSONObject(i) ?: continue
                val id = t.optJSONObject("team")?.optString("id").orEmpty()
                val home = isHome[id] ?: (t.optString("homeAway") == "home")
                if (home) homeStats = t.optJSONArray("statistics") else awayStats = t.optJSONArray("statistics")
            }
        }
        val rows = ArrayList<StatRow>()
        val hs = homeStats; val aw = awayStats
        if (hs != null && aw != null) {
            val awayByName = HashMap<String, JSONObject>()
            for (i in 0 until aw.length()) aw.optJSONObject(i)?.let { awayByName[it.optString("name")] = it }
            for (i in 0 until hs.length()) {
                val h = hs.optJSONObject(i) ?: continue
                val a = awayByName[h.optString("name")] ?: continue
                val hv = h.optString("displayValue"); val av = a.optString("displayValue")
                if (hv.isBlank() && av.isBlank()) continue
                rows += StatRow(statLabel(h.optString("name"), h.optString("label")), hv, av)
                if (rows.size >= 30) break
            }
        }
        val events = ArrayList<MatchEvent>()
        root.optJSONArray("keyEvents")?.let { arr ->
            for (i in 0 until arr.length()) {
                val e = arr.optJSONObject(i) ?: continue
                val type = e.optJSONObject("type")?.optString("type").orEmpty().lowercase()
                val kind = when {
                    type.contains("goal") || type.contains("penalty---scored") -> "goal"
                    type.contains("yellow") -> "yellow"
                    type.contains("red") -> "red"
                    type.contains("substitution") -> "sub"
                    else -> continue
                }
                val text = e.optString("shortText").ifBlank { e.optString("text") }.ifBlank { e.optJSONObject("type")?.optString("text").orEmpty() }
                val tid = e.optJSONObject("team")?.optString("id").orEmpty()
                events += MatchEvent(e.optJSONObject("clock")?.optString("displayValue").orEmpty(), kind, text, isHome[tid])
            }
        }
        val venue = root.optJSONObject("gameInfo")?.optJSONObject("venue")?.optString("fullName").orEmpty()
        val att = root.optJSONObject("gameInfo")?.optInt("attendance", 0) ?: 0
        return MatchDetail(rows, events, venue.ifBlank { null }, if (att > 0) att else null)
    }

    private fun statLabel(name: String, label: String): String = when (name) {
        "possessionPct" -> "Possession (%)"
        "totalShots" -> "Tirs"
        "shotsOnTarget" -> "Tirs cadrés"
        "blockedShots" -> "Tirs bloqués"
        "wonCorners" -> "Corners"
        "foulsCommitted" -> "Fautes"
        "yellowCards" -> "Cartons jaunes"
        "redCards" -> "Cartons rouges"
        "offsides" -> "Hors-jeu"
        "saves" -> "Arrêts"
        "accuratePasses" -> "Passes réussies"
        "totalPasses" -> "Passes"
        "passPct" -> "Précision des passes (%)"
        "accurateCrosses" -> "Centres réussis"
        "totalCrosses" -> "Centres"
        "totalLongBalls" -> "Longs ballons"
        "accurateLongBalls" -> "Longs ballons réussis"
        "effectiveTackles" -> "Tacles réussis"
        "totalTackles" -> "Tacles"
        "interceptions" -> "Interceptions"
        "effectiveClearance", "totalClearance" -> "Dégagements"
        "rebounds" -> "Rebonds"
        "assists" -> "Passes décisives"
        "steals" -> "Interceptions"
        "blocks" -> "Contres"
        "turnovers" -> "Balles perdues"
        "fieldGoalPct" -> "Réussite aux tirs (%)"
        "threePointFieldGoalPct" -> "Réussite à 3 pts (%)"
        "freeThrowPct" -> "Lancers francs (%)"
        else -> label.ifBlank { name }
    }

    private fun httpGet(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 8000; c.readTimeout = 10000
            c.setRequestProperty("User-Agent", "LinkShare")
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally { c.disconnect() }
    }

    private fun parse(json: String, l: League): List<Match> {
        val events = JSONObject(json).optJSONArray("events") ?: return emptyList()
        val zone = ZoneId.systemDefault()
        val out = ArrayList<Match>()
        for (i in 0 until events.length()) {
            val e = events.optJSONObject(i) ?: continue
            val comp = e.optJSONArray("competitions")?.optJSONObject(0) ?: continue
            val teams = comp.optJSONArray("competitors") ?: continue
            var home: JSONObject? = null; var away: JSONObject? = null
            for (k in 0 until teams.length()) {
                val t = teams.optJSONObject(k) ?: continue
                if (t.optString("homeAway") == "home") home = t else if (t.optString("homeAway") == "away") away = t
            }
            if (home == null || away == null) continue
            val st = e.optJSONObject("status") ?: comp.optJSONObject("status")
            val type = st?.optJSONObject("type")
            val stateRaw = type?.optString("state").orEmpty()
            val name = type?.optString("name").orEmpty()
            val start = runCatching { OffsetDateTime.parse(e.optString("date")).toInstant().toEpochMilli() }.getOrDefault(0L)
            val state = when (stateRaw) { "in" -> MatchState.LIVE; "post" -> MatchState.POST; else -> MatchState.PRE }
            val status = when {
                name.contains("POSTPONED") -> "Reporté"
                name.contains("CANCEL") -> "Annulé"
                name.contains("SUSPENDED") || name.contains("DELAYED") -> "Interrompu"
                state == MatchState.LIVE -> when {
                    name.contains("HALFTIME") -> "Mi-temps"
                    else -> type?.optString("shortDetail").orEmpty().ifBlank { st?.optString("displayClock").orEmpty() }.ifBlank { "En cours" }
                }
                state == MatchState.POST -> "Terminé"
                else -> java.time.Instant.ofEpochMilli(start).atZone(zone).toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm"))
            }
            fun nm(t: JSONObject): String {
                val team = t.optJSONObject("team")
                return team?.optString("shortDisplayName").orEmpty().ifBlank { team?.optString("displayName").orEmpty() }.ifBlank { "?" }
            }
            out += Match(
                id = e.optString("id"), leaguePath = l.path, league = l.label,
                home = nm(home), away = nm(away),
                homeScore = home.optString("score").toIntOrNull(), awayScore = away.optString("score").toIntOrNull(),
                state = state, status = status, start = start,
            )
        }
        return out
    }
}
