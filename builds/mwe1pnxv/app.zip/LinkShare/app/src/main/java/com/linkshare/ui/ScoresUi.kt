package com.linkshare.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.linkshare.scores.LEAGUES
import com.linkshare.scores.Match
import com.linkshare.scores.MatchDetail
import com.linkshare.scores.MatchEvent
import com.linkshare.scores.MatchState
import com.linkshare.scores.MATCH_ORDER
import com.linkshare.scores.ScoresPrefs
import com.linkshare.scores.ScoresRepo
import com.linkshare.scores.ScoresService
import com.linkshare.scores.ScoresWidget
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/** Demande d'ouverture de l'écran Scores (toucher la notification ou le widget). */
internal object ScoresOpen { var request by mutableStateOf(false) }

internal val ScoresIcon: ImageVector by lazy {
    ImageVector.Builder("scores", 24.dp, 24.dp, 24f, 24f)
        .addPath(
            PathParser().parsePathString(
                "M19,5h-2V3H7v2H5c-1.1,0 -2,0.9 -2,2v1c0,2.55 1.92,4.63 4.39,4.94 0.63,1.5 1.98,2.63 3.61,2.95V19H7v2h10v-2h-4v-3.11c1.63,-0.32 2.98,-1.45 3.61,-2.95C19.08,12.63 21,10.55 21,8V7c0,-1.1 -0.9,-2 -2,-2zM5,8V7h2v3.82C5.84,10.4 5,9.3 5,8zM19,8c0,1.3 -0.84,2.4 -2,2.82V7h2v1z"
            ).toNodes(),
            fill = SolidColor(Color.Black),
        ).build()
}

private class ScoreSection(val title: String, val matches: List<Match>)

private fun sections(all: List<Match>): List<ScoreSection> {
    val out = ArrayList<ScoreSection>()
    val live = all.filter { it.live }.sortedWith(MATCH_ORDER)
    val done = all.filter { it.state == MatchState.POST }.sortedWith(MATCH_ORDER)
    val next = all.filter { it.state == MatchState.PRE }.sortedWith(MATCH_ORDER)
    if (live.isNotEmpty()) out += ScoreSection("En direct", live)
    if (done.isNotEmpty()) out += ScoreSection("Terminés", done)
    if (next.isNotEmpty()) out += ScoreSection("À venir", next)
    return out
}

private fun norm(s: String) = java.text.Normalizer.normalize(s, java.text.Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "").lowercase()

/** Scores des matchs : en direct, du jour, d'hier et de demain, avec recherche, statistiques, notification et widget. */
@Composable
internal fun ScoresScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var leagues by remember { mutableStateOf(ScoresPrefs.leagues(ctx)) }
    var notif by remember { mutableStateOf(ScoresPrefs.notif(ctx)) }
    var matches by remember { mutableStateOf(ScoresRepo.cached(ctx)) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var tick by remember { mutableIntStateOf(0) }
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var pool by remember { mutableStateOf<List<Match>?>(null) } // tous les championnats, chargés à la 1re recherche
    var selected by remember { mutableStateOf<Match?>(null) }

    fun setNotif(on: Boolean) {
        notif = on
        ScoresPrefs.setNotif(ctx, on)
        if (on) ScoresService.start(ctx) else ScoresService.stop(ctx)
    }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) setNotif(true) else Toast.makeText(ctx, "Autorise les notifications pour recevoir les scores", Toast.LENGTH_LONG).show()
    }
    fun toggleNotif(on: Boolean) {
        if (!on) { setNotif(false); return }
        val needs = Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        if (needs) perm.launch(Manifest.permission.POST_NOTIFICATIONS) else setNotif(true)
    }

    // Chargement, puis actualisation régulière tant que l'écran est ouvert (30 s en direct, 2 min sinon)
    LaunchedEffect(leagues, tick) {
        while (true) {
            loading = true
            val r = withContext(Dispatchers.IO) { runCatching { ScoresRepo.fetch(ctx) } }
            loading = false
            r.onSuccess { matches = it; error = null; ScoresWidget.render(ctx) }
                .onFailure { error = "Scores indisponibles (réseau). Derniers résultats connus affichés." }
            delay(if (matches.any { it.live }) 30_000L else 120_000L)
        }
    }
    // Recherche : on charge une fois tous les championnats pour pouvoir trouver n'importe quelle équipe
    LaunchedEffect(searching) {
        if (searching && pool == null) pool = withContext(Dispatchers.IO) { runCatching { ScoresRepo.fetchAll() }.getOrNull() }
    }

    BackHandler(enabled = selected != null || searching) {
        if (selected != null) selected = null else { searching = false; query = "" }
    }

    // Détail d'un match (score à jour : on reprend la version la plus récente de la liste)
    val sel = selected
    if (sel != null) {
        val live = (matches + pool.orEmpty()).firstOrNull { it.id == sel.id && it.leaguePath == sel.leaguePath } ?: sel
        MatchDetailScreen(live, onBack = { selected = null })
        return
    }

    val q = norm(query.trim())
    val searchActive = searching && q.isNotEmpty()
    val shown = if (searchActive)
        (pool ?: matches).filter { norm(it.home).contains(q) || norm(it.away).contains(q) || norm(it.league).contains(q) }
    else matches.filter { it.leaguePath in leagues }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ if (searching) { searching = false; query = "" } else onBack() }) { Icon(Ic.Back, "Retour", tint = LS.Text) }
            if (searching) OutlinedTextField(
                query, { query = it }, Modifier.weight(1f).padding(end = 4.dp), singleLine = true,
                placeholder = { Text("Équipe ou championnat", color = LS.Muted) },
                trailingIcon = { if (query.isNotEmpty()) Icon(Ic.Close, "Effacer", Modifier.clip(RoundedCornerShape(20.dp)).clickable { query = "" }.padding(4.dp), tint = LS.Muted) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = LS.Text, unfocusedTextColor = LS.Text, cursorColor = LS.Blue,
                    focusedBorderColor = LS.Blue, unfocusedBorderColor = LS.Line,
                ),
            ) else {
                Text("Scores", Modifier.weight(1f), color = LS.Text, fontSize = 20.sp, fontWeight = FontWeight.Medium)
                IconButton({ searching = true }) { Icon(Ic.Search, "Rechercher", tint = LS.Blue) }
                IconButton({ tick++ }) { Icon(Ic.Refresh, "Actualiser", tint = LS.Blue) }
            }
        }
        if (loading || (searching && pool == null)) LinearProgressIndicator(Modifier.fillMaxWidth().padding(horizontal = 16.dp), color = LS.Blue)

        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (!searching) {
                item(key = "chips") {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item(key = "all") {
                            val allOn = LEAGUES.all { it.path in leagues }
                            FilterChip(
                                selected = allOn,
                                onClick = {
                                    // Tout : tous les matchs confondus ; re-toucher revient à la sélection par défaut
                                    val n = if (allOn) setOf("soccer/fra.1", "soccer/uefa.champions") else LEAGUES.map { it.path }.toSet()
                                    leagues = n; ScoresPrefs.setLeagues(ctx, n)
                                },
                                label = { Text("Tout") },
                                colors = FilterChipDefaults.filterChipColors(
                                    containerColor = LS.Card, labelColor = LS.Text,
                                    selectedContainerColor = LS.BlueLight, selectedLabelColor = LS.Text,
                                ),
                            )
                        }
                        items(LEAGUES, key = { it.path }) { l ->
                            FilterChip(
                                selected = l.path in leagues,
                                onClick = {
                                    val n = if (l.path in leagues) leagues - l.path else leagues + l.path
                                    leagues = n; ScoresPrefs.setLeagues(ctx, n)
                                },
                                label = { Text(l.label) },
                                colors = FilterChipDefaults.filterChipColors(
                                    containerColor = LS.Card, labelColor = LS.Text,
                                    selectedContainerColor = LS.BlueLight, selectedLabelColor = LS.Text,
                                ),
                            )
                        }
                    }
                }
                item(key = "notif") {
                    Row(
                        Modifier.fillMaxWidth().lsCard(RoundedCornerShape(18.dp)).padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text("Scores en notification", color = LS.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            Text(
                                "Matchs en direct, alerte à chaque but. Widget : appui long sur l'écran d'accueil › Widgets › LinkShare.",
                                color = LS.Muted, fontSize = 11.sp,
                            )
                        }
                        Switch(
                            notif, { toggleNotif(it) },
                            colors = SwitchDefaults.colors(checkedTrackColor = LS.Blue, checkedThumbColor = LS.OnBlue),
                        )
                    }
                }
                error?.let { e -> item(key = "err") { Text(e, color = LS.Muted, fontSize = 12.sp) } }
            } else item(key = "hint") {
                Text(
                    if (q.isEmpty()) "Tape le nom d'une équipe ou d'un championnat (tous les championnats sont inclus)."
                    else "Recherche dans tous les championnats",
                    color = LS.Muted, fontSize = 12.sp,
                )
            }
            if (shown.isEmpty() && !loading && !(searching && pool == null) && !(searching && q.isEmpty())) item(key = "empty") {
                Text(
                    if (searchActive) "Aucun match trouvé pour « ${query.trim()} » (hier, aujourd'hui, demain)."
                    else if (leagues.isEmpty()) "Choisis au moins un championnat." else "Aucun match hier, aujourd'hui ni demain dans ces championnats.",
                    Modifier.fillMaxWidth().padding(top = 24.dp), color = LS.Muted, fontSize = 13.sp, textAlign = TextAlign.Center,
                )
            }
            if (!(searching && q.isEmpty())) for (sec in sections(shown)) {
                item(key = "h_" + sec.title) {
                    Text(
                        sec.title, Modifier.padding(top = 10.dp, bottom = 2.dp),
                        color = if (sec.title == "En direct") LS.Red else LS.Muted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                    )
                }
                items(sec.matches, key = { it.leaguePath + it.id }) { m -> MatchRow(m) { selected = m } }
            }
        }
    }
}

@Composable
private fun MatchRow(m: Match, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().lsCard(RoundedCornerShape(18.dp)).clickable { onClick() }.padding(horizontal = 14.dp, vertical = 10.dp)) {
        Text(m.league, color = LS.Muted, fontSize = 10.sp)
        Spacer(Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                m.home, Modifier.weight(1f), color = LS.Text, fontSize = 14.sp, textAlign = TextAlign.End,
                fontWeight = if (m.live) FontWeight.SemiBold else FontWeight.Normal, maxLines = 2, overflow = TextOverflow.Ellipsis,
            )
            Column(Modifier.width(78.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(m.scoreText, color = LS.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(
                    m.status, color = if (m.live) LS.Red else LS.Muted, fontSize = 11.sp,
                    fontWeight = if (m.live) FontWeight.SemiBold else FontWeight.Normal, maxLines = 1,
                )
            }
            Text(
                m.away, Modifier.weight(1f), color = LS.Text, fontSize = 14.sp, textAlign = TextAlign.Start,
                fontWeight = if (m.live) FontWeight.SemiBold else FontWeight.Normal, maxLines = 2, overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

// ═══════════════════════════ Détail d'un match ═══════════════════════════

/** Statistiques et temps forts (buts, cartons, remplacements) d'un match ; actualisés toutes les 30 s pendant le match. */
@Composable
private fun MatchDetailScreen(m: Match, onBack: () -> Unit) {
    var detail by remember(m.id) { mutableStateOf<MatchDetail?>(null) }
    var failed by remember(m.id) { mutableStateOf(false) }
    var loading by remember(m.id) { mutableStateOf(true) }
    var tick by remember { mutableIntStateOf(0) }
    val liveNow by rememberUpdatedState(m.live)
    LaunchedEffect(m.id, tick) {
        while (true) {
            loading = true
            val r = withContext(Dispatchers.IO) { runCatching { ScoresRepo.fetchDetail(m) } }
            loading = false
            r.onSuccess { detail = it; failed = false }.onFailure { failed = true }
            if (!liveNow) break
            delay(30_000L)
        }
    }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Ic.Back, "Retour", tint = LS.Text) }
            Text(m.league, Modifier.weight(1f), color = LS.Text, fontSize = 18.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            IconButton({ tick++ }) { Icon(Ic.Refresh, "Actualiser", tint = LS.Blue) }
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(horizontal = 16.dp), color = LS.Blue)
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item(key = "head") {
                Column(Modifier.fillMaxWidth().lsCard(RoundedCornerShape(22.dp)).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(m.home, Modifier.weight(1f), color = LS.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.End)
                        Text(m.scoreText, Modifier.padding(horizontal = 14.dp), color = LS.Text, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                        Text(m.away, Modifier.weight(1f), color = LS.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Start)
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(m.status, color = if (m.live) LS.Red else LS.Muted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    detail?.let { d ->
                        val extra = listOfNotNull(d.venue, d.attendance?.let { "%,d spectateurs".format(java.util.Locale.FRANCE, it) }).joinToString(" · ")
                        if (extra.isNotEmpty()) Text(extra, Modifier.padding(top = 4.dp), color = LS.Muted, fontSize = 11.sp, textAlign = TextAlign.Center)
                    }
                }
            }
            val d = detail
            if (d == null) {
                if (!loading) item(key = "none") {
                    Text(
                        if (failed) "Statistiques indisponibles (réseau)." else "",
                        Modifier.fillMaxWidth().padding(top = 16.dp), color = LS.Muted, fontSize = 13.sp, textAlign = TextAlign.Center,
                    )
                }
            } else {
                if (d.events.isNotEmpty()) {
                    item(key = "h_ev") { Text("Temps forts", Modifier.padding(top = 10.dp), color = LS.Muted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
                    item(key = "events") {
                        Column(Modifier.fillMaxWidth().lsCard(RoundedCornerShape(18.dp)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            d.events.forEach { EventRow(it) }
                        }
                    }
                }
                item(key = "h_st") { Text("Statistiques", Modifier.padding(top = 10.dp), color = LS.Muted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
                if (d.stats.isEmpty()) item(key = "nostats") {
                    Text(
                        if (m.state == com.linkshare.scores.MatchState.PRE) "Les statistiques apparaîtront au coup d'envoi." else "Pas de statistiques disponibles pour ce match.",
                        color = LS.Muted, fontSize = 13.sp,
                    )
                } else item(key = "stats") {
                    Column(Modifier.fillMaxWidth().lsCard(RoundedCornerShape(18.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        d.stats.forEach { r ->
                            val hv = r.home.replace("%", "").replace(',', '.').toDoubleOrNull()
                            val av = r.away.replace("%", "").replace(',', '.').toDoubleOrNull()
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(r.home, color = LS.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                    Text(r.label, Modifier.weight(1f), color = LS.Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
                                    Text(r.away, color = LS.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                }
                                Spacer(Modifier.height(4.dp))
                                val total = (hv ?: 0.0) + (av ?: 0.0)
                                val hw = if (hv == null || av == null || total <= 0.0) 0.5f else (hv / total).toFloat()
                                val colored = hv != null && av != null && total > 0.0
                                Row(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp))) {
                                    Box(Modifier.weight(hw.coerceIn(0.001f, 0.999f)).fillMaxHeight().background(if (colored) LS.Blue else LS.Line))
                                    Spacer(Modifier.width(2.dp))
                                    Box(Modifier.weight((1f - hw).coerceIn(0.001f, 0.999f)).fillMaxHeight().background(if (colored) LS.Orange else LS.Line))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EventRow(e: MatchEvent) {
    val icon = when (e.kind) { "goal" -> "⚽"; "yellow" -> "🟨"; "red" -> "🟥"; else -> "🔄" }
    val text = (if (e.minute.isNotBlank()) e.minute + "  " else "") + icon + "  " + e.text
    Text(
        text, Modifier.fillMaxWidth(), color = LS.Text, fontSize = 12.sp,
        textAlign = when (e.home) { true -> TextAlign.Start; false -> TextAlign.End; null -> TextAlign.Center },
    )
}
