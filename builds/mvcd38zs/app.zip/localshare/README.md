# LocalShare

Partage local style Quick Share / AirDrop :
- **envoi de fichiers**, reçus dans le dossier **`DoubigueShare`** et lisibles directement dans l'appli ;
- **accès aux fichiers de l'autre téléphone** (comme un téléphone branché à un PC) ;
- **« Partager mon téléphone »** : l'autre voit votre écran en direct, y compris quand vous quittez l'appli ;
- connexion par **radar** ou par **QR code**.

## Mise en route
1. `flutter create --org com.example --project-name localshare .` (génère android/ et ios/)
2. Copiez `lib/` et `pubspec.yaml` de cette archive, puis `flutter pub get`
3. Remplacez `android/app/src/main/AndroidManifest.xml` par `platform_config/AndroidManifest.xml`
4. Dans `android/app/build.gradle(.kts)` : `minSdk = 23`, `compileSdk = 34` (ou plus),
   `applicationId = "com.example.localshare"` (doit correspondre à `_serviceId` dans NearbyService)
5. iOS : fusionnez `platform_config/Info.plist.snippet.xml` dans `ios/Runner/Info.plist`
6. Testez sur **deux appareils physiques** (pas d'émulateur).

## Utilisation
- **Être visible** : affiche le QR code (appui long = ne plus être visible).
- **Scanner QR** : scanne le QR de l'autre → connexion automatique, sans validation.
- **Radar** : recherche les appareils visibles ; touchez un écho (ou une pastille). L'appareil
  visible doit alors valider la demande en comparant un **code à 4 chiffres** identique des deux côtés.
- Une fois connectés :
  - **Envoyer** : choisit des fichiers.
  - **Ses fichiers** : l'autre téléphone doit **autoriser** (révocable à tout moment). Touchez un
    fichier pour le télécharger, appui long pour en sélectionner plusieurs.
  - **Partager mon téléphone** : confirmation, puis partage jusqu'à « Arrêter le partage ».
- Fichiers reçus : `<stockage interne>/DoubigueShare`. Touchez un transfert terminé (ou l'icône
  dossier de l'accueil) pour l'ouvrir : images, vidéos, audio, PDF et texte se lisent dans l'appli.

## Sécurité
- QR : contient un identifiant public + un **secret aléatoire de session** ; seul celui qui le
  présente est accepté automatiquement. Les autres passent par la validation avec code.
- Accès aux fichiers : consentement explicite, limité au stockage interne, chemins normalisés
  (pas de sortie via `..`), fichiers cachés masqués, remis à zéro à la déconnexion.
- Les noms de fichiers reçus sont assainis avant écriture.

## Limites connues
- **Dossier DoubigueShare à la racine** : Android 11+ exige « Accès à tous les fichiers »
  (`MANAGE_EXTERNAL_STORAGE`), demandé au premier lancement. Si refusé, repli sur le dossier privé de
  l'appli. Cette permission est soumise à justification sur le Play Store (sans objet en installation directe).
- **Partage de téléphone** : WebRTC sans serveur ICE → les deux appareils doivent être sur le **même
  réseau IP** (même Wi-Fi ou point d'accès d'un des téléphones). Il continue en arrière-plan grâce au
  service au premier plan (notification + verrous CPU/Wi-Fi) ; l'arrêt se fait dans l'appli
  (touchez la notification). Ne fermez pas l'appli depuis les « récents » : cela coupe le partage.
  Sur certains constructeurs (Xiaomi, Huawei, Samsung…), désactivez aussi l'économie de batterie pour l'appli.
- **Radar** : Nearby ne donne ni distance ni direction. La position d'un écho est stable mais
  symbolique ; l'écho s'allume quand le faisceau le croise.
- Dossiers : téléchargement fichier par fichier (pas de dossier entier pour l'instant).
- **iOS** : `nearby_connections` est Android-only. Implémentez la même interface que `NearbyService`
  avec MultipeerConnectivity ou Bonjour + sockets TCP ; le protocole JSON (`protocol.dart`) reste identique.
  Le partage d'écran iOS hors appli nécessite une Broadcast Upload Extension (ReplayKit).
- `flutter_foreground_task` doit être en version >= 9.1.0 (paramètre `serviceTypes`).
