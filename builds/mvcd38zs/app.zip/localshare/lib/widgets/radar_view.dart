import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../models/peer.dart';

/// Radar de proximité.
///
/// - Balayage (sweep) rotatif avec traînée dégradée, comme un vrai écran radar.
/// - Chaque appareil est un « écho » : il s'allume quand le faisceau le croise,
///   puis s'estompe (rémanence phosphore) jusqu'au prochain passage.
/// - Ondes de sonar qui partent du centre, graduations de cap, grille.
/// - Toucher un écho lance la connexion.
///
/// NB : l'API Nearby ne fournit ni distance ni direction. La position d'un écho
/// est donc déterministe (dérivée de son identifiant) : elle est stable pour
/// un appareil donné mais n'indique pas sa distance réelle.
class RadarView extends StatefulWidget {
  const RadarView({
    super.key,
    required this.peers,
    required this.active,
    required this.onPeerTap,
  });

  final List<Peer> peers;
  final bool active;
  final ValueChanged<Peer> onPeerTap;

  @override
  State<RadarView> createState() => _RadarViewState();
}

class _RadarViewState extends State<RadarView> with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 3600));

  @override
  void initState() {
    super.initState();
    if (widget.active) _ctrl.repeat();
  }

  @override
  void didUpdateWidget(covariant RadarView old) {
    super.didUpdateWidget(old);
    if (widget.active && !_ctrl.isAnimating) _ctrl.repeat();
    if (!widget.active && _ctrl.isAnimating) _ctrl.stop();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Peer? _hit(Offset pos, double side) {
    final c = Offset(side / 2, side / 2);
    final r = side / 2 - 4;
    Peer? best;
    var bestD = 34.0;
    for (final p in widget.peers) {
      final d = (blipOffset(p, c, r) - pos).distance;
      if (d < bestD) {
        bestD = d;
        best = p;
      }
    }
    return best;
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, box) {
      final side = math.min(box.maxWidth, box.maxHeight);
      return Center(
        child: SizedBox(
          width: side,
          height: side,
          child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTapUp: (d) {
              final p = _hit(d.localPosition, side);
              if (p != null && p.state == PeerState.discovered) widget.onPeerTap(p);
            },
            child: AnimatedBuilder(
              animation: _ctrl,
              builder: (_, __) => CustomPaint(
                painter: _RadarPainter(
                  t: _ctrl.value,
                  peers: widget.peers,
                  active: widget.active,
                ),
              ),
            ),
          ),
        ),
      );
    });
  }
}

int _fnv(String s) {
  var h = 0x811c9dc5;
  for (final u in s.codeUnits) {
    h ^= u;
    h = (h * 0x01000193) & 0xFFFFFFFF;
  }
  return h;
}

/// Position déterministe d'un écho (angle + rayon dérivés de l'id).
Offset blipOffset(Peer p, Offset c, double r) {
  final h = _fnv(p.id);
  final angle = (h % 3600) / 3600 * 2 * math.pi;
  final frac = 0.36 + ((h >> 12) % 100) / 100 * 0.5;
  return c + Offset(math.cos(angle), math.sin(angle)) * (r * frac);
}

double _blipAngle(Peer p) => (_fnv(p.id) % 3600) / 3600 * 2 * math.pi;

class _RadarPainter extends CustomPainter {
  _RadarPainter({required this.t, required this.peers, required this.active});

  final double t;
  final List<Peer> peers;
  final bool active;

  static const _cyan = Color(0xFF00E5FF);
  static const _green = Color(0xFF39FF9A);
  static const _amber = Color(0xFFFFC107);

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2 - 4;
    final rect = Rect.fromCircle(center: c, radius: r);
    final sweep = t * 2 * math.pi;

    // Fond
    canvas.drawCircle(
      c,
      r,
      Paint()
        ..shader = const RadialGradient(
          colors: [Color(0xFF06343F), Color(0xFF020B10)],
        ).createShader(rect),
    );

    final line = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;

    // Cercles de portée
    for (var i = 1; i <= 3; i++) {
      canvas.drawCircle(c, r * i / 4, line..color = _cyan.withOpacity(0.18));
    }
    // Axes
    line.color = _cyan.withOpacity(0.14);
    canvas.drawLine(Offset(c.dx - r, c.dy), Offset(c.dx + r, c.dy), line);
    canvas.drawLine(Offset(c.dx, c.dy - r), Offset(c.dx, c.dy + r), line);

    // Graduations de cap
    for (var deg = 0; deg < 360; deg += 6) {
      final a = deg * math.pi / 180;
      final len = deg % 30 == 0 ? 11.0 : 5.0;
      final d = Offset(math.cos(a), math.sin(a));
      canvas.drawLine(
        c + d * (r - len),
        c + d * r,
        line..color = _cyan.withOpacity(deg % 30 == 0 ? 0.7 : 0.35),
      );
    }
    // Bague extérieure
    canvas.drawCircle(
      c,
      r,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = _cyan.withOpacity(0.65),
    );

    if (active) {
      // Ondes sonar
      for (var k = 0; k < 3; k++) {
        final ph = (t * 1.0 + k / 3) % 1.0;
        canvas.drawCircle(
          c,
          r * ph,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = 1.6
            ..color = _green.withOpacity((1 - ph) * 0.35),
        );
      }
      // Faisceau + traînée
      canvas.save();
      canvas.clipPath(Path()..addOval(rect));
      canvas.drawCircle(
        c,
        r,
        Paint()
          ..shader = SweepGradient(
            colors: [
              _cyan.withOpacity(0),
              _cyan.withOpacity(0),
              _cyan.withOpacity(0.5),
            ],
            stops: const [0.0, 0.7, 1.0],
            transform: GradientRotation(sweep),
          ).createShader(rect),
      );
      canvas.restore();
      canvas.drawLine(
        c,
        c + Offset(math.cos(sweep), math.sin(sweep)) * r,
        Paint()
          ..color = _cyan.withOpacity(0.95)
          ..strokeWidth = 2
          ..strokeCap = StrokeCap.round,
      );
    }

    // Échos (appareils)
    for (final p in peers) {
      final pos = blipOffset(p, c, r);
      var b = 0.3;
      if (active) {
        var delta = (sweep - _blipAngle(p)) % (2 * math.pi);
        if (delta < 0) delta += 2 * math.pi;
        b = 0.25 + 0.75 * math.exp(-delta * 0.9); // rémanence
      }
      final color = switch (p.state) {
        PeerState.discovered => _green,
        PeerState.connecting => _amber,
        PeerState.connected => _cyan,
      };
      final pulse = p.state == PeerState.connecting ? 2.5 * math.sin(t * 2 * math.pi * 4).abs() : 0.0;

      canvas.drawCircle(
        pos,
        13 + pulse,
        Paint()
          ..color = color.withOpacity(0.5 * b)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8),
      );
      canvas.drawCircle(pos, 5.5, Paint()..color = color.withOpacity(0.35 + 0.65 * b));
      canvas.drawCircle(
        pos,
        10 + pulse,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.2
          ..color = color.withOpacity(0.6 * b),
      );

      final tp = TextPainter(
        text: TextSpan(
          text: p.name,
          style: TextStyle(
            color: Colors.white.withOpacity(0.55 + 0.45 * b),
            fontSize: 11,
            fontWeight: FontWeight.w600,
          ),
        ),
        maxLines: 1,
        ellipsis: '…',
        textDirection: TextDirection.ltr,
      )..layout(maxWidth: 110);
      final x = (pos.dx - tp.width / 2).clamp(4.0, size.width - tp.width - 4);
      tp.paint(canvas, Offset(x, pos.dy + 14));
    }

    // Centre : cet appareil
    canvas.drawCircle(
      c,
      16,
      Paint()
        ..color = _green.withOpacity(0.3)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8),
    );
    canvas.drawCircle(c, 9, Paint()..style = PaintingStyle.stroke..strokeWidth = 1.5..color = _green);
    canvas.drawCircle(c, 4.5, Paint()..color = Colors.white);
  }

  @override
  bool shouldRepaint(covariant _RadarPainter old) => true;
}
