import 'dart:async';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:nearby_connections/nearby_connections.dart';
import 'nearby_service.dart';
import 'protocol.dart';

/// « Partager mon téléphone » : partage d'écran WebRTC, continue en arrière-plan.
/// - Signalisation (offer/answer/ICE) : envoyée via les BYTES payloads Nearby.
/// - Média : WebRTC direct. IMPORTANT : sans serveur ICE, les deux appareils
///   doivent partager un réseau IP (même Wi-Fi ou hotspot d'un des deux téléphones).
class ScreenShareService extends ChangeNotifier {
  ScreenShareService(this._nearby) {
    _sub = _nearby.onPayload.listen(_onPayload);
  }

  final NearbyService _nearby;
  late final StreamSubscription _sub;

  final RTCVideoRenderer remoteRenderer = RTCVideoRenderer();
  RTCPeerConnection? _pc;
  MediaStream? _localStream;
  final List<RTCIceCandidate> _pendingIce = [];
  bool _remoteDescSet = false;

  bool isSharing = false; // je diffuse mon écran
  bool isViewing = false; // je regarde l'écran de l'autre
  bool _rendererReady = false;

  Future<void> init() async {
    if (_rendererReady) return;
    _rendererReady = true;
    await remoteRenderer.initialize();
  }

  // ------------------------------------------------------------ côté émetteur
  Future<void> startSharing() async {
    if (isSharing) return;
    try {
      if (Platform.isAndroid) {
        await _prepareBackground();
        // 1) Autorisation MediaProjection, 2) service au premier plan (Android 14+
        // exige cet ordre), 3) capture.
        final granted = await Helper.requestCapturePermission();
        if (!granted) return;
        await _startForegroundService();
      }

      final stream = await navigator.mediaDevices.getDisplayMedia({
        'video': {'frameRate': 24},
        'audio': false,
      });
      _localStream = stream;

      // Si l'utilisateur arrête la capture depuis la barre système.
      stream.getVideoTracks().first.onEnded = stopSharing;

      final pc = await _createPeerConnection();
      for (final t in stream.getTracks()) {
        await pc.addTrack(t, stream);
      }

      final offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      await _nearby.sendBytes(Protocol.encode(
        {'t': 'offer', 'sdp': offer.sdp, 'type': offer.type},
      ));

      isSharing = true;
      notifyListeners();
    } catch (e) {
      debugPrint('startSharing error: $e');
      await _teardown();
    }
  }

  Future<void> stopSharing() async {
    await _nearby.sendBytes(Protocol.encode({'t': 'ss_stop'}));
    await _teardown();
  }

  // ----------------------------------------------------------- côté récepteur
  Future<void> _handleOffer(Map<String, dynamic> m) async {
    await _teardown(notify: false);
    final pc = await _createPeerConnection();
    await pc.setRemoteDescription(RTCSessionDescription(m['sdp'], m['type']));
    _remoteDescSet = true;
    await _flushPendingIce();

    final answer = await pc.createAnswer();
    await pc.setLocalDescription(answer);
    await _nearby.sendBytes(Protocol.encode(
      {'t': 'answer', 'sdp': answer.sdp, 'type': answer.type},
    ));
  }

  // ----------------------------------------------------------------- commun
  Future<RTCPeerConnection> _createPeerConnection() async {
    final pc = await createPeerConnection({
      'iceServers': <Map<String, dynamic>>[], // pas de STUN/TURN : réseau local
      'sdpSemantics': 'unified-plan',
    });

    pc.onIceCandidate = (c) {
      if (c.candidate == null) return;
      _nearby.sendBytes(Protocol.encode({'t': 'ice', 'c': c.toMap()}));
    };

    pc.onTrack = (e) {
      if (e.streams.isEmpty) return;
      remoteRenderer.srcObject = e.streams.first;
      isViewing = true;
      notifyListeners();
    };

    pc.onConnectionState = (s) {
      if (s == RTCPeerConnectionState.RTCPeerConnectionStateFailed ||
          s == RTCPeerConnectionState.RTCPeerConnectionStateClosed) {
        _teardown();
      }
    };

    _pc = pc;
    _remoteDescSet = false;
    return pc;
  }

  Future<void> _onPayload((String, Payload) event) async {
    final m = Protocol.decode(event.$2);
    if (m == null) return;

    switch (m['t']) {
      case 'offer':
        await _handleOffer(m);
        break;
      case 'answer':
        await _pc?.setRemoteDescription(RTCSessionDescription(m['sdp'], m['type']));
        _remoteDescSet = true;
        await _flushPendingIce();
        break;
      case 'ice':
        final c = m['c'] as Map<String, dynamic>;
        final cand = RTCIceCandidate(c['candidate'], c['sdpMid'], c['sdpMLineIndex']);
        if (_pc != null && _remoteDescSet) {
          await _pc!.addCandidate(cand);
        } else {
          _pendingIce.add(cand); // reçu avant la description distante
        }
        break;
      case 'ss_stop':
        await _teardown();
        break;
    }
  }

  Future<void> _flushPendingIce() async {
    for (final c in _pendingIce) {
      await _pc?.addCandidate(c);
    }
    _pendingIce.clear();
  }

  /// Pour que le partage survive en arrière-plan : notification autorisée
  /// (Android 13+) et appli exclue de l'optimisation de batterie.
  Future<void> _prepareBackground() async {
    final notif = await FlutterForegroundTask.checkNotificationPermission();
    if (notif != NotificationPermission.granted) {
      await FlutterForegroundTask.requestNotificationPermission();
    }
    if (!await FlutterForegroundTask.isIgnoringBatteryOptimizations) {
      await FlutterForegroundTask.requestIgnoreBatteryOptimization();
    }
  }

  /// Service au premier plan : garde le processus (donc la capture, WebRTC et la
  /// connexion Nearby) en vie quand l'utilisateur quitte l'appli. Verrous CPU
  /// et Wi-Fi maintenus jusqu'à l'appui sur « Arrêter ».
  Future<void> _startForegroundService() async {
    FlutterForegroundTask.init(
      androidNotificationOptions: AndroidNotificationOptions(
        channelId: 'phone_share',
        channelName: 'Partage du téléphone',
        channelImportance: NotificationChannelImportance.LOW,
        priority: NotificationPriority.LOW,
      ),
      iosNotificationOptions: const IOSNotificationOptions(),
      foregroundTaskOptions: ForegroundTaskOptions(
        eventAction: ForegroundTaskEventAction.nothing(),
        allowWakeLock: true,
        allowWifiLock: true,
      ),
    );
    await FlutterForegroundTask.startService(
      serviceId: 7001,
      notificationTitle: 'Partage du téléphone en cours',
      notificationText: "Touchez pour revenir dans l'appli et arrêter le partage",
      serviceTypes: [ForegroundServiceTypes.mediaProjection],
    );
  }

  Future<void> _teardown({bool notify = true}) async {
    _localStream?.getTracks().forEach((t) => t.stop());
    await _localStream?.dispose();
    _localStream = null;
    await _pc?.close();
    _pc = null;
    _pendingIce.clear();
    _remoteDescSet = false;
    remoteRenderer.srcObject = null;
    if (Platform.isAndroid && await FlutterForegroundTask.isRunningService) {
      await FlutterForegroundTask.stopService();
    }
    isSharing = false;
    isViewing = false;
    if (notify) notifyListeners();
  }

  @override
  void dispose() {
    _sub.cancel();
    _teardown(notify: false);
    remoteRenderer.dispose();
    super.dispose();
  }
}
