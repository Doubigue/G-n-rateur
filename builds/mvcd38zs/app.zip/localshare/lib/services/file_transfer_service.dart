import 'dart:async';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:nearby_connections/nearby_connections.dart';
import 'package:path/path.dart' as p;
import 'nearby_service.dart';
import 'protocol.dart';
import 'storage_service.dart';

enum TransferStatus { inProgress, done, failed }

class TransferItem {
  TransferItem({
    required this.payloadId,
    required this.name,
    required this.outgoing,
    this.total = 0,
  });
  final int payloadId;
  String name;
  final bool outgoing;
  int total;
  int transferred = 0;
  TransferStatus status = TransferStatus.inProgress;
  String? savedPath; // destination finale dans DoubigueShare (réception)

  double get progress => total == 0 ? 0 : (transferred / total).clamp(0.0, 1.0);
}

/// Envoi / réception de fichiers via les payloads Nearby.
/// Les fichiers reçus sont rangés dans <stockage>/DoubigueShare.
class FileTransferService extends ChangeNotifier {
  FileTransferService(this._nearby) {
    _subs.add(_nearby.onPayload.listen(_onPayload));
    _subs.add(_nearby.onProgress.listen(_onProgress));
  }

  final NearbyService _nearby;
  final List<StreamSubscription> _subs = [];
  final Map<int, TransferItem> _items = {};
  final Map<int, String> _names = {};
  final Map<int, String> _sources = {};

  List<TransferItem> get items => _items.values.toList().reversed.toList();

  // ------------------------------------------------------------------ envoi
  Future<void> pickAndSend() async {
    final res = await FilePicker.platform.pickFiles(allowMultiple: true);
    if (res == null) return;
    for (final f in res.files) {
      final path = f.path;
      if (path != null) await sendPath(path);
    }
  }

  /// Envoie un fichier local (utilisé aussi quand l'autre appareil en télécharge un).
  Future<void> sendPath(String path) async {
    final file = File(path);
    if (!await file.exists()) return;
    final size = await file.length();
    final name = p.basename(path);

    final id = await _nearby.sendFile(path);
    if (id == null) return;

    _items[id] = TransferItem(payloadId: id, name: name, outgoing: true, total: size);
    notifyListeners();

    await _nearby.sendBytes(
      Protocol.encode({'t': 'file', 'id': id, 'name': name, 'size': size}),
    );
  }

  // -------------------------------------------------------------- réception
  void _onPayload((String, Payload) event) {
    final payload = event.$2;

    if (payload.type == PayloadType.BYTES) {
      final msg = Protocol.decode(payload);
      if (msg == null || msg['t'] != 'file') return;
      final id = msg['id'] as int;
      _names[id] = msg['name'] as String;
      _items[id]?.name = _safeName(_names[id]!);
      notifyListeners();
    } else if (payload.type == PayloadType.FILE) {
      _sources[payload.id] = payload.uri ?? payload.filePath ?? '';
      _items[payload.id] = TransferItem(
        payloadId: payload.id,
        name: _names[payload.id] != null ? _safeName(_names[payload.id]!) : 'Réception…',
        outgoing: false,
      );
      notifyListeners();
    }
  }

  Future<void> _onProgress((String, PayloadTransferUpdate) event) async {
    final u = event.$2;
    final item = _items[u.id];
    if (item == null) return;

    item.total = u.totalBytes > 0 ? u.totalBytes : item.total;
    item.transferred = u.bytesTransferred;

    switch (u.status) {
      case PayloadStatus.IN_PROGRESS:
        break;
      case PayloadStatus.SUCCESS:
        item.transferred = item.total;
        if (item.outgoing) {
          item.status = TransferStatus.done;
        } else {
          await _saveReceived(item);
        }
        break;
      case PayloadStatus.FAILURE:
      case PayloadStatus.CANCELED:
        item.status = TransferStatus.failed;
        break;
      default:
        break;
    }
    notifyListeners();
  }

  /// Le nom vient de l'autre appareil : on ne garde que le nom de fichier
  /// (protège contre « ../../ » et caractères interdits).
  String _safeName(String raw) {
    var n = p.basename(raw.replaceAll('\\', '/')).replaceAll(RegExp(r'[<>:"|?*\x00-\x1F]'), '_').trim();
    if (n.isEmpty || n == '.' || n == '..') n = 'fichier';
    return n;
  }

  Future<void> _saveReceived(TransferItem item) async {
    try {
      final dir = await StorageService.shareDir();

      // Les métadonnées (nom) peuvent arriver juste après un très petit fichier.
      for (var i = 0; i < 30 && !_names.containsKey(item.payloadId); i++) {
        await Future.delayed(const Duration(milliseconds: 100));
      }
      final name = _safeName(_names[item.payloadId] ?? 'fichier_${item.payloadId}');
      item.name = name;
      final dest = _uniquePath(dir.path, name);

      final ok = await _nearby.moveReceivedFile(_sources[item.payloadId] ?? '', dest);
      item.savedPath = ok ? dest : null;
      item.status = ok ? TransferStatus.done : TransferStatus.failed;
    } catch (e) {
      debugPrint('saveReceived error: $e');
      item.status = TransferStatus.failed;
    }
  }

  String _uniquePath(String dir, String name) {
    var path = '$dir/$name';
    var i = 1;
    final dot = name.lastIndexOf('.');
    final stem = dot > 0 ? name.substring(0, dot) : name;
    final ext = dot > 0 ? name.substring(dot) : '';
    while (File(path).existsSync()) {
      path = '$dir/$stem ($i)$ext';
      i++;
    }
    return path;
  }

  @override
  void dispose() {
    for (final s in _subs) {
      s.cancel();
    }
    super.dispose();
  }
}
