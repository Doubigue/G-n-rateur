import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:nearby_connections/nearby_connections.dart';
import 'package:permission_handler/permission_handler.dart';
import '../models/peer.dart';
import '../models/qr_payload.dart';
import 'protocol.dart';

/// Rôle de cet appareil dans la session.
enum NearbyRole { none, host, client }

/// Demande de connexion entrante à valider manuellement.
class PendingConnection {
  PendingConnection(this.id, this.name, this.code);
  final String id;
  final String name;
  final String code; // authenticationToken : doit être identique des deux côtés
}

/// Gère découverte, connexion et échange de payloads.
/// Host   = celui qui s'annonce (advertising) et affiche le QR code
/// Client = celui qui scanne (radar ou QR) et demande la connexion
///
/// Sécurité : l'hôte accepte automatiquement uniquement celui qui présente le
/// secret du QR code. Toute autre demande (radar) passe par une confirmation
/// avec code de vérification.
class NearbyService extends ChangeNotifier {
  static const _serviceId = 'com.example.localshare'; // = applicationId
  static const _strategy = Strategy.P2P_POINT_TO_POINT;

  final Nearby _nearby = Nearby();
  final Map<String, Peer> _peers = {};
  NearbyRole role = NearbyRole.none;
  bool isAdvertising = false;
  bool isDiscovering = false;
  String? connectedId;
  String deviceName = 'Appareil';

  /// Message d'état affiché à l'utilisateur (recherche QR, erreurs…).
  String? status;

  /// Demande entrante en attente de validation (côté hôte).
  PendingConnection? pending;

  /// Code de vérification côté demandeur.
  String? outgoingCode;

  String? _rid;
  String? _secret;
  QrPayload? _qrTarget;
  Timer? _qrTimer;

  final _payloadCtrl = StreamController<(String, Payload)>.broadcast();
  final _progressCtrl = StreamController<(String, PayloadTransferUpdate)>.broadcast();
  Stream<(String, Payload)> get onPayload => _payloadCtrl.stream;
  Stream<(String, PayloadTransferUpdate)> get onProgress => _progressCtrl.stream;

  List<Peer> get peers => _peers.values.toList();
  bool get isConnected => connectedId != null;
  String get connectedName => _peers[connectedId]?.name ?? 'Appareil';

  /// QR code à afficher (non null tant que l'appareil est visible).
  QrPayload? get myQr => (isAdvertising && _rid != null && _secret != null)
      ? QrPayload(rid: _rid!, secret: _secret!, name: deviceName)
      : null;

  static bool get supported => Platform.isAndroid;

  // ---------------------------------------------------------------- init
  Future<void> init() async {
    if (Platform.isAndroid) {
      final info = await DeviceInfoPlugin().androidInfo;
      deviceName = '${info.brand} ${info.model}'.replaceAll('#', '');
      notifyListeners();
    }
  }

  Future<bool> requestPermissions() async {
    final perms = <Permission>[
      Permission.location,
      Permission.bluetooth,
      Permission.bluetoothAdvertise,
      Permission.bluetoothConnect,
      Permission.bluetoothScan,
      Permission.nearbyWifiDevices, // Android 13+
    ];
    final res = await perms.request();
    final critical = [Permission.location, Permission.bluetoothScan, Permission.bluetoothConnect];
    final ok = critical.every((p) => res[p]?.isGranted ?? true);
    if (!ok) {
      status = 'Permissions refusées : activez-les dans les réglages.';
      notifyListeners();
    }
    return ok;
  }

  static String _randomHex(int n) {
    final r = Random.secure();
    return List.generate(n, (_) => r.nextInt(16).toRadixString(16)).join();
  }

  // ------------------------------------------------------- advertising (Hôte)
  Future<void> startAdvertising() async {
    if (!supported) return;
    if (!await requestPermissions()) return;
    _rid = _randomHex(4);
    _secret = _randomHex(16);
    try {
      await _nearby.stopAdvertising();
      isAdvertising = await _nearby.startAdvertising(
        Protocol.joinName(deviceName, _rid!),
        _strategy,
        serviceId: _serviceId,
        onConnectionInitiated: _onConnectionInitiated,
        onConnectionResult: _onConnectionResult,
        onDisconnected: _onDisconnected,
      );
      if (isAdvertising) {
        role = NearbyRole.host;
        status = null;
      }
    } catch (e) {
      debugPrint('startAdvertising error: $e');
      status = 'Impossible de devenir visible.';
    }
    if (!isAdvertising) _rid = _secret = null;
    notifyListeners();
  }

  Future<void> stopAdvertising() async {
    await _nearby.stopAdvertising();
    isAdvertising = false;
    _rid = _secret = null;
    notifyListeners();
  }

  // --------------------------------------------------------- discovery (Client)
  Future<void> startDiscovery() async {
    if (!supported) return;
    if (!await requestPermissions()) return;
    _peers.removeWhere((_, p) => p.state != PeerState.connected);
    try {
      await _nearby.stopDiscovery();
      isDiscovering = await _nearby.startDiscovery(
        Protocol.joinName(deviceName, ''),
        _strategy,
        serviceId: _serviceId,
        onEndpointFound: (id, rawName, _) {
          final (display, rid) = Protocol.splitName(rawName);
          final peer = Peer(id, display, rid: rid);
          _peers[id] = peer;
          // Scan de QR code en cours : on se connecte dès que l'appareil apparaît.
          final t = _qrTarget;
          if (t != null && rid == t.rid) _connectFromQr(peer, t);
          notifyListeners();
        },
        onEndpointLost: (id) {
          if (id != null) _peers.remove(id);
          notifyListeners();
        },
      );
    } catch (e) {
      debugPrint('startDiscovery error: $e');
      status = 'Impossible de lancer la recherche.';
    }
    notifyListeners();
  }

  Future<void> stopDiscovery() async {
    await _nearby.stopDiscovery();
    isDiscovering = false;
    notifyListeners();
  }

  // ------------------------------------------------------------- QR code
  /// Retrouve l'appareil du QR (via son rid) puis s'y connecte avec le secret.
  Future<void> connectByQr(QrPayload target) async {
    _qrTarget = target;
    status = 'Recherche de ${target.name}…';
    notifyListeners();

    final already = _peers.values.where((p) => p.rid == target.rid);
    if (already.isNotEmpty) {
      _connectFromQr(already.first, target);
      return;
    }
    await startDiscovery();
    _qrTimer?.cancel();
    _qrTimer = Timer(const Duration(seconds: 25), () async {
      if (_qrTarget != null && !isConnected) {
        _qrTarget = null;
        status = 'Appareil introuvable. Vérifiez qu\u2019il est toujours « Visible ».';
        await stopDiscovery();
      }
    });
  }

  void _connectFromQr(Peer peer, QrPayload t) {
    _qrTimer?.cancel();
    _qrTarget = null;
    status = 'Connexion à ${t.name}…';
    connectTo(peer, secret: t.secret);
  }

  // ------------------------------------------------------------- connexion
  Future<void> connectTo(Peer peer, {String secret = ''}) async {
    peer.state = PeerState.connecting;
    notifyListeners();
    try {
      await _nearby.requestConnection(
        Protocol.joinName(deviceName, secret),
        peer.id,
        onConnectionInitiated: _onConnectionInitiated,
        onConnectionResult: _onConnectionResult,
        onDisconnected: _onDisconnected,
      );
      role = NearbyRole.client;
    } catch (e) {
      peer.state = PeerState.discovered;
      status = 'Connexion impossible.';
      debugPrint('requestConnection error: $e');
      notifyListeners();
    }
  }

  void _onConnectionInitiated(String id, ConnectionInfo info) {
    final (name, secret) = Protocol.splitName(info.endpointName);
    final peer = _peers.putIfAbsent(id, () => Peer(id, name));
    peer.state = PeerState.connecting;

    final trusted = !info.isIncomingConnection ||
        (_secret != null && secret.isNotEmpty && secret == _secret);
    if (trusted) {
      _accept(id);
    } else {
      pending = PendingConnection(id, name, info.authenticationToken);
    }
    if (!info.isIncomingConnection) outgoingCode = info.authenticationToken;
    notifyListeners();
  }

  void _accept(String id) {
    _nearby.acceptConnection(
      id,
      onPayLoadRecieved: (endpointId, payload) => _payloadCtrl.add((endpointId, payload)),
      onPayloadTransferUpdate: (endpointId, update) => _progressCtrl.add((endpointId, update)),
    );
  }

  void acceptPending() {
    final pc = pending;
    if (pc == null) return;
    pending = null;
    _accept(pc.id);
    notifyListeners();
  }

  void rejectPending() {
    final pc = pending;
    if (pc == null) return;
    pending = null;
    _nearby.rejectConnection(pc.id);
    _peers.remove(pc.id);
    notifyListeners();
  }

  void _onConnectionResult(String id, Status result) {
    if (result == Status.CONNECTED) {
      connectedId = id;
      _peers[id]?.state = PeerState.connected;
      pending = null;
      outgoingCode = null;
      status = null;
      _qrTimer?.cancel();
      _qrTarget = null;
      _nearby.stopAdvertising();
      _nearby.stopDiscovery();
      isAdvertising = isDiscovering = false;
      _rid = _secret = null;
    } else {
      _peers[id]?.state = PeerState.discovered;
      pending = null;
      outgoingCode = null;
      status = 'Connexion refusée ou échouée.';
      role = NearbyRole.none;
    }
    notifyListeners();
  }

  void _onDisconnected(String id) {
    _peers.remove(id);
    if (connectedId == id) connectedId = null;
    role = NearbyRole.none;
    notifyListeners();
  }

  Future<void> disconnect() async {
    if (connectedId != null) await _nearby.disconnectFromEndpoint(connectedId!);
    await _nearby.stopAllEndpoints();
    connectedId = null;
    role = NearbyRole.none;
    _peers.clear();
    notifyListeners();
  }

  // --------------------------------------------------------------- envoi
  Future<void> sendBytes(Uint8List data) async {
    if (connectedId != null) await _nearby.sendBytesPayload(connectedId!, data);
  }

  Future<int?> sendFile(String path) async {
    if (connectedId == null) return null;
    return _nearby.sendFilePayload(connectedId!, path);
  }

  Future<bool> moveReceivedFile(String sourceUri, String destPath) =>
      _nearby.copyFileAndDeleteOriginal(sourceUri, destPath);

  @override
  void dispose() {
    _qrTimer?.cancel();
    _payloadCtrl.close();
    _progressCtrl.close();
    super.dispose();
  }
}
