import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:nearby_connections/nearby_connections.dart';
import 'package:path/path.dart' as p;
import 'file_transfer_service.dart';
import 'nearby_service.dart';
import 'protocol.dart';
import 'storage_service.dart';

enum RemoteAccess { none, requesting, granted, denied }

class RemoteEntry {
  RemoteEntry(this.name, this.isDir, this.size, this.modified);
  final String name;
  final bool isDir;
  final int size;
  final DateTime modified;

  factory RemoteEntry.fromJson(Map<String, dynamic> j) => RemoteEntry(
        j['n'] as String,
        (j['d'] as int) == 1,
        (j['s'] as num).toInt(),
        DateTime.fromMillisecondsSinceEpoch((j['m'] as num).toInt()),
      );
}

/// Accès aux fichiers de l'autre téléphone, comme un téléphone branché à un PC.
///
/// - Côté « serveur » (mon téléphone exposé) : l'accès doit être AUTORISÉ
///   explicitement, il est limité au stockage interne, par session, et révocable.
/// - Côté « client » : navigation dossier par dossier + téléchargement dans
///   DoubigueShare (via le même canal que l'envoi de fichiers).
class RemoteFsService extends ChangeNotifier {
  RemoteFsService(this._nearby, this._files) {
    _sub = _nearby.onPayload.listen(_onPayload);
    _nearby.addListener(_onNearby);
  }

  final NearbyService _nearby;
  final FileTransferService _files;
  late final StreamSubscription _sub;

  static const root = StorageService.rootPath;

  // ----------------------------------------------------- état « serveur »
  bool accessGranted = false; // l'autre peut parcourir MES fichiers
  bool pendingRequest = false; // il demande l'autorisation

  // ------------------------------------------------------ état « client »
  RemoteAccess access = RemoteAccess.none;
  String currentPath = root;
  List<RemoteEntry> entries = [];
  bool loading = false;
  String? error;
  int _req = 0;

  bool get atRoot => currentPath == root;

  void _onNearby() {
    if (!_nearby.isConnected && (access != RemoteAccess.none || accessGranted || pendingRequest)) {
      _reset();
    }
  }

  void _reset() {
    accessGranted = false;
    pendingRequest = false;
    access = RemoteAccess.none;
    currentPath = root;
    entries = [];
    loading = false;
    error = null;
    notifyListeners();
  }

  // ------------------------------------------------------------- client
  Future<void> requestAccess() async {
    access = RemoteAccess.requesting;
    error = null;
    notifyListeners();
    await _nearby.sendBytes(Protocol.encode({'t': 'fs_req'}));
  }

  Future<void> list(String path) async {
    _req++;
    loading = true;
    error = null;
    entries = [];
    currentPath = path;
    notifyListeners();
    await _nearby.sendBytes(Protocol.encode({'t': 'ls', 'r': _req, 'p': path}));
  }

  Future<void> up() async {
    if (atRoot) return;
    await list(p.dirname(currentPath));
  }

  Future<void> refresh() => list(currentPath);

  Future<void> download(Iterable<String> remotePaths) async {
    for (final path in remotePaths) {
      await _nearby.sendBytes(Protocol.encode({'t': 'get', 'p': path}));
    }
  }

  // ------------------------------------------------------------ serveur
  Future<void> respond(bool ok) async {
    pendingRequest = false;
    accessGranted = ok;
    notifyListeners();
    await _nearby.sendBytes(Protocol.encode({'t': 'fs_grant', 'ok': ok}));
  }

  Future<void> revoke() async {
    accessGranted = false;
    notifyListeners();
    await _nearby.sendBytes(Protocol.encode({'t': 'fs_revoke'}));
  }

  /// Refuse tout chemin hors du stockage interne (« .. », autre racine…).
  String? _safe(String path) {
    final norm = p.normalize(path);
    if (norm == root || p.isWithin(root, norm)) return norm;
    return null;
  }

  Future<void> _serveList(int r, String path) async {
    Future<void> reply(Map<String, dynamic> extra) => _nearby.sendBytes(Protocol.encode({
          't': 'ls_r',
          'r': r,
          'p': path,
          'pg': 0,
          'more': false,
          'e': <Map<String, dynamic>>[],
          ...extra,
        }));

    final safe = _safe(path);
    if (!accessGranted || safe == null) {
      await reply({'err': 'Accès refusé'});
      return;
    }
    try {
      final list = <Map<String, dynamic>>[];
      await for (final ent in Directory(safe).list(followLinks: false)) {
        final name = p.basename(ent.path);
        if (name.startsWith('.')) continue; // fichiers cachés masqués
        try {
          final st = ent.statSync();
          list.add({
            'n': name,
            'd': ent is Directory ? 1 : 0,
            's': st.size,
            'm': st.modified.millisecondsSinceEpoch,
          });
        } catch (_) {}
      }
      list.sort((a, b) {
        if (a['d'] != b['d']) return (b['d'] as int).compareTo(a['d'] as int);
        return (a['n'] as String).toLowerCase().compareTo((b['n'] as String).toLowerCase());
      });

      // Pagination : un message Nearby fait au plus 32 Ko.
      var page = <Map<String, dynamic>>[];
      var size = 0;
      var pg = 0;
      Future<void> flush(bool more) async {
        await reply({'p': safe, 'pg': pg++, 'more': more, 'e': page});
        page = [];
        size = 0;
      }

      for (final e in list) {
        final approx = utf8.encode(e['n'] as String).length + 60;
        if (size + approx > 20000) await flush(true);
        page.add(e);
        size += approx;
      }
      await flush(false);
    } catch (e) {
      await reply({'err': 'Dossier illisible'});
    }
  }

  Future<void> _serveGet(String path) async {
    final safe = _safe(path);
    if (!accessGranted || safe == null) return;
    if (await File(safe).exists()) await _files.sendPath(safe);
  }

  // ------------------------------------------------------------ réception
  void _onPayload((String, Payload) event) {
    final m = Protocol.decode(event.$2);
    if (m == null) return;

    switch (m['t']) {
      // ----- côté serveur
      case 'fs_req':
        if (accessGranted) {
          respond(true);
        } else {
          pendingRequest = true;
          notifyListeners();
        }
        break;
      case 'ls':
        _serveList(m['r'] as int, m['p'] as String);
        break;
      case 'get':
        _serveGet(m['p'] as String);
        break;

      // ----- côté client
      case 'fs_grant':
        if (m['ok'] == true) {
          access = RemoteAccess.granted;
          notifyListeners();
          list(root);
        } else {
          access = RemoteAccess.denied;
          notifyListeners();
        }
        break;
      case 'fs_revoke':
        access = RemoteAccess.denied;
        entries = [];
        currentPath = root;
        loading = false;
        notifyListeners();
        break;
      case 'ls_r':
        if (m['r'] != _req) return; // réponse périmée
        if (m['err'] != null) {
          error = m['err'] as String;
          loading = false;
        } else {
          if (m['pg'] == 0) currentPath = m['p'] as String;
          entries = [
            ...entries,
            ...(m['e'] as List).map((x) => RemoteEntry.fromJson(x as Map<String, dynamic>)),
          ];
          loading = m['more'] == true;
        }
        notifyListeners();
        break;
    }
  }

  @override
  void dispose() {
    _nearby.removeListener(_onNearby);
    _sub.cancel();
    super.dispose();
  }
}
