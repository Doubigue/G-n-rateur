import 'dart:io';
import 'package:flutter/material.dart';
import '../models/peer.dart';
import '../models/qr_payload.dart';
import '../services/file_transfer_service.dart';
import '../services/nearby_service.dart';
import '../services/remote_fs_service.dart';
import '../services/screen_share_service.dart';
import '../services/storage_service.dart';
import '../widgets/qr_sheet.dart';
import '../widgets/radar_view.dart';
import 'received_screen.dart';
import 'scan_qr_screen.dart';
import 'transfer_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({
    super.key,
    required this.nearby,
    required this.files,
    required this.screen,
    required this.remote,
  });
  final NearbyService nearby;
  final FileTransferService files;
  final ScreenShareService screen;
  final RemoteFsService remote;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  NearbyService get n => widget.nearby;
  bool _transferOpen = false;
  bool _pendingDialogOpen = false;

  @override
  void initState() {
    super.initState();
    n.init();
    n.addListener(_onChange);
    WidgetsBinding.instance.addPostFrameCallback((_) => _ensureStorage());
  }

  /// Au premier lancement : explique puis demande l'accès aux fichiers et crée
  /// le dossier DoubigueShare.
  Future<void> _ensureStorage() async {
    if (!Platform.isAndroid) {
      await StorageService.shareDir();
      return;
    }
    if (await StorageService.hasAccess()) {
      await StorageService.shareDir();
      return;
    }
    if (!mounted) return;
    final ok = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        icon: const Icon(Icons.folder_special_outlined, size: 36),
        title: const Text('Accès aux fichiers'),
        content: const Text(
          'Pour créer le dossier « ${StorageService.folderName} » où seront rangés les fichiers reçus, '
          'et pouvoir parcourir vos fichiers à distance (si vous l\u2019autorisez), '
          'l\u2019appli a besoin de l\u2019accès à tous les fichiers.\n\n'
          'Sur l\u2019écran suivant, activez l\u2019option pour LocalShare.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Plus tard')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Continuer')),
        ],
      ),
    );
    if (ok == true) {
      await StorageService.ensureAccess();
      await StorageService.shareDir();
    }
  }

  void _onChange() {
    if (!mounted) return;

    // Connexion entrante à valider (hors QR code).
    final pc = n.pending;
    if (pc != null && !_pendingDialogOpen) {
      _pendingDialogOpen = true;
      showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (_) => AlertDialog(
          icon: const Icon(Icons.link, size: 36),
          title: const Text('Demande de connexion'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            Text('« ${pc.name} » veut se connecter à votre appareil.'),
            const SizedBox(height: 16),
            Text(pc.code,
                style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold, letterSpacing: 6)),
            const SizedBox(height: 8),
            const Text('Vérifiez que le même code s\u2019affiche sur l\u2019autre appareil.',
                textAlign: TextAlign.center),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Refuser')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Accepter')),
          ],
        ),
      ).then((ok) {
        _pendingDialogOpen = false;
        if (ok == true) {
          n.acceptPending();
        } else {
          n.rejectPending();
        }
      });
    }

    // Connecté : ferme feuilles/dialogues et ouvre l'écran de transfert.
    if (n.isConnected && !_transferOpen) {
      _transferOpen = true;
      Navigator.of(context).popUntil((r) => r.isFirst);
      Navigator.of(context)
          .push(MaterialPageRoute(
            builder: (_) => TransferScreen(
              nearby: n,
              files: widget.files,
              screen: widget.screen,
              remote: widget.remote,
            ),
          ))
          .then((_) {
        _transferOpen = false;
        if (n.isConnected) n.disconnect();
      });
    }
  }

  @override
  void dispose() {
    n.removeListener(_onChange);
    super.dispose();
  }

  Future<void> _goVisible() async {
    await n.startAdvertising();
    if (n.isAdvertising && mounted) _showQr();
  }

  void _showQr() {
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (_) => QrSheet(nearby: n),
    );
  }

  Future<void> _scanQr() async {
    final raw = await Navigator.of(context).push<String>(
      MaterialPageRoute(builder: (_) => const ScanQrScreen()),
    );
    if (raw == null) return;
    final payload = QrPayload.parse(raw);
    if (payload != null) await n.connectByQr(payload);
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: const Text('LocalShare'),
        centerTitle: true,
        actions: [
          IconButton(
            tooltip: 'Fichiers reçus (${StorageService.folderName})',
            icon: const Icon(Icons.folder_special_outlined),
            onPressed: () => Navigator.of(context)
                .push(MaterialPageRoute(builder: (_) => const ReceivedScreen())),
          ),
        ],
      ),
      body: ListenableBuilder(
        listenable: n,
        builder: (context, _) {
          final active = n.isAdvertising || n.isDiscovering;
          final discoverable = n.peers.where((p) => p.state == PeerState.discovered).toList();
          return Column(
            children: [
              if (!NearbyService.supported)
                Container(
                  width: double.infinity,
                  margin: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: cs.errorContainer,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    'Nearby Connections est Android uniquement. Sur iOS, voir le README.',
                    style: TextStyle(color: cs.onErrorContainer),
                  ),
                ),
              // ----- Radar
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                  child: RadarView(
                    peers: n.peers,
                    active: active,
                    onPeerTap: n.connectTo,
                  ),
                ),
              ),
              // ----- État
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 200),
                  child: Text(
                    n.status ??
                        (n.outgoingCode != null
                            ? 'Code de vérification : ${n.outgoingCode}'
                            : n.isDiscovering
                                ? 'Recherche d\u2019appareils à proximité…'
                                : n.isAdvertising
                                    ? 'Visible comme « ${n.deviceName} »'
                                    : 'Radar en veille'),
                    key: ValueKey(n.status ?? n.outgoingCode ?? '${n.isDiscovering}${n.isAdvertising}'),
                    textAlign: TextAlign.center,
                    style: TextStyle(color: n.status != null ? cs.error : cs.outline),
                  ),
                ),
              ),
              if (discoverable.isNotEmpty)
                SizedBox(
                  height: 48,
                  child: ListView.separated(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                    scrollDirection: Axis.horizontal,
                    itemCount: discoverable.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 8),
                    itemBuilder: (_, i) => ActionChip(
                      avatar: const Icon(Icons.smartphone, size: 18),
                      label: Text(discoverable[i].name),
                      onPressed: () => n.connectTo(discoverable[i]),
                    ),
                  ),
                ),
              // ----- Actions
              Padding(
                padding: const EdgeInsets.all(16),
                child: Row(children: [
                  Expanded(
                    child: _ActionTile(
                      icon: n.isAdvertising ? Icons.visibility : Icons.visibility_outlined,
                      label: n.isAdvertising ? 'Visible' : 'Être visible',
                      selected: n.isAdvertising,
                      onTap: n.isAdvertising ? _showQr : _goVisible,
                      onLongPress: n.isAdvertising ? n.stopAdvertising : null,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _ActionTile(
                      icon: Icons.radar,
                      label: n.isDiscovering ? 'Arrêter' : 'Radar',
                      selected: n.isDiscovering,
                      onTap: n.isDiscovering ? n.stopDiscovery : n.startDiscovery,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _ActionTile(
                      icon: Icons.qr_code_scanner,
                      label: 'Scanner QR',
                      onTap: _scanQr,
                    ),
                  ),
                ]),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _ActionTile extends StatelessWidget {
  const _ActionTile({
    required this.icon,
    required this.label,
    required this.onTap,
    this.onLongPress,
    this.selected = false,
  });
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final VoidCallback? onLongPress;
  final bool selected;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Material(
      color: selected ? cs.primaryContainer : cs.surfaceContainerHigh,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        onLongPress: onLongPress,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 14),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(icon, color: selected ? cs.onPrimaryContainer : cs.primary),
            const SizedBox(height: 6),
            Text(label,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: selected ? cs.onPrimaryContainer : null,
                )),
          ]),
        ),
      ),
    );
  }
}
