import 'package:flutter/material.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import '../services/file_transfer_service.dart';
import '../services/nearby_service.dart';
import '../services/remote_fs_service.dart';
import '../services/screen_share_service.dart';
import '../services/storage_service.dart';
import '../utils/file_utils.dart';
import 'file_viewer_screen.dart';
import 'received_screen.dart';
import 'remote_browser_screen.dart';

class TransferScreen extends StatefulWidget {
  const TransferScreen({
    super.key,
    required this.nearby,
    required this.files,
    required this.screen,
    required this.remote,
  });
  final NearbyService nearby;
  final FileTransferService files;
  final ScreenShareService screen;
  final RemoteFsService remote;

  @override
  State<TransferScreen> createState() => _TransferScreenState();
}

class _TransferScreenState extends State<TransferScreen> {
  bool _askOpen = false;
  late final String _peerName = widget.nearby.connectedName;

  @override
  void initState() {
    super.initState();
    widget.screen.init();
    widget.nearby.addListener(_watchConnection);
    widget.remote.addListener(_onRemote);
  }

  /// Retour automatique à l'accueil si l'autre appareil se déconnecte.
  void _watchConnection() {
    if (!widget.nearby.isConnected && mounted) Navigator.of(context).maybePop();
  }

  /// L'autre appareil demande à parcourir mes fichiers : consentement explicite.
  void _onRemote() {
    if (!widget.remote.pendingRequest || _askOpen || !mounted) return;
    _askOpen = true;
    showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        icon: const Icon(Icons.folder_shared_outlined, size: 36),
        title: const Text('Accès à vos fichiers'),
        content: Text(
          '« $_peerName » demande à parcourir et télécharger les fichiers de votre téléphone '
          '(stockage interne).\n\nVous pourrez révoquer l\u2019accès à tout moment.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Refuser')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Autoriser')),
        ],
      ),
    ).then((ok) async {
      _askOpen = false;
      if (ok == true) await StorageService.ensureAccess();
      widget.remote.respond(ok == true && await StorageService.hasAccess());
    });
  }

  Future<void> _confirmShare() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        icon: const Icon(Icons.phonelink_ring, size: 36),
        title: const Text('Partager mon téléphone'),
        content: Text(
          '« $_peerName » verra en direct TOUT ce qui s\u2019affiche sur votre écran '
          '(messages, notifications, mots de passe saisis…), même si vous quittez l\u2019appli.\n\n'
          'Le partage continue en arrière-plan jusqu\u2019à ce que vous appuyiez sur « Arrêter ».\n\n'
          'Les deux téléphones doivent être sur le même Wi-Fi (ou le point d\u2019accès de l\u2019un d\u2019eux).',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Partager')),
        ],
      ),
    );
    if (ok == true) await widget.screen.startSharing();
  }

  @override
  void dispose() {
    widget.nearby.removeListener(_watchConnection);
    widget.remote.removeListener(_onRemote);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final n = widget.nearby, files = widget.files, screen = widget.screen, remote = widget.remote;

    return ListenableBuilder(
      listenable: Listenable.merge([n, files, screen, remote]),
      builder: (context, _) => PopScope(
        // Pendant un partage, « retour » met l'appli en arrière-plan au lieu de couper.
        canPop: !screen.isSharing,
        onPopInvokedWithResult: (didPop, _) {
          if (!didPop) FlutterForegroundTask.minimizeApp();
        },
        child: Scaffold(
          appBar: AppBar(
            title: Text('Connecté à $_peerName'),
            actions: [
              IconButton(
                tooltip: 'Se déconnecter',
                icon: const Icon(Icons.link_off),
                onPressed: () async {
                  if (screen.isSharing) await screen.stopSharing();
                  await n.disconnect();
                },
              ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              // ----- Bannières d'état
              if (screen.isSharing)
                _Banner(
                  color: cs.errorContainer,
                  onColor: cs.onErrorContainer,
                  icon: Icons.fiber_manual_record,
                  text: 'Votre téléphone est partagé en direct. Le partage continue en arrière-plan.',
                ),
              if (remote.accessGranted)
                _Banner(
                  color: cs.tertiaryContainer,
                  onColor: cs.onTertiaryContainer,
                  icon: Icons.folder_shared,
                  text: '« $_peerName » a accès à vos fichiers.',
                  action: TextButton(onPressed: remote.revoke, child: const Text('Révoquer')),
                ),

              // ----- Actions principales
              Row(children: [
                Expanded(
                  child: _BigAction(
                    icon: Icons.upload_file,
                    title: 'Envoyer',
                    subtitle: 'Des fichiers',
                    onTap: files.pickAndSend,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _BigAction(
                    icon: Icons.folder_shared_outlined,
                    title: 'Ses fichiers',
                    subtitle: 'Parcourir son téléphone',
                    onTap: () => Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) => RemoteBrowserScreen(remote: remote, peerName: _peerName),
                    )),
                  ),
                ),
              ]),
              const SizedBox(height: 12),
              FilledButton.icon(
                style: FilledButton.styleFrom(
                  minimumSize: const Size.fromHeight(56),
                  backgroundColor: screen.isSharing ? cs.error : null,
                  foregroundColor: screen.isSharing ? cs.onError : null,
                ),
                onPressed: screen.isSharing ? screen.stopSharing : _confirmShare,
                icon: Icon(screen.isSharing ? Icons.stop_circle_outlined : Icons.phonelink_ring),
                label: Text(screen.isSharing ? 'Arrêter le partage' : 'Partager mon téléphone'),
              ),

              // ----- Écran de l'autre appareil
              if (screen.isViewing) ...[
                const SizedBox(height: 20),
                Row(children: [
                  Expanded(
                    child: Text('Écran de $_peerName',
                        style: const TextStyle(fontWeight: FontWeight.w600)),
                  ),
                  IconButton(
                    tooltip: 'Plein écran',
                    icon: const Icon(Icons.fullscreen),
                    onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) => _FullScreenView(screen: screen),
                    )),
                  ),
                ]),
                ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: SizedBox(
                    height: 380,
                    child: ColoredBox(
                      color: Colors.black,
                      child: RTCVideoView(
                        screen.remoteRenderer,
                        objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitContain,
                      ),
                    ),
                  ),
                ),
              ],

              // ----- Transferts
              Padding(
                padding: const EdgeInsets.only(top: 24, bottom: 8),
                child: Row(children: [
                  const Expanded(
                    child: Text('Transferts', style: TextStyle(fontWeight: FontWeight.w600)),
                  ),
                  TextButton.icon(
                    onPressed: () => Navigator.of(context)
                        .push(MaterialPageRoute(builder: (_) => const ReceivedScreen())),
                    icon: const Icon(Icons.folder_special_outlined, size: 18),
                    label: const Text(StorageService.folderName),
                  ),
                ]),
              ),
              if (files.items.isEmpty)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 32),
                  child: Center(child: Text('Aucun transfert', style: TextStyle(color: cs.outline))),
                ),
              for (final t in files.items) _TransferTile(item: t),
            ],
          ),
        ),
      ),
    );
  }
}

class _Banner extends StatelessWidget {
  const _Banner({
    required this.color,
    required this.onColor,
    required this.icon,
    required this.text,
    this.action,
  });
  final Color color, onColor;
  final IconData icon;
  final String text;
  final Widget? action;

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.fromLTRB(14, 10, 8, 10),
        decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(14)),
        child: Row(children: [
          Icon(icon, color: onColor, size: 18),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: TextStyle(color: onColor, fontSize: 13))),
          if (action != null) action!,
        ]),
      );
}

class _BigAction extends StatelessWidget {
  const _BigAction({required this.icon, required this.title, required this.subtitle, required this.onTap});
  final IconData icon;
  final String title, subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Material(
      color: cs.surfaceContainerHigh,
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(icon, size: 28, color: cs.primary),
            const SizedBox(height: 10),
            Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
            Text(subtitle, style: TextStyle(color: cs.outline, fontSize: 12)),
          ]),
        ),
      ),
    );
  }
}

class _TransferTile extends StatelessWidget {
  const _TransferTile({required this.item});
  final TransferItem item;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final t = item;
    final inProgress = t.status == TransferStatus.inProgress;
    final canOpen = !t.outgoing && t.savedPath != null && t.status == TransferStatus.done;
    return Card(
      elevation: 0,
      color: cs.surfaceContainerHigh,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: canOpen ? () => openInApp(context, t.savedPath!) : null,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Icon(t.outgoing ? Icons.arrow_upward : Icons.arrow_downward, size: 18, color: cs.primary),
              const SizedBox(width: 8),
              Expanded(child: Text(t.name, overflow: TextOverflow.ellipsis)),
              if (canOpen) Icon(Icons.visibility_outlined, size: 20, color: cs.primary),
              if (t.status == TransferStatus.done && !canOpen)
                const Icon(Icons.check_circle, color: Colors.green, size: 20),
              if (t.status == TransferStatus.failed) Icon(Icons.error, color: cs.error, size: 20),
            ]),
            const SizedBox(height: 10),
            LinearProgressIndicator(
              value: inProgress ? t.progress : 1,
              borderRadius: BorderRadius.circular(4),
            ),
            const SizedBox(height: 6),
            Text(
              '${formatBytes(t.transferred)} / ${formatBytes(t.total)}'
              '${inProgress ? "  •  ${(t.progress * 100).toStringAsFixed(0)} %" : ""}'
              '${canOpen ? "  •  Touchez pour ouvrir" : ""}',
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ]),
        ),
      ),
    );
  }
}

class _FullScreenView extends StatelessWidget {
  const _FullScreenView({required this.screen});
  final ScreenShareService screen;

  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: screen,
        builder: (context, _) {
          if (!screen.isViewing) {
            WidgetsBinding.instance.addPostFrameCallback((_) {
              if (context.mounted && Navigator.of(context).canPop()) Navigator.of(context).pop();
            });
          }
          return Scaffold(
            backgroundColor: Colors.black,
            appBar: AppBar(
              backgroundColor: Colors.black,
              foregroundColor: Colors.white,
              title: const Text('Écran distant'),
            ),
            body: InteractiveViewer(
              maxScale: 5,
              child: RTCVideoView(
                screen.remoteRenderer,
                objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitContain,
              ),
            ),
          );
        },
      );
}
