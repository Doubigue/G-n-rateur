@file:OptIn(ExperimentalMaterial3Api::class)

package com.moncoffre.app.ui

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.moncoffre.app.VaultViewModel
import com.moncoffre.app.data.BackupCrypto
import com.moncoffre.app.data.accountsFromJson
import com.moncoffre.app.data.accountsToJson
import com.moncoffre.app.data.hasContactsPermission
import com.moncoffre.app.pdf.PdfExporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ------------------------------------------------------------------
// Contacts : lus automatiquement depuis le téléphone
// ------------------------------------------------------------------

@Composable
fun ContactsScreen(vm: VaultViewModel, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var granted by remember { mutableStateOf(hasContactsPermission(context)) }
    var query by rememberSaveable { mutableStateOf("") }
    val permission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted = it }

    LaunchedEffect(Unit) {
        if (!granted) permission.launch(Manifest.permission.READ_CONTACTS)
    }
    LaunchedEffect(granted) {
        if (granted) vm.loadContacts()
    }

    if (!granted) {
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Text("Accès aux contacts", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Text(
                text = "Autorisez MonCoffre à lire vos contacts pour les afficher ici et les inclure dans le PDF. Ils ne quittent pas le téléphone.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(20.dp))
            Button(onClick = { permission.launch(Manifest.permission.READ_CONTACTS) }) {
                Text("Autoriser")
            }
            TextButton(onClick = {
                context.startActivity(
                    Intent(
                        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.fromParts("package", context.packageName, null),
                    )
                )
            }) { Text("Ouvrir les paramètres de l'appli") }
        }
        return
    }

    val shown = if (query.isBlank()) vm.contacts else vm.contacts.filter { c ->
        c.name.contains(query, true) || c.numbers.any { it.contains(query) }
    }
    Column(modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            placeholder = { Text("Rechercher parmi ${vm.contacts.size} contacts") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            singleLine = true,
            shape = RoundedCornerShape(28.dp),
        )
        if (!vm.contactsLoaded) {
            LinearProgressIndicator(
                modifier =
                Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            )
        }
        LazyColumn(contentPadding = PaddingValues(vertical = 8.dp)) {
            items(shown) { contact ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { copyToClipboard(context, contact.numbers.firstOrNull().orEmpty()) }
                        .padding(horizontal = 20.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    ServiceBadge(contact.name.ifBlank { "?" }, size = 38.dp)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            text = contact.name,
                            style = MaterialTheme.typography.bodyLarge,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            text = contact.numbers.joinToString("  ·  "),
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = FontFamily.Monospace,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------
// Export PDF + sauvegarde chiffrée
// ------------------------------------------------------------------

@Composable
fun ExportScreen(vm: VaultViewModel, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val contactsAllowed = remember { hasContactsPermission(context) }
    val day = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }

    var includeSecrets by rememberSaveable { mutableStateOf(true) }
    var includeContacts by rememberSaveable { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }
    var confirmPdf by remember { mutableStateOf(false) }
    var askExportPassword by remember { mutableStateOf(false) }
    var backupPassword by remember { mutableStateOf("") }
    var importUri by remember { mutableStateOf<Uri?>(null) }

    LaunchedEffect(contactsAllowed) {
        if (contactsAllowed && !vm.contactsLoaded) vm.loadContacts()
    }

    val pdfSaver = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        if (uri != null) {
            val accounts = vm.accounts
            val contacts = if (includeContacts && contactsAllowed) vm.contacts else emptyList()
            val secrets = includeSecrets
            busy = true
            scope.launch {
                val ok = withContext(Dispatchers.IO) {
                    runCatching {
                        context.contentResolver.openOutputStream(uri)!!.use { out ->
                            PdfExporter().export(out, accounts, contacts, secrets)
                        }
                    }.isSuccess
                }
                busy = false
                toast(context, if (ok) "PDF enregistré" else "Échec de la création du PDF")
            }
        }
    }

    val backupSaver = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri ->
        val password = backupPassword
        backupPassword = ""
        if (uri != null && password.isNotEmpty()) {
            val json = accountsToJson(vm.accounts)
            busy = true
            scope.launch {
                val ok = withContext(Dispatchers.IO) {
                    runCatching {
                        val data = BackupCrypto.encrypt(json, password)
                        context.contentResolver.openOutputStream(uri)!!.use { it.write(data) }
                    }.isSuccess
                }
                busy = false
                toast(context, if (ok) "Sauvegarde enregistrée" else "Échec de la sauvegarde")
            }
        }
    }

    val backupPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> importUri = uri }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
    ) {
        if (busy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())

        SectionCard("Document PDF") {
            Text(
                text = "Un PDF mis en page avec tous vos comptes : identifiants, mots de passe, méthodes de récupération et codes de secours.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            SwitchRow(
                label = "Inclure mots de passe et codes",
                checked = includeSecrets,
                onChange = { includeSecrets = it },
            )
            SwitchRow(
                label = if (contactsAllowed) "Inclure les contacts (${vm.contacts.size})"
                else "Inclure les contacts — ouvrez d'abord l'onglet Contacts",
                checked = includeContacts && contactsAllowed,
                enabled = contactsAllowed,
                onChange = { includeContacts = it },
            )
            Button(
                enabled = !busy && (vm.accounts.isNotEmpty() || vm.contacts.isNotEmpty()),
                onClick = {
                    if (includeSecrets) confirmPdf = true else pdfSaver.launch("MonCoffre_$day.pdf")
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Télécharger le PDF") }
        }

        SectionCard("Sauvegarde chiffrée") {
            Text(
                text = "Le coffre n'existe que sur ce téléphone. Gardez une sauvegarde protégée par mot de passe pour le retrouver après un changement de téléphone ou une réinstallation.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    enabled = !busy && vm.accounts.isNotEmpty(),
                    onClick = { askExportPassword = true },
                ) { Text("Sauvegarder") }
                OutlinedButton(
                    enabled = !busy,
                    onClick = { backupPicker.launch(arrayOf("*/*")) },
                ) { Text("Restaurer") }
            }
        }
        Spacer(Modifier.height(24.dp))
    }

    if (confirmPdf) {
        AlertDialog(
            onDismissRequest = { confirmPdf = false },
            title = { Text("PDF non chiffré") },
            text = {
                Text("Ce PDF contiendra vos mots de passe en clair : toute personne qui l'ouvre peut les lire. Enregistrez-le dans un endroit sûr et ne l'envoyez pas par messagerie.")
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmPdf = false
                    pdfSaver.launch("MonCoffre_$day.pdf")
                }) { Text("Créer le PDF") }
            },
            dismissButton = {
                TextButton(onClick = { confirmPdf = false }) { Text("Annuler") }
            },
        )
    }

    if (askExportPassword) {
        PasswordDialog(
            title = "Mot de passe de la sauvegarde",
            message = "Il sera demandé pour restaurer. S'il est oublié, la sauvegarde est irrécupérable.",
            confirmLabel = "Continuer",
            minLength = 6,
            onDismiss = { askExportPassword = false },
            onConfirm = { password ->
                askExportPassword = false
                backupPassword = password
                backupSaver.launch("MonCoffre_$day.mcoffre")
            },
        )
    }

    importUri?.let { uri ->
        PasswordDialog(
            title = "Restaurer la sauvegarde",
            message = "Saisissez le mot de passe choisi lors de la sauvegarde. Les comptes seront ajoutés à ceux déjà présents.",
            confirmLabel = "Restaurer",
            minLength = 1,
            onDismiss = { importUri = null },
            onConfirm = { password ->
                importUri = null
                busy = true
                scope.launch {
                    val imported = withContext(Dispatchers.IO) {
                        runCatching {
                            val data = context.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                            accountsFromJson(BackupCrypto.decrypt(data, password))
                        }.getOrNull()
                    }
                    busy = false
                    if (imported == null) {
                        toast(context, "Mot de passe incorrect ou fichier invalide")
                    } else {
                        toast(context, "${vm.importAccounts(imported)} compte(s) restauré(s)")
                    }
                }
            },
        )
    }
}

@Composable
private fun SwitchRow(
    label: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit,
    enabled: Boolean = true,
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            text = label,
            modifier = Modifier.weight(1f),
            color = if (enabled) MaterialTheme.colorScheme.onSurface
            else MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}

@Composable
private fun PasswordDialog(
    title: String,
    message: String,
    confirmLabel: String,
    minLength: Int,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit,
) {
    var password by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(message)
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text(if (minLength > 1) "Mot de passe ($minLength caractères min.)" else "Mot de passe") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            TextButton(enabled = password.length >= minLength, onClick = { onConfirm(password) }) {
                Text(confirmLabel)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Annuler") }
        },
    )
}
