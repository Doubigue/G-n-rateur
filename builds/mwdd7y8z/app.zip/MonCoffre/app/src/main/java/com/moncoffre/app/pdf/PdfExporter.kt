package com.moncoffre.app.pdf

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.TextPaint
import android.text.TextUtils
import com.moncoffre.app.data.Account
import com.moncoffre.app.data.PhoneContact
import com.moncoffre.app.data.Services
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/**
 * Génère le PDF (A4) de tous les comptes et, au choix, des contacts.
 * Utiliser une instance par export.
 */
class PdfExporter {

    private val pageW = 595
    private val pageH = 842
    private val margin = 40f
    private val contentW = pageW - 2 * margin
    private val bottom = pageH - 56f
    private val labelW = 150f
    private val lineH = 14.5f

    private val ink = Color.rgb(22, 24, 29)
    private val grey = Color.rgb(108, 115, 128)
    private val hairline = Color.rgb(228, 231, 236)
    private val gold = Color.rgb(176, 130, 22)
    private val goldLight = Color.rgb(226, 184, 87)

    private val sansBold = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
    private val monoBold = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)

    private fun textPaint(size: Float, color: Int, face: Typeface = Typeface.SANS_SERIF): TextPaint {
        val p = TextPaint(Paint.ANTI_ALIAS_FLAG)
        p.textSize = size
        p.color = color
        p.typeface = face
        return p
    }

    private val pLabel = textPaint(8.5f, grey)
    private val pValue = textPaint(10.5f, ink)
    private val pMono = textPaint(10.5f, ink, monoBold)
    private val pMonoUsed = textPaint(10.5f, Color.rgb(165, 170, 180), Typeface.MONOSPACE).apply {
        isStrikeThruText = true
    }
    private val pTitle = textPaint(12.5f, ink, sansBold)
    private val pService = textPaint(8f, grey, sansBold).apply {
        textAlign = Paint.Align.RIGHT
        letterSpacing = 0.08f
    }
    private val pBadge = textPaint(11f, Color.WHITE, sansBold).apply { textAlign = Paint.Align.CENTER }
    private val pSection = textPaint(10f, gold, sansBold).apply { letterSpacing = 0.14f }
    private val pFooter = textPaint(8f, grey)
    private val pFooterRight = textPaint(8f, grey).apply { textAlign = Paint.Align.RIGHT }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)

    private val doc = PdfDocument()
    private var page: PdfDocument.Page? = null
    private lateinit var canvas: Canvas
    private var pageNo = 0
    private var y = 0f
    private var stamp = ""

    fun export(
        out: OutputStream,
        accounts: List<Account>,
        contacts: List<PhoneContact>,
        includeSecrets: Boolean,
    ) {
        stamp = SimpleDateFormat("dd/MM/yyyy 'à' HH:mm", Locale.FRANCE).format(Date())
        try {
            newPage()
            cover(accounts.size, contacts.size, includeSecrets)

            if (accounts.isNotEmpty()) {
                section("Comptes (${accounts.size})")
                accounts.forEach { drawAccount(it, includeSecrets) }
            }
            if (contacts.isNotEmpty()) {
                y += 8f
                section("Contacts du téléphone (${contacts.size})")
                drawContacts(contacts)
            }
            finishPage()
            doc.writeTo(out)
        } finally {
            doc.close()
        }
    }

    // ---------- Pages ----------

    private fun newPage() {
        finishPage()
        pageNo++
        val p = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create())
        page = p
        canvas = p.canvas
        if (pageNo > 1) {
            fill.color = goldLight
            canvas.drawRect(margin, 30f, margin + 28f, 32.5f, fill)
        }
        y = 46f
    }

    private fun finishPage() {
        val p = page ?: return
        fill.color = hairline
        canvas.drawRect(margin, pageH - 40f, margin + contentW, pageH - 39.2f, fill)
        canvas.drawText("Confidentiel · MonCoffre · exporté le $stamp", margin, pageH - 26f, pFooter)
        canvas.drawText("Page $pageNo", margin + contentW, pageH - 26f, pFooterRight)
        doc.finishPage(p)
        page = null
    }

    /** Passe à la page suivante s'il ne reste pas [height] points. */
    private fun ensure(height: Float) {
        if (y + height > bottom) newPage()
    }

    // ---------- Blocs ----------

    private fun cover(accountCount: Int, contactCount: Int, includeSecrets: Boolean) {
        fill.color = Color.rgb(14, 16, 20)
        canvas.drawRect(0f, 0f, pageW.toFloat(), 136f, fill)
        fill.color = goldLight
        canvas.drawRect(margin, 36f, margin + 28f, 39f, fill)

        val brand = textPaint(9.5f, goldLight, sansBold).apply { letterSpacing = 0.22f }
        canvas.drawText("MONCOFFRE", margin, 60f, brand)
        canvas.drawText("Comptes & mots de passe", margin, 91f, textPaint(24f, Color.WHITE, sansBold))
        val summary = buildString {
            append("Exporté le $stamp  ·  $accountCount compte(s)")
            if (contactCount > 0) append("  ·  $contactCount contact(s)")
        }
        canvas.drawText(summary, margin, 113f, textPaint(9.5f, Color.rgb(170, 177, 190)))

        y = 136f + 18f
        fill.color = Color.rgb(255, 246, 221)
        canvas.drawRoundRect(RectF(margin, y, margin + contentW, y + 30f), 6f, 6f, fill)
        val warning = if (includeSecrets) {
            "Document confidentiel : il contient vos mots de passe en clair. Ne le partagez pas."
        } else {
            "Mots de passe et codes masqués dans cet export."
        }
        canvas.drawText(warning, margin + 12f, y + 19f, textPaint(9f, Color.rgb(120, 84, 0), sansBold))
        y += 30f + 22f
    }

    private fun section(title: String) {
        ensure(70f)
        canvas.drawText(title.uppercase(Locale.FRANCE), margin, y + 10f, pSection)
        fill.color = hairline
        canvas.drawRect(margin, y + 17f, margin + contentW, y + 17.8f, fill)
        y += 30f
    }

    private fun drawAccount(a: Account, includeSecrets: Boolean) {
        ensure(34f + 8f + lineH * 2)
        val color = Services.color(a.service)
        fill.color = Color.rgb(244, 245, 248)
        canvas.drawRoundRect(RectF(margin, y, margin + contentW, y + 34f), 8f, 8f, fill)
        fill.color = color
        canvas.drawRoundRect(RectF(margin + 7f, y + 6f, margin + 29f, y + 28f), 6f, 6f, fill)
        canvas.drawText(Services.initial(a.service), margin + 18f, y + 21f, pBadge)

        val service = a.service.uppercase(Locale.FRANCE)
        pService.color = color
        canvas.drawText(service, margin + contentW - 10f, y + 20.5f, pService)
        val titleWidth = contentW - 38f - pService.measureText(service) - 26f
        val title = TextUtils.ellipsize(a.displayName, pTitle, titleWidth, TextUtils.TruncateAt.END)
        canvas.drawText(title.toString(), margin + 38f, y + 21.5f, pTitle)
        y += 34f + 10f

        val hidden = "••••••••"
        row("Identifiant", a.login)
        row("Mot de passe", if (includeSecrets || a.password.isEmpty()) a.password else hidden, mono = true)
        row("Numéro de récupération", a.recoveryPhone)
        row("E-mail de récupération", a.recoveryEmail)
        a.fields.filter { it.value.isNotBlank() }.forEach { f ->
            val shown = if (f.secret && !includeSecrets) hidden else f.value
            row(f.label.ifBlank { "Autre" }, shown, mono = f.secret)
        }
        drawCodes(a, includeSecrets)
        row("Notes", a.notes)
        y += 14f
    }

    /** Ligne intitulé / valeur, avec retour à la ligne et saut de page automatiques. */
    private fun row(label: String, value: String, mono: Boolean = false) {
        if (value.isBlank()) return
        val paint = if (mono) pMono else pValue
        val labelLines = wrap(label, pLabel, labelW - 16f)
        val valueLines = wrap(value, paint, contentW - labelW - 8f)
        for (i in 0 until max(labelLines.size, valueLines.size)) {
            ensure(lineH)
            if (i < labelLines.size) canvas.drawText(labelLines[i], margin + 8f, y + 10.5f, pLabel)
            if (i < valueLines.size) canvas.drawText(valueLines[i], margin + labelW, y + 10.5f, paint)
            y += lineH
        }
        separator()
    }

    private fun drawCodes(a: Account, includeSecrets: Boolean) {
        if (a.backupCodes.isEmpty()) return
        val remaining = a.backupCodes.count { !it.used }
        if (!includeSecrets) {
            row("Codes de secours", "$remaining restant(s) sur ${a.backupCodes.size} (masqués)")
            return
        }
        val areaW = contentW - labelW - 8f
        val widest = a.backupCodes.maxOf { pMono.measureText(it.code) }
        val columns = max(1, min(4, (areaW / (widest + 18f)).toInt()))
        val columnW = areaW / columns
        val grid = a.backupCodes.chunked(columns)
        val labelLines = wrap("Codes de secours ($remaining restant(s) sur ${a.backupCodes.size})", pLabel, labelW - 16f)
        val rowH = 16f
        for (i in 0 until max(labelLines.size, grid.size)) {
            ensure(rowH)
            if (i < labelLines.size) canvas.drawText(labelLines[i], margin + 8f, y + 11f, pLabel)
            if (i < grid.size) {
                grid[i].forEachIndexed { col, code ->
                    canvas.drawText(
                        code.code,
                        margin + labelW + col * columnW,
                        y + 11f,
                        if (code.used) pMonoUsed else pMono,
                    )
                }
            }
            y += rowH
        }
        separator()
    }

    private fun separator() {
        y += 3f
        fill.color = hairline
        canvas.drawRect(margin + 8f, y, margin + contentW - 8f, y + 0.6f, fill)
        y += 6f
    }

    private fun drawContacts(list: List<PhoneContact>) {
        val nameW = 210f
        val pName = textPaint(10f, ink, sansBold)
        val pNumber = textPaint(10f, ink, Typeface.MONOSPACE)
        list.forEachIndexed { index, contact ->
            val numbers = wrap(contact.numbers.joinToString("   ·   "), pNumber, contentW - nameW - 16f)
            val height = max(1, numbers.size) * lineH + 7f
            ensure(height)
            if (index % 2 == 0) {
                fill.color = Color.rgb(246, 247, 249)
                canvas.drawRoundRect(RectF(margin, y, margin + contentW, y + height), 4f, 4f, fill)
            }
            val name = TextUtils.ellipsize(contact.name, pName, nameW - 16f, TextUtils.TruncateAt.END)
            canvas.drawText(name.toString(), margin + 8f, y + 13.5f, pName)
            numbers.forEachIndexed { i, line ->
                canvas.drawText(line, margin + nameW, y + 13.5f + i * lineH, pNumber)
            }
            y += height
        }
    }

    // ---------- Texte ----------

    private fun wrap(text: String, paint: TextPaint, width: Float): List<String> {
        val lines = ArrayList<String>()
        text.trim().split('\n').forEach { paragraph ->
            var rest = paragraph.trim()
            if (rest.isEmpty()) {
                lines.add("")
                return@forEach
            }
            while (rest.isNotEmpty()) {
                var count = paint.breakText(rest, true, width, null)
                if (count <= 0) count = 1
                if (count < rest.length) {
                    val space = rest.lastIndexOf(' ', count)
                    if (space > 0) count = space
                }
                lines.add(rest.substring(0, count).trimEnd())
                rest = rest.substring(count).trimStart()
            }
        }
        return lines
    }
}
