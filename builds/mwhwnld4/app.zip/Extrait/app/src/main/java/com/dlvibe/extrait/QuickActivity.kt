package com.dlvibe.extrait

import android.app.Application
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Color as AColor
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.IntentCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.dlvibe.extrait.ui.Beam
import com.dlvibe.extrait.ui.Cobalt
import com.dlvibe.extrait.ui.ExtraitTheme
import com.dlvibe.extrait.ui.Ink
import com.dlvibe.extrait.ui.Line
import com.dlvibe.extrait.ui.Muted
import com.dlvibe.extrait.ui.Page
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** État de la petite fenêtre : choix, travail en cours, résultat. */
class QuickViewModel(private val app: Application) : AndroidViewModel(app) {
    sealed interface Phase {
        data object Choose : Phase
        data class Working(val label: String, val done: Int, val total: Int) : Phase
        data class Extracted(val text: String) : Phase
        data class Made(val file: File, val pages: Int) : Phase
        data class Fail(val message: String) : Phase
    }

    var uris by mutableStateOf<List<Uri>>(emptyList())
        private set
    var phase by mutableStateOf<Phase>(Phase.Choose)
        private set
    var note by mutableStateOf<String?>(null)

    private var job: Job? = null

    fun load(list: List<Uri>, mode: String?) {
        job?.cancel()
        uris = list
        phase = Phase.Choose
        note = null
        when (mode) {
            QuickActivity.MODE_OCR -> runOcr()
            QuickActivity.MODE_PDF -> runPdf()
        }
    }

    fun cancel() {
        job?.cancel()
        phase = Phase.Choose
    }

    fun runOcr() {
        val list = uris
        if (list.isEmpty()) return
        job?.cancel()
        note = null
        phase = Phase.Working("Lecture du texte…", 0, list.size)
        job = viewModelScope.launch {
            val parts = ArrayList<Pair<String, String>>()
            var failed = 0
            list.forEachIndexed { i, uri ->
                val name = withContext(Dispatchers.IO) { Ocr.displayName(app, uri) } ?: "Image ${i + 1}"
                val text = try {
                    withContext(Dispatchers.Default) { Ocr.read(app, uri).text }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    failed++
                    ""
                }
                parts.add(name to text)
                phase = Phase.Working("Lecture du texte…", i + 1, list.size)
            }
            if (failed == list.size) {
                phase = Phase.Fail("Lecture impossible")
                return@launch
            }
            val all = if (parts.size == 1) parts[0].second else parts.withIndex().joinToString("\n\n") { (i, p) ->
                "━━ ${i + 1}. ${p.first} ━━\n\n" + p.second.ifBlank { "(aucun texte détecté)" }
            }
            phase = Phase.Extracted(all)
        }
    }

    fun runPdf() {
        val list = uris
        if (list.isEmpty()) return
        job?.cancel()
        note = null
        phase = Phase.Working("Création du PDF…", 0, 0)
        job = viewModelScope.launch {
            try {
                val (file, pages) = withContext(Dispatchers.IO) { Export.imagesToPdf(app, list) }
                phase = Phase.Made(file, pages)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                phase = Phase.Fail("Création du PDF impossible")
            }
        }
    }

    fun save(file: File, dest: Uri) {
        viewModelScope.launch {
            note = try {
                withContext(Dispatchers.IO) { Export.copyTo(app, file, dest) }
                "PDF enregistré ✓"
            } catch (e: Throwable) {
                "Enregistrement impossible"
            }
        }
    }
}

/**
 * Petite fenêtre transparente avec deux actions : « Extraire le texte » (OCR) et « Numériser en PDF ».
 * Ouverte depuis le menu Partager de la galerie / de l'explorateur, depuis « Ouvrir avec »,
 * ou depuis la proposition qui suit une capture d'écran.
 */
class QuickActivity : ComponentActivity() {
    private val vm: QuickViewModel by viewModels()

    private val saveLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { dest ->
        val made = vm.phase as? QuickViewModel.Phase.Made
        if (dest != null && made != null) vm.save(made.file, dest)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT)
        )
        if (savedInstanceState == null && !accept(intent)) {
            finish()
            return
        }
        setContent {
            ExtraitTheme {
                Popup(
                    vm = vm,
                    onClose = { vm.cancel(); finish() },
                    onOcr = vm::runOcr,
                    onPdf = vm::runPdf,
                    onCancel = vm::cancel,
                    onCopy = { t -> vm.note = if (Actions.copy(this, t)) "Texte copié ✓" else "Texte trop volumineux : utilisez Partager" },
                    onShareText = { t -> Actions.share(this, t) },
                    onSavePdf = { saveLauncher.launch("Extrait.pdf") },
                    onSharePdf = { f -> Export.share(this, f, "application/pdf") },
                    onOpenApp = ::openInApp
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        accept(intent)
    }

    private fun accept(i: Intent): Boolean {
        val list = urisFrom(i)
        if (list.isEmpty()) return false
        vm.load(list, i.getStringExtra(EXTRA_MODE))
        return true
    }

    /** Ouvre l'app complète (recadrage, rotation, lecture fidèle, export Word/Excel/PDF) avec ces images. */
    private fun openInApp() {
        val list = vm.uris
        if (list.isEmpty()) return
        val clip = ClipData.newRawUri("images", list[0]).also { c -> list.drop(1).forEach { c.addItem(ClipData.Item(it)) } }
        val i = Intent(this, MainActivity::class.java)
            .setAction(MainActivity.ACTION_OPEN)
            .putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(list))
            .setClipData(clip)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        startActivity(i)
        finish()
    }

    private fun urisFrom(i: Intent): List<Uri> {
        val out = LinkedHashSet<Uri>()
        when (i.action) {
            Intent.ACTION_VIEW -> i.data?.let { out.add(it) }
            Intent.ACTION_SEND -> IntentCompat.getParcelableExtra(i, Intent.EXTRA_STREAM, Uri::class.java)?.let { out.add(it) }
            else -> IntentCompat.getParcelableArrayListExtra(i, Intent.EXTRA_STREAM, Uri::class.java)?.let { out.addAll(it) }
        }
        if (out.isEmpty()) {
            val clip = i.clipData
            if (clip != null) for (k in 0 until clip.itemCount) clip.getItemAt(k).uri?.let { out.add(it) }
        }
        return out.toList()
    }

    companion object {
        const val ACTION_QUICK = "com.dlvibe.extrait.QUICK"
        const val EXTRA_MODE = "mode"
        const val MODE_OCR = "ocr"
        const val MODE_PDF = "pdf"

        fun intent(ctx: Context, uris: List<Uri>, mode: String?): Intent {
            val i = Intent(ctx, QuickActivity::class.java)
                .setAction(ACTION_QUICK)
                .putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            if (uris.isNotEmpty()) {
                i.clipData = ClipData.newRawUri("images", uris[0]).also { c -> uris.drop(1).forEach { c.addItem(ClipData.Item(it)) } }
            }
            if (mode != null) i.putExtra(EXTRA_MODE, mode)
            return i
        }
    }
}

@Composable
private fun Popup(
    vm: QuickViewModel,
    onClose: () -> Unit,
    onOcr: () -> Unit,
    onPdf: () -> Unit,
    onCancel: () -> Unit,
    onCopy: (String) -> Unit,
    onShareText: (String) -> Unit,
    onSavePdf: () -> Unit,
    onSharePdf: (File) -> Unit,
    onOpenApp: () -> Unit
) {
    val count = vm.uris.size
    val what = if (count > 1) "ces $count images" else "cette image"
    Box(
        Modifier.fillMaxSize().background(Color(0x66000000))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onClose() },
        contentAlignment = Alignment.BottomCenter
    ) {
        Card(
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
            modifier = Modifier.padding(12.dp).navigationBarsPadding().widthIn(max = 460.dp).fillMaxWidth()
        ) {
            Column(
                Modifier.padding(20.dp)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        when (val p = vm.phase) {
                            is QuickViewModel.Phase.Choose -> "Que faire de $what ?"
                            is QuickViewModel.Phase.Working -> p.label
                            is QuickViewModel.Phase.Extracted -> "Texte extrait"
                            is QuickViewModel.Phase.Made -> "PDF prêt"
                            is QuickViewModel.Phase.Fail -> p.message
                        },
                        modifier = Modifier.weight(1f), color = Ink, fontSize = 19.sp, fontWeight = FontWeight.Black
                    )
                    IconButton(onClick = onClose) { Icon(Icons.Rounded.Close, contentDescription = "Fermer", tint = Muted) }
                }
                Spacer(Modifier.height(12.dp))
                when (val p = vm.phase) {
                    is QuickViewModel.Phase.Choose -> {
                        Button(
                            onClick = onOcr,
                            modifier = Modifier.fillMaxWidth().height(54.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Beam, contentColor = Ink)
                        ) {
                            Icon(Icons.Rounded.TextFields, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Extraire le texte", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                        Spacer(Modifier.height(10.dp))
                        Button(
                            onClick = onPdf,
                            modifier = Modifier.fillMaxWidth().height(54.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Cobalt, contentColor = Color.White)
                        ) {
                            Icon(Icons.Rounded.PictureAsPdf, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Numériser en PDF", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                        Spacer(Modifier.height(4.dp))
                        TextButton(onClick = onOpenApp, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                            Icon(Icons.Rounded.OpenInNew, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Ouvrir dans Extrait (recadrer, Word, Excel…)")
                        }
                    }

                    is QuickViewModel.Phase.Working -> {
                        if (p.total > 1) {
                            LinearProgressIndicator(progress = { p.done / p.total.toFloat() }, modifier = Modifier.fillMaxWidth().height(8.dp))
                            Spacer(Modifier.height(8.dp))
                            Text("${p.done} sur ${p.total}", color = Muted, fontSize = 13.sp)
                        } else {
                            LinearProgressIndicator(modifier = Modifier.fillMaxWidth().height(8.dp))
                        }
                        TextButton(onClick = onCancel) { Text("Annuler") }
                    }

                    is QuickViewModel.Phase.Extracted -> {
                        if (p.text.isBlank()) {
                            Text("Aucun texte détecté dans " + what + ".", color = Muted, fontSize = 14.sp)
                        } else {
                            Box(
                                Modifier.fillMaxWidth().heightIn(max = 240.dp)
                                    .clip8().background(Page).border(1.dp, Line, RoundedCornerShape(14.dp)).padding(12.dp)
                            ) {
                                SelectionContainer {
                                    Text(
                                        p.text, color = Ink, fontFamily = FontFamily.Monospace, fontSize = 12.sp, lineHeight = 17.sp,
                                        modifier = Modifier.verticalScroll(rememberScrollState())
                                    )
                                }
                            }
                            Spacer(Modifier.height(12.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Button(
                                    onClick = { onCopy(p.text) },
                                    modifier = Modifier.weight(1f).height(50.dp),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Beam, contentColor = Ink)
                                ) {
                                    Icon(Icons.Rounded.ContentCopy, contentDescription = null, modifier = Modifier.size(20.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Copier", fontWeight = FontWeight.Bold)
                                }
                                OutlinedButton(
                                    onClick = { onShareText(p.text) },
                                    modifier = Modifier.weight(1f).height(50.dp),
                                    shape = RoundedCornerShape(14.dp)
                                ) {
                                    Icon(Icons.Rounded.Share, contentDescription = null, modifier = Modifier.size(20.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Partager", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        TextButton(onClick = onOpenApp, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                            Icon(Icons.Rounded.OpenInNew, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Ouvrir dans Extrait")
                        }
                    }

                    is QuickViewModel.Phase.Made -> {
                        Text(
                            "${p.pages} page${if (p.pages > 1) "s" else ""} · une page par image",
                            color = Muted, fontSize = 14.sp
                        )
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                onClick = onSavePdf,
                                modifier = Modifier.weight(1f).height(50.dp),
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Beam, contentColor = Ink)
                            ) {
                                Icon(Icons.Rounded.Save, contentDescription = null, modifier = Modifier.size(20.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Enregistrer", fontWeight = FontWeight.Bold)
                            }
                            OutlinedButton(
                                onClick = { onSharePdf(p.file) },
                                modifier = Modifier.weight(1f).height(50.dp),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Icon(Icons.Rounded.Share, contentDescription = null, modifier = Modifier.size(20.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Partager", fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    is QuickViewModel.Phase.Fail -> {
                        TextButton(onClick = onClose) { Text("Fermer") }
                    }
                }
                vm.note?.let {
                    Spacer(Modifier.height(8.dp))
                    Text(it, color = Cobalt, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

private fun Modifier.clip8(): Modifier = this.then(Modifier.clip(RoundedCornerShape(14.dp)))
