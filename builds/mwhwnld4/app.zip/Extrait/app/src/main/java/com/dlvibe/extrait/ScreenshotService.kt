package com.dlvibe.extrait

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.database.ContentObserver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.max

/**
 * Surveille la galerie : quand une capture d'écran apparaît, propose tout de suite d'en extraire le texte,
 * même si l'app n'est pas ouverte. Petite carte flottante si l'autorisation « Affichage par-dessus
 * les autres applis » est accordée, sinon notification avec boutons.
 */
class ScreenshotService : Service() {

    private val main = Handler(Looper.getMainLooper())
    private val io: ExecutorService = Executors.newSingleThreadExecutor()
    private var observer: ContentObserver? = null
    private var lastShownId = -1L
    private var overlay: View? = null

    private val check = Runnable { io.execute { checkLatest() } }
    private val hide = Runnable { hideOverlay() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannels()
        try {
            val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            else ServiceInfo.FOREGROUND_SERVICE_TYPE_MANIFEST
            ServiceCompat.startForeground(this, ONGOING_ID, ongoingNotification(), type)
        } catch (e: Throwable) {
            stopSelf()
            return
        }
        val obs = object : ContentObserver(main) {
            override fun onChange(selfChange: Boolean, uri: Uri?) {
                main.removeCallbacks(check)
                main.postDelayed(check, 700)
            }
        }
        contentResolver.registerContentObserver(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true, obs)
        observer = obs
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        observer?.let { contentResolver.unregisterContentObserver(it) }
        observer = null
        main.removeCallbacksAndMessages(null)
        hideOverlay()
        io.shutdownNow()
        super.onDestroy()
    }

    // ------------------------------------------------------------ détection

    private fun checkLatest() {
        if (!Prefs.hasMedia(this)) return
        val ids = arrayListOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.DATE_ADDED)
        ids.add(if (Build.VERSION.SDK_INT >= 29) MediaStore.Images.Media.RELATIVE_PATH else MediaStore.Images.Media.DATA)
        val args = Bundle().apply {
            putStringArray(ContentResolver.QUERY_ARG_SORT_COLUMNS, arrayOf(MediaStore.Images.Media.DATE_ADDED, MediaStore.Images.Media._ID))
            putInt(ContentResolver.QUERY_ARG_SORT_DIRECTION, ContentResolver.QUERY_SORT_DIRECTION_DESCENDING)
            putInt(ContentResolver.QUERY_ARG_LIMIT, 5)
        }
        var found: Long = -1L
        try {
            contentResolver.query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, ids.toTypedArray(), args, null)?.use { c ->
                val now = System.currentTimeMillis() / 1000
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    val name = c.getString(1).orEmpty()
                    val added = c.getLong(2)
                    val where = c.getString(3).orEmpty()
                    if (now - added > 20) break
                    if (looksLikeScreenshot(name, where)) { found = id; break }
                }
            }
        } catch (e: Throwable) {
            return
        }
        if (found < 0 || found == lastShownId) return
        lastShownId = found
        val uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, found)
        val thumb = smallThumb(uri)
        main.post { present(uri, thumb) }
    }

    private fun looksLikeScreenshot(name: String, path: String): Boolean {
        val s = "$path/$name".lowercase()
        return listOf("screenshot", "screen_shot", "screen-shot", "screencap", "capture d", "capture_d", "capture-d").any { it in s }
    }

    private fun smallThumb(uri: Uri): Bitmap? = try {
        val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, b) }
        var sample = 1
        while (max(b.outWidth, b.outHeight) / (sample * 2) >= 320) sample *= 2
        val o = BitmapFactory.Options().apply { inSampleSize = sample }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
    } catch (e: Throwable) {
        null
    }

    private fun present(uri: Uri, thumb: Bitmap?) {
        if (Prefs.hasOverlay(this)) {
            try { showOverlay(uri, thumb); return } catch (e: Throwable) { /* repli : notification */ }
        }
        notifyShot(uri, thumb)
    }

    // ------------------------------------------------------------ carte flottante

    private fun showOverlay(uri: Uri, thumb: Bitmap?) {
        hideOverlay()
        val wm = getSystemService(WindowManager::class.java)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        fun pill(label: String, bg: Int, fg: Int, onClick: () -> Unit) = TextView(this).apply {
            text = label
            setTextColor(fg)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            maxLines = 1
            setPadding(dp(12), dp(9), dp(12), dp(9))
            background = GradientDrawable().apply { setColor(bg); cornerRadius = dp(14).toFloat() }
            setOnClickListener { onClick() }
        }

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(12), dp(8), dp(12))
            background = GradientDrawable().apply { setColor(0xFF0E1530.toInt()); cornerRadius = dp(22).toFloat() }
            elevation = dp(10).toFloat()
        }
        val img = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(0xFF1C2A5E.toInt())
            if (thumb != null) setImageBitmap(thumb)
            clipToOutline = true
            outlineProvider = object : android.view.ViewOutlineProvider() {
                override fun getOutline(v: View, o: android.graphics.Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(10).toFloat()) }
            }
        }
        card.addView(img, LinearLayout.LayoutParams(dp(48), dp(64)))

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(TextView(this).apply {
            text = "Capture d’écran"
            setTextColor(0xFFFFFFFF.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.DEFAULT_BOLD
        })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val lp = { LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { topMargin = dp(8); marginEnd = dp(6) } }
        row.addView(pill("Extraire le texte", 0xFFFFC857.toInt(), 0xFF0E1530.toInt()) { openQuick(uri, QuickActivity.MODE_OCR) }, lp())
        row.addView(pill("PDF", 0x33FFFFFF, 0xFFFFFFFF.toInt()) { openQuick(uri, QuickActivity.MODE_PDF) }, lp().apply { weight = 0.6f })
        col.addView(row)
        card.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(12) })

        card.addView(TextView(this).apply {
            text = "✕"
            setTextColor(0xFFB9C3E3.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            gravity = Gravity.CENTER
            setOnClickListener { hideOverlay() }
        }, LinearLayout.LayoutParams(dp(40), dp(40)))

        val width = minOf(resources.displayMetrics.widthPixels - dp(24), dp(420))
        val params = WindowManager.LayoutParams(
            width, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            android.graphics.PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dp(96)
        }
        wm.addView(card, params)
        overlay = card
        main.removeCallbacks(hide)
        main.postDelayed(hide, 9000)
    }

    private fun hideOverlay() {
        main.removeCallbacks(hide)
        val v = overlay ?: return
        overlay = null
        try { getSystemService(WindowManager::class.java).removeView(v) } catch (e: Throwable) { /* déjà retirée */ }
    }

    private fun openQuick(uri: Uri, mode: String?) {
        val i = QuickActivity.intent(this, listOf(uri), mode).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { startActivity(i) } catch (e: Throwable) { /* refusé par le système */ }
        hideOverlay()
    }

    // ------------------------------------------------------------ notifications

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_WATCH, "Surveillance des captures", NotificationManager.IMPORTANCE_MIN)
                .apply { description = "Notification discrète qui garde la détection active."; setShowBadge(false) }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_SHOT, "Capture d’écran détectée", NotificationManager.IMPORTANCE_HIGH)
                .apply { description = "Propose d’extraire le texte ou de créer un PDF."; setShowBadge(false) }
        )
    }

    private fun ongoingNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CH_WATCH)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Extrait surveille les captures d’écran")
            .setContentText("Appuyez pour ouvrir l’app")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
    }

    private fun notifyShot(uri: Uri, thumb: Bitmap?) {
        fun pi(code: Int, mode: String?) = PendingIntent.getActivity(
            this, code, QuickActivity.intent(this, listOf(uri), mode),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val b = Notification.Builder(this, CH_SHOT)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Capture d’écran")
            .setContentText("Extraire le texte ou créer un PDF ?")
            .setContentIntent(pi(1, null))
            .setAutoCancel(true)
            .setTimeoutAfter(30_000)
            .addAction(Notification.Action.Builder(null, "Extraire le texte", pi(2, QuickActivity.MODE_OCR)).build())
            .addAction(Notification.Action.Builder(null, "PDF", pi(3, QuickActivity.MODE_PDF)).build())
        if (thumb != null) b.setLargeIcon(thumb)
        try {
            getSystemService(NotificationManager::class.java).notify(SHOT_ID, b.build())
        } catch (e: Throwable) { /* notifications refusées */ }
    }

    companion object {
        private const val CH_WATCH = "watch"
        private const val CH_SHOT = "shot"
        private const val ONGOING_ID = 1
        private const val SHOT_ID = 2

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, ScreenshotService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, ScreenshotService::class.java))
        }
    }
}
