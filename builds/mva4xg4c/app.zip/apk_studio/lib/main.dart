import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

late SharedPreferences prefs;
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  prefs = await SharedPreferences.getInstance();
  runApp(MaterialApp(
    title: 'APK Studio', debugShowCheckedModeBanner: false,
    theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF2E7D32))),
    darkTheme: ThemeData(useMaterial3: true, brightness: Brightness.dark, colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF2E7D32), brightness: Brightness.dark)),
    home: const Home(),
  ));
}

/// Client GitHub : même protocole que la version web (commits dans builds/<id>/, release apk-<id>).
class GH {
  static String get repo => prefs.getString('repo') ?? '';
  static String get token => prefs.getString('token') ?? '';
  static Map<String, String> get h => {'Authorization': 'Bearer $token', 'Accept': 'application/vnd.github+json'};
  static Uri u(String p) => Uri.parse('https://api.github.com/repos/$repo$p');

  static Future<Map> put(String path, List<int> bytes, String msg) async {
    final r = await http.put(u('/contents/$path'), headers: h, body: jsonEncode({'message': msg, 'content': base64Encode(bytes)}));
    if (r.statusCode >= 300) throw 'GitHub ${r.statusCode} : ${jsonDecode(r.body)['message']}';
    return jsonDecode(r.body);
  }

  static Future<Map?> get(String p) async {
    final r = await http.get(u(p), headers: h);
    return r.statusCode == 200 ? jsonDecode(r.body) : null;
  }

  static Future<String?> buildError(String id) async {
    final r = await http.get(u('/contents/builds/$id/build-error.txt'), headers: {...h, 'Accept': 'application/vnd.github.raw+json'});
    return r.statusCode == 200 ? utf8.decode(r.bodyBytes) : null;
  }
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int i = 0;
  @override
  Widget build(BuildContext c) => Scaffold(
        body: SafeArea(child: [const BuildPage(), const AppsPage(), const SettingsPage()][i]),
        bottomNavigationBar: NavigationBar(selectedIndex: i, onDestinationSelected: (v) => setState(() => i = v), destinations: const [
          NavigationDestination(icon: Icon(Icons.build_circle_outlined), label: 'Créer'),
          NavigationDestination(icon: Icon(Icons.android), label: 'Mes apps'),
          NavigationDestination(icon: Icon(Icons.settings), label: 'Réglages'),
        ]),
      );
}

const perms = {'storage': 'Stockage', 'media': 'Médias', 'allfiles': 'Tous les fichiers', 'camera': 'Caméra', 'micro': 'Micro', 'location': 'Position', 'notifications': 'Notifications', 'contacts': 'Contacts', 'calendar': 'Calendrier', 'bluetooth': 'Bluetooth', 'phone': 'Téléphone'};

class BuildPage extends StatefulWidget {
  const BuildPage({super.key});
  @override
  State<BuildPage> createState() => _BuildPageState();
}

class _BuildPageState extends State<BuildPage> {
  String type = 'flutter', orient = 'auto';
  bool full = false, share = true, ask = true, busy = false;
  final name = TextEditingController(), pkg = TextEditingController(text: 'com.exemple.app'), vn = TextEditingController(text: '1.0.0'), vc = TextEditingController(text: '1');
  final sel = <String>{'notifications'};
  File? zip, icon;
  final log = <String>[];
  String? apk, err;

  void say(String s) => setState(() => log.add(s));

  Future<File?> pick(List<String> ext) async {
    final r = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ext);
    return r?.files.single.path == null ? null : File(r!.files.single.path!);
  }

  Future<void> run() async {
    setState(() { busy = true; log.clear(); apk = null; err = null; });
    try {
      if (GH.repo.isEmpty || GH.token.isEmpty) throw 'Renseignez le dépôt et le token dans Réglages.';
      if (zip == null) throw 'Choisissez un ZIP.';
      if (name.text.trim().isEmpty) throw 'Nom requis.';
      if (!RegExp(r'^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$').hasMatch(pkg.text.trim().toLowerCase())) throw 'Nom de paquet invalide.';
      if (zip!.lengthSync() > 40 * 1048576) throw 'ZIP trop volumineux (40 Mo max).';
      final id = DateTime.now().millisecondsSinceEpoch.toRadixString(36), dir = 'builds/$id/';
      say('Envoi de l\'archive…');
      await GH.put('${dir}app.zip', await zip!.readAsBytes(), 'Build $id : archive');
      if (icon != null) { say('Envoi de l\'icône…'); await GH.put('${dir}icon.png', await icon!.readAsBytes(), 'Build $id : icône'); }
      final cfg = {'name': name.text.trim(), 'pkg': pkg.text.trim().toLowerCase(), 'versionName': vn.text.trim(), 'versionCode': int.tryParse(vc.text) ?? 1, 'orientation': orient, 'color': '#2E7D32', 'fullscreen': full, 'icon': icon != null, 'type': type, 'permissions': sel.toList(), 'share': share, 'askStart': ask};
      say('Envoi de la configuration…');
      final res = await GH.put(dir + (type == 'flutter' ? 'flutter.json' : 'config.json'), utf8.encode(const JsonEncoder.withIndent('  ').convert(cfg)), 'Build $id : ${cfg['name']}');
      final sha = res['commit']['sha'];
      say('Commit ${sha.toString().substring(0, 7)} — compilation lancée');
      final t0 = DateTime.now();
      String last = '';
      int okNoRel = 0;
      while (DateTime.now().difference(t0).inMinutes < 35) {
        await Future.delayed(const Duration(seconds: 6));
        final rel = await GH.get('/releases/tags/apk-$id');
        if (rel != null && (rel['assets'] as List).isNotEmpty) {
          apk = (rel['assets'] as List).firstWhere((a) => '${a['name']}'.endsWith('.apk'), orElse: () => rel['assets'][0])['browser_download_url'];
          say('✔ APK prêt'); break;
        }
        final runs = await GH.get('/actions/runs?head_sha=$sha');
        final l = (runs?['workflow_runs'] as List?) ?? [];
        if (l.isEmpty) continue;
        final r = l.first, st = '${r['status']}';
        if (st != last) { last = st; say('Compilation : $st'); }
        if (st == 'completed') {
          if (r['conclusion'] != 'success') { err = await GH.buildError(id) ?? 'Échec : ${r['html_url']}'; say('✖ Échec de la compilation'); break; }
          if (++okNoRel > 4) throw 'Build réussi mais APK introuvable dans les releases.';
        }
      }
    } catch (e) { say('✖ $e'); }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext c) => ListView(padding: const EdgeInsets.all(16), children: [
        Text('Nouvelle application', style: Theme.of(c).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 12),
        SegmentedButton<String>(segments: const [ButtonSegment(value: 'flutter', label: Text('Flutter'), icon: Icon(Icons.flutter_dash)), ButtonSegment(value: 'site', label: Text('Site web'), icon: Icon(Icons.language))], selected: {type}, onSelectionChanged: (s) => setState(() => type = s.first)),
        const SizedBox(height: 12),
        TextField(controller: name, decoration: const InputDecoration(labelText: 'Nom de l\'application', border: OutlineInputBorder())),
        const SizedBox(height: 10),
        TextField(controller: pkg, decoration: const InputDecoration(labelText: 'Nom du paquet', border: OutlineInputBorder())),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(child: TextField(controller: vn, decoration: const InputDecoration(labelText: 'Version', border: OutlineInputBorder()))),
          const SizedBox(width: 10),
          Expanded(child: TextField(controller: vc, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Code', border: OutlineInputBorder()))),
        ]),
        const SizedBox(height: 10),
        DropdownButtonFormField<String>(value: orient, decoration: const InputDecoration(labelText: 'Orientation', border: OutlineInputBorder()), items: const [DropdownMenuItem(value: 'auto', child: Text('Automatique')), DropdownMenuItem(value: 'portrait', child: Text('Portrait')), DropdownMenuItem(value: 'landscape', child: Text('Paysage'))], onChanged: (v) => setState(() => orient = v!)),
        SwitchListTile(title: const Text('Plein écran'), value: full, onChanged: (v) => setState(() => full = v)),
        SwitchListTile(title: const Text('Autoriser le partage'), value: share, onChanged: (v) => setState(() => share = v)),
        SwitchListTile(title: const Text('Demander les autorisations au démarrage'), value: ask, onChanged: (v) => setState(() => ask = v)),
        Wrap(spacing: 8, children: [for (final e in perms.entries) FilterChip(label: Text(e.value), selected: sel.contains(e.key), onSelected: (v) => setState(() => v ? sel.add(e.key) : sel.remove(e.key)))]),
        const SizedBox(height: 12),
        OutlinedButton.icon(icon: const Icon(Icons.folder_zip), label: Text(zip == null ? 'Choisir le ZIP du projet' : zip!.path.split('/').last), onPressed: () async { final f = await pick(['zip']); if (f != null) setState(() => zip = f); }),
        const SizedBox(height: 8),
        OutlinedButton.icon(icon: const Icon(Icons.image), label: Text(icon == null ? 'Choisir l\'icône (PNG)' : icon!.path.split('/').last), onPressed: () async { final f = await pick(['png']); if (f != null) setState(() => icon = f); }),
        const SizedBox(height: 16),
        FilledButton.icon(icon: busy ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.rocket_launch), label: const Text('Générer l\'APK'), onPressed: busy ? null : run),
        if (log.isNotEmpty) Card(margin: const EdgeInsets.only(top: 16), child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [for (final l in log) Text(l, style: const TextStyle(fontFamily: 'monospace', fontSize: 12))]))),
        if (apk != null) FilledButton.tonalIcon(icon: const Icon(Icons.download), label: const Text('Télécharger l\'APK'), onPressed: () => launchUrl(Uri.parse(apk!), mode: LaunchMode.externalApplication)),
        if (err != null) Card(color: Theme.of(c).colorScheme.errorContainer, child: Padding(padding: const EdgeInsets.all(12), child: SelectableText(err!, style: const TextStyle(fontSize: 11, fontFamily: 'monospace')))),
      ]);
}

class AppsPage extends StatefulWidget {
  const AppsPage({super.key});
  @override
  State<AppsPage> createState() => _AppsPageState();
}

class _AppsPageState extends State<AppsPage> {
  List rels = [];
  bool loading = false;
  String? err;
  @override
  void initState() { super.initState(); load(); }

  Future<void> load() async {
    if (GH.repo.isEmpty) return;
    setState(() { loading = true; err = null; });
    final r = await http.get(GH.u('/releases?per_page=100'), headers: GH.h);
    if (r.statusCode == 200) { rels = (jsonDecode(r.body) as List).where((x) => '${x['tag_name']}'.startsWith('apk-')).toList(); } else { err = 'Erreur ${r.statusCode}'; }
    if (mounted) setState(() => loading = false);
  }

  Future<void> del(Map x) async {
    await http.delete(GH.u('/releases/${x['id']}'), headers: GH.h);
    await http.delete(GH.u('/git/refs/tags/${x['tag_name']}'), headers: GH.h);
    load();
  }

  @override
  Widget build(BuildContext c) => RefreshIndicator(
        onRefresh: load,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          Text('Mes applications', style: Theme.of(c).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
          if (loading) const LinearProgressIndicator(),
          if (err != null) Text(err!),
          for (final x in rels) Card(child: ListTile(
            leading: const CircleAvatar(child: Icon(Icons.android)),
            title: Text('${x['name'] ?? x['tag_name']}'),
            subtitle: Text('${x['published_at']}'.split('T').first),
            trailing: Row(mainAxisSize: MainAxisSize.min, children: [
              IconButton(icon: const Icon(Icons.download), onPressed: () { final a = (x['assets'] as List).where((a) => '${a['name']}'.endsWith('.apk')); if (a.isNotEmpty) launchUrl(Uri.parse(a.first['browser_download_url']), mode: LaunchMode.externalApplication); }),
              IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => del(x)),
            ]),
          )),
          if (!loading && rels.isEmpty) const Padding(padding: EdgeInsets.all(32), child: Center(child: Text('Aucune application. Tirez pour actualiser.'))),
        ]),
      );
}

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});
  @override
  Widget build(BuildContext c) {
    final repo = TextEditingController(text: GH.repo), tok = TextEditingController(text: GH.token);
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('Réglages GitHub', style: Theme.of(c).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
      const SizedBox(height: 12),
      TextField(controller: repo, decoration: const InputDecoration(labelText: 'Dépôt (ex: Doubigue/G-n-rateur)', border: OutlineInputBorder())),
      const SizedBox(height: 10),
      TextField(controller: tok, obscureText: true, decoration: const InputDecoration(labelText: 'Token GitHub (contents + actions)', border: OutlineInputBorder())),
      const SizedBox(height: 12),
      FilledButton(onPressed: () async { await prefs.setString('repo', repo.text.trim()); await prefs.setString('token', tok.text.trim()); if (c.mounted) ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content: Text('Enregistré'))); }, child: const Text('Enregistrer')),
      const SizedBox(height: 16),
      const Text('Le token reste uniquement sur ce téléphone.', style: TextStyle(fontSize: 12)),
    ]);
  }
}
