package app.arpenteur

import android.app.Application
import android.content.Context
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.*

enum class Mode { AUTO, MANUEL }
enum class Measure { DISTANCE, PARCELLE }

class MainViewModel(app: Application) : AndroidViewModel(app) {
    val tracker = GpsTracker(app)
    private val store = ParcelStore(app)

    val points = mutableStateListOf<GeoPoint>()
    var mode by mutableStateOf(Mode.MANUEL)
    var measure by mutableStateOf(Measure.PARCELLE); private set
    var nearStart by mutableStateOf(false); private set
    var recording by mutableStateOf(false)
    var closed by mutableStateOf(false)
    var avgProgress by mutableStateOf<Float?>(null); private set
    var message by mutableStateOf<String?>(null)
    var fix by mutableStateOf<Fix?>(null); private set
    var sats by mutableStateOf(0 to 0); private set
    var gpsOn by mutableStateOf(true); private set
    var parcels by mutableStateOf(store.load()); private set

    // Réglages
    var maxAcc by mutableFloatStateOf(5f)
    var minMove by mutableFloatStateOf(1.5f)
    var autoStep by mutableFloatStateOf(5f)

    private val isParcel get() = measure == Measure.PARCELLE
    val perimeter get() = GeoCalculator.perimeter(points, isParcel && points.size >= 3)
    val area get() = if (isParcel) GeoCalculator.areaM2(points) else 0.0
    val intersects get() = isParcel && GeoCalculator.selfIntersects(points)

    // Mode distance A -> B
    val distAB get() = if (points.size >= 2) GeoCalculator.distance(points.first(), points.last()) else 0.0
    val pathLength get() = GeoCalculator.perimeter(points, false)
    val liveFromLast: Double? get() {
        val f = fix ?: return null; val l = points.lastOrNull() ?: return null
        return GeoCalculator.distance(l, f.toPoint())
    }
    // Mode parcelle : retour au point de départ
    val closeRadius get() = (fix?.acc ?: 5f).coerceIn(4f, 15f)
    val distToStart: Double? get() {
        val f = fix ?: return null; val s = points.firstOrNull() ?: return null
        return GeoCalculator.distance(s, f.toPoint())
    }

    fun setMeasure(m: Measure) { if (m != measure) { reset(); measure = m } }

    private fun checkReturn(f: Fix) {
        if (!isParcel || closed || points.size < 3) { nearStart = false; return }
        if (f.acc > maxAcc * 3) return
        val near = GeoCalculator.distance(points.first(), f.toPoint()) <= closeRadius &&
            GeoCalculator.perimeter(points, false) > 4 * closeRadius
        if (near && !nearStart) {
            buzz()
            if (mode == Mode.AUTO && recording) { closed = true; recording = false; message = "Retour au départ : parcelle fermée" }
            else message = "Vous êtes revenu au point de départ : appuyez sur Fermer"
        }
        nearStart = near
    }

    init {
        viewModelScope.launch { tracker.fix.collect { f -> fix = f; f?.let(::onFix) } }
        viewModelScope.launch { tracker.sats.collect { sats = it } }
        viewModelScope.launch { tracker.enabled.collect { gpsOn = it } }
    }

    fun startGps() = tracker.start()
    override fun onCleared() = tracker.stop()

    private fun buzz() {
        val v = getApplication<Application>().getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        v.vibrate(VibrationEffect.createOneShot(60, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    private fun onFix(f: Fix) {
        checkReturn(f)
        if (!recording || mode != Mode.AUTO || closed) return
        if (f.acc > maxAcc) return                       // filtre d'imprécision
        val last = points.lastOrNull()
        if (last == null || GeoCalculator.distance(last, f.toPoint()) >= maxOf(minMove, autoStep)) {
            points.add(f.toPoint()); buzz()
        }
    }

    fun toggleRecording() {
        if (closed) return
        recording = !recording
        message = if (recording) "Marchez le long de la limite du champ" else "Relevé en pause"
    }

    /** Borne manuelle : moyenne pondérée (1/précision²) des fixes pendant 5 s. */
    fun markCorner() {
        if (closed || avgProgress != null) return
        viewModelScope.launch {
            val samples = mutableListOf<Fix>()
            val job = launch { tracker.fix.collect { it?.let(samples::add) } }
            for (i in 1..50) { avgProgress = i / 50f; delay(100) }
            job.cancel(); avgProgress = null
            if (samples.isEmpty()) { message = "Aucun signal GPS"; return@launch }
            val w = samples.map { 1.0 / (it.acc * it.acc).coerceAtLeast(0.25f) }
            val sw = w.sum()
            val p = GeoPoint(
                samples.indices.sumOf { samples[it].lat * w[it] } / sw,
                samples.indices.sumOf { samples[it].lon * w[it] } / sw,
                samples.map { it.acc }.average().toFloat()
            )
            val last = points.lastOrNull()
            when {
                points.size >= 3 && isParcel && GeoCalculator.distance(points.first(), p) <= closeRadius -> {
                    closed = true; buzz(); message = "Retour au départ : parcelle fermée"
                }
                last != null && GeoCalculator.distance(last, p) < minMove ->
                    message = "Trop proche du point précédent (< %.1f m)".format(minMove)
                else -> {
                    points.add(p); buzz()
                    message = if (p.acc > maxAcc) "Borne ajoutée, précision moyenne %.1f m (faible)".format(p.acc)
                    else "Borne %d ajoutée (± %.1f m)".format(points.size, p.acc)
                }
            }
        }
    }

    fun undo() { if (points.isNotEmpty()) { points.removeLast(); closed = false } }
    fun toggleClose() {
        if (points.size < 3) { message = "Il faut au moins 3 points"; return }
        closed = !closed; recording = false
        if (closed && intersects) message = "Attention : le tracé se croise, la surface peut être faussée"
    }
    fun reset() { points.clear(); closed = false; recording = false; nearStart = false }

    fun save(name: String) {
        val s = SavedParcel(System.currentTimeMillis(), name.ifBlank { "Parcelle" }, Exporter.now(), points.toList(), area, perimeter)
        parcels = listOf(s) + parcels; store.saveAll(parcels); message = "Parcelle enregistrée"
    }
    fun load(p: SavedParcel) { points.clear(); points.addAll(p.points); closed = true; recording = false }
    fun delete(p: SavedParcel) { parcels = parcels.filter { it.id != p.id }; store.saveAll(parcels) }

    fun export(name: String, p: List<GeoPoint>, geo: Boolean): android.net.Uri? {
        if (p.size < 3) { message = "Rien à exporter"; return null }
        val a = GeoCalculator.areaM2(p); val per = GeoCalculator.perimeter(p)
        val safe = name.replace(Regex("[^A-Za-z0-9_-]"), "_")
        return if (geo) Exporter.write(getApplication(), "$safe.geojson", "application/geo+json", Exporter.geoJson(name, p, a, per))
        else Exporter.write(getApplication(), "$safe.csv", "text/csv", Exporter.csv(name, p, a, per))
    }
}
