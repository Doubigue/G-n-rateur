package com.example.mydm.ui

import android.graphics.BitmapFactory
import android.util.LruCache
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.mydm.core.*
import com.example.mydm.downloader.DownloadService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

// ───── Miniatures (cache mémoire, sans bibliothèque externe)
private val imgHttp = OkHttpClient()
private val imgCache = object : LruCache<String, ImageBitmap>(80) {}

@Composable
private fun RemoteImage(url: String?, modifier: Modifier) {
    val bmp by produceState<ImageBitmap?>(url?.let { imgCache.get(it) }, url) {
        if (url == null || value != null) return@produceState
        value = withContext(Dispatchers.IO) {
            runCatching {
                imgHttp.newCall(Request.Builder().url(url).build()).execute().use { r ->
                    r.body?.byteStream()?.let { BitmapFactory.decodeStream(it) }?.asImageBitmap()
                }
            }.getOrNull()
        }?.also { imgCache.put(url, it) }
    }
    Box(modifier.background(Surface1)) {
        bmp?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
    }
}

private data class Quality(val label: String, val opt: QualityOption)

private fun heightOpt(h: Int) = Quality("${h}p",
    QualityOption("${h}p", null, false, "bv*[height<=$h][ext=mp4]+ba[ext=m4a]/bv*[height<=$h]+ba/b[height<=$h]"))

private val QUALITIES = listOf(
    Quality("Meilleure qualité", QualityOption("", null, false, "bv*[ext=mp4]+ba[ext=m4a]/bv*+ba/b")),
    heightOpt(1080), heightOpt(720), heightOpt(480), heightOpt(360),
    Quality("Audio MP3", QualityOption("MP3", null, false, "ba/b", mp3 = true)),
    Quality("Audio M4A", QualityOption("M4A", null, false, "ba[ext=m4a]/ba/b"))
)

/**
 * Onglet « Vidéos » (comme VidMate) : recherche YouTube, collage d'un lien de vidéo / playlist / chaîne,
 * liste à plat (des centaines de vidéos en quelques secondes), sélection multiple, qualité commune, téléchargement groupé.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoHubScreen(goDownloads: () -> Unit) {
    val ctx = LocalContext.current
    val app = appInstance()
    val scope = rememberCoroutineScope()

    var query by rememberSaveable { mutableStateOf("") }
    var playlistsMode by rememberSaveable { mutableStateOf(false) }
    var qualityIdx by rememberSaveable { mutableIntStateOf(0) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var entries by remember { mutableStateOf<List<VideoEntry>>(emptyList()) }
    var listTitle by remember { mutableStateOf<String?>(null) }        // non nul : on est dans une liste (dossier du même nom)
    var parent by remember { mutableStateOf<List<VideoEntry>?>(null) } // résultats avant l'ouverture d'une liste
    var wanted by remember { mutableIntStateOf(50) }
    var lastSearch by remember { mutableStateOf<String?>(null) }
    val selected = remember { mutableStateMapOf<String, Boolean>() }
    var qMenu by remember { mutableStateOf(false) }

    BackHandler(parent != null) { entries = parent!!; parent = null; listTitle = null; selected.clear() }

    fun load(target: String, title: String?, max: Int, keepSelection: Boolean = false) {
        loading = true; error = null
        scope.launch {
            runCatching { MediaResolver.listEntries(app, target, max) }
                .onSuccess { r ->
                    entries = r.entries
                    listTitle = if (title != null) (title.ifBlank { r.title }) else if (!target.startsWith("ytsearch") && r.entries.size > 1 && !target.contains("results?")) r.title else null
                    if (!keepSelection) selected.clear()
                    if (r.entries.isEmpty()) error = "Aucun résultat."
                }
                .onFailure { error = (it.message ?: "Impossible de charger la liste").take(240) }
            loading = false
        }
    }

    fun search() {
        val q = query.trim()
        if (q.isEmpty()) return
        parent = null; wanted = 50
        lastSearch = if (q.startsWith("http")) null else q
        if (q.startsWith("http")) load(q, null, 0)
        else load(MediaResolver.searchUrl(q, playlistsMode).let { if (playlistsMode) it else "ytsearch:$q" }, null, 50)
    }

    fun more() {
        val q = lastSearch ?: return
        wanted = (wanted + 50).coerceAtMost(300)
        load(if (playlistsMode) MediaResolver.searchUrl(q, true) else "ytsearch:$q", null, wanted, keepSelection = true)
    }

    fun downloadSelected() {
        val picked = entries.filter { selected[it.id] == true && !it.isList }
        if (picked.isEmpty()) return
        val q = QUALITIES[qualityIdx].opt
        val sub = listTitle?.takeIf { it.isNotBlank() }?.let { cleanName(it) }
        scope.launch {
            val ids = picked.map { e -> app.downloadEngine.enqueueYt(e.url, e.title, q, null, null, sub, e.durationSec) }
            DownloadService.startMany(ctx, ids)
            Toast.makeText(ctx, "${ids.size} téléchargement(s) ajouté(s)", Toast.LENGTH_SHORT).show()
            selected.clear()
            goDownloads()
        }
    }

    val videos = entries.filter { !it.isList }
    val count = selected.count { it.value }

    Column(Modifier.fillMaxSize()) {
        // ── Barre de recherche
        Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (parent != null) TextButton({ entries = parent!!; parent = null; listTitle = null; selected.clear() }) { Text("←") }
                OutlinedTextField(
                    query, { query = it }, Modifier.weight(1f), singleLine = true,
                    placeholder = { Text("Rechercher sur YouTube ou coller un lien") },
                    trailingIcon = { if (query.isNotEmpty()) TextButton({ query = "" }) { Text("✕", color = Muted) } },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { search() })
                )
                Spacer(Modifier.width(6.dp))
                Button({ search() }, enabled = query.isNotBlank() && !loading) { Text("OK") }
            }
            Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                FilterChip(!playlistsMode, { playlistsMode = false }, label = { Text("Vidéos") })
                FilterChip(playlistsMode, { playlistsMode = true }, label = { Text("Listes de lecture") })
                Text("ou collez le lien d'une playlist / chaîne", color = Muted, fontSize = 11.sp, maxLines = 2)
            }
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        error?.let { Text(it, color = Danger, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp)) }

        // ── Barre de sélection
        if (videos.isNotEmpty()) Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically
        ) {
            listTitle?.takeIf { it.isNotBlank() }?.let {
                Text("📁 $it", color = Accent, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            } ?: Text("${videos.size} vidéo(s)", color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
            TextButton({ videos.forEach { selected[it.id] = true } }) { Text("Tout (${videos.size})") }
            TextButton({ selected.clear() }, enabled = count > 0) { Text("Aucun") }
        }

        // ── Résultats
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (entries.isEmpty() && !loading && error == null) {
                Centered("Recherchez une vidéo ou collez le lien d'une playlist, d'une chaîne ou d'un compte.\n\nCochez autant de vidéos que vous voulez (des centaines), choisissez la qualité, puis téléchargez.")
            }
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(entries, key = { it.id + it.url }) { e ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).glass()
                            .clickable {
                                if (e.isList) { parent = entries; load(e.url, e.title, 0) }
                                else selected[e.id] = !(selected[e.id] ?: false)
                            }.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (!e.isList) Checkbox(selected[e.id] == true, { selected[e.id] = it })
                        Box(Modifier.width(120.dp).height(68.dp).clip(RoundedCornerShape(8.dp))) {
                            RemoteImage(e.thumb, Modifier.fillMaxSize())
                            if (e.durationSec > 0) Text(formatDuration(e.durationSec), color = androidx.compose.ui.graphics.Color.White, fontSize = 10.sp,
                                modifier = Modifier.align(Alignment.BottomEnd).padding(3.dp).background(androidx.compose.ui.graphics.Color(0xAA000000), RoundedCornerShape(4.dp)).padding(horizontal = 4.dp))
                            if (e.isList) Text("☰" + (e.count?.let { " $it" } ?: ""), color = androidx.compose.ui.graphics.Color.White, fontSize = 11.sp,
                                modifier = Modifier.align(Alignment.CenterEnd).background(androidx.compose.ui.graphics.Color(0xAA000000)).padding(horizontal = 6.dp, vertical = 2.dp))
                        }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(e.title, color = Txt, fontSize = 13.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                            (e.channel ?: if (e.isList) "Liste de lecture • appuyez pour ouvrir" else null)?.let {
                                Text(it, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
                if (lastSearch != null && parent == null && entries.isNotEmpty() && wanted < 300 && entries.size >= wanted - 5) item {
                    TextButton({ more() }, enabled = !loading, modifier = Modifier.fillMaxWidth()) { Text("Plus de résultats") }
                }
                item { Spacer(Modifier.height(8.dp)) }
            }
        }

        // ── Barre de téléchargement (qualité commune + bouton)
        if (count > 0) Row(
            Modifier.fillMaxWidth().background(Surface1).padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box {
                OutlinedButton({ qMenu = true }) { Text(QUALITIES[qualityIdx].label + " ▾", fontSize = 12.sp, maxLines = 1) }
                DropdownMenu(qMenu, { qMenu = false }) {
                    QUALITIES.forEachIndexed { i, q -> DropdownMenuItem({ Text(q.label) }, { qualityIdx = i; qMenu = false }) }
                }
            }
            Spacer(Modifier.weight(1f))
            Button({ downloadSelected() }) { Text("⬇ Télécharger ($count)") }
        }
    }
}
