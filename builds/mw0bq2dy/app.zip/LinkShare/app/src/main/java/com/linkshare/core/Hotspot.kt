package com.linkshare.core

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.SoftApConfiguration
import android.net.wifi.WifiManager
import android.net.wifi.WifiNetworkSpecifier
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withTimeoutOrNull
import java.net.InetSocketAddress
import java.net.Socket
import java.security.SecureRandom

/**
 * Point d'accès créé par l'appli (aucun réglage manuel, aucun routeur) :
 *  1. Wi-Fi Direct « groupe autonome » en 5 GHz : le plus rapide (souvent 3 à 5 fois plus que le 2,4 GHz),
 *     et le téléphone garde son Wi-Fi / Internet en même temps sur la plupart des modèles ;
 *  2. sinon Wi-Fi Direct sur la bande choisie par le téléphone ;
 *  3. sinon « point d'accès local » d'Android (LocalOnlyHotspot).
 * Le nom et le mot de passe sont mis dans le QR : l'autre téléphone s'y connecte tout seul.
 */
object Hotspot {
    data class State(
        val ssid: String, val pass: String, val host: String, val band: String, val kind: String,
        val wpa3: Boolean = false, val freq: Int = 0,
    )
    const val KIND_P2P = "Wi-Fi Direct"

    val state = MutableStateFlow<State?>(null)
    val starting = MutableStateFlow(false)
    val error = MutableStateFlow<String?>(null)

    private var p2p: WifiP2pManager? = null
    private var channel: WifiP2pManager.Channel? = null
    private var lohs: WifiManager.LocalOnlyHotspotReservation? = null
    private val main = Handler(Looper.getMainLooper())

    /** Permissions nécessaires pour créer le point d'accès (et pour rejoindre celui de l'autre). */
    fun permissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.NEARBY_WIFI_DEVICES)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

    fun hasPermissions(ctx: Context) = permissions().all {
        ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED
    }

    /** Avant Android 13, Wi-Fi Direct et le point d'accès local exigent que la localisation soit activée. */
    fun locationNeeded(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT >= 33) return false
        val lm = ctx.getSystemService(LocationManager::class.java) ?: return false
        return !lm.isLocationEnabled
    }

    fun isActive() = state.value != null

    private fun randomPass(n: Int): String {
        val chars = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val r = SecureRandom()
        return (1..n).map { chars[r.nextInt(chars.length)] }.joinToString("")
    }

    /** Ne plante jamais : toute erreur (permission retirée, Wi-Fi occupé…) s'affiche à l'écran. */
    fun start(ctx: Context) {
        try { startUnsafe(ctx) } catch (e: Exception) {
            closeP2p()
            fail(if (e is SecurityException) "Autorise « Appareils à proximité » / la localisation puis réessaie" else e.message ?: "Point d'accès impossible")
        }
    }

    @SuppressLint("MissingPermission")
    private fun startUnsafe(ctx: Context) {
        val app = ctx.applicationContext
        if (state.value != null || starting.value) return
        if (!hasPermissions(app)) { fail("Autorise « Appareils à proximité » / la localisation puis réessaie"); return }
        error.value = null
        starting.value = true
        val wm = app.getSystemService(WifiManager::class.java)
        val mgr = app.getSystemService(WifiP2pManager::class.java)
        // Wi-Fi Direct a besoin du Wi-Fi allumé ; sinon on passe directement au point d'accès local
        if (mgr == null || wm == null || !wm.isWifiEnabled || !app.packageManager.hasSystemFeature(PackageManager.FEATURE_WIFI_DIRECT)) {
            startLocal(app); return
        }
        val ch = mgr.initialize(app, Looper.getMainLooper()) { if (p2p != null) state.value = null }
        if (ch == null) { startLocal(app); return }
        p2p = mgr; channel = ch
        val pass = randomPass(10)
        val model = Build.MODEL.filter { it.isLetterOrDigit() }.take(12).ifEmpty { "Phone" }
        val name = "DIRECT-LS-$model"

        fun create(band: Int, retry: Boolean) {
            val cfg = try {
                WifiP2pConfig.Builder().setNetworkName(name).setPassphrase(pass).setGroupOperatingBand(band).build()
            } catch (e: Exception) { startLocal(app); return }
            try { mgr.createGroup(ch, cfg, object : WifiP2pManager.ActionListener {
                override fun onSuccess() { readGroup(app, mgr, ch, 0) }
                override fun onFailure(reason: Int) {
                    when {
                        // Un ancien groupe est encore ouvert : on le ferme puis on recommence
                        reason == WifiP2pManager.BUSY && retry -> mgr.removeGroup(ch, object : WifiP2pManager.ActionListener {
                            override fun onSuccess() { main.postDelayed({ create(band, false) }, 400) }
                            override fun onFailure(r: Int) { main.postDelayed({ create(band, false) }, 400) }
                        })
                        band == WifiP2pConfig.GROUP_OWNER_BAND_5GHZ -> create(WifiP2pConfig.GROUP_OWNER_BAND_AUTO, true)
                        else -> { closeP2p(); startLocal(app) }
                    }
                }
            }) } catch (e: Exception) { closeP2p(); startLocal(app) }
        }
        create(WifiP2pConfig.GROUP_OWNER_BAND_5GHZ, true)
    }

    @SuppressLint("MissingPermission")
    private fun readGroup(app: Context, mgr: WifiP2pManager, ch: WifiP2pManager.Channel, attempt: Int) {
        if (p2p == null) return
        try { mgr.requestGroupInfo(ch) { g ->
            if (g == null || g.networkName.isNullOrEmpty()) {
                if (attempt < 15) main.postDelayed({ readGroup(app, mgr, ch, attempt + 1) }, 300)
                else { closeP2p(); startLocal(app) }
                return@requestGroupInfo
            }
            val freq = g.frequency
            val band = when {
                freq >= 5900 -> "6 GHz"
                freq >= 4900 -> "5 GHz"
                freq > 0 -> "2,4 GHz"
                else -> "Wi-Fi Direct"
            }
            // Le propriétaire d'un groupe Wi-Fi Direct a toujours l'adresse 192.168.49.1
            state.value = State(g.networkName, g.passphrase ?: "", "192.168.49.1", band, KIND_P2P, freq = freq)
            starting.value = false
        } } catch (e: Exception) { closeP2p(); startLocal(app) }
    }

    @SuppressLint("MissingPermission")
    private fun startLocal(app: Context) {
        val wm = app.getSystemService(WifiManager::class.java)
        if (wm == null) { fail("Wi-Fi indisponible"); return }
        runCatching { lohs?.close() }; lohs = null
        try {
            wm.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
                override fun onStarted(r: WifiManager.LocalOnlyHotspotReservation) {
                    lohs = r
                    val c: SoftApConfiguration = r.softApConfiguration
                    @Suppress("DEPRECATION") val ssid = c.ssid ?: ""
                    val pass = c.passphrase ?: ""
                    val wpa3 = c.securityType == SoftApConfiguration.SECURITY_TYPE_WPA3_SAE
                    waitApIp(0) { ip ->
                        state.value = State(ssid, pass, ip, "Point d'accès", "Point d'accès local", wpa3)
                        starting.value = false
                    }
                }
                override fun onStopped() { lohs = null; state.value = null }
                override fun onFailed(reason: Int) {
                    fail(
                        when (reason) {
                            WifiManager.LocalOnlyHotspotCallback.ERROR_INCOMPATIBLE_MODE -> "Le partage de connexion du téléphone est activé : désactive-le puis réessaie"
                            WifiManager.LocalOnlyHotspotCallback.ERROR_TETHERING_DISALLOWED -> "Le point d'accès est interdit sur ce téléphone"
                            WifiManager.LocalOnlyHotspotCallback.ERROR_NO_CHANNEL -> "Aucun canal Wi-Fi libre"
                            else -> "Impossible de créer le point d'accès"
                        }
                    )
                }
            }, main)
        } catch (e: Exception) {
            fail(e.message ?: "Impossible de créer le point d'accès")
        }
    }

    private fun waitApIp(attempt: Int, done: (String) -> Unit) {
        val ip = NetUtil.apIp()
        if (ip != null || attempt >= 15) done(ip ?: NetUtil.localIp())
        else main.postDelayed({ waitApIp(attempt + 1, done) }, 200)
    }

    private fun fail(msg: String) {
        error.value = msg
        starting.value = false
        state.value = null
    }

    private fun closeP2p() {
        val mgr = p2p; val ch = channel
        p2p = null; channel = null
        if (mgr != null && ch != null) {
            runCatching { mgr.removeGroup(ch, null) }
            runCatching { ch.close() }
        }
    }

    fun stop() {
        closeP2p()
        runCatching { lohs?.close() }
        lohs = null
        state.value = null
        starting.value = false
    }
}

/**
 * Connexion automatique au point d'accès de l'autre téléphone (nom + mot de passe lus dans le QR).
 *  1. Wi-Fi Direct « connexion rapide » : on rejoint le groupe avec ses identifiants et sa fréquence,
 *     sans fenêtre de confirmation, sans balayage Wi-Fi (limité par Android à 4 par 2 min) et
 *     en gardant son propre Wi-Fi : c'est le plus rapide et le plus fiable ;
 *  2. sinon, demande de réseau Android (une petite fenêtre « Se connecter » à accepter).
 */
object WifiJoin {
    private val main = Handler(Looper.getMainLooper())
    private var cb: ConnectivityManager.NetworkCallback? = null
    @Volatile var network: Network? = null; private set
    private var p2pMgr: WifiP2pManager? = null
    private var p2pCh: WifiP2pManager.Channel? = null
    /** Appelé si le point d'accès de l'autre disparaît. */
    var onLost: (() -> Unit)? = null

    val joined get() = network != null || p2pCh != null

    /** Vrai si l'hôte répond déjà (même Wi-Fi) : pas besoin de changer de réseau. */
    fun reachable(host: String, port: Int, timeout: Int = 1500): Boolean = runCatching {
        Socket().use { it.connect(InetSocketAddress(host, port), timeout) }; true
    }.getOrDefault(false)

    private suspend fun p2pCall(block: (WifiP2pManager.ActionListener) -> Unit): Boolean {
        val d = CompletableDeferred<Boolean>()
        val l = object : WifiP2pManager.ActionListener {
            override fun onSuccess() { d.complete(true) }
            override fun onFailure(reason: Int) { d.complete(false) }
        }
        try { main.post { try { block(l) } catch (e: Exception) { d.complete(false) } } } catch (e: Exception) { return false }
        return withTimeoutOrNull(8_000) { d.await() } ?: false
    }

    /** Rejoint un groupe Wi-Fi Direct (API 29+) : aucune fenêtre, le Wi-Fi normal reste connecté. */
    @SuppressLint("MissingPermission")
    suspend fun joinP2p(ctx: Context, ssid: String, pass: String, freq: Int, host: String, port: Int): Boolean {
        val app = ctx.applicationContext
        if (!Hotspot.hasPermissions(app) || !Radio.wifiOn(app)) return false
        val mgr = app.getSystemService(WifiP2pManager::class.java) ?: return false
        release(app)
        val ch = try { mgr.initialize(app, Looper.getMainLooper(), null) } catch (e: Exception) { null } ?: return false
        p2pMgr = mgr; p2pCh = ch
        // Un ancien groupe ou une ancienne invitation bloquent la connexion : on nettoie d'abord
        p2pCall { mgr.cancelConnect(ch, it) }
        p2pCall { mgr.removeGroup(ch, it) }
        fun cfg(withFreq: Boolean) = WifiP2pConfig.Builder().setNetworkName(ssid).setPassphrase(pass).apply {
            if (withFreq && freq > 0) setGroupOperatingFrequency(freq)
        }.build()
        val tries = if (freq > 0) listOf(true, false) else listOf(false)
        for (withFreq in tries) {
            val c = try { cfg(withFreq) } catch (e: Exception) { continue }
            if (!p2pCall { mgr.connect(ch, c, it) }) { delay(500); continue }
            // Attend l'adresse IP puis la réponse du serveur de l'autre téléphone
            for (i in 0 until 40) {
                if (withContext(Dispatchers.IO) { reachable(host, port, 700) }) return true
                delay(300)
            }
            p2pCall { mgr.cancelConnect(ch, it) }
        }
        releaseP2p()
        return false
    }

    /** Android affiche une petite fenêtre « Se connecter à l'appareil » : il suffit d'accepter. */
    suspend fun join(ctx: Context, ssid: String, pass: String, wpa3: Boolean): Boolean {
        val cm = ctx.applicationContext.getSystemService(ConnectivityManager::class.java)
        releaseSpecifier(ctx)
        val result = CompletableDeferred<Network?>()
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(n: Network) {
                // Toute l'appli (HTTP, voie rapide, lecteur, miniatures) passe par ce réseau
                runCatching { cm.bindProcessToNetwork(n) }
                network = n
                result.complete(n)
            }
            override fun onUnavailable() { result.complete(null) }
            override fun onLost(n: Network) {
                if (n == network) {
                    network = null
                    runCatching { cm.bindProcessToNetwork(null) }
                    onLost?.invoke()
                }
            }
        }
        try {
            val spec = WifiNetworkSpecifier.Builder().setSsid(ssid).apply {
                if (pass.isNotEmpty()) { if (wpa3) setWpa3Passphrase(pass) else setWpa2Passphrase(pass) }
            }.build()
            val req = NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .setNetworkSpecifier(spec)
                .build()
            cb = callback
            cm.requestNetwork(req, callback)
        } catch (e: Exception) {
            cb = null
            return false
        }
        val n = withTimeoutOrNull(60_000) { result.await() }
        if (n == null) releaseSpecifier(ctx)
        return n != null
    }

    private fun releaseSpecifier(ctx: Context) {
        val cm = ctx.applicationContext.getSystemService(ConnectivityManager::class.java)
        val c = cb ?: return
        cb = null; network = null
        runCatching { cm.bindProcessToNetwork(null) }
        runCatching { cm.unregisterNetworkCallback(c) }
    }

    private fun releaseP2p() {
        val mgr = p2pMgr; val ch = p2pCh
        p2pMgr = null; p2pCh = null
        if (mgr != null && ch != null) {
            runCatching { mgr.removeGroup(ch, null) }
            runCatching { ch.close() }
        }
    }

    fun release(ctx: Context) {
        releaseSpecifier(ctx)
        releaseP2p()
    }
}

/** État de la radio, pour guider l'utilisateur avant le scan. */
object Radio {
    fun wifiOn(ctx: Context) = ctx.getSystemService(WifiManager::class.java)?.isWifiEnabled == true

    /** Partage de connexion du système (point d'accès « classique ») : détection best effort. */
    fun systemHotspotOn(ctx: Context): Boolean {
        val wm = ctx.getSystemService(WifiManager::class.java) ?: return false
        val viaApi = runCatching {
            val m = wm.javaClass.getDeclaredMethod("isWifiApEnabled")
            m.isAccessible = true
            m.invoke(wm) as Boolean
        }.getOrNull()
        return viaApi ?: (NetUtil.apInterfaceUp() && !Hotspot.isActive())
    }

    /** Ouvre le panneau Wi-Fi (Android 10+ n'autorise plus les applis à l'allumer elles-mêmes). */
    fun openWifiPanel(ctx: Context) {
        // Depuis une activité : pas de FLAG_ACTIVITY_NEW_TASK, sinon le panneau s'ouvre dans une autre tâche et reste caché
        val act = ctx as? android.app.Activity
        fun go(i: Intent): Boolean = try {
            if (act != null) act.startActivity(i) else ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
        } catch (_: Exception) { false }
        go(Intent(Settings.Panel.ACTION_WIFI)) || go(Intent(Settings.ACTION_WIFI_SETTINGS)) || go(Intent(Settings.ACTION_WIRELESS_SETTINGS))
    }

    /** Ouvre les réglages du point d'accès du système pour le couper. */
    fun openTetherSettings(ctx: Context) {
        val tries = listOf(
            Intent().setClassName("com.android.settings", "com.android.settings.TetherSettings"),
            Intent().setClassName("com.android.settings", "com.android.settings.Settings\$TetherSettingsActivity"),
            Intent(Settings.ACTION_WIRELESS_SETTINGS),
        )
        for (i in tries) {
            try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return } catch (_: Exception) { }
        }
    }

    fun openLocationSettings(ctx: Context) {
        runCatching { ctx.startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    /** Page de l'appli dans les réglages (permission refusée définitivement). */
    fun openAppSettings(ctx: Context) {
        runCatching {
            ctx.startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:${ctx.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }
}
