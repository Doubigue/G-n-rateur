package com.linguavibe.app.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.ui.viewinterop.AndroidView
import io.github.sceneview.SceneView
import io.github.sceneview.math.Position
import io.github.sceneview.node.ModelNode
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.OutlinedButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linguavibe.app.data.Languages
import java.util.Locale

private data class TeacherProfile(
    val code: String, val name: String, val role: String, val avatar: String,
    val greeting: String, val frenchIntro: String, val nativeIntro: String
)

private val teacherProfiles = listOf(
    TeacherProfile("en", "Emily", "Professeure d’anglais", "👩🏽‍🏫", "Hello! I am Emily. Welcome to your English class!", "Bonjour ! Je suis Emily, ta professeure d’anglais. Nous allons apprendre pas à pas, avec des exemples, de l’écoute et de la pratique.", "I will help you speak English with confidence. Listen, repeat, and practise every day."),
    TeacherProfile("es", "Carlos", "Professeur d’espagnol", "👨🏽‍🏫", "¡Hola! Soy Carlos. ¡Bienvenido a tu clase de español!", "Bonjour ! Je suis Carlos, ton professeur d’espagnol. Nous allons apprendre le vocabulaire, construire des phrases et parler dans des situations de la vie quotidienne.", "Te ayudaré a hablar español paso a paso. Escucha, repite y practica cada día."),
    TeacherProfile("pt", "Ana", "Professeure de portugais", "👩🏾‍🏫", "Olá! Eu sou a Ana. Bem-vindo à aula de português!", "Bonjour ! Je suis Ana, ta professeure de portugais. Nous allons travailler la prononciation, les expressions utiles et les conversations de tous les jours.", "Vou ajudar você a falar português passo a passo. Ouça, repita e pratique todos os dias."),
    TeacherProfile("ru", "Mikhail", "Professeur de russe", "👨🏻‍🏫", "Здравствуйте! Меня зовут Михаил. Добро пожаловать на урок русского языка!", "Bonjour ! Je suis Mikhail, ton professeur de russe. Nous allons découvrir l’alphabet, les sons, les déclinaisons et des dialogues progressifs.", "Я помогу вам изучать русский язык шаг за шагом. Слушайте, повторяйте и практикуйтесь каждый день."),
    TeacherProfile("zh", "Mei", "Professeure de chinois", "👩🏻‍🏫", "你好！我是美老师。欢迎学习中文！", "Bonjour ! Je suis Mei, ta professeure de chinois. Nous allons apprendre les tons, les caractères, le vocabulaire et les phrases utiles.", "我会一步一步帮助你学习中文。请认真听、大声跟读，并每天练习。"),
    TeacherProfile("ar", "Nour", "Professeure d’arabe", "👩🏽‍🏫", "مرحباً! أنا نور. أهلاً بك في درس اللغة العربية!", "Bonjour ! Je suis Nour, ta professeure d’arabe. Nous allons travailler les lettres, les sons, la lecture et les expressions de la vie courante.", "سأساعدك على تعلم اللغة العربية خطوة بخطوة. استمع وكرر وتدرب كل يوم.")
)

@Composable
fun TeachersScreen(onBack: () -> Unit) {
    val speaker = LocalSpeaker.current
    var selectedCode by remember { mutableStateOf("en") }
    var speaking by remember { mutableStateOf(false) }
    val selected = teacherProfiles.first { it.code == selectedCode }
    val language = Languages.byCode(selected.code)
    val speed = speaker.settings.playbackSpeed

    // L'analyse du niveau sonore (Android Visualizer) exige l'autorisation audio, même si le micro n'est pas utilisé.
    // Sans elle, la bouche utilise un rythme de repli.
    val context = LocalContext.current
    var afterPermission by remember { mutableStateOf<(() -> Unit)?>(null) }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        afterPermission?.invoke(); afterPermission = null
    }
    fun withLevelPermission(action: () -> Unit) {
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) action() else { afterPermission = action; permission.launch(Manifest.permission.RECORD_AUDIO) }
    }

    Column(Modifier.fillMaxSize().background(Paper)) {
        TopBar("Mes professeurs", "Choisissez votre accompagnateur de langue", Navy, onBack)
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            CardBox {
                Text("Un cours particulier, à votre rythme", style = PosterTitle, fontSize = 20.sp, color = Ink)
                Text("Chaque professeur apparaît sous forme de personnage 3D. Il vous accueille, explique en français puis dans la langue étudiée, et vous aide à écouter et répéter.", color = InkSoft, fontSize = 14.sp, lineHeight = 21.sp)
            }

            Text("Choisir un professeur", style = PosterTitle, fontSize = 19.sp, color = Ink)
            teacherProfiles.chunked(2).forEach { pair ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    pair.forEach { profile ->
                        val active = profile.code == selectedCode
                        Column(
                            Modifier.weight(1f).clip(RoundedCornerShape(20.dp))
                                .background(if (active) Navy else Color.White)
                                .border(1.dp, if (active) Gold else Sand, RoundedCornerShape(20.dp))
                                .clickable {
                                    speaker.stop(); speaking = false; selectedCode = profile.code
                                }.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(profile.name.take(1), fontSize = 34.sp, fontWeight = FontWeight.Black, color = GoldSoft)
                            Text(profile.name, color = if (active) Color.White else Ink, fontWeight = FontWeight.Bold)
                            Text(Languages.byCode(profile.code).flag + " " + Languages.byCode(profile.code).name,
                                color = if (active) GoldSoft else InkSoft, fontSize = 12.sp)
                        }
                    }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }

            val theme = posterTheme(selected.code)
            CardBox {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Teacher3DModel(selected.code, speaking)
                    Column(Modifier.weight(1f)) {
                        Text(selected.name, style = PosterTitle, fontSize = 23.sp, color = Ink)
                        Text(selected.role, color = InkSoft, fontSize = 13.sp)
                        Text(language.flag + "  " + language.nativeName, color = theme.start, fontWeight = FontWeight.Bold)
                    }
                }
                Text("Présentation en français", style = PosterTitle, fontSize = 16.sp, color = Ink)
                Text(selected.frenchIntro, color = InkSoft, fontSize = 14.sp, lineHeight = 21.sp)
                Button(
                    onClick = {
                        withLevelPermission {
                            speaking = true
                            speaker.speak(selected.frenchIntro, Locale.forLanguageTag("fr-FR")) { speaking = false }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = theme.start)
                ) { Text("▶ Écouter en français") }
                Text("Présentation dans la langue étudiée", style = PosterTitle, fontSize = 16.sp, color = Ink)
                Text(selected.nativeIntro, color = InkSoft, fontSize = 14.sp, lineHeight = 22.sp)
                Button(
                    onClick = {
                        withLevelPermission {
                            speaking = true
                            speaker.speak(selected.nativeIntro, language.locale) { speaking = false }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = theme.start)
                ) { Text("▶ Écouter en ${language.name}") }
                OutlinedButton(onClick = {
                    if (speaking) { speaker.stop(); speaking = false }
                    else withLevelPermission {
                        speaking = true
                        speaker.speak(selected.greeting, language.locale) { speaking = false }
                    }
                }) { Text(if (speaking) "■ Arrêter la voix" else "▶ Faire saluer le professeur") }
            }

            CardBox {
                Text("Vitesse de lecture", style = PosterTitle, fontSize = 17.sp, color = Ink)
                Text("${"%.1f".format(java.util.Locale.US, speed)}×", color = theme.start, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                Slider(value = speed, onValueChange = { speaker.settings.updatePlaybackSpeed(it) }, valueRange = 0.5f..1.5f)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("0,5× Lent", fontSize = 12.sp, color = InkSoft)
                    Text("1× Normal", fontSize = 12.sp, color = InkSoft)
                    Text("1,5× Rapide", fontSize = 12.sp, color = InkSoft)
                }
            }
            Text("Astuce : écoutez d’abord en français pour comprendre, puis dans la langue étudiée pour entraîner votre oreille. La vitesse choisie s’applique aussi aux autres lectures de l’application.", color = InkSoft, fontSize = 12.sp, lineHeight = 18.sp)
        }
    }
}

@Composable
private fun Teacher3DModel(code: String, speaking: Boolean) {
    val speaker = LocalSpeaker.current
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        key(code, speaking) {
        AndroidView(
            modifier = Modifier.size(width = 154.dp, height = 220.dp)
                .clip(RoundedCornerShape(18.dp)),
            factory = { context ->
                SceneView(context).apply {
                    // Deux clips GLB : animation d'attente et animation de parole.
                    // La clé Compose recrée la vue lorsque l'état de parole change.
                    cameraNode.position = Position(x = 0f, y = 0.88f, z = 3.25f)
                    val animationFile = if (speaking) "speaking" else "idle"
                    val node = ModelNode(
                        modelInstance = modelLoader.createModelInstance(
                            assetFileLocation = "models/${code}_${animationFile}.glb"
                        ),
                        autoAnimate = true,
                        scaleToUnits = 1.8f
                    )
                    node.position = Position(y = -0.9f)
                    addChildNode(node)
                    // Le nœud « mouth » n'est plus animé par le clip GLB : il suit le niveau sonore réel
                    // du Speaker à chaque image (ou un rythme de repli si l'analyse audio est indisponible).
                    val rig = MouthRig.find(engine, node.modelInstance.asset)
                    if (rig != null) {
                        var lastFrame = 0L
                        onFrame = { frameTimeNanos ->
                            val dt = if (lastFrame == 0L) 0f else (frameTimeNanos - lastFrame) / 1_000_000_000f
                            lastFrame = frameTimeNanos
                            rig.update(speaker.speechLevel, speaker.levelLive, speaking && speaker.levelUnavailable, dt)
                        }
                    }
                }
            }
        )
        }
        Text(
            if (speaking) (when {
                speaker.levelLive -> "● bouche pilotée par le son"
                speaker.levelUnavailable -> "● parle (rythme simulé)"
                else -> "● préparation de la voix…"
            })
            else "● animation d’attente",
            color = if (speaking) Good else InkSoft,
            fontSize = 11.sp
        )
    }
}
