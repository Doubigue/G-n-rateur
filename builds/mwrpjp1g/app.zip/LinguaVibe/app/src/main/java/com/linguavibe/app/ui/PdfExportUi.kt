package com.linguavibe.app.ui

import android.Manifest
import android.app.DownloadManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileOutputStream
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.OutputStream

private const val DL_CHANNEL = "linguavibe_downloads"

/**
 * Renvoie une fonction « exporter(nomDuFichier, écriture) » : le PDF est généré en arrière-plan puis
 * enregistré directement dans le dossier Téléchargements du téléphone, avec une notification
 * « Téléchargement terminé » (toucher la notification ouvre le PDF).
 */
@Composable
fun rememberPdfExporter(): (String, (OutputStream) -> Unit) -> Unit {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pending by remember { mutableStateOf<Pair<String, (OutputStream) -> Unit>?>(null) }

    val start: (String, (OutputStream) -> Unit) -> Unit = { name, job ->
        Toast.makeText(context, "Création du PDF… (un cours complet peut prendre quelques secondes)", Toast.LENGTH_LONG).show()
        scope.launch {
            val result = withContext(Dispatchers.IO) {
                try {
                    saveToDownloads(context, name, job)
                } catch (e: Throwable) {
                    null
                }
            }
            if (result != null) {
                if (result.uri != null) notifyDownloadDone(context, name, result.uri)
                Toast.makeText(context, "PDF enregistré dans Téléchargements", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(context, "Impossible de créer le PDF", Toast.LENGTH_LONG).show()
            }
        }
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        val job = pending
        pending = null
        if (job != null) start(job.first, job.second)
    }

    return { name, job ->
        val needed = buildList {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
            ) add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (needed.isEmpty()) {
            start(name, job)
        } else {
            pending = name to job
            permLauncher.launch(needed.toTypedArray())
        }
    }
}

private class SavedPdf(val uri: Uri?)

/** Écrit le PDF dans Téléchargements. Android 10+ : MediaStore. Avant : fichier + Gestionnaire de téléchargement. */
@Suppress("DEPRECATION")
private fun saveToDownloads(context: Context, name: String, job: (OutputStream) -> Unit): SavedPdf? {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return null
        return try {
            val stream = resolver.openOutputStream(uri) ?: throw IllegalStateException("flux nul")
            stream.use { job(it) }
            resolver.update(uri, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
            SavedPdf(uri)
        } catch (e: Throwable) {
            resolver.delete(uri, null, null)
            null
        }
    }
    val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
    dir.mkdirs()
    val base = name.removeSuffix(".pdf")
    var file = File(dir, name)
    var n = 1
    while (file.exists()) file = File(dir, "$base ($n).pdf").also { n++ }
    try {
        FileOutputStream(file).use { job(it) }
    } catch (e: Throwable) {
        file.delete()
        return null
    }
    val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    dm.addCompletedDownload(file.name, "LinguaVibe", true, "application/pdf", file.absolutePath, file.length(), true)
    return SavedPdf(null)
}

/** Android 10+ : le Gestionnaire de téléchargement ne notifie pas pour MediaStore, on poste donc la notification. */
private fun notifyDownloadDone(context: Context, name: String, uri: Uri) {
    try {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(DL_CHANNEL, "Téléchargements", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
        val view = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/pdf")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val pi = PendingIntent.getActivity(context, name.hashCode(), view, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val notif = NotificationCompat.Builder(context, DL_CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle(name)
            .setContentText("Téléchargement terminé")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        if (NotificationManagerCompat.from(context).areNotificationsEnabled()) {
            nm.notify(name.hashCode(), notif)
        }
    } catch (_: Throwable) {
    }
}

/** Bouton « PDF » à placer dans la barre du haut. */
@Composable
fun PdfTopButton(onClick: () -> Unit) {
    Row(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(Color.White.copy(alpha = 0.18f))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        LineIcon(Art.icDownload, Color.White, 18.dp, accent = Gold)
        Text("PDF", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}
