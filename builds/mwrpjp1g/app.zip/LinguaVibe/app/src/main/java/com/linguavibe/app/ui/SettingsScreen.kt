package com.linguavibe.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linguavibe.app.speech.ElevenLabs
import com.linguavibe.app.speech.GoogleVoice
import com.linguavibe.app.speech.ElevenVoice
import kotlinx.coroutines.launch

/** Paramètres : voix de l'appli, voix ElevenLabs, cache audio. */
@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val speaker = LocalSpeaker.current
    val settings = speaker.settings
    val scope = rememberCoroutineScope()

    var keyInput by remember { mutableStateOf(settings.apiKey) }
    var voiceInput by remember { mutableStateOf(settings.voiceId) }
    var showKey by remember { mutableStateOf(false) }
    var voices by remember { mutableStateOf<List<ElevenVoice>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var cacheVersion by remember { mutableIntStateOf(0) }
    val cacheMb = remember(cacheVersion) { ElevenLabs.cacheSizeMb(context) }

    Column(Modifier.fillMaxSize()) {
        TopBar("Paramètres", "Voix des leçons", Ruby, onBack, PosterTheme(Ruby, Night, GoldSoft))
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ScreenHero(
                "Les voix de LinguaVibe", "Voix Google (téléchargeable) ou ElevenLabs",
                Art.icVoice, PosterTheme(Ruby, Color(0xFF8E1B1B), GoldSoft)
            )
            VoiceEngineSection()
            VoicePacksSection()

            CardBox {
                Text("Voix en ligne : ElevenLabs", style = PosterTitle, fontSize = 17.sp, color = Ink)
                Text(
                    "Avec une clé API ElevenLabs, les mots, les exemples et les dialogues sont lus par une voix " +
                        "naturelle dans toutes les langues. Sans clé, l'application utilise sa voix Google gratuite.\n" +
                        "• Créez la clé sur elevenlabs.io (Paramètres › Clés API).\n" +
                        "• Chaque phrase n'est demandée qu'une fois, puis relue depuis le téléphone.\n" +
                        "• La clé reste sur ce téléphone ; elle n'est envoyée qu'à ElevenLabs.",
                    fontSize = 14.sp, color = InkSoft
                )
            }

            CardBox {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Utiliser la voix ElevenLabs", fontWeight = FontWeight.Bold, color = Ink,
                        modifier = Modifier.weight(1f)
                    )
                    Switch(checked = settings.enabled, onCheckedChange = { settings.updateEnabled(it) })
                }
                OutlinedTextField(
                    value = keyInput,
                    onValueChange = { keyInput = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Clé API ElevenLabs") },
                    visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        settings.updateApiKey(keyInput)
                        if (settings.apiKey.isNotBlank()) settings.updateEnabled(true)
                        message = if (settings.apiKey.isBlank()) "Clé effacée." else "Clé enregistrée."
                    }) { Text("Enregistrer") }
                    TextButton(onClick = { showKey = !showKey }) { Text(if (showKey) "Masquer" else "Afficher") }
                }
            }

            CardBox {
                Text("Voix", style = PosterTitle, fontSize = 17.sp, color = Ink)
                if (settings.voiceId.isNotBlank()) {
                    Chip("Voix choisie : ${settings.voiceName.ifBlank { settings.voiceId }}", Good)
                } else {
                    Chip("Aucune voix choisie", Warn)
                }
                PillButton("Charger mes voix", Art.icDownload, Navy, filled = false, enabled = !loading && settings.apiKey.isNotBlank()) {
                        scope.launch {
                            loading = true
                            message = "Chargement des voix…"
                            try {
                                voices = ElevenLabs.listVoices(settings.apiKey)
                                message = if (voices.isEmpty()) "Aucune voix sur ce compte." else "Touchez une voix pour la choisir."
                            } catch (e: Exception) {
                                message = "ERR: ${e.message ?: "Impossible de charger les voix"}"
                            } finally {
                                loading = false
                            }
                        }
                }
                voices.forEach { voice ->
                    val selected = voice.id == settings.voiceId
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (selected) Good.copy(alpha = 0.14f) else Paper)
                            .clickable {
                                settings.updateVoice(voice.id, voice.name)
                                voiceInput = voice.id
                            }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(voice.name, fontWeight = FontWeight.SemiBold, color = Ink)
                            if (voice.category.isNotBlank()) Text(voice.category, fontSize = 12.sp, color = InkSoft)
                        }
                        if (selected) LineIcon(Art.icCheck, Good, 18.dp)
                    }
                }
                OutlinedTextField(
                    value = voiceInput,
                    onValueChange = { voiceInput = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("…ou collez un identifiant de voix") }
                )
                TextButton(onClick = {
                    settings.updateVoice(voiceInput, "")
                    message = "Voix enregistrée."
                }) { Text("Utiliser cet identifiant") }
            }

            CardBox {
                Text("Modèle", style = PosterTitle, fontSize = 17.sp, color = Ink)
                listOf(
                    ElevenLabs.MODEL_QUALITY to "Qualité maximale (multilingue v2)",
                    ElevenLabs.MODEL_FAST to "Rapide et économique (flash v2.5)"
                ).forEach { (id, label) ->
                    val selected = settings.model == id
                    ChoiceRow(label, selected) { settings.updateModel(id) }
                }
            }

            CardBox {
                Text("Audio enregistré : ${cacheMb + GoogleVoice.cacheSizeMb(context)} Mo", color = Ink)
                TextButton(onClick = {
                    speaker.stop()
                    ElevenLabs.clearCache(context)
                    GoogleVoice.clearCache(context)
                    com.linguavibe.app.speech.VoicePacks.resetAll(context)
                    cacheVersion++
                }) { LineIcon(Art.icTrash, Bad, 18.dp); Spacer(Modifier.width(6.dp)); Text("Vider l'audio enregistré", color = Bad) }
            }

            message?.let { AutoStatus(it) }
        }
    }
}
