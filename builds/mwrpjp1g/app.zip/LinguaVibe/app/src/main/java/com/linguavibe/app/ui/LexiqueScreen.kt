package com.linguavibe.app.ui

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linguavibe.app.data.Languages
import com.linguavibe.app.lexique.LexiqueReminder
import com.linguavibe.app.lexique.LexiqueStore
import com.linguavibe.app.lexique.LexiqueWord
import com.linguavibe.app.lexique.normalize
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

private fun fmt(n: Int): String = NumberFormat.getInstance().format(n)

private fun clock(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%02d:%02d".format(s / 60, s % 60)
}

/** Les « / » séparent plusieurs traductions : la synthèse vocale les lit mieux comme une pause. */
private fun spoken(text: String): String = text.replace(" / ", ", ").replace("/", ", ")

private val GreenSoft = Good.copy(alpha = 0.13f)

// ============================================================================ Écran principal

@Composable
fun LexiqueScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val store = remember { LexiqueStore.get(context) }
    LaunchedEffect(Unit) { store.load() }
    val theme = posterTheme("es")
    var tab by rememberSaveable { mutableStateOf(0) }
    val tabs = listOf("Mots", "Quiz", "Bilan", "Rappels")
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize()) {
        TopBar(
            "Lexique espagnol",
            if (store.loading) "Chargement du fichier Excel…"
            else "${fmt(store.learnedCount)} appris · ${fmt(store.remaining)} restants",
            theme.start, onBack, theme
        )
        TabRow(selectedTabIndex = tab, containerColor = Color.White, contentColor = Forest) {
            tabs.forEachIndexed { i, label ->
                Tab(
                    selected = tab == i, onClick = { tab = i },
                    text = { Text(label, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1) }
                )
            }
        }
        Box(Modifier.fillMaxSize()) {
            when {
                tab == 3 -> ReminderTab()
                store.loading -> Column(
                    Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    CircularProgressIndicator(color = Forest)
                    Spacer(Modifier.height(12.dp))
                    Text("Lecture des 10 000 mots du fichier Excel…", color = InkSoft)
                }
                store.error != null -> Column(
                    Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(store.error ?: "", color = Bad, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(12.dp))
                    PillButton("Réessayer", Art.icRefresh, Forest) { scope.launch { store.load(force = true) } }
                }
                tab == 0 -> WordsTab(store)
                tab == 1 -> QuizTab(store)
                else -> DashboardTab(store)
            }
        }
    }
}

// ============================================================================ Éléments communs

@Composable
private fun LexBar(fraction: Float, color: Color, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(50)).background(Sand)) {
        Box(Modifier.fillMaxWidth(fraction.coerceIn(0f, 1f)).fillMaxHeight().clip(RoundedCornerShape(50)).background(color))
    }
}

@Composable
private fun SpeakButton(color: Color = Forest, size: Dp = 42.dp, slow: Boolean = false, onClick: () -> Unit) {
    Box(
        Modifier.size(size).clip(CircleShape).background(color.copy(alpha = 0.13f)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { LineIcon(if (slow) Art.icSlow else Art.icVoice, color, size * 0.55f) }
}

@Composable
private fun FilterPill(text: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        text, color = if (selected) Color.White else Ink, fontWeight = FontWeight.Bold, fontSize = 13.sp,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) Forest else Sand)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    )
}

@Composable
private fun StatTile(label: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(20.dp)).background(color.copy(alpha = 0.12f)).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(value, style = PosterTitle, fontSize = 28.sp, color = color)
        Text(label, fontSize = 12.sp, color = InkSoft, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun ConfirmDialog(title: String, text: String, confirm: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = { Text(text) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(confirm, color = Bad, fontWeight = FontWeight.Bold) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}

// ============================================================================ Onglet 1 : cartes de mots

@Composable
private fun WordsTab(store: LexiqueStore) {
    val speaker = LocalSpeaker.current
    val es = remember { Languages.byCode("es").locale }
    var query by rememberSaveable { mutableStateOf("") }
    var filter by rememberSaveable { mutableStateOf(0) } // 0 tous, 1 à apprendre, 2 appris
    val q = remember(query) { normalize(query.trim()) }
    val shown = remember(q, filter, store.words, store.learnedCount) {
        store.words.filter { w ->
            (q.isEmpty() || w.search.contains(q)) && when (filter) {
                1 -> store.flagOf(w.id) == 0
                2 -> store.flagOf(w.id) != 0
                else -> true
            }
        }
    }
    LazyColumn(
        Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item(key = "head") {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = query, onValueChange = { query = it }, singleLine = true,
                    placeholder = { Text("Rechercher en espagnol ou en français") },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterPill("Tous", filter == 0) { filter = 0 }
                    FilterPill("À apprendre", filter == 1) { filter = 1 }
                    FilterPill("Appris", filter == 2) { filter = 2 }
                }
                LexBar(if (store.total == 0) 0f else store.learnedCount.toFloat() / store.total, Good)
                Text(
                    "${fmt(shown.size)} mot(s) affiché(s) · ${fmt(store.learnedCount)} appris sur ${fmt(store.total)}",
                    fontSize = 12.sp, color = InkSoft
                )
            }
        }
        items(shown, key = { it.id }) { w ->
            val flag = store.flags[w.id] ?: 0
            WordCard(
                w, flag,
                onSpeak = { speaker.speak(spoken(w.es), es) },
                onSlow = { speaker.speak(spoken(w.es), es, slow = true) },
                onMark = { store.mark(w.id) },
                onReset = { store.resetWord(w.id) }
            )
        }
    }
}

@Composable
private fun WordCard(
    w: LexiqueWord, flag: Int, onSpeak: () -> Unit, onSlow: () -> Unit, onMark: () -> Unit, onReset: () -> Unit
) {
    val learned = flag != 0
    val shape = RoundedCornerShape(22.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(if (learned) GreenSoft else Color.White)
            .border(if (learned) 2.dp else 1.dp, if (learned) Good else Sand, shape)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(w.es, style = PosterTitle, fontSize = 22.sp, color = if (learned) Good else Ink)
                if (w.phon.isNotEmpty()) Text(w.phon, style = AccentText, fontSize = 14.sp, color = InkSoft)
            }
            SpeakButton(slow = true, size = 38.dp, onClick = onSlow)
            Spacer(Modifier.width(8.dp))
            SpeakButton(onClick = onSpeak)
        }
        Text(w.fr, fontSize = 16.sp, color = Ink)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (learned) {
                Chip(if ((flag and 1) != 0) "APPRIS ✓" else "RÉUSSI AU QUIZ ✓", Good)
                Spacer(Modifier.weight(1f))
                PillButton("Réinitialiser", Art.icRefresh, Bad, filled = false, onClick = onReset)
            } else {
                Spacer(Modifier.weight(1f))
                PillButton("Marquer appris", Art.icCheck, Good, onClick = onMark)
            }
        }
    }
}

// ============================================================================ Onglet 2 : quiz

/** Choisit un mot au hasard parmi ceux qui restent, plus 3 mauvaises réponses. Null si tout est appris. */
private fun buildQuestion(store: LexiqueStore, lastId: Int?, direction: Int): Pair<LexiqueWord, List<LexiqueWord>>? {
    val pool = store.pool()
    if (pool.isEmpty()) return null
    var target = pool.random()
    var tries = 0
    while (pool.size > 1 && target.id == lastId && tries < 10) {
        target = pool.random()
        tries++
    }
    val all = store.words
    fun label(w: LexiqueWord) = (if (direction == 0) w.fr else w.es).lowercase()
    val used = hashSetOf(label(target))
    val options = mutableListOf(target)
    var guard = 0
    while (options.size < 4 && guard < 500 && all.size >= 4) {
        guard++
        val c = all.random()
        if (c.es == target.es || c.fr == target.fr) continue
        if (used.add(label(c))) options.add(c)
    }
    options.shuffle()
    return target to options
}

@Composable
private fun QuizTab(store: LexiqueStore) {
    val speaker = LocalSpeaker.current
    val es = remember { Languages.byCode("es").locale }
    val fr = remember { Locale.FRENCH }

    var direction by remember { mutableStateOf(0) }   // 0 : j'écoute l'espagnol, je choisis le français
    var limit by remember { mutableStateOf(15) }       // secondes par question
    var started by remember { mutableStateOf(false) }
    var serial by remember { mutableStateOf(0) }
    var target by remember { mutableStateOf<LexiqueWord?>(null) }
    var options by remember { mutableStateOf<List<LexiqueWord>>(emptyList()) }
    var picked by remember { mutableStateOf<Int?>(null) } // id choisi, -1 = temps écoulé
    var timeLeft by remember { mutableStateOf(0L) }
    var good by remember { mutableStateOf(0) }
    var bad by remember { mutableStateOf(0) }
    var streak by remember { mutableStateOf(0) }
    var sessionStart by remember { mutableStateOf(0L) }
    var elapsed by remember { mutableStateOf(0L) }
    var lastId by remember { mutableStateOf<Int?>(null) }
    var confirmReset by remember { mutableStateOf(false) }

    DisposableEffect(Unit) { onDispose { speaker.stop() } }

    fun nextQuestion() {
        val q = buildQuestion(store, lastId, direction)
        if (q == null) {
            target = null
            options = emptyList()
        } else {
            target = q.first
            options = q.second
            lastId = q.first.id
        }
        picked = null
        timeLeft = limit * 1000L
        serial++
    }

    fun answer(choice: Int) {
        val t = target ?: return
        if (picked != null) return
        val spent = limit * 1000L - timeLeft
        picked = choice
        val ok = choice == t.id
        if (ok) {
            good++
            streak++
            store.markQuizPassed(t.id) // réussi : il ne reviendra plus et sort du total restant
        } else {
            bad++
            streak = 0
        }
        store.recordAnswer(ok, spent, streak)
    }

    fun startSession() {
        good = 0
        bad = 0
        streak = 0
        lastId = null
        sessionStart = System.currentTimeMillis()
        elapsed = 0L
        started = true
        nextQuestion()
    }

    // Écoute automatique de chaque nouvelle question
    LaunchedEffect(serial) {
        val t = target ?: return@LaunchedEffect
        if (direction == 0) speaker.speak(spoken(t.es), es) else speaker.speak(spoken(t.fr), fr)
    }

    // Minuteur de la question
    LaunchedEffect(serial) {
        if (target == null) return@LaunchedEffect
        val begin = System.currentTimeMillis()
        val total = limit * 1000L
        while (picked == null) {
            val left = total - (System.currentTimeMillis() - begin)
            timeLeft = left.coerceAtLeast(0L)
            if (left <= 0L) {
                answer(-1)
                break
            }
            delay(100)
        }
    }

    // Chronomètre de la session
    LaunchedEffect(started, target) {
        while (started && target != null) {
            elapsed = System.currentTimeMillis() - sessionStart
            delay(500)
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        val t = target
        when {
            !started -> {
                CardBox {
                    SectionTitle("Quiz sur ${fmt(store.total)} mots", "Aléatoire · les mots réussis ne reviennent pas", Art.icQuiz)
                    Text("${fmt(store.remaining)} mots restent dans le quiz.", fontWeight = FontWeight.Bold, color = Ink)
                    Text("Sens du quiz", fontWeight = FontWeight.Bold, color = Ink)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterPill("J'écoute l'espagnol → je trouve le français", direction == 0) { direction = 0 }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterPill("J'écoute le français → je trouve l'espagnol", direction == 1) { direction = 1 }
                    }
                    Text("Temps par question", fontWeight = FontWeight.Bold, color = Ink)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(10, 15, 30).forEach { s -> FilterPill("$s s", limit == s) { limit = s } }
                    }
                    PillButton(
                        "Commencer le quiz", Art.icPlay, Forest, Modifier.fillMaxWidth(),
                        enabled = store.remaining > 0, big = true
                    ) { startSession() }
                    if (store.remaining == 0) Text("Tous les mots sont appris. Réinitialisez pour recommencer.", color = InkSoft)
                    PillButton("Réinitialiser le quiz", Art.icRefresh, Bad, Modifier.fillMaxWidth(), filled = false) { confirmReset = true }
                }
            }
            t == null -> {
                CardBox {
                    Text("Bravo !", style = PosterTitle, fontSize = 26.sp, color = Good)
                    Text("Il n'y a plus aucun mot à réviser : tout est appris ou réussi.", color = Ink)
                    Text("Session : $good bonne(s) réponse(s) en ${clock(elapsed)}.", color = InkSoft)
                    PillButton("Réinitialiser le quiz", Art.icRefresh, Forest, Modifier.fillMaxWidth(), big = true) { confirmReset = true }
                }
            }
            else -> {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Pill("✓ $good", bg = Good, fg = Color.White)
                    Pill("✗ $bad", bg = Bad, fg = Color.White)
                    Pill("⏱ ${clock(elapsed)}", bg = Sand, fg = Ink)
                    if (streak >= 2) Pill("Série $streak")
                }
                val fraction = if (limit == 0) 0f else timeLeft / (limit * 1000f)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    LexBar(fraction, if (fraction > 0.5f) Good else if (fraction > 0.25f) Warn else Bad, Modifier.weight(1f))
                    Text("${(timeLeft + 999) / 1000} s", fontWeight = FontWeight.Bold, color = Ink)
                }
                CardBox {
                    Text(
                        if (direction == 0) "Écoutez le mot espagnol, puis choisissez sa traduction française"
                        else "Écoutez le mot en français, puis choisissez le mot espagnol",
                        color = InkSoft
                    )
                    Row(
                        Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterHorizontally),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        SpeakButton(slow = true, size = 52.dp) {
                            if (direction == 0) speaker.speak(spoken(t.es), es, slow = true) else speaker.speak(spoken(t.fr), fr, slow = true)
                        }
                        SpeakButton(size = 76.dp) {
                            if (direction == 0) speaker.speak(spoken(t.es), es) else speaker.speak(spoken(t.fr), fr)
                        }
                    }
                }
                options.forEach { o ->
                    val st = when {
                        picked == null -> 0
                        o.id == t.id -> 1
                        picked == o.id -> 2
                        else -> 3
                    }
                    OptionRow(
                        text = if (direction == 0) o.fr else o.es,
                        sub = if (picked != null && direction == 1 && o.phon.isNotEmpty()) o.phon else null,
                        state = st, enabled = picked == null,
                        onClick = { answer(o.id) },
                        // Chaque proposition peut être prononcée dans sa langue (le français dans le sens 1 → l'espagnol)
                        onSpeak = {
                            if (direction == 0) speaker.speak(spoken(o.fr), fr) else speaker.speak(spoken(o.es), es)
                        }
                    )
                }
                if (picked != null) {
                    val ok = picked == t.id
                    CardBox {
                        Text(
                            when {
                                ok -> "Bonne réponse !"
                                picked == -1 -> "Temps écoulé"
                                else -> "Raté"
                            },
                            style = PosterTitle, fontSize = 22.sp, color = if (ok) Good else Bad
                        )
                        Text(t.es, style = PosterTitle, fontSize = 22.sp, color = Ink)
                        if (t.phon.isNotEmpty()) Text(t.phon, style = AccentText, color = InkSoft)
                        Text(t.fr, fontSize = 16.sp, color = Ink)
                        if (ok) Text("Ce mot est retiré du quiz et du total restant.", fontSize = 12.sp, color = Good)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            PillButton("En français", Art.icVoice, Navy, filled = false) { speaker.speak(spoken(t.fr), fr) }
                            PillButton("En espagnol", Art.icVoice, Forest, filled = false) { speaker.speak(spoken(t.es), es) }
                        }
                        PillButton("Mot suivant", Art.icPlay, Forest, Modifier.fillMaxWidth(), big = true) { nextQuestion() }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PillButton("Arrêter", Art.icStop, Navy, filled = false) { speaker.stop(); started = false }
                    PillButton("Réinitialiser", Art.icRefresh, Bad, filled = false) { confirmReset = true }
                }
            }
        }
    }

    if (confirmReset) {
        ConfirmDialog(
            "Réinitialiser le quiz ?",
            "Les mots réussis au quiz reviennent dans le quiz et les statistiques du quiz repartent de zéro. " +
                "Les mots que vous avez marqués « appris » restent verts.",
            "Réinitialiser",
            onConfirm = {
                confirmReset = false
                speaker.stop()
                store.resetQuiz()
                started = false
                target = null
                picked = null
                good = 0
                bad = 0
                streak = 0
                lastId = null
            },
            onDismiss = { confirmReset = false }
        )
    }
}

@Composable
private fun OptionRow(text: String, sub: String?, state: Int, enabled: Boolean, onClick: () -> Unit, onSpeak: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    val (bg, border) = when (state) {
        1 -> GreenSoft to Good
        2 -> Bad.copy(alpha = 0.12f) to Bad
        3 -> Color.White to Sand
        else -> Color.White to Color(0xFFD9D1BC)
    }
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(bg)
            .border(2.dp, border, shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(start = 14.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = Ink)
            if (sub != null) Text(sub, style = AccentText, fontSize = 13.sp, color = InkSoft)
        }
        SpeakButton(size = 40.dp, onClick = onSpeak)
    }
}

// ============================================================================ Onglet 3 : tableau de bord

@Composable
private fun DashboardTab(store: LexiqueStore) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var confirm by remember { mutableStateOf(0) } // 1 appris, 2 quiz, 3 tout, 4 fichier d'origine
    var message by remember { mutableStateOf<String?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            message = try {
                "${fmt(store.importExcel(uri))} mots importés. La progression a été remise à zéro."
            } catch (e: Exception) {
                e.message ?: "Import impossible."
            }
        }
    }
    val fraction = if (store.total == 0) 0f else store.learnedCount.toFloat() / store.total
    val answered = store.quizCorrect + store.quizWrong
    val rate = if (answered == 0) 0 else store.quizCorrect * 100 / answered
    val avg = if (answered == 0) 0.0 else store.quizMillis / 1000.0 / answered

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(28.dp))
                .background(Brush.linearGradient(listOf(Forest, Color(0xFF06331F))))
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Mots appris", color = Color(0xFFE8F25C), fontWeight = FontWeight.Bold)
            Text(fmt(store.learnedCount), style = PosterTitle, fontSize = 52.sp, color = Color.White)
            Text("sur ${fmt(store.total)} · ${"%.1f".format(fraction * 100)} %", color = Color.White.copy(alpha = 0.85f))
            Box(Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.22f))) {
                Box(Modifier.fillMaxWidth(fraction.coerceIn(0f, 1f)).fillMaxHeight().clip(RoundedCornerShape(50)).background(Color(0xFFE8F25C)))
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatTile("Appris", fmt(store.learnedCount), Good, Modifier.weight(1f))
            StatTile("Restants", fmt(store.remaining), Warn, Modifier.weight(1f))
        }
        CardBox {
            Text("Détail", style = PosterTitle, fontSize = 18.sp, color = Ink)
            Text("Marqués appris à la main : ${fmt(store.markedCount)}", color = Ink)
            Text("Réussis au quiz : ${fmt(store.quizCount)}", color = Ink)
            Text("Total dans le fichier Excel : ${fmt(store.total)}", color = Ink)
            Text("Un mot réussi ou marqué appris est retiré du total restant.", fontSize = 12.sp, color = InkSoft)
        }
        CardBox {
            Text("Quiz", style = PosterTitle, fontSize = 18.sp, color = Ink)
            Text("Réponses : ${fmt(answered)} (${fmt(store.quizCorrect)} justes, ${fmt(store.quizWrong)} ratées)", color = Ink)
            Text("Taux de réussite : $rate %", color = Ink)
            Text("Temps moyen par réponse : ${"%.1f".format(avg)} s", color = Ink)
            Text("Meilleure série : ${store.bestStreak}", color = Ink)
        }
        CardBox {
            Text("Réinitialiser", style = PosterTitle, fontSize = 18.sp, color = Ink)
            PillButton("Réinitialiser les mots appris", Art.icRefresh, Bad, Modifier.fillMaxWidth(), filled = false) { confirm = 1 }
            PillButton("Réinitialiser le quiz", Art.icRefresh, Bad, Modifier.fillMaxWidth(), filled = false) { confirm = 2 }
            PillButton("Tout réinitialiser", Art.icTrash, Bad, Modifier.fillMaxWidth()) { confirm = 3 }
        }
        CardBox {
            Text("Fichier Excel", style = PosterTitle, fontSize = 18.sp, color = Ink)
            Text(
                if (store.imported) "Lexique chargé depuis un fichier que vous avez importé (${fmt(store.total)} mots)."
                else "Lexique chargé depuis le fichier Excel intégré à l'application (${fmt(store.total)} mots).",
                color = Ink
            )
            Text("Colonnes attendues : N°, Espagnol, Français, Prononciation.", fontSize = 12.sp, color = InkSoft)
            PillButton("Importer un autre fichier Excel", Art.icFolder, Navy, Modifier.fillMaxWidth(), filled = false) {
                picker.launch(arrayOf("*/*"))
            }
            if (store.imported) {
                PillButton("Revenir au fichier d'origine", Art.icRefresh, Navy, Modifier.fillMaxWidth(), filled = false) { confirm = 4 }
            }
            if (message != null) Text(message ?: "", fontSize = 13.sp, color = Forest, fontWeight = FontWeight.SemiBold)
        }
    }

    if (confirm != 0) {
        val (title, text) = when (confirm) {
            1 -> "Réinitialiser les mots appris ?" to "Tous les mots marqués « appris » repassent à apprendre. Les mots réussis au quiz sont conservés."
            2 -> "Réinitialiser le quiz ?" to "Les mots réussis au quiz reviennent dans le quiz et ses statistiques repartent de zéro."
            3 -> "Tout réinitialiser ?" to "Tous les mots reviennent à apprendre et les statistiques du quiz sont effacées."
            else -> "Revenir au fichier d'origine ?" to "Le lexique intégré est rechargé et la progression est remise à zéro."
        }
        ConfirmDialog(title, text, "Confirmer",
            onConfirm = {
                when (confirm) {
                    1 -> store.resetMarked()
                    2 -> store.resetQuiz()
                    3 -> store.resetAll()
                    else -> scope.launch { store.restoreOriginal() }
                }
                confirm = 0
            },
            onDismiss = { confirm = 0 }
        )
    }
}

// ============================================================================ Onglet 4 : rappels

@Composable
private fun ReminderTab() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var enabled by remember { mutableStateOf(LexiqueReminder.isEnabled(context)) }
    var hour by remember { mutableStateOf(LexiqueReminder.hour(context)) }
    var minute by remember { mutableStateOf(LexiqueReminder.minute(context)) }
    var showTime by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf<String?>(null) }

    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            LexiqueReminder.setEnabled(context, true)
            enabled = true
            note = null
        } else {
            note = "Les notifications sont refusées : autorisez-les dans les réglages du téléphone pour recevoir les rappels."
        }
    }

    fun setEnabled(on: Boolean) {
        if (!on) {
            LexiqueReminder.setEnabled(context, false)
            enabled = false
        } else if (LexiqueReminder.hasPermission(context)) {
            LexiqueReminder.setEnabled(context, true)
            enabled = true
            note = null
        } else {
            permission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        CardBox {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Rappel quotidien", style = PosterTitle, fontSize = 20.sp, color = Ink)
                    Text("Une notification avec le nombre de mots restants et un mot du jour.", color = InkSoft, fontSize = 13.sp)
                }
                Switch(checked = enabled, onCheckedChange = { setEnabled(it) })
            }
            Text(
                "Heure du rappel : ${"%02d:%02d".format(hour, minute)}",
                fontWeight = FontWeight.Bold, color = Ink, fontSize = 17.sp
            )
            PillButton("Changer l'heure", Art.icBulb, Navy, Modifier.fillMaxWidth(), filled = false) { showTime = true }
            PillButton("Envoyer un rappel test", Art.icVoice, Forest, Modifier.fillMaxWidth()) {
                if (LexiqueReminder.hasPermission(context)) {
                    scope.launch {
                        LexiqueReminder.notifyNow(context)
                        note = "Notification de test envoyée."
                    }
                } else {
                    permission.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }
            if (note != null) Text(note ?: "", fontSize = 13.sp, color = Forest, fontWeight = FontWeight.SemiBold)
        }
        CardBox {
            Text(
                "Le rappel est reprogrammé automatiquement après un redémarrage du téléphone. " +
                    "Sur certains téléphones, l'économie de batterie peut retarder la notification de quelques minutes.",
                fontSize = 12.sp, color = InkSoft
            )
        }
    }

    if (showTime) {
        val state = rememberTimePickerState(initialHour = hour, initialMinute = minute, is24Hour = true)
        AlertDialog(
            onDismissRequest = { showTime = false },
            confirmButton = {
                TextButton(onClick = {
                    hour = state.hour
                    minute = state.minute
                    LexiqueReminder.setTime(context, hour, minute)
                    if (enabled) LexiqueReminder.schedule(context)
                    showTime = false
                }) { Text("OK", fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { showTime = false }) { Text("Annuler") } },
            text = { TimePicker(state = state) }
        )
    }
}
