package com.linguavibe.app.lexique

import android.content.Context
import android.net.Uri
import android.util.Xml
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayInputStream
import java.io.File
import java.io.InputStream
import java.text.Normalizer
import java.util.zip.ZipInputStream

// ============================================================================ Modèle

/** Une entrée du lexique : numéro du fichier Excel, espagnol, français, prononciation figurée. */
data class LexiqueWord(
    val id: Int,
    val es: String,
    val fr: String,
    val phon: String
) {
    /** Texte de recherche sans accents ni majuscules (calculé une seule fois). */
    val search: String = normalize("$es $fr")
}

fun normalize(text: String): String =
    Normalizer.normalize(text.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")

// ============================================================================ Lecture du fichier Excel

/**
 * Lecteur .xlsx minimal (sans bibliothèque externe) : un .xlsx est une archive ZIP de fichiers XML.
 * Colonnes attendues : A = N°, B = Espagnol, C = Français, D = Prononciation.
 * Les lignes dont la colonne A n'est pas un nombre (titres, en-têtes) sont ignorées.
 */
object XlsxReader {
    private const val DEFAULT_SHEET = "Lexique complet"

    fun readWords(input: InputStream): List<LexiqueWord> {
        val files = HashMap<String, ByteArray>()
        ZipInputStream(input).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                val name = entry.name
                if (name == "xl/sharedStrings.xml" || name == "xl/workbook.xml" ||
                    name == "xl/_rels/workbook.xml.rels" || name.startsWith("xl/worksheets/sheet")
                ) {
                    files[name] = zip.readBytes()
                }
                entry = zip.nextEntry
            }
        }
        val shared = files["xl/sharedStrings.xml"]?.let { parseSharedStrings(it) } ?: emptyList()
        val sheetPath = findSheetPath(files) ?: "xl/worksheets/sheet1.xml"
        val sheet = files[sheetPath] ?: throw IllegalStateException("Feuille Excel introuvable dans le fichier.")
        return parseSheet(sheet, shared)
    }

    /** Retrouve la feuille « Lexique complet » (sinon la première feuille). */
    private fun findSheetPath(files: Map<String, ByteArray>): String? {
        val workbook = files["xl/workbook.xml"] ?: return null
        val rels = files["xl/_rels/workbook.xml.rels"] ?: return null
        var rid: String? = null
        var firstRid: String? = null
        run {
            val p = Xml.newPullParser()
            p.setInput(ByteArrayInputStream(workbook), "UTF-8")
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG && p.name == "sheet") {
                    var r: String? = null
                    for (i in 0 until p.attributeCount) {
                        val an = p.getAttributeName(i)
                        if (an == "r:id" || an == "id") r = p.getAttributeValue(i)
                    }
                    if (firstRid == null) firstRid = r
                    if (p.getAttributeValue(null, "name") == DEFAULT_SHEET) rid = r
                }
                ev = p.next()
            }
        }
        val wanted = rid ?: firstRid ?: return null
        val p = Xml.newPullParser()
        p.setInput(ByteArrayInputStream(rels), "UTF-8")
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG && p.name == "Relationship" && p.getAttributeValue(null, "Id") == wanted) {
                val target = p.getAttributeValue(null, "Target") ?: return null
                return if (target.startsWith("/")) target.removePrefix("/") else "xl/$target"
            }
            ev = p.next()
        }
        return null
    }

    private fun parseSharedStrings(bytes: ByteArray): List<String> {
        val out = ArrayList<String>()
        val p = Xml.newPullParser()
        p.setInput(ByteArrayInputStream(bytes), "UTF-8")
        val sb = StringBuilder()
        var inT = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> when (p.name) {
                    "si" -> sb.setLength(0)
                    "t" -> inT = true
                }
                XmlPullParser.TEXT -> if (inT) sb.append(p.text)
                XmlPullParser.END_TAG -> when (p.name) {
                    "t" -> inT = false
                    "si" -> out.add(sb.toString())
                }
            }
            ev = p.next()
        }
        return out
    }

    private fun parseSheet(bytes: ByteArray, shared: List<String>): List<LexiqueWord> {
        val out = ArrayList<LexiqueWord>(10_500)
        val seen = HashSet<Int>()
        val cells = HashMap<String, String>()
        val sb = StringBuilder()
        var col = ""
        var type: String? = null
        var capture = false
        val p = Xml.newPullParser()
        p.setInput(ByteArrayInputStream(bytes), "UTF-8")
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> when (p.name) {
                    "row" -> cells.clear()
                    "c" -> {
                        col = (p.getAttributeValue(null, "r") ?: "").takeWhile { it.isLetter() }
                        type = p.getAttributeValue(null, "t")
                        sb.setLength(0)
                    }
                    "v", "t" -> capture = true
                }
                XmlPullParser.TEXT -> if (capture) sb.append(p.text)
                XmlPullParser.END_TAG -> when (p.name) {
                    "v", "t" -> capture = false
                    "c" -> {
                        val raw = sb.toString()
                        cells[col] = if (type == "s") shared.getOrElse(raw.trim().toIntOrNull() ?: -1) { "" } else raw
                    }
                    "row" -> {
                        val id = cells["A"]?.trim()?.toDoubleOrNull()?.toInt()
                        val es = cells["B"]?.trim().orEmpty()
                        val fr = cells["C"]?.trim().orEmpty()
                        if (id != null && es.isNotEmpty() && fr.isNotEmpty() && seen.add(id)) {
                            out.add(LexiqueWord(id, es, fr, cells["D"]?.trim().orEmpty()))
                        }
                    }
                }
            }
            ev = p.next()
        }
        return out
    }
}

// ============================================================================ Chargement (asset ou fichier importé)

object LexiqueRepository {
    private const val ASSET = "lexique/Lexique_10000.xlsx"
    private const val IMPORTED = "lexique_importe.xlsx"

    fun importedFile(context: Context) = File(context.filesDir, IMPORTED)
    fun isImported(context: Context) = importedFile(context).exists()

    /** Charge le fichier Excel importé s'il existe et est valide, sinon celui intégré à l'application. */
    fun load(context: Context): List<LexiqueWord> {
        val imported = importedFile(context)
        if (imported.exists()) {
            try {
                val list = imported.inputStream().use { XlsxReader.readWords(it) }
                if (list.isNotEmpty()) return list
            } catch (_: Exception) {
                // Fichier importé illisible : retour au lexique d'origine.
            }
        }
        return context.assets.open(ASSET).use { XlsxReader.readWords(it) }
    }

    /** Importe un autre fichier Excel (même format de colonnes). Renvoie le nombre de mots lus. */
    fun importFrom(context: Context, uri: Uri): Int {
        val tmp = File(context.cacheDir, "import_tmp.xlsx")
        context.contentResolver.openInputStream(uri)?.use { input -> tmp.outputStream().use { input.copyTo(it) } }
            ?: throw IllegalStateException("Fichier illisible.")
        val words = tmp.inputStream().use { XlsxReader.readWords(it) }
        if (words.isEmpty()) {
            tmp.delete()
            throw IllegalStateException("Aucun mot trouvé : colonnes attendues N°, Espagnol, Français, Prononciation.")
        }
        val dest = importedFile(context)
        dest.delete()
        tmp.copyTo(dest, overwrite = true)
        tmp.delete()
        return words.size
    }

    fun removeImported(context: Context) {
        importedFile(context).delete()
    }
}

// ============================================================================ Room : état de chaque mot

@Entity(tableName = "word_state")
data class WordState(
    @PrimaryKey val id: Int,
    val marked: Boolean = false,
    val quizPassed: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)

@Dao
interface WordStateDao {
    @Query("SELECT * FROM word_state")
    suspend fun all(): List<WordState>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(state: WordState)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(states: List<WordState>)

    @Query("DELETE FROM word_state WHERE id = :id")
    suspend fun delete(id: Int)

    @Query("DELETE FROM word_state")
    suspend fun clear()

    @Query("UPDATE word_state SET marked = 0")
    suspend fun clearMarked()

    @Query("UPDATE word_state SET quizPassed = 0")
    suspend fun clearQuiz()

    @Query("DELETE FROM word_state WHERE marked = 0 AND quizPassed = 0")
    suspend fun purge()
}

@Database(entities = [WordState::class], version = 1, exportSchema = false)
abstract class LexiqueDatabase : RoomDatabase() {
    abstract fun dao(): WordStateDao

    companion object {
        @Volatile private var instance: LexiqueDatabase? = null
        fun get(context: Context): LexiqueDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext, LexiqueDatabase::class.java, "linguavibe_lexique.db"
            ).build().also { instance = it }
        }
    }
}

// ============================================================================ Store observable par l'interface

/**
 * État du lexique partagé par les cartes, le quiz et le tableau de bord.
 * Chaque mot a un drapeau : 1 = marqué appris à la main, 2 = réussi au quiz.
 * Un mot dont le drapeau n'est pas 0 est « appris » : il sort du total restant et du quiz.
 */
class LexiqueStore private constructor(context: Context) {
    private val app = context.applicationContext
    private val dao = LexiqueDatabase.get(app).dao()
    private val sp = app.getSharedPreferences("lexique", Context.MODE_PRIVATE)
    private val io = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    var words by mutableStateOf<List<LexiqueWord>>(emptyList())
        private set
    var loading by mutableStateOf(true)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var imported by mutableStateOf(LexiqueRepository.isImported(app))
        private set

    /** id du mot -> drapeaux (1 = marqué, 2 = réussi au quiz). Absent = à apprendre. */
    val flags = mutableStateMapOf<Int, Int>()

    var markedCount by mutableIntStateOf(0)
        private set
    var quizCount by mutableIntStateOf(0)
        private set
    var learnedCount by mutableIntStateOf(0)
        private set

    // Statistiques cumulées du quiz
    var quizCorrect by mutableIntStateOf(sp.getInt("quiz_correct", 0))
        private set
    var quizWrong by mutableIntStateOf(sp.getInt("quiz_wrong", 0))
        private set
    var quizMillis by mutableStateOf(sp.getLong("quiz_millis", 0L))
        private set
    var bestStreak by mutableIntStateOf(sp.getInt("quiz_best_streak", 0))
        private set

    private var loaded = false

    val total: Int get() = words.size
    val remaining: Int get() = (words.size - learnedCount).coerceAtLeast(0)

    fun flagOf(id: Int): Int = flags[id] ?: 0
    fun isLearned(id: Int): Boolean = flagOf(id) != 0

    /** Mots encore à apprendre (hors mots marqués ou réussis). */
    fun pool(): List<LexiqueWord> = words.filter { flagOf(it.id) == 0 }

    suspend fun load(force: Boolean = false) {
        if (loaded && !force) return
        loading = true
        error = null
        try {
            val list = withContext(Dispatchers.IO) { LexiqueRepository.load(app) }
            val saved = withContext(Dispatchers.IO) { dao.all() }
            val ids = HashSet<Int>(list.size * 2)
            list.forEach { ids.add(it.id) }
            val map = HashMap<Int, Int>()
            saved.forEach {
                if (it.id in ids) {
                    val f = (if (it.marked) 1 else 0) or (if (it.quizPassed) 2 else 0)
                    if (f != 0) map[it.id] = f
                }
            }
            words = list
            flags.clear()
            flags.putAll(map)
            imported = LexiqueRepository.isImported(app)
            recount()
            loaded = true
        } catch (e: Throwable) {
            error = "Impossible de charger le fichier Excel : ${e.message ?: e.javaClass.simpleName}"
        }
        loading = false
    }

    private fun recount() {
        var m = 0
        var q = 0
        var l = 0
        for (f in flags.values) {
            if ((f and 1) != 0) m++
            if ((f and 2) != 0) q++
            if (f != 0) l++
        }
        markedCount = m
        quizCount = q
        learnedCount = l
    }

    private fun setFlag(id: Int, f: Int) {
        if (f == 0) {
            flags.remove(id)
        } else {
            flags[id] = f
        }
        recount()
        io.launch {
            if (f == 0) {
                dao.delete(id)
            } else {
                dao.upsert(WordState(id, marked = (f and 1) != 0, quizPassed = (f and 2) != 0))
            }
        }
    }

    /** Marque un mot comme appris (il passe au vert). */
    fun mark(id: Int) = setFlag(id, flagOf(id) or 1)

    /** Remet un mot à apprendre (efface « appris » et « réussi au quiz »). */
    fun resetWord(id: Int) = setFlag(id, 0)

    /** Mot réussi au quiz : il ne reviendra plus. */
    fun markQuizPassed(id: Int) = setFlag(id, flagOf(id) or 2)

    fun resetMarked() {
        val copy = HashMap<Int, Int>()
        for ((id, f) in flags) {
            val n = f and 1.inv()
            if (n != 0) copy[id] = n
        }
        flags.clear()
        flags.putAll(copy)
        recount()
        io.launch { dao.clearMarked(); dao.purge() }
    }

    fun resetQuiz() {
        val copy = HashMap<Int, Int>()
        for ((id, f) in flags) {
            val n = f and 2.inv()
            if (n != 0) copy[id] = n
        }
        flags.clear()
        flags.putAll(copy)
        recount()
        quizCorrect = 0
        quizWrong = 0
        quizMillis = 0L
        bestStreak = 0
        sp.edit().putInt("quiz_correct", 0).putInt("quiz_wrong", 0)
            .putLong("quiz_millis", 0L).putInt("quiz_best_streak", 0).apply()
        io.launch { dao.clearQuiz(); dao.purge() }
    }

    fun resetAll() {
        flags.clear()
        recount()
        quizCorrect = 0
        quizWrong = 0
        quizMillis = 0L
        bestStreak = 0
        sp.edit().putInt("quiz_correct", 0).putInt("quiz_wrong", 0)
            .putLong("quiz_millis", 0L).putInt("quiz_best_streak", 0).apply()
        io.launch { dao.clear() }
    }

    fun recordAnswer(correct: Boolean, millis: Long, streak: Int) {
        if (correct) quizCorrect++ else quizWrong++
        quizMillis += millis.coerceAtLeast(0)
        if (streak > bestStreak) bestStreak = streak
        sp.edit().putInt("quiz_correct", quizCorrect).putInt("quiz_wrong", quizWrong)
            .putLong("quiz_millis", quizMillis).putInt("quiz_best_streak", bestStreak).apply()
    }

    /** Importe un autre fichier Excel ; la progression est remise à zéro car les numéros changent. */
    suspend fun importExcel(uri: Uri): Int {
        val count = withContext(Dispatchers.IO) { LexiqueRepository.importFrom(app, uri) }
        withContext(Dispatchers.IO) { dao.clear() }
        resetAll()
        load(force = true)
        return count
    }

    suspend fun restoreOriginal() {
        withContext(Dispatchers.IO) { LexiqueRepository.removeImported(app); dao.clear() }
        resetAll()
        load(force = true)
    }

    companion object {
        @Volatile private var instance: LexiqueStore? = null
        fun get(context: Context): LexiqueStore = instance ?: synchronized(this) {
            instance ?: LexiqueStore(context.applicationContext).also { instance = it }
        }
    }
}
