package com.linguavibe.app.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.speech.tts.TextToSpeech
import androidx.compose.runtime.DisposableEffect
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linguavibe.app.data.Languages
import com.linguavibe.app.speech.VoicePacks
import com.linguavibe.app.speech.VoiceSettings
import kotlinx.coroutines.launch

/** Phrases d'essai pour chaque langue. */
private val samples = listOf(
    "es" to "Hola, bienvenido a tu clase de español.",
    "en" to "Hello, welcome to your English lesson.",
    "pt" to "Olá, bem-vindo à sua aula de português.",
    "ru" to "Здравствуйте, добро пожаловать на урок.",
    "zh" to "你好，欢迎来上中文课。",
    "ar" to "مرحبا، أهلا بك في درس اللغة العربية."
)

/** Choix de la voix de l'appli et essai des voix. */
@Composable
fun VoiceEngineSection() {
    val speaker = LocalSpeaker.current
    val settings = speaker.settings

    CardBox {
        Text("Voix utilisée pour lire les leçons", style = PosterTitle, fontSize = 17.sp, color = Ink)
        listOf(
            VoiceSettings.ENGINE_AUTO to "Voix Google de l'appli (gratuite, sans clé, rapide). Internet requis la première fois pour chaque phrase",
            VoiceSettings.ENGINE_ELEVEN to "ElevenLabs en priorité (clé API, voix très naturelle)"
        ).forEach { (id, label) ->
            val selected = settings.engine == id ||
                (id == VoiceSettings.ENGINE_AUTO && settings.engine != VoiceSettings.ENGINE_ELEVEN)
            ChoiceRow(label, selected, Ruby) { settings.updateEngine(id) }
        }
        Text(
            "La voix du téléphone n'est pas utilisée. Chaque phrase écoutée est gardée sur le téléphone : " +
                "elle se relit ensuite instantanément, même sans connexion.",
            fontSize = 12.sp, color = InkSoft
        )
    }

    CardBox {
        Text("Essayer les voix", style = PosterTitle, fontSize = 17.sp, color = Ink)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            samples.forEach { (code, sentence) ->
                val lang = Languages.byCode(code)
                Box(
                    Modifier.weight(1f).clickable { speaker.speak(sentence, lang.locale) },
                    contentAlignment = Alignment.Center
                ) { LangBadge(code, 42.dp) }
            }
        }
        if (speaker.lastEngine.isNotBlank()) {
            Text("Dernière phrase lue par : ${speaker.lastEngine}", fontSize = 13.sp, color = InkSoft)
        }
        speaker.lastError?.let { StatusLine(it, -1) }
    }
}

/** Téléchargement des voix, une fois par langue, pour tout lire sans Internet. */
@Composable
fun VoicePacksSection() {
    val context = LocalContext.current
    CardBox {
        Text("Télécharger les voix (une seule fois)", style = PosterTitle, fontSize = 17.sp, color = Ink)
        Text(
            "Enregistre sur le téléphone tout l'audio des cours d'une langue. Ensuite, la voix de l'appli " +
                "fonctionne sans Internet. Faites-le en Wi-Fi, appli ouverte ; une langue prend quelques minutes. " +
                "Si le téléchargement s'arrête, relancez-le : il reprend où il en était.",
            fontSize = 14.sp, color = InkSoft
        )
        Languages.courses.filter { it.available }.forEach { lang ->
            val state = VoicePacks.progress[lang.code]
            val done = state == null && VoicePacks.isDone(context, lang.code) ||
                (state != null && !state.running && state.total > 0 && state.done >= state.total)
            Column(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    LangBadge(lang.code, 34.dp)
                    Column(Modifier.weight(1f)) {
                        Text(lang.name, fontWeight = FontWeight.SemiBold, color = Ink)
                        Text(
                            when {
                                state?.running == true && state.total > 0 -> "${state.done} / ${state.total} phrases"
                                state?.running == true -> "Préparation…"
                                done -> "Voix téléchargée"
                                else -> "Non téléchargée"
                            },
                            fontSize = 12.sp, color = if (done) Good else InkSoft
                        )
                    }
                    when {
                        state?.running == true ->
                            PillButton("Arrêter", Art.icStop, Bad, filled = false) { VoicePacks.cancel(lang.code) }
                        done -> Unit
                        else ->
                            PillButton(
                                if (state != null && state.done > 0) "Reprendre" else "Télécharger",
                                Art.icDownload, Ruby
                            ) { VoicePacks.start(context, lang.code) }
                    }
                }
                if (state?.running == true && state.total > 0) {
                    LinearProgressIndicator(
                        progress = { state.done.toFloat() / state.total },
                        modifier = Modifier.fillMaxWidth(), color = Ruby
                    )
                }
                state?.message?.let { Text(it, fontSize = 12.sp, color = Bad) }
            }
        }
    }
}
