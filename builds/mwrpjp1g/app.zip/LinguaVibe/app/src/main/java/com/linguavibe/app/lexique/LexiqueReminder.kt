package com.linguavibe.app.lexique

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.linguavibe.app.MainActivity
import com.linguavibe.app.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.NumberFormat
import java.util.Calendar
import java.util.concurrent.TimeUnit

/** Rappel quotidien : « il vous reste N mots » + un mot à réviser. */
object LexiqueReminder {
    const val CHANNEL_ID = "lexique_rappels"
    private const val WORK_NAME = "lexique_rappel_quotidien"
    private const val NOTIF_ID = 4201

    private fun sp(context: Context) = context.getSharedPreferences("lexique", Context.MODE_PRIVATE)

    fun isEnabled(context: Context) = sp(context).getBoolean("reminder_on", false)
    fun hour(context: Context) = sp(context).getInt("reminder_hour", 19)
    fun minute(context: Context) = sp(context).getInt("reminder_minute", 0)

    fun setTime(context: Context, hour: Int, minute: Int) {
        sp(context).edit().putInt("reminder_hour", hour).putInt("reminder_minute", minute).apply()
    }

    fun setEnabled(context: Context, enabled: Boolean) {
        sp(context).edit().putBoolean("reminder_on", enabled).apply()
        if (enabled) schedule(context) else cancel(context)
    }

    fun hasPermission(context: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel(CHANNEL_ID, "Rappels du lexique", NotificationManager.IMPORTANCE_DEFAULT)
        channel.description = "Rappel quotidien pour réviser le lexique espagnol"
        manager.createNotificationChannel(channel)
    }

    /** Délai avant la prochaine occurrence de l'heure choisie. */
    private fun delayUntilNext(hour: Int, minute: Int): Long {
        val now = System.currentTimeMillis()
        val cal = Calendar.getInstance().apply {
            timeInMillis = now
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (cal.timeInMillis <= now + 1_000L) cal.add(Calendar.DAY_OF_MONTH, 1)
        return cal.timeInMillis - now
    }

    /** (Re)programme le rappel quotidien à l'heure choisie. Survit au redémarrage du téléphone. */
    fun schedule(context: Context) {
        val app = context.applicationContext
        if (!isEnabled(app)) return
        createChannel(app)
        val request = PeriodicWorkRequestBuilder<ReminderWorker>(1, TimeUnit.DAYS)
            .setInitialDelay(delayUntilNext(hour(app), minute(app)), TimeUnit.MILLISECONDS)
            .build()
        WorkManager.getInstance(app)
            .enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.CANCEL_AND_REENQUEUE, request)
    }

    fun cancel(context: Context) {
        WorkManager.getInstance(context.applicationContext).cancelUniqueWork(WORK_NAME)
    }

    /** Construit et affiche la notification (utilisé par le rappel quotidien et par le bouton « tester »). */
    suspend fun notifyNow(context: Context) {
        val app = context.applicationContext
        if (!hasPermission(app) || !NotificationManagerCompat.from(app).areNotificationsEnabled()) return
        createChannel(app)

        val (title, text) = withContext(Dispatchers.IO) {
            val words = LexiqueRepository.load(app)
            val states = LexiqueDatabase.get(app).dao().all()
            val learnedIds = states.filter { it.marked || it.quizPassed }.map { it.id }.toHashSet()
            val left = words.filter { it.id !in learnedIds }
            val nf = NumberFormat.getInstance()
            if (left.isEmpty()) {
                "Lexique espagnol terminé !" to "Bravo, vous avez appris les ${nf.format(words.size)} mots."
            } else {
                val w = left.random()
                "Il vous reste ${nf.format(left.size)} mots à apprendre" to
                    "Mot du jour : « ${w.es} » ${w.phon} = ${w.fr}. Faites un quiz de 2 minutes !"
            }
        }

        val open = PendingIntent.getActivity(
            app, 0, Intent(app, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(app, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_reminder)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        try {
            NotificationManagerCompat.from(app).notify(NOTIF_ID, notification)
        } catch (_: SecurityException) {
            // Permission de notification retirée entre-temps.
        }
    }
}

class ReminderWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        if (!LexiqueReminder.isEnabled(applicationContext)) return Result.success()
        return try {
            LexiqueReminder.notifyNow(applicationContext)
            Result.success()
        } catch (_: Exception) {
            Result.retry()
        }
    }
}
