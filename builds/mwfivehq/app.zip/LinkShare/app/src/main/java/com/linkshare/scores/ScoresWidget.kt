package com.linkshare.scores

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.app.PendingIntent
import android.graphics.Color
import android.widget.RemoteViews
import com.linkshare.R
import java.text.DateFormat
import java.util.Date
import kotlin.concurrent.thread

/**
 * Widget « Scores » : jusqu'à 6 matchs (en direct d'abord). Se met à jour toutes les 30 minutes, à chaque rafraîchissement
 * de la notification, et au toucher du bouton ↻. Toucher le widget ouvre l'écran Scores.
 */
class ScoresWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        render(context)
        refreshAsync(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == ACTION_REFRESH) { render(context); refreshAsync(context) } else super.onReceive(context, intent)
    }

    private fun refreshAsync(ctx: Context) {
        val pending = goAsync()
        thread {
            try { runCatching { ScoresRepo.fetch(ctx) }; render(ctx) } finally { pending.finish() }
        }
    }

    companion object {
        const val ACTION_REFRESH = "com.linkshare.scores.REFRESH"
        private val HOME = intArrayOf(R.id.w_h1, R.id.w_h2, R.id.w_h3, R.id.w_h4, R.id.w_h5, R.id.w_h6)
        private val SCORE = intArrayOf(R.id.w_s1, R.id.w_s2, R.id.w_s3, R.id.w_s4, R.id.w_s5, R.id.w_s6)
        private val AWAY = intArrayOf(R.id.w_a1, R.id.w_a2, R.id.w_a3, R.id.w_a4, R.id.w_a5, R.id.w_a6)
        private val STATUS = intArrayOf(R.id.w_t1, R.id.w_t2, R.id.w_t3, R.id.w_t4, R.id.w_t5, R.id.w_t6)
        private val ROW = intArrayOf(R.id.w_r1, R.id.w_r2, R.id.w_r3, R.id.w_r4, R.id.w_r5, R.id.w_r6)

        /** Redessine tous les widgets à partir des derniers scores connus. */
        fun render(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, ScoresWidget::class.java))
            if (ids.isEmpty()) return
            mgr.updateAppWidget(ids, build(ctx))
        }

        private fun build(ctx: Context): RemoteViews {
            val v = RemoteViews(ctx.packageName, R.layout.widget_scores)
            val wanted = ScoresPrefs.leagues(ctx)
            val all = ScoresRepo.cached(ctx).filter { it.leaguePath in wanted }
            val shown = (all.filter { it.live } + all.filter { !it.live && it.state == MatchState.PRE } + all.filter { it.state == MatchState.POST }.reversed())
                .distinctBy { it.id }.take(6)
            for (i in 0 until 6) {
                val m = shown.getOrNull(i)
                if (m == null) { v.setViewVisibility(ROW[i], android.view.View.GONE); continue }
                v.setViewVisibility(ROW[i], android.view.View.VISIBLE)
                v.setTextViewText(HOME[i], m.home); v.setTextViewText(AWAY[i], m.away)
                v.setTextViewText(SCORE[i], m.scoreText); v.setTextViewText(STATUS[i], m.status)
                v.setTextColor(STATUS[i], if (m.live) Color.parseColor("#FF5252") else Color.parseColor("#9AA0A6"))
            }
            v.setViewVisibility(R.id.w_empty, if (shown.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE)
            val at = ScoresPrefs.cacheAt(ctx)
            v.setTextViewText(R.id.w_updated, if (at > 0) DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(at)) else "")
            val refresh = PendingIntent.getBroadcast(
                ctx, 9, Intent(ctx, ScoresWidget::class.java).setAction(ACTION_REFRESH), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
            v.setOnClickPendingIntent(R.id.w_refresh, refresh)
            v.setOnClickPendingIntent(R.id.w_root, ScoresService.openApp(ctx))
            return v
        }
    }
}
