package com.linkshare.ui

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.LruCache
import android.util.Xml
import androidx.compose.foundation.Image
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.io.InputStream
import java.util.zip.ZipFile

/** Formats dont le contenu s'affiche dans l'appli (sans bibliothèque externe). */
internal val VIEW_OFFICE = setOf("docx", "xlsx", "pptx", "odt", "ods", "odp", "rtf")

private const val MAX_PART_CHARS = 400_000
private const val MAX_ROWS = 3000
private const val MAX_COLS = 60

/** Une partie lisible d'un document : une feuille, une diapositive, ou le texte entier. */
internal class OfficePart(val title: String?, val text: String, val table: Boolean = false)

private fun newParser(input: InputStream): XmlPullParser =
    Xml.newPullParser().apply { setInput(input, null) }

private fun String.local() = substringAfter(':')

private fun ZipFile.read(name: String): InputStream? = getEntry(name)?.let { getInputStream(it) }

private fun StringBuilder.capped() = length < MAX_PART_CHARS

/** Lit le contenu texte d'un document ; lève une exception si le fichier est illisible. */
internal fun readOffice(f: File, quick: Boolean = false): List<OfficePart> = when (f.extension.lowercase()) {
    "docx" -> ZipFile(f).use { listOf(OfficePart(null, docxText(it, if (quick) 4000 else MAX_PART_CHARS))) }
    "xlsx" -> ZipFile(f).use { xlsxParts(it, quick) }
    "pptx" -> ZipFile(f).use { pptxParts(it, quick) }
    "odt", "ods", "odp" -> ZipFile(f).use { odfParts(it, f.extension.lowercase()) }
    "rtf" -> listOf(OfficePart(null, rtfText(f.readBytes())))
    else -> emptyList()
}

// ───────────────────────────── Word ─────────────────────────────

private fun docxText(zip: ZipFile, limit: Int): String {
    val sb = StringBuilder()
    val input = zip.read("word/document.xml") ?: error("Document Word invalide")
    input.use {
        val p = newParser(it)
        var inText = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT && sb.length < limit) {
            when (ev) {
                XmlPullParser.START_TAG -> when (p.name.local()) {
                    "t" -> inText = true
                    "tab" -> sb.append('\t')
                    "br", "cr" -> sb.append('\n')
                }
                XmlPullParser.TEXT -> if (inText) sb.append(p.text)
                XmlPullParser.END_TAG -> when (p.name.local()) {
                    "t" -> inText = false
                    "p" -> sb.append('\n')
                    "tc" -> sb.append("  │  ")
                    "tr" -> sb.append('\n')
                }
            }
            ev = p.next()
        }
    }
    return sb.toString().replace(Regex("(  │  )+\n"), "\n").replace(Regex("\n{3,}"), "\n\n").trim()
}

// ───────────────────────────── Excel ─────────────────────────────

private fun sharedStrings(zip: ZipFile): List<String> {
    val out = ArrayList<String>()
    val input = zip.read("xl/sharedStrings.xml") ?: return out
    input.use {
        val p = newParser(it)
        val cur = StringBuilder()
        var inT = false
        var inPhonetic = false
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> when (p.name.local()) {
                    "si" -> cur.setLength(0)
                    "rPh" -> inPhonetic = true
                    "t" -> inT = !inPhonetic
                }
                XmlPullParser.TEXT -> if (inT) cur.append(p.text)
                XmlPullParser.END_TAG -> when (p.name.local()) {
                    "t" -> inT = false
                    "rPh" -> inPhonetic = false
                    "si" -> out.add(cur.toString())
                }
            }
            ev = p.next()
        }
    }
    return out
}

/** « AB12 » → index de colonne 27 (base 0). */
private fun colIndex(ref: String): Int {
    var n = 0
    for (c in ref) {
        if (c in 'A'..'Z') n = n * 26 + (c - 'A' + 1) else break
    }
    return (n - 1).coerceAtLeast(0)
}

private fun xlsxParts(zip: ZipFile, quick: Boolean = false): List<OfficePart> {
    val strings = sharedStrings(zip)
    // Noms des feuilles + fichier correspondant (workbook.xml + ses relations)
    val sheets = ArrayList<Pair<String, String>>() // (nom, rId)
    zip.read("xl/workbook.xml")?.use {
        val p = newParser(it)
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG && p.name.local() == "sheet") {
                var name = ""; var rid = ""
                for (i in 0 until p.attributeCount) {
                    val a = p.getAttributeName(i)
                    if (a == "name") name = p.getAttributeValue(i)
                    else if (a.local() == "id") rid = p.getAttributeValue(i)
                }
                sheets.add(name to rid)
            }
            ev = p.next()
        }
    }
    val targets = HashMap<String, String>()
    zip.read("xl/_rels/workbook.xml.rels")?.use {
        val p = newParser(it)
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG && p.name.local() == "Relationship") {
                val id = p.getAttributeValue(null, "Id") ?: ""
                val t = p.getAttributeValue(null, "Target") ?: ""
                targets[id] = if (t.startsWith("/")) t.removePrefix("/") else "xl/$t"
            }
            ev = p.next()
        }
    }
    val parts = ArrayList<OfficePart>()
    (if (quick) sheets.take(1) else sheets).forEachIndexed { i, (name, rid) ->
        val path = targets[rid] ?: "xl/worksheets/sheet${i + 1}.xml"
        val input = zip.read(path) ?: return@forEachIndexed
        val rows = input.use { sheetRows(it, strings, if (quick) 40 else MAX_ROWS) }
        parts.add(OfficePart(name, alignTable(rows), table = true))
    }
    if (parts.isEmpty()) error("Classeur Excel vide ou invalide")
    return parts
}

private fun sheetRows(input: InputStream, strings: List<String>, rowLimit: Int): List<List<String>> {
    val rows = ArrayList<List<String>>()
    val p = newParser(input)
    var row = ArrayList<String>()
    var col = 0
    var type = ""
    var inV = false
    var inT = false
    val v = StringBuilder()
    var ev = p.eventType
    while (ev != XmlPullParser.END_DOCUMENT && rows.size < rowLimit) {
        when (ev) {
            XmlPullParser.START_TAG -> when (p.name.local()) {
                "row" -> row = ArrayList()
                "c" -> {
                    col = colIndex(p.getAttributeValue(null, "r") ?: "")
                    type = p.getAttributeValue(null, "t") ?: ""
                    v.setLength(0)
                }
                "v" -> inV = true
                "t" -> inT = true
            }
            XmlPullParser.TEXT -> if (inV || inT) v.append(p.text)
            XmlPullParser.END_TAG -> when (p.name.local()) {
                "v" -> inV = false
                "t" -> inT = false
                "c" -> {
                    if (col < MAX_COLS) {
                        val raw = v.toString()
                        val shown = when (type) {
                            "s" -> strings.getOrNull(raw.trim().toIntOrNull() ?: -1) ?: ""
                            "b" -> if (raw.trim() == "1") "VRAI" else "FAUX"
                            else -> raw
                        }
                        while (row.size < col) row.add("")
                        if (row.size == col) row.add(shown) else row[col] = shown
                    }
                }
                "row" -> rows.add(row)
            }
        }
        ev = p.next()
    }
    return rows
}

/** Met les lignes en colonnes alignées (police à chasse fixe). */
private fun alignTable(rows: List<List<String>>): String {
    val clean = rows.map { r -> r.map { it.replace('\n', ' ').replace('\t', ' ').trim() } }
        .dropLastWhile { r -> r.all { it.isEmpty() } }
    if (clean.isEmpty()) return "(feuille vide)"
    val cols = clean.maxOf { it.size }
    val widths = IntArray(cols)
    for (r in clean) for (i in r.indices) widths[i] = maxOf(widths[i], minOf(r[i].length, 40))
    val sb = StringBuilder()
    for (r in clean) {
        for (i in 0 until cols) {
            val cell = r.getOrElse(i) { "" }.let { if (it.length > 40) it.take(39) + "…" else it }
            sb.append(cell.padEnd(widths[i]))
            if (i < cols - 1) sb.append(" │ ")
        }
        sb.append('\n')
        if (sb.length > MAX_PART_CHARS) { sb.append("… (aperçu limité)"); break }
    }
    return sb.toString().lines().joinToString("\n") { it.trimEnd() }
}

// ───────────────────────────── PowerPoint ─────────────────────────────

private fun pptxParts(zip: ZipFile, quick: Boolean = false): List<OfficePart> {
    val names = zip.entries().asSequence().map { it.name }
        .filter { Regex("ppt/slides/slide\\d+\\.xml").matches(it) }
        .sortedBy { it.filter { c -> c.isDigit() }.toIntOrNull() ?: 0 }
        .toList().let { if (quick) it.take(1) else it }
    if (names.isEmpty()) error("Présentation vide ou invalide")
    return names.mapIndexed { i, n ->
        val sb = StringBuilder()
        zip.read(n)?.use {
            val p = newParser(it)
            var inT = false
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT && sb.capped()) {
                when (ev) {
                    XmlPullParser.START_TAG -> if (p.name.local() == "t") inT = true
                    XmlPullParser.TEXT -> if (inT) sb.append(p.text)
                    XmlPullParser.END_TAG -> when (p.name.local()) {
                        "t" -> inT = false
                        "p" -> sb.append('\n')
                    }
                }
                ev = p.next()
            }
        }
        OfficePart("Diapositive ${i + 1}", sb.toString().replace(Regex("\n{3,}"), "\n\n").trim().ifEmpty { "(aucun texte)" })
    }
}

// ───────────────────────────── OpenDocument ─────────────────────────────

private fun odfParts(zip: ZipFile, ext: String): List<OfficePart> {
    val input = zip.read("content.xml") ?: error("Document OpenDocument invalide")
    val parts = ArrayList<OfficePart>()
    val sb = StringBuilder()
    var title: String? = null
    var rows = ArrayList<List<String>>()
    var row = ArrayList<String>()
    val cell = StringBuilder()
    var inTable = 0
    var slide = 0
    fun flush() {
        if (ext == "ods") {
            if (rows.isNotEmpty()) parts.add(OfficePart(title, alignTable(rows), table = true))
            rows = ArrayList()
        } else if (sb.isNotBlank()) {
            parts.add(OfficePart(title, sb.toString().replace(Regex("\n{3,}"), "\n\n").trim()))
            sb.setLength(0)
        }
    }
    input.use {
        val p = newParser(it)
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> when (p.name) {
                    "table:table" -> {
                        inTable++
                        if (ext == "ods") { flush(); title = p.getAttributeValue(null, "table:name") }
                    }
                    "draw:page" -> if (ext == "odp") { flush(); slide++; title = "Diapositive $slide" }
                    "table:table-row" -> row = ArrayList()
                    "table:table-cell", "table:covered-table-cell" -> cell.setLength(0)
                    "text:s" -> (if (ext == "ods") cell else sb).append(' ')
                    "text:tab" -> (if (ext == "ods") cell else sb).append('\t')
                    "text:line-break" -> (if (ext == "ods") cell else sb).append('\n')
                }
                XmlPullParser.TEXT -> if (ext == "ods") cell.append(p.text) else if (sb.length < MAX_PART_CHARS) sb.append(p.text)
                XmlPullParser.END_TAG -> when (p.name) {
                    "table:table" -> inTable--
                    "table:table-cell", "table:covered-table-cell" -> {
                        if (ext == "ods") { if (row.size < MAX_COLS) row.add(cell.toString()) } else sb.append('\t')
                    }
                    "table:table-row" -> {
                        if (ext == "ods") { if (rows.size < MAX_ROWS) rows.add(row) } else sb.append('\n')
                    }
                    "text:p", "text:h" -> if (ext == "ods") cell.append(' ') else sb.append('\n')
                }
            }
            ev = p.next()
        }
    }
    flush()
    if (parts.isEmpty()) parts.add(OfficePart(null, "(document vide)"))
    return parts
}

// ───────────────────────────── RTF ─────────────────────────────

private fun rtfText(bytes: ByteArray): String {
    val s = String(bytes, Charsets.ISO_8859_1)
    val sb = StringBuilder()
    val skipGroups = setOf("fonttbl", "colortbl", "stylesheet", "info", "pict", "header", "footer", "generator")
    var i = 0
    var depth = 0
    var skipDepth = -1
    var uc = 1
    while (i < s.length && sb.length < MAX_PART_CHARS) {
        val c = s[i]
        when {
            c == '{' -> { depth++; i++ }
            c == '}' -> { if (depth == skipDepth) skipDepth = -1; depth--; i++ }
            c == '\\' -> {
                i++
                if (i >= s.length) break
                val d = s[i]
                when {
                    d == '\\' || d == '{' || d == '}' -> { if (skipDepth < 0) sb.append(d); i++ }
                    d == '*' -> { if (skipDepth < 0) skipDepth = depth; i++ }
                    d == '\'' -> {
                        val hex = s.substring(i + 1, minOf(i + 3, s.length))
                        if (skipDepth < 0) hex.toIntOrNull(16)?.let { sb.append(String(byteArrayOf(it.toByte()), charset("windows-1252"))) }
                        i += 3
                    }
                    d.isLetter() -> {
                        var j = i
                        while (j < s.length && s[j].isLetter()) j++
                        val word = s.substring(i, j)
                        var k = j
                        if (k < s.length && (s[k] == '-' || s[k].isDigit())) { k++; while (k < s.length && s[k].isDigit()) k++ }
                        val num = s.substring(j, k).toIntOrNull()
                        if (k < s.length && s[k] == ' ') k++
                        if (word in skipGroups && skipDepth < 0) skipDepth = depth
                        if (skipDepth < 0) when (word) {
                            "par", "line", "row" -> sb.append('\n')
                            "tab", "cell" -> sb.append('\t')
                            "uc" -> uc = num ?: 1
                            "u" -> if (num != null) {
                                sb.append((if (num < 0) num + 65536 else num).toChar())
                                // caractère de remplacement qui suit \uN : à ignorer
                                var skip = uc
                                while (skip > 0 && k < s.length) {
                                    if (s[k] == '\\' && k + 3 < s.length && s[k + 1] == '\'') k += 4 else k++
                                    skip--
                                }
                            }
                        }
                        i = k
                    }
                    else -> i++
                }
            }
            c == '\r' || c == '\n' -> i++
            else -> { if (skipDepth < 0) sb.append(c); i++ }
        }
    }
    return sb.toString().replace(Regex("\n{3,}"), "\n\n").trim()
}

// ───────────────────────────── Affichage ─────────────────────────────

@Composable
internal fun OfficeViewer(f: File) {
    val result by produceState<Result<List<OfficePart>>?>(null, f) {
        value = withContext(Dispatchers.IO) { runCatching { readOffice(f) } }
    }
    val r = result
    when {
        r == null -> Text("Chargement…", Modifier.padding(16.dp), color = LS.Muted, fontSize = 13.sp)
        r.isFailure -> Text(
            "Lecture impossible : ${r.exceptionOrNull()?.message ?: "fichier illisible"}",
            Modifier.padding(16.dp), color = LS.Muted, fontSize = 13.sp,
        )
        else -> {
            val parts = r.getOrThrow()
            SelectionContainer {
                LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp)) {
                    items(parts) { part ->
                        Column(Modifier.fillMaxWidth().padding(bottom = 14.dp)) {
                            if (part.title != null) Text(
                                part.title, Modifier.padding(bottom = 6.dp), color = LS.Blue,
                                fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                            )
                            if (part.table) Box(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(LS.Card)
                                    .horizontalScroll(rememberScrollState()).padding(10.dp)
                            ) {
                                Text(part.text, color = LS.Text, fontSize = 12.sp, fontFamily = FontFamily.Monospace, softWrap = false)
                            } else Text(part.text, color = LS.Text, fontSize = 14.sp, lineHeight = 20.sp)
                        }
                    }
                }
            }
        }
    }
}

// ───────────────────────────── Aperçus du contenu ─────────────────────────────

/** Vrai si LinkShare sait montrer le contenu du fichier en miniature (PDF, texte, Word, Excel, PowerPoint…). */
internal fun File.hasContentPreview(): Boolean {
    val e = extension.lowercase()
    return e == "pdf" || e in VIEW_TXT || e in VIEW_OFFICE
}

private object DocPreviews {
    val cache = object : LruCache<String, Bitmap>(16 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }
    val gate = Semaphore(2)
}

private fun previewSource(f: File): Pair<String, Boolean> {
    val e = f.extension.lowercase()
    if (e in VIEW_TXT) {
        val text = f.bufferedReader().use { r ->
            val buf = CharArray(4000)
            val n = r.read(buf)
            if (n > 0) String(buf, 0, n) else ""
        }
        return text to false
    }
    val part = readOffice(f, quick = true).firstOrNull() ?: return "" to false
    return part.text.take(4000) to part.table
}

private fun accentOf(ext: String): Int = when (ext) {
    "docx", "odt", "rtf" -> 0xFF2B579A.toInt()
    "xlsx", "ods", "csv" -> 0xFF217346.toInt()
    "pptx", "odp" -> 0xFFD24726.toInt()
    else -> 0xFF7A7A7A.toInt()
}

/** Dessine une « page blanche » avec les premières lignes du document, comme l'aperçu d'un PDF. */
private fun renderDocPreview(f: File, widthPx: Int): Bitmap? = runCatching {
    val (text, mono) = previewSource(f)
    if (text.isBlank()) return@runCatching null
    val w = widthPx.coerceIn(64, 1200)
    val h = (w * 1.3f).toInt()
    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    c.drawColor(android.graphics.Color.WHITE)
    val strip = (w * 0.035f).coerceAtLeast(3f)
    val bar = Paint().apply { color = accentOf(f.extension.lowercase()) }
    c.drawRect(0f, 0f, w.toFloat(), strip, bar)
    val margin = w * 0.07f
    val size = w * (if (mono) 0.036f else 0.045f)
    val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF202020.toInt(); textSize = size
        typeface = if (mono) Typeface.MONOSPACE else Typeface.SANS_SERIF
    }
    c.save()
    c.translate(margin, strip + margin)
    if (mono) {
        // Tableau : pas de retour à la ligne, on coupe à droite
        var y = size
        for (line in text.lines()) {
            if (y > h - strip - margin * 2) break
            c.drawText(line.replace('\t', ' '), 0f, y, tp)
            y += size * 1.35f
        }
    } else {
        val width = (w - 2 * margin).toInt().coerceAtLeast(10)
        val layout = StaticLayout.Builder.obtain(text.replace('\t', ' '), 0, text.length, tp, width)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL).setLineSpacing(0f, 1.15f)
            .setMaxLines(((h - strip - margin * 2) / (size * 1.25f)).toInt().coerceAtLeast(1))
            .build()
        layout.draw(c)
    }
    c.restore()
    bmp
}.getOrNull()

private suspend fun docPreview(f: File, widthPx: Int): Bitmap? {
    val key = f.path + "@" + f.lastModified() + "#" + widthPx
    DocPreviews.cache.get(key)?.let { return it }
    return DocPreviews.gate.withPermit { withContext(Dispatchers.IO) { renderDocPreview(f, widthPx) } }
        ?.also { DocPreviews.cache.put(key, it) }
}

/**
 * Miniature du contenu d'un document : 1re page pour un PDF, début du texte pour un fichier texte, Word, Excel ou
 * PowerPoint. Tant qu'elle se charge (ou si le fichier est illisible / protégé) on garde l'icône [fallback].
 */
@Composable
internal fun DocThumb(f: File, modifier: Modifier, widthPx: Int = 360, fallback: @Composable () -> Unit) {
    if (f.extension.equals("pdf", true)) { PdfThumb(f, modifier, widthPx, fallback = fallback); return }
    val bmp by produceState<Bitmap?>(null, f.path, widthPx) { value = docPreview(f, widthPx) }
    val b = bmp
    if (b == null) fallback()
    else Image(
        b.asImageBitmap(), "Aperçu de ${f.name}", modifier.background(Color.White),
        contentScale = ContentScale.Crop, alignment = Alignment.TopCenter,
    )
}
