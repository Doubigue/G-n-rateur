package com.linkshare.scores

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.linkshare.MainActivity
import com.linkshare.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.ZoneId

const val EXTRA_SCORES = "linkshare.open_scores"

/**
 * Scores en notification : une notification permanente (discrète) liste les matchs en direct et se met à jour toute
 * seule (toutes les minutes pendant un match, toutes les 5 minutes sinon). Une alerte sonne à chaque but et à chaque
 * fin de match.
 */
class ScoresService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private val last = HashMap<String, Match>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            ScoresPrefs.setNotif(this, false)
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        ensureChannels(this)
        // Toujours appeler startForeground en premier (obligatoire après startForegroundService).
        val n = ongoing(this, ScoresRepo.cached(this))
        if (Build.VERSION.SDK_INT >= 34) ServiceCompat.startForeground(this, ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(ID, n)
        if (job?.isActive != true) job = scope.launch { loop() }
        return START_STICKY
    }

    private suspend fun loop() {
        while (scope.isActive) {
            val list = runCatching { ScoresRepo.fetch(this) }.getOrNull()
            if (list != null) {
                alerts(list)
                getSystemService(NotificationManager::class.java).notify(ID, ongoing(this, list))
                ScoresWidget.render(this)
            }
            delay(if (list?.any { it.live } == true) 60_000L else 300_000L)
        }
    }

    /** But (score qui monte pendant le match) ou fin de match : alerte avec son. Rien au premier chargement. */
    private fun alerts(list: List<Match>) {
        val nm = getSystemService(NotificationManager::class.java)
        for (m in list) {
            val before = last[m.id]
            if (before != null) {
                val goal = m.live && ((m.homeScore ?: 0) + (m.awayScore ?: 0)) > ((before.homeScore ?: 0) + (before.awayScore ?: 0))
                val ended = before.state != MatchState.POST && m.state == MatchState.POST
                if (goal || ended) nm.notify(
                    ID_ALERT + (m.id.hashCode() and 0xFFFF),
                    NotificationCompat.Builder(this, CH_ALERT)
                        .setSmallIcon(R.drawable.ic_stat_logo)
                        .setContentTitle(if (goal) "⚽ But ! ${m.league}" else "Match terminé · ${m.league}")
                        .setContentText(if (goal) "${m.line} · ${m.status}" else m.line)
                        .setContentIntent(openApp(this))
                        .setAutoCancel(true).setCategory(NotificationCompat.CATEGORY_STATUS).build(),
                )
            }
            last[m.id] = m
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val ID = 4200
        private const val ID_ALERT = 4300
        private const val CH_LIVE = "scores_live"
        private const val CH_ALERT = "scores_alert"
        private const val ACTION_STOP = "com.linkshare.scores.STOP"

        fun start(ctx: Context) {
            runCatching { ContextCompat.startForegroundService(ctx, Intent(ctx, ScoresService::class.java)) }
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, ScoresService::class.java))
            ctx.getSystemService(NotificationManager::class.java).cancel(ID)
        }

        private fun ensureChannels(ctx: Context) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CH_LIVE, "Scores en direct", NotificationManager.IMPORTANCE_LOW).apply { setShowBadge(false) })
            nm.createNotificationChannel(NotificationChannel(CH_ALERT, "Buts et fins de match", NotificationManager.IMPORTANCE_HIGH))
        }

        internal fun openApp(ctx: Context): PendingIntent = PendingIntent.getActivity(
            ctx, 7, Intent(ctx, MainActivity::class.java).putExtra(EXTRA_SCORES, true).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

        /** Notification permanente : matchs en direct, sinon les matchs du jour. */
        private fun ongoing(ctx: Context, all: List<Match>): Notification {
            val live = all.filter { it.live }
            val today = LocalDate.now()
            val zone = ZoneId.systemDefault()
            val shown = (if (live.isNotEmpty()) live else all.filter {
                it.state != MatchState.POST && java.time.Instant.ofEpochMilli(it.start).atZone(zone).toLocalDate() == today
            }).take(6)
            val title = when {
                live.isNotEmpty() -> "⚽ ${live.size} match${if (live.size > 1) "s" else ""} en direct"
                shown.isNotEmpty() -> "Matchs du jour"
                else -> "Scores"
            }
            val lines = shown.map { if (it.live) "${it.line} · ${it.status}" else it.line }
            val text = lines.firstOrNull() ?: "Aucun match en cours"
            val stop = PendingIntent.getService(
                ctx, 8, Intent(ctx, ScoresService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
            return NotificationCompat.Builder(ctx, CH_LIVE)
                .setSmallIcon(R.drawable.ic_stat_logo)
                .setContentTitle(title).setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(lines.joinToString("\n").ifEmpty { text }))
                .setContentIntent(openApp(ctx))
                .addAction(0, "Arrêter", stop)
                .setOngoing(true).setOnlyAlertOnce(true).setShowWhen(false)
                .setCategory(NotificationCompat.CATEGORY_STATUS)
                .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
                .build()
        }
    }
}
