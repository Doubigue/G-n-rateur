package com.linkshare.ui

import android.content.Context
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.os.SystemClock
import android.text.format.Formatter
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DateFormat
import java.util.Date
import java.util.Locale

// ═══════════════════════════ Calcul du contenu d'un dossier ═══════════════════════════

/** Contenu cumulé d'un ou plusieurs éléments : taille, nombre de fichiers et de sous-dossiers. [done] = calcul terminé. */
internal data class TreeStats(val bytes: Long = 0L, val files: Int = 0, val dirs: Int = 0, val done: Boolean = false)

/**
 * Parcourt [roots] (fichiers et dossiers, sous-dossiers compris) en arrière-plan et publie le total au fil de l'eau,
 * pour que les gros dossiers affichent tout de suite un chiffre qui grimpe. Les dossiers de [roots] eux-mêmes
 * ne sont pas comptés comme sous-dossiers.
 */
internal fun treeStats(roots: List<File>): Flow<TreeStats> = flow {
    var bytes = 0L
    var files = 0
    var dirs = 0
    var last = SystemClock.elapsedRealtime()
    val stack = ArrayDeque<File>()
    for (r in roots) {
        if (r.isDirectory) stack.addLast(r) else { bytes += r.length(); files++ }
    }
    while (stack.isNotEmpty()) {
        currentCoroutineContext().ensureActive()
        val kids = stack.removeLast().listFiles() ?: continue
        for (k in kids) {
            if (k.isDirectory) { dirs++; stack.addLast(k) } else { files++; bytes += k.length() }
        }
        val now = SystemClock.elapsedRealtime()
        if (now - last > 150) { last = now; emit(TreeStats(bytes, files, dirs, false)) }
    }
    emit(TreeStats(bytes, files, dirs, true))
}.flowOn(Dispatchers.IO)

@Composable
internal fun rememberTreeStats(files: List<File>): TreeStats {
    val key = files.joinToString("|") { it.path }
    val current by rememberUpdatedState(files)
    val stats by produceState(TreeStats(), key) {
        value = TreeStats()
        treeStats(current).collect { value = it }
    }
    return stats
}

// ═══════════════════════════ Libellés ═══════════════════════════

private fun File.isApk() = extension.equals("apk", ignoreCase = true)

internal fun fileTint(f: File, isDir: Boolean): Color = when {
    isDir -> LS.Blue
    f.isArchive() -> LS.Amber
    f.isApk() -> LS.Green
    else -> f.category().tint()
}

internal fun fileIcon(f: File, isDir: Boolean): ImageVector = when {
    isDir -> Ic.Folder
    f.isArchive() -> Ic.Archive
    f.isApk() -> Ic.Apps
    f.category() == Category.MORE -> Ic.Doc
    else -> f.category().icon()
}

internal fun kindLabel(f: File, isDir: Boolean): String = when {
    isDir -> "Dossier"
    f.isArchive() -> "Archive"
    f.isApk() -> "Application (APK)"
    else -> when (f.category()) {
        Category.DOCS -> "Document"
        Category.PHOTOS -> "Image"
        Category.VIDEOS -> "Vidéo"
        Category.MUSIC -> "Audio"
        Category.MORE -> "Fichier"
    }
}

/** Chemin lisible : la racine du téléphone devient « Stockage interne », le coffre « Dossier sécurisé ». */
internal fun prettyPath(ex: ExplorerViewModel, f: File): String {
    val p = f.path
    return when {
        ex.inVault(f) -> "Dossier sécurisé" + p.removePrefix(ex.vaultDir.path)
        p.startsWith(ex.root.path) -> "Stockage interne" + p.removePrefix(ex.root.path)
        else -> p
    }
}

/** Nom du dossier qui contient [f]. */
internal fun parentLabel(ex: ExplorerViewModel, f: File): String {
    val parent = f.parentFile ?: return "—"
    return when (parent.path) {
        ex.root.path -> "Stockage interne"
        ex.vaultDir.path -> "Dossier sécurisé"
        else -> parent.name
    }
}

internal fun fmtSize(ctx: Context, bytes: Long): String = Formatter.formatShortFileSize(ctx, bytes)

internal fun fmtDateTime(ms: Long): String =
    DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(ms))

internal fun fmtDate(ms: Long): String = DateFormat.getDateInstance(DateFormat.SHORT).format(Date(ms))

private fun fmtBytes(bytes: Long): String = String.format(Locale.FRANCE, "%,d octets", bytes)

private fun fmtDuration(ms: Long): String {
    val s = ms / 1000
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec) else String.format(Locale.US, "%d:%02d", m, sec)
}

internal fun plural(n: Int, one: String, many: String) = "$n " + if (n > 1) many else one

/** Informations propres au type : dimensions d'une image, durée et résolution d'une vidéo, titre d'un morceau, version d'un APK. */
private fun mediaDetails(ctx: Context, f: File): List<Pair<String, String>> {
    val out = ArrayList<Pair<String, String>>()
    val e = f.extension.lowercase()
    val cat = categoryOfExt(e)
    try {
        if (cat == Category.PHOTOS) {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.path, o)
            if (o.outWidth > 0 && o.outHeight > 0) {
                out.add("Dimensions" to "${o.outWidth} × ${o.outHeight} px")
                val mp = o.outWidth.toLong() * o.outHeight / 1_000_000.0
                if (mp >= 0.1) out.add("Définition" to String.format(Locale.FRANCE, "%.1f Mpx", mp))
            }
        } else if (cat == Category.VIDEOS || cat == Category.MUSIC) {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(f.path)
                fun meta(k: Int): String? = r.extractMetadata(k)?.trim()?.takeIf { it.isNotEmpty() }
                val dur = meta(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
                if (dur != null && dur > 0) out.add("Durée" to fmtDuration(dur))
                if (cat == Category.VIDEOS) {
                    val w = meta(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                    val h = meta(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                    if (w != null && h != null) out.add("Résolution" to "$w × $h px")
                } else {
                    meta(MediaMetadataRetriever.METADATA_KEY_TITLE)?.let { out.add("Titre" to it) }
                    meta(MediaMetadataRetriever.METADATA_KEY_ARTIST)?.let { out.add("Artiste" to it) }
                    meta(MediaMetadataRetriever.METADATA_KEY_ALBUM)?.let { out.add("Album" to it) }
                }
                val rate = meta(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toLongOrNull()
                if (rate != null && rate > 0) out.add("Débit" to "${rate / 1000} kb/s")
            } finally {
                runCatching { r.release() }
            }
        } else if (e == "apk") {
            val pi = ctx.packageManager.getPackageArchiveInfo(f.path, 0)
            if (pi != null) {
                out.add("Paquet" to pi.packageName)
                pi.versionName?.let { out.add("Version" to it) }
            }
        }
    } catch (_: Exception) {
        // fichier illisible ou format inconnu : on affiche simplement les informations générales
    }
    return out
}

// ═══════════════════════════ Aperçu de la sélection ═══════════════════════════

/**
 * Carte affichée au-dessus de la barre d'actions dès qu'on sélectionne : nom, dossier, taille et date d'un fichier ;
 * taille, sous-dossiers et fichiers d'un dossier ; total pour plusieurs éléments. Un toucher ouvre tous les détails.
 */
@Composable
internal fun SelectionInfoCard(ex: ExplorerViewModel, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val files = ex.selected.map { File(it) }
    if (files.isEmpty()) return
    val stats = rememberTreeStats(files)
    val shape = RoundedCornerShape(22.dp)
    val sizeText = fmtSize(ctx, stats.bytes) + if (stats.done) "" else "…"
    Row(
        modifier.fillMaxWidth().padding(horizontal = 14.dp).clip(shape).background(LS.Sheet).border(1.dp, LS.Line, shape)
            .clickable { ex.showInfo(files) }.padding(horizontal = 10.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(34.dp).clip(CircleShape).clickable { ex.selected.clear() },
            contentAlignment = Alignment.Center,
        ) { Icon(Ic.Close, "Annuler la sélection", Modifier.size(20.dp), tint = LS.Muted) }
        Spacer(Modifier.width(4.dp))
        val one = files.singleOrNull()
        if (one != null) {
            val isDir = remember(one.path) { one.isDirectory }
            val modified = remember(one.path) { one.lastModified() }
            IconBadge(fileIcon(one, isDir), fileTint(one, isDir), 46.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(one.name, color = LS.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    kindLabel(one, isDir) + " · dans " + parentLabel(ex, one),
                    color = LS.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                Text(
                    if (isDir) sizeText + " · " + plural(stats.dirs, "sous-dossier", "sous-dossiers") + " · " + plural(stats.files, "fichier", "fichiers")
                    else sizeText + " · " + fmtDateTime(modified),
                    color = LS.Text.copy(alpha = 0.85f), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
        } else {
            val nDirs = remember(files.size, files.first().path, files.last().path) { files.count { it.isDirectory } }
            IconBadge(Ic.Check, LS.Blue, 46.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("${files.size} éléments sélectionnés", color = LS.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text(
                    plural(nDirs, "dossier", "dossiers") + " · " + plural(files.size - nDirs, "fichier", "fichiers"),
                    color = LS.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                Text(
                    "Taille totale : $sizeText" + if (nDirs > 0) " · " + plural(stats.files, "fichier", "fichiers") + " en tout" else "",
                    color = LS.Text.copy(alpha = 0.85f), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
        }
        // Accès direct à Media Studio, sans passer par l'écran « Actions »
        if (studioRelevant(files) && files.none { ex.inVault(it) }) {
            Spacer(Modifier.width(8.dp))
            Column(
                Modifier.clip(RoundedCornerShape(14.dp)).background(LS.Purple).clickable { ex.studioFiles = files }
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Icon(Ic.Animation, "Media Studio", Modifier.size(20.dp), tint = Color.White)
                Text("Studio", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        Spacer(Modifier.width(8.dp))
        Column(
            Modifier.clip(RoundedCornerShape(14.dp)).background(LS.Blue).padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Icon(Ic.Info, "Infos et actions", Modifier.size(20.dp), tint = LS.OnBlue)
            Text("Actions", color = LS.OnBlue, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

// ═══════════════════════════ Feuille « Détails » ═══════════════════════════

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun FileInfoSheet(ex: ExplorerViewModel, onShowInFolder: (File) -> Unit) {
    val files = ex.infoFiles
    if (files.isEmpty()) return
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = { ex.infoFiles = emptyList() },
        sheetState = state, containerColor = LS.Sheet, contentColor = LS.Text,
    ) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).navigationBarsPadding()
                .padding(horizontal = 16.dp).padding(bottom = 20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            val one = files.singleOrNull()
            if (one != null) SingleInfo(ex, one, onShowInFolder) else MultiInfo(ex, files)
        }
    }
}

@Composable
private fun SingleInfo(ex: ExplorerViewModel, f: File, onShowInFolder: (File) -> Unit) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val isDir = remember(f.path) { f.isDirectory }
    val length = remember(f.path) { if (isDir) 0L else f.length() }
    val modified = remember(f.path) { f.lastModified() }
    val writable = remember(f.path) { f.canWrite() }
    val direct = remember(f.path) { if (isDir) f.list()?.size ?: 0 else 0 }
    val vault = ex.inVault(f)
    val tint = fileTint(f, isDir)
    val ext = f.extension.lowercase()
    val visual = !isDir && (ext in VIEW_IMG || ext == "heic" || categoryOfExt(ext) == Category.VIDEOS)
    val loader = rememberThumbLoader()
    val stats = rememberTreeStats(listOf(f))
    val extra by produceState(emptyList<Pair<String, String>>(), f.path) {
        value = withContext(Dispatchers.IO) { if (isDir) emptyList() else mediaDetails(ctx, f) }
    }
    var renaming by remember { mutableStateOf(false) }
    var askDelete by remember { mutableStateOf(false) }
    var askForever by remember { mutableStateOf(false) }
    val bytes = if (isDir) stats.bytes else length
    val computing = isDir && !stats.done

    // ── En-tête : aperçu, nom, étiquettes
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (visual) AsyncImage(
            model = f, contentDescription = null, imageLoader = loader,
            modifier = Modifier.size(76.dp).clip(RoundedCornerShape(20.dp)).background(LS.Card), contentScale = ContentScale.Crop,
        ) else if (!isDir && f.hasContentPreview()) DocThumb(f, Modifier.size(76.dp).clip(RoundedCornerShape(20.dp)), widthPx = 240) {
            IconBadge(fileIcon(f, isDir), tint, 76.dp)
        } else IconBadge(fileIcon(f, isDir), tint, 76.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(f.name, color = LS.Text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, maxLines = 3, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Chip(kindLabel(f, isDir), tint)
                if (!isDir && ext.isNotEmpty() && ext != "apk") Chip(ext.uppercase(), LS.Muted)
            }
        }
    }

    // ── Chiffres clés
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        if (isDir) {
            StatTile("Taille", fmtSize(ctx, bytes), LS.Blue, computing, Modifier.weight(1f))
            StatTile("Sous-dossiers", "${stats.dirs}", LS.Amber, computing, Modifier.weight(1f))
            StatTile("Fichiers", "${stats.files}", LS.Green, computing, Modifier.weight(1f))
        } else {
            StatTile("Taille", fmtSize(ctx, bytes), LS.Blue, false, Modifier.weight(1f))
            StatTile("Modifié", fmtDate(modified), LS.Amber, false, Modifier.weight(1f))
            StatTile("Format", if (ext.isEmpty()) "—" else ext.uppercase(), LS.Green, false, Modifier.weight(1f))
        }
    }

    // ── Actions : tout se fait ici (ouvrir, copier, déplacer, supprimer, coffre…)
    val actions = buildList {
        add(InfoAction(Ic.OpenIn, "Ouvrir", LS.Blue) { ex.infoFiles = emptyList(); ex.open(f) })
        if (!vault) {
            if (!isDir) add(InfoAction(Ic.Animation, "Studio", LS.Purple) { ex.infoFiles = emptyList(); ex.studioFiles = listOf(f) })
            add(InfoAction(Ic.Share, "Partager", LS.Green) { ex.infoFiles = emptyList(); ex.selected.clear(); ex.shareFiles(listOf(f)) })
            add(InfoAction(Ic.Copy, "Copier", LS.Teal) { ex.infoFiles = emptyList(); ex.startTransfer(move = false, files = listOf(f)) })
            add(InfoAction(Ic.Forward, "Déplacer", LS.Orange) { ex.infoFiles = emptyList(); ex.startTransfer(move = true, files = listOf(f)) })
            add(InfoAction(Ic.Edit, "Renommer", LS.Pink) { renaming = true })
            if (ext == "zip") add(InfoAction(Ic.Archive, "Extraire", LS.Amber) { ex.infoFiles = emptyList(); ex.extract(f) })
            else add(InfoAction(Ic.Archive, "Compresser", LS.Amber) { ex.infoFiles = emptyList(); ex.compressSelected(listOf(f)) })
            add(InfoAction(Ic.Lock, "Verrouiller", LS.Purple) { ex.infoFiles = emptyList(); ex.moveToVault(listOf(f)) })
            add(InfoAction(Ic.Delete, "Supprimer", LS.Red) { askDelete = true })
            add(InfoAction(Ic.Close, "Supprimer définitivement", LS.Red) { askForever = true })
            add(InfoAction(Ic.Link, "Copier le chemin", LS.Blue) {
                clipboard.setText(AnnotatedString(f.path))
                Toast.makeText(ctx, "Chemin copié", Toast.LENGTH_SHORT).show()
            })
            add(InfoAction(Ic.Folder, "Voir le dossier", LS.Green) { onShowInFolder(f) })
        } else {
            add(InfoAction(Ic.Restore, "Restaurer", LS.Green) { ex.infoFiles = emptyList(); ex.restoreFromVault(listOf(f)) })
            add(InfoAction(Ic.Delete, "Supprimer", LS.Red) { askDelete = true })
        }
    }
    ActionsGrid(actions)

    // ── Détails
    Column(Modifier.fillMaxWidth().lsCard(RoundedCornerShape(20.dp)).padding(horizontal = 16.dp, vertical = 6.dp)) {
        InfoLine("Nom", f.name)
        val mime = if (isDir) null else MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
        InfoLine("Type", kindLabel(f, isDir) + if (mime != null) " ($mime)" else "")
        InfoLine("Dossier", parentLabel(ex, f))
        InfoLine("Emplacement", f.parentFile?.let { prettyPath(ex, it) } ?: "—")
        InfoLine("Taille", fmtSize(ctx, bytes) + " (" + fmtBytes(bytes) + ")" + if (computing) " · calcul en cours…" else "")
        if (isDir) {
            InfoLine(
                "Contenu",
                plural(stats.dirs, "sous-dossier", "sous-dossiers") + ", " + plural(stats.files, "fichier", "fichiers") +
                    if (computing) "…" else "",
            )
            InfoLine("À la racine", plural(direct, "élément", "éléments"))
        }
        InfoLine("Modifié le", fmtDateTime(modified))
        extra.forEach { (k, v) -> InfoLine(k, v) }
        if (f.name.startsWith(".")) InfoLine("Visibilité", "Élément caché")
        InfoLine("Accès", if (writable) "Lecture et écriture" else "Lecture seule", last = true)
    }

    if (renaming) RenameDialog(f.name, onDismiss = { renaming = false }) { name ->
        ex.rename(f, name)?.let { renamed -> renaming = false; ex.infoFiles = listOf(renamed) }
    }
    if (askDelete) DeleteDialog(ex, listOf(f), vault) { askDelete = false }
    if (askForever) ForeverDialog(ex, listOf(f)) { askForever = false }
}

@Composable
private fun MultiInfo(ex: ExplorerViewModel, files: List<File>) {
    val ctx = LocalContext.current
    val stats = rememberTreeStats(files)
    val key = files.joinToString("|") { it.path }
    val nDirs = remember(key) { files.count { it.isDirectory } }
    val dates = remember(key) { files.map { it.lastModified() }.filter { it > 0 } }
    val parents = remember(key) { files.mapNotNull { it.parentFile }.distinctBy { it.path } }
    val computing = !stats.done

    Row(verticalAlignment = Alignment.CenterVertically) {
        IconBadge(Ic.Check, LS.Blue, 76.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text("${files.size} éléments sélectionnés", color = LS.Text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (nDirs > 0) Chip(plural(nDirs, "dossier", "dossiers"), LS.Blue)
                if (files.size - nDirs > 0) Chip(plural(files.size - nDirs, "fichier", "fichiers"), LS.Green)
            }
        }
    }

    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        StatTile("Taille totale", fmtSize(ctx, stats.bytes), LS.Blue, computing, Modifier.weight(1f))
        StatTile("Sous-dossiers", "${stats.dirs}", LS.Amber, computing, Modifier.weight(1f))
        StatTile("Fichiers", "${stats.files}", LS.Green, computing, Modifier.weight(1f))
    }

    // ── Actions sur toute la sélection
    var askDelete by remember { mutableStateOf(false) }
    var askForever by remember { mutableStateOf(false) }
    val vault = files.all { ex.inVault(it) }
    val actions = buildList {
        if (!vault) {
            if (studioRelevant(files)) add(InfoAction(Ic.Animation, "Studio", LS.Purple) { ex.infoFiles = emptyList(); ex.studioFiles = files })
            add(InfoAction(Ic.Share, "Partager", LS.Green) { ex.infoFiles = emptyList(); ex.selected.clear(); ex.shareFiles(files) })
            add(InfoAction(Ic.Copy, "Copier", LS.Teal) { ex.infoFiles = emptyList(); ex.startTransfer(move = false, files = files) })
            add(InfoAction(Ic.Forward, "Déplacer", LS.Orange) { ex.infoFiles = emptyList(); ex.startTransfer(move = true, files = files) })
            add(InfoAction(Ic.Archive, "Compresser", LS.Amber) { ex.infoFiles = emptyList(); ex.compressSelected(files) })
            add(InfoAction(Ic.Lock, "Verrouiller", LS.Purple) { ex.infoFiles = emptyList(); ex.moveToVault(files) })
            add(InfoAction(Ic.Delete, "Supprimer", LS.Red) { askDelete = true })
            add(InfoAction(Ic.Close, "Supprimer définitivement", LS.Red) { askForever = true })
        } else {
            add(InfoAction(Ic.Restore, "Restaurer", LS.Green) { ex.infoFiles = emptyList(); ex.restoreFromVault(files) })
            add(InfoAction(Ic.Delete, "Supprimer", LS.Red) { askDelete = true })
        }
        add(InfoAction(Ic.Close, "Désélectionner", LS.Muted) { ex.infoFiles = emptyList(); ex.selected.clear() })
    }
    ActionsGrid(actions)
    if (askDelete) DeleteDialog(ex, files, vault) { askDelete = false }
    if (askForever) ForeverDialog(ex, files) { askForever = false }

    Column(Modifier.fillMaxWidth().lsCard(RoundedCornerShape(20.dp)).padding(horizontal = 16.dp, vertical = 6.dp)) {
        InfoLine("Sélection", plural(nDirs, "dossier", "dossiers") + ", " + plural(files.size - nDirs, "fichier", "fichiers"))
        InfoLine("Taille totale", fmtSize(ctx, stats.bytes) + " (" + fmtBytes(stats.bytes) + ")" + if (computing) " · calcul en cours…" else "")
        if (nDirs > 0) InfoLine(
            "Contenu des dossiers",
            plural(stats.dirs, "sous-dossier", "sous-dossiers") + ", " + plural(stats.files, "fichier", "fichiers") + " en tout",
        )
        InfoLine("Emplacement", if (parents.size == 1) prettyPath(ex, parents[0]) else plural(parents.size, "dossier différent", "dossiers différents"))
        if (dates.isNotEmpty()) {
            InfoLine("Plus récent", fmtDateTime(dates.max()))
            InfoLine("Plus ancien", fmtDateTime(dates.min()), last = true)
        }
    }

    // Les premiers éléments de la sélection, pour vérifier d'un coup d'œil
    Column(Modifier.fillMaxWidth().lsCard(RoundedCornerShape(20.dp)).padding(horizontal = 12.dp, vertical = 8.dp)) {
        files.take(6).forEach { f ->
            val isDir = remember(f.path) { f.isDirectory }
            val len = remember(f.path) { if (isDir) -1L else f.length() }
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconBadge(fileIcon(f, isDir), fileTint(f, isDir), 34.dp)
                Spacer(Modifier.width(10.dp))
                Text(f.name, Modifier.weight(1f), color = LS.Text, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(if (len < 0) "Dossier" else fmtSize(ctx, len), color = LS.Muted, fontSize = 12.sp)
            }
        }
        if (files.size > 6) Text(
            "+ ${files.size - 6} autre(s)", Modifier.fillMaxWidth().padding(vertical = 6.dp),
            color = LS.Muted, fontSize = 12.sp, textAlign = TextAlign.Center,
        )
    }
}

// ═══════════════════════════ Briques ═══════════════════════════

private class InfoAction(val icon: ImageVector, val label: String, val tint: Color, val onClick: () -> Unit)

/** Grille d'actions de l'écran d'infos : 4 par ligne, dans une carte. */
@Composable
private fun ActionsGrid(actions: List<InfoAction>) {
    Column(
        Modifier.fillMaxWidth().lsCard(RoundedCornerShape(UiStyle.r(20.dp))).padding(horizontal = 6.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Text("Actions", Modifier.padding(start = 10.dp, bottom = 2.dp), color = LS.Blue, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        actions.chunked(4).forEach { row ->
            Row(Modifier.fillMaxWidth()) {
                row.forEach { a -> QuickAction(a.icon, a.label, a.tint, Modifier.weight(1f), a.onClick) }
                repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

/** Suppression définitive : confirmation toujours demandée (même si « Confirmer la suppression » est désactivé). */
@Composable
private fun ForeverDialog(ex: ExplorerViewModel, files: List<File>, onDismiss: () -> Unit) {
    val dirs = remember(files) { files.count { it.isDirectory } }
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Ic.Delete, null, tint = LS.Red) },
        title = { Text("Supprimer définitivement ?") },
        text = {
            Text(
                (if (files.size == 1) "« ${files[0].name} »" else "${files.size} éléments") +
                    (if (dirs > 0) " (dossiers compris, avec tout leur contenu)" else "") +
                    " seront effacés sans passer par la corbeille.\n\nCette action est irréversible."
            )
        },
        confirmButton = {
            TextButton({
                onDismiss()
                ex.infoFiles = emptyList()
                ex.deleteForever(files)
            }) { Text("Supprimer définitivement", color = LS.Red, fontWeight = FontWeight.SemiBold) }
        },
        dismissButton = { TextButton(onDismiss) { Text("Annuler") } },
    )
}

/** Confirmation de suppression : corbeille pour les fichiers, suppression définitive pour le coffre. */
@Composable
private fun DeleteDialog(ex: ExplorerViewModel, files: List<File>, vault: Boolean, onDismiss: () -> Unit) {
    fun go() {
        onDismiss()
        ex.infoFiles = emptyList()
        if (vault) ex.deleteFromVault(files) else ex.deleteSelected(files)
    }
    if (!vault && !UiStyle.confirmDelete) { LaunchedEffect(Unit) { go() }; return }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (vault) "Supprimer du coffre ?" else "Supprimer ?") },
        text = {
            Text(
                if (vault) "${files.size} élément(s) seront supprimés définitivement."
                else "${files.size} élément(s) seront placés dans la corbeille (restaurables pendant $TRASH_DAYS jours)."
            )
        },
        confirmButton = { TextButton({ go() }) { Text("Supprimer", color = LS.Red) } },
        dismissButton = { TextButton(onDismiss) { Text("Annuler") } },
    )
}

@Composable
internal fun Chip(text: String, tint: Color) {
    Text(
        text,
        Modifier.clip(CircleShape).background(tint.copy(alpha = 0.16f)).padding(horizontal = 10.dp, vertical = 4.dp),
        color = tint, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
    )
}

@Composable
private fun StatTile(label: String, value: String, tint: Color, loading: Boolean, modifier: Modifier) {
    Column(modifier.lsCard(RoundedCornerShape(18.dp)).padding(horizontal = 12.dp, vertical = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(tint))
            Spacer(Modifier.width(6.dp))
            Text(label, Modifier.weight(1f), color = LS.Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (loading) CircularProgressIndicator(Modifier.size(11.dp), color = tint, strokeWidth = 1.5.dp)
        }
        Spacer(Modifier.height(6.dp))
        Text(value, color = LS.Text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun QuickAction(icon: ImageVector, label: String, tint: Color, modifier: Modifier = Modifier.width(76.dp), onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.size(48.dp).clip(CircleShape).background(tint.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
            Icon(icon, null, Modifier.size(22.dp), tint = tint)
        }
        Spacer(Modifier.height(6.dp))
        Text(label, color = LS.Text, fontSize = 11.sp, maxLines = 2, textAlign = TextAlign.Center, lineHeight = 13.sp)
    }
}

@Composable
private fun InfoLine(label: String, value: String, last: Boolean = false) {
    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.Top) {
        Text(label, Modifier.width(112.dp), color = LS.Muted, fontSize = 13.sp)
        Text(value, Modifier.weight(1f), color = LS.Text, fontSize = 13.sp)
    }
    if (!last) HorizontalDivider(color = LS.Line)
}

@Composable
internal fun RenameDialog(current: String, onDismiss: () -> Unit, onRename: (String) -> Unit) {
    var name by remember { mutableStateOf(current) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Renommer") },
        text = {
            TextField(value = name, onValueChange = { name = it }, singleLine = true, placeholder = { Text("Nouveau nom") })
        },
        confirmButton = { TextButton({ onRename(name) }, enabled = name.isNotBlank() && name.trim() != current) { Text("Renommer") } },
        dismissButton = { TextButton({ onDismiss() }) { Text("Annuler") } },
    )
}
