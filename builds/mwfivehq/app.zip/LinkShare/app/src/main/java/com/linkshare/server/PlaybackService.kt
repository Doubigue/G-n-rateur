package com.linkshare.server

import android.app.PendingIntent
import android.content.Intent
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import com.linkshare.MainActivity
import com.linkshare.R
import com.linkshare.core.ZipAwareDataSourceFactory

/**
 * Lecture vidéo/audio hors de l'écran, via une MediaSession :
 *  - notification de lecture dans la barre d'état (icône LinkShare, titre, lecture/pause/avance) ;
 *  - commandes sur l'écran verrouillé (Android 11-12 : notification ; Android 13+ : contrôles multimédia) ;
 *  - la lecture continue quand l'écran s'éteint ou que l'appli passe en arrière-plan.
 */
class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()

        // Notification : petite icône LinkShare dans la barre d'état, canal nommé en français
        setMediaNotificationProvider(
            DefaultMediaNotificationProvider.Builder(this)
                .setChannelName(R.string.playback_channel)
                .build()
                .apply { setSmallIcon(R.drawable.ic_stat_logo) }
        )

        val player = ExoPlayer.Builder(this)
            // Les adresses lszip:// sont lues directement dans l'archive, sans décompression sur le disque
            .setMediaSourceFactory(DefaultMediaSourceFactory(ZipAwareDataSourceFactory(this)))
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(),
                true,
            )
            .setHandleAudioBecomingNoisy(true) // pause si les écouteurs sont débranchés
            // Écran verrouillé : maintient le CPU *et le Wi-Fi* (sinon un flux venant de l'autre téléphone
            // se coupe quelques secondes après l'extinction de l'écran). WAKE_MODE_LOCAL ne gardait que le CPU.
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()

        // Toucher la notification (ou le contrôle de l'écran verrouillé) rouvre l'appli
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        session = MediaSession.Builder(this, player).setCallback(Callback()).setSessionActivity(open).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        session?.run { player.release(); release() }
        session = null
        super.onDestroy()
    }

    /** Les contrôleurs envoient une demande (URI dans requestMetadata) : on la transforme en vrai MediaItem. */
    private class Callback : MediaSession.Callback {
        override fun onAddMediaItems(
            mediaSession: MediaSession, controller: MediaSession.ControllerInfo, mediaItems: MutableList<MediaItem>,
        ): ListenableFuture<MutableList<MediaItem>> {
            val resolved = mediaItems.map { it.buildUpon().setUri(it.requestMetadata.mediaUri ?: it.localConfiguration?.uri).build() }
            return Futures.immediateFuture(resolved.toMutableList())
        }
    }
}
