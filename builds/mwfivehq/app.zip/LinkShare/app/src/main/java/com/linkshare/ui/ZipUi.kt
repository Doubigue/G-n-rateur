package com.linkshare.ui

import android.content.Context
import android.graphics.BitmapFactory
import android.text.format.Formatter
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.Image
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linkshare.core.ZipUri
import com.linkshare.core.openZip
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ═══════════════════════════ Données ═══════════════════════════

/** Une entrée de l'archive, telle que lue dans l'index (sans rien décompresser). */
private class ZipInfo(val name: String, val isDir: Boolean, val size: Long, val packed: Long, val time: Long)

/** Un élément affiché dans le dossier courant de l'archive. */
private class ZipItem(
    val name: String, val path: String, val isDir: Boolean, val size: Long, val packed: Long, val time: Long, val count: Int = 0,
)

private class ZipIndex(val all: List<ZipInfo>, val error: String?)

private fun readIndex(f: File): ZipIndex = try {
    openZip(f).use { z ->
        val list = z.entries().asSequence()
            .map { ZipInfo(it.name.trimEnd('/'), it.isDirectory, it.size, it.compressedSize, it.time) }
            .filter { it.name.isNotEmpty() && !it.name.startsWith("__MACOSX/") }
            .toList()
        ZipIndex(list, null)
    }
} catch (e: Exception) {
    ZipIndex(emptyList(), "Archive illisible : ${e.message ?: e.javaClass.simpleName}")
}

/** Contenu d'un dossier de l'archive : sous-dossiers d'abord, puis fichiers, par ordre alphabétique. */
private fun children(all: List<ZipInfo>, dir: String): List<ZipItem> {
    val prefix = if (dir.isEmpty()) "" else "$dir/"
    val dirs = LinkedHashMap<String, Int>()
    val files = ArrayList<ZipItem>()
    for (e in all) {
        if (!e.name.startsWith(prefix) || e.name.length == prefix.length) continue
        val rest = e.name.substring(prefix.length)
        val slash = rest.indexOf('/')
        when {
            slash >= 0 -> rest.substring(0, slash).let { dirs[it] = (dirs[it] ?: 0) + 1 }
            e.isDir -> if (rest !in dirs) dirs[rest] = 0
            else -> files.add(ZipItem(rest, e.name, false, e.size, e.packed, e.time))
        }
    }
    val folders = dirs.map { (n, c) -> ZipItem(n, prefix + n, true, 0, 0, 0, c) }.sortedBy { it.name.lowercase() }
    return folders + files.sortedBy { it.name.lowercase() }
}

private fun emojiOf(item: ZipItem): String {
    if (item.isDir) return "📁"
    val e = item.name.substringAfterLast('.', "").lowercase()
    return when {
        e in VIEW_IMG -> "🖼️"
        categoryOfExt(e) == Category.VIDEOS -> "🎬"
        categoryOfExt(e) == Category.MUSIC -> "🎵"
        e == "pdf" -> "📕"
        e in VIEW_OFFICE -> "📝"
        e in VIEW_TXT -> "📄"
        e == "apk" -> "🤖"
        e in setOf("zip", "rar", "7z", "gz", "tar") -> "📦"
        else -> "📄"
    }
}

private fun tintOf(item: ZipItem): Color {
    if (item.isDir) return LS.Blue
    val e = item.name.substringAfterLast('.', "").lowercase()
    return when {
        e in VIEW_IMG -> LS.Pink
        categoryOfExt(e) == Category.VIDEOS -> LS.Red
        categoryOfExt(e) == Category.MUSIC -> LS.Purple
        e == "pdf" -> LS.Orange
        e in VIEW_OFFICE -> LS.Teal
        e == "apk" -> LS.Green
        else -> LS.Amber
    }
}

// ═══════════════════════════ Lecture directe dans l'archive ═══════════════════════════

private const val MAX_IMAGE_BYTES = 60L * 1024 * 1024

private fun decodeEntry(zip: File, path: String): ImageBitmap? = try {
    openZip(zip).use { z ->
        val e = z.getEntry(path)
        if (e == null || (e.size > MAX_IMAGE_BYTES)) null
        else {
            val bytes = z.getInputStream(e).use { it.readBytes() }
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= 2400) sample *= 2
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
                ?.asImageBitmap()
        }
    }
} catch (e: Exception) { null }

private fun readEntryText(zip: File, path: String): String = try {
    openZip(zip).use { z ->
        val e = z.getEntry(path) ?: return@use "Fichier introuvable dans l'archive"
        InputStreamReader(z.getInputStream(e), Charsets.UTF_8).use { r ->
            val buf = CharArray(300_000)
            val n = r.read(buf)
            (if (n > 0) String(buf, 0, n) else "") + if (e.size > 600_000) "\n\n… (aperçu limité)" else ""
        }
    }
} catch (e: Exception) { "Lecture impossible : ${e.message}" }

/** Pour les formats qui exigent un vrai fichier (PDF, Word…) : copie temporaire d'UNE seule entrée, dans le cache. */
private fun extractToCache(ctx: Context, zip: File, path: String): File {
    val dir = File(ctx.cacheDir, "zipview").apply { mkdirs() }
    val out = File(dir, path.substringAfterLast('/').ifEmpty { "fichier" })
    openZip(zip).use { z ->
        val e = z.getEntry(path) ?: error("Fichier introuvable dans l'archive")
        z.getInputStream(e).use { i -> out.outputStream().use { i.copyTo(it) } }
    }
    return out
}

/** Extrait UNE entrée à côté de l'archive (sans écraser un fichier existant). */
private fun extractBeside(zip: File, path: String): File {
    val parent = zip.parentFile ?: error("Dossier introuvable")
    val name = path.substringAfterLast('/').ifEmpty { "fichier" }
    val stem = if (name.contains('.')) name.substringBeforeLast('.') else name
    val ext = if (name.contains('.')) "." + name.substringAfterLast('.') else ""
    var out = File(parent, name)
    var i = 1
    while (out.exists()) { out = File(parent, "$stem ($i)$ext"); i++ }
    openZip(zip).use { z ->
        val e = z.getEntry(path) ?: error("Fichier introuvable dans l'archive")
        z.getInputStream(e).use { inp -> out.outputStream().use { inp.copyTo(it) } }
    }
    return out
}

private sealed interface ZPreview {
    class Images(val items: List<ZipItem>, val start: Int) : ZPreview
    class Text(val item: ZipItem) : ZPreview
    class Media(val items: List<ZipItem>, val start: Int) : ZPreview
}

// ═══════════════════════════ Écran ═══════════════════════════

/**
 * Contenu d'une archive ZIP : on navigue dans les dossiers, on voit les tailles, on lit images / textes / vidéos / musiques
 * directement dans l'archive, sans la décompresser. Les formats qui ont besoin d'un fichier (PDF, Word…) s'ouvrent via
 * une copie temporaire de ce seul fichier.
 */
@Composable
internal fun ZipBrowserScreen(ex: ExplorerViewModel) {
    val zip = ex.zipBrowsing ?: return
    val ctx = LocalContext.current
    var dir by rememberSaveable(zip.path) { mutableStateOf("") }
    var preview by remember(zip.path) { mutableStateOf<ZPreview?>(null) }
    val index by produceState<ZipIndex?>(null, zip) { value = withContext(Dispatchers.IO) { readIndex(zip) } }

    fun close() { ex.zipBrowsing = null }
    // Les copies temporaires disparaissent en quittant l'archive
    DisposableEffect(zip.path) { onDispose { File(ctx.cacheDir, "zipview").deleteRecursively() } }

    // Fenêtre flottante fermée avec la croix : la lecture est coupée, on revient à la liste
    LaunchedEffect(PipHost.dismissed) { if (PipHost.dismissed) { PipHost.dismissed = false; preview = null } }

    BackHandler {
        when {
            preview != null -> preview = null
            dir.isNotEmpty() -> dir = dir.substringBeforeLast('/', "")
            else -> close()
        }
    }

    // Lecture d'une vidéo / musique : lecteur plein écran, flux lu directement dans l'archive
    (preview as? ZPreview.Media)?.let { p ->
        val urls = remember(p) { p.items.map { ZipUri.of(zip, it.path).toString() } }
        val names = remember(p) { p.items.map { it.name } }
        Player(urls, names, p.start, names = names, onClose = { preview = null })
        return
    }

    Column(Modifier.fillMaxSize().background(LS.Bg).systemBarsPadding()) {
        val idx = index
        val cur = preview
        Row(Modifier.padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({
                when {
                    cur != null -> preview = null
                    dir.isNotEmpty() -> dir = dir.substringBeforeLast('/', "")
                    else -> close()
                }
            }) { Icon(Ic.Back, "Retour", tint = LS.Blue) }
            Column(Modifier.weight(1f)) {
                Text(
                    if (cur is ZPreview.Text) cur.item.name else zip.name,
                    color = LS.Blue, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                Text(
                    if (cur == null) (if (dir.isEmpty()) "Contenu de l'archive" else dir) else "Lecture directe, sans décompresser",
                    color = LS.Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
            if (cur == null) IconButton({ ex.extract(zip) }) { Icon(Ic.Download, "Tout extraire", tint = LS.Blue) }
        }

        when (cur) {
            is ZPreview.Images -> ZipImages(zip, cur)
            is ZPreview.Text -> ZipText(zip, cur.item)
            else -> {
                if (idx == null) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                else if (idx.error != null) Text(idx.error, Modifier.padding(16.dp), color = LS.Muted, fontSize = 13.sp)
                else ZipList(ex, zip, idx, dir, onDir = { dir = it }, onPreview = { preview = it })
            }
        }
    }
}

@Composable
private fun ZipList(
    ex: ExplorerViewModel, zip: File, idx: ZipIndex, dir: String, onDir: (String) -> Unit, onPreview: (ZPreview) -> Unit,
) {
    val ctx = LocalContext.current
    val rows = remember(idx, dir) { children(idx.all, dir) }
    val files = remember(idx) { idx.all.filter { !it.isDir } }
    val fmt = remember { SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()) }

    fun open(item: ZipItem) {
        if (item.isDir) { onDir(item.path); return }
        val e = item.name.substringAfterLast('.', "").lowercase()
        val siblings = rows.filter { !it.isDir }
        when {
            e in VIEW_IMG -> {
                val imgs = siblings.filter { it.name.substringAfterLast('.', "").lowercase() in VIEW_IMG }
                onPreview(ZPreview.Images(imgs, imgs.indexOfFirst { it.path == item.path }.coerceAtLeast(0)))
            }
            e in VIEW_TXT -> onPreview(ZPreview.Text(item))
            categoryOfExt(e) == Category.VIDEOS || categoryOfExt(e) == Category.MUSIC -> {
                val cat = categoryOfExt(e)
                val list = siblings.filter { categoryOfExt(it.name.substringAfterLast('.', "").lowercase()) == cat }
                onPreview(ZPreview.Media(list, list.indexOfFirst { it.path == item.path }.coerceAtLeast(0)))
            }
            else -> try {
                ex.message = "Ouverture de ${item.name}…"
                ex.open(extractToCache(ctx, zip, item.path))
            } catch (x: Exception) {
                ex.message = if (x.message?.contains("encrypted", true) == true) "Fichier protégé par mot de passe : non pris en charge" else (x.message ?: "Ouverture impossible")
            }
        }
    }

    fun extract(item: ZipItem) {
        try {
            val out = extractBeside(zip, item.path)
            ex.message = "Extrait : ${out.name}"
            ex.reload()
        } catch (x: Exception) {
            ex.message = if (x.message?.contains("encrypted", true) == true) "Fichier protégé par mot de passe : non pris en charge" else (x.message ?: "Extraction impossible")
        }
    }

    LazyColumn(
        Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 14.dp, end = 14.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Résumé
                val total = files.sumOf { it.size.coerceAtLeast(0L) }
                val packed = files.sumOf { it.packed.coerceAtLeast(0L) }
                val saved = if (total > 0) (100 - packed * 100 / total).toInt().coerceIn(0, 100) else 0
                Box(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
                        .background(Brush.linearGradient(listOf(LS.Amber, lerp(LS.Amber, Color.Black, 0.45f))))
                        .padding(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("📦", fontSize = 34.sp)
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text("${files.size} fichier${if (files.size > 1) "s" else ""}", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                            Text(
                                "${Formatter.formatShortFileSize(ctx, total)} décompressé · ${Formatter.formatShortFileSize(ctx, packed)} compressé · −$saved %",
                                color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp,
                            )
                        }
                    }
                }
                // Fil d'Ariane
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Crumb("🏠 Racine", dir.isEmpty()) { onDir("") }
                    var acc = ""
                    dir.split('/').filter { it.isNotEmpty() }.forEach { seg ->
                        acc = if (acc.isEmpty()) seg else "$acc/$seg"
                        val target = acc
                        Text("›", color = LS.Muted)
                        Crumb(seg, target == dir) { onDir(target) }
                    }
                }
                if (rows.isEmpty()) Text("Dossier vide", Modifier.padding(8.dp), color = LS.Muted, fontSize = 13.sp)
            }
        }
        items(rows, key = { it.path }) { item ->
            val tint = tintOf(item)
            val shape = RoundedCornerShape(20.dp)
            Row(
                Modifier.fillMaxWidth().clip(shape).background(LS.Card).border(1.dp, LS.Line, shape)
                    .clickable { open(item) }.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier.size(46.dp).clip(RoundedCornerShape(14.dp))
                        .background(Brush.linearGradient(listOf(tint, lerp(tint, Color.Black, 0.35f)))),
                    contentAlignment = Alignment.Center,
                ) { Text(emojiOf(item), fontSize = 22.sp) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(item.name, color = LS.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        if (item.isDir) "${item.count} élément${if (item.count > 1) "s" else ""}"
                        else Formatter.formatShortFileSize(ctx, item.size.coerceAtLeast(0)) +
                            (if (item.time > 0) " · " + fmt.format(Date(item.time)) else ""),
                        color = LS.Muted, fontSize = 11.sp, maxLines = 1,
                    )
                }
                if (!item.isDir) {
                    Box(
                        Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(LS.Card2).clickable { extract(item) },
                        contentAlignment = Alignment.Center,
                    ) { Icon(Ic.Download, "Extraire", Modifier.size(20.dp), tint = LS.Blue) }
                } else Icon(Ic.Chevron, null, tint = LS.Muted)
            }
        }
    }
}

@Composable
private fun Crumb(text: String, current: Boolean, onClick: () -> Unit) {
    Text(
        text, color = if (current) LS.OnBlue else LS.Text, fontSize = 12.sp, fontWeight = FontWeight.Medium,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(if (current) LS.Blue else LS.Card2)
            .clickable(enabled = !current, onClick = onClick).padding(horizontal = 12.dp, vertical = 6.dp),
    )
}

@Composable
private fun ZipImages(zip: File, p: ZPreview.Images) {
    val pager = rememberPagerState(initialPage = p.start.coerceIn(0, (p.items.size - 1).coerceAtLeast(0))) { p.items.size }
    Column(Modifier.fillMaxSize()) {
        Text(
            "${pager.currentPage + 1}/${p.items.size} · ${p.items.getOrNull(pager.currentPage)?.name.orEmpty()}",
            Modifier.padding(horizontal = 16.dp, vertical = 4.dp), color = LS.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
        )
        HorizontalPager(state = pager, modifier = Modifier.fillMaxSize(), beyondViewportPageCount = 1) { i ->
            val item = p.items[i]
            val bmp by produceState<ImageBitmap?>(null, item.path) { value = withContext(Dispatchers.IO) { decodeEntry(zip, item.path) } }
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                val b = bmp
                if (b == null) CircularProgressIndicator() else Image(b, item.name, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            }
        }
    }
}

@Composable
private fun ZipText(zip: File, item: ZipItem) {
    val text by produceState("Chargement…", item.path) { value = withContext(Dispatchers.IO) { readEntryText(zip, item.path) } }
    SelectionContainer {
        Text(
            text, Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            color = LS.Text, fontSize = 12.sp, fontFamily = FontFamily.Monospace,
        )
    }
}
