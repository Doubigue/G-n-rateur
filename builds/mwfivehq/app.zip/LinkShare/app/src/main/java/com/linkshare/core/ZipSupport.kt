package com.linkshare.core

import android.net.Uri
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.BaseDataSource
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.TransferListener
import java.io.File
import java.io.FileNotFoundException
import java.io.IOException
import java.io.InputStream
import java.util.zip.ZipFile

/** Ouvre une archive ZIP ; les anciens zips dont les noms ne sont pas en UTF-8 sont relus en ISO-8859-1. */
fun openZip(f: File): ZipFile = try {
    ZipFile(f)
} catch (e: IllegalArgumentException) {
    ZipFile(f, Charsets.ISO_8859_1)
}

/** Adresse d'un fichier situé DANS une archive : `lszip://entry/<chemin dans le zip>?z=<chemin du zip>`. */
object ZipUri {
    const val SCHEME = "lszip"

    fun of(zip: File, entry: String): Uri =
        Uri.Builder().scheme(SCHEME).authority("entry").path("/$entry").appendQueryParameter("z", zip.absolutePath).build()
}

/**
 * Lit un fichier directement dans l'archive, sans rien écrire sur le disque : le lecteur (ExoPlayer) reçoit les octets
 * décompressés à la volée. Un fichier stocké sans compression se positionne instantanément ; un fichier compressé se
 * repositionne en relisant l'archive depuis l'entrée (rien n'est stocké).
 */
@UnstableApi
class ZipEntryDataSource : BaseDataSource(/* isNetwork = */ false) {
    private var zip: ZipFile? = null
    private var stream: InputStream? = null
    private var currentUri: Uri? = null
    private var remaining = C.LENGTH_UNSET.toLong()
    private var opened = false

    override fun open(dataSpec: DataSpec): Long {
        currentUri = dataSpec.uri
        transferInitializing(dataSpec)
        val zipPath = dataSpec.uri.getQueryParameter("z") ?: throw IOException("Archive manquante")
        val name = dataSpec.uri.path?.removePrefix("/") ?: throw IOException("Fichier manquant dans l'archive")
        val z = openZip(File(zipPath))
        zip = z
        val entry = z.getEntry(name) ?: throw FileNotFoundException(name)
        val s = z.getInputStream(entry)
        stream = s

        var skipped = 0L
        while (skipped < dataSpec.position) {
            val n = s.skip(dataSpec.position - skipped)
            if (n > 0) skipped += n else if (s.read() == -1) break else skipped++
        }
        val size = entry.size
        remaining = when {
            dataSpec.length != C.LENGTH_UNSET.toLong() -> dataSpec.length
            size >= 0 -> (size - dataSpec.position).coerceAtLeast(0L)
            else -> C.LENGTH_UNSET.toLong()
        }
        opened = true
        transferStarted(dataSpec)
        return remaining
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        if (length == 0) return 0
        if (remaining == 0L) return C.RESULT_END_OF_INPUT
        val toRead = if (remaining == C.LENGTH_UNSET.toLong()) length else minOf(remaining, length.toLong()).toInt()
        val n = stream?.read(buffer, offset, toRead) ?: return C.RESULT_END_OF_INPUT
        if (n == -1) return C.RESULT_END_OF_INPUT
        if (remaining != C.LENGTH_UNSET.toLong()) remaining -= n
        bytesTransferred(n)
        return n
    }

    override fun getUri(): Uri? = currentUri

    override fun close() {
        try {
            stream?.close()
            zip?.close()
        } catch (_: IOException) {
        } finally {
            stream = null
            zip = null
            currentUri = null
            if (opened) { opened = false; transferEnded() }
        }
    }
}

/** Fabrique du lecteur : adresses `lszip://` lues dans l'archive, tout le reste (fichier, http, content…) comme d'habitude. */
@UnstableApi
class ZipAwareDataSourceFactory(ctx: android.content.Context) : DataSource.Factory {
    private val default = DefaultDataSource.Factory(ctx)

    override fun createDataSource(): DataSource = SchemeSwitch(default.createDataSource(), ZipEntryDataSource())

    private class SchemeSwitch(private val base: DataSource, private val zip: DataSource) : DataSource {
        private var active: DataSource = base

        override fun addTransferListener(transferListener: TransferListener) {
            base.addTransferListener(transferListener)
            zip.addTransferListener(transferListener)
        }

        override fun open(dataSpec: DataSpec): Long {
            active = if (dataSpec.uri.scheme == ZipUri.SCHEME) zip else base
            return active.open(dataSpec)
        }

        override fun read(buffer: ByteArray, offset: Int, length: Int): Int = active.read(buffer, offset, length)

        override fun getUri(): Uri? = active.uri

        override fun getResponseHeaders(): Map<String, List<String>> = active.responseHeaders

        override fun close() = active.close()
    }
}
