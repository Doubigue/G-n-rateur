package com.linkshare.ui

import android.app.Activity
import android.app.PendingIntent
import android.app.PictureInPictureParams
import android.app.RemoteAction
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Icon
import android.util.Rational
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Fenêtre flottante (Picture-in-Picture) du lecteur vidéo : la vidéo se réduit en une petite fenêtre que l'on peut
 * déplacer n'importe où sur l'écran, agrandir, et qui reste affichée par-dessus les autres applis.
 * Un bouton lecture / pause est ajouté à la fenêtre.
 */
internal object PipHost {
    const val ACTION_TOGGLE = "com.linkshare.PIP_TOGGLE"

    /** Vrai quand l'activité est affichée dans la fenêtre flottante (le lecteur masque alors ses commandes). */
    var inPip by mutableStateOf(false)

    /** Vrai quand l'utilisateur a fermé la fenêtre flottante : le lecteur se ferme à son retour. */
    var dismissed by mutableStateOf(false)

    fun supported(a: Activity): Boolean =
        a.packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)

    /** Seule une vidéo en cours (hors dossier sécurisé) peut être réduite. */
    fun canEnter(a: Activity): Boolean =
        supported(a) && PlayerHost.videoActive && !PlayerHost.secure && PlayerHost.controller != null

    private fun params(a: Activity): PictureInPictureParams {
        val c = PlayerHost.controller
        val vs = c?.videoSize
        val ratio = if (vs != null && vs.width > 0 && vs.height > 0) vs.width * vs.pixelWidthHeightRatio / vs.height else 16f / 9f
        val playing = c?.playWhenReady == true
        val label = if (playing) "Pause" else "Lecture"
        val icon = Icon.createWithResource(a, if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
        val pi = PendingIntent.getBroadcast(
            a, 0, Intent(ACTION_TOGGLE).setPackage(a.packageName),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return PictureInPictureParams.Builder()
            .setAspectRatio(Rational((ratio.coerceIn(0.5f, 2.3f) * 1000).toInt(), 1000))
            .setActions(listOf(RemoteAction(icon, label, label, pi)))
            .build()
    }

    fun enter(a: Activity): Boolean {
        if (!canEnter(a)) return false
        return try { a.enterPictureInPictureMode(params(a)) } catch (e: Exception) { false }
    }

    /** Met à jour le bouton lecture / pause de la fenêtre flottante. */
    fun refresh(a: Activity) {
        if (!inPip) return
        try { a.setPictureInPictureParams(params(a)) } catch (_: Exception) {}
    }
}
