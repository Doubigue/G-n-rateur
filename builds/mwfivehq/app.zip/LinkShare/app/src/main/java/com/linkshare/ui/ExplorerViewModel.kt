package com.linkshare.ui

import android.app.Application
import android.content.ActivityNotFoundException
import android.content.ContentResolver
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import androidx.compose.runtime.*
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.*
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

data class LItem(val file: File, val isDir: Boolean, val size: Long, val modified: Long, val count: Int)

/** Élément de la corbeille : [dir] = son dossier de rangement, [file] = l'élément lui-même, [origin] = son chemin d'origine. */
data class TrashItem(val dir: File, val file: File, val origin: String, val deletedAt: Long, val size: Long, val isDir: Boolean)

/** Copie ou déplacement en attente : les éléments sont choisis, il reste à désigner le dossier de destination. */
data class PendingTransfer(val files: List<File>, val move: Boolean)

enum class SortKey(val label: String) { NAME("Nom"), DATE("Date"), SIZE("Taille"), TYPE("Type") }

enum class LCat(val label: String) {
    IMAGES("Images"), VIDEOS("Vidéos"), AUDIO("Audio"), DOCS("Documents"), ARCHIVES("Archives"),
    LARGE("Grands fichiers"), DUPES("Doublons"),
}

/** Extensions reconnues pour chaque catégorie (complètent le type MIME, parfois absent ou faux dans l'index Android). */
internal val IMG_EXT = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif", "avif", "dng", "jfif")
internal val VID_EXT = setOf("mp4", "mkv", "webm", "3gp", "3g2", "mov", "avi", "m4v", "ts", "mts", "m2ts", "flv", "wmv", "mpg", "mpeg", "vob", "ogv")
internal val AUD_EXT = setOf("mp3", "m4a", "aac", "ogg", "opus", "wav", "flac", "amr", "wma", "mid", "midi", "3ga")
private val DEEP_CATS = setOf(LCat.IMAGES, LCat.VIDEOS, LCat.AUDIO, LCat.DOCS, LCat.ARCHIVES)
private const val LARGE_BYTES = 50L * 1024 * 1024

/** Le coffre n'est ouvert qu'après le déverrouillage du téléphone, et se referme dès que l'app quitte l'écran. */
object VaultLock { var unlocked by mutableStateOf(false) }

/** Compteur incrémenté à chaque retour dans l'app (rafraîchit permissions et listes). */
object AppEvents { var resumeTick by mutableIntStateOf(0) }

internal val VIEW_IMG = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif", "avif", "jfif")
internal val VIEW_TXT = setOf("txt", "md", "csv", "log", "json", "xml", "ini", "conf", "yml", "yaml", "srt")
internal const val TRASH_DAYS = 30
private val ARCHIVE_EXT = setOf("zip", "rar", "7z", "tar", "gz")
private val DOC_EXT = listOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "odt", "csv", "rtf")

internal fun File.isArchive() = extension.lowercase() in ARCHIVE_EXT

class ExplorerViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx get() = getApplication<Application>()

    val root: File = Environment.getExternalStorageDirectory()
    val vaultDir: File get() = File(ctx.filesDir, "vault").apply { mkdirs() }

    var dir by mutableStateOf(root)
    var category by mutableStateOf<LCat?>(null)
    /** Onglets d'une catégorie : un par dossier contenant des fichiers de ce type (le dossier, son nombre de fichiers). */
    var catTabs by mutableStateOf<List<Pair<File, Int>>>(emptyList())
    /** Onglet choisi : null = « Tout », sinon le chemin du dossier. */
    var folderTab by mutableStateOf<String?>(null)
    var query by mutableStateOf("")
    var items by mutableStateOf<List<LItem>>(emptyList())
    var recents by mutableStateOf<List<File>>(emptyList())
    /** Dernières photos et vidéos : diaporamas animés des cartes Images et Vidéos de l'accueil. */
    var homeImages by mutableStateOf<List<File>>(emptyList())
    var homeVideos by mutableStateOf<List<File>>(emptyList())
    /** Analyse approfondie (parcours des dossiers) en cours pour la catégorie affichée. */
    var deepScanning by mutableStateOf(false)
    var vaultItems by mutableStateOf<List<LItem>>(emptyList())
    /** Coffre : grille par défaut, tri propre (indépendant de l'explorateur) et dossier affiché (null = la racine du coffre). */
    var vaultGrid by mutableStateOf(true)
    var vaultSort by mutableStateOf(SortKey.NAME)
    var vaultAsc by mutableStateOf(true)
    var vaultSub by mutableStateOf<File?>(null)
    var sort by mutableStateOf(SortKey.NAME)
    var ascending by mutableStateOf(true)
    var grid by mutableStateOf(UiStyle.defaultGrid)
    var loading by mutableStateOf(false)
    var busy by mutableStateOf<String?>(null)
    var message by mutableStateOf<String?>(null)
    var viewing by mutableStateOf<File?>(null)
    var zipPrompt by mutableStateOf<File?>(null)
    /** Archive dont on parcourt le contenu (sans la décompresser). */
    var zipBrowsing by mutableStateOf<File?>(null)
    /** Fichiers « frères » du fichier ouvert (même type) : on passe de l'un à l'autre en balayant. */
    var viewList by mutableStateOf<List<File>>(emptyList())
    /** Non nul = le sélecteur de dossier de destination est affiché. */
    var transfer by mutableStateOf<PendingTransfer?>(null)
    val selected = mutableStateListOf<String>()
    /** Non vide = la feuille « Détails » est affichée pour ces éléments. */
    var infoFiles by mutableStateOf<List<File>>(emptyList())
    /** Fichiers pour lesquels la feuille « Studio » (MediaStudio + Modifier avec…) est ouverte. */
    var studioFiles by mutableStateOf<List<File>>(emptyList())
    var trashItems by mutableStateOf<List<TrashItem>>(emptyList())
    var trashCount by mutableIntStateOf(0)

    /** Point d'entrée de l'explorateur : le « retour » s'arrête ici et ramène à l'accueil. */
    var base by mutableStateOf(root)
    /** Vrai quand la liste affichée est celle des favoris. */
    var favMode by mutableStateOf(false)
    /** Taille occupée par catégorie (dl, img, vid, aud, doc), affichée sur l'accueil. */
    var sizes by mutableStateOf<Map<String, Long>>(emptyMap())
    val favorites = mutableStateListOf<String>()

    private val prefs get() = ctx.getSharedPreferences("linkshare", Context.MODE_PRIVATE)

    init { favorites.addAll(prefs.getStringSet("favs", emptySet()).orEmpty()); loadTrash() }

    private var loadJob: Job? = null
    private var searchJob: Job? = null

    val canGoUp get() = query.isNotEmpty() || category != null || dir.path != base.path

    // ───────────────────────────── Navigation ─────────────────────────────

    fun refresh() { reload(); loadRecents() }

    fun openDir(d: File) { category = null; query = ""; if (favMode) base = d; favMode = false; dir = d; reload() }

    fun openCategory(c: LCat) { favMode = false; category = c; folderTab = null; catTabs = emptyList(); query = ""; reload() }

    /** Entrées depuis l'accueil : le dossier choisi devient le point d'entrée. */
    fun enter(d: File) { favMode = false; base = d; openDir(d) }
    fun enterCategory(c: LCat) = openCategory(c)
    fun enterFavorites() { category = null; query = ""; selected.clear(); favMode = true; reload() }

    /** Remonte d'un cran ; false = on est au point d'entrée (retour à l'accueil). */
    fun back(): Boolean = when {
        selected.isNotEmpty() -> { selected.clear(); true }
        query.isNotEmpty() -> { query = ""; reload(); true }
        favMode || category != null -> false
        dir.path != base.path -> { dir = dir.parentFile ?: base; reload(); true }
        else -> false
    }

    fun leave() { favMode = false; category = null; folderTab = null; catTabs = emptyList(); query = ""; selected.clear() }

    fun up() {
        when {
            query.isNotEmpty() -> { query = ""; reload() }
            category != null -> { category = null; reload() }
            dir.path != base.path -> { dir = dir.parentFile ?: base; reload() }
        }
    }

    fun selectFolderTab(path: String?) { folderTab = path; reload() }

    fun updateQuery(q: String) {
        query = q
        searchJob?.cancel()
        searchJob = viewModelScope.launch { if (q.isNotBlank()) delay(300); reload() }
    }

    fun reload(keepSelection: Boolean = false) {
        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            loading = true
            val d = dir; val q = query.trim(); val cat = category; val fav = favMode; val favs = favorites.toList()
            val tab = folderTab
            var tabs: List<Pair<File, Int>>? = null
            val res = try {
                withContext(Dispatchers.IO) {
                    when {
                        fav -> favs.map { File(it) }.filter { it.exists() }.map { it.toItem() }.filter { q.isEmpty() || it.file.name.contains(q, true) }
                        cat != null -> {
                            val all = categoryItems(cat)
                            // Onglets : les dossiers qui contiennent des fichiers de cette catégorie
                            tabs = all.groupBy { it.file.parentFile }.filterKeys { it != null }
                                .map { (k, v) -> k!! to v.size }
                                .sortedBy { it.first.name.lowercase() }
                            all.filter { tab == null || it.file.parentFile?.path == tab }
                                .filter { q.isEmpty() || it.file.name.contains(q, true) }
                        }
                        q.isNotEmpty() -> search(d, q)
                        else -> d.listFiles().orEmpty().filter { UiStyle.showHidden || !it.name.startsWith(".") }.map { it.toItem() }
                    }
                }
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { message = e.message ?: e.toString(); emptyList() }
            tabs?.let { t ->
                catTabs = t
                // Le dossier choisi n'existe plus (fichiers déplacés ou supprimés) : retour à « Tout »
                if (tab != null && t.none { it.first.path == tab }) folderTab = null
            }
            // Doublons : on garde les fichiers identiques côte à côte
            items = if (cat == LCat.DUPES) res else sortItems(res)
            if (!keepSelection) selected.clear() else selected.retainAll(res.map { it.file.path }.toSet())
            loading = false
            if (cat != null) maybeDeepScan(cat)
        }
    }

    fun loadRecents() {
        viewModelScope.launch {
            recents = withContext(Dispatchers.IO) {
                try {
                    queryFiles("${MediaStore.Files.FileColumns.SIZE} > 0 AND ${MediaStore.Files.FileColumns.MIME_TYPE} IS NOT NULL", 150).take(15)
                } catch (e: Exception) { emptyList() }
            }
            val (img, vid) = withContext(Dispatchers.IO) {
                fun latest(c: LCat) = runCatching { queryItems(categorySelection(c), 14).map { it.file } }.getOrDefault(emptyList())
                latest(LCat.IMAGES) to latest(LCat.VIDEOS)
            }
            homeImages = img; homeVideos = vid
        }
    }

    // ───────────────────────────── Favoris & tailles ─────────────────────────────

    private fun saveFavs() { prefs.edit().putStringSet("favs", favorites.toSet()).apply() }

    fun favoriteSelected() {
        val paths = selected.toList()
        if (paths.isEmpty()) return
        val all = paths.all { it in favorites }
        if (all) favorites.removeAll(paths.toSet()) else paths.forEach { if (it !in favorites) favorites.add(it) }
        saveFavs()
        message = if (all) "Retiré des favoris" else "Ajouté aux favoris"
        selected.clear()
        if (favMode) reload()
    }

    fun toggleFavorite(f: File) {
        val had = favorites.remove(f.path)
        if (!had) favorites.add(f.path)
        saveFavs()
        message = if (had) "Retiré des favoris" else "Ajouté aux favoris"
    }

    private fun docSelection(): String {
        val name = MediaStore.Files.FileColumns.DISPLAY_NAME
        return DOC_EXT.joinToString(" OR ", "(", ")") { "LOWER($name) LIKE '%.$it'" }
    }

    fun loadSizes() {
        viewModelScope.launch {
            sizes = withContext(Dispatchers.IO) {
                fun sum(uri: Uri, sel: String? = null): Long {
                    var t = 0L
                    try {
                        ctx.contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.SIZE), sel, null, null)?.use { c ->
                            while (c.moveToNext()) t += c.getLong(0)
                        }
                    } catch (_: Exception) {}
                    return t
                }
                val dl = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                mapOf(
                    "dl" to dl.walkTopDown().filter { it.isFile }.sumOf { it.length() },
                    "img" to sum(MediaStore.Images.Media.EXTERNAL_CONTENT_URI),
                    "vid" to sum(MediaStore.Video.Media.EXTERNAL_CONTENT_URI),
                    "aud" to sum(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI),
                    "doc" to sum(MediaStore.Files.getContentUri("external"), docSelection()),
                )
            }
        }
    }

    // ───────────────────────────── Tri ─────────────────────────────

    fun changeSort(k: SortKey) { sort = k; items = sortItems(items) }
    fun setSort(k: SortKey, asc: Boolean) { sort = k; ascending = asc; items = sortItems(items) }
    fun toggleOrder() { ascending = !ascending; items = sortItems(items) }

    private fun sortItems(l: List<LItem>, key: SortKey = sort, asc: Boolean = ascending): List<LItem> {
        val cmp: Comparator<LItem> = when (key) {
            SortKey.NAME -> compareBy<LItem> { it.file.name.lowercase() }
            SortKey.DATE -> compareBy<LItem> { it.modified }
            SortKey.SIZE -> compareBy<LItem> { if (it.isDir) it.count.toLong() else it.size }
            SortKey.TYPE -> compareBy<LItem>({ it.file.extension.lowercase() }, { it.file.name.lowercase() })
        }
        val c = if (asc) cmp else cmp.reversed()
        return l.sortedWith(compareByDescending<LItem> { it.isDir }.then(c))
    }

    private fun File.toItem() = LItem(this, isDirectory, if (isDirectory) 0L else length(), lastModified(), if (isDirectory) (list()?.size ?: 0) else 0)

    /** Recherche récursive (largeur d'abord) dans le dossier courant, limitée à 300 résultats. */
    private suspend fun search(base: File, q: String): List<LItem> {
        val out = ArrayList<LItem>()
        val queue = ArrayList<File>().apply { add(base) }
        var i = 0
        while (i < queue.size && out.size < 300) {
            currentCoroutineContext().ensureActive()
            val kids = queue[i++].listFiles() ?: continue
            for (k in kids) {
                if (k.name.startsWith(".")) continue
                if (k.name.contains(q, ignoreCase = true) && out.size < 300) out += k.toItem()
                if (k.isDirectory) queue.add(k)
            }
        }
        return out
    }

    private fun queryFiles(selection: String, limit: Int): List<File> {
        val b = Bundle().apply {
            putString(ContentResolver.QUERY_ARG_SQL_SELECTION, selection)
            putStringArray(ContentResolver.QUERY_ARG_SORT_COLUMNS, arrayOf(MediaStore.Files.FileColumns.DATE_MODIFIED))
            putInt(ContentResolver.QUERY_ARG_SORT_DIRECTION, ContentResolver.QUERY_SORT_DIRECTION_DESCENDING)
            putInt(ContentResolver.QUERY_ARG_LIMIT, limit)
        }
        val out = ArrayList<File>()
        ctx.contentResolver.query(
            MediaStore.Files.getContentUri("external"), arrayOf(MediaStore.Files.FileColumns.DATA), b, null,
        )?.use { c ->
            while (c.moveToNext()) {
                val p = c.getString(0) ?: continue
                if (p.contains("/.") || p.contains("/Android/")) continue
                val f = File(p)
                if (f.isFile) out += f
            }
        }
        return out
    }

    /** Fichiers d'une catégorie connus d'Android (tous les volumes : mémoire interne, carte SD, clé USB). */
    private fun categorySelection(c: LCat): String {
        val col = MediaStore.Files.FileColumns.MIME_TYPE
        val name = MediaStore.Files.FileColumns.DISPLAY_NAME
        fun exts(l: Collection<String>) = l.joinToString(" OR ", "(", ")") { "LOWER($name) LIKE '%.$it'" }
        return when (c) {
            LCat.IMAGES -> "($col LIKE 'image/%' OR ${exts(IMG_EXT)})"
            LCat.VIDEOS -> "($col LIKE 'video/%' OR ${exts(VID_EXT)})"
            LCat.AUDIO -> "($col LIKE 'audio/%' OR ${exts(AUD_EXT)})"
            LCat.DOCS -> exts(DOC_EXT)
            LCat.ARCHIVES -> exts(ARCHIVE_EXT)
            LCat.LARGE -> "${MediaStore.Files.FileColumns.SIZE} > $LARGE_BYTES"
            LCat.DUPES -> "${MediaStore.Files.FileColumns.SIZE} > 102400"
        }
    }

    /**
     * Interroge l'index d'Android sans limite de nombre (l'ancienne limite de 500 cachait une partie des photos et
     * des vidéos). Taille et date viennent de l'index : l'affichage reste rapide même avec des milliers de fichiers.
     */
    private fun queryItems(selection: String, limit: Int = 0, bySize: Boolean = false): List<LItem> {
        val b = Bundle().apply {
            putString(ContentResolver.QUERY_ARG_SQL_SELECTION, "($selection) AND ${MediaStore.Files.FileColumns.SIZE} > 0")
            putStringArray(ContentResolver.QUERY_ARG_SORT_COLUMNS, arrayOf(if (bySize) MediaStore.Files.FileColumns.SIZE else MediaStore.Files.FileColumns.DATE_MODIFIED))
            putInt(ContentResolver.QUERY_ARG_SORT_DIRECTION, ContentResolver.QUERY_SORT_DIRECTION_DESCENDING)
            if (limit > 0) putInt(ContentResolver.QUERY_ARG_LIMIT, limit)
        }
        val out = ArrayList<LItem>()
        val seen = HashSet<String>()
        ctx.contentResolver.query(
            MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL), arrayOf(MediaStore.Files.FileColumns.DATA, MediaStore.Files.FileColumns.SIZE, MediaStore.Files.FileColumns.DATE_MODIFIED), b, null,
        )?.use { c ->
            while (c.moveToNext()) {
                val p = c.getString(0) ?: continue
                if (!keepPath(p) || !seen.add(p)) continue
                val f = File(p)
                if (!f.isFile) continue
                val size = c.getLong(1).takeIf { it > 0 } ?: f.length()
                val mod = c.getLong(2).takeIf { it > 0 }?.times(1000) ?: f.lastModified()
                out += LItem(f, false, size, mod, 0)
            }
        }
        return out
    }

    /** Fichiers à montrer : jamais la corbeille ni les données privées des applis ; les cachés selon le réglage. */
    private fun keepPath(p: String): Boolean {
        if (p.contains("/.LinkShare-Corbeille/") || p.contains("/Android/data/") || p.contains("/Android/obb/")) return false
        return UiStyle.showHidden || !p.contains("/.")
    }

    private fun mediaStoreItems(c: LCat): List<LItem> = when (c) {
        LCat.DUPES -> findDuplicates()
        LCat.LARGE -> queryItems(categorySelection(c), bySize = true)
        else -> queryItems(categorySelection(c))
    }

    // ── Analyse approfondie : certains dossiers (WhatsApp, Telegram, applis de montage, dossiers avec un fichier
    // « .nomedia »…) ne sont pas indexés par Android. On parcourt aussi les dossiers pour ne rien oublier.
    private val deepCache = java.util.concurrent.ConcurrentHashMap<LCat, Pair<Long, List<LItem>>>()
    private var deepJob: Job? = null

    private fun categoryItems(c: LCat): List<LItem> {
        val ms = mediaStoreItems(c)
        if (!UiStyle.deepScan || c !in DEEP_CATS) return ms
        val deep = deepCache[c]?.second ?: return ms
        val known = ms.mapTo(HashSet()) { it.file.path }
        val extra = deep.filter { it.file.path !in known && keepPath(it.file.path) && it.file.isFile }
        return if (extra.isEmpty()) ms else (ms + extra).sortedByDescending { it.modified }
    }

    private fun maybeDeepScan(c: LCat) {
        if (!UiStyle.deepScan || c !in DEEP_CATS) return
        val at = deepCache[c]?.first ?: 0L
        if (System.currentTimeMillis() - at < 90_000L) return
        if (deepJob?.isActive == true) return
        deepJob = viewModelScope.launch {
            deepScanning = true
            val found = withContext(Dispatchers.IO) { runCatching { deepScan(c) }.getOrDefault(emptyList()) }
            deepCache[c] = System.currentTimeMillis() to found
            deepScanning = false
            if (category == c) reload(keepSelection = true)
        }
    }

    /** Volumes montés : mémoire interne + carte SD / clé USB. */
    fun volumeRoots(): List<File> = runCatching {
        ctx.getSystemService(android.os.storage.StorageManager::class.java).storageVolumes
            .filter { it.state == Environment.MEDIA_MOUNTED }.mapNotNull { it.directory }
    }.getOrDefault(emptyList()).ifEmpty { listOf(root) }

    private suspend fun deepScan(c: LCat): List<LItem> {
        val exts: Set<String> = when (c) {
            LCat.IMAGES -> IMG_EXT
            LCat.VIDEOS -> VID_EXT
            LCat.AUDIO -> AUD_EXT
            LCat.DOCS -> DOC_EXT.toSet()
            LCat.ARCHIVES -> ARCHIVE_EXT
            else -> return emptyList()
        }
        val out = ArrayList<LItem>()
        val queue = ArrayDeque<Pair<File, Int>>()
        volumeRoots().forEach { queue.add(it to 0) }
        while (queue.isNotEmpty() && out.size < 20_000) {
            currentCoroutineContext().ensureActive()
            val (d, depth) = queue.removeFirst()
            val kids = d.listFiles() ?: continue
            for (k in kids) {
                val n = k.name
                if (k.isDirectory) {
                    if (depth >= 14) continue
                    if (n.startsWith(".") && !UiStyle.showHidden) continue
                    if (n == ".LinkShare-Corbeille") continue
                    if (d.name == "Android" && (n == "data" || n == "obb")) continue
                    queue.add(k to depth + 1)
                } else {
                    val e = n.substringAfterLast('.', "").lowercase()
                    if (e in exts && (UiStyle.showHidden || !n.startsWith("."))) {
                        val len = k.length()
                        if (len > 0) out += LItem(k, false, len, k.lastModified(), 0)
                    }
                }
            }
        }
        return out
    }

    // ── Doublons : même taille, puis même empreinte (début + fin du fichier)
    private fun findDuplicates(): List<LItem> {
        val all = queryItems(categorySelection(LCat.DUPES), bySize = true)
        val out = ArrayList<LItem>()
        for ((_, group) in all.groupBy { it.size }) {
            if (group.size < 2) continue
            group.groupBy { quickHash(it.file) }
                .filter { it.key != null && it.value.size > 1 }
                .values.forEach { same -> out += same.sortedBy { it.modified } }
            if (out.size > 3000) break
        }
        return out
    }

    private fun quickHash(f: File): String? = runCatching {
        val md = java.security.MessageDigest.getInstance("MD5")
        java.io.RandomAccessFile(f, "r").use { r ->
            val buf = ByteArray(64 * 1024)
            val n = r.read(buf)
            if (n > 0) md.update(buf, 0, n)
            val len = r.length()
            if (len > 2L * buf.size) {
                r.seek(len - buf.size)
                val m = r.read(buf)
                if (m > 0) md.update(buf, 0, m)
            }
        }
        md.digest().joinToString("") { "%02x".format(it) }
    }.getOrNull()

    // ───────────────────────────── Fichiers APK ─────────────────────────────

    /** Tous les fichiers .apk du stockage (via MediaStore). */
    fun findApks(): List<File> =
        try {
            val name = MediaStore.Files.FileColumns.DISPLAY_NAME
            queryFiles("LOWER($name) LIKE '%.apk'", 1000)
        } catch (e: Exception) { emptyList() }

    /** Ouvre l'installateur Android pour un fichier APK. */
    fun installApk(f: File) {
        try {
            if (!ctx.packageManager.canRequestPackageInstalls()) {
                message = "Autorise LinkShare à installer des applications, puis réessaie"
                ctx.startActivity(
                    Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                return
            }
            val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
            ctx.startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            message = e.message ?: e.toString()
        }
    }

    // ───────────────────────────── Ouverture ─────────────────────────────

    /** 0 = image, 1 = vidéo, 2 = audio, 3 = texte : on ne balaie qu'entre fichiers du même type. */
    private fun viewKind(f: File): Int {
        val e = f.extension.lowercase()
        return when {
            e in VIEW_IMG -> 0
            categoryOfExt(e) == Category.VIDEOS -> 1
            categoryOfExt(e) == Category.MUSIC -> 2
            else -> 3
        }
    }

    /** Liste dans laquelle on balaie : celle d'où vient le fichier (liste affichée, coffre ou récents), même type seulement. */
    private fun siblingsOf(f: File, from: List<File>?): List<File> {
        val kind = viewKind(f)
        if (kind == 3) return listOf(f)
        val src = from ?: listOf(items.map { it.file }, vaultItems.map { it.file }).firstOrNull { l -> l.any { it.path == f.path } }
        val list = src?.filter { !it.isDirectory && viewKind(it) == kind }.orEmpty()
        return if (list.any { it.path == f.path }) list else listOf(f)
    }

    fun open(f: File, siblings: List<File>? = null) {
        val e = f.extension.lowercase()
        val cat = categoryOfExt(e)
        when {
            f.isDirectory ->
                if (f.path.startsWith(vaultDir.path)) openVaultDir(f) else openDir(f)
            e in VIEW_IMG || e in VIEW_TXT || e in VIEW_WEB || e in VIEW_OFFICE || cat == Category.VIDEOS || cat == Category.MUSIC -> {
                viewList = siblingsOf(f, siblings)
                viewing = f
            }
            // PDF : lecteur intégré (pages affichées dans l'appli)
            e == "pdf" -> { viewList = listOf(f); viewing = f }
            e == "zip" || e == "cbz" -> zipBrowsing = f
            else -> external(f)
        }
    }

    fun external(f: File) {
        try {
            val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
            ctx.startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: ActivityNotFoundException) {
            message = "Aucune application pour ouvrir ce fichier"
        } catch (e: Exception) {
            message = e.message ?: e.toString()
        }
    }

    // ───────────────────────────── Sélection ─────────────────────────────

    fun toggle(path: String) { if (!selected.remove(path)) selected.add(path) }
    fun selectAll(list: List<LItem>) { selected.clear(); selected.addAll(list.map { it.file.path }) }
    private fun picked(list: List<LItem>) = list.filter { it.file.path in selected }.map { it.file }

    // ───────────────────────────── Détails & renommage ─────────────────────────────

    fun showInfo(files: List<File>) { infoFiles = files.filter { it.exists() } }

    /** Éléments cochés, quelle que soit la liste affichée (explorateur ou coffre). */
    fun selectedFiles(): List<File> = selected.map { File(it) }

    fun inVault(f: File) = f.path.startsWith(vaultDir.path)

    /** Renomme un fichier ou un dossier ; renvoie le nouvel élément, ou null si c'est impossible. */
    fun rename(f: File, newName: String): File? {
        val n = newName.trim()
        if (n.isEmpty() || n.contains('/') || n == "." || n == "..") { message = "Nom invalide"; return null }
        if (n == f.name) return f
        val t = File(f.parentFile, n)
        if (t.exists()) { message = "« $n » existe déjà"; return null }
        val old = filePathsOf(f)
        if (!f.renameTo(t)) { message = "Impossible de renommer cet élément"; return null }
        if (favorites.remove(f.path)) { favorites.add(t.path); saveFavs() }
        message = "Renommé en « $n »"
        viewModelScope.launch {
            withContext(Dispatchers.IO) { runCatching { scanPaths(old + filePathsOf(t)) } }
            reload(); loadRecents()
        }
        return t
    }

    /** Crée un dossier dans le dossier affiché, puis rafraîchit la liste. */
    fun createFolderHere(name: String): Boolean {
        val ok = createFolder(dir, name)
        if (ok) { message = "Dossier « ${name.trim()} » créé"; reload() }
        return ok
    }

    // ───────────────────────────── Travaux (IO) ─────────────────────────────

    private fun work(label: String, block: () -> String) {
        viewModelScope.launch {
            busy = label
            try { message = withContext(Dispatchers.IO) { block() }.ifEmpty { null } }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { message = e.message ?: e.toString() }
            busy = null
            reload(); loadRecents()
            if (VaultLock.unlocked) loadVault()
            loadTrash()
        }
    }

    private fun stamp() = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    private fun unique(f: File): File {
        if (!f.exists()) return f
        val ext = f.extension.let { if (it.isEmpty()) "" else ".$it" }
        return generateSequence(1) { it + 1 }
            .map { File(f.parentFile, "${f.nameWithoutExtension} ($it)$ext") }
            .first { !it.exists() }
    }

    /** Partage via le menu Android. Les dossiers sont envoyés sous forme d'archive ZIP. */
    fun shareSelected() { val f = picked(items); selected.clear(); shareFiles(f) }

    fun shareFiles(files: List<File>) {
        if (files.isEmpty()) return
        work("Préparation du partage…") {
            val cache = File(ctx.cacheDir, "share").apply { deleteRecursively(); mkdirs() }
            val srcs = files.map { f ->
                if (f.isDirectory) unique(File(cache, f.name + ".zip")).also { z -> writeZip(listOf(f), z) { n -> busy = "Compression · $n" } } else f
            }
            val uris = srcs.map { FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", it) }
            val intent = if (uris.size == 1) {
                val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(srcs[0].extension.lowercase()) ?: "*/*"
                Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, uris[0])
            } else {
                Intent(Intent.ACTION_SEND_MULTIPLE).setType("*/*").putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
            }
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            intent.clipData = ClipData.newRawUri("", uris[0]).also { c -> uris.drop(1).forEach { c.addItem(ClipData.Item(it)) } }
            ctx.startActivity(Intent.createChooser(intent, "Partager").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            if (files.any { it.isDirectory }) "Les dossiers sont envoyés en archive ZIP" else ""
        }
    }

    fun compressSelected(files: List<File> = picked(items)) {
        if (files.isEmpty()) return
        val parent = files.first().parentFile ?: return
        val dest = unique(File(parent, if (files.size == 1) files[0].name + ".zip" else "Archive_${stamp()}.zip"))
        selected.clear()
        work("Compression…") {
            writeZip(files, dest) { busy = "Compression · $it" }
            "Archive créée : ${dest.name}"
        }
    }

    fun extract(archive: File) {
        val target = unique(File(archive.parentFile, archive.nameWithoutExtension))
        work("Décompression…") {
            readZip(archive, target) { busy = "Décompression · $it" }
            "Décompressé dans « ${target.name} »"
        }
    }

    /** Supprimer = placer dans la corbeille (restaurable, vidée automatiquement après 30 jours). */
    fun deleteSelected(files: List<File> = picked(items)) {
        selected.clear()
        work("Déplacement vers la corbeille…") {
            val n = moveToTrash(files)
            "$n élément(s) placé(s) dans la corbeille"
        }
    }

    private fun writeZip(sources: List<File>, dest: File, onFile: (String) -> Unit) {
        val destPath = dest.canonicalPath
        ZipOutputStream(BufferedOutputStream(FileOutputStream(dest))).use { z ->
            fun add(f: File, name: String) {
                if (f.canonicalPath == destPath) return
                if (f.isDirectory) {
                    z.putNextEntry(ZipEntry("$name/")); z.closeEntry()
                    f.listFiles()?.forEach { add(it, "$name/${it.name}") }
                } else {
                    onFile(f.name)
                    z.putNextEntry(ZipEntry(name).apply { time = f.lastModified() })
                    FileInputStream(f).use { it.copyTo(z, 64 * 1024) }
                    z.closeEntry()
                }
            }
            sources.forEach { add(it, it.name) }
        }
    }

    /** Décompression protégée contre les chemins « ../ » (zip-slip). */
    private fun readZip(archive: File, target: File, onFile: (String) -> Unit) {
        target.mkdirs()
        val base = target.canonicalPath + File.separator
        ZipInputStream(BufferedInputStream(FileInputStream(archive))).use { zin ->
            var next: ZipEntry? = zin.nextEntry
            while (next != null) {
                val entry: ZipEntry = next
                val out = File(target, entry.name).canonicalFile
                if (out.path.startsWith(base)) {
                    if (entry.isDirectory) out.mkdirs()
                    else {
                        out.parentFile?.mkdirs()
                        onFile(out.name)
                        FileOutputStream(out).use { zin.copyTo(it, 64 * 1024) }
                    }
                }
                zin.closeEntry()
                next = zin.nextEntry
            }
        }
    }

    // ───────────────────────────── Copier / déplacer ─────────────────────────────

    /** Ouvre le sélecteur de dossier pour copier (move = false) ou déplacer (move = true) la sélection. */
    fun startTransfer(move: Boolean, files: List<File> = picked(items)) {
        selected.clear()
        if (files.isNotEmpty()) transfer = PendingTransfer(files, move)
    }

    fun cancelTransfer() { transfer = null }

    /** Message d'erreur si la destination est impossible (dossier dans lui-même, rien à déplacer), sinon null. */
    fun transferProblem(t: PendingTransfer, dest: File): String? {
        val d = runCatching { dest.canonicalPath }.getOrDefault(dest.path)
        for (f in t.files) {
            val p = runCatching { f.canonicalPath }.getOrDefault(f.path)
            if (f.isDirectory && (d == p || d.startsWith(p + File.separator))) return "Impossible de mettre « ${f.name} » dans lui-même"
        }
        if (t.move && t.files.all { (it.parentFile?.path ?: "") == dest.path }) return "Ces éléments sont déjà dans ce dossier"
        return null
    }

    fun createFolder(parent: File, name: String): Boolean {
        val n = name.trim()
        if (n.isEmpty() || n.contains('/')) { message = "Nom de dossier invalide"; return false }
        val d = File(parent, n)
        if (d.exists()) { message = "« $n » existe déjà"; return false }
        val ok = d.mkdirs()
        if (!ok) message = "Impossible de créer le dossier"
        return ok
    }

    /** Copie ou déplace les éléments en attente dans [dest]. Les homonymes sont renommés « nom (1) ». */
    fun pasteTo(dest: File) {
        val t = transfer ?: return
        if (transferProblem(t, dest) != null) return
        transfer = null
        selected.clear()
        val verb = if (t.move) "Déplacement" else "Copie"
        work("$verb…") {
            var ok = 0
            var fail = 0
            val created = ArrayList<String>()
            for (f in t.files) {
                busy = "$verb · ${f.name}"
                if (t.move && f.parentFile?.path == dest.path) { ok++; continue }
                val target = unique(File(dest, f.name))
                try {
                    val done = if (t.move) {
                        // renameTo est instantané sur le même volume ; sinon on copie puis on supprime l'original
                        f.renameTo(target) || (f.copyRecursively(target) && f.deleteRecursively())
                    } else {
                        f.copyRecursively(target)
                    }
                    if (done) { ok++; target.walkTopDown().filter { it.isFile }.forEach { created += it.path } }
                    else { fail++; if (!t.move) target.deleteRecursively() }
                } catch (e: Exception) {
                    fail++
                    if (!t.move) target.deleteRecursively()
                }
            }
            scanPaths(created)
            val what = if (t.move) "déplacé(s)" else "copié(s)"
            "$ok élément(s) $what" + if (fail > 0) " · $fail échec(s)" else ""
        }
    }

    /** Signale les nouveaux fichiers à Android pour qu'ils apparaissent aussitôt dans Images, Vidéos, Audio, Documents. */
    private fun scanPaths(paths: List<String>) {
        if (paths.isEmpty()) return
        val latch = CountDownLatch(paths.size)
        MediaScannerConnection.scanFile(ctx, paths.toTypedArray(), null) { _, _ -> latch.countDown() }
        latch.await(10, TimeUnit.SECONDS)
    }

    // ───────────────────────────── Coffre-fort ─────────────────────────────

    /** Dossier du coffre actuellement affiché. */
    val vaultCurrent: File get() = vaultSub ?: vaultDir

    /**
     * Index des emplacements d'origine : nom de l'élément rangé à la racine du coffre → chemin qu'il avait avant.
     * Il est gardé hors du coffre (dans filesDir) pour ne pas apparaître dans la liste ; il sert à la restauration.
     */
    private val vaultIndexFile get() = File(ctx.filesDir, "vault_index.properties")
    private val vaultIndexLock = Any()

    private fun readVaultIndex(): java.util.Properties = java.util.Properties().apply {
        runCatching { if (vaultIndexFile.exists()) vaultIndexFile.reader(Charsets.UTF_8).use { load(it) } }
    }

    private fun updateVaultIndex(block: (java.util.Properties) -> Unit) {
        synchronized(vaultIndexLock) {
            val p = readVaultIndex()
            block(p)
            runCatching { vaultIndexFile.writer(Charsets.UTF_8).use { p.store(it, null) } }
        }
    }

    /** Emplacement d'origine d'un élément du coffre (à la racine ou dans un dossier rangé) ; null si inconnu. */
    private fun originOf(f: File, index: java.util.Properties): File? {
        val rel = runCatching { f.relativeTo(vaultDir).path }.getOrNull() ?: return null
        if (rel.isEmpty() || rel.startsWith("..")) return null
        val top = rel.substringBefore(File.separatorChar)
        val base = index.getProperty(top) ?: return null
        val rest = rel.substringAfter(File.separatorChar, "")
        return if (rest.isEmpty()) File(base) else File(File(base), rest)
    }

    fun loadVault() {
        if (vaultSub?.isDirectory == false) vaultSub = null // le dossier affiché a disparu
        val dir = vaultCurrent
        viewModelScope.launch {
            vaultItems = withContext(Dispatchers.IO) {
                // Les éléments supprimés du coffre n'ont plus besoin de leur emplacement d'origine
                val present = vaultDir.list()?.toSet().orEmpty()
                val stale = synchronized(vaultIndexLock) { readVaultIndex() }.stringPropertyNames().filter { it !in present }
                if (stale.isNotEmpty()) updateVaultIndex { p -> stale.forEach { p.remove(it) } }
                sortItems(dir.listFiles().orEmpty().map { it.toItem() }, vaultSort, vaultAsc)
            }
        }
    }

    fun setVaultSort(k: SortKey, asc: Boolean) { vaultSort = k; vaultAsc = asc; vaultItems = sortItems(vaultItems, k, asc) }

    fun openVaultDir(d: File) { selected.clear(); vaultSub = d; loadVault() }

    /** Remonte d'un dossier dans le coffre ; false = on est déjà à la racine. */
    fun vaultUp(): Boolean {
        val cur = vaultSub ?: return false
        selected.clear()
        val parent = cur.parentFile
        vaultSub = if (parent == null || parent.path == vaultDir.path || !parent.path.startsWith(vaultDir.path)) null else parent
        loadVault()
        return true
    }

    fun lockVault() {
        PlayerHost.stopIfSecure()
        VaultLock.unlocked = false; selected.clear(); vaultItems = emptyList(); vaultSub = null
        viewing?.takeIf { inVault(it) }?.let { viewing = null; viewList = emptyList() }
    }

    /** Fichiers contenus dans [f] (ou [f] lui-même), pour signaler à Android ce qui apparaît ou disparaît. */
    private fun filePathsOf(f: File): List<String> =
        if (f.isDirectory) f.walkTopDown().filter { it.isFile }.map { it.path }.take(2000).toList() else listOf(f.path)

    /** Range les éléments (fichiers ou dossiers entiers) dans le coffre en retenant leur emplacement d'origine. */
    fun moveToVault(files: List<File> = picked(items)) {
        selected.clear()
        work("Déplacement vers le coffre…") {
            var n = 0
            val origins = LinkedHashMap<String, String>() // nom dans le coffre → chemin d'origine
            val gone = ArrayList<String>()
            files.forEach { f ->
                if (f.path.startsWith(vaultDir.path)) return@forEach
                busy = "Coffre · ${f.name}"
                val paths = filePathsOf(f)
                val t = unique(File(vaultDir, f.name))
                try {
                    // renameTo est instantané sur le même volume ; sinon on copie puis on supprime l'original
                    val ok = f.renameTo(t) || (f.copyRecursively(t) && f.deleteRecursively())
                    if (ok) { origins[t.name] = f.path; gone += paths; n++ } else t.deleteRecursively()
                } catch (e: Exception) { t.deleteRecursively() }
            }
            if (origins.isNotEmpty()) updateVaultIndex { p -> origins.forEach { (k, v) -> p.setProperty(k, v) } }
            scanPaths(gone) // ils disparaissent aussitôt de Images, Vidéos, Audio, Documents
            "$n élément(s) déplacé(s) dans le coffre"
        }
    }

    /** Remet chaque élément dans le dossier où il se trouvait avant d'entrer au coffre (dossiers compris). */
    fun restoreFromVault(files: List<File> = picked(vaultItems)) {
        selected.clear()
        val fallback = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Restauré du coffre")
        work("Restauration…") {
            val index = synchronized(vaultIndexLock) { readVaultIndex() }
            var n = 0
            var elsewhere = 0
            val created = ArrayList<String>()
            files.forEach { f ->
                busy = "Restauration · ${f.name}"
                val origin = originOf(f, index)
                fun place(parent: File, name: String): File? {
                    val t = unique(File(parent, name))
                    return try {
                        parent.mkdirs()
                        if (f.copyRecursively(t)) t else { t.deleteRecursively(); null }
                    } catch (e: Exception) { t.deleteRecursively(); null }
                }
                val parent = origin?.parentFile
                var target: File? = if (origin != null && parent != null) place(parent, origin.name) else null
                if (target == null) {
                    // Emplacement d'origine inconnu (rangé avant cette version) ou devenu inaccessible
                    target = place(fallback, f.name)
                    if (target != null) elsewhere++
                }
                val done = target
                if (done != null) {
                    f.deleteRecursively()
                    created += filePathsOf(done)
                    n++
                }
            }
            scanPaths(created)
            "$n élément(s) restauré(s)" +
                if (elsewhere == 0) " à leur emplacement d'origine" else " · $elsewhere dans Download/Restauré du coffre (origine inconnue)"
        }
    }

    /** Suppression définitive (sans corbeille) : fichiers et dossiers entiers, impossible à annuler. */
    fun deleteForever(files: List<File>) {
        selected.clear()
        work("Suppression définitive…") {
            var n = 0
            val gone = ArrayList<String>()
            files.forEach { f ->
                busy = "Suppression · ${f.name}"
                val paths = filePathsOf(f)
                if (f.deleteRecursively()) { n++; gone += paths }
            }
            scanPaths(gone) // disparaissent aussitôt de Images, Vidéos, Audio, Documents
            val fail = files.size - n
            "$n élément(s) supprimé(s) définitivement" + if (fail > 0) " · $fail impossible(s) à supprimer" else ""
        }
    }

    fun deleteFromVault(files: List<File> = picked(vaultItems)) {
        selected.clear()
        work("Suppression…") {
            var n = 0
            files.forEach { if (it.deleteRecursively()) n++ }
            "$n élément(s) supprimé(s) du coffre"
        }
    }

    // ───────────────────────────── Corbeille ─────────────────────────────

    /** Dossier caché à la racine du stockage (même volume : le déplacement est instantané). */
    val trashDir: File
        get() = File(root, ".LinkShare-Corbeille").apply {
            mkdirs()
            File(this, ".nomedia").let { if (!it.exists()) runCatching { it.createNewFile() } }
        }

    private fun readTrash(): List<TrashItem> {
        val limit = System.currentTimeMillis() - TRASH_DAYS * 24L * 3600_000L
        return trashDir.listFiles().orEmpty().filter { it.isDirectory }.mapNotNull { d ->
            val meta = File(d, "meta.txt")
            val lines = runCatching { meta.readLines() }.getOrDefault(emptyList())
            val file = d.listFiles()?.firstOrNull { it.name != "meta.txt" }
            val at = lines.getOrNull(1)?.toLongOrNull() ?: d.lastModified()
            if (file == null || at < limit) { d.deleteRecursively(); null }
            else TrashItem(
                d, file, lines.getOrNull(0) ?: file.name, at,
                if (file.isDirectory) file.walkTopDown().filter { it.isFile }.sumOf { it.length() } else file.length(),
                file.isDirectory,
            )
        }.sortedByDescending { it.deletedAt }
    }

    /** Relit la corbeille (et en purge les éléments de plus de [TRASH_DAYS] jours). */
    fun loadTrash() {
        viewModelScope.launch {
            val l = withContext(Dispatchers.IO) { readTrash() }
            trashItems = l; trashCount = l.size
        }
    }

    private fun moveToTrash(files: List<File>): Int {
        var n = 0
        val origins = ArrayList<String>()
        files.forEach { f ->
            val d = File(trashDir, "${System.currentTimeMillis()}_${n}_${(0..9999).random()}").apply { mkdirs() }
            val target = File(d, f.name)
            val moved = f.renameTo(target) || try {
                (if (f.isDirectory) f.copyRecursively(target) else { f.copyTo(target); true }).also { ok ->
                    if (ok) f.deleteRecursively() else target.deleteRecursively()
                }
            } catch (e: Exception) { target.deleteRecursively(); false }
            if (moved) {
                File(d, "meta.txt").writeText(f.path + "\n" + System.currentTimeMillis())
                origins += f.path; n++
            } else d.deleteRecursively()
        }
        scanPaths(origins)
        return n
    }

    fun restoreFromTrash(list: List<TrashItem>) {
        work("Restauration…") {
            var n = 0
            val restored = ArrayList<String>()
            list.forEach { t ->
                try {
                    val origin = File(t.origin)
                    val parent = origin.parentFile ?: root
                    parent.mkdirs()
                    val target = unique(File(parent, t.file.name))
                    val ok = t.file.renameTo(target) || (if (t.isDir) t.file.copyRecursively(target) else { t.file.copyTo(target); true })
                    if (ok) { t.dir.deleteRecursively(); restored += target.path; n++ }
                } catch (e: Exception) { /* élément laissé dans la corbeille */ }
            }
            scanPaths(restored)
            "$n élément(s) restauré(s)"
        }
    }

    fun deleteTrashForever(list: List<TrashItem>) {
        work("Suppression définitive…") {
            var n = 0
            list.forEach { if (it.dir.deleteRecursively()) n++ }
            "$n élément(s) supprimé(s) définitivement"
        }
    }

    fun emptyTrash() = deleteTrashForever(trashItems)

    // ───────────────────────────── Nettoyeur ─────────────────────────────

    /** Nettoyage : [toTrash] passe par la corbeille (restaurable), [toDelete] est effacé (miniatures, dossiers vides, cache). */
    fun clean(toTrash: List<File>, toDelete: List<File>, onDone: () -> Unit = {}) {
        work("Nettoyage…") {
            var freed = 0L
            toDelete.forEach { f ->
                val len = if (f.isDirectory) f.walkTopDown().filter { it.isFile }.sumOf { it.length() } else f.length()
                if (f.deleteRecursively()) freed += len
            }
            freed += toTrash.sumOf { it.length() }
            val n = moveToTrash(toTrash)
            android.os.Handler(android.os.Looper.getMainLooper()).post { onDone() }
            "Nettoyage terminé : " + android.text.format.Formatter.formatShortFileSize(ctx, freed) + " libérés" +
                if (n > 0) " · $n fichier(s) dans la corbeille" else ""
        }
    }

    /** Vide le cache de l'appli (miniatures, fichiers temporaires de partage). */
    fun clearAppCache(): Long {
        val dirs = listOfNotNull(ctx.cacheDir, ctx.externalCacheDir)
        val size = dirs.sumOf { d -> d.walkTopDown().filter { it.isFile }.sumOf { it.length() } }
        dirs.forEach { d -> d.listFiles()?.forEach { it.deleteRecursively() } }
        deepCache.clear()
        return size
    }

    fun appCacheSize(): Long = listOfNotNull(ctx.cacheDir, ctx.externalCacheDir)
        .sumOf { d -> d.walkTopDown().filter { it.isFile }.sumOf { it.length() } }

    /** Oublie l'analyse approfondie (après un changement de réglage). */
    fun forgetScans() { deepCache.clear() }

    // ───────────────────────────── Scan de documents ─────────────────────────────

    fun saveScan(uri: Uri) {
        val scans = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "LinkShare Scans")
        category = null; query = ""; favMode = false; base = scans; dir = scans
        work("Enregistrement du scan…") {
            scans.mkdirs()
            val out = unique(File(scans, "Scan_${stamp()}.pdf"))
            val input = ctx.contentResolver.openInputStream(uri) ?: error("Scan illisible")
            input.use { i -> FileOutputStream(out).use { i.copyTo(it) } }
            "Scan enregistré : Documents/LinkShare Scans/${out.name}"
        }
    }
}
