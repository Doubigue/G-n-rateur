# LinkShare

Partage rapide Android (Kotlin / Compose / Ktor) avec accès distant aux fichiers et applications.

## Lancer
1. Ouvrir le dossier dans Android Studio (Ladybug ou plus récent, JDK 17) et laisser Gradle synchroniser.
2. Installer sur deux téléphones (Android 11+).
3. Téléphone A : « Envoyer » → « Activer le point d'accès » → un code s'affiche.
4. Téléphone B : « Scanner » → scanne le code, accepte la connexion proposée par Android.
5. Les deux téléphones affichent les cartes « autre téléphone » et « Moi » : chacun parcourt, télécharge et envoie.

## Interface (explorateur façon Files by Google)
Accueil, de haut en bas : carrousel **Récents** (défile tout seul en boucle, se met en pause quand on le fait glisser puis
reprend), **Catégories** (Images et Vidéos en diaporamas animés des dernières photos / vidéos, puis Téléchargements, Audio,
Documents, Applications), **Outils** (Archives, Grands fichiers > 50 Mo, Doublons, Nettoyeur) et, en bas, **Stockage**
(jauge de la mémoire interne, puis **Dossier sécurisé** et **Autres stockages** côte à côte).

La **pilule** flottante en bas de l'accueil : **Partager** à gauche (LinkShare : envoyer / recevoir) et **Scanner** à droite
(scan de documents en PDF, ML Kit, enregistré dans Documents/LinkShare Scans).
- **Autres stockages** : mémoire interne, carte SD et clé USB (OTG) avec leur jauge, plus les dossiers système (DCIM, Films,
  Musique, médias des applications).
- **Doublons** : fichiers identiques (même taille et même empreinte), rangés côte à côte.
- **Nettoyeur** : APK déjà installés, miniatures en cache, fichiers temporaires, dossiers vides, cache de l'appli. Les APK et
  fichiers temporaires passent par la corbeille.
- Explorateur : dossiers en grille (bascule liste), recherche récursive, tri, lecture intégrée, ZIP, dossier sécurisé, corbeille.
- Les **vidéos** s'affichent avec un aperçu animé (plusieurs images de la vidéo en fondu + léger zoom).

## Images, Vidéos, Audio : rien n'est oublié
- L'index d'Android est lu **sans limite** (avant : 500 fichiers au plus, ce qui cachait des photos de l'appareil photo et des
  vidéos), sur tous les volumes (mémoire interne, carte SD, clé USB), y compris `Android/media` (WhatsApp, Telegram…).
- **Analyse approfondie** (activée par défaut, Paramètres › Fichiers) : les dossiers sont aussi parcourus pour trouver les
  médias qu'Android n'indexe pas (dossiers avec `.nomedia`, applis de montage…). Les résultats s'ajoutent tout seuls à la liste.
- Formats reconnus en plus : HEIC/HEIF, AVIF, DNG ; M4V, TS, MTS, FLV, MPG ; AMR…

## Paramètres
- **Apparence** : 9 thèmes (Graphite, Noir AMOLED, Nuit bleue, Forêt, Prune, Or DL Vibe, Braise, Clair, Sable), 9 couleurs
  d'accent, forme des coins (arrondis / très ronds / carrés), style des cartes (dégradé / plat / contour), grille compacte.
- **Animations** : activer / couper, vitesse des diaporamas, aperçus vidéo animés.
- **Accueil** : afficher ou masquer Récents et Outils.
- **Fichiers** : analyse approfondie, fichiers cachés, vue grille par défaut, confirmation de suppression, corbeille, vider le cache.
- **Lecteur** : style du lecteur de musique (Vinyle / Pochette / Minimal), saut de 5 / 10 / 15 / 30 s, reprise de lecture,
  écran allumé pendant les vidéos.
- **Sécurité** (verrouillage du coffre) et **À propos**, avec réinitialisation de l'apparence.

## Onglets « Tout » + dossiers, APK non installés
- **Images, Vidéos, Audio, Documents** : une rangée d'onglets sous la recherche. **Tout** liste tous les fichiers de la catégorie ;
  chaque onglet suivant est un dossier qui en contient (avec le nombre de fichiers) et n'affiche que ceux de ce dossier.
- **Applications** : même rangée d'onglets. **Tout** = applications installées + section « Fichiers APK non installés »
  (icône, nom, version et taille lus dans l'APK ; ceux dont l'appli est déjà installée sont masqués) ; les autres onglets = dossiers contenant des APK.
  Toucher un APK ouvre l'installateur Android (la première fois, autoriser LinkShare à « installer des applis inconnues »).

## Lecteur vidéo / audio
**Vidéo** : commandes en verre dépoli qui se masquent seules, gros bouton lecture en dégradé avec halo, barre de progression
épaisse (toucher pour sauter). En haut : retour, titre, **vitesse** (0,5x à 2x), **format de l'image** (ajuster / remplir /
étirer), **verrouillage de l'écran** (bloque les gestes ; un cadenas permet de déverrouiller) et **rotation** imposée par
l'appli. Centre : précédent, −N s, lecture / pause, +N s, suivant. Bas : Aléatoire, Boucle, Tout, **file d'attente**.
Gestes : balayage horizontal = média suivant / précédent ; vertical = volume (droite) ou luminosité (gauche) ; double toucher = ±N s.

**Musique** : fond flou tiré de la pochette (ou d'une photo de l'appareil photo) avec des halos de couleur qui dérivent,
**disque vinyle** qui tourne pendant la lecture (ou grande pochette / anneaux, au choix dans Paramètres), titre, artiste et
album lus dans le fichier, égaliseur animé, Aléatoire / Répéter (tout → titre → non), vitesse, **minuterie de mise en veille**
(10 à 90 min), saut ±N s et file d'attente.

**Reprise** : une vidéo ou une musique de plus de 30 s repart là où elle avait été laissée.

## Fichiers web (https)
- **Ouvrir un lien** : l'icône « lien » en haut de l'accueil (à gauche de l'engrenage) ouvre une boîte où coller une adresse
  `https://…` (ou `http://`). Vidéo et audio (mp4, mkv, webm, mp3, m4a, flux HLS `.m3u8` et DASH `.mpd`…) passent dans le lecteur
  plein écran, les images s'affichent, les textes (txt, json, srt…) se lisent. Sans extension reconnaissable, le type est demandé au
  serveur. Les autres formats (PDF, ZIP…) proposent d'ouvrir avec une autre appli, d'enregistrer dans `Download/LinkShare`
  ou de décompresser (ZIP).
- **Depuis une autre appli** : un lien web vers un fichier vidéo, audio, image ou texte peut s'ouvrir avec LinkShare, même quand
  l'appli d'origine n'annonce pas de type (le lien doit se terminer par l'extension du fichier).

## Pages web (HTML)
Les fichiers `.html`, `.htm`, `.xhtml` et `.svg` s'affichent comme dans un navigateur (lecteur web intégré), au lieu de leur code source :
- **Dans l'explorateur**, toucher un fichier HTML l'ouvre en page ; ses images, styles et scripts rangés à côté se chargent.
- **Liens https / http** (icône « lien » de l'accueil, ou lien reçu d'une autre appli) : la page s'affiche, avec navigation entre
  les pages (retour = page précédente, puis fermeture), actualisation et barre de chargement. Le type est vérifié auprès du
  serveur si le lien n'a pas d'extension. Un fichier à télécharger part dans `Download/LinkShare`.
- **« Ouvrir avec »** : un fichier ou un lien HTML reçu d'une autre appli s'ouvre de la même façon. Les liens `mailto:`, `tel:`…
  sont confiés à l'appli qui convient.

## Intégration au système
- **« Ouvrir avec »** : en plus de vidéo, audio, image et texte, LinkShare se déclare pour PDF, Word / Excel / PowerPoint, OpenDocument,
  RTF, ZIP, RAR, 7z, GZ et TAR. Les documents **Word (docx), Excel (xlsx), PowerPoint (pptx), OpenDocument (odt, ods, odp) et RTF** s'affichent dans l'appli (texte, tableaux, diapositives). Pour les autres formats, elle propose : ouvrir avec une autre appli (LinkShare exclue de la liste),
  enregistrer dans Download/LinkShare, décompresser (ZIP), partager.
- **Sélecteur de fichiers Android** (`FilesDocumentsProvider`) : « LinkShare » apparaît parmi les emplacements quand une appli demande un fichier
  (Joindre, Importer, Enregistrer sous…). Le stockage interne y est parcourable, avec recherche, miniatures, création, renommage et suppression.
  Les dossiers cachés (commençant par un point) sont masqués. Il faut l'accès à tous les fichiers ; sans lui l'emplacement n'est pas proposé.

## Grille, copier / déplacer, balayage
- **Grille** (bouton en haut à droite) : dossiers en grandes cases, fichiers en miniatures (image et vidéo : aperçu ; PDF, texte, Word,
  Excel, PowerPoint : le contenu de la 1re page / des premières lignes ; audio : icône + nom). Fonctionne aussi dans Images, Vidéos, Audio et Documents.
- **Copier / Déplacer** : appui long pour sélectionner (fichiers et dossiers), puis « Copier » ou « Déplacer » dans la barre
  bleue (elle défile vers la droite) → choisir le dossier de destination (« Nouveau dossier » possible) → « Copier ici » /
  « Déplacer ici ». Un homonyme devient « nom (1) » ; un dossier ne peut pas être mis dans lui-même.
- **Images** : balayer vers la gauche / la droite pour passer à l'image suivante / précédente (même dossier ou même catégorie).
- **Vidéo et audio** : balayer vers la gauche / la droite = média suivant / précédent (liste de lecture du dossier, aussi
  depuis la notification) ; balayer vers le haut / le bas = volume ; double toucher à gauche / à droite = −10 s / +10 s ;
  toucher = afficher / masquer les commandes. Même chose pour les fichiers lus depuis l'autre téléphone.

## Lecture, ouverture depuis d'autres applis, partage
- **Lecture en arrière-plan** (service Media3, `PlaybackService`) : notification de lecture dans la barre d'état
  (icône LinkShare, titre, lecture/pause/avance), commandes sur l'écran verrouillé, la lecture continue écran éteint ou
  appli quittée avec Accueil (vidéo comme audio). Le Wi-Fi reste actif écran éteint, donc un flux venant de l'autre
  téléphone ne se coupe pas. Toucher la notification rouvre l'appli. La flèche retour du lecteur arrête la lecture.
  Le nom d'un fichier du dossier sécurisé n'est pas affiché sur l'écran verrouillé.
- **Appli par défaut / « Ouvrir avec »** : LinkShare se déclare pour vidéo, audio, image, texte (fichiers locaux, `content://`
  ou `file://`), vidéo/audio en streaming (liens http/https), dossiers, Téléchargements et « Parcourir » (Réglages › Stockage).
  Pour en faire l'appli par défaut : ouvrir un fichier depuis une autre appli, choisir LinkShare puis « Toujours »
  (ou Réglages › Applis › LinkShare › Ouvrir par défaut).
- **Partager** (menu Android) fichiers et dossiers : appui long pour sélectionner, puis « Partager ». Les dossiers partent
  en ZIP (un ZIP par dossier). Aussi disponible dans le menu ⋮ des récents (fichiers).
- **Logo** : `res/drawable/ic_launcher_*` (icône adaptative + monochrome), `ic_logo` (appli, lecteur audio), `ic_stat_logo`
  (barre d'état) ; sources dans `branding/` (SVG + PNG 512).

## Paramètres, coffre et corbeille
- **Paramètres** : toucher l'en-tête de l'accueil (logo + « LinkShare / Explorateur de fichiers », engrenage à droite).
- **Verrouillage du coffre** (Paramètres › Sécurité) : par défaut le verrouillage du téléphone ; on peut définir un **schéma** ou un **code**
  propres au coffre (stockés en PBKDF2 salé, 30 s d'attente après 5 échecs). Pour ouvrir ce réglage et le changer, l'appli demande
  d'abord l'**empreinte du verrouillage d'écran** du téléphone (ou son code si l'empreinte échoue). Option « Ouvrir aussi avec l'empreinte » :
  elle utilise les doigts enregistrés dans le téléphone (Android ne permet pas d'enregistrer une empreinte propre à l'appli).
- **Corbeille** (Paramètres › Fichiers) : « Suppr. » place les éléments dans la corbeille (dossier caché `.LinkShare-Corbeille`) ;
  restauration à l'emplacement d'origine, suppression définitive ou « Vider » ; vidée automatiquement après 30 jours.
- **Luminosité** : dans le lecteur vidéo / audio, balayer vers le haut / le bas sur la **moitié gauche** de l'écran règle la luminosité,
  sur la **moitié droite** le volume.

## Dossier sécurisé (coffre)
- **Fichiers et dossiers** : appui long dans l'explorateur, puis « Sécurisé ». Un dossier entier est rangé avec son contenu, et on
  peut l'ouvrir dans le coffre (flèche retour = dossier parent, puis verrouillage). Les éléments rangés disparaissent aussitôt des
  galeries et des catégories.
- **Grille par défaut** (bouton en haut à droite pour passer en liste) : dossiers en grandes cases, fichiers en miniatures.
- **Tri** (bouton en haut à droite) : nom, date, taille, type, dans les deux sens, plus « Tout sélectionner ». Le tri du coffre est
  indépendant de celui de l'explorateur.
- **Restaurer** remet chaque élément **dans le dossier d'où il vient** (le dossier est recréé s'il n'existe plus ; un homonyme devient
  « nom (1) »). L'emplacement d'origine est mémorisé à la mise au coffre dans `files/vault_index.properties` (hors du coffre). Les
  éléments rangés avec une ancienne version, dont l'origine est inconnue, vont dans `Download/Restauré du coffre`.

## Connexion à double sens, point d'accès et transferts rapides (nouveau)
**Envoyer** (téléphone A) : un bouton **« Activer le point d'accès »** s'affiche. LinkShare crée son propre point d'accès
(Wi-Fi Direct **5 GHz** en priorité, sinon la bande choisie par le téléphone, sinon le point d'accès local d'Android),
puis affiche le **code à scanner**. Le code contient le nom et le mot de passe du point d'accès.
- Android 13+ : autoriser « Appareils à proximité ». Android 11-12 : autoriser la localisation et l'activer.
- « Déjà sur le même Wi-Fi ? » affiche un code sans point d'accès.

**Scanner** (téléphone B) : avant le scan, l'écran vérifie la radio.
- Si le point d'accès de LinkShare est actif : bouton **« Désactiver le point d'accès et activer le Wi-Fi »**.
- Si le partage de connexion du téléphone est actif : bouton **« Désactiver le point d'accès »** (ouvre le réglage, Android
  n'autorise pas une appli à le couper elle-même), puis « Activer le Wi-Fi » si besoin.
- Tout est prêt : l'appareil photo s'ouvre directement. Après le scan, Android demande de confirmer la connexion au
  point d'accès de l'autre téléphone (une seule touche), puis la connexion se fait.

**Après le scan, des deux côtés** : écran avec deux jolies cartes, **le nom de l'autre téléphone** puis **Moi**.
- Toucher l'autre → ses fichiers et ses applis : parcourir, lire, cocher, **Télécharger**.
- Toucher **Moi** → mes fichiers (raccourcis Appareil photo, Téléchargements, Images…), mes **applis** (APK) ou
  « Autres » (sélecteur Android) : cocher puis **Envoyer**.
- On revient aux cartes avec la flèche retour. Chaque téléphone a accès aux fichiers de l'autre.
- **Envoi et réception en même temps** : écran **Transferts** avec deux anneaux (Envoi ↑ / Réception ↓), et pour chaque
  élément le **pourcentage**, la taille, le débit et le temps restant ; annulation élément par élément ou « Tout annuler ».
  Une petite barre de pourcentage reste visible en bas des écrans de fichiers.
- Tout arrive dans `Download/LinkShare` (les photos et vidéos apparaissent dans la galerie).

**Écran éteint / appli quittée** : un service au premier plan garde le serveur, le point d'accès, le Wi-Fi (verrou haute
performance) et le processeur éveillés pendant toute la session. La notification affiche **↑ x % ↓ y %**, le débit et une
barre de progression, avec « Annuler les transferts » et « Se déconnecter ». L'exemption d'optimisation de batterie est
demandée une fois (recommandée).

**Rapidité** :
- Point d'accès **Wi-Fi Direct 5 GHz** au lieu du 2,4 GHz : en général 3 à 5 fois plus rapide.
- **Voie rapide** (port 8766) : les fichiers ne passent plus par HTTP mais par un protocole TCP minimal ; l'envoi utilise
  `sendfile()` du noyau (zéro copie), tampons de socket de 4 Mo.
- Les gros fichiers (≥ 24 Mo) sont coupés en **3 morceaux envoyés en parallèle**, plusieurs fichiers partent en même temps
  (4 connexions au maximum) ; un dossier est envoyé fichier par fichier sans ZIP, avec sa taille totale connue d'avance.
- HTTP (port 8765) reste utilisé pour parcourir, les miniatures et la lecture en streaming.

**Déconnexion** : bouton sur l'écran des cartes ; l'autre téléphone est prévenu, le point d'accès est coupé et le Wi-Fi
normal revient. Si l'autre disparaît (hors de portée), la connexion est fermée au bout d'une vingtaine de secondes.

## Préparatifs, connexion directe et stabilité (v suivante)
- **Écran « Les préparatifs »** (comme Xender) avant Envoyer et avant Scanner : une ligne par condition avec son bouton —
  Autoriser l'accès aux fichiers, *Couper le point d'accès* (scan seulement), **Ouvrir le WLAN** (ouvre la petite fenêtre
  Wi-Fi d'Android en bas de l'écran, avec son interrupteur ; elle est ouverte « pour résultat », sinon Android la referme aussitôt. Si un téléphone ne l'a pas, la fenêtre Wi-Fi de LinkShare — interrupteur, Paramètres, OK — prend le relais), Autoriser les appareils à proximité / la localisation, Ouvrir le GPS (Android 11-12),
  et en « Recommandé » les notifications et le fonctionnement écran éteint (batterie). Chaque ligne passe au vert ✓ dès que
  c'est fait ; **SUIVANT** s'active quand tout l'obligatoire est prêt. Si tout est déjà prêt, l'écran est sauté.
- **Connexion directe Wi-Fi Direct** : le téléphone qui scanne rejoint le groupe de l'autre avec son nom, son mot de passe et
  sa fréquence (lus dans le code) — sans fenêtre de confirmation, sans balayage Wi-Fi (Android en limite le nombre) et en
  gardant son propre Wi-Fi. Si cela échoue, l'ancienne méthode (fenêtre « Se connecter ») prend le relais.
- **Stabilité** : les serveurs démarrent une seule fois par processus (plus d'erreur « port déjà utilisé » en relançant le
  partage), hors du fil principal ; toutes les erreurs de permission / Wi-Fi / service sont rattrapées et affichées au lieu
  de fermer l'appli ; messages d'erreur clairs à la connexion.
- **Plus rapide** : morceaux parallèles 4 au lieu de 3 dès 16 Mo, 6 connexions simultanées, blocs de 8 Mo ; notre serveur
  démarre pendant qu'on rejoint l'autre téléphone (connexion plus courte).
- Sur Tecno / Infinix / Xiaomi / Oppo, autoriser aussi le **démarrage automatique** et « Aucune restriction » de batterie
  pour LinkShare dans les réglages du téléphone : sinon le système peut couper l'appli en arrière-plan.

## Réseau
Point d'accès créé par LinkShare (recommandé, le plus rapide), ou même Wi-Fi.

## À faire ensuite
- TLS (certificat auto-signé épinglé dans le QR) : actuellement HTTP + jeton aléatoire de 192 bits.
- Choix des dossiers partagés + écran de consentement / révocation.
- Visionneuse texte/PDF, reprise des transferts, installation directe des APK.

## Détails des fichiers, carrousel et nouvelle présentation (0.9)
- **Infos à la sélection** : dès qu'on sélectionne (appui long), une carte apparaît au-dessus de la barre d'actions.
  Un fichier : nom, type, dossier, taille et date. Un dossier : taille totale, nombre de sous-dossiers et de fichiers
  (calculés en arrière-plan, les chiffres grimpent en direct). Plusieurs éléments : total de la sélection.
- **Feuille « Détails »** : toucher cette carte, le bouton **Infos** de la barre, ou le **ⓘ** de chaque ligne / dossier.
  Aperçu, étiquettes, chiffres clés, puis nom, type (MIME), dossier, emplacement, taille exacte en octets, date,
  accès ; en plus selon le type : dimensions d'une image, durée / résolution / débit d'une vidéo, titre / artiste / album
  d'un morceau, paquet et version d'un APK. Actions rapides : Ouvrir, Partager, Favori, **Renommer**, Copier le chemin,
  Voir le dossier. Fonctionne aussi dans le dossier sécurisé (lecture seule).
- **Récents en carrousel** : grande carte centrale, voisines estompées sur les côtés, points de position, défilement
  automatique (il s'arrête dès qu'on le fait glisser). Chaque carte montre type, taille, ancienneté et dossier.
- **Jauge de stockage** sur l'accueil : anneau de remplissage, espace libre et barre de répartition
  (Images, Vidéos, Audio, Documents, Autres).
- **Accès rapide** : pastilles vers les dossiers courants présents sur le téléphone (Appareil photo, Captures, WhatsApp…).
- **Explorateur** : fil d'Ariane cliquable, résumé « n dossiers · n fichiers · taille », bouton **Nouveau dossier**,
  cartes à pastilles colorées par type de fichier.

## Clé de signature dédiée
L'appli est signée avec sa propre clé : `app/linkshare-release.jks` (alias `linkshare`, mots de passe dans
`app/keystore.properties`). Debug et release utilisent cette clé, donc chaque nouvelle version s'installe **par-dessus**
l'ancienne, quel que soit le serveur qui compile (avant, la clé debug changeait d'une compilation à l'autre).
- Empreinte SHA-256 : `0F:62:32:9C:30:1D:B9:FA:AB:D1:84:FC:75:D3:B0:62:05:11:55:D6:EB:3D:48:D3:3F:34:75:26:F7:A0:85:CE`
- Valable jusqu'en 2056.
- **Garde une copie de ces deux fichiers en lieu sûr** : sans eux, impossible de publier une mise à jour qui s'installe
  sur la version existante. Ne les mets pas dans un dépôt public.
- Première installation avec cette clé : désinstaller une seule fois l'ancienne version (signée avec l'ancienne clé).

## Mises à jour intégrées
Paramètres › **Mises à jour** : version installée, bouton **Rechercher une mise à jour**, choix de la **source**, vérification
au démarrage. Quand une version plus récente existe, un bandeau **Installer la mise à jour** apparaît en haut de l'accueil :
l'APK est téléchargé (avec progression), vérifié (même appli `com.linkshare`, numéro de version plus grand), puis l'installeur
d'Android s'ouvre. La clé de signature dédiée permet l'installation par-dessus l'ancienne version (données conservées).

Source possible :
- un dépôt GitHub `propriétaire/dépôt` : publier chaque version dans **Releases** avec l'APK en pièce jointe
  (tag = numéro de version, ex. `v1.2`) ; pour un dépôt privé, ajouter un jeton GitHub (lecture seule) ;
- ou le lien d'un manifeste JSON : `{"versionCode": 12, "versionName": "1.2", "url": "https://…/LinkShare.apk", "notes": "…"}`.

**À chaque nouvelle version, augmenter `versionCode` et `versionName`** dans `app/build.gradle.kts`, sinon elle n'est pas
proposée (Android refuse d'installer un numéro égal ou inférieur).

## Dossier sécurisé : confidentialité
- Il se **verrouille immédiatement** dès que l'on quitte l'appli : bouton « récents », Accueil, appel, écran qui s'éteint.
- Un fichier du dossier sécurisé ouvert à l'écran (image, PDF, texte, document, vidéo, musique) se ferme en même temps.
- **Aucune lecture en arrière-plan** : la vidéo ou la musique du dossier sécurisé s'arrête dès que l'on quitte l'appli ou que le dossier se verrouille.
- **Aucune notification** et aucune commande sur l'écran verrouillé pour ces médias (lecteur interne, sans service de lecture).
- Pas de capture d'écran, et l'aperçu des applis récentes reste vide tant que le dossier est ouvert.

## Scores des matchs
- **Écran Scores** (accueil › Outils › Scores) : matchs en direct, d'hier, d'aujourd'hui et de demain, groupés par jour. Choix des championnats
  (Ligue 1, Ligue 2, Ligue des champions, Ligue Europa, Premier League, LaLiga, Serie A, Bundesliga, NBA). Actualisation automatique
  (30 s pendant un match, 2 min sinon) et bouton ↻.
- **Détail d'un match** : toucher un match ouvre ses **statistiques** (possession, tirs, tirs cadrés, corners, fautes, cartons, passes…
  en barres comparatives) et ses **temps forts** (buts, cartons, remplacements), avec stade et affluence. Actualisé toutes les 30 s pendant le match.
- **Recherche** (loupe en haut de l'écran Scores) : trouve une équipe ou un championnat parmi **tous** les championnats proposés, même ceux
  qui ne sont pas cochés.
- **Scores en notification** : interrupteur dans l'écran Scores. Une notification discrète liste les matchs en direct (ou ceux du jour)
  et se met à jour seule ; une alerte sonne à **chaque but** et à **chaque fin de match**. Bouton « Arrêter » dans la notification.
- **Widget** : appui long sur l'écran d'accueil › Widgets › LinkShare › Scores. Jusqu'à 6 matchs (en direct d'abord), heure de mise à jour,
  bouton ↻ ; toucher le widget ouvre l'écran Scores. Mise à jour toutes les 30 min, et à chaque rafraîchissement de la notification.
- Source : API publique ESPN (sans clé). Les derniers scores sont gardés en cache pour l'affichage hors ligne.
