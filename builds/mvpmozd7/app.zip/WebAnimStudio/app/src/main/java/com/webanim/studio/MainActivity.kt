package com.webanim.studio

import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.webkit.WebView
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts.OpenDocument
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Surface { Studio(this) } } }
    }
}

private fun ComponentActivity.readText(u: Uri) = contentResolver.openInputStream(u)!!.bufferedReader().use { it.readText() }
private fun ComponentActivity.durationOf(u: Uri): Double = MediaMetadataRetriever().run {
    setDataSource(this@durationOf, u)
    (extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toDouble() ?: 0.0) / 1000.0.also { release() }
}

@Composable
fun Studio(act: ComponentActivity) {
    val scope = rememberCoroutineScope()
    var html by remember { mutableStateOf(act.assets.open("samples/canvas.html").bufferedReader().readText()) }
    var audio by remember { mutableStateOf<Uri?>(null) }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    var audioDur by remember { mutableStateOf<Double?>(null) }
    var pageDur by remember { mutableDoubleStateOf(0.0) }
    val dur = audioDur ?: pageDur
    val segs = remember { mutableStateListOf<Segment>() }
    var portrait by remember { mutableStateOf(true) }
    var res by remember { mutableStateOf(Res.HD) }
    var wv by remember { mutableStateOf<WebView?>(null) }
    var pos by remember { mutableDoubleStateOf(0.0) }
    var playing by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var progress by remember { mutableFloatStateOf(-1f) }
    var toolUri by remember { mutableStateOf<Uri?>(null) }
    val cfg = ExportConfig(portrait, res)

    fun show(t: Double) { wv?.evaluateJavascript(Bridge.frame(TimeMap.anim(segs, t), TimeMap.subtitle(segs, t)), null) }

    val pickHtml = rememberLauncherForActivityResult(OpenDocument()) { u -> u?.let { html = act.readText(it); pos = 0.0; playing = false } }
    val pickAudio = rememberLauncherForActivityResult(OpenDocument()) { u ->
        u?.let { audio = it; audioDur = act.durationOf(it); player?.release(); player = MediaPlayer.create(act, it); segs.clear() }
    }
    val pickTool = rememberLauncherForActivityResult(OpenDocument()) { toolUri = it }

    LaunchedEffect(playing) {            // moteur de lecture : la voix off (ou l'horloge) pilote l'animation
        if (!playing) return@LaunchedEffect
        val p = player; val start = pos; val t0 = System.nanoTime()
        p?.apply { seekTo((start * 1000).toInt()); start() }
        try {
            while (isActive) {
                withFrameNanos { }
                val t = p?.let { it.currentPosition / 1000.0 } ?: (start + (System.nanoTime() - t0) / 1e9)
                if (t >= dur) { pos = dur; playing = false; break }
                pos = t; show(t)
            }
        } finally { p?.pause() }
    }

    fun launchJob(label: String, block: suspend () -> Unit) = scope.launch {
        try { status = "$label…"; block() } catch (e: Exception) { status = "Erreur : ${e.message}" }
        progress = -1f
    }
    fun tool(name: String, mime: String, ext: String, work: suspend (Uri, File) -> Unit) = toolUri?.let { u ->
        launchJob(name) {
            val f = File(act.cacheDir, "tool.$ext"); work(u, f)
            status = "Enregistré : " + MediaStoreSaver.save(act, f, mime, "${name}_${System.currentTimeMillis()}.$ext")
        }
    } ?: run { status = "Choisissez d'abord un fichier (section Outils)." }

    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp).statusBarsPadding(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("WebAnim Studio", style = MaterialTheme.typography.headlineSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ pickHtml.launch(arrayOf("text/html")) }) { Text("Animation HTML") }
            Button({ pickAudio.launch(arrayOf("audio/*", "video/mp4")) }) { Text("Voix off") }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("canvas", "svg", "css", "gsap", "three").forEach { n ->
                AssistChip({ html = act.assets.open("samples/$n.html").bufferedReader().readText(); pos = 0.0; playing = false }, { Text("Exemple $n") })
            }
        }
        key(html) {
            AndroidView(modifier = Modifier.fillMaxWidth(if (portrait) 0.6f else 1f).aspectRatio(cfg.width / cfg.height.toFloat()), factory = { c ->
                WebView(c).also { w -> Bridge.configure(w)
                    scope.launch {
                        Bridge.loadHtml(w, html)
                        pageDur = Bridge.eval(w, "window.__duration||0").trim('"').toDoubleOrNull() ?: 0.0
                        wv = w; show(0.0)
                    } }
            })
        }
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Button({ playing = !playing }) { Text(if (playing) "Pause" else "Lecture") }
            Slider(pos.toFloat(), { playing = false; pos = it.toDouble(); show(pos) }, Modifier.weight(1f).padding(start = 8.dp),
                valueRange = 0f..dur.toFloat().coerceAtLeast(0.1f))
        }
        Text("%.2f / %.2f s".format(pos, dur))

        Text("Format de sortie", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(portrait, { portrait = true }, { Text("Portrait 9:16") })
            FilterChip(!portrait, { portrait = false }, { Text("Paysage 16:9") })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Res.values().forEach { r -> FilterChip(res == r, { res = r }, { Text(r.label) }) }
        }

        Text("Découpage voix off / sous-titres", style = MaterialTheme.typography.titleMedium)
        Button({ audio?.let { u -> launchJob("Analyse audio") {
            segs.clear(); segs.addAll(kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) { AudioSplitter.split(act, u) })
            status = "${segs.size} blocs détectés" } } }, enabled = audio != null) { Text("Détecter les phrases (silences)") }
        segs.forEachIndexed { i, s ->
            OutlinedTextField(s.text, { segs[i] = s.copy(text = it) }, Modifier.fillMaxWidth(),
                label = { Text("%.1fs → %.1fs".format(s.start, s.end)) })
        }

        Button({ launchJob("Rendu vidéo (gardez l'app ouverte)") {
            val f = File(act.cacheDir, "render.mp4")
            WebViewRecorder(act).record(html, segs.toList(), audio, cfg, dur, f) { progress = it }
            status = "Exporté : " + MediaStoreSaver.save(act, f, "video/mp4", "anim_${System.currentTimeMillis()}.mp4")
        } }, Modifier.fillMaxWidth(), enabled = dur > 0 && progress < 0f) { Text("Exporter en MP4 (${cfg.width}×${cfg.height})") }
        if (progress >= 0f) LinearProgressIndicator({ progress }, Modifier.fillMaxWidth())

        HorizontalDivider()
        Text("Outils audio / vidéo", style = MaterialTheme.typography.titleMedium)
        Button({ pickTool.launch(arrayOf("video/*", "audio/*")) }) { Text(if (toolUri == null) "Choisir un fichier" else "Fichier choisi ✓") }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ tool("compress720", "video/mp4", "mp4") { u, f -> VideoCompressor.videoToVideo(act, u, f, 720, 2_000_000) } }) { Text("Compresser") }
            Button({ tool("upscale1080", "video/mp4", "mp4") { u, f -> VideoCompressor.videoToVideo(act, u, f, 1080, 8_000_000) } }) { Text("1080p+") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ tool("audio", "audio/mp4", "m4a") { u, f -> VideoCompressor.extractAudioM4a(act, u, f) } }) { Text("→ M4A") }
            Button({ tool("audio", "audio/wav", "wav") { u, f ->
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { AudioConverter.toWav(act, u, f) } } }) { Text("→ WAV") }
            Button({ tool("audio", "audio/mpeg", "mp3") { u, f -> Mp3Encoder.encode(act, u, f) } }) { Text("→ MP3") }
        }
        if (status.isNotEmpty()) Text(status)
    }
}
