# DL Vibe Projets

Application Android (Kotlin, Jetpack Compose) qui lit des projets web — pages HTML
avec leurs vidéos, images et scripts — et les présente en cartes avec aperçu.

## Ce que fait l'app

- **Tableau de bord en cartes** : une carte par projet, avec son aperçu, son titre
  (le `<title>` de la page), son type (ZIP / HTML), sa date et sa taille.
  Recherche et filtres ZIP / HTML.
- **Un projet = un sous-dossier** du dossier de l'app :
  `Android/data/com.dlvibe.projets/files/Projets/<nom du projet>/`
  (le chemin exact s'affiche avec le bouton ⓘ).
- **Import** de fichiers `.zip` (décompressés) ou `.html` (enregistrés en `index.html`)
  par le bouton « Importer », par « Ouvrir avec » ou « Partager » depuis une autre app
  (gestionnaire de fichiers, WhatsApp…). Un `.zip` ou `.html` déposé directement dans le
  dossier de l'app est rangé automatiquement à l'actualisation.
- **Lecteur** : la page s'ouvre en plein écran ; les chemins relatifs, la vidéo
  (avec avance rapide et plein écran), les polices et les scripts fonctionnent.
- **Aperçu des cartes**, dans cet ordre :
  1. une image du projet nommée `apercu`, `preview`, `poster`, `cover`, `vignette`… ;
  2. sinon une capture de la page faite à sa première ouverture ;
  3. sinon une image de la vidéo du projet, ou la plus grande image du dossier ;
  4. sinon les initiales du titre sur un dégradé.
- **Projet de démonstration** : la pub « L'élégance au féminin » (A&M Boutique by Mimi)
  est installée au premier lancement.

## Format d'un projet

```
Projets/
└── Pub A&M Boutique by Mimi/
    ├── index.html          ← page d'entrée (sinon la première page .html trouvée)
    ├── pub_ensemble_42s.mp4
    └── poster.jpg          ← aperçu de la carte
```

Un zip qui contient un seul dossier est remonté d'un niveau automatiquement.

## Compiler l'APK

**Avec Android Studio** (Koala ou plus récent) : *File › Open*, choisir ce dossier,
attendre la synchronisation Gradle, puis *Run ▶* sur un téléphone ou *Build › Build APK(s)*.

**Sans Android Studio** : publier ce dossier sur GitHub. L'action
`.github/workflows/apk.yml` compile l'APK à chaque envoi ; il se télécharge dans
l'onglet *Actions › Compiler l'APK › Artifacts*.

Configuration : Android 8.0 minimum (API 26), cible API 34, Gradle 8.7, AGP 8.5.2,
Kotlin 2.0.21, JDK 17.

## Code

| Fichier | Rôle |
| --- | --- |
| `ProjectRepository.kt` | dossier de l'app, lecture des projets, import zip/html, aperçus |
| `ProjectsViewModel.kt` | état du tableau de bord, import, suppression |
| `MainActivity.kt` | tableau de bord Compose (cartes, recherche, filtres, import) |
| `ViewerActivity.kt` | lecteur WebView, serveur de fichiers local avec requêtes « Range », capture d'aperçu |
| `ui/Thumbnail.kt` | chargement des aperçus et cartes sans image |
| `ui/Theme.kt` | palette DL Vibe (espresso, or, ivoire), clair et sombre |

---
Créé par DL VIBE STUDIO · Doubigue Loubikoa, vos idées prennent vie.
