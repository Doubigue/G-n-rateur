# Règles R8 (minification désactivée par défaut)
