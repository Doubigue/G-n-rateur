package com.dlvibe.projets

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.nio.charset.Charset
import java.util.Properties
import java.util.zip.ZipException
import java.util.zip.ZipFile

/**
 * Gère le dossier de l'app : chaque sous-dossier de « Projets » est un projet
 * contenant au moins une page HTML. Les .zip et .html importés ou déposés
 * dans ce dossier sont rangés chacun dans leur propre sous-dossier.
 */
class ProjectRepository(private val context: Context) {

    companion object {
        /** Aperçu capturé par l'app (caché par le point initial). */
        const val SNAPSHOT = ".apercu.jpg"
        private const val META = ".projet.properties"

        private val IMAGE_EXT = setOf("jpg", "jpeg", "png", "webp")
        private val VIDEO_EXT = setOf("mp4", "m4v", "webm", "mov", "3gp")
        private val HTML_EXT = setOf("html", "htm", "xhtml")
        private val PREVIEW_NAMES = setOf(
            "apercu", "aperçu", "preview", "poster", "thumbnail", "thumb",
            "cover", "couverture", "vignette", "miniature",
        )
        private val ZIP_MIMES = setOf(
            "application/zip", "application/x-zip-compressed", "application/x-zip", "multipart/x-zip",
        )

        /** Types proposés par le sélecteur de fichiers. */
        val PICKER_MIMES = arrayOf(
            "application/zip", "application/x-zip-compressed", "text/html",
            "application/xhtml+xml", "application/octet-stream",
        )

        private val TITLE_RE = Regex("<title[^>]*>(.*?)</title>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
        private val NUM_ENTITY = Regex("&#(x?)([0-9a-fA-F]+);")
    }

    /** Dossier de l'app : Android/data/com.dlvibe.projets/files/Projets */
    val root: File by lazy {
        File(context.getExternalFilesDir(null) ?: context.filesDir, "Projets").apply { mkdirs() }
    }

    // ---------------------------------------------------------------- lecture

    fun list(): List<Project> {
        root.mkdirs()
        importLooseFiles()
        return (root.listFiles() ?: emptyArray<File>())
            .filter { it.isDirectory && !it.name.startsWith(".") }
            .mapNotNull { runCatching { readProject(it) }.getOrNull() }
            .sortedByDescending { it.modified }
    }

    private fun readProject(dir: File): Project? {
        val entry = findEntry(dir) ?: return null
        val meta = readMeta(dir)
        val files = dir.walkTopDown().filter { it.isFile && !it.name.startsWith(".") }.toList()
        val source = when (meta.getProperty("source")) {
            "zip" -> ProjectSource.ZIP
            "html" -> ProjectSource.HTML
            else -> ProjectSource.DOSSIER
        }
        val modified = meta.getProperty("importe")?.toLongOrNull()
            ?: files.maxOfOrNull { it.lastModified() }
            ?: dir.lastModified()
        val title = readHtmlTitle(entry) ?: prettify(dir.name)

        var (preview, kind) = findPreview(dir, files)
        if (kind == PreviewKind.NONE) {
            // Projet vidéo sans image : on prend une image de la vidéo.
            val video = files.firstOrNull { it.extension.lowercase() in VIDEO_EXT }
            val out = File(dir, SNAPSHOT)
            if (video != null && extractVideoFrame(video, out)) {
                preview = out
                kind = PreviewKind.SNAPSHOT
            }
        }
        return Project(
            id = dir.name,
            title = title,
            dir = dir,
            entry = entry,
            source = source,
            sizeBytes = files.sumOf { it.length() },
            modified = modified,
            preview = preview,
            previewKind = kind,
        )
    }

    /** index.html à la racine, sinon la page HTML la moins profonde (3 niveaux max). */
    fun findEntry(dir: File): File? {
        listOf("index.html", "index.htm").map { File(dir, it) }.firstOrNull { it.isFile }?.let { return it }
        return dir.walkTopDown().maxDepth(3)
            .filter { it.isFile && it.extension.lowercase() in HTML_EXT && !it.name.startsWith(".") }
            .sortedWith(
                compareBy<File>(
                    { f -> f.relativeTo(dir).path.count { it == File.separatorChar } },
                    { f -> if (f.nameWithoutExtension.equals("index", ignoreCase = true)) 0 else 1 },
                    { f -> f.name.lowercase() },
                )
            )
            .firstOrNull()
    }

    private fun findPreview(dir: File, files: List<File>): Pair<File?, PreviewKind> {
        val images = files.filter { it.extension.lowercase() in IMAGE_EXT }
        images.firstOrNull { it.nameWithoutExtension.lowercase() in PREVIEW_NAMES }
            ?.let { return it to PreviewKind.NAMED }
        File(dir, SNAPSHOT).takeIf { it.isFile }?.let { return it to PreviewKind.SNAPSHOT }
        images.filter { it.length() in 10_000L..10_000_000L }.maxByOrNull { it.length() }
            ?.let { return it to PreviewKind.IMAGE }
        return null to PreviewKind.NONE
    }

    private fun readHtmlTitle(file: File): String? = runCatching {
        val buf = CharArray(32 * 1024)
        val n = file.reader(Charsets.UTF_8).use { it.read(buf) }
        if (n <= 0) return@runCatching null
        TITLE_RE.find(String(buf, 0, n))?.groupValues?.get(1)
            ?.let(::decodeEntities)
            ?.replace(Regex("\\s+"), " ")
            ?.trim()
            ?.takeIf { it.isNotEmpty() }
    }.getOrNull()

    private fun decodeEntities(s: String): String =
        NUM_ENTITY.replace(s) { m ->
            val code = m.groupValues[2].toIntOrNull(if (m.groupValues[1].isEmpty()) 10 else 16)
            if (code != null && code in 1..0x10FFFF) String(Character.toChars(code)) else m.value
        }
            .replace("&nbsp;", " ").replace("&lt;", "<").replace("&gt;", ">")
            .replace("&quot;", "\"").replace("&apos;", "'").replace("&amp;", "&")

    private fun prettify(name: String) = name.replace('_', ' ').replace('-', ' ').trim()

    // ---------------------------------------------------------------- import

    /** Importe un fichier choisi dans le sélecteur ou reçu par « Ouvrir avec ». */
    fun importUri(uri: Uri): Project {
        val name = displayName(uri) ?: uri.lastPathSegment?.substringAfterLast('/') ?: "projet"
        val mime = context.contentResolver.getType(uri)
        val tmp = File(context.cacheDir, "import-${System.nanoTime()}")
        try {
            val input = context.contentResolver.openInputStream(uri)
                ?: throw IOException("Impossible d'ouvrir « $name »")
            input.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
            return importFile(tmp, name, mime)
        } finally {
            tmp.delete()
        }
    }

    /** Range un .zip (décompressé) ou un .html (en index.html) dans un nouveau sous-dossier. */
    fun importFile(file: File, name: String, mime: String? = null): Project {
        val lower = name.lowercase()
        val kind = when {
            lower.endsWith(".zip") || (mime != null && mime in ZIP_MIMES) -> "zip"
            HTML_EXT.any { lower.endsWith(".$it") } || mime == "text/html" || mime == "application/xhtml+xml" -> "html"
            else -> sniff(file)
        } ?: throw IllegalArgumentException("« $name » n'est ni un fichier .zip ni une page .html")

        val base = name.substringBeforeLast('.').ifBlank { "projet" }
        val dir = uniqueDir(base)
        try {
            if (kind == "zip") extractZip(file, dir) else file.copyTo(File(dir, "index.html"), overwrite = true)
            if (findEntry(dir) == null) throw IllegalArgumentException("Le zip « $name » ne contient aucune page HTML")
            writeMeta(dir, kind, name)
            return readProject(dir) ?: throw IOException("Projet illisible")
        } catch (e: Exception) {
            dir.deleteRecursively()
            throw e
        }
    }

    /** Reconnaît un zip ou une page HTML à leur contenu quand le nom ne suffit pas. */
    private fun sniff(file: File): String? {
        val head = ByteArray(512)
        val n = file.inputStream().use { it.read(head) }
        if (n >= 4 && head[0] == 'P'.code.toByte() && head[1] == 'K'.code.toByte() && head[2] == 3.toByte() && head[3] == 4.toByte()) return "zip"
        if (n <= 0) return null
        val text = String(head, 0, n, Charsets.UTF_8).trimStart('﻿').trimStart().lowercase()
        return if (text.startsWith("<!doctype html") || text.contains("<html") || (text.startsWith("<") && text.contains("<body"))) "html" else null
    }

    private fun extractZip(file: File, dir: File) {
        val charsets = listOfNotNull(
            Charsets.UTF_8,
            runCatching { Charset.forName("IBM437") }.getOrNull(),   // zips créés sous Windows
            Charsets.ISO_8859_1,
        )
        var last: Exception? = null
        for (cs in charsets) {
            try {
                dir.listFiles()?.forEach { it.deleteRecursively() }
                unzip(file, dir, cs)
                unwrapSingleFolder(dir)
                return
            } catch (e: IllegalArgumentException) {
                last = e      // nom de fichier mal encodé : on essaie l'encodage suivant
            } catch (e: ZipException) {
                last = e
            }
        }
        throw IOException("Zip illisible : ${last?.message ?: "format inconnu"}")
    }

    private fun unzip(file: File, dir: File, cs: Charset) {
        val rootCanon = dir.canonicalPath
        val rootPrefix = rootCanon + File.separator
        ZipFile(file, cs).use { zip ->
            val entries = zip.entries()
            while (entries.hasMoreElements()) {
                val e = entries.nextElement()
                val n = e.name.replace('\\', '/')
                if (n.isBlank() || n.startsWith("__MACOSX/") || n.substringAfterLast('/') == ".DS_Store") continue
                val out = File(dir, n)
                val canon = out.canonicalPath
                if (canon == rootCanon) continue
                if (!canon.startsWith(rootPrefix)) throw IOException("Chemin interdit dans le zip : $n")
                if (e.isDirectory) {
                    out.mkdirs()
                    continue
                }
                out.parentFile?.mkdirs()
                zip.getInputStream(e).use { i -> out.outputStream().use { o -> i.copyTo(o) } }
            }
        }
    }

    /** Un zip qui contient un seul dossier : on remonte son contenu d'un niveau. */
    private fun unwrapSingleFolder(dir: File) {
        val kids = dir.listFiles()?.filter { it.name != META } ?: return
        if (kids.size != 1 || !kids[0].isDirectory) return
        val tmp = File(dir, ".deplacement-${System.nanoTime()}")
        if (!kids[0].renameTo(tmp)) return
        tmp.listFiles()?.forEach { it.renameTo(File(dir, it.name)) }
        tmp.deleteRecursively()
    }

    private fun uniqueDir(base: String): File {
        val clean = base.replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "_")
            .trim().trimStart('.').take(60).ifBlank { "projet" }
        var d = File(root, clean)
        var i = 2
        while (d.exists()) {
            d = File(root, "$clean ($i)")
            i++
        }
        d.mkdirs()
        return d
    }

    /** Fichiers .zip / .html déposés directement dans le dossier de l'app. */
    private fun importLooseFiles() {
        root.listFiles()
            ?.filter { it.isFile && !it.name.startsWith(".") }
            ?.forEach { f ->
                val ext = f.extension.lowercase()
                if (ext == "zip" || ext in HTML_EXT) {
                    runCatching { importFile(f, f.name) }.onSuccess { f.delete() }
                }
            }
    }

    private fun displayName(uri: Uri): String? = runCatching {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
    }.getOrNull()

    private fun readMeta(dir: File): Properties = Properties().apply {
        val f = File(dir, META)
        if (f.isFile) runCatching { f.inputStream().use { load(InputStreamReader(it, Charsets.UTF_8)) } }
    }

    private fun writeMeta(dir: File, source: String, original: String) {
        val p = Properties().apply {
            setProperty("source", source)
            setProperty("fichier", original)
            setProperty("importe", System.currentTimeMillis().toString())
        }
        File(dir, META).outputStream().use { p.store(OutputStreamWriter(it, Charsets.UTF_8), "DL Vibe Projets") }
    }

    // ---------------------------------------------------------------- gestion

    fun delete(project: Project): Boolean = project.dir.deleteRecursively()

    /** Oublie l'aperçu capturé : la page sera recapturée à sa prochaine ouverture. */
    fun resetPreview(project: Project) {
        File(project.dir, SNAPSHOT).delete()
    }

    fun saveSnapshot(dir: File, bitmap: Bitmap) = saveJpeg(bitmap, File(dir, SNAPSHOT))

    private fun saveJpeg(src: Bitmap, out: File, maxWidth: Int = 540) {
        val bmp = if (src.width > maxWidth) {
            val h = (src.height * maxWidth.toFloat() / src.width).toInt().coerceAtLeast(1)
            Bitmap.createScaledBitmap(src, maxWidth, h, true)
        } else src
        val tmp = File(out.parentFile, out.name + ".tmp")
        FileOutputStream(tmp).use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
        if (!tmp.renameTo(out)) {
            tmp.copyTo(out, overwrite = true)
            tmp.delete()
        }
        if (bmp !== src) bmp.recycle()
    }

    private fun extractVideoFrame(video: File, out: File): Boolean = runCatching {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(video.absolutePath)
            val bmp = r.getFrameAtTime(1_500_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: return@runCatching false
            saveJpeg(bmp, out)
            bmp.recycle()
            true
        } finally {
            r.release()
        }
    }.getOrDefault(false)

    // ---------------------------------------------------------------- démo

    /** Au tout premier lancement, installe la pub A&M Boutique comme projet d'exemple. */
    fun seedDemoIfNeeded() {
        val prefs = context.getSharedPreferences("projets", Context.MODE_PRIVATE)
        if (prefs.getBoolean("demo_installe", false)) return
        runCatching {
            val dir = File(root, "Pub A&M Boutique by Mimi")
            if (!dir.exists()) {
                copyAssetDir("demo/pub-am-boutique", dir)
                writeMeta(dir, "zip", "Pub_AM_Boutique_by_Mimi.zip")
            }
        }
        prefs.edit().putBoolean("demo_installe", true).apply()
    }

    private fun copyAssetDir(path: String, out: File) {
        val children = context.assets.list(path).orEmpty()
        if (children.isEmpty()) {
            out.parentFile?.mkdirs()
            context.assets.open(path).use { i -> out.outputStream().use { o -> i.copyTo(o) } }
        } else {
            out.mkdirs()
            children.forEach { copyAssetDir("$path/$it", File(out, it)) }
        }
    }
}
