package com.dlvibe.projets

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.webkit.MimeTypeMap
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.addCallback
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FilterInputStream
import java.io.InputStream

/**
 * Affiche la page HTML d'un projet. Les fichiers du dossier sont servis sous
 * https://appassets.androidplatform.net/ : chemins relatifs, vidéos (avec avance
 * rapide), polices et scripts fonctionnent comme sur un vrai site.
 */
class ViewerActivity : ComponentActivity() {

    companion object {
        const val EXTRA_DIR = "dir"
        const val EXTRA_ENTRY = "entry"
        const val EXTRA_CAPTURE = "capture"
        const val HOST = "appassets.androidplatform.net"
    }

    private lateinit var root: FrameLayout
    private lateinit var web: WebView
    private lateinit var progress: ProgressBar
    private lateinit var chrome: WebChromeClient
    private var fullscreenView: View? = null
    private var fullscreenCallback: WebChromeClient.CustomViewCallback? = null
    private var captured = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dirPath = intent.getStringExtra(EXTRA_DIR)
        if (dirPath == null) {
            finish()
            return
        }
        val dir = File(dirPath)
        val entry = intent.getStringExtra(EXTRA_ENTRY) ?: "index.html"
        val capture = intent.getBooleanExtra(EXTRA_CAPTURE, false)
        val files = LocalFiles(dir)

        root = FrameLayout(this)
        web = WebView(this)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        root.addView(web, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        root.addView(progress, FrameLayout.LayoutParams(MATCH_PARENT, dp(3), Gravity.TOP))
        setContentView(root)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            useWideViewPort = true
            loadWithOverviewMode = true
            builtInZoomControls = true
            displayZoomControls = false
            setSupportZoom(true)
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val url = request.url
                return if (url.host == HOST) files.serve(url.path ?: "/", request.requestHeaders) else null
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url
                if (url.host == HOST) return false
                // Liens externes (site, WhatsApp, téléphone, e-mail) : ouverts par l'app qui convient.
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, url))
                } catch (e: ActivityNotFoundException) {
                    Toast.makeText(this@ViewerActivity, "Aucune app pour ouvrir ce lien", Toast.LENGTH_SHORT).show()
                }
                return true
            }

            override fun onPageFinished(view: WebView, url: String) {
                progress.visibility = View.GONE
                if (capture && !captured) {
                    captured = true
                    view.postDelayed({ captureSnapshot(dir) }, 2200)
                }
            }
        }

        chrome = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress < 100) View.VISIBLE else View.GONE
            }

            override fun onShowCustomView(view: View, callback: WebChromeClient.CustomViewCallback) {
                if (fullscreenView != null) {
                    callback.onCustomViewHidden()
                    return
                }
                fullscreenView = view
                fullscreenCallback = callback
                root.addView(view, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
                web.visibility = View.GONE
                insets().apply {
                    hide(WindowInsetsCompat.Type.systemBars())
                    systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                }
            }

            override fun onHideCustomView() {
                fullscreenView?.let { root.removeView(it) }
                fullscreenView = null
                web.visibility = View.VISIBLE
                fullscreenCallback?.onCustomViewHidden()
                fullscreenCallback = null
                insets().show(WindowInsetsCompat.Type.systemBars())
            }
        }
        web.webChromeClient = chrome
        web.setBackgroundColor(Color.TRANSPARENT)

        onBackPressedDispatcher.addCallback(this) {
            when {
                fullscreenView != null -> chrome.onHideCustomView()
                web.canGoBack() -> web.goBack()
                else -> finish()
            }
        }

        val start = Uri.Builder().scheme("https").authority(HOST)
            .apply { entry.split('/').filter { it.isNotEmpty() }.forEach { appendPath(it) } }
            .build()
        web.loadUrl(start.toString())
    }

    private fun insets() = WindowCompat.getInsetsController(window, window.decorView)

    /** Capture la page affichée et l'enregistre comme aperçu de la carte. */
    private fun captureSnapshot(dir: File) {
        if (isFinishing || web.width == 0 || web.height == 0) return
        val scale = 540f / web.width
        val bmp = runCatching {
            Bitmap.createBitmap((web.width * scale).toInt(), (web.height * scale).toInt(), Bitmap.Config.ARGB_8888)
        }.getOrNull() ?: return
        val canvas = Canvas(bmp)
        canvas.drawColor(Color.BLACK)
        canvas.scale(scale, scale)
        web.draw(canvas)
        lifecycleScope.launch(Dispatchers.IO) {
            runCatching { ProjectRepository(applicationContext).saveSnapshot(dir, bmp) }
            bmp.recycle()
        }
    }

    override fun onPause() {
        if (::web.isInitialized) web.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) web.onResume()
    }

    override fun onDestroy() {
        if (::web.isInitialized) {
            web.stopLoading()
            web.destroy()
        }
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}

/** Sert les fichiers d'un dossier de projet, avec prise en charge des requêtes « Range » (vidéo). */
private class LocalFiles(dir: File) {
    private val root = dir.canonicalFile
    private val rootPrefix = root.path + File.separator

    private val types = mapOf(
        "html" to "text/html", "htm" to "text/html", "xhtml" to "application/xhtml+xml",
        "css" to "text/css", "js" to "text/javascript", "mjs" to "text/javascript",
        "json" to "application/json", "map" to "application/json", "txt" to "text/plain", "md" to "text/markdown",
        "csv" to "text/csv", "xml" to "application/xml", "svg" to "image/svg+xml",
        "png" to "image/png", "jpg" to "image/jpeg", "jpeg" to "image/jpeg", "gif" to "image/gif",
        "webp" to "image/webp", "avif" to "image/avif", "ico" to "image/x-icon",
        "mp4" to "video/mp4", "m4v" to "video/mp4", "webm" to "video/webm", "mov" to "video/quicktime",
        "mp3" to "audio/mpeg", "m4a" to "audio/mp4", "wav" to "audio/wav", "ogg" to "audio/ogg",
        "woff" to "font/woff", "woff2" to "font/woff2", "ttf" to "font/ttf", "otf" to "font/otf",
        "wasm" to "application/wasm", "pdf" to "application/pdf",
    )

    fun serve(path: String, headers: Map<String, String>): WebResourceResponse {
        val rel = path.trimStart('/')
        var file = if (rel.isEmpty()) root else File(root, rel).canonicalFile
        if (file != root && !file.path.startsWith(rootPrefix)) return error(403, "Forbidden")
        if (file.isDirectory) file = File(file, "index.html")
        if (!file.isFile) return error(404, "Not Found")

        val mime = mimeOf(file)
        val charset = if (mime.startsWith("text/") || mime.endsWith("json") || mime.endsWith("xml") || mime.endsWith("javascript")) "utf-8" else null
        val length = file.length()
        val base = mutableMapOf(
            "Accept-Ranges" to "bytes",
            "Cache-Control" to "no-cache",
            "Access-Control-Allow-Origin" to "*",
        )

        val range = headers.entries.firstOrNull { it.key.equals("Range", ignoreCase = true) }?.value
        val m = range?.let { Regex("bytes=(\\d*)-(\\d*)").find(it) }
        if (m != null) {
            var start = m.groupValues[1].toLongOrNull()
            var end = m.groupValues[2].toLongOrNull()
            if (start == null && end != null) {           // « bytes=-500 » : les 500 derniers octets
                start = (length - end).coerceAtLeast(0)
                end = length - 1
            }
            val s = start ?: 0L
            val e = (end ?: (length - 1)).coerceAtMost(length - 1)
            if (s > e || s >= length) {
                base["Content-Range"] = "bytes */$length"
                return WebResourceResponse(mime, null, 416, "Range Not Satisfiable", base, ByteArrayInputStream(ByteArray(0)))
            }
            val input = FileInputStream(file).also { it.channel.position(s) }
            base["Content-Range"] = "bytes $s-$e/$length"
            base["Content-Length"] = (e - s + 1).toString()
            return WebResourceResponse(mime, charset, 206, "Partial Content", base, Limited(input, e - s + 1))
        }

        base["Content-Length"] = length.toString()
        return WebResourceResponse(mime, charset, 200, "OK", base, FileInputStream(file))
    }

    private fun mimeOf(file: File): String {
        val ext = file.extension.lowercase()
        return types[ext] ?: MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    private fun error(code: Int, reason: String) =
        WebResourceResponse("text/plain", "utf-8", code, reason, mapOf("Cache-Control" to "no-cache"), ByteArrayInputStream(reason.toByteArray()))
}

/** Flux limité à un nombre d'octets (réponse partielle). */
private class Limited(input: InputStream, private var remaining: Long) : FilterInputStream(input) {
    override fun read(): Int {
        if (remaining <= 0) return -1
        val b = super.read()
        if (b >= 0) remaining--
        return b
    }

    override fun read(b: ByteArray, off: Int, len: Int): Int {
        if (remaining <= 0) return -1
        val n = super.read(b, off, minOf(len.toLong(), remaining).toInt())
        if (n > 0) remaining -= n
        return n
    }

    override fun available(): Int = minOf(super.available().toLong(), remaining).toInt()
}
