package com.dlvibe.projets.ui

import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Petites images déjà décodées, pour que la grille défile sans saccade. */
private object ThumbCache {
    private val cache = LruCache<String, ImageBitmap>(48)

    fun get(key: String): ImageBitmap? = cache.get(key)

    fun load(file: File, key: String, targetWidth: Int = 480): ImageBitmap? {
        cache.get(key)?.let { return it }
        return runCatching {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= targetWidth) sample *= 2
            val bmp = BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
            bmp?.asImageBitmap()?.also { cache.put(key, it) }
        }.getOrNull()
    }
}

@Composable
fun Thumbnail(file: File?, title: String, modifier: Modifier = Modifier) {
    val key = file?.let { it.absolutePath + ":" + it.lastModified() }
    val bitmap by produceState(initialValue = key?.let { ThumbCache.get(it) }, key) {
        value = if (file == null || key == null) null else withContext(Dispatchers.IO) { ThumbCache.load(file, key) }
    }
    val bmp = bitmap
    if (bmp != null) {
        Image(
            bitmap = bmp,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            alignment = Alignment.TopCenter,
            modifier = modifier,
        )
    } else {
        Placeholder(title, modifier)
    }
}

private val PALETTES = listOf(
    Color(0xFF3A2618) to Color(0xFF8A6420),
    Color(0xFF1F2A24) to Color(0xFF5C7A5A),
    Color(0xFF2A1B2E) to Color(0xFF8A4F7D),
    Color(0xFF1C2433) to Color(0xFF4F6E9A),
    Color(0xFF331C1C) to Color(0xFF9A4F3F),
)

/** Carte sans image : dégradé et initiales du titre. */
@Composable
private fun Placeholder(title: String, modifier: Modifier) {
    val (a, b) = PALETTES[(title.hashCode() and 0x7fffffff) % PALETTES.size]
    Box(modifier.background(Brush.linearGradient(listOf(a, b))), contentAlignment = Alignment.Center) {
        Text(
            text = initials(title),
            style = MaterialTheme.typography.displaySmall.copy(fontFamily = FontFamily.Serif),
            color = Color(0xFFF2E4C4),
        )
    }
}

fun initials(title: String): String =
    title.split(Regex("[\\s_\\-]+"))
        .filter { it.isNotEmpty() && it[0].isLetterOrDigit() }
        .take(2)
        .joinToString("") { it.take(1).uppercase() }
        .ifEmpty { "?" }
