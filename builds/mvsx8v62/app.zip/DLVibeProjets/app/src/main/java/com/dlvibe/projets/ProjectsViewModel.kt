package com.dlvibe.projets

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class UiState(
    val projects: List<Project> = emptyList(),
    val loading: Boolean = true,
    val importing: Boolean = false,
)

class ProjectsViewModel(app: Application) : AndroidViewModel(app) {

    val repo = ProjectRepository(app)

    private val _state = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _state.asStateFlow()

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 4)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    /** Projet à ouvrir tout de suite (fichier reçu par « Ouvrir avec »). */
    private val _open = MutableSharedFlow<Project>(extraBufferCapacity = 1)
    val openEvents: SharedFlow<Project> = _open.asSharedFlow()

    init {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { repo.seedDemoIfNeeded() }
            refresh()
        }
    }

    fun refresh() {
        viewModelScope.launch {
            _state.update { it.copy(loading = true) }
            val list = withContext(Dispatchers.IO) { repo.list() }
            _state.update { it.copy(loading = false, projects = list) }
        }
    }

    fun import(uris: List<Uri>, openAfter: Boolean = false) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            _state.update { it.copy(importing = true) }
            val results = withContext(Dispatchers.IO) { uris.map { u -> runCatching { repo.importUri(u) } } }
            _state.update { it.copy(importing = false) }
            val ok = results.mapNotNull { it.getOrNull() }
            val errors = results.mapNotNull { it.exceptionOrNull() }
            when {
                ok.size == 1 -> _messages.tryEmit("« ${ok[0].title} » importé")
                ok.size > 1 -> _messages.tryEmit("${ok.size} projets importés")
            }
            errors.firstOrNull()?.let { e ->
                val more = if (errors.size > 1) " (+${errors.size - 1} autre(s) échec(s))" else ""
                _messages.tryEmit((e.message ?: "Import impossible") + more)
            }
            refresh()
            if (openAfter && ok.size == 1) _open.tryEmit(ok[0])
        }
    }

    fun delete(project: Project) {
        viewModelScope.launch {
            val done = withContext(Dispatchers.IO) { repo.delete(project) }
            _messages.tryEmit(if (done) "« ${project.title} » supprimé" else "Suppression impossible")
            refresh()
        }
    }

    fun resetPreview(project: Project) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { repo.resetPreview(project) }
            _messages.tryEmit("L'aperçu sera recapturé à la prochaine ouverture")
            refresh()
        }
    }
}
