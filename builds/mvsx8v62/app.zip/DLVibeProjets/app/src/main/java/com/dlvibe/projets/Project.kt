package com.dlvibe.projets

import java.io.File

/** Origine d'un projet : importé depuis un .zip, depuis une page .html, ou dossier déposé à la main. */
enum class ProjectSource(val label: String) {
    ZIP("ZIP"),
    HTML("HTML"),
    DOSSIER("DOSSIER"),
}

/** D'où vient l'image de la carte. */
enum class PreviewKind {
    /** Image nommée apercu / preview / poster… fournie avec le projet. */
    NAMED,
    /** Capture de la page (ou image de la vidéo) faite par l'app. */
    SNAPSHOT,
    /** Plus grande image trouvée dans le dossier, faute de mieux. */
    IMAGE,
    /** Aucune image : la carte affiche les initiales. */
    NONE,
}

data class Project(
    /** Nom du sous-dossier dans le dossier de l'app. */
    val id: String,
    /** Titre affiché : <title> de la page, sinon nom du dossier. */
    val title: String,
    val dir: File,
    /** Page HTML d'entrée (index.html de préférence). */
    val entry: File,
    val source: ProjectSource,
    val sizeBytes: Long,
    val modified: Long,
    val preview: File?,
    val previewKind: PreviewKind,
) {
    /** Chemin de la page d'entrée relatif au dossier du projet, avec des « / ». */
    val entryRelative: String get() = entry.relativeTo(dir).invariantSeparatorsPath

    /** Vrai quand l'app doit capturer la page à la première ouverture pour faire l'aperçu. */
    val needsSnapshot: Boolean get() = previewKind == PreviewKind.NONE || previewKind == PreviewKind.IMAGE
}
