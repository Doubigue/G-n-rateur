package com.dlvibe.projets.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight

/** Palette DL Vibe : brun espresso, or et ivoire. */
private val Light = lightColorScheme(
    primary = Color(0xFF8A6420),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFF1E2C2),
    onPrimaryContainer = Color(0xFF2B1E08),
    secondary = Color(0xFF6E5F53),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFEDE3D3),
    onSecondaryContainer = Color(0xFF241A14),
    background = Color(0xFFF6F1E8),
    onBackground = Color(0xFF241A14),
    surface = Color(0xFFFFFDF8),
    onSurface = Color(0xFF241A14),
    surfaceVariant = Color(0xFFEDE3D3),
    onSurfaceVariant = Color(0xFF6E5F53),
    outline = Color(0xFFD3C3AC),
    outlineVariant = Color(0xFFE6DACA),
)

private val Dark = darkColorScheme(
    primary = Color(0xFFD8B46A),
    onPrimary = Color(0xFF2A1D0C),
    primaryContainer = Color(0xFF4A3818),
    onPrimaryContainer = Color(0xFFF4DFB4),
    secondary = Color(0xFFB3A291),
    onSecondary = Color(0xFF241A14),
    secondaryContainer = Color(0xFF3A2D23),
    onSecondaryContainer = Color(0xFFF2E9DC),
    background = Color(0xFF17110D),
    onBackground = Color(0xFFF2E9DC),
    surface = Color(0xFF211913),
    onSurface = Color(0xFFF2E9DC),
    surfaceVariant = Color(0xFF2E241C),
    onSurfaceVariant = Color(0xFFB3A291),
    outline = Color(0xFF4A3B2F),
    outlineVariant = Color(0xFF3A2D23),
)

private val Base = Typography()
private val AppTypography = Base.copy(
    headlineMedium = Base.headlineMedium.copy(fontFamily = FontFamily.Serif),
    headlineSmall = Base.headlineSmall.copy(fontFamily = FontFamily.Serif),
    titleLarge = Base.titleLarge.copy(fontFamily = FontFamily.Serif),
    titleMedium = Base.titleMedium.copy(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Medium),
)

@Composable
fun ProjetsTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) Dark else Light, typography = AppTypography, content = content)
}
