# Signature dédiée Media Studio

Le projet contient la clé privée Android :
`keystore/mediastudio-release.jks`

- Type : JKS
- Alias : `mediastudio-release`
- Algorithme : RSA 3072 bits
- Signature : SHA256withRSA

## Variables à définir avant une compilation Release

Définir les variables d'environnement suivantes dans l'environnement utilisé
par Gradle / Android Studio :

- `MEDIA_STUDIO_STORE_PASSWORD` : mot de passe du keystore
- `MEDIA_STUDIO_KEY_PASSWORD` : mot de passe de la clé (identique au mot de
  passe du keystore si vous avez conservé la configuration initiale)

La configuration de signature est dans `app/build.gradle.kts`.
Les builds Debug restent utilisables sans ces variables ; un build Release
doit recevoir les bons mots de passe.

## Sécurité et mises à jour

Cette clé est privée : ne la publiez pas et ne la transmettez pas avec des
versions publiques du projet. Conservez une copie de sauvegarde hors ligne.
Toutes les futures mises à jour de Media Studio doivent être signées avec
exactement cette même clé pour permettre la mise à jour de l'application
installée. Ne régénérez pas la clé.

Empreinte SHA-256 du certificat :
`59:49:EE:6B:A1:5A:F0:82:50:01:A2:73:5A:C6:0A:80:D9:79:E5:93:4B:1E:DF:6E:05:E5:44:84:6B:29:CC:F3`
