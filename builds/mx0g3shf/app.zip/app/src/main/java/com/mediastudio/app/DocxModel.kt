package com.mediastudio.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.StaticLayout
import android.text.TextPaint
import android.text.style.LeadingMarginSpan
import android.text.style.LineHeightSpan
import android.text.style.MetricAffectingSpan
import android.text.style.ReplacementSpan
import android.text.style.TabStopSpan
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.InputStream
import java.util.zip.ZipFile
import kotlin.math.roundToInt

// ───────────────────────────── XML léger ─────────────────────────────

internal class XNode(val name: String) {
    val attrs = HashMap<String, String>(4)
    val kids = ArrayList<XNode>()
    val text = StringBuilder()
    fun a(n: String): String? = attrs[n]
    fun v(): String? = attrs["w:val"]
    fun c(n: String): XNode? { for (k in kids) if (k.name == n) return k; return null }
    fun all(n: String): List<XNode> = kids.filter { it.name == n }
    fun find(n: String): XNode? { for (k in kids) { if (k.name == n) return k; k.find(n)?.let { return it } }; return null }
}

internal object XmlTree {
    fun parse(input: InputStream): XNode {
        val p = Xml.newPullParser()
        p.setInput(input, "UTF-8")
        val root = XNode("#root")
        val stack = ArrayList<XNode>()
        stack.add(root)
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            when (ev) {
                XmlPullParser.START_TAG -> {
                    val n = XNode(p.name)
                    for (i in 0 until p.attributeCount) n.attrs[p.getAttributeName(i)] = p.getAttributeValue(i)
                    stack.last().kids.add(n)
                    stack.add(n)
                }
                XmlPullParser.TEXT -> stack.last().text.append(p.text)
                XmlPullParser.END_TAG -> if (stack.size > 1) stack.removeAt(stack.lastIndex)
            }
            ev = p.next()
        }
        return root.kids.firstOrNull() ?: root
    }
}

// ───────────────────────────── Propriétés ─────────────────────────────

internal fun colorOf(s: String?): Int? {
    if (s == null || s.equals("auto", true)) return null
    return s.toIntOrNull(16)?.let { 0xFF000000.toInt() or it }
}

private val HIGHLIGHT = mapOf(
    "yellow" to 0xFFFF00, "green" to 0x00FF00, "cyan" to 0x00FFFF, "magenta" to 0xFF00FF, "blue" to 0x0000FF,
    "red" to 0xFF0000, "darkBlue" to 0x000080, "darkCyan" to 0x008080, "darkGreen" to 0x008000,
    "darkMagenta" to 0x800080, "darkRed" to 0x800000, "darkYellow" to 0x808000, "darkGray" to 0x808080,
    "lightGray" to 0xC0C0C0, "black" to 0x000000, "white" to 0xFFFFFF,
)

internal class RP {
    var font: String? = null; var size: Float? = null; var bold: Boolean? = null; var italic: Boolean? = null
    var underline: Boolean? = null; var strike: Boolean? = null; var color: Int? = null; var bg: Int? = null
    var caps: Boolean? = null; var vert: Int? = null; var vanish: Boolean? = null

    fun over(o: RP) {
        o.font?.let { font = it }; o.size?.let { size = it }; o.bold?.let { bold = it }; o.italic?.let { italic = it }
        o.underline?.let { underline = it }; o.strike?.let { strike = it }; o.color?.let { color = it }; o.bg?.let { bg = it }
        o.caps?.let { caps = it }; o.vert?.let { vert = it }; o.vanish?.let { vanish = it }
    }
    fun copy(): RP = RP().also { it.over(this) }
}

internal class PP {
    var align: String? = null; var before: Float? = null; var after: Float? = null
    var line: Float? = null; var lineRule: String? = null
    var left: Float? = null; var right: Float? = null; var first: Float? = null; var hanging: Float? = null
    var shd: Int? = null; var numId: Int? = null; var ilvl: Int? = null
    var pageBreakBefore: Boolean? = null; var keepNext: Boolean? = null; var contextual: Boolean? = null
    var tabs: List<Float>? = null

    fun over(o: PP) {
        o.align?.let { align = it }; o.before?.let { before = it }; o.after?.let { after = it }
        o.line?.let { line = it }; o.lineRule?.let { lineRule = it }
        o.left?.let { left = it }; o.right?.let { right = it }
        if (o.first != null || o.hanging != null) { first = o.first; hanging = o.hanging }
        o.shd?.let { shd = it }; o.numId?.let { numId = it }; o.ilvl?.let { ilvl = it }
        o.pageBreakBefore?.let { pageBreakBefore = it }; o.keepNext?.let { keepNext = it }
        o.contextual?.let { contextual = it }; o.tabs?.let { tabs = it }
    }
    fun copy(): PP = PP().also { it.over(this) }
}

private fun on(k: XNode): Boolean = k.v().let { it == null || (it != "0" && it != "false" && it != "off" && it != "none") }
private fun tw(s: String?): Float? = s?.toFloatOrNull()?.div(20f)

internal fun parseRP(n: XNode?, theme: Map<String, String>): RP {
    val r = RP()
    if (n == null) return r
    for (k in n.kids) when (k.name) {
        "w:rFonts" -> {
            val th = k.a("w:asciiTheme") ?: k.a("w:hAnsiTheme")
            r.font = k.a("w:ascii") ?: k.a("w:hAnsi") ?: k.a("w:cs") ?: k.a("w:eastAsia")
                ?: th?.let { if (it.startsWith("major")) theme["major"] else theme["minor"] }
        }
        "w:sz" -> r.size = k.v()?.toFloatOrNull()?.div(2f)
        "w:b" -> r.bold = on(k)
        "w:i" -> r.italic = on(k)
        "w:u" -> r.underline = k.v() != "none"
        "w:strike", "w:dstrike" -> r.strike = on(k)
        "w:color" -> r.color = colorOf(k.v()) ?: Color.BLACK
        "w:highlight" -> HIGHLIGHT[k.v()]?.let { r.bg = 0xFF000000.toInt() or it }
        "w:shd" -> colorOf(k.a("w:fill"))?.let { r.bg = it }
        "w:caps", "w:smallCaps" -> r.caps = on(k)
        "w:vertAlign" -> r.vert = when (k.v()) { "superscript" -> 1; "subscript" -> -1; else -> 0 }
        "w:vanish" -> r.vanish = on(k)
    }
    return r
}

internal fun parsePP(n: XNode?): PP {
    val p = PP()
    if (n == null) return p
    for (k in n.kids) when (k.name) {
        "w:jc" -> p.align = k.v()
        "w:spacing" -> {
            tw(k.a("w:before"))?.let { p.before = it }
            tw(k.a("w:after"))?.let { p.after = it }
            k.a("w:line")?.toFloatOrNull()?.let { l ->
                p.lineRule = k.a("w:lineRule") ?: "auto"
                p.line = if (p.lineRule == "auto") l / 240f else l / 20f
            }
        }
        "w:ind" -> {
            tw(k.a("w:left") ?: k.a("w:start"))?.let { p.left = it }
            tw(k.a("w:right") ?: k.a("w:end"))?.let { p.right = it }
            p.first = tw(k.a("w:firstLine")); p.hanging = tw(k.a("w:hanging"))
        }
        "w:shd" -> colorOf(k.a("w:fill"))?.let { p.shd = it }
        "w:numPr" -> {
            p.numId = k.c("w:numId")?.v()?.toIntOrNull()
            p.ilvl = k.c("w:ilvl")?.v()?.toIntOrNull()
        }
        "w:pageBreakBefore" -> p.pageBreakBefore = on(k)
        "w:keepNext" -> p.keepNext = on(k)
        "w:contextualSpacing" -> p.contextual = on(k)
        "w:tabs" -> p.tabs = k.all("w:tab").filter { it.v() != "clear" }.mapNotNull { tw(it.a("w:pos")) }
    }
    return p
}

// ───────────────────────────── Styles, thème, numérotation ─────────────────────────────

internal class St(val id: String, val type: String?, val basedOn: String?, val pp: PP, val rp: RP, val tblBorders: XNode?, val isDefault: Boolean)

internal class Styles(root: XNode?, val theme: Map<String, String>) {
    private val map = HashMap<String, St>()
    private val defP = PP()
    private val defR = RP()
    private var defaultPara: String? = null

    init {
        root?.c("w:docDefaults")?.let { d ->
            d.c("w:rPrDefault")?.c("w:rPr")?.let { defR.over(parseRP(it, theme)) }
            d.c("w:pPrDefault")?.c("w:pPr")?.let { defP.over(parsePP(it)) }
        }
        root?.all("w:style")?.forEach { s ->
            val id = s.a("w:styleId") ?: return@forEach
            val st = St(
                id, s.a("w:type"), s.c("w:basedOn")?.v(), parsePP(s.c("w:pPr")), parseRP(s.c("w:rPr"), theme),
                s.c("w:tblPr")?.c("w:tblBorders"), s.a("w:default") == "1",
            )
            map[id] = st
            if (st.type == "paragraph" && st.isDefault) defaultPara = id
        }
        if (defR.size == null) defR.size = 10f
    }

    private fun chain(id: String?): List<St> {
        val out = ArrayList<St>()
        var cur = id
        var guard = 0
        while (cur != null && guard++ < 20) { val s = map[cur] ?: break; out.add(0, s); cur = s.basedOn }
        return out
    }

    fun forPara(id: String?): Pair<PP, RP> {
        val pp = defP.copy(); val rp = defR.copy()
        for (s in chain(id ?: defaultPara)) { pp.over(s.pp); rp.over(s.rp) }
        return pp to rp
    }

    fun charStyle(id: String?): RP? = if (id == null) null else RP().also { r -> for (s in chain(id)) r.over(s.rp) }

    fun tableBorders(id: String?): XNode? { for (s in chain(id).reversed()) s.tblBorders?.let { return it }; return null }
}

internal class Lvl(val fmt: String, val text: String, val start: Int, val pp: PP, val rp: RP)

internal class Numbering(root: XNode?, theme: Map<String, String>) {
    private val abs = HashMap<Int, Map<Int, Lvl>>()
    private val nums = HashMap<Int, Int>()
    private val counters = HashMap<Int, IntArray>()

    init {
        root?.all("w:abstractNum")?.forEach { a ->
            val id = a.a("w:abstractNumId")?.toIntOrNull() ?: return@forEach
            val lv = HashMap<Int, Lvl>()
            a.all("w:lvl").forEach { l ->
                val i = l.a("w:ilvl")?.toIntOrNull() ?: return@forEach
                lv[i] = Lvl(
                    l.c("w:numFmt")?.v() ?: "decimal", l.c("w:lvlText")?.v() ?: "", l.c("w:start")?.v()?.toIntOrNull() ?: 1,
                    parsePP(l.c("w:pPr")), parseRP(l.c("w:rPr"), theme),
                )
            }
            abs[id] = lv
        }
        root?.all("w:num")?.forEach { n ->
            val id = n.a("w:numId")?.toIntOrNull() ?: return@forEach
            n.c("w:abstractNumId")?.v()?.toIntOrNull()?.let { nums[id] = it }
        }
    }

    fun level(numId: Int, ilvl: Int): Lvl? = nums[numId]?.let { abs[it]?.get(ilvl) }

    fun label(numId: Int, ilvl: Int): String? {
        val absId = nums[numId] ?: return null
        val levels = abs[absId] ?: return null
        val lv = levels[ilvl] ?: return null
        val c = counters.getOrPut(absId) { IntArray(9) }
        val i = ilvl.coerceIn(0, 8)
        if (c[i] == 0) c[i] = lv.start else c[i]++
        for (j in i + 1 until 9) c[j] = 0
        if (lv.fmt == "bullet") return bullet(lv.text)
        if (lv.fmt == "none") return ""
        var s = lv.text
        for (j in 0..8) {
            val l = levels[j]
            s = s.replace("%${j + 1}", fmt(l?.fmt ?: "decimal", if (c[j] == 0) (l?.start ?: 1) else c[j]))
        }
        return s
    }

    private fun bullet(t: String): String {
        if (t.isEmpty()) return "•"
        val ch = t[0]
        return when {
            ch.code >= 0xF000 -> "•"
            ch == 'o' -> "◦"
            else -> t
        }
    }

    private fun fmt(f: String, n: Int): String = when (f) {
        "lowerLetter" -> letters(n).lowercase()
        "upperLetter" -> letters(n)
        "lowerRoman" -> roman(n).lowercase()
        "upperRoman" -> roman(n)
        "decimalZero" -> n.toString().padStart(2, '0')
        else -> n.toString()
    }
    private fun letters(n: Int): String {
        val sb = StringBuilder(); var x = n
        while (x > 0) { x--; sb.insert(0, 'A' + x % 26); x /= 26 }
        return sb.toString()
    }
    private fun roman(n: Int): String {
        val v = intArrayOf(1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1)
        val s = arrayOf("M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I")
        val sb = StringBuilder(); var x = n
        for (i in v.indices) while (x >= v[i]) { sb.append(s[i]); x -= v[i] }
        return sb.toString()
    }
}

// ───────────────────────────── Modèle de page ─────────────────────────────

internal class Geo(
    val w: Float, val h: Float, val top: Float, val right: Float, val bottom: Float, val left: Float,
    val header: Float, val footer: Float, val continuous: Boolean = false, val titlePg: Boolean = false,
    val hdrDefault: String? = null, val hdrFirst: String? = null, val ftrDefault: String? = null, val ftrFirst: String? = null,
) {
    companion object { val A4 = Geo(595f, 842f, 56f, 56f, 56f, 56f, 35f, 35f) }
}

internal class DxBorder(val w: Float, val color: Int)
internal class DxBorders(val top: DxBorder?, val left: DxBorder?, val bottom: DxBorder?, val right: DxBorder?)

internal class FloatItem(
    val bmp: Bitmap?, val box: List<WB.Para>?, val w: Float, val h: Float, val x: Float, val y: Float,
    val relH: String, val relV: String, val alignH: String?, val alignV: String?, val behind: Boolean,
    val insL: Float, val insT: Float,
)

internal class DxCell(
    val blocks: List<WB>, val x: Float, val w: Float, val fill: Int?, val borders: DxBorders,
    val vmCont: Boolean, var vmSpan: Int = 1,
)
internal class DxRow(val cells: List<DxCell>, val minH: Float, val exact: Boolean)

internal sealed interface WB {
    class Para(
        val text: SpannableStringBuilder, val align: Layout.Alignment, val justify: Boolean,
        val before: Float, val after: Float, val mult: Float, val left: Float, val right: Float, val first: Float,
        val label: String?, val labelTf: Typeface, val labelSize: Float, val labelColor: Int,
        val shade: Int?, val pageBreakBefore: Boolean, val keepNext: Boolean, val contextual: Boolean, val styleId: String?,
        val baseTf: Typeface, val baseSize: Float, val floats: List<FloatItem>,
    ) : WB {
        private var cacheW = -1
        private var cacheL: StaticLayout? = null
        fun layout(width: Float): StaticLayout {
            val w = (width - right).roundToInt().coerceAtLeast(20)
            cacheL?.let { if (cacheW == w) return it }
            val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = baseSize; typeface = baseTf; color = Color.BLACK }
            val b = StaticLayout.Builder.obtain(text, 0, text.length, paint, w)
                .setAlignment(align).setIncludePad(false)
                .setBreakStrategy(Layout.BREAK_STRATEGY_SIMPLE) // retour à la ligne « glouton », comme Word
                .setHyphenationFrequency(Layout.HYPHENATION_FREQUENCY_NONE)
                .setLineSpacing(0f, mult)
            if (justify) b.setJustificationMode(Layout.JUSTIFICATION_MODE_INTER_WORD)
            return b.build().also { cacheL = it; cacheW = w }
        }
    }
    class Table(val rows: List<DxRow>, val left: Float, val width: Float) : WB
    data object PageBreak : WB
    class Section(val geo: Geo) : WB
}

// ───────────────────────────── Spans ─────────────────────────────

internal class RunSpan(
    private val tf: Typeface, private val size: Float, private val color: Int, private val underline: Boolean,
    private val strike: Boolean, private val bg: Int?, private val vert: Int,
) : MetricAffectingSpan() {
    private fun apply(tp: TextPaint) {
        tp.typeface = tf
        tp.textSize = if (vert != 0) size * 0.65f else size
        if (vert > 0) tp.baselineShift += (tp.ascent() / 2).toInt()
        if (vert < 0) tp.baselineShift -= (tp.ascent() / 2).toInt()
    }
    override fun updateMeasureState(tp: TextPaint) = apply(tp)
    override fun updateDrawState(tp: TextPaint) {
        apply(tp)
        tp.color = color
        if (underline) tp.isUnderlineText = true
        if (strike) tp.isStrikeThruText = true
        bg?.let { tp.bgColor = it }
    }
}

internal class PicSpan(private val bmp: Bitmap, private val w: Float, private val h: Float) : ReplacementSpan() {
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    override fun getSize(paint: Paint, text: CharSequence?, start: Int, end: Int, fm: Paint.FontMetricsInt?): Int {
        if (fm != null) { fm.ascent = -h.roundToInt(); fm.descent = 0; fm.top = fm.ascent; fm.bottom = 0 }
        return w.roundToInt()
    }
    override fun draw(canvas: Canvas, text: CharSequence?, start: Int, end: Int, x: Float, top: Int, y: Int, bottom: Int, paint: Paint) {
        canvas.drawBitmap(bmp, null, RectF(x, y - h, x + w, y.toFloat()), this.paint)
    }
}

/** Interligne « exactement » / « au moins » (en points). */
internal class FixedLine(private val h: Float, private val atLeast: Boolean) : LineHeightSpan {
    override fun chooseHeight(text: CharSequence?, start: Int, end: Int, spanstartv: Int, lineHeight: Int, fm: Paint.FontMetricsInt?) {
        fm ?: return
        val cur = fm.descent - fm.ascent
        val target = if (atLeast) maxOf(cur, h.roundToInt()) else h.roundToInt()
        val d = (target * 0.21f).roundToInt()
        fm.descent = d; fm.ascent = -(target - d); fm.top = fm.ascent; fm.bottom = fm.descent
    }
}

// ───────────────────────────── Lecture du document ─────────────────────────────

internal class DocxBuilder(private val zip: ZipFile) {
    private val rels = readRels("word/_rels/document.xml.rels")
    val theme: Map<String, String> = readTheme()
    private val styles = Styles(readXml("word/styles.xml"), theme)
    private val numbering = Numbering(readXml("word/numbering.xml"), theme)
    private val imgCache = HashMap<String, Bitmap?>()
    var pageNo = 1
    var totalPages = 1

    private fun readXml(path: String): XNode? =
        zip.getEntry(path)?.let { e -> runCatching { zip.getInputStream(e).use { XmlTree.parse(it) } }.getOrNull() }

    private fun readRels(path: String): Map<String, String> {
        val root = readXml(path) ?: return emptyMap()
        val m = HashMap<String, String>()
        root.all("Relationship").forEach { r -> val id = r.a("Id"); val t = r.a("Target"); if (id != null && t != null) m[id] = t }
        return m
    }

    private fun readTheme(): Map<String, String> {
        val root = zip.entries().asSequence().firstOrNull { it.name.startsWith("word/theme/") && it.name.endsWith(".xml") }
            ?.let { e -> runCatching { zip.getInputStream(e).use { XmlTree.parse(it) } }.getOrNull() } ?: return emptyMap()
        val m = HashMap<String, String>()
        root.find("a:majorFont")?.c("a:latin")?.a("typeface")?.let { m["major"] = it }
        root.find("a:minorFont")?.c("a:latin")?.a("typeface")?.let { m["minor"] = it }
        return m
    }

    // ── Document complet : blocs + sections
    fun read(): List<WB> {
        val doc = readXml("word/document.xml") ?: error("Ce fichier n'est pas un document Word (.docx)")
        val body = doc.c("w:body") ?: error("Document vide")
        val geos = ArrayList<Geo>()
        fun scan(n: XNode) { for (k in n.kids) { if (k.name == "w:sectPr") geos.add(geoOf(k)) else if (k.name == "w:p" || k.name == "w:body") scan(k) else if (k.name == "w:pPr") scan(k) } }
        scan(body)
        if (geos.isEmpty()) geos.add(Geo.A4)
        val out = ArrayList<WB>()
        out.add(WB.Section(geos[0]))
        var gi = 0
        fun walk(kids: List<XNode>) {
            for (k in kids) when (k.name) {
                "w:p" -> {
                    paragraph(k, out)
                    if (k.c("w:pPr")?.c("w:sectPr") != null) { gi++; if (gi < geos.size) out.add(WB.Section(geos[gi])) }
                }
                "w:tbl" -> table(k, out, 0f)
                "w:sdt" -> k.c("w:sdtContent")?.let { walk(it.kids) }
            }
        }
        walk(body.kids)
        return out
    }

    private fun geoOf(s: XNode): Geo {
        val sz = s.c("w:pgSz"); val m = s.c("w:pgMar")
        fun g(n: XNode?, a: String, d: Float) = tw(n?.a(a)) ?: d
        fun ref(type: String, kind: String): String? =
            s.all(kind).firstOrNull { it.a("w:type") == type }?.a("r:id")
        return Geo(
            g(sz, "w:w", 595f), g(sz, "w:h", 842f), g(m, "w:top", 56f), g(m, "w:right", 56f), g(m, "w:bottom", 56f), g(m, "w:left", 56f),
            g(m, "w:header", 35f), g(m, "w:footer", 35f), s.c("w:type")?.v() == "continuous", s.c("w:titlePg") != null,
            ref("default", "w:headerReference"), ref("first", "w:headerReference"),
            ref("default", "w:footerReference"), ref("first", "w:footerReference"),
        )
    }

    /** Paragraphes d'un en-tête / pied de page (numéro de page déjà injecté). */
    fun headerFooter(rid: String?, pageNo: Int, total: Int): List<WB.Para> {
        val target = rid?.let { rels[it] } ?: return emptyList()
        val root = readXml("word/" + target.removePrefix("/word/")) ?: return emptyList()
        this.pageNo = pageNo; this.totalPages = total
        val out = ArrayList<WB>()
        for (k in root.kids) if (k.name == "w:p") paragraph(k, out)
        return out.filterIsInstance<WB.Para>()
    }

    // ── Paragraphe
    private class PState { val sb = SpannableStringBuilder(); val floats = ArrayList<FloatItem>() }

    fun paragraph(p: XNode, out: MutableList<WB>) {
        val ppr = p.c("w:pPr")
        val styleId = ppr?.c("w:pStyle")?.v()
        val (base, rpBase) = styles.forPara(styleId)
        val pp = base.copy()
        val markRp = rpBase.copy().also { it.over(parseRP(ppr?.c("w:rPr"), theme)) }
        val direct = parsePP(ppr)
        val numId = direct.numId ?: pp.numId
        val ilvl = direct.ilvl ?: pp.ilvl ?: 0
        var label: String? = null
        var labelRp = markRp
        if (numId != null && numId != 0) {
            numbering.level(numId, ilvl)?.let { lv ->
                pp.over(lv.pp)
                labelRp = markRp.copy().also { it.over(lv.rp) }
            }
            label = numbering.label(numId, ilvl)
        }
        pp.over(direct)

        var st = PState()
        var firstPiece = true
        var inField = false
        var instr = StringBuilder()
        var skipResult = false

        fun runProps(r: XNode): RP {
            val rpr = r.c("w:rPr")
            val rp = rpBase.copy()
            styles.charStyle(rpr?.c("w:rStyle")?.v())?.let { rp.over(it) }
            rp.over(parseRP(rpr, theme))
            return rp
        }

        fun append(text: String, rp: RP) {
            if (text.isEmpty() || rp.vanish == true) return
            val t = if (rp.caps == true) text.uppercase() else text
            val start = st.sb.length
            st.sb.append(t)
            val fam = FontKit.family(rp.font)
            val tf = FontKit.typeface(fam, rp.bold == true, rp.italic == true)
            st.sb.setSpan(
                RunSpan(tf, rp.size ?: 10f, rp.color ?: Color.BLACK, rp.underline == true, rp.strike == true, rp.bg, rp.vert ?: 0),
                start, st.sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE,
            )
        }

        fun flush(last: Boolean) {
            val first = firstPiece
            out.add(makePara(st.sb, st.floats, pp, markRp, labelRp, if (first) label else null, styleId, first))
            firstPiece = false
            st = PState()
            if (!last) out.add(WB.PageBreak)
        }

        fun drawing(d: XNode, rp: RP) {
            val inline = d.c("wp:inline")
            val anchor = d.c("wp:anchor")
            val node = inline ?: anchor ?: return
            val ext = node.c("wp:extent")
            val w = (ext?.a("cx")?.toLongOrNull() ?: 0L) / 12700f
            val h = (ext?.a("cy")?.toLongOrNull() ?: 0L) / 12700f
            val blip = node.find("a:blip")
            val bmp = blip?.a("r:embed")?.let { id -> rels[id]?.let { loadImage(it) } }
            val txbx = node.find("w:txbxContent")
            if (inline != null) {
                if (bmp != null) {
                    val s = st.sb.length
                    st.sb.append('\uFFFC')
                    st.sb.setSpan(
                        PicSpan(bmp, if (w > 1f) w else bmp.width * 0.75f, if (h > 1f) h else bmp.height * 0.75f),
                        s, st.sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE,
                    )
                }
                return
            }
            // Objet flottant : position absolue
            val ph = node.c("wp:positionH"); val pv = node.c("wp:positionV")
            val box: List<WB.Para>? = txbx?.let { tb ->
                val inner = ArrayList<WB>()
                for (k in tb.kids) if (k.name == "w:p") paragraph(k, inner)
                inner.filterIsInstance<WB.Para>()
            }
            if (bmp == null && box == null) return
            val bp = node.find("wps:bodyPr")
            fun ins(a: String, dflt: Float) = (bp?.a(a)?.toLongOrNull()?.div(12700f)) ?: dflt
            st.floats.add(
                FloatItem(
                    bmp, box, if (box != null && bp?.a("wrap") == "none") w + 600f else w, h, // « pas de retour à la ligne »
                    (ph?.c("wp:posOffset")?.text?.toString()?.trim()?.toLongOrNull() ?: 0L) / 12700f,
                    (pv?.c("wp:posOffset")?.text?.toString()?.trim()?.toLongOrNull() ?: 0L) / 12700f,
                    ph?.a("relativeFrom") ?: "page", pv?.a("relativeFrom") ?: "page",
                    ph?.c("wp:align")?.text?.toString()?.trim(), pv?.c("wp:align")?.text?.toString()?.trim(),
                    anchor?.a("behindDoc") == "1", ins("lIns", 7.2f), ins("tIns", 3.6f),
                ),
            )
        }

        fun run(r: XNode) {
            val rp = runProps(r)
            for (k in r.kids) when (k.name) {
                "w:t" -> if (!skipResult) append(k.text.toString(), rp)
                "w:tab" -> if (!skipResult) append("\t", rp)
                "w:br", "w:cr" -> if (!skipResult) { if (k.a("w:type") == "page") flush(false) else append("\n", rp) }
                "w:noBreakHyphen" -> append("-", rp)
                "w:instrText" -> instr.append(k.text)
                "w:fldChar" -> when (k.a("w:fldCharType")) {
                    "begin" -> { inField = true; instr = StringBuilder(); skipResult = false }
                    "separate" -> {
                        val s = instr.toString().uppercase()
                        if (s.contains("NUMPAGES")) { append(totalPages.toString(), rp); skipResult = true }
                        else if (s.contains("PAGE")) { append(pageNo.toString(), rp); skipResult = true }
                    }
                    "end" -> { inField = false; skipResult = false }
                }
                "w:drawing" -> drawing(k, rp)
                "mc:AlternateContent" -> k.c("mc:Choice")?.find("w:drawing")?.let { drawing(it, rp) }
            }
        }

        fun walk(kids: List<XNode>) {
            for (k in kids) when (k.name) {
                "w:r" -> run(k)
                "w:hyperlink", "w:ins", "w:smartTag", "w:customXml", "w:moveTo", "w:sdtContent" -> walk(k.kids)
                "w:sdt" -> k.c("w:sdtContent")?.let { walk(it.kids) }
                "w:fldSimple" -> {
                    val s = (k.a("w:instr") ?: "").uppercase()
                    val rp = k.c("w:r")?.let { runProps(it) } ?: rpBase.copy()
                    when {
                        s.contains("NUMPAGES") -> append(totalPages.toString(), rp)
                        s.contains("PAGE") -> append(pageNo.toString(), rp)
                        else -> walk(k.kids)
                    }
                }
                "mc:AlternateContent" -> k.c("mc:Choice")?.let { walk(it.kids) }
            }
        }
        walk(p.kids)
        flush(true)
    }

    private fun makePara(
        sb: SpannableStringBuilder, floats: List<FloatItem>, pp: PP, markRp: RP, labelRp: RP,
        label: String?, styleId: String?, first: Boolean,
    ): WB.Para {
        val fam = FontKit.family(markRp.font)
        val tf = FontKit.typeface(fam, markRp.bold == true, markRp.italic == true)
        val size = markRp.size ?: 10f
        if (sb.isEmpty()) { // paragraphe vide : garde la hauteur de ligne de la marque de paragraphe
            sb.append(' ')
            sb.setSpan(RunSpan(tf, size, Color.BLACK, false, false, null, 0), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        val left = (pp.left ?: 0f).coerceAtLeast(0f)
        val firstLine = when {
            pp.hanging != null -> -(pp.hanging!!)
            pp.first != null -> pp.first!!
            else -> 0f
        }
        val firstX = (left + firstLine).coerceAtLeast(0f)
        // Paragraphes Android : un par segment séparé par un saut de ligne
        val tabs = pp.tabs
        var segStart = 0
        var segIdx = 0
        val text = sb.toString()
        while (segStart <= text.length) {
            var segEnd = text.indexOf('\n', segStart)
            val last = segEnd < 0
            if (last) segEnd = text.length
            if (segEnd > segStart) {
                val f = Spanned.SPAN_INCLUSIVE_EXCLUSIVE
                sb.setSpan(LeadingMarginSpan.Standard(if (segIdx == 0) firstX.roundToInt() else left.roundToInt(), left.roundToInt()), segStart, segEnd, f)
                if (pp.line != null && pp.lineRule != null && pp.lineRule != "auto") sb.setSpan(FixedLine(pp.line!!, pp.lineRule == "atLeast"), segStart, segEnd, f)
                if (text.indexOf('\t', segStart).let { it in segStart until segEnd }) {
                    val stops = ArrayList<Int>()
                    tabs?.forEach { stops.add(it.roundToInt()) }
                    for (i in 1..40) stops.add((36f * i).roundToInt()) // taquets par défaut de Word : tous les 36 pt
                    stops.sorted().distinct().forEach { sb.setSpan(TabStopSpan.Standard(it), segStart, segEnd, f) }
                }
            }
            segIdx++
            if (last) break
            segStart = segEnd + 1
        }
        val mult = if (pp.lineRule == "auto" || pp.line == null || pp.lineRule == null) (pp.line ?: 1f) * fam.lineFix else fam.lineFix
        val align = when (pp.align) {
            "center" -> Layout.Alignment.ALIGN_CENTER
            "right", "end" -> Layout.Alignment.ALIGN_OPPOSITE
            else -> Layout.Alignment.ALIGN_NORMAL
        }
        val lfam = FontKit.family(labelRp.font)
        return WB.Para(
            sb, align, pp.align == "both" || pp.align == "distribute",
            if (first) (pp.before ?: 0f) else 0f, pp.after ?: 0f, mult, left, (pp.right ?: 0f).coerceAtLeast(0f), firstLine,
            label, FontKit.typeface(lfam, labelRp.bold == true, labelRp.italic == true), labelRp.size ?: size, labelRp.color ?: Color.BLACK,
            pp.shd, pp.pageBreakBefore == true && first, pp.keepNext == true, pp.contextual == true, styleId, tf, size, floats,
        )
    }

    // ── Tableaux
    private fun border(n: XNode?): DxBorder? {
        if (n == null) return null
        val v = n.v()
        if (v == null || v == "nil" || v == "none") return null
        return DxBorder(((n.a("w:sz")?.toFloatOrNull() ?: 4f) / 8f).coerceAtLeast(0.25f), colorOf(n.a("w:color")) ?: Color.BLACK)
    }

    fun table(t: XNode, out: MutableList<WB>, outerLeft: Float) {
        val pr = t.c("w:tblPr")
        val tblB = pr?.c("w:tblBorders") ?: styles.tableBorders(pr?.c("w:tblStyle")?.v())
        val grid = t.c("w:tblGrid")?.all("w:gridCol")?.map { (tw(it.a("w:w")) ?: 0f) } ?: emptyList()
        val ind = tw(pr?.c("w:tblInd")?.a("w:w")) ?: 0f
        val padL = tw(pr?.c("w:tblCellMar")?.c("w:left")?.a("w:w")) ?: 5.4f
        val rows = ArrayList<DxRow>()
        val ongoing = HashMap<Int, DxCell>() // fusions verticales en cours (colonne → cellule d'origine)
        for (tr in t.all("w:tr")) {
            val cells = ArrayList<DxCell>()
            var col = 0
            var x = 0f
            val trh = tr.c("w:trPr")?.c("w:trHeight")
            for (tc in tr.all("w:tc")) {
                val tcp = tc.c("w:tcPr")
                val span = tcp?.c("w:gridSpan")?.v()?.toIntOrNull() ?: 1
                var w = 0f
                for (i in col until col + span) w += grid.getOrNull(i) ?: 0f
                if (w <= 0f) w = tw(tcp?.c("w:tcW")?.a("w:w")) ?: 60f
                val vm = tcp?.c("w:vMerge")
                val cont = vm != null && vm.v() != "restart"
                val tb = tcp?.c("w:tcBorders")
                fun pick(side: String, inside: String, edge: Boolean): DxBorder? {
                    val own = tb?.c("w:$side")
                    if (own != null) return border(own)
                    return border(tblB?.c(if (edge) "w:$side" else "w:$inside"))
                }
                val inner = ArrayList<WB>()
                if (!cont) for (k in tc.kids) when (k.name) { "w:p" -> paragraph(k, inner); "w:tbl" -> table(k, inner, 0f) }
                val cell = DxCell(
                    inner, x, w, colorOf(tcp?.c("w:shd")?.a("w:fill")),
                    DxBorders(
                        pick("top", "insideH", rows.isEmpty()), pick("left", "insideV", col == 0),
                        pick("bottom", "insideH", false), pick("right", "insideV", false),
                    ),
                    cont,
                )
                if (cont) ongoing[col]?.let { it.vmSpan++ } else if (vm != null) ongoing[col] = cell else ongoing.remove(col)
                cells.add(cell)
                x += w; col += span
            }
            val h = tw(trh?.a("w:val")) ?: 0f
            rows.add(DxRow(cells, h, trh?.a("w:hRule") == "exact"))
        }
        // bordure basse du tableau : appliquée à la dernière ligne
        out.add(WB.Table(rows, outerLeft + ind - padL, grid.sum()))
    }

    private fun loadImage(target: String): Bitmap? = imgCache.getOrPut(target) {
        val path = if (target.startsWith("/")) target.removePrefix("/") else "word/$target"
        val e = zip.getEntry(path) ?: return@getOrPut null
        val bytes = zip.getInputStream(e).use { it.readBytes() }
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0) return@getOrPut null // EMF / WMF non pris en charge
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= 2400) sample *= 2
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
    }
}
