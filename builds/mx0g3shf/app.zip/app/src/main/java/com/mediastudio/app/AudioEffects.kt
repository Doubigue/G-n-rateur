package com.mediastudio.app

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI

/** Effets audio appliqués à l'export, sans modifier le fichier source. */
enum class AudioPreset(val label: String) {
    RADIO("Radio ancienne"), PHONE("Téléphone"), BASS("Basses renforcées"),
    TREBLE("Aigus clairs"), ECHO("Écho léger")
}

/**
 * DSP PCM 16 bits, autonome et hors ligne. Radio = bande passante réduite + saturation douce
 * + quantification vintage ; téléphone = bande vocale ; basses/aigus = accentuation ;
 * écho = retard court avec retour modéré.
 */
@UnstableApi
class PresetAudioProcessor(private val preset: AudioPreset) : BaseAudioProcessor() {
    private var channels = 2
    private var rate = 44100
    private var low = FloatArray(2)
    private var previous = FloatArray(2)
    private var echo = FloatArray(2)
    private var echoIndex = 0
    private var echoDelayFrames = 1

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        require(inputAudioFormat.encoding == C.ENCODING_PCM_16BIT) {
            "Format audio non pris en charge pour cet effet (PCM 16 bits requis)."
        }
        channels = inputAudioFormat.channelCount.coerceIn(1, 8)
        rate = inputAudioFormat.sampleRate.coerceAtLeast(8000)
        low = FloatArray(channels)
        previous = FloatArray(channels)
        echoDelayFrames = (rate * 0.19f).toInt().coerceAtLeast(1)
        echo = FloatArray(echoDelayFrames * channels)
        echoIndex = 0
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val size = inputBuffer.remaining()
        val output = replaceOutputBuffer(size).order(ByteOrder.LITTLE_ENDIAN)
        val input = inputBuffer.slice().order(ByteOrder.LITTLE_ENDIAN)
        val frameCount = size / (2 * channels)
        val upperCutoff = when (preset) {
            AudioPreset.RADIO -> 3500.0
            AudioPreset.PHONE -> 3000.0
            AudioPreset.BASS -> 180.0
            AudioPreset.TREBLE -> 2500.0
            AudioPreset.ECHO -> 900.0
        }
        val lowerCutoff = if (preset == AudioPreset.RADIO || preset == AudioPreset.PHONE) 300.0 else upperCutoff
        val alphaUpper = (1f - kotlin.math.exp((-2.0 * PI * upperCutoff / rate).toFloat())).coerceIn(0.001f, 0.99f)
        val alphaLower = (1f - kotlin.math.exp((-2.0 * PI * lowerCutoff / rate).toFloat())).coerceIn(0.001f, 0.99f)

        repeat(frameCount) {
            for (ch in 0 until channels) {
                val x = input.getShort() / 32768f
                low[ch] += alphaUpper * (x - low[ch])
                previous[ch] += alphaLower * (x - previous[ch])
                val high = x - low[ch]
                val y = when (preset) {
                    AudioPreset.RADIO -> {
                        val band = previous[ch] - low[ch]
                        val saturated = (band * 2.2f).coerceIn(-1f, 1f)
                        // Une quantification douce évoque les anciens récepteurs sans ajouter de bruit aléatoire.
                        (saturated * 92f).toInt() / 92f
                    }
                    AudioPreset.PHONE -> {
                        val voiceBand = previous[ch] - low[ch]
                        (voiceBand * 2.2f).coerceIn(-0.88f, 0.88f)
                    }
                    AudioPreset.BASS -> (x + low[ch] * 0.85f).coerceIn(-1f, 1f)
                    AudioPreset.TREBLE -> (x + high * 0.65f).coerceIn(-1f, 1f)
                    AudioPreset.ECHO -> {
                        val delayed = echo[echoIndex]
                        val mixed = (x + delayed * 0.38f).coerceIn(-1f, 1f)
                        echo[echoIndex] = (x + delayed * 0.22f).coerceIn(-1f, 1f)
                        mixed
                    }
                }
                output.putShort((y * 32767f).toInt().coerceIn(-32768, 32767).toShort())
                if (preset == AudioPreset.ECHO) echoIndex = (echoIndex + 1) % echo.size
            }
        }
        inputBuffer.position(inputBuffer.limit())
        output.flip()
    }

    override fun onFlush() {
        low.fill(0f); previous.fill(0f); echo.fill(0f); echoIndex = 0
    }

    override fun onReset() {
        low = FloatArray(0); previous = FloatArray(0); echo = FloatArray(0)
    }
}
