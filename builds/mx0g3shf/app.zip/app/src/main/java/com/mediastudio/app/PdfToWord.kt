package com.mediastudio.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.contentstream.operator.Operator
import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.pdfparser.PDFStreamParser
import com.tom_roush.pdfbox.pdfwriter.ContentStreamWriter
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDResources
import com.tom_roush.pdfbox.pdmodel.common.PDStream
import com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException
import com.tom_roush.pdfbox.pdmodel.graphics.form.PDFormXObject
import com.tom_roush.pdfbox.pdmodel.graphics.state.RenderingMode
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * PDF → Word qui reproduit la page :
 *  - chaque page du PDF devient une page Word de MÊME taille, sans marges (même nombre de pages) ;
 *  - le texte est de vrais textes modifiables, posés à la position exacte, avec la police, la taille, le gras/italique et la couleur du PDF ;
 *  - tout le reste (images, filets, aplats, dégradés, logos) est rendu dans une image de fond, DANS LAQUELLE LE TEXTE A ÉTÉ RETIRÉ ;
 *  - PDF scanné (aucun texte) : l'image de chaque page, à la taille de la page.
 */
internal object PdfToWord {

    private const val EMU = 12700f
    private const val BASELINE = 0.97f // position de la ligne de base dans une boîte à interligne « exactement 1,2 × » (mesuré)

    private class Glyph(
        val ch: String, val x: Float, val y: Float, val w: Float, val size: Float,
        val font: String, val bold: Boolean, val italic: Boolean, val color: Int,
    )

    private class Run(val text: StringBuilder, val font: String, val size: Float, val bold: Boolean, val italic: Boolean, val color: Int)
    private class Seg(val x: Float, val y: Float, var end: Float, var size: Float, val runs: ArrayList<Run>)

    /** Récupère chaque caractère avec sa position, sa police et sa couleur réelles. */
    private class StyledStripper : PDFTextStripper() {
        val glyphs = ArrayList<Glyph>()

        override fun processTextPosition(text: TextPosition) {
            try {
                val gs = graphicsState
                val mode = gs.textState.renderingMode
                if (mode == RenderingMode.NEITHER) return // texte invisible (couche OCR)
                val rgb = runCatching {
                    val col = if (mode.isFill) gs.nonStrokingColor else gs.strokingColor
                    col.toRGB() and 0xFFFFFF
                }.getOrDefault(0)
                val u = text.unicode ?: return
                if (u.isEmpty()) return
                val fname = text.font?.name ?: ""
                val fd = text.font?.fontDescriptor
                val bold = Regex("(?i)bold|black|heavy|semibold|demi").containsMatchIn(fname) ||
                    (fd != null && (fd.isForceBold || fd.fontWeight >= 700f))
                val italic = Regex("(?i)italic|oblique").containsMatchIn(fname) || (fd != null && (fd.isItalic || fd.italicAngle != 0f))
                glyphs += Glyph(u, text.xDirAdj, text.yDirAdj, text.widthDirAdj, text.fontSizeInPt, fname, bold, italic, 0xFF000000.toInt() or rgb)
            } catch (_: Exception) { /* un caractère illisible ne doit pas arrêter la conversion */ }
        }
    }

    suspend fun convert(ctx: Context, input: Uri, output: File, onProgress: (Float) -> Unit) {
        PDFBoxResourceLoader.init(ctx.applicationContext)
        val tmp = File.createTempFile("conv", ".pdf", ctx.cacheDir)
        val stripped = File.createTempFile("conv_notext", ".pdf", ctx.cacheDir)
        try {
            ctx.contentResolver.openInputStream(input)?.use { i -> tmp.outputStream().use { i.copyTo(it) } } ?: error("Fichier illisible")

            // 1) texte positionné, page par page
            val pagesSegs = ArrayList<List<Seg>>()
            try {
                PDDocument.load(tmp).use { doc ->
                    val n = doc.numberOfPages
                    for (p in 1..n) {
                        val st = StyledStripper().apply { startPage = p; endPage = p; sortByPosition = false }
                        st.getText(doc)
                        pagesSegs += segments(st.glyphs)
                        onProgress(0.3f * p / n)
                    }
                    // 2) copie du PDF dont le texte est retiré (pour le fond)
                    val done = HashSet<Any>()
                    for (page in doc.pages) runCatching { stripText(doc, page, done) }
                    doc.save(stripped)
                }
            } catch (e: InvalidPasswordException) { error("PDF protégé par mot de passe") }

            val hasText = pagesSegs.any { it.isNotEmpty() }
            // 3) fonds (images, filets, aplats…) : rendu du PDF sans texte, ou du PDF d'origine s'il est scanné
            val bg = render(if (hasText) stripped else tmp) { onProgress(0.3f + 0.65f * it) }
            writeDocx(pagesSegs, bg, output)
            onProgress(1f)
        } finally { tmp.delete(); stripped.delete() }
    }

    // ───────────────────────────── Lignes et blocs de texte ─────────────────────────────

    private fun segments(gl: List<Glyph>): List<Seg> {
        val out = ArrayList<Seg>()
        var cur: Seg? = null
        for (g in gl) {
            val c = cur
            val fits = c != null && abs(g.y - c.y) <= 0.3f * g.size && (g.x - c.end) >= -0.5f * g.size && (g.x - c.end) <= 0.9f * g.size
            if (c != null && fits) {
                val last = c.runs.last()
                if (g.x - c.end > 0.15f * g.size && !last.text.endsWith(" ") && g.ch != " ") last.text.append(' ')
                if (last.font == g.font && abs(last.size - g.size) < 0.05f && last.bold == g.bold && last.italic == g.italic && last.color == g.color) last.text.append(g.ch)
                else c.runs += Run(StringBuilder(g.ch), g.font, g.size, g.bold, g.italic, g.color)
                c.end = g.x + g.w
                if (g.size > c.size) c.size = g.size
            } else {
                cur = Seg(g.x, g.y, g.x + g.w, g.size, arrayListOf(Run(StringBuilder(g.ch), g.font, g.size, g.bold, g.italic, g.color))).also { out += it }
            }
        }
        return out.filter { s -> s.runs.any { it.text.isNotBlank() } }
    }

    // ───────────────────────────── PDF sans texte ─────────────────────────────

    private fun stripText(doc: PDDocument, page: PDPage, done: HashSet<Any>) {
        val toks = PDFStreamParser(page).also { it.parse() }.tokens
        val kept = withoutText(doc, toks, page.resources, done, 0)
        val ns = PDStream(doc)
        ns.createOutputStream(COSName.FLATE_DECODE).use { ContentStreamWriter(it).writeTokens(kept) }
        page.setContents(ns)
    }

    private fun withoutText(doc: PDDocument, toks: List<Any?>, res: PDResources?, done: HashSet<Any>, depth: Int): List<Any?> {
        val out = ArrayList<Any?>(toks.size)
        var inText = false
        for ((i, t) in toks.withIndex()) {
            if (t is Operator) {
                when (t.name) {
                    "BT" -> { inText = true; continue }
                    "ET" -> { inText = false; continue }
                    "Do" -> if (!inText && depth < 6 && res != null) {
                        val nm = toks.getOrNull(i - 1) as? COSName
                        if (nm != null) runCatching {
                            val xo = res.getXObject(nm)
                            if (xo is PDFormXObject && done.add(xo.cosObject)) {
                                val inner = PDFStreamParser(xo).also { it.parse() }.tokens
                                val cleaned = withoutText(doc, inner, xo.resources ?: res, done, depth + 1)
                                xo.contentStream.createOutputStream(COSName.FLATE_DECODE).use { ContentStreamWriter(it).writeTokens(cleaned) }
                            }
                        }
                    }
                }
            }
            if (!inText) out += t
        }
        return out
    }

    // ───────────────────────────── Rendu des fonds ─────────────────────────────

    private class PageBg(val wPt: Float, val hPt: Float, val jpeg: ByteArray?)

    private fun render(pdf: File, progress: (Float) -> Unit): List<PageBg> {
        val pfd = ParcelFileDescriptor.open(pdf, ParcelFileDescriptor.MODE_READ_ONLY)
        val out = ArrayList<PageBg>()
        try {
            PdfRenderer(pfd).use { r ->
                for (i in 0 until r.pageCount) {
                    r.openPage(i).use { page ->
                        val wPt = page.width.toFloat(); val hPt = page.height.toFloat()
                        val px = minOf(2000f, wPt * 150f / 72f)           // 150 dpi
                        val w = px.roundToInt().coerceAtLeast(1)
                        val h = (px * hPt / wPt).roundToInt().coerceAtLeast(1)
                        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        bmp.eraseColor(Color.WHITE)
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        val jpeg = if (isBlank(bmp)) null else ByteArrayOutputStream().also { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }.toByteArray()
                        bmp.recycle()
                        out += PageBg(wPt, hPt, jpeg)
                    }
                    progress((i + 1f) / r.pageCount)
                }
            }
        } finally { pfd.close() }
        return out
    }

    /** Page entièrement blanche : inutile d'embarquer une image. */
    private fun isBlank(b: Bitmap): Boolean {
        val row = IntArray(b.width)
        for (yy in 0 until b.height) {
            b.getPixels(row, 0, b.width, 0, yy, b.width, 1)
            for (p in row) if ((p shr 16 and 0xFF) < 250 || (p shr 8 and 0xFF) < 250 || (p and 0xFF) < 250) return false
        }
        return true
    }

    // ───────────────────────────── Écriture du .docx ─────────────────────────────

    private const val HDR = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
    private const val NS = "xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" " +
        "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" " +
        "xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" " +
        "xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" " +
        "xmlns:pic=\"http://schemas.openxmlformats.org/drawingml/2006/picture\" " +
        "xmlns:wps=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\""

    private fun emu(pt: Float) = (pt * EMU).toLong()

    private fun writeDocx(pages: List<List<Seg>>, bg: List<PageBg>, output: File) {
        val body = StringBuilder()
        var id = 1
        var lastSect = ""
        val media = ArrayList<ByteArray>()
        val rels = StringBuilder()
        for (pi in bg.indices) {
            val pg = bg[pi]
            val sect = "<w:sectPr><w:pgSz w:w=\"${(pg.wPt * 20).roundToInt()}\" w:h=\"${(pg.hPt * 20).roundToInt()}\"/>" +
                "<w:pgMar w:top=\"0\" w:right=\"0\" w:bottom=\"0\" w:left=\"0\" w:header=\"0\" w:footer=\"0\" w:gutter=\"0\"/></w:sectPr>"
            val anchors = StringBuilder()
            pg.jpeg?.let { jpg ->
                media += jpg
                val rid = "rIdImg${media.size}"
                rels.append("<Relationship Id=\"$rid\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" Target=\"media/bg${media.size}.jpg\"/>")
                val cx = emu(pg.wPt); val cy = emu(pg.hPt)
                anchors.append(
                    "<w:r><w:drawing><wp:anchor distT=\"0\" distB=\"0\" distL=\"0\" distR=\"0\" simplePos=\"0\" relativeHeight=\"0\" behindDoc=\"1\" locked=\"1\" layoutInCell=\"1\" allowOverlap=\"1\">" +
                        "<wp:simplePos x=\"0\" y=\"0\"/><wp:positionH relativeFrom=\"page\"><wp:posOffset>0</wp:posOffset></wp:positionH>" +
                        "<wp:positionV relativeFrom=\"page\"><wp:posOffset>0</wp:posOffset></wp:positionV><wp:extent cx=\"$cx\" cy=\"$cy\"/>" +
                        "<wp:effectExtent l=\"0\" t=\"0\" r=\"0\" b=\"0\"/><wp:wrapNone/><wp:docPr id=\"${id}\" name=\"Page ${pi + 1}\"/><wp:cNvGraphicFramePr/>" +
                        "<a:graphic><a:graphicData uri=\"http://schemas.openxmlformats.org/drawingml/2006/picture\"><pic:pic>" +
                        "<pic:nvPicPr><pic:cNvPr id=\"${id}\" name=\"bg${media.size}.jpg\"/><pic:cNvPicPr/></pic:nvPicPr>" +
                        "<pic:blipFill><a:blip r:embed=\"$rid\"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>" +
                        "<pic:spPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"$cx\" cy=\"$cy\"/></a:xfrm><a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></pic:spPr>" +
                        "</pic:pic></a:graphicData></a:graphic></wp:anchor></w:drawing></w:r>",
                )
                id++
            }
            for (s in pages.getOrElse(pi) { emptyList() }) { anchors.append(textBox(id++, s)) }
            val ppr = "<w:pPr><w:spacing w:before=\"0\" w:after=\"0\" w:line=\"20\" w:lineRule=\"exact\"/>" +
                (if (pi < bg.size - 1) sect else "") + "</w:pPr>"
            body.append("<w:p>").append(ppr).append(anchors).append("</w:p>")
            lastSect = sect
        }

        ZipOutputStream(output.outputStream().buffered()).use { z ->
            fun put(name: String, data: ByteArray) { z.putNextEntry(ZipEntry(name)); z.write(data); z.closeEntry() }
            put(
                "[Content_Types].xml",
                ("$HDR<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
                    "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
                    "<Default Extension=\"xml\" ContentType=\"application/xml\"/><Default Extension=\"jpg\" ContentType=\"image/jpeg\"/>" +
                    "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>" +
                    "<Override PartName=\"/word/settings.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml\"/>" +
                    "</Types>").toByteArray(),
            )
            put(
                "_rels/.rels",
                ("$HDR<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                    "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/></Relationships>").toByteArray(),
            )
            put(
                "word/settings.xml",
                ("$HDR<w:settings xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\">" +
                    "<w:compat><w:compatSetting w:name=\"compatibilityMode\" w:uri=\"http://schemas.microsoft.com/office/word\" w:val=\"15\"/></w:compat></w:settings>").toByteArray(),
            )
            put(
                "word/_rels/document.xml.rels",
                ("$HDR<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                    "<Relationship Id=\"rIdSet\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/settings\" Target=\"settings.xml\"/>" +
                    rels + "</Relationships>").toByteArray(),
            )
            put("word/document.xml", "$HDR<w:document $NS><w:body>$body$lastSect</w:body></w:document>".toByteArray())
            media.forEachIndexed { i, b -> put("word/media/bg${i + 1}.jpg", b) }
        }
    }

    private fun textBox(id: Int, s: Seg): String {
        val lineH = s.size * 1.2f
        val w = (s.end - s.x) + s.size * 0.6f
        val runs = StringBuilder()
        for (r in s.runs) {
            val f = fontName(r.font)
            val sz = (r.size * 2).roundToInt().coerceAtLeast(2)
            runs.append("<w:r><w:rPr><w:rFonts w:ascii=\"$f\" w:hAnsi=\"$f\" w:cs=\"$f\"/>")
            if (r.bold) runs.append("<w:b/>")
            if (r.italic) runs.append("<w:i/>")
            runs.append("<w:color w:val=\"%06X\"/>".format(r.color and 0xFFFFFF))
            runs.append("<w:sz w:val=\"$sz\"/><w:szCs w:val=\"$sz\"/></w:rPr><w:t xml:space=\"preserve\">").append(esc(r.text.toString())).append("</w:t></w:r>")
        }
        val cx = emu(w); val cy = emu(lineH)
        return "<w:r><w:drawing><wp:anchor distT=\"0\" distB=\"0\" distL=\"0\" distR=\"0\" simplePos=\"0\" relativeHeight=\"${id + 10}\" behindDoc=\"0\" locked=\"0\" layoutInCell=\"1\" allowOverlap=\"1\">" +
            "<wp:simplePos x=\"0\" y=\"0\"/><wp:positionH relativeFrom=\"page\"><wp:posOffset>${emu(s.x)}</wp:posOffset></wp:positionH>" +
            "<wp:positionV relativeFrom=\"page\"><wp:posOffset>${emu(s.y - BASELINE * s.size)}</wp:posOffset></wp:positionV>" +
            "<wp:extent cx=\"$cx\" cy=\"$cy\"/><wp:effectExtent l=\"0\" t=\"0\" r=\"0\" b=\"0\"/><wp:wrapNone/><wp:docPr id=\"$id\" name=\"Texte $id\"/><wp:cNvGraphicFramePr/>" +
            "<a:graphic><a:graphicData uri=\"http://schemas.microsoft.com/office/word/2010/wordprocessingShape\"><wps:wsp><wps:cNvSpPr txBox=\"1\"/>" +
            "<wps:spPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"$cx\" cy=\"$cy\"/></a:xfrm><a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom><a:noFill/><a:ln><a:noFill/></a:ln></wps:spPr>" +
            "<wps:txbx><w:txbxContent><w:p><w:pPr><w:spacing w:before=\"0\" w:after=\"0\" w:line=\"${(lineH * 20).roundToInt()}\" w:lineRule=\"exact\"/></w:pPr>$runs</w:p></w:txbxContent></wps:txbx>" +
            "<wps:bodyPr wrap=\"none\" lIns=\"0\" tIns=\"0\" rIns=\"0\" bIns=\"0\" anchor=\"t\"><a:noAutofit/></wps:bodyPr></wps:wsp></a:graphicData></a:graphic></wp:anchor></w:drawing></w:r>"
    }

    /** « ABCDEF+TimesNewRomanPS-BoldMT » → « Times New Roman » (la police Word du même nom). */
    private fun fontName(raw: String): String {
        var n = raw.replace(Regex("^[A-Z]{6}\\+"), "").substringBefore(',').substringBefore('-')
        n = n.replace(Regex("(PSMT|MT|PS)$"), "").replace(Regex("(?<=[a-z])(?=[A-Z])"), " ").trim()
        return when (n.lowercase()) {
            "", "helvetica" -> "Arial"
            "times", "times roman" -> "Times New Roman"
            "courier" -> "Courier New"
            else -> esc(n)
        }
    }

    private fun esc(s: String): String = buildString(s.length + 16) {
        for (c in s) when {
            c == '&' -> append("&amp;")
            c == '<' -> append("&lt;")
            c == '>' -> append("&gt;")
            c == '"' -> append("&quot;")
            c.code < 0x20 && c != '\t' && c != '\n' && c != '\r' -> {}
            else -> append(c)
        }
    }
}
