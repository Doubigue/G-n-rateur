package com.mediastudio.app

import android.app.Activity
import android.app.ActivityManager
import android.content.Intent
import android.os.Bundle

/**
 * Cible de la notification de progression. Media Studio s'affiche par-dessus LinkShare, dans la tâche de LinkShare :
 * on ramène donc cette tâche au premier plan (l'écran Media Studio est au sommet), au lieu d'ouvrir l'accueil
 * de Media Studio ou de retomber sur LinkShare. Sans écran ouvert, on ouvre Media Studio normalement.
 */
class NotifOpenActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = ExportManager.routerTaskId
        val moved = id >= 0 && runCatching {
            getSystemService(ActivityManager::class.java).moveTaskToFront(id, ActivityManager.MOVE_TASK_WITH_HOME)
        }.isSuccess
        if (!moved) startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }
}
