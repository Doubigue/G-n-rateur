package com.mediastudio.app

import android.content.Context
import androidx.media3.common.util.UnstableApi
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.graphics.Bitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Comptage, extraction des images et création d'un paquet autonome de reconstruction. */
@UnstableApi
object VideoFrameOps {
    private const val MAX_FRAMES = 250_000L

    suspend fun count(ctx: Context, source: Uri): Long = withContext(Dispatchers.IO) {
        countSamples(ctx, source)
    }

    /**
     * Le ZIP contient <nom-video>/image_XXXXXX.jpg, metadata.txt et, lorsque la piste
     * audio est AAC compatible MP4, audio_originale.m4a.
     */
    suspend fun extractAll(
        ctx: Context, source: Uri, baseName: String, output: File, onProgress: (Float) -> Unit = {}
    ): Long = withContext(Dispatchers.IO) {
        val total = countSamples(ctx, source)
        require(total > 0) { "Aucune image vidéo n'a été trouvée." }
        val retriever = MediaMetadataRetriever()
        val extractor = MediaExtractor()
        val tempAudio = File(ctx.cacheDir, "mediastudio_audio_${System.nanoTime()}.m4a")
        var audioInfo = AudioInfo(false, "Aucune piste audio", null, 0, 0, 0)
        try {
            retriever.setDataSource(ctx, source)
            extractor.setDataSource(ctx, source, null)
            val videoTrack = findVideoTrack(extractor)
            val videoFormat = extractor.getTrackFormat(videoTrack)
            val safeFolder = baseName.replace(Regex("[\\\\/:*?\\\"<>|\\u0000-\\u001F]"), "_").trim().ifEmpty { "video" }
            val metadata = readMetadata(retriever, videoFormat, total, extractor)
            audioInfo = extractAudioIfPossible(ctx, source, tempAudio)
            val containerMime = ctx.contentResolver.getType(source) ?: "inconnu"

            var index = 0L
            ZipOutputStream(output.outputStream().buffered()).use { zip ->
                extractor.selectTrack(videoTrack)
                while (extractor.sampleTime >= 0) {
                    val timeUs = extractor.sampleTime
                    val bitmap = retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST)
                    if (bitmap != null) {
                        index++
                        val fileName = String.format(Locale.US, "%s/image_%06d.jpg", safeFolder, index)
                        zip.putNextEntry(ZipEntry(fileName))
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, zip)
                        zip.closeEntry()
                        bitmap.recycle()
                    }
                    if (index > MAX_FRAMES) error("La vidéo contient trop d'images (limite : $MAX_FRAMES).")
                    onProgress((index.toFloat() / total.toFloat()).coerceIn(0f, 0.95f))
                    if (!extractor.advance()) break
                }
                require(index > 0) { "Impossible d'extraire les images de cette vidéo." }

                val report = buildString {
                    appendLine("MEDIA STUDIO - METADONNEES DE RECONSTRUCTION")
                    appendLine("Nom_video=$safeFolder")
                    appendLine("Nombre_images=$index")
                    appendLine("FPS=${metadata.fps}")
                    appendLine("Largeur=${metadata.width}")
                    appendLine("Hauteur=${metadata.height}")
                    appendLine("Resolution=${metadata.width}x${metadata.height}")
                    appendLine("Format_conteneur_MIME=$containerMime")
                    appendLine("Codec_video_MIME=${metadata.mime}")
                    appendLine("Duree_ms=${metadata.durationMs}")
                    appendLine("Duree_secondes=${String.format(Locale.US, "%.3f", metadata.durationMs / 1000.0)}")
                    appendLine("FPS_declare=${metadata.fps}")
                    appendLine("FPS_moyen_calcule=${metadata.averageFps}")
                    appendLine("Debit_video_bps=${metadata.bitrate}")
                    appendLine("Profil_codec=${metadata.profile}")
                    appendLine("Niveau_codec=${metadata.level}")
                    appendLine("Couleur_standard=${metadata.colorStandard}")
                    appendLine("Couleur_plage=${metadata.colorRange}")
                    appendLine("Couleur_transfert=${metadata.colorTransfer}")
                    appendLine("Rotation_degres=${metadata.rotation}")
                    appendLine("Qualite_source=Indicateurs disponibles: codec, profil, niveau et debit; la qualite perceptuelle exacte n'est pas mesurable automatiquement")
                    appendLine("Piste_audio_presente=${audioInfo.present}")
                    appendLine("Codec_audio=${audioInfo.description}")
                    appendLine("Audio_frequence_Hz=${audioInfo.sampleRate}")
                    appendLine("Audio_canaux=${audioInfo.channels}")
                    appendLine("Audio_debit_bps=${audioInfo.bitrate}")
                    appendLine("Fichier_audio=${if (audioInfo.file != null) "audio_originale.m4a" else "Aucun fichier audio exporte (codec non compatible ou aucune piste)"}")
                    appendLine("Format_images=JPEG")
                    appendLine("Qualite_JPEG=100")
                    appendLine("Ordre=Numerotation croissante image_000001.jpg...")
                    appendLine("Note=Une reconstruction depuis des JPEG re-encode la video et ne garantit pas une identite binaire avec l'original.")
                }
                zip.putNextEntry(ZipEntry("$safeFolder/metadata.txt"))
                zip.write(report.toByteArray(Charsets.UTF_8))
                zip.closeEntry()

                audioInfo.file?.takeIf { it.exists() && it.length() > 0 }?.let { audio ->
                    zip.putNextEntry(ZipEntry("$safeFolder/audio_originale.m4a"))
                    audio.inputStream().buffered().use { it.copyTo(zip) }
                    zip.closeEntry()
                }
            }
            onProgress(1f)
            index
        } finally {
            extractor.release()
            retriever.release()
            tempAudio.delete()
        }
    }

    private data class VideoInfo(
        val fps: String, val width: Int, val height: Int, val mime: String,
        val durationMs: Long, val bitrate: Int, val rotation: Int,
        val averageFps: String, val profile: String, val level: String,
        val colorStandard: String, val colorRange: String, val colorTransfer: String
    )
    private data class AudioInfo(
        val present: Boolean, val description: String, val file: File?,
        val sampleRate: Int, val channels: Int, val bitrate: Int
    )

    private fun readMetadata(
        retriever: MediaMetadataRetriever, format: MediaFormat, frames: Long, extractor: MediaExtractor
    ): VideoInfo {
        fun meta(key: Int) = retriever.extractMetadata(key)
        val width = meta(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull()
            ?: format.getInteger(MediaFormat.KEY_WIDTH)
        val height = meta(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull()
            ?: format.getInteger(MediaFormat.KEY_HEIGHT)
        val duration = meta(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        val fpsRaw = meta(MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE)?.toFloatOrNull()
        val fpsTrack = if (format.containsKey(MediaFormat.KEY_FRAME_RATE)) format.getInteger(MediaFormat.KEY_FRAME_RATE).toFloat() else null
        val fps = (fpsRaw ?: fpsTrack ?: if (duration > 0) frames * 1000f / duration else 0f)
        val averageFps = if (duration > 0) frames * 1000.0 / duration else fps.toDouble()
        val mime = format.getString(MediaFormat.KEY_MIME) ?: "video/unknown"
        val bitrate = if (format.containsKey(MediaFormat.KEY_BIT_RATE)) format.getInteger(MediaFormat.KEY_BIT_RATE) else
            meta(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toIntOrNull() ?: 0
        val rotation = meta(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
        fun fmt(key: String): String = if (format.containsKey(key)) format.getInteger(key).toString() else "inconnu"
        return VideoInfo(
            String.format(Locale.US, "%.3f", fps), width, height, mime, duration, bitrate, rotation,
            String.format(Locale.US, "%.3f", averageFps), fmt(MediaFormat.KEY_PROFILE), fmt(MediaFormat.KEY_LEVEL),
            fmt(MediaFormat.KEY_COLOR_STANDARD), fmt(MediaFormat.KEY_COLOR_RANGE), fmt(MediaFormat.KEY_COLOR_TRANSFER)
        )
    }

    /** Détecte la piste audio puis la décode/réencode en AAC pour accepter les codecs audio décodables par Android. */
    private suspend fun extractAudioIfPossible(ctx: Context, source: Uri, target: File): AudioInfo {
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(ctx, source, null)
            val audioTrack = (0 until extractor.trackCount).firstOrNull {
                extractor.getTrackFormat(it).getString(MediaFormat.KEY_MIME).orEmpty().startsWith("audio/")
            } ?: return AudioInfo(false, "Aucune piste audio", null, 0, 0, 0)
            val format = extractor.getTrackFormat(audioTrack)
            val mime = format.getString(MediaFormat.KEY_MIME).orEmpty()
            val sampleRate = if (format.containsKey(MediaFormat.KEY_SAMPLE_RATE)) format.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 0
            val channels = if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) format.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 0
            val bitrate = if (format.containsKey(MediaFormat.KEY_BIT_RATE)) format.getInteger(MediaFormat.KEY_BIT_RATE) else 0
            return try {
                VideoOps.extractAudioAsAac(ctx, source, target)
                AudioInfo(true, "$mime → AAC (M4A)", target.takeIf { it.exists() && it.length() > 0 }, sampleRate, channels, bitrate)
            } catch (e: Exception) {
                target.delete()
                AudioInfo(true, "$mime détecté, conversion AAC impossible : ${e.message ?: "erreur"}", null, sampleRate, channels, bitrate)
            }
        } finally { extractor.release() }
    }

    /** Reconstruit le MP4 depuis le ZIP créé par extractAll ; metadata.txt pilote FPS et durée. */
    suspend fun rebuildFromArchive(ctx: Context, archive: Uri, output: File, onProgress: (Float) -> Unit = {}) = withContext(Dispatchers.IO) {
        val temp = File(ctx.cacheDir, "rebuild_${System.nanoTime()}").apply { mkdirs() }
        try {
            ctx.contentResolver.openInputStream(archive)?.use { input ->
                java.util.zip.ZipInputStream(input.buffered()).use { zip ->
                    var entry = zip.nextEntry
                    while (entry != null) {
                        val relative = File(entry.name)
                        require(!relative.isAbsolute && relative.toPath().none { it.toString() == ".." }) { "Archive invalide : chemin interdit." }
                        val target = File(temp, entry.name).canonicalFile
                        require(target.toPath().startsWith(temp.canonicalFile.toPath())) { "Archive invalide : chemin interdit." }
                        if (entry.isDirectory) target.mkdirs() else {
                            target.parentFile?.mkdirs()
                            target.outputStream().buffered().use { zip.copyTo(it) }
                        }
                        zip.closeEntry(); entry = zip.nextEntry
                    }
                }
            } ?: error("Impossible de lire l'archive sélectionnée.")
            val metadataFile = temp.walkTopDown().firstOrNull { it.isFile && it.name.equals("metadata.txt", true) }
                ?: error("metadata.txt est absent. Sélectionnez un paquet extrait par Media Studio.")
            val values = metadataFile.readLines().mapNotNull { line ->
                val i = line.indexOf('='); if (i <= 0) null else line.substring(0, i).trim() to line.substring(i + 1).trim()
            }.toMap()
            val fps = values["FPS_moyen_calcule"]?.toDoubleOrNull() ?: values["FPS_declare"]?.toDoubleOrNull() ?: values["FPS"]?.toDoubleOrNull()
                ?: error("FPS absent ou invalide dans metadata.txt.")
            val duration = values["Duree_ms"]?.toLongOrNull() ?: 0L
            val expected = values["Nombre_images"]?.toIntOrNull()
            val images = temp.walkTopDown().filter { it.isFile && it.extension.equals("jpg", true) }
                .sortedBy { it.name.substringAfterLast('_').substringBeforeLast('.').toLongOrNull() ?: Long.MAX_VALUE }.toList()
            require(images.isNotEmpty()) { "Aucune image JPEG trouvée dans le paquet." }
            if (expected != null) require(images.size == expected) { "Paquet incomplet : ${images.size} images trouvées sur $expected." }
            val audioName = values["Fichier_audio"].orEmpty()
            val audio = if (audioName.isNotBlank() && !audioName.startsWith("Aucun"))
                temp.walkTopDown().firstOrNull { it.isFile && it.name.equals(audioName, true) } else null
            if (values["Piste_audio_presente"] == "true" && audio == null)
                error("La vidéo originale avait une piste audio, mais le fichier audio est absent du dossier.")
            VideoOps.rebuildFromImages(ctx, images, fps, duration, audio, output) { onProgress(it) }
        } finally { temp.deleteRecursively() }
    }

    private fun countSamples(ctx: Context, source: Uri): Long {
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(ctx, source, null)
            val track = findVideoTrack(extractor)
            extractor.selectTrack(track)
            var count = 0L
            while (extractor.sampleTime >= 0) {
                count++
                if (count > MAX_FRAMES) error("La vidéo contient trop d'images (limite : $MAX_FRAMES).")
                if (!extractor.advance()) break
            }
            return count
        } finally { extractor.release() }
    }

    private fun findVideoTrack(extractor: MediaExtractor): Int {
        for (i in 0 until extractor.trackCount) {
            val mime = extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME).orEmpty()
            if (mime.startsWith("video/")) return i
        }
        error("Aucune piste vidéo trouvée dans ce fichier.")
    }
}
