package com.mediastudio.app

import android.content.Context
import android.content.res.AssetManager
import android.graphics.Typeface

/**
 * Polices embarquées (assets/fonts) dont les chasses sont identiques à celles de Word :
 *  Carlito = Calibri, Caladea = Cambria, Liberation Sans = Arial, Liberation Serif = Times New Roman, Liberation Mono = Courier New.
 * Sans elles, les retours à la ligne et le nombre de pages d'un .docx ne peuvent pas être respectés.
 */
internal object FontKit {
    enum class Fam(val file: String, val lineFix: Float) {
        CARLITO("Carlito", 1f),
        CALADEA("Caladea", 1f),
        SANS("LiberationSans", 1.029f),   // Word ajoute l'interligne (lineGap) de la police
        SERIF("LiberationSerif", 1.037f),
        MONO("LiberationMono", 1f),
    }

    private var assets: AssetManager? = null
    private val cache = HashMap<String, Typeface>()

    fun init(ctx: Context) { assets = ctx.applicationContext.assets }

    fun family(name: String?): Fam {
        val n = (name ?: "").lowercase()
        return when {
            n.isEmpty() -> Fam.CARLITO
            "calibri" in n || "carlito" in n || "aptos" in n -> Fam.CARLITO
            "cambria" in n || "caladea" in n -> Fam.CALADEA
            "courier" in n || "consolas" in n || "mono" in n || "lucida console" in n -> Fam.MONO
            "times" in n || "georgia" in n || "garamond" in n || "palatino" in n || "book antiqua" in n ||
                "minion" in n || ("serif" in n && "sans" !in n) -> Fam.SERIF
            else -> Fam.SANS // Arial, Helvetica, Verdana, Tahoma, Segoe UI…
        }
    }

    fun typeface(fam: Fam, bold: Boolean, italic: Boolean): Typeface {
        val style = (if (bold) "Bold" else "") + (if (italic) "Italic" else "")
        val key = fam.file + style
        return cache.getOrPut(key) {
            val file = "fonts/${fam.file}-${style.ifEmpty { "Regular" }}.ttf"
            runCatching { Typeface.createFromAsset(assets, file) }.getOrNull()
                ?: Typeface.create(
                    when (fam) { Fam.SERIF, Fam.CALADEA -> Typeface.SERIF; Fam.MONO -> Typeface.MONOSPACE; else -> Typeface.SANS_SERIF },
                    (if (bold) Typeface.BOLD else 0) or (if (italic) Typeface.ITALIC else 0),
                )
        }
    }
}
