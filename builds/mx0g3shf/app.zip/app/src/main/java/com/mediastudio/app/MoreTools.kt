package com.mediastudio.app

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.Alignment
import androidx.compose.material3.TextButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.unit.dp
import androidx.media3.common.util.UnstableApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Outils de Media Studio qui n'étaient jusqu'ici utilisables que depuis LinkShare (routeur) :
 * pivoter / miroir, vitesse, volume, retirer le son, capture d'image, images de la vidéo,
 * conversion d'images, images → PDF, Word ↔ PDF, texte → PDF. Mêmes fonctions que le routeur.
 */

private fun displayName(ctx: Context, uri: Uri): String? = runCatching {
    ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
        if (it.moveToFirst()) it.getString(0) else null
    }
}.getOrNull()

private fun baseName(ctx: Context, uri: Uri): String {
    val raw = displayName(ctx, uri) ?: "media"
    return raw.substringBeforeLast('.').replace(Regex("[^A-Za-z0-9_-]"), "_").take(40).ifBlank { "media" }
}

private suspend fun loadClip(ctx: Context, uri: Uri): Clip {
    val c = withContext(Dispatchers.IO) { Clip.from(ctx, uri) }
    if (c.durationMs <= 0) error("Durée du média illisible")
    return c
}

@Composable
private fun PickButton(label: String, mimes: Array<String>, picked: Boolean, onPick: (Uri) -> Unit) {
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> u?.let(onPick) }
    Button({ pick.launch(mimes) }) { Text(if (picked) "$label ✓" else label) }
}

@UnstableApi
@Composable
internal fun PivotTool() {
    val r = rememberRunner()
    var src by remember { mutableStateOf<Uri?>(null) }
    var deg by remember { mutableIntStateOf(90) }
    var flip by remember { mutableStateOf(false) }
    PickButton("Choisir une vidéo", arrayOf("video/*"), src != null) { src = it }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(0, 90, 180, 270).forEach { FilterChip(deg == it, { deg = it }, label = { Text("$it°") }) }
    }
    Row { Switch(flip, { flip = it }); Spacer(Modifier.width(8.dp)); Text("Miroir horizontal") }
    Button(enabled = src != null && !r.busy && (deg != 0 || flip), onClick = {
        val u = src!!; val d = deg; val f = flip
        r.run("${baseName(r.ctx, u)}_pivot_${stamp()}.mp4", "video/mp4") { out, rep ->
            VideoOps.transform(r.ctx, loadClip(r.ctx, u), out, d, f, rep)
        }
    }) { Text("Appliquer") }
    Status(r)
}

@UnstableApi
@Composable
internal fun SpeedTool() {
    val r = rememberRunner()
    var src by remember { mutableStateOf<Uri?>(null) }
    var speed by remember { mutableFloatStateOf(2f) }
    PickButton("Choisir une vidéo", arrayOf("video/*"), src != null) { src = it }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(0.25f, 0.5f, 2f, 4f).forEach { FilterChip(speed == it, { speed = it }, label = { Text("×$it") }) }
    }
    Text("Vitesse : ×%.2f (%s)".format(speed, if (speed < 1f) "ralenti" else "accéléré"))
    Slider(speed, { speed = it }, valueRange = 0.25f..4f)
    Button(enabled = src != null && !r.busy, onClick = {
        val u = src!!; val sp = speed
        r.run("${baseName(r.ctx, u)}_x${sp}_${stamp()}.mp4".replace(',', '_'), "video/mp4") { out, rep ->
            VideoOps.speed(r.ctx, loadClip(r.ctx, u), out, sp, rep)
        }
    }) { Text("Changer la vitesse") }
    Status(r)
}

@UnstableApi
@Composable
internal fun VolumeTool() {
    val r = rememberRunner()
    var src by remember { mutableStateOf<Uri?>(null) }
    var vol by remember { mutableFloatStateOf(1.5f) }
    PickButton("Choisir une vidéo ou un audio", arrayOf("video/*", "audio/*"), src != null) { src = it }
    Text("Volume : ${(vol * 100).toInt()} %")
    Slider(vol, { vol = it }, valueRange = 0f..3f)
    Button(enabled = src != null && !r.busy, onClick = {
        val u = src!!; val v = vol
        val audio = r.ctx.contentResolver.getType(u).orEmpty().startsWith("audio/")
        val ext = if (audio) "m4a" else "mp4"
        r.run("${baseName(r.ctx, u)}_volume_${stamp()}.$ext", if (audio) "audio/mp4" else "video/mp4") { out, rep ->
            VideoOps.volume(r.ctx, loadClip(r.ctx, u), out, v, rep)
        }
    }) { Text("Régler le volume") }
    Status(r)
}

@UnstableApi
@Composable
internal fun MuteTool() {
    val r = rememberRunner()
    var src by remember { mutableStateOf<Uri?>(null) }
    PickButton("Choisir une vidéo", arrayOf("video/*"), src != null) { src = it }
    Button(enabled = src != null && !r.busy, onClick = {
        val u = src!!
        r.run("${baseName(r.ctx, u)}_muet_${stamp()}.mp4", "video/mp4") { out, rep ->
            VideoOps.mute(r.ctx, loadClip(r.ctx, u), out, rep)
        }
    }) { Text("Retirer le son") }
    Status(r)
}

@Composable
@UnstableApi
internal fun FrameTool() {
    val r = rememberRunner()
    var src by remember { mutableStateOf<Uri?>(null) }
    var durationMs by remember { mutableStateOf(0L) }
    var atMs by remember { mutableFloatStateOf(0f) }
    val ctx = r.ctx
    PickButton("Choisir une vidéo", arrayOf("video/*"), src != null) { u ->
        src = u
        durationMs = runCatching { Clip.from(ctx, u).durationMs }.getOrDefault(0L)
        atMs = durationMs / 2f
    }
    if (durationMs > 0) {
        Text("Instant : ${fmtTime(atMs.toLong())} / ${fmtTime(durationMs)}")
        Slider(atMs, { atMs = it }, valueRange = 0f..durationMs.toFloat())
    }
    Button(enabled = src != null && !r.busy, onClick = {
        val u = src!!; val t = atMs.toLong()
        r.run("${baseName(r.ctx, u)}_image_${stamp()}.jpg", "image/jpeg") { out, rep ->
            MediaFrame.extract(r.ctx, u, t, out, rep)
        }
    }) { Text("Enregistrer l'image (JPG)") }
    Status(r)
}

@UnstableApi
@Composable
internal fun FramesTool() {
    val r = rememberRunner()
    var video by remember { mutableStateOf<Uri?>(null) }
    var zip by remember { mutableStateOf<Uri?>(null) }
    PickButton("Choisir une vidéo", arrayOf("video/*"), video != null) { video = it }
    Button(enabled = video != null && !r.busy, onClick = {
        val u = video!!; val base = baseName(r.ctx, u)
        r.run("${base}_nombre_images.txt", "text/plain") { out, rep ->
            val n = VideoFrameOps.count(r.ctx, u)
            out.writeText("Vidéo : $base\nNombre d'images (frames vidéo) : $n\n")
            rep(1f)
        }
    }) { Text("Compter les images") }
    Button(enabled = video != null && !r.busy, onClick = {
        val u = video!!; val base = baseName(r.ctx, u)
        r.run("${base}_images.zip", "application/zip") { out, rep ->
            if (VideoFrameOps.extractAll(r.ctx, u, base, out, rep) <= 0) error("Aucune image extraite.")
        }
    }) { Text("Extraire toutes les images (ZIP)") }
    Text("Reconstruire une vidéo à partir d'un paquet ZIP créé ci-dessus :")
    PickButton("Choisir le paquet ZIP", arrayOf("application/zip", "application/octet-stream"), zip != null) { zip = it }
    Button(enabled = zip != null && !r.busy, onClick = {
        val z = zip!!
        r.run("${baseName(r.ctx, z)}_reconstruit.mp4", "video/mp4") { out, rep ->
            VideoFrameOps.rebuildFromArchive(r.ctx, z, out, rep)
        }
    }) { Text("Reconstruire la vidéo") }
    Status(r)
}

@Composable
@UnstableApi
internal fun ImageTool() {
    val r = rememberRunner()
    var src by remember { mutableStateOf<Uri?>(null) }
    var format by remember { mutableStateOf("JPG") }
    var quality by remember { mutableFloatStateOf(85f) }
    var maxSide by remember { mutableIntStateOf(2048) }
    PickButton("Choisir une image", arrayOf("image/*"), src != null) { src = it }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("JPG", "PNG", "WEBP").forEach { FilterChip(format == it, { format = it }, label = { Text(it) }) }
    }
    if (format != "PNG") {
        Text("Qualité : ${quality.toInt()} %")
        Slider(quality, { quality = it }, valueRange = 30f..100f)
    }
    Text("Taille max (côté le plus long) :")
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(1080, 2048, 4096, 6000).forEach { FilterChip(maxSide == it, { maxSide = it }, label = { Text("$it") }) }
    }
    Button(enabled = src != null && !r.busy, onClick = {
        val u = src!!; val f = format; val q = quality.toInt(); val m = maxSide
        val (ext, mime) = when (f) { "PNG" -> "png" to "image/png"; "WEBP" -> "webp" to "image/webp"; else -> "jpg" to "image/jpeg" }
        r.run("${baseName(r.ctx, u)}_${stamp()}.$ext", mime) { out, rep ->
            ImageOps.convert(r.ctx, u, out, f, q, m, rep)
        }
    }) { Text("Convertir / compresser") }
    Status(r)
}

@Composable
@UnstableApi
internal fun ImagesPdfTool() {
    val r = rememberRunner()
    var images by remember { mutableStateOf(listOf<Uri>()) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { list -> images = images + list }
    Button({ pick.launch(arrayOf("image/*")) }) { Text(if (images.isEmpty()) "Ajouter des images" else "Ajouter d'autres images (${images.size})") }
    if (images.isNotEmpty()) androidx.compose.material3.TextButton({ images = emptyList() }) { Text("Vider la liste") }
    Button(enabled = images.isNotEmpty() && !r.busy, onClick = {
        val list = images
        r.run("images_${stamp()}.pdf", "application/pdf") { out, rep ->
            DocConverters.imagesToPdf(r.ctx, list, out, rep)
        }
    }) { Text("Créer le PDF") }
    Status(r)
}

@Composable
@UnstableApi
internal fun DocTool(
    pickLabel: String, mimes: Array<String>, runLabel: String, ext: String, outMime: String,
    convert: suspend (Context, Uri, java.io.File, (Float) -> Unit) -> Unit,
) {
    val r = rememberRunner()
    var src by remember { mutableStateOf<Uri?>(null) }
    PickButton(pickLabel, mimes, src != null) { src = it }
    Button(enabled = src != null && !r.busy, onClick = {
        val u = src!!
        r.run("${baseName(r.ctx, u)}_${stamp()}.$ext", outMime) { out, rep -> convert(r.ctx, u, out, rep) }
    }) { Text(runLabel) }
    Status(r)
}

/** Une ou plusieurs vidéos (MKV, AVI, WebM, MOV, TS…) converties en MP4. */
@UnstableApi
@Composable
internal fun ToMp4Tool() {
    val r = rememberRunner()
    var videos by remember { mutableStateOf(listOf<Pair<Uri, String>>()) }
    var mode by remember { mutableStateOf(Mp4Mode.AUTO) }
    var allowMute by remember { mutableStateOf(false) }
    var warning by remember { mutableStateOf<String?>(null) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { list ->
        val added = list.map { it to (displayName(r.ctx, it) ?: "vidéo") }
        val valid = added.filter { (u, n) -> Mp4Plan.isVideo(r.ctx.contentResolver.getType(u).orEmpty(), n) }
        val all = (videos + valid).distinctBy { it.first }
        videos = all.take(Mp4Plan.MAX_FILES)
        warning = when {
            all.size > Mp4Plan.MAX_FILES -> "Maximum ${Mp4Plan.MAX_FILES} vidéos par lot."
            valid.size < added.size -> "${added.size - valid.size} fichier(s) ignoré(s) : ce ne sont pas des vidéos."
            else -> null
        }
    }
    // « application/octet-stream » : certains téléphones ne reconnaissent pas les MKV, TS ou VOB comme des vidéos
    Button({ pick.launch(arrayOf("video/*", "application/octet-stream")) }) {
        Text(if (videos.isEmpty()) "Choisir des vidéos" else "Ajouter d'autres vidéos (${videos.size})")
    }
    Text("Appui long sur une vidéo pour en sélectionner plusieurs.", style = MaterialTheme.typography.bodySmall)
    warning?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    videos.forEach { (u, n) ->
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(n, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
            TextButton({ videos = videos.filterNot { it.first == u } }) { Text("✕") }
        }
    }
    if (videos.isNotEmpty()) TextButton({ videos = emptyList(); warning = null }) { Text("Vider la liste") }
    Mp4Settings(mode, { mode = it }, allowMute, { allowMute = it })
    Button(enabled = videos.isNotEmpty() && !r.busy, onClick = {
        val list = videos.map { it.first }
        r.runBatch(
            if (list.size > 1) "Conversion MP4 (${list.size} vidéos)" else "Conversion MP4", "video/mp4",
            Mp4Batch(r.ctx, list, mode, allowMute, null),
        )
    }) { Text(if (videos.size > 1) "Convertir ${videos.size} vidéos en MP4" else "Convertir en MP4") }
    Status(r)
}

/** Réglages partagés entre l'onglet « Vidéo→MP4 » et l'écran piloté par LinkShare. */
@Composable
internal fun Mp4Settings(mode: Mp4Mode, onMode: (Mp4Mode) -> Unit, allowMute: Boolean, onAllowMute: (Boolean) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Mp4Mode.entries.forEach { FilterChip(mode == it, { onMode(it) }, label = { Text(it.label) }) }
    }
    Text(mode.help, style = MaterialTheme.typography.bodySmall)
    Row(verticalAlignment = Alignment.CenterVertically) {
        Switch(allowMute, onAllowMute)
        Spacer(Modifier.width(8.dp))
        Text("Si le son est inconvertible, créer la vidéo sans le son", style = MaterialTheme.typography.bodySmall)
    }
}

/** Liste du lot + réglages, affichée dans la carte flottante du routeur. */
@Composable
internal fun Mp4Options(
    names: List<String>, mode: Mp4Mode, onMode: (Mp4Mode) -> Unit, allowMute: Boolean, onAllowMute: (Boolean) -> Unit,
) {
    Text(if (names.size > 1) "${names.size} vidéos à convertir" else "Vidéo à convertir", style = MaterialTheme.typography.labelLarge)
    names.take(5).forEach {
        Text(it, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
    if (names.size > 5) Text("… et ${names.size - 5} autre(s)", style = MaterialTheme.typography.bodySmall)
    Mp4Settings(mode, onMode, allowMute, onAllowMute)
}
