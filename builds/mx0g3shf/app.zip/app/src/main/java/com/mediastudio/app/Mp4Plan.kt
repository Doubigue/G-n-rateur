package com.mediastudio.app

/**
 * Logique « Convertir en MP4 » sans aucune dépendance Android : formats reconnus, ordre des essais,
 * mixage stéréo et résumé du lot. [Mp4Converter] l'applique avec Media3 Transformer.
 */

/** AUTO : copie sans réencodage quand l'image est déjà en H.264 / H.265. H264 : lisible partout. */
enum class Mp4Mode(val label: String, val help: String) {
    AUTO("Rapide", "L'image H.264 / H.265 est copiée sans perte ; les autres formats sont réencodés en H.264."),
    H264("Compatible partout", "L'image est mise en H.264 (réencodage seulement si elle est dans un autre format).");

    companion object {
        fun of(name: String?): Mp4Mode = entries.firstOrNull { it.name.equals(name, ignoreCase = true) } ?: AUTO
    }
}

/** Ce qu'on a pu lire de la source ; tout est facultatif (certains conteneurs ne sont pas analysables). */
data class SourceInfo(
    val videoMime: String? = null,
    val audioMime: String? = null,
    val audioChannels: Int = 0,
    val durationUs: Long = 0,
)

/** Un essai de conversion. [videoMime] null = garder le format d'image d'origine. */
data class Mp4Attempt(val videoMime: String?, val forceVideoEncode: Boolean, val removeAudio: Boolean)

object Mp4Plan {
    const val H264 = "video/avc"
    const val H265 = "video/hevc"
    const val AAC = "audio/mp4a-latm"
    const val MAX_FILES = 50

    val VIDEO_EXTENSIONS = setOf(
        "mp4", "mkv", "webm", "mov", "avi", "m4v", "3gp", "3g2", "ts", "mts", "m2ts", "flv", "mpg", "mpeg",
        "vob", "ogv", "wmv", "asf", "rm", "rmvb",
    )

    /** Conteneurs que Media3 ne sait pas ouvrir : on le dit tout de suite, sans essai inutile. */
    private val UNREADABLE = setOf("wmv", "asf", "rm", "rmvb")

    fun extensionOf(name: String): String = name.substringAfterLast('.', "").lowercase()

    fun isVideo(mime: String, name: String): Boolean =
        mime.startsWith("video/") || extensionOf(name) in VIDEO_EXTENSIONS

    fun unsupportedReason(name: String): String? {
        val ext = extensionOf(name)
        return if (ext in UNREADABLE) "format ${ext.uppercase()} non pris en charge" else null
    }

    /** Essais dans l'ordre : le plus rapide d'abord, puis réencodage complet, puis (si autorisé) sans le son. */
    fun attempts(mode: Mp4Mode, info: SourceInfo, allowMute: Boolean): List<Mp4Attempt> {
        val keepVideo = mode == Mp4Mode.AUTO && (info.videoMime == H264 || info.videoMime == H265)
        val withSound = listOf(
            Mp4Attempt(if (keepVideo) null else H264, forceVideoEncode = false, removeAudio = false),
            Mp4Attempt(H264, forceVideoEncode = true, removeAudio = false),
        )
        return if (allowMute) withSound + withSound.map { it.copy(removeAudio = true) } else withSound
    }

    /**
     * Matrice de mixage vers la stéréo (lignes = canaux d'entrée, colonnes = gauche, droite) pour 3 à 8 canaux,
     * ordre Android : FL, FR, FC, LFE, BL, BR, SL, SR. Les gains sont normalisés pour éviter la saturation.
     */
    fun stereoCoefficients(channels: Int): FloatArray {
        require(channels in 3..8)
        val half = 0.707f
        val rows: List<Pair<Float, Float>> = when (channels) {
            3 -> listOf(1f to 0f, 0f to 1f, half to half)
            4 -> listOf(1f to 0f, 0f to 1f, half to 0f, 0f to half)
            5 -> listOf(1f to 0f, 0f to 1f, half to half, half to 0f, 0f to half)
            else -> listOf(1f to 0f, 0f to 1f, half to half, 0f to 0f) + when (channels) {
                6 -> listOf(half to 0f, 0f to half)
                7 -> listOf(half to 0f, 0f to half, 0.5f to 0.5f)
                else -> listOf(half to 0f, 0f to half, half to 0f, 0f to half)
            }
        }
        val gain = 1f / maxOf(rows.sumOf { it.first.toDouble() }, rows.sumOf { it.second.toDouble() }).toFloat()
        return FloatArray(channels * 2) { i -> (if (i % 2 == 0) rows[i / 2].first else rows[i / 2].second) * gain }
    }

    /** Résumé affiché à la fin (et renvoyé à LinkShare). [failures] : « nom : raison ». */
    fun summary(total: Int, done: Int, muted: Int, failures: List<String>, cancelled: Boolean): String = buildString {
        append(
            when {
                total == 1 && done == 1 -> "Vidéo convertie en MP4"
                done == total -> "$done vidéos converties en MP4"
                else -> "$done sur $total converties en MP4"
            }
        )
        if (cancelled) append(" (arrêté avant la fin)")
        if (muted > 0) append("\nSans le son : $muted")
        if (failures.isNotEmpty()) {
            append("\nÉchecs : ${failures.size}")
            failures.take(3).forEach { append("\n• ").append(it) }
            if (failures.size > 3) append("\n• … et ${failures.size - 3} autre(s)")
        }
    }
}
