package com.mediastudio.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.File

/** Un des fichiers produits par un traitement par lot. */
data class BatchOutput(val uri: Uri, val name: String)

/** Traitement qui produit plusieurs fichiers et les enregistre lui-même, au fur et à mesure. */
interface BatchWork {
    /** Fichiers déjà enregistrés (se remplit pendant le traitement). */
    val outputs: List<BatchOutput>
    /** Échoue (exception) seulement si aucun fichier n'a pu être produit. */
    suspend fun run(onStage: (String) -> Unit, onProgress: (Float) -> Unit)
    fun summary(cancelled: Boolean): String
}

/** Pont entre l'interface et le service : file d'attente d'un export + état observable. */
object ExportManager {
    data class State(
        val busy: Boolean = false, val progress: Float = 0f, val status: String = "",
        /** Renseigné à la fin d'un export réussi (URI MediaStore du fichier produit). */
        val outputUri: Uri? = null,
        /** Renseigné si l'export a échoué ou a été interrompu. */
        val error: String? = null,
        val cancelled: Boolean = false,
        val outputName: String? = null,
        val outputMime: String? = null,
        val outputLocation: String? = null,
        val outputSummary: String? = null,
        /** Traitement par lot : tous les fichiers produits ([outputUri] est le premier). */
        val outputs: List<BatchOutput> = emptyList()
    )

    class Job(
        /** Modifiable avant le lancement (nom choisi par l'utilisateur dans le routeur). */
        var name: String, val mime: String,
        val block: suspend (File, (Float) -> Unit) -> Unit,
        val destinationTreeUri: Uri? = null,
        /** Appelé (thread principal) avec l'URI du fichier enregistré, avant la mise à jour de l'état. */
        val onSaved: ((Uri) -> Unit)? = null,
        /** Non nul : traitement par lot ; [block] n'est alors pas utilisé. */
        val batch: BatchWork? = null,
    ) {
        /** Résumé renvoyé à l'appelant (LinkShare) ; le bloc peut le renseigner pendant le traitement. */
        @Volatile var summary: String? = null
        /** Libellé de l'étape en cours affiché sous la barre de progression (« Transcription… »). */
        @Volatile var stage: String = "En cours…"
    }

    val state = MutableStateFlow(State())
    @Volatile var pending: Job? = null

    /** Tâche Android qui contient l'écran du routeur (celle de LinkShare) ; -1 si aucun écran n'est ouvert. */
    @Volatile var routerTaskId: Int = -1

    fun start(ctx: Context, job: Job) {
        if (state.value.busy) return
        pending = job
        state.value = State(busy = true, status = "En cours…")
        ContextCompat.startForegroundService(ctx, Intent(ctx, ExportService::class.java))
    }
}
