package com.mediastudio.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.SpannableStringBuilder
import android.text.Spanned
import java.io.File
import java.util.zip.ZipFile
import kotlin.math.roundToInt

/**
 * Word (.docx) → PDF, hors-ligne. La page garde la taille et les marges du document ; les styles (police, taille,
 * couleur, interlignes, retraits, numérotation), tableaux, images, zones de texte, en-têtes et pieds de page sont respectés.
 * Polices : Carlito/Caladea/Liberation (mêmes chasses que Calibri/Cambria/Arial/Times/Courier) pour garder les mêmes sauts de ligne.
 */
internal object WordToPdf {

    fun fromDocx(file: File, output: File, onProgress: (Float) -> Unit) {
        ZipFile(file).use { zip ->
            val b = DocxBuilder(zip)
            render(b.read(), b, output, onProgress)
        }
    }

    fun fromText(text: String, output: File, onProgress: (Float) -> Unit) {
        val tf = FontKit.typeface(FontKit.Fam.SANS, false, false)
        val blocks = ArrayList<WB>()
        blocks.add(WB.Section(Geo.A4))
        text.replace("\r\n", "\n").split('\n').forEach { line ->
            val sb = SpannableStringBuilder(line.ifEmpty { " " }.replace("\t", "    "))
            sb.setSpan(RunSpan(tf, 11f, Color.BLACK, false, false, null, 0), 0, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            blocks.add(
                WB.Para(
                    sb, Layout.Alignment.ALIGN_NORMAL, false, 0f, 0f, FontKit.Fam.SANS.lineFix, 0f, 0f, 0f,
                    null, tf, 11f, Color.BLACK, null, false, false, false, null, tf, 11f, emptyList(),
                ),
            )
        }
        render(blocks, null, output, onProgress)
    }

    private fun render(blocks: List<WB>, b: DocxBuilder?, output: File, onProgress: (Float) -> Unit) {
        // 1re passe : compte les pages (pour « page X sur Y »)
        val first = Pager(null, b, 0) { onProgress(0.45f * it) }
        first.run(blocks)
        val total = first.pageNo
        val doc = PdfDocument()
        try {
            val pager = Pager(doc, b, total) { onProgress(0.45f + 0.55f * it) }
            pager.run(blocks)
            if (doc.pages.isEmpty()) error("Document vide")
            output.outputStream().use { doc.writeTo(it) }
        } finally { doc.close() }
    }

    private class Pager(
        private val doc: PdfDocument?,
        private val b: DocxBuilder?,
        private val total: Int,
        private val progress: (Float) -> Unit,
    ) {
        var pageNo = 0
        private var page: PdfDocument.Page? = null
        private val dummy = Canvas(Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888))
        private var canvas: Canvas = dummy
        private var geo = Geo.A4
        private var y = 0f
        private var top = 0f
        private var bottom = 0f
        private var needPage = true
        private var autoBreak = false
        private var firstOfSection = true
        private var lastAfter = 0f
        private var lastStyle: String? = null
        private var lastContextual = false
        private val contentW get() = geo.w - geo.left - geo.right
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)

        fun run(blocks: List<WB>) {
            blocks.forEachIndexed { i, blk ->
                when (blk) {
                    is WB.Section -> section(blk.geo)
                    is WB.Para -> para(blk)
                    is WB.Table -> table(blk)
                    WB.PageBreak -> { ensurePage(); newPage(false) }
                }
                progress((i + 1f) / blocks.size)
            }
            closePage()
        }

        // ── Pages
        private fun section(g: Geo) {
            geo = g
            if (needPage) { firstOfSection = true; return }
            if (g.continuous) { top = g.top; bottom = g.h - g.bottom; return }
            firstOfSection = true
            newPage(false)
        }

        private fun newPage(auto: Boolean) { closePage(); needPage = true; autoBreak = auto }

        private fun closePage() {
            page?.let { doc?.finishPage(it) }
            page = null
        }

        private fun ensurePage() {
            if (!needPage) return
            needPage = false
            pageNo++
            page = doc?.startPage(PdfDocument.PageInfo.Builder(geo.w.roundToInt(), geo.h.roundToInt(), pageNo).create())
            canvas = page?.canvas ?: dummy
            canvas.drawColor(Color.WHITE)
            top = geo.top; bottom = geo.h - geo.bottom
            y = top
            lastAfter = 0f; lastStyle = null; lastContextual = false
            val firstPg = geo.titlePg && firstOfSection
            firstOfSection = false
            b?.let { bb ->
                val hdr = bb.headerFooter(if (firstPg) geo.hdrFirst else geo.hdrDefault, pageNo, total)
                var hy = geo.header
                hdr.forEach { hy += drawPara(canvas, it, geo.left, hy, contentW) }
                if (hdr.isNotEmpty()) top = maxOf(top, hy)
                val ftr = bb.headerFooter(if (firstPg) geo.ftrFirst else geo.ftrDefault, pageNo, total)
                if (ftr.isNotEmpty()) {
                    var fh = 0f
                    ftr.forEach { fh += it.before + it.layout(contentW).height + it.after }
                    var fy = geo.h - geo.footer - fh
                    ftr.forEach { fy += drawPara(canvas, it, geo.left, fy, contentW) }
                    bottom = minOf(bottom, geo.h - geo.footer - fh)
                }
                y = top
            }
        }

        // ── Paragraphes
        private fun para(p: WB.Para) {
            ensurePage()
            if (p.pageBreakBefore && y > top + 1f) { newPage(false); ensurePage() }
            var before = p.before
            if (autoBreak && y <= top + 0.5f) before = 0f // Word supprime l'espace avant en haut de page après un saut automatique
            if (p.contextual && lastContextual && lastStyle == p.styleId) { y -= lastAfter; before = 0f }
            val l = p.layout(contentW)
            val total = l.height.toFloat()
            if (p.keepNext && y + before + total + 30f > bottom && y > top + 1f && total < (bottom - top) * 0.5f) {
                newPage(true); ensurePage(); before = 0f
            }
            y += before
            val paraTop = y
            p.floats.filter { it.behind }.forEach { drawFloat(it, paraTop) }

            var line = 0
            val n = l.lineCount
            while (line < n) {
                val avail = bottom - y
                var last = line - 1
                while (last + 1 < n && l.getLineBottom(last + 1) - l.getLineTop(line) <= avail) last++
                if (last < line) {
                    if (y > top + 1f) { newPage(true); ensurePage(); continue } else last = line // ligne plus haute que la page
                } else if (last < n - 1) {
                    val shown = last - line + 1
                    if (line == 0 && shown == 1 && n > 2) { newPage(true); ensurePage(); continue } // ligne orpheline
                    if (n - 1 - last == 1 && shown >= 3) last-- // ligne veuve
                }
                drawLines(l, line, last, p)
                y += (l.getLineBottom(last) - l.getLineTop(line)).toFloat()
                line = last + 1
                if (line < n) { newPage(true); ensurePage() }
            }
            p.floats.filter { !it.behind }.forEach { drawFloat(it, paraTop) }
            y += p.after
            lastAfter = p.after; lastStyle = p.styleId; lastContextual = p.contextual
            autoBreak = false
        }

        private fun drawLines(l: android.text.StaticLayout, from: Int, to: Int, p: WB.Para) {
            val tTop = l.getLineTop(from)
            val tBot = l.getLineBottom(to)
            p.shade?.let {
                fill.color = it; fill.style = Paint.Style.FILL
                canvas.drawRect(geo.left, y, geo.left + contentW - p.right, y + (tBot - tTop), fill)
            }
            canvas.save()
            canvas.translate(geo.left, y - tTop)
            canvas.clipRect(-20f, tTop.toFloat(), contentW + 20f, tBot.toFloat())
            l.draw(canvas)
            canvas.restore()
            if (from == 0) drawLabel(canvas, p, l, geo.left, y - tTop)
        }

        private fun drawLabel(c: Canvas, p: WB.Para, l: android.text.StaticLayout, x: Float, y0: Float) {
            val lab = p.label ?: return
            if (lab.isEmpty()) return
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = p.labelTf; textSize = p.labelSize; color = p.labelColor }
            c.drawText(lab, x + (p.left + p.first).coerceAtLeast(0f), y0 + l.getLineBaseline(0), paint)
        }

        /** Dessine un paragraphe entier (en-têtes, cellules, zones de texte) ; renvoie sa hauteur avec espacements. */
        private fun drawPara(c: Canvas, p: WB.Para, x: Float, y0: Float, w: Float): Float {
            val l = p.layout(w)
            val yy = y0 + p.before
            p.shade?.let {
                fill.color = it; fill.style = Paint.Style.FILL
                c.drawRect(x, yy, x + w - p.right, yy + l.height, fill)
            }
            c.save(); c.translate(x, yy); l.draw(c); c.restore()
            drawLabel(c, p, l, x, yy)
            return p.before + l.height + p.after
        }

        // ── Objets flottants (images ancrées, zones de texte)
        private fun drawFloat(f: FloatItem, paraY: Float) {
            val baseX = if (f.relH == "page") 0f else geo.left
            val baseW = if (f.relH == "page") geo.w else contentW
            var x = baseX + f.x
            when (f.alignH) { "center" -> x = baseX + (baseW - f.w) / 2; "right" -> x = baseX + baseW - f.w; "left" -> x = baseX }
            val baseY = when (f.relV) { "page" -> 0f; "paragraph", "line" -> paraY; else -> geo.top }
            val baseH = if (f.relV == "page") geo.h else geo.h - geo.top - geo.bottom
            var yy = baseY + f.y
            when (f.alignV) { "center" -> yy = baseY + (baseH - f.h) / 2; "bottom" -> yy = baseY + baseH - f.h; "top" -> yy = baseY }
            f.bmp?.let { canvas.drawBitmap(it, null, RectF(x, yy, x + f.w, yy + f.h), bmpPaint) }
            f.box?.let { paras ->
                var cy = yy + f.insT
                for (q in paras) cy += drawPara(canvas, q, x + f.insL, cy, f.w - 2 * f.insL)
            }
        }

        // ── Tableaux
        private fun table(t: WB.Table) {
            ensurePage()
            val x0 = geo.left + t.left
            val hs = t.rows.map { rowHeight(it) }
            t.rows.forEachIndexed { ri, row ->
                if (y + hs[ri] > bottom && y > top + 1f) { newPage(true); ensurePage() }
                drawRow(canvas, t, hs, ri, row, x0, y)
                y += hs[ri]
            }
            lastAfter = 0f; lastStyle = null; lastContextual = false
            autoBreak = false
        }

        private fun rowHeight(row: DxRow): Float {
            var h = row.minH
            if (row.exact) return h
            for (c in row.cells) if (!c.vmCont && c.vmSpan == 1) h = maxOf(h, blocksHeight(c.blocks, c.w - 10.8f))
            return h
        }

        private fun blocksHeight(blocks: List<WB>, w: Float): Float {
            var h = 0f
            for (bl in blocks) when (bl) {
                is WB.Para -> h += bl.before + bl.layout(w).height + bl.after
                is WB.Table -> bl.rows.forEach { h += rowHeight(it) }
                else -> {}
            }
            return h
        }

        private fun drawBlocks(c: Canvas, blocks: List<WB>, x: Float, y0: Float, w: Float) {
            var yy = y0
            for (bl in blocks) when (bl) {
                is WB.Para -> yy += drawPara(c, bl, x, yy, w)
                is WB.Table -> {
                    val hs = bl.rows.map { rowHeight(it) }
                    bl.rows.forEachIndexed { ri, r -> drawRow(c, bl, hs, ri, r, x + bl.left, yy); yy += hs[ri] }
                }
                else -> {}
            }
        }

        private fun drawRow(c: Canvas, t: WB.Table, hs: List<Float>, ri: Int, row: DxRow, x0: Float, y0: Float) {
            for (cell in row.cells) {
                if (cell.vmCont) continue
                var h = hs[ri]
                for (k in 1 until cell.vmSpan) h += hs.getOrNull(ri + k) ?: 0f
                val x = x0 + cell.x
                cell.fill?.let {
                    fill.color = it; fill.style = Paint.Style.FILL
                    c.drawRect(x, y0, x + cell.w, y0 + h, fill)
                }
                c.save()
                c.clipRect(x, y0, x + cell.w, y0 + h)
                drawBlocks(c, cell.blocks, x + 5.4f, y0, cell.w - 10.8f)
                c.restore()
                line(c, cell.borders.top, x, y0, x + cell.w, y0)
                line(c, cell.borders.bottom, x, y0 + h, x + cell.w, y0 + h)
                line(c, cell.borders.left, x, y0, x, y0 + h)
                line(c, cell.borders.right, x + cell.w, y0, x + cell.w, y0 + h)
            }
        }

        private fun line(c: Canvas, b: DxBorder?, x1: Float, y1: Float, x2: Float, y2: Float) {
            b ?: return
            fill.color = b.color; fill.style = Paint.Style.STROKE; fill.strokeWidth = b.w
            c.drawLine(x1, y1, x2, y2, fill)
            fill.style = Paint.Style.FILL
        }
    }
}
