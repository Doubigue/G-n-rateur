package com.mediastudio.app

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import androidx.media3.common.util.UnstableApi
import com.mediastudio.app.whisper.Cue
import com.mediastudio.app.whisper.Subtitles
import com.mediastudio.app.whisper.TranscribeOptions
import com.mediastudio.app.whisper.Transcript
import com.mediastudio.app.whisper.WhisperEngine
import com.mediastudio.app.whisper.WhisperModels
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import java.io.File

/** Formats de sortie d'une transcription. */
internal enum class SubFormat(val ext: String, val mime: String, val label: String) {
    SRT("srt", "application/x-subrip", "SRT"),
    TXT("txt", "text/plain", "TXT"),
    VTT("vtt", "text/vtt", "VTT"),
}

/** Fabriques d'ExportManager.Job pour la transcription et l'incrustation (studio et routeur LinkShare). */
@UnstableApi
internal object SubtitleJobs {

    fun safeBase(raw: String, fallback: String = "video"): String =
        raw.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001F]"), "_").trim().take(80).ifEmpty { fallback }

    /**
     * Transcrit [source] et produit le fichier [format] (sortie principale). Si [alsoTxt], la transcription
     * horodatée lisible (.txt) est enregistrée en plus, à côté.
     */
    fun transcribe(
        app: Context, source: Uri, name: String, format: SubFormat, model: WhisperModels.Model,
        options: TranscribeOptions, title: String, destinationTreeUri: Uri? = null, alsoTxt: Boolean = false,
        onCue: (Cue) -> Unit = {}, onResult: (Transcript) -> Unit = {}, onTxtSaved: (Uri) -> Unit = {},
        onSaved: ((Uri) -> Unit)? = null,
    ): ExportManager.Job {
        lateinit var job: ExportManager.Job
        job = ExportManager.Job(name, format.mime, { out, report ->
            job.stage = "Extraction de l'audio…"
            val t = WhisperEngine.transcribe(app, source, model, options, onProgress = { stage, p ->
                job.stage = when (stage) {
                    WhisperEngine.Stage.AUDIO -> "Extraction de l'audio…"
                    WhisperEngine.Stage.MODEL -> "Chargement du modèle ${model.label}…"
                    WhisperEngine.Stage.TRANSCRIBE -> "Transcription hors ligne (Whisper)…"
                }
                report(p)
            }, onCue = onCue)
            if (t.cues.isEmpty()) error("Aucune parole n'a été détectée dans ce fichier.")
            job.stage = "Écriture des fichiers…"
            val txt = Subtitles.toTxt(t.cues, title, t.language, t.model, t.durationMs)
            out.writeText(
                when (format) {
                    SubFormat.SRT -> Subtitles.toSrt(t.cues)
                    SubFormat.VTT -> Subtitles.toVtt(t.cues)
                    SubFormat.TXT -> txt
                }
            )
            if (alsoTxt && format != SubFormat.TXT) {
                val txtName = job.name.substringBeforeLast('.') + ".txt"
                val f = File(app.cacheDir, txtName)
                try {
                    f.writeText(txt)
                    onTxtSaved(Saver.save(app, f, txtName, SubFormat.TXT.mime, destinationTreeUri))
                } finally { f.delete() }
            }
            job.summary = "${t.cues.size} sous-titres · ${Subtitles.languageLabel(t.language)} · ${Subtitles.short(t.durationMs)}"
            onResult(t)
        }, destinationTreeUri, onSaved)
        return job
    }

    /** Incruste [cues] dans la vidéo avec [style]. */
    fun burn(
        app: Context, video: Uri, cues: List<Cue>, style: SubtitleStyle, name: String,
        destinationTreeUri: Uri? = null, onSaved: ((Uri) -> Unit)? = null,
    ): ExportManager.Job {
        lateinit var job: ExportManager.Job
        job = ExportManager.Job(name, "video/mp4", { out, report ->
            job.stage = "Incrustation des sous-titres…"
            SubtitleBurner.burn(app, video, cues, style, out, report)
            job.summary = "${cues.size} sous-titres incrustés"
        }, destinationTreeUri, onSaved)
        return job
    }
}

/**
 * État du studio sous-titres. Vit au niveau de l'appli : le travail tourne dans ExportService et
 * l'écran peut être recréé (rotation, retour dans l'appli) sans rien perdre.
 */
@UnstableApi
internal object SubtitleSession {

    enum class Phase { EMPTY, READY, TRANSCRIBING, REVIEW, BURNING, BURNED }

    data class Source(
        val uri: Uri, val name: String, val base: String, val durationMs: Long,
        val width: Int, val height: Int, val hasVideo: Boolean,
    )

    val source = MutableStateFlow<Source?>(null)
    val phase = MutableStateFlow(Phase.EMPTY)
    val cues = MutableStateFlow<List<Cue>>(emptyList())
    val options = MutableStateFlow(TranscribeOptions())
    val style = MutableStateFlow(SubtitleStyle())
    val language = MutableStateFlow("")
    val modelName = MutableStateFlow("")
    val srtUri = MutableStateFlow<Uri?>(null)
    val txtUri = MutableStateFlow<Uri?>(null)
    val burnedUri = MutableStateFlow<Uri?>(null)
    val message = MutableStateFlow<String?>(null)

    fun open(ctx: Context, uri: Uri) {
        val name = runCatching {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { if (it.moveToFirst()) it.getString(0) else null }
        }.getOrNull() ?: "media"
        var duration = 0L
        var hasVideo = false
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, uri)
            duration = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            hasVideo = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO) == "yes"
        } catch (_: Exception) {
        } finally { r.release() }
        val (w, h) = if (hasVideo) SubtitleBurner.displaySize(ctx, uri) else 0 to 0
        source.value = Source(uri, name, SubtitleJobs.safeBase(name.substringBeforeLast('.')), duration, w, h, hasVideo && w > 0)
        cues.value = emptyList()
        srtUri.value = null; txtUri.value = null; burnedUri.value = null
        language.value = ""; modelName.value = ""
        message.value = null
        phase.value = Phase.READY
    }

    /** Charge un SRT / VTT existant pour l'incruster sans retranscrire. */
    fun loadSubtitleFile(ctx: Context, uri: Uri): Boolean {
        val text = runCatching {
            ctx.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
        }.getOrNull()
        val parsed = text?.let(Subtitles::parse).orEmpty()
        if (parsed.isEmpty()) { message.value = "Aucun sous-titre lisible dans ce fichier (SRT ou VTT attendu)."; return false }
        cues.value = parsed
        srtUri.value = uri
        txtUri.value = null
        burnedUri.value = null
        phase.value = Phase.REVIEW
        message.value = "${parsed.size} sous-titres importés"
        return true
    }

    fun startTranscription(ctx: Context, model: WhisperModels.Model, destinationTreeUri: Uri? = null) {
        val src = source.value ?: return
        if (ExportManager.state.value.busy) { message.value = "Un traitement est déjà en cours."; return }
        WhisperEngine.available()?.let { message.value = it; return }
        val app = ctx.applicationContext
        cues.value = emptyList()
        srtUri.value = null; txtUri.value = null; burnedUri.value = null
        message.value = null
        val job = SubtitleJobs.transcribe(
            app, src.uri, "${src.base}.srt", SubFormat.SRT, model, options.value, src.name,
            destinationTreeUri, alsoTxt = true,
            onCue = { c -> cues.update { it + c } },
            onResult = { t ->
                cues.value = t.cues
                language.value = t.language
                modelName.value = t.model
            },
            onTxtSaved = { txtUri.value = it },
            onSaved = { uri ->
                srtUri.value = uri
                phase.value = Phase.REVIEW
            },
        )
        phase.value = Phase.TRANSCRIBING
        ExportManager.start(app, job)
    }

    fun startBurn(ctx: Context, destinationTreeUri: Uri? = null) {
        val src = source.value ?: return
        if (!src.hasVideo) { message.value = "Un fichier audio ne peut pas recevoir de sous-titres incrustés."; return }
        if (ExportManager.state.value.busy) { message.value = "Un traitement est déjà en cours."; return }
        val list = cues.value.filter { it.text.isNotBlank() }
        if (list.isEmpty()) { message.value = "Aucun sous-titre à incruster."; return }
        burnedUri.value = null
        message.value = null
        val job = SubtitleJobs.burn(
            ctx.applicationContext, src.uri, list, style.value, "${src.base}_soustitre.mp4", destinationTreeUri,
            onSaved = { uri -> burnedUri.value = uri; phase.value = Phase.BURNED },
        )
        phase.value = Phase.BURNING
        ExportManager.start(ctx.applicationContext, job)
    }

    /** Remet l'écran dans un état cohérent si le service s'est arrêté sur une erreur ou une annulation. */
    fun reconcile(st: ExportManager.State) {
        if (st.busy) return
        when (phase.value) {
            Phase.TRANSCRIBING -> if (st.error != null || st.cancelled) {
                phase.value = if (cues.value.isNotEmpty() && st.cancelled) Phase.REVIEW else Phase.READY
                if (phase.value == Phase.READY) cues.value = emptyList()
                message.value = if (st.cancelled) "Transcription annulée" else "Échec : ${st.error}"
            }
            Phase.BURNING -> if (st.error != null || st.cancelled) {
                phase.value = Phase.REVIEW
                message.value = if (st.cancelled) "Incrustation annulée" else "Échec : ${st.error}"
            }
            else -> Unit
        }
    }

    /** Enregistre la version modifiée (SRT + TXT) ; rapide, fait sans le service. */
    fun saveEdited(ctx: Context, destinationTreeUri: Uri? = null): Boolean {
        val src = source.value ?: return false
        val list = cues.value.filter { it.text.isNotBlank() }
        if (list.isEmpty()) { message.value = "Aucun sous-titre à enregistrer."; return false }
        return try {
            val srt = File(ctx.cacheDir, "${src.base}.srt").apply { writeText(Subtitles.toSrt(list)) }
            val txt = File(ctx.cacheDir, "${src.base}.txt").apply {
                writeText(Subtitles.toTxt(list, src.name, language.value, modelName.value, src.durationMs))
            }
            srtUri.value = Saver.save(ctx, srt, srt.name, SubFormat.SRT.mime, destinationTreeUri)
            txtUri.value = Saver.save(ctx, txt, txt.name, SubFormat.TXT.mime, destinationTreeUri)
            srt.delete(); txt.delete()
            message.value = "Sous-titres modifiés enregistrés (SRT + TXT)"
            true
        } catch (e: Exception) {
            message.value = "Enregistrement impossible : ${e.message}"
            false
        }
    }

    fun editCue(index: Int, text: String) = cues.update { l ->
        if (index !in l.indices) l else l.toMutableList().also { it[index] = it[index].copy(text = text) }
    }

    fun deleteCue(index: Int) = cues.update { l -> l.filterIndexed { i, _ -> i != index } }

    fun shiftAll(deltaMs: Long) = cues.update { Subtitles.shift(it, deltaMs) }

    fun reset() {
        source.value = null
        cues.value = emptyList()
        srtUri.value = null; txtUri.value = null; burnedUri.value = null
        message.value = null
        phase.value = Phase.EMPTY
    }
}
