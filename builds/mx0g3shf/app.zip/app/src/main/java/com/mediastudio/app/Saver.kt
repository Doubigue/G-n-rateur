package com.mediastudio.app

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.provider.DocumentsContract
import java.io.File

/**
 * Copie le résultat dans le bon dossier public :
 * vidéo → Movies/MediaStudio · audio → Music/MediaStudio · image → Pictures/MediaStudio · reste (PDF, Word…) → Download/MediaStudio.
 */
object Saver {
    @SuppressLint("NewApi")
    fun save(ctx: Context, file: File, displayName: String, mime: String, destinationTreeUri: Uri? = null): Uri {
        if (destinationTreeUri != null) {
            val root = DocumentsContract.buildDocumentUriUsingTree(
                destinationTreeUri, DocumentsContract.getTreeDocumentId(destinationTreeUri)
            )
            val created = DocumentsContract.createDocument(ctx.contentResolver, root, mime, displayName)
                ?: error("Impossible de créer le fichier dans le dossier choisi")
            try {
                ctx.contentResolver.openOutputStream(created)?.use { out ->
                    file.inputStream().use { input -> input.copyTo(out) }
                } ?: error("Impossible d'écrire dans le dossier choisi")
            } catch (e: Exception) {
                runCatching { DocumentsContract.deleteDocument(ctx.contentResolver, created) }
                throw e
            }
            return created
        }
        val (collection, base) = when {
            mime.startsWith("video") -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_MOVIES
            mime.startsWith("audio") -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_MUSIC
            mime.startsWith("image") -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_PICTURES
            else -> MediaStore.Downloads.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_DOWNLOADS
        }
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, "$base/MediaStudio")
        }
        val uri = ctx.contentResolver.insert(collection, values) ?: error("Sauvegarde impossible")
        try {
            ctx.contentResolver.openOutputStream(uri)!!.use { o -> file.inputStream().use { it.copyTo(o) } }
        } catch (e: Exception) {
            runCatching { ctx.contentResolver.delete(uri, null, null) }
            throw e
        }
        return uri
    }
}
