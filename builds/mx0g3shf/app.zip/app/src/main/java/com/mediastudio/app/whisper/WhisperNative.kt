package com.mediastudio.app.whisper

import android.content.res.AssetManager

/**
 * Liaison JNI vers whisper.cpp (src/main/cpp/whisper_jni.cpp). Ne pas renommer : les symboles natifs
 * sont dérivés du paquet, de la classe et du nom de chaque fonction.
 *
 * Toutes les fonctions sont bloquantes : à appeler hors du thread principal.
 */
internal object WhisperNative {

    /** Rappels appelés depuis le thread qui exécute [transcribe]. */
    interface Callback {
        fun onProgress(progress: Int)
        fun onSegment(t0Ms: Long, t1Ms: Long, utf8: ByteArray)
    }

    /** null si la bibliothèque est chargée, sinon le message d'erreur (ABI non prise en charge…). */
    val loadError: String? = try {
        System.loadLibrary("mediastudio_whisper"); null
    } catch (e: Throwable) {
        e.message ?: "Bibliothèque Whisper introuvable"
    }

    external fun initFromFile(path: String): Long
    external fun initFromAsset(assets: AssetManager, path: String): Long
    external fun free(handle: Long)
    external fun abort(handle: Long)

    /** 0 = succès, 1 = annulé, autre = erreur. */
    external fun transcribe(
        handle: Long, samples: FloatArray, nSamples: Int, language: String, translate: Boolean,
        threads: Int, maxLen: Int, beamSize: Int, prompt: String?, callback: Callback?,
    ): Int

    external fun segmentCount(handle: Long): Int
    external fun segmentT0(handle: Long, index: Int): Long
    external fun segmentT1(handle: Long, index: Int): Long
    external fun segmentText(handle: Long, index: Int): ByteArray
    external fun detectedLanguage(handle: Long): String
    external fun isMultilingual(handle: Long): Boolean
    external fun modelType(handle: Long): String
    external fun systemInfo(): String
}
