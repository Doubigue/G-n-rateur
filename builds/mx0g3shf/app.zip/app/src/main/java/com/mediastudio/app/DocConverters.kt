package com.mediastudio.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.min

/**
 * Conversions de documents, 100 % hors-ligne :
 *  - Word (.docx) → PDF : mise en page du document respectée (WordToPdf) ;
 *  - PDF → Word (.docx) : page par page à l'identique (PdfToWord) ;
 *  - Texte (.txt) → PDF ; images → un seul PDF.
 */
object DocConverters {

    const val DOCX_MIME = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"

    private const val PAGE_W = 595 // A4 en points (72 dpi)
    private const val PAGE_H = 842
    private const val MARGIN = 56

    // ───────────────────────────── Word → PDF ─────────────────────────────

    suspend fun wordToPdf(ctx: Context, input: Uri, output: File, onProgress: (Float) -> Unit = {}) =
        withContext(Dispatchers.IO) {
            FontKit.init(ctx)
            val tmp = copyToCache(ctx, input, ".docx")
            try {
                onProgress(0.02f)
                WordToPdf.fromDocx(tmp, output, onProgress)
            } finally { tmp.delete() }
        }

    suspend fun textToPdf(ctx: Context, input: Uri, output: File, onProgress: (Float) -> Unit = {}) =
        withContext(Dispatchers.IO) {
            FontKit.init(ctx)
            val text = ctx.contentResolver.openInputStream(input)?.use { it.readBytes().toString(Charsets.UTF_8) }
                ?: error("Fichier illisible")
            WordToPdf.fromText(text, output, onProgress)
        }

    suspend fun imagesToPdf(ctx: Context, uris: List<Uri>, output: File, onProgress: (Float) -> Unit = {}) =
        withContext(Dispatchers.IO) {
            val doc = PdfDocument()
            try {
                uris.forEachIndexed { i, u ->
                    val bmp = ImageOps.decode(ctx, u, 2200)
                    val landscape = bmp.width > bmp.height
                    val pw = if (landscape) PAGE_H else PAGE_W
                    val ph = if (landscape) PAGE_W else PAGE_H
                    val page = doc.startPage(PdfDocument.PageInfo.Builder(pw, ph, i + 1).create())
                    val m = 24f
                    val s = min((pw - 2 * m) / bmp.width, (ph - 2 * m) / bmp.height)
                    val w = bmp.width * s
                    val h = bmp.height * s
                    val left = (pw - w) / 2
                    val top = (ph - h) / 2
                    page.canvas.drawColor(Color.WHITE)
                    page.canvas.drawBitmap(bmp, null, RectF(left, top, left + w, top + h), Paint(Paint.FILTER_BITMAP_FLAG))
                    doc.finishPage(page)
                    bmp.recycle()
                    onProgress((i + 1f) / uris.size)
                }
                output.outputStream().use { doc.writeTo(it) }
            } finally { doc.close() }
        }

    // ───────────────────────────── PDF → Word ─────────────────────────────

    /** Page par page à l'identique : même taille, même nombre de pages, textes modifiables à leur place (police, taille, couleur). */
    suspend fun pdfToWord(ctx: Context, input: Uri, output: File, onProgress: (Float) -> Unit = {}) =
        withContext(Dispatchers.IO) { PdfToWord.convert(ctx, input, output, onProgress) }

    private fun copyToCache(ctx: Context, uri: Uri, suffix: String): File {
        val tmp = File.createTempFile("conv", suffix, ctx.cacheDir)
        ctx.contentResolver.openInputStream(uri)?.use { i -> tmp.outputStream().use { i.copyTo(it) } }
            ?: error("Fichier illisible")
        return tmp
    }

}
