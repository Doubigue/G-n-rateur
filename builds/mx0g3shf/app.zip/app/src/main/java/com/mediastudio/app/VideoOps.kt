package com.mediastudio.app

import android.content.Context
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.ChannelMixingAudioProcessor
import androidx.media3.common.audio.ChannelMixingMatrix
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.effect.RgbMatrix
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.transformer.*
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.roundToInt

/** Matrice couleur qui ne change rien : sa seule présence impose le réencodage de l'image. */
@UnstableApi
private class NeutralMatrix : RgbMatrix {
    override fun getMatrix(presentationTimeUs: Long, useHdr: Boolean) = floatArrayOf(
        1f, 0f, 0f, 0f,
        0f, 1f, 0f, 0f,
        0f, 0f, 1f, 0f,
        0f, 0f, 0f, 1f)
}

/** Compression, collage (concat) et mixage musique+vidéo via Media3 Transformer (MediaCodec matériel). */
@UnstableApi
object VideoOps {

    private fun fx(audio: List<AudioProcessor> = emptyList(), video: List<Effect> = emptyList()) =
        Effects(audio, video)

    private fun volumeProcessors(volume: Float): List<AudioProcessor> {
        val mixer = ChannelMixingAudioProcessor()
        for (ch in 1..2) mixer.putChannelMixingMatrix(ChannelMixingMatrix.create(ch, 2).scaleBy(volume))
        return listOf(mixer)
    }

    /** Le son d'origine est conservé (setRemoveAudio(false) explicite) : seules les opérations « muet » / « remplacer le son » le retirent. */
    private fun item(ctx: Context, c: Clip, maxHeight: Int?, fadeIn: Boolean = false, fadeOut: Boolean = false) =
        EditedMediaItem.Builder(c.toMediaItem())
            .setRemoveAudio(false)
            .setEffects(fx(video = videoEffects(c, fadeIn, fadeOut, maxHeight, ctx))).build()

    private fun single(
        c: Clip, video: List<Effect> = emptyList(), audio: List<AudioProcessor> = emptyList(), removeAudio: Boolean = false
    ) = EditedMediaItem.Builder(c.toMediaItem()).setRemoveAudio(removeAudio).setEffects(fx(audio, video)).build()

    internal suspend fun runSingle(ctx: Context, item: EditedMediaItem, output: File, onProgress: (Float) -> Unit) {
        val seq = EditedMediaItemSequence.Builder(item).build()
        run(ctx, Composition.Builder(listOf(seq)).build(), output, null, onProgress)
    }

    /** Rotation (degrés, sens horaire : 90 / 180 / 270) et/ou miroir horizontal. Le son est conservé. */
    suspend fun transform(
        ctx: Context, clip: Clip, output: File, rotateClockwiseDeg: Int, flipHorizontal: Boolean,
        onProgress: (Float) -> Unit = {}
    ) {
        val t = ScaleAndRotateTransformation.Builder()
            .setRotationDegrees(((360 - rotateClockwiseDeg) % 360).toFloat()) // Media3 tourne dans le sens anti-horaire
            .setScale(if (flipHorizontal) -1f else 1f, 1f)
            .build()
        runSingle(ctx, single(clip, video = listOf<Effect>(t) + videoEffects(clip, context = ctx)), output, onProgress)
    }

    /** Ralenti / accéléré : l'image ET le son changent de vitesse (le son garde sa hauteur). */
    suspend fun speed(ctx: Context, clip: Clip, output: File, speed: Float, onProgress: (Float) -> Unit = {}) {
        val sonic = SonicAudioProcessor().apply { setSpeed(speed) }
        runSingle(
            ctx,
            single(clip, video = listOf<Effect>(SpeedChangeEffect(speed)) + videoEffects(clip, context = ctx), audio = listOf<AudioProcessor>(sonic)),
            output, onProgress
        )
    }

    /** Volume du son d'une vidéo ou d'un fichier audio (export AAC) ; 1 = inchangé. */
    suspend fun volume(ctx: Context, clip: Clip, output: File, volume: Float, onProgress: (Float) -> Unit = {}) =
        runSingle(ctx, single(clip, video = videoEffects(clip, context = ctx), audio = volumeProcessors(volume)), output, onProgress)

    /** Applique un preset DSP au son d'un fichier audio ou d'une vidéo. */
    suspend fun audioEffect(
        ctx: Context, clip: Clip, output: File, preset: AudioPreset, onProgress: (Float) -> Unit = {}
    ) {
        runSingle(
            ctx,
            single(clip, video = videoEffects(clip, context = ctx), audio = listOf(PresetAudioProcessor(preset))),
            output, onProgress
        )
    }

    /** Supprime la piste audio. */
    suspend fun mute(ctx: Context, clip: Clip, output: File, onProgress: (Float) -> Unit = {}) =
        runSingle(ctx, single(clip, video = videoEffects(clip, context = ctx), removeAudio = true), output, onProgress)

    /** Découpe + filtre + texte + hauteur max + débit vidéo (H.264 + AAC). */
    suspend fun compress(
        ctx: Context, clip: Clip, output: File,
        maxHeight: Int = 720, videoBitrate: Int = 2_000_000,
        onProgress: (Float) -> Unit = {}
    ) {
        val encoderFactory = DefaultEncoderFactory.Builder(ctx)
            .setRequestedVideoEncoderSettings(
                VideoEncoderSettings.Builder().setBitrate(videoBitrate).build())
            .build()
        val seq = EditedMediaItemSequence.Builder(item(ctx, clip, maxHeight)).build()
        run(ctx, Composition.Builder(listOf(seq)).build(), output, encoderFactory, onProgress)
    }

    /** Applique uniquement les effets du clip (filtre, texte, découpe) ; résolution d'origine si [maxHeight] est null. */
    suspend fun applyEffects(
        ctx: Context, clip: Clip, output: File,
        maxHeight: Int? = null, onProgress: (Float) -> Unit = {}
    ) {
        val seq = EditedMediaItemSequence.Builder(item(ctx, clip, maxHeight)).build()
        run(ctx, Composition.Builder(listOf(seq)).build(), output, null, onProgress)
    }

    /** Colle les clips ; [fade] ajoute un fondu au noir entre chaque clip. */
    suspend fun concat(
        ctx: Context, clips: List<Clip>, output: File,
        fade: Boolean = false, maxHeight: Int = 1080, onProgress: (Float) -> Unit = {}
    ) {
        val items = clips.mapIndexed { i, c ->
            item(ctx, c, maxHeight, fadeIn = fade && i > 0, fadeOut = fade && i < clips.lastIndex)
        }
        val seq = EditedMediaItemSequence.Builder(items).build()
        run(ctx, Composition.Builder(listOf(seq)).build(), output, null, onProgress)
    }

    /** Musique (découpée, bouclée) sur la vidéo (découpée, filtrée, texte), volumes réglables. */
    suspend fun mixMusic(
        ctx: Context, clip: Clip, music: Clip, output: File,
        keepOriginalAudio: Boolean = true, videoVolume: Float = 1f, musicVolume: Float = 1f,
        onProgress: (Float) -> Unit = {}
    ) {
        val v = EditedMediaItem.Builder(clip.toMediaItem())
            .setRemoveAudio(!keepOriginalAudio)
            .setEffects(fx(
                audio = if (keepOriginalAudio && videoVolume != 1f) volumeProcessors(videoVolume) else emptyList(),
                video = videoEffects(clip, context = ctx)))
            .build()
        val m = EditedMediaItem.Builder(music.toMediaItem())
            .setRemoveVideo(true).setEffects(fx(audio = volumeProcessors(musicVolume))).build()
        val videoSeq = EditedMediaItemSequence.Builder(v).build()
        val musicSeq = EditedMediaItemSequence.Builder(m).setIsLooping(true).build()
        run(ctx, Composition.Builder(listOf(videoSeq, musicSeq)).build(), output, null, onProgress)
    }


    /** Un essai de conversion en MP4 (voir [Mp4Plan.attempts]) ; le son est toujours mis en AAC. */
    internal suspend fun toMp4(
        ctx: Context, source: android.net.Uri, output: File, attempt: Mp4Attempt, info: SourceInfo,
        onProgress: (Float) -> Unit = {}
    ) {
        // Une matrice neutre oblige Media3 à décoder puis réencoder l'image (utile quand la copie échoue)
        val video: List<Effect> = if (attempt.forceVideoEncode) listOf(NeutralMatrix()) else emptyList()
        // Son 5.1 / 7.1 à réencoder : mixage en stéréo, accepté par tous les encodeurs AAC
        val audio: List<AudioProcessor> =
            if (!attempt.removeAudio && info.audioMime != null && info.audioMime != Mp4Plan.AAC && info.audioChannels in 3..8) {
                val mixer = ChannelMixingAudioProcessor()
                mixer.putChannelMixingMatrix(
                    ChannelMixingMatrix(info.audioChannels, 2, Mp4Plan.stereoCoefficients(info.audioChannels)))
                listOf(mixer)
            } else emptyList()
        val edited = EditedMediaItem.Builder(MediaItem.fromUri(source))
            .setRemoveAudio(attempt.removeAudio)
            .setEffects(fx(audio, video))
            .build()
        val seq = EditedMediaItemSequence.Builder(edited).build()
        run(ctx, Composition.Builder(listOf(seq)).build(), output, null, onProgress, attempt.videoMime)
    }

    /** Extrait toute piste audio décodable et la normalise en AAC/M4A pour le paquet d'images. */
    suspend fun extractAudioAsAac(ctx: Context, source: android.net.Uri, output: File, onProgress: (Float) -> Unit = {}) {
        val probe = android.media.MediaExtractor()
        val hasAudio = try {
            probe.setDataSource(ctx, source, null)
            (0 until probe.trackCount).any { probe.getTrackFormat(it).getString(android.media.MediaFormat.KEY_MIME).orEmpty().startsWith("audio/") }
        } finally { probe.release() }
        if (!hasAudio) error("Aucune piste audio dans la source")
        val mediaItem = MediaItem.fromUri(source)
        val edited = EditedMediaItem.Builder(mediaItem).setRemoveVideo(true).setRemoveAudio(false).build()
        val sequence = EditedMediaItemSequence.Builder(edited).build()
        run(ctx, Composition.Builder(listOf(sequence)).build(), output, null, onProgress)
    }

    /** Reconstruit un MP4 à partir d'une séquence d'images JPEG et d'une piste audio facultative. */
    suspend fun rebuildFromImages(
        ctx: Context, images: List<File>, fps: Double, durationMs: Long, audio: File?, output: File,
        onProgress: (Float) -> Unit = {}
    ) {
        require(images.isNotEmpty()) { "Le dossier ne contient aucune image JPEG." }
        require(fps in 0.1..240.0) { "FPS absent ou invalide dans metadata.txt." }
        require(images.size <= 50000) { "Ce dossier contient trop d'images pour une reconstruction sur cet appareil (maximum 50 000)." }
        val nominalFrameMs = (1000.0 / fps).toLong().coerceAtLeast(1L)
        val totalDuration = durationMs.takeIf { it > 0 } ?: nominalFrameMs * images.size
        val videoItems = images.mapIndexed { index, file ->
            require(file.isFile && file.length() > 0) { "Image illisible : ${file.name}" }
            val thisDuration = if (index == images.lastIndex) {
                (totalDuration - nominalFrameMs * index).coerceAtLeast(1L)
            } else nominalFrameMs
            val item = MediaItem.Builder().setUri(android.net.Uri.fromFile(file)).setImageDurationMs(thisDuration).build()
            EditedMediaItem.Builder(item).setFrameRate(fps.roundToInt().coerceIn(1, 240)).build()
        }
        val videoSequence = EditedMediaItemSequence.Builder(videoItems).build()
        val sequences = mutableListOf(videoSequence)
        if (audio != null && audio.exists() && audio.length() > 0) {
            val audioItem = EditedMediaItem.Builder(MediaItem.fromUri(android.net.Uri.fromFile(audio)))
                .setRemoveVideo(true).setRemoveAudio(false).build()
            sequences += EditedMediaItemSequence.Builder(audioItem).build()
        }
        run(ctx, Composition.Builder(sequences).build(), output, null, onProgress)
    }

    private suspend fun run(
        ctx: Context, composition: Composition, output: File,
        encoderFactory: Codec.EncoderFactory?, onProgress: (Float) -> Unit,
        /** null : garder le format d'image de la source (copie sans réencodage). */
        videoMime: String? = MimeTypes.VIDEO_H264,
    ) = withContext(Dispatchers.Main) {
        val done = CompletableDeferred<Unit>()
        val b = Transformer.Builder(ctx)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(c: Composition, r: ExportResult) { done.complete(Unit) }
                override fun onError(c: Composition, r: ExportResult, e: ExportException) {
                    done.completeExceptionally(e)
                }
            })
        videoMime?.let { b.setVideoMimeType(it) }
        encoderFactory?.let { b.setEncoderFactory(it) }
        val t = b.build()
        output.delete()
        t.start(composition, output.absolutePath)
        val holder = ProgressHolder()
        try {
            while (!done.isCompleted && isActive) {
                if (t.getProgress(holder) != Transformer.PROGRESS_STATE_NOT_STARTED)
                    onProgress(holder.progress / 100f)
                delay(300)
            }
            done.await()
        } finally { if (!done.isCompleted) t.cancel() }
    }
}
