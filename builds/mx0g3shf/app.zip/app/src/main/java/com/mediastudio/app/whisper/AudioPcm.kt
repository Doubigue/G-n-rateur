package com.mediastudio.app.whisper

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.coroutines.coroutineContext
import kotlin.math.sqrt

/**
 * Extrait la piste audio d'une vidéo ou d'un fichier audio et la convertit au format attendu par Whisper :
 * PCM float 32 bits, mono, 16 kHz. Le résultat est écrit dans un fichier temporaire (une heure d'audio
 * = ~230 Mo) puis relu par blocs, pour ne jamais tout garder en mémoire.
 */
object AudioPcm {
    const val RATE = 16_000

    class Pcm(val file: File, val samples: Long) {
        val durationMs get() = samples * 1000 / RATE
    }

    suspend fun decode(ctx: Context, source: Uri, out: File, onProgress: (Float) -> Unit): Pcm = withContext(Dispatchers.IO) {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(ctx, source, null)
            val track = (0 until ex.trackCount).firstOrNull {
                ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME).orEmpty().startsWith("audio/")
            } ?: error("Ce fichier ne contient aucune piste audio à transcrire.")
            ex.selectTrack(track)
            val inFmt = ex.getTrackFormat(track)
            val mime = inFmt.getString(MediaFormat.KEY_MIME)!!
            val durationUs = if (inFmt.containsKey(MediaFormat.KEY_DURATION)) inFmt.getLong(MediaFormat.KEY_DURATION) else 0L

            val dec = try { MediaCodec.createDecoderByType(mime) } catch (e: Exception) {
                error("Format audio non pris en charge par ce téléphone ($mime).")
            }
            codec = dec
            dec.configure(inFmt, null, null, 0)
            dec.start()

            var channels = inFmt.getIntegerOr(MediaFormat.KEY_CHANNEL_COUNT, 1)
            var rate = inFmt.getIntegerOr(MediaFormat.KEY_SAMPLE_RATE, 44_100)
            var floatPcm = false
            var resampler = Resampler(rate)

            val writer = FloatWriter(out)
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var lastReport = 0L
            try {
                while (!outputDone) {
                    coroutineContext.ensureActive()
                    if (!inputDone) {
                        val i = dec.dequeueInputBuffer(10_000)
                        if (i >= 0) {
                            val buf = dec.getInputBuffer(i)!!
                            val n = ex.readSampleData(buf, 0)
                            if (n < 0) {
                                dec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                dec.queueInputBuffer(i, 0, n, ex.sampleTime, 0)
                                ex.advance()
                            }
                        }
                    }
                    val o = dec.dequeueOutputBuffer(info, 10_000)
                    when {
                        o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            val f = dec.outputFormat
                            channels = f.getIntegerOr(MediaFormat.KEY_CHANNEL_COUNT, channels).coerceAtLeast(1)
                            val newRate = f.getIntegerOr(MediaFormat.KEY_SAMPLE_RATE, rate)
                            if (newRate != rate) { rate = newRate; resampler = Resampler(rate) }
                            floatPcm = f.getIntegerOr(MediaFormat.KEY_PCM_ENCODING, AudioFormat.ENCODING_PCM_16BIT) ==
                                AudioFormat.ENCODING_PCM_FLOAT
                        }
                        o >= 0 -> {
                            val bb = dec.getOutputBuffer(o)
                            if (bb != null && info.size > 0) {
                                bb.position(info.offset).limit(info.offset + info.size)
                                val ordered = bb.slice().order(ByteOrder.nativeOrder())
                                if (floatPcm) {
                                    val fb = ordered.asFloatBuffer()
                                    val frames = fb.remaining() / channels
                                    for (k in 0 until frames) {
                                        var sum = 0f
                                        for (c in 0 until channels) sum += fb.get(k * channels + c)
                                        resampler.push(sum / channels, writer::write)
                                    }
                                } else {
                                    val sb = ordered.asShortBuffer()
                                    val frames = sb.remaining() / channels
                                    for (k in 0 until frames) {
                                        var sum = 0
                                        for (c in 0 until channels) sum += sb.get(k * channels + c)
                                        resampler.push(sum / (channels * 32768f), writer::write)
                                    }
                                }
                            }
                            outputDone = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                            dec.releaseOutputBuffer(o, false)
                            if (durationUs > 0 && info.presentationTimeUs - lastReport > 500_000) {
                                lastReport = info.presentationTimeUs
                                onProgress((info.presentationTimeUs.toFloat() / durationUs).coerceIn(0f, 1f))
                            }
                        }
                    }
                }
            } finally {
                writer.close()
            }
            onProgress(1f)
            if (writer.count < RATE / 2) error("La piste audio est vide ou trop courte.")
            Pcm(out, writer.count)
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            ex.release()
        }
    }

    /**
     * Découpe le PCM en blocs d'environ [chunkSec] secondes, coupés dans le passage le plus silencieux
     * des dernières secondes du bloc pour ne pas trancher un mot.
     */
    fun chunks(pcm: Pcm, chunkSec: Int = 300): List<LongRange> {
        val total = pcm.samples
        val size = chunkSec.toLong() * RATE
        if (total <= size + RATE * 20L) return listOf(0L until total)
        val out = ArrayList<LongRange>()
        RandomAccessFile(pcm.file, "r").use { raf ->
            var start = 0L
            while (start < total) {
                val remaining = total - start
                if (remaining <= size + RATE * 20L) { out += start until total; break }
                val searchFrom = start + size - RATE * 4L
                val cut = quietestPoint(raf, searchFrom, RATE * 4)
                out += start until cut
                start = cut
            }
        }
        return out
    }

    private fun quietestPoint(raf: RandomAccessFile, from: Long, length: Int): Long {
        val win = RATE / 10 // 100 ms
        val data = readFloats(raf, from, length)
        var best = from + length / 2
        var bestEnergy = Double.MAX_VALUE
        var w = 0
        while (w + win <= data.size) {
            var e = 0.0
            for (k in w until w + win) e += data[k] * data[k]
            val rms = sqrt(e / win)
            if (rms < bestEnergy) { bestEnergy = rms; best = from + w + win / 2 }
            w += win / 2
        }
        return best
    }

    fun read(pcm: Pcm, range: LongRange): FloatArray =
        RandomAccessFile(pcm.file, "r").use { readFloats(it, range.first, (range.last - range.first + 1).toInt()) }

    private fun readFloats(raf: RandomAccessFile, from: Long, count: Int): FloatArray {
        val bytes = ByteArray(count * 4)
        raf.seek(from * 4)
        var read = 0
        while (read < bytes.size) {
            val n = raf.read(bytes, read, bytes.size - read)
            if (n < 0) break
            read += n
        }
        val out = FloatArray(read / 4)
        ByteBuffer.wrap(bytes, 0, read).order(ByteOrder.LITTLE_ENDIAN).asFloatBuffer().get(out)
        return out
    }

    private fun MediaFormat.getIntegerOr(key: String, def: Int): Int =
        if (containsKey(key)) runCatching { getInteger(key) }.getOrDefault(def) else def

    /** Écriture tamponnée de floats little-endian. */
    private class FloatWriter(file: File) {
        private val stream = file.outputStream().buffered(1 shl 16)
        private val buf = ByteBuffer.allocate(4096 * 4).order(ByteOrder.LITTLE_ENDIAN)
        var count = 0L
            private set

        fun write(v: Float) {
            buf.putFloat(v.coerceIn(-1f, 1f))
            count++
            if (!buf.hasRemaining()) flush()
        }

        private fun flush() {
            stream.write(buf.array(), 0, buf.position())
            buf.clear()
        }

        fun close() { flush(); stream.close() }
    }

    /**
     * Rééchantillonnage vers 16 kHz : filtre moyenneur (anti-repliement simple) puis interpolation linéaire.
     * Suffisant pour la voix, qui est l'unique usage.
     */
    private class Resampler(inRate: Int) {
        private val step = inRate.toDouble() / RATE
        private val box = if (step > 1.5) step.toInt().coerceIn(1, 8) else 1
        private val ring = FloatArray(box)
        private var ringPos = 0
        private var ringSum = 0f
        private var t = 0.0
        private var idx = -1L
        private var prev = 0f

        fun push(sample: Float, out: (Float) -> Unit) {
            val x = if (box == 1) sample else {
                ringSum += sample - ring[ringPos]
                ring[ringPos] = sample
                ringPos = (ringPos + 1) % box
                ringSum / box
            }
            idx++
            if (idx == 0L) prev = x
            while (t <= idx) {
                val frac = (t - (idx - 1)).toFloat().coerceIn(0f, 1f)
                out(prev + (x - prev) * frac)
                t += step
            }
            prev = x
        }
    }
}
