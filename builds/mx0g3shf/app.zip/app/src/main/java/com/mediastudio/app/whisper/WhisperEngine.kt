package com.mediastudio.app.whisper

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.coroutineContext

/** Réglages d'une transcription. */
data class TranscribeOptions(
    /** Code ISO (fr, en…) ou « auto ». */
    val language: String = "auto",
    /** Traduit vers l'anglais au lieu de transcrire. */
    val translate: Boolean = false,
    /** Longueur maximale d'un sous-titre en caractères (0 = phrases entières de Whisper). */
    val maxChars: Int = 42,
    /** true : recherche en faisceau (plus précis, ~2× plus lent). */
    val accurate: Boolean = false,
    /** Vocabulaire / noms propres pour guider Whisper (facultatif). */
    val prompt: String = "",
)

/** Résultat complet d'une transcription. */
data class Transcript(
    val cues: List<Cue>,
    val language: String,
    val model: String,
    val durationMs: Long,
)

/**
 * Moteur de transcription hors ligne (whisper.cpp). Un seul modèle chargé à la fois, gardé en mémoire
 * entre deux transcriptions ; un seul calcul à la fois.
 */
object WhisperEngine {
    private val mutex = Mutex()
    private var handle = 0L
    private var loadedId: String? = null
    private var loadedType = ""

    enum class Stage { AUDIO, MODEL, TRANSCRIBE }

    fun available(): String? = WhisperNative.loadError?.let {
        "Le moteur Whisper ne peut pas démarrer sur ce téléphone ($it)."
    }

    /**
     * Audio → PCM 16 kHz → Whisper par blocs de 5 min.
     * [onProgress] : étape + avancement global 0..1 ; [onCue] : chaque sous-titre dès qu'il est produit.
     */
    suspend fun transcribe(
        ctx: Context, source: Uri, model: WhisperModels.Model, options: TranscribeOptions,
        onProgress: (Stage, Float) -> Unit, onCue: (Cue) -> Unit = {},
    ): Transcript = mutex.withLock {
        available()?.let { error(it) }
        val report = onProgress
        val emit = onCue
        val pcmFile = File(ctx.cacheDir, "whisper_${System.nanoTime()}.f32")
        try {
            val pcm = AudioPcm.decode(ctx, source, pcmFile) { report(Stage.AUDIO, it * 0.12f) }
            report(Stage.MODEL, 0.12f)
            val h = load(ctx, model)
            report(Stage.TRANSCRIBE, 0.15f)

            val ranges = AudioPcm.chunks(pcm)
            val total = pcm.samples.toFloat()
            val all = ArrayList<Cue>()
            var detected = ""
            for (range in ranges) {
                coroutineContext.ensureActive()
                val offsetMs = range.first * 1000 / AudioPcm.RATE
                val done = range.first / total
                val share = (range.last - range.first + 1) / total
                val samples = withContext(Dispatchers.IO) { AudioPcm.read(pcm, range) }
                val callback = object : WhisperNative.Callback {
                    override fun onProgress(progress: Int) {
                        val p = progress.coerceIn(0, 100) / 100f
                        report(Stage.TRANSCRIBE, 0.15f + 0.85f * (done + share * p))
                    }

                    override fun onSegment(t0Ms: Long, t1Ms: Long, utf8: ByteArray) {
                        val text = utf8.toString(Charsets.UTF_8).trim()
                        if (text.isNotEmpty()) emit(Cue(t0Ms + offsetMs, t1Ms + offsetMs, text))
                    }
                }
                val rc = runCancellable(h) {
                    WhisperNative.transcribe(
                        h, samples, samples.size, options.language, options.translate, threads(), options.maxChars, if (options.accurate) 5 else 1,
                        options.prompt.trim().ifEmpty { null }, callback,
                    )
                }
                coroutineContext.ensureActive()
                if (rc == 1) error("Transcription annulée")
                if (rc != 0) error("Whisper a échoué (code $rc). Essayez un autre modèle.")
                if (detected.isEmpty()) detected = WhisperNative.detectedLanguage(h)
                // Résultat définitif du bloc (identique aux rappels, mais texte complet garanti)
                val n = WhisperNative.segmentCount(h)
                for (i in 0 until n) {
                    val text = WhisperNative.segmentText(h, i).toString(Charsets.UTF_8).trim()
                    if (text.isEmpty()) continue
                    all += Cue(WhisperNative.segmentT0(h, i) + offsetMs, WhisperNative.segmentT1(h, i) + offsetMs, text)
                }
            }
            report(Stage.TRANSCRIBE, 1f)
            val language = if (options.translate) "en" else detected.ifEmpty { options.language }
            Transcript(Subtitles.normalize(all, pcm.durationMs), language, loadedType.ifEmpty { model.label }, pcm.durationMs)
        } finally {
            pcmFile.delete()
        }
    }

    /** Exécute l'appel natif bloquant ; une annulation de la coroutine lève le drapeau d'arrêt de Whisper. */
    private suspend fun runCancellable(h: Long, block: () -> Int): Int = coroutineScope {
        val watcher = launch { try { awaitCancellation() } finally { WhisperNative.abort(h) } }
        try {
            withContext(Dispatchers.Default) { block() }
        } finally {
            watcher.cancel()
        }
    }

    private suspend fun load(ctx: Context, model: WhisperModels.Model): Long {
        if (handle != 0L && loadedId == model.id) return handle
        freeCurrent()
        val h = withContext(Dispatchers.IO) {
            when {
                model.asset != null -> WhisperNative.initFromAsset(ctx.applicationContext.assets, model.asset)
                model.file != null -> WhisperNative.initFromFile(model.file.absolutePath)
                else -> 0L
            }
        }
        if (h == 0L) error("Impossible de charger le modèle ${model.fileName} (fichier abîmé ou mémoire insuffisante).")
        handle = h
        loadedId = model.id
        loadedType = runCatching { WhisperNative.modelType(h) }.getOrDefault("")
        return h
    }

    private fun freeCurrent() {
        if (handle != 0L) WhisperNative.free(handle)
        handle = 0L
        loadedId = null
        loadedType = ""
    }

    /** Libère le modèle [id] s'il est chargé (avant suppression du fichier). */
    fun release(id: String) {
        if (loadedId == id && !mutex.isLocked) freeCurrent()
    }

    private fun threads(): Int = Runtime.getRuntime().availableProcessors().coerceIn(1, 4)
}
