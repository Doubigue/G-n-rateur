package com.mediastudio.app.whisper

import java.util.Locale

/** Un sous-titre : intervalle en millisecondes + texte (une ou deux lignes). */
data class Cue(val startMs: Long, val endMs: Long, val text: String) {
    val durationMs get() = endMs - startMs
}

/** Lecture / écriture des formats SRT, VTT et TXT horodaté. */
object Subtitles {

    /** 00:01:02,345 (SRT) ou 00:01:02.345 (VTT / TXT). */
    fun stamp(ms: Long, sep: Char = ','): String {
        val v = ms.coerceAtLeast(0)
        val h = v / 3_600_000
        val m = (v / 60_000) % 60
        val s = (v / 1000) % 60
        return String.format(Locale.US, "%02d:%02d:%02d%c%03d", h, m, s, sep, v % 1000)
    }

    /** 1:02 ou 1:02:03 — pour l'interface. */
    fun short(ms: Long): String {
        val t = ms.coerceAtLeast(0) / 1000
        return if (t >= 3600) String.format(Locale.US, "%d:%02d:%02d", t / 3600, (t / 60) % 60, t % 60)
        else String.format(Locale.US, "%d:%02d", t / 60, t % 60)
    }

    fun toSrt(cues: List<Cue>): String = buildString {
        cues.forEachIndexed { i, c ->
            append(i + 1).append('\n')
            append(stamp(c.startMs)).append(" --> ").append(stamp(c.endMs)).append('\n')
            append(c.text.trim()).append("\n\n")
        }
    }

    fun toVtt(cues: List<Cue>): String = buildString {
        append("WEBVTT\n\n")
        cues.forEach { c ->
            append(stamp(c.startMs, '.')).append(" --> ").append(stamp(c.endMs, '.')).append('\n')
            append(c.text.trim()).append("\n\n")
        }
    }

    /** Transcription lisible : en-tête, une ligne horodatée par segment, puis le texte intégral. */
    fun toTxt(cues: List<Cue>, title: String, language: String?, model: String?, durationMs: Long): String = buildString {
        val line = "─".repeat(48)
        append("Transcription — ").append(title).append('\n')
        val meta = buildList {
            language?.takeIf { it.isNotBlank() }?.let { add("Langue : ${languageLabel(it)}") }
            model?.takeIf { it.isNotBlank() }?.let { add("Modèle : Whisper $it") }
            if (durationMs > 0) add("Durée : ${short(durationMs)}")
            add("${cues.size} segment${if (cues.size > 1) "s" else ""}")
        }
        append(meta.joinToString(" · ")).append('\n')
        append("Transcrit hors ligne par Media Studio (Whisper)\n")
        append(line).append("\n\n")
        cues.forEach { c ->
            append('[').append(stamp(c.startMs, '.')).append(" → ").append(stamp(c.endMs, '.')).append("]  ")
            append(c.text.replace('\n', ' ').trim()).append('\n')
        }
        // Le TXT est un véritable fichier de sous-titres : aucune copie de texte non horodatée.
    }

    /** Texte continu : segments réunis, paragraphe après une pause de plus de 2 s. */
    fun fullText(cues: List<Cue>): String = buildString {
        var prevEnd = -1L
        cues.forEach { c ->
            val t = c.text.replace('\n', ' ').trim()
            if (t.isEmpty()) return@forEach
            if (prevEnd >= 0) append(if (c.startMs - prevEnd > 2000) "\n\n" else " ")
            append(t)
            prevEnd = c.endMs
        }
    }

    private val timeLine = Regex("""(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})\s*-->\s*(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})""")
    private val shortTimeLine = Regex("""(\d{1,2}):(\d{2})[,.](\d{1,3})\s*-->\s*(\d{1,2}):(\d{2})[,.](\d{1,3})""")

    /** Lit un SRT ou un VTT (balises <i>, <b>, {\an8}… retirées). */
    fun parse(content: String): List<Cue> {
        val out = ArrayList<Cue>()
        val lines = content.replace("﻿", "").replace("\r\n", "\n").replace('\r', '\n').split('\n')
        var i = 0
        while (i < lines.size) {
            val l = lines[i].trim()
            val full = timeLine.find(l)
            val short = if (full == null) shortTimeLine.find(l) else null
            if (full == null && short == null) { i++; continue }
            val (start, end) = if (full != null) {
                val g = full.groupValues
                ms(g[1], g[2], g[3], g[4]) to ms(g[5], g[6], g[7], g[8])
            } else {
                val g = short!!.groupValues
                ms("0", g[1], g[2], g[3]) to ms("0", g[4], g[5], g[6])
            }
            i++
            val text = StringBuilder()
            while (i < lines.size && lines[i].isNotBlank()) {
                if (text.isNotEmpty()) text.append('\n')
                text.append(lines[i].trim())
                i++
            }
            val clean = text.toString()
                .replace(Regex("<[^>]+>"), "")
                .replace(Regex("""\{\\[^}]*\}"""), "")
                .trim()
            if (clean.isNotEmpty() && end > start) out += Cue(start, end, clean)
        }
        return out.sortedBy { it.startMs }
    }

    private fun ms(h: String, m: String, s: String, frac: String): Long {
        val f = frac.padEnd(3, '0').take(3).toLong()
        return h.toLong() * 3_600_000 + m.toLong() * 60_000 + s.toLong() * 1000 + f
    }

    /** Index du sous-titre affiché à [ms] (recherche dichotomique), ou -1. */
    fun indexAt(cues: List<Cue>, ms: Long): Int {
        var lo = 0
        var hi = cues.size - 1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            val c = cues[mid]
            when {
                ms < c.startMs -> hi = mid - 1
                ms >= c.endMs -> lo = mid + 1
                else -> return mid
            }
        }
        return -1
    }

    /**
     * Nettoie la sortie brute de Whisper : textes vides retirés, chevauchements corrigés,
     * durée minimale de lecture, bornée par la durée du média.
     */
    fun normalize(raw: List<Cue>, mediaDurationMs: Long): List<Cue> {
        val sorted = raw.map { it.copy(text = it.text.trim()) }
            .filter { it.text.isNotEmpty() && !isNoise(it.text) }
            .sortedBy { it.startMs }
        val out = ArrayList<Cue>(sorted.size)
        sorted.forEachIndexed { i, c ->
            val next = sorted.getOrNull(i + 1)?.startMs
            var start = c.startMs.coerceAtLeast(out.lastOrNull()?.endMs ?: 0L)
            var end = maxOf(c.endMs, start + 700)
            if (next != null && end > next) end = maxOf(next, start + 200)
            if (mediaDurationMs > 0) {
                start = start.coerceAtMost(mediaDurationMs)
                end = end.coerceAtMost(mediaDurationMs)
            }
            if (end > start) out += Cue(start, end, c.text)
        }
        return out
    }

    /** Annotations de Whisper sans paroles : [Musique], (applaudissements), ♪… */
    private fun isNoise(t: String): Boolean {
        val s = t.trim()
        if (s.all { it == '♪' || it == '♫' || it.isWhitespace() || it == '.' || it == '-' }) return true
        return false
    }

    /** Décale tous les sous-titres de [deltaMs] (positif = plus tard). */
    fun shift(cues: List<Cue>, deltaMs: Long): List<Cue> = cues.mapNotNull {
        val s = (it.startMs + deltaMs).coerceAtLeast(0)
        val e = (it.endMs + deltaMs).coerceAtLeast(0)
        if (e > s) Cue(s, e, it.text) else null
    }

    val LANGUAGES: List<Pair<String, String>> = listOf(
        "auto" to "Détection auto", "fr" to "Français", "en" to "Anglais", "es" to "Espagnol",
        "pt" to "Portugais", "ar" to "Arabe", "de" to "Allemand", "it" to "Italien",
        "nl" to "Néerlandais", "sw" to "Swahili", "yo" to "Yoruba", "ha" to "Haoussa",
        "ln" to "Lingala", "zh" to "Chinois", "ru" to "Russe", "tr" to "Turc", "hi" to "Hindi",
        "ja" to "Japonais", "ko" to "Coréen",
    )

    fun languageLabel(code: String): String =
        LANGUAGES.firstOrNull { it.first == code }?.second ?: code.uppercase(Locale.ROOT)
}
