package com.mediastudio.app

import android.content.Context
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.provider.OpenableColumns
import androidx.media3.common.util.UnstableApi
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Conversion d'un lot de vidéos (MKV, AVI, WebM, MOV, TS…) en MP4, l'une après l'autre.
 * Chaque résultat est enregistré dès qu'il est prêt (Movies/MediaStudio ou le dossier choisi) : un échec
 * ou une annulation ne fait pas perdre les vidéos déjà converties.
 */
@UnstableApi
class Mp4Batch(
    private val ctx: Context,
    private val sources: List<Uri>,
    private val mode: Mp4Mode,
    private val allowMute: Boolean,
    private val destinationTreeUri: Uri?,
) : BatchWork {

    override val outputs = CopyOnWriteArrayList<BatchOutput>()
    private val failures = CopyOnWriteArrayList<String>()
    @Volatile private var muted = 0

    override fun summary(cancelled: Boolean): String =
        Mp4Plan.summary(sources.size, outputs.size, muted, failures.toList(), cancelled)

    override suspend fun run(onStage: (String) -> Unit, onProgress: (Float) -> Unit) {
        val dir = File(ctx.cacheDir, "mp4_batch")
        dir.deleteRecursively() // restes d'un traitement interrompu
        dir.mkdirs()
        try {
            sources.forEachIndexed { index, uri ->
                currentCoroutineContext().ensureActive()
                val name = withContext(Dispatchers.IO) { displayName(uri) } ?: "video_${index + 1}"
                onStage(if (sources.size > 1) "${index + 1}/${sources.size} · $name" else "Conversion en MP4")
                onProgress(index.toFloat() / sources.size)
                val temp = File(dir, "$index.mp4")
                try {
                    convert(uri, name, temp) { p -> onProgress((index + p.coerceIn(0f, 1f)) / sources.size) }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    failures += "$name : ${e.message ?: "conversion impossible"}"
                } finally {
                    temp.delete()
                }
            }
            onProgress(1f)
        } finally {
            dir.deleteRecursively()
        }
        if (outputs.isEmpty()) error(summary(false))
    }

    private suspend fun convert(uri: Uri, name: String, temp: File, onProgress: (Float) -> Unit) {
        Mp4Plan.unsupportedReason(name)?.let { error(it) }
        val info = withContext(Dispatchers.IO) {
            checkSpace(uri)
            probe { setDataSource(ctx, uri, null) }
        }
        var last: Exception? = null
        for (attempt in Mp4Plan.attempts(mode, info, allowMute)) {
            // Retirer le son n'a de sens que si la source en a un
            if (attempt.removeAudio && info.videoMime != null && info.audioMime == null) continue
            try {
                VideoOps.toMp4(ctx, uri, temp, attempt, info, onProgress)
                withContext(Dispatchers.IO) { verify(temp, info, attempt) }
                save(name, temp, attempt.removeAudio)
                return
            } catch (e: CancellationException) {
                throw e
            } catch (e: SaveFailed) {
                throw e // inutile de réencoder : c'est l'écriture qui échoue
            } catch (e: Exception) {
                last = e
                temp.delete()
            }
        }
        error(explain(info, last))
    }

    /** Le résultat doit contenir l'image, le son (sauf choix contraire) et à peu près toute la durée. */
    private fun verify(file: File, source: SourceInfo, attempt: Mp4Attempt) {
        if (file.length() <= 0L) error("fichier produit vide")
        val out = probe { setDataSource(file.absolutePath) }
        if (out.videoMime == null) error("le résultat ne contient pas d'image")
        if (!attempt.removeAudio && source.audioMime != null && out.audioMime == null) error("le son a été perdu")
        if (source.durationUs > 0 && out.durationUs > 0 && out.durationUs < source.durationUs * 9 / 10)
            error("le résultat est incomplet")
    }

    private suspend fun save(sourceName: String, temp: File, isMuted: Boolean) {
        val base = sourceName.substringBeforeLast('.', sourceName)
            .replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001F]"), "_").trim().take(80).ifEmpty { "video" }
        val wanted = base + (if (isMuted) "_sans_son" else "") + ".mp4"
        // Non annulable : une copie commencée est menée à son terme et comptée
        withContext(NonCancellable + Dispatchers.IO) {
            try {
                val saved = Saver.save(ctx, temp, wanted, "video/mp4", destinationTreeUri)
                outputs += BatchOutput(saved, displayName(saved) ?: wanted)
                if (isMuted) muted++
            } catch (e: Exception) {
                throw SaveFailed("enregistrement impossible (${e.message ?: "erreur d'écriture"})")
            }
        }
    }

    private class SaveFailed(message: String) : Exception(message)

    private fun checkSpace(uri: Uri) {
        val size = runCatching {
            ctx.contentResolver.openFileDescriptor(uri, "r")?.use { it.statSize }
        }.getOrNull() ?: return
        if (size <= 0) return
        // Fichier de travail + copie finale (la copie est sur ce même stockage pour le dossier par défaut)
        val needed = size * (if (destinationTreeUri == null) 2 else 1) + 50_000_000L
        if (ctx.cacheDir.usableSpace < needed)
            error("espace libre insuffisant (environ ${needed / 1_000_000} Mo nécessaires)")
    }

    private fun probe(open: MediaExtractor.() -> Unit): SourceInfo {
        val ex = MediaExtractor()
        return try {
            ex.open()
            var info = SourceInfo()
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME).orEmpty()
                val duration = if (f.containsKey(MediaFormat.KEY_DURATION)) f.getLong(MediaFormat.KEY_DURATION) else 0L
                if (mime.startsWith("video/") && info.videoMime == null) {
                    info = info.copy(videoMime = mime, durationUs = duration)
                } else if (mime.startsWith("audio/") && info.audioMime == null) {
                    val channels = if (f.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) f.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 0
                    info = info.copy(audioMime = mime, audioChannels = channels)
                }
            }
            info
        } catch (_: Exception) {
            SourceInfo() // conteneur illisible par Android : Media3 tentera quand même
        } finally {
            ex.release()
        }
    }

    private fun explain(info: SourceInfo, error: Exception?): String {
        val codecs = listOfNotNull(info.videoMime?.substringAfter('/'), info.audioMime?.substringAfter('/'))
            .joinToString(" + ")
        val reason = error?.message
        return "ce téléphone n'a pas pu la convertir" +
            (if (codecs.isNotEmpty()) " ($codecs)" else "") +
            (reason?.let { " – $it" } ?: "")
    }

    private fun displayName(uri: Uri): String? = runCatching {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { if (it.moveToFirst()) it.getString(0) else null }
    }.getOrNull()
}
