// Pont JNI entre Media Studio (Kotlin) et whisper.cpp — transcription 100 % hors ligne.
//
// Côté Kotlin : com.mediastudio.app.whisper.WhisperNative
//  - un « handle » (jlong) enveloppe un whisper_context + un drapeau d'annulation atomique ;
//  - les textes sont renvoyés en octets UTF-8 (jbyteArray) : whisper peut couper un caractère multi-octets
//    entre deux segments, ce que NewStringUTF ne tolère pas.

#include <jni.h>
#include <atomic>
#include <cstring>
#include <string>
#include <thread>
#include <algorithm>

#include "whisper.h"

#ifdef MS_ANDROID
#include <android/asset_manager.h>
#include <android/asset_manager_jni.h>
#include <android/log.h>
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "MsWhisper", __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, "MsWhisper", __VA_ARGS__)
#else
#include <cstdio>
#define LOGI(...) do { fprintf(stderr, __VA_ARGS__); fputc('\n', stderr); } while (0)
#define LOGW(...) LOGI(__VA_ARGS__)
#endif

namespace {

struct Handle {
    whisper_context * ctx = nullptr;
    std::atomic<bool> abort{false};
};

inline Handle * H(jlong h) { return reinterpret_cast<Handle *>(h); }

// Données transmises aux rappels de whisper_full (exécutés sur le thread appelant).
struct CallbackData {
    JNIEnv * env = nullptr;
    jobject cb = nullptr;
    jmethodID onProgress = nullptr;
    jmethodID onSegment = nullptr;
    Handle * handle = nullptr;
    int lastProgress = -1;
};

void log_to_android(ggml_log_level level, const char * text, void *) {
#ifdef MS_ANDROID
    int prio = level == GGML_LOG_LEVEL_ERROR ? ANDROID_LOG_ERROR
             : level == GGML_LOG_LEVEL_WARN ? ANDROID_LOG_WARN : ANDROID_LOG_DEBUG;
    __android_log_print(prio, "MsWhisper", "%s", text);
#else
    (void) level; (void) text;
#endif
}

jbyteArray toBytes(JNIEnv * env, const char * s) {
    const jsize n = s ? (jsize) strlen(s) : 0;
    jbyteArray arr = env->NewByteArray(n);
    if (arr && n > 0) env->SetByteArrayRegion(arr, 0, n, reinterpret_cast<const jbyte *>(s));
    return arr;
}

whisper_context * init_ctx(whisper_model_loader * loader, const char * path) {
    whisper_context_params cp = whisper_context_default_params();
    cp.use_gpu = false;
    cp.flash_attn = false;
    return loader ? whisper_init_with_params(loader, cp) : whisper_init_from_file_with_params(path, cp);
}

#ifdef MS_ANDROID
size_t asset_read(void * ctx, void * output, size_t read_size) {
    return (size_t) AAsset_read((AAsset *) ctx, output, read_size);
}
bool asset_eof(void * ctx) { return AAsset_getRemainingLength64((AAsset *) ctx) <= 0; }
void asset_close(void * ctx) { AAsset_close((AAsset *) ctx); }
#endif

} // namespace

extern "C" {

#define FN(name) Java_com_mediastudio_app_whisper_WhisperNative_##name

JNIEXPORT jlong JNICALL FN(initFromFile)(JNIEnv * env, jobject, jstring jpath) {
    whisper_log_set(log_to_android, nullptr);
    const char * path = env->GetStringUTFChars(jpath, nullptr);
    whisper_context * ctx = init_ctx(nullptr, path);
    env->ReleaseStringUTFChars(jpath, path);
    if (!ctx) return 0;
    auto * h = new Handle();
    h->ctx = ctx;
    return reinterpret_cast<jlong>(h);
}

JNIEXPORT jlong JNICALL FN(initFromAsset)(JNIEnv * env, jobject, jobject jassets, jstring jpath) {
#ifdef MS_ANDROID
    whisper_log_set(log_to_android, nullptr);
    AAssetManager * mgr = AAssetManager_fromJava(env, jassets);
    const char * path = env->GetStringUTFChars(jpath, nullptr);
    AAsset * asset = AAssetManager_open(mgr, path, AASSET_MODE_STREAMING);
    env->ReleaseStringUTFChars(jpath, path);
    if (!asset) { LOGW("Modèle introuvable dans les assets"); return 0; }
    whisper_model_loader loader{};
    loader.context = asset;
    loader.read = asset_read;
    loader.eof = asset_eof;
    loader.close = asset_close;
    whisper_context * ctx = init_ctx(&loader, nullptr);
    if (!ctx) return 0;
    auto * h = new Handle();
    h->ctx = ctx;
    return reinterpret_cast<jlong>(h);
#else
    (void) env; (void) jassets; (void) jpath;
    return 0;
#endif
}

JNIEXPORT void JNICALL FN(free)(JNIEnv *, jobject, jlong handle) {
    Handle * h = H(handle);
    if (!h) return;
    if (h->ctx) whisper_free(h->ctx);
    delete h;
}

JNIEXPORT void JNICALL FN(abort)(JNIEnv *, jobject, jlong handle) {
    if (Handle * h = H(handle)) h->abort.store(true);
}

/**
 * Transcrit [samples] (PCM float 16 kHz mono). Renvoie 0 si tout va bien, 1 si annulé, autre valeur = erreur.
 * cb : objet Kotlin avec onProgress(int) et onSegment(long t0Ms, long t1Ms, byte[] utf8).
 */
JNIEXPORT jint JNICALL FN(transcribe)(
        JNIEnv * env, jobject, jlong handle, jfloatArray jsamples, jint nSamples, jstring jlang,
        jboolean translate, jint threads, jint maxLen, jint beamSize, jstring jprompt, jobject cb) {
    Handle * h = H(handle);
    if (!h || !h->ctx) return -1;
    h->abort.store(false);

    CallbackData data;
    data.env = env;
    data.cb = cb;
    data.handle = h;
    if (cb) {
        jclass cls = env->GetObjectClass(cb);
        data.onProgress = env->GetMethodID(cls, "onProgress", "(I)V");
        data.onSegment = env->GetMethodID(cls, "onSegment", "(JJ[B)V");
        env->DeleteLocalRef(cls);
        if (env->ExceptionCheck()) { env->ExceptionClear(); data.onProgress = nullptr; data.onSegment = nullptr; }
    }

    whisper_full_params p = whisper_full_default_params(
            beamSize > 1 ? WHISPER_SAMPLING_BEAM_SEARCH : WHISPER_SAMPLING_GREEDY);
    if (beamSize > 1) p.beam_search.beam_size = beamSize;
    const int hw = (int) std::thread::hardware_concurrency();
    p.n_threads = threads > 0 ? threads : std::max(1, std::min(4, hw));
    p.print_realtime = false;
    p.print_progress = false;
    p.print_timestamps = false;
    p.print_special = false;
    p.translate = translate;
    p.no_context = false;
    p.single_segment = false;
    p.suppress_blank = true;
    if (maxLen > 0) {
        // Segments courts pour les sous-titres : horodatage par jeton + coupure sur les mots
        p.token_timestamps = true;
        p.max_len = maxLen;
        p.split_on_word = true;
    }

    const char * lang = env->GetStringUTFChars(jlang, nullptr);
    std::string language = lang ? lang : "auto";
    env->ReleaseStringUTFChars(jlang, lang);
    p.language = language.c_str();
    p.detect_language = false;

    std::string prompt;
    if (jprompt) {
        const char * pr = env->GetStringUTFChars(jprompt, nullptr);
        if (pr) prompt = pr;
        env->ReleaseStringUTFChars(jprompt, pr);
    }
    if (!prompt.empty()) p.initial_prompt = prompt.c_str();

    p.progress_callback = [](whisper_context *, whisper_state *, int progress, void * ud) {
        auto * d = static_cast<CallbackData *>(ud);
        if (!d->onProgress || progress == d->lastProgress) return;
        d->lastProgress = progress;
        d->env->CallVoidMethod(d->cb, d->onProgress, (jint) progress);
        if (d->env->ExceptionCheck()) { d->env->ExceptionClear(); d->handle->abort.store(true); }
    };
    p.progress_callback_user_data = &data;

    p.new_segment_callback = [](whisper_context * ctx, whisper_state *, int nNew, void * ud) {
        auto * d = static_cast<CallbackData *>(ud);
        if (!d->onSegment) return;
        const int n = whisper_full_n_segments(ctx);
        for (int i = std::max(0, n - nNew); i < n; ++i) {
            jbyteArray txt = toBytes(d->env, whisper_full_get_segment_text(ctx, i));
            d->env->CallVoidMethod(d->cb, d->onSegment,
                                   (jlong) (whisper_full_get_segment_t0(ctx, i) * 10),
                                   (jlong) (whisper_full_get_segment_t1(ctx, i) * 10), txt);
            d->env->DeleteLocalRef(txt);
            if (d->env->ExceptionCheck()) { d->env->ExceptionClear(); d->handle->abort.store(true); }
        }
    };
    p.new_segment_callback_user_data = &data;

    // Pas d'appel JNI ici : ce rappel peut être consulté pendant les calculs ggml
    p.abort_callback = [](void * ud) -> bool { return static_cast<Handle *>(ud)->abort.load(); };
    p.abort_callback_user_data = h;
    p.encoder_begin_callback = [](whisper_context *, whisper_state *, void * ud) -> bool {
        return !static_cast<Handle *>(ud)->abort.load();
    };
    p.encoder_begin_callback_user_data = h;

    jfloat * samples = env->GetFloatArrayElements(jsamples, nullptr);
    const jsize len = env->GetArrayLength(jsamples);
    const int n = std::max(0, std::min((int) nSamples, (int) len));
    const int rc = whisper_full(h->ctx, p, samples, n);
    env->ReleaseFloatArrayElements(jsamples, samples, JNI_ABORT);

    if (h->abort.load()) return 1;
    return rc == 0 ? 0 : (rc < 0 ? rc : -100);
}

JNIEXPORT jint JNICALL FN(segmentCount)(JNIEnv *, jobject, jlong handle) {
    Handle * h = H(handle);
    return h && h->ctx ? whisper_full_n_segments(h->ctx) : 0;
}

JNIEXPORT jlong JNICALL FN(segmentT0)(JNIEnv *, jobject, jlong handle, jint i) {
    return (jlong) whisper_full_get_segment_t0(H(handle)->ctx, i) * 10;
}

JNIEXPORT jlong JNICALL FN(segmentT1)(JNIEnv *, jobject, jlong handle, jint i) {
    return (jlong) whisper_full_get_segment_t1(H(handle)->ctx, i) * 10;
}

JNIEXPORT jbyteArray JNICALL FN(segmentText)(JNIEnv * env, jobject, jlong handle, jint i) {
    return toBytes(env, whisper_full_get_segment_text(H(handle)->ctx, i));
}

JNIEXPORT jstring JNICALL FN(detectedLanguage)(JNIEnv * env, jobject, jlong handle) {
    Handle * h = H(handle);
    const int id = h && h->ctx ? whisper_full_lang_id(h->ctx) : -1;
    const char * s = id >= 0 ? whisper_lang_str(id) : nullptr;
    return env->NewStringUTF(s ? s : "");
}

JNIEXPORT jboolean JNICALL FN(isMultilingual)(JNIEnv *, jobject, jlong handle) {
    Handle * h = H(handle);
    return h && h->ctx && whisper_is_multilingual(h->ctx) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jstring JNICALL FN(modelType)(JNIEnv * env, jobject, jlong handle) {
    Handle * h = H(handle);
    const char * s = h && h->ctx ? whisper_model_type_readable(h->ctx) : nullptr;
    return env->NewStringUTF(s ? s : "");
}

JNIEXPORT jstring JNICALL FN(systemInfo)(JNIEnv * env, jobject) {
    return env->NewStringUTF(whisper_print_system_info());
}

} // extern "C"
