# Moteur de transcription hors ligne de Media Studio : whisper.cpp (v1.9.5, copie allégée : CPU uniquement)
cmake_minimum_required(VERSION 3.22.1)
project(mediastudio_whisper C CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
# Les bibliothèques statiques sont liées dans un .so : code indépendant de la position obligatoire
set(CMAKE_POSITION_INDEPENDENT_CODE ON)
if (NOT CMAKE_BUILD_TYPE)
    set(CMAKE_BUILD_TYPE Release)
endif()

# whisper.cpp et ggml en bibliothèques statiques, sans exemples, tests ni serveur
set(BUILD_SHARED_LIBS OFF CACHE BOOL "" FORCE)
set(WHISPER_BUILD_TESTS OFF CACHE BOOL "" FORCE)
set(WHISPER_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
set(WHISPER_BUILD_SERVER OFF CACHE BOOL "" FORCE)
set(WHISPER_ALL_WARNINGS OFF CACHE BOOL "" FORCE)
set(WHISPER_CURL OFF CACHE BOOL "" FORCE)
set(WHISPER_SDL2 OFF CACHE BOOL "" FORCE)
# GGML_NATIVE=OFF : pas de -march=native (compilation croisée Android) ; aucun backend GPU
set(GGML_NATIVE OFF CACHE BOOL "" FORCE)
set(GGML_OPENMP OFF CACHE BOOL "" FORCE)
set(GGML_LLAMAFILE OFF CACHE BOOL "" FORCE)
set(GGML_BACKEND_DL OFF CACHE BOOL "" FORCE)
set(GGML_CPU_ALL_VARIANTS OFF CACHE BOOL "" FORCE)
set(GGML_BUILD_TESTS OFF CACHE BOOL "" FORCE)
set(GGML_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)

add_subdirectory(whisper.cpp)

add_library(mediastudio_whisper SHARED whisper_jni.cpp)
target_link_libraries(mediastudio_whisper PRIVATE whisper)

if (ANDROID)
    find_library(LOG_LIB log)
    find_library(ANDROID_LIB android)
    target_link_libraries(mediastudio_whisper PRIVATE ${LOG_LIB} ${ANDROID_LIB})
    target_compile_definitions(mediastudio_whisper PRIVATE MS_ANDROID=1)
endif()

if (NOT CMAKE_BUILD_TYPE STREQUAL "Debug")
    target_compile_options(mediastudio_whisper PRIVATE -O3 -fvisibility=hidden -ffunction-sections -fdata-sections)
    if (ANDROID)
        target_link_options(mediastudio_whisper PRIVATE -Wl,--gc-sections -Wl,--exclude-libs,ALL)
    endif()
endif()
