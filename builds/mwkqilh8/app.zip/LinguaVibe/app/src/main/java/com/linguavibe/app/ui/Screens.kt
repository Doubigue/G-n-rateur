package com.linguavibe.app.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linguavibe.app.data.CourseRepository
import com.linguavibe.app.data.LanguageInfo
import com.linguavibe.app.data.Languages
import com.linguavibe.app.data.Lesson
import com.linguavibe.app.data.Levels
import com.linguavibe.app.data.ProgressStore
import com.linguavibe.app.speech.Speaker
import com.linguavibe.app.speech.VoskManager
import kotlinx.coroutines.launch

sealed class Screen {
    object Home : Screen()
    data class OpenCourse(val lang: String) : Screen()
    data class OpenLesson(val lang: String, val lessonId: String) : Screen()
    object Models : Screen()
    object Settings : Screen()
    object Firebase : Screen()
}

@Composable
fun AppRoot(speaker: Speaker, progress: ProgressStore) {
    val stack = remember { mutableStateListOf<Screen>(Screen.Home) }
    val push: (Screen) -> Unit = { stack.add(it) }
    val pop: () -> Unit = { if (stack.size > 1) stack.removeAt(stack.lastIndex) }
    val openModels: () -> Unit = { if (stack.last() != Screen.Models) stack.add(Screen.Models) }

    BackHandler(enabled = stack.size > 1) { pop() }

    CompositionLocalProvider(LocalSpeaker provides speaker, LocalOpenModels provides openModels) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            AnimatedContent(
                targetState = stack.last(),
                transitionSpec = {
                    (fadeIn(tween(280)) + slideInHorizontally(tween(280)) { it / 8 }) togetherWith fadeOut(tween(180))
                },
                label = "navigation"
            ) { screen ->
                when (screen) {
                    is Screen.Home -> HomeScreen(
                        progress, { push(Screen.OpenCourse(it)) }, openModels, { push(Screen.Firebase) }
                    ) { push(Screen.Settings) }
                    is Screen.OpenCourse -> CourseScreen(
                        Languages.byCode(screen.lang), progress, pop
                    ) { push(Screen.OpenLesson(screen.lang, it)) }
                    is Screen.OpenLesson -> LessonScreen(Languages.byCode(screen.lang), screen.lessonId, progress, pop)
                    is Screen.Models -> ModelsScreen(pop)
                    is Screen.Settings -> SettingsScreen(pop)
                    is Screen.Firebase -> FirebaseScreen(pop)
                }
            }
        }
    }
}

// ------------------------------------------------------------ Éléments communs

@Composable
fun TopBar(title: String, subtitle: String?, color: Color, onBack: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(color)
            .padding(horizontal = 6.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "←", color = Color.White, fontSize = 24.sp,
            modifier = Modifier
                .clip(CircleShape)
                .clickable(onClick = onBack)
                .padding(horizontal = 14.dp, vertical = 4.dp)
        )
        Column(Modifier.weight(1f)) {
            Text(
                title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            if (subtitle != null) Text(subtitle, color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
        }
    }
}

@Composable
fun CardBox(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(Color.White)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        content = content
    )
}

@Composable
fun SectionTitle(title: String, hint: String? = null) {
    Column {
        Text(title, fontWeight = FontWeight.ExtraBold, fontSize = 19.sp, color = Ink)
        if (hint != null) Text(hint, fontSize = 13.sp, color = InkSoft)
    }
}

@Composable
fun Chip(text: String, color: Color) {
    Text(
        text, color = color, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.13f))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    )
}

// --------------------------------------------------------------------- Accueil

@Composable
fun HomeScreen(
    progress: ProgressStore,
    onOpenCourse: (String) -> Unit,
    onOpenModels: () -> Unit,
    onOpenFirebase: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val context = LocalContext.current
    val version = VoskManager.installsVersion
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        SceneBanner(
            emoji = "🌍",
            extras = listOf("💬", "🎧", "✨"),
            color = Indigo,
            title = "LinguaVibe",
            subtitle = "Parlez une nouvelle langue, leçon après leçon",
            tag = "🔥 ${progress.streak} j   ⭐ ${progress.xp} XP"
        )
        SectionTitle("Choisissez une langue")
        Languages.courses.forEachIndexed { index, lang ->
            val installed = remember(version, lang.code) { VoskManager.isInstalled(context, lang.code) }
            val course = remember(lang.code, CourseRepository.version) { CourseRepository.load(context, lang.code) }
            val done = course.lessons.count { progress.isCompleted(it.id) }
            StaggerIn(index) {
                LanguageCard(lang, installed, course.lessons.size, done) {
                    if (lang.available) onOpenCourse(lang.code)
                }
            }
        }
        Button(
            onClick = onOpenModels,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            contentPadding = PaddingValues(vertical = 14.dp)
        ) {
            Text("🎙  Modèles vocaux (Vosk)", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
        OutlinedButton(
            onClick = onOpenSettings,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            contentPadding = PaddingValues(vertical = 14.dp)
        ) {
            Text("⚙️  Paramètres · voix réaliste", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
        OutlinedButton(
            onClick = onOpenFirebase,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            contentPadding = PaddingValues(vertical = 14.dp)
        ) {
            Text("☁️  Données Firebase", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
        if (com.linguavibe.app.data.FirebaseSync.busy) {
            Text("☁️ Mise à jour des cours…", fontSize = 13.sp, color = InkSoft)
        }
        Text(
            "La correction de la prononciation fonctionne hors ligne grâce à un modèle vocal par langue.",
            fontSize = 13.sp, color = InkSoft
        )
    }
}

@Composable
private fun LanguageCard(lang: LanguageInfo, modelInstalled: Boolean, total: Int, done: Int, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .alpha(if (lang.available) 1f else 0.6f)
            .clip(RoundedCornerShape(22.dp))
            .background(Color.White)
            .clickable(enabled = lang.available, onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (lang.available) FloatingEmoji(lang.flag, 40) else Text(lang.flag, fontSize = 40.sp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text("${lang.name} · ${lang.nativeName}", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Ink)
            if (lang.available) {
                Text("$done / $total leçons validées", fontSize = 13.sp, color = InkSoft)
                AnimatedBar(if (total == 0) 0f else done.toFloat() / total, Good)
            } else {
                Text("Cours bientôt disponible", fontSize = 13.sp, color = InkSoft)
            }
            Chip(
                if (modelInstalled) "🎙 Modèle vocal installé" else "🎙 Modèle vocal à installer",
                if (modelInstalled) Good else Warn
            )
        }
        if (lang.available) Text("›", fontSize = 30.sp, color = Indigo)
    }
}

// ----------------------------------------------------------------------- Cours

@Composable
fun CourseScreen(lang: LanguageInfo, progress: ProgressStore, onBack: () -> Unit, onOpenLesson: (String) -> Unit) {
    val context = LocalContext.current
    val course = remember(lang.code, CourseRepository.version) { CourseRepository.load(context, lang.code) }
    val done = course.lessons.count { progress.isCompleted(it.id) }
    Column(Modifier.fillMaxSize()) {
        TopBar("${lang.flag}  ${lang.name}", "$done / ${course.lessons.size} leçons validées", IndigoDark, onBack)
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item(key = "progress") {
                CardBox {
                    Text("Votre parcours : de débutant à la maîtrise", fontWeight = FontWeight.Bold, color = Ink)
                    AnimatedBar(if (course.lessons.isEmpty()) 0f else done.toFloat() / course.lessons.size, Indigo)
                    Text(
                        "Chaque leçon : vocabulaire illustré, grammaire, dialogue, prononciation corrigée, quiz et devoir.",
                        fontSize = 13.sp, color = InkSoft
                    )
                }
            }
            Levels.order.forEach { level ->
                val lessons = course.lessons.filter { it.level == level }
                if (lessons.isNotEmpty()) {
                    item(key = "level-$level") {
                        Row(
                            Modifier.padding(top = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                level, color = Color.White, fontWeight = FontWeight.ExtraBold,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(levelColor(level))
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                            Text(Levels.label(level), fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Ink)
                        }
                    }
                    items(lessons, key = { it.id }) { lesson ->
                        LessonRow(lesson, progress.bestScore(lesson.id), progress.isCompleted(lesson.id)) {
                            onOpenLesson(lesson.id)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LessonRow(lesson: Lesson, best: Int?, completed: Boolean, onClick: () -> Unit) {
    val color = levelColor(lesson.level)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Color.White)
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(52.dp)
                .clip(CircleShape)
                .background(color.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center
        ) { Text(lesson.emoji, fontSize = 26.sp) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("Leçon ${lesson.number}", fontSize = 12.sp, color = color, fontWeight = FontWeight.Bold)
            Text(lesson.title, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Ink)
            Text(lesson.titleTr, fontSize = 13.sp, color = InkSoft)
        }
        when {
            completed -> Chip("✅ ${best ?: 0}%", Good)
            best != null -> Chip("${best}%", Warn)
            else -> Text("▶", fontSize = 18.sp, color = color)
        }
    }
}

// --------------------------------------------------------------- Modèles vocaux

@Composable
fun ModelsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val version = VoskManager.installsVersion
    val status = remember { mutableStateMapOf<String, String>() }
    val busy = remember { mutableStateMapOf<String, Float>() }
    var pendingLang by rememberSaveable { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val lang = pendingLang
        if (uri != null && lang != null) {
            scope.launch {
                busy[lang] = -1f
                status[lang] = "Décompression du modèle…"
                try {
                    val input = context.contentResolver.openInputStream(uri)
                        ?: throw IllegalStateException("Fichier illisible")
                    input.use { stream ->
                        VoskManager.installZip(context, lang, stream) { bytes ->
                            status[lang] = "Décompression… ${bytes / (1024 * 1024)} Mo"
                        }
                    }
                    status[lang] = "✅ Modèle installé"
                } catch (e: Exception) {
                    status[lang] = "❌ ${e.message ?: "Échec de l'import"}"
                } finally {
                    busy.remove(lang)
                }
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        TopBar("Modèles vocaux", "Reconnaissance hors ligne Vosk", IndigoDark, onBack)
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            CardBox {
                Text("Comment ça marche ?", fontWeight = FontWeight.Bold, color = Ink)
                Text(
                    "Chaque langue a besoin d'un modèle Vosk pour écouter et corriger votre prononciation.\n" +
                        "• ⭐ Précision maximale : le meilleur modèle, mais très lourd (plus de 1 Go) et gourmand en mémoire.\n" +
                        "• 🪶 Léger : conçu pour les téléphones, fonctionne partout.\n" +
                        "• Importer un ZIP : choisissez un fichier .zip déjà téléchargé depuis " +
                        "alphacephei.com/vosk/models (tout modèle Vosk est accepté).\n" +
                        "Un seul modèle par langue : le nouveau remplace l'ancien.",
                    fontSize = 14.sp, color = InkSoft
                )
            }
            Languages.all.forEach { lang ->
                val code = lang.code
                val installedName = remember(version, code) { VoskManager.installedName(context, code) }
                val sizeMb = remember(version, code) { VoskManager.installedSizeMb(context, code) }
                val progressValue = busy[code]
                CardBox {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(lang.flag, fontSize = 34.sp)
                        Spacer(Modifier.width(12.dp))
                        Text(
                            if (lang.native) "${lang.name} (langue maternelle)" else lang.name,
                            fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Ink,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    if (lang.native) {
                        Text(
                            "Permet de répondre à voix haute en français dans les quiz d'écoute.",
                            fontSize = 13.sp, color = InkSoft
                        )
                    }
                    if (installedName != null) {
                        Chip("✅ Installé : $installedName ($sizeMb Mo)", Good)
                    } else {
                        Chip("Aucun modèle installé", Warn)
                    }
                    if (progressValue != null) {
                        if (progressValue >= 0f) AnimatedBar(progressValue, Indigo)
                        else LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    }
                    status[code]?.let { Text(it, fontSize = 13.sp, color = Ink) }

                    lang.models.forEach { model ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(Cream)
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(
                                    "${model.label} · ${model.size}",
                                    fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Indigo
                                )
                                Text(model.name, fontSize = 12.sp, color = Ink)
                                Text(model.note, fontSize = 12.sp, color = InkSoft, lineHeight = 16.sp)
                            }
                            Spacer(Modifier.width(8.dp))
                            Button(
                                enabled = progressValue == null,
                                onClick = {
                                    scope.launch {
                                        busy[code] = 0f
                                        status[code] = "Téléchargement de ${model.name}…"
                                        try {
                                            VoskManager.download(context, code, model.url) { fraction ->
                                                busy[code] = fraction
                                                status[code] = if (fraction >= 0f) {
                                                    "Téléchargement… ${(fraction * 100).toInt()} %"
                                                } else {
                                                    "Décompression du modèle…"
                                                }
                                            }
                                            status[code] = "✅ ${model.name} installé"
                                        } catch (e: Exception) {
                                            status[code] = "❌ ${e.message ?: "Échec du téléchargement"}"
                                        } finally {
                                            busy.remove(code)
                                        }
                                    }
                                }
                            ) { Text("⬇") }
                        }
                    }

                    OutlinedButton(
                        enabled = progressValue == null,
                        onClick = {
                            pendingLang = code
                            picker.launch(
                                arrayOf(
                                    "application/zip",
                                    "application/x-zip-compressed",
                                    "application/octet-stream"
                                )
                            )
                        }
                    ) { Text("📂 Importer un ZIP") }
                    if (installedName != null && progressValue == null) {
                        TextButton(onClick = {
                            VoskManager.delete(context, code)
                            status[code] = "Modèle supprimé"
                        }) { Text("🗑 Supprimer le modèle installé", color = Bad) }
                    }
                }
            }
        }
    }
}
