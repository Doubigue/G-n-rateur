package com.linguavibe.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import com.linguavibe.app.speech.Speaker

val Indigo = Color(0xFF5B4BDB)
val IndigoDark = Color(0xFF4A3BC9)
val Coral = Color(0xFFFF7A59)
val Cream = Color(0xFFF6F3FF)
val Ink = Color(0xFF1E1B3A)
val InkSoft = Color(0xFF6B6785)
val Good = Color(0xFF1FA971)
val Warn = Color(0xFFF29D38)
val Bad = Color(0xFFE5484D)

private val scheme = lightColorScheme(
    primary = Indigo,
    onPrimary = Color.White,
    secondary = Coral,
    onSecondary = Color.White,
    background = Cream,
    onBackground = Ink,
    surface = Color.White,
    onSurface = Ink,
    surfaceVariant = Color(0xFFECE8FB),
    onSurfaceVariant = InkSoft,
    error = Bad
)

fun levelColor(level: String): Color = when (level) {
    "A1" -> Color(0xFF1FA971)
    "A2" -> Color(0xFF1498C2)
    "B1" -> Color(0xFF5B4BDB)
    "B2" -> Color(0xFFA548D6)
    "C1" -> Color(0xFFE8663D)
    "C2" -> Color(0xFFD43F6B)
    else -> Indigo
}

fun scoreColor(score: Int): Color = when {
    score >= 80 -> Good
    score >= 50 -> Warn
    else -> Bad
}

val LocalSpeaker = staticCompositionLocalOf<Speaker> { error("Speaker manquant") }
val LocalOpenModels = staticCompositionLocalOf<() -> Unit> { {} }

@Composable
fun LinguaTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, content = content)
}
