package com.linguavibe.app.speech

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.setValue
import com.k2fsa.sherpa.onnx.OfflineTts
import com.k2fsa.sherpa.onnx.OfflineTtsConfig
import com.k2fsa.sherpa.onnx.OfflineTtsKokoroModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsVitsModelConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import kotlin.coroutines.coroutineContext

enum class NeuralEngine(val label: String) { KOKORO("Kokoro"), PIPER("Piper") }

/**
 * Une voix hors ligne téléchargeable (archives publiées par le projet sherpa-onnx).
 * [langs] : codes des langues qu'elle sait lire.
 */
data class NeuralVoice(
    val id: String,
    val engine: NeuralEngine,
    val langs: List<String>,
    val label: String,
    val size: String,
    val note: String
) {
    val url: String get() = "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/$id.tar.bz2"
}

/** État d'un téléchargement en cours (fraction 0..1, ou -1 si inconnue). */
data class InstallState(val progress: Float, val step: String, val error: String? = null)

/**
 * Voix neuronales hors ligne : Kokoro (multilingue, très naturelle) et Piper (une voix par langue).
 *
 * Les voix ne sont pas livrées avec l'application : on les télécharge une seule fois depuis
 * l'écran Paramètres. Elles sont rangées dans files/tts/<identifiant>/ et fonctionnent ensuite
 * sans connexion.
 */
object NeuralVoices {
    // ------------------------------------------------------------ Catalogue

    private const val MEDIUM = "Voix de qualité moyenne, bon compromis entre naturel et rapidité."
    private const val LOW = "Version allégée : plus rapide et plus petite, un peu moins naturelle."

    val kokoro = NeuralVoice(
        "kokoro-multi-lang-v1_0", NeuralEngine.KOKORO, listOf("es", "en", "pt", "zh", "fr"),
        "Kokoro multilingue", "plus de 300 Mo",
        "Une seule installation pour l'espagnol, l'anglais, le portugais du Brésil, le chinois et le français. " +
            "Voix très naturelles. Prévoir un téléphone récent (4 Go de RAM ou plus). " +
            "Kokoro ne parle ni russe ni arabe : installez Piper pour ces deux langues."
    )

    val piper = listOf(
        NeuralVoice("vits-piper-es_ES-davefx-medium", NeuralEngine.PIPER, listOf("es"), "Espagnol · Davefx", "≈ 65 Mo", MEDIUM),
        NeuralVoice("vits-piper-en_US-amy-medium", NeuralEngine.PIPER, listOf("en"), "Anglais · Amy", "≈ 65 Mo", MEDIUM),
        NeuralVoice("vits-piper-en_US-amy-low", NeuralEngine.PIPER, listOf("en"), "Anglais · Amy (légère)", "≈ 25 Mo", LOW),
        NeuralVoice("vits-piper-pt_BR-faber-medium", NeuralEngine.PIPER, listOf("pt"), "Portugais · Faber", "≈ 65 Mo", MEDIUM),
        NeuralVoice("vits-piper-ru_RU-irina-medium", NeuralEngine.PIPER, listOf("ru"), "Russe · Irina", "≈ 65 Mo", MEDIUM),
        NeuralVoice("vits-piper-ru_RU-ruslan-medium", NeuralEngine.PIPER, listOf("ru"), "Russe · Ruslan", "≈ 65 Mo", MEDIUM),
        NeuralVoice("vits-piper-zh_CN-xiao_ya-medium", NeuralEngine.PIPER, listOf("zh"), "Chinois · Xiao Ya", "≈ 65 Mo", MEDIUM),
        NeuralVoice("vits-piper-zh_CN-huayan-medium", NeuralEngine.PIPER, listOf("zh"), "Chinois · Huayan", "≈ 65 Mo", MEDIUM),
        NeuralVoice("vits-piper-ar_JO-kareem-medium", NeuralEngine.PIPER, listOf("ar"), "Arabe · Kareem", "≈ 65 Mo", MEDIUM),
        NeuralVoice("vits-piper-ar_JO-kareem-low", NeuralEngine.PIPER, listOf("ar"), "Arabe · Kareem (légère)", "≈ 25 Mo", LOW),
        NeuralVoice("vits-piper-fr_FR-siwis-medium", NeuralEngine.PIPER, listOf("fr"), "Français · Siwis", "≈ 65 Mo", MEDIUM)
    )

    val all: List<NeuralVoice> get() = listOf(kokoro) + piper

    /** Voix Kokoro choisie pour chaque langue : (voix féminine, voix masculine). */
    private val kokoroSpeakers = mapOf(
        "en" to (3 to 16),   // af_heart, am_michael
        "es" to (28 to 29),  // ef_dora, em_alex
        "pt" to (42 to 43),  // pf_dora, pm_alex
        "zh" to (47 to 50),  // zf_xiaoxiao, zm_yunxi
        "fr" to (30 to 30)   // ff_siwis
    )

    /** Langue donnée au phonétiseur de Kokoro (vide : dictionnaires anglais et chinois du modèle). */
    private val kokoroLang = mapOf("es" to "es", "pt" to "pt-br", "fr" to "fr", "en" to "", "zh" to "")

    // ------------------------------------------------------------ Installation

    /** Incrémenté à chaque installation / suppression pour rafraîchir l'interface. */
    var version by mutableIntStateOf(0)
        private set

    /** Téléchargements en cours, par identifiant de voix. */
    val installing = mutableStateMapOf<String, InstallState>()

    private val jobs = HashMap<String, Job>()
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private fun baseDir(context: Context) = File(context.filesDir, "tts")
    private fun voiceDir(context: Context, voice: NeuralVoice) = File(baseDir(context), voice.id)

    /** Dossier qui contient tokens.txt (l'archive ajoute un dossier de premier niveau). */
    private fun findRoot(dir: File, depth: Int = 0): File? {
        if (!dir.isDirectory) return null
        if (File(dir, "tokens.txt").isFile) return dir
        if (depth >= 2) return null
        dir.listFiles()?.forEach { child -> if (child.isDirectory) findRoot(child, depth + 1)?.let { return it } }
        return null
    }

    fun isInstalled(context: Context, voice: NeuralVoice): Boolean = findRoot(voiceDir(context, voice)) != null

    fun sizeMb(context: Context, voice: NeuralVoice): Long {
        val dir = voiceDir(context, voice)
        if (!dir.exists()) return 0
        return dir.walkTopDown().filter { it.isFile }.sumOf { it.length() } / (1024 * 1024)
    }

    fun installed(context: Context): List<NeuralVoice> = all.filter { isInstalled(context, it) }

    /** Lance le téléchargement en arrière-plan (il continue si l'on quitte l'écran). */
    fun install(context: Context, voice: NeuralVoice) {
        if (jobs[voice.id]?.isActive == true) return
        val app = context.applicationContext
        installing[voice.id] = InstallState(0f, "Connexion…")
        jobs[voice.id] = ioScope.launch {
            try {
                download(app, voice)
                withContext(Dispatchers.Main) {
                    installing.remove(voice.id)
                    version++
                }
            } catch (e: Exception) {
                val message = if (e is kotlinx.coroutines.CancellationException) null
                else e.message ?: "Installation impossible"
                withContext(Dispatchers.Main + kotlinx.coroutines.NonCancellable) {
                    if (message == null) installing.remove(voice.id)
                    else installing[voice.id] = InstallState(0f, "", message)
                }
            }
        }
    }

    fun cancel(voice: NeuralVoice) {
        jobs.remove(voice.id)?.cancel()
        installing.remove(voice.id)
    }

    fun clearError(voice: NeuralVoice) {
        if (installing[voice.id]?.error != null) installing.remove(voice.id)
    }

    suspend fun delete(context: Context, voice: NeuralVoice) {
        lock.withLock {
            if (loadedKey?.startsWith(voice.id) == true) releaseEngine()
        }
        withContext(Dispatchers.IO) { voiceDir(context, voice).deleteRecursively() }
        version++
    }

    private suspend fun report(id: String, progress: Float, step: String) =
        withContext(Dispatchers.Main) { installing[id] = InstallState(progress, step) }

    private suspend fun download(context: Context, voice: NeuralVoice) {
        val archive = File(context.cacheDir, "${voice.id}.tar.bz2")
        try {
            val connection = URL(voice.url).openConnection() as HttpURLConnection
            connection.connectTimeout = 20_000
            connection.readTimeout = 30_000
            connection.instanceFollowRedirects = true
            var total: Long
            try {
                if (connection.responseCode !in 200..299) {
                    throw IllegalStateException("Téléchargement impossible (code ${connection.responseCode})")
                }
                total = connection.contentLengthLong
                // Place de l'archive + celle de la voix décompressée.
                if (total > 0 && context.filesDir.usableSpace < total * 5 / 2) {
                    throw IllegalStateException("Espace insuffisant : libérez environ ${total * 5 / 2 / (1024 * 1024)} Mo.")
                }
                var done = 0L
                var last = 0L
                val buffer = ByteArray(64 * 1024)
                connection.inputStream.use { ins ->
                    FileOutputStream(archive).use { out ->
                        while (true) {
                            coroutineContext.ensureActive()
                            val n = ins.read(buffer)
                            if (n < 0) break
                            out.write(buffer, 0, n)
                            done += n
                            if (done - last > 512 * 1024) {
                                last = done
                                val mb = done / (1024 * 1024)
                                report(
                                    voice.id, if (total > 0) done.toFloat() / total else -1f,
                                    if (total > 0) "Téléchargement : $mb / ${total / (1024 * 1024)} Mo" else "Téléchargement : $mb Mo"
                                )
                            }
                        }
                    }
                }
                if (total <= 0) total = archive.length()
            } finally {
                connection.disconnect()
            }
            extract(voice, archive, total, File(baseDir(context), voice.id))
        } finally {
            archive.delete()
        }
    }

    /** Décompresse une archive .tar.bz2 (lecteur tar minimal : fichiers, dossiers, noms longs). */
    private suspend fun extract(voice: NeuralVoice, archive: File, total: Long, target: File) {
        val tmp = File(target.parentFile, "${voice.id}.tmp")
        tmp.deleteRecursively()
        tmp.mkdirs()
        val base = tmp.canonicalPath + File.separator
        try {
            val counting = CountingStream(FileInputStream(archive))
            BZip2CompressorInputStream(BufferedInputStream(counting, 256 * 1024)).use { tar ->
                val header = ByteArray(512)
                val buffer = ByteArray(64 * 1024)
                var longName: String? = null
                var last = 0L
                while (true) {
                    coroutineContext.ensureActive()
                    if (!readFully(tar, header)) break
                    if (header.all { it == 0.toByte() }) break
                    val size = octal(header, 124, 12)
                    val type = header[156].toInt().toChar()
                    var name = longName ?: run {
                        val prefix = text(header, 345, 155)
                        val plain = text(header, 0, 100)
                        if (prefix.isNotEmpty()) "$prefix/$plain" else plain
                    }
                    longName = null
                    when (type) {
                        'L' -> { // nom long GNU : le contenu est le nom de l'entrée suivante
                            longName = String(readBytes(tar, size), Charsets.UTF_8).trimEnd('\u0000', '\n')
                            skipPadding(tar, size)
                            continue
                        }
                        'x' -> { // en-tête pax : on récupère « path= » si présent
                            val pax = String(readBytes(tar, size), Charsets.UTF_8)
                            Regex("""\d+ path=([^\n]*)\n""").find(pax)?.let { longName = it.groupValues[1] }
                            skipPadding(tar, size)
                            continue
                        }
                        'g' -> {
                            skip(tar, size); skipPadding(tar, size); continue
                        }
                    }
                    name = name.removePrefix("./")
                    val out = File(tmp, name)
                    if (!(out.canonicalPath + File.separator).startsWith(base)) {
                        throw SecurityException("Archive invalide")
                    }
                    when (type) {
                        '5' -> out.mkdirs()
                        '0', '\u0000', '7' -> {
                            out.parentFile?.mkdirs()
                            FileOutputStream(out).use { fos ->
                                var left = size
                                while (left > 0) {
                                    val n = tar.read(buffer, 0, minOf(buffer.size.toLong(), left).toInt())
                                    if (n < 0) throw IllegalStateException("Archive incomplète")
                                    fos.write(buffer, 0, n)
                                    left -= n
                                }
                            }
                            skipPadding(tar, size)
                        }
                        else -> { // liens et autres types : ignorés
                            skip(tar, size); skipPadding(tar, size)
                        }
                    }
                    if (counting.count - last > 1024 * 1024) {
                        last = counting.count
                        report(
                            voice.id, if (total > 0) counting.count.toFloat() / total else -1f,
                            "Décompression…"
                        )
                    }
                }
            }
            if (findRoot(tmp) == null) throw IllegalStateException("Cette archive ne contient pas de voix valide.")
            target.deleteRecursively()
            if (!tmp.renameTo(target)) {
                tmp.copyRecursively(target, overwrite = true)
                tmp.deleteRecursively()
            }
        } catch (e: Exception) {
            tmp.deleteRecursively()
            throw e
        }
    }

    private class CountingStream(private val input: InputStream) : InputStream() {
        var count = 0L
        override fun read(): Int = input.read().also { if (it >= 0) count++ }
        override fun read(b: ByteArray, off: Int, len: Int): Int = input.read(b, off, len).also { if (it > 0) count += it }
        override fun close() = input.close()
    }

    private fun readFully(input: InputStream, buf: ByteArray): Boolean {
        var off = 0
        while (off < buf.size) {
            val n = input.read(buf, off, buf.size - off)
            if (n < 0) return false
            off += n
        }
        return true
    }

    private fun readBytes(input: InputStream, size: Long): ByteArray {
        val buf = ByteArray(size.toInt())
        if (size > 0 && !readFully(input, buf)) throw IllegalStateException("Archive incomplète")
        return buf
    }

    private fun skip(input: InputStream, size: Long) {
        var left = size
        val buf = ByteArray(16 * 1024)
        while (left > 0) {
            val n = input.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
            if (n < 0) return
            left -= n
        }
    }

    private fun skipPadding(input: InputStream, size: Long) {
        val rest = (512 - size % 512) % 512
        if (rest > 0) skip(input, rest)
    }

    private fun text(h: ByteArray, off: Int, len: Int): String {
        var end = off
        while (end < off + len && h[end] != 0.toByte()) end++
        return String(h, off, end - off, Charsets.UTF_8).trim()
    }

    private fun octal(h: ByteArray, off: Int, len: Int): Long {
        // Grands fichiers : encodage binaire (bit de poids fort à 1).
        if (h[off].toInt() and 0x80 != 0) {
            var v = 0L
            for (i in off + 1 until off + len) v = (v shl 8) or (h[i].toLong() and 0xff)
            return v
        }
        val s = text(h, off, len).trim()
        return if (s.isEmpty()) 0 else s.toLong(8)
    }

    // ------------------------------------------------------------ Synthèse

    private val lock = Mutex()
    private var engine: OfflineTts? = null
    private var loadedKey: String? = null

    /** Vrai pendant le chargement d'une voix en mémoire (quelques secondes pour Kokoro). */
    var loading by androidx.compose.runtime.mutableStateOf(false)
        private set

    /** Première voix installée capable de lire [lang], selon le moteur demandé. */
    fun voiceFor(context: Context, lang: String, engine: NeuralEngine): NeuralVoice? = when (engine) {
        NeuralEngine.KOKORO -> kokoro.takeIf { lang in it.langs && isInstalled(context, it) }
        NeuralEngine.PIPER -> piper.firstOrNull { lang in it.langs && isInstalled(context, it) }
    }

    private fun releaseEngine() {
        try {
            engine?.release()
        } catch (_: Exception) {
        }
        engine = null
        loadedKey = null
    }

    private fun buildConfig(voice: NeuralVoice, root: File, lang: String): OfflineTtsConfig {
        val threads = Runtime.getRuntime().availableProcessors().coerceIn(1, 4)
        fun path(name: String) = File(root, name).takeIf { it.exists() }?.absolutePath ?: ""
        return if (voice.engine == NeuralEngine.KOKORO) {
            val lexicons = when (lang) {
                "en" -> listOf("lexicon-us-en.txt")
                "zh" -> listOf("lexicon-us-en.txt", "lexicon-zh.txt")
                else -> emptyList()
            }.map { path(it) }.filter { it.isNotEmpty() }.joinToString(",")
            OfflineTtsConfig(
                model = OfflineTtsModelConfig(
                    kokoro = OfflineTtsKokoroModelConfig(
                        model = path("model.onnx"),
                        voices = path("voices.bin"),
                        tokens = path("tokens.txt"),
                        dataDir = path("espeak-ng-data"),
                        lexicon = lexicons,
                        lang = kokoroLang[lang] ?: ""
                    ),
                    numThreads = threads
                )
            )
        } else {
            val model = root.listFiles()?.firstOrNull { it.isFile && it.name.endsWith(".onnx") }?.absolutePath
                ?: throw IllegalStateException("Modèle Piper introuvable")
            val fsts = root.listFiles()?.filter { it.name.endsWith(".fst") }?.sortedBy { it.name }
                ?.joinToString(",") { it.absolutePath } ?: ""
            OfflineTtsConfig(
                model = OfflineTtsModelConfig(
                    vits = OfflineTtsVitsModelConfig(
                        model = model,
                        lexicon = path("lexicon.txt"),
                        tokens = path("tokens.txt"),
                        dataDir = path("espeak-ng-data")
                    ),
                    numThreads = threads
                ),
                ruleFsts = fsts
            )
        }
    }

    /**
     * Fabrique (ou retrouve en cache) le fichier WAV de [text] lu par [voice].
     * [slow] : lecture ralentie, calculée par le modèle (plus naturelle qu'un simple ralenti).
     */
    suspend fun speechFile(
        context: Context,
        voice: NeuralVoice,
        lang: String,
        text: String,
        slow: Boolean,
        male: Boolean
    ): File = withContext(Dispatchers.Default) {
        val sid = if (voice.engine == NeuralEngine.KOKORO) {
            kokoroSpeakers[lang]?.let { if (male) it.second else it.first } ?: 0
        } else 0
        val speed = if (slow) 0.7f else 1.0f
        val dir = File(context.cacheDir, "neural").apply { mkdirs() }
        val file = File(dir, hash("${voice.id}|$lang|$sid|$speed|$text") + ".wav")
        if (file.isFile && file.length() > 44) return@withContext file

        lock.withLock {
            val key = "${voice.id}|$lang"
            if (loadedKey != key || engine == null) {
                releaseEngine()
                val root = findRoot(voiceDir(context, voice)) ?: throw IllegalStateException("Voix non installée")
                withContext(Dispatchers.Main) { loading = true }
                try {
                    engine = OfflineTts(config = buildConfig(voice, root, lang))
                    loadedKey = key
                } finally {
                    withContext(Dispatchers.Main) { loading = false }
                }
            }
            val audio = engine!!.generate(text = text, sid = sid, speed = speed)
            if (audio.samples.isEmpty()) throw IllegalStateException("La voix n'a rien produit")
            val tmp = File(dir, file.name + ".tmp")
            if (!audio.save(tmp.absolutePath)) throw IllegalStateException("Enregistrement audio impossible")
            tmp.renameTo(file)
        }
        file
    }

    fun cacheSizeMb(context: Context): Long =
        File(context.cacheDir, "neural").walkTopDown().filter { it.isFile }.sumOf { it.length() } / (1024 * 1024)

    fun clearCache(context: Context) {
        File(context.cacheDir, "neural").deleteRecursively()
    }

    private fun hash(text: String): String =
        MessageDigest.getInstance("SHA-1").digest(text.toByteArray()).joinToString("") { "%02x".format(it) }
}
