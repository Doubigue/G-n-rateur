package com.linguavibe.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linguavibe.app.data.FirebaseConfig
import com.linguavibe.app.data.FirebaseRest
import com.linguavibe.app.data.FirebaseSync
import kotlinx.coroutines.launch

/**
 * Formulaire de connexion à une base Firebase.
 * On importe le fichier de configuration de l'app (google-services.json) : ses paramètres remplissent
 * le formulaire, qu'on peut encore corriger à la main.
 */
@Composable
fun FirebaseConfigForm(
    initial: FirebaseConfig,
    onSave: (FirebaseConfig) -> Unit,
    onMessage: (String) -> Unit
) {
    val context = LocalContext.current
    var projectId by remember { mutableStateOf(initial.projectId) }
    var apiKey by remember { mutableStateOf(initial.apiKey) }
    var appId by remember { mutableStateOf(initial.appId) }
    var databaseUrl by remember { mutableStateOf(initial.databaseUrl) }
    var bucket by remember { mutableStateOf(initial.storageBucket) }
    var rootPath by remember { mutableStateOf(initial.rootPath) }
    var anonymous by remember { mutableStateOf(initial.anonymousAuth) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        try {
            val text = context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                ?: throw IllegalStateException("Fichier illisible")
            val c = FirebaseConfig.parse(text, context.packageName)
            projectId = c.projectId
            apiKey = c.apiKey
            appId = c.appId
            databaseUrl = c.databaseUrl
            bucket = c.storageBucket
            onMessage("✅ Configuration importée : vérifiez les champs puis touchez « Enregistrer ».")
        } catch (e: Exception) {
            onMessage("❌ ${e.message ?: "Fichier de configuration non reconnu"}")
        }
    }

    CardBox {
        Text("1. Fichier de configuration", fontWeight = FontWeight.Bold, color = Ink)
        Text(
            "Console Firebase › Paramètres du projet › Vos applications : téléchargez google-services.json " +
                "(application Android) ou copiez la configuration Web dans un fichier texte.",
            fontSize = 13.sp, color = InkSoft
        )
        Button(onClick = { picker.launch(arrayOf("application/json", "text/*", "*/*")) }, modifier = Modifier.fillMaxWidth()) {
            Text("📂 Importer le fichier de configuration")
        }
    }

    CardBox {
        Text("2. Paramètres de la base", fontWeight = FontWeight.Bold, color = Ink)
        Field("ID du projet", projectId) { projectId = it }
        Field("Clé API (api_key)", apiKey) { apiKey = it }
        Field("ID de l'application (mobilesdk_app_id)", appId) { appId = it }
        Field("URL de la base de données", databaseUrl, KeyboardType.Uri) { databaseUrl = it }
        Text(
            "Exemple : https://mon-projet-default-rtdb.firebaseio.com ou, en Europe, " +
                "https://mon-projet-default-rtdb.europe-west1.firebasedatabase.app",
            fontSize = 11.sp, color = InkSoft
        )
        Field("Bucket de stockage (facultatif)", bucket) { bucket = it }
        Field("Dossier des données dans la base", rootPath) { rootPath = it }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = anonymous, onCheckedChange = { anonymous = it })
            Text(
                "Connexion anonyme (recommandé : règles « auth != null »)",
                fontSize = 13.sp, color = Ink, modifier = Modifier.weight(1f)
            )
        }
        Button(onClick = {
            val config = FirebaseConfig(
                projectId.trim(), apiKey.trim(), appId.trim(), databaseUrl.trim(), bucket.trim(),
                rootPath.trim().trim('/').ifBlank { "linguavibe" }, anonymous
            )
            if (!config.isComplete) {
                onMessage("❌ Il faut au moins l'URL de la base et la clé API.")
            } else {
                onSave(config)
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("💾 Enregistrer") }
    }
}

@Composable
private fun Field(label: String, value: String, type: KeyboardType = KeyboardType.Text, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = type),
        modifier = Modifier.fillMaxWidth()
    )
}

/** Écran « Données Firebase » de l'application LinguaVibe. */
@Composable
fun FirebaseScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var config by remember { mutableStateOf(FirebaseSync.loadConfig(context)) }
    var message by remember { mutableStateOf<String?>(null) }
    var autoSync by remember { mutableStateOf(FirebaseSync.autoSync(context)) }
    var refresh by remember { mutableStateOf(0) }
    val downloaded = remember(refresh, FirebaseSync.busy) { FirebaseSync.hasDownloaded(context) }
    val last = remember(refresh, FirebaseSync.busy) { FirebaseSync.lastSync(context) }

    Column(Modifier.fillMaxSize()) {
        TopBar("Données Firebase", "Cours en ligne, disponibles hors ligne", IndigoDark, onBack)
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            CardBox {
                Text("☁️ Charger les cours depuis Firebase", fontWeight = FontWeight.Bold, color = Ink)
                Text(
                    "Branchez l'application sur votre base Firebase (Realtime Database). Les cours y sont téléchargés " +
                        "une fois puis enregistrés sur le téléphone : ils fonctionnent ensuite sans connexion. " +
                        "Les leçons ajoutées avec l'appli d'administration apparaissent après chaque mise à jour.",
                    fontSize = 14.sp, color = InkSoft
                )
            }

            FirebaseConfigForm(config, onSave = {
                FirebaseSync.saveConfig(context, it)
                config = it
                message = "✅ Paramètres enregistrés."
            }, onMessage = { message = it })

            CardBox {
                Text("3. Connexion et téléchargement", fontWeight = FontWeight.Bold, color = Ink)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(enabled = config.isComplete && !FirebaseSync.busy, onClick = {
                        scope.launch {
                            message = "Test de la connexion…"
                            message = try {
                                val meta = FirebaseRest(context, config).test()
                                if (meta.trim() == "null") "✅ Connexion réussie, mais aucune donnée sous « ${config.rootPath} » pour l'instant."
                                else "✅ Connexion réussie. Données trouvées : $meta"
                            } catch (e: Exception) {
                                "❌ ${e.message}"
                            }
                        }
                    }) { Text("🔌 Tester") }
                    Button(enabled = config.isComplete && !FirebaseSync.busy, onClick = {
                        scope.launch {
                            try {
                                FirebaseSync.sync(context, config)
                            } catch (_: Exception) {
                            }
                            refresh++
                        }
                    }, modifier = Modifier.weight(1f)) { Text("⬇️ Télécharger les cours") }
                }
                if (FirebaseSync.busy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = Indigo)
                if (FirebaseSync.status.isNotBlank()) Text(FirebaseSync.status, fontSize = 14.sp, color = Ink)
                Text(
                    if (downloaded) "Cours utilisés : ceux de Firebase (dernière mise à jour : $last)."
                    else "Cours utilisés : ceux intégrés à l'application.",
                    fontSize = 13.sp, color = InkSoft
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Mettre à jour au démarrage (si connexion)", color = Ink, modifier = Modifier.weight(1f), fontSize = 14.sp)
                    Switch(checked = autoSync, onCheckedChange = {
                        autoSync = it
                        FirebaseSync.setAutoSync(context, it)
                    })
                }
                if (downloaded) {
                    TextButton(onClick = {
                        FirebaseSync.clear(context)
                        refresh++
                    }) { Text("↩️ Revenir aux cours intégrés", color = Bad) }
                }
            }

            message?.let { CardBox { Text(it, fontSize = 14.sp, color = Ink) } }

            CardBox {
                Text("Préparer Firebase (une seule fois)", fontWeight = FontWeight.Bold, color = Ink)
                Text(
                    "• Build › Realtime Database › Créer une base de données.\n" +
                        "• Build › Authentication › Méthodes de connexion : activez « Anonyme » " +
                        "(et « E-mail/Mot de passe » pour l'appli d'administration).\n" +
                        "• Règles de la base : lecture pour « auth != null », écriture réservée à l'administrateur " +
                        "(modèle fourni dans le dossier firebase/ du projet).\n" +
                        "• Envoyez les cours avec l'appli LinguaVibe Admin, puis touchez « Télécharger les cours ».",
                    fontSize = 13.sp, color = InkSoft
                )
            }
        }
    }
}
