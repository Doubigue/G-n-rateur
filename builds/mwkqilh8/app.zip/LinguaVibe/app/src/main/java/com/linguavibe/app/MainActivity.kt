package com.linguavibe.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.lifecycleScope
import com.linguavibe.app.data.FirebaseSync
import kotlinx.coroutines.launch
import com.linguavibe.app.data.ProgressStore
import com.linguavibe.app.speech.Speaker
import com.linguavibe.app.speech.VoskManager
import com.linguavibe.app.ui.AppRoot
import com.linguavibe.app.ui.LinguaTheme

class MainActivity : ComponentActivity() {
    private lateinit var speaker: Speaker

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        speaker = Speaker(this)
        val progress = ProgressStore(this)
        // Mise à jour discrète des cours depuis Firebase (s'il est configuré et qu'il y a du réseau).
        if (savedInstanceState == null && FirebaseSync.autoSync(this) && FirebaseSync.loadConfig(this).isComplete) {
            lifecycleScope.launch {
                try {
                    FirebaseSync.sync(applicationContext)
                } catch (_: Exception) {
                    // Hors ligne : on garde les cours déjà enregistrés.
                }
            }
        }
        setContent {
            LinguaTheme {
                AppRoot(speaker, progress)
            }
        }
    }

    override fun onStop() {
        super.onStop()
        // On libère le micro quand l'application passe en arrière-plan.
        VoskManager.cancel()
        speaker.stop()
    }

    override fun onDestroy() {
        speaker.shutdown()
        super.onDestroy()
    }
}
