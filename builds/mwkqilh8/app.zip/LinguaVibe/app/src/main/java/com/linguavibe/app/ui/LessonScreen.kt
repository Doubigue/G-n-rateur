package com.linguavibe.app.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.linguavibe.app.data.CourseRepository
import com.linguavibe.app.data.DialogueLine
import com.linguavibe.app.data.GrammarPoint
import com.linguavibe.app.data.Homework
import com.linguavibe.app.data.LanguageInfo
import com.linguavibe.app.data.Languages
import com.linguavibe.app.data.Lesson
import com.linguavibe.app.data.Levels
import com.linguavibe.app.data.ProgressStore
import com.linguavibe.app.data.QuizItem
import com.linguavibe.app.speech.Pronunciation
import com.linguavibe.app.speech.PronunciationResult
import com.linguavibe.app.speech.VoskManager
import com.linguavibe.app.speech.WordStatus
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val tabTitles = listOf("📖 Leçon", "📰 Lecture", "💬 Dialogue", "🎤 Prononciation", "❓ Quiz", "📝 Devoir")

@Composable
fun LessonScreen(lang: LanguageInfo, lessonId: String, progress: ProgressStore, onBack: () -> Unit) {
    val context = LocalContext.current
    val speaker = LocalSpeaker.current
    val course = remember(lang.code, CourseRepository.version) { CourseRepository.load(context, lang.code) }
    val lesson = course.lesson(lessonId)
    if (lesson == null) {
        Column(Modifier.fillMaxSize()) {
            TopBar("Leçon introuvable", null, IndigoDark, onBack)
        }
        return
    }
    val color = levelColor(lesson.level)
    var tab by rememberSaveable(lessonId) { mutableStateOf(0) }

    // On coupe la voix et le micro en changeant d'onglet ou en quittant la leçon.
    LaunchedEffect(tab) {
        speaker.stop()
        VoskManager.cancel()
    }
    DisposableEffect(lessonId) {
        onDispose {
            speaker.stop()
            VoskManager.cancel()
        }
    }

    Column(Modifier.fillMaxSize()) {
        TopBar(lesson.title, "${lesson.level} · Leçon ${lesson.number} · ${lesson.titleTr}", color, onBack)
        ScrollableTabRow(
            selectedTabIndex = tab,
            edgePadding = 8.dp,
            containerColor = Color.White,
            contentColor = color
        ) {
            tabTitles.forEachIndexed { index, title ->
                Tab(
                    selected = tab == index,
                    onClick = { tab = index },
                    text = {
                        Text(title, fontWeight = if (tab == index) FontWeight.Bold else FontWeight.Normal)
                    }
                )
            }
        }
        AnimatedContent(
            targetState = tab,
            modifier = Modifier.weight(1f),
            transitionSpec = { fadeIn(tween(250)) togetherWith fadeOut(tween(150)) },
            label = "lessonTab"
        ) { current ->
            when (current) {
                0 -> LearnStep(lesson, lang, color) { tab = 1 }
                1 -> ReadingStep(lesson, lang, color) { tab = 2 }
                2 -> DialogueStep(lesson, lang, color) { tab = 3 }
                3 -> PronunciationStep(lesson, lang, color) { tab = 4 }
                4 -> QuizStep(lesson, lang, color, progress) { tab = 5 }
                else -> HomeworkStep(lesson, lang, color, progress)
            }
        }
    }
}

/** Étape sans contenu (leçon ajoutée depuis l'administration et encore incomplète). */
@Composable
private fun EmptyStep(message: String, next: String, color: Color, onNext: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        CardBox { Text(message, color = InkSoft) }
        NextButton(next, color, onNext)
    }
}

@Composable
private fun NextButton(text: String, color: Color, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = ButtonDefaults.buttonColors(containerColor = color),
        contentPadding = PaddingValues(vertical = 14.dp)
    ) { Text(text, fontWeight = FontWeight.Bold, fontSize = 16.sp) }
}

// ------------------------------------------------------------------ 1. Leçon

@Composable
private fun LearnStep(lesson: Lesson, lang: LanguageInfo, color: Color, onNext: () -> Unit) {
    val speaker = LocalSpeaker.current
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        SceneBanner(
            emoji = lesson.emoji,
            extras = lesson.vocab.take(3).map { it.emoji },
            color = color,
            title = lesson.title,
            subtitle = lesson.titleTr,
            tag = "${lesson.level} · ${Levels.label(lesson.level)}"
        )
        if (!speaker.voiceAvailable) {
            CardBox {
                Text(
                    "🔇 La voix « ${lang.name} » n'est pas installée sur ce téléphone. Ouvrez Paramètres › " +
                        "Synthèse vocale et téléchargez cette langue pour entendre les exemples.",
                    fontSize = 13.sp, color = Bad
                )
            }
        }
        speaker.lastError?.let { message ->
            CardBox {
                Text("⚠️ $message La voix du téléphone est utilisée à la place.", fontSize = 13.sp, color = Bad)
            }
        }
        if (lesson.intro.isNotBlank()) {
            CardBox {
                Text(lesson.intro, fontSize = 15.sp, color = Ink, lineHeight = 21.sp)
                PronLegend(lang)
            }
        }

        // Écoute de toute la leçon : vocabulaire, exemples de grammaire, puis dialogue.
        val playlist = remember(lesson.id) {
            lesson.vocab.flatMap { vocab ->
                if (vocab.word.any { it == '+' || it == '…' }) listOf(vocab.example)
                else listOf(vocab.word, vocab.example)
            } + lesson.grammar.flatMap { point -> point.examples.map { it.text } } +
                lesson.dialogue.map { it.text }
        }
        Button(
            onClick = {
                if (speaker.sequencePlaying) speaker.stop() else speaker.speakAll(playlist, lang.locale)
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = ButtonDefaults.buttonColors(containerColor = if (speaker.sequencePlaying) Bad else color),
            contentPadding = PaddingValues(vertical = 14.dp)
        ) {
            Text(
                if (speaker.sequencePlaying) "⏹  Arrêter l'écoute" else "🎧  Écouter toute la leçon",
                fontWeight = FontWeight.Bold, fontSize = 16.sp
            )
        }
        if (speaker.sequencePlaying) {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { Waveform(color) }
        }

        SectionTitle("📚 Vocabulaire", "Touchez une carte pour la retourner, 🔊 pour l'écouter")
        lesson.vocab.chunked(2).forEach { pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                pair.forEach { vocab ->
                    // Pour une structure (« llevar + gerundio »), on fait entendre l'exemple.
                    val spoken = if (vocab.word.any { it == '+' || it == '…' }) vocab.example else vocab.word
                    FlipCard(vocab, color, { speaker.speak(spoken, lang.locale) }, Modifier.weight(1f))
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }

        SectionTitle("🧩 Grammaire", "Touchez un exemple pour l'écouter")
        lesson.grammar.forEachIndexed { index, point ->
            StaggerIn(index) { GrammarCard(point, lang, color) }
        }

        NextButton("Passer à la lecture  📰", color, onNext)
    }
}

/** Mode d'emploi de la prononciation figurée, par langue. */
val pronLegend = mapOf(
    "es" to "🗣 Comment lire la prononciation : syllabe accentuée en MAJUSCULES · th = « th » anglais (z, ce, ci) · " +
        "kh = son raclé de la jota · rr = r roulé · r = r battu, un seul coup de langue · " +
        "nn, mm = n et m jamais nasaux · ou = u espagnol.",
    "pt" to "🗣 Comment lire la prononciation : syllabe accentuée en MAJUSCULES · ã, ẽ, ĩ, õ, ũ = voyelles nasales " +
        "(ãou = « pão ») · rr = r du fond de la gorge, soufflé · r = r battu · tch, dj = t et d devant le son i · " +
        "è = e ouvert · ô = o fermé · ou = u.",
    "en" to "🗣 Comment lire la prononciation (anglais américain) : syllabe accentuée en MAJUSCULES, toutes les lettres " +
        "se prononcent · e = son faible · eu = u de « but » · eur = « bird » · ii = i long · â = a de « father » · " +
        "ôou = o de « go » · th = langue entre les dents (think) · dh = th doux (this) · w = ou bref · " +
        "ng = n du nez sans g · h = expiré · nn, mm = jamais nasaux.",
    "ru" to "🗣 Comment lire la prononciation : syllabe accentuée en MAJUSCULES (les voyelles non accentuées " +
        "s'affaiblissent : о se lit a, е et я se lisent i) · y = ы, i dur, langue en arrière · ' = consonne mouillée (ь) · " +
        "kh = son raclé (х) · ch = ш · j = ж · tch = ч · chtch = щ · r = r roulé · nn, mm = jamais nasaux.",
    "zh" to "🗣 La prononciation est donnée en pinyin, avec les tons : ā haut et plat · á montant · ǎ descendant puis " +
        "montant · à descendant · a sans signe = ton neutre. x ≈ ch doux · q ≈ tch soufflé · zh ≈ dj · ch ≈ tch · " +
        "c ≈ ts soufflé · z ≈ dz · r ≈ j anglais · u = ou (ü = u français).",
    "ar" to "🗣 La prononciation est transcrite en lettres latines : ā, ī, ū = voyelles longues · ʿ = son de gorge (ع) · " +
        "ʾ = coup de glotte (ء) · ḥ = h soufflé · kh = jota (خ) · gh = r grasseyé (غ) · q = k du fond de la gorge · " +
        "ṣ, ḍ, ṭ, ẓ = consonnes « lourdes » · th = th anglais dur · dh = th doux · sh = ch."
)

@Composable
fun PronLegend(lang: LanguageInfo) {
    val legend = pronLegend[lang.code] ?: return
    Text(legend, fontSize = 12.sp, color = InkSoft, lineHeight = 16.sp)
}

/** Prononciation figurée (« comment prononcer »), syllabe accentuée en MAJUSCULES. */
@Composable
fun PronLine(pron: String, color: Color, fontSize: Int = 13, onDark: Boolean = false) {
    if (pron.isBlank()) return
    Text(
        "🗣 $pron",
        fontSize = fontSize.sp,
        lineHeight = (fontSize + 4).sp,
        color = if (onDark) Color.White.copy(alpha = 0.92f) else color,
        fontWeight = FontWeight.Medium
    )
}

@Composable
private fun GrammarCard(point: GrammarPoint, lang: LanguageInfo, color: Color) {
    val speaker = LocalSpeaker.current
    CardBox {
        Text(point.title, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = color)
        Text(point.explanation, fontSize = 14.sp, color = Ink, lineHeight = 20.sp)
        point.examples.forEach { example ->
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(color.copy(alpha = 0.08f))
                    .clickable { speaker.speak(example.text, lang.locale) }
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Text("🔊  ${example.text}", fontWeight = FontWeight.SemiBold, fontSize = 15.sp, color = Ink)
                PronLine(example.pron, color)
                Text(example.translation, fontSize = 13.sp, color = InkSoft, fontStyle = FontStyle.Italic)
            }
        }
    }
}

// -------------------------------------------------------- Micro et correction

/** Bouton micro complet : permission, chargement du modèle, écoute, texte en direct. */
@Composable
fun MicControl(id: String, lang: LanguageInfo, color: Color, onHeard: (String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val openModels = LocalOpenModels.current
    val speaker = LocalSpeaker.current
    val currentOnHeard by rememberUpdatedState(onHeard)
    var error by remember(id) { mutableStateOf<String?>(null) }
    var missingModel by remember(id) { mutableStateOf(false) }
    val listening = VoskManager.activeId == id
    val loading = VoskManager.loadingId == id

    val begin: () -> Unit = {
        error = null
        if (!VoskManager.isInstalled(context, lang.code)) {
            missingModel = true
        } else {
            missingModel = false
            speaker.stop()
            scope.launch {
                VoskManager.loadingId = id
                try {
                    val model = VoskManager.ensureModel(context, lang.code)
                    VoskManager.start(
                        id, model,
                        onFinal = { heard -> currentOnHeard(heard) },
                        onError = { message -> error = message }
                    )
                } catch (e: Exception) {
                    error = e.message ?: "Impossible de charger le modèle vocal"
                } finally {
                    if (VoskManager.loadingId == id) VoskManager.loadingId = null
                }
            }
        }
    }

    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) begin() else error = "Autorisez le microphone pour vous faire corriger."
    }

    DisposableEffect(id) {
        onDispose { if (VoskManager.activeId == id) VoskManager.cancel() }
    }

    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        PulsingMic(listening, loading, color) {
            val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
            when {
                listening -> VoskManager.stop()
                granted -> begin()
                else -> permission.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
        when {
            loading -> Text("Chargement du modèle vocal…", fontSize = 13.sp, color = InkSoft)
            listening -> {
                Waveform(color)
                Text(
                    VoskManager.partial.ifBlank { "Parlez… puis touchez ⏹ pour terminer" },
                    fontSize = 14.sp, color = Ink, textAlign = TextAlign.Center
                )
            }
            else -> Text("Touchez le micro et parlez", fontSize = 13.sp, color = InkSoft)
        }
        if (missingModel) {
            Text(
                "Aucun modèle vocal n'est encore installé pour : ${lang.name.lowercase()}.",
                fontSize = 13.sp, color = Bad, textAlign = TextAlign.Center
            )
            OutlinedButton(onClick = openModels) { Text("Installer le modèle") }
        }
        error?.let { Text(it, fontSize = 13.sp, color = Bad, textAlign = TextAlign.Center) }
    }
}

@Composable
private fun PronunciationFeedback(result: PronunciationResult) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(scoreColor(result.score).copy(alpha = 0.08f))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ScoreRing(result.score, 68.dp)
        Spacer(Modifier.width(12.dp))
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                buildAnnotatedString {
                    result.words.forEach { word ->
                        val style = when (word.status) {
                            WordStatus.OK -> SpanStyle(color = Good, fontWeight = FontWeight.Bold)
                            WordStatus.CLOSE -> SpanStyle(color = Warn, fontWeight = FontWeight.Bold)
                            WordStatus.MISSED -> SpanStyle(
                                color = Bad, fontWeight = FontWeight.Bold,
                                textDecoration = TextDecoration.Underline
                            )
                        }
                        withStyle(style) { append(word.word) }
                        append("  ")
                    }
                },
                fontSize = 16.sp
            )
            if (result.heardText.isNotBlank()) {
                Text("Entendu : « ${result.heardText} »", fontSize = 13.sp, color = InkSoft)
            }
            Text(result.feedback, fontSize = 13.sp, color = Ink)
            Text("vert = correct · orange = presque · rouge = à retravailler", fontSize = 11.sp, color = InkSoft)
        }
    }
}

/** Micro + correction mot à mot de la phrase attendue. */
@Composable
fun PronounceBlock(id: String, expected: String, lang: LanguageInfo, color: Color) {
    var result by remember(id) { mutableStateOf<PronunciationResult?>(null) }
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        MicControl(id, lang, color) { heard ->
            result = Pronunciation.evaluate(expected, heard, lang.code)
        }
        AnimatedVisibility(visible = result != null) {
            result?.let { PronunciationFeedback(it) }
        }
    }
}

// ---------------------------------------------------------------- 2. Lecture

@Composable
private fun ReadingStep(lesson: Lesson, lang: LanguageInfo, color: Color, onNext: () -> Unit) {
    val speaker = LocalSpeaker.current
    val reading = lesson.reading
    var showPron by rememberSaveable(lesson.id) { mutableStateOf(true) }
    var showTr by rememberSaveable(lesson.id) { mutableStateOf(false) }
    var micIndex by remember(lesson.id) { mutableIntStateOf(-1) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (reading == null || reading.sentences.isEmpty()) {
            CardBox {
                Text("📰 Le texte de lecture de cette leçon arrive bientôt.", color = InkSoft)
            }
            NextButton("Passer au dialogue  💬", color, onNext)
            return@Column
        }
        val texts = reading.sentences.map { it.text }

        CardBox {
            Text("📰 ${reading.title}", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, color = color)
            if (reading.titleTr.isNotBlank()) {
                Text(reading.titleTr, fontSize = 14.sp, color = InkSoft, fontStyle = FontStyle.Italic)
            }
            Text(
                "Lisez le texte, écoutez-le phrase par phrase, puis lisez-le à voix haute.",
                fontSize = 13.sp, color = InkSoft
            )
            PronLegend(lang)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = showPron, onClick = { showPron = !showPron },
                    label = { Text("🗣 Prononciation") }
                )
                FilterChip(
                    selected = showTr, onClick = { showTr = !showTr },
                    label = { Text("🇫🇷 Traduction") }
                )
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { if (speaker.sequencePlaying) speaker.stop() else speaker.speakAll(texts, lang.locale) },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = if (speaker.sequencePlaying) Bad else color)
            ) { Text(if (speaker.sequencePlaying) "⏹ Arrêter" else "🎧 Écouter le texte", fontWeight = FontWeight.Bold) }
            OutlinedButton(
                onClick = { speaker.speakAll(texts, lang.locale, slow = true) },
                shape = RoundedCornerShape(18.dp)
            ) { Text("🐢 Lent") }
        }
        if (speaker.sequencePlaying) {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { Waveform(color) }
        }

        reading.sentences.forEachIndexed { index, sentence ->
            val active = speaker.sequencePlaying && speaker.sequenceIndex == index
            StaggerIn(index) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (active) color.copy(alpha = 0.16f) else Color.White)
                        .border(2.dp, if (active) color else Color.Transparent, RoundedCornerShape(16.dp))
                        .clickable { speaker.speak(sentence.text, lang.locale) }
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(sentence.text, fontWeight = FontWeight.SemiBold, fontSize = 17.sp, color = Ink, lineHeight = 24.sp)
                    if (showPron) PronLine(sentence.pron, color, fontSize = 14)
                    if (showTr) {
                        Text(sentence.translation, fontSize = 14.sp, color = InkSoft, fontStyle = FontStyle.Italic)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        TextButton(onClick = { speaker.speak(sentence.text, lang.locale) }) { Text("🔊") }
                        TextButton(onClick = { speaker.speak(sentence.text, lang.locale, slow = true) }) { Text("🐢") }
                        TextButton(onClick = { speaker.speakAll(texts, lang.locale, from = index) }) { Text("▶ D'ici") }
                        TextButton(onClick = { micIndex = if (micIndex == index) -1 else index }) {
                            Text(if (micIndex == index) "✖ Micro" else "🎤 Lire")
                        }
                    }
                    AnimatedVisibility(visible = micIndex == index) {
                        PronounceBlock("reading-${lesson.id}-$index", sentence.text, lang, color)
                    }
                }
            }
        }
        NextButton("Passer au dialogue  💬", color, onNext)
    }
}

// --------------------------------------------------------------- 3. Dialogue

@Composable
private fun DialogueStep(lesson: Lesson, lang: LanguageInfo, color: Color, onNext: () -> Unit) {
    val speaker = LocalSpeaker.current
    val lines = lesson.dialogue
    if (lines.isEmpty()) {
        EmptyStep("💬 Cette leçon n'a pas encore de dialogue.", "Passer à la prononciation  🎤", color, onNext)
        return
    }
    var shown by remember(lesson.id) { mutableIntStateOf(1) }
    val scroll = rememberScrollState()
    val current = lines[(shown - 1).coerceIn(0, lines.lastIndex)]
    val isLast = shown >= lines.size

    LaunchedEffect(shown) {
        delay(200)
        scroll.animateScrollTo(scroll.maxValue)
        if (!current.isUser) speaker.speak(current.text, lang.locale)
    }

    Column(Modifier.fillMaxSize()) {
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(scroll)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                "Jeu de rôle : l'application joue le premier personnage, vous jouez le second (bulles colorées). " +
                    "Touchez une bulle pour la réécouter.",
                fontSize = 13.sp, color = InkSoft
            )
            lines.take(shown).forEachIndexed { index, line ->
                key(index) {
                    StaggerIn(0) { Bubble(line, color) { speaker.speak(line.text, lang.locale) } }
                }
            }
        }
        Column(
            Modifier
                .fillMaxWidth()
                .background(Color.White)
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (current.isUser) {
                Text("🎤 À vous ! Dites la phrase colorée :", fontWeight = FontWeight.Bold, color = color)
                PronounceBlock("dialogue-${lesson.id}-$shown", current.text, lang, color)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { speaker.speak(current.text, lang.locale, slow = true) },
                    modifier = Modifier.weight(1f)
                ) { Text("🐢 Réécouter") }
                Button(
                    onClick = { if (isLast) onNext() else shown++ },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = color)
                ) { Text(if (isLast) "Terminer ✓" else "Continuer ▶") }
            }
        }
    }
}

@Composable
private fun Bubble(line: DialogueLine, color: Color, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (line.isUser) Arrangement.End else Arrangement.Start
    ) {
        if (!line.isUser) {
            Text("🧑‍🏫", fontSize = 26.sp)
            Spacer(Modifier.width(6.dp))
        }
        Column(
            Modifier
                .fillMaxWidth(0.8f)
                .clip(
                    RoundedCornerShape(
                        topStart = 20.dp, topEnd = 20.dp,
                        bottomStart = if (line.isUser) 20.dp else 4.dp,
                        bottomEnd = if (line.isUser) 4.dp else 20.dp
                    )
                )
                .background(if (line.isUser) color else Color.White)
                .clickable(onClick = onClick)
                .padding(12.dp)
        ) {
            val textColor = if (line.isUser) Color.White else Ink
            Text(line.text, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, color = textColor)
            PronLine(line.pron, color, onDark = line.isUser)
            Text(line.translation, fontSize = 13.sp, color = textColor.copy(alpha = 0.75f), fontStyle = FontStyle.Italic)
        }
    }
}

// ---------------------------------------------------------- 4. Prononciation

@Composable
private fun PronunciationStep(lesson: Lesson, lang: LanguageInfo, color: Color, onNext: () -> Unit) {
    val speaker = LocalSpeaker.current
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        SectionTitle(
            "🎤 Prononciation",
            "Écoutez le modèle, répétez dans le micro : chaque mot est corrigé."
        )
        lesson.phrases.forEachIndexed { index, phrase ->
            StaggerIn(index) {
                CardBox {
                    Text(phrase.text, fontWeight = FontWeight.Bold, fontSize = 19.sp, color = Ink)
                    PronLine(phrase.pron, color, fontSize = 15)
                    Text(phrase.translation, fontSize = 14.sp, color = InkSoft, fontStyle = FontStyle.Italic)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { speaker.speak(phrase.text, lang.locale) }) { Text("🔊 Écouter") }
                        OutlinedButton(onClick = { speaker.speak(phrase.text, lang.locale, slow = true) }) {
                            Text("🐢 Lentement")
                        }
                    }
                    PronounceBlock("phrase-${lesson.id}-$index", phrase.text, lang, color)
                }
            }
        }
        NextButton("Passer au quiz  ❓", color, onNext)
    }
}

// ------------------------------------------------------------------- 5. Quiz

@Composable
private fun QuizStep(lesson: Lesson, lang: LanguageInfo, color: Color, progress: ProgressStore, onNext: () -> Unit) {
    val items = lesson.quiz
    if (items.isEmpty()) {
        EmptyStep("❓ Cette leçon n'a pas encore de quiz.", "Faire le devoir  📝", color, onNext)
        return
    }
    var index by remember(lesson.id) { mutableIntStateOf(0) }
    var correct by remember(lesson.id) { mutableIntStateOf(0) }
    var finished by remember(lesson.id) { mutableStateOf(false) }
    var gained by remember(lesson.id) { mutableIntStateOf(0) }

    if (finished) {
        val score = correct * 100 / items.size
        val passed = score >= ProgressStore.PASS_SCORE
        Box(Modifier.fillMaxSize()) {
            Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                FloatingEmoji(if (passed) "🏆" else "💪", 64)
                ScoreRing(score, 124.dp)
                Text(
                    if (passed) "Leçon validée !" else "Encore un effort",
                    fontWeight = FontWeight.ExtraBold, fontSize = 24.sp, color = Ink
                )
                Text(
                    "$correct bonnes réponses sur ${items.size}" +
                        if (passed) "" else " — il faut ${ProgressStore.PASS_SCORE} % pour valider.",
                    fontSize = 15.sp, color = InkSoft, textAlign = TextAlign.Center
                )
                Chip("⭐ +$gained XP", Indigo)
                OutlinedButton(onClick = {
                    index = 0
                    correct = 0
                    finished = false
                }) { Text("🔁 Refaire le quiz") }
                NextButton("Faire le devoir  📝", color, onNext)
            }
            if (passed) Confetti()
        }
        return
    }

    Column(
        Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        AnimatedBar(index.toFloat() / items.size, color)
        Text("Question ${index + 1} / ${items.size}", fontSize = 13.sp, color = InkSoft)
        AnimatedContent(
            targetState = index,
            modifier = Modifier.weight(1f),
            transitionSpec = {
                (fadeIn(tween(260)) + slideInHorizontally(tween(260)) { it / 5 }) togetherWith fadeOut(tween(140))
            },
            label = "question"
        ) { i ->
            QuestionView(
                item = items[i.coerceIn(0, items.lastIndex)],
                lang = lang,
                color = color,
                onAnswered = { ok -> if (ok) correct++ },
                onContinue = {
                    if (i >= items.lastIndex) {
                        gained = progress.recordQuiz(lesson.id, correct * 100 / items.size)
                        finished = true
                    } else {
                        index = i + 1
                    }
                }
            )
        }
    }
}

@Composable
private fun QuestionView(
    item: QuizItem,
    lang: LanguageInfo,
    color: Color,
    onAnswered: (Boolean) -> Unit,
    onContinue: () -> Unit
) {
    val speaker = LocalSpeaker.current
    var answered by remember(item) { mutableStateOf(false) }
    var wasCorrect by remember(item) { mutableStateOf(false) }
    var note by remember(item) { mutableStateOf("") }
    val submit: (Boolean, String) -> Unit = { ok, message ->
        if (!answered) {
            answered = true
            wasCorrect = ok
            note = message
            onAnswered(ok)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        when (item) {
            is QuizItem.Mcq -> {
                Text(item.question, fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Ink, lineHeight = 26.sp)
                Options(item.correct, item.wrong, answered) { ok -> submit(ok, item.correct) }
            }

            is QuizItem.Listen -> {
                LaunchedEffect(item) {
                    delay(350)
                    speaker.speak(item.phrase, lang.locale)
                }
                Text("🎧 Écoutez et choisissez le sens", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Ink)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { speaker.speak(item.phrase, lang.locale) },
                        colors = ButtonDefaults.buttonColors(containerColor = color)
                    ) { Text("🔊 Écouter") }
                    OutlinedButton(onClick = { speaker.speak(item.phrase, lang.locale, slow = true) }) {
                        Text("🐢 Lentement")
                    }
                }
                Options(
                    item.correct, item.wrong, answered,
                    voiceId = "quiz-voice-${item.phrase.hashCode()}"
                ) { ok -> submit(ok, "${item.phrase} = ${item.correct}") }
            }

            is QuizItem.Typed -> {
                var input by remember(item) { mutableStateOf("") }
                Text(
                    "✍️ Traduisez en ${lang.name.lowercase()}" +
                        when (lang.code) {
                            "zh" -> " (caractères ou pinyin)"
                            "ar" -> " (écriture arabe ou lettres latines)"
                            else -> ""
                        },
                    fontSize = 14.sp, color = InkSoft
                )
                Text(item.prompt, fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Ink, lineHeight = 26.sp)
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    enabled = !answered,
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Votre réponse") }
                )
                if (!answered) {
                    Button(
                        enabled = input.isNotBlank(),
                        onClick = {
                            val typed = Pronunciation.matchKey(input, lang.code)
                            val ok = item.answers.any { Pronunciation.matchKey(it, lang.code) == typed }
                            val exact = item.answers.any {
                                Pronunciation.clean(it).replace(" ", "") == Pronunciation.clean(input).replace(" ", "")
                            }
                            // En chinois et en arabe, on donne l'écriture d'origine et sa transcription.
                            val best = item.answers.first() +
                                if (lang.code in setOf("zh", "ar") && item.answers.size > 1) "  ·  ${item.answers[1]}" else ""
                            val note = when (lang.code) {
                                "zh" -> "attention aux tons"
                                "ar" -> "attention aux voyelles longues"
                                else -> "attention aux accents"
                            }
                            submit(ok, if (ok && !exact) "$best  ($note)" else best)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = color)
                    ) { Text("Valider") }
                }
            }
        }

        AnimatedVisibility(visible = answered) {
            val feedbackColor = if (wasCorrect) Good else Bad
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(feedbackColor.copy(alpha = 0.12f))
                    .padding(14.dp)
            ) {
                Text(
                    if (wasCorrect) "✅ Bravo !" else "❌ Pas tout à fait",
                    fontWeight = FontWeight.Bold, color = feedbackColor, fontSize = 16.sp
                )
                Text("Réponse : $note", color = Ink, fontSize = 15.sp)
            }
        }
        if (answered) NextButton("Continuer", color, onContinue)
    }
}

@Composable
private fun Options(
    correct: String,
    wrong: List<String>,
    answered: Boolean,
    voiceId: String? = null,
    onPick: (Boolean) -> Unit
) {
    val context = LocalContext.current
    val options = remember(correct, wrong) { (wrong + correct).distinct().shuffled() }
    var picked by remember(correct, wrong) { mutableStateOf<String?>(null) }
    var voiceNote by remember(correct, wrong) { mutableStateOf<String?>(null) }
    options.forEach { option ->
        val highlight = when {
            !answered -> null
            option == correct -> Good
            option == picked -> Bad
            else -> null
        }
        val background by animateColorAsState(highlight?.copy(alpha = 0.16f) ?: Color.White, label = "optionBg")
        val shape = RoundedCornerShape(16.dp)
        Text(
            option,
            fontSize = 16.sp,
            color = Ink,
            fontWeight = if (highlight != null) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(background)
                .border(1.5.dp, highlight ?: Color(0xFFDAD5F0), shape)
                .clickable(enabled = !answered) {
                    picked = option
                    onPick(option == correct)
                }
                .padding(16.dp)
        )
    }

    // Réponse à voix haute dans la langue maternelle, si son modèle vocal est installé.
    val native = Languages.native
    val version = VoskManager.installsVersion
    val nativeReady = remember(version) { VoskManager.isInstalled(context, native.code) }
    if (voiceId != null && nativeReady && !answered) {
        Text("…ou dites la réponse en ${native.name.lowercase()} :", fontSize = 13.sp, color = InkSoft)
        MicControl(voiceId, native, Indigo) { heard ->
            val best = options.maxByOrNull { Pronunciation.evaluate(it, heard, native.code).score }
            val score = if (best == null) 0 else Pronunciation.evaluate(best, heard, native.code).score
            if (best != null && score >= 60) {
                picked = best
                onPick(best == correct)
            } else {
                voiceNote = "Je n'ai reconnu aucune des réponses (entendu : « $heard »). Réessayez ou touchez une réponse."
            }
        }
        voiceNote?.let { Text(it, fontSize = 13.sp, color = Bad) }
    }
}

// ----------------------------------------------------------------- 5. Devoir

@Composable
private fun HomeworkStep(lesson: Lesson, lang: LanguageInfo, color: Color, progress: ProgressStore) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        SectionTitle(
            "📝 Devoir",
            "Répondez en ${lang.name.lowercase()} avec vos propres mots (à l'écrit ou à la voix), puis comparez au modèle."
        )
        if (lesson.homework.isEmpty()) {
            CardBox { Text("📝 Cette leçon n'a pas encore de devoir.", color = InkSoft) }
        }
        lesson.homework.forEachIndexed { index, homework ->
            HomeworkCard("${lesson.id}-$index", index + 1, homework, lang, color, progress)
        }
    }
}

@Composable
private fun HomeworkCard(
    key: String,
    number: Int,
    homework: Homework,
    lang: LanguageInfo,
    color: Color,
    progress: ProgressStore
) {
    val speaker = LocalSpeaker.current
    var text by remember(key) { mutableStateOf(progress.homeworkAnswer(key)) }
    var corrected by remember(key) { mutableStateOf(false) }
    CardBox {
        Text("Question $number", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = color)
        Text(homework.prompt, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Ink, lineHeight = 22.sp)
        OutlinedTextField(
            value = text,
            onValueChange = {
                text = it
                corrected = false
            },
            modifier = Modifier.fillMaxWidth(),
            minLines = 3,
            label = { Text("Votre réponse") }
        )
        Text("…ou dictez votre réponse :", fontSize = 13.sp, color = InkSoft)
        MicControl("homework-$key", lang, color) { heard ->
            if (heard.isNotBlank()) {
                text = (text.trim() + " " + heard).trim()
                corrected = false
            }
        }
        Button(
            enabled = text.isNotBlank(),
            onClick = {
                progress.saveHomework(key, text)
                corrected = true
            },
            colors = ButtonDefaults.buttonColors(containerColor = color)
        ) { Text("Corriger mon devoir") }

        AnimatedVisibility(visible = corrected) {
            val answer = Pronunciation.matchKey(text, lang.code)
            // Un mot-clé peut avoir des variantes séparées par « / » (caractères / pinyin).
            val found = homework.keywords.filter { keyword ->
                keyword.split('/').any { variant ->
                    val key = Pronunciation.matchKey(variant, lang.code)
                    key.isNotBlank() && answer.contains(key)
                }
            }.map { it.replace("/", " / ") }
            val missing = homework.keywords.map { it.replace("/", " / ") }.filter { it !in found }
            val wordCount = if (lang.code == "zh") answer.length / 2 else text.split(Regex("\\s+")).count { it.isNotBlank() }
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (homework.keywords.isNotEmpty()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        ScoreRing(found.size * 100 / homework.keywords.size, 60.dp)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            if (found.isNotEmpty()) {
                                Text("✅ Bien utilisé : ${found.joinToString(", ")}", fontSize = 14.sp, color = Good)
                            }
                            if (missing.isNotEmpty()) {
                                Text("➕ À intégrer : ${missing.joinToString(", ")}", fontSize = 14.sp, color = Warn)
                            }
                        }
                    }
                }
                if (wordCount < 6) {
                    Text("💡 Développez davantage : visez au moins deux phrases complètes.", fontSize = 13.sp, color = Ink)
                }
                Text("Réponse modèle (touchez pour écouter)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = color)
                Text(
                    "🔊  ${homework.model}",
                    fontSize = 15.sp, color = Ink, lineHeight = 21.sp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(color.copy(alpha = 0.08f))
                        .clickable { speaker.speak(homework.model, lang.locale) }
                        .padding(12.dp)
                )
                Text(
                    "La correction automatique vérifie les éléments clés attendus ; comparez votre texte au modèle " +
                        "pour l'orthographe et la grammaire.",
                    fontSize = 12.sp, color = InkSoft
                )
            }
        }
    }
}
