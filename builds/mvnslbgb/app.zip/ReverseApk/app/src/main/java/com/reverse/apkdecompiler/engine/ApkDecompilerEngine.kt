package com.reverse.apkdecompiler.engine

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest
import java.util.zip.Inflater
import java.util.zip.InflaterInputStream
import java.util.zip.ZipFile

/**
 * Moteur "force brute" : n'a JAMAIS besoin d'un AndroidManifest.xml / resources.arsc valides.
 *
 *  Étape 1 : ZipFile (index central) – entrée par entrée, chaque erreur est isolée.
 *  Étape 2 : si l'index central est cassé / piégé → "carving" : on cherche toutes les
 *            signatures PK\x03\x04 et on décompresse chaque entrée à la main (Inflater brut).
 *  Étape 3 : extraction des chaînes des .dex / .so / AndroidManifest.xml.
 */
class ApkDecompilerEngine(private val context: Context) {

    private class Session(val out: File) {
        var extracted = 0
        var partial = 0
        var failed = 0
        var bytes = 0L
        var dex = 0
        var so = 0
        val errors = ArrayList<String>()
        val scanTargets = ArrayList<Pair<File, String>>()
        fun err(m: String) { if (errors.size < 1000) errors.add(m) }
    }

    fun displayName(uri: Uri): String {
        val n: String? = try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        } catch (e: Exception) { null }
        return n ?: uri.lastPathSegment ?: "app.apk"
    }

    suspend fun run(
        uri: Uri,
        onProgress: (Progress) -> Unit,
        onLog: (String) -> Unit
    ): ExtractionReport = withContext(Dispatchers.IO) {
        val check: () -> Unit = { ensureActive() }
        val displayName = displayName(uri)
        val cache = File(context.cacheDir, "input_${System.nanoTime()}.apk")
        try {
            onProgress(Progress("Copie de l'APK", 0, 1, displayName))
            val sha = copyToCache(uri, cache, check)
            onLog("APK copié : ${cache.length() / 1024} Ko — SHA-256 ${sha.take(16)}…")

            val (label, pkg) = readMeta(cache, displayName.substringBeforeLast('.'))
            onLog(
                "Application : $label" +
                    (pkg?.let { " ($it)" } ?: " — manifeste illisible par Android, nom du fichier utilisé")
            )

            val base = OutputPaths.baseDir(context)
            val outDir = uniqueDir(File(base, OutputPaths.sanitize(label)))
            outDir.mkdirs()
            onLog("Sortie : ${outDir.absolutePath}")

            val s = Session(outDir)

            // ---- Étape 1 : ZipFile
            var mode = "ZipFile (index central)"
            val ok = extractWithZipFile(cache, s, onProgress, onLog, check)
            // ---- Étape 2 : carving si nécessaire
            if (!ok) {
                mode = "Carving des en-têtes locaux (force brute)"
                onLog("Index central inutilisable → bascule en carving")
                extractByCarving(cache, s, onProgress, onLog, check)
            }
            onLog("Extraction : ${s.extracted} OK, ${s.partial} partiels, ${s.failed} échecs")

            // ---- Étape 3 : chaînes
            val findings = scanStrings(s, onProgress, onLog, check)

            val report = ExtractionReport(
                appName = label,
                packageName = pkg,
                sha256 = sha,
                outputDir = outDir,
                mode = mode,
                extracted = s.extracted,
                partial = s.partial,
                failed = s.failed,
                totalBytes = s.bytes,
                manifestReadable = pkg != null,
                dexCount = s.dex,
                nativeLibCount = s.so,
                findings = findings,
                errors = s.errors
            )
            writeReports(report)
            onProgress(Progress("Terminé", 1, 1))
            onLog("Terminé ✔")
            report
        } finally {
            cache.delete()
        }
    }

    // ------------------------------------------------------------------ copie / méta

    private fun copyToCache(uri: Uri, dest: File, check: () -> Unit): String {
        val md = MessageDigest.getInstance("SHA-256")
        val input = context.contentResolver.openInputStream(uri)
            ?: throw IOException("Impossible d'ouvrir le fichier sélectionné")
        input.use { ins ->
            FileOutputStream(dest).use { out ->
                val buf = ByteArray(256 * 1024)
                while (true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    md.update(buf, 0, n)
                    check()
                }
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    /** Tente de lire le label/package via Android ; ne plante jamais. */
    private fun readMeta(apk: File, fallback: String): Pair<String, String?> {
        return try {
            val pm = context.packageManager
            val info = pm.getPackageArchiveInfo(apk.absolutePath, 0)
            val ai = info?.applicationInfo
            if (info != null && ai != null) {
                ai.sourceDir = apk.absolutePath
                ai.publicSourceDir = apk.absolutePath
                val label = ai.loadLabel(pm).toString().ifBlank { fallback }
                label to info.packageName
            } else fallback to null
        } catch (t: Throwable) {
            fallback to null
        }
    }

    private fun uniqueDir(wanted: File): File {
        if (!wanted.exists()) return wanted
        var i = 2
        while (true) {
            val c = File(wanted.parentFile, "${wanted.name}_$i")
            if (!c.exists()) return c
            i++
        }
    }

    // ------------------------------------------------------------------ étape 1

    private fun extractWithZipFile(
        apk: File, s: Session,
        onProgress: (Progress) -> Unit, onLog: (String) -> Unit, check: () -> Unit
    ): Boolean {
        val zip = try {
            ZipFile(apk)
        } catch (e: Throwable) {
            onLog("ZipFile impossible : ${e.javaClass.simpleName} ${e.message ?: ""}")
            return false
        }
        zip.use { z ->
            val entries = try {
                z.entries().toList()
            } catch (e: Throwable) {
                onLog("Lecture de l'index impossible : ${e.message}")
                return false
            }
            entries.forEachIndexed { i, e ->
                check()
                onProgress(Progress("Extraction", i, entries.size, e.name))
                if (e.isDirectory) {
                    destFor(s.out, e.name)?.mkdirs()
                } else {
                    writeEntry(s, e.name) { z.getInputStream(e) }
                }
            }
            onProgress(Progress("Extraction", entries.size, entries.size))
        }
        return s.extracted + s.partial > 0
    }

    // ------------------------------------------------------------------ étape 2

    private fun extractByCarving(
        apk: File, s: Session,
        onProgress: (Progress) -> Unit, onLog: (String) -> Unit, check: () -> Unit
    ) {
        val offsets = findLocalHeaders(apk, check)
        onLog("Carving : ${offsets.size} en-têtes locaux trouvés")
        offsets.forEachIndexed { i, off ->
            check()
            try {
                var name = ""
                var method = 0
                var flags = 0
                var csize = 0L
                var dataStart = 0L
                RandomAccessFile(apk, "r").use { raf ->
                    raf.seek(off)
                    val h = ByteArray(30)
                    raf.readFully(h)
                    val bb = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN)
                    flags = bb.getShort(6).toInt()
                    method = bb.getShort(8).toInt() and 0xFFFF
                    csize = bb.getInt(18).toLong() and 0xFFFFFFFFL
                    val nl = bb.getShort(26).toInt() and 0xFFFF
                    val el = bb.getShort(28).toInt() and 0xFFFF
                    val nb = ByteArray(nl)
                    raf.readFully(nb)
                    name = String(nb, Charsets.UTF_8)
                    dataStart = off + 30 + nl + el
                }
                onProgress(Progress("Carving", i, offsets.size, name))
                if (name.isEmpty()) return@forEachIndexed
                if (name.endsWith("/")) {
                    destFor(s.out, name)?.mkdirs()
                    return@forEachIndexed
                }
                val m = method; val cs = csize; val fl = flags; val ds = dataStart
                writeEntry(s, name) {
                    val fis = FileInputStream(apk)
                    fis.channel.position(ds)
                    val raw = BufferedInputStream(fis, 64 * 1024)
                    when (m) {
                        0 -> {
                            if (cs == 0L && (fl and 8) != 0) {
                                raw.close(); throw IOException("taille inconnue (data descriptor)")
                            }
                            LimitedInputStream(raw, cs)
                        }
                        8 -> {
                            val inf = Inflater(true)
                            object : InflaterInputStream(raw, inf, 64 * 1024) {
                                override fun close() {
                                    try { super.close() } finally { inf.end() }
                                }
                            }
                        }
                        else -> {
                            raw.close(); throw IOException("méthode de compression $m non supportée")
                        }
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                s.failed++
                s.err("Carving @$off : ${e.javaClass.simpleName} ${e.message ?: ""}")
            }
        }
        onProgress(Progress("Carving", offsets.size, offsets.size))
    }

    private fun findLocalHeaders(f: File, check: () -> Unit): List<Long> {
        val res = ArrayList<Long>()
        FileInputStream(f).use { ins ->
            val buf = ByteArray(256 * 1024)
            var win = 0
            var pos = 0L
            while (true) {
                val n = ins.read(buf)
                if (n < 0) break
                for (i in 0 until n) {
                    win = (win shl 8) or (buf[i].toInt() and 0xFF)
                    pos++
                    if (win == 0x504B0304) res.add(pos - 4)
                }
                check()
            }
        }
        return res
    }

    private class LimitedInputStream(private val src: InputStream, private var left: Long) : InputStream() {
        override fun read(): Int {
            if (left <= 0) return -1
            val b = src.read()
            if (b >= 0) left--
            return b
        }
        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (left <= 0) return -1
            val n = src.read(b, off, minOf(len.toLong(), left).toInt())
            if (n > 0) left -= n
            return n
        }
        override fun close() = src.close()
    }

    // ------------------------------------------------------------------ écriture d'une entrée

    /** Chemin de sortie sûr (anti zip-slip, noms obfusqués nettoyés). */
    private fun destFor(out: File, rawName: String): File? {
        val parts = rawName.replace('\\', '/').split('/')
            .filter { it.isNotEmpty() && it != "." && it != ".." }
            .map { OutputPaths.sanitizeSegment(it) }
        if (parts.isEmpty()) return null
        val f = File(out, parts.joinToString("/"))
        return try {
            if (f.canonicalPath.startsWith(out.canonicalPath + File.separator)) f else null
        } catch (e: IOException) { null }
    }

    private fun uniqueFile(f: File): File {
        if (!f.exists()) return f
        val ext = f.extension.let { if (it.isEmpty()) "" else ".$it" }
        val base = f.nameWithoutExtension
        var i = 1
        while (true) {
            val c = File(f.parentFile, "${base}__dup$i$ext")
            if (!c.exists()) return c
            i++
        }
    }

    /** Écrit une entrée en conservant tout ce qui peut l'être, même si le flux est tronqué/corrompu. */
    private fun writeEntry(s: Session, name: String, open: () -> InputStream) {
        val target = destFor(s.out, name)
        if (target == null) {
            s.failed++; s.err("Nom invalide ignoré : $name"); return
        }
        var dest = uniqueFile(target)
        try {
            dest.parentFile?.mkdirs()
            if (dest.parentFile?.isDirectory != true) throw IOException("conflit de chemin")
        } catch (e: Throwable) {
            val flat = OutputPaths.sanitizeSegment(name.substringAfterLast('/'))
            dest = uniqueFile(File(File(s.out, "_recovered"), flat))
            dest.parentFile?.mkdirs()
        }

        var written = 0L
        var state = 0 // 0 = OK, 1 = partiel, 2 = échec
        try {
            open().use { input ->
                FileOutputStream(dest).use { out ->
                    val buf = ByteArray(64 * 1024)
                    try {
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            written += n
                        }
                    } catch (e: Throwable) {
                        state = 1
                        s.err("Flux tronqué ($written o conservés) : $name — ${e.message}")
                    }
                }
            }
        } catch (e: Throwable) {
            state = 2
            s.err("Échec : $name — ${e.javaClass.simpleName} ${e.message ?: ""}")
        }

        when {
            state == 2 && written == 0L -> { s.failed++; dest.delete(); return }
            state == 0 -> s.extracted++
            else -> s.partial++
        }
        s.bytes += written

        val lower = name.lowercase()
        val rel = dest.relativeTo(s.out).invariantSeparatorsPath
        when {
            lower.endsWith(".dex") -> { s.dex++; s.scanTargets.add(dest to rel) }
            lower.endsWith(".so") -> { s.so++; s.scanTargets.add(dest to rel) }
            lower == "androidmanifest.xml" -> s.scanTargets.add(dest to rel)
        }
    }

    // ------------------------------------------------------------------ étape 3

    private fun scanStrings(
        s: Session, onProgress: (Progress) -> Unit, onLog: (String) -> Unit, check: () -> Unit
    ): Map<String, List<Pair<String, String>>> {
        val collector = FindingsCollector()
        val dir = File(s.out, "_analysis/strings").apply { mkdirs() }
        val total = s.scanTargets.size
        s.scanTargets.forEachIndexed { i, (file, rel) ->
            check()
            onProgress(Progress("Analyse des chaînes", i, total, rel))
            try {
                val outFile = File(dir, rel.replace("/", "__") + ".txt")
                val isManifest = rel.equals("AndroidManifest.xml", ignoreCase = true)
                val n = StringScanner.scanFile(file, rel, outFile, isManifest, collector, check)
                onLog("$rel : $n chaînes")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                s.err("Analyse de $rel impossible : ${e.message}")
            }
        }
        onProgress(Progress("Analyse des chaînes", total, total))
        return collector.snapshot()
    }

    private fun writeReports(r: ExtractionReport) {
        try {
            val dir = File(r.outputDir, "_analysis").apply { mkdirs() }
            File(dir, "summary.txt").writeText(buildString {
                appendLine("Application : ${r.appName}")
                appendLine("Package     : ${r.packageName ?: "(illisible)"}")
                appendLine("SHA-256     : ${r.sha256}")
                appendLine("Mode        : ${r.mode}")
                appendLine("Fichiers    : ${r.extracted} OK / ${r.partial} partiels / ${r.failed} échecs")
                appendLine("Octets      : ${r.totalBytes}")
                appendLine("DEX         : ${r.dexCount}")
                appendLine("Libs natives: ${r.nativeLibCount}")
                r.findings.forEach { (k, v) -> appendLine("$k : ${v.size}") }
            })
            val j = JSONObject()
            r.findings.forEach { (cat, list) ->
                val arr = JSONArray()
                list.forEach { (v, src) -> arr.put(JSONObject().put("value", v).put("source", src)) }
                j.put(cat, arr)
            }
            File(dir, "findings.json").writeText(j.toString(2))
            if (r.errors.isNotEmpty()) File(dir, "errors.txt").writeText(r.errors.joinToString("\n"))
        } catch (e: Throwable) { /* rapports non critiques */ }
    }
}
