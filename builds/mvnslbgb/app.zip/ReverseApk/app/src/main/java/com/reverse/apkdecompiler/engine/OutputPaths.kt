package com.reverse.apkdecompiler.engine

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import androidx.core.content.ContextCompat
import java.io.File

/** Gère l'arborescence imposée : Reverse app / Apk décompiler / <nom de l'app>. */
object OutputPaths {
    const val ROOT_FOLDER = "Reverse app"
    const val SUB_FOLDER = "Apk décompiler"

    private val BAD_CHARS = Regex("[\\\\/:*?\"<>|\\u0000-\\u001F]")

    fun hasFullAccess(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED
        }

    /**
     * <stockage>/Reverse app/Apk décompiler si l'accès complet est accordé,
     * sinon repli vers Android/data/<pkg>/files/Reverse app/Apk décompiler.
     */
    @Suppress("DEPRECATION")
    fun baseDir(ctx: Context, create: Boolean = true): File {
        val shared = File(File(Environment.getExternalStorageDirectory(), ROOT_FOLDER), SUB_FOLDER)
        if (hasFullAccess(ctx)) {
            if (!create) return shared
            if (shared.isDirectory || shared.mkdirs()) return shared
        }
        val appRoot = ctx.getExternalFilesDir(null) ?: ctx.filesDir
        val fallback = File(File(appRoot, ROOT_FOLDER), SUB_FOLDER)
        if (create) fallback.mkdirs()
        return fallback
    }

    /** Nom de dossier d'application sûr. */
    fun sanitize(raw: String, max: Int = 80): String =
        raw.replace(BAD_CHARS, "_").trim().trim('.').take(max).ifBlank { "app" }

    /** Segment de chemin issu d'une entrée ZIP (potentiellement obfusquée). */
    fun sanitizeSegment(raw: String): String =
        raw.replace(BAD_CHARS, "_").take(200).ifBlank { "_" }
}
