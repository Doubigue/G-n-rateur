package com.reverse.apkdecompiler.ui

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(vm: MainViewModel) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }

    // Rafraîchit l'état de la permission au retour des réglages système
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) vm.refreshAccess() }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.analyze(uri)
    }
    val legacyPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        vm.refreshAccess()
    }

    fun requestAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val uri = Uri.fromParts("package", ctx.packageName, null)
            try {
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, uri))
            } catch (e: Exception) {
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else legacyPerm.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
    }

    fun share(zip: File) {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", zip)
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "application/zip"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(i, "Partager l'archive"))
    }

    val root = ui.report?.outputDir
    BackHandler(enabled = tab == 1 && root != null && ui.explorerDir != root) { vm.up() }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Reverse APK") }) },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 },
                    icon = { Text("🔬") }, label = { Text("Analyse") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 },
                    icon = { Text("📁") }, label = { Text("Explorateur") })
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (tab == 0) {
                AnalyseTab(
                    ui = ui,
                    onPick = { picker.launch(arrayOf("*/*")) },
                    onCancel = vm::cancel,
                    onGrant = ::requestAccess,
                    onZip = vm::zip,
                    onShare = { ui.zipFile?.let(::share) }
                )
            } else {
                ExplorerTab(ui, vm)
            }
        }
    }

    ui.preview?.let { p ->
        AlertDialog(
            onDismissRequest = vm::closePreview,
            confirmButton = { TextButton(onClick = vm::closePreview) { Text("Fermer") } },
            title = { Text(p.title, maxLines = 2) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    SelectionContainer { Mono(p.body, 11) }
                }
            }
        )
    }
}

// ============================================================ onglet Analyse

@Composable
private fun AnalyseTab(
    ui: UiState,
    onPick: () -> Unit,
    onCancel: () -> Unit,
    onGrant: () -> Unit,
    onZip: () -> Unit,
    onShare: () -> Unit
) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            AppCard {
                Text("Dossier de sortie", style = MaterialTheme.typography.titleSmall)
                Mono(ui.outputBase, 12)
                if (!ui.hasAccess) {
                    Text(
                        "Accès complet au stockage non accordé : les fichiers seront écrits dans le dossier " +
                            "privé de l'application. Accordez l'accès pour créer « Reverse app » à la racine.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedButton(onClick = onGrant) { Text("Autoriser l'accès aux fichiers") }
                }
            }
        }

        item {
            AppCard {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onPick, enabled = !ui.running && !ui.zipping) { Text("Choisir un APK") }
                    if (ui.running) OutlinedButton(onClick = onCancel) { Text("Annuler") }
                }
                ui.selectedName?.let { Mono(it, 12) }
            }
        }

        if (ui.running || ui.zipping) {
            item {
                AppCard {
                    Text(ui.phase, style = MaterialTheme.typography.titleSmall)
                    if (ui.total > 0) {
                        LinearProgressIndicator(
                            progress = { ui.done.toFloat() / ui.total },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text("${ui.done} / ${ui.total}", style = MaterialTheme.typography.bodySmall)
                    } else {
                        LinearProgressIndicator(Modifier.fillMaxWidth())
                    }
                    if (ui.current.isNotEmpty()) Mono(ui.current, 11)
                }
            }
        }

        ui.error?.let { err ->
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                    Text(err, Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onErrorContainer)
                }
            }
        }

        ui.report?.let { r ->
            item {
                AppCard {
                    Text(r.appName, style = MaterialTheme.typography.titleMedium)
                    Mono(r.packageName ?: "package illisible (manifeste protégé/corrompu)", 12)
                    Text("Mode : ${r.mode}", style = MaterialTheme.typography.bodySmall)
                    Text(
                        "${r.extracted} fichiers OK · ${r.partial} partiels · ${r.failed} échecs · ${fmt(r.totalBytes)}",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text("${r.dexCount} DEX · ${r.nativeLibCount} libs natives", style = MaterialTheme.typography.bodySmall)
                    Mono(r.outputDir.absolutePath, 11)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = onZip, enabled = !ui.zipping) { Text("Archiver en .zip") }
                        if (ui.zipFile != null) OutlinedButton(onClick = onShare) { Text("Partager") }
                    }
                    ui.zipFile?.let { Mono(it.absolutePath, 11) }
                }
            }
            r.findings.forEach { (cat, items) ->
                item(key = cat) { FindingsSection(cat, items) }
            }
        }

        if (ui.logs.isNotEmpty()) {
            item {
                AppCard {
                    Text("Journal", style = MaterialTheme.typography.titleSmall)
                    ui.logs.takeLast(40).forEach { Mono(it, 11) }
                }
            }
        }
    }
}

@Composable
private fun FindingsSection(title: String, items: List<Pair<String, String>>) {
    var open by remember { mutableStateOf(false) }
    AppCard {
        Row(
            Modifier.fillMaxWidth().clickable { open = !open },
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("$title (${items.size})", style = MaterialTheme.typography.titleSmall)
            Text(if (open) "▲" else "▼")
        }
        if (open) {
            SelectionContainer {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items.take(100).forEach { (v, src) ->
                        Column {
                            Mono(v, 12)
                            Text("↳ $src", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
            if (items.size > 100) {
                Text(
                    "… ${items.size - 100} de plus dans _analysis/findings.json",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

// ============================================================ onglet Explorateur

@Composable
private fun ExplorerTab(ui: UiState, vm: MainViewModel) {
    val root = ui.report?.outputDir
    val cur = ui.explorerDir
    if (root == null || cur == null) {
        Box(Modifier.fillMaxSize().padding(24.dp)) {
            Text("Analysez d'abord un APK pour explorer son contenu.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        return
    }
    Column(Modifier.fillMaxSize()) {
        Mono(cur.relativeTo(root.parentFile ?: root).path, 12, Modifier.padding(16.dp, 8.dp))
        LazyColumn(Modifier.fillMaxSize()) {
            if (cur != root) {
                item {
                    Row(Modifier.fillMaxWidth().clickable { vm.up() }.padding(16.dp, 12.dp)) {
                        Text("⬆️  ..")
                    }
                }
            }
            items(ui.explorerEntries, key = { it.absolutePath }) { f ->
                Row(
                    Modifier.fillMaxWidth()
                        .clickable { if (f.isDirectory) vm.openDir(f) else vm.openFile(f) }
                        .padding(16.dp, 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        (if (f.isDirectory) "📁 " else "📄 ") + f.name,
                        modifier = Modifier.weight(1f),
                        maxLines = 1
                    )
                    if (f.isFile) Text(fmt(f.length()), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

// ============================================================ utilitaires UI

@Composable
private fun AppCard(content: @Composable () -> Unit) {
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { content() }
    }
}

@Composable
private fun Mono(text: String, size: Int = 12, modifier: Modifier = Modifier) {
    Text(text, modifier = modifier, fontFamily = FontFamily.Monospace, fontSize = size.sp)
}

private fun fmt(b: Long): String = when {
    b >= 1 shl 20 -> "%.1f Mo".format(b / 1048576.0)
    b >= 1 shl 10 -> "%.1f Ko".format(b / 1024.0)
    else -> "$b o"
}
