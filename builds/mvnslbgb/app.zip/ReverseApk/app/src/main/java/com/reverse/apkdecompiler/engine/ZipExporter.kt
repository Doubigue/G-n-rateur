package com.reverse.apkdecompiler.engine

import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object ZipExporter {
    /**
     * Archive [dir] dans <parent>/<nom>.zip (à côté du dossier, jamais dedans).
     * Le ZIP contient le dossier racine nommé d'après l'application.
     */
    fun zipFolder(
        dir: File,
        onProgress: (done: Int, total: Int) -> Unit,
        check: () -> Unit
    ): File {
        val target = File(dir.parentFile, dir.name + ".zip")
        if (target.exists()) target.delete()
        val files = dir.walkTopDown().filter { it.isFile }.toList()
        val base = dir.parentFile ?: dir
        ZipOutputStream(BufferedOutputStream(FileOutputStream(target))).use { zos ->
            files.forEachIndexed { i, f ->
                check()
                zos.putNextEntry(ZipEntry(f.relativeTo(base).invariantSeparatorsPath))
                f.inputStream().use { it.copyTo(zos) }
                zos.closeEntry()
                onProgress(i + 1, files.size)
            }
        }
        return target
    }
}
