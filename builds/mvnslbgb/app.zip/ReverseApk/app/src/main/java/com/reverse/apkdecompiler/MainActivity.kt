package com.reverse.apkdecompiler

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.reverse.apkdecompiler.ui.MainScreen
import com.reverse.apkdecompiler.ui.MainViewModel
import com.reverse.apkdecompiler.ui.theme.ReverseTheme

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        // "Ouvrir avec Reverse APK" depuis un gestionnaire de fichiers
        if (savedInstanceState == null && intent?.action == Intent.ACTION_VIEW) {
            intent.data?.let { vm.analyze(it) }
        }
        setContent { ReverseTheme { MainScreen(vm) } }
    }
}
