package com.reverse.apkdecompiler.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Color(0xFF80CBC4),
    onPrimary = Color(0xFF00201D),
    secondary = Color(0xFFB0BEC5),
    background = Color(0xFF101214),
    onBackground = Color(0xFFE3E3E3),
    surface = Color(0xFF101214),
    onSurface = Color(0xFFE3E3E3),
    surfaceVariant = Color(0xFF1C2024),
    onSurfaceVariant = Color(0xFFA9B0B5),
    error = Color(0xFFFFB4AB),
    errorContainer = Color(0xFF5C1A14),
    onErrorContainer = Color(0xFFFFDAD6)
)

/** Thème sombre natif, toujours actif. */
@Composable
fun ReverseTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkColors, content = content)
}
