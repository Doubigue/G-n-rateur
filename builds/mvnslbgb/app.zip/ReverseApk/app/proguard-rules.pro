# Aucune règle spécifique (minification désactivée).
