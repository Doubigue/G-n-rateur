# LocalShare 3 — Wi-Fi Direct + serveur web (Android natif, Kotlin)

Deux façons de partager, sans Internet ni données mobiles :

**1. Téléphone ↔ téléphone, en Wi-Fi Direct (comme Quick Share / Xender, sans Bluetooth)**
- Découverte automatique des téléphones proches (DNS-SD Wi-Fi Direct, `_localshare._tcp`), invitation sans mot de passe,
  puis code de vérification à 4 chiffres identique des deux côtés → Accepter.
- Le groupe Wi-Fi Direct est créé même si le téléphone est déjà connecté à un Wi-Fi (trafic forcé sur le Wi-Fi Direct).
- Envoi de fichiers (reçus dans `DoubigueShare`) et de texte, progression, vitesse, durée restante, annulation.
- **Ses fichiers** : parcourir tout le stockage de l'autre téléphone, filtre par jour (Tout / Aujourd'hui / Hier / un jour),
  téléchargement multiple. L'autre téléphone doit **autoriser** (limité au stockage interne, révocable, remis à zéro à la déconnexion).
- **Ses applications** : liste avec icônes, version, recherche, apps système masquables, et récupération de l'APK.
- **Menu « Partager » d'Android** : appui long sur un fichier → Partager → LocalShare → choisir l'appareil → envoi dès l'accord.
- **Fichiers reçus** : liste avec filtre par jour, ouverture avec n'importe quelle appli, suppression (appui long).
- Service au premier plan + notifications (demandes, progression, terminé) : l'appli reste connectée écran éteint.

**2. Appareil quelconque via navigateur (PC, autre téléphone), sans installation** — écran « Serveur web / QR »
- QR Code + adresse `http://192.168.x.x:8080/?t=…`, serveur NanoHTTPD dans un service de premier plan.
- Explorateur de fichiers, lecture vidéo/audio en streaming (Range), téléchargement.
- Envoi par glisser-déposer ou sélection multiple (débit et progression affichés).
- Grille des applications installées (icône, nom, taille) avec téléchargement de l'APK (`.apks` pour les apps découpées).
- Jeton de session : sans lui, personne d'autre sur le réseau ne peut lire le stockage.

## Structure
```
settings.gradle  build.gradle  gradle.properties  gradle/wrapper/gradle-wrapper.properties
app/build.gradle
app/src/main/AndroidManifest.xml
app/src/main/assets/index.html               <- dashboard web (serveur web)
app/src/main/java/com/example/localshare/
  App.kt                  moteurs partagés (vivent autant que le processus)
  P2pEngine.kt            Wi-Fi Direct : annonce, découverte, connexion, code, lien TCP
  DirectLink.kt           trames TCP (port 8988), identiques à LocalShare 2.0 Flutter
  TransferManager.kt      envoi/réception, texte, file « Partager », notifications
  RemoteFs.kt             fichiers/applications de l'autre téléphone (client + serveur)
  AppsLister.kt  Storage.kt  Notifier.kt  Support.kt  RowAdapter.kt
  P2pService.kt           service Wi-Fi Direct      ShareService.kt  service serveur web
  LocalServer.kt          serveur HTTP (NanoHTTPD)
  MainActivity.kt         accueil, appareils proches   SessionActivity.kt  session connectée
  BrowserActivity.kt      explorateur + filtre jour    AppsActivity.kt     applications distantes
  WebServerActivity.kt    QR Code / serveur web
app/src/main/res/...      layouts, icône adaptative (fond bleu nuit), file_paths.xml
ic_launcher-playstore.png icône 512 px
```

## Compiler
Le zip est un **projet Gradle complet** (`settings.gradle`, `build.gradle`, `gradle.properties`, `app/`).
1. Décompressez, puis dans Android Studio (Ladybug ou plus récent) : **File > Open** et choisissez le dossier `LocalShare`.
2. Laissez Android Studio synchroniser (il télécharge Gradle 8.9, le plugin Android 8.7.3 et Kotlin 2.0.21 ; JDK 17 inclus).
3. Branchez un téléphone Android 7+ (débogage USB) et **Run**.

Versions utilisées : Gradle 8.9 · Android Gradle Plugin 8.7.3 · Kotlin 2.0.21 · compileSdk/targetSdk 35 · minSdk 24.
Si vous voulez compiler en ligne de commande (`./gradlew assembleDebug`), générez d'abord le script avec
`gradle wrapper --gradle-version 8.9` (le fichier `gradle-wrapper.jar` n'est pas inclus dans ce zip).

## Tester (Wi-Fi Direct)
1. Sur les deux téléphones : Wi-Fi activé (inutile d'être connecté à un réseau) ; localisation activée sur Android 12 et moins.
2. Ouvrez LocalShare, acceptez les autorisations. Chaque téléphone apparaît dans la liste de l'autre.
3. Touchez l'autre téléphone → sur lui, Android affiche l'invitation Wi-Fi Direct → **Accepter**
   → LocalShare affiche un code à 4 chiffres identique des deux côtés → **Accepter**.
4. Session : Envoyer des fichiers / du texte, Ses fichiers, Ses applications, Reçus.
5. Test du partage Android : dans la Galerie, partagez une photo → LocalShare → touchez l'appareil.

## Tester (serveur web)
Accueil → « Serveur web / QR » → Activer → scanner le QR Code depuis un PC ou un autre téléphone sur le même Wi-Fi
(ou connecté au hotspot de ce téléphone).

## Limites et points d'attention
- **Non compilé ni testé sur appareil** dans cette livraison : prévoir un premier passage de correction après la
  compilation (versions de dépendances, avertissements).
- Compatible avec le protocole de LocalShare 2.0 Flutter (mêmes trames, même port 8988, même type DNS-SD) ;
  la demande d'APK (`getapk`) est une extension ignorée par l'ancienne version.
- Certains téléphones coupent le Wi-Fi classique pendant le Wi-Fi Direct (rétabli à la déconnexion) ; l'invitation
  Wi-Fi Direct d'Android ne peut pas être supprimée ; sur certains Samsung/Xiaomi un PIN peut être demandé
  (c'est celui affiché sur l'autre téléphone).
- Sur Android 11+, « Accès à tous les fichiers » est nécessaire (dossier `DoubigueShare`, parcours à distance).
  Pour une publication Play Store, `MANAGE_EXTERNAL_STORAGE`, `QUERY_ALL_PACKAGES`, `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS`
  et le service `specialUse` demandent une déclaration de politique ; sans souci en usage personnel.
- Le serveur web utilise du HTTP en clair : à réserver aux réseaux de confiance (ou au hotspot du téléphone).
  Le dashboard n'utilise pas le CDN Tailwind (inutilisable sans Internet) : le CSS est intégré.
- Les dossiers ne se déposent pas dans l'interface web (fichiers uniquement) ; sur Android 11+ `/Android/data` n'est pas exposé.
- Écran volontairement simple (vues Material standard) : l'interface n'a pas été retravaillée.
