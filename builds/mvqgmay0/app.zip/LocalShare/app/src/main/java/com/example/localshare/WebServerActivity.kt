package com.example.localshare

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.button.MaterialButton
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Serveur web : n'importe quel appareil (PC, téléphone) accède au stockage et aux applications depuis un
 * simple navigateur en scannant le QR Code — aucune installation sur l'appareil distant.
 */
class WebServerActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var tvUrl: TextView
    private lateinit var tvHint: TextView
    private lateinit var ivQr: ImageView
    private lateinit var qrCard: View
    private lateinit var btnToggle: MaterialButton
    private lateinit var btnPerm: MaterialButton

    private var shownUrl: String? = null
    private var lastQrUrl: String? = null

    private val notifPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { startServer() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_web)

        tvStatus = findViewById(R.id.tvStatus)
        tvUrl = findViewById(R.id.tvUrl)
        tvHint = findViewById(R.id.tvHint)
        ivQr = findViewById(R.id.ivQr)
        qrCard = findViewById(R.id.qrCard)
        btnToggle = findViewById(R.id.btnToggle)
        btnPerm = findViewById(R.id.btnPerm)

        btnToggle.setOnClickListener { onToggle() }
        btnPerm.setOnClickListener { Storage.requestAccess(this) }
        tvUrl.setOnClickListener {
            val url = shownUrl ?: return@setOnClickListener
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("LocalShare", url))
            Toast.makeText(this, "Adresse copiée", Toast.LENGTH_SHORT).show()
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { ServerState.status.collect { render() } }
                // Rafraîchit l'IP si l'utilisateur change de Wi-Fi / active le hotspot.
                launch { while (true) { render(); delay(2500) } }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        val st = ServerState.status.value
        btnPerm.visibility = if (Storage.hasAccess(this)) View.GONE else View.VISIBLE

        if (!st.running) {
            tvStatus.text = st.error ?: "Serveur arrêté"
            btnToggle.text = "Activer le serveur"
            hideQr()
            return
        }
        btnToggle.text = "Désactiver le serveur"
        val ip = NetUtils.localIp()
        if (ip == null) {
            tvStatus.text = "Serveur actif, mais aucun réseau local détecté.\nConnectez-vous au Wi-Fi ou activez le point d’accès."
            hideQr()
            return
        }
        val url = "http://$ip:${st.port}/?t=${st.token}"
        tvStatus.text = "Serveur actif — en attente de connexions"
        tvUrl.text = url
        tvUrl.visibility = View.VISIBLE
        tvHint.visibility = View.VISIBLE
        qrCard.visibility = View.VISIBLE
        shownUrl = url
        if (url != lastQrUrl) {
            lastQrUrl = url
            lifecycleScope.launch { ivQr.setImageBitmap(makeQr(url)) }
        }
    }

    private fun hideQr() {
        qrCard.visibility = View.GONE
        tvUrl.visibility = View.GONE
        tvHint.visibility = View.GONE
        shownUrl = null
        lastQrUrl = null
    }

    private suspend fun makeQr(text: String, size: Int = 900): Bitmap = withContext(Dispatchers.Default) {
        val hints = mapOf<EncodeHintType, Any>(
            EncodeHintType.MARGIN to 1,
            EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M,
            EncodeHintType.CHARACTER_SET to "UTF-8"
        )
        val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size, hints)
        val w = m.width
        val h = m.height
        val px = IntArray(w * h)
        for (y in 0 until h) for (x in 0 until w) px[y * w + x] = if (m.get(x, y)) Color.BLACK else Color.WHITE
        Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    private fun onToggle() {
        if (ServerState.status.value.running) {
            startService(Intent(this, ShareService::class.java).setAction(ShareService.ACTION_STOP))
            return
        }
        if (!Storage.hasAccess(this)) {
            Toast.makeText(this, "Autorisez d’abord l’accès aux fichiers", Toast.LENGTH_LONG).show()
            Storage.requestAccess(this)
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        startServer()
    }

    private fun startServer() {
        ContextCompat.startForegroundService(this, Intent(this, ShareService::class.java))
    }
}
