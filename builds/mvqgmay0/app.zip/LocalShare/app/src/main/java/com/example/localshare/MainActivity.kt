package com.example.localshare

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import kotlinx.coroutines.launch

/** Accueil : appareils à proximité en Wi-Fi Direct, connexion, partage depuis le menu « Partager » d'Android. */
class MainActivity : AppCompatActivity() {

    private val p2p get() = app.p2p
    private val transfers get() = app.transfers

    private lateinit var tvName: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvShare: TextView
    private lateinit var tvEmpty: TextView
    private lateinit var btnFix: Button
    private lateinit var btnOpen: Button
    private lateinit var adapter: RowAdapter<Peer>

    private var pendingDialog: AlertDialog? = null
    private var shownPendingCode: String? = null
    private var lastOpenedId: String? = null
    private var askedOnce = false
    private var fromFix = false

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (fromFix && !p2p.hasPermission()) openAppSettings()
            fromFix = false
            p2p.start()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        tvName = findViewById(R.id.tvName)
        tvStatus = findViewById(R.id.tvStatus)
        tvShare = findViewById(R.id.tvShare)
        tvEmpty = findViewById(R.id.tvEmpty)
        btnFix = findViewById(R.id.btnFix)
        btnOpen = findViewById(R.id.btnOpen)

        adapter = RowAdapter(
            bind = { h, p ->
                h.title.text = p.name
                h.sub.text = if (p.state == PeerState.CONNECTING) "Connexion…" else "Touchez pour se connecter"
            },
            onClick = { p -> p2p.connectTo(p.id) }
        )
        findViewById<RecyclerView>(R.id.list).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }

        findViewById<MaterialSwitch>(R.id.swVisible).setOnCheckedChangeListener { _, c -> p2p.setVisible(c) }
        btnFix.setOnClickListener { onFix() }
        btnOpen.setOnClickListener { startActivity(Intent(this, SessionActivity::class.java)) }
        tvShare.setOnClickListener {
            transfers.clearQueue()
            Toast.makeText(this, "Envoi annulé", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btnWeb).setOnClickListener { startActivity(Intent(this, WebServerActivity::class.java)) }
        findViewById<Button>(R.id.btnReceived).setOnClickListener {
            startActivity(Intent(this, BrowserActivity::class.java).putExtra(BrowserActivity.EXTRA_MODE, BrowserActivity.MODE_LOCAL))
        }
        findViewById<Button>(R.id.btnAccess).setOnClickListener { Storage.requestAccess(this) }
        findViewById<Button>(R.id.btnBattery).setOnClickListener { requestBatteryExemption() }
        findViewById<Button>(R.id.btnRename).setOnClickListener { askRename() }
        findViewById<Button>(R.id.btnQuit).setOnClickListener {
            p2p.shutdown()
            stopService(Intent(this, P2pService::class.java))
            finishAffinity()
        }

        if (savedInstanceState == null) handleShareIntent(intent)

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { p2p.state.collect { render(it) } }
                launch { transfers.tick.collect { renderShare() } }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleShareIntent(intent)
    }

    override fun onStart() {
        super.onStart()
        ensureAndStart()
    }

    // ---------------------------------------------------------------- partage Android
    private fun handleShareIntent(i: Intent?) {
        if (i == null) return
        if (i.action == Intent.ACTION_SEND || i.action == Intent.ACTION_SEND_MULTIPLE) {
            transfers.queueFromIntent(i)
            i.action = null
        }
    }

    private fun renderShare() {
        val n = transfers.queuedCount
        tvShare.visibility = if (n > 0) View.VISIBLE else View.GONE
        tvShare.text = "$n élément(s) à envoyer : touchez l’appareil destinataire (touchez ici pour annuler)."
    }

    // ---------------------------------------------------------------- permissions
    private fun neededPermissions(): Array<String> {
        val l = p2p.requiredPermissions().toMutableList()
        if (Build.VERSION.SDK_INT >= 33) l += Manifest.permission.POST_NOTIFICATIONS
        return l.toTypedArray()
    }

    private fun ensureAndStart() {
        if (!p2p.hasPermission() && !askedOnce) {
            askedOnce = true
            permLauncher.launch(neededPermissions())
        } else {
            p2p.start()
        }
    }

    private fun onFix() {
        when {
            !p2p.hasPermission() -> {
                fromFix = true
                permLauncher.launch(neededPermissions())
            }
            p2p.state.value.statusNeedsSettings -> openAppSettings()
            else -> p2p.restart()
        }
    }

    private fun openAppSettings() {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }

    private fun requestBatteryExemption() {
        try {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    private fun askRename() {
        val et = EditText(this).apply { setText(p2p.state.value.deviceName); setSelectAllOnFocus(true) }
        MaterialAlertDialogBuilder(this)
            .setTitle("Nom de votre appareil")
            .setView(et)
            .setPositiveButton("Enregistrer") { _, _ -> p2p.renameDevice(et.text.toString()) }
            .setNegativeButton("Annuler", null)
            .show()
    }

    // ---------------------------------------------------------------- affichage
    private fun render(s: P2pState) {
        tvName.text = "Mon nom : ${s.deviceName}"

        val lines = mutableListOf<String>()
        s.status?.let { lines += it }
        s.info?.let { lines += it }
        s.outgoingCode?.let { lines += "Code de vérification : $it (le même doit s’afficher sur l’autre téléphone)" }
        if (lines.isEmpty()) {
            lines += when {
                s.isConnected -> "Connecté à ${s.connectedName}"
                s.advertising && s.discovering -> "Visible comme « ${s.deviceName} » · recherche en cours…"
                s.advertising -> "Visible comme « ${s.deviceName} »"
                s.discovering -> "Recherche d’appareils…"
                else -> "Inactif"
            }
        }
        tvStatus.text = lines.joinToString("\n")

        btnFix.visibility = if (s.status != null) View.VISIBLE else View.GONE
        btnFix.text = if (s.statusNeedsSettings) "Autoriser" else "Réessayer"
        btnOpen.visibility = if (s.isConnected) View.VISIBLE else View.GONE

        val shown = s.peers.filter { it.state != PeerState.CONNECTED }
        adapter.submit(shown)
        tvEmpty.visibility = if (shown.isEmpty()) View.VISIBLE else View.GONE

        // Demande de connexion entrante.
        val pc = s.pending
        if (pc != null) {
            if (pendingDialog?.isShowing != true || shownPendingCode != pc.code) {
                pendingDialog?.dismiss()
                shownPendingCode = pc.code
                pendingDialog = MaterialAlertDialogBuilder(this)
                    .setTitle("Demande de connexion")
                    .setMessage(
                        "« ${pc.name} » veut se connecter à votre appareil (Wi-Fi Direct).\n\n" +
                                "Code : ${pc.code}\nVérifiez que le même code s’affiche sur l’autre appareil."
                    )
                    .setCancelable(false)
                    .setPositiveButton("Accepter") { _, _ -> p2p.acceptPending() }
                    .setNegativeButton("Refuser") { _, _ -> p2p.rejectPending() }
                    .show()
            }
        } else {
            pendingDialog?.dismiss()
            pendingDialog = null
            shownPendingCode = null
        }

        // Session ouverte automatiquement une fois par connexion.
        if (s.connectedId != null) {
            if (s.connectedId != lastOpenedId) {
                lastOpenedId = s.connectedId
                startActivity(Intent(this, SessionActivity::class.java))
            }
        } else {
            lastOpenedId = null
        }
    }

    override fun onDestroy() {
        pendingDialog?.dismiss()
        super.onDestroy()
    }
}
