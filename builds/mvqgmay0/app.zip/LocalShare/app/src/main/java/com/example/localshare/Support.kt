package com.example.localshare

import kotlinx.coroutines.flow.MutableStateFlow
import java.net.Inet4Address
import java.net.NetworkInterface
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** État du serveur web (accès par navigateur), partagé entre ShareService et WebServerActivity. */
data class ServerStatus(
    val running: Boolean = false,
    val port: Int = 8080,
    val token: String = "",
    val error: String? = null
)

object ServerState {
    val status = MutableStateFlow(ServerStatus())
}

object NetUtils {
    /**
     * IPv4 locale utilisable par un autre appareil : Wi-Fi client, point d'accès (hotspot),
     * Ethernet. Les interfaces de données mobiles sont ignorées.
     */
    fun localIp(): String? {
        return try {
            val found = mutableListOf<Pair<Int, String>>()
            for (nif in NetworkInterface.getNetworkInterfaces()?.toList().orEmpty()) {
                if (!nif.isUp || nif.isLoopback) continue
                val name = nif.name.lowercase()
                if (name.startsWith("rmnet") || name.startsWith("ccmni") ||
                    name.startsWith("tun") || name.startsWith("dummy") || name.startsWith("v4-")
                ) continue
                for (addr in nif.inetAddresses) {
                    if (addr is Inet4Address && !addr.isLoopbackAddress && addr.isSiteLocalAddress) {
                        val prio = when {
                            name.startsWith("wlan") || name.startsWith("swlan") || name.startsWith("ap") -> 0
                            name.startsWith("eth") -> 1
                            else -> 2
                        }
                        found += prio to addr.hostAddress!!
                    }
                }
            }
            found.minByOrNull { it.first }?.second
        } catch (e: Exception) {
            null
        }
    }
}

/** Formats d'affichage et utilitaires de date (filtre par jour). */
object Fmt {
    fun bytes(n: Long): String = when {
        n < 1024 -> "$n o"
        n < 1024L * 1024 -> String.format(Locale.FRANCE, "%.1f Ko", n / 1024.0)
        n < 1024L * 1024 * 1024 -> String.format(Locale.FRANCE, "%.1f Mo", n / 1024.0 / 1024.0)
        else -> String.format(Locale.FRANCE, "%.2f Go", n / 1024.0 / 1024.0 / 1024.0)
    }

    fun date(ms: Long): String = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE).format(Date(ms))

    fun day(ms: Long): String = SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE).format(Date(ms))

    fun sameDay(a: Long, b: Long): Boolean {
        val x = Calendar.getInstance().apply { timeInMillis = a }
        val y = Calendar.getInstance().apply { timeInMillis = b }
        return x.get(Calendar.YEAR) == y.get(Calendar.YEAR) &&
                x.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR)
    }

    fun startOfDay(offsetDays: Int = 0): Long = Calendar.getInstance().apply {
        add(Calendar.DAY_OF_YEAR, offsetDays)
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    fun displayPath(path: String): String = path.replaceFirst("/storage/emulated/0", "Stockage interne")
}
