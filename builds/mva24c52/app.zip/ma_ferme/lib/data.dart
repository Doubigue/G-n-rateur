import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/data/latest_all.dart' as tzd;
import 'package:timezone/timezone.dart' as tz;

class Animal {
  final String key, name, kw; final Color color; final IconData icon;
  final bool poultry, eggs;
  const Animal(this.key, this.name, this.kw, this.color, this.icon, {this.poultry = false, this.eggs = false});
  // vraies photos (Flickr via LoremFlickr, par mot-clé)
  String get img => 'https://loremflickr.com/800/500/$kw?lock=${key.hashCode.abs() % 99}';
  List<String> get kinds => [
        'achat', 'vente', 'mort', 'soin',
        if (poultry) 'eclosion', if (eggs) ...['oeufs', 'casses'],
        if (!poultry && key != 'poisson') 'naissance',
      ];
}

const animals = [
  Animal('chair', 'Poulet de chair', 'broiler,chicken', Color(0xFFE67E22), Icons.set_meal, poultry: true),
  Animal('pondeuse', 'Poule pondeuse', 'hen,chicken,coop', Color(0xFFF1C40F), Icons.egg, poultry: true, eggs: true),
  Animal('dindon', 'Dindon', 'turkey,bird', Color(0xFF8E5A3C), Icons.pets, poultry: true),
  Animal('canard', 'Canard', 'duck,farm', Color(0xFF16A085), Icons.water, poultry: true, eggs: true),
  Animal('oie', 'Oie', 'goose,farm', Color(0xFF7F8C8D), Icons.flutter_dash, poultry: true, eggs: true),
  Animal('perdrix', 'Perdrix', 'partridge', Color(0xFFA0522D), Icons.nature, poultry: true, eggs: true),
  Animal('porc', 'Porc', 'pig,farm', Color(0xFFE91E63), Icons.pets),
  Animal('boeuf', 'Bœuf', 'cattle,cow', Color(0xFF5D4037), Icons.agriculture),
  Animal('lapin', 'Lapin', 'rabbit', Color(0xFF9C27B0), Icons.cruelty_free),
  Animal('cabri', 'Cabri', 'kid,goat', Color(0xFF3F51B5), Icons.terrain),
  Animal('mouton', 'Mouton', 'sheep', Color(0xFF607D8B), Icons.cloud),
  Animal('chevre', 'Chèvre', 'goat', Color(0xFF2E7D32), Icons.landscape),
  Animal('poisson', 'Poisson', 'fish,pond,tilapia', Color(0xFF0288D1), Icons.waves),
];
Animal animalOf(String k) => animals.firstWhere((a) => a.key == k);

const kindLabels = {
  'achat': 'Achat (lot)', 'vente': 'Vendu', 'mort': 'Morts', 'soin': 'Piqûre / soin',
  'eclosion': 'Poussins éclos', 'oeufs': 'Œufs pondus', 'casses': 'Œufs cassés', 'naissance': 'Naissances',
};
const expenseCats = ['Nourriture', 'Piqûres / vétérinaire', 'Loyer', 'Électricité', 'Eau', 'Salaires', 'Transport', 'Autres'];

class Repo {
  static final fs = FirebaseFirestore.instance;
  static late SharedPreferences p;
  static final records = ValueNotifier<List<Map<String, dynamic>>>([]);
  static final expenses = ValueNotifier<List<Map<String, dynamic>>>([]);
  static final employees = ValueNotifier<List<Map<String, dynamic>>>([]);
  static final pendingCount = ValueNotifier<int>(0);
  static final srv = {'records': <Map<String, dynamic>>[], 'expenses': <Map<String, dynamic>>[], 'employees': <Map<String, dynamic>>[]};
  static List<Map<String, dynamic>> pending = [];

  static Future<void> init() async {
    p = await SharedPreferences.getInstance();
    pending = (jsonDecode(p.getString('pending') ?? '[]') as List).cast<Map<String, dynamic>>();
    for (final c in srv.keys) {
      fs.collection(c).snapshots().listen((s) {
        srv[c] = s.docs.map((d) => {...d.data(), 'id': d.id}).toList();
        _merge();
      }, onError: (_) {});
    }
    _merge();
    Connectivity().onConnectivityChanged.listen((_) => flush());
  }

  static void _merge() {
    for (final c in srv.keys) {
      final loc = pending.where((e) => e['_c'] == c).map((e) => {...e, 'pending': true});
      final all = [...srv[c]!, ...loc]..sort((a, b) => '${b['d']}'.compareTo('${a['d']}'));
      ({'records': records, 'expenses': expenses, 'employees': employees}[c]!).value = all;
    }
    pendingCount.value = pending.length;
  }

  static Future<bool> online() async => !(await Connectivity().checkConnectivity()).contains(ConnectivityResult.none);

  static Future<void> add(String col, Map<String, dynamic> data) async {
    data['ts'] = DateTime.now().toIso8601String();
    if (FirebaseAuth.instance.currentUser != null && await online()) {
      fs.collection(col).add(data);
    } else {
      pending.add({...data, '_c': col});
      await p.setString('pending', jsonEncode(pending));
      _merge();
    }
  }

  static Future<void> flush() async {
    if (pending.isEmpty || FirebaseAuth.instance.currentUser == null || !await online()) return;
    for (final e in [...pending]) {
      final c = e['_c'];
      fs.collection(c).add(Map.of(e)..remove('_c'));
      pending.remove(e);
    }
    await p.setString('pending', jsonEncode(pending));
    _merge();
  }

  static Future<void> update(String col, String id, Map<String, dynamic> d) => fs.collection(col).doc(id).update(d);

  static Future<void> remove(String col, String id) => fs.collection(col).doc(id).delete();

  static int stock(String a) {
    int s = 0;
    for (final r in records.value.where((r) => r['a'] == a)) {
      final q = (r['q'] ?? 0) as num;
      if (['achat', 'eclosion', 'naissance'].contains(r['k'])) s += q.toInt();
      if (['vente', 'mort'].contains(r['k'])) s -= q.toInt();
    }
    return s;
  }
  static num sum(Iterable<Map<String, dynamic>> l, String f) => l.fold<num>(0, (s, e) => s + ((e[f] ?? 0) as num));
}

class Notif {
  static final pl = FlutterLocalNotificationsPlugin();
  static Future<void> init() async {
    tzd.initializeTimeZones();
    tz.setLocalLocation(tz.getLocation(await FlutterTimezone.getLocalTimezone()));
    await pl.initialize(const InitializationSettings(android: AndroidInitializationSettings('@mipmap/ic_launcher')));
    final a = pl.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await a?.requestNotificationsPermission();
    await a?.requestExactAlarmsPermission();
  }

  static List<Map<String, dynamic>> all() => (jsonDecode(Repo.p.getString('rem') ?? '[]') as List).cast<Map<String, dynamic>>();

  static Future<void> schedule(Map<String, dynamic> r) async {
    final now = tz.TZDateTime.now(tz.local);
    var t = tz.TZDateTime(tz.local, now.year, now.month, now.day, r['h'], r['m']);
    if (t.isBefore(now)) t = t.add(const Duration(days: 1));
    await pl.zonedSchedule(
      r['id'], '🚜 ${r['label']}', r['msg'], t,
      NotificationDetails(android: AndroidNotificationDetails('alarme', 'Alarmes de la ferme',
          importance: Importance.max, priority: Priority.max, category: AndroidNotificationCategory.alarm,
          fullScreenIntent: true, audioAttributesUsage: AudioAttributesUsage.alarm,
          additionalFlags: Int32List.fromList([4]), // insistant comme une alarme
          styleInformation: BigTextStyleInformation(r['msg']))),
      androidScheduleMode: AndroidScheduleMode.alarmClock,
      matchDateTimeComponents: DateTimeComponents.time, // répété chaque jour
    );
  }

  static Future<void> add(String label, String msg, TimeOfDay t) async {
    final l = all();
    final r = {'id': DateTime.now().millisecondsSinceEpoch ~/ 1000, 'label': label, 'msg': msg, 'h': t.hour, 'm': t.minute};
    l.add(r);
    await Repo.p.setString('rem', jsonEncode(l));
    await schedule(r);
  }

  static Future<void> update(String col, String id, Map<String, dynamic> d) => fs.collection(col).doc(id).update(d);

  static Future<void> remove(int id) async {
    await pl.cancel(id);
    await Repo.p.setString('rem', jsonEncode(all()..removeWhere((e) => e['id'] == id)));
  }
}
