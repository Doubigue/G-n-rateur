import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'admin.dart';
import 'data.dart';
import 'report.dart';

// Config Firebase (idéalement remplacez par `flutterfire configure` pour Android/iOS)
const fbOptions = FirebaseOptions(
  apiKey: 'AIzaSyBKBE87ba6InjfRuJfHiI0knEoo7FsoeS8',
  authDomain: 'ma-ferme-285f9.firebaseapp.com',
  projectId: 'ma-ferme-285f9',
  storageBucket: 'ma-ferme-285f9.firebasestorage.app',
  messagingSenderId: '843964352119',
  appId: '1:843964352119:web:0bd0ee77a8ae11e8e5a872',
);

// Config Android (valeurs de google-services.json, fournies en Dart car le générateur d'APK ignore le dossier android/)
const fbAndroid = FirebaseOptions(
  apiKey: 'AIzaSyBfdpIx0gp2iLp5b_lJL-NUtz1FsFzA_5M',
  appId: '1:843964352119:android:c8c898d169193b6fe5a872',
  messagingSenderId: '843964352119',
  projectId: 'ma-ferme-285f9',
  storageBucket: 'ma-ferme-285f9.firebasestorage.app',
);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: kIsWeb ? fbOptions : fbAndroid);
  await Repo.init();
  await Notif.init();
  runApp(const FermeApp());
}

final money = NumberFormat.decimalPattern('fr');
String f(num n) => '${money.format(n)} F';

class FermeApp extends StatelessWidget {
  const FermeApp({super.key});
  @override
  Widget build(BuildContext c) => MaterialApp(
        title: 'Ma Ferme', debugShowCheckedModeBanner: false,
        theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF2E7D32)),
            cardTheme: CardThemeData(elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)))),
        home: const Shell(),
      );
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int i = 0;
  @override
  Widget build(BuildContext c) => Scaffold(
        body: IndexedStack(index: i, children: const [Home(), ReportPage(), AdminGate()]),
        bottomNavigationBar: NavigationBar(selectedIndex: i, onDestinationSelected: (v) => setState(() => i = v), destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'Ferme'),
          NavigationDestination(icon: Icon(Icons.assessment_outlined), selectedIcon: Icon(Icons.assessment), label: 'Rapport'),
          NavigationDestination(icon: Icon(Icons.admin_panel_settings_outlined), selectedIcon: Icon(Icons.admin_panel_settings), label: 'Admin'),
        ]),
      );
}

class Home extends StatelessWidget {
  const Home({super.key});
  @override
  Widget build(BuildContext c) => ValueListenableBuilder(
        valueListenable: Repo.records,
        builder: (_, recs, __) {
          final today = DateFormat('yyyy-MM-dd').format(DateTime.now());
          int sumK(String k, {bool t = false}) => Repo.sum(recs.where((r) => r['k'] == k && (!t || r['d'] == today)), 'q').toInt();
          final total = animals.fold<int>(0, (s, a) => s + Repo.stock(a.key));
          return CustomScrollView(slivers: [
            SliverAppBar(
              expandedHeight: 170, pinned: true,
              flexibleSpace: FlexibleSpaceBar(
                title: const Text('Ma Ferme', style: TextStyle(fontWeight: FontWeight.w800)),
                background: Container(
                  decoration: const BoxDecoration(gradient: LinearGradient(colors: [Color(0xFF1B5E20), Color(0xFF66BB6A)], begin: Alignment.topLeft, end: Alignment.bottomRight)),
                  padding: const EdgeInsets.fromLTRB(20, 80, 20, 50),
                  child: Align(alignment: Alignment.centerRight, child: Icon(Icons.agriculture, size: 90, color: Colors.white.withOpacity(.25))),
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: SizedBox(height: 112, child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.all(16), children: [
                _stat('Effectif total', '$total', Icons.pets, Colors.green),
                _stat('Œufs aujourd\'hui', '${sumK('oeufs', t: true)}', Icons.egg, Colors.amber.shade800),
                _stat('Cassés aujourd\'hui', '${sumK('casses', t: true)}', Icons.heart_broken, Colors.orange),
                _stat('Morts aujourd\'hui', '${sumK('mort', t: true)}', Icons.warning_amber, Colors.red),
                _stat('Éclos (total)', '${sumK('eclosion')}', Icons.cruelty_free, Colors.teal),
              ])),
            ),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              sliver: SliverGrid.builder(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 14, crossAxisSpacing: 14, childAspectRatio: .82),
                itemCount: animals.length,
                itemBuilder: (_, i) => _card(c, animals[i]),
              ),
            ),
          ]);
        },
      );

  Widget _stat(String t, String v, IconData ic, Color col) => Container(
        width: 140, margin: const EdgeInsets.only(right: 12), padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: col.withOpacity(.12), borderRadius: BorderRadius.circular(20)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Icon(ic, color: col), Text(v, style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: col)), Text(t, style: const TextStyle(fontSize: 12)),
        ]),
      );

  Widget _card(BuildContext c, Animal a) => GestureDetector(
        onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => AnimalPage(a))),
        child: Hero(
          tag: a.key,
          child: Material(
            color: Colors.transparent,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(24),
              child: Stack(fit: StackFit.expand, children: [
                Image.network(a.img, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(color: a.color.withOpacity(.4), child: Icon(a.icon, size: 50, color: Colors.white))),
                const DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, Colors.black87]))),
                Positioned(left: 14, right: 14, bottom: 12, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(a.name, style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 4),
                  Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3), decoration: BoxDecoration(color: a.color, borderRadius: BorderRadius.circular(20)),
                      child: ValueListenableBuilder(valueListenable: Repo.records, builder: (_, __, ___) => Text('${Repo.stock(a.key)} têtes', style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600)))),
                ])),
              ]),
            ),
          ),
        ),
      );
}

class AnimalPage extends StatelessWidget {
  final Animal a;
  const AnimalPage(this.a, {super.key});
  @override
  Widget build(BuildContext c) => Scaffold(
        body: ValueListenableBuilder(
          valueListenable: Repo.records,
          builder: (_, all, __) {
            final l = all.where((r) => r['a'] == a.key).toList();
            return CustomScrollView(slivers: [
              SliverAppBar(
                expandedHeight: 260, pinned: true, title: Text(a.name),
                flexibleSpace: FlexibleSpaceBar(background: Hero(tag: a.key, child: Image.network(a.img, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(color: a.color)))),
              ),
              SliverToBoxAdapter(
                child: Padding(padding: const EdgeInsets.all(16), child: Wrap(spacing: 10, runSpacing: 10, children: [
                  _chip('Effectif', '${Repo.stock(a.key)}', a.color),
                  for (final k in a.kinds.where((k) => k != 'soin')) _chip(kindLabels[k]!, '${Repo.sum(l.where((r) => r['k'] == k), 'q').toInt()}', a.color),
                  _chip('Dépenses achat', f(Repo.sum(l.where((r) => r['k'] == 'achat'), 'm')), Colors.red),
                  _chip('Ventes', f(Repo.sum(l.where((r) => r['k'] == 'vente'), 'm')), Colors.green),
                ])),
              ),
              SliverList.builder(
                itemCount: l.length,
                itemBuilder: (_, i) {
                  final r = l[i];
                  return ListTile(
                    leading: CircleAvatar(backgroundColor: a.color.withOpacity(.15), child: Icon(r['pending'] == true ? Icons.cloud_off : Icons.check, color: a.color)),
                    title: Text('${kindLabels[r['k']]} • ${r['q']}'),
                    subtitle: Text('${r['d']}  ${r['n'] ?? ''}'),
                    trailing: (r['m'] ?? 0) > 0 ? Text(f(r['m']), style: const TextStyle(fontWeight: FontWeight.bold)) : null,
                  );
                },
              ),
            ]);
          },
        ),
      );
  Widget _chip(String t, String v, Color col) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(color: col.withOpacity(.12), borderRadius: BorderRadius.circular(16)),
        child: Column(children: [Text(v, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18, color: col)), Text(t, style: const TextStyle(fontSize: 11))]),
      );
}
