# Ma Ferme (Flutter) — package com.doubigue.ferme
Build via APK Studio (mode Flutter) : envoyez ce ZIP. Le dossier android/ est ignoré par le générateur,
la config Firebase Android est donc dans lib/main.dart (fbAndroid).
Remplacez .github/scripts/android_setup.py de votre dépôt APK Studio par la version fournie (alarmes),
cochez la permission « Notifications » dans APK Studio, paquet : com.doubigue.ferme.
Firebase Console : Authentication > Email/Mot de passe ; Firestore > Règles : contenu de firestore.rules.
