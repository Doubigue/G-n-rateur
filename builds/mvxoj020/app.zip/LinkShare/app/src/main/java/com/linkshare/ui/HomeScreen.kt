package com.linkshare.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.text.format.DateUtils
import android.text.format.Formatter
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.linkshare.client.TransferManager
import com.linkshare.core.*
import com.linkshare.server.ShareService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class HomeActions(
    val share: () -> Unit,
    val scan: () -> Unit,
    val link: () -> Unit,
    val stop: () -> Unit,
    val showShare: () -> Unit,
)

@Composable
fun HomeScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val info by ShareState.info.collectAsState()
    var tab by rememberSaveable { mutableStateOf(0) }
    var linkDialog by remember { mutableStateOf(false) }

    fun startSharing() {
        ContextCompat.startForegroundService(ctx, Intent(ctx, ShareService::class.java))
        askBatteryExemptionOnce(ctx)
    }
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { startSharing() }
    fun shareNow() {
        if (ensureAllFiles(ctx)) {
            tab = 2
            if (needsNotifPermission(ctx)) notif.launch(Manifest.permission.POST_NOTIFICATIONS) else startSharing()
        }
    }
    fun scanNow() = scan(ctx) { vm.connect(it); askBatteryExemptionOnce(ctx) }
    val notifScan = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { scanNow() }
    fun scanAction() {
        if (ensureAllFiles(ctx)) {
            if (needsNotifPermission(ctx)) notifScan.launch(Manifest.permission.POST_NOTIFICATIONS) else scanNow()
        }
    }

    val actions = HomeActions(
        share = { shareNow() },
        scan = { scanAction() },
        link = { linkDialog = true },
        stop = { ctx.stopService(Intent(ctx, ShareService::class.java)) },
        showShare = { tab = 2 },
    )

    LaunchedEffect(vm.message) { vm.message?.let { Toast.makeText(ctx, it, Toast.LENGTH_LONG).show(); vm.message = null } }

    if (linkDialog) LinkDialog(onDismiss = { linkDialog = false }) { c ->
        linkDialog = false
        if (ensureAllFiles(ctx)) { vm.connect(c); askBatteryExemptionOnce(ctx) }
    }

    Column(Modifier.fillMaxSize().background(LS.Bg)) {
        Box(Modifier.weight(1f).statusBarsPadding()) {
            when (tab) {
                0 -> HomeTab(vm, info, actions)
                1 -> StorageTab()
                2 -> ShareTab(info, actions)
                else -> ProfileTab()
            }
        }
        BottomNav(tab) { tab = it }
    }
}

// ───────────────────────── Barre de navigation bleue ─────────────────────────

@Composable
private fun BottomNav(selected: Int, onSelect: (Int) -> Unit) {
    val items = listOf("Accueil" to Ic.Home, "Stockage" to Ic.Cloud, "Partage" to Ic.Share, "Profil" to Ic.Person)
    Box(Modifier.fillMaxWidth().navigationBarsPadding().padding(start = 14.dp, end = 14.dp, bottom = 8.dp, top = 4.dp)) {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(LS.Blue).padding(vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceAround,
        ) {
            items.forEachIndexed { i, (label, icon) ->
                val on = i == selected
                val tint = if (on) Color.White else Color.White.copy(alpha = 0.6f)
                Column(
                    Modifier.clip(RoundedCornerShape(12.dp)).clickable { onSelect(i) }.padding(horizontal = 12.dp, vertical = 2.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Icon(icon, label, Modifier.size(22.dp), tint = tint)
                    Text(label, color = tint, fontSize = 10.sp, fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal)
                }
            }
        }
    }
}

// ───────────────────────────── Onglet Accueil ─────────────────────────────

@Composable
private fun HomeTab(vm: MainViewModel, info: ShareInfo?, a: HomeActions) {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Avatar(40.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(Build.MODEL, color = LS.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text("LinkShare", color = LS.Muted, fontSize = 11.sp)
            }
            Box(
                Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(LS.BlueLight).clickable { a.scan() },
                contentAlignment = Alignment.Center,
            ) { Icon(Ic.Scan, "Scanner un QR", Modifier.size(20.dp), tint = LS.Blue) }
        }

        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(LS.Card)
                .clickable { Toast.makeText(ctx, "Connecte-toi à un téléphone pour chercher dans ses fichiers", Toast.LENGTH_SHORT).show() }
                .padding(horizontal = 14.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Ic.Search, null, Modifier.size(18.dp), tint = LS.Muted)
            Spacer(Modifier.width(10.dp))
            Text("Rechercher un fichier", color = LS.Muted, fontSize = 13.sp)
        }

        vm.status?.let {
            Column {
                Text(it, color = LS.Text, fontSize = 12.sp)
                Spacer(Modifier.height(4.dp))
                LinearProgressIndicator(Modifier.fillMaxWidth(), color = LS.Blue)
            }
        }

        StorageCard()

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Category.values().forEach { c ->
                CategoryTile(c, selected = false) {
                    Toast.makeText(ctx, "Scanne le QR du téléphone pour parcourir : ${c.label}", Toast.LENGTH_SHORT).show()
                    vm.category = c
                    a.scan()
                }
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ActionTile("Partager", Ic.Send, Modifier.weight(1f)) { a.share() }
            ActionTile("Recevoir", Ic.Download, Modifier.weight(1f)) { a.scan() }
            ActionTile("Lien", Ic.Link, Modifier.weight(1f)) { a.link() }
        }

        if (info != null) {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(LS.BlueLight)
                    .clickable { a.showShare() }.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Ic.Share, null, Modifier.size(20.dp), tint = LS.Blue)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("Partage actif", color = LS.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Text("${info.host}:${info.port} · toucher pour afficher le QR", color = LS.Muted, fontSize = 11.sp)
                }
                Text("Arrêter", Modifier.clickable { a.stop() }.padding(8.dp), color = LS.Blue, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
        }

        SectionTitle("Transferts récents", if (vm.history.isNotEmpty()) "Effacer" else null) { vm.history.clear() }
        if (vm.history.isEmpty()) {
            Text("Aucun transfert pour l'instant", color = LS.Muted, fontSize = 12.sp)
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                vm.history.take(4).forEach { HistoryRow(it) }
            }
        }

        SectionTitle("Connexion")
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(LS.Card).padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Ic.Info, null, Modifier.size(18.dp), tint = LS.Blue)
            Spacer(Modifier.width(10.dp))
            Text("Même Wi-Fi, ou l'un sur le point d'accès de l'autre", color = LS.Text, fontSize = 12.sp)
        }

        Text(
            "DL VIBE STUDIO", Modifier.fillMaxWidth(), color = LS.Muted, fontSize = 11.sp,
            letterSpacing = 2.sp, textAlign = TextAlign.Center,
        )
    }
}

@Composable
private fun HistoryRow(h: HistoryItem) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(LS.Card).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(34.dp).clip(RoundedCornerShape(10.dp)).background(Color.White), contentAlignment = Alignment.Center) {
            Icon(if (h.up) Ic.Up else Ic.Down, null, Modifier.size(18.dp), tint = LS.Blue)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(h.text, color = LS.Text, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                DateUtils.getRelativeTimeSpanString(h.time, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS).toString(),
                color = LS.Muted, fontSize = 10.sp,
            )
        }
    }
}

// ───────────────────────── Carte de stockage (vraies valeurs) ─────────────────────────

private fun storageUsage(): Pair<Long, Long> {
    val s = StatFs(Environment.getDataDirectory().path)
    return (s.totalBytes - s.availableBytes) to s.totalBytes
}

@Composable
private fun StorageCard() {
    val ctx = LocalContext.current
    val (used, total) = remember { storageUsage() }
    val p = if (total > 0) (used.toFloat() / total).coerceIn(0f, 1f) else 0f
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(LS.Card).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(60.dp), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(progress = { p }, modifier = Modifier.fillMaxSize(), color = LS.Blue, trackColor = Color.White, strokeWidth = 6.dp)
            Text("${(p * 100).toInt()}%", color = LS.Blue, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(14.dp))
        Column {
            Text("Stockage utilisé", color = LS.Muted, fontSize = 10.sp)
            Text(
                "${Formatter.formatShortFileSize(ctx, used)} sur ${Formatter.formatShortFileSize(ctx, total)} utilisés",
                color = LS.Text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
            )
            Text(
                "Gérer le stockage",
                Modifier.clickable {
                    try {
                        ctx.startActivity(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (_: Exception) {
                        ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }
                }.padding(vertical = 4.dp),
                color = LS.Blue, fontSize = 11.sp, fontWeight = FontWeight.SemiBold,
            )
        }
    }
}

// ───────────────────────────── Onglet Stockage ─────────────────────────────

private fun receivedFiles(): List<File> =
    File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "LinkShare")
        .listFiles()?.sortedByDescending { it.lastModified() }?.take(100).orEmpty()

@Composable
private fun StorageTab() {
    val ctx = LocalContext.current
    val running by TransferManager.active.collectAsState()
    val files by produceState(emptyList<File>(), running) { value = withContext(Dispatchers.IO) { receivedFiles() } }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("Stockage", color = LS.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        StorageCard()
        SectionTitle("Fichiers reçus")
        Text("Dossier : Download/LinkShare", color = LS.Muted, fontSize = 11.sp)
        if (files.isEmpty()) {
            Text("Rien reçu pour l'instant", color = LS.Muted, fontSize = 12.sp)
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                files.forEach { f ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(LS.Card).padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)).background(Color.White), contentAlignment = Alignment.Center) {
                            Icon(if (f.isDirectory) Ic.Folder else Ic.Doc, null, Modifier.size(18.dp), tint = LS.Blue)
                        }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(f.name, color = LS.Text, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                if (f.isDirectory) "Dossier" else Formatter.formatShortFileSize(ctx, f.length()),
                                color = LS.Muted, fontSize = 10.sp,
                            )
                        }
                    }
                }
            }
        }
    }
}

// ───────────────────────── Onglet Partage (QR + radar) ─────────────────────────

@Composable
fun Radar(diameter: Dp) {
    val t = rememberInfiniteTransition(label = "radar")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(2600, easing = LinearEasing)), label = "p")
    Box(Modifier.size(diameter), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val maxR = this.size.minDimension / 2
            for (i in 0..2) {
                val f = (p + i / 3f) % 1f
                drawCircle(LS.Blue.copy(alpha = (1f - f) * 0.28f), radius = maxR * (0.3f + 0.7f * f))
            }
        }
        Box(Modifier.size(diameter * 0.36f).clip(CircleShape).background(LS.BlueLight), contentAlignment = Alignment.Center) {
            Icon(Ic.Person, null, Modifier.size(diameter * 0.22f), tint = LS.Blue)
        }
    }
}

@Composable
private fun ShareTab(info: ShareInfo?, a: HomeActions) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val busy by ShareState.active.collectAsState()
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text("Partage", Modifier.fillMaxWidth(), color = LS.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        if (info == null) {
            Spacer(Modifier.height(24.dp))
            Radar(190.dp)
            Text("Partage désactivé", color = LS.Blue, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(
                "Affiche un QR code pour que l'autre téléphone se connecte et parcoure tes fichiers et apps.",
                color = LS.Muted, fontSize = 12.sp, textAlign = TextAlign.Center,
            )
            Button(
                { a.share() }, Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = LS.Blue),
            ) { Text("Partager mon téléphone") }
        } else {
            val bmp = remember(info) { qr(info.toUri()) }
            Image(
                bmp.asImageBitmap(), "QR code",
                Modifier.size(210.dp).clip(RoundedCornerShape(16.dp)).background(Color.White),
            )
            Text("Scanne ce QR pour te connecter", color = LS.Blue, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            Text("${info.host}:${info.port}", color = LS.Text, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Radar(150.dp)
            Text(
                if (busy > 0) "Transfert en cours…" else "En attente d'un téléphone…",
                color = LS.Blue, fontSize = 18.sp, fontWeight = FontWeight.Bold,
            )
            Text("Patiente un instant", color = LS.Muted, fontSize = 11.sp)
            Text(
                "Quiconque scanne ce code accède à tes fichiers. Arrête le partage quand tu as fini.",
                color = LS.Muted, fontSize = 11.sp, textAlign = TextAlign.Center,
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    {
                        clip.setText(AnnotatedString(info.toUri()))
                        Toast.makeText(ctx, "Lien copié", Toast.LENGTH_SHORT).show()
                    },
                    Modifier.weight(1f).height(48.dp), shape = RoundedCornerShape(14.dp),
                ) { Icon(Ic.Copy, null, Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)); Text("Copier le lien") }
                Button(
                    { a.stop() }, Modifier.weight(1f).height(48.dp), shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = LS.Blue),
                ) { Icon(Ic.Stop, null, Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)); Text("Arrêter") }
            }
        }
    }
}

// ───────────────────────────── Onglet Profil ─────────────────────────────

@Composable
private fun ProfileTab() {
    val ctx = LocalContext.current
    val allFiles = Environment.isExternalStorageManager()
    val battery = ctx.getSystemService(android.os.PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName)
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Spacer(Modifier.height(12.dp))
        Avatar(84.dp)
        Text(Build.MODEL, color = LS.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text("LinkShare · version 0.1", color = LS.Muted, fontSize = 11.sp)
        Spacer(Modifier.height(8.dp))
        val fixFiles: (() -> Unit)? = if (allFiles) null else ({ ensureAllFiles(ctx); Unit })
        val fixBattery: (() -> Unit)? = if (battery) null else ({ requestBatteryExemption(ctx) })
        InfoRow(Ic.Folder, "Accès à tous les fichiers", if (allFiles) "Autorisé" else "Non autorisé · toucher pour régler", fixFiles)
        InfoRow(
            Ic.Info, "Batterie",
            if (battery) "Optimisation désactivée (recommandé)" else "Optimisation active · toucher pour désactiver", fixBattery,
        )
        InfoRow(Ic.Download, "Dossier de réception", "Download/LinkShare")
        InfoRow(Ic.Person, "Créé par DL VIBE STUDIO", "Doubigue Loubikoa")
    }
}

private fun requestBatteryExemption(ctx: Context) {
    ctx.startActivity(
        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    )
}

@Composable
private fun InfoRow(icon: ImageVector, title: String, subtitle: String, onClick: (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(LS.Card)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, Modifier.size(20.dp), tint = LS.Blue)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = LS.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = LS.Muted, fontSize = 11.sp)
        }
    }
}

// ───────────────────────── Connexion par lien (« Web Link ») ─────────────────────────

@Composable
private fun LinkDialog(onDismiss: () -> Unit, onConnect: (Connection) -> Unit) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    var text by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Se connecter avec un lien") },
        text = {
            Column {
                OutlinedTextField(
                    value = text, onValueChange = { text = it }, singleLine = true,
                    placeholder = { Text("linkshare://…") }, modifier = Modifier.fillMaxWidth(),
                )
                TextButton({ clip.getText()?.text?.let { text = it } }) { Text("Coller") }
            }
        },
        confirmButton = {
            TextButton({
                val c = Connection.parse(text.trim())
                if (c != null) onConnect(c) else Toast.makeText(ctx, "Lien non reconnu", Toast.LENGTH_SHORT).show()
            }) { Text("Se connecter") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Annuler") } },
    )
}
