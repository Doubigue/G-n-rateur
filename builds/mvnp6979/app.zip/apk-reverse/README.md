# APK Reverse Toolkit — mode brute-force (sans Java)

Outil web local d'analyse et d'extraction d'APK Android. Aucune dépendance
Java : pas d'apktool, pas de jadx. Tout le parsing (AXML, DEX, ZIP) est
réimplémenté en JavaScript pur côté backend Node, avec un fallback
brute-force systématique si un fichier est corrompu, tronqué ou protégé.

> ⚠️ **Usage légal uniquement.** Cet outil est destiné à l'analyse de vos
> propres applications ou dans le cadre d'un audit/pentest autorisé
> (bug bounty avec scope défini, contrat de test d'intrusion, app que vous
> avez développée). Décompiler une application tierce sans autorisation
> peut constituer une violation des CGU de l'éditeur et, selon les
> juridictions, une infraction pénale.

## 1. Arborescence du projet

```
apk-reverse/
├── package.json
├── server.js                  # Serveur Express : routes API + orchestration
├── lib/
│   ├── axmlParser.js           # Décodeur binaire AndroidManifest.xml (AXML)
│   ├── dexParser.js            # Lecteur d'en-tête DEX (classes/méthodes/strings)
│   ├── bruteForce.js           # Extraction strings/URLs/IPs/clés API par scan brut
│   └── zipBuilder.js           # Génère le ZIP final "Reverse app/Apk décompiler"
├── public/
│   ├── index.html               # Frontend décompilateur (Tailwind CDN, dark mode VS Code-like)
│   ├── app.js                   # Logique vanilla JS (drag&drop, fetch API, tree-view)
│   └── generator/                # Module 2 : "APK Studio" — générateur/compilateur via GitHub Actions
│       ├── index.html             # App autonome (voir §6), 100% client-side
│       └── logo/
├── github-repo-template/       # À pousser dans TON dépôt GitHub (pas servi par ce serveur, voir §6)
├── uploads/                    # Fichiers .apk temporairement reçus (vidé après analyse)
└── tmp/                        # Un sous-dossier par session = pack décompilé en attente
                                   de téléchargement (à nettoyer périodiquement, voir §5)
```

## 2. Prérequis

- Node.js ≥ 18 (aucune autre dépendance système : pas de JDK, pas d'apktool/jadx)

## 3. Installation

```bash
cd apk-reverse
npm install
```

Cela installe : `express`, `multer` (upload), `adm-zip` (lecture ZIP),
`archiver` (génération du ZIP de sortie).

## 4. Lancement

```bash
npm start
# ou pour le rechargement auto en dev :
npm run dev
```

Puis ouvrez **http://localhost:3000**.

## 5. Utilisation

1. Glissez-déposez un fichier `.apk` dans la zone prévue (ou cliquez pour le
   sélectionner).
2. Le dashboard affiche immédiatement : package, version, taille, SDK min/target.
3. L'explorateur de fichiers à gauche permet de naviguer dans l'APK décompressé.
4. L'onglet **Strings & URLs** liste toutes les URLs, IPs, emails et clés
   d'API détectées par le scan brute-force (sur l'ensemble des fichiers,
   y compris les `.dex` et `.so`).
5. L'onglet **Classes (DEX)** montre la structure des classes extraites de
   chaque `.dex` (noms de classes, nombre de méthodes/chaînes) — une vue
   « type Smali » sans recompilation.
6. Cliquez sur **↓ télécharger le pack .zip** : vous obtenez un fichier
   `Reverse-app-pack.zip` qui, une fois décompressé, donne exactement :

   ```
   Reverse app/
   └── Apk décompiler/
       ├── AndroidManifest.xml (et/ou .decoded.json, .brute-force-strings.json)
       ├── classes.dex, res/, assets/, lib/, META-INF/...  (arborescence APK d'origine)
       └── __analysis__/
           ├── classes/*.structure.json
           ├── strings-report.json
           └── full-report.json
   ```

### Nettoyage des sessions temporaires

Chaque analyse crée un dossier dans `tmp/<sessionId>/`. Ces dossiers ne sont
pas supprimés automatiquement (pour permettre le téléchargement après coup).
En production, ajoutez un job cron ou un intervalle Node (`setInterval`) qui
supprime les dossiers de `tmp/` plus vieux que X heures.

## 6. Module 2 : Générateur APK ("APK Studio")

En plus du décompilateur, l'app embarque maintenant un second outil accessible
via le bouton **⚒ générateur APK** en haut à droite (route `/generator/`).

C'est un outil différent dans son fonctionnement : il ne compile rien en
local. C'est une interface qui pousse ton code (collé, zip, ou "fonctions"
générées) vers **ton propre dépôt GitHub**, via un token que tu fournis
toi-même, puis déclenche un **GitHub Actions workflow** qui fait la vraie
compilation (Gradle/Java, Flutter, React Native ou Python selon le mode)
sur les serveurs de GitHub — c'est pour ça qu'aucun JDK n'est nécessaire en
local : la compilation Android a lieu côté GitHub, pas sur ta machine.

### Ce que tu dois faire une fois, côté GitHub (pas dans cette app)

Le dossier `github-repo-template/` à la racine de ce projet contient les
fichiers qui doivent exister **dans le dépôt GitHub cible** (pas dans ce
serveur local) pour que le bouton "Compiler" du générateur fonctionne :

```
github-repo-template/
├── .github/
│   ├── workflows/        # build-apk.yml, build-flutter.yml, build-native.yml,
│   │                        build-python.yml, build-reactnative.yml, download-repo.yml
│   ├── scripts/          # android_setup.py, native_setup.py, fonction_setup.py, icon_setup.py
│   └── fonction/         # templates Java pour les "fonctions" additionnelles
├── signing/debug.keystore  # keystore de signature par défaut (debug uniquement)
└── Modele-fonction/        # documentation/modèle pour créer une "fonction" custom
```

Étapes :
1. Crée (ou utilise) un dépôt GitHub vide, par exemple `tonpseudo/mon-generateur`.
2. Copie le contenu de `github-repo-template/` à la racine de ce dépôt et pousse-le (`git push`).
3. Dans l'onglet **Réglages** du générateur (`/generator/`), renseigne :
   - le nom du dépôt (`tonpseudo/mon-generateur`)
   - un **token GitHub** (`github.com/settings/tokens`) avec les droits
     `Contents` (écriture) et `workflow`
4. (Optionnel) Pour la correction automatique des erreurs de build par IA,
   renseigne ta propre **clé API Anthropic** dans Réglages — elle est
   envoyée uniquement à `api.anthropic.com` depuis ton navigateur, jamais
   stockée ailleurs que dans le `localStorage` de ton appareil.

> Le token GitHub et la clé API restent dans le `localStorage` de ton
> navigateur et ne sont envoyés qu'à `api.github.com` / `api.anthropic.com`.
> Ce serveur Node local ne les voit jamais : le générateur appelle ces API
> directement depuis le frontend.

## 7. Limites connues du mode brute-force (volontaires)

- Pas de génération de vrai code **Smali** (nécessiterait baksmali/Java) :
  l'onglet "Classes" donne une vue structurelle (noms de classes, compteurs)
  suffisante pour cartographier la logique, pas un désassemblage complet.
- `resources.arsc` n'est pas entièrement décodé (table de ressources
  typées) : les chaînes qu'il contient sont malgré tout capturées par le
  scanner brute-force global.
- Le fallback ZIP par scan de signatures locales (`PK\x03\x04`) peut
  manquer des entrées si l'inflate DEFLATE échoue sur un flux volontairement
  corrompu — dans ce cas l'entrée est tout de même gardée en octets bruts
  pour que le scan de strings reste exploitable.
