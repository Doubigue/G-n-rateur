/**
 * server.js
 * ------------------------------------------------------------------
 * Backend Node/Express de l'outil d'analyse APK "force brute".
 *
 * Flux :
 *  1. POST /api/analyze  -> upload d'un .apk, extraction ZIP tolérante,
 *     parsing AXML/DEX avec fallback brute-force systématique en cas
 *     d'échec, écriture du pack décompilé sur disque (dossier de
 *     session temporaire), retour JSON (métadonnées + arborescence).
 *  2. GET  /api/download/:sessionId -> stream du ZIP final structuré
 *     "Reverse app/Apk décompiler/..." construit à partir du pack.
 *  3. GET  /api/tree/:sessionId -> arborescence complète (si trop
 *     volumineuse pour la réponse initiale de /analyze).
 *
 * Aucune des étapes ne doit jamais faire planter le process : chaque
 * bloc d'analyse est encapsulé dans son propre try/catch, et une
 * erreur de parsing dégrade simplement le résultat (flags partial/
 * error) sans interrompre la requête.
 */

const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const AdmZip = require('adm-zip');

const { parseAXML } = require('./lib/axmlParser');
const { parseDex } = require('./lib/dexParser');
const { scanBuffer, bruteForceManifestGuess } = require('./lib/bruteForce');
const { buildReverseZip } = require('./lib/zipBuilder');

const app = express();
const PORT = process.env.PORT || 3000;

const TMP_ROOT = path.join(__dirname, 'tmp');
const UPLOAD_ROOT = path.join(__dirname, 'uploads');
fs.mkdirSync(TMP_ROOT, { recursive: true });
fs.mkdirSync(UPLOAD_ROOT, { recursive: true });

// Limite large (APK peuvent dépasser 200 Mo) ; ajustable selon l'environnement.
const upload = multer({
  dest: UPLOAD_ROOT,
  limits: { fileSize: 1024 * 1024 * 1024 }, // 1 Go
});

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

/** Nettoie un nom de fichier pour écriture disque sûre (anti path traversal) */
function safeRelPath(entryName) {
  const normalized = path
    .normalize(entryName)
    .replace(/^(\.\.(\/|\\|$))+/, '')
    .replace(/\\/g, '/');
  return normalized;
}

function newSessionId() {
  return crypto.randomBytes(8).toString('hex');
}

/**
 * Construit récursivement un tree-view (nom + type + taille) à partir
 * d'un dossier sur disque, pour l'explorateur de fichiers du frontend.
 */
function buildTree(dir, base = dir) {
  const stat = fs.statSync(dir);
  const name = path.basename(dir);
  if (stat.isDirectory()) {
    let children = [];
    try {
      children = fs
        .readdirSync(dir)
        .sort()
        .map((child) => buildTree(path.join(dir, child), base));
    } catch (e) {
      // dossier illisible (droits, lien cassé) -> on l'affiche vide plutôt que de planter
    }
    return { name, type: 'dir', children };
  }
  return { name, type: 'file', size: stat.size, path: path.relative(base, dir).replace(/\\/g, '/') };
}

app.post('/api/analyze', upload.single('apk'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Aucun fichier APK reçu.' });

  const sessionId = newSessionId();
  const extractDir = path.join(TMP_ROOT, sessionId);
  fs.mkdirSync(extractDir, { recursive: true });

  const report = {
    sessionId,
    fileName: req.file.originalname,
    sizeBytes: req.file.size,
    zip: { ok: false, entryCount: 0, corrupted: false },
    manifest: null,
    dex: [],
    analysis: { urls: [], ips: [], emails: [], apiKeys: [], packages: [] },
    warnings: [],
  };

  // --- 1. Extraction ZIP tolérante -------------------------------------
  let zip;
  let entries = [];
  try {
    zip = new AdmZip(req.file.path);
    entries = zip.getEntries();
    report.zip.ok = true;
    report.zip.entryCount = entries.length;
  } catch (e) {
    report.zip.corrupted = true;
    report.warnings.push(
      `Table ZIP centrale illisible (${e.message}). Bascule sur extraction par scan brut des signatures locales.`
    );
    // Fallback : scan brut du fichier à la recherche de "local file headers"
    // ZIP (PK\x03\x04) directement dans les octets, sans passer par la
    // table centrale (souvent la cible des protections anti-extraction).
    entries = rawZipLocalHeaderScan(req.file.path);
    report.zip.entryCount = entries.length;
    report.zip.recoveredByRawScan = true;
  }

  // --- 2. Écriture de chaque entrée sur disque + collecte des buffers --
  const allStringTargets = []; // { relPath, buffer } pour l'analyse brute-force globale
  for (const entry of entries) {
    try {
      const entryName = entry.entryName || entry.name;
      if (!entryName || entry.isDirectory) continue;
      const relPath = safeRelPath(entryName);
      const destPath = path.join(extractDir, relPath);
      fs.mkdirSync(path.dirname(destPath), { recursive: true });

      let data;
      try {
        data = entry.getData ? entry.getData() : entry.data; // adm-zip vs fallback brut
      } catch (eData) {
        report.warnings.push(`Entrée "${entryName}" illisible/protégée, ignorée pour la décompression (gardée en brute-force).`);
        continue;
      }
      fs.writeFileSync(destPath, data);
      allStringTargets.push({ relPath, buffer: data });
    } catch (eEntry) {
      report.warnings.push(`Erreur sur une entrée ZIP : ${eEntry.message}`);
    }
  }

  // --- 3. Parsing AndroidManifest.xml (AXML) avec fallback brute-force -
  const manifestEntry = allStringTargets.find((t) => t.relPath === 'AndroidManifest.xml');
  if (manifestEntry) {
    const axml = parseAXML(manifestEntry.buffer);
    if (axml.ok) {
      report.manifest = { mode: axml.partial ? 'axml-partial' : 'axml', ...axml.meta };
      fs.writeFileSync(
        path.join(extractDir, 'AndroidManifest.decoded.json'),
        JSON.stringify(axml.elements, null, 2)
      );
    } else {
      report.warnings.push('AndroidManifest.xml illisible en binaire standard, bascule brute-force.');
      const guess = bruteForceManifestGuess(manifestEntry.buffer);
      report.manifest = { mode: 'brute-force-guess', package: guess.package, versionName: guess.versionName };
      fs.writeFileSync(
        path.join(extractDir, 'AndroidManifest.brute-force-strings.json'),
        JSON.stringify(guess, null, 2)
      );
    }
  } else {
    report.warnings.push('AndroidManifest.xml absent de l\'archive.');
  }

  // --- 4. Parsing DEX (classes/méthodes) --------------------------------
  const dexEntries = allStringTargets.filter((t) => /\.dex$/i.test(t.relPath));
  const classesDir = path.join(extractDir, '__analysis__', 'classes');
  fs.mkdirSync(classesDir, { recursive: true });
  for (const d of dexEntries) {
    const parsed = parseDex(d.buffer);
    report.dex.push({
      file: d.relPath,
      ok: parsed.ok,
      classCount: parsed.classCount,
      methodCount: parsed.methodCount,
      stringCount: parsed.stringCount,
      error: parsed.error,
    });
    fs.writeFileSync(
      path.join(classesDir, `${path.basename(d.relPath)}.structure.json`),
      JSON.stringify({ classNames: parsed.classNames, sampleStrings: parsed.sampleStrings.slice(0, 1000) }, null, 2)
    );
  }

  // --- 5. Extraction agressive strings/URLs/IPs/clés sur TOUT le pack --
  const analysisDir = path.join(extractDir, '__analysis__');
  fs.mkdirSync(analysisDir, { recursive: true });
  const merged = { urls: new Set(), ips: new Set(), emails: new Set(), apiKeys: new Set(), packages: new Set() };
  for (const t of allStringTargets) {
    try {
      const found = scanBuffer(t.buffer, { limitRaw: 300 });
      found.urls.forEach((v) => merged.urls.add(v));
      found.ips.forEach((v) => merged.ips.add(v));
      found.emails.forEach((v) => merged.emails.add(v));
      found.apiKeys.forEach((v) => merged.apiKeys.add(v));
      found.packages.forEach((v) => merged.packages.add(v));
    } catch (eScan) {
      report.warnings.push(`Scan brute-force échoué sur ${t.relPath}: ${eScan.message}`);
    }
  }
  report.analysis = {
    urls: [...merged.urls],
    ips: [...merged.ips],
    emails: [...merged.emails],
    apiKeys: [...merged.apiKeys],
    packages: [...merged.packages].slice(0, 300),
  };
  fs.writeFileSync(path.join(analysisDir, 'strings-report.json'), JSON.stringify(report.analysis, null, 2));
  fs.writeFileSync(path.join(analysisDir, 'full-report.json'), JSON.stringify(report, null, 2));

  // --- 6. Arborescence pour le tree-view frontend ------------------------
  let tree;
  try {
    tree = buildTree(extractDir);
  } catch (eTree) {
    tree = { name: path.basename(extractDir), type: 'dir', children: [] };
    report.warnings.push('Construction de l\'arborescence partielle suite à une erreur.');
  }

  // Nettoyage du fichier uploadé temporaire (on garde extractDir pour le download)
  fs.unlink(req.file.path, () => {});

  res.json({ report, tree });
});

/**
 * Scan brut d'un fichier à la recherche des signatures ZIP locales
 * (PK\x03\x04) quand la table centrale est absente/corrompue. Permet de
 * récupérer un maximum d'entrées même sur une archive volontairement
 * endommagée en fin de fichier (technique anti-apktool classique).
 */
function rawZipLocalHeaderScan(filePath) {
  const buf = fs.readFileSync(filePath);
  const out = [];
  const SIG = Buffer.from([0x50, 0x4b, 0x03, 0x04]);
  let idx = 0;
  while (true) {
    idx = buf.indexOf(SIG, idx);
    if (idx === -1) break;
    try {
      const compMethod = buf.readUInt16LE(idx + 8);
      const compSize = buf.readUInt32LE(idx + 18);
      const uncompSize = buf.readUInt32LE(idx + 22);
      const nameLen = buf.readUInt16LE(idx + 26);
      const extraLen = buf.readUInt16LE(idx + 28);
      const nameStart = idx + 30;
      const name = buf.toString('utf8', nameStart, nameStart + nameLen);
      const dataStart = nameStart + nameLen + extraLen;
      const dataEnd = dataStart + compSize;

      if (compMethod === 0) {
        // STORED : données brutes directement exploitables
        out.push({ entryName: name, isDirectory: name.endsWith('/'), data: buf.slice(dataStart, dataEnd) });
      } else {
        // DEFLATE ou autre : on tente une inflate best-effort, sinon on
        // garde les octets bruts (toujours utile pour le scan de strings).
        try {
          const zlib = require('zlib');
          const inflated = zlib.inflateRawSync(buf.slice(dataStart, dataEnd));
          out.push({ entryName: name, isDirectory: name.endsWith('/'), data: inflated });
        } catch (eInflate) {
          out.push({ entryName: name, isDirectory: name.endsWith('/'), data: buf.slice(dataStart, Math.min(dataEnd, buf.length)) });
        }
      }
      idx = Math.max(dataEnd, idx + 4);
    } catch (e) {
      idx += 4; // signature trouvée mais header illisible -> on continue le scan plus loin
    }
  }
  return out;
}

app.get('/api/tree/:sessionId', (req, res) => {
  const dir = path.join(TMP_ROOT, req.params.sessionId);
  if (!fs.existsSync(dir)) return res.status(404).json({ error: 'Session inconnue ou expirée.' });
  res.json(buildTree(dir));
});

app.get('/api/file/:sessionId/*', (req, res) => {
  const dir = path.join(TMP_ROOT, req.params.sessionId);
  const rel = req.params[0];
  const target = path.join(dir, rel);
  if (!target.startsWith(dir) || !fs.existsSync(target)) return res.status(404).send('Introuvable.');
  res.sendFile(target);
});

app.get('/api/download/:sessionId', async (req, res) => {
  const dir = path.join(TMP_ROOT, req.params.sessionId);
  if (!fs.existsSync(dir)) return res.status(404).json({ error: 'Session inconnue ou expirée.' });

  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', `attachment; filename="Reverse-app-pack.zip"`);

  try {
    await buildReverseZip(dir, res);
  } catch (e) {
    if (!res.headersSent) res.status(500).json({ error: `Échec génération ZIP: ${e.message}` });
  }
});

app.listen(PORT, () => {
  console.log(`APK Reverse Toolkit disponible sur http://localhost:${PORT}`);
});
