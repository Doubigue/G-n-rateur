/**
 * app.js — logique frontend vanilla JS (aucun framework, aucune build step).
 * Communique avec le backend Express via /api/analyze et /api/download/:id.
 */

const dropzone = document.getElementById('dropzone');
const fileInput = document.getElementById('file-input');
const dropScreen = document.getElementById('drop-screen');
const workspace = document.getElementById('workspace');
const statusDot = document.getElementById('status-dot');
const statusText = document.getElementById('status-text');
const downloadBtn = document.getElementById('download-btn');
const fileBadge = document.getElementById('file-badge');
const warningsBar = document.getElementById('warnings-bar');

let currentSessionId = null;
let currentReport = null;

// ---------------------------------------------------------------------
// Drag & drop + sélection manuelle
// ---------------------------------------------------------------------
['dragenter', 'dragover'].forEach((evt) =>
  dropzone.addEventListener(evt, (e) => {
    e.preventDefault();
    dropzone.classList.add('drop-active');
  })
);
['dragleave', 'drop'].forEach((evt) =>
  dropzone.addEventListener(evt, (e) => {
    e.preventDefault();
    dropzone.classList.remove('drop-active');
  })
);
dropzone.addEventListener('drop', (e) => {
  const file = e.dataTransfer.files[0];
  if (file) handleFile(file);
});
dropzone.addEventListener('click', () => fileInput.click());
fileInput.addEventListener('change', () => {
  if (fileInput.files[0]) handleFile(fileInput.files[0]);
});

document.getElementById('new-file-btn').addEventListener('click', () => {
  workspace.classList.add('hidden');
  dropScreen.classList.remove('hidden');
  downloadBtn.disabled = true;
  fileBadge.classList.add('hidden');
  setStatus('idle', "en attente d'un .apk");
});

// ---------------------------------------------------------------------
// Upload + analyse
// ---------------------------------------------------------------------
function setStatus(kind, text) {
  statusText.textContent = text;
  const colors = { idle: '#5a5a5a', busy: '#ce9178', ok: '#4ec9b0', error: '#f1555c' };
  statusDot.style.background = colors[kind] || colors.idle;
  statusDot.classList.toggle('pulse-dot', kind === 'busy');
}

async function handleFile(file) {
  if (!file.name.toLowerCase().endsWith('.apk')) {
    alert("Ce fichier ne semble pas être un .apk — l'outil tentera quand même l'extraction brute.");
  }

  setStatus('busy', `analyse de ${file.name}…`);
  dropScreen.classList.add('hidden');
  workspace.classList.remove('hidden');
  fileBadge.textContent = file.name;
  fileBadge.classList.remove('hidden');

  const form = new FormData();
  form.append('apk', file);

  try {
    const res = await fetch('/api/analyze', { method: 'POST', body: form });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error || `HTTP ${res.status}`);
    }
    const data = await res.json();
    currentSessionId = data.report.sessionId;
    currentReport = data.report;

    renderDashboard(data.report, file.size);
    renderTree(data.tree);
    renderStrings(data.report.analysis);
    renderClasses(data.report.dex);
    renderReport(data.report);
    renderWarnings(data.report.warnings);

    downloadBtn.disabled = false;
    setStatus('ok', `analyse terminée — ${data.report.zip.entryCount} entrées`);
  } catch (e) {
    console.error(e);
    setStatus('error', `échec : ${e.message}`);
  }
}

// ---------------------------------------------------------------------
// Dashboard
// ---------------------------------------------------------------------
function renderDashboard(report, sizeBytes) {
  const m = report.manifest || {};
  document.getElementById('meta-package').textContent = m.package || 'non résolu';
  document.getElementById('meta-version').textContent =
    [m.versionName, m.versionCode ? `(code ${m.versionCode})` : null].filter(Boolean).join(' ') || '—';
  document.getElementById('meta-size').textContent = formatBytes(sizeBytes);
  document.getElementById('meta-sdk').textContent =
    `${m.minSdkVersion ?? '?'} / ${m.targetSdkVersion ?? '?'}`;

  const icon = document.getElementById('app-icon');
  icon.textContent = m.mode === 'brute-force-guess' ? '⚠' : (m.package ? m.package[0].toUpperCase() : '?');
}

function formatBytes(n) {
  if (!n && n !== 0) return '—';
  const units = ['o', 'Ko', 'Mo', 'Go'];
  let i = 0;
  let v = n;
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i++;
  }
  return `${v.toFixed(v < 10 && i > 0 ? 1 : 0)} ${units[i]}`;
}

// ---------------------------------------------------------------------
// Tree-view
// ---------------------------------------------------------------------
function renderTree(tree) {
  const root = document.getElementById('tree-root');
  root.innerHTML = '';
  root.appendChild(renderNode(tree, 0, ''));
}

function iconFor(name, type) {
  if (type === 'dir') return '📁';
  if (/\.dex$/i.test(name)) return '⚙';
  if (/\.xml$/i.test(name)) return '📄';
  if (/\.(png|jpg|jpeg|webp)$/i.test(name)) return '🖼';
  if (/\.json$/i.test(name)) return '{}';
  if (/\.(so)$/i.test(name)) return '🧩';
  return '•';
}

function renderNode(node, depth, parentPath) {
  const wrap = document.createElement('div');
  const fullPath = parentPath ? `${parentPath}/${node.name}` : node.name;

  const row = document.createElement('div');
  row.className = 'tree-row flex items-center gap-1.5 px-2 py-0.5 cursor-pointer select-none';
  row.style.paddingLeft = `${8 + depth * 14}px`;
  row.innerHTML = `<span class="text-[10px]">${iconFor(node.name, node.type)}</span><span class="truncate ${node.type === 'dir' ? 'text-[#dcdcaa]' : 'text-[#d4d4d4]'}">${escapeHtml(node.name)}</span>${
    node.type === 'file' ? `<span class="text-dim text-[10px] ml-auto">${formatBytes(node.size)}</span>` : ''
  }`;
  wrap.appendChild(row);

  if (node.type === 'dir') {
    const childrenWrap = document.createElement('div');
    let expanded = depth < 1; // racine ouverte par défaut, le reste replié
    childrenWrap.style.display = expanded ? 'block' : 'none';
    (node.children || []).forEach((c) => childrenWrap.appendChild(renderNode(c, depth + 1, fullPath)));
    wrap.appendChild(childrenWrap);
    row.addEventListener('click', () => {
      expanded = !expanded;
      childrenWrap.style.display = expanded ? 'block' : 'none';
    });
  } else {
    row.addEventListener('click', () => openFile(fullPath, node.name));
  }

  return wrap;
}

async function openFile(relPath, name) {
  switchTab('viewer');
  const viewer = document.getElementById('panel-viewer');
  viewer.textContent = 'chargement…';
  try {
    const res = await fetch(`/api/file/${currentSessionId}/${relPath.split('/').map(encodeURIComponent).join('/')}`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    if (/\.(png|jpg|jpeg|webp|gif)$/i.test(name)) {
      const blob = await res.blob();
      viewer.innerHTML = '';
      const img = document.createElement('img');
      img.src = URL.createObjectURL(blob);
      img.className = 'max-w-full border border-line';
      viewer.appendChild(img);
    } else {
      const text = await res.text();
      viewer.textContent = text.length > 200000 ? text.slice(0, 200000) + '\n\n… (tronqué, fichier volumineux)' : text;
    }
  } catch (e) {
    viewer.textContent = `Impossible d'afficher ce fichier (probablement binaire) : ${e.message}`;
  }
}

// ---------------------------------------------------------------------
// Strings / URLs / IPs / clés
// ---------------------------------------------------------------------
function renderStrings(analysis) {
  fillList('list-urls', 'count-urls', analysis.urls);
  fillList('list-ips', 'count-ips', analysis.ips);
  fillList('list-keys', 'count-keys', analysis.apiKeys);
  fillList('list-emails', 'count-emails', analysis.emails);
}

function fillList(listId, countId, items) {
  const list = document.getElementById(listId);
  const count = document.getElementById(countId);
  count.textContent = `(${items.length})`;
  list.innerHTML = items.length
    ? items.slice(0, 500).map((v) => `<div class="truncate hover:text-white">${escapeHtml(v)}</div>`).join('')
    : '<div class="text-dim">aucune occurrence détectée</div>';
}

// ---------------------------------------------------------------------
// Classes DEX
// ---------------------------------------------------------------------
function renderClasses(dexList) {
  const panel = document.getElementById('panel-classes');
  if (!dexList || !dexList.length) {
    panel.innerHTML = '<div class="text-dim">aucun fichier .dex détecté</div>';
    return;
  }
  panel.innerHTML = dexList
    .map(
      (d) => `
    <div class="mb-4 border border-line rounded p-3">
      <div class="text-teal mb-1">${escapeHtml(d.file)}</div>
      <div class="text-dim text-[11px]">
        ${d.ok ? `${d.classCount} classes · ${d.methodCount} méthodes · ${d.stringCount} chaînes` : `non lisible : ${escapeHtml(d.error || 'inconnu')}`}
      </div>
    </div>`
    )
    .join('');
}

// ---------------------------------------------------------------------
// Rapport brut + warnings
// ---------------------------------------------------------------------
function renderReport(report) {
  document.getElementById('panel-report').textContent = JSON.stringify(report, null, 2);
}

function renderWarnings(warnings) {
  if (!warnings || !warnings.length) {
    warningsBar.classList.add('hidden');
    return;
  }
  warningsBar.classList.remove('hidden');
  warningsBar.innerHTML = warnings.map((w) => `⚠ ${escapeHtml(w)}`).join('<br/>');
}

// ---------------------------------------------------------------------
// Onglets
// ---------------------------------------------------------------------
document.querySelectorAll('.tab-btn').forEach((btn) => {
  btn.addEventListener('click', () => switchTab(btn.dataset.tab));
});
function switchTab(tab) {
  document.querySelectorAll('.tab-btn').forEach((b) => {
    b.classList.toggle('tab-active', b.dataset.tab === tab);
    b.classList.toggle('text-dim', b.dataset.tab !== tab);
  });
  document.querySelectorAll('.tab-panel').forEach((p) => p.classList.toggle('hidden', p.id !== `panel-${tab}`));
}

// ---------------------------------------------------------------------
// Téléchargement du pack ZIP structuré
// ---------------------------------------------------------------------
downloadBtn.addEventListener('click', () => {
  if (!currentSessionId) return;
  window.location.href = `/api/download/${currentSessionId}`;
});

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
