package com.linkshare.client

import android.content.Context
import android.net.Uri
import android.os.Environment
import com.linkshare.core.*
import io.ktor.client.*
import io.ktor.client.call.*
import io.ktor.client.engine.cio.*
import io.ktor.client.plugins.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.request.*
import io.ktor.client.statement.*
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import io.ktor.utils.io.jvm.javaio.toByteReadChannel
import io.ktor.utils.io.jvm.javaio.toInputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import java.io.File
import java.util.zip.ZipInputStream

class RemoteClient(val conn: Connection) {
    private val base = "http://${conn.host}:${conn.port}"
    private val http = HttpClient(CIO) {
        install(ContentNegotiation) { json(Json { ignoreUnknownKeys = true }) }
        install(HttpTimeout) {
            requestTimeoutMillis = HttpTimeout.INFINITE_TIMEOUT_MS
            connectTimeoutMillis = 5_000
            socketTimeoutMillis = 60_000
        }
        defaultRequest { headers.append("X-Token", conn.token) }
    }

    fun close() = http.close()

    suspend fun info(): DeviceInfo = http.get("$base/info").body()
    suspend fun list(path: String): Listing = http.get("$base/files") { parameter("path", path) }.body()
    suspend fun apps(): List<AppEntry> = http.get("$base/apps").body()

    /** URL directe (jeton inclus) pour ExoPlayer / Coil, avec support Range. */
    fun fileUrl(path: String) = "$base/file?path=${Uri.encode(path)}&token=${conn.token}"
    fun iconUrl(pkg: String) = "$base/icon?pkg=$pkg&token=${conn.token}"

    private fun downloadsDir() =
        File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "LinkShare")

    suspend fun downloadFile(path: String, name: String, onProgress: (Long) -> Unit): File =
        downloadTo("file", mapOf("path" to path), File(downloadsDir(), File(name).name), onProgress)

    suspend fun downloadApk(pkg: String, split: Boolean, onProgress: (Long) -> Unit): File =
        downloadTo("apk", mapOf("pkg" to pkg), File(downloadsDir(), pkg + if (split) ".apks" else ".apk"), onProgress)

    private suspend fun downloadTo(endpoint: String, params: Map<String, String>, dest: File, onProgress: (Long) -> Unit): File =
        withContext(Dispatchers.IO) {
            dest.parentFile?.mkdirs()
            http.prepareGet("$base/$endpoint") { params.forEach { (k, v) -> parameter(k, v) } }.execute { resp ->
                check(resp.status.isSuccess()) { "Erreur ${resp.status}" }
                val ch = resp.bodyAsChannel()
                val buf = ByteArray(BUF)
                var done = 0L
                dest.outputStream().buffered(BUF).use { out ->
                    while (true) {
                        val n = ch.readAvailable(buf, 0, buf.size)
                        if (n < 0) break
                        out.write(buf, 0, n); done += n; onProgress(done)
                    }
                }
            }
            dest
        }

    /** Télécharge un dossier : ZIP streamé et extrait à la volée (sans fichier temporaire). */
    suspend fun downloadFolder(path: String, name: String, onProgress: (Long) -> Unit): File =
        withContext(Dispatchers.IO) {
            val outDir = File(downloadsDir(), File(name).name).canonicalFile
            outDir.mkdirs()
            http.prepareGet("$base/folder") { parameter("path", path) }.execute { resp ->
                check(resp.status.isSuccess()) { "Erreur ${resp.status}" }
                var done = 0L
                ZipInputStream(resp.bodyAsChannel().toInputStream().buffered(BUF)).use { zin ->
                    var e = zin.nextEntry
                    while (e != null) {
                        val out = File(outDir, e.name).canonicalFile
                        if (!out.path.startsWith(outDir.path + File.separator)) throw SecurityException("Chemin invalide")
                        if (e.isDirectory) out.mkdirs() else {
                            out.parentFile?.mkdirs()
                            out.outputStream().buffered(BUF).use { done += zin.copyTo(it, BUF); onProgress(done) }
                        }
                        e = zin.nextEntry
                    }
                }
            }
            outDir
        }

    /** Envoie un fichier vers Download/LinkShare/<name> sur l'autre téléphone (name peut contenir des sous-dossiers). */
    suspend fun upload(ctx: Context, uri: Uri, name: String) {
        val input = ctx.contentResolver.openInputStream(uri) ?: error("Lecture impossible : $name")
        val resp = http.put("$base/upload") {
            parameter("name", name)
            setBody(input.toByteReadChannel())
        }
        check(resp.status.isSuccess()) { "Envoi refusé (${resp.status})" }
    }
}
