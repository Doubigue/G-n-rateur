package com.linkshare.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.text.format.Formatter
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import com.linkshare.core.*
import com.linkshare.server.ShareService

@Composable
fun LinkShareApp(vm: MainViewModel) {
    when {
        vm.viewer != null -> ViewerScreen(vm)
        vm.client != null -> RemoteScreen(vm)
        else -> HomeScreen(vm)
    }
}

private fun ensureAllFiles(ctx: Context): Boolean {
    if (Environment.isExternalStorageManager()) return true
    ctx.startActivity(
        Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${ctx.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    )
    Toast.makeText(ctx, "Autorise l'accès à tous les fichiers, puis réessaie", Toast.LENGTH_LONG).show()
    return false
}

private fun qr(text: String): Bitmap {
    val n = 640
    val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, n, n)
    return Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888).also { b ->
        for (x in 0 until n) for (y in 0 until n)
            b.setPixel(x, y, if (m.get(x, y)) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
    }
}

private fun scan(ctx: Context, onResult: (Connection) -> Unit) {
    val opts = GmsBarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()
    GmsBarcodeScanning.getClient(ctx, opts).startScan()
        .addOnSuccessListener { b ->
            val c = Connection.parse(b.rawValue ?: "")
            if (c != null) onResult(c) else Toast.makeText(ctx, "QR non reconnu", Toast.LENGTH_SHORT).show()
        }
}

@Composable
fun HomeScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val info by ShareState.info.collectAsState()
    fun startSharing() = ContextCompat.startForegroundService(ctx, Intent(ctx, ShareService::class.java))
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { startSharing() }

    LaunchedEffect(vm.message) { vm.message?.let { Toast.makeText(ctx, it, Toast.LENGTH_LONG).show(); vm.message = null } }

    Column(
        Modifier.fillMaxSize().systemBarsPadding().padding(24.dp).verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("LinkShare", style = MaterialTheme.typography.headlineLarge)
        val i = info
        if (i == null) {
            Button(
                onClick = {
                    if (ensureAllFiles(ctx)) {
                        if (Build.VERSION.SDK_INT >= 33 &&
                            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                        ) notif.launch(Manifest.permission.POST_NOTIFICATIONS) else startSharing()
                    }
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Partager mon téléphone") }
        } else {
            val bmp = remember(i) { qr(i.toUri()) }
            Image(bmp.asImageBitmap(), "QR code", Modifier.size(260.dp))
            Text("${i.host}:${i.port}")
            Text(
                "Quiconque scanne ce code accède à tes fichiers. Arrête le partage quand tu as fini.",
                style = MaterialTheme.typography.bodySmall,
            )
            OutlinedButton(onClick = { ctx.stopService(Intent(ctx, ShareService::class.java)) }) { Text("Arrêter le partage") }
        }
        HorizontalDivider()
        vm.status?.let { Text(it) }
        Button(
            onClick = { if (ensureAllFiles(ctx)) scan(ctx) { vm.connect(it) } },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Scanner un QR pour se connecter") }
        Text(
            "Les deux téléphones doivent être sur le même Wi-Fi, ou l'un sur le point d'accès de l'autre.",
            style = MaterialTheme.typography.bodySmall,
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RemoteScreen(vm: MainViewModel) {
    var tab by remember { mutableIntStateOf(0) }
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(vm.message) { vm.message?.let { snack.showSnackbar(it); vm.message = null } }
    BackHandler { if (tab == 0 && vm.path.isNotEmpty()) vm.up() else vm.disconnect() }

    val pickFiles = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { vm.uploadFiles(it) }
    val pickTree = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { it?.let(vm::uploadFolder) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(vm.deviceName) },
                navigationIcon = { TextButton(onClick = { vm.disconnect() }) { Text("✕") } },
            )
        },
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({ pickFiles.launch(arrayOf("*/*")) }, Modifier.weight(1f)) { Text("Envoyer fichiers") }
                Button({ pickTree.launch(null) }, Modifier.weight(1f)) { Text("Envoyer dossier") }
            }
        },
    ) { pad ->
        Column(Modifier.padding(pad)) {
            TabRow(selectedTabIndex = tab) {
                Tab(tab == 0, { tab = 0 }, text = { Text("Fichiers") })
                Tab(tab == 1, { tab = 1 }, text = { Text("Applications") })
            }
            vm.status?.let {
                Column(Modifier.padding(8.dp)) {
                    Text(it, style = MaterialTheme.typography.bodySmall)
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                }
            }
            if (tab == 0) FilesTab(vm) else AppsTab(vm)
        }
    }
}

@Composable
private fun FilesTab(vm: MainViewModel) {
    val ctx = LocalContext.current
    Text("/" + vm.path, Modifier.padding(horizontal = 16.dp, vertical = 8.dp), style = MaterialTheme.typography.labelLarge)
    LazyColumn {
        if (vm.path.isNotEmpty()) item {
            ListItem(
                headlineContent = { Text("..") },
                leadingContent = { Text("📁") },
                modifier = Modifier.clickable { vm.up() },
            )
        }
        items(vm.entries, key = { it.path }) { e ->
            var menu by remember { mutableStateOf(false) }
            ListItem(
                headlineContent = { Text(e.name, maxLines = 1) },
                supportingContent = { if (!e.isDir) Text(Formatter.formatShortFileSize(ctx, e.size)) },
                leadingContent = { Text(if (e.isDir) "📁" else "📄") },
                trailingContent = {
                    Box {
                        TextButton({ menu = true }) { Text("⋮") }
                        DropdownMenu(menu, { menu = false }) {
                            DropdownMenuItem(
                                text = { Text(if (e.isDir) "Télécharger le dossier" else "Télécharger") },
                                onClick = { menu = false; vm.download(e) },
                            )
                        }
                    }
                },
                modifier = Modifier.clickable { vm.tap(e) },
            )
        }
    }
}

@Composable
private fun AppsTab(vm: MainViewModel) {
    val ctx = LocalContext.current
    var system by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { vm.loadApps() }
    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Switch(system, { system = it })
        Spacer(Modifier.width(12.dp))
        Text("Afficher les apps système")
    }
    LazyColumn {
        items(vm.apps.filter { system || !it.isSystem }, key = { it.pkg }) { a ->
            ListItem(
                leadingContent = { AsyncImage(vm.client?.iconUrl(a.pkg), null, Modifier.size(40.dp)) },
                headlineContent = { Text(a.name, maxLines = 1) },
                supportingContent = {
                    Text("${a.version} · ${Formatter.formatShortFileSize(ctx, a.size)}" + if (a.split) " · .apks" else "")
                },
                modifier = Modifier.clickable { vm.downloadApp(a) },
            )
        }
    }
}

@Composable
fun ViewerScreen(vm: MainViewModel) {
    val e = vm.viewer ?: return
    val url = vm.client?.fileUrl(e.path) ?: return
    BackHandler { vm.viewer = null }
    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton({ vm.viewer = null }) { Text("←") }
            Text(e.name, maxLines = 1)
        }
        if (e.isImage()) AsyncImage(url, e.name, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
        else Player(url)
    }
}

@Composable
private fun Player(url: String) {
    val ctx = LocalContext.current
    val player = remember {
        ExoPlayer.Builder(ctx).build().apply {
            setMediaItem(MediaItem.fromUri(url)); prepare(); playWhenReady = true
        }
    }
    DisposableEffect(Unit) { onDispose { player.release() } }
    AndroidView(factory = { PlayerView(it).also { v -> v.player = player } }, modifier = Modifier.fillMaxSize())
}
