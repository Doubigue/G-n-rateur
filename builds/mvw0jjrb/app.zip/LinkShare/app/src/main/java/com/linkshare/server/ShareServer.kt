package com.linkshare.server

import android.content.Context
import android.content.pm.ApplicationInfo
import android.graphics.Bitmap
import android.os.Build
import android.os.Environment
import androidx.core.graphics.drawable.toBitmap
import com.linkshare.core.*
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import io.ktor.server.application.*
import io.ktor.server.cio.*
import io.ktor.server.engine.*
import io.ktor.server.http.content.LocalFileContent
import io.ktor.server.plugins.autohead.AutoHeadResponse
import io.ktor.server.plugins.contentnegotiation.ContentNegotiation
import io.ktor.server.plugins.partialcontent.PartialContent
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Serveur HTTP embarqué : fichiers, dossiers (ZIP streamé), apps, upload. */
class ShareServer(private val ctx: Context, private val token: String, private val port: Int = PORT) {

    private val root = SharedRoot(Environment.getExternalStorageDirectory())
    private val uploads = SharedRoot(File(root.dir, "Download/LinkShare").apply { mkdirs() })
    private var engine: ApplicationEngine? = null

    fun start() {
        engine = embeddedServer(CIO, port = port, host = "0.0.0.0") { module() }.start(wait = false)
    }

    fun stop() { engine?.stop(300, 1000); engine = null }

    private fun Application.module() {
        install(ContentNegotiation) { json() }
        install(PartialContent)       // requêtes Range : lecture/seek en streaming
        install(AutoHeadResponse)

        // Authentification par jeton (reçu via le QR code)
        intercept(ApplicationCallPipeline.Plugins) {
            val given = call.request.headers["X-Token"] ?: call.request.queryParameters["token"] ?: ""
            if (!MessageDigest.isEqual(given.toByteArray(), token.toByteArray())) {
                call.respond(HttpStatusCode.Unauthorized)
                finish()
            }
        }

        routing {
            get("/info") { call.respond(DeviceInfo(Build.MODEL)) }

            get("/files") {
                val dir = root.resolve(call.parameters["path"] ?: "")
                if (dir == null || !dir.isDirectory) return@get call.respond(HttpStatusCode.NotFound)
                val entries = withContext(Dispatchers.IO) {
                    (dir.listFiles() ?: emptyArray()).map {
                        FileEntry(it.name, root.relative(it), it.isDirectory, if (it.isDirectory) 0 else it.length(), it.lastModified())
                    }.sortedWith(compareByDescending<FileEntry> { it.isDir }.thenBy { it.name.lowercase() })
                }
                call.respond(Listing(root.relative(dir), entries))
            }

            get("/file") {
                val f = root.resolve(call.parameters["path"] ?: "")
                if (f == null || !f.isFile) return@get call.respond(HttpStatusCode.NotFound)
                call.respond(LocalFileContent(f))
            }

            get("/folder") {
                val dir = root.resolve(call.parameters["path"] ?: "")
                if (dir == null || !dir.isDirectory) return@get call.respond(HttpStatusCode.NotFound)
                call.respondOutputStream(ContentType.Application.Zip) {
                    ZipOutputStream(this.buffered(BUF)).use { zip ->
                        zip.setLevel(0) // pas de compression : vitesse maximale
                        dir.walkTopDown().filter { it.isFile }.forEach { f ->
                            zip.putNextEntry(ZipEntry(f.relativeTo(dir).path.replace('\\', '/')))
                            f.inputStream().use { it.copyTo(zip, BUF) }
                            zip.closeEntry()
                        }
                    }
                }
            }

            put("/upload") {
                val name = call.parameters["name"] ?: return@put call.respond(HttpStatusCode.BadRequest)
                val dest = uploads.resolve(name)
                if (dest == null || dest == uploads.dir) return@put call.respond(HttpStatusCode.BadRequest)
                withContext(Dispatchers.IO) {
                    dest.parentFile?.mkdirs()
                    dest.outputStream().buffered(BUF).use { out ->
                        call.receiveStream().use { it.copyTo(out, BUF) }
                    }
                }
                call.respond(HttpStatusCode.Created)
            }

            get("/apps") {
                val pm = ctx.packageManager
                val list = withContext(Dispatchers.IO) {
                    pm.getInstalledApplications(0).map { ai ->
                        val splits = ai.splitSourceDirs ?: emptyArray()
                        AppEntry(
                            name = pm.getApplicationLabel(ai).toString(),
                            pkg = ai.packageName,
                            version = runCatching { pm.getPackageInfo(ai.packageName, 0).versionName }.getOrNull() ?: "",
                            size = File(ai.sourceDir).length() + splits.sumOf { File(it).length() },
                            isSystem = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0,
                            split = splits.isNotEmpty(),
                        )
                    }.sortedBy { it.name.lowercase() }
                }
                call.respond(list)
            }

            get("/apk") {
                val pkg = call.parameters["pkg"] ?: return@get call.respond(HttpStatusCode.BadRequest)
                val ai = try { ctx.packageManager.getApplicationInfo(pkg, 0) }
                catch (e: Exception) { return@get call.respond(HttpStatusCode.NotFound) }
                val splits = ai.splitSourceDirs ?: emptyArray()
                if (splits.isEmpty()) {
                    call.respond(LocalFileContent(File(ai.sourceDir), ContentType("application", "vnd.android.package-archive")))
                } else {
                    call.respondOutputStream(ContentType.Application.Zip) {
                        ZipOutputStream(this.buffered(BUF)).use { z ->
                            z.setLevel(0)
                            (listOf(ai.sourceDir) + splits.toList()).forEach { p ->
                                z.putNextEntry(ZipEntry(File(p).name))
                                File(p).inputStream().use { it.copyTo(z, BUF) }
                                z.closeEntry()
                            }
                        }
                    }
                }
            }

            get("/icon") {
                val pkg = call.parameters["pkg"] ?: return@get call.respond(HttpStatusCode.BadRequest)
                val bytes = withContext(Dispatchers.IO) {
                    runCatching {
                        val bmp = ctx.packageManager.getApplicationIcon(pkg).toBitmap(96, 96)
                        ByteArrayOutputStream().also { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }.toByteArray()
                    }.getOrNull()
                }
                if (bytes == null) call.respond(HttpStatusCode.NotFound) else call.respondBytes(bytes, ContentType.Image.PNG)
            }
        }
    }
}
