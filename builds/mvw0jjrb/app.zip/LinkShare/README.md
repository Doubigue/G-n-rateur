# LinkShare

Partage rapide Android (Kotlin / Compose / Ktor) avec accès distant aux fichiers et applications.

## Lancer
1. Ouvrir le dossier dans Android Studio (Ladybug ou plus récent, JDK 17) et laisser Gradle synchroniser.
2. Installer sur deux téléphones (Android 11+).
3. Téléphone A : « Partager mon téléphone » (autoriser l'accès à tous les fichiers) → un QR s'affiche.
4. Téléphone B : « Scanner un QR » → parcourir fichiers et apps, lire vidéos / audio / images en streaming,
   télécharger fichiers ou dossiers, envoyer fichiers ou dossiers (ils arrivent dans Download/LinkShare).

## Réseau
Même Wi-Fi, ou B connecté au point d'accès de A (le plus rapide, sans routeur).

## À faire ensuite
- TLS (certificat auto-signé épinglé dans le QR) : actuellement HTTP + jeton aléatoire de 192 bits.
- Wi-Fi Direct (WifiP2pManager) pour une connexion sans routeur ni hotspot manuel.
- Choix des dossiers partagés + écran de consentement / révocation.
- Visionneuse texte/PDF, reprise des transferts, installation directe des APK.
