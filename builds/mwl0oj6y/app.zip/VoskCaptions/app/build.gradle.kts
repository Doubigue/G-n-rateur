import java.io.File
import java.util.Properties
import java.util.Base64

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// ---- Clé de signature dédiée -------------------------------------------------------------
// Ordre de recherche : 1) keystore.properties (+ fichier .jks)  2) variables d'environnement / secrets CI
//   VOSK_KEYSTORE_BASE64 (le .jks encodé en base64), VOSK_KEYSTORE_PASSWORD, VOSK_KEY_ALIAS, VOSK_KEY_PASSWORD
val keystoreProps = Properties().apply {
    val f = rootProject.file("keystore.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}
fun signingValue(key: String, env: String): String? =
    keystoreProps.getProperty(key) ?: System.getenv(env)?.takeIf { it.isNotBlank() }

val keystoreFile: File? = run {
    val fromProps = keystoreProps.getProperty("storeFile")?.let { rootProject.file(it) }
    val b64 = System.getenv("VOSK_KEYSTORE_BASE64")?.takeIf { it.isNotBlank() }
    when {
        fromProps != null && fromProps.exists() -> fromProps
        b64 != null -> layout.buildDirectory.file("ci-signing/release.jks").get().asFile.also {
            it.parentFile.mkdirs()
            it.writeBytes(Base64.getMimeDecoder().decode(b64))
        }
        else -> null
    }
}
val storePass = signingValue("storePassword", "VOSK_KEYSTORE_PASSWORD")
val keyAliasName = signingValue("keyAlias", "VOSK_KEY_ALIAS") ?: "vosk-captions"
val keyPass = signingValue("keyPassword", "VOSK_KEY_PASSWORD") ?: storePass
val hasReleaseKey = keystoreFile != null && storePass != null
if (!hasReleaseKey) {
    logger.warn("⚠ Clé de signature introuvable (keystore.properties ou VOSK_KEYSTORE_*) : l'APK ne sera PAS signé avec votre clé dédiée.")
}

android {
    namespace = "com.example.voskcaptions"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.voskcaptions"
        minSdk = 29            // AudioPlaybackCapture = Android 10+
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    signingConfigs {
        if (hasReleaseKey) {
            create("release") {
                storeFile = keystoreFile
                storePassword = storePass
                keyAlias = keyAliasName
                keyPassword = keyPass
            }
        }
    }

    buildTypes {
        // Même clé en debug : l'APK debug et l'APK release se mettent à jour l'un l'autre sans désinstaller.
        debug {
            if (hasReleaseKey) signingConfig = signingConfigs.getByName("release")
        }
        release {
            isMinifyEnabled = false
            if (hasReleaseKey) signingConfig = signingConfigs.getByName("release")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    buildFeatures { viewBinding = true }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    packaging {
        jniLibs { useLegacyPackaging = true }   // libs natives Vosk/JNA extraites sur disque
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.1")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.4")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")

    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.8.1")

    // Vosk (reconnaissance vocale hors ligne)
    implementation("net.java.dev.jna:jna:5.13.0@aar")
    implementation("com.alphacephei:vosk-android:0.3.47")

    // ML Kit (traduction hors ligne + détection de langue embarquée)
    implementation("com.google.mlkit:translate:17.0.3")
    implementation("com.google.mlkit:language-id:17.0.6")
}
