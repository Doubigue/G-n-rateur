plugins {
    kotlin("jvm") version "2.0.21"
    application
}

group = "kbrowser"
version = "1.0.0"

repositories {
    mavenCentral()
}

dependencies {
    // Chromium embarqué (JCEF) : rendu web, DevTools, téléchargements
    implementation("me.friwi:jcefmaven:122.1.10")
    // Décompression zip / rar (RAR4 + RAR5) / 7z / tar
    implementation("net.sf.sevenzipjbinding:sevenzipjbinding:16.02-2.01")
    implementation("net.sf.sevenzipjbinding:sevenzipjbinding-all-platforms:16.02-2.01")
    // Certificat auto-signé pour le serveur HTTPS local
    implementation("org.bouncycastle:bcpkix-jdk18on:1.78.1")
    // Lecture des manifest.json des extensions
    implementation("com.google.code.gson:gson:2.11.0")
}

application {
    mainClass.set("kbrowser.MainKt")
    applicationDefaultJvmArgs = listOf(
        "--add-opens=java.desktop/sun.awt=ALL-UNNAMED",
        "--add-opens=java.desktop/java.awt.peer=ALL-UNNAMED",
        "--add-opens=java.desktop/sun.lwawt=ALL-UNNAMED",
        "--add-opens=java.desktop/sun.lwawt.macosx=ALL-UNNAMED"
    )
}
