# KBrowser

Navigateur de bureau écrit en Kotlin (Swing + Chromium embarqué via JCEF).

## Lancer

Prérequis : JDK 17+ et une connexion Internet au premier démarrage
(téléchargement du moteur Chromium, ~100 Mo, mis en cache dans `~/.kbrowser`).

- IntelliJ IDEA : ouvrir le dossier, laisser Gradle synchroniser, lancer `MainKt`.
- Terminal : `gradle run` (ou `gradle wrapper` puis `./gradlew run`).
- Argument optionnel : une URL, un fichier, un dossier ou une archive
  `gradle run --args="https://exemple.com/archive.zip"`

## Fonctions

| Besoin | Réalisation |
|---|---|
| Lire / décompresser zip, rar, 7z, tar | `Archive.kt` (java.util.zip + SevenZipJBinding, RAR5 inclus, protection zip-slip). Fichier ▸ Ouvrir… ou glisser-déposer : l'archive est extraite puis servie. |
| Fichiers web en HTTPS local | `LocalServer.kt` : serveur HTTPS (127.0.0.1:8443) avec certificat auto-signé (`SelfSignedCert.kt`), accepté uniquement pour localhost. Index, listing de dossiers, Range, MIME (wasm, js, css…). Marche pour un build React/Vite, Flutter web, un site statique. |
| Lire CSS / JS / Python / Flutter (Dart) / Kotlin / React (JSX/TSX) / Java | HTML, CSS et JS **s'exécutent** normalement. Les fichiers source ouverts directement s'affichent dans un visualiseur coloré (`viewer.html`) ; `?raw=1` donne le texte brut, `?src=1` force la vue source (même pour .html). Python, Kotlin, Java, Dart ne sont **pas exécutés**. |
| Téléchargements | `Downloads.kt` : lien de téléchargement collé dans la barre d'adresse, drag & drop d'une URL, ou Fichier ▸ Télécharger une URL. Une archive téléchargée propose « Extraire et ouvrir ». |
| Extensions type Chrome | `Extensions.kt` : installation depuis dossier, .crx/.zip, import depuis Chrome / Edge / Brave installés sur l'ordinateur, ou Chrome Web Store (URL/ID). |

## Limites des extensions

JCEF n'expose pas l'API d'extensions de Chromium. KBrowser réimplémente donc le
plus courant :

- supporté : `content_scripts` (matches, exclude_matches, js, css, run_at, all_frames),
  pages popup/options, mini-shim `chrome.runtime` / `chrome.storage` / `chrome.i18n`
- non supporté : service workers/background, `webRequest`, `declarativeNetRequest`
  (bloqueurs de pub), `chrome.tabs`, menus contextuels, messagerie entre scripts…
- les scripts s'exécutent dans le monde de la page (pas de « isolated world »).

## Sécurité

Le serveur écoute uniquement sur la boucle locale, refuse les requêtes
`Sec-Fetch-Site: cross-site` et les en-têtes Host inattendus. Ouvrir un fichier
isolé expose son dossier parent à ce serveur local : évitez d'ouvrir un fichier
à la racine d'un dossier sensible.
