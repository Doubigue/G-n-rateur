package kbrowser

import org.cef.CefApp
import org.cef.CefClient
import org.cef.browser.CefBrowser
import org.cef.browser.CefFrame
import org.cef.callback.CefCallback
import org.cef.handler.CefDisplayHandlerAdapter
import org.cef.handler.CefFocusHandlerAdapter
import org.cef.handler.CefLifeSpanHandlerAdapter
import org.cef.handler.CefLoadHandler
import org.cef.handler.CefLoadHandlerAdapter
import org.cef.handler.CefRequestHandlerAdapter
import org.cef.network.CefRequest
import org.cef.security.CefSSLInfo
import java.awt.BorderLayout
import java.awt.Component
import java.awt.Desktop
import java.awt.Dimension
import java.awt.FlowLayout
import java.awt.KeyboardFocusManager
import java.awt.Toolkit
import java.awt.datatransfer.DataFlavor
import java.awt.dnd.DnDConstants
import java.awt.dnd.DropTarget
import java.awt.dnd.DropTargetAdapter
import java.awt.dnd.DropTargetDropEvent
import java.awt.event.FocusAdapter
import java.awt.event.FocusEvent
import java.awt.event.KeyEvent
import java.awt.event.WindowAdapter
import java.awt.event.WindowEvent
import java.io.File
import java.net.URI
import java.net.URLEncoder
import javax.swing.BorderFactory
import javax.swing.JButton
import javax.swing.JComponent
import javax.swing.JFileChooser
import javax.swing.JFrame
import javax.swing.JLabel
import javax.swing.JList
import javax.swing.JMenu
import javax.swing.JMenuBar
import javax.swing.JMenuItem
import javax.swing.JOptionPane
import javax.swing.JPanel
import javax.swing.JScrollPane
import javax.swing.JTabbedPane
import javax.swing.JTextField
import javax.swing.KeyStroke
import javax.swing.SwingUtilities
import kotlin.system.exitProcess

class BrowserWindow(private val cefApp: CefApp, private val ctx: AppContext) : JFrame("KBrowser") {
    private val tabs = JTabbedPane()
    private val address = JTextField()
    private val back = JButton("◀")
    private val forward = JButton("▶")
    private val reload = JButton("⟳")
    private val status = JLabel(" ")
    private val tabList = mutableListOf<Tab>()
    private var browserFocus = true

    private val downloadExts = setOf(
        "zip", "rar", "7z", "tar", "gz", "tgz", "bz2", "xz", "exe", "msi", "dmg", "pkg",
        "apk", "iso", "jar", "deb", "rpm", "appimage"
    )

    init {
        defaultCloseOperation = DO_NOTHING_ON_CLOSE
        size = Dimension(1280, 820)
        setLocationRelativeTo(null)

        val toolbar = JPanel(BorderLayout(6, 0)).apply {
            border = BorderFactory.createEmptyBorder(6, 6, 6, 6)
            add(JPanel(FlowLayout(FlowLayout.LEFT, 4, 0)).apply { add(back); add(forward); add(reload) }, BorderLayout.WEST)
            add(address, BorderLayout.CENTER)
            add(JButton("+").apply {
                toolTipText = "Nouvel onglet"
                addActionListener { newTab(ctx.server.baseUrl + "/") }
            }, BorderLayout.EAST)
        }
        status.border = BorderFactory.createEmptyBorder(2, 8, 2, 8)
        contentPane.layout = BorderLayout()
        contentPane.add(toolbar, BorderLayout.NORTH)
        contentPane.add(tabs, BorderLayout.CENTER)
        contentPane.add(status, BorderLayout.SOUTH)

        back.addActionListener { current()?.browser?.goBack() }
        forward.addActionListener { current()?.browser?.goForward() }
        reload.addActionListener {
            current()?.let { if (it.loading) it.browser.stopLoad() else it.browser.reload() }
        }
        address.addActionListener { navigate(address.text) }
        address.addFocusListener(object : FocusAdapter() {
            override fun focusGained(e: FocusEvent) {
                browserFocus = false
                address.selectAll()
            }
        })
        tabs.addChangeListener { syncToolbar() }

        enableDrop(toolbar); enableDrop(status); enableDrop(tabs)
        buildMenu()

        ctx.downloads.onStatus = { msg -> SwingUtilities.invokeLater { status.text = msg } }
        ctx.downloads.onCompleted = { f -> SwingUtilities.invokeLater { afterDownload(f) } }

        addWindowListener(object : WindowAdapter() {
            override fun windowClosing(e: WindowEvent) = shutdown()
        })
    }

    fun start(arg: String?) {
        newTab(ctx.server.baseUrl + "/")
        if (!arg.isNullOrBlank()) navigate(arg)
    }

    // ------------------------------------------------------------------ onglets

    private inner class Tab(startUrl: String) {
        val client: CefClient = cefApp.createClient()
        val browser: CefBrowser = client.createBrowser(startUrl, false, false)
        val component: Component = browser.uiComponent
        var title: String = "Nouvel onglet"
        var url: String = startUrl
        var loading = false
        var canBack = false
        var canForward = false
        private val titleLabel = JLabel(title)
        val header = JPanel(FlowLayout(FlowLayout.LEFT, 4, 0)).apply {
            isOpaque = false
            add(titleLabel)
            add(JButton("×").apply {
                isBorderPainted = false
                isContentAreaFilled = false
                isFocusable = false
                addActionListener { closeTab(this@Tab) }
            })
        }

        init {
            client.addDisplayHandler(object : CefDisplayHandlerAdapter() {
                override fun onAddressChange(b: CefBrowser, frame: CefFrame, newUrl: String) {
                    if (!frame.isMain) return
                    SwingUtilities.invokeLater {
                        this@Tab.url = newUrl
                        if (current() === this@Tab) syncToolbar()
                    }
                }

                override fun onTitleChange(b: CefBrowser, newTitle: String) {
                    SwingUtilities.invokeLater {
                        this@Tab.title = newTitle.ifBlank { this@Tab.url }
                        titleLabel.text = this@Tab.title.take(26)
                        titleLabel.toolTipText = this@Tab.title
                        if (current() === this@Tab) syncToolbar()
                    }
                }

                override fun onStatusMessage(b: CefBrowser, value: String?) {
                    SwingUtilities.invokeLater { status.text = if (value.isNullOrEmpty()) " " else value }
                }
            })

            client.addLoadHandler(object : CefLoadHandlerAdapter() {
                override fun onLoadingStateChange(b: CefBrowser, isLoading: Boolean, canGoBack: Boolean, canGoForward: Boolean) {
                    SwingUtilities.invokeLater {
                        loading = isLoading
                        canBack = canGoBack
                        canForward = canGoForward
                        if (current() === this@Tab) syncToolbar()
                    }
                }

                override fun onLoadStart(b: CefBrowser, frame: CefFrame, transitionType: CefRequest.TransitionType) {
                    inject(frame, "document_start")
                }

                override fun onLoadEnd(b: CefBrowser, frame: CefFrame, httpStatusCode: Int) {
                    inject(frame, "document_end")
                    inject(frame, "document_idle")
                }
            })

            // target=_blank / window.open -> nouvel onglet
            client.addLifeSpanHandler(object : CefLifeSpanHandlerAdapter() {
                override fun onBeforePopup(b: CefBrowser, frame: CefFrame, targetUrl: String, targetFrameName: String): Boolean {
                    SwingUtilities.invokeLater { newTab(targetUrl) }
                    return true
                }
            })

            // Certificat auto-signé accepté UNIQUEMENT pour localhost / 127.0.0.1
            client.addRequestHandler(object : CefRequestHandlerAdapter() {
                override fun onCertificateError(
                    b: CefBrowser, certError: CefLoadHandler.ErrorCode, requestUrl: String,
                    sslInfo: CefSSLInfo?, callback: CefCallback
                ): Boolean {
                    val host = try { URI(requestUrl).host } catch (_: Exception) { null }
                    if (host == "localhost" || host == "127.0.0.1") {
                        callback.Continue()
                        return true
                    }
                    return false
                }
            })

            client.addDownloadHandler(ctx.downloads)

            client.addFocusHandler(object : CefFocusHandlerAdapter() {
                override fun onGotFocus(b: CefBrowser) {
                    if (browserFocus) return
                    browserFocus = true
                    KeyboardFocusManager.getCurrentKeyboardFocusManager().clearGlobalFocusOwner()
                    b.setFocus(true)
                }

                override fun onTakeFocus(b: CefBrowser, next: Boolean) {
                    browserFocus = false
                }
            })
        }
    }

    private fun inject(frame: CefFrame, runAt: String) {
        val u = frame.url ?: return
        if (!u.startsWith("http") && !u.startsWith("file")) return
        ctx.extensions.scriptsFor(u, runAt, frame.isMain).forEach { frame.executeJavaScript(it, u, 0) }
    }

    private fun current(): Tab? = tabList.getOrNull(tabs.selectedIndex)

    fun newTab(url: String) {
        val t = Tab(url)
        tabList.add(t)
        tabs.addTab(null, t.component)
        tabs.setTabComponentAt(tabs.tabCount - 1, t.header)
        tabs.selectedIndex = tabs.tabCount - 1
    }

    private fun closeTab(t: Tab) {
        val idx = tabList.indexOf(t)
        if (idx < 0) return
        tabList.removeAt(idx)
        tabs.removeTabAt(idx)
        t.client.dispose()
        if (tabList.isEmpty()) newTab(ctx.server.baseUrl + "/")
    }

    private fun syncToolbar() {
        val t = current() ?: return
        back.isEnabled = t.canBack
        forward.isEnabled = t.canForward
        reload.text = if (t.loading) "✕" else "⟳"
        if (!address.hasFocus()) address.text = t.url
        title = t.title + " — KBrowser"
    }

    private fun loadInCurrent(url: String) {
        val t = current()
        if (t == null) newTab(url) else t.browser.loadURL(url)
    }

    // ------------------------------------------------------------------ navigation

    fun navigate(input: String) {
        val text = input.trim()
        if (text.isEmpty()) return

        // Fichier / dossier / archive local (chemin ou file://) -> servi en HTTPS local
        val local: File? = when {
            text.startsWith("file:") -> try { File(URI(text)) } catch (_: Exception) { null }
            !text.startsWith("http") -> File(text).takeIf { it.exists() }
            else -> null
        }
        if (local != null && local.exists()) return openLocal(local)

        // Lien de téléchargement direct (lien partagé)
        if (text.startsWith("http")) {
            val path = try { URI(text).path?.lowercase() } catch (_: Exception) { null }
            if (path != null && downloadExts.contains(path.substringAfterLast('.', ""))) {
                current()?.browser?.startDownload(text)
                status.text = "⬇ Téléchargement demandé…"
                return
            }
        }
        loadInCurrent(toUrl(text))
    }

    private fun toUrl(t: String): String = when {
        t.startsWith("http://") || t.startsWith("https://") || t.startsWith("about:") ||
            t.startsWith("chrome:") || t.startsWith("data:") -> t
        t.startsWith("localhost") || Regex("^\\d{1,3}(\\.\\d{1,3}){3}(:\\d+)?(/.*)?$").matches(t) -> "http://$t"
        !t.contains(' ') && t.contains('.') -> "https://$t"
        else -> "https://duckduckgo.com/?q=" + URLEncoder.encode(t, "UTF-8")
    }

    fun openLocal(file: File) {
        var url = ""
        runTask("Préparation de ${file.name}…", { url = ctx.localUrlFor(file) }) { loadInCurrent(url) }
    }

    private fun runTask(label: String, work: () -> Unit, onOk: () -> Unit = {}) {
        status.text = "⏳ $label"
        Thread {
            try {
                work()
                SwingUtilities.invokeLater { status.text = " "; onOk() }
            } catch (e: Throwable) {
                SwingUtilities.invokeLater {
                    status.text = " "
                    JOptionPane.showMessageDialog(this, "Erreur : ${e.message ?: e}", "KBrowser", JOptionPane.ERROR_MESSAGE)
                }
            }
        }.apply { isDaemon = true }.start()
    }

    private fun afterDownload(f: File) {
        if (Archive.isArchive(f)) {
            val r = JOptionPane.showConfirmDialog(
                this, "« ${f.name} » est téléchargé.\nL'extraire et l'ouvrir dans le navigateur ?",
                "Téléchargement terminé", JOptionPane.YES_NO_OPTION
            )
            if (r == JOptionPane.YES_OPTION) openLocal(f)
        }
    }

    private fun enableDrop(c: JComponent) {
        c.dropTarget = DropTarget(c, object : DropTargetAdapter() {
            override fun drop(e: DropTargetDropEvent) {
                try {
                    e.acceptDrop(DnDConstants.ACTION_COPY)
                    val t = e.transferable
                    if (t.isDataFlavorSupported(DataFlavor.javaFileListFlavor)) {
                        @Suppress("UNCHECKED_CAST")
                        (t.getTransferData(DataFlavor.javaFileListFlavor) as List<File>).firstOrNull()?.let { openLocal(it) }
                    } else if (t.isDataFlavorSupported(DataFlavor.stringFlavor)) {
                        navigate(t.getTransferData(DataFlavor.stringFlavor) as String)
                    }
                    e.dropComplete(true)
                } catch (_: Exception) {
                    e.dropComplete(false)
                }
            }
        })
    }

    // ------------------------------------------------------------------ menus

    private fun buildMenu() {
        val mask = Toolkit.getDefaultToolkit().menuShortcutKeyMaskEx
        fun item(text: String, key: Int? = null, action: () -> Unit) = JMenuItem(text).apply {
            if (key != null) accelerator = KeyStroke.getKeyStroke(key, mask)
            addActionListener { action() }
        }

        val file = JMenu("Fichier").apply {
            add(item("Nouvel onglet", KeyEvent.VK_T) { newTab(ctx.server.baseUrl + "/") })
            add(item("Fermer l'onglet", KeyEvent.VK_W) { current()?.let { closeTab(it) } })
            addSeparator()
            add(item("Ouvrir un fichier, une archive ou un dossier…", KeyEvent.VK_O) { chooseAndOpen() })
            add(item("Télécharger une URL…") { downloadUrl() })
            add(item("Ouvrir le dossier des téléchargements") {
                runCatching { Desktop.getDesktop().open(ctx.paths.downloads) }
            })
            addSeparator()
            add(item("Vider l'espace de travail (archives extraites)") { clearWorkspace() })
            addSeparator()
            add(item("Quitter") { shutdown() })
        }

        val extMenu = JMenu("Extensions").apply {
            add(item("Installer depuis un dossier (non empaqueté)…") { installFromFolder() })
            add(item("Installer un fichier .crx / .zip…") { installFromFile() })
            add(item("Importer depuis Chrome / Edge / Brave…") { importFromChrome() })
            add(item("Chrome Web Store (URL ou ID)…") { installFromStore() })
            addSeparator()
            add(item("Gérer les extensions…") {
                ExtensionsDialog(this@BrowserWindow, ctx) { newTab(it) }.isVisible = true
            })
        }

        val tools = JMenu("Outils").apply {
            add(item("Outils de développement") { devTools() }
                .apply { accelerator = KeyStroke.getKeyStroke(KeyEvent.VK_F12, 0) })
            add(item("Voir le code source de la page locale") {
                current()?.let { t ->
                    loadInCurrent(t.url + (if (t.url.contains('?')) "&" else "?") + "src=1")
                }
            })
        }
        jMenuBar = JMenuBar().apply { add(file); add(extMenu); add(tools) }
    }

    private fun chooseAndOpen() {
        val fc = JFileChooser().apply {
            fileSelectionMode = JFileChooser.FILES_AND_DIRECTORIES
            dialogTitle = "Ouvrir un fichier, une archive ou un dossier"
        }
        if (fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) openLocal(fc.selectedFile)
    }

    private fun downloadUrl() {
        val url = JOptionPane.showInputDialog(this, "Lien de téléchargement :", "Télécharger", JOptionPane.PLAIN_MESSAGE)?.trim()
        if (url.isNullOrEmpty()) return
        (current() ?: return).browser.startDownload(url)
    }

    private fun clearWorkspace() {
        val ok = JOptionPane.showConfirmDialog(
            this, "Supprimer toutes les archives extraites et fermer les sites locaux ?",
            "Espace de travail", JOptionPane.YES_NO_OPTION
        )
        if (ok != JOptionPane.YES_OPTION) return
        runTask("Nettoyage…", {
            ctx.server.clearSites()
            ctx.paths.workspace.listFiles()?.forEach { it.deleteRecursively() }
        })
    }

    private fun devTools() {
        val t = current() ?: return
        JFrame("DevTools — ${t.title}").apply {
            setSize(1000, 650)
            add(t.browser.devTools.uiComponent)
            setLocationRelativeTo(this@BrowserWindow)
            isVisible = true
        }
    }

    // ------------------------------------------------------------------ extensions

    private fun info(msg: String) = JOptionPane.showMessageDialog(this, msg, "KBrowser", JOptionPane.INFORMATION_MESSAGE)

    private fun installFromFolder() {
        val fc = JFileChooser().apply {
            fileSelectionMode = JFileChooser.DIRECTORIES_ONLY
            dialogTitle = "Dossier de l'extension (contenant manifest.json)"
        }
        if (fc.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) return
        val dir = fc.selectedFile
        var name = ""
        runTask("Installation…", { name = ctx.extensions.installFromDirectory(dir).name }) {
            info("Extension installée : $name\nRechargez les pages pour l'activer.")
        }
    }

    private fun installFromFile() {
        val fc = JFileChooser().apply { dialogTitle = "Fichier .crx ou .zip" }
        if (fc.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) return
        val f = fc.selectedFile
        var name = ""
        runTask("Installation…", { name = ctx.extensions.installFromPackage(f).name }) {
            info("Extension installée : $name\nRechargez les pages pour l'activer.")
        }
    }

    private fun installFromStore() {
        val input = JOptionPane.showInputDialog(
            this, "URL de la fiche Chrome Web Store ou identifiant (32 lettres) :",
            "Chrome Web Store", JOptionPane.PLAIN_MESSAGE
        )?.trim()
        if (input.isNullOrEmpty()) return
        var name = ""
        runTask("Téléchargement de l'extension…", { name = ctx.extensions.installFromWebStore(input).name }) {
            info("Extension installée : $name\nRechargez les pages pour l'activer.")
        }
    }

    private fun importFromChrome() {
        val found = ctx.extensions.chromeInstalledExtensions()
        if (found.isEmpty()) {
            info("Aucune extension Chrome / Edge / Brave trouvée sur cet ordinateur.")
            return
        }
        val labels = found.map { (id, dir) ->
            val p = ctx.extensions.peek(dir)
            "${p?.first ?: id}   v${p?.second ?: "?"}   [$id]"
        }
        val list = JList(labels.toTypedArray())
        val scroll = JScrollPane(list).apply { preferredSize = Dimension(560, 340) }
        val res = JOptionPane.showConfirmDialog(
            this, scroll, "Importer des extensions (sélection multiple)", JOptionPane.OK_CANCEL_OPTION
        )
        if (res != JOptionPane.OK_OPTION) return
        val picked = list.selectedIndices.map { found[it] }
        if (picked.isEmpty()) return
        var n = 0
        runTask("Import…", {
            picked.forEach { (id, dir) -> ctx.extensions.installFromChromeDir(id, dir); n++ }
        }) { info("$n extension(s) importée(s). Rechargez les pages pour les activer.") }
    }

    // ------------------------------------------------------------------ fermeture

    private fun shutdown() {
        runCatching { ctx.server.stop() }
        Thread { Thread.sleep(4000); exitProcess(0) }.apply { isDaemon = true }.start()
        cefApp.dispose()
        dispose()
    }
}
