package kbrowser

import java.io.File

class AppPaths {
    private val home = File(System.getProperty("user.home"))
    val root = File(home, ".kbrowser").apply { mkdirs() }
    val cache = File(root, "cache").apply { mkdirs() }
    val jcef = File(root, "jcef-bundle")
    val workspace = File(root, "workspace").apply { mkdirs() }
    val extensions = File(root, "extensions").apply { mkdirs() }
    val tls = File(root, "tls").apply { mkdirs() }
    val downloads: File = File(home, "Downloads").takeIf { it.isDirectory }
        ?: File(root, "downloads").apply { mkdirs() }
}
