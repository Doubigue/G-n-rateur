package kbrowser

/** Visualiseur de code source coloré (Python, Kotlin, Java, Dart/Flutter, JS/JSX/TSX, CSS…). */
object SourceViewer {
    val LANGS: Map<String, String> = mapOf(
        "py" to "python", "pyw" to "python",
        "kt" to "kotlin", "kts" to "kotlin", "gradle" to "kotlin",
        "java" to "java",
        "dart" to "dart",
        "js" to "js", "mjs" to "js", "cjs" to "js", "jsx" to "js", "ts" to "js", "tsx" to "js", "vue" to "js",
        "css" to "css", "scss" to "css", "less" to "css",
        "json" to "json", "yaml" to "yaml", "yml" to "yaml", "toml" to "toml", "sh" to "sh",
        "xml" to "xml", "md" to "md", "txt" to "text", "properties" to "text", "ini" to "text"
    )

    private val template: String by lazy {
        SourceViewer::class.java.getResourceAsStream("/viewer.html")!!.readBytes().toString(Charsets.UTF_8)
    }

    fun render(fileName: String, lang: String, code: String): String =
        template
            .replace("__TITLE__", esc(fileName))
            .replace("__LANG__", lang)
            .replace("__CODE__", esc(code)) // en dernier : le code ne doit jamais être re-substitué
}
