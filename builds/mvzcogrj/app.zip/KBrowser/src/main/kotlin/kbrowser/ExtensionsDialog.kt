package kbrowser

import java.awt.BorderLayout
import java.awt.Component
import java.awt.Dimension
import java.awt.FlowLayout
import java.awt.Frame
import javax.swing.BorderFactory
import javax.swing.DefaultListCellRenderer
import javax.swing.DefaultListModel
import javax.swing.JButton
import javax.swing.JDialog
import javax.swing.JLabel
import javax.swing.JList
import javax.swing.JOptionPane
import javax.swing.JPanel
import javax.swing.JScrollPane

class ExtensionsDialog(
    owner: Frame,
    private val ctx: AppContext,
    private val openTab: (String) -> Unit
) : JDialog(owner, "Extensions", true) {

    private val model = DefaultListModel<ChromeExtension>()
    private val list = JList(model)

    init {
        reloadModel()
        list.cellRenderer = object : DefaultListCellRenderer() {
            override fun getListCellRendererComponent(
                l: JList<*>, value: Any?, index: Int, isSelected: Boolean, cellHasFocus: Boolean
            ): Component {
                val e = value as ChromeExtension
                val text = (if (e.enabled) "✔ " else "✖ ") + "${e.name}  v${e.version}  — ${e.contentScripts.size} script(s) de contenu"
                return super.getListCellRendererComponent(l, text, index, isSelected, cellHasFocus)
            }
        }

        val buttons = JPanel(FlowLayout(FlowLayout.LEFT)).apply {
            add(JButton("Activer / Désactiver").apply { addActionListener { toggle() } })
            add(JButton("Options").apply { addActionListener { open { it.optionsPage } } })
            add(JButton("Popup").apply { addActionListener { open { it.popupPage } } })
            add(JButton("Supprimer").apply { addActionListener { remove() } })
            add(JButton("Fermer").apply { addActionListener { dispose() } })
        }
        val note = JLabel(
            "<html><small>Pris en charge : scripts de contenu, CSS, pages options/popup, chrome.storage/runtime (mini-shim).<br>" +
                "Non pris en charge : service workers, webRequest, bloqueurs de pub, chrome.tabs…</small></html>"
        ).apply { border = BorderFactory.createEmptyBorder(6, 8, 0, 8) }

        contentPane.layout = BorderLayout()
        contentPane.add(note, BorderLayout.NORTH)
        contentPane.add(JScrollPane(list), BorderLayout.CENTER)
        contentPane.add(buttons, BorderLayout.SOUTH)
        preferredSize = Dimension(640, 380)
        pack()
        setLocationRelativeTo(owner)
    }

    private fun reloadModel() {
        model.clear()
        ctx.extensions.all.forEach { model.addElement(it) }
    }

    private fun toggle() {
        val e = list.selectedValue ?: return
        e.enabled = !e.enabled
        list.repaint()
    }

    private fun remove() {
        val e = list.selectedValue ?: return
        val ok = JOptionPane.showConfirmDialog(this, "Supprimer « ${e.name} » ?", "Extensions", JOptionPane.YES_NO_OPTION)
        if (ok == JOptionPane.YES_OPTION) {
            ctx.extensions.remove(e)
            reloadModel()
        }
    }

    private fun open(page: (ChromeExtension) -> String?) {
        val e = list.selectedValue ?: return
        val p = page(e)
        if (p == null) {
            JOptionPane.showMessageDialog(this, "Cette extension ne déclare pas cette page.")
            return
        }
        openTab(ctx.server.urlFor(e.mountKey, p))
        dispose()
    }
}
