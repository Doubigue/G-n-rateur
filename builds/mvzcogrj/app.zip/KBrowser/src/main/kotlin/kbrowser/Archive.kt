package kbrowser

import net.sf.sevenzipjbinding.ExtractOperationResult
import net.sf.sevenzipjbinding.ISequentialOutStream
import net.sf.sevenzipjbinding.PropID
import net.sf.sevenzipjbinding.SevenZip
import net.sf.sevenzipjbinding.impl.RandomAccessFileInStream
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.util.zip.ZipFile

/** Décompression zip / rar (RAR4 et RAR5) / 7z / tar, avec protection contre le « zip-slip ». */
object Archive {
    private val EXTENSIONS = listOf(".zip", ".rar", ".7z", ".tar")

    fun isArchive(f: File): Boolean = EXTENSIONS.any { f.name.lowercase().endsWith(it) }

    fun extract(archive: File, dest: File) {
        dest.mkdirs()
        if (archive.name.lowercase().endsWith(".zip")) {
            try {
                extractZip(archive, dest)
                return
            } catch (_: Exception) {
                // zip exotique (chiffrement, noms non UTF-8…) : on retente avec 7-Zip
            }
        }
        extractWith7z(archive, dest)
    }

    private fun extractZip(archive: File, dest: File) {
        ZipFile(archive).use { zip ->
            val entries = zip.entries()
            while (entries.hasMoreElements()) {
                val e = entries.nextElement()
                val out = safeResolve(dest, e.name)
                if (e.isDirectory) {
                    out.mkdirs()
                    continue
                }
                out.parentFile.mkdirs()
                zip.getInputStream(e).use { input -> out.outputStream().use { input.copyTo(it) } }
            }
        }
    }

    private var sevenZipReady = false

    @Synchronized
    private fun initSevenZip() {
        if (!sevenZipReady) {
            SevenZip.initSevenZipFromPlatformJAR()
            sevenZipReady = true
        }
    }

    private fun extractWith7z(archive: File, dest: File) {
        initSevenZip()
        RandomAccessFile(archive, "r").use { raf ->
            val inArchive = SevenZip.openInArchive(null, RandomAccessFileInStream(raf))
            try {
                for (i in 0 until inArchive.numberOfItems) {
                    val rel = inArchive.getProperty(i, PropID.PATH) as? String ?: continue
                    val isFolder = inArchive.getProperty(i, PropID.IS_FOLDER) as? Boolean ?: false
                    val target = safeResolve(dest, rel)
                    if (isFolder) {
                        target.mkdirs()
                        continue
                    }
                    target.parentFile.mkdirs()
                    target.outputStream().use { out ->
                        val result = inArchive.extractSlow(i, ISequentialOutStream { data ->
                            out.write(data)
                            data.size
                        })
                        if (result != ExtractOperationResult.OK) {
                            throw IOException("Extraction impossible pour « $rel » ($result)")
                        }
                    }
                }
            } finally {
                inArchive.close()
            }
        }
    }

    private fun safeResolve(dest: File, rel: String): File {
        val base = dest.canonicalFile
        val out = File(base, rel.replace('\\', '/')).canonicalFile
        if (out.path != base.path && !out.path.startsWith(base.path + File.separator)) {
            throw SecurityException("Chemin dangereux dans l'archive : $rel")
        }
        return out
    }
}
