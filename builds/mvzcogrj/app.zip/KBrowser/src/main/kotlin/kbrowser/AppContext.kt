package kbrowser

import java.io.File

class AppContext(
    val paths: AppPaths,
    val server: LocalServer,
    val extensions: ExtensionManager,
    val downloads: DownloadManager
) {
    /** Retourne l'URL https://localhost/... qui sert le dossier, l'archive ou le fichier donné. */
    fun localUrlFor(input: File): String {
        val f = input.canonicalFile
        return when {
            f.isDirectory ->
                server.urlFor(server.mountDir(f.name.ifEmpty { "racine" }, f))

            Archive.isArchive(f) -> {
                val dest = uniqueDir(f.nameWithoutExtension)
                Archive.extract(f, dest)
                val kids = dest.listFiles().orEmpty()
                // Beaucoup d'archives contiennent un unique dossier racine : on le sert directement
                val root = if (kids.size == 1 && kids[0].isDirectory) kids[0] else dest
                server.urlFor(server.mountDir(f.nameWithoutExtension, root))
            }

            else -> {
                val parent = f.parentFile
                server.urlFor(server.mountDir(parent.name.ifEmpty { "racine" }, parent), f.name)
            }
        }
    }

    private fun uniqueDir(base: String): File {
        val clean = base.replace(Regex("[^A-Za-z0-9._-]+"), "_").ifEmpty { "archive" }
        var d = File(paths.workspace, clean)
        var i = 2
        while (d.exists()) d = File(paths.workspace, "${clean}_${i++}")
        return d
    }
}
