package kbrowser

import org.cef.browser.CefBrowser
import org.cef.callback.CefBeforeDownloadCallback
import org.cef.callback.CefDownloadItem
import org.cef.callback.CefDownloadItemCallback
import org.cef.handler.CefDownloadHandler
import java.io.File
import java.util.concurrent.ConcurrentHashMap

/** Reçoit tous les téléchargements (lien partagé, clic sur un fichier, startDownload). */
class DownloadManager(private val paths: AppPaths) : CefDownloadHandler {
    var onStatus: ((String) -> Unit)? = null
    var onCompleted: ((File) -> Unit)? = null
    private val finished = ConcurrentHashMap.newKeySet<Int>()

    override fun onBeforeDownload(
        browser: CefBrowser,
        item: CefDownloadItem,
        suggestedName: String,
        callback: CefBeforeDownloadCallback
    ) {
        val clean = suggestedName.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifEmpty { "telechargement" }
        val target = unique(File(paths.downloads, clean))
        callback.Continue(target.absolutePath, false)
        onStatus?.invoke("⬇ Téléchargement : ${target.name}")
    }

    override fun onDownloadUpdated(browser: CefBrowser, item: CefDownloadItem, callback: CefDownloadItemCallback) {
        when {
            item.isCanceled -> onStatus?.invoke("Téléchargement annulé")
            item.isComplete -> if (finished.add(item.id)) {
                val f = File(item.fullPath)
                onStatus?.invoke("✔ Téléchargé : ${f.absolutePath}")
                onCompleted?.invoke(f)
            }
            else -> {
                val pct = item.percentComplete
                val name = File(item.fullPath ?: "").name
                onStatus?.invoke("⬇ $name — " + (if (pct >= 0) "$pct %" else "en cours…"))
            }
        }
    }

    private fun unique(f: File): File {
        if (!f.exists()) return f
        val base = f.nameWithoutExtension
        val ext = f.extension.let { if (it.isEmpty()) "" else ".$it" }
        var i = 1
        while (true) {
            val c = File(f.parentFile, "$base ($i)$ext")
            if (!c.exists()) return c
            i++
        }
    }
}
