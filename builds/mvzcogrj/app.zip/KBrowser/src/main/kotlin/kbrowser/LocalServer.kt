package kbrowser

import com.sun.net.httpserver.HttpExchange
import com.sun.net.httpserver.HttpsConfigurator
import com.sun.net.httpserver.HttpsServer
import java.io.File
import java.io.RandomAccessFile
import java.net.BindException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.URLEncoder
import java.nio.file.Files
import java.nio.file.Path
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

internal fun esc(s: String): String =
    s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

internal fun slug(s: String): String =
    s.lowercase().replace(Regex("[^a-z0-9._-]+"), "-").trim('-').ifEmpty { "site" }

private const val MAX_VIEW = 2_000_000L

/**
 * Serveur HTTPS local (127.0.0.1) : https://localhost:PORT/<montage>/chemin
 * Chaque dossier / archive extraite / extension est un « montage ».
 */
class LocalServer(private val paths: AppPaths) {
    private val mounts = ConcurrentHashMap<String, Path>()
    private val headInjections = ConcurrentHashMap<String, String>()
    private lateinit var server: HttpsServer

    var port: Int = 0
        private set
    val baseUrl: String get() = "https://localhost:$port"

    private val mime = mapOf(
        "html" to "text/html; charset=utf-8", "htm" to "text/html; charset=utf-8",
        "css" to "text/css; charset=utf-8",
        "js" to "text/javascript; charset=utf-8", "mjs" to "text/javascript; charset=utf-8",
        "cjs" to "text/javascript; charset=utf-8", "jsx" to "text/javascript; charset=utf-8",
        "ts" to "text/javascript; charset=utf-8", "tsx" to "text/javascript; charset=utf-8",
        "json" to "application/json; charset=utf-8", "map" to "application/json; charset=utf-8",
        "webmanifest" to "application/manifest+json", "wasm" to "application/wasm",
        "svg" to "image/svg+xml", "png" to "image/png", "jpg" to "image/jpeg", "jpeg" to "image/jpeg",
        "gif" to "image/gif", "webp" to "image/webp", "ico" to "image/x-icon", "avif" to "image/avif",
        "woff" to "font/woff", "woff2" to "font/woff2", "ttf" to "font/ttf", "otf" to "font/otf",
        "mp4" to "video/mp4", "webm" to "video/webm", "mp3" to "audio/mpeg", "ogg" to "audio/ogg",
        "wav" to "audio/wav", "pdf" to "application/pdf", "zip" to "application/zip",
        "xml" to "application/xml; charset=utf-8", "txt" to "text/plain; charset=utf-8"
    )

    fun start() {
        val ssl = SelfSignedCert.sslContext(paths.tls)
        val addr = InetAddress.getByName("127.0.0.1")
        server = try {
            HttpsServer.create(InetSocketAddress(addr, 8443), 0)
        } catch (_: BindException) {
            HttpsServer.create(InetSocketAddress(addr, 0), 0)
        }
        server.httpsConfigurator = HttpsConfigurator(ssl)
        server.createContext("/") { handle(it) }
        server.executor = Executors.newFixedThreadPool(8) { r -> Thread(r, "kb-https").apply { isDaemon = true } }
        server.start()
        port = server.address.port
    }

    fun stop() = server.stop(0)

    // ---------- montages ----------

    @Synchronized
    fun mountDir(preferred: String, dir: File): String {
        val path = dir.toPath().toAbsolutePath().normalize()
        mounts.entries.firstOrNull { it.value == path && !it.key.startsWith("ext-") }?.let { return it.key }
        var base = slug(preferred)
        if (base.startsWith("ext-")) base = "site-$base"
        var key = base
        var i = 2
        while (mounts.containsKey(key)) key = "$base-${i++}"
        mounts[key] = path
        return key
    }

    fun mountFixed(key: String, dir: File) {
        mounts[key] = dir.toPath().toAbsolutePath().normalize()
    }

    fun unmount(key: String) {
        mounts.remove(key)
        headInjections.remove(key)
    }

    fun clearSites() {
        mounts.keys.filter { !it.startsWith("ext-") }.forEach { mounts.remove(it) }
    }

    /** Injecte un fragment HTML (ex. <script>) dans toutes les pages .html d'un montage. */
    fun injectIntoHtml(mountKey: String, snippet: String) {
        headInjections[mountKey] = snippet
    }

    fun urlFor(key: String, rel: String = ""): String {
        val tail = rel.split('/').filter { it.isNotEmpty() }.joinToString("/") { urlEnc(it) }
        return "$baseUrl/$key/$tail"
    }

    private fun urlEnc(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20")

    // ---------- requêtes ----------

    private fun handle(ex: HttpExchange) {
        try {
            val host = ex.requestHeaders.getFirst("Host")?.substringBefore(':')
            if (host != "localhost" && host != "127.0.0.1") return sendText(ex, 403, "Hôte refusé")
            if (ex.requestHeaders.getFirst("Sec-Fetch-Site") == "cross-site") return sendText(ex, 403, "Requête cross-site refusée")
            if (ex.requestMethod != "GET" && ex.requestMethod != "HEAD") return sendText(ex, 405, "Méthode non autorisée")

            val path = ex.requestURI.path ?: "/"
            if (path == "/") return sendHtml(ex, 200, indexPage())

            val segs = path.removePrefix("/").split("/", limit = 2)
            val mountKey = segs[0]
            val root = mounts[mountKey] ?: return sendText(ex, 404, "Montage introuvable")
            val target = root.resolve(segs.getOrElse(1) { "" }).normalize()
            if (!target.startsWith(root)) return sendText(ex, 403, "Accès refusé")

            when {
                Files.isDirectory(target) -> {
                    if (!path.endsWith("/")) {
                        ex.responseHeaders.set("Location", (ex.requestURI.rawPath ?: path) + "/")
                        ex.sendResponseHeaders(301, -1L)
                        return
                    }
                    val index = target.resolve("index.html")
                    if (Files.isRegularFile(index)) serveFile(ex, mountKey, index)
                    else sendHtml(ex, 200, listing(mountKey, root, target))
                }
                Files.isRegularFile(target) -> serveFile(ex, mountKey, target)
                else -> sendText(ex, 404, "Fichier introuvable")
            }
        } catch (e: Exception) {
            try { sendText(ex, 500, "Erreur : ${e.message}") } catch (_: Exception) {}
        } finally {
            ex.close()
        }
    }

    private fun serveFile(ex: HttpExchange, mountKey: String, file: Path) {
        val name = file.fileName.toString()
        val ext = name.substringAfterLast('.', "").lowercase()
        val params = (ex.requestURI.rawQuery ?: "").split('&').map { it.substringBefore('=') }
        val dest = ex.requestHeaders.getFirst("Sec-Fetch-Dest") ?: ""
        val size = Files.size(file)
        val lang = SourceViewer.LANGS[ext]

        // Navigation directe vers un fichier source -> visualiseur. Un <script src> reçoit le vrai fichier.
        val wantsViewer = "raw" !in params && size <= MAX_VIEW &&
            ((lang != null && dest == "document") ||
                ("src" in params && (lang != null || ext == "html" || ext == "htm")))
        if (wantsViewer) {
            val text = String(Files.readAllBytes(file), Charsets.UTF_8)
            return sendHtml(ex, 200, SourceViewer.render(name, lang ?: "xml", text))
        }

        val contentType = mime[ext]
            ?: if (lang != null) "text/plain; charset=utf-8" else "application/octet-stream"

        val inject = headInjections[mountKey]
        if (inject != null && (ext == "html" || ext == "htm")) {
            val text = String(Files.readAllBytes(file), Charsets.UTF_8)
            val m = Regex("<head[^>]*>", RegexOption.IGNORE_CASE).find(text)
            val out = if (m != null) text.substring(0, m.range.last + 1) + inject + text.substring(m.range.last + 1)
            else inject + text
            return send(ex, 200, contentType, out.toByteArray(Charsets.UTF_8))
        }

        var start = 0L
        var end = size - 1
        var status = 200
        val range = ex.requestHeaders.getFirst("Range")
        if (range != null && range.startsWith("bytes=")) {
            val parts = range.removePrefix("bytes=").substringBefore(',').split('-')
            val s = parts[0].toLongOrNull()
            val e = parts.getOrNull(1)?.toLongOrNull()
            if (s != null) {
                start = s
                if (e != null) end = minOf(e, size - 1)
            } else if (e != null) {
                start = maxOf(0L, size - e)
            }
            if (start > end || start >= size) {
                ex.responseHeaders.set("Content-Range", "bytes */$size")
                ex.sendResponseHeaders(416, -1L)
                return
            }
            status = 206
            ex.responseHeaders.set("Content-Range", "bytes $start-$end/$size")
        }
        ex.responseHeaders.set("Content-Type", contentType)
        ex.responseHeaders.set("Accept-Ranges", "bytes")
        ex.responseHeaders.set("Cache-Control", "no-cache")
        val len = end - start + 1
        if (ex.requestMethod == "HEAD" || len <= 0) {
            ex.sendResponseHeaders(status, -1L)
            return
        }
        ex.sendResponseHeaders(status, len)
        RandomAccessFile(file.toFile(), "r").use { raf ->
            raf.seek(start)
            val buf = ByteArray(64 * 1024)
            var remaining = len
            while (remaining > 0) {
                val n = raf.read(buf, 0, minOf(buf.size.toLong(), remaining).toInt())
                if (n < 0) break
                ex.responseBody.write(buf, 0, n)
                remaining -= n
            }
        }
    }

    // ---------- réponses ----------

    private fun send(ex: HttpExchange, status: Int, type: String, body: ByteArray) {
        ex.responseHeaders.set("Content-Type", type)
        ex.responseHeaders.set("Cache-Control", "no-cache")
        if (ex.requestMethod == "HEAD" || body.isEmpty()) {
            ex.sendResponseHeaders(status, -1L)
            return
        }
        ex.sendResponseHeaders(status, body.size.toLong())
        ex.responseBody.write(body)
    }

    private fun sendHtml(ex: HttpExchange, status: Int, html: String) =
        send(ex, status, "text/html; charset=utf-8", html.toByteArray(Charsets.UTF_8))

    private fun sendText(ex: HttpExchange, status: Int, text: String) =
        send(ex, status, "text/plain; charset=utf-8", text.toByteArray(Charsets.UTF_8))

    // ---------- pages générées ----------

    private fun page(title: String, body: String) = """<!doctype html><html lang="fr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)}</title>
<style>
:root{color-scheme:light dark;--bg:#fff;--fg:#1f2328;--mut:#6e7781;--link:#0969da}
@media (prefers-color-scheme:dark){:root{--bg:#0d1117;--fg:#e6edf3;--mut:#8b949e;--link:#58a6ff}}
body{margin:0;padding:24px;max-width:860px;margin-inline:auto;background:var(--bg);color:var(--fg);font:16px/1.6 system-ui,sans-serif}
a{color:var(--link);text-decoration:none}a:hover{text-decoration:underline}
li{margin:4px 0;list-style:none}ul{padding:0}small{color:var(--mut)}h1{font-size:1.4rem}
</style></head><body>$body</body></html>"""

    private fun indexPage(): String {
        val items = mounts.keys.filter { !it.startsWith("ext-") }.sorted().joinToString("") {
            "<li><a href=\"/$it/\">📁 ${esc(it)}</a> <small>${esc(mounts[it].toString())}</small></li>"
        }
        val sites = if (items.isEmpty()) "<p><i>Aucun pour le moment.</i></p>" else "<ul>$items</ul>"
        return page(
            "KBrowser",
            "<h1>KBrowser</h1><p>Utilisez <b>Fichier ▸ Ouvrir…</b> (dossier, archive .zip / .rar / .7z, fichier source) " +
                "ou glissez-déposez un élément dans la fenêtre. Collez un lien de téléchargement dans la barre d'adresse " +
                "pour le télécharger.</p><h2>Sites locaux</h2>$sites"
        )
    }

    private fun listing(mountKey: String, root: Path, dir: Path): String {
        val rel = root.relativize(dir).toString().replace('\\', '/')
        val title = "/$mountKey/" + (if (rel.isEmpty()) "" else "$rel/")
        val rows = StringBuilder()
        if (dir != root) rows.append("<li><a href=\"../\">⬆ ..</a></li>")
        Files.list(dir).use { stream ->
            stream.sorted(compareBy<Path>({ !Files.isDirectory(it) }, { it.fileName.toString().lowercase() }))
                .forEach { p ->
                    val n = p.fileName.toString()
                    val isDir = Files.isDirectory(p)
                    rows.append("<li><a href=\"${urlEnc(n)}${if (isDir) "/" else ""}\">${if (isDir) "📁" else "📄"} ${esc(n)}</a></li>")
                }
        }
        return page(title, "<h1>${esc(title)}</h1><ul>$rows</ul>")
    }
}
