package kbrowser

import me.friwi.jcefmaven.CefAppBuilder
import me.friwi.jcefmaven.MavenCefAppHandlerAdapter
import org.cef.CefApp.CefAppState
import java.awt.BorderLayout
import javax.swing.BorderFactory
import javax.swing.JComponent
import javax.swing.JFrame
import javax.swing.JLabel
import javax.swing.JOptionPane
import javax.swing.JProgressBar
import javax.swing.SwingUtilities
import kotlin.system.exitProcess

private class Splash {
    private val label = JLabel("Initialisation du moteur Chromium…")
    private val bar = JProgressBar().apply { isIndeterminate = true }
    private val frame = JFrame("KBrowser").apply {
        defaultCloseOperation = JFrame.DO_NOTHING_ON_CLOSE
        layout = BorderLayout(8, 8)
        add(label, BorderLayout.NORTH)
        add(bar, BorderLayout.CENTER)
        (contentPane as JComponent).border = BorderFactory.createEmptyBorder(16, 20, 16, 20)
        setSize(440, 120)
        setLocationRelativeTo(null)
    }

    fun show() = SwingUtilities.invokeLater { frame.isVisible = true }

    fun update(text: String, percent: Float) = SwingUtilities.invokeLater {
        label.text = text
        if (percent in 0f..100f) {
            bar.isIndeterminate = false
            bar.value = percent.toInt()
        } else {
            bar.isIndeterminate = true
        }
    }

    fun close() = SwingUtilities.invokeLater { frame.dispose() }
}

fun main(args: Array<String>) {
    val paths = AppPaths()
    val splash = Splash()
    splash.show()
    try {
        val server = LocalServer(paths).also { it.start() }
        val ctx = AppContext(paths, server, ExtensionManager(paths, server), DownloadManager(paths))

        val builder = CefAppBuilder()
        builder.setInstallDir(paths.jcef)
        builder.cefSettings.cache_path = paths.cache.absolutePath
        builder.cefSettings.windowless_rendering_enabled = false
        builder.cefSettings.locale = "fr"
        builder.addJcefArgs("--allow-insecure-localhost")
        // Premier lancement : télécharge le moteur Chromium (~100 Mo) puis le met en cache
        builder.setProgressHandler { state, percent ->
            splash.update("Chromium : ${state.name.lowercase()}", percent)
        }
        builder.setAppHandler(object : MavenCefAppHandlerAdapter() {
            override fun stateHasChanged(state: CefAppState) {
                if (state == CefAppState.TERMINATED) exitProcess(0)
            }
        })
        val cefApp = builder.build()

        SwingUtilities.invokeLater {
            splash.close()
            BrowserWindow(cefApp, ctx).apply {
                isVisible = true
                start(args.firstOrNull())
            }
        }
    } catch (e: Throwable) {
        e.printStackTrace()
        splash.close()
        JOptionPane.showMessageDialog(
            null, "Impossible de démarrer KBrowser :\n${e.message ?: e}", "KBrowser", JOptionPane.ERROR_MESSAGE
        )
        exitProcess(1)
    }
}
