package kbrowser

import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.asn1.x509.Extension
import org.bouncycastle.asn1.x509.GeneralName
import org.bouncycastle.asn1.x509.GeneralNames
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import java.io.File
import java.math.BigInteger
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.SecureRandom
import java.util.Date
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.SSLContext

/** Certificat auto-signé pour localhost / 127.0.0.1, généré une seule fois puis réutilisé. */
object SelfSignedCert {
    private val PASSWORD = "kbrowser".toCharArray()

    fun sslContext(dir: File): SSLContext {
        val file = File(dir, "localhost.p12")
        val loaded: KeyStore? = if (file.exists()) {
            try {
                KeyStore.getInstance("PKCS12").also { k -> file.inputStream().use { k.load(it, PASSWORD) } }
            } catch (_: Exception) {
                null
            }
        } else null
        val ks: KeyStore = loaded ?: generate().also { k -> file.outputStream().use { k.store(it, PASSWORD) } }
        val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm())
        kmf.init(ks, PASSWORD)
        return SSLContext.getInstance("TLS").apply { init(kmf.keyManagers, null, SecureRandom()) }
    }

    private fun generate(): KeyStore {
        val kp = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }.generateKeyPair()
        val name = X500Name("CN=localhost, O=KBrowser")
        val now = System.currentTimeMillis()
        val builder = JcaX509v3CertificateBuilder(
            name, BigInteger.valueOf(now),
            Date(now - 86_400_000L), Date(now + 3650L * 86_400_000L),
            name, kp.public
        )
        builder.addExtension(
            Extension.subjectAlternativeName, false,
            GeneralNames(
                arrayOf(
                    GeneralName(GeneralName.dNSName, "localhost"),
                    GeneralName(GeneralName.iPAddress, "127.0.0.1")
                )
            )
        )
        val signer = JcaContentSignerBuilder("SHA256withRSA").build(kp.private)
        val cert = JcaX509CertificateConverter().getCertificate(builder.build(signer))
        return KeyStore.getInstance("PKCS12").apply {
            load(null, null)
            setKeyEntry("localhost", kp.private, PASSWORD, arrayOf(cert))
        }
    }
}
