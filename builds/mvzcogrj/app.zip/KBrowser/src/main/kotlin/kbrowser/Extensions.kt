package kbrowser

import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import java.io.File
import java.net.URI
import java.net.http.HttpClient
import java.net.http.HttpRequest
import java.net.http.HttpResponse
import java.nio.file.Files
import java.util.concurrent.CopyOnWriteArrayList

// ---------- helpers JSON ----------

internal fun JsonObject.str(key: String): String? = get(key)?.takeIf { it.isJsonPrimitive }?.asString
internal fun JsonObject.obj(key: String): JsonObject? = get(key)?.takeIf { it.isJsonObject }?.asJsonObject
internal fun JsonObject.list(key: String): List<JsonElement> =
    get(key)?.takeIf { it.isJsonArray }?.asJsonArray?.toList() ?: emptyList()
internal fun JsonObject.strings(key: String): List<String> =
    list(key).filter { it.isJsonPrimitive }.map { it.asString }

internal fun parseManifest(f: File): JsonObject =
    JsonParser.parseString(f.readText(Charsets.UTF_8).removePrefix("\uFEFF")).asJsonObject

/** Résout les noms localisés « __MSG_appName__ » via _locales/<langue>/messages.json. */
internal fun localize(dir: File, manifest: JsonObject, raw: String): String {
    val m = Regex("^__MSG_(.+)__$").matchEntire(raw) ?: return raw
    val key = m.groupValues[1]
    for (loc in listOfNotNull(manifest.str("default_locale"), "en", "en_US", "fr")) {
        val f = File(dir, "_locales/$loc/messages.json")
        if (!f.isFile) continue
        try {
            val o = JsonParser.parseString(f.readText(Charsets.UTF_8).removePrefix("\uFEFF")).asJsonObject
            val msg = o.entrySet().firstOrNull { it.key.equals(key, ignoreCase = true) }
                ?.value?.asJsonObject?.get("message")?.asString
            if (msg != null) return msg
        } catch (_: Exception) {
        }
    }
    return key
}

// ---------- modèle ----------

class ContentScript(
    val matches: List<String>,
    val exclude: List<String>,
    val js: List<String>,
    val css: List<String>,
    val runAt: String,
    val allFrames: Boolean
)

class ChromeExtension(val id: String, val dir: File, val manifest: JsonObject) {
    val name: String = localize(dir, manifest, manifest.str("name") ?: id)
    val version: String = manifest.str("version") ?: "?"
    val mountKey: String get() = "ext-$id"

    var enabled: Boolean
        get() = !File(dir, ".kb_disabled").exists()
        set(v) {
            val f = File(dir, ".kb_disabled")
            if (v) f.delete() else f.createNewFile()
        }

    val contentScripts: List<ContentScript> = manifest.list("content_scripts")
        .filter { it.isJsonObject }
        .map { it.asJsonObject }
        .map { o ->
            ContentScript(
                o.strings("matches"), o.strings("exclude_matches"),
                o.strings("js"), o.strings("css"),
                o.str("run_at") ?: "document_idle",
                o.get("all_frames")?.takeIf { it.isJsonPrimitive }?.asBoolean ?: false
            )
        }

    val popupPage: String? = (manifest.obj("action") ?: manifest.obj("browser_action"))?.str("default_popup")
    val optionsPage: String? = manifest.str("options_page") ?: manifest.obj("options_ui")?.str("page")

    fun read(rel: String): String? {
        val f = File(dir, rel).canonicalFile
        val ok = f.path.startsWith(dir.canonicalPath + File.separator) && f.isFile
        return if (ok) f.readText(Charsets.UTF_8) else null
    }
}

// ---------- patterns d'URL (<all_urls>, *://*.exemple.com/*, ...) ----------

object MatchPattern {
    private val parts = Regex("^(\\*|https?|file|ftp)://([^/]*)(/.*)$")

    fun matches(pattern: String, url: String): Boolean {
        val uri = try { URI(url) } catch (_: Exception) { return false }
        val us = uri.scheme ?: return false
        if (pattern == "<all_urls>") return us == "http" || us == "https" || us == "file"
        val m = parts.matchEntire(pattern) ?: return false
        val (scheme, host, path) = m.destructured
        if (scheme == "*") {
            if (us != "http" && us != "https") return false
        } else if (scheme != us) return false

        if (scheme != "file" && host != "*") {
            val uh = uri.host ?: return false
            if (host.startsWith("*.")) {
                val base = host.substring(2)
                if (uh != base && !uh.endsWith(".$base")) return false
            } else if (host != uh) return false
        }
        val target = (uri.rawPath?.ifEmpty { "/" } ?: "/") + (uri.rawQuery?.let { "?$it" } ?: "")
        return Regex(path.split("*").joinToString(".*") { Regex.escape(it) }).matches(target)
    }
}

// ---------- shim chrome.* minimal ----------

object ChromeShim {
    private const val FACTORY = """
(function(ID, BASE, MANIFEST){
  function wrap(fn){ return function(){
    var a=[].slice.call(arguments);
    var cb=(a.length&&typeof a[a.length-1]==='function')?a.pop():null; var r;
    try{ r=fn.apply(null,a); }catch(e){ if(cb){ setTimeout(function(){cb();},0); return; } return Promise.reject(e); }
    if(cb){ setTimeout(function(){cb(r);},0); return; } return Promise.resolve(r); }; }
  function area(name){
    var key='__kbext_'+ID+'_'+name;
    function load(){ try{ return JSON.parse(localStorage.getItem(key)||'{}'); }catch(e){ return {}; } }
    function save(o){ try{ localStorage.setItem(key, JSON.stringify(o)); }catch(e){} }
    return {
      get: wrap(function(k){ var o=load(); if(k==null) return o; var r={};
        if(typeof k==='string') k=[k];
        if(Array.isArray(k)){ k.forEach(function(x){ if(x in o) r[x]=o[x]; }); }
        else { Object.keys(k).forEach(function(x){ r[x]=(x in o)?o[x]:k[x]; }); }
        return r; }),
      set: wrap(function(items){ var o=load(); Object.keys(items).forEach(function(x){ o[x]=items[x]; }); save(o); }),
      remove: wrap(function(k){ var o=load(); [].concat(k).forEach(function(x){ delete o[x]; }); save(o); }),
      clear: wrap(function(){ save({}); })
    };
  }
  var ev={ addListener:function(){}, removeListener:function(){}, hasListener:function(){ return false; } };
  function url(p){ return BASE+String(p).replace(/^\//,''); }
  return {
    runtime:{ id:ID, getURL:url, getManifest:function(){ return MANIFEST; },
      sendMessage:wrap(function(){}),
      connect:function(){ return { postMessage:function(){}, disconnect:function(){}, onMessage:ev, onDisconnect:ev }; },
      onMessage:ev, onInstalled:ev, onConnect:ev },
    storage:{ local:area('local'), sync:area('sync'), session:area('session'), onChanged:ev },
    i18n:{ getMessage:function(k){ return k; }, getUILanguage:function(){ return navigator.language; } },
    extension:{ getURL:url }
  };
})"""

    fun jsString(s: String): String {
        val sb = StringBuilder("\"")
        for (c in s) {
            when (c) {
                '\\' -> sb.append("\\\\")
                '"' -> sb.append("\\\"")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                '\t' -> sb.append("\\t")
                '<' -> sb.append("\\u003c")
                '\u2028' -> sb.append("\\u2028")
                '\u2029' -> sb.append("\\u2029")
                else -> if (c < ' ') sb.append(String.format("\\u%04x", c.code)) else sb.append(c)
            }
        }
        return sb.append('"').toString()
    }

    private fun factory(ext: ChromeExtension, base: String) =
        "$FACTORY(${jsString(ext.id)}, ${jsString(base)}, JSON.parse(${jsString(ext.manifest.toString())}))"

    /** Code d'un content script : exécuté avec `chrome` / `browser` locaux (pas de pollution globale). */
    fun wrap(ext: ChromeExtension, base: String, code: String): String =
        "(function(){ var __c = ${factory(ext, base)}; (function(chrome, browser){\n$code\n})(__c, __c); })();"

    fun css(ext: ChromeExtension, css: String): String =
        "(function(){ var s=document.createElement('style'); s.setAttribute('data-kbext', ${jsString(ext.id)}); " +
            "s.textContent=${jsString(css)}; (document.head||document.documentElement).appendChild(s); })();"

    /** Pour les pages popup/options de l'extension elle-même : définit window.chrome. */
    fun globalAssign(ext: ChromeExtension, base: String): String =
        "window.chrome = Object.assign(window.chrome || {}, ${factory(ext, base)}); window.browser = window.chrome;"
}

// ---------- gestionnaire ----------

class ExtensionManager(private val paths: AppPaths, private val server: LocalServer) {
    val all = CopyOnWriteArrayList<ChromeExtension>()

    init {
        paths.extensions.listFiles { f -> f.isDirectory }?.sortedBy { it.name }?.forEach { dir ->
            loadDir(dir)?.let { all.add(it) }
        }
    }

    private fun baseOf(ext: ChromeExtension) = "${server.baseUrl}/${ext.mountKey}/"

    private fun loadDir(dir: File): ChromeExtension? {
        val mf = File(dir, "manifest.json")
        if (!mf.isFile) return null
        return try {
            val ext = ChromeExtension(dir.name, dir, parseManifest(mf))
            server.mountFixed(ext.mountKey, dir)
            server.injectIntoHtml(ext.mountKey, "<script>${ChromeShim.globalAssign(ext, baseOf(ext))}</script>")
            ext
        } catch (_: Exception) {
            null
        }
    }

    /** Scripts à injecter dans un frame pour l'étape `runAt` (document_start / document_end / document_idle). */
    fun scriptsFor(url: String, runAt: String, isMainFrame: Boolean): List<String> {
        val out = mutableListOf<String>()
        for (ext in all) {
            if (!ext.enabled) continue
            val css = StringBuilder()
            val js = StringBuilder()
            for (cs in ext.contentScripts) {
                if (cs.runAt != runAt) continue
                if (!isMainFrame && !cs.allFrames) continue
                if (cs.matches.none { MatchPattern.matches(it, url) }) continue
                if (cs.exclude.any { MatchPattern.matches(it, url) }) continue
                cs.css.forEach { p -> ext.read(p)?.let { css.append(it).append('\n') } }
                cs.js.forEach { p -> ext.read(p)?.let { js.append(it).append("\n;\n") } }
            }
            if (css.isNotEmpty()) out.add(ChromeShim.css(ext, css.toString()))
            if (js.isNotEmpty()) out.add(ChromeShim.wrap(ext, baseOf(ext), js.toString()))
        }
        return out
    }

    fun remove(ext: ChromeExtension) {
        server.unmount(ext.mountKey)
        all.remove(ext)
        ext.dir.deleteRecursively()
    }

    // ----- installation -----

    private fun findManifestRoot(dir: File): File? {
        if (File(dir, "manifest.json").isFile) return dir
        return dir.listFiles { f -> f.isDirectory }?.firstOrNull { File(it, "manifest.json").isFile }
    }

    private fun installInto(id: String, root: File): ChromeExtension {
        val dest = File(paths.extensions, id)
        all.removeIf { it.id == id }
        server.unmount("ext-$id")
        if (dest.exists()) dest.deleteRecursively()
        root.copyRecursively(dest, overwrite = true)
        val ext = loadDir(dest) ?: error("Extension invalide (manifest.json illisible)")
        all.add(ext)
        return ext
    }

    /** Dossier d'extension « non empaquetée » (contenant manifest.json). */
    fun installFromDirectory(src: File): ChromeExtension {
        val root = findManifestRoot(src) ?: error("manifest.json introuvable dans ${src.name}")
        val manifest = parseManifest(File(root, "manifest.json"))
        val name = localize(root, manifest, manifest.str("name") ?: root.name)
        val id = slug(name).take(24) + "-" + Integer.toHexString(name.hashCode())
        return installInto(id, root)
    }

    /** Fichier .crx (Chrome) ou .zip. */
    fun installFromPackage(file: File, forcedId: String? = null): ChromeExtension {
        val tmp = Files.createTempDirectory("kbext").toFile()
        try {
            val zip = File(tmp, "pkg.zip")
            zip.writeBytes(crxToZip(file.readBytes()))
            val out = File(tmp, "x")
            Archive.extract(zip, out)
            val root = findManifestRoot(out) ?: error("manifest.json introuvable dans le paquet")
            return if (forcedId != null) installInto(forcedId, root) else installFromDirectory(root)
        } finally {
            tmp.deleteRecursively()
        }
    }

    private fun crxToZip(b: ByteArray): ByteArray {
        if (b.size < 16 || String(b, 0, 4, Charsets.ISO_8859_1) != "Cr24") return b
        fun u32(o: Int) = (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8) or
            ((b[o + 2].toInt() and 0xFF) shl 16) or ((b[o + 3].toInt() and 0xFF) shl 24)
        val start = when (val v = u32(4)) {
            2 -> 16 + u32(8) + u32(12)
            3 -> 12 + u32(8)
            else -> error("Version CRX non supportée : $v")
        }
        return b.copyOfRange(start, b.size)
    }

    /** Chrome Web Store : URL de la fiche ou identifiant de 32 lettres. */
    fun installFromWebStore(input: String): ChromeExtension {
        val id = Regex("[a-p]{32}").find(input)?.value ?: error("Identifiant d'extension introuvable")
        val url = "https://clients2.google.com/service/update2/crx?response=redirect&prodversion=122.0" +
            "&acceptformat=crx2,crx3&x=id%3D$id%26uc"
        val client = HttpClient.newBuilder().followRedirects(HttpClient.Redirect.NORMAL).build()
        val resp = client.send(
            HttpRequest.newBuilder(URI(url)).header("User-Agent", "Mozilla/5.0").build(),
            HttpResponse.BodyHandlers.ofByteArray()
        )
        if (resp.statusCode() != 200 || resp.body().size < 100) {
            error("Téléchargement impossible (HTTP ${resp.statusCode()})")
        }
        val tmp = File.createTempFile("ext", ".crx")
        try {
            tmp.writeBytes(resp.body())
            return installFromPackage(tmp, id)
        } finally {
            tmp.delete()
        }
    }

    // ----- import depuis un Chrome / Edge / Brave déjà installé -----

    fun chromeInstalledExtensions(): List<Pair<String, File>> {
        val home = File(System.getProperty("user.home"))
        val os = System.getProperty("os.name").lowercase()
        val bases: List<File> = when {
            os.contains("win") -> listOfNotNull(System.getenv("LOCALAPPDATA")).flatMap { local ->
                listOf("Google/Chrome/User Data", "Microsoft/Edge/User Data", "BraveSoftware/Brave-Browser/User Data")
                    .map { File(local, it) }
            }
            os.contains("mac") -> listOf("Google/Chrome", "Microsoft Edge", "BraveSoftware/Brave-Browser", "Chromium")
                .map { File(home, "Library/Application Support/$it") }
            else -> listOf(".config/google-chrome", ".config/chromium", ".config/microsoft-edge", ".config/BraveSoftware/Brave-Browser")
                .map { File(home, it) }
        }
        val result = mutableListOf<Pair<String, File>>()
        for (base in bases) {
            File(base, "Default/Extensions").listFiles { f -> f.isDirectory }?.forEach { idDir ->
                val latest = idDir.listFiles { f -> f.isDirectory }?.maxByOrNull { it.name } ?: return@forEach
                if (File(latest, "manifest.json").isFile) result.add(idDir.name to latest)
            }
        }
        return result.distinctBy { it.first }
    }

    fun peek(dir: File): Pair<String, String>? = try {
        val m = parseManifest(File(dir, "manifest.json"))
        localize(dir, m, m.str("name") ?: "?") to (m.str("version") ?: "?")
    } catch (_: Exception) {
        null
    }

    fun installFromChromeDir(id: String, versionDir: File): ChromeExtension = installInto(id, versionDir)
}
