# LocalShare

Partage de fichiers + partage d'écran en local (style Quick Share / AirDrop).

## Mise en route
1. `flutter create --org com.example --project-name localshare .` (génère android/ et ios/)
2. Copiez `lib/` et `pubspec.yaml` de cette archive, puis `flutter pub get`
3. Remplacez `android/app/src/main/AndroidManifest.xml` par `platform_config/AndroidManifest.xml`
4. Dans `android/app/build.gradle(.kts)` : `minSdk = 23`, `compileSdk = 34` (ou plus),
   `applicationId = "com.example.localshare"` (doit correspondre à `_serviceId` dans NearbyService)
5. iOS : fusionnez `platform_config/Info.plist.snippet.xml` dans `ios/Runner/Info.plist`
6. Testez sur **deux appareils physiques** (pas d'émulateur) :
   A -> « Visible », B -> « Scanner » -> touchez l'appareil A.

## Limites connues
- **iOS** : `nearby_connections` est Android-only. Pour iOS, implémentez la même interface
  que `NearbyService` avec MultipeerConnectivity (channel natif) ou Bonjour + sockets TCP.
  Les BYTES/FILE payloads et le protocole JSON (`protocol.dart`) restent identiques.
  Le partage d'écran iOS hors de l'app nécessite une Broadcast Upload Extension (ReplayKit),
  voir la doc de flutter_webrtc.
- **WebRTC** : pas de serveur ICE, les deux appareils doivent être sur le même réseau IP
  (même Wi-Fi ou point d'accès d'un des téléphones). Nearby ne fournit pas de route IP.
- Les fichiers reçus sont rangés dans `Android/data/<appId>/files/Received/`.
- Vérifiez les signatures de `flutter_foreground_task` / `flutter_webrtc` si vous changez de version majeure.
