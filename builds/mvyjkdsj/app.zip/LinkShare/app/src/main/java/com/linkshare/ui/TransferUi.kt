package com.linkshare.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Plein écran : choisir le dossier de destination d'une copie ou d'un déplacement.
 * On entre dans les dossiers en les touchant, la flèche (ou Retour) remonte d'un cran, « Nouveau dossier » en crée un.
 */
@Composable
internal fun FolderPicker(ex: ExplorerViewModel, t: PendingTransfer) {
    var cur by remember { mutableStateOf(ex.root) }
    var refresh by remember { mutableIntStateOf(0) }
    var creating by remember { mutableStateOf(false) }
    val dirs by produceState(emptyList<File>(), cur, refresh) {
        value = withContext(Dispatchers.IO) {
            cur.listFiles().orEmpty()
                .filter { it.isDirectory && !it.name.startsWith(".") }
                .sortedBy { it.name.lowercase() }
        }
    }
    val problem = remember(cur, t) { ex.transferProblem(t, cur) }
    val verb = if (t.move) "Déplacer" else "Copier"
    val atRoot = cur.path == ex.root.path

    fun up() { if (atRoot) ex.cancelTransfer() else cur = cur.parentFile ?: ex.root }
    BackHandler { up() }

    Column(
        // Le pointerInput empêche les touchers de « traverser » vers l'explorateur qui est dessous
        Modifier.fillMaxSize().background(LS.Bg).pointerInput(Unit) { detectTapGestures { } }.systemBarsPadding(),
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ up() }) { Icon(Ic.Back, "Retour", tint = LS.Text) }
            Column(Modifier.weight(1f)) {
                Text(
                    "$verb ${t.files.size} élément(s) vers…", color = LS.Text, fontSize = 18.sp,
                    fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                val crumb = if (atRoot) "Stockage interne" else "/" + runCatching { cur.relativeTo(ex.root).path }.getOrDefault(cur.path)
                Text(crumb, color = LS.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            if (dirs.isEmpty()) item(key = "none") {
                Text(
                    "Aucun sous-dossier ici", Modifier.fillMaxWidth().padding(24.dp),
                    color = LS.Muted, fontSize = 13.sp, textAlign = TextAlign.Center,
                )
            }
            items(dirs, key = { it.path }) { d ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(LS.Card)
                        .clickable { cur = d }.padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Ic.Folder, null, Modifier.size(28.dp), tint = LS.Blue)
                    Spacer(Modifier.width(14.dp))
                    Text(d.name, Modifier.weight(1f), color = LS.Text, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Icon(Ic.Chevron, null, Modifier.size(20.dp), tint = LS.Muted)
                }
            }
        }
        problem?.let {
            Text(it, Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 4.dp), color = Color(0xFFF28B82), fontSize = 12.sp)
        }
        Row(
            Modifier.fillMaxWidth().background(LS.Card2).padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            TextButton({ creating = true }) { Text("Nouveau dossier", color = LS.Blue, fontSize = 13.sp) }
            Spacer(Modifier.weight(1f))
            TextButton({ ex.cancelTransfer() }) { Text("Annuler", color = LS.Blue, fontSize = 13.sp) }
            Button(
                { ex.pasteTo(cur) }, enabled = problem == null,
                colors = ButtonDefaults.buttonColors(containerColor = LS.Blue, contentColor = LS.OnBlue),
            ) { Text("$verb ici", fontSize = 13.sp, maxLines = 1) }
        }
    }

    if (creating) NewFolderDialog(
        onDismiss = { creating = false },
        onCreate = { name ->
            if (ex.createFolder(cur, name)) { creating = false; cur = File(cur, name.trim()) }
        },
    )
}

@Composable
private fun NewFolderDialog(onDismiss: () -> Unit, onCreate: (String) -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nouveau dossier") },
        text = {
            TextField(
                value = name, onValueChange = { name = it }, singleLine = true,
                placeholder = { Text("Nom du dossier") },
            )
        },
        confirmButton = { TextButton({ onCreate(name) }, enabled = name.isNotBlank()) { Text("Créer") } },
        dismissButton = { TextButton({ onDismiss() }) { Text("Annuler") } },
    )
}
