package com.linkshare

import android.app.DownloadManager
import android.content.Intent
import android.os.Bundle
import android.os.Environment
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.material3.*
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import android.app.NotificationManager
import com.linkshare.client.TransferManager
import com.linkshare.client.TransferNotifier
import com.linkshare.ui.AppEvents
import com.linkshare.ui.ExternalOpen
import com.linkshare.ui.LS
import com.linkshare.ui.VaultLock
import com.linkshare.ui.LinkShareApp
import com.linkshare.ui.MainViewModel

private const val ACTION_BROWSE = "android.provider.action.BROWSE"
private val FOLDER_TYPES = setOf("vnd.android.document/directory", "vnd.android.document/root", "resource/folder")

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onStart() {
        super.onStart()
        TransferManager.appVisible = true
        AppEvents.resumeTick += 1
        getSystemService(NotificationManager::class.java).cancel(TransferNotifier.ID)
    }

    override fun onStop() {
        super.onStop()
        TransferManager.appVisible = false
        VaultLock.unlocked = false // le coffre se reverrouille dès que l'app quitte l'écran
    }

    /**
     * Ouverture depuis une autre appli : vidéo, audio, image, texte (y compris en streaming http/https) ou dossier
     * (« Ouvrir avec », « Afficher dans le dossier », Réglages › Stockage › Parcourir, Téléchargements).
     */
    private fun handleIntent(i: Intent?) {
        if (i == null) return
        when (i.action) {
            Intent.ACTION_VIEW, ACTION_BROWSE -> {
                val data = i.data ?: return
                val type = i.type ?: contentResolver.getType(data)
                if (i.action == ACTION_BROWSE || (type != null && type in FOLDER_TYPES)) {
                    ExternalOpen.folder = ExternalOpen.resolveFolder(data)
                } else {
                    ExternalOpen.mime = type
                    ExternalOpen.uri = data
                }
            }
            DownloadManager.ACTION_VIEW_DOWNLOADS ->
                ExternalOpen.folder = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        // Relancée depuis les applis récentes, l'activité reçoit encore l'intent d'origine : on ne rouvre pas le fichier
        val fromHistory = (intent.flags and Intent.FLAG_ACTIVITY_LAUNCHED_FROM_HISTORY) != 0
        if (savedInstanceState == null && !fromHistory) handleIntent(intent)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = LS.Blue, onPrimary = LS.OnBlue,
                    background = LS.Bg, surface = LS.Bg, onSurface = LS.Text, onBackground = LS.Text,
                    surfaceContainer = LS.Card2, surfaceContainerHigh = LS.Card2, surfaceContainerHighest = LS.Card2,
                    surfaceVariant = LS.Card2, onSurfaceVariant = LS.Muted,
                ),
            ) {
                Surface(color = LS.Bg) { LinkShareApp(vm) }
            }
        }
    }
}
