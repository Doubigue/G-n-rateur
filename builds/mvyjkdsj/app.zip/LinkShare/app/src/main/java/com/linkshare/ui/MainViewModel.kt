package com.linkshare.ui

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import android.text.format.Formatter
import androidx.compose.runtime.*
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.linkshare.client.RemoteClient
import com.linkshare.client.TransferManager
import com.linkshare.core.*
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.util.concurrent.atomic.AtomicInteger

data class HistoryItem(val text: String, val up: Boolean, val time: Long)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    var client by mutableStateOf<RemoteClient?>(null); private set
    var deviceName by mutableStateOf("")
    var path by mutableStateOf("")
    var entries by mutableStateOf<List<FileEntry>>(emptyList())
    var apps by mutableStateOf<List<AppEntry>>(emptyList())
    var viewer by mutableStateOf<FileEntry?>(null)
    /** Fichiers du même type que [viewer] dans le dossier affiché : on passe de l'un à l'autre en balayant. */
    var viewerList by mutableStateOf<List<FileEntry>>(emptyList())
    var status by mutableStateOf<String?>(null)
    var message by mutableStateOf<String?>(null)

    /** Filtre de catégorie (Docs, Photos…) choisi à l'accueil ou dans la liste distante. */
    var category by mutableStateOf<Category?>(null)
    /** Chemins cochés dans la liste distante (téléchargement groupé). */
    val selection = mutableStateListOf<String>()
    /** Derniers transferts terminés (affichés sur l'accueil). */
    val history = mutableStateListOf<HistoryItem>()

    private val ctx get() = getApplication<Application>()
    private fun size(n: Long) = Formatter.formatShortFileSize(ctx, n)

    private fun launchSafe(block: suspend () -> Unit) = viewModelScope.launch {
        try { block() }
        catch (e: CancellationException) { throw e }
        catch (e: Exception) { message = e.message ?: e.toString(); status = null }
    }

    /** Les transferts tournent hors de l'écran, protégés par un service au premier plan. */
    private fun transfer(block: suspend () -> Unit) =
        TransferManager.launch(ctx, { message = it.message ?: it.toString(); status = null }, block)

    private fun log(text: String, up: Boolean) {
        history.add(0, HistoryItem(text, up, System.currentTimeMillis()))
        while (history.size > 20) history.removeAt(history.lastIndex)
    }

    private fun progress(text: String) { status = text; TransferManager.label.value = text }

    fun connect(c: Connection) = launchSafe {
        status = "Connexion à ${c.name}…"
        val rc = RemoteClient(c)
        val info = try { rc.info() } catch (e: Exception) { rc.close(); throw e }
        client = rc; deviceName = info.name
        browse("")
        status = null
    }

    fun disconnect() {
        PlayerHost.stop() // un flux venant de l'autre téléphone ne peut plus continuer
        client?.close(); client = null; viewer = null; viewerList = emptyList()
        entries = emptyList(); apps = emptyList(); path = ""
        selection.clear(); category = null
    }

    private suspend fun browse(p: String) {
        val l = client!!.list(p)
        entries = l.entries; path = l.path
        selection.clear()
    }

    fun open(p: String) = launchSafe { browse(p) }
    fun up() { if (path.isNotEmpty()) open(path.substringBeforeLast('/', "")) }

    fun tap(e: FileEntry) {
        if (e.isDir) open(e.path)
        else if (e.isImage() || e.isAv()) {
            viewerList = entries.filter { !it.isDir && sameKind(e, it) }
            viewer = e
        } else download(e)
    }

    /** Images avec images ; vidéos avec vidéos ; audio avec audio. */
    private fun sameKind(a: FileEntry, b: FileEntry) =
        if (a.isImage()) b.isImage() else b.isAv() && a.category() == b.category()

    fun loadApps() = launchSafe { if (apps.isEmpty()) apps = client?.apps().orEmpty() }

    fun download(e: FileEntry) = transfer {
        val c = client ?: return@transfer
        progress("Téléchargement de ${e.name}…")
        val f = if (e.isDir) c.downloadFolder(e.path, e.name) { progress("${e.name} · ${size(it)}") }
        else c.downloadFile(e.path, e.name) { progress("${e.name} · ${size(it)}") }
        status = null; message = "Enregistré : ${f.path}"
        TransferManager.report(true, "${e.name} enregistré dans Download/LinkShare")
        log(e.name, false)
    }

    fun downloadApp(a: AppEntry) = transfer {
        val c = client ?: return@transfer
        progress("Téléchargement de ${a.name}…")
        val f = c.downloadApk(a.pkg, a.split) { progress("${a.name} · ${size(it)}") }
        status = null; message = "Enregistré : ${f.path}"
        TransferManager.report(true, "${a.name} (APK) enregistré dans Download/LinkShare")
        log("${a.name} (APK)", false)
    }

    /** Télécharge toutes les entrées cochées (fichiers et dossiers). */
    fun downloadSelected() {
        val list = entries.filter { it.path in selection }
        selection.clear()
        when {
            list.isEmpty() -> Unit
            list.size == 1 -> download(list[0])
            else -> downloadMany(list)
        }
    }

    private fun downloadMany(list: List<FileEntry>) = transfer {
        val c = client ?: return@transfer
        list.forEachIndexed { i, e ->
            val tag = "${i + 1}/${list.size} · ${e.name}"
            progress("Téléchargement $tag…")
            if (e.isDir) c.downloadFolder(e.path, e.name) { progress("$tag · ${size(it)}") }
            else c.downloadFile(e.path, e.name) { progress("$tag · ${size(it)}") }
        }
        status = null
        message = "${list.size} élément(s) enregistré(s) dans Download/LinkShare"
        TransferManager.report(true, "${list.size} élément(s) enregistré(s) dans Download/LinkShare")
        log("${list.size} éléments téléchargés", false)
    }

    fun uploadFiles(uris: List<Uri>) = transfer { sendAll(uris.map { it to displayName(it) }) }

    fun uploadFolder(tree: Uri) = transfer {
        val root = DocumentFile.fromTreeUri(ctx, tree) ?: return@transfer
        val items = mutableListOf<Pair<Uri, String>>()
        fun walk(d: DocumentFile, prefix: String) {
            d.listFiles().forEach {
                if (it.isDirectory) walk(it, "$prefix${it.name}/") else items += it.uri to "$prefix${it.name}"
            }
        }
        withContext(Dispatchers.IO) { walk(root, "${root.name}/") }
        sendAll(items)
    }

    /** Envoi parallèle (4 flux) : bien plus rapide pour beaucoup de petits fichiers. */
    private suspend fun sendAll(items: List<Pair<Uri, String>>) {
        val c = client ?: return
        if (items.isEmpty()) return
        val sem = Semaphore(4); val done = AtomicInteger(0)
        progress("Envoi 0/${items.size}")
        coroutineScope {
            items.map { (u, n) ->
                async(Dispatchers.IO) {
                    sem.withPermit { c.upload(ctx, u, n); progress("Envoi ${done.incrementAndGet()}/${items.size}") }
                }
            }.awaitAll()
        }
        status = null
        message = "${items.size} fichier(s) envoyé(s) dans Download/LinkShare"
        TransferManager.report(true, "${items.size} fichier(s) envoyé(s) vers $deviceName")
        log("${items.size} fichier(s) envoyé(s) vers $deviceName", true)
    }

    private fun displayName(u: Uri): String =
        ctx.contentResolver.query(u, null, null, null, null)?.use {
            if (it.moveToFirst()) it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
        } ?: "fichier"
}
