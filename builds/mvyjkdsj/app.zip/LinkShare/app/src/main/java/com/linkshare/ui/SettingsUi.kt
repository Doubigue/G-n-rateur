package com.linkshare.ui

import android.text.format.Formatter
import android.widget.Toast
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.DateFormat
import java.util.Date

// ═══════════════════════════ Paramètres de l'explorateur ═══════════════════════════

@Composable
internal fun SettingsScreen(ex: ExplorerViewModel, onBack: () -> Unit, onTrash: () -> Unit) {
    val ctx = LocalContext.current
    val act = ctx.findActivity()
    var mode by remember { mutableStateOf(VaultAuth.mode(ctx)) }
    var fingerprint by remember { mutableStateOf(VaultAuth.fingerprint(ctx)) }
    var options by remember { mutableStateOf(false) }
    var setup by remember { mutableStateOf<VaultMode?>(null) }

    fun applyMode(m: VaultMode, secret: String?) {
        VaultAuth.set(ctx, m, secret)
        mode = m; fingerprint = VaultAuth.fingerprint(ctx)
        setup = null; options = false
        Toast.makeText(ctx, "Verrouillage du coffre : ${m.label.lowercase()}", Toast.LENGTH_SHORT).show()
    }

    LaunchedEffect(Unit) { ex.loadTrash() }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Ic.Back, "Retour", tint = LS.Text) }
            Text("Paramètres", color = LS.Text, fontSize = 20.sp, fontWeight = FontWeight.Medium)
        }
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item { SettingsHeading("Sécurité") }
            item {
                SettingsRow(
                    Ic.Lock, "Verrouillage du coffre", mode.label,
                ) {
                    // Pour ouvrir ce réglage : empreinte (ou code) du verrouillage d'écran du téléphone
                    if (act != null) authenticateWithPhoneLock(
                        act, "Verrouillage du coffre", "Confirme avec le verrouillage de ton téléphone",
                    ) { options = true }
                }
            }
            item { SettingsHeading("Fichiers") }
            item {
                val sub = if (ex.trashCount == 0) "Vide" else "${ex.trashCount} élément(s) · vidée après $TRASH_DAYS jours"
                SettingsRow(Ic.Delete, "Corbeille", sub, onTrash)
            }
        }
    }

    // ── Choix de la méthode (accessible seulement après la confirmation du téléphone)
    if (options) AlertDialog(
        onDismissRequest = { options = false },
        title = { Text("Verrouillage du coffre") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                VaultMode.values().forEach { m ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable {
                            when (m) {
                                VaultMode.PHONE -> applyMode(VaultMode.PHONE, null)
                                else -> setup = m
                            }
                        }.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(mode == m, onClick = null)
                        Spacer(Modifier.width(10.dp))
                        Text(m.label, color = LS.Text, fontSize = 15.sp)
                    }
                }
                if (mode != VaultMode.PHONE) {
                    HorizontalDivider(Modifier.padding(vertical = 8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Ouvrir aussi avec l'empreinte", color = LS.Text, fontSize = 15.sp)
                            Text(
                                if (fingerprintAvailable(ctx)) "Utilise les empreintes enregistrées dans le téléphone : Android ne permet pas d'en enregistrer une propre à l'appli."
                                else "Aucune empreinte enregistrée sur le téléphone.",
                                color = LS.Muted, fontSize = 11.sp,
                            )
                        }
                        Switch(
                            fingerprint, enabled = fingerprintAvailable(ctx),
                            onCheckedChange = { fingerprint = it; VaultAuth.setFingerprint(ctx, it) },
                        )
                    }
                }
            }
        },
        confirmButton = { TextButton({ options = false }) { Text("Fermer") } },
    )

    when (setup) {
        VaultMode.PATTERN -> PatternSetupDialog({ setup = null }) { applyMode(VaultMode.PATTERN, it) }
        VaultMode.PIN -> PinSetupDialog({ setup = null }) { applyMode(VaultMode.PIN, it) }
        else -> {}
    }
}

@Composable
private fun SettingsHeading(title: String) {
    Text(title, Modifier.padding(top = 8.dp, start = 4.dp), color = LS.Blue, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
}

@Composable
private fun SettingsRow(icon: ImageVector, title: String, sub: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(LS.Card).clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(42.dp).clip(CircleShape).background(LS.Card2), contentAlignment = Alignment.Center) {
            Icon(icon, null, Modifier.size(22.dp), tint = LS.Blue)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = LS.Text, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Text(sub, color = LS.Muted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        Icon(Ic.Chevron, null, Modifier.size(22.dp), tint = LS.Muted)
    }
}

// ═══════════════════════════ Corbeille ═══════════════════════════

@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun TrashScreen(ex: ExplorerViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val sel = remember { mutableStateListOf<String>() }
    var confirmEmpty by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { ex.loadTrash() }
    // Un élément disparu de la corbeille (restauré, supprimé) quitte la sélection
    LaunchedEffect(ex.trashItems) { sel.retainAll(ex.trashItems.map { it.dir.path }.toSet()) }
    val picked = ex.trashItems.filter { it.dir.path in sel }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton({ if (sel.isNotEmpty()) sel.clear() else onBack() }) { Icon(Ic.Back, "Retour", tint = LS.Text) }
                Text("Corbeille", Modifier.weight(1f), color = LS.Text, fontSize = 20.sp, fontWeight = FontWeight.Medium)
                if (ex.trashItems.isNotEmpty()) TextButton({ confirmEmpty = true }) { Text("Vider", color = LS.Blue) }
            }
            ex.busy?.let { b ->
                Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                    Text(b, color = LS.Text, fontSize = 11.sp)
                    Spacer(Modifier.height(4.dp))
                    LinearProgressIndicator(Modifier.fillMaxWidth(), color = LS.Blue)
                }
            }
            Text(
                "Les éléments supprimés restent ici $TRASH_DAYS jours, puis sont effacés définitivement.",
                Modifier.padding(horizontal = 20.dp, vertical = 6.dp), color = LS.Muted, fontSize = 12.sp,
            )
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 6.dp, bottom = if (sel.isNotEmpty()) 104.dp else 32.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                if (ex.trashItems.isEmpty()) item(key = "empty") {
                    Text("La corbeille est vide", Modifier.fillMaxWidth().padding(24.dp), color = LS.Muted, fontSize = 13.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                }
                items(ex.trashItems, key = { it.dir.path }) { t ->
                    val on = t.dir.path in sel
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(if (on) LS.BlueLight else androidx.compose.ui.graphics.Color.Transparent)
                            .combinedClickable(
                                onClick = { if (sel.isNotEmpty()) { if (!sel.remove(t.dir.path)) sel.add(t.dir.path) } else sel.add(t.dir.path) },
                                onLongClick = { if (!sel.remove(t.dir.path)) sel.add(t.dir.path) },
                            ).padding(4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(Modifier.size(52.dp).clip(RoundedCornerShape(10.dp)).background(LS.Card), contentAlignment = Alignment.Center) {
                            Icon(if (t.isDir) Ic.Folder else t.file.category().icon(), null, Modifier.size(28.dp), tint = if (t.isDir) LS.Blue else LS.Muted)
                        }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(t.file.name, color = LS.Text, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                Formatter.formatShortFileSize(ctx, t.size) + " · supprimé le " + DateFormat.getDateInstance(DateFormat.SHORT).format(Date(t.deletedAt)),
                                color = LS.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            )
                        }
                        if (on) Icon(Ic.Check, null, Modifier.padding(end = 8.dp).size(20.dp), tint = LS.Blue)
                    }
                }
            }
        }
        if (sel.isNotEmpty()) SelectionBar(
            sel.size,
            listOf(
                BarAction("Restaurer", Ic.Restore) { ex.restoreFromTrash(picked); sel.clear() },
                BarAction("Suppr.", Ic.Delete) { confirmDelete = true },
            ),
            Modifier.align(Alignment.BottomCenter).navigationBarsPadding(),
            onCancel = { sel.clear() },
        )
    }

    if (confirmEmpty) AlertDialog(
        onDismissRequest = { confirmEmpty = false },
        title = { Text("Vider la corbeille ?") },
        text = { Text("${ex.trashItems.size} élément(s) seront supprimés définitivement.") },
        confirmButton = { TextButton({ confirmEmpty = false; sel.clear(); ex.emptyTrash() }) { Text("Vider") } },
        dismissButton = { TextButton({ confirmEmpty = false }) { Text("Annuler") } },
    )
    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("Supprimer définitivement ?") },
        text = { Text("${picked.size} élément(s) seront supprimés définitivement.") },
        confirmButton = { TextButton({ confirmDelete = false; ex.deleteTrashForever(picked); sel.clear() }) { Text("Supprimer") } },
        dismissButton = { TextButton({ confirmDelete = false }) { Text("Annuler") } },
    )
}
