package com.linkshare.ui

import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.selection.SelectionContainer
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Demandes d'ouverture venant d'autres applications (renseignées par MainActivity). */
object ExternalOpen {
    var uri by mutableStateOf<Uri?>(null)
    var mime by mutableStateOf<String?>(null)
    var folder by mutableStateOf<File?>(null)

    /** content://…externalstorage.documents/… ou file:// → dossier réel, si on sait le retrouver. */
    fun resolveFolder(u: Uri): File? {
        if (u.scheme == "file") return u.path?.let { File(it) }?.takeIf { it.isDirectory }
        // Racine d'un volume (Réglages › Stockage › Parcourir) : content://…externalstorage.documents/root/<volume>
        val seg = u.pathSegments
        if (u.authority == "com.android.externalstorage.documents" && seg.size >= 2 && seg[0] == "root") {
            val root = if (seg[1] == "primary") Environment.getExternalStorageDirectory() else File("/storage/${seg[1]}")
            return root.takeIf { it.isDirectory }
        }
        val id = runCatching { DocumentsContract.getDocumentId(u) }.getOrNull()
            ?: runCatching { DocumentsContract.getTreeDocumentId(u) }.getOrNull() ?: return null
        val vol = id.substringBefore(':')
        val rel = id.substringAfter(':', "")
        val f = if (vol == "primary") File(Environment.getExternalStorageDirectory(), rel) else File("/storage/$vol/$rel")
        return f.takeIf { it.isDirectory }
    }
}

private fun displayName(ctx: Context, u: Uri): String =
    runCatching {
        ctx.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    }.getOrNull() ?: u.lastPathSegment ?: "Fichier"

/** Lecteur plein écran pour un fichier ouvert depuis une autre appli (retour = on revient à l'appli d'origine). */
@Composable
fun ExternalViewerScreen() {
    val ctx = LocalContext.current
    val uri = ExternalOpen.uri ?: return
    val mime = ExternalOpen.mime ?: ctx.contentResolver.getType(uri) ?: ""
    val name = remember(uri) { displayName(ctx, uri) }
    fun close() { PlayerHost.stop(); ExternalOpen.uri = null; ExternalOpen.mime = null; ctx.findActivity()?.finish() }
    BackHandler { close() }
    Column(Modifier.fillMaxSize().background(LS.Bg).systemBarsPadding()) {
        Row(Modifier.padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ close() }) { Icon(Ic.Back, "Retour", tint = LS.Blue) }
            Text(name, color = LS.Blue, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        when {
            mime.startsWith("image/") -> AsyncImage(uri, name, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            mime.startsWith("video/") || mime.startsWith("audio/") -> Player(uri.toString(), name)
            mime.startsWith("text/") -> ExternalText(uri)
            else -> Text("Format non pris en charge", Modifier.padding(16.dp), color = LS.Muted)
        }
    }
}

@Composable
private fun ExternalText(uri: Uri) {
    val ctx = LocalContext.current
    val text by produceState("Chargement…", uri) {
        value = withContext(Dispatchers.IO) {
            try {
                ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { r ->
                    val buf = CharArray(300_000)
                    val n = r.read(buf)
                    if (n > 0) String(buf, 0, n) else ""
                } ?: "Lecture impossible"
            } catch (e: Exception) { "Lecture impossible : ${e.message}" }
        }
    }
    SelectionContainer {
        Text(
            text, Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            color = LS.Text, fontSize = 12.sp, fontFamily = FontFamily.Monospace,
        )
    }
}
