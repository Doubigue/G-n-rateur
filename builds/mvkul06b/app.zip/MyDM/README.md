# MyDM — Navigateur & Gestionnaire de téléchargements (Kotlin / Compose)

Ouvrir le dossier dans **Android Studio (Ladybug+)**, laisser la synchro Gradle se faire (génère le wrapper), puis Run sur un appareil Android 10+ (API 29).

- `browser/` WebView + sniffer (shouldInterceptRequest + JS injecté)
- `downloader/` moteur multi-segments (Range) + Foreground Service
- `whatsapp/` statuts via Storage Access Framework
- `torrent/` jlibtorrent (magnet / .torrent, sélection de fichiers, stats temps réel)
- `ui/` thème sombre « glass » + écrans Compose

Limites connues : HLS (.m3u8) détecté mais pas téléchargé ; pas de DRM ; vérifier les signatures jlibtorrent selon la version.

## Téléchargeur (pastille ⬇)
- Détection par extension, balises vidéo/audio **et Content-Type** (fichiers sans extension).
- Pastille « ⬇ » sur le navigateur : liste des médias, taille au clic, bouton Télécharger.
- Liens YouTube / Facebook / TikTok / HLS (m3u8) : analyse par yt-dlp (qualités + tailles), MP4 / M4A / MP3.
- Statuts WhatsApp : tous les dossiers `.Statuses` sont fusionnés et triés du plus récent au plus ancien.

## Onglets & paramètres
- Onglets : bouton compteur dans la barre d'adresse → grille d'onglets (miniatures, fermer, nouvel onglet). Les liens `target=_blank` / `window.open` ouvrent un nouvel onglet. Chaque onglet a sa propre liste de médias détectés.
- Paramètres (menu ⋮ du navigateur) : page d'accueil, moteur de recherche, mode ordinateur, blocage des pop-ups, restauration des onglets, nombre de connexions par téléchargement, effacement cookies/cache/médias.

## Nouveautés (v1.1)
- **Page « Vidéos à télécharger »** (pastille ⬇ du navigateur) en plein écran : taille calculée automatiquement, dossier de destination, « Tout » télécharger.
- **Pastille sur l'onglet Téléchargements** (et Torrent) : nombre de téléchargements en cours.
- **Dossiers** : `Download/MyDM/` → Video made (statuts WhatsApp photos+vidéos), Video, Torrent, Documents, Images, Musiques, Autres. Filtre par dossier dans l'écran Téléchargements.
- **Notification** : nombre en cours, % global, nom + % + taille des 5 premiers (réglable 3-5), « +N autres », pastille numérique sur l'icône, bouton « Tout mettre en pause ».
- **Site en ZIP** (menu ⋮) : index.html réécrit pour l'hors-ligne, original.html, assets/{css,js,img,fonts,media,other}, console.txt, network.txt, resources.txt.
- **Console / Réseau** (menu ⋮) : messages console, exécution de JS, requêtes de la page. Débogage distant chrome://inspect dans les paramètres.
- **Liens externes** : http/https (MyDM choisissable comme navigateur), texte/lien partagé, magnet:, fichiers .torrent.
- **Recherche par photo** : menu ⋮ → Google Lens (envoi de fichier supporté), et appui long sur une image → Lens / télécharger / copier.
- **Extensions** : scripts utilisateur (.user.js) et content scripts d'extensions Chrome (.zip/.crx). Le Chrome Web Store n'est pas installable dans une WebView Android.
- **Paramètres avancés** : téléchargements simultanés, connexions/fichier (jusqu'à 32), limite de vitesse, tentatives auto sur erreur DNS/réseau, Wi-Fi uniquement, JS, images, zoom du texte, User-Agent, réinitialisation.

## Vitesse (v1.2)
- File d'attente de chunks (1–16 Mo) répartie entre 16 connexions par défaut (jusqu'à 32) : un serveur lent n'attend plus le dernier segment.
- HTTP/1.1 forcé pour les segments : une vraie connexion TCP par worker (en HTTP/2 elles se partageaient une seule connexion).
- Serveur qui répond 429/503 : le nombre de connexions baisse automatiquement au lieu d'échouer.
- Buffers 256 Ko ; yt-dlp : jusqu'à 16 fragments HLS/DASH en parallèle.
