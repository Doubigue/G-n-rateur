package com.example.mydm.core

import android.net.Uri
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import java.util.UUID

enum class MediaType { VIDEO, HLS, AUDIO, APK, PDF, ARCHIVE, IMAGE }

data class DetectedMedia(
    val url: String, val type: MediaType, val pageUrl: String?, val pageTitle: String?,
    val userAgent: String, val cookies: String?, val referer: String?,
    val name: String? = null, val sizeBytes: Long? = null
)

object MediaDetector {
    private val extMap = mapOf(
        "mp4" to MediaType.VIDEO, "webm" to MediaType.VIDEO, "mkv" to MediaType.VIDEO,
        "m3u8" to MediaType.HLS, "mp3" to MediaType.AUDIO, "m4a" to MediaType.AUDIO,
        "apk" to MediaType.APK, "pdf" to MediaType.PDF,
        "zip" to MediaType.ARCHIVE, "rar" to MediaType.ARCHIVE
    )
    fun detect(url: String): MediaType? {
        val path = Uri.parse(url).path ?: return null
        return extMap[path.lowercase().substringAfterLast('.', "")]
    }
}

enum class Status { QUEUED, RUNNING, PAUSED, MERGING, COMPLETED, FAILED }

@Entity(tableName = "tasks")
data class DownloadTask(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val url: String, val fileName: String, val mimeType: String?,
    val totalBytes: Long = -1, val status: Status = Status.QUEUED,
    val headersJson: String = "{}", val maxSegments: Int = 8,
    val resultUri: String? = null, val error: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val folder: String = ""            // nom de Folder ; vide = déduit de l'extension
)

@Entity(tableName = "segments", primaryKeys = ["taskId", "idx"])
data class Segment(val taskId: String, val idx: Int, val start: Long, val end: Long)

@Dao
interface DownloadDao {
    @Query("SELECT * FROM tasks ORDER BY createdAt DESC") fun observeTasks(): Flow<List<DownloadTask>>
    @Query("SELECT * FROM tasks WHERE status IN ('QUEUED','RUNNING','MERGING')") fun observeActive(): Flow<List<DownloadTask>>
    @Query("SELECT * FROM tasks WHERE status IN ('QUEUED','RUNNING','MERGING') ORDER BY createdAt") suspend fun activeNow(): List<DownloadTask>
    @Query("SELECT * FROM tasks WHERE id = :id") suspend fun task(id: String): DownloadTask?
    @Upsert suspend fun upsert(t: DownloadTask)
    @Query("UPDATE tasks SET status = :s, error = :e WHERE id = :id") suspend fun setStatus(id: String, s: Status, e: String?)
    @Query("SELECT * FROM segments WHERE taskId = :id ORDER BY idx") suspend fun segments(id: String): List<Segment>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertSegments(s: List<Segment>)
    @Query("DELETE FROM tasks WHERE id = :id") suspend fun delete(id: String)
    @Query("DELETE FROM segments WHERE taskId = :id") suspend fun deleteSegments(id: String)
}

class Converters {
    @TypeConverter fun toStatus(v: String) = Status.valueOf(v)
    @TypeConverter fun fromStatus(s: Status) = s.name
}

val MIGRATION_1_2 = object : androidx.room.migration.Migration(1, 2) {
    override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE tasks ADD COLUMN folder TEXT NOT NULL DEFAULT ''")
    }
}

@Database(entities = [DownloadTask::class, Segment::class], version = 2, exportSchema = false)
@TypeConverters(Converters::class)
abstract class AppDb : RoomDatabase() { abstract fun downloadDao(): DownloadDao }


// ───── Utilitaires de noms / tailles
fun cleanName(s: String): String =
    s.replace(Regex("[\\\\/:*?\"<>|\\n\\r]"), "_").trim().take(120)

fun DetectedMedia.displayName(): String =
    name?.takeIf { it.isNotBlank() }
        ?: Uri.parse(url).lastPathSegment?.takeIf { it.contains('.') }
        ?: pageTitle?.takeIf { it.isNotBlank() }
        ?: url.substringAfter("://").take(40)

fun fileNameFor(m: DetectedMedia): String {
    val known = mapOf(
        MediaType.VIDEO to listOf("mp4", "webm", "mkv", "m4v", "mov"),
        MediaType.AUDIO to listOf("mp3", "m4a", "aac", "ogg", "wav"),
        MediaType.HLS to listOf("mp4"), MediaType.APK to listOf("apk"),
        MediaType.PDF to listOf("pdf"), MediaType.ARCHIVE to listOf("zip", "rar", "7z"),
        MediaType.IMAGE to listOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "avif")
    )
    val default = mapOf(MediaType.VIDEO to "mp4", MediaType.AUDIO to "mp3", MediaType.HLS to "mp4",
        MediaType.APK to "apk", MediaType.PDF to "pdf", MediaType.ARCHIVE to "zip", MediaType.IMAGE to "jpg")
    val base = cleanName(m.displayName()).ifBlank { "fichier" }
    val ext = base.substringAfterLast('.', "").lowercase()
    return if (ext in known.getValue(m.type)) base else base + "." + default.getValue(m.type)
}

fun formatSize(b: Long): String = when {
    b >= 1L shl 30 -> "%.2f Go".format(b / 1073741824.0)
    b >= 1L shl 20 -> "%.1f Mo".format(b / 1048576.0)
    else -> "${b / 1024} Ko"
}
