package com.example.mydm.downloader

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import com.example.mydm.core.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import android.webkit.MimeTypeMap
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import okhttp3.*
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/** exact = false : pourcentage seulement (yt-dlp), pas de vraies tailles. */
data class Progress(val downloaded: Long, val total: Long, val speedBps: Long, val exact: Boolean = true)

/** Limiteur de débit global (Ko/s, 0 = illimité). */
object Throttle {
    private var windowStart = System.nanoTime()
    private var bytes = 0L
    suspend fun take(n: Int) {
        val limit = Prefs.speedLimitKb * 1024L
        if (limit <= 0) return
        var wait = 0L
        synchronized(this) {
            val now = System.nanoTime()
            if (now - windowStart >= 1_000_000_000L) { windowStart = now; bytes = 0 }
            bytes += n
            if (bytes > limit) wait = ((1_000_000_000L - (now - windowStart)) / 1_000_000L).coerceIn(1, 1000)
        }
        if (wait > 0) delay(wait)
    }
}

class DownloadEngine(
    private val context: Context,
    private val dao: DownloadDao,
    private val client: OkHttpClient = OkHttpClient.Builder()
        // HTTP/1.1 : chaque segment ouvre sa propre connexion TCP. En HTTP/2 tous les segments partageraient
        // une seule connexion et le téléchargement parallèle n'accélérerait rien.
        .protocols(listOf(Protocol.HTTP_1_1))
        .connectionPool(ConnectionPool(64, 5, TimeUnit.MINUTES))
        .connectTimeout(10, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true).build()
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val jobs = ConcurrentHashMap<String, Job>()
    private val _progress = MutableStateFlow<Map<String, Progress>>(emptyMap())
    val progress: StateFlow<Map<String, Progress>> = _progress
    val activeCount get() = jobs.values.count { it.isActive }

    private val partsDir get() = File(context.getExternalFilesDir(null), "parts").apply { mkdirs() }
    private fun part(id: String, i: Int) = File(partsDir, "$id.part$i")

    private val running = AtomicInteger(0)

    /** Attend qu'une place se libère (réglage « téléchargements simultanés »). Annulable. */
    private suspend fun acquire() {
        while (true) {
            val c = running.get()
            if (c < Prefs.maxParallel.coerceAtLeast(1) && running.compareAndSet(c, c + 1)) return
            delay(400)
        }
    }

    fun start(id: String) {
        if (jobs[id]?.isActive == true) return
        jobs[id] = scope.launch {
            var acquired = false
            try {
                dao.setStatus(id, Status.QUEUED, null)
                acquire(); acquired = true
                runTask(id)
            } catch (e: CancellationException) {
                withContext(NonCancellable) { dao.setStatus(id, Status.PAUSED, null) }
                _progress.update { it - id }
                throw e
            } catch (e: Exception) {
                dao.setStatus(id, Status.FAILED, friendly(e))
                _progress.update { it - id }
            } finally { if (acquired) running.decrementAndGet() }
        }
    }

    fun pauseAll() { jobs.keys.toList().forEach(::pause) }

    private fun caps(): NetworkCapabilities? =
        context.getSystemService(ConnectivityManager::class.java).let { cm -> cm.getNetworkCapabilities(cm.activeNetwork) }

    private fun checkNetwork() {
        val c = caps()
        if (c == null || !c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) throw IOException("Pas de connexion Internet")
        if (Prefs.wifiOnly && !(c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)))
            throw IOException("Wi-Fi requis (réglage « Wi-Fi uniquement »)")
    }

    private fun isNetworkError(e: Throwable): Boolean {
        val m = e.message ?: ""
        return e is UnknownHostException || e is SocketTimeoutException ||
            "No address associated with hostname" in m || "Unable to resolve host" in m ||
            "TransportError" in m || "timed out" in m || "Network is unreachable" in m
    }

    private fun friendly(e: Throwable): String {
        val m = e.message ?: e::class.java.simpleName
        return when {
            "No address associated with hostname" in m || "Unable to resolve host" in m || e is UnknownHostException ->
                "Serveur injoignable (DNS/Internet). Vérifiez la connexion, le DNS privé ou le VPN, puis « Reprendre »."
            "timed out" in m || e is SocketTimeoutException -> "Délai dépassé : connexion trop lente. Réessayez."
            else -> m.take(300)
        }
    }

    fun pause(id: String) { jobs.remove(id)?.cancel() }   // les .part restent => reprise possible

    fun cancel(id: String) {
        pause(id)
        scope.launch {
            partsDir.listFiles { f -> f.name.startsWith(id) }?.forEach { it.delete() }
            File(context.getExternalFilesDir(null), "ytdlp/$id").deleteRecursively()
            File(context.getExternalFilesDir(null), "site/$id").deleteRecursively()
            dao.deleteSegments(id); dao.delete(id)
        }
    }

    /** Crée la tâche en base (headers rejoués : UA, cookies, referer). */
    suspend fun enqueue(m: DetectedMedia): String {
        val headers = JSONObject().apply {
            put("User-Agent", m.userAgent)
            m.cookies?.let { put("Cookie", it) }
            m.referer?.let { put("Referer", it) }
        }.toString()
        val task = DownloadTask(url = m.url, fileName = fileNameFor(m),
            mimeType = null, headersJson = headers, maxSegments = Prefs.maxSegments)
        dao.upsert(task)
        return task.id
    }

    /** ZIP des composants du site : HTML rendu, CSS, JS, images, polices, console et journal réseau. */
    suspend fun enqueueSite(pageUrl: String, title: String, html: String, urls: List<String>,
                            consoleText: String, networkText: String, ua: String): String {
        val task = DownloadTask(url = pageUrl, fileName = cleanName(title.ifBlank { Uri.parse(pageUrl).host ?: "site" }) + ".zip",
            mimeType = "application/zip", headersJson = JSONObject().put("siteZip", true).put("ua", ua).toString(),
            folder = Folder.OTHER.name)
        val dir = File(context.getExternalFilesDir(null), "site/${task.id}").apply { mkdirs() }
        File(dir, "page.html").writeText(html)
        File(dir, "urls.txt").writeText(urls.joinToString("\n"))
        File(dir, "console.txt").writeText(consoleText)
        File(dir, "network.txt").writeText(networkText)
        dao.upsert(task)
        return task.id
    }

    private suspend fun runSite(task: DownloadTask) {
        val id = task.id
        val dir = File(context.getExternalFilesDir(null), "site/$id")
        if (!File(dir, "page.html").exists()) error("Données du site introuvables")
        dao.setStatus(id, Status.RUNNING, null)
        val ua = JSONObject(task.headersJson).optString("ua").ifBlank { "Mozilla/5.0" }
        val zip = SiteGrabber(client).build(
            dir, task.url, File(dir, "page.html").readText(),
            File(dir, "urls.txt").readLines().filter { it.isNotBlank() },
            File(dir, "console.txt").readText(), File(dir, "network.txt").readText(), ua
        ) { done, total -> _progress.update { it + (id to Progress(done.toLong(), total.toLong().coerceAtLeast(1), 0, exact = false)) } }
        dao.setStatus(id, Status.MERGING, null)
        val uri = Storage.saveFile(context, zip, task.fileName, "application/zip", Folder.OTHER)
        dao.upsert(dao.task(id)!!.copy(status = Status.COMPLETED, resultUri = uri.toString(), totalBytes = zip.length()))
        dir.deleteRecursively()
        _progress.update { it - id }
    }

    /** Tâche gérée par yt-dlp : page YouTube/Facebook/TikTok ou flux HLS. */
    suspend fun enqueueYt(pageUrl: String, title: String, opt: QualityOption, referer: String? = null): String {
        val h = JSONObject().put("ytdlpFormat", opt.selector).put("ytdlpMp3", opt.mp3)
        referer?.let { h.put("ytdlpReferer", it) }
        val q = opt.label.substringBefore(" •")
        val task = DownloadTask(url = pageUrl, fileName = cleanName("$title [$q]").ifBlank { "video" },
            mimeType = null, headersJson = h.toString())
        dao.upsert(task)
        return task.id
    }

    private suspend fun runYtDlp(task: DownloadTask) {
        val id = task.id
        val o = JSONObject(task.headersJson)
        val dir = File(context.getExternalFilesDir(null), "ytdlp/$id").apply { mkdirs() }
        dao.setStatus(id, Status.RUNNING, null)

        val req = YoutubeDLRequest(task.url).apply {
            addOption("-f", o.getString("ytdlpFormat"))
            addOption("--no-playlist")
            addOption("-N", Prefs.maxSegments.coerceIn(4, 16))   // fragments HLS/DASH en parallèle
            addOption("--retries", "10"); addOption("--extractor-retries", "5"); addOption("--socket-timeout", "30")
            if (Prefs.speedLimitKb > 0) addOption("--limit-rate", "${Prefs.speedLimitKb}K")
            addOption("-o", dir.absolutePath + "/out.%(ext)s")
            if (o.optBoolean("ytdlpMp3")) { addOption("-x"); addOption("--audio-format", "mp3") }
            else addOption("--merge-output-format", "mp4")
            o.optString("ytdlpReferer").takeIf { it.isNotEmpty() }?.let { addOption("--referer", it) }
        }
        val handle = currentCoroutineContext()[Job]!!.invokeOnCompletion { YoutubeDL.getInstance().destroyProcessById(id) }
        try {
            var attempt = 0
            while (true) {
                try {
                    YoutubeDL.getInstance().execute(req, id) { p, _, _ ->
                        _progress.update { it + (id to Progress((p.coerceIn(0f, 100f) * 10).toLong(), 1000, 0, exact = false)) }
                    }
                    break
                } catch (e: Exception) {
                    if (!currentCoroutineContext().isActive) throw CancellationException("pause")
                    // Erreur réseau/DNS (ex. « No address associated with hostname ») : on réessaie avant d'abandonner
                    if (isNetworkError(e) && ++attempt <= Prefs.retries) { delay(3000L * attempt); continue }
                    throw e
                }
            }
        } finally { handle.dispose() }

        val out = dir.listFiles()
            ?.filter { it.isFile && it.name.startsWith("out.") && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") }
            ?.maxByOrNull { it.length() } ?: error("Fichier de sortie introuvable")
        dao.setStatus(id, Status.MERGING, null)
        val name = cleanName(task.fileName) + "." + out.extension
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(out.extension)
        val folder = folderFor(name, mime).let { if (it == Folder.OTHER) Folder.VIDEO else it }
        val uri = Storage.saveFile(context, out, name, mime, folder)
        dao.upsert(dao.task(id)!!.copy(fileName = name, mimeType = mime, status = Status.COMPLETED, resultUri = uri.toString(),
            totalBytes = out.length(), folder = folder.name))
        dir.deleteRecursively()
        _progress.update { it - id }
    }

    private suspend fun runTask(id: String) {
        val task = dao.task(id) ?: return
        checkNetwork()
        if (task.headersJson.contains("siteZip")) { runSite(task); return }
        if (task.headersJson.contains("ytdlpFormat")) { runYtDlp(task); return }
        val headers = task.headersJson.toHeaders()
        dao.setStatus(id, Status.RUNNING, null)

        var segs = dao.segments(id)
        var total = task.totalBytes
        if (segs.isEmpty()) {
            val probe = probe(task.url, headers)
            total = probe.length
            segs = plan(id, probe, task.maxSegments)
            dao.insertSegments(segs)
            dao.upsert(task.copy(totalBytes = total, status = Status.RUNNING))
        }
        val ranged = total > 0 && segs.first().end >= 0

        val ticker = scope.launch {
            var last = segs.sumOf { part(id, it.idx).length() }; var lastT = System.nanoTime()
            while (isActive) {
                delay(500)
                val done = segs.sumOf { part(id, it.idx).length() }
                val now = System.nanoTime()
                val speed = ((done - last) * 1_000_000_000L) / (now - lastT).coerceAtLeast(1)
                last = done; lastT = now
                _progress.update { it + (id to Progress(done, total, speed)) }
            }
        }
        try {
            val workers = if (ranged) task.maxSegments.coerceIn(1, 32).coerceAtMost(segs.size) else 1
            val queue = java.util.concurrent.ConcurrentLinkedQueue(segs)
            val alive = AtomicInteger(workers)
            coroutineScope {
                repeat(workers) {
                    launch {
                        var strikes = 0
                        while (true) {
                            val s = queue.poll() ?: break
                            try { downloadSegment(task.url, headers, id, s, ranged) }
                            catch (e: Throttled) {
                                queue.add(s)
                                if (alive.get() > 1) { alive.decrementAndGet(); return@launch }   // un worker de moins
                                if (++strikes > 5) throw e
                                delay(2000L * strikes)
                            }
                        }
                    }
                }
            }
        } finally { ticker.cancel() }

        dao.setStatus(id, Status.MERGING, null)
        val uri = merge(task, segs)
        dao.upsert(dao.task(id)!!.copy(status = Status.COMPLETED, resultUri = uri.toString()))
        _progress.update { it - id }
    }

    private data class Probe(val length: Long, val acceptsRanges: Boolean)

    private fun probe(url: String, headers: Headers): Probe {
        val req = Request.Builder().url(url).headers(headers).header("Range", "bytes=0-0").build()
        client.newCall(req).execute().use { r ->
            return when {
                r.code == 206 -> {
                    val total = r.header("Content-Range")?.substringAfter('/')?.toLongOrNull() ?: -1
                    Probe(total, total > 0)
                }
                r.isSuccessful -> Probe(r.header("Content-Length")?.toLongOrNull() ?: -1, false)
                else -> throw IOException("HTTP ${r.code}")
            }
        }
    }

    /** Découpe en chunks de 1 à 16 Mo : les workers rapides en prennent davantage (pas d'attente sur le plus lent). */
    private fun plan(id: String, p: Probe, maxSeg: Int): List<Segment> {
        if (!p.acceptsRanges || p.length <= 0) return listOf(Segment(id, 0, 0, -1))
        val chunk = (p.length / (maxSeg.coerceAtLeast(1) * 4L)).coerceIn(1L shl 20, 16L shl 20)
        val n = ((p.length + chunk - 1) / chunk).toInt().coerceIn(1, 2000)
        val size = p.length / n
        return (0 until n).map { i ->
            Segment(id, i, i * size, if (i == n - 1) p.length - 1 else (i + 1) * size - 1)
        }
    }

    /** Serveur qui limite les connexions (429/503) : on réduit le nombre de workers au lieu d'échouer. */
    private class Throttled(msg: String) : IOException(msg)

    private suspend fun downloadSegment(url: String, headers: Headers, id: String, s: Segment, ranged: Boolean) {
        val file = part(id, s.idx)
        var attempt = 0
        while (true) {
            try {
                val already = if (ranged && file.exists()) file.length() else 0L
                if (ranged && s.start + already > s.end) return          // segment déjà complet

                val rb = Request.Builder().url(url).headers(headers)
                if (ranged) rb.header("Range", "bytes=${s.start + already}-${s.end}")
                val call = client.newCall(rb.build())
                val h = currentCoroutineContext()[Job]!!.invokeOnCompletion { call.cancel() }
                try {
                    call.execute().use { r ->
                        if (r.code == 429 || r.code == 503) throw Throttled("HTTP ${r.code}")
                        if (ranged && r.code != 206) throw IOException("Range non respecté (${r.code})")
                        if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
                        FileOutputStream(file, ranged).use { out ->
                            val buf = ByteArray(256 * 1024)
                            val input = r.body!!.byteStream()
                            while (true) {
                                currentCoroutineContext().ensureActive()
                                val n = input.read(buf); if (n < 0) break
                                out.write(buf, 0, n)
                                Throttle.take(n)
                            }
                        }
                    }
                } finally { h.dispose() }
                return
            } catch (e: CancellationException) { throw e }
            catch (e: Throttled) { throw e }
            catch (e: IOException) {
                if (++attempt >= 5) throw e
                delay(1000L * attempt)
            }
        }
    }

    private fun merge(task: DownloadTask, segs: List<Segment>): Uri {
        val folder = task.resolvedFolder()
        val uri = Storage.create(context, task.fileName, task.mimeType, folder)
        context.contentResolver.openOutputStream(uri)!!.use { out ->
            segs.sortedBy { it.idx }.forEach { s ->
                part(task.id, s.idx).inputStream().use { it.copyTo(out, 256 * 1024) }
            }
        }
        Storage.publish(context, uri)
        segs.forEach { part(task.id, it.idx).delete() }
        return uri
    }

    private fun String.toHeaders(): Headers {
        val b = Headers.Builder(); val o = JSONObject(this)
        o.keys().forEach { b.add(it, o.getString(it)) }; return b.build()
    }
}
