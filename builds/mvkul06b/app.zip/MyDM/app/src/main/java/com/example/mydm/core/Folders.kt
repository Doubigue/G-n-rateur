package com.example.mydm.core

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import java.io.File

/** Dossiers de l'application : Download/MyDM/<dir> */
enum class Folder(val label: String, val dir: String, val icon: String) {
    VIDEO_MADE("Vidéo made", "Video made", "💬"),   // statuts WhatsApp (photos + vidéos)
    VIDEO("Vidéo", "Video", "🎬"),                  // vidéos téléchargées
    TORRENT("Torrent", "Torrent", "🧲"),            // tout ce qui vient d'un torrent
    DOCUMENTS("Documents", "Documents", "📄"),
    IMAGES("Images", "Images", "🖼️"),
    MUSIC("Musiques", "Musiques", "🎵"),
    OTHER("Autres", "Autres", "📦")
}

private val VIDEO_EXT = setOf("mp4", "mkv", "webm", "mov", "avi", "m4v", "3gp", "flv", "ts", "wmv")
private val AUDIO_EXT = setOf("mp3", "m4a", "aac", "ogg", "wav", "flac", "opus", "wma")
private val IMAGE_EXT = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "svg", "heic", "avif")
private val DOC_EXT = setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "epub", "csv", "odt", "rtf", "md")

fun folderFor(fileName: String, mime: String? = null): Folder {
    val ext = fileName.substringAfterLast('.', "").lowercase()
    return when {
        ext in VIDEO_EXT || mime?.startsWith("video/") == true -> Folder.VIDEO
        ext in AUDIO_EXT || mime?.startsWith("audio/") == true -> Folder.MUSIC
        ext in IMAGE_EXT || mime?.startsWith("image/") == true -> Folder.IMAGES
        ext in DOC_EXT || mime == "application/pdf" -> Folder.DOCUMENTS
        else -> Folder.OTHER
    }
}

fun DownloadTask.resolvedFolder(): Folder =
    runCatching { Folder.valueOf(folder) }.getOrNull() ?: folderFor(fileName, mimeType)

object Storage {
    /** Crée l'entrée MediaStore (IS_PENDING) dans Download/MyDM/<dossier>[/<sous-dossier>]. */
    fun create(ctx: Context, name: String, mime: String?, folder: Folder, sub: String? = null): Uri {
        val rel = "${Environment.DIRECTORY_DOWNLOADS}/MyDM/${folder.dir}" + (sub?.let { "/" + cleanName(it) } ?: "")
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            mime?.let { put(MediaStore.Downloads.MIME_TYPE, it) }
            put(MediaStore.Downloads.RELATIVE_PATH, rel)
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        return ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: error("Impossible de créer le fichier")
    }

    fun publish(ctx: Context, uri: Uri) {
        ctx.contentResolver.update(uri, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
    }

    fun saveFile(ctx: Context, file: File, name: String, mime: String?, folder: Folder, sub: String? = null): Uri {
        val uri = create(ctx, name, mime, folder, sub)
        ctx.contentResolver.openOutputStream(uri)!!.use { out -> file.inputStream().use { it.copyTo(out, 256 * 1024) } }
        publish(ctx, uri)
        return uri
    }
}
