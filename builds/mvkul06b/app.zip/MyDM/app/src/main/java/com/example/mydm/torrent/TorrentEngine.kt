package com.example.mydm.torrent

import android.content.Context
import android.net.Uri
import com.frostwire.jlibtorrent.*
import com.frostwire.jlibtorrent.alerts.Alert
import com.frostwire.jlibtorrent.alerts.AlertType
import com.frostwire.jlibtorrent.swig.torrent_flags_t
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import com.example.mydm.core.DownloadTask
import com.example.mydm.core.Folder
import com.example.mydm.core.Status
import com.example.mydm.core.Storage
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.ConcurrentHashMap

data class TorrentFile(val index: Int, val path: String, val size: Long, val progress: Long = 0, val selected: Boolean = true)

data class TorrentState(
    val infoHash: String, val name: String, val progress: Float,
    val downloadRate: Int, val uploadRate: Int, val peers: Int, val seeds: Int,
    val state: String, val files: List<TorrentFile>
)

class TorrentEngine(private val context: Context) {
    private val session by lazy { SessionManager() }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val saveDir = File(context.getExternalFilesDir(null), "torrents").apply { mkdirs() }

    private val _states = MutableStateFlow<Map<String, TorrentState>>(emptyMap())
    val states: StateFlow<Map<String, TorrentState>> = _states
    private val infos = ConcurrentHashMap<String, TorrentInfo>()
    private val selection = ConcurrentHashMap<String, Set<Int>>()
    private var polling: Job? = null
    private val exported = ConcurrentHashMap.newKeySet<String>()

    @Synchronized fun start() {
        if (session.isRunning) return
        session.addListener(object : AlertListener {
            override fun types() = intArrayOf(AlertType.TORRENT_FINISHED.swig(), AlertType.TORRENT_ERROR.swig())
            override fun alert(alert: Alert<*>) { /* ex. notifier la fin du torrent */ }
        })
        session.start()
        polling = scope.launch { pollLoop() }
    }

    /** Étape 1 : parse un .torrent (content:// ou file://) ou résout un magnet. */
    suspend fun inspect(source: String): TorrentInfo = withContext(Dispatchers.IO) {
        start()
        val data: ByteArray? = if (source.startsWith("magnet:")) session.fetchMagnet(source, 60, saveDir)
        else if (source.startsWith("http")) OkHttpClient().newCall(Request.Builder().url(source).build()).execute().use { r ->
            if (!r.isSuccessful) error("HTTP ${r.code}"); r.body!!.bytes()
        }
        else context.contentResolver.openInputStream(Uri.parse(source))!!.use { it.readBytes() }
        TorrentInfo.bdecode(data ?: error("Métadonnées introuvables (aucun pair ?)"))
            .also { infos[it.infoHashV1().toHex()] = it }
    }

    fun hash(ti: TorrentInfo) = ti.infoHashV1().toHex()

    fun listFiles(ti: TorrentInfo): List<TorrentFile> {
        val fs = ti.files()
        return (0 until fs.numFiles()).map { TorrentFile(it, fs.filePath(it), fs.fileSize(it)) }
    }

    /** Étape 2 : démarre avec les fichiers sélectionnés. */
    fun download(ti: TorrentInfo, selected: Set<Int>) {
        val prios = Array(ti.numFiles()) { if (it in selected) Priority.NORMAL else Priority.IGNORE }
        selection[hash(ti)] = selected
        session.download(ti, saveDir, null, prios, null, torrent_flags_t())
    }

    fun setSelection(infoHash: String, selected: Set<Int>) {
        val ti = infos[infoHash] ?: return
        val h = session.find(ti.infoHashV1()) ?: return
        h.prioritizeFiles(Array(ti.numFiles()) { if (it in selected) Priority.NORMAL else Priority.IGNORE })
        selection[infoHash] = selected
    }

    fun pause(hash: String) = handle(hash)?.pause()
    fun resume(hash: String) = handle(hash)?.resume()
    fun remove(hash: String) {
        handle(hash)?.let { session.remove(it) }
        infos.remove(hash); selection.remove(hash)
    }

    private fun handle(hash: String) = infos[hash]?.let { session.find(it.infoHashV1()) }

    private suspend fun pollLoop() {
        while (currentCoroutineContext().isActive) {
            val snapshot = infos.mapNotNull { (hash, ti) ->
                val h = session.find(ti.infoHashV1()) ?: return@mapNotNull null
                if (!h.isValid) return@mapNotNull null
                val st = h.status()
                // jlibtorrent 1.2.x
                val perFile = h.fileProgress(TorrentHandle.PIECE_GRANULARITY)
                val sel = selection[hash] ?: emptySet()
                val files = listFiles(ti).map {
                    it.copy(progress = perFile.getOrElse(it.index) { 0L }, selected = it.index in sel)
                }
                hash to TorrentState(hash, ti.name(), st.progress(), st.downloadPayloadRate(),
                    st.uploadPayloadRate(), st.numPeers(), st.numSeeds(), st.state().name, files)
            }.toMap()
            _states.value = snapshot
            // Torrent terminé : copie des fichiers choisis dans Download/MyDM/Torrent/<nom>
            snapshot.values.forEach { st ->
                if (st.state in setOf("FINISHED", "SEEDING") && exported.add(st.infoHash)) {
                    scope.launch { runCatching { exportFinished(st) } }
                }
            }
            delay(1000)
        }
    }

    private suspend fun exportFinished(st: TorrentState) {
        val dao = (context.applicationContext as com.example.mydm.App).db.downloadDao()
        st.files.filter { it.selected }.forEach { f ->
            val file = File(saveDir, f.path)
            if (!file.isFile) return@forEach
            val name = file.name
            val mime = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(file.extension.lowercase())
            val uri = Storage.saveFile(context, file, name, mime, Folder.TORRENT, st.name)
            dao.upsert(DownloadTask(url = "torrent://" + st.infoHash, fileName = name, mimeType = mime, totalBytes = file.length(),
                status = Status.COMPLETED, resultUri = uri.toString(), folder = Folder.TORRENT.name))
        }
    }
}
