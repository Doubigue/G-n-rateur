package com.example.mydm.ext

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.util.UUID
import java.util.zip.ZipInputStream

/**
 * « Extensions » de MyDM.
 * Une WebView Android ne sait PAS installer les extensions Chrome (.crx / Web Store) : il n'existe pas d'API d'extension.
 * On propose donc deux formats injectés dans les pages :
 *  - les scripts utilisateur (.user.js, style Tampermonkey) ;
 *  - les « content scripts » d'une extension Chrome (.zip / .crx dépaquetée) : manifest.json → content_scripts (js + css).
 * Les API chrome.* sont simulées de façon minimale (runtime.getURL, storage.local) ; les extensions qui dépendent
 * d'un service worker / popup / webRequest ne fonctionneront pas.
 */
data class UserExt(
    val id: String, val name: String, val matches: List<String>,
    val js: String, val css: String, val enabled: Boolean, val source: String
)

object Extensions {
    val items = mutableStateListOf<UserExt>()
    private lateinit var ctx: Context
    private val regexCache = HashMap<String, Regex?>()

    fun init(c: Context) {
        ctx = c.applicationContext
        items.clear()
        runCatching {
            val a = JSONArray(ctx.getSharedPreferences("ext", Context.MODE_PRIVATE).getString("list", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                items.add(UserExt(o.getString("id"), o.getString("name"),
                    o.getJSONArray("matches").let { m -> List(m.length()) { m.getString(it) } },
                    o.optString("js"), o.optString("css"), o.optBoolean("on", true), o.optString("src", "userscript")))
            }
        }
    }

    private fun save() {
        val a = JSONArray()
        items.forEach { e ->
            a.put(JSONObject().put("id", e.id).put("name", e.name).put("matches", JSONArray(e.matches))
                .put("js", e.js).put("css", e.css).put("on", e.enabled).put("src", e.source))
        }
        ctx.getSharedPreferences("ext", Context.MODE_PRIVATE).edit().putString("list", a.toString()).apply()
    }

    fun setEnabled(id: String, on: Boolean) {
        val i = items.indexOfFirst { it.id == id }; if (i < 0) return
        items[i] = items[i].copy(enabled = on); save()
    }
    fun remove(id: String) { items.removeAll { it.id == id }; save() }

    // ───── Ajout / import
    fun addUserScript(code: String, fallbackName: String = "Script"): UserExt {
        val header = Regex("(?s)//\\s*==UserScript==(.*?)//\\s*==/UserScript==").find(code)?.groupValues?.get(1) ?: ""
        fun tags(t: String) = Regex("//\\s*@$t\\s+(.+)").findAll(header).map { it.groupValues[1].trim() }.toList()
        val name = tags("name").firstOrNull() ?: fallbackName
        val matches = (tags("match") + tags("include")).ifEmpty { listOf("<all_urls>") }
        val e = UserExt(UUID.randomUUID().toString(), name, matches, code, "", true, "userscript")
        items.add(e); save(); return e
    }

    /** Importe un fichier : .js / .user.js, ou extension Chrome en .zip / .crx. Renvoie le nombre d'éléments ajoutés. */
    fun importUri(uri: Uri): Int {
        val bytes = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
        val name = uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':') ?: "Script"
        val isZip = bytes.size > 4 && ((bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte()) ||
            (bytes[0] == 'C'.code.toByte() && bytes[1] == 'r'.code.toByte() && bytes[2] == '2'.code.toByte()))
        if (!isZip) { addUserScript(bytes.toString(Charsets.UTF_8), name.removeSuffix(".user.js").removeSuffix(".js")); return 1 }
        return importChromeExtension(bytes)
    }

    private fun importChromeExtension(raw: ByteArray): Int {
        var data = raw
        if (raw.size > 12 && raw[0] == 'C'.code.toByte() && raw[1] == 'r'.code.toByte()) {   // en-tête CRX3
            val hdr = (raw[8].toInt() and 0xFF) or ((raw[9].toInt() and 0xFF) shl 8) or
                ((raw[10].toInt() and 0xFF) shl 16) or ((raw[11].toInt() and 0xFF) shl 24)
            data = raw.copyOfRange(12 + hdr, raw.size)
        }
        val files = HashMap<String, ByteArray>()
        ZipInputStream(ByteArrayInputStream(data)).use { z ->
            var e = z.nextEntry
            while (e != null) { if (!e.isDirectory) files[e.name] = z.readBytes(); e = z.nextEntry }
        }
        val manifest = JSONObject(files["manifest.json"]?.toString(Charsets.UTF_8) ?: error("manifest.json introuvable"))
        val extName = manifest.optString("name", "Extension").takeUnless { it.startsWith("__MSG_") } ?: "Extension"
        val cs = manifest.optJSONArray("content_scripts") ?: error("Aucun content_script : cette extension n'est pas utilisable dans MyDM")
        var n = 0
        for (i in 0 until cs.length()) {
            val c = cs.getJSONObject(i)
            val matches = c.optJSONArray("matches")?.let { m -> List(m.length()) { m.getString(it) } } ?: listOf("<all_urls>")
            fun read(key: String) = c.optJSONArray(key)?.let { a ->
                (0 until a.length()).joinToString("\n") { files[a.getString(it).removePrefix("/")]?.toString(Charsets.UTF_8) ?: "" }
            } ?: ""
            val js = read("js"); val css = read("css")
            if (js.isBlank() && css.isBlank()) continue
            items.add(UserExt(UUID.randomUUID().toString(), if (cs.length() > 1) "$extName (${i + 1})" else extName,
                matches, js, css, true, "chrome"))
            n++
        }
        if (n == 0) error("Aucun script à injecter dans cette extension")
        save(); return n
    }

    // ───── Injection
    private const val SHIM = "window.chrome=window.chrome||{};chrome.runtime=chrome.runtime||{getURL:function(p){return p;},sendMessage:function(){},onMessage:{addListener:function(){}}};" +
        "chrome.storage=chrome.storage||{local:{get:function(k,cb){cb&&cb({});},set:function(o,cb){cb&&cb();}}};"

    private fun regexFor(pattern: String): Regex? = regexCache.getOrPut(pattern) {
        runCatching {
            if (pattern == "<all_urls>" || pattern == "*") return@runCatching Regex(".*")
            var s = pattern; val sb = StringBuilder("^")
            if (s.startsWith("*://")) { sb.append("https?://"); s = s.removePrefix("*://") }
            if (s.startsWith("*.")) { sb.append("(?:[^/]*\\.)?"); s = s.removePrefix("*.") }
            s.forEach { c -> sb.append(if (c == '*') ".*" else Regex.escape(c.toString())) }
            Regex(sb.toString(), RegexOption.IGNORE_CASE)
        }.getOrNull()
    }

    /** Code JS à évaluer pour cette URL (null s'il n'y a rien à injecter). */
    fun scriptFor(url: String): String? {
        if (!com.example.mydm.core.Prefs.extensionsOn || !url.startsWith("http")) return null
        val hits = items.filter { e -> e.enabled && e.matches.any { regexFor(it)?.matches(url) == true } }
        if (hits.isEmpty()) return null
        return hits.joinToString("\n") { e ->
            val css = if (e.css.isNotBlank())
                "var s=document.createElement('style');s.textContent=${JSONObject.quote(e.css)};(document.head||document.documentElement).appendChild(s);" else ""
            "(function(){try{${if (e.source == "chrome") SHIM else ""}$css\n${e.js}\n}catch(err){console.error('[MyDM ext: ${e.name.replace("'", "")}]',err);}})();"
        }
    }
}
