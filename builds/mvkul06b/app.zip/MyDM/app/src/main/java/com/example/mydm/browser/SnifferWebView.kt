package com.example.mydm.browser

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.content.Intent
import android.os.Message
import androidx.compose.runtime.mutableStateListOf
import com.example.mydm.core.Incoming
import com.example.mydm.ext.Extensions
import org.json.JSONObject
import org.json.JSONTokener
import android.webkit.*
import com.example.mydm.core.DetectedMedia
import com.example.mydm.core.MediaDetector
import com.example.mydm.core.MediaType
import com.example.mydm.core.Prefs
import kotlinx.coroutines.flow.MutableSharedFlow
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit

object SnifferScript {
    const val JS = """
(function(){
  if (window.__sniffer) return; window.__sniffer = true;
  const seen = new Set();
  const exts = /\.(mp4|webm|mkv|m3u8|mp3|m4a|apk|pdf|zip|rar)(\?|#|${'$'})/i;
  function send(u, kind){
    try { u = new URL(u, location.href).href; } catch(e){ return; }
    if (u.startsWith('blob:') || u.startsWith('data:') || seen.has(u)) return;
    seen.add(u); SnifferBridge.report(u, kind, document.title || '');
  }
  function scan(){
    document.querySelectorAll('video,audio').forEach(function(m){
      if (m.currentSrc) send(m.currentSrc,'media'); if (m.src) send(m.src,'media');
      m.querySelectorAll('source').forEach(function(s){ if (s.src) send(s.src,'media'); });
    });
    document.querySelectorAll('a[href]').forEach(function(a){ if (exts.test(a.href)) send(a.href,'link'); });
  }
  scan();
  new MutationObserver(scan).observe(document.documentElement,
    {childList:true, subtree:true, attributes:true, attributeFilter:['src','href']});
  document.addEventListener('play', function(e){ if (e.target && e.target.currentSrc) send(e.target.currentSrc,'media'); }, true);
  const xo = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function(m,u){ if (exts.test(u)) send(u,'xhr'); return xo.apply(this, arguments); };
  const f = window.fetch;
  window.fetch = function(i){ var u=(typeof i==='string')?i:(i&&i.url); if (u&&exts.test(u)) send(u,'fetch'); return f.apply(this, arguments); };
})();
"""
}

class JsBridge(private val onFound: (String, String, String) -> Unit) {
    @JavascriptInterface fun report(url: String, kind: String, title: String) = onFound(url, kind, title)
}

class SnifferWebViewClient(
    private val events: MutableSharedFlow<DetectedMedia>,
    private val userAgent: () -> String
) : WebViewClient() {
    private val seen = ConcurrentHashMap.newKeySet<String>()
    private val probed = ConcurrentHashMap.newKeySet<String>()
    @Volatile var currentPage: String? = null
    @Volatile var currentTitle: String? = null
    var onUrlChanged: (String) -> Unit = {}
    var onRequest: (String) -> Unit = {}
    var onPageReset: () -> Unit = {}

    private val http = OkHttpClient.Builder().connectTimeout(8, TimeUnit.SECONDS).readTimeout(8, TimeUnit.SECONDS).build()
    private val pool = ThreadPoolExecutor(2, 3, 30, TimeUnit.SECONDS, ArrayBlockingQueue(40), ThreadPoolExecutor.DiscardPolicy())

    private val staticExt = Regex("\\.(js|css|png|jpe?g|gif|webp|svg|ico|woff2?|ttf|html?|json|map|ts)(\\?|#|$)", RegexOption.IGNORE_CASE)
    private val hints = listOf("video", "mp4", "stream", "download", "/media/", "audio", "videoplayback")
    private val cdName = Regex("filename\\*?=(?:UTF-8'')?\"?([^\";]+)", RegexOption.IGNORE_CASE)

    override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
        currentPage = url; seen.clear(); probed.clear(); onUrlChanged(url); onPageReset()
    }

    /** Liens externes : magnet → onglet Torrent ; mailto/tel/intent/market… → autre appli. */
    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
        val u = request.url.toString()
        return when {
            u.startsWith("http://") || u.startsWith("https://") || u.startsWith("about:") ||
                u.startsWith("file:") || u.startsWith("data:") || u.startsWith("blob:") || u.startsWith("javascript:") -> false
            u.startsWith("magnet:") -> { Incoming.magnet = u; true }
            else -> {
                runCatching {
                    val i = if (u.startsWith("intent:")) Intent.parseUri(u, Intent.URI_INTENT_SCHEME)
                            else Intent(Intent.ACTION_VIEW, Uri.parse(u))
                    view.context.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
                true
            }
        }
    }
    override fun doUpdateVisitedHistory(view: WebView, url: String, isReload: Boolean) {
        if (url.startsWith("http")) onUrlChanged(url)
    }
    override fun onPageFinished(view: WebView, url: String) {
        currentTitle = view.title
        view.evaluateJavascript(SnifferScript.JS, null)
        Extensions.scriptFor(url)?.let { view.evaluateJavascript(it, null) }
    }

    // Thread d'arrière-plan : ne pas toucher à la View
    override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
        val url = request.url.toString()
        if (!url.startsWith("http")) return null
        onRequest(url)
        val type = MediaDetector.detect(url)
        if (type != null) emit(url, type)
        else if (request.method == "GET" && shouldProbe(url, request.requestHeaders)) probe(url)
        return null
    }

    private fun shouldProbe(url: String, headers: Map<String, String>): Boolean {
        val u = Uri.parse(url)
        val host = u.host?.lowercase() ?: return false
        if (host.endsWith("googlevideo.com") || host.contains("doubleclick") || host.contains("google-analytics")) return false
        if (staticExt.containsMatchIn(u.path ?: "")) return false
        // Un lecteur média envoie toujours un en-tête Range
        if (headers.keys.any { it.equals("Range", ignoreCase = true) }) return true
        val l = url.lowercase()
        return hints.any { it in l }
    }

    /** Détection par Content-Type / Content-Disposition (fichiers sans extension dans l'URL). */
    private fun probe(url: String) {
        if (!probed.add(url)) return
        val ref = currentPage; val ua = userAgent()
        pool.execute {
            runCatching {
                val rb = Request.Builder().url(url).header("Range", "bytes=0-0").header("User-Agent", ua)
                ref?.let { rb.header("Referer", it) }
                CookieManager.getInstance().getCookie(url)?.let { rb.header("Cookie", it) }
                http.newCall(rb.build()).execute().use { r ->
                    if (!r.isSuccessful) return@use
                    val ct = r.header("Content-Type")?.substringBefore(';')?.trim()?.lowercase() ?: ""
                    val cd = r.header("Content-Disposition")
                    val cdFile = cd?.let { cdName.find(it)?.groupValues?.get(1)?.trim() }?.let { Uri.decode(it) }
                    val type = typeFromMime(ct) ?: cdFile?.let { MediaDetector.detect("http://x/$it") } ?: return@use
                    val size = r.header("Content-Range")?.substringAfter('/')?.toLongOrNull()
                        ?: if (r.code == 200) r.header("Content-Length")?.toLongOrNull() else null
                    if ((type == MediaType.VIDEO || type == MediaType.AUDIO) && size != null && size < 100_000) return@use
                    val fileName = cdFile ?: Uri.parse(url).lastPathSegment?.takeIf { it.contains('.') }
                    emit(url, type, fileName, size)
                }
            }
        }
    }

    private fun typeFromMime(ct: String): MediaType? = when {
        ct == "video/mp2t" -> null
        ct.contains("mpegurl") -> MediaType.HLS
        ct.startsWith("video/") -> MediaType.VIDEO
        ct.startsWith("audio/") -> MediaType.AUDIO
        ct == "application/pdf" -> MediaType.PDF
        ct == "application/vnd.android.package-archive" -> MediaType.APK
        ct == "application/zip" || ct == "application/x-zip-compressed" ||
            ct == "application/x-rar-compressed" || ct == "application/x-7z-compressed" -> MediaType.ARCHIVE
        else -> null
    }

    fun emit(url: String, type: MediaType, name: String? = null, size: Long? = null) {
        if (!seen.add(url)) return
        events.tryEmit(DetectedMedia(url, type, currentPage, currentTitle, userAgent(),
            CookieManager.getInstance().getCookie(url), currentPage, name, size))
    }
}

class SnifferWebView(context: Context) : WebView(context) {
    val detectedMedia = MutableSharedFlow<DetectedMedia>(extraBufferCapacity = 64)

    // ── Outils développeur : console JS + journal des requêtes réseau de la page courante
    class ConsoleLine(val time: Long, val level: String, val text: String, val source: String)
    val console = mutableStateListOf<ConsoleLine>()
    val netLog: MutableList<String> = java.util.Collections.synchronizedList(ArrayList())
    fun logRequest(u: String) = synchronized(netLog) { if (netLog.size > 3000) netLog.subList(0, 500).clear(); netLog.add(u) }
    fun consoleText(): String = console.joinToString("\n") { l ->
        java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date(l.time)) + " [" + l.level + "] " + l.text +
            (if (l.source.isNotBlank()) "  (" + l.source + ")" else "")
    }
    fun networkText(): String = synchronized(netLog) { netLog.joinToString("\n") }

    /** Exécute du JS saisi dans la console et affiche le résultat. */
    fun runConsole(code: String) {
        console.add(ConsoleLine(System.currentTimeMillis(), "INPUT", "> $code", ""))
        evaluateJavascript(code) { r -> console.add(ConsoleLine(System.currentTimeMillis(), "RESULT", r ?: "undefined", "")) }
    }

    /** HTML rendu (DOM actuel) + toutes les URLs de ressources de la page. */
    fun captureSite(cb: (html: String, urls: List<String>, title: String) -> Unit) {
        evaluateJavascript(CAPTURE_JS) { raw ->
            runCatching {
                val o = JSONObject(JSONTokener(raw).nextValue() as String)
                val arr = o.getJSONArray("res")
                val urls = List(arr.length()) { arr.getString(it) } + synchronized(netLog) { netLog.toList() }
                cb(o.getString("html"), urls.distinct(), o.optString("title"))
            }
        }
    }

    var fileChooser: ((ValueCallback<Array<Uri>>, Intent) -> Unit)? = null
    var onImageLongPress: (String) -> Unit = {}
    // User-Agent mis en cache : le client le lit depuis un thread d'arrière-plan (jamais settings.* ici)
    @Volatile private var ua: String = ""
    private val client = SnifferWebViewClient(detectedMedia) { ua }
    private val defaultUa: String
    private val defaultWideViewPort: Boolean
    private val defaultOverview: Boolean

    var onUrlChanged: (String) -> Unit
        get() = client.onUrlChanged
        set(v) { client.onUrlChanged = v }
    var onTitleChanged: (String) -> Unit = {}
    var onProgress: (Int) -> Unit = {}
    /** Appelé quand une page ouvre une nouvelle fenêtre (target=_blank, window.open) : renvoie la WebView du nouvel onglet. */
    var windowRequested: () -> SnifferWebView? = { null }
    var closeRequested: () -> Unit = {}

    init {
        settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            setSupportMultipleWindows(true)
            javaScriptCanOpenWindowsAutomatically = true
            builtInZoomControls = true; displayZoomControls = false
        }
        client.onRequest = { logRequest(it) }
        client.onPageReset = { synchronized(netLog) { netLog.clear() }; post { console.clear() } }
        defaultUa = settings.userAgentString
        defaultWideViewPort = settings.useWideViewPort
        defaultOverview = settings.loadWithOverviewMode
        applyPrefs()
        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
        webViewClient = client
        webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) = onProgress(newProgress)
            override fun onReceivedTitle(view: WebView, title: String?) { title?.let(onTitleChanged) }
            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
                if (Prefs.blockPopups && !isUserGesture) return false
                val child = windowRequested() ?: return false
                (resultMsg.obj as WebView.WebViewTransport).webView = child
                resultMsg.sendToTarget()
                return true
            }
            override fun onCloseWindow(window: WebView) = closeRequested()
            override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                console.add(ConsoleLine(System.currentTimeMillis(), m.messageLevel().name, m.message(),
                    m.sourceId().orEmpty().substringAfterLast('/') + ":" + m.lineNumber()))
                if (console.size > 1000) console.removeAt(0)
                return true
            }
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                val h = fileChooser ?: return false
                h(cb, p.createIntent()); return true
            }
        }
        addJavascriptInterface(JsBridge { url, kind, title ->
            val type = MediaDetector.detect(url) ?: if (kind == "media") MediaType.VIDEO else return@JsBridge
            client.emit(url, type, if (kind == "media") title.takeIf { it.isNotBlank() } else null)
        }, "SnifferBridge")
        setOnLongClickListener {
            val r = hitTestResult
            if ((r.type == HitTestResult.IMAGE_TYPE || r.type == HitTestResult.SRC_IMAGE_ANCHOR_TYPE) && r.extra != null) {
                onImageLongPress(r.extra!!); true
            } else false
        }
        setDownloadListener { url, _, disposition, mime, length ->
            val type = MediaDetector.detect(url)
                ?: if (mime?.startsWith("video") == true) MediaType.VIDEO
                else if (mime?.startsWith("audio") == true) MediaType.AUDIO else MediaType.ARCHIVE
            client.emit(url, type, URLUtil.guessFileName(url, disposition, mime), length.takeIf { it > 0 })
        }
    }

    /** Applique les réglages. Thread principal uniquement. Renvoie true si le User-Agent a changé. */
    fun applyPrefs(): Boolean {
        val desktop = Prefs.desktopMode
        val newUa = if (desktop) DESKTOP_UA else Prefs.userAgent.ifBlank { defaultUa }
        val changed = newUa != ua
        ua = newUa
        settings.userAgentString = newUa
        settings.useWideViewPort = if (desktop) true else defaultWideViewPort
        settings.loadWithOverviewMode = if (desktop) true else defaultOverview
        settings.javaScriptEnabled = Prefs.jsEnabled
        settings.loadsImagesAutomatically = Prefs.loadImages
        settings.textZoom = Prefs.textZoom
        WebView.setWebContentsDebuggingEnabled(Prefs.debugWeb)
        return changed
    }

    companion object {
        const val CAPTURE_JS = """(function(){var u=new Set();
function add(x){try{x=new URL(x,location.href).href;if(/^https?:/.test(x))u.add(x);}catch(e){}}
performance.getEntriesByType('resource').forEach(function(e){add(e.name)});
document.querySelectorAll('link[href],script[src],img[src],img[data-src],source[src],video[src],video[poster],audio[src],iframe[src]').forEach(function(n){add(n.href||n.src||n.getAttribute('data-src')||n.poster)});
return JSON.stringify({html:'<!DOCTYPE html>'+document.documentElement.outerHTML,res:Array.from(u),title:document.title});})()"""
        const val DESKTOP_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    }
}
