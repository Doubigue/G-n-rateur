package com.example.mydm.downloader

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.mydm.App
import com.example.mydm.MainActivity
import com.example.mydm.core.DownloadTask
import com.example.mydm.core.Prefs
import com.example.mydm.core.formatSize
import kotlinx.coroutines.*

class DownloadService : Service() {
    private val app get() = application as App
    private val engine get() = app.downloadEngine
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    @Volatile private var started = false

    override fun onBind(i: Intent?) = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Téléchargements", NotificationManager.IMPORTANCE_LOW).apply {
            setShowBadge(true)
        })
        startForeground(NOTIF_ID, build(emptyList(), emptyMap()), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        scope.launch {
            while (isActive) {
                delay(1000)
                val active = withContext(Dispatchers.IO) { app.db.downloadDao().activeNow() }
                nm.notify(NOTIF_ID, build(active, engine.progress.value))
                if (started && engine.activeCount == 0) stopSelf()
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val id = intent?.getStringExtra(EXTRA_ID)
        when (intent?.action) {
            ACTION_START -> id?.let { engine.start(it); started = true }
            ACTION_PAUSE -> id?.let(engine::pause)
            ACTION_PAUSE_ALL -> engine.pauseAll()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() { scope.cancel() }

    /**
     * Notification : nombre de téléchargements en cours, % global, et pour chacun des N premiers
     * (réglage, 5 par défaut) son nom, son % et sa taille. Les suivants sont comptés dans « +N autres »
     * et dans la pastille numérique (setNumber) de l'icône de l'appli.
     */
    private fun build(active: List<DownloadTask>, prog: Map<String, Progress>): Notification {
        val count = active.size
        var done = 0L; var total = 0L; var speed = 0L
        active.forEach { t -> prog[t.id]?.let { p -> if (p.total > 0) { done += p.downloaded * 1000 / p.total; total += 1000 }; speed += p.speedBps } }
        val pct = if (total > 0) (done * 100 / total).toInt() else 0

        val max = Prefs.notifLines.coerceIn(1, 5)
        val lines = active.take(max).map { t ->
            val p = prog[t.id]
            val name = if (t.fileName.length > 30) t.fileName.take(29) + "…" else t.fileName
            val parts = mutableListOf<String>()
            if (p == null || p.total <= 0) parts += if (t.status.name == "QUEUED") "en attente" else "…"
            else {
                if (Prefs.notifPercent) parts += "${(p.downloaded * 100 / p.total).toInt()}%"
                if (Prefs.notifSizes) {
                    if (p.exact) parts += "${formatSize(p.downloaded)} / ${formatSize(p.total)}"
                    else if (t.totalBytes > 0) parts += formatSize(t.totalBytes)
                }
            }
            if (t.status.name == "MERGING") parts += "finalisation"
            "$name • " + parts.joinToString(" • ")
        }
        val title = when (count) {
            0 -> "MyDM"
            1 -> "1 téléchargement en cours" + if (Prefs.notifPercent) " • $pct%" else ""
            else -> "$count téléchargements en cours" + if (Prefs.notifPercent) " • $pct%" else ""
        }
        val style = NotificationCompat.InboxStyle().setBigContentTitle(title)
        lines.forEach { style.addLine(it) }
        if (count > max) style.setSummaryText("+${count - max} autre(s)")

        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP), PendingIntent.FLAG_IMMUTABLE)
        val pauseAll = PendingIntent.getService(this, 1, Intent(this, DownloadService::class.java).setAction(ACTION_PAUSE_ALL),
            PendingIntent.FLAG_IMMUTABLE)

        return NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(title)
            .setContentText(lines.firstOrNull() ?: "Préparation…")
            .setSubText(if (speed > 0) "${speed / 1024} Ko/s" else null)
            .setStyle(style)
            .setNumber(count)                                   // pastille numérique
            .setProgress(100, pct, total <= 0)
            .setOngoing(true).setOnlyAlertOnce(true).setContentIntent(open)
            .addAction(0, "Tout mettre en pause", pauseAll)
            .build()
    }

    companion object {
        const val CH = "downloads"; const val NOTIF_ID = 42
        const val ACTION_START = "start"; const val ACTION_PAUSE = "pause"; const val ACTION_PAUSE_ALL = "pause_all"
        const val EXTRA_ID = "id"
        fun start(ctx: Context, taskId: String) = ContextCompat.startForegroundService(
            ctx, Intent(ctx, DownloadService::class.java).setAction(ACTION_START).putExtra(EXTRA_ID, taskId))
    }
}
