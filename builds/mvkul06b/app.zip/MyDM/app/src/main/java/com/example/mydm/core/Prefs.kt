package com.example.mydm.core

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray

enum class SearchEngine(val label: String, val template: String) {
    GOOGLE("Google", "https://www.google.com/search?q="),
    DUCKDUCKGO("DuckDuckGo", "https://duckduckgo.com/?q="),
    BING("Bing", "https://www.bing.com/search?q="),
    ECOSIA("Ecosia", "https://www.ecosia.org/search?q=")
}

/** Réglages de l'application (SharedPreferences + état Compose, donc l'UI se met à jour seule). */
object Prefs {
    const val DEFAULT_HOME = "https://www.google.com"
    private lateinit var sp: SharedPreferences

    var homeUrl by mutableStateOf(DEFAULT_HOME); private set
    var searchEngine by mutableStateOf(SearchEngine.GOOGLE); private set
    var desktopMode by mutableStateOf(false); private set
    var blockPopups by mutableStateOf(false); private set
    var restoreTabs by mutableStateOf(true); private set
    var maxSegments by mutableIntStateOf(16); private set

    // ── Téléchargements
    var maxParallel by mutableIntStateOf(3); private set        // téléchargements simultanés
    var speedLimitKb by mutableIntStateOf(0); private set       // 0 = illimité (Ko/s)
    var retries by mutableIntStateOf(3); private set
    var wifiOnly by mutableStateOf(false); private set
    // ── Notification
    var notifLines by mutableIntStateOf(5); private set         // téléchargements listés (les autres → pastille)
    var notifPercent by mutableStateOf(true); private set
    var notifSizes by mutableStateOf(true); private set
    // ── Navigateur avancé
    var userAgent by mutableStateOf(""); private set
    var jsEnabled by mutableStateOf(true); private set
    var loadImages by mutableStateOf(true); private set
    var textZoom by mutableIntStateOf(100); private set
    var debugWeb by mutableStateOf(false); private set
    var extensionsOn by mutableStateOf(true); private set

    fun init(ctx: Context) {
        sp = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
        homeUrl = sp.getString("home", DEFAULT_HOME) ?: DEFAULT_HOME
        searchEngine = runCatching { SearchEngine.valueOf(sp.getString("engine", "GOOGLE")!!) }.getOrDefault(SearchEngine.GOOGLE)
        desktopMode = sp.getBoolean("desktop", false)
        blockPopups = sp.getBoolean("blockPopups", false)
        restoreTabs = sp.getBoolean("restoreTabs", true)
        maxSegments = sp.getInt("segments", 16)
        maxParallel = sp.getInt("parallel", 3)
        speedLimitKb = sp.getInt("speedKb", 0)
        retries = sp.getInt("retries", 3)
        wifiOnly = sp.getBoolean("wifiOnly", false)
        notifLines = sp.getInt("notifLines", 5)
        notifPercent = sp.getBoolean("notifPercent", true)
        notifSizes = sp.getBoolean("notifSizes", true)
        userAgent = sp.getString("ua", "") ?: ""
        jsEnabled = sp.getBoolean("js", true)
        loadImages = sp.getBoolean("images", true)
        textZoom = sp.getInt("zoom", 100)
        debugWeb = sp.getBoolean("debugWeb", false)
        extensionsOn = sp.getBoolean("extOn", true)
    }

    fun updateMaxParallel(v: Int) { maxParallel = v; sp.edit().putInt("parallel", v).apply() }
    fun updateSpeedLimit(v: Int) { speedLimitKb = v; sp.edit().putInt("speedKb", v).apply() }
    fun updateRetries(v: Int) { retries = v; sp.edit().putInt("retries", v).apply() }
    fun updateWifiOnly(v: Boolean) { wifiOnly = v; sp.edit().putBoolean("wifiOnly", v).apply() }
    fun updateNotifLines(v: Int) { notifLines = v; sp.edit().putInt("notifLines", v).apply() }
    fun updateNotifPercent(v: Boolean) { notifPercent = v; sp.edit().putBoolean("notifPercent", v).apply() }
    fun updateNotifSizes(v: Boolean) { notifSizes = v; sp.edit().putBoolean("notifSizes", v).apply() }
    fun updateUserAgent(v: String) { userAgent = v.trim(); sp.edit().putString("ua", userAgent).apply() }
    fun updateJs(v: Boolean) { jsEnabled = v; sp.edit().putBoolean("js", v).apply() }
    fun updateLoadImages(v: Boolean) { loadImages = v; sp.edit().putBoolean("images", v).apply() }
    fun updateTextZoom(v: Int) { textZoom = v; sp.edit().putInt("zoom", v).apply() }
    fun updateDebugWeb(v: Boolean) { debugWeb = v; sp.edit().putBoolean("debugWeb", v).apply() }
    fun updateExtensionsOn(v: Boolean) { extensionsOn = v; sp.edit().putBoolean("extOn", v).apply() }

    fun resetAll(ctx: Context) {
        val tabs = sp.getString("tabs", "[]"); val idx = sp.getInt("tabIndex", 0)
        sp.edit().clear().putString("tabs", tabs).putInt("tabIndex", idx).apply()
        init(ctx)
    }

    fun updateHomeUrl(v: String) {
        val t = v.trim().ifEmpty { DEFAULT_HOME }
        homeUrl = if (t.startsWith("http://") || t.startsWith("https://")) t else "https://$t"
        sp.edit().putString("home", homeUrl).apply()
    }
    fun updateSearchEngine(v: SearchEngine) { searchEngine = v; sp.edit().putString("engine", v.name).apply() }
    fun updateDesktopMode(v: Boolean) { desktopMode = v; sp.edit().putBoolean("desktop", v).apply() }
    fun updateBlockPopups(v: Boolean) { blockPopups = v; sp.edit().putBoolean("blockPopups", v).apply() }
    fun updateRestoreTabs(v: Boolean) { restoreTabs = v; sp.edit().putBoolean("restoreTabs", v).apply() }
    fun updateMaxSegments(v: Int) { maxSegments = v; sp.edit().putInt("segments", v).apply() }

    /** Transforme ce que tape l'utilisateur en URL : adresse, domaine ou recherche. */
    fun resolveInput(input: String): String {
        val t = input.trim()
        return when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            "." in t && " " !in t -> "https://$t"
            else -> searchEngine.template + android.net.Uri.encode(t)
        }
    }

    // ── Onglets ouverts (restaurés au démarrage si l'option est active)
    fun saveTabs(urls: List<String>, current: Int) {
        sp.edit().putString("tabs", JSONArray(urls).toString()).putInt("tabIndex", current).apply()
    }
    fun savedTabs(): List<String> = runCatching {
        val a = JSONArray(sp.getString("tabs", "[]"))
        List(a.length()) { a.getString(it) }.filter { it.startsWith("http") }
    }.getOrDefault(emptyList())
    fun savedTabIndex(): Int = sp.getInt("tabIndex", 0)
}
