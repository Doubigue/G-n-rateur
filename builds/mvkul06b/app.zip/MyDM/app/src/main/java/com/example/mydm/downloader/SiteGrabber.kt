package com.example.mydm.downloader

import android.webkit.CookieManager
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.net.URI
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Construit un ZIP des composants d'une page visitée :
 *   index.html (liens réécrits vers les fichiers locaux, ouvrable hors-ligne), original.html (HTML rendu tel quel),
 *   assets/{css,js,img,fonts,media,other}/..., console.txt, network.txt, resources.txt.
 */
class SiteGrabber(private val client: OkHttpClient) {
    private val MAX_FILE = 25L * 1024 * 1024
    private val MAX_RES = 400

    private fun kindOf(url: String, mime: String): String {
        val ext = url.substringBefore('?').substringBefore('#').substringAfterLast('.', "").lowercase()
        return when {
            ext == "css" || mime.contains("text/css") -> "css"
            ext in setOf("js", "mjs") || mime.contains("javascript") -> "js"
            ext in setOf("png", "jpg", "jpeg", "gif", "webp", "svg", "ico", "avif", "bmp") || mime.startsWith("image/") -> "img"
            ext in setOf("woff", "woff2", "ttf", "otf", "eot") || mime.contains("font") -> "fonts"
            ext in setOf("mp4", "webm", "mp3", "m4a", "ogg", "wav") || mime.startsWith("video/") || mime.startsWith("audio/") -> "media"
            else -> "other"
        }
    }

    private fun resolve(base: String, ref: String): String? = runCatching {
        val r = ref.trim()
        if (r.isEmpty() || r.startsWith("data:") || r.startsWith("blob:") || r.startsWith("javascript:") || r.startsWith("#")) return null
        URI(base).resolve(r.replace(" ", "%20")).toString().substringBefore('#')
    }.getOrNull()

    private fun localName(url: String, kind: String): String {
        val last = url.substringBefore('?').substringAfterLast('/').ifBlank { "file" }
        val clean = last.replace(Regex("[^A-Za-z0-9._-]"), "_").takeLast(60)
        return "assets/$kind/%08x_%s".format(url.hashCode(), clean)
    }

    /**
     * @param work dossier de travail (supprimé par l'appelant)
     * @return le fichier ZIP final
     */
    suspend fun build(
        work: File, pageUrl: String, html: String, urls: List<String>,
        consoleText: String, networkText: String, ua: String,
        onProgress: (done: Int, total: Int) -> Unit
    ): File = withContext(Dispatchers.IO) {
        val resDir = File(work, "res").apply { mkdirs() }
        val list = urls.mapNotNull { resolve(pageUrl, it) }.filter { it.startsWith("http") }.distinct().take(MAX_RES)

        val map = HashMap<String, String>()      // url absolue → chemin local dans le zip
        val skipped = StringBuilder()
        var done = 0
        val gate = Semaphore(6)
        onProgress(0, list.size)

        coroutineScope {
            list.map { u ->
                async {
                    gate.withPermit {
                        runCatching {
                            ensureActive()
                            val rb = Request.Builder().url(u).header("User-Agent", ua).header("Referer", pageUrl)
                            CookieManager.getInstance().getCookie(u)?.let { rb.header("Cookie", it) }
                            client.newCall(rb.build()).execute().use { r ->
                                if (!r.isSuccessful) { synchronized(skipped) { skipped.append("HTTP ${r.code}  $u\n") }; return@use }
                                val len = r.header("Content-Length")?.toLongOrNull() ?: -1
                                if (len > MAX_FILE) { synchronized(skipped) { skipped.append("trop gros  $u\n") }; return@use }
                                val mime = r.header("Content-Type")?.substringBefore(';')?.lowercase() ?: ""
                                val local = localName(u, kindOf(u, mime))
                                val f = File(resDir, local.replace('/', '_'))
                                var total = 0L
                                f.outputStream().use { out ->
                                    val buf = ByteArray(32 * 1024); val ins = r.body!!.byteStream()
                                    while (true) {
                                        val n = ins.read(buf); if (n < 0) break
                                        total += n; if (total > MAX_FILE) break
                                        out.write(buf, 0, n)
                                    }
                                }
                                if (total > MAX_FILE) { f.delete(); synchronized(skipped) { skipped.append("trop gros  $u\n") } }
                                else synchronized(map) { map[u] = local }
                            }
                        }.onFailure { e ->
                            if (e is CancellationException) throw e
                            synchronized(skipped) { skipped.append("échec (${e.message})  $u\n") }
                        }
                        onProgress(synchronized(this@SiteGrabber) { ++done }, list.size)
                    }
                }
            }.awaitAll()
        }

        // ── Réécriture du HTML : src/href/poster/data-src et url(...) inline
        val attr = Regex("""(?i)(\b(?:src|href|poster|data-src)\s*=\s*)(["'])(.*?)\2""")
        var index = attr.replace(html) { m ->
            val local = resolve(pageUrl, m.groupValues[3])?.let { map[it] }
            if (local != null) m.groupValues[1] + m.groupValues[2] + local + m.groupValues[2] else m.value
        }
        index = index.replace(Regex("""(?i)\s+integrity\s*=\s*(["']).*?\1"""), "")
        index = rewriteCssUrls(index, pageUrl, map, "")

        val zipFile = File(work, "site.zip")
        ZipOutputStream(zipFile.outputStream().buffered()).use { z ->
            fun text(name: String, s: String) { z.putNextEntry(ZipEntry(name)); z.write(s.toByteArray()); z.closeEntry() }
            text("index.html", index)
            text("original.html", html)
            text("console.txt", consoleText.ifBlank { "(console vide)" })
            text("network.txt", networkText.ifBlank { "(aucune requête)" })
            text("resources.txt", list.joinToString("\n") { u -> (map[u] ?: "—") + "  ←  " + u } +
                (if (skipped.isNotEmpty()) "\n\n# Non téléchargés\n$skipped" else ""))
            map.forEach { (u, local) ->
                val f = File(resDir, local.replace('/', '_'))
                if (!f.exists()) return@forEach
                z.putNextEntry(ZipEntry(local))
                if (local.startsWith("assets/css/")) z.write(rewriteCssUrls(f.readText(), u, map, "../").toByteArray())
                else f.inputStream().use { it.copyTo(z, 64 * 1024) }
                z.closeEntry()
            }
        }
        zipFile
    }

    /** Réécrit url(...) d'un CSS/HTML vers les fichiers locaux. prefix = "../" depuis assets/css/, "" depuis la racine. */
    private fun rewriteCssUrls(css: String, base: String, map: Map<String, String>, prefix: String): String {
        val re = Regex("""url\(\s*(['"]?)(.*?)\1\s*\)""")
        return re.replace(css) { m ->
            val local = resolve(base, m.groupValues[2])?.let { map[it] }
            if (local == null) m.value
            else "url(" + m.groupValues[1] + (if (prefix.isEmpty()) local else prefix + local.removePrefix("assets/")) + m.groupValues[1] + ")"
        }
    }
}
