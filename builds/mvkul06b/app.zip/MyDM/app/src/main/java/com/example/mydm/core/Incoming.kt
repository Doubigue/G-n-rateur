package com.example.mydm.core

import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Liens reçus de l'extérieur (autre appli, lien partagé, magnet, .torrent). Consommés par l'UI. */
object Incoming {
    var url by mutableStateOf<String?>(null)
    var magnet by mutableStateOf<String?>(null)
    var torrentFile by mutableStateOf<String?>(null)

    private val urlRegex = Regex("""https?://[^\s<>"']+""")

    fun handle(intent: Intent?) {
        intent ?: return
        val data: Uri? = intent.data
        when (intent.action) {
            Intent.ACTION_VIEW -> {
                if (data == null) return
                val s = data.toString()
                val type = intent.type ?: ""
                when {
                    data.scheme == "magnet" -> magnet = s
                    type == "application/x-bittorrent" || (data.path ?: "").endsWith(".torrent", true) ->
                        torrentFile = s
                    data.scheme == "http" || data.scheme == "https" -> url = s
                }
            }
            Intent.ACTION_SEND -> {
                val text = intent.getStringExtra(Intent.EXTRA_TEXT)?.trim() ?: return
                when {
                    text.startsWith("magnet:") -> magnet = text
                    else -> url = urlRegex.find(text)?.value ?: Prefs.resolveInput(text)
                }
            }
        }
    }
}
