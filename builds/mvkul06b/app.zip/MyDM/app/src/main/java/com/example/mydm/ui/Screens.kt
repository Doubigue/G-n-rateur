package com.example.mydm.ui

import android.content.Intent
import android.net.Uri
import java.util.Date
import java.text.DateFormat
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.RoundedCornerShape
import android.view.ViewGroup
import androidx.compose.runtime.snapshots.SnapshotStateList
import android.util.Size
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.mydm.App
import com.example.mydm.browser.SnifferWebView
import com.example.mydm.core.*
import com.example.mydm.downloader.DownloadService
import com.example.mydm.torrent.TorrentFile
import com.example.mydm.torrent.TorrentService
import com.example.mydm.whatsapp.ScanResult
import com.example.mydm.whatsapp.StatusItem
import com.example.mydm.whatsapp.WaApp
import com.frostwire.jlibtorrent.TorrentInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable private fun appInstance() = LocalContext.current.applicationContext as App

// ───────────── Téléchargements ─────────────
private fun statusFr(s: Status) = when (s) {
    Status.QUEUED -> "En attente"; Status.RUNNING -> "En cours"; Status.PAUSED -> "En pause"
    Status.MERGING -> "Finalisation"; Status.COMPLETED -> "Terminé"; Status.FAILED -> "Échec"
}

@Composable
fun DownloadsScreen() {
    val ctx = LocalContext.current; val app = appInstance()
    val tasks by app.db.downloadDao().observeTasks().collectAsStateWithLifecycle(emptyList())
    val progress by app.downloadEngine.progress.collectAsStateWithLifecycle()
    var filter by remember { mutableStateOf<Folder?>(null) }

    val activeCount = tasks.count { it.status == Status.RUNNING || it.status == Status.QUEUED || it.status == Status.MERGING }
    val speed = progress.values.sumOf { it.speedBps }
    val shown = tasks.filter { filter == null || it.resolvedFolder() == filter }

    Column(Modifier.fillMaxSize()) {
        // Résumé + « tout mettre en pause »
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(if (activeCount > 0) "$activeCount en cours" + (if (speed > 0) " • ${speed / 1024} Ko/s" else "") else "Téléchargements",
                color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            if (activeCount > 0) TextButton({
                ctx.startService(Intent(ctx, DownloadService::class.java).setAction(DownloadService.ACTION_PAUSE_ALL))
            }) { Text("Tout pauser") }
        }
        // Dossiers
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(filter == null, { filter = null }, label = { Text("Tous (${tasks.size})") })
            Folder.entries.forEach { f ->
                val n = tasks.count { it.resolvedFolder() == f }
                FilterChip(filter == f, { filter = if (filter == f) null else f }, label = { Text("${f.icon} ${f.label} ($n)") })
            }
        }
        if (shown.isEmpty()) { Centered(if (tasks.isEmpty()) "Aucun téléchargement" else "Dossier vide"); return@Column }

        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(shown, key = { it.id }) { t ->
                val p = progress[t.id]
                val total = p?.total ?: t.totalBytes
                val frac = if (t.status == Status.COMPLETED) 1f else if (p != null && total > 0) p.downloaded.toFloat() / total else 0f
                val folder = t.resolvedFolder()
                Column(Modifier.fillMaxWidth().glass().padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(folder.icon, fontSize = 20.sp)
                        Spacer(Modifier.width(8.dp))
                        Text(t.fileName, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    if (t.status != Status.COMPLETED) LinearProgressIndicator({ frac }, Modifier.fillMaxWidth().padding(vertical = 8.dp))
                    val sizeTxt = when {
                        p != null && p.exact && p.total > 0 -> "${formatSize(p.downloaded)} / ${formatSize(p.total)}"
                        t.totalBytes > 0 -> formatSize(t.totalBytes)
                        else -> null
                    }
                    Text(buildString {
                        append(statusFr(t.status))
                        if (t.status != Status.COMPLETED) append(" • ${(frac * 100).toInt()}%")
                        sizeTxt?.let { append(" • $it") }
                        p?.takeIf { it.speedBps > 0 }?.let { append(" • ${it.speedBps / 1024} Ko/s") }
                        append(" • ${folder.label}")
                        t.error?.let { append("\n$it") }
                    }, color = if (t.status == Status.FAILED) Color(0xFFFF8A80) else Muted, fontSize = 12.sp)
                    Row {
                        when (t.status) {
                            Status.RUNNING, Status.QUEUED -> TextButton({
                                ctx.startService(Intent(ctx, DownloadService::class.java)
                                    .setAction(DownloadService.ACTION_PAUSE).putExtra(DownloadService.EXTRA_ID, t.id))
                            }) { Text("Pause") }
                            Status.PAUSED, Status.FAILED -> TextButton({ DownloadService.start(ctx, t.id) }) { Text("Reprendre") }
                            Status.COMPLETED -> TextButton({
                                t.resultUri?.let { u ->
                                    val uri = Uri.parse(u)
                                    runCatching {
                                        ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, ctx.contentResolver.getType(uri))
                                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
                                    }
                                }
                            }) { Text("Ouvrir") }
                            else -> {}
                        }
                        TextButton({ app.downloadEngine.cancel(t.id) }) { Text("Supprimer") }
                    }
                }
            }
        }
    }
}

// ───────────── Statuts WhatsApp ─────────────
@Composable
fun StatusScreen() {
    val ctx = LocalContext.current; val repo = appInstance().statusRepo
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf(WaApp.WHATSAPP) }
    var scan by remember { mutableStateOf<ScanResult?>(null) }
    var granted by remember { mutableStateOf(repo.hasGrant(tab)) }
    var loading by remember { mutableStateOf(false) }
    var reload by remember { mutableIntStateOf(0) }

    LaunchedEffect(tab, reload) {
        granted = repo.hasGrant(tab)
        scan = null
        if (granted) {
            loading = true
            scan = runCatching { repo.scan(tab) }.getOrElse { ScanResult(emptyList(), "Erreur : ${it.message}") }
            loading = false
        }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) { repo.persistGrant(tab, uri); reload++ }
    }

    Column(Modifier.fillMaxSize()) {
        TabRow(WaApp.entries.indexOf(tab), containerColor = Bg) {
            WaApp.entries.forEach { a -> Tab(tab == a, { tab = a }, text = { Text(a.label) }) }
        }
        val s = scan ?: ScanResult(emptyList(), "")
        when {
            !granted -> Centered("Autorisez l'accès au dossier Android/media/${tab.pkg}\n(appuyez sur « Utiliser ce dossier »)") {
                Button({ picker.launch(repo.initialUri(tab)) }) { Text("Autoriser l'accès") }
            }
            loading || scan == null -> Centered("Recherche des statuts…")
            s.items.isEmpty() -> Centered(s.message) {
                Row {
                    Button({ reload++ }) { Text("Actualiser") }
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton({ picker.launch(repo.initialUri(tab)) }) { Text("Changer de dossier") }
                }
            }
            else -> LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    Row {
                        TextButton({ reload++ }) { Text("Actualiser (${s.items.size})") }
                        TextButton({ picker.launch(repo.initialUri(tab)) }) { Text("Changer de dossier") }
                    }
                }
                if (s.info.isNotBlank()) item { Text(s.info, color = Muted, fontSize = 11.sp) }
                items(s.items, key = { it.uri.toString() }) { st ->
                    val thumb by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, st.uri) {
                        value = withContext(Dispatchers.IO) {
                            runCatching { ctx.contentResolver.loadThumbnail(st.uri, Size(256, 256), null).asImageBitmap() }.getOrNull()
                        }
                    }
                    Row(Modifier.fillMaxWidth().glass().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(72.dp).background(Color(0x22FFFFFF))) {
                            thumb?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
                        }
                        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                            Text(if (st.isVideo) "Vidéo" else "Photo", color = Accent)
                            Text("${st.size / 1024} Ko • ${fmtDate(st.modified)}", color = Muted, fontSize = 12.sp)
                        }
                        Button({
                            scope.launch {
                                runCatching { repo.save(st) }
                                    .onSuccess { Toast.makeText(ctx, "Enregistré dans Vidéo made", Toast.LENGTH_SHORT).show() }
                                    .onFailure { Toast.makeText(ctx, "Échec : ${it.message}", Toast.LENGTH_LONG).show() }
                            }
                        }) { Text("Enregistrer") }
                    }
                }
            }
        }
    }
}

// ───────────── Torrent ─────────────
@Composable
fun TorrentScreen() {
    val ctx = LocalContext.current; val engine = appInstance().torrentEngine
    val scope = rememberCoroutineScope()
    val states by engine.states.collectAsStateWithLifecycle()
    var source by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<TorrentInfo?>(null) }
    var files by remember { mutableStateOf<List<TorrentFile>>(emptyList()) }
    var selected by remember { mutableStateOf<Set<Int>>(emptySet()) }

    fun inspect(src: String) = scope.launch {
        busy = true
        runCatching { engine.inspect(src) }
            .onSuccess { ti -> pending = ti; files = engine.listFiles(ti); selected = files.map { it.index }.toSet() }
            .onFailure { Toast.makeText(ctx, "Erreur : ${it.message}", Toast.LENGTH_LONG).show() }
        busy = false
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { inspect(it.toString()) }
    }
    // Liens reçus d'une autre appli (magnet:, .torrent)
    val inMagnet = Incoming.magnet
    LaunchedEffect(inMagnet) { if (inMagnet != null) { source = inMagnet; Incoming.magnet = null; inspect(inMagnet) } }
    val inFile = Incoming.torrentFile
    LaunchedEffect(inFile) { if (inFile != null) { Incoming.torrentFile = null; inspect(inFile) } }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Column(Modifier.fillMaxWidth().glass().padding(14.dp)) {
                OutlinedTextField(source, { source = it }, Modifier.fillMaxWidth(), label = { Text("Lien magnet:?xt=urn:btih:…") })
                Row {
                    Button({ inspect(source.trim()) }, enabled = source.startsWith("magnet:") && !busy) { Text("Analyser") }
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton({ picker.launch(arrayOf("*/*")) }, enabled = !busy) { Text("Fichier .torrent") }
                }
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))
            }
        }
        pending?.let { ti ->
            item {
                Column(Modifier.fillMaxWidth().glass().padding(14.dp)) {
                    Text(ti.name() + "  →  🧲 Torrent", color = Color.White)
                    files.forEach { f ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(f.index in selected, { c -> selected = if (c) selected + f.index else selected - f.index })
                            Text("${f.path}  (${f.size / 1_048_576} Mo)", color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
                        }
                    }
                    Button({
                        engine.download(ti, selected); TorrentService.start(ctx); pending = null
                    }, enabled = selected.isNotEmpty()) { Text("Télécharger") }
                }
            }
        }
        items(states.values.toList(), key = { it.infoHash }) { s ->
            Column(Modifier.fillMaxWidth().glass().padding(14.dp)) {
                Text(s.name, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                LinearProgressIndicator({ s.progress }, Modifier.fillMaxWidth().padding(vertical = 8.dp))
                Text("${(s.progress * 100).toInt()}% • ${s.state} • ↓ ${s.downloadRate / 1024} Ko/s • ↑ ${s.uploadRate / 1024} Ko/s • ${s.peers} pairs",
                    color = Muted, fontSize = 12.sp)
                Row {
                    TextButton({ engine.pause(s.infoHash) }) { Text("Pause") }
                    TextButton({ engine.resume(s.infoHash) }) { Text("Reprendre") }
                    TextButton({ engine.remove(s.infoHash) }) { Text("Retirer") }
                }
            }
        }
    }
}

@Composable
private fun Centered(text: String, extra: @Composable () -> Unit = {}) =
    Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Text(text, color = Muted); Spacer(Modifier.height(12.dp)); extra()
    }

private fun fmtDate(ms: Long): String =
    if (ms <= 0) "date inconnue" else DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(ms))
