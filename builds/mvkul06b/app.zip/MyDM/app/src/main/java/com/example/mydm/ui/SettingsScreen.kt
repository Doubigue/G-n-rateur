package com.example.mydm.ui

import android.webkit.CookieManager
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.mydm.browser.BrowserManager
import com.example.mydm.core.Prefs
import com.example.mydm.core.SearchEngine

@Composable
fun SettingsScreen(manager: BrowserManager, onBack: () -> Unit) {
    val ctx = LocalContext.current
    fun toast(m: String) = Toast.makeText(ctx, m, Toast.LENGTH_SHORT).show()
    var home by remember { mutableStateOf(Prefs.homeUrl) }
    var ua by remember { mutableStateOf(Prefs.userAgent) }
    var showExt by remember { mutableStateOf(false) }
    if (showExt) { ExtensionsScreen { showExt = false }; return }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 4.dp, top = 8.dp, end = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onBack) { Text("◀", fontSize = 18.sp) }
            Text("Paramètres", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {

            item {
                Section("Navigateur") {
                    Text("Page d'accueil", color = Color.White)
                    OutlinedTextField(home, { home = it }, Modifier.fillMaxWidth().padding(top = 6.dp), singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { Prefs.updateHomeUrl(home); home = Prefs.homeUrl; toast("Enregistré") }))
                    Row {
                        TextButton({ Prefs.updateHomeUrl(home); home = Prefs.homeUrl; toast("Enregistré") }) { Text("Enregistrer") }
                        TextButton({ Prefs.updateHomeUrl(manager.current.url); home = Prefs.homeUrl; toast("Page actuelle définie") }) { Text("Utiliser la page actuelle") }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Moteur de recherche", color = Color.White)
                    SearchEngine.entries.forEach { e ->
                        Row(Modifier.fillMaxWidth().clickable { Prefs.updateSearchEngine(e) }, verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(Prefs.searchEngine == e, { Prefs.updateSearchEngine(e) })
                            Text(e.label, color = Color.White)
                        }
                    }
                    SwitchRow("Mode ordinateur", "Affiche la version bureau des sites (recharge les onglets)", Prefs.desktopMode) {
                        Prefs.updateDesktopMode(it)
                    }
                    SwitchRow("Bloquer les pop-ups", "Ignore les fenêtres ouvertes sans clic de votre part", Prefs.blockPopups) {
                        Prefs.updateBlockPopups(it)
                    }
                    SwitchRow("Rouvrir les onglets au démarrage", "Retrouve vos onglets à la prochaine ouverture", Prefs.restoreTabs) {
                        Prefs.updateRestoreTabs(it)
                    }
                }
            }

            item {
                Section("Navigateur avancé") {
                    SwitchRow("JavaScript", "Désactivé, beaucoup de sites ne fonctionnent plus", Prefs.jsEnabled) { Prefs.updateJs(it) }
                    SwitchRow("Charger les images", "Désactivez pour économiser les données", Prefs.loadImages) { Prefs.updateLoadImages(it) }
                    SwitchRow("Débogage à distance", "Inspecter les pages depuis chrome://inspect sur un PC", Prefs.debugWeb) { Prefs.updateDebugWeb(it) }
                    Spacer(Modifier.height(10.dp))
                    Text("Taille du texte", color = Color.White)
                    Chips(listOf(80, 100, 125, 150), Prefs.textZoom, { "$it%" }) { Prefs.updateTextZoom(it) }
                    Spacer(Modifier.height(10.dp))
                    Text("User-Agent personnalisé", color = Color.White)
                    Text("Vide = valeur par défaut. Ignoré en mode ordinateur.", color = Muted, fontSize = 12.sp)
                    OutlinedTextField(ua, { ua = it }, Modifier.fillMaxWidth().padding(top = 6.dp), singleLine = true)
                    TextButton({ Prefs.updateUserAgent(ua); toast("Enregistré (rechargez la page)") }) { Text("Enregistrer") }
                    TextButton({ showExt = true }) { Text("🧩 Gérer les extensions (${com.example.mydm.ext.Extensions.items.size})") }
                }
            }

            item {
                Section("Téléchargements") {
                    Text("Téléchargements simultanés", color = Color.White)
                    Text("Les suivants restent « en attente ».", color = Muted, fontSize = 12.sp)
                    Chips(listOf(1, 2, 3, 5, 8), Prefs.maxParallel, { "$it" }) { Prefs.updateMaxParallel(it) }
                    Spacer(Modifier.height(10.dp))
                    Text("Connexions par fichier", color = Color.White)
                    Text("Plus il y en a, plus c'est rapide (si le serveur l'accepte). S'applique aux nouveaux téléchargements.",
                        color = Muted, fontSize = 12.sp)
                    Chips(listOf(1, 4, 8, 16, 32), Prefs.maxSegments, { "$it" }) { Prefs.updateMaxSegments(it) }
                    Spacer(Modifier.height(10.dp))
                    Text("Limite de vitesse", color = Color.White)
                    Chips(listOf(0, 500, 1000, 2000, 5000), Prefs.speedLimitKb, { if (it == 0) "Illimité" else "$it Ko/s" }) { Prefs.updateSpeedLimit(it) }
                    Spacer(Modifier.height(10.dp))
                    Text("Nouvelles tentatives (erreur réseau/DNS)", color = Color.White)
                    Chips(listOf(0, 3, 5, 10), Prefs.retries, { "$it" }) { Prefs.updateRetries(it) }
                    SwitchRow("Wi-Fi uniquement", "Aucun téléchargement en données mobiles", Prefs.wifiOnly) { Prefs.updateWifiOnly(it) }
                }
            }

            item {
                Section("Notification de téléchargement") {
                    Text("Téléchargements détaillés dans la notification", color = Color.White)
                    Text("Les autres sont comptés dans « +N autres » et dans la pastille de l'icône.", color = Muted, fontSize = 12.sp)
                    Chips(listOf(3, 4, 5), Prefs.notifLines, { "$it" }) { Prefs.updateNotifLines(it) }
                    SwitchRow("Afficher le pourcentage", "Global et pour chaque téléchargement", Prefs.notifPercent) { Prefs.updateNotifPercent(it) }
                    SwitchRow("Afficher la taille", "Téléchargé / total pour chaque fichier", Prefs.notifSizes) { Prefs.updateNotifSizes(it) }
                }
            }

            item {
                Section("Données") {
                    TextButton({ CookieManager.getInstance().removeAllCookies(null); CookieManager.getInstance().flush(); toast("Cookies effacés") }) {
                        Text("Effacer les cookies")
                    }
                    TextButton({ manager.clearCacheAndHistory(); toast("Cache et historique effacés") }) {
                        Text("Effacer le cache et l'historique")
                    }
                    TextButton({ manager.clearDetected(); toast("Liste des médias vidée") }) {
                        Text("Vider les médias détectés")
                    }
                    TextButton({ Prefs.resetAll(ctx); home = Prefs.homeUrl; ua = Prefs.userAgent; toast("Réglages réinitialisés") }) {
                        Text("Réinitialiser tous les réglages")
                    }
                }
            }
        }
    }
}

@Composable
private fun <T> Chips(values: List<T>, selected: T, label: (T) -> String, onPick: (T) -> Unit) =
    Row(Modifier.padding(top = 8.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        values.forEach { v -> FilterChip(selected == v, { onPick(v) }, label = { Text(label(v)) }) }
    }

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) =
    Column(Modifier.fillMaxWidth().glass().padding(16.dp)) {
        Text(title, color = Accent, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Spacer(Modifier.height(10.dp))
        content()
    }

@Composable
private fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) =
    Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, color = Color.White)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
        Switch(checked, onChange)
    }
