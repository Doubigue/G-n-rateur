package com.example.mydm

import android.app.Application
import android.util.Log
import androidx.room.Room
import com.example.mydm.core.AppDb
import com.example.mydm.core.Prefs
import com.example.mydm.downloader.DownloadEngine
import com.example.mydm.torrent.TorrentEngine
import com.example.mydm.whatsapp.StatusRepository
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.File

class App : Application() {
    lateinit var db: AppDb
    lateinit var downloadEngine: DownloadEngine
    lateinit var statusRepo: StatusRepository
    val torrentEngine by lazy { TorrentEngine(this) }

    /** "loading" | "ready" | "error:<message>" — état du moteur yt-dlp */
    val ytState = MutableStateFlow("loading")

    override fun onCreate() {
        super.onCreate()
        installCrashLogger()
        Prefs.init(this)
        com.example.mydm.ext.Extensions.init(this)
        db = Room.databaseBuilder(this, AppDb::class.java, "mydm.db").addMigrations(com.example.mydm.core.MIGRATION_1_2).fallbackToDestructiveMigration().build()
        downloadEngine = DownloadEngine(this, db.downloadDao())
        statusRepo = StatusRepository(this)
        initYtDlp()
    }

    private fun initYtDlp() {
        Thread {
            try {
                YoutubeDL.getInstance().init(this)
                FFmpeg.getInstance().init(this)
                ytState.value = "ready"
                // Met yt-dlp à jour (YouTube change souvent) ; sans conséquence si hors-ligne
                runCatching { YoutubeDL.getInstance().updateYoutubeDL(this) }
            } catch (t: Throwable) {
                ytState.value = "error:" + (t.message ?: t::class.java.simpleName)
            }
        }.start()
    }

    private fun installCrashLogger() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            runCatching { File(filesDir, "crash.txt").writeText(Log.getStackTraceString(error)) }
            previous?.uncaughtException(thread, error)
        }
    }
}
