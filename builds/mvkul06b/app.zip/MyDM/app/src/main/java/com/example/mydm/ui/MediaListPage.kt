package com.example.mydm.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.mydm.App
import com.example.mydm.core.*
import com.example.mydm.downloader.DownloadService
import kotlinx.coroutines.launch

/** Page (plein écran) listant les vidéos/médias détectés dans l'onglet + analyse d'un lien YouTube/Facebook/TikTok. */
@Composable
fun MediaListPage(found: SnapshotStateList<DetectedMedia>, pageUrl: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val app = ctx.applicationContext as App
    val scope = rememberCoroutineScope()
    BackHandler(onBack = onBack)

    var link by remember { mutableStateOf(if (MediaResolver.isSupportedPage(pageUrl)) pageUrl else "") }
    var loading by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf<YtInfo?>(null) }
    var infoUrl by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val sizes = remember { mutableStateMapOf<String, Long?>() }
    val ytState by app.ytState.collectAsState()

    fun analyze() {
        val u = link.trim(); if (u.isEmpty()) return
        loading = true; error = null; info = null
        scope.launch {
            runCatching { MediaResolver.ytInfo(app, u) }
                .onSuccess { info = it; infoUrl = u }
                .onFailure { error = friendlyError(it.message) }
            loading = false
        }
    }

    fun downloadYt(opt: QualityOption) {
        val i = info ?: return
        scope.launch {
            val id = app.downloadEngine.enqueueYt(infoUrl, i.title, opt)
            DownloadService.start(ctx, id)
            Toast.makeText(ctx, "Téléchargement ajouté", Toast.LENGTH_SHORT).show()
        }
    }

    fun downloadDirect(m: DetectedMedia, close: Boolean = false) {
        scope.launch {
            val id = if (m.type == MediaType.HLS)
                app.downloadEngine.enqueueYt(m.url, m.displayName(), QualityOption("HLS", null, false, "b"), m.referer)
            else app.downloadEngine.enqueue(m)
            DownloadService.start(ctx, id)
            found.remove(m)
            if (close) Toast.makeText(ctx, "Téléchargement ajouté", Toast.LENGTH_SHORT).show()
        }
    }

    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(Modifier.fillMaxWidth().padding(start = 4.dp, top = 8.dp, end = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onBack) { Text("◀", fontSize = 18.sp) }
            Text("Vidéos à télécharger", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            if (found.size > 1) TextButton({
                found.toList().forEach { downloadDirect(it) }
                Toast.makeText(ctx, "${found.size} téléchargements ajoutés", Toast.LENGTH_SHORT).show()
            }) { Text("Tout (${found.size})") }
        }
        LazyColumn(
            Modifier.fillMaxWidth().weight(1f),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // ── Lien YouTube / Facebook / TikTok
            item {
                Column(Modifier.fillMaxWidth().glass().padding(12.dp)) {
                    Text("Lien vidéo (YouTube, Facebook, TikTok…)", color = Muted, fontSize = 12.sp)
                    OutlinedTextField(link, { link = it }, Modifier.fillMaxWidth(), singleLine = true,
                        placeholder = { Text("Collez un lien ici") })
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button({ analyze() }, enabled = link.isNotBlank() && !loading) { Text("Analyser") }
                        Spacer(Modifier.width(10.dp))
                        if (ytState == "loading") Text("Moteur en préparation…", color = Muted, fontSize = 11.sp)
                        else if (ytState.startsWith("error:")) Text("Moteur indisponible", color = Color(0xFFFF8A80), fontSize = 11.sp)
                    }
                }
            }
            if (loading) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
            error?.let { e -> item { Text(e, color = Color(0xFFFF8A80), fontSize = 12.sp) } }

            info?.let { i ->
                item { Text(i.title + (i.uploader?.let { " — $it" } ?: ""), color = Accent, maxLines = 2, overflow = TextOverflow.Ellipsis) }
                items(i.options) { o ->
                    Row(Modifier.fillMaxWidth().glass().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(o.label, color = Color.White)
                            Text(o.sizeBytes?.let { (if (o.approx) "~" else "") + formatSize(it) } ?: "taille inconnue",
                                color = Muted, fontSize = 12.sp)
                        }
                        Button({ downloadYt(o) }) { Text("Télécharger") }
                    }
                }
            }

            // ── Médias détectés dans la page
            item { Text("Médias détectés (${found.size})", color = Color.White, modifier = Modifier.padding(top = 8.dp)) }
            if (found.isEmpty()) item {
                Text("Lancez une vidéo dans la page : elle apparaîtra ici.", color = Muted, fontSize = 12.sp)
            }
            items(found.toList(), key = { it.url }) { m ->
                // taille calculée automatiquement
                LaunchedEffect(m.url) {
                    if (m.sizeBytes == null && m.url !in sizes) sizes[m.url] = MediaResolver.probeSize(m)
                }
                val size = m.sizeBytes ?: sizes[m.url]
                val dest = folderFor(fileNameFor(m)).let { if (it == Folder.OTHER && m.type == MediaType.VIDEO) Folder.VIDEO else it }
                Row(Modifier.fillMaxWidth().glass().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Row {
                            Text(m.type.name, color = Accent, fontSize = 11.sp, modifier = Modifier.width(56.dp))
                            Text(m.displayName(), color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                        }
                        Text((size?.let { formatSize(it) } ?: if (m.url in sizes) "taille inconnue" else "calcul…") +
                            "  →  ${dest.icon} ${dest.label}", color = Muted, fontSize = 12.sp)
                    }
                    Button({ downloadDirect(m, close = true) }) { Text("⬇") }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

/** Message lisible pour les erreurs réseau fréquentes (ex. DNS). */
fun friendlyError(raw: String?): String {
    val m = raw ?: return "Analyse impossible"
    return when {
        "No address associated with hostname" in m || "Unable to resolve host" in m ->
            "Impossible de joindre le site (DNS/Internet). Vérifiez votre connexion, le DNS privé ou le VPN, puis réessayez."
        "timed out" in m -> "Délai dépassé : connexion trop lente. Réessayez."
        else -> m.take(240)
    }
}
