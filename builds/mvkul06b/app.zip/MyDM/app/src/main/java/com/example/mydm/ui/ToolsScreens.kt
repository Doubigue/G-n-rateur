package com.example.mydm.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.mydm.browser.BrowserTab
import com.example.mydm.ext.Extensions

private fun copy(ctx: Context, label: String, text: String) {
    ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText(label, text))
    Toast.makeText(ctx, "Copié", Toast.LENGTH_SHORT).show()
}

// ───────────── Console / Réseau ─────────────
@Composable
fun ConsoleScreen(tab: BrowserTab, onBack: () -> Unit) {
    val ctx = LocalContext.current
    BackHandler(onBack = onBack)
    var page by remember { mutableIntStateOf(0) }       // 0 = console, 1 = réseau
    var input by remember { mutableStateOf("") }
    var netTick by remember { mutableIntStateOf(0) }
    val lines = tab.web.console
    val state = rememberLazyListState()
    LaunchedEffect(lines.size) { if (lines.isNotEmpty() && page == 0) state.scrollToItem(lines.lastIndex) }

    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(Modifier.fillMaxWidth().padding(start = 4.dp, top = 8.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onBack) { Text("◀", fontSize = 18.sp) }
            Text("Console", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton({ copy(ctx, "log", if (page == 0) tab.web.consoleText() else tab.web.networkText()) }) { Text("Copier") }
            TextButton({ if (page == 0) tab.web.console.clear() else { tab.web.netLog.clear(); netTick++ } }) { Text("Vider") }
        }
        TabRow(page, containerColor = Bg) {
            Tab(page == 0, { page = 0 }, text = { Text("Console (${lines.size})") })
            Tab(page == 1, { page = 1; netTick++ }, text = { Text("Réseau (${tab.web.netLog.size})") })
        }
        if (page == 0) {
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = state, contentPadding = PaddingValues(8.dp)) {
                items(lines.toList()) { l ->
                    val c = when (l.level) {
                        "ERROR" -> Color(0xFFFF8A80); "WARNING" -> Color(0xFFFFD180)
                        "INPUT" -> Accent; "RESULT" -> Color(0xFF82B1FF); else -> Color.White
                    }
                    Text(l.text + (if (l.source.length > 1) "   ${l.source}" else ""), color = c,
                        fontFamily = FontFamily.Monospace, fontSize = 11.sp, modifier = Modifier.padding(vertical = 2.dp))
                }
            }
            OutlinedTextField(input, { input = it }, Modifier.fillMaxWidth().padding(8.dp), singleLine = true,
                placeholder = { Text("Exécuter du JavaScript sur la page…") },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { if (input.isNotBlank()) { tab.web.runConsole(input); input = "" } }))
        } else {
            val net = remember(netTick, tab.url, tab.progress) { synchronized(tab.web.netLog) { tab.web.netLog.toList() } }
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(8.dp)) {
                items(net) { u -> Text(u, color = Muted, fontFamily = FontFamily.Monospace, fontSize = 10.sp, modifier = Modifier.padding(vertical = 2.dp)) }
            }
        }
    }
}

// ───────────── Extensions ─────────────
@Composable
fun ExtensionsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    BackHandler(onBack = onBack)
    var paste by remember { mutableStateOf(false) }
    var pasteName by remember { mutableStateOf("") }
    var pasteCode by remember { mutableStateOf("") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) runCatching { Extensions.importUri(uri) }
            .onSuccess { Toast.makeText(ctx, "$it extension(s) ajoutée(s)", Toast.LENGTH_SHORT).show() }
            .onFailure { Toast.makeText(ctx, "Import impossible : ${it.message}", Toast.LENGTH_LONG).show() }
    }

    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(Modifier.fillMaxWidth().padding(start = 4.dp, top = 8.dp, end = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onBack) { Text("◀", fontSize = 18.sp) }
            Text("Extensions", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Switch(com.example.mydm.core.Prefs.extensionsOn, { com.example.mydm.core.Prefs.updateExtensionsOn(it) })
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Column(Modifier.fillMaxWidth().glass().padding(14.dp)) {
                    Text("Android n'autorise pas l'installation directe des extensions du Chrome Web Store dans une WebView. " +
                        "MyDM injecte à la place : des scripts utilisateur (.user.js) et les « content scripts » d'une extension Chrome " +
                        "(fichier .zip ou .crx). Les API chrome.* ne sont simulées que de façon minimale.", color = Muted, fontSize = 12.sp)
                    Row(Modifier.padding(top = 8.dp)) {
                        Button({ picker.launch(arrayOf("*/*")) }) { Text("Importer un fichier") }
                        Spacer(Modifier.width(8.dp))
                        OutlinedButton({ paste = true }) { Text("Coller un script") }
                    }
                }
            }
            if (Extensions.items.isEmpty()) item { Text("Aucune extension installée.", color = Muted) }
            items(Extensions.items.toList(), key = { it.id }) { e ->
                Row(Modifier.fillMaxWidth().glass().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(e.name, color = Color.White)
                        Text((if (e.source == "chrome") "Extension Chrome • " else "Script • ") + e.matches.take(2).joinToString(", "),
                            color = Muted, fontSize = 11.sp, maxLines = 2)
                    }
                    Switch(e.enabled, { Extensions.setEnabled(e.id, it) })
                    TextButton({ Extensions.remove(e.id) }) { Text("✕") }
                }
            }
        }
    }

    if (paste) AlertDialog(
        onDismissRequest = { paste = false },
        title = { Text("Nouveau script") },
        text = {
            Column {
                OutlinedTextField(pasteName, { pasteName = it }, singleLine = true, label = { Text("Nom") })
                OutlinedTextField(pasteCode, { pasteCode = it }, Modifier.heightIn(min = 140.dp), label = { Text("Code JavaScript (// @match …)") })
            }
        },
        confirmButton = {
            TextButton({
                if (pasteCode.isNotBlank()) { Extensions.addUserScript(pasteCode, pasteName.ifBlank { "Script" }); paste = false; pasteName = ""; pasteCode = "" }
            }) { Text("Ajouter") }
        },
        dismissButton = { TextButton({ paste = false }) { Text("Annuler") } }
    )
}
