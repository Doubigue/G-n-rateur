package com.doubigue.ai.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "app_voice_config", indices = [Index(value = ["packageName"], unique = true)])
data class AppVoiceConfig(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val packageName: String,
    val spokenName: String,
    val aliases: String = "",
    val openAudioUri: String? = null,
    val closeAudioUri: String? = null,
    val smartToggle: Boolean = true
)

@Dao interface AppVoiceConfigDao {
    @Query("SELECT * FROM app_voice_config ORDER BY spokenName") fun observeAll(): Flow<List<AppVoiceConfig>>
    @Query("SELECT * FROM app_voice_config WHERE packageName = :packageName LIMIT 1") suspend fun get(packageName: String): AppVoiceConfig?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun save(config: AppVoiceConfig)
    @Query("DELETE FROM app_voice_config WHERE packageName = :packageName") suspend fun delete(packageName: String)
}

@Entity(tableName = "conversation_message", indices = [Index(value = ["createdAt"])])
data class ConversationMessage(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String,
    val content: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Dao interface ConversationDao {
    @Query("SELECT * FROM conversation_message ORDER BY createdAt DESC LIMIT :limit")
    fun latest(limit: Int = 100): Flow<List<ConversationMessage>>
    @Insert suspend fun add(message: ConversationMessage)
    @Query("DELETE FROM conversation_message") suspend fun clear()
}

@Entity(tableName = "learned_command", indices = [Index(value = ["triggerPhrase"], unique = true)])
data class LearnedCommand(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val triggerPhrase: String,
    val commandText: String,
    val profileName: String = "Général",
    val createdAt: Long = System.currentTimeMillis()
)

@Dao interface LearnedCommandDao {
    @Query("SELECT * FROM learned_command ORDER BY triggerPhrase COLLATE NOCASE") fun observeAll(): Flow<List<LearnedCommand>>
    @Query("SELECT * FROM learned_command") suspend fun all(): List<LearnedCommand>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun save(command: LearnedCommand)
    @Query("DELETE FROM learned_command WHERE id = :id") suspend fun delete(id: Long)
}

@Database(entities = [AppVoiceConfig::class, ConversationMessage::class, LearnedCommand::class], version = 5, exportSchema = true)
abstract class AssistantDatabase : RoomDatabase() { abstract fun appVoiceConfigDao(): AppVoiceConfigDao; abstract fun conversationDao(): ConversationDao; abstract fun learnedCommandDao(): LearnedCommandDao }

val MIGRATION_1_2 = object : androidx.room.migration.Migration(1, 2) {
    override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE app_voice_config ADD COLUMN aliases TEXT NOT NULL DEFAULT ''")
    }
}


val MIGRATION_2_3 = object : androidx.room.migration.Migration(2, 3) {
    override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS conversation_message (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, role TEXT NOT NULL, content TEXT NOT NULL, createdAt INTEGER NOT NULL)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_conversation_message_createdAt ON conversation_message(createdAt)")
    }
}


val MIGRATION_3_4 = object : androidx.room.migration.Migration(3, 4) {
    override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS learned_command (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, triggerPhrase TEXT NOT NULL, commandText TEXT NOT NULL, createdAt INTEGER NOT NULL)")
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_learned_command_triggerPhrase ON learned_command(triggerPhrase)")
    }
}


val MIGRATION_4_5 = object : androidx.room.migration.Migration(4, 5) {
    override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE learned_command ADD COLUMN profileName TEXT NOT NULL DEFAULT 'Général'")
    }
}
