import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'admin.dart';
import 'data.dart';
import 'entry.dart';
import 'notif.dart';

/// Réglages enregistrés sur le téléphone (valeurs par défaut entre parenthèses).
class AppSettings {
  static final changed = ValueNotifier<int>(0);
  static void _bump() => changed.value++;

  static String get currency => Repo.p.getString('cur') ?? 'FCFA';
  static int get repeatMin => Repo.p.getInt('rep_min') ?? 5; // minutes entre deux sonneries
  static int get ringSec => Repo.p.getInt('ring_sec') ?? 60; // durée d'une sonnerie
  static int get maxRepeats => Repo.p.getInt('rep_max') ?? 20; // nombre max de répétitions
  static bool get beep => Repo.p.getBool('beep') ?? true;
  static int get packSize => Repo.p.getInt('pack') ?? 30;
  static String get farm => Repo.p.getString('farm') ?? 'Ma Ferme';

  static Future<void> setStr(String k, String v) async { await Repo.p.setString(k, v); _bump(); }
  static Future<void> setInt(String k, int v) async { await Repo.p.setInt(k, v); _bump(); }
  static Future<void> setBool(String k, bool v) async { await Repo.p.setBool(k, v); _bump(); }
}

/// Montant avec la devise choisie (FCFA par défaut)
String money(num n) => '${NumberFormat.decimalPattern('fr').format(n)} ${AppSettings.currency}';

/// Version sûre pour le PDF (pas d'espace fine insécable)
String moneyPdf(num n) => money(n).replaceAll('\u202f', ' ').replaceAll('\u00a0', ' ');

const _devises = ['FCFA', 'XOF', 'XAF', 'EUR', 'USD', 'GNF', 'MAD', 'CDF', 'NGN', 'GHS'];

class SettingsPage extends StatefulWidget {
  final VoidCallback onLogout;
  const SettingsPage({super.key, required this.onLogout});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  Future<void> _askInt(String title, String key, int cur, {int min = 1, int max = 999, String unit = ''}) async {
    final t = TextEditingController(text: '$cur');
    final v = await showDialog<int>(context: context, builder: (c) => AlertDialog(
      title: Text(title),
      content: TextField(controller: t, keyboardType: TextInputType.number, autofocus: true, decoration: InputDecoration(suffixText: unit, border: const OutlineInputBorder())),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c), child: const Text('Annuler')),
        FilledButton(onPressed: () => Navigator.pop(c, (int.tryParse(t.text) ?? cur).clamp(min, max).toInt()), child: const Text('OK')),
      ],
    ));
    if (v == null) return;
    await AppSettings.setInt(key, v);
    if (key.startsWith('rep') || key == 'ring_sec') await Notif.rescheduleAll();
    if (mounted) { setState(() {}); saved(context, 'Paramètre enregistré ✔'); }
  }

  Future<void> _askText(String title, String key, String cur) async {
    final t = TextEditingController(text: cur);
    final v = await showDialog<String>(context: context, builder: (c) => AlertDialog(
      title: Text(title),
      content: TextField(controller: t, autofocus: true, decoration: const InputDecoration(border: OutlineInputBorder())),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c), child: const Text('Annuler')),
        FilledButton(onPressed: () => Navigator.pop(c, t.text.trim()), child: const Text('OK')),
      ],
    ));
    if (v == null || v.isEmpty) return;
    await AppSettings.setStr(key, v);
    if (mounted) { setState(() {}); saved(context, 'Paramètre enregistré ✔'); }
  }

  Widget _sec(String t) => Padding(padding: const EdgeInsets.fromLTRB(8, 18, 8, 6), child: Text(t, style: TextStyle(fontWeight: FontWeight.w800, color: Theme.of(context).colorScheme.primary)));

  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: const Text('Paramètres'), actions: [IconButton(icon: const Icon(Icons.logout), onPressed: widget.onLogout)]),
        body: ListView(padding: const EdgeInsets.fromLTRB(12, 0, 12, 40), children: [
          _sec('GÉNÉRAL'),
          Card(child: Column(children: [
            ListTile(leading: const Icon(Icons.payments_outlined), title: const Text('Devise'), subtitle: Text(AppSettings.currency),
              onTap: () async {
                final v = await showDialog<String>(context: c, builder: (d) => SimpleDialog(title: const Text('Devise'), children: [
                  for (final x in _devises) SimpleDialogOption(onPressed: () => Navigator.pop(d, x), child: Text(x, style: TextStyle(fontWeight: x == AppSettings.currency ? FontWeight.bold : FontWeight.normal))),
                  SimpleDialogOption(onPressed: () => Navigator.pop(d, '_autre'), child: const Text('Autre…')),
                ]));
                if (v == null) return;
                if (v == '_autre') { await _askText('Votre devise', 'cur', AppSettings.currency); }
                else { await AppSettings.setStr('cur', v); if (mounted) { setState(() {}); saved(context, 'Devise : $v ✔'); } }
              }),
            ListTile(leading: const Icon(Icons.agriculture), title: const Text('Nom de la ferme'), subtitle: Text(AppSettings.farm), onTap: () => _askText('Nom de la ferme', 'farm', AppSettings.farm)),
            ListTile(leading: const Icon(Icons.inventory_2_outlined), title: const Text('Œufs par paquet (par défaut)'), subtitle: Text('${AppSettings.packSize}'), onTap: () => _askInt('Œufs par paquet', 'pack', AppSettings.packSize, max: 500)),
            SwitchListTile(secondary: const Icon(Icons.volume_up_outlined), title: const Text('Bip à chaque enregistrement'), value: AppSettings.beep, onChanged: (v) async { await AppSettings.setBool('beep', v); if (v) Notif.beep(force: true); setState(() {}); }),
          ])),
          _sec('ALARMES'),
          Card(child: Column(children: [
            ListTile(leading: const Icon(Icons.repeat), title: const Text('Minutes de répétition'), subtitle: Text('L\'alarme sonne à nouveau toutes les ${AppSettings.repeatMin} min tant qu\'elle n\'est pas arrêtée'),
              onTap: () => _askInt('Répéter toutes les (minutes)', 'rep_min', AppSettings.repeatMin, max: 240, unit: 'min')),
            ListTile(leading: const Icon(Icons.timer_outlined), title: const Text('Durée de la sonnerie'), subtitle: Text('${AppSettings.ringSec} secondes'),
              onTap: () => _askInt('Durée de la sonnerie (secondes)', 'ring_sec', AppSettings.ringSec, min: 10, max: 300, unit: 's')),
            ListTile(leading: const Icon(Icons.format_list_numbered), title: const Text('Nombre maximum de répétitions'), subtitle: Text('${AppSettings.maxRepeats} fois'),
              onTap: () => _askInt('Répétitions maximum', 'rep_max', AppSettings.maxRepeats, max: 48)),
            ListTile(leading: const Icon(Icons.alarm_on), title: const Text('Autoriser les alarmes précises'), subtitle: const Text('Nécessaire pour l\'icône d\'alarme dans la barre du téléphone'),
              onTap: () async {
                final a = Notif.pl.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
                await a?.requestNotificationsPermission();
                await a?.requestExactAlarmsPermission();
                await Notif.rescheduleAll();
                if (mounted) saved(context, 'Alarmes reprogrammées ✔');
              }),
          ])),
          SoundCard(onChanged: () => setState(() {})),
          _sec('ÉQUIPE'),
          Card(child: ValueListenableBuilder(valueListenable: Repo.employees, builder: (_, l, __) => ListTile(
            leading: const Icon(Icons.groups_outlined), title: const Text('Employés et leur rôle'), subtitle: Text('${l.length} employé(s)'), trailing: const Icon(Icons.chevron_right),
            onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => Scaffold(appBar: AppBar(title: const Text('Employés et rôles')), body: const EmployeeTab()))),
          ))),
          _sec('DONNÉES ET SÉCURITÉ'),
          const ToolsTab(),
        ]),
      );
}
