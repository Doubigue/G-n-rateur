import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'data.dart';
import 'entry.dart';
import 'main.dart';
import 'notif.dart';
import 'settings.dart';

class ReportPage extends StatefulWidget {
  const ReportPage({super.key});
  @override
  State<ReportPage> createState() => _ReportPageState();

  static Future<void> _pdf(BuildContext c) async {
    final s = Summary(inPeriod(Repo.records.value), inPeriod(Repo.expenses.value));
    final doc = pw.Document();
    pw.Widget h(String t) => pw.Padding(padding: const pw.EdgeInsets.only(top: 14, bottom: 4), child: pw.Text(t, style: pw.TextStyle(fontSize: 15, fontWeight: pw.FontWeight.bold)));
    doc.addPage(pw.MultiPage(pageFormat: PdfPageFormat.a4, build: (_) => [
      pw.Header(level: 0, child: pw.Text('Rapport - ${AppSettings.farm} - ${DateFormat('dd/MM/yyyy').format(DateTime.now())} (${days == 0 ? 'tout' : '$days derniers jours'})', style: pw.TextStyle(fontSize: 20, fontWeight: pw.FontWeight.bold))),
      pw.Text('Ventes : ${moneyPdf(s.sales)}   Achats : ${moneyPdf(s.purchases)}   Depenses : ${moneyPdf(s.expTotal)}'),
      pw.Text('Benefice net : ${moneyPdf(s.profit)}', style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold)),
      h('Detail par animal'),
      pw.TableHelper.fromTextArray(headers: ['Animal', 'Stock', 'Achats', 'Morts', 'Vendus', 'Oeufs', 'Casses', 'Eclos/nes', 'Ventes (${AppSettings.currency})'], data: s.rows, cellStyle: const pw.TextStyle(fontSize: 9), headerStyle: pw.TextStyle(fontSize: 9, fontWeight: pw.FontWeight.bold)),
      h('Depenses par categorie'),
      pw.TableHelper.fromTextArray(headers: ['Categorie', 'Montant'], data: s.byCat.entries.map((e) => [e.key, moneyPdf(e.value)]).toList()),
      h('Employes'),
      pw.TableHelper.fromTextArray(headers: ['Nom', 'Role', 'Salaire'], data: Repo.employees.value.map((e) => [e['name'], e['role'], moneyPdf(e['salary'] ?? 0)]).toList()),
      h('Depenses detaillees'),
      pw.TableHelper.fromTextArray(headers: ['Date', 'Categorie', 'Note', 'Montant'], data: inPeriod(Repo.expenses.value).map((e) => [e['d'], e['c'], e['n'] ?? '', moneyPdf(e['m'] ?? 0)]).toList(), cellStyle: const pw.TextStyle(fontSize: 9)),
      h('Journal des enregistrements'),
      pw.TableHelper.fromTextArray(headers: ['Date', 'Animal', 'Type', 'Nb', 'Montant', 'Note'], data: inPeriod(Repo.records.value).take(300).map((r) => [r['d'], animalOf(r['a']).name, kindLabels[r['k']] ?? r['k'], r['q'], moneyPdf(r['m'] ?? 0), r['n'] ?? '']).toList(), cellStyle: const pw.TextStyle(fontSize: 8)),
    ]));
    final bytes = await doc.save();
    final name = 'rapport_ferme_${DateFormat('yyyy-MM-dd_HH-mm').format(DateTime.now())}.pdf';
    await _telecharger(c, bytes, name);
  }

  /// Enregistre le PDF dans le dossier Téléchargements du téléphone (visible dans « Téléchargements »)
  static Future<void> _telecharger(BuildContext c, Uint8List bytes, String name) async {
    try {
      final r = await const MethodChannel('baobab/download').invokeMethod('save', {'name': name, 'mime': 'application/pdf', 'bytes': bytes});
      if (r == null) throw Exception('échec');
      Notif.info('Rapport téléchargé', '$name est dans Téléchargements');
      if (c.mounted) saved(c, 'Rapport téléchargé ✔ Dossier Téléchargements : $name');
    } catch (_) {
      // hors Android (ou ancienne version) : on propose le partage classique
      await Printing.sharePdf(bytes: bytes, filename: name);
    }
  }
}

int days = 30; // 0 = tout
List<Map<String, dynamic>> inPeriod(List<Map<String, dynamic>> l) {
  if (days == 0) return l;
  final lim = DateFormat('yyyy-MM-dd').format(DateTime.now().subtract(Duration(days: days)));
  return l.where((e) => '${e['d']}'.compareTo(lim) >= 0).toList();
}

class _ReportPageState extends State<ReportPage> {
  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: const Text('Rapport détaillé')),
        floatingActionButton: FloatingActionButton.extended(onPressed: () => ReportPage._pdf(c), icon: const Icon(Icons.picture_as_pdf), label: const Text('Télécharger le rapport')),
        body: ValueListenableBuilder(
          valueListenable: Repo.records,
          builder: (_, recs, __) => ValueListenableBuilder(
            valueListenable: Repo.expenses,
            builder: (_, exp, __) {
              final s = Summary(inPeriod(recs), inPeriod(exp));
              return ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 90), children: [
                Wrap(spacing: 8, children: [for (final p in [[7, '7 jours'], [30, '30 jours'], [90, '90 jours'], [0, 'Tout']]) ChoiceChip(label: Text(p[1] as String), selected: days == p[0], onSelected: (_) => setState(() => days = p[0] as int))]),
                const SizedBox(height: 8),
                Card(color: s.profit >= 0 ? Colors.green.shade50 : Colors.red.shade50, child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
                  const Text('Bénéfice net'), Text(f(s.profit), style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900, color: s.profit >= 0 ? Colors.green.shade800 : Colors.red)),
                  Text('Ventes ${f(s.sales)} • Achats ${f(s.purchases)} • Dépenses ${f(s.expTotal)}', style: const TextStyle(fontSize: 12)),
                ]))),
                _eggChart(recs),
                for (final r in s.rows) Card(child: ListTile(title: Text(r[0], style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text('Stock ${r[1]} • Achats ${r[2]} • Morts ${r[3]} • Vendus ${r[4]}\nŒufs ${r[5]} (cassés ${r[6]}) • Éclos/nés ${r[7]}'), isThreeLine: true, trailing: Text(f(num.parse('${r[8]}')), style: const TextStyle(fontWeight: FontWeight.bold)))),
                const Padding(padding: EdgeInsets.all(8), child: Text('Dépenses par catégorie', style: TextStyle(fontWeight: FontWeight.bold))),
                for (final e in s.byCat.entries) ListTile(title: Text(e.key), trailing: Text(f(e.value)), subtitle: LinearProgressIndicator(value: s.expTotal == 0 ? 0 : (e.value / s.expTotal).toDouble(), minHeight: 6, borderRadius: BorderRadius.circular(6))),
              ]);
            },
          ),
        ),
      );

  Widget _eggChart(List<Map<String, dynamic>> recs) {
    final df = DateFormat('yyyy-MM-dd');
    final v = [for (var i = 13; i >= 0; i--) Repo.sum(recs.where((r) => r['k'] == 'oeufs' && r['d'] == df.format(DateTime.now().subtract(Duration(days: i)))), 'q').toDouble()];
    final mx = v.fold<double>(1, (m, e) => e > m ? e : m);
    return Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Œufs pondus (14 derniers jours)', style: TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height: 10),
      SizedBox(height: 110, child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
        for (final e in v) Expanded(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 2), child: AnimatedContainer(duration: const Duration(milliseconds: 500), height: 4 + 100 * e / mx, decoration: BoxDecoration(color: Colors.amber.shade700, borderRadius: BorderRadius.circular(6))))),
      ])),
    ])));
  }
}

class Summary {
  late num sales, purchases, expTotal, profit;
  final rows = <List<dynamic>>[];
  final byCat = <String, num>{};
  Summary(List<Map<String, dynamic>> recs, List<Map<String, dynamic>> exp) {
    num k(List<Map<String, dynamic>> l, String kind, String fld) => Repo.sum(l.where((r) => r['k'] == kind), fld);
    sales = k(recs, 'vente', 'm') + k(recs, 'ovente', 'm');
    purchases = k(recs, 'achat', 'm') + k(recs, 'oachat', 'm');
    for (final e in exp) { byCat[e['c']] = (byCat[e['c']] ?? 0) + (e['m'] ?? 0); }
    // nourriture et piqûres saisies dans les fiches animaux comptent comme dépenses
    for (final r in recs.where((r) => r['k'] == 'nourriture' || r['k'] == 'soin')) {
      final cat = r['k'] == 'nourriture' ? 'Nourriture' : 'Piqûres / vétérinaire';
      byCat[cat] = (byCat[cat] ?? 0) + (r['m'] ?? 0);
    }
    expTotal = byCat.values.fold<num>(0, (s, e) => s + e);
    profit = sales - purchases - expTotal;
    for (final a in animals) {
      final l = recs.where((r) => r['a'] == a.key).toList();
      rows.add([a.name, Repo.stock(a.key), k(l, 'achat', 'q'), k(l, 'mort', 'q'), k(l, 'vente', 'q'), k(l, 'oeufs', 'q'), k(l, 'casses', 'q') + k(l, 'oeufs', 'br'), k(l, 'eclosion', 'q') + k(l, 'naissance', 'q'), k(l, 'vente', 'm')]);
    }
  }
}
