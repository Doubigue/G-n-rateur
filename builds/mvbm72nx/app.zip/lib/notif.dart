import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:audioplayers/audioplayers.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show HapticFeedback;
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/data/latest_all.dart' as tzd;
import 'package:timezone/timezone.dart' as tz;
import 'data.dart';
import 'entry.dart';
import 'settings.dart';

const builtinSounds = {'ferme_cloche': 'Cloche de la ferme', 'ferme_coq': 'Chant du coq', 'ferme_sirene': 'Sirène', 'ferme_douce': 'Mélodie douce'};

/// Identifiant Android de la k-ième sonnerie d'une alarme (0 = sonnerie principale, 1..n = répétitions)
int nid(int rid, int k) => (rid % 40000000) * 50 + k;
bool isDaily(Map<String, dynamic> r) => r['daily'] == true || r['date'] == null;
String _day(DateTime d) => DateFormat('yyyy-MM-dd').format(d);

/// Appelé quand on touche « Arrêter » alors que l'appli est fermée
@pragma('vm:entry-point')
void notifBackground(NotificationResponse r) {
  Notif.onResponse(r);
}

class Notif {
  static final pl = FlutterLocalNotificationsPlugin();
  static final inbox = ValueNotifier<List<Map<String, dynamic>>>([]);
  static final player = AudioPlayer();
  static final _beep = AudioPlayer();
  static final _fired = <String>{};
  static bool _ready = false;
  static const _initSettings = InitializationSettings(android: AndroidInitializationSettings('@mipmap/ic_launcher'));
  static String get sound => Repo.p.getString('sound') ?? 'ferme_cloche';
  static String? get customPath => Repo.p.getString('sound_custom');

  static Future<void> init() async {
    tzd.initializeTimeZones();
    final name = await FlutterTimezone.getLocalTimezone();
    tz.setLocalLocation(tz.getLocation(name));
    await Repo.p.setString('tzname', name);
    await pl.initialize(_initSettings, onDidReceiveNotificationResponse: onResponse, onDidReceiveBackgroundNotificationResponse: notifBackground);
    _ready = true;
    final a = pl.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await a?.requestNotificationsPermission();
    await a?.requestExactAlarmsPermission();
    inbox.value = (jsonDecode(Repo.p.getString('inbox') ?? '[]') as List).cast<Map<String, dynamic>>();
    final d = await pl.getNotificationAppLaunchDetails();
    if (d?.didNotificationLaunchApp == true && d!.notificationResponse != null) onResponse(d.notificationResponse!);
    Timer.periodic(const Duration(seconds: 20), (_) => _tick());
  }

  // ---------- Bip de confirmation ----------
  static Future<void> beep({bool force = false}) async {
    if (!force && !AppSettings.beep) return;
    try {
      HapticFeedback.mediumImpact();
      await _beep.stop();
      await _beep.play(AssetSource('sounds/bip.wav'), mode: PlayerMode.lowLatency);
    } catch (_) {}
  }

  // Quand l'appli est ouverte : range dans la boîte de notifications les rappels qui sonnent
  static void _tick() {
    final n = DateTime.now();
    final td = _day(n);
    for (final r in all()) {
      if (r['h'] != n.hour || r['m'] != n.minute) continue;
      if (!isDaily(r) && r['date'] != td) continue;
      final key = '${r['id']}-$td-${n.hour}:${n.minute}';
      if (_fired.add(key)) log('${r['label']}', '${r['msg']}');
    }
  }

  static void log(String t, String b) {
    inbox.value = [{'t': t, 'b': b, 'ts': DateTime.now().toIso8601String(), 'r': false}, ...inbox.value].take(100).toList();
    Repo.p.setString('inbox', jsonEncode(inbox.value));
  }

  static void markAllRead() {
    inbox.value = [for (final e in inbox.value) {...e, 'r': true}];
    Repo.p.setString('inbox', jsonEncode(inbox.value));
  }

  static AndroidNotificationDetails _det(String msg) {
    final s = sound;
    AndroidNotificationSound? snd;
    var id = 'alarme_v2_$s';
    if (s == 'custom' && customPath != null) {
      snd = UriAndroidNotificationSound(Uri.file(customPath!).toString());
      id = 'alarme_v2_custom_${customPath.hashCode}';
    } else if (s.startsWith('ferme_')) {
      snd = RawResourceAndroidNotificationSound(s);
    }
    return AndroidNotificationDetails(id, 'Alarmes de la ferme',
        channelDescription: 'Rappels et alarmes de la ferme',
        importance: Importance.max, priority: Priority.max, category: AndroidNotificationCategory.alarm,
        fullScreenIntent: true, playSound: true, sound: snd, enableVibration: true, audioAttributesUsage: AudioAttributesUsage.alarm,
        additionalFlags: Int32List.fromList([4]), // 4 = la sonnerie boucle jusqu'à l'arrêt…
        timeoutAfter: AppSettings.ringSec * 1000, // …mais s'arrête seule après la durée réglée (1 min par défaut)
        visibility: NotificationVisibility.public,
        actions: const [AndroidNotificationAction('stop', 'Arrêter', cancelNotification: true)],
        styleInformation: BigTextStyleInformation(msg));
  }

  // Notification immédiate (ex : mortalité enregistrée, test d'alarme)
  static Future<void> now(String title, String msg) async {
    log(title, msg);
    await pl.show(DateTime.now().millisecondsSinceEpoch ~/ 1000 % 100000 + 100000, '🚜 $title', msg, NotificationDetails(android: _det(msg)));
  }

  // Simple information (ex : rapport téléchargé)
  static Future<void> info(String title, String msg) async {
    await pl.show(DateTime.now().millisecondsSinceEpoch ~/ 1000 % 100000 + 200000, title, msg,
        const NotificationDetails(android: AndroidNotificationDetails('infos', 'Informations', importance: Importance.defaultImportance, priority: Priority.defaultPriority)));
  }

  static List<Map<String, dynamic>> all() => (jsonDecode(Repo.p.getString('rem') ?? '[]') as List).cast<Map<String, dynamic>>();

  /// Programme la sonnerie principale + les répétitions (toutes les N minutes, réglage « Paramètres »).
  /// Retourne false si Android a refusé les alarmes précises (pas d'icône d'alarme dans la barre).
  static Future<bool> schedule(Map<String, dynamic> r, {bool fromTomorrow = false}) async {
    final now = tz.TZDateTime.now(tz.local);
    final rid = r['id'] as int;
    final daily = isDaily(r);
    if (daily && Repo.p.getString('stop_$rid') == _day(DateTime.now())) fromTomorrow = true; // déjà arrêtée aujourd'hui
    final today = tz.TZDateTime(tz.local, now.year, now.month, now.day);
    final tomorrow = today.add(const Duration(days: 1));
    var base = today;
    if (r['date'] != null) {
      final d = DateTime.parse(r['date']);
      final s = tz.TZDateTime(tz.local, d.year, d.month, d.day);
      if (!daily || s.isAfter(today)) base = s;
    }
    final every = AppSettings.repeatMin, n = AppSettings.maxRepeats.clamp(0, 48);
    var ok = true;
    for (var k = 0; k <= n; k++) {
      var t = tz.TZDateTime(tz.local, base.year, base.month, base.day, r['h'], r['m']).add(Duration(minutes: k * every));
      if (daily) {
        while (t.isBefore(now) || (fromTomorrow && t.isBefore(tomorrow))) { t = t.add(const Duration(days: 1)); }
      } else if (t.isBefore(now)) {
        continue;
      }
      final title = k == 0 ? '⏰ ${r['label']}' : '⏰ Rappel $k • ${r['label']}';
      Future<void> go(AndroidScheduleMode mode) => pl.zonedSchedule(nid(rid, k), title, '${r['msg']}', t, NotificationDetails(android: _det('${r['msg']}')),
          androidScheduleMode: mode, payload: '$rid', matchDateTimeComponents: daily ? DateTimeComponents.time : null);
      try {
        await go(AndroidScheduleMode.alarmClock); // mode « réveil » : icône d'alarme dans la barre d'état
      } catch (_) {
        ok = false;
        try { await go(AndroidScheduleMode.inexactAllowWhileIdle); } catch (_) {}
      }
    }
    return ok;
  }

  static Future<void> _cancelChain(int rid) async {
    for (var k = 0; k <= 48; k++) { await pl.cancel(nid(rid, k)); }
  }

  static Future<void> rescheduleAll() async {
    for (final r in all()) { await _cancelChain(r['id']); await schedule(r); }
  }

  /// Ajoute une alarme (date + heure). daily = répétée chaque jour à partir de la date.
  static Future<bool> add(String label, String msg, TimeOfDay t, {required DateTime date, bool daily = false}) async {
    final l = all();
    final rid = (Repo.p.getInt('rid') ?? 0) + 1;
    await Repo.p.setInt('rid', rid);
    final r = {'id': rid, 'label': label, 'msg': msg, 'h': t.hour, 'm': t.minute, 'date': _day(date), 'daily': daily};
    l.add(r);
    await Repo.p.setString('rem', jsonEncode(l));
    return schedule(r);
  }

  static Future<void> remove(int id) async {
    await _cancelChain(id);
    await Repo.p.remove('stop_$id');
    await Repo.p.setString('rem', jsonEncode(all()..removeWhere((e) => e['id'] == id)));
  }

  /// « Arrêter » ou toucher la notification : coupe la sonnerie et toutes les répétitions de cette alarme.
  static Future<void> onResponse(NotificationResponse resp) async {
    final rid = int.tryParse(resp.payload ?? '');
    if (rid == null) return;
    try { await stop(rid); } catch (_) {}
  }

  static Future<void> stop(int rid) async {
    final p = await SharedPreferences.getInstance(); // fonctionne aussi quand l'appli est fermée
    await p.reload();
    Repo.p = p;
    if (!_ready) {
      try {
        tzd.initializeTimeZones();
        tz.setLocalLocation(tz.getLocation(p.getString('tzname') ?? 'UTC'));
      } catch (_) {}
      await pl.initialize(_initSettings);
      _ready = true;
    }
    await _cancelChain(rid);
    final found = all().where((e) => e['id'] == rid);
    if (found.isNotEmpty && isDaily(found.first)) {
      await p.setString('stop_$rid', _day(DateTime.now()));
      await schedule(found.first, fromTomorrow: true); // on garde l'alarme quotidienne pour demain
    }
  }

  static Future<void> setSound(String s) async {
    await Repo.p.setString('sound', s);
    await rescheduleAll(); // les canaux gardent leur son : on reprogramme
  }

  static Future<void> preview(String s) async {
    await player.stop();
    if (s == 'custom' && customPath != null) { await player.play(DeviceFileSource(customPath!)); }
    else if (s.startsWith('ferme_')) { await player.play(AssetSource('sounds/$s.wav')); }
  }

  static Future<bool> pickCustom() async {
    final res = await FilePicker.platform.pickFiles(type: FileType.audio);
    final src = res?.files.single.path;
    if (src == null) return false;
    final dir = await getApplicationDocumentsDirectory();
    final ext = src.contains('.') ? src.split('.').last : 'mp3';
    final dst = '${dir.path}/sonnerie_${DateTime.now().millisecondsSinceEpoch}.$ext';
    await File(src).copy(dst);
    await Repo.p.setString('sound_custom', dst);
    await setSound('custom');
    return true;
  }
}

class NotifPage extends StatefulWidget {
  const NotifPage({super.key});
  @override
  State<NotifPage> createState() => _NotifPageState();
}

class _NotifPageState extends State<NotifPage> {
  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: const Text('Notifications'), actions: [IconButton(icon: const Icon(Icons.done_all), tooltip: 'Tout marquer lu', onPressed: Notif.markAllRead)]),
        body: ListView(padding: const EdgeInsets.all(12), children: [SoundCard(onChanged: () => setState(() {})),
          ValueListenableBuilder(valueListenable: Notif.inbox, builder: (_, l, __) => Column(children: [
            if (l.isEmpty) const Padding(padding: EdgeInsets.all(30), child: Text('Aucune notification pour le moment')),
            for (final e in l) ListTile(
              leading: Icon(e['r'] == true ? Icons.notifications_none : Icons.notifications_active, color: e['r'] == true ? null : Colors.orange),
              title: Text('${e['t']}', style: TextStyle(fontWeight: e['r'] == true ? FontWeight.normal : FontWeight.bold)),
              subtitle: Text('${e['b']}\n${DateFormat('dd/MM HH:mm').format(DateTime.parse(e['ts']))}'), isThreeLine: true),
          ])),
        ]),
      );
}

class SoundCard extends StatelessWidget {
  final VoidCallback onChanged;
  const SoundCard({super.key, required this.onChanged});
  @override
  Widget build(BuildContext c) {
    final cur = Notif.sound;
    Widget tile(String k, String label) => RadioListTile<String>(
          value: k, groupValue: cur, title: Text(label),
          secondary: k == 'systeme' ? null : IconButton(icon: const Icon(Icons.play_circle_outline), onPressed: () => Notif.preview(k)),
          onChanged: (v) async { await Notif.setSound(v!); onChanged(); });
    return Card(child: Column(children: [
      const ListTile(leading: Icon(Icons.music_note), title: Text('Sonnerie des alarmes', style: TextStyle(fontWeight: FontWeight.bold))),
      for (final e in builtinSounds.entries) tile(e.key, e.value),
      tile('systeme', 'Son par défaut du téléphone'),
      if (Notif.customPath != null) tile('custom', 'Ma sonnerie (${Notif.customPath!.split('/').last})'),
      Padding(padding: const EdgeInsets.all(8), child: OutlinedButton.icon(icon: const Icon(Icons.library_music), label: const Text('Ajouter ma propre sonnerie'),
          onPressed: () async { if (await Notif.pickCustom()) onChanged(); })),
    ]));
  }
}

class ReminderTab extends StatefulWidget {
  const ReminderTab({super.key});
  @override
  State<ReminderTab> createState() => _ReminderTabState();
}

class _ReminderTabState extends State<ReminderTab> {
  Animal a = animals.first; String type = 'Ramassage des œufs'; TimeOfDay t = const TimeOfDay(hour: 7, minute: 0);
  bool daily = false; DateTime date = DateTime.now();
  final types = ['Ramassage des œufs', 'Piqûre / vaccin', 'Alimentation', 'Traitement', 'Autre'];

  Future<void> _create(BuildContext c) async {
    final when = DateTime(date.year, date.month, date.day, t.hour, t.minute);
    if (!daily && when.isBefore(DateTime.now())) return toast(c, 'Cette date et cette heure sont déjà passées', error: true);
    final ok = await Notif.add('$type - ${a.name}', 'C\'est l\'heure : $type (${a.name})', t, date: date, daily: daily);
    setState(() {});
    if (!c.mounted) return;
    saved(c, 'Alarme programmée ✔ ${DateFormat('dd/MM/yyyy').format(date)} à ${t.format(c)}');
    if (!ok) toast(c, 'Autorisez « Alarmes et rappels » (Paramètres) pour l\'icône d\'alarme', error: true);
  }

  @override
  Widget build(BuildContext c) => ListView(padding: const EdgeInsets.all(16), children: [
        Card(child: ListTile(leading: const Icon(Icons.repeat), title: Text('Répétition : toutes les ${AppSettings.repeatMin} min'),
            subtitle: Text('Sonne ${AppSettings.ringSec} s, puis revient tant que vous ne touchez pas « Arrêter ». À régler dans Paramètres.'))),
        SoundCard(onChanged: () => setState(() {})),
        OutlinedButton.icon(icon: const Icon(Icons.notifications_active_outlined), label: const Text('Tester la sonnerie maintenant'), onPressed: () => Notif.now('Test d\'alarme', 'Si vous entendez ceci, la sonnerie fonctionne.')),
        const SizedBox(height: 12),
        DropdownButtonFormField<Animal>(value: a, decoration: const InputDecoration(labelText: 'Animal', border: OutlineInputBorder()), items: [for (final x in animals) DropdownMenuItem(value: x, child: Text(x.name))], onChanged: (v) => setState(() => a = v!)),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(value: type, decoration: const InputDecoration(labelText: 'Type', border: OutlineInputBorder()), items: [for (final x in types) DropdownMenuItem(value: x, child: Text(x))], onChanged: (v) => setState(() => type = v!)),
        ListTile(leading: const Icon(Icons.event), title: Text('Date : ${DateFormat('dd/MM/yyyy').format(date)}'), subtitle: Text(daily ? 'Puis chaque jour à la même heure' : 'Une seule fois'), onTap: () async {
          final d = await showDatePicker(context: c, initialDate: date, firstDate: DateTime(2020), lastDate: DateTime(2100));
          if (d != null) setState(() => date = d);
        }),
        SwitchListTile(title: const Text('Répéter chaque jour'), value: daily, onChanged: (v) => setState(() => daily = v)),
        ListTile(leading: const Icon(Icons.alarm), title: Text('Heure : ${t.format(c)}'), onTap: () async { final v = await showTimePicker(context: c, initialTime: t); if (v != null) setState(() => t = v); }),
        FilledButton.icon(icon: const Icon(Icons.alarm_add), label: const Text('Programmer l\'alarme'), onPressed: () => _create(c)),
        const Divider(height: 32),
        for (final r in Notif.all()) ListTile(leading: const Icon(Icons.alarm_on), title: Text(r['label']),
            subtitle: Text('${isDaily(r) ? 'Chaque jour dès le ' : ''}${r['date'] != null ? DateFormat('dd/MM/yyyy').format(DateTime.parse(r['date'])) : ''} à ${r['h'].toString().padLeft(2, '0')}:${r['m'].toString().padLeft(2, '0')}'),
            trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () async { await Notif.remove(r['id']); setState(() {}); })),
      ]);
}
