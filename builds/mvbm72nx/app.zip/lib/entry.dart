import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'data.dart';
import 'notif.dart';
import 'settings.dart';

final _fmt = DateFormat('yyyy-MM-dd');
/// Clé globale : le message s'affiche toujours, même dans les écrans imbriqués
final rootMessenger = GlobalKey<ScaffoldMessengerState>();

void toast(BuildContext c, String m, {bool error = false}) {
  final ms = rootMessenger.currentState ?? ScaffoldMessenger.of(c);
  ms.hideCurrentSnackBar();
  ms.showSnackBar(SnackBar(
    behavior: SnackBarBehavior.floating,
    margin: const EdgeInsets.fromLTRB(16, 0, 16, 96),
    backgroundColor: error ? Colors.red.shade700 : Colors.green.shade700,
    duration: const Duration(seconds: 3),
    content: Row(children: [Icon(error ? Icons.error_outline : Icons.check_circle, color: Colors.white), const SizedBox(width: 10), Expanded(child: Text(m, style: const TextStyle(fontWeight: FontWeight.w700, color: Colors.white)))]),
  ));
}

/// « Enregistré » : message à l'écran + bip + vibration
void saved(BuildContext c, [String m = 'Enregistré ✔']) {
  Notif.beep();
  toast(c, m);
}

// Pour mettre vos images : déposez assets/logos/nourriture.png et assets/logos/piqure.png (sinon icône par défaut)
const _kindFile = {'soin': 'piqure', 'vaccin': 'piqure', 'nourriture': 'nourriture', 'oeufs': '14_oeuf', 'ovente': '14_oeuf', 'oachat': '14_oeuf'};
const _kindIcons = {'achat': Icons.shopping_cart, 'vente': Icons.sell, 'mort': Icons.heart_broken, 'soin': Icons.vaccines, 'vaccin': Icons.event_available,
  'nourriture': Icons.grass, 'eclosion': Icons.egg_alt, 'naissance': Icons.child_friendly, 'oeufs': Icons.egg, 'ovente': Icons.sell, 'oachat': Icons.shopping_cart, 'casses': Icons.egg};
Widget kindBadge(String k, {double s = 24, Color? col}) {
  final ic = Icon(_kindIcons[k] ?? Icons.circle, size: s, color: col);
  final f = _kindFile[k];
  return f == null ? ic : Image.asset('assets/logos/$f.png', width: s, height: s, errorBuilder: (_, __, ___) => ic);
}

String recSub(Map<String, dynamic> r) => [
      r['d'],
      if ('${r['lot'] ?? ''}'.isNotEmpty) 'Lot ${r['lot']}',
      if (r['k'] == 'oeufs') '${r['et'] ?? ''} • cassés ${r['br'] ?? 0} • paquets ${r['pk'] ?? 0}',
      if (r['k'] == 'soin' && '${r['vn'] ?? ''}'.isNotEmpty) 'piqûre n°${r['vn']} ${r['prod'] ?? ''}',
      if (r['k'] == 'nourriture') '${r['q']} × ${r['w']} ${r['u']}',
      if (r['k'] == 'ovente' || r['k'] == 'oachat') '${r['mode'] == 'gros' ? 'en gros' : 'en détail'} ${r['et'] ?? ''}',
      if ((r['r'] ?? 0) > 0) 'rabais ${r['r']}',
      r['n'] ?? '',
    ].where((e) => '$e'.isNotEmpty).join(' • ');

mixin Fields<T extends StatefulWidget> on State<T> {
  final ctl = <String, TextEditingController>{};
  TextEditingController t(String k) => ctl.putIfAbsent(k, () => TextEditingController());
  num v(String k) => num.tryParse(t(k).text.replaceAll(',', '.')) ?? 0;
  void clearAll() { for (final e in ctl.values) { e.clear(); } }
  Widget tf(String k, String label, {bool number = true}) => Padding(
      padding: const EdgeInsets.only(top: 12),
      child: TextField(controller: t(k), keyboardType: number ? TextInputType.number : TextInputType.text, onChanged: (_) => setState(() {}),
          decoration: InputDecoration(labelText: label, border: const OutlineInputBorder())));
  Widget seg(String cur, Map<String, String> opts, void Function(String) on) => Padding(
      padding: const EdgeInsets.only(top: 12),
      child: SegmentedButton<String>(segments: [for (final e in opts.entries) ButtonSegment(value: e.key, label: Text(e.value, style: const TextStyle(fontSize: 12)))],
          selected: {cur}, onSelectionChanged: (s) => setState(() => on(s.first))));
  Widget dateTile(DateTime d, void Function(DateTime) on) => ListTile(leading: const Icon(Icons.event), title: Text(DateFormat('dd/MM/yyyy').format(d)), onTap: () async {
        final x = await showDatePicker(context: context, initialDate: d, firstDate: DateTime(2020), lastDate: DateTime(2100));
        if (x != null) setState(() => on(x));
      });
  Widget totalLine(num tot) => tot == 0 ? const SizedBox() : Padding(padding: const EdgeInsets.only(top: 10),
      child: Text('Total : ${money(tot)}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)));
}

class EntryTab extends StatefulWidget {
  const EntryTab({super.key});
  @override
  State<EntryTab> createState() => _EntryTabState();
}

class _EntryTabState extends State<EntryTab> with Fields<EntryTab> {
  Animal a = animals.first; String kind = 'achat', mode = 'gros', unit = 'kg'; DateTime date = DateTime.now();
  TimeOfDay vt = const TimeOfDay(hour: 7, minute: 0);

  num _total() {
    switch (kind) {
      case 'achat': return (mode == 'gros' ? v('tot') : v('pu') * v('q')) + v('tr');
      case 'vente': return (a.key == 'poisson' ? v('kg') : v('q')) * v('pu') - v('r');
      case 'nourriture': return v('q') * v('pu');
      case 'soin': return v('cost');
    }
    return 0;
  }

  List<Widget> _fields() {
    final fish = a.key == 'poisson';
    final lots = {for (final r in Repo.records.value.where((r) => r['a'] == a.key)) if ('${r['lot'] ?? ''}'.isNotEmpty) '${r['lot']}'}.toList();
    final lot = [tf('lot', kind == 'eclosion' ? 'Lot d\'éclosion' : kind == 'naissance' ? 'Lot de naissance' : 'Lot (ex: Lot A-03)', number: false),
      if (lots.isNotEmpty) Wrap(spacing: 6, children: [for (final l in lots.take(8)) ActionChip(label: Text(l), onPressed: () => setState(() => t('lot').text = l))])];
    final note = tf('n', 'Note', number: false);
    switch (kind) {
      case 'achat': return [tf('q', 'Nombre'), seg(mode, {'gros': 'Prix du lot (gros)', 'detail': 'Prix par tête (détail)'}, (x) => mode = x),
        mode == 'gros' ? tf('tot', 'Prix total du lot') : tf('pu', 'Prix par tête'), tf('tr', 'Transport'), ...lot, note, totalLine(_total())];
      case 'vente': return [tf('q', 'Nombre à vendre'), if (fish) tf('kg', 'Poids total (kg)'), tf('pu', fish ? 'Prix par kg' : 'Prix unitaire'), tf('r', 'Rabais'), ...lot, note, totalLine(_total())];
      case 'mort': return [tf('q', 'Nombre de morts'), ...lot, note];
      case 'soin': return [tf('q', 'Nombre de têtes piquées'), ...lot, tf('vn', 'Quelle piqûre ? (1, 2, 3…)'), tf('prod', 'Vaccin / produit', number: false), tf('cost', 'Coût (optionnel)'), note, totalLine(_total())];
      case 'vaccin': return [tf('prod', 'Vaccin / traitement', number: false), tf('vn', 'Quelle piqûre ? (1, 2, 3…)'), ...lot,
        ListTile(leading: const Icon(Icons.alarm), title: Text('Heure : ${vt.format(context)}'), onTap: () async { final x = await showTimePicker(context: context, initialTime: vt); if (x != null) setState(() => vt = x); }), note];
      case 'eclosion':
      case 'naissance': return [tf('q', 'Nombre'), ...lot, note];
      case 'nourriture': return [tf('q', 'Nombre de sacs / bidons'), tf('w', 'Poids ou volume d\'un sac'), seg(unit, {'kg': 'KG', 'L': 'Litres'}, (x) => unit = x),
        tf('pu', 'Prix par sac / bidon'), note, totalLine(_total()),
        const Padding(padding: EdgeInsets.only(top: 6), child: Text('Sacs de poids différents : faites un enregistrement par poids.', style: TextStyle(fontSize: 11)))];
    }
    return [];
  }

  Future<void> _save() async {
    final q = v('q').toInt();
    if (kind == 'vaccin') {
      if (t('prod').text.isEmpty) return toast(context, 'Entrez le nom du vaccin', error: true);
      final n = t('vn').text.isEmpty ? '' : '(piqûre n°${t('vn').text}) ';
      await Notif.add('Vaccin - ${a.name}', '${t('prod').text} $n${t('lot').text}', vt, date: date);
      clearAll();
      return saved(context, 'Vaccination programmée ✔ le ${DateFormat('dd/MM').format(date)} à ${vt.format(context)}');
    }
    if (q <= 0) return toast(context, 'Entrez un nombre', error: true);
    final fish = a.key == 'poisson';
    final r = <String, dynamic>{'a': a.key, 'k': kind, 'q': q, 'm': _total(), 'lot': t('lot').text.trim(), 'n': t('n').text, 'd': _fmt.format(date)};
    switch (kind) {
      case 'achat': r.addAll({'mode': mode, 'tr': v('tr'), 'pu': mode == 'gros' ? v('tot') / q : v('pu')}); break;
      case 'vente': r.addAll({'pu': v('pu'), 'r': v('r'), if (fish) 'kg': v('kg')}); break;
      case 'soin': r.addAll({'vn': t('vn').text, 'prod': t('prod').text}); break;
      case 'nourriture': r.addAll({'w': v('w'), 'u': unit, 'pu': v('pu'), 'tw': v('w') * q}); break;
    }
    await Repo.add('records', r);
    if (kind == 'mort') await Notif.now('Mortalité - ${a.name}', '$q mort(s) enregistré(s) ${t('lot').text}');
    clearAll();
    if (mounted) saved(context, 'Enregistré ✔ ${a.name} • ${kindLabels[kind]} • $q');
  }

  @override
  Widget build(BuildContext c) {
    if (!a.kinds.contains(kind)) kind = a.kinds.first;
    return ListView(padding: const EdgeInsets.all(16), children: [
      SizedBox(height: 96, child: ListView(scrollDirection: Axis.horizontal, children: [
        for (final x in animals) GestureDetector(onTap: () => setState(() => a = x), child: Container(
          width: 88, margin: const EdgeInsets.only(right: 8), padding: const EdgeInsets.all(4),
          decoration: BoxDecoration(color: x.color.withOpacity(a == x ? .3 : .08), borderRadius: BorderRadius.circular(18), border: a == x ? Border.all(color: x.color, width: 2) : null),
          child: Image.asset(x.logo, fit: BoxFit.contain, errorBuilder: (_, __, ___) => Icon(x.icon, color: x.color)))),
      ])),
      const SizedBox(height: 14),
      Wrap(spacing: 8, children: [for (final k in a.kinds) ChoiceChip(avatar: kindBadge(k, s: 18), label: Text(kindLabels[k]!), selected: kind == k, onSelected: (_) => setState(() => kind = k))]),
      ..._fields(),
      dateTile(date, (d) => date = d),
      FilledButton.icon(icon: Icon(kind == 'vaccin' ? Icons.alarm_add : Icons.save), label: Text(kind == 'vaccin' ? 'Programmer' : 'Enregistrer'), onPressed: _save),
      const Divider(height: 32),
      const Text('Derniers enregistrements', style: TextStyle(fontWeight: FontWeight.bold)),
      ValueListenableBuilder(valueListenable: Repo.records, builder: (_, l, __) => Column(children: [
        for (final r in l.take(15)) ListTile(
          dense: true, leading: kindBadge(r['k'], col: animalOf(r['a']).color),
          title: Text('${animalOf(r['a']).name} • ${kindLabels[r['k']] ?? r['k']} • ${r['q']}'), subtitle: Text(recSub(r)),
          trailing: r['pending'] == true ? const Icon(Icons.cloud_off, size: 18) : Row(mainAxisSize: MainAxisSize.min, children: [
            IconButton(icon: const Icon(Icons.edit_outlined), onPressed: () => editRecord(c, r)),
            IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => Repo.remove('records', r['id']))]),
        ),
      ])),
    ]);
  }
}

class EggTab extends StatefulWidget {
  const EggTab({super.key});
  @override
  State<EggTab> createState() => _EggTabState();
}

class _EggTabState extends State<EggTab> with Fields<EggTab> {
  Animal a = animals.firstWhere((x) => x.egg != null);
  String op = 'oeufs', mode = 'gros'; // op : oeufs = Ramassage • ovente = Vente • oachat = Achat
  DateTime date = DateTime.now();
  int get _ps => v('ps') > 0 ? v('ps').toInt() : AppSettings.packSize;
  num get _tot => v('q') * v('pu') - (op == 'ovente' ? v('r') : 0);

  Future<void> _save() async {
    final q = v('q').toInt();
    if (q <= 0) return toast(context, op == 'oeufs' ? 'Entrez le nombre d\'œufs ramassés' : 'Entrez un nombre', error: true);
    final et = 'Œufs de ${a.egg}';
    if (op == 'oeufs') {
      final br = v('br').toInt();
      if (br > q) return toast(context, 'Les œufs cassés ne peuvent pas dépasser les œufs ramassés', error: true);
      await Repo.add('records', {'a': a.key, 'k': 'oeufs', 'q': q, 'br': br, 'pk': v('pk').toInt(), 'ps': _ps, 'et': et, 'm': 0, 'n': t('n').text, 'd': _fmt.format(date)});
      clearAll();
      return saved(context, 'Enregistré ✔ Ramassage • $q œufs de ${a.egg}');
    }
    await Repo.add('records', {'a': a.key, 'k': op, 'q': q, 'mode': mode, 'ps': _ps, 'u': mode == 'gros' ? q * _ps : q, 'pu': v('pu'), 'r': op == 'ovente' ? v('r') : 0,
      'm': _tot, 'et': et, 'n': t('n').text, 'd': _fmt.format(date)});
    clearAll();
    saved(context, 'Enregistré ✔ ${op == 'ovente' ? 'Vente' : 'Achat'} • $et');
  }

  /// Les paquets peuvent être faits plus tard : on les ajoute ici
  Future<void> _packs(Map<String, dynamic> r) async {
    final pk = TextEditingController(text: '${r['pk'] ?? 0}'), ps = TextEditingController(text: '${r['ps'] ?? AppSettings.packSize}');
    final ok = await showDialog<bool>(context: context, builder: (d) => AlertDialog(
      title: const Text('Nombre de paquets'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: pk, keyboardType: TextInputType.number, autofocus: true, decoration: const InputDecoration(labelText: 'Paquets emballés')),
        TextField(controller: ps, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Œufs par paquet')),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Annuler')), FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('Enregistrer'))],
    ));
    if (ok != true) return;
    await Repo.update('records', r['id'], {'pk': int.tryParse(pk.text) ?? 0, 'ps': int.tryParse(ps.text) ?? AppSettings.packSize});
    if (mounted) saved(context, 'Paquets enregistrés ✔');
  }

  @override
  Widget build(BuildContext c) {
    final gros = mode == 'gros';
    return ListView(padding: const EdgeInsets.all(16), children: [
      DropdownButtonFormField<Animal>(
        value: a, decoration: const InputDecoration(labelText: 'Type d\'œufs', border: OutlineInputBorder()),
        items: [for (final x in animals.where((x) => x.egg != null)) DropdownMenuItem(value: x, child: Row(children: [kindBadge('oeufs', s: 22), const SizedBox(width: 10), Text('Œufs de ${x.egg}')]))],
        onChanged: (x) => setState(() => a = x!)),
      ValueListenableBuilder(valueListenable: Repo.records, builder: (_, __, ___) => Padding(padding: const EdgeInsets.only(top: 12),
        child: Card(color: Colors.amber.shade50, child: ListTile(leading: kindBadge('oeufs', s: 36), title: Text('Stock : ${Repo.eggs(a.key)} œufs'), subtitle: Text('${Repo.packs(a.key)} paquet(s) emballé(s)'))))),
      seg(op, {'oeufs': 'Ramassage', 'ovente': 'Vente', 'oachat': 'Achat'}, (x) => op = x),
      if (op == 'oeufs') ...[
        tf('q', 'Nombre d\'œufs ramassés'),
        tf('br', 'Nombre d\'œufs cassés'),
        tf('pk', 'Nombre de paquets (laissez vide si pas encore emballés)'),
        if (v('pk') > 0) tf('ps', 'Œufs par paquet (${AppSettings.packSize} par défaut)'),
        const Padding(padding: EdgeInsets.only(top: 6), child: Text('Les paquets peuvent être ajoutés plus tard : touchez « Emballer » dans la liste ci-dessous.', style: TextStyle(fontSize: 11))),
        tf('n', 'Note', number: false),
      ] else ...[
        seg(mode, {'gros': 'En gros (paquets)', 'detail': 'En détail (œufs)'}, (x) => mode = x),
        tf('q', gros ? 'Nombre de paquets' : 'Nombre d\'œufs'),
        if (gros) tf('ps', 'Œufs par paquet (${AppSettings.packSize} par défaut)'),
        tf('pu', gros ? 'Prix par paquet' : 'Prix par œuf'),
        if (op == 'ovente') tf('r', 'Rabais'),
        tf('n', op == 'ovente' ? 'Client / note' : 'Fournisseur / note', number: false),
        totalLine(_tot),
      ],
      dateTile(date, (d) => date = d),
      FilledButton.icon(icon: const Icon(Icons.save), label: const Text('Enregistrer'), onPressed: _save),
      const Divider(height: 32),
      Text(op == 'oeufs' ? 'Derniers ramassages' : op == 'ovente' ? 'Dernières ventes' : 'Derniers achats', style: const TextStyle(fontWeight: FontWeight.bold)),
      ValueListenableBuilder(valueListenable: Repo.records, builder: (_, l, __) => Column(children: [
        for (final r in l.where((r) => r['k'] == op && r['a'] == a.key).take(15)) ListTile(
          dense: true, leading: kindBadge(r['k']),
          title: Text(op == 'oeufs' ? '${r['q']} œufs ramassés • ${r['br'] ?? 0} cassés' : '${kindLabels[r['k']]} • ${r['q']} ${r['mode'] == 'gros' ? 'paquet(s)' : 'œuf(s)'}'), subtitle: Text(recSub(r)),
          trailing: r['pending'] == true ? const Icon(Icons.cloud_off, size: 18) : Row(mainAxisSize: MainAxisSize.min, children: [
            if (op == 'oeufs') TextButton(onPressed: () => _packs(r), child: Text(((r['pk'] ?? 0) as num) > 0 ? '${r['pk']} paq.' : 'Emballer'))
            else Text(f0(r['m'] ?? 0), style: const TextStyle(fontWeight: FontWeight.bold)),
            IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => Repo.remove('records', r['id']))])),
      ])),
    ]);
  }
}

String f0(num n) => money(n);

Future<void> editRecord(BuildContext c, Map<String, dynamic> r) {
  final k = r['k'];
  final ctl = {for (final x in ['q', 'm', 'lot', 'n', 'br', 'pk', 'ps']) x: TextEditingController(text: '${r[x] ?? ''}')};
  Widget tf(String x, String l, {bool isNum = true}) => TextField(controller: ctl[x], keyboardType: isNum ? TextInputType.number : TextInputType.text, decoration: InputDecoration(labelText: l));
  return showDialog(context: c, builder: (_) => AlertDialog(
    title: const Text('Modifier'),
    content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
      tf('q', k == 'oeufs' ? 'Œufs pondus' : 'Nombre'),
      if (k == 'oeufs') ...[tf('br', 'Œufs cassés'), tf('pk', 'Nombre de paquets'), tf('ps', 'Œufs par paquet')] else tf('m', 'Montant'),
      tf('lot', 'Lot', isNum: false), tf('n', 'Note', isNum: false),
    ])),
    actions: [TextButton(onPressed: () async {
      int i(String x) => int.tryParse(ctl[x]!.text) ?? 0;
      final u = <String, dynamic>{'q': i('q'), 'lot': ctl['lot']!.text, 'n': ctl['n']!.text};
      if (k == 'oeufs') { u.addAll({'br': i('br'), 'pk': i('pk'), 'ps': i('ps') > 0 ? i('ps') : 30}); } else { u['m'] = num.tryParse(ctl['m']!.text) ?? 0; }
      await Repo.update('records', r['id'], u);
      if (c.mounted) { Navigator.pop(c); saved(c, 'Modification enregistrée ✔'); }
    }, child: const Text('Enregistrer'))],
  ));
}
