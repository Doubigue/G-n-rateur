package com.doubigue.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.graphics.Color
import com.doubigue.ai.ui.DoubigueApp

class MainActivity : ComponentActivity() {
    override fun onStart() {
        super.onStart()
        com.doubigue.ai.events.EventSounds.playWelcomeOnce(applicationContext)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        runCatching { com.doubigue.ai.data.BackupManager.applyPendingRestore(applicationContext) }
        window.statusBarColor = android.graphics.Color.rgb(8, 11, 18)
        window.navigationBarColor = android.graphics.Color.rgb(8, 11, 18)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Color(0xFF78DCE8), background = Color(0xFF080B12), surface = Color(0xFF111827)
            )) { DoubigueApp() }
        }
    }
}
