package com.doubigue.ai.apps

import android.app.ActivityManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.provider.Settings
import android.os.Process
import android.os.Build
import java.util.Locale

data class InstalledApp(val label: String, val packageName: String, val icon: android.graphics.drawable.Drawable)
enum class AppState { FOREGROUND, BACKGROUND_OR_STOPPED, UNKNOWN }

class AppController(private val context: Context) {
    fun installedApps(): List<InstalledApp> {
        val pm = context.packageManager
        return pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { pm.getLaunchIntentForPackage(it.packageName) != null && it.packageName != context.packageName }
            .map { InstalledApp(pm.getApplicationLabel(it).toString(), it.packageName, pm.getApplicationIcon(it)) }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }
    }

    fun findBySpokenName(spoken: String): InstalledApp? {
        val key = normalize(spoken)
        return installedApps().firstOrNull { normalize(it.label) == key }
            ?: installedApps().firstOrNull { normalize(it.label).contains(key) && key.length >= 3 }
    }

    fun stateOf(packageName: String): AppState {
        if (!hasUsageAccess()) return AppState.UNKNOWN
        return try {
            val manager = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val end = System.currentTimeMillis()
            val events = manager.queryEvents(end - 60_000, end)
            val event = UsageEvents.Event()
            val resumed = if (Build.VERSION.SDK_INT >= 29) UsageEvents.Event.ACTIVITY_RESUMED else UsageEvents.Event.MOVE_TO_FOREGROUND
            val home = context.packageManager.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)?.activityInfo?.packageName
            // Ordre des applications passées au premier plan (sans doublons consécutifs).
            val order = mutableListOf<String>()
            while (events.hasNextEvent()) {
                events.getNextEvent(event)
                if (event.eventType == resumed && order.lastOrNull() != event.packageName) order.add(event.packageName)
            }
            var current = order.lastOrNull()
            // Quand on parle à DOUBIGUE, c'est lui qui est au premier plan : l'application « ouverte »
            // est alors celle qui était juste avant (sauf si on est passé par l'écran d'accueil).
            if (current == context.packageName) current = order.getOrNull(order.size - 2)
            if (current == home) current = null
            if (current == packageName) AppState.FOREGROUND else AppState.BACKGROUND_OR_STOPPED
        } catch (_: Exception) { AppState.UNKNOWN }
    }

    fun hasUsageAccess(): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager
        val mode = appOps.checkOpNoThrow("android:get_usage_stats", Process.myUid(), context.packageName)
        return mode == android.app.AppOpsManager.MODE_ALLOWED
    }

    fun openUsageAccessSettings() { context.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }

    fun toggleByName(name: String, announce: (String) -> Unit): Boolean {
        val app = findBySpokenName(name) ?: return false
        val state = stateOf(app.packageName)
        if (state == AppState.FOREGROUND) {
            // Android does not expose a public API to force-stop another app. Home is the safe fallback.
            val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(home)
            announce("${app.label} quitté. Retour à l'accueil.")
        } else {
            val launch = context.packageManager.getLaunchIntentForPackage(app.packageName)
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                context.startActivity(launch)
                announce("${app.label} ouvert.")
            } else return false
        }
        return true
    }

    private fun normalize(value: String) = value.lowercase(Locale.FRENCH).trim().replace(" ", "").replace("-", "")
}
