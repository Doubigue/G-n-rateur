package com.dlvibestudio.dlturbo.engine

import android.content.Context
import com.dlvibestudio.dlturbo.data.DlStatus
import com.dlvibestudio.dlturbo.data.DownloadRepository
import com.dlvibestudio.dlturbo.data.Settings
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.runInterruptible
import kotlinx.coroutines.withContext
import java.io.File
import org.json.JSONObject
import java.io.IOException
import java.util.UUID
import kotlin.coroutines.coroutineContext

/**
 * Téléchargement de vidéos depuis les sites de partage (YouTube, Instagram, Facebook,
 * TikTok, Pinterest, X/Twitter et plus d'un millier d'autres) grâce à yt-dlp + ffmpeg.
 */
class VideoEngine(
    private val context: Context,
    private val repo: DownloadRepository,
    private val settings: Settings,
    scope: CoroutineScope,
) {
    /** null = prêt ; sinon, l'erreur d'initialisation. */
    private val ready = CompletableDeferred<Throwable?>()

    init {
        scope.launch(Dispatchers.IO) {
            val error = try {
                YoutubeDL.getInstance().init(context)
                FFmpeg.getInstance().init(context)
                null
            } catch (t: Throwable) {
                t
            }
            ready.complete(error)
            // YouTube change souvent : yt-dlp est mis à jour tout seul, au plus une fois par jour,
            // après une pause pour ne pas ralentir les premières analyses.
            if (error == null) {
                val prefs = context.getSharedPreferences("ytdlp", Context.MODE_PRIVATE)
                if (System.currentTimeMillis() - prefs.getLong("updatedAt", 0L) > 24 * 3600_000L) {
                    kotlinx.coroutines.delay(15_000)
                    runCatching { YoutubeDL.getInstance().updateYoutubeDL(context) }
                        .onSuccess { prefs.edit().putLong("updatedAt", System.currentTimeMillis()).apply() }
                }
            }
        }
    }

    suspend fun run(id: String): File? {
        val item = repo.get(id) ?: throw FatalDownloadException("Téléchargement introuvable")
        val cfg = settings.value
        repo.update(id) { it.copy(info = "Analyse du lien…") }

        ready.await()?.let {
            throw FatalDownloadException("Module vidéo indisponible : ${it.message ?: it.javaClass.simpleName}")
        }

        val dir = File(item.dir)
        if (!dir.exists() && !dir.mkdirs() && !dir.exists()) {
            throw FatalDownloadException("Impossible de créer le dossier ${dir.path}")
        }

        val quality = item.quality.ifBlank { cfg.videoQuality }
        val wholePlaylist = item.playlist || cfg.wholePlaylist
        val request = YoutubeDLRequest(item.url)
        val template = if (wholePlaylist)
            "%(playlist_title|Playlist).80B/%(playlist_index|)s %(title).100B [%(id)s].%(ext)s"
        else if (item.outName.isNotBlank()) item.outName.replace("%", "") + ".%(ext)s"
        else "%(title).120B [%(id)s].%(ext)s"
        request.addOption("-o", File(dir, template).path)
        request.addOption("--no-mtime")
        request.addOption("--continue")
        request.addOption("--newline")
        request.addOption("--retries", cfg.retries.coerceAtLeast(1))
        request.addOption("--fragment-retries", cfg.retries.coerceAtLeast(1))
        request.addOption("--concurrent-fragments", cfg.videoFragments)
        // User-Agent de navigateur seulement pour un flux repéré dans une page (le serveur attend le même
        // navigateur) ; ailleurs yt-dlp choisit lui-même, c'est indispensable pour YouTube.
        if (item.referer.isNotBlank()) {
            request.addOption("--user-agent", cfg.userAgent.ifBlank { com.dlvibestudio.dlturbo.data.SettingsData.DEFAULT_UA })
        }
        if (wholePlaylist) {
            request.addOption("--yes-playlist")
            request.addOption("--ignore-errors") // une vidéo indisponible ne bloque pas les autres
        } else {
            request.addOption("--no-playlist")
        }
        if (item.referer.isNotBlank()) request.addOption("--referer", item.referer)
        if (item.cookie.isNotBlank()) request.addOption("--add-header", "Cookie:" + item.cookie)
        if (cfg.speedLimit > 0) request.addOption("--limit-rate", "${cfg.speedLimit / 1024}K")

        when (quality) {
            "audio", "mp3" -> {
                request.addOption("-f", "ba/b")
                request.addOption("-x")
                request.addOption("--audio-format", "mp3")
                request.addOption("--audio-quality", "0")
            }
            "wav" -> {
                request.addOption("-f", "ba/b")
                request.addOption("-x")
                request.addOption("--audio-format", "wav")
            }
            "m4a" -> {
                request.addOption("-f", "ba[ext=m4a]/ba/b")
                request.addOption("-x")
                request.addOption("--audio-format", "m4a")
            }
            "best" -> request.addOption("-f", "bv*+ba/b")
            else -> {
                val h = quality.toIntOrNull() ?: 720
                request.addOption("-f", "bv*[height<=$h]+ba/b[height<=$h]/bv*+ba/b")
            }
        }
        if (!isAudioQuality(quality) && cfg.preferMp4) {
            request.addOption("-S", "ext:mp4:m4a")
            request.addOption("--merge-output-format", "mp4")
        }

        var outputPath: String? = null
        var lastUpdate = 0L

        try {
            runInterruptible(Dispatchers.IO) {
                YoutubeDL.getInstance().execute(request, id) { progress, _, line ->
                    parseDestination(line)?.let { path ->
                        outputPath = path
                        val name = File(path).name
                        repo.update(id) { it.copy(fileName = name, autoName = false) }
                    }
                    val now = System.currentTimeMillis()
                    if (now - lastUpdate >= 400) {
                        lastUpdate = now
                        val total = parseSize(TOTAL_REGEX, line)
                        val speed = parseSize(SPEED_REGEX, line)
                        val position = ITEM_REGEX.find(line)
                        val stage = when {
                            position != null -> "Vidéo ${position.groupValues[1]}/${position.groupValues[2]}"
                            line.startsWith("[Merger]") -> "Fusion vidéo + audio…"
                            line.startsWith("[ExtractAudio]") -> "Conversion audio…"
                            line.startsWith("[download]") -> "Téléchargement"
                            else -> null
                        }
                        repo.update(id) {
                            it.copy(
                                status = if (it.status == DlStatus.CONNECTING || it.status == DlStatus.QUEUED)
                                    DlStatus.RUNNING else it.status,
                                percent = if (progress >= 0f) progress else it.percent,
                                totalBytes = if (total > 0) total else it.totalBytes,
                                downloadedBytes = if (total > 0 && progress >= 0f)
                                    (total * (progress / 100f)).toLong() else it.downloadedBytes,
                                speed = if (speed >= 0) speed else it.speed,
                                info = stage ?: it.info,
                            )
                        }
                    }
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: InterruptedException) {
            throw CancellationException("Annulé")
        } catch (e: Exception) {
            // Processus arrêté volontairement (pause / suppression) : ce n'est pas une erreur.
            if (e.javaClass.simpleName == "CanceledException") throw CancellationException("Annulé")
            coroutineContext.ensureActive()
            throw IOException(cleanError(e.message))
        } finally {
            // Arrête le processus yt-dlp s'il tourne encore (pause, suppression).
            // Les fichiers partiels (.part) restent sur le disque : la reprise continue dessus.
            runCatching { YoutubeDL.getInstance().destroyProcessById(id) }
            repo.update(id) { it.copy(speed = 0) }
        }

        val file = outputPath?.let { File(it) }?.takeIf { it.exists() }
        if (file != null) {
            val length = file.length()
            repo.update(id) {
                it.copy(fileName = file.name, totalBytes = length, downloadedBytes = length, percent = 100f)
            }
        }
        return file
    }

    /** Met à jour yt-dlp (les sites changent souvent : à faire quand un site ne marche plus). */
    suspend fun update(): String = withContext(Dispatchers.IO) {
        ready.await()?.let { return@withContext "Module vidéo indisponible : ${it.message}" }
        try {
            val status = YoutubeDL.getInstance().updateYoutubeDL(context)
            val version = YoutubeDL.getInstance().version(context) ?: ""
            if (status?.toString() == "ALREADY_UP_TO_DATE") "yt-dlp est déjà à jour ($version)"
            else "yt-dlp mis à jour ($version)"
        } catch (e: Throwable) {
            "Échec de la mise à jour : ${e.message ?: "erreur inconnue"}"
        }
    }

    private fun parseDestination(line: String): String? {
        for (regex in DEST_REGEXES) {
            regex.find(line)?.let { return it.groupValues[1].trim() }
        }
        return null
    }

    private fun parseSize(regex: Regex, line: String): Long {
        val m = regex.find(line) ?: return -1
        val value = m.groupValues[1].toDoubleOrNull() ?: return -1
        val factor = when (m.groupValues[2]) {
            "KiB" -> 1024.0
            "MiB" -> 1024.0 * 1024
            "GiB" -> 1024.0 * 1024 * 1024
            else -> 1.0
        }
        return (value * factor).toLong()
    }

    private fun cleanError(message: String?): String {
        if (message.isNullOrBlank()) return "Échec de l'extraction de la vidéo"
        val line = message.lines().lastOrNull { it.contains("ERROR") } ?: message.lines().last { it.isNotBlank() }
        return line.replace("ERROR:", "").trim().take(240)
    }

    /**
     * Interroge yt-dlp et renvoie son résultat JSON (`-J`) : infos d'une vidéo, formats disponibles,
     * résultats de recherche ou contenu d'une playlist. Annulable.
     */
    suspend fun dumpJson(url: String, vararg options: Pair<String, String?>): JSONObject {
        ready.await()?.let {
            throw IOException("Module vidéo indisponible : ${it.message ?: it.javaClass.simpleName}")
        }
        val cfg = settings.value
        val request = YoutubeDLRequest(url)
        request.addOption("-J")
        request.addOption("--no-warnings")
        // Pas de User-Agent imposé : yt-dlp choisit lui-même celui qui convient à chaque site (YouTube surtout).
        request.addOption("--socket-timeout", "15")
        request.addOption("--extractor-retries", "1")
        for ((key, value) in options) {
            if (value == null) request.addOption(key) else request.addOption(key, value)
        }
        val processId = "info-" + UUID.randomUUID().toString().take(8)
        try {
            val response = runInterruptible(Dispatchers.IO) {
                YoutubeDL.getInstance().execute(request, processId, null)
            }
            val text = response.out.trim()
            val start = text.indexOf('{')
            if (start < 0) throw IOException("Réponse vide du moteur vidéo")
            return JSONObject(text.substring(start))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            if (e.javaClass.simpleName == "CanceledException") throw CancellationException("Annulé")
            coroutineContext.ensureActive()
            if (e is IOException) throw e
            throw IOException(cleanError(e.message))
        } finally {
            runCatching { YoutubeDL.getInstance().destroyProcessById(processId) }
        }
    }

    companion object {
        private val ITEM_REGEX = Regex("""Downloading item (\d+) of (\d+)""")

        fun isAudioQuality(q: String) = q == "audio" || q == "mp3" || q == "wav" || q == "m4a"

        private val DEST_REGEXES = listOf(
            Regex("""^\[Merger\] Merging formats into "(.+)"\s*$"""),
            Regex("""^\[ExtractAudio\] Destination: (.+)$"""),
            Regex("""^\[download\] Destination: (.+)$"""),
            Regex("""^\[download\] (.+) has already been downloaded$"""),
        )
        private val TOTAL_REGEX = Regex("""of\s+~?\s*([\d.]+)\s*(KiB|MiB|GiB|B)""")
        private val SPEED_REGEX = Regex("""at\s+([\d.]+)\s*(KiB|MiB|GiB|B)/s""")
    }
}
