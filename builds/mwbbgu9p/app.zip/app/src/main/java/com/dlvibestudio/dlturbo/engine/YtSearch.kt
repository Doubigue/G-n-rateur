package com.dlvibestudio.dlturbo.engine

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runInterruptible
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder

/**
 * Recherche YouTube directe : une seule requête sur la page de résultats, dont on lit les données
 * intégrées (ytInitialData). Bien plus rapide que de lancer yt-dlp, qui reste la solution de secours.
 */
object YtSearch {

    private const val DESKTOP_UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"

    suspend fun search(client: OkHttpClient, query: String, playlists: Boolean): List<YtEntry> {
        val q = URLEncoder.encode(query, "UTF-8")
        val url = "https://www.youtube.com/results?search_query=$q&hl=fr" + if (playlists) "&sp=EgIQAw%3D%3D" else ""
        val request = Request.Builder().url(url)
            .header("User-Agent", DESKTOP_UA)
            .header("Accept-Language", "fr-FR,fr;q=0.9,en;q=0.6")
            .header("Cookie", "SOCS=CAI; CONSENT=YES+1")
            .build()
        val html = runInterruptible(Dispatchers.IO) {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) throw IOException("YouTube a répondu ${response.code}")
                response.body?.string() ?: throw IOException("Réponse vide de YouTube")
            }
        }
        val json = extractInitialData(html) ?: throw IOException("Résultats YouTube illisibles")
        val out = ArrayList<YtEntry>()
        val seen = HashSet<String>()
        walk(JSONObject(json), out, seen, 0)
        return out
    }

    /** Isole l'objet JSON qui suit « ytInitialData = » en comptant les accolades (hors chaînes). */
    private fun extractInitialData(html: String): String? {
        val marker = html.indexOf("ytInitialData")
        if (marker < 0) return null
        val start = html.indexOf('{', marker)
        if (start < 0 || start - marker > 40) return null
        var depth = 0
        var inString = false
        var escaped = false
        var i = start
        while (i < html.length) {
            val c = html[i]
            if (inString) {
                if (escaped) escaped = false
                else if (c == '\\') escaped = true
                else if (c == '"') inString = false
            } else {
                when (c) {
                    '"' -> inString = true
                    '{' -> depth++
                    '}' -> {
                        depth--
                        if (depth == 0) return html.substring(start, i + 1)
                    }
                }
            }
            i++
        }
        return null
    }

    private fun walk(node: Any?, out: MutableList<YtEntry>, seen: MutableSet<String>, depth: Int) {
        if (depth > 40 || out.size >= 60) return
        when (node) {
            is JSONObject -> {
                node.optJSONObject("videoRenderer")?.let { video(it)?.let { e -> if (seen.add(e.url)) out.add(e) } }
                node.optJSONObject("playlistRenderer")?.let { playlist(it)?.let { e -> if (seen.add(e.url)) out.add(e) } }
                node.optJSONObject("lockupViewModel")?.let { lockup(it)?.let { e -> if (seen.add(e.url)) out.add(e) } }
                val keys = node.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    if (k == "videoRenderer" || k == "playlistRenderer" || k == "lockupViewModel") continue
                    val v = node.opt(k)
                    if (v is JSONObject || v is JSONArray) walk(v, out, seen, depth + 1)
                }
            }
            is JSONArray -> for (i in 0 until node.length()) walk(node.opt(i), out, seen, depth + 1)
        }
    }

    private fun text(o: JSONObject?): String {
        if (o == null) return ""
        o.optString("simpleText").takeIf { it.isNotBlank() }?.let { return it }
        o.optString("content").takeIf { it.isNotBlank() }?.let { return it }
        val runs = o.optJSONArray("runs") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until runs.length()) sb.append(runs.optJSONObject(i)?.optString("text").orEmpty())
        return sb.toString()
    }

    private fun video(v: JSONObject): YtEntry? {
        val id = v.optString("videoId")
        if (id.isBlank()) return null
        return YtEntry(
            id = id,
            url = "https://www.youtube.com/watch?v=$id",
            title = text(v.optJSONObject("title")).ifBlank { "Sans titre" },
            channel = text(v.optJSONObject("ownerText")).ifBlank { text(v.optJSONObject("longBylineText")) },
            durationSec = clock(text(v.optJSONObject("lengthText"))),
            views = text(v.optJSONObject("viewCountText")).filter(Char::isDigit).take(15).toLongOrNull() ?: 0,
            thumbnail = VideoInfo.thumbnailFor(id),
            isPlaylist = false,
        )
    }

    private fun playlist(p: JSONObject): YtEntry? {
        val id = p.optString("playlistId")
        if (id.isBlank()) return null
        return YtEntry(
            id = id,
            url = "https://www.youtube.com/playlist?list=$id",
            title = text(p.optJSONObject("title")).ifBlank { "Playlist" },
            channel = text(p.optJSONObject("longBylineText")).ifBlank { text(p.optJSONObject("shortBylineText")) },
            durationSec = 0,
            views = 0,
            thumbnail = firstImage(p) ?: "",
            isPlaylist = true,
            count = p.optString("videoCount").filter(Char::isDigit).take(6).toIntOrNull() ?: 0,
        )
    }

    /** Nouveau format des playlists dans les résultats. */
    private fun lockup(l: JSONObject): YtEntry? {
        val id = l.optString("contentId")
        val type = l.optString("contentType")
        if (id.isBlank() || !type.contains("PLAYLIST")) return null
        val meta = l.optJSONObject("metadata")?.optJSONObject("lockupMetadataViewModel")
        return YtEntry(
            id = id,
            url = "https://www.youtube.com/playlist?list=$id",
            title = text(meta?.optJSONObject("title")).ifBlank { "Playlist" },
            channel = "",
            durationSec = 0,
            views = 0,
            thumbnail = firstImage(l.optJSONObject("contentImage")) ?: "",
            isPlaylist = true,
            count = 0,
        )
    }

    /** Première adresse d'image trouvée dans un objet (miniature). */
    private fun firstImage(node: Any?, depth: Int = 0): String? {
        if (depth > 12) return null
        when (node) {
            is JSONObject -> {
                val url = node.optString("url")
                if (url.startsWith("http") && (url.contains("ytimg") || url.contains("ggpht"))) return url
                if (url.startsWith("//") && url.contains("ytimg")) return "https:$url"
                val keys = node.keys()
                while (keys.hasNext()) {
                    val v = node.opt(keys.next())
                    if (v is JSONObject || v is JSONArray) firstImage(v, depth + 1)?.let { return it }
                }
            }
            is JSONArray -> for (i in 0 until node.length()) firstImage(node.opt(i), depth + 1)?.let { return it }
        }
        return null
    }

    private fun clock(t: String): Long {
        val parts = t.trim().split(':').mapNotNull { it.trim().toLongOrNull() }
        if (parts.isEmpty() || parts.size > 3) return 0
        return parts.fold(0L) { acc, v -> acc * 60 + v }
    }
}
