package com.dlvibestudio.dlturbo

import android.app.Application
import com.dlvibestudio.dlturbo.data.DownloadRepository
import com.dlvibestudio.dlturbo.data.Settings
import com.dlvibestudio.dlturbo.engine.DownloadManager
import com.dlvibestudio.dlturbo.service.Notifications
import com.dlvibestudio.dlturbo.ui.ViewerRequest
import com.dlvibestudio.dlturbo.ui.WebHub
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.File

class App : Application() {

    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    lateinit var settings: Settings
        private set
    lateinit var repo: DownloadRepository
        private set
    lateinit var manager: DownloadManager
        private set

    /** Visionneuse plein écran affichée par-dessus l'application (lecteur, image, archive…). */
    val viewer = MutableStateFlow<ViewerRequest?>(null)

    /** Demande d'ouverture d'un dossier dans l'onglet Fichiers. */
    val openFolder = MutableStateFlow<File?>(null)

    /** Navigateur en cours (WebViews) ; null tant que l'activité n'existe pas. */
    @Volatile
    var hub: WebHub? = null

    /** Une vidéo est affichée dans le lecteur : l activité peut passer en fenêtre flottante (PiP). */
    @Volatile
    var videoOnScreen: Boolean = false

    override fun onCreate() {
        super.onCreate()
        instance = this
        Notifications.createChannels(this)
        settings = Settings(this)
        repo = DownloadRepository(this, scope)
        manager = DownloadManager(this, repo, settings, scope)
    }

    companion object {
        lateinit var instance: App
            private set
    }
}
