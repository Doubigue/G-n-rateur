@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package com.dlvibestudio.dlturbo.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.view.ViewGroup
import android.widget.Toast
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Tab
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.dlvibestudio.dlturbo.App
import com.dlvibestudio.dlturbo.engine.Links
import java.io.File

private data class Site(val name: String, val url: String, val color: Color)

private val SITES = listOf(
    Site("YouTube", "", Color(0xFFE62117)),
    Site("Facebook", "https://m.facebook.com", Color(0xFF1877F2)),
    Site("Instagram", "https://www.instagram.com", Color(0xFFC13584)),
    Site("TikTok", "https://www.tiktok.com", Color(0xFF2B2B33)),
    Site("Pinterest", "https://www.pinterest.com", Color(0xFFE60023)),
    Site("X", "https://x.com", Color(0xFF14171A)),
    Site("Vimeo", "https://vimeo.com", Color(0xFF1AB7EA)),
    Site("Dailymotion", "https://www.dailymotion.com", Color(0xFF0066DC)),
    Site("Twitch", "https://www.twitch.tv", Color(0xFF9146FF)),
    Site("Reddit", "https://www.reddit.com", Color(0xFFFF4500)),
    Site("Google", "https://www.google.com", Color(0xFF4285F4)),
    Site("Wikipédia", "https://fr.m.wikipedia.org", Color(0xFF636466)),
)

private fun isBlank(url: String) = url.isBlank() || url == "about:blank"

/** Navigateur : onglets, barre d'adresse, blocage des pubs / traqueurs / pop-ups, téléchargement de vidéos. */
@Composable
fun BrowserScreen(app: App, hub: WebHub, onOpenYoutube: () -> Unit) {
    val context = LocalContext.current
    val settings by app.settings.data.collectAsState()

    LaunchedEffect(Unit) { if (hub.tabs.isEmpty()) hub.newBrowserTab() }
    val tab = hub.current
    if (tab == null) {
        Box(Modifier.fillMaxSize())
        return
    }

    var menuOpen by remember { mutableStateOf(false) }
    var tabsOpen by remember { mutableStateOf(false) }
    val home = isBlank(tab.url)

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        AddressBar(hub, tab)
        if (tab.progress < 100 && !home) {
            LinearProgressIndicator(
                progress = { tab.progress / 100f },
                modifier = Modifier.fillMaxWidth().height(2.dp),
            )
        } else {
            Spacer(Modifier.height(2.dp))
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (home) {
                BrowserHome(hub, tab, onOpenYoutube)
            } else {
                key(tab.id, tab.generation) {
                    AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = {
                            val wv = tab.webView
                            (wv.parent as? ViewGroup)?.removeView(wv)
                            wv
                        },
                    )
                }
                val ready = tab.hasVideo || tab.media.isNotEmpty()
                BadgedBox(
                    badge = {
                        if (tab.media.isNotEmpty()) Badge { Text(tab.media.size.toString()) }
                    },
                    modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
                ) {
                    SmallFloatingActionButton(
                        onClick = { hub.mediaSheet.value = tab },
                        containerColor = if (ready) Color(0xFFF5B301) else MaterialTheme.colorScheme.primary,
                        contentColor = if (ready) Color(0xFF1A1300) else MaterialTheme.colorScheme.onPrimary,
                    ) {
                        Icon(Icons.Filled.Download, contentDescription = "Télécharger depuis cette page")
                    }
                }
            }
        }

        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = { tab.webView.goBack() }, enabled = tab.canGoBack && !home) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Page précédente")
            }
            IconButton(onClick = { tab.webView.goForward() }, enabled = tab.canGoForward && !home) {
                Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Page suivante")
            }
            IconButton(onClick = {
                if (tab.progress < 100) tab.webView.stopLoading() else tab.webView.reload()
            }, enabled = !home) {
                Icon(
                    if (tab.progress < 100) Icons.Filled.Close else Icons.Filled.Refresh,
                    contentDescription = "Actualiser",
                )
            }
            IconButton(onClick = { tab.webView.loadUrl("about:blank") }) {
                Icon(Icons.Filled.Home, contentDescription = "Accueil")
            }
            // Bouclier : nombre de requêtes bloquées ; un appui active / désactive le blocage.
            Row(
                Modifier.clip(RoundedCornerShape(16.dp))
                    .clickable { app.settings.update { it.copy(blockAds = !it.blockAds) } }
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(
                    Icons.Filled.Security,
                    contentDescription = "Blocage des publicités",
                    tint = if (settings.blockAds) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(22.dp),
                )
                Text(
                    if (settings.blockAds) " ${hub.blocked}" else " off",
                    style = MaterialTheme.typography.labelMedium,
                )
            }
            Box {
                IconButton(onClick = { tabsOpen = true }) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.Tab, contentDescription = "Onglets")
                        Text(
                            hub.tabs.size.toString(),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                    }
                }
            }
            Box {
                IconButton(onClick = { menuOpen = true }) {
                    Icon(Icons.Filled.MoreVert, contentDescription = "Menu")
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(
                        text = { Text("Nouvel onglet") },
                        onClick = { menuOpen = false; hub.newBrowserTab() },
                    )
                    if (!home) {
                        DropdownMenuItem(
                            text = { Text("Liste d'épisodes / playlist") },
                            onClick = { menuOpen = false; hub.scanEpisodes(tab) },
                        )
                        DropdownMenuItem(
                            text = { Text("Images de la page") },
                            onClick = { menuOpen = false; hub.scanImages(tab) },
                        )
                        DropdownMenuItem(
                            text = {
                                Text(if (hub.bookmarks.contains(tab.url)) "Retirer des favoris" else "Ajouter aux favoris")
                            },
                            onClick = { menuOpen = false; hub.bookmarks.toggle(tab.title, tab.url) },
                        )
                        DropdownMenuItem(
                            text = { Text("Enregistrer la page hors ligne") },
                            onClick = { menuOpen = false; savePage(context, app, tab) },
                        )
                        DropdownMenuItem(
                            text = { Text("Copier le lien") },
                            onClick = { menuOpen = false; copy(context, tab.url) },
                        )
                        DropdownMenuItem(
                            text = { Text("Partager le lien") },
                            onClick = {
                                menuOpen = false
                                val send = Intent(Intent.ACTION_SEND).setType("text/plain")
                                    .putExtra(Intent.EXTRA_TEXT, tab.url)
                                context.startActivity(
                                    Intent.createChooser(send, "Partager").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                )
                            },
                        )
                    }
                    DropdownMenuItem(
                        text = { Text(if (tab.desktop) "Version mobile" else "Version ordinateur") },
                        onClick = { menuOpen = false; hub.setDesktop(tab, !tab.desktop) },
                    )
                    DropdownMenuItem(
                        text = { Text("Effacer les données de navigation") },
                        onClick = {
                            menuOpen = false
                            hub.clearData()
                            Toast.makeText(context, "Cookies, cache et historique effacés", Toast.LENGTH_SHORT).show()
                        },
                    )
                }
            }
        }
    }

    if (tabsOpen) TabSwitcher(hub, onDismiss = { tabsOpen = false })
    HitDialog(app, hub)
}

@Composable
private fun AddressBar(hub: WebHub, tab: WebTab) {
    val focus = LocalFocusManager.current
    var text by remember(tab.id, tab.url) { mutableStateOf(if (isBlank(tab.url)) "" else tab.url) }
    val colors = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        BasicTextField(
            value = text,
            onValueChange = { text = it },
            singleLine = true,
            textStyle = TextStyle(color = colors.onSurface, fontSize = 15.sp),
            cursorBrush = SolidColor(colors.primary),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go, keyboardType = KeyboardType.Uri),
            keyboardActions = KeyboardActions(onGo = {
                hub.load(tab, text)
                focus.clearFocus()
            }),
            modifier = Modifier.weight(1f),
            decorationBox = { inner ->
                Row(
                    Modifier.fillMaxWidth().height(42.dp)
                        .clip(RoundedCornerShape(21.dp))
                        .background(colors.surfaceContainerHigh)
                        .padding(horizontal = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        if (tab.url.startsWith("https://")) Icons.Filled.Lock else Icons.Filled.Search,
                        contentDescription = null,
                        tint = colors.onSurfaceVariant,
                        modifier = Modifier.size(18.dp),
                    )
                    Spacer(Modifier.width(10.dp))
                    Box(Modifier.weight(1f)) {
                        if (text.isEmpty()) {
                            Text("Rechercher ou saisir une adresse", color = colors.onSurfaceVariant, fontSize = 15.sp)
                        }
                        inner()
                    }
                    if (text.isNotEmpty()) {
                        Icon(
                            Icons.Filled.Close,
                            contentDescription = "Effacer",
                            tint = colors.onSurfaceVariant,
                            modifier = Modifier.size(18.dp).clickable { text = "" },
                        )
                    }
                }
            },
        )
    }
}

@Composable
private fun BrowserHome(hub: WebHub, tab: WebTab, onOpenYoutube: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        Spacer(Modifier.height(16.dp))
        Text(
            "Navigation protégée",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
        )
        Text(
            "Publicités, traqueurs et pop-ups bloqués sur tous les sites. " +
                "Ouvrez un site, puis appuyez sur le bouton de téléchargement pour récupérer sa vidéo.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp, bottom = 16.dp),
        )
        if (hub.bookmarks.items.isNotEmpty()) {
            Text("Favoris", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            LazyColumn(Modifier.heightIn(max = 170.dp)) {
                items(hub.bookmarks.items.toList()) { b ->
                    Row(
                        Modifier.fillMaxWidth().clickable { hub.load(tab, b.url) }.padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            b.title, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.bodyMedium,
                        )
                        IconButton(onClick = { hub.bookmarks.remove(b) }) {
                            Icon(Icons.Filled.Close, contentDescription = "Retirer", modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            items(SITES) { site ->
                Column(
                    Modifier.clip(RoundedCornerShape(12.dp)).clickable {
                        if (site.url.isEmpty()) onOpenYoutube() else hub.load(tab, site.url)
                    }.padding(4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Box(
                        Modifier.size(54.dp).clip(CircleShape).background(site.color)
                            .border(1.dp, Color(0x33FFFFFF), CircleShape),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            site.name.take(1),
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 22.sp,
                        )
                    }
                    Text(
                        site.name,
                        style = MaterialTheme.typography.labelMedium,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(top = 6.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun TabSwitcher(hub: WebHub, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Onglets (${hub.tabs.size})") },
        text = {
            LazyColumn {
                itemsIndexed(hub.tabs.toList()) { index, t ->
                    Row(
                        Modifier.fillMaxWidth()
                            .clickable { hub.currentIndex = index; onDismiss() }
                            .background(
                                if (index == hub.currentIndex) MaterialTheme.colorScheme.primaryContainer
                                else Color.Transparent
                            )
                            .padding(horizontal = 8.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                t.title.ifBlank { if (isBlank(t.url)) "Nouvel onglet" else t.url },
                                maxLines = 1, overflow = TextOverflow.Ellipsis,
                                fontWeight = FontWeight.SemiBold,
                            )
                            if (!isBlank(t.url)) {
                                Text(
                                    t.url, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                        IconButton(onClick = { hub.closeTab(index) }) {
                            Icon(Icons.Filled.Close, contentDescription = "Fermer l'onglet")
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { hub.newBrowserTab(); onDismiss() }) { Text("Nouvel onglet") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Fermer") } },
    )
}

/** Appui long sur une image ou un lien. */
@Composable
fun HitDialog(app: App, hub: WebHub) {
    val context = LocalContext.current
    val hit = hub.hit.value ?: return
    val dismiss = { hub.hit.value = null }
    AlertDialog(
        onDismissRequest = { dismiss() },
        title = { Text(if (hit.isImage) "Image" else "Lien") },
        text = {
            Column {
                Text(hit.url, maxLines = 3, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(8.dp))
                if (hit.isImage) {
                    HitAction("Télécharger l'image") {
                        app.manager.enqueueFromBrowser(
                            hit.url, android.webkit.CookieManager.getInstance().getCookie(hit.url) ?: "",
                            hub.current?.url ?: "", null, null,
                        )
                        Toast.makeText(context, "Téléchargement ajouté", Toast.LENGTH_SHORT).show()
                        dismiss()
                    }
                    HitAction("Ouvrir l'image dans un nouvel onglet") { hub.newBrowserTab(hit.url); dismiss() }
                } else {
                    HitAction("Ouvrir dans un nouvel onglet") { hub.newBrowserTab(hit.url); dismiss() }
                    HitAction("Télécharger la vidéo / le fichier") {
                        if (Links.isVideoSite(hit.url)) hub.formatRequest.value = hit.url
                        else {
                            app.manager.enqueueFromBrowser(
                                hit.url, android.webkit.CookieManager.getInstance().getCookie(hit.url) ?: "",
                                hub.current?.url ?: "", null, null,
                            )
                            Toast.makeText(context, "Téléchargement ajouté", Toast.LENGTH_SHORT).show()
                        }
                        dismiss()
                    }
                }
                HitAction("Copier le lien") { copy(context, hit.url); dismiss() }
            }
        },
        confirmButton = { TextButton(onClick = { dismiss() }) { Text("Fermer") } },
    )
}

@Composable
private fun HitAction(label: String, onClick: () -> Unit) {
    Text(
        label,
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 12.dp),
        style = MaterialTheme.typography.bodyLarge,
    )
}

private fun copy(context: Context, text: String) {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("lien", text))
    Toast.makeText(context, "Lien copié", Toast.LENGTH_SHORT).show()
}

/** Enregistre la page (.mhtml) dans Téléchargements/DLTurbo/Pages pour la lire hors ligne. */
private fun savePage(context: Context, app: App, tab: WebTab) {
    val dir = File(app.manager.baseDir, "Pages")
    if (!dir.exists() && !dir.mkdirs() && !dir.exists()) {
        Toast.makeText(context, "Dossier inaccessible", Toast.LENGTH_SHORT).show()
        return
    }
    val name = Links.sanitize(tab.title.ifBlank { Links.hostOf(tab.url) }).take(80)
    val target = Links.uniqueFile(dir, "$name.mhtml")
    tab.webView.saveWebArchive(target.path, false) { saved ->
        Toast.makeText(
            context,
            if (saved != null) "Page enregistrée : Pages/${target.name}" else "Échec de l'enregistrement",
            Toast.LENGTH_LONG,
        ).show()
    }
}
