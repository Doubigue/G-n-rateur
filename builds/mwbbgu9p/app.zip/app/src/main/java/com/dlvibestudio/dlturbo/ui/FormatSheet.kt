@file:OptIn(ExperimentalMaterial3Api::class)

package com.dlvibestudio.dlturbo.ui

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PlaylistPlay
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.dlvibestudio.dlturbo.App
import com.dlvibestudio.dlturbo.engine.QualityOption
import com.dlvibestudio.dlturbo.engine.VideoDetails
import com.dlvibestudio.dlturbo.engine.VideoInfo
import com.dlvibestudio.dlturbo.util.Format
import kotlinx.coroutines.CancellationException

private data class AudioChoice(val key: String, val label: String, val detail: String, val size: Long)

private val PLAYLIST_VIDEO_CHOICES = listOf(
    QualityOption("best", "Meilleure qualité", "MP4", 0),
    QualityOption("1080", "1080p", "MP4", 0),
    QualityOption("720", "720p", "MP4", 0),
    QualityOption("480", "480p", "MP4", 0),
    QualityOption("360", "360p", "MP4", 0),
)

/**
 * Choix du format avant téléchargement, comme dans Vidmate : vidéo (MP4 en toutes qualités)
 * ou audio (MP3, M4A, WAV). Fonctionne pour YouTube, Instagram, Facebook, TikTok, Pinterest, X…
 */
@Composable
fun FormatSheet(app: App, url: String, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var details by remember(url) { mutableStateOf<VideoDetails?>(null) }
    var error by remember(url) { mutableStateOf<String?>(null) }
    var tab by remember(url) { mutableIntStateOf(0) }
    val pure = remember(url) { VideoInfo.isPurePlaylist(url) }
    var wholePlaylist by remember(url) { mutableStateOf(pure) }

    LaunchedEffect(url) {
        try {
            val json = if (pure) app.manager.videos.dumpJson(url, "--flat-playlist" to null)
            else app.manager.videos.dumpJson(url, "--no-playlist" to null)
            details = VideoInfo.details(url, json)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            error = e.message ?: "Impossible d'analyser ce lien"
        }
    }

    fun start(key: String) {
        val d = details
        app.manager.enqueueVideo(url, key, playlist = wholePlaylist || (d?.isPlaylist == true), title = d?.title ?: "")
        Toast.makeText(context, "Téléchargement ajouté", Toast.LENGTH_SHORT).show()
        onDismiss()
    }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(
            Modifier.fillMaxWidth().navigationBarsPadding().verticalScroll(rememberScrollState())
                .padding(bottom = 16.dp),
        ) {
            val d = details
            when {
                error != null -> {
                    Text(
                        error!!,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(20.dp),
                    )
                    Text(
                        "Si le site ne fonctionne plus : Paramètres → « Mettre à jour le moteur vidéo ».",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 20.dp),
                    )
                }

                d == null -> Box(Modifier.fillMaxWidth().height(160.dp), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator()
                        Spacer(Modifier.height(12.dp))
                        Text("Analyse du lien…", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                else -> {
                    // ----- En-tête : miniature, titre, auteur, durée
                    Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                        Box(Modifier.width(128.dp).height(72.dp).clip(RoundedCornerShape(8.dp))) {
                            RemoteImage(d.thumbnail, app.manager.http.client, Modifier.fillMaxWidth().height(72.dp))
                            if (d.isPlaylist) {
                                Icon(
                                    Icons.Filled.PlaylistPlay, null,
                                    tint = androidx.compose.ui.graphics.Color.White,
                                    modifier = Modifier.align(Alignment.BottomEnd).padding(4.dp).size(22.dp),
                                )
                            }
                        }
                        Column(Modifier.weight(1f).padding(start = 12.dp)) {
                            Text(
                                d.title,
                                maxLines = 3,
                                overflow = TextOverflow.Ellipsis,
                                fontWeight = FontWeight.SemiBold,
                                style = MaterialTheme.typography.bodyLarge,
                            )
                            val sub = buildList {
                                if (d.uploader.isNotBlank()) add(d.uploader)
                                if (d.isPlaylist) add("${d.entries.size} vidéos")
                                else if (d.durationSec > 0) add(Format.clock(d.durationSec))
                            }.joinToString(" · ")
                            if (sub.isNotBlank()) {
                                Text(
                                    sub,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }

                    // ----- Vidéo seule + paramètre de playlist
                    if (!d.isPlaylist && VideoInfo.hasPlaylistParam(url)) {
                        Row(
                            Modifier.fillMaxWidth().clickable { wholePlaylist = !wholePlaylist }
                                .padding(horizontal = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Checkbox(checked = wholePlaylist, onCheckedChange = { wholePlaylist = it })
                            Text("Télécharger toute la playlist de cette vidéo")
                        }
                    }

                    TabRow(selectedTabIndex = tab) {
                        Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Vidéo") })
                        Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Audio") })
                    }

                    if (tab == 0) {
                        val options = if (d.isPlaylist) PLAYLIST_VIDEO_CHOICES else d.videoOptions
                        options.forEach { o ->
                            OptionRow(
                                title = "${o.detail} · ${o.label}",
                                detail = if (o.sizeBytes > 0) "~" + Format.bytes(o.sizeBytes) else "",
                            ) { start(o.key) }
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                        }
                    } else {
                        val dur = d.durationSec
                        val choices = listOf(
                            AudioChoice("mp3", "MP3", "Meilleure qualité · compatible partout", d.audioSizeEstimate),
                            AudioChoice("m4a", "M4A", "AAC d'origine · sans perte supplémentaire", d.audioSizeEstimate),
                            AudioChoice("wav", "WAV", "Sans compression · très volumineux", if (dur > 0) dur * 176_400 else 0),
                        )
                        choices.forEach { c ->
                            OptionRow(
                                title = c.label,
                                detail = c.detail + if (!d.isPlaylist && c.size > 0) " · ~" + Format.bytes(c.size) else "",
                            ) { start(c.key) }
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun OptionRow(title: String, detail: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
            if (detail.isNotBlank()) {
                Text(
                    detail,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Icon(Icons.Filled.Download, contentDescription = "Télécharger", tint = MaterialTheme.colorScheme.primary)
    }
}
