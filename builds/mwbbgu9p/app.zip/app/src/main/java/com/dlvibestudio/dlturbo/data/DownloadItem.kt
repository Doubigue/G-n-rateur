package com.dlvibestudio.dlturbo.data

import org.json.JSONArray
import org.json.JSONObject

enum class DlType { HTTP, TORRENT, VIDEO }

enum class DlStatus {
    QUEUED, CONNECTING, RUNNING, PAUSED, WAITING_NETWORK, COMPLETED, ERROR;

    /** Le téléchargement occupe (ou attend) une place dans la file. */
    val isActive: Boolean
        get() = this == QUEUED || this == CONNECTING || this == RUNNING || this == WAITING_NETWORK
}

/** Portion d'un fichier téléchargée par une connexion. [end] = -1 quand la taille est inconnue. */
data class Segment(val start: Long, val end: Long, val done: Long)

data class DownloadItem(
    val id: String,
    val type: DlType,
    val url: String,
    val fileName: String,
    val dir: String,
    val totalBytes: Long = -1,
    val downloadedBytes: Long = 0,
    val speed: Long = 0,
    val status: DlStatus = DlStatus.QUEUED,
    val error: String? = null,
    val info: String = "",
    val resumable: Boolean = true,
    val segments: List<Segment> = emptyList(),
    val etag: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val finishedAt: Long = 0,
    val quality: String = "",
    val peers: Int = 0,
    /** Pourcentage fourni directement par le moteur (vidéo, torrent). -1 = calculé avec les octets. */
    val percent: Float = -1f,
    /** Nom de fichier choisi automatiquement : le moteur peut encore le corriger. */
    val autoName: Boolean = true,
    /** Lien direct inconnu : si c'est une page web, on bascule sur l'extracteur vidéo. */
    val videoFallback: Boolean = false,
    /** Cookies et page d'origine, transmis quand le lien vient du navigateur (liens protégés). */
    val cookie: String = "",
    val referer: String = "",
    /** Playlist entière (vidéos). */
    val playlist: Boolean = false,
    /** Nom de fichier imposé (sans extension) pour les flux détectés dans le navigateur. */
    val outName: String = "",
) {
    val progress: Float
        get() = when {
            status == DlStatus.COMPLETED -> 1f
            percent >= 0f -> (percent / 100f).coerceIn(0f, 1f)
            totalBytes > 0 -> (downloadedBytes.toFloat() / totalBytes).coerceIn(0f, 1f)
            else -> 0f
        }

    val percentInt: Int get() = (progress * 100).toInt()

    /** Secondes restantes, ou -1 si inconnu. */
    val etaSeconds: Long
        get() = if (speed > 0 && totalBytes > 0 && downloadedBytes in 0..totalBytes)
            (totalBytes - downloadedBytes) / speed else -1

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("type", type.name)
        put("url", url)
        put("fileName", fileName)
        put("dir", dir)
        put("totalBytes", totalBytes)
        put("downloadedBytes", downloadedBytes)
        put("status", status.name)
        put("error", error ?: JSONObject.NULL)
        put("resumable", resumable)
        put("etag", etag ?: JSONObject.NULL)
        put("createdAt", createdAt)
        put("finishedAt", finishedAt)
        put("quality", quality)
        put("percent", percent.toDouble())
        put("autoName", autoName)
        put("videoFallback", videoFallback)
        put("cookie", cookie)
        put("referer", referer)
        put("playlist", playlist)
        put("outName", outName)
        put("segments", JSONArray().apply {
            segments.forEach { s ->
                put(JSONArray().apply { put(s.start); put(s.end); put(s.done) })
            }
        })
    }

    companion object {
        fun fromJson(o: JSONObject): DownloadItem {
            val segs = ArrayList<Segment>()
            val arr = o.optJSONArray("segments")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val s = arr.getJSONArray(i)
                    segs.add(Segment(s.getLong(0), s.getLong(1), s.getLong(2)))
                }
            }
            return DownloadItem(
                id = o.getString("id"),
                type = runCatching { DlType.valueOf(o.getString("type")) }.getOrDefault(DlType.HTTP),
                url = o.getString("url"),
                fileName = o.optString("fileName", "fichier"),
                dir = o.getString("dir"),
                totalBytes = o.optLong("totalBytes", -1),
                downloadedBytes = o.optLong("downloadedBytes", 0),
                status = runCatching { DlStatus.valueOf(o.getString("status")) }
                    .getOrDefault(DlStatus.PAUSED),
                error = if (o.isNull("error")) null else o.optString("error"),
                resumable = o.optBoolean("resumable", true),
                segments = segs,
                etag = if (o.isNull("etag")) null else o.optString("etag"),
                createdAt = o.optLong("createdAt", System.currentTimeMillis()),
                finishedAt = o.optLong("finishedAt", 0),
                quality = o.optString("quality", ""),
                percent = o.optDouble("percent", -1.0).toFloat(),
                autoName = o.optBoolean("autoName", false),
                videoFallback = o.optBoolean("videoFallback", false),
                cookie = o.optString("cookie", ""),
                referer = o.optString("referer", ""),
                playlist = o.optBoolean("playlist", false),
                outName = o.optString("outName", ""),
            )
        }
    }
}
