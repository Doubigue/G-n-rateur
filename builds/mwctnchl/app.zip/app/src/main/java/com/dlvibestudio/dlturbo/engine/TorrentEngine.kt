package com.dlvibestudio.dlturbo.engine

import android.content.Context
import com.dlvibestudio.dlturbo.data.DlStatus
import com.dlvibestudio.dlturbo.data.DownloadRepository
import com.dlvibestudio.dlturbo.data.Settings
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runInterruptible
import org.libtorrent4j.Priority
import org.libtorrent4j.SessionManager
import org.libtorrent4j.TorrentFlags
import org.libtorrent4j.TorrentHandle
import org.libtorrent4j.TorrentInfo
import org.libtorrent4j.TorrentStatus
import java.io.File
import java.io.IOException

/**
 * Téléchargement BitTorrent (liens magnet et fichiers .torrent) avec libtorrent.
 * Le fichier .torrent de chaque élément est conservé dans le stockage privé de
 * l'application : après un redémarrage, libtorrent vérifie les données déjà
 * présentes sur le disque et ne télécharge que ce qui manque.
 */
class TorrentEngine(
    private val context: Context,
    private val repo: DownloadRepository,
    private val settings: Settings,
    private val http: HttpDownloader,
) {
    private var session: SessionManager? = null
    private val torrentsDir = File(context.filesDir, "torrents").apply { mkdirs() }

    fun torrentFile(id: String) = File(torrentsDir, "$id.torrent")

    @Synchronized
    private fun session(): SessionManager {
        session?.let { return it }
        val s = SessionManager()
        s.start()
        session = s
        applyLimits()
        return s
    }

    data class TorrentFile(val index: Int, val path: String, val size: Long)

    data class Live(
        val fileProgress: LongArray,
        val seeds: Int,
        val peers: Int,
        val uploadRate: Long,
        val uploaded: Long,
        val downloaded: Long,
        val trackers: Int,
        val state: String,
    )

    data class Details(
        val hash: String,
        val totalSize: Long,
        val pieces: Int,
        val pieceLength: Int,
        val comment: String,
        val creator: String,
        val createdAt: Long,
    )

    /** Fichiers contenus dans le torrent (lus dans le .torrent conservé). */
    fun files(id: String): List<TorrentFile> = runCatching {
        val fs = TorrentInfo(torrentFile(id)).files()
        (0 until fs.numFiles()).map { TorrentFile(it, fs.filePath(it), fs.fileSize(it)) }
    }.getOrDefault(emptyList())

    fun details(id: String): Details? = runCatching {
        val i = TorrentInfo(torrentFile(id))
        Details(
            i.infoHash().toHex(), i.totalSize(), i.numPieces(), i.pieceLength(),
            i.comment() ?: "", i.creator() ?: "", i.creationDate(),
        )
    }.getOrNull()

    private fun handleOf(id: String): TorrentHandle? {
        val s = session ?: return null
        val f = torrentFile(id)
        if (!f.exists()) return null
        return runCatching { s.find(TorrentInfo(f).infoHash())?.takeIf { it.isValid } }.getOrNull()
    }

    /** État en direct (pairs, sources, envoi, avancement de chaque fichier). Null si le torrent n'est pas en cours. */
    fun live(id: String): Live? {
        val h = handleOf(id) ?: return null
        return runCatching {
            val st = h.status()
            Live(
                runCatching { h.fileProgress() }.getOrDefault(LongArray(0)),
                st.numSeeds(), st.numPeers(), st.uploadRate().toLong(),
                st.allTimeUpload(), st.allTimeDownload(),
                runCatching { h.trackers().size }.getOrDefault(0),
                st.state().name,
            )
        }.getOrNull()
    }

    private fun ignoredSet(csv: String): Set<Int> =
        csv.split(',').mapNotNull { it.trim().toIntOrNull() }.toSet()

    /** Applique les fichiers cochés / décochés au torrent en cours : seuls les fichiers cochés sont téléchargés. */
    fun applyFiles(id: String) {
        val item = repo.get(id) ?: return
        val h = handleOf(id) ?: return
        runCatching {
            val n = TorrentInfo(torrentFile(id)).numFiles()
            val skip = ignoredSet(item.ignored)
            h.prioritizeFiles(Array(n) { if (it in skip) Priority.IGNORE else Priority.DEFAULT })
        }
    }

    /** Coche ou décoche un fichier du torrent (effet immédiat s'il est en cours). */
    fun setFileWanted(id: String, index: Int, wanted: Boolean) {
        repo.update(id) {
            val set = ignoredSet(it.ignored).toMutableSet()
            if (wanted) set.remove(index) else set.add(index)
            it.copy(ignored = set.sorted().joinToString(","))
        }
        applyFiles(id)
    }

    /** Téléchargement dans l'ordre : on peut lire la vidéo avant la fin. */
    fun setSequential(id: String, on: Boolean) {
        repo.update(id) { it.copy(sequential = on) }
        val h = handleOf(id) ?: return
        runCatching { if (on) h.setFlags(TorrentFlags.SEQUENTIAL_DOWNLOAD) else h.unsetFlags(TorrentFlags.SEQUENTIAL_DOWNLOAD) }
    }

    /** Démarre la session (et le réseau DHT) à l'avance, pour que les métadonnées arrivent plus vite. */
    fun warmUp() {
        Thread { runCatching { session() } }.start()
    }

    /** Ajoute au magnet des trackers publics rapides : les pairs sont trouvés en quelques secondes. */
    private fun withTrackers(magnet: String): String {
        val sb = StringBuilder(magnet)
        for (t in TRACKERS) {
            if (!magnet.contains(t.substringAfter("://").substringBefore('/'), ignoreCase = true)) {
                sb.append("&tr=").append(java.net.URLEncoder.encode(t, "UTF-8"))
            }
        }
        return sb.toString()
    }

    /** Applique les limites des paramètres à la session en cours. */
    fun applyLimits() {
        val s = session ?: return
        val cfg = settings.value
        runCatching {
            s.downloadRateLimit(cfg.speedLimit.coerceAtMost(Int.MAX_VALUE.toLong()).toInt())
            s.uploadRateLimit(cfg.torrentUploadLimit.coerceAtMost(Int.MAX_VALUE.toLong()).toInt())
            s.maxConnections(cfg.torrentMaxConnections)
        }
    }

    suspend fun run(id: String) {
        val item = repo.get(id) ?: throw FatalDownloadException("Téléchargement introuvable")
        val s = session()
        val file = torrentFile(id)

        if (!file.exists()) {
            if (Links.isMagnet(item.url)) {
                repo.update(id) {
                    it.copy(info = "Récupération des métadonnées…")
                }
                val tmp = File(context.cacheDir, "magnet").apply { mkdirs() }
                val uri = withTrackers(item.url)
                val started = System.currentTimeMillis()
                var data: ByteArray? = null
                coroutineScope {
                    // Compteur visible : on voit que ça avance, et chaque tentative relance la recherche de pairs.
                    val ticker = launch {
                        while (true) {
                            val sec = (System.currentTimeMillis() - started) / 1000
                            repo.update(id) { it.copy(info = "Métadonnées… ${sec} s (recherche de pairs)") }
                            delay(1000)
                        }
                    }
                    try {
                        var attempt = 0
                        while (data == null && attempt < 4) {
                            data = runInterruptible(Dispatchers.IO) { s.fetchMagnet(uri, 30, tmp) }
                            attempt++
                        }
                    } finally {
                        ticker.cancel()
                    }
                }
                file.writeBytes(
                    data ?: throw IOException("Métadonnées introuvables : aucun pair n'a répondu (torrent peu actif ?)")
                )
            } else {
                repo.update(id) {
                    it.copy(info = "Téléchargement du fichier .torrent…")
                }
                file.writeBytes(http.fetchBytes(item.url))
            }
        }

        val info = try {
            TorrentInfo(file)
        } catch (e: Throwable) {
            file.delete()
            throw FatalDownloadException("Fichier .torrent invalide")
        }
        val saveDir = File(item.dir)
        if (!saveDir.exists() && !saveDir.mkdirs() && !saveDir.exists()) {
            throw FatalDownloadException("Impossible de créer le dossier ${saveDir.path}")
        }
        val name = info.name()
        val size = info.totalSize()
        repo.update(id) {
            it.copy(fileName = name, totalBytes = size, autoName = false, error = null, info = "Connexion aux pairs…")
        }

        var handle: TorrentHandle? = s.find(info.infoHash())
        if (handle == null || !handle.isValid) {
            s.download(info, saveDir)
            var waited = 0
            while (waited < 100) {
                handle = s.find(info.infoHash())
                if (handle != null && handle.isValid) break
                delay(100)
                waited++
            }
        } else {
            handle.resume()
        }
        val h = handle?.takeIf { it.isValid }
            ?: throw IOException("Impossible de démarrer le torrent")
        applyFiles(id)
        if (repo.get(id)?.sequential == true) runCatching { h.setFlags(TorrentFlags.SEQUENTIAL_DOWNLOAD) }

        try {
            while (true) {
                val st = h.status()
                val state = st.state()
                val label = when (state) {
                    TorrentStatus.State.CHECKING_FILES,
                    TorrentStatus.State.CHECKING_RESUME_DATA -> "Vérification des données…"
                    TorrentStatus.State.DOWNLOADING_METADATA -> "Récupération des métadonnées…"
                    else -> "${st.numPeers()} pairs · ${st.numSeeds()} sources"
                }
                repo.update(id) {
                    it.copy(
                        status = if (it.status == DlStatus.CONNECTING || it.status == DlStatus.QUEUED)
                            DlStatus.RUNNING else it.status,
                        downloadedBytes = st.totalDone(),
                        totalBytes = if (st.totalWanted() > 0) st.totalWanted() else it.totalBytes,
                        speed = st.downloadRate().toLong(),
                        peers = st.numPeers(),
                        percent = st.progress() * 100f,
                        info = label,
                    )
                }
                val checking = state == TorrentStatus.State.CHECKING_FILES ||
                    state == TorrentStatus.State.CHECKING_RESUME_DATA
                if (!checking && (st.isFinished || st.isSeeding)) break
                delay(1000)
            }
        } catch (e: CancellationException) {
            // Pause : on fige le torrent sans le retirer, la reprise est alors immédiate.
            runCatching {
                h.unsetFlags(TorrentFlags.AUTO_MANAGED)
                h.pause()
            }
            repo.update(id) { it.copy(speed = 0, peers = 0) }
            throw e
        }

        repo.update(id) { it.copy(speed = 0, percent = 100f) }
        if (!settings.value.torrentSeed) {
            runCatching { s.remove(h) }
        }
    }

    /** Retire le torrent de la session (suppression d'un élément). */
    fun remove(id: String) {
        val s = session
        val file = torrentFile(id)
        if (s != null && file.exists()) {
            runCatching {
                val info = TorrentInfo(file)
                s.find(info.infoHash())?.let { s.remove(it) }
            }
        }
        file.delete()
    }

    companion object {
        private val TRACKERS = listOf(
            "udp://tracker.opentrackr.org:1337/announce",
            "udp://open.tracker.cl:1337/announce",
            "udp://tracker.torrent.eu.org:451/announce",
            "udp://open.stealth.si:80/announce",
            "udp://exodus.desync.com:6969/announce",
            "udp://explodie.org:6969/announce",
            "udp://tracker.tiny-vps.com:6969/announce",
            "udp://tracker.moeking.me:6969/announce",
            "udp://opentracker.i2p.rocks:6969/announce",
            "udp://tracker.dler.org:6969/announce",
            "udp://tracker.bittor.pw:1337/announce",
            "udp://tracker1.bt.moack.co.kr:80/announce",
        )
    }

    fun stop() {
        runCatching { session?.stop() }
        session = null
    }
}
