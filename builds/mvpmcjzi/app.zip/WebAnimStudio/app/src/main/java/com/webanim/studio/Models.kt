package com.webanim.studio

/** Bloc de voix off : [start,end] en secondes audio, mappé sur [animStart,animEnd] de l'animation. */
data class Segment(
    val start: Double, val end: Double, val text: String,
    val animStart: Double = start, val animEnd: Double = end
)

/** Time-mapping : temps audio -> temps animation, par interpolation linéaire dans chaque bloc. */
object TimeMap {
    fun anim(s: List<Segment>, t: Double): Double {
        val g = s.firstOrNull { t >= it.start && t < it.end } ?: return t
        val r = (t - g.start) / (g.end - g.start).coerceAtLeast(1e-6)
        return g.animStart + r * (g.animEnd - g.animStart)
    }
    fun subtitle(s: List<Segment>, t: Double): String =
        s.firstOrNull { t >= it.start && t < it.end }?.text ?: ""
}

enum class Res(val label: String, val shortSide: Int, val longSide: Int) {
    SD("480p", 480, 854), HD("720p", 720, 1280), FHD("1080p", 1080, 1920)
}

data class ExportConfig(val portrait: Boolean, val res: Res, val fps: Int = 30) {
    val width get() = if (portrait) res.shortSide else res.longSide
    val height get() = if (portrait) res.longSide else res.shortSide
    val bitrate get() = (width * height * fps * 0.07).toInt()
}
