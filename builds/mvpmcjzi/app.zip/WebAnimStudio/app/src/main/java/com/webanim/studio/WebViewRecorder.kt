package com.webanim.studio

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.PixelCopy
import android.view.WindowManager
import android.widget.FrameLayout
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import android.media.*
import android.net.Uri
import android.view.ViewGroup
import android.webkit.WebView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.android.awaitFrame
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer

/**
 * Rendu déterministe image par image : pour chaque frame on appelle window.seek(t) dans une WebView
 * affichée à l'écran, on la copie (PixelCopy, compatible WebGL) dans un Bitmap puis on l'envoie à un MediaCodec H.264 (Surface).
 * Les timestamps sont imposés (frame n -> n/fps) donc la vidéo est parfaitement calée sur la voix off.
 * La voix off (AAC/M4A/MP4) est recopiée sans ré-encodage dans le MP4 final.
 */
class WebViewRecorder(private val activity: Activity) {

    suspend fun record(
        html: String, segs: List<Segment>, audio: Uri?, cfg: ExportConfig,
        durationSec: Double, out: File, onProgress: (Float) -> Unit
    ) = withContext(Dispatchers.Main) {
        val w = cfg.width; val h = cfg.height; val fps = cfg.fps
        val root = activity.window.decorView as ViewGroup
        // Capture fiable (WebGL inclus) : la WebView est affichée à l'écran dans un calque noir et copiée avec PixelCopy.
        // Elle est dimensionnée au format de sortie, réduite si l'écran est plus petit (puis remise à l'échelle à l'encodage).
        val s = minOf(1f, root.width / w.toFloat(), root.height / h.toFloat())
        val cw = (w * s).toInt(); val ch = (h * s).toInt()
        val wv = WebView(activity).also { Bridge.configure(it) }
        val overlay = FrameLayout(activity).apply { setBackgroundColor(Color.BLACK); isClickable = true }
        overlay.addView(wv, FrameLayout.LayoutParams(cw, ch, Gravity.CENTER))
        root.addView(overlay, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        activity.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)
        val dst = Rect(0, 0, w, h)

        val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        enc.configure(MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, cfg.bitrate)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val surface = enc.createInputSurface(); enc.start()
        val muxer = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

        var audioEx: MediaExtractor? = null; var audioTrack = -1
        if (audio != null) {
            audioEx = MediaExtractor().apply { setDataSource(activity, audio, null) }
            val i = (0 until audioEx.trackCount).firstOrNull {
                audioEx.getTrackFormat(it).getString(MediaFormat.KEY_MIME) == MediaFormat.MIMETYPE_AUDIO_AAC
            } ?: throw IllegalArgumentException("Voix off : format AAC/M4A requis (convertissez-la d'abord).")
            audioEx.selectTrack(i); audioTrack = muxer.addTrack(audioEx.getTrackFormat(i))
        }

        var videoTrack = -1; var started = false; var outFrames = 0L
        val info = MediaCodec.BufferInfo()
        fun drain(eos: Boolean) {
            while (true) {
                val i = enc.dequeueOutputBuffer(info, if (eos) 10_000 else 0)
                if (i == MediaCodec.INFO_TRY_AGAIN_LATER) { if (!eos) return }
                else if (i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    videoTrack = muxer.addTrack(enc.outputFormat); muxer.start(); started = true
                } else if (i >= 0) {
                    val buf = enc.getOutputBuffer(i)!!
                    if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
                    if (info.size > 0 && started) {
                        info.presentationTimeUs = outFrames++ * 1_000_000L / fps   // timestamps imposés
                        buf.position(info.offset); buf.limit(info.offset + info.size)
                        muxer.writeSampleData(videoTrack, buf, info)
                    }
                    enc.releaseOutputBuffer(i, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
                }
            }
        }

        try {
            Bridge.loadHtml(wv, html)
            awaitFrame(); awaitFrame()
            val bmp = Bitmap.createBitmap(cw, ch, Bitmap.Config.ARGB_8888)
            val loc = IntArray(2)
            val total = (durationSec * fps).toInt().coerceAtLeast(1)
            for (f in 0 until total) {
                val t = f.toDouble() / fps
                Bridge.eval(wv, Bridge.frame(TimeMap.anim(segs, t), TimeMap.subtitle(segs, t)))
                awaitFrame(); awaitFrame()        // laisse Chromium appliquer et composer le rendu
                wv.getLocationInWindow(loc)
                val ok = suspendCancellableCoroutine<Boolean> { k ->
                    PixelCopy.request(activity.window, Rect(loc[0], loc[1], loc[0] + cw, loc[1] + ch), bmp,
                        { r -> if (k.isActive) k.resume(r == PixelCopy.SUCCESS) }, Handler(Looper.getMainLooper()))
                }
                if (!ok) throw IllegalStateException("Capture d'écran impossible (gardez l'application au premier plan).")
                val sc = surface.lockHardwareCanvas()
                sc.drawBitmap(bmp, null, dst, paint)
                surface.unlockCanvasAndPost(sc)
                drain(false)
                onProgress(f / total.toFloat())
            }
            enc.signalEndOfInputStream(); drain(true)

            audioEx?.let { ex ->
                val ab = ByteBuffer.allocate(1 shl 20); val bi = MediaCodec.BufferInfo()
                val endUs = (durationSec * 1e6).toLong()
                while (true) {
                    val n = ex.readSampleData(ab, 0)
                    if (n < 0 || ex.sampleTime > endUs) break
                    val key = if ((ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC) != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                    bi.set(0, n, ex.sampleTime, key)
                    muxer.writeSampleData(audioTrack, ab, bi); ex.advance()
                }
            }
            muxer.stop()
        } finally {
            runCatching { enc.stop() }; enc.release(); surface.release()
            runCatching { muxer.release() }; audioEx?.release()
            activity.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            root.removeView(overlay); wv.destroy()
        }
    }
}
