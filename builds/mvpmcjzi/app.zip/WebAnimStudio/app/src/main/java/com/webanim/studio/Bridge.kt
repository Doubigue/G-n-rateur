package com.webanim.studio

import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.suspendCancellableCoroutine
import org.json.JSONObject
import kotlin.coroutines.resume

/**
 * Pont JS commun à la prévisualisation et à l'export (garantit le même rendu).
 * - Les librairies embarquées (assets/lib : gsap, three, lame) sont servies sur https://appassets.local/lib/<fichier> (hors-ligne).
 * - Si la page ne définit pas window.seek(t), un adaptateur pilote automatiquement GSAP, CSS Keyframes/Transitions,
 *   Web Animations et SVG SMIL. Canvas 2D et Three.js doivent définir window.seek(t) (+ window.__duration).
 */
object Bridge {
    val INSTALL = """
(function(){
 if(window.__adapter)return;window.__adapter=1;
 var d=document.createElement('div');d.id='__sub';
 d.style.cssText='position:fixed;left:5%;right:5%;bottom:6%;text-align:center;color:#fff;font:600 4vmin sans-serif;text-shadow:0 0 6px #000,0 0 3px #000;z-index:2147483647;pointer-events:none';
 document.body.appendChild(d);window.__setSub=function(t){d.textContent=t};
 if(!window.seek){window.seek=function(t){
  try{if(window.gsap){gsap.globalTimeline.pause();gsap.globalTimeline.time(t,false);}}catch(e){}
  try{document.getAnimations().forEach(function(a){a.pause();a.currentTime=t*1000})}catch(e){}
  try{document.querySelectorAll('svg').forEach(function(s){s.pauseAnimations();s.setCurrentTime(t)})}catch(e){}
 };}
 if(!window.__duration){var m=0;
  try{if(window.gsap){var g=gsap.globalTimeline.duration();if(isFinite(g))m=Math.max(m,g)}}catch(e){}
  try{document.getAnimations().forEach(function(a){var e=a.effect&&a.effect.getComputedTiming();if(e&&isFinite(e.endTime))m=Math.max(m,e.endTime/1000)})}catch(e){}
  if(m>0)window.__duration=m;}
})();""".trimIndent()

    fun frame(animT: Double, sub: String) =
        "if(window.seek)window.seek($animT);if(window.__setSub)window.__setSub(${JSONObject.quote(sub)});window.__duration||0"

    suspend fun loadHtml(wv: WebView, html: String) = suspendCancellableCoroutine<Unit> { k ->
        wv.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                val p = r.url.path ?: return null
                if (r.url.host != "appassets.local" || !p.startsWith("/lib/")) return null
                return try { WebResourceResponse("application/javascript", "utf-8", v.context.assets.open(p.removePrefix("/"))) }
                catch (e: Exception) { null }
            }
            override fun onPageFinished(v: WebView, url: String) {
                v.evaluateJavascript(INSTALL) { if (k.isActive) k.resume(Unit) }
            }
        }
        wv.loadDataWithBaseURL("https://appassets.local/", html, "text/html", "utf-8", null)
    }

    suspend fun eval(wv: WebView, js: String): String = suspendCancellableCoroutine { k ->
        wv.evaluateJavascript(js) { if (k.isActive) k.resume(it ?: "") }
    }

    fun configure(wv: WebView) = wv.settings.run {
        javaScriptEnabled = true; domStorageEnabled = true
        mediaPlaybackRequiresUserGesture = false; allowFileAccess = false
    }
}
