package com.webanim.studio

import android.content.Context
import android.net.Uri
import android.util.Base64
import android.webkit.WebView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Encodage MP3 sans dépendance native : lamejs (LAME en JavaScript, embarqué dans assets/lib) tourne
 * dans une WebView cachée. Pipeline : média -> WAV (MediaCodec) -> blocs PCM -> lamejs -> .mp3
 */
object Mp3Encoder {
    private const val PAGE = """<html><body><script src="https://appassets.local/lib/lame.min.js"></script><script>
var E,C;
function init(sr,ch,k){C=ch;E=new lamejs.Mp3Encoder(ch,sr,k);return 'ok'}
function b64(a){a=new Uint8Array(a.buffer,a.byteOffset,a.length);var s='';for(var i=0;i<a.length;i+=8192)s+=String.fromCharCode.apply(null,a.subarray(i,i+8192));return btoa(s)}
function enc(x){var b=atob(x),u=new Uint8Array(b.length),i;for(i=0;i<b.length;i++)u[i]=b.charCodeAt(i);var p=new Int16Array(u.buffer),o;
if(C==2){var n=p.length>>1,l=new Int16Array(n),r=new Int16Array(n);for(i=0;i<n;i++){l[i]=p[2*i];r[i]=p[2*i+1]}o=E.encodeBuffer(l,r)}else o=E.encodeBuffer(p);return b64(o)}
function fin(){return b64(E.flush())}
</script></body></html>"""

    private fun InputStream.fill(buf: ByteArray): Int {
        var n = 0
        while (n < buf.size) { val r = read(buf, n, buf.size - n); if (r < 0) break; n += r }
        return n
    }
    private fun String.unq() = Base64.decode(trim('"'), Base64.DEFAULT)

    suspend fun encode(ctx: Context, input: Uri, out: File, kbps: Int = 128) {
        val wav = File(ctx.cacheDir, "mp3_tmp.wav")
        withContext(Dispatchers.IO) { AudioConverter.toWav(ctx, input, wav) }
        withContext(Dispatchers.Main) {
            val wv = WebView(ctx).also { Bridge.configure(it) }
            try {
                Bridge.loadHtml(wv, PAGE)
                val hdr = ByteArray(44)
                withContext(Dispatchers.IO) { wav.inputStream().use { it.read(hdr) } }
                val bb = ByteBuffer.wrap(hdr).order(ByteOrder.LITTLE_ENDIAN)
                val ch = bb.getShort(22).toInt(); val sr = bb.getInt(24)
                Bridge.eval(wv, "init($sr,$ch,$kbps)")
                out.outputStream().buffered().use { os ->
                    wav.inputStream().use { ins ->
                        ins.skip(44)
                        val buf = ByteArray(65536)
                        while (true) {
                            val n = withContext(Dispatchers.IO) { ins.fill(buf) }
                            val len = n - n % (2 * ch)
                            if (len <= 0) break
                            os.write(Bridge.eval(wv, "enc('${Base64.encodeToString(buf, 0, len, Base64.NO_WRAP)}')").unq())
                            if (n < buf.size) break
                        }
                    }
                    os.write(Bridge.eval(wv, "fin()").unq())
                }
            } finally { wv.destroy(); wav.delete() }
        }
    }
}
