package com.webanim.studio

import android.content.Context
import android.net.Uri
import androidx.media3.common.Effects
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.effect.Presentation
import androidx.media3.transformer.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Compression / amélioration MP4->MP4 (H.264) et extraction audio (M4A/AAC) via Media3 Transformer. */
object VideoCompressor {
    suspend fun videoToVideo(ctx: Context, input: Uri, out: File, targetHeight: Int, bitrate: Int) =
        run(ctx, out, audioOnly = false, bitrate = bitrate) {
            EditedMediaItem.Builder(MediaItem.fromUri(input))
                .setEffects(Effects(emptyList(), listOf(Presentation.createForHeight(targetHeight)))).build()
        }

    suspend fun extractAudioM4a(ctx: Context, input: Uri, out: File) =
        run(ctx, out, audioOnly = true, bitrate = null) {
            EditedMediaItem.Builder(MediaItem.fromUri(input)).setRemoveVideo(true).build()
        }

    private suspend fun run(ctx: Context, out: File, audioOnly: Boolean, bitrate: Int?, item: () -> EditedMediaItem) =
        withContext(Dispatchers.Main) {   // Transformer exige un thread avec Looper
            out.delete()
            suspendCancellableCoroutine<Unit> { k ->
                val b = Transformer.Builder(ctx)
                if (!audioOnly) {
                    b.setVideoMimeType(MimeTypes.VIDEO_H264).setAudioMimeType(MimeTypes.AUDIO_AAC)
                    bitrate?.let {
                        b.setEncoderFactory(DefaultEncoderFactory.Builder(ctx)
                            .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(it).build()).build())
                    }
                }
                val t = b.addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) { if (k.isActive) k.resume(Unit) }
                    override fun onError(composition: Composition, exportResult: ExportResult, e: ExportException) {
                        if (k.isActive) k.resumeWithException(e)
                    }
                }).build()
                t.start(item(), out.path)
                k.invokeOnCancellation { t.cancel() }
            }
        }
}
