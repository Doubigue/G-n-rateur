package com.webanim.studio

import android.content.Context
import android.net.Uri
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.pow
import kotlin.math.sqrt

/** Découpage intelligent : détecte les silences et produit des blocs horodatés (phrases). */
object AudioSplitter {
    fun split(
        ctx: Context, uri: Uri, thresholdDb: Double = -38.0,
        minSilenceSec: Double = 0.45, minSegmentSec: Double = 0.9
    ): List<Segment> {
        var sr = 44100; var ch = 2; var win = 882
        val thr = 10.0.pow(thresholdDb / 20.0) * 32768
        var acc = 0.0; var cnt = 0; var ci = 0; var frames = 0L
        var start = -1.0; var lastVoice = 0.0
        val spans = mutableListOf<Pair<Double, Double>>()
        AudioDecoder.decode(ctx, uri, { s, c -> sr = s; ch = c; win = s / 50 }) { pcm ->
            for (v in pcm) {
                acc += v.toDouble() * v
                if (++ci == ch) {
                    ci = 0; frames++; cnt++
                    if (cnt >= win) {
                        val rms = sqrt(acc / (cnt * ch)); acc = 0.0; cnt = 0
                        val t = frames.toDouble() / sr
                        if (rms > thr) { if (start < 0) start = (t - 0.02).coerceAtLeast(0.0); lastVoice = t }
                        else if (start >= 0 && t - lastVoice >= minSilenceSec) { spans += start to lastVoice; start = -1.0 }
                    }
                }
            }
        }
        if (start >= 0) spans += start to lastVoice
        // fusionne les blocs trop courts avec le suivant
        val merged = mutableListOf<Pair<Double, Double>>()
        var cur: Pair<Double, Double>? = null
        for (s in spans) {
            cur = if (cur == null) s else cur.first to s.second
            if (cur.second - cur.first >= minSegmentSec) { merged += cur; cur = null }
        }
        cur?.let { if (merged.isEmpty()) merged += it else merged[merged.lastIndex] = merged.last().first to it.second }
        return merged.mapIndexed { i, s -> Segment(s.first, s.second + 0.1, "Phrase ${i + 1}") }
    }
}

object AudioConverter {
    /** Tout audio/vidéo -> WAV PCM 16 bits. */
    fun toWav(ctx: Context, uri: Uri, out: File) {
        var sr = 44100; var ch = 2; var bytes = 0L
        RandomAccessFile(out, "rw").use { raf ->
            raf.setLength(0); raf.write(ByteArray(44))
            AudioDecoder.decode(ctx, uri, { s, c -> sr = s; ch = c }) { pcm ->
                val bb = ByteBuffer.allocate(pcm.size * 2).order(ByteOrder.LITTLE_ENDIAN)
                bb.asShortBuffer().put(pcm); raf.write(bb.array()); bytes += pcm.size * 2
            }
            val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            h.put("RIFF".toByteArray()).putInt((36 + bytes).toInt()).put("WAVEfmt ".toByteArray())
            h.putInt(16).putShort(1).putShort(ch.toShort()).putInt(sr).putInt(sr * ch * 2)
            h.putShort((ch * 2).toShort()).putShort(16).put("data".toByteArray()).putInt(bytes.toInt())
            raf.seek(0); raf.write(h.array())
        }
    }
}
