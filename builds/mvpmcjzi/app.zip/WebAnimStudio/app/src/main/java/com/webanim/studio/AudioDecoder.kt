package com.webanim.studio

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteOrder

/** Décode n'importe quel audio supporté par Android en PCM 16 bits, en flux (mémoire constante). */
object AudioDecoder {
    fun decode(ctx: Context, uri: Uri, onFormat: (sampleRate: Int, channels: Int) -> Unit, onPcm: (ShortArray) -> Unit) {
        val ex = MediaExtractor().apply { setDataSource(ctx, uri, null) }
        try {
            val idx = (0 until ex.trackCount).first { ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)!!.startsWith("audio/") }
            ex.selectTrack(idx)
            val fmt = ex.getTrackFormat(idx)
            onFormat(fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE), fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT))
            val codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
            codec.configure(fmt, null, null, 0); codec.start()
            val info = MediaCodec.BufferInfo()
            var inDone = false; var outDone = false
            while (!outDone) {
                if (!inDone) {
                    val i = codec.dequeueInputBuffer(10_000)
                    if (i >= 0) {
                        val n = ex.readSampleData(codec.getInputBuffer(i)!!, 0)
                        if (n < 0) { codec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true }
                        else { codec.queueInputBuffer(i, 0, n, ex.sampleTime, 0); ex.advance() }
                    }
                }
                val o = codec.dequeueOutputBuffer(info, 10_000)
                if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val f = codec.outputFormat
                    onFormat(f.getInteger(MediaFormat.KEY_SAMPLE_RATE), f.getInteger(MediaFormat.KEY_CHANNEL_COUNT))
                } else if (o >= 0) {
                    val b = codec.getOutputBuffer(o)!!
                    b.position(info.offset); b.limit(info.offset + info.size)
                    val sb = b.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                    val arr = ShortArray(sb.remaining()); sb.get(arr)
                    if (arr.isNotEmpty()) onPcm(arr)
                    codec.releaseOutputBuffer(o, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                }
            }
            codec.stop(); codec.release()
        } finally { ex.release() }
    }
}
