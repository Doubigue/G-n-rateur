package com.webanim.studio

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import java.io.File

object MediaStoreSaver {
    /** Scoped Storage : aucune permission requise (minSdk 29). */
    fun save(ctx: Context, file: File, mime: String, name: String): Uri {
        val audio = mime.startsWith("audio")
        val coll = if (audio) MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                   else MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val v = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, (if (audio) "Music" else "Movies") + "/WebAnimStudio")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = ctx.contentResolver.insert(coll, v)!!
        ctx.contentResolver.openOutputStream(uri)!!.use { o -> file.inputStream().use { it.copyTo(o) } }
        v.clear(); v.put(MediaStore.MediaColumns.IS_PENDING, 0)
        ctx.contentResolver.update(uri, v, null, null)
        return uri
    }
}
