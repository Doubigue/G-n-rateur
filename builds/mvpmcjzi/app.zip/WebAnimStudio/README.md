# WebAnim Studio (Android / Kotlin)
Ouvrir le dossier dans Android Studio (Koala+), laisser Gradle synchroniser, lancer sur un appareil API 29+.

Contrat des animations HTML : définir `window.__duration` (secondes) et `window.seek(t)` (rendu déterministe à t).
GSAP : `tl.pause(); window.seek = t => tl.time(t); window.__duration = tl.duration();`
Voix off : AAC/M4A/MP4. Sorties : Movies/WebAnimStudio et Music/WebAnimStudio (MediaStore, sans permission).
MP3 : non natif sur Android -> nécessite un fork communautaire de FFmpegKit ou LAME (non inclus).

## Types d'animation (exemples dans l'app : assets/samples)
| Type | Pilotage | Exemple |
|---|---|---|
| CSS Keyframes / transitions | automatique (Web Animations) | css.html |
| SVG SMIL | automatique (`setCurrentTime`), `__duration` à préciser | svg.html |
| GSAP | automatique (`globalTimeline`) | gsap.html |
| Canvas 2D | `window.seek(t)` + `__duration` | canvas.html |
| Three.js (WebGL) | `window.seek(t)` + `__duration`, `preserveDrawingBuffer:true` | three.html |

Librairies embarquées hors-ligne : `https://appassets.local/lib/{gsap,three,lame}.min.js` (GSAP 3.12.5, Three r128, lamejs 1.2.1).
MP3 : lamejs dans une WebView cachée (pas de binaire natif).

Export : la WebView est capturée avec PixelCopy (WebGL/Three.js inclus). Pendant le rendu, l'écran affiche l'animation : gardez l'application au premier plan.
