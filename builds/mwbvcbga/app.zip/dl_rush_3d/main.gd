extends Node3D
## DL RUSH 3D — runner urbain 3D, 100 % procédural (Godot 4.3+)
## Aucun asset externe : décor, personnage, trains, sons et UI sont générés par code.
## Contrôles : glisser ← → (voies), ↑ (sauter), ↓ (glisser) — ou flèches / WASD / Espace.

const LANE_W := 2.6
const CHUNK_LEN := 60.0
const VIEW_AHEAD := 230.0
const GRAVITY := -48.0
const JUMP_V := 16.0
const PLAYER_H := 1.8
const SLIDE_H := 0.8
const TRAIN_H := 3.4
const RAMP_LEN := 7.0
const START_SPEED := 15.0
const MAX_SPEED := 34.0
const SAVE_PATH := "user://best.save"

enum State { SPLASH, MENU, PLAY, OVER }

const JET_Y := 8.0
const JET_TIME := 7.0
const MAGNET_TIME := 10.0
const X2_TIME := 12.0
const MOVING_VZ := 11.0

const BUILDING_SHADER := """
shader_type spatial;
uniform vec3 base_color : source_color = vec3(0.5);
varying vec3 wpos;
varying vec3 wnrm;

float hash(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }

void vertex() {
	wpos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	wnrm = normalize((MODEL_MATRIX * vec4(NORMAL, 0.0)).xyz);
}

void fragment() {
	vec2 uv = abs(wnrm.x) > 0.5 ? wpos.zy : wpos.xy;
	vec2 cs = vec2(2.2, 2.8);
	vec2 cell = fract(uv / cs);
	vec2 id = floor(uv / cs);
	float win = step(0.22, cell.x) * step(cell.x, 0.78) * step(0.28, cell.y) * step(cell.y, 0.82);
	win *= step(abs(wnrm.y), 0.5);
	win *= step(1.8, wpos.y);
	float lit = step(0.55, hash(id + vec2(floor(wpos.x * 0.05), 0.0)));
	vec3 glass = vec3(0.10, 0.13, 0.19);
	float roof = step(0.5, wnrm.y);
	ALBEDO = mix(mix(base_color, glass, win), base_color * 0.6, roof);
	EMISSION = vec3(1.0, 0.78, 0.45) * win * lit * 1.8;
	ROUGHNESS = mix(0.9, 0.25, win);
}
"""

const BALLAST_SHADER := """
shader_type spatial;
varying vec3 wpos;

void vertex() {
	wpos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
}

void fragment() {
	float s = step(0.6, fract(wpos.z * 0.9));
	float n = fract(sin(dot(floor(wpos.xz * 8.0), vec2(12.9898, 78.233))) * 43758.5453);
	vec3 gravel = vec3(0.30, 0.27, 0.25) * (0.8 + 0.4 * n);
	vec3 wood = vec3(0.32, 0.20, 0.12);
	ALBEDO = mix(gravel, wood, s);
	ROUGHNESS = 0.95;
}
"""

var state: State = State.SPLASH
var rng := RandomNumberGenerator.new()

# Ressources partagées
var mats := {}
var meshes := {}
var unit_box: BoxMesh
var building_mats: Array = []
var ballast_mat: ShaderMaterial
var coin_mesh: CylinderMesh
var coin_mat: StandardMaterial3D
var ramp_mesh: PrismMesh
var train_colors := [
	Color(0.85, 0.85, 0.88), Color(0.20, 0.45, 0.85), Color(0.85, 0.25, 0.20),
	Color(0.25, 0.65, 0.40), Color(0.55, 0.30, 0.70),
]

# Joueur
var player: Node3D
var rig: Node3D
var leg_l: Node3D
var leg_r: Node3D
var arm_l: Node3D
var arm_r: Node3D
var cam: Camera3D

var lane := 1
var px := 0.0
var py := 0.0
var pz := 0.0
var vy := 0.0
var on_ground := true
var slide_t := 0.0
var speed := START_SPEED
var distance := 0.0
var coins := 0
var coin_points := 0
var jet_t := 0.0
var magnet_t := 0.0
var x2_t := 0.0
var invuln_t := 0.0
var run_phase := 0.0
var shake := 0.0
var dead_t := 0.0
var best := 0

# Monde
var chunks: Array = []
var obstacles: Array = []
var coin_list: Array = []
var powerups: Array = []
var next_chunk_z := 30.0
var next_row_z := -60.0
var lane_block := [1e9, 1e9, 1e9]

# Entrées
var touch_start := Vector2.ZERO
var swiped := false

# UI / son
var score_lbl: Label
var coin_lbl: Label
var title_lbl: Label
var center_lbl: Label
var dim: ColorRect
var power_lbl: Label
var splash: ColorRect
var splash_t := 0.0
var jet_vis: Node3D
var flame_l: MeshInstance3D
var flame_r: MeshInstance3D
var sfx_power: AudioStreamPlayer
var sfx_horn: AudioStreamPlayer
var sfx_coin: AudioStreamPlayer
var sfx_jump: AudioStreamPlayer
var sfx_crash: AudioStreamPlayer


func _ready() -> void:
	rng.randomize()
	load_best()
	setup_resources()
	setup_environment()
	build_player()
	build_camera()
	build_ui()
	build_audio()
	stream_world()
	show_splash()


# ───────────────────────────── Ressources ─────────────────────────────

func m(color: Color, emit := 0.0, metal := 0.0, rough := 0.7) -> StandardMaterial3D:
	var key := "%s_%s_%s_%s" % [color.to_html(), emit, metal, rough]
	if mats.has(key):
		return mats[key]
	var mt := StandardMaterial3D.new()
	mt.albedo_color = color
	mt.metallic = metal
	mt.roughness = rough
	if emit > 0.0:
		mt.emission_enabled = true
		mt.emission = color
		mt.emission_energy_multiplier = emit
	mats[key] = mt
	return mt


func box(parent: Node3D, size: Vector3, mat: Material, pos: Vector3) -> MeshInstance3D:
	var key := "b%s" % size
	var mesh: BoxMesh
	if meshes.has(key):
		mesh = meshes[key]
	else:
		mesh = BoxMesh.new()
		mesh.size = size
		meshes[key] = mesh
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.position = pos
	parent.add_child(mi)
	return mi


func setup_resources() -> void:
	unit_box = BoxMesh.new()
	unit_box.size = Vector3.ONE

	var bshader := Shader.new()
	bshader.code = BUILDING_SHADER
	var palette := [
		Color(0.42, 0.36, 0.40), Color(0.55, 0.45, 0.35), Color(0.30, 0.34, 0.42),
		Color(0.62, 0.58, 0.52), Color(0.48, 0.30, 0.28), Color(0.26, 0.40, 0.38),
	]
	for c in palette:
		var sm := ShaderMaterial.new()
		sm.shader = bshader
		sm.set_shader_parameter("base_color", c)
		building_mats.append(sm)

	var gshader := Shader.new()
	gshader.code = BALLAST_SHADER
	ballast_mat = ShaderMaterial.new()
	ballast_mat.shader = gshader

	coin_mesh = CylinderMesh.new()
	coin_mesh.top_radius = 0.38
	coin_mesh.bottom_radius = 0.38
	coin_mesh.height = 0.1
	coin_mesh.radial_segments = 20
	coin_mesh.rings = 1
	coin_mat = m(Color(1.0, 0.78, 0.15), 1.2, 0.9, 0.25)

	ramp_mesh = PrismMesh.new()
	ramp_mesh.size = Vector3(RAMP_LEN, TRAIN_H, 2.2)
	ramp_mesh.left_to_right = 1.0


func setup_environment() -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sm := ProceduralSkyMaterial.new()
	sm.sky_top_color = Color(0.22, 0.32, 0.62)
	sm.sky_horizon_color = Color(0.98, 0.62, 0.42)
	sm.ground_horizon_color = Color(0.98, 0.62, 0.42)
	sm.ground_bottom_color = Color(0.20, 0.15, 0.20)
	sky.sky_material = sm
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.7
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = true
	env.fog_light_color = Color(0.95, 0.62, 0.48)
	env.fog_density = 0.011
	env.glow_enabled = true
	env.glow_intensity = 0.7
	env.glow_bloom = 0.05
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-38.0, 35.0, 0.0)
	sun.light_color = Color(1.0, 0.86, 0.7)
	sun.light_energy = 1.2
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 70.0
	add_child(sun)


# ───────────────────────────── Joueur & caméra ─────────────────────────────

func limb(parent: Node3D, pivot: Vector3, size: Vector3, mat: Material, end_mat: Material) -> Node3D:
	var p := Node3D.new()
	p.position = pivot
	parent.add_child(p)
	box(p, size, mat, Vector3(0.0, -size.y * 0.5, 0.0))
	box(p, Vector3(size.x + 0.04, 0.12, size.z + 0.12), end_mat, Vector3(0.0, -size.y, -0.05))
	return p


func build_player() -> void:
	player = Node3D.new()
	add_child(player)
	rig = Node3D.new()
	player.add_child(rig)

	var hoodie := m(Color(0.95, 0.42, 0.12))
	var pants := m(Color(0.12, 0.16, 0.30))
	var skin := m(Color(0.45, 0.28, 0.18))
	var shoe := m(Color(0.95, 0.95, 0.95))
	var gold := m(Color(0.95, 0.75, 0.2), 0.3, 0.8, 0.3)
	var cap := m(Color(0.1, 0.1, 0.12))

	leg_l = limb(rig, Vector3(-0.15, 0.85, 0.0), Vector3(0.2, 0.8, 0.22), pants, shoe)
	leg_r = limb(rig, Vector3(0.15, 0.85, 0.0), Vector3(0.2, 0.8, 0.22), pants, shoe)
	box(rig, Vector3(0.56, 0.68, 0.34), hoodie, Vector3(0.0, 1.2, 0.0))
	arm_l = limb(rig, Vector3(-0.37, 1.48, 0.0), Vector3(0.15, 0.62, 0.16), hoodie, skin)
	arm_r = limb(rig, Vector3(0.37, 1.48, 0.0), Vector3(0.15, 0.62, 0.16), hoodie, skin)

	var hm := SphereMesh.new()
	hm.radius = 0.22
	hm.height = 0.44
	var head := MeshInstance3D.new()
	head.mesh = hm
	head.material_override = skin
	head.position = Vector3(0.0, 1.72, 0.0)
	rig.add_child(head)
	box(rig, Vector3(0.46, 0.14, 0.46), cap, Vector3(0.0, 1.88, 0.0))
	box(rig, Vector3(0.40, 0.05, 0.25), cap, Vector3(0.0, 1.83, -0.30))
	box(rig, Vector3(0.42, 0.48, 0.20), gold, Vector3(0.0, 1.22, 0.26))  # sac à dos doré

	# Jetpack (visible seulement pendant le bonus)
	jet_vis = Node3D.new()
	jet_vis.position = Vector3(0.0, 1.2, 0.42)
	rig.add_child(jet_vis)
	var tank := CylinderMesh.new()
	tank.top_radius = 0.12
	tank.bottom_radius = 0.12
	tank.height = 0.6
	for sx in [-0.16, 0.16]:
		var tk := MeshInstance3D.new()
		tk.mesh = tank
		tk.material_override = m(Color(0.75, 0.75, 0.8), 0.0, 0.9, 0.25)
		tk.position = Vector3(sx, 0.0, 0.0)
		jet_vis.add_child(tk)
	var fm := CylinderMesh.new()
	fm.top_radius = 0.1
	fm.bottom_radius = 0.02
	fm.height = 0.6
	var fmat := m(Color(1.0, 0.55, 0.1), 5.0)
	flame_l = MeshInstance3D.new()
	flame_l.mesh = fm
	flame_l.material_override = fmat
	flame_l.position = Vector3(-0.16, -0.6, 0.0)
	jet_vis.add_child(flame_l)
	flame_r = MeshInstance3D.new()
	flame_r.mesh = fm
	flame_r.material_override = fmat
	flame_r.position = Vector3(0.16, -0.6, 0.0)
	jet_vis.add_child(flame_r)
	jet_vis.visible = false


func build_camera() -> void:
	cam = Camera3D.new()
	cam.keep_aspect = Camera3D.KEEP_WIDTH
	cam.fov = 68.0
	cam.far = 320.0
	cam.position = Vector3(0.0, 5.2, 7.5)
	cam.rotation_degrees.x = -20.0
	add_child(cam)
	cam.current = true


# ───────────────────────────── Génération du monde ─────────────────────────────

func lane_x(l: int) -> float:
	return (l - 1) * LANE_W


func spawn_chunk(z0: float) -> void:
	var c := Node3D.new()
	add_child(c)
	var z_end := z0 - CHUNK_LEN
	var zc := z0 - CHUNK_LEN * 0.5

	box(c, Vector3(70.0, 0.2, CHUNK_LEN), m(Color(0.18, 0.18, 0.2), 0.0, 0.0, 0.95), Vector3(0.0, -0.1, zc))
	var rail := m(Color(0.75, 0.75, 0.8), 0.0, 0.9, 0.3)
	for l in 3:
		var x := lane_x(l)
		box(c, Vector3(2.2, 0.1, CHUNK_LEN), ballast_mat, Vector3(x, 0.0, zc))
		box(c, Vector3(0.1, 0.12, CHUNK_LEN), rail, Vector3(x - 0.72, 0.11, zc))
		box(c, Vector3(0.1, 0.12, CHUNK_LEN), rail, Vector3(x + 0.72, 0.11, zc))

	var metal := m(Color(0.2, 0.2, 0.22), 0.0, 0.6, 0.4)
	var bulb := m(Color(1.0, 0.85, 0.55), 4.0)
	for side in [-1.0, 1.0]:
		# Trottoir
		box(c, Vector3(2.0, 0.4, CHUNK_LEN), m(Color(0.45, 0.45, 0.48)), Vector3(side * (LANE_W * 1.5 + 2.2), 0.2, zc))
		# Lampadaires
		var lz := z0 - 10.0
		while lz > z_end:
			var lx: float = side * (LANE_W * 1.5 + 2.0)
			box(c, Vector3(0.15, 5.0, 0.15), metal, Vector3(lx, 2.5, lz))
			box(c, Vector3(1.0, 0.12, 0.15), metal, Vector3(lx - side * 0.45, 5.0, lz))
			box(c, Vector3(0.4, 0.1, 0.25), bulb, Vector3(lx - side * 0.85, 4.92, lz))
			lz -= 20.0
		# Immeubles
		var bz := z0
		while bz > z_end:
			var w := minf(rng.randf_range(7.0, 13.0), bz - z_end)
			if w < 3.0:
				break
			var h := rng.randf_range(10.0, 38.0)
			var d := rng.randf_range(8.0, 14.0)
			var b := MeshInstance3D.new()
			b.mesh = unit_box
			b.material_override = building_mats[rng.randi() % building_mats.size()]
			b.scale = Vector3(d, h, w)
			b.position = Vector3(side * (LANE_W * 1.5 + 5.5 + d * 0.5), h * 0.5, bz - w * 0.5)
			c.add_child(b)
			if rng.randf() < 0.35:  # château d'eau / clim sur le toit
				box(c, Vector3(2.0, 1.6, 2.0), metal, Vector3(b.position.x, h + 0.8, bz - w * 0.5))
			bz -= w + rng.randf_range(0.5, 2.5)
	chunks.append({"node": c, "z_end": z_end})


func gen_row(z: float) -> void:
	var diff := clampf(-z / 3000.0, 0.0, 1.0)
	var trains := 0
	for l in 3:
		if z > lane_block[l]:
			trains += 1
	var order := [0, 1, 2]
	order.shuffle()
	for l in order:
		if z > lane_block[l]:
			continue  # voie occupée par un train
		var r := rng.randf()
		var t := "empty"
		if r < 0.30:
			t = "coins"
		elif r < 0.47:
			t = "barrier"
		elif r < 0.62:
			t = "overhead"
		elif r < 0.80 + 0.12 * diff:
			t = "train"
		if t == "train":
			if trains >= 2:
				t = "barrier"  # toujours au moins une voie praticable
			else:
				trains += 1
		place(t, l, z)


func place(t: String, l: int, z: float) -> void:
	var x := lane_x(l)
	match t:
		"coins":
			if rng.randf() < 0.07 and -z > 150.0:
				var kinds := ["magnet", "jetpack", "x2"]
				add_powerup(kinds[rng.randi() % kinds.size()], Vector3(x, 1.2, z))
			else:
				for i in 5:
					add_coin(Vector3(x, 0.9, z + 4.0 - i * 2.0))
		"barrier":
			make_barrier(x, z)
			if rng.randf() < 0.5:
				for i in 5:
					add_coin(Vector3(x, 0.9 + 1.8 * sin(PI * i / 4.0), z + 4.0 - i * 2.0))
		"overhead":
			make_overhead(x, z)
		"train":
			var lens := [12.0, 18.0, 24.0]
			var L: float = lens[rng.randi() % lens.size()]
			var diff := clampf(-z / 3000.0, 0.0, 1.0)
			var moving := -z > 400.0 and rng.randf() < 0.15 + 0.25 * diff and clear_for_moving(x, z)
			make_train(x, z, L, moving)
			lane_block[l] = z - L - 8.0
			if moving:
				return
			if rng.randf() < 0.45:
				make_ramp(x, z)
				var cz := z - 1.5
				while cz > z - L + 1.0:
					add_coin(Vector3(x, TRAIN_H + 0.9, cz))
					cz -= 2.0


# Un train en mouvement remonte la voie : on la vide devant lui (sauf s'il y a déjà un train).
func clear_for_moving(x: float, z: float) -> bool:
	var reach := z + 34.0
	var other_lanes := {}
	for o in obstacles:
		if o["type"] != "train" and o["type"] != "ramp":
			continue
		var ox: float = o["x"]
		var zf: float = o["zf"]
		var zn: float = o["zn"]
		if absf(ox - x) < 0.1:
			if zf < reach:
				return false
		elif zf < reach and zn > z - 2.0:
			other_lanes[int(round(ox))] = true
	if other_lanes.size() >= 2:
		return false  # il doit toujours rester une voie libre
	var keep := []
	for o in obstacles:
		var ox: float = o["x"]
		var zn: float = o["zn"]
		var zf: float = o["zf"]
		if absf(ox - x) < 0.1 and zf < reach and zn > z:
			o["node"].queue_free()
		else:
			keep.append(o)
	obstacles = keep
	var keep_c := []
	for c in coin_list:
		var cp: Vector3 = c.position
		if absf(cp.x - x) < 0.1 and cp.z < reach and cp.z > z:
			c.queue_free()
		else:
			keep_c.append(c)
	coin_list = keep_c
	var keep_p := []
	for pu in powerups:
		var pn: Node3D = pu["node"]
		if absf(pn.position.x - x) < 0.1 and pn.position.z < reach and pn.position.z > z:
			pn.queue_free()
		else:
			keep_p.append(pu)
	powerups = keep_p
	return true


func add_powerup(kind: String, pos: Vector3) -> void:
	var n := Node3D.new()
	n.position = pos
	add_child(n)
	var col := Color(0.9, 0.2, 0.2)
	if kind == "jetpack":
		col = Color(1.0, 0.6, 0.1)
	elif kind == "x2":
		col = Color(0.2, 0.9, 0.4)
	var halo := SphereMesh.new()
	halo.radius = 0.6
	halo.height = 1.2
	var hm := StandardMaterial3D.new()
	hm.albedo_color = Color(col.r, col.g, col.b, 0.25)
	hm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	hm.emission_enabled = true
	hm.emission = col
	hm.emission_energy_multiplier = 1.5
	var hmi := MeshInstance3D.new()
	hmi.mesh = halo
	hmi.material_override = hm
	hmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	n.add_child(hmi)
	var core := m(col, 2.0, 0.5, 0.3)
	match kind:
		"magnet":  # aimant en U
			box(n, Vector3(0.14, 0.5, 0.14), core, Vector3(-0.2, 0.05, 0.0))
			box(n, Vector3(0.14, 0.5, 0.14), core, Vector3(0.2, 0.05, 0.0))
			box(n, Vector3(0.54, 0.14, 0.14), core, Vector3(0.0, -0.2, 0.0))
			box(n, Vector3(0.15, 0.12, 0.15), m(Color(0.9, 0.9, 0.95), 1.0), Vector3(-0.2, 0.34, 0.0))
			box(n, Vector3(0.15, 0.12, 0.15), m(Color(0.9, 0.9, 0.95), 1.0), Vector3(0.2, 0.34, 0.0))
		"jetpack":
			box(n, Vector3(0.18, 0.55, 0.18), core, Vector3(-0.14, 0.0, 0.0))
			box(n, Vector3(0.18, 0.55, 0.18), core, Vector3(0.14, 0.0, 0.0))
			box(n, Vector3(0.45, 0.12, 0.12), m(Color(0.3, 0.3, 0.35)), Vector3(0.0, 0.15, 0.0))
		_:  # x2
			box(n, Vector3(0.12, 0.5, 0.12), core, Vector3(-0.18, 0.0, 0.0))
			box(n, Vector3(0.12, 0.5, 0.12), core, Vector3(0.18, 0.0, 0.0))
			box(n, Vector3(0.48, 0.12, 0.12), core, Vector3(0.0, 0.0, 0.0))
	powerups.append({"kind": kind, "node": n})


func add_coin(pos: Vector3) -> void:
	var n := Node3D.new()
	n.position = pos
	add_child(n)
	var mi := MeshInstance3D.new()
	mi.mesh = coin_mesh
	mi.material_override = coin_mat
	mi.rotation_degrees.x = 90.0
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	n.add_child(mi)
	coin_list.append(n)


func make_barrier(x: float, z: float) -> void:
	var n := Node3D.new()
	n.position = Vector3(x, 0.0, z)
	add_child(n)
	var grey := m(Color(0.35, 0.35, 0.38), 0.0, 0.5, 0.5)
	box(n, Vector3(0.12, 1.0, 0.12), grey, Vector3(-0.9, 0.5, 0.0))
	box(n, Vector3(0.12, 1.0, 0.12), grey, Vector3(0.9, 0.5, 0.0))
	box(n, Vector3(2.2, 0.35, 0.25), m(Color(0.9, 0.15, 0.1)), Vector3(0.0, 0.82, 0.0))
	box(n, Vector3(2.22, 0.12, 0.27), m(Color(0.95, 0.95, 0.95)), Vector3(0.0, 0.82, 0.0))
	box(n, Vector3(2.2, 0.2, 0.2), m(Color(0.9, 0.15, 0.1)), Vector3(0.0, 0.35, 0.0))
	obstacles.append({"type": "barrier", "x": x, "zn": z + 0.25, "zf": z - 0.25,
		"y0": 0.0, "y1": 1.0, "top": 1.0, "node": n})


func make_overhead(x: float, z: float) -> void:
	var n := Node3D.new()
	n.position = Vector3(x, 0.0, z)
	add_child(n)
	var yellow := m(Color(1.0, 0.75, 0.1))
	var dark := m(Color(0.1, 0.1, 0.12))
	box(n, Vector3(0.18, 2.7, 0.18), dark, Vector3(-1.15, 1.35, 0.0))
	box(n, Vector3(0.18, 2.7, 0.18), dark, Vector3(1.15, 1.35, 0.0))
	box(n, Vector3(2.4, 1.3, 0.2), yellow, Vector3(0.0, 1.95, 0.0))
	box(n, Vector3(2.42, 0.18, 0.22), dark, Vector3(0.0, 1.75, 0.0))
	box(n, Vector3(2.42, 0.18, 0.22), dark, Vector3(0.0, 2.25, 0.0))
	box(n, Vector3(0.22, 0.22, 0.05), m(Color(1.0, 0.1, 0.05), 4.0), Vector3(-0.8, 2.45, 0.12))
	box(n, Vector3(0.22, 0.22, 0.05), m(Color(1.0, 0.1, 0.05), 4.0), Vector3(0.8, 2.45, 0.12))
	obstacles.append({"type": "overhead", "x": x, "zn": z + 0.2, "zf": z - 0.2,
		"y0": 1.25, "y1": 2.6, "top": 2.6, "node": n})


func make_train(x: float, z: float, L: float, moving := false) -> void:
	var n := Node3D.new()
	n.position = Vector3(x, 0.0, z - L * 0.5)
	add_child(n)
	var col: Color = train_colors[rng.randi() % train_colors.size()]
	var glass := m(Color(0.6, 0.85, 1.0), 0.6, 0.2, 0.2)
	var dark := m(Color(0.12, 0.12, 0.14))
	box(n, Vector3(2.0, 0.4, L - 0.6), dark, Vector3(0.0, 0.2, 0.0))
	box(n, Vector3(2.3, 3.0, L), m(col, 0.0, 0.3, 0.5), Vector3(0.0, 1.9, 0.0))
	box(n, Vector3(2.34, 0.8, L - 1.5), glass, Vector3(0.0, 2.5, 0.0))
	box(n, Vector3(2.34, 0.25, L), m(Color(1.0, 0.8, 0.2)), Vector3(0.0, 1.4, 0.0))
	box(n, Vector3(2.0, 0.1, L - 0.4), m(Color(0.5, 0.5, 0.55), 0.0, 0.6, 0.4), Vector3(0.0, 3.42, 0.0))
	box(n, Vector3(1.6, 0.8, 0.05), glass, Vector3(0.0, 2.6, L * 0.5 + 0.01))
	var head_light := m(Color(1.0, 1.0, 0.8), 5.0)
	box(n, Vector3(0.3, 0.2, 0.05), head_light, Vector3(-0.7, 1.0, L * 0.5 + 0.02))
	box(n, Vector3(0.3, 0.2, 0.05), head_light, Vector3(0.7, 1.0, L * 0.5 + 0.02))
	if moving:  # phares rouges clignotants + gyrophare sur le toit
		var warn := m(Color(1.0, 0.15, 0.1), 6.0)
		box(n, Vector3(0.5, 0.25, 0.3), warn, Vector3(0.0, 3.6, L * 0.5 - 0.6))
		box(n, Vector3(0.3, 0.2, 0.05), warn, Vector3(-0.7, 3.0, L * 0.5 + 0.02))
		box(n, Vector3(0.3, 0.2, 0.05), warn, Vector3(0.7, 3.0, L * 0.5 + 0.02))
	obstacles.append({"type": "train", "x": x, "zn": z, "zf": z - L,
		"y0": 0.0, "y1": TRAIN_H, "top": TRAIN_H, "node": n,
		"vz": MOVING_VZ if moving else 0.0, "active": false})


func make_ramp(x: float, z: float) -> void:
	var mi := MeshInstance3D.new()
	mi.mesh = ramp_mesh
	mi.material_override = m(Color(0.95, 0.7, 0.15), 0.0, 0.4, 0.5)
	mi.rotation_degrees.y = 90.0  # partie haute côté train (vers -Z)
	mi.position = Vector3(x, TRAIN_H * 0.5, z + RAMP_LEN * 0.5)
	add_child(mi)
	obstacles.append({"type": "ramp", "x": x, "zn": z + RAMP_LEN, "zf": z,
		"y0": 0.0, "y1": 0.0, "top": TRAIN_H, "node": mi})


func stream_world() -> void:
	while next_chunk_z > pz - VIEW_AHEAD:
		spawn_chunk(next_chunk_z)
		next_chunk_z -= CHUNK_LEN
	while next_row_z > pz - VIEW_AHEAD + 30.0:
		gen_row(next_row_z)
		var diff := clampf(-next_row_z / 3000.0, 0.0, 1.0)
		next_row_z -= lerpf(17.0, 10.5, diff)

	var keep := []
	for o in obstacles:
		var zf: float = o["zf"]
		if zf > pz + 12.0:
			o["node"].queue_free()
		else:
			keep.append(o)
	obstacles = keep

	var keep_c := []
	for c in chunks:
		var ze: float = c["z_end"]
		if ze > pz + 15.0:
			c["node"].queue_free()
		else:
			keep_c.append(c)
	chunks = keep_c


# ───────────────────────────── Physique & collisions ─────────────────────────────

func ground_height(x: float, z: float, y: float) -> float:
	var g := 0.0
	for o in obstacles:
		var t: String = o["type"]
		if t != "train" and t != "ramp":
			continue
		var ox: float = o["x"]
		if absf(x - ox) > 1.0:
			continue
		var zn: float = o["zn"]
		var zf: float = o["zf"]
		if z > zn + 0.4 or z < zf - 0.4:
			continue
		var top: float = o["top"]
		if t == "train":
			if y >= top - 0.6:
				g = maxf(g, top)
		else:
			var k := clampf((zn - z) / (zn - zf), 0.0, 1.0)
			var h := k * top
			if y >= h - 0.9:
				g = maxf(g, h)
	return g


func check_collisions() -> bool:
	if invuln_t > 0.0:
		return false
	var ph := SLIDE_H if slide_t > 0.0 else PLAYER_H
	for o in obstacles:
		var t: String = o["type"]
		if t == "ramp":
			continue
		var ox: float = o["x"]
		if absf(px - ox) > 1.45:
			continue
		var zn: float = o["zn"]
		var zf: float = o["zf"]
		if pz - 0.3 > zn or pz + 0.3 < zf:
			continue
		var y0: float = o["y0"]
		var y1: float = o["y1"]
		var tol := 0.5 if t == "train" else 0.05
		if py + ph <= y0 or py >= y1 - tol:
			continue
		crash()
		return true
	return false


func move_trains(dt: float) -> void:
	for o in obstacles:
		if o["type"] != "train":
			continue
		var vz: float = o.get("vz", 0.0)
		if vz <= 0.0:
			continue
		var zn: float = o["zn"]
		if not o["active"]:
			if zn > pz - 75.0:
				o["active"] = true
				sfx_horn.play()
			else:
				continue
		o["zn"] = zn + vz * dt
		o["zf"] = float(o["zf"]) + vz * dt
		var nd: Node3D = o["node"]
		nd.position.z += vz * dt


func physics_step(dt: float) -> bool:
	pz -= speed * dt
	distance += speed * dt
	px = lerpf(px, lane_x(lane), 1.0 - exp(-14.0 * dt))
	move_trains(dt)
	if jet_t > 0.0:
		py = lerpf(py, JET_Y, 1.0 - exp(-3.0 * dt))
		vy = 0.0
		on_ground = false
		return false
	vy += GRAVITY * dt
	py += vy * dt
	var g := ground_height(px, pz, py)
	if py <= g:
		py = g
		vy = 0.0
		on_ground = true
	else:
		on_ground = false
	return check_collisions()


func collect_coins() -> void:
	var keep := []
	var pp := Vector3(px, py + 0.9, pz)
	for c in coin_list:
		var cp: Vector3 = c.position
		if magnet_t > 0.0 and cp.distance_to(pp) < 9.0:
			cp = cp.move_toward(pp, 30.0 * get_process_delta_time())
			c.position = cp
		if cp.distance_to(pp) < 1.15:
			coins += 1
			coin_points += 20 if x2_t > 0.0 else 10
			sfx_coin.play()
			c.queue_free()
		elif cp.z > pz + 6.0:
			c.queue_free()
		else:
			keep.append(c)
	coin_list = keep

	var keep_p := []
	for pu in powerups:
		var pn: Node3D = pu["node"]
		if pn.position.distance_to(pp) < 1.4:
			activate_power(pu["kind"])
			pn.queue_free()
		elif pn.position.z > pz + 6.0:
			pn.queue_free()
		else:
			keep_p.append(pu)
	powerups = keep_p


func activate_power(kind: String) -> void:
	sfx_power.play()
	match kind:
		"magnet":
			magnet_t = MAGNET_TIME
		"x2":
			x2_t = X2_TIME
		"jetpack":
			jet_t = JET_TIME
			slide_t = 0.0
			jet_vis.visible = true
			# Traînée de pièces dans le ciel
			var l := lane
			var cz := pz - 20.0
			var end_z := pz - speed * JET_TIME
			while cz > end_z:
				if rng.randf() < 0.12:
					l = clampi(l + (1 if rng.randf() < 0.5 else -1), 0, 2)
				add_coin(Vector3(lane_x(l), JET_Y + 0.9, cz))
				cz -= 2.5


# ───────────────────────────── Boucle principale ─────────────────────────────

func _process(delta: float) -> void:
	var dt := minf(delta, 0.05)
	for c in coin_list:
		c.rotate_y(dt * 3.5)
	for pu in powerups:
		var pn: Node3D = pu["node"]
		pn.rotate_y(dt * 2.0)

	match state:
		State.SPLASH:
			update_splash(dt)
		State.MENU:
			run_phase += dt * 2.0
			rig.position.y = sin(run_phase) * 0.03
			arm_l.rotation.x = sin(run_phase) * 0.12
			arm_r.rotation.x = -sin(run_phase) * 0.12
		State.PLAY:
			update_play(dt)
		State.OVER:
			dead_t += dt
			var k := 1.0 - exp(-6.0 * dt)
			rig.rotation.x = lerpf(rig.rotation.x, 1.45, k)
			rig.position.y = lerpf(rig.position.y, 0.15, k)
			if dead_t > 0.8 and center_lbl.text.find("REJOUER") == -1:
				center_lbl.text += "\n\nTOUCHEZ POUR REJOUER"
	update_camera(dt)


func update_play(dt: float) -> void:
	speed = minf(MAX_SPEED, START_SPEED + distance * 0.0065)
	slide_t = maxf(0.0, slide_t - dt)
	magnet_t = maxf(0.0, magnet_t - dt)
	x2_t = maxf(0.0, x2_t - dt)
	invuln_t = maxf(0.0, invuln_t - dt)
	if jet_t > 0.0:
		jet_t -= dt
		var fl := 0.8 + randf() * 0.5
		flame_l.scale = Vector3(1.0, fl, 1.0)
		flame_r.scale = Vector3(1.0, 2.1 - fl, 1.0)
		if jet_t <= 0.0:
			jet_t = 0.0
			jet_vis.visible = false
			invuln_t = 2.0  # atterrissage sans danger
	player.visible = invuln_t <= 0.0 or fmod(invuln_t, 0.2) > 0.1
	var n := maxi(1, int(ceil((speed + MOVING_VZ) * dt / 0.35)))
	var sub := dt / n
	for i in n:
		if physics_step(sub):
			player.position = Vector3(px, py, pz)
			return
	collect_coins()
	stream_world()
	player.position = Vector3(px, py, pz)
	animate(dt)
	update_ui()


func animate(dt: float) -> void:
	run_phase += dt * (9.0 + speed * 0.22)
	var k := 1.0 - exp(-18.0 * dt)
	var s := sin(run_phase)
	var lean := 0.0
	var la := 0.0
	var lr := 0.0
	var aa := 0.0
	var ar := 0.0
	if slide_t > 0.0 and on_ground:
		lean = 1.25
		la = -0.2
		lr = -0.2
		aa = -1.4
		ar = -1.4
	elif jet_t > 0.0:
		lean = -0.35
		la = 0.3
		lr = 0.4
		aa = 0.6
		ar = 0.6
	elif not on_ground:
		la = 0.9
		lr = -0.5
		aa = -2.4
		ar = -2.0
	else:
		la = s * 0.95
		lr = -s * 0.95
		aa = -s * 0.8
		ar = s * 0.8
	rig.rotation.x = lerpf(rig.rotation.x, lean, k)
	rig.rotation.z = lerpf(rig.rotation.z, (px - lane_x(lane)) * 0.12, k)
	leg_l.rotation.x = lerpf(leg_l.rotation.x, la, k)
	leg_r.rotation.x = lerpf(leg_r.rotation.x, lr, k)
	arm_l.rotation.x = lerpf(arm_l.rotation.x, aa, k)
	arm_r.rotation.x = lerpf(arm_r.rotation.x, ar, k)
	var bob := absf(s) * 0.07 if (on_ground and slide_t <= 0.0) else 0.0
	rig.position.y = lerpf(rig.position.y, bob, k)


func update_camera(dt: float) -> void:
	var k := 1.0 - exp(-6.0 * dt)
	cam.position.x = lerpf(cam.position.x, px * 0.55, k)
	cam.position.y = lerpf(cam.position.y, 5.2 + py * 0.75, k)
	cam.position.z = pz + 7.5
	shake = maxf(0.0, shake - dt * 1.5)
	cam.h_offset = randf_range(-1.0, 1.0) * shake * 0.4
	cam.v_offset = randf_range(-1.0, 1.0) * shake * 0.4


# ───────────────────────────── Entrées & actions ─────────────────────────────

func _unhandled_input(e: InputEvent) -> void:
	if e is InputEventKey:
		var k := e as InputEventKey
		if not k.pressed or k.echo:
			return
		match k.keycode:
			KEY_LEFT, KEY_A:
				act("left")
			KEY_RIGHT, KEY_D:
				act("right")
			KEY_UP, KEY_W, KEY_SPACE:
				act("up")
			KEY_DOWN, KEY_S:
				act("down")
			KEY_ENTER:
				act("tap")
	elif e is InputEventScreenTouch:
		var t := e as InputEventScreenTouch
		if t.pressed:
			touch_start = t.position
			swiped = false
		elif not swiped:
			act("tap")
	elif e is InputEventScreenDrag:
		var d := e as InputEventScreenDrag
		if swiped:
			return
		var v: Vector2 = d.position - touch_start
		if v.length() > 50.0:
			swiped = true
			if absf(v.x) > absf(v.y):
				act("right" if v.x > 0.0 else "left")
			else:
				act("down" if v.y > 0.0 else "up")


func act(a: String) -> void:
	match state:
		State.SPLASH:
			end_splash()
		State.MENU:
			start_game()
		State.OVER:
			if dead_t > 0.8:
				get_tree().reload_current_scene()
		State.PLAY:
			match a:
				"left":
					change_lane(-1)
				"right":
					change_lane(1)
				"up":
					jump()
				"down":
					slide()


func change_lane(dir: int) -> void:
	var nl := clampi(lane + dir, 0, 2)
	if nl == lane:
		shake = 0.2
		return
	var tx := lane_x(nl)
	for o in obstacles:
		if o["type"] != "train":
			continue
		var ox: float = o["x"]
		var zn: float = o["zn"]
		var zf: float = o["zf"]
		var top: float = o["top"]
		if absf(ox - tx) < 0.1 and pz <= zn + 0.5 and pz >= zf - 0.5 and py < top - 0.5:
			shake = 0.25  # bloqué par un train sur le côté
			return
	lane = nl


func jump() -> void:
	if on_ground and jet_t <= 0.0:
		vy = JUMP_V
		slide_t = 0.0
		on_ground = false
		sfx_jump.play()


func slide() -> void:
	if jet_t > 0.0:
		return
	if not on_ground:
		vy = -30.0  # plongeon rapide puis glissade
	slide_t = 0.75


func start_game() -> void:
	state = State.PLAY
	dim.visible = false
	title_lbl.visible = false
	center_lbl.visible = false
	score_lbl.visible = true
	coin_lbl.visible = true
	power_lbl.visible = true


func crash() -> void:
	state = State.OVER
	dead_t = 0.0
	shake = 0.7
	sfx_crash.play()
	var sc := score()
	var record := sc > best
	if record:
		best = sc
		save_best()
	dim.visible = true
	title_lbl.visible = true
	center_lbl.visible = true
	title_lbl.text = "NOUVEAU RECORD !" if record else "PERDU !"
	power_lbl.visible = false
	center_lbl.text = "Score : %d\nPièces : %d\nDistance : %d m\nRecord : %d" % [sc, coins, int(distance), best]


func score() -> int:
	return int(distance) + coin_points


# ───────────────────────────── UI ─────────────────────────────

func make_label(parent: Control, size: int, col: Color, align: HorizontalAlignment) -> Label:
	var l := Label.new()
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	l.add_theme_color_override("font_outline_color", Color(0.0, 0.0, 0.0, 0.85))
	l.add_theme_constant_override("outline_size", 10)
	l.horizontal_alignment = align
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(l)
	return l


func build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	var root := Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(root)

	dim = ColorRect.new()
	dim.color = Color(0.05, 0.03, 0.08, 0.55)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(dim)

	var gold := Color(1.0, 0.8, 0.25)
	score_lbl = make_label(root, 52, Color.WHITE, HORIZONTAL_ALIGNMENT_RIGHT)
	score_lbl.set_anchors_preset(Control.PRESET_TOP_WIDE)
	score_lbl.offset_left = 24.0
	score_lbl.offset_right = -28.0
	score_lbl.offset_top = 40.0
	score_lbl.offset_bottom = 110.0

	coin_lbl = make_label(root, 44, gold, HORIZONTAL_ALIGNMENT_LEFT)
	coin_lbl.set_anchors_preset(Control.PRESET_TOP_WIDE)
	coin_lbl.offset_left = 28.0
	coin_lbl.offset_right = -24.0
	coin_lbl.offset_top = 46.0
	coin_lbl.offset_bottom = 110.0

	power_lbl = make_label(root, 30, Color(0.7, 1.0, 0.8), HORIZONTAL_ALIGNMENT_LEFT)
	power_lbl.set_anchors_preset(Control.PRESET_TOP_WIDE)
	power_lbl.offset_left = 28.0
	power_lbl.offset_right = -24.0
	power_lbl.offset_top = 110.0
	power_lbl.offset_bottom = 230.0

	title_lbl = make_label(root, 84, gold, HORIZONTAL_ALIGNMENT_CENTER)
	title_lbl.set_anchors_preset(Control.PRESET_TOP_WIDE)
	title_lbl.offset_left = 20.0
	title_lbl.offset_right = -20.0
	title_lbl.offset_top = 240.0
	title_lbl.offset_bottom = 400.0
	title_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART

	center_lbl = make_label(root, 38, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER)
	center_lbl.set_anchors_preset(Control.PRESET_FULL_RECT)
	center_lbl.offset_left = 30.0
	center_lbl.offset_right = -30.0
	center_lbl.offset_top = 430.0
	center_lbl.vertical_alignment = VERTICAL_ALIGNMENT_TOP
	center_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART

	build_splash(layer)


# Écran d'intro DL VIBE STUDIO. Pour utiliser ton vrai logo, place-le dans le projet
# sous le nom res://logo.png : il remplacera automatiquement le logo texte.
func build_splash(layer: CanvasLayer) -> void:
	splash = ColorRect.new()
	splash.color = Color(0.03, 0.02, 0.04)
	splash.set_anchors_preset(Control.PRESET_FULL_RECT)
	splash.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(splash)
	var gold := Color(1.0, 0.8, 0.25)
	if ResourceLoader.exists("res://logo.png"):
		var tr := TextureRect.new()
		tr.texture = load("res://logo.png")
		tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		tr.set_anchors_preset(Control.PRESET_FULL_RECT)
		tr.offset_left = 80.0
		tr.offset_right = -80.0
		tr.offset_top = 380.0
		tr.offset_bottom = -520.0
		tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
		splash.add_child(tr)
	else:
		var dl := make_label(splash, 170, gold, HORIZONTAL_ALIGNMENT_CENTER)
		dl.text = "DL"
		dl.set_anchors_preset(Control.PRESET_TOP_WIDE)
		dl.offset_top = 400.0
		dl.offset_bottom = 620.0
		var vibe := make_label(splash, 54, gold, HORIZONTAL_ALIGNMENT_CENTER)
		vibe.text = "VIBE STUDIO"
		vibe.set_anchors_preset(Control.PRESET_TOP_WIDE)
		vibe.offset_top = 620.0
		vibe.offset_bottom = 700.0
		var line := ColorRect.new()
		line.color = gold
		line.set_anchors_preset(Control.PRESET_CENTER_TOP)
		line.offset_left = -150.0
		line.offset_right = 150.0
		line.offset_top = 712.0
		line.offset_bottom = 716.0
		line.mouse_filter = Control.MOUSE_FILTER_IGNORE
		splash.add_child(line)
	var sub := make_label(splash, 30, Color(0.85, 0.85, 0.9), HORIZONTAL_ALIGNMENT_CENTER)
	sub.text = "Doubigue Loubikoa présente"
	sub.set_anchors_preset(Control.PRESET_TOP_WIDE)
	sub.offset_top = 760.0
	sub.offset_bottom = 820.0


func show_splash() -> void:
	state = State.SPLASH
	splash_t = 0.0
	splash.visible = true
	splash.modulate.a = 1.0
	dim.visible = false
	title_lbl.visible = false
	center_lbl.visible = false
	score_lbl.visible = false
	coin_lbl.visible = false
	power_lbl.visible = false
	for ch in splash.get_children():
		ch.modulate.a = 0.0


func update_splash(dt: float) -> void:
	splash_t += dt
	var a := clampf(splash_t / 0.8, 0.0, 1.0)  # fondu d'entrée du logo
	for ch in splash.get_children():
		ch.modulate.a = a
	var s := 1.0 + 0.04 * sin(splash_t * 3.0)
	if splash.get_child_count() > 0:
		var first: Control = splash.get_child(0)
		first.pivot_offset = first.size * 0.5
		first.scale = Vector2(s, s)
	if splash_t > 2.6:
		splash.modulate.a = clampf(1.0 - (splash_t - 2.6) / 0.6, 0.0, 1.0)  # fondu de sortie
	if splash_t > 3.2:
		end_splash()


func end_splash() -> void:
	splash.visible = false
	state = State.MENU
	show_menu()


func show_menu() -> void:
	dim.visible = true
	title_lbl.visible = true
	center_lbl.visible = true
	score_lbl.visible = false
	coin_lbl.visible = false
	power_lbl.visible = false
	title_lbl.text = "DL RUSH 3D"
	center_lbl.text = "Glisse à gauche / droite : changer de voie\nGlisse en haut : sauter\nGlisse en bas : glisser\nMonte sur les trains par les rampes jaunes\nAttention aux trains à feux rouges : ils foncent sur toi !\nBonus : aimant, jetpack, pièces x2\n\nRecord : %d\n\nTOUCHEZ POUR JOUER" % best


func update_ui() -> void:
	score_lbl.text = str(score())
	coin_lbl.text = "PIÈCES %d" % coins
	var parts := PackedStringArray()
	if jet_t > 0.0:
		parts.append("JETPACK %ds" % ceili(jet_t))
	if magnet_t > 0.0:
		parts.append("AIMANT %ds" % ceili(magnet_t))
	if x2_t > 0.0:
		parts.append("PIÈCES x2 %ds" % ceili(x2_t))
	power_lbl.text = "\n".join(parts)


# ───────────────────────────── Sons générés ─────────────────────────────

func make_tone(freqs: Array, dur: float, vol: float) -> AudioStreamWAV:
	var rate := 22050
	var n := int(rate * dur)
	var data := PackedByteArray()
	data.resize(n * 2)
	for i in n:
		var t := float(i) / rate
		var seg := mini(int(float(i) / n * freqs.size()), freqs.size() - 1)
		var f: float = freqs[seg]
		var env := 1.0 - float(i) / n
		var s := sin(TAU * f * t) * env * vol
		data.encode_s16(i * 2, int(s * 32767.0))
	return wav(data, rate)


func make_noise(dur: float, vol: float) -> AudioStreamWAV:
	var rate := 22050
	var n := int(rate * dur)
	var data := PackedByteArray()
	data.resize(n * 2)
	var last := 0.0
	for i in n:
		var env := pow(1.0 - float(i) / n, 2.0)
		last = lerpf(last, rng.randf_range(-1.0, 1.0), 0.35)  # bruit filtré (plus sourd)
		data.encode_s16(i * 2, int(last * env * vol * 32767.0))
	return wav(data, rate)


func wav(data: PackedByteArray, rate: int) -> AudioStreamWAV:
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = rate
	w.stereo = false
	w.data = data
	return w


func add_sfx(stream: AudioStream) -> AudioStreamPlayer:
	var p := AudioStreamPlayer.new()
	p.stream = stream
	add_child(p)
	return p


func build_audio() -> void:
	sfx_coin = add_sfx(make_tone([988.0, 1319.0], 0.12, 0.25))
	sfx_jump = add_sfx(make_tone([330.0, 520.0], 0.12, 0.18))
	sfx_crash = add_sfx(make_noise(0.45, 0.6))
	sfx_power = add_sfx(make_tone([523.0, 659.0, 784.0, 1047.0], 0.35, 0.22))
	sfx_horn = add_sfx(make_tone([220.0, 185.0], 0.7, 0.3))


# ───────────────────────────── Sauvegarde ─────────────────────────────

func load_best() -> void:
	if FileAccess.file_exists(SAVE_PATH):
		var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
		if f:
			best = f.get_32()


func save_best() -> void:
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f:
		f.store_32(best)
