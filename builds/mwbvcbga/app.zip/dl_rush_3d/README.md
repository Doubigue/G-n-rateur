# DL RUSH 3D — Godot 4.3+

Runner urbain 3D sans fin, 100 % généré par code (aucun asset à importer).

## Lancer
1. Ouvrir Godot 4.3 ou plus récent → Importer → choisir `project.godot`.
2. Appuyer sur F5.

## Contrôles
- Mobile : glisser gauche/droite (voies), haut (sauter), bas (glisser). Toucher pour démarrer/rejouer.
- PC : flèches ou WASD, Espace = sauter, Entrée = démarrer.

## Gameplay
- 3 voies ferrées entre des immeubles éclairés, coucher de soleil + brouillard.
- Barrières rouges → sauter. Panneaux jaunes → glisser dessous. Trains → changer de voie,
  ou monter dessus par les rampes jaunes et courir sur les toits.
- Pièces (+10 pts), vitesse qui augmente, record sauvegardé.
- Trains en mouvement (feux rouges + klaxon) qui foncent vers toi après 400 m.
- Bonus : aimant (10 s), jetpack (7 s, vol au-dessus des trains + pièces dans le ciel), pièces x2 (12 s).
- Écran d'intro DL VIBE STUDIO. Pour mettre ton vrai logo : copie-le dans le projet sous le nom `logo.png`
  (à côté de `project.godot`), il remplace automatiquement le logo texte.

## Fichiers
- `main.gd` : tout le jeu (monde, joueur, obstacles, UI, sons).
- `main.tscn` : scène principale (un seul nœud).
