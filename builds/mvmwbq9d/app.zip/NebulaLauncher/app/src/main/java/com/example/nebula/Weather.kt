package com.example.nebula

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.roundToInt

/** Météo temps réel via Open-Meteo (sans clé API). Position approximative si autorisée, sinon Paris. */
object Weather {
    fun fetch(ctx: Context, cb: (String) -> Unit) {
        Thread {
            try {
                var lat = 48.85; var lon = 2.35
                if (ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
                    lm.getProviders(true).mapNotNull { try { lm.getLastKnownLocation(it) } catch (_: SecurityException) { null } }
                        .maxByOrNull { it.time }?.let { lat = it.latitude; lon = it.longitude }
                }
                val con = URL("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code")
                    .openConnection() as HttpURLConnection
                con.connectTimeout = 5000; con.readTimeout = 5000
                val cur = JSONObject(con.inputStream.bufferedReader().readText()).getJSONObject("current")
                val code = cur.getInt("weather_code"); val temp = cur.getDouble("temperature_2m")
                val icon = when (code) {
                    0 -> "☀️"; 1, 2 -> "🌤️"; 3 -> "☁️"; 45, 48 -> "🌫️"; in 51..67 -> "🌧️"
                    in 71..77 -> "❄️"; in 80..82 -> "🌦️"; in 95..99 -> "⛈️"; else -> "🌡️"
                }
                val s = "$icon ${temp.roundToInt()}°C"
                Prefs(ctx).weather = s; cb(s)
            } catch (_: Throwable) {}
        }.start()
    }
}
