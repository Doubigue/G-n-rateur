package com.example.nebula

import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.MotionEvent
import android.view.SurfaceHolder

/** Vrai fond d'écran animé Android (à choisir dans les réglages de fond d'écran). */
class NebulaWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = object : Engine() {
        val eng = ParticleEngine()
        val h = Handler(Looper.getMainLooper())
        var visible = false
        val loop = object : Runnable { override fun run() { drawFrame(); if (visible) h.postDelayed(this, 16) } }

        override fun onCreate(sh: SurfaceHolder) { super.onCreate(sh); setTouchEventsEnabled(true) }
        override fun onSurfaceChanged(sh: SurfaceHolder, f: Int, w: Int, hh: Int) { eng.resize(w, hh) }
        override fun onVisibilityChanged(v: Boolean) {
            visible = v
            if (v) {
                val p = Prefs(applicationContext)
                eng.theme = Themes.all[p.theme.coerceIn(0, Themes.all.size - 1)]
                eng.style = if (p.bgMode < 4 || p.bgMode >= 6) p.bgMode else 0
                eng.rebuild(); h.post(loop)
            } else h.removeCallbacks(loop)
        }
        override fun onSurfaceDestroyed(sh: SurfaceHolder) { visible = false; h.removeCallbacks(loop) }
        override fun onTouchEvent(e: MotionEvent) {
            if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) eng.tx = -1f
            else { eng.tx = e.x; eng.ty = e.y }
        }
        private fun drawFrame() {
            val c = surfaceHolder.lockCanvas() ?: return
            try { eng.draw(c) } finally { surfaceHolder.unlockCanvasAndPost(c) }
        }
    }
}
