package com.example.nebula

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.Drawable
import androidx.core.content.res.ResourcesCompat
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory

enum class Cat(val label: String) {
    ALL("Tout"), SOCIAL("Réseaux"), GAMES("Jeux"), TOOLS("Outils"), PRODUCTIVITY("Productivité"), MEDIA("Médias"), OTHER("Autres")
}

data class AppItem(val label: String, val pkg: String, val icon: Drawable, val cat: Cat, val hue: Float, val intent: Intent)

object IconPacks {
    private val actions = listOf("org.adw.launcher.THEMES", "com.novalauncher.THEME", "com.gau.go.launcherex.theme")
    fun available(pm: PackageManager): List<Pair<String, String>> =
        actions.flatMap { pm.queryIntentActivities(Intent(it), 0) }
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }.distinctBy { it.first }

    /** Lit appfilter.xml (format ADW/Nova/Apex) : "pkg/classe" -> nom du drawable. */
    fun loadMap(pm: PackageManager, pack: String): Map<String, String> {
        val map = HashMap<String, String>()
        try {
            val res = pm.getResourcesForApplication(pack)
            val id = res.getIdentifier("appfilter", "xml", pack)
            val p: XmlPullParser = if (id != 0) res.getXml(id)
            else XmlPullParserFactory.newInstance().newPullParser().apply { setInput(res.assets.open("appfilter.xml"), null) }
            var e = p.eventType
            while (e != XmlPullParser.END_DOCUMENT) {
                if (e == XmlPullParser.START_TAG && p.name == "item") {
                    val comp = p.getAttributeValue(null, "component"); val dr = p.getAttributeValue(null, "drawable")
                    if (comp != null && dr != null && comp.startsWith("ComponentInfo{"))
                        map[comp.substringAfter("{").substringBefore("}")] = dr
                }
                e = p.next()
            }
        } catch (_: Throwable) {}
        return map
    }

    fun icon(pm: PackageManager, pack: String, name: String): Drawable? = try {
        val res = pm.getResourcesForApplication(pack)
        val id = res.getIdentifier(name, "drawable", pack)
        if (id != 0) ResourcesCompat.getDrawable(res, id, null) else null
    } catch (_: Throwable) { null }
}

class AppRepo(private val ctx: Context, private val prefs: Prefs) {
    fun load(): List<AppItem> {
        val pm = ctx.packageManager
        val map = if (prefs.iconPack.isNotEmpty()) IconPacks.loadMap(pm, prefs.iconPack) else emptyMap()
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(q, 0).filter { it.activityInfo.packageName != ctx.packageName }.map { ri ->
            val pkg = ri.activityInfo.packageName
            val icon = map["$pkg/${ri.activityInfo.name}"]?.let { IconPacks.icon(pm, prefs.iconPack, it) } ?: ri.loadIcon(pm)
            val label = ri.loadLabel(pm).toString()
            AppItem(label, pkg, icon, categorize(ri.activityInfo.applicationInfo, pkg, label), hueOf(icon),
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                    .setComponent(ComponentName(pkg, ri.activityInfo.name)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }.distinctBy { it.intent.component }
    }

    /** Catégorisation : catégorie déclarée par l'app (API 26+) puis heuristique sur nom de paquet / libellé. */
    private fun categorize(ai: ApplicationInfo, pkg: String, label: String): Cat {
        val k = "$pkg ${label.lowercase()}"
        fun has(vararg w: String) = w.any { k.contains(it) }
        val c = ai.category
        return when {
            c == ApplicationInfo.CATEGORY_GAME || has("game", "supercell", "gameloft") -> Cat.GAMES
            c == ApplicationInfo.CATEGORY_SOCIAL || has("whatsapp", "telegram", "facebook", "instagram", "twitter", "snapchat",
                "discord", "tiktok", "messenger", "signal", "reddit", "linkedin") -> Cat.SOCIAL
            c == ApplicationInfo.CATEGORY_AUDIO || c == ApplicationInfo.CATEGORY_VIDEO || c == ApplicationInfo.CATEGORY_IMAGE ||
                has("spotify", "youtube", "music", "video", "player", "camera", "gallery", "galerie", "photo", "netflix", "deezer") -> Cat.MEDIA
            c == ApplicationInfo.CATEGORY_PRODUCTIVITY || has("office", "docs", "sheets", "calendar", "agenda", "mail", "notes",
                "drive", "slack", "teams", "excel", "outlook") -> Cat.PRODUCTIVITY
            has("calculat", "clock", "horloge", "settings", "param", "files", "fichiers", "torch", "vpn", "browser", "chrome",
                "phone", "contacts", "dialer") -> Cat.TOOLS
            else -> Cat.OTHER
        }
    }

    /** Teinte dominante (pondérée par saturation) ; 400 = icône grise, triée en dernier. */
    private fun hueOf(d: Drawable): Float {
        val b = Bitmap.createBitmap(16, 16, Bitmap.Config.ARGB_8888)
        val cp = d.copy(); cp.setBounds(0, 0, 16, 16); cp.draw(Canvas(b))
        var r = 0.0; var g = 0.0; var bl = 0.0; var wt = 0.0; val hsv = FloatArray(3)
        for (x in 0 until 16) for (y in 0 until 16) {
            val p = b.getPixel(x, y); if (Color.alpha(p) < 128) continue
            Color.colorToHSV(p, hsv); val w = (hsv[1] * hsv[2]).toDouble()
            r += Color.red(p) * w; g += Color.green(p) * w; bl += Color.blue(p) * w; wt += w
        }
        if (wt < 5.0) return 400f
        Color.colorToHSV(Color.rgb((r / wt).toInt(), (g / wt).toInt(), (bl / wt).toInt()), hsv)
        return hsv[0]
    }

    fun sort(l: List<AppItem>, mode: Int) = when (mode) {
        1 -> l.sortedWith(compareByDescending<AppItem> { prefs.launches(it.pkg) }.thenBy { it.label.lowercase() })
        2 -> l.sortedBy { it.hue }
        else -> l.sortedBy { it.label.lowercase() }
    }
}
