package com.example.nebula

import android.content.Context
import android.graphics.*
import android.graphics.drawable.Drawable
import android.hardware.*
import android.view.MotionEvent
import android.view.View

/** Inclinaison gyroscopique : les vues enregistrées pivotent selon l'orientation du téléphone. */
class Tilt(ctx: Context) : SensorEventListener {
    val views = ArrayList<View>()
    var rx = 0f; var ry = 0f
    var onChange: ((Float, Float) -> Unit)? = null
    private val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    fun add(v: View) { v.cameraDistance = 12000f; views += v }
    fun start() { sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) } }
    fun stop() = sm.unregisterListener(this)
    override fun onSensorChanged(e: SensorEvent) {
        val ty = (-e.values[0] * 2.5f).coerceIn(-18f, 18f)
        val tx = ((e.values[1] - 6.5f) * 2f).coerceIn(-18f, 18f)
        ry += (ty - ry) * 0.15f; rx += (tx - rx) * 0.15f
        for (v in views) { v.rotationY = ry; v.rotationX = rx }
        onChange?.invoke(rx, ry)
    }
    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
}

/** Carte 3D interactive : s'incline sous le doigt. */
fun View.tiltOnTouch(): View {
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                v.cameraDistance = 12000f
                v.rotationY = ((e.x / v.width) - .5f) * 24f
                v.rotationX = -((e.y / v.height) - .5f) * 24f
            }
            else -> v.animate().rotationX(0f).rotationY(0f).setDuration(200).start()
        }
        false
    }
    return this
}

fun Drawable.copy(): Drawable = constantState?.newDrawable()?.mutate() ?: this

/** Icône avec effet miroir / réflexion. */
class ReflectionIcon(ctx: Context, src: Drawable) : View(ctx) {
    private val d = src.copy()
    private val p = Paint()
    override fun onDraw(cv: Canvas) {
        val ih = (height * 0.72f).toInt()
        val iw = minOf(width, ih)
        val left = (width - iw) / 2
        d.setBounds(left, 0, left + iw, ih); d.draw(cv)
        val sc = cv.saveLayer(0f, ih.toFloat(), width.toFloat(), height.toFloat(), null)
        cv.save(); cv.scale(1f, -1f, 0f, ih.toFloat()); d.draw(cv); cv.restore()
        p.shader = LinearGradient(0f, ih.toFloat(), 0f, height.toFloat(), 0x66FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
        p.xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
        cv.drawRect(0f, ih.toFloat(), width.toFloat(), height.toFloat(), p)
        p.xfermode = null; p.shader = null
        cv.restoreToCount(sc)
    }
}
