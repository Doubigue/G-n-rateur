package com.example.nebula

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Typeface
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.SystemClock
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.text.TextUtils
import android.view.*
import android.widget.*
import androidx.core.app.NotificationManagerCompat
import kotlin.math.abs

/** Doit être activé dans « Accès aux notifications » pour lire/contrôler les sessions média. */
class MediaListener : NotificationListenerService() {
    companion object { var instance: MediaListener? = null }
    override fun onListenerConnected() { instance = this }
    override fun onListenerDisconnected() { instance = null }
}

object MediaHelper {
    fun hasAccess(c: Context) = NotificationManagerCompat.getEnabledListenerPackages(c).contains(c.packageName)
    fun controller(c: Context): MediaController? = try {
        (c.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager)
            .getActiveSessions(ComponentName(c, MediaListener::class.java))
            .let { l -> l.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: l.firstOrNull() }
    } catch (_: SecurityException) { null }
}

/** Widget média : pochette floutée, titre, artiste, progression, boutons, gestes (swipe = piste, double-tap = muet). */
class MediaCard(ctx: Context, private val t: NebulaTheme) : FrameLayout(ctx) {
    var onOtherFling: ((Float, Float) -> Boolean)? = null
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val art = ImageView(ctx).apply { scaleType = ImageView.ScaleType.CENTER_CROP; alpha = 0.5f }
    private val title = TextView(ctx).apply {
        setTextColor(t.text); textSize = 16f; maxLines = 1; ellipsize = TextUtils.TruncateAt.END; setTypeface(typeface, Typeface.BOLD)
    }
    private val artist = TextView(ctx).apply { setTextColor(t.text); alpha = .75f; textSize = 13f; maxLines = 1 }
    private val bar = ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal).apply {
        max = 1000; progressTintList = ColorStateList.valueOf(t.accent)
    }
    private val playBtn = ctrl("▶") { c ->
        if (c.playbackState?.state == PlaybackState.STATE_PLAYING) c.transportControls.pause() else c.transportControls.play()
    }
    private var lastArt: Bitmap? = null

    private fun ctrl(label: String, act: (MediaController) -> Unit) = TextView(context).apply {
        text = label; textSize = 28f; setTextColor(t.accent2); gravity = Gravity.CENTER; setPadding(dp(18), dp(4), dp(18), dp(4))
        setOnClickListener { performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); MediaHelper.controller(context)?.let(act) }
    }

    private val gd = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent) = true
        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            if (!MediaHelper.hasAccess(context))
                context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return true
        }
        override fun onDoubleTap(e: MotionEvent): Boolean {
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            (context.getSystemService(Context.AUDIO_SERVICE) as AudioManager)
                .adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, 0)
            return true
        }
        override fun onFling(a: MotionEvent?, b: MotionEvent, vx: Float, vy: Float): Boolean {
            if (abs(vx) > 800 && abs(vx) > abs(vy)) {
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                MediaHelper.controller(context)?.transportControls?.let { if (vx < 0) it.skipToNext() else it.skipToPrevious() }
                return true
            }
            return onOtherFling?.invoke(vx, vy) ?: false
        }
    })

    init {
        background = glassBg(t, dp(24).toFloat(), 60); clipToOutline = true; outlineProvider = ViewOutlineProvider.BACKGROUND
        addView(art, FrameLayout.LayoutParams(-1, -1))
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(10)) }
        col.addView(title); col.addView(artist)
        col.addView(bar, LinearLayout.LayoutParams(-1, dp(10)).apply { topMargin = dp(8) })
        val row = LinearLayout(ctx).apply { gravity = Gravity.CENTER }
        row.addView(ctrl("⏮") { it.transportControls.skipToPrevious() }); row.addView(playBtn)
        row.addView(ctrl("⏭") { it.transportControls.skipToNext() })
        col.addView(row); addView(col, FrameLayout.LayoutParams(-1, -2))
        refresh()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean { gd.onTouchEvent(e); return true }

    fun refresh() {
        val c = MediaHelper.controller(context)
        if (c == null) {
            title.text = if (MediaHelper.hasAccess(context)) "Aucun média en lecture" else "Touchez pour autoriser le contrôle média"
            artist.text = ""; bar.progress = 0; art.setImageDrawable(null); lastArt = null; playBtn.text = "▶"; return
        }
        val md = c.metadata
        title.text = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "—"
        artist.text = md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        val bmp = md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
        if (bmp !== lastArt) { lastArt = bmp; art.setImageBitmap(bmp?.let { Bitmap.createScaledBitmap(it, 32, 32, true) }) } // 32px agrandi = flou
        val st = c.playbackState; val dur = md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        if (st != null && dur > 0) {
            var pos = st.position
            if (st.state == PlaybackState.STATE_PLAYING) pos += ((SystemClock.elapsedRealtime() - st.lastPositionUpdateTime) * st.playbackSpeed).toLong()
            bar.progress = (pos * 1000 / dur).toInt().coerceIn(0, 1000)
        }
        playBtn.text = if (st?.state == PlaybackState.STATE_PLAYING) "⏸" else "▶"
    }
}
