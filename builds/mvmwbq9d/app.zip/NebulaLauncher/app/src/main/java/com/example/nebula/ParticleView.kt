package com.example.nebula

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.*
import kotlin.random.Random

/** Moteur de fonds animés partagé par la vue du launcher, le lockscreen et le live wallpaper. */
class ParticleEngine {
    var theme: NebulaTheme = Themes.all[0]
    /** 0 particules, 1 vagues fluides, 2 motifs géométriques, 3 nébuleuse */
    var style = 0
    var tx = -1f; var ty = -1f
    var w = 0
        private set
    var h = 0
        private set

    private class P(var x: Float, var y: Float, var vx: Float, var vy: Float, val r: Float, val color: Int)
    private class Blob(var x: Float, var y: Float, var vx: Float, var vy: Float, val r: Float, val shader: RadialGradient)
    private val ps = ArrayList<P>()
    private val blobs = ArrayList<Blob>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val scene = SceneRenderer()

    fun resize(w: Int, h: Int) {
        this.w = w; this.h = h; ps.clear(); blobs.clear(); scene.resize(w, h)
        if (w == 0 || h == 0) return
        val pal = theme.palette
        repeat(90) {
            ps += P(Random.nextFloat() * w, Random.nextFloat() * h, Random.nextFloat() - .5f, Random.nextFloat() - .5f,
                Random.nextFloat() * 5f + 2f, pal[Random.nextInt(pal.size)])
        }
        repeat(8) { i ->
            val col = pal[i % pal.size]
            val r = min(w, h) * (0.35f + Random.nextFloat() * 0.3f)
            blobs += Blob(Random.nextFloat() * w, Random.nextFloat() * h, (Random.nextFloat() - .5f) * .6f, (Random.nextFloat() - .5f) * .6f, r,
                RadialGradient(0f, 0f, r, (col and 0x00FFFFFF) or 0x77000000, col and 0x00FFFFFF, Shader.TileMode.CLAMP))
        }
    }
    fun rebuild() = resize(w, h)

    fun draw(cv: Canvas) {
        if (w == 0) return
        if (style >= 6) { scene.draw(cv, style, tx, ty); return }
        paint.style = Paint.Style.FILL
        paint.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), theme.bgTop, theme.bgBottom, Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, w.toFloat(), h.toFloat(), paint)
        paint.shader = null
        val t = System.nanoTime() / 1e9f
        when (style) { 1 -> waves(cv, t); 2 -> geo(cv, t); 3 -> nebula(cv); else -> particles(cv) }
    }

    private fun particles(cv: Canvas) {
        for (p in ps) {
            if (tx >= 0) {
                val dx = p.x - tx; val dy = p.y - ty; val d = hypot(dx, dy) + 1f
                if (d < 300f) { p.vx += dx / d * 0.6f; p.vy += dy / d * 0.6f }
            }
            p.vx *= 0.98f; p.vy *= 0.98f
            p.x = (p.x + p.vx + w) % w; p.y = (p.y + p.vy + h) % h
            paint.color = p.color; paint.alpha = 55; cv.drawCircle(p.x, p.y, p.r * 3f, paint)
            paint.alpha = 200; cv.drawCircle(p.x, p.y, p.r, paint)
        }
    }

    private fun waves(cv: Canvas, t: Float) {
        for (k in 0..2) {
            path.reset(); path.moveTo(0f, h.toFloat())
            var x = 0f
            while (x <= w + 16) {
                var y = h * (0.55f + 0.1f * k) + sin(x * 0.008f + t * (0.8f + 0.3f * k) + k) * h * 0.04f
                if (tx >= 0) { val d = abs(x - tx); if (d < 250f) y -= (1f - d / 250f) * 70f }
                path.lineTo(x, y); x += 16f
            }
            path.lineTo(w + 16f, h.toFloat()); path.close()
            paint.color = theme.palette[k % theme.palette.size]; paint.alpha = 80
            cv.drawPath(path, paint)
        }
    }

    private fun geo(cv: Canvas, t: Float) {
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 3f
        val cx = w / 2f + if (tx >= 0) (tx - w / 2f) * 0.1f else 0f
        val cy = h / 2f + if (ty >= 0) (ty - h / 2f) * 0.1f else 0f
        for (i in 1..8) {
            val r = min(w, h) * 0.06f * i; val sides = 3 + i % 4
            val rot = t * (0.15f + 0.05f * i) * (if (i % 2 == 0) 1f else -1f)
            path.reset()
            for (s in 0..sides) {
                val a = rot + s * (2f * PI.toFloat() / sides)
                val px = cx + cos(a) * r; val py = cy + sin(a) * r
                if (s == 0) path.moveTo(px, py) else path.lineTo(px, py)
            }
            paint.color = theme.palette[i % theme.palette.size]; paint.alpha = 170
            cv.drawPath(path, paint)
        }
        paint.style = Paint.Style.FILL
    }

    private fun nebula(cv: Canvas) {
        for (b in blobs) {
            if (tx >= 0) { b.vx += (tx - b.x) * 0.000015f; b.vy += (ty - b.y) * 0.000015f }
            b.x += b.vx; b.y += b.vy
            if (b.x < -b.r) b.x = w + b.r; if (b.x > w + b.r) b.x = -b.r
            if (b.y < -b.r) b.y = h + b.r; if (b.y > h + b.r) b.y = -b.r
            cv.save(); cv.translate(b.x, b.y); paint.shader = b.shader
            cv.drawCircle(0f, 0f, b.r, paint); paint.shader = null; cv.restore()
        }
    }
}

class ParticleView(c: Context) : View(c) {
    val engine = ParticleEngine()
    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { engine.resize(w, h) }
    override fun onDraw(cv: Canvas) { engine.draw(cv); postInvalidateOnAnimation() }
    fun touch(e: MotionEvent) {
        if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) engine.tx = -1f
        else { engine.tx = e.x; engine.ty = e.y }
    }
}
