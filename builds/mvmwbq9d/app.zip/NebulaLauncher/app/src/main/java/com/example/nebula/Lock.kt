package com.example.nebula

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.*
import android.os.*
import android.view.*
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*

/** Service au premier plan : à l'extinction de l'écran, prépare l'écran de verrouillage Nebula. */
class LockService : Service() {
    private val rcv = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == Intent.ACTION_SCREEN_OFF && Prefs(c).lockEnabled)
                c.startActivity(Intent(c, LockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS))
        }
    }
    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("lock", "Écran de verrouillage", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "lock").setSmallIcon(android.R.drawable.ic_lock_idle_lock).setContentTitle("Nebula Lockscreen actif").build()
        ServiceCompat.startForeground(this, 1, n, if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0)
        ContextCompat.registerReceiver(this, rcv, IntentFilter(Intent.ACTION_SCREEN_OFF), ContextCompat.RECEIVER_NOT_EXPORTED)
    }
    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY
    override fun onDestroy() { unregisterReceiver(rcv); super.onDestroy() }
    override fun onBind(i: Intent?): IBinder? = null
}

/** Jauge de batterie circulaire style hologramme. */
class GaugeView(ctx: Context, private val t: NebulaTheme) : View(ctx) {
    private var pct = 0
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeWidth = 14f }
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; color = t.text }
    fun update() {
        val v = (context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        if (v != pct) { pct = v; invalidate() }
    }
    override fun onDraw(c: Canvas) {
        val s = min(width, height).toFloat(); val m = 14f; val r = RectF(m, m, s - m, s - m)
        c.save(); c.rotate(135f, s / 2, s / 2)
        p.shader = null; p.color = Color.argb(60, 255, 255, 255); c.drawArc(r, 0f, 270f, false, p)
        p.shader = SweepGradient(s / 2, s / 2, intArrayOf(t.accent2, t.accent, t.accent2), null)
        p.setShadowLayer(12f, 0f, 0f, t.accent2)
        c.drawArc(r, 0f, 270f * pct / 100f, false, p); p.clearShadowLayer()
        c.restore()
        tp.textSize = s * 0.26f; c.drawText("$pct%", s / 2, s / 2 + tp.textSize * 0.35f, tp)
    }
}

/** Trace du doigt (particules) + détection : glisser vers le haut OU tracer un cercle = déverrouiller. */
class TraceView(ctx: Context, private val accent: Int, private val onUnlock: () -> Unit) : View(ctx) {
    private val pts = ArrayList<PointF>()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    fun feed(e: MotionEvent) {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { animate().cancel(); alpha = 1f; pts.clear(); pts.add(PointF(e.x, e.y)) }
            MotionEvent.ACTION_MOVE -> { pts.add(PointF(e.x, e.y)); invalidate() }
            MotionEvent.ACTION_UP -> {
                pts.add(PointF(e.x, e.y)); evaluate()
                animate().alpha(0f).setDuration(350).withEndAction { pts.clear(); alpha = 1f; invalidate() }.start()
            }
        }
    }
    private fun evaluate() {
        if (pts.size < 6) return
        val f = pts.first(); val l = pts.last()
        val bw = pts.maxOf { it.x } - pts.minOf { it.x }; val bh = pts.maxOf { it.y } - pts.minOf { it.y }
        val dx = l.x - f.x; val dy = l.y - f.y; val d = resources.displayMetrics.density
        val up = dy < -height * 0.25f && abs(dx) < abs(dy) * 0.6f
        val circle = pts.size > 12 && bw > 110 * d && bh > 110 * d && hypot(dx, dy) < 0.3f * max(bw, bh)
        if (up || circle) { performHapticFeedback(HapticFeedbackConstants.LONG_PRESS); onUnlock() }
    }
    override fun onDraw(c: Canvas) {
        for (i in pts.indices) {
            val fr = i / pts.size.toFloat()
            p.color = accent; p.alpha = (fr * 220).toInt(); c.drawCircle(pts[i].x, pts[i].y, 4f + fr * 12f, p)
        }
    }
}

class LockActivity : ComponentActivity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var media: MediaCard
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var weather: TextView
    private lateinit var notifs: LinearLayout
    private lateinit var gauge: GaugeView
    private lateinit var tilt: Tilt
    private var n = 0
    private val loop = object : Runnable { override fun run() { tick(); h.postDelayed(this, 500) } }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        WindowCompat.setDecorFitsSystemWindows(window, false)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) { override fun handleOnBackPressed() {} })
        val prefs = Prefs(this); val t = Themes.all[prefs.theme.coerceIn(0, Themes.all.size - 1)]
        tilt = Tilt(this)
        val trace = TraceView(this, t.accent) { unlock() }
        val root = object : FrameLayout(this) {
            override fun dispatchTouchEvent(ev: MotionEvent): Boolean { trace.feed(ev); return super.dispatchTouchEvent(ev) }
        }
        root.addView(ParticleView(this).also { it.engine.theme = t; it.engine.style = if (prefs.bgMode < 4 || prefs.bgMode >= 6) prefs.bgMode else 0 },
            FrameLayout.LayoutParams(-1, -1))

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(20), dp(90), dp(20), dp(40)) }
        clock = TextView(this).apply {
            textSize = 88f; setTextColor(t.accent2); typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
            setShadowLayer(30f, 0f, 0f, t.accent2); tilt.add(this)
        }
        date = TextView(this).apply { setTextColor(t.text); textSize = 16f }
        weather = TextView(this).apply { setTextColor(t.text); textSize = 22f; text = prefs.weather }
        ObjectAnimator_bob(weather)
        gauge = GaugeView(this, t)
        notifs = LinearLayout(this).apply { gravity = Gravity.CENTER }
        media = MediaCard(this, t)
        col.addView(clock); col.addView(date)
        col.addView(weather, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(8) })
        col.addView(gauge, LinearLayout.LayoutParams(dp(120), dp(120)).apply { topMargin = dp(16) })
        col.addView(notifs, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(16) })
        col.addView(View(this), LinearLayout.LayoutParams(-1, 0, 1f))
        col.addView(media, LinearLayout.LayoutParams(-1, -2))
        col.addView(TextView(this).apply { text = "Glissez vers le haut ou tracez un cercle"; setTextColor(t.text); alpha = .6f; textSize = 12f; gravity = Gravity.CENTER },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
        root.addView(col, FrameLayout.LayoutParams(-1, -1))
        root.addView(trace, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
    }

    private fun ObjectAnimator_bob(v: View) {
        android.animation.ObjectAnimator.ofFloat(v, "translationY", 0f, -dp(6).toFloat()).apply {
            duration = 1500; repeatMode = android.animation.ValueAnimator.REVERSE; repeatCount = android.animation.ValueAnimator.INFINITE; start()
        }
    }

    private fun unlock() {
        getSystemService(KeyguardManager::class.java).requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
            override fun onDismissSucceeded() { finish() }
        })
    }

    private fun tick() {
        val now = Date()
        clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
        date.text = SimpleDateFormat("EEEE d MMMM", Locale.getDefault()).format(now)
        media.refresh(); gauge.update()
        if (n++ % 10 == 0) refreshNotifs()
    }

    /** Notifications discrètes : seulement le nom de l'app, dans des bulles de verre. */
    private fun refreshNotifs() {
        notifs.removeAllViews()
        val t = Themes.all[Prefs(this).theme.coerceIn(0, Themes.all.size - 1)]
        val list = (try { MediaListener.instance?.activeNotifications?.filter { !it.isOngoing && it.packageName != packageName } }
        catch (_: Throwable) { null }) ?: return
        list.map { it.packageName }.distinct().take(5).forEach { pkg ->
            val label = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (_: Exception) { pkg }
            notifs.addView(TextView(this).apply {
                text = label; setTextColor(t.text); textSize = 12f; setPadding(dp(12), dp(6), dp(12), dp(6)); background = glassBg(t, dp(16).toFloat(), 60)
            }, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(6) })
        }
    }

    override fun onResume() {
        super.onResume(); tilt.start(); h.post(loop)
        Weather.fetch(this) { s -> h.post { weather.text = s } }
    }
    override fun onPause() { super.onPause(); tilt.stop(); h.removeCallbacks(loop) }
}
