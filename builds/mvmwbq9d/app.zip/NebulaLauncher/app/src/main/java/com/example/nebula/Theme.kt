package com.example.nebula

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable

data class NebulaTheme(
    val name: String, val bgTop: Int, val bgBottom: Int, val accent: Int, val accent2: Int,
    val text: Int, val glass: Int, val palette: IntArray
)

private fun c(v: Long) = v.toInt()

object Themes {
    val all = listOf(
        NebulaTheme("Futuriste Cyberpunk", c(0xFF0A0014), c(0xFF2A0A3F), c(0xFFFF2BD6), c(0xFF00F5FF), c(0xFFFFFFFF), c(0xFFFFFFFF),
            intArrayOf(c(0xFFFF2BD6), c(0xFF00F5FF), c(0xFFFFE600))),
        NebulaTheme("Minimaliste Épuré", c(0xFFF4F4F6), c(0xFFD9DCE3), c(0xFF222222), c(0xFF555555), c(0xFF111111), c(0xFF000000),
            intArrayOf(c(0xFF9AA0AA), c(0xFFC2C6CE), c(0xFF7A808A))),
        NebulaTheme("Néon Dark Mode", c(0xFF000000), c(0xFF0B0B12), c(0xFF39FF88), c(0xFF00B7FF), c(0xFFFFFFFF), c(0xFFFFFFFF),
            intArrayOf(c(0xFF39FF88), c(0xFF00B7FF), c(0xFFB400FF))),
        NebulaTheme("Nature Glass", c(0xFF06231A), c(0xFF1F5A3F), c(0xFFB6F5C8), c(0xFFFFE9A8), c(0xFFFFFFFF), c(0xFFFFFFFF),
            intArrayOf(c(0xFF7BD389), c(0xFFB6F5C8), c(0xFFFFE9A8))),
        NebulaTheme("Aurore Boréale", c(0xFF020B1F), c(0xFF0B3B4A), c(0xFF5CFFC8), c(0xFF9B7BFF), c(0xFFFFFFFF), c(0xFFFFFFFF),
            intArrayOf(c(0xFF5CFFC8), c(0xFF9B7BFF), c(0xFF3AA0FF)))
    )
}

fun glassBg(t: NebulaTheme, radius: Float, alpha: Int = 70) = GradientDrawable().apply {
    cornerRadius = radius
    setColor(Color.argb(alpha, Color.red(t.glass), Color.green(t.glass), Color.blue(t.glass)))
    setStroke(2, (t.accent and 0x00FFFFFF) or (0x5A shl 24))
}

class Prefs(c: Context) {
    private val sp = c.applicationContext.getSharedPreferences("nebula", Context.MODE_PRIVATE)
    var theme: Int get() = sp.getInt("theme", 0); set(v) { sp.edit().putInt("theme", v).apply() }
    /** 0 particules, 1 vagues, 2 géométrique, 3 nébuleuse, 4 image, 5 vidéo */
    var bgMode: Int get() = sp.getInt("bg", 0); set(v) { sp.edit().putInt("bg", v).apply() }
    var bgUri: String? get() = sp.getString("bguri", null); set(v) { sp.edit().putString("bguri", v).apply() }
    var iconPack: String get() = sp.getString("pack", "") ?: ""; set(v) { sp.edit().putString("pack", v).apply() }
    /** 0 A-Z, 1 fréquence, 2 couleur */
    var sort: Int get() = sp.getInt("sort", 0); set(v) { sp.edit().putInt("sort", v).apply() }
    var focus: Boolean get() = sp.getBoolean("focus", false); set(v) { sp.edit().putBoolean("focus", v).apply() }
    var focusSince: Long get() = sp.getLong("focusSince", 0); set(v) { sp.edit().putLong("focusSince", v).apply() }
    var lockEnabled: Boolean get() = sp.getBoolean("lock", false); set(v) { sp.edit().putBoolean("lock", v).apply() }
    var dock: String get() = sp.getString("dock", "") ?: ""; set(v) { sp.edit().putString("dock", v).apply() }
    var weather: String get() = sp.getString("weather", "") ?: ""; set(v) { sp.edit().putString("weather", v).apply() }
    fun launches(pkg: String) = sp.getInt("n_$pkg", 0)
    fun addLaunch(pkg: String) { sp.edit().putInt("n_$pkg", launches(pkg) + 1).apply() }
}
