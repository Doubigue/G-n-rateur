package com.linguavibe.app.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linguavibe.app.data.Lesson
import com.linguavibe.app.data.Levels
import com.linguavibe.app.data.Vocab

// ------------------------------------------------------------------ Icônes lineart

/** Petite icône lineart fixe (sans animation). */
@Composable
fun LineIcon(drawing: LineDrawing, color: Color, size: Dp = 20.dp, accent: Color = color) {
    LineArt(
        drawing, Modifier.size(size), color = color, accent = accent,
        strokeWidth = (size.value / 12f).coerceIn(1.4f, 2.6f).dp, animate = false, float = false
    )
}

/**
 * Bouton pilule avec icône lineart. [filled] : fond plein coloré ; sinon contour.
 */
@Composable
fun PillButton(
    text: String,
    icon: LineDrawing?,
    color: Color,
    modifier: Modifier = Modifier,
    filled: Boolean = true,
    enabled: Boolean = true,
    big: Boolean = false,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(50)
    val fg = if (filled) Color.White else color
    Row(
        modifier
            .alpha(if (enabled) 1f else 0.45f)
            .clip(shape)
            .then(
                if (filled) Modifier.background(Brush.linearGradient(listOf(color, lerpNight(color))))
                else Modifier.border(1.6.dp, color.copy(alpha = 0.6f), shape)
            )
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = if (big) 20.dp else 14.dp, vertical = if (big) 14.dp else 9.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)
    ) {
        if (icon != null) LineIcon(icon, fg, if (big) 22.dp else 18.dp, accent = if (filled) Gold else color)
        Text(
            text, color = fg, fontWeight = FontWeight.Bold, fontSize = if (big) 16.sp else 14.sp,
            maxLines = 1, overflow = TextOverflow.Ellipsis
        )
    }
}

fun lerpNight(c: Color, k: Float = 0.4f) = Color(
    red = c.red * (1 - k) + Night.red * k,
    green = c.green * (1 - k) + Night.green * k,
    blue = c.blue * (1 - k) + Night.blue * k
)

/** Pastille de langue (code en lettres) qui remplace les drapeaux émoji. */
@Composable
fun LangBadge(code: String, size: Dp = 34.dp) {
    val t = posterTheme(code)
    Box(
        Modifier.size(size).clip(CircleShape).background(Brush.linearGradient(listOf(t.start, t.end))),
        contentAlignment = Alignment.Center
    ) {
        Text(code.uppercase(), style = PosterTitle, fontSize = (size.value * 0.36f).sp, color = t.accent)
    }
}

// --------------------------------------------------------------- En-tête de leçon

/** Bandeau affiche de la leçon : illustration lineart animée, numéro, titres. */
@Composable
fun LessonHero(lesson: Lesson) {
    val theme = levelPoster(lesson.level)
    val drawing = remember(lesson) { Art.forLesson(lesson) }
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(Brush.linearGradient(listOf(theme.start, theme.end)))
            .waxPattern(alpha = 0.09f, seed = lesson.number)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(
                "LEÇON ${lesson.number.toString().padStart(2, '0')}",
                fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp, color = theme.accent
            )
            Text(lesson.title, style = PosterTitle, fontSize = 24.sp, lineHeight = 27.sp, color = Color.White)
            Text(lesson.titleTr, style = AccentText, fontSize = 15.sp, color = Color.White.copy(alpha = 0.88f))
            Spacer(Modifier.height(2.dp))
            Pill("${lesson.level} · ${Levels.label(lesson.level)}")
        }
        Spacer(Modifier.width(10.dp))
        LineArt(drawing, Modifier.size(116.dp), color = Color.White, accent = theme.accent, strokeWidth = 2.2.dp)
    }
}

// ------------------------------------------------------------------- Onglets

data class LessonTab(val label: String, val icon: LineDrawing)

val lessonTabs = listOf(
    LessonTab("Leçon", Art.icBook),
    LessonTab("Lecture", Art.icNews),
    LessonTab("Dialogue", Art.icChat),
    LessonTab("Prononciation", Art.icMic),
    LessonTab("Quiz", Art.icQuiz),
    LessonTab("Devoir", Art.icPen),
)

/** Barre d'onglets en pilules défilantes : l'onglet actif est sombre avec texte doré. */
@Composable
fun LessonTabBar(selected: Int, color: Color, onSelect: (Int) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(Paper)
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        lessonTabs.forEachIndexed { index, tab ->
            val active = index == selected
            val bg by animateColorAsState(if (active) Night else Color.White, label = "tab")
            Row(
                Modifier
                    .clip(RoundedCornerShape(50))
                    .background(bg)
                    .border(1.dp, if (active) Night else Sand, RoundedCornerShape(50))
                    .clickable { onSelect(index) }
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                LineIcon(tab.icon, if (active) Gold else color, 18.dp, accent = if (active) Gold else color)
                Text(
                    "${index + 1}. ${tab.label}", fontSize = 13.sp,
                    fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
                    color = if (active) Color.White else Ink
                )
            }
        }
    }
}

// ------------------------------------------------------- Carte de vocabulaire

/**
 * Carte de vocabulaire typographique (sans émoji) qui se retourne :
 * recto = mot en grand + prononciation ; verso = traduction + exemple.
 */
@Composable
fun VocabCard(vocab: Vocab, index: Int, color: Color, onSpeak: () -> Unit, modifier: Modifier = Modifier) {
    var flipped by remember { mutableStateOf(false) }
    val rotation by animateFloatAsState(
        if (flipped) 180f else 0f,
        spring(dampingRatio = 0.7f, stiffness = Spring.StiffnessLow),
        label = "flip"
    )
    val front = rotation <= 90f
    val shape = RoundedCornerShape(24.dp)
    Box(
        modifier
            .height(200.dp)
            .graphicsLayer {
                rotationY = rotation
                cameraDistance = 14f * density
            }
            .clip(shape)
            .then(
                if (front) Modifier.background(Color.White).border(1.dp, Sand, shape)
                else Modifier.background(Brush.linearGradient(listOf(color, lerpNight(color))))
            )
            .then(if (front) Modifier else Modifier.waxPattern(alpha = 0.08f, seed = index))
            .clickable { flipped = !flipped }
            .padding(12.dp)
    ) {
        if (front) {
            // Grand numéro décoratif en filigrane
            Text(
                (index + 1).toString().padStart(2, '0'), style = PosterTitle, fontSize = 40.sp,
                color = color.copy(alpha = 0.10f), modifier = Modifier.align(Alignment.TopStart)
            )
            Box(
                Modifier.align(Alignment.TopEnd).size(34.dp).clip(CircleShape)
                    .background(color.copy(alpha = 0.12f)).clickable(onClick = onSpeak),
                contentAlignment = Alignment.Center
            ) { LineIcon(Art.icVoice, color, 18.dp) }
            Column(
                Modifier.align(Alignment.Center).padding(top = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    vocab.word, style = PosterTitle,
                    fontSize = when {
                        vocab.word.length <= 8 -> 26.sp
                        vocab.word.length <= 16 -> 20.sp
                        else -> 16.sp
                    },
                    color = Ink, textAlign = TextAlign.Center, lineHeight = 28.sp
                )
                Box(Modifier.width(28.dp).height(3.dp).clip(RoundedCornerShape(50)).background(Gold))
                if (vocab.pron.isNotBlank()) {
                    Text(
                        vocab.pron, style = AccentText, fontSize = 14.sp, color = color,
                        textAlign = TextAlign.Center, lineHeight = 17.sp
                    )
                }
            }
            Text(
                "toucher pour retourner", fontSize = 10.sp, color = InkSoft,
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        } else {
            Column(
                Modifier.fillMaxSize().graphicsLayer { rotationY = 180f },
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(5.dp, Alignment.CenterVertically)
            ) {
                Text(
                    vocab.translation, style = PosterTitle, fontSize = 18.sp, color = Gold,
                    textAlign = TextAlign.Center, lineHeight = 21.sp
                )
                Text(vocab.example, fontSize = 13.sp, color = Color.White, textAlign = TextAlign.Center, lineHeight = 17.sp)
                if (vocab.examplePron.isNotBlank()) {
                    Text(
                        vocab.examplePron, style = AccentText, fontSize = 11.sp,
                        color = Color.White.copy(alpha = 0.9f), textAlign = TextAlign.Center, lineHeight = 14.sp
                    )
                }
                Text(
                    vocab.exampleTr, fontSize = 11.sp, color = Color.White.copy(alpha = 0.75f),
                    textAlign = TextAlign.Center, lineHeight = 14.sp
                )
            }
        }
    }
}

// ------------------------------------------------------------- Avatars dialogue

@Composable
fun Avatar(user: Boolean, color: Color) {
    Box(
        Modifier.size(38.dp).clip(CircleShape)
            .background(if (user) color.copy(alpha = 0.15f) else Night),
        contentAlignment = Alignment.Center
    ) {
        LineIcon(
            if (user) Art.avYou else Art.avTeacher,
            if (user) color else Color.White, 32.dp, accent = if (user) Ruby else Gold
        )
    }
}

/** En-tête d'écran de réglages : grand titre + dessin lineart. */
@Composable
fun ScreenHero(title: String, subtitle: String, drawing: LineDrawing, theme: PosterTheme) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(26.dp))
            .background(Brush.linearGradient(listOf(theme.start, theme.end)))
            .waxPattern(alpha = 0.08f)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, style = PosterTitle, fontSize = 22.sp, color = Color.White, lineHeight = 25.sp)
            Text(subtitle, style = AccentText, fontSize = 14.sp, color = theme.accent, lineHeight = 18.sp)
        }
        LineArt(drawing, Modifier.size(78.dp), color = Color.White, accent = theme.accent, strokeWidth = 2.dp)
    }
}

/** Ligne de choix avec pastille ronde (remplace les boutons radio en émoji). */
@Composable
fun ChoiceRow(label: String, selected: Boolean, color: Color = Navy, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) color.copy(alpha = 0.10f) else Color.Transparent, label = "choice")
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(bg).clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            Modifier.size(20.dp).clip(CircleShape).border(2.dp, if (selected) color else InkSoft, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            if (selected) Box(Modifier.size(10.dp).clip(CircleShape).background(Gold))
        }
        Text(
            label, fontSize = 14.sp, color = Ink, lineHeight = 18.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
        )
    }
}

/** Message d'état avec icône (succès, erreur, info) à la place des émojis. */
@Composable
fun StatusLine(text: String, kind: Int = 0) {
    val (icon, color) = when (kind) {
        1 -> Art.icCheck to Good
        -1 -> Art.icCross to Bad
        else -> Art.icBulb to Navy
    }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        LineIcon(icon, color, 16.dp)
        Text(text, fontSize = 13.sp, color = if (kind == -1) Bad else Ink, lineHeight = 17.sp)
    }
}

/** Affiche un message d'état en devinant son type d'après son préfixe (« OK: » / « ERR: »). */
@Composable
fun AutoStatus(message: String) {
    when {
        message.startsWith("OK:") -> StatusLine(message.removePrefix("OK:").trim(), 1)
        message.startsWith("ERR:") -> StatusLine(message.removePrefix("ERR:").trim(), -1)
        else -> StatusLine(message, 0)
    }
}
