package com.linguavibe.app.speech

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/** Réglages de la voix réaliste ElevenLabs, enregistrés sur le téléphone. */
class VoiceSettings(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("voice", Context.MODE_PRIVATE)

    var enabled by mutableStateOf(sp.getBoolean("enabled", false))
        private set
    var apiKey by mutableStateOf(sp.getString("apiKey", "") ?: "")
        private set
    var voiceId by mutableStateOf(sp.getString("voiceId", "") ?: "")
        private set
    var voiceName by mutableStateOf(sp.getString("voiceName", "") ?: "")
        private set
    var model by mutableStateOf(sp.getString("model", ElevenLabs.MODEL_QUALITY) ?: ElevenLabs.MODEL_QUALITY)
        private set

    /** Vrai si la voix ElevenLabs peut être utilisée. */
    val ready: Boolean get() = enabled && apiKey.isNotBlank() && voiceId.isNotBlank()

    /** Moteur de voix préféré : auto, kokoro, piper, eleven ou android. */
    var engine by mutableStateOf(sp.getString("engine", ENGINE_AUTO) ?: ENGINE_AUTO)
        private set

    /** Voix masculine pour Kokoro (sinon féminine). */
    var kokoroMale by mutableStateOf(sp.getBoolean("kokoroMale", false))
        private set

    fun updateEngine(value: String) {
        engine = value
        sp.edit().putString("engine", value).apply()
    }

    fun updateKokoroMale(value: Boolean) {
        kokoroMale = value
        sp.edit().putBoolean("kokoroMale", value).apply()
    }

    companion object {
        const val ENGINE_AUTO = "auto"
        const val ENGINE_KOKORO = "kokoro"
        const val ENGINE_PIPER = "piper"
        const val ENGINE_ELEVEN = "eleven"
        const val ENGINE_ANDROID = "android"
    }

    fun updateEnabled(value: Boolean) {
        enabled = value
        sp.edit().putBoolean("enabled", value).apply()
    }

    fun updateApiKey(value: String) {
        apiKey = value.trim()
        sp.edit().putString("apiKey", apiKey).apply()
    }

    fun updateVoice(id: String, name: String) {
        voiceId = id.trim()
        voiceName = name
        sp.edit().putString("voiceId", voiceId).putString("voiceName", name).apply()
    }

    fun updateModel(value: String) {
        model = value
        sp.edit().putString("model", value).apply()
    }
}

data class ElevenVoice(val id: String, val name: String, val category: String)

/** Client minimal de l'API ElevenLabs (synthèse vocale + liste des voix). */
object ElevenLabs {
    const val MODEL_QUALITY = "eleven_multilingual_v2"
    const val MODEL_FAST = "eleven_flash_v2_5"
    private const val BASE = "https://api.elevenlabs.io"

    private fun cacheDir(context: Context): File = File(context.filesDir, "tts").apply { mkdirs() }

    fun cacheSizeMb(context: Context): Long =
        cacheDir(context).listFiles()?.sumOf { it.length() }?.div(1024 * 1024) ?: 0

    fun clearCache(context: Context) {
        cacheDir(context).listFiles()?.forEach { it.delete() }
    }

    private fun sha1(text: String): String =
        MessageDigest.getInstance("SHA-1").digest(text.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }

    private fun errorMessage(connection: HttpURLConnection): String {
        val code = connection.responseCode
        val body = try {
            connection.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        } catch (_: Exception) {
            ""
        }
        val detail = try {
            val d = JSONObject(body).opt("detail")
            if (d is JSONObject) d.optString("message") else d?.toString() ?: ""
        } catch (_: Exception) {
            ""
        }
        return when (code) {
            401 -> "Clé API ElevenLabs refusée. Vérifiez-la dans Paramètres."
            429 -> "Quota ElevenLabs dépassé ou trop de demandes."
            else -> "ElevenLabs : erreur $code" + if (detail.isNotBlank()) " ($detail)" else ""
        }
    }

    /**
     * Renvoie le fichier MP3 de la phrase. Chaque phrase n'est demandée qu'une fois :
     * elle est ensuite relue depuis le téléphone, sans consommer de crédits.
     */
    suspend fun speechFile(
        context: Context,
        apiKey: String,
        voiceId: String,
        model: String,
        text: String,
        languageCode: String
    ): File = withContext(Dispatchers.IO) {
        val file = File(cacheDir(context), sha1("$voiceId|$model|$languageCode|$text") + ".mp3")
        if (file.length() > 0) return@withContext file

        val connection = URL("$BASE/v1/text-to-speech/$voiceId?output_format=mp3_44100_128")
            .openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "POST"
            connection.connectTimeout = 15_000
            connection.readTimeout = 30_000
            connection.doOutput = true
            connection.setRequestProperty("xi-api-key", apiKey)
            connection.setRequestProperty("Content-Type", "application/json")
            connection.setRequestProperty("Accept", "audio/mpeg")
            val body = JSONObject().put("text", text).put("model_id", model)
            // Le modèle rapide accepte un code de langue ; le modèle de qualité la détecte seul.
            if (model == MODEL_FAST) body.put("language_code", languageCode)
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            if (connection.responseCode !in 200..299) throw IllegalStateException(errorMessage(connection))
            val tmp = File(file.path + ".part")
            connection.inputStream.use { input -> tmp.outputStream().use { input.copyTo(it) } }
            if (tmp.length() == 0L || !tmp.renameTo(file)) {
                tmp.delete()
                throw IllegalStateException("ElevenLabs : réponse audio vide")
            }
            file
        } finally {
            connection.disconnect()
        }
    }

    /** Liste les voix disponibles sur le compte. */
    suspend fun listVoices(apiKey: String): List<ElevenVoice> = withContext(Dispatchers.IO) {
        val connection = URL("$BASE/v2/voices?page_size=100").openConnection() as HttpURLConnection
        try {
            connection.connectTimeout = 15_000
            connection.readTimeout = 20_000
            connection.setRequestProperty("xi-api-key", apiKey)
            connection.setRequestProperty("Accept", "application/json")
            if (connection.responseCode !in 200..299) throw IllegalStateException(errorMessage(connection))
            val text = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val array = JSONObject(text).getJSONArray("voices")
            (0 until array.length()).map { array.getJSONObject(it) }.map {
                ElevenVoice(it.getString("voice_id"), it.optString("name", "Voix"), it.optString("category", ""))
            }
        } finally {
            connection.disconnect()
        }
    }
}
