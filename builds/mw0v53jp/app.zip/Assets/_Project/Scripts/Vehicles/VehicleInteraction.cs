using AbidjanOpenWorld.CameraSystem;
using AbidjanOpenWorld.Player;
using UnityEngine;

namespace AbidjanOpenWorld.Vehicles
{
    public sealed class VehicleInteraction : MonoBehaviour
    {
        [SerializeField] private PlayerController player;
        [SerializeField] private ThirdPersonCamera followCamera;
        [SerializeField] private float interactionRadius = 3f;
        private VehicleController currentVehicle;
        private Renderer[] playerRenderers;

        private void Awake()
        {
            if (player == null) player = GetComponent<PlayerController>();
            playerRenderers = GetComponentsInChildren<Renderer>(true);
        }

        private void Update()
        {
#if UNITY_EDITOR || UNITY_STANDALONE
            if (Input.GetKeyDown(KeyCode.E)) Interact();
#endif
        }

        public void Interact()
        {
            if (currentVehicle != null) ExitVehicle();
            else EnterNearestVehicle();
        }

        private void EnterNearestVehicle()
        {
            VehicleController nearest = null;
            float bestDistance = interactionRadius;
            foreach (var vehicle in FindObjectsByType<VehicleController>(FindObjectsSortMode.None))
            {
                float distance = Vector3.Distance(transform.position, vehicle.transform.position);
                if (distance < bestDistance && !vehicle.IsOccupied)
                {
                    bestDistance = distance;
                    nearest = vehicle;
                }
            }
            if (nearest == null) return;

            currentVehicle = nearest;
            currentVehicle.SetOccupied(true);
            player.SetControlsEnabled(false);
            var characterController = player.GetComponent<CharacterController>();
            if (characterController != null) characterController.enabled = false;
            foreach (var renderer in playerRenderers) renderer.enabled = false;
            followCamera?.SetTarget(currentVehicle.CameraAnchor);
        }

        private void ExitVehicle()
        {
            Vector3 exitPosition = currentVehicle.transform.position + currentVehicle.transform.right * 2f + Vector3.up * 0.2f;
            transform.position = exitPosition;
            currentVehicle.SetOccupied(false);
            currentVehicle = null;
            foreach (var renderer in playerRenderers) renderer.enabled = true;
            var characterController = player.GetComponent<CharacterController>();
            if (characterController != null) characterController.enabled = true;
            player.SetControlsEnabled(true);
            followCamera?.SetTarget(player.transform);
        }
    }
}
