using AbidjanOpenWorld.UI;
using UnityEngine;

namespace AbidjanOpenWorld.Vehicles
{
    [RequireComponent(typeof(Rigidbody))]
    public sealed class VehicleController : MonoBehaviour
    {
        [Header("Vehicle tuning")]
        [SerializeField] private float acceleration = 18f;
        [SerializeField] private float reverseAcceleration = 9f;
        [SerializeField] private float steeringDegreesPerSecond = 85f;
        [SerializeField] private float maxSpeed = 28f;
        [SerializeField] private float brakeStrength = 12f;
        [SerializeField] private Transform cameraAnchor;
        [SerializeField] private MobileInputHub mobileInput;
        private Rigidbody body;
        public bool IsOccupied { get; private set; }
        public Transform CameraAnchor => cameraAnchor != null ? cameraAnchor : transform;
        public float SpeedKmh => body != null ? body.velocity.magnitude * 3.6f : 0f;

        private void Awake()
        {
            body = GetComponent<Rigidbody>();
            body.centerOfMass = new Vector3(0f, -0.45f, 0f);
            body.interpolation = RigidbodyInterpolation.Interpolate;
            body.constraints = RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationZ;
        }

        public void SetOccupied(bool occupied) => IsOccupied = occupied;

        private void FixedUpdate()
        {
            if (!IsOccupied) return;
            float steer = mobileInput != null ? mobileInput.VehicleSteering.x : 0f;
            float throttle = mobileInput != null && mobileInput.IsAccelerating ? 1f : 0f;
            bool braking = mobileInput != null && mobileInput.IsBraking;
            bool handbrake = mobileInput != null && mobileInput.IsHandbraking;
#if UNITY_EDITOR || UNITY_STANDALONE
            if (Mathf.Abs(steer) < 0.01f) steer = Input.GetAxisRaw("Horizontal");
            if (Mathf.Abs(throttle) < 0.01f) throttle = Input.GetAxisRaw("Vertical");
            braking |= Input.GetKey(KeyCode.Space);
            handbrake |= Input.GetKey(KeyCode.LeftShift);
#endif
            float forwardSpeed = Vector3.Dot(body.velocity, transform.forward);
            if (Mathf.Abs(forwardSpeed) < maxSpeed || Mathf.Sign(throttle) != Mathf.Sign(forwardSpeed))
            {
                float force = throttle >= 0f ? acceleration : reverseAcceleration;
                body.AddForce(transform.forward * throttle * force, ForceMode.Acceleration);
            }
            if (braking) body.AddForce(-body.velocity.normalized * brakeStrength, ForceMode.Acceleration);
            if (handbrake) body.velocity = Vector3.Lerp(body.velocity, Vector3.zero, 0.025f);

            float steeringFactor = Mathf.Clamp01(body.velocity.magnitude / 3f);
            float turn = steer * steeringDegreesPerSecond * steeringFactor * Time.fixedDeltaTime;
            if (Mathf.Abs(forwardSpeed) > 0.25f)
                body.MoveRotation(body.rotation * Quaternion.Euler(0f, turn * Mathf.Sign(forwardSpeed), 0f));
        }
    }
}
