using UnityEngine;

namespace AbidjanOpenWorld.CameraSystem
{
    public sealed class ThirdPersonCamera : MonoBehaviour
    {
        [SerializeField] private Transform target;
        [SerializeField] private Vector3 offset = new Vector3(0f, 2.8f, -5.5f);
        [SerializeField] private float followSharpness = 12f;
        [SerializeField] private float lookHeight = 1.4f;
        [SerializeField] private float mouseSensitivity = 3f;
        [SerializeField] private float minPitch = -15f;
        [SerializeField] private float maxPitch = 65f;
        private float yaw;
        private float pitch = 12f;

        public void SetTarget(Transform newTarget) => target = newTarget;

        private void LateUpdate()
        {
            if (target == null) return;
#if UNITY_EDITOR || UNITY_STANDALONE
            if (Input.GetMouseButton(1))
            {
                yaw += Input.GetAxis("Mouse X") * mouseSensitivity;
                pitch -= Input.GetAxis("Mouse Y") * mouseSensitivity;
            }
#endif
            pitch = Mathf.Clamp(pitch, minPitch, maxPitch);
            var rotation = Quaternion.Euler(pitch, yaw + target.eulerAngles.y, 0f);
            var desiredPosition = target.position + rotation * offset;
            transform.position = Vector3.Lerp(transform.position, desiredPosition, 1f - Mathf.Exp(-followSharpness * Time.deltaTime));
            transform.rotation = Quaternion.LookRotation(target.position + Vector3.up * lookHeight - transform.position, Vector3.up);
        }
    }
}
