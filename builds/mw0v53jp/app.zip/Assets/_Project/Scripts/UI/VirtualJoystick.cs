using UnityEngine;
using UnityEngine.EventSystems;

namespace AbidjanOpenWorld.UI
{
    public sealed class VirtualJoystick : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
    {
        [SerializeField] private RectTransform handle;
        [SerializeField, Range(0.1f, 1f)] private float handleRange = 0.65f;
        public Vector2 Value { get; private set; }

        public void OnPointerDown(PointerEventData eventData) => OnDrag(eventData);

        public void OnDrag(PointerEventData eventData)
        {
            var rect = (RectTransform)transform;
            if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(rect, eventData.position,
                    eventData.pressEventCamera, out var localPoint)) return;

            var half = rect.rect.size * 0.5f;
            var normalized = new Vector2(
                half.x > 0 ? localPoint.x / half.x : 0,
                half.y > 0 ? localPoint.y / half.y : 0);
            Value = Vector2.ClampMagnitude(normalized, 1f);
            if (handle != null)
                handle.anchoredPosition = new Vector2(Value.x * half.x * handleRange, Value.y * half.y * handleRange);
        }

        public void OnPointerUp(PointerEventData eventData) => ResetJoystick();

        private void OnDisable() => ResetJoystick();

        private void ResetJoystick()
        {
            Value = Vector2.zero;
            if (handle != null) handle.anchoredPosition = Vector2.zero;
        }
    }
}
