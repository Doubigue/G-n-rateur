using AbidjanOpenWorld.Vehicles;
using UnityEngine;
using UnityEngine.EventSystems;

namespace AbidjanOpenWorld.UI
{
    public sealed class MobileInteractButton : MonoBehaviour, IPointerDownHandler
    {
        [SerializeField] private VehicleInteraction vehicleInteraction;
        public void SetTarget(VehicleInteraction target) => vehicleInteraction = target;
        public void OnPointerDown(PointerEventData eventData) => vehicleInteraction?.Interact();
    }
}
