using UnityEngine;

namespace AbidjanOpenWorld.UI
{
    public sealed class MobileInputHub : MonoBehaviour
    {
        public VirtualJoystick movement;
        public VirtualJoystick vehicleSteering;
        public HoldButton run;
        public HoldButton accelerate;
        public HoldButton brake;
        public HoldButton handbrake;

        public Vector2 Movement => movement != null ? movement.Value : Vector2.zero;
        public Vector2 VehicleSteering => vehicleSteering != null ? vehicleSteering.Value : Vector2.zero;
        public bool IsRunning => run != null && run.IsHeld;
        public bool IsAccelerating => accelerate != null && accelerate.IsHeld;
        public bool IsBraking => brake != null && brake.IsHeld;
        public bool IsHandbraking => handbrake != null && handbrake.IsHeld;
    }
}
