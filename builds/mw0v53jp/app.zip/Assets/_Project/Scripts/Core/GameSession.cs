using AbidjanOpenWorld.Save;
using UnityEngine;

namespace AbidjanOpenWorld.Core
{
    public sealed class GameSession : MonoBehaviour
    {
        [SerializeField] private Transform player;
        [SerializeField] private float autosaveInterval = 60f;
        private float saveTimer;

        private void Start()
        {
            GameSave.RestorePlayerPosition(player);
        }

        private void Update()
        {
            saveTimer += Time.deltaTime;
            if (saveTimer >= autosaveInterval)
            {
                saveTimer = 0f;
                GameSave.SavePlayerPosition(player);
            }
        }

        private void OnApplicationPause(bool paused)
        {
            if (paused) GameSave.SavePlayerPosition(player);
        }

        private void OnApplicationQuit() => GameSave.SavePlayerPosition(player);
    }
}
