using UnityEngine;
using UnityEngine.SceneManagement;

namespace AbidjanOpenWorld.Core
{
    public sealed class MainMenuController : MonoBehaviour
    {
        public void StartGame() => SceneManager.LoadScene("GameWorld");
        public void QuitGame() => Application.Quit();
    }
}
