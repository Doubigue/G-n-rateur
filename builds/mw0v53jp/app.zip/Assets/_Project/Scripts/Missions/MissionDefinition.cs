using UnityEngine;

namespace AbidjanOpenWorld.Missions
{
    [CreateAssetMenu(menuName = "Abidjan Open World/Mission", fileName = "Mission_")]
    public sealed class MissionDefinition : ScriptableObject
    {
        public string missionId = "mission_001";
        public string displayName = "Première course";
        [TextArea] public string description = "Rejoindre le point indiqué.";
        public int rewardMoney = 250;
        public Vector3 objectivePosition;
        public float objectiveRadius = 5f;
    }
}
