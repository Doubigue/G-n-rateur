using UnityEngine;
using AbidjanOpenWorld.Save;

namespace AbidjanOpenWorld.Missions
{
    public sealed class MissionManager : MonoBehaviour
    {
        [SerializeField] private MissionDefinition activeMission;
        [SerializeField] private Transform player;
        public bool IsMissionActive { get; private set; }
        public string CurrentObjective => activeMission != null ? activeMission.description : string.Empty;
        public event System.Action<MissionDefinition> MissionCompleted;

        private void Start()
        {
            IsMissionActive = activeMission != null;
        }

        public void StartMission(MissionDefinition mission)
        {
            activeMission = mission;
            IsMissionActive = activeMission != null;
        }

        private void Update()
        {
            if (!IsMissionActive || activeMission == null || player == null) return;
            if (Vector3.Distance(player.position, activeMission.objectivePosition) <= activeMission.objectiveRadius)
                CompleteMission();
        }

        private void CompleteMission()
        {
            IsMissionActive = false;
            GameSave.Current.money += activeMission.rewardMoney;
            MissionCompleted?.Invoke(activeMission);
            GameSave.Save();
            activeMission = null;
        }
    }
}
