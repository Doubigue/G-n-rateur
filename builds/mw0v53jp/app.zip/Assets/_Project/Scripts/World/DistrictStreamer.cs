using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace AbidjanOpenWorld.World
{
    [System.Serializable]
    public sealed class DistrictScene
    {
        public string sceneName;
        public Transform center;
        public float loadDistance = 450f;
        public float unloadDistance = 600f;
    }

    public sealed class DistrictStreamer : MonoBehaviour
    {
        [SerializeField] private Transform player;
        [SerializeField] private List<DistrictScene> districts = new List<DistrictScene>();
        [SerializeField, Min(0.5f)] private float checkInterval = 2f;
        private readonly HashSet<string> busyScenes = new HashSet<string>();

        private IEnumerator Start()
        {
            while (true)
            {
                if (player != null)
                {
                    foreach (var district in districts)
                    {
                        if (district == null || string.IsNullOrWhiteSpace(district.sceneName) || district.center == null) continue;
                        float distance = Vector3.Distance(player.position, district.center.position);
                        bool loaded = SceneIsLoaded(district.sceneName);
                        if (!loaded && distance <= district.loadDistance) yield return LoadDistrict(district.sceneName);
                        else if (loaded && distance >= district.unloadDistance) yield return UnloadDistrict(district.sceneName);
                    }
                }
                yield return new WaitForSeconds(checkInterval);
            }
        }

        private bool SceneIsLoaded(string sceneName)
        {
            var scene = SceneManager.GetSceneByName(sceneName);
            return scene.IsValid() && scene.isLoaded;
        }

        private IEnumerator LoadDistrict(string sceneName)
        {
            if (!busyScenes.Add(sceneName)) yield break;
            var operation = SceneManager.LoadSceneAsync(sceneName, LoadSceneMode.Additive);
            if (operation != null) while (!operation.isDone) yield return null;
            busyScenes.Remove(sceneName);
        }

        private IEnumerator UnloadDistrict(string sceneName)
        {
            if (!busyScenes.Add(sceneName)) yield break;
            var scene = SceneManager.GetSceneByName(sceneName);
            if (scene.IsValid() && scene.isLoaded)
            {
                var operation = SceneManager.UnloadSceneAsync(scene);
                if (operation != null) while (!operation.isDone) yield return null;
            }
            busyScenes.Remove(sceneName);
        }
    }
}
