using System;
using System.IO;
using UnityEngine;

namespace AbidjanOpenWorld.Save
{
    [Serializable]
    public sealed class SaveData
    {
        public int money = 500;
        public string lastDistrict = "District_Cocody";
        public float playerX;
        public float playerY;
        public float playerZ;
        public string[] completedMissionIds = Array.Empty<string>();
    }

    public static class GameSave
    {
        private const string FileName = "abidjan_open_world_save.json";
        private static SaveData current;
        public static SaveData Current => current ??= LoadInternal();
        private static string FilePath => Path.Combine(Application.persistentDataPath, FileName);

        public static void Save()
        {
            try { File.WriteAllText(FilePath, JsonUtility.ToJson(Current, true)); }
            catch (Exception exception) { Debug.LogError($"Save failed: {exception.Message}"); }
        }

        public static void SavePlayerPosition(Transform player)
        {
            if (player == null) return;
            Current.playerX = player.position.x;
            Current.playerY = player.position.y;
            Current.playerZ = player.position.z;
            Save();
        }

        public static void RestorePlayerPosition(Transform player)
        {
            if (player == null) return;
            var data = Current;
            if (data.playerX == 0f && data.playerY == 0f && data.playerZ == 0f) return;
            player.position = new Vector3(data.playerX, data.playerY, data.playerZ);
        }

        private static SaveData LoadInternal()
        {
            try { return File.Exists(FilePath) ? JsonUtility.FromJson<SaveData>(File.ReadAllText(FilePath)) ?? new SaveData() : new SaveData(); }
            catch (Exception exception) { Debug.LogWarning($"Save load failed: {exception.Message}"); return new SaveData(); }
        }
    }
}
