using AbidjanOpenWorld.UI;
using UnityEngine;

namespace AbidjanOpenWorld.Player
{
    [RequireComponent(typeof(CharacterController))]
    public sealed class PlayerController : MonoBehaviour
    {
        [SerializeField] private Transform cameraTransform;
        [SerializeField] private MobileInputHub mobileInput;
        [SerializeField] private float walkSpeed = 4.2f;
        [SerializeField] private float runSpeed = 6.5f;
        [SerializeField] private float rotationSpeed = 14f;
        [SerializeField] private float jumpHeight = 1.1f;
        [SerializeField] private float gravity = -22f;
        private CharacterController controller;
        private Vector3 verticalVelocity;
        private bool controlsEnabled = true;

        public bool ControlsEnabled => controlsEnabled;

        private void Awake()
        {
            controller = GetComponent<CharacterController>();
            if (cameraTransform == null && UnityEngine.Camera.main != null)
                cameraTransform = UnityEngine.Camera.main.transform;
        }

        private void Update()
        {
            if (!controlsEnabled || !controller.enabled) return;
            Vector2 input = mobileInput != null ? mobileInput.Movement : Vector2.zero;
#if UNITY_EDITOR || UNITY_STANDALONE
            if (input.sqrMagnitude < 0.01f)
                input = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
#endif
            input = Vector2.ClampMagnitude(input, 1f);
            Vector3 forward = cameraTransform != null ? Vector3.ProjectOnPlane(cameraTransform.forward, Vector3.up).normalized : transform.forward;
            Vector3 right = cameraTransform != null ? Vector3.ProjectOnPlane(cameraTransform.right, Vector3.up).normalized : transform.right;
            Vector3 move = forward * input.y + right * input.x;
            bool running = mobileInput != null && mobileInput.IsRunning;
#if UNITY_EDITOR || UNITY_STANDALONE
            running |= Input.GetKey(KeyCode.LeftShift);
#endif
            float speed = running ? runSpeed : walkSpeed;
            controller.Move(move * speed * Time.deltaTime);

            if (controller.isGrounded && verticalVelocity.y < 0f) verticalVelocity.y = -2f;
#if UNITY_EDITOR || UNITY_STANDALONE
            if (controller.isGrounded && Input.GetButtonDown("Jump")) verticalVelocity.y = Mathf.Sqrt(jumpHeight * -2f * gravity);
#endif
            verticalVelocity.y += gravity * Time.deltaTime;
            controller.Move(verticalVelocity * Time.deltaTime);

            if (move.sqrMagnitude > 0.01f)
            {
                var targetRotation = Quaternion.LookRotation(move.normalized, Vector3.up);
                transform.rotation = Quaternion.Slerp(transform.rotation, targetRotation, rotationSpeed * Time.deltaTime);
            }
        }

        public void SetControlsEnabled(bool enabled)
        {
            controlsEnabled = enabled;
            if (!enabled) verticalVelocity = Vector3.zero;
        }
    }
}
