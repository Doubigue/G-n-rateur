#if UNITY_EDITOR
using AbidjanOpenWorld.CameraSystem;
using AbidjanOpenWorld.Core;
using AbidjanOpenWorld.Missions;
using AbidjanOpenWorld.Player;
using AbidjanOpenWorld.UI;
using AbidjanOpenWorld.Vehicles;
using AbidjanOpenWorld.World;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace AbidjanOpenWorld.EditorTools
{
    public static class ProjectScaffoldBuilder
    {
        private const string SceneFolder = "Assets/_Project/Scenes";

        [MenuItem("Abidjan Open World/1 - Generate starter scenes")]
        public static void GenerateScenes()
        {
            PrepareForBuild();
            EditorUtility.DisplayDialog("Abidjan Open World", "Starter scenes created. Open GameWorld to inspect the prototype.", "OK");
        }

        [MenuItem("Abidjan Open World/2 - Configure Android player settings")]
        public static void ConfigureAndroid()
        {
            ConfigureAndroidSettings();
            EditorUtility.DisplayDialog("Android settings", "Android target configured for ARM64 / IL2CPP / landscape. Review Player Settings and signing before release.", "OK");
        }

        private static void ConfigureAndroidSettings()
        {
            PlayerSettings.productName = "Abidjan Open World";
            PlayerSettings.companyName = "Independent Studio";
            PlayerSettings.SetApplicationIdentifier(BuildTargetGroup.Android, "com.independentstudio.abidjanopenworld");
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.LandscapeLeft;
            PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel26;
            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
            PlayerSettings.SetScriptingBackend(BuildTargetGroup.Android, ScriptingImplementation.IL2CPP);
            PlayerSettings.stripEngineCode = true;
            PlayerSettings.SetApiCompatibilityLevel(BuildTargetGroup.Android, ApiCompatibilityLevel.NET_Standard_2_1);
            EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Android, BuildTarget.Android);
            Debug.Log("Android settings configured automatically for CI build.");
        }

        private static void CreateGameWorld()
        {
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            scene.name = "GameWorld";
            RenderSettings.ambientLight = new Color(0.48f, 0.50f, 0.53f);
            RenderSettings.fog = true;
            RenderSettings.fogColor = new Color(0.62f, 0.68f, 0.72f);
            RenderSettings.fogMode = FogMode.Linear;
            RenderSettings.fogStartDistance = 100f;
            RenderSettings.fogEndDistance = 420f;

            var lightObject = new GameObject("Sun - Baked or Mixed");
            var light = lightObject.AddComponent<Light>();
            light.type = LightType.Directional;
            light.intensity = 1.15f;
            lightObject.transform.rotation = Quaternion.Euler(48f, -32f, 0f);

            var ground = GameObject.CreatePrimitive(PrimitiveType.Plane);
            ground.name = "Prototype Ground - replace with authored terrain";
            ground.transform.localScale = new Vector3(12f, 1f, 12f);
            ground.GetComponent<Renderer>().sharedMaterial = MakeMaterial("Ground_Mat", new Color(0.28f, 0.34f, 0.27f));

            CreateRoad(new Vector3(0f, 0.03f, 0f), new Vector3(18f, 0.08f, 180f), "Boulevard Principal");
            CreateRoad(new Vector3(0f, 0.04f, 0f), new Vector3(180f, 0.08f, 18f), "Boulevard Transversal");
            CreateBuilding(new Vector3(-28f, 5f, 35f), new Vector3(18f, 10f, 22f), "Immeuble Plateau A");
            CreateBuilding(new Vector3(32f, 8f, 30f), new Vector3(20f, 16f, 24f), "Immeuble Plateau B");
            CreateBuilding(new Vector3(-34f, 3f, -35f), new Vector3(16f, 6f, 18f), "Maison Cocody");
            CreateBuilding(new Vector3(35f, 4f, -38f), new Vector3(20f, 8f, 20f), "Entrepot Zone Industrielle");

            var player = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            player.name = "Player - Prototype";
            player.tag = "Player";
            player.transform.position = new Vector3(0f, 1.2f, -12f);
            player.GetComponent<Renderer>().sharedMaterial = MakeMaterial("Player_Mat", new Color(0.12f, 0.25f, 0.55f));
            var capsuleCollider = player.GetComponent<CapsuleCollider>();
            Object.DestroyImmediate(capsuleCollider);
            var characterController = player.AddComponent<CharacterController>();
            characterController.height = 1.9f;
            characterController.radius = 0.38f;
            characterController.center = new Vector3(0f, 0.95f, 0f);
            var playerController = player.AddComponent<PlayerController>();

            var cameraObject = new GameObject("Main Camera");
            cameraObject.tag = "MainCamera";
            var camera = cameraObject.AddComponent<Camera>();
            camera.fieldOfView = 65f;
            camera.nearClipPlane = 0.1f;
            camera.farClipPlane = 650f;
            cameraObject.AddComponent<AudioListener>();
            var follow = cameraObject.AddComponent<ThirdPersonCamera>();
            follow.SetTarget(player.transform);

            var inputObject = new GameObject("MobileInputHub");
            var hub = inputObject.AddComponent<MobileInputHub>();
            playerController = player.GetComponent<PlayerController>();
            SetObjectReference(playerController, "cameraTransform", cameraObject.transform);
            SetObjectReference(playerController, "mobileInput", hub);

            var vehicle = GameObject.CreatePrimitive(PrimitiveType.Cube);
            vehicle.name = "Vehicle - Prototype Sedan";
            vehicle.transform.position = new Vector3(7f, 0.85f, -9f);
            vehicle.transform.localScale = new Vector3(2.1f, 1.2f, 4.2f);
            vehicle.GetComponent<Renderer>().sharedMaterial = MakeMaterial("Vehicle_Mat", new Color(0.65f, 0.12f, 0.08f));
            var vehicleCollider = vehicle.GetComponent<BoxCollider>();
            var rb = vehicle.AddComponent<Rigidbody>();
            rb.mass = 1250f;
            rb.drag = 0.15f;
            rb.angularDrag = 2f;
            var vehicleController = vehicle.AddComponent<VehicleController>();
            SetObjectReference(vehicleController, "mobileInput", hub);
            var cameraAnchor = new GameObject("CameraAnchor").transform;
            cameraAnchor.SetParent(vehicle.transform, false);
            cameraAnchor.localPosition = new Vector3(0f, 1.2f, 0f);
            SetObjectReference(vehicleController, "cameraAnchor", cameraAnchor);

            var interaction = player.AddComponent<VehicleInteraction>();
            SetObjectReference(interaction, "player", playerController);
            SetObjectReference(interaction, "followCamera", follow);

            var session = new GameObject("GameSession").AddComponent<GameSession>();
            SetObjectReference(session, "player", player.transform);
            var streamer = new GameObject("DistrictStreamer").AddComponent<DistrictStreamer>();
            SetObjectReference(streamer, "player", player.transform);
            var missions = new GameObject("MissionManager").AddComponent<MissionManager>();
            SetObjectReference(missions, "player", player.transform);
            var mission = AssetDatabase.LoadAssetAtPath<MissionDefinition>("Assets/_Project/FirstMission.asset");
            if (mission == null)
            {
                mission = ScriptableObject.CreateInstance<MissionDefinition>();
                mission.missionId = "mission_first_delivery";
                mission.displayName = "Première livraison";
                mission.description = "Rejoindre le point de livraison près du boulevard.";
                mission.rewardMoney = 250;
                mission.objectivePosition = new Vector3(42f, 0f, 42f);
                mission.objectiveRadius = 7f;
                AssetDatabase.CreateAsset(mission, "Assets/_Project/FirstMission.asset");
            }
            SetObjectReference(missions, "activeMission", mission);

            CreateMobileHud(hub, interaction);
            EditorSceneManager.SaveScene(scene, SceneFolder + "/GameWorld.unity");
        }

        private static void CreateMainMenu()
        {
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            scene.name = "MainMenu";
            var canvasObject = new GameObject("MainMenuCanvas", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            var canvas = canvasObject.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            var scaler = canvasObject.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920, 1080);
            var title = CreateText(canvasObject.transform, "ABIDJAN OPEN WORLD", new Vector2(0.5f, 0.68f), new Vector2(900, 130), 64, TextAnchor.MiddleCenter);
            title.color = Color.white;
            var play = CreateButton(canvasObject.transform, "JOUER", new Vector2(0.5f, 0.42f), new Vector2(360, 100));
            var controller = new GameObject("MainMenuController").AddComponent<MainMenuController>();
            play.onClick.AddListener(controller.StartGame);
            EnsureEventSystem();
            EditorSceneManager.SaveScene(scene, SceneFolder + "/MainMenu.unity");
        }

        private static void CreateMobileHud(MobileInputHub hub, VehicleInteraction interaction)
        {
            var canvasObject = new GameObject("MobileHUD", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            var canvas = canvasObject.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            var scaler = canvasObject.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920, 1080);
            EnsureEventSystem();

            var joystickBase = CreateImage(canvasObject.transform, "MoveJoystick", new Vector2(0f, 0f), new Vector2(250, 250), new Vector2(0.12f, 0.16f));
            joystickBase.color = new Color(1f, 1f, 1f, 0.22f);
            var handle = CreateImage(joystickBase.transform, "Handle", new Vector2(0.5f, 0.5f), new Vector2(100, 100), new Vector2(0.5f, 0.5f));
            handle.color = new Color(1f, 1f, 1f, 0.6f);
            var moveJoystick = joystickBase.gameObject.AddComponent<VirtualJoystick>();
            SetObjectReference(moveJoystick, "handle", handle.rectTransform);
            hub.movement = moveJoystick;

            var steeringBase = CreateImage(canvasObject.transform, "SteeringJoystick", new Vector2(0.68f, 0f), new Vector2(210, 210), new Vector2(0.5f, 0.12f));
            steeringBase.color = new Color(1f, 1f, 1f, 0.16f);
            var steeringHandle = CreateImage(steeringBase.transform, "SteeringHandle", new Vector2(0.5f, 0.5f), new Vector2(86, 86), new Vector2(0.5f, 0.5f));
            steeringHandle.color = new Color(1f, 1f, 1f, 0.55f);
            var steeringJoystick = steeringBase.gameObject.AddComponent<VirtualJoystick>();
            SetObjectReference(steeringJoystick, "handle", steeringHandle.rectTransform);
            hub.vehicleSteering = steeringJoystick;

            var run = CreateHoldControl(canvasObject.transform, "RUN", new Vector2(0.84f, 0.16f), new Vector2(135, 135));
            var accelerate = CreateHoldControl(canvasObject.transform, "GO", new Vector2(0.94f, 0.16f), new Vector2(145, 145));
            var brake = CreateHoldControl(canvasObject.transform, "BRAKE", new Vector2(0.94f, 0.35f), new Vector2(145, 115));
            var handbrake = CreateHoldControl(canvasObject.transform, "HAND", new Vector2(0.84f, 0.35f), new Vector2(135, 115));
            hub.run = run;
            hub.accelerate = accelerate;
            hub.brake = brake;
            hub.handbrake = handbrake;

            var interact = CreateButton(canvasObject.transform, "ENTRER / SORTIR", new Vector2(0.79f, 0.42f), new Vector2(300, 90));
            interact.onClick.AddListener(interaction.Interact);
        }

        private static void AddScenesToBuildSettings()
        {
            EditorBuildSettings.scenes = new[]
            {
                new EditorBuildSettingsScene(SceneFolder + "/MainMenu.unity", true),
                new EditorBuildSettingsScene(SceneFolder + "/GameWorld.unity", true)
            };
        }

        private static void CreateRoad(Vector3 position, Vector3 scale, string name)
        {
            var road = GameObject.CreatePrimitive(PrimitiveType.Cube);
            road.name = name;
            road.transform.position = position;
            road.transform.localScale = scale;
            road.GetComponent<Renderer>().sharedMaterial = MakeMaterial(name + "_Mat", new Color(0.12f, 0.13f, 0.14f));
        }

        private static void CreateBuilding(Vector3 position, Vector3 scale, string name)
        {
            var building = GameObject.CreatePrimitive(PrimitiveType.Cube);
            building.name = name;
            building.transform.position = position;
            building.transform.localScale = scale;
            building.GetComponent<Renderer>().sharedMaterial = MakeMaterial(name + "_Mat", new Color(0.48f, 0.49f, 0.50f));
        }

        private static Material MakeMaterial(string name, Color color)
        {
            const string materialFolder = "Assets/_Project/Materials";
            if (!AssetDatabase.IsValidFolder(materialFolder)) AssetDatabase.CreateFolder("Assets/_Project", "Materials");
            string path = materialFolder + "/" + name + ".mat";
            var material = AssetDatabase.LoadAssetAtPath<Material>(path);
            if (material == null)
            {
                var shader = Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard");
                material = new Material(shader) { name = name };
                AssetDatabase.CreateAsset(material, path);
            }
            material.color = color;
            EditorUtility.SetDirty(material);
            return material;
        }

        private static Image CreateImage(Transform parent, string name, Vector2 anchor, Vector2 size, Vector2 pivot)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(CanvasRenderer), typeof(Image));
            go.transform.SetParent(parent, false);
            var rect = go.GetComponent<RectTransform>();
            rect.anchorMin = rect.anchorMax = anchor;
            rect.pivot = pivot;
            rect.anchoredPosition = Vector2.zero;
            rect.sizeDelta = size;
            return go.GetComponent<Image>();
        }

        private static HoldButton CreateHoldControl(Transform parent, string label, Vector2 anchor, Vector2 size)
        {
            var image = CreateImage(parent, label + "Button", anchor, size, new Vector2(0.5f, 0.5f));
            image.color = new Color(0.08f, 0.08f, 0.08f, 0.55f);
            var hold = image.gameObject.AddComponent<HoldButton>();
            var text = CreateText(image.transform, label, new Vector2(0.5f, 0.5f), size, 28, TextAnchor.MiddleCenter);
            text.color = Color.white;
            return hold;
        }

        private static Button CreateButton(Transform parent, string label, Vector2 anchor, Vector2 size)
        {
            var image = CreateImage(parent, label + "Button", anchor, size, new Vector2(0.5f, 0.5f));
            image.color = new Color(0.08f, 0.20f, 0.30f, 0.88f);
            var button = image.gameObject.AddComponent<Button>();
            var text = CreateText(image.transform, label, new Vector2(0.5f, 0.5f), size, 30, TextAnchor.MiddleCenter);
            text.color = Color.white;
            return button;
        }

        private static Text CreateText(Transform parent, string value, Vector2 anchor, Vector2 size, int fontSize, TextAnchor alignment)
        {
            var go = new GameObject("Text_" + value.Replace(" ", "_"), typeof(RectTransform), typeof(CanvasRenderer), typeof(Text));
            go.transform.SetParent(parent, false);
            var rect = go.GetComponent<RectTransform>();
            rect.anchorMin = rect.anchorMax = anchor;
            rect.pivot = anchor;
            rect.sizeDelta = size;
            rect.anchoredPosition = Vector2.zero;
            var text = go.GetComponent<Text>();
            text.text = value;
            text.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            text.fontSize = fontSize;
            text.alignment = alignment;
            text.horizontalOverflow = HorizontalWrapMode.Wrap;
            text.verticalOverflow = VerticalWrapMode.Overflow;
            return text;
        }

        private static void EnsureEventSystem()
        {
            if (Object.FindFirstObjectByType<EventSystem>() != null) return;
            new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));
        }

        private static void SetObjectReference(Object target, string propertyName, Object value)
        {
            var serialized = new SerializedObject(target);
            var property = serialized.FindProperty(propertyName);
            if (property != null) { property.objectReferenceValue = value; serialized.ApplyModifiedPropertiesWithoutUndo(); }
        }
    }
}
#endif
