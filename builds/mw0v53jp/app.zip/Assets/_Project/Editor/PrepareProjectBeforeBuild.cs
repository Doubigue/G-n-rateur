#if UNITY_EDITOR
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace AbidjanOpenWorld.EditorTools
{
    /// <summary>Creates the starter scenes and Android settings in batch mode before DroidForge builds.</summary>
    public sealed class PrepareProjectBeforeBuild : IPreprocessBuildWithReport
    {
        public int callbackOrder => -1000;

        public void OnPreprocessBuild(BuildReport report)
        {
            Debug.Log("[Abidjan Open World] Preparing scenes and Android settings for build...");
            ProjectScaffoldBuilder.PrepareForBuild();
            Debug.Log("[Abidjan Open World] Build preparation complete.");
        }
    }
}
#endif
