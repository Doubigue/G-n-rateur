# Abidjan Open World — projet Unity Android importable

Ce ZIP est un projet Unity 6 de démarrage pour un jeu solo 3D en monde ouvert inspiré d'Abidjan. Il contient les scripts runtime, le générateur de scènes, les paramètres Android et un crochet de préparation automatique avant compilation.

## Ce que le projet contient réellement

- Personnage prototype avec déplacement à la troisième personne.
- Caméra de suivi derrière le personnage.
- Voiture prototype arcade et interaction entrer/sortir.
- HUD tactile : joystick de déplacement, direction et boutons d'action.
- Ville blockout : routes, sol et bâtiments primitifs représentant Plateau, Cocody et zone industrielle.
- Mission de livraison de démonstration.
- Sauvegarde locale JSON.
- Base de chargement additif des quartiers.
- Configuration Android ARM64 / IL2CPP / paysage.
- Préparation automatique des scènes `MainMenu` et `GameWorld` lors d'une compilation Unity qui exécute les callbacks de build.

**Limite importante :** ce n'est pas un GTA complet ni un jeu photoréaliste terminé. Le personnage est une capsule, la voiture et les bâtiments sont des formes de prototype, et les systèmes trafic/PNJ/police ne sont pas encore implémentés. Le projet est un prototype compilable à compléter avec des modèles, animations et contenus 3D autorisés.

## Import direct dans Unity

1. Décompresser `AbidjanOpenWorldStarter.zip`.
2. Dans Unity Hub, choisir **Add > Add project from disk** et sélectionner le dossier `AbidjanOpenWorldStarter`.
3. Ouvrir avec Unity 6.0 (6000.0.x) et attendre l'installation de URP, UGUI et Test Framework.
4. Pour prévisualiser les scènes dans l'éditeur, lancer **Abidjan Open World > 1 - Generate starter scenes**.
5. Installer les modules Android Build Support, Android SDK & NDK Tools et OpenJDK via Unity Hub.
6. Vérifier la cible Android dans File > Build Profiles, puis lancer un build de test.

Le callback `PrepareProjectBeforeBuild` recrée les scènes et configure les paramètres Android juste avant le build. Pour vérifier visuellement le projet avant compilation, utiliser le menu de génération des scènes.

## Import dans DroidForge Studio

Le dossier de demande de build fourni séparément contient :

```text
builds/abidjan-open-world-v001/
  unity.json
  app.zip
```

`app.zip` contient le projet Unity. À la racine de ton dépôt DroidForge, fusionne le dossier `builds/` de ce package avec le dépôt qui contient déjà `.github/workflows/build-unity.yml`, puis pousse les fichiers sur GitHub. Le workflow fourni surveille l'ajout/modification de `builds/*/unity.json`.

Dans GitHub > Settings > Secrets and variables > Actions, configure la licence Unity requise par GameCI : `UNITY_LICENSE`, `UNITY_EMAIL` et éventuellement `UNITY_PASSWORD` selon la méthode de licence utilisée. Ne mets jamais de mot de passe ou keystore dans le ZIP.

Consulte l'onglet Actions et la GitHub Release pour récupérer l'APK si le workflow réussit.

## Réglages Android

- Identifiant : `com.independentstudio.abidjanopenworld` (à remplacer avant publication).
- Architecture : ARM64.
- Backend : IL2CPP.
- Orientation : paysage.
- Minimum : Android API 26.
- Le workflow fourni produit un APK de test. Pour Google Play, ajouter une signature release et une sortie AAB.

## À savoir avant compilation

La compilation n'a pas été exécutée dans cet environnement : aucun éditeur Unity ni licence Unity n'est disponible ici. La réussite finale dépend de la version Unity installée, des modules Android, de la licence GameCI et de la configuration exacte du dépôt DroidForge. Ce ZIP fournit les sources et la préparation de projet, pas un APK déjà compilé.
