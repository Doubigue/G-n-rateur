package com.linkshare.ui

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.content.ContextWrapper
import android.net.Uri
import android.os.Environment
import android.text.format.Formatter
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.decode.VideoFrameDecoder
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DateFormat
import java.util.Date

internal tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

private fun LItem.iconVec(): ImageVector = fileIcon(file, isDir)

private fun LItem.tint(): Color = fileTint(file, isDir)

private fun LItem.isPhoto() = !isDir && file.extension.lowercase() in VIEW_IMG

// ═══════════════════════════ Composants ═══════════════════════════

@Composable
internal fun Thumb(item: LItem, size: Dp = 52.dp) {
    if (item.isPhoto()) AsyncImage(
        item.file, null,
        Modifier.size(size).clip(RoundedCornerShape(size * 0.3f)).background(LS.Card), contentScale = ContentScale.Crop,
    ) else if (!item.isDir && item.file.hasContentPreview()) {
        // Document : aperçu du contenu (1re page d'un PDF, début d'un texte, Word, Excel…)
        DocThumb(item.file, Modifier.size(size).clip(RoundedCornerShape(size * 0.3f)), widthPx = 200) {
            IconBadge(item.iconVec(), item.tint(), size)
        }
    } else IconBadge(item.iconVec(), item.tint(), size)
}

/** Pastille ronde « coché » des éléments sélectionnés. */
@Composable
private fun CheckDot(modifier: Modifier = Modifier) {
    Box(modifier.size(22.dp).clip(CircleShape).background(LS.Blue), contentAlignment = Alignment.Center) {
        Icon(Ic.Check, "Sélectionné", Modifier.size(16.dp), tint = LS.OnBlue)
    }
}

/** Bouton « i » : ouvre les détails de l'élément sans passer par la sélection. */
@Composable
private fun InfoDot(item: LItem, ex: ExplorerViewModel, modifier: Modifier = Modifier) {
    Icon(
        Ic.Info, "Détails",
        modifier.clip(CircleShape).clickable { ex.showInfo(listOf(item.file)) }.padding(8.dp).size(20.dp),
        tint = LS.Muted,
    )
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun FileRow(item: LItem, ex: ExplorerViewModel) {
    val ctx = LocalContext.current
    val f = item.file
    val sel = f.path in ex.selected
    val showParent = ex.query.isNotBlank() || ex.category != null
    val shape = RoundedCornerShape(UiStyle.r(18.dp))
    val box = if (sel) Modifier.clip(shape).background(LS.BlueLight).border(1.5.dp, LS.Blue, shape) else Modifier.lsCard(shape)
    Row(
        Modifier.fillMaxWidth().then(box)
            .combinedClickable(
                onClick = { if (ex.selected.isNotEmpty()) ex.toggle(f.path) else ex.open(f) },
                onLongClick = { ex.toggle(f.path) },
            ).padding(start = 10.dp, top = 9.dp, bottom = 9.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Thumb(item, 48.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(f.name, color = LS.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val date = DateFormat.getDateInstance(DateFormat.SHORT).format(Date(item.modified))
            val sub = if (item.isDir) "${item.count} élément(s) · $date"
            else Formatter.formatShortFileSize(ctx, item.size) + " · " + date
            Text(
                if (showParent) sub + " · " + (f.parentFile?.name ?: "") else sub,
                color = LS.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
        if (sel) CheckDot(Modifier.padding(horizontal = 9.dp))
        else if (ex.selected.isEmpty()) InfoDot(item, ex)
        else Spacer(Modifier.width(40.dp))
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun FolderCell(item: LItem, ex: ExplorerViewModel, modifier: Modifier) {
    val f = item.file
    val sel = f.path in ex.selected
    val shape = RoundedCornerShape(UiStyle.r(22.dp))
    val box = if (sel) modifier.clip(shape).background(LS.BlueLight).border(1.5.dp, LS.Blue, shape) else modifier.lsCard(shape)
    Column(
        box.combinedClickable(
            onClick = { if (ex.selected.isNotEmpty()) ex.toggle(f.path) else ex.open(f) },
            onLongClick = { ex.toggle(f.path) },
        ).padding(start = 14.dp, top = 12.dp, bottom = 14.dp, end = 6.dp),
    ) {
        Row(Modifier.fillMaxWidth().height(52.dp), verticalAlignment = Alignment.Top) {
            IconBadge(Ic.Folder, LS.Blue, 52.dp)
            Spacer(Modifier.weight(1f))
            if (sel) CheckDot(Modifier.padding(top = 6.dp, end = 8.dp))
            else if (ex.selected.isEmpty()) InfoDot(item, ex)
        }
        Spacer(Modifier.height(10.dp))
        Text(
            f.name, Modifier.padding(end = 8.dp), color = LS.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
            maxLines = 1, overflow = TextOverflow.Ellipsis,
        )
        Text(
            "${item.count} élément(s) · " + DateFormat.getDateInstance(DateFormat.SHORT).format(Date(item.modified)),
            Modifier.padding(end = 8.dp), color = LS.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
        )
    }
}

/** Chargeur de miniatures qui sait aussi extraire une image d'une vidéo. */
@Composable
internal fun rememberThumbLoader(): ImageLoader {
    val ctx = LocalContext.current
    return remember { ImageLoader.Builder(ctx).components { add(VideoFrameDecoder.Factory()) }.crossfade(true).build() }
}

/** Fichier en vue grille : miniature pour les images et les vidéos, pastille colorée + nom + taille pour le reste. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun FileCell(item: LItem, ex: ExplorerViewModel, loader: ImageLoader, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val f = item.file
    val sel = f.path in ex.selected
    val ext = f.extension.lowercase()
    val cat = f.category()
    val video = cat == Category.VIDEOS
    val visual = ext in VIEW_IMG || ext == "heic" || video
    val shape = RoundedCornerShape(UiStyle.r(18.dp))
    val box = if (sel) modifier.aspectRatio(1f).clip(shape).background(LS.BlueLight).border(2.dp, LS.Blue, shape)
    else modifier.aspectRatio(1f).lsCard(shape)
    Box(
        box.combinedClickable(
            onClick = { if (ex.selected.isNotEmpty()) ex.toggle(f.path) else ex.open(f) },
            onLongClick = { ex.toggle(f.path) },
        ),
        contentAlignment = Alignment.Center,
    ) {
        if (visual) {
            // Vidéos : aperçu animé (plusieurs images de la vidéo en fondu + léger zoom)
            if (video) AnimatedVideoThumb(f, loader, Modifier.fillMaxSize())
            else AsyncImage(
                model = f, contentDescription = f.name, imageLoader = loader,
                modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop,
            )
            if (video) {
                val pulse = rememberInfiniteTransition(label = "pulse")
                val a by pulse.animateFloat(
                    0.55f, if (UiStyle.animations) 1f else 0.55f,
                    infiniteRepeatable(tween(1100), RepeatMode.Reverse), label = "playpulse",
                )
                Box(
                    Modifier.size(34.dp).graphicsLayer { scaleX = 0.9f + 0.1f * a; scaleY = 0.9f + 0.1f * a }
                        .clip(CircleShape).background(Color.Black.copy(alpha = 0.35f + 0.25f * a)),
                    contentAlignment = Alignment.Center,
                ) { Icon(Ic.Play, null, Modifier.size(20.dp), tint = Color.White) }
                Text(
                    f.extension.uppercase(),
                    Modifier.align(Alignment.BottomStart).padding(6.dp).clip(RoundedCornerShape(6.dp))
                        .background(Color(0x99000000)).padding(horizontal = 5.dp, vertical = 1.dp),
                    color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold,
                )
            }
        } else if (f.hasContentPreview()) {
            // Document : le contenu (1re page d'un PDF, début d'un texte, Word, Excel…) sert de miniature, le nom en bas
            DocThumb(f, Modifier.fillMaxSize()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { IconBadge(item.iconVec(), item.tint(), 40.dp) }
            }
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0.55f to Color.Transparent, 1f to Color(0xCC000000))))
            if (ext == "pdf") PdfBadge(Modifier.align(Alignment.TopStart).padding(6.dp))
            else Text(
                ext.uppercase(),
                Modifier.align(Alignment.TopStart).padding(6.dp).clip(RoundedCornerShape(6.dp))
                    .background(Color(0x99000000)).padding(horizontal = 5.dp, vertical = 1.dp),
                color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold,
            )
            Text(
                f.name, Modifier.align(Alignment.BottomStart).padding(horizontal = 7.dp, vertical = 5.dp),
                color = Color.White, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        } else {
            Column(
                Modifier.fillMaxSize().padding(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
            ) {
                IconBadge(item.iconVec(), item.tint(), 40.dp)
                Spacer(Modifier.height(6.dp))
                Text(
                    f.name, color = LS.Text, fontSize = 11.sp, maxLines = 1,
                    overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                )
                Text(Formatter.formatShortFileSize(ctx, item.size), color = LS.Muted, fontSize = 10.sp, maxLines = 1)
            }
        }
        if (sel) CheckDot(Modifier.align(Alignment.TopEnd).padding(6.dp))
    }
}

internal class BarAction(val label: String, val icon: ImageVector, val onClick: () -> Unit)

/**
 * Barre d'actions de la sélection. Les actions défilent horizontalement quand elles sont trop nombreuses ;
 * [onCancel], s'il est fourni, ajoute un bouton « Annuler » toujours visible à gauche.
 */
@Composable
internal fun SelectionBar(count: Int, actions: List<BarAction>, modifier: Modifier, onCancel: (() -> Unit)? = null) {
    Row(
        modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp).clip(RoundedCornerShape(22.dp))
            .background(LS.Blue).padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (onCancel != null) Column(
            Modifier.clip(RoundedCornerShape(10.dp)).clickable(onClick = onCancel).padding(horizontal = 8.dp, vertical = 2.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Icon(Ic.Close, "Annuler", Modifier.size(20.dp), tint = LS.OnBlue)
            Text("Annuler", color = LS.OnBlue, fontSize = 9.sp)
        }
        Text("$count", Modifier.padding(horizontal = 8.dp), color = LS.OnBlue, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        Row(
            Modifier.weight(1f).horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically,
        ) {
            actions.forEach { a ->
                Column(
                    Modifier.clip(RoundedCornerShape(10.dp)).clickable(onClick = a.onClick).padding(horizontal = 8.dp, vertical = 2.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Icon(a.icon, a.label, Modifier.size(20.dp), tint = LS.OnBlue)
                    Text(a.label, color = LS.OnBlue, fontSize = 9.sp)
                }
            }
        }
    }
}

// ═══════════════════════════ Dossier sécurisé ═══════════════════════════

@Composable
internal fun VaultView(ex: ExplorerViewModel) {
    var confirm by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { ex.loadVault() }
    val sub = ex.vaultSub
    val dirs = ex.vaultItems.filter { it.isDir }
    val files = ex.vaultItems.filter { !it.isDir }
    val pad = PaddingValues(start = 16.dp, end = 16.dp, top = 6.dp, bottom = if (ex.selected.isNotEmpty()) 190.dp else 32.dp)
    val emptyText = if (sub == null) "Le coffre est vide" else "Ce dossier est vide"
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton({ if (!ex.vaultUp()) ex.lockVault() }) {
                    Icon(Ic.Back, if (sub == null) "Verrouiller" else "Dossier parent", tint = LS.Text)
                }
                Text(
                    sub?.name ?: "Dossier sécurisé", Modifier.weight(1f),
                    color = LS.Text, fontSize = 20.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                if (sub == null) Icon(Ic.Lock, null, Modifier.padding(end = 2.dp).size(18.dp), tint = LS.Blue)
                SortMenuButton(ex.vaultSort, ex.vaultAsc, { k, asc -> ex.setVaultSort(k, asc) }) { ex.selectAll(ex.vaultItems) }
                IconButton({ ex.vaultGrid = !ex.vaultGrid }) {
                    Icon(
                        if (ex.vaultGrid) Ic.ViewList else Ic.GridView,
                        if (ex.vaultGrid) "Afficher en liste" else "Afficher en grille", tint = LS.Text,
                    )
                }
            }
            if (sub != null) Text(
                "Coffre / " + runCatching { sub.relativeTo(ex.vaultDir).path.replace(File.separatorChar, '/').replace("/", " / ") }.getOrDefault(sub.name),
                Modifier.padding(horizontal = 20.dp, vertical = 6.dp),
                color = LS.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            ex.busy?.let { b ->
                Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                    Text(b, color = LS.Text, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(4.dp))
                    LinearProgressIndicator(Modifier.fillMaxWidth(), color = LS.Blue)
                }
            }
            if (ex.vaultGrid) {
                // Grille (par défaut) : dossiers en grandes cases (2 par ligne), fichiers en miniatures (3 par ligne)
                val loader = rememberThumbLoader()
                LazyVerticalGrid(
                    columns = GridCells.Fixed(6), modifier = Modifier.fillMaxSize(), contentPadding = pad,
                    verticalArrangement = Arrangement.spacedBy(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    if (sub == null) item(key = "vinfo", span = { GridItemSpan(maxLineSpan) }) { VaultInfo() }
                    if (ex.vaultItems.isEmpty()) item(key = "vempty", span = { GridItemSpan(maxLineSpan) }) {
                        Text(emptyText, Modifier.fillMaxWidth().padding(24.dp), color = LS.Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
                    }
                    items(dirs, key = { it.file.path }, span = { GridItemSpan(3) }) { d -> FolderCell(d, ex, Modifier.fillMaxWidth()) }
                    items(files, key = { it.file.path }, span = { GridItemSpan(2) }) { f -> FileCell(f, ex, loader, Modifier.fillMaxWidth()) }
                }
            } else {
                LazyColumn(Modifier.fillMaxSize(), contentPadding = pad, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (sub == null) item(key = "vinfo") { VaultInfo() }
                    if (ex.vaultItems.isEmpty()) item(key = "vempty") {
                        Text(emptyText, Modifier.fillMaxWidth().padding(24.dp), color = LS.Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
                    }
                    items(dirs, key = { it.file.path }) { d -> FileRow(d, ex) }
                    items(files, key = { it.file.path }) { f -> FileRow(f, ex) }
                }
            }
        }
        if (ex.selected.isNotEmpty()) {
            Column(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 10.dp)) {
                SelectionInfoCard(ex)
            }
        }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("Supprimer du coffre ?") },
        text = { Text("${ex.selected.size} élément(s) seront supprimés définitivement.") },
        confirmButton = { TextButton({ confirm = false; ex.deleteFromVault() }) { Text("Supprimer") } },
        dismissButton = { TextButton({ confirm = false }) { Text("Annuler") } },
    )
}

@Composable
private fun VaultInfo() {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(LS.BlueLight).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Ic.Info, null, Modifier.size(18.dp), tint = LS.Blue)
        Spacer(Modifier.width(10.dp))
        Text(
            "Ajoute des fichiers ou des dossiers depuis l'explorateur : appui long, puis « Sécurisé ». " +
                "« Restaurer » les remet dans leur dossier d'origine. " +
                "Ils sont rangés dans l'espace privé de l'appli, invisibles aux autres apps et gestionnaires de fichiers. " +
                "Désinstaller LinkShare les supprime : restaure-les avant.",
            color = LS.Text, fontSize = 11.sp,
        )
    }
}

// ═══════════════════════════ Lecteur local ═══════════════════════════

@Composable
fun LocalViewerScreen(ex: ExplorerViewModel) {
    val f = ex.viewing ?: return
    val e = f.extension.lowercase()
    // Fichiers du même type dans la liste d'où vient le fichier : on y passe en balayant
    val list = ex.viewList.ifEmpty { listOf(f) }
    val start = remember { list.indexOfFirst { it.path == f.path }.coerceAtLeast(0) }
    fun close() { PlayerHost.stop(); ex.viewing = null; ex.viewList = emptyList() }
    BackHandler { close() }
    // Fichier du dossier sécurisé : si le coffre se verrouille, le lecteur se ferme (rien ne reste affiché ni lu)
    LaunchedEffect(VaultLock.unlocked, f.path) { if (!VaultLock.unlocked && ex.inVault(f)) close() }
    // Fichier du dossier sécurisé : son nom ne doit pas s'afficher sur l'écran verrouillé
    fun lockTitle(x: File) = if (x.path.startsWith(ex.vaultDir.path)) "Fichier sécurisé" else x.name
    if (e == "pdf") {
        PdfViewer(ex, f) { close() }
        return
    }
    if (e in VIEW_WEB) {
        // Page web (.html, .htm…) : affichée comme dans un navigateur, ses images et styles voisins se chargent
        WebPage(Uri.fromFile(f).toString(), f.name, onClose = { close() })
        return
    }
    if (e !in VIEW_IMG && e !in VIEW_TXT && e !in VIEW_OFFICE) {
        // Vidéo / audio : lecteur plein écran, avec ses propres commandes (retour, titre, rotation…)
        val urls = remember(list) { list.map { Uri.fromFile(it).toString() } }
        val titles = remember(list) { list.map { lockTitle(it) } }
        Player(urls, titles, start, names = list.map { it.name }, onClose = { close() }) { ex.viewing = list[it] }
        return
    }
    Column(Modifier.fillMaxSize().background(LS.Bg).systemBarsPadding()) {
        Row(Modifier.padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ close() }) { Icon(Ic.Back, "Retour", tint = LS.Blue) }
            Text(f.name, Modifier.weight(1f), color = LS.Blue, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (list.size > 1) Text(
                "${list.indexOfFirst { it.path == f.path } + 1}/${list.size}",
                Modifier.padding(end = 12.dp), color = LS.Muted, fontSize = 12.sp,
            )
        }
        when {
            e in VIEW_IMG -> ImagePager(list, start) { ex.viewing = list[it] }
            e in VIEW_OFFICE -> OfficeViewer(f)
            else -> TextViewer(f)
        }
    }
}

@Composable
private fun TextViewer(f: File) {
    val text by produceState("Chargement…", f) {
        value = withContext(Dispatchers.IO) {
            try {
                f.bufferedReader().use { r ->
                    val buf = CharArray(300_000)
                    val n = r.read(buf)
                    (if (n > 0) String(buf, 0, n) else "") + if (f.length() > 600_000) "\n\n… (aperçu limité)" else ""
                }
            } catch (e: Exception) { "Lecture impossible : ${e.message}" }
        }
    }
    SelectionContainer {
        Text(
            text, Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            color = LS.Text, fontSize = 12.sp, fontFamily = FontFamily.Monospace,
        )
    }
}
