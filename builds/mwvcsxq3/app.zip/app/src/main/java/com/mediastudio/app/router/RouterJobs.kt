package com.mediastudio.app.router

import android.content.Context
import android.net.Uri
import androidx.media3.common.util.UnstableApi
import com.mediastudio.app.Clip
import com.mediastudio.app.DocConverters
import com.mediastudio.app.ExportManager
import com.mediastudio.app.ImageOps
import com.mediastudio.app.MediaFrame
import com.mediastudio.app.Mp3Converter
import com.mediastudio.app.Mp4Batch
import com.mediastudio.app.SubFormat
import com.mediastudio.app.SubtitleBurner
import com.mediastudio.app.SubtitleJobs
import com.mediastudio.app.whisper.Subtitles
import com.mediastudio.app.whisper.WhisperModels
import com.mediastudio.app.VideoOps
import com.mediastudio.app.VideoFrameOps
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Routeur interne : transforme une [RouterRequest] validée en [ExportManager.Job], exécuté ensuite par
 * ExportService (premier plan + WakeLock) avec les classes existantes :
 * Mp3Converter, VideoOps (+ ClipEffects via Clip.filter / Clip.text), ImageOps, MediaFrame, DocConverters,
 * puis Saver (via ExportService).
 *
 * Toutes les opérations vidéo conservent le son d'origine (sauf « retirer le son » / « remplacer le son »).
 */
@UnstableApi
internal object RouterJobs {

    private const val MP4 = "video/mp4"

    fun build(app: Context, req: RouterRequest, base: String, destinationTreeUri: Uri? = null): ExportManager.Job {
        val t = System.currentTimeMillis()
        fun job(name: String, mime: String, block: suspend (java.io.File, (Float) -> Unit) -> Unit) =
            ExportManager.Job(name, mime, block, destinationTreeUri)
        return when (req) {
            is RouterRequest.ToMp3 -> job("${base}_$t.mp3", "audio/mpeg") { out, report ->
                Mp3Converter.convert(app, req.source, out, req.bitrateKbps, report)
            }

            is RouterRequest.ToMp4 -> ExportManager.Job(
                name = if (req.videos.size > 1) "Conversion MP4 (${req.videos.size} vidéos)" else "$base.mp4",
                mime = MP4, block = { _, _ -> }, destinationTreeUri = destinationTreeUri,
                batch = Mp4Batch(app, req.videos, req.mode, req.allowMute, destinationTreeUri),
            )

            is RouterRequest.Compress -> job("${base}_${req.maxHeight}p_$t.mp4", MP4) { out, report ->
                val clip = clipOf(app, req.source, req.startMs, req.endMs)
                VideoOps.compress(app, clip, out, req.maxHeight, req.videoBitrate, report)
            }

            is RouterRequest.Effect -> {
                val tag = when {
                    req.filter.name != "NONE" -> req.filter.name.lowercase()
                    req.logoUri != null -> "logo"
                    else -> "texte"
                }
                job("${base}_${tag}_$t.mp4", MP4) { out, report ->
                    // ClipEffects.videoEffects() lit filter / text / textPos du Clip
                    val clip = clipOf(app, req.source, req.startMs, req.endMs)
                        .copy(filter = req.filter, text = req.text, textPos = req.textPos,
                            logoUri = req.logoUri, logoScale = if (req.logoUri != null) req.logoScale else 0.18f,
                            logoPosition = req.logoPosition)
                    VideoOps.applyEffects(app, clip, out, maxHeight = null, onProgress = report)
                }
            }

            is RouterRequest.Mix -> job("${base}_mix_$t.mp4", MP4) { out, report ->
                val video = clipOf(app, req.video)
                val music = clipOf(app, req.music)
                VideoOps.mixMusic(app, video, music, out, req.keepOriginalAudio, req.videoVolume, req.musicVolume, report)
            }

            is RouterRequest.Concat -> job("montage_$t.mp4", MP4) { out, report ->
                val clips = req.clips.map { clipOf(app, it) }
                VideoOps.concat(app, clips, out, req.fade, onProgress = report)
            }

            is RouterRequest.Transform -> job("${base}_pivot_$t.mp4", MP4) { out, report ->
                VideoOps.transform(app, clipOf(app, req.source), out, req.rotateDeg, req.flipH, report)
            }

            is RouterRequest.Speed -> {
                val tag = req.speed.toString().replace('.', '_')
                job("${base}_x${tag}_$t.mp4", MP4) { out, report ->
                    VideoOps.speed(app, clipOf(app, req.source), out, req.speed, report)
                }
            }

            is RouterRequest.Volume ->
                if (req.audioOnly) job("${base}_volume_$t.m4a", "audio/mp4") { out, report ->
                    VideoOps.volume(app, clipOf(app, req.source), out, req.volume, report)
                } else job("${base}_volume_$t.mp4", MP4) { out, report ->
                    VideoOps.volume(app, clipOf(app, req.source), out, req.volume, report)
                }

            is RouterRequest.Mute -> job("${base}_muet_$t.mp4", MP4) { out, report ->
                VideoOps.mute(app, clipOf(app, req.source), out, report)
            }

            is RouterRequest.Frame -> job("${base}_image_$t.jpg", "image/jpeg") { out, report ->
                MediaFrame.extract(app, req.source, req.atMs, out, report)
            }

            is RouterRequest.FrameCount -> job("${base}_nombre_images.txt", "text/plain") { out, report ->
                val count = VideoFrameOps.count(app, req.source)
                out.writeText("Vidéo : $base\nNombre d'images (frames vidéo) : $count\n")
                report(1f)
            }

            is RouterRequest.ExtractFrames -> job("${base}_images.zip", "application/zip") { out, report ->
                val count = VideoFrameOps.extractAll(app, req.source, base, out, report)
                if (count <= 0) error("Aucune image extraite.")
            }

            is RouterRequest.RebuildVideo -> job("${base}_reconstruit.mp4", MP4) { out, report ->
                VideoFrameOps.rebuildFromArchive(app, req.source, out, report)
            }

            is RouterRequest.ImageConvert -> {
                val (ext, mime) = when (req.format) {
                    "PNG" -> "png" to "image/png"
                    "WEBP" -> "webp" to "image/webp"
                    else -> "jpg" to "image/jpeg"
                }
                job("${base}_$t.$ext", mime) { out, report ->
                    ImageOps.convert(app, req.source, out, req.format, req.quality, req.maxSide, report)
                }
            }

            is RouterRequest.ImagesToPdf -> job("images_$t.pdf", "application/pdf") { out, report ->
                DocConverters.imagesToPdf(app, req.images, out, report)
            }

            is RouterRequest.WordToPdf -> job("${base}_$t.pdf", "application/pdf") { out, report ->
                DocConverters.wordToPdf(app, req.source, out, report)
            }

            is RouterRequest.PdfToWord -> job("${base}_$t.docx", DocConverters.DOCX_MIME) { out, report ->
                DocConverters.pdfToWord(app, req.source, out, report)
            }

            is RouterRequest.TextToPdf -> job("${base}_$t.pdf", "application/pdf") { out, report ->
                DocConverters.textToPdf(app, req.source, out, report)
            }

            is RouterRequest.Transcribe -> {
                val model = WhisperModels.selected(app)
                if (model == null) job("$base.${req.format.ext}", req.format.mime) { _, _ -> error(WhisperModels.HELP) }
                else SubtitleJobs.transcribe(
                    app, req.source, "$base.${req.format.ext}", req.format, model, req.options,
                    title = base, destinationTreeUri = destinationTreeUri, alsoTxt = req.alsoTxt,
                )
            }

            is RouterRequest.BurnSubtitles -> job("${base}_soustitre.mp4", MP4) { out, report ->
                val cues = withContext(Dispatchers.IO) {
                    app.contentResolver.openInputStream(req.subtitles)?.use { Subtitles.parse(it.readBytes().toString(Charsets.UTF_8)) }
                }.orEmpty()
                if (cues.isEmpty()) error("Aucun sous-titre lisible dans le fichier .srt.")
                SubtitleBurner.burn(app, req.video, cues, req.style, out, report)
            }

            // Ces deux demandes ne passent pas par ExportService (écran dédié / copie locale)
            is RouterRequest.SubtitleStudio, is RouterRequest.ImportWhisperModel ->
                job("$base.bin", "application/octet-stream") { _, _ -> error("Action interactive") }
        }
    }

    /** Lecture des métadonnées hors du thread principal (le bloc du Job s'exécute sur Main dans le service). */
    private suspend fun clipOf(ctx: Context, uri: Uri, startMs: Long = -1, endMs: Long = -1): Clip {
        val c = withContext(Dispatchers.IO) { Clip.from(ctx, uri) }
        if (c.durationMs <= 0) error("Durée du média illisible")
        if (startMs < 0 && endMs < 0) return c
        val s = startMs.coerceIn(0, c.durationMs - 1)
        val e = (if (endMs > 0) endMs else c.durationMs).coerceIn(s + 1, c.durationMs)
        return c.copy(startMs = s, endMs = e)
    }
}
