package com.virtuelmix.audio

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import java.nio.ByteBuffer
import kotlin.math.abs

class DeckProcessor(
    private val id: String,
    private val bus: MixBus,
    private val ducker: Ducker
) : BaseAudioProcessor() {

    @Volatile var deckGain = 1f        // utilisé par l'auto-mix
    @Volatile var userGain = 1f        // fader de voie x crossfader
    @Volatile var preset: EqPreset = EqPreset.FLAT
    @Volatile var echo = false
    @Volatile var level = 0f

    private var eq: EqProcessor? = null
    private var channels = 2
    private var delay = FloatArray(2)
    private var dPos = 0

    val equalizer: EqProcessor? get() = eq

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT || inputAudioFormat.channelCount !in 1..2)
            throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        channels = inputAudioFormat.channelCount
        eq = EqProcessor(inputAudioFormat.sampleRate).also { it.apply(preset) }
        delay = FloatArray((inputAudioFormat.sampleRate * 0.32f).toInt() * channels)
        dPos = 0
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val frames = inputBuffer.remaining() / (2 * channels)
        val out = replaceOutputBuffer(frames * channels * 2)
        val tap = FloatArray(frames * 2)
        val g = deckGain * userGain * ducker.musicGain
        val e = eq!!
        val useEcho = echo
        var peak = 0f
        for (f in 0 until frames) {
            var l = 0f
            var r = 0f
            for (c in 0 until channels) {
                val x = e.process(inputBuffer.short / 32768f, c)
                val w = if (useEcho) {
                    val d = delay[dPos]
                    delay[dPos] = x + d * 0.45f
                    dPos = (dPos + 1) % delay.size
                    x + d * 0.5f
                } else x
                val y = (w * g).coerceIn(-1f, 1f)
                out.putShort((y * 32767f).toInt().toShort())
                if (abs(y) > peak) peak = abs(y)
                if (c == 0) l = y else r = y
            }
            if (channels == 1) r = l
            tap[2 * f] = l
            tap[2 * f + 1] = r
        }
        out.flip()
        level = peak
        bus.push(id, tap, tap.size)
    }
}
