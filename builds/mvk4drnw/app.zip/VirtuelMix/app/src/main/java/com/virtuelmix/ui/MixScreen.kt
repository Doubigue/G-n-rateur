package com.virtuelmix.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.SystemClock
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import com.virtuelmix.audio.EqPreset
import com.virtuelmix.service.MixService
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin

private val PadBg = Color(0xFF1B1D24)
private val PanelBg = Color(0xFF23252D)
private val Gray = Color(0xFF8A8D99)
private val Orange = Color(0xFFFFA24A)

@Composable
fun MixScreen(vm: MixViewModel = viewModel()) {
    val ctx = LocalContext.current
    val e = vm.engine
    var menu by remember { mutableStateOf(false) }
    var eqDeck by remember { mutableStateOf<DeckUi?>(null) }

    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) { e.mic.start(); vm.talk = true }
    }
    val loadA = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.a.load(ctx, uri)
    }
    val loadB = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.b.load(ctx, uri)
    }
    val queuePick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach {
            runCatching {
                ctx.contentResolver.takePersistableUriPermission(it, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            e.playlist.enqueue(MediaItem.fromUri(it))
        }
        menu = false
    }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    LaunchedEffect(Unit) {
        while (true) {
            vm.a.tick(); vm.b.tick()
            vm.now = SystemClock.elapsedRealtime()
            delay(33)
        }
    }
    LaunchedEffect(vm.a.playing, vm.b.playing, vm.rec, vm.talk) {
        val parts = mutableListOf<String>()
        if (vm.a.playing) parts.add("Deck A")
        if (vm.b.playing) parts.add("Deck B")
        if (vm.rec) parts.add("REC en cours")
        if (vm.talk) parts.add("Micro actif")
        if (parts.isEmpty()) MixService.stop(ctx) else MixService.update(ctx, parts.joinToString(" · "), vm.talk)
    }

    val onRec = {
        if (vm.rec) { e.recorder.stop(); vm.rec = false }
        else {
            e.recorder.start()
            vm.recStart = SystemClock.elapsedRealtime(); vm.now = vm.recStart; vm.rec = true
        }
    }
    val onTalk = {
        if (vm.talk) { e.mic.stop(); vm.talk = false }
        else if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            e.mic.start(); vm.talk = true
        } else micPerm.launch(Manifest.permission.RECORD_AUDIO)
    }

    Column(Modifier.fillMaxSize().background(Color(0xFF0B0C10)).safeDrawingPadding()) {
        // --- Bandeau du haut : BPM / formes d'onde / MENU
        Row(Modifier.fillMaxWidth().height(72.dp).background(Color.Black)) {
            BpmBox(vm.a, Modifier.width(96.dp).fillMaxHeight())
            WaveStrip(vm.a, false, Modifier.weight(1f).fillMaxHeight())
            Column(Modifier.width(110.dp).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    Modifier.padding(top = 6.dp).clip(RoundedCornerShape(50)).background(Color(0xFF2B2BC8))
                        .clickable { menu = true }.padding(horizontal = 20.dp, vertical = 8.dp)
                ) { Text("MENU", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp) }
                Box(Modifier.width(2.dp).weight(1f).background(Color.Red))
            }
            WaveStrip(vm.b, true, Modifier.weight(1f).fillMaxHeight())
            BpmBox(vm.b, Modifier.width(96.dp).fillMaxHeight())
        }

        // --- Zone centrale : pads, platines, mixeur
        Row(
            Modifier.fillMaxWidth().weight(1f).background(PanelBg).padding(6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            PadColumn(vm.a, { eqDeck = vm.a }, Modifier.width(88.dp).fillMaxHeight())
            Turntable(vm.a, Modifier.weight(1f).fillMaxHeight())
            Mixer(vm, { loadA.launch(arrayOf("audio/*")) }, { loadB.launch(arrayOf("audio/*")) }, onRec, onTalk,
                Modifier.width(190.dp).fillMaxHeight())
            Turntable(vm.b, Modifier.weight(1f).fillMaxHeight())
            PadColumn(vm.b, { eqDeck = vm.b }, Modifier.width(88.dp).fillMaxHeight())
        }

        // --- Bas : lecture, cue, crossfader
        Row(
            Modifier.fillMaxWidth().height(84.dp).background(PadBg).padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            PlayBtn(vm.a, Modifier.width(120.dp).fillMaxHeight())
            Pad("CUE", Modifier.width(64.dp).fillMaxHeight(), false, vm.a.color, { vm.a.cue() })
            Column(
                Modifier.weight(1f).fillMaxHeight(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    "FADE · ${vm.fades[vm.fadeIdx] / 1000} s",
                    Modifier.clickable {
                        vm.fadeIdx = (vm.fadeIdx + 1) % vm.fades.size
                        e.playlist.crossfadeMs = vm.fades[vm.fadeIdx]
                    }.padding(4.dp),
                    color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("A", color = vm.a.color, fontWeight = FontWeight.Bold)
                    HFader(vm.cross, { vm.cross = it; vm.applyGains() }, Modifier.weight(1f).height(44.dp).padding(horizontal = 8.dp))
                    Text("B", color = vm.b.color, fontWeight = FontWeight.Bold)
                }
            }
            Pad("CUE", Modifier.width(64.dp).fillMaxHeight(), false, vm.b.color, { vm.b.cue() })
            PlayBtn(vm.b, Modifier.width(120.dp).fillMaxHeight())
        }
    }

    if (menu) {
        AlertDialog(
            onDismissRequest = { menu = false },
            confirmButton = { TextButton({ menu = false }) { Text("Fermer") } },
            title = { Text("Menu") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button({ queuePick.launch(arrayOf("audio/*")) }) { Text("Ajouter à la file auto-mix") }
                    Button({ e.playlist.startFirst(); menu = false }) { Text("Lancer l'auto-mix") }
                    Text("Enregistrements : Music/Virtuelmix", fontSize = 12.sp, color = Gray)
                }
            }
        )
    }
    eqDeck?.let { d ->
        AlertDialog(
            onDismissRequest = { eqDeck = null },
            confirmButton = { TextButton({ eqDeck = null }) { Text("OK") } },
            title = { Text("EQ · Deck ${d.name}") },
            text = { EqPanel(d) { p -> e.setEq(d.proc, p); d.presetName = p.name } }
        )
    }
}

@Composable
fun Pad(
    label: String,
    modifier: Modifier,
    active: Boolean,
    accent: Color,
    onClick: (() -> Unit)?,
    content: @Composable BoxScope.() -> Unit = {}
) {
    val shape = RoundedCornerShape(6.dp)
    Box(
        modifier.clip(shape)
            .background(if (active) accent.copy(alpha = 0.22f) else PadBg)
            .border(1.dp, if (active) accent else Color(0xFF0B0C10), shape)
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
            .padding(6.dp)
    ) {
        if (label.isNotEmpty())
            Text(label, color = if (active) accent else Color(0xFFB9BCC8), fontSize = 11.sp, fontWeight = FontWeight.Medium)
        content()
    }
}

@Composable
fun PadColumn(ui: DeckUi, onEq: () -> Unit, modifier: Modifier) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Pad("FX", Modifier.fillMaxWidth().weight(1f), ui.echo, ui.color, { ui.echo = !ui.echo; ui.proc.echo = ui.echo }) {
            Text("ÉCHO", Modifier.align(Alignment.BottomStart), color = Gray, fontSize = 10.sp)
        }
        Pad("LOOP", Modifier.fillMaxWidth().weight(1f), ui.loopOn, ui.color, { ui.toggleLoop() }) {
            Text("4 temps", Modifier.align(Alignment.BottomStart), color = Gray, fontSize = 10.sp)
        }
        Pad("EQ", Modifier.fillMaxWidth().weight(1f), false, ui.color, onEq) {
            Text(ui.presetName, Modifier.align(Alignment.BottomStart), color = Gray, fontSize = 10.sp)
        }
        Pad("HOT CUES", Modifier.fillMaxWidth().weight(1.25f), false, ui.color, null) {
            Row(Modifier.align(Alignment.BottomCenter).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                repeat(4) { i ->
                    Box(
                        Modifier.weight(1f).height(26.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (ui.cues[i] >= 0L) ui.color else Color(0xFF2E3039))
                            .pointerInput(i) {
                                detectTapGestures(onTap = { ui.cueTap(i) }, onLongPress = { ui.cueClear(i) })
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Text("${i + 1}", color = if (ui.cues[i] >= 0L) Color.Black else Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun BpmBox(ui: DeckUi, modifier: Modifier) {
    Column(
        modifier.background(Color(0xFF14151A)).padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        val b = ui.effBpm()
        Column(Modifier.clickable { ui.tapTempo() }, horizontalAlignment = Alignment.CenterHorizontally) {
            Text(if (b > 0f) "%.1f".format(b) else "TAP", color = if (b > 0f) Orange else Gray, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text("BPM", color = Gray, fontSize = 10.sp)
        }
        Box(
            Modifier.padding(top = 4.dp).clip(RoundedCornerShape(4.dp))
                .border(1.dp, Color(0xFF5A5D6A), RoundedCornerShape(4.dp))
                .clickable { ui.pitchPct = 0f; ui.applyPitch() }
                .padding(horizontal = 8.dp, vertical = 2.dp)
        ) { Text("%+.1f%%".format(ui.pitchPct), color = Color.White, fontSize = 11.sp) }
    }
}

@Composable
fun WaveStrip(ui: DeckUi, mirror: Boolean, modifier: Modifier) {
    Box(modifier.background(Color.Black)) {
        Canvas(Modifier.fillMaxSize()) {
            ui.waveTick.let { }
            val n = ui.wave.size
            val bw = size.width / n
            val col = ui.color.copy(alpha = if (ui.playing) 0.95f else 0.3f)
            for (k in 0 until n) {
                val idx = if (mirror) n - 1 - k else k
                val h = (3f + ui.wave[idx] * size.height * 1.3f).coerceAtMost(size.height)
                drawRect(col, Offset(k * bw, (size.height - h) / 2f), Size(bw * 0.7f, h))
            }
        }
        Text(
            ui.title, Modifier.align(Alignment.TopCenter).padding(top = 2.dp),
            color = Color(0xFFB9BCC8), fontSize = 11.sp, maxLines = 1
        )
    }
}

@Composable
fun Turntable(ui: DeckUi, modifier: Modifier) {
    var angle by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            androidx.compose.runtime.withFrameNanos { t ->
                if (last != 0L && ui.playing) {
                    angle = (angle + (t - last) / 1e9f * 198f * (1f + ui.pitchPct / 100f)) % 360f
                }
                last = t
            }
        }
    }
    Box(modifier) {
        Canvas(
            Modifier.fillMaxSize().pointerInput(Unit) {
                // « scratch » : glisser sur le plateau déplace la lecture
                detectDragGestures { _, d ->
                    ui.player.seekTo((ui.player.currentPosition + (d.x * 25).toLong()).coerceAtLeast(0L))
                    angle = (angle + d.x * 0.6f) % 360f
                }
            }
        ) {
            val r = minOf(size.width * 0.42f, size.height * 0.46f)
            val c = Offset(size.width * 0.45f, size.height * 0.52f)
            drawCircle(Color(0xFF050608), r * 1.05f, c)
            drawCircle(Color(0xFF17181D), r, c)
            for (k in 1..5) drawCircle(Color(0xFF1F2128), r * (0.3f + 0.13f * k), c, style = Stroke(1.5f))
            val a = Math.toRadians(angle.toDouble())
            val ca = cos(a).toFloat()
            val sa = sin(a).toFloat()
            drawLine(
                ui.color.copy(alpha = 0.9f),
                Offset(c.x + r * 0.62f * ca, c.y + r * 0.62f * sa),
                Offset(c.x + r * 0.94f * ca, c.y + r * 0.94f * sa),
                5f, StrokeCap.Round
            )
            drawCircle(Color(0xFF0D0E12), r * 0.3f, c)
            drawCircle(ui.color, r * 0.3f, c, style = Stroke(3f))
            drawLine(
                Color.White.copy(alpha = 0.7f),
                Offset(c.x + r * 0.08f * ca, c.y + r * 0.08f * sa),
                Offset(c.x + r * 0.26f * ca, c.y + r * 0.26f * sa),
                3f, StrokeCap.Round
            )
            drawCircle(Color.White, 4f, c)

            // bras de lecture : avance avec la progression du morceau
            val tr = r * (0.92f - 0.5f * ui.progress)
            val ta = Math.toRadians(35.0)
            val tip = Offset(c.x + tr * cos(ta).toFloat(), c.y + tr * sin(ta).toFloat())
            val pivot = Offset(c.x + r * 1.0f, c.y - r * 0.98f)
            val dir = (tip - pivot) / (tip - pivot).getDistance()
            drawLine(Color(0xFFB8BAC4), pivot, tip, 6f, StrokeCap.Round)
            drawCircle(Color(0xFF2B2D36), r * 0.11f, pivot)
            drawCircle(Gray, r * 0.05f, pivot)
            drawLine(Color(0xFFFF3B3B), tip - dir * (r * 0.1f), tip + dir * (r * 0.05f), 9f, StrokeCap.Round)
        }
        Column(Modifier.align(Alignment.TopStart)) {
            Box(Modifier.size(40.dp).clickable { ui.bump(0.5f) }, contentAlignment = Alignment.Center) {
                Text("+", color = Gray, fontSize = 26.sp)
            }
            Box(Modifier.size(40.dp).clickable { ui.bump(-0.5f) }, contentAlignment = Alignment.Center) {
                Text("−", color = Gray, fontSize = 26.sp)
            }
        }
    }
}

@Composable
fun Mixer(
    vm: MixViewModel,
    onLoadA: () -> Unit,
    onLoadB: () -> Unit,
    onRec: () -> Unit,
    onTalk: () -> Unit,
    modifier: Modifier
) {
    Column(
        modifier.clip(RoundedCornerShape(8.dp)).background(Color(0xFF181A20)).padding(6.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly) {
            NoteBtn(vm.a.color, onLoadA)
            NoteBtn(vm.b.color, onLoadB)
        }
        Row(Modifier.fillMaxWidth().weight(1f), Arrangement.SpaceEvenly) {
            VFader(vm.a.channel, { vm.a.channel = it; vm.applyGains() }, { vm.a.vu }, vm.a.color, Modifier.weight(1f).fillMaxHeight())
            VFader(vm.b.channel, { vm.b.channel = it; vm.applyGains() }, { vm.b.vu }, vm.b.color, Modifier.weight(1f).fillMaxHeight())
        }
        Row(Modifier.fillMaxWidth().height(34.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            RecBtn(vm, Modifier.weight(1f).fillMaxHeight(), onRec)
            Pad("", Modifier.weight(1f).fillMaxHeight(), vm.talk, Color(0xFF4CAF50), onTalk) {
                Text(
                    "TALK", Modifier.align(Alignment.Center),
                    color = if (vm.talk) Color(0xFF4CAF50) else Color(0xFFB9BCC8), fontSize = 12.sp, fontWeight = FontWeight.Bold
                )
            }
        }
        Pad("", Modifier.fillMaxWidth().height(30.dp), false, Color.White, { vm.sync() }) {
            Text("SYNC", Modifier.align(Alignment.Center), color = Color(0xFFB9BCC8), fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun RecBtn(vm: MixViewModel, modifier: Modifier, onClick: () -> Unit) {
    val secs = if (vm.rec) ((vm.now - vm.recStart) / 1000).coerceAtLeast(0L) else 0L
    Pad("", modifier, vm.rec, Color.Red, onClick) {
        Text(
            if (vm.rec) "● %02d:%02d".format(secs / 60, secs % 60) else "● REC",
            Modifier.align(Alignment.Center),
            color = if (vm.rec) Color.Red else Color(0xFFE57373), fontSize = 12.sp, fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun NoteBtn(color: Color, onClick: () -> Unit) {
    Box(
        Modifier.size(38.dp).clip(CircleShape).border(2.dp, color, CircleShape).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { Text("♫", color = color, fontSize = 18.sp) }
}

@Composable
fun PlayBtn(ui: DeckUi, modifier: Modifier) {
    val shape = RoundedCornerShape(8.dp)
    Box(
        modifier.clip(shape).background(PadBg)
            .border(1.dp, if (ui.playing) ui.color else Color(0xFF0B0C10), shape)
            .clickable { ui.toggle() },
        contentAlignment = Alignment.Center
    ) {
        PlayPauseIcon(ui.playing, if (ui.playing) ui.color else Gray, Modifier.size(34.dp))
    }
}

@Composable
fun PlayPauseIcon(playing: Boolean, color: Color, modifier: Modifier) {
    Canvas(modifier) {
        if (playing) {
            drawRect(color, Offset(size.width * 0.18f, size.height * 0.12f), Size(size.width * 0.24f, size.height * 0.76f))
            drawRect(color, Offset(size.width * 0.58f, size.height * 0.12f), Size(size.width * 0.24f, size.height * 0.76f))
        } else {
            val p = Path().apply {
                moveTo(size.width * 0.25f, size.height * 0.1f)
                lineTo(size.width * 0.9f, size.height * 0.5f)
                lineTo(size.width * 0.25f, size.height * 0.9f)
                close()
            }
            drawPath(p, color)
        }
    }
}

@Composable
fun VFader(value: Float, onChange: (Float) -> Unit, vu: () -> Float, color: Color, modifier: Modifier) {
    Canvas(
        modifier
            .pointerInput(Unit) {
                detectVerticalDragGestures { change, _ ->
                    change.consume()
                    onChange((1f - change.position.y / size.height).coerceIn(0f, 1f))
                }
            }
            .pointerInput(Unit) {
                detectTapGestures { onChange((1f - it.y / size.height).coerceIn(0f, 1f)) }
            }
    ) {
        val cx = size.width / 2f
        drawRoundRect(Color.Black, Offset(cx - 5.dp.toPx(), 0f), Size(10.dp.toPx(), size.height), CornerRadius(5.dp.toPx()))
        for (k in 0..8) {
            val y = size.height * k / 8f
            drawLine(Color(0xFF3A3D48), Offset(cx - 24.dp.toPx(), y), Offset(cx - 14.dp.toPx(), y), 2f)
        }
        val v = vu().coerceIn(0f, 1f)
        val vh = size.height * v
        val vc = if (v > 0.85f) Color.Red else if (v > 0.6f) Color(0xFFFFC107) else color
        drawRoundRect(vc, Offset(size.width - 8.dp.toPx(), size.height - vh), Size(5.dp.toPx(), vh), CornerRadius(2.dp.toPx()))
        val hh = 22.dp.toPx()
        val y = (1f - value) * (size.height - hh)
        drawRoundRect(Color(0xFF3B3E4A), Offset(cx - 20.dp.toPx(), y), Size(40.dp.toPx(), hh), CornerRadius(4.dp.toPx()))
        drawLine(Color.White, Offset(cx - 20.dp.toPx(), y + hh / 2f), Offset(cx + 20.dp.toPx(), y + hh / 2f), 3f)
    }
}

@Composable
fun HFader(value: Float, onChange: (Float) -> Unit, modifier: Modifier) {
    Canvas(
        modifier
            .pointerInput(Unit) {
                detectHorizontalDragGestures { change, _ ->
                    change.consume()
                    onChange((change.position.x / size.width).coerceIn(0f, 1f))
                }
            }
            .pointerInput(Unit) {
                detectTapGestures { onChange((it.x / size.width).coerceIn(0f, 1f)) }
            }
    ) {
        val cy = size.height / 2f
        drawRoundRect(Color.Black, Offset(0f, cy - 3.dp.toPx()), Size(size.width, 6.dp.toPx()), CornerRadius(3.dp.toPx()))
        for (k in 0..10) {
            val x = size.width * k / 10f
            drawLine(Color(0xFF4A4D5A), Offset(x, cy - 18.dp.toPx()), Offset(x, cy - 8.dp.toPx()), if (k == 5) 3f else 1.5f)
        }
        val hw = 26.dp.toPx()
        val x = value * (size.width - hw)
        drawRoundRect(Color(0xFF3B3E4A), Offset(x, cy - 20.dp.toPx()), Size(hw, 40.dp.toPx()), CornerRadius(4.dp.toPx()))
        drawLine(Color.White, Offset(x + hw / 2f, cy - 20.dp.toPx()), Offset(x + hw / 2f, cy + 20.dp.toPx()), 3f)
    }
}

@Composable
fun EqPanel(ui: DeckUi, onChange: (EqPreset) -> Unit) {
    var low by remember { mutableFloatStateOf(ui.proc.preset.lowDb) }
    var mid by remember { mutableFloatStateOf(ui.proc.preset.midDb) }
    var high by remember { mutableFloatStateOf(ui.proc.preset.highDb) }
    fun push() = onChange(EqPreset("Custom", low, mid, high))
    Column(Modifier.verticalScroll(rememberScrollState())) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            EqPreset.ALL.forEach { p ->
                OutlinedButton({ low = p.lowDb; mid = p.midDb; high = p.highDb; onChange(p) }) { Text(p.name) }
            }
        }
        Text("Basses ${"%.1f".format(low)} dB")
        Slider(low, { low = it; push() }, valueRange = -12f..12f)
        Text("Médiums ${"%.1f".format(mid)} dB")
        Slider(mid, { mid = it; push() }, valueRange = -12f..12f)
        Text("Aigus ${"%.1f".format(high)} dB")
        Slider(high, { high = it; push() }, valueRange = -12f..12f)
    }
}
