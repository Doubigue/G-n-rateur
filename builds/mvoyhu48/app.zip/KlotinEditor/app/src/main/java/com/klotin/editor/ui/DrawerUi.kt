package com.klotin.editor.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
private fun DItem(label: String, icon: ImageVector, onClick: () -> Unit) {
    NavigationDrawerItem(
        label = { Text(label, fontSize = 16.sp) },
        selected = false,
        onClick = onClick,
        icon = { Icon(icon, null) },
        modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
    )
}

/** Tiroir latéral (même organisation que QuickEdit). */
@Composable
fun DrawerSheet(version: String, onItem: (String) -> Unit) {
    ModalDrawerSheet(drawerContainerColor = MaterialTheme.colorScheme.background) {
        Box(
            Modifier.fillMaxWidth().height(170.dp)
                .background(Brush.linearGradient(listOf(Color(0xFF283593), Color(0xFF3F51B5), Color(0xFF00A8F0))))
        ) {
            Row(Modifier.align(Alignment.BottomStart).padding(20.dp), verticalAlignment = Alignment.Bottom) {
                Text("Co-edit", fontSize = 26.sp, color = Color.White)
                Text("v$version", fontSize = 14.sp, color = Color.White, modifier = Modifier.padding(start = 10.dp, bottom = 3.dp))
            }
        }
        Spacer(Modifier.height(8.dp))
        DItem("Mémoire stockage interne", Icons.Default.PhoneAndroid) { onItem("files") }
        DItem("Favoris", Icons.Default.StarBorder) { onItem("favs") }
        DItem("Fichiers récents", Icons.Default.History) { onItem("recents") }
        DItem("Serveur local (HTTP/HTTPS)", Icons.Default.CloudQueue) { onItem("server") }
        HorizontalDivider(Modifier.padding(vertical = 8.dp))
        DItem("Console Python", Icons.Default.Code) { onItem("python") }
        DItem("Recommander", Icons.Default.Email) { onItem("share") }
        DItem("Paramètres", Icons.Default.Settings) { onItem("settings") }
        DItem("Aide", Icons.Default.HelpOutline) { onItem("help") }
        DItem("Quitter", Icons.Default.ExitToApp) { onItem("quit") }
    }
}

@Composable
fun SettingsDialog(theme: KTheme, fontSize: Int, onTheme: (KTheme) -> Unit, onFont: (Int) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Paramètres", color = MaterialTheme.colorScheme.primary) },
        text = {
            Column {
                Text("Thème")
                KTheme.values().forEach { t ->
                    Row(Modifier.fillMaxWidth().clickable { onTheme(t) }, verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = t == theme, onClick = { onTheme(t) })
                        Text(t.label, Modifier.padding(start = 8.dp))
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text("Taille du texte : $fontSize")
                Slider(value = fontSize.toFloat(), onValueChange = { onFont(it.toInt()) }, valueRange = 10f..24f, steps = 13)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("OK") } }
    )
}

@Composable
fun ServerDialog(info: String, lan: Boolean, onLan: (Boolean) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Serveur local", color = MaterialTheme.colorScheme.primary) },
        text = {
            Column {
                Text(info, fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Partager sur le réseau local", Modifier.weight(1f))
                    Switch(checked = lan, onCheckedChange = onLan)
                }
                Spacer(Modifier.height(8.dp))
                Text("Le certificat HTTPS est auto-signé : un autre appareil affichera un avertissement.", fontSize = 12.sp)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("OK") } }
    )
}

@Composable
fun HelpDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Aide", color = MaterialTheme.colorScheme.primary) },
        text = {
            Text(
                "• Menu ≡ : stockage, favoris, récents, serveur, Python.\n" +
                "• Icône dossier : ouvrir un fichier du workspace.\n" +
                "• Crayon : édition (défaire, indentation, couleur, horodotage).\n" +
                "• ⋮ : nouveau, enregistrer sous, encodage, aperçu HTML, partage, PDF.\n" +
                "• Barre du bas : coller, défaire/refaire, chercher, curseur, enregistrer, fermer.\n" +
                "• Toucher une archive (zip, 7z, rar, tar…) l'extrait et range son contenu.",
                fontSize = 14.sp
            )
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("OK") } }
    )
}
