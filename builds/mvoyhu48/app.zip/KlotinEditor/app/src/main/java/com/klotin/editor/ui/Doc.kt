package com.klotin.editor.ui

import androidx.compose.runtime.*
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import java.io.File
import java.nio.charset.Charset

/** Un onglet d'édition. */
class Doc(val file: File, enc: String = "UTF-8") {
    var encoding by mutableStateOf(enc)
    var value by mutableStateOf(TextFieldValue(""))
    var dirty by mutableStateOf(false)
    var canUndo by mutableStateOf(false)
    var canRedo by mutableStateOf(false)
    val undo = ArrayDeque<String>()
    val redo = ArrayDeque<String>()

    init { reload() }

    private fun sync() { canUndo = undo.isNotEmpty(); canRedo = redo.isNotEmpty() }

    fun reload() {
        value = TextFieldValue(runCatching { file.readText(Charset.forName(encoding)) }.getOrDefault(""))
        dirty = false
        undo.clear(); redo.clear(); sync()
    }

    fun edit(new: TextFieldValue) {
        if (new.text != value.text) {
            undo.addLast(value.text)
            if (undo.size > 300) undo.removeFirst()
            redo.clear()
            dirty = true
            sync()
        }
        value = new
    }

    fun doUndo() {
        val prev = undo.removeLastOrNull() ?: return
        redo.addLast(value.text)
        value = TextFieldValue(prev, TextRange(prev.length)); dirty = true; sync()
    }

    fun doRedo() {
        val next = redo.removeLastOrNull() ?: return
        undo.addLast(value.text)
        value = TextFieldValue(next, TextRange(next.length)); dirty = true; sync()
    }
}

fun Doc.insert(s: String) {
    val sel = value.selection
    edit(TextFieldValue(value.text.replaceRange(sel.min, sel.max, s), TextRange(sel.min + s.length)))
}

fun Doc.selectAll() { value = value.copy(selection = TextRange(0, value.text.length)) }

fun Doc.moveCursor(delta: Int) {
    val s = value.selection
    val pos = (if (delta < 0) s.min + delta else s.max + delta).coerceIn(0, value.text.length)
    value = value.copy(selection = TextRange(pos))
}

/** Augmente / diminue le retrait des lignes touchées par la sélection. */
fun Doc.indent(increase: Boolean) {
    val t = value.text
    val s = value.selection
    val lineStart = if (s.min == 0) 0 else t.lastIndexOf('\n', s.min - 1) + 1
    val lineEnd = t.indexOf('\n', s.max).let { if (it == -1) t.length else it }
    val lines = t.substring(lineStart, lineEnd).split("\n")
    val out = lines.map { l ->
        if (increase) "    $l"
        else if (l.startsWith("\t")) l.drop(1)
        else l.drop(minOf(4, l.takeWhile { it == ' ' }.length))
    }
    val newBlock = out.joinToString("\n")
    val firstDelta = out.first().length - lines.first().length
    val totalDelta = newBlock.length - lines.joinToString("\n").length
    val newMin = (s.min + firstDelta).coerceAtLeast(lineStart)
    val newMax = (s.max + totalDelta).coerceAtLeast(newMin)
    edit(TextFieldValue(t.substring(0, lineStart) + newBlock + t.substring(lineEnd), TextRange(newMin, newMax)))
}

fun Doc.findNext(q: String, forward: Boolean) {
    if (q.isEmpty()) return
    val t = value.text
    val s = value.selection
    var i = if (forward) t.indexOf(q, s.max, ignoreCase = true)
            else if (s.min > 0) t.lastIndexOf(q, s.min - 1, ignoreCase = true) else -1
    if (i < 0) i = if (forward) t.indexOf(q, 0, ignoreCase = true) else t.lastIndexOf(q, ignoreCase = true)
    if (i >= 0) value = value.copy(selection = TextRange(i, i + q.length))
}

fun Doc.replaceCurrent(q: String, r: String) {
    val s = value.selection
    if (q.isNotEmpty() && s.length > 0 && value.text.substring(s.min, s.max).equals(q, ignoreCase = true)) {
        edit(TextFieldValue(value.text.replaceRange(s.min, s.max, r), TextRange(s.min + r.length)))
    }
    findNext(q, true)
}

fun Doc.replaceAll(q: String, r: String) {
    if (q.isEmpty()) return
    edit(TextFieldValue(value.text.replace(q, r, ignoreCase = true)))
}

/** (libellé affiché, nom Java du charset) — même liste que QuickEdit. */
val ENCODINGS = listOf(
    "UTF-8" to "UTF-8", "UTF-16" to "UTF-16", "UTF-16BE" to "UTF-16BE", "UTF-16LE" to "UTF-16LE",
    "UTF-32" to "UTF-32", "UTF-32BE" to "UTF-32BE", "UTF-32LE" to "UTF-32LE",
    "Arabe (ISO-8859-6)" to "ISO-8859-6", "Arabe (windows-1256)" to "windows-1256",
    "Langues baltes (ISO-8859-4)" to "ISO-8859-4", "Langues baltes (ISO-8859-13)" to "ISO-8859-13",
    "Langues baltes (windows-1257)" to "windows-1257", "Langues celtiques (ISO-8859-14)" to "ISO-8859-14",
    "Cyrillique (IBM866)" to "IBM866", "Cyrillique (ISO-8859-5)" to "ISO-8859-5",
    "Cyrillique (KOI8-R)" to "KOI8-R", "Cyrillique (KOI8-U)" to "KOI8-U", "Cyrillique (windows-1251)" to "windows-1251",
    "Langues d'Europe centrale (windows-1250)" to "windows-1250", "Langues d'Europe orientale (ISO-8859-2)" to "ISO-8859-2",
    "Grec (ISO-8859-7)" to "ISO-8859-7", "Grec (windows-1253)" to "windows-1253",
    "Hébreu (ISO-8859-8)" to "ISO-8859-8", "Hébreu (windows-1255)" to "windows-1255",
    "Japonais (EUC-JP)" to "EUC-JP", "Japonais (ISO-2022-JP)" to "ISO-2022-JP", "Japonais (Shift_JIS)" to "Shift_JIS",
    "Coréen (EUC-KR)" to "EUC-KR", "Coréen (ISO-2022-KR)" to "ISO-2022-KR",
    "Chinois Simplifié (GB18030)" to "GB18030", "Chinois Simplifié (GBK)" to "GBK", "Thaï (TIS-620)" to "TIS-620",
    "Chinois Traditionnel (Big5)" to "Big5", "Chinois Traditionnel (Big5-HKSCS)" to "Big5-HKSCS",
    "Turc (ISO-8859-3)" to "ISO-8859-3", "Turc (ISO-8859-9)" to "ISO-8859-9", "Turc (windows-1254)" to "windows-1254",
    "Vietnamien (windows-1258)" to "windows-1258",
    "Langues d'Europe occidentale (ISO-8859-1)" to "ISO-8859-1", "Langues d'Europe occidentale (ISO-8859-15)" to "ISO-8859-15",
    "Langues d'Europe occidentale (windows-1252)" to "windows-1252",
)
