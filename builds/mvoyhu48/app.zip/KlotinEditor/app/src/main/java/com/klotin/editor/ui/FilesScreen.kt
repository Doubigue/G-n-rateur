package com.klotin.editor.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.klotin.editor.workspace.ArchiveManager
import com.klotin.editor.workspace.WorkspaceManager
import java.io.File

class FileActions(
    val open: (File) -> Unit,
    val openWith: (File) -> Unit,
    val share: (File) -> Unit,
    val whatsapp: (File) -> Unit,
    val extract: (File) -> Unit,
    val pdf: (File) -> Unit,
    val zip: (File) -> Unit,
    val runPy: (File) -> Unit,
    val toggleFav: (File) -> Unit,
    val delete: (File) -> Unit,
)

/** Explorateur : workspace (groupé par catégorie), favoris ou fichiers récents. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FilesScreen(
    wm: WorkspaceManager,
    title: String,
    files: List<File>,
    grouped: Boolean,
    favorites: Set<String>,
    actions: FileActions,
    onBack: () -> Unit,
    onImport: (() -> Unit)?,
    onCreate: ((String) -> Unit)?,
) {
    var newName by remember { mutableStateOf<String?>(null) }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Retour") } },
                actions = { if (onImport != null) IconButton(onClick = onImport) { Icon(Icons.Default.FolderOpen, "Importer") } }
            )
        },
        floatingActionButton = {
            if (onCreate != null) FloatingActionButton(onClick = { newName = "" }) { Icon(Icons.Default.Add, "Nouveau") }
        }
    ) { pad ->
        if (files.isEmpty()) {
            Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) { Text("Aucun fichier") }
        } else LazyColumn(Modifier.padding(pad)) {
            if (grouped) {
                files.groupBy { wm.categoryOf(it) }.forEach { (cat, list) ->
                    item {
                        Text("/${cat.dir}/", Modifier.padding(16.dp, 12.dp, 16.dp, 4.dp),
                            color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.titleSmall)
                    }
                    items(list) { f -> FileRow(f, f.absolutePath in favorites, actions, wm) }
                }
            } else {
                items(files) { f -> FileRow(f, f.absolutePath in favorites, actions, wm) }
            }
        }
    }
    newName?.let { n ->
        AlertDialog(
            onDismissRequest = { newName = null },
            title = { Text("Nouveau fichier", color = MaterialTheme.colorScheme.primary) },
            text = { OutlinedTextField(n, { newName = it }, singleLine = true, label = { Text("ex : index.html") }) },
            confirmButton = { TextButton(onClick = { if (n.isNotBlank()) onCreate?.invoke(n.trim()); newName = null }) { Text("CRÉER") } },
            dismissButton = { TextButton(onClick = { newName = null }) { Text("ANNULER") } }
        )
    }
}

@Composable
private fun FileRow(f: File, isFav: Boolean, actions: FileActions, wm: WorkspaceManager) {
    var menu by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().clickable { actions.open(f) }.padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(f.name)
            Text("${f.length()} o", style = MaterialTheme.typography.labelSmall)
        }
        if (isFav) Icon(Icons.Default.Star, "Favori", tint = MaterialTheme.colorScheme.primary)
        Box {
            IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Menu") }
            DropdownMenu(menu, { menu = false }) {
                @Composable fun item(label: String, block: () -> Unit) =
                    DropdownMenuItem({ Text(label) }, { menu = false; block() })
                item(if (isFav) "Retirer des favoris" else "Ajouter aux favoris") { actions.toggleFav(f) }
                if (f.extension.lowercase() == "py") item("Exécuter (Python)") { actions.runPy(f) }
                if (ArchiveManager.canExtract(f)) item("Extraire") { actions.extract(f) }
                item("Ouvrir avec…") { actions.openWith(f) }
                item("Partager") { actions.share(f) }
                item("Envoyer sur WhatsApp") { actions.whatsapp(f) }
                if (wm.categoryOf(f).isText) item("Exporter en PDF") { actions.pdf(f) }
                item("Compresser (zip)") { actions.zip(f) }
                item("Supprimer") { actions.delete(f) }
            }
        }
    }
}
