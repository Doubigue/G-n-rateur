package com.klotin.editor.ui

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

enum class KTheme(val label: String) { LIGHT("Clair"), DARK("Sombre"), OLED("OLED"), CYBERPUNK("Cyberpunk") }

@Composable
fun KlotinTheme(theme: KTheme, content: @Composable () -> Unit) {
    val scheme = when (theme) {
        KTheme.LIGHT -> lightColorScheme(
            primary = Color(0xFF43A047), onPrimary = Color.White,
            background = Color(0xFFEEEEEE), surface = Color(0xFFFAFAFA), surfaceVariant = Color(0xFFE0E0E0),
            onBackground = Color(0xFF333333), onSurface = Color(0xFF333333), onSurfaceVariant = Color(0xFF616161))
        KTheme.DARK -> darkColorScheme(
            primary = Color(0xFF66BB6A), onPrimary = Color.Black,
            background = Color(0xFF1E1E1E), surface = Color(0xFF2A2A2A), surfaceVariant = Color(0xFF333333),
            onBackground = Color(0xFFE6E6E6), onSurface = Color(0xFFE6E6E6), onSurfaceVariant = Color(0xFFB0B0B0))
        KTheme.OLED -> darkColorScheme(
            primary = Color(0xFF82B1FF), background = Color.Black, surface = Color(0xFF0D0D0D), surfaceVariant = Color(0xFF111111),
            onBackground = Color.White, onSurface = Color.White, onSurfaceVariant = Color(0xFFB0B0B0))
        KTheme.CYBERPUNK -> darkColorScheme(
            primary = Color(0xFFFF2BD6), secondary = Color(0xFF00F0FF), background = Color(0xFF0B0221), surface = Color(0xFF140636),
            surfaceVariant = Color(0xFF1A0B3D), onBackground = Color(0xFFE0F7FF), onSurface = Color(0xFFE0F7FF), onSurfaceVariant = Color(0xFF8FE9FF))
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
