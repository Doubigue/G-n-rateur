package com.klotin.editor.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class EditorActions(
    val openFiles: () -> Unit,
    val openSaf: () -> Unit,
    val newFile: (String) -> Unit,
    val save: (Doc) -> Unit,
    val saveAs: (Doc, String) -> Unit,
    val reload: (Doc) -> Unit,
    val close: (Doc) -> Unit,
    val setEncoding: (Doc, String) -> Unit,
    val preview: (Doc) -> Unit,
    val runPy: (Doc) -> Unit,
    val hex: (Doc) -> Unit,
    val share: (Doc) -> Unit,
    val whatsapp: (Doc) -> Unit,
    val pdf: (Doc) -> Unit,
    val setAutoCorrect: (Boolean) -> Unit,
)

@Composable
fun EditorHost(
    docs: List<Doc>,
    current: Int,
    fontSize: Int,
    autoCorrect: Boolean,
    onSelect: (Int) -> Unit,
    onMenu: () -> Unit,
    a: EditorActions,
) {
    val doc = docs.getOrNull(current)
    val clipboard = LocalClipboardManager.current
    val gray = MaterialTheme.colorScheme.onSurfaceVariant
    var editMenu by remember { mutableStateOf(false) }
    var fileMenu by remember { mutableStateOf(false) }
    var dialog by remember { mutableStateOf<String?>(null) }
    var closeAsk by remember { mutableStateOf<Doc?>(null) }
    var showFind by remember { mutableStateOf(false) }
    var find by remember { mutableStateOf("") }
    var repl by remember { mutableStateOf("") }

    fun requestClose(d: Doc) { if (d.dirty) closeAsk = d else a.close(d) }
    fun paste() { clipboard.getText()?.text?.let { doc?.insert(it) } }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        // ---------- Barre supérieure ----------
        Surface(shadowElevation = 4.dp, color = MaterialTheme.colorScheme.background) {
            Row(Modifier.fillMaxWidth().height(64.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onMenu) { Icon(Icons.Default.Menu, "Menu", tint = gray) }
                Column(Modifier.weight(1f).padding(horizontal = 8.dp)) {
                    Text(doc?.file?.name ?: "Co-edit", fontSize = 20.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(doc?.file?.absolutePath ?: "Aucun fichier ouvert", fontSize = 13.sp, maxLines = 1,
                        overflow = TextOverflow.Ellipsis, color = gray)
                }
                IconButton(onClick = a.openFiles) { Icon(Icons.Default.FolderOpen, "Ouvrir", tint = gray) }
                Box {
                    IconButton(onClick = { editMenu = true }) { Icon(Icons.Default.Edit, "Édition", tint = gray) }
                    DropdownMenu(expanded = editMenu, onDismissRequest = { editMenu = false }) {
                        @Composable fun mi(label: String, icon: ImageVector, enabled: Boolean = true, onClick: () -> Unit) =
                            DropdownMenuItem(text = { Text(label) }, onClick = { editMenu = false; onClick() },
                                leadingIcon = { Icon(icon, null) }, enabled = enabled)
                        mi("Défaire", Icons.Default.Undo, doc?.canUndo == true) { doc?.doUndo() }
                        mi("Refaire", Icons.Default.Redo, doc?.canRedo == true) { doc?.doRedo() }
                        mi("Sélectionner tout", Icons.Default.SelectAll, doc != null) { doc?.selectAll() }
                        mi("Coller", Icons.Default.ContentPaste, doc != null) { paste() }
                        mi("Insérer une couleur", Icons.Default.Palette, doc != null) { dialog = "color" }
                        mi("Insérer un Horodotage", Icons.Default.Schedule, doc != null) {
                            doc?.insert(SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date()))
                        }
                        mi("Augmenter le retrait", Icons.Default.FormatIndentIncrease, doc != null) { doc?.indent(true) }
                        mi("Diminuer le retrait", Icons.Default.FormatIndentDecrease, doc != null) { doc?.indent(false) }
                        mi("Mode de saisie", Icons.Default.Keyboard) { dialog = "input" }
                    }
                }
                Box {
                    IconButton(onClick = { fileMenu = true }) { Icon(Icons.Default.MoreVert, "Plus", tint = gray) }
                    DropdownMenu(expanded = fileMenu, onDismissRequest = { fileMenu = false }) {
                        @Composable fun mi(label: String, icon: ImageVector, enabled: Boolean = true, onClick: () -> Unit) =
                            DropdownMenuItem(text = { Text(label) }, onClick = { fileMenu = false; onClick() },
                                leadingIcon = { Icon(icon, null) }, enabled = enabled)
                        val ext = doc?.file?.extension?.lowercase() ?: ""
                        mi("Nouveau", Icons.Default.Add) { dialog = "new" }
                        mi("Ouvrir", Icons.Default.FolderOpen) { a.openFiles() }
                        mi("Ouvrir (SAF)", Icons.Default.PhoneAndroid) { a.openSaf() }
                        mi("Enregistrer", Icons.Default.Save, doc?.dirty == true) { doc?.let { a.save(it) } }
                        mi("Enregistrer sous…", Icons.Default.SaveAlt, doc != null) { dialog = "saveas" }
                        mi("Recharger", Icons.Default.Refresh, doc != null) { doc?.let { a.reload(it) } }
                        mi("Fermer", Icons.Default.Close, doc != null) { doc?.let { requestClose(it) } }
                        if (doc != null) {
                            HorizontalDivider()
                            mi("Encodage", Icons.Default.Language) { dialog = "encoding" }
                            if (ext == "html" || ext == "htm") mi("Aperçu (navigateur intégré)", Icons.Default.PlayArrow) { a.preview(doc) }
                            if (ext == "py") mi("Exécuter (Python)", Icons.Default.PlayArrow) { a.runPy(doc) }
                            mi("Afficher en hexadécimal", Icons.Default.Code) { a.hex(doc) }
                            mi("Partager", Icons.Default.Share) { a.share(doc) }
                            mi("Envoyer sur WhatsApp", Icons.Default.Send) { a.whatsapp(doc) }
                            mi("Exporter en PDF", Icons.Default.Description) { a.pdf(doc) }
                        }
                    }
                }
            }
        }

        if (doc == null) {
            // ---------- État vide ----------
            Column(Modifier.weight(1f).fillMaxWidth().padding(24.dp), verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Aucun fichier ouvert", fontSize = 20.sp)
                Spacer(Modifier.height(16.dp))
                Button(onClick = { dialog = "new" }) { Text("Nouveau fichier") }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = a.openFiles) { Text("Ouvrir") }
            }
        } else {
            // ---------- Onglets ----------
            Row(Modifier.fillMaxWidth().height(52.dp).horizontalScroll(rememberScrollState())) {
                docs.forEachIndexed { i, d ->
                    Box(Modifier.fillMaxHeight().clickable { onSelect(i) }.padding(horizontal = 18.dp), contentAlignment = Alignment.Center) {
                        Text((if (d.dirty) "*" else "") + d.file.name, fontSize = 18.sp, maxLines = 1,
                            color = if (i == current) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = .75f))
                        if (i == current) Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(3.dp).background(MaterialTheme.colorScheme.primary))
                    }
                    Box(Modifier.align(Alignment.CenterVertically).width(1.dp).height(26.dp).background(gray.copy(alpha = .3f)))
                }
            }
            Box(Modifier.fillMaxWidth().height(1.dp).background(gray.copy(alpha = .3f)))

            // ---------- Zone d'édition ----------
            Box(Modifier.weight(1f).fillMaxWidth()) { key(doc) { EditorArea(doc, fontSize, autoCorrect) } }

            // ---------- Recherche / remplacement ----------
            if (showFind) {
                Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        OutlinedTextField(find, { find = it }, Modifier.weight(1f), singleLine = true, label = { Text("Chercher") })
                        IconButton(onClick = { doc.findNext(find, false) }) { Icon(Icons.Default.KeyboardArrowUp, "Précédent") }
                        IconButton(onClick = { doc.findNext(find, true) }) { Icon(Icons.Default.KeyboardArrowDown, "Suivant") }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        OutlinedTextField(repl, { repl = it }, Modifier.weight(1f), singleLine = true, label = { Text("Remplacer par") })
                        TextButton(onClick = { doc.replaceCurrent(find, repl) }) { Text("REMPL.") }
                        TextButton(onClick = { doc.replaceAll(find, repl) }) { Text("TOUT") }
                    }
                }
            }

            // ---------- Barre d'outils inférieure ----------
            Surface(shadowElevation = 8.dp, color = MaterialTheme.colorScheme.background) {
                Row(Modifier.fillMaxWidth().height(56.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = a.openFiles) { Icon(Icons.Default.FolderOpen, "Ouvrir", tint = gray) }
                    IconButton(onClick = { paste() }) { Icon(Icons.Default.ContentPaste, "Coller", tint = gray) }
                    IconButton(onClick = { doc.doUndo() }, enabled = doc.canUndo) { Icon(Icons.Default.Undo, "Défaire") }
                    IconButton(onClick = { doc.doRedo() }, enabled = doc.canRedo) { Icon(Icons.Default.Redo, "Refaire") }
                    IconButton(onClick = { showFind = !showFind }) { Icon(Icons.Default.Search, "Chercher", tint = gray) }
                    IconButton(onClick = { doc.moveCursor(-1) }) { Icon(Icons.Default.ArrowBack, "Curseur à gauche", tint = gray) }
                    IconButton(onClick = { doc.moveCursor(1) }) { Icon(Icons.Default.ArrowForward, "Curseur à droite", tint = gray) }
                    IconButton(onClick = { a.save(doc) }, enabled = doc.dirty) { Icon(Icons.Default.Save, "Enregistrer") }
                    IconButton(onClick = { requestClose(doc) }) { Icon(Icons.Default.Close, "Fermer l'onglet", tint = gray) }
                }
            }
        }
    }

    // ---------- Dialogues ----------
    when (dialog) {
        "new" -> NameDialog("Nouveau fichier", "", "ex : index.html", "CRÉER", { dialog = null }) { a.newFile(it); dialog = null }
        "saveas" -> doc?.let { d ->
            NameDialog("Enregistrer sous…", d.file.name, "nom du fichier", "ENREGISTRER", { dialog = null }) { a.saveAs(d, it); dialog = null }
        }
        "encoding" -> doc?.let { d ->
            EncodingDialog(d.encoding, { dialog = null }) { a.setEncoding(d, it); dialog = null }
        }
        "color" -> ColorDialog({ dialog = null }) { doc?.insert(it); dialog = null }
        "input" -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Mode de saisie", color = MaterialTheme.colorScheme.primary) },
            text = {
                Column {
                    listOf(false to "Sans correction automatique (code)", true to "Avec correction automatique (texte)").forEach { (v, label) ->
                        Row(Modifier.fillMaxWidth().clickable { a.setAutoCorrect(v) }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = autoCorrect == v, onClick = { a.setAutoCorrect(v) })
                            Text(label, Modifier.padding(start = 12.dp))
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { dialog = null }) { Text("OK") } }
        )
    }
    closeAsk?.let { d ->
        AlertDialog(
            onDismissRequest = { closeAsk = null },
            title = { Text("Modifications non enregistrées") },
            text = { Text("Enregistrer « ${d.file.name} » avant de fermer ?") },
            confirmButton = { TextButton(onClick = { a.save(d); a.close(d); closeAsk = null }) { Text("ENREGISTRER") } },
            dismissButton = {
                Row {
                    TextButton(onClick = { closeAsk = null }) { Text("ANNULER") }
                    TextButton(onClick = { a.close(d); closeAsk = null }) { Text("IGNORER") }
                }
            }
        )
    }
}

@Composable
private fun EditorArea(doc: Doc, fontSize: Int, autoCorrect: Boolean) {
    val focus = remember { FocusRequester() }
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val gray = MaterialTheme.colorScheme.onSurfaceVariant
    val style = TextStyle(
        fontFamily = FontFamily.Monospace, fontSize = fontSize.sp, lineHeight = (fontSize * 1.5f).sp,
        color = MaterialTheme.colorScheme.onSurface
    )
    val text = doc.value.text
    val lines = text.count { it == '\n' } + 1
    val gutter = remember(lines) { (1..lines).joinToString("\n") }
    val gutterW = (lines.toString().length * fontSize * 0.62f + 18f).dp
    val screenW = LocalConfiguration.current.screenWidthDp
    val ext = doc.file.extension.lowercase()

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth()) {
            Text(
                gutter,
                style = style.copy(color = gray, textAlign = TextAlign.End),
                modifier = Modifier.width(gutterW).background(gray.copy(alpha = .08f)).padding(end = 8.dp, top = 6.dp)
            )
            Box(Modifier.weight(1f).horizontalScroll(rememberScrollState())) {
                BasicTextField(
                    value = doc.value,
                    onValueChange = { doc.edit(it) },
                    textStyle = style,
                    cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                    visualTransformation = remember(ext, dark) { SyntaxTransformation(ext, dark) },
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.None, autoCorrect = autoCorrect),
                    modifier = Modifier
                        .widthIn(min = (screenW - 60).dp)
                        .padding(start = 8.dp, top = 6.dp, end = 24.dp)
                        .focusRequester(focus)
                )
            }
        }
        Spacer(
            Modifier.fillMaxWidth().height(320.dp).clickable(
                interactionSource = remember { MutableInteractionSource() }, indication = null
            ) { focus.requestFocus() }
        )
    }
}

@Composable
fun NameDialog(title: String, initial: String, hint: String, ok: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var name by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, color = MaterialTheme.colorScheme.primary) },
        text = { OutlinedTextField(name, { name = it }, singleLine = true, label = { Text(hint) }) },
        confirmButton = { TextButton(onClick = { if (name.isNotBlank()) onOk(name.trim()) }) { Text(ok) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("ANNULER") } }
    )
}

@Composable
fun EncodingDialog(current: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var sel by remember { mutableStateOf(current) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Encodage", color = MaterialTheme.colorScheme.primary) },
        text = {
            LazyColumn(Modifier.heightIn(max = 440.dp)) {
                items(ENCODINGS) { (label, cs) ->
                    Row(Modifier.fillMaxWidth().clickable { sel = cs }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = sel.equals(cs, ignoreCase = true), onClick = { sel = cs })
                        Text(label, Modifier.padding(start = 12.dp))
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onOk(sel) }) { Text("OK") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("ANNULER") } }
    )
}

@Composable
private fun ColorDialog(onDismiss: () -> Unit, onPick: (String) -> Unit) {
    var hex by remember { mutableStateOf("#") }
    val palette = listOf("#F44336", "#E91E63", "#9C27B0", "#3F51B5", "#2196F3", "#00BCD4", "#4CAF50",
        "#CDDC39", "#FFEB3B", "#FF9800", "#795548", "#607D8B", "#000000", "#FFFFFF")
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Insérer une couleur", color = MaterialTheme.colorScheme.primary) },
        text = {
            Column {
                palette.chunked(5).forEach { row ->
                    Row(Modifier.padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { h ->
                            Box(
                                Modifier.size(40.dp).background(Color(android.graphics.Color.parseColor(h)))
                                    .border(1.dp, Color.Gray).clickable { onPick(h) }
                            )
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(hex, { hex = it }, singleLine = true, label = { Text("Code hexadécimal") })
            }
        },
        confirmButton = { TextButton(onClick = { if (hex.length > 1) onPick(hex) }) { Text("INSÉRER") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("ANNULER") } }
    )
}
