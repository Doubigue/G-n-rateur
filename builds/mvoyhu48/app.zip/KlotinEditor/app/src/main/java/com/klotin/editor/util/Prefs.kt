package com.klotin.editor.util

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("coedit", Context.MODE_PRIVATE)

    var theme: String
        get() = sp.getString("theme", "LIGHT") ?: "LIGHT"
        set(v) { sp.edit().putString("theme", v).apply() }
    var fontSize: Int
        get() = sp.getInt("font", 14)
        set(v) { sp.edit().putInt("font", v).apply() }
    var autoCorrect: Boolean
        get() = sp.getBoolean("autocorrect", false)
        set(v) { sp.edit().putBoolean("autocorrect", v).apply() }
    var recents: List<String>
        get() = (sp.getString("recents", "") ?: "").split("\n").filter { it.isNotBlank() }
        set(v) { sp.edit().putString("recents", v.joinToString("\n")).apply() }
    var favorites: Set<String>
        get() = (sp.getStringSet("favs", emptySet()) ?: emptySet()).toSet()
        set(v) { sp.edit().putStringSet("favs", v.toSet()).apply() }

    fun addRecent(path: String) { recents = (listOf(path) + recents.filter { it != path }).take(20) }
}
