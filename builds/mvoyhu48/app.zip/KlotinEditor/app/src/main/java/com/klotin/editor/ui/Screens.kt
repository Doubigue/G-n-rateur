package com.klotin.editor.ui

import android.annotation.SuppressLint
import android.graphics.BitmapFactory
import android.net.Uri
import android.net.http.SslError
import android.webkit.SslErrorHandler
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.klotin.editor.workspace.WorkspaceManager
import java.io.File

private val mono = FontFamily.Monospace

// ---------------- Hex viewer ----------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HexScreen(file: File, onBack: () -> Unit) {
    val dump = remember(file) {
        val max = 256 * 1024
        val bytes = com.klotin.editor.util.Share.readHead(file, max)
        buildString {
            bytes.toList().chunked(16).forEachIndexed { i, row ->
                append("%08X  ".format(i * 16))
                append(row.joinToString(" ") { "%02X".format(it) }.padEnd(47))
                append("  ")
                append(row.map { b -> val c = b.toInt() and 0xFF; if (c in 32..126) c.toChar() else '.' }.joinToString(""))
                append('\n')
            }
            if (file.length() > max) append("\n… tronqué à 256 Ko sur ${file.length()} octets")
        }
    }
    Column(Modifier.fillMaxSize()) {
        TopAppBar(title = { Text(file.name) }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Retour") } })
        Box(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).horizontalScroll(rememberScrollState()).padding(8.dp)) {
            Text(dump, style = TextStyle(fontFamily = mono, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface))
        }
    }
}

// ---------------- Image viewer ----------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImageScreen(file: File, onBack: () -> Unit) {
    val bmp = remember(file) { BitmapFactory.decodeFile(file.path)?.asImageBitmap() }
    Column(Modifier.fillMaxSize()) {
        TopAppBar(title = { Text(file.name) }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Retour") } })
        if (bmp != null) Image(bmp, file.name, Modifier.fillMaxSize()) else Text("Format non décodable", Modifier.padding(16.dp))
    }
}

// ---------------- Live preview (HTTP / HTTPS servis par le serveur local) ----------------
@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun PreviewScreen(httpUrl: String, httpsUrl: String, onBack: () -> Unit) {
    var secure by remember { mutableStateOf(false) }
    val url = if (secure) httpsUrl else httpUrl
    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(url, maxLines = 1, fontSize = 12.sp) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Retour") } },
            actions = { TextButton(onClick = { secure = !secure }) { Text(if (secure) "HTTPS" else "HTTP") } }
        )
        key(url) {
            AndroidView(factory = { ctx ->
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    webViewClient = object : WebViewClient() {
                        // certificat auto-signé : accepté uniquement pour notre serveur local
                        override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
                            val host = Uri.parse(error.url).host
                            if (host == "127.0.0.1" || host == "localhost") handler.proceed() else handler.cancel()
                        }
                    }
                    loadUrl(url)
                }
            }, modifier = Modifier.fillMaxSize())
        }
    }
}
