package com.klotin.editor.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation

/** Lightweight regex-based highlighter, generic across languages. */
class SyntaxTransformation(private val ext: String, private val dark: Boolean = true) : VisualTransformation {
    private val keywords = Regex(
        "\\b(fun|val|var|class|object|interface|return|if|else|for|while|when|import|package|def|function|const|let|" +
        "public|private|static|void|int|new|this|true|false|null|None|True|False|try|catch|in|is|as|from|select|where)\\b")
    private val numbers = Regex("\\b\\d+(\\.\\d+)?\\b")
    private val strings = Regex("\"(\\\\.|[^\"\\\\\\n])*\"|'(\\\\.|[^'\\\\\\n])*'")
    private val cComments = Regex("//.*|/\\*[\\s\\S]*?\\*/|<!--[\\s\\S]*?-->")
    private val hashComments = Regex("(?m)^\\s*#.*|\\s#.*")
    private val hashExts = setOf("py", "sh", "rb", "yaml", "yml", "toml", "ini", "conf", "pl", "r", "env", "properties")

    override fun filter(text: AnnotatedString): TransformedText {
        val s = text.text
        val out = buildAnnotatedString {
            append(s)
            fun paint(r: Regex, c: Color) = r.findAll(s).forEach { addStyle(SpanStyle(color = c), it.range.first, it.range.last + 1) }
            paint(keywords, if (dark) Color(0xFFC792EA) else Color(0xFF7B1FA2))
            paint(numbers, if (dark) Color(0xFFF78C6C) else Color(0xFFE65100))
            paint(strings, if (dark) Color(0xFFC3E88D) else Color(0xFF2E7D32))
            paint(cComments, if (dark) Color(0xFF7F8C98) else Color(0xFF757575))
            if (ext in hashExts) paint(hashComments, if (dark) Color(0xFF7F8C98) else Color(0xFF757575))
        }
        return TransformedText(out, OffsetMapping.Identity)
    }
}
