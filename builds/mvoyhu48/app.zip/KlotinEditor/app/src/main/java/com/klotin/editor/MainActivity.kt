package com.klotin.editor

import android.content.Intent
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Window
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Surface
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.core.view.WindowCompat
import com.klotin.editor.server.CertManager
import com.klotin.editor.server.LocalServer
import com.klotin.editor.ui.*
import com.klotin.editor.util.PdfExport
import com.klotin.editor.util.Prefs
import com.klotin.editor.util.Share
import com.klotin.editor.workspace.ArchiveManager
import com.klotin.editor.workspace.WorkspaceManager
import kotlinx.coroutines.launch
import java.io.File
import java.net.Inet4Address
import java.net.NetworkInterface
import java.nio.charset.Charset
import kotlin.concurrent.thread

private sealed interface Screen {
    object Editor : Screen
    object Files : Screen
    object Recents : Screen
    object Favorites : Screen
    data class Hex(val f: File) : Screen
    data class Img(val f: File) : Screen
    data class Media(val f: File) : Screen
    data class Pdf(val f: File) : Screen
    data class Py(val f: File?) : Screen
    data class Preview(val rel: String) : Screen
}

class MainActivity : ComponentActivity() {
    private lateinit var wm: WorkspaceManager
    private lateinit var prefs: Prefs
    private var http: LocalServer? = null
    private var https: LocalServer? = null
    private val lanState = mutableStateOf(false)
    private val serverInfo = mutableStateOf("Démarrage du serveur…")

    private val imgExt = setOf("png", "jpg", "jpeg", "gif", "webp", "bmp", "ico")
    private val mediaExt = setOf("mp3", "wav", "ogg", "m4a", "flac", "aac", "opus", "mp4", "mkv", "webm", "avi", "mov", "3gp")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        wm = WorkspaceManager(this)
        prefs = Prefs(this)
        startServers(false)
        val version = runCatching { packageManager.getPackageInfo(packageName, 0).versionName }.getOrNull() ?: ""

        setContent {
            var theme by remember { mutableStateOf(runCatching { KTheme.valueOf(prefs.theme) }.getOrDefault(KTheme.LIGHT)) }
            var fontSize by remember { mutableStateOf(prefs.fontSize) }
            var autoCorrect by remember { mutableStateOf(prefs.autoCorrect) }
            var screen by remember { mutableStateOf<Screen>(Screen.Editor) }
            val docs = remember { mutableStateListOf<Doc>() }
            var current by remember { mutableStateOf(0) }
            var files by remember { mutableStateOf(wm.files()) }
            var favs by remember { mutableStateOf(prefs.favorites) }
            var dlg by remember { mutableStateOf<String?>(null) }
            val drawer = rememberDrawerState(DrawerValue.Closed)
            val scope = rememberCoroutineScope()

            fun toast(m: String) = runOnUiThread { Toast.makeText(this, m, Toast.LENGTH_LONG).show() }
            fun refresh() { files = wm.files() }

            fun addDoc(f: File) {
                val i = docs.indexOfFirst { it.file == f }
                if (i >= 0) current = i else { docs.add(Doc(f)); current = docs.lastIndex }
                prefs.addRecent(f.absolutePath)
                screen = Screen.Editor
            }

            fun extract(f: File) {
                toast("Extraction de ${f.name}…")
                thread {
                    val r = runCatching { ArchiveManager.extract(f, wm, cacheDir) }
                    toast(r.fold({ "${it.size} fichier(s) extrait(s) et rangés" }, { "Échec : ${it.message}" }))
                    runOnUiThread { refresh() }
                }
            }

            fun openFile(f: File) {
                val ext = f.extension.lowercase()
                when {
                    ArchiveManager.canExtract(f) -> extract(f)
                    ext in imgExt -> screen = Screen.Img(f)
                    ext in mediaExt -> screen = Screen.Media(f)
                    ext == "pdf" -> screen = Screen.Pdf(f)
                    wm.categoryOf(f).isText || isProbablyText(f) -> addDoc(f)
                    else -> screen = Screen.Hex(f)
                }
            }

            fun closeDoc(d: Doc) {
                val i = docs.indexOf(d)
                docs.remove(d)
                current = if (docs.isEmpty()) 0 else (if (i > 0) i - 1 else 0).coerceAtMost(docs.lastIndex)
            }

            fun saveDoc(d: Doc) {
                runCatching { wm.save(d.file, d.value.text, d.encoding) }
                    .onSuccess { d.dirty = false; toast("Enregistré") }
                    .onFailure { toast("Échec : ${it.message}") }
            }

            fun importUris(uris: List<android.net.Uri>): List<File> = uris.mapNotNull { uri ->
                val name = contentResolver.query(uri, null, null, null, null)?.use { c ->
                    if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
                } ?: "import.bin"
                contentResolver.openInputStream(uri)?.let { wm.import(name, it) }
            }

            val importPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
                importUris(uris); refresh()
            }
            val safPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
                val imported = importUris(uris); refresh(); imported.forEach { openFile(it) }
            }

            val editorActions = EditorActions(
                openFiles = { refresh(); screen = Screen.Files },
                openSaf = { safPicker.launch(arrayOf("*/*")) },
                newFile = { name -> openFile(wm.create(name)); refresh() },
                save = { saveDoc(it) },
                saveAs = { d, name ->
                    val dest = wm.create(name)
                    runCatching { dest.writeText(d.value.text, Charset.forName(d.encoding)) }
                        .onSuccess {
                            val i = docs.indexOf(d)
                            if (i >= 0) docs[i] = Doc(dest, d.encoding)
                            prefs.addRecent(dest.absolutePath); refresh(); toast("Enregistré : ${dest.name}")
                        }
                        .onFailure { toast("Échec : ${it.message}") }
                },
                reload = { it.reload() },
                close = { closeDoc(it) },
                setEncoding = { d, enc ->
                    if (Charset.isSupported(enc)) { d.encoding = enc; if (!d.dirty) d.reload() }
                    else toast("Encodage non supporté sur cet appareil")
                },
                preview = { d -> saveDoc(d); screen = Screen.Preview(d.file.relativeTo(wm.root).path) },
                runPy = { d -> saveDoc(d); screen = Screen.Py(d.file) },
                hex = { d -> screen = Screen.Hex(d.file) },
                share = { d -> if (d.dirty) saveDoc(d); Share.send(this, d.file, false) },
                whatsapp = { d -> if (d.dirty) saveDoc(d); Share.send(this, d.file, true) },
                pdf = { d ->
                    val dest = wm.create(d.file.nameWithoutExtension + ".pdf")
                    runCatching { PdfExport.textToPdf(d.value.text, dest) }
                        .onSuccess { toast("PDF créé : /media_docs/${dest.name}"); refresh() }
                        .onFailure { toast("Échec PDF : ${it.message}") }
                },
                setAutoCorrect = { autoCorrect = it; prefs.autoCorrect = it },
            )

            val fileActions = FileActions(
                open = { openFile(it) },
                openWith = { Share.open(this, it) },
                share = { Share.send(this, it, false) },
                whatsapp = { Share.send(this, it, true) },
                extract = { extract(it) },
                pdf = { f ->
                    val dest = wm.create(f.nameWithoutExtension + ".pdf")
                    runCatching { PdfExport.textToPdf(f.readText(), dest) }
                        .onSuccess { toast("PDF créé : /media_docs/${dest.name}") }
                        .onFailure { toast("Échec PDF : ${it.message}") }
                    refresh()
                },
                zip = { f -> ArchiveManager.compress(listOf(f), wm.create(f.nameWithoutExtension + ".zip")); refresh() },
                runPy = { screen = Screen.Py(it) },
                toggleFav = { f ->
                    val p = f.absolutePath
                    prefs.favorites = if (p in favs) favs - p else favs + p
                    favs = prefs.favorites
                },
                delete = { f ->
                    wm.delete(f)
                    docs.removeAll { it.file == f }
                    current = current.coerceAtMost((docs.size - 1).coerceAtLeast(0))
                    refresh()
                },
            )

            val onDrawer: (String) -> Unit = { id ->
                scope.launch { drawer.close() }
                when (id) {
                    "files" -> { refresh(); screen = Screen.Files }
                    "favs" -> screen = Screen.Favorites
                    "recents" -> screen = Screen.Recents
                    "server" -> dlg = "server"
                    "python" -> screen = Screen.Py(null)
                    "share" -> startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, "Essaie Co-edit, un éditeur de code et de texte pour Android.")
                    }, "Recommander Co-edit"))
                    "settings" -> dlg = "settings"
                    "help" -> dlg = "help"
                    "quit" -> finish()
                }
            }

            BackHandler(drawer.isOpen || screen != Screen.Editor) {
                if (drawer.isOpen) scope.launch { drawer.close() } else { screen = Screen.Editor; refresh() }
            }

            KlotinTheme(theme) {
                SystemBars(window)
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    ModalNavigationDrawer(
                        drawerState = drawer,
                        gesturesEnabled = screen == Screen.Editor,
                        drawerContent = { DrawerSheet(version, onDrawer) }
                    ) {
                        when (val s = screen) {
                            Screen.Editor -> EditorHost(
                                docs, current, fontSize, autoCorrect,
                                onSelect = { current = it },
                                onMenu = { scope.launch { drawer.open() } },
                                a = editorActions
                            )
                            Screen.Files -> FilesScreen(
                                wm, "Mémoire stockage interne", files, true, favs, fileActions,
                                onBack = { screen = Screen.Editor },
                                onImport = { importPicker.launch(arrayOf("*/*")) },
                                onCreate = { openFile(wm.create(it)); refresh() }
                            )
                            Screen.Recents -> FilesScreen(
                                wm, "Fichiers récents", prefs.recents.map { File(it) }.filter { it.exists() }, false, favs,
                                fileActions, { screen = Screen.Editor }, null, null
                            )
                            Screen.Favorites -> FilesScreen(
                                wm, "Favoris", favs.map { File(it) }.filter { it.exists() }, false, favs,
                                fileActions, { screen = Screen.Editor }, null, null
                            )
                            is Screen.Hex -> HexScreen(s.f) { screen = Screen.Editor }
                            is Screen.Img -> ImageScreen(s.f) { screen = Screen.Editor }
                            is Screen.Media -> MediaScreen(s.f) { screen = Screen.Editor }
                            is Screen.Pdf -> PdfScreen(s.f) { screen = Screen.Editor }
                            is Screen.Py -> PythonScreen(s.f) { screen = Screen.Editor }
                            is Screen.Preview -> PreviewScreen(
                                "http://127.0.0.1:8080/${s.rel}", "https://127.0.0.1:8443/${s.rel}"
                            ) { screen = Screen.Editor }
                        }
                    }
                }
                when (dlg) {
                    "settings" -> SettingsDialog(
                        theme, fontSize,
                        onTheme = { theme = it; prefs.theme = it.name },
                        onFont = { fontSize = it; prefs.fontSize = it },
                        onDismiss = { dlg = null }
                    )
                    "server" -> ServerDialog(serverInfo.value, lanState.value, { startServers(it) }) { dlg = null }
                    "help" -> HelpDialog { dlg = null }
                }
            }
        }
    }

    @Composable
    private fun SystemBars(window: Window) {
        val bg = MaterialTheme.colorScheme.background
        SideEffect {
            window.statusBarColor = bg.toArgb()
            window.navigationBarColor = bg.toArgb()
            val c = WindowCompat.getInsetsController(window, window.decorView)
            c.isAppearanceLightStatusBars = bg.luminance() > 0.5f
            c.isAppearanceLightNavigationBars = bg.luminance() > 0.5f
        }
    }

    /** Un fichier sans extension connue est texte s'il est petit et sans octet nul. */
    private fun isProbablyText(f: File): Boolean {
        if (f.length() > 2_000_000) return false
        val head = Share.readHead(f, 4096)
        return head.none { it.toInt() == 0 }
    }

    /** HTTP :8080 + HTTPS :8443 (certificat auto-signé). shareOnLan = toutes les interfaces. */
    private fun startServers(shareOnLan: Boolean) {
        lanState.value = shareOnLan
        serverInfo.value = "Démarrage du serveur…"
        thread {
            http?.stop(); https?.stop()
            val host = if (shareOnLan) null else "127.0.0.1"
            val ips = if (shareOnLan) lanIps() else emptyList()
            http = LocalServer(wm.root, host, 8080).also { it.start() }
            val httpsOk = runCatching {
                val ssl = CertManager.sslFactory(this, ips)
                https = LocalServer(wm.root, host, 8443, ssl).also { it.start() }
            }.isSuccess
            val where = if (shareOnLan && ips.isNotEmpty()) ips.first() else "127.0.0.1"
            serverInfo.value = "http://$where:8080" +
                (if (httpsOk) "\nhttps://$where:8443 (auto-signé)" else "\nHTTPS indisponible") +
                (if (shareOnLan) "\nPartagé sur le réseau" else "\nLocal uniquement")
        }
    }

    private fun lanIps(): List<String> =
        NetworkInterface.getNetworkInterfaces().toList()
            .flatMap { it.inetAddresses.toList() }
            .filter { !it.isLoopbackAddress && it is Inet4Address }
            .mapNotNull { it.hostAddress }

    override fun onDestroy() { http?.stop(); https?.stop(); super.onDestroy() }
}
