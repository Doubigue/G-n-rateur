# Co-edit v0.3

Ouvrir le dossier dans Android Studio (Koala+), laisser Gradle synchroniser (le wrapper est généré à l'ouverture), puis Run.
Prérequis : JDK 17. Le wrapper Gradle est fourni (Gradle 8.9, compatible AGP 8.5.2).

## Interface (façon QuickEdit)
Barre du haut (≡, nom + chemin, ouvrir, crayon = édition, ⋮ = fichier), onglets multiples avec * pour non enregistré,
éditeur avec numéros de ligne, barre du bas (ouvrir, coller, défaire, refaire, chercher, curseur ←/→, enregistrer, fermer),
tiroir latéral, dialogue d'encodage (40 encodages), thème Clair vert par défaut (+ Sombre, OLED, Cyberpunk).

## Fonctionnalités
- Workspace `KlotinWorkspace/` (stockage de l'app) : 5 sous-dossiers routés par extension, `binaries_others` = catch-all
- Éditeur : numéros de ligne, coloration, undo/redo, chercher/remplacer, encodages, historique Git-lite (`.history/`)
- Visionneuses : hexadécimal (tout fichier), images, **audio/vidéo (Media3)**, **PDF (PdfRenderer)**
- Aperçu HTML (WebView) servi par NanoHTTPD, liens relatifs inter-dossiers résolus par nom de fichier
- **HTTP :8080 + HTTPS :8443** : certificat auto-signé (BouncyCastle), SAN localhost/127.0.0.1/IP LAN, régénéré si l'IP change ; bouton « Serveur » = partage réseau
- **Console Python (optionnelle, Chaquopy 3.11)** : exécuter un .py (▶ dans l'éditeur ou menu du fichier) + REPL persistant
- **Archives** : zip, 7z, tar, tar.gz/tgz, tar.bz2, tar.xz, gz/bz2/xz, rar (RAR4) ; toucher une archive l'extrait et range les fichiers ; compression zip
- **Partage** : feuille de partage, envoi direct WhatsApp, « Ouvrir avec… » (docx/xlsx/pptx), export PDF des fichiers texte
- Thèmes OLED / Cyberpunk / Clair

## Activer la console Python (optionnel)
Le build par défaut n'inclut PAS Chaquopy (il est incompatible avec les Gradle trop récents : erreur `org/gradle/util/VersionNumber`). Pour l'activer, avec le wrapper Gradle 8.9 fourni :
1. `build.gradle.kts` (racine), dans `plugins { }` : `id("com.chaquo.python") version "15.0.1" apply false`
2. `app/build.gradle.kts` : ajouter `id("com.chaquo.python")` dans `plugins { }`, `ndk { abiFilters += listOf("arm64-v8a", "x86_64") }` dans `defaultConfig { }`, puis `chaquopy { defaultConfig { version = "3.11" } }` sous le bloc `android { }`
Sans cela, l'écran Python affiche simplement « Python n'est pas activé ».

## Limites connues
- Certificat auto-signé : le navigateur d'un autre appareil affichera un avertissement ; la WebView intégrée l'accepte pour localhost/127.0.0.1 uniquement
- Python : pas de `input()`, pas de pip (ajouter des paquets via `chaquopy { defaultConfig { pip { install("...") } } }`)
- RAR5 non supporté (junrar) ; l'extraction met les fichiers à plat par catégorie (pas d'arborescence)

## Idées suivantes
Rendu Markdown, éditeur Sora pour gros fichiers, tests instrumentés
