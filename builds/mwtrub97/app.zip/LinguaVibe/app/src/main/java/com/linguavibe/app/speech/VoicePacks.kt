package com.linguavibe.app.speech

import android.content.Context
import androidx.compose.runtime.mutableStateMapOf
import com.linguavibe.app.data.CourseRepository
import com.linguavibe.app.data.QuizItem
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

data class PackProgress(val done: Int, val total: Int, val running: Boolean, val message: String? = null)

/**
 * Téléchargement des voix d'une langue, une seule fois : tout l'audio des cours est enregistré
 * sur le téléphone, puis lu sans Internet. Les phrases déjà enregistrées sont sautées, donc un
 * téléchargement interrompu reprend où il s'était arrêté.
 */
object VoicePacks {
    val progress = mutableStateMapOf<String, PackProgress>()
    private val jobs = ConcurrentHashMap<String, Job>()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences("voice_packs", Context.MODE_PRIVATE)

    fun isDone(context: Context, lang: String): Boolean = prefs(context).getBoolean("done_$lang", false)

    /** Toutes les phrases que les leçons font lire dans [lang]. */
    fun texts(context: Context, lang: String): List<String> {
        if (lang == "fr") {
            return listOf(
                "Bonjour et bienvenue dans LinguaVibe.",
                "Écoutez la phrase, puis répétez-la à voix haute.",
                "Je peux apprendre une nouvelle langue chaque jour.",
                "Comment allez-vous ? Je vais bien, merci.",
                "Téléchargement de la voix française terminé."
            )
        }
        val courses = buildList {
            add(CourseRepository.load(context, lang, "model1"))
            if (lang == "es") add(CourseRepository.load(context, lang, "model2"))
        }
        val out = ArrayList<String>()
        for (lesson in courses.flatMap { it.lessons }) {
            lesson.vocab.forEach { v ->
                out.add(if (v.word.any { it == '+' || it == '…' }) v.example else v.word)
                out.add(v.example)
            }
            lesson.grammar.forEach { g -> g.examples.forEach { out.add(it.text) } }
            lesson.dialogue.forEach { out.add(it.text) }
            lesson.quiz.filterIsInstance<QuizItem.Listen>().forEach { out.add(it.phrase) }
            lesson.phrases.forEach { out.add(it.text) }
            lesson.reading?.sentences?.forEach { out.add(it.text) }
            lesson.homework.forEach { out.add(it.model) }
        }
        return out.map { it.trim() }.filter { it.isNotEmpty() }.distinct()
    }

    fun start(context: Context, lang: String) {
        if (jobs[lang]?.isActive == true) return
        val app = context.applicationContext
        progress[lang] = PackProgress(0, 0, true)
        jobs[lang] = scope.launch {
            val all = texts(app, lang)
            val total = all.size
            var done = 0
            progress[lang] = PackProgress(0, total, true)
            for (text in all) {
                val cached = GoogleVoice.isCached(app, text, lang)
                try {
                    GoogleVoice.speechFile(app, text, lang)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: VoiceNetworkException) {
                    progress[lang] = PackProgress(done, total, false, "Connexion interrompue : relancez pour reprendre.")
                    return@launch
                } catch (_: Throwable) {
                    // Une phrase refusée par le service : on passe à la suivante.
                }
                done++
                if (done % 3 == 0 || done == total) progress[lang] = PackProgress(done, total, true)
                if (!cached) delay(120)
            }
            prefs(app).edit().putBoolean("done_$lang", true).apply()
            progress[lang] = PackProgress(total, total, false)
        }
    }

    fun cancel(lang: String) {
        jobs[lang]?.cancel()
        progress[lang]?.let { progress[lang] = it.copy(running = false, message = "Téléchargement arrêté.") }
    }

    /** À appeler quand l'audio enregistré est vidé. */
    fun resetAll(context: Context) {
        jobs.values.forEach { it.cancel() }
        progress.clear()
        prefs(context).edit().clear().apply()
    }
}
