package com.linguavibe.app.speech

import android.content.Context
import androidx.compose.runtime.mutableStateOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import java.io.BufferedInputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Pack chinois dédié : modèle VITS Icefall AISHELL-3 (non Piper, non Kokoro). */
object ChineseVoiceManager {
    const val MODEL_ID = "vits-icefall-zh-aishell3"
    const val MODEL_URL = "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/$MODEL_ID.tar.bz2"
    val progress = mutableStateOf(SupertonicVoiceManager.DownloadProgress())
    fun modelDir(context: Context) = File(context.filesDir, "tts-models/$MODEL_ID")
    fun isInstalled(context: Context) = listOf("model.onnx", "lexicon.txt", "tokens.txt").all { File(modelDir(context), it).length() > 0 }

    suspend fun install(context: Context) = withContext(Dispatchers.IO) {
        if (isInstalled(context)) return@withContext
        val root = File(context.filesDir, "tts-models").apply { mkdirs() }
        val archive = File(root, "$MODEL_ID.tar.bz2.part")
        progress.value = SupertonicVoiceManager.DownloadProgress(running = true)
        var connection: HttpURLConnection? = null
        try {
            connection = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply { connectTimeout = 20_000; readTimeout = 60_000; instanceFollowRedirects = true }
            connection.connect()
            if (connection.responseCode !in 200..299) throw IllegalStateException("Téléchargement chinois : HTTP ${connection.responseCode}")
            val total = connection.contentLengthLong; var count = 0L
            connection.inputStream.use { input -> archive.outputStream().use { output ->
                val buffer = ByteArray(64 * 1024)
                while (true) { val n = input.read(buffer); if (n < 0) break; output.write(buffer, 0, n); count += n; progress.value = SupertonicVoiceManager.DownloadProgress(count, total, true) }
            } }
            if (archive.length() < 1024L) throw IllegalStateException("Archive chinoise vide ou incomplète.")
            val staging = File(root, "$MODEL_ID.extracting").apply { deleteRecursively(); mkdirs() }
            BZip2CompressorInputStream(BufferedInputStream(archive.inputStream())).use { bz ->
                TarArchiveInputStream(bz).use { tar ->
                    while (true) {
                        val entry = tar.nextTarEntry ?: break
                        val out = File(staging, entry.name).canonicalFile
                        require(out.path.startsWith(staging.canonicalPath + File.separator) || out == staging) { "Archive chinoise invalide." }
                        if (entry.isDirectory) out.mkdirs() else { out.parentFile?.mkdirs(); out.outputStream().use { tar.copyTo(it) } }
                    }
                }
            }
            val extracted = File(staging, MODEL_ID).takeIf { it.isDirectory } ?: staging
            val destination = modelDir(context); destination.deleteRecursively()
            if (!extracted.renameTo(destination)) extracted.walkTopDown().forEach { f -> val target = File(destination, f.relativeTo(extracted).path); if (f.isDirectory) target.mkdirs() else { target.parentFile?.mkdirs(); f.copyTo(target, true) } }
            staging.deleteRecursively(); archive.delete()
            if (!isInstalled(context)) throw IllegalStateException("Fichiers du modèle chinois manquants après extraction.")
            progress.value = SupertonicVoiceManager.DownloadProgress(count, total, false)
        } catch (t: Throwable) {
            progress.value = SupertonicVoiceManager.DownloadProgress(error = t.message ?: "Installation du chinois impossible.")
            throw t
        } finally { connection?.disconnect(); archive.delete() }
    }

    fun remove(context: Context) { modelDir(context).deleteRecursively() }
}
