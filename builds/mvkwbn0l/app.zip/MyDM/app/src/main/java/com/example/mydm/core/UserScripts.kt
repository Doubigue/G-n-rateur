package com.example.mydm.core

import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class UserScript(val id: String = UUID.randomUUID().toString(), val name: String, val match: String,
                      val code: String, val enabled: Boolean = true)

/**
 * « Extensions » : scripts utilisateur injectés dans les pages (façon Tampermonkey).
 * Les vraies extensions Chrome (.crx) ne peuvent pas tourner dans une WebView Android.
 */
object UserScripts {
    val list = mutableStateListOf<UserScript>()

    fun load() {
        list.clear()
        runCatching {
            val a = JSONArray(Prefs.sp.getString("scripts", "[]"))
            for (k in 0 until a.length()) a.getJSONObject(k).let {
                list += UserScript(it.getString("id"), it.getString("name"), it.getString("match"), it.getString("code"), it.optBoolean("on", true))
            }
        }
    }

    private fun save() {
        val a = JSONArray(); list.forEach {
            a.put(JSONObject().put("id", it.id).put("name", it.name).put("match", it.match).put("code", it.code).put("on", it.enabled))
        }
        Prefs.sp.edit().putString("scripts", a.toString()).apply()
    }

    fun upsert(s: UserScript) { val i = list.indexOfFirst { it.id == s.id }; if (i >= 0) list[i] = s else list.add(s); save() }
    fun remove(id: String) { list.removeAll { it.id == id }; save() }

    /** Motif simple : « * » = joker (ex. https://*.youtube.com/*). Vide ou « * » = toutes les pages. */
    private fun matches(pattern: String, url: String): Boolean {
        val p = pattern.trim()
        if (p.isEmpty() || p == "*") return true
        val rx = p.split("*").joinToString(".*") { Regex.escape(it) }
        return Regex("^$rx$", RegexOption.IGNORE_CASE).matches(url)
    }

    fun forUrl(url: String): List<UserScript> = list.filter { it.enabled && matches(it.match, url) }

    fun wrap(code: String) = "(function(){try{\n$code\n}catch(e){console.error('[UserScript] '+e)}})();"
}
