package com.safeemail.keeper
import android.content.ContentValues
import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.provider.MediaStore
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.*
import java.util.zip.*

object PdfExport {
    private const val W = 595; private const val H = 842
    const val FOLDER = "Compte Google clé"
    private var pageRef: PdfDocument.Page? = null
    private fun paint(size: Float, color: Int, bold: Boolean = false) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = size; this.color = color; typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT }

    // Fond redessiné d'après l'image fournie : blanc lumineux au centre, gris sur les bords, quadrillage fin
    private fun background(c: Canvas) {
        c.drawColor(Color.WHITE)
        c.drawRect(0f, 0f, W.toFloat(), H.toFloat(), Paint().apply {
            shader = RadialGradient(W * .5f, H * .5f, H * .72f, intArrayOf(Color.WHITE, Color.parseColor("#D2D2D2")), null, Shader.TileMode.CLAMP) })
        val line = Paint().apply { color = Color.parseColor("#8A5B6068"); strokeWidth = .7f }
        for (i in 0..10) c.drawLine(i * W / 10f, 0f, i * W / 10f, H.toFloat(), line)
        for (j in 0..19) c.drawLine(0f, j * H / 19f, W.toFloat(), j * H / 19f, line)
    }

    private fun page(doc: PdfDocument, n: Int, title: String): Canvas {
        val pg = doc.startPage(PdfDocument.PageInfo.Builder(W, H, n).create()); pageRef = pg
        val c = pg.canvas; background(c)
        c.drawRect(0f, 0f, W.toFloat(), 90f, Paint().apply { shader = LinearGradient(0f, 0f, W.toFloat(), 0f, Color.parseColor("#7C3AED"), Color.parseColor("#06B6D4"), Shader.TileMode.CLAMP) })
        c.drawText("SafeEmail Keeper", 32f, 42f, paint(24f, Color.WHITE, true))
        c.drawText(title, 32f, 68f, paint(13f, Color.parseColor("#E0F2FE")))
        return c
    }

    private fun drawAccounts(doc: PdfDocument, list: List<Account>, title: String) {
        var n = 1; var c = page(doc, n, title); var y = 125f
        val ink = Color.parseColor("#0F172A"); val grey = Color.parseColor("#475569")
        for (a in list) {
            val need = 150f + a.keys.size * 20f + a.methods.size * 18f
            if (y + need > H - 30 && y > 130f) { doc.finishPage(pageRef!!); c = page(doc, ++n, title); y = 125f }
            c.drawRoundRect(24f, y - 22f, W - 24f, y + need - 30f, 16f, 16f, Paint().apply { color = Color.argb(235, 255, 255, 255) })
            c.drawRoundRect(24f, y - 22f, W - 24f, y + need - 30f, 16f, 16f, Paint().apply { style = Paint.Style.STROKE; color = Color.parseColor("#A5B4FC"); strokeWidth = 1f })
            c.drawText(a.email, 40f, y, paint(17f, ink, true)); y += 24f
            c.drawText("Mot de passe : " + a.password, 40f, y, paint(13f, ink)); y += 20f
            c.drawText("Numéro de récupération : " + a.phone.ifBlank { "—" }, 40f, y, paint(13f, grey)); y += 24f
            c.drawText("CLÉS DE SECOURS", 40f, y, paint(11f, Color.parseColor("#0E7490"), true)); y += 18f
            a.keys.forEachIndexed { i, k ->
                val t = "${i + 1}. ${k.text}"
                val p = paint(13f, if (k.used) Color.parseColor("#6B7280") else Color.parseColor("#047857"))
                c.drawText(t + if (k.used) "   (utilisée)" else "   (valide)", 48f, y, p)
                if (k.used) c.drawLine(48f, y - 4f, 48f + p.measureText(t), y - 4f, Paint().apply { color = Color.parseColor("#F43F5E"); strokeWidth = 1.6f })
                y += 20f }
            y += 6f; c.drawText("MÉTHODES DE SÉCURITÉ", 40f, y, paint(11f, Color.parseColor("#6D28D9"), true)); y += 18f
            a.methods.forEach { m -> c.drawText("• $m", 48f, y, paint(13f, ink)); y += 18f }
            y += 40f
        }
        doc.finishPage(pageRef!!)
    }

    fun bytes(list: List<Account>, title: String): ByteArray {
        val doc = PdfDocument(); drawAccounts(doc, list, title)
        return ByteArrayOutputStream().also { doc.writeTo(it); doc.close() }.toByteArray()
    }

    private fun zipBytes(list: List<Account>): ByteArray {
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { z -> list.forEach { a ->
            z.putNextEntry(ZipEntry(a.email.replace(Regex("[^A-Za-z0-9@._-]"), "_") + ".pdf"))
            z.write(bytes(listOf(a), a.email)); z.closeEntry() } }
        return out.toByteArray()
    }

    /** Enregistre automatiquement dans Téléchargements/Compte Google clé et renvoie le chemin affichable. */
    fun download(ctx: Context, list: List<Account>, zip: Boolean): String {
        val stamp = SimpleDateFormat("yyyyMMdd-HHmm", Locale.FRANCE).format(Date())
        val name = if (zip) "Comptes-par-email-$stamp.zip" else "Comptes-global-$stamp.pdf"
        val data = if (zip) zipBytes(list) else bytes(list, "Export global — ${list.size} comptes")
        val v = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, if (zip) "application/zip" else "application/pdf")
            put(MediaStore.Downloads.RELATIVE_PATH, "Download/$FOLDER") }
        val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: error("MediaStore")
        ctx.contentResolver.openOutputStream(uri)!!.use { it.write(data) }
        return "Téléchargements/$FOLDER/$name"
    }
}
