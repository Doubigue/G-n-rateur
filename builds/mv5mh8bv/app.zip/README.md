# Édition Baobab — application Flutter Android

## Contenu
- `pubspec.yaml`
- `lib/main.dart`
- `lib/models/` : modèles livre et panier
- `lib/services/local_store.dart` : stockage JSON privé via `path_provider` et `dart:io`
- `lib/screens/` : accueil, catalogue, panier, compte, dépôt de manuscrit

## Construire l’application
1. Créez un projet Flutter vierge avec le SDK Flutter installé.
2. Remplacez son `pubspec.yaml` par celui fourni et copiez le dossier `lib/`.
3. Dans un terminal, lancez `flutter pub get`.
4. Pour générer l’APK : `flutter build apk --release`.

Le ZIP ne contient volontairement aucun dossier `android/`, `ios/`, `web/` ou `test/`.

## Important
Cette version est une adaptation native Android du site fourni, pas une synchronisation complète avec Firebase. Les livres de démonstration sont définis dans `lib/screens/app_shell.dart`. Le panier, le profil, les commandes et les brouillons de manuscrits sont enregistrés localement dans un fichier JSON privé de l’application. Aucune authentification réelle, commande serveur, synchronisation Firebase, paiement, facture PDF Cloudinary, messagerie en ligne ou téléchargement d’e-book n’est effectué dans cette version. Les couvertures web et les publications Firebase du site doivent être raccordées à une API sécurisée si la synchronisation est souhaitée.
