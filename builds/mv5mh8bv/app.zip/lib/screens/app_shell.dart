import 'package:flutter/material.dart';
import '../models/book.dart';
import '../models/cart_item.dart';
import '../services/local_store.dart';
import 'home_screen.dart';
import 'catalog_screen.dart';
import 'cart_screen.dart';
import 'account_screen.dart';
import 'manuscript_screen.dart';

const sampleBooks = <Book>[
  Book(id:'baobab-001', title:'Les voix du baobab', author:'Collectif Baobab',
    description:'Des récits sensibles qui célèbrent les mémoires, les rencontres et les imaginaires africains.',
    price:6500, ebookPrice:3000, category:'Roman', coverUrl:'', hasEbook:true),
  Book(id:'baobab-002', title:'Au fil des saisons', author:'Aminata Koné',
    description:'Un recueil poétique sur le temps, la famille et la force des recommencements.',
    price:5000, ebookPrice:2500, category:'Poésie', coverUrl:'', hasEbook:true),
  Book(id:'baobab-003', title:'Penser demain', author:'Serge Dago',
    description:'Essais et réflexions pour comprendre les transformations de nos sociétés.',
    price:7500, ebookPrice:3500, category:'Essai', coverUrl:'', hasEbook:false),
  Book(id:'baobab-004', title:'Le chemin des lucioles', author:'Mariam Traoré',
    description:'Un roman d’apprentissage entre héritage, liberté et espoir.',
    price:6000, ebookPrice:2800, category:'Roman', coverUrl:'', hasEbook:true),
];

class AppShell extends StatefulWidget {
  const AppShell({super.key});
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int _index = 0;
  List<CartItem> _cart = [];
  Map<String, dynamic> _profile = {};
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final cart = await LocalStore.loadCart();
    final profile = await LocalStore.loadProfile();
    if (!mounted) return;
    setState(() { _cart = cart; _profile = profile; _ready = true; });
  }

  Future<void> _add(Book book, String format) async {
    final matches = _cart.where((e) => e.book.id == book.id && e.format == format);
    final existing = matches.isEmpty ? null : matches.first;
    setState(() {
      if (existing != null) { existing.quantity++; }
      else { _cart.add(CartItem(book: book, format: format)); }
    });
    await LocalStore.saveCart(_cart);
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${book.title} ajouté au panier')),
    );
  }

  Future<void> _saveProfile(Map<String, dynamic> profile) async {
    await LocalStore.saveProfile(profile);
    if (mounted) setState(() => _profile = profile);
  }

  @override
  Widget build(BuildContext context) {
    if (!_ready) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final pages = [
      HomeScreen(books: sampleBooks, onCatalog: () => setState(() => _index = 1),
        onAdd: _add, profile: _profile),
      CatalogScreen(books: sampleBooks, onAdd: _add),
      CartScreen(items: _cart, profile: _profile, onChanged: (items) async {
        setState(() => _cart = items); await LocalStore.saveCart(items);
      }, onOrder: (order) async {
        await LocalStore.addOrder(order);
        setState(() => _cart = []);
      }),
      AccountScreen(profile: _profile, onSave: _saveProfile),
      ManuscriptScreen(profile: _profile),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('Édition Baobab', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: -.4)),
        bottom: PreferredSize(preferredSize: const Size.fromHeight(1), child: Container(height: 1, color: const Color(0xFFE8E1D5))),
        actions: [
          IconButton(onPressed: () => setState(() => _index = 2),
            icon: Badge(label: Text('${_cart.fold<int>(0, (sum, e) => sum + e.quantity)}'),
              child: const Icon(Icons.shopping_bag_outlined)), tooltip: 'Panier'),
          const SizedBox(width: 8),
        ],
      ),
      body: IndexedStack(index: _index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Accueil'),
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'Catalogue'),
          NavigationDestination(icon: Icon(Icons.shopping_cart_outlined), selectedIcon: Icon(Icons.shopping_cart), label: 'Panier'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Compte'),
          NavigationDestination(icon: Icon(Icons.edit_note), selectedIcon: Icon(Icons.edit_note), label: 'Manuscrit'),
        ],
      ),
    );
  }
}
