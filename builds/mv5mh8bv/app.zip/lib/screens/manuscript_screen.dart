import 'package:flutter/material.dart';
import '../services/local_store.dart';

class ManuscriptScreen extends StatefulWidget {
  final Map<String, dynamic> profile;
  const ManuscriptScreen({super.key, required this.profile});
  @override
  State<ManuscriptScreen> createState() => _ManuscriptScreenState();
}
class _ManuscriptScreenState extends State<ManuscriptScreen> {
  final _key = GlobalKey<FormState>();
  final _title = TextEditingController();
  final _author = TextEditingController();
  final _email = TextEditingController();
  final _genre = TextEditingController();
  final _summary = TextEditingController();

  @override
  void initState() {
    super.initState();
    _author.text = widget.profile['name'] as String? ?? '';
    _email.text = widget.profile['email'] as String? ?? '';
  }
  @override
  void dispose() { _title.dispose(); _author.dispose(); _email.dispose(); _genre.dispose(); _summary.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('Soumettre un manuscrit', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w800, color: Color(0xFF10281E))),
    const SizedBox(height: 8),
    const Text('Présentez votre projet éditorial. Cette version conserve le formulaire sur votre appareil ; elle ne l’envoie pas à la maison d’édition.'),
    const SizedBox(height: 18),
    Card(child: Padding(padding: const EdgeInsets.all(16), child: Form(key: _key, child: Column(children: [
      TextFormField(controller: _title, decoration: const InputDecoration(labelText: 'Titre du manuscrit'), validator: _required),
      const SizedBox(height: 12),
      TextFormField(controller: _author, decoration: const InputDecoration(labelText: 'Nom de l’auteur'), validator: _required),
      const SizedBox(height: 12),
      TextFormField(controller: _email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Adresse e-mail'), validator: (v) => v == null || !v.contains('@') ? 'Adresse e-mail invalide.' : null),
      const SizedBox(height: 12),
      TextFormField(controller: _genre, decoration: const InputDecoration(labelText: 'Genre (roman, poésie, essai…)'), validator: _required),
      const SizedBox(height: 12),
      TextFormField(controller: _summary, minLines: 4, maxLines: 7, decoration: const InputDecoration(labelText: 'Résumé et présentation du projet'), validator: _required),
      const SizedBox(height: 16),
      SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _submit, icon: const Icon(Icons.save_outlined), label: const Text('Enregistrer le dossier'))),
    ]))),
  ]);

  String? _required(String? value) => value == null || value.trim().isEmpty ? 'Ce champ est obligatoire.' : null;

  Future<void> _submit() async {
    if (!_key.currentState!.validate()) return;
    final ref = 'MS-${DateTime.now().year}-${DateTime.now().millisecondsSinceEpoch.toString().substring(7)}';
    await LocalStore.saveManuscript({
      'title': _title.text.trim(), 'author': _author.text.trim(), 'email': _email.text.trim(),
      'genre': _genre.text.trim(), 'summary': _summary.text.trim(), 'reference': ref,
      'createdAt': DateTime.now().toIso8601String(), 'status': 'Brouillon local',
    });
    if (!mounted) return;
    _title.clear(); _genre.clear(); _summary.clear();
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Dossier enregistré sur cet appareil. Référence : $ref')));
  }
}
