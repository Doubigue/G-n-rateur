import 'package:flutter/material.dart';
import '../models/book.dart';

class HomeScreen extends StatelessWidget {
  final List<Book> books;
  final VoidCallback onCatalog;
  final Future<void> Function(Book, String) onAdd;
  final Map<String, dynamic> profile;
  const HomeScreen({super.key, required this.books, required this.onCatalog, required this.onAdd, required this.profile});

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.fromLTRB(18, 18, 18, 28), children: [
      Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(26),
          gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: [Color(0xFF10281E), Color(0xFF28523A)]),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('MAISON D’ÉDITION INDÉPENDANTE', style: TextStyle(color: Color(0xFFE8CB6A), fontSize: 11, letterSpacing: 1.5, fontWeight: FontWeight.bold)),
          const SizedBox(height: 18),
          const Text('Des voix d’ici,\ndes pages pour tous.', style: TextStyle(color: Colors.white, fontSize: 32, height: 1.08, fontWeight: FontWeight.w800)),
          const SizedBox(height: 12),
          const Text('Romans, poésie et essais pour faire vivre les histoires et les idées.', style: TextStyle(color: Colors.white70, height: 1.5)),
          const SizedBox(height: 22),
          FilledButton.icon(onPressed: onCatalog, icon: const Icon(Icons.arrow_forward), label: const Text('Découvrir le catalogue')),
        ]),
      ),
      const SizedBox(height: 26),
      const _SectionTitle(title: 'Dernières parutions', subtitle: 'Des histoires à découvrir'),
      const SizedBox(height: 12),
      SizedBox(height: 275, child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: books.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (context, i) => SizedBox(width: 190, child: _BookCard(book: books[i], onAdd: onAdd)),
      )),
      const SizedBox(height: 24),
      Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(color: const Color(0xFFF0E9D9), borderRadius: BorderRadius.circular(20)),
        child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Votre histoire mérite d’être lue.', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold, color: Color(0xFF10281E))),
          SizedBox(height: 8),
          Text('Vous écrivez un roman, un essai ou de la poésie ? Préparez votre manuscrit et déposez-le depuis l’onglet Manuscrit.'),
        ])),
      const SizedBox(height: 24),
      const _SectionTitle(title: 'Notre engagement', subtitle: 'Faire émerger des voix singulières'),
      const SizedBox(height: 8),
      const Text('Nous accompagnons les auteurs et proposons aux lecteurs des œuvres qui nourrissent la curiosité, l’émotion et le dialogue.'),
    ]);
  }
}

class _SectionTitle extends StatelessWidget {
  final String title, subtitle;
  const _SectionTitle({required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(title, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w800, color: Color(0xFF10281E))),
    const SizedBox(height: 3), Text(subtitle, style: const TextStyle(color: Colors.black54)),
  ]);
}

class _BookCard extends StatelessWidget {
  final Book book;
  final Future<void> Function(Book, String) onAdd;
  const _BookCard({required this.book, required this.onAdd});
  @override
  Widget build(BuildContext context) => Card(clipBehavior: Clip.antiAlias, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Expanded(child: Container(width: double.infinity, color: const Color(0xFFE6E0D2),
      child: const Center(child: Icon(Icons.menu_book_rounded, size: 65, color: Color(0xFF10281E))))),
    Padding(padding: const EdgeInsets.fromLTRB(12, 10, 12, 12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(book.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold)),
      Text(book.author, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.black54, fontSize: 12)),
      const SizedBox(height: 8),
      Row(children: [
        Expanded(child: Text('${book.price} FCFA', style: const TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF10281E)))),
        IconButton(onPressed: () => _choose(context), icon: const Icon(Icons.add_shopping_cart), tooltip: 'Ajouter au panier'),
      ]),
    ])),
  ]));

  void _choose(BuildContext context) {
    String format = 'Livre papier';
    showDialog<void>(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, setState) => AlertDialog(
      title: const Text('Choisir le format'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        RadioListTile<String>(value: 'Livre papier', groupValue: format, title: const Text('Livre papier'), subtitle: Text('${book.price} FCFA'), onChanged: (v) => setState(() => format = v!)),
        if (book.hasEbook) RadioListTile<String>(value: 'E-book', groupValue: format, title: const Text('E-book'), subtitle: Text('${book.ebookPrice} FCFA'), onChanged: (v) => setState(() => format = v!)),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
        FilledButton(onPressed: () { Navigator.pop(ctx); onAdd(book, format); }, child: const Text('Ajouter')),
      ],
    )));
  }
}
