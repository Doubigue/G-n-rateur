import 'package:flutter/material.dart';
import '../models/book.dart';

class CatalogScreen extends StatefulWidget {
  final List<Book> books;
  final Future<void> Function(Book, String) onAdd;
  const CatalogScreen({super.key, required this.books, required this.onAdd});
  @override
  State<CatalogScreen> createState() => _CatalogScreenState();
}
class _CatalogScreenState extends State<CatalogScreen> {
  String query = '';
  String category = 'Tous';
  @override
  Widget build(BuildContext context) {
    final categories = ['Tous', ...{...widget.books.map((e) => e.category)}];
    final filtered = widget.books.where((b) =>
      (category == 'Tous' || b.category == category) &&
      ('${b.title} ${b.author}'.toLowerCase().contains(query.toLowerCase()))).toList();
    return Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(16, 16, 16, 8), child: TextField(
        onChanged: (v) => setState(() => query = v),
        decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Rechercher un livre ou un auteur'),
      )),
      SizedBox(height: 52, child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12),
        children: categories.map((c) => Padding(padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6), child: ChoiceChip(
          label: Text(c), selected: category == c, onSelected: (_) => setState(() => category = c),
        ))).toList())),
      Expanded(child: filtered.isEmpty
        ? const Center(child: Text('Aucune publication trouvée.'))
        : GridView.builder(padding: const EdgeInsets.all(14), itemCount: filtered.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: .61, crossAxisSpacing: 12, mainAxisSpacing: 12),
          itemBuilder: (context, i) {
            final b = filtered[i];
            return Card(clipBehavior: Clip.antiAlias, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Expanded(child: Container(width: double.infinity, color: const Color(0xFFE6E0D2), child: const Center(child: Icon(Icons.menu_book, size: 58, color: Color(0xFF10281E))))),
              Padding(padding: const EdgeInsets.all(10), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(b.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold)),
                Text(b.author, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, color: Colors.black54)),
                const SizedBox(height: 6),
                Text('${b.price} FCFA', style: const TextStyle(fontWeight: FontWeight.w800)),
                SizedBox(width: double.infinity, child: FilledButton.tonal(onPressed: () => _choose(context, b), child: const Text('Acheter'))),
              ])),
            ]));
          })),
    ]);
  }

  void _choose(BuildContext context, Book book) {
    String format = 'Livre papier';
    showDialog<void>(context: context, barrierDismissible: false, builder: (ctx) => StatefulBuilder(builder: (ctx, setDialogState) => AlertDialog(
      title: const Text('Choisir le format'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        RadioListTile<String>(value: 'Livre papier', groupValue: format, title: const Text('Livre papier'), subtitle: Text('${book.price} FCFA'), onChanged: (v) => setDialogState(() => format = v!)),
        if (book.hasEbook) RadioListTile<String>(value: 'E-book', groupValue: format, title: const Text('E-book'), subtitle: Text('${book.ebookPrice} FCFA'), onChanged: (v) => setDialogState(() => format = v!)),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
        FilledButton(onPressed: () { Navigator.pop(ctx); widget.onAdd(book, format); }, child: const Text('Ajouter au panier')),
      ],
    )));
  }
}
