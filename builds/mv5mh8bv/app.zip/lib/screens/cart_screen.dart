import 'package:flutter/material.dart';
import '../models/cart_item.dart';

class CartScreen extends StatelessWidget {
  final List<CartItem> items;
  final Map<String, dynamic> profile;
  final ValueChanged<List<CartItem>> onChanged;
  final Future<void> Function(Map<String, dynamic>) onOrder;
  const CartScreen({super.key, required this.items, required this.profile, required this.onChanged, required this.onOrder});

  int get total => items.fold(0, (sum, item) => sum + item.total);

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) return const Center(child: Padding(padding: EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
      Icon(Icons.shopping_bag_outlined, size: 70, color: Color(0xFF8A927F)),
      SizedBox(height: 12), Text('Votre panier est vide', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
      SizedBox(height: 6), Text('Explorez le catalogue pour choisir vos prochaines lectures.', textAlign: TextAlign.center),
    ])));
    return Column(children: [
      Expanded(child: ListView.separated(padding: const EdgeInsets.all(16), itemCount: items.length, separatorBuilder: (_, __) => const SizedBox(height: 8),
        itemBuilder: (context, i) {
          final item = items[i];
          return Card(child: ListTile(
            leading: const CircleAvatar(backgroundColor: Color(0xFFE6E0D2), child: Icon(Icons.menu_book, color: Color(0xFF10281E))),
            title: Text(item.book.title, style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text('${item.format} • ${item.unitPrice} FCFA'),
            trailing: Row(mainAxisSize: MainAxisSize.min, children: [
              IconButton(onPressed: () { if (item.quantity > 1) item.quantity--; else items.removeAt(i); onChanged(List.of(items)); }, icon: const Icon(Icons.remove_circle_outline)),
              Text('${item.quantity}'),
              IconButton(onPressed: () { item.quantity++; onChanged(List.of(items)); }, icon: const Icon(Icons.add_circle_outline)),
            ]),
          ));
        })),
      SafeArea(top: false, child: Container(padding: const EdgeInsets.all(18), decoration: const BoxDecoration(color: Colors.white, border: Border(top: BorderSide(color: Color(0xFFE8E1D5)))), child: Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('Total', style: TextStyle(fontSize: 17)), Text('$total FCFA', style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w800, color: Color(0xFF10281E)))]),
        const SizedBox(height: 12),
        SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: () => _checkout(context), icon: const Icon(Icons.receipt_long), label: const Text('Enregistrer la commande locale'))),
        const SizedBox(height: 5),
        const Text('Prototype local : aucun paiement réel n’est effectué.', style: TextStyle(fontSize: 11, color: Colors.black54)),
      ]))),
    ]);
  }

  Future<void> _checkout(BuildContext context) async {
    if ((profile['email'] as String? ?? '').trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Renseignez votre profil dans l’onglet Compte avant de commander.')));
      return;
    }
    final order = {
      'reference': 'BAO-${DateTime.now().millisecondsSinceEpoch}',
      'createdAt': DateTime.now().toIso8601String(),
      'email': profile['email'],
      'customerName': profile['name'] ?? '',
      'items': items.map((e) => e.toJson()).toList(),
      'total': total,
      'status': 'En attente de paiement',
    };
    await onOrder(order);
    if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Commande enregistrée sur cet appareil.')));
  }
}
