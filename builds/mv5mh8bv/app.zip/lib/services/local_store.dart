import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import '../models/book.dart';
import '../models/cart_item.dart';

class LocalStore {
  static const _fileName = 'baobab_data.json';
  static Future<File> _file() async {
    final dir = await getApplicationDocumentsDirectory();
    return File('${dir.path}/$_fileName');
  }

  static Future<Map<String, dynamic>> _read() async {
    try {
      final file = await _file();
      if (!await file.exists()) return {};
      final decoded = jsonDecode(await file.readAsString());
      return decoded is Map<String, dynamic> ? decoded : {};
    } catch (_) {
      return {};
    }
  }

  static Future<void> _write(Map<String, dynamic> data) async {
    final file = await _file();
    await file.writeAsString(jsonEncode(data), flush: true);
  }

  static Future<List<CartItem>> loadCart() async {
    final data = await _read();
    final rows = data['cart'];
    if (rows is! List) return [];
    return rows.whereType<Map>().map((e) =>
      CartItem.fromJson(Map<String, dynamic>.from(e))).toList();
  }

  static Future<void> saveCart(List<CartItem> items) async {
    final data = await _read();
    data['cart'] = items.map((e) => e.toJson()).toList();
    await _write(data);
  }

  static Future<List<Map<String, dynamic>>> loadOrders() async {
    final data = await _read();
    final rows = data['orders'];
    if (rows is! List) return [];
    return rows.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
  }

  static Future<void> addOrder(Map<String, dynamic> order) async {
    final data = await _read();
    final rows = data['orders'] is List ? List<dynamic>.from(data['orders'] as List) : <dynamic>[];
    rows.insert(0, order);
    data['orders'] = rows;
    data['cart'] = [];
    await _write(data);
  }

  static Future<void> saveProfile(Map<String, dynamic> profile) async {
    final data = await _read();
    data['profile'] = profile;
    await _write(data);
  }

  static Future<Map<String, dynamic>> loadProfile() async {
    final data = await _read();
    final profile = data['profile'];
    return profile is Map ? Map<String, dynamic>.from(profile) : {};
  }

  static Future<void> saveManuscript(Map<String, dynamic> manuscript) async {
    final data = await _read();
    final rows = data['manuscripts'] is List
        ? List<dynamic>.from(data['manuscripts'] as List) : <dynamic>[];
    rows.insert(0, manuscript);
    data['manuscripts'] = rows;
    await _write(data);
  }

  static Future<List<Map<String, dynamic>>> loadManuscripts() async {
    final data = await _read();
    final rows = data['manuscripts'];
    if (rows is! List) return [];
    return rows.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
  }
}
