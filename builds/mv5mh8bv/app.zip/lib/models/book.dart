class Book {
  final String id;
  final String title;
  final String author;
  final String description;
  final int price;
  final int ebookPrice;
  final String category;
  final String coverUrl;
  final bool hasEbook;

  const Book({
    required this.id,
    required this.title,
    required this.author,
    required this.description,
    required this.price,
    required this.ebookPrice,
    required this.category,
    required this.coverUrl,
    this.hasEbook = true,
  });

  Map<String, dynamic> toJson() => {
    'id': id, 'title': title, 'author': author, 'description': description,
    'price': price, 'ebookPrice': ebookPrice, 'category': category,
    'coverUrl': coverUrl, 'hasEbook': hasEbook,
  };

  factory Book.fromJson(Map<String, dynamic> json) => Book(
    id: json['id'] as String? ?? '',
    title: json['title'] as String? ?? 'Sans titre',
    author: json['author'] as String? ?? 'Auteur inconnu',
    description: json['description'] as String? ?? '',
    price: (json['price'] as num?)?.toInt() ?? 5000,
    ebookPrice: (json['ebookPrice'] as num?)?.toInt() ?? 2500,
    category: json['category'] as String? ?? 'Littérature',
    coverUrl: json['coverUrl'] as String? ?? '',
    hasEbook: json['hasEbook'] as bool? ?? false,
  );
}
