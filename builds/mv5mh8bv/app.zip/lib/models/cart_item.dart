import 'book.dart';

class CartItem {
  final Book book;
  final String format;
  int quantity;

  CartItem({required this.book, required this.format, this.quantity = 1});

  int get unitPrice => format == 'E-book' ? book.ebookPrice : book.price;
  int get total => unitPrice * quantity;

  Map<String, dynamic> toJson() => {
    'book': book.toJson(), 'format': format, 'quantity': quantity,
  };

  factory CartItem.fromJson(Map<String, dynamic> json) => CartItem(
    book: Book.fromJson(Map<String, dynamic>.from(json['book'] as Map)),
    format: json['format'] as String? ?? 'Livre papier',
    quantity: (json['quantity'] as num?)?.toInt() ?? 1,
  );
}
