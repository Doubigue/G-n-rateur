package com.virtuelmix.data

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.media.*
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import androidx.media3.common.*
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import kotlinx.coroutines.*
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*
import com.virtuelmix.audio.*

class PlaylistManager(
    private val deckA: ExoPlayer, private val procA: DeckProcessor,
    private val deckB: ExoPlayer, private val procB: DeckProcessor,
    private val scope: CoroutineScope,
    var crossfadeMs: Long = 6000L
) {
    private val queue = kotlin.collections.ArrayDeque<MediaItem>()
    private var active = deckA
    private var fading = false
    private var autoMix = false
    private var fadeJob: Job? = null

    val queueSize: Int get() = queue.size

    private val listener = { p: ExoPlayer ->
        object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                // Filet de sécurité : si le crossfade n'a pas eu lieu (piste très courte)
                if (autoMix && state == Player.STATE_ENDED && p === active && !fading) startNext()
            }
        }
    }

    init {
        deckA.addListener(listener(deckA)); deckB.addListener(listener(deckB))
        // Surveille la fin de piste pour lancer le crossfade en avance (mode auto seulement)
        scope.launch {
            while (isActive) {
                val d = active.duration
                if (autoMix && active.isPlaying && d != C.TIME_UNSET && !fading &&
                    d - active.currentPosition <= crossfadeMs) startNext()
                delay(250)
            }
        }
    }

    fun enqueue(item: MediaItem) { queue.addLast(item) }

    /** Coupe l'auto-mix (chargement manuel) : annule un fondu en cours et remet les gains à 1. */
    fun stopAuto() {
        autoMix = false
        fadeJob?.cancel()
        fading = false
        procA.deckGain = 1f
        procB.deckGain = 1f
    }

    fun startFirst() {
        val first = queue.removeFirstOrNull() ?: return
        stopAuto()
        autoMix = true
        deckA.setMediaItem(first); deckA.prepare(); deckA.play()
        active = deckA
    }

    private fun startNext() {
        if (queue.isEmpty()) return
        val from = active
        val dest = if (from === deckA) deckB else deckA
        if (dest.isPlaying) return                      // ne jamais écraser une platine en lecture
        val next = queue.removeFirst()
        val pFrom = if (from === deckA) procA else procB
        val pTo = if (from === deckA) procB else procA

        fading = true
        pTo.deckGain = 0f
        dest.setMediaItem(next); dest.prepare(); dest.play()
        active = dest

        fadeJob = scope.launch {                          // crossfade à puissance constante
            val steps = 60
            repeat(steps + 1) { i ->
                val t = i / steps.toFloat()
                pFrom.deckGain = cos(t * PI / 2).toFloat()
                pTo.deckGain = sin(t * PI / 2).toFloat()
                delay(crossfadeMs / steps)
            }
            from.pause(); from.seekTo(0)
            pFrom.deckGain = 1f
            fading = false
        }
    }
}
