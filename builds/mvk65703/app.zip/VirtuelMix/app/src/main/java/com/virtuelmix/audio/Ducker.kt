package com.virtuelmix.audio

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.media.*
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import androidx.media3.common.*
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import kotlinx.coroutines.*
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*
import com.virtuelmix.data.*

/** Baisse la musique à ~25 % quand la voix est détectée, remonte en douceur. */
class Ducker(
    private val threshold: Float = 0.02f,   // RMS ~ -34 dBFS
    private val duckedGain: Float = 0.25f,
    private val attackMs: Float = 40f,
    private val releaseMs: Float = 900f,
    private val holdMs: Long = 400L
) {
    @Volatile var musicGain = 1f; private set
    private var lastVoice = 0L

    fun onMicLevel(rms: Float) {
        val now = SystemClock.elapsedRealtime()
        if (rms > threshold) lastVoice = now
        val target = if (now - lastVoice < holdMs) duckedGain else 1f
        val frameMs = 11.6f                                   // 512 échantillons @ 44,1 kHz
        val tau = if (target < musicGain) attackMs else releaseMs
        val a = 1f - exp(-frameMs / tau)
        musicGain += (target - musicGain) * a
    }
}
