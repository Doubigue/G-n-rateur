package com.virtuelmix.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.virtuelmix.audio.DeckProcessor

fun displayName(ctx: Context, uri: Uri): String {
    val name = runCatching {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }.getOrNull() ?: "Morceau"
    return name.substringBeforeLast('.')
}

/** État d'une platine côté interface. */
class DeckUi(val name: String, val player: ExoPlayer, val proc: DeckProcessor, val color: Color) {
    var title by mutableStateOf("Aucun morceau")
    var presetName by mutableStateOf("Flat")
    var speed by mutableFloatStateOf(1f)
    var pitchPct: Float
        get() = (speed - 1f) * 100f
        set(v) { speed = 1f + v / 100f }
    var baseBpm by mutableFloatStateOf(0f)
    var playing by mutableStateOf(false)
    var loopOn by mutableStateOf(false)
    var echo by mutableStateOf(false)
    var channel by mutableFloatStateOf(0.85f)
    var progress by mutableFloatStateOf(0f)
    var vu by mutableFloatStateOf(0f)
    var waveTick by mutableIntStateOf(0)
    val wave = FloatArray(140)
    val cues = mutableStateListOf(-1L, -1L, -1L, -1L)
    var loopStart = 0L
    var loopLen = 4000L
    private val taps = ArrayList<Long>()

    init {
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onPlayerError(error: PlaybackException) { title = "Erreur de lecture : fichier non pris en charge" }
        })
    }

    fun effBpm(): Float = if (baseBpm > 0f) baseBpm * (1f + pitchPct / 100f) else 0f

    fun applyPitch() {
        player.playbackParameters = PlaybackParameters(1f + pitchPct / 100f, 1f)
    }

    fun bump(delta: Float) {
        pitchPct = (Math.round((pitchPct + delta) * 10f) / 10f).coerceIn(-12f, 12f)
        applyPitch()
    }

    /** Poussoir BPM : monte ou descend le tempo effectif (30 à 1000 BPM). Sans BPM connu, on part de 120. */
    fun pushBpm(delta: Float) {
        if (baseBpm <= 0f) baseBpm = 120f
        val target = (effBpm() + delta).coerceIn(30f, 1000f)
        speed = (target / baseBpm).coerceIn(0.25f, 30f)
        applyPitch()
    }

    fun tapTempo() {
        val now = System.currentTimeMillis()
        if (taps.isNotEmpty() && now - taps.last() > 2000) taps.clear()
        taps.add(now)
        while (taps.size > 6) taps.removeAt(0)
        if (taps.size >= 2) {
            val avg = (taps.last() - taps.first()).toFloat() / (taps.size - 1)
            baseBpm = (60000f / avg) / (1f + pitchPct / 100f)
        }
    }

    fun syncTo(o: DeckUi) {
        val target = o.effBpm()
        if (target > 0f && baseBpm > 0f) {
            speed = (target / baseBpm).coerceIn(0.25f, 30f)
            applyPitch()
        }
    }

    fun toggle() {
        if (player.mediaItemCount == 0) return
        if (player.isPlaying) player.pause() else {
            if (player.playbackState == Player.STATE_ENDED) player.seekTo(0)
            player.play()
        }
    }

    fun cue() { player.pause(); player.seekTo(0) }

    fun toggleLoop() {
        if (loopOn) { loopOn = false; return }
        loopStart = player.currentPosition
        val b = effBpm()
        loopLen = if (b > 0f) (4 * 60000f / b).toLong() else 4000L
        loopOn = true
    }

    fun cueTap(i: Int) {
        val p = cues[i]
        val pos = player.currentPosition
        if (p < 0) cues[i] = pos
        else if (pos - p in -300L..1500L) cues[i] = -1L      // on est sur le point : on l'éteint
        else player.seekTo(p)                                 // sinon on saute dessus
    }

    fun cueClear(i: Int) { cues[i] = -1L }

    fun load(ctx: Context, uri: Uri) {
        runCatching { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        proc.deckGain = 1f
        player.stop()
        player.clearMediaItems()
        player.setMediaItem(MediaItem.fromUri(uri))
        player.prepare()
        player.play()
        title = displayName(ctx, uri)
        baseBpm = 0f
        loopOn = false
        for (i in cues.indices) cues[i] = -1L
    }

    /** Appelé ~30 fois par seconde : progression, boucle, niveaux et forme d'onde en direct. */
    fun tick() {
        val d = player.duration
        progress = if (d > 0) (player.currentPosition.toFloat() / d).coerceIn(0f, 1f) else 0f
        if (loopOn && player.currentPosition >= loopStart + loopLen) player.seekTo(loopStart)
        val l = if (playing) proc.level else 0f
        vu = maxOf(l, vu * 0.82f)
        System.arraycopy(wave, 1, wave, 0, wave.size - 1)
        wave[wave.size - 1] = vu
        waveTick++
    }
}
