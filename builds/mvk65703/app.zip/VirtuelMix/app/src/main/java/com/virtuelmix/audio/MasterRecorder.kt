package com.virtuelmix.audio

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.media.*
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import androidx.media3.common.*
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import kotlinx.coroutines.*
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*
import com.virtuelmix.data.*
import com.naman14.androidlame.AndroidLame
import com.naman14.androidlame.LameBuilder

class MasterRecorder(
    private val storage: RecordingStorage,
    private val bus: MixBus,
    private val sampleRate: Int = 44100,
    private val channels: Int = 2
) {
    @Volatile private var running = false
    private var thread: Thread? = null

    fun start() {
        if (running) return
        running = true
        thread = Thread { record() }.also { it.start() }
    }

    fun stop() {
        running = false
        thread?.join()
        thread = null
    }

    /** Limiteur doux : évite la saturation dure quand les deux platines + la voix s'additionnent. */
    private fun toShort(x: Float): Short {
        val a = abs(x)
        val y = if (a <= 0.8f) x else sign(x) * (0.8f + 0.2f * tanh((a - 0.8f) / 0.2f))
        return (y * 32767f).toInt().toShort()
    }

    private fun record() {
        val frames = 1024
        val mixed = FloatArray(frames * channels)

        // Encodeur MP3 320 kbps stéréo (LAME, qualité 3). Si indisponible, on enregistre en WAV.
        val lame: AndroidLame? = try {
            LameBuilder()
                .setInSampleRate(sampleRate)
                .setOutChannels(2)
                .setOutBitrate(320)
                .setOutSampleRate(sampleRate)
                .setMode(LameBuilder.Mode.STEREO)
                .setQuality(3)
                .build()
        } catch (t: Throwable) { null }
        val mp3 = lame != null

        val target = if (mp3) storage.create("mp3", "audio/mpeg") else storage.create("wav", "audio/wav")
        val channel = FileOutputStream(target.pfd.fileDescriptor).channel
        if (!mp3) channel.write(ByteBuffer.wrap(wavHeader(0)))

        val left = ShortArray(frames)
        val right = ShortArray(frames)
        val mp3buf = ByteArray((1.25 * frames + 7200).toInt())
        val pcm = ByteBuffer.allocate(frames * channels * 2).order(ByteOrder.LITTLE_ENDIAN)
        var dataLen = 0L

        Thread.sleep(150)                                   // petite avance pour éviter les trous
        val periodNs = frames * 1_000_000_000L / sampleRate
        var next = System.nanoTime()
        while (running) {
            bus.pullMixed(mixed)
            if (mp3) {
                for (i in 0 until frames) {
                    left[i] = toShort(mixed[2 * i])
                    right[i] = toShort(mixed[2 * i + 1])
                }
                val n = lame!!.encode(left, right, frames, mp3buf)
                if (n > 0) channel.write(ByteBuffer.wrap(mp3buf, 0, n))
            } else {
                pcm.clear()
                for (s in mixed) pcm.putShort(toShort(s))
                pcm.flip()
                dataLen += channel.write(pcm)
            }
            next += periodNs
            val waitMs = (next - System.nanoTime()) / 1_000_000L
            if (waitMs > 0) Thread.sleep(waitMs)
        }

        if (mp3) {
            val n = lame!!.flush(mp3buf)
            if (n > 0) channel.write(ByteBuffer.wrap(mp3buf, 0, n))
            lame.close()
        } else {
            channel.position(0)
            channel.write(ByteBuffer.wrap(wavHeader(dataLen)))
        }
        channel.close()
        target.pfd.close()
        storage.finish(target.uri)
    }

    private fun wavHeader(dataLen: Long): ByteArray {
        val byteRate = sampleRate * channels * 2
        return ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN).apply {
            put("RIFF".toByteArray()); putInt((36 + dataLen).toInt())
            put("WAVEfmt ".toByteArray()); putInt(16)
            putShort(1); putShort(channels.toShort())
            putInt(sampleRate); putInt(byteRate)
            putShort((channels * 2).toShort()); putShort(16)
            put("data".toByteArray()); putInt(dataLen.toInt())
        }.array()
    }
}
