package com.virtuelmix.audio

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.media.*
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import androidx.media3.common.*
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import kotlinx.coroutines.*
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*
import com.virtuelmix.data.*

class Biquad {
    private var b0 = 1f; private var b1 = 0f; private var b2 = 0f
    private var a1 = 0f; private var a2 = 0f
    private val z1 = FloatArray(2); private val z2 = FloatArray(2)   // état par canal

    fun process(x: Float, ch: Int): Float {
        val y = b0 * x + z1[ch]
        z1[ch] = b1 * x - a1 * y + z2[ch]
        z2[ch] = b2 * x - a2 * y
        return y
    }

    // Formules RBJ (Audio EQ Cookbook)
    fun lowShelf(fs: Int, f0: Float, gainDb: Float, s: Float = 1f) =
        shelf(fs, f0, gainDb, s, low = true)
    fun highShelf(fs: Int, f0: Float, gainDb: Float, s: Float = 1f) =
        shelf(fs, f0, gainDb, s, low = false)

    private fun shelf(fs: Int, f0: Float, gainDb: Float, s: Float, low: Boolean) {
        val A = 10.0.pow(gainDb / 40.0)
        val w = 2 * PI * f0 / fs
        val cw = cos(w); val sw = sin(w)
        val alpha = sw / 2 * sqrt((A + 1 / A) * (1 / s - 1) + 2)
        val t = 2 * sqrt(A) * alpha
        val n: Double
        if (low) {
            n = (A + 1) + (A - 1) * cw + t
            set(A * ((A + 1) - (A - 1) * cw + t) / n,
                2 * A * ((A - 1) - (A + 1) * cw) / n,
                A * ((A + 1) - (A - 1) * cw - t) / n,
                -2 * ((A - 1) + (A + 1) * cw) / n,
                ((A + 1) + (A - 1) * cw - t) / n)
        } else {
            n = (A + 1) - (A - 1) * cw + t
            set(A * ((A + 1) + (A - 1) * cw + t) / n,
                -2 * A * ((A - 1) + (A + 1) * cw) / n,
                A * ((A + 1) + (A - 1) * cw - t) / n,
                2 * ((A - 1) - (A + 1) * cw) / n,
                ((A + 1) - (A - 1) * cw - t) / n)
        }
    }

    fun peaking(fs: Int, f0: Float, gainDb: Float, q: Float) {
        val A = 10.0.pow(gainDb / 40.0)
        val w = 2 * PI * f0 / fs
        val alpha = sin(w) / (2 * q); val cw = cos(w)
        val n = 1 + alpha / A
        set((1 + alpha * A) / n, -2 * cw / n, (1 - alpha * A) / n,
            -2 * cw / n, (1 - alpha / A) / n)
    }

    private fun set(b0: Double, b1: Double, b2: Double, a1: Double, a2: Double) {
        this.b0 = b0.toFloat(); this.b1 = b1.toFloat(); this.b2 = b2.toFloat()
        this.a1 = a1.toFloat(); this.a2 = a2.toFloat()
    }
}

data class EqPreset(val name: String, val lowDb: Float, val midDb: Float, val highDb: Float) {
    companion object {
        val FLAT = EqPreset("Flat", 0f, 0f, 0f)
        // Jazz : basses chaudes, médiums légèrement creusés, aigus aérés
        val JAZZ = EqPreset("Jazz", +3.0f, -1.0f, +2.5f)
        val ALL = listOf(FLAT, JAZZ)
    }
}

class EqProcessor(private val sampleRate: Int) {
    private val low = Biquad(); private val mid = Biquad(); private val high = Biquad()

    fun apply(p: EqPreset) = set(p.lowDb, p.midDb, p.highDb)

    fun set(lowDb: Float, midDb: Float, highDb: Float) {
        low.lowShelf(sampleRate, 100f, lowDb)
        mid.peaking(sampleRate, 1000f, midDb, 0.8f)
        high.highShelf(sampleRate, 8000f, highDb)
    }

    fun process(x: Float, ch: Int) = high.process(mid.process(low.process(x, ch), ch), ch)
}
