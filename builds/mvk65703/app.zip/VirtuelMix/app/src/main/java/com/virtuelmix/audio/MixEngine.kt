package com.virtuelmix.audio

import android.content.Context
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import com.virtuelmix.data.PlaylistManager
import com.virtuelmix.data.RecordingStorage
import kotlinx.coroutines.CoroutineScope

/** Time-stretch (pitch sans changer la tonalité) puis EQ/effets/tap : l'enregistrement suit le pitch. */
class DeckChain(private val tap: AudioProcessor) : DefaultAudioSink.AudioProcessorChain {
    private val sonic = SonicAudioProcessor()
    override fun getAudioProcessors(): Array<AudioProcessor> = arrayOf(sonic, tap)
    override fun applyPlaybackParameters(playbackParameters: PlaybackParameters): PlaybackParameters {
        sonic.setSpeed(playbackParameters.speed)
        sonic.setPitch(playbackParameters.pitch)
        return playbackParameters
    }
    override fun applySkipSilenceEnabled(skipSilenceEnabled: Boolean): Boolean = false
    override fun getMediaDuration(playoutDuration: Long): Long =
        if (sonic.isActive) sonic.getMediaDuration(playoutDuration) else playoutDuration
    override fun getSkippedOutputFrameCount(): Long = 0L
}

class MixEngine(private val ctx: Context, scope: CoroutineScope) {
    val bus = MixBus()
    val ducker = Ducker()
    val procA = DeckProcessor("A", bus, ducker)
    val procB = DeckProcessor("B", bus, ducker)
    val deckA = newDeck(procA)
    val deckB = newDeck(procB)
    val playlist = PlaylistManager(deckA, procA, deckB, procB, scope)
    val recorder = MasterRecorder(RecordingStorage(ctx), bus)
    val mic = MicEngine(bus, ducker)

    private fun newDeck(p: DeckProcessor): ExoPlayer =
        ExoPlayer.Builder(ctx).setRenderersFactory(object : DefaultRenderersFactory(ctx) {
            override fun buildAudioSink(
                context: Context, enableFloatOutput: Boolean, enableAudioTrackPlaybackParams: Boolean
            ): AudioSink = DefaultAudioSink.Builder(context).setAudioProcessorChain(DeckChain(p)).build()
        }).build()

    fun setEq(p: DeckProcessor, preset: EqPreset) {
        p.preset = preset
        p.equalizer?.apply(preset)
    }

    fun release() {
        mic.stop(); recorder.stop(); deckA.release(); deckB.release()
    }
}
