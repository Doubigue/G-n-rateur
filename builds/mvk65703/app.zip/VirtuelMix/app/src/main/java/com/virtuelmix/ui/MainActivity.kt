package com.virtuelmix.ui

import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.virtuelmix.audio.MixEngine

class MixViewModel(app: Application) : AndroidViewModel(app) {
    val engine = MixEngine(app, viewModelScope)
    val a = DeckUi("A", engine.deckA, engine.procA, Color(0xFF22D3EE))
    val b = DeckUi("B", engine.deckB, engine.procB, Color(0xFFF43F8E))
    var cross by mutableFloatStateOf(0.5f)
    val fades = listOf(3000L, 6000L, 10000L)
    var fadeIdx by mutableIntStateOf(1)
    var rec by mutableStateOf(false)
    var talk by mutableStateOf(false)
    var recStart by mutableLongStateOf(0L)
    var now by mutableLongStateOf(0L)

    init { applyGains() }

    /** Crossfader classique : au centre les deux voies sont à fond, on coupe l'autre côté. */
    fun applyGains() {
        a.proc.userGain = a.channel * minOf(1f, 2f * (1f - cross))
        b.proc.userGain = b.channel * minOf(1f, 2f * cross)
    }

    fun sync() {
        if (a.effBpm() > 0f && b.baseBpm > 0f) b.syncTo(a)
        else if (b.effBpm() > 0f && a.baseBpm > 0f) a.syncTo(b)
    }

    override fun onCleared() = engine.release()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        WindowInsetsControllerCompat(window, window.decorView).let {
            it.hide(WindowInsetsCompat.Type.navigationBars())
            it.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(color = Color(0xFF0B0C10)) { MixScreen() }
            }
        }
    }
}
