package com.virtuelmix.audio

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.media.*
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import androidx.media3.common.*
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import kotlinx.coroutines.*
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*
import com.virtuelmix.data.*

/** Bus interne : un ring buffer float par source (deckA, deckB, mic). */
class MixBus(private val capacity: Int = 44100 * 2 * 2) {
    private class Ring(cap: Int) {
        val buf = FloatArray(cap); var r = 0; var w = 0; var size = 0
        @Synchronized fun push(src: FloatArray, n: Int) {
            for (i in 0 until n) {
                if (size == buf.size) { r = (r + 1) % buf.size; size-- }  // écrase l'ancien
                buf[w] = src[i]; w = (w + 1) % buf.size; size++
            }
        }
        @Synchronized fun pullAdd(dst: FloatArray) {
            for (i in dst.indices) {
                if (size == 0) return                      // sous-débit = silence
                dst[i] += buf[r]; r = (r + 1) % buf.size; size--
            }
        }
    }
    private val rings = mutableMapOf<String, Ring>()
    private fun ring(id: String) = synchronized(rings) { rings.getOrPut(id) { Ring(capacity) } }

    fun push(id: String, samples: FloatArray, n: Int) = ring(id).push(samples, n)
    fun pullMixed(out: FloatArray) {
        out.fill(0f)
        synchronized(rings) { rings.values.toList() }.forEach { it.pullAdd(out) }
    }
}
