package com.linguavibe.app.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.setValue

/** Progression de l'apprenant, enregistrée localement (SharedPreferences). */
class ProgressStore(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("progress", Context.MODE_PRIVATE)

    var xp by mutableIntStateOf(sp.getInt("xp", 0))
        private set
    var streak by mutableIntStateOf(sp.getInt("streak", 0))
        private set

    /** identifiant de leçon -> meilleur score au quiz (0..100) */
    val scores = mutableStateMapOf<String, Int>()

    init {
        sp.all.forEach { (key, value) ->
            if (key.startsWith("score_") && value is Int) scores[key.removePrefix("score_")] = value
        }
        // La série est perdue si plus d'un jour s'est écoulé.
        val last = sp.getLong("lastDay", -1L)
        if (last >= 0 && today() - last > 1) {
            streak = 0
            sp.edit().putInt("streak", 0).apply()
        }
    }

    private fun today(): Long = System.currentTimeMillis() / 86_400_000L

    fun isCompleted(lessonId: String): Boolean = (scores[lessonId] ?: -1) >= PASS_SCORE

    fun bestScore(lessonId: String): Int? = scores[lessonId]

    /** Enregistre le résultat d'un quiz et renvoie les XP gagnés. */
    fun recordQuiz(lessonId: String, score: Int): Int {
        val previous = scores[lessonId]
        val gained = when {
            score < PASS_SCORE -> 5
            previous == null || previous < PASS_SCORE -> 50 + score / 2
            else -> 10
        }
        if (previous == null || score > previous) scores[lessonId] = score
        xp += gained
        touchStreak()
        sp.edit()
            .putInt("score_$lessonId", scores[lessonId] ?: score)
            .putInt("xp", xp)
            .apply()
        return gained
    }

    fun addXp(amount: Int) {
        xp += amount
        touchStreak()
        sp.edit().putInt("xp", xp).apply()
    }

    private fun touchStreak() {
        val day = today()
        val last = sp.getLong("lastDay", -1L)
        if (last == day) return
        streak = if (last == day - 1) streak + 1 else 1
        sp.edit().putLong("lastDay", day).putInt("streak", streak).apply()
    }

    fun homeworkAnswer(key: String): String = sp.getString("hw_$key", "") ?: ""

    fun saveHomework(key: String, text: String) {
        sp.edit().putString("hw_$key", text).apply()
    }

    companion object {
        const val PASS_SCORE = 70
    }
}
