# LinguaVibe — application Android d'apprentissage des langues

Kotlin + Jetpack Compose. Reconnaissance vocale **hors ligne** avec Vosk pour corriger la prononciation.

## Contenu

- **Espagnol : 36 leçons, du niveau A1 au niveau C2.**
- **Anglais : 36 leçons, du niveau A1 au niveau C2.**
- **Russe : 36 leçons, du niveau A1 au niveau C2** (alphabet cyrillique et prononciation dès la première leçon).
- **Portugais (du Brésil) : 36 leçons, du niveau A1 au niveau C2.**
- **Chinois mandarin : 36 leçons, du niveau A1 au niveau C2** (pinyin partout ; réponses écrites en caractères ou en pinyin).
- **Français (langue maternelle)** : pas de cours, mais son modèle vocal permet de répondre à voix haute
  en français dans les quiz d'écoute.
- **Arabe (standard moderne) : 36 leçons, du niveau A1 au niveau C2** (alphabet et prononciation dès la première
  leçon ; transcription en lettres latines partout ; réponses écrites en arabe ou en lettres latines ;
  parlers d'Égypte, du Levant, du Maghreb et du Golfe abordés aux niveaux C1 et C2).

Chaque leçon de chaque langue a son texte de lecture (216 textes au total), et tous les mots, exemples, dialogues, phrases et textes ont leur prononciation figurée « à la française » (pinyin pour le chinois, transcription latine pour l'arabe).

Les six langues suivent la même progression : 8 leçons A1, 7 A2, 8 B1, 6 B2, 5 C1 et 2 C2, soit pour chacune
288 mots illustrés, 72 points de grammaire, 36 dialogues, 233 questions de quiz, 72 devoirs et 144 phrases à prononcer.

Chaque leçon comporte six étapes :

| Étape | Ce qu'on y fait |
|---|---|
| 📖 Leçon | Bandeau illustré animé, cartes de vocabulaire qui se retournent, grammaire avec exemples à écouter |
| 📰 Lecture | Un texte suivi à lire et à écouter phrase par phrase, avec prononciation figurée, traduction et micro pour le lire à voix haute |
| 💬 Dialogue | Jeu de rôle : l'application joue un personnage, vous dites les répliques de l'autre au micro |
| 🎤 Prononciation | Écoute (normale ou lente), enregistrement, correction mot à mot (vert / orange / rouge) et score |
| ❓ Quiz | Choix multiples, compréhension orale, traduction écrite ; 70 % pour valider la leçon |
| 📝 Devoir | Questions ouvertes (écrites ou dictées), vérification des éléments clés et réponse modèle |

## Signature

L'application a sa propre clé de signature : `signing/linguavibe.jks` (mots de passe dans `signing/keystore.properties`).
Les APK debug et release sont signés avec elle.

| | |
|---|---|
| Package | `com.linguavibe.app` |
| Alias | `linguavibe` |
| SHA-1 | `62:8D:76:55:25:D2:1B:DB:00:94:5F:ED:BA:10:06:27:9B:F9:A5:AA` |
| SHA-256 | `6C:02:AE:04:0E:4D:62:DE:1E:C3:3D:18:3B:03:C8:97:5C:83:97:46:31:D8:C7:6E:E7:CB:F2:4A:2A:22:B6:47` |

- **Firebase** : Paramètres du projet › Vos applications › Android `com.linguavibe.app` › « Ajouter une empreinte » : collez le SHA-1
  et le SHA-256 (utile si la clé API est restreinte aux applications Android).
- **Gardez une copie de `signing/` hors du dépôt** (clé USB, coffre de mots de passe) : sans cette clé, impossible de
  publier une mise à jour de l'appli sous le même nom.
- Dépôt GitHub public : retirez `signing/` du dépôt et définissez les secrets `SIGNING_STORE_PASSWORD` et
  `SIGNING_KEY_PASSWORD`. En dépôt privé, les fichiers fournis suffisent.

## Compiler l'APK

**Avec GitHub Actions** : poussez ce dossier dans un dépôt GitHub. Le workflow `.github/workflows/build.yml`
compile l'APK ; il se télécharge dans l'onglet *Actions* (artefact `LinguaVibe-release`, APK signé).

**Avec Android Studio** : ouvrez le dossier, laissez Gradle se synchroniser, puis *Run*.

**En ligne de commande** (JDK 17, Gradle 8.7 ou plus, SDK Android 34) : `gradle assembleRelease`

## Modèles vocaux Vosk

Dans l'application : accueil › **Modèles vocaux**. Pour chaque langue, deux possibilités :

1. **Télécharger** : l'application récupère le modèle recommandé.
2. **Importer un ZIP** : choisissez un fichier `.zip` déjà téléchargé sur <https://alphacephei.com/vosk/models>.
   Tout modèle Vosk est accepté (le ZIP doit contenir les dossiers `am/`, `conf/`, `graph/`).

| Langue | Précision maximale | Taille | Alternative pour téléphone | Taille |
|---|---|---|---|---|
| Espagnol | `vosk-model-es-0.42` | 1,4 Go | `vosk-model-small-es-0.42` | 39 Mo |
| Anglais | `vosk-model-en-us-0.22` | 1,8 Go | `vosk-model-en-us-0.22-lgraph` (128 Mo) ou `vosk-model-small-en-us-0.15` | 40 Mo |
| Russe | `vosk-model-ru-0.42` | 1,8 Go | `vosk-model-small-ru-0.22` | 45 Mo |
| Français | `vosk-model-fr-0.22` | 1,4 Go | `vosk-model-small-fr-0.22` | 41 Mo |
| Portugais | `vosk-model-pt-fb-v0.1.1-20220516_2113` | 1,6 Go | `vosk-model-small-pt-0.3` | 31 Mo |
| Chinois | `vosk-model-cn-0.22` | 1,3 Go | `vosk-model-small-cn-0.22` | 42 Mo |
| Arabe | `vosk-model-ar-0.22-linto-1.1.0` | 1,3 Go | `vosk-model-ar-mgb2-0.4` | 318 Mo |

**Attention :** les modèles complets sont conçus pour des serveurs. D'après la documentation Vosk, ils peuvent
demander jusqu'à 16 Go de mémoire, contre environ 300 Mo pour un petit modèle. Sur la plupart des téléphones,
l'application risque de se fermer au chargement : installez alors l'alternative. Un seul modèle est conservé
par langue (le nouveau remplace l'ancien). Le téléchargement exige environ 2,3 fois la taille du ZIP en espace libre.

La voix qui lit les exemples est la synthèse vocale d'Android : installez la voix de la langue dans
Paramètres › Synthèse vocale si elle manque.

## Voix hors ligne : Kokoro et Piper

Accueil › **Paramètres** › « Voix hors ligne ». Les voix ne sont **pas** incluses dans l'application ni dans le dépôt :
on les télécharge **une seule fois** depuis l'application (bouton « Installer »), puis elles fonctionnent sans connexion.

| Voix | Langues | Taille |
|---|---|---|
| Kokoro multilingue (`kokoro-multi-lang-v1_0`) | espagnol, anglais, portugais du Brésil, chinois, français ; voix féminine ou masculine | plus de 300 Mo |
| Piper (`vits-piper-…`) | une voix par langue, y compris le **russe** et l'**arabe** (que Kokoro ne parle pas) | ≈ 25 à 65 Mo |

- Le réglage « Voix utilisée » choisit l'ordre : automatique (ElevenLabs si configuré, puis Kokoro, Piper, voix du téléphone),
  Kokoro d'abord, Piper d'abord, ElevenLabs d'abord ou toujours la voix du téléphone.
- Le mode lent est calculé par la voix elle-même (plus naturel qu'un simple ralenti).
- Chaque phrase calculée est gardée sur le téléphone : la réécoute est immédiate.

Le moteur qui fait tourner ces voix est la bibliothèque **sherpa-onnx** : `app/build.gradle.kts` la télécharge
automatiquement dans `app/libs/` à la première compilation (GitHub Actions ou Android Studio, connexion nécessaire).

## Voix réaliste (ElevenLabs)

Accueil › **Paramètres** : collez une clé API ElevenLabs, touchez « Charger mes voix » et choisissez une voix.
Les mots, les exemples et les dialogues sont alors lus par une voix naturelle dans toutes les langues, et le bouton
**« Écouter toute la leçon »** lit la leçon d'un bout à l'autre.

- Chaque phrase n'est demandée qu'une fois à ElevenLabs, puis relue depuis le téléphone (pas de crédits consommés à la réécoute).
- Sans clé, sans connexion ou en cas de quota dépassé, l'application revient à la voix d'Android.
- La clé est enregistrée dans les données privées de l'application ; elle n'est pas dans le code source.

## Cours en ligne avec Firebase (utilisables hors ligne)

Accueil › **☁️ Données Firebase** :

1. **Importer le fichier de configuration** : `google-services.json` (Firebase › Paramètres du projet › Vos applications)
   ou la configuration Web. Ses paramètres remplissent le formulaire (ID du projet, clé API, ID de l'app, URL de la base) ;
   on peut les corriger à la main, puis **Enregistrer**.
2. **Tester** la connexion, puis **Télécharger les cours** : ils sont enregistrés sur le téléphone (`files/courses/`)
   et restent disponibles **sans connexion**. L'option « Mettre à jour au démarrage » les rafraîchit à chaque lancement.
3. « Revenir aux cours intégrés » supprime les cours téléchargés.

L'application utilise l'API REST de Firebase : pas de plugin Google à compiler, n'importe quel projet Firebase convient.

**Préparer Firebase** (une fois) : créez une *Realtime Database* ; dans *Authentication*, activez **Anonyme** (lecture
par l'application) et **E-mail/Mot de passe** (administration) ; collez les règles de `firebase/database.rules.json`
en remplaçant l'UID par celui du compte administrateur (Authentication › Utilisateurs).

Organisation des données dans la base :

```
linguavibe/
  meta      { version, updatedAt }
  courses/  { es: { lang, lessons: [...] }, en: {...}, pt, ru, zh, ar }
```

## Ajouter des leçons ou une langue

Prononciation figurée : `content/<code>/prononciation.txt`, produit par `tools/pron_<code>.py` (les lignes corrigées à la main sont conservées) (une ligne `texte = prononciation`, syllabe accentuée
en MAJUSCULES). Textes de lecture : `content/<code>/lecture.txt`. Le format est décrit en tête de `tools/build_course.py`.


Les cours sont écrits dans `content/<code>/*.txt` (format expliqué en tête de `tools/build_course.py`),
puis convertis en JSON :

```
python3 tools/build_course.py es
```

Pour ouvrir une nouvelle langue : ajoutez-la à la liste de `app/src/main/java/com/linguavibe/app/data/Models.kt`
(code, voix, modèles Vosk, `available = true`), créez `content/<code>/…`, puis lancez `python3 tools/build_course.py <code>`.

## Organisation du code

```
app/src/main/java/com/linguavibe/app/
  MainActivity.kt
  data/Models.kt           langues, structure des cours, lecture du JSON
  data/ProgressStore.kt    XP, série de jours, scores, devoirs
  speech/VoskManager.kt    import / téléchargement des modèles, écoute du micro
  speech/Pronunciation.kt  correction mot à mot et score
  speech/Speaker.kt        lecture à voix haute (ElevenLabs ou voix d'Android)
  speech/ElevenLabs.kt     appels à l'API ElevenLabs, réglages, cache audio
  speech/NeuralVoices.kt   voix hors ligne Kokoro / Piper : installation et synthèse
  ui/SettingsScreen.kt     paramètres : moteur de voix, clé API, voix, modèle
  ui/VoicesSettings.kt     installation des voix Kokoro / Piper
  ui/Screens.kt            accueil, parcours, gestion des modèles
  ui/LessonScreen.kt       les six étapes d'une leçon
  ui/Motion.kt             animations (bandeaux, cartes, micro, confettis)
```
