package com.example.assistant

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.ImageView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlin.math.hypot

/**
 * Foreground Service qui affiche la bulle flottante et orchestre l'assistant :
 *  - 1 clic  : écoute vocale hors-ligne (Vosk) -> analyse -> exécution -> réponse vocale
 *  - 3 clics : alarme SOS (sirène locale en boucle, re-triple-clic pour l'arrêter)
 *  - glisser : déplace la bulle verticalement, elle se recolle au bord droit
 */
class FloatingWidgetService : Service() {

    private enum class State(val color: Int) {
        IDLE(Color.parseColor("#1E88E5")),
        LISTENING(Color.parseColor("#43A047")),
        SPEAKING(Color.parseColor("#FB8C00")),
        SOS(Color.parseColor("#E53935"))
    }

    private lateinit var windowManager: WindowManager
    private lateinit var params: WindowManager.LayoutParams
    private var bubble: ImageView? = null
    private val bubbleBg = GradientDrawable().apply { shape = GradientDrawable.OVAL }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var speaker: AssistantSpeaker
    private lateinit var engine: VoskEngine
    private lateinit var executor: CommandExecutor
    private val parser = VoiceCommandParser()

    private var state = State.IDLE
    private var tapCount = 0
    private var siren: MediaPlayer? = null
    private var savedAlarmVolume = -1

    // Après la fenêtre de clics : 1 ou 2 clics = clic simple (le 3e clic est traité immédiatement)
    private val tapRunnable = Runnable {
        val n = tapCount
        tapCount = 0
        if (n in 1..2) onSingleTap()
    }

    // ------------------------------------------------------------------ cycle de vie

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        startInForeground()

        if (!Settings.canDrawOverlays(this)) {   // permission retirée entre-temps
            stopSelf()
            return
        }

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        speaker = AssistantSpeaker(this)
        engine = VoskEngine(this)
        executor = CommandExecutor(
            this, NoteManager(this), SystemStatusReporter(this), TorchController(this)
        )
        engine.loadAsync { ok ->
            if (!ok) speaker.speak("Le modèle vocal est introuvable. Consultez le fichier lisez-moi.")
        }
        createBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) stopSelf()
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        isRunning = false
        handler.removeCallbacksAndMessages(null)
        if (::engine.isInitialized) engine.release()
        if (::speaker.isInitialized) speaker.shutdown()
        stopSiren()
        bubble?.let { runCatching { windowManager.removeView(it) } }
        bubble = null
        super.onDestroy()
    }

    // ------------------------------------------------------------------ notification

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Assistant vocal", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, FloatingWidgetService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle("Assistant actif")
            .setContentText("Touchez la bulle pour parler · 3 clics = SOS")
            .setContentIntent(open)
            .addAction(0, "Arrêter", stop)
            .setOngoing(true)
            .build()
        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
        ServiceCompat.startForeground(this, NOTIF_ID, notification, type)
    }

    // ------------------------------------------------------------------ bulle flottante

    @SuppressLint("ClickableViewAccessibility")
    private fun createBubble() {
        val metrics = resources.displayMetrics
        val size = (56 * metrics.density).toInt()
        val pad = (14 * metrics.density).toInt()
        val slop = ViewConfiguration.get(this).scaledTouchSlop

        val view = ImageView(this).apply {
            setImageResource(R.drawable.ic_mic)
            setPadding(pad, pad, pad, pad)
            background = bubbleBg
            elevation = 8 * metrics.density
        }
        params = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = metrics.widthPixels - size            // bord droit
            y = metrics.heightPixels / 3
        }

        var startX = 0; var startY = 0
        var touchX = 0f; var touchY = 0f
        var moved = false

        view.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - touchX
                    val dy = e.rawY - touchY
                    if (!moved && hypot(dx, dy) > slop) moved = true
                    if (moved) {
                        params.x = (startX + dx).toInt()
                        params.y = (startY + dy).toInt().coerceIn(0, metrics.heightPixels - size)
                        windowManager.updateViewLayout(v, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {                       // se recolle au bord droit
                        params.x = metrics.widthPixels - size
                        windowManager.updateViewLayout(v, params)
                    } else {
                        v.performClick()
                        registerTap(v)
                    }
                    true
                }
                else -> false
            }
        }

        bubble = view
        windowManager.addView(view, params)
        setState(State.IDLE)
    }

    // ------------------------------------------------------------------ détection des clics

    private fun registerTap(v: android.view.View) {
        v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        tapCount++
        handler.removeCallbacks(tapRunnable)
        if (tapCount >= 3) {                   // TRIPLE CLIC RAPIDE -> SOS immédiat
            tapCount = 0
            toggleSos()
        } else {
            handler.postDelayed(tapRunnable, TAP_WINDOW_MS)
        }
    }

    private fun onSingleTap() {
        if (siren != null) return              // pendant le SOS, seul le triple clic agit
        if (state == State.LISTENING) {        // 2e clic = annuler l'écoute
            engine.cancel(); setState(State.IDLE); return
        }
        speaker.stop()
        if (!engine.isReady) {
            speaker.speak("Le moteur vocal n'est pas prêt.")
            return
        }
        setState(State.LISTENING)
        engine.listen(
            onText = { text -> handleSpeech(text) },
            onError = { msg ->
                setState(State.IDLE)
                if (msg.isEmpty()) speaker.speak("Je n'ai rien entendu.")
            }
        )
    }

    private fun handleSpeech(text: String) {
        val reply = executor.execute(parser.parse(text))
        setState(State.SPEAKING)
        speaker.speak(reply) { if (state == State.SPEAKING) setState(State.IDLE) }
    }

    // ------------------------------------------------------------------ SOS

    private fun toggleSos() = if (siren == null) startSiren() else stopSiren()

    private fun startSiren() {
        engine.cancel(); speaker.stop()
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        savedAlarmVolume = am.getStreamVolume(AudioManager.STREAM_ALARM)
        am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
        siren = try {
            MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                resources.openRawResourceFd(R.raw.siren).use { setDataSource(it.fileDescriptor, it.startOffset, it.length) }
                isLooping = true
                prepare()
                start()
            }
        } catch (e: Exception) { null }
        if (siren != null) setState(State.SOS)
    }

    private fun stopSiren() {
        siren?.let { runCatching { it.stop() }; it.release() }
        siren = null
        if (savedAlarmVolume >= 0) {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.setStreamVolume(AudioManager.STREAM_ALARM, savedAlarmVolume, 0)
            savedAlarmVolume = -1
        }
        if (bubble != null && state == State.SOS) setState(State.IDLE)
    }

    // ------------------------------------------------------------------ affichage

    private fun setState(s: State) {
        state = s
        bubbleBg.setColor(s.color)
        bubble?.invalidate()
    }

    companion object {
        @Volatile var isRunning = false
            private set
        const val ACTION_STOP = "com.example.assistant.STOP"
        private const val CHANNEL_ID = "assistant_service"
        private const val NOTIF_ID = 1001
        private const val TAP_WINDOW_MS = 350L
    }
}
