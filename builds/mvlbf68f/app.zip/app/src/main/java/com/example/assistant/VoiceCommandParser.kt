package com.example.assistant

import java.text.Normalizer
import java.util.Locale

/** Commandes comprises par l'assistant. */
sealed interface Command {
    data class Torch(val on: Boolean) : Command
    data object Battery : Command
    data object Storage : Command
    data class Note(val text: String) : Command          // text vide = "que dois-je noter ?"
    data class Alarm(val hour: Int?, val minute: Int?) : Command // null = heure non comprise
    data class OpenApp(val name: String) : Command
    data object PowerMenu : Command
    data class Unknown(val heard: String) : Command
}

/**
 * Analyse du texte reconnu par Vosk (minuscules, sans ponctuation, nombres écrits en lettres).
 * La détection se fait sur une version sans accents ; le texte des notes garde ses accents.
 */
class VoiceCommandParser {

    fun parse(raw: String): Command {
        val original = raw.trim().lowercase(Locale.FRENCH)
        // Même longueur que 'original' : permet de réextraire le texte avec accents
        val t = stripAccents(original).replace('-', ' ').replace('\'', ' ').replace('’', ' ')
        if (t.isBlank()) return Command.Unknown("")

        // 1. Notes / rappels (prioritaire : le contenu de la note peut contenir d'autres mots-clés)
        NOTE.find(t)?.let { m ->
            val g = m.groups[1]!!
            val text = if (original.length == t.length) original.substring(g.range) else g.value
            return Command.Note(text.trim())
        }
        if (NOTE_EMPTY.matches(t)) return Command.Note("")

        // 2. Torche
        if (TORCH_ON.containsMatchIn(t)) return Command.Torch(true)
        if (TORCH_OFF.containsMatchIn(t)) return Command.Torch(false)

        // 3. Menu d'alimentation (éteins / redémarre le téléphone)
        if (POWER.containsMatchIn(t)) return Command.PowerMenu

        // 4. Alarme
        if (ALARM.containsMatchIn(t)) {
            val time = parseTime(t)
            return Command.Alarm(time?.first, time?.second)
        }

        // 5. Ouverture d'application
        OPEN.find(t)?.let { return Command.OpenApp(it.groupValues[1].trim()) }

        // 6. Infos système
        if (BATTERY.containsMatchIn(t)) return Command.Battery
        if (STORAGE.containsMatchIn(t)) return Command.Storage

        return Command.Unknown(raw)
    }

    // ---------------- Extraction de l'heure ----------------

    private fun parseTime(t: String): Pair<Int, Int>? {
        var hour: Int
        var minute = 0

        if (Regex("\\bminuit\\b").containsMatchIn(t)) {
            hour = 0
        } else if (Regex("\\bmidi\\b").containsMatchIn(t)) {
            hour = 12
        } else {
            val digits = Regex("(\\d{1,2})\\s*(?:h|heures?|:)\\s*(\\d{1,2})?").find(t)
            if (digits != null) {
                hour = digits.groupValues[1].toInt()
                minute = digits.groupValues[2].ifEmpty { "0" }.toInt()
            } else {
                // "sept heures et demie", "huit heures moins le quart", "vingt deux heures quinze"...
                val m = Regex("(.*?)\\bheures?\\b(.*)").find(t) ?: return null
                val before = m.groupValues[1].split(" ").filter { it.isNotBlank() }
                    .takeLastWhile { FrenchNumbers.isNumberWord(it) && it != "et" }
                hour = FrenchNumbers.toInt(before) ?: return null
                val after = m.groupValues[2].trim()
                when {
                    after.startsWith("et demi") -> minute = 30
                    after.startsWith("et quart") -> minute = 15
                    after.startsWith("moins le quart") || after.startsWith("moins quart") -> {
                        minute = 45; hour -= 1
                    }
                    else -> {
                        val words = after.split(" ").filter { it.isNotBlank() }
                            .takeWhile { FrenchNumbers.isNumberWord(it) }
                        if (words.isNotEmpty()) minute = FrenchNumbers.toInt(words) ?: 0
                    }
                }
            }
        }
        if (hour < 0) hour = 23
        // "huit heures du soir" -> 20h
        if (hour in 1..11 && Regex("\\b(du soir|de l apres midi)\\b").containsMatchIn(t)) hour += 12
        return if (hour in 0..23 && minute in 0..59) hour to minute else null
    }

    /** Nombres français 0-59 par simple addition des mots ("vingt trois" = 20 + 3). */
    private object FrenchNumbers {
        private val values = mapOf(
            "zero" to 0, "un" to 1, "une" to 1, "deux" to 2, "trois" to 3, "quatre" to 4,
            "cinq" to 5, "six" to 6, "sept" to 7, "huit" to 8, "neuf" to 9, "dix" to 10,
            "onze" to 11, "douze" to 12, "treize" to 13, "quatorze" to 14, "quinze" to 15,
            "seize" to 16, "vingt" to 20, "trente" to 30, "quarante" to 40, "cinquante" to 50,
            "et" to 0
        )
        fun isNumberWord(w: String) = values.containsKey(w)
        fun toInt(words: List<String>): Int? =
            if (words.isEmpty() || words.any { !values.containsKey(it) }) null
            else words.sumOf { values.getValue(it) }
    }

    companion object {
        private val NOTE = Regex(
            "^(?:(?:prends|prend|fais|ajoute|enregistre|cree|ecris)\\s+(?:une\\s+)?)?" +
                "(?:note|rappelle moi)\\s+(?:que\\s+|de\\s+|d\\s+)?(.+)$"
        )
        private val NOTE_EMPTY = Regex("^(?:(?:prends|prend|fais|ajoute|enregistre)\\s+(?:une\\s+)?)?note$")
        private val TORCH_ON = Regex("\\b(allume|allumer|active|activer)\\b.*\\b(torche|lampe|flash)\\b")
        private val TORCH_OFF = Regex("\\b(eteins|eteint|eteindre|desactive|desactiver|coupe|couper)\\b.*\\b(torche|lampe|flash)\\b")
        private val POWER = Regex(
            "\\b(eteins|eteint|eteindre|redemarre|redemarrer|reboot|arrete)\\b.*\\b(telephone|portable|appareil|mobile|smartphone)\\b" +
                "|menu d alimentation|menu power"
        )
        private val ALARM = Regex("\\b(alarme|reveil)\\b")
        private val OPEN = Regex(
            "^(?:ouvre|ouvrir|lance|lancer|demarre|demarrer)\\s+" +
                "(?:(?:l |le |la |les )?(?:application|app)\\s+)?(?:l |le |la |les )?(.+)$"
        )
        private val BATTERY = Regex("\\b(batterie|pile|autonomie)\\b")
        private val STORAGE = Regex("\\b(stockage|memoire|espace libre|espace disque)\\b")

        fun stripAccents(s: String): String =
            Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")

        /** Normalisation partagée pour comparer des noms d'applications. */
        fun normalizeName(s: String): String =
            stripAccents(s.lowercase(Locale.FRENCH)).replace(Regex("[^a-z0-9]+"), " ").trim()
    }
}
