# Plugins LinkShare

Un plugin = une appli Android + un `plugin.json`, regroupés dans un fichier `.lsplugin` (zip).

## Fabriquer le plugin Media Studio (Media Studio n'est pas modifié)
1. Compiler Media Studio comme d'habitude (GitHub Actions) pour obtenir l'APK.
2. `./make-lsplugin.sh MediaStudio-debug.apk mediastudio/plugin.json MediaStudio.lsplugin`

Étape GitHub Actions à ajouter après la compilation de Media Studio :
```yaml
      - name: Assembler le plugin LinkShare
        run: |
          APK=$(find . -name "*.apk" | head -n 1)
          ./plugin-tools/make-lsplugin.sh "$APK" plugin-tools/mediastudio/plugin.json MediaStudio.lsplugin
      - uses: actions/upload-artifact@v4
        with: { name: MediaStudio-plugin, path: MediaStudio.lsplugin }
```

## Utiliser
LinkShare › Paramètres › Install plugins › « Ajouter un nouveau plugin » :
- **Téléverser** le `.lsplugin` (ou un `.apk` seul) → vérifier la fiche → **Valider et installer**
- ou coller un **lien https** direct vers le fichier → **Télécharger et installer**

`plugin.json` : id, name, version, package (doit être celui de l'APK), contract (1), description, actions, apk, sha256 (ajouté par le script).
