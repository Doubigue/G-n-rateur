package com.linkshare.ui

import android.content.Context
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.linkshare.core.Bridge
import com.linkshare.core.Bridges
import com.linkshare.core.ExtraitBridge
import com.linkshare.core.ExtraitRequest
import java.io.File
import kotlin.math.roundToInt

private val BoltIcon: ImageVector by lazy {
    ImageVector.Builder("bolt", 24.dp, 24.dp, 24f, 24f)
        .addPath(
            PathParser().parsePathString(
                "M11,21h-1l1,-7H7.5c-0.88,0 -0.33,-0.75 -0.31,-0.78C8.48,10.94 10.42,7.54 13.01,3h1l-1,7h3.51c0.4,0 0.62,0.19 0.4,0.66C12.97,17.55 11,21 11,21z"
            ).toNodes(),
            fill = SolidColor(Color.Black),
        )
        .build()
}

/**
 * Deux boutons flottants, déplaçables au doigt (leur place est mémorisée) :
 *  - « Action » : ouvre l'écran d'infos et d'actions de la sélection (ou du dossier affiché) ;
 *  - « Ocr / Pdf » : ouvre le menu Extraire et numériser en PDF / Numériser (pont vers Extrait).
 * À poser en plein écran au-dessus de l'explorateur : seuls les deux boutons captent les touchers.
 */
@Composable
internal fun FloatingTools(ex: ExplorerViewModel, folder: File?, onScan: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val d = LocalDensity.current
        val tile = with(d) { 70.dp.toPx() }
        val maxX = with(d) { maxWidth.toPx() } - tile
        val maxY = with(d) { maxHeight.toPx() } - tile
        val margin = with(d) { 12.dp.toPx() }
        val gap = with(d) { 12.dp.toPx() }
        val lift = with(d) { 150.dp.toPx() } // au-dessus de la pilule Partager / Scanner et de la carte de sélection

        if (Bridges.on(Bridge.EXTRAIT)) FloatTile(
            key = "ocr", label = "Ocr / Pdf", icon = Ic.ScanDoc,
            colors = listOf(Color(0xFF8A4DFF), Color(0xFF4B1FD6)), glow = Color(0xFF8A4DFF),
            defX = maxX - margin, defY = maxY - lift - tile - gap, maxX = maxX, maxY = maxY,
        ) { menu = true }

        FloatTile(
            key = "action", label = "Action", icon = BoltIcon,
            colors = listOf(Color(0xFF2DA8FF), Color(0xFF1537E6)), glow = Color(0xFF2D7BFF),
            defX = maxX - margin, defY = maxY - lift, maxX = maxX, maxY = maxY,
        ) {
            val sel = ex.selected.map { File(it) }
            when {
                sel.isNotEmpty() -> ex.showInfo(sel)
                folder != null -> ex.showInfo(listOf(folder))
                else -> ex.message = "Sélectionnez un fichier ou un dossier pour voir ses actions"
            }
        }
    }
    if (menu && Bridges.on(Bridge.EXTRAIT)) OcrPdfScreen(ex, folder, onDismiss = { menu = false }, onScan = onScan)
}

@Composable
private fun FloatTile(
    key: String, label: String, icon: ImageVector, colors: List<Color>, glow: Color,
    defX: Float, defY: Float, maxX: Float, maxY: Float, onClick: () -> Unit,
) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("floating_tools", Context.MODE_PRIVATE) }
    var x by remember { mutableFloatStateOf(prefs.getFloat("${key}_x", defX)) }
    var y by remember { mutableFloatStateOf(prefs.getFloat("${key}_y", defY)) }
    val limX by rememberUpdatedState(maxX)
    val limY by rememberUpdatedState(maxY)
    val click by rememberUpdatedState(onClick)
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (pressed) 0.92f else 1f, label = "floatTile")
    val shape = RoundedCornerShape(22.dp)

    Column(
        Modifier
            .offset { IntOffset(x.coerceIn(0f, maxX).roundToInt(), y.coerceIn(0f, maxY).roundToInt()) }
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .size(70.dp)
            .shadow(14.dp, shape, ambientColor = glow, spotColor = glow)
            .clip(shape)
            .background(Brush.linearGradient(colors))
            .border(1.5.dp, Color.White.copy(alpha = 0.6f), shape)
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = { pressed = true; tryAwaitRelease(); pressed = false },
                    onTap = { click() },
                )
            }
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragEnd = { prefs.edit().putFloat("${key}_x", x).putFloat("${key}_y", y).apply() },
                    onDragCancel = { prefs.edit().putFloat("${key}_x", x).putFloat("${key}_y", y).apply() },
                ) { change, drag ->
                    change.consume()
                    x = (x + drag.x).coerceIn(0f, limX)
                    y = (y + drag.y).coerceIn(0f, limY)
                }
            },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(icon, null, Modifier.size(28.dp), tint = Color.White)
        Spacer(Modifier.height(2.dp))
        Text(label, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

// ═══════════════════════════ Menu « Ocr / Pdf » ═══════════════════════════

@Composable
private fun OcrPdfScreen(ex: ExplorerViewModel, folder: File?, onDismiss: () -> Unit, onScan: () -> Unit) {
    val ctx = LocalContext.current
    val installed = remember { ExtraitBridge.isInstalled(ctx) }
    val files = ex.selected.map { File(it) }
    val images = files.isNotEmpty() && ExtraitBridge.relevant(files) && files.none { ex.inVault(it) }

    // Pas d'image sélectionnée : on propose d'en choisir ; le PDF est rangé dans le dossier affiché (ou Documents).
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) {
            val dir = folder ?: File(ex.root, "Documents").also { it.mkdirs() }
            ex.extraitRequest = ExtraitRequest(emptyList(), null, uris, dir)
            onDismiss()
        }
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF050B2E), Color(0xFF12104A), Color(0xFF2B1580)))
            )
        ) {
            Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 16.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    RoundGlyph(Ic.Back, "Retour", onDismiss)
                    Spacer(Modifier.weight(1f))
                    RoundGlyph(Ic.Settings, "Réglages d'Extrait") {
                        val i = ExtraitBridge.launchIntent(ctx)
                        if (i == null) ex.message = "Extrait n'est pas installé"
                        else try { ctx.startActivity(i) } catch (_: Exception) { ex.message = "Impossible d'ouvrir Extrait" }
                    }
                }
                ScanIllustration(Modifier.align(Alignment.CenterHorizontally).padding(top = 8.dp).size(220.dp))
                Spacer(Modifier.height(24.dp))
                BigOption(
                    title = "Extraire et numériser en pdf",
                    sub = when {
                        !installed -> "Extrait n'est pas installé"
                        images -> if (files.size == 1) "1 image sélectionnée" else "${files.size} images sélectionnées"
                        else -> "Choisir des images…"
                    },
                    icon = Ic.Doc, primary = true,
                ) {
                    when {
                        !installed -> ex.message = "Extrait n'est pas installé"
                        images -> { ex.extraitRequest = ExtraitRequest(files, null); onDismiss() }
                        else -> picker.launch("image/*")
                    }
                }
                Spacer(Modifier.height(14.dp))
                BigOption(title = "Numériser", sub = "Appareil photo → PDF", icon = Ic.ScanDoc, primary = false) {
                    onDismiss()
                    onScan()
                }
            }
        }
    }
}

@Composable
private fun RoundGlyph(icon: ImageVector, desc: String, onClick: () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(CircleShape).background(Color(0x33FFFFFF)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, desc, Modifier.size(24.dp), tint = Color.White) }
}

@Composable
private fun BigOption(title: String, sub: String, icon: ImageVector, primary: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(28.dp)
    val bg: Brush = if (primary) Brush.horizontalGradient(listOf(Color(0xFF6A5BFF), Color(0xFF3A2BFF)))
    else SolidColor(Color(0x2EFFFFFF))
    Row(
        Modifier.fillMaxWidth().clip(shape).background(bg).clickable(onClick = onClick)
            .padding(horizontal = 22.dp, vertical = 24.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, Modifier.size(38.dp), tint = Color.White)
        Spacer(Modifier.width(18.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            if (sub.isNotEmpty()) Text(sub, color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
        }
        Icon(Ic.Chevron, null, Modifier.size(26.dp), tint = Color.White.copy(alpha = 0.85f))
    }
}

/** Petite scène : page avec cadre de numérisation, orbite lumineuse et pastille PDF. */
@Composable
private fun ScanIllustration(modifier: Modifier) {
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val violet = Color(0xFF8A6BFF)
            val cyan = Color(0xFF5CE1FF)
            // orbites
            rotate(-16f) {
                drawOval(
                    Brush.sweepGradient(listOf(violet, cyan, violet), center),
                    topLeft = Offset(w * 0.02f, h * 0.32f), size = Size(w * 0.96f, h * 0.40f),
                    style = Stroke(3.dp.toPx()),
                )
            }
            // page
            drawRoundRect(Color(0xFFF2F0FF), Offset(w * 0.30f, h * 0.14f), Size(w * 0.40f, h * 0.60f), CornerRadius(12.dp.toPx()))
            repeat(4) { i ->
                drawRoundRect(
                    violet, Offset(w * 0.36f, h * (0.26f + i * 0.085f)), Size(w * (if (i == 3) 0.14f else 0.28f), 5.dp.toPx()),
                    CornerRadius(3.dp.toPx()),
                )
            }
            // cadre de numérisation (4 coins)
            val l = w * 0.09f
            val sw = 4.dp.toPx()
            val x0 = w * 0.22f
            val x1 = w * 0.78f
            val y0 = h * 0.07f
            val y1 = h * 0.80f
            fun corner(x: Float, y: Float, dx: Float, dy: Float) {
                drawLine(violet, Offset(x, y), Offset(x + dx * l, y), sw, StrokeCap.Round)
                drawLine(violet, Offset(x, y), Offset(x, y + dy * l), sw, StrokeCap.Round)
            }
            corner(x0, y0, 1f, 1f); corner(x1, y0, -1f, 1f); corner(x0, y1, 1f, -1f); corner(x1, y1, -1f, -1f)
        }
        Text(
            "PDF", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black,
            modifier = Modifier.align(Alignment.BottomEnd).padding(end = 44.dp, bottom = 52.dp)
                .clip(RoundedCornerShape(8.dp)).background(Color(0xFFFF3B5C)).padding(horizontal = 10.dp, vertical = 4.dp),
        )
    }
}
