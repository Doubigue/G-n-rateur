package com.linkshare.core

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Les ponts de LinkShare vers d'autres applis. Chaque pont a son interrupteur (Paramètres › Ponts). */
enum class Bridge(val id: String, val title: String, val sub: String) {
    STUDIO("studio", "Media Studio", "MP3, compression, effets, montage, images et documents (PDF, Word)"),
    EXTRAIT("extrait", "Extrait", "Extraire le texte des images (OCR) et numériser en PDF"),
    EDITOR("editor", "Modifier avec…", "Ouvrir un fichier dans l'éditeur d'une autre application"),
}

/**
 * État des ponts. Un pont désactivé : ses boutons disparaissent de LinkShare et plus aucun Intent n'est envoyé
 * vers l'autre appli (le contrôle est aussi fait au moment de l'envoi). Réglage conservé à part (clé « br_off ») :
 * « Réinitialiser l'apparence » ne le touche pas.
 */
object Bridges {
    private var off by mutableStateOf(emptySet<String>())

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("linkshare", Context.MODE_PRIVATE)

    fun load(ctx: Context) {
        off = prefs(ctx).getString("br_off", "").orEmpty().split(',').filter { it.isNotBlank() }.toSet()
    }

    fun on(b: Bridge): Boolean = b.id !in off

    fun set(ctx: Context, b: Bridge, enabled: Boolean) {
        off = if (enabled) off - b.id else off + b.id
        prefs(ctx).edit().putString("br_off", off.joinToString(",")).apply()
    }

    fun activeCount(): Int = Bridge.values().count { on(it) }

    const val DISABLED_MSG = "Ce pont est désactivé (Paramètres › Ponts)"
}
