package com.linkshare.core

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Valeurs partagées avec Extrait (QuickActivity). Toute modification doit être faite des deux côtés. */
object ExtraitContract {
    /** Identifiants possibles de l'appli installée (Extractor = com.doubigue.ocr ; l'ancien identifiant reste accepté). */
    val PACKAGES = listOf("com.doubigue.ocr", "com.dlvibe.extrait")
    /** Nom de classe (espace de noms du code), indépendant de l'identifiant de l'appli (applicationId). */
    const val QUICK_CLASS = "com.dlvibe.extrait.QuickActivity"
    const val ACTION_QUICK = "com.dlvibe.extrait.QUICK"

    const val EXTRA_MODE = "mode"
    /** Extraire le texte (OCR) : Extrait affiche le résultat (copier, partager). */
    const val MODE_OCR = "ocr"
    /** Numériser en PDF : Extrait crée le PDF et le renvoie à LinkShare (setResult + data = Uri du PDF). */
    const val MODE_PDF = "pdf"
}

/** Une demande = des images + une action. Chaque demande est une instance distincte (clé d'effet Compose). */
/**
 * [mode] = null : Extrait affiche ses deux choix (Extraire le texte / Numériser en PDF).
 * [uris] : images choisies hors de l'explorateur (sélecteur système) ; [saveDir] : dossier où ranger le PDF dans ce cas.
 */
class ExtraitRequest(val files: List<File>, val mode: String?, val uris: List<Uri> = emptyList(), val saveDir: File? = null)

sealed interface ExtraitLaunch {
    data object Launched : ExtraitLaunch
    data object NotInstalled : ExtraitLaunch
    data class Failed(val reason: String) : ExtraitLaunch
}

/** Pont LinkShare → Extrait : envoie les images sélectionnées dans l'explorateur (OCR ou PDF). */
object ExtraitBridge {
    /** Formats que le lecteur d'images d'Android sait décoder pour l'OCR. */
    private val IMAGE_EXT = setOf("jpg", "jpeg", "jfif", "png", "webp", "bmp", "gif", "heic", "heif")

    /** Vrai si toute la sélection est faite d'images exploitables (ni dossier, ni vidéo, ni document). */
    fun relevant(files: List<File>): Boolean =
        Bridges.on(Bridge.EXTRAIT) && files.isNotEmpty() && files.all { it.extension.lowercase() in IMAGE_EXT && !it.isDirectory }

    fun installedPackage(ctx: Context): String? = ExtraitContract.PACKAGES.firstOrNull { pkg ->
        try { ctx.packageManager.getPackageInfo(pkg, 0); true } catch (_: PackageManager.NameNotFoundException) { false }
    }

    fun isInstalled(ctx: Context): Boolean = installedPackage(ctx) != null

    /** Intent EXPLICITE + lecture accordée uniquement aux images choisies (jamais d'écriture dans la source). */
    fun buildIntent(ctx: Context, pkg: String, mode: String?, files: List<File>, extra: List<Uri> = emptyList()): Intent {
        val authority = "${ctx.packageName}.files"
        val uris = files.map { FileProvider.getUriForFile(ctx, authority, it) } + extra
        val clip = ClipData.newRawUri("Extrait", uris[0]).also { c -> uris.drop(1).forEach { c.addItem(ClipData.Item(it)) } }
        return Intent(ExtraitContract.ACTION_QUICK)
            .setComponent(ComponentName(pkg, ExtraitContract.QUICK_CLASS))
            .putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
            .also { it.clipData = clip }
            .also { if (mode != null) it.putExtra(ExtraitContract.EXTRA_MODE, mode) }
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }

    /** Ouvre l'appli Extrait elle-même (ses réglages). */
    fun launchIntent(ctx: Context): Intent? =
        if (!Bridges.on(Bridge.EXTRAIT)) null else installedPackage(ctx)?.let { ctx.packageManager.getLaunchIntentForPackage(it) }

    /** @param launch lance l'Intent avec startActivityForResult : Extrait renvoie ainsi le PDF créé. */
    fun dispatch(ctx: Context, launch: (Intent) -> Unit, req: ExtraitRequest): ExtraitLaunch {
        if (!Bridges.on(Bridge.EXTRAIT)) return ExtraitLaunch.Failed(Bridges.DISABLED_MSG)
        if (req.files.isEmpty() && req.uris.isEmpty()) return ExtraitLaunch.Failed("Aucune image sélectionnée")
        if (req.files.any { !it.isFile || !it.canRead() }) return ExtraitLaunch.Failed("Image introuvable ou illisible")
        val pkg = installedPackage(ctx) ?: return ExtraitLaunch.NotInstalled
        return try {
            launch(buildIntent(ctx, pkg, req.mode, req.files, req.uris))
            ExtraitLaunch.Launched
        } catch (_: ActivityNotFoundException) {
            ExtraitLaunch.Failed("Extrait est installé mais trop ancien : mettez-le à jour")
        } catch (_: SecurityException) {
            ExtraitLaunch.Failed("Accès refusé par Extrait")
        } catch (_: IllegalArgumentException) { // FileProvider : fichier hors des chemins déclarés
            ExtraitLaunch.Failed("Cette image ne peut pas être partagée")
        }
    }

    /** Nom du PDF rangé à côté des images : celui de l'image seule, ou « Images <date> » pour plusieurs. */
    fun resultBaseName(files: List<File>): String =
        if (files.size == 1) files[0].nameWithoutExtension
        else "Images " + SimpleDateFormat("yyyy-MM-dd HH.mm", Locale.getDefault()).format(Date())

    /** Copie le fichier fourni par Extrait dans [dir] sans jamais écraser un fichier existant. */
    fun saveResult(ctx: Context, src: Uri, dir: File, base: String, ext: String): File {
        var out = File(dir, "$base.$ext")
        var n = 1
        while (out.exists()) { out = File(dir, "$base ($n).$ext"); n++ }
        ctx.contentResolver.openInputStream(src)!!.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
        return out
    }
}
