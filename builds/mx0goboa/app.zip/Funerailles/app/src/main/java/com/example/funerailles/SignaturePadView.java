package com.example.funerailles;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Bitmap;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/** Zone de signature manuscrite destinée à être intégrée aux reçus et rapports PDF. */
public class SignaturePadView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private Bitmap bitmap;
    private Canvas bitmapCanvas;
    private boolean hasSignature = false;

    public SignaturePadView(Context context) { super(context); init(); }
    public SignaturePadView(Context context, AttributeSet attrs) { super(context, attrs); init(); }
    private void init() {
        setBackground(Ui.shape(Color.WHITE, 18));
        paint.setColor(Color.rgb(25, 25, 25));
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(4f);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeJoin(Paint.Join.ROUND);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }
    private void ensureBitmap() {
        if (getWidth() > 0 && getHeight() > 0 && (bitmap == null || bitmap.getWidth() != getWidth() || bitmap.getHeight() != getHeight())) {
            Bitmap next = Bitmap.createBitmap(getWidth(), getHeight(), Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(next);
            if (bitmap != null) c.drawBitmap(bitmap, 0, 0, null);
            bitmap = next;
            bitmapCanvas = c;
        }
    }
    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        ensureBitmap();
        if (bitmap != null) canvas.drawBitmap(bitmap, 0, 0, null);
        canvas.drawPath(path, paint);
    }
    @Override public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX(), y = event.getY();
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN: path.moveTo(x, y); invalidate(); return true;
            case MotionEvent.ACTION_MOVE: path.lineTo(x, y); hasSignature = true; invalidate(); return true;
            case MotionEvent.ACTION_UP:
                path.lineTo(x, y); ensureBitmap();
                if (bitmapCanvas != null) { bitmapCanvas.drawPath(path, paint); path.reset(); }
                hasSignature = true; invalidate(); return true;
            default: return true;
        }
    }
    public boolean hasSignature() { return hasSignature; }
    public Bitmap getSignatureBitmap() {
        ensureBitmap();
        if (bitmap == null) return null;
        Bitmap copy = bitmap.copy(Bitmap.Config.ARGB_8888, false);
        Canvas c = new Canvas(copy);
        c.drawPath(path, paint);
        return copy;
    }
    public void clear() {
        path.reset(); hasSignature = false;
        if (bitmap != null) { bitmap.eraseColor(Color.TRANSPARENT); }
        invalidate();
    }
}
