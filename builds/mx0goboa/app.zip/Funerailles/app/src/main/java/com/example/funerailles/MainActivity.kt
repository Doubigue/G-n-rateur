package com.example.funerailles

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.Toast
import java.text.NumberFormat
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var db: DatabaseHelper

    private fun money(v: Double): String =
        NumberFormat.getIntegerInstance(Locale.FRANCE).format(v) + " FCFA"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = DatabaseHelper(this)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        val root = Ui.page(this, "Funérailles")
        root.addView(Ui.text("Bienvenue dans votre espace de collecte", 15, false))
        root.addView(Ui.hero("Total des cotisations", money(db.total), "${db.count} enregistrement(s)"))
        root.addView(Ui.button(this, "Enregistrer une cotisation").apply {
            setOnClickListener { open(CotisationActivity::class.java) }
        })
        addMenu(root, "Cotisants et historique", ContributorsActivity::class.java)
        addMenu(root, "Gérer groupes et quartiers", ManageActivity::class.java)
        addMenu(root, "Rapports PDF", ReportsActivity::class.java)
        root.addView(Ui.menu(this, "Tester la synchronisation").apply {
            setOnClickListener { testSync() }
        })
        root.addView(Ui.text("Vos données sont enregistrées sur ce téléphone. Configurez Firebase pour activer la synchronisation multi-téléphones.", 13, false).apply {
            setTextColor(Ui.MUTED)
            val space = (20 * resources.displayMetrics.density).toInt()
            setPadding(0, space, 0, 0)
        })
        Ui.show(this, root)
    }

    private fun addMenu(root: LinearLayout, label: String, target: Class<out Activity>) {
        root.addView(Ui.menu(this, label).apply { setOnClickListener { open(target) } })
    }

    private fun open(target: Class<out Activity>) {
        startActivity(Intent(this, target))
    }

    private fun testSync() {
        SyncManager.testConnection { _, message ->
            runOnUiThread {
                Toast.makeText(this@MainActivity, message, Toast.LENGTH_LONG).show()
            }
        }
    }
}
