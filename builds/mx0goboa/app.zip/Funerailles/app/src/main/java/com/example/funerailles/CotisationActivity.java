package com.example.funerailles;

import android.app.*;import android.os.Bundle;import android.os.Environment;import android.text.InputType;import android.view.*;import android.widget.*;import android.graphics.*;import android.graphics.pdf.PdfDocument;import java.io.*;import java.text.SimpleDateFormat;import java.text.NumberFormat;import java.util.*;

public class CotisationActivity extends Activity {
 DatabaseHelper db; EditText nom,montant; RadioGroup choix; LinearLayout options; String categorie="Groupe",lieu="";
 @Override public void onCreate(Bundle b){super.onCreate(b);db=new DatabaseHelper(this);LinearLayout root=Ui.page(this,"Nouvelle cotisation");
 nom=new EditText(this);nom.setSingleLine(true);nom.setHint("Nom et prénom");nom.setTextColor(Ui.INK);nom.setHintTextColor(Ui.MUTED);Ui.style(nom);root.addView(nom);
 montant=new EditText(this);montant.setSingleLine(true);montant.setHint("Somme en FCFA");montant.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);montant.setTextColor(Ui.INK);montant.setHintTextColor(Ui.MUTED);Ui.style(montant);root.addView(montant);
 TextView label=Ui.text("Type de cotisation",18,true);label.setPadding(0,22,0,8);root.addView(label);choix=new RadioGroup(this);choix.setOrientation(LinearLayout.HORIZONTAL);RadioButton g=new RadioButton(this);g.setText("Groupe");g.setTextColor(Ui.INK);g.setId(View.generateViewId());RadioButton q=new RadioButton(this);q.setText("Quartier / Village");q.setTextColor(Ui.INK);q.setId(View.generateViewId());choix.addView(g);choix.addView(q);root.addView(choix);options=new LinearLayout(this);options.setOrientation(1);root.addView(options);g.setChecked(true);showOptions();choix.setOnCheckedChangeListener((x,id)->{categorie=id==g.getId()?"Groupe":"Quartier";showOptions();});
 TextView save=Ui.button(this,"ENREGISTRER LA COTISATION");save.setOnClickListener(v->save());root.addView(save);Ui.show(this,root);
 }
 void showReceiptSignature(String donor,double amount,String type,String place,String date){
  LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(20,12,20,8);
  EditText responsible=new EditText(this);responsible.setSingleLine(true);responsible.setHint("Nom et prénom du responsable");
  EditText function=new EditText(this);function.setSingleLine(true);function.setHint("Fonction (ex. Trésorier)");
  TextView label=Ui.text("Signature manuscrite du responsable :",14,false);
  SignaturePadView pad=new SignaturePadView(this);LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,dp(145));pp.topMargin=dp(8);pp.bottomMargin=dp(8);
  TextView clear=Ui.button(this,"Effacer la signature");clear.setOnClickListener(v->pad.clear());
  box.addView(responsible);box.addView(function);box.addView(label);box.addView(pad,pp);box.addView(clear);
  new AlertDialog.Builder(this).setTitle("Créer le reçu PDF signé").setView(box)
   .setNegativeButton("Plus tard",(d,w)->finish())
   .setPositiveButton("Créer le reçu",(d,w)->{
    String signer=responsible.getText().toString().trim();
    if(signer.isEmpty()||!pad.hasSignature()){Toast.makeText(this,"Indiquez le responsable et signez pour créer le reçu.",Toast.LENGTH_LONG).show();finish();return;}
    createReceipt(donor,amount,type,place,date,signer,function.getText().toString().trim(),pad.getSignatureBitmap());finish();
   }).setOnCancelListener(d->finish()).show();
 }
 int dp(int value){return (int)(value*getResources().getDisplayMetrics().density+0.5f);}
 void createReceipt(String donor,double amount,String type,String place,String date,String signer,String function,Bitmap signature){
  PdfDocument pdf=new PdfDocument();PdfDocument.Page page=pdf.startPage(new PdfDocument.PageInfo.Builder(595,842,1).create());Canvas c=page.getCanvas();Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);c.drawColor(Color.WHITE);
  p.setColor(Color.rgb(255,133,0));c.drawRect(0,0,595,125,p);p.setColor(Color.BLACK);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(30);c.drawText("REÇU DE COTISATION",35,58,p);p.setTypeface(Typeface.DEFAULT);p.setTextSize(14);c.drawText("FUNÉRAILLES • SOLIDARITÉ ET SOUTIEN",35,91,p);
  p.setColor(Color.DKGRAY);p.setTextSize(13);c.drawText("Date : "+date,40,175,p);p.setColor(Color.BLACK);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));p.setTextSize(17);c.drawText("Détails de la cotisation",40,225,p);
  p.setTypeface(Typeface.DEFAULT);p.setTextSize(15);c.drawText("Cotisant : "+donor,40,270,p);c.drawText("Montant versé : "+NumberFormat.getIntegerInstance(Locale.FRANCE).format(amount)+" FCFA",40,310,p);c.drawText("Catégorie : "+type,40,350,p);c.drawText("Groupe / Quartier : "+place,40,390,p);
  p.setColor(Color.rgb(255,133,0));c.drawRect(40,425,555,428,p);p.setColor(Color.BLACK);p.setTextSize(14);c.drawText("Responsable : "+signer,40,475,p);if(!function.isEmpty())c.drawText("Fonction : "+function,40,500,p);c.drawText("Signature :",40,545,p);
  if(signature!=null){Rect src=new Rect(0,0,signature.getWidth(),signature.getHeight());Rect dst=new Rect(40,555,270,660);c.drawBitmap(signature,src,dst,new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG));}
  p.setColor(Color.GRAY);p.setTextSize(10);c.drawText("Merci pour votre contribution et votre solidarité.",40,760,p);c.drawText("Reçu généré par l'application Funérailles",40,785,p);pdf.finishPage(page);
  try{File dir=getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);if(dir!=null&&!dir.exists())dir.mkdirs();File file=new File(dir,"Recu_"+System.currentTimeMillis()+".pdf");FileOutputStream out=new FileOutputStream(file);pdf.writeTo(out);out.close();Toast.makeText(this,"Reçu PDF signé créé : "+file.getAbsolutePath(),Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"Erreur reçu PDF : "+e.getMessage(),Toast.LENGTH_LONG).show();}finally{pdf.close();if(signature!=null)signature.recycle();}
 }

 void showOptions(){options.removeAllViews();List<String> items=db.getItems(categorie.equals("Groupe")?"groupes":"quartiers");TextView h=Ui.text(categorie.equals("Groupe")?"Choisir un groupe":"Choisir un quartier ou village",16,true);h.setPadding(0,14,0,4);options.addView(h);if(items.isEmpty()){TextView t=Ui.text("Aucun élément. Ajoutez d'abord un "+(categorie.equals("Groupe")?"groupe":"quartier")+" dans Gestion.",13,false);t.setTextColor(Ui.MUTED);options.addView(t);}RadioGroup rg=new RadioGroup(this);for(String item:items){RadioButton r=new RadioButton(this);r.setText(item);r.setTextColor(Ui.INK);rg.addView(r);}rg.setOnCheckedChangeListener((x,id)->{RadioButton r=findViewById(id);if(r!=null)lieu=r.getText().toString();});options.addView(rg);}
 void save(){String n=nom.getText().toString().trim(),m=montant.getText().toString().trim();if(n.isEmpty()||m.isEmpty()||lieu.isEmpty()){Toast.makeText(this,"Remplissez les champs et choisissez un groupe ou quartier.",Toast.LENGTH_LONG).show();return;}try{double value=Double.parseDouble(m);if(value<=0)throw new Exception();String date=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.FRANCE).format(new Date());if(db.addCotisation(n,value,categorie,lieu,date)){Toast.makeText(this,"Cotisation enregistrée",Toast.LENGTH_SHORT).show();showReceiptSignature(n,value,categorie,lieu,date);}}catch(Exception e){Toast.makeText(this,"Montant invalide",Toast.LENGTH_SHORT).show();}}
}
