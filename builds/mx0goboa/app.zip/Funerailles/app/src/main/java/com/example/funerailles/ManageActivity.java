package com.example.funerailles;
import android.app.*;import android.os.Bundle;import android.view.*;import android.widget.*;
public class ManageActivity extends Activity {
 DatabaseHelper db; LinearLayout root;
 @Override public void onCreate(Bundle b){super.onCreate(b);db=new DatabaseHelper(this);root=Ui.page(this,"Gestion des groupes et quartiers");section("Ajouter un groupe","Nom du groupe","groupes");section("Ajouter un quartier / village","Nom du quartier ou village","quartiers");Ui.show(this,root);}
 void section(String title,String hint,String table){TextView h=Ui.text(title,18,true);h.setPadding(0,18,0,4);root.addView(h);EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setTextColor(Ui.INK);e.setHintTextColor(Ui.MUTED);Ui.style(e);root.addView(e);TextView b=Ui.button(this,"Ajouter");b.setOnClickListener(v->{String s=e.getText().toString().trim();if(s.isEmpty())return;if(db.addItem(table,s)){e.setText("");refresh(table);}else Toast.makeText(this,"Nom déjà utilisé ou erreur",Toast.LENGTH_SHORT).show();});root.addView(b);TextView list=Ui.text("",14,false);list.setPadding(8,8,8,8);root.addView(list);refreshInto(table,list);}
 void refresh(String table){for(int i=0;i<root.getChildCount();i++)if(root.getChildAt(i) instanceof TextView){TextView t=(TextView)root.getChildAt(i);if(t.getTag()!=null&&t.getTag().equals(table))refreshInto(table,t);}}
 void refreshInto(String table,TextView t){t.setTag(table);t.setText(String.join("\n",db.getItems(table)));}
}
