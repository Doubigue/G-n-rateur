# Funérailles — Android Studio

Application Android native en Kotlin + Java, monnaie FCFA, thème noir / anthracite / orange.

## Fonctionnalités incluses
- Enregistrement local des cotisations (SQLite), utilisable hors connexion.
- Création de groupes et de quartiers/villages.
- Filtrage de la liste des cotisants par catégorie et lieu.
- Tableau de bord avec total et nombre de cotisants.
- Génération d'un PDF général dans le dossier Documents privé de l'application.
- Saisie du nom/fonction du responsable et signature manuscrite intégrée aux reçus individuels et au rapport PDF.
- Configuration Gradle pour signer les versions Release avec une clé Android personnelle (JKS).
- Point d'intégration Firebase Firestore pour la synchronisation en ligne.

## Ouvrir dans Android Studio
1. Décompresser le ZIP.
2. Android Studio → Open → sélectionner le dossier `Funerailles`.
3. Installer un JDK 17 et un SDK Android 35 si Android Studio le demande.
4. Laisser Gradle synchroniser, puis lancer sur un appareil Android ou un émulateur.

## Activer la synchronisation multi-téléphones (à configurer)
La base locale fonctionne immédiatement sans configuration. Pour activer le cloud :
1. Créer un projet dans Firebase Console.
2. Ajouter une application Android avec l'identifiant `com.example.funerailles`.
3. Télécharger `google-services.json` et le placer dans `Funerailles/app/`.
4. Activer Cloud Firestore et configurer des règles de sécurité adaptées.
5. Créer un mécanisme d'identification des utilisateurs avant tout déploiement réel.

**Important :** la version fournie est une base de projet fonctionnelle côté stockage local et écrans essentiels. Le bouton de test Firebase vérifie la connexion, mais la réplication automatique des enregistrements SQLite vers Firestore, l'authentification multi-utilisateur, la pagination PDF et les exports filtrés sont des étapes d'intégration à terminer avant une utilisation réelle en production.

## Sécurité et sauvegarde
Les données locales sont stockées dans la base privée de l'application. Désinstaller l'application peut les supprimer. Effectuer des sauvegardes régulières et configurer Firebase avant de partager l'application entre plusieurs collecteurs.


## Signature du responsable sur les rapports PDF
Après l’enregistrement d’une cotisation, l’application propose de créer un reçu PDF : saisissez le nom et la fonction du responsable, puis signez dans le cadre blanc. La signature dessinée est intégrée au reçu. Le même principe est disponible dans Rapports PDF pour signer le rapport général.

## Signature cryptographique Android (APK/AAB)
La configuration Gradle de signature Release est incluse. Pour des raisons de sécurité, aucune clé privée ni aucun mot de passe n'est intégré à l'archive. Suivez les étapes de `CREER_CLE_SIGNATURE.txt` pour générer votre propre fichier JKS et créer `keystore.properties`. Ces fichiers secrets sont exclus de Git. Une fois configurée, générez votre APK/AAB signé depuis Android Studio ou avec la tâche Gradle `assembleRelease`.
