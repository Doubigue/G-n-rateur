import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:http/http.dart' as http;
import 'package:open_filex/open_filex.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'config.dart';

class UpdateInfo {
  UpdateInfo(this.versionName, this.versionCode, this.apkUrl);
  final String versionName;
  final int versionCode;
  final String apkUrl;
}

enum UpdateStatus { idle, available, downloading, installing, error }

/// Recherche les nouvelles versions dans les Releases GitHub du dépôt,
/// notifie, télécharge l'APK et lance l'installation.
class UpdateController extends ChangeNotifier {
  UpdateController._();
  static final UpdateController instance = UpdateController._();

  final FlutterLocalNotificationsPlugin _np = FlutterLocalNotificationsPlugin();
  UpdateStatus status = UpdateStatus.idle;
  UpdateInfo? info;
  double progress = 0;
  String? error;
  String? lastCheckMessage;
  String currentVersion = '';
  bool checking = false;
  bool _started = false;
  Timer? _timer;

  void _set(void Function() f) {
    f();
    notifyListeners();
  }

  Future<void> start() async {
    if (_started) return;
    _started = true;
    var launchedByAction = false;
    try {
      final pi = await PackageInfo.fromPlatform();
      currentVersion = '${pi.version}+${pi.buildNumber}';
      await _np.initialize(
        const InitializationSettings(
            android: AndroidInitializationSettings('@mipmap/ic_launcher')),
        onDidReceiveNotificationResponse: _onResponse,
      );
      await _np
          .resolvePlatformSpecificImplementation<
              AndroidFlutterLocalNotificationsPlugin>()
          ?.requestNotificationsPermission();
      final d = await _np.getNotificationAppLaunchDetails();
      launchedByAction = (d?.didNotificationLaunchApp ?? false) &&
          d?.notificationResponse?.actionId == 'update';
    } catch (e) {
      debugPrint('Init notifications : $e');
    }
    notifyListeners();
    _timer = Timer.periodic(const Duration(hours: 6), (_) => check());
    await check();
    if (launchedByAction) unawaited(install());
  }

  void _onResponse(NotificationResponse r) {
    if (r.actionId == 'update') unawaited(install());
  }

  /// Cherche une version plus récente. Retourne true si une mise à jour existe.
  Future<bool> check({bool manual = false}) async {
    if (checking ||
        status == UpdateStatus.downloading ||
        status == UpdateStatus.installing) {
      return info != null;
    }
    final repo = await Config.getRepo();
    if (repo.isEmpty) {
      _set(() => lastCheckMessage =
          'Aucun dépôt GitHub configuré (Réglages → Mises à jour).');
      return false;
    }
    _set(() {
      checking = true;
      lastCheckMessage = null;
    });
    try {
      final pi = await PackageInfo.fromPlatform();
      final pkg = pi.packageName;
      final cur = int.tryParse(pi.buildNumber) ?? 0;
      final r = await http.get(
        Uri.parse('https://api.github.com/repos/$repo/releases?per_page=50'),
        headers: {'Accept': 'application/vnd.github+json'},
      ).timeout(const Duration(seconds: 15));
      if (r.statusCode != 200) {
        throw 'GitHub a répondu HTTP ${r.statusCode} (dépôt privé ou introuvable ?)';
      }
      UpdateInfo? best;
      for (final rel in (jsonDecode(r.body) as List)) {
        final body = (rel['body'] ?? '').toString();
        final p = RegExp(r'Paquet\s*:\s*(\S+)').firstMatch(body)?.group(1);
        if (p != pkg) continue;
        final v = RegExp(r'Version\s*:\s*(\S+)\s*\((\d+)\)').firstMatch(body);
        if (v == null) continue;
        final code = int.parse(v.group(2)!);
        String? url;
        for (final a in (rel['assets'] as List? ?? [])) {
          if (a['name'].toString().toLowerCase().endsWith('.apk')) {
            url = a['browser_download_url'].toString();
            break;
          }
        }
        if (url == null) continue;
        if (best == null || code > best.versionCode) {
          best = UpdateInfo(v.group(1)!, code, url);
        }
      }
      if (best != null && best.versionCode > cur) {
        _set(() {
          info = best;
          status = UpdateStatus.available;
          lastCheckMessage = 'Nouvelle version ${best!.versionName} disponible.';
        });
        if (await Config.getLastNotified() < best.versionCode) {
          await _notify(best);
          await Config.setLastNotified(best.versionCode);
        }
        return true;
      }
      _set(() {
        info = null;
        status = UpdateStatus.idle;
        lastCheckMessage = 'Vous avez la dernière version.';
      });
      return false;
    } catch (e) {
      _set(() => lastCheckMessage = 'Vérification impossible : $e');
      return false;
    } finally {
      _set(() => checking = false);
    }
  }

  Future<void> _notify(UpdateInfo i) async {
    try {
      await _np.show(
        1001,
        'Nouvelle version ${i.versionName}',
        'Une mise à jour de l’application est disponible.',
        const NotificationDetails(
          android: AndroidNotificationDetails(
            'updates',
            'Mises à jour',
            channelDescription: 'Nouvelles versions de l’application',
            importance: Importance.high,
            priority: Priority.high,
            actions: [
              AndroidNotificationAction('update', 'Mettre à jour',
                  showsUserInterface: true),
            ],
          ),
        ),
        payload: 'update',
      );
    } catch (e) {
      debugPrint('Notification : $e');
    }
  }

  /// Télécharge l'APK puis ouvre l'installateur Android.
  Future<void> install() async {
    if (status == UpdateStatus.downloading ||
        status == UpdateStatus.installing) {
      return;
    }
    if (info == null) await check();
    final i = info;
    if (i == null) return;
    _set(() {
      status = UpdateStatus.downloading;
      progress = 0;
      error = null;
    });
    try {
      await _np.cancel(1001);
      final dir = (await getExternalStorageDirectory()) ??
          await getTemporaryDirectory();
      final file = File('${dir.path}/update_${i.versionCode}.apk');
      final client = http.Client();
      final resp = await client
          .send(http.Request('GET', Uri.parse(i.apkUrl)))
          .timeout(const Duration(seconds: 30));
      if (resp.statusCode != 200) throw 'Téléchargement : HTTP ${resp.statusCode}';
      final total = resp.contentLength ?? 0;
      var got = 0;
      var lastTick = 0;
      final sink = file.openWrite();
      await for (final chunk in resp.stream) {
        sink.add(chunk);
        got += chunk.length;
        final tick = total > 0 ? (got * 100 ~/ total) : 0;
        if (tick != lastTick) {
          lastTick = tick;
          _set(() => progress = got / total);
        }
      }
      await sink.close();
      client.close();
      _set(() => status = UpdateStatus.installing);
      final res = await OpenFilex.open(file.path,
          type: 'application/vnd.android.package-archive');
      if (res.type != ResultType.done) {
        throw 'Installation : ${res.message}. Autorisez l’installation depuis cette appli (Réglages Android) puis réessayez.';
      }
      _set(() => status = UpdateStatus.available);
    } catch (e) {
      _set(() {
        status = UpdateStatus.error;
        error = e.toString();
      });
    }
  }
}
