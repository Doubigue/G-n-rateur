import 'package:shared_preferences/shared_preferences.dart';

/// Réglages enregistrés sur le téléphone.
class Config {
  /// Dépôt GitHub qui héberge les versions (ex. "monpseudo/monrepo").
  /// Peut aussi être saisi dans Réglages sans recompiler.
  static const String defaultRepo = '';

  static Future<String> getIp() async =>
      (await SharedPreferences.getInstance()).getString('ip') ?? '192.168.0.1';
  static Future<void> setIp(String v) async =>
      (await SharedPreferences.getInstance()).setString('ip', v);

  static Future<String> getPassword() async =>
      (await SharedPreferences.getInstance()).getString('pw') ?? 'admin';
  static Future<void> setPassword(String v) async =>
      (await SharedPreferences.getInstance()).setString('pw', v);

  static Future<String> getRepo() async =>
      (await SharedPreferences.getInstance()).getString('repo') ?? defaultRepo;
  static Future<void> setRepo(String v) async {
    var r = v.trim();
    r = r.replaceFirst(RegExp(r'^https?://github\.com/'), '');
    r = r.replaceFirst(RegExp(r'/+$'), '').replaceFirst(RegExp(r'\.git$'), '');
    await (await SharedPreferences.getInstance()).setString('repo', r);
  }

  static Future<int> getLastNotified() async =>
      (await SharedPreferences.getInstance()).getInt('lastNotified') ?? 0;
  static Future<void> setLastNotified(int v) async =>
      (await SharedPreferences.getInstance()).setInt('lastNotified', v);
}
