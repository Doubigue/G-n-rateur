import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models.dart';

class ResultScreen extends StatelessWidget {
  const ResultScreen({super.key, required this.result});
  final UnlockResult result;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final ok = result.outcome == Outcome.success;
    final failed = result.outcome == Outcome.failed;
    final color = ok
        ? const Color(0xFF2E7D32)
        : failed
            ? cs.error
            : const Color(0xFFEF6C00);
    final icon = ok
        ? Icons.check_circle
        : failed
            ? Icons.cancel
            : Icons.help;

    return Scaffold(
      appBar: AppBar(title: const Text('Résultat')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const SizedBox(height: 8),
          Icon(icon, size: 96, color: color),
          const SizedBox(height: 12),
          Text(result.title,
              textAlign: TextAlign.center,
              style: Theme.of(context)
                  .textTheme
                  .headlineSmall
                  ?.copyWith(color: color, fontWeight: FontWeight.w700)),
          const SizedBox(height: 16),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Cause',
                      style: Theme.of(context).textTheme.labelLarge),
                  const SizedBox(height: 4),
                  Text(result.cause),
                  if (result.suggestion != null) ...[
                    const SizedBox(height: 12),
                    Text('Que faire ?',
                        style: Theme.of(context).textTheme.labelLarge),
                    const SizedBox(height: 4),
                    Text(result.suggestion!),
                  ],
                ],
              ),
            ),
          ),
          if (result.details.isNotEmpty)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: result.details.entries
                      .map((e) => Padding(
                            padding: const EdgeInsets.symmetric(vertical: 4),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                    flex: 4,
                                    child: Text(e.key,
                                        style: TextStyle(
                                            color: cs.onSurfaceVariant))),
                                Expanded(flex: 5, child: Text(e.value)),
                              ],
                            ),
                          ))
                      .toList(),
                ),
              ),
            ),
          Card(
            child: ExpansionTile(
              title: const Text('Journal technique'),
              childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              children: [
                SelectableText(
                  result.log.isEmpty ? '(vide)' : result.log.join('\n'),
                  style: const TextStyle(fontFamily: 'monospace', fontSize: 11),
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            icon: const Icon(Icons.copy),
            label: const Text('Copier le rapport complet'),
            onPressed: () async {
              await Clipboard.setData(ClipboardData(text: result.report()));
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Rapport copié')));
              }
            },
          ),
          const SizedBox(height: 8),
          FilledButton(
            onPressed: () => Navigator.pop(context),
            child: Text(failed ? 'Retour / Réessayer' : 'Terminer'),
          ),
        ],
      ),
    );
  }
}
