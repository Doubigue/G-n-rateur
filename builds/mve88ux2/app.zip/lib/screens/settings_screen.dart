import 'package:flutter/material.dart';
import '../config.dart';
import '../update_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _repo = TextEditingController();
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    Config.getRepo().then((v) {
      if (mounted) setState(() => _repo.text = v);
    });
  }

  @override
  void dispose() {
    _repo.dispose();
    super.dispose();
  }

  Future<void> _checkNow() async {
    setState(() => _busy = true);
    await Config.setRepo(_repo.text);
    final u = UpdateController.instance;
    await u.check(manual: true);
    if (!mounted) return;
    setState(() => _busy = false);
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(u.lastCheckMessage ?? 'Terminé')));
  }

  @override
  Widget build(BuildContext context) {
    final u = UpdateController.instance;
    return Scaffold(
      appBar: AppBar(title: const Text('Réglages')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('Mises à jour', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 4),
          Text('Version installée : ${u.currentVersion}'),
          const SizedBox(height: 12),
          TextField(
            controller: _repo,
            autocorrect: false,
            decoration: const InputDecoration(
              labelText: 'Dépôt GitHub (pseudo/depot)',
              helperText:
                  'Le dépôt public où APK Studio publie vos APK. Les nouvelles versions y sont cherchées.',
              helperMaxLines: 3,
              prefixIcon: Icon(Icons.cloud_download_outlined),
            ),
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: _busy ? null : _checkNow,
            icon: _busy
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.refresh),
            label: const Text('Enregistrer et rechercher'),
          ),
          const SizedBox(height: 24),
          Text('À savoir', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 4),
          const Text(
              '• La recherche se fait au lancement, au retour dans l’appli et toutes les 6 h tant qu’elle est ouverte.\n'
              '• Pour installer la mise à jour, Android peut demander d’autoriser cette appli à installer des applications.\n'
              '• Le nombre d’essais NCK est limité par le routeur : vérifiez toujours votre code.'),
        ],
      ),
    );
  }
}
