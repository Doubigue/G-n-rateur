package com.linkshare.ui

import android.app.Activity
import android.text.format.Formatter
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linkshare.core.ExternalEditor
import com.linkshare.core.MediaStudioRouter
import com.linkshare.core.StudioCommand
import com.linkshare.core.StudioContract
import com.linkshare.core.StudioFilter
import com.linkshare.core.StudioLaunch
import com.linkshare.core.StudioTextPos
import java.io.File

// ═══════════════════════════ Types de fichiers ═══════════════════════════

internal enum class MediaKind { AUDIO, VIDEO, IMAGE, OTHER }

internal fun File.mediaKind(): MediaKind = when (category()) {
    Category.VIDEOS -> MediaKind.VIDEO
    Category.MUSIC -> MediaKind.AUDIO
    Category.PHOTOS -> MediaKind.IMAGE
    else -> MediaKind.OTHER
}

/** Vrai si la feuille « Studio » a quelque chose à proposer pour cette sélection (sert à afficher ou non l'entrée de menu). */
internal fun studioRelevant(files: List<File>): Boolean {
    if (files.isEmpty() || files.any { it.isDirectory }) return false
    val kinds = files.map { it.mediaKind() }
    return when (files.size) {
        1 -> true // un fichier seul : Studio est toujours accessible (la feuille explique si le type n'est pas pris en charge)
        else -> kinds.all { it == MediaKind.VIDEO } ||
            (files.size == 2 && kinds.count { it == MediaKind.VIDEO } == 1 && kinds.count { it == MediaKind.AUDIO } == 1)
    }
}

// ═══════════════════════════ Modèle d'actions (pur, sans Compose) ═══════════════════════════

internal class StudioRow(
    val icon: ImageVector, val tint: Color, val title: String, val subtitle: String,
    /** true : nécessite MediaStudio (grisé s'il n'est pas installé). */
    val needsStudio: Boolean = true,
    val onClick: () -> Unit,
)

internal class StudioChips(val title: String, val chips: List<Pair<String, () -> Unit>>)

internal class StudioSection(val title: String, val rows: List<StudioRow> = emptyList(), val chips: StudioChips? = null)

/**
 * Liste dynamique des actions selon le type des fichiers (audio / vidéo / image) et leur nombre.
 * [run] envoie une commande à MediaStudio ; [edit] ouvre « Modifier avec… » ; [askText] demande le texte à incruster.
 */
internal fun buildStudioSections(
    files: List<File>, run: (StudioCommand) -> Unit, edit: (File) -> Unit, askText: () -> Unit,
): List<StudioSection> = buildList {
    if (files.size == 1) {
        val f = files[0]
        when (f.mediaKind()) {
            MediaKind.AUDIO -> add(StudioSection("Conversion", buildList {
                if (f.extension.equals("mp3", true)) {
                    add(StudioRow(Ic.Music, LS.Purple, "Alléger le MP3", "Réencodage à 128 kbps") { run(StudioCommand.toMp3(128)) })
                } else {
                    add(StudioRow(Ic.Music, LS.Purple, "Convertir en MP3", "192 kbps · qualité standard") { run(StudioCommand.toMp3(192)) })
                    add(StudioRow(Ic.Music, LS.Purple, "MP3 haute qualité", "320 kbps") { run(StudioCommand.toMp3(320)) })
                    add(StudioRow(Ic.Music, LS.Purple, "MP3 léger", "128 kbps · fichier réduit") { run(StudioCommand.toMp3(128)) })
                }
            }))

            MediaKind.VIDEO -> {
                add(StudioSection("Conversion", listOf(
                    StudioRow(Ic.Music, LS.Purple, "Extraire l'audio en MP3", "192 kbps · enregistré dans Musique") { run(StudioCommand.toMp3(192)) },
                )))
                add(StudioSection("Compression", listOf(
                    StudioRow(Ic.Archive, LS.Amber, "Compresser en 480p", "Très léger · ~1 Mbit/s") { run(StudioCommand.compress(480, 1_000_000)) },
                    StudioRow(Ic.Archive, LS.Amber, "Compresser en 720p", "Équilibré · ~2 Mbit/s") { run(StudioCommand.compress(720, 2_000_000)) },
                    StudioRow(Ic.Archive, LS.Amber, "Compresser en 1080p", "Haute qualité · ~4 Mbit/s") { run(StudioCommand.compress(1080, 4_000_000)) },
                )))
                add(StudioSection(
                    "Effets",
                    rows = listOf(StudioRow(Ic.Edit, LS.Pink, "Ajouter un texte…", "Incruster un titre sur la vidéo") { askText() }),
                    chips = StudioChips("Appliquer un filtre", StudioFilter.entries.map { fl -> fl.label to { run(StudioCommand.effect(fl)) } }),
                ))
            }

            else -> Unit
        }
    } else {
        val videos = files.count { it.mediaKind() == MediaKind.VIDEO }
        val audios = files.count { it.mediaKind() == MediaKind.AUDIO }
        when {
            videos == files.size && videos >= 2 -> add(StudioSection("Montage", listOf(
                StudioRow(Ic.Video, LS.Red, "Assembler les $videos vidéos", "Dans l'ordre de sélection") { run(StudioCommand.concat(false)) },
                StudioRow(Ic.Video, LS.Red, "Assembler avec fondu", "Fondu au noir entre les clips") { run(StudioCommand.concat(true)) },
            )))

            files.size == 2 && videos == 1 && audios == 1 -> add(StudioSection("Montage", listOf(
                StudioRow(Ic.Music, LS.Purple, "Ajouter la musique à la vidéo", "Son d'origine conservé · musique à 80 %") { run(StudioCommand.mix(true)) },
                StudioRow(Ic.Music, LS.Purple, "Remplacer le son par la musique", "Le son d'origine est supprimé") { run(StudioCommand.mix(false, musicVolume = 1f)) },
            )))
        }
    }

    // « Modifier avec… » : un seul fichier image / vidéo / audio, indépendant de MediaStudio
    val single = files.singleOrNull()
    if (single != null && single.mediaKind() != MediaKind.OTHER) {
        val what = when (single.mediaKind()) { MediaKind.IMAGE -> "cette image"; MediaKind.VIDEO -> "cette vidéo"; else -> "ce fichier audio" }
        add(StudioSection("Modifier", listOf(
            StudioRow(Ic.Edit, LS.Blue, "Modifier avec…", "Choisir une application pour retoucher $what", needsStudio = false) { edit(single) },
        )))
    }
}

// ═══════════════════════════ Feuille + gestion du résultat ═══════════════════════════

/**
 * À composer UNE fois (à côté de FileInfoSheet). Le launcher reste toujours composé : le résultat de MediaStudio
 * arrive même après la fermeture de la feuille.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun MediaActionsHost(ex: ExplorerViewModel) {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        when (r.resultCode) {
            Activity.RESULT_OK -> {
                val name = r.data?.getStringExtra(StudioContract.EXTRA_OUTPUT_NAME)
                ex.message = if (name.isNullOrEmpty()) "Traitement terminé" else "Terminé : $name"
                ex.reload() // le résultat est écrit dans Movies/MediaStudio ou Music/MediaStudio
            }
            else -> r.data?.getStringExtra(StudioContract.EXTRA_ERROR)?.let { ex.message = "Media Studio : $it" }
        }
    }

    val files = ex.studioFiles
    if (files.isEmpty()) return

    val installed = remember { MediaStudioRouter.isInstalled(ctx) }
    var textDialog by remember { mutableStateOf(false) }
    fun close() { ex.studioFiles = emptyList() }

    fun runCmd(cmd: StudioCommand) {
        val target = files
        close()
        when (val r = MediaStudioRouter.dispatch(ctx, { launcher.launch(it) }, cmd, target)) {
            StudioLaunch.Launched -> ex.selected.clear()
            StudioLaunch.NotInstalled -> ex.message = "Media Studio n'est pas installé"
            is StudioLaunch.Failed -> ex.message = r.reason
        }
    }

    fun editFile(f: File) {
        close()
        ExternalEditor.edit(ctx, f)?.let { ex.message = it }
    }

    val sections = remember(files) { buildStudioSections(files, ::runCmd, ::editFile) { textDialog = true } }

    ModalBottomSheet(
        onDismissRequest = ::close,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = LS.Sheet, contentColor = LS.Text,
    ) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).navigationBarsPadding()
                .padding(horizontal = 12.dp).padding(bottom = 20.dp),
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            StudioHeader(files)
            if (!installed && sections.any { s -> s.rows.any { it.needsStudio } || s.chips != null })
                Text(
                    "Media Studio n'est pas installé : ses actions sont désactivées.",
                    Modifier.padding(horizontal = 8.dp, vertical = 6.dp), color = LS.Muted, fontSize = 12.sp,
                )
            if (sections.isEmpty()) Text(
                if (files.size == 1) "Media Studio ne traite que l'audio, la vidéo et les images : ce type de fichier n'est pas pris en charge."
                else "Pour plusieurs fichiers : sélectionnez au moins deux vidéos (assemblage) ou une vidéo et une musique (mixage).",
                Modifier.padding(8.dp), color = LS.Muted, fontSize = 13.sp,
            )
            sections.forEach { s ->
                Text(
                    s.title, Modifier.padding(start = 8.dp, top = 12.dp, bottom = 2.dp),
                    color = LS.Blue, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                )
                s.rows.forEach { StudioRowItem(it, enabled = installed || !it.needsStudio) }
                s.chips?.let { ChipsBlock(it, enabled = installed) }
            }
        }
    }

    if (textDialog) TextOverlayDialog(
        onDismiss = { textDialog = false },
        onConfirm = { text, pos -> textDialog = false; runCmd(StudioCommand.effect(null, text, pos)) },
    )
}

@Composable
private fun StudioHeader(files: List<File>) {
    val ctx = LocalContext.current
    val title = if (files.size == 1) files[0].name else "${files.size} fichiers sélectionnés"
    val sub = if (files.size == 1) {
        val kind = when (files[0].mediaKind()) { MediaKind.AUDIO -> "Audio"; MediaKind.VIDEO -> "Vidéo"; MediaKind.IMAGE -> "Image"; else -> "Fichier" }
        "$kind · " + Formatter.formatShortFileSize(ctx, files[0].length())
    } else Formatter.formatShortFileSize(ctx, files.sumOf { it.length() })
    Column(Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
        Text(title, color = LS.Text, fontSize = 18.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(sub, color = LS.Muted, fontSize = 12.sp)
    }
}

@Composable
private fun StudioRowItem(row: StudioRow, enabled: Boolean) {
    Row(
        Modifier.fillMaxWidth().alpha(if (enabled) 1f else 0.4f).clip(RoundedCornerShape(16.dp))
            .clickable(enabled = enabled, onClick = row.onClick).padding(horizontal = 8.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconBadge(row.icon, row.tint, 42.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(row.title, color = LS.Text, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Text(row.subtitle, color = LS.Muted, fontSize = 12.sp)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ChipsBlock(chips: StudioChips, enabled: Boolean) {
    Column(Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) {
        Text(chips.title, color = LS.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            chips.chips.forEach { (label, onClick) ->
                FilterChip(selected = false, onClick = onClick, enabled = enabled, label = { Text(label) })
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TextOverlayDialog(onDismiss: () -> Unit, onConfirm: (String, StudioTextPos) -> Unit) {
    var text by remember { mutableStateOf("") }
    var pos by remember { mutableStateOf(StudioTextPos.BOTTOM) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Ajouter un texte") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(text, { text = it.take(120) }, label = { Text("Texte") }, singleLine = true)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StudioTextPos.entries.forEach { p -> FilterChip(pos == p, { pos = p }, label = { Text(p.label) }) }
                }
            }
        },
        confirmButton = { TextButton(enabled = text.isNotBlank(), onClick = { onConfirm(text.trim(), pos) }) { Text("Appliquer") } },
        dismissButton = { TextButton(onDismiss) { Text("Annuler") } },
    )
}
