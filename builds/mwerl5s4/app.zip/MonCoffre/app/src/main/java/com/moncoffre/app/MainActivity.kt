package com.moncoffre.app

import android.os.Bundle
import android.os.SystemClock
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK
import androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.moncoffre.app.ui.LockScreen
import com.moncoffre.app.ui.MonCoffreApp
import com.moncoffre.app.ui.MonCoffreTheme

class MainActivity : FragmentActivity() {

    private val vm: VaultViewModel by viewModels()

    private var unlocked by mutableStateOf(false)
    private var everUnlocked by mutableStateOf(false)
    private var autoPrompted = false
    private var stoppedAt = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Pas de capture d'écran ni d'aperçu dans les applis récentes.
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE,
        )
        setContent {
            MonCoffreTheme {
                Box(Modifier.fillMaxSize()) {
                    // L'appli reste composée sous l'écran de verrouillage pour ne pas
                    // perdre une saisie ou un import de fichier en cours.
                    if (everUnlocked) MonCoffreApp(vm)
                    if (!unlocked) {
                        LockScreen(
                            onUnlock = { authenticate() },
                            onBack = { moveTaskToBack(true) },
                        )
                    }
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        val away = SystemClock.elapsedRealtime() - stoppedAt
        if (unlocked && stoppedAt != 0L && away > LOCK_AFTER_MS && !vm.deviceUnsecured) {
            unlocked = false
            autoPrompted = false
        }
    }

    override fun onResume() {
        super.onResume()
        if (!unlocked && !autoPrompted) {
            autoPrompted = true
            authenticate()
        }
    }

    override fun onStop() {
        super.onStop()
        stoppedAt = SystemClock.elapsedRealtime()
    }

    private fun unlock() {
        unlocked = true
        everUnlocked = true
    }

    /** Empreinte / visage, ou à défaut le code, schéma ou mot de passe du téléphone. */
    private fun authenticate() {
        val authenticators = BIOMETRIC_WEAK or DEVICE_CREDENTIAL
        val status = BiometricManager.from(this).canAuthenticate(authenticators)
        if (status != BiometricManager.BIOMETRIC_SUCCESS) {
            vm.deviceUnsecured = true
            unlock()
            return
        }
        val prompt = BiometricPrompt(
            this,
            ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    unlock()
                }
            },
        )
        prompt.authenticate(
            BiometricPrompt.PromptInfo.Builder()
                .setTitle("Déverrouiller MonCoffre")
                .setSubtitle("Confirmez que c'est bien vous")
                .setAllowedAuthenticators(authenticators)
                .build()
        )
    }

    private companion object {
        /** Reverrouillage après une minute passée hors de l'appli. */
        const val LOCK_AFTER_MS = 60_000L
    }
}
