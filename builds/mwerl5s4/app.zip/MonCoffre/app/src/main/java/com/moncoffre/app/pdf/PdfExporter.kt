package com.moncoffre.app.pdf

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.TextPaint
import android.text.TextUtils
import com.moncoffre.app.data.Account
import com.moncoffre.app.data.PhoneContact
import com.moncoffre.app.data.Services
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/**
 * Génère le PDF (A4) en cartes : une carte par compte, une grille de cartes pour
 * les contacts. Passer une liste vide pour ne pas inclure une partie.
 * Utiliser une instance par export.
 */
class PdfExporter {

    private val pageW = 595
    private val pageH = 842
    private val margin = 36f
    private val contentW = pageW - 2 * margin
    private val bottom = pageH - 52f
    private val pad = 16f
    private val labelW = 140f
    private val labelX = margin + pad
    private val valueX = margin + pad + labelW
    private val valueW = contentW - 2 * pad - labelW
    private val lineH = 14.5f
    private val headerH = 44f
    private val cardGap = 14f

    private val ink = Color.rgb(22, 24, 29)
    private val grey = Color.rgb(108, 115, 128)
    private val pageBg = Color.rgb(244, 245, 248)
    private val hairline = Color.rgb(226, 229, 235)
    private val shadow = Color.rgb(228, 230, 236)
    private val chip = Color.rgb(241, 243, 247)
    private val gold = Color.rgb(176, 130, 22)
    private val goldLight = Color.rgb(226, 184, 87)
    private val night = Color.rgb(14, 16, 20)

    private val avatarColors = intArrayOf(
        Color.rgb(66, 133, 244), Color.rgb(31, 175, 88), Color.rgb(214, 36, 159),
        Color.rgb(232, 113, 10), Color.rgb(96, 1, 210), Color.rgb(34, 158, 217),
        Color.rgb(230, 33, 23), Color.rgb(74, 85, 104),
    )

    private val sansBold = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
    private val monoBold = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)

    private fun textPaint(size: Float, color: Int, face: Typeface = Typeface.SANS_SERIF): TextPaint {
        val p = TextPaint(Paint.ANTI_ALIAS_FLAG)
        p.textSize = size
        p.color = color
        p.typeface = face
        return p
    }

    private val pLabel = textPaint(8.5f, grey)
    private val pValue = textPaint(10.5f, ink)
    private val pMono = textPaint(10.5f, ink, monoBold)
    private val pCode = textPaint(10f, ink, monoBold)
    private val pCodeUsed = textPaint(10f, Color.rgb(165, 170, 180), Typeface.MONOSPACE).apply {
        isStrikeThruText = true
    }
    private val pTitle = textPaint(13f, ink, sansBold)
    private val pPill = textPaint(7.5f, Color.WHITE, sansBold).apply { letterSpacing = 0.08f }
    private val pBadge = textPaint(12f, Color.WHITE, sansBold).apply { textAlign = Paint.Align.CENTER }
    private val pSection = textPaint(10f, gold, sansBold).apply { letterSpacing = 0.14f }
    private val pFooter = textPaint(8f, grey)
    private val pFooterRight = textPaint(8f, grey).apply { textAlign = Paint.Align.RIGHT }
    private val pContactName = textPaint(10.5f, ink, sansBold)
    private val pContactNumber = textPaint(9.5f, Color.rgb(70, 76, 88), Typeface.MONOSPACE)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 0.8f
    }

    private val doc = PdfDocument()
    private var page: PdfDocument.Page? = null
    private lateinit var canvas: Canvas
    private var pageNo = 0
    private var y = 0f
    private var stamp = ""

    /** Une ligne à l'intérieur d'une carte de compte. */
    private class Row(val height: Float, val separator: Boolean, val draw: (Float) -> Unit)

    fun export(
        out: OutputStream,
        accounts: List<Account>,
        contacts: List<PhoneContact>,
        includeSecrets: Boolean,
    ) {
        stamp = SimpleDateFormat("dd/MM/yyyy 'à' HH:mm", Locale.FRANCE).format(Date())
        try {
            newPage()
            cover(accounts.size, contacts.size, includeSecrets)

            if (accounts.isNotEmpty()) {
                section("Comptes", accounts.size)
                accounts.forEach { drawAccount(it, includeSecrets) }
            }
            if (contacts.isNotEmpty()) {
                if (accounts.isNotEmpty()) y += 6f
                section("Contacts du téléphone", contacts.size)
                drawContacts(contacts)
            }
            finishPage()
            doc.writeTo(out)
        } finally {
            doc.close()
        }
    }

    // ---------- Pages ----------

    private fun newPage() {
        finishPage()
        pageNo++
        val p = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create())
        page = p
        canvas = p.canvas
        fill.color = pageBg
        canvas.drawRect(0f, 0f, pageW.toFloat(), pageH.toFloat(), fill)
        y = 38f
    }

    private fun finishPage() {
        val p = page ?: return
        canvas.drawText("Confidentiel · MonCoffre · exporté le $stamp", margin, pageH - 26f, pFooter)
        canvas.drawText("Page $pageNo", margin + contentW, pageH - 26f, pFooterRight)
        doc.finishPage(p)
        page = null
    }

    /** Passe à la page suivante s'il ne reste pas [height] points. */
    private fun ensure(height: Float) {
        if (y + height > bottom) newPage()
    }

    // ---------- Couverture et titres ----------

    private fun cover(accountCount: Int, contactCount: Int, includeSecrets: Boolean) {
        val bandH = 150f
        fill.color = night
        canvas.drawRect(0f, 0f, pageW.toFloat(), bandH, fill)
        fill.color = goldLight
        canvas.drawRect(margin, 40f, margin + 28f, 43f, fill)

        val brand = textPaint(9.5f, goldLight, sansBold).apply { letterSpacing = 0.22f }
        canvas.drawText("MONCOFFRE", margin, 64f, brand)
        val title = when {
            accountCount > 0 && contactCount > 0 -> "Comptes & contacts"
            accountCount > 0 -> "Comptes & mots de passe"
            else -> "Contacts du téléphone"
        }
        canvas.drawText(title, margin, 96f, textPaint(23f, Color.WHITE, sansBold))
        canvas.drawText("Exporté le $stamp", margin, 118f, textPaint(9.5f, Color.rgb(170, 177, 190)))

        // Tuiles de chiffres à droite.
        val pNumber = textPaint(19f, goldLight, sansBold).apply { textAlign = Paint.Align.CENTER }
        val pCaption = textPaint(7f, Color.rgb(170, 177, 190), sansBold).apply {
            textAlign = Paint.Align.CENTER
            letterSpacing = 0.12f
        }
        var right = pageW - margin
        val tiles = ArrayList<Pair<Int, String>>()
        if (contactCount > 0) tiles.add(Pair(contactCount, "CONTACTS"))
        if (accountCount > 0) tiles.add(Pair(accountCount, "COMPTES"))
        tiles.forEach { tile ->
            val w = 74f
            fill.color = Color.rgb(30, 34, 43)
            canvas.drawRoundRect(RectF(right - w, 50f, right, 108f), 10f, 10f, fill)
            canvas.drawText(tile.first.toString(), right - w / 2, 80f, pNumber)
            canvas.drawText(tile.second, right - w / 2, 96f, pCaption)
            right -= w + 8f
        }

        y = bandH + 16f
        if (accountCount > 0) {
            fill.color = Color.rgb(255, 246, 221)
            canvas.drawRoundRect(RectF(margin, y, margin + contentW, y + 30f), 8f, 8f, fill)
            val warning = if (includeSecrets) {
                "Document confidentiel : il contient vos mots de passe en clair. Ne le partagez pas."
            } else {
                "Mots de passe et codes masqués dans cet export."
            }
            canvas.drawText(warning, margin + 12f, y + 19f, textPaint(9f, Color.rgb(120, 84, 0), sansBold))
            y += 30f + 18f
        } else {
            y += 4f
        }
    }

    private fun section(title: String, count: Int) {
        ensure(120f)
        val text = title.uppercase(Locale.FRANCE)
        canvas.drawText(text, margin, y + 11f, pSection)
        // Pastille du nombre d'éléments.
        val label = count.toString()
        val left = margin + pSection.measureText(text) + 10f
        val w = pPill.measureText(label) + 14f
        fill.color = gold
        canvas.drawRoundRect(RectF(left, y, left + w, y + 15f), 7.5f, 7.5f, fill)
        canvas.drawText(label, left + 7f, y + 10.5f, pPill)
        y += 28f
    }

    // ---------- Carte d'un compte ----------

    private fun drawAccount(a: Account, includeSecrets: Boolean) {
        val hidden = "••••••••"
        val rows = ArrayList<Row>()
        addField(rows, "Identifiant", a.login, false)
        addField(rows, "Mot de passe", if (includeSecrets || a.password.isEmpty()) a.password else hidden, true)
        addField(rows, "Numéro de récupération", a.recoveryPhone, false)
        addField(rows, "E-mail de récupération", a.recoveryEmail, false)
        a.fields.filter { it.value.isNotBlank() }.forEach { f ->
            val shown = if (f.secret && !includeSecrets) hidden else f.value
            addField(rows, f.label.ifBlank { "Autre" }, shown, f.secret)
        }
        addCodes(rows, a, includeSecrets)
        addField(rows, "Notes", a.notes, false)

        // La carte est découpée en segments si elle ne tient pas sur la page.
        val padBottom = 8f
        var i = 0
        var first = true
        while (first || i < rows.size) {
            val head = if (first) headerH + 2f else 8f
            val firstRowH = if (i < rows.size) rows[i].height else 0f
            ensure(head + firstRowH + padBottom)

            var h = head
            var j = i
            while (j < rows.size && y + h + rows[j].height + padBottom <= bottom) {
                h += rows[j].height
                j++
            }
            if (j == i && i < rows.size) {
                h += rows[i].height
                j = i + 1
            }
            h += padBottom

            cardBackground(margin, y, contentW, h, 12f)
            if (first) accountHeader(a, y)
            stroke.color = hairline
            canvas.drawRoundRect(RectF(margin, y, margin + contentW, y + h), 12f, 12f, stroke)

            var cy = y + head
            for (k in i until j) {
                val row = rows[k]
                if (row.separator && k != i) {
                    fill.color = hairline
                    canvas.drawRect(labelX, cy, margin + contentW - pad, cy + 0.6f, fill)
                }
                row.draw(cy)
                cy += row.height
            }
            y += h + cardGap
            i = j
            first = false
        }
    }

    /** Fond blanc arrondi avec une ombre légère. */
    private fun cardBackground(x: Float, top: Float, w: Float, h: Float, radius: Float) {
        fill.color = shadow
        canvas.drawRoundRect(RectF(x + 0.5f, top + 2f, x + w + 0.5f, top + h + 2f), radius, radius, fill)
        fill.color = Color.WHITE
        canvas.drawRoundRect(RectF(x, top, x + w, top + h), radius, radius, fill)
    }

    private fun accountHeader(a: Account, top: Float) {
        val color = Services.color(a.service)
        // Bandeau teinté à la couleur du service, arrondi en haut seulement.
        val band = Path()
        band.addRoundRect(
            RectF(margin, top, margin + contentW, top + headerH),
            floatArrayOf(12f, 12f, 12f, 12f, 0f, 0f, 0f, 0f),
            Path.Direction.CW,
        )
        fill.color = tint(color, 0.11f)
        canvas.drawPath(band, fill)
        fill.color = color
        canvas.drawRect(margin, top + headerH - 1.2f, margin + contentW, top + headerH, fill)

        canvas.drawCircle(margin + pad + 13f, top + 22f, 13f, fill)
        canvas.drawText(Services.initial(a.service), margin + pad + 13f, top + 26.3f, pBadge)

        val service = a.service.uppercase(Locale.FRANCE)
        val pillW = pPill.measureText(service) + 16f
        val pillLeft = margin + contentW - 14f - pillW
        canvas.drawRoundRect(RectF(pillLeft, top + 13f, pillLeft + pillW, top + 31f), 9f, 9f, fill)
        canvas.drawText(service, pillLeft + 8f, top + 24.8f, pPill)

        val titleX = margin + pad + 36f
        val title = TextUtils.ellipsize(a.displayName, pTitle, pillLeft - titleX - 10f, TextUtils.TruncateAt.END)
        canvas.drawText(title.toString(), titleX, top + 26.5f, pTitle)
    }

    private fun addField(rows: MutableList<Row>, label: String, value: String, mono: Boolean) {
        if (value.isBlank()) return
        val paint = if (mono) pMono else pValue
        val labelLines = wrap(label, pLabel, labelW - 12f)
        val valueLines = wrap(value, paint, if (mono) valueW - 16f else valueW)
        val chunks = valueLines.chunked(12)
        chunks.forEachIndexed { index, chunk ->
            val firstChunk = index == 0
            val lines = if (firstChunk) max(labelLines.size, chunk.size) else chunk.size
            val topPad = if (firstChunk) 9f else 0f
            val height = topPad + lines * lineH + (if (index == chunks.lastIndex) 7f else 0f)
            rows.add(Row(height, firstChunk) { top ->
                val base = top + topPad + 10.5f
                if (firstChunk) {
                    labelLines.forEachIndexed { n, line ->
                        canvas.drawText(line, labelX, base + n * lineH, pLabel)
                    }
                }
                if (mono) {
                    // Les secrets sont posés sur une pastille grise.
                    val widest = chunk.maxOf { paint.measureText(it) }
                    fill.color = chip
                    canvas.drawRoundRect(
                        RectF(valueX, top + topPad - 2f, valueX + widest + 16f, top + topPad + chunk.size * lineH + 2f),
                        5f, 5f, fill,
                    )
                }
                chunk.forEachIndexed { n, line ->
                    canvas.drawText(line, valueX + (if (mono) 8f else 0f), base + n * lineH, paint)
                }
            })
        }
    }

    private fun addCodes(rows: MutableList<Row>, a: Account, includeSecrets: Boolean) {
        if (a.backupCodes.isEmpty()) return
        val remaining = a.backupCodes.count { !it.used }
        val summary = "$remaining restant(s) sur ${a.backupCodes.size}"
        if (!includeSecrets) {
            addField(rows, "Codes de secours", "$summary (masqués)", false)
            return
        }
        val chipW = a.backupCodes.maxOf { pCode.measureText(it.code) } + 16f
        val gap = 6f
        val columns = max(1, min(4, ((valueW + gap) / (chipW + gap)).toInt()))
        val grid = a.backupCodes.chunked(columns)
        val labelLines = wrap("Codes de secours\n$summary", pLabel, labelW - 12f)
        val lineRowH = 23f
        grid.forEachIndexed { index, line ->
            val firstLine = index == 0
            val topPad = if (firstLine) 9f else 0f
            var height = topPad + lineRowH
            if (firstLine && grid.size == 1) height = max(height, topPad + labelLines.size * lineH)
            if (index == grid.lastIndex) height += 4f
            rows.add(Row(height, firstLine) { top ->
                if (firstLine) {
                    labelLines.forEachIndexed { n, text ->
                        canvas.drawText(text, labelX, top + topPad + 10.5f + n * lineH, pLabel)
                    }
                }
                line.forEachIndexed { col, code ->
                    val left = valueX + col * (chipW + gap)
                    val chipTop = top + topPad
                    fill.color = if (code.used) Color.rgb(247, 248, 250) else chip
                    canvas.drawRoundRect(RectF(left, chipTop, left + chipW, chipTop + 18f), 5f, 5f, fill)
                    canvas.drawText(code.code, left + 8f, chipTop + 12.6f, if (code.used) pCodeUsed else pCode)
                }
            })
        }
    }

    // ---------- Cartes des contacts (grille à deux colonnes) ----------

    private fun drawContacts(list: List<PhoneContact>) {
        val gap = 10f
        val cardW = (contentW - gap) / 2
        list.chunked(2).forEach { pair ->
            val height = pair.maxOf { contactHeight(it) }
            ensure(height + gap)
            pair.forEachIndexed { col, contact ->
                contactCard(contact, margin + col * (cardW + gap), y, cardW, height)
            }
            y += height + gap
        }
    }

    private fun contactHeight(c: PhoneContact): Float = max(50f, 12f + 15f + c.numbers.size * 12.5f + 9f)

    private fun contactCard(c: PhoneContact, x: Float, top: Float, w: Float, h: Float) {
        cardBackground(x, top, w, h, 10f)
        stroke.color = hairline
        canvas.drawRoundRect(RectF(x, top, x + w, top + h), 10f, 10f, stroke)

        val color = avatarColors[(c.name.hashCode() and 0x7fffffff) % avatarColors.size]
        fill.color = tint(color, 0.16f)
        canvas.drawCircle(x + 25f, top + 25f, 14f, fill)
        val pInitial = textPaint(12f, color, sansBold).apply { textAlign = Paint.Align.CENTER }
        val initial = c.name.trim().take(1).uppercase(Locale.FRANCE).ifEmpty { "?" }
        canvas.drawText(initial, x + 25f, top + 29.3f, pInitial)

        val textX = x + 48f
        val textW = w - 48f - 10f
        val name = TextUtils.ellipsize(c.name, pContactName, textW, TextUtils.TruncateAt.END)
        canvas.drawText(name.toString(), textX, top + 22f, pContactName)
        c.numbers.forEachIndexed { n, number ->
            val shown = TextUtils.ellipsize(number, pContactNumber, textW, TextUtils.TruncateAt.END)
            canvas.drawText(shown.toString(), textX, top + 36f + n * 12.5f, pContactNumber)
        }
    }

    // ---------- Outils ----------

    /** Mélange [color] avec du blanc : 0 = blanc, 1 = couleur pleine. */
    private fun tint(color: Int, amount: Float): Int {
        fun mix(channel: Int) = (255 + (channel - 255) * amount).toInt()
        return Color.rgb(mix(Color.red(color)), mix(Color.green(color)), mix(Color.blue(color)))
    }

    private fun wrap(text: String, paint: TextPaint, width: Float): List<String> {
        val lines = ArrayList<String>()
        text.trim().split('\n').forEach { paragraph ->
            var rest = paragraph.trim()
            if (rest.isEmpty()) {
                lines.add("")
                return@forEach
            }
            while (rest.isNotEmpty()) {
                var count = paint.breakText(rest, true, width, null)
                if (count <= 0) count = 1
                if (count < rest.length) {
                    val space = rest.lastIndexOf(' ', count)
                    if (space > 0) count = space
                }
                lines.add(rest.substring(0, count).trimEnd())
                rest = rest.substring(count).trimStart()
            }
        }
        return lines
    }
}
