package com.moncoffre.app.data

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.ContactsContract.CommonDataKinds.Phone
import androidx.core.content.ContextCompat

data class PhoneContact(val name: String, val numbers: List<String>)

fun hasContactsPermission(context: Context): Boolean =
    ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) ==
        PackageManager.PERMISSION_GRANTED

/** Lit automatiquement tous les contacts du téléphone (nom + numéros). */
fun readContacts(context: Context): List<PhoneContact> {
    val byId = LinkedHashMap<Long, Pair<String, MutableList<String>>>()
    context.contentResolver.query(
        Phone.CONTENT_URI,
        arrayOf(Phone.CONTACT_ID, Phone.DISPLAY_NAME, Phone.NUMBER),
        null,
        null,
        Phone.DISPLAY_NAME + " COLLATE NOCASE ASC",
    )?.use { c ->
        while (c.moveToNext()) {
            val id = c.getLong(0)
            val name = c.getString(1)?.trim().orEmpty()
            val number = c.getString(2)?.trim().orEmpty()
            if (number.isEmpty()) continue
            val entry = byId.getOrPut(id) { Pair(name.ifEmpty { number }, mutableListOf()) }
            val digits = number.filter { it.isDigit() || it == '+' }
            if (entry.second.none { n -> n.filter { it.isDigit() || it == '+' } == digits }) {
                entry.second.add(number)
            }
        }
    }
    return byId.values.map { PhoneContact(it.first, it.second) }
}
