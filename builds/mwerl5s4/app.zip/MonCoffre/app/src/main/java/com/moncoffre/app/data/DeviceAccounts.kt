package com.moncoffre.app.data

import android.Manifest
import android.accounts.AccountManager
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat

/** Un compte présent sur le téléphone (ex. adresse Gmail) et le service associé. */
data class DeviceAccount(val name: String, val type: String, val service: String)

fun hasAccountsPermission(context: Context): Boolean =
    ContextCompat.checkSelfPermission(context, Manifest.permission.GET_ACCOUNTS) ==
        PackageManager.PERMISSION_GRANTED

private fun serviceForType(type: String): String {
    val t = type.lowercase()
    return when {
        "google" in t -> "Google"
        "whatsapp" in t -> "WhatsApp"
        "facebook" in t -> "Facebook"
        "instagram" in t -> "Instagram"
        "telegram" in t -> "Telegram"
        "linkedin" in t -> "LinkedIn"
        "twitter" in t -> "X (Twitter)"
        "snapchat" in t -> "Snapchat"
        "tiktok" in t || "musically" in t -> "TikTok"
        "microsoft" in t || "outlook" in t || "exchange" in t -> "Microsoft / Outlook"
        "yahoo" in t -> "Yahoo"
        "apple" in t || "icloud" in t -> "Apple / iCloud"
        else -> "Autre"
    }
}

/**
 * Lit les comptes déclarés sur l'appareil. Selon la version d'Android et le
 * fabricant, certains comptes peuvent ne pas être visibles par l'appli.
 */
fun readDeviceAccounts(context: Context): List<DeviceAccount> =
    AccountManager.get(context).accounts
        .filter { it.name.contains("@") }
        .map { DeviceAccount(it.name.trim(), it.type, serviceForType(it.type)) }
        .distinctBy { it.name.trim().lowercase() }
        .sortedBy { it.name.lowercase() }

/** Forme normalisée d'un identifiant pour détecter les doublons. */
fun normalizeLogin(login: String): String = login.trim().lowercase()
