package com.moncoffre.app.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.KeyStore
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Informations d'une clé de signature Android. Les secrets restent chiffrés dans le coffre. */
data class AppSigningKey(
    val id: String = UUID.randomUUID().toString(),
    val appName: String = "",
    val packageName: String = "",
    val keystoreFileName: String = "",
    val keyAlias: String = "",
    val storePassword: String = "",
    val keyPassword: String = "",
    val keyAlgorithm: String = "RSA",
    val validity: String = "",
    val sha1: String = "",
    val sha256: String = "",
    val notes: String = "",
    val updatedAt: Long = System.currentTimeMillis(),
)

private fun AppSigningKey.toJson() = JSONObject()
    .put("id", id).put("appName", appName).put("packageName", packageName)
    .put("keystoreFileName", keystoreFileName).put("keyAlias", keyAlias)
    .put("storePassword", storePassword).put("keyPassword", keyPassword)
    .put("keyAlgorithm", keyAlgorithm).put("validity", validity)
    .put("sha1", sha1).put("sha256", sha256).put("notes", notes)
    .put("updatedAt", updatedAt)

private fun signingKeyFromJson(o: JSONObject) = AppSigningKey(
    id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
    appName = o.optString("appName"), packageName = o.optString("packageName"),
    keystoreFileName = o.optString("keystoreFileName"), keyAlias = o.optString("keyAlias"),
    storePassword = o.optString("storePassword"), keyPassword = o.optString("keyPassword"),
    keyAlgorithm = o.optString("keyAlgorithm", "RSA"), validity = o.optString("validity"),
    sha1 = o.optString("sha1"), sha256 = o.optString("sha256"),
    notes = o.optString("notes"), updatedAt = o.optLong("updatedAt", System.currentTimeMillis()),
)

/** Fichier de clés de signature chiffré avec une clé non exportable Android Keystore. */
class AppSigningKeyVault(context: Context) {
    private val file = File(context.filesDir, "app-signing-keys.bin")

    private fun secretKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build()
        )
        return generator.generateKey()
    }

    fun load(): List<AppSigningKey> {
        if (!file.exists()) return emptyList()
        val raw = file.readBytes()
        require(raw.size > 28) { "Fichier de clés invalide" }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, raw, 0, 12))
        val array = JSONArray(String(cipher.doFinal(raw, 12, raw.size - 12), Charsets.UTF_8))
        return (0 until array.length()).map { signingKeyFromJson(array.getJSONObject(it)) }
    }

    fun save(items: List<AppSigningKey>) {
        val array = JSONArray()
        items.forEach { array.put(it.toJson()) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey())
        val bytes = cipher.iv + cipher.doFinal(array.toString().toByteArray(Charsets.UTF_8))
        val temp = File(file.parentFile, "app-signing-keys.tmp")
        temp.writeBytes(bytes)
        if (!temp.renameTo(file)) { file.writeBytes(bytes); temp.delete() }
    }

    private companion object { const val ALIAS = "moncoffre_app_signing_keys_key" }
}
