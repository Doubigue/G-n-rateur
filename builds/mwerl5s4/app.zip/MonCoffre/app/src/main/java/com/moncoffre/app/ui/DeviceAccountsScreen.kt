@file:OptIn(ExperimentalMaterial3Api::class)

package com.moncoffre.app.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.moncoffre.app.VaultViewModel
import com.moncoffre.app.data.hasAccountsPermission
import com.moncoffre.app.data.normalizeLogin

@Composable
fun DeviceAccountsScreen(vm: VaultViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    var granted by remember { mutableStateOf(hasAccountsPermission(context)) }
    var message by remember { mutableStateOf<String?>(null) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        granted = it
    }
    LaunchedEffect(granted) { if (granted) vm.loadDeviceAccounts() }
    BackHandler(onBack = onBack)

    val saved = vm.accounts.map { normalizeLogin(it.login) }.toSet()
    val available = vm.deviceAccounts.filter { normalizeLogin(it.name) !in saved }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Comptes de l’appareil") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                    }
                },
            )
        },
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            if (!granted) {
                Column(
                    Modifier.fillMaxSize().padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    Text(
                        "Autorisez MonCoffre à lire la liste des comptes du téléphone pour les ajouter en un geste.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = { launcher.launch(android.Manifest.permission.GET_ACCOUNTS) }) {
                        Text("Autoriser")
                    }
                }
                return@Column
            }

            Button(
                onClick = {
                    val n = vm.addDeviceAccounts(vm.deviceAccounts)
                    message = if (n == 0) "Rien à ajouter : tout est déjà enregistré."
                    else "$n compte(s) ajouté(s)."
                },
                enabled = available.isNotEmpty(),
                modifier = Modifier.fillMaxWidth().padding(16.dp),
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(if (available.isEmpty()) "Tout est déjà ajouté" else "Tout ajouter (${available.size})")
            }
            message?.let { Notice(it) }

            if (vm.deviceAccounts.isEmpty()) {
                Text(
                    "Aucun compte e-mail visible sur cet appareil.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(24.dp),
                )
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    items(vm.deviceAccounts, key = { it.name }) { acc ->
                        val exists = normalizeLogin(acc.name) in saved
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surfaceContainer,
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                ServiceBadge(acc.service)
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(acc.name, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                        style = MaterialTheme.typography.titleSmall)
                                    Text(acc.service, style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                OutlinedButton(
                                    enabled = !exists,
                                    onClick = {
                                        val n = vm.addDeviceAccounts(listOf(acc))
                                        message = if (n == 1) "${acc.name} ajouté." else null
                                    },
                                ) { Text(if (exists) "Déjà ajouté" else "Ajouter") }
                            }
                        }
                    }
                }
            }
        }
    }
}
