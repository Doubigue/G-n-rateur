package com.moncoffre.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.os.PersistableBundle
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.moncoffre.app.data.Services

val Gold = Color(0xFFE2B857)

private val Scheme = darkColorScheme(
    primary = Gold,
    onPrimary = Color(0xFF1B1503),
    primaryContainer = Color(0xFF3A2F0E),
    onPrimaryContainer = Color(0xFFF6E3AE),
    secondary = Color(0xFF9DB7E8),
    onSecondary = Color(0xFF0B1A33),
    secondaryContainer = Color(0xFF2A3345),
    onSecondaryContainer = Color(0xFFDCE6FA),
    background = Color(0xFF0E1014),
    onBackground = Color(0xFFECEEF2),
    surface = Color(0xFF0E1014),
    onSurface = Color(0xFFECEEF2),
    surfaceVariant = Color(0xFF1B2029),
    onSurfaceVariant = Color(0xFFA9B0BD),
    surfaceContainerLowest = Color(0xFF0B0D10),
    surfaceContainerLow = Color(0xFF13161C),
    surfaceContainer = Color(0xFF161A21),
    surfaceContainerHigh = Color(0xFF1B2029),
    surfaceContainerHighest = Color(0xFF232935),
    outline = Color(0xFF4A5263),
    outlineVariant = Color(0xFF2A303B),
    error = Color(0xFFFF8A80),
    onError = Color(0xFF2B0A07),
)

@Composable
fun MonCoffreTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}

/** Copie dans le presse-papiers en marquant le contenu comme sensible. */
fun copyToClipboard(context: Context, text: String) {
    val manager = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText("MonCoffre", text)
    clip.description.extras = PersistableBundle().apply {
        putBoolean("android.content.extra.IS_SENSITIVE", true)
    }
    manager.setPrimaryClip(clip)
    // Android 13+ affiche déjà sa propre confirmation.
    if (Build.VERSION.SDK_INT < 33) toast(context, "Copié")
}

fun toast(context: Context, message: String) {
    Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
}

@Composable
fun ServiceBadge(service: String, size: Dp = 44.dp) {
    Box(
        modifier = Modifier
            .size(size)
            .clip(RoundedCornerShape(size / 3))
            .background(Color(Services.color(service))),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = Services.initial(service),
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = (size.value * 0.42f).sp,
        )
    }
}

@Composable
fun SectionCard(
    title: String,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(modifier.fillMaxWidth()) {
        Text(
            text = title.uppercase(),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(start = 4.dp, bottom = 6.dp),
        )
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surfaceContainer,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                content = content,
            )
        }
    }
}

/** Ligne « intitulé / valeur » avec Copier, et Afficher/Masquer pour les secrets. */
@Composable
fun ValueRow(label: String, value: String, secret: Boolean = false) {
    val context = LocalContext.current
    var visible by remember(value, secret) { mutableStateOf(!secret) }
    Column(Modifier.fillMaxWidth()) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = if (visible) value else "•".repeat(value.length.coerceIn(6, 14)),
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.bodyLarge,
                fontFamily = if (secret) FontFamily.Monospace else null,
            )
            if (secret) {
                TextButton(onClick = { visible = !visible }) {
                    Text(if (visible) "Masquer" else "Afficher")
                }
            }
            TextButton(onClick = { copyToClipboard(context, value) }) { Text("Copier") }
        }
    }
}
