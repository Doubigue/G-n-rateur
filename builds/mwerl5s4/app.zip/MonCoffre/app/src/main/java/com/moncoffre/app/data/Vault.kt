package com.moncoffre.app.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.File
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Coffre local : un seul fichier chiffré en AES-256-GCM.
 * La clé vit dans l'Android Keystore et ne quitte jamais le téléphone.
 */
class Vault(context: Context) {

    private val file = File(context.filesDir, "vault.bin")

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(
                ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    fun load(): List<Account> {
        if (!file.exists()) return emptyList()
        val raw = file.readBytes()
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, raw, 0, IV_SIZE))
        val json = String(cipher.doFinal(raw, IV_SIZE, raw.size - IV_SIZE), Charsets.UTF_8)
        return accountsFromJson(json)
    }

    fun save(accounts: List<Account>) {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val data = cipher.iv + cipher.doFinal(accountsToJson(accounts).toByteArray(Charsets.UTF_8))
        val tmp = File(file.parentFile, "vault.tmp")
        tmp.writeBytes(data)
        if (!tmp.renameTo(file)) {
            file.writeBytes(data)
            tmp.delete()
        }
    }

    /** Met de côté un fichier illisible au lieu de l'écraser. */
    fun quarantine() {
        if (file.exists()) file.renameTo(File(file.parentFile, "vault-illisible-${System.currentTimeMillis()}.bin"))
    }

    private companion object {
        const val ALIAS = "moncoffre_vault_key"
        const val TRANSFORMATION = "AES/GCM/NoPadding"
        const val IV_SIZE = 12
    }
}

/**
 * Sauvegarde transportable (changement de téléphone) : chiffrée avec un mot de passe
 * choisi par l'utilisateur (PBKDF2 + AES-256-GCM).
 */
object BackupCrypto {
    private val MAGIC = byteArrayOf(0x4D, 0x43, 0x46, 0x01) // "MCF" v1
    private const val ITERATIONS = 150_000
    private const val SALT_SIZE = 16
    private const val IV_SIZE = 12

    private fun derive(password: String, salt: ByteArray): SecretKeySpec {
        val spec = PBEKeySpec(password.toCharArray(), salt, ITERATIONS, 256)
        val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        return SecretKeySpec(bytes, "AES")
    }

    fun encrypt(json: String, password: String): ByteArray {
        val random = SecureRandom()
        val salt = ByteArray(SALT_SIZE).also { random.nextBytes(it) }
        val iv = ByteArray(IV_SIZE).also { random.nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, derive(password, salt), GCMParameterSpec(128, iv))
        return MAGIC + salt + iv + cipher.doFinal(json.toByteArray(Charsets.UTF_8))
    }

    /** Lève une exception si le mot de passe est faux ou le fichier invalide. */
    fun decrypt(data: ByteArray, password: String): String {
        val header = MAGIC.size + SALT_SIZE + IV_SIZE
        require(data.size > header + 16 && data.copyOfRange(0, MAGIC.size).contentEquals(MAGIC)) {
            "Fichier de sauvegarde invalide"
        }
        val salt = data.copyOfRange(MAGIC.size, MAGIC.size + SALT_SIZE)
        val iv = data.copyOfRange(MAGIC.size + SALT_SIZE, header)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, derive(password, salt), GCMParameterSpec(128, iv))
        return String(cipher.doFinal(data, header, data.size - header), Charsets.UTF_8)
    }
}
