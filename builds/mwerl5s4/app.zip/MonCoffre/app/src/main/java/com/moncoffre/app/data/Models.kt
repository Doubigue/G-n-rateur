package com.moncoffre.app.data

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Un code de secours (à usage unique) : on le coche une fois utilisé. */
data class BackupCode(val code: String, val used: Boolean = false)

/** Champ libre : toute autre méthode de récupération ou information du compte. */
data class ExtraField(
    val id: String = UUID.randomUUID().toString(),
    val label: String = "",
    val value: String = "",
    val secret: Boolean = false,
)

data class Account(
    val id: String = UUID.randomUUID().toString(),
    val service: String = "Google",
    val title: String = "",
    val login: String = "",
    val password: String = "",
    val recoveryPhone: String = "",
    val recoveryEmail: String = "",
    val backupCodes: List<BackupCode> = emptyList(),
    val fields: List<ExtraField> = emptyList(),
    val notes: String = "",
    val updatedAt: Long = System.currentTimeMillis(),
) {
    val displayName: String
        get() = title.ifBlank { login.ifBlank { service } }
}

object Services {
    val all = listOf(
        "Google", "WhatsApp", "Facebook", "Instagram", "TikTok", "Telegram",
        "X (Twitter)", "Snapchat", "YouTube", "LinkedIn", "Microsoft / Outlook",
        "Yahoo", "Apple / iCloud", "Mobile Money / Banque", "Autre",
    )

    /** Couleur ARGB de la pastille du service (appli et PDF). */
    fun color(service: String): Int = when (service) {
        "Google" -> 0xFF4285F4.toInt()
        "WhatsApp" -> 0xFF1FAF58.toInt()
        "Facebook" -> 0xFF1877F2.toInt()
        "Instagram" -> 0xFFD6249F.toInt()
        "TikTok" -> 0xFFEE1D52.toInt()
        "Telegram" -> 0xFF229ED9.toInt()
        "X (Twitter)" -> 0xFF4A5568.toInt()
        "Snapchat" -> 0xFFD9A800.toInt()
        "YouTube" -> 0xFFE62117.toInt()
        "LinkedIn" -> 0xFF0A66C2.toInt()
        "Microsoft / Outlook" -> 0xFF0F6CBD.toInt()
        "Yahoo" -> 0xFF6001D2.toInt()
        "Apple / iCloud" -> 0xFF6B7280.toInt()
        "Mobile Money / Banque" -> 0xFFE8710A.toInt()
        else -> 0xFF7A8699.toInt()
    }

    fun initial(service: String): String =
        if (service.startsWith("X ")) "X" else service.take(1).uppercase()

    /** Suggestions de méthodes de récupération selon le service. */
    fun presets(service: String): List<String> = when (service) {
        "Google", "YouTube" -> listOf(
            "Clé de configuration Authenticator (2FA)",
            "Numéro pour les codes SMS (2FA)",
            "Appareil de confiance (invite Google)",
            "Clé d'accès (passkey) – appareil",
            "Clé de sécurité physique",
            "Date de création du compte",
            "Dernier mot de passe connu",
            "Question secrète",
            "Réponse secrète",
            "Mot de passe d'application",
            "Date de naissance du compte",
        )
        "WhatsApp" -> listOf(
            "PIN de vérification en deux étapes",
            "E-mail lié au PIN",
            "Clé de chiffrement de la sauvegarde",
            "Compte Google de la sauvegarde",
        )
        "Facebook", "Instagram" -> listOf(
            "Nom d'utilisateur",
            "Clé Authenticator (2FA)",
            "Numéro lié au compte",
            "E-mail lié au compte",
            "Date de naissance du compte",
            "Contacts de confiance",
        )
        "Mobile Money / Banque" -> listOf(
            "Code PIN",
            "Numéro du compte",
            "Question secrète",
            "Réponse secrète",
        )
        else -> listOf(
            "Nom d'utilisateur",
            "Clé Authenticator (2FA)",
            "Numéro lié au compte",
            "E-mail lié au compte",
            "Code PIN",
            "Question secrète",
            "Réponse secrète",
        )
    }

    /** Un champ est masqué par défaut si son intitulé évoque un secret. */
    fun isSecretLabel(label: String): Boolean {
        val l = label.lowercase()
        return listOf("mot de passe", "pin", "clé", "réponse", "code").any { it in l } &&
            "appareil" !in l && "physique" !in l
    }
}

/**
 * Extrait les codes de secours d'un texte (fichier .txt téléchargé depuis Google,
 * ou codes collés). Reconnaît d'abord le format Google « 1234 5678 » ;
 * sinon, prend une ligne = un code.
 */
fun parseBackupCodes(text: String): List<String> {
    val eightDigits = Regex("(?<!\\d)\\d{4} ?\\d{4}(?!\\d)").findAll(text)
        .map { it.value.replace(" ", "") }
        .map { it.substring(0, 4) + " " + it.substring(4) }
        .toList()
    if (eightDigits.isNotEmpty()) return eightDigits.distinct()
    return text.lines()
        .map { it.trim().replace(Regex("^\\d{1,2}[.)]\\s+"), "") }
        .filter { it.isNotEmpty() && it.length <= 80 }
        .distinct()
}

// ---------- JSON ----------

private fun Account.toJson(): JSONObject {
    val codes = JSONArray()
    backupCodes.forEach { codes.put(JSONObject().put("code", it.code).put("used", it.used)) }
    val extra = JSONArray()
    fields.forEach {
        extra.put(
            JSONObject().put("id", it.id).put("label", it.label)
                .put("value", it.value).put("secret", it.secret)
        )
    }
    return JSONObject()
        .put("id", id)
        .put("service", service)
        .put("title", title)
        .put("login", login)
        .put("password", password)
        .put("recoveryPhone", recoveryPhone)
        .put("recoveryEmail", recoveryEmail)
        .put("backupCodes", codes)
        .put("fields", extra)
        .put("notes", notes)
        .put("updatedAt", updatedAt)
}

private fun accountFromJson(o: JSONObject): Account {
    val codes = o.optJSONArray("backupCodes") ?: JSONArray()
    val extra = o.optJSONArray("fields") ?: JSONArray()
    return Account(
        id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
        service = o.optString("service", "Autre"),
        title = o.optString("title"),
        login = o.optString("login"),
        password = o.optString("password"),
        recoveryPhone = o.optString("recoveryPhone"),
        recoveryEmail = o.optString("recoveryEmail"),
        backupCodes = (0 until codes.length()).map {
            val c = codes.getJSONObject(it)
            BackupCode(c.optString("code"), c.optBoolean("used"))
        },
        fields = (0 until extra.length()).map {
            val f = extra.getJSONObject(it)
            ExtraField(
                id = f.optString("id").ifBlank { UUID.randomUUID().toString() },
                label = f.optString("label"),
                value = f.optString("value"),
                secret = f.optBoolean("secret"),
            )
        },
        notes = o.optString("notes"),
        updatedAt = o.optLong("updatedAt", System.currentTimeMillis()),
    )
}

fun accountsToJson(list: List<Account>): String {
    val arr = JSONArray()
    list.forEach { arr.put(it.toJson()) }
    return JSONObject().put("version", 1).put("accounts", arr).toString()
}

fun accountsFromJson(json: String): List<Account> {
    val arr = JSONObject(json).optJSONArray("accounts") ?: return emptyList()
    return (0 until arr.length()).map { accountFromJson(arr.getJSONObject(it)) }
}
