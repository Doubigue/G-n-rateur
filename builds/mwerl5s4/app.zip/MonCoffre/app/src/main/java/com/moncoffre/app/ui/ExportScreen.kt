package com.moncoffre.app.ui

import android.Manifest
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.moncoffre.app.VaultViewModel
import com.moncoffre.app.data.BackupCrypto
import com.moncoffre.app.data.accountsFromJson
import com.moncoffre.app.data.accountsToJson
import com.moncoffre.app.data.hasContactsPermission
import com.moncoffre.app.pdf.PdfExporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val CONTENT_ACCOUNTS = 0
private const val CONTENT_CONTACTS = 1
private const val CONTENT_BOTH = 2

// ------------------------------------------------------------------
// Export : choix du contenu → aperçu → enregistrement du PDF
// ------------------------------------------------------------------

@Composable
fun ExportScreen(vm: VaultViewModel, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val day = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }
    val previewFile = remember {
        File(context.cacheDir, "apercu.pdf").also { it.delete() }
    }

    var contactsAllowed by remember { mutableStateOf(hasContactsPermission(context)) }
    var content by rememberSaveable { mutableIntStateOf(CONTENT_ACCOUNTS) }
    var includeSecrets by rememberSaveable { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }
    var preview by remember { mutableStateOf<File?>(null) }
    var confirmPdf by remember { mutableStateOf(false) }
    var askExportPassword by remember { mutableStateOf(false) }
    var backupPassword by remember { mutableStateOf("") }
    var importUri by remember { mutableStateOf<Uri?>(null) }

    val permission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        contactsAllowed = granted
        if (!granted) {
            content = CONTENT_ACCOUNTS
            toast(context, "Sans cette autorisation, les contacts ne peuvent pas être exportés")
        }
    }

    LaunchedEffect(contactsAllowed) {
        if (contactsAllowed && !vm.contactsLoaded) vm.loadContacts()
    }
    // L'aperçu contient des mots de passe : il ne reste jamais sur le disque.
    DisposableEffect(Unit) {
        onDispose { previewFile.delete() }
    }

    val withAccounts = content != CONTENT_CONTACTS
    val withContacts = content != CONTENT_ACCOUNTS
    val accounts = if (withAccounts) vm.accounts else emptyList()
    val contacts = if (withContacts && contactsAllowed) vm.contacts else emptyList()
    val fileName = "MonCoffre_" + listOf("Comptes", "Contacts", "Complet")[content] + "_$day.pdf"

    val closePreview: () -> Unit = {
        preview = null
        previewFile.delete()
    }

    val pdfSaver = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        val source = preview
        if (uri != null && source != null) {
            busy = true
            scope.launch {
                val ok = withContext(Dispatchers.IO) {
                    runCatching {
                        context.contentResolver.openOutputStream(uri)!!.use { out ->
                            source.inputStream().use { it.copyTo(out) }
                        }
                    }.isSuccess
                }
                busy = false
                if (ok) {
                    toast(context, "PDF enregistré")
                    closePreview()
                } else {
                    toast(context, "Échec de l'enregistrement du PDF")
                }
            }
        }
    }

    val buildPreview: () -> Unit = {
        val secrets = includeSecrets
        busy = true
        scope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    previewFile.outputStream().use { out ->
                        PdfExporter().export(out, accounts, contacts, secrets)
                    }
                }.isSuccess
            }
            busy = false
            if (ok) preview = previewFile else toast(context, "Échec de la création de l'aperçu")
        }
    }

    val backupSaver = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri ->
        val password = backupPassword
        backupPassword = ""
        if (uri != null && password.isNotEmpty()) {
            val json = accountsToJson(vm.accounts)
            busy = true
            scope.launch {
                val ok = withContext(Dispatchers.IO) {
                    runCatching {
                        val data = BackupCrypto.encrypt(json, password)
                        context.contentResolver.openOutputStream(uri)!!.use { it.write(data) }
                    }.isSuccess
                }
                busy = false
                toast(context, if (ok) "Sauvegarde enregistrée" else "Échec de la sauvegarde")
            }
        }
    }

    val backupPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> importUri = uri }

    val shown = preview
    if (shown != null) {
        PdfPreview(
            file = shown,
            busy = busy,
            onBack = closePreview,
            onSave = {
                if (includeSecrets && withAccounts) confirmPdf = true else pdfSaver.launch(fileName)
            },
            modifier = modifier,
        )
    } else {
        Column(
            modifier = modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
        ) {
            if (busy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())

            SectionCard("Document PDF") {
                Text(
                    text = "Choisissez ce que contient le PDF, regardez l'aperçu, puis enregistrez-le.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Comptes", "Contacts", "Les deux").forEachIndexed { index, label ->
                        FilterChip(
                            selected = content == index,
                            onClick = {
                                content = index
                                if (index != CONTENT_ACCOUNTS && !contactsAllowed) {
                                    permission.launch(Manifest.permission.READ_CONTACTS)
                                }
                            },
                            label = { Text(label) },
                        )
                    }
                }
                val parts = ArrayList<String>()
                if (withAccounts) parts.add("${vm.accounts.size} compte(s)")
                if (withContacts) {
                    parts.add(
                        if (contactsAllowed && !vm.contactsLoaded) "contacts en cours de lecture…"
                        else "${contacts.size} contact(s)"
                    )
                }
                Text(
                    text = parts.joinToString("  ·  "),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary,
                )
                if (withAccounts) {
                    SwitchRow(
                        label = "Inclure mots de passe et codes",
                        checked = includeSecrets,
                        onChange = { includeSecrets = it },
                    )
                }
                Button(
                    enabled = !busy && (accounts.isNotEmpty() || contacts.isNotEmpty()),
                    onClick = buildPreview,
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Voir l'aperçu") }
            }

            SectionCard("Sauvegarde chiffrée") {
                Text(
                    text = "Le coffre n'existe que sur ce téléphone. Gardez une sauvegarde protégée par mot de passe pour le retrouver après un changement de téléphone ou une réinstallation.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        enabled = !busy && vm.accounts.isNotEmpty(),
                        onClick = { askExportPassword = true },
                    ) { Text("Sauvegarder") }
                    OutlinedButton(
                        enabled = !busy,
                        onClick = { backupPicker.launch(arrayOf("*/*")) },
                    ) { Text("Restaurer") }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (confirmPdf) {
        AlertDialog(
            onDismissRequest = { confirmPdf = false },
            title = { Text("PDF non chiffré") },
            text = {
                Text("Ce PDF contiendra vos mots de passe en clair : toute personne qui l'ouvre peut les lire. Enregistrez-le dans un endroit sûr et ne l'envoyez pas par messagerie.")
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmPdf = false
                    pdfSaver.launch(fileName)
                }) { Text("Enregistrer") }
            },
            dismissButton = {
                TextButton(onClick = { confirmPdf = false }) { Text("Annuler") }
            },
        )
    }

    if (askExportPassword) {
        PasswordDialog(
            title = "Mot de passe de la sauvegarde",
            message = "Il sera demandé pour restaurer. S'il est oublié, la sauvegarde est irrécupérable.",
            confirmLabel = "Continuer",
            minLength = 6,
            onDismiss = { askExportPassword = false },
            onConfirm = { password ->
                askExportPassword = false
                backupPassword = password
                backupSaver.launch("MonCoffre_$day.mcoffre")
            },
        )
    }

    importUri?.let { uri ->
        PasswordDialog(
            title = "Restaurer la sauvegarde",
            message = "Saisissez le mot de passe choisi lors de la sauvegarde. Les comptes seront ajoutés à ceux déjà présents.",
            confirmLabel = "Restaurer",
            minLength = 1,
            onDismiss = { importUri = null },
            onConfirm = { password ->
                importUri = null
                busy = true
                scope.launch {
                    val imported = withContext(Dispatchers.IO) {
                        runCatching {
                            val data = context.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                            accountsFromJson(BackupCrypto.decrypt(data, password))
                        }.getOrNull()
                    }
                    busy = false
                    if (imported == null) {
                        toast(context, "Mot de passe incorrect ou fichier invalide")
                    } else {
                        toast(context, "${vm.importAccounts(imported)} compte(s) restauré(s)")
                    }
                }
            },
        )
    }
}

// ------------------------------------------------------------------
// Aperçu : les pages du PDF réellement généré, avant enregistrement
// ------------------------------------------------------------------

/** Rend les pages d'un PDF en images, une à la fois. */
private class PdfPages(file: File) {
    private val descriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
    private val renderer = PdfRenderer(descriptor)
    private var closed = false
    val count: Int = renderer.pageCount

    @Synchronized
    fun render(index: Int, width: Int): Bitmap? {
        if (closed) return null
        val page = renderer.openPage(index)
        try {
            val height = width * page.height / page.width
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            bitmap.eraseColor(android.graphics.Color.WHITE)
            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            return bitmap
        } finally {
            page.close()
        }
    }

    @Synchronized
    fun close() {
        if (closed) return
        closed = true
        renderer.close()
        descriptor.close()
    }
}

@Composable
private fun PdfPreview(
    file: File,
    busy: Boolean,
    onBack: () -> Unit,
    onSave: () -> Unit,
    modifier: Modifier = Modifier,
) {
    BackHandler(onBack = onBack)
    val pages = remember(file) { runCatching { PdfPages(file) }.getOrNull() }
    DisposableEffect(pages) {
        onDispose { pages?.close() }
    }

    Column(modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 20.dp, vertical = 4.dp)) {
            Text("Aperçu du PDF", style = MaterialTheme.typography.titleMedium)
            Text(
                text = if (pages != null) "${pages.count} page(s) · rien n'est encore enregistré"
                else "Aperçu indisponible sur cet appareil, vous pouvez tout de même enregistrer",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        if (busy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (pages != null) {
                items(pages.count) { index ->
                    PdfPageCard(pages, index)
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            OutlinedButton(onClick = onBack, modifier = Modifier.weight(1f)) {
                Text("Modifier")
            }
            Button(onClick = onSave, enabled = !busy, modifier = Modifier.weight(1.5f)) {
                Text("Enregistrer le PDF")
            }
        }
    }
}

@Composable
private fun PdfPageCard(pages: PdfPages, index: Int) {
    val bitmap by produceState<Bitmap?>(initialValue = null, pages, index) {
        value = withContext(Dispatchers.IO) {
            runCatching { pages.render(index, 1080) }.getOrNull()
        }
    }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color.White,
            shadowElevation = 6.dp,
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(595f / 842f),
        ) {
            val rendered = bitmap
            if (rendered != null) {
                Image(
                    bitmap = rendered.asImageBitmap(),
                    contentDescription = "Page ${index + 1}",
                    modifier = Modifier.fillMaxSize(),
                )
            }
        }
        Text(
            text = "Page ${index + 1} / ${pages.count}",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 6.dp, bottom = 6.dp),
        )
    }
}

// ------------------------------------------------------------------
// Petits composants
// ------------------------------------------------------------------

@Composable
private fun SwitchRow(
    label: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit,
    enabled: Boolean = true,
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            text = label,
            modifier = Modifier.weight(1f),
            color = if (enabled) MaterialTheme.colorScheme.onSurface
            else MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}

@Composable
private fun PasswordDialog(
    title: String,
    message: String,
    confirmLabel: String,
    minLength: Int,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit,
) {
    var password by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(message)
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text(if (minLength > 1) "Mot de passe ($minLength caractères min.)" else "Mot de passe") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            TextButton(enabled = password.length >= minLength, onClick = { onConfirm(password) }) {
                Text(confirmLabel)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Annuler") }
        },
    )
}
