package com.moncoffre.app.pdf

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import com.moncoffre.app.data.AppSigningKey
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Export A4 des fiches de clés de signature. Le PDF contient des secrets si l'option est activée. */
class AppSigningKeyPdfExporter {
    fun export(out: OutputStream, items: List<AppSigningKey>, includePasswords: Boolean) {
        val doc = PdfDocument()
        val width = 595
        val height = 842
        val margin = 40f
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(25, 29, 38); textSize = 22f; typeface = Typeface.DEFAULT_BOLD
        }
        val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(100, 108, 122); textSize = 9f; typeface = Typeface.DEFAULT_BOLD
        }
        val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(28, 32, 40); textSize = 11f
        }
        val monoPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(28, 32, 40); textSize = 10f; typeface = Typeface.MONOSPACE
        }
        val mutedPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.GRAY; textSize = 8f }
        val gold = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(176, 130, 22) }
        val stamp = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE).format(Date())
        var pageNo = 0
        var page: PdfDocument.Page? = null
        var canvas: Canvas? = null
        var y = 0f

        fun startPage() {
            page?.let { p ->
                p.canvas.drawText("CONFIDENTIEL · MonCoffre · $stamp", margin, height - 24f, mutedPaint)
                p.canvas.drawText("Page $pageNo", width - margin - 35f, height - 24f, mutedPaint)
                doc.finishPage(p)
            }
            pageNo++
            val p = doc.startPage(PdfDocument.PageInfo.Builder(width, height, pageNo).create())
            page = p; canvas = p.canvas; y = 48f
            p.canvas.drawColor(Color.rgb(247, 248, 250))
            p.canvas.drawRect(0f, 0f, width.toFloat(), 112f, Paint().apply { color = Color.rgb(18, 22, 30) })
            p.canvas.drawText("MONCOFFRE", margin, 44f, Paint(titlePaint).apply {
                color = Color.rgb(226, 184, 87); textSize = 10f
            })
            p.canvas.drawText("Clés de signature des applications", margin, 78f, Paint(titlePaint).apply {
                color = Color.WHITE; textSize = 19f
            })
            p.canvas.drawText("Exporté le $stamp · ${items.size} fiche(s)", margin, 96f, Paint(mutedPaint).apply {
                color = Color.LTGRAY
            })
            y = 140f
        }
        fun line(label: String, value: String, mono: Boolean = false) {
            if (value.isBlank()) return
            if (y > height - 76f) startPage()
            canvas!!.drawText(label.uppercase(Locale.FRANCE), margin + 14f, y, labelPaint)
            val paint = if (mono) monoPaint else valuePaint
            val maxChars = if (mono) 72 else 78
            val chunks = value.chunked(maxChars)
            chunks.forEachIndexed { index, part ->
                if (y > height - 76f) startPage()
                canvas!!.drawText(part, margin + 175f, y, paint)
                if (index < chunks.lastIndex) y += 14f
            }
            y += 21f
        }

        startPage()
        if (items.isEmpty()) line("Information", "Aucune clé enregistrée")
        items.forEachIndexed { index, item ->
            if (y > height - 180f) startPage()
            canvas!!.drawRoundRect(margin, y - 18f, width - margin, y + 13f, 7f, 7f, gold)
            canvas!!.drawText("${index + 1}. ${item.appName.ifBlank { "Application sans nom" }}", margin + 12f, y + 3f,
                Paint(titlePaint).apply { color = Color.WHITE; textSize = 12f })
            y += 35f
            line("Package", item.packageName)
            line("Fichier keystore", item.keystoreFileName)
            line("Alias", item.keyAlias, true)
            line("Mot de passe coffre", if (includePasswords) item.storePassword else if (item.storePassword.isNotEmpty()) "••••••••" else "")
            line("Mot de passe clé", if (includePasswords) item.keyPassword else if (item.keyPassword.isNotEmpty()) "••••••••" else "")
            line("Algorithme", item.keyAlgorithm)
            line("Validité", item.validity)
            line("Empreinte SHA-1", item.sha1, true)
            line("Empreinte SHA-256", item.sha256, true)
            line("Notes", item.notes)
            y += 16f
        }
        page?.let { p ->
            p.canvas.drawText("CONFIDENTIEL · MonCoffre · $stamp", margin, height - 24f, mutedPaint)
            p.canvas.drawText("Page $pageNo", width - margin - 35f, height - 24f, mutedPaint)
            doc.finishPage(p)
        }
        try { doc.writeTo(out) } finally { doc.close() }
    }
}
