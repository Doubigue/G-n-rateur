# HTML → MP4 (Kotlin natif)

Version Android native (Kotlin) de l'appli Flutter `html2mp4`, prête pour **APK Studio** :
dépose le ZIP de ce dossier, type **Kotlin / Java**. (`settings.gradle`, module `app/`, wrapper Gradle 8.9 inclus.)

## Ce qui est repris de la version Flutter
Horloge virtuelle (`assets/shim.js`, identique), capture image par image, durée automatique,
sons de la page mixés par FFmpeg, musique de fond + volume, fondu, MP4 / GIF, formats
Portrait / Paysage / Carré, SD / HD / Full HD, vitesses Rapide / Équilibré / Qualité, projet .zip
(HTML + sons), « Mes vidéos », aperçu (boucle, ±1 s, vitesse), partage, enregistrement galerie,
écran maintenu allumé, vibration finale.

## Nouveau : notification de progression dans la barre d'état
- Service au premier plan (`ExportService`) + notification : titre « Phase · 42 % », barre de
  progression, détail (images/s, temps restant), chronomètre, miniature de la dernière image,
  bouton **Annuler**.
- Fin : notification « Vidéo prête ✓ » (toucher = aperçu, bouton **Partager**).
- Android 13+ : la permission notifications est demandée au premier export.
- Bouton Retour pendant l'export : l'appli passe en arrière-plan sans arrêter la conversion.
- La capture a besoin que la page soit à l'écran : si l'appli est en arrière-plan, la capture se met
  **en pause** (notification « En pause ») et reprend au retour ; l'encodage FFmpeg, lui, continue
  en arrière-plan.

## Notes
- FFmpeg : `com.antonkarpenko:ffmpeg-kit-full-gpl:2.2.1` (isolé dans `Ffmpeg.kt`).
- APK volumineux (FFmpeg complet, 3 architectures) : retirer des ABI dans `app/build.gradle` pour alléger.
