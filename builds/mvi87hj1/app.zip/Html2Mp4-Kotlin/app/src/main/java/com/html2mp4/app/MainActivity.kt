package com.html2mp4.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.Gravity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.WebView
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.widget.doAfterTextChanged
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.color.MaterialColors
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.slider.Slider
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlin.math.floor
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private val scope = MainScope()
    private val uiHandler = Handler(Looper.getMainLooper())

    private lateinit var web: WebView
    private lateinit var host: PageHost
    private lateinit var exporter: Exporter

    // ------------------------------------------------------------- réglages
    private var fmt = Fmt.PORTRAIT
    private var res = Res.HD
    private var quality = Quality.FAST
    private var out = Out.MP4
    private var autoDur = true
    private var fade = false
    private var musicVol = 1.0
    private var audioPath: String? = null
    private var audioName: String? = null
    private var projectName: String? = null
    private var lastOut: String? = null

    // ----------------------------------------------------------------- état
    private var busy = false
    private var exporting = false
    private var started = false // activité visible : le WebView peint
    private var status = ""
    private var askedPerms = false
    private var updating = false
    private var startMs = 0L
    private var exportJob: Job? = null
    private var tickJob: Job? = null
    private var htmlDebounce: Runnable? = null
    private var sampleHtml = ""

    // ---------------------------------------------------------------- vues
    private lateinit var previewBox: FrameLayout
    private lateinit var wEdit: EditText
    private lateinit var hEdit: EditText
    private lateinit var fpsEdit: EditText
    private lateinit var durEdit: EditText
    private lateinit var htmlEdit: EditText
    private lateinit var hintText: TextView
    private lateinit var autoSwitch: MaterialSwitch
    private lateinit var fadeSwitch: MaterialSwitch
    private lateinit var projectChip: Chip
    private lateinit var audioBtn: MaterialButton
    private lateinit var audioClear: MaterialButton
    private lateinit var volRow: LinearLayout
    private lateinit var volLabel: TextView
    private lateinit var detectBtn: MaterialButton
    private lateinit var htmlBtn: MaterialButton
    private lateinit var zipBtn: MaterialButton
    private lateinit var idleBar: LinearLayout
    private lateinit var busyBar: LinearLayout
    private lateinit var progressCard: LinearLayout
    private lateinit var statusIdle: TextView
    private lateinit var statusBusy: TextView
    private lateinit var convertBtn: MaterialButton
    private lateinit var afterRow: LinearLayout
    private lateinit var thumbView: ImageView
    private lateinit var phaseText: TextView
    private lateinit var detailText: TextView
    private lateinit var elapsedText: TextView
    private lateinit var pctText: TextView
    private lateinit var bar: LinearProgressIndicator
    private lateinit var cancelBtn: MaterialButton
    private val chips = ArrayList<Chip>()

    // ------------------------------------------------------------ sélecteurs
    private val pickHtml = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) onHtmlPicked(uri)
    }
    private val pickZip = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) onZipPicked(uri)
    }
    private val pickAudio = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) onAudioPicked(uri)
    }
    private val permReq = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        startExport()
    }

    // =================================================================== cycle de vie

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        host = PageHost(this, web)
        exporter = Exporter(this, host, { started }, { p -> onProg(p) })
        sampleHtml = assets.open("sample.html").bufferedReader(Charsets.UTF_8).use { it.readText() }
        host.inlineHtml = sampleHtml

        setContentView(buildUi())
        htmlEdit.setText(sampleHtml)
        applySize()
        refresh()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (exporting) {
                    moveTaskToBack(true) // l'export continue (notification de progression)
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        scope.launch {
            try {
                host.load()
            } catch (_: Exception) {
            }
        }
        handleIntent(intent)
    }

    override fun onStart() {
        super.onStart()
        started = true
        web.onResume()
        web.resumeTimers()
    }

    override fun onStop() {
        started = false
        super.onStop()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onDestroy() {
        if (exporting) exporter.cancel()
        ExportControl.onCancel = null
        ProgressNotifier.end(this)
        ExportService.stop(this)
        scope.cancel()
        (web.parent as? ViewGroup)?.removeView(web)
        web.destroy()
        super.onDestroy()
    }

    private fun handleIntent(i: Intent?) {
        val p = i?.getStringExtra(ProgressNotifier.EXTRA_OPEN_PATH) ?: return
        i.removeExtra(ProgressNotifier.EXTRA_OPEN_PATH)
        if (File(p).exists()) {
            lastOut = p
            refresh()
            openPreview(p)
        }
        ProgressNotifier.cancelDone(this)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(0, 1, 0, "Mes vidéos").setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == 1) {
            if (!busy) startActivity(Intent(this, LibraryActivity::class.java))
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    // ========================================================================= UI

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun lp(w: Int = ViewGroup.LayoutParams.MATCH_PARENT, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT) =
        LinearLayout.LayoutParams(w, h)

    private fun title(t: String): TextView {
        val v = TextView(this)
        v.text = t
        v.setTextAppearance(com.google.android.material.R.style.TextAppearance_Material3_TitleSmall)
        v.setPadding(0, dp(16), 0, dp(6))
        return v
    }

    private fun small(t: String): TextView {
        val v = TextView(this)
        v.text = t
        v.setTextAppearance(com.google.android.material.R.style.TextAppearance_Material3_BodySmall)
        return v
    }

    private fun button(t: String, outlined: Boolean = true, onClick: () -> Unit): MaterialButton {
        val b = if (outlined) MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle)
        else MaterialButton(this)
        b.text = t
        b.setAllCaps(false)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun <T> chipRow(items: List<Pair<String, T>>, current: () -> T, onPick: (T) -> Unit): ChipGroup {
        val g = ChipGroup(this)
        g.isSingleSelection = true
        g.isSelectionRequired = true
        for ((label, v) in items) {
            val c = Chip(this)
            c.id = View.generateViewId()
            c.text = label
            c.isCheckable = true
            c.isChecked = (v == current())
            c.setOnCheckedChangeListener { _, checked ->
                if (checked && !updating) onPick(v)
            }
            g.addView(c)
            chips.add(c)
        }
        return g
    }

    private fun numField(hint: String, text: String, weight: Float = 1f, decimal: Boolean = false): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setText(text)
        e.inputType = if (decimal) android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        else android.text.InputType.TYPE_CLASS_NUMBER
        e.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weight).also {
            it.marginEnd = dp(8)
        }
        return e
    }

    private fun buildUi(): View {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }

        val toolbar = MaterialToolbar(this)
        setSupportActionBar(toolbar)
        supportActionBar?.title = "HTML animé → MP4"
        root.addView(toolbar, lp(h = dp(56)))

        val scroll = ScrollView(this)
        scroll.isFillViewport = false
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(16), dp(16), dp(16))
        scroll.addView(col, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // --- aperçu de la page (le WebView a la taille réelle de la vidéo, affiché réduit)
        previewBox = FrameLayout(this)
        previewBox.setBackgroundColor(0x1F000000)
        previewBox.addView(web, FrameLayout.LayoutParams(720, 1280))
        previewBox.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> fitPreview() }
        col.addView(previewBox, lp(h = dp(240)))

        // --- format et résolution
        col.addView(title("Format"))
        col.addView(chipRow(
            listOf("Portrait 9:16" to Fmt.PORTRAIT, "Paysage 16:9" to Fmt.LANDSCAPE, "Carré 1:1" to Fmt.SQUARE),
            { fmt }) { fmt = it; applySize() })
        col.addView(chipRow(
            listOf("SD 480p" to Res.SD, "HD 720p" to Res.HD, "Full HD 1080p" to Res.FHD),
            { res }) { res = it; applySize() })

        val sizeRow = LinearLayout(this)
        sizeRow.orientation = LinearLayout.HORIZONTAL
        wEdit = numField("Largeur", "720")
        hEdit = numField("Hauteur", "1280")
        fpsEdit = numField("FPS", "30")
        sizeRow.addView(wEdit); sizeRow.addView(hEdit); sizeRow.addView(fpsEdit)
        col.addView(sizeRow, lp())
        wEdit.doAfterTextChanged { onSizeEdited() }
        hEdit.doAfterTextChanged { onSizeEdited() }

        // --- sortie
        col.addView(title("Sortie"))
        col.addView(chipRow(listOf("Vidéo MP4" to Out.MP4, "GIF animé" to Out.GIF), { out }) {
            out = it; refresh()
        })

        // --- vitesse
        col.addView(title("Vitesse de conversion"))
        col.addView(chipRow(QPS.entries.map { it.value.label to it.key }, { quality }) {
            quality = it; refresh()
        })
        hintText = small(QPS.getValue(quality).hint)
        col.addView(hintText, lp())

        // --- durée
        autoSwitch = MaterialSwitch(this)
        autoSwitch.text = "Durée automatique"
        autoSwitch.isChecked = true
        autoSwitch.setOnCheckedChangeListener { _, c -> if (!updating) { autoDur = c; refresh() } }
        col.addView(autoSwitch, lp())
        col.addView(small("Calculée d'après les animations et les sons du HTML"), lp())
        val durRow = LinearLayout(this)
        durRow.orientation = LinearLayout.HORIZONTAL
        durRow.gravity = Gravity.CENTER_VERTICAL
        durEdit = numField("Durée (s)", "4", 1f, true)
        detectBtn = button("Détecter") { detectDuration() }
        durRow.addView(durEdit); durRow.addView(detectBtn)
        col.addView(durRow, lp())

        fadeSwitch = MaterialSwitch(this)
        fadeSwitch.text = "Fondu d'entrée et de sortie"
        fadeSwitch.setOnCheckedChangeListener { _, c -> if (!updating) fade = c }
        col.addView(fadeSwitch, lp())
        col.addView(small("Vidéo MP4 uniquement (0,4 s)"), lp())

        // --- source HTML
        col.addView(title("Source"))
        projectChip = Chip(this)
        projectChip.isCloseIconVisible = true
        projectChip.setOnCloseIconClickListener { if (!busy) closeProject() }
        col.addView(projectChip, lp(ViewGroup.LayoutParams.WRAP_CONTENT))
        htmlEdit = EditText(this)
        htmlEdit.hint = "Code HTML (animé uniquement)"
        htmlEdit.minLines = 5
        htmlEdit.maxLines = 8
        htmlEdit.gravity = Gravity.TOP or Gravity.START
        htmlEdit.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or
            android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        htmlEdit.doAfterTextChanged { onHtmlEdited() }
        col.addView(htmlEdit, lp())

        val srcRow = LinearLayout(this)
        srcRow.orientation = LinearLayout.HORIZONTAL
        htmlBtn = button("Ouvrir un .html") { pickHtml.launch(arrayOf("*/*")) }
        zipBtn = button("Projet .zip (HTML + sons)") { pickZip.launch(arrayOf("*/*")) }
        srcRow.addView(htmlBtn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).also { it.marginEnd = dp(8) })
        srcRow.addView(zipBtn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        col.addView(srcRow, lp().also { it.topMargin = dp(8) })
        col.addView(
            small("Zippez le HTML avec son dossier de sons : les sons que la page joue sont détectés et mixés automatiquement."),
            lp()
        )

        // --- musique
        val musicRow = LinearLayout(this)
        musicRow.orientation = LinearLayout.HORIZONTAL
        audioBtn = button("Ajouter une musique de fond") { pickAudio.launch(arrayOf("*/*")) }
        audioBtn.maxLines = 1
        audioClear = button("✕") { audioPath = null; audioName = null; refresh() }
        musicRow.addView(audioBtn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        musicRow.addView(audioClear, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        col.addView(musicRow, lp().also { it.topMargin = dp(12) })

        volRow = LinearLayout(this)
        volRow.orientation = LinearLayout.HORIZONTAL
        volRow.gravity = Gravity.CENTER_VERTICAL
        val slider = Slider(this)
        slider.valueFrom = 0f
        slider.valueTo = 100f
        slider.stepSize = 5f
        slider.value = 100f
        volLabel = TextView(this)
        volLabel.text = "100 %"
        slider.addOnChangeListener { _, v, _ ->
            musicVol = v / 100.0
            volLabel.text = "${v.roundToInt()} %"
        }
        volRow.addView(small("Volume"), LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        volRow.addView(slider, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        volRow.addView(volLabel, LinearLayout.LayoutParams(dp(48), ViewGroup.LayoutParams.WRAP_CONTENT))
        col.addView(volRow, lp())

        // --- bandeau du bas : bouton / progression
        val dock = LinearLayout(this)
        dock.orientation = LinearLayout.VERTICAL
        dock.elevation = dp(10).toFloat()
        dock.setBackgroundColor(MaterialColors.getColor(this, com.google.android.material.R.attr.colorSurface, Color.WHITE))
        dock.setPadding(dp(16), dp(10), dp(16), dp(10))

        idleBar = LinearLayout(this)
        idleBar.orientation = LinearLayout.VERTICAL
        statusIdle = TextView(this)
        statusIdle.maxLines = 3
        idleBar.addView(statusIdle, lp())
        convertBtn = button("Convertir et enregistrer", outlined = false) { onConvert() }
        idleBar.addView(convertBtn, lp())
        afterRow = LinearLayout(this)
        afterRow.orientation = LinearLayout.HORIZONTAL
        afterRow.gravity = Gravity.CENTER_HORIZONTAL
        afterRow.addView(button("Aperçu") { lastOut?.let { openPreview(it) } })
        afterRow.addView(button("Partager") { lastOut?.let { Sharing.share(this, it) } })
        idleBar.addView(afterRow, lp())
        dock.addView(idleBar, lp())

        busyBar = LinearLayout(this)
        busyBar.orientation = LinearLayout.VERTICAL
        val busyProgress = LinearProgressIndicator(this)
        busyProgress.isIndeterminate = true
        busyBar.addView(busyProgress, lp())
        statusBusy = TextView(this)
        statusBusy.setPadding(0, dp(8), 0, 0)
        busyBar.addView(statusBusy, lp())
        dock.addView(busyBar, lp())

        progressCard = LinearLayout(this)
        progressCard.orientation = LinearLayout.VERTICAL
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        thumbView = ImageView(this)
        thumbView.scaleType = ImageView.ScaleType.CENTER_CROP
        thumbView.visibility = View.GONE
        top.addView(thumbView, LinearLayout.LayoutParams(dp(56), dp(56)).also { it.marginEnd = dp(12) })
        val texts = LinearLayout(this)
        texts.orientation = LinearLayout.VERTICAL
        phaseText = TextView(this)
        phaseText.setTextAppearance(com.google.android.material.R.style.TextAppearance_Material3_TitleSmall)
        detailText = small("")
        detailText.maxLines = 2
        elapsedText = small("")
        texts.addView(phaseText); texts.addView(detailText); texts.addView(elapsedText)
        top.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        pctText = TextView(this)
        pctText.setTextAppearance(com.google.android.material.R.style.TextAppearance_Material3_HeadlineMedium)
        top.addView(pctText)
        progressCard.addView(top, lp())
        bar = LinearProgressIndicator(this)
        bar.max = 1000
        bar.trackThickness = dp(10)
        progressCard.addView(bar, lp().also { it.topMargin = dp(10) })
        cancelBtn = button("Annuler", outlined = false) { cancelExport() }
        progressCard.addView(cancelBtn, lp(ViewGroup.LayoutParams.WRAP_CONTENT).also { it.gravity = Gravity.END })
        dock.addView(progressCard, lp())

        root.addView(dock, lp())
        return root
    }

    /** Affiche le WebView (taille réelle de la vidéo) réduit pour tenir dans le cadre d'aperçu. */
    private fun fitPreview() {
        val bw = previewBox.width.toFloat()
        val bh = previewBox.height.toFloat()
        if (bw <= 0 || bh <= 0) return
        val ww = host.viewW.toFloat()
        val wh = host.viewH.toFloat()
        val s = minOf(bw / ww, bh / wh)
        web.pivotX = 0f
        web.pivotY = 0f
        web.scaleX = s
        web.scaleY = s
        web.translationX = (bw - ww * s) / 2f
        web.translationY = (bh - wh * s) / 2f
    }

    private fun wv(): Int = (wEdit.text.toString().toIntOrNull() ?: 720).coerceIn(64, 4096)
    private fun hv(): Int = (hEdit.text.toString().toIntOrNull() ?: 1280).coerceIn(64, 4096)

    private fun onSizeEdited() {
        if (updating || busy) return
        host.resizeView(wv(), hv())
        previewBox.post { fitPreview() }
    }

    /** Applique format (portrait / paysage / carré) + résolution aux champs. */
    private fun applySize() {
        val s = when (res) { Res.SD -> 480; Res.HD -> 720; Res.FHD -> 1080 }
        val long = ((s * 16 / 9.0) / 2).roundToInt() * 2
        val (w, h) = when (fmt) {
            Fmt.PORTRAIT -> s to long
            Fmt.LANDSCAPE -> long to s
            Fmt.SQUARE -> s to s
        }
        updating = true
        wEdit.setText(w.toString())
        hEdit.setText(h.toString())
        updating = false
        host.resizeView(w, h)
        previewBox.post { fitPreview() }
    }

    /** Synchronise tous les widgets avec l'état. */
    private fun refresh() {
        updating = true
        idleBar.visibility = if (!busy) View.VISIBLE else View.GONE
        busyBar.visibility = if (busy && !exporting) View.VISIBLE else View.GONE
        progressCard.visibility = if (exporting) View.VISIBLE else View.GONE
        statusIdle.text = status
        statusIdle.visibility = if (status.isEmpty()) View.GONE else View.VISIBLE
        statusBusy.text = if (status.isEmpty()) "Patiente…" else status
        afterRow.visibility = if (lastOut != null) View.VISIBLE else View.GONE

        for (v in listOf<View>(wEdit, hEdit, fpsEdit, htmlEdit, htmlBtn, zipBtn, audioBtn, audioClear, detectBtn,
            autoSwitch, projectChip)) v.isEnabled = !busy
        chips.forEach { it.isEnabled = !busy }
        durEdit.isEnabled = !busy && !autoDur
        fadeSwitch.isEnabled = !busy && out == Out.MP4
        fadeSwitch.isChecked = fade && out == Out.MP4
        autoSwitch.isChecked = autoDur

        val project = projectName
        projectChip.visibility = if (project != null) View.VISIBLE else View.GONE
        if (project != null) projectChip.text = "Projet : $project"
        htmlEdit.visibility = if (project == null) View.VISIBLE else View.GONE
        audioBtn.text = audioName ?: "Ajouter une musique de fond"
        audioClear.visibility = if (audioPath != null) View.VISIBLE else View.GONE
        volRow.visibility = if (audioPath != null && out == Out.MP4) View.VISIBLE else View.GONE
        convertBtn.text = if (out == Out.GIF) "Convertir en GIF" else "Convertir et enregistrer"
        hintText.text = QPS.getValue(quality).hint
        updating = false
    }

    private fun snack(msg: String) {
        Snackbar.make(findViewById<View>(android.R.id.content), msg, Snackbar.LENGTH_LONG).show()
    }

    private fun openPreview(path: String) {
        startActivity(Intent(this, PreviewActivity::class.java).putExtra("path", path))
    }

    // =================================================================== sources

    private fun displayName(uri: Uri): String {
        var name: String? = null
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) name = c.getString(0)
            }
        } catch (_: Exception) {
        }
        return name ?: (uri.lastPathSegment ?: "fichier")
    }

    /** Exécute une action en affichant l'erreur à l'écran au lieu de l'avaler en silence. */
    private fun safe(block: suspend () -> Unit) {
        scope.launch {
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                busy = false
                exporting = false
                status = "Erreur : ${e.message ?: e.javaClass.simpleName}"
                refresh()
            }
        }
    }

    private fun setBusy(b: Boolean, msg: String = "") {
        busy = b
        status = msg
        refresh()
    }

    /** Essaie une nouvelle source ; la garde seulement si elle est animée. */
    private suspend fun tryOpen(dir: File?, entry: String?, name: String?, html: String?): Boolean {
        val prevDir = host.projectDir
        val prevEntry = host.entryPath
        val prevName = projectName
        val prevHtml = host.inlineHtml
        host.projectDir = dir
        host.entryPath = entry ?: PageHost.INLINE
        projectName = name
        if (html != null) host.inlineHtml = html
        try {
            host.load()
            if (host.isAnimated()) return true
        } catch (_: Exception) {
        }
        host.projectDir = prevDir
        host.entryPath = prevEntry
        projectName = prevName
        host.inlineHtml = prevHtml
        try {
            host.load()
        } catch (_: Exception) {
        }
        return false
    }

    private fun onHtmlPicked(uri: Uri) = safe {
        val name = displayName(uri).lowercase()
        if (!name.endsWith(".html") && !name.endsWith(".htm")) {
            snack("Choisis un fichier .html")
            return@safe
        }
        setBusy(true, "Vérification de l'animation…")
        val text = withContext(Dispatchers.IO) {
            contentResolver.openInputStream(uri)!!.bufferedReader(Charsets.UTF_8).use { it.readText() }
        }
        val old = host.projectDir
        val ok = tryOpen(null, null, null, text)
        if (ok) {
            old?.deleteRecursively()
            updating = true
            htmlEdit.setText(text)
            updating = false
        }
        setBusy(false, if (ok) "HTML animé accepté ✓" else "")
        if (!ok) snack("Refusé : ce HTML ne contient aucune animation.")
    }

    private fun onZipPicked(uri: Uri) = safe {
        val name = displayName(uri)
        if (!name.lowercase().endsWith(".zip")) {
            snack("Choisis un fichier .zip")
            return@safe
        }
        setBusy(true, "Extraction du projet…")
        val root = File(cacheDir, "project_" + System.currentTimeMillis())
        try {
            val htmls = withContext(Dispatchers.IO) {
                contentResolver.openInputStream(uri)!!.use { Project.extract(it, root) }
            }
            if (htmls.isEmpty()) throw IllegalStateException("aucun fichier .html dans le zip")
            val entry = Project.pickEntry(htmls)
            status = "Vérification de l'animation…"
            refresh()
            val old = host.projectDir
            val ok = tryOpen(root, entry, "$name → $entry", null)
            if (ok) {
                if (old != null && old != root) old.deleteRecursively()
                setBusy(false, "Projet animé accepté ✓")
            } else {
                root.deleteRecursively()
                setBusy(false, "")
                snack("Refusé : ce projet ne contient aucune animation.")
            }
        } catch (e: Exception) {
            root.deleteRecursively()
            throw e
        }
    }

    private fun closeProject() = safe {
        val old = host.projectDir
        host.projectDir = null
        host.entryPath = PageHost.INLINE
        projectName = null
        host.inlineHtml = htmlEdit.text.toString()
        refresh()
        try {
            host.load()
        } catch (_: Exception) {
        }
        old?.deleteRecursively()
    }

    private fun onAudioPicked(uri: Uri) = safe {
        val name = displayName(uri)
        val safeName = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val dst = File(cacheDir, "music_$safeName")
        setBusy(true, "Import de la musique…")
        withContext(Dispatchers.IO) {
            contentResolver.openInputStream(uri)!!.use { i -> FileOutputStream(dst).use { i.copyTo(it) } }
        }
        audioPath?.let { if (it != dst.path) File(it).delete() }
        audioPath = dst.path
        audioName = name
        setBusy(false, "")
    }

    private fun onHtmlEdited() {
        if (updating || busy || projectName != null) return
        htmlDebounce?.let { uiHandler.removeCallbacks(it) }
        val r = Runnable {
            if (busy || projectName != null) return@Runnable
            host.inlineHtml = htmlEdit.text.toString()
            scope.launch {
                try {
                    host.load()
                } catch (_: Exception) {
                }
            }
        }
        htmlDebounce = r
        uiHandler.postDelayed(r, 900)
    }

    // ================================================================ durée auto

    private fun detectDuration() = safe {
        setBusy(true, "Calcul de la durée…")
        if (projectName == null) host.inlineHtml = htmlEdit.text.toString()
        host.resizeView(wv(), hv())
        host.awaitSize()
        host.load()
        val d = exporter.measureDuration()
        host.load() // repart d'un état propre
        durEdit.setText(d.toString())
        setBusy(false, "Durée détectée : ${d}s")
    }

    // ==================================================================== export

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun onConvert() {
        if (busy) return
        val need = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) {
            need.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (Build.VERSION.SDK_INT <= 28 && !granted(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            need.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        if (need.isNotEmpty() && !askedPerms) {
            askedPerms = true
            permReq.launch(need.toTypedArray())
        } else {
            startExport()
        }
    }

    private fun cancelExport() {
        if (!exporting) return
        cancelBtn.isEnabled = false
        exporter.cancel()
    }

    private fun onProg(p: Prog) {
        val t = p.thumb
        if (t != null) {
            thumbView.setImageBitmap(t)
            thumbView.visibility = View.VISIBLE
        }
        val pct = floor(p.value * 100).toInt()
        phaseText.text = p.phase
        detailText.text = p.detail
        pctText.text = "$pct %"
        bar.isIndeterminate = false
        bar.setProgressCompat((p.value * 1000).toInt(), true)
        ProgressNotifier.update(
            this,
            ProgressNotifier.State(pct, p.phase, p.detail, t, p.paused, p.value <= 0.0 && !p.paused)
        )
    }

    private fun startExport() {
        if (busy) return
        val w = wv()
        val h = hv()
        val fps = (fpsEdit.text.toString().toIntOrNull() ?: 30).coerceIn(1, 60)
        val dur = (durEdit.text.toString().replace(',', '.').toDoubleOrNull() ?: 4.0).coerceIn(0.1, 600.0)
        if (projectName == null) host.inlineHtml = htmlEdit.text.toString()
        val st = ExportSettings(
            w, h, fps, dur, autoDur, quality, out, fade && out == Out.MP4, audioPath, musicVol
        )

        busy = true
        exporting = true
        lastOut = null
        status = ""
        startMs = System.currentTimeMillis()
        cancelBtn.isEnabled = true
        thumbView.visibility = View.GONE
        bar.isIndeterminate = true
        phaseText.text = "Préparation"
        detailText.text = "Chargement de la page…"
        pctText.text = "0 %"
        refresh()

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        ProgressNotifier.begin(this)
        ExportControl.onCancel = { uiHandler.post { cancelExport() } }
        ExportService.start(this)
        ProgressNotifier.update(this, ProgressNotifier.State(0, "Préparation", "Chargement de la page…"), true)

        if (!ProgressNotifier.canNotify(this)) {
            Snackbar.make(
                findViewById<View>(android.R.id.content),
                "Active les notifications pour suivre la progression dans la barre d'état.",
                Snackbar.LENGTH_LONG
            ).setAction("Réglages") {
                val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                i.putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                startActivity(i)
            }.show()
        }

        tickJob?.cancel()
        tickJob = scope.launch {
            while (isActive) {
                elapsedText.text = "écoulé ${fmtSec((System.currentTimeMillis() - startMs) / 1000)}"
                delay(1000)
            }
        }

        exportJob = scope.launch {
            var doneTitle: String
            var doneText: String
            var donePath: String? = null
            var ok = false
            try {
                val r = exporter.run(st)
                ok = true
                lastOut = r.path
                donePath = r.path
                val kind = if (r.gif) "GIF" else "Vidéo"
                status = r.galleryNote ?: ("$kind terminé en ${fmtSec(r.seconds)} ✓" +
                    (if (r.sounds == 0) "" else " (${r.sounds} son(s) mixé(s))"))
                doneTitle = "$kind prête ✓"
                doneText = "Terminé en ${fmtSec(r.seconds)} · touche pour ouvrir l'aperçu"
                buzz()
            } catch (e: ExportCancelled) {
                status = "Conversion annulée."
                doneTitle = "Conversion annulée"
                doneText = "Aucune vidéo n'a été créée."
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                val msg = e.message ?: e.javaClass.simpleName
                status = "Erreur : $msg"
                doneTitle = "Échec de la conversion"
                doneText = msg
            } finally {
                tickJob?.cancel()
                ProgressNotifier.end(this@MainActivity)
                ExportService.stop(this@MainActivity)
                ExportControl.onCancel = null
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                busy = false
                exporting = false
            }
            refresh()
            if (started) {
                ProgressNotifier.cancelDone(this@MainActivity)
                if (ok && donePath != null) openPreview(donePath)
            } else {
                // appli en arrière-plan : la notification finale remplace la progression
                ProgressNotifier.postDone(this@MainActivity, doneTitle, doneText, donePath, ok)
            }
        }
    }

    private fun buzz() {
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                val vm = getSystemService(VibratorManager::class.java)
                vm?.defaultVibrator?.vibrate(VibrationEffect.createOneShot(60, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                val v = getSystemService(VIBRATOR_SERVICE) as Vibrator
                if (Build.VERSION.SDK_INT >= 26) {
                    v.vibrate(VibrationEffect.createOneShot(60, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    v.vibrate(60)
                }
            }
        } catch (_: Exception) {
        }
    }
}
