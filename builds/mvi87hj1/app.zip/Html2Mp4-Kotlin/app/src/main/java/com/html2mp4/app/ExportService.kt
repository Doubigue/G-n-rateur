package com.html2mp4.app

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/**
 * Service au premier plan : garde le processus vivant pendant l'export (encodage FFmpeg compris)
 * et porte la notification de progression de la barre d'état.
 */
class ExportService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL) {
            ExportControl.onCancel?.invoke()
            if (!ProgressNotifier.active) stopSelf()
            return START_NOT_STICKY
        }
        ProgressNotifier.ensureChannels(this)
        try {
            ServiceCompat.startForeground(
                this,
                ProgressNotifier.ID_PROGRESS,
                ProgressNotifier.build(this, ProgressNotifier.last),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } catch (_: Exception) {
            // Pas de service au premier plan : l'export continue, sans notification persistante.
            stopSelf()
        }
        return START_NOT_STICKY
    }

    /** L'appli a été fermée depuis les applis récentes : la page web disparaît, on arrête tout. */
    override fun onTaskRemoved(rootIntent: Intent?) {
        ExportControl.onCancel?.invoke()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        super.onTaskRemoved(rootIntent)
    }

    companion object {
        const val ACTION_START = "com.html2mp4.app.EXPORT_START"
        const val ACTION_CANCEL = "com.html2mp4.app.EXPORT_CANCEL"

        fun start(ctx: Context) {
            val i = Intent(ctx, ExportService::class.java).setAction(ACTION_START)
            ContextCompat.startForegroundService(ctx, i)
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, ExportService::class.java))
        }
    }
}
