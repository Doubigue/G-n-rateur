package com.html2mp4.app

import android.graphics.Bitmap
import java.util.Locale

enum class Fmt { PORTRAIT, LANDSCAPE, SQUARE }
enum class Res { SD, HD, FHD }
enum class Quality { FAST, BALANCED, BEST }
enum class Out { MP4, GIF }

/** Réglages de vitesse / qualité (identiques à la version Flutter). */
class QP(
    val label: String,
    val hint: String,
    val png: Boolean,   // true = captures PNG (lent, sans perte)
    val jpg: Int,       // qualité JPEG
    val rafs: Int,      // images réelles attendues après chaque seek
    val preset: String, // preset x264
    val crf: Int        // x264 : plus petit = meilleure qualité
)

val QPS: Map<Quality, QP> = linkedMapOf(
    Quality.FAST to QP("Rapide", "Captures JPEG + encodage express (conseillé)", false, 85, 1, "ultrafast", 24),
    Quality.BALANCED to QP("Équilibré", "JPEG haute qualité, bon compromis", false, 93, 2, "veryfast", 21),
    Quality.BEST to QP("Qualité", "PNG sans perte, nettement plus lent", true, 100, 2, "medium", 17)
)

/** Un son joué par la page, avec son instant de départ (ms) dans la vidéo. */
class Snd(
    val file: String,
    val t: Double,
    val off: Double,
    val vol: Double,
    val rate: Double,
    val loop: Boolean,
    var dur: Double? // secondes
)

/** État affiché dans le bandeau de progression et dans la notification. */
class Prog(
    val value: Double,          // 0..1
    val phase: String,
    val detail: String,
    val thumb: Bitmap? = null,  // nouvelle miniature (null = inchangée)
    val paused: Boolean = false
)

/** Réglages d'un export. */
class ExportSettings(
    val w: Int,
    val h: Int,
    val fps: Int,
    val durSec: Double,
    val autoDur: Boolean,
    val quality: Quality,
    val out: Out,
    val fade: Boolean,
    val musicPath: String?,
    val musicVol: Double
)

class ExportResult(
    val path: String,
    val gif: Boolean,
    val sounds: Int,
    val galleryNote: String?,
    val seconds: Long,
    val durationSec: Double
)

/** Levée quand l'utilisateur appuie sur « Annuler ». */
class ExportCancelled : Exception("Conversion annulée")

fun n3(v: Double): String = String.format(Locale.US, "%.3f", v)

fun fmtSec(s: Long): String {
    if (s < 60) return "${s}s"
    return "${s / 60}min ${(s % 60).toString().padStart(2, '0')}s"
}
