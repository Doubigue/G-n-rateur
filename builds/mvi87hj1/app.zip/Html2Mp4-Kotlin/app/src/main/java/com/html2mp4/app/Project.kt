package com.html2mp4.app

import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.zip.ZipInputStream

/** Projet = .zip contenant le HTML et ses dossiers (sons, images, scripts…). */
object Project {
    /** Extrait le zip dans [root] et renvoie la liste des fichiers .html trouvés. */
    fun extract(input: InputStream, root: File): List<String> {
        root.deleteRecursively()
        root.mkdirs()
        val rootPath = root.canonicalPath + File.separator
        val htmls = ArrayList<String>()
        ZipInputStream(input).use { z ->
            var e = z.nextEntry
            while (e != null) {
                val name = e.name.replace('\\', '/')
                if (!e.isDirectory && !name.contains("..") && !name.startsWith("__MACOSX") &&
                    !name.startsWith("/")
                ) {
                    val out = File(root, name).canonicalFile
                    if (out.path.startsWith(rootPath)) {
                        out.parentFile?.mkdirs()
                        FileOutputStream(out).use { z.copyTo(it) }
                        val low = name.lowercase()
                        if (low.endsWith(".html") || low.endsWith(".htm")) htmls.add(name)
                    }
                }
                z.closeEntry()
                e = z.nextEntry
            }
        }
        return htmls
    }

    /** Entrée = index.html le moins profond, sinon le premier .html. */
    fun pickEntry(htmls: List<String>): String =
        htmls.sortedWith(
            compareBy<String>({ it.count { c -> c == '/' } },
                { if (it.lowercase().endsWith("index.html")) 0 else 1 })
        ).first()
}
