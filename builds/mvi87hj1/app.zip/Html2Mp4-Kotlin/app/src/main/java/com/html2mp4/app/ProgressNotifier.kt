package com.html2mp4.app

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

/** Rappelle l'export en cours depuis le bouton « Annuler » de la notification. */
object ExportControl {
    @Volatile
    var onCancel: (() -> Unit)? = null
}

/**
 * Notification de progression dans la barre d'état :
 * pourcentage, phase, détail (images/s, temps restant), chronomètre, miniature de la dernière
 * image capturée et bouton Annuler. Mise à jour limitée à ~2 fois par seconde.
 */
object ProgressNotifier {
    const val CH_PROGRESS = "export_progress"
    const val CH_DONE = "export_done"
    const val ID_PROGRESS = 4101
    const val ID_DONE = 4102
    const val EXTRA_OPEN_PATH = "open_path"

    class State(
        val pct: Int = 0,
        val phase: String = "Préparation",
        val detail: String = "",
        val thumb: Bitmap? = null,
        val paused: Boolean = false,
        val indeterminate: Boolean = true
    )

    @Volatile
    var active = false
        private set

    @Volatile
    var last = State()
        private set

    private var startMs = 0L
    private var lastPct = -1
    private var lastPost = 0L

    fun ensureChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CH_PROGRESS) == null) {
            val ch = NotificationChannel(CH_PROGRESS, "Progression de la conversion", NotificationManager.IMPORTANCE_LOW)
            ch.description = "Avancement de la conversion HTML → MP4"
            ch.setShowBadge(false)
            nm.createNotificationChannel(ch)
        }
        if (nm.getNotificationChannel(CH_DONE) == null) {
            val ch = NotificationChannel(CH_DONE, "Conversion terminée", NotificationManager.IMPORTANCE_DEFAULT)
            ch.description = "Prévient quand la vidéo est prête"
            nm.createNotificationChannel(ch)
        }
    }

    fun canNotify(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return false
        return NotificationManagerCompat.from(ctx).areNotificationsEnabled()
    }

    fun begin(ctx: Context) {
        ensureChannels(ctx)
        active = true
        startMs = System.currentTimeMillis()
        last = State()
        lastPct = -1
        lastPost = 0L
        NotificationManagerCompat.from(ctx).cancel(ID_DONE)
    }

    /** Fin de l'export : plus aucune mise à jour de progression, on retire la notification. */
    fun end(ctx: Context) {
        active = false
        NotificationManagerCompat.from(ctx).cancel(ID_PROGRESS)
    }

    private fun openApp(ctx: Context): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(ctx, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    fun build(ctx: Context, s: State): Notification {
        val cancel = Intent(ctx, ExportService::class.java).setAction(ExportService.ACTION_CANCEL)
        val cancelPi = PendingIntent.getService(
            ctx, 1, cancel, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val title = "${s.phase} · ${s.pct} %"
        val b = NotificationCompat.Builder(ctx, CH_PROGRESS)
            .setSmallIcon(R.drawable.ic_stat_export)
            .setContentTitle(title)
            .setContentText(s.detail)
            .setStyle(NotificationCompat.BigTextStyle().bigText(s.detail))
            .setProgress(100, s.pct.coerceIn(0, 100), s.indeterminate)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setColor(0xFF3F51B5.toInt())
            .setWhen(startMs)
            .setUsesChronometer(true)
            .setContentIntent(openApp(ctx))
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .addAction(0, "Annuler", cancelPi)
        if (s.thumb != null) b.setLargeIcon(s.thumb)
        return b.build()
    }

    /** Met à jour la notification de progression (limité pour ne pas saturer le système). */
    fun update(ctx: Context, s: State, force: Boolean = false) {
        val keepThumb = s.thumb ?: last.thumb
        val st = State(s.pct, s.phase, s.detail, keepThumb, s.paused, s.indeterminate)
        last = st
        if (!active || !canNotify(ctx)) return
        val now = System.currentTimeMillis()
        val due = force || (st.pct != lastPct && now - lastPost >= 400) || now - lastPost >= 1000
        if (!due) return
        lastPct = st.pct
        lastPost = now
        try {
            NotificationManagerCompat.from(ctx).notify(ID_PROGRESS, build(ctx, st))
        } catch (_: SecurityException) {
        }
    }

    /** Notification finale (succès, annulation ou erreur), qui reste dans le panneau. */
    fun postDone(ctx: Context, title: String, text: String, path: String?, success: Boolean) {
        if (!canNotify(ctx)) return
        ensureChannels(ctx)
        val open = Intent(ctx, MainActivity::class.java)
        open.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        if (path != null) open.putExtra(EXTRA_OPEN_PATH, path)
        val openPi = PendingIntent.getActivity(
            ctx, 2, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = NotificationCompat.Builder(ctx, CH_DONE)
            .setSmallIcon(R.drawable.ic_stat_export)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setColor(0xFF3F51B5.toInt())
            .setCategory(if (success) NotificationCompat.CATEGORY_STATUS else NotificationCompat.CATEGORY_ERROR)
            .setContentIntent(openPi)
        if (success && path != null) {
            try {
                val sharePi = PendingIntent.getActivity(
                    ctx, 3, Sharing.chooser(ctx, path), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
                b.addAction(0, "Partager", sharePi)
            } catch (_: Exception) {
            }
            last.thumb?.let { b.setLargeIcon(it) }
        }
        try {
            NotificationManagerCompat.from(ctx).notify(ID_DONE, b.build())
        } catch (_: SecurityException) {
        }
    }

    fun cancelDone(ctx: Context) {
        NotificationManagerCompat.from(ctx).cancel(ID_DONE)
    }
}
