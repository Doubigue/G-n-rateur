package com.html2mp4.app

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.PopupMenu
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** « Mes vidéos » : tous les exports (MP4 / GIF) conservés dans l'appli. */
class LibraryActivity : AppCompatActivity() {
    private var files: List<File> = emptyList()
    private lateinit var list: ListView
    private lateinit var empty: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }
        val tb = MaterialToolbar(this)
        setSupportActionBar(tb)
        supportActionBar?.title = "Mes vidéos"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        root.addView(tb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)))

        list = ListView(this)
        list.adapter = adapter
        list.setOnItemClickListener { _, _, i, _ ->
            startActivity(Intent(this, PreviewActivity::class.java).putExtra("path", files[i].path))
        }
        empty = TextView(this)
        empty.text = "Aucun export pour l'instant. Convertis une animation, elle apparaîtra ici."
        empty.gravity = Gravity.CENTER
        empty.setPadding(dp(24), dp(24), dp(24), dp(24))
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(empty, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        reload()
    }

    private fun reload() {
        val dir = File(filesDir, "exports")
        files = (dir.listFiles() ?: emptyArray())
            .filter { val n = it.name.lowercase(); n.endsWith(".mp4") || n.endsWith(".gif") }
            .sortedByDescending { it.lastModified() }
        adapter.notifyDataSetChanged()
        list.visibility = if (files.isEmpty()) View.GONE else View.VISIBLE
        empty.visibility = if (files.isEmpty()) View.VISIBLE else View.GONE
        invalidateOptionsMenu()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        if (files.isNotEmpty()) menu.add(0, 1, 0, "Tout supprimer").setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            finish()
            return true
        }
        if (item.itemId == 1) {
            MaterialAlertDialogBuilder(this)
                .setTitle("Tout supprimer ?")
                .setMessage("Les fichiers déjà enregistrés dans la galerie ne sont pas touchés.")
                .setNegativeButton("Annuler", null)
                .setPositiveButton("Supprimer") { _, _ ->
                    files.forEach { it.delete() }
                    reload()
                }.show()
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun size(b: Long): String =
        if (b < 1024 * 1024) "${b / 1024} Ko" else String.format(Locale.US, "%.1f Mo", b / 1024.0 / 1024.0)

    private val adapter = object : BaseAdapter() {
        override fun getCount() = files.size
        override fun getItem(position: Int) = files[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val f = files[position]
            val row = LinearLayout(this@LibraryActivity)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(16), dp(10), dp(8), dp(10))
            val col = LinearLayout(this@LibraryActivity)
            col.orientation = LinearLayout.VERTICAL
            val t = TextView(this@LibraryActivity)
            t.text = f.name
            t.maxLines = 1
            t.ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
            t.textSize = 16f
            val s = TextView(this@LibraryActivity)
            s.text = size(f.length()) + " · " + SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE).format(Date(f.lastModified()))
            s.textSize = 12f
            col.addView(t)
            col.addView(s)
            row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val more = MaterialButton(this@LibraryActivity, null, com.google.android.material.R.attr.borderlessButtonStyle)
            more.text = "⋮"
            more.setOnClickListener { v ->
                val pm = PopupMenu(this@LibraryActivity, v)
                pm.menu.add(0, 1, 0, "Partager")
                pm.menu.add(0, 2, 1, "Supprimer")
                pm.setOnMenuItemClickListener { m ->
                    if (m.itemId == 1) Sharing.share(this@LibraryActivity, f.path) else {
                        f.delete()
                        reload()
                    }
                    true
                }
                pm.show()
            }
            row.addView(more)
            return row
        }
    }
}
