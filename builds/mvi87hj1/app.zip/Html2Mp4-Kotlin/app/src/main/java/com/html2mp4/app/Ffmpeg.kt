package com.html2mp4.app

// Seul fichier qui connaît FFmpegKit : si le paquet de la bibliothèque change,
// il suffit de modifier ces trois imports.
import com.antonkarpenko.ffmpegkit.FFmpegKit
import com.antonkarpenko.ffmpegkit.FFprobeKit
import com.antonkarpenko.ffmpegkit.ReturnCode
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

object Ffmpeg {
    class Result(val ok: Boolean, val cancelled: Boolean, val logTail: String)

    /** Lance FFmpeg ; [onTimeMs] reçoit le temps encodé (ms) sur un thread d'arrière-plan. */
    suspend fun run(args: List<String>, onTimeMs: (Double) -> Unit): Result =
        suspendCancellableCoroutine { cont ->
            FFmpegKit.executeWithArgumentsAsync(
                args.toTypedArray(),
                { session ->
                    val rc = session.returnCode
                    val logs = session.allLogsAsString ?: ""
                    if (cont.isActive) {
                        cont.resume(
                            Result(ReturnCode.isSuccess(rc), ReturnCode.isCancel(rc), logs.takeLast(300))
                        )
                    }
                },
                null,
                { st -> onTimeMs(st.time.toDouble()) }
            )
            cont.invokeOnCancellation { FFmpegKit.cancel() }
        }

    fun cancel() {
        try {
            FFmpegKit.cancel()
        } catch (_: Throwable) {
        }
    }

    /** Durée d'un fichier audio (secondes) via FFprobe, null si inconnue. */
    fun duration(path: String): Double? = try {
        FFprobeKit.getMediaInformation(path).mediaInformation?.duration?.toDoubleOrNull()
    } catch (_: Throwable) {
        null
    }
}
