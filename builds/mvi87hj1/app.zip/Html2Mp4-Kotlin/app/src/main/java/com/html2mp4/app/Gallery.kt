package com.html2mp4.app

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileInputStream

object Gallery {
    /** Copie l'export dans la galerie. Renvoie null si tout va bien, sinon un message. */
    fun save(ctx: Context, src: File, gif: Boolean): String? {
        return try {
            val mime = if (gif) "image/gif" else "video/mp4"
            val folder = if (gif) Environment.DIRECTORY_PICTURES else Environment.DIRECTORY_MOVIES
            if (Build.VERSION.SDK_INT >= 29) {
                val cv = ContentValues()
                cv.put(MediaStore.MediaColumns.DISPLAY_NAME, src.name)
                cv.put(MediaStore.MediaColumns.MIME_TYPE, mime)
                cv.put(MediaStore.MediaColumns.RELATIVE_PATH, "$folder/HTML2MP4")
                cv.put(MediaStore.MediaColumns.IS_PENDING, 1)
                val coll = if (gif) MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                val uri = ctx.contentResolver.insert(coll, cv) ?: return "Galerie indisponible, utilise Partager."
                val out = ctx.contentResolver.openOutputStream(uri)
                    ?: return "Galerie indisponible, utilise Partager."
                out.use { o -> FileInputStream(src).use { it.copyTo(o) } }
                val done = ContentValues()
                done.put(MediaStore.MediaColumns.IS_PENDING, 0)
                ctx.contentResolver.update(uri, done, null, null)
            } else {
                val ok = ContextCompat.checkSelfPermission(
                    ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE
                ) == PackageManager.PERMISSION_GRANTED
                if (!ok) return "Autorisation de stockage refusée, utilise Partager."
                val dir = File(Environment.getExternalStoragePublicDirectory(folder), "HTML2MP4")
                dir.mkdirs()
                val dst = File(dir, src.name)
                src.copyTo(dst, true)
                MediaScannerConnection.scanFile(ctx, arrayOf(dst.path), arrayOf(mime), null)
            }
            null
        } catch (e: Exception) {
            "Galerie indisponible (${e.message}), utilise Partager."
        }
    }
}

object Sharing {
    fun uriFor(ctx: Context, path: String) =
        FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", File(path))

    fun mimeOf(path: String): String =
        if (path.lowercase().endsWith(".gif")) "image/gif" else "video/mp4"

    /** Intent de partage prêt à être lancé (déjà enveloppé dans un sélecteur). */
    fun chooser(ctx: Context, path: String): Intent {
        val uri = uriFor(ctx, path)
        val send = Intent(Intent.ACTION_SEND)
        send.type = mimeOf(path)
        send.putExtra(Intent.EXTRA_STREAM, uri)
        send.clipData = android.content.ClipData.newRawUri("", uri)
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        return Intent.createChooser(send, "Partager")
    }

    fun share(ctx: Context, path: String) {
        ctx.startActivity(chooser(ctx, path))
    }
}
