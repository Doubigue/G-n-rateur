package com.html2mp4.app

import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.drawable.AnimatedImageDrawable
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.SeekBar
import android.widget.TextView
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import java.io.File

/** Aperçu : lecteur vidéo (lecture, barre, ±1 s, boucle, vitesse) pour un MP4, image animée pour un GIF. */
class PreviewActivity : AppCompatActivity() {
    private lateinit var path: String
    private var video: VideoView? = null
    private var player: MediaPlayer? = null
    private var loop = true
    private var speed = 1f
    private var seeking = false
    private val h = Handler(Looper.getMainLooper())
    private lateinit var seek: SeekBar
    private lateinit var posText: TextView
    private lateinit var durText: TextView
    private lateinit var playBtn: MaterialButton
    private lateinit var loopBtn: MaterialButton

    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()

    private val tick = object : Runnable {
        override fun run() {
            val v = video
            if (v != null && player != null) {
                if (!seeking) {
                    seek.progress = v.currentPosition
                }
                posText.text = fmt(v.currentPosition)
                playBtn.text = if (v.isPlaying) "⏸" else "▶"
            }
            h.postDelayed(this, 100)
        }
    }

    private fun fmt(ms: Int): String =
        String.format("%02d:%02d.%d", ms / 60000, ms / 1000 % 60, ms % 1000 / 100)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        path = intent.getStringExtra("path") ?: run { finish(); return }
        val gif = path.lowercase().endsWith(".gif")

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.BLACK)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }
        val tb = MaterialToolbar(this)
        tb.setBackgroundColor(Color.BLACK)
        tb.setTitleTextColor(Color.WHITE)
        setSupportActionBar(tb)
        supportActionBar?.title = if (gif) "Aperçu du GIF" else "Aperçu de la vidéo"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        root.addView(tb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56)))

        val stage = FrameLayout(this)
        root.addView(stage, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        if (gif) {
            val iv = ImageView(this)
            iv.scaleType = ImageView.ScaleType.FIT_CENTER
            stage.addView(iv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            try {
                if (Build.VERSION.SDK_INT >= 28) {
                    val d = ImageDecoder.decodeDrawable(ImageDecoder.createSource(File(path)))
                    iv.setImageDrawable(d)
                    (d as? AnimatedImageDrawable)?.start()
                } else {
                    iv.setImageBitmap(android.graphics.BitmapFactory.decodeFile(path))
                }
            } catch (_: Exception) {
            }
            setContentView(root)
            return
        }

        val v = VideoView(this)
        video = v
        stage.addView(v, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER))
        stage.setOnClickListener { toggle() }

        seek = SeekBar(this)
        root.addView(seek, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val times = LinearLayout(this)
        times.orientation = LinearLayout.HORIZONTAL
        times.setPadding(dp(16), 0, dp(16), 0)
        posText = TextView(this)
        posText.setTextColor(Color.WHITE)
        durText = TextView(this)
        durText.setTextColor(Color.WHITE)
        durText.gravity = Gravity.END
        times.addView(posText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        times.addView(durText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(times, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val ctl = LinearLayout(this)
        ctl.orientation = LinearLayout.HORIZONTAL
        ctl.gravity = Gravity.CENTER
        ctl.setPadding(0, dp(8), 0, dp(8))
        fun btn(t: String, onClick: () -> Unit): MaterialButton {
            val b = MaterialButton(this, null, com.google.android.material.R.attr.borderlessButtonStyle)
            b.text = t
            b.setAllCaps(false)
            b.setTextColor(Color.WHITE)
            b.setOnClickListener { onClick() }
            ctl.addView(b)
            return b
        }
        loopBtn = btn("🔁") {
            loop = !loop
            player?.isLooping = loop
            loopBtn.setTextColor(if (loop) Color.parseColor("#40C4FF") else Color.GRAY)
        }
        loopBtn.setTextColor(Color.parseColor("#40C4FF"))
        btn("−1 s") { step(-1000) }
        playBtn = btn("▶") { toggle() }
        playBtn.textSize = 24f
        btn("+1 s") { step(1000) }
        val speedBtn = btn("×1") {}
        speedBtn.setOnClickListener { anchor ->
            val pm = PopupMenu(this, anchor)
            val speeds = floatArrayOf(0.25f, 0.5f, 1f, 1.5f, 2f)
            speeds.forEachIndexed { i, s -> pm.menu.add(0, i, i, "×$s") }
            pm.setOnMenuItemClickListener { m ->
                speed = speeds[m.itemId]
                speedBtn.text = "×" + speed
                applySpeed()
                true
            }
            pm.show()
        }
        root.addView(ctl, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(root)

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) v.seekTo(p)
            }
            override fun onStartTrackingTouch(s: SeekBar?) { seeking = true }
            override fun onStopTrackingTouch(s: SeekBar?) { seeking = false }
        })
        v.setOnPreparedListener { mp ->
            player = mp
            mp.isLooping = loop
            seek.max = v.duration
            durText.text = fmt(v.duration)
            v.start()
        }
        v.setOnErrorListener { _, _, _ ->
            posText.text = "Lecture impossible"
            true
        }
        v.setVideoPath(path)
        h.post(tick)
    }

    private fun toggle() {
        val v = video ?: return
        if (v.isPlaying) v.pause() else {
            if (v.currentPosition >= v.duration - 50) v.seekTo(0)
            v.start()
        }
    }

    private fun step(ms: Int) {
        val v = video ?: return
        v.seekTo((v.currentPosition + ms).coerceIn(0, v.duration))
    }

    private fun applySpeed() {
        val mp = player ?: return
        val v = video ?: return
        if (Build.VERSION.SDK_INT < 23) return
        val was = v.isPlaying
        try {
            mp.playbackParams = PlaybackParams().setSpeed(speed)
            if (!was) v.pause()
        } catch (_: Exception) {
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(0, 1, 0, "Partager").setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            finish()
            return true
        }
        if (item.itemId == 1) {
            Sharing.share(this, path)
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        video?.stopPlayback()
        super.onDestroy()
    }
}
