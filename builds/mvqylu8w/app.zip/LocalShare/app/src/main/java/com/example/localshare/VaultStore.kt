package com.example.localshare

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import java.io.*
import java.nio.ByteBuffer
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec
import javax.crypto.KeyGenerator

/** Encrypted local vault. Files are encrypted with a random vault AES-256 key. */
object VaultStore {
    private const val PREF = "secure_vault"
    private const val SALT = "salt"
    private const val PIN_IV = "pin_iv"
    private const val PIN_KEY = "pin_wrapped_key"
    private const val BIO_IV = "bio_iv"
    private const val BIO_KEY = "bio_wrapped_key"
    private const val KS = "AndroidKeyStore"
    private const val ALIAS = "LocalShareVaultBiometric"
    private const val ITERATIONS = 120_000
    private const val GCM_BITS = 128
    private const val IV_BYTES = 12

    data class Item(val file: File, val name: String, val size: Long)

    private fun prefs(ctx: Context): SharedPreferences = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
    fun isConfigured(ctx: Context) = prefs(ctx).contains(PIN_KEY)
    fun hasBiometric(ctx: Context) = prefs(ctx).contains(BIO_KEY) && keyStore().containsAlias(ALIAS)

    private fun keyStore(): KeyStore = KeyStore.getInstance(KS).apply { load(null) }

    private fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.NO_WRAP)
    private fun unb64(s: String) = Base64.decode(s, Base64.NO_WRAP)

    private fun derivePin(pin: CharArray, salt: ByteArray): SecretKey {
        val spec = PBEKeySpec(pin, salt, ITERATIONS, 256)
        return try {
            val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
            SecretKeySpec(bytes, "AES")
        } finally { spec.clearPassword() }
    }

    private fun aesEncrypt(data: ByteArray, key: SecretKey): Pair<ByteArray, ByteArray> {
        val iv = ByteArray(IV_BYTES).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(GCM_BITS, iv))
        return cipher.doFinal(data) to iv
    }

    private fun aesDecrypt(data: ByteArray, key: SecretKey, iv: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(GCM_BITS, iv))
        return cipher.doFinal(data)
    }

    /** Creates the vault and returns the generated key. */
    fun create(ctx: Context, pin: CharArray): SecretKey {
        val vault = ByteArray(32).also { SecureRandom().nextBytes(it) }
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val pinKey = derivePin(pin, salt)
        val (wrapped, iv) = aesEncrypt(vault, pinKey)
        prefs(ctx).edit()
            .putString(SALT, b64(salt))
            .putString(PIN_IV, b64(iv))
            .putString(PIN_KEY, b64(wrapped))
            .apply()
        File(ctx.filesDir, "vault").mkdirs()
        return SecretKeySpec(vault, "AES")
    }

    fun unlockWithPin(ctx: Context, pin: CharArray): SecretKey? {
        return try {
            val p = prefs(ctx)
            val pinKey = derivePin(pin, unb64(p.getString(SALT, "")!!))
            SecretKeySpec(aesDecrypt(unb64(p.getString(PIN_KEY, "")!!), pinKey, unb64(p.getString(PIN_IV, "")!!)), "AES")
        } catch (_: Exception) { null }
    }

    fun enableBiometric(ctx: Context, vaultKey: SecretKey): Boolean {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.R) return false
        return try {
            val ks = keyStore()
            if (!ks.containsAlias(ALIAS)) {
                val kg = KeyGenerator.getInstance("AES", KS)
                kg.init(android.security.keystore.KeyGenParameterSpec.Builder(
                    ALIAS,
                    android.security.keystore.KeyProperties.PURPOSE_ENCRYPT or android.security.keystore.KeyProperties.PURPOSE_DECRYPT
                ).setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setUserAuthenticationRequired(true)
                    .setUserAuthenticationParameters(30, android.security.keystore.KeyProperties.AUTH_BIOMETRIC_STRONG)
                    .build())
                kg.generateKey()
            }
            val k = (ks.getKey(ALIAS, null) as SecretKey)
            val (wrapped, iv) = aesEncrypt(vaultKey.encoded, k)
            prefs(ctx).edit().putString(BIO_KEY, b64(wrapped)).putString(BIO_IV, b64(iv)).apply()
            true
        } catch (_: Exception) { false }
    }

    fun biometricCipher(ctx: Context): Cipher? {
        return try {
            val ks = keyStore()
            val key = ks.getKey(ALIAS, null) as SecretKey
            Cipher.getInstance("AES/GCM/NoPadding").apply {
                init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(GCM_BITS, unb64(prefs(ctx).getString(BIO_IV, "")!!)))
            }
        } catch (_: Exception) { null }
    }

    fun unlockWithBiometric(ctx: Context, cipher: Cipher): SecretKey? {
        return try {
            val wrapped = unb64(prefs(ctx).getString(BIO_KEY, "")!!)
            SecretKeySpec(cipher.doFinal(wrapped), "AES")
        } catch (_: Exception) { null }
    }

    fun vaultDir(ctx: Context) = File(ctx.filesDir, "vault").also { it.mkdirs() }

    fun importFile(ctx: Context, key: SecretKey, source: File): Item {
        val out = File(vaultDir(ctx), "${System.currentTimeMillis()}_${java.util.UUID.randomUUID()}.vlt")
        val iv = ByteArray(IV_BYTES).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(GCM_BITS, iv))
        DataOutputStream(BufferedOutputStream(FileOutputStream(out))).use { raw ->
            raw.write(iv)
            CipherOutputStream(raw, cipher).use { cos ->
                DataOutputStream(cos).use { data ->
                    val name = source.name.toByteArray(StandardCharsets.UTF_8)
                    data.writeInt(name.size)
                    data.write(name)
                    FileInputStream(source).use { it.copyTo(data, 64 * 1024) }
                }
            }
        }
        return Item(out, source.name, source.length())
    }

    fun list(ctx: Context, key: SecretKey): List<Item> = vaultDir(ctx).listFiles { f -> f.extension == "vlt" }
        ?.mapNotNull { file -> readMeta(file, key)?.let { Item(file, it.first, it.second) } }
        ?.sortedByDescending { it.file.lastModified() } ?: emptyList()

    private fun readMeta(file: File, key: SecretKey): Pair<String, Long>? {
        return try {
            DataInputStream(BufferedInputStream(FileInputStream(file))).use { raw ->
                val iv = ByteArray(IV_BYTES); raw.readFully(iv)
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(GCM_BITS, iv))
                CipherInputStream(raw, cipher).use { cis ->
                    DataInputStream(cis).use { data ->
                        val n = data.readInt()
                        if (n <= 0 || n > 1_000_000) return null
                        val bytes = ByteArray(n); data.readFully(bytes)
                        val name = String(bytes, StandardCharsets.UTF_8)
                        var size = 0L
                        val buf = ByteArray(64 * 1024)
                        while (true) { val r = data.read(buf); if (r < 0) break; size += r }
                        name to size
                    }
                }
            }
        } catch (_: Exception) { null }
    }

    fun exportTo(ctx: Context, key: SecretKey, item: Item, target: File): File {
        val dest = Storage.uniqueFile(target, item.name)
        DataInputStream(BufferedInputStream(FileInputStream(item.file))).use { raw ->
            val iv = ByteArray(IV_BYTES); raw.readFully(iv)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(GCM_BITS, iv))
            CipherInputStream(raw, cipher).use { cis ->
                DataInputStream(cis).use { data ->
                    val n = data.readInt(); data.skipBytes(n)
                    FileOutputStream(dest).use { out ->
                        val buf = ByteArray(64 * 1024)
                        while (true) { val r = data.read(buf); if (r < 0) break; out.write(buf, 0, r) }
                    }
                }
            }
        }
        return dest
    }

    fun delete(item: Item) { item.file.delete() }
}
