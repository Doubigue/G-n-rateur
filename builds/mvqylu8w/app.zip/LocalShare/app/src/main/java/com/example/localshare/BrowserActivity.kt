package com.example.localshare

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.EditText
import android.view.inputmethod.EditorInfo
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.launch
import java.io.File
import java.util.Calendar

/**
 * Explorateur de fichiers, avec filtre par jour.
 *  - MODE_REMOTE : « Ses fichiers » — parcourir le stockage de l'autre téléphone et télécharger.
 *  - MODE_LOCAL  : « Fichiers reçus » — le dossier LocalShare de ce téléphone.
 */
class BrowserActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_MODE = "mode"
        const val MODE_LOCAL = "local"
        const val MODE_REMOTE = "remote"
        const val EXTRA_QUERY = "query"
        const val EXTRA_CATEGORY = "category"
        const val EXTRA_PICK_FOR_SHARE = "pick_for_share"
    }

    private class Row(val name: String, val isDir: Boolean, val size: Long, val modified: Long, val path: String)

    private val p2p get() = app.p2p
    private val remoteFs get() = app.remoteFs

    private var remote = false
    private var day: Long? = null
    private val selected = LinkedHashSet<String>()
    private lateinit var localRoot: File
    private lateinit var localDir: File

    private lateinit var tvTitle: TextView
    private lateinit var tvPath: TextView
    private lateinit var tvState: TextView
    private lateinit var btnRetry: Button
    private lateinit var btnDownload: Button
    private lateinit var dayPick: Button
    private lateinit var adapter: RowAdapter<Row>
    private lateinit var gridAdapter: FileGridAdapter
    private lateinit var search: EditText
    private lateinit var btnView: Button
    private var gridMode = true
    private var query = ""
    private var category: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_browser)
        remote = intent.getStringExtra(EXTRA_MODE) == MODE_REMOTE

        tvTitle = findViewById(R.id.tvTitle)
        tvPath = findViewById(R.id.tvPath)
        tvState = findViewById(R.id.tvState)
        btnRetry = findViewById(R.id.btnRetry)
        btnDownload = findViewById(R.id.btnDownload)
        dayPick = findViewById(R.id.dayPick)
        search = findViewById(R.id.search)
        btnView = findViewById(R.id.btnView)
        query = intent.getStringExtra(EXTRA_QUERY).orEmpty()
        category = intent.getStringExtra(EXTRA_CATEGORY)
        search.setText(query)
        search.setOnEditorActionListener { _, _, _ -> render(); true }
        btnView.setOnClickListener { gridMode = !gridMode; updateLayout(); render() }

        localRoot = Storage.shareDir(this)
        localDir = localRoot
        tvTitle.text = if (remote) "Fichiers de ${p2p.state.value.connectedName}" else if (category != null) category else "Fichiers · ${Storage.FOLDER}"

        adapter = RowAdapter(
            bind = { h, r ->
                h.title.text = if (r.isDir) "📁 ${r.name}" else r.name
                h.sub.text = if (r.isDir) "Dossier" else "${Fmt.bytes(r.size)} · ${Fmt.date(r.modified)}"
            },
            onClick = { onRowClick(it) },
            onLongClick = { if (!remote && !it.isDir) confirmDelete(it) }
        )
        gridAdapter = FileGridAdapter { x -> onGridClick(x) }
        updateLayout()

        findViewById<Button>(R.id.dayAll).setOnClickListener { setDay(null) }
        findViewById<Button>(R.id.dayToday).setOnClickListener { setDay(Fmt.startOfDay(0)) }
        findViewById<Button>(R.id.dayYesterday).setOnClickListener { setDay(Fmt.startOfDay(-1)) }
        dayPick.setOnClickListener { pickDay() }
        btnRetry.setOnClickListener { remoteFs.requestAccess() }
        btnDownload.setOnClickListener {
            remoteFs.download(selected.toList())
            Toast.makeText(this, "Téléchargement demandé : ${selected.size} fichier(s) → ${Storage.FOLDER}", Toast.LENGTH_LONG).show()
            selected.clear()
            render()
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (remote) {
                    if (remoteFs.access == RemoteAccess.GRANTED && !remoteFs.atRoot) remoteFs.up() else finish()
                } else if (localDir != localRoot) {
                    localDir = localDir.parentFile ?: localRoot
                    render()
                } else finish()
            }
        })

        if (remote) {
            when (remoteFs.access) {
                RemoteAccess.GRANTED -> remoteFs.list(remoteFs.currentPath)
                RemoteAccess.REQUESTING -> {}
                else -> remoteFs.requestAccess()
            }
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { remoteFs.tick.collect { render() } }
                launch { app.transfers.tick.collect { if (!remote) render() } }
                launch { p2p.state.collect { if (remote && !it.isConnected) finish() } }
            }
        }
    }

    private fun updateLayout() {
        val list = findViewById<RecyclerView>(R.id.list)
        if (remote || !gridMode) {
            list.layoutManager = LinearLayoutManager(this)
            list.adapter = adapter
            btnView.text = "▦ Grille"
        } else {
            val cols = (resources.displayMetrics.widthPixels / resources.displayMetrics.density / 150f).toInt().coerceIn(2, 4)
            list.layoutManager = androidx.recyclerview.widget.GridLayoutManager(this, cols)
            list.adapter = gridAdapter
            btnView.text = "☷ Liste"
        }
    }

    // ---------------------------------------------------------------- filtre par jour
    private fun setDay(d: Long?) {
        day = d
        dayPick.text = if (d != null && d != Fmt.startOfDay(0) && d != Fmt.startOfDay(-1)) Fmt.day(d) else "Choisir un jour"
        render()
    }

    private fun pickDay() {
        val c = Calendar.getInstance().apply { if (day != null) timeInMillis = day!! }
        DatePickerDialog(this, { _, y, m, d ->
            val cal = Calendar.getInstance().apply {
                set(y, m, d, 0, 0, 0)
                set(Calendar.MILLISECOND, 0)
            }
            setDay(cal.timeInMillis)
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).apply {
            datePicker.maxDate = System.currentTimeMillis()
            setTitle("Afficher les fichiers de ce jour")
        }.show()
    }

    // ---------------------------------------------------------------- affichage
    private fun render() {
        val rows: List<Row>
        var state: String? = null
        var retry = false

        if (remote) {
            tvPath.text = Fmt.displayPath(remoteFs.currentPath)
            val who = p2p.state.value.connectedName
            when (remoteFs.access) {
                RemoteAccess.REQUESTING, RemoteAccess.NONE -> state = "En attente de l’autorisation de $who…"
                RemoteAccess.DENIED -> { state = "Accès refusé ou révoqué."; retry = true }
                RemoteAccess.GRANTED -> state = remoteFs.error
                    ?: if (remoteFs.loading && remoteFs.entries.isEmpty()) "Chargement…" else null
            }
            rows = if (remoteFs.access == RemoteAccess.GRANTED) {
                remoteFs.entries.map {
                    Row(it.name, it.isDir, it.size, it.modified, File(remoteFs.currentPath, it.name).path)
                }
            } else emptyList()
        } else {
            tvPath.text = Fmt.displayPath(localDir.path)
            val source = if (query.isBlank()) {
                (localDir.listFiles() ?: emptyArray()).asSequence()
            } else {
                localRoot.walkTopDown().asSequence().filter { it != localRoot }
            }
            rows = source
                .filter { !it.name.startsWith(".") && !it.name.endsWith(".part") }
                .filter { category == null || it.isDirectory || Storage.categoryFor(it.name) == category }
                .filter { query.isBlank() || it.name.contains(query, ignoreCase = true) }
                .sortedWith(compareBy({ !it.isDirectory }, { -it.lastModified() }))
                .map { Row(it.name, it.isDirectory, if (it.isDirectory) 0 else it.length(), it.lastModified(), it.path) }
                .toList()
        }

        val d = day
        val shown = if (d == null) rows else rows.filter { it.isDir || Fmt.sameDay(it.modified, d) }
        if (!remote && gridMode) {
            gridAdapter.submit(shown.map { FileGridAdapter.FileItem(File(it.path), it.isDir, it.name, it.size, it.modified) })
        } else {
            adapter.submit(shown)
        }

        if (state == null && shown.isEmpty()) state = if (d != null) "Aucun fichier ce jour-là." else "Dossier vide."
        tvState.text = state
        tvState.visibility = if (state != null) View.VISIBLE else View.GONE
        btnRetry.visibility = if (retry) View.VISIBLE else View.GONE

        btnDownload.visibility = if (remote && selected.isNotEmpty()) View.VISIBLE else View.GONE
        btnDownload.text = "Télécharger (${selected.size})"
    }

    private fun onGridClick(x: FileGridAdapter.FileItem) {
        if (x.isDir) { localDir = x.file; query = ""; search.setText(""); render() }
        else Storage.open(this, x.file)
    }

    private fun onRowClick(r: Row) {
        if (r.isDir) {
            selected.clear()
            if (remote) remoteFs.list(r.path) else { localDir = File(r.path); render() }
        } else if (remote) {
            if (!selected.add(r.path)) selected.remove(r.path)
            render()
        } else {
            Storage.open(this, File(r.path))
        }
    }

    private fun confirmDelete(r: Row) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Supprimer ce fichier ?")
            .setMessage(r.name)
            .setPositiveButton("Supprimer") { _, _ -> File(r.path).delete(); render() }
            .setNegativeButton("Annuler", null)
            .show()
    }
}
