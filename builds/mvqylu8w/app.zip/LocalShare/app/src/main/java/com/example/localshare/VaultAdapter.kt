package com.example.localshare

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView

class VaultAdapter(
    private val onOpen: (VaultStore.Item) -> Unit,
    private val onExport: (VaultStore.Item) -> Unit,
    private val onDelete: (VaultStore.Item) -> Unit
) : ListAdapter<VaultStore.Item, VaultAdapter.H>(DIFF) {
    class H(v: View): RecyclerView.ViewHolder(v) {
        val name: TextView = v.findViewById(R.id.vaultName)
        val meta: TextView = v.findViewById(R.id.vaultMeta)
        val open: Button = v.findViewById(R.id.vaultOpen)
        val export: Button = v.findViewById(R.id.vaultExport)
        val delete: Button = v.findViewById(R.id.vaultDelete)
    }
    override fun onCreateViewHolder(p: ViewGroup, t: Int) = H(LayoutInflater.from(p.context).inflate(R.layout.item_vault, p, false))
    override fun onBindViewHolder(h: H, pos: Int) {
        val x = getItem(pos)
        h.name.text = "🔒 ${x.name}"
        h.meta.text = Fmt.bytes(x.size)
        h.open.setOnClickListener { onOpen(x) }
        h.export.setOnClickListener { onExport(x) }
        h.delete.setOnClickListener { onDelete(x) }
    }
    companion object { val DIFF = object: DiffUtil.ItemCallback<VaultStore.Item>() {
        override fun areItemsTheSame(a: VaultStore.Item,b: VaultStore.Item)=a.file.absolutePath==b.file.absolutePath
        override fun areContentsTheSame(a: VaultStore.Item,b: VaultStore.Item)=a.name==b.name && a.size==b.size
    }}
}
