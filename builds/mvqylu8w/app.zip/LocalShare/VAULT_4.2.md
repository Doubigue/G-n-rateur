# Local Share 4.2 — Coffre-fort sécurisé

Cette version ajoute un véritable coffre-fort local chiffré :

- PIN obligatoire à la première configuration ;
- fichiers chiffrés avec AES-256-GCM dans le stockage privé de l'application ;
- noms de fichiers protégés dans les conteneurs chiffrés ;
- ouverture, export vers LocalShare et suppression ;
- biométrie optionnelle via Android BiometricPrompt lorsque l'appareil la prend en charge ;
- les fichiers du coffre ne sont pas parcourus par l'explorateur LocalShare normal ;
- verrouillage manuel ;
- export automatique dans le sous-dossier correspondant (Vidéo, Documents, Musique, Application, Autres).

Le coffre-fort est indépendant du dossier public `LocalShare` : un fichier exporté en sort du coffre et redevient visible dans l'explorateur normal.
