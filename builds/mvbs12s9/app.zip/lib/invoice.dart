import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'data.dart';
import 'entry.dart';
import 'notif.dart';
import 'settings.dart';

const _vert = PdfColor.fromInt(0xFF1B5E20);
const _vertClair = PdfColor.fromInt(0xFFF1F8E9);
const _or = PdfColor.fromInt(0xFFF9A825);
const _gris = PdfColor.fromInt(0xFF5F6B5F);

/// Enregistre un PDF dans « Téléchargements » du téléphone (partage classique ailleurs)
Future<void> telechargerPdf(BuildContext c, Uint8List bytes, String name) async {
  try {
    final r = await const MethodChannel('baobab/download').invokeMethod('save', {'name': name, 'mime': 'application/pdf', 'bytes': bytes});
    if (r == null) throw Exception('échec');
    Notif.info('Fichier téléchargé', '$name est dans Téléchargements');
    if (c.mounted) saved(c, 'Téléchargé ✔ Dossier Téléchargements : $name', false);
  } catch (_) {
    await Printing.sharePdf(bytes: bytes, filename: name);
  }
}

String _s(String t) => t.replaceAll('Œ', 'Oe').replaceAll('œ', 'oe').replaceAll('’', "'").replaceAll('\u202f', ' ').replaceAll('\u00a0', ' ');

class Invoice {
  /// Lignes de la facture à partir d'un enregistrement de vente
  static Map<String, dynamic> _lines(Map<String, dynamic> r) {
    final q = (r['q'] ?? 0) as num;
    final pu = (r['pu'] ?? 0) as num;
    String label, unit;
    num qty = q;
    if (r['k'] == 'ovente') {
      final gros = r['mode'] == 'gros';
      label = '${r['et'] ?? 'Oeufs'}${gros ? ' - paquet de ${r['ps'] ?? AppSettings.packSize} oeufs' : ' - a l\'unite'}';
      unit = gros ? 'paquet(s)' : 'oeuf(s)';
    } else {
      final a = animalOf(r['a']);
      final kg = (r['kg'] ?? 0) as num;
      if (r['a'] == 'poisson' && kg > 0) { qty = kg; unit = 'kg'; label = '${a.name} (${r['q']} piece(s))'; }
      else { unit = 'tete(s)'; label = a.name; }
    }
    final sub = qty * pu;
    final rabais = (r['r'] ?? 0) as num;
    return {'label': _s(label), 'unit': unit, 'qty': qty, 'pu': pu, 'sub': sub, 'rabais': rabais, 'total': (r['m'] as num?) ?? (sub - rabais)};
  }

  static Future<Uint8List> build(Map<String, dynamic> r) async {
    final l = _lines(r);
    final doc = pw.Document(title: 'Facture ${r['inv']}', author: AppSettings.farm);
    pw.MemoryImage? logo;
    try { logo = pw.MemoryImage((await rootBundle.load('assets/logo.png')).buffer.asUint8List()); } catch (_) {}
    final date = DateFormat('dd/MM/yyyy').format(DateTime.tryParse('${r['d']}') ?? DateTime.now());
    final client = _s(clientName(r));
    final f = moneyPdf;

    pw.Widget bloc(String titre, List<pw.Widget> children) => pw.Container(
          padding: const pw.EdgeInsets.all(14),
          decoration: pw.BoxDecoration(color: _vertClair, borderRadius: pw.BorderRadius.circular(10), border: pw.Border(left: pw.BorderSide(color: _or, width: 4))),
          child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
            pw.Text(titre, style: pw.TextStyle(fontSize: 9, color: _gris, fontWeight: pw.FontWeight.bold, letterSpacing: 1)),
            pw.SizedBox(height: 6), ...children,
          ]),
        );
    pw.Widget cell(String t, {bool bold = false, bool right = false, PdfColor? color, double size = 10.5}) => pw.Padding(
        padding: const pw.EdgeInsets.symmetric(horizontal: 10, vertical: 9),
        child: pw.Text(t, textAlign: right ? pw.TextAlign.right : pw.TextAlign.left, style: pw.TextStyle(fontSize: size, color: color ?? PdfColors.grey900, fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal)));
    pw.Widget ligne(String a, String b, {bool fort = false}) => pw.Padding(
        padding: const pw.EdgeInsets.symmetric(vertical: 3),
        child: pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [
          pw.Text(a, style: pw.TextStyle(fontSize: fort ? 13 : 10.5, color: fort ? PdfColors.white : _gris, fontWeight: fort ? pw.FontWeight.bold : pw.FontWeight.normal)),
          pw.Text(b, style: pw.TextStyle(fontSize: fort ? 15 : 10.5, color: fort ? PdfColor.fromInt(0xFFFFD54F) : PdfColors.grey900, fontWeight: pw.FontWeight.bold)),
        ]));

    doc.addPage(pw.Page(
      pageFormat: PdfPageFormat.a4,
      margin: pw.EdgeInsets.zero,
      build: (_) => pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
        // ----- bandeau d'en-tête -----
        pw.Container(
          color: _vert, padding: const pw.EdgeInsets.fromLTRB(36, 30, 36, 26),
          child: pw.Row(crossAxisAlignment: pw.CrossAxisAlignment.center, children: [
            if (logo != null) pw.Container(width: 62, height: 62, decoration: const pw.BoxDecoration(shape: pw.BoxShape.circle, color: PdfColors.white), padding: const pw.EdgeInsets.all(3), child: pw.Image(logo)),
            pw.SizedBox(width: 14),
            pw.Expanded(child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
              pw.Text(_s(AppSettings.farm), style: pw.TextStyle(fontSize: 22, color: PdfColors.white, fontWeight: pw.FontWeight.bold)),
              pw.SizedBox(height: 3),
              pw.Text('Elevage et produits de la ferme', style: const pw.TextStyle(fontSize: 10, color: PdfColor.fromInt(0xFFC8E6C9))),
            ])),
            pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.end, children: [
              pw.Text('FACTURE', style: pw.TextStyle(fontSize: 26, color: PdfColor.fromInt(0xFFFFD54F), fontWeight: pw.FontWeight.bold, letterSpacing: 3)),
              pw.Text('${r['inv'] ?? ''}', style: const pw.TextStyle(fontSize: 11, color: PdfColors.white)),
            ]),
          ]),
        ),
        pw.Container(height: 5, color: _or),
        pw.Padding(
          padding: const pw.EdgeInsets.fromLTRB(36, 28, 36, 0),
          child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
            // ----- client / détails -----
            pw.Row(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
              pw.Expanded(child: bloc('FACTURE A', [
                pw.Text(client.isEmpty ? 'Client comptant' : client, style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold)),
                if ('${r['cw'] ?? ''}'.isNotEmpty) pw.Text('WhatsApp : ${r['cw']}', style: const pw.TextStyle(fontSize: 10, color: _gris)),
                if ('${r['ce'] ?? ''}'.isNotEmpty) pw.Text('${r['ce']}', style: const pw.TextStyle(fontSize: 10, color: _gris)),
              ])),
              pw.SizedBox(width: 14),
              pw.Expanded(child: bloc('DETAILS', [
                pw.Text('N° ${r['inv'] ?? ''}', style: pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold)),
                pw.Text('Date : $date', style: const pw.TextStyle(fontSize: 10, color: _gris)),
                pw.Text('Devise : ${AppSettings.currency}', style: const pw.TextStyle(fontSize: 10, color: _gris)),
              ])),
            ]),
            pw.SizedBox(height: 26),
            // ----- tableau -----
            pw.ClipRRect(
              horizontalRadius: 10, verticalRadius: 10,
              child: pw.Table(
                columnWidths: {0: const pw.FlexColumnWidth(5), 1: const pw.FlexColumnWidth(2), 2: const pw.FlexColumnWidth(2.6), 3: const pw.FlexColumnWidth(2.8)},
                children: [
                  pw.TableRow(decoration: const pw.BoxDecoration(color: _vert), children: [
                    cell('DESIGNATION', bold: true, color: PdfColors.white, size: 9),
                    cell('QUANTITE', bold: true, color: PdfColors.white, size: 9, right: true),
                    cell('PRIX UNITAIRE', bold: true, color: PdfColors.white, size: 9, right: true),
                    cell('TOTAL', bold: true, color: PdfColors.white, size: 9, right: true),
                  ]),
                  pw.TableRow(decoration: const pw.BoxDecoration(color: _vertClair), children: [
                    cell('${l['label']}', bold: true),
                    cell('${NumberFormat.decimalPattern('fr').format(l['qty'])} ${l['unit']}'.replaceAll('\u202f', ' ').replaceAll('\u00a0', ' '), right: true),
                    cell(f(l['pu']), right: true),
                    cell(f(l['sub']), right: true, bold: true),
                  ]),
                ],
              ),
            ),
            pw.SizedBox(height: 22),
            // ----- totaux -----
            pw.Align(alignment: pw.Alignment.centerRight, child: pw.SizedBox(width: 240, child: pw.Column(children: [
              ligne('Sous-total', f(l['sub'])),
              if ((l['rabais'] as num) > 0) ligne('Rabais', '- ${f(l['rabais'])}'),
              pw.SizedBox(height: 8),
              pw.Container(
                padding: const pw.EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                decoration: pw.BoxDecoration(color: _vert, borderRadius: pw.BorderRadius.circular(10)),
                child: ligne('TOTAL A PAYER', f(l['total']), fort: true),
              ),
            ]))),
            if ('${r['n'] ?? ''}'.isNotEmpty) ...[pw.SizedBox(height: 18), pw.Text('Note : ${_s('${r['n']}')}', style: const pw.TextStyle(fontSize: 10, color: _gris))],
          ]),
        ),
        pw.Spacer(),
        // ----- pied de page -----
        pw.Center(child: pw.Text('Merci pour votre confiance !', style: pw.TextStyle(fontSize: 15, color: _vert, fontWeight: pw.FontWeight.bold, fontStyle: pw.FontStyle.italic))),
        pw.SizedBox(height: 4),
        pw.Center(child: pw.Text('Document genere par ${_s(AppSettings.farm)}', style: const pw.TextStyle(fontSize: 9, color: _gris))),
        pw.SizedBox(height: 18),
        pw.Container(height: 10, color: _vert),
      ]),
    ));
    return doc.save();
  }

  /// Après une vente (ou depuis la liste) : Télécharger • Partager (WhatsApp, e-mail…) • Imprimer
  static Future<void> offer(BuildContext c, Map<String, dynamic> r) async {
    var rec = r;
    if ('${rec['inv'] ?? ''}'.isEmpty) {
      final n = await Repo.nextInvoice();
      rec = {...rec, 'inv': n};
      if (rec['id'] != null) await Repo.update('records', rec['id'], {'inv': n});
    }
    if (!c.mounted) return;
    final nom = clientName(rec);
    final name = 'facture_${rec['inv']}.pdf';
    await showModalBottomSheet(
      context: c, showDragHandle: true, backgroundColor: Colors.transparent, isScrollControlled: true,
      builder: (d) => Container(
        margin: const EdgeInsets.all(12), padding: const EdgeInsets.fromLTRB(20, 8, 20, 20),
        decoration: BoxDecoration(color: Theme.of(d).colorScheme.surface, borderRadius: BorderRadius.circular(28)),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF1B5E20), Color(0xFF43A047)]), borderRadius: BorderRadius.circular(20)),
            child: Row(children: [
              const CircleAvatar(backgroundColor: Colors.white24, child: Icon(Icons.receipt_long, color: Colors.white)),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Facture ${rec['inv']}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 17)),
                Text(nom.isEmpty ? 'Client comptant' : nom, style: const TextStyle(color: Color(0xFFC8E6C9))),
              ])),
              Text(money((rec['m'] as num?) ?? 0), style: const TextStyle(color: Color(0xFFFFD54F), fontWeight: FontWeight.w800, fontSize: 16)),
            ]),
          ),
          const SizedBox(height: 14),
          FilledButton.icon(icon: const Icon(Icons.download), label: const Text('Télécharger la facture (PDF)'), onPressed: () async {
            final b = await build(rec);
            if (d.mounted) Navigator.pop(d);
            if (c.mounted) await telechargerPdf(c, b, name);
          }),
          const SizedBox(height: 8),
          FilledButton.tonalIcon(icon: const Icon(Icons.share), label: Text('Partager (WhatsApp, e-mail…)${'${rec['cw'] ?? ''}'.isNotEmpty ? '  ${rec['cw']}' : ''}'), onPressed: () async {
            final b = await build(rec);
            await Printing.sharePdf(bytes: b, filename: name, subject: 'Facture ${rec['inv']}', body: 'Bonjour $nom, voici votre facture ${rec['inv']}. Merci !');
          }),
          const SizedBox(height: 8),
          OutlinedButton.icon(icon: const Icon(Icons.print_outlined), label: const Text('Aperçu / Imprimer'), onPressed: () async {
            final b = await build(rec);
            await Printing.layoutPdf(onLayout: (_) async => b, name: name);
          }),
          TextButton(onPressed: () => Navigator.pop(d), child: const Text('Plus tard')),
        ]),
      ),
    );
  }
}
