import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/data/latest_all.dart' as tzd;
import 'package:timezone/timezone.dart' as tz;

class Animal {
  final String key, name, file; final Color color; final IconData icon;
  final bool poultry; final String? egg; // egg = « poule », « dinde »… (donne la signature « Œufs de … »)
  const Animal(this.key, this.name, this.file, this.color, this.icon, {this.poultry = false, this.egg});
  String get logo => 'assets/logos/$file';
  bool get eggs => egg != null;
  List<String> get kinds => [
        'achat', 'vente', 'mort', 'soin', 'vaccin', 'nourriture',
        if (poultry) 'eclosion', // le ramassage des œufs se fait dans le menu Œufs
        if (!poultry && key != 'poisson') 'naissance',
      ];
}

const animals = [
  Animal('chair', 'Poulet de chair', '01_poulet_de_chair.png', Color(0xFFE67E22), Icons.set_meal, poultry: true),
  Animal('pondeuse', 'Poule pondeuse', '02_poule_pondeuse.png', Color(0xFFF1C40F), Icons.egg, poultry: true, egg: 'poule'),
  Animal('dindon', 'Dindon', '03_dindon.png', Color(0xFF8E5A3C), Icons.pets, poultry: true, egg: 'dinde'),
  Animal('canard', 'Canard', '04_canard.png', Color(0xFF16A085), Icons.water, poultry: true, egg: 'canard'),
  Animal('oie', 'Oie', '05_oie.png', Color(0xFF7F8C8D), Icons.flutter_dash, poultry: true, egg: 'oie'),
  Animal('perdrix', 'Perdrix', '06_perdrix.png', Color(0xFFA0522D), Icons.nature, poultry: true, egg: 'perdrix'),
  Animal('porc', 'Porc', '07_porc.png', Color(0xFFE91E63), Icons.pets),
  Animal('boeuf', 'Bœuf', '08_boeuf.png', Color(0xFF5D4037), Icons.agriculture),
  Animal('lapin', 'Lapin', '09_lapin.png', Color(0xFF9C27B0), Icons.cruelty_free),
  Animal('cabri', 'Cabri', '10_cabri.png', Color(0xFF3F51B5), Icons.terrain),
  Animal('mouton', 'Mouton', '11_mouton.png', Color(0xFF607D8B), Icons.cloud),
  Animal('chevre', 'Chèvre', '12_chevre.png', Color(0xFF2E7D32), Icons.landscape),
  Animal('poisson', 'Poisson', '13_poisson.png', Color(0xFF0288D1), Icons.waves),
];
Animal animalOf(String k) => animals.firstWhere((a) => a.key == k);

const kindLabels = {
  'achat': 'Achat', 'vente': 'Vente', 'mort': 'Mort', 'soin': 'Piqûre / soin', 'vaccin': 'Programmer vaccin', 'nourriture': 'Nourriture',
  'eclosion': 'Éclosion', 'oeufs': 'Ramassage œufs', 'casses': 'Œufs cassés', 'naissance': 'Naissance',
  'ovente': 'Vente d\'œufs', 'oachat': 'Achat d\'œufs',
};
const expenseCats = ['Nourriture', 'Piqûres / vétérinaire', 'Loyer', 'Électricité', 'Eau', 'Salaires', 'Transport', 'Autres'];

class Repo {
  static final fs = FirebaseFirestore.instance;
  static late SharedPreferences p;
  static final records = ValueNotifier<List<Map<String, dynamic>>>([]);
  static final expenses = ValueNotifier<List<Map<String, dynamic>>>([]);
  static final employees = ValueNotifier<List<Map<String, dynamic>>>([]);
  static final pendingCount = ValueNotifier<int>(0);
  static final srv = {'records': <Map<String, dynamic>>[], 'expenses': <Map<String, dynamic>>[], 'employees': <Map<String, dynamic>>[]};
  static List<Map<String, dynamic>> pending = [];

  static Future<void> init() async {
    p = await SharedPreferences.getInstance();
    pending = (jsonDecode(p.getString('pending') ?? '[]') as List).cast<Map<String, dynamic>>();
    for (final c in srv.keys) {
      fs.collection(c).snapshots().listen((s) {
        srv[c] = s.docs.map((d) => {...d.data(), 'id': d.id}).toList();
        _merge();
      }, onError: (_) {});
    }
    _merge();
    Connectivity().onConnectivityChanged.listen((_) => flush());
  }

  /// Numéro de facture automatique : FAC-2026-0001, 0002…
  static Future<String> nextInvoice() async {
    final n = (p.getInt('inv_n') ?? 0) + 1;
    await p.setInt('inv_n', n);
    return 'FAC-${DateTime.now().year}-${n.toString().padLeft(4, '0')}';
  }

  static final _opt = <Map<String, dynamic>>[]; // enregistrements affichés tout de suite, avant la confirmation du serveur

  static void _merge() {
    for (final c in srv.keys) {
      _opt.removeWhere((o) => o['_c'] == c && srv[c]!.any((e) => e['ts'] == o['ts']));
      final loc = [...pending, ..._opt].where((e) => e['_c'] == c).map((e) => {...e, 'pending': true});
      final all = [...srv[c]!, ...loc]..sort((a, b) {
          final byDate = '${b['d']}'.compareTo('${a['d']}');
          return byDate != 0 ? byDate : '${b['ts']}'.compareTo('${a['ts']}'); // même jour : le plus récent en premier
        });
      ({'records': records, 'expenses': expenses, 'employees': employees}[c]!).value = all;
    }
    pendingCount.value = pending.length;
  }

  static Future<bool> online() async => !(await Connectivity().checkConnectivity()).contains(ConnectivityResult.none);

  static Future<void> add(String col, Map<String, dynamic> data) async {
    data['ts'] = DateTime.now().toIso8601String();
    if (FirebaseAuth.instance.currentUser != null) {
      _opt.add({...data, '_c': col});
      _merge(); // affichage immédiat
      fs.collection(col).add(Map.of(data)).catchError((_) { // Firestore met lui-même en file d'attente si pas de réseau
        _opt.removeWhere((o) => o['ts'] == data['ts']);
        pending.add({...data, '_c': col});
        p.setString('pending', jsonEncode(pending));
        _merge();
        return fs.collection(col).doc();
      });
    } else {
      pending.add({...data, '_c': col});
      await p.setString('pending', jsonEncode(pending));
      _merge();
    }
  }

  static Future<void> flush() async {
    if (pending.isEmpty || FirebaseAuth.instance.currentUser == null || !await online()) return;
    for (final e in [...pending]) {
      final c = e['_c'];
      fs.collection(c).add(Map.of(e)..remove('_c'));
      pending.remove(e);
    }
    await p.setString('pending', jsonEncode(pending));
    _merge();
  }

  static Future<void> update(String col, String id, Map<String, dynamic> d) => fs.collection(col).doc(id).update(d);

  static Future<void> remove(String col, String id) => fs.collection(col).doc(id).delete();

  static int stock(String a) {
    int s = 0;
    for (final r in records.value.where((r) => r['a'] == a)) {
      final q = (r['q'] ?? 0) as num;
      if (['achat', 'eclosion', 'naissance'].contains(r['k'])) s += q.toInt();
      if (['vente', 'mort'].contains(r['k'])) s -= q.toInt();
    }
    return s;
  }
  // Œufs en stock (unités) pour un type d'œuf (clé de l'animal), et paquets emballés
  static int eggs(String a) {
    int s = 0;
    for (final r in records.value.where((r) => r['a'] == a)) {
      final q = ((r['q'] ?? 0) as num).toInt(), u = ((r['u'] ?? q) as num).toInt();
      switch (r['k']) {
        case 'oeufs': s += q - ((r['br'] ?? 0) as num).toInt(); break;
        case 'casses': s -= q; break;
        case 'oachat': s += u; break;
        case 'ovente': s -= u; break;
      }
    }
    return s;
  }
  static int packs(String a) {
    int s = 0;
    for (final r in records.value.where((r) => r['a'] == a)) {
      final q = ((r['q'] ?? 0) as num).toInt();
      if (r['k'] == 'oeufs') s += ((r['pk'] ?? 0) as num).toInt();
      if (r['mode'] == 'gros') s += r['k'] == 'oachat' ? q : r['k'] == 'ovente' ? -q : 0;
    }
    return s;
  }
  static num sum(Iterable<Map<String, dynamic>> l, String f) => l.fold<num>(0, (s, e) => s + ((e[f] ?? 0) as num));
}

