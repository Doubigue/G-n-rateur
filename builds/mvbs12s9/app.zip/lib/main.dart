import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'admin.dart';
import 'data.dart';
import 'entry.dart';
import 'notif.dart';
import 'report.dart';
import 'settings.dart';

// Config Firebase (idéalement remplacez par `flutterfire configure` pour Android/iOS)
const fbOptions = FirebaseOptions(
  apiKey: 'AIzaSyBKBE87ba6InjfRuJfHiI0knEoo7FsoeS8',
  authDomain: 'ma-ferme-285f9.firebaseapp.com',
  projectId: 'ma-ferme-285f9',
  storageBucket: 'ma-ferme-285f9.firebasestorage.app',
  messagingSenderId: '843964352119',
  appId: '1:843964352119:web:0bd0ee77a8ae11e8e5a872',
);

// Config Android (valeurs de google-services.json, fournies en Dart car le générateur d'APK ignore le dossier android/)
const fbAndroid = FirebaseOptions(
  apiKey: 'AIzaSyBfdpIx0gp2iLp5b_lJL-NUtz1FsFzA_5M',
  appId: '1:843964352119:android:c8c898d169193b6fe5a872',
  messagingSenderId: '843964352119',
  projectId: 'ma-ferme-285f9',
  storageBucket: 'ma-ferme-285f9.firebasestorage.app',
);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: kIsWeb ? fbOptions : fbAndroid);
  await Repo.init();
  await Notif.init();
  runApp(const FermeApp());
}

String f(num n) => money(n);

/// Police Roboto (celle de WhatsApp sur Android), sans l'espacement large des lettres de Material 3
ThemeData _theme() {
  final base = ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF2E7D32)));
  TextStyle? w(TextStyle? s) => s?.copyWith(fontFamily: 'Roboto', letterSpacing: 0);
  final t = base.textTheme;
  return base.copyWith(
    textTheme: TextTheme(
      displayLarge: w(t.displayLarge), displayMedium: w(t.displayMedium), displaySmall: w(t.displaySmall),
      headlineLarge: w(t.headlineLarge), headlineMedium: w(t.headlineMedium), headlineSmall: w(t.headlineSmall),
      titleLarge: w(t.titleLarge), titleMedium: w(t.titleMedium), titleSmall: w(t.titleSmall),
      bodyLarge: w(t.bodyLarge), bodyMedium: w(t.bodyMedium), bodySmall: w(t.bodySmall),
      labelLarge: w(t.labelLarge), labelMedium: w(t.labelMedium), labelSmall: w(t.labelSmall),
    ),
    cardTheme: CardThemeData(elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22))),
  );
}

/// Image d'en-tête : déposez assets/couverture.jpg (ou .png / .webp) – elle est trouvée toute seule
class CoverImage extends StatelessWidget {
  const CoverImage({super.key});
  static Future<String?>? _path;
  static Future<String?> find() => _path ??= (() async {
        try {
          final man = await AssetManifest.loadFromAssetBundle(rootBundle);
          return man.listAssets().firstWhere((a) => a.toLowerCase().startsWith('assets/couverture.'));
        } catch (_) { return null; }
      })();
  @override
  Widget build(BuildContext c) => FutureBuilder<String?>(
        future: find(),
        builder: (_, s) => s.data == null
            ? Align(alignment: Alignment.centerRight, child: Padding(padding: const EdgeInsets.fromLTRB(20, 80, 20, 50), child: Icon(Icons.agriculture, size: 90, color: Colors.white.withOpacity(.25))))
            : Stack(fit: StackFit.expand, children: [
                Image.asset(s.data!, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const SizedBox()),
                const DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.black26, Colors.transparent, Colors.black54]))),
              ]),
      );
}

class FermeApp extends StatelessWidget {
  const FermeApp({super.key});
  @override
  Widget build(BuildContext c) => MaterialApp(
        title: 'Ma Ferme', debugShowCheckedModeBanner: false, scaffoldMessengerKey: rootMessenger,
        theme: _theme(),
        home: const Shell(),
      );
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int i = 0;
  @override
  Widget build(BuildContext c) => ValueListenableBuilder<int>(
        valueListenable: AppSettings.changed, // devise / nom : tout se met à jour
        builder: (_, __, ___) => Scaffold(
          body: IndexedStack(index: i, children: [
            Home(), ReportPage(),
            AdminGate(builder: (logout) => AdminPanel(onLogout: logout)),
            AdminGate(builder: (logout) => SettingsPage(onLogout: logout)),
          ]),
          bottomNavigationBar: NavigationBar(selectedIndex: i, onDestinationSelected: (v) => setState(() => i = v), destinations: const [
            NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'Ferme'),
            NavigationDestination(icon: Icon(Icons.assessment_outlined), selectedIcon: Icon(Icons.assessment), label: 'Rapport'),
            NavigationDestination(icon: Icon(Icons.admin_panel_settings_outlined), selectedIcon: Icon(Icons.admin_panel_settings), label: 'Admin'),
            NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'Paramètres'),
          ]),
        ),
      );
}

class Home extends StatelessWidget {
  const Home({super.key});
  @override
  Widget build(BuildContext c) => ValueListenableBuilder(
        valueListenable: Repo.records,
        builder: (_, recs, __) {
          final today = DateFormat('yyyy-MM-dd').format(DateTime.now());
          int sumK(String k, {bool t = false}) => Repo.sum(recs.where((r) => r['k'] == k && (!t || r['d'] == today)), 'q').toInt();
          final total = animals.fold<int>(0, (s, a) => s + Repo.stock(a.key));
          return CustomScrollView(slivers: [
            SliverAppBar(
              expandedHeight: 190, pinned: true, foregroundColor: Colors.white, backgroundColor: const Color(0xFF1B5E20),
              actions: [ValueListenableBuilder(valueListenable: Notif.inbox, builder: (_, l, __) {
                final n = l.where((e) => e['r'] != true).length;
                return IconButton(icon: Badge(isLabelVisible: n > 0, label: Text('$n'), child: const Icon(Icons.notifications, color: Colors.white)),
                    onPressed: () => Navigator.push(c, MaterialPageRoute(builder: (_) => const NotifPage())));
              })],
              flexibleSpace: FlexibleSpaceBar(
                title: Text(AppSettings.farm, style: const TextStyle(fontWeight: FontWeight.w800, color: Colors.white, shadows: [Shadow(blurRadius: 6, color: Colors.black54)])),
                background: Container(
                  decoration: const BoxDecoration(gradient: LinearGradient(colors: [Color(0xFF1B5E20), Color(0xFF66BB6A)], begin: Alignment.topLeft, end: Alignment.bottomRight)),
                  child: const CoverImage(),
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: SizedBox(height: 112, child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.all(16), children: [
                _stat('Effectif total', '$total', Icons.pets, Colors.green),
                _stat('Œufs aujourd\'hui', '${sumK('oeufs', t: true)}', Icons.egg, Colors.amber.shade800),
                _stat('Cassés aujourd\'hui', '${sumK('casses', t: true) + Repo.sum(recs.where((r) => r['k'] == 'oeufs' && r['d'] == today), 'br').toInt()}', Icons.heart_broken, Colors.orange),
                _stat('Morts aujourd\'hui', '${sumK('mort', t: true)}', Icons.warning_amber, Colors.red),
                _stat('Éclos (total)', '${sumK('eclosion')}', Icons.cruelty_free, Colors.teal),
              ])),
            ),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              sliver: SliverGrid.builder(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 14, crossAxisSpacing: 14, childAspectRatio: .9),
                itemCount: animals.length,
                itemBuilder: (_, i) => _card(c, animals[i]),
              ),
            ),
          ]);
        },
      );

  Widget _stat(String t, String v, IconData ic, Color col) => Container(
        width: 140, margin: const EdgeInsets.only(right: 12), padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: col.withOpacity(.12), borderRadius: BorderRadius.circular(20)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Icon(ic, color: col), Text(v, style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: col)), Text(t, style: const TextStyle(fontSize: 12)),
        ]),
      );

  Widget _card(BuildContext c, Animal a) => GestureDetector(
        onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => AnimalPage(a))),
        child: Hero(
          tag: a.key,
          child: Material(
            color: Colors.transparent,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(24),
              child: Container(
                color: a.color.withOpacity(.14),
                child: Stack(fit: StackFit.expand, children: [
                  Padding(padding: const EdgeInsets.fromLTRB(8, 8, 8, 40), child: Image.asset(a.logo, fit: BoxFit.contain, errorBuilder: (_, __, ___) => Icon(a.icon, size: 50, color: a.color))),
                  Positioned(left: 0, right: 0, bottom: 10, child: Center(child: Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4), decoration: BoxDecoration(color: a.color, borderRadius: BorderRadius.circular(20)),
                      child: ValueListenableBuilder(valueListenable: Repo.records, builder: (_, __, ___) => Text('${Repo.stock(a.key)} têtes', style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600)))))),
                ]),
              ),
            ),
          ),
        ),
      );
}

class AnimalPage extends StatelessWidget {
  final Animal a;
  const AnimalPage(this.a, {super.key});
  @override
  Widget build(BuildContext c) => Scaffold(
        body: ValueListenableBuilder(
          valueListenable: Repo.records,
          builder: (_, all, __) {
            final l = all.where((r) => r['a'] == a.key).toList();
            return CustomScrollView(slivers: [
              SliverAppBar(
                expandedHeight: 260, pinned: true, title: Text(a.name),
                flexibleSpace: FlexibleSpaceBar(background: Hero(tag: a.key, child: Container(color: a.color.withOpacity(.2), padding: const EdgeInsets.only(top: 60, bottom: 8), child: Image.asset(a.logo, fit: BoxFit.contain, errorBuilder: (_, __, ___) => Icon(a.icon, size: 80, color: a.color))))),
              ),
              SliverToBoxAdapter(
                child: Padding(padding: const EdgeInsets.all(16), child: Wrap(spacing: 10, runSpacing: 10, children: [
                  _chip('Effectif', '${Repo.stock(a.key)}', a.color),
                  if (a.eggs) ...[_chip('Œufs en stock', '${Repo.eggs(a.key)}', a.color), _chip('Œufs cassés', '${Repo.sum(l.where((r) => r['k'] == 'oeufs'), 'br').toInt() + Repo.sum(l.where((r) => r['k'] == 'casses'), 'q').toInt()}', Colors.orange)],
                  for (final k in a.kinds.where((k) => !['vaccin', 'oeufs'].contains(k))) _chip(kindLabels[k]!, '${Repo.sum(l.where((r) => r['k'] == k), 'q').toInt()}', a.color),
                  if (a.eggs) _chip('Œufs pondus', '${Repo.sum(l.where((r) => r['k'] == 'oeufs'), 'q').toInt()}', a.color),
                  _chip('Dépenses nourriture', f(Repo.sum(l.where((r) => r['k'] == 'nourriture'), 'm')), Colors.brown),
                  _chip('Dépenses achat', f(Repo.sum(l.where((r) => r['k'] == 'achat'), 'm')), Colors.red),
                  _chip('Ventes', f(Repo.sum(l.where((r) => r['k'] == 'vente'), 'm')), Colors.green),
                ])),
              ),
              SliverList.builder(
                itemCount: l.where((r) => r['k'] != 'ovente' && r['k'] != 'oachat').length,
                itemBuilder: (_, i) {
                  final r = l.where((r) => r['k'] != 'ovente' && r['k'] != 'oachat').toList()[i];
                  return ListTile(
                    leading: CircleAvatar(backgroundColor: a.color.withOpacity(.15), child: r['pending'] == true ? Icon(Icons.cloud_off, color: a.color) : kindBadge(r['k'], s: 22, col: a.color)),
                    title: Text('${kindLabels[r['k']] ?? r['k']} • ${r['q']}'),
                    subtitle: Text(recSub(r)),
                    trailing: (r['m'] ?? 0) > 0 ? Text(f(r['m']), style: const TextStyle(fontWeight: FontWeight.bold)) : null,
                  );
                },
              ),
            ]);
          },
        ),
      );
  Widget _chip(String t, String v, Color col) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(color: col.withOpacity(.12), borderRadius: BorderRadius.circular(16)),
        child: Column(children: [Text(v, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18, color: col)), Text(t, style: const TextStyle(fontSize: 11))]),
      );
}
