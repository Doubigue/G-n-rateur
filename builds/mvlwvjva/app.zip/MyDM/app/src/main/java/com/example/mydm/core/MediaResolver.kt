package com.example.mydm.core

import android.net.Uri
import com.example.mydm.App
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap
import com.yausername.youtubedl_android.mapper.VideoFormat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.Request
import java.util.concurrent.TimeUnit

data class QualityOption(
    val label: String, val sizeBytes: Long?, val approx: Boolean,
    val selector: String, val mp3: Boolean = false
)

data class YtInfo(val title: String, val uploader: String?, val options: List<QualityOption>, val durationSec: Long = 0)

/** Une qualité d'un flux HLS (liste maître). */
data class HlsVariant(val url: String, val height: Int?, val bandwidth: Long?) {
    val label: String get() = height?.let { "${it}p" } ?: (bandwidth?.let { "%.1f Mb/s".format(it / 1_000_000.0) } ?: "Qualité")
    fun toOption() = QualityOption(label, null, false,
        if (height != null) "bv*[height<=$height]+ba/b[height<=$height]/b" else "b[tbr<=${(bandwidth ?: 0) / 1000}]/b")
}

/** Durée (si connue) et qualités disponibles (seulement si plusieurs) d'un média détecté. */
data class MediaMeta(val durationSec: Long?, val variants: List<HlsVariant>)

object MediaResolver {
    private val client = OkHttpClient.Builder().connectTimeout(10, TimeUnit.SECONDS).readTimeout(10, TimeUnit.SECONDS).build()

    private val supportedHosts = listOf("youtube.com", "youtu.be", "facebook.com", "fb.watch", "fb.com", "tiktok.com",
        "instagram.com", "twitter.com", "x.com", "dailymotion.com", "vimeo.com", "twitch.tv")

    /** Les vidéos de ce site ou plus courtes sont ignorées (publicités) — sauf sur les plateformes ci-dessus. */
    const val MIN_VIDEO_SEC = 120L

    fun isSupportedPage(url: String): Boolean {
        val host = Uri.parse(url).host?.lowercase() ?: return false
        return supportedHosts.any { host == it || host.endsWith(".$it") }
    }

    /** Taille d'un fichier direct (Content-Range / Content-Length). */
    suspend fun probeSize(m: DetectedMedia): Long? = withContext(Dispatchers.IO) {
        runCatching {
            val rb = Request.Builder().url(m.url).header("Range", "bytes=0-0").header("User-Agent", m.userAgent)
            m.referer?.let { rb.header("Referer", it) }
            m.cookies?.let { rb.header("Cookie", it) }
            client.newCall(rb.build()).execute().use { r ->
                r.header("Content-Range")?.substringAfter('/')?.toLongOrNull()
                    ?: if (r.code == 200) r.header("Content-Length")?.toLongOrNull() else null
            }
        }.getOrNull()
    }

    // ── Durée + qualités d'un média détecté
    private val metaCache = ConcurrentHashMap<String, MediaMeta>()
    fun cachedMeta(url: String): MediaMeta? = metaCache[url]

    suspend fun probeMeta(m: DetectedMedia): MediaMeta = withContext(Dispatchers.IO) {
        metaCache[m.url]?.let { return@withContext it }
        val meta = withTimeoutOrNull(9_000) { runCatching { if (m.type == MediaType.HLS) hlsMeta(m) else fileMeta(m) }.getOrNull() }
            ?: MediaMeta(null, emptyList())
        if (meta.durationSec != null || meta.variants.isNotEmpty()) metaCache[m.url] = meta
        meta
    }

    private fun getText(m: DetectedMedia, url: String): String? {
        val rb = Request.Builder().url(url).header("User-Agent", m.userAgent)
        m.referer?.let { rb.header("Referer", it) }
        m.cookies?.let { rb.header("Cookie", it) }
        return client.newCall(rb.build()).execute().use { r -> if (r.isSuccessful) r.body?.string()?.take(2_000_000) else null }
    }

    private fun sumExtinf(txt: String): Long? {
        if ("#EXT-X-ENDLIST" !in txt && "PLAYLIST-TYPE:VOD" !in txt) return null     // direct : durée inconnue
        val total = Regex("#EXTINF:([0-9.]+)").findAll(txt).sumOf { it.groupValues[1].toDoubleOrNull() ?: 0.0 }
        return if (total > 0) total.toLong() else null
    }

    private fun hlsMeta(m: DetectedMedia): MediaMeta {
        val txt = getText(m, m.url) ?: return MediaMeta(null, emptyList())
        if ("#EXT-X-STREAM-INF" !in txt) return MediaMeta(sumExtinf(txt), emptyList())
        val base = m.url.toHttpUrlOrNull()
        val lines = txt.lines()
        val all = ArrayList<HlsVariant>()
        for (i in lines.indices) {
            val l = lines[i]
            if (!l.startsWith("#EXT-X-STREAM-INF")) continue
            val bw = Regex("BANDWIDTH=(\\d+)").find(l)?.groupValues?.get(1)?.toLongOrNull()
            val h = Regex("RESOLUTION=\\d+x(\\d+)").find(l)?.groupValues?.get(1)?.toIntOrNull()
            val next = lines.drop(i + 1).firstOrNull { it.isNotBlank() && !it.startsWith("#") }?.trim() ?: continue
            val u = base?.resolve(next)?.toString() ?: continue
            all += HlsVariant(u, h, bw)
        }
        // Une entrée par hauteur (la plus haute qualité de débit), de la meilleure à la plus basse
        val distinct = all.groupBy { it.height ?: -1 }.values.map { g -> g.maxByOrNull { it.bandwidth ?: 0 }!! }
            .sortedWith(compareByDescending<HlsVariant> { it.height ?: 0 }.thenByDescending { it.bandwidth ?: 0 })
        val dur = all.maxByOrNull { it.bandwidth ?: 0 }?.let { v -> runCatching { getText(m, v.url) }.getOrNull() }?.let(::sumExtinf)
        return MediaMeta(dur, if (distinct.size >= 2) distinct else emptyList())   // choix seulement s'il y en a plusieurs
    }

    private fun fileMeta(m: DetectedMedia): MediaMeta {
        val r = android.media.MediaMetadataRetriever()
        return try {
            val h = HashMap<String, String>().apply {
                put("User-Agent", m.userAgent); m.referer?.let { put("Referer", it) }; m.cookies?.let { put("Cookie", it) }
            }
            r.setDataSource(m.url, h)
            val ms = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
            MediaMeta(ms?.let { it / 1000 }?.takeIf { it > 0 }, emptyList())
        } finally { runCatching { r.release() } }
    }

    private val hosters = listOf("voe.", "streamtape", "dood", "uqload", "vidoza", "mixdrop", "upstream", "filemoon",
        "vidmoly", "supervideo", "streamlare", "mp4upload", "vtube", "sibnet", "ok.ru", "vk.com", "dailymotion", "vimeo")
    /** Hébergeurs de vidéos courants que yt-dlp sait souvent extraire. */
    fun isKnownHoster(url: String): Boolean {
        val host = Uri.parse(url).host?.lowercase() ?: return false
        return hosters.any { it in host }
    }

    /** Lien d'une vraie vidéo (et pas la page d'accueil / un fil) : seuls ceux-ci méritent une pré-analyse. */
    fun isVideoPage(url: String): Boolean {
        if (!isSupportedPage(url)) return false
        val u = url.lowercase()
        return "watch?v=" in u || "youtu.be/" in u || "/shorts/" in u || "/live/" in u ||
            "/videos/" in u || "/watch" in u || "/reel" in u || "fb.watch" in u || "/video/" in u ||
            "vm.tiktok.com" in u || "/t/" in u || "vt.tiktok.com" in u ||
            ("instagram.com" in u && ("/p/" in u || "/tv/" in u)) || ("/status/" in u && ("twitter.com" in u || "x.com" in u)) ||
            ("vimeo.com/" in u && Regex("vimeo\\.com/(\\w+/)*\\d+").containsMatchIn(u)) || "twitch.tv/videos" in u
    }

    // ── Cache + pré-analyse : la 2e demande (ou l'ouverture de la fenêtre) est instantanée
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val inflight = ConcurrentHashMap<String, Deferred<YtInfo>>()
    private val cache = ConcurrentHashMap<String, Pair<Long, YtInfo>>()
    private const val TTL = 15 * 60_000L
    private fun key(url: String) = url.trim().substringBefore('#')

    fun cached(url: String): YtInfo? = cache[key(url)]?.takeIf { System.currentTimeMillis() - it.first < TTL }?.second

    /** Lance l'analyse en arrière-plan (sans attendre le résultat). */
    fun prefetch(app: App, url: String) {
        if (!isVideoPage(url) || cached(url) != null || inflight.containsKey(key(url))) return
        scope.launch { runCatching { ytInfo(app, url) } }
    }

    suspend fun ytInfo(app: App, url: String): YtInfo {
        val k = key(url)
        cached(url)?.let { return it }
        val d = inflight.getOrPut(k) {
            scope.async {
                try { fetchInfo(app, url).also { cache[k] = System.currentTimeMillis() to it } }
                finally { inflight.remove(k) }
            }
        }
        return d.await()
    }

    /** Analyse un lien YouTube / Facebook / TikTok / HLS avec yt-dlp et liste les qualités + tailles. */
    private suspend fun fetchInfo(app: App, url: String): YtInfo = withContext(Dispatchers.IO) {
        withTimeoutOrNull(90_000) { app.ytState.first { it != "loading" } }
            ?: error("Moteur en cours d'initialisation, réessayez dans un instant.")
        val st = app.ytState.value
        if (st.startsWith("error:")) error("Moteur indisponible : ${st.removePrefix("error:")}")

        // Options « rapides » : pas de playlist, délais courts, une seule nouvelle tentative
        val req = YoutubeDLRequest(url).apply {
            addOption("--no-playlist")
            addOption("--no-warnings")
            addOption("--socket-timeout", 10)
            addOption("--extractor-retries", 1)
        }
        val info = YoutubeDL.getInstance().getInfo(req)
        val fmts = info.formats.orEmpty()

        fun exact(f: VideoFormat): Long? = f.fileSize.takeIf { it > 0 } ?: f.fileSizeApproximate.takeIf { it > 0 }
        fun est(f: VideoFormat): Pair<Long?, Boolean> {
            exact(f)?.let { return it to false }
            return if (f.tbr > 0 && info.duration > 0) (f.tbr * 1000L / 8 * info.duration) to true else (null to false)
        }

        val videos = fmts.filter { it.height > 0 && it.vcodec != "none" }
        val audios = fmts.filter { it.vcodec == "none" && it.acodec != "none" }
        val bestAudio = audios.maxByOrNull { maxOf(it.abr, it.tbr) }
        val audioEst = bestAudio?.let { est(it) }

        val opts = mutableListOf<QualityOption>()
        videos.groupBy { it.height }.toSortedMap(compareByDescending<Int> { it }).entries.take(6).forEach { (h, group) ->
            val best = group.maxByOrNull { it.tbr } ?: group.first()
            val (s, approx) = est(best)
            val needsAudio = best.acodec == "none"
            val total = s?.plus(if (needsAudio) (audioEst?.first ?: 0L) else 0L)
            val fps = if (best.fps > 30) " ${best.fps}fps" else ""
            val ext = if (needsAudio) "MP4" else (best.ext ?: "mp4").uppercase()
            opts += QualityOption("${h}p$fps • $ext", total, approx || (needsAudio && audioEst?.second == true),
                "bv*[height<=$h][ext=mp4]+ba[ext=m4a]/bv*[height<=$h]+ba/b[height<=$h]")
        }
        if (opts.isEmpty()) {
            val sz = info.fileSize.takeIf { it > 0 } ?: info.fileSizeApproximate.takeIf { it > 0 }
            opts += QualityOption("Meilleure qualité", sz, false, "b/best")
        }
        if (bestAudio != null || videos.isNotEmpty()) {
            opts += QualityOption("Audio M4A", audioEst?.first, audioEst?.second ?: true, "ba[ext=m4a]/ba/b")
            opts += QualityOption("Audio MP3", audioEst?.first, true, "ba/b", mp3 = true)
        }
        YtInfo(info.title ?: info.fulltitle ?: "video", info.uploader, opts, info.duration.toLong().coerceAtLeast(0))
    }
}
