package com.linkshare.plugin.api

/**
 * Une action affichée dans l'écran « Action » quand la sélection correspond.
 *
 * @param icon emoji ou court texte affiché devant le libellé (vide = 🧩)
 * @param accepts types acceptés pour CHAQUE fichier : type MIME exact (`image/png`), famille (`image/` + une étoile),
 *   toutes les familles (une étoile seule) ou extension (`txt`, `.txt`). Insensible à la casse. Liste vide = tous les fichiers.
 * @param minFiles nombre minimal de fichiers sélectionnés
 * @param maxFiles nombre maximal ; [Int.MAX_VALUE] = illimité
 * @param params réglages demandés à l'utilisateur avant l'exécution (boîte de dialogue générée)
 */
class PluginAction @JvmOverloads constructor(
    val id: String,
    val label: String,
    val icon: String = "",
    val accepts: List<String> = emptyList(),
    val minFiles: Int = 1,
    val maxFiles: Int = 1,
    val params: List<PluginParam> = emptyList(),
)

/**
 * Un paramètre d'action ou un réglage du plugin.
 *
 * @param type `int`, `float`, `bool`, `choice` ou `text` (voir [PluginParamType])
 * @param default valeur par défaut, écrite en texte (`"5"`, `"0.5"`, `"true"`, un élément de [choices], …)
 * @param min borne basse (int / float) ; [max] borne haute. Sans bornes : 0 à 100.
 * @param choices valeurs possibles pour `choice`
 *
 * Dans [LinkSharePlugin.run], les valeurs arrivent dans `params` sous forme de texte : `"true"`/`"false"` pour bool,
 * `"42"` pour int, `"0.5"` (point décimal) pour float.
 */
class PluginParam @JvmOverloads constructor(
    val key: String,
    val label: String,
    val type: String,
    val default: String = "",
    val min: Double? = null,
    val max: Double? = null,
    val choices: List<String> = emptyList(),
)

object PluginParamType {
    const val INT = "int"
    const val FLOAT = "float"
    const val BOOL = "bool"
    const val CHOICE = "choice"
    const val TEXT = "text"
    val ALL = setOf(INT, FLOAT, BOOL, CHOICE, TEXT)
}

/**
 * Un fichier choisi par l'utilisateur. [uri] est une adresse (`file://…` ou `content://…`) donnée à titre d'identifiant :
 * pour lire le contenu, utilise toujours [PluginHost.openInput].
 */
class PluginInput(val name: String, val mime: String, val uri: String)

/** Résultat de [LinkSharePlugin.run]. */
sealed class PluginResult {
    /**
     * @param outputs noms des fichiers produits (informatif : LinkShare affiche les noms réellement créés,
     *   qui peuvent différer si un fichier du même nom existait déjà — rien n'est jamais écrasé)
     * @param message texte court affiché avec « Terminé »
     */
    class Success @JvmOverloads constructor(val outputs: List<String> = emptyList(), val message: String = "") : PluginResult()

    /** Échec « normal » (fichier illisible, paramètre invalide…). Les fichiers de sortie déjà créés sont supprimés. */
    class Failure(val message: String) : PluginResult()
}

/**
 * Réservé pour une version future (NON implémenté dans LinkShare 1.6) : écran Compose optionnel fourni par le plugin.
 * Voir plugin-tools/README-v2.md, section « Écran Compose optionnel ».
 */
interface PluginScreenProvider {
    fun screens(): List<PluginScreen>
}

/** Réservé : description d'un écran fourni par un plugin. */
class PluginScreen @JvmOverloads constructor(val id: String, val title: String, val icon: String = "")
