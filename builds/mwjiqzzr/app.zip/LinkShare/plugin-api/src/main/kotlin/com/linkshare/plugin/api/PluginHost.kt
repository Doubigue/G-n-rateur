package com.linkshare.plugin.api

import android.content.Context
import android.content.SharedPreferences
import java.io.InputStream
import java.io.OutputStream

/** Ce que LinkShare met à disposition du plugin pendant [LinkSharePlugin.run]. */
interface PluginHost {
    /** Contexte de LinkShare (le code du plugin tourne avec les droits de LinkShare). */
    val context: Context

    /** Préférences propres au plugin (les `settings[]` de plugin.json y sont écrits sous leur `key`). */
    val prefs: SharedPreferences

    /** Lit un fichier du dossier `assets/` du plugin (chemin relatif, ex. `"models/fr.bin"`). */
    fun openAsset(path: String): InputStream

    /** Ouvre un des fichiers choisis par l'utilisateur. Refuse tout autre fichier. Nécessite la permission `storage`. */
    fun openInput(i: PluginInput): InputStream

    /**
     * Crée un fichier de sortie à côté du fichier source. Le nom est nettoyé et rendu unique (« nom (1).ext ») :
     * aucun fichier existant n'est écrasé. Ferme le flux quand tu as fini. Nécessite la permission `storage`.
     */
    fun createOutput(name: String, mime: String): OutputStream

    /** Fait avancer la notification de progression (0 à 100) avec un court texte. */
    fun progress(percent: Int, text: String)

    /** true quand l'utilisateur a touché « Annuler » : arrête-toi dès que possible. */
    fun isCancelled(): Boolean
}
