package com.linkshare.plugin.api

/**
 * Contrat 2 — plugin intégré : du code chargé directement dans LinkShare (classes.dex), sans appli à installer.
 *
 * Le plugin déclare une classe publique avec un constructeur sans argument qui implémente cette interface ;
 * son nom complet est donné dans plugin.json (`entryClass`).
 *
 * Règles :
 *  - [run] s'exécute hors du thread principal, dans un service de premier plan. Appelle régulièrement
 *    [PluginHost.isCancelled] et arrête-toi vite quand il vaut true (le bouton « Annuler » ne peut pas tuer ton code).
 *  - N'écris jamais ailleurs que via [PluginHost.createOutput] ; ne lis que via [PluginHost.openInput].
 *  - Toute exception non rattrapée met le plugin « en erreur » (désactivé tant que l'utilisateur ne le relance pas).
 */
interface LinkSharePlugin {
    /** Les actions proposées (doit contenir au moins les `id` déclarés dans plugin.json). */
    fun actions(): List<PluginAction>

    suspend fun run(
        host: PluginHost,
        actionId: String,
        inputs: List<PluginInput>,
        params: Map<String, String>,
    ): PluginResult
}
