plugins {
    id("com.android.library")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.linkshare.plugin.api"
    compileSdk = 35
    defaultConfig {
        minSdk = 30
        // Garde les classes du contrat si LinkShare est un jour compilé avec R8 (elles sont partagées avec les plugins)
        consumerProguardFiles("consumer-rules.pro")
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

// Aucune dépendance : le contrat n'utilise que la bibliothèque standard de Kotlin et android.jar.
// (suspend fun = kotlin.coroutines.Continuation, déjà dans la stdlib : pas de kotlinx-coroutines ici.)

/**
 * Fabrique le .jar à donner aux projets de plugins :  ./gradlew :plugin-api:exportApiJar
 * → build/plugin-api/linkshare-plugin-api-<version>.jar  (à déclarer en `compileOnly` dans le projet du plugin).
 */
tasks.register<Jar>("exportApiJar") {
    group = "linkshare"
    description = "Exporte linkshare-plugin-api.jar pour les projets de plugins"
    dependsOn("compileReleaseKotlin")
    from(layout.buildDirectory.dir("tmp/kotlin-classes/release")) { exclude("META-INF/**") }
    archiveBaseName.set("linkshare-plugin-api")
    archiveVersion.set("2.0")
    destinationDirectory.set(rootProject.layout.buildDirectory.dir("plugin-api"))
}
