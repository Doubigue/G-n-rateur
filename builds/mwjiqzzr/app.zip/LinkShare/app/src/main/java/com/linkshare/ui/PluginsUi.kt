package com.linkshare.ui

import android.text.format.Formatter
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linkshare.core.PluginDraft
import com.linkshare.core.PluginEntry
import com.linkshare.core.PluginManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ═══════════════════════════ Paramètres › Install plugins ═══════════════════════════

/** Contenu de la section « Install plugins » des Paramètres. */
internal fun LazyListScope.pluginItems() {
    item { PluginAddCard() }
    item { PluginDraftCard() }
    item { PluginInstalledCard() }
    // Plugins intégrés (contrat 2) : carte de configuration + liste (interrupteur, réglages, permissions, suppression)
    embeddedPluginItems()
}

@Composable
private fun PluginAddCard() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var open by remember { mutableStateOf(false) }
    var url by remember { mutableStateOf("") }
    val busy = PluginManager.busy

    LaunchedEffect(Unit) { PluginManager.refresh(ctx) }

    // Fichier .lsplugin ou .apk choisi dans le sélecteur d'Android
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            PluginManager.busy = true; PluginManager.status = "Analyse du plugin…"
            val err = withContext(Dispatchers.IO) { PluginManager.inspect(ctx, uri) }
            PluginManager.status = err ?: "Plugin valide : vérifie les informations puis valide"
            PluginManager.busy = false
        }
    }

    Column(
        Modifier.fillMaxWidth().lsCard(RoundedCornerShape(UiStyle.r(22.dp))).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBadge(Ic.Apps, LS.Blue, 42.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Install plugins", color = LS.Text, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                Text(
                    "Applis-plugins (ex. Media Studio) ou plugins intégrés (.lsplugin) que LinkShare pourra utiliser",
                    color = LS.Muted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
                )
            }
        }
        Button(
            { open = !open }, Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = LS.Blue, contentColor = LS.OnBlue),
        ) { Text(if (open) "Fermer" else "Ajouter un nouveau plugin", fontWeight = FontWeight.SemiBold) }

        AnimatedVisibility(open) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // 1) Fichier local : téléverser, configurer (aperçu), valider
                OutlinedButton(
                    { picker.launch(arrayOf("*/*")) }, Modifier.fillMaxWidth(), enabled = !busy,
                ) {
                    Icon(Ic.Folder, null, Modifier.size(18.dp), tint = LS.Blue)
                    Spacer(Modifier.width(8.dp))
                    Text("Téléverser un plugin (.lsplugin ou .apk)", color = LS.Blue)
                }
                HorizontalDivider(color = LS.Line)
                // 2) Lien en ligne : télécharger puis installer
                OutlinedTextField(
                    url, { url = it }, Modifier.fillMaxWidth(), singleLine = true, enabled = !busy,
                    label = { Text("Lien du plugin (https://…)") },
                    leadingIcon = { Icon(Ic.Link, null, Modifier.size(20.dp), tint = LS.Muted) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                )
                Button(
                    {
                        scope.launch {
                            PluginManager.busy = true; PluginManager.status = "Téléchargement…"
                            val err = withContext(Dispatchers.IO) { PluginManager.download(ctx, url) }
                            PluginManager.busy = false
                            if (err != null) { PluginManager.status = err; return@launch }
                            // Plugin intégré (contrat 2) : jamais installé sans passer par la carte de configuration
                            if (PluginManager.draft == null && com.linkshare.core.embedded.EmbeddedPlugins.draft != null) {
                                PluginManager.status = "Plugin intégré valide : vérifie les informations puis valide"
                                return@launch
                            }
                            val d = PluginManager.draft ?: return@launch
                            PluginManager.status = PluginManager.install(ctx, d) ?: "Installation lancée : confirme dans la fenêtre d'Android"
                        }
                    },
                    Modifier.fillMaxWidth(), enabled = !busy && url.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = LS.Blue, contentColor = LS.OnBlue),
                ) {
                    Icon(Ic.Download, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Télécharger et installer", fontWeight = FontWeight.SemiBold)
                }
            }
        }
        PluginManager.progress?.let { LinearProgressIndicator(progress = { it }, modifier = Modifier.fillMaxWidth().clip(CircleShape), color = LS.Blue) }
        if (busy && PluginManager.progress == null) LinearProgressIndicator(Modifier.fillMaxWidth().clip(CircleShape), color = LS.Blue)
        PluginManager.status?.let { Text(it, color = LS.Muted, fontSize = 12.sp) }
    }
}

/** Configuration du plugin téléversé : informations vérifiées, puis « Valider et installer ». */
@Composable
private fun PluginDraftCard() {
    val ctx = LocalContext.current
    val d: PluginDraft = PluginManager.draft ?: return
    val i = d.info
    Column(
        Modifier.fillMaxWidth().lsCard(RoundedCornerShape(UiStyle.r(22.dp))).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Text("Configuration du plugin", color = LS.Blue, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        Text("${i.name} · ${i.version}", color = LS.Text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        if (i.description.isNotBlank()) Text(i.description, color = LS.Text.copy(alpha = 0.85f), fontSize = 13.sp)
        Text("Package : ${i.pkg}", color = LS.Muted, fontSize = 12.sp)
        Text("Taille : " + Formatter.formatShortFileSize(ctx, d.sizeBytes), color = LS.Muted, fontSize = 12.sp)
        if (i.actions.isNotEmpty()) Text("Fonctions : " + i.actions.joinToString(" · "), color = LS.Muted, fontSize = 12.sp)
        Text(
            if (d.shaChecked) "Empreinte SHA-256 vérifiée ✓" else "Pas d'empreinte fournie : source non contrôlée",
            color = if (d.shaChecked) LS.Green else LS.Amber, fontSize = 12.sp,
        )
        i.signer?.let { Text("Signature : ${it.take(16)}…", color = LS.Muted, fontSize = 12.sp) }
        d.note?.let { Text(it, color = LS.Blue, fontSize = 12.sp) }
        Spacer(Modifier.height(4.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                {
                    PluginManager.status = PluginManager.install(ctx, d) ?: "Installation lancée : confirme dans la fenêtre d'Android"
                },
                Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = LS.Blue, contentColor = LS.OnBlue),
            ) { Text("Valider et installer", fontWeight = FontWeight.SemiBold, maxLines = 1) }
            OutlinedButton({ PluginManager.cancelDraft(ctx); PluginManager.status = null }) { Text("Annuler", color = LS.Blue) }
        }
    }
}

/** Carte « Plugins installés » avec un petit bouton de suppression par plugin. */
@Composable
private fun PluginInstalledCard() {
    val ctx = LocalContext.current
    var confirm by remember { mutableStateOf<PluginEntry?>(null) }
    val list = PluginManager.entries
    Column(
        Modifier.fillMaxWidth().lsCard(RoundedCornerShape(UiStyle.r(22.dp))).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text("Plugins installés (${list.count { it.installed }})", color = LS.Blue, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        if (list.isEmpty()) Text("Aucun plugin pour l'instant", color = LS.Muted, fontSize = 13.sp)
        list.forEach { e ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(40.dp).clip(CircleShape).background(LS.Card2), contentAlignment = Alignment.Center) {
                    Icon(Ic.Apps, null, Modifier.size(20.dp), tint = if (e.installed) LS.Blue else LS.Muted)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(e.info.name, color = LS.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        if (e.installed) "Version ${e.installedVersion} · prêt" else "En attente d'installation",
                        color = if (e.installed) LS.Muted else LS.Amber, fontSize = 12.sp, maxLines = 1,
                    )
                }
                Icon(
                    Ic.Delete, "Supprimer le plugin",
                    Modifier.clip(CircleShape).clickable { confirm = e }.padding(8.dp).size(20.dp), tint = LS.Muted,
                )
            }
        }
    }
    confirm?.let { e ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text("Supprimer ${e.info.name} ?") },
            text = { Text(if (e.installed) "L'application du plugin sera désinstallée (Android demande une confirmation)." else "Le plugin sera retiré de la liste.") },
            confirmButton = {
                TextButton({
                    confirm = null
                    PluginManager.remove(ctx, e)
                    Toast.makeText(ctx, if (e.installed) "Confirme la désinstallation" else "Plugin retiré", Toast.LENGTH_SHORT).show()
                }) { Text("Supprimer") }
            },
            dismissButton = { TextButton({ confirm = null }) { Text("Annuler") } },
        )
    }
}
