package com.linkshare.core.embedded

import org.json.JSONArray
import org.json.JSONObject

/** Erreur lisible (affichée telle quelle à l'utilisateur) levée par l'analyse d'un plugin.json. */
class ManifestException(message: String) : Exception(message)

class ManifestParam(
    val key: String, val label: String, val type: String, val default: String,
    val min: Double?, val max: Double?, val choices: List<String>,
)

class ManifestAction(
    val id: String, val label: String, val icon: String, val accepts: List<String>,
    val minFiles: Int, val maxFiles: Int, val params: List<ManifestParam>,
)

/** Contenu validé d'un plugin.json de contrat 2. */
class PluginManifest(
    val id: String, val name: String, val version: String, val description: String,
    val entryClass: String, val contract: Int, val permissions: List<String>,
    val actions: List<ManifestAction>, val settings: List<ManifestParam>,
    val replacesBridge: String?,
    /** Empreinte SHA-256 (hexa minuscules) de chaque fichier du plugin, hors plugin.json. */
    val sha256: Map<String, String>,
    /** Réservé : écrans Compose fournis par le plugin (non utilisés dans LinkShare 1.6). */
    val screens: List<String> = emptyList(),
) {
    companion object {
        /** Fiche minimale pour un plugin dont le plugin.json est illisible (il est alors affiché « en erreur »). */
        fun placeholder(id: String, version: String) = PluginManifest(
            id, id, version, "", "", PluginManifestParser.CONTRACT, emptyList(), emptyList(), emptyList(), null, emptyMap(),
        )
    }
}

/** Chemins autorisés dans un .lsplugin et noms de fichiers sûrs. */
object PluginPaths {
    val ABIS = setOf("arm64-v8a", "armeabi-v7a", "x86", "x86_64")

    /** Nom d'entrée de zip sûr : relatif, sans « .. », sans antislash, sans segment vide ni caractère de contrôle. */
    fun isSafeName(name: String): Boolean {
        if (name.isEmpty() || name.length > 200) return false
        if (name.startsWith("/") || name.endsWith("/") || name.contains('\\') || name.any { it < ' ' }) return false
        return name.split('/').none { it.isEmpty() || it == "." || it == ".." }
    }

    /** Seuls classes.dex, le dossier assets et lib/<abi>/<fichier>.so sont acceptés (plugin.json est traité à part). */
    fun isAllowedEntry(name: String): Boolean {
        if (!isSafeName(name)) return false
        if (name == "classes.dex") return true
        if (name.startsWith("assets/")) return name.length > "assets/".length
        val p = name.split('/')
        return p.size == 3 && p[0] == "lib" && p[1] in ABIS && p[2].endsWith(".so") && p[2].length > 3
    }
}

object PluginManifestParser {
    const val CONTRACT = 2
    val PERMISSIONS = setOf("storage", "notifications", "network")
    val KNOWN_BRIDGES = setOf("studio", "extrait", "editor")
    const val MAX_JSON_BYTES = 64 * 1024

    private val ID = Regex("^[a-z0-9][a-z0-9_-]{1,39}$")
    private val VERSION = Regex("^[0-9A-Za-z][0-9A-Za-z._+-]{0,30}$")
    private val CLASS = Regex("^[A-Za-z_][A-Za-z0-9_$]*(\\.[A-Za-z_][A-Za-z0-9_$]*)*$")
    private val ACTION_ID = Regex("^[A-Za-z0-9_.-]{1,40}$")
    private val KEY = Regex("^[A-Za-z][A-Za-z0-9_]{0,39}$")
    private val SHA = Regex("^[0-9a-f]{64}$")

    /** @throws ManifestException avec un message clair si le plugin.json est invalide. */
    fun parse(text: String, knownBridges: Set<String> = KNOWN_BRIDGES): PluginManifest {
        val o = try { JSONObject(text) } catch (e: Exception) { throw ManifestException("plugin.json illisible : ${e.message}") }

        val contract = o.optInt("contract", -1)
        if (contract != CONTRACT) throw ManifestException("plugin.json : « contract » doit valoir $CONTRACT")
        val id = o.str("id")
        if (!ID.matches(id)) throw ManifestException("plugin.json : id invalide (minuscules, chiffres, - et _ ; 2 à 40 caractères)")
        val name = o.str("name").ifBlank { throw ManifestException("plugin.json : « name » manquant") }.take(60)
        val version = o.str("version")
        if (!VERSION.matches(version)) throw ManifestException("plugin.json : version invalide")
        val entry = o.str("entryClass")
        if (!CLASS.matches(entry)) throw ManifestException("plugin.json : entryClass invalide")

        val perms = o.strList("permissions", 10).map { it.lowercase() }.distinct()
        perms.firstOrNull { it !in PERMISSIONS }?.let { throw ManifestException("plugin.json : permission inconnue « $it » (storage, notifications ou network)") }

        val actionsJson = o.optJSONArray("actions") ?: throw ManifestException("plugin.json : « actions » manquant")
        if (actionsJson.length() == 0) throw ManifestException("plugin.json : au moins une action est nécessaire")
        if (actionsJson.length() > 30) throw ManifestException("plugin.json : 30 actions au maximum")
        val actions = (0 until actionsJson.length()).map { parseAction(actionsJson.optJSONObject(it) ?: throw ManifestException("plugin.json : action ${it + 1} invalide")) }
        if (actions.map { it.id }.toSet().size != actions.size) throw ManifestException("plugin.json : identifiants d'action en double")

        val settingsJson = o.optJSONArray("settings") ?: JSONArray()
        if (settingsJson.length() > 30) throw ManifestException("plugin.json : 30 réglages au maximum")
        val settings = (0 until settingsJson.length()).map { parseParam(settingsJson.optJSONObject(it) ?: throw ManifestException("plugin.json : réglage ${it + 1} invalide")) }
        if (settings.map { it.key }.toSet().size != settings.size) throw ManifestException("plugin.json : clés de réglage en double")

        val replaces = o.str("replacesBridge").lowercase().ifBlank { null }
        if (replaces != null && replaces !in knownBridges) throw ManifestException("plugin.json : replacesBridge « $replaces » inconnu (${knownBridges.sorted().joinToString(", ")})")

        val shaObj = o.optJSONObject("sha256") ?: throw ManifestException("plugin.json : « sha256 » (empreinte de chaque fichier) manquant")
        val sha = LinkedHashMap<String, String>()
        shaObj.keys().forEach { k ->
            if (!PluginPaths.isAllowedEntry(k)) throw ManifestException("plugin.json : fichier non autorisé dans sha256 : $k")
            val v = shaObj.optString(k).lowercase()
            if (!SHA.matches(v)) throw ManifestException("plugin.json : empreinte invalide pour $k")
            sha[k] = v
        }
        if ("classes.dex" !in sha) throw ManifestException("plugin.json : l'empreinte de classes.dex est obligatoire")

        val screens = o.optJSONArray("screens")?.let { a -> (0 until a.length()).mapNotNull { a.optJSONObject(it)?.optString("id")?.takeIf(String::isNotBlank) } }.orEmpty()

        return PluginManifest(
            id, name, version, o.str("description").take(300), entry, contract, perms, actions, settings, replaces, sha, screens,
        )
    }

    private fun parseAction(a: JSONObject): ManifestAction {
        val id = a.str("id")
        if (!ACTION_ID.matches(id)) throw ManifestException("plugin.json : id d'action invalide « $id »")
        val label = a.str("label").ifBlank { throw ManifestException("plugin.json : l'action « $id » n'a pas de libellé") }.take(60)
        val min = if (a.has("minFiles")) a.optInt("minFiles", 1) else 1
        if (min < 1) throw ManifestException("plugin.json : minFiles de « $id » doit être ≥ 1")
        val rawMax = if (a.has("maxFiles")) a.optInt("maxFiles", 1) else 1
        val max = if (rawMax <= 0) Int.MAX_VALUE else rawMax
        if (max < min) throw ManifestException("plugin.json : maxFiles < minFiles pour « $id »")
        val paramsJson = a.optJSONArray("params") ?: JSONArray()
        if (paramsJson.length() > 12) throw ManifestException("plugin.json : 12 paramètres au maximum par action")
        val params = (0 until paramsJson.length()).map { parseParam(paramsJson.optJSONObject(it) ?: throw ManifestException("plugin.json : paramètre invalide dans « $id »")) }
        if (params.map { it.key }.toSet().size != params.size) throw ManifestException("plugin.json : clés de paramètre en double dans « $id »")
        return ManifestAction(id, label, a.str("icon").take(8), a.strList("accepts", 20).map { it.take(80) }, min, max, params)
    }

    fun parseParam(p: JSONObject): ManifestParam {
        val key = p.str("key")
        if (!KEY.matches(key)) throw ManifestException("plugin.json : clé invalide « $key »")
        val type = p.str("type").lowercase()
        if (type !in TYPES) throw ManifestException("plugin.json : type « $type » inconnu pour « $key » (int, float, bool, choice, text)")
        val label = p.str("label").ifBlank { key }.take(60)
        val rawDefault = if (p.isNull("default")) "" else p.opt("default")?.toString().orEmpty()
        return when (type) {
            "bool" -> ManifestParam(key, label, type, if (rawDefault.equals("true", true)) "true" else "false", null, null, emptyList())
            "text" -> ManifestParam(key, label, type, rawDefault.take(200), null, null, emptyList())
            "choice" -> {
                val choices = p.strList("choices", 20).map { it.take(60) }.distinct()
                if (choices.isEmpty()) throw ManifestException("plugin.json : « $key » (choice) demande une liste « choices »")
                ManifestParam(key, label, type, if (rawDefault in choices) rawDefault else choices[0], null, null, choices)
            }
            else -> { // int / float
                val lo = if (p.has("min") && !p.isNull("min")) p.optDouble("min", 0.0) else 0.0
                val hi = if (p.has("max") && !p.isNull("max")) p.optDouble("max", 100.0) else 100.0
                if (!(lo < hi)) throw ManifestException("plugin.json : « $key » : min doit être inférieur à max")
                val d = (rawDefault.toDoubleOrNull() ?: lo).coerceIn(lo, hi)
                val dText = if (type == "int") Math.round(d).toString() else trimNumber(d)
                ManifestParam(key, label, type, dText, lo, hi, emptyList())
            }
        }
    }

    private val TYPES = setOf("int", "float", "bool", "choice", "text")

    fun trimNumber(d: Double): String = if (d == Math.floor(d) && Math.abs(d) < 1e15) d.toLong().toString() else d.toString()

    private fun JSONObject.str(k: String): String = if (isNull(k)) "" else optString(k, "").trim()

    private fun JSONObject.strList(k: String, max: Int): List<String> {
        val a = optJSONArray(k) ?: return emptyList()
        if (a.length() > max) throw ManifestException("plugin.json : « $k » : $max éléments au maximum")
        return (0 until a.length()).mapNotNull { a.optString(it, "").trim().takeIf(String::isNotEmpty) }
    }
}
