package com.linkshare.core.embedded

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.webkit.MimeTypeMap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.linkshare.core.PluginManager
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.security.MessageDigest
import java.util.zip.ZipFile

/** Plugin intégré installé : sa fiche (relue depuis plugin.json), son interrupteur et les permissions acceptées. */
class EmbeddedEntry(val manifest: PluginManifest, val enabled: Boolean, val grantedPermissions: List<String>) {
    val id get() = manifest.id
}

/** Plugin analysé dans le dossier de préparation, prêt à être installé après « Valider et installer ». */
class EmbeddedDraft(
    val manifest: PluginManifest, val stageDir: File, val sizeBytes: Long, val existing: EmbeddedEntry?,
) {
    val isUpdate get() = existing != null
    val permissionsChanged get() = existing == null || existing.grantedPermissions.toSet() != manifest.permissions.toSet()
    val addedPermissions get() = manifest.permissions - (existing?.grantedPermissions?.toSet() ?: emptySet())
    /** Confirmation obligatoire : première installation ou mise à jour qui change les permissions. */
    val needsConfirmation get() = existing == null || permissionsChanged
}

/**
 * Plugins INTÉGRÉS (contrat 2) : du code (classes.dex) chargé dans LinkShare, sans appli à installer.
 *
 * Totalement indépendants des Ponts (Bridges.kt) et des plugins installés (PluginManager.kt, contrat 1) :
 *  - leur interrupteur est propre à chaque plugin (registre plugins.v2.json) ;
 *  - ils ne lisent jamais l'état des ponts ; seul un plugin actif et sain qui annonce `replacesBridge` fait
 *    MASQUER un pont (sans toucher à son réglage), et le pont réapparaît si le plugin est coupé ou en erreur.
 *
 * Disposition sur disque : filesDir/plugins/<id>/<version>/{plugin.json, classes.dex, assets/, lib/<abi>/}.
 */
object EmbeddedPlugins {
    const val MAX_TOTAL_BYTES = 150L * 1024 * 1024
    private const val MAX_ENTRIES = 3000

    val entries = mutableStateListOf<EmbeddedEntry>()
    var draft by mutableStateOf<EmbeddedDraft?>(null)

    private val lock = Any()

    // ───────────── Emplacements ─────────────

    fun root(ctx: Context) = File(ctx.filesDir, "plugins")
    fun versionDir(ctx: Context, id: String, version: String) = File(File(root(ctx), id), version)
    private fun registryFile(ctx: Context) = File(ctx.filesDir, "plugins.v2.json")
    private fun stageRoot(ctx: Context) = File(ctx.cacheDir, "plugins-v2")
    fun prefsName(id: String) = "plugin_$id"
    fun prefs(ctx: Context, id: String): SharedPreferences = ctx.getSharedPreferences(prefsName(id), Context.MODE_PRIVATE)

    // ───────────── Registre ─────────────

    private class Reg(val id: String, val version: String, val enabled: Boolean, val permissions: List<String>)

    private fun readRegistry(ctx: Context): List<Reg> = runCatching {
        val a = JSONArray(registryFile(ctx).readText())
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Reg(
                o.getString("id"), o.getString("version"), o.optBoolean("enabled", true),
                o.optJSONArray("permissions")?.let { p -> (0 until p.length()).map(p::getString) }.orEmpty(),
            )
        }
    }.getOrDefault(emptyList())

    private fun writeRegistry(ctx: Context, list: List<Reg>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("id", it.id).put("version", it.version).put("enabled", it.enabled).put("permissions", JSONArray(it.permissions))) }
        val tmp = File(ctx.filesDir, "plugins.v2.json.tmp")
        tmp.writeText(a.toString())
        if (!tmp.renameTo(registryFile(ctx))) { registryFile(ctx).writeText(a.toString()); tmp.delete() }
    }

    /** Relit le registre et les plugin.json. À appeler au démarrage et après toute modification. */
    fun load(ctx: Context) { synchronized(lock) { loadLocked(ctx) } }

    private fun loadLocked(ctx: Context) {
        val list = readRegistry(ctx).map { r ->
            val f = File(versionDir(ctx, r.id, r.version), "plugin.json")
            val m = runCatching { PluginManifestParser.parse(f.readText()) }.getOrElse { e ->
                PluginLoader.markError(r.id, "plugin.json illisible : ${e.message}")
                PluginManifest.placeholder(r.id, r.version)
            }
            EmbeddedEntry(m, r.enabled, r.permissions)
        }
        entries.clear(); entries.addAll(list)
    }

    fun find(id: String): EmbeddedEntry? = entries.firstOrNull { it.id == id }

    /** Plugins actifs et sains. */
    fun active(): List<EmbeddedEntry> = entries.filter { it.enabled && PluginLoader.errorOf(it.id) == null }

    /** Nom du plugin actif qui remplace ce pont (id de Bridge), sinon null. */
    fun replacedBy(bridgeId: String): String? = active().firstOrNull { it.manifest.replacesBridge == bridgeId }?.manifest?.name

    /** Pour chaque plugin actif : ses actions qui correspondent à la sélection. */
    fun matching(files: List<File>): List<Pair<EmbeddedEntry, List<ManifestAction>>> {
        if (files.isEmpty()) return emptyList()
        val cands = files.map { candidate(it) }
        return active().mapNotNull { e ->
            if ("storage" !in e.manifest.permissions) null // sans « storage » le plugin ne pourrait lire aucun fichier
            else e.manifest.actions.filter { PluginMatcher.matches(it, cands) }.takeIf { it.isNotEmpty() }?.let { e to it }
        }
    }

    fun mimeOf(f: File): String? = MimeTypeMap.getSingleton().getMimeTypeFromExtension(PluginMatcher.extensionOf(f.name))
    fun candidate(f: File) = Candidate(f.name, mimeOf(f))

    // ───────────── Interrupteur, réglages ─────────────

    fun setEnabled(ctx: Context, id: String, on: Boolean) { synchronized(lock) {
        writeRegistry(ctx, readRegistry(ctx).map { if (it.id == id) Reg(it.id, it.version, on, it.permissions) else it })
        load(ctx)
    } }

    /** Valeurs actuelles des réglages (prefs du plugin, sinon valeur par défaut), en texte. */
    fun readSettings(ctx: Context, m: PluginManifest): Map<String, String> {
        val all = prefs(ctx, m.id).all
        return m.settings.associate { p ->
            val v = all[p.key]
            p.key to when {
                v == null -> p.default
                p.type == "float" && v is Number -> PluginManifestParser.trimNumber(v.toDouble())
                else -> v.toString()
            }
        }
    }

    /** Écrit les réglages avec leur vrai type : int → Int, float → Float, bool → Boolean, choice / text → String. */
    fun writeSettings(ctx: Context, m: PluginManifest, values: Map<String, String>) {
        val ed = prefs(ctx, m.id).edit()
        m.settings.forEach { p ->
            val v = values[p.key] ?: p.default
            when (p.type) {
                "int" -> ed.putInt(p.key, (v.toDoubleOrNull() ?: p.default.toDouble()).coerceIn(p.min!!, p.max!!).toInt())
                "float" -> ed.putFloat(p.key, (v.toDoubleOrNull() ?: p.default.toDouble()).coerceIn(p.min!!, p.max!!).toFloat())
                "bool" -> ed.putBoolean(p.key, v.equals("true", true))
                "choice" -> ed.putString(p.key, if (v in p.choices) v else p.default)
                else -> ed.putString(p.key, v.take(500))
            }
        }
        ed.apply()
    }

    // ───────────── Analyse (étape « carte de configuration ») ─────────────

    fun clearDraft(ctx: Context? = null) {
        draft = null
        ctx?.let { runCatching { stageRoot(it).deleteRecursively() } }
    }

    /**
     * Analyse un .lsplugin v2 : lit plugin.json, extrait chaque fichier autorisé dans un dossier de préparation en
     * vérifiant son SHA-256, sans rien exécuter. @return null si valide (draft rempli), sinon le message d'erreur.
     */
    fun inspectZip(ctx: Context, file: File): String? {
        PluginManager.draft = null
        draft = null
        val stage = File(stageRoot(ctx), "stage")
        try {
            stageRoot(ctx).deleteRecursively(); stage.mkdirs()
            ZipFile(file).use { z ->
                val all = z.entries().toList()
                if (all.size > MAX_ENTRIES) return "Plugin invalide : trop de fichiers"
                val me = z.getEntry("plugin.json") ?: return "plugin.json absent"
                val jsonBytes = z.getInputStream(me).use { readBounded(it, PluginManifestParser.MAX_JSON_BYTES) } ?: return "plugin.json trop volumineux"
                val m = try { PluginManifestParser.parse(String(jsonBytes, Charsets.UTF_8)) } catch (e: ManifestException) { return e.message }

                val seen = HashSet<String>()
                var total = 0L
                val stageCanon = stage.canonicalPath + File.separator
                for (e in all) {
                    if (e.isDirectory || e.name == "plugin.json") continue
                    val n = e.name
                    if (!PluginPaths.isAllowedEntry(n)) return "Fichier non autorisé dans le plugin : $n"
                    if (!seen.add(n)) return "Fichier en double dans le plugin : $n"
                    val want = m.sha256[n] ?: return "Empreinte SHA-256 manquante dans plugin.json pour $n"
                    val dest = File(stage, n)
                    if (!dest.canonicalPath.startsWith(stageCanon)) return "Chemin invalide : $n"
                    dest.parentFile?.mkdirs()
                    val md = MessageDigest.getInstance("SHA-256")
                    z.getInputStream(e).use { i ->
                        dest.outputStream().use { o ->
                            val buf = ByteArray(64 * 1024)
                            while (true) {
                                val r = i.read(buf); if (r < 0) break
                                total += r
                                if (total > MAX_TOTAL_BYTES) return "Plugin trop volumineux (max ${MAX_TOTAL_BYTES / 1024 / 1024} Mo décompressé)"
                                md.update(buf, 0, r); o.write(buf, 0, r)
                            }
                        }
                    }
                    if (hex(md.digest()) != want) return "Empreinte SHA-256 différente pour $n : plugin corrompu ou modifié"
                }
                (m.sha256.keys - seen).firstOrNull()?.let { return "Fichier annoncé mais absent du plugin : $it" }
                if (File(stage, "lib").isDirectory && Build.SUPPORTED_ABIS.none { File(stage, "lib/$it").isDirectory })
                    return "Ce plugin n'a pas de bibliothèque native pour ce téléphone (${Build.SUPPORTED_ABIS.joinToString()})"
                File(stage, "plugin.json").writeBytes(jsonBytes)

                val existing = find(m.id)
                if (existing != null && PluginMatcher.compareVersions(m.version, existing.manifest.version) < 0)
                    return "Une version plus récente (${existing.manifest.version}) est déjà installée"
                draft = EmbeddedDraft(m, stage, total, existing)
            }
            if (file.path.startsWith(ctx.cacheDir.path)) runCatching { file.delete() } // la copie téléversée ne sert plus
            return null
        } catch (e: Exception) {
            runCatching { stageRoot(ctx).deleteRecursively() }
            return "Plugin invalide : " + (e.message ?: e.javaClass.simpleName)
        }
    }

    // ───────────── Installation, suppression ─────────────

    /** « Valider et installer » (la confirmation des permissions a déjà été faite par l'écran). @return message d'erreur ou null. */
    fun install(ctx: Context, d: EmbeddedDraft): String? = synchronized(lock) { installLocked(ctx, d) }

    private fun installLocked(ctx: Context, d: EmbeddedDraft): String? {
        val m = d.manifest
        if (PluginRunner.isRunning(m.id)) return "Ce plugin est en cours d'exécution : attends la fin avant de le mettre à jour"
        try {
            val idDir = File(root(ctx), m.id).apply { mkdirs() }
            val target = File(idDir, m.version)
            PluginLoader.unload(m.id)
            if (target.exists() && !target.deleteRecursively()) return "Impossible de remplacer la version installée"
            if (!d.stageDir.renameTo(target)) {
                d.stageDir.copyRecursively(target, overwrite = true)
                d.stageDir.deleteRecursively()
            }
            lockDown(target)
            val prev = readRegistry(ctx)
            val enabled = prev.firstOrNull { it.id == m.id }?.enabled ?: true
            writeRegistry(ctx, prev.filterNot { it.id == m.id } + Reg(m.id, m.version, enabled, m.permissions))
            idDir.listFiles()?.filter { it.name != m.version }?.forEach { it.deleteRecursively() } // anciennes versions
            PluginLoader.clearError(m.id)
            draft = null
            runCatching { stageRoot(ctx).deleteRecursively() }
            load(ctx)
            return null
        } catch (e: Exception) {
            return "Installation impossible : " + (e.message ?: e.javaClass.simpleName)
        }
    }

    /** classes.dex DOIT être en lecture seule (Android 14 refuse de charger un dex modifiable) ; on protège tout le reste aussi. */
    private fun lockDown(dir: File) {
        dir.walkTopDown().filter { it.isFile }.forEach { it.setReadOnly() }
    }

    /** Supprime le plugin : dossier, préférences et entrée du registre. @return message d'erreur ou null. */
    fun remove(ctx: Context, id: String): String? = synchronized(lock) { removeLocked(ctx, id) }

    private fun removeLocked(ctx: Context, id: String): String? {
        if (PluginRunner.isRunning(id)) return "Ce plugin est en cours d'exécution"
        PluginLoader.unload(id); PluginLoader.clearError(id)
        val dir = File(root(ctx), id)
        if (dir.exists() && !dir.deleteRecursively()) return "Suppression incomplète du dossier du plugin"
        ctx.deleteSharedPreferences(prefsName(id))
        writeRegistry(ctx, readRegistry(ctx).filterNot { it.id == id })
        load(ctx)
        return null
    }

    // ───────────── Utilitaires ─────────────

    private fun readBounded(i: InputStream, max: Int): ByteArray? {
        val out = java.io.ByteArrayOutputStream()
        val buf = ByteArray(8192)
        while (true) {
            val r = i.read(buf); if (r < 0) break
            if (out.size() + r > max) return null
            out.write(buf, 0, r)
        }
        return out.toByteArray()
    }

    fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }

    fun sha256(f: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        f.inputStream().use { i -> val b = ByteArray(64 * 1024); while (true) { val n = i.read(b); if (n < 0) break; md.update(b, 0, n) } }
        return hex(md.digest())
    }
}
