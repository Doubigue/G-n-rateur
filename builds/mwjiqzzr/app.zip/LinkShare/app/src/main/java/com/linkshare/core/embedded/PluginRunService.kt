package com.linkshare.core.embedded

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.linkshare.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Service de premier plan (dataSync) qui exécute l'action d'un plugin intégré, avec une notification de progression
 * et un bouton « Annuler ». Le travail du plugin tourne sur Dispatchers.IO.
 */
class PluginRunService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var started = false
    private var lastNotify = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL) { PluginRunner.cancel(); return START_NOT_STICKY }
        val job = PluginRunner.current
        if (job == null || started) {
            if (!started) { // démarré sans travail : on doit tout de même passer au premier plan puis s'arrêter
                startFg(buildNotification("LinkShare", "", -1, false))
                stopSelf()
            }
            return START_NOT_STICKY
        }
        started = true
        startFg(buildNotification(job.pluginName, job.actionLabel, -1, true))
        val co = scope.launch(Dispatchers.IO) {
            val result = PluginRunner.execute(this@PluginRunService, job) { pct, text -> progress(job, pct, text) }
            PluginRunner.finished = result
            PluginRunner.clear()
            ServiceCompat.stopForeground(this@PluginRunService, ServiceCompat.STOP_FOREGROUND_REMOVE)
            notifyDone(job, result)
            stopSelf()
        }
        job.coroutine = co
        if (job.cancelled) co.cancel()
        return START_NOT_STICKY
    }

    /** Android 15 : limite de durée des services dataSync. On annule proprement. */
    override fun onTimeout(startId: Int, fgsType: Int) {
        PluginRunner.cancel()
    }

    override fun onDestroy() {
        scope.cancel()
        if (PluginRunner.current != null) PluginRunner.clear()
        super.onDestroy()
    }

    private fun startFg(n: Notification) {
        ensureChannel(this)
        ServiceCompat.startForeground(this, NOTIF_RUN, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
    }

    private fun progress(job: PluginJob, pct: Int, text: String) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastNotify < 400 && pct < 100) return
        lastNotify = now
        getSystemService(NotificationManager::class.java).notify(NOTIF_RUN, buildNotification(job.pluginName, text.ifBlank { job.actionLabel }, pct, true))
    }

    private fun buildNotification(title: String, text: String, percent: Int, cancellable: Boolean): Notification {
        val open = packageManager.getLaunchIntentForPackage(packageName)?.let {
            PendingIntent.getActivity(this, 0, it, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        }
        val b = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_logo).setContentTitle(title).setContentText(text)
            .setOngoing(true).setOnlyAlertOnce(true).setContentIntent(open)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setProgress(100, percent.coerceAtLeast(0), percent < 0)
        if (cancellable) {
            val cancel = PendingIntent.getService(
                this, 1, Intent(this, PluginRunService::class.java).setAction(ACTION_CANCEL),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
            b.addAction(0, "Annuler", cancel)
        }
        return b.build()
    }

    private fun notifyDone(job: PluginJob, r: PluginFinished) {
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_logo).setContentTitle(job.pluginName).setContentText(r.message)
            .setAutoCancel(true)
            .setContentIntent(packageManager.getLaunchIntentForPackage(packageName)?.let {
                PendingIntent.getActivity(this, 0, it, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            })
            .build()
        getSystemService(NotificationManager::class.java).notify(NOTIF_DONE, n)
    }

    companion object {
        const val CHANNEL = "plugin_run"
        const val ACTION_CANCEL = "com.linkshare.plugin.CANCEL"
        private const val NOTIF_RUN = 4601
        private const val NOTIF_DONE = 4602

        fun ensureChannel(ctx: Context) {
            ctx.getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL, "Plugins", NotificationManager.IMPORTANCE_LOW).apply { setShowBadge(false) },
            )
        }
    }
}
