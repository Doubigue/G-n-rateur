package com.linkshare.ui

import android.text.format.Formatter
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linkshare.core.Bridge
import com.linkshare.core.PluginManager
import com.linkshare.core.embedded.EmbeddedEntry
import com.linkshare.core.embedded.EmbeddedPlugins
import com.linkshare.core.embedded.ManifestAction
import com.linkshare.core.embedded.ManifestParam
import com.linkshare.core.embedded.PluginLoader
import com.linkshare.core.embedded.PluginManifest
import com.linkshare.core.embedded.PluginManifestParser
import com.linkshare.core.embedded.PluginRunner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

// ═══════════════════════════ Textes de sécurité ═══════════════════════════

internal const val PLUGIN_SECURITY_NOTE =
    "Le code d'un plugin intégré s'exécute dans LinkShare, avec les mêmes droits que LinkShare (fichiers, réseau…). " +
        "N'installe que des plugins dont tu fais confiance à la source. Les permissions ci-dessous sont celles que le " +
        "plugin annonce : elles ne l'empêchent pas techniquement d'agir autrement."

private fun permLabel(p: String) = when (p) {
    "storage" -> "Stockage : lire les fichiers que tu choisis et écrire les résultats à côté"
    "notifications" -> "Notifications : afficher des notifications"
    "network" -> "Réseau : accéder à Internet"
    else -> p
}

private fun permShort(list: List<String>) =
    if (list.isEmpty()) "Aucune permission" else "Permissions : " + list.joinToString(" · ") {
        when (it) { "storage" -> "stockage"; "notifications" -> "notifications"; "network" -> "réseau"; else -> it }
    }

private fun acceptsText(a: ManifestAction): String {
    val types = if (a.accepts.isEmpty()) "tous les fichiers" else a.accepts.joinToString(", ")
    val n = when {
        a.maxFiles == Int.MAX_VALUE -> "${a.minFiles} fichier(s) ou plus"
        a.minFiles == a.maxFiles -> "${a.minFiles} fichier(s)"
        else -> "${a.minFiles} à ${a.maxFiles} fichiers"
    }
    return "$types · $n"
}

// ═══════════════════════════ Fin d'exécution (à composer une fois, à côté de ExtraitHost) ═══════════════════════════

/** Affiche « Terminé : nom » et recharge l'explorateur quand une action de plugin se termine (même si l'appli était en arrière-plan). */
@Composable
internal fun PluginRunHost(ex: ExplorerViewModel) {
    val f = PluginRunner.finished
    LaunchedEffect(f) {
        if (f == null) return@LaunchedEffect
        ex.message = f.message
        if (f.outputs.isNotEmpty() || f.ok) ex.refresh()
        PluginRunner.finished = null
    }
}

// ═══════════════════════════ Écran « Action » : une carte par plugin actif ═══════════════════════════

/** Une carte par plugin actif dont au moins une action correspond à la sélection (comme StudioPanel). */
@Composable
internal fun PluginActionsPanel(ex: ExplorerViewModel, files: List<File>, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var pending by remember { mutableStateOf<Pair<EmbeddedEntry, ManifestAction>?>(null) }
    // Jamais pour un dossier ni pour un fichier du coffre
    if (files.isEmpty() || files.any { it.isDirectory || ex.inVault(it) }) return
    val groups = EmbeddedPlugins.matching(files)
    if (groups.isEmpty()) return

    fun launch(e: EmbeddedEntry, a: ManifestAction, params: Map<String, String>) {
        val err = PluginRunner.start(ctx, e, a, files, params, ex.vaultDir)
        if (err != null) { ex.message = err; return }
        onClose()
        ex.selected.clear()
        ex.message = "« ${a.label} » lancé : la progression est dans la notification"
    }

    groups.forEach { (e, actions) ->
        Column(
            Modifier.fillMaxWidth().lsCard(RoundedCornerShape(UiStyle.r(20.dp))).padding(horizontal = 12.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(Modifier.padding(start = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Ic.Apps, null, Modifier.size(18.dp), tint = LS.Green)
                Spacer(Modifier.width(8.dp))
                Text(e.manifest.name, Modifier.weight(1f), color = LS.Green, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("Plugin · ${e.manifest.version}", color = LS.Muted, fontSize = 11.sp)
            }
            actions.forEach { a ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(UiStyle.r(14.dp))).background(LS.Card2)
                        .clickable { if (a.params.isEmpty()) launch(e, a, emptyMap()) else pending = e to a }
                        .padding(horizontal = 12.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(a.icon.ifBlank { "🧩" }, fontSize = 20.sp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(a.label, color = LS.Text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                        if (a.params.isNotEmpty()) Text("Réglages avant l'exécution", color = LS.Muted, fontSize = 11.sp)
                    }
                    Icon(Ic.Chevron, null, Modifier.size(18.dp), tint = LS.Muted)
                }
            }
        }
    }

    pending?.let { (e, a) ->
        ParamsDialog(
            title = a.label, params = a.params, initial = emptyMap(), confirmLabel = "Lancer",
            onDismiss = { pending = null },
        ) { values -> pending = null; launch(e, a, values) }
    }
}

// ═══════════════════════════ Boîte de dialogue générée depuis un schéma ═══════════════════════════

/** Curseur (int / float), interrupteur (bool), choix (choice) ou texte (text), générés depuis [params]. */
@Composable
internal fun ParamsDialog(
    title: String, params: List<ManifestParam>, initial: Map<String, String>, confirmLabel: String,
    onDismiss: () -> Unit, onConfirm: (Map<String, String>) -> Unit,
) {
    val values = remember {
        mutableStateMapOf<String, String>().apply { params.forEach { put(it.key, initial[it.key] ?: it.default) } }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                params.forEach { p -> ParamField(p, values[p.key] ?: p.default) { values[p.key] = it } }
            }
        },
        confirmButton = { TextButton({ onConfirm(params.associate { it.key to (values[it.key] ?: it.default) }) }) { Text(confirmLabel) } },
        dismissButton = { TextButton(onDismiss) { Text("Annuler") } },
    )
}

@Composable
private fun ParamField(p: ManifestParam, value: String, onChange: (String) -> Unit) {
    when (p.type) {
        "bool" -> Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(p.label, Modifier.weight(1f), color = LS.Text, fontSize = 14.sp)
            Switch(
                value == "true", { onChange(it.toString()) },
                colors = SwitchDefaults.colors(checkedThumbColor = LS.OnBlue, checkedTrackColor = LS.Blue),
            )
        }
        "int", "float" -> {
            val lo = p.min ?: 0.0
            val hi = p.max ?: 100.0
            val v = (value.toDoubleOrNull() ?: lo).coerceIn(lo, hi)
            val isInt = p.type == "int"
            Column {
                Text("${p.label} : ${if (isInt) Math.round(v).toString() else PluginManifestParser.trimNumber(Math.round(v * 100.0) / 100.0)}", color = LS.Text, fontSize = 14.sp)
                Slider(
                    value = v.toFloat(),
                    onValueChange = { onChange(if (isInt) Math.round(it).toString() else PluginManifestParser.trimNumber(Math.round(it * 100.0) / 100.0)) },
                    valueRange = lo.toFloat()..hi.toFloat(),
                    steps = if (isInt && hi - lo in 2.0..100.0) (hi - lo).toInt() - 1 else 0,
                    colors = SliderDefaults.colors(thumbColor = LS.Blue, activeTrackColor = LS.Blue),
                )
            }
        }
        "choice" -> Column {
            Text(p.label, color = LS.Text, fontSize = 14.sp)
            p.choices.forEach { c ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable { onChange(c) },
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    RadioButton(value == c, { onChange(c) }, colors = RadioButtonDefaults.colors(selectedColor = LS.Blue))
                    Text(c, color = LS.Text, fontSize = 14.sp)
                }
            }
        }
        else -> OutlinedTextField(value, onChange, Modifier.fillMaxWidth(), singleLine = true, label = { Text(p.label) })
    }
}

// ═══════════════════════════ Paramètres › Install plugins : plugins intégrés ═══════════════════════════

internal fun LazyListScope.embeddedPluginItems() {
    item { EmbeddedDraftCard() }
    item { EmbeddedPluginsCard() }
}

/** Carte de configuration d'un .lsplugin v2 analysé : actions, réglages, permissions, empreintes, puis « Valider et installer ». */
@Composable
private fun EmbeddedDraftCard() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val d = EmbeddedPlugins.draft
    var confirm by remember(d) { mutableStateOf(false) }
    if (d == null) return
    val m = d.manifest

    fun doInstall() {
        scope.launch {
            PluginManager.busy = true; PluginManager.status = "Installation…"
            val err = withContext(Dispatchers.IO) { EmbeddedPlugins.install(ctx, d) }
            PluginManager.busy = false
            PluginManager.status = err ?: "« ${m.name} » installé et activé"
            if (err == null) {
                val e = EmbeddedPlugins.find(m.id)
                val loadErr = if (e != null) withContext(Dispatchers.IO) { PluginLoader.check(ctx, e) } else null
                if (loadErr != null) PluginManager.status = "« ${m.name} » installé mais en erreur : $loadErr"
            }
        }
    }

    Column(
        Modifier.fillMaxWidth().lsCard(RoundedCornerShape(UiStyle.r(22.dp))).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Text("Configuration du plugin intégré", color = LS.Blue, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        Text("${m.name} · ${m.version}", color = LS.Text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        if (m.description.isNotBlank()) Text(m.description, color = LS.Text.copy(alpha = 0.85f), fontSize = 13.sp)
        Text("Identifiant : ${m.id} · contrat ${m.contract}", color = LS.Muted, fontSize = 12.sp)
        Text("Taille : " + Formatter.formatShortFileSize(ctx, d.sizeBytes), color = LS.Muted, fontSize = 12.sp)
        d.existing?.let { Text("Mise à jour : ${it.manifest.version} → ${m.version}", color = LS.Blue, fontSize = 12.sp) }

        Text("Actions", color = LS.Text, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 6.dp))
        m.actions.forEach { a ->
            Text("${a.icon.ifBlank { "🧩" }} ${a.label} — ${acceptsText(a)}", color = LS.Muted, fontSize = 12.sp)
        }
        if (m.settings.isNotEmpty()) {
            Text("Réglages", color = LS.Text, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 6.dp))
            Text(m.settings.joinToString(" · ") { it.label }, color = LS.Muted, fontSize = 12.sp)
        }
        Text("Permissions demandées", color = LS.Text, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 6.dp))
        if (m.permissions.isEmpty()) Text("Aucune", color = LS.Muted, fontSize = 12.sp)
        m.permissions.forEach { p ->
            val isNew = d.isUpdate && p in d.addedPermissions
            Text("• " + permLabel(p) + if (isNew) "  (nouvelle)" else "", color = if (isNew) LS.Amber else LS.Muted, fontSize = 12.sp)
        }
        m.replacesBridge?.let { id ->
            val title = Bridge.values().firstOrNull { it.id == id }?.title ?: id
            Text("Remplace le pont « $title » : il sera masqué tant que ce plugin est actif", color = LS.Muted, fontSize = 12.sp)
        }
        Text("Empreintes SHA-256 vérifiées ✓ (${m.sha256.size} fichier(s))", color = LS.Green, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
        Text(PLUGIN_SECURITY_NOTE, color = LS.Amber, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
        Spacer(Modifier.height(4.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                { if (d.needsConfirmation) confirm = true else doInstall() },
                Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = LS.Blue, contentColor = LS.OnBlue),
            ) { Text("Valider et installer", fontWeight = FontWeight.SemiBold, maxLines = 1) }
            OutlinedButton({ EmbeddedPlugins.clearDraft(ctx); PluginManager.status = null }) { Text("Annuler", color = LS.Blue) }
        }
    }

    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text(if (d.isUpdate) "Les permissions changent" else "Autoriser ce plugin ?") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(PLUGIN_SECURITY_NOTE)
                if (m.permissions.isEmpty()) Text("Ce plugin ne demande aucune permission.")
                m.permissions.forEach { Text("• " + permLabel(it)) }
            }
        },
        confirmButton = { TextButton({ confirm = false; doInstall() }) { Text("Autoriser et installer") } },
        dismissButton = { TextButton({ confirm = false }) { Text("Annuler") } },
    )
}

/** Plugins intégrés installés : interrupteur Activer, Réglages, permissions, suppression. */
@Composable
private fun EmbeddedPluginsCard() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val list = EmbeddedPlugins.entries
    var confirmDelete by remember { mutableStateOf<EmbeddedEntry?>(null) }
    var settingsFor by remember { mutableStateOf<EmbeddedEntry?>(null) }

    Column(
        Modifier.fillMaxWidth().lsCard(RoundedCornerShape(UiStyle.r(22.dp))).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text("Plugins intégrés (${list.size})", color = LS.Blue, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        Text(PLUGIN_SECURITY_NOTE, color = LS.Muted, fontSize = 12.sp)
        if (list.isEmpty()) Text("Aucun plugin intégré pour l'instant", color = LS.Muted, fontSize = 13.sp)
        list.forEach { e ->
            val m = e.manifest
            val err = PluginLoader.errorOf(e.id)
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(UiStyle.r(16.dp))).background(LS.Card2).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(40.dp).clip(CircleShape).background(LS.Card), contentAlignment = Alignment.Center) {
                        Icon(Ic.Apps, null, Modifier.size(20.dp), tint = if (err != null) LS.Red else if (e.enabled) LS.Green else LS.Muted)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(m.name, color = LS.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            "Version ${m.version} · " + when { err != null -> "en erreur"; e.enabled -> "actif"; else -> "désactivé" },
                            color = if (err != null) LS.Red else LS.Muted, fontSize = 12.sp, maxLines = 1,
                        )
                    }
                    Switch(
                        e.enabled,
                        { on ->
                            scope.launch {
                                EmbeddedPlugins.setEnabled(ctx, e.id, on)
                                if (!on) PluginLoader.unload(e.id)
                                else EmbeddedPlugins.find(e.id)?.let { cur -> withContext(Dispatchers.IO) { PluginLoader.check(ctx, cur) } }
                            }
                        },
                        colors = SwitchDefaults.colors(checkedThumbColor = LS.OnBlue, checkedTrackColor = LS.Blue),
                    )
                }
                if (err != null) Text(err, color = LS.Red, fontSize = 12.sp)
                if (m.description.isNotBlank()) Text(m.description, color = LS.Text.copy(alpha = 0.85f), fontSize = 12.sp)
                Text(permShort(m.permissions), color = LS.Muted, fontSize = 12.sp)
                if (m.actions.isNotEmpty()) Text("Actions : " + m.actions.joinToString(" · ") { it.label }, color = LS.Muted, fontSize = 12.sp)
                m.replacesBridge?.let { id ->
                    val title = Bridge.values().firstOrNull { it.id == id }?.title ?: id
                    Text("Masque le pont « $title » tant qu'il est actif", color = LS.Muted, fontSize = 12.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (m.settings.isNotEmpty()) OutlinedButton({ settingsFor = e }) { Text("Réglages", color = LS.Blue) }
                    if (err != null) OutlinedButton({
                        scope.launch {
                            PluginLoader.clearError(e.id)
                            val msg = withContext(Dispatchers.IO) {
                                EmbeddedPlugins.load(ctx)
                                EmbeddedPlugins.find(e.id)?.let { PluginLoader.check(ctx, it) }
                            }
                            if (msg == null) Toast.makeText(ctx, "Plugin relancé", Toast.LENGTH_SHORT).show()
                        }
                    }) { Text("Réessayer", color = LS.Blue) }
                    Spacer(Modifier.weight(1f))
                    Icon(
                        Ic.Delete, "Supprimer le plugin",
                        Modifier.clip(CircleShape).clickable { confirmDelete = e }.padding(8.dp).size(20.dp), tint = LS.Muted,
                    )
                }
            }
        }
    }

    confirmDelete?.let { e ->
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text("Supprimer ${e.manifest.name} ?") },
            text = { Text("Le dossier du plugin et ses réglages seront effacés. Les fichiers qu'il a déjà produits restent où ils sont.") },
            confirmButton = {
                TextButton({
                    confirmDelete = null
                    val err = EmbeddedPlugins.remove(ctx, e.id)
                    Toast.makeText(ctx, err ?: "Plugin supprimé", Toast.LENGTH_SHORT).show()
                }) { Text("Supprimer") }
            },
            dismissButton = { TextButton({ confirmDelete = null }) { Text("Annuler") } },
        )
    }

    settingsFor?.let { e ->
        val m: PluginManifest = e.manifest
        ParamsDialog(
            title = "Réglages · ${m.name}", params = m.settings, initial = EmbeddedPlugins.readSettings(ctx, m),
            confirmLabel = "Enregistrer", onDismiss = { settingsFor = null },
        ) { values ->
            settingsFor = null
            EmbeddedPlugins.writeSettings(ctx, m, values)
            Toast.makeText(ctx, "Réglages enregistrés", Toast.LENGTH_SHORT).show()
        }
    }
}
