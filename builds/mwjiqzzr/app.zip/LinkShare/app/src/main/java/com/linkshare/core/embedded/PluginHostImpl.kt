package com.linkshare.core.embedded

import android.content.Context
import android.content.SharedPreferences
import android.webkit.MimeTypeMap
import com.linkshare.plugin.api.PluginHost
import com.linkshare.plugin.api.PluginInput
import java.io.File
import java.io.FileInputStream
import java.io.FileNotFoundException
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream

/**
 * Ce que le plugin voit de LinkShare pendant une action.
 *  - openInput : UNIQUEMENT les fichiers choisis par l'utilisateur pour cette action (jamais ceux du coffre) ;
 *  - createOutput : un nouveau fichier à côté du fichier source, sans jamais en écraser un existant ;
 *  - openAsset : les fichiers assets/ du plugin lui-même.
 * Sans la permission « storage », openInput et createOutput sont refusés.
 *
 * Limite à connaître (voir README) : c'est une barrière d'API, pas un bac à sable. Le code du plugin tourne dans le
 * processus de LinkShare avec ses droits, et pourrait en théorie ouvrir des fichiers par ses propres moyens.
 */
internal class PluginHostImpl(
    override val context: Context,
    override val prefs: SharedPreferences,
    private val assetsDir: File,
    private val storageAllowed: Boolean,
    private val inputs: Map<String, File>,
    private val outputDir: File,
    private val onProgress: (Int, String) -> Unit,
    private val cancelled: () -> Boolean,
) : PluginHost {

    private val created = java.util.Collections.synchronizedList(mutableListOf<File>())

    /** Fichiers réellement créés (noms uniques). */
    fun createdFiles(): List<File> = synchronized(created) { created.toList() }

    private fun needStorage() { if (!storageAllowed) throw SecurityException("Permission « storage » non déclarée par ce plugin") }

    override fun openAsset(path: String): InputStream {
        if (!PluginPaths.isSafeName(path)) throw FileNotFoundException("Chemin d'asset invalide : $path")
        val f = File(assetsDir, path)
        if (!f.canonicalPath.startsWith(assetsDir.canonicalPath + File.separator) || !f.isFile) throw FileNotFoundException("Asset introuvable : $path")
        return FileInputStream(f).buffered()
    }

    override fun openInput(i: PluginInput): InputStream {
        needStorage()
        val f = inputs[i.uri] ?: throw SecurityException("Ce fichier n'a pas été choisi pour cette action")
        if (!f.isFile) throw FileNotFoundException(f.name)
        return FileInputStream(f).buffered()
    }

    override fun createOutput(name: String, mime: String): OutputStream {
        needStorage()
        var clean = PluginMatcher.sanitizeName(name)
        if (!clean.substringAfterLast('.', "").let { it.isNotEmpty() && clean.contains('.') }) {
            MimeTypeMap.getSingleton().getExtensionFromMimeType(mime.substringBefore(';').trim().lowercase())?.let { clean += ".$it" }
        }
        if (!outputDir.isDirectory || !outputDir.canWrite()) throw IOException("Dossier de destination non modifiable : ${outputDir.name}")
        // createNewFile est atomique : jamais d'écrasement, même si deux sorties portent le même nom
        var target = File(outputDir, PluginMatcher.uniqueName(clean) { File(outputDir, it).exists() })
        var tries = 0
        while (!target.createNewFile()) {
            if (++tries > 50) throw IOException("Impossible de créer le fichier de sortie")
            target = File(outputDir, PluginMatcher.uniqueName(clean) { File(outputDir, it).exists() })
        }
        created += target
        return FileOutputStream(target).buffered()
    }

    override fun progress(percent: Int, text: String) = onProgress(percent.coerceIn(0, 100), text.take(120))

    override fun isCancelled(): Boolean = cancelled()
}
