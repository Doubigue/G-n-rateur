package com.linkshare.core

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.FileProvider
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.zip.ZipFile

/** Fiche d'un plugin (lue dans plugin.json, ou déduite de l'APK). */
class PluginInfo(
    val id: String,
    val name: String,
    val version: String,
    val pkg: String,
    val description: String,
    val actions: List<String>,
    val contract: Int,
    val signer: String?,          // empreinte SHA-256 du certificat de l'APK
) {
    fun toJson() = JSONObject().put("id", id).put("name", name).put("version", version).put("package", pkg)
        .put("description", description).put("actions", JSONArray(actions)).put("contract", contract)
        .put("signer", signer ?: "")

    companion object {
        fun fromJson(o: JSONObject) = PluginInfo(
            id = o.getString("id"), name = o.optString("name", o.getString("id")), version = o.optString("version"),
            pkg = o.getString("package"), description = o.optString("description"),
            actions = o.optJSONArray("actions")?.let { a -> (0 until a.length()).map { a.optString(it) } } ?: emptyList(),
            contract = o.optInt("contract", 1), signer = o.optString("signer").ifBlank { null },
        )
    }
}

/** Plugin analysé et vérifié, prêt à être installé (« Valider »). */
class PluginDraft(val info: PluginInfo, val apk: File, val sizeBytes: Long, val sha256: String, val shaChecked: Boolean, val note: String?)

/** Ligne de la liste : un plugin enregistré et son état réel dans Android. */
class PluginEntry(val info: PluginInfo, val installed: Boolean, val installedVersion: String?)

/**
 * Plugins INSTALLÉS (contrat 1) de LinkShare = applis Android installées à part. (Les plugins intégrés, contrat 2, sont dans core/embedded.) LinkShare leur parle par Intents (voir MediaStudioBridge).
 *
 * Format accepté :
 *  - `.lsplugin` : un zip contenant `plugin.json` + l'APK (nom donné par le champ « apk ») ;
 *  - ou directement un `.apk` (la fiche est alors déduite de l'APK).
 *
 * plugin.json : {"id":"mediastudio","name":"Media Studio","version":"1.0","package":"com.mediastudio.app",
 *   "contract":1,"description":"…","actions":["MP3","Compression"],"apk":"MediaStudio.apk","sha256":"…"}
 *
 * Sécurité : taille limitée, aucun chemin du zip n'est utilisé pour écrire, empreinte SHA-256 contrôlée si elle est
 * fournie, package cohérent avec l'APK, jamais LinkShare lui-même, signature identique en cas de mise à jour.
 * L'installation et la suppression passent toujours par la fenêtre de confirmation d'Android.
 */
object PluginManager {
    const val SUPPORTED_CONTRACT = 1
    private const val MAX_BYTES = 400L * 1024 * 1024

    val entries = mutableStateListOf<PluginEntry>()
    var draft by mutableStateOf<PluginDraft?>(null)
    var busy by mutableStateOf(false)
    var progress by mutableStateOf<Float?>(null)
    var status by mutableStateOf<String?>(null)

    private val removing = mutableSetOf<String>()
    private fun registryFile(ctx: Context) = File(ctx.filesDir, "plugins.json")
    private fun stageDir(ctx: Context) = File(ctx.cacheDir, "plugins").apply { mkdirs() }

    // ───────────── Registre ─────────────

    private fun readRegistry(ctx: Context): List<PluginInfo> = runCatching {
        val a = JSONArray(registryFile(ctx).readText())
        (0 until a.length()).map { PluginInfo.fromJson(a.getJSONObject(it)) }
    }.getOrDefault(emptyList())

    private fun writeRegistry(ctx: Context, list: List<PluginInfo>) {
        val tmp = File(ctx.filesDir, "plugins.json.tmp")
        tmp.writeText(JSONArray(list.map { it.toJson() }).toString())
        tmp.renameTo(registryFile(ctx))
    }

    /** À appeler au chargement des paramètres et au retour dans l'appli (après une installation / suppression). */
    fun refresh(ctx: Context) {
        var list = readRegistry(ctx)
        val gone = list.filter { it.id in removing && versionOf(ctx, it.pkg) == null }
        if (gone.isNotEmpty()) {
            list = list.filterNot { p -> gone.any { it.id == p.id } }
            removing.removeAll(gone.map { it.id }.toSet())
            writeRegistry(ctx, list)
        }
        entries.clear()
        entries.addAll(list.map { PluginEntry(it, versionOf(ctx, it.pkg) != null, versionOf(ctx, it.pkg)) })
    }

    private fun versionOf(ctx: Context, pkg: String): String? = try {
        ctx.packageManager.getPackageInfo(pkg, 0).versionName ?: "?"
    } catch (_: PackageManager.NameNotFoundException) { null }

    // ───────────── Analyse et validation ─────────────

    /** Fichier choisi dans le sélecteur d'Android. */
    fun inspect(ctx: Context, uri: Uri): String? {
        val dir = stageDir(ctx).apply { listFiles()?.forEach { it.delete() } }
        val src = File(dir, "import.bin")
        try {
            ctx.contentResolver.openInputStream(uri)?.use { input ->
                src.outputStream().use { out -> copyLimited(input, out) }
            } ?: return "Impossible de lire ce fichier"
        } catch (e: Exception) { src.delete(); return e.message ?: "Lecture impossible" }
        return inspectFile(ctx, src)
    }

    /** @return null si le plugin est valide (draft rempli), sinon le message d'erreur. */
    fun inspectFile(ctx: Context, file: File): String? {
        draft = null
        com.linkshare.core.embedded.EmbeddedPlugins.draft = null
        try {
            val zip = try { ZipFile(file) } catch (_: Exception) { return "Ce fichier n'est ni un .lsplugin ni un APK" }
            return zip.use { z ->
                val manifestEntry = z.getEntry("plugin.json")
                val apk: File
                var meta: JSONObject? = null
                if (manifestEntry != null) {
                    meta = JSONObject(z.getInputStream(manifestEntry).bufferedReader().use { it.readText().take(64 * 1024) })
                    // Contrat 2 = plugin intégré (code chargé dans LinkShare) : autre chemin, voir core/embedded
                    if (meta.optInt("contract", 1) == com.linkshare.core.embedded.PluginManifestParser.CONTRACT)
                        return com.linkshare.core.embedded.EmbeddedPlugins.inspectZip(ctx, file)
                    val apkName = meta.optString("apk", "plugin.apk")
                    if (apkName.contains('/') || apkName.contains('\\') || apkName.contains("..")) return "Nom d'APK invalide dans plugin.json"
                    val e = z.getEntry(apkName) ?: return "L'APK « $apkName » est absent du plugin"
                    if (e.size > MAX_BYTES) return "Plugin trop volumineux"
                    apk = File(stageDir(ctx), "plugin.apk")
                    z.getInputStream(e).use { i -> apk.outputStream().use { o -> copyLimited(i, o) } }
                } else if (z.getEntry("AndroidManifest.xml") != null) {
                    apk = File(stageDir(ctx), "plugin.apk")
                    if (file.canonicalPath != apk.canonicalPath) file.copyTo(apk, overwrite = true)
                } else return "Aucun plugin.json ni AndroidManifest.xml : ce n'est pas un plugin"

                val pm = ctx.packageManager
                @Suppress("DEPRECATION")
                val arch = pm.getPackageArchiveInfo(apk.path, PackageManager.GET_SIGNING_CERTIFICATES)
                    ?: return "L'APK du plugin est illisible ou invalide"
                if (arch.packageName == ctx.packageName) return "Un plugin ne peut pas remplacer LinkShare"
                val declaredPkg = meta?.optString("package").orEmpty()
                if (declaredPkg.isNotBlank() && declaredPkg != arch.packageName)
                    return "plugin.json annonce $declaredPkg mais l'APK est ${arch.packageName}"
                val contract = meta?.optInt("contract", 1) ?: 1
                if (contract > SUPPORTED_CONTRACT) return "Ce plugin demande une version plus récente de LinkShare (contrat $contract)"

                val sha = sha256(apk)
                val wanted = meta?.optString("sha256").orEmpty().lowercase()
                if (wanted.isNotBlank() && wanted != sha) return "Empreinte SHA-256 différente : le plugin est corrompu ou modifié"

                val signer = arch.signingInfo?.apkContentsSigners?.firstOrNull()?.let { digest(it.toByteArray()) }
                // Mise à jour : même signature, version plus récente
                val installed = try { pm.getPackageInfo(arch.packageName, PackageManager.GET_SIGNING_CERTIFICATES) } catch (_: PackageManager.NameNotFoundException) { null }
                var note: String? = null
                if (installed != null) {
                    val old = installed.signingInfo?.apkContentsSigners?.firstOrNull()?.let { digest(it.toByteArray()) }
                    if (old != null && signer != null && old != signer)
                        return "Signature différente de la version installée : désinstalle-la d'abord"
                    if (arch.longVersionCode < installed.longVersionCode) return "Une version plus récente est déjà installée"
                    note = if (arch.longVersionCode == installed.longVersionCode) "Déjà installé (même version) : réinstallation" else "Mise à jour de la version installée"
                }
                val label = runCatching {
                    arch.applicationInfo?.also { it.sourceDir = apk.path; it.publicSourceDir = apk.path }?.loadLabel(pm)?.toString()
                }.getOrNull()
                val info = PluginInfo(
                    id = (meta?.optString("id").orEmpty().ifBlank { arch.packageName }).take(64).replace(Regex("[^\\w.-]"), "_"),
                    name = meta?.optString("name").orEmpty().ifBlank { label ?: arch.packageName }.take(60),
                    version = meta?.optString("version").orEmpty().ifBlank { arch.versionName ?: "?" }.take(30),
                    pkg = arch.packageName,
                    description = meta?.optString("description").orEmpty().take(300),
                    actions = meta?.optJSONArray("actions")?.let { a -> (0 until a.length()).map { a.optString(it).take(40) }.take(30) } ?: emptyList(),
                    contract = contract, signer = signer,
                )
                draft = PluginDraft(info, apk, apk.length(), sha, wanted.isNotBlank(), note)
                null
            }
        } catch (e: Exception) {
            return "Plugin invalide : " + (e.message ?: e.javaClass.simpleName)
        }
    }

    // ───────────── Téléchargement (lien en ligne) ─────────────

    /** Télécharge puis valide. @return null si valide, sinon le message d'erreur. */
    suspend fun download(ctx: Context, url: String): String? {
        val u = url.trim()
        if (!u.startsWith("https://", true)) return "Le lien doit commencer par https://"
        val dir = stageDir(ctx).apply { listFiles()?.forEach { it.delete() } }
        val out = File(dir, "download.bin")
        try {
            var cur = u
            var conn: HttpURLConnection? = null
            var hops = 0
            while (conn == null && hops++ < 6) {
                val c = (URL(cur).openConnection() as HttpURLConnection).apply {
                    instanceFollowRedirects = false; connectTimeout = 15_000; readTimeout = 30_000
                    setRequestProperty("User-Agent", "LinkShare-Plugins")
                }
                val code = c.responseCode
                if (code in 300..399) {
                    val loc = c.getHeaderField("Location") ?: return "Redirection sans adresse"
                    c.disconnect()
                    cur = URL(URL(cur), loc).toString()
                    if (!cur.startsWith("https://", true)) return "Redirection vers un lien non sécurisé refusée"
                } else {
                    if (code !in 200..299) { c.disconnect(); return if (code == 404) "Lien introuvable (404)" else "Erreur HTTP $code" }
                    conn = c
                }
            }
            val c = conn ?: return "Trop de redirections"
            try {
                val total = c.contentLengthLong
                if (total > MAX_BYTES) return "Plugin trop volumineux"
                progress = 0f
                c.inputStream.use { input ->
                    out.outputStream().use { o ->
                        val buf = ByteArray(64 * 1024); var done = 0L
                        while (true) {
                            currentCoroutineContext().ensureActive()
                            val n = input.read(buf); if (n < 0) break
                            done += n
                            if (done > MAX_BYTES) throw IllegalStateException("Plugin trop volumineux")
                            o.write(buf, 0, n)
                            if (total > 0) progress = (done.toFloat() / total).coerceIn(0f, 1f)
                        }
                    }
                }
            } finally { c.disconnect(); progress = null }
        } catch (e: Exception) {
            out.delete(); return "Téléchargement impossible : " + (e.message ?: e.javaClass.simpleName)
        }
        return inspectFile(ctx, out)
    }

    // ───────────── Installation et suppression ─────────────

    /** Enregistre le plugin validé puis ouvre l'installeur d'Android. @return message si rien n'a été lancé. */
    fun install(ctx: Context, d: PluginDraft): String? {
        if (!ctx.packageManager.canRequestPackageInstalls()) {
            ctx.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
            return "Autorise LinkShare à installer des applications, puis touche à nouveau « Valider et installer »"
        }
        val list = readRegistry(ctx).filterNot { it.id == d.info.id || it.pkg == d.info.pkg } + d.info
        writeRegistry(ctx, list)
        return try {
            val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", d.apk)
            ctx.startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK),
            )
            draft = null
            refresh(ctx)
            null
        } catch (e: Exception) { "Installation impossible : " + (e.message ?: e.javaClass.simpleName) }
    }

    fun cancelDraft(ctx: Context) { draft = null; stageDir(ctx).listFiles()?.forEach { it.delete() } }

    /** Bouton de suppression : désinstalle l'appli (confirmation d'Android) puis retire le plugin de la liste. */
    fun remove(ctx: Context, e: PluginEntry) {
        if (e.installed) {
            removing += e.info.id
            ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${e.info.pkg}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } else {
            writeRegistry(ctx, readRegistry(ctx).filterNot { it.id == e.info.id })
            refresh(ctx)
        }
    }

    // ───────────── Utilitaires ─────────────

    private fun copyLimited(input: java.io.InputStream, out: java.io.OutputStream) {
        val buf = ByteArray(64 * 1024); var total = 0L
        while (true) {
            val n = input.read(buf); if (n < 0) break
            total += n
            if (total > MAX_BYTES) throw IllegalStateException("Fichier trop volumineux (max ${MAX_BYTES / 1024 / 1024} Mo)")
            out.write(buf, 0, n)
        }
    }

    private fun sha256(f: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        f.inputStream().use { i -> val b = ByteArray(64 * 1024); while (true) { val n = i.read(b); if (n < 0) break; md.update(b, 0, n) } }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun digest(b: ByteArray) = MessageDigest.getInstance("SHA-256").digest(b).joinToString("") { "%02x".format(it) }
}
