package com.linkshare.core.embedded

import android.content.Context
import android.os.Build
import androidx.compose.runtime.mutableStateMapOf
import com.linkshare.plugin.api.LinkSharePlugin
import dalvik.system.DexClassLoader
import java.io.File
import java.lang.reflect.InvocationTargetException

class PluginLoadException(message: String, cause: Throwable? = null) : Exception(message, cause)

/** Plugin chargé : l'instance et le chargeur de classes qui la porte. */
class LoadedPlugin(val id: String, val version: String, val plugin: LinkSharePlugin, val loader: ClassLoader, val dir: File)

/**
 * Charge le code d'un plugin intégré. Garanties :
 *  - les empreintes SHA-256 de TOUS les fichiers sont revérifiées à chaque appel (et tout fichier en trop est refusé) ;
 *  - classes.dex est mis en lecture seule (obligatoire Android 14) ;
 *  - DexClassLoader dont le parent est le chargeur de LinkShare (le contrat plugin-api et la stdlib Kotlin sont donc
 *    ceux de LinkShare), avec les bibliothèques natives du bon ABI ;
 *  - TOUTE erreur — y compris NoClassDefFoundError, UnsatisfiedLinkError, ExceptionInInitializerError — est attrapée :
 *    le plugin passe « en erreur » (voir [errors]) et LinkShare continue de fonctionner.
 */
object PluginLoader {
    /** id → message. Un plugin en erreur n'est plus proposé jusqu'à « Réessayer ». Observable par l'interface. */
    val errors = mutableStateMapOf<String, String>()

    private val cache = HashMap<String, LoadedPlugin>()

    fun errorOf(id: String): String? = errors[id]
    fun markError(id: String, message: String) { errors[id] = message }
    fun clearError(id: String) { errors.remove(id) }
    @Synchronized fun unload(id: String) { cache.remove(id) }

    /** @throws PluginLoadException (le plugin est alors marqué en erreur). */
    @Synchronized
    fun load(ctx: Context, entry: EmbeddedEntry): LoadedPlugin {
        val m = entry.manifest
        try {
            if (m.entryClass.isEmpty()) throw PluginLoadException("plugin.json illisible")
            val dir = EmbeddedPlugins.versionDir(ctx, m.id, m.version)
            verifyFiles(dir, m)

            val dex = File(dir, "classes.dex")
            if (dex.canWrite()) dex.setReadOnly()
            if (dex.canWrite()) throw PluginLoadException("classes.dex n'est pas en lecture seule (refusé par Android 14)")

            cache[m.id]?.takeIf { it.version == m.version }?.let { clearError(m.id); return it }

            val libDir: File? = File(dir, "lib").takeIf { it.isDirectory }?.let {
                Build.SUPPORTED_ABIS.map { abi -> File(it, abi) }.firstOrNull { d -> d.isDirectory }
                    ?: throw PluginLoadException("Aucune bibliothèque native pour ${Build.SUPPORTED_ABIS.joinToString()}")
            }
            val loader = DexClassLoader(dex.path, null, libDir?.path, PluginLoader::class.java.classLoader)
            val cls = loader.loadClass(m.entryClass)
            if (!LinkSharePlugin::class.java.isAssignableFrom(cls))
                throw PluginLoadException("${m.entryClass} n'implémente pas LinkSharePlugin")
            val plugin = cls.getDeclaredConstructor().newInstance() as LinkSharePlugin

            val declared = plugin.actions().map { it.id }.toSet()
            m.actions.firstOrNull { it.id !in declared }?.let { throw PluginLoadException("Action « ${it.id} » annoncée dans plugin.json mais absente du code") }

            val loaded = LoadedPlugin(m.id, m.version, plugin, loader, dir)
            cache[m.id] = loaded
            clearError(m.id)
            return loaded
        } catch (t: Throwable) {
            val msg = describe(t)
            cache.remove(m.id)
            markError(m.id, msg)
            throw PluginLoadException(msg, t)
        }
    }

    /** Charge sans lever : message d'erreur ou null. */
    fun check(ctx: Context, entry: EmbeddedEntry): String? =
        try { load(ctx, entry); null } catch (e: PluginLoadException) { e.message }

    /** Empreintes de tous les fichiers listés + aucun fichier étranger dans le dossier du plugin. */
    private fun verifyFiles(dir: File, m: PluginManifest) {
        if (!dir.isDirectory) throw PluginLoadException("Dossier du plugin introuvable")
        for ((name, want) in m.sha256) {
            val f = File(dir, name)
            if (!f.isFile) throw PluginLoadException("Fichier manquant : $name")
            if (EmbeddedPlugins.sha256(f) != want) throw PluginLoadException("Empreinte SHA-256 invalide : $name a été modifié")
        }
        dir.walkTopDown().filter { it.isFile }.forEach {
            val rel = it.relativeTo(dir).invariantSeparatorsPath
            if (rel != "plugin.json" && rel !in m.sha256) throw PluginLoadException("Fichier inattendu dans le plugin : $rel")
        }
    }

    /** Message lisible : on remonte jusqu'à la vraie cause (InvocationTargetException, ExceptionInInitializerError…). */
    fun describe(t: Throwable): String {
        var c: Throwable = t
        var guard = 0
        while (guard++ < 8 && (c is InvocationTargetException || c is ExceptionInInitializerError || (c is PluginLoadException && c.cause != null))) {
            c = (if (c is InvocationTargetException) c.targetException else c.cause) ?: break
        }
        val text = c.message?.takeIf { it.isNotBlank() }
        return (if (c is PluginLoadException) text.orEmpty() else c.javaClass.simpleName + (text?.let { ": $it" } ?: "")).take(300)
    }
}
