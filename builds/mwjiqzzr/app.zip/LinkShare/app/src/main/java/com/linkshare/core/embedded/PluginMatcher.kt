package com.linkshare.core.embedded

import java.util.Locale

/** Fichier de la sélection, réduit à ce qui sert à la correspondance (testable sans Android). */
class Candidate(val name: String, val mime: String?)

/** Correspondance entre une sélection de fichiers et les actions d'un plugin, et petits utilitaires de noms. */
object PluginMatcher {

    fun extensionOf(name: String): String = name.substringAfterLast('.', "").lowercase(Locale.ROOT)

    /**
     * Un fichier est accepté si l'un des jetons de [accepts] lui convient. Jeton = type MIME exact (`image/png`), famille
     * (`image/` + étoile), étoile seule ou extension (`txt`, `.txt`). Liste vide = tout est accepté.
     */
    fun accepts(accepts: List<String>, name: String, mime: String?): Boolean {
        if (accepts.isEmpty()) return true
        val ext = extensionOf(name)
        val m = mime?.substringBefore(';')?.trim()?.lowercase(Locale.ROOT)?.takeIf { it.isNotEmpty() }
        return accepts.any { raw ->
            val t = raw.trim().lowercase(Locale.ROOT)
            when {
                t.isEmpty() -> false
                t == "*" || t == "*/*" -> true
                t.contains('/') -> when {
                    m == null -> false
                    t.endsWith("/*") -> m.substringBefore('/') == t.removeSuffix("/*")
                    else -> m == t
                }
                else -> ext.isNotEmpty() && ext == t.removePrefix("*").removePrefix(".")
            }
        }
    }

    /** Vrai si le nombre de fichiers est dans [minFiles, maxFiles] et si CHAQUE fichier est accepté. */
    fun matches(action: ManifestAction, files: List<Candidate>): Boolean =
        files.size in action.minFiles..action.maxFiles && files.all { accepts(action.accepts, it.name, it.mime) }

    // ───────────── Noms de fichiers de sortie ─────────────

    private val FORBIDDEN = Regex("[\\\\/:*?\"<>|\\p{Cntrl}]")

    /** Nom sûr : pas de séparateur de dossier, pas de point initial, 120 caractères au plus (l'extension est conservée). */
    fun sanitizeName(raw: String): String {
        var n = FORBIDDEN.replace(raw, "_").trim().trimStart('.').trim()
        if (n.isEmpty()) n = "sortie"
        if (n.length > 120) {
            val ext = n.substringAfterLast('.', "").takeIf { it.isNotEmpty() && it.length <= 10 && n.contains('.') }
            n = if (ext != null) n.substringBeforeLast('.').take(120 - ext.length - 1) + "." + ext else n.take(120)
        }
        return n
    }

    /** « nom.ext » → « nom (1).ext », « nom (2).ext »… jusqu'au premier nom libre selon [taken]. */
    fun uniqueName(name: String, taken: (String) -> Boolean): String {
        if (!taken(name)) return name
        val dot = name.lastIndexOf('.')
        val (base, ext) = if (dot > 0) name.substring(0, dot) to name.substring(dot) else name to ""
        for (i in 1..9999) {
            val c = "$base ($i)$ext"
            if (!taken(c)) return c
        }
        return base + "_" + System.currentTimeMillis() + ext
    }

    // ───────────── Versions ─────────────

    /** Compare deux versions « 1.2.10 » / « 1.10 » segment par segment (numérique si possible). */
    fun compareVersions(a: String, b: String): Int {
        val pa = a.split('.', '-', '+', '_'); val pb = b.split('.', '-', '+', '_')
        for (i in 0 until maxOf(pa.size, pb.size)) {
            val x = pa.getOrElse(i) { "0" }; val y = pb.getOrElse(i) { "0" }
            val nx = x.toLongOrNull(); val ny = y.toLongOrNull()
            val c = if (nx != null && ny != null) nx.compareTo(ny) else x.compareTo(y)
            if (c != 0) return c
        }
        return 0
    }
}
