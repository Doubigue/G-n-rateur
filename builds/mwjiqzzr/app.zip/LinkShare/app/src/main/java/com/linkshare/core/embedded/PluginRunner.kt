package com.linkshare.core.embedded

import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import com.linkshare.plugin.api.PluginInput
import com.linkshare.plugin.api.PluginResult
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job as CoroutineJob
import java.io.File

/** Une exécution d'action demandée par l'utilisateur. */
class PluginJob(
    val pluginId: String, val pluginName: String, val actionId: String, val actionLabel: String,
    val files: List<File>, val params: Map<String, String>, val vaultDir: File,
) {
    @Volatile var cancelled = false
    @Volatile var coroutine: CoroutineJob? = null
}

/** Fin d'une exécution, lue par l'explorateur (message + rechargement de la liste). */
class PluginFinished(val ok: Boolean, val message: String, val outputs: List<File>)

/**
 * Exécute les actions des plugins intégrés dans un service de premier plan (type dataSync, notification de progression
 * avec bouton Annuler). Une seule exécution à la fois. Voir [PluginRunService].
 */
object PluginRunner {
    var current by mutableStateOf<PluginJob?>(null)
        private set
    /** Posé à la fin ; consommé (remis à null) par PluginRunHost, qui affiche le message et recharge l'explorateur. */
    var finished by mutableStateOf<PluginFinished?>(null)

    fun isRunning(id: String? = null) = current?.let { id == null || it.pluginId == id } ?: false

    /** Valide la demande puis démarre le service. @return message d'erreur si rien n'a été lancé. */
    fun start(ctx: Context, entry: EmbeddedEntry, action: ManifestAction, files: List<File>, params: Map<String, String>, vaultDir: File): String? {
        if (current != null) return "Un plugin est déjà en cours d'exécution"
        if (!entry.enabled) return "Ce plugin est désactivé"
        PluginLoader.errorOf(entry.id)?.let { return "Plugin en erreur : $it" }
        "storage".let { if (it !in entry.manifest.permissions) return "Ce plugin n'a pas la permission « $it »" }
        val check = checkFiles(files, vaultDir)
        if (check != null) return check
        if (!PluginMatcher.matches(action, files.map { EmbeddedPlugins.candidate(it) })) return "Cette action ne s'applique pas à la sélection"
        val job = PluginJob(entry.id, entry.manifest.name, action.id, action.label, files.toList(), params, vaultDir)
        current = job
        return try {
            ContextCompat.startForegroundService(ctx, Intent(ctx, PluginRunService::class.java))
            null
        } catch (e: Exception) {
            current = null
            "Impossible de démarrer le traitement : " + (e.message ?: e.javaClass.simpleName)
        }
    }

    /** Fichiers autorisés : réguliers, existants, JAMAIS dans le coffre. */
    fun checkFiles(files: List<File>, vaultDir: File): String? {
        if (files.isEmpty()) return "Aucun fichier"
        val vault = vaultDir.canonicalPath + File.separator
        for (f in files) {
            if (!f.isFile) return "« ${f.name} » n'est pas un fichier lisible"
            if ((f.canonicalPath + File.separator).startsWith(vault) || f.canonicalPath.startsWith(vault)) return "Les fichiers du coffre ne sont jamais transmis aux plugins"
        }
        return null
    }

    fun cancel() { current?.let { it.cancelled = true; it.coroutine?.cancel() } }

    internal fun clear() { current = null }

    /**
     * Exécute l'action (appelée par le service, ou directement par les tests). Ne lève jamais d'exception :
     * échec, annulation et plantage du plugin sont tous traduits en [PluginFinished].
     */
    suspend fun execute(ctx: Context, job: PluginJob, onProgress: (Int, String) -> Unit): PluginFinished {
        val app = ctx.applicationContext
        var host: PluginHostImpl? = null
        try {
            val entry = EmbeddedPlugins.find(job.pluginId) ?: return PluginFinished(false, "Plugin introuvable", emptyList())
            val loaded = PluginLoader.load(app, entry) // erreurs : PluginLoadException, le plugin passe « en erreur »
            val inputs = job.files.map { f -> PluginInput(f.name, EmbeddedPlugins.mimeOf(f) ?: "application/octet-stream", Uri.fromFile(f).toString()) }
            val map = inputs.zip(job.files).associate { (i, f) -> i.uri to f }
            val h = PluginHostImpl(
                app, EmbeddedPlugins.prefs(app, job.pluginId), File(loaded.dir, "assets"),
                "storage" in entry.manifest.permissions, map, job.files.first().parentFile ?: job.vaultDir, onProgress,
            ) { job.cancelled }
            host = h
            val result = loaded.plugin.run(h, job.actionId, inputs, job.params)
            if (job.cancelled) { discard(h); return PluginFinished(false, "Annulé", emptyList()) }
            return when (result) {
                is PluginResult.Success -> {
                    val files = h.createdFiles()
                    MediaScannerConnection.scanFile(app, files.map { it.path }.toTypedArray(), null, null)
                    val name = when {
                        files.isNotEmpty() -> files[0].name + if (files.size > 1) " (+${files.size - 1})" else ""
                        result.outputs.isNotEmpty() -> result.outputs[0]
                        else -> ""
                    }
                    val note = result.message.trim().takeIf { it.isNotEmpty() && it.length <= 80 }
                    PluginFinished(true, (if (name.isEmpty()) "Terminé" else "Terminé : $name") + (note?.let { " · $it" } ?: ""), files)
                }
                is PluginResult.Failure -> { discard(h); PluginFinished(false, "${job.pluginName} : ${result.message.ifBlank { "échec" }.take(200)}", emptyList()) }
            }
        } catch (ce: CancellationException) {
            host?.let { discard(it) }
            return PluginFinished(false, "Annulé", emptyList())
        } catch (t: Throwable) {
            // Plantage du plugin (ou échec de chargement) : on le met « en erreur », LinkShare continue.
            host?.let { discard(it) }
            val msg = if (t is PluginLoadException) (t.message ?: "chargement impossible") else PluginLoader.describe(t)
            if (t !is PluginLoadException) PluginLoader.markError(job.pluginId, msg)
            return PluginFinished(false, "${job.pluginName} est en erreur : $msg", emptyList())
        }
    }

    /** Supprime les sorties d'une exécution échouée ou annulée (jamais un fichier existant avant l'action). */
    private fun discard(h: PluginHostImpl) { h.createdFiles().forEach { runCatching { it.delete() } } }
}
