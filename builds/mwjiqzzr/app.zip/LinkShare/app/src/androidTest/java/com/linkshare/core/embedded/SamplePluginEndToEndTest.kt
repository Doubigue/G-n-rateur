package com.linkshare.core.embedded

import android.content.Context
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assume.assumeTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File

/**
 * Test de bout en bout du plugin d'exemple (sample-plugin, action « texte en majuscules ») :
 * analyse → installation → chargement (DexClassLoader) → exécution → sortie à côté de la source.
 *
 * Préparation : `cd sample-plugin && ./gradlew buildLsplugin`, puis copier build/sample-uppercase.lsplugin dans
 * app/src/androidTest/assets/ . Sans ce fichier, le test est ignoré (et non en échec).
 * Lancement : ./gradlew :app:connectedDebugAndroidTest   (téléphone ou émulateur API 30+)
 */
@RunWith(AndroidJUnit4::class)
class SamplePluginEndToEndTest {
    private val ctx: Context get() = InstrumentationRegistry.getInstrumentation().targetContext
    private val testCtx: Context get() = InstrumentationRegistry.getInstrumentation().context
    private lateinit var work: File

    @Before fun setUp() {
        work = File(ctx.cacheDir, "e2e").apply { deleteRecursively(); mkdirs() }
        EmbeddedPlugins.remove(ctx, "sample-uppercase")
    }

    @After fun tearDown() {
        EmbeddedPlugins.remove(ctx, "sample-uppercase")
        work.deleteRecursively()
    }

    private fun sampleZip(): File? {
        val f = File(work, "sample.lsplugin")
        return try { testCtx.assets.open("sample-uppercase.lsplugin").use { i -> f.outputStream().use { i.copyTo(it) } }; f } catch (e: Exception) { null }
    }

    @Test fun installLoadRunAndKeepSource() = runBlocking {
        val zip = sampleZip()
        assumeTrue("sample-uppercase.lsplugin absent des assets de test", zip != null)

        // 1. Analyse : rien n'est exécuté, la carte de configuration est remplie
        assertNull(EmbeddedPlugins.inspectZip(ctx, zip!!))
        val draft = EmbeddedPlugins.draft
        assertNotNull(draft)
        assertEquals("sample-uppercase", draft!!.manifest.id)
        assertTrue(draft.needsConfirmation)

        // 2. Installation : classes.dex en lecture seule
        assertNull(EmbeddedPlugins.install(ctx, draft))
        val entry = EmbeddedPlugins.find("sample-uppercase")!!
        assertTrue(entry.enabled)
        val dex = File(EmbeddedPlugins.versionDir(ctx, entry.id, entry.manifest.version), "classes.dex")
        assertTrue(dex.isFile); assertTrue(!dex.canWrite())

        // 3. Chargement : DexClassLoader + vérification des empreintes
        assertNull(PluginLoader.check(ctx, entry))

        // 4. Exécution
        val src = File(work, "bonjour.txt").apply { writeText("bonjour le monde\nça va ?") }
        val vault = File(work, "vault").apply { mkdirs() }
        val job = PluginJob(entry.id, entry.manifest.name, "upper", "Texte en majuscules", listOf(src), mapOf("suffix" to "_MAJ", "keep_accents" to "true"), vault)
        val percents = mutableListOf<Int>()
        val res = PluginRunner.execute(ctx, job) { p, _ -> percents += p }
        assertTrue(res.message, res.ok)
        assertTrue(res.message.startsWith("Terminé : "))
        val out = res.outputs.single()
        assertEquals(src.parentFile, out.parentFile)          // à côté du fichier source
        assertEquals("BONJOUR LE MONDE\nÇA VA ?", out.readText())
        assertEquals("bonjour le monde\nça va ?", src.readText()) // source intacte
        assertTrue(percents.isNotEmpty())

        // 5. Deuxième exécution : aucun écrasement (« … (1).txt »)
        val res2 = PluginRunner.execute(ctx, job) { _, _ -> }
        assertTrue(res2.ok)
        assertTrue(res2.outputs.single().name != out.name)
        assertEquals("BONJOUR LE MONDE\nÇA VA ?", out.readText())

        // 6. Un fichier du coffre n'est jamais transmis
        val inVault = File(vault, "secret.txt").apply { writeText("x") }
        assertTrue(PluginRunner.checkFiles(listOf(inVault), vault) != null)

        // 7. Fichier modifié sur disque → empreinte refusée, plugin « en erreur », pas de plantage
        dex.setWritable(true); dex.appendBytes(byteArrayOf(0)); dex.setReadOnly()
        PluginLoader.unload(entry.id)
        val res3 = PluginRunner.execute(ctx, job) { _, _ -> }
        assertTrue(!res3.ok)
        assertNotNull(PluginLoader.errorOf(entry.id))
        Unit
    }
}
