package com.linkshare.core.embedded

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class PluginManifestTest {
    private val sha = "a".repeat(64)

    /** plugin.json valide, avec des morceaux remplaçables pour provoquer chaque erreur. */
    private fun json(
        id: String = "upper", contract: String = "2", entry: String = "com.example.Plugin", perms: String = """["storage"]""",
        actions: String = """[{"id":"up","label":"Majuscules","accepts":["txt"]}]""", settings: String = "[]",
        replaces: String? = null, shaMap: String = """{"classes.dex":"$sha"}""",
    ) = """{"id":"$id","name":"Démo","version":"1.0","entryClass":"$entry","contract":$contract,"permissions":$perms,
        "actions":$actions,"settings":$settings,"sha256":$shaMap${replaces?.let { ""","replacesBridge":"$it"""" } ?: ""}}"""

    private fun error(text: String): String = try { PluginManifestParser.parse(text); fail("aurait dû échouer"); "" } catch (e: ManifestException) { e.message.orEmpty() }

    @Test fun parsesMinimalManifest() {
        val m = PluginManifestParser.parse(json())
        assertEquals("upper", m.id); assertEquals(2, m.contract); assertEquals(listOf("storage"), m.permissions)
        val a = m.actions.single()
        assertEquals(1, a.minFiles); assertEquals(1, a.maxFiles); assertEquals(listOf("txt"), a.accepts); assertTrue(a.params.isEmpty())
        assertNull(m.replacesBridge); assertEquals(sha, m.sha256["classes.dex"])
    }

    @Test fun parsesActionParamsAndSettings() {
        val m = PluginManifestParser.parse(json(
            actions = """[{"id":"x","label":"X","icon":"🔠","accepts":["image/*"],"minFiles":2,"maxFiles":0,"params":[
                {"key":"n","label":"N","type":"int","default":500,"min":1,"max":10},
                {"key":"f","label":"F","type":"float","default":0.5,"min":0,"max":1},
                {"key":"b","label":"B","type":"bool","default":true},
                {"key":"c","label":"C","type":"choice","choices":["a","b"],"default":"zzz"},
                {"key":"t","label":"T","type":"text","default":"hi"}]}]""",
            settings = """[{"key":"s","label":"S","type":"text"}]""",
        ))
        val a = m.actions[0]
        assertEquals(2, a.minFiles); assertEquals(Int.MAX_VALUE, a.maxFiles) // maxFiles ≤ 0 = illimité
        val p = a.params.associateBy { it.key }
        assertEquals("10", p.getValue("n").default)   // défaut ramené dans [min, max]
        assertEquals("0.5", p.getValue("f").default)
        assertEquals("true", p.getValue("b").default)
        assertEquals("a", p.getValue("c").default)    // défaut hors liste → premier choix
        assertEquals(1, m.settings.size)
    }

    @Test fun rejectsWrongContract() { assertTrue(error(json(contract = "1")).contains("contract")) }
    @Test fun rejectsBadId() { assertTrue(error(json(id = "../evil")).contains("id")) }
    @Test fun rejectsBadEntryClass() { assertTrue(error(json(entry = "com..Bad")).contains("entryClass")) }
    @Test fun rejectsUnknownPermission() { assertTrue(error(json(perms = """["storage","camera"]""")).contains("camera")) }
    @Test fun rejectsNoActions() { assertTrue(error(json(actions = "[]")).contains("action")) }
    @Test fun rejectsDuplicateActionIds() {
        assertTrue(error(json(actions = """[{"id":"a","label":"A"},{"id":"a","label":"B"}]""")).contains("double"))
    }
    @Test fun rejectsMaxBelowMin() {
        assertTrue(error(json(actions = """[{"id":"a","label":"A","minFiles":3,"maxFiles":2}]""")).contains("maxFiles"))
    }
    @Test fun rejectsChoiceWithoutChoices() {
        assertTrue(error(json(settings = """[{"key":"c","label":"C","type":"choice"}]""")).contains("choices"))
    }
    @Test fun rejectsUnknownBridge() { assertTrue(error(json(replaces = "nope")).contains("replacesBridge")) }
    @Test fun acceptsKnownBridge() { assertEquals("studio", PluginManifestParser.parse(json(replaces = "studio")).replacesBridge) }

    @Test fun requiresDexHash() {
        assertTrue(error(json(shaMap = """{"assets/a.txt":"$sha"}""")).contains("classes.dex"))
        assertTrue(error(json(shaMap = "{}")).contains("classes.dex"))
    }
    @Test fun rejectsBadHashOrPath() {
        assertTrue(error(json(shaMap = """{"classes.dex":"xyz"}""")).contains("empreinte"))
        assertTrue(error(json(shaMap = """{"classes.dex":"$sha","../x":"$sha"}""")).contains("non autorisé"))
    }
    @Test fun rejectsGarbage() { assertTrue(error("pas du json").contains("illisible")) }

    @Test fun allowedEntries() {
        assertTrue(PluginPaths.isAllowedEntry("classes.dex"))
        assertTrue(PluginPaths.isAllowedEntry("assets/models/fr.bin"))
        assertTrue(PluginPaths.isAllowedEntry("lib/arm64-v8a/libfoo.so"))
        assertFalse(PluginPaths.isAllowedEntry("lib/mips/libfoo.so"))
        assertFalse(PluginPaths.isAllowedEntry("lib/arm64-v8a/sub/libfoo.so"))
        assertFalse(PluginPaths.isAllowedEntry("lib/arm64-v8a/readme.txt"))
        assertFalse(PluginPaths.isAllowedEntry("../classes.dex"))
        assertFalse(PluginPaths.isAllowedEntry("assets/../../x"))
        assertFalse(PluginPaths.isAllowedEntry("/classes.dex"))
        assertFalse(PluginPaths.isAllowedEntry("assets\\x"))
        assertFalse(PluginPaths.isAllowedEntry("classes2.dex"))
        assertFalse(PluginPaths.isAllowedEntry("plugin.json"))
        assertFalse(PluginPaths.isAllowedEntry("assets/"))
    }
}
