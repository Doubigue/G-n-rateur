package com.linkshare.core.embedded

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PluginMatcherTest {
    private fun action(accepts: List<String>, min: Int = 1, max: Int = 1) =
        ManifestAction("a", "A", "", accepts, min, max, emptyList())

    private fun c(name: String, mime: String? = null) = Candidate(name, mime)

    @Test fun extensionTokens() {
        assertTrue(PluginMatcher.accepts(listOf("txt"), "notes.TXT", null))
        assertTrue(PluginMatcher.accepts(listOf(".txt"), "a.txt", null))
        assertTrue(PluginMatcher.accepts(listOf("*.txt"), "a.txt", null))
        assertFalse(PluginMatcher.accepts(listOf("txt"), "a.md", null))
        assertFalse(PluginMatcher.accepts(listOf("txt"), "txt", null)) // pas d'extension
    }

    @Test fun mimeTokens() {
        assertTrue(PluginMatcher.accepts(listOf("image/png"), "a", "image/png"))
        assertTrue(PluginMatcher.accepts(listOf("image/*"), "a.jpg", "image/jpeg"))
        assertFalse(PluginMatcher.accepts(listOf("image/*"), "a.mp4", "video/mp4"))
        assertFalse(PluginMatcher.accepts(listOf("image/png"), "a", null))
        assertTrue(PluginMatcher.accepts(listOf("text/plain"), "a", "text/plain; charset=utf-8"))
        assertTrue(PluginMatcher.accepts(listOf("*/*"), "a", null))
        assertTrue(PluginMatcher.accepts(listOf("*"), "a", null))
    }

    @Test fun mixedTokensAndEmptyList() {
        assertTrue(PluginMatcher.accepts(listOf("txt", "image/*"), "a.jpg", "image/jpeg"))
        assertTrue(PluginMatcher.accepts(listOf("txt", "image/*"), "a.txt", "text/plain"))
        assertTrue(PluginMatcher.accepts(emptyList(), "anything.bin", null)) // liste vide = tout
    }

    @Test fun fileCountBounds() {
        val one = action(listOf("txt"))
        assertTrue(PluginMatcher.matches(one, listOf(c("a.txt"))))
        assertFalse(PluginMatcher.matches(one, emptyList()))
        assertFalse(PluginMatcher.matches(one, listOf(c("a.txt"), c("b.txt"))))
        val range = action(listOf("txt"), 2, 3)
        assertFalse(PluginMatcher.matches(range, listOf(c("a.txt"))))
        assertTrue(PluginMatcher.matches(range, listOf(c("a.txt"), c("b.txt"))))
        assertFalse(PluginMatcher.matches(range, List(4) { c("f$it.txt") }))
        val unlimited = action(emptyList(), 1, Int.MAX_VALUE)
        assertTrue(PluginMatcher.matches(unlimited, List(500) { c("f$it.bin") }))
    }

    @Test fun everyFileMustBeAccepted() {
        val a = action(listOf("jpg", "png"), 1, 5)
        assertTrue(PluginMatcher.matches(a, listOf(c("a.jpg"), c("b.PNG"))))
        assertFalse(PluginMatcher.matches(a, listOf(c("a.jpg"), c("b.gif"))))
    }

    @Test fun sanitizeNames() {
        assertEquals("a_b_c.txt", PluginMatcher.sanitizeName("a/b\\c.txt"))
        assertEquals("_evil.txt", PluginMatcher.sanitizeName("../evil.txt"))
        assertFalse(PluginMatcher.sanitizeName("../../x").contains('/'))
        assertFalse(PluginMatcher.sanitizeName("..hidden").startsWith("."))
        assertEquals("sortie", PluginMatcher.sanitizeName("   "))
        val long = PluginMatcher.sanitizeName("x".repeat(300) + ".txt")
        assertEquals(120, long.length); assertTrue(long.endsWith(".txt"))
    }

    @Test fun uniqueNamesNeverOverwrite() {
        assertEquals("a.txt", PluginMatcher.uniqueName("a.txt") { false })
        assertEquals("a (1).txt", PluginMatcher.uniqueName("a.txt") { it == "a.txt" })
        assertEquals("a (2).txt", PluginMatcher.uniqueName("a.txt") { it == "a.txt" || it == "a (1).txt" })
        assertEquals("noext (1)", PluginMatcher.uniqueName("noext") { it == "noext" })
    }

    @Test fun versionOrder() {
        assertTrue(PluginMatcher.compareVersions("1.10", "1.9") > 0)
        assertTrue(PluginMatcher.compareVersions("1.0", "1.0.0") == 0)
        assertTrue(PluginMatcher.compareVersions("2.0", "10.0") < 0)
    }
}
