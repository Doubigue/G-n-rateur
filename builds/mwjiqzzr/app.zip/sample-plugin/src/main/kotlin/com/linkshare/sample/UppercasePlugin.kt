package com.linkshare.sample

import com.linkshare.plugin.api.LinkSharePlugin
import com.linkshare.plugin.api.PluginAction
import com.linkshare.plugin.api.PluginHost
import com.linkshare.plugin.api.PluginInput
import com.linkshare.plugin.api.PluginParam
import com.linkshare.plugin.api.PluginParamType
import com.linkshare.plugin.api.PluginResult
import java.text.Normalizer
import java.util.Locale

/** Action « Texte en majuscules » : copie le fichier texte choisi en MAJUSCULES, à côté de l'original. */
class UppercasePlugin : LinkSharePlugin {

    override fun actions() = listOf(
        PluginAction(
            id = "upper", label = "Texte en majuscules", icon = "🔠",
            accepts = listOf("txt", "md", "text/plain"),
            params = listOf(
                PluginParam("suffix", "Suffixe ajouté au nom", PluginParamType.TEXT, "_MAJ"),
                PluginParam("keep_accents", "Garder les accents", PluginParamType.BOOL, "true"),
            ),
        ),
    )

    override suspend fun run(host: PluginHost, actionId: String, inputs: List<PluginInput>, params: Map<String, String>): PluginResult {
        if (actionId != "upper") return PluginResult.Failure("Action inconnue : $actionId")
        val input = inputs.firstOrNull() ?: return PluginResult.Failure("Aucun fichier")

        host.progress(5, "Lecture de ${input.name}")
        val text = host.openInput(input).bufferedReader(Charsets.UTF_8).use { it.readText() }
        if (host.isCancelled()) return PluginResult.Failure("Annulé")

        // Réglage du plugin (Paramètres › Install plugins › Réglages), lu dans host.prefs
        val locale = when (host.prefs.getString("locale", "root")) {
            "fr" -> Locale.FRENCH
            "tr" -> Locale.forLanguageTag("tr")
            else -> Locale.ROOT
        }
        host.progress(40, "Conversion")
        var up = text.uppercase(locale)
        if (params["keep_accents"] == "false") up = Normalizer.normalize(up, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")
        val banner = host.prefs.getString("banner", "").orEmpty()
        if (banner.isNotBlank()) up = banner + "\n" + up

        val base = input.name.substringBeforeLast('.', input.name)
        val ext = input.name.substringAfterLast('.', "txt")
        val outName = base + (params["suffix"] ?: "_MAJ") + "." + ext

        host.progress(80, "Écriture de $outName")
        host.createOutput(outName, "text/plain").bufferedWriter(Charsets.UTF_8).use { it.write(up) }
        host.progress(100, "Terminé")
        return PluginResult.Success(listOf(outName), "${up.length} caractères")
    }
}
