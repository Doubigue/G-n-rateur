# Plugin d'exemple : texte en majuscules (contrat 2)

Valide de bout en bout le chargement d'un plugin intégré : analyse → installation → DexClassLoader → exécution.

1. Dans `LinkShare/` : `gradle :plugin-api:exportApiJar`, puis copier `build/plugin-api/linkshare-plugin-api-2.0.jar` dans `sample-plugin/libs/`.
2. Ici : `gradle buildLsplugin` (SDK Android + build-tools requis : `ANDROID_HOME` ou `local.properties`) → `build/sample-uppercase.lsplugin`.
3. Sur le téléphone : Paramètres › Install plugins › Ajouter un nouveau plugin › Téléverser → carte de configuration → Valider et installer.
4. Dans l'explorateur, ouvrir un fichier `.txt` › écran Action : une carte « Texte en majuscules (exemple) » apparaît.
5. Test automatique : copier le `.lsplugin` dans `LinkShare/app/src/androidTest/assets/` puis `gradle :app:connectedDebugAndroidTest`.
