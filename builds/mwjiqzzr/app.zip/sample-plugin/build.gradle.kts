import java.security.MessageDigest
import java.util.Properties
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

plugins { kotlin("jvm") version "2.0.21" }

// Projet de plugin INTÉGRÉ (contrat 2) d'exemple. Aucune dépendance Android Gradle : on compile du Kotlin/JVM contre
//   - linkshare-plugin-api-2.0.jar   (à copier dans libs/, voir libs/README.txt)
//   - android.jar de ton SDK         (Context, SharedPreferences…)
// puis on convertit en classes.dex avec d8 et on assemble le .lsplugin (avec les SHA-256).
// Tout ce que LinkShare fournit déjà (plugin-api, bibliothèque standard Kotlin, Android) reste en compileOnly :
// ne jamais l'embarquer dans classes.dex.

java {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
}
kotlin { compilerOptions { jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17) } }

fun sdkDir(): File {
    System.getenv("ANDROID_HOME")?.let { return File(it) }
    System.getenv("ANDROID_SDK_ROOT")?.let { return File(it) }
    val lp = file("local.properties")
    if (lp.exists()) Properties().apply { lp.inputStream().use { load(it) } }.getProperty("sdk.dir")?.let { return File(it) }
    error("SDK Android introuvable : définis ANDROID_HOME ou sdk.dir dans local.properties")
}

fun androidJar(): File =
    File(sdkDir(), "platforms").listFiles().orEmpty().filter { File(it, "android.jar").exists() }
        .maxByOrNull { it.name.substringAfter("android-").substringBefore('-').toIntOrNull() ?: 0 }
        ?.let { File(it, "android.jar") } ?: error("Aucune plateforme Android trouvée dans ${sdkDir()}/platforms")

dependencies {
    compileOnly(fileTree("libs") { include("*.jar") })
    compileOnly(files(provider { androidJar() }))
}

val dexOut = layout.buildDirectory.dir("dex")

val dex by tasks.registering(Exec::class) {
    group = "linkshare"
    description = "classes.dex (d8) à partir du jar du plugin"
    dependsOn(tasks.jar)
    doFirst {
        val out = dexOut.get().asFile.apply { deleteRecursively(); mkdirs() }
        val win = System.getProperty("os.name").startsWith("Windows")
        val bt = File(sdkDir(), "build-tools").listFiles().orEmpty()
            .filter { File(it, if (win) "d8.bat" else "d8").exists() }
            .maxWithOrNull(compareBy({ it.name.substringBefore('.').toIntOrNull() ?: 0 }, { it.name }))
            ?: error("d8 introuvable : installe les build-tools Android (SDK Manager)")
        val androidJar = androidJar()
        val cp = configurations.compileClasspath.get().files.filter { it.name.endsWith(".jar") && it.name != "android.jar" }
        val cmd = mutableListOf(File(bt, if (win) "d8.bat" else "d8").path, "--release", "--min-api", "30", "--lib", androidJar.path)
        cp.forEach { cmd += listOf("--classpath", it.path) }
        cmd += listOf("--output", out.path, tasks.jar.get().archiveFile.get().asFile.path)
        commandLine(cmd)
    }
}

tasks.register("buildLsplugin") {
    group = "linkshare"
    description = "Assemble build/sample-uppercase.lsplugin (plugin.json + classes.dex, avec les empreintes SHA-256)"
    dependsOn(dex)
    doLast {
        val dexFile = dexOut.get().file("classes.dex").asFile
        val bytes = dexFile.readBytes()
        val sha = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
        val json = file("plugin.template.json").readText().replace("@SHA256_MAP@", """{"classes.dex":"$sha"}""")
        val out = layout.buildDirectory.file("sample-uppercase.lsplugin").get().asFile
        out.parentFile.mkdirs(); out.delete()
        ZipOutputStream(out.outputStream()).use { z ->
            z.putNextEntry(ZipEntry("plugin.json")); z.write(json.toByteArray(Charsets.UTF_8)); z.closeEntry()
            z.putNextEntry(ZipEntry("classes.dex")); z.write(bytes); z.closeEntry()
        }
        println("OK : $out  (classes.dex sha256 $sha)")
    }
}
