Copie ici linkshare-plugin-api-2.0.jar, fabriqué depuis le projet LinkShare :

    cd LinkShare && gradle :plugin-api:exportApiJar
    → LinkShare/build/plugin-api/linkshare-plugin-api-2.0.jar

(compileOnly : ce jar est déjà dans LinkShare, il ne doit PAS finir dans classes.dex.)
