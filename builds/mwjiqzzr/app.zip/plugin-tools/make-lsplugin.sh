#!/usr/bin/env bash
# Assemble un plugin LinkShare (.lsplugin) à partir d'un APK et d'un plugin.json.
# Usage : ./make-lsplugin.sh MediaStudio-debug.apk mediastudio/plugin.json MediaStudio.lsplugin
set -euo pipefail
APK="$1"; META="$2"; OUT="${3:-plugin.lsplugin}"
[ -f "$APK" ] && [ -f "$META" ] || { echo "APK ou plugin.json introuvable" >&2; exit 1; }
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
NAME="$(python3 -c "import json,sys;print(json.load(open(sys.argv[1])).get('apk','plugin.apk'))" "$META")"
cp "$APK" "$TMP/$NAME"
SHA="$(sha256sum "$TMP/$NAME" | cut -d' ' -f1)"
python3 - "$META" "$TMP/plugin.json" "$SHA" <<'PY'
import json, sys
m = json.load(open(sys.argv[1])); m["sha256"] = sys.argv[3]
json.dump(m, open(sys.argv[2], "w"), ensure_ascii=False, indent=2)
PY
OUT_ABS="$(cd "$(dirname "$OUT")" && pwd)/$(basename "$OUT")"
( cd "$TMP" && zip -q -X "$OUT_ABS" plugin.json "$NAME" )
echo "OK : $OUT  (sha256 $SHA)"
