# Plugins intégrés LinkShare (contrat 2)

Du code chargé **dans** LinkShare (`classes.dex`), sans installer d'appli. Indépendant des plugins installés (contrat 1, APK) et des
Ponts : couper un pont ne coupe jamais un plugin ; chaque plugin a son propre interrupteur (Paramètres › Install plugins).
Seul un plugin **actif et sain** qui déclare `replacesBridge` fait *masquer* le pont correspondant (le réglage du pont n'est pas modifié).

## Fabriquer le jar de l'API
`gradle :plugin-api:exportApiJar` → `LinkShare/build/plugin-api/linkshare-plugin-api-2.0.jar` (à mettre en `compileOnly`).
Ne jamais embarquer l'API, la stdlib Kotlin ni android.jar dans `classes.dex` : LinkShare les fournit (classloader parent).
Si LinkShare est un jour compilé avec R8, garder `com.linkshare.plugin.api.**` et la stdlib (règle déjà dans `consumer-rules.pro`).

## Format `.lsplugin` v2 (zip)
```
plugin.json
classes.dex          (un seul dex ; d8 --min-api 30)
assets/...           (facultatif, lu via host.openAsset)
lib/<abi>/lib*.so    (facultatif : arm64-v8a, armeabi-v7a, x86, x86_64)
```
`plugin.json` : `id` (minuscules/chiffres/-/_), `name`, `version`, `description`, `entryClass`, `contract: 2`,
`permissions` (`storage|notifications|network`), `actions[]` (`id,label,icon,accepts[],minFiles,maxFiles,params[]`),
`settings[]` (même schéma que `params`), `replacesBridge` (`studio|extrait|editor`), `sha256` : objet `{fichier: empreinte}`
pour **chaque** fichier (hors plugin.json), `classes.dex` obligatoire. Exemple : `sample-plugin/plugin.template.json`.
Outil générique : `./make-lsplugin-v2.py <dossier> <plugin.json> <sortie.lsplugin>`.

- `accepts` : type MIME (`image/png`, `image/` + étoile), étoile seule, ou extension (`txt`, `.txt`) ; liste vide = tout. `maxFiles ≤ 0` = illimité.
- `params`/`settings` : types `int|float` (curseur, `min`/`max`), `bool` (interrupteur), `choice` (`choices`), `text`. Les `params` arrivent en texte dans `run()` ; les `settings` sont écrits dans `host.prefs` avec leur vrai type (Int, Float, Boolean, String).
- Les actions de `plugin.json` doivent exister dans `actions()` du code (sinon le plugin passe « en erreur »).

## Ce que LinkShare garantit
- Analyse sans exécuter de code ; chemins du zip filtrés (pas de `..`), tailles limitées, SHA-256 de chaque fichier contrôlé.
- Installation dans `filesDir/plugins/<id>/<version>/`, `classes.dex` en lecture seule (obligatoire Android 14).
- À **chaque chargement** : empreintes revérifiées, fichier en trop refusé, `DexClassLoader` (parent = LinkShare, libs natives du bon ABI).
- Toute erreur (`Throwable`, `NoClassDefFoundError`, `UnsatisfiedLinkError`…) → plugin « en erreur » (carte rouge, **Réessayer**), LinkShare ne plante pas.
- Exécution dans un service de premier plan `dataSync` : notification de progression + **Annuler** (`host.isCancelled()` : à interroger régulièrement). Une seule exécution à la fois.
- `openInput` : seulement les fichiers choisis, **jamais** ceux du coffre ; `createOutput` : à côté du fichier source, nom nettoyé et rendu unique, rien n'est écrasé ; sorties supprimées si échec/annulation.

## Sécurité — à lire
**Le code d'un plugin tourne avec les droits de LinkShare** (dont l'accès aux fichiers et au réseau). Les permissions sont des
déclarations confirmées par l'utilisateur à l'installation et à chaque mise à jour qui les change ; seule `storage` est appliquée
au niveau de l'API hôte (`openInput`/`createOutput` refusés sans elle). Ce n'est **pas** un bac à sable : n'installer que des plugins de confiance.

## Écran Compose optionnel (prévu, NON implémenté en 1.6)
Réservé : `PluginScreenProvider`/`PluginScreen` dans `plugin-api`, et clé `screens` ignorée de `plugin.json`. Piste : un plugin
exposerait des écrans (`id`, `title`) que LinkShare listerait dans la carte du plugin ; le rendu se ferait via le runtime Compose
de LinkShare (parent du classloader), ce qui impose de figer la version du compilateur Compose entre hôte et plugins et d'ajouter
une API de contenu (`@Composable`) dans une version ultérieure du contrat (contrat 3 ou extension déclarée).

## Tests
`gradle :app:testDebugUnitTest` (analyse de plugin.json, accepts/fichiers, noms, chemins) ; bout en bout : voir `sample-plugin/README.md`.
