#!/usr/bin/env python3
"""Assemble un plugin LinkShare intégré (.lsplugin v2) et calcule les empreintes SHA-256.

Usage : ./make-lsplugin-v2.py <dossier> <plugin.json> <sortie.lsplugin>

<dossier> contient : classes.dex  (obligatoire), assets/…  (facultatif), lib/<abi>/*.so  (facultatif).
<plugin.json> est le modèle : le champ « sha256 » est (re)calculé pour chaque fichier du dossier.
"""
import hashlib, json, os, sys, zipfile

ABIS = {"arm64-v8a", "armeabi-v7a", "x86", "x86_64"}

def allowed(rel: str) -> bool:
    p = rel.split("/")
    if rel == "classes.dex": return True
    if p[0] == "assets" and len(p) >= 2: return True
    return len(p) == 3 and p[0] == "lib" and p[1] in ABIS and p[2].endswith(".so")

def main() -> int:
    if len(sys.argv) != 4:
        print(__doc__); return 2
    folder, template, out = sys.argv[1:]
    files = {}
    for root, _, names in os.walk(folder):
        for n in names:
            full = os.path.join(root, n)
            rel = os.path.relpath(full, folder).replace(os.sep, "/")
            if not allowed(rel):
                print(f"Fichier ignoré (non autorisé dans un plugin) : {rel}", file=sys.stderr); continue
            files[rel] = full
    if "classes.dex" not in files:
        print("classes.dex introuvable dans le dossier", file=sys.stderr); return 1
    meta = json.load(open(template, encoding="utf-8"))
    meta["contract"] = 2
    meta["sha256"] = {rel: hashlib.sha256(open(p, "rb").read()).hexdigest() for rel, p in sorted(files.items())}
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("plugin.json", json.dumps(meta, ensure_ascii=False, indent=2))
        for rel, p in sorted(files.items()):
            z.write(p, rel)
    print(f"OK : {out} ({len(files)} fichier(s))")
    return 0

if __name__ == "__main__":
    sys.exit(main())
