plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
}
android {
    namespace = "com.example.mydm"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.mydm"
        minSdk = 29; targetSdk = 35
        versionCode = 16; versionName = "2.9.4"
    }
    // ── Signature FIXE : la même clé à chaque compilation (Android Studio, autre PC, générateur)
    // → les nouvelles versions s'installent PAR-DESSUS l'ancienne, sans désinstaller.
    // Priorité : signing/debug.keystore (clé du générateur d'APK, si vous la copiez ici), sinon signing/mydm.keystore.
    // NE SUPPRIMEZ PAS et NE CHANGEZ PAS ce fichier : sans lui, plus aucune mise à jour ne passerait.
    val fixedKey = listOf("debug.keystore", "mydm.keystore").map { rootProject.file("signing/$it") }.firstOrNull { it.exists() }
    signingConfigs {
        if (fixedKey != null) create("fixed") {
            storeFile = fixedKey
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    buildTypes {
        getByName("debug") { if (fixedKey != null) signingConfig = signingConfigs.getByName("fixed") }
        getByName("release") { if (fixedKey != null) signingConfig = signingConfigs.getByName("fixed") }
    }
    buildFeatures { compose = true }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    defaultConfig { ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a", "x86_64") } }
    packaging { jniLibs { useLegacyPackaging = true } }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")
    // Lecteur intégré vidéo / audio (mkv, mp4, webm, mp3, flac, ogg, HLS…)
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.4.1")
    implementation("androidx.media3:media3-ui:1.4.1")
    // yt-dlp embarqué : YouTube, Facebook, TikTok, HLS... (Maven Central)
    implementation("io.github.junkfood02.youtubedl-android:library:0.18.1")
    implementation("io.github.junkfood02.youtubedl-android:ffmpeg:0.18.1")
}
