package com.example.mydm.core

import android.net.Uri
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import java.util.UUID

enum class MediaType { VIDEO, HLS, AUDIO, APK, PDF, ARCHIVE }

data class DetectedMedia(
    val url: String, val type: MediaType, val pageUrl: String?, val pageTitle: String?,
    val userAgent: String, val cookies: String?, val referer: String?
)

object MediaDetector {
    private val extMap = mapOf(
        "mp4" to MediaType.VIDEO, "webm" to MediaType.VIDEO, "mkv" to MediaType.VIDEO,
        "m3u8" to MediaType.HLS, "mp3" to MediaType.AUDIO, "m4a" to MediaType.AUDIO,
        "apk" to MediaType.APK, "pdf" to MediaType.PDF,
        "zip" to MediaType.ARCHIVE, "rar" to MediaType.ARCHIVE
    )
    fun detect(url: String): MediaType? {
        val path = Uri.parse(url).path ?: return null
        return extMap[path.lowercase().substringAfterLast('.', "")]
    }
}

enum class Status { QUEUED, RUNNING, PAUSED, MERGING, COMPLETED, FAILED }

@Entity(tableName = "tasks")
data class DownloadTask(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val url: String, val fileName: String, val mimeType: String?,
    val totalBytes: Long = -1, val status: Status = Status.QUEUED,
    val headersJson: String = "{}", val maxSegments: Int = 8,
    val resultUri: String? = null, val error: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "segments", primaryKeys = ["taskId", "idx"])
data class Segment(val taskId: String, val idx: Int, val start: Long, val end: Long)

@Dao
interface DownloadDao {
    @Query("SELECT * FROM tasks ORDER BY createdAt DESC") fun observeTasks(): Flow<List<DownloadTask>>
    @Query("SELECT * FROM tasks WHERE id = :id") suspend fun task(id: String): DownloadTask?
    @Upsert suspend fun upsert(t: DownloadTask)
    @Query("UPDATE tasks SET status = :s, error = :e WHERE id = :id") suspend fun setStatus(id: String, s: Status, e: String?)
    @Query("SELECT * FROM segments WHERE taskId = :id ORDER BY idx") suspend fun segments(id: String): List<Segment>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertSegments(s: List<Segment>)
    @Query("DELETE FROM tasks WHERE id = :id") suspend fun delete(id: String)
    @Query("DELETE FROM segments WHERE taskId = :id") suspend fun deleteSegments(id: String)
}

class Converters {
    @TypeConverter fun toStatus(v: String) = Status.valueOf(v)
    @TypeConverter fun fromStatus(s: Status) = s.name
}

@Database(entities = [DownloadTask::class, Segment::class], version = 1, exportSchema = false)
@TypeConverters(Converters::class)
abstract class AppDb : RoomDatabase() { abstract fun downloadDao(): DownloadDao }
