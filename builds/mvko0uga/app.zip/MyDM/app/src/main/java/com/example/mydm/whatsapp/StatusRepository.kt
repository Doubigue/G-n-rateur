package com.example.mydm.whatsapp

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class WaApp(val label: String, val pkg: String, val rootFolders: List<String>) {
    WHATSAPP("WhatsApp", "com.whatsapp", listOf("WhatsApp")),
    BUSINESS("WhatsApp Business", "com.whatsapp.w4b", listOf("WhatsApp Business", "WhatsApp"))
}

data class StatusItem(val uri: Uri, val name: String, val mime: String, val size: Long, val modified: Long) {
    val isVideo get() = mime.startsWith("video/")
}

data class ScanResult(val items: List<StatusItem>, val message: String)

class StatusRepository(private val context: Context) {
    private val prefs = context.getSharedPreferences("wa", Context.MODE_PRIVATE)

    fun initialUri(app: WaApp): Uri = DocumentsContract.buildDocumentUri(
        "com.android.externalstorage.documents", "primary:Android/media/${app.pkg}")

    fun persistGrant(app: WaApp, treeUri: Uri) {
        context.contentResolver.takePersistableUriPermission(treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        prefs.edit().putString(app.pkg, treeUri.toString()).apply()
    }

    fun hasGrant(app: WaApp) = prefs.getString(app.pkg, null) != null

    /** Cherche ".Statuses" dans le dossier autorisé, quel que soit le niveau choisi par l'utilisateur. */
    private fun findStatusesDir(root: DocumentFile, app: WaApp): DocumentFile? {
        if (root.name == ".Statuses") return root
        val hints = listOf("Android", "media", app.pkg, "WhatsApp Business", "WhatsApp", "Media")
        var level = listOf(root)
        repeat(6) {
            val next = mutableListOf<DocumentFile>()
            for (d in level) for (c in d.listFiles()) {
                if (!c.isDirectory) continue
                val n = c.name ?: continue
                if (n == ".Statuses") return c
                // WhatsApp standard : ignorer les dossiers de la version Business
                if (app == WaApp.WHATSAPP && (n == "com.whatsapp.w4b" || n == "WhatsApp Business")) continue
                next.add(c)
            }
            level = next.sortedBy { c -> hints.indexOf(c.name).let { if (it < 0) 99 else it } }.take(150)
        }
        return null
    }

    private fun mimeOf(f: DocumentFile): String? {
        val t = f.type
        if (t != null && t != "application/octet-stream") return t
        return when (f.name?.substringAfterLast('.', "")?.lowercase()) {
            "jpg", "jpeg" -> "image/jpeg"; "png" -> "image/png"; "webp" -> "image/webp"; "gif" -> "image/gif"
            "mp4", "m4v" -> "video/mp4"; "3gp" -> "video/3gpp"; "mkv" -> "video/x-matroska"; "webm" -> "video/webm"
            else -> null
        }
    }

    suspend fun scan(app: WaApp): ScanResult = withContext(Dispatchers.IO) {
        val tree = prefs.getString(app.pkg, null)?.let(Uri::parse)
            ?: return@withContext ScanResult(emptyList(), "Accès non autorisé.")
        val root = DocumentFile.fromTreeUri(context, tree)
        if (root == null || !root.exists())
            return@withContext ScanResult(emptyList(), "Le dossier autorisé est introuvable. Choisissez-le à nouveau.")
        val dir = findStatusesDir(root, app)
            ?: return@withContext ScanResult(emptyList(),
                "Dossier « .Statuses » introuvable dans « ${root.name} ».\nChoisissez Android/media/${app.pkg} " +
                "(ou « WhatsApp/Media » sur Android 10), puis appuyez sur « Utiliser ce dossier ».")
        val files = dir.listFiles()
        val items = files.filter { it.isFile }.mapNotNull { f ->
            mimeOf(f)?.takeIf { it.startsWith("image/") || it.startsWith("video/") }
                ?.let { StatusItem(f.uri, f.name ?: "status", it, f.length(), f.lastModified()) }
        }.sortedByDescending { it.modified }
        ScanResult(items, if (items.isEmpty())
            "Dossier trouvé (${files.size} élément(s)) mais aucun statut.\nOuvrez WhatsApp, visionnez des statuts, puis actualisez." else "")
    }

    suspend fun save(item: StatusItem): Uri = withContext(Dispatchers.IO) {
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, item.name)
            put(MediaStore.Downloads.MIME_TYPE, item.mime)
            put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/Statuses")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val resolver = context.contentResolver
        val dest = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)!!
        resolver.openInputStream(item.uri)!!.use { i -> resolver.openOutputStream(dest)!!.use { o -> i.copyTo(o) } }
        resolver.update(dest, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
        dest
    }
}
