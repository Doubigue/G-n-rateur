package com.example.mydm.downloader

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.webkit.URLUtil
import com.example.mydm.core.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import okhttp3.*
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

data class Progress(val downloaded: Long, val total: Long, val speedBps: Long)

class DownloadEngine(
    private val context: Context,
    private val dao: DownloadDao,
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build()
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val jobs = ConcurrentHashMap<String, Job>()
    private val _progress = MutableStateFlow<Map<String, Progress>>(emptyMap())
    val progress: StateFlow<Map<String, Progress>> = _progress
    val activeCount get() = jobs.values.count { it.isActive }

    private val partsDir get() = File(context.getExternalFilesDir(null), "parts").apply { mkdirs() }
    private fun part(id: String, i: Int) = File(partsDir, "$id.part$i")

    fun start(id: String) {
        if (jobs[id]?.isActive == true) return
        jobs[id] = scope.launch {
            try { runTask(id) }
            catch (e: CancellationException) {
                withContext(NonCancellable) { dao.setStatus(id, Status.PAUSED, null) }
                _progress.update { it - id }
                throw e
            } catch (e: Exception) {
                dao.setStatus(id, Status.FAILED, e.message)
                _progress.update { it - id }
            }
        }
    }

    fun pause(id: String) { jobs.remove(id)?.cancel() }   // les .part restent => reprise possible

    fun cancel(id: String) {
        pause(id)
        scope.launch {
            partsDir.listFiles { f -> f.name.startsWith(id) }?.forEach { it.delete() }
            dao.deleteSegments(id); dao.delete(id)
        }
    }

    /** Crée la tâche en base (headers rejoués : UA, cookies, referer). */
    suspend fun enqueue(m: DetectedMedia): String {
        val headers = JSONObject().apply {
            put("User-Agent", m.userAgent)
            m.cookies?.let { put("Cookie", it) }
            m.referer?.let { put("Referer", it) }
        }.toString()
        val task = DownloadTask(url = m.url, fileName = URLUtil.guessFileName(m.url, null, null),
            mimeType = null, headersJson = headers)
        dao.upsert(task)
        return task.id
    }

    private suspend fun runTask(id: String) {
        val task = dao.task(id) ?: return
        val headers = task.headersJson.toHeaders()
        dao.setStatus(id, Status.RUNNING, null)

        var segs = dao.segments(id)
        var total = task.totalBytes
        if (segs.isEmpty()) {
            val probe = probe(task.url, headers)
            total = probe.length
            segs = plan(id, probe, task.maxSegments)
            dao.insertSegments(segs)
            dao.upsert(task.copy(totalBytes = total, status = Status.RUNNING))
        }
        val ranged = total > 0 && segs.first().end >= 0

        val ticker = scope.launch {
            var last = segs.sumOf { part(id, it.idx).length() }; var lastT = System.nanoTime()
            while (isActive) {
                delay(500)
                val done = segs.sumOf { part(id, it.idx).length() }
                val now = System.nanoTime()
                val speed = ((done - last) * 1_000_000_000L) / (now - lastT).coerceAtLeast(1)
                last = done; lastT = now
                _progress.update { it + (id to Progress(done, total, speed)) }
            }
        }
        try {
            coroutineScope { segs.map { s -> async { downloadSegment(task.url, headers, id, s, ranged) } }.awaitAll() }
        } finally { ticker.cancel() }

        dao.setStatus(id, Status.MERGING, null)
        val uri = merge(task, segs)
        dao.upsert(dao.task(id)!!.copy(status = Status.COMPLETED, resultUri = uri.toString()))
        _progress.update { it - id }
    }

    private data class Probe(val length: Long, val acceptsRanges: Boolean)

    private fun probe(url: String, headers: Headers): Probe {
        val req = Request.Builder().url(url).headers(headers).header("Range", "bytes=0-0").build()
        client.newCall(req).execute().use { r ->
            return when {
                r.code == 206 -> {
                    val total = r.header("Content-Range")?.substringAfter('/')?.toLongOrNull() ?: -1
                    Probe(total, total > 0)
                }
                r.isSuccessful -> Probe(r.header("Content-Length")?.toLongOrNull() ?: -1, false)
                else -> throw IOException("HTTP ${r.code}")
            }
        }
    }

    private fun plan(id: String, p: Probe, maxSeg: Int): List<Segment> {
        if (!p.acceptsRanges || p.length <= 0) return listOf(Segment(id, 0, 0, -1))
        val n = if (p.length < 1_000_000) 1 else maxSeg
        val size = p.length / n
        return (0 until n).map { i ->
            Segment(id, i, i * size, if (i == n - 1) p.length - 1 else (i + 1) * size - 1)
        }
    }

    private suspend fun downloadSegment(url: String, headers: Headers, id: String, s: Segment, ranged: Boolean) {
        val file = part(id, s.idx)
        var attempt = 0
        while (true) {
            try {
                val already = if (ranged && file.exists()) file.length() else 0L
                if (ranged && s.start + already > s.end) return          // segment déjà complet

                val rb = Request.Builder().url(url).headers(headers)
                if (ranged) rb.header("Range", "bytes=${s.start + already}-${s.end}")
                val call = client.newCall(rb.build())
                val h = currentCoroutineContext()[Job]!!.invokeOnCompletion { call.cancel() }
                try {
                    call.execute().use { r ->
                        if (ranged && r.code != 206) throw IOException("Range non respecté (${r.code})")
                        if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
                        FileOutputStream(file, ranged).use { out ->
                            val buf = ByteArray(64 * 1024)
                            val input = r.body!!.byteStream()
                            while (true) {
                                currentCoroutineContext().ensureActive()
                                val n = input.read(buf); if (n < 0) break
                                out.write(buf, 0, n)
                            }
                        }
                    }
                } finally { h.dispose() }
                return
            } catch (e: CancellationException) { throw e }
            catch (e: IOException) {
                if (++attempt >= 5) throw e
                delay(1000L * attempt)
            }
        }
    }

    private fun merge(task: DownloadTask, segs: List<Segment>): Uri {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, task.fileName)
            task.mimeType?.let { put(MediaStore.Downloads.MIME_TYPE, it) }
            put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/MyDM")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)!!
        resolver.openOutputStream(uri)!!.use { out ->
            segs.sortedBy { it.idx }.forEach { s ->
                part(task.id, s.idx).inputStream().use { it.copyTo(out, 256 * 1024) }
            }
        }
        resolver.update(uri, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
        segs.forEach { part(task.id, it.idx).delete() }
        return uri
    }

    private fun String.toHeaders(): Headers {
        val b = Headers.Builder(); val o = JSONObject(this)
        o.keys().forEach { b.add(it, o.getString(it)) }; return b.build()
    }
}
