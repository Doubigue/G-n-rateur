package com.example.mydm

import android.app.Application
import android.util.Log
import androidx.room.Room
import com.example.mydm.core.AppDb
import com.example.mydm.downloader.DownloadEngine
import com.example.mydm.torrent.TorrentEngine
import com.example.mydm.whatsapp.StatusRepository
import java.io.File

class App : Application() {
    lateinit var db: AppDb
    lateinit var downloadEngine: DownloadEngine
    lateinit var statusRepo: StatusRepository
    // Créé uniquement quand l'onglet Torrent est utilisé (charge la bibliothèque native)
    val torrentEngine by lazy { TorrentEngine(this) }

    override fun onCreate() {
        super.onCreate()
        installCrashLogger()
        db = Room.databaseBuilder(this, AppDb::class.java, "mydm.db").build()
        downloadEngine = DownloadEngine(this, db.downloadDao())
        statusRepo = StatusRepository(this)
    }

    /** Écrit la dernière erreur fatale dans un fichier ; elle est affichée au prochain lancement. */
    private fun installCrashLogger() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            runCatching { File(filesDir, "crash.txt").writeText(Log.getStackTraceString(error)) }
            previous?.uncaughtException(thread, error)
        }
    }
}
