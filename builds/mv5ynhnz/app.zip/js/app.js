import { db, auth, SETTINGS } from "../firebase-config.js";
import { collection, getDocs, doc, getDoc, setDoc, onSnapshot, query, where, updateDoc } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import { DEFAULTS, merge } from "./defaults.js";
export { SETTINGS };

/* ---------- Utilitaires ---------- */
export const $ = (s, r = document) => r.querySelector(s);
export const $$ = (s, r = document) => [...r.querySelectorAll(s)];
export const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const safeUrl = u => /^\s*(javascript|data):/i.test(u || '') ? '#' : (u || '#');
export const fmt = n => new Intl.NumberFormat(SETTINGS.locale, { style: 'currency', currency: SETTINGS.currency, maximumFractionDigits: ['EUR', 'USD', 'MAD'].includes(SETTINGS.currency) ? 2 : 0 }).format(n || 0);
export const onSale = p => p.promoPrice > 0 && p.promoPrice < p.price;
export const price = p => (onSale(p) ? p.promoPrice : p.price);
export const PH = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 200 200'%3E%3Crect width='200' height='200' fill='%23e9efee'/%3E%3Cpath d='M60 130l30-40 25 30 15-18 25 28z' fill='%23c5d2cf'/%3E%3Ccircle cx='75' cy='75' r='10' fill='%23c5d2cf'/%3E%3C/svg%3E";
export const img = p => p.images?.[0] || PH;

export function cleanHTML(html) {
  const ok = new Set(['B', 'STRONG', 'I', 'EM', 'U', 'UL', 'OL', 'LI', 'P', 'BR', 'DIV', 'H3']);
  const t = new DOMParser().parseFromString(`<body>${html || ''}`, 'text/html').body;
  (function walk(n) {
    [...n.childNodes].forEach(c => {
      if (c.nodeType === 1) {
        if (!ok.has(c.tagName)) { c.replaceWith(document.createTextNode(c.textContent)); return; }
        [...c.attributes].forEach(a => c.removeAttribute(a.name)); walk(c);
      } else if (c.nodeType !== 3) c.remove();
    });
  })(t);
  return t.innerHTML;
}

export function toast(msg, type = 'ok') {
  let box = $('#toasts');
  if (!box) {
    box = document.createElement('div'); box.id = 'toasts';
    box.className = 'fixed bottom-4 right-4 left-4 sm:left-auto z-[100] flex flex-col gap-2 items-end pointer-events-none';
    box.setAttribute('role', 'status'); box.setAttribute('aria-live', 'polite'); document.body.appendChild(box);
  }
  const t = document.createElement('div'); t.className = 'toast' + (type === 'err' ? ' err' : ''); t.textContent = msg; box.appendChild(t);
  setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 300); }, 3200);
}

export const authReady = new Promise(res => { const un = onAuthStateChanged(auth, u => { un(); res(u); }); });

/* ---------- Réglages du site (modifiables depuis l'admin) ---------- */
export const CFG = (() => { try { return merge(DEFAULTS, JSON.parse(localStorage.getItem('bz_cfg')) || {}); } catch { return merge(DEFAULTS, {}); } })();
const setCfg = n => { for (const k in CFG) delete CFG[k]; Object.assign(CFG, n); };
const mix = (hex, t = .86) => { const n = parseInt(hex.slice(1), 16), c = [n >> 16, (n >> 8) & 255, n & 255].map(v => Math.round(v + (255 - v) * t)); return `rgb(${c})`; };
const baseTitle = document.title;
function applyCfg() {
  Object.assign(SETTINGS, { shopName: CFG.shopName, email: CFG.email, logo: CFG.logo, currency: CFG.currency || SETTINGS.currency });
  const r = document.documentElement.style, c = CFG.colors;
  r.setProperty('--brand', c.brand); r.setProperty('--brand-d', c.brandDark); r.setProperty('--sun', c.accent); r.setProperty('--soft', mix(c.brand));
  const a = CFG.appearance || {};
  document.documentElement.dataset.buttonStyle = a.buttonStyle || 'solid';
  document.documentElement.dataset.buttonRadius = a.buttonRadius || 'rounded';
  document.documentElement.dataset.buttonGlow = a.buttonGlow ? '1' : '0';
  if (CFG.favicon) {
    let l = document.querySelector('link[rel~="icon"]');
    if (!l) { l = document.createElement('link'); l.rel = 'icon'; document.head.appendChild(l); }
    l.removeAttribute('type'); l.href = CFG.favicon;
  }
  document.title = baseTitle.replace('Bazario', CFG.shopName);
}
applyCfg();
export const settingsReady = (async () => {
  try {
    const s = await getDoc(doc(db, 'settings', 'site'));
    if (s.exists()) {
      const n = merge(DEFAULTS, s.data());
      if (JSON.stringify(n) !== JSON.stringify(CFG)) { setCfg(n); localStorage.setItem('bz_cfg', JSON.stringify(n)); applyCfg(); renderShell(); }
    }
  } catch (e) { console.warn('Réglages', e); }
  return CFG;
})();
export const waLink = text => {
  const n = String(CFG.whatsapp.number || '').replace(/\D/g, '');
  return CFG.whatsapp.on && n ? `https://wa.me/${n}?text=${encodeURIComponent(text || CFG.whatsapp.message)}` : '';
};
export const shippingFor = sub => { const s = CFG.shipping; if (!(s.fee > 0) || sub <= 0) return 0; return s.freeFrom > 0 && sub >= s.freeFrom ? 0 : +s.fee; };

/* ---------- Données ---------- */
let _products, _cats;
export async function loadProducts(force = false) {
  if (!_products || force) { const s = await getDocs(collection(db, 'products')); _products = s.docs.map(d => ({ id: d.id, ...d.data() })).filter(p => p.active !== false); }
  return _products;
}
export async function loadCategories() {
  if (!_cats) { const s = await getDocs(collection(db, 'categories')); _cats = s.docs.map(d => ({ id: d.id, ...d.data() })).sort((a, b) => (a.name || '').localeCompare(b.name || '')); }
  return _cats;
}

/* ---------- Favoris ---------- */
export const getFavs = () => { try { return JSON.parse(localStorage.getItem('bz_fav')) || []; } catch { return []; } };
export function toggleFav(id) { const f = getFavs(), i = f.indexOf(id); i < 0 ? f.push(id) : f.splice(i, 1); localStorage.setItem('bz_fav', JSON.stringify(f)); return i < 0; }

/* ---------- Vus récemment ---------- */
export const getRecent = () => { try { return JSON.parse(localStorage.getItem('bz_recent')) || []; } catch { return []; } };
export function pushRecent(id) { localStorage.setItem('bz_recent', JSON.stringify([id, ...getRecent().filter(x => x !== id)].slice(0, 12))); }

/* ---------- Rangées de produits défilantes (gauche / droite) ---------- */
export function rowHTML(title, href, list) {
  return `<section class="mt-10"><div class="flex items-end justify-between mb-3 gap-3"><h2 class="text-xl md:text-2xl font-bold">${title}</h2>
  <div class="flex items-center gap-2">${href ? `<a class="text-sm font-semibold text-brand hover:underline" href="${href}">Tout voir</a>` : ''}<button class="row-btn" data-dir="-1" aria-label="Défiler à gauche">‹</button><button class="row-btn" data-dir="1" aria-label="Défiler à droite">›</button></div></div>
  <div class="hscroll" data-row>${list.map(p => `<div class="hitem">${productCard(p)}</div>`).join('')}</div></section>`;
}
export function wireRows(root = document) {
  root.addEventListener('click', e => {
    const b = e.target.closest('.row-btn'); if (!b) return;
    const row = b.closest('section').querySelector('[data-row]'); row.scrollBy({ left: b.dataset.dir * row.clientWidth * .85, behavior: 'smooth' });
  });
}

/* ---------- Panier ---------- */
const CK = 'bazario_cart';
export const getCart = () => { try { return JSON.parse(localStorage.getItem(CK)) || []; } catch { return []; } };
export const cartCount = () => getCart().reduce((n, i) => n + i.qty, 0);
let pushTimer;
async function pushCart() { const u = auth.currentUser; if (!u) return; try { await setDoc(doc(db, 'users', u.uid), { cart: getCart() }, { merge: true }); } catch (e) { console.warn(e); } }
export function saveCart(c) { localStorage.setItem(CK, JSON.stringify(c)); paint(); clearTimeout(pushTimer); pushTimer = setTimeout(pushCart, 600); window.dispatchEvent(new Event('cart:changed')); }
export function addToCart(p, { size = '', color = '', qty = 1 } = {}) {
  if (!(p.stock > 0)) { toast('Ce produit est en rupture de stock', 'err'); return false; }
  const key = [p.id, size, color].join('|'), c = getCart(), it = c.find(i => i.key === key);
  if (it) it.qty = Math.min(it.qty + qty, p.stock);
  else c.push({ key, id: p.id, title: p.title, image: p.images?.[0] || '', price: price(p), size, color, qty: Math.min(qty, p.stock) });
  saveCart(c); toast(`« ${p.title} » ajouté au panier`); return true;
}

/* ---------- Session, synchro panier, messagerie ---------- */
let curUser = null, unsubMsg = null;
export let MSGS = [];
function paint() {
  const a = $('#acct-label'); if (a) a.textContent = curUser ? (curUser.displayName || curUser.email || 'Mon foyer').split(' ')[0] : 'Connexion';
  $$('.cart-badge').forEach(b => { const n = cartCount(); b.textContent = n; b.classList.toggle('hidden', n === 0); });
  $$('.msg-badge').forEach(m => { const n = MSGS.filter(x => x.from === 'admin' && !x.read).length; m.textContent = n; m.classList.toggle('hidden', n === 0); });
}
onAuthStateChanged(auth, async u => {
  curUser = u; unsubMsg?.(); unsubMsg = null; MSGS = []; paint();
  if (!u) return;
  let first = true;
  unsubMsg = onSnapshot(query(collection(db, 'messages'), where('userId', '==', u.uid)), s => {
    MSGS = s.docs.map(d => ({ id: d.id, ...d.data() })).sort((a, b) => (a.createdAt?.seconds ?? 9e9) - (b.createdAt?.seconds ?? 9e9));
    if (!first) s.docChanges().forEach(c => { if (c.type === 'added' && c.doc.data().from === 'admin') toast('Nouveau message de la boutique'); });
    first = false; paint(); window.dispatchEvent(new Event('messages:changed'));
  }, e => console.warn('Messages', e));
  try {
    const s = await getDoc(doc(db, 'users', u.uid));
    const remote = s.exists() ? (s.data().cart || []) : [], local = getCart(), map = new Map();
    [...remote, ...local].forEach(i => { const e = map.get(i.key); map.set(i.key, e ? { ...e, qty: Math.max(e.qty, i.qty) } : i); });
    const merged = [...map.values()];
    if (JSON.stringify(merged) !== JSON.stringify(local)) { localStorage.setItem(CK, JSON.stringify(merged)); window.dispatchEvent(new Event('cart:changed')); }
    paint(); if (JSON.stringify(merged) !== JSON.stringify(remote)) pushCart();
  } catch (e) { console.warn(e); }
});
window.addEventListener('storage', paint);
export const markRead = async list => { for (const m of list) { try { await updateDoc(doc(db, 'messages', m.id), { read: true }); } catch { } } };

/* ---------- Cartes produit ---------- */
export function productCard(p) {
  const s = onSale(p), out = !(p.stock > 0), pct = s ? Math.round(100 - (p.promoPrice / p.price) * 100) : 0, fav = getFavs().includes(p.id);
  return `<article class="card pcard">
  <button class="fav" data-fav="${p.id}" aria-pressed="${fav}" aria-label="Favori"><svg width="18" height="18" viewBox="0 0 24 24"><path d="M12 21s-7-4.6-9.3-9A5.4 5.4 0 0 1 12 6a5.4 5.4 0 0 1 9.3 6c-2.3 4.4-9.3 9-9.3 9z"/></svg></button>
  <a href="produit-detail.html?id=${p.id}" class="block flex-1">
    <div class="ph"><img loading="lazy" src="${esc(img(p))}" alt="${esc(p.title)}" onerror="this.onerror=null;this.src='${PH}'">
      <div class="absolute left-2 top-2 flex gap-1 flex-wrap">${s ? `<span class="badge badge-promo">-${pct}%</span>` : ''}${p.flash ? '<span class="badge badge-flash">Vente flash</span>' : ''}${out ? '<span class="badge badge-out">Rupture</span>' : ''}</div></div>
    <div class="p-3"><p class="text-xs muted">${esc(p.category || '')}</p>
      <h3 class="font-semibold leading-snug line-clamp-2 min-h-[2.6em]">${esc(p.title)}</h3>
      <p class="mt-1 font-bold">${fmt(price(p))} ${s ? `<span class="old font-normal">${fmt(p.price)}</span>` : ''}</p></div></a>
  <div class="px-3 pb-3"><button class="btn btn-ghost btn-sm w-full" data-add="${p.id}" ${out ? 'disabled' : ''}>${out ? 'Indisponible' : 'Ajouter au panier'}</button></div></article>`;
}
export function wireCards(root, list) {
  root.addEventListener('click', e => {
    const f = e.target.closest('[data-fav]');
    if (f) { const on = toggleFav(f.dataset.fav); f.setAttribute('aria-pressed', on); toast(on ? 'Ajouté aux favoris' : 'Retiré des favoris'); return; }
    const b = e.target.closest('[data-add]'); if (!b) return;
    const p = list.find(x => x.id === b.dataset.add); if (!p) return;
    if (p.variants?.sizes?.length || p.variants?.colors?.length) { location.href = `produit-detail.html?id=${p.id}`; return; }
    addToCart(p);
  });
}

/* ---------- Petit splash de navigation ---------- */
let splashTimer;
export function showNavSplash() {
  if (!CFG.appearance?.splashOn) return;
  let el = document.getElementById('nav-splash');
  if (!el) { el = document.createElement('div'); el.id = 'nav-splash'; el.setAttribute('aria-hidden', 'true'); el.innerHTML = '<div class="nav-splash-mark"></div>'; document.body.appendChild(el); }
  el.dataset.style = CFG.appearance?.splashStyle || 'pulse';
  el.classList.remove('show'); void el.offsetWidth; el.classList.add('show');
  clearTimeout(splashTimer); splashTimer = setTimeout(() => el.classList.remove('show'), +(CFG.appearance?.splashDuration || 280));
}
function wireNavigationSplash() {
  document.addEventListener('click', e => {
    const a = e.target.closest('a[href]'); if (!a) return;
    if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    if (a.target === '_blank' || a.hasAttribute('download')) return;
    const href = a.getAttribute('href') || '';
    if (!href || href.startsWith('#') || /^(mailto:|tel:|javascript:|https?:\/\/)/i.test(href)) return;
    showNavSplash();
  }, true);
}
wireNavigationSplash();

/* ---------- En-tête / pied de page / WhatsApp ---------- */
const SOC = { facebook: 'Facebook', instagram: 'Instagram', tiktok: 'TikTok', youtube: 'YouTube', x: 'X' };
export function renderShell() {
  const H = CFG.header, F = CFG.footer;
  const h = $('#app-header');
  if (h) h.innerHTML = `
  ${H.announceOn && H.announce ? `<div class="bg-brand-dark text-white text-xs text-center py-1.5 px-2">${H.announceLink ? `<a class="underline" href="${esc(safeUrl(H.announceLink))}">${esc(H.announce)}</a>` : esc(H.announce)}</div>` : ''}
  <div class="sticky top-0 z-40 bg-white/95 backdrop-blur border-b border-[var(--line)]">
    <div class="max-w-7xl mx-auto px-4 h-16 flex items-center gap-3">
      <a href="index.html" class="shrink-0" aria-label="${esc(CFG.shopName)}">${CFG.logo ? `<img src="${esc(CFG.logo)}" alt="${esc(CFG.shopName)}" class="h-9 w-auto max-w-[9rem] object-contain">` : `<span class="font-display text-2xl font-extrabold text-brand">${esc(CFG.shopName)}</span>`}</a>
      <nav class="hidden lg:flex gap-5 text-sm font-medium ml-4" aria-label="Navigation principale">${H.nav.map(l => `<a class="hover:text-brand" href="${esc(safeUrl(l.url))}">${esc(l.label)}</a>`).join('')}</nav>
      ${H.showSearch ? `<form action="produits.html" class="hidden md:block flex-1 max-w-md ml-auto"><input name="q" class="input" placeholder="Rechercher un produit" aria-label="Rechercher un produit"></form>` : ''}
      <span class="flex-1 md:hidden"></span>
      <a href="foyer.html#messages" class="btn btn-ghost relative ml-auto md:ml-0" aria-label="Messages"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9a6 6 0 0 1 12 0c0 6 2 7 2 7H4s2-1 2-7z"/><path d="M10 20a2 2 0 0 0 4 0"/></svg><span class="msg-badge hidden absolute -top-2 -right-2 bg-promo text-white text-xs font-bold rounded-full min-w-[1.2rem] h-[1.2rem] grid place-items-center px-1">0</span></a>
      <div class="hidden md:flex items-center gap-3">
        <a href="produits.html?fav=1" class="btn btn-ghost" aria-label="Favoris"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 21s-7-4.6-9.3-9A5.4 5.4 0 0 1 12 6a5.4 5.4 0 0 1 9.3 6c-2.3 4.4-9.3 9-9.3 9z"/></svg></a>
        <a href="foyer.html" class="btn btn-ghost" aria-label="Mon compte"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/></svg><span id="acct-label">Connexion</span></a>
        <a href="panier.html" class="btn btn-primary relative" aria-label="Panier"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 4h2l2.5 11h10L20 7H6"/><circle cx="9" cy="20" r="1.5"/><circle cx="17" cy="20" r="1.5"/></svg>Panier<span class="cart-badge hidden absolute -top-2 -right-2 bg-sun text-[#1b1300] text-xs font-bold rounded-full min-w-[1.3rem] h-[1.3rem] grid place-items-center px-1">0</span></a>
      </div>
    </div>
    ${H.showSearch ? `<form action="produits.html" class="md:hidden px-4 pb-3"><input name="q" class="input" placeholder="Rechercher un produit" aria-label="Rechercher un produit"></form>` : ''}
  </div>`;
  const f = $('#app-footer');
  const soc = Object.entries(F.socials || {}).filter(([, v]) => v);
  if (f) f.innerHTML = `<div class="mt-16 bg-brand-dark text-white"><div class="max-w-7xl mx-auto px-4 py-10 grid gap-8 sm:grid-cols-3 text-sm">
    <div>${CFG.logo ? `<img src="${esc(CFG.logo)}" alt="" class="h-9 w-auto mb-2 brightness-0 invert">` : `<p class="font-display text-xl font-bold">${esc(CFG.shopName)}</p>`}<p class="opacity-70 mt-2">${esc(F.about)}</p>
      ${soc.length ? `<p class="mt-3 flex flex-wrap gap-3">${soc.map(([k, v]) => `<a class="underline opacity-90" target="_blank" rel="noopener" href="${esc(safeUrl(v))}">${SOC[k]}</a>`).join('')}</p>` : ''}</div>
    <div><p class="font-bold mb-2">Liens utiles</p><ul class="space-y-1 opacity-80">${F.links.map(l => `<li><a href="${esc(safeUrl(l.url))}">${esc(l.label)}</a></li>`).join('')}</ul></div>
    <div><p class="font-bold mb-2">Contact</p><ul class="space-y-1 opacity-80">${CFG.email ? `<li>${esc(CFG.email)}</li>` : ''}${F.phone ? `<li>${esc(F.phone)}</li>` : ''}${F.address ? `<li>${esc(F.address)}</li>` : ''}</ul></div></div>
    <div class="border-t border-white/10 text-center text-xs opacity-60 py-4">${esc(F.copyright || `© ${new Date().getFullYear()} ${CFG.shopName}. Tous droits réservés.`)}</div></div>`;
  /* Barre de navigation du bas (smartphone) */
  let nav = $('#bottom-nav'); if (!nav) { nav = document.createElement('nav'); nav.id = 'bottom-nav'; nav.className = 'bnav'; nav.setAttribute('aria-label', 'Menu mobile'); document.body.appendChild(nav); }
  const cur = location.pathname.split('/').pop() || 'index.html', fav = location.search.includes('fav=1');
  const I = d => `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
  const items = [
    ['index.html', 'Accueil', I('<path d="M3 11l9-8 9 8"/><path d="M5 10v10h5v-6h4v6h5V10"/>'), cur === 'index.html' || cur === ''],
    ['produits.html', 'Boutique', I('<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>'), cur.startsWith('produit') && !fav],
    ['produits.html?fav=1', 'Favoris', I('<path d="M12 21s-7-4.6-9.3-9A5.4 5.4 0 0 1 12 6a5.4 5.4 0 0 1 9.3 6c-2.3 4.4-9.3 9-9.3 9z"/>'), fav],
    ['panier.html', 'Panier', I('<path d="M3 4h2l2.5 11h10L20 7H6"/><circle cx="9" cy="20" r="1.5"/><circle cx="17" cy="20" r="1.5"/>') + '<span class="cart-badge nb hidden">0</span>', cur === 'panier.html'],
    ['foyer.html', 'Compte', I('<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>') + '<span class="msg-badge nb hidden">0</span>', cur === 'foyer.html'],
  ];
  nav.innerHTML = items.map(([h, l, ic, on]) => `<a href="${h}" class="${on ? 'on' : ''}" ${on ? 'aria-current="page"' : ''}><span class="relative">${ic}</span><span>${l}</span></a>`).join('');

  /* Discussion WhatsApp */
  const link = waLink();
  let w = $('#wa-float'), panel = $('#wa-panel');
  if (link) {
    if (!w) {
      w = document.createElement('button'); w.id = 'wa-float'; w.className = 'wa-float'; w.setAttribute('aria-label', 'Discuter sur WhatsApp'); w.setAttribute('aria-expanded', 'false');
      w.innerHTML = '<svg width="28" height="28" viewBox="0 0 24 24" fill="#fff"><path d="M12 2a10 10 0 0 0-8.6 15L2 22l5.2-1.4A10 10 0 1 0 12 2zm5.3 14.2c-.2.6-1.3 1.2-1.8 1.2-.5.1-1 .2-3.3-.7-2.8-1.2-4.6-4-4.7-4.2-.1-.2-1.1-1.5-1.1-2.8s.7-2 1-2.3c.2-.3.5-.3.7-.3h.5c.2 0 .4 0 .6.5l.8 2c.1.2.1.4 0 .5l-.4.6-.3.3c-.1.2-.3.3-.1.6.2.3.8 1.3 1.7 2.1 1.2 1 2.100 1.300 2.400 1.400.3.1.5.1.6-.1l.9-1.100c.2-.3.4-.2.6-.1l1.900.9c.3.1.5.2.5.3.1.2.1.8-.1 1.400z"/></svg>';
      document.body.appendChild(w);
      panel = document.createElement('div'); panel.id = 'wa-panel'; panel.className = 'wa-panel hidden'; panel.setAttribute('role', 'dialog'); panel.setAttribute('aria-label', 'Discussion WhatsApp'); document.body.appendChild(panel);
      w.onclick = () => { const open = panel.classList.toggle('hidden') === false; w.setAttribute('aria-expanded', open); };
    }
    const q = [['Suivre ma commande', 'Bonjour, je souhaite suivre ma commande.'], ['Question sur un produit', 'Bonjour, j’ai une question sur un produit.'], ['Livraison et délais', 'Bonjour, quels sont vos délais et modes de livraison ?'], ['Autre question', CFG.whatsapp.message]];
    panel.innerHTML = `<div class="wa-head"><b>${esc(CFG.shopName)}</b><span>Répond généralement rapidement</span></div>
      <div class="wa-body"><div class="wa-msg">${esc(CFG.whatsapp.greeting || 'Bonjour ! Comment pouvons-nous vous aider ?')}</div>${q.map(([l, t]) => `<a class="wa-q" target="_blank" rel="noopener" href="${waLink(t)}">${l}</a>`).join('')}</div>`;
  } else { w?.remove(); panel?.remove(); }
  paint();
}
