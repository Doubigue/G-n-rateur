import { db } from "../firebase-config.js";
import { collection, getDocs } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import {
  $, esc, fmt, price, onSale, PH, img, renderShell, loadProducts, loadCategories, wireCards,
  settingsReady, CFG, safeUrl, rowHTML, wireRows, getRecent,
} from "./app.js";

renderShell();

let products = [], cats = [], sliders = [];
try {
  [products, cats] = await Promise.all([loadProducts(), loadCategories()]);
  sliders = (await getDocs(collection(db, 'sliders'))).docs.map(d => d.data());
} catch (e) {
  console.error(e);
  $('#sections').innerHTML = '<p class="card p-6 mt-8">Impossible de charger le catalogue. Vérifiez la configuration Firebase et les règles.</p>';
}

/* ================= Carousel ================= */
const slides = [
  ...sliders.map(s => ({ title: s.title, sub: s.subtitle, image: s.image, href: s.link || 'produits.html', cta: 'Découvrir' })),
  ...products.filter(p => p.hero).map(p => ({ title: p.title, sub: onSale(p) ? `${fmt(price(p))} au lieu de ${fmt(p.price)}` : `Dès ${fmt(price(p))}`, image: img(p), href: `produit-detail.html?id=${p.id}`, cta: 'Voir le produit' })),
];
if (!slides.length) slides.push({ title: 'Tout ce qu’il vous faut, livré chez vous', sub: 'Vêtements, nourriture, électronique, accessoires et technologie.', image: PH, href: 'produits.html', cta: 'Voir la boutique' });

await settingsReady;
const C = CFG.carousel, center = C.align === 'center';
const HEIGHT = { sm: 'min-h-[15rem] md:min-h-[19rem]', md: 'min-h-[19rem] md:min-h-[25rem]', lg: 'min-h-[24rem] md:min-h-[31rem]', xl: 'min-h-[28rem] md:min-h-[38rem]' }[C.height] || '';

const textBlock = s => `<div class="${center ? 'text-center mx-auto' : ''} max-w-2xl">
  <span class="pill">À la une</span>
  <h1 class="text-3xl sm:text-4xl md:text-6xl font-extrabold leading-[1.05] mt-3">${esc(s.title)}</h1>
  <p class="mt-3 text-base md:text-lg opacity-90 max-w-md ${center ? 'mx-auto' : ''}">${esc(s.sub || '')}</p>
  <div class="mt-6 flex gap-3 flex-wrap ${center ? 'justify-center' : ''}"><a href="${esc(safeUrl(s.href))}" class="btn btn-sun">${esc(s.cta)}</a><a href="produits.html" class="btn btn-glass">Toute la boutique</a></div></div>`;

const slideHTML = (s, i) => {
  const im = esc(s.image || PH), lab = `role="group" aria-label="${i + 1} sur ${slides.length}"`;
  if (C.layout === 'cover') {
    return `<div class="slide relative ${HEIGHT} flex items-end md:items-center" ${lab}>
      <img src="${im}" alt="" class="kb absolute inset-0 w-full h-full object-cover" ${i ? 'loading="lazy"' : ''} onerror="this.onerror=null;this.src='${PH}'">
      <div class="ov ${center ? 'c' : ''} absolute inset-0" style="--ov:${C.overlay / 100}"></div>
      <div class="relative z-10 w-full p-6 pb-14 md:p-14 ${center ? 'flex justify-center' : ''}">${textBlock(s)}</div></div>`;
  }
  return `<div class="slide grid md:grid-cols-2 items-center gap-4 md:gap-8 p-5 pb-14 md:p-12 ${HEIGHT}" ${lab}>
    <div class="order-2 md:order-1">${textBlock(s)}</div>
    <div class="order-1 md:order-2"><img src="${im}" alt="" class="kb rounded-2xl w-full h-44 sm:h-60 md:h-80 object-cover shadow-2xl" onerror="this.onerror=null;this.src='${PH}'"></div></div>`;
};

const multi = slides.length > 1;
$('#hero').innerHTML = `<div class="slider ${C.rounded ? 'rounded-3xl' : ''}" style="background:${esc(C.bg)};color:${esc(C.text)}" aria-roledescription="carousel" aria-label="À la une">
  <div class="${C.transition === 'slide' ? 'track' : 'fade'}" id="track">${slides.map(slideHTML).join('')}</div>
  ${multi && C.arrows ? '<button class="sl-btn left-3" id="prev" aria-label="Précédent">‹</button><button class="sl-btn right-3" id="next" aria-label="Suivant">›</button>' : ''}
  ${multi && C.dots ? `<div class="absolute bottom-5 ${center ? 'left-1/2 -translate-x-1/2' : 'left-6 md:left-14'} flex items-center gap-2 z-[5]">${slides.map((_, i) => `<button class="dot" aria-label="Aller à la bannière ${i + 1}"></button>`).join('')}</div>` : ''}
  ${multi ? `<span class="sl-count" id="cnt"></span><div class="sl-progress" id="prog" style="--dur:${Math.max(2, C.interval)}s"><i></i></div>` : ''}
</div>`;

const els = [...document.querySelectorAll('.slide')], dots = [...document.querySelectorAll('.dot')], track = $('#track');
let cur = 0, timer;
const pad = n => String(n).padStart(2, '0');
const restartBar = () => { const p = $('#prog'); if (!p) return; p.classList.remove('run'); void p.offsetWidth; if (C.autoplay) p.classList.add('run'); };
function go(n) {
  cur = (n + els.length) % els.length;
  if (C.transition === 'slide') track.style.transform = `translateX(-${cur * 100}%)`;
  els.forEach((e, i) => e.classList.toggle('on', i === cur));
  dots.forEach((d, i) => d.classList.toggle('on', i === cur));
  const c = $('#cnt'); if (c) c.textContent = `${pad(cur + 1)} / ${pad(els.length)}`;
  restartBar();
}
go(0);
if (multi) {
  const play = () => { clearInterval(timer); if (C.autoplay && !matchMedia('(prefers-reduced-motion: reduce)').matches) timer = setInterval(() => go(cur + 1), Math.max(2, C.interval) * 1000); restartBar(); };
  dots.forEach((d, i) => d.addEventListener('click', () => { go(i); play(); }));
  $('#prev')?.addEventListener('click', () => { go(cur - 1); play(); }); $('#next')?.addEventListener('click', () => { go(cur + 1); play(); });
  const sl = $('.slider'); let x0 = null;
  sl.addEventListener('touchstart', e => x0 = e.touches[0].clientX, { passive: true });
  sl.addEventListener('touchend', e => { if (x0 === null) return; const d = e.changedTouches[0].clientX - x0; if (Math.abs(d) > 50) { go(cur + (d < 0 ? 1 : -1)); play(); } x0 = null; });
  document.addEventListener('visibilitychange', () => document.hidden ? clearInterval(timer) : play());
  play();
}

/* ================= Recherche rapide ================= */
const qs = $('#qs'), sg = $('#sugg');
qs.addEventListener('input', () => {
  const v = qs.value.trim().toLowerCase();
  const m = v.length < 2 ? [] : products.filter(p => p.title?.toLowerCase().includes(v)).slice(0, 5);
  sg.innerHTML = m.map(p => `<li><a class="flex items-center gap-3 p-2 hover:bg-brand-soft" href="produit-detail.html?id=${p.id}"><img src="${esc(img(p))}" class="w-9 h-9 rounded object-cover" alt=""><span class="flex-1">${esc(p.title)}</span><b>${fmt(price(p))}</b></a></li>`).join('');
  sg.classList.toggle('hidden', !m.length);
});
document.addEventListener('click', e => { if (!e.target.closest('#quick')) sg.classList.add('hidden'); });

/* ================= Cartes catégories : style aléatoire à chaque visite ================= */
const shuffle = a => { a = [...a]; for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
const pick = n => Math.floor(Math.random() * n);
if (cats.length) {
  const palettes = shuffle([0, 1, 2, 3, 4, 5, 6, 7]);
  $('#cats').innerHTML = `<div class="hscroll">${cats.map((c, i) => {
    const list = products.filter(p => p.category === c.name), pic = list.find(p => p.images?.[0]);
    const rot = (Math.random() * 12 - 6).toFixed(1);
    return `<a href="produits.html?cat=${encodeURIComponent(c.name)}" class="cat-tile ct${palettes[i % palettes.length]} sh${pick(5)} r${pick(4)}">
      ${pic ? `<img src="${esc(pic.images[0])}" alt="" loading="lazy" style="transform:rotate(${rot}deg)" onerror="this.remove()">` : ''}
      <b>${esc(c.name)}</b><small>${list.length} produit${list.length > 1 ? 's' : ''}</small></a>`;
  }).join('')}</div>`;
} else $('#cats').innerHTML = '<span class="muted text-sm">Aucune catégorie pour le moment.</span>';

/* ================= Rangées de produits (défilement gauche / droite) ================= */
const box = $('#sections');
const rows = [
  ['Ventes flash', products.filter(p => p.flash), 'produits.html?promo=1'],
  ['Produits en promotion', products.filter(onSale), 'produits.html?promo=1'],
  ['Meilleures ventes', [...products].filter(p => p.sold > 0).sort((a, b) => b.sold - a.sold), 'produits.html?sort=best'],
  ['En vedette', products.filter(p => p.featured), 'produits.html'],
  ...cats.map(c => [c.name, products.filter(p => p.category === c.name), `produits.html?cat=${encodeURIComponent(c.name)}`]),
  ['Vus récemment', getRecent().map(id => products.find(p => p.id === id)).filter(Boolean), ''],
];
if (!products.length) box.innerHTML = '<div class="card p-8 mt-8 text-center"><p class="font-bold">Le catalogue est vide</p><p class="muted text-sm mt-1">Ajoutez vos premiers produits depuis l’administration (ou utilisez les données d’exemple).</p></div>';
else {
  box.innerHTML = rows.filter(r => r[1].length).map(r => rowHTML(esc(r[0]), r[2], r[1])).join('');
  wireCards(box, products); wireRows(box);
}
