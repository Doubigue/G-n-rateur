/* Bazario / Doubigue — modules réutilisables.
 * Dépendances CDN chargées par les pages qui utilisent ce fichier : GSAP, html2canvas, jsPDF.
 */
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money = (n, settings = {}) => new Intl.NumberFormat(settings.locale || 'fr-FR', { style:'currency', currency:settings.currency || 'XOF', maximumFractionDigits:['EUR','USD','MAD'].includes(settings.currency) ? 2 : 0 }).format(+n || 0);
const wait = ms => new Promise(r => setTimeout(r, ms));

/* ---------- 1. Complément de profil ---------- */
async function imageToDataUrl(file, maxSize = 320, quality = .82) {
  if (!file) return '';
  if (!file.type.startsWith('image/')) throw new Error('Veuillez choisir une image.');
  if (file.size > 8 * 1024 * 1024) throw new Error('La photo est trop volumineuse (8 Mo maximum).');
  const src = await new Promise((resolve, reject) => { const r = new FileReader(); r.onload = () => resolve(r.result); r.onerror = reject; r.readAsDataURL(file); });
  const img = await new Promise((resolve, reject) => { const i = new Image(); i.onload = () => resolve(i); i.onerror = reject; i.src = src; });
  const scale = Math.min(1, maxSize / Math.max(img.width, img.height));
  const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(img.width * scale)); c.height = Math.max(1, Math.round(img.height * scale));
  const ctx = c.getContext('2d'); ctx.drawImage(img, 0, 0, c.width, c.height);
  return c.toDataURL('image/jpeg', quality);
}

export function openProfileCompletionModal({ initial = {}, title = 'Complétez votre profil', onSave } = {}) {
  return new Promise(resolve => {
    const m = document.createElement('div'); m.className = 'dbx-modal'; m.innerHTML = `<div class="dbx-modal-card dbx-profile-modal" role="dialog" aria-modal="true" aria-labelledby="dbx-profile-title">
      <button class="dbx-modal-close" type="button" aria-label="Fermer">×</button>
      <h2 id="dbx-profile-title">${esc(title)}</h2><p class="dbx-muted">Ces informations permettent de personnaliser votre espace client.</p>
      <form class="dbx-profile-form">
        <div class="dbx-avatar-row"><div class="dbx-avatar" id="dbx-avatar"><span>Photo</span></div><div><label class="dbx-upload" for="dbx-photo">Choisir une photo depuis l’appareil</label><input id="dbx-photo" type="file" accept="image/*" class="dbx-file-input" aria-label="Choisir une photo de profil"><p class="dbx-help">JPG/PNG · photo compressée automatiquement</p></div></div>
        <div class="dbx-grid2"><label>Nom<input id="dbx-last" required maxlength="80" value="${esc(initial.lastName || '')}"></label><label>Prénom<input id="dbx-first" required maxlength="80" value="${esc(initial.firstName || '')}"></label></div>
        <div class="dbx-grid2"><label>Âge <span>(optionnel)</span><input id="dbx-age" type="number" min="13" max="120" value="${esc(initial.age || '')}"></label><label>Lieu de résidence<input id="dbx-city" required maxlength="120" value="${esc(initial.city || initial.residence || '')}"></label></div>
        <div class="dbx-actions"><button type="button" class="dbx-btn dbx-btn-secondary" data-skip>Plus tard</button><button class="dbx-btn dbx-btn-primary" type="submit">Enregistrer le profil</button></div>
        <p class="dbx-error" id="dbx-profile-error" aria-live="polite"></p>
      </form></div>`;
    document.body.appendChild(m);
    const form = m.querySelector('form'), photo = m.querySelector('#dbx-photo'), avatar = m.querySelector('#dbx-avatar'), err = m.querySelector('#dbx-profile-error');
    let photoDataUrl = initial.photoDataUrl || '';
    const close = result => { m.remove(); resolve(result); };
    const paintPhoto = src => { avatar.innerHTML = src ? `<img src="${esc(src)}" alt="Photo de profil">` : '<span>Photo</span>'; };
    paintPhoto(photoDataUrl);
    m.querySelector('.dbx-modal-close').onclick = () => close(null);
    m.querySelector('[data-skip]').onclick = () => close(null);
    photo.onchange = async () => { err.textContent = ''; try { photoDataUrl = await imageToDataUrl(photo.files?.[0]); paintPhoto(photoDataUrl); } catch(e) { err.textContent = e.message; } };
    form.onsubmit = async e => { e.preventDefault(); err.textContent = ''; const btn = form.querySelector('[type=submit]'); btn.disabled = true;
      try {
        const data = { firstName: m.querySelector('#dbx-first').value.trim(), lastName: m.querySelector('#dbx-last').value.trim(), age: m.querySelector('#dbx-age').value ? +m.querySelector('#dbx-age').value : null, city: m.querySelector('#dbx-city').value.trim(), photoDataUrl: photoDataUrl || '', updatedAt: new Date().toISOString() };
        if (!data.firstName || !data.lastName || !data.city) throw new Error('Nom, prénom et lieu de résidence sont requis.');
        if (data.age !== null && (data.age < 13 || data.age > 120)) throw new Error('L’âge doit être compris entre 13 et 120 ans.');
        if (typeof onSave === 'function') await onSave(data);
        close(data);
      } catch(e) { err.textContent = e.message || 'Enregistrement impossible.'; btn.disabled = false; }
    };
  });
}
export function profileToJSON(data = {}) { return JSON.stringify({ firstName:data.firstName || '', lastName:data.lastName || '', age:data.age ?? null, city:data.city || '', photoDataUrl:data.photoDataUrl || '' }); }

/* ---------- 2. Bouton de confirmation animé ---------- */
export function orderButtonHTML(label = 'Order Now') { return `<button type="button" class="btn btn-sun dbx-order-btn" id="order" data-order-animation><span class="dbx-order-label">${esc(label)}</span><span class="dbx-order-scene" aria-hidden="true"><span class="dbx-warehouse"><span class="dbx-door"></span><span class="dbx-warehouse-light"></span></span><svg class="dbx-van" viewBox="0 0 120 52"><rect x="4" y="18" width="72" height="25" rx="5" fill="#2563eb"/><path d="M76 23h20l17 14v6H76z" fill="#3b82f6"/><rect x="84" y="27" width="12" height="9" rx="1" fill="#dbeafe"/><circle cx="27" cy="45" r="6" fill="#111827"/><circle cx="91" cy="45" r="6" fill="#111827"/><circle cx="27" cy="45" r="2" fill="#e5e7eb"/><circle cx="91" cy="45" r="2" fill="#e5e7eb"/></svg></span><span class="dbx-order-done"><svg viewBox="0 0 24 24"><path d="m5 12 4 4L19 6"/></svg> Order Placed</span></button>`; }
export function initOrderButton(btn, { onConfirm } = {}) {
  if (!btn || !window.gsap || btn.dataset.dbxReady) return;
  btn.dataset.dbxReady = '1';
  const label = btn.querySelector('.dbx-order-label'), scene = btn.querySelector('.dbx-order-scene'), door = btn.querySelector('.dbx-door'), van = btn.querySelector('.dbx-van'), done = btn.querySelector('.dbx-order-done');
  const reset = () => { btn.classList.remove('is-animating','is-done'); btn.disabled = false; label.hidden = false; done.hidden = true; gsap.set(scene,{autoAlpha:0}); gsap.set(door,{scaleY:1}); gsap.set(van,{x:-135}); };
  reset();
  btn.addEventListener('click', async () => {
    if (btn.disabled || btn.classList.contains('is-animating')) return;
    btn.disabled = true; btn.classList.add('is-animating'); label.hidden = true; done.hidden = true;
    const tl = gsap.timeline();
    tl.set(scene,{autoAlpha:1}).set(van,{x:-135}).set(door,{scaleY:1,transformOrigin:'right center'})
      .to(door,{scaleY:.18,duration:.28,ease:'power2.out'})
      .to(van,{x:8,duration:.48,ease:'power2.inOut'})
      .to(door,{scaleY:1,duration:.28,ease:'power2.in'})
      .to(van,{x:150,duration:.55,ease:'power3.in'})
      .set(scene,{autoAlpha:0})
      .add(() => { btn.classList.remove('is-animating'); btn.classList.add('is-done'); done.hidden = false; });
    try { await tl; if (typeof onConfirm === 'function') await onConfirm(btn); } catch(e) { reset(); throw e; }
  });
  btn.__dbxReset = reset;
  return { reset };
}


/* ---------- PDF engine: ancienne méthode (html2canvas + jsPDF), chargement robuste ---------- */
let __pdfLoader = null;
export function ensurePdfModules() {
  if (window.html2canvas && window.jspdf?.jsPDF) return Promise.resolve();
  if (__pdfLoader) return __pdfLoader;
  const load = (src, test) => new Promise((resolve, reject) => {
    if (test()) return resolve();
    const script = document.createElement('script');
    script.src = src;
    script.async = false;
    script.onload = () => test() ? resolve() : reject(new Error('Module chargé mais API absente'));
    script.onerror = () => reject(new Error('Impossible de charger ' + src));
    document.head.appendChild(script);
  });
  __pdfLoader = (async () => {
    const errors = [];
    if (!window.html2canvas) {
      let ok = false;
      for (const src of [
        'https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js',
        'https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js',
        'https://unpkg.com/html2canvas@1.4.1/dist/html2canvas.min.js'
      ]) { try { await load(src, () => !!window.html2canvas); ok = true; break; } catch(e) { errors.push(e); } }
      if (!ok) throw new Error('Le module de capture PDF (html2canvas) ne peut pas être chargé.');
    }
    if (!window.jspdf?.jsPDF) {
      let ok = false;
      for (const src of [
        'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.2/jspdf.umd.min.js',
        'https://cdn.jsdelivr.net/npm/jspdf@2.5.2/dist/jspdf.umd.min.js',
        'https://unpkg.com/jspdf@2.5.2/dist/jspdf.umd.min.js'
      ]) { try { await load(src, () => !!window.jspdf?.jsPDF); ok = true; break; } catch(e) { errors.push(e); } }
      if (!ok) throw new Error('Le module PDF (jsPDF) ne peut pas être chargé.');
    }
  })();
  return __pdfLoader;
}

const pdfSafeName = name => String(name || 'document.pdf').replace(/[\\/:*?"<>|]+/g, '-').replace(/\.pdf$/i,'') + '.pdf';

/* ---------- 3. Carte VIP flip + PDF 2 pages ---------- */
export function vipCardHTML(customer = {}, settings = {}) { const name = `${customer.firstName || ''} ${customer.lastName || customer.name || ''}`.trim() || 'Client VIP'; const photo = customer.photoDataUrl || customer.photoUrl || customer.photo || ''; const city = customer.city || customer.residence || '—'; return `<div class="dbx-vip-wrap" data-vip-card tabindex="0" aria-label="Carte VIP, cliquer pour retourner"><div class="dbx-vip-inner"><article class="dbx-vip-face dbx-vip-front"><div class="dbx-vip-brand">${esc(settings.shopName || 'Bazario')} <span>VIP</span></div><div class="dbx-vip-chip"></div><div class="dbx-vip-main"><div class="dbx-vip-photo">${photo ? `<img src="${esc(photo)}" crossorigin="anonymous" alt="">` : '<span>VIP</span>'}</div><div><small>MEMBRE VIP</small><strong>${esc(name)}</strong><span>${esc(city)}</span></div></div></article><article class="dbx-vip-face dbx-vip-back"><div class="dbx-vip-brand">${esc(settings.shopName || 'Bazario')} <span>VIP</span></div><p class="dbx-vip-title">CARTE CLIENT PRIVILÈGE</p><div class="dbx-vip-stripe"></div><p>Cette carte identifie son titulaire comme client VIP.</p><div class="dbx-vip-number">VIP · ${esc((customer.uid || customer.id || '00000000').toString().slice(0,8).toUpperCase())}</div><small>Présentez cette carte lors de vos achats.</small></article></div></div>`; }
export function initVipCard(root) { if (!root) return; const card = root.querySelector('[data-vip-card]') || root; const flip = () => card.classList.toggle('is-flipped'); card.addEventListener('click', flip); card.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); flip(); } }); }
export async function downloadVipCard(rootOrSelector, filename = 'carte-vip.pdf') {
  await ensurePdfModules();
  const root = typeof rootOrSelector === 'string' ? document.querySelector(rootOrSelector) : rootOrSelector;
  if (!root) throw new Error('Carte VIP introuvable.');
  const faces = [...root.querySelectorAll('.dbx-vip-front,.dbx-vip-back')];
  if (faces.length < 2) throw new Error('Les deux faces de la carte sont nécessaires.');

  const { jsPDF } = window.jspdf;
  const MM_W = 85.6, MM_H = 53.98;
  const PX_W = 856, PX_H = 539.8;
  const stage = document.createElement('div');
  stage.className = 'dbx-vip-export-stage';
  Object.assign(stage.style, {
    position: 'fixed', left: '-10000px', top: '0', width: `${PX_W}px`, height: `${PX_H}px`,
    overflow: 'hidden', pointerEvents: 'none', zIndex: '-1', opacity: '1',
    background: '#fff'
  });
  document.body.appendChild(stage);

  const waitImages = async el => {
    const imgs = [...el.querySelectorAll('img')];
    await Promise.all(imgs.map(img => img.complete ? Promise.resolve() : new Promise(resolve => {
      img.addEventListener('load', resolve, { once: true });
      img.addEventListener('error', resolve, { once: true });
    })));
  };

  try {
    const pdf = new jsPDF({ orientation: 'landscape', unit: 'mm', format: [MM_W, MM_H], compress: true });
    for (let i = 0; i < faces.length; i++) {
      const clone = faces[i].cloneNode(true);
      Object.assign(clone.style, {
        position: 'absolute', left: '0', top: '0', right: 'auto', bottom: 'auto', inset: 'auto', width: `${PX_W}px`, height: `${PX_H}px`,
        margin: '0', transform: 'none', backfaceVisibility: 'visible', visibility: 'visible',
        borderRadius: '0', boxSizing: 'border-box'
      });
      // La face exportée est indépendante du flip 3D de l'interface.
      clone.querySelectorAll('*').forEach(node => {
        node.style.backfaceVisibility = 'visible';
      });
      stage.appendChild(clone);
      await waitImages(clone);
      await new Promise(requestAnimationFrame);
      const canvas = await html2canvas(clone, {
        scale: 2.5,
        width: PX_W,
        height: PX_H,
        useCORS: true,
        allowTaint: false,
        backgroundColor: '#ffffff',
        logging: false,
        imageTimeout: 15000
      });
      const img = canvas.toDataURL('image/jpeg', 0.95);
      if (i > 0) pdf.addPage([MM_W, MM_H], 'landscape');
      pdf.addImage(img, 'JPEG', 0, 0, MM_W, MM_H, undefined, 'FAST');
      clone.remove();
    }
    const safeName = pdfSafeName(filename || 'carte-vip.pdf');
    // jsPDF gère lui-même le téléchargement, ce qui est plus fiable sur Android/iOS
    // que la création manuelle d'un lien Blob après html2canvas.
    pdf.save(safeName);
    return true;
  } finally {
    stage.remove();
  }
}

/* ---------- 4. Reçus thermique 80 mm / A4 ---------- */
export function receiptFormatModal() { return new Promise(resolve => { const m = document.createElement('div'); m.className='dbx-modal'; m.innerHTML=`<div class="dbx-modal-card dbx-receipt-modal" role="dialog" aria-modal="true"><button class="dbx-modal-close" aria-label="Fermer">×</button><h2>Format du reçu</h2><p class="dbx-muted">Choisissez le format du document à télécharger.</p><div class="dbx-format-grid"><button class="dbx-format" data-format="thermal"><b>🎫 Ticket Thermique</b><span>80 mm · compact · caisse</span></button><button class="dbx-format" data-format="a4"><b>📄 Facture A4</b><span>210 × 297 mm · professionnel</span></button></div></div>`; document.body.appendChild(m); const close = v => { m.remove(); resolve(v); }; m.querySelector('.dbx-modal-close').onclick=()=>close(null); m.addEventListener('click',e=>{if(e.target===m)close(null);}); m.querySelectorAll('[data-format]').forEach(b=>b.onclick=()=>close(b.dataset.format)); }); }
function receiptRows(order, settings) { return (order.items || []).map(i => ({ name:i.title || 'Article', qty:+i.qty||1, price:+i.price||0, total:(+i.qty||1)*(+i.price||0), variant:[i.size,i.color].filter(Boolean).join(' / ') })); }
function drawReceipt(pdf, order, settings, thermal=false) { const rows=receiptRows(order,settings), W=thermal?80:210, m=thermal?5:18; let y=thermal?7:18; const line=(txt,size=9,bold=false,x=m,align='left')=>{pdf.setFont('helvetica',bold?'bold':'normal');pdf.setFontSize(size);pdf.text(String(txt),x,y,{align});y+=size*.48+2;};
  pdf.setFont('helvetica','bold');pdf.setFontSize(thermal?13:18);pdf.text(settings.shopName || 'Bazario', W/2,y,{align:'center'});y+=thermal?7:10; pdf.setFont('helvetica','normal');pdf.setFontSize(thermal?8:10);pdf.text('REÇU DE COMMANDE',W/2,y,{align:'center'});y+=thermal?6:9;
  pdf.setFontSize(thermal?7.5:10); line(`Commande : ${order.number || order.id || '—'}`); line(`Date : ${order.createdAt?.toDate ? order.createdAt.toDate().toLocaleString(settings.locale||'fr-FR') : new Date().toLocaleString(settings.locale||'fr-FR')}`); line(`Client : ${order.customer?.name || order.address?.fullName || '—'}`); line(`Ville : ${order.address?.city || '—'}`); y+=2; pdf.line(m,y,W-m,y); y+=5;
  rows.forEach(r=>{ pdf.setFont('helvetica','bold');pdf.setFontSize(thermal?8:10);pdf.text(`${r.qty} × ${r.name}`.slice(0,thermal?31:55),m,y);pdf.text(money(r.total,settings),W-m,y,{align:'right'});y+=thermal?5:6; if(r.variant){pdf.setFont('helvetica','normal');pdf.setFontSize(thermal?6.5:8);pdf.text(r.variant.slice(0,thermal?36:70),m+2,y);y+=thermal?4:5;}});
  y+=2; pdf.line(m,y,W-m,y);y+=6; const vals=[['Sous-total',order.subtotal],['Remise',-(order.discount||0)],['Livraison',order.shipping||0],['TOTAL',order.total]]; vals.forEach(([k,v],idx)=>{pdf.setFont('helvetica',idx===3?'bold':'normal');pdf.setFontSize(idx===3?(thermal?11:14):(thermal?8:10));pdf.text(k,m,y);pdf.text(money(v,settings),W-m,y,{align:'right'});y+=thermal?5.5:7;}); y+=4; pdf.setFont('helvetica','normal');pdf.setFontSize(thermal?7:9);pdf.text('Merci pour votre commande.',W/2,y,{align:'center'}); return y+m; }
function receiptHTML(order, settings, thermal=false) {
  const rows=receiptRows(order,settings);
  const money=(n)=>new Intl.NumberFormat(settings.locale||'fr-FR',{style:'currency',currency:settings.currency||'XOF',maximumFractionDigits:(settings.currency||'XOF')==='EUR'?2:0}).format(Number(n)||0);
  const shop=esc(settings.shopName||'Bazario');
  const date=order.createdAt?.toDate ? order.createdAt.toDate().toLocaleString(settings.locale||'fr-FR') : new Date().toLocaleString(settings.locale||'fr-FR');
  return `<div class="dbx-pdf-receipt ${thermal?'thermal':'a4'}" style="background:#ffffff;color:#10201f;font-family:Arial,Helvetica,sans-serif;box-sizing:border-box;padding:${thermal?'18px':'55px'};width:${thermal?'302px':'794px'};min-height:${thermal?'auto':'1123px'}">
    <div style="text-align:center;border-bottom:3px solid #0f4c47;padding-bottom:${thermal?'12px':'18px'};margin-bottom:${thermal?'12px':'20px'}">
      <div style="font-size:${thermal?'23px':'31px'};font-weight:800;color:#0f4c47">${shop}</div>
      <div style="font-size:${thermal?'12px':'15px'};font-weight:700;color:#5b6d6b;margin-top:5px">REÇU DE COMMANDE</div>
    </div>
    <div style="font-size:${thermal?'11px':'14px'};line-height:1.7;margin-bottom:14px">
      <div><b>Commande :</b> ${esc(order.number||order.id||'—')}</div>
      <div><b>Date :</b> ${esc(date)}</div>
      <div><b>Client :</b> ${esc(order.customer?.name||order.address?.fullName||'—')}</div>
      <div><b>Ville :</b> ${esc(order.address?.city||'—')}</div>
    </div>
    <table style="width:100%;border-collapse:collapse;font-size:${thermal?'11px':'14px'}">
      <thead><tr style="background:#0f4c47;color:#fff"><th style="padding:9px;text-align:left">Article</th><th style="padding:9px;text-align:center">Qté</th><th style="padding:9px;text-align:right">Total</th></tr></thead>
      <tbody>${rows.map(r=>`<tr><td style="padding:9px;border-bottom:1px solid #dce6e4"><b>${esc(r.name)}</b>${r.variant?`<br><small style="color:#5b6d6b">${esc(r.variant)}</small>`:''}</td><td style="padding:9px;border-bottom:1px solid #dce6e4;text-align:center">${r.qty}</td><td style="padding:9px;border-bottom:1px solid #dce6e4;text-align:right">${money(r.total)}</td></tr>`).join('')}</tbody>
    </table>
    <div style="margin-top:18px;margin-left:auto;width:${thermal?'100%':'300px'};font-size:${thermal?'12px':'14px'}">
      <div style="display:flex;justify-content:space-between;padding:5px 0"><span>Sous-total</span><b>${money(order.subtotal)}</b></div>
      <div style="display:flex;justify-content:space-between;padding:5px 0"><span>Remise</span><b>- ${money(order.discount||0)}</b></div>
      <div style="display:flex;justify-content:space-between;padding:5px 0"><span>Livraison</span><b>${money(order.shipping||0)}</b></div>
      <div style="display:flex;justify-content:space-between;padding:10px 0;margin-top:5px;border-top:3px solid #0f4c47;color:#0f4c47;font-size:${thermal?'16px':'20px'}"><b>TOTAL</b><b>${money(order.total)}</b></div>
    </div>
    <div style="text-align:center;margin-top:${thermal?'20px':'50px'};font-size:${thermal?'10px':'13px'};color:#5b6d6b">Merci pour votre commande.</div>
  </div>`;
}

export async function downloadOrderReceipt(order, settings = {}, format = null) {
  const f=format || await receiptFormatModal();
  if (!f) return false;
  await ensurePdfModules();
  const {jsPDF}=window.jspdf;
  const thermal=f==='thermal';
  const stage=document.createElement('div');
  stage.style.cssText=`position:fixed;left:-20000px;top:0;z-index:-9999;background:#fff;overflow:hidden;width:${thermal?302:794}px;`;
  stage.innerHTML=receiptHTML(order,settings,thermal);
  document.body.appendChild(stage);
  try {
    await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));
    const target=stage.firstElementChild;
    const canvas=await html2canvas(target,{scale:2.5,useCORS:true,allowTaint:false,backgroundColor:'#ffffff',logging:false,imageTimeout:15000,windowWidth:thermal?302:794});
    const img=canvas.toDataURL('image/jpeg',0.96);
    const height=thermal?Math.max(70,Math.min(400,canvas.height/canvas.width*80)):297;
    const pdf=new jsPDF({orientation:'portrait',unit:'mm',format:thermal?[80,height]:'a4',compress:true});
    const pageW=thermal?80:210;
    const pageH=height;
    pdf.addImage(img,'JPEG',0,0,pageW,pageH,undefined,'FAST');
    pdf.save(pdfSafeName(`${order.number||'commande'}-${thermal?'ticket-80mm':'facture-A4'}`));
    return true;
  } finally { stage.remove(); }
}

