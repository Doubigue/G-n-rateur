import { db, auth, SETTINGS } from "../firebase-config.js";
import { doc, getDoc, setDoc, addDoc, collection, query, where, onSnapshot, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import {
  onAuthStateChanged, signOut, signInWithEmailAndPassword, createUserWithEmailAndPassword,
  GoogleAuthProvider, signInWithPopup, signInWithRedirect, getRedirectResult, sendPasswordResetEmail, updateProfile,
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import { $, $$, esc, fmt, PH, toast, renderShell, waLink, settingsReady, MSGS, markRead, CFG } from "./app.js";

import { openProfileCompletionModal, profileToJSON, vipCardHTML, initVipCard, downloadVipCard, downloadOrderReceipt } from "./features.js";

renderShell();
await settingsReady;
const root = $('#foyer');
const STEPS = ['En attente', 'Confirmée', 'Expédiée', 'Livrée'];
const params = new URLSearchParams(location.search);
const next = (() => { const n = params.get('next'); return n && /^[\w\-./?=&%]+$/.test(n) && !n.startsWith('//') ? n : null; })();
let unsub = null, profile = {}, orders = [], tab = location.hash === '#messages' ? 'messages' : 'orders', msgOrder = '';

const host = location.hostname || 'ce domaine';
const ERR = {
  'auth/invalid-credential': 'E-mail ou mot de passe incorrect', 'auth/user-not-found': 'Aucun compte avec cet e-mail',
  'auth/wrong-password': 'Mot de passe incorrect', 'auth/email-already-in-use': 'Cet e-mail a déjà un compte. Connectez-vous.',
  'auth/weak-password': 'Mot de passe trop court (6 caractères minimum)', 'auth/invalid-email': 'Adresse e-mail invalide',
  'auth/popup-closed-by-user': `Fenêtre Google fermée avant la fin. Si elle affichait une erreur, ajoutez « ${host} » dans Firebase > Authentication > Paramètres > Domaines autorisés.`,
  'auth/unauthorized-domain': `Domaine non autorisé : ajoutez « ${host} » dans Firebase > Authentication > Paramètres > Domaines autorisés.`,
  'auth/popup-blocked': 'Popup bloquée par le navigateur : autorisez les popups pour ce site.',
  'auth/operation-not-allowed': 'Connexion Google non activée dans Firebase (Authentication > Sign-in method).',
  'auth/cancelled-popup-request': 'Connexion Google annulée, réessayez.', 'auth/network-request-failed': 'Problème de réseau, réessayez.',
  'auth/too-many-requests': 'Trop de tentatives. Réessayez plus tard.',
};
const fail = e => { console.error(e); toast((ERR[e.code] || 'Une erreur est survenue') + (ERR[e.code] ? '' : ` (${e.code || 'erreur'})`), 'err'); };
// Retour d'une connexion Google par redirection (repli si la popup est indisponible)
getRedirectResult(auth).then(async r => { if (r?.user) { await setDoc(doc(db, 'users', r.user.uid), { name: r.user.displayName || '', email: r.user.email, createdAt: serverTimestamp() }, { merge: true }); await maybeCompleteProfile(r.user); } }).catch(fail);

async function maybeCompleteProfile(u) {
  try {
    const s = await getDoc(doc(db, 'users', u.uid));
    const p = s.exists() ? s.data() : {};
    if (p.profileCompleted || CFG.isProfileCompletionEnabled === false) return p;
    const parts = String(p.name || u.displayName || '').trim().split(/\s+/);
    const initial = { firstName: p.firstName || parts.slice(0, -1).join(' '), lastName: p.lastName || parts.slice(-1).join(''), age: p.age ?? '', city: p.city || '', photoDataUrl: p.photoDataUrl || '' };
    const data = await openProfileCompletionModal({ initial, onSave: async d => {
      const name = `${d.firstName} ${d.lastName}`.trim();
      await setDoc(doc(db, 'users', u.uid), { ...d, name, email: u.email || p.email || '', profileCompleted: true, profileJSON: profileToJSON(d), updatedAt: serverTimestamp() }, { merge: true });
      await updateProfile(u, { displayName: name, photoURL: d.photoDataUrl || u.photoURL || null });
    }});
    return data || p;
  } catch (e) { console.error(e); toast('Le complément de profil pourra être effectué plus tard.', 'err'); return null; }
}

/* ---------- Vue connexion ---------- */
function authView() {
  let mode = 'login';
  root.innerHTML = `<div class="max-w-md mx-auto card p-6">
    <div class="flex gap-2 mb-5" role="tablist"><button class="chip flex-1 justify-center" data-m="login" aria-pressed="true">Connexion</button><button class="chip flex-1 justify-center" data-m="register" aria-pressed="false">Créer un compte</button></div>
    <form id="af" class="space-y-3">
      <div id="nm" class="hidden"><label class="lbl" for="name">Nom complet</label><input id="name" class="input" autocomplete="name"></div>
      <div><label class="lbl" for="em">E-mail</label><input id="em" type="email" required class="input" autocomplete="email"></div>
      <div><label class="lbl" for="pw">Mot de passe</label><input id="pw" type="password" required minlength="6" class="input" autocomplete="current-password"></div>
      <button class="btn btn-primary w-full" id="go">Se connecter</button>
    </form>
    <button id="forgot" class="text-sm underline mt-3">Mot de passe oublié ?</button>
    <div class="my-4 text-center text-xs muted">ou</div>
    <button id="gg" class="btn btn-ghost w-full">Continuer avec Google</button></div>`;
  $$('[data-m]').forEach(b => b.onclick = () => {
    mode = b.dataset.m; $$('[data-m]').forEach(x => x.setAttribute('aria-pressed', x === b));
    $('#nm').classList.toggle('hidden', mode === 'login'); $('#go').textContent = mode === 'login' ? 'Se connecter' : 'Créer mon compte';
  });
  $('#af').onsubmit = async e => {
    e.preventDefault(); const btn = $('#go'); btn.disabled = true;
    try {
      if (mode === 'login') await signInWithEmailAndPassword(auth, $('#em').value, $('#pw').value);
      else {
        const c = await createUserWithEmailAndPassword(auth, $('#em').value, $('#pw').value), name = $('#name').value.trim();
        if (name) await updateProfile(c.user, { displayName: name });
        await setDoc(doc(db, 'users', c.user.uid), { name, email: c.user.email, createdAt: serverTimestamp() }, { merge: true });
        await maybeCompleteProfile(c.user);
      }
    } catch (err) { fail(err); btn.disabled = false; }
  };
  $('#gg').onclick = async () => {
    const prov = new GoogleAuthProvider(); prov.setCustomParameters({ prompt: 'select_account' });
    try {
      const c = await signInWithPopup(auth, prov);
      await setDoc(doc(db, 'users', c.user.uid), { name: c.user.displayName || '', email: c.user.email, createdAt: serverTimestamp() }, { merge: true });
      await maybeCompleteProfile(c.user);
    } catch (err) {
      if (['auth/popup-blocked', 'auth/operation-not-supported-in-this-environment'].includes(err.code)) { try { await signInWithRedirect(auth, prov); return; } catch (e2) { return fail(e2); } }
      fail(err);
    }
  };
  $('#forgot').onclick = async () => {
    const em = $('#em').value.trim(); if (!em) return toast('Saisissez votre e-mail d’abord', 'err');
    try { await sendPasswordResetEmail(auth, em); toast('E-mail de réinitialisation envoyé'); } catch (e) { fail(e); }
  };
}

/* ---------- Vue espace client ---------- */
async function dashView(u) {
  try { const s = await getDoc(doc(db, 'users', u.uid)); profile = s.exists() ? s.data() : {}; } catch { profile = {}; }
  root.innerHTML = `<div class="flex flex-wrap items-center justify-between gap-3"><div><h1 class="text-3xl font-extrabold">Bonjour ${esc((profile.name || u.displayName || '').split(' ')[0] || 'et bienvenue')}</h1><p class="muted text-sm">${esc(u.email || '')}</p></div><button id="out" class="btn btn-ghost">Se déconnecter</button></div>
  <div class="flex gap-2 mt-5" role="tablist"><button class="chip" data-t="orders">Mes commandes</button><button class="chip" data-t="messages">Messages <span id="tab-unread" class="badge bg-promo text-white ml-1 hidden"></span></button><button class="chip" data-t="profile">Profil</button><button class="chip" data-t="addr">Adresses</button></div>
  <div id="pane" class="mt-5"></div>`;
  $('#out').onclick = () => signOut(auth);
  $$('[data-t]').forEach(b => b.onclick = () => show(b.dataset.t, u));
  unsub?.(); // commandes en temps réel (tri côté client : pas d'index composite requis)
  unsub = onSnapshot(query(collection(db, 'orders'), where('userId', '==', u.uid)), s => {
    orders = s.docs.map(d => ({ id: d.id, ...d.data() })).sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0));
    if (tab === 'orders') show('orders', u);
  }, e => { console.error(e); toast('Impossible de charger vos commandes', 'err'); });
  show(tab, u); paintUnread();
}

function show(t, u) {
  tab = t; $$('[data-t]').forEach(b => b.setAttribute('aria-pressed', b.dataset.t === t));
  const pane = $('#pane'); if (!pane) return;
  if (t === 'orders') pane.innerHTML = orders.length ? orders.map(orderCard).join('') : '<div class="card p-8 text-center"><p class="font-bold">Aucune commande pour le moment</p><a class="btn btn-primary mt-4" href="produits.html">Découvrir la boutique</a></div>';
  if (t === 'orders') pane.onclick = e => { const c = e.target.closest('[data-msg]'); if (c) { msgOrder = c.dataset.msg; show('messages', u); } };
  if (t === 'messages') msgPane(pane, u);
  if (t === 'profile') {
    pane.onclick = null;
    const vip = CFG.isVipEnabled && profile.vipEnabled === true ? `<section class="card p-4 mt-4"><div class="flex items-center justify-between gap-3 mb-3"><div><h2 class="font-bold">Carte VIP</h2><p class="text-xs muted">Cliquez sur la carte pour la retourner.</p></div><button class="btn btn-primary btn-sm" id="vip-download">Télécharger PDF</button></div><div id="vip-card-host" class="flex justify-center">${vipCardHTML({ ...profile, uid:u.uid, name:profile.name || u.displayName }, SETTINGS)}</div></section>` : '';
    pane.innerHTML = `<form id="pf" class="card p-5 max-w-lg space-y-3"><div class="dbx-avatar-row"><div class="dbx-avatar">${profile.photoDataUrl ? `<img src="${esc(profile.photoDataUrl)}" alt="">` : '<span>Photo</span>'}</div><button type="button" class="btn btn-ghost btn-sm" id="edit-profile">Compléter / modifier le profil</button></div><div><label class="lbl" for="pn">Nom complet</label><input id="pn" class="input" value="${esc(profile.name || u.displayName || '')}"></div><div><label class="lbl" for="pp">Téléphone</label><input id="pp" class="input" value="${esc(profile.phone || '')}"></div><div><label class="lbl">E-mail</label><input class="input" value="${esc(u.email || '')}" disabled></div><div><label class="lbl">Lieu de résidence</label><input id="pcity" class="input" value="${esc(profile.city || '')}"></div><button class="btn btn-primary">Enregistrer</button></form>${vip}`;
    $('#edit-profile').onclick = () => openProfileCompletionModal({ initial:{ firstName:profile.firstName || (profile.name||'').split(' ').slice(0,-1).join(' '), lastName:profile.lastName || (profile.name||'').split(' ').slice(-1).join(''), age:profile.age || '', city:profile.city || '', photoDataUrl:profile.photoDataUrl || '' }, onSave: async d => { const name=`${d.firstName} ${d.lastName}`.trim(); profile={...profile,...d,name,profileCompleted:true}; await setDoc(doc(db,'users',u.uid),{...d,name,profileCompleted:true,profileJSON:profileToJSON(d),updatedAt:serverTimestamp()},{merge:true}); await updateProfile(u,{displayName:name}); show('profile',u); }});
    $('#pf').onsubmit = async e => { e.preventDefault(); try { profile={...profile,name:$('#pn').value.trim(),phone:$('#pp').value.trim(),city:$('#pcity').value.trim()}; await setDoc(doc(db,'users',u.uid),{name:profile.name,phone:profile.phone,city:profile.city},{merge:true}); if(profile.name) await updateProfile(u,{displayName:profile.name}); toast('Profil enregistré'); } catch { toast('Enregistrement impossible','err'); } };
    if (CFG.isVipEnabled) { const host=$('#vip-card-host'); initVipCard(host); $('#vip-download').onclick=async()=>{try{await downloadVipCard(host,`carte-vip-${u.uid.slice(0,8)}.pdf`)}catch(e){console.error(e);toast(e.message||'Export VIP impossible','err')}}; }
  }
  if (t === 'addr') addrPane(pane, u);
}

function threadHTML() {
  return MSGS.length ? MSGS.map(m => {
    const me = m.from === 'client', d = m.createdAt?.toDate ? m.createdAt.toDate().toLocaleString(SETTINGS.locale, { dateStyle: 'short', timeStyle: 'short' }) : '';
    const order = m.orderId ? orders.find(o => o.id === m.orderId) : null;
    const receipt = CFG.isReceiptEnabled && m.from === 'admin' && m.kind === 'status' && m.status === 'Livrée' && order && order.status === 'Livrée'
      ? `<button class="btn btn-primary btn-sm mt-2" data-msg-inv="${esc(order.id)}">Télécharger « Reçu commande »</button>` : '';
    const vipAction = CFG.isVipEnabled && m.from === 'admin' && m.kind === 'vip_activation' && m.vipEnabled === true && profile.vipEnabled === true
      ? `<button class="btn btn-primary btn-sm mt-2" data-msg-vip>🪪 Ouvrir ma carte VIP</button>` : '';
    return `<div class="flex flex-col ${me ? 'items-end' : 'items-start'}"><div class="bubble ${me ? 'me' : 'them'}">${m.orderId ? `<span class="block text-[11px] opacity-70 mb-0.5">Commande ${esc((order || {}).number || '')}</span>` : ''}${esc(m.text)}${receipt}${vipAction}</div><span class="text-[11px] muted mt-0.5">${me ? 'Vous' : esc(SETTINGS.shopName)} · ${d}</span></div>`;
  }).join('') : '<p class="muted text-center py-8">Aucun message. Écrivez-nous, nous répondons rapidement.</p>';
}
function paintUnread() { const n = MSGS.filter(m => m.from === 'admin' && !m.read).length, b = $('#tab-unread'); if (b) { b.textContent = n; b.classList.toggle('hidden', !n); } }
async function openVipFromMessage(u) {
  if (!CFG.isVipEnabled || profile.vipEnabled !== true) return;
  const m = document.createElement('div');
  m.className = 'dbx-modal';
  m.innerHTML = `<div class="dbx-modal-card" role="dialog" aria-modal="true"><button class="dbx-modal-close" aria-label="Fermer">×</button><h2 class="text-xl font-bold mb-3">Votre carte VIP</h2><div id="dbx-message-vip-card" class="flex justify-center"></div><div class="flex justify-end gap-2 mt-4"><button class="btn btn-primary" id="dbx-message-vip-download">Télécharger la carte VIP</button></div></div>`;
  document.body.appendChild(m);
  const host = m.querySelector('#dbx-message-vip-card');
  host.innerHTML = vipCardHTML({ ...profile, uid: u.uid, name: profile.name || u.displayName }, SETTINGS);
  initVipCard(host);
  m.querySelector('.dbx-modal-close').onclick = () => m.remove();
  m.addEventListener('click', e => { if (e.target === m) m.remove(); });
  m.querySelector('#dbx-message-vip-download').onclick = async () => {
    try { await downloadVipCard(host, `Carte-VIP-${(profile.firstName || profile.name || 'Client')}-${(profile.lastName || '').trim()}.pdf`); toast('Carte VIP téléchargée'); }
    catch (e) { console.error(e); toast(e.message || 'Téléchargement impossible', 'err'); }
  };
}
function msgPane(pane, u) {
  pane.onclick = e => {
    const vipBtn = e.target.closest('[data-msg-vip]');
    if (vipBtn) { openVipFromMessage(u); return; }
    const b = e.target.closest('[data-msg-inv]'); if (!b) return;
    const o = orders.find(x => x.id === b.dataset.msgInv);
    if (o && CFG.isReceiptEnabled && o.status === 'Livrée') downloadOrderReceipt(o, SETTINGS).catch(e => toast(e.message || 'Téléchargement impossible', 'err'));
  };
  pane.innerHTML = `<div class="card max-w-2xl"><div id="thread" class="p-4 space-y-3 max-h-[55vh] overflow-y-auto bg-mist rounded-t-2xl"></div>
   <form id="mf" class="p-3 border-t border-[var(--line)] space-y-2">
    <select id="mo" class="input" aria-label="À propos de"><option value="">Question générale</option>${orders.map(o => `<option value="${o.id}" ${o.id === msgOrder ? 'selected' : ''}>À propos de la commande ${esc(o.number || o.id.slice(0, 8))}</option>`).join('')}</select>
    <div class="flex gap-2"><textarea id="mt" rows="2" maxlength="1500" required class="input" placeholder="Votre message…"></textarea><button class="btn btn-primary self-end">Envoyer</button></div></form></div>`;
  paintThread();
  $('#mf').onsubmit = async e => {
    e.preventDefault(); const text = $('#mt').value.trim(); if (!text) return;
    const data = { userId: u.uid, userName: profile.name || u.displayName || u.email || '', from: 'client', kind: 'msg', text, read: false, createdAt: serverTimestamp() };
    if ($('#mo').value) data.orderId = $('#mo').value;
    try { await addDoc(collection(db, 'messages'), data); $('#mt').value = ''; } catch (err) { console.error(err); toast('Envoi impossible', 'err'); }
  };
}
function paintThread() {
  const t = $('#thread'); if (!t) return;
  t.innerHTML = threadHTML(); t.scrollTop = t.scrollHeight;
  const unread = MSGS.filter(m => m.from === 'admin' && !m.read); if (unread.length) markRead(unread);
}
window.addEventListener('messages:changed', () => { paintUnread(); if (tab === 'messages') paintThread(); });

function addrPane(pane, u) {
  const list = profile.addresses || [];
  pane.innerHTML = `<div class="grid md:grid-cols-2 gap-5">
   <div class="space-y-3">${list.length ? list.map((a, i) => `<div class="card p-4 flex gap-3"><div class="flex-1 text-sm"><p class="font-bold">${esc(a.fullName)}</p><p>${esc(a.address)}, ${esc(a.city)}</p><p class="muted">${esc(a.phone)}</p></div><button class="btn btn-danger btn-sm h-fit" data-del="${i}">Supprimer</button></div>`).join('') : '<p class="muted">Aucune adresse enregistrée.</p>'}</div>
   <form id="af2" class="card p-5 space-y-3"><h2 class="font-bold">Nouvelle adresse</h2><input id="a1" class="input" placeholder="Nom complet" required><input id="a2" class="input" placeholder="Téléphone" required><input id="a3" class="input" placeholder="Adresse" required><input id="a4" class="input" placeholder="Ville" required><button class="btn btn-primary">Ajouter l’adresse</button></form></div>`;
  const save = async arr => { profile.addresses = arr; await setDoc(doc(db, 'users', u.uid), { addresses: arr }, { merge: true }); addrPane(pane, u); };
  pane.onclick = async e => { const b = e.target.closest('[data-del]'); if (b) { await save(list.filter((_, i) => i !== +b.dataset.del)); toast('Adresse supprimée'); } };
  $('#af2').onsubmit = async e => {
    e.preventDefault();
    const a = { fullName: $('#a1').value.trim(), phone: $('#a2').value.trim(), address: $('#a3').value.trim(), city: $('#a4').value.trim() };
    await save([...list, { ...a, label: `${a.address}, ${a.city}` }]); toast('Adresse ajoutée');
  };
}

const wl = o => waLink(`Bonjour, à propos de ma commande ${o.number || o.id} (${o.status}).`);
function orderCard(o) {
  const idx = Math.max(0, STEPS.indexOf(o.status)), d = o.createdAt?.toDate ? o.createdAt.toDate().toLocaleDateString(SETTINGS.locale) : '';
  return `<article class="card p-4 mb-4">
   <div class="flex flex-wrap justify-between gap-2"><div><p class="font-bold">Commande ${esc(o.number || o.id.slice(0, 8))}</p><p class="text-xs muted">${d}</p></div><p class="font-bold text-lg">${fmt(o.total)}</p></div>
   <ol class="steps mt-4" aria-label="Statut de la commande">${STEPS.map((s, i) => `<li class="${i <= idx ? 'done' : ''}" ${i === idx ? 'aria-current="step"' : ''}>${s}</li>`).join('')}</ol>
   <ul class="mt-4 divide-y divide-[var(--line)]">${(o.items || []).map(i => `<li class="flex items-center gap-3 py-2 text-sm"><img src="${esc(i.image || PH)}" class="w-11 h-11 rounded object-cover" alt="" onerror="this.onerror=null;this.src='${PH}'"><span class="flex-1">${esc(i.title)}<br><span class="muted text-xs">${esc([i.size, i.color].filter(Boolean).join(' / '))}</span></span><span>${i.qty} × ${fmt(i.price)}</span></li>`).join('')}</ul>
   <div class="mt-3 flex flex-wrap items-center justify-end gap-2">
     ${CFG.isReceiptEnabled ? '<span class="text-xs muted mr-auto">Le reçu est disponible uniquement dans le message de livraison.</span>' : ''}
     <button class="btn btn-ghost btn-sm" data-msg="${o.id}">Écrire à la boutique</button>${wl(o) ? `<a class="btn btn-ghost btn-sm" target="_blank" rel="noopener" href="${wl(o)}">WhatsApp</a>` : ''}</div></article>`;
}

await settingsReady;
onAuthStateChanged(auth, u => {
  unsub?.(); unsub = null;
  if (!u) { authView(); return; }
  if (next) { location.replace(next); return; }
  dashView(u);
});
