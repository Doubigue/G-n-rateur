// Générateur de reçu / facture : ouvre une page optimisée impression (Enregistrer en PDF possible)
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

export function invoiceHTML(o, S) {
  const money = n => new Intl.NumberFormat(S.locale, { style: 'currency', currency: S.currency, maximumFractionDigits: S.currency === 'EUR' ? 2 : 0 }).format(n || 0);
  const d = o.createdAt?.toDate ? o.createdAt.toDate() : new Date();
  const a = o.address || {}, c = o.customer || {};
  const rows = (o.items || []).map(i => `<tr><td>${esc(i.title)}${i.size || i.color ? `<br><small>${esc([i.size, i.color].filter(Boolean).join(' / '))}</small>` : ''}</td><td class="r">${i.qty}</td><td class="r">${money(i.price)}</td><td class="r">${money(i.price * i.qty)}</td></tr>`).join('');
  return `<!doctype html><html lang="fr"><head><meta charset="utf-8"><title>Facture ${esc(o.number || o.id)}</title>
<style>
*{box-sizing:border-box}body{font-family:'Helvetica Neue',Arial,sans-serif;color:#10201f;margin:0;background:#eef2f1}
.sheet{max-width:780px;margin:24px auto;background:#fff;padding:48px;border-radius:12px}
.top{display:flex;justify-content:space-between;align-items:flex-start;border-bottom:3px solid #0f4c47;padding-bottom:20px}
h1{margin:0;font-size:28px;color:#0f4c47}.tag{font-size:26px;font-weight:800;text-align:right}
.meta{display:flex;gap:40px;margin:24px 0;font-size:14px;line-height:1.6;flex-wrap:wrap}.meta b{display:block;font-size:12px;color:#5b6d6b;margin-bottom:2px}
table{width:100%;border-collapse:collapse;font-size:14px}th{text-align:left;background:#f3f6f5;padding:10px}td{padding:10px;border-bottom:1px solid #e3e9e7}.r{text-align:right}small{color:#5b6d6b}
.tot{margin:20px 0 0 auto;width:280px;font-size:14px}.tot div{display:flex;justify-content:space-between;padding:5px 0}.tot .g{font-size:18px;font-weight:800;border-top:2px solid #10201f;margin-top:6px;padding-top:10px}
.foot{margin-top:40px;font-size:12px;color:#5b6d6b;text-align:center}
.bar{max-width:780px;margin:16px auto 0;text-align:right}button{background:#0f4c47;color:#fff;border:0;border-radius:10px;padding:10px 18px;font-weight:700;cursor:pointer}
@media print{body{background:#fff}.sheet{margin:0;padding:0;border-radius:0}.bar{display:none}}
</style></head><body>
<div class="bar"><button onclick="window.print()">Imprimer / Enregistrer en PDF</button></div>
<div class="sheet">
<div class="top"><div>${S.logo ? `<img src="${esc(S.logo)}" alt="" style="height:44px">` : `<h1>${esc(S.shopName)}</h1>`}<small>${esc(S.email || '')}</small></div><div class="tag">Facture<br><small>N° ${esc(o.number || o.id)}</small></div></div>
<div class="meta"><div><b>Date</b>${d.toLocaleDateString(S.locale)}</div><div><b>Statut</b>${esc(o.status)}</div>
<div><b>Client</b>${esc(c.name || a.fullName)}<br>${esc(c.email || '')}<br>${esc(c.phone || a.phone || '')}</div>
<div><b>Livraison</b>${esc(a.fullName)}<br>${esc(a.address)}<br>${esc(a.city)}</div></div>
<table><thead><tr><th>Article</th><th class="r">Qté</th><th class="r">Prix</th><th class="r">Total</th></tr></thead><tbody>${rows}</tbody></table>
<div class="tot"><div><span>Sous-total</span><span>${money(o.subtotal)}</span></div>
${o.discount ? `<div><span>Remise${o.promoCode ? ' (' + esc(o.promoCode) + ')' : ''}</span><span>- ${money(o.discount)}</span></div>` : ''}
${o.shipping ? `<div><span>Livraison</span><span>${money(o.shipping)}</span></div>` : ''}
<div class="g"><span>Total</span><span>${money(o.total)}</span></div></div>
<p class="foot">Merci pour votre commande. Paiement à la livraison.</p></div></body></html>`;
}

export function openInvoice(o, S) {
  const w = window.open('', '_blank');
  if (!w) { alert('Autorisez les pop-ups pour afficher la facture.'); return; }
  w.document.write(invoiceHTML(o, S)); w.document.close();
}
