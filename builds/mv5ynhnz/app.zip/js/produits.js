import { $, esc, price, onSale, renderShell, loadProducts, loadCategories, productCard, wireCards, getFavs } from "./app.js";

renderShell();
const prm = new URLSearchParams(location.search);
$('#grid').innerHTML = Array(8).fill('<div class="skeleton h-64"></div>').join('');

let products = [], cats = [];
try { [products, cats] = await Promise.all([loadProducts(), loadCategories()]); }
catch (e) { console.error(e); $('#grid').innerHTML = '<p class="card p-6 col-span-full">Chargement impossible. Vérifiez la configuration Firebase.</p>'; }

$('#cat').innerHTML += cats.map(c => `<option>${esc(c.name)}</option>`).join('');
$('#q').value = prm.get('q') || ''; $('#cat').value = prm.get('cat') || ''; $('#promo').checked = prm.get('promo') === '1'; $('#favs').checked = prm.get('fav') === '1';
if (prm.get('sort')) $('#sort').value = prm.get('sort');

const grid = $('#grid');
wireCards(grid, products);

function apply() {
  const q = $('#q').value.trim().toLowerCase(), cat = $('#cat').value;
  const min = parseFloat($('#pmin').value), max = parseFloat($('#pmax').value);
  let list = products.filter(p =>
    (!q || [p.title, p.description, p.category, p.subcategory].some(x => String(x || '').toLowerCase().includes(q))) &&
    (!cat || p.category === cat) &&
    (isNaN(min) || price(p) >= min) && (isNaN(max) || price(p) <= max) &&
    (!$('#stock').checked || p.stock > 0) && (!$('#promo').checked || onSale(p)) && (!$('#favs').checked || getFavs().includes(p.id)));
  const s = $('#sort').value;
  const sorters = {
    new: (a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0),
    asc: (a, b) => price(a) - price(b), desc: (a, b) => price(b) - price(a),
    best: (a, b) => (b.sold || 0) - (a.sold || 0), name: (a, b) => (a.title || '').localeCompare(b.title || ''),
  };
  list.sort(sorters[s]);
  $('#count').textContent = `${list.length} produit${list.length > 1 ? 's' : ''}`;
  grid.innerHTML = list.length ? list.map(productCard).join('')
    : '<div class="card p-8 col-span-full text-center"><p class="font-bold">Aucun produit ne correspond</p><p class="muted text-sm mt-1">Modifiez ou réinitialisez les filtres.</p></div>';
}
['q', 'cat', 'pmin', 'pmax', 'stock', 'promo', 'favs', 'sort'].forEach(id => $('#' + id).addEventListener('input', apply));
$('#reset').addEventListener('click', () => { ['q', 'pmin', 'pmax'].forEach(i => $('#' + i).value = ''); $('#cat').value = ''; $('#stock').checked = $('#promo').checked = $('#favs').checked = false; $('#sort').value = 'new'; apply(); });
$('#tog').addEventListener('click', e => { const f = $('#filters'); const open = f.classList.toggle('hidden') === false; e.target.setAttribute('aria-expanded', open); });
apply();
