import { db, auth, SETTINGS } from "../firebase-config.js";
import { doc, getDoc, setDoc, addDoc, collection, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import { $, $$, esc, fmt, PH, toast, getCart, saveCart, authReady, renderShell, loadProducts, price, CFG, settingsReady, shippingFor } from "./app.js";
import { orderButtonHTML, initOrderButton } from "./features.js";

renderShell();
const root = $('#cart');
let promo = null, user = null, profile = {};
try { promo = JSON.parse(sessionStorage.getItem('bazario_promo')); } catch { }

user = await authReady;
await settingsReady;
if (user) { try { const s = await getDoc(doc(db, 'users', user.uid)); profile = s.exists() ? s.data() : {}; } catch { } }

const subtotal = c => c.reduce((n, i) => n + i.price * i.qty, 0);
const discountOf = sub => !promo ? 0 : promo.type === 'percent' ? Math.round(sub * promo.value) / 100 : Math.min(promo.value, sub);

function render() {
  const cart = getCart();
  if (!cart.length) {
    root.innerHTML = '<div class="card p-10 text-center"><p class="font-bold text-lg">Votre panier est vide</p><p class="muted mt-1">Parcourez la boutique pour trouver votre bonheur.</p><a href="produits.html" class="btn btn-primary mt-5">Voir les produits</a></div>'; return;
  }
  const sub = subtotal(cart), disc = discountOf(sub), ship = shippingFor(sub), total = sub - disc + ship, S = CFG.shipping, left = S.fee > 0 && S.freeFrom > 0 ? S.freeFrom - sub : 0;
  const addrs = profile.addresses || [], a0 = addrs[0] || {};
  root.innerHTML = `<div class="grid lg:grid-cols-[1fr_380px] gap-6 items-start">
  <ul class="space-y-3">${cart.map(i => `<li class="card p-3 flex gap-3">
    <img src="${esc(i.image || PH)}" class="w-20 h-20 rounded-lg object-cover" alt="" onerror="this.onerror=null;this.src='${PH}'">
    <div class="flex-1 min-w-0"><p class="font-semibold truncate">${esc(i.title)}</p><p class="text-xs muted">${esc([i.size, i.color].filter(Boolean).join(' / '))}</p><p class="font-bold mt-1">${fmt(i.price)}</p>
      <div class="flex items-center gap-2 mt-2"><button class="btn btn-ghost btn-sm" data-q="-1" data-k="${esc(i.key)}" aria-label="Diminuer">−</button><span class="w-6 text-center font-bold">${i.qty}</span><button class="btn btn-ghost btn-sm" data-q="1" data-k="${esc(i.key)}" aria-label="Augmenter">+</button>
      <button class="btn btn-danger btn-sm ml-auto" data-rm="${esc(i.key)}">Retirer</button></div></div>
    <p class="font-bold hidden sm:block">${fmt(i.price * i.qty)}</p></li>`).join('')}</ul>
  <aside class="card p-4 space-y-4 lg:sticky lg:top-24">
    <div><label class="lbl" for="code">Code promo</label><div class="flex gap-2"><input id="code" class="input uppercase" value="${esc(promo?.code || '')}" placeholder="EX. BIENVENUE10"><button id="apply" class="btn btn-ghost">Appliquer</button></div>${promo ? `<p class="text-xs text-brand mt-1 font-semibold">Code ${esc(promo.code)} appliqué. <button id="unpromo" class="underline">Retirer</button></p>` : ''}</div>
    ${left > 0 ? `<div class="text-sm"><p>Plus que <b>${fmt(left)}</b> pour la livraison gratuite</p><div class="h-2 rounded-full bg-[var(--line)] mt-1.5 overflow-hidden"><div class="h-full bg-brand" style="width:${Math.min(100, sub / S.freeFrom * 100)}%"></div></div></div>` : ''}
    <dl class="text-sm space-y-1.5"><div class="flex justify-between"><dt>Sous-total</dt><dd>${fmt(sub)}</dd></div>${disc ? `<div class="flex justify-between text-brand"><dt>Remise</dt><dd>- ${fmt(disc)}</dd></div>` : ''}${S.fee > 0 ? `<div class="flex justify-between"><dt>Livraison</dt><dd>${ship ? fmt(ship) : 'Gratuite'}</dd></div>` : ''}<div class="flex justify-between text-lg font-bold border-t border-[var(--line)] pt-2"><dt>Total</dt><dd>${fmt(total)}</dd></div></dl>
    <div id="checkout">${!user ? `<a class="btn btn-primary w-full" href="foyer.html?next=panier.html">Se connecter pour commander</a>` : `
      <h2 class="font-bold mb-2">Livraison</h2>
      ${addrs.length ? `<select id="saved" class="input mb-2"><option value="">Saisir une nouvelle adresse</option>${addrs.map((a, k) => `<option value="${k}" ${k === 0 ? 'selected' : ''}>${esc(a.label || a.address)}</option>`).join('')}</select>` : ''}
      <div class="space-y-2"><input id="fn" class="input" placeholder="Nom complet" value="${esc(a0.fullName || profile.name || user.displayName || '')}"><input id="ph" class="input" placeholder="Téléphone" value="${esc(a0.phone || profile.phone || '')}"><input id="ad" class="input" placeholder="Adresse" value="${esc(a0.address || '')}"><input id="ci" class="input" placeholder="Ville" value="${esc(a0.city || '')}"></div>
      <label class="flex items-center gap-2 text-sm mt-2"><input id="save" type="checkbox" ${addrs.length ? '' : 'checked'}> Enregistrer cette adresse</label>
      <div id="order-host" class="mt-3">${orderButtonHTML('Order Now')}</div><p class="text-xs muted mt-2 text-center">Paiement à la livraison</p>`}</div>
  </aside></div>`;
  wireOrderAnimation();
}

function wireOrderAnimation() { const b = $('#order'); if (b) initOrderButton(b, { onConfirm: placeOrder }); }

root.addEventListener('click', async e => {
  const t = e.target.closest('button'); if (!t) return;
  let cart = getCart();
  if (t.dataset.q) { const i = cart.find(x => x.key === t.dataset.k); i.qty = Math.max(1, i.qty + +t.dataset.q); saveCart(cart); render(); }
  else if (t.dataset.rm) { saveCart(cart.filter(x => x.key !== t.dataset.rm)); toast('Article retiré du panier'); render(); }
  else if (t.id === 'unpromo') { promo = null; sessionStorage.removeItem('bazario_promo'); render(); }
  else if (t.id === 'apply') applyCode();
});
root.addEventListener('change', e => {
  if (e.target.id !== 'saved') return;
  const a = (profile.addresses || [])[e.target.value] || {};
  $('#fn').value = a.fullName || ''; $('#ph').value = a.phone || ''; $('#ad').value = a.address || ''; $('#ci').value = a.city || '';
});

async function fetchPromo(code) {
  const s = await getDoc(doc(db, 'promoCodes', code));
  if (!s.exists()) throw new Error('Code promo inconnu');
  const d = s.data();
  if (d.active === false) throw new Error('Ce code n’est plus actif');
  if (d.expires && new Date(d.expires + 'T23:59:59') < new Date()) throw new Error('Ce code a expiré');
  return { code, type: d.type, value: +d.value };
}
async function applyCode() {
  const code = $('#code').value.trim().toUpperCase(); if (!code) return;
  try { promo = await fetchPromo(code); sessionStorage.setItem('bazario_promo', JSON.stringify(promo)); toast('Code promo appliqué'); render(); }
  catch (e) { toast(e.message || 'Code invalide', 'err'); }
}

async function placeOrder(btn) {
  const address = { fullName: $('#fn').value.trim(), phone: $('#ph').value.trim(), address: $('#ad').value.trim(), city: $('#ci').value.trim() };
  if (!address.fullName || !address.phone || !address.address || !address.city) return toast('Complétez l’adresse de livraison', 'err');
  btn.disabled = true; btn.textContent = 'Envoi en cours…';
  try {
    // Prix et stocks revérifiés depuis le catalogue
    const catalog = await loadProducts(true), items = [];
    for (const i of getCart()) {
      const p = catalog.find(x => x.id === i.id);
      if (!p) throw new Error(`« ${i.title} » n’est plus disponible. Retirez-le du panier.`);
      if (p.stock < i.qty) throw new Error(`Stock insuffisant pour « ${p.title} » (${Math.max(p.stock, 0)} restant)`);
      items.push({ id: p.id, title: p.title, image: p.images?.[0] || '', price: price(p), qty: i.qty, size: i.size || '', color: i.color || '' });
    }
    if (promo) { try { promo = await fetchPromo(promo.code); } catch { promo = null; sessionStorage.removeItem('bazario_promo'); } }
    const sub = items.reduce((n, i) => n + i.price * i.qty, 0), disc = discountOf(sub), ship = shippingFor(sub);
    const order = {
      number: 'BZ-' + Date.now().toString(36).toUpperCase(), userId: user.uid,
      customer: { name: address.fullName, email: user.email || '', phone: address.phone },
      address, items, subtotal: sub, discount: disc, promoCode: promo?.code || '', shipping: ship, total: sub - disc + ship,
      status: 'En attente', stockDeducted: false, createdAt: serverTimestamp(),
    };
    await addDoc(collection(db, 'orders'), order);
    if ($('#save')?.checked) {
      const addrs = [...(profile.addresses || []), { ...address, label: `${address.address}, ${address.city}` }].slice(-5);
      await setDoc(doc(db, 'users', user.uid), { addresses: addrs }, { merge: true });
    }
    saveCart([]); sessionStorage.removeItem('bazario_promo');
    toast('Commande validée ! Suivez-la dans votre espace.');
    setTimeout(() => location.href = 'foyer.html#orders', 1000);
  } catch (e) {
    console.error(e); toast(e.message || 'Commande impossible', 'err');
    btn.__dbxReset?.(); btn.disabled = false;
  }
}
render();
window.addEventListener('cart:changed', () => { if (!$('#checkout input:focus')) render(); });
