// Réglages par défaut du site (fusionnés avec le document Firestore settings/site)
export const DEFAULTS = {
  shopName: 'Bazario', tagline: '', logo: '', favicon: '', currency: 'EUR', email: 'contact@bazario.example',
  colors: { brand: '#0f4c47', brandDark: '#0a3532', accent: '#f2a516' },
  appearance: { buttonStyle: 'solid', buttonRadius: 'rounded', buttonGlow: false, splashOn: true, splashStyle: 'pulse', splashDuration: 280 },
  isProfileCompletionEnabled: true, isOrderAnimationEnabled: true, isVipEnabled: true, isReceiptEnabled: true,
  header: { announceOn: true, announce: 'Commande directe, paiement à la livraison', announceLink: '', showSearch: true,
    nav: [{ label: 'Boutique', url: 'produits.html' }, { label: 'Promotions', url: 'produits.html?promo=1' }] },
  carousel: { layout: 'cover', transition: 'fade', autoplay: true, interval: 6, height: 'lg', bg: '#0a3532', text: '#ffffff', align: 'left', arrows: true, dots: true, rounded: true, overlay: 55 },
  whatsapp: { on: true, number: '', message: 'Bonjour, j’ai une question.', greeting: 'Bonjour ! Comment pouvons-nous vous aider ?' },
  shipping: { fee: 0, freeFrom: 0 },
  footer: { about: 'Vêtements, nourriture, électronique, accessoires et technologie au même endroit.',
    links: [{ label: 'Tous les produits', url: 'produits.html' }, { label: 'Promotions', url: 'produits.html?promo=1' }, { label: 'Mon panier', url: 'panier.html' }, { label: 'Mes commandes', url: 'foyer.html' }],
    phone: '', address: '', socials: { facebook: '', instagram: '', tiktok: '', youtube: '', x: '' }, copyright: '' },
};
export const merge = (a, b) => {
  const o = Array.isArray(a) ? [...a] : { ...a };
  for (const k in (b || {})) {
    const bv = b[k], av = a?.[k];
    o[k] = bv && typeof bv === 'object' && !Array.isArray(bv) && av && typeof av === 'object' && !Array.isArray(av) ? merge(av, bv) : bv;
  }
  return o;
};
export const getP = (o, p) => p.split('.').reduce((x, k) => x?.[k], o);
export const setP = (o, p, v) => { const ks = p.split('.'); let x = o; ks.slice(0, -1).forEach(k => x = (x[k] ??= {})); x[ks[ks.length - 1]] = v; };
export const parseLinks = t => String(t || '').split('\n').map(l => { const [a, ...b] = l.split('|'); return a.trim() && b.join('|').trim() ? { label: a.trim(), url: b.join('|').trim() } : null; }).filter(Boolean);
export const linksText = arr => (arr || []).map(l => `${l.label} | ${l.url}`).join('\n');
