import { db, auth } from "../firebase-config.js";
import { doc, getDoc, collection, getDocs, query, where, addDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import { $, $$, esc, fmt, price, onSale, PH, cleanHTML, toast, addToCart, authReady, renderShell, loadProducts, wireCards, settingsReady, waLink, pushRecent, getRecent, rowHTML, wireRows } from "./app.js";

renderShell();
const id = new URLSearchParams(location.search).get('id');
const root = $('#detail');
const notFound = () => root.innerHTML = '<div class="card p-8 text-center"><p class="font-bold">Produit introuvable</p><a class="btn btn-primary mt-4" href="produits.html">Retour à la boutique</a></div>';

let p;
try {
  const s = id && await getDoc(doc(db, 'products', id));
  if (!s || !s.exists() || s.data().active === false) { notFound(); throw new Error('nf'); }
  p = { id: s.id, ...s.data() };
} catch (e) { if (e.message !== 'nf') { console.error(e); notFound(); } }

if (p) {
  document.title = `${p.title} - Bazario`;
  const imgs = p.images?.length ? p.images : [PH], sizes = p.variants?.sizes || [], colors = p.variants?.colors || [], specs = p.variants?.specs || [];
  let size = '', color = '', qty = 1, cur = 0;
  const s = onSale(p), stock = p.stock || 0;
  const stockTxt = stock <= 0 ? '<span class="text-promo font-bold">Rupture de stock</span>' : stock <= 5 ? `<span class="text-[#a86400] font-bold">Plus que ${stock} en stock</span>` : `<span class="text-brand font-bold">En stock (${stock})</span>`;

  root.innerHTML = `
  <nav class="text-sm muted mb-4"><a href="produits.html" class="hover:underline">Boutique</a> / <a class="hover:underline" href="produits.html?cat=${encodeURIComponent(p.category || '')}">${esc(p.category || '')}</a></nav>
  <div class="grid md:grid-cols-2 gap-8">
    <div>
      <div class="zoom rounded-2xl aspect-square" id="zoom"><img id="main" src="${esc(imgs[0])}" alt="${esc(p.title)}" class="w-full h-full object-cover" onerror="this.onerror=null;this.src='${PH}'"></div>
      <div class="flex gap-2 mt-3 overflow-x-auto" id="thumbs">${imgs.map((u, i) => `<button class="shrink-0 w-16 h-16 rounded-lg overflow-hidden border-2 ${i ? 'border-transparent' : 'border-brand'}" data-i="${i}" aria-label="Photo ${i + 1}"><img src="${esc(u)}" alt="" class="w-full h-full object-cover"></button>`).join('')}</div>
    </div>
    <div>
      <p class="text-sm muted">${esc(p.category || '')}${p.subcategory ? ' / ' + esc(p.subcategory) : ''}</p>
      <div class="flex items-start justify-between gap-3"><h1 class="text-2xl md:text-3xl font-extrabold mt-1">${esc(p.title)}</h1><button id="share" class="btn btn-ghost btn-sm shrink-0" aria-label="Partager">Partager</button></div>
      <div id="rating" class="mt-2 text-sm muted"></div>
      <p class="mt-4 text-3xl font-bold">${fmt(price(p))} ${s ? `<span class="old text-lg font-normal">${fmt(p.price)}</span> <span class="badge badge-promo align-middle">-${Math.round(100 - p.promoPrice / p.price * 100)}%</span>` : ''}</p>
      <p class="mt-2 text-sm">${stockTxt}</p>
      ${sizes.length ? `<div class="mt-5"><p class="lbl">Taille</p><div class="flex flex-wrap gap-2" id="sizes">${sizes.map(x => `<button class="chip" aria-pressed="false" data-v="${esc(x)}">${esc(x)}</button>`).join('')}</div></div>` : ''}
      ${colors.length ? `<div class="mt-4"><p class="lbl">Couleur</p><div class="flex flex-wrap gap-2" id="colors">${colors.map(x => `<button class="chip" aria-pressed="false" data-v="${esc(x)}">${esc(x)}</button>`).join('')}</div></div>` : ''}
      <div class="mt-6 flex gap-3 items-center">
        <div class="flex items-center border border-[var(--line)] rounded-xl bg-white"><button class="px-3 py-2" id="minus" aria-label="Diminuer">−</button><span id="qty" class="w-8 text-center font-bold">1</span><button class="px-3 py-2" id="plus" aria-label="Augmenter">+</button></div>
        <button id="add" class="btn btn-primary flex-1" ${stock <= 0 ? 'disabled' : ''}>Ajouter au panier</button>
      </div>
      <div id="wa-slot"></div>
      ${specs.length ? `<table class="mt-6 w-full text-sm card overflow-hidden"><tbody>${specs.map(x => `<tr class="border-b border-[var(--line)] last:border-0"><th class="text-left p-2.5 bg-mist w-2/5 font-semibold">${esc(x.k)}</th><td class="p-2.5">${esc(x.v)}</td></tr>`).join('')}</tbody></table>` : ''}
      ${p.description ? `<div class="prose-lite mt-6 text-[0.95rem] leading-relaxed">${cleanHTML(p.description)}</div>` : ''}
    </div>
  </div>
  <section class="mt-14 grid lg:grid-cols-[1fr_360px] gap-8"><div><h2 class="text-2xl font-bold mb-3">Avis clients</h2><div id="reviews" class="space-y-3"></div></div><div id="review-form"></div></section>
  <section class="mt-14" id="related"></section><div id="recent"></div>
  <div class="buybar"><div><p class="text-xs muted line-clamp-1 max-w-[9rem]">${esc(p.title)}</p><b>${fmt(price(p))}</b></div><button id="add2" class="btn btn-primary flex-1 max-w-[14rem]" ${stock <= 0 ? 'disabled' : ''}>Ajouter au panier</button></div>`;
  pushRecent(p.id);

  settingsReady.then(() => { const l = waLink(`Bonjour, je suis intéressé par « ${p.title} » (${fmt(price(p))}) ${location.href}`); if (l) $('#wa-slot').innerHTML = `<a class="btn btn-ghost w-full mt-3" target="_blank" rel="noopener" href="${l}">Poser une question sur WhatsApp</a>`; });

  // Galerie + zoom
  const setImg = i => { cur = i; $('#main').src = imgs[i]; $$('#thumbs button').forEach((b, k) => b.classList.toggle('border-brand', k === i)); $$('#thumbs button').forEach((b, k) => b.classList.toggle('border-transparent', k !== i)); };
  $('#thumbs').addEventListener('click', e => { const b = e.target.closest('button'); if (b) setImg(+b.dataset.i); });
  $('#zoom').addEventListener('mousemove', e => { const r = e.currentTarget.getBoundingClientRect(); e.currentTarget.style.setProperty('--x', ((e.clientX - r.left) / r.width * 100) + '%'); e.currentTarget.style.setProperty('--y', ((e.clientY - r.top) / r.height * 100) + '%'); });

  // Variantes
  const pick = (sel, set) => $(sel)?.addEventListener('click', e => { const b = e.target.closest('.chip'); if (!b) return; $$('.chip', $(sel)).forEach(x => x.setAttribute('aria-pressed', 'false')); b.setAttribute('aria-pressed', 'true'); set(b.dataset.v); });
  pick('#sizes', v => size = v); pick('#colors', v => color = v);
  $('#minus').onclick = () => { qty = Math.max(1, qty - 1); $('#qty').textContent = qty; };
  $('#plus').onclick = () => { qty = Math.min(Math.max(stock, 1), qty + 1); $('#qty').textContent = qty; };
  $('#add').onclick = () => {
    if (sizes.length && !size) return toast('Choisissez une taille', 'err');
    if (colors.length && !color) return toast('Choisissez une couleur', 'err');
    addToCart(p, { size, color, qty });
  };
  $('#add2').onclick = $('#add').onclick;
  $('#share').onclick = async () => { try { if (navigator.share) await navigator.share({ title: p.title, url: location.href }); else { await navigator.clipboard.writeText(location.href); toast('Lien copié'); } } catch { } };

  // Avis
  async function loadReviews() {
    try {
      const s = await getDocs(query(collection(db, 'reviews'), where('productId', '==', p.id), where('approved', '==', true)));
      const list = s.docs.map(d => d.data()).sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0));
      const avg = list.length ? list.reduce((n, r) => n + r.rating, 0) / list.length : 0;
      $('#rating').textContent = list.length ? `${'★'.repeat(Math.round(avg))}${'☆'.repeat(5 - Math.round(avg))} ${avg.toFixed(1)} (${list.length} avis)` : 'Pas encore d’avis';
      $('#reviews').innerHTML = list.length ? list.map(r => `<div class="card p-4"><p class="text-sun font-bold">${'★'.repeat(r.rating)}<span class="text-[var(--line)]">${'★'.repeat(5 - r.rating)}</span></p><p class="mt-1">${esc(r.comment)}</p><p class="text-xs muted mt-2">${esc(r.name || 'Client')}</p></div>`).join('') : '<p class="muted">Soyez le premier à donner votre avis.</p>';
    } catch (e) { console.warn(e); $('#reviews').innerHTML = '<p class="muted">Avis indisponibles.</p>'; }
  }
  loadReviews();
  const u = await authReady;
  $('#review-form').innerHTML = u ? `<div class="card p-4"><h3 class="font-bold mb-3">Donner votre avis</h3>
    <label class="lbl" for="rt">Note</label><select id="rt" class="input mb-3"><option value="5">5 étoiles</option><option value="4">4 étoiles</option><option value="3">3 étoiles</option><option value="2">2 étoiles</option><option value="1">1 étoile</option></select>
    <label class="lbl" for="rc">Commentaire</label><textarea id="rc" rows="3" maxlength="800" class="input mb-3"></textarea><button id="rs" class="btn btn-primary w-full">Publier mon avis</button></div>`
    : `<div class="card p-4"><p class="font-bold">Un avis à partager ?</p><a class="btn btn-ghost mt-3" href="foyer.html?next=${encodeURIComponent(location.pathname.split('/').pop() + location.search)}">Se connecter pour donner mon avis</a></div>`;
  $('#rs')?.addEventListener('click', async () => {
    const comment = $('#rc').value.trim(); if (comment.length < 3) return toast('Écrivez un commentaire', 'err');
    try {
      await addDoc(collection(db, 'reviews'), { productId: p.id, userId: u.uid, name: u.displayName || u.email.split('@')[0], rating: +$('#rt').value, comment, approved: false, createdAt: serverTimestamp() });
      $('#rc').value = ''; toast('Merci ! Votre avis sera publié après validation.');
    } catch (e) { console.error(e); toast('Envoi impossible', 'err'); }
  });

  // Produits similaires + vus récemment (rangées défilantes)
  const all = await loadProducts();
  const rel = all.filter(x => x.id !== p.id && x.category === p.category);
  const rec = getRecent().filter(x => x !== p.id).map(id => all.find(x => x.id === id)).filter(Boolean);
  $('#related').innerHTML = rel.length ? rowHTML('Vous aimerez aussi', '', rel) : '';
  $('#recent').innerHTML = rec.length ? rowHTML('Vus récemment', '', rec) : '';
  wireCards(root, all); wireRows(root);
}
