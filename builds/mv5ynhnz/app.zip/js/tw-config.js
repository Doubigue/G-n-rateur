tailwind.config = {
  theme: { extend: {
    colors: { ink:'#10201f', brand:{DEFAULT:'var(--brand)', dark:'var(--brand-d)', soft:'var(--soft)'}, mist:'#f3f6f5', sun:'var(--sun)', promo:'#d9363e' },
    fontFamily: { display:['"Bricolage Grotesque"','sans-serif'], sans:['"DM Sans"','sans-serif'] }
  } }
};
