// ============================================================
//  firebase-config.js : à remplir avec les valeurs de votre projet
//  Console Firebase > Paramètres du projet > Vos applications > Web
// ============================================================
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyACHl3zq8uUe58jEYCAFqBi1J_H4YM_HOM",
  authDomain: "e-commerce-22ca0.firebaseapp.com",
  projectId: "e-commerce-22ca0",
  messagingSenderId: "910468550913",
  appId: "1:910468550913:web:e5266d81070af408c34b00",
};

export const app = initializeApp(firebaseConfig); // équivalent moderne de firebase.initializeApp()
export const db = getFirestore(app);
export const auth = getAuth(app);

// Réglages de la boutique (modifiables librement)
export const SETTINGS = {
  shopName: "Bazario",
  currency: "EUR", // ex. "XOF", "MAD", "USD"
  locale: "fr-FR",
  email: "contact@bazario.example",
};
