# Bazario - e-commerce Firebase (client + admin)

## Mise en route
1. Console Firebase : créez un projet, activez **Authentication** (E-mail/Mot de passe + Google) et **Firestore** (les images sont des liens externes, pas de Storage).
2. Copiez votre config web dans `firebase-config.js` (dans **les deux** dossiers). Réglez `SETTINGS.currency` (EUR, XOF, MAD...).
3. Publiez `firestore.rules` (Firestore > Règles).
4. Créez votre compte admin : inscrivez-vous via `foyer.html` (ou Authentication > Ajouter un utilisateur), copiez son **UID**, puis dans Firestore créez le document `admins/{UID}` (un champ quelconque, ex. `role: "admin"`).
5. Ajoutez vos domaines dans Authentication > Paramètres > Domaines autorisés (pour Google).
6. Lancez chaque site via un serveur local (les modules ES ne marchent pas en `file://`) :
   `npx serve site-client` et `npx serve site-admin`, puis ouvrez `admin.html` côté admin.
7. Dans l'admin : créez des catégories, puis des produits.

## Notes
- Stock : décrémenté quand l'admin passe une commande à « Confirmée » (restauré si retour à « En attente »).
- Les prix sont revérifiés côté client au moment de la commande ; sans paiement en ligne ni Cloud Functions, un contrôle serveur strict n'est pas possible.
- Aucun index composite n'est nécessaire (tris faits côté client).
- Facture : bouton « Imprimer / Enregistrer en PDF » dans la fenêtre de reçu.

## Nouveautés (v2)
- **Admin > Paramètres du site** : nom, logo, favicon (liens externes), couleurs, en-tête (annonce, menu, recherche), pied de page, carousel (disposition, transition, hauteur, couleurs, flèches, points), WhatsApp, frais de livraison.
- **Admin > Messages** : conversations avec les clients, messages personnalisés, envoi à un client ou à tous, modèles avec variables {nom} et {boutique}. Un message automatique part à chaque changement de statut de commande.
- **Admin > Tableau de bord** : boutons « Utiliser / Supprimer les données d'exemple ».
- **Site client** : reçu téléchargeable uniquement une fois la commande « Livrée », messagerie (cloche dans l'en-tête), bouton WhatsApp, favoris, livraison offerte avec barre de progression.
- Republiez `firestore.rules` (nouvelles collections `settings` et `messages`).
- **Admin > Sauvegarde** (et bouton « Sauvegarder » du tableau de bord) : export/import JSON de toutes les données. Le document `admins` n'est jamais exporté ni importé.

## Version 3
- Correctif : la fiche produit et le panier ne chargeaient plus (export `authReady` manquant).
- Responsive smartphone / tablette / ordinateur ; menu du bas avec icônes sur smartphone (site client et admin).
- Carousel v2 (image plein cadre, barre de progression, compteur, flèches, glisser au doigt).
- Rangées de produits avec défilement gauche/droite ; cartes catégories au style aléatoire à chaque visite.
- Google : messages d'erreur précis (domaine non autorisé, popup bloquée) et repli par redirection.
- WhatsApp : fenêtre de discussion avec réponses rapides (renseignez le numéro dans Admin > Paramètres > WhatsApp).
- Client : « Vus récemment », bouton Partager, barre d'achat collante sur mobile, favoris.
- Admin : alerte sonore de nouvelle commande, stock modifiable dans le tableau, meilleures ventes.
