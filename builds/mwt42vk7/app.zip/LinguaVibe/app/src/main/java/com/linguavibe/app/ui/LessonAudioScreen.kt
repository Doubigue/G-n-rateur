package com.linguavibe.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linguavibe.app.data.CourseRepository
import com.linguavibe.app.data.LanguageInfo
import com.linguavibe.app.speech.Speaker
import kotlinx.coroutines.delay

/** Lecteur narratif : la légende suit l'index réellement annoncé par Speaker.speakAll. */
@Composable
fun LessonAudioScreen(lang: LanguageInfo, lessonId: String, modelId: String, onBack: () -> Unit) {
    val context = LocalContext.current
    val speaker = LocalSpeaker.current
    val lesson = remember(lang.code, lessonId, modelId) {
        CourseRepository.load(context, lang.code, modelId).lesson(lessonId)
    }
    if (lesson == null) {
        Column(Modifier.fillMaxSize()) { TopBar("Cours audio", "Leçon introuvable", Night, onBack) }
        return
    }
    val segments = remember(lesson) {
        buildList {
            add("Bienvenue dans cette explication. Aujourd'hui, nous allons étudier : ${lesson.title}.")
            lesson.intro.takeIf { it.isNotBlank() && !it.startsWith("Contenu officiel") }?.let(::add)
            lesson.grammar.forEach { point ->
                add("Passons à la règle suivante : ${point.title}.")
                point.explanation.takeIf { it.isNotBlank() }?.let(::add)
                point.examples.forEach { ex -> add("Exemple : ${ex.text}. En français : ${ex.translation}.") }
            }
            if (isEmpty()) lesson.vocab.forEach { add("${it.word}. Cela signifie : ${it.translation}. Exemple : ${it.example}. ${it.exampleTr}") }
        }.flatMap { raw -> raw.split(Regex("(?<=[.!?])\\s+(?=[A-ZÀ-ÖØ-Þ¿¡])")).map(String::trim).filter { it.length > 2 } }
    }
    var paused by remember { mutableStateOf(false) }
    var started by remember { mutableStateOf(false) }
    var resumeAt by remember { mutableIntStateOf(0) }
    val current = speaker.sequenceIndex.coerceIn(0, (segments.size - 1).coerceAtLeast(0))
    val accent = Forest
    fun play(from: Int) {
        if (segments.isNotEmpty()) {
            paused = false
            started = true
            speaker.speakAll(segments, java.util.Locale.FRENCH, from = from)
        }
    }
    DisposableEffect(Unit) { onDispose { speaker.stop() } }
    BackHandler { speaker.stop(); onBack() }

    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFFFFF9EC), Color(0xFFF1E9D8))))) {
        TopBar("Écouter le cours", "${lesson.level} · ${lesson.title}", Forest, { speaker.stop(); onBack() })
        Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("LE PROFESSEUR EXPLIQUE", color = Forest, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 1.4.sp)
                Text("${(current + 1).coerceAtMost(segments.size)} / ${segments.size}", color = InkSoft, fontSize = 12.sp)
            }
            Spacer(Modifier.height(10.dp))
            Card(Modifier.fillMaxWidth().weight(0.95f), shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFDF7)), elevation = CardDefaults.cardElevation(4.dp)) {
                Box(Modifier.fillMaxSize().padding(10.dp), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        // Portrait lineart africain intégré à la bibliothèque graphique du projet.
                        LineArt(Art.avTeacher, Modifier.fillMaxWidth(0.82f).weight(1f), color = Ink, accent = Forest, strokeWidth = 3.dp, animate = false, float = false)
                        Text("Votre professeur", color = Forest, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Text("Portrait fixe en lineart · motifs inspirés des arts africains", color = InkSoft, fontSize = 10.sp)
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            Card(Modifier.fillMaxWidth().weight(0.8f), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Night)) {
                Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.Center) {
                    Text("PHRASE PRONONCÉE", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                    Spacer(Modifier.height(12.dp))
                    AnimatedContent(targetState = current, transitionSpec = { fadeIn(tween(250)) togetherWith fadeOut(tween(150)) }, label = "spokenCaption") { index ->
                        Text(segments.getOrNull(index).orEmpty(), color = Color.White, fontSize = 21.sp, lineHeight = 31.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Start)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("DESSIN DU COURS", color = Forest, fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 1.sp)
                Spacer(Modifier.weight(1f))
                Text(lesson.emoji, fontSize = 22.sp)
                Text(lesson.title, color = InkSoft, fontSize = 12.sp, maxLines = 1)
            }
            // Le dessin thématique se redessine à chaque nouvelle partie de l'explication.
            Card(Modifier.fillMaxWidth().height(104.dp), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.72f))) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    AnimatedContent(targetState = current, transitionSpec = { fadeIn(tween(400)) togetherWith fadeOut(tween(200)) }, label = "lessonSketch") { index ->
                        val caption = segments.getOrNull(index).orEmpty().lowercase()
                        val sketch = when {
                            listOf("famille", "mère", "père", "enfant").any(caption::contains) -> Art.family
                            listOf("manger", "repas", "nourriture", "boire").any(caption::contains) -> Art.food
                            listOf("ville", "maison", "lieu", "habiter").any(caption::contains) -> Art.city
                            listOf("temps", "hier", "passé", "demain", "futur").any(caption::contains) -> Art.past
                            listOf("voyage", "aller", "transport").any(caption::contains) -> Art.travel
                            listOf("travail", "profession", "métier").any(caption::contains) -> Art.work
                            listOf("nombre", "chiffre", "compter").any(caption::contains) -> Art.numbers
                            listOf("salut", "bonjour", "présent").any(caption::contains) -> Art.greet
                            else -> Art.forLesson(lesson)
                        }
                        LineArt(sketch, Modifier.fillMaxHeight(0.92f).fillMaxWidth(0.72f), color = Ink, accent = Gold, strokeWidth = 2.dp, animate = true, drawMillis = 850)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Slider(value = current.toFloat(), onValueChange = { resumeAt = it.toInt() }, valueRange = 0f..(segments.lastIndex.coerceAtLeast(1)).toFloat(), onValueChangeFinished = { speaker.stop(); play(resumeAt) }, colors = SliderDefaults.colors(thumbColor = Forest, activeTrackColor = Forest))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { speaker.stop(); resumeAt = (current - 1).coerceAtLeast(0); play(resumeAt) }, modifier = Modifier.weight(1f)) { Text("Précédent") }
                Button(onClick = {
                    if (speaker.sequencePlaying) { resumeAt = current; speaker.stop(); paused = true }
                    else if (paused) play(resumeAt) else play(0)
                }, modifier = Modifier.weight(1.25f), colors = ButtonDefaults.buttonColors(containerColor = Forest)) {
                    Text(if (speaker.sequencePlaying) "Pause" else if (paused) "Reprendre" else "Écouter")
                }
                OutlinedButton(onClick = { speaker.stop(); resumeAt = (current + 1).coerceAtMost(segments.lastIndex); play(resumeAt) }, modifier = Modifier.weight(1f)) { Text("Suivant") }
            }
            PlaybackSpeedControl(speaker.settings.playbackSpeed, speaker.settings::updatePlaybackSpeed, Forest)
        }
    }
}
