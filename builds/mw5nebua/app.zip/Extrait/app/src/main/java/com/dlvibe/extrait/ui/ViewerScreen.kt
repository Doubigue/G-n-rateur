package com.dlvibe.extrait.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.TextDecrease
import androidx.compose.material.icons.rounded.TextIncrease
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dlvibe.extrait.ScanItem
import com.dlvibe.extrait.ScanViewModel
import kotlinx.coroutines.delay

@Composable
fun ViewerScreen(
    vm: ScanViewModel,
    index: Int,
    onBack: () -> Unit,
    onCopy: (String) -> Unit,
    onShare: (String) -> Unit
) {
    val items = vm.items
    val sections: List<ScanItem> = if (index >= 0) listOfNotNull(items.getOrNull(index)) else items.toList()
    val multi = index < 0 && items.size > 1
    val title = if (multi) "Toutes les images" else sections.firstOrNull()?.name ?: "Texte extrait"
    val words = sections.sumOf { it.words }
    val subtitle = if (multi) "${items.size} images · $words mots" else "$words mots"

    var size by rememberSaveable { mutableIntStateOf(13) }
    var copied by remember { mutableStateOf(false) }
    LaunchedEffect(copied) {
        if (copied) {
            delay(1600)
            copied = false
        }
    }
    val hScroll = rememberScrollState()

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 8.dp, end = 14.dp, top = 4.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Retour", tint = Ink)
            }
            Column(Modifier.weight(1f)) {
                Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(subtitle, fontSize = 13.sp, color = Muted)
            }
            IconButton(onClick = { onShare(vm.textFor(index)) }) {
                Icon(Icons.Rounded.Share, contentDescription = "Partager en fichier .txt", tint = Ink)
            }
            FilledIconButton(
                onClick = {
                    onCopy(vm.textFor(index))
                    copied = true
                },
                modifier = Modifier.size(46.dp),
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = Ink, contentColor = Beam)
            ) {
                Icon(
                    if (copied) Icons.Rounded.Check else Icons.Rounded.ContentCopy,
                    contentDescription = "Copier le texte"
                )
            }
        }

        // La « page » : le texte garde sa disposition (police à chasse fixe, défilement horizontal commun).
        Surface(
            modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp),
            shape = RoundedCornerShape(22.dp),
            color = Color.White,
            shadowElevation = 3.dp
        ) {
            Box(Modifier.horizontalScroll(hScroll)) {
                LazyColumn(
                    contentPadding = PaddingValues(18.dp),
                    verticalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                    itemsIndexed(sections, key = { _, s -> s.index }) { _, s ->
                        Column {
                            if (multi) SectionHeader(s)
                            if (s.text.isBlank()) {
                                Text(
                                    if (s.failed) "Lecture impossible pour cette image." else "Aucun texte détecté.",
                                    color = Muted,
                                    fontStyle = FontStyle.Italic,
                                    fontSize = 14.sp
                                )
                            } else {
                                SelectionContainer {
                                    Text(
                                        s.text,
                                        softWrap = false,
                                        style = TextStyle(
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = size.sp,
                                            lineHeight = (size * 1.35f).sp,
                                            color = Ink
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(vertical = 10.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(shape = RoundedCornerShape(24.dp), color = Color.White, shadowElevation = 2.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { if (size > 9) size-- }) {
                        Icon(Icons.Rounded.TextDecrease, contentDescription = "Réduire le texte", tint = Ink)
                    }
                    Text("$size", fontWeight = FontWeight.Bold, color = Ink, fontSize = 15.sp)
                    IconButton(onClick = { if (size < 24) size++ }) {
                        Icon(Icons.Rounded.TextIncrease, contentDescription = "Agrandir le texte", tint = Ink)
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionHeader(s: ScanItem) {
    Row(Modifier.padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.clip(RoundedCornerShape(8.dp)).background(Ink).padding(horizontal = 8.dp, vertical = 3.dp),
            contentAlignment = Alignment.Center
        ) { Text("${s.index + 1}", color = Beam, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
        Spacer(Modifier.width(10.dp))
        Text(s.name, fontWeight = FontWeight.SemiBold, color = Ink, fontSize = 14.sp, maxLines = 1)
    }
}
