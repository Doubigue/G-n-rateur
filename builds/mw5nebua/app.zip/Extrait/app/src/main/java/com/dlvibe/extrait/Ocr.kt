package com.dlvibe.extrait

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.Rect
import android.net.Uri
import android.provider.OpenableColumns
import androidx.exifinterface.media.ExifInterface
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.tasks.await
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

object Ocr {
    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    /** Lit une image et renvoie son texte, positionné comme dans l'image. */
    suspend fun read(context: Context, uri: Uri): String {
        val bmp = decode(context, uri) ?: error("Image illisible")
        try {
            val result = recognizer.process(InputImage.fromBitmap(bmp, 0)).await()
            return LayoutBuilder.build(result)
        } finally {
            bmp.recycle()
        }
    }

    fun displayName(context: Context, uri: Uri): String? = try {
        context.contentResolver
            .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
    } catch (e: Exception) {
        null
    }

    /** Décode en limitant la taille (centaines d'images : on évite de saturer la mémoire). */
    private fun decode(context: Context, uri: Uri): Bitmap? {
        val cr = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        val longSide = max(bounds.outWidth, bounds.outHeight)
        if (longSide <= 0) return null

        var sample = 1
        while (longSide / (sample * 2) >= 2200) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null

        val degrees = try {
            cr.openInputStream(uri)?.use { s ->
                when (ExifInterface(s).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } ?: 0f
        } catch (e: Exception) {
            0f
        }

        val big = max(bmp.width, bmp.height)
        if (big > 3200) {
            val k = 3200f / big
            val scaled = Bitmap.createScaledBitmap(bmp, (bmp.width * k).roundToInt(), (bmp.height * k).roundToInt(), true)
            if (scaled !== bmp) bmp.recycle()
            bmp = scaled
        }
        if (degrees != 0f) {
            val m = Matrix().apply { postRotate(degrees) }
            val rotated = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            if (rotated !== bmp) bmp.recycle()
            bmp = rotated
        }
        return bmp
    }
}

/**
 * Reconstruit la disposition : les lignes détectées sont regroupées par rangée,
 * puis placées sur une grille à espacement fixe selon leur position horizontale.
 * Les écarts verticaux deviennent des lignes vides.
 */
object LayoutBuilder {
    private class L(val text: String, val r: Rect) {
        val cy: Float get() = r.exactCenterY()
    }

    fun build(t: Text): String {
        val lines = t.textBlocks.flatMap { it.lines }
            .mapNotNull { l -> l.boundingBox?.let { L(l.text.trim(), it) } }
            .filter { it.text.isNotEmpty() }
        if (lines.isEmpty()) return ""

        val minLeft = lines.minOf { it.r.left }
        val maxRight = lines.maxOf { it.r.right }
        val widths = lines.map { it.r.width().toFloat() / it.text.length }.sorted()
        var cw = widths[widths.size / 2].coerceAtLeast(1f)
        val medH = lines.map { it.r.height() }.sorted()[lines.size / 2].coerceAtLeast(1)
        if ((maxRight - minLeft) / cw > 140f) cw = (maxRight - minLeft) / 140f

        val rows = mutableListOf<MutableList<L>>()
        for (l in lines.sortedBy { it.cy }) {
            val row = rows.lastOrNull()
            if (row != null && sameRow(row, l)) row.add(l) else rows.add(mutableListOf(l))
        }

        val sb = StringBuilder()
        var prevBottom: Int? = null
        for (row in rows) {
            val items = row.sortedBy { it.r.left }
            val top = items.minOf { it.r.top }
            val bottom = items.maxOf { it.r.bottom }
            if (prevBottom != null) {
                val gap = top - prevBottom
                val blanks = if (gap > 0.6f * medH) (gap / medH.toFloat()).roundToInt().coerceIn(1, 4) else 0
                repeat(blanks + 1) { sb.append('\n') }
            }
            val line = StringBuilder()
            for (item in items) {
                val target = ((item.r.left - minLeft) / cw).roundToInt()
                val pad = if (line.isEmpty()) target else max(1, target - line.length)
                repeat(pad) { line.append(' ') }
                line.append(item.text)
            }
            sb.append(line)
            prevBottom = bottom
        }
        return sb.toString()
    }

    private fun sameRow(row: List<L>, l: L): Boolean {
        val rcy = row.map { it.cy }.average()
        val rh = row.map { it.r.height() }.average()
        return abs(l.cy - rcy) < 0.5 * min(rh, l.r.height().toDouble())
    }
}
