# Extrait

Appli Android (Kotlin + Jetpack Compose) qui extrait le texte d'une ou de plusieurs centaines d'images, en gardant la disposition du texte.

- OCR local avec ML Kit (alphabet latin, hors ligne)
- Choix multiple d'images, lecture une par une avec progression
- Icône copier, partage en .txt, écran de lecture avec taille de texte réglable

## Compiler
Poussez le dossier sur la branche `main` d'un dépôt GitHub : le workflow `.github/workflows/build.yml` produit l'APK (onglet Actions > artefact `Extrait-debug-apk`).
