@file:OptIn(ExperimentalFoundationApi::class)

package com.dlvibe.dlphone.sms

import android.Manifest
import android.app.TimePickerDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.database.ContentObserver
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.provider.Telephony
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dlvibe.dlphone.ContactsRepo
import com.dlvibe.dlphone.MagicEffects
import com.dlvibe.dlphone.Phone
import com.dlvibe.dlphone.Prefs
import com.dlvibe.dlphone.ui.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class ConversationActivity : ComponentActivity() {
    companion object {
        const val EXTRA_ADDRESS = "address"
        const val EXTRA_DRAFT = "draft"

        fun intent(c: Context, address: String?, draft: String? = null): Intent =
            Intent(c, ConversationActivity::class.java)
                .putExtra(EXTRA_ADDRESS, address)
                .putExtra(EXTRA_DRAFT, draft)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

        fun open(c: Context, address: String?, draft: String? = null) {
            runCatching { c.startActivity(intent(c, address, draft)) }
        }
    }

    private val address = mutableStateOf("")
    private val draft = mutableStateOf("")
    private val key = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        enableEdgeToEdge()
        parse(intent)
        setContent {
            DlTheme {
                ConversationScreen(address.value, draft.value, key.intValue, onClose = { finish() })
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        parse(intent)
    }

    private fun parse(i: Intent?) {
        if (i == null) return
        var a = i.getStringExtra(EXTRA_ADDRESS) ?: ""
        var d = i.getStringExtra(EXTRA_DRAFT) ?: ""
        val data = i.data
        if (data != null && data.scheme in setOf("sms", "smsto", "mms", "mmsto")) {
            val ssp = data.schemeSpecificPart ?: ""
            a = ssp.substringBefore('?').split(',', ';').first().trim()
            if (ssp.contains("body=")) d = Uri.decode(ssp.substringAfter("body=").substringBefore('&'))
        }
        i.getStringExtra("sms_body")?.let { d = it }
        if (d.isEmpty()) i.getStringExtra(Intent.EXTRA_TEXT)?.let { d = it }
        address.value = a
        draft.value = d
        key.intValue++
    }
}

private val TIME = SimpleDateFormat("HH:mm", Locale.FRENCH)

private fun dayTitle(t: Long): String = dayLabel(t)

private fun sameDay(a: Long, b: Long): Boolean {
    val x = Calendar.getInstance().apply { timeInMillis = a }
    val y = Calendar.getInstance().apply { timeInMillis = b }
    return x.get(Calendar.YEAR) == y.get(Calendar.YEAR) && x.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR)
}

private fun atTime(hour: Int, minute: Int, tomorrowIfPast: Boolean = true, plusDays: Int = 0): Long {
    val c = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        add(Calendar.DAY_OF_YEAR, plusDays)
    }
    if (tomorrowIfPast && c.timeInMillis <= System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR, 1)
    return c.timeInMillis
}

@Composable
private fun ConversationScreen(initialAddress: String, initialDraft: String, key: Int, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val p = LocalPalette.current
    var address by remember(key) { mutableStateOf(initialAddress) }
    var editingAddress by remember(key) { mutableStateOf(initialAddress.isBlank()) }
    var text by remember(key) { mutableStateOf(initialDraft) }
    var scheduleDialog by remember { mutableStateOf(false) }
    val tick by SmsBus.tick.collectAsState()
    var obsTick by remember { mutableIntStateOf(0) }

    DisposableEffect(Unit) {
        val obs = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean) {
                obsTick++
            }
        }
        runCatching { ctx.contentResolver.registerContentObserver(Telephony.Sms.CONTENT_URI, true, obs) }
        runCatching { ctx.contentResolver.registerContentObserver(Uri.parse("content://mms"), true, obs) }
        onDispose { runCatching { ctx.contentResolver.unregisterContentObserver(obs) } }
    }

    var msgs by remember { mutableStateOf<List<SmsMsg>>(emptyList()) }
    LaunchedEffect(address, editingAddress, tick, obsTick) {
        if (!editingAddress && address.isNotBlank()) {
            delay(150)
            val list = withContext(Dispatchers.IO) { SmsRepo.messages(ctx, address) }
            msgs = list
            if (list.any { !it.read && !it.outgoing && it.date > Prefs.smsReadThrough(address) }) {
                withContext(Dispatchers.IO) { SmsRepo.markRead(ctx, address) }
            }
            SmsNotif.cancel(ctx, address)
        }
    }
    val name by produceState<String?>(null, address, editingAddress) {
        value = if (address.isBlank()) null else withContext(Dispatchers.IO) { ContactsRepo.nameFor(ctx, address) }
    }
    val scheduled = remember(tick, address) {
        val k = Prefs.norm(address)
        Scheduled.all(ctx).filter { Prefs.norm(it.address) == k }
    }
    val listState = rememberLazyListState()
    LaunchedEffect(msgs.size, scheduled.size) {
        val total = msgs.size + scheduled.size
        if (total > 0) listState.scrollToItem(total - 1)
    }

    val pickContact = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val uri = r.data?.data ?: return@rememberLauncherForActivityResult
        runCatching {
            ctx.contentResolver.query(uri, arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER), null, null, null)?.use {
                if (it.moveToFirst()) {
                    address = it.getString(0) ?: ""
                    editingAddress = false
                }
            }
        }
    }
    val scope = rememberCoroutineScope()
    var attach by remember { mutableStateOf<Uri?>(null) }
    var sendingMms by remember { mutableStateOf(false) }
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) attach = uri
    }
    var pendingSend by remember { mutableStateOf<String?>(null) }
    val smsPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        val t = pendingSend
        pendingSend = null
        if (ok && t != null && SmsSender.send(ctx, address, t)) text = ""
    }

    val phonePerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        Toast.makeText(ctx, if (ok) "Autorisé : touchez de nouveau Envoyer" else "Autorisation Téléphone nécessaire pour choisir la SIM", Toast.LENGTH_LONG).show()
    }

    fun send() {
        val t = text.trim()
        val img = attach
        if (t.isEmpty() && img == null) return
        if (address.isBlank()) {
            Toast.makeText(ctx, "Entrez un numéro", Toast.LENGTH_SHORT).show()
            return
        }
        editingAddress = false
        if (!ContactsRepo.granted(ctx, Manifest.permission.READ_PHONE_STATE)) {
            phonePerm.launch(Manifest.permission.READ_PHONE_STATE)
            return
        }
        if (!ContactsRepo.granted(ctx, Manifest.permission.SEND_SMS)) {
            pendingSend = t
            smsPerm.launch(Manifest.permission.SEND_SMS)
            return
        }
        if (img != null) {
            // MMS : photo + texte
            sendingMms = true
            val to = address
            scope.launch {
                val ok = withContext(Dispatchers.IO) { MmsTransport.send(ctx.applicationContext, to, t.ifBlank { null }, img) }
                sendingMms = false
                if (ok) {
                    text = ""; attach = null
                }
            }
            return
        }
        if (SmsSender.send(ctx, address, t)) text = ""
    }

    fun schedule(at: Long) {
        val t = text.trim()
        if (t.isEmpty() || address.isBlank()) return
        Scheduled.add(ctx, address, t, at)
        text = ""
        editingAddress = false
        Toast.makeText(ctx, "Programmé pour ${SimpleDateFormat("EEE d MMM HH:mm", Locale.FRENCH).format(Date(at))}", Toast.LENGTH_SHORT).show()
    }

    val title = when {
        editingAddress -> "Nouveau message"
        name != null -> name!!
        else -> address
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(bgBrush(p))
            .systemBarsPadding()
            .imePadding()
    ) {
        // Barre du haut
        Row(
            Modifier
                .fillMaxWidth()
                .background(p.sheet)
                .padding(horizontal = 6.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose) { Icon(Icons.Filled.ArrowBack, "Retour", tint = p.text) }
            if (!editingAddress) Avatar(title, 40.dp, number = address, lookup = true)
            Column(
                Modifier
                    .weight(1f)
                    .padding(start = 10.dp)
            ) {
                Text(title, color = p.text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                if (!editingAddress && name != null) Text(address, color = p.muted, fontSize = 12.sp)
            }
            if (!editingAddress && address.isNotBlank()) {
                IconButton(onClick = {
                    if (ContactsRepo.granted(ctx, Manifest.permission.CALL_PHONE)) Phone.call(ctx, address)
                    else safeStart(ctx, Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", address, null)))
                }) { Icon(Icons.Filled.Call, "Appeler", tint = p.accent) }
            }
        }

        if (editingAddress) {
            Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("À : numéro") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    shape = RoundedCornerShape(16.dp),
                    colors = dlTextFieldColors(),
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = {
                    runCatching { pickContact.launch(Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI)) }
                }) { Icon(Icons.Filled.Contacts, "Choisir un contact", tint = p.accent) }
                TextButton(onClick = { if (address.isNotBlank()) editingAddress = false }) { Text("OK", color = p.accent) }
            }
        }

        // Fil de discussion
        LazyColumn(
            Modifier
                .weight(1f)
                .fillMaxWidth(),
            state = listState,
            contentPadding = PaddingValues(vertical = 10.dp)
        ) {
            itemsIndexed(msgs, key = { _, m -> (if (m.isMms) "m" else "s") + m.id }) { i, m ->
                if (i == 0 || !sameDay(msgs[i - 1].date, m.date)) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp), contentAlignment = Alignment.Center
                    ) {
                        Text(dayTitle(m.date), color = p.muted, fontSize = 12.sp)
                    }
                }
                Bubble(m, onForward = { open -> ConversationActivity.open(ctx, null, open) }) {
                    val ok = if (m.isMms) MmsRepo.delete(ctx, m.id) else SmsRepo.delete(ctx, m.id)
                    if (ok) SmsBus.changed()
                    else Toast.makeText(ctx, "Suppression possible quand Téléphone est l'appli SMS par défaut", Toast.LENGTH_LONG).show()
                }
            }
            items(scheduled, key = { "p${it.id}" }) { s ->
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    Column(
                        Modifier
                            .widthIn(max = 300.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .border(1.5.dp, p.accent, RoundedCornerShape(18.dp))
                            .padding(horizontal = 14.dp, vertical = 9.dp)
                    ) {
                        Text(s.body, color = p.text, fontSize = 15.sp)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("" + SimpleDateFormat("EEE d MMM HH:mm", Locale.FRENCH).format(Date(s.at)), color = p.accent, fontSize = 11.sp)
                        TextButton(onClick = { Scheduled.cancel(ctx, s.id) }) { Text("Annuler", color = p.muted, fontSize = 11.sp) }
                    }
                }
            }
        }

        // Réponses rapides
        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(Prefs.quickReplies()) { r ->
                Text(
                    r, color = p.text, fontSize = 12.sp, maxLines = 1,
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(p.surface2)
                        .clickable { text = r }
                        .padding(horizontal = 12.dp, vertical = 7.dp)
                )
            }
        }

        // Pièce jointe choisie
        val att = attach
        if (att != null) {
            Row(
                Modifier
                    .padding(horizontal = 12.dp, vertical = 6.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(p.surface2)
                    .padding(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                MmsImage(att.toString(), Modifier.size(64.dp))
                Text(
                    if (sendingMms) "  Envoi du MMS…" else "  Photo jointe (MMS)",
                    color = p.text, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 6.dp)
                )
                if (!sendingMms) IconButton(onClick = { attach = null }) { Icon(Icons.Filled.Close, "Retirer", tint = p.muted) }
            }
        }

        // Zone de saisie
        if (!editingAddress && Prefs.isService(address)) {
            Text(
                "noreply · Numéro de service, réponse impossible",
                color = p.muted, fontSize = 13.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally).padding(14.dp)
            )
        } else {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            IconButton(onClick = { runCatching { pickImage.launch("image/*") } }) {
                Icon(Icons.Filled.AddPhotoAlternate, "Joindre une photo", tint = p.accent)
            }
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                placeholder = { Text(if (attach != null) "Légende (facultatif)" else "Message") },
                maxLines = 5,
                shape = RoundedCornerShape(24.dp),
                colors = dlTextFieldColors(),
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(8.dp))
            Box(
                Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(if (text.isNotBlank() || attach != null) p.accent else p.surface2)
                    .combinedClickable(onClick = { if (!sendingMms) send() }, onLongClick = { if (text.isNotBlank() && attach == null) scheduleDialog = true }),
                contentAlignment = Alignment.Center
            ) {
                if (sendingMms) CircularProgressIndicator(color = p.onAccent, strokeWidth = 2.dp, modifier = Modifier.size(22.dp))
                else Icon(Icons.Filled.Send, "Envoyer (appui long : programmer)", tint = if (text.isNotBlank() || attach != null) p.onAccent else p.muted)
            }
        }
        Text(
            "Appui long sur Envoyer : programmer l'envoi",
            color = p.muted, fontSize = 10.sp,
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .padding(bottom = 4.dp)
        )
        }
    }

    if (scheduleDialog) {
        AlertDialog(
            onDismissRequest = { scheduleDialog = false },
            containerColor = p.sheet,
            title = { Text("Programmer l'envoi", color = p.text) },
            text = {
                Column {
                    val now = System.currentTimeMillis()
                    listOf(
                        "Dans 10 minutes" to now + 10 * 60_000L,
                        "Dans 1 heure" to now + 60 * 60_000L,
                        "Ce soir à 20 h" to atTime(20, 0),
                        "Demain à 8 h" to atTime(8, 0, tomorrowIfPast = false, plusDays = 1)
                    ).forEach { (label, at) ->
                        Text(
                            label, color = p.text,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { scheduleDialog = false; schedule(at) }
                                .padding(vertical = 12.dp, horizontal = 8.dp)
                        )
                    }
                    Text(
                        "Choisir l'heure…", color = p.accent,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                scheduleDialog = false
                                val c = Calendar.getInstance()
                                TimePickerDialog(ctx, { _, h, m -> schedule(atTime(h, m)) },
                                    c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show()
                            }
                            .padding(vertical = 12.dp, horizontal = 8.dp)
                    )
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { scheduleDialog = false }) { Text("Annuler", color = p.accent) } }
        )
    }
}

@Composable
private fun Bubble(m: SmsMsg, onForward: (String) -> Unit, onDelete: () -> Unit) {
    val ctx = LocalContext.current
    val p = LocalPalette.current
    val out = m.outgoing
    var menu by remember { mutableStateOf(false) }
    val code = remember(m.body) { if (!out) OtpDetector.find(m.body) else null }
    val shape = RoundedCornerShape(
        topStart = 18.dp, topEnd = 18.dp,
        bottomStart = if (out) 18.dp else 4.dp, bottomEnd = if (out) 4.dp else 18.dp
    )
    var viewer by remember { mutableStateOf<String?>(null) }
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 3.dp),
        horizontalAlignment = if (out) Alignment.End else Alignment.Start
    ) {
        // Photos du MMS
        m.parts.filter { it.uri != null && it.type.startsWith("image/") }.forEach { part ->
            MmsImage(
                part.uri!!,
                Modifier
                    .padding(bottom = 4.dp)
                    .widthIn(max = 260.dp)
                    .heightIn(max = 320.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .combinedClickable(onClick = { viewer = part.uri }, onLongClick = { menu = true })
            )
        }
        m.parts.filter { it.uri != null && !it.type.startsWith("image/") }.forEach { part ->
            Text(
                "Pièce jointe (${part.type})", color = p.accent, fontSize = 13.sp,
                modifier = Modifier
                    .padding(bottom = 4.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(p.surface2)
                    .clickable {
                        safeStart(ctx, Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(part.uri), part.type)
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                    }
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            )
        }
        if (m.body.isNotEmpty() || !m.isMms) Box {
            Text(
                m.body,
                color = if (out) p.onAccent else p.text,
                fontSize = 15.sp,
                modifier = Modifier
                    .widthIn(max = 300.dp)
                    .clip(shape)
                    .background(if (out) p.accent else p.surface2)
                    .combinedClickable(onClick = {}, onLongClick = { menu = true })
                    .padding(horizontal = 14.dp, vertical = 9.dp)
            )
        }
        Box {
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("Copier") }, onClick = {
                    menu = false
                    ctx.getSystemService(ClipboardManager::class.java)?.setPrimaryClip(ClipData.newPlainText("SMS", m.body))
                })
                DropdownMenuItem(text = { Text("Lire à voix haute") }, onClick = {
                    menu = false
                    MagicEffects.say(ctx, m.body)
                })
                DropdownMenuItem(text = { Text("Transférer") }, onClick = {
                    menu = false
                    onForward(m.body)
                })
                DropdownMenuItem(text = { Text("Supprimer", color = HangupRed) }, onClick = {
                    menu = false
                    onDelete()
                })
            }
        }
        if (code != null) {
            Text(
                "Copier le code $code",
                color = p.onAccent, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .padding(top = 4.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(p.accent)
                    .clickable {
                        ctx.getSystemService(ClipboardManager::class.java)?.setPrimaryClip(ClipData.newPlainText("Code", code))
                        Toast.makeText(ctx, "Code $code copié", Toast.LENGTH_SHORT).show()
                    }
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            )
        }
        viewer?.let { v -> ImageViewer(v) { viewer = null } }
        val status = when {
            !out -> ""
            m.type == Telephony.Sms.MESSAGE_TYPE_FAILED -> " · Échec"
            m.type == Telephony.Sms.MESSAGE_TYPE_OUTBOX || m.type == Telephony.Sms.MESSAGE_TYPE_QUEUED -> " · Envoi…"
            m.status == Telephony.Sms.STATUS_COMPLETE -> " · Reçu"
            else -> " · Envoyé"
        }
        Text(
            TIME.format(Date(m.date)) + status,
            color = if (m.type == Telephony.Sms.MESSAGE_TYPE_FAILED) HangupRed else p.muted,
            fontSize = 11.sp,
            modifier = Modifier.padding(top = 2.dp, start = 4.dp, end = 4.dp)
        )
    }
}


/** Image d'un MMS (ou d'une pièce jointe choisie). */
@Composable
fun MmsImage(uri: String, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val p = LocalPalette.current
    val img by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, uri) {
        value = withContext(Dispatchers.IO) { com.dlvibe.dlphone.PhotoLoader.decode(ctx, uri, 900) }
    }
    val bmp = img
    if (bmp != null) {
        androidx.compose.foundation.Image(
            bmp, "Photo",
            contentScale = androidx.compose.ui.layout.ContentScale.Crop,
            modifier = modifier.aspectRatio(bmp.width.toFloat() / bmp.height.coerceAtLeast(1))
        )
    } else {
        Box(modifier.size(160.dp).background(p.surface2), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = p.accent, strokeWidth = 2.dp, modifier = Modifier.size(22.dp))
        }
    }
}

/** Visionneuse plein écran avec « Enregistrer dans la galerie ». */
@Composable
private fun ImageViewer(uri: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    androidx.compose.ui.window.Dialog(
        onDismissRequest = onClose,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black)
                .clickable { onClose() }
        ) {
            val img by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, uri) {
                value = withContext(Dispatchers.IO) { com.dlvibe.dlphone.PhotoLoader.decode(ctx, uri, 2000) }
            }
            img?.let {
                androidx.compose.foundation.Image(
                    it, "Photo",
                    contentScale = androidx.compose.ui.layout.ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxSize()
                        .align(Alignment.Center)
                )
            }
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding()
                    .padding(20.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(onClick = { saveToGallery(ctx, uri) }) { Text("Enregistrer") }
                OutlinedButton(onClick = onClose) { Text("Fermer", color = Color.White) }
            }
        }
    }
}

private fun saveToGallery(ctx: Context, uri: String) {
    try {
        val values = android.content.ContentValues().apply {
            put(android.provider.MediaStore.Images.Media.DISPLAY_NAME, "MMS_${System.currentTimeMillis()}.jpg")
            put(android.provider.MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            if (android.os.Build.VERSION.SDK_INT >= 29) put(android.provider.MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Téléphone")
        }
        val dest = ctx.contentResolver.insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException()
        ctx.contentResolver.openInputStream(Uri.parse(uri))?.use { input ->
            ctx.contentResolver.openOutputStream(dest)?.use { input.copyTo(it) }
        }
        Toast.makeText(ctx, "Photo enregistrée dans la galerie", Toast.LENGTH_SHORT).show()
    } catch (_: Exception) {
        Toast.makeText(ctx, "Enregistrement impossible", Toast.LENGTH_SHORT).show()
    }
}
