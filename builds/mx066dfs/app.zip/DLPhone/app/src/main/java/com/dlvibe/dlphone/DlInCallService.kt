package com.dlvibe.dlphone

import android.content.Context
import android.content.Intent
import android.os.Build
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.CallScreeningService
import android.telecom.DisconnectCause
import android.telecom.InCallService
import android.telecom.TelecomManager
import android.Manifest

/** Service que le système lie quand DL Phone est l'appli Téléphone par défaut. */
class DlInCallService : InCallService() {
    private val callbacks = HashMap<Call, Call.Callback>()
    private val lastState = HashMap<Call, Int>()

    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        CallManager.service = this
    }

    override fun onDestroy() {
        if (CallManager.service === this) CallManager.service = null
        MagicEffects.stopAll()
        super.onDestroy()
    }

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        val number = CallManager.numberOf(call)
        val state = CallManager.stateOf(call)

        // Bouclier : rejet silencieux des numéros bloqués
        if (state == Call.STATE_RINGING && Shield.shouldBlock(this, number, call.details.handlePresentation)) {
            call.reject(false, null)
            Prefs.blockedCount = Prefs.blockedCount + 1
            return
        }

        val cb = object : Call.Callback() {
            override fun onStateChanged(c: Call, newState: Int) {
                onState(c, newState)
            }

            override fun onDetailsChanged(c: Call, details: Call.Details) {
                CallManager.changed()
            }
        }
        call.registerCallback(cb)
        callbacks[call] = cb
        lastState[call] = state
        if (state == Call.STATE_RINGING) CallManager.incoming.add(call)
        CallManager.add(call)

        val name = ContactsRepo.nameFor(this, number)
        if (state == Call.STATE_RINGING && Prefs.announceCaller && !number.isNullOrBlank()) {
            VoiceAnnouncer.speakDigits(this, number)
        } else {
            VoiceAnnouncer.stop()
        }
        var islandShown = false
        if (state == Call.STATE_RINGING) {
            // Téléphone en main : îlot autour de la caméra au lieu du plein écran
            islandShown = Prefs.island && CallIsland.deviceInUse(this) && CallIsland.show(this, number, name)
            if (islandShown) Notif.incomingQuiet(this, number, name) else Notif.incoming(this, number, name)
            Ringer.start(this, number)
            MagicEffects.onIncoming(this, number, name)
        } else {
            Notif.ongoing(this, number, name)
        }
        if (!islandShown) {
            try {
                startActivity(Intent(this, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {
                // La notification plein écran prend le relais
            }
        }
    }

    private fun onState(call: Call, s: Int) {
        val prev = lastState[call]
        lastState[call] = s
        if (s != Call.STATE_RINGING) VoiceAnnouncer.stop()
        val number = CallManager.numberOf(call)
        when (s) {
            Call.STATE_ACTIVE -> {
                CallManager.answered.add(call)
                if (CallManager.ringing() == null) {
                    MagicEffects.stopAll()
                    CallIsland.hide()
                    Notif.cancelIncoming(this)
                }
                if ((prev == Call.STATE_DIALING || prev == Call.STATE_CONNECTING) && Prefs.vibrateOnConnect) {
                    MagicEffects.vibrateConnected(this)
                }
                Notif.ongoing(this, number, ContactsRepo.nameFor(this, number))
            }

            Call.STATE_DISCONNECTED -> {
                if (CallManager.incoming.contains(call) && !CallManager.answered.contains(call)) {
                    MagicEffects.stopAll()
                    if (CallManager.calls.value.none { it != call && CallManager.stateOf(it) == Call.STATE_RINGING }) CallIsland.hide()
                    Notif.cancelIncoming(this)
                    val cause = call.details.disconnectCause?.code
                    if (cause == DisconnectCause.MISSED && Prefs.missedNotif) {
                        Notif.missed(this, number, ContactsRepo.nameFor(this, number))
                    }
                }
            }
        }
        CallManager.changed()
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
        callbacks.remove(call)?.let { call.unregisterCallback(it) }
        lastState.remove(call)
        CallManager.remove(call)
        if (CallManager.calls.value.isEmpty()) {
            MagicEffects.stopAll()
            CallIsland.hide()
            Notif.cancelCallNotifs(this)
        } else if (CallManager.ringing() == null) {
            CallIsland.hide()
            Notif.cancelIncoming(this)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onCallAudioStateChanged(audioState: CallAudioState?) {
        super.onCallAudioStateChanged(audioState)
        CallManager.audio.value = audioState
    }
}

/** Règles du bouclier anti-indésirables. */
object Shield {
    fun shouldBlock(c: Context, number: String?, presentation: Int): Boolean {
        Prefs.init(c)
        val hidden = number.isNullOrBlank() || presentation != TelecomManager.PRESENTATION_ALLOWED
        if (hidden) return Prefs.blockHidden
        if (Prefs.isBlocked(number)) return true
        if (Prefs.blockUnknown &&
            ContactsRepo.granted(c, Manifest.permission.READ_CONTACTS) &&
            ContactsRepo.nameFor(c, number) == null
        ) return true
        return false
    }
}

/** Filtrage système (avant même que le téléphone sonne). */
class DlScreeningService : CallScreeningService() {
    override fun onScreenCall(details: Call.Details) {
        Prefs.init(this)
        val incoming = if (Build.VERSION.SDK_INT >= 29) {
            details.callDirection == Call.Details.DIRECTION_INCOMING
        } else true
        val number = details.handle?.schemeSpecificPart
        val block = incoming && Shield.shouldBlock(this, number, details.handlePresentation)
        if (block) Prefs.blockedCount = Prefs.blockedCount + 1
        val response = CallScreeningService.CallResponse.Builder()
            .setDisallowCall(block)
            .setRejectCall(block)
            .setSkipCallLog(false)
            .setSkipNotification(block)
            .build()
        respondToCall(details, response)
    }
}
