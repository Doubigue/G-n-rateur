package com.dlvibe.dlphone.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Grille de raccourcis ; chaque tuile fait défiler jusqu'à sa section. */
@Composable
fun ServiceTiles(onOpen: (Int) -> Unit) {
    val p = LocalPalette.current
    val tiles: List<Triple<String, ImageVector, Int>> = listOf(
        Triple("Général", Icons.Filled.Settings, 2), Triple("Voix", Icons.Filled.RecordVoiceOver, 3),
        Triple("Îlot", Icons.Filled.TouchApp, 5), Triple("Thèmes", Icons.Filled.Wallpaper, 7),
        Triple("Style", Icons.Filled.Palette, 8), Triple("Effets", Icons.Filled.AutoAwesome, 9),
        Triple("Blocage", Icons.Filled.Shield, 10), Triple("Réponses", Icons.Filled.Message, 11)
    )
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Services", color = p.text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        tiles.chunked(4).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { (label, icon, index) ->
                    val shape = RoundedCornerShape(16.dp)
                    Column(
                        Modifier
                            .weight(1f)
                            .height(96.dp)
                            .clip(shape)
                            .background(p.card)
                            .border(1.dp, p.line, shape)
                            .clickable { onOpen(index) },
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(icon, null, tint = p.accent, modifier = Modifier.size(34.dp))
                        Text(label, color = p.text, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    }
                }
            }
        }
    }
}
