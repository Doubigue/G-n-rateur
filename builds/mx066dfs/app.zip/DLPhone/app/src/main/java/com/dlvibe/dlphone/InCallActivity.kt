package com.dlvibe.dlphone

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager
import android.telecom.VideoProfile
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.dlvibe.dlphone.ui.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class InCallActivity : ComponentActivity() {
    companion object {
        const val ACTION_ANSWER = "com.dlvibe.dlphone.ANSWER"
        const val EXTRA_PREVIEW = "preview_number"
        const val EXTRA_PREVIEW_NAME = "preview_name"
    }

    private var proximity: PowerManager.WakeLock? = null
    private var previewNumber: String? = null

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enableEdgeToEdge()
        handle(intent)

        val pm = getSystemService(PowerManager::class.java)
        if (pm != null && pm.isWakeLockLevelSupported(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK)) {
            proximity = pm.newWakeLock(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK, "dlphone:proximity")
        }
        lifecycleScope.launch {
            combine(CallManager.calls, CallManager.tick, CallManager.audio) { _, _, a -> a }
                .collect { updateProximity(it) }
        }

        previewNumber = intent.getStringExtra(EXTRA_PREVIEW)
        val previewName = intent.getStringExtra(EXTRA_PREVIEW_NAME)
        previewNumber?.let { if (CallManager.calls.value.isEmpty()) Ringer.start(this, it, preview = true) }
        setContent {
            DlTheme {
                InCallScreen(onClose = {
                    if (previewNumber != null && CallManager.calls.value.isEmpty()) Ringer.stop()
                    finish()
                }, previewNumber = previewNumber, previewName = previewName)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handle(intent)
    }

    private fun handle(i: Intent?) {
        if (i?.action == ACTION_ANSWER) {
            CallManager.answer()
            CallIsland.hide()
            Notif.cancelIncoming(this)
        }
    }

    /** L'écran s'éteint contre l'oreille pendant l'appel. */
    private fun updateProximity(a: CallAudioState?) {
        val wl = proximity ?: return
        val c = CallManager.primary()
        val s = c?.let { CallManager.stateOf(it) }
        val want = c != null &&
                (s == Call.STATE_ACTIVE || s == Call.STATE_DIALING || s == Call.STATE_CONNECTING || s == Call.STATE_HOLDING) &&
                (a == null || a.route == CallAudioState.ROUTE_EARPIECE)
        try {
            if (want && !wl.isHeld) wl.acquire(4 * 60 * 60 * 1000L)
            else if (!want && wl.isHeld) wl.release(PowerManager.RELEASE_FLAG_WAIT_FOR_NO_PROXIMITY)
        } catch (_: Exception) {
        }
    }

    override fun onDestroy() {
        if (previewNumber != null && CallManager.calls.value.isEmpty()) Ringer.stop()
        proximity?.let { if (it.isHeld) runCatching { it.release() } }
        super.onDestroy()
    }
}

private fun timer(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
    else "%02d:%02d".format(s / 60, s % 60)
}

val LocalOnMedia = staticCompositionLocalOf { false }

@Composable
fun InCallScreen(onClose: () -> Unit, previewNumber: String? = null, previewName: String? = null) {
    val ctx = LocalContext.current
    val p = LocalPalette.current
    val calls by CallManager.calls.collectAsState()
    val tick by CallManager.tick.collectAsState()
    val audio by CallManager.audio.collectAsState()
    val isPreview = previewNumber != null && calls.isEmpty()
    val call = remember(calls, tick) { CallManager.primary() }
    val state = if (isPreview) Call.STATE_RINGING
    else remember(call, tick) { call?.let { CallManager.stateOf(it) } ?: Call.STATE_DISCONNECTED }
    val number = if (isPreview) previewNumber ?: "" else call?.let { CallManager.numberOf(it) } ?: ""
    val name by produceState(if (isPreview) previewName else null, number, isPreview) {
        value = if (isPreview) previewName
        else withContext(Dispatchers.IO) { ContactsRepo.nameFor(ctx, number) }
    }
    val theme = remember(number, isPreview) { CallThemes.forCall(ctx, number) }
    val bigPhoto by produceState<ImageBitmap?>(null, number) {
        value = withContext(Dispatchers.IO) { PhotoLoader.load(ctx, number.ifBlank { null }, null, 1080, lookup = true) }
    }
    var ended by remember { mutableStateOf(false) }
    LaunchedEffect(calls.isEmpty()) {
        if (calls.isEmpty() && previewNumber == null) {
            ended = true
            delay(900)
            onClose()
        }
    }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis(); delay(500)
        }
    }
    val connect = if (isPreview) 0L else call?.details?.connectTimeMillis ?: 0L
    val title = when {
        ended -> "Appel terminé"
        name != null -> name!!
        theme?.label != null -> theme.label!!
        number.isNotBlank() -> number
        else -> "Numéro masqué"
    }
    val status = when {
        ended -> "À bientôt"
        isPreview -> "Aperçu de l'appel"
        state == Call.STATE_RINGING -> "Appel entrant…"
        state == Call.STATE_DIALING || state == Call.STATE_CONNECTING -> "Appel en cours…"
        state == Call.STATE_ACTIVE -> if (connect > 0) timer(now - connect) else "Connecté"
        state == Call.STATE_HOLDING -> "En attente"
        state == Call.STATE_DISCONNECTING -> "Fin de l'appel…"
        state == Call.STATE_SELECT_PHONE_ACCOUNT -> "Choisissez votre SIM"
        else -> "Appel terminé"
    }
    val ringing = state == Call.STATE_RINGING && !ended
    val early = state == Call.STATE_RINGING || state == Call.STATE_DIALING || state == Call.STATE_CONNECTING
    val videoPath = theme?.video?.takeIf { !ended && (early || Prefs.videoDuringCall) && File(it).exists() }
    val photo = bigPhoto
    val onMedia = videoPath != null || photo != null
    val textColor = if (onMedia) Color.White else p.text
    val subColor = if (onMedia) Color.White.copy(alpha = 0.8f) else p.muted

    val inf = rememberInfiniteTransition(label = "pulse")
    val pulse by inf.animateFloat(
        initialValue = 1f, targetValue = 1.28f,
        animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "scale"
    )

    CompositionLocalProvider(LocalOnMedia provides onMedia) {
        Box(
            Modifier
                .fillMaxSize()
                .background(bgBrush(p))
        ) {
            // Vidéo plein écran, ou photo plein écran
            if (videoPath != null) LoopingVideo(videoPath, Modifier.fillMaxSize())
            else if (photo != null) Image(photo, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            if (onMedia) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Black.copy(alpha = 0.55f), Color.Black.copy(alpha = 0.05f), Color.Black.copy(alpha = 0.85f))
                            )
                        )
                )
            }
            Column(
                Modifier
                    .fillMaxSize()
                    .systemBarsPadding()
                    .padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(24.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("TÉLÉPHONE", color = p.accent, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                    if (theme?.vip == true) Text("  VIP", color = Color(0xFFFDD663), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(if (videoPath != null) 16.dp else 30.dp))
                val avatarSize = if (videoPath != null) 84.dp else 120.dp
                Box(contentAlignment = Alignment.Center, modifier = Modifier.size(avatarSize + 50.dp)) {
                    if (ringing) {
                        Box(
                            Modifier
                                .size(avatarSize + 10.dp)
                                .scale(pulse)
                                .clip(CircleShape)
                                .background(p.accent.copy(alpha = 0.22f))
                        )
                    }
                    Box(
                        Modifier
                            .size(avatarSize + 8.dp)
                            .clip(CircleShape)
                            .border(2.dp, if (onMedia) Color.White.copy(alpha = 0.6f) else p.line, CircleShape),
                        contentAlignment = Alignment.Center
                    ) { Avatar(title, avatarSize, number = number.ifBlank { null }, lookup = true) }
                }
                Spacer(Modifier.height(14.dp))
                Text(title, color = textColor, fontSize = 30.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 2)
                if (name != null && !ended && number.isNotBlank()) Text(number, color = subColor, fontSize = 15.sp)
                Spacer(Modifier.height(6.dp))
                Text(status, color = p.accent, fontSize = 16.sp, fontWeight = FontWeight.Medium)

                // Note liée au numéro
                val note = theme?.note
                if (!note.isNullOrBlank() && !ended) {
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "$note",
                        color = if (onMedia) Color.White else p.text,
                        fontSize = 14.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (onMedia) Color.Black.copy(alpha = 0.45f) else p.surface2)
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    )
                }

                // Appel en attente : bascule en un geste
                val other = if (isPreview) null else calls.firstOrNull { it != call }
                if (other != null && !ended) {
                    val oNum = CallManager.numberOf(other)
                    Spacer(Modifier.height(14.dp))
                    Row(
                        Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(p.surface2)
                            .clickable {
                                if (CallManager.stateOf(other) == Call.STATE_HOLDING) other.unhold()
                            }
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.SwapCalls, null, tint = p.accent, modifier = Modifier.size(18.dp))
                        Text(
                            "  ${oNum.ifBlank { "Autre appel" }} · en attente — basculer",
                            color = p.text, fontSize = 13.sp
                        )
                    }
                }

                Spacer(Modifier.weight(1f))
                val c = call
                when {
                    isPreview -> PreviewControls(onClose)
                    ended || c == null -> {}
                    ringing -> RingingControls(c, number, name)
                    state == Call.STATE_SELECT_PHONE_ACCOUNT -> SimPicker(c)
                    else -> ActiveControls(c, audio, state)
                }
                Spacer(Modifier.height(30.dp))
            }
        }
    }
}

@Composable
private fun PreviewControls(onClose: () -> Unit) {
    Text("Voici ce qui s'affichera quand ce numéro appelle", color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
    Spacer(Modifier.height(24.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
        RoundAction(HangupRed, Icons.Filled.CallEnd, "Fermer", 76.dp) { onClose() }
        RoundAction(AnswerGreen, Icons.Filled.Call, "Répondre", 76.dp) { onClose() }
    }
}

@Composable
private fun RoundAction(color: Color, icon: ImageVector, label: String, size: Dp = 72.dp, tint: Color = Color.White, onClick: () -> Unit) {
    val p = LocalPalette.current
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(size)
                .clip(CircleShape)
                .background(color)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) { Icon(icon, label, tint = tint, modifier = Modifier.size(size * 0.42f)) }
        Text(label, color = if (LocalOnMedia.current) Color.White else p.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
    }
}

@Composable
private fun ToggleAction(icon: ImageVector, label: String, active: Boolean, onClick: () -> Unit) {
    val p = LocalPalette.current
    RoundAction(
        color = if (active) p.accent else p.surface2,
        icon = icon,
        label = label,
        size = 64.dp,
        tint = if (active) p.onAccent else p.text,
        onClick = onClick
    )
}

@Composable
private fun RingingControls(call: Call, number: String, name: String?) {
    val ctx = LocalContext.current
    val p = LocalPalette.current
    var replies by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
        ToggleAction(Icons.Filled.Sms, "Message", false) { replies = true }
        ToggleAction(Icons.Filled.NotificationsOff, "Silence", false) { MagicEffects.silence(ctx) }
        ToggleAction(Icons.Filled.Alarm, "Dans 10 min", false) {
            Reminders.schedule(ctx, number, name, 10)
            run { com.dlvibe.dlphone.VoiceAnnouncer.stop(); call.reject(false, null) }
        }
    }
    Spacer(Modifier.height(30.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
        RoundAction(HangupRed, Icons.Filled.CallEnd, "Refuser", 76.dp) { run { com.dlvibe.dlphone.VoiceAnnouncer.stop(); call.reject(false, null) } }
        RoundAction(AnswerGreen, Icons.Filled.Call, "Répondre", 76.dp) {
            run { com.dlvibe.dlphone.VoiceAnnouncer.stop(); call.answer(VideoProfile.STATE_AUDIO_ONLY) }
        }
    }
    if (replies) {
        AlertDialog(
            onDismissRequest = { replies = false },
            containerColor = p.sheet,
            title = { Text("Refuser avec un message", color = p.text) },
            text = {
                Column {
                    Prefs.quickReplies().forEach { r ->
                        Text(
                            r, color = p.text,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable {
                                    replies = false
                                    run { com.dlvibe.dlphone.VoiceAnnouncer.stop(); call.reject(true, r) }
                                }
                                .padding(vertical = 12.dp, horizontal = 8.dp)
                        )
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { replies = false }) { Text("Annuler", color = p.accent) } }
        )
    }
}

@Composable
private fun ActiveControls(call: Call, audio: CallAudioState?, state: Int) {
    val p = LocalPalette.current
    var keypad by remember { mutableStateOf(false) }
    var dtmf by remember { mutableStateOf("") }
    val svc = CallManager.service
    val muted = audio?.isMuted == true
    val route = audio?.route ?: CallAudioState.ROUTE_EARPIECE
    val speaker = route == CallAudioState.ROUTE_SPEAKER
    val bluetoothAvailable = ((audio?.supportedRouteMask ?: 0) and CallAudioState.ROUTE_BLUETOOTH) != 0
    val held = state == Call.STATE_HOLDING

    if (keypad) {
        Text(dtmf, color = p.text, fontSize = 26.sp, maxLines = 1, modifier = Modifier.padding(bottom = 10.dp))
        Keypad(onPress = { d ->
            // Clavier d'appel : aucune annonce vocale des chiffres. Seules les
            // tonalités DTMF sont transmises au correspondant via Telecom.
            VoiceAnnouncer.stop()
            dtmf += d
            Dtmf.send(call, d)
        })
        TextButton(onClick = { keypad = false }) { Text("Masquer le clavier", color = p.accent) }
    } else {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            ToggleAction(if (muted) Icons.Filled.MicOff else Icons.Filled.Mic, "Muet", muted) {
                svc?.setMuted(!muted)
            }
            ToggleAction(Icons.Filled.Dialpad, "Clavier", false) {
                VoiceAnnouncer.stop()
                keypad = true
            }
            ToggleAction(Icons.Filled.VolumeUp, "Haut-parleur", speaker) {
                svc?.setAudioRoute(if (speaker) CallAudioState.ROUTE_WIRED_OR_EARPIECE else CallAudioState.ROUTE_SPEAKER)
            }
        }
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            ToggleAction(if (held) Icons.Filled.PlayArrow else Icons.Filled.Pause, if (held) "Reprendre" else "Attente", held) {
                if (held) call.unhold() else call.hold()
            }
            if (bluetoothAvailable) {
                val bt = route == CallAudioState.ROUTE_BLUETOOTH
                ToggleAction(Icons.Filled.Bluetooth, "Bluetooth", bt) {
                    svc?.setAudioRoute(if (bt) CallAudioState.ROUTE_WIRED_OR_EARPIECE else CallAudioState.ROUTE_BLUETOOTH)
                }
            }
            val ctx = LocalContext.current
            ToggleAction(Icons.Filled.AddIcCall, "Ajouter", false) {
                ctx.startActivity(Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
    }
    Spacer(Modifier.height(26.dp))
    RoundAction(HangupRed, Icons.Filled.CallEnd, "Raccrocher", 76.dp) { call.disconnect() }
}

@Composable
private fun SimPicker(call: Call) {
    val ctx = LocalContext.current
    val p = LocalPalette.current
    val tm = remember { ctx.getSystemService(TelecomManager::class.java) }
    val accounts: List<PhoneAccountHandle> = remember {
        try {
            tm?.callCapablePhoneAccounts ?: emptyList()
        } catch (_: SecurityException) {
            emptyList()
        }
    }
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (accounts.isEmpty()) Text("Aucune SIM disponible", color = p.muted)
        accounts.forEachIndexed { i, h ->
            val label = runCatching { tm?.getPhoneAccount(h)?.label?.toString() }.getOrNull() ?: "SIM ${i + 1}"
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(p.surface2)
                    .clickable { call.phoneAccountSelected(h, false) }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconPill(Icons.Filled.SimCard, p.accent, 36.dp)
                Text(label, color = p.text, fontWeight = FontWeight.Medium, modifier = Modifier.padding(start = 12.dp))
            }
        }
        Spacer(Modifier.height(10.dp))
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            RoundAction(HangupRed, Icons.Filled.CallEnd, "Annuler", 68.dp) { call.disconnect() }
        }
    }
}

