package com.example.mydm.ui

import android.webkit.CookieManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.mydm.browser.BrowserManager
import com.example.mydm.core.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

@Composable
fun SettingsScreen(manager: BrowserManager, onBack: () -> Unit) {
    val ctx = LocalContext.current; val app = appInstance(); val scope = rememberCoroutineScope()
    fun toast(m: String) = Toast.makeText(ctx, m, Toast.LENGTH_SHORT).show()
    var home by remember { mutableStateOf(Prefs.homeUrl) }
    var root by remember { mutableStateOf(Prefs.rootFolder) }
    var sub by rememberSaveable { mutableStateOf("main") }
    BackHandler(sub != "main") { sub = "main" }
    if (sub == "scripts") { ScriptsScreen { sub = "main" }; return }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 4.dp, top = 8.dp, end = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onBack) { Text("◀", fontSize = 18.sp) }
            Text("Paramètres", color = Txt, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {

            item {
                Section("Navigateur") {
                    Text("Page d'accueil", color = Txt)
                    OutlinedTextField(home, { home = it }, Modifier.fillMaxWidth().padding(top = 6.dp), singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { Prefs.updateHomeUrl(home); home = Prefs.homeUrl; toast("Enregistré") }))
                    Row {
                        TextButton({ Prefs.updateHomeUrl(home); home = Prefs.homeUrl; toast("Enregistré") }) { Text("Enregistrer") }
                        TextButton({ Prefs.updateHomeUrl(manager.current.url); home = Prefs.homeUrl; toast("Page actuelle définie") }) { Text("Page actuelle") }
                    }
                    Label("Moteur de recherche")
                    Chips(SearchEngine.entries.map { it.label to it }, Prefs.searchEngine) { Prefs.updateSearchEngine(it) }
                    Label("Recherche par photo")
                    Chips(ImageEngine.entries.map { it.label to it }, Prefs.imageEngine) { Prefs.updateImageEngine(it) }
                    Label("Taille du texte")
                    Chips(listOf(80, 100, 120, 150).map { "$it %" to it }, Prefs.textZoom) { Prefs.updateTextZoom(it) }
                    SwitchRow("Mode ordinateur", "Version bureau des sites (recharge les onglets)", Prefs.desktopMode) { Prefs.updateDesktopMode(it) }
                    SwitchRow("Bloquer les pop-ups", "Ignore les fenêtres ouvertes sans clic de votre part", Prefs.blockPopups) { Prefs.updateBlockPopups(it) }
                    SwitchRow("Bloquer pubs et traqueurs", "Liste d'hôtes publicitaires courants", Prefs.blockAds) { Prefs.updateBlockAds(it) }
                    SwitchRow("JavaScript", "Désactivé : beaucoup de sites ne fonctionnent plus", Prefs.jsEnabled) { Prefs.updateJs(it) }
                    SwitchRow("Charger les images", "Désactivez pour économiser les données", Prefs.loadImages) { Prefs.updateLoadImages(it) }
                    SwitchRow("Rouvrir les onglets au démarrage", "Retrouve vos onglets à la prochaine ouverture", Prefs.restoreTabs) { Prefs.updateRestoreTabs(it) }
                    SwitchRow("Liens externes dans un nouvel onglet", "Liens reçus d'autres applications", Prefs.externalNewTab) { Prefs.updateExternalNewTab(it) }
                }
            }

            item {
                Section("Téléchargements") {
                    Label("Connexions simultanées par fichier")
                    Chips(listOf(4, 8, 16, 32).map { "$it" to it }, Prefs.maxSegments) { Prefs.updateMaxSegments(it) }
                    Label("Téléchargements en même temps")
                    Chips(listOf(1, 2, 3, 5).map { "$it" to it }, Prefs.maxParallel) { Prefs.updateMaxParallel(it) }
                    Label("Limite de vitesse (par téléchargement)")
                    Chips(listOf("Illimitée" to 0, "500 Ko/s" to 500, "1 Mo/s" to 1024, "2 Mo/s" to 2048, "5 Mo/s" to 5120), Prefs.speedLimitKbps) { Prefs.updateSpeedLimit(it) }
                    SwitchRow("Wi-Fi uniquement", "Met les téléchargements en attente sur données mobiles", Prefs.wifiOnly) { Prefs.updateWifiOnly(it) }
                    SwitchRow("Télécharger directement les liens partagés", "Désactivé (conseillé) : un lien partagé vers MyDM — vidéo (Facebook, TikTok, YouTube…), image, APK, document, logiciel — ouvre un écran « Analyse en cours » puis les formats ou le fichier trouvé. Activé : le téléchargement démarre aussitôt", Prefs.autoDownloadShared) { Prefs.updateAutoDownloadShared(it) }
                    Label("Arrière-plan : si Android coupe les téléchargements écran éteint")
                    OutlinedButton({
                        runCatching { ctx.startActivity(android.content.Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, android.net.Uri.parse("package:" + ctx.packageName))) }
                            .onFailure { toast("Réglages > Applications > MyDM > Batterie > Sans restriction") }
                    }) { Text("Autoriser sans restriction de batterie") }
                    Label("Dossier principal (Download/…)")
                    OutlinedTextField(root, { root = it }, Modifier.fillMaxWidth(), singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { Prefs.updateRootFolder(root); root = Prefs.rootFolder; toast("Enregistré") }))
                    TextButton({ Prefs.updateRootFolder(root); root = Prefs.rootFolder; toast("Dossier : Download/${Prefs.rootFolder}") }) { Text("Enregistrer") }
                    Label("Lignes affichées dans la notification (les autres : pastille +N)")
                    Chips(listOf(3, 5, 8).map { "$it" to it }, Prefs.notifLines) { Prefs.updateNotifLines(it) }
                    SwitchRow("Relancer automatiquement en cas d'échec", "Erreur serveur (503), coupure, délai dépassé : nouvel essai tout seul, de plus en plus espacé (jusqu'à 12 fois)", Prefs.autoRetry) { Prefs.updateAutoRetry(it) }
                    SwitchRow("Notifier à la fin", "Une notification par fichier terminé", Prefs.notifyDone) { Prefs.updateNotifyDone(it) }
                }
            }

            item {
                Section("Apparence") {
                    Label("Style (fond, cartes, texte et couleurs)")
                    ThemePicker(Prefs.themeMode) { Prefs.updateThemeMode(it) }
                    Label("Couleur d'accent")
                    Chips(AccentColor.entries.map { it.label to it }, Prefs.accent) { Prefs.updateAccent(it) }
                }
            }

            item {
                Section("Analyse de liens & séries") {
                    SwitchRow("Pré-analyser les vidéos", "YouTube / Facebook / TikTok : l'analyse démarre dès l'ouverture de la page, la fenêtre de téléchargement s'ouvre instantanément", Prefs.prefetchLinks) { Prefs.updatePrefetch(it) }
                    SwitchRow("Proposer les liens copiés", "Affiche un bandeau quand un lien est dans le presse-papiers", Prefs.clipboardWatch) { Prefs.updateClipboardWatch(it) }
                    Label("Durée max. d'analyse d'une page (sans lecture)")
                    Chips(listOf(5, 8, 12, 20).map { "$it s" to it }, Prefs.scanSeconds) { Prefs.updateScanSeconds(it) }
                    Label("Lecteurs intégrés (iframes) testés par page")
                    Chips(listOf(1, 3, 5, 8).map { "$it" to it }, Prefs.scanEmbeds) { Prefs.updateScanEmbeds(it) }
                    SwitchRow("Mise à jour automatique de yt-dlp", "Une fois par jour (YouTube change souvent)", Prefs.autoUpdateYt) { Prefs.updateAutoUpdateYt(it) }
                    TextButton({ toast("Mise à jour en cours…"); app.updateYtNow { toast(it) } }) { Text("Mettre à jour yt-dlp maintenant") }
                    // ── Mise à jour de MyDM (OTA)
                    var updUrl by remember { mutableStateOf(Prefs.updateUrl) }
                    SwitchRow("Mise à jour automatique de MyDM", "Vérifie au démarrage (au plus toutes les 6 h) et propose d'installer la nouvelle version", Prefs.autoUpdateCheck) { Prefs.updateAutoUpdateCheck(it) }
                    Label("Adresse de mise à jour (dépôt GitHub public ou fichier JSON)")
                    OutlinedTextField(updUrl, { updUrl = it }, Modifier.fillMaxWidth(), singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { Prefs.updateUpdateUrl(updUrl); toast("Enregistré") }))
                    TextButton({
                        Prefs.updateUpdateUrl(updUrl); toast("Recherche en cours…")
                        scope.launch {
                            when (val r = Updater.check(ctx, force = true)) {
                                is Updater.Result.Available -> Updater.pending = r.info
                                is Updater.Result.UpToDate -> toast("MyDM est à jour (${Updater.currentName(ctx)})")
                                is Updater.Result.Error -> toast(r.msg)
                            }
                        }
                    }) { Text("Rechercher une mise à jour de MyDM (${Updater.currentName(ctx)})") }
                }
            }

            item {
                Section("Lecteur intégré") {
                    SwitchRow("Lire le suivant automatiquement", "Enchaîne les vidéos / musiques / épisodes du dossier", Prefs.autoPlayNext) { Prefs.updateAutoPlayNext(it) }
                    SwitchRow("Reprendre où j'en étais", "Mémorise la position de chaque vidéo ou musique", Prefs.resumePlayback) { Prefs.updateResumePlayback(it) }
                    SwitchRow("Écran toujours allumé", "Pendant la lecture d'une vidéo", Prefs.keepScreenOn) { Prefs.updateKeepScreenOn(it) }
                    SwitchRow("Confirmer avant de supprimer", "Demande confirmation dans les dossiers et la liste des téléchargements", Prefs.confirmDelete) { Prefs.updateConfirmDelete(it) }
                    Text("MyDM peut aussi être choisi comme application pour ouvrir vos vidéos, musiques, images, PDF, textes et APK depuis un gestionnaire de fichiers.",
                        color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
                }
            }

            item {
                Section("Détection de médias") {
                    SwitchRow("Détection automatique en naviguant", "Désactivé : rien n'est ajouté à « À télécharger » sans votre demande (bouton ⬇ / Analyser)", Prefs.autoDetect) { Prefs.updateAutoDetect(it) }
                    SwitchRow("Vidéos", "mp4, webm, mkv, HLS (.m3u8)…", Prefs.detectVideo) { Prefs.updateDetectVideo(it) }
                    SwitchRow("Audio", "mp3, m4a…", Prefs.detectAudio) { Prefs.updateDetectAudio(it) }
                    SwitchRow("Fichiers", "apk, pdf, zip, rar…", Prefs.detectFiles) { Prefs.updateDetectFiles(it) }
                }
            }

            item {
                Section("Développeur & extensions") {
                    SwitchRow("Console JavaScript", "Enregistre console.log et erreurs de chaque onglet", Prefs.captureConsole) { Prefs.updateCaptureConsole(it) }
                    Label("Taille max. d'une archive de site")
                    Chips(listOf(50, 100, 250, 500).map { "$it Mo" to it }, Prefs.siteMaxMb) { Prefs.updateSiteMaxMb(it) }
                    Spacer(Modifier.height(6.dp))
                    Button({ sub = "scripts" }) { Text("Extensions / scripts utilisateur (${UserScripts.list.size})") }
                    Text("Les extensions Chrome (.crx) ne fonctionnent pas dans une WebView Android ; les scripts utilisateur (style Tampermonkey) offrent la plupart des usages.",
                        color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
                }
            }

            item {
                Section("Données") {
                    TextButton({ CookieManager.getInstance().removeAllCookies(null); CookieManager.getInstance().flush(); toast("Cookies effacés") }) { Text("Effacer les cookies") }
                    TextButton({ manager.clearCacheAndHistory(); toast("Cache et historique effacés") }) { Text("Effacer le cache et l'historique") }
                    TextButton({ manager.clearDetected(); toast("Liste des médias vidée") }) { Text("Vider les médias détectés") }
                    TextButton({ scope.launch { app.db.downloadDao().clearCompleted(); toast("Historique des téléchargements effacé") } }) { Text("Effacer l'historique des téléchargements terminés") }
                }
            }
        }
    }
}

// ───────────── Extensions : scripts utilisateur ─────────────
@Composable
private fun ScriptsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    var editing by remember { mutableStateOf<UserScript?>(null) }
    var importUrl by remember { mutableStateOf("") }
    val http = remember { OkHttpClient() }

    editing?.let { s ->
        var name by remember(s.id) { mutableStateOf(s.name) }
        var match by remember(s.id) { mutableStateOf(s.match) }
        var code by remember(s.id) { mutableStateOf(s.code) }
        BackHandler { editing = null }
        Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Script", color = Txt, fontSize = 20.sp)
            OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Nom") })
            OutlinedTextField(match, { match = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Pages concernées (ex. https://*.youtube.com/*)") })
            OutlinedTextField(code, { code = it }, Modifier.fillMaxWidth().weight(1f), label = { Text("Code JavaScript") })
            Row {
                Button({ UserScripts.upsert(s.copy(name = name.ifBlank { "Script" }, match = match, code = code)); editing = null }) { Text("Enregistrer") }
                Spacer(Modifier.width(8.dp))
                OutlinedButton({ editing = null }) { Text("Annuler") }
            }
        }
        return
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 4.dp, top = 8.dp, end = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onBack) { Text("◀", fontSize = 18.sp) }
            Text("Extensions", color = Txt, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton({ editing = UserScript(name = "Nouveau script", match = "*", code = "// document.body.style.background = '#000';") }) { Text("＋ Ajouter") }
        }
        Column(Modifier.fillMaxWidth().glass().padding(12.dp).padding(bottom = 4.dp)) {
            Text("Importer un script (.user.js)", color = Muted, fontSize = 12.sp)
            OutlinedTextField(importUrl, { importUrl = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("https://…/script.user.js") })
            TextButton({
                scope.launch {
                    val code = withContext(Dispatchers.IO) {
                        runCatching { http.newCall(Request.Builder().url(importUrl.trim()).build()).execute().use { it.body!!.string() } }.getOrNull()
                    }
                    if (code == null) Toast.makeText(ctx, "Téléchargement impossible", Toast.LENGTH_SHORT).show()
                    else {
                        val name = Regex("@name\\s+(.+)").find(code)?.groupValues?.get(1)?.trim() ?: importUrl.substringAfterLast('/')
                        val match = Regex("@match\\s+(\\S+)").find(code)?.groupValues?.get(1) ?: "*"
                        UserScripts.upsert(UserScript(name = name, match = match, code = code)); importUrl = ""
                    }
                }
            }, enabled = importUrl.startsWith("http")) { Text("Importer") }
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (UserScripts.list.isEmpty()) item { Text("Aucun script. Ajoutez-en un ou importez un .user.js.", color = Muted, fontSize = 12.sp) }
            items(UserScripts.list.toList(), key = { it.id }) { s ->
                Row(Modifier.fillMaxWidth().glass().clickable { editing = s }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(s.name, color = Txt, maxLines = 1)
                        Text(s.match.ifBlank { "*" }, color = Muted, fontSize = 11.sp, maxLines = 1)
                    }
                    Switch(s.enabled, { UserScripts.upsert(s.copy(enabled = it)) })
                    TextButton({ UserScripts.remove(s.id) }) { Text("✕") }
                }
            }
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) =
    Column(Modifier.fillMaxWidth().glass().padding(16.dp)) {
        Text(title, color = Accent, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Spacer(Modifier.height(10.dp))
        content()
    }

@Composable
private fun Label(t: String) = Text(t, color = Txt, modifier = Modifier.padding(top = 10.dp, bottom = 4.dp))

@Composable
private fun <T> Chips(options: List<Pair<String, T>>, selected: T, onSelect: (T) -> Unit) =
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (label, v) -> FilterChip(selected == v, { onSelect(v) }, label = { Text(label) }) }
    }

@Composable
private fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) =
    Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, color = Txt)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
        Switch(checked, onChange)
    }

/** Styles complets : chaque carte montre le fond, le texte et l'accent du style. */
@Composable
private fun ThemePicker(selected: ThemeMode, onSelect: (ThemeMode) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        ThemeMode.entries.forEach { m ->
            val on = m == selected
            val shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)
            Column(
                Modifier.width(84.dp)
                    .clip(shape)
                    .background(Color(m.bg))
                    .border(if (on) 3.dp else 1.dp, if (on) Accent else Outline, shape)
                    .clickable { onSelect(m) }
                    .padding(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(Modifier.fillMaxWidth().height(30.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(8.dp)).background(Color(m.surface1)),
                    contentAlignment = Alignment.Center) {
                    Text(if (m == ThemeMode.SYSTEM) "A" else "Aa", color = Color(m.text), fontSize = 14.sp)
                }
                Spacer(Modifier.height(6.dp))
                Box(Modifier.size(14.dp).clip(androidx.compose.foundation.shape.CircleShape).background(Color(m.accent)))
                Spacer(Modifier.height(4.dp))
                Text(m.label, color = Color(m.text), fontSize = 11.sp, maxLines = 1)
            }
        }
    }
}
