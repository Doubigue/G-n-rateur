package com.example.mydm.ui

import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import android.webkit.CookieManager
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.mydm.browser.FoundFile
import com.example.mydm.browser.PageScan
import com.example.mydm.browser.PageScanner
import com.example.mydm.core.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Fenêtre « Télécharger » :
 *  • lien YouTube / Facebook / TikTok → qualités + tailles (analyse pré-chargée, donc quasi instantanée) ;
 *  • lien direct vers un fichier (image, APK, document, logiciel, archive…) → nom, type, taille + Télécharger ;
 *  • autre page (cinezzz, papadustream…) → analyse SANS lecture : vidéos, images et fichiers de la page ;
 *  • médias détectés pendant la navigation.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DownloadSheet(
    found: SnapshotStateList<DetectedMedia>, pageUrl: String, onDismiss: () -> Unit,
    autoAnalyze: Boolean = false      // lien reçu d'une autre appli / copié : analyse lancée dès l'ouverture
) {
    val ctx = LocalContext.current
    val app = appInstance()
    val scope = rememberCoroutineScope()

    var link by remember { mutableStateOf(if (pageUrl.startsWith("http")) pageUrl else "") }
    var loading by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf(MediaResolver.cached(link)) }
    var scan by remember { mutableStateOf<PageScan?>(null) }
    var direct by remember { mutableStateOf<AutoDownload.FileProbe?>(null) }     // le lien est lui-même un fichier
    var infoUrl by remember { mutableStateOf(link) }
    var error by remember { mutableStateOf<String?>(null) }
    val sizes = remember { mutableStateMapOf<String, Long?>() }
    val ytState by app.ytState.collectAsState()
    var startAt by remember { mutableStateOf<Long?>(null) }          // null = tout de suite
    var showSchedule by remember { mutableStateOf(false) }
    // Nom du fichier : proposé d'après le titre, modifiable avant de télécharger (l'extension est ajoutée toute seule)
    var customName by remember { mutableStateOf("") }
    val suggested = (direct?.name?.let { cleanName(it.substringBeforeLast('.')) }
        ?: info?.title?.let { cleanName(it) }
        ?: scan?.title?.takeIf { it.isNotBlank() }?.let { cleanName(it) }
        ?: found.firstOrNull()?.displayName()?.let { cleanName(stripMediaExt(it)) }).orEmpty()
    LaunchedEffect(suggested) { customName = suggested }
    /** Nom saisi par l'utilisateur (sans extension), ou null s'il n'a pas été modifié. */
    fun typedName(): String? = cleanName(stripMediaExt(customName.trim())).takeIf { it.isNotBlank() && it != suggested }
    fun addedMsg() = startAt?.let { "Programmé : ${formatWhen(it)}" } ?: "Téléchargement ajouté"

    fun analyze() {
        val u = link.trim()
        if (u.isEmpty()) return
        val url = if (u.startsWith("http")) u else Prefs.resolveInput(u)
        loading = true; error = null; info = null; scan = null; direct = null
        scope.launch {
            if (MediaResolver.isSupportedPage(url)) {
                val r = runCatching { MediaResolver.ytInfo(app, url) }
                r.onSuccess { info = it; infoUrl = url }
                r.onFailure { e ->
                    // Publication sans vidéo (photo Instagram / Facebook / Pinterest…) : on cherche les images et fichiers
                    val sc = runCatching { PageScanner.scan(ctx, url, null, false) }.getOrNull()
                    if (sc != null && (sc.files.isNotEmpty() || sc.media.isNotEmpty())) { scan = sc; infoUrl = url }
                    else error = (e.message ?: "Analyse impossible").take(240)
                }
            } else {
                // 1) Le lien est-il directement un fichier (image, APK, PDF, ZIP, EXE, DOCX…) ?
                val d = AutoDownload.probeDirect(url)
                if (d != null) { direct = d; infoUrl = url; loading = false; return@launch }
                // 2) Sinon c'est une page : vidéos, images et fichiers qu'elle contient
                runCatching { PageScanner.scan(ctx, url, null, true) }
                    .onSuccess {
                        scan = it; infoUrl = url
                        if (it.media.isEmpty() && it.embeds.isEmpty() && it.files.isEmpty()) {
                            // Rien dans la page : yt-dlp sait extraire la vidéo de nombreux autres sites
                            runCatching { withTimeoutOrNull(60_000L) { MediaResolver.ytInfo(app, url) } }.getOrNull()?.let { yi ->
                                info = yi; infoUrl = url; scan = null
                            } ?: run { error = "Aucune vidéo, image ni fichier trouvé dans ce lien. Pour une vidéo, essayez de la lancer dans la page, ou augmentez la durée d'analyse (Paramètres)." }
                        }
                    }
                    .onFailure { error = (it.message ?: "Analyse impossible").take(240) }
            }
            loading = false
        }
    }

    // Ouverture : analyse automatique (YouTube/Facebook/TikTok : déjà pré-chargée ; autre page : analyse sans lecture)
    LaunchedEffect(Unit) {
        if (link.isBlank() || info != null) return@LaunchedEffect
        if (autoAnalyze) { analyze(); return@LaunchedEffect }
        if (MediaResolver.isSupportedPage(link)) { if (MediaResolver.isVideoPage(link)) analyze() }
        // autre page : aucune analyse automatique — c'est vous qui choisissez le lecteur ; on affiche la vidéo en lecture
    }

    fun downloadYt(opt: QualityOption) {
        val i = info ?: return
        scope.launch {
            val custom = typedName()
            val id = app.downloadEngine.enqueueYt(infoUrl, custom ?: i.title, opt, durationSec = i.durationSec, sizeBytes = opt.sizeBytes, exactName = custom != null)
            DownloadActions.launch(ctx, app, id, startAt)
            Toast.makeText(ctx, addedMsg(), Toast.LENGTH_SHORT).show()
            onDismiss()
        }
    }

    fun downloadDirect(m: DetectedMedia, variant: HlsVariant? = null) {
        scope.launch {
            val custom = typedName()
            DownloadActions.queue(ctx, app, m, name = custom, variant = variant, startAt = startAt, exactName = custom != null)
            Toast.makeText(ctx, addedMsg(), Toast.LENGTH_SHORT).show()
        }
    }

    /** Fichier quelconque (image, APK, document, logiciel…) : nom et extension d'origine conservés. */
    fun downloadFile(url: String, origName: String, mime: String?, referer: String?, ua: String?) {
        scope.launch {
            val ext = origName.substringAfterLast('.', "")
            val name = customName.trim().takeIf { direct != null && it.isNotBlank() && it != suggested }
                ?.let { cleanName(it).removeSuffix(".$ext") + if (ext.isNotEmpty()) ".$ext" else "" } ?: origName
            val cookies = runCatching { CookieManager.getInstance().getCookie(url) }.getOrNull()
            val id = app.downloadEngine.enqueueFile(url, name, mime, ua ?: AutoDownload.UA, referer, cookies)
            DownloadActions.launch(ctx, app, id, startAt)
            Toast.makeText(ctx, addedMsg(), Toast.LENGTH_SHORT).show()
            if (direct != null) onDismiss()
        }
    }

    fun downloadEmbed(embed: String) {
        scope.launch {
            val name = typedName() ?: cleanName(scan?.title.orEmpty()).ifBlank { "video" }
            val id = app.downloadEngine.enqueueYt(embed, name, QualityOption("", null, false, "bv*+ba/b"), infoUrl, exactName = typedName() != null)
            DownloadActions.launch(ctx, app, id, startAt)
            Toast.makeText(ctx, startAt?.let { "Programmé : ${formatWhen(it)}" } ?: "Ajouté (yt-dlp)", Toast.LENGTH_SHORT).show()
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = Bg
    ) {
        LazyColumn(
            Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item { Text("Télécharger", color = Txt, fontSize = 20.sp) }

            item {
                Column(Modifier.fillMaxWidth().glass().padding(12.dp)) {
                    Text("Lien à analyser : vidéo, image, APK, document, logiciel, archive ou page web", color = Muted, fontSize = 12.sp)
                    OutlinedTextField(link, { link = it }, Modifier.fillMaxWidth(), singleLine = true,
                        placeholder = { Text("Collez un lien ici") })
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button({ analyze() }, enabled = link.isNotBlank() && !loading) { Text("Analyser") }
                        Spacer(Modifier.width(10.dp))
                        if (ytState == "loading") Text("Moteur en préparation…", color = Muted, fontSize = 11.sp)
                        else if (ytState.startsWith("error:")) Text("Moteur yt-dlp indisponible", color = Danger, fontSize = 11.sp)
                        else Text("Pour un lien collé", color = Muted, fontSize = 11.sp)
                    }
                }
            }
            if (suggested.isNotBlank()) item {
                Column(Modifier.fillMaxWidth().glass().padding(12.dp)) {
                    Text("Nom du fichier (modifiable)", color = Muted, fontSize = 12.sp)
                    OutlinedTextField(customName, { customName = it }, Modifier.fillMaxWidth(), singleLine = true,
                        trailingIcon = { if (customName != suggested) TextButton({ customName = suggested }) { Text("↺", color = Muted, fontSize = 18.sp) } })
                    Text("L'extension (.mp4, .mp3…) est ajoutée automatiquement.", color = Muted, fontSize = 11.sp)
                }
            }
            item { ScheduleBar(startAt, { showSchedule = true }, { startAt = null }) }
            if (loading) item {
                Column(Modifier.fillMaxWidth().glass().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    CircularProgressIndicator()
                    Text("Analyse en cours…", color = Txt, fontSize = 18.sp)
                    Text(
                        (Uri.parse(link).host?.removePrefix("www.")?.removePrefix("m.") ?: "") +
                            if (MediaResolver.isSupportedPage(link)) "" else " — recherche des vidéos, images et fichiers",
                        color = Accent, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    Text("Type de fichier, formats et tailles disponibles", color = Muted, fontSize = 12.sp)
                    if (ytState == "loading") Text("Le moteur d'analyse démarre, un instant…", color = Muted, fontSize = 11.sp)
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                }
            }
            error?.let { e -> item { Text(e, color = Danger, fontSize = 12.sp) } }

            // ── Le lien est un fichier
            direct?.let { d ->
                item { Text("Fichier détecté", color = Txt, modifier = Modifier.padding(top = 4.dp)) }
                item {
                    Column(Modifier.fillMaxWidth().glass().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (kindOf(d.name, d.mime) == ViewKind.IMAGE)
                                RemoteImage(d.url, Modifier.size(64.dp).clip(RoundedCornerShape(8.dp)))
                            else Text(fileIcon(d.name, d.mime), fontSize = 34.sp)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(d.name, color = Txt, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text(fileTypeLabel(d.name, d.mime) + " • " + (d.size?.let { formatSize(it) } ?: "taille inconnue") +
                                    " • " + (Uri.parse(d.url).host ?: ""), color = Muted, fontSize = 12.sp, maxLines = 2)
                            }
                        }
                        Button({ downloadFile(d.url, d.name, d.mime, infoUrl.takeIf { it != d.url }, null) }, Modifier.fillMaxWidth()) { Text("⬇ Télécharger") }
                    }
                }
            }

            // ── YouTube / Facebook / TikTok
            info?.let { i ->
                item { Text(i.title + (i.uploader?.let { " — $it" } ?: "") + (if (i.durationSec > 0) "  •  ⏱ ${formatDuration(i.durationSec)}" else ""), color = Accent, maxLines = 2, overflow = TextOverflow.Ellipsis) }
                val (audioOpts, videoOpts) = i.options.partition { it.label.startsWith("Audio") }
                if (videoOpts.isNotEmpty()) item { Text("Formats vidéo (${videoOpts.size})", color = Txt, modifier = Modifier.padding(top = 4.dp)) }
                items(videoOpts.distinctBy { it.label }, key = { "v" + it.label }) { o -> FormatRow(o) { downloadYt(o) } }
                if (audioOpts.isNotEmpty()) item { Text("Audio seulement", color = Txt, modifier = Modifier.padding(top = 4.dp)) }
                items(audioOpts.distinctBy { it.label }, key = { "a" + it.label }) { o -> FormatRow(o) { downloadYt(o) } }
            }

            // ── Page analysée sans lecture
            scan?.let { sc ->
                if (sc.title.isNotBlank()) item { Text(sc.title, color = Accent, maxLines = 2, overflow = TextOverflow.Ellipsis) }
                if (sc.media.isNotEmpty()) {
                    item { Text("Vidéos et fichiers trouvés (${sc.media.size})", color = Txt, modifier = Modifier.padding(top = 4.dp)) }
                    items(sc.media.distinctBy { it.url }, key = { "s" + it.url }) { m -> MediaRow(m, sizes) { downloadDirect(m) } }
                }
                if (sc.files.isNotEmpty()) {
                    item { Text("Images et fichiers trouvés (${sc.files.size})", color = Txt, modifier = Modifier.padding(top = 4.dp)) }
                    items(sc.files, key = { "x" + it.url }) { f -> FileRow(f) { downloadFile(f.url, f.name, null, sc.pageUrl ?: infoUrl, sc.ua) } }
                }
                if (sc.media.none { it.type == MediaType.VIDEO || it.type == MediaType.HLS } && sc.embeds.isNotEmpty()) {
                    item {
                        Text("Lecteurs intégrés (yt-dlp peut en extraire certains)", color = Txt, modifier = Modifier.padding(top = 4.dp))
                    }
                    items(sc.embeds.distinct().take(6), key = { "e" + it }) { e ->
                        Row(Modifier.fillMaxWidth().glass().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text((Uri.parse(e).host ?: e) + if (MediaResolver.isKnownHoster(e)) "  ✓" else "", color = Txt, fontSize = 13.sp,
                                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                            Button({ downloadEmbed(e) }) { Text("Essayer") }
                        }
                    }
                }
            }

            // ── Médias détectés pendant la navigation
            if (!(autoAnalyze && found.isEmpty())) item { Text("Vidéo en cours de lecture", color = Txt, modifier = Modifier.padding(top = 8.dp)) }
            if (found.isEmpty() && !autoAnalyze) item {
                Text("Aucune vidéo en lecture. Choisissez le lecteur dans la page et lancez la vidéo, puis rouvrez ce panneau.", color = Muted, fontSize = 12.sp)
            }
            items(found.toList().distinctBy { it.url }, key = { "f" + it.url }) { m -> PlayingCard(m, sizes) { v -> downloadDirect(m, v) } }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
    if (showSchedule) ScheduleDialog(onDismiss = { showSchedule = false }) { startAt = it; showSchedule = false }
}

private fun fileIcon(name: String, mime: String?): String {
    val e = extOf(name)
    return when {
        e in setOf("exe", "msi", "dmg", "pkg", "deb", "rpm", "appimage", "iso", "img", "jar") -> "💿"
        e in setOf("zip", "rar", "7z", "tar", "gz", "tgz", "bz2", "xz", "xapk", "apks", "obb") -> "🗜️"
        e in setOf("doc", "docx", "odt", "rtf", "xls", "xlsx", "ods", "csv", "ppt", "pptx", "odp", "epub", "mobi") -> "📄"
        else -> when (kindOf(name, mime)) {
            ViewKind.VIDEO -> "🎞️"; ViewKind.AUDIO -> "🎵"; ViewKind.IMAGE -> "🖼️"; ViewKind.PDF -> "📕"
            ViewKind.TEXT -> "📝"; ViewKind.APK -> "🤖"; ViewKind.OTHER -> "📦"
        }
    }
}

private fun fileTypeLabel(name: String, mime: String?): String {
    val e = extOf(name)
    return when {
        e in setOf("exe", "msi") -> "Logiciel Windows (.$e)"
        e in setOf("dmg", "pkg") -> "Logiciel macOS (.$e)"
        e in setOf("deb", "rpm", "appimage") -> "Logiciel Linux (.$e)"
        e in setOf("iso", "img") -> "Image disque (.$e)"
        e in setOf("xapk", "apks") -> "Application Android groupée (.$e)"
        e in setOf("zip", "rar", "7z", "tar", "gz", "tgz", "bz2", "xz") -> "Archive (.$e)"
        e in setOf("doc", "docx", "odt", "rtf") -> "Document texte (.$e)"
        e in setOf("xls", "xlsx", "ods", "csv") -> "Tableur (.$e)"
        e in setOf("ppt", "pptx", "odp") -> "Présentation (.$e)"
        e in setOf("epub", "mobi") -> "Livre numérique (.$e)"
        else -> when (kindOf(name, mime)) {
            ViewKind.APK -> "Application Android (APK)"
            ViewKind.IMAGE -> "Image" + if (e.isNotEmpty()) " (.$e)" else ""
            ViewKind.VIDEO -> "Vidéo" + if (e.isNotEmpty()) " (.$e)" else ""
            ViewKind.AUDIO -> "Audio" + if (e.isNotEmpty()) " (.$e)" else ""
            ViewKind.PDF -> "Document PDF"
            ViewKind.TEXT -> "Texte" + if (e.isNotEmpty()) " (.$e)" else ""
            ViewKind.OTHER -> if (e.isNotEmpty()) "Fichier .$e" else (mime ?: "Fichier")
        }
    }
}

/** Image / fichier trouvé dans la page : miniature pour les images, icône sinon. */
@Composable
private fun FileRow(f: FoundFile, onGet: () -> Unit) {
    Row(Modifier.fillMaxWidth().glass().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        if (kindOf(f.name, null) == ViewKind.IMAGE) RemoteImage(f.url, Modifier.size(52.dp).clip(RoundedCornerShape(8.dp)))
        else Text(fileIcon(f.name, null), fontSize = 26.sp)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(f.label, color = Txt, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
            Text(fileTypeLabel(f.name, null) + " • " + (Uri.parse(f.url).host ?: ""), color = Muted, fontSize = 11.sp, maxLines = 1)
        }
        Button(onGet, contentPadding = PaddingValues(horizontal = 12.dp)) { Text("⬇") }
    }
}

@Composable
private fun FormatRow(o: QualityOption, onGet: () -> Unit) {
    Row(Modifier.fillMaxWidth().glass().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(o.label, color = Txt)
            Text(o.sizeBytes?.let { (if (o.approx) "~" else "") + formatSize(it) } ?: "taille inconnue", color = Muted, fontSize = 12.sp)
        }
        Button(onGet) { Text("Télécharger") }
    }
}

@Composable
private fun MediaRow(m: DetectedMedia, sizes: MutableMap<String, Long?>, onGet: () -> Unit) {
    LaunchedEffect(m.url) { if (m.sizeBytes == null && m.url !in sizes) sizes[m.url] = MediaResolver.sizeOf(m) }
    val size = m.sizeBytes ?: sizes[m.url]
    Row(Modifier.fillMaxWidth().glass().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(m.displayName(), color = Txt, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
            Text(m.type.name + " • " + m.sizeText(size, m.url in sizes) +
                " • " + (Uri.parse(m.url).host ?: ""), color = Muted, fontSize = 11.sp, maxLines = 1)
        }
        Button(onGet, contentPadding = PaddingValues(horizontal = 12.dp)) { Text("⬇") }
    }
}

/** La vidéo en cours de lecture : durée, taille et — seulement si le flux en propose plusieurs — choix de la qualité. */
@Composable
private fun PlayingCard(m: DetectedMedia, sizes: MutableMap<String, Long?>, onGet: (HlsVariant?) -> Unit) {
    var meta by remember(m.url) { mutableStateOf(MediaResolver.cachedMeta(m.url)) }
    LaunchedEffect(m.url) { if (meta == null) meta = MediaResolver.probeMeta(m) }
    LaunchedEffect(m.url) { if (m.type != MediaType.HLS && m.sizeBytes == null && m.url !in sizes) sizes[m.url] = MediaResolver.probeSize(m) }
    // Fichier direct : taille exacte ; flux HLS : taille estimée (débit × durée ou segments mesurés), « ~ » devant
    val size = m.sizeBytes ?: if (m.type == MediaType.HLS) meta?.sizeBytes else sizes[m.url]
    val probed = if (m.type == MediaType.HLS) meta != null else m.url in sizes
    val dur = meta?.durationSec
    val variants = meta?.variants.orEmpty()
    Column(Modifier.fillMaxWidth().glass().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(m.displayName(), color = Txt, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
        Text(buildString {
            append(m.type.name)
            append(if (dur != null) "  •  ⏱ ${formatDuration(dur)}" else if (meta == null) "  •  durée…" else "")
            append("  •  " + m.sizeText(size, probed))
            append("  •  " + (Uri.parse(m.url).host ?: ""))
        }, color = Muted, fontSize = 11.sp, maxLines = 2)
        if (variants.size >= 2) {
            Text("Choisissez la qualité", color = Muted, fontSize = 12.sp)
            variants.forEach { v ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(v.label, color = Txt)
                        Text(v.estimatedSize(dur)?.let { "~" + formatSize(it) } ?: "taille inconnue", color = Muted, fontSize = 11.sp)
                    }
                    Button({ onGet(v) }, contentPadding = PaddingValues(horizontal = 12.dp)) { Text("⬇ Télécharger") }
                }
            }
        } else Button({ onGet(null) }, Modifier.fillMaxWidth()) { Text("⬇ Télécharger") }
    }
}

private val MEDIA_EXT = Regex("\\.(mp4|mkv|webm|m4v|mov|avi|ts|m3u8|mp3|m4a|aac|ogg|opus|wav|flac)$", RegexOption.IGNORE_CASE)
/** Retire une extension média tapée ou héritée du nom (l'extension réelle est ajoutée au téléchargement). */
private fun stripMediaExt(s: String) = s.replace(MEDIA_EXT, "")
