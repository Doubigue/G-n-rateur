package com.example.mydm.browser

import android.content.Context
import android.net.Uri
import android.os.SystemClock
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebView
import com.example.mydm.core.DetectedMedia
import com.example.mydm.core.MediaDetector
import com.example.mydm.core.MediaResolver
import com.example.mydm.core.MediaType
import com.example.mydm.core.Prefs
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import org.json.JSONTokener
import kotlin.coroutines.resume

data class EpisodeLink(val url: String, val label: String, val season: Int?, val episode: Int?, val lang: String? = null)

/** Un lecteur de la liste du site (VOE, UQLOAD…) avec sa langue lue sur le drapeau. */
data class PlayerChoice(val idx: Int, val name: String, val lang: String?, val url: String?)

/** Fichier (image, APK, document, logiciel, archive…) trouvé dans une page analysée. */
data class FoundFile(val url: String, val name: String, val label: String)

data class PageScan(
    val title: String,
    val media: List<DetectedMedia>,   // flux vidéo / audio / fichiers trouvés
    val embeds: List<String>,         // lecteurs intégrés (iframes) de la page
    val episodes: List<EpisodeLink>,  // liens qui ressemblent à d'autres épisodes
    val players: List<PlayerChoice> = emptyList(),  // liste des lecteurs du site, du meilleur au moins bon
    val files: List<FoundFile> = emptyList(),       // images, APK, documents, logiciels… présents dans la page
    val ua: String? = null,
    val pageUrl: String? = null
)

/**
 * Analyse une page SANS la lire : une WebView invisible charge la page, lance les lecteurs en sourdine,
 * écoute le réseau (comme le navigateur) et lit le DOM (video, iframes, scripts, liens d'épisodes).
 */
object PageScanner {

    private const val COLLECT_JS = """
(function(){
  var out={title:document.title||'',media:[],iframes:[],links:[],files:[]};
  function abs(u){try{return new URL(u,location.href).href}catch(e){return null}}
  function push(a,u){var x=abs(u); if(x&&a.indexOf(x)<0)a.push(x)}
  document.querySelectorAll('video,audio').forEach(function(v){
    if(v.currentSrc)push(out.media,v.currentSrc); if(v.src)push(out.media,v.src);
    v.querySelectorAll('source').forEach(function(s){if(s.src)push(out.media,s.src)});
  });
  document.querySelectorAll('iframe').forEach(function(f){
    var s=f.src||f.getAttribute('data-src')||f.getAttribute('data-lazy-src'); if(s)push(out.iframes,s)});
  document.querySelectorAll('[data-embed],[data-link],[data-url],[data-player]').forEach(function(e){
    ['data-embed','data-link','data-url','data-player'].forEach(function(k){
      var v=e.getAttribute(k); if(v&&/^(https?:)?\/\//.test(v))push(out.iframes,v)})});
  try{
    var html=document.documentElement.innerHTML;
    var re=/https?:(?:\\?\/){2}[^"'\s<>\\]+?\.(?:m3u8|mp4|webm|mkv|mp3|m4a)(?:\?[^"'\s<>\\]*)?/gi;
    var m,n=0; while((m=re.exec(html))&&n<40){push(out.media,m[0].replace(/\\\//g,'/')); n++}
  }catch(e){}
  try{
    var FEXT=/\.(apk|xapk|apks|obb|exe|msi|dmg|pkg|deb|rpm|appimage|iso|img|zip|rar|7z|tar|gz|tgz|bz2|xz|jar|pdf|docx?|xlsx?|pptx?|odt|ods|odp|rtf|epub|mobi|csv|txt|torrent|jpe?g|png|gif|webp|bmp|heic|avif|svg|tiff?|mp3|m4a|flac|wav|ogg|opus|aac|mp4|mkv|webm|avi|mov)(\?|#|$)/i;
    var fseen={};
    function addF(u,t,k){var x=abs(u); if(!x||fseen[x]||!/^https?:/.test(x)||out.files.length>=80)return; fseen[x]=1; out.files.push({u:x,t:(t||'').replace(/\s+/g,' ').trim().slice(0,90),k:k||''})}
    // image principale de la page (Pinterest, Instagram, Facebook, sites d'images…)
    ['og:image','og:image:secure_url','twitter:image','twitter:image:src'].forEach(function(p){
      document.querySelectorAll('meta[property="'+p+'"],meta[name="'+p+'"]').forEach(function(m){var c=m.getAttribute('content'); if(c)addF(c,'Image principale','img')})});
    document.querySelectorAll('link[rel="image_src"]').forEach(function(l){if(l.href)addF(l.href,'Image principale','img')});
    // liens de téléchargement (apk, pdf, zip, exe, docx…)
    document.querySelectorAll('a[href]').forEach(function(a){
      var h=a.href||''; if(FEXT.test(h)||a.hasAttribute('download'))addF(h,a.innerText||a.getAttribute('download')||a.title||'','link')});
    // grandes images affichées
    var imgs=[].slice.call(document.images||[]).filter(function(i){return (i.naturalWidth||i.width)>=400&&(i.naturalHeight||i.height)>=300})
      .sort(function(a,b){return (b.naturalWidth*b.naturalHeight)-(a.naturalWidth*a.naturalHeight)}).slice(0,12);
    imgs.forEach(function(i){var s=i.currentSrc||i.src; if(s&&!/^data:/.test(s))addF(s,i.alt||'','img')});
  }catch(e){}
  out.players=[];
  try{
    var HOST=/^(voe|doodstream|dood|filemoon|netu|younetu|uqload|vidoza|upvid|uptostream|streamtape|mixdrop|vidmoly|supervideo|streamlare|mp4upload|vtube|sibnet|ok\.ru|vidhide|streamwish)$/i;
    function nm(e){return (e.innerText||'').replace(/\s+/g,' ').trim().replace(/^\d+\s*/,'')}
    function qual(e){var t=(e.innerText||'').trim(); return t.length>0&&t.length<=26&&HOST.test(nm(e))}
    var idx=0;
    document.querySelectorAll('li,a,div,span,button,tr,p').forEach(function(e){
      if(idx>=40||!qual(e))return;
      if(e.parentElement&&qual(e.parentElement))return;   // on garde la ligne entière, pas son sous-élément
      var attrs='',u=null;
      e.querySelectorAll('img,span,i,div').forEach(function(c){
        attrs+=' '+(c.getAttribute('src')||'')+' '+(c.getAttribute('alt')||'')+' '+(c.getAttribute('title')||'')+' '+(c.className&&c.className.baseVal===undefined?c.className:'')});
      attrs+=' '+(e.className&&e.className.baseVal===undefined?e.className:'')+' '+(e.getAttribute('data-lang')||'')+' '+(e.getAttribute('title')||'');
      attrs=attrs.toLowerCase();
      var lang=null;
      if(/vostfr|(^|[\/_\-. ])(en|uk|gb|us|vo)([\/_\-. ]|\.|$)/.test(attrs))lang='VO';
      else if(/(^|[\/_\-. ])(fr|vf|france|french)([\/_\-. ]|\.|$)/.test(attrs))lang='VF';
      [e].concat([].slice.call(e.querySelectorAll('*'))).forEach(function(x){
        [].slice.call(x.attributes||[]).forEach(function(a){
          if(!u&&/^(https?:)?\/\//.test(a.value)&&!/\.(png|jpe?g|gif|svg|webp|ico)/i.test(a.value))u=abs(a.value)})});
      e.setAttribute('data-mydm-i',String(idx));
      out.players.push({i:idx,n:nm(e),l:lang,u:u}); idx++;
    });
  }catch(e){}
  var seen={};
  document.querySelectorAll('a[href]').forEach(function(a){
    var u=abs(a.href); if(!u||seen[u]||out.links.length>=1500)return; seen[u]=1;
    out.links.push({u:u,t:(a.innerText||a.title||a.getAttribute('aria-label')||'').replace(/\s+/g,' ').trim().slice(0,90)})});
  document.querySelectorAll('select option[value]').forEach(function(o){
    var u=abs(o.value); if(u&&!seen[u]&&/^https?:/.test(u)&&out.links.length<1500){
      seen[u]=1; out.links.push({u:u,t:(o.textContent||'').trim().slice(0,90)})}});
  return JSON.stringify(out);
})()
"""

    private fun clickPlayerJs(i: Int) = """
(function(){
  var e=document.querySelector('[data-mydm-i="$i"]'); if(!e) return 'no';
  try{e.scrollIntoView({block:'center'})}catch(x){}
  ['mousedown','mouseup'].forEach(function(t){try{e.dispatchEvent(new MouseEvent(t,{bubbles:true,cancelable:true,view:window}))}catch(x){}});
  try{e.click()}catch(x){}
  return 'ok';
})()
"""

    /** Du meilleur au moins bon : français d'abord ; Uqload en tête, sinon l'ordre du site (le premier lecteur). */
    fun parsePlayers(js: JSONObject?): List<PlayerChoice> {
        val a = js?.optJSONArray("players") ?: return emptyList()
        val seen = HashSet<String>()
        val l = ArrayList<PlayerChoice>()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            val name = o.optString("n")
            val flag = o.optString("l").ifBlank { null }
            // Langue : le drapeau seul est peu fiable (classes CSS, sprites). Sur ces sites la liste française vient d'abord,
            // puis les mêmes lecteurs en version anglaise : un nom déjà vu = autre langue, sauf drapeau français explicite.
            val firstTime = seen.add(name.lowercase())
            val lang = when {
                flag == "VF" -> "VF"
                firstTime -> "VF"
                else -> "VO"
            }
            l += PlayerChoice(o.optInt("i"), name, lang, o.optString("u").ifBlank { null })
        }
        return l.sortedBy { p ->
            (if (p.lang == "VO") 1000 else 0) + (if (p.name.contains("uqload", true)) 0 else 10 + p.idx)
        }
    }

    private const val PLAY_JS = """
(function(){
  document.querySelectorAll('video,audio').forEach(function(v){
    try{v.muted=true;var p=v.play();if(p&&p.catch)p.catch(function(){})}catch(e){}});
  ['.vjs-big-play-button','.jw-icon-display','.jw-display-icon-container','.plyr__control--overlaid','.fp-play',
   '.dplayer-play-icon','.mejs__overlay-button','.play-button','.btn-play','.bigplay','.ytp-large-play-button',
   '.video-js','#player','.play','[aria-label=Play]','[title=Play]'].forEach(function(s){
    try{var e=document.querySelector(s); if(e)e.click()}catch(x){}});
  return 'ok';
})()
"""

    private val badEmbedHosts = listOf("youtube.com", "youtu.be", "facebook.com", "twitter.com", "x.com", "instagram.com",
        "google.com", "gstatic.com", "doubleclick.net", "disqus.com", "recaptcha.net", "googlesyndication.com",
        "adservice.google.com", "taboola.com", "outbrain.com", "popads.net", "histats.com", "addthis.com")

    private fun embedOk(u: String): Boolean {
        if (!u.startsWith("http")) return false
        val host = Uri.parse(u).host?.lowercase() ?: return false
        if (badEmbedHosts.any { host == it || host.endsWith(".$it") }) return false
        return !Regex("\\.(js|css|png|jpe?g|gif|webp|svg|ico)(\\?|#|$)", RegexOption.IGNORE_CASE).containsMatchIn(Uri.parse(u).path ?: "")
    }

    /** Lit le DOM d'une WebView déjà chargée (onglet courant) : médias, iframes, liens. Thread principal. */
    suspend fun collectFrom(web: WebView): JSONObject? {
        val raw = withTimeoutOrNull(4000) {
            suspendCancellableCoroutine<String?> { c -> web.evaluateJavascript(COLLECT_JS) { c.resume(it) } }
        } ?: return null
        val txt = runCatching { JSONTokener(raw).nextValue() as? String }.getOrNull() ?: return null
        return runCatching { JSONObject(txt) }.getOrNull()
    }

    /** Épisodes de la page affichée dans un onglet (instantané : pas de nouveau chargement). */
    suspend fun episodesOf(web: WebView, pageUrl: String): List<EpisodeLink> =
        collectFrom(web)?.let { parseEpisodes(it, pageUrl) } ?: emptyList()

    // ───────────── Analyse complète d'une page
    /** [autoPlayer] : choisit seul le lecteur (Uqload en français, sinon le premier) — réservé au téléchargement d'une saison. */
    suspend fun scan(ctx: Context, url: String, referer: String? = null, withEmbeds: Boolean = true, autoPlayer: Boolean = false): PageScan {
        val first = scanOne(ctx, url, referer, 0, autoPlayer)
        if (!withEmbeds) return first
        val media = LinkedHashMap<String, DetectedMedia>()
        first.media.forEach { media[it.url] = it }
        // Uqload d'abord, puis les hébergeurs connus ; on descend aussi dans les lecteurs imbriqués
        fun order(l: List<String>) = l.filter(::embedOk).distinct()
            .sortedWith(compareBy({ !it.contains("uqload", true) }, { !MediaResolver.isKnownHoster(it) }))
        fun hasVideo() = media.values.any { it.type == MediaType.VIDEO || it.type == MediaType.HLS }
        val allEmbeds = LinkedHashSet<String>()
        var cur = first
        var tried = 0
        for (rank in 0..(if (autoPlayer) 2 else 0)) {   // un seul passage, sauf saison : 3 lecteurs au plus
            if (rank > 0) {
                if (cur.players.size <= rank || first.players.size <= rank) break
                cur = runCatching { scanOne(ctx, url, referer, rank, true) }.getOrNull() ?: break
                cur.media.forEach { media.putIfAbsent(it.url, it) }
            }
            val queue = ArrayDeque(order(cur.embeds).filter { allEmbeds.add(it) })
            while (queue.isNotEmpty() && tried < 12 && !hasVideo()) {
                val e = queue.removeFirst(); tried++
                val r = runCatching { scanOne(ctx, e, url) }.getOrNull() ?: continue
                r.media.forEach { media.putIfAbsent(it.url, it) }
                order(r.embeds).filter { allEmbeds.add(it) }.take(2).forEach { queue.addLast(it) }
            }
            if (hasVideo()) break
        }
        return first.copy(media = media.values.toList(), embeds = order(allEmbeds.toList()))
    }

    private suspend fun scanOne(ctx: Context, url: String, referer: String?, playerRank: Int = 0, autoPlayer: Boolean = false): PageScan = withContext(Dispatchers.Main) {
        val web = SnifferWebView(ctx.applicationContext)
        val found = ArrayList<DetectedMedia>()
        // Écoute dès maintenant : le flux n'a pas de relecture
        val collector = launch(start = CoroutineStart.UNDISPATCHED) { web.detectedMedia.collect { found.add(it) } }
        try {
            // WebView hors écran : on lui donne une taille pour que les lecteurs se chargent
            web.measure(View.MeasureSpec.makeMeasureSpec(1080, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(1920, View.MeasureSpec.EXACTLY))
            web.layout(0, 0, 1080, 1920)
            web.onResume()
            web.guardNavigation = false          // aucune fenêtre ouverte par la page d'analyse
            var progress = 0
            web.onProgress = { progress = it }
            if (referer != null) web.loadUrl(url, mapOf("Referer" to referer)) else web.loadUrl(url)

            val limit = Prefs.scanSeconds * 1000L
            val t0 = SystemClock.uptimeMillis()
            var played = 0
            var pickedPlayer = false
            var foundAt = -1L
            while (true) {
                delay(400)
                val el = SystemClock.uptimeMillis() - t0
                if (el >= limit) break
                // Saison : on choisit un lecteur dans la liste de la page (Uqload en français, sinon le premier)
                if (autoPlayer && (progress >= 100 || el > 6000) && !pickedPlayer && el >= 1500) {
                    pickedPlayer = true
                    val pl = parsePlayers(collectFrom(web))
                    pl.getOrNull(playerRank)?.let { web.blockNavFor(3000); web.evaluateJavascript(clickPlayerJs(it.idx), null) }
                }
                if ((progress >= 100 || el > 6000) && played < 3 && el >= 1200L * (played + 1)) {
                    web.blockNavFor(2500); web.evaluateJavascript(PLAY_JS, null); played++
                }
                val hasVideo = found.any { it.type == MediaType.VIDEO || it.type == MediaType.HLS }
                if (hasVideo && foundAt < 0) foundAt = el
                if (foundAt >= 0 && el - foundAt > 1500) break
            }

            val js = collectFrom(web)
            val pageUrl = web.url ?: url
            val title = js?.optString("title").orEmpty().ifBlank { web.title.orEmpty() }
            val ua = web.settings.userAgentString
            val all = LinkedHashMap<String, DetectedMedia>()
            found.forEach { all[it.url] = it }
            js?.optJSONArray("media")?.let { a ->
                for (i in 0 until a.length()) {
                    val u = a.optString(i)
                    if (!u.startsWith("http") || u in all) continue
                    val type = MediaDetector.detect(u) ?: continue
                    all[u] = DetectedMedia(u, type, pageUrl, title, ua, CookieManager.getInstance().getCookie(u), pageUrl)
                }
            }
            val embeds = ArrayList<String>()
            js?.optJSONArray("iframes")?.let { a -> for (i in 0 until a.length()) embeds += a.optString(i) }
            val players = parsePlayers(js)
            // Liens directs fournis par la liste : essayés dans l'ordre de préférence
            players.mapNotNull { it.url }.reversed().forEach { if (it !in embeds) embeds.add(0, it) }
            PageScan(title, all.values.toList(), embeds, js?.let { parseEpisodes(it, pageUrl) } ?: emptyList(), players,
                parseFiles(js, all.keys), ua, pageUrl)
        } finally {
            collector.cancel()
            runCatching { web.stopLoading(); web.loadUrl("about:blank"); web.destroy() }
        }
    }

    /** Fichiers de la page (hors flux vidéo déjà listés), avec un nom lisible et leur type. */
    private fun parseFiles(js: JSONObject?, skip: Set<String>): List<FoundFile> {
        val a = js?.optJSONArray("files") ?: return emptyList()
        val out = LinkedHashMap<String, FoundFile>()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            val u = o.optString("u")
            if (!u.startsWith("http") || u in skip || u in out) continue
            val seg = Uri.decode(Uri.parse(u).lastPathSegment.orEmpty())
            var name = seg.ifBlank { "fichier" }
            if (!name.contains('.') && o.optString("k") == "img") name += ".jpg"
            val ext = name.substringAfterLast('.', "").lowercase()
            if (ext in setOf("html", "htm", "php", "asp", "aspx", "js", "css", "ico")) continue
            out[u] = FoundFile(u, name, o.optString("t").ifBlank { name })
        }
        return out.values.toList()
    }

    // ───────────── Épisodes
    private val epRe = Regex(
        """(?:s(?:aison|eason)?\s*0*(\d{1,2})[-_.x\s]*e(?:p(?:isode)?)?[-_.\s]*0*(\d{1,3}))|(?:\b(?:[eé]pisode|[eé]p\.?|e)[-_.\s]*0*(\d{1,3})\b)""",
        RegexOption.IGNORE_CASE)
    private val seasonRe = Regex("""(?:saison|season|\bs)[-_.\s]*0*(\d{1,2})\b""", RegexOption.IGNORE_CASE)
    // Morceaux d'URL qui changent d'un épisode à l'autre (retirés pour reconnaître « la même série »)
    private val tokenRe = Regex(
        """(?i)(s\d{1,2}[-_. ]?e\d{1,3}|\d{1,2}x\d{1,3}|saison[-_ .]?\d+|season[-_ .]?\d+|[eé]pisode[-_ .]?\d+|(?<![a-z])ep?[-_ .]?\d+(?![a-z])|vostfr|truefrench|(?<![a-z])vf(?![a-z])|(?<![a-z])vo(?![a-z])|french|streaming)""")
    private val voRe = Regex("""(?i)vostfr|sous-?titr|(?<![a-z])vost(?![a-z])|(?<![a-z])vo(?![a-z])""")
    private val vfRe = Regex("""(?i)(?<![a-z])vf(?![a-z])|truefrench|french|fran[cç]ais|(?<![a-z])fr(?![a-z])""")

    private fun hostKey(u: String) = Uri.parse(u).host?.lowercase()?.removePrefix("www.")

    /** « /serie/12-the-boys/saison-2/episode-3.html » → « serie/the-boys » : identique pour tous les épisodes de la série. */
    private fun seriesKey(u: String): String {
        val segs = Uri.decode(Uri.parse(u).path.orEmpty()).lowercase().split('/').filter { it.isNotBlank() }
        return segs.mapIndexedNotNull { i, raw ->
            var s = raw.replace(Regex("\\.(html?|php|aspx?)$"), "")
            s = s.replace(Regex("^\\d+[-_]"), "")
            s = tokenRe.replace(s, "").replace(Regex("[-_.\\s]{2,}"), "-").trim('-', '_', '.', ' ')
            when {
                s.isBlank() -> null
                s.all { it.isDigit() } && i == segs.lastIndex -> null   // identifiant propre à l'épisode
                else -> s
            }
        }.joinToString("/")
    }

    private fun langOf(text: String, url: String): String? {
        val s = "$text ${Uri.decode(url)}"
        return when {
            voRe.containsMatchIn(s) -> "VOSTFR"
            vfRe.containsMatchIn(s) -> "VF"
            else -> null
        }
    }

    /**
     * Épisodes de LA série affichée uniquement (pas les « derniers épisodes » d'autres séries présents dans la page).
     * À la racine d'une saison, seule cette saison est gardée ; un épisode en doublon garde sa version française.
     */
    fun parseEpisodes(js: JSONObject, pageUrl: String): List<EpisodeLink> {
        val links = js.optJSONArray("links") ?: return emptyList()
        val pageHost = hostKey(pageUrl)
        val pagePath = Uri.decode(Uri.parse(pageUrl).path.orEmpty())
        val pageSeason = seasonRe.find("$pagePath ${js.optString("title")}")?.groupValues?.get(1)?.toIntOrNull()
        val pageClean = pageUrl.substringBefore('#')
        val cands = LinkedHashMap<String, EpisodeLink>()
        val keys = HashMap<String, String>()
        for (i in 0 until links.length()) {
            val o = links.optJSONObject(i) ?: continue
            val u = o.optString("u").substringBefore('#')
            val t = o.optString("t")
            if (!u.startsWith("http") || u == pageClean || hostKey(u) != pageHost) continue
            val path = Uri.decode(Uri.parse(u).path.orEmpty())
            val m = epRe.find("$t ${path.substringAfterLast('/')}") ?: continue
            val season = (m.groupValues[1].toIntOrNull() ?: seasonRe.find("$t $path")?.groupValues?.get(1)?.toIntOrNull())
            val ep = m.groupValues[2].toIntOrNull() ?: m.groupValues[3].toIntOrNull() ?: continue
            if (u !in cands) {
                cands[u] = EpisodeLink(u, t.ifBlank { "Épisode $ep" }, season, ep, langOf(t, u))
                keys[u] = seriesKey(u)
            }
        }
        if (cands.isEmpty()) return emptyList()

        // 1) La bonne série : même « clé » que la page affichée, sinon le plus gros groupe cohérent
        val groups = cands.values.groupBy { keys[it.url].orEmpty() }
        val pageKey = seriesKey(pageUrl)
        val chosen = (if (pageKey.isNotBlank()) groups[pageKey] else null)
            ?: groups.entries.filter { it.key.isNotBlank() && pageKey.isNotBlank() && (it.key.startsWith(pageKey) || pageKey.startsWith(it.key)) }
                .maxByOrNull { it.value.size }?.value
            ?: groups.maxByOrNull { it.value.size }?.value
            ?: return emptyList()

        // 2) Racine d'une saison : on ne garde que cette saison
        var list = chosen.map { if (it.season == null && pageSeason != null) it.copy(season = pageSeason) else it }
        if (pageSeason != null && list.any { it.season == pageSeason }) list = list.filter { it.season == pageSeason }

        // 3) Un seul exemplaire par épisode : version française d'abord
        fun rank(l: String?) = when (l) { "VF" -> 0; null -> 1; else -> 2 }
        list = list.groupBy { (it.season ?: 0) to it.episode }.values.map { g -> g.minByOrNull { rank(it.lang) }!! }

        // Un seul lien « épisode » = probablement « suivant » : on n'en fait pas une série
        if (list.size < 2) return emptyList()
        return list.sortedWith(compareBy({ it.season ?: 0 }, { it.episode ?: Int.MAX_VALUE }))
    }

    /** Meilleur flux parmi ceux trouvés : on écarte les petits clips (publicités). */
    suspend fun pickBest(list: List<DetectedMedia>): DetectedMedia? {
        val vids = list.filter { it.type == MediaType.VIDEO || it.type == MediaType.HLS }
        if (vids.isEmpty()) return null
        val scored = vids.map { m ->
            val size = m.sizeBytes ?: if (m.type == MediaType.VIDEO) MediaResolver.probeSize(m) else null
            m to (if (m.type == MediaType.HLS) 400_000_000L + (if ("master" in m.url) 1L else 0L) else size ?: 0L)
        }
        val big = scored.filter { it.second >= 5_000_000L }
        return (big.ifEmpty { scored }).maxByOrNull { it.second }?.first
    }
}
