package com.example.mydm.ui

import android.graphics.BitmapFactory
import android.util.LruCache
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.mydm.browser.BrowserManager
import com.example.mydm.core.*
import com.example.mydm.downloader.DownloadService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

// ───── Miniatures (cache mémoire, sans bibliothèque externe)
private val imgHttp = OkHttpClient()
private val imgCache = object : LruCache<String, ImageBitmap>(80) {}

@Composable
private fun RemoteImage(url: String?, modifier: Modifier) {
    val bmp by produceState<ImageBitmap?>(url?.let { imgCache.get(it) }, url) {
        if (url == null || value != null) return@produceState
        value = withContext(Dispatchers.IO) {
            runCatching {
                imgHttp.newCall(Request.Builder().url(url).build()).execute().use { r ->
                    r.body?.byteStream()?.let { BitmapFactory.decodeStream(it) }?.asImageBitmap()
                }
            }.getOrNull()
        }?.also { imgCache.put(url, it) }
    }
    Box(modifier.background(Surface1)) {
        bmp?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
    }
}

private data class Quality(val label: String, val opt: QualityOption)

private fun heightOpt(h: Int) = Quality("${h}p",
    QualityOption("${h}p", null, false, "bv*[height<=$h][ext=mp4]+ba[ext=m4a]/bv*[height<=$h]+ba/b[height<=$h]"))

private val QUALITIES = listOf(
    Quality("Meilleure qualité", QualityOption("", null, false, "bv*[ext=mp4]+ba[ext=m4a]/bv*+ba/b")),
    heightOpt(1080), heightOpt(720), heightOpt(480), heightOpt(360),
    Quality("Audio MP3", QualityOption("MP3", null, false, "ba/b", mp3 = true)),
    Quality("Audio M4A", QualityOption("M4A", null, false, "ba[ext=m4a]/ba/b"))
)

private val Red = Color(0xFFE53950)
private val TABS = listOf("Tout", "YouTube", "Liste de lecture", "Instagram", "Facebook", "Image", "Google")
private val DURATIONS = listOf("Toutes durées", "Moins de 4 min", "4 – 20 min", "Plus de 20 min")

private fun durOk(f: Int, s: Long) = s <= 0 || when (f) { 1 -> s < 240; 2 -> s in 240..1200; 3 -> s > 1200; else -> true }

/**
 * Onglet « Vidéos » rendu comme VidMate : barre de recherche + onglets (Tout / YouTube / Liste de lecture / Instagram / Facebook / Image / Google),
 * grandes cartes avec miniature + durée + bouton ⬇, playlists → écran « Sélectionné » (cases, Tout sélectionner, n/N, FAIT).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoHubScreen(manager: BrowserManager, goBrowser: () -> Unit, goDownloads: () -> Unit) {
    val ctx = LocalContext.current
    val app = appInstance()
    val scope = rememberCoroutineScope()

    var query by rememberSaveable { mutableStateOf("") }
    var tabIdx by rememberSaveable { mutableIntStateOf(0) }
    var durFilter by rememberSaveable { mutableIntStateOf(0) }
    var sortDur by rememberSaveable { mutableStateOf(false) }
    var videosRes by remember { mutableStateOf<List<VideoEntry>>(emptyList()) }
    var listsRes by remember { mutableStateOf<List<VideoEntry>>(emptyList()) }
    var homeRes by remember { mutableStateOf<List<VideoEntry>>(emptyList()) }     // vidéos de l'accueil YouTube (sans recherche)
    var homeLoading by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var loadingLists by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var wanted by remember { mutableIntStateOf(50) }
    var lastQuery by remember { mutableStateOf<String?>(null) }
    var openTitle by remember { mutableStateOf<String?>(null) }          // non nul : écran « Sélectionné »
    var openItems by remember { mutableStateOf<List<VideoEntry>>(emptyList()) }
    var openLoading by remember { mutableStateOf(false) }
    var qualityFor by remember { mutableStateOf<Pair<List<VideoEntry>, String?>?>(null) }
    var durMenu by remember { mutableStateOf(false) }
    var sortMenu by remember { mutableStateOf(false) }
    val queue = remember { mutableStateListOf<VideoEntry>() }          // file « téléchargement en lot »

    // Accueil YouTube : dès l'ouverture du filtre « YouTube », on affiche des vidéos sans qu'il faille chercher
    fun loadHome(force: Boolean = false) {
        if (homeLoading) return
        homeLoading = true; if (force) error = null
        scope.launch {
            runCatching { MediaResolver.homeEntries(app, force) }
                .onSuccess { homeRes = it }
                .onFailure { if (homeRes.isEmpty()) error = (it.message ?: "Impossible de charger les vidéos").take(240) }
            homeLoading = false
        }
    }
    LaunchedEffect(tabIdx) { if (tabIdx == 1 && homeRes.isEmpty()) loadHome() }

    fun toggleQueue(e: VideoEntry) { val i = queue.indexOfFirst { it.url == e.url }; if (i >= 0) queue.removeAt(i) else queue.add(e) }

    BackHandler(openTitle != null) { openTitle = null; openItems = emptyList() }

    val showHome = tabIdx == 1 && lastQuery == null && videosRes.isEmpty()
    val source = if (showHome) homeRes else videosRes

    fun enc(q: String) = android.net.Uri.encode(q)
    fun web(url: String) { manager.newTab(url); goBrowser() }

    fun openList(e: VideoEntry) {
        openTitle = e.title; openItems = emptyList(); openLoading = true; error = null
        scope.launch {
            runCatching { MediaResolver.listEntries(app, e.url, 0) }
                .onSuccess { r -> openItems = r.entries.filter { !it.isList }; if (r.title.isNotBlank()) openTitle = r.title }
                .onFailure { error = (it.message ?: "Impossible de charger la liste").take(240); openTitle = null }
            openLoading = false
        }
    }

    fun runSearch(q: String, more: Boolean = false) {
        lastQuery = q; error = null
        wanted = if (more) (wanted + 50).coerceAtMost(300) else 50
        loading = true
        scope.launch {
            runCatching { MediaResolver.listEntries(app, "ytsearch:$q", wanted) }
                .onSuccess { videosRes = it.entries.filter { e -> !e.isList }; if (it.entries.isEmpty()) error = "Aucun résultat." }
                .onFailure { error = (it.message ?: "Recherche impossible").take(240) }
            loading = false
        }
        if (!more) {
            loadingLists = true
            scope.launch {
                runCatching { MediaResolver.listEntries(app, MediaResolver.searchUrl(q, true), 30) }
                    .onSuccess { listsRes = it.entries.filter { e -> e.isList } }
                    .onFailure { listsRes = emptyList() }
                loadingLists = false
            }
        }
    }

    fun search() {
        val q = query.trim()
        if (q.isEmpty()) return
        when {
            tabIdx == 3 -> web("https://www.google.com/search?q=" + enc("site:instagram.com $q"))
            tabIdx == 4 -> web("https://www.google.com/search?q=" + enc("site:facebook.com $q"))
            tabIdx == 5 -> web("https://www.google.com/search?tbm=isch&q=" + enc(q))
            tabIdx == 6 -> web("https://www.google.com/search?q=" + enc(q))
            else -> if (q.startsWith("http")) {
                loading = true; error = null; lastQuery = null
                scope.launch {
                    runCatching { MediaResolver.listEntries(app, q, 0) }
                        .onSuccess { r ->
                            if (r.entries.size > 1) { openTitle = r.title.ifBlank { "Liste" }; openItems = r.entries.filter { !it.isList } }
                            else { videosRes = r.entries; listsRes = emptyList() }
                        }
                        .onFailure { error = (it.message ?: "Lien non reconnu").take(240) }
                    loading = false
                }
            } else runSearch(q)
        }
    }

    // Lecture dans le lecteur intégré : on récupère l'adresse du flux avec yt-dlp, sans rien télécharger
    var playingUrl by remember { mutableStateOf<String?>(null) }
    fun play(e: VideoEntry) {
        if (playingUrl != null) return
        playingUrl = e.url
        Toast.makeText(ctx, "Chargement de la vidéo…", Toast.LENGTH_SHORT).show()
        scope.launch {
            runCatching { MediaResolver.streamUrl(app, e.url) }
                .onSuccess { Viewer.open(listOf(ViewItem(android.net.Uri.parse(it), e.title, "video/mp4"))) }
                .onFailure { Toast.makeText(ctx, "Lecture impossible : " + (it.message ?: "erreur").take(120), Toast.LENGTH_LONG).show() }
            playingUrl = null
        }
    }

    fun download(items: List<VideoEntry>, folder: String?, q: Quality) {
        scope.launch {
            val sub = folder?.takeIf { it.isNotBlank() }?.let { cleanName(it) }
            queue.removeAll { qe -> items.any { it.url == qe.url } }
            val ids = items.map { e -> app.downloadEngine.enqueueYt(e.url, e.title, q.opt, null, null, sub, e.durationSec) }
            if (ids.size == 1) DownloadService.start(ctx, ids[0]) else DownloadService.startMany(ctx, ids)
            Toast.makeText(ctx, "${ids.size} téléchargement(s) ajouté(s)", Toast.LENGTH_SHORT).show()
        }
    }

    // ───────── Écran « Sélectionné » (playlist)
    if (openTitle != null) {
        SelectionScreen(openTitle!!, openItems, openLoading, error,
            onBack = { openTitle = null; openItems = emptyList() },
            onPlay = { play(it) },
            onDone = { picked -> qualityFor = picked to openTitle })
    } else Column(Modifier.fillMaxSize()) {
        // ── Barre de recherche
        Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(goBrowser, contentPadding = PaddingValues(horizontal = 8.dp)) { Text("‹", color = Txt, fontSize = 26.sp) }
            OutlinedTextField(
                query, { query = it }, Modifier.weight(1f), singleLine = true, shape = RoundedCornerShape(24.dp),
                placeholder = { Text("Rechercher ou coller un lien") },
                trailingIcon = { if (query.isNotEmpty()) TextButton({ query = "" }) { Text("✕", color = Muted) } },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { search() })
            )
            TextButton(goDownloads, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("⬇", color = Txt, fontSize = 22.sp) }
        }
        // ── Onglets
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp)) {
            TABS.forEachIndexed { i, t ->
                Column(
                    Modifier.clickable {
                        tabIdx = i
                        val q = query.trim()
                        if ((i == 0 || i == 1 || i == 2) && q.isNotEmpty() && !q.startsWith("http") && lastQuery != q) runSearch(q)
                    }.padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(t, color = if (i == tabIdx) Txt else Muted, fontSize = 13.sp, fontWeight = if (i == tabIdx) FontWeight.Bold else FontWeight.Normal)
                    Box(Modifier.padding(top = 4.dp).height(2.dp).width(if (i == tabIdx) 24.dp else 0.dp).background(Red))
                }
            }
        }
        HorizontalDivider()
        if (loading || homeLoading && showHome || playingUrl != null || loadingLists && tabIdx == 2) LinearProgressIndicator(Modifier.fillMaxWidth().height(2.dp), color = Red)
        error?.let { Text(it, color = Danger, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp)) }

        // ── Puces de filtre (onglet Tout)
        if ((tabIdx == 0 || tabIdx == 1) && source.isNotEmpty()) Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box {
                FilterChip(durFilter != 0, { durMenu = true }, label = { Text(DURATIONS[durFilter] + " ▾") }, shape = RoundedCornerShape(16.dp))
                DropdownMenu(durMenu, { durMenu = false }) { DURATIONS.forEachIndexed { i, d -> DropdownMenuItem({ Text(d) }, { durFilter = i; durMenu = false }) } }
            }
            Box {
                FilterChip(true, { sortMenu = true }, label = { Text(if (sortDur) "Durée ▾" else "Pertinence ▾") }, shape = RoundedCornerShape(16.dp))
                DropdownMenu(sortMenu, { sortMenu = false }) {
                    DropdownMenuItem({ Text("Pertinence") }, { sortDur = false; sortMenu = false })
                    DropdownMenuItem({ Text("Durée (la plus longue d'abord)") }, { sortDur = true; sortMenu = false })
                }
            }
        }

        // ── Contenu
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (tabIdx) {
                0, 1 -> {
                    val vids = source.filter { durOk(durFilter, it.durationSec) }.let { if (sortDur) it.sortedByDescending { v -> v.durationSec } else it }
                    val cards: List<VideoEntry> = (if (tabIdx == 0) listsRes.take(2) + vids else vids).distinctBy { it.id + "|" + it.url }
                    if (cards.isEmpty() && !loading && !homeLoading && error == null) Centered("Recherchez une vidéo ou collez le lien d'une vidéo, d'une playlist ou d'une chaîne.")
                    // lecture quasi instantanée : on prépare à l'avance le flux des premières vidéos affichées
                    LaunchedEffect(cards.take(4).map { it.url }) { cards.take(4).filter { !it.isList }.forEach { MediaResolver.prefetchStream(app, it.url) } }
                    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        items(cards, key = { it.id + "|" + it.url }) { e ->
                            VideoCard(e, inQueue = queue.any { it.url == e.url },
                                onOpen = { if (e.isList) openList(e) else play(e) },
                                onQueue = { toggleQueue(e) },
                                onDownload = { if (e.isList) openList(e) else qualityFor = listOf(e) to null })
                        }
                        if (lastQuery != null && videosRes.isNotEmpty() && wanted < 300 && videosRes.size >= wanted - 5) item {
                            TextButton({ lastQuery?.let { runSearch(it, true) } }, enabled = !loading, modifier = Modifier.fillMaxWidth()) { Text("Plus de résultats") }
                        }
                        if (showHome && homeRes.isNotEmpty()) item {
                            TextButton({ loadHome(true) }, enabled = !homeLoading, modifier = Modifier.fillMaxWidth()) { Text("Actualiser") }
                        }
                        item { Spacer(Modifier.height(8.dp)) }
                    }
                }
                2 -> {
                    if (listsRes.isEmpty() && !loadingLists) Centered("Aucune liste de lecture. Lancez une recherche.")
                    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(listsRes.distinctBy { it.id + "|" + it.url }, key = { it.id + "|" + it.url }) { e ->
                            Row(Modifier.fillMaxWidth().clickable { openList(e) }, verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.width(104.dp).height(64.dp).clip(RoundedCornerShape(10.dp))) {
                                    RemoteImage(e.thumb, Modifier.fillMaxSize())
                                    Text("☰ " + (e.count?.toString() ?: ""), color = Color.White, fontSize = 11.sp,
                                        modifier = Modifier.align(Alignment.BottomEnd).background(Color(0xAA000000), RoundedCornerShape(topStart = 6.dp)).padding(horizontal = 6.dp, vertical = 2.dp))
                                }
                                Text(e.title, color = Txt, fontSize = 13.sp, maxLines = 3, overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f).padding(horizontal = 12.dp))
                                TextButton({ openList(e) }, contentPadding = PaddingValues(horizontal = 8.dp)) { Text("⬇", color = Muted, fontSize = 20.sp) }
                            }
                        }
                    }
                }
                else -> Centered("Appuyez sur la touche de recherche du clavier : " + TABS[tabIdx] +
                    " s'ouvre dans le navigateur, où la vidéo est captée dès sa lecture.")
            }
        }
        // ── Barre « file d'attente » (téléchargement en lot)
        if (queue.isNotEmpty()) {
            HorizontalDivider()
            Row(Modifier.fillMaxWidth().background(Surface1).padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                QueueIcon(false, Red)
                Text("${queue.size} en attente", color = Txt, fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 8.dp).weight(1f))
                TextButton({ queue.clear() }) { Text("Vider", color = Muted) }
                Button({ qualityFor = queue.toList() to null },
                    colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White), shape = RoundedCornerShape(4.dp)) { Text("TÉLÉCHARGER") }
            }
        }
    }

    // ───────── Choix de la qualité
    qualityFor?.let { (items, folder) ->
        ModalBottomSheet({ qualityFor = null }, containerColor = Bg) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                Text(if (items.size == 1) items[0].title else "${items.size} vidéos", color = Txt, fontSize = 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text("Choisissez la qualité", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp))
                QUALITIES.forEach { q ->
                    Row(Modifier.fillMaxWidth().clickable { qualityFor = null; download(items, folder, q) }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(q.label, color = Txt, modifier = Modifier.weight(1f))
                        Text("⬇", color = Red, fontSize = 18.sp)
                    }
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

/** Grande carte : miniature 16:9, durée, ▶ ; ligne d'infos + bouton ⬇ (liste de lecture : pile + « N Vidéos »). */
@Composable
private fun VideoCard(e: VideoEntry, inQueue: Boolean, onOpen: () -> Unit, onQueue: () -> Unit, onDownload: () -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        if (e.isList) Box(Modifier.padding(horizontal = 14.dp).fillMaxWidth().height(6.dp).clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp)).background(Surface2))
        Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(14.dp)).clickable(onClick = onOpen)) {
            RemoteImage(e.thumb, Modifier.fillMaxSize())
            if (!e.isList) Box(Modifier.align(Alignment.Center).size(46.dp).background(Color(0x88000000), CircleShape), contentAlignment = Alignment.Center) {
                Text("▶", color = Color.White, fontSize = 18.sp)
            }
            val badge = if (e.isList) "☰ " + (e.count?.let { "$it Vidéos" } ?: "Liste") else if (e.durationSec > 0) formatDuration(e.durationSec) else null
            badge?.let {
                Text(it, color = Color.White, fontSize = 11.sp,
                    modifier = Modifier.align(Alignment.BottomEnd).padding(8.dp).background(Color(0xAA000000), RoundedCornerShape(5.dp)).padding(horizontal = 6.dp, vertical = 2.dp))
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.Top) {
            Box(Modifier.size(34.dp).clip(CircleShape).background(Surface2), contentAlignment = Alignment.Center) {
                Text((e.channel ?: e.title).take(1).uppercase(), color = Txt, fontWeight = FontWeight.Bold)
            }
            Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                Text(e.title, color = Txt, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(e.channel ?: if (e.isList) "Liste de lecture" else "", color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (!e.isList) IconButton(onQueue, Modifier.size(40.dp)) { QueueIcon(inQueue, if (inQueue) Red else Muted) }
            IconButton(onDownload, Modifier.size(40.dp)) { DownloadIcon(Muted) }
        }
    }
}

/** Icône « ajouter à la liste » (lignes + plus) ; une fois ajoutée : lignes + coche. */
@Composable
private fun QueueIcon(added: Boolean, tint: Color, modifier: Modifier = Modifier.size(22.dp)) {
    Canvas(modifier) {
        val s = size.width / 24f
        fun l(x1: Float, y1: Float, x2: Float, y2: Float) = drawLine(tint, Offset(x1 * s, y1 * s), Offset(x2 * s, y2 * s), 2f * s, StrokeCap.Round)
        l(3f, 6f, 15f, 6f); l(3f, 12f, 15f, 12f); l(3f, 18f, 10f, 18f)
        if (!added) { l(18f, 14f, 18f, 22f); l(14f, 18f, 22f, 18f) } else { l(14f, 18f, 17f, 21f); l(17f, 21f, 22f, 14f) }
    }
}

/** Icône « télécharger » (flèche vers un plateau). */
@Composable
private fun DownloadIcon(tint: Color, modifier: Modifier = Modifier.size(22.dp)) {
    Canvas(modifier) {
        val s = size.width / 24f
        fun l(x1: Float, y1: Float, x2: Float, y2: Float) = drawLine(tint, Offset(x1 * s, y1 * s), Offset(x2 * s, y2 * s), 2f * s, StrokeCap.Round)
        l(12f, 3f, 12f, 16f); l(6f, 10f, 12f, 16f); l(18f, 10f, 12f, 16f); l(5f, 21f, 19f, 21f)
    }
}

/** Écran « Sélectionné » : toutes les vidéos de la liste cochées par défaut, « Tout Sélectionner », n/N, FAIT. */
@Composable
private fun SelectionScreen(title: String, items: List<VideoEntry>, loading: Boolean, error: String?,
                            onBack: () -> Unit, onPlay: (VideoEntry) -> Unit, onDone: (List<VideoEntry>) -> Unit) {
    val selected = remember { mutableStateMapOf<String, Boolean>() }
    var initFor by remember { mutableIntStateOf(-1) }
    if (items.isNotEmpty() && initFor != items.size) { items.forEach { selected[it.id] = true }; initFor = items.size }
    val count = items.count { selected[it.id] == true }
    val all = items.isNotEmpty() && count == items.size

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onBack, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("‹", color = Txt, fontSize = 26.sp) }
            Text("Sélectionné", color = Txt, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(title, color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f).padding(start = 10.dp))
        }
        HorizontalDivider()
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth().height(2.dp), color = Red)
        error?.let { Text(it, color = Danger, fontSize = 12.sp, modifier = Modifier.padding(14.dp)) }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(items.distinctBy { it.id + "|" + it.url }, key = { it.id + "|" + it.url }) { e ->
                val on = selected[e.id] == true
                Row(Modifier.fillMaxWidth().clickable { selected[e.id] = !on }, verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(24.dp).clip(CircleShape).background(if (on) Red else Surface2), contentAlignment = Alignment.Center) {
                        if (on) Text("✓", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(10.dp))
                    Box(Modifier.width(112.dp).height(64.dp).clip(RoundedCornerShape(8.dp)).clickable { onPlay(e) }) {
                        RemoteImage(e.thumb, Modifier.fillMaxSize())
                        Text("▶", color = Color.White, fontSize = 18.sp, modifier = Modifier.align(Alignment.Center))
                        if (e.durationSec > 0) Text(formatDuration(e.durationSec), color = Color.White, fontSize = 10.sp,
                            modifier = Modifier.align(Alignment.BottomEnd).padding(3.dp).background(Color(0xAA000000), RoundedCornerShape(4.dp)).padding(horizontal = 4.dp))
                    }
                    Text(e.title, color = Txt, fontSize = 13.sp, maxLines = 3, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f).padding(start = 12.dp))
                }
            }
        }
        HorizontalDivider()
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.clickable { items.forEach { selected[it.id] = !all } }, verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(24.dp).clip(CircleShape).background(if (all) Red else Surface2), contentAlignment = Alignment.Center) {
                    if (all) Text("✓", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }
                Text("Tout Sélectionner", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(start = 8.dp))
            }
            Spacer(Modifier.weight(1f))
            Text("$count/${items.size}", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(end = 12.dp))
            Button({ onDone(items.filter { selected[it.id] == true }) }, enabled = count > 0,
                colors = ButtonDefaults.buttonColors(containerColor = Red, contentColor = Color.White), shape = RoundedCornerShape(4.dp)) { Text("FAIT") }
        }
    }
}
