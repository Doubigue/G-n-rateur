# MyDM — Navigateur & Gestionnaire de téléchargements (Kotlin / Compose)

Ouvrir le dossier dans **Android Studio (Ladybug+)**, laisser la synchro Gradle se faire (génère le wrapper), puis Run sur un appareil Android 10+ (API 29).

- `browser/` WebView + sniffer (shouldInterceptRequest + JS injecté)
- `downloader/` moteur multi-segments (Range) + Foreground Service
- `whatsapp/` statuts via Storage Access Framework
- `torrent/` jlibtorrent (magnet / .torrent, sélection de fichiers, stats temps réel)
- `ui/` thème sombre « glass » + écrans Compose

Limites connues : HLS (.m3u8) détecté mais pas téléchargé ; pas de DRM ; vérifier les signatures jlibtorrent selon la version.

## Téléchargeur (pastille ⬇)
- Détection par extension, balises vidéo/audio **et Content-Type** (fichiers sans extension).
- Pastille « ⬇ » sur le navigateur : liste des médias, taille au clic, bouton Télécharger.
- Liens YouTube / Facebook / TikTok / HLS (m3u8) : analyse par yt-dlp (qualités + tailles), MP4 / M4A / MP3.
- Statuts WhatsApp : tous les dossiers `.Statuses` sont fusionnés et triés du plus récent au plus ancien.

## Onglets & paramètres
- Onglets : bouton compteur dans la barre d'adresse → grille d'onglets (miniatures, fermer, nouvel onglet). Les liens `target=_blank` / `window.open` ouvrent un nouvel onglet. Chaque onglet a sa propre liste de médias détectés.
- Paramètres (menu ⋮ du navigateur) : page d'accueil, moteur de recherche, mode ordinateur, blocage des pop-ups, restauration des onglets, nombre de connexions par téléchargement, effacement cookies/cache/médias.
