package com.example.mydm.ui

import android.view.ViewGroup
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.mydm.browser.BrowserManager
import com.example.mydm.core.Prefs

// ───────────── Navigateur (avec onglets) ─────────────
@Composable
fun BrowserScreen(manager: BrowserManager, onOpenSettings: () -> Unit) {
    val tab = manager.tabs.getOrNull(manager.currentIndex) ?: return
    var address by remember(tab.id) { mutableStateOf(tab.url) }
    LaunchedEffect(tab.id, tab.url) { address = tab.url }
    var showSheet by remember { mutableStateOf(false) }
    var showTabs by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }

    fun go() { tab.web.loadUrl(Prefs.resolveInput(address)) }

    // Retour : fermer le sélecteur → page précédente → fermer l'onglet (s'il y en a plusieurs)
    val canGoBack = remember(tab.id, tab.url) { tab.web.canGoBack() }
    BackHandler(enabled = showTabs || canGoBack || manager.tabs.size > 1) {
        when {
            showTabs -> showTabs = false
            tab.web.canGoBack() -> tab.web.goBack()
            else -> manager.close(manager.currentIndex)
        }
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                BarButton("◀") { if (tab.web.canGoBack()) tab.web.goBack() }
                OutlinedTextField(address, { address = it }, Modifier.weight(1f), singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = { go() }))
                BarButton(if (tab.progress in 0..99) "✕" else "⟳") {
                    if (tab.progress in 0..99) tab.web.stopLoading() else tab.web.reload()
                }
                // Compteur d'onglets
                Box(Modifier.size(40.dp).clickable { tab.captureThumb(); showTabs = true }, contentAlignment = Alignment.Center) {
                    Box(Modifier.size(24.dp).border(2.dp, Accent, RoundedCornerShape(6.dp)), contentAlignment = Alignment.Center) {
                        Text("${manager.tabs.size}", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Box {
                    BarButton("⋮") { menu = true }
                    DropdownMenu(menu, { menu = false }) {
                        DropdownMenuItem({ Text("Nouvel onglet") }, { menu = false; manager.newTab() })
                        DropdownMenuItem({ Text("Fermer l'onglet") }, { menu = false; manager.close(manager.currentIndex) })
                        DropdownMenuItem({ Text("Page suivante") }, { menu = false; if (tab.web.canGoForward()) tab.web.goForward() })
                        DropdownMenuItem({ Text("Paramètres") }, { menu = false; onOpenSettings() })
                    }
                }
            }
            if (tab.progress in 0..99) LinearProgressIndicator({ tab.progress / 100f }, Modifier.fillMaxWidth().height(2.dp))

            Box(Modifier.weight(1f)) {
                // key = id : chaque onglet réattache sa propre WebView
                key(tab.id) {
                    AndroidView({ (tab.web.parent as? ViewGroup)?.removeView(tab.web); tab.web }, Modifier.fillMaxSize())
                }
                // Pastille « téléchargeur » (médias de l'onglet courant)
                Row(
                    Modifier.align(Alignment.BottomEnd).padding(16.dp)
                        .clip(RoundedCornerShape(50)).background(Accent)
                        .clickable { showSheet = true }
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("⬇", color = Bg, fontSize = 16.sp)
                    Spacer(Modifier.width(8.dp))
                    Text(if (tab.found.isEmpty()) "Télécharger" else "${tab.found.size} média(s)", color = Bg, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
        if (showTabs) TabSwitcher(manager) { showTabs = false }
    }
    if (showSheet) DownloadSheet(tab.found, tab.web.url ?: address) { showSheet = false }
}

@Composable
private fun BarButton(label: String, onClick: () -> Unit) =
    Box(Modifier.size(40.dp).clip(RoundedCornerShape(50)).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(label, color = Accent, fontSize = 18.sp)
    }

// ───────────── Sélecteur d'onglets ─────────────
@Composable
private fun TabSwitcher(manager: BrowserManager, onClose: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 12.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Onglets (${manager.tabs.size})", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton({ manager.newTab(); onClose() }) { Text("＋ Nouvel onglet") }
            TextButton(onClose) { Text("OK") }
        }
        LazyVerticalGrid(GridCells.Fixed(2), contentPadding = PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            itemsIndexed(manager.tabs, key = { _, t -> t.id }) { i, t ->
                val selected = i == manager.currentIndex
                Column(
                    Modifier.fillMaxWidth().glass()
                        .border(if (selected) 2.dp else 0.dp, if (selected) Accent else Color.Transparent, RoundedCornerShape(20.dp))
                        .clickable { manager.select(i); onClose() }
                ) {
                    Row(Modifier.padding(start = 12.dp, top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(t.title.ifBlank { t.url }, color = Color.White, fontSize = 12.sp, maxLines = 1,
                            overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        Box(Modifier.size(36.dp).clickable { manager.close(i) }, contentAlignment = Alignment.Center) {
                            Text("✕", color = Muted, fontSize = 14.sp)
                        }
                    }
                    Box(Modifier.fillMaxWidth().height(130.dp).background(Color(0x22FFFFFF)), contentAlignment = Alignment.Center) {
                        val th = t.thumb
                        if (th != null) Image(th, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, alignment = Alignment.TopCenter)
                        else Text(t.url.substringAfter("://").substringBefore('/').ifBlank { "Nouvel onglet" },
                            color = Muted, fontSize = 12.sp, modifier = Modifier.padding(8.dp), maxLines = 2)
                    }
                }
            }
        }
    }
}
