package com.example.mydm.browser

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.view.ViewGroup
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.example.mydm.core.DetectedMedia
import com.example.mydm.core.Prefs
import kotlinx.coroutines.Job
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** Un onglet = une WebView + ses médias détectés + son état d'affichage. */
class BrowserTab(context: Context, val id: Int, var pendingUrl: String? = null) {
    val web = SnifferWebView(context)
    val found = mutableStateListOf<DetectedMedia>()
    var title by mutableStateOf("Nouvel onglet")
    var url by mutableStateOf(pendingUrl ?: "")
    var progress by mutableIntStateOf(100)
    var thumb by mutableStateOf<ImageBitmap?>(null)
    var job: Job? = null

    fun activate() {
        web.onResume()
        pendingUrl?.let { web.loadUrl(it); pendingUrl = null }
    }

    /** Miniature affichée dans le sélecteur d'onglets. */
    fun captureThumb() {
        if (web.width <= 0 || web.height <= 0 || pendingUrl != null) return
        runCatching {
            val s = 0.35f
            val bmp = Bitmap.createBitmap((web.width * s).toInt(), (web.height * s).toInt(), Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            c.scale(s, s)
            c.translate(-web.scrollX.toFloat(), -web.scrollY.toFloat())
            web.draw(c)
            thumb = bmp.asImageBitmap()
        }
    }

    fun dispose() {
        job?.cancel()
        (web.parent as? ViewGroup)?.removeView(web)
        web.post { web.destroy() }
    }
}

/** Possède tous les onglets ; vit dans MainActivity pour survivre au changement d'écran. */
class BrowserManager(private val ctx: Context) {
    val tabs = mutableStateListOf<BrowserTab>()
    var currentIndex by mutableIntStateOf(0); private set
    val current: BrowserTab get() = tabs[currentIndex]

    private val scope = MainScope()
    private var counter = 0
    private var restoring = false

    init {
        val saved = if (Prefs.restoreTabs) Prefs.savedTabs() else emptyList()
        if (saved.isEmpty()) newTab()
        else {
            restoring = true
            saved.forEach { addTab(BrowserTab(ctx, ++counter, it).also { t -> t.title = it.substringAfter("://").substringBefore('/') }) }
            restoring = false
            select(Prefs.savedTabIndex().coerceIn(tabs.indices))
        }
    }

    private fun addTab(t: BrowserTab): BrowserTab {
        t.web.onUrlChanged = { t.url = it; persist() }
        t.web.onTitleChanged = { t.title = it }
        t.web.onProgress = { t.progress = it }
        t.web.windowRequested = { newTab(blank = true).web }
        t.web.closeRequested = { close(tabs.indexOf(t)) }
        t.job = scope.launch { t.web.detectedMedia.collect { t.found.add(0, it) } }
        tabs.add(t)
        return t
    }

    /** blank = true : la page ouvrante charge elle-même le contenu (window.open / target=_blank). */
    fun newTab(url: String? = null, blank: Boolean = false): BrowserTab {
        val t = addTab(BrowserTab(ctx, ++counter))
        select(tabs.lastIndex)
        if (!blank) t.web.loadUrl(url ?: Prefs.homeUrl)
        return t
    }

    fun select(i: Int) {
        if (tabs.isEmpty()) return
        if (currentIndex in tabs.indices) tabs[currentIndex].captureThumb()
        currentIndex = i.coerceIn(tabs.indices)
        tabs.forEachIndexed { idx, t -> if (idx == currentIndex) t.activate() else t.web.onPause() }
        persist()
    }

    fun close(i: Int) {
        if (i !in tabs.indices) return
        val t = tabs.removeAt(i)
        t.dispose()
        if (tabs.isEmpty()) { newTab(); return }
        currentIndex = when {
            i < currentIndex -> currentIndex - 1
            i == currentIndex -> minOf(i, tabs.lastIndex)
            else -> currentIndex
        }
        tabs[currentIndex].activate()
        persist()
    }

    /** Réapplique les réglages à tous les onglets ; recharge ceux dont le User-Agent a changé. */
    fun applyPrefsToAll() = tabs.forEach { t ->
        if (t.web.applyPrefs() && t.pendingUrl == null && t.url.isNotBlank()) t.web.reload()
    }

    fun clearCacheAndHistory() = tabs.forEach { it.web.clearCache(true); it.web.clearHistory() }
    fun clearDetected() = tabs.forEach { it.found.clear() }

    private fun persist() {
        if (restoring || tabs.isEmpty()) return
        Prefs.saveTabs(tabs.map { it.pendingUrl ?: it.url.ifBlank { Prefs.homeUrl } }, currentIndex)
    }

    fun destroy() {
        scope.cancel()
        tabs.forEach { it.dispose() }
        tabs.clear()
    }
}
