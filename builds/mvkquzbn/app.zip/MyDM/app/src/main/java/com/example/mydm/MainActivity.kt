package com.example.mydm

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.activity.compose.BackHandler
import com.example.mydm.browser.BrowserManager
import com.example.mydm.core.Prefs
import com.example.mydm.ui.*
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MyDMTheme { Root() } }
    }
}

private val tabs = listOf("\uD83C\uDF10" to "Navigateur", "\u2B07\uFE0F" to "Téléchargements", "\uD83D\uDCAC" to "Statuts", "\uD83E\uDDF2" to "Torrent")

@Composable
private fun Root() {
    val ctx = LocalContext.current
    var tab by rememberSaveable { mutableIntStateOf(0) }

    // Les onglets (WebViews + médias détectés) vivent ici : ils survivent au changement d'écran
    val manager = remember { BrowserManager(ctx) }
    DisposableEffect(manager) { onDispose { manager.destroy() } }
    var showSettings by rememberSaveable { mutableStateOf(false) }
    BackHandler(showSettings) { showSettings = false }
    // Mode ordinateur : réapplique les réglages à tous les onglets
    LaunchedEffect(Prefs.desktopMode) { manager.applyPrefsToAll() }

    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) notif.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    // Affiche l'erreur du dernier plantage, s'il y en a eu un
    val crashFile = remember { File(ctx.filesDir, "crash.txt") }
    var crash by remember { mutableStateOf(runCatching { if (crashFile.exists()) crashFile.readText() else null }.getOrNull()) }
    crash?.let { log ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text("Dernier plantage") },
            text = {
                Box(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())) {
                    SelectionContainer { Text(log.take(4000), fontSize = 10.sp) }
                }
            },
            confirmButton = { TextButton({ crashFile.delete(); crash = null }) { Text("Fermer") } }
        )
    }

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Bg) {
                tabs.forEachIndexed { i, (icon, label) ->
                    NavigationBarItem(tab == i && !showSettings, { tab = i; showSettings = false }, icon = { Text(icon) }, label = { Text(label) })
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (showSettings) SettingsScreen(manager) { showSettings = false }
            else when (tab) {
                0 -> BrowserScreen(manager) { showSettings = true }
                1 -> DownloadsScreen()
                2 -> StatusScreen()
                3 -> TorrentScreen()
            }
        }
    }
}
