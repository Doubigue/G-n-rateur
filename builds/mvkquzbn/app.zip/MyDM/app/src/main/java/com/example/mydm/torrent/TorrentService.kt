package com.example.mydm.torrent

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.mydm.App
import kotlinx.coroutines.*

class TorrentService : Service() {
    private val engine get() = (application as App).torrentEngine
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onBind(i: Intent?) = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Torrents", NotificationManager.IMPORTANCE_LOW))
        startForeground(NOTIF_ID, notif("Torrent en cours…"), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        runCatching { engine.start() }
        scope.launch {
            delay(5000)
            while (isActive) {
                val s = engine.states.value.values
                if (s.isEmpty()) { stopSelf(); break }
                nm.notify(NOTIF_ID, notif("${s.size} torrent(s) • ↓ ${s.sumOf { it.downloadRate } / 1024} Ko/s ↑ ${s.sumOf { it.uploadRate } / 1024} Ko/s"))
                delay(1000)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_NOT_STICKY
    override fun onDestroy() { scope.cancel() }

    private fun notif(text: String) = NotificationCompat.Builder(this, CH)
        .setSmallIcon(android.R.drawable.stat_sys_download).setContentTitle("MyDM Torrent")
        .setContentText(text).setOngoing(true).build()

    companion object {
        const val CH = "torrents"; const val NOTIF_ID = 43
        fun start(ctx: Context) = ContextCompat.startForegroundService(ctx, Intent(ctx, TorrentService::class.java))
    }
}
