package com.dlvibestudio.dlturbo.ui

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.lifecycleScope
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import com.dlvibestudio.dlturbo.App
import com.dlvibestudio.dlturbo.data.SettingsData
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.coroutines.coroutineContext
import java.io.ByteArrayInputStream
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Télécharge une liste d'épisodes (1 → N) sur les sites de streaming : chaque page d'épisode est ouverte
 * à tour de rôle dans un navigateur invisible, la lecture est lancée en sourdine, le flux vidéo qui passe
 * (HLS, DASH, mp4) est repéré puis mis dans la file de téléchargement.
 */
class EpisodeCrawler(
    private val activity: ComponentActivity,
    private val app: App,
    private val blocker: AdBlocker,
) {
    data class State(
        val total: Int,
        val done: Int,
        val added: Int,
        val failed: List<String>,
        val current: String,
        val running: Boolean,
    )

    val state = mutableStateOf<State?>(null)

    private var webView: WebView? = null
    private var container: FrameLayout? = null
    private var job: Job? = null
    private val found = CopyOnWriteArrayList<MediaHit>()

    @Volatile
    private var currentPage = ""

    fun start(prefix: String, items: List<EpisodeItem>, quality: String) {
        if (items.isEmpty()) return
        cancel()
        state.value = State(items.size, 0, 0, emptyList(), items.first().title, true)
        job = activity.lifecycleScope.launch {
            try {
                ensureWebView()
                var added = 0
                val failed = ArrayList<String>()
                items.forEachIndexed { index, episode ->
                    state.value = State(items.size, index, added, failed.toList(), episode.title, true)
                    val hit = findStream(episode.url)
                    if (hit != null) {
                        val cookie = CookieManager.getInstance().getCookie(hit.url) ?: ""
                        val title = listOf(prefix, episode.title).filter { it.isNotBlank() }.joinToString(" - ")
                        app.manager.enqueueStream(hit.url, hit.referer, cookie, title, quality)
                        added++
                    } else {
                        failed.add(episode.title)
                    }
                    delay(400)
                }
                state.value = State(items.size, items.size, added, failed, "", false)
            } finally {
                // Seule la tâche en cours nettoie ; une tâche annulée a déjà été nettoyée par cancel().
                if (job === coroutineContext[Job]) teardown()
            }
        }
    }

    fun cancel() {
        job?.cancel()
        job = null
        teardown()
        state.value = null
    }

    fun dismiss() {
        if (state.value?.running != true) state.value = null
    }

    private suspend fun findStream(url: String): MediaHit? {
        val w = webView ?: return null
        found.clear()
        currentPage = url
        w.loadUrl(url)
        val start = System.currentTimeMillis()
        var firstAt = 0L
        while (System.currentTimeMillis() - start < TIMEOUT_MS) {
            delay(300)
            if (found.isNotEmpty()) {
                if (firstAt == 0L) firstAt = System.currentTimeMillis()
                // On laisse un instant pour voir passer la liste principale (HLS maître) après un éventuel premier flux.
                if (System.currentTimeMillis() - firstAt > SETTLE_MS) break
            }
        }
        w.stopLoading()
        val hit = MediaSniffer.pick(found.toList())
        w.loadUrl("about:blank")
        return hit
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun ensureWebView() {
        if (webView != null) return
        val wv = WebView(activity)
        with(wv.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            setSupportMultipleWindows(false)
            javaScriptCanOpenWindowsAutomatically = false
            allowFileAccess = false
            allowContentAccess = false
            userAgentString = SettingsData.DEFAULT_UA
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
        wv.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val uri = request.url
                val pageHost = runCatching { Uri.parse(currentPage).host }.getOrNull()
                if (app.settings.value.blockAds && blocker.shouldBlock(uri, pageHost)) {
                    return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                }
                val kind = MediaSniffer.classify(uri)
                val u = uri.toString()
                if (kind != null && !MediaSniffer.noisy(u)) {
                    val referer = request.requestHeaders?.get("Referer")?.takeIf { it.isNotBlank() } ?: currentPage
                    found.add(MediaHit(u, kind, referer))
                }
                return null
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (!request.isForMainFrame) return false
                if (request.isRedirect) return false
                val to = request.url.host
                val from = runCatching { Uri.parse(currentPage).host }.getOrNull()
                // La page d'épisode reste sur son site ; tout saut vers ailleurs (publicité) est ignoré.
                return !(to != null && from != null && site(to) == site(from))
            }

            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                    view.evaluateJavascript(MediaSniffer.AUTOPLAY_SCRIPT, null)
                }
            }
        }
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            runCatching { WebViewCompat.addDocumentStartJavaScript(wv, MediaSniffer.AUTOPLAY_SCRIPT, setOf("*")) }
        }

        // Presque invisible mais « affiché » : certains lecteurs ne démarrent pas hors de l'écran.
        // Le conteneur laisse passer les appuis vers l'application située dessous.
        val density = activity.resources.displayMetrics.density
        val frame = PassThroughFrame(activity)
        frame.alpha = 0.02f
        frame.addView(wv, FrameLayout.LayoutParams((320 * density).toInt(), (180 * density).toInt()))
        val decor = activity.window.decorView as FrameLayout
        decor.addView(
            frame,
            FrameLayout.LayoutParams((320 * density).toInt(), (180 * density).toInt(), Gravity.BOTTOM or Gravity.START),
        )
        webView = wv
        container = frame
    }

    private fun teardown() {
        runCatching {
            container?.let { (it.parent as? ViewGroup)?.removeView(it) }
            webView?.stopLoading()
            webView?.destroy()
        }
        webView = null
        container = null
    }

    private fun site(host: String): String {
        val parts = host.lowercase().split('.')
        return if (parts.size <= 2) host.lowercase() else parts.takeLast(2).joinToString(".")
    }

    private class PassThroughFrame(context: Context) : FrameLayout(context) {
        override fun dispatchTouchEvent(ev: MotionEvent?): Boolean = false
    }

    companion object {
        private const val TIMEOUT_MS = 28_000L
        private const val SETTLE_MS = 1_800L
    }
}
