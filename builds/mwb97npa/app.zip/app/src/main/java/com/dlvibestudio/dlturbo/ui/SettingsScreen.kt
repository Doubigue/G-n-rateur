@file:OptIn(ExperimentalMaterial3Api::class)

package com.dlvibestudio.dlturbo.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.widget.Toast
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.dlvibestudio.dlturbo.App
import com.dlvibestudio.dlturbo.data.SettingsData
import com.dlvibestudio.dlturbo.util.Format
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

private val SPEED_STEPS = listOf(
    0L, 256L * 1024, 512L * 1024, 1024L * 1024, 2L * 1024 * 1024,
    5L * 1024 * 1024, 10L * 1024 * 1024, 20L * 1024 * 1024,
)
private val UPLOAD_STEPS = listOf(
    0L, 20L * 1024, 50L * 1024, 100L * 1024, 250L * 1024, 500L * 1024, 1024L * 1024,
)
private val TORRENT_CONNECTIONS = listOf(50, 100, 200, 300, 500)

@Composable
fun SettingsScreen(app: App, onBack: () -> Unit) {
    val context = LocalContext.current
    val s by app.settings.data.collectAsState()
    val scope = rememberCoroutineScope()
    var updating by remember { mutableStateOf(false) }
    var updateMessage by remember { mutableStateOf<String?>(null) }
    var userAgent by remember { mutableStateOf(s.userAgent) }

    fun set(transform: (SettingsData) -> SettingsData) = app.settings.update(transform)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Paramètres", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                    }
                },
            )
        },
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
        ) {
            // ------------------------------------------------------ Vitesse
            Section("Vitesse et file d'attente")
            SliderRow(
                title = "Connexions par fichier",
                value = "${s.connections}",
                hint = "Plus il y en a, plus le téléchargement est rapide (si le serveur l'accepte).",
                position = s.connections.toFloat(), range = 1f..32f, steps = 30,
            ) { v -> set { it.copy(connections = v.roundToInt()) } }
            SliderRow(
                title = "Téléchargements simultanés",
                value = "${s.maxParallel}",
                position = s.maxParallel.toFloat(), range = 1f..10f, steps = 8,
            ) { v -> set { it.copy(maxParallel = v.roundToInt()) } }
            StepRow(
                title = "Limite de vitesse",
                steps = SPEED_STEPS, current = s.speedLimit,
                label = { if (it == 0L) "Illimitée" else Format.speed(it) },
            ) { v -> set { it.copy(speedLimit = v) } }
            SliderRow(
                title = "Nouvelles tentatives en cas d'erreur",
                value = "${s.retries}",
                position = s.retries.toFloat(), range = 0f..30f, steps = 29,
            ) { v -> set { it.copy(retries = v.roundToInt()) } }

            // ------------------------------------------------------ Réseau
            Section("Réseau et reprise")
            SwitchRow(
                "Wi-Fi uniquement",
                "Suspend les téléchargements sur les données mobiles et les reprend au retour du Wi-Fi.",
                s.wifiOnly,
            ) { v -> set { it.copy(wifiOnly = v) } }
            SwitchRow(
                "Reprise automatique",
                "Relance au prochain lancement ce qui a été interrompu par la fermeture de l'application.",
                s.autoResume,
            ) { v -> set { it.copy(autoResume = v) } }
            OutlinedTextField(
                value = userAgent,
                onValueChange = { v ->
                    userAgent = v
                    set { it.copy(userAgent = v) }
                },
                label = { Text("User-Agent (navigateur simulé)") },
                maxLines = 3,
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            )
            TextButton(onClick = {
                userAgent = SettingsData.DEFAULT_UA
                set { it.copy(userAgent = SettingsData.DEFAULT_UA) }
            }) { Text("Rétablir le User-Agent par défaut") }

            // ---------------------------------------------------- Fichiers
            Section("Fichiers")
            SwitchRow(
                "Ranger par catégorie",
                "Vidéos, Musique, Images, APK, Documents, Archives, Logiciels, Torrents.",
                s.sortByCategory,
            ) { v -> set { it.copy(sortByCategory = v) } }
            InfoRow("Dossier de téléchargement", app.manager.baseDir.path)

            // ------------------------------------------------------- Vidéo
            Section("Vidéos (YouTube, Instagram, TikTok, Facebook, Pinterest…)")
            ChipRow(
                title = "Qualité par défaut",
                options = QUALITY_OPTIONS, selected = s.videoQuality,
            ) { v -> set { it.copy(videoQuality = v) } }
            SwitchRow(
                "Préférer le format MP4",
                "Compatible avec tous les lecteurs. Désactivez pour obtenir la meilleure qualité brute (WebM/MKV).",
                s.preferMp4,
            ) { v -> set { it.copy(preferMp4 = v) } }
            SwitchRow(
                "Télécharger les playlists entières",
                "Sinon, seule la vidéo du lien est téléchargée.",
                s.wholePlaylist,
            ) { v -> set { it.copy(wholePlaylist = v) } }
            SliderRow(
                title = "Fragments simultanés",
                value = "${s.videoFragments}",
                hint = "Accélère les vidéos diffusées par morceaux (HLS/DASH).",
                position = s.videoFragments.toFloat(), range = 1f..16f, steps = 14,
            ) { v -> set { it.copy(videoFragments = v.roundToInt()) } }
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                OutlinedButton(
                    enabled = !updating,
                    onClick = {
                        updating = true
                        updateMessage = "Mise à jour en cours…"
                        scope.launch {
                            updateMessage = app.manager.videos.update()
                            updating = false
                        }
                    },
                ) { Text("Mettre à jour le moteur vidéo (yt-dlp)") }
            }
            Text(
                updateMessage ?: "À faire quand un site ne fonctionne plus : les sites changent souvent.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp),
            )

            // ----------------------------------------------------- Torrent
            Section("Torrents")
            StepRow(
                title = "Limite d'envoi (upload)",
                steps = UPLOAD_STEPS, current = s.torrentUploadLimit,
                label = { if (it == 0L) "Illimitée" else Format.speed(it) },
            ) { v -> set { it.copy(torrentUploadLimit = v) } }
            StepRow(
                title = "Connexions maximum",
                steps = TORRENT_CONNECTIONS.map { it.toLong() }, current = s.torrentMaxConnections.toLong(),
                label = { "$it" },
            ) { v -> set { it.copy(torrentMaxConnections = v.toInt()) } }
            SwitchRow(
                "Continuer à partager après la fin",
                "Le torrent reste actif (seed) tant que l'application tourne.",
                s.torrentSeed,
            ) { v -> set { it.copy(torrentSeed = v) } }

            // ----------------------------------------------- Notifications
            Section("Notifications")
            SwitchRow(
                "Son à la fin d'un téléchargement",
                null,
                s.soundOnComplete,
            ) { v -> set { it.copy(soundOnComplete = v) } }

            // ----------------------------------------------------- Système
            Section("Écran éteint et arrière-plan")
            val ignoring = remember(updating) { isIgnoringBattery(context) }
            Text(
                if (ignoring) "L'optimisation de batterie est déjà désactivée pour DL Turbo."
                else "Pour que rien ne s'arrête écran éteint, autorisez DL Turbo à ignorer l'optimisation de batterie.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Button(
                onClick = {
                    try {
                        context.startActivity(
                            Intent(
                                android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                                Uri.parse("package:" + context.packageName),
                            )
                        )
                    } catch (_: Exception) {
                        runCatching {
                            context.startActivity(
                                Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                            )
                        }.onFailure {
                            Toast.makeText(context, "Réglage indisponible sur ce téléphone", Toast.LENGTH_SHORT).show()
                        }
                    }
                },
                modifier = Modifier.padding(top = 8.dp),
            ) { Text("Désactiver l'optimisation de batterie") }

            // ------------------------------------------ Navigateur et blocage
            Section("Navigateur et blocage")
            SwitchRow(
                "Bloquer les publicités et les traqueurs",
                "Sur tous les sites visités, y compris YouTube (au mieux : YouTube change souvent).",
                s.blockAds,
            ) { v -> set { it.copy(blockAds = v) } }
            SwitchRow(
                "Bloquer les pop-ups",
                "Empêche l'ouverture de fenêtres non demandées.",
                s.blockPopups,
            ) { v -> set { it.copy(blockPopups = v) } }
            SwitchRow(
                "Bloquer les redirections",
                "Bloque les sauts automatiques vers un autre site sans action de votre part.",
                s.blockRedirects,
            ) { v -> set { it.copy(blockRedirects = v) } }
            ChipRow(
                title = "Moteur de recherche",
                options = listOf("google" to "Google", "duckduckgo" to "DuckDuckGo", "bing" to "Bing"),
                selected = s.searchEngine,
            ) { v -> set { it.copy(searchEngine = v) } }
            androidx.compose.material3.OutlinedButton(
                onClick = {
                    app.hub?.clearData()
                    Toast.makeText(context, "Données de navigation effacées", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.padding(top = 8.dp),
            ) { Text("Effacer les données de navigation") }

            ScheduleAndSecuritySection(app)

            // --------------------------------------------------- Apparence
            Section("Apparence")
            ChipRow(
                title = "Thème",
                options = listOf("dark" to "Sombre", "light" to "Clair", "system" to "Système"),
                selected = s.theme,
            ) { v -> set { it.copy(theme = v) } }

            Spacer(Modifier.height(24.dp))
            HorizontalDivider()
            Text(
                "DL Turbo 1.0.0 · DL VIBE STUDIO",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(vertical = 16.dp),
            )
        }
    }
}

private fun isIgnoringBattery(context: Context): Boolean {
    val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return false
    return pm.isIgnoringBatteryOptimizations(context.packageName)
}

@Composable
private fun Section(title: String) {
    Text(
        title,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(top = 24.dp, bottom = 8.dp),
    )
}

@Composable
private fun SwitchRow(title: String, hint: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (hint != null) {
                Text(
                    hint,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun SliderRow(
    title: String,
    value: String,
    position: Float,
    range: ClosedFloatingPointRange<Float>,
    steps: Int,
    hint: String? = null,
    onChange: (Float) -> Unit,
) {
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
            Text(
                value,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
            )
        }
        if (hint != null) {
            Text(
                hint,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Slider(value = position, onValueChange = onChange, valueRange = range, steps = steps)
    }
}

/** Curseur sur une liste de valeurs prédéfinies. */
@Composable
private fun StepRow(
    title: String,
    steps: List<Long>,
    current: Long,
    label: (Long) -> String,
    onChange: (Long) -> Unit,
) {
    val index = steps.indexOf(current).let { if (it < 0) 0 else it }
    SliderRow(
        title = title,
        value = label(steps[index]),
        position = index.toFloat(),
        range = 0f..(steps.size - 1).toFloat(),
        steps = (steps.size - 2).coerceAtLeast(0),
    ) { v -> onChange(steps[v.roundToInt().coerceIn(0, steps.size - 1)]) }
}

@Composable
private fun ChipRow(
    title: String,
    options: List<Pair<String, String>>,
    selected: String,
    onSelect: (String) -> Unit,
) {
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(title, style = MaterialTheme.typography.bodyLarge)
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            options.forEach { (key, text) ->
                FilterChip(selected = selected == key, onClick = { onSelect(key) }, label = { Text(text) })
            }
        }
    }
}

@Composable
private fun InfoRow(title: String, value: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Text(title, style = MaterialTheme.typography.bodyLarge)
        Text(
            value,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
