package com.dlvibestudio.dlturbo.ui

import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.net.Uri
import android.os.Message
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import androidx.webkit.ScriptHandler
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import com.dlvibestudio.dlturbo.App
import com.dlvibestudio.dlturbo.data.SettingsData
import com.dlvibestudio.dlturbo.engine.Links
import kotlinx.coroutines.launch
import java.io.ByteArrayInputStream
import java.net.URLEncoder

/** Un onglet : une WebView + l'état affiché par l'interface. */
class WebTab(val id: Int, val kind: Kind) {
    enum class Kind { BROWSER, YOUTUBE }

    lateinit var webView: WebView
    var title by mutableStateOf("")
    var url by mutableStateOf("")
    var progress by mutableIntStateOf(100)
    var canGoBack by mutableStateOf(false)
    var canGoForward by mutableStateOf(false)
    var desktop by mutableStateOf(false)

    /** Augmente quand la WebView est recréée (processus de rendu planté) : l'interface se rattache. */
    var generation by mutableIntStateOf(0)
    val handlers = ArrayList<ScriptHandler>()

    /** Flux vidéo/audio repérés dans le trafic de la page (y compris ses lecteurs intégrés). */
    val media = mutableStateListOf<MediaHit>()

    /** Un lecteur vidéo est visible dans la page (même à l'arrêt). */
    var hasVideo by mutableStateOf(false)

    /** Adresse du lecteur intégré (iframe) sur lequel l'utilisateur a appuyé. */
    var embed by mutableStateOf("")

    fun addMedia(hit: MediaHit) {
        if (media.any { it.url == hit.url }) return
        if (media.size >= 40) media.removeAt(0)
        media.add(hit)
    }

    fun resetMedia() {
        media.clear()
        hasVideo = false
        embed = ""
    }
}

/** Élément sous le doigt lors d'un appui long (image ou lien). */
data class HitInfo(val url: String, val isImage: Boolean)

/**
 * Gère toutes les WebViews de l'application : onglets du navigateur, page YouTube,
 * blocage des pubs / traqueurs / pop-ups, plein écran vidéo, téléchargements.
 * Les WebViews restent en vie quand on change d'onglet de l'application.
 */
class WebHub(private val activity: ComponentActivity, private val app: App) {

    val blocker = AdBlocker(activity)

    val tabs = mutableStateListOf<WebTab>()
    var currentIndex by mutableIntStateOf(0)
    var blocked by mutableIntStateOf(0)

    /** Lien pour lequel le sélecteur de formats doit s'ouvrir. */
    val formatRequest = mutableStateOf<String?>(null)
    val hit = mutableStateOf<HitInfo?>(null)
    val fullscreen = mutableStateOf(false)

    /** Demande de changement d'onglet de l'application (0 = Téléchargements … 3 = Fichiers). */
    val requestTab = mutableStateOf<Int?>(null)

    val yt = YtModel(app)

    /** Onglet pour lequel la liste des médias détectés est affichée. */
    val mediaSheet = mutableStateOf<WebTab?>(null)

    /** Épisodes trouvés dans la page, en attente de sélection. */
    val episodes = mutableStateOf<EpisodeList?>(null)

    /** Images trouvées dans la page, en attente de sélection. */
    val images = mutableStateOf<List<PageImage>?>(null)

    val crawler = EpisodeCrawler(activity, app, blocker)
    val bookmarks = Bookmarks(activity)

    private var nextId = 1
    private var youtubeTab: WebTab? = null
    private var customView: View? = null
    private var customCallback: WebChromeClient.CustomViewCallback? = null

    val youtube: WebTab
        get() = youtubeTab ?: createTab(WebTab.Kind.YOUTUBE).also { youtubeTab = it }

    /** Onglet affiché dans le navigateur (null tant qu'aucun n'a été créé). */
    val current: WebTab?
        get() = tabs.getOrNull(currentIndex.coerceIn(0, (tabs.size - 1).coerceAtLeast(0)))

    init {
        activity.lifecycleScope.launch {
            app.settings.data.collect { applyAll() }
        }
    }

    // ---------------------------------------------------------------- Onglets

    fun newBrowserTab(url: String? = null, select: Boolean = true): WebTab {
        if (tabs.size >= MAX_TABS) {
            val last = tabs.last()
            url?.let { load(last, it) }
            currentIndex = tabs.size - 1
            return last
        }
        val tab = createTab(WebTab.Kind.BROWSER)
        tabs.add(tab)
        if (select) currentIndex = tabs.size - 1
        if (!url.isNullOrBlank()) load(tab, url)
        return tab
    }

    fun closeTab(index: Int) {
        if (index !in tabs.indices) return
        val tab = tabs.removeAt(index)
        destroy(tab)
        if (tabs.isEmpty()) {
            newBrowserTab()
        } else {
            currentIndex = currentIndex.coerceIn(0, tabs.size - 1)
            if (index < currentIndex) currentIndex--
        }
    }

    fun load(tab: WebTab, input: String) {
        val target = resolve(input)
        if (target.isBlank()) return
        if (Links.isMagnet(target)) {
            app.manager.enqueue(target)
            toast("Torrent ajouté aux téléchargements")
            return
        }
        tab.webView.loadUrl(target)
    }

    /** Adresse saisie -> URL, ou recherche avec le moteur choisi. */
    fun resolve(input: String): String {
        val t = input.trim()
        if (t.isEmpty()) return ""
        if (Regex("^[a-zA-Z][a-zA-Z0-9+.-]*:").containsMatchIn(t) && !t.contains(' ')) return t
        if (!t.contains(' ') && t.contains('.') && !t.endsWith(".")) return "https://$t"
        val q = URLEncoder.encode(t, "UTF-8")
        return when (app.settings.value.searchEngine) {
            "duckduckgo" -> "https://duckduckgo.com/?q=$q"
            "bing" -> "https://www.bing.com/search?q=$q"
            else -> "https://www.google.com/search?q=$q"
        }
    }

    fun setDesktop(tab: WebTab, enabled: Boolean) {
        tab.desktop = enabled
        tab.webView.settings.userAgentString = if (enabled) DESKTOP_UA else SettingsData.DEFAULT_UA
        tab.webView.settings.useWideViewPort = true
        tab.webView.settings.loadWithOverviewMode = enabled
        tab.webView.reload()
    }

    // ---------------------------------------------------------- Création

    @SuppressLint("SetJavaScriptEnabled", "AddJavascriptInterface")
    private fun createTab(kind: WebTab.Kind): WebTab {
        val tab = WebTab(nextId++, kind)
        tab.webView = buildWebView(tab)
        return tab
    }

    @SuppressLint("SetJavaScriptEnabled", "AddJavascriptInterface")
    private fun buildWebView(tab: WebTab): WebView {
        val wv = WebView(activity)
        wv.setBackgroundColor(android.graphics.Color.parseColor("#0E0E12"))
        with(wv.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            setSupportMultipleWindows(true)
            javaScriptCanOpenWindowsAutomatically = false
            builtInZoomControls = true
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = false
            allowFileAccess = false
            allowContentAccess = false
            userAgentString = if (tab.desktop) DESKTOP_UA else SettingsData.DEFAULT_UA
        }
        CookieManager.getInstance().setAcceptCookie(true)
        wv.webViewClient = client(tab)
        wv.webChromeClient = chrome(tab)
        wv.setDownloadListener { url, _, disposition, mime, _ -> onDownload(tab, url, disposition, mime) }
        wv.setOnLongClickListener {
            val r = wv.hitTestResult
            val extra = r.extra
            when {
                extra == null -> false
                r.type == WebView.HitTestResult.IMAGE_TYPE ||
                    r.type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE -> {
                    hit.value = HitInfo(extra, true)
                    true
                }
                r.type == WebView.HitTestResult.SRC_ANCHOR_TYPE -> {
                    hit.value = HitInfo(extra, false)
                    true
                }
                else -> false
            }
        }
        if (tab.kind == WebTab.Kind.YOUTUBE) wv.addJavascriptInterface(YtBridge(), "DLT")
        else wv.addJavascriptInterface(MediaBridge(tab), "DLM")
        applyScripts(tab, wv)
        applyCookiePolicy(wv)
        return wv
    }

    private fun applyAll() {
        val list = ArrayList<WebTab>(tabs)
        youtubeTab?.let { list.add(it) }
        for (tab in list) {
            applyScripts(tab, tab.webView)
            applyCookiePolicy(tab.webView)
        }
    }

    private fun applyCookiePolicy(wv: WebView) {
        // Les cookies de sites tiers servent surtout au suivi publicitaire.
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, !app.settings.value.blockAds)
    }

    /** Scripts exécutés avant ceux de la page, selon les paramètres. Effet à la page suivante. */
    private fun applyScripts(tab: WebTab, wv: WebView) {
        tab.handlers.forEach { runCatching { it.remove() } }
        tab.handlers.clear()
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) return
        val s = app.settings.value
        fun add(script: String) {
            runCatching { tab.handlers.add(WebViewCompat.addDocumentStartJavaScript(wv, script, setOf("*"))) }
        }
        if (s.blockPopups) add(AdBlocker.POPUP_SCRIPT)
        if (s.blockAds) {
            add(AdBlocker.COSMETIC_SCRIPT)
            if (tab.kind == WebTab.Kind.YOUTUBE) add(AdBlocker.YOUTUBE_SCRIPT)
        }
        if (tab.kind == WebTab.Kind.YOUTUBE) add(AdBlocker.YOUTUBE_BUTTONS_SCRIPT)
        else add(MediaSniffer.MEDIA_BUTTON_SCRIPT)
    }

    /** Anciens WebView sans prise en charge des scripts « document start » : injection au chargement. */
    private fun injectFallback(tab: WebTab, view: WebView) {
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) return
        val s = app.settings.value
        if (s.blockPopups) view.evaluateJavascript(AdBlocker.POPUP_SCRIPT, null)
        if (s.blockAds) {
            view.evaluateJavascript(AdBlocker.COSMETIC_SCRIPT, null)
            if (tab.kind == WebTab.Kind.YOUTUBE) view.evaluateJavascript(AdBlocker.YOUTUBE_SCRIPT, null)
        }
        if (tab.kind == WebTab.Kind.YOUTUBE) view.evaluateJavascript(AdBlocker.YOUTUBE_BUTTONS_SCRIPT, null)
        else view.evaluateJavascript(MediaSniffer.MEDIA_BUTTON_SCRIPT, null)
    }

    // ------------------------------------------------------------ Clients

    private fun client(tab: WebTab) = object : WebViewClient() {

        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
            val pageHost = runCatching { Uri.parse(tab.url).host }.getOrNull()
            if (app.settings.value.blockAds && blocker.shouldBlock(request.url, pageHost)) {
                activity.runOnUiThread { blocked++ }
                return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
            }
            if (tab.kind == WebTab.Kind.BROWSER) {
                val kind = MediaSniffer.classify(request.url)
                val u = request.url.toString()
                if (kind != null && !MediaSniffer.noisy(u)) {
                    val referer = request.requestHeaders?.get("Referer")?.takeIf { it.isNotBlank() } ?: tab.url
                    activity.runOnUiThread { tab.addMedia(MediaHit(u, kind, referer)) }
                }
            }
            return null
        }

        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            val uri = request.url
            val scheme = uri.scheme?.lowercase()
            when (scheme) {
                "http", "https" -> Unit
                "magnet" -> {
                    app.manager.enqueue(uri.toString())
                    toast("Torrent ajouté aux téléchargements")
                    return true
                }
                "tel", "mailto", "sms", "geo" -> {
                    if (request.hasGesture()) {
                        runCatching {
                            activity.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        }
                    }
                    return true
                }
                // intent:, market:, applications tierces… : souvent des publicités déguisées
                else -> {
                    activity.runOnUiThread { blocked++ }
                    return true
                }
            }

            val s = app.settings.value
            if (s.blockRedirects && request.isForMainFrame && !request.hasGesture() &&
                !request.isRedirect && tab.url.isNotBlank()
            ) {
                val from = runCatching { Uri.parse(tab.url).host }.getOrNull()
                val to = uri.host
                if (from != null && to != null && site(from) != site(to)) {
                    activity.runOnUiThread { blocked++ }
                    return true
                }
            }

            // L'onglet YouTube reste sur YouTube : les liens externes s'ouvrent dans le navigateur.
            if (tab.kind == WebTab.Kind.YOUTUBE && !isYoutubeFamily(uri.host)) {
                openInBrowser(uri.toString())
                return true
            }
            return false
        }

        override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
            if (url != tab.url) tab.resetMedia()
            tab.url = url
            tab.progress = 5
            injectFallback(tab, view)
        }

        override fun onPageFinished(view: WebView, url: String) {
            tab.url = url
            tab.title = view.title ?: ""
            tab.progress = 100
            tab.canGoBack = view.canGoBack()
            tab.canGoForward = view.canGoForward()
        }

        override fun doUpdateVisitedHistory(view: WebView, url: String, isReload: Boolean) {
            tab.url = url
            tab.canGoBack = view.canGoBack()
            tab.canGoForward = view.canGoForward()
        }

        override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
            val url = tab.url
            activity.runOnUiThread {
                val old = tab.webView
                (old.parent as? ViewGroup)?.removeView(old)
                old.destroy()
                tab.webView = buildWebView(tab)
                tab.generation++
                if (url.isNotBlank()) tab.webView.loadUrl(url)
            }
            return true
        }
    }

    private fun chrome(tab: WebTab) = object : WebChromeClient() {

        override fun onProgressChanged(view: WebView, newProgress: Int) {
            tab.progress = newProgress
        }

        override fun onReceivedTitle(view: WebView, title: String?) {
            tab.title = title ?: ""
        }

        override fun onCreateWindow(
            view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message,
        ): Boolean {
            // Fenêtre ouverte sans action de l'utilisateur : c'est un pop-up, on la refuse.
            if (app.settings.value.blockPopups && !isUserGesture) {
                activity.runOnUiThread { blocked++ }
                return false
            }
            if (tab.kind == WebTab.Kind.YOUTUBE) return false
            val fresh = newBrowserTab()
            val transport = resultMsg.obj as WebView.WebViewTransport
            transport.webView = fresh.webView
            resultMsg.sendToTarget()
            return true
        }

        override fun onShowCustomView(view: View, callback: CustomViewCallback) {
            if (customView != null) {
                callback.onCustomViewHidden()
                return
            }
            customView = view
            customCallback = callback
            val decor = activity.window.decorView as FrameLayout
            view.setBackgroundColor(android.graphics.Color.BLACK)
            decor.addView(
                view,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT,
                ),
            )
            val controller = WindowCompat.getInsetsController(activity.window, decor)
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            fullscreen.value = true
        }

        override fun onHideCustomView() {
            exitFullscreen()
        }
    }

    fun exitFullscreen() {
        val view = customView ?: return
        (view.parent as? ViewGroup)?.removeView(view)
        customCallback?.onCustomViewHidden()
        customView = null
        customCallback = null
        val decor = activity.window.decorView
        WindowCompat.getInsetsController(activity.window, decor).show(WindowInsetsCompat.Type.systemBars())
        activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        fullscreen.value = false
    }

    // -------------------------------------------------------- Téléchargements

    private fun onDownload(tab: WebTab, url: String, disposition: String?, mime: String?) {
        if (url.startsWith("blob:") || url.startsWith("data:")) {
            toast("Ce type de lien ne peut pas être téléchargé directement")
            return
        }
        val cookie = CookieManager.getInstance().getCookie(url) ?: ""
        app.manager.enqueueFromBrowser(url, cookie, tab.url, disposition, mime)
        toast("Téléchargement ajouté")
    }

    /** Pont JavaScript de la page YouTube : l'icône de téléchargement d'une miniature appelle download(). */
    inner class YtBridge {
        @JavascriptInterface
        fun download(url: String?) {
            val u = url ?: return
            val host = runCatching { Uri.parse(u).host }.getOrNull()
            if (!isYoutubeFamily(host)) return
            activity.runOnUiThread { formatRequest.value = u }
        }
    }

    /** Pont JavaScript des pages web : l'icône posée sur un lecteur vidéo appelle tap(). */
    inner class MediaBridge(private val tab: WebTab) {
        @JavascriptInterface
        fun tap(src: String?, kind: String?) {
            val u = src.orEmpty()
            activity.runOnUiThread {
                if (u.startsWith("http")) {
                    val k = MediaSniffer.classify(Uri.parse(u))
                    if (k != null) tab.addMedia(MediaHit(u, k, tab.url))
                    else if (kind == "iframe") tab.embed = u
                }
                mediaSheet.value = tab
            }
        }

        @JavascriptInterface
        fun seen(count: Int) {
            if (count > 0) activity.runOnUiThread { tab.hasVideo = true }
        }
    }

    /** Cherche les épisodes de la page courante (séries, listes de lecture) et ouvre la sélection. */
    fun scanEpisodes(tab: WebTab) {
        tab.webView.evaluateJavascript(MediaSniffer.EPISODES_SCRIPT) { raw ->
            val json = unwrap(raw)
            val list = runCatching {
                val o = org.json.JSONObject(json ?: "")
                val arr = o.getJSONArray("items")
                val items = ArrayList<EpisodeItem>()
                for (i in 0 until arr.length()) {
                    val e = arr.getJSONObject(i)
                    items.add(EpisodeItem(e.getString("t"), e.getString("u"), e.optInt("n", 0)))
                }
                EpisodeList(o.optString("page"), tab.url, items)
            }.getOrNull()
            if (list == null || list.items.isEmpty()) toast("Aucun épisode trouvé sur cette page")
            else episodes.value = list
        }
    }

    /** Cherche les images de la page courante et ouvre la sélection. */
    fun scanImages(tab: WebTab) {
        tab.webView.evaluateJavascript(MediaSniffer.IMAGES_SCRIPT) { raw ->
            val json = unwrap(raw)
            val list = runCatching {
                val arr = org.json.JSONArray(json ?: "")
                (0 until arr.length()).map { i ->
                    val o = arr.getJSONObject(i)
                    PageImage(o.getString("u"), o.optInt("w", 0))
                }
            }.getOrNull()
            if (list.isNullOrEmpty()) toast("Aucune image trouvée sur cette page")
            else images.value = list
        }
    }

    /** Télécharge un fichier de la page avec les cookies et la page d'origine (liens protégés). */
    fun downloadFile(tab: WebTab, url: String, disposition: String? = null, referer: String? = null) {
        val cookie = CookieManager.getInstance().getCookie(url) ?: ""
        app.manager.enqueueFromBrowser(url, cookie, referer ?: tab.url, disposition, null)
    }

    /** Télécharge un flux détecté. [audio] : extraire en MP3. */
    fun downloadMedia(tab: WebTab, hit: MediaHit, audio: Boolean) {
        val title = tab.title.ifBlank { Links.hostOf(tab.url) }
        val cookie = CookieManager.getInstance().getCookie(hit.url) ?: ""
        if (!hit.isStream && !audio) {
            val name = Links.sanitize(title).take(100) + "." + hit.extension
            downloadFile(tab, hit.url, "attachment; filename=\"$name\"", hit.referer)
        } else {
            app.manager.enqueueStream(hit.url, hit.referer, cookie, title, if (audio) "mp3" else "best")
        }
        toast("Téléchargement ajouté")
    }

    private fun unwrap(raw: String?): String? {
        if (raw == null || raw == "null") return null
        return runCatching { org.json.JSONTokener(raw).nextValue() as? String }.getOrNull()
    }

    private fun openInBrowser(url: String) {
        activity.runOnUiThread {
            newBrowserTab(url)
            requestTab.value = TAB_BROWSER
        }
    }

    // ------------------------------------------------------------ Divers

    fun clearData() {
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        WebStorage.getInstance().deleteAllData()
        val all = ArrayList<WebTab>(tabs)
        youtubeTab?.let { all.add(it) }
        all.forEach {
            it.webView.clearCache(true)
            it.webView.clearHistory()
            it.webView.clearFormData()
        }
    }

    fun pause() {
        tabs.forEach { it.webView.onPause() }
        youtubeTab?.webView?.onPause()
    }

    fun resume() {
        tabs.forEach { it.webView.onResume() }
        youtubeTab?.webView?.onResume()
    }

    fun destroyAll() {
        exitFullscreen()
        crawler.cancel()
        tabs.toList().forEach { destroy(it) }
        tabs.clear()
        youtubeTab?.let { destroy(it) }
        youtubeTab = null
    }

    private fun destroy(tab: WebTab) {
        runCatching {
            tab.handlers.forEach { it.remove() }
            tab.handlers.clear()
            val wv = tab.webView
            (wv.parent as? ViewGroup)?.removeView(wv)
            wv.stopLoading()
            wv.destroy()
        }
    }

    private fun toast(message: String) {
        activity.runOnUiThread { Toast.makeText(activity, message, Toast.LENGTH_SHORT).show() }
    }

    private fun site(host: String): String {
        val parts = host.lowercase().split('.')
        return if (parts.size <= 2) host.lowercase() else parts.takeLast(2).joinToString(".")
    }

    companion object {
        const val MAX_TABS = 12
        const val TAB_BROWSER = 2
        const val DESKTOP_UA =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"

        fun isYoutubeFamily(host: String?): Boolean {
            val h = host?.lowercase() ?: return false
            return listOf(
                "youtube.com", "youtu.be", "google.com", "gstatic.com", "ytimg.com",
                "googleusercontent.com", "googlevideo.com", "ggpht.com", "youtube-nocookie.com",
            ).any { h == it || h.endsWith(".$it") }
        }
    }
}
