package com.dlvibestudio.dlturbo.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dlvibestudio.dlturbo.App
import com.dlvibestudio.dlturbo.R
import com.dlvibestudio.dlturbo.util.PinLock
import kotlinx.coroutines.delay

/** Écran de verrouillage : clavier numérique, 5 essais puis 30 secondes d'attente. */
@Composable
fun LockScreen(app: App, onUnlock: () -> Unit) {
    val s = app.settings.value
    var pin by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var failures by remember { mutableIntStateOf(0) }
    var blockedUntil by remember { mutableLongStateOf(0L) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(blockedUntil) {
        while (System.currentTimeMillis() < blockedUntil) {
            now = System.currentTimeMillis()
            delay(500)
        }
        now = System.currentTimeMillis()
    }
    val blocked = now < blockedUntil

    fun submit() {
        if (blocked || pin.length < 4) return
        if (PinLock.verify(pin, s.pinHash, s.pinSalt)) {
            onUnlock()
        } else {
            failures++
            pin = ""
            if (failures % 5 == 0) {
                blockedUntil = System.currentTimeMillis() + 30_000
                message = "Trop d'essais. Patientez 30 secondes."
            } else {
                message = "Code incorrect"
            }
        }
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier.fillMaxSize().systemBarsPadding().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Image(
                painter = painterResource(R.drawable.logo),
                contentDescription = null,
                modifier = Modifier.size(72.dp).clip(RoundedCornerShape(18.dp)),
            )
            Spacer(Modifier.height(12.dp))
            Text("DL Turbo", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Entrez votre code", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(16.dp))
            Text(
                "●".repeat(pin.length) + "○".repeat((4 - pin.length).coerceAtLeast(0)),
                fontSize = 26.sp,
                letterSpacing = 6.sp,
            )
            Text(
                if (blocked) "Trop d'essais. Patientez ${((blockedUntil - now) / 1000 + 1)} s." else message,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.height(28.dp).padding(top = 6.dp),
            )
            Spacer(Modifier.height(8.dp))
            val rows = listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"))
            rows.forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.padding(vertical = 6.dp)) {
                    row.forEach { d -> Key(d) { if (pin.length < 8 && !blocked) { pin += d; message = "" } } }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.padding(vertical = 6.dp)) {
                Key("⌫") { pin = pin.dropLast(1) }
                Key("0") { if (pin.length < 8 && !blocked) { pin += "0"; message = "" } }
                Key("OK") { submit() }
            }
        }
    }
}

@Composable
private fun Key(label: String, onClick: () -> Unit) {
    FilledTonalButton(onClick = onClick, modifier = Modifier.size(width = 78.dp, height = 56.dp)) {
        Text(label, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
    }
}
