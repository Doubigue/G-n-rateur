package com.dlvibestudio.dlturbo.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.dlvibestudio.dlturbo.App
import com.dlvibestudio.dlturbo.engine.VideoInfo
import com.dlvibestudio.dlturbo.engine.YtEntry
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.net.URLEncoder

data class YtCategory(val label: String, val query: String, val playlists: Boolean = false)

/**
 * État de l'onglet YouTube : recherche native (résultats avec icône de téléchargement),
 * catégories, contenu d'une playlist. Conservé quand on change d'onglet.
 */
class YtModel(private val app: App) {

    val categories = listOf(
        YtCategory("Tendances", "tendances du moment"),
        YtCategory("Musique", "musique"),
        YtCategory("Afrique", "musique africaine"),
        YtCategory("Films", "film complet"),
        YtCategory("Jeux", "gaming"),
        YtCategory("Sport", "sport"),
        YtCategory("Actualités", "actualités"),
        YtCategory("Playlists", "playlist musique", playlists = true),
    )

    /** 0 = Découvrir (liste native), 1 = Site YouTube (WebView). */
    var mode by mutableIntStateOf(0)
    var query by mutableStateOf("")
    var category by mutableIntStateOf(0)
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var results by mutableStateOf<List<YtEntry>>(emptyList())
    var canLoadMore by mutableStateOf(false)

    /** Page à charger dans le mode « Site YouTube » dès qu'il s'affiche (null = rien de spécial). */
    var siteTarget by mutableStateOf<String?>(null)
    var siteLoaded = false

    /** Non nul quand on regarde le contenu d'une playlist. */
    var playlistTitle by mutableStateOf<String?>(null)
    var playlistUrl by mutableStateOf<String?>(null)

    private var count = PAGE
    private var lastQuery = ""
    private var lastPlaylists = false
    private var job: Job? = null
    private var parentResults: List<YtEntry>? = null
    private var started = false

    /** Ouvre une vidéo dans le site YouTube pour la regarder. */
    fun watch(videoUrl: String) {
        siteTarget = videoUrl.replace("://www.youtube.com", "://m.youtube.com")
        mode = 1
    }

    fun startIfNeeded() {
        if (started) return
        started = true
        selectCategory(0)
    }

    fun selectCategory(index: Int) {
        category = index
        query = ""
        val c = categories[index]
        search(c.query, c.playlists, more = false)
    }

    fun submit() {
        val q = query.trim()
        if (q.isEmpty()) return
        category = -1
        search(q, playlists = false, more = false)
    }

    fun loadMore() {
        search(lastQuery, lastPlaylists, more = true)
    }

    private fun search(q: String, playlists: Boolean, more: Boolean) {
        job?.cancel()
        playlistTitle = null
        playlistUrl = null
        parentResults = null
        lastQuery = q
        lastPlaylists = playlists
        count = if (more) (count + PAGE).coerceAtMost(MAX) else PAGE
        job = app.scope.launch {
            loading = true
            error = null
            try {
                val json = if (playlists) {
                    val enc = URLEncoder.encode(q, "UTF-8")
                    app.manager.videos.dumpJson(
                        "https://www.youtube.com/results?search_query=$enc&sp=EgIQAw%3D%3D",
                        "--flat-playlist" to null,
                        "--playlist-end" to count.toString(),
                    )
                } else {
                    app.manager.videos.dumpJson("ytsearch$count:$q", "--flat-playlist" to null)
                }
                val list = VideoInfo.entries(json)
                results = list
                canLoadMore = list.size >= count && count < MAX
                if (list.isEmpty()) error = "Aucun résultat"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = e.message ?: "Erreur de recherche"
            } finally {
                loading = false
            }
        }
    }

    fun openPlaylist(entry: YtEntry) {
        job?.cancel()
        parentResults = results
        playlistTitle = entry.title
        playlistUrl = entry.url
        results = emptyList()
        canLoadMore = false
        job = app.scope.launch {
            loading = true
            error = null
            try {
                val json = app.manager.videos.dumpJson(entry.url, "--flat-playlist" to null)
                results = VideoInfo.entries(json)
                json.optString("title").takeIf { it.isNotBlank() }?.let { playlistTitle = it }
                if (results.isEmpty()) error = "Playlist vide ou privée"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = e.message ?: "Impossible de lire la playlist"
            } finally {
                loading = false
            }
        }
    }

    /** Retour depuis une playlist. Renvoie false s'il n'y avait rien à fermer. */
    fun closePlaylist(): Boolean {
        if (playlistTitle == null) return false
        job?.cancel()
        results = parentResults ?: emptyList()
        parentResults = null
        playlistTitle = null
        playlistUrl = null
        loading = false
        error = null
        canLoadMore = false
        return true
    }

    companion object {
        private const val PAGE = 20
        private const val MAX = 100
    }
}
