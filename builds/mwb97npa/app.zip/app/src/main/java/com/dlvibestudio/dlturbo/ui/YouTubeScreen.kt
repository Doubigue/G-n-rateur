@file:OptIn(ExperimentalMaterial3Api::class)

package com.dlvibestudio.dlturbo.ui

import android.view.ViewGroup
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.PlaylistPlay
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.key
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.dlvibestudio.dlturbo.App
import com.dlvibestudio.dlturbo.engine.YtEntry
import com.dlvibestudio.dlturbo.util.Format
import java.util.Locale

private val SITE_PAGES = listOf(
    "Accueil" to "https://m.youtube.com/",
    "Shorts" to "https://m.youtube.com/shorts",
    "Abonnements" to "https://m.youtube.com/feed/subscriptions",
    "Playlists" to "https://m.youtube.com/feed/library",
    "Historique" to "https://m.youtube.com/feed/history",
)

/**
 * Onglet YouTube façon Vidmate :
 * - « Découvrir » : recherche, catégories et playlists, avec une icône de téléchargement sur chaque vidéo ;
 * - « Site YouTube » : le vrai site, sans publicités, avec la même icône sur chaque miniature.
 */
@Composable
fun YouTubeScreen(app: App, hub: WebHub) {
    val yt = hub.yt
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Filled.PlayCircle, null, tint = Color(0xFFE62117), modifier = Modifier.size(30.dp))
            Spacer(Modifier.width(10.dp))
            Text("YouTube", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        TabRow(selectedTabIndex = yt.mode) {
            Tab(selected = yt.mode == 0, onClick = { yt.mode = 0 }, text = { Text("Découvrir") })
            Tab(selected = yt.mode == 1, onClick = { yt.mode = 1 }, text = { Text("Site YouTube") })
        }
        if (yt.mode == 0) DiscoverContent(app, hub) else SiteContent(hub)
    }
}

@Composable
private fun DiscoverContent(app: App, hub: WebHub) {
    val yt = hub.yt
    LaunchedEffect(Unit) { yt.startIfNeeded() }

    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = yt.query,
            onValueChange = { yt.query = it },
            placeholder = { Text("Rechercher une vidéo, un artiste, une playlist…") },
            singleLine = true,
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { yt.submit() }),
            shape = RoundedCornerShape(28.dp),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
        )

        val inPlaylist = yt.playlistTitle != null
        if (inPlaylist) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = { yt.closePlaylist() }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                }
                Text(
                    yt.playlistTitle ?: "",
                    modifier = Modifier.weight(1f),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    fontWeight = FontWeight.SemiBold,
                )
                Button(
                    onClick = { yt.playlistUrl?.let { hub.formatRequest.value = it } },
                    modifier = Modifier.padding(end = 8.dp),
                ) {
                    Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                    Text("  Tout")
                }
            }
        } else {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                yt.categories.forEachIndexed { i, c ->
                    FilterChip(
                        selected = yt.category == i,
                        onClick = { yt.selectCategory(i) },
                        label = { Text(c.label) },
                    )
                }
            }
        }

        if (yt.loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 4.dp))

        val err = yt.error
        if (err != null && yt.results.isEmpty()) {
            Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(err, color = MaterialTheme.colorScheme.error)
                Spacer(Modifier.height(8.dp))
                Text(
                    "Vérifiez la connexion. Si le problème persiste : Paramètres → « Mettre à jour le moteur vidéo ».",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 16.dp)) {
            items(yt.results, key = { it.url }) { entry ->
                VideoRow(app, entry,
                    onOpen = {
                        if (entry.isPlaylist) yt.openPlaylist(entry) else yt.watch(entry.url)
                    },
                    onDownload = { hub.formatRequest.value = entry.url },
                )
            }
            if (yt.canLoadMore && !yt.loading) {
                item {
                    OutlinedButton(
                        onClick = { yt.loadMore() },
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                    ) { Text("Voir plus de résultats") }
                }
            }
            if (yt.loading && yt.results.isEmpty()) {
                item {
                    Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
            }
        }
    }
}

@Composable
private fun VideoRow(app: App, entry: YtEntry, onOpen: () -> Unit, onDownload: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onOpen).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.width(144.dp).height(81.dp).clip(RoundedCornerShape(10.dp))) {
            RemoteImage(entry.thumbnail, app.manager.http.client, Modifier.fillMaxSize())
            if (entry.isPlaylist) {
                Row(
                    Modifier.align(Alignment.CenterEnd).fillMaxSize(0.38f).background(Color(0xCC000000)),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Filled.PlaylistPlay, null, tint = Color.White)
                        if (entry.count > 0) Text("${entry.count}", color = Color.White, fontSize = 11.sp)
                    }
                }
            } else if (entry.durationSec > 0) {
                Text(
                    Format.clock(entry.durationSec),
                    color = Color.White,
                    fontSize = 11.sp,
                    modifier = Modifier.align(Alignment.BottomEnd).padding(4.dp)
                        .background(Color(0xCC000000), RoundedCornerShape(4.dp))
                        .padding(horizontal = 4.dp, vertical = 1.dp),
                )
            }
        }
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(
                entry.title,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
            )
            val sub = buildList {
                if (entry.channel.isNotBlank()) add(entry.channel)
                if (entry.views > 0) add(views(entry.views))
                if (entry.isPlaylist) add("Playlist")
            }.joinToString(" · ")
            if (sub.isNotBlank()) {
                Text(
                    sub,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        // Petite icône de téléchargement sur chaque vidéo (formats MP4 / MP3 / WAV…)
        IconButton(onClick = onDownload) {
            Icon(
                Icons.Filled.Download,
                contentDescription = "Télécharger",
                tint = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.size(34.dp).clip(RoundedCornerShape(17.dp))
                    .background(MaterialTheme.colorScheme.primary).padding(6.dp),
            )
        }
    }
}

private fun views(n: Long): String = when {
    n >= 1_000_000_000 -> String.format(Locale.FRANCE, "%.1f Md vues", n / 1e9)
    n >= 1_000_000 -> String.format(Locale.FRANCE, "%.1f M vues", n / 1e6)
    n >= 1_000 -> String.format(Locale.FRANCE, "%.0f k vues", n / 1e3)
    else -> "$n vues"
}

@Composable
private fun SiteContent(hub: WebHub) {
    val yt = hub.yt
    val tab = hub.youtube

    LaunchedEffect(yt.siteTarget, tab.generation) {
        val target = yt.siteTarget
        if (target != null) {
            tab.webView.loadUrl(target)
            yt.siteTarget = null
            yt.siteLoaded = true
        } else if (!yt.siteLoaded) {
            yt.siteLoaded = true
            tab.webView.loadUrl("https://m.youtube.com/")
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            SITE_PAGES.forEach { (label, url) ->
                FilterChip(
                    selected = false,
                    onClick = { tab.webView.loadUrl(url) },
                    label = { Text(label) },
                )
            }
        }
        if (tab.progress < 100) {
            LinearProgressIndicator(
                progress = { tab.progress / 100f },
                modifier = Modifier.fillMaxWidth().height(2.dp),
            )
        } else {
            Spacer(Modifier.height(2.dp))
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            key(tab.generation) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = {
                        val wv = tab.webView
                        (wv.parent as? ViewGroup)?.removeView(wv)
                        wv
                    },
                )
            }
            val onVideo = tab.url.contains("/watch") || tab.url.contains("/shorts/") ||
                tab.url.contains("/playlist")
            if (onVideo) {
                ExtendedFloatingActionButton(
                    onClick = { hub.formatRequest.value = tab.url },
                    icon = { Icon(Icons.Filled.Download, contentDescription = null) },
                    text = { Text("Télécharger") },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
                )
            }
        }
    }
}
