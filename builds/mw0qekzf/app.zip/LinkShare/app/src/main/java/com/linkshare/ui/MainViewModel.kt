package com.linkshare.ui

import android.app.Application
import android.content.pm.ApplicationInfo
import android.net.Uri
import android.os.Environment
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.linkshare.client.Jobs
import com.linkshare.client.RemoteClient
import com.linkshare.core.*
import kotlinx.coroutines.*
import java.io.File

data class HistoryItem(val text: String, val up: Boolean, val time: Long)

/** Application installée sur CE téléphone (onglet « Applis » de l'écran « Moi »). */
data class LocalApp(val info: ApplicationInfo, val label: String, val size: Long, val system: Boolean)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    /** Connexion à l'autre téléphone : elle vit dans [Session], hors de l'écran. */
    val client: RemoteClient? get() = Session.client
    val deviceName: String get() = Session.peerName

    var path by mutableStateOf("")
    var entries by mutableStateOf<List<FileEntry>>(emptyList())
    var apps by mutableStateOf<List<AppEntry>>(emptyList())
    var viewer by mutableStateOf<FileEntry?>(null)
    /** Fichiers du même type que [viewer] dans le dossier affiché : on passe de l'un à l'autre en balayant. */
    var viewerList by mutableStateOf<List<FileEntry>>(emptyList())
    var status by mutableStateOf<String?>(null)
    var message by mutableStateOf<String?>(null)

    /** Filtre de catégorie (Docs, Photos…) choisi à l'accueil ou dans la liste distante. */
    var category by mutableStateOf<Category?>(null)
    /** Chemins cochés dans la liste distante (téléchargement groupé). */
    val selection = mutableStateListOf<String>()
    /** Derniers transferts terminés (affichés sur l'accueil). */
    val history = mutableStateListOf<HistoryItem>()

    // ── « Moi » : mes fichiers et mes applis, à envoyer à l'autre
    val localRoot: File = Environment.getExternalStorageDirectory()
    var localDir by mutableStateOf(localRoot)
    var localEntries by mutableStateOf<List<File>>(emptyList())
    /** Chemins absolus cochés dans « Moi ». */
    val localSel = mutableStateListOf<String>()
    var localApps by mutableStateOf<List<LocalApp>>(emptyList())
    val localAppSel = mutableStateListOf<String>()

    private val ctx get() = getApplication<Application>()

    init {
        Session.init(app)
        // Connexion ouverte (y compris par l'autre téléphone) → on affiche sa racine ; fermée → on nettoie
        viewModelScope.launch {
            snapshotFlow { Session.client }.collect { c ->
                if (c != null) launchSafe { browse("") } else clearRemote()
            }
        }
        viewModelScope.launch { Session.events.collect { message = it } }
        // Historique de l'accueil : transferts terminés
        viewModelScope.launch {
            val seen = HashSet<String>()
            TransferHub.items.collect { list ->
                list.filter { it.state == XState.DONE && seen.add(it.key) }.reversed().forEach {
                    history.add(0, HistoryItem(it.name + if (it.dir == Dir.UP) " → ${it.peer}" else " ← ${it.peer}", it.dir == Dir.UP, System.currentTimeMillis()))
                }
                while (history.size > 20) history.removeAt(history.lastIndex)
            }
        }
    }

    private fun launchSafe(block: suspend () -> Unit) = viewModelScope.launch {
        try { block() }
        catch (e: CancellationException) { throw e }
        catch (e: Exception) { message = e.message ?: e.toString(); status = null }
    }

    private fun safe(block: () -> Unit) {
        try { block() } catch (e: Exception) { message = e.message ?: e.toString() }
    }

    fun connect(c: Connection) = launchSafe {
        status = "Connexion à ${c.name}…"
        try { Session.connect(ctx, c) } finally { status = null }
    }

    fun disconnect() {
        Session.disconnect()
        clearRemote()
    }

    private fun clearRemote() {
        stopPlayback()
        viewer = null; viewerList = emptyList()
        entries = emptyList(); apps = emptyList(); path = ""
        selection.clear(); category = null
    }

    /** Un flux venant de l'autre téléphone ne peut plus continuer. */
    private fun stopPlayback() { }

    private suspend fun browse(p: String) {
        val c = client ?: return
        val l = c.list(p)
        entries = l.entries; path = l.path
        selection.clear()
    }

    fun open(p: String) = launchSafe { browse(p) }
    fun up() { if (path.isNotEmpty()) open(path.substringBeforeLast('/', "")) }

    fun tap(e: FileEntry) {
        if (e.isDir) open(e.path)
        else if (e.isImage() || e.isAv()) {
            viewerList = entries.filter { !it.isDir && sameKind(e, it) }
            viewer = e
        } else download(e)
    }

    /** Images avec images ; vidéos avec vidéos ; audio avec audio. */
    private fun sameKind(a: FileEntry, b: FileEntry) =
        if (a.isImage()) b.isImage() else b.isAv() && a.category() == b.category()

    fun loadApps() = launchSafe { if (apps.isEmpty()) apps = client?.apps().orEmpty() }

    fun download(e: FileEntry) = safe {
        Jobs.download(ctx, e)
        message = "Réception de ${e.name}…"
    }

    fun downloadApp(a: AppEntry) = safe {
        Jobs.downloadApp(ctx, a)
        message = "Réception de ${a.name}…"
    }

    /** Télécharge toutes les entrées cochées (fichiers et dossiers), chacune avec son pourcentage. */
    fun downloadSelected() = safe {
        val list = entries.filter { it.path in selection }
        selection.clear()
        list.forEach { Jobs.download(ctx, it) }
        if (list.isNotEmpty()) message = "${list.size} élément(s) en réception"
    }

    // ───────────────────────────── « Moi » ─────────────────────────────

    fun openLocal(dir: File) = launchSafe {
        val list = withContext(Dispatchers.IO) {
            (dir.listFiles() ?: emptyArray()).filter { !it.name.startsWith(".") }
                .sortedWith(compareByDescending<File> { it.isDirectory }.thenBy { it.name.lowercase() })
        }
        localDir = dir; localEntries = list
    }

    fun localUp(): Boolean {
        if (localDir.path == localRoot.path) return false
        openLocal(localDir.parentFile ?: localRoot)
        return true
    }

    fun toggleLocal(f: File) {
        if (f.path in localSel) localSel.remove(f.path) else localSel.add(f.path)
    }

    fun loadLocalApps() = launchSafe {
        if (localApps.isNotEmpty()) return@launchSafe
        val pm = ctx.packageManager
        localApps = withContext(Dispatchers.IO) {
            pm.getInstalledApplications(0).map { ai ->
                val splits = ai.splitSourceDirs ?: emptyArray()
                LocalApp(
                    ai, pm.getApplicationLabel(ai).toString(),
                    File(ai.sourceDir).length() + splits.sumOf { File(it).length() },
                    (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0,
                )
            }.sortedBy { it.label.lowercase() }
        }
    }

    /** Envoie tout ce qui est coché dans « Moi » (fichiers, dossiers, applis). */
    fun sendLocalSelection() = safe {
        val files = localSel.map { File(it) }
        val appsSel = localApps.filter { it.info.packageName in localAppSel }.map { it.info }
        localSel.clear(); localAppSel.clear()
        if (files.isNotEmpty()) Jobs.sendFiles(ctx, files)
        if (appsSel.isNotEmpty()) Jobs.sendApps(ctx, appsSel)
        val n = files.size + appsSel.size
        if (n > 0) message = "$n élément(s) en envoi vers $deviceName"
    }

    fun sendUris(uris: List<Uri>) = safe { if (uris.isNotEmpty()) Jobs.sendUris(ctx, uris) }
    fun sendTree(tree: Uri) = safe { Jobs.sendTree(ctx, tree) }

    // Compatibilité avec les anciens boutons « Envoyer fichiers / dossier »
    fun uploadFiles(uris: List<Uri>) = sendUris(uris)
    fun uploadFolder(tree: Uri) = sendTree(tree)
}
