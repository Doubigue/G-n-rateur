package com.linkshare.core

import android.os.SystemClock
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import java.util.concurrent.atomic.AtomicLong

enum class Dir { UP, DOWN }
enum class XState { RUNNING, DONE, FAILED, CANCELLED }

/**
 * Un transfert (fichier, dossier ou application) vu depuis CE téléphone :
 * UP = envoi vers l'autre, DOWN = réception depuis l'autre.
 * Les deux téléphones ont chacun leur fiche, ce qui donne le même pourcentage des deux côtés.
 */
class Xfer internal constructor(
    val key: String, val name: String, val dir: Dir, total: Long, val peer: String,
    /** Côté serveur : terminé automatiquement quand tous les octets sont passés. */
    private val autoFinish: Boolean,
) {
    @Volatile var total: Long = total
    val done = AtomicLong(0)
    @Volatile var state = XState.RUNNING; private set
    @Volatile var error: String? = null; private set
    val started: Long = SystemClock.elapsedRealtime()
    @Volatile var ended = 0L; private set
    @Volatile var speed = 0L; internal set
    internal var lastBytes = 0L
    internal var lastT = started
    /** Annulation : job côté client, fermeture du socket côté serveur. */
    @Volatile var canceller: (() -> Unit)? = null

    fun add(n: Long) {
        if (n <= 0) return
        val d = done.addAndGet(n)
        TransferHub.dirty = true
        if (autoFinish && total in 1..d) finish()
    }

    fun finish() { end(XState.DONE, null) }
    fun fail(msg: String?) { end(XState.FAILED, msg ?: "Erreur") }
    fun cancel() {
        val c = canceller
        end(XState.CANCELLED, null)
        runCatching { c?.invoke() }
    }

    private fun end(s: XState, msg: String?) {
        synchronized(this) {
            if (state != XState.RUNNING) return
            state = s; error = msg; ended = SystemClock.elapsedRealtime(); speed = 0
        }
        TransferHub.changed()
    }
}

/** Instantané immuable pour l'interface. */
data class XView(
    val key: String, val name: String, val dir: Dir, val done: Long, val total: Long,
    val speed: Long, val state: XState, val error: String?, val peer: String, val elapsedMs: Long,
) {
    val percent: Int get() = when {
        state == XState.DONE -> 100
        total > 0 -> ((done * 100) / total).toInt().coerceIn(0, 100)
        else -> 0
    }
    val fraction: Float get() = if (state == XState.DONE) 1f else if (total > 0) (done.toFloat() / total).coerceIn(0f, 1f) else 0f
    /** Temps restant estimé, en secondes (null si inconnu). */
    val etaSec: Long? get() = if (state == XState.RUNNING && speed > 0 && total > done) (total - done) / speed else null
}

data class DirSummary(val running: Int, val done: Long, val total: Long, val speed: Long) {
    val percent: Int get() = if (total > 0) ((done * 100) / total).toInt().coerceIn(0, 100) else 0
    val fraction: Float get() = if (total > 0) (done.toFloat() / total).coerceIn(0f, 1f) else 0f
}

object TransferHub {
    private val list = ArrayList<Xfer>() // ordre d'arrivée, plus récent en tête
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    @Volatile internal var dirty = false

    val items = MutableStateFlow<List<XView>>(emptyList())
    val up = MutableStateFlow(DirSummary(0, 0, 0, 0))
    val down = MutableStateFlow(DirSummary(0, 0, 0, 0))

    init {
        scope.launch {
            while (isActive) {
                delay(400)
                if (dirty || anyRunning()) publish()
            }
        }
    }

    private fun anyRunning() = synchronized(list) { list.any { it.state == XState.RUNNING } }

    /**
     * Crée (ou retrouve, pour les morceaux d'un même fichier envoyés en parallèle) la fiche d'un transfert.
     */
    fun track(key: String, name: String, dir: Dir, total: Long, peer: String, autoFinish: Boolean = false): Xfer =
        synchronized(list) {
            // Même clé = même lot (morceaux parallèles, fichiers d'un dossier) : une seule fiche, une seule ligne
            list.firstOrNull { it.key == key }?.let { return it }
            Xfer(key, name, dir, total, peer, autoFinish).also {
                list.add(0, it)
                while (list.size > 200) list.removeAt(list.lastIndex)
            }
        }.also { changed() }

    fun changed() { dirty = true }

    fun cancel(key: String) = synchronized(list) { list.filter { it.key == key } }.forEach { it.cancel() }
    fun cancelAll() = synchronized(list) { list.toList() }.forEach { if (it.state == XState.RUNNING) it.cancel() }

    fun clearFinished() {
        synchronized(list) { list.removeAll { it.state != XState.RUNNING } }
        changed()
    }

    fun runningCount(): Int = synchronized(list) { list.count { it.state == XState.RUNNING } }

    private fun publish() {
        dirty = false
        val now = SystemClock.elapsedRealtime()
        val snap = synchronized(list) {
            list.map { x ->
                if (x.state == XState.RUNNING) {
                    val dt = now - x.lastT
                    if (dt >= 800) {
                        val d = x.done.get()
                        // Moyenne glissante : un débit lisible, qui ne saute pas d'une valeur à l'autre
                        val inst = (d - x.lastBytes) * 1000 / dt
                        x.speed = if (x.speed == 0L) inst else (x.speed * 6 + inst * 4) / 10
                        x.lastBytes = d; x.lastT = now
                    }
                }
                XView(
                    x.key, x.name, x.dir, x.done.get(), x.total, x.speed, x.state, x.error, x.peer,
                    (if (x.ended > 0) x.ended else now) - x.started,
                )
            }
        }
        items.value = snap
        up.value = summary(snap, Dir.UP)
        down.value = summary(snap, Dir.DOWN)
    }

    /** Résumé d'un sens : seules les fiches en cours (et le « lot » qu'elles forment) comptent dans le pourcentage. */
    private fun summary(s: List<XView>, d: Dir): DirSummary {
        val run = s.filter { it.dir == d && it.state == XState.RUNNING }
        return DirSummary(run.size, run.sumOf { it.done }, run.sumOf { it.total.coerceAtLeast(0) }, run.sumOf { it.speed })
    }
}
