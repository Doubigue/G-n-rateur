package com.linkshare.ui

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Environment
import android.text.format.Formatter
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.compose.ui.graphics.ImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.linkshare.core.*
import com.linkshare.server.ShareService
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

// ══════════════════════ Écrans de session : envoyer, scanner, cartes, mes fichiers, transferts ══════════════════════

private fun svec(name: String, d: String): ImageVector =
    ImageVector.Builder(name, 24.dp, 24.dp, 24f, 24f)
        .addPath(PathParser().parsePathString(d).toNodes(), fill = SolidColor(Color.Black))
        .build()

/** Icônes propres aux écrans de session (tracés Material). */
private object SIc {
    val Wifi by lazy { svec("wifi", "M1,9l2,2c4.97,-4.97 13.03,-4.97 18,0l2,-2C16.93,2.93 7.08,2.93 1,9zM9,17l3,3 3,-3c-1.65,-1.66 -4.34,-1.66 -6,0zM5,13l2,2c2.76,-2.76 7.24,-2.76 10,0l2,-2C15.14,9.14 8.87,9.14 5,13z") }
    val Hotspot by lazy { svec("hotspot", "M12,11c-1.1,0 -2,0.9 -2,2 0,0.74 0.4,1.38 1,1.72V22h2v-7.28c0.6,-0.35 1,-0.98 1,-1.72 0,-1.1 -0.9,-2 -2,-2zM18,13c0,1.13 -0.31,2.18 -0.85,3.08l1.71,1.03C19.58,15.9 20,14.5 20,13c0,-4.42 -3.58,-8 -8,-8s-8,3.58 -8,8c0,1.5 0.42,2.9 1.14,4.11l1.71,-1.03C6.31,15.18 6,14.13 6,13c0,-3.31 2.69,-6 6,-6s6,2.69 6,6zM12,1C5.93,1 1,5.93 1,12c0,2.06 0.57,3.98 1.56,5.62l1.72,-1.03C3.47,15.24 3,13.67 3,12c0,-4.96 4.04,-9 9,-9s9,4.04 9,9c0,1.67 -0.47,3.24 -1.28,4.59l1.72,1.03C22.43,15.98 23,14.06 23,12c0,-6.07 -4.93,-11 -11,-11z") }
    val Phone by lazy { svec("phone", "M17,1.01L7,1c-1.1,0 -2,0.9 -2,2v18c0,1.1 0.9,2 2,2h10c1.1,0 2,-0.9 2,-2V3c0,-1.1 -0.9,-1.99 -2,-1.99zM17,19H7V5h10v14z") }
    val Swap by lazy { svec("swap", "M6.99,11L3,15l3.99,4v-3H14v-2H6.99v-3zM21,9l-3.99,-4v3H10v2h7.01v3L21,9z") }
    val Power by lazy { svec("power", "M13,3h-2v10h2V3zM17.83,5.17l-1.42,1.42C17.99,7.86 19,9.81 19,12c0,3.87 -3.13,7 -7,7s-7,-3.13 -7,-7c0,-2.19 1.01,-4.14 2.58,-5.42L6.17,5.17C4.23,6.82 3,9.26 3,12c0,4.97 4.03,9 9,9s9,-4.03 9,-9c0,-2.74 -1.23,-5.18 -3.17,-6.83z") }
    val Error by lazy { svec("error", "M12,2C6.48,2 2,6.48 2,12s4.48,10 10,10 10,-4.48 10,-10S17.52,2 12,2zM13,17h-2v-2h2v2zM13,13h-2V7h2v6z") }
    val Pin by lazy { svec("pin", "M12,2C8.13,2 5,5.13 5,9c0,5.25 7,13 7,13s7,-7.75 7,-13c0,-3.87 -3.13,-7 -7,-7zM12,11.5c-1.38,0 -2.5,-1.12 -2.5,-2.5s1.12,-2.5 2.5,-2.5 2.5,1.12 2.5,2.5 -1.12,2.5 -2.5,2.5z") }
    val Bell by lazy { svec("bell", "M12,22c1.1,0 2,-0.9 2,-2h-4c0,1.1 0.89,2 2,2zM18,16v-5c0,-3.07 -1.64,-5.64 -4.5,-6.32V4c0,-0.83 -0.67,-1.5 -1.5,-1.5s-1.5,0.67 -1.5,1.5v0.68C7.63,5.36 6,7.92 6,11v5l-2,2v1h16v-1l-2,-2z") }
    val Bolt by lazy { svec("bolt", "M7,2v11h3v9l7,-12h-4l4,-8z") }
}

private val PeerGradient = Brush.linearGradient(listOf(Color(0xFF1E6FEB), Color(0xFF7C3AED)))
private val MeGradient = Brush.linearGradient(listOf(Color(0xFF0EA5A4), Color(0xFF1E6FEB)))
private val UpColor = Color(0xFF22C55E)
private val DownColor = Color(0xFF3B82F6)
private val Warn = Color(0xFFF59E0B)
private val Bad = Color(0xFFEF4444)

/** Écran précédant « Transferts » (retour). */
object SessionNav { var back by mutableStateOf(SessionScreen.PEERS) }

private fun openTransfers(from: SessionScreen) { SessionNav.back = from; Session.screen = SessionScreen.TRANSFERS }

@Composable
private fun TopBar(title: String, subtitle: String? = null, onBack: (() -> Unit)?, actions: @Composable RowScope.() -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (onBack != null) IconButton(onBack) { Icon(Ic.Back, "Retour", tint = LS.Text) } else Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = LS.Text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (subtitle != null) Text(subtitle, color = LS.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        actions()
    }
}

@Composable
private fun BigButton(text: String, icon: ImageVector?, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Button(
        onClick, modifier.fillMaxWidth().height(54.dp), enabled = enabled, shape = RoundedCornerShape(18.dp),
        colors = ButtonDefaults.buttonColors(containerColor = LS.Blue, contentColor = LS.OnBlue),
    ) {
        if (icon != null) { Icon(icon, null, Modifier.size(20.dp)); Spacer(Modifier.width(10.dp)) }
        Text(text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun NoticeCard(icon: ImageVector, tint: Color, title: String, text: String, content: @Composable ColumnScope.() -> Unit = {}) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(LS.Card).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(40.dp).clip(CircleShape).background(tint.copy(alpha = 0.18f)), contentAlignment = Alignment.Center) {
                Icon(icon, null, Modifier.size(22.dp), tint = tint)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = LS.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Text(text, color = LS.Muted, fontSize = 12.sp)
            }
        }
        content()
    }
}

// ═══════════════════════════════ FENÊTRE Wi-Fi (interrupteur) ═══════════════════════════════

/** Notre propre fenêtre Wi-Fi, affichée seulement si le téléphone ne montre pas celle d'Android. */
object WifiPopup { var show by mutableStateOf(false) }

/**
 * Ouvre la petite fenêtre Wi-Fi d'Android, avec son interrupteur (comme Xender).
 * Elle est lancée « pour résultat » (sinon Android la referme aussitôt). Si au bout d'une seconde
 * l'appli n'a pas été recouverte (téléphone sans cette fenêtre), notre propre fenêtre Wi-Fi s'affiche.
 */
@Composable
fun rememberWifiOpener(): () -> Unit {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    @Suppress("DEPRECATION")
    val owner = androidx.compose.ui.platform.LocalLifecycleOwner.current
    val paused = remember { mutableStateOf(false) }
    DisposableEffect(owner) {
        val obs = androidx.lifecycle.LifecycleEventObserver { _, e ->
            if (e == androidx.lifecycle.Lifecycle.Event.ON_PAUSE) paused.value = true
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { }
    return remember(launcher) {
        {
            scope.launch {
                if (Radio.wifiOn(ctx)) return@launch
                Radio.tryEnableWifi(ctx)
                delay(250)
                if (Radio.wifiOn(ctx)) return@launch
                for (i in Radio.wifiPanelIntents()) {
                    paused.value = false
                    val launched = try { launcher.launch(i); true } catch (_: Exception) { false }
                    if (!launched) continue
                    delay(1100)
                    if (paused.value || Radio.wifiOn(ctx)) return@launch // la fenêtre d'Android est à l'écran
                }
                WifiPopup.show = true // le téléphone n'a pas cette fenêtre : la nôtre prend le relais
            }
            Unit
        }
    }
}

/** Fenêtre « Wi-Fi » avec interrupteur, Paramètres et OK (à placer dans les écrans qui ouvrent le Wi-Fi). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WifiPopupHost() {
    if (!WifiPopup.show) return
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(500); tick++ } }
    val on = remember(tick) { Radio.wifiOn(ctx) }
    LaunchedEffect(on) { if (on) { delay(600); WifiPopup.show = false } }
    ModalBottomSheet(onDismissRequest = { WifiPopup.show = false }, containerColor = Color(0xFF2E2E2E), contentColor = Color.White) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(bottom = 16.dp)) {
            Text("Wi-Fi", Modifier.fillMaxWidth().padding(bottom = 16.dp), color = Color.White, fontSize = 24.sp,
                fontWeight = FontWeight.Medium, textAlign = TextAlign.Center)
            Row(
                Modifier.fillMaxWidth().background(Color(0xFF3D3D3D))
                    .clickable { if (!on) { Radio.tryEnableWifi(ctx); Radio.openWifiSettings(ctx) } }
                    .padding(horizontal = 28.dp, vertical = 22.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Wi-Fi", Modifier.weight(1f), color = Color.White, fontSize = 18.sp)
                Box(Modifier.width(1.dp).height(36.dp).background(Color(0xFF666666)))
                Spacer(Modifier.width(20.dp))
                Switch(
                    checked = on,
                    onCheckedChange = { want ->
                        // Android 10+ réserve l'interrupteur au système : on ouvre la page Wi-Fi, il suffit d'y toucher
                        if (want) { Radio.tryEnableWifi(ctx); if (!Radio.wifiOn(ctx)) Radio.openWifiSettings(ctx) }
                        else Radio.openWifiSettings(ctx)
                    },
                    colors = SwitchDefaults.colors(checkedTrackColor = UpColor),
                )
            }
            if (!on) Text(
                "Touche l'interrupteur : la page Wi-Fi s'ouvre, active-le puis reviens.",
                Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 10.dp),
                color = Color(0xFFBBBBBB), fontSize = 12.sp, textAlign = TextAlign.Center,
            )
            Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton({ Radio.openWifiSettings(ctx) }, shape = CircleShape) { Text("Paramètres", color = Color.White) }
                Spacer(Modifier.weight(1f))
                Button(
                    { WifiPopup.show = false }, shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE0E0E0), contentColor = Color.Black),
                ) { Text("OK") }
            }
        }
    }
}

// ═══════════════════════════════ PRÉPARATIFS (façon Xender) ═══════════════════════════════

enum class PrepMode { SEND, SCAN }

private class PrepItem(
    val icon: ImageVector, val label: String, val action: String,
    val done: Boolean, val required: Boolean, val onClick: () -> Unit,
)

/** « Envoyer » : préparatifs (Wi-Fi, autorisations, GPS…), puis bouton « Activer le point d'accès » et QR. */
@Composable
fun SendPanel(onBack: (() -> Unit)?) {
    PrepGate(PrepMode.SEND, onBack) { SendPanelContent(onBack) }
}

/** « Scanner » : préparatifs (Wi-Fi allumé, point d'accès coupé, autorisations…), puis scan. */
@Composable
fun ReceivePanel(onBack: (() -> Unit)?, onConnect: (Connection) -> Unit) {
    PrepGate(PrepMode.SCAN, onBack) { ReceiveContent(onBack, onConnect) }
}

/**
 * Écran « Les préparatifs » : une ligne par condition, avec son bouton (OUVRIR, CONFIGURER…).
 * « SUIVANT » s'active quand tout ce qui est obligatoire est prêt. Si tout est déjà prêt, l'écran est sauté.
 */
@Composable
fun PrepGate(mode: PrepMode, onBack: (() -> Unit)?, content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val act = ctx.findActivity()
    var tick by remember { mutableIntStateOf(0) }
    val resume = AppEvents.resumeTick
    // Le panneau Wi-Fi est une petite fenêtre : l'appli ne passe pas en arrière-plan, on vérifie donc en continu
    LaunchedEffect(Unit) { while (true) { delay(700); tick++ } }
    val ours by Hotspot.state.collectAsState()
    val info by ShareState.info.collectAsState()

    val files = remember(tick, resume) { Environment.isExternalStorageManager() }
    val wifi = remember(tick, resume) { Radio.wifiOn(ctx) }
    val perm = remember(tick, resume) { Hotspot.hasPermissions(ctx) }
    val gpsNeeded = Build.VERSION.SDK_INT < 33
    val gps = remember(tick, resume) { !Hotspot.locationNeeded(ctx) }
    val notif = remember(tick, resume) { !needsNotifPermission(ctx) }
    val battery = remember(tick, resume) {
        runCatching { ctx.getSystemService(android.os.PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName) }.getOrDefault(true)
    }
    val oursOn = ours != null || info?.ssid != null
    val systemAp = remember(tick, resume, ours) { mode == PrepMode.SCAN && Radio.systemHotspotOn(ctx) }
    val apOff = mode == PrepMode.SEND || (!oursOn && !systemAp)

    val required = files && wifi && perm && (!gpsNeeded || gps) && apOff
    var passed by remember { mutableStateOf(required) } // déjà prêt : on saute l'écran
    if (passed) { content(); return }

    // ── Lanceurs
    var deniedOnce by remember { mutableStateOf(false) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        tick++
        if (!r.values.all { it }) deniedOnce = true
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }

    val openWifi = rememberWifiOpener()
    fun askPerm() {
        val perms = Hotspot.permissions()
        val permanentlyDenied = deniedOnce && act != null &&
            perms.none { androidx.core.app.ActivityCompat.shouldShowRequestPermissionRationale(act, it) }
        if (permanentlyDenied) {
            Toast.makeText(ctx, "Autorise « ${if (Build.VERSION.SDK_INT >= 33) "Appareils à proximité" else "Position"} » dans Autorisations", Toast.LENGTH_LONG).show()
            Radio.openAppSettings(ctx)
        } else permLauncher.launch(perms)
    }
    fun cutHotspot() {
        if (oursOn) {
            Hotspot.stop()
            ctx.stopService(Intent(ctx, ShareService::class.java))
            tick++
        } else Radio.openTetherSettings(ctx)
    }

    val items = buildList {
        add(PrepItem(Ic.Folder, "Autoriser l'accès aux fichiers", "AUTORISER", files, true) { ensureAllFiles(ctx) })
        if (mode == PrepMode.SCAN && (oursOn || systemAp))
            add(PrepItem(SIc.Hotspot, "Couper le point d'accès", "COUPER", false, true) { cutHotspot() })
        add(PrepItem(SIc.Wifi, "Ouvrir le WLAN", "OUVRIR", wifi, true) { openWifi() })
        add(
            PrepItem(
                SIc.Pin, if (Build.VERSION.SDK_INT >= 33) "Autoriser les appareils à proximité" else "Accorder l'autorisation de localisation",
                "CONFIGURER", perm, true,
            ) { askPerm() }
        )
        if (gpsNeeded) add(PrepItem(SIc.Pin, "Ouvrir le GPS", "CONFIGURER", gps, true) { Radio.openLocationSettings(ctx) })
        if (Build.VERSION.SDK_INT >= 33) add(
            PrepItem(SIc.Bell, "Autoriser les notifications", "AUTORISER", notif, false) {
                notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        )
        add(PrepItem(SIc.Bolt, "Fonctionner écran éteint (batterie)", "AUTORISER", battery, false) {
            runCatching {
                ctx.startActivity(
                    Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, android.net.Uri.parse("package:${ctx.packageName}"))
                )
            }
        })
    }

    BackHandler(enabled = onBack != null) { onBack?.invoke() }
    Column(Modifier.fillMaxSize().background(LS.Bg)) {
        // En-tête plein, comme Xender
        Row(
            Modifier.fillMaxWidth().background(LS.Blue).statusBarsPadding().padding(horizontal = 4.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (onBack != null) IconButton(onBack) { Icon(Ic.Back, "Retour", tint = LS.OnBlue) } else Spacer(Modifier.width(16.dp))
            Text("Les préparatifs", color = LS.OnBlue, fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
        }
        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            PrepIllustration(Modifier.fillMaxWidth().height(200.dp).padding(vertical = 14.dp))
            Text(
                if (mode == PrepMode.SEND) "Avant d'envoyer, prépare ce téléphone :" else "Avant de scanner, prépare ce téléphone :",
                color = LS.Muted, fontSize = 13.sp, modifier = Modifier.padding(bottom = 6.dp),
            )
            items.forEach { PrepRow(it) }
        }
        val ready = items.filter { it.required }.all { it.done }
        Button(
            {
                if (needsNotifPermission(ctx) && !notif) runCatching { notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }
                passed = true
            },
            Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 18.dp, vertical = 14.dp).height(56.dp),
            enabled = ready, shape = CircleShape,
            colors = ButtonDefaults.buttonColors(
                containerColor = LS.Blue, contentColor = LS.OnBlue,
                disabledContainerColor = Color(0xFFCCCCCC), disabledContentColor = Color.White,
            ),
        ) { Text("SUIVANT", fontSize = 17.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp) }
    }
    WifiPopupHost()
}

@Composable
private fun PrepRow(it: PrepItem) {
    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(44.dp).clip(CircleShape).background(if (it.done) UpColor else LS.Blue), contentAlignment = Alignment.Center) {
            Icon(it.icon, null, Modifier.size(22.dp), tint = if (it.done) Color.White else LS.OnBlue)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(it.label, color = LS.Text, fontSize = 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (!it.required && !it.done) Text("Recommandé", color = LS.Muted, fontSize = 11.sp)
        }
        Spacer(Modifier.width(8.dp))
        if (it.done) {
            Box(Modifier.size(36.dp).clip(CircleShape).background(UpColor.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
                Icon(Ic.Check, "Fait", Modifier.size(20.dp), tint = UpColor)
            }
        } else {
            OutlinedButton(
                it.onClick, shape = CircleShape, contentPadding = PaddingValues(horizontal = 14.dp),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, LS.Blue),
                modifier = Modifier.height(40.dp).widthIn(min = 108.dp),
            ) { Text(it.action, color = LS.Blue, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1) }
        }
    }
}

/** Petite illustration : deux téléphones reliés par des ondes Wi-Fi. */
@Composable
private fun PrepIllustration(modifier: Modifier) {
    val t = rememberInfiniteTransition(label = "prep")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(2200, easing = LinearEasing)), label = "p")
    Canvas(modifier) {
        val h = size.height
        val pw = h * 0.42f; val ph = h * 0.78f
        val cy = h / 2
        val lx = size.width / 2 - h * 0.75f; val rx = size.width / 2 + h * 0.75f
        fun phone(cx: Float, color: Color) {
            drawRoundRect(color, Offset(cx - pw / 2, cy - ph / 2), androidx.compose.ui.geometry.Size(pw, ph), androidx.compose.ui.geometry.CornerRadius(pw * 0.18f))
            drawRoundRect(Color.White.copy(alpha = 0.9f), Offset(cx - pw / 2 + 6f, cy - ph / 2 + 14f), androidx.compose.ui.geometry.Size(pw - 12f, ph - 28f), androidx.compose.ui.geometry.CornerRadius(pw * 0.1f))
            // interrupteur vert sur l'écran
            drawRoundRect(UpColor, Offset(cx - pw * 0.25f, cy - ph * 0.08f), androidx.compose.ui.geometry.Size(pw * 0.5f, pw * 0.24f), androidx.compose.ui.geometry.CornerRadius(pw * 0.12f))
            drawCircle(Color.White, pw * 0.09f, Offset(cx + pw * 0.12f, cy - ph * 0.08f + pw * 0.12f))
        }
        phone(lx, Color(0xFF7C3AED))
        phone(rx, Color(0xFF1E6FEB))
        // Ondes qui voyagent de gauche à droite
        for (i in 0..2) {
            val f = (p + i / 3f) % 1f
            val x = lx + pw / 2 + (rx - lx - pw) * f
            drawCircle(UpColor.copy(alpha = (1f - f) * 0.9f), h * 0.05f, Offset(x, cy))
        }
        drawArc(UpColor.copy(alpha = 0.35f), 200f, 140f, false, Offset(size.width / 2 - h * 0.3f, cy - h * 0.45f), androidx.compose.ui.geometry.Size(h * 0.6f, h * 0.6f), style = Stroke(5f, cap = StrokeCap.Round))
        drawArc(UpColor.copy(alpha = 0.2f), 200f, 140f, false, Offset(size.width / 2 - h * 0.45f, cy - h * 0.6f), androidx.compose.ui.geometry.Size(h * 0.9f, h * 0.9f), style = Stroke(5f, cap = StrokeCap.Round))
    }
}

// ═══════════════════════════════ ENVOYER : point d'accès → QR ═══════════════════════════════

/**
 * « Envoyer » : un bouton active le point d'accès de l'appli, puis le QR s'affiche.
 * Dès que l'autre téléphone a scanné, l'écran des cartes s'ouvre tout seul (des deux côtés).
 */
@Composable
private fun SendPanelContent(onBack: (() -> Unit)?) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val info by ShareState.info.collectAsState()
    val hs by Hotspot.state.collectAsState()
    val starting by Hotspot.starting.collectAsState()
    val err by Hotspot.error.collectAsState()
    val tick = AppEvents.resumeTick
    var lanMode by remember { mutableStateOf(false) }
    val locationOff = remember(tick, starting) { Hotspot.locationNeeded(ctx) }

    fun startService(hotspot: Boolean) {
        val i = Intent(ctx, ShareService::class.java)
        if (hotspot) i.action = ShareService.ACTION_HOTSPOT
        ContextCompat.startForegroundService(ctx, i)
        askBatteryExemptionOnce(ctx)
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r.values.all { it }) startService(true)
        else Toast.makeText(ctx, "Autorise « Appareils à proximité » pour créer le point d'accès", Toast.LENGTH_LONG).show()
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (Hotspot.hasPermissions(ctx)) startService(true) else permLauncher.launch(Hotspot.permissions())
    }

    fun activate() {
        if (!ensureAllFiles(ctx)) return
        lanMode = false
        if (Hotspot.locationNeeded(ctx)) {
            Toast.makeText(ctx, "Active la localisation : Android l'exige pour créer un point d'accès", Toast.LENGTH_LONG).show()
            Radio.openLocationSettings(ctx); return
        }
        when {
            needsNotifPermission(ctx) -> notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            !Hotspot.hasPermissions(ctx) -> permLauncher.launch(Hotspot.permissions())
            else -> startService(true)
        }
    }

    fun stopAll() {
        lanMode = false
        ctx.stopService(Intent(ctx, ShareService::class.java))
    }

    val showQr = info != null && (hs != null && info?.ssid != null || lanMode)

    Column(Modifier.fillMaxSize().background(LS.Bg).statusBarsPadding()) {
        TopBar("Envoyer", if (showQr) "Fais scanner ce code par l'autre téléphone" else "Étape 1 : active le point d'accès", onBack)
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            val i = info
            if (showQr && i != null) {
                val bmp = remember(i) { qr(i.toUri()) }
                Box(
                    Modifier.clip(RoundedCornerShape(28.dp)).background(Brush.linearGradient(listOf(LS.Blue, Color(0xFF7C3AED)))).padding(10.dp),
                ) {
                    Image(bmp.asImageBitmap(), "QR code", Modifier.size(240.dp).clip(RoundedCornerShape(20.dp)).background(Color.White))
                }
                if (hs != null && !lanMode) {
                    val h = hs!!
                    Row(
                        Modifier.clip(CircleShape).background(LS.Card).padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(SIc.Hotspot, null, Modifier.size(18.dp), tint = UpColor)
                        Spacer(Modifier.width(8.dp))
                        Text("« ${h.ssid} » · ${h.band}", color = LS.Text, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    }
                    Text(
                        "L'autre téléphone se connecte tout seul au point d'accès en scannant (Android demande juste de confirmer).",
                        color = LS.Muted, fontSize = 12.sp, textAlign = TextAlign.Center,
                    )
                } else {
                    Text("${i.host}:${i.port} · même Wi-Fi", color = LS.Text, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                }
                Radar(120.dp)
                Text("En attente de l'autre téléphone…", color = LS.Blue, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        {
                            clip.setText(AnnotatedString(i.toUri()))
                            Toast.makeText(ctx, "Lien copié", Toast.LENGTH_SHORT).show()
                        },
                        Modifier.weight(1f).height(50.dp), shape = RoundedCornerShape(16.dp),
                    ) { Icon(Ic.Copy, null, Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)); Text("Copier le lien") }
                    Button(
                        { stopAll() }, Modifier.weight(1f).height(50.dp), shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = LS.Blue, contentColor = LS.OnBlue),
                    ) { Icon(Ic.Stop, null, Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)); Text("Arrêter") }
                }
            } else {
                Spacer(Modifier.height(8.dp))
                Radar(170.dp)
                if (starting) {
                    CircularProgressIndicator(color = LS.Blue)
                    Text("Activation du point d'accès…", color = LS.Blue, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text("Wi-Fi Direct 5 GHz en priorité : le plus rapide", color = LS.Muted, fontSize = 12.sp)
                } else {
                    Text("Point d'accès désactivé", color = LS.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "Active le point d'accès de LinkShare : le code à scanner s'affichera. Aucun routeur ni réglage manuel.",
                        color = LS.Muted, fontSize = 13.sp, textAlign = TextAlign.Center,
                    )
                    err?.let {
                        NoticeCard(SIc.Error, Bad, "Point d'accès impossible", it)
                    }
                    if (locationOff) NoticeCard(Ic.Info, Warn, "Localisation désactivée", "Android l'exige pour créer un point d'accès sur ce téléphone.") {
                        TextButton({ Radio.openLocationSettings(ctx) }) { Text("Activer la localisation", color = LS.Blue) }
                    }
                    BigButton("Activer le point d'accès", SIc.Hotspot) { activate() }
                    TextButton({
                        if (!ensureAllFiles(ctx)) return@TextButton
                        lanMode = true; startService(false)
                    }) { Text("Déjà sur le même Wi-Fi ? Afficher le code sans point d'accès", color = LS.Blue, fontSize = 12.sp, textAlign = TextAlign.Center) }
                }
            }
        }
    }
}

// ═══════════════════════════════ RECEVOIR : préparer le Wi-Fi → scanner ═══════════════════════════════

/**
 * « Scanner » : si un point d'accès est encore actif, un bouton propose de le couper et de rallumer le Wi-Fi.
 * Le scan connecte tout de suite à l'autre téléphone.
 */
@Composable
private fun ReceiveContent(onBack: (() -> Unit)?, onConnect: (Connection) -> Unit) {
    val ctx = LocalContext.current
    val openWifi = rememberWifiOpener()
    val tick = AppEvents.resumeTick
    val ours by Hotspot.state.collectAsState()
    val info by ShareState.info.collectAsState()
    var poll by remember { mutableIntStateOf(0) }
    var linkDialog by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { while (true) { delay(1500); poll++ } }
    val wifi = remember(tick, poll) { Radio.wifiOn(ctx) }
    val system = remember(tick, poll, ours) { Radio.systemHotspotOn(ctx) }
    val oursOn = ours != null || info?.ssid != null
    val ready = !oursOn && !system && wifi
    val connecting = Session.connecting

    fun doScan() {
        if (!ensureAllFiles(ctx)) return
        scan(ctx) { onConnect(it) }
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { doScan() }
    fun scanNow() { if (needsNotifPermission(ctx)) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) else doScan() }

    // Tout est prêt dès l'ouverture : on lance directement l'appareil photo
    var autoDone by remember { mutableStateOf(false) }
    LaunchedEffect(ready) {
        if (ready && !autoDone && connecting == null) { autoDone = true; scanNow() }
    }

    Column(Modifier.fillMaxSize().background(LS.Bg).statusBarsPadding()) {
        TopBar("Scanner", "Recevoir et envoyer avec l'autre téléphone", onBack)
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            if (connecting != null) {
                Spacer(Modifier.height(30.dp))
                Radar(170.dp)
                CircularProgressIndicator(color = LS.Blue)
                Text(connecting, color = LS.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center)
                return@Column
            }
            Spacer(Modifier.height(6.dp))
            Box(
                Modifier.size(150.dp).clip(CircleShape).background(LS.Card),
                contentAlignment = Alignment.Center,
            ) { Icon(Ic.Scan, null, Modifier.size(72.dp), tint = LS.Blue) }

            when {
                oursOn -> NoticeCard(
                    SIc.Hotspot, Warn, "Ton point d'accès est activé",
                    "Pour scanner, il faut le couper et revenir sur le Wi-Fi.",
                ) {
                    BigButton("Désactiver le point d'accès et activer le Wi-Fi", SIc.Wifi) {
                        Hotspot.stop()
                        ctx.stopService(Intent(ctx, ShareService::class.java))
                        if (!Radio.wifiOn(ctx)) openWifi()
                        poll++
                    }
                }
                system -> NoticeCard(
                    SIc.Hotspot, Warn, "Le point d'accès du téléphone est activé",
                    "Coupe le partage de connexion, puis reviens ici : le Wi-Fi sera rallumé.",
                ) {
                    BigButton("Désactiver le point d'accès", SIc.Power) { Radio.openTetherSettings(ctx) }
                    if (!wifi) OutlinedButton({ openWifi() }, Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(16.dp)) {
                        Icon(SIc.Wifi, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text("Activer le Wi-Fi")
                    }
                }
                !wifi -> NoticeCard(SIc.Wifi, Warn, "Wi-Fi désactivé", "Le Wi-Fi doit être allumé pour rejoindre l'autre téléphone.") {
                    BigButton("Activer le Wi-Fi", SIc.Wifi) { openWifi() }
                }
                else -> {
                    Text("Prêt à scanner", color = LS.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "Scanne le code affiché sur l'autre téléphone : la connexion à son point d'accès est automatique.",
                        color = LS.Muted, fontSize = 13.sp, textAlign = TextAlign.Center,
                    )
                }
            }
            BigButton("Scanner le code", Ic.Scan, enabled = ready) { scanNow() }
            TextButton({ linkDialog = true }) { Text("Se connecter avec un lien", color = LS.Blue) }
        }
    }
    if (linkDialog) LinkDialog(onDismiss = { linkDialog = false }) { c -> linkDialog = false; if (ensureAllFiles(ctx)) onConnect(c) }
    WifiPopupHost()
}

// ═══════════════════════════════ SESSION CONNECTÉE ═══════════════════════════════

@Composable
fun SessionHost(vm: MainViewModel) {
    val ctx = LocalContext.current
    LaunchedEffect(vm.message) { vm.message?.let { Toast.makeText(ctx, it, Toast.LENGTH_SHORT).show(); vm.message = null } }
    when (Session.screen) {
        SessionScreen.PEERS -> PeersScreen(vm)
        SessionScreen.REMOTE -> RemoteScreen(vm)
        SessionScreen.LOCAL -> LocalScreen(vm)
        SessionScreen.TRANSFERS -> TransfersScreen()
    }
}

/** Après le scan : le nom de l'autre téléphone, puis moi, dans deux cartes. */
@Composable
fun PeersScreen(vm: MainViewModel) {
    var confirm by remember { mutableStateOf(false) }
    val up by TransferHub.up.collectAsState()
    val down by TransferHub.down.collectAsState()
    val info by ShareState.info.collectAsState()
    BackHandler { confirm = true }

    Column(Modifier.fillMaxSize().background(LS.Bg).statusBarsPadding()) {
        TopBar("Connecté", info?.ssid?.let { "Point d'accès « $it »" } ?: "Accès aux fichiers dans les deux sens", onBack = { confirm = true }) {
            IconButton({ confirm = true }) { Icon(SIc.Power, "Se déconnecter", tint = LS.Muted) }
        }
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(horizontal = 18.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            PeerCard(
                gradient = PeerGradient, icon = SIc.Phone, title = vm.deviceName.ifEmpty { "Autre téléphone" },
                badge = "Autre téléphone", text = "Toucher pour parcourir ses fichiers et les télécharger",
                stats = if (down.running > 0) "↓ ${down.percent} %" else null,
            ) { vm.open(""); Session.screen = SessionScreen.REMOTE }

            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Box(Modifier.size(42.dp).clip(CircleShape).background(LS.Card), contentAlignment = Alignment.Center) {
                    Icon(SIc.Swap, null, Modifier.size(22.dp), tint = LS.Blue)
                }
            }

            PeerCard(
                gradient = MeGradient, icon = Ic.Person, title = "Moi · ${Session.myName}",
                badge = "Ce téléphone", text = "Toucher pour choisir mes fichiers et les envoyer",
                stats = if (up.running > 0) "↑ ${up.percent} %" else null,
            ) { Session.screen = SessionScreen.LOCAL }

            TransfersSummaryCard(up, down) { openTransfers(SessionScreen.PEERS) }

            Text(
                "Tu peux recevoir et envoyer en même temps. Les transferts continuent écran éteint ou appli fermée.",
                color = LS.Muted, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(),
            )
            OutlinedButton({ confirm = true }, Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(16.dp)) {
                Icon(SIc.Power, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text("Se déconnecter")
            }
        }
    }

    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("Se déconnecter ?") },
        text = { Text(if (up.running + down.running > 0) "Les transferts en cours seront annulés." else "L'autre téléphone sera prévenu.") },
        confirmButton = { TextButton({ confirm = false; vm.disconnect() }) { Text("Se déconnecter") } },
        dismissButton = { TextButton({ confirm = false }) { Text("Rester") } },
    )
}

@Composable
private fun PeerCard(gradient: Brush, icon: ImageVector, title: String, badge: String, text: String, stats: String?, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().height(170.dp).clip(RoundedCornerShape(28.dp)).background(gradient).clickable(onClick = onClick),
    ) {
        // Cercles décoratifs
        Canvas(Modifier.matchParentSize()) {
            drawCircle(Color.White.copy(alpha = 0.10f), radius = size.height * 0.75f, center = Offset(size.width * 0.95f, size.height * 0.05f))
            drawCircle(Color.White.copy(alpha = 0.07f), radius = size.height * 0.45f, center = Offset(size.width * 0.75f, size.height * 1.05f))
        }
        Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(52.dp).clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = 0.2f)), contentAlignment = Alignment.Center) {
                    Icon(icon, null, Modifier.size(28.dp), tint = Color.White)
                }
                Spacer(Modifier.weight(1f))
                Text(
                    badge, Modifier.clip(CircleShape).background(Color.White.copy(alpha = 0.2f)).padding(horizontal = 12.dp, vertical = 5.dp),
                    color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold,
                )
            }
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(title, Modifier.weight(1f), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (stats != null) Text(stats, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Icon(Ic.Chevron, null, Modifier.size(26.dp), tint = Color.White)
                }
                Text(text, color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun TransfersSummaryCard(up: DirSummary, down: DirSummary, onClick: () -> Unit) {
    val ctx = LocalContext.current
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(LS.Card).clickable(onClick = onClick).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Ring(up.fraction, UpColor, if (up.running > 0) "${up.percent}%" else "↑", 54.dp)
        Spacer(Modifier.width(10.dp))
        Ring(down.fraction, DownColor, if (down.running > 0) "${down.percent}%" else "↓", 54.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text("Envoi et réception", color = LS.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            val line = when {
                up.running + down.running == 0 -> "Aucun transfert en cours"
                else -> "↑ ${Formatter.formatShortFileSize(ctx, up.speed)}/s   ↓ ${Formatter.formatShortFileSize(ctx, down.speed)}/s"
            }
            Text(line, color = LS.Muted, fontSize = 12.sp)
        }
        Icon(Ic.Chevron, null, Modifier.size(22.dp), tint = LS.Muted)
    }
}

@Composable
private fun Ring(fraction: Float, color: Color, label: String, size: Dp) {
    val anim by animateFloatAsState(fraction, tween(400), label = "ring")
    Box(Modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = 6.dp.toPx()
            drawArc(color.copy(alpha = 0.18f), 0f, 360f, false, style = Stroke(w))
            drawArc(color, -90f, 360f * anim, false, style = Stroke(w, cap = StrokeCap.Round))
        }
        Text(label, color = LS.Text, fontSize = if (label.length > 3) 12.sp else 16.sp, fontWeight = FontWeight.Bold)
    }
}

/** Petite barre en bas des écrans de fichiers : pourcentages en direct, toucher pour voir les transferts. */
@Composable
fun TransfersMini(from: SessionScreen) {
    val up by TransferHub.up.collectAsState()
    val down by TransferHub.down.collectAsState()
    AnimatedVisibility(up.running + down.running > 0) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp).clip(RoundedCornerShape(16.dp)).background(LS.Card)
                .clickable { openTransfers(from) }.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            if (up.running > 0) MiniBar("↑ ${up.percent} %", up.fraction, UpColor, Modifier.weight(1f))
            if (down.running > 0) MiniBar("↓ ${down.percent} %", down.fraction, DownColor, Modifier.weight(1f))
            Icon(Ic.Chevron, "Transferts", Modifier.size(18.dp), tint = LS.Muted)
        }
    }
}

@Composable
private fun MiniBar(label: String, fraction: Float, color: Color, modifier: Modifier) {
    Column(modifier) {
        Text(label, color = LS.Text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { fraction }, modifier = Modifier.fillMaxWidth().height(5.dp).clip(CircleShape),
            color = color, trackColor = color.copy(alpha = 0.18f),
        )
    }
}

// ═══════════════════════════════ MOI : mes fichiers à envoyer ═══════════════════════════════

@Composable
fun LocalScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) } // 0 fichiers, 1 applis
    var system by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    val granted = remember(AppEvents.resumeTick) { Environment.isExternalStorageManager() }
    LaunchedEffect(Unit) { if (vm.localEntries.isEmpty()) vm.openLocal(vm.localDir) }
    LaunchedEffect(tab) { if (tab == 1) vm.loadLocalApps() }

    val pickFiles = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { vm.sendUris(it) }
    val pickTree = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { it?.let(vm::sendTree) }

    fun back() {
        when {
            vm.localSel.isNotEmpty() || vm.localAppSel.isNotEmpty() -> { vm.localSel.clear(); vm.localAppSel.clear() }
            tab == 0 && vm.localUp() -> Unit
            else -> Session.screen = SessionScreen.PEERS
        }
    }
    BackHandler { back() }

    val n = vm.localSel.size + vm.localAppSel.size
    Column(Modifier.fillMaxSize().background(LS.Bg).statusBarsPadding()) {
        TopBar("Mes fichiers", "Envoyer à ${vm.deviceName}", onBack = { Session.screen = SessionScreen.PEERS })
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Seg(listOf("Fichiers", "Applis", "Autres"), tab) { tab = it }
            SearchField(query, if (tab == 1) "Rechercher une appli" else "Filtrer ce dossier") { query = it }
        }
        Spacer(Modifier.height(8.dp))
        Box(Modifier.weight(1f)) {
            when (tab) {
                0 -> if (granted) LocalFiles(vm, query) else NoAccess { ensureAllFiles(ctx) }
                1 -> LocalApps(vm, query, system) { system = it }
                else -> Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Choisis avec le sélecteur Android (photos, documents, cloud…)", color = LS.Muted, fontSize = 13.sp)
                    BigButton("Choisir des fichiers", Ic.Doc) { pickFiles.launch(arrayOf("*/*")) }
                    BigButton("Choisir un dossier", Ic.Folder) { pickTree.launch(null) }
                }
            }
        }
        TransfersMini(SessionScreen.LOCAL)
        Row(
            Modifier.fillMaxWidth().navigationBarsPadding().padding(12.dp).clip(RoundedCornerShape(22.dp)).background(LS.Card2)
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                if (n == 0) "Coche des fichiers, dossiers ou applis" else "$n élément(s) sélectionné(s)",
                Modifier.weight(1f), color = LS.Text, fontSize = 12.sp, fontWeight = FontWeight.Medium,
            )
            Button(
                { vm.sendLocalSelection() }, enabled = n > 0, shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = LS.Blue, contentColor = LS.OnBlue),
            ) { Icon(Ic.Send, null, Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)); Text("Envoyer") }
        }
    }
}

@Composable
private fun NoAccess(onFix: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        NoticeCard(Ic.Folder, Warn, "Accès aux fichiers nécessaire", "Autorise l'accès à tous les fichiers, ou utilise l'onglet « Autres ».")
        BigButton("Autoriser", Ic.Check) { onFix() }
    }
}

@Composable
private fun Seg(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(LS.Card).padding(4.dp)) {
        options.forEachIndexed { i, label ->
            val on = i == selected
            Box(
                Modifier.weight(1f).height(36.dp).clip(RoundedCornerShape(11.dp))
                    .background(if (on) LS.Blue else Color.Transparent).clickable { onSelect(i) },
                contentAlignment = Alignment.Center,
            ) { Text(label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = if (on) LS.OnBlue else LS.Muted) }
        }
    }
}

@Composable
private fun LocalFiles(vm: MainViewModel, query: String) {
    val ctx = LocalContext.current
    val root = vm.localRoot
    val shortcuts = remember {
        listOf(
            "Stockage" to root, "Appareil photo" to File(root, "DCIM"), "Téléchargements" to File(root, "Download"),
            "Images" to File(root, "Pictures"), "Vidéos" to File(root, "Movies"), "Musique" to File(root, "Music"),
            "Documents" to File(root, "Documents"),
        ).filter { it.second.isDirectory }
    }
    val q = query.trim()
    val list = vm.localEntries.filter { q.isEmpty() || it.name.contains(q, ignoreCase = true) }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        item(key = "shortcuts") {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(shortcuts, key = { it.second.path }) { (label, dir) ->
                    val on = vm.localDir.path == dir.path
                    Text(
                        label,
                        Modifier.clip(CircleShape).background(if (on) LS.Blue else LS.Card).clickable { vm.openLocal(dir) }
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        color = if (on) LS.OnBlue else LS.Text, fontSize = 12.sp, fontWeight = FontWeight.Medium,
                    )
                }
            }
        }
        if (vm.localDir.path != root.path) item(key = "up") {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { vm.localUp() }.padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Ic.Back, null, Modifier.size(20.dp), tint = LS.Blue)
                Spacer(Modifier.width(8.dp))
                Text("/" + vm.localDir.relativeTo(root).path, color = LS.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        if (list.isEmpty()) item(key = "empty") {
            Text("Dossier vide", Modifier.fillMaxWidth().padding(24.dp), color = LS.Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
        }
        items(list, key = { it.path }) { f ->
            val checked = f.path in vm.localSel
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(if (checked) LS.BlueLight else Color.Transparent)
                    .clickable { if (f.isDirectory) vm.openLocal(f) else vm.toggleLocal(f) }
                    .padding(start = 6.dp, top = 3.dp, bottom = 3.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(LS.Card), contentAlignment = Alignment.Center) {
                    val icon = if (f.isDirectory) Ic.Folder else f.category().let { if (it == Category.MORE) Ic.Doc else it.icon() }
                    Icon(icon, null, Modifier.size(22.dp), tint = if (f.isDirectory) LS.Blue else LS.Muted)
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(f.name, color = LS.Text, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(if (f.isDirectory) "Dossier · toucher pour ouvrir" else Formatter.formatShortFileSize(ctx, f.length()), color = LS.Muted, fontSize = 10.sp)
                }
                Checkbox(checked, { vm.toggleLocal(f) }, colors = CheckboxDefaults.colors(checkedColor = LS.Blue))
            }
        }
    }
}

@Composable
private fun LocalApps(vm: MainViewModel, query: String, system: Boolean, onSystem: (Boolean) -> Unit) {
    val ctx = LocalContext.current
    val pm = ctx.packageManager
    val q = query.trim()
    val list = vm.localApps.filter { (system || !it.system) && (q.isEmpty() || it.label.contains(q, ignoreCase = true)) }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        item(key = "sys") {
            Row(Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Switch(system, onSystem, colors = SwitchDefaults.colors(checkedTrackColor = LS.Blue))
                Spacer(Modifier.width(12.dp))
                Text("Afficher les applis système", color = LS.Text, fontSize = 13.sp)
            }
        }
        if (vm.localApps.isEmpty()) item(key = "load") {
            Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = LS.Blue) }
        }
        items(list, key = { it.info.packageName }) { a ->
            val pkg = a.info.packageName
            val checked = pkg in vm.localAppSel
            val icon by produceState<ImageBitmap?>(null, pkg) {
                value = withContext(Dispatchers.IO) {
                    runCatching { pm.getApplicationIcon(a.info).toBitmap(96, 96).asImageBitmap() }.getOrNull()
                }
            }
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(if (checked) LS.BlueLight else Color.Transparent)
                    .clickable { if (checked) vm.localAppSel.remove(pkg) else vm.localAppSel.add(pkg) }.padding(6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                val bmp = icon
                if (bmp != null) Image(bmp, null, Modifier.size(42.dp))
                else Box(Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(LS.Card), contentAlignment = Alignment.Center) {
                    Icon(Ic.Apps, null, Modifier.size(22.dp), tint = LS.Blue)
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(a.label, color = LS.Text, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(Formatter.formatShortFileSize(ctx, a.size), color = LS.Muted, fontSize = 10.sp)
                }
                Checkbox(checked, { on -> if (on) vm.localAppSel.add(pkg) else vm.localAppSel.remove(pkg) }, colors = CheckboxDefaults.colors(checkedColor = LS.Blue))
            }
        }
    }
}

// ═══════════════════════════════ TRANSFERTS : envoi et réception en même temps ═══════════════════════════════

@Composable
fun TransfersScreen() {
    val ctx = LocalContext.current
    val items by TransferHub.items.collectAsState()
    val up by TransferHub.up.collectAsState()
    val down by TransferHub.down.collectAsState()
    fun back() { Session.screen = SessionNav.back.takeIf { it != SessionScreen.TRANSFERS } ?: SessionScreen.PEERS }
    BackHandler { back() }

    val ups = items.filter { it.dir == Dir.UP }
    val downs = items.filter { it.dir == Dir.DOWN }

    Column(Modifier.fillMaxSize().background(LS.Bg).statusBarsPadding()) {
        TopBar("Transferts", "Avec ${Session.peerName}", onBack = { back() }) {
            if (items.any { it.state != XState.RUNNING }) TextButton({ TransferHub.clearFinished() }) { Text("Effacer", color = LS.Blue) }
        }
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item(key = "head") {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    DirCard("Envoi", "↑", up, UpColor, Modifier.weight(1f))
                    DirCard("Réception", "↓", down, DownColor, Modifier.weight(1f))
                }
            }
            item(key = "upTitle") { SectionLabel("Envoi vers ${Session.peerName}", ups.size, UpColor) }
            if (ups.isEmpty()) item(key = "upEmpty") { EmptyLine("Rien à envoyer pour l'instant") }
            items(ups, key = { "u" + it.key }) { XRow(it, UpColor) }
            item(key = "downTitle") { SectionLabel("Réception depuis ${Session.peerName}", downs.size, DownColor) }
            if (downs.isEmpty()) item(key = "downEmpty") { EmptyLine("Rien en réception pour l'instant") }
            items(downs, key = { "d" + it.key }) { XRow(it, DownColor) }
        }
        if (up.running + down.running > 0) {
            OutlinedButton(
                { TransferHub.cancelAll() },
                Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp).height(48.dp),
                shape = RoundedCornerShape(16.dp),
            ) { Icon(Ic.Close, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text("Tout annuler") }
        } else Spacer(Modifier.navigationBarsPadding())
    }
}

@Composable
private fun DirCard(title: String, arrow: String, s: DirSummary, color: Color, modifier: Modifier) {
    val ctx = LocalContext.current
    Column(
        modifier.clip(RoundedCornerShape(22.dp)).background(LS.Card).padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Ring(s.fraction, color, if (s.running > 0) "${s.percent}%" else arrow, 76.dp)
        Text(title, color = LS.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        Text(
            if (s.running > 0) "${Formatter.formatShortFileSize(ctx, s.speed)}/s · ${s.running} en cours" else "Inactif",
            color = LS.Muted, fontSize = 11.sp, textAlign = TextAlign.Center,
        )
    }
}

@Composable
private fun SectionLabel(text: String, count: Int, color: Color) {
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(8.dp))
        Text(text, Modifier.weight(1f), color = LS.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text("$count", color = LS.Muted, fontSize = 12.sp)
    }
}

@Composable
private fun EmptyLine(text: String) {
    Text(text, Modifier.fillMaxWidth().padding(vertical = 10.dp), color = LS.Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
}

private fun eta(sec: Long): String = when {
    sec < 60 -> "${sec} s"
    sec < 3600 -> "${sec / 60} min ${sec % 60} s"
    else -> "${sec / 3600} h ${(sec % 3600) / 60} min"
}

@Composable
private fun XRow(x: XView, color: Color) {
    val ctx = LocalContext.current
    fun size(b: Long) = Formatter.formatShortFileSize(ctx, b)
    val tint = when (x.state) {
        XState.RUNNING -> color
        XState.DONE -> UpColor
        XState.FAILED -> Bad
        XState.CANCELLED -> LS.Muted
    }
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(LS.Card).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(34.dp).clip(RoundedCornerShape(10.dp)).background(tint.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
                Icon(
                    when (x.state) {
                        XState.DONE -> Ic.Check
                        XState.FAILED -> SIc.Error
                        XState.CANCELLED -> Ic.Close
                        XState.RUNNING -> if (x.dir == Dir.UP) Ic.Up else Ic.Down
                    }, null, Modifier.size(18.dp), tint = tint,
                )
            }
            Spacer(Modifier.width(10.dp))
            Text(x.name, Modifier.weight(1f), color = LS.Text, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${x.percent} %", color = tint, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            if (x.state == XState.RUNNING) {
                Icon(
                    Ic.Close, "Annuler",
                    Modifier.padding(start = 6.dp).clip(CircleShape).clickable { TransferHub.cancel(x.key) }.padding(4.dp).size(18.dp),
                    tint = LS.Muted,
                )
            }
        }
        LinearProgressIndicator(
            progress = { x.fraction }, modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
            color = tint, trackColor = tint.copy(alpha = 0.16f),
        )
        val detail = when (x.state) {
            XState.RUNNING -> buildString {
                append(size(x.done)); if (x.total > 0) append(" / ").append(size(x.total))
                if (x.speed > 0) append(" · ").append(size(x.speed)).append("/s")
                x.etaSec?.let { append(" · ").append(eta(it)).append(" restantes") }
            }
            XState.DONE -> "Terminé · ${size(x.total.coerceAtLeast(x.done))}" +
                (if (x.elapsedMs > 0) " · ${size(x.done * 1000 / x.elapsedMs.coerceAtLeast(1))}/s en moyenne" else "") +
                if (x.dir == Dir.DOWN) " · Download/LinkShare" else ""
            XState.FAILED -> "Échec : ${x.error ?: "erreur"}"
            XState.CANCELLED -> "Annulé"
        }
        Text(detail, color = if (x.state == XState.FAILED) Bad else LS.Muted, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}
