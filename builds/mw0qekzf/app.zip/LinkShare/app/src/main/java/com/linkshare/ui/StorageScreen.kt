package com.linkshare.ui

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.content.ContextWrapper
import android.net.Uri
import android.os.Environment
import android.text.format.Formatter
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DateFormat
import java.util.Date

internal tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

private fun LItem.iconVec(): ImageVector = when {
    isDir -> Ic.Folder
    file.isArchive() -> Ic.Archive
    file.category() == Category.MORE -> Ic.Doc
    else -> file.category().icon()
}

private fun LItem.isPhoto() = !isDir && file.extension.lowercase() in VIEW_IMG

// ═══════════════════════════ Onglet Stockage ═══════════════════════════

@Composable
fun StorageTab() {
    val ctx = LocalContext.current
    val ex: ExplorerViewModel = viewModel()
    val granted = remember(AppEvents.resumeTick) { Environment.isExternalStorageManager() }
    var confirmDelete by remember { mutableStateOf(false) }

    LaunchedEffect(granted, AppEvents.resumeTick) { if (granted) ex.refresh() }
    LaunchedEffect(ex.message) { ex.message?.let { Toast.makeText(ctx, it, Toast.LENGTH_LONG).show(); ex.message = null } }

    // Coffre : déverrouillage par le verrouillage du téléphone (code, schéma, mot de passe, empreinte selon l'appareil)
    val authLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) { ex.selected.clear(); VaultLock.unlocked = true; ex.loadVault() }
    }
    fun openVault() {
        if (VaultLock.unlocked) { ex.loadVault(); return }
        val km = ctx.getSystemService(KeyguardManager::class.java)
        val intent = if (km.isDeviceSecure) km.createConfirmDeviceCredentialIntent("Coffre-fort", "Déverrouille ton téléphone pour ouvrir le coffre") else null
        if (intent == null) Toast.makeText(ctx, "Configure d'abord un verrouillage d'écran (code, schéma ou mot de passe)", Toast.LENGTH_LONG).show()
        else authLauncher.launch(intent)
    }

    // Scan de documents (recadrage auto, filtres, export PDF)
    val scanLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            GmsDocumentScanningResult.fromActivityResultIntent(r.data)?.pdf?.uri?.let { ex.saveScan(it) }
        }
    }
    fun scanDoc() {
        if (!ensureAllFiles(ctx)) return
        val act = ctx.findActivity() ?: return
        val opts = GmsDocumentScannerOptions.Builder()
            .setGalleryImportAllowed(true).setPageLimit(20)
            .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_PDF)
            .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL).build()
        GmsDocumentScanning.getClient(opts).getStartScanIntent(act)
            .addOnSuccessListener { scanLauncher.launch(IntentSenderRequest.Builder(it).build()) }
            .addOnFailureListener { Toast.makeText(ctx, "Scanner indisponible : ${it.message}", Toast.LENGTH_LONG).show() }
    }

    BackHandler(enabled = VaultLock.unlocked || ex.selected.isNotEmpty() || ex.canGoUp) {
        when {
            ex.selected.isNotEmpty() -> ex.selected.clear()
            VaultLock.unlocked -> ex.lockVault()
            else -> ex.up()
        }
    }

    if (VaultLock.unlocked) {
        VaultView(ex)
    } else {
        val tiles = listOf(
            ToolTile("Images", Ic.Image) { ex.openCategory(LCat.IMAGES) },
            ToolTile("Vidéos", Ic.Video) { ex.openCategory(LCat.VIDEOS) },
            ToolTile("Audio", Ic.Music) { ex.openCategory(LCat.AUDIO) },
            ToolTile("Docs", Ic.Doc) { ex.openCategory(LCat.DOCS) },
            ToolTile("Archives", Ic.Archive) { ex.openCategory(LCat.ARCHIVES) },
            ToolTile("Téléchargé", Ic.Download) { ex.openDir(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)) },
            ToolTile("Coffre-fort", Ic.Lock, highlight = true) { openVault() },
            ToolTile("Scanner", Ic.ScanDoc, highlight = true) { scanDoc() },
        )
        Box(Modifier.fillMaxSize()) {
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = if (ex.selected.isNotEmpty()) 84.dp else 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                item(key = "title") { Text("Stockage", color = LS.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
                item(key = "card") { StorageCard() }

                if (!granted) {
                    item(key = "perm") {
                        Column(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(LS.Card).padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Icon(Ic.Folder, null, Modifier.size(32.dp), tint = LS.Blue)
                            Text("L'explorateur a besoin de l'accès à tous les fichiers", color = LS.Text, fontSize = 13.sp, textAlign = TextAlign.Center)
                            Button({ ensureAllFiles(ctx) }, colors = ButtonDefaults.buttonColors(containerColor = LS.Blue)) { Text("Autoriser") }
                        }
                    }
                } else {
                    ex.busy?.let { b ->
                        item(key = "busy") {
                            Column {
                                Text(b, color = LS.Text, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Spacer(Modifier.height(4.dp))
                                LinearProgressIndicator(Modifier.fillMaxWidth(), color = LS.Blue)
                            }
                        }
                    }

                    // Tableau de bord : récents
                    if (ex.recents.isNotEmpty()) item(key = "recents") {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            SectionTitle("Récents")
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(ex.recents, key = { it.path }) { f -> RecentCard(f) { ex.open(f) } }
                            }
                        }
                    }

                    // Tableau de bord : catégories et outils
                    item(key = "tiles") {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            tiles.chunked(4).forEach { row ->
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    row.forEach { t -> ToolTileView(t, Modifier.weight(1f)) }
                                }
                            }
                        }
                    }

                    // Explorateur
                    item(key = "toolbar") {
                        Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("Explorateur", Modifier.weight(1f), color = LS.Text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                            var menu by remember { mutableStateOf(false) }
                            Box {
                                IconButton({ menu = true }) { Icon(Ic.Sort, "Trier", tint = LS.Blue) }
                                DropdownMenu(menu, { menu = false }) {
                                    SortKey.values().forEach { k ->
                                        DropdownMenuItem(
                                            text = { Text(k.label + if (ex.sort == k) "  ✓" else "") },
                                            onClick = { ex.changeSort(k); menu = false },
                                        )
                                    }
                                    HorizontalDivider()
                                    DropdownMenuItem(
                                        text = { Text(if (ex.ascending) "Passer en ordre décroissant" else "Passer en ordre croissant") },
                                        onClick = { ex.toggleOrder(); menu = false },
                                    )
                                }
                            }
                            IconButton({ ex.grid = !ex.grid }) {
                                Icon(if (ex.grid) Ic.ViewList else Ic.GridView, if (ex.grid) "Afficher en liste" else "Afficher en grille", tint = LS.Blue)
                            }
                        }
                    }
                    item(key = "search") {
                        SearchField(ex.query, "Rechercher un fichier ou dossier") { ex.updateQuery(it) }
                    }
                    item(key = "crumb") {
                        val cat = ex.category
                        val label = when {
                            ex.query.isNotBlank() -> "Résultats pour « ${ex.query.trim()} »"
                            cat != null -> cat.label
                            else -> "/" + runCatching { ex.dir.relativeTo(ex.root).path }.getOrDefault(ex.dir.path)
                        }
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                                .then(if (ex.canGoUp) Modifier.clickable { ex.up() } else Modifier).padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            if (ex.canGoUp) { Icon(Ic.Back, "Dossier parent", Modifier.size(20.dp), tint = LS.Blue); Spacer(Modifier.width(4.dp)) }
                            Text(label, Modifier.weight(1f), color = LS.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (ex.loading) CircularProgressIndicator(Modifier.size(14.dp), color = LS.Blue, strokeWidth = 2.dp)
                        }
                    }

                    val dirs = ex.items.filter { it.isDir }
                    val files = ex.items.filter { !it.isDir }
                    if (!ex.loading && ex.items.isEmpty()) item(key = "empty") {
                        Text("Aucun élément", Modifier.fillMaxWidth().padding(24.dp), color = LS.Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
                    }
                    if (ex.grid) {
                        dirs.chunked(3).forEach { row ->
                            item(key = "g_" + row.first().file.path) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    row.forEach { d -> FolderCell(d, ex, Modifier.weight(1f)) }
                                    repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                                }
                            }
                        }
                    } else {
                        items(dirs, key = { it.file.path }) { d -> FileRow(d, ex) }
                    }
                    items(files, key = { it.file.path }) { f -> FileRow(f, ex) }
                }
            }

            if (ex.selected.isNotEmpty()) {
                SelectionBar(
                    ex.selected.size,
                    listOf(
                        BarAction("Tout", Ic.Check) { ex.selectAll(ex.items) },
                        BarAction("Zip", Ic.Archive) { ex.compressSelected() },
                        BarAction("Coffre", Ic.Lock) { ex.moveToVault() },
                        BarAction("Suppr.", Ic.Delete) { confirmDelete = true },
                        BarAction("Annuler", Ic.Close) { ex.selected.clear() },
                    ),
                    Modifier.align(Alignment.BottomCenter),
                )
            }
        }
    }

    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("Supprimer ?") },
        text = { Text("${ex.selected.size} élément(s) seront supprimés définitivement.") },
        confirmButton = { TextButton({ confirmDelete = false; if (VaultLock.unlocked) ex.deleteFromVault() else ex.deleteSelected() }) { Text("Supprimer") } },
        dismissButton = { TextButton({ confirmDelete = false }) { Text("Annuler") } },
    )

    ex.zipPrompt?.let { z ->
        AlertDialog(
            onDismissRequest = { ex.zipPrompt = null },
            title = { Text(z.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            text = { Text("Décompresser cette archive dans un nouveau dossier ?") },
            confirmButton = { TextButton({ ex.zipPrompt = null; ex.extract(z) }) { Text("Décompresser") } },
            dismissButton = { TextButton({ ex.zipPrompt = null; ex.external(z) }) { Text("Ouvrir avec…") } },
        )
    }
}

// ═══════════════════════════ Composants ═══════════════════════════

private class ToolTile(val label: String, val icon: ImageVector, val highlight: Boolean = false, val onClick: () -> Unit)

@Composable
private fun ToolTileView(t: ToolTile, modifier: Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(14.dp)).background(if (t.highlight) LS.BlueLight else LS.Card)
            .clickable(onClick = t.onClick).padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(t.icon, null, Modifier.size(24.dp), tint = LS.Blue)
        Spacer(Modifier.height(4.dp))
        Text(t.label, fontSize = 10.sp, color = LS.Text, maxLines = 1)
    }
}

@Composable
private fun RecentCard(f: File, onClick: () -> Unit) {
    val photo = f.extension.lowercase() in VIEW_IMG
    Column(Modifier.width(84.dp).clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(84.dp).clip(RoundedCornerShape(14.dp)).background(LS.Card), contentAlignment = Alignment.Center) {
            if (photo) AsyncImage(f, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else Icon(LItem(f, false, 0, 0, 0).iconVec(), null, Modifier.size(30.dp), tint = LS.Blue)
        }
        Text(f.name, Modifier.padding(top = 4.dp), color = LS.Text, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun Thumb(item: LItem, size: Dp = 40.dp) {
    Box(Modifier.size(size).clip(RoundedCornerShape(10.dp)).background(LS.Card), contentAlignment = Alignment.Center) {
        if (item.isPhoto()) AsyncImage(item.file, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(item.iconVec(), null, Modifier.size(size / 2), tint = if (item.isDir) LS.Blue else LS.Muted)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FileRow(item: LItem, ex: ExplorerViewModel) {
    val ctx = LocalContext.current
    val f = item.file
    val sel = f.path in ex.selected
    val showParent = ex.query.isNotBlank() || ex.category != null
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(if (sel) LS.BlueLight else Color.Transparent)
            .combinedClickable(
                onClick = { if (ex.selected.isNotEmpty()) ex.toggle(f.path) else ex.open(f) },
                onLongClick = { ex.toggle(f.path) },
            ).padding(4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Thumb(item)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(f.name, color = LS.Text, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val sub = if (item.isDir) "${item.count} élément(s)"
            else Formatter.formatShortFileSize(ctx, item.size) + " · " + DateFormat.getDateInstance(DateFormat.SHORT).format(Date(item.modified))
            Text(
                if (showParent) sub + " · " + (f.parentFile?.name ?: "") else sub,
                color = LS.Muted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
        if (sel) Icon(Ic.Check, null, Modifier.padding(end = 8.dp).size(20.dp), tint = LS.Blue)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FolderCell(item: LItem, ex: ExplorerViewModel, modifier: Modifier) {
    val f = item.file
    val sel = f.path in ex.selected
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier.clip(shape).background(if (sel) LS.BlueLight else LS.Card)
            .then(if (sel) Modifier.border(1.5.dp, LS.Blue, shape) else Modifier)
            .combinedClickable(
                onClick = { if (ex.selected.isNotEmpty()) ex.toggle(f.path) else ex.open(f) },
                onLongClick = { ex.toggle(f.path) },
            ).padding(12.dp),
    ) {
        Icon(Ic.Folder, null, Modifier.size(30.dp), tint = LS.Blue)
        Spacer(Modifier.height(6.dp))
        Text(f.name, color = LS.Text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Text("${item.count} élément(s)", color = LS.Muted, fontSize = 10.sp)
    }
}

private class BarAction(val label: String, val icon: ImageVector, val onClick: () -> Unit)

@Composable
private fun SelectionBar(count: Int, actions: List<BarAction>, modifier: Modifier) {
    Row(
        modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp).clip(RoundedCornerShape(22.dp))
            .background(LS.Blue).padding(horizontal = 10.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("$count", Modifier.padding(horizontal = 8.dp), color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        actions.forEach { a ->
            Column(
                Modifier.clip(RoundedCornerShape(10.dp)).clickable(onClick = a.onClick).padding(horizontal = 8.dp, vertical = 2.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Icon(a.icon, a.label, Modifier.size(20.dp), tint = Color.White)
                Text(a.label, color = Color.White, fontSize = 9.sp)
            }
        }
    }
}

// ═══════════════════════════ Coffre-fort ═══════════════════════════

@Composable
private fun VaultView(ex: ExplorerViewModel) {
    var confirm by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { ex.loadVault() }
    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = if (ex.selected.isNotEmpty()) 84.dp else 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item(key = "vtitle") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton({ ex.lockVault() }) { Icon(Ic.Back, "Verrouiller", tint = LS.Blue) }
                    Text("Coffre-fort", Modifier.weight(1f), color = LS.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Icon(Ic.Lock, null, Modifier.size(22.dp), tint = LS.Blue)
                }
            }
            item(key = "vinfo") {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(LS.BlueLight).padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Ic.Info, null, Modifier.size(18.dp), tint = LS.Blue)
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "Ajoute des fichiers depuis l'explorateur : appui long, puis « Coffre ». " +
                            "Ils sont rangés dans l'espace privé de l'appli, invisibles aux autres apps et gestionnaires de fichiers. " +
                            "Désinstaller LinkShare les supprime : restaure-les avant.",
                        color = LS.Text, fontSize = 11.sp,
                    )
                }
            }
            ex.busy?.let { b -> item(key = "vbusy") { Column { Text(b, color = LS.Text, fontSize = 11.sp); LinearProgressIndicator(Modifier.fillMaxWidth(), color = LS.Blue) } } }
            if (ex.vaultItems.isEmpty()) item(key = "vempty") {
                Text("Le coffre est vide", Modifier.fillMaxWidth().padding(24.dp), color = LS.Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
            }
            items(ex.vaultItems, key = { it.file.path }) { FileRow(it, ex) }
        }
        if (ex.selected.isNotEmpty()) {
            SelectionBar(
                ex.selected.size,
                listOf(
                    BarAction("Restaurer", Ic.Up) { ex.restoreFromVault() },
                    BarAction("Suppr.", Ic.Delete) { confirm = true },
                    BarAction("Annuler", Ic.Close) { ex.selected.clear() },
                ),
                Modifier.align(Alignment.BottomCenter),
            )
        }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("Supprimer du coffre ?") },
        text = { Text("${ex.selected.size} élément(s) seront supprimés définitivement.") },
        confirmButton = { TextButton({ confirm = false; ex.deleteFromVault() }) { Text("Supprimer") } },
        dismissButton = { TextButton({ confirm = false }) { Text("Annuler") } },
    )
}

// ═══════════════════════════ Lecteur local ═══════════════════════════

@Composable
fun LocalViewerScreen(ex: ExplorerViewModel) {
    val f = ex.viewing ?: return
    val e = f.extension.lowercase()
    BackHandler { ex.viewing = null }
    Column(Modifier.fillMaxSize().background(LS.Bg).systemBarsPadding()) {
        Row(Modifier.padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ ex.viewing = null }) { Icon(Ic.Back, "Retour", tint = LS.Blue) }
            Text(f.name, color = LS.Blue, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        when {
            e in VIEW_IMG -> AsyncImage(f, f.name, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            e in VIEW_TXT -> TextViewer(f)
            else -> Player(Uri.fromFile(f).toString())
        }
    }
}

@Composable
private fun TextViewer(f: File) {
    val text by produceState("Chargement…", f) {
        value = withContext(Dispatchers.IO) {
            try {
                f.bufferedReader().use { r ->
                    val buf = CharArray(300_000)
                    val n = r.read(buf)
                    (if (n > 0) String(buf, 0, n) else "") + if (f.length() > 600_000) "\n\n… (aperçu limité)" else ""
                }
            } catch (e: Exception) { "Lecture impossible : ${e.message}" }
        }
    }
    SelectionContainer {
        Text(
            text, Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            color = LS.Text, fontSize = 12.sp, fontFamily = FontFamily.Monospace,
        )
    }
}
