package com.linkshare

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.material3.*
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import android.app.NotificationManager
import com.linkshare.client.TransferManager
import com.linkshare.client.TransferNotifier
import com.linkshare.ui.AppEvents
import com.linkshare.ui.LS
import com.linkshare.ui.VaultLock
import com.linkshare.ui.LinkShareApp
import com.linkshare.ui.MainViewModel

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onStart() {
        super.onStart()
        TransferManager.appVisible = true
        AppEvents.resumeTick += 1
        getSystemService(NotificationManager::class.java).cancel(TransferNotifier.ID)
    }

    override fun onStop() {
        super.onStop()
        TransferManager.appVisible = false
        VaultLock.unlocked = false // le coffre se reverrouille dès que l'app quitte l'écran
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = LS.Blue, onPrimary = androidx.compose.ui.graphics.Color.White,
                    background = LS.Bg, surface = LS.Bg, onSurface = LS.Text,
                ),
            ) {
                Surface(color = LS.Bg) { LinkShareApp(vm) }
            }
        }
    }
}
