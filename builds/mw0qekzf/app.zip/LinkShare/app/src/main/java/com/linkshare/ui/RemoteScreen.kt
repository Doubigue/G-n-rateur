package com.linkshare.ui

import android.text.format.Formatter
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateMap
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.linkshare.core.*

@Composable
fun RemoteScreen(vm: MainViewModel) {
    var mode by remember { mutableStateOf(1) } // 0 = récents, 1 = dossiers, 2 = apps
    var query by remember { mutableStateOf("") }
    var system by remember { mutableStateOf(false) }
    val collapsed = remember { mutableStateMapOf<String, Boolean>() }
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(vm.message) { vm.message?.let { snack.showSnackbar(it); vm.message = null } }
    LaunchedEffect(mode) { if (mode == 2) vm.loadApps() }

    BackHandler {
        when {
            vm.selection.isNotEmpty() -> vm.selection.clear()
            mode == 1 && vm.path.isNotEmpty() -> vm.up()
            else -> Session.screen = SessionScreen.PEERS
        }
    }

    val pickFiles = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { vm.uploadFiles(it) }
    val pickTree = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { it?.let(vm::uploadFolder) }

    Box(Modifier.fillMaxSize().background(LS.Bg)) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            // En-tête : retour + titre centré
            Box(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), contentAlignment = Alignment.Center) {
                IconButton({ Session.screen = SessionScreen.PEERS }, Modifier.align(Alignment.CenterStart)) { Icon(Ic.Back, "Retour aux téléphones", tint = LS.Blue) }
                Text(vm.deviceName, color = LS.Blue, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(horizontal = 52.dp))
            }

            Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                SearchField(query, if (mode == 2) "Rechercher une application" else "Rechercher dans ${vm.deviceName}") { query = it }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Category.values().forEach { c ->
                        CategoryTile(c, selected = vm.category == c) {
                            vm.category = if (vm.category == c) null else c
                            if (mode == 2) mode = 1
                        }
                    }
                }

                Segmented(listOf("Récents", "Dossiers", "Apps"), mode) { mode = it }

                vm.status?.let {
                    Column {
                        Text(it, color = LS.Text, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Spacer(Modifier.height(4.dp))
                        LinearProgressIndicator(Modifier.fillMaxWidth(), color = LS.Blue)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))

            Box(Modifier.weight(1f)) {
                if (mode == 2) AppsList(vm, query, system) { system = it }
                else FilesList(vm, mode == 0, query, collapsed)
            }

            TransfersMini(SessionScreen.REMOTE)
            BottomBar(vm, onFiles = { Session.screen = SessionScreen.LOCAL }, onFolder = { SessionNav.back = SessionScreen.REMOTE; Session.screen = SessionScreen.TRANSFERS })
        }
        SnackbarHost(snack, Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 84.dp))
    }
}

@Composable
internal fun SearchField(value: String, placeholder: String, onChange: (String) -> Unit) {
    TextField(
        value = value, onValueChange = onChange, singleLine = true,
        placeholder = { Text(placeholder, fontSize = 13.sp, color = LS.Muted) },
        leadingIcon = { Icon(Ic.Search, null, Modifier.size(18.dp), tint = LS.Muted) },
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth(),
        colors = TextFieldDefaults.colors(
            focusedContainerColor = LS.Card, unfocusedContainerColor = LS.Card,
            focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
            cursorColor = LS.Blue,
        ),
    )
}

@Composable
private fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val shape = RoundedCornerShape(8.dp)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEachIndexed { i, label ->
            val on = i == selected
            Box(
                Modifier.weight(1f).height(36.dp).clip(shape)
                    .then(if (on) Modifier.background(LS.Blue) else Modifier.border(1.dp, LS.Blue, shape))
                    .clickable { onSelect(i) },
                contentAlignment = Alignment.Center,
            ) { Text(label, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = if (on) Color.White else LS.Blue) }
        }
    }
}

// ───────────────────────── Liste de fichiers groupée ─────────────────────────

@Composable
private fun FilesList(vm: MainViewModel, recents: Boolean, query: String, collapsed: SnapshotStateMap<String, Boolean>) {
    val q = query.trim()
    val cat = vm.category
    val base = vm.entries.filter { q.isEmpty() || it.name.contains(q, ignoreCase = true) }
    val groups: List<Pair<String, List<FileEntry>>> = (
        if (recents) {
            listOf("Récents" to base.filter { !it.isDir && (cat == null || it.category() == cat) }.sortedByDescending { it.modified })
        } else {
            val files = base.filter { !it.isDir && (cat == null || it.category() == cat) }
            listOf("Dossiers" to base.filter { it.isDir }) + Category.values().map { c -> c.group to files.filter { it.category() == c } }
        }
    ).filter { it.second.isNotEmpty() }

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 2.dp, bottom = 12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        if (!recents && vm.path.isNotEmpty()) item(key = "up") {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { vm.up() }.padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Ic.Back, null, Modifier.size(20.dp), tint = LS.Blue)
                Spacer(Modifier.width(8.dp))
                Text("/" + vm.path, color = LS.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        if (groups.isEmpty()) item(key = "empty") {
            Text("Aucun élément", Modifier.fillMaxWidth().padding(24.dp), color = LS.Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
        }
        groups.forEach { (title, list) ->
            val open = collapsed[title] != true
            item(key = "h_$title") {
                val paths = list.map { it.path }
                val all = paths.all { it in vm.selection }
                GroupHeader(title, list.size, open, all, onToggle = { collapsed[title] = open }, onCheck = {
                    if (all) vm.selection.removeAll(paths) else paths.forEach { p -> if (p !in vm.selection) vm.selection.add(p) }
                })
            }
            if (open) items(list, key = { it.path }) { e -> EntryRow(vm, e) }
        }
    }
}

@Composable
private fun GroupHeader(title: String, count: Int, open: Boolean, allChecked: Boolean, onToggle: () -> Unit, onCheck: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(LS.Card).clickable(onClick = onToggle)
            .padding(start = 12.dp, top = 2.dp, bottom = 2.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(if (open) Ic.Expand else Ic.Chevron, null, Modifier.size(20.dp), tint = LS.Text)
        Spacer(Modifier.width(6.dp))
        Text("$title ", color = LS.Text, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        Text("($count)", color = LS.Muted, fontSize = 11.sp, modifier = Modifier.weight(1f))
        Checkbox(allChecked, { onCheck() }, colors = CheckboxDefaults.colors(checkedColor = LS.Blue))
    }
}

@Composable
private fun EntryRow(vm: MainViewModel, e: FileEntry) {
    val ctx = LocalContext.current
    val checked = e.path in vm.selection
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { vm.tap(e) }.padding(start = 4.dp, top = 2.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(40.dp).clip(RoundedCornerShape(10.dp)).background(LS.Card), contentAlignment = Alignment.Center) {
            Icon(e.icon(), null, Modifier.size(20.dp), tint = if (e.isDir) LS.Blue else LS.Muted)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(e.name, color = LS.Text, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(if (e.isDir) "Dossier" else Formatter.formatShortFileSize(ctx, e.size), color = LS.Muted, fontSize = 10.sp)
        }
        Checkbox(
            checked, { on -> if (on) vm.selection.add(e.path) else vm.selection.remove(e.path) },
            colors = CheckboxDefaults.colors(checkedColor = LS.Blue),
        )
    }
}

// ───────────────────────────── Applications ─────────────────────────────

@Composable
private fun AppsList(vm: MainViewModel, query: String, system: Boolean, onSystem: (Boolean) -> Unit) {
    val ctx = LocalContext.current
    val q = query.trim()
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 2.dp, bottom = 12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        item(key = "sys") {
            Row(Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Switch(system, onSystem, colors = SwitchDefaults.colors(checkedTrackColor = LS.Blue))
                Spacer(Modifier.width(12.dp))
                Text("Afficher les apps système", color = LS.Text, fontSize = 13.sp)
            }
        }
        items(vm.apps.filter { (system || !it.isSystem) && (q.isEmpty() || it.name.contains(q, ignoreCase = true)) }, key = { it.pkg }) { a ->
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { vm.downloadApp(a) }.padding(4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                AsyncImage(vm.client?.iconUrl(a.pkg), null, Modifier.size(40.dp))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(a.name, color = LS.Text, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        "${a.version} · ${Formatter.formatShortFileSize(ctx, a.size)}" + if (a.split) " · .apks" else "",
                        color = LS.Muted, fontSize = 10.sp,
                    )
                }
                Icon(Ic.Download, "Télécharger", Modifier.size(20.dp), tint = LS.Blue)
                Spacer(Modifier.width(8.dp))
            }
        }
    }
}

// ───────────────────────── Barre bleue du bas ─────────────────────────

@Composable
private fun BottomBar(vm: MainViewModel, onFiles: () -> Unit, onFolder: () -> Unit) {
    val n = vm.selection.size
    val white = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = LS.Blue)
    val shape = RoundedCornerShape(12.dp)
    Box(Modifier.fillMaxWidth().navigationBarsPadding().padding(start = 12.dp, end = 12.dp, bottom = 8.dp, top = 4.dp)) {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(LS.Blue).padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (n > 0) {
                Text(
                    if (n == 1) "1 élément sélectionné" else "$n éléments sélectionnés",
                    Modifier.weight(1f), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium,
                )
                Button({ vm.downloadSelected() }, shape = shape, colors = white) { Text("Télécharger", fontSize = 13.sp) }
            } else {
                Button(onFiles, Modifier.weight(1f), shape = shape, colors = white, contentPadding = PaddingValues(horizontal = 8.dp)) {
                    Text("Envoyer mes fichiers", fontSize = 13.sp, maxLines = 1)
                }
                Button(onFolder, Modifier.weight(1f), shape = shape, colors = white, contentPadding = PaddingValues(horizontal = 8.dp)) {
                    Text("Transferts", fontSize = 13.sp, maxLines = 1)
                }
            }
        }
    }
}
