package com.linkshare.core

import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.EOFException
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.io.RandomAccessFile
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.nio.channels.ServerSocketChannel
import java.nio.channels.SocketChannel
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicLong
import kotlin.concurrent.thread
import kotlin.math.min

/*
 * ════════════════════ Voie rapide ════════════════════
 * Le HTTP (Ktor) sert à parcourir, afficher les miniatures et lire en streaming.
 * Les fichiers, eux, passent par un protocole TCP minimal, bien plus rapide :
 *  - côté envoi, FileChannel.transferTo → sendfile() du noyau : aucune copie dans l'appli ;
 *  - tampons de socket de 4 Mo (le Wi-Fi a beaucoup de latence, il faut beaucoup de données « en vol ») ;
 *  - les gros fichiers sont coupés en 4 morceaux envoyés en parallèle sur 4 connexions ;
 *  - plusieurs fichiers partent en même temps (6 connexions au total au maximum).
 *
 * Trame : [int32 longueur][en-tête JSON] puis
 *  get → le serveur répond [int64 taille du fichier][int64 octets qui suivent][données]
 *  put → le client envoie les données, le serveur répond 1 octet (0 = OK).
 */

private const val SOCK_BUF = 4 * 1024 * 1024
private const val CHUNK = 8L * 1024 * 1024
/** À partir de cette taille, un fichier est coupé en morceaux parallèles. */
private const val PARALLEL_MIN = 16L * 1024 * 1024
private const val PARTS = 4

private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

@Serializable
internal data class FastReq(
    val t: String,
    val op: String,
    val path: String = "",
    val name: String = "",
    val off: Long = 0,
    val len: Long = -1,
    val total: Long = -1,
    val id: String = "",
    val app: Boolean = false,
    /** Lot (dossier, sélection) : le transfert est affiché comme une seule ligne des deux côtés. */
    val gid: String = "",
    val gname: String = "",
    val gtotal: Long = -1,
    val from: String = "",
)

/** Lot affiché comme une seule ligne (un fichier, un dossier entier ou une appli). */
data class Group(val id: String, val name: String, val total: Long)

private fun tune(s: Socket) {
    runCatching { s.sendBufferSize = SOCK_BUF }
    runCatching { s.receiveBufferSize = SOCK_BUF }
    runCatching { s.tcpNoDelay = true }
    runCatching { s.keepAlive = true }
    runCatching { s.trafficClass = 0x10 } // IPTOS_LOWDELAY : priorité au Wi-Fi « vidéo/voix » sur certains routeurs
}

private fun SocketChannel.readFully(b: ByteBuffer) {
    while (b.hasRemaining()) if (read(b) < 0) throw EOFException("Connexion fermée")
}

private fun SocketChannel.writeFully(b: ByteBuffer) {
    while (b.hasRemaining()) write(b)
}

private fun longs(a: Long, b: Long): ByteBuffer {
    val buf = ByteBuffer.allocate(16)
    buf.putLong(a); buf.putLong(b); buf.flip()
    return buf
}

private fun SocketChannel.sendHeader(r: FastReq) {
    val bytes = json.encodeToString(r).toByteArray()
    val b = ByteBuffer.allocate(4 + bytes.size).putInt(bytes.size).put(bytes)
    b.flip(); writeFully(b)
}

/** Dossier de réception commun : Download/LinkShare. */
fun receiveDir(): File =
    File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "LinkShare").apply { mkdirs() }

/** « photo.jpg » existe déjà → « photo (1).jpg ». */
fun uniqueFile(f: File): File {
    fun free(c: File) = !c.exists() && !File(c.parentFile, c.name + ".lspart").exists()
    if (free(f)) return f
    val base = f.nameWithoutExtension
    val ext = f.extension.let { if (it.isEmpty()) "" else ".$it" }
    var i = 1
    while (true) {
        val c = File(f.parentFile, "$base ($i)$ext")
        if (free(c)) return c
        i++
    }
}

private fun scanMedia(ctx: Context, f: File) {
    runCatching { MediaScannerConnection.scanFile(ctx, arrayOf(f.path), null, null) }
}

// ═══════════════════════════════ Serveur ═══════════════════════════════

class FastServer(private val ctx: Context, private val port: Int = FAST_PORT) {
    private val root = SharedRoot(Environment.getExternalStorageDirectory())
    private var ss: ServerSocketChannel? = null
    private val pool = Executors.newCachedThreadPool { r -> Thread(r, "fastlane").apply { isDaemon = true } }

    /** Fichiers reçus en morceaux : chaque morceau écrit à sa place dans « nom.lspart », renommé à la fin. */
    private class Incoming(val part: File, val final: File, val total: Long) { val got = AtomicLong(0) }
    private val incoming = ConcurrentHashMap<String, Incoming>()

    fun start() {
        val s = ServerSocketChannel.open()
        s.socket().reuseAddress = true
        runCatching { s.socket().receiveBufferSize = SOCK_BUF }
        s.socket().bind(InetSocketAddress(port), 32)
        ss = s
        thread(name = "fastlane-accept", isDaemon = true) {
            while (s.isOpen) {
                val ch = try { s.accept() } catch (e: Exception) { break }
                pool.execute { handle(ch) }
            }
        }
    }

    fun stop() {
        runCatching { ss?.close() }
        ss = null
        pool.shutdownNow()
    }

    private fun handle(ch: SocketChannel) {
        try {
            ch.use {
                tune(ch.socket())
                val lenBuf = ByteBuffer.allocate(4); ch.readFully(lenBuf); lenBuf.flip()
                val n = lenBuf.int
                if (n <= 0 || n > 64 * 1024) return
                val hb = ByteBuffer.allocate(n); ch.readFully(hb)
                val req = runCatching { json.decodeFromString<FastReq>(String(hb.array())) }.getOrNull() ?: return
                val token = ShareState.token
                if (!ShareState.open || token.isEmpty() || !MessageDigest.isEqual(req.t.toByteArray(), token.toByteArray())) {
                    ch.writeFully(longs(-401, 0))
                    return
                }
                when (req.op) {
                    "get" -> serveGet(ch, req)
                    "put" -> servePut(ch, req)
                }
            }
        } catch (_: Exception) {
            // connexion coupée : la fiche du transfert est marquée en échec plus bas
        }
    }

    private fun appPaths(): Set<String> {
        val pm = ctx.packageManager
        return pm.getInstalledApplications(0).flatMap { ai ->
            listOf(ai.sourceDir) + (ai.splitSourceDirs?.toList() ?: emptyList())
        }.toSet()
    }

    private fun tracker(req: FastReq, fallbackName: String, fallbackTotal: Long, dir: Dir): Xfer {
        val key = "srv:" + req.gid.ifEmpty { req.id.ifEmpty { UUID.randomUUID().toString() } }
        val name = req.gname.ifEmpty { fallbackName }
        val total = if (req.gtotal > 0) req.gtotal else fallbackTotal
        return TransferHub.track(key, name, dir, total, req.from.ifEmpty { Session.peerName }, autoFinish = true)
    }

    private fun serveGet(ch: SocketChannel, req: FastReq) {
        val f: File? = if (req.app) File(req.path).takeIf { it.isFile && req.path in appPaths() }
        else root.resolve(req.path)?.takeIf { it.isFile }
        if (f == null) {
            ch.writeFully(longs(-404, 0))
            return
        }
        val size = f.length()
        val off = req.off.coerceIn(0, size)
        val len = if (req.len < 0) size - off else min(req.len, size - off)
        ch.writeFully(longs(size, len))
        val x = tracker(req, f.name, size, Dir.UP)
        x.canceller = { runCatching { ch.close() } }
        try {
            FileInputStream(f).channel.use { fc ->
                var pos = off
                val end = off + len
                while (pos < end) {
                    val sent = fc.transferTo(pos, min(CHUNK, end - pos), ch)
                    if (sent <= 0) throw IOException("Envoi interrompu")
                    pos += sent; x.add(sent)
                }
            }
        } catch (e: Exception) {
            if (x.state == XState.RUNNING) x.fail(e.message ?: "Connexion perdue")
            throw e
        }
    }

    private fun servePut(ch: SocketChannel, req: FastReq) {
        val uploads = SharedRoot(receiveDir())
        val key = req.id.ifEmpty { UUID.randomUUID().toString() } + "|" + req.name
        val inc = synchronized(incoming) {
            incoming.getOrPut(key) {
                val dest = uploads.resolve(req.name)?.takeIf { it != uploads.dir } ?: throw IOException("Nom invalide")
                dest.parentFile?.mkdirs()
                val final = uniqueFile(dest)
                Incoming(File(final.parentFile, final.name + ".lspart"), final, req.total)
            }
        }
        val x = tracker(req, inc.final.name, req.total, Dir.DOWN)
        x.canceller = { runCatching { ch.close() } }
        var received = 0L
        try {
            RandomAccessFile(inc.part, "rw").use { raf ->
                if (req.total > 0 && raf.length() < req.total) raf.setLength(req.total)
                val fc = raf.channel
                val buf = ByteBuffer.allocateDirect(BUF)
                var pos = req.off
                var remaining = req.len
                while (remaining != 0L) {
                    buf.clear()
                    if (remaining in 1 until buf.capacity()) buf.limit(remaining.toInt())
                    val n = ch.read(buf)
                    if (n < 0) { if (req.len < 0) break else throw EOFException("Envoi interrompu") }
                    buf.flip()
                    while (buf.hasRemaining()) pos += fc.write(buf, pos)
                    if (remaining > 0) remaining -= n
                    received += n; x.add(n.toLong())
                }
            }
        } catch (e: Exception) {
            if (x.state == XState.RUNNING) x.fail(e.message ?: "Connexion perdue")
            incoming.remove(key)
            throw e
        }
        val all = inc.got.addAndGet(received)
        if (req.len < 0 || (inc.total >= 0 && all >= inc.total)) {
            incoming.remove(key)
            if (req.len < 0) RandomAccessFile(inc.part, "rw").use { it.setLength(all) }
            inc.part.renameTo(inc.final)
            scanMedia(ctx, inc.final)
            if (req.len < 0 && x.total <= 0) x.finish()
        }
        ch.writeFully(ByteBuffer.wrap(byteArrayOf(0)))
    }
}

// ═══════════════════════════════ Client ═══════════════════════════════

/** Source d'un envoi : un fichier (accès à tous les fichiers) ou un document choisi dans le sélecteur Android. */
sealed class Source {
    data class F(val file: File) : Source()
    data class U(val uri: Uri) : Source()
}

object FastClient {
    /** 6 connexions simultanées au maximum, tous transferts confondus. */
    private val streams = Semaphore(6)

    private fun open(c: Connection): SocketChannel {
        val ch = SocketChannel.open()
        tune(ch.socket())
        try {
            ch.socket().connect(InetSocketAddress(c.host, c.fastPort), 6000)
        } catch (e: Exception) {
            runCatching { ch.close() }
            throw IOException("Connexion impossible à ${c.name}")
        }
        return ch
    }

    private fun ranges(size: Long): List<Pair<Long, Long>> {
        if (size < PARALLEL_MIN) return listOf(0L to size)
        val part = size / PARTS
        return (0 until PARTS).map { i ->
            val off = i * part
            off to if (i == PARTS - 1) size - off else part
        }
    }

    /** Exécute un bloc bloquant ; l'annulation de la coroutine ferme le socket et l'interrompt aussitôt. */
    private suspend fun <T> io(block: () -> T): T = streams.withPermit { runInterruptible(Dispatchers.IO) { block() } }

    /**
     * Télécharge [path] (taille [size]) dans [dest]. Les gros fichiers arrivent en 3 morceaux parallèles,
     * écrits directement à leur place dans un fichier temporaire « .lspart ».
     */
    suspend fun get(c: Connection, path: String, size: Long, dest: File, rec: Xfer, g: Group, app: Boolean = false): File {
        dest.parentFile?.mkdirs()
        val final = uniqueFile(dest)
        val part = File(final.parentFile, final.name + ".lspart")
        RandomAccessFile(part, "rw").use { if (size > 0) it.setLength(size) }
        val id = UUID.randomUUID().toString()
        try {
            coroutineScope {
                ranges(size).map { (off, len) ->
                    async {
                        io {
                            open(c).use { ch ->
                                ch.sendHeader(
                                    FastReq(
                                        c.token, "get", path = path, off = off, len = if (size <= 0) -1 else len,
                                        total = size, id = id, app = app, gid = g.id, gname = g.name, gtotal = g.total,
                                        from = Session.myName,
                                    )
                                )
                                val h = ByteBuffer.allocate(16); ch.readFully(h); h.flip()
                                val real = h.long; var left = h.long
                                if (real < 0) throw IOException(if (real == -404L) "Fichier introuvable" else "Accès refusé")
                                if (size > 0 && real != size) throw IOException("Fichier modifié pendant l'envoi")
                                RandomAccessFile(part, "rw").use { raf ->
                                    val fc = raf.channel
                                    val buf = ByteBuffer.allocateDirect(BUF)
                                    var pos = off
                                    while (left > 0) {
                                        buf.clear()
                                        if (left < buf.capacity()) buf.limit(left.toInt())
                                        val n = ch.read(buf)
                                        if (n < 0) throw EOFException("Connexion perdue")
                                        buf.flip()
                                        while (buf.hasRemaining()) pos += fc.write(buf, pos)
                                        left -= n; rec.add(n.toLong())
                                    }
                                }
                            }
                        }
                    }
                }.awaitAll()
            }
        } catch (e: Throwable) {
            part.delete()
            throw e
        }
        if (!part.renameTo(final)) throw IOException("Enregistrement impossible : ${final.name}")
        return final
    }

    private class Opened(val channel: FileChannel?, val closer: () -> Unit, val stream: java.io.InputStream?)

    private fun openSource(ctx: Context, s: Source): Opened = when (s) {
        is Source.F -> FileInputStream(s.file).let { fis -> Opened(fis.channel, { fis.close() }, null) }
        is Source.U -> {
            val pfd: ParcelFileDescriptor? = runCatching { ctx.contentResolver.openFileDescriptor(s.uri, "r") }.getOrNull()
            if (pfd != null) {
                val fis = FileInputStream(pfd.fileDescriptor)
                Opened(fis.channel, { runCatching { fis.close() }; runCatching { pfd.close() } }, null)
            } else {
                val ins = ctx.contentResolver.openInputStream(s.uri) ?: throw IOException("Lecture impossible")
                Opened(null, { ins.close() }, ins)
            }
        }
    }

    fun sizeOf(ctx: Context, s: Source): Long = when (s) {
        is Source.F -> s.file.length()
        is Source.U -> runCatching {
            ctx.contentResolver.query(s.uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use {
                if (it.moveToFirst() && !it.isNull(0)) it.getLong(0) else -1L
            } ?: -1L
        }.getOrDefault(-1L)
    }

    /** Envoie [src] vers Download/LinkShare/[name] de l'autre téléphone ([name] peut contenir des sous-dossiers). */
    suspend fun put(ctx: Context, c: Connection, src: Source, name: String, size: Long, rec: Xfer, g: Group) {
        val id = UUID.randomUUID().toString()
        val parts = if (size > 0) ranges(size) else listOf(0L to -1L)
        coroutineScope {
            parts.map { (off, len) ->
                async {
                    io {
                        val o = openSource(ctx, src)
                        try {
                            open(c).use { ch ->
                                ch.sendHeader(
                                    FastReq(
                                        c.token, "put", name = name, off = off, len = len, total = size, id = id,
                                        gid = g.id, gname = g.name, gtotal = g.total, from = Session.myName,
                                    )
                                )
                                val fc = o.channel
                                if (fc != null && len >= 0) {
                                    var pos = off
                                    val end = off + len
                                    while (pos < end) {
                                        val sent = fc.transferTo(pos, min(CHUNK, end - pos), ch)
                                        if (sent <= 0) throw IOException("Lecture interrompue")
                                        pos += sent; rec.add(sent)
                                    }
                                } else {
                                    // Taille inconnue ou document non « seekable » : envoi d'un seul flux jusqu'à la fin
                                    val ins = o.stream ?: java.nio.channels.Channels.newInputStream(fc ?: throw IOException("Lecture impossible"))
                                    val arr = ByteArray(BUF)
                                    while (true) {
                                        val n = ins.read(arr)
                                        if (n < 0) break
                                        ch.writeFully(ByteBuffer.wrap(arr, 0, n)); rec.add(n.toLong())
                                    }
                                    ch.shutdownOutput()
                                }
                                val ack = ByteBuffer.allocate(1); ch.readFully(ack)
                                if (ack.get(0).toInt() != 0) throw IOException("Refusé par ${c.name}")
                            }
                        } finally { o.closer() }
                    }
                }
            }.awaitAll()
        }
    }
}
