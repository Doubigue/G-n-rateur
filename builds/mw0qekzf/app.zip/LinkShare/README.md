# LinkShare

Partage rapide Android (Kotlin / Compose / Ktor) avec accès distant aux fichiers et applications.

## Lancer
1. Ouvrir le dossier dans Android Studio (Ladybug ou plus récent, JDK 17) et laisser Gradle synchroniser.
2. Installer sur deux téléphones (Android 11+).
3. Téléphone A : « Envoyer » → « Activer le point d'accès » → un code s'affiche.
4. Téléphone B : « Scanner » → scanne le code, accepte la connexion proposée par Android.
5. Les deux téléphones affichent les cartes « autre téléphone » et « Moi » : chacun parcourt, télécharge et envoie.

## Interface
Style « Data Transfer With Ease » : accueil (stockage réel, catégories, Partager / Recevoir / Lien, transferts récents),
barre bleue Accueil · Stockage · Partage · Profil, écran de partage avec QR + radar, et liste distante groupée
avec cases à cocher (téléchargement groupé), filtre par catégorie, recherche et bascule Récents / Dossiers / Apps.

## Stockage (explorateur local)
Tableau de bord (récents, catégories, coffre-fort, scanner) + explorateur : dossiers en grille par défaut (bascule liste),
recherche récursive, tri (nom/date/taille/type, croissant/décroissant), lecture intégrée (images, vidéos, audio, texte),
ouverture externe des autres documents (PDF, Office…), compression/décompression ZIP, scan de documents en PDF
(ML Kit), coffre-fort dans l'espace privé de l'appli ouvert via le verrouillage du téléphone.

## Connexion à double sens, point d'accès et transferts rapides (nouveau)
**Envoyer** (téléphone A) : un bouton **« Activer le point d'accès »** s'affiche. LinkShare crée son propre point d'accès
(Wi-Fi Direct **5 GHz** en priorité, sinon la bande choisie par le téléphone, sinon le point d'accès local d'Android),
puis affiche le **code à scanner**. Le code contient le nom et le mot de passe du point d'accès.
- Android 13+ : autoriser « Appareils à proximité ». Android 11-12 : autoriser la localisation et l'activer.
- « Déjà sur le même Wi-Fi ? » affiche un code sans point d'accès.

**Scanner** (téléphone B) : avant le scan, l'écran vérifie la radio.
- Si le point d'accès de LinkShare est actif : bouton **« Désactiver le point d'accès et activer le Wi-Fi »**.
- Si le partage de connexion du téléphone est actif : bouton **« Désactiver le point d'accès »** (ouvre le réglage, Android
  n'autorise pas une appli à le couper elle-même), puis « Activer le Wi-Fi » si besoin.
- Tout est prêt : l'appareil photo s'ouvre directement. Après le scan, Android demande de confirmer la connexion au
  point d'accès de l'autre téléphone (une seule touche), puis la connexion se fait.

**Après le scan, des deux côtés** : écran avec deux jolies cartes, **le nom de l'autre téléphone** puis **Moi**.
- Toucher l'autre → ses fichiers et ses applis : parcourir, lire, cocher, **Télécharger**.
- Toucher **Moi** → mes fichiers (raccourcis Appareil photo, Téléchargements, Images…), mes **applis** (APK) ou
  « Autres » (sélecteur Android) : cocher puis **Envoyer**.
- On revient aux cartes avec la flèche retour. Chaque téléphone a accès aux fichiers de l'autre.
- **Envoi et réception en même temps** : écran **Transferts** avec deux anneaux (Envoi ↑ / Réception ↓), et pour chaque
  élément le **pourcentage**, la taille, le débit et le temps restant ; annulation élément par élément ou « Tout annuler ».
  Une petite barre de pourcentage reste visible en bas des écrans de fichiers.
- Tout arrive dans `Download/LinkShare` (les photos et vidéos apparaissent dans la galerie).

**Écran éteint / appli quittée** : un service au premier plan garde le serveur, le point d'accès, le Wi-Fi (verrou haute
performance) et le processeur éveillés pendant toute la session. La notification affiche **↑ x % ↓ y %**, le débit et une
barre de progression, avec « Annuler les transferts » et « Se déconnecter ». L'exemption d'optimisation de batterie est
demandée une fois (recommandée).

**Rapidité** :
- Point d'accès **Wi-Fi Direct 5 GHz** au lieu du 2,4 GHz : en général 3 à 5 fois plus rapide.
- **Voie rapide** (port 8766) : les fichiers ne passent plus par HTTP mais par un protocole TCP minimal ; l'envoi utilise
  `sendfile()` du noyau (zéro copie), tampons de socket de 4 Mo.
- Les gros fichiers (≥ 24 Mo) sont coupés en **3 morceaux envoyés en parallèle**, plusieurs fichiers partent en même temps
  (4 connexions au maximum) ; un dossier est envoyé fichier par fichier sans ZIP, avec sa taille totale connue d'avance.
- HTTP (port 8765) reste utilisé pour parcourir, les miniatures et la lecture en streaming.

**Déconnexion** : bouton sur l'écran des cartes ; l'autre téléphone est prévenu, le point d'accès est coupé et le Wi-Fi
normal revient. Si l'autre disparaît (hors de portée), la connexion est fermée au bout d'une vingtaine de secondes.

## Préparatifs, connexion directe et stabilité (v suivante)
- **Écran « Les préparatifs »** (comme Xender) avant Envoyer et avant Scanner : une ligne par condition avec son bouton —
  Autoriser l'accès aux fichiers, *Couper le point d'accès* (scan seulement), **Ouvrir le WLAN** (ouvre la petite fenêtre
  Wi-Fi d'Android en bas de l'écran, avec son interrupteur ; elle est ouverte « pour résultat », sinon Android la referme aussitôt. Si un téléphone ne l'a pas, la fenêtre Wi-Fi de LinkShare — interrupteur, Paramètres, OK — prend le relais), Autoriser les appareils à proximité / la localisation, Ouvrir le GPS (Android 11-12),
  et en « Recommandé » les notifications et le fonctionnement écran éteint (batterie). Chaque ligne passe au vert ✓ dès que
  c'est fait ; **SUIVANT** s'active quand tout l'obligatoire est prêt. Si tout est déjà prêt, l'écran est sauté.
- **Connexion directe Wi-Fi Direct** : le téléphone qui scanne rejoint le groupe de l'autre avec son nom, son mot de passe et
  sa fréquence (lus dans le code) — sans fenêtre de confirmation, sans balayage Wi-Fi (Android en limite le nombre) et en
  gardant son propre Wi-Fi. Si cela échoue, l'ancienne méthode (fenêtre « Se connecter ») prend le relais.
- **Stabilité** : les serveurs démarrent une seule fois par processus (plus d'erreur « port déjà utilisé » en relançant le
  partage), hors du fil principal ; toutes les erreurs de permission / Wi-Fi / service sont rattrapées et affichées au lieu
  de fermer l'appli ; messages d'erreur clairs à la connexion.
- **Plus rapide** : morceaux parallèles 4 au lieu de 3 dès 16 Mo, 6 connexions simultanées, blocs de 8 Mo ; notre serveur
  démarre pendant qu'on rejoint l'autre téléphone (connexion plus courte).
- Sur Tecno / Infinix / Xiaomi / Oppo, autoriser aussi le **démarrage automatique** et « Aucune restriction » de batterie
  pour LinkShare dans les réglages du téléphone : sinon le système peut couper l'appli en arrière-plan.

## Réseau
Point d'accès créé par LinkShare (recommandé, le plus rapide), ou même Wi-Fi.

## À faire ensuite
- TLS (certificat auto-signé épinglé dans le QR) : actuellement HTTP + jeton aléatoire de 192 bits.
- Choix des dossiers partagés + écran de consentement / révocation.
- Visionneuse texte/PDF, reprise des transferts, installation directe des APK.
