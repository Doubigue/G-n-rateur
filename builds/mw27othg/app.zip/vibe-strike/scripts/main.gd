extends Node2D
## Vibe Strike — jeu de foot "trace ta trajectoire" (inspiré de Score! Hero)
## DL VIBE STUDIO — Godot 4.x
## Tout est dessiné en code (_draw) : aucun asset externe nécessaire.

const W := 720.0
const H := 1280.0
const GOAL_Y := 150.0
const GOAL_L := 250.0
const GOAL_R := 470.0
const BALL_R := 13.0
const PLAYER_R := 26.0
const SHOT_SPEED := 1350.0
const PASS_SPEED := 950.0
const PICK_RADIUS := 120.0
const LOB_H := 150.0        # hauteur max d'un lob (pixels "virtuels")
const SEASON_NAMES := ["Saison 1 — Débuts", "Saison 2 — Coupe Continentale"]
const SAVE_PATH := "user://vibe_strike.cfg"

const GOLD := Color(0.95, 0.76, 0.25)
const DARK := Color(0.07, 0.07, 0.09)
const TEAM_COL := Color(0.95, 0.76, 0.25)
const OPP_COL := Color(0.85, 0.18, 0.2)
const KEEPER_COL := Color(0.2, 0.75, 0.95)

enum Screen { SPLASH, MENU, LEVELS, GAME, KITS, LOBBY }
enum Phase { AIM, DRAW, FLIGHT, RESULT, END }

var font: Font
var screen: int = Screen.SPLASH
var phase: int = Phase.AIM
var levels: Array = []
var level_idx := 0
var unlocked := 1
var best_stars: Array = []
var total_score := 0

# --- état du niveau ---
var team: Array = []        # positions des coéquipiers (Vector2)
var defenders: Array = []   # {base, range, speed, ph, pos}
var holder := 0
var ball := Vector2.ZERO
var ball_rot := 0.0
var keeper_x := 360.0
var keeper_speed := 200.0
var keeper_react := 0.0
var attempts_left := 3
var attempts_max := 3
var passes := 0
var t := 0.0

var draw_pts := PackedVector2Array()
var flight_pts := PackedVector2Array()
var flight_cum := PackedFloat32Array()
var flight_dist := 0.0
var flight_speed := SHOT_SPEED
var flight_is_pass := false
var pass_target := -1
var curve_bonus := false
var prev_ball := Vector2.ZERO
var trail: Array = []

var msg := ""
var msg_color := Color.WHITE
var msg_timer := 0.0
var result_goal := false
var shake := 0.0
var net_wobble := 0.0
var particles: Array = []
var popups: Array = []
var end_win := false
var end_stars := 0
var end_score := 0
var buttons: Array = []     # {rect, id}

var sb_gold: StyleBoxFlat
var sb_dark: StyleBoxFlat
var sb_lock: StyleBoxFlat

const LOGO_PATH := "res://assets/logo.png"   # dépose ton logo ici (PNG) : il remplace l'emblème dessiné
var sfx: Node
var logo_tex: Texture2D
var splash_t := 0.0
var sound_on := true

# --- lob & carrière ---
var lob_mode := false
var flight_lob := false
var flight_h := 0.0
var lob_len := 0.0
var season := 0

# --- mode Défi 60 s ---
const CHALLENGE_TIME := 60.0
var challenge := false
var challenge_lvl: Dictionary = {}
var challenge_time := 0.0
var challenge_goals := 0
var challenge_points := 0
var challenge_best := 0
var challenge_record := false
var last_tick := 0

# --- maillots ---
var kits: Array = []
var kit := 0

# --- duel 2 téléphones (Wi-Fi local) ---
var duel_net: Node
var duel := false
var crng := RandomNumberGenerator.new()
var challenge_round := 0
var duel_countdown := 0.0
var opp_goals := 0
var opp_done := false
var opp_kit_i := 0
var duel_msg := ""
var duel_rematch_sent := false
var lobby_state := "choose"     # choose | hosting | joining | keypad | connecting
var lobby_err := ""
var lobby_t := 0.0
var ip_input := "192.168."
var join_ip := ""


func _ready() -> void:
	font = ThemeDB.fallback_font
	sb_gold = _make_sb(GOLD, DARK)
	sb_dark = _make_sb(Color(0, 0, 0, 0.55), GOLD)
	sb_lock = _make_sb(Color(0.15, 0.15, 0.17, 0.85), Color(0.35, 0.35, 0.38))
	_build_levels()
	_build_kits()
	best_stars.resize(levels.size())
	best_stars.fill(0)
	_load()
	sfx = preload("res://scripts/sfx.gd").new()
	add_child(sfx)
	sfx.call("set_enabled", sound_on)
	duel_net = preload("res://scripts/duel.gd").new()
	duel_net.name = "Duel"
	add_child(duel_net)
	duel_net.connect("peer_joined", _on_duel_peer_joined)
	duel_net.connect("start", _on_duel_start)
	duel_net.connect("opp_score", _on_opp_score)
	duel_net.connect("opp_finished", _on_opp_finished)
	duel_net.connect("opp_kit", _on_opp_kit)
	duel_net.connect("net_error", _on_net_error)
	if ResourceLoader.exists(LOGO_PATH):
		logo_tex = load(LOGO_PATH) as Texture2D


func _sfx(name: String, pitch: float = 1.0, vol: float = 0.0) -> void:
	if sfx:
		sfx.call("play", name, pitch, vol)


## Maillots : débloqués avec les étoiles de la carrière (ou le record du Défi)
func _build_kits() -> void:
	kits = [
		{"name": "Or Vibe", "main": Color(0.95, 0.76, 0.25), "acc": Color(0.07, 0.07, 0.09), "stars": 0, "defi": 0},
		{"name": "Abidjan", "main": Color(1.0, 0.55, 0.1), "acc": Color(1, 1, 1), "stars": 6, "defi": 0},
		{"name": "Nuit", "main": Color(0.1, 0.1, 0.12), "acc": Color(0.95, 0.76, 0.25), "stars": 12, "defi": 0},
		{"name": "Océan", "main": Color(0.15, 0.3, 0.8), "acc": Color(1, 1, 1), "stars": 20, "defi": 0},
		{"name": "Émeraude", "main": Color(0.05, 0.6, 0.35), "acc": Color(1, 1, 1), "stars": 30, "defi": 0},
		{"name": "Royal", "main": Color(0.45, 0.15, 0.7), "acc": Color(1.0, 0.85, 0.3), "stars": 40, "defi": 0},
		{"name": "Légende", "main": Color(0.97, 0.97, 0.97), "acc": Color(0.85, 0.65, 0.15), "stars": 55, "defi": 0},
		{"name": "Néon Défi", "main": Color(0.1, 0.95, 0.6), "acc": Color(0.07, 0.07, 0.09), "stars": 0, "defi": 10},
	]


func _total_stars() -> int:
	var n := 0
	for v in best_stars:
		n += int(v)
	return n


func _kit_open(i: int) -> bool:
	var k: Dictionary = kits[i]
	return _total_stars() >= int(k["stars"]) and challenge_best >= int(k["defi"])


func _cur() -> Dictionary:
	if challenge:
		return challenge_lvl
	return levels[level_idx]


# ------------------------------------------------------------------ DÉFI
func _start_challenge(seed_value: int = -1) -> void:
	if seed_value >= 0:
		crng.seed = seed_value
	else:
		crng.randomize()
	challenge_round = 0
	challenge = true
	challenge_time = CHALLENGE_TIME
	challenge_goals = 0
	challenge_points = 0
	challenge_record = false
	last_tick = 0
	attempts_max = 99
	attempts_left = 99
	particles.clear()
	popups.clear()
	_next_challenge()
	screen = Screen.GAME
	if not duel:
		_sfx("whistle")


func _next_challenge() -> void:
	challenge_lvl = _gen_challenge()
	challenge_round += 1
	keeper_speed = float(challenge_lvl["keeper"])
	_reset_attempt()


## Génère une situation aléatoire, plus dure à chaque but marqué
func _gen_challenge() -> Dictionary:
	var g := challenge_round / 2
	var n_team := crng.randi_range(1, 3)
	var tp: Array = []
	for i in n_team:
		var y0 := 1080.0 - i * (520.0 / maxf(1.0, n_team - 1.0)) if n_team > 1 else crng.randf_range(520.0, 680.0)
		tp.append(Vector2(crng.randf_range(150.0, 570.0), clampf(y0 + crng.randf_range(-40.0, 40.0), 480.0, 1120.0)))
	var defs: Array = []
	var n_def := crng.randi_range(mini(g / 3, 3), mini(1 + g / 2, 5))
	var tries := 0
	while defs.size() < n_def and tries < 60:
		tries += 1
		var dp := Vector2(crng.randf_range(180.0, 540.0), crng.randf_range(300.0, 1000.0))
		var ok := true
		for q in tp:
			if dp.distance_to(q) < 110.0:
				ok = false
		if ok:
			var moving := crng.randf() < 0.6
			defs.append([dp, crng.randf_range(40.0, 150.0) if moving else 0.0, crng.randf_range(1.0, 2.2 + g * 0.08)])
	return {"name": "Défi", "team": tp, "def": defs, "keeper": minf(170.0 + g * 22.0, 400.0), "attempts": 99, "req": ""}


func _make_sb(bg: Color, border: Color) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.border_color = border
	sb.set_border_width_all(4)
	sb.set_corner_radius_all(22)
	return sb


# ------------------------------------------------------------------ NIVEAUX
## req : "" (n'importe quel but), "lob" (but en lob), "passN" (au moins N passes avant le but)
func _lvl(name: String, team_pos: Array, defs: Array, keeper: float, attempts: int, req: String = "") -> Dictionary:
	return {"name": name, "team": team_pos, "def": defs, "keeper": keeper, "attempts": attempts, "req": req}


func _wall(y: float, x0: float, n: int, gap: float = 55.0) -> Array:
	var out: Array = []
	for i in n:
		out.append([Vector2(x0 + i * gap, y), 0.0, 0.0])
	return out


func _req_text(req: String) -> String:
	if req == "lob":
		return "Objectif : marquer sur un LOB"
	if req.begins_with("pass"):
		return "Objectif : %s passes avant de marquer" % req.substr(4)
	return "Objectif : marquer"


func _build_levels() -> void:
	# défenseur = [position, amplitude de déplacement horizontal, vitesse]
	levels = [
		_lvl("Premier tir", [Vector2(360, 600)], [], 110.0, 3),
		_lvl("Une passe", [Vector2(200, 950), Vector2(480, 540)],
			[[Vector2(340, 760), 0.0, 0.0]], 150.0, 3),
		_lvl("Le mur", [Vector2(360, 660)],
			[[Vector2(300, 440), 0.0, 0.0], [Vector2(360, 440), 0.0, 0.0], [Vector2(420, 440), 0.0, 0.0]], 170.0, 3),
		_lvl("Le couloir", [Vector2(150, 1050), Vector2(560, 760), Vector2(360, 500)],
			[[Vector2(360, 880), 140.0, 1.5]], 190.0, 3),
		_lvl("Contre-attaque", [Vector2(360, 1080), Vector2(170, 760), Vector2(540, 520)],
			[[Vector2(300, 920), 110.0, 2.0], [Vector2(440, 640), 120.0, 1.6]], 210.0, 3),
		_lvl("Coup franc", [Vector2(400, 620)],
			[[Vector2(290, 450), 0.0, 0.0], [Vector2(345, 450), 0.0, 0.0], [Vector2(400, 450), 0.0, 0.0], [Vector2(455, 450), 0.0, 0.0]], 240.0, 3),
		_lvl("Triangle", [Vector2(560, 1060), Vector2(160, 800), Vector2(480, 540)],
			[[Vector2(360, 930), 150.0, 2.2], [Vector2(320, 660), 130.0, 1.8], [Vector2(400, 330), 60.0, 1.2]], 240.0, 3),
		_lvl("Angle fermé", [Vector2(620, 520)],
			[[Vector2(520, 340), 40.0, 1.0]], 270.0, 3),
		_lvl("Pressing", [Vector2(360, 1120), Vector2(190, 880), Vector2(530, 680), Vector2(300, 470)],
			[[Vector2(280, 1000), 90.0, 2.4], [Vector2(380, 780), 140.0, 2.0], [Vector2(420, 580), 120.0, 1.7], [Vector2(360, 320), 80.0, 1.4]], 280.0, 3),
		_lvl("Dernière minute", [Vector2(140, 1120), Vector2(560, 920), Vector2(180, 680), Vector2(520, 480)],
			[[Vector2(360, 1020), 160.0, 2.6], [Vector2(380, 800), 160.0, 2.3], [Vector2(330, 580), 150.0, 2.0], [Vector2(420, 390), 90.0, 1.8], [Vector2(300, 300), 60.0, 1.5]], 310.0, 2),
		# ---------------- SAISON 2 : Coupe Continentale (lobs & objectifs)
		_lvl("Le grand mur", [Vector2(360, 720)], _wall(480, 250, 5), 250.0, 3),
		_lvl("Lob obligatoire", [Vector2(360, 560)], [], 330.0, 3, "lob"),
		_lvl("Par-dessus", [Vector2(360, 1060), Vector2(360, 600)], _wall(830, 230, 6, 52.0), 260.0, 3),
		_lvl("Deux passes", [Vector2(180, 1050), Vector2(540, 820), Vector2(260, 560)],
			[[Vector2(360, 940), 140.0, 2.0], [Vector2(400, 690), 130.0, 1.8]], 270.0, 3, "pass2"),
		_lvl("Gardien rapide", [Vector2(200, 900), Vector2(520, 560)],
			[[Vector2(360, 740), 120.0, 2.2], [Vector2(360, 380), 70.0, 1.5]], 380.0, 3),
		_lvl("Les deux murs", [Vector2(360, 1080), Vector2(360, 680)], _wall(880, 250, 5) + _wall(470, 280, 4), 280.0, 3),
		_lvl("Lob en course", [Vector2(560, 1000), Vector2(180, 640)],
			[[Vector2(360, 840), 180.0, 3.0], [Vector2(320, 470), 150.0, 2.6]], 320.0, 3, "lob"),
		_lvl("Tiki-taka", [Vector2(360, 1120), Vector2(150, 920), Vector2(570, 760), Vector2(170, 580), Vector2(520, 460)],
			[[Vector2(360, 1010), 150.0, 2.4], [Vector2(360, 840), 170.0, 2.2], [Vector2(360, 660), 160.0, 2.0], [Vector2(360, 330), 70.0, 1.6]], 290.0, 3, "pass3"),
		_lvl("Forteresse", [Vector2(140, 1100), Vector2(580, 860), Vector2(360, 640)],
			_wall(980, 300, 3, 60.0) + [[Vector2(360, 760), 170.0, 2.6], [Vector2(250, 470), 60.0, 1.8], [Vector2(470, 470), 60.0, 1.8]] + _wall(330, 330, 2, 60.0), 340.0, 3),
		_lvl("La finale", [Vector2(360, 1120), Vector2(160, 880), Vector2(560, 700), Vector2(300, 520)],
			[[Vector2(360, 1000), 180.0, 3.0], [Vector2(360, 800), 180.0, 2.6], [Vector2(420, 610), 150.0, 2.3], [Vector2(330, 400), 90.0, 2.0], [Vector2(420, 300), 60.0, 1.7]], 380.0, 2, "pass2"),
	]


func _start_level(i: int) -> void:
	level_idx = i
	challenge = false
	duel = false
	var L: Dictionary = levels[i]
	attempts_max = int(L["attempts"])
	attempts_left = attempts_max
	keeper_speed = float(L["keeper"])
	season = i / 10
	screen = Screen.GAME
	particles.clear()
	popups.clear()
	_reset_attempt()
	_sfx("whistle")


func _reset_attempt() -> void:
	var L: Dictionary = _cur()
	team = (L["team"] as Array).duplicate()
	defenders.clear()
	for d in L["def"]:
		var arr: Array = d
		defenders.append({"base": arr[0], "range": arr[1], "speed": arr[2], "ph": crng.randf() * TAU, "pos": arr[0]})
	holder = 0
	passes = 0
	ball = _ball_at_owner()
	keeper_x = 360.0
	trail.clear()
	draw_pts.clear()
	flight_pts.clear()
	lob_mode = false
	flight_lob = false
	flight_h = 0.0
	phase = Phase.AIM


func _ball_at_owner() -> Vector2:
	var p: Vector2 = team[holder]
	return p + Vector2(0, -PLAYER_R - BALL_R + 2)


# ------------------------------------------------------------------ BOUCLE
func _process(delta: float) -> void:
	t += delta
	shake = maxf(0.0, shake - delta * 2.5)
	net_wobble = maxf(0.0, net_wobble - delta * 1.5)
	_update_fx(delta)
	if sfx:
		sfx.call("crowd_on", screen == Screen.GAME and phase != Phase.END)
	if screen == Screen.LOBBY and lobby_state == "connecting" and not bool(duel_net.call("connected")):
		lobby_t += delta
		if lobby_t > 8.0:
			duel_net.call("close")
			lobby_err = "Pas de réponse de %s" % join_ip
			lobby_state = "choose"
	if screen == Screen.SPLASH:
		splash_t += delta
		if splash_t > 2.6:
			screen = Screen.MENU

	if screen == Screen.GAME:
		for d in defenders:
			var dd: Dictionary = d
			var base: Vector2 = dd["base"]
			dd["pos"] = base + Vector2(sin(t * float(dd["speed"]) + float(dd["ph"])) * float(dd["range"]), 0)

		if duel and duel_countdown > 0.0:
			duel_countdown -= delta
			if duel_countdown <= 0.0:
				_sfx("whistle")
		if challenge and phase != Phase.END and duel_countdown <= 0.0:
			challenge_time = maxf(0.0, challenge_time - delta)
			var sec := int(ceil(challenge_time))
			if sec <= 5 and sec != last_tick and sec > 0:
				last_tick = sec
				_sfx("click", 1.6, 0.0)
			if challenge_time <= 0.0 and (phase == Phase.AIM or phase == Phase.DRAW):
				_end_challenge()
		match phase:
			Phase.AIM, Phase.DRAW:
				ball = _ball_at_owner()
				var idle_target: float = clampf(lerpf(360.0, ball.x, 0.35), GOAL_L + 25, GOAL_R - 25)
				keeper_x = move_toward(keeper_x, idle_target, keeper_speed * 0.4 * delta)
			Phase.FLIGHT:
				_update_flight(delta)
			Phase.RESULT:
				msg_timer -= delta
				if msg_timer <= 0.0:
					_after_result()
	queue_redraw()


func _update_flight(delta: float) -> void:
	prev_ball = ball
	flight_dist += flight_speed * delta
	ball_rot += delta * 18.0
	var total: float = flight_cum[flight_cum.size() - 1]
	if flight_dist >= total:
		flight_dist = total
		ball = flight_pts[flight_pts.size() - 1]
		if flight_is_pass:
			_receive_pass()
		else:
			_miss("Hors du terrain !")
		return
	ball = _point_at(flight_dist)
	flight_h = 0.0
	if flight_lob and flight_dist < lob_len:
		var u := flight_dist / lob_len
		flight_h = 4.0 * LOB_H * u * (1.0 - u)
	trail.append(ball + Vector2(0, -flight_h * 0.5))
	if trail.size() > 14:
		trail.pop_front()

	# Interception par un défenseur
	if flight_dist > 30.0:
		for d in defenders:
			var dp: Vector2 = (d as Dictionary)["pos"]
			if flight_h < 45.0 and ball.distance_to(dp) < PLAYER_R + BALL_R - 2:
				_miss("Intercepté !")
				return

	# Gardien : il lit la direction ACTUELLE du ballon (un tir enroulé le trompe)
	var v := ball - prev_ball
	if ball.y < 780.0:
		keeper_react -= delta
		if keeper_react <= 0.0 and v.y < -0.5:
			var frames := (ball.y - GOAL_Y) / -v.y
			var pred := ball.x + v.x * frames
			var target: float = clampf(pred, GOAL_L + 18, GOAL_R - 18)
			keeper_x = move_toward(keeper_x, target, keeper_speed * delta)
	var ky := GOAL_Y + 22.0
	if flight_h < 70.0 and absf(ball.x - keeper_x) < 36.0 and absf(ball.y - ky) < 20.0:
		_miss("Arrêt du gardien !")
		return

	# Franchissement de la ligne de but
	if ball.y <= GOAL_Y and prev_ball.y > GOAL_Y:
		var k := (prev_ball.y - GOAL_Y) / maxf(0.001, prev_ball.y - ball.y)
		var cx: float = lerpf(prev_ball.x, ball.x, k)
		if flight_h > 95.0:
			_miss("Au-dessus !")
		elif cx > GOAL_L + BALL_R * 0.5 and cx < GOAL_R - BALL_R * 0.5:
			_goal()
		elif cx > GOAL_L - BALL_R and cx < GOAL_R + BALL_R:
			_miss("Poteau !")
		else:
			_miss("À côté !")
		return

	if ball.x < -20 or ball.x > W + 20 or ball.y > H + 40 or ball.y < 0:
		_miss("Hors du terrain !")


func _receive_pass() -> void:
	holder = pass_target
	passes += 1
	_popup(team[holder] + Vector2(0, -60), "Passe +150", Color.WHITE)
	_sfx("pass", 0.8, -6.0)
	trail.clear()
	phase = Phase.AIM


func _goal() -> void:
	var req := String(_cur()["req"])
	if req == "lob" and not flight_lob:
		_miss("Il faut un LOB !")
		return
	if req.begins_with("pass") and passes < int(req.substr(4)):
		_miss("Il faut %s passes !" % req.substr(4))
		return
	result_goal = true
	shake = 1.0
	net_wobble = 1.0
	_burst(ball, 60)
	var used := attempts_max - attempts_left + 1
	end_stars = 3 if used == 1 else (2 if used == 2 else 1)
	end_score = 1000 + passes * 150 + (300 if curve_bonus else 0) + (250 if flight_lob else 0) + attempts_left * 100
	msg = "BUUUT !"
	if flight_lob:
		msg = "BUT EN LOB !"
	elif curve_bonus:
		msg = "BUT ENROULÉ !"
	msg_color = GOLD
	msg_timer = 0.9 if challenge else 1.6
	_sfx("cheer")
	_sfx("whistle", 1.0, -4.0)
	phase = Phase.RESULT


func _miss(text: String) -> void:
	result_goal = false
	attempts_left -= 1
	shake = 0.35
	msg = text
	msg_color = Color(1, 0.45, 0.45)
	msg_timer = 0.8 if challenge else 1.3
	phase = Phase.RESULT
	if text == "Poteau !":
		_sfx("post")
	elif text == "Intercepté !":
		_sfx("kick", 0.7, -3.0)
	_sfx("groan", randf_range(0.9, 1.1), -2.0)


func _end_challenge() -> void:
	if duel:
		duel_net.call("send_finished", challenge_goals)
		_sfx("whistle")
		phase = Phase.END
		_duel_verdict_sfx()
		return
	challenge_record = challenge_goals > challenge_best
	if challenge_record:
		challenge_best = challenge_goals
		_save()
	_sfx("whistle")
	_sfx("whistle", 0.9, -3.0)
	phase = Phase.END


func _after_result() -> void:
	if challenge:
		if result_goal:
			challenge_goals += 1
			if duel:
				duel_net.call("send_score", challenge_goals)
			challenge_points += end_score
			challenge_time += 3.0   # bonus de temps à chaque but
			_popup(Vector2(360, 760), "+3 s", Color(0.55, 0.85, 1.0))
		if challenge_time <= 0.0:
			_end_challenge()
		else:
			_next_challenge()
		return
	if result_goal:
		end_win = true
		total_score += end_score
		if end_stars > int(best_stars[level_idx]):
			best_stars[level_idx] = end_stars
		unlocked = maxi(unlocked, mini(levels.size(), level_idx + 2))
		_save()
		phase = Phase.END
		for i in end_stars:
			get_tree().create_timer(0.25 + i * 0.3).timeout.connect(_sfx.bind("star", 1.0 + i * 0.25, -2.0))
	elif attempts_left <= 0:
		end_win = false
		end_stars = 0
		phase = Phase.END
	else:
		_reset_attempt()


# ------------------------------------------------------------------ TRAJECTOIRE
func _launch() -> void:
	if draw_pts.size() < 3 or _poly_len(draw_pts) < 40.0:
		phase = Phase.AIM
		return
	var pts := _smooth(_resample(draw_pts, 14.0))
	var end_p: Vector2 = pts[pts.size() - 1]

	# Passe : la trajectoire se termine près d'un coéquipier
	pass_target = -1
	var best := 85.0
	for i in team.size():
		if i == holder:
			continue
		var d := end_p.distance_to(team[i])
		if d < best:
			best = d
			pass_target = i
	flight_is_pass = pass_target >= 0
	curve_bonus = false
	flight_lob = lob_mode
	lob_mode = false
	lob_len = maxf(1.0, _poly_len(pts))

	if flight_is_pass:
		pts[pts.size() - 1] = team[pass_target] + Vector2(0, -PLAYER_R - BALL_R + 2)
		flight_speed = PASS_SPEED
	else:
		# Tir : le ballon continue dans la dernière direction
		var dir := (pts[pts.size() - 1] - pts[pts.size() - 3]).normalized()
		var p := end_p
		for i in 60:
			p += dir * 30.0
			pts.append(p)
		flight_speed = SHOT_SPEED
		curve_bonus = _deviation(draw_pts) > 55.0

	flight_pts = pts
	flight_cum = PackedFloat32Array()
	flight_cum.append(0.0)
	for i in range(1, pts.size()):
		flight_cum.append(flight_cum[i - 1] + pts[i].distance_to(pts[i - 1]))
	if flight_lob:
		flight_speed *= 0.72
	flight_dist = 0.0
	prev_ball = ball
	if flight_is_pass:
		_sfx("pass", randf_range(0.95, 1.1))
	else:
		_sfx("kick", randf_range(0.9, 1.1))
	keeper_react = 0.12
	trail.clear()
	phase = Phase.FLIGHT


func _point_at(d: float) -> Vector2:
	for i in range(1, flight_cum.size()):
		if flight_cum[i] >= d:
			var seg := flight_cum[i] - flight_cum[i - 1]
			var k := 0.0 if seg <= 0.0 else (d - flight_cum[i - 1]) / seg
			return flight_pts[i - 1].lerp(flight_pts[i], k)
	return flight_pts[flight_pts.size() - 1]


func _poly_len(p: PackedVector2Array) -> float:
	var l := 0.0
	for i in range(1, p.size()):
		l += p[i].distance_to(p[i - 1])
	return l


func _resample(p: PackedVector2Array, step: float) -> PackedVector2Array:
	var out := PackedVector2Array()
	out.append(p[0])
	var acc := 0.0
	for i in range(1, p.size()):
		var a := p[i - 1]
		var b := p[i]
		var seg := a.distance_to(b)
		while acc + seg >= step:
			var k := (step - acc) / seg
			a = a.lerp(b, k)
			out.append(a)
			seg = a.distance_to(b)
			acc = 0.0
		acc += seg
	out.append(p[p.size() - 1])
	return out


func _smooth(p: PackedVector2Array) -> PackedVector2Array:
	var cur := p
	for it in 2:
		if cur.size() < 3:
			break
		var out := PackedVector2Array()
		out.append(cur[0])
		for i in range(cur.size() - 1):
			out.append(cur[i].lerp(cur[i + 1], 0.25))
			out.append(cur[i].lerp(cur[i + 1], 0.75))
		out.append(cur[cur.size() - 1])
		cur = out
	return cur


func _deviation(p: PackedVector2Array) -> float:
	var a := p[0]
	var b := p[p.size() - 1]
	var ab := b - a
	if ab.length() < 1.0:
		return 0.0
	var n := Vector2(-ab.y, ab.x).normalized()
	var m := 0.0
	for q in p:
		m = maxf(m, absf((q - a).dot(n)))
	return m


# ------------------------------------------------------------------ ENTRÉES
func _input(event: InputEvent) -> void:
	var e := make_input_local(event)
	if e is InputEventMouseButton and (e as InputEventMouseButton).button_index == MOUSE_BUTTON_LEFT:
		var mb := e as InputEventMouseButton
		if mb.pressed:
			_on_press(mb.position)
		else:
			_on_release(mb.position)
	elif e is InputEventMouseMotion:
		_on_drag((e as InputEventMouseMotion).position)


func _on_press(pos: Vector2) -> void:
	if screen == Screen.SPLASH:
		screen = Screen.MENU
		return
	for b in buttons:
		var r: Rect2 = (b as Dictionary)["rect"]
		if r.has_point(pos):
			_sfx("click")
			_on_button(String((b as Dictionary)["id"]))
			return
	if duel and duel_countdown > 0.0:
		return
	if screen == Screen.GAME and phase == Phase.AIM and pos.distance_to(ball) < PICK_RADIUS:
		draw_pts = PackedVector2Array([ball])
		phase = Phase.DRAW


func _on_drag(pos: Vector2) -> void:
	if screen == Screen.GAME and phase == Phase.DRAW:
		var last := draw_pts[draw_pts.size() - 1]
		if pos.distance_to(last) > 8.0 and _poly_len(draw_pts) < 1700.0:
			draw_pts.append(pos)


func _on_release(_pos: Vector2) -> void:
	if screen == Screen.GAME and phase == Phase.DRAW:
		_launch()


func _on_button(id: String) -> void:
	if id == "lob":
		if phase == Phase.AIM:
			lob_mode = not lob_mode
	elif id == "season0":
		season = 0
	elif id == "season1":
		if unlocked > 10:
			season = 1
	elif id == "sound":
		sound_on = not sound_on
		sfx.call("set_enabled", sound_on)
		_save()
	elif id == "play":
		screen = Screen.LEVELS
	elif id == "challenge":
		duel = false
		_start_challenge()
	elif id == "duel":
		screen = Screen.LOBBY
		lobby_state = "choose"
		lobby_err = ""
	elif id == "lobby_host":
		duel_net.set("my_kit", kit)
		if int(duel_net.call("host")) == OK:
			lobby_state = "hosting"
			lobby_err = ""
		else:
			lobby_err = "Impossible de créer la partie"
	elif id == "lobby_join":
		duel_net.call("start_discovery")
		lobby_state = "joining"
		lobby_err = ""
	elif id == "lobby_keypad":
		lobby_state = "keypad"
	elif id == "lobby_cancel":
		duel_net.call("close")
		lobby_state = "choose"
	elif id == "lobby_back":
		duel_net.call("close")
		screen = Screen.MENU
	elif id.begins_with("host_"):
		_duel_connect(id.substr(5))
	elif id == "key_del":
		ip_input = ip_input.substr(0, maxi(0, ip_input.length() - 1))
	elif id == "key_ok":
		_save()
		_duel_connect(ip_input)
	elif id.begins_with("key_"):
		if ip_input.length() < 15:
			ip_input += id.substr(4)
	elif id == "duel_quit":
		_quit_duel()
	elif id == "duel_rematch":
		if not duel_rematch_sent:
			duel_rematch_sent = true
			duel_net.call("request_rematch")
	elif id == "kits":
		screen = Screen.KITS
	elif id.begins_with("kit_"):
		var ki := int(id.substr(4))
		if _kit_open(ki):
			kit = ki
			_save()
	elif id == "back_menu":
		screen = Screen.MENU
	elif id == "levels":
		screen = Screen.LEVELS
	elif id == "retry":
		if challenge:
			_start_challenge()
		else:
			_start_level(level_idx)
	elif id == "next":
		_start_level(mini(level_idx + 1, levels.size() - 1))
	elif id == "pause":
		if duel:
			_quit_duel()
		else:
			screen = Screen.MENU if challenge else Screen.LEVELS
	elif id.begins_with("lvl_"):
		var i := int(id.substr(4))
		if i < unlocked:
			_start_level(i)


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		if screen == Screen.GAME and duel:
			_quit_duel()
		elif screen == Screen.LOBBY:
			duel_net.call("close")
			screen = Screen.MENU
		elif screen == Screen.GAME:
			screen = Screen.MENU if challenge else Screen.LEVELS
		elif screen == Screen.LEVELS or screen == Screen.KITS:
			screen = Screen.MENU
		elif screen == Screen.SPLASH:
			screen = Screen.MENU
		else:
			get_tree().quit()


# ------------------------------------------------------------------ DUEL
func _duel_connect(ip: String) -> void:
	join_ip = ip.strip_edges()
	duel_net.set("my_kit", kit)
	if int(duel_net.call("join", join_ip)) == OK:
		lobby_state = "connecting"
		lobby_t = 0.0
		lobby_err = ""
	else:
		lobby_err = "Adresse invalide : %s" % join_ip
		lobby_state = "choose"


func _quit_duel() -> void:
	duel_net.call("close")
	duel = false
	challenge = false
	screen = Screen.MENU


func _on_duel_peer_joined() -> void:
	duel_net.call("begin_match")


func _on_duel_start(seed_value: int) -> void:
	duel = true
	opp_goals = 0
	opp_done = false
	duel_msg = ""
	duel_rematch_sent = false
	_start_challenge(seed_value)
	duel_countdown = 3.0


func _on_opp_score(goals: int) -> void:
	opp_goals = goals
	if screen == Screen.GAME and duel and phase != Phase.END:
		_popup(Vector2(360, 860), "L'adversaire marque ! (%d)" % goals, Color(1, 0.6, 0.6))


func _on_opp_finished(goals: int) -> void:
	opp_goals = goals
	opp_done = true
	if phase == Phase.END:
		_duel_verdict_sfx()


func _on_opp_kit(k: int) -> void:
	opp_kit_i = clampi(k, 0, kits.size() - 1)


func _on_net_error(reason: String) -> void:
	if screen == Screen.GAME and duel:
		duel_msg = reason
		if phase != Phase.END:
			_end_challenge()
	elif screen == Screen.LOBBY:
		duel_net.call("close")
		lobby_err = reason
		lobby_state = "choose"


func _duel_verdict_sfx() -> void:
	if not opp_done:
		return
	if challenge_goals > opp_goals:
		_sfx("cheer")
	elif challenge_goals < opp_goals:
		_sfx("groan")
	else:
		_sfx("whistle")


# ------------------------------------------------------------------ EFFETS
func _burst(at: Vector2, n: int) -> void:
	var cols := [GOLD, Color.WHITE, Color(1, 0.4, 0.3), Color(0.4, 0.85, 1)]
	for i in n:
		var a := randf() * TAU
		var s := randf_range(150, 650)
		particles.append({"p": at, "v": Vector2(cos(a), sin(a)) * s, "c": cols[i % cols.size()], "life": randf_range(0.7, 1.4)})


func _popup(at: Vector2, text: String, col: Color) -> void:
	popups.append({"p": at, "text": text, "c": col, "life": 1.0})


func _update_fx(delta: float) -> void:
	for i in range(particles.size() - 1, -1, -1):
		var p: Dictionary = particles[i]
		p["life"] = float(p["life"]) - delta
		p["v"] = (p["v"] as Vector2) * 0.97 + Vector2(0, 600) * delta
		p["p"] = (p["p"] as Vector2) + (p["v"] as Vector2) * delta
		if float(p["life"]) <= 0.0:
			particles.remove_at(i)
	for i in range(popups.size() - 1, -1, -1):
		var q: Dictionary = popups[i]
		q["life"] = float(q["life"]) - delta
		q["p"] = (q["p"] as Vector2) + Vector2(0, -60) * delta
		if float(q["life"]) <= 0.0:
			popups.remove_at(i)


# ------------------------------------------------------------------ DESSIN
func _draw() -> void:
	buttons.clear()
	var off := Vector2.ZERO
	if shake > 0.0:
		off = Vector2(randf_range(-1, 1), randf_range(-1, 1)) * shake * 14.0
	if screen == Screen.SPLASH:
		_draw_splash()
		return
	draw_set_transform(off)
	_draw_pitch()
	match screen:
		Screen.MENU:
			draw_set_transform(Vector2.ZERO)
			_draw_menu()
		Screen.LEVELS:
			draw_set_transform(Vector2.ZERO)
			_draw_levels()
		Screen.KITS:
			draw_set_transform(Vector2.ZERO)
			_draw_kits()
		Screen.LOBBY:
			draw_set_transform(Vector2.ZERO)
			_draw_lobby()
		Screen.GAME:
			_draw_game()
			draw_set_transform(Vector2.ZERO)
			_draw_hud()


func _draw_pitch() -> void:
	var vh := maxf(H, get_viewport_rect().size.y)
	draw_rect(Rect2(-40, -40, W + 80, vh + 80), Color(0.13, 0.45, 0.18))
	for i in 14:
		if i % 2 == 0:
			draw_rect(Rect2(0, i * 100.0, W, 100), Color(0.15, 0.5, 0.2))
	var lc := Color(1, 1, 1, 0.75)
	draw_rect(Rect2(30, GOAL_Y, W - 60, 1110), lc, false, 4.0)
	draw_rect(Rect2(130, GOAL_Y, 460, 280), lc, false, 4.0)
	draw_rect(Rect2(230, GOAL_Y, 260, 110), lc, false, 4.0)
	draw_circle(Vector2(360, 360), 5, lc)
	draw_arc(Vector2(360, 380), 110, deg_to_rad(30), deg_to_rad(150), 32, lc, 4.0)
	draw_line(Vector2(30, 1260), Vector2(690, 1260), lc, 4.0)
	draw_arc(Vector2(360, 1260), 130, PI, TAU, 40, lc, 4.0)
	# But + filet
	var wob := sin(t * 30.0) * 6.0 * net_wobble
	var net := Rect2(GOAL_L, GOAL_Y - 70 - wob, GOAL_R - GOAL_L, 70 + wob)
	draw_rect(net, Color(1, 1, 1, 0.08))
	var nc := Color(1, 1, 1, 0.35)
	var x := GOAL_L
	while x <= GOAL_R:
		draw_line(Vector2(x, GOAL_Y), Vector2(x, net.position.y), nc, 1.5)
		x += 18.0
	var y := net.position.y
	while y <= GOAL_Y:
		draw_line(Vector2(GOAL_L, y), Vector2(GOAL_R, y), nc, 1.5)
		y += 14.0
	draw_line(Vector2(GOAL_L, GOAL_Y), Vector2(GOAL_L, GOAL_Y - 72), Color.WHITE, 8.0)
	draw_line(Vector2(GOAL_R, GOAL_Y), Vector2(GOAL_R, GOAL_Y - 72), Color.WHITE, 8.0)
	draw_line(Vector2(GOAL_L - 4, GOAL_Y - 72), Vector2(GOAL_R + 4, GOAL_Y - 72), Color.WHITE, 8.0)


func _draw_player(p: Vector2, col: Color, num: String, highlight: bool, accent: Color = DARK) -> void:
	draw_circle(p + Vector2(4, 6), PLAYER_R, Color(0, 0, 0, 0.3))
	if highlight:
		var pulse := 6.0 + sin(t * 6.0) * 3.0
		draw_arc(p, PLAYER_R + pulse, 0, TAU, 32, Color(1, 1, 1, 0.8), 3.0)
	draw_circle(p, PLAYER_R, col)
	if accent != DARK:
		draw_arc(p, PLAYER_R - 4, 0, TAU, 32, accent, 6.0)
	draw_arc(p, PLAYER_R, 0, TAU, 32, DARK, 3.0)
	draw_circle(p + Vector2(0, -6), 10, Color(0.36, 0.22, 0.14))
	_text(p + Vector2(0, 16), num, 18, accent)


func _draw_ball(ground: Vector2, h: float = 0.0) -> void:
	var sc := 1.0 + h / 220.0
	var p := ground + Vector2(0, -h * 0.5)
	draw_circle(ground + Vector2(3, 5), BALL_R * (1.0 - h / 400.0), Color(0, 0, 0, 0.35 - h / 800.0))
	draw_circle(p, BALL_R * sc, Color.WHITE)
	for i in 5:
		var a := ball_rot + i * TAU / 5.0
		draw_circle(p + Vector2(cos(a), sin(a)) * 7.0 * sc, 3.2 * sc, DARK)
	draw_circle(p, 4.0 * sc, DARK)
	draw_arc(p, BALL_R * sc, 0, TAU, 24, DARK, 1.5)


func _draw_game() -> void:
	# trajectoire en cours de tracé
	if phase == Phase.DRAW and draw_pts.size() > 1:
		var preview := _smooth(draw_pts)
		var acc := 0.0
		for i in range(1, preview.size()):
			acc += preview[i].distance_to(preview[i - 1])
			if int(acc / 22.0) % 2 == 0:
				draw_line(preview[i - 1], preview[i], Color(0.55, 0.85, 1.0, 0.95) if lob_mode else Color(1, 1, 1, 0.9), 7.0)
		var e := draw_pts[draw_pts.size() - 1]
		var near_mate := false
		for i in team.size():
			if i != holder and e.distance_to(team[i]) < 85.0:
				near_mate = true
		draw_circle(e, 12, GOLD if near_mate else Color(1, 1, 1, 0.9))
	# trajectoire suivie (fantôme)
	if phase == Phase.FLIGHT and flight_pts.size() > 1:
		draw_polyline(flight_pts, Color(1, 1, 1, 0.12), 4.0)

	# coéquipiers
	for i in team.size():
		var hl := (phase == Phase.AIM and i != holder)
		var kd: Dictionary = kits[kit]
		_draw_player(team[i], kd["main"], str(i + 7), hl, kd["acc"])
	# défenseurs
	for d in defenders:
		_draw_player((d as Dictionary)["pos"], OPP_COL, "", false)
	# gardien
	var kp := Vector2(keeper_x, GOAL_Y + 22)
	draw_rect(Rect2(kp.x - 36, kp.y - 8, 72, 16), KEEPER_COL.darkened(0.2))
	draw_circle(kp, 22, KEEPER_COL)
	draw_arc(kp, 22, 0, TAU, 28, DARK, 3.0)
	draw_circle(kp + Vector2(-38, 0), 8, Color(0.95, 0.95, 0.95))
	draw_circle(kp + Vector2(38, 0), 8, Color(0.95, 0.95, 0.95))

	# traînée + ballon
	for i in trail.size():
		var a := float(i) / maxi(1, trail.size())
		draw_circle(trail[i], BALL_R * a, Color(1, 1, 1, 0.35 * a))
	_draw_ball(ball, flight_h)

	# indice de début
	if phase == Phase.AIM and passes == 0 and attempts_left == attempts_max:
		var a2 := 0.5 + 0.5 * sin(t * 4.0)
		_text(ball + Vector2(0, 110), "Glisse depuis le ballon", 26, Color(1, 1, 1, 0.5 + 0.5 * a2))

	# effets
	for p in particles:
		var pd: Dictionary = p
		var c: Color = pd["c"]
		c.a = clampf(float(pd["life"]), 0.0, 1.0)
		draw_rect(Rect2((pd["p"] as Vector2) - Vector2(5, 3), Vector2(10, 6)), c)
	for q in popups:
		var qd: Dictionary = q
		var c2: Color = qd["c"]
		c2.a = clampf(float(qd["life"]), 0.0, 1.0)
		_text(qd["p"], String(qd["text"]), 30, c2)


func _draw_hud() -> void:
	var L: Dictionary = _cur()
	draw_rect(Rect2(0, 0, W, 70), Color(0, 0, 0, 0.55))
	_button(Rect2(14, 10, 110, 50), "MENU", "pause", sb_dark, 22, GOLD)
	sb_dark.draw(get_canvas_item(), Rect2(14, 1150, 560, 70))
	if duel:
		var ok: Dictionary = kits[opp_kit_i]
		var mk: Dictionary = kits[kit]
		draw_circle(Vector2(178, 36), 11, mk["main"])
		_text(Vector2(330, 48), "Toi  %d  —  %d  Adv." % [challenge_goals, opp_goals], 30, Color.WHITE)
		draw_circle(Vector2(482, 36), 11, ok["main"])
		var dsec := int(ceil(challenge_time))
		_text(Vector2(W - 60, 50), "%d s" % dsec, 36, Color(1, 0.4, 0.4) if dsec <= 10 else GOLD)
		_text(Vector2(294, 1194), "Duel : mêmes situations que l'adversaire", 22, GOLD)
	elif challenge:
		_text(Vector2(330, 46), "DÉFI — %d but%s" % [challenge_goals, "s" if challenge_goals > 1 else ""], 28, Color.WHITE)
		var sec := int(ceil(challenge_time))
		var tc := Color(1, 0.4, 0.4) if sec <= 10 else GOLD
		_text(Vector2(W - 70, 50), "%d s" % sec, 36 if sec > 10 else int(36 + 6 * absf(sin(t * 8.0))), tc)
		_text(Vector2(294, 1194), "Record : %d  •  +3 s par but" % challenge_best, 24, GOLD)
	else:
		_text(Vector2(360, 46), "Niv. %d — %s" % [level_idx + 1, String(L["name"])], 26, Color.WHITE)
		_text(Vector2(294, 1194), _req_text(String(L["req"])), 24, GOLD)
	if phase == Phase.AIM or phase == Phase.DRAW:
		_button(Rect2(590, 1150, 116, 70), "LOB", "lob", sb_gold if lob_mode else sb_dark, 28, DARK if lob_mode else GOLD)
		if lob_mode:
			_text(Vector2(360, 1125), "Lob activé : passe par-dessus les défenseurs", 22, Color(0.55, 0.85, 1.0))
	# tentatives = ballons
	for i in (0 if challenge else attempts_max):
		var c := Color.WHITE if i < attempts_left else Color(1, 1, 1, 0.2)
		draw_circle(Vector2(W - 40 - i * 34, 35), 12, c)

	if duel and duel_countdown > 0.0:
		draw_rect(Rect2(0, 0, W, maxf(H, get_viewport_rect().size.y)), Color(0, 0, 0, 0.45))
		_text(Vector2(360, 560), "Prêts ?", 44, Color.WHITE)
		var cd := int(ceil(duel_countdown))
		var pulse: float = 1.0 + 0.3 * (ceilf(duel_countdown) - duel_countdown)
		_text(Vector2(360, 720), str(cd), int(170 * pulse), GOLD)
	if phase == Phase.RESULT:
		var s := 1.0 + 0.15 * sin(t * 12.0)
		draw_rect(Rect2(0, 560, W, 150), Color(0, 0, 0, 0.5))
		_text(Vector2(360, 660), msg, int(72 * s), msg_color)

	if phase == Phase.END:
		_draw_end()


func _draw_end() -> void:
	draw_rect(Rect2(0, 0, W, maxf(H, get_viewport_rect().size.y)), Color(0, 0, 0, 0.6))
	var box := Rect2(70, 360, 580, 560)
	sb_dark.draw(get_canvas_item(), box)
	if duel:
		_draw_end_duel()
		return
	if challenge:
		_text(Vector2(360, 450), "TEMPS ÉCOULÉ !", 56, GOLD)
		_text(Vector2(360, 580), str(challenge_goals), 120, Color.WHITE)
		_text(Vector2(360, 630), "but%s marqué%s" % ["s" if challenge_goals > 1 else "", "s" if challenge_goals > 1 else ""], 28, Color(1, 1, 1, 0.8))
		if challenge_record:
			_text(Vector2(360, 690), "NOUVEAU RECORD !", 34 + int(4 * sin(t * 6.0)), Color(0.55, 0.85, 1.0))
		else:
			_text(Vector2(360, 690), "Record : %d" % challenge_best, 30, Color(1, 1, 1, 0.7))
		_text(Vector2(360, 740), "Points : %d" % challenge_points, 26, Color(1, 1, 1, 0.7))
		_button(Rect2(110, 780, 240, 90), "MENU", "back_menu", sb_dark, 28, GOLD)
		_button(Rect2(370, 780, 240, 90), "REJOUER", "retry", sb_gold, 30, DARK)
		return
	if end_win:
		_text(Vector2(360, 450), "VICTOIRE !", 64, GOLD)
		for i in 3:
			_star(Vector2(240 + i * 120, 560), 44.0, i < end_stars)
		_text(Vector2(360, 680), "Score : %d" % end_score, 34, Color.WHITE)
		_text(Vector2(360, 725), "Passes : %d" % passes, 24, Color(1, 1, 1, 0.7))
		if level_idx + 1 < levels.size():
			_button(Rect2(110, 780, 240, 90), "REJOUER", "retry", sb_dark, 28, GOLD)
			_button(Rect2(370, 780, 240, 90), "SUIVANT", "next", sb_gold, 30, DARK)
		else:
			_button(Rect2(110, 780, 240, 90), "REJOUER", "retry", sb_dark, 28, GOLD)
			_button(Rect2(370, 780, 240, 90), "NIVEAUX", "levels", sb_gold, 30, DARK)
	else:
		_text(Vector2(360, 470), "RATÉ...", 64, Color(1, 0.45, 0.45))
		_text(Vector2(360, 560), "Plus de tentatives.", 30, Color.WHITE)
		_text(Vector2(360, 610), "Astuce : courbe ta trajectoire", 24, Color(1, 1, 1, 0.7))
		_text(Vector2(360, 645), "pour tromper le gardien !", 24, Color(1, 1, 1, 0.7))
		_button(Rect2(110, 780, 240, 90), "NIVEAUX", "levels", sb_dark, 28, GOLD)
		_button(Rect2(370, 780, 240, 90), "REJOUER", "retry", sb_gold, 30, DARK)


func _draw_end_duel() -> void:
	var title := "TEMPS ÉCOULÉ !"
	var tcol := GOLD
	if opp_done:
		if challenge_goals > opp_goals:
			title = "VICTOIRE !"
		elif challenge_goals < opp_goals:
			title = "DÉFAITE"
			tcol = Color(1, 0.45, 0.45)
		else:
			title = "ÉGALITÉ"
			tcol = Color.WHITE
	elif duel_msg != "":
		title = "PARTIE INTERROMPUE"
		tcol = Color(1, 0.45, 0.45)
	_text(Vector2(360, 450), title, 56 if title.length() < 16 else 42, tcol)
	_text(Vector2(250, 600), str(challenge_goals), 110, Color.WHITE)
	_text(Vector2(360, 590), "—", 60, Color(1, 1, 1, 0.5))
	_text(Vector2(470, 600), str(opp_goals) if (opp_done or duel_msg == "") else "?", 110, Color.WHITE)
	var mk: Dictionary = kits[kit]
	var ok: Dictionary = kits[opp_kit_i]
	draw_circle(Vector2(215, 637), 9, mk["main"])
	_text(Vector2(258, 646), "Toi", 26, Color(1, 1, 1, 0.8))
	draw_circle(Vector2(405, 637), 9, ok["main"])
	_text(Vector2(488, 646), "Adversaire", 26, Color(1, 1, 1, 0.8))
	if duel_msg != "":
		_text(Vector2(360, 720), duel_msg, 26, Color(1, 0.6, 0.6))
	elif not opp_done:
		var dots: String = ["", ".", "..", "..."][int(t * 2.0) % 4]
		_text(Vector2(360, 720), "L'adversaire joue encore" + dots, 26, Color(1, 1, 1, 0.75))
	_button(Rect2(110, 780, 240, 90), "QUITTER", "duel_quit", sb_dark, 28, GOLD)
	if opp_done and duel_msg == "" and bool(duel_net.call("connected")):
		if duel_rematch_sent:
			_button(Rect2(370, 780, 240, 90), "DEMANDÉE…", "duel_rematch", sb_dark, 26, GOLD)
		else:
			_button(Rect2(370, 780, 240, 90), "REVANCHE", "duel_rematch", sb_gold, 30, DARK)


func _draw_lobby() -> void:
	var vh := maxf(H, get_viewport_rect().size.y)
	draw_rect(Rect2(0, 0, W, vh), Color(0, 0, 0, 0.6))
	_button(Rect2(20, 20, 130, 60), "RETOUR", "lobby_back", sb_dark, 22, GOLD)
	_text(Vector2(360, 150), "DUEL", 70, GOLD)
	_text(Vector2(360, 200), "2 téléphones  •  même Wi-Fi", 26, Color(1, 1, 1, 0.8))
	var dots: String = ["", ".", "..", "..."][int(t * 2.0) % 4]
	match lobby_state:
		"choose":
			var lines := ["Connecte les 2 téléphones au même Wi-Fi", "(ou au point d'accès de l'un des deux).",
				"Chacun joue 60 s sur les MÊMES situations :", "celui qui marque le plus gagne !"]
			for i in lines.size():
				_text(Vector2(360, 280 + i * 40), String(lines[i]), 24, Color.WHITE)
			_button(Rect2(140, 480, 440, 100), "CRÉER LA PARTIE", "lobby_host", sb_gold, 34, DARK)
			_button(Rect2(140, 600, 440, 100), "REJOINDRE", "lobby_join", sb_dark, 34, GOLD)
			_text(Vector2(360, 760), "L'un crée la partie, l'autre la rejoint.", 22, Color(1, 1, 1, 0.6))
		"hosting":
			_text(Vector2(360, 300), "Partie créée !", 40, GOLD)
			_text(Vector2(360, 370), "Ton adresse :", 26, Color.WHITE)
			var ips: Array = duel_net.call("local_ips")
			if ips.is_empty():
				_text(Vector2(360, 430), "Pas de réseau Wi-Fi détecté", 28, Color(1, 0.6, 0.6))
			for i in mini(ips.size(), 3):
				_text(Vector2(360, 430 + i * 50), String(ips[i]), 42, GOLD)
			_text(Vector2(360, 640), "En attente de l'adversaire" + dots, 28, Color.WHITE)
			_text(Vector2(360, 690), "Sur l'autre téléphone : DUEL À DEUX → REJOINDRE", 22, Color(1, 1, 1, 0.6))
			_button(Rect2(220, 800, 280, 90), "ANNULER", "lobby_cancel", sb_dark, 28, GOLD)
		"joining":
			_text(Vector2(360, 290), "Recherche des parties" + dots, 30, Color.WHITE)
			var found: Array = duel_net.call("found_hosts")
			if found.is_empty():
				_text(Vector2(360, 420), "Aucune partie trouvée pour l'instant.", 24, Color(1, 1, 1, 0.6))
				_text(Vector2(360, 460), "Sinon, saisis l'adresse affichée", 24, Color(1, 1, 1, 0.6))
				_text(Vector2(360, 495), "sur le téléphone hôte.", 24, Color(1, 1, 1, 0.6))
			for i in mini(found.size(), 3):
				_button(Rect2(110, 340 + i * 110, 500, 90), "Rejoindre %s" % String(found[i]), "host_%s" % String(found[i]), sb_gold, 28, DARK)
			_button(Rect2(140, 720, 440, 90), "SAISIR L'ADRESSE", "lobby_keypad", sb_dark, 30, GOLD)
			_button(Rect2(220, 830, 280, 80), "ANNULER", "lobby_cancel", sb_dark, 26, GOLD)
		"keypad":
			sb_dark.draw(get_canvas_item(), Rect2(110, 250, 500, 95))
			var cursor := "|" if int(t * 2.0) % 2 == 0 else " "
			_text(Vector2(360, 313), ip_input + cursor, 44, Color.WHITE)
			var keys := ["1", "2", "3", "4", "5", "6", "7", "8", "9", ".", "0", "del"]
			for i in keys.size():
				var r := Rect2(140 + (i % 3) * 150, 370 + (i / 3) * 105, 135, 92)
				var key := String(keys[i])
				var lab := "EFF" if key == "del" else key
				_button(r, lab, "key_%s" % key, sb_dark, 40, GOLD)
			_button(Rect2(140, 800, 440, 95), "CONNEXION", "key_ok", sb_gold, 34, DARK)
			_button(Rect2(220, 910, 280, 80), "RETOUR", "lobby_join", sb_dark, 26, GOLD)
		"connecting":
			if bool(duel_net.call("connected")):
				_text(Vector2(360, 420), "Connecté !", 44, GOLD)
				_text(Vector2(360, 480), "Lancement de la partie" + dots, 28, Color.WHITE)
			else:
				_text(Vector2(360, 420), "Connexion à", 30, Color.WHITE)
				_text(Vector2(360, 480), join_ip + dots, 40, GOLD)
			_button(Rect2(220, 800, 280, 90), "ANNULER", "lobby_cancel", sb_dark, 28, GOLD)
	if lobby_err != "":
		_text(Vector2(360, 1030), lobby_err, 26, Color(1, 0.55, 0.55))


func _draw_menu() -> void:
	var vh := maxf(H, get_viewport_rect().size.y)
	draw_rect(Rect2(0, 0, W, vh), Color(0, 0, 0, 0.45))
	_text(Vector2(360, 330), "VIBE", 120, GOLD)
	_text(Vector2(360, 450), "STRIKE", 120, Color.WHITE)
	_text(Vector2(360, 510), "Trace. Passe. Marque.", 30, Color(1, 1, 1, 0.75))
	var bounce := absf(sin(t * 3.0)) * 60.0
	ball_rot += 0.02
	_draw_ball(Vector2(360, 610), bounce * 0.6)
	_button(Rect2(160, 670, 400, 95), "CARRIÈRE", "play", sb_gold, 40, DARK)
	_button(Rect2(160, 778, 400, 82), "DÉFI 60 s", "challenge", sb_dark, 32, GOLD)
	_button(Rect2(160, 872, 400, 82), "DUEL À DEUX", "duel", sb_dark, 32, GOLD)
	_button(Rect2(160, 966, 400, 82), "MAILLOTS", "kits", sb_dark, 32, GOLD)
	_text(Vector2(360, 1088), "Score : %d   •   Étoiles : %d   •   Record défi : %d" % [total_score, _total_stars(), challenge_best], 22, Color.WHITE)
	_button(Rect2(560, 20, 140, 60), "SON : OUI" if sound_on else "SON : NON", "sound", sb_dark, 20, GOLD)
	_draw_emblem(Vector2(360, 1178), 0.32, 1.0)


func _draw_splash() -> void:
	var vh := maxf(H, get_viewport_rect().size.y)
	draw_rect(Rect2(-40, -40, W + 80, vh + 80), DARK)
	var a := clampf(splash_t / 0.6, 0.0, 1.0) * clampf((2.6 - splash_t) / 0.5, 0.0, 1.0)
	var s := 0.9 + 0.1 * clampf(splash_t / 0.6, 0.0, 1.0)
	# halo doré
	for i in 6:
		draw_circle(Vector2(360, 560), 260.0 - i * 30.0, Color(GOLD.r, GOLD.g, GOLD.b, 0.025 * a))
	_draw_emblem(Vector2(360, 560), s, a)
	_text(Vector2(360, 860), "présente", 30, Color(1, 1, 1, 0.6 * a))


func _draw_emblem(c: Vector2, s: float, a: float) -> void:
	if logo_tex:
		var sz := logo_tex.get_size()
		var k := (340.0 * s) / maxf(sz.x, sz.y)
		draw_texture_rect(logo_tex, Rect2(c - sz * k / 2.0, sz * k), false, Color(1, 1, 1, a))
		return
	var g := Color(GOLD.r, GOLD.g, GOLD.b, a)
	draw_arc(c, 150.0 * s, 0, TAU, 64, g, 8.0 * s)
	draw_arc(c, 132.0 * s, 0, TAU, 64, Color(g.r, g.g, g.b, 0.5 * a), 2.5 * s)
	_text(c + Vector2(0, 30.0 * s), "DL", int(140 * s), g)
	_text(c + Vector2(0, 205.0 * s), "V I B E   S T U D I O", int(36 * s), g)


func _draw_kits() -> void:
	var vh := maxf(H, get_viewport_rect().size.y)
	draw_rect(Rect2(0, 0, W, vh), Color(0, 0, 0, 0.55))
	_button(Rect2(20, 20, 130, 60), "RETOUR", "back_menu", sb_dark, 22, GOLD)
	_text(Vector2(360, 140), "MAILLOTS", 60, GOLD)
	_text(Vector2(360, 190), "Tes étoiles : %d   •   Record défi : %d" % [_total_stars(), challenge_best], 24, Color.WHITE)
	for i in kits.size():
		var k: Dictionary = kits[i]
		var r := Rect2(60 + (i % 2) * 310, 230 + (i / 2) * 235, 290, 215)
		var open := _kit_open(i)
		var sb := sb_gold if i == kit else (sb_dark if open else sb_lock)
		_button(r, "", "kit_%d" % i, sb, 20, GOLD)
		var c := r.get_center() + Vector2(0, -25)
		var main: Color = k["main"]
		var acc: Color = k["acc"]
		if not open:
			main = main.darkened(0.6)
			acc = acc.darkened(0.6)
		# grand aperçu du joueur
		draw_circle(c + Vector2(5, 7), 46, Color(0, 0, 0, 0.3))
		draw_circle(c, 46, main)
		draw_arc(c, 40, 0, TAU, 40, acc, 10.0)
		draw_arc(c, 46, 0, TAU, 40, DARK, 4.0)
		_text(c + Vector2(0, 14), "10", 34, acc)
		var tc := DARK if i == kit else Color.WHITE
		_text(Vector2(c.x, r.end.y - 48), String(k["name"]), 28, tc)
		var sub := ""
		if i == kit:
			sub = "Porté"
		elif open:
			sub = "Toucher pour porter"
		elif int(k["defi"]) > 0:
			sub = "Record défi %d buts" % int(k["defi"])
		else:
			sub = "%d étoiles requises" % int(k["stars"])
		_text(Vector2(c.x, r.end.y - 18), sub, 20, DARK if i == kit else Color(1, 1, 1, 0.6))


func _draw_levels() -> void:
	var vh := maxf(H, get_viewport_rect().size.y)
	draw_rect(Rect2(0, 0, W, vh), Color(0, 0, 0, 0.5))
	_button(Rect2(20, 20, 130, 60), "RETOUR", "back_menu", sb_dark, 22, GOLD)
	_text(Vector2(360, 140), "CARRIÈRE", 60, GOLD)
	_button(Rect2(70, 170, 280, 66), "SAISON 1", "season0", sb_gold if season == 0 else sb_dark, 26, DARK if season == 0 else GOLD)
	var s2_open := unlocked > 10
	_button(Rect2(370, 170, 280, 66), "SAISON 2", "season1",
		(sb_gold if season == 1 else sb_dark) if s2_open else sb_lock, 26,
		(DARK if season == 1 else GOLD) if s2_open else Color(0.6, 0.6, 0.6))
	var got := 0
	for i in range(season * 10, mini(season * 10 + 10, levels.size())):
		got += int(best_stars[i])
	_text(Vector2(360, 280), "%s  —  %d / 30 étoiles" % [String(SEASON_NAMES[season]), got], 24, Color.WHITE)
	var cols := 3
	for i in range(season * 10, mini(season * 10 + 10, levels.size())):
		var j := i - season * 10
		var cx := j % cols
		var cy := j / cols
		var r := Rect2(70 + cx * 200, 310 + cy * 215, 180, 190)
		var open := i < unlocked
		_button(r, "", "lvl_%d" % i, sb_dark if open else sb_lock, 20, GOLD)
		if open:
			_text(r.position + Vector2(90, 95), str(i + 1), 64, Color.WHITE)
			for s in 3:
				_star(r.position + Vector2(45 + s * 45, 145), 16.0, s < int(best_stars[i]))
		else:
			# cadenas
			var c := r.get_center()
			draw_arc(c + Vector2(0, -12), 22, PI, TAU, 16, Color(0.6, 0.6, 0.6), 7.0)
			draw_rect(Rect2(c.x - 30, c.y - 12, 60, 46), Color(0.6, 0.6, 0.6))


# ------------------------------------------------------------------ OUTILS UI
func _text(center_baseline: Vector2, s: String, size: int, col: Color) -> void:
	var w := 1400.0
	draw_string(font, Vector2(center_baseline.x - w / 2.0, center_baseline.y), s,
		HORIZONTAL_ALIGNMENT_CENTER, w, size, col)


func _button(r: Rect2, label: String, id: String, sb: StyleBoxFlat, size: int, col: Color) -> void:
	sb.draw(get_canvas_item(), r)
	if label != "":
		_text(Vector2(r.get_center().x, r.get_center().y + size * 0.36), label, size, col)
	buttons.append({"rect": r, "id": id})


func _star(c: Vector2, r: float, filled: bool) -> void:
	var pts := PackedVector2Array()
	for i in 10:
		var rad := r if i % 2 == 0 else r * 0.45
		var a := -PI / 2.0 + i * PI / 5.0
		pts.append(c + Vector2(cos(a), sin(a)) * rad)
	if filled:
		draw_colored_polygon(pts, GOLD)
	else:
		draw_colored_polygon(pts, Color(1, 1, 1, 0.15))
	pts.append(pts[0])
	draw_polyline(pts, DARK, 2.0)


# ------------------------------------------------------------------ SAUVEGARDE
func _save() -> void:
	var cf := ConfigFile.new()
	cf.set_value("progress", "unlocked", unlocked)
	cf.set_value("progress", "stars", best_stars)
	cf.set_value("progress", "score", total_score)
	cf.set_value("settings", "sound", sound_on)
	cf.set_value("settings", "kit", kit)
	cf.set_value("settings", "last_ip", ip_input)
	cf.set_value("progress", "challenge_best", challenge_best)
	cf.save(SAVE_PATH)


func _load() -> void:
	var cf := ConfigFile.new()
	if cf.load(SAVE_PATH) != OK:
		return
	unlocked = int(cf.get_value("progress", "unlocked", 1))
	total_score = int(cf.get_value("progress", "score", 0))
	sound_on = bool(cf.get_value("settings", "sound", true))
	kit = clampi(int(cf.get_value("settings", "kit", 0)), 0, kits.size() - 1)
	challenge_best = int(cf.get_value("progress", "challenge_best", 0))
	ip_input = String(cf.get_value("settings", "last_ip", "192.168."))
	var s: Array = cf.get_value("progress", "stars", [])
	for i in mini(s.size(), best_stars.size()):
		best_stars[i] = int(s[i])
