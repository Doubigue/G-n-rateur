# Vibe Strike — DL VIBE STUDIO

Jeu de foot mobile Godot 4.3 inspiré de Score! Hero : on trace la trajectoire du ballon au doigt.

## Jouer
- Glisse depuis le ballon pour dessiner sa trajectoire.
- Termine le tracé sur un coéquipier (cercle doré) → **passe**.
- Sinon c'est un **tir** : le ballon suit ta courbe puis continue tout droit.
- Le gardien lit la direction du ballon : un tir **enroulé** le trompe (+300).
- Les défenseurs rouges interceptent tout ce qui passe sur eux.
- 10 niveaux, étoiles selon les tentatives utilisées, progression sauvegardée.

## Duel à deux (v1.4)
- **2 téléphones sur le même Wi-Fi** (ou le point d'accès de l'un des deux). Aucun Internet nécessaire.
- Menu → DUEL À DEUX → l'un fait **CRÉER LA PARTIE**, l'autre **REJOINDRE** : la partie est trouvée automatiquement, sinon saisir l'adresse affichée sur l'hôte.
- Compte à rebours 3-2-1, puis 60 s chacun sur les **mêmes situations** (même graine aléatoire) ; score de l'adversaire en direct, verdict, revanche.
- Réseau : ENet port 7777 + annonce UDP port 7778 (`scripts/duel.gd`). Permissions Android Internet/Wi-Fi ajoutées au preset.

## Défi & maillots (v1.3)
- **Défi 60 s** : situations générées au hasard, de plus en plus dures (gardien plus rapide, plus de défenseurs). +3 s par but, record sauvegardé.
- **Maillots** : 8 tenues (Or Vibe, Abidjan, Nuit, Océan, Émeraude, Royal, Légende, Néon Défi) débloquées avec les étoiles de la carrière ou le record du Défi.

## Lob & carrière (v1.2)
- Bouton **LOB** (en bas à droite) : le prochain tir ou la prochaine passe passe par-dessus les défenseurs et les murs. Trace jusque dans le but pour lober le gardien ; un lob qui retombe trop tôt roule et peut être arrêté, un lob trop haut passe « Au-dessus ! ». But en lob : +250.
- **Carrière** en 2 saisons (20 niveaux). La Saison 2 « Coupe Continentale » se débloque après le niveau 10.
- Objectifs par niveau : marquer, marquer sur un lob, ou faire N passes avant de marquer.

## Son et logo
- Sons synthétisés en code (`scripts/sfx.gd`) : frappe, passe, sifflet, poteau, foule qui exulte, déception, ambiance de stade. Bouton SON : OUI/NON dans le menu.
- Intro « DL VIBE STUDIO présente » (touche pour passer).
- Mets ton logo dans `assets/logo.png` : il remplace l'emblème dessiné, sur l'intro et le menu.

## Structure
- `project.godot` — portrait 720×1280, rendu Compatibilité (mobile)
- `scenes/main.tscn` + `scripts/main.gd` — tout le jeu (dessiné en code, aucun asset)
- `export_presets.cfg` — preset Android (com.dlvibestudio.vibestrike)

## Ajouter un niveau
Dans `_build_levels()` : `_lvl(nom, [positions coéquipiers], [[pos défenseur, amplitude, vitesse]], vitesse gardien, tentatives, objectif)` — objectif : `""`, `"lob"` ou `"pass2"`, `"pass3"`… `_wall(y, x_départ, nombre)` crée un mur de défenseurs..
