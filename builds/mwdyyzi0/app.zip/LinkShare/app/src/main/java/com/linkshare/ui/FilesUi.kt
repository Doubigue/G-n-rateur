package com.linkshare.ui

import android.Manifest
import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.os.StatFs
import android.os.storage.StorageManager
import android.provider.Settings
import android.text.format.Formatter
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.collectIsDraggedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.linkshare.R
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.decode.VideoFrameDecoder
import coil.request.ImageRequest
import coil.request.videoFramePercent
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import com.linkshare.core.*
import com.linkshare.server.ShareService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.absoluteValue

// ═══════════════════════════ Navigation ═══════════════════════════

enum class Screen { HOME, BROWSE, VAULT, APPS, SHARE, RECEIVE, SETTINGS, TRASH, VOLUMES, CLEANER }

/** État de navigation de l'explorateur (survit à la recréation de l'activité). */
object FilesNav {
    var screen by mutableStateOf(Screen.HOME)
    var shareSheet by mutableStateOf(false)
}

private class HomeActions(
    val openShareSheet: () -> Unit,
    val scanDoc: () -> Unit,
    val vault: () -> Unit,
    val apps: () -> Unit,
    val showQr: () -> Unit,
    val stopShare: () -> Unit,
    val settings: () -> Unit,
    val openWeb: () -> Unit,
    val volumes: () -> Unit,
    val cleaner: () -> Unit,
)

// ═══════════════════════════ Racine ═══════════════════════════

@Composable
fun FilesApp(vm: MainViewModel) {
    val ctx = LocalContext.current
    val ex: ExplorerViewModel = viewModel()
    val nav = FilesNav
    val info by ShareState.info.collectAsState()
    val granted = remember(AppEvents.resumeTick) { Environment.isExternalStorageManager() }
    var confirmDelete by remember { mutableStateOf(false) }
    var linkDialog by remember { mutableStateOf(false) }
    var webDialog by remember { mutableStateOf(false) }

    // Dossier demandé par une autre appli (« Ouvrir dans le gestionnaire de fichiers », Téléchargements…)
    LaunchedEffect(ExternalOpen.folder) {
        ExternalOpen.folder?.let { ex.enter(it); nav.screen = Screen.BROWSE; ExternalOpen.folder = null }
    }

    fun goHome() { ex.leave(); nav.screen = Screen.HOME; ex.loadSizes(); ex.loadRecents() }

    LaunchedEffect(granted, AppEvents.resumeTick) {
        if (granted) {
            ex.refresh(); ex.loadSizes()
            // « LinkShare » apparaît (ou disparaît) dans le sélecteur de fichiers des autres applis
            runCatching { ctx.contentResolver.notifyChange(android.provider.DocumentsContract.buildRootsUri("${ctx.packageName}.documents"), null) }
        }
    }
    LaunchedEffect(ex.message) { ex.message?.let { Toast.makeText(ctx, it, Toast.LENGTH_LONG).show(); ex.message = null } }
    LaunchedEffect(vm.message) { vm.message?.let { Toast.makeText(ctx, it, Toast.LENGTH_LONG).show(); vm.message = null } }
    // Le dossier sécurisé se referme dès que l'app quitte l'écran
    LaunchedEffect(VaultLock.unlocked) { if (!VaultLock.unlocked && nav.screen == Screen.VAULT) goHome() }

    // ── Dossier sécurisé : verrouillage du téléphone, ou schéma / code propre au coffre (Paramètres)
    var vaultPrompt by remember { mutableStateOf<VaultMode?>(null) }
    fun unlockVault() {
        vaultPrompt = null
        ex.selected.clear(); VaultLock.unlocked = true; ex.loadVault(); nav.screen = Screen.VAULT
    }
    val authLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) unlockVault()
    }
    fun openVault() {
        if (VaultLock.unlocked) { ex.loadVault(); nav.screen = Screen.VAULT; return }
        val mode = VaultAuth.mode(ctx)
        if (mode != VaultMode.PHONE) { vaultPrompt = mode; return }
        val km = ctx.getSystemService(KeyguardManager::class.java)
        val intent = if (km.isDeviceSecure)
            km.createConfirmDeviceCredentialIntent("Dossier sécurisé", "Déverrouille ton téléphone pour ouvrir le dossier sécurisé")
        else null
        if (intent == null) Toast.makeText(ctx, "Configure d'abord un verrouillage d'écran (code, schéma ou mot de passe)", Toast.LENGTH_LONG).show()
        else authLauncher.launch(intent)
    }

    // ── Scanner de documents (bouton de droite de la pilule)
    val scanLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            GmsDocumentScanningResult.fromActivityResultIntent(r.data)?.pdf?.uri?.let { ex.saveScan(it); nav.screen = Screen.BROWSE }
        }
    }
    fun scanDoc() {
        if (!ensureAllFiles(ctx)) return
        val act = ctx.findActivity() ?: return
        val opts = GmsDocumentScannerOptions.Builder()
            .setGalleryImportAllowed(true).setPageLimit(20)
            .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_PDF)
            .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL).build()
        GmsDocumentScanning.getClient(opts).getStartScanIntent(act)
            .addOnSuccessListener { scanLauncher.launch(IntentSenderRequest.Builder(it).build()) }
            .addOnFailureListener { Toast.makeText(ctx, "Scanner indisponible : ${it.message}", Toast.LENGTH_LONG).show() }
    }

    // ── Partage LinkShare (bouton de gauche de la pilule)
    // Envoyer : bouton « Activer le point d'accès » puis QR. Recevoir : préparer le Wi-Fi puis scanner.
    fun shareNow() { if (ensureAllFiles(ctx)) nav.screen = Screen.SHARE }
    fun receiveNow() { if (ensureAllFiles(ctx)) nav.screen = Screen.RECEIVE }

    BackHandler(enabled = nav.screen != Screen.HOME) {
        when (nav.screen) {
            Screen.BROWSE -> if (!ex.back()) goHome()
            Screen.VAULT -> when {
                ex.selected.isNotEmpty() -> ex.selected.clear()
                ex.vaultUp() -> Unit
                else -> { ex.lockVault(); goHome() }
            }
            Screen.TRASH -> nav.screen = Screen.SETTINGS
            else -> goHome()
        }
    }

    val actions = HomeActions(
        openShareSheet = { nav.shareSheet = true },
        scanDoc = { scanDoc() },
        vault = { openVault() },
        apps = { nav.screen = Screen.APPS },
        showQr = { nav.screen = Screen.SHARE },
        stopShare = { ctx.stopService(Intent(ctx, ShareService::class.java)) },
        settings = { nav.screen = Screen.SETTINGS },
        openWeb = { webDialog = true },
        volumes = { nav.screen = Screen.VOLUMES },
        cleaner = { nav.screen = Screen.CLEANER },
    )

    Box(Modifier.fillMaxSize().background(LS.Bg)) {
        when (nav.screen) {
            Screen.HOME -> {
                HomeContent(ex, vm, info, granted, actions)
                ActionPill(
                    onShare = { nav.shareSheet = true },
                    onScan = { scanDoc() },
                    modifier = Modifier.align(Alignment.BottomCenter),
                )
            }
            Screen.BROWSE -> BrowseScreen(ex, onBack = { if (!ex.back()) goHome() }, onDelete = { if (UiStyle.confirmDelete) confirmDelete = true else ex.deleteSelected() })
            Screen.VAULT -> Box(Modifier.fillMaxSize().statusBarsPadding()) { VaultView(ex) }
            Screen.APPS -> AppsScreen(ex, onBack = { goHome() })
            Screen.SHARE -> SendPanel(onBack = { goHome() })
            Screen.RECEIVE -> ReceivePanel(onBack = { goHome() }) { c -> vm.connect(c); askBatteryExemptionOnce(ctx) }
            Screen.SETTINGS -> SettingsScreen(ex, onBack = { goHome() }, onTrash = { nav.screen = Screen.TRASH })
            Screen.TRASH -> TrashScreen(ex, onBack = { nav.screen = Screen.SETTINGS })
            Screen.VOLUMES -> VolumesScreen(ex, onBack = { goHome() }) { d -> ex.enter(d); nav.screen = Screen.BROWSE }
            Screen.CLEANER -> CleanerScreen(ex, onBack = { goHome() })
        }
        // Copier / déplacer : choix du dossier de destination
        ex.transfer?.let { FolderPicker(ex, it) }
    }

    if (nav.shareSheet) ShareSheet(
        active = info != null,
        onDismiss = { nav.shareSheet = false },
        onSend = { nav.shareSheet = false; shareNow() },
        onReceive = { nav.shareSheet = false; receiveNow() },
        onLink = { nav.shareSheet = false; linkDialog = true },
        onShowQr = { nav.shareSheet = false; nav.screen = Screen.SHARE },
    )

    if (webDialog) WebLinkDialog(onDismiss = { webDialog = false }) { u ->
        webDialog = false
        ExternalOpen.inApp = true; ExternalOpen.mime = null; ExternalOpen.uri = u
    }

    if (linkDialog) LinkDialog(onDismiss = { linkDialog = false }) { c ->
        linkDialog = false
        if (ensureAllFiles(ctx)) { vm.connect(c); askBatteryExemptionOnce(ctx) }
    }

    // Détails d'un fichier, d'un dossier ou d'une sélection
    FileInfoSheet(ex) { f ->
        ex.infoFiles = emptyList()
        f.parentFile?.let { ex.enter(it); nav.screen = Screen.BROWSE }
    }

    vaultPrompt?.let { m -> VaultUnlockDialog(m, onDismiss = { vaultPrompt = null }, onUnlocked = { unlockVault() }) }

    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("Supprimer ?") },
        text = { Text("${ex.selected.size} élément(s) seront placés dans la corbeille (restaurables pendant $TRASH_DAYS jours).") },
        confirmButton = { TextButton({ confirmDelete = false; ex.deleteSelected() }) { Text("Supprimer") } },
        dismissButton = { TextButton({ confirmDelete = false }) { Text("Annuler") } },
    )

    ex.zipPrompt?.let { z ->
        AlertDialog(
            onDismissRequest = { ex.zipPrompt = null },
            title = { Text(z.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            text = { Text("Décompresser cette archive dans un nouveau dossier ?") },
            confirmButton = { TextButton({ ex.zipPrompt = null; ex.extract(z) }) { Text("Décompresser") } },
            dismissButton = { TextButton({ ex.zipPrompt = null; ex.external(z) }) { Text("Ouvrir avec…") } },
        )
    }
}

// ═══════════════════════════ Pilule Partager / Scanner ═══════════════════════════

@Composable
private fun ActionPill(onShare: () -> Unit, onScan: () -> Unit, modifier: Modifier) {
    val ink = Color(0xFF1C1C1C)
    Row(
        modifier.navigationBarsPadding().padding(bottom = 18.dp)
            .clip(CircleShape).background(LS.Pill).padding(horizontal = 12.dp, vertical = 9.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onShare, Modifier.size(46.dp)) { Icon(Ic.ShareNearby, "Partager", Modifier.size(28.dp), tint = ink) }
        IconButton(onScan, Modifier.size(46.dp)) { Icon(Ic.ScanDoc, "Scanner un document", Modifier.size(28.dp), tint = ink) }
    }
}

// ═══════════════════════════ Feuille « Partager » (LinkShare) ═══════════════════════════

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ShareSheet(
    active: Boolean, onDismiss: () -> Unit, onSend: () -> Unit, onReceive: () -> Unit, onLink: () -> Unit, onShowQr: () -> Unit,
) {
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = LS.Card2, contentColor = LS.Text) {
        Column(Modifier.navigationBarsPadding().padding(horizontal = 12.dp).padding(bottom = 16.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text("Partager avec LinkShare", Modifier.padding(start = 8.dp, bottom = 8.dp), color = LS.Text, fontSize = 18.sp, fontWeight = FontWeight.Medium)
            if (active) SheetRow(Ic.Share, "Partage en cours", "Afficher le QR code", onShowQr)
            SheetRow(Ic.Send, "Envoyer", "Active le point d'accès et affiche le code à scanner", onSend)
            SheetRow(Ic.Scan, "Scanner", "Scanne le code de l'autre téléphone pour vous connecter", onReceive)
            SheetRow(Ic.Link, "Se connecter avec un lien", "Colle un lien linkshare://", onLink)
        }
    }
}

@Composable
private fun SheetRow(icon: ImageVector, title: String, sub: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(horizontal = 8.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(44.dp).clip(CircleShape).background(LS.Card), contentAlignment = Alignment.Center) {
            Icon(icon, null, Modifier.size(22.dp), tint = LS.Blue)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = LS.Text, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Text(sub, color = LS.Muted, fontSize = 12.sp)
        }
    }
}

// ═══════════════════════════ Accueil ═══════════════════════════

private class HomeCardData(val icon: ImageVector, val title: String, val sub: String?, val tint: Color = LS.Blue, val onClick: () -> Unit)

internal fun removableVolume(ctx: Context): File? =
    ctx.getSystemService(StorageManager::class.java).storageVolumes
        .firstOrNull { it.isRemovable && it.state == Environment.MEDIA_MOUNTED }?.directory

private fun typeLabel(c: Category) = when (c) {
    Category.VIDEOS -> "Vidéo"
    Category.PHOTOS -> "Image"
    Category.MUSIC -> "Audio"
    Category.DOCS -> "Document"
    Category.MORE -> "Fichier"
}

@Composable
private fun HomeContent(ex: ExplorerViewModel, vm: MainViewModel, info: ShareInfo?, granted: Boolean, a: HomeActions) {
    val ctx = LocalContext.current
    val nav = FilesNav
    val loader = remember { ImageLoader.Builder(ctx).components { add(VideoFrameDecoder.Factory()) }.crossfade(true).build() }
    val sd = remember(AppEvents.resumeTick) { removableVolume(ctx) }
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    // Nouvelle version publiée ? (vérifiée en silence au lancement, si une source est définie)
    LaunchedEffect(Unit) { AppUpdate.checkOnLaunch(ctx) }

    fun size(k: String) = ex.sizes[k]?.let { Formatter.formatShortFileSize(ctx, it) }
    fun browse(block: () -> Unit) { block(); nav.screen = Screen.BROWSE }
    val download = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)

    val categories = listOf(
        HomeCardData(Ic.Download, "Téléchargements", size("dl"), LS.Green) { browse { ex.enter(download) } },
        HomeCardData(Ic.Music, "Audio", size("aud"), LS.Purple) { browse { ex.enterCategory(LCat.AUDIO) } },
        HomeCardData(Ic.Doc, "Documents", size("doc"), LS.Blue) { browse { ex.enterCategory(LCat.DOCS) } },
        HomeCardData(Ic.Apps, "Applications", "Installées et APK", LS.Teal) { a.apps() },
    )
    val tools = listOf(
        HomeCardData(Ic.Archive, "Archives", "ZIP, RAR, 7z…", LS.Amber) { browse { ex.enterCategory(LCat.ARCHIVES) } },
        HomeCardData(Ic.BigFile, "Grands fichiers", "Plus de 50 Mo", LS.Orange) { browse { ex.enterCategory(LCat.LARGE) } },
        HomeCardData(Ic.Duplicate, "Doublons", "Fichiers identiques", LS.Pink) { browse { ex.enterCategory(LCat.DUPES) } },
        HomeCardData(Ic.Broom, "Nettoyeur", "Libérer de l'espace", LS.Green) { a.cleaner() },
    )

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = top + 12.dp, bottom = 130.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item(key = "logo") {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable { a.settings() },
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Image(painterResource(R.drawable.ic_logo), "Logo LinkShare", Modifier.size(42.dp).clip(RoundedCornerShape(13.dp)))
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("LinkShare", color = LS.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Explorateur de fichiers", color = LS.Muted, fontSize = 12.sp)
                }
                Spacer(Modifier.weight(1f))
                Icon(
                    Ic.Link, "Ouvrir un lien web",
                    Modifier.clip(CircleShape).clickable { a.openWeb() }.padding(8.dp).size(24.dp), tint = LS.Blue,
                )
                Icon(Ic.Settings, "Paramètres", Modifier.padding(end = 6.dp).size(24.dp), tint = LS.Muted)
            }
        }
        if (AppUpdate.available != null && !AppUpdate.dismissed) item(key = "update") { UpdateBanner() }
        vm.status?.let { s ->
            item(key = "status") {
                Column {
                    Text(s, color = LS.Text, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(4.dp))
                    LinearProgressIndicator(Modifier.fillMaxWidth(), color = LS.Blue)
                }
            }
        }
        if (!granted) item(key = "perm") {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(LS.Card).padding(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Icon(Ic.Folder, null, Modifier.size(48.dp), tint = LS.Blue)
                Text("L'explorateur a besoin de l'accès à tous les fichiers", color = LS.Text, fontSize = 14.sp, textAlign = TextAlign.Center)
                Button({ ensureAllFiles(ctx) }, colors = ButtonDefaults.buttonColors(containerColor = LS.Blue)) { Text("Autoriser", color = LS.OnBlue) }
            }
        }
        if (granted && UiStyle.showRecents && ex.recents.isNotEmpty()) {
            item(key = "h_recents") { Heading("Récents", plural(ex.recents.size, "fichier", "fichiers")) }
            item(key = "recents") { RecentsCarousel(ex, loader) }
        }
        if (info != null) item(key = "active") {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(LS.BlueLight)
                    .clickable { a.showQr() }.padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Ic.Share, null, Modifier.size(22.dp), tint = LS.Blue)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Partage actif", color = LS.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Text("${info.host}:${info.port} · toucher pour afficher le QR", color = LS.Muted, fontSize = 11.sp)
                }
                Text("Arrêter", Modifier.clickable { a.stopShare() }.padding(8.dp), color = LS.Blue, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
        }

        // ── Catégories : Images et Vidéos en diaporamas animés, puis les autres
        item(key = "h_cat") { Heading("Catégories") }
        item(key = "media") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MediaSlideCard(
                    "Images", size("img"), ex.homeImages, Ic.Image, LS.Pink, video = false, loader = loader,
                    startDelay = 0L, modifier = Modifier.weight(1f),
                ) { browse { ex.enterCategory(LCat.IMAGES) } }
                MediaSlideCard(
                    "Vidéos", size("vid"), ex.homeVideos, Ic.Video, LS.Red, video = true, loader = loader,
                    startDelay = 1200L, modifier = Modifier.weight(1f),
                ) { browse { ex.enterCategory(LCat.VIDEOS) } }
            }
        }
        item(key = "cat") { CardGrid(categories) }

        if (UiStyle.showTools) {
            item(key = "h_tools") { Heading("Outils") }
            item(key = "tools") { CardGrid(tools) }
        }

        // ── Stockage, en bas : jauge, puis Dossier sécurisé et Autres stockages côte à côte
        item(key = "h_sto") { Heading("Stockage") }
        item(key = "gauge") { StorageCard(ex) { browse { ex.enter(ex.root) } } }
        item(key = "sto") {
            CardGrid(
                listOf(
                    HomeCardData(Ic.Lock, "Dossier sécurisé", "Verrouillé", LS.Purple) { a.vault() },
                    HomeCardData(
                        if (sd != null) Ic.SdCard else Ic.Storage, "Autres stockages",
                        if (sd != null) "Carte SD détectée" else "Carte SD, clé USB", LS.Orange,
                    ) { a.volumes() },
                )
            )
        }
    }
}

/**
 * Carte de catégorie en diaporama : les dernières photos (ou vidéos) défilent toutes seules, avec un léger zoom.
 * Sans fichier, elle affiche simplement l'icône de la catégorie.
 */
@Composable
private fun MediaSlideCard(
    title: String, sub: String?, files: List<File>, icon: ImageVector, tint: Color, video: Boolean,
    loader: ImageLoader, startDelay: Long, modifier: Modifier, onClick: () -> Unit,
) {
    val anim = UiStyle.animations
    var idx by remember(files) { mutableIntStateOf(0) }
    LaunchedEffect(files, anim, UiStyle.carouselMs) {
        if (!anim || files.size < 2) return@LaunchedEffect
        delay(startDelay)
        while (true) {
            delay(UiStyle.carouselMs)
            idx = (idx + 1) % files.size
        }
    }
    val zoom = rememberInfiniteTransition(label = "zoom")
    val scale by zoom.animateFloat(
        1f, if (anim) 1.12f else 1f,
        infiniteRepeatable(tween(7000, easing = LinearEasing), RepeatMode.Reverse), label = "kenburns",
    )
    val shape = RoundedCornerShape(UiStyle.r(26.dp))
    Box(modifier.height(176.dp).lsCard(shape).clickable(onClick = onClick)) {
        if (files.isEmpty()) {
            Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(tint.copy(alpha = 0.32f), LS.Card))))
            IconBadge(icon, tint, 64.dp, Modifier.align(Alignment.Center).padding(bottom = 30.dp))
        } else {
            AnimatedContent(
                targetState = idx.coerceIn(0, files.lastIndex),
                transitionSpec = {
                    (slideInHorizontally(tween(650)) { it } + fadeIn(tween(650))) togetherWith
                        (slideOutHorizontally(tween(650)) { -it / 3 } + fadeOut(tween(650)))
                },
                label = "slide",
            ) { k ->
                val f = files[k]
                if (video) AnimatedVideoThumb(f, loader, Modifier.fillMaxSize(), animate = false)
                else AsyncImage(
                    model = f, contentDescription = null, imageLoader = loader,
                    modifier = Modifier.fillMaxSize().graphicsLayer { scaleX = scale; scaleY = scale }, contentScale = ContentScale.Crop,
                )
            }
            if (video) Box(
                Modifier.align(Alignment.Center).padding(bottom = 26.dp).size(42.dp).clip(CircleShape).background(Color(0x99000000)),
                contentAlignment = Alignment.Center,
            ) { Icon(Ic.Play, null, Modifier.size(24.dp), tint = Color.White) }
        }
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0.45f to Color.Transparent, 1f to Color(0xE0000000))))
        Row(Modifier.align(Alignment.BottomStart).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(34.dp).clip(RoundedCornerShape(11.dp)).background(tint), contentAlignment = Alignment.Center) {
                Icon(icon, null, Modifier.size(19.dp), tint = Color(0xFF1A1A1A))
            }
            Spacer(Modifier.width(10.dp))
            Column {
                Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                if (sub != null) Text(sub, color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp, maxLines = 1)
            }
        }
        if (files.size > 1) Text(
            "${idx + 1}/${files.size}",
            Modifier.align(Alignment.TopEnd).padding(10.dp).clip(CircleShape).background(Color(0x88000000))
                .padding(horizontal = 8.dp, vertical = 3.dp),
            color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold,
        )
    }
}

/**
 * Miniature de vidéo animée : plusieurs images de la vidéo défilent en fondu, avec un léger zoom (aperçu « vivant »).
 * Désactivable dans Paramètres › Animations.
 */
@Composable
internal fun AnimatedVideoThumb(
    f: File, loader: ImageLoader, modifier: Modifier,
    animate: Boolean = UiStyle.animations && UiStyle.videoPreview,
) {
    val ctx = LocalContext.current
    val frames = remember { listOf(0.12, 0.3, 0.5, 0.7, 0.88) }
    var i by remember(f.path) { mutableIntStateOf(0) }
    LaunchedEffect(f.path, animate) {
        if (!animate) { i = 0; return@LaunchedEffect }
        delay((300..1500).random().toLong())
        while (true) {
            delay(1500)
            i = (i + 1) % frames.size
        }
    }
    val zoom = rememberInfiniteTransition(label = "vzoom")
    val scale by zoom.animateFloat(
        1f, if (animate) 1.1f else 1f,
        infiniteRepeatable(tween(6000, easing = LinearEasing), RepeatMode.Reverse), label = "vscale",
    )
    Crossfade(i, modifier, animationSpec = tween(600), label = "frames") { k ->
        AsyncImage(
            model = ImageRequest.Builder(ctx).data(f).videoFramePercent(frames[k]).size(420).build(),
            contentDescription = null, imageLoader = loader,
            modifier = Modifier.fillMaxSize().graphicsLayer { scaleX = scale; scaleY = scale },
            contentScale = ContentScale.Crop,
        )
    }
}

@Composable
private fun Heading(title: String, trailing: String? = null) {
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(width = 4.dp, height = 18.dp).clip(CircleShape).background(LS.Blue))
        Spacer(Modifier.width(10.dp))
        Text(title, Modifier.weight(1f), color = LS.Text.copy(alpha = 0.94f), fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
        if (trailing != null) Text(trailing, color = LS.Muted, fontSize = 12.sp)
    }
}

@Composable
private fun CardGrid(cards: List<HomeCardData>) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        cards.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { c -> HomeCard(c, Modifier.weight(1f)) }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun HomeCard(c: HomeCardData, modifier: Modifier) {
    Row(
        modifier.height(72.dp).lsCard(RoundedCornerShape(UiStyle.r(22.dp)))
            .clickable(onClick = c.onClick).padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconBadge(c.icon, c.tint, 44.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(c.title, color = LS.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (c.sub != null) Text(c.sub, color = LS.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

// ═══════════════════════════ Jauge de stockage ═══════════════════════════

/** Carte « Stockage interne » : anneau de remplissage, espace libre et répartition par type de contenu. */
@Composable
private fun StorageCard(ex: ExplorerViewModel, onOpen: () -> Unit) {
    val ctx = LocalContext.current
    val space = remember(AppEvents.resumeTick) {
        runCatching { StatFs(Environment.getDataDirectory().path).let { it.totalBytes to it.availableBytes } }.getOrDefault(0L to 0L)
    }
    val total = space.first
    val free = space.second
    val used = (total - free).coerceAtLeast(0L)
    val frac = if (total > 0L) used.toFloat() / total else 0f
    val anim by animateFloatAsState(frac, tween(900), label = "stockage")
    val gauge = when {
        frac > 0.9f -> LS.Red
        frac > 0.75f -> LS.Orange
        else -> LS.Blue
    }
    val known = listOf(
        Triple("Images", ex.sizes["img"] ?: 0L, LS.Pink),
        Triple("Vidéos", ex.sizes["vid"] ?: 0L, LS.Red),
        Triple("Audio", ex.sizes["aud"] ?: 0L, LS.Purple),
        Triple("Documents", ex.sizes["doc"] ?: 0L, LS.Blue),
    )
    val other = (used - known.sumOf { it.second }).coerceAtLeast(0L)
    val parts = (known + Triple("Autres", other, LS.Teal)).filter { it.second > 0L }
    val shape = RoundedCornerShape(UiStyle.r(26.dp))

    Column(Modifier.fillMaxWidth().lsCard(shape).clickable(onClick = onOpen).padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(84.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val w = 9.dp.toPx()
                    val topLeft = Offset(w / 2, w / 2)
                    val arc = Size(size.width - w, size.height - w)
                    drawArc(LS.Card2, -90f, 360f, false, topLeft, arc, style = Stroke(w))
                    drawArc(gauge, -90f, 360f * anim, false, topLeft, arc, style = Stroke(w, cap = StrokeCap.Round))
                }
                Text("${(frac * 100).toInt()} %", color = LS.Text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text("Stockage interne", color = LS.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(2.dp))
                Text(
                    Formatter.formatShortFileSize(ctx, used) + " utilisés sur " + Formatter.formatShortFileSize(ctx, total),
                    color = LS.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(8.dp))
                Chip(Formatter.formatShortFileSize(ctx, free) + " libres", if (frac > 0.9f) LS.Red else LS.Green)
            }
            Icon(Ic.Chevron, "Parcourir", Modifier.size(22.dp), tint = LS.Muted)
        }
        if (total > 0L && parts.isNotEmpty()) {
            Spacer(Modifier.height(16.dp))
            // Barre segmentée : une couleur par type de contenu, le reste (gris) = espace libre
            Row(Modifier.fillMaxWidth().height(10.dp).clip(CircleShape).background(LS.Card2)) {
                parts.forEach { (_, bytes, color) ->
                    Box(Modifier.weight((bytes.toFloat() / total).coerceAtLeast(0.006f)).fillMaxHeight().background(color))
                }
                if (free > 0L) Spacer(Modifier.weight((free.toFloat() / total).coerceAtLeast(0.006f)))
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                parts.forEach { (label, bytes, color) ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(8.dp).clip(CircleShape).background(color))
                        Spacer(Modifier.width(6.dp))
                        Text(label, color = LS.Text, fontSize = 12.sp)
                        Spacer(Modifier.width(4.dp))
                        Text(Formatter.formatShortFileSize(ctx, bytes), color = LS.Muted, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

// ═══════════════════════════ Carrousel des fichiers récents ═══════════════════════════

/**
 * Carrousel : une grande carte au centre, les voisines dépassent sur les côtés (plus petites et estompées).
 * Il avance tout seul toutes les quelques secondes, jusqu'à ce qu'on le fasse glisser soi-même.
 */
@Composable
private fun RecentsCarousel(ex: ExplorerViewModel, loader: ImageLoader) {
    val list = ex.recents
    val pager = rememberPagerState { list.size }
    val dragged by pager.interactionSource.collectIsDraggedAsState()
    // Défilement automatique en boucle ; il se met en pause pendant qu'on fait glisser, puis reprend tout seul
    LaunchedEffect(list.size, dragged, UiStyle.animations, UiStyle.carouselMs) {
        if (dragged || !UiStyle.animations || list.size < 2) return@LaunchedEffect
        while (true) {
            delay(UiStyle.carouselMs)
            if (!pager.isScrollInProgress) {
                pager.animateScrollToPage((pager.currentPage + 1) % list.size, animationSpec = tween(750, easing = FastOutSlowInEasing))
            }
        }
    }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        HorizontalPager(
            state = pager,
            modifier = Modifier.fillMaxWidth().height(216.dp),
            contentPadding = PaddingValues(horizontal = 30.dp),
            pageSpacing = 10.dp,
            key = { list.getOrNull(it)?.path ?: it },
        ) { page ->
            val f = list.getOrNull(page)
            if (f != null) RecentCard(
                f, ex, loader,
                Modifier.fillMaxSize().graphicsLayer {
                    val off = ((pager.currentPage - page) + pager.currentPageOffsetFraction).absoluteValue.coerceIn(0f, 1f)
                    val scale = 1f - 0.1f * off
                    scaleX = scale
                    scaleY = scale
                    alpha = 1f - 0.45f * off
                    // Effet de profondeur : les cartes voisines pivotent légèrement
                    val side = (pager.currentPage - page) + pager.currentPageOffsetFraction
                    rotationY = (side * 8f).coerceIn(-8f, 8f)
                    cameraDistance = 12f * density
                },
            )
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
            repeat(list.size) { i ->
                val on = i == pager.currentPage
                val w by animateDpAsState(if (on) 18.dp else 6.dp, label = "point")
                Box(Modifier.size(width = w, height = 6.dp).clip(CircleShape).background(if (on) LS.Blue else LS.Card2))
            }
        }
    }
}

@Composable
private fun RecentCard(f: File, ex: ExplorerViewModel, loader: ImageLoader, modifier: Modifier) {
    val ctx = LocalContext.current
    val cat = f.category()
    val visual = cat == Category.PHOTOS || cat == Category.VIDEOS
    val tint = fileTint(f, false)
    var menu by remember { mutableStateOf(false) }
    val ink = Color(0xFF202020)
    val meta = remember(f.path) {
        val ago = android.text.format.DateUtils.getRelativeTimeSpanString(
            f.lastModified(), System.currentTimeMillis(), android.text.format.DateUtils.MINUTE_IN_MILLIS,
        )
        Formatter.formatShortFileSize(ctx, f.length()) + " · " + ago
    }
    val shape = RoundedCornerShape(UiStyle.r(28.dp))
    Box(modifier.clip(shape).background(LS.Card).clickable { ex.open(f, ex.recents) }) {
        if (cat == Category.VIDEOS) AnimatedVideoThumb(f, loader, Modifier.fillMaxSize())
        else if (f.hasContentPreview()) DocThumb(f, Modifier.fillMaxSize(), widthPx = 600) {
            Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(tint.copy(alpha = 0.30f), LS.Card)))) {
                IconBadge(fileIcon(f, false), tint, 72.dp, Modifier.align(Alignment.Center).padding(bottom = 44.dp))
            }
        }
        else if (visual) AsyncImage(
            model = f, contentDescription = null, imageLoader = loader,
            modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop,
        ) else {
            Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(tint.copy(alpha = 0.30f), LS.Card))))
            IconBadge(fileIcon(f, false), tint, 72.dp, Modifier.align(Alignment.Center).padding(bottom = 44.dp))
        }
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0.45f to Color.Transparent, 1f to Color(0xE6000000))))
        if (cat == Category.VIDEOS) Box(
            Modifier.align(Alignment.Center).size(48.dp).clip(CircleShape).background(Color.White),
            contentAlignment = Alignment.Center,
        ) { Icon(Ic.Play, null, Modifier.size(28.dp), tint = ink) }
        // Étiquette du type, en haut à gauche
        Text(
            typeLabel(cat) + (f.extension.takeIf { it.isNotEmpty() }?.let { " · " + it.uppercase() } ?: ""),
            Modifier.align(Alignment.TopStart).padding(12.dp).clip(CircleShape).background(Color(0x99000000))
                .padding(horizontal = 10.dp, vertical = 5.dp),
            color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
        )
        Column(Modifier.align(Alignment.BottomStart).padding(start = 18.dp, end = 14.dp, bottom = 14.dp)) {
            Text(f.name, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(meta, color = Color.White.copy(alpha = 0.88f), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Ic.Folder, null, Modifier.size(13.dp), tint = Color.White.copy(alpha = 0.75f))
                Spacer(Modifier.width(5.dp))
                Text(parentLabel(ex, f), color = Color.White.copy(alpha = 0.75f), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        Row(Modifier.align(Alignment.TopEnd).padding(10.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Box(
                Modifier.size(36.dp).clip(CircleShape).background(Color(0x99000000)).clickable { ex.showInfo(listOf(f)) },
                contentAlignment = Alignment.Center,
            ) { Icon(Ic.Info, "Détails", Modifier.size(20.dp), tint = Color.White) }
            Box {
                Box(
                    Modifier.size(36.dp).clip(CircleShape).background(LS.Pill).clickable { menu = true },
                    contentAlignment = Alignment.Center,
                ) { Icon(Ic.MoreVert, "Plus d'options", Modifier.size(20.dp), tint = ink) }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem(text = { Text("Ouvrir") }, onClick = { menu = false; ex.open(f, ex.recents) })
                    DropdownMenuItem(text = { Text("Détails") }, onClick = { menu = false; ex.showInfo(listOf(f)) })
                    DropdownMenuItem(text = { Text("Partager") }, onClick = { menu = false; ex.shareFiles(listOf(f)) })
                    DropdownMenuItem(
                        text = { Text("Voir dans le dossier") },
                        onClick = { menu = false; f.parentFile?.let { ex.enter(it); FilesNav.screen = Screen.BROWSE } },
                    )
                }
            }
        }
    }
}

// ═══════════════════════════ Explorateur ═══════════════════════════

@Composable
private fun BrowseScreen(ex: ExplorerViewModel, onBack: () -> Unit, onDelete: () -> Unit) {
    val cat = ex.category
    val title = when {
        ex.favMode -> "Favoris"
        cat != null -> cat.label
        ex.dir.path == ex.root.path -> "Stockage interne"
        else -> ex.dir.name
    }
    val ctx = LocalContext.current
    var creating by remember { mutableStateOf(false) }
    // Dossier « réel » affiché (ni catégorie, ni favoris, ni résultats de recherche)
    val plainDir = !ex.favMode && cat == null && ex.query.isBlank()
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onBack) { Icon(Ic.Back, "Retour", tint = LS.Text) }
                Text(title, Modifier.weight(1f), color = LS.Text, fontSize = 20.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (ex.loading || (cat != null && ex.deepScanning)) CircularProgressIndicator(Modifier.size(18.dp), color = LS.Blue, strokeWidth = 2.dp)
                if (plainDir) IconButton({ creating = true }) { Icon(Ic.NewFolder, "Nouveau dossier", tint = LS.Text) }
                SortMenuButton(ex.sort, ex.ascending, { k, asc -> ex.setSort(k, asc) }) { ex.selectAll(ex.items) }
                IconButton({ ex.grid = !ex.grid }) {
                    Icon(if (ex.grid) Ic.ViewList else Ic.GridView, if (ex.grid) "Afficher en liste" else "Afficher en grille", tint = LS.Text)
                }
            }
            Box(Modifier.padding(horizontal = 16.dp)) {
                SearchField(ex.query, "Rechercher un fichier ou dossier") { ex.updateQuery(it) }
            }
            // Images, Vidéos, Audio, Documents : onglet « Tout », puis un onglet par dossier
            if (cat != null && ex.catTabs.isNotEmpty()) FolderTabs(
                listOf<Pair<String?, String>>(null to "Tout") + ex.catTabs.map { (d, n) -> d.path to "${d.name} ($n)" },
                ex.folderTab,
            ) { ex.selectFolderTab(it) }
            val dirs = ex.items.filter { it.isDir }
            val files = ex.items.filter { !it.isDir }
            // Fil d'Ariane cliquable (dossier réel) ou rappel de la recherche
            if (plainDir) Breadcrumbs(ex)
            else if (ex.query.isNotBlank()) Text(
                "Résultats pour « ${ex.query.trim()} »", Modifier.padding(start = 20.dp, end = 20.dp, top = 8.dp),
                color = LS.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            // Résumé du contenu affiché
            if (!ex.loading && ex.items.isNotEmpty()) Text(
                listOfNotNull(
                    if (dirs.isNotEmpty()) plural(dirs.size, "dossier", "dossiers") else null,
                    if (files.isNotEmpty()) plural(files.size, "fichier", "fichiers") + " · " + Formatter.formatShortFileSize(ctx, files.sumOf { it.size }) else null,
                ).joinToString(" · "),
                Modifier.padding(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 2.dp),
                color = LS.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            ex.busy?.let { b ->
                Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                    Text(b, color = LS.Text, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(4.dp))
                    LinearProgressIndicator(Modifier.fillMaxWidth(), color = LS.Blue)
                }
            }

            val listPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 6.dp, bottom = if (ex.selected.isNotEmpty()) 190.dp else 32.dp)
            val emptyText = when {
                ex.loading || (cat != null && ex.deepScanning) -> "Recherche en cours…"
                cat == LCat.DUPES -> "Aucun doublon trouvé"
                cat == LCat.LARGE -> "Aucun fichier de plus de 50 Mo"
                else -> "Aucun élément"
            }
            if (ex.grid) {
                // Grille : dossiers en grandes cases (2 par ligne), fichiers en miniatures (3 par ligne).
                // Les fichiers sont aussi en grille dans Images, Vidéos, Audio et Documents, où il n'y a pas de dossiers.
                val loader = rememberThumbLoader()
                // Grille normale : 3 fichiers par ligne ; compacte (Paramètres) : 4
                val cols = if (UiStyle.denseGrid) 12 else 6
                val fileSpan = if (UiStyle.denseGrid) 3 else 2
                LazyVerticalGrid(
                    columns = GridCells.Fixed(cols), modifier = Modifier.fillMaxSize(), contentPadding = listPadding,
                    verticalArrangement = Arrangement.spacedBy(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    if (!ex.loading && ex.items.isEmpty()) item(key = "empty", span = { GridItemSpan(maxLineSpan) }) {
                        Text(emptyText, Modifier.fillMaxWidth().padding(24.dp), color = LS.Muted, fontSize = 13.sp, textAlign = TextAlign.Center)
                    }
                    items(dirs, key = { it.file.path }, span = { GridItemSpan(cols / 2) }) { d -> FolderCell(d, ex, Modifier.fillMaxWidth()) }
                    items(files, key = { it.file.path }, span = { GridItemSpan(fileSpan) }) { f -> FileCell(f, ex, loader, Modifier.fillMaxWidth()) }
                }
            } else {
                LazyColumn(Modifier.fillMaxSize(), contentPadding = listPadding, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (!ex.loading && ex.items.isEmpty()) item(key = "empty") {
                        Text(emptyText, Modifier.fillMaxWidth().padding(24.dp), color = LS.Muted, fontSize = 13.sp, textAlign = TextAlign.Center)
                    }
                    items(dirs, key = { it.file.path }) { d -> FileRow(d, ex) }
                    items(files, key = { it.file.path }) { f -> FileRow(f, ex) }
                }
            }
        }

        if (ex.selected.isNotEmpty()) {
            // Aperçu des infos de la sélection (toucher = tous les détails), puis la barre d'actions
            // Les actions (copier, déplacer, supprimer, coffre…) sont dans l'écran d'infos : toucher la carte l'ouvre
            Column(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 10.dp)) {
                SelectionInfoCard(ex)
            }
        }
    }

    if (creating) NewFolderDialog(
        onDismiss = { creating = false },
        onCreate = { name -> if (ex.createFolderHere(name)) creating = false },
    )
}

/** Fil d'Ariane : chaque dossier du chemin est une pastille cliquable ; le dossier affiché est mis en avant. */
@Composable
private fun Breadcrumbs(ex: ExplorerViewModel) {
    val chain = remember(ex.dir.path, ex.base.path) {
        val l = ArrayList<File>()
        var c: File? = ex.dir
        while (c != null) {
            l.add(0, c)
            if (c.path == ex.base.path) break
            c = c.parentFile
        }
        if (l.firstOrNull()?.path == ex.base.path) l else listOf(ex.dir)
    }
    val scroll = rememberScrollState()
    // Le dossier affiché (à droite) reste toujours visible
    LaunchedEffect(chain.size) { snapshotFlow { scroll.maxValue }.collect { scroll.scrollTo(it) } }
    Row(
        Modifier.fillMaxWidth().padding(top = 8.dp).horizontalScroll(scroll).padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        chain.forEachIndexed { i, d ->
            val last = i == chain.lastIndex
            if (i > 0) Icon(Ic.Chevron, null, Modifier.padding(horizontal = 2.dp).size(16.dp), tint = LS.Muted)
            Row(
                Modifier.clip(CircleShape).background(if (last) LS.BlueLight else LS.Card)
                    .clickable(enabled = !last) { ex.openDir(d) }.padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (i == 0) {
                    Icon(if (d.path == ex.root.path) Ic.Phone else Ic.Folder, null, Modifier.size(14.dp), tint = if (last) LS.Blue else LS.Muted)
                    Spacer(Modifier.width(6.dp))
                }
                Text(
                    if (d.path == ex.root.path) "Stockage interne" else d.name,
                    color = if (last) LS.Blue else LS.Text, fontSize = 12.sp,
                    fontWeight = if (last) FontWeight.SemiBold else FontWeight.Normal, maxLines = 1,
                )
            }
        }
    }
}

/**
 * Bouton « Trier » et son menu (chaque critère existe dans les deux sens ; ascending = croissant : A→Z, petit→grand,
 * ancien→récent) + « Tout sélectionner ». Partagé par l'explorateur et le coffre.
 */
@Composable
internal fun SortMenuButton(sort: SortKey, ascending: Boolean, onSet: (SortKey, Boolean) -> Unit, onSelectAll: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Box {
        IconButton({ menu = true }) { Icon(Ic.Sort, "Trier", tint = LS.Blue) }
        DropdownMenu(menu, { menu = false }) {
            @Composable fun opt(k: SortKey, asc: Boolean, label: String) = DropdownMenuItem(
                text = { Text(label + if (sort == k && ascending == asc) "  ✓" else "") },
                onClick = { onSet(k, asc); menu = false },
            )
            opt(SortKey.NAME, true, "Nom (A → Z)")
            opt(SortKey.NAME, false, "Nom (Z → A)")
            HorizontalDivider()
            opt(SortKey.DATE, false, "Date : plus récent d'abord")
            opt(SortKey.DATE, true, "Date : plus ancien d'abord")
            HorizontalDivider()
            opt(SortKey.SIZE, false, "Taille : plus grand d'abord")
            opt(SortKey.SIZE, true, "Taille : plus petit d'abord")
            HorizontalDivider()
            opt(SortKey.TYPE, true, "Type (A → Z)")
            opt(SortKey.TYPE, false, "Type (Z → A)")
            HorizontalDivider()
            DropdownMenuItem(text = { Text("Tout sélectionner") }, onClick = { onSelectAll(); menu = false })
        }
    }
}

// ═══════════════════════════ Onglets « Tout » + dossiers ═══════════════════════════

/** Rangée d'onglets défilante : [tabs] = (chemin du dossier ou null pour « Tout », libellé). */
@Composable
internal fun FolderTabs(tabs: List<Pair<String?, String>>, selected: String?, onSelect: (String?) -> Unit) {
    LazyRow(
        Modifier.fillMaxWidth().padding(top = 6.dp),
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        items(tabs, key = { it.first ?: "__all" }) { (path, label) ->
            val on = path == selected
            Text(
                label,
                Modifier.clip(CircleShape).background(if (on) LS.Blue else LS.Card)
                    .clickable { onSelect(path) }.padding(horizontal = 16.dp, vertical = 8.dp),
                color = if (on) LS.OnBlue else LS.Text, fontSize = 13.sp,
                fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal,
                maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

// ═══════════════════════════ Applications ═══════════════════════════

private class AppItem(val label: String, val pkg: String, val icon: ImageBitmap)

/** Fichier APK dont l'application n'est pas installée ([icon] = null si l'archive est illisible). */
private class ApkItem(val file: File, val label: String, val version: String?, val icon: ImageBitmap?)

private fun loadApks(ctx: Context, ex: ExplorerViewModel): List<ApkItem> {
    val pm = ctx.packageManager
    return ex.findApks().mapNotNull { f ->
        val info = pm.getPackageArchiveInfo(f.path, 0)
        if (info == null) return@mapNotNull ApkItem(f, f.name, null, null)
        val installed = try { pm.getPackageInfo(info.packageName, 0); true } catch (e: Exception) { false }
        if (installed) return@mapNotNull null
        val ai = info.applicationInfo
        val (label, icon) = if (ai != null) {
            ai.sourceDir = f.path; ai.publicSourceDir = f.path
            val l = runCatching { ai.loadLabel(pm).toString() }.getOrDefault(f.name)
            val ic = runCatching { ai.loadIcon(pm).toBitmap(96, 96).asImageBitmap() }.getOrNull()
            l to ic
        } else f.name to null
        ApkItem(f, label, info.versionName, icon)
    }.sortedBy { it.label.lowercase() }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppsScreen(ex: ExplorerViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var query by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf<String?>(null) }
    val apps by produceState<List<AppItem>?>(null, AppEvents.resumeTick) {
        value = withContext(Dispatchers.IO) {
            val pm = ctx.packageManager
            val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            pm.queryIntentActivities(launcher, 0)
                .map { ri -> AppItem(ri.loadLabel(pm).toString(), ri.activityInfo.packageName, ri.loadIcon(pm).toBitmap(96, 96).asImageBitmap()) }
                .distinctBy { it.pkg }
                .sortedBy { it.label.lowercase() }
        }
    }
    val apks by produceState<List<ApkItem>?>(null, AppEvents.resumeTick) {
        value = withContext(Dispatchers.IO) { loadApks(ctx, ex) }
    }
    val q = query.trim()
    val apkFolders = apks.orEmpty().groupBy { it.file.parentFile }.filterKeys { it != null }
        .map { (d, l) -> d!! to l.size }.sortedBy { it.first.name.lowercase() }
    // Le dossier choisi n'a plus d'APK (installés entre-temps) : retour à « Tout »
    LaunchedEffect(apks) { if (tab != null && apks != null && apkFolders.none { it.first.path == tab }) tab = null }

    val installed = if (tab == null) apps?.filter { q.isEmpty() || it.label.contains(q, ignoreCase = true) } else emptyList()
    val apkList = apks?.filter { (tab == null || it.file.parentFile?.path == tab) && (q.isEmpty() || it.label.contains(q, true) || it.file.name.contains(q, true)) }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Ic.Back, "Retour", tint = LS.Text) }
            Text("Applications", color = LS.Text, fontSize = 20.sp, fontWeight = FontWeight.Medium)
        }
        Box(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) { SearchField(query, "Rechercher une application ou un APK") { query = it } }
        // Onglet « Tout » (apps installées + APK non installés), puis un onglet par dossier contenant des APK
        FolderTabs(
            listOf<Pair<String?, String>>(null to "Tout") + apkFolders.map { (d, n) -> d.path to "${d.name} ($n)" },
            tab,
        ) { tab = it }
        if (installed == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = LS.Blue) }
        } else {
            LazyVerticalGrid(
                GridCells.Fixed(4), Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 32.dp),
            ) {
                items(installed, key = { "app:" + it.pkg }) { app ->
                    Column(
                        Modifier.clip(RoundedCornerShape(16.dp)).combinedClickable(
                            onClick = { ctx.packageManager.getLaunchIntentForPackage(app.pkg)?.let { ctx.startActivity(it) } },
                            onLongClick = {
                                ctx.startActivity(
                                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}"))
                                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                )
                            },
                        ).padding(vertical = 10.dp, horizontal = 2.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Image(app.icon, app.label, Modifier.size(54.dp))
                        Spacer(Modifier.height(6.dp))
                        Text(app.label, color = LS.Text, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
                    }
                }
                if (apkList == null) {
                    if (tab == null) item(key = "apk_loading", span = { GridItemSpan(maxLineSpan) }) {
                        Text("Recherche des fichiers APK…", Modifier.fillMaxWidth().padding(16.dp), color = LS.Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
                    }
                } else if (apkList.isNotEmpty() || tab != null) {
                    item(key = "apk_header", span = { GridItemSpan(maxLineSpan) }) {
                        Text(
                            "Fichiers APK non installés (${apkList.size})",
                            Modifier.padding(start = 4.dp, top = 14.dp, bottom = 4.dp),
                            color = LS.Text.copy(alpha = 0.92f), fontSize = 16.sp, fontWeight = FontWeight.Medium,
                        )
                    }
                    if (apkList.isEmpty()) item(key = "apk_empty", span = { GridItemSpan(maxLineSpan) }) {
                        Text("Aucun APK à installer", Modifier.fillMaxWidth().padding(16.dp), color = LS.Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
                    }
                    items(apkList, key = { "apk:" + it.file.path }) { apk ->
                        Column(
                            Modifier.clip(RoundedCornerShape(16.dp)).clickable { ex.installApk(apk.file) }
                                .padding(vertical = 10.dp, horizontal = 2.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            if (apk.icon != null) Image(apk.icon, apk.label, Modifier.size(54.dp))
                            else Box(Modifier.size(54.dp).clip(RoundedCornerShape(14.dp)).background(LS.Card), contentAlignment = Alignment.Center) {
                                Icon(Ic.Apps, null, Modifier.size(28.dp), tint = LS.Muted)
                            }
                            Spacer(Modifier.height(6.dp))
                            Text(apk.label, color = LS.Text, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
                            Text(
                                Formatter.formatShortFileSize(ctx, apk.file.length()) + (apk.version?.let { " · v$it" } ?: ""),
                                color = LS.Muted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                            )
                        }
                    }
                }
            }
        }
    }
}
