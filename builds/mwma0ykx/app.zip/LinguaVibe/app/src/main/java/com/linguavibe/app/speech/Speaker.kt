package com.linguavibe.app.speech

import android.content.Context
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.io.File
import java.util.Locale

/**
 * Fait entendre la prononciation modèle.
 * Ordre par défaut : ElevenLabs (si configuré), puis les voix hors ligne Kokoro et Piper
 * (si elles sont installées), puis la synthèse vocale d'Android.
 */
class Speaker(context: Context) : TextToSpeech.OnInitListener {
    private val appContext = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val tts = TextToSpeech(appContext, this)
    private var ready = false
    private var pending: (() -> Unit)? = null
    private var player: MediaPlayer? = null
    private var job: Job? = null
    private var sequenceId = 0

    val settings = VoiceSettings(appContext)

    /** Faux si la voix Android de la langue demandée n'est pas installée. */
    var voiceAvailable by mutableStateOf(true)
        private set

    /** Dernière erreur de la voix ElevenLabs (affichée à l'apprenant). */
    var lastError by mutableStateOf<String?>(null)
        private set

    /** Vrai pendant la lecture d'une suite de phrases (« écouter la leçon »). */
    var sequencePlaying by mutableStateOf(false)
        private set

    /** Position de la phrase lue dans la suite en cours (-1 hors lecture). */
    var sequenceIndex by mutableStateOf(-1)
        private set

    /** Nom de la voix utilisée pour la dernière phrase (affiché dans les paramètres). */
    var lastEngine by mutableStateOf("")
        private set

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
        if (!ready) voiceAvailable = false
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) = finish()
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) = finish()
        })
    }

    private fun finish() {
        main.post {
            val callback = pending
            pending = null
            callback?.invoke()
        }
    }

    /** Arrête le son en cours sans toucher à la suite de phrases. */
    private fun halt() {
        job?.cancel()
        job = null
        pending = null
        player?.let {
            try {
                it.stop()
            } catch (_: Exception) {
            }
            it.release()
        }
        player = null
        if (ready) tts.stop()
    }

    fun speak(text: String, locale: Locale, slow: Boolean = false, onDone: (() -> Unit)? = null) {
        sequenceId++
        sequencePlaying = false
        sequenceIndex = -1
        val rate = (settings.playbackSpeed * if (slow) 0.65f else 1.0f).coerceIn(0.35f, 1.5f)
        start(text, locale, rate, onDone)
    }

    /** Lit plusieurs phrases à la suite (en partant de [from]). */
    fun speakAll(texts: List<String>, locale: Locale, slow: Boolean = false, from: Int = 0) {
        val id = ++sequenceId
        sequencePlaying = true
        fun next(index: Int) {
            if (id != sequenceId) return
            if (index >= texts.size) {
                sequencePlaying = false
                sequenceIndex = -1
                return
            }
            sequenceIndex = index
            val rate = (settings.playbackSpeed * if (slow) 0.65f else 1.0f).coerceIn(0.35f, 1.5f)
            start(texts[index], locale, rate) { next(index + 1) }
        }
        next(from)
    }

    fun stop() {
        sequenceId++
        sequencePlaying = false
        sequenceIndex = -1
        halt()
    }

    private enum class Source { ELEVEN, KOKORO, PIPER, ANDROID }

    /** Ordre d'essai des voix selon le réglage choisi dans les paramètres. */
    private fun order(): List<Source> = when (settings.engine) {
        VoiceSettings.ENGINE_KOKORO -> listOf(Source.KOKORO, Source.PIPER, Source.ANDROID)
        VoiceSettings.ENGINE_PIPER -> listOf(Source.PIPER, Source.KOKORO, Source.ANDROID)
        VoiceSettings.ENGINE_ELEVEN -> listOf(Source.ELEVEN, Source.KOKORO, Source.PIPER, Source.ANDROID)
        VoiceSettings.ENGINE_ANDROID -> listOf(Source.ANDROID)
        else -> listOf(Source.ELEVEN, Source.KOKORO, Source.PIPER, Source.ANDROID)
    }

    private fun start(text: String, locale: Locale, rate: Float, onDone: (() -> Unit)?) {
        halt()
        val lang = locale.language
        val sources = order().filter { source ->
            when (source) {
                Source.ELEVEN -> settings.ready
                Source.KOKORO -> NeuralVoices.voiceFor(appContext, lang, NeuralEngine.KOKORO) != null
                Source.PIPER -> NeuralVoices.voiceFor(appContext, lang, NeuralEngine.PIPER) != null
                Source.ANDROID -> true
            }
        }
        if (sources.first() == Source.ANDROID) {
            lastEngine = "Voix du téléphone"
            speakTts(text, locale, rate, onDone)
            return
        }
        job = scope.launch {
            for (source in sources) {
                if (source == Source.ANDROID) break
                try {
                    val file = when (source) {
                        Source.ELEVEN -> ElevenLabs.speechFile(
                            appContext, settings.apiKey, settings.voiceId, settings.model, text, lang
                        )
                        else -> {
                            val engine = if (source == Source.KOKORO) NeuralEngine.KOKORO else NeuralEngine.PIPER
                            val voice = NeuralVoices.voiceFor(appContext, lang, engine)!!
                            NeuralVoices.speechFile(appContext, voice, lang, text, slow, settings.kokoroMale)
                        }
                    }
                    lastError = null
                    lastEngine = when (source) {
                        Source.ELEVEN -> "ElevenLabs"
                        Source.KOKORO -> "Kokoro"
                        else -> "Piper"
                    }
                    // Les voix hors ligne calculent elles-mêmes le ralenti.
                    play(file, rate, onDone)
                    return@launch
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    // Pas de réseau, quota dépassé, voix trop lourde… : on essaie la voix suivante.
                    lastError = when (source) {
                        Source.ELEVEN -> e.message ?: "Voix ElevenLabs indisponible."
                        else -> "Voix hors ligne indisponible : ${e.message ?: e.javaClass.simpleName}."
                    }
                }
            }
            lastEngine = "Voix du téléphone"
            speakTts(text, locale, rate, onDone)
        }
    }

    private fun play(file: File, rate: Float, onDone: (() -> Unit)?) {
        val mp = MediaPlayer()
        player = mp
        pending = onDone
        mp.setOnCompletionListener {
            if (player === it) {
                it.release()
                player = null
                finish()
            }
        }
        mp.setOnErrorListener { failed, _, _ ->
            if (player === failed) {
                failed.release()
                player = null
                finish()
            }
            true
        }
        mp.setDataSource(file.absolutePath)
        mp.prepare()
        mp.playbackParams = mp.playbackParams.setSpeed(rate)
        mp.start()
    }

    private fun speakTts(text: String, locale: Locale, rate: Float, onDone: (() -> Unit)?) {
        if (!ready) {
            onDone?.invoke()
            return
        }
        val result = tts.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            voiceAvailable = false
            onDone?.invoke()
            return
        }
        voiceAvailable = true
        tts.setSpeechRate((0.95f * rate).coerceIn(0.35f, 1.5f))
        pending = onDone
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u" + System.nanoTime())
    }

    fun shutdown() {
        stop()
        scope.cancel()
        tts.shutdown()
    }
}
