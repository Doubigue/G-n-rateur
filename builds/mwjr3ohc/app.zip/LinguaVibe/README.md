# LinguaVibe — application Android d'apprentissage des langues

Kotlin + Jetpack Compose. Reconnaissance vocale **hors ligne** avec Vosk pour corriger la prononciation.

## Contenu

- **Espagnol : 36 leçons, du niveau A1 au niveau C2.**
- **Anglais : 24 leçons, du niveau A1 au niveau C2.**
- Portugais, chinois, arabe : la langue, sa voix et ses modèles vocaux sont déjà prévus ; il reste à écrire
  leurs cours (voir « Ajouter une langue »).

Chaque leçon comporte cinq étapes :

| Étape | Ce qu'on y fait |
|---|---|
| 📖 Leçon | Bandeau illustré animé, cartes de vocabulaire qui se retournent, grammaire avec exemples à écouter |
| 💬 Dialogue | Jeu de rôle : l'application joue un personnage, vous dites les répliques de l'autre au micro |
| 🎤 Prononciation | Écoute (normale ou lente), enregistrement, correction mot à mot (vert / orange / rouge) et score |
| ❓ Quiz | Choix multiples, compréhension orale, traduction écrite ; 70 % pour valider la leçon |
| 📝 Devoir | Questions ouvertes (écrites ou dictées), vérification des éléments clés et réponse modèle |

## Compiler l'APK

**Avec GitHub Actions** : poussez ce dossier dans un dépôt GitHub. Le workflow `.github/workflows/build.yml`
compile l'APK ; il se télécharge dans l'onglet *Actions* (artefact `LinguaVibe-debug`).

**Avec Android Studio** : ouvrez le dossier, laissez Gradle se synchroniser, puis *Run*.

**En ligne de commande** (JDK 17, Gradle 8.7 ou plus, SDK Android 34) : `gradle assembleDebug`

## Modèles vocaux Vosk

Dans l'application : accueil › **Modèles vocaux**. Pour chaque langue, deux possibilités :

1. **Télécharger** : l'application récupère le modèle recommandé.
2. **Importer un ZIP** : choisissez un fichier `.zip` déjà téléchargé sur <https://alphacephei.com/vosk/models>.
   Tout modèle Vosk est accepté (le ZIP doit contenir les dossiers `am/`, `conf/`, `graph/`).

| Langue | Précision maximale | Taille | Alternative pour téléphone | Taille |
|---|---|---|---|---|
| Espagnol | `vosk-model-es-0.42` | 1,4 Go | `vosk-model-small-es-0.42` | 39 Mo |
| Anglais | `vosk-model-en-us-0.22` | 1,8 Go | `vosk-model-en-us-0.22-lgraph` (128 Mo) ou `vosk-model-small-en-us-0.15` | 40 Mo |
| Portugais | `vosk-model-pt-fb-v0.1.1-20220516_2113` | 1,6 Go | `vosk-model-small-pt-0.3` | 31 Mo |
| Chinois | `vosk-model-cn-0.22` | 1,3 Go | `vosk-model-small-cn-0.22` | 42 Mo |
| Arabe | `vosk-model-ar-0.22-linto-1.1.0` | 1,3 Go | `vosk-model-ar-mgb2-0.4` | 318 Mo |

**Attention :** les modèles complets sont conçus pour des serveurs. D'après la documentation Vosk, ils peuvent
demander jusqu'à 16 Go de mémoire, contre environ 300 Mo pour un petit modèle. Sur la plupart des téléphones,
l'application risque de se fermer au chargement : installez alors l'alternative. Un seul modèle est conservé
par langue (le nouveau remplace l'ancien). Le téléchargement exige environ 2,3 fois la taille du ZIP en espace libre.

La voix qui lit les exemples est la synthèse vocale d'Android : installez la voix de la langue dans
Paramètres › Synthèse vocale si elle manque.

## Ajouter des leçons ou une langue

Les cours sont écrits dans `content/<code>/*.txt` (format expliqué en tête de `tools/build_course.py`),
puis convertis en JSON :

```
python3 tools/build_course.py es
```

Pour ouvrir une nouvelle langue : créez `content/pt/…`, lancez `python3 tools/build_course.py pt`,
puis passez `available` à `true` pour cette langue dans `app/src/main/java/com/linguavibe/app/data/Models.kt`.

## Organisation du code

```
app/src/main/java/com/linguavibe/app/
  MainActivity.kt
  data/Models.kt           langues, structure des cours, lecture du JSON
  data/ProgressStore.kt    XP, série de jours, scores, devoirs
  speech/VoskManager.kt    import / téléchargement des modèles, écoute du micro
  speech/Pronunciation.kt  correction mot à mot et score
  speech/Speaker.kt        synthèse vocale
  ui/Screens.kt            accueil, parcours, gestion des modèles
  ui/LessonScreen.kt       les cinq étapes d'une leçon
  ui/Motion.kt             animations (bandeaux, cartes, micro, confettis)
```
