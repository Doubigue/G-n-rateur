package com.linguavibe.app.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.linguavibe.app.data.CourseRepository
import com.linguavibe.app.data.DialogueLine
import com.linguavibe.app.data.GrammarPoint
import com.linguavibe.app.data.Homework
import com.linguavibe.app.data.LanguageInfo
import com.linguavibe.app.data.Lesson
import com.linguavibe.app.data.Levels
import com.linguavibe.app.data.ProgressStore
import com.linguavibe.app.data.QuizItem
import com.linguavibe.app.speech.Pronunciation
import com.linguavibe.app.speech.PronunciationResult
import com.linguavibe.app.speech.VoskManager
import com.linguavibe.app.speech.WordStatus
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val tabTitles = listOf("📖 Leçon", "💬 Dialogue", "🎤 Prononciation", "❓ Quiz", "📝 Devoir")

@Composable
fun LessonScreen(lang: LanguageInfo, lessonId: String, progress: ProgressStore, onBack: () -> Unit) {
    val context = LocalContext.current
    val speaker = LocalSpeaker.current
    val course = remember(lang.code) { CourseRepository.load(context, lang.code) }
    val lesson = course.lesson(lessonId)
    if (lesson == null) {
        Column(Modifier.fillMaxSize()) {
            TopBar("Leçon introuvable", null, IndigoDark, onBack)
        }
        return
    }
    val color = levelColor(lesson.level)
    var tab by rememberSaveable(lessonId) { mutableStateOf(0) }

    // On coupe la voix et le micro en changeant d'onglet ou en quittant la leçon.
    LaunchedEffect(tab) {
        speaker.stop()
        VoskManager.cancel()
    }
    DisposableEffect(lessonId) {
        onDispose {
            speaker.stop()
            VoskManager.cancel()
        }
    }

    Column(Modifier.fillMaxSize()) {
        TopBar(lesson.title, "${lesson.level} · Leçon ${lesson.number} · ${lesson.titleTr}", color, onBack)
        ScrollableTabRow(
            selectedTabIndex = tab,
            edgePadding = 8.dp,
            containerColor = Color.White,
            contentColor = color
        ) {
            tabTitles.forEachIndexed { index, title ->
                Tab(
                    selected = tab == index,
                    onClick = { tab = index },
                    text = {
                        Text(title, fontWeight = if (tab == index) FontWeight.Bold else FontWeight.Normal)
                    }
                )
            }
        }
        AnimatedContent(
            targetState = tab,
            modifier = Modifier.weight(1f),
            transitionSpec = { fadeIn(tween(250)) togetherWith fadeOut(tween(150)) },
            label = "lessonTab"
        ) { current ->
            when (current) {
                0 -> LearnStep(lesson, lang, color) { tab = 1 }
                1 -> DialogueStep(lesson, lang, color) { tab = 2 }
                2 -> PronunciationStep(lesson, lang, color) { tab = 3 }
                3 -> QuizStep(lesson, lang, color, progress) { tab = 4 }
                else -> HomeworkStep(lesson, lang, color, progress)
            }
        }
    }
}

@Composable
private fun NextButton(text: String, color: Color, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = ButtonDefaults.buttonColors(containerColor = color),
        contentPadding = PaddingValues(vertical = 14.dp)
    ) { Text(text, fontWeight = FontWeight.Bold, fontSize = 16.sp) }
}

// ------------------------------------------------------------------ 1. Leçon

@Composable
private fun LearnStep(lesson: Lesson, lang: LanguageInfo, color: Color, onNext: () -> Unit) {
    val speaker = LocalSpeaker.current
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        SceneBanner(
            emoji = lesson.emoji,
            extras = lesson.vocab.take(3).map { it.emoji },
            color = color,
            title = lesson.title,
            subtitle = lesson.titleTr,
            tag = "${lesson.level} · ${Levels.label(lesson.level)}"
        )
        if (!speaker.voiceAvailable) {
            CardBox {
                Text(
                    "🔇 La voix « ${lang.name} » n'est pas installée sur ce téléphone. Ouvrez Paramètres › " +
                        "Synthèse vocale et téléchargez cette langue pour entendre les exemples.",
                    fontSize = 13.sp, color = Bad
                )
            }
        }
        if (lesson.intro.isNotBlank()) {
            CardBox { Text(lesson.intro, fontSize = 15.sp, color = Ink, lineHeight = 21.sp) }
        }

        SectionTitle("📚 Vocabulaire", "Touchez une carte pour la retourner, 🔊 pour l'écouter")
        lesson.vocab.chunked(2).forEach { pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                pair.forEach { vocab ->
                    // Pour une structure (« llevar + gerundio »), on fait entendre l'exemple.
                    val spoken = if (vocab.word.any { it == '+' || it == '…' }) vocab.example else vocab.word
                    FlipCard(vocab, color, { speaker.speak(spoken, lang.locale) }, Modifier.weight(1f))
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }

        SectionTitle("🧩 Grammaire", "Touchez un exemple pour l'écouter")
        lesson.grammar.forEachIndexed { index, point ->
            StaggerIn(index) { GrammarCard(point, lang, color) }
        }

        NextButton("Passer au dialogue  💬", color, onNext)
    }
}

@Composable
private fun GrammarCard(point: GrammarPoint, lang: LanguageInfo, color: Color) {
    val speaker = LocalSpeaker.current
    CardBox {
        Text(point.title, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = color)
        Text(point.explanation, fontSize = 14.sp, color = Ink, lineHeight = 20.sp)
        point.examples.forEach { example ->
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(color.copy(alpha = 0.08f))
                    .clickable { speaker.speak(example.text, lang.locale) }
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Text("🔊  ${example.text}", fontWeight = FontWeight.SemiBold, fontSize = 15.sp, color = Ink)
                Text(example.translation, fontSize = 13.sp, color = InkSoft, fontStyle = FontStyle.Italic)
            }
        }
    }
}

// -------------------------------------------------------- Micro et correction

/** Bouton micro complet : permission, chargement du modèle, écoute, texte en direct. */
@Composable
fun MicControl(id: String, lang: LanguageInfo, color: Color, onHeard: (String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val openModels = LocalOpenModels.current
    val speaker = LocalSpeaker.current
    val currentOnHeard by rememberUpdatedState(onHeard)
    var error by remember(id) { mutableStateOf<String?>(null) }
    var missingModel by remember(id) { mutableStateOf(false) }
    val listening = VoskManager.activeId == id
    val loading = VoskManager.loadingId == id

    val begin: () -> Unit = {
        error = null
        if (!VoskManager.isInstalled(context, lang.code)) {
            missingModel = true
        } else {
            missingModel = false
            speaker.stop()
            scope.launch {
                VoskManager.loadingId = id
                try {
                    val model = VoskManager.ensureModel(context, lang.code)
                    VoskManager.start(
                        id, model,
                        onFinal = { heard -> currentOnHeard(heard) },
                        onError = { message -> error = message }
                    )
                } catch (e: Exception) {
                    error = e.message ?: "Impossible de charger le modèle vocal"
                } finally {
                    if (VoskManager.loadingId == id) VoskManager.loadingId = null
                }
            }
        }
    }

    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) begin() else error = "Autorisez le microphone pour vous faire corriger."
    }

    DisposableEffect(id) {
        onDispose { if (VoskManager.activeId == id) VoskManager.cancel() }
    }

    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        PulsingMic(listening, loading, color) {
            val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
            when {
                listening -> VoskManager.stop()
                granted -> begin()
                else -> permission.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
        when {
            loading -> Text("Chargement du modèle vocal…", fontSize = 13.sp, color = InkSoft)
            listening -> {
                Waveform(color)
                Text(
                    VoskManager.partial.ifBlank { "Parlez… puis touchez ⏹ pour terminer" },
                    fontSize = 14.sp, color = Ink, textAlign = TextAlign.Center
                )
            }
            else -> Text("Touchez le micro et parlez", fontSize = 13.sp, color = InkSoft)
        }
        if (missingModel) {
            Text(
                "Aucun modèle vocal n'est encore installé pour : ${lang.name.lowercase()}.",
                fontSize = 13.sp, color = Bad, textAlign = TextAlign.Center
            )
            OutlinedButton(onClick = openModels) { Text("Installer le modèle") }
        }
        error?.let { Text(it, fontSize = 13.sp, color = Bad, textAlign = TextAlign.Center) }
    }
}

@Composable
private fun PronunciationFeedback(result: PronunciationResult) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(scoreColor(result.score).copy(alpha = 0.08f))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ScoreRing(result.score, 68.dp)
        Spacer(Modifier.width(12.dp))
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                buildAnnotatedString {
                    result.words.forEach { word ->
                        val style = when (word.status) {
                            WordStatus.OK -> SpanStyle(color = Good, fontWeight = FontWeight.Bold)
                            WordStatus.CLOSE -> SpanStyle(color = Warn, fontWeight = FontWeight.Bold)
                            WordStatus.MISSED -> SpanStyle(
                                color = Bad, fontWeight = FontWeight.Bold,
                                textDecoration = TextDecoration.Underline
                            )
                        }
                        withStyle(style) { append(word.word) }
                        append("  ")
                    }
                },
                fontSize = 16.sp
            )
            if (result.heardText.isNotBlank()) {
                Text("Entendu : « ${result.heardText} »", fontSize = 13.sp, color = InkSoft)
            }
            Text(result.feedback, fontSize = 13.sp, color = Ink)
            Text("vert = correct · orange = presque · rouge = à retravailler", fontSize = 11.sp, color = InkSoft)
        }
    }
}

/** Micro + correction mot à mot de la phrase attendue. */
@Composable
fun PronounceBlock(id: String, expected: String, lang: LanguageInfo, color: Color) {
    var result by remember(id) { mutableStateOf<PronunciationResult?>(null) }
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        MicControl(id, lang, color) { heard ->
            result = Pronunciation.evaluate(expected, heard, lang.code)
        }
        AnimatedVisibility(visible = result != null) {
            result?.let { PronunciationFeedback(it) }
        }
    }
}

// --------------------------------------------------------------- 2. Dialogue

@Composable
private fun DialogueStep(lesson: Lesson, lang: LanguageInfo, color: Color, onNext: () -> Unit) {
    val speaker = LocalSpeaker.current
    val lines = lesson.dialogue
    if (lines.isEmpty()) return
    var shown by remember(lesson.id) { mutableIntStateOf(1) }
    val scroll = rememberScrollState()
    val current = lines[(shown - 1).coerceIn(0, lines.lastIndex)]
    val isLast = shown >= lines.size

    LaunchedEffect(shown) {
        delay(200)
        scroll.animateScrollTo(scroll.maxValue)
        if (!current.isUser) speaker.speak(current.text, lang.locale)
    }

    Column(Modifier.fillMaxSize()) {
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(scroll)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                "Jeu de rôle : l'application joue le premier personnage, vous jouez le second (bulles colorées). " +
                    "Touchez une bulle pour la réécouter.",
                fontSize = 13.sp, color = InkSoft
            )
            lines.take(shown).forEachIndexed { index, line ->
                key(index) {
                    StaggerIn(0) { Bubble(line, color) { speaker.speak(line.text, lang.locale) } }
                }
            }
        }
        Column(
            Modifier
                .fillMaxWidth()
                .background(Color.White)
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (current.isUser) {
                Text("🎤 À vous ! Dites la phrase colorée :", fontWeight = FontWeight.Bold, color = color)
                PronounceBlock("dialogue-${lesson.id}-$shown", current.text, lang, color)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { speaker.speak(current.text, lang.locale, slow = true) },
                    modifier = Modifier.weight(1f)
                ) { Text("🐢 Réécouter") }
                Button(
                    onClick = { if (isLast) onNext() else shown++ },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = color)
                ) { Text(if (isLast) "Terminer ✓" else "Continuer ▶") }
            }
        }
    }
}

@Composable
private fun Bubble(line: DialogueLine, color: Color, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (line.isUser) Arrangement.End else Arrangement.Start
    ) {
        if (!line.isUser) {
            Text("🧑‍🏫", fontSize = 26.sp)
            Spacer(Modifier.width(6.dp))
        }
        Column(
            Modifier
                .fillMaxWidth(0.8f)
                .clip(
                    RoundedCornerShape(
                        topStart = 20.dp, topEnd = 20.dp,
                        bottomStart = if (line.isUser) 20.dp else 4.dp,
                        bottomEnd = if (line.isUser) 4.dp else 20.dp
                    )
                )
                .background(if (line.isUser) color else Color.White)
                .clickable(onClick = onClick)
                .padding(12.dp)
        ) {
            val textColor = if (line.isUser) Color.White else Ink
            Text(line.text, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, color = textColor)
            Text(line.translation, fontSize = 13.sp, color = textColor.copy(alpha = 0.75f), fontStyle = FontStyle.Italic)
        }
    }
}

// ---------------------------------------------------------- 3. Prononciation

@Composable
private fun PronunciationStep(lesson: Lesson, lang: LanguageInfo, color: Color, onNext: () -> Unit) {
    val speaker = LocalSpeaker.current
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        SectionTitle(
            "🎤 Prononciation",
            "Écoutez le modèle, répétez dans le micro : chaque mot est corrigé."
        )
        lesson.phrases.forEachIndexed { index, phrase ->
            StaggerIn(index) {
                CardBox {
                    Text(phrase.text, fontWeight = FontWeight.Bold, fontSize = 19.sp, color = Ink)
                    Text(phrase.translation, fontSize = 14.sp, color = InkSoft, fontStyle = FontStyle.Italic)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { speaker.speak(phrase.text, lang.locale) }) { Text("🔊 Écouter") }
                        OutlinedButton(onClick = { speaker.speak(phrase.text, lang.locale, slow = true) }) {
                            Text("🐢 Lentement")
                        }
                    }
                    PronounceBlock("phrase-${lesson.id}-$index", phrase.text, lang, color)
                }
            }
        }
        NextButton("Passer au quiz  ❓", color, onNext)
    }
}

// ------------------------------------------------------------------- 4. Quiz

@Composable
private fun QuizStep(lesson: Lesson, lang: LanguageInfo, color: Color, progress: ProgressStore, onNext: () -> Unit) {
    val items = lesson.quiz
    if (items.isEmpty()) return
    var index by remember(lesson.id) { mutableIntStateOf(0) }
    var correct by remember(lesson.id) { mutableIntStateOf(0) }
    var finished by remember(lesson.id) { mutableStateOf(false) }
    var gained by remember(lesson.id) { mutableIntStateOf(0) }

    if (finished) {
        val score = correct * 100 / items.size
        val passed = score >= ProgressStore.PASS_SCORE
        Box(Modifier.fillMaxSize()) {
            Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                FloatingEmoji(if (passed) "🏆" else "💪", 64)
                ScoreRing(score, 124.dp)
                Text(
                    if (passed) "Leçon validée !" else "Encore un effort",
                    fontWeight = FontWeight.ExtraBold, fontSize = 24.sp, color = Ink
                )
                Text(
                    "$correct bonnes réponses sur ${items.size}" +
                        if (passed) "" else " — il faut ${ProgressStore.PASS_SCORE} % pour valider.",
                    fontSize = 15.sp, color = InkSoft, textAlign = TextAlign.Center
                )
                Chip("⭐ +$gained XP", Indigo)
                OutlinedButton(onClick = {
                    index = 0
                    correct = 0
                    finished = false
                }) { Text("🔁 Refaire le quiz") }
                NextButton("Faire le devoir  📝", color, onNext)
            }
            if (passed) Confetti()
        }
        return
    }

    Column(
        Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        AnimatedBar(index.toFloat() / items.size, color)
        Text("Question ${index + 1} / ${items.size}", fontSize = 13.sp, color = InkSoft)
        AnimatedContent(
            targetState = index,
            modifier = Modifier.weight(1f),
            transitionSpec = {
                (fadeIn(tween(260)) + slideInHorizontally(tween(260)) { it / 5 }) togetherWith fadeOut(tween(140))
            },
            label = "question"
        ) { i ->
            QuestionView(
                item = items[i.coerceIn(0, items.lastIndex)],
                lang = lang,
                color = color,
                onAnswered = { ok -> if (ok) correct++ },
                onContinue = {
                    if (i >= items.lastIndex) {
                        gained = progress.recordQuiz(lesson.id, correct * 100 / items.size)
                        finished = true
                    } else {
                        index = i + 1
                    }
                }
            )
        }
    }
}

@Composable
private fun QuestionView(
    item: QuizItem,
    lang: LanguageInfo,
    color: Color,
    onAnswered: (Boolean) -> Unit,
    onContinue: () -> Unit
) {
    val speaker = LocalSpeaker.current
    var answered by remember(item) { mutableStateOf(false) }
    var wasCorrect by remember(item) { mutableStateOf(false) }
    var note by remember(item) { mutableStateOf("") }
    val submit: (Boolean, String) -> Unit = { ok, message ->
        if (!answered) {
            answered = true
            wasCorrect = ok
            note = message
            onAnswered(ok)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        when (item) {
            is QuizItem.Mcq -> {
                Text(item.question, fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Ink, lineHeight = 26.sp)
                Options(item.correct, item.wrong, answered) { ok -> submit(ok, item.correct) }
            }

            is QuizItem.Listen -> {
                LaunchedEffect(item) {
                    delay(350)
                    speaker.speak(item.phrase, lang.locale)
                }
                Text("🎧 Écoutez et choisissez le sens", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Ink)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { speaker.speak(item.phrase, lang.locale) },
                        colors = ButtonDefaults.buttonColors(containerColor = color)
                    ) { Text("🔊 Écouter") }
                    OutlinedButton(onClick = { speaker.speak(item.phrase, lang.locale, slow = true) }) {
                        Text("🐢 Lentement")
                    }
                }
                Options(item.correct, item.wrong, answered) { ok -> submit(ok, "${item.phrase} = ${item.correct}") }
            }

            is QuizItem.Typed -> {
                var input by remember(item) { mutableStateOf("") }
                Text("✍️ Traduisez en ${lang.name.lowercase()}", fontSize = 14.sp, color = InkSoft)
                Text(item.prompt, fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Ink, lineHeight = 26.sp)
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    enabled = !answered,
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Votre réponse") }
                )
                if (!answered) {
                    Button(
                        enabled = input.isNotBlank(),
                        onClick = {
                            val typed = Pronunciation.loose(input)
                            val ok = item.answers.any { Pronunciation.loose(it) == typed }
                            val exact = item.answers.any { Pronunciation.clean(it) == Pronunciation.clean(input) }
                            val best = item.answers.first()
                            submit(ok, if (ok && !exact) "$best  (attention aux accents)" else best)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = color)
                    ) { Text("Valider") }
                }
            }
        }

        AnimatedVisibility(visible = answered) {
            val feedbackColor = if (wasCorrect) Good else Bad
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(feedbackColor.copy(alpha = 0.12f))
                    .padding(14.dp)
            ) {
                Text(
                    if (wasCorrect) "✅ Bravo !" else "❌ Pas tout à fait",
                    fontWeight = FontWeight.Bold, color = feedbackColor, fontSize = 16.sp
                )
                Text("Réponse : $note", color = Ink, fontSize = 15.sp)
            }
        }
        if (answered) NextButton("Continuer", color, onContinue)
    }
}

@Composable
private fun Options(correct: String, wrong: List<String>, answered: Boolean, onPick: (Boolean) -> Unit) {
    val options = remember(correct, wrong) { (wrong + correct).distinct().shuffled() }
    var picked by remember(correct, wrong) { mutableStateOf<String?>(null) }
    options.forEach { option ->
        val highlight = when {
            !answered -> null
            option == correct -> Good
            option == picked -> Bad
            else -> null
        }
        val background by animateColorAsState(highlight?.copy(alpha = 0.16f) ?: Color.White, label = "optionBg")
        val shape = RoundedCornerShape(16.dp)
        Text(
            option,
            fontSize = 16.sp,
            color = Ink,
            fontWeight = if (highlight != null) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(background)
                .border(1.5.dp, highlight ?: Color(0xFFDAD5F0), shape)
                .clickable(enabled = !answered) {
                    picked = option
                    onPick(option == correct)
                }
                .padding(16.dp)
        )
    }
}

// ----------------------------------------------------------------- 5. Devoir

@Composable
private fun HomeworkStep(lesson: Lesson, lang: LanguageInfo, color: Color, progress: ProgressStore) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        SectionTitle(
            "📝 Devoir",
            "Répondez en ${lang.name.lowercase()} avec vos propres mots (à l'écrit ou à la voix), puis comparez au modèle."
        )
        lesson.homework.forEachIndexed { index, homework ->
            HomeworkCard("${lesson.id}-$index", index + 1, homework, lang, color, progress)
        }
    }
}

@Composable
private fun HomeworkCard(
    key: String,
    number: Int,
    homework: Homework,
    lang: LanguageInfo,
    color: Color,
    progress: ProgressStore
) {
    val speaker = LocalSpeaker.current
    var text by remember(key) { mutableStateOf(progress.homeworkAnswer(key)) }
    var corrected by remember(key) { mutableStateOf(false) }
    CardBox {
        Text("Question $number", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = color)
        Text(homework.prompt, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Ink, lineHeight = 22.sp)
        OutlinedTextField(
            value = text,
            onValueChange = {
                text = it
                corrected = false
            },
            modifier = Modifier.fillMaxWidth(),
            minLines = 3,
            label = { Text("Votre réponse") }
        )
        Text("…ou dictez votre réponse :", fontSize = 13.sp, color = InkSoft)
        MicControl("homework-$key", lang, color) { heard ->
            if (heard.isNotBlank()) {
                text = (text.trim() + " " + heard).trim()
                corrected = false
            }
        }
        Button(
            enabled = text.isNotBlank(),
            onClick = {
                progress.saveHomework(key, text)
                corrected = true
            },
            colors = ButtonDefaults.buttonColors(containerColor = color)
        ) { Text("Corriger mon devoir") }

        AnimatedVisibility(visible = corrected) {
            val answer = Pronunciation.loose(text)
            val found = homework.keywords.filter { answer.contains(Pronunciation.loose(it)) }
            val missing = homework.keywords.filter { it !in found }
            val wordCount = answer.split(' ').count { it.isNotBlank() }
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (homework.keywords.isNotEmpty()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        ScoreRing(found.size * 100 / homework.keywords.size, 60.dp)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            if (found.isNotEmpty()) {
                                Text("✅ Bien utilisé : ${found.joinToString(", ")}", fontSize = 14.sp, color = Good)
                            }
                            if (missing.isNotEmpty()) {
                                Text("➕ À intégrer : ${missing.joinToString(", ")}", fontSize = 14.sp, color = Warn)
                            }
                        }
                    }
                }
                if (wordCount < 6) {
                    Text("💡 Développez davantage : visez au moins deux phrases complètes.", fontSize = 13.sp, color = Ink)
                }
                Text("Réponse modèle (touchez pour écouter)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = color)
                Text(
                    "🔊  ${homework.model}",
                    fontSize = 15.sp, color = Ink, lineHeight = 21.sp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(color.copy(alpha = 0.08f))
                        .clickable { speaker.speak(homework.model, lang.locale) }
                        .padding(12.dp)
                )
                Text(
                    "La correction automatique vérifie les éléments clés attendus ; comparez votre texte au modèle " +
                        "pour l'orthographe et la grammaire.",
                    fontSize = 12.sp, color = InkSoft
                )
            }
        }
    }
}
