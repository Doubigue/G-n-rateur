package com.linguavibe.app.speech

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.Locale

/** Synthèse vocale : fait entendre la prononciation modèle. */
class Speaker(context: Context) : TextToSpeech.OnInitListener {
    private val main = Handler(Looper.getMainLooper())
    private val tts = TextToSpeech(context.applicationContext, this)
    private var ready = false
    private var pending: (() -> Unit)? = null

    /** Faux si la voix de la langue demandée n'est pas installée sur le téléphone. */
    var voiceAvailable by mutableStateOf(true)
        private set

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
        if (!ready) voiceAvailable = false
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) = finish()
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) = finish()
        })
    }

    private fun finish() {
        main.post {
            val callback = pending
            pending = null
            callback?.invoke()
        }
    }

    fun speak(text: String, locale: Locale, slow: Boolean = false, onDone: (() -> Unit)? = null) {
        pending = null
        if (!ready) {
            onDone?.invoke()
            return
        }
        val result = tts.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            voiceAvailable = false
            onDone?.invoke()
            return
        }
        voiceAvailable = true
        tts.setSpeechRate(if (slow) 0.55f else 0.95f)
        pending = onDone
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u" + System.nanoTime())
    }

    fun stop() {
        pending = null
        if (ready) tts.stop()
    }

    fun shutdown() {
        pending = null
        tts.stop()
        tts.shutdown()
    }
}
