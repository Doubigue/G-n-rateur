package com.linguavibe.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/** Un modèle Vosk téléchargeable (alphacephei.com/vosk/models). */
data class VoskModel(val name: String, val size: String, val label: String, val note: String) {
    val url: String get() = "https://alphacephei.com/vosk/models/$name.zip"
}

/** Une langue proposée par l'application, avec ses modèles Vosk (le plus précis en premier). */
data class LanguageInfo(
    val code: String,
    val name: String,
    val nativeName: String,
    val flag: String,
    val ttsTag: String,
    val models: List<VoskModel>,
    val available: Boolean
) {
    val locale: Locale get() = Locale.forLanguageTag(ttsTag)
}

object Languages {
    private const val BEST = "⭐ Précision maximale"
    private const val MID = "⚖️ Équilibré"
    private const val LIGHT = "🪶 Léger"
    private const val BIG_NOTE =
        "Modèle complet, le plus précis. Très gourmand en mémoire : réservé aux appareils haut de gamme " +
            "(8 Go de RAM ou plus). Si l'application se ferme au chargement, prenez le modèle suivant."
    private const val LIGHT_NOTE = "Conçu pour les téléphones : rapide, fonctionne sur tous les appareils."

    val all = listOf(
        LanguageInfo(
            "es", "Espagnol", "Español", "🇪🇸", "es-ES",
            listOf(
                VoskModel("vosk-model-es-0.42", "1,4 Go", BEST, BIG_NOTE),
                VoskModel("vosk-model-small-es-0.42", "39 Mo", LIGHT, LIGHT_NOTE)
            ), true
        ),
        LanguageInfo(
            "en", "Anglais", "English", "🇬🇧", "en-US",
            listOf(
                VoskModel("vosk-model-en-us-0.22", "1,8 Go", BEST, BIG_NOTE),
                VoskModel(
                    "vosk-model-en-us-0.22-lgraph", "128 Mo", MID,
                    "Nettement plus précis que le modèle léger tout en restant utilisable sur un bon téléphone " +
                        "(4 Go de RAM ou plus)."
                ),
                VoskModel("vosk-model-small-en-us-0.15", "40 Mo", LIGHT, LIGHT_NOTE)
            ), true
        ),
        LanguageInfo(
            "pt", "Portugais", "Português", "🇵🇹", "pt-BR",
            listOf(
                VoskModel("vosk-model-pt-fb-v0.1.1-20220516_2113", "1,6 Go", BEST, BIG_NOTE),
                VoskModel("vosk-model-small-pt-0.3", "31 Mo", LIGHT, LIGHT_NOTE)
            ), false
        ),
        LanguageInfo(
            "zh", "Chinois", "中文", "🇨🇳", "zh-CN",
            listOf(
                VoskModel("vosk-model-cn-0.22", "1,3 Go", BEST, BIG_NOTE),
                VoskModel("vosk-model-small-cn-0.22", "42 Mo", LIGHT, LIGHT_NOTE)
            ), false
        ),
        LanguageInfo(
            "ar", "Arabe", "العربية", "🇸🇦", "ar",
            listOf(
                VoskModel("vosk-model-ar-0.22-linto-1.1.0", "1,3 Go", BEST, BIG_NOTE),
                VoskModel(
                    "vosk-model-ar-mgb2-0.4", "318 Mo", MID,
                    "Le plus petit modèle d'arabe standard : prévoir un téléphone avec 4 Go de RAM ou plus."
                )
            ), false
        )
    )

    fun byCode(code: String): LanguageInfo = all.first { it.code == code }
}

data class Vocab(
    val word: String,
    val translation: String,
    val emoji: String,
    val example: String,
    val exampleTr: String
)

data class GrammarExample(val text: String, val translation: String)

data class GrammarPoint(
    val title: String,
    val explanation: String,
    val examples: List<GrammarExample>
)

data class DialogueLine(val speaker: String, val text: String, val translation: String) {
    /** Le rôle « B » est joué par l'apprenant. */
    val isUser: Boolean get() = speaker == "B"
}

sealed class QuizItem {
    data class Mcq(val question: String, val correct: String, val wrong: List<String>) : QuizItem()
    data class Typed(val prompt: String, val answers: List<String>) : QuizItem()
    data class Listen(val phrase: String, val correct: String, val wrong: List<String>) : QuizItem()
}

data class Homework(val prompt: String, val model: String, val keywords: List<String>)

data class Phrase(val text: String, val translation: String)

data class Lesson(
    val id: String,
    val level: String,
    val number: Int,
    val title: String,
    val titleTr: String,
    val emoji: String,
    val intro: String,
    val vocab: List<Vocab>,
    val grammar: List<GrammarPoint>,
    val dialogue: List<DialogueLine>,
    val quiz: List<QuizItem>,
    val homework: List<Homework>,
    val phrases: List<Phrase>
)

data class Course(val lang: String, val lessons: List<Lesson>) {
    fun lesson(id: String): Lesson? = lessons.firstOrNull { it.id == id }
}

object Levels {
    val order = listOf("A1", "A2", "B1", "B2", "C1", "C2")
    fun label(level: String): String = when (level) {
        "A1" -> "Débutant"
        "A2" -> "Élémentaire"
        "B1" -> "Intermédiaire"
        "B2" -> "Avancé"
        "C1" -> "Autonome"
        "C2" -> "Maîtrise"
        else -> level
    }
}

/** Charge les cours depuis assets/courses/<code>.json. */
object CourseRepository {
    private val cache = HashMap<String, Course>()

    fun load(context: Context, lang: String): Course {
        cache[lang]?.let { return it }
        val course = try {
            val text = context.assets.open("courses/$lang.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
            parse(lang, JSONObject(text))
        } catch (e: Exception) {
            Course(lang, emptyList())
        }
        cache[lang] = course
        return course
    }

    private fun JSONArray.objects(): List<JSONObject> = (0 until length()).map { getJSONObject(it) }
    private fun JSONArray.strings(): List<String> = (0 until length()).map { getString(it) }

    private fun parse(lang: String, root: JSONObject): Course {
        val lessons = root.getJSONArray("lessons").objects().map { o ->
            Lesson(
                id = o.getString("id"),
                level = o.getString("level"),
                number = o.getInt("number"),
                title = o.getString("title"),
                titleTr = o.getString("titleTr"),
                emoji = o.getString("emoji"),
                intro = o.optString("intro"),
                vocab = o.getJSONArray("vocab").objects().map {
                    Vocab(
                        it.getString("word"), it.getString("translation"), it.getString("emoji"),
                        it.getString("example"), it.getString("exampleTr")
                    )
                },
                grammar = o.getJSONArray("grammar").objects().map { g ->
                    GrammarPoint(
                        g.getString("title"), g.getString("explanation"),
                        g.getJSONArray("examples").objects().map {
                            GrammarExample(it.getString("text"), it.getString("translation"))
                        }
                    )
                },
                dialogue = o.getJSONArray("dialogue").objects().map {
                    DialogueLine(it.getString("speaker"), it.getString("text"), it.getString("translation"))
                },
                quiz = o.getJSONArray("quiz").objects().map { q ->
                    when (q.getString("type")) {
                        "typed" -> QuizItem.Typed(q.getString("prompt"), q.getJSONArray("answers").strings())
                        "listen" -> QuizItem.Listen(
                            q.getString("phrase"), q.getString("correct"), q.getJSONArray("wrong").strings()
                        )
                        else -> QuizItem.Mcq(
                            q.getString("question"), q.getString("correct"), q.getJSONArray("wrong").strings()
                        )
                    }
                },
                homework = o.getJSONArray("homework").objects().map {
                    Homework(it.getString("prompt"), it.getString("model"), it.getJSONArray("keywords").strings())
                },
                phrases = o.getJSONArray("phrases").objects().map {
                    Phrase(it.getString("text"), it.getString("translation"))
                }
            )
        }
        return Course(lang, lessons)
    }
}
