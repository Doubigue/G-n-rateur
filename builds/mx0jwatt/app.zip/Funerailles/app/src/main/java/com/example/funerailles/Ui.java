package com.example.funerailles;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class Ui {
    public static final int BG = Color.rgb(10, 10, 10), CARD = Color.rgb(38, 38, 38),
            PLUM = Color.rgb(244, 122, 0), GOLD = PLUM, INK = Color.WHITE,
            MUTED = Color.rgb(175, 175, 175), LINE = Color.rgb(75, 75, 75), WHITE = Color.WHITE;

    private static Context context;

    static int dp(int v) {
        return Math.round(v * context.getResources().getDisplayMetrics().density);
    }

    public static GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private static GradientDrawable outlined(int color, int radius) {
        GradientDrawable d = shape(color, radius);
        d.setStroke(dp(1), LINE);
        return d;
    }

    private static LinearLayout.LayoutParams spaced() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(12);
        return p;
    }

    public static TextView text(String s, int size, boolean bold) {
        TextView t = new TextView(context);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(INK);
        t.setLineSpacing(0, 1.15f);
        if (bold) t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        return t;
    }

    public static LinearLayout page(Activity a, String title) {
        context = a;
        ScrollView scroll = new ScrollView(a);
        scroll.setBackgroundColor(BG);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(a);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(20), dp(20), dp(28));
        scroll.addView(root);
        TextView h = text(title, 28, false);
        h.setTypeface(Typeface.DEFAULT_BOLD);
        h.setTextColor(INK);
        h.setPadding(0, 0, 0, dp(8));
        root.addView(h);
        return root;
    }

    /** Affiche la page avec la barre des quatre onglets en bas. */
    public static void show(Activity a, LinearLayout root) {
        context = a;
        LinearLayout screen = new LinearLayout(a);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setFitsSystemWindows(true);
        screen.addView((View) root.getParent(), new LinearLayout.LayoutParams(-1, 0, 1));
        LinearLayout bar = new LinearLayout(a);
        bar.setBackgroundColor(CARD);
        bar.setPadding(dp(4), dp(8), dp(4), dp(8));
        Class<?>[] pages = {MainActivity.class, CotisationActivity.class, ManageActivity.class, ReportsActivity.class};
        String[] labels = {"▦\nAccueil", "＋\nCotisation", "☷\nGroupe/Quartier", "▤\nRapport"};
        for (int i = 0; i < pages.length; i++) {
            final Class<?> target = pages[i];
            boolean active = target == a.getClass();
            TextView tab = text(labels[i], 12, active);
            tab.setGravity(Gravity.CENTER);
            tab.setTextColor(active ? PLUM : INK);
            tab.setPadding(0, dp(6), 0, dp(6));
            if (active) tab.setBackground(shape(Color.rgb(52, 52, 52), 24));
            tab.setOnClickListener(v -> { if (!active) open(a, target); });
            bar.addView(tab, new LinearLayout.LayoutParams(0, -2, 1));
        }
        screen.addView(bar);
        a.setContentView(screen);
    }

    /** Change d'onglet sans empiler les écrans. */
    public static void open(Activity a, Class<?> target) {
        a.startActivity(new Intent(a, target).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK));
        a.overridePendingTransition(0, 0);
    }

    public static void style(EditText e) {
        e.setTextColor(INK);
        e.setHintTextColor(MUTED);
        e.setPadding(dp(16), dp(14), dp(16), dp(14));
        e.setBackground(outlined(CARD, 12));
        e.setLayoutParams(spaced());
    }

    public static TextView button(Activity a, String label) {
        TextView b = text(label, 16, true);
        b.setGravity(Gravity.CENTER);
        b.setTextColor(WHITE);
        b.setMinHeight(dp(52));
        b.setPadding(dp(16), dp(14), dp(16), dp(14));
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x55FFFFFF), shape(PLUM, 14), null));
        b.setFocusable(true);
        b.setClickable(true);
        b.setLayoutParams(spaced());
        return b;
    }

    public static TextView menu(Activity a, String label) {
        TextView b = button(a, label);
        b.setGravity(Gravity.CENTER_VERTICAL);
        b.setTextColor(INK);
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x33F47A00), outlined(CARD, 14), null));
        return b;
    }

    public static TextView card(Activity a, String title, String subtitle) {
        SpannableString s = new SpannableString(title + "\n" + subtitle);
        int start = title.length() + 1;
        s.setSpan(new ForegroundColorSpan(MUTED), start, s.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        s.setSpan(new RelativeSizeSpan(0.88f), start, s.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        TextView t = text("", 17, true);
        t.setText(s);
        t.setPadding(dp(16), dp(14), dp(16), dp(14));
        t.setBackground(outlined(CARD, 14));
        t.setLayoutParams(spaced());
        return t;
    }

    public static TextView hero(String label, String amount, String detail) {
        SpannableString s = new SpannableString(label + "\n" + amount + "\n" + detail);
        int start = label.length() + 1, end = start + amount.length();
        s.setSpan(new RelativeSizeSpan(2.1f), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        s.setSpan(new ForegroundColorSpan(GOLD), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        TextView t = text("", 15, false);
        t.setText(s);
        t.setTextColor(WHITE);
        t.setPadding(dp(20), dp(22), dp(20), dp(22));
        t.setBackground(shape(PLUM, 20));
        t.setLayoutParams(spaced());
        return t;
    }
}
