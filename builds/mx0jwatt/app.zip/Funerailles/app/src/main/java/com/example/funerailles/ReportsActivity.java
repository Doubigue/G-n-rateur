package com.example.funerailles;

import android.app.*;
import android.os.Bundle;
import android.os.Environment;
import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.text.*;
import java.util.*;

public class ReportsActivity extends Activity {
    DatabaseHelper db;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        db = new DatabaseHelper(this);
        LinearLayout root = Ui.page(this, "Rapports PDF");
        root.addView(Ui.text("Générez le rapport PDF de toutes les cotisations.", 15, false));
        TextView button = Ui.button(this, "Générer le rapport PDF");
        button.setOnClickListener(v -> export(getSharedPreferences("app", MODE_PRIVATE).getString("responsable", "")));
        root.addView(button);
        TextView history = Ui.menu(this, "Voir l'historique des cotisations");
        history.setOnClickListener(v -> startActivity(new android.content.Intent(this, ContributorsActivity.class)));
        root.addView(history);
        TextView sync = Ui.menu(this, "Tester la synchronisation");
        sync.setOnClickListener(v -> SyncManager.testConnection((ok, message) ->
            runOnUiThread(() -> Toast.makeText(this, message, Toast.LENGTH_LONG).show())));
        root.addView(sync);
        Ui.show(this,root);
    }

    int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    /** Nouvelle page avec le titre et les en-têtes de colonnes. */
    PdfDocument.Page newPage(PdfDocument pdf, int number, Paint p) {
        PdfDocument.Page page = pdf.startPage(new PdfDocument.PageInfo.Builder(595, 842, number).create());
        Canvas c = page.getCanvas();
        c.drawColor(Color.WHITE);
        p.setColor(Color.rgb(255, 133, 0)); c.drawRect(0, 0, 595, 105, p);
        p.setColor(Color.BLACK); p.setTextSize(27); p.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        c.drawText("RAPPORT DES COTISATIONS", 35, 58, p);
        p.setTextSize(12); p.setTypeface(Typeface.DEFAULT);
        c.drawText("Collecte funéraire • FCFA • " + new SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE).format(new Date()), 35, 85, p);
        p.setTextSize(13); p.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        c.drawText("Nom et prénom", 35, 145, p); c.drawText("Montant", 330, 145, p); c.drawText("Catégorie / lieu", 420, 145, p);
        p.setTypeface(Typeface.DEFAULT); p.setTextSize(10);
        return page;
    }

    void finishPage(PdfDocument pdf, PdfDocument.Page page, int number, Paint p) {
        p.setColor(Color.GRAY); p.setTextSize(8); p.setTypeface(Typeface.DEFAULT);
        page.getCanvas().drawText("Page " + number, 520, 832, p);
        pdf.finishPage(page);
    }

    /** Raccourcit un texte trop large pour sa colonne. */
    String fit(String s, Paint p, float width) {
        if (p.measureText(s) <= width) return s;
        return s.substring(0, p.breakText(s, true, width - p.measureText("…"), null)) + "…";
    }

    void export(String responsible) {
        PdfDocument pdf = new PdfDocument();
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        List<String[]> rows = db.getCotisations("Tous", "Tous");
        int number = 1, y = 175, count = rows.size();
        PdfDocument.Page page = newPage(pdf, number, p);
        Canvas c = page.getCanvas();
        for (String[] r : rows) {
            if (y > 790) {
                finishPage(pdf, page, number, p);
                page = newPage(pdf, ++number, p); c = page.getCanvas(); y = 175;
            }
            c.drawText(fit(r[0], p, 285), 35, y, p);
            c.drawText(NumberFormat.getIntegerInstance(Locale.FRANCE).format(Double.parseDouble(r[1])) + " F", 330, y, p);
            c.drawText(fit(r[2] + " / " + r[3], p, 140), 420, y, p);
            y += 21;
        }
        // Le total et la signature ont besoin du bas de la page
        if (y > 640) {
            finishPage(pdf, page, number, p);
            page = newPage(pdf, ++number, p); c = page.getCanvas();
        }
        p.setColor(Color.rgb(255, 133, 0)); c.drawRect(35, 650, 560, 652, p);
        p.setColor(Color.BLACK); p.setTypeface(Typeface.create("sans-serif", Typeface.BOLD)); p.setTextSize(16);
        c.drawText("TOTAL : " + NumberFormat.getIntegerInstance(Locale.FRANCE).format(db.getTotal()) + " FCFA", 35, 680, p);
        p.setTypeface(Typeface.DEFAULT); p.setTextSize(10);
        if (!responsible.isEmpty()) c.drawText("Responsable : " + responsible, 35, 720, p);
        p.setColor(Color.GRAY); p.setTextSize(8); p.setTypeface(Typeface.DEFAULT);
        c.drawText(count + " cotisation(s) au total", 330, 800, p);
        finishPage(pdf, page, number, p);
        try {
            File dir = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
            if (dir != null && !dir.exists()) dir.mkdirs();
            File f = new File(dir, "Rapport_Funerailles_" + System.currentTimeMillis() + ".pdf");
            FileOutputStream out = new FileOutputStream(f); pdf.writeTo(out); out.close();
            Toast.makeText(this, "PDF créé : " + f.getAbsolutePath(), Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Erreur PDF : " + e.getMessage(), Toast.LENGTH_LONG).show();
        } finally { pdf.close(); }
    }
}
