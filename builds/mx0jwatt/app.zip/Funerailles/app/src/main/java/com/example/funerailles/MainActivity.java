package com.example.funerailles;

import android.app.*;
import android.content.Intent;
import android.graphics.*;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.*;
import com.google.zxing.*;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import java.text.NumberFormat;
import java.util.*;

public class MainActivity extends Activity {
    private DatabaseHelper db;
    private boolean visible = false;

    @Override public void onCreate(Bundle b) { super.onCreate(b); db = new DatabaseHelper(this); }
    @Override protected void onResume() { super.onResume(); render(); }

    private static String number(double v) { return NumberFormat.getIntegerInstance(Locale.FRANCE).format(v); }

    private void render() {
        LinearLayout root = Ui.page(this, "Bienvenue");
        String name = getSharedPreferences("app", MODE_PRIVATE).getString("responsable", "");
        String total = number(db.getTotal()) + " FCFA";

        LinearLayout card = new LinearLayout(this);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(Ui.dp(16), Ui.dp(20), Ui.dp(16), Ui.dp(20));
        card.setBackground(Ui.shape(Ui.CARD, 20));
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);

        TextView owner = Ui.text((name.isEmpty() ? "Nom du responsable" : name) + "  ⌄", 16, true);
        owner.setOnClickListener(v -> editName(name));
        TextView amount = Ui.text((visible ? total : "****** FCFA") + "\n" + (visible ? "Masquer" : "Afficher"), 20, true);
        amount.setPadding(0, Ui.dp(14), 0, Ui.dp(14));
        amount.setOnClickListener(v -> { visible = !visible; render(); });
        TextView history = Ui.text("Voir historique  ›", 15, true);
        history.setTextColor(Ui.PLUM);
        history.setPadding(0, Ui.dp(8), 0, Ui.dp(8));
        history.setOnClickListener(v -> startActivity(new Intent(this, ContributorsActivity.class)));
        left.addView(owner); left.addView(amount); left.addView(history);
        card.addView(left, new LinearLayout.LayoutParams(0, -2, 1));

        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        right.setGravity(Gravity.CENTER_HORIZONTAL);
        ImageView qr = new ImageView(this);
        qr.setBackground(Ui.shape(Ui.PLUM, 16));
        qr.setPadding(Ui.dp(6), Ui.dp(6), Ui.dp(6), Ui.dp(6));
        qr.setImageBitmap(qrCode("Funérailles\nResponsable : " + name + "\nTotal : " + total));
        qr.setContentDescription("Code QR du total des cotisations");
        right.addView(qr, new LinearLayout.LayoutParams(Ui.dp(130), Ui.dp(130)));
        right.addView(Ui.text("Scanner le total", 13, false));
        card.addView(right);
        root.addView(card, new LinearLayout.LayoutParams(-1, -2));

        section(root, "Cotisations par groupe", db.getTotals("groupes", "Groupe"));
        section(root, "Cotisations par quartier", db.getTotals("quartiers", "Quartier"));
        Ui.show(this, root);
    }

    /** Titre puis cartes sur quatre colonnes, montants en FCFA. */
    private void section(LinearLayout root, String title, List<String[]> items) {
        TextView h = Ui.text(title + "  ›", 19, true);
        h.setPadding(0, Ui.dp(24), 0, Ui.dp(6));
        h.setOnClickListener(v -> Ui.open(this, ManageActivity.class));
        root.addView(h);
        if (items.isEmpty()) root.addView(Ui.text("Touchez le titre pour en ajouter.", 14, false));
        LinearLayout row = null;
        for (int i = 0; i < items.size(); i++) {
            if (i % 4 == 0) { row = new LinearLayout(this); root.addView(row); }
            TextView t = Ui.text(items.get(i)[0] + "\n" + number(Double.parseDouble(items.get(i)[1])), 12, true);
            t.setGravity(Gravity.CENTER);
            t.setPadding(Ui.dp(4), Ui.dp(10), Ui.dp(4), Ui.dp(10));
            t.setBackground(Ui.shape(Ui.CARD, 14));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, Ui.dp(96), 1);
            p.setMargins(Ui.dp(3), Ui.dp(3), Ui.dp(3), Ui.dp(3));
            row.addView(t, p);
        }
        // Cases vides pour garder la même largeur sur la dernière ligne
        for (int i = items.size(); i % 4 != 0; i++) {
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, 1, 1);
            p.setMargins(Ui.dp(3), 0, Ui.dp(3), 0);
            row.addView(new android.view.View(this), p);
        }
    }

    private void editName(String current) {
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setText(current);
        e.setHint("Nom et prénom");
        new AlertDialog.Builder(this).setTitle("Responsable des funérailles").setView(e)
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Enregistrer", (d, w) -> {
                getSharedPreferences("app", MODE_PRIVATE).edit().putString("responsable", e.getText().toString().trim()).apply();
                render();
            }).show();
    }

    private Bitmap qrCode(String content) {
        try {
            Map<EncodeHintType, Object> hints = new HashMap<>();
            hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
            hints.put(EncodeHintType.MARGIN, 2);
            BitMatrix m = new QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, 400, 400, hints);
            Bitmap b = Bitmap.createBitmap(400, 400, Bitmap.Config.RGB_565);
            for (int x = 0; x < 400; x++)
                for (int y = 0; y < 400; y++) b.setPixel(x, y, m.get(x, y) ? Color.BLACK : Color.WHITE);
            return b;
        } catch (WriterException e) { return null; }
    }
}
