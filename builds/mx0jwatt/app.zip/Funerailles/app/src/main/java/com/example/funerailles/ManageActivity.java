package com.example.funerailles;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;
import java.text.NumberFormat;
import java.util.Locale;

public class ManageActivity extends Activity {
    private DatabaseHelper db;
    private boolean groups = true;

    @Override public void onCreate(Bundle b) { super.onCreate(b); db = new DatabaseHelper(this); render(); }

    private void render() {
        LinearLayout root = Ui.page(this, "Groupe/Quartier");
        LinearLayout choice = new LinearLayout(this);
        for (boolean isGroup : new boolean[]{true, false}) {
            TextView c = Ui.button(this, isGroup ? "Groupes" : "Quartiers");
            c.setBackground(Ui.shape(isGroup == groups ? Ui.PLUM : Ui.CARD, 14));
            c.setOnClickListener(v -> { groups = isGroup; render(); });
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1);
            p.setMargins(Ui.dp(3), 0, Ui.dp(3), 0);
            choice.addView(c, p);
        }
        root.addView(choice);

        String table = groups ? "groupes" : "quartiers";
        EditText name = new EditText(this);
        name.setSingleLine(true);
        name.setHint(groups ? "Nom du groupe" : "Nom du quartier ou village");
        Ui.style(name);
        root.addView(name);
        TextView add = Ui.button(this, groups ? "Ajouter le groupe" : "Ajouter le quartier");
        add.setOnClickListener(v -> {
            String s = name.getText().toString().trim();
            if (s.isEmpty()) { name.setError("Saisissez un nom"); return; }
            if (db.addItem(table, s)) render();
            else Toast.makeText(this, "Ce nom existe déjà", Toast.LENGTH_SHORT).show();
        });
        root.addView(add);

        for (String[] r : db.getTotals(table, groups ? "Groupe" : "Quartier"))
            root.addView(Ui.card(this, r[0], NumberFormat.getIntegerInstance(Locale.FRANCE).format(Double.parseDouble(r[1])) + " FCFA"));
        Ui.show(this, root);
    }
}
