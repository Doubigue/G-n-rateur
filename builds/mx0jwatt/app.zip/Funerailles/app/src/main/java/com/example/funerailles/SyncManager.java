package com.example.funerailles;

import com.google.firebase.firestore.FirebaseFirestore;
import java.util.*;

/** Envoie les nouvelles écritures locales vers Firestore lorsque Firebase est configuré.
 * La persistance hors ligne Firestore est activée par défaut sur Android.
 */
public class SyncManager {
    public interface Callback { void done(boolean ok, String message); }
    public static void testConnection(Callback cb) {
        try {
            FirebaseFirestore.getInstance().collection("_status").document("connection")
                .set(Collections.singletonMap("updatedAt", System.currentTimeMillis()))
                .addOnSuccessListener(v -> cb.done(true,"Synchronisation en ligne réussie"))
                .addOnFailureListener(e -> cb.done(false,"Synchronisation indisponible : "+e.getLocalizedMessage()));
        } catch (Exception e) { cb.done(false,"Firebase non configuré. Ajoutez google-services.json."); }
    }
}
