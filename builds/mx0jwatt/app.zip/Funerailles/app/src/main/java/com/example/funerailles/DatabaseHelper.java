package com.example.funerailles;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.util.*;

public class DatabaseHelper extends SQLiteOpenHelper {
    public DatabaseHelper(Context c) { super(c, "funerailles.db", null, 1); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE cotisations(id INTEGER PRIMARY KEY AUTOINCREMENT, nom TEXT NOT NULL, montant REAL NOT NULL, categorie TEXT NOT NULL, lieu TEXT NOT NULL, date TEXT NOT NULL, synced INTEGER DEFAULT 0)");
        db.execSQL("CREATE TABLE groupes(id INTEGER PRIMARY KEY AUTOINCREMENT, nom TEXT UNIQUE NOT NULL)");
        db.execSQL("CREATE TABLE quartiers(id INTEGER PRIMARY KEY AUTOINCREMENT, nom TEXT UNIQUE NOT NULL)");
    }
    @Override public void onUpgrade(SQLiteDatabase db,int oldV,int newV) { }
    public boolean addCotisation(String nom,double montant,String categorie,String lieu,String date) {
        ContentValues v=new ContentValues(); v.put("nom",nom);v.put("montant",montant);v.put("categorie",categorie);v.put("lieu",lieu);v.put("date",date);v.put("synced",0);
        return getWritableDatabase().insert("cotisations",null,v)>0;
    }
    public boolean addItem(String table,String nom) { ContentValues v=new ContentValues();v.put("nom",nom);return getWritableDatabase().insert(table,null,v)>0; }
    public List<String> getItems(String table) { List<String> a=new ArrayList<>();Cursor c=getReadableDatabase().rawQuery("SELECT nom FROM "+table+" ORDER BY nom",null);while(c.moveToNext())a.add(c.getString(0));c.close();return a; }
    public List<String[]> getCotisations(String categorie,String lieu) {
        List<String[]> a=new ArrayList<>(); String sql="SELECT nom,montant,categorie,lieu,date FROM cotisations"; List<String> args=new ArrayList<>();
        if(categorie!=null&&!categorie.equals("Tous")){sql+=" WHERE categorie=?";args.add(categorie);}
        if(lieu!=null&&!lieu.equals("Tous")){sql+=args.isEmpty()?" WHERE lieu=?":" AND lieu=?";args.add(lieu);}
        sql+=" ORDER BY id DESC"; Cursor c=getReadableDatabase().rawQuery(sql,args.toArray(new String[0]));while(c.moveToNext())a.add(new String[]{c.getString(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4)});c.close();return a;
    }

    public List<String> getCotisants(String categorie,String lieu) {
        List<String> a=new ArrayList<>();
        Cursor c=getReadableDatabase().rawQuery(
            "SELECT DISTINCT nom FROM cotisations WHERE categorie=? AND lieu=? ORDER BY nom",
            new String[]{categorie,lieu});
        while(c.moveToNext()) a.add(c.getString(0));
        c.close(); return a;
    }
    public String findCotisant(String nom,String categorie,String lieu) {
        Cursor c=getReadableDatabase().rawQuery(
            "SELECT nom,montant,date FROM cotisations WHERE categorie=? AND lieu=? AND lower(trim(nom))=lower(trim(?)) ORDER BY id LIMIT 1",
            new String[]{categorie,lieu,nom});
        String result=null;
        if(c.moveToFirst()) result=c.getString(0)+"|"+c.getString(1)+"|"+c.getString(2);
        c.close(); return result;
    }
    /** Chaque groupe ou quartier avec la somme de ses cotisations. */
    public List<String[]> getTotals(String table,String categorie) {
        List<String[]> a=new ArrayList<>();
        Cursor c=getReadableDatabase().rawQuery("SELECT t.nom,COALESCE(SUM(c.montant),0) FROM "+table+" t LEFT JOIN cotisations c ON c.lieu=t.nom AND c.categorie=? GROUP BY t.nom ORDER BY t.nom",new String[]{categorie});
        while(c.moveToNext())a.add(new String[]{c.getString(0),String.valueOf(c.getDouble(1))});
        c.close(); return a;
    }
    public double getTotal(){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(montant),0) FROM cotisations",null);double n=0;if(c.moveToFirst())n=c.getDouble(0);c.close();return n;}
    public int getCount(){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM cotisations",null);int n=0;if(c.moveToFirst())n=c.getInt(0);c.close();return n;}
}
