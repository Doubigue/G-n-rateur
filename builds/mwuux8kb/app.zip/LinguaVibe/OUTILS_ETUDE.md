# Outils d'étude (révision, statistiques, examens…)

Code : `study/StudyStore.kt` (données), `study/StudyReminder.kt` (rappel), `export/StudyPdf.kt` (PDF), écrans dans `ui/`.

| Fonction | Écran / fichier | Accès |
|---|---|---|
| Révision espacée (cartes des erreurs, 1-3-7-14-30-60 jours) + mini-quiz du jour | `ReviewScreen.kt` | Carte « Révision du jour » sur l'accueil, notification |
| Statistiques : XP, jours de suite, minutes, réussite, calendrier 5 semaines, boîtes, réussite par temps, examens | `StatsScreen.kt` | Accueil → Statistiques |
| Rappel quotidien (heure au choix, test) avec mini-quiz de 3 questions | `StudyReminder.kt` + carte dans Statistiques | — |
| Fiches par temps (15) : règle, modèles -ar/-er/-ir, irréguliers, entraînement 10 formes, PDF | `TenseSheets.kt` | Espagnol → Fiches par temps |
| Dictée (10 phrases, correction mot à mot, accents en jaune) | `Dictation.kt` | Quiz de chaque leçon → Dictée |
| Conversation libre au micro ou au clavier (7 sujets, A1 à B2) | `ConversationScreen.kt` | Espagnol → Conversation |
| Examens de niveau A1 à C2 (30 questions, 70 %) + certificat PDF au nom de l'élève | `ExamScreen.kt` | Accueil → Examens |
| Tout télécharger : micro léger + voix hors ligne + audios, place estimée et espace libre | `OfflineScreen.kt` | Accueil → Hors ligne |

- Toute réponse fausse (quiz, mini-quiz, examen, dictée, entraînement, conversation) devient une carte de révision.
- Le temps d'étude est compté minute par minute quand l'application est au premier plan (`AppRoot`).
- Model 2 : leçons 35 à 38 dans `tools/content_m2_more3.py` (sport et santé, vie citoyenne, aéroport et discours indirect, littérature).
