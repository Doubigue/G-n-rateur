LINGUAVIBE — VOIX DE SYNTHÈSE VOCALE (TTS)

Langues de l'application : espagnol (es), anglais (en), portugais (pt), russe (ru),
chinois (zh), arabe (ar) et français (fr).

Lien officiel Google Play (moteur de synthèse vocale Android) :
https://play.google.com/store/apps/details?id=com.google.android.tts

Guide officiel d'installation des données vocales :
https://support.google.com/accessibility/android/answer/6006983?hl=fr

Sur Android : Paramètres > Accessibilité ou Système > Sortie de synthèse vocale >
moteur Google > Installer les données vocales > sélectionner la langue > télécharger.
Les liens directs vers un fichier vocal par langue ne sont pas publiés par Google :
les données se téléchargent depuis le moteur TTS sur l'appareil.

Dans l'application, la section Voix propose maintenant les 7 langues, dont le français.
Pour le français, un petit pack de phrases de démonstration peut être enregistré hors ligne.
