# Format des données LinguaVibe (Firebase)

`linguavibe_data.json` regroupe toutes les données de l'application. Dans Realtime Database, il se place sous le
nœud `linguavibe` (console : Realtime Database › ⋮ › Importer JSON, après avoir sélectionné `linguavibe`),
ou s'envoie avec l'appli **LinguaVibe Admin**.

```
meta     { version, updatedAt, languages: [...], lessonCount }
courses  { <code langue>: { lang, lessons: [ Leçon, ... ] } }        codes : es en pt ru zh ar
```

## Leçon

| Champ | Contenu |
|---|---|
| `id` | identifiant unique et stable (ex. `es-12`) : la progression de l'apprenant y est rattachée |
| `level` | A1, A2, B1, B2, C1 ou C2 (la leçon apparaît dans ce niveau) |
| `number` | numéro affiché |
| `title`, `titleTr`, `emoji`, `intro` | titre dans la langue, titre en français, emoji, introduction |
| `vocab[]` | `word, translation, emoji, example, exampleTr, pron, examplePron` |
| `grammar[]` | `title, explanation, examples[] { text, translation, pron }` |
| `dialogue[]` | `speaker` (A = l'appli, B = l'apprenant), `text, translation, pron`, `name` (facultatif : nom du personnage) |
| `scenes[]` | facultatif (MODEL 2 et 3) : `title, titleTr, scene` (dessin : patio, familia, campo, selva, veillee, mercado, aula, maquis, gare, dispensaire, telefono, couture, fete, bureau, place), `context`, `cast` {A, B}, `lines[]` (mêmes champs que `dialogue`) |
| `quiz[]` | `type: "mcq"` → `question, correct, wrong[]` · `type: "listen"` → `phrase, correct, wrong[]` · `type: "typed"` → `prompt, answers[]` |
| `homework[]` | `prompt, model, keywords[]` (variantes séparées par « / ») |
| `phrases[]` | phrases à prononcer : `text, translation, pron` |
| `reading` | texte de lecture : `title, titleTr, sentences[] { text, pron, translation }` |

`pron` = prononciation figurée (syllabe accentuée en MAJUSCULES) ; pour le chinois, utiliser le pinyin avec tons ; pour
l’arabe, une translittération latine cohérente. Les anciennes leçons peuvent encore contenir des champs vides. Toute leçon ajoutée avec ces champs profite de toutes les
fonctions de l'application : cartes, écoute, lecture, dialogue au micro, correction de prononciation, quiz, devoir.

Régénérer le fichier depuis les sources du projet : `python3 tools/export_firebase_json.py`.
