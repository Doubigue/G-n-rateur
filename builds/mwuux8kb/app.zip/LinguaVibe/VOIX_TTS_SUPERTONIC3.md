# Voix TTS hors ligne — Supertonic 3

## Ce qui est intégré dans cette version

- Moteur TTS Supertonic 3 via Sherpa-ONNX (Android/Kotlin).
- Téléchargement du modèle depuis les paramètres LinguaVibe, dans `filesDir/tts-models/`.
- Synthèse locale de nouveaux textes, sans requête réseau après installation.
- Supertonic 3 : français (`fr`), espagnol (`es`), anglais (`en`), portugais (`pt`), russe (`ru`) et arabe (`ar`). Le chinois n'est pas dans la liste officielle Supertonic 3.
- Chinois : pack séparé `vits-icefall-zh-aishell3` via Sherpa-ONNX (174 speakers), téléchargé dans le stockage privé de l'application. Ce modèle n'est ni Piper ni Kokoro.
- Choix d'un speaker Supertonic (ID 0 à 9) par langue ; aperçu vocal depuis l'écran des voix.
- Cache audio privé dans `filesDir/tts-supertonic/cache/`.
- Suppression du modèle depuis les paramètres pour libérer l'espace.

## Téléchargement

Le modèle multilingue Supertonic 3 partagé fait environ 132 Mo à télécharger et 145 Mo une fois extrait. Le modèle officiel annonce 31 langues, mais sa liste ne comprend pas le chinois. Le pack Supertonic est téléchargé une seule fois puis la langue et la voix sont sélectionnées dans l'application. Le chinois utilise un second pack VITS Icefall AISHELL-3 (modèle ONNX d'environ 29 Mo, 174 speakers) téléchargé séparément.

Archive officielle utilisée :
`https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/sherpa-onnx-supertonic-3-tts-int8-2026-05-11.tar.bz2`

Référence modèle et langue : https://k2-fsa.github.io/sherpa/onnx/tts/supertonic.html
Pack chinois : https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-icefall-zh-aishell3.tar.bz2
Documentation AISHELL-3 : https://k2-fsa.github.io/sherpa/onnx/tts/pretrained_models/vits.html

## Licences

- Sherpa-ONNX : Apache 2.0.
- Modèle Supertonic 3 : OpenRAIL-M ; lire les conditions du modèle avant distribution commerciale ou redistribution de ses poids.
- Modèle chinois AISHELL-3 : les conditions et notices de licence sont incluses dans l'archive de modèle ; vérifier les fichiers `LICENSE`/`README` de la version téléchargée avant toute redistribution.
- Supertonic 3 et Sherpa-ONNX sont distincts des moteurs Piper et Kokoro ; aucun modèle Piper/Kokoro n'est utilisé par cette intégration.

## Limite de validation

La source a été modifiée et l'archive du modèle est téléchargée à l'installation. La compilation Android et un test réel sur appareil n'ont pas été exécutés dans cet environnement (pas d'accès réseau de build/Gradle ici). Il faut ouvrir le projet dans Android Studio, synchroniser Gradle puis tester le téléchargement et la lecture sur un téléphone ARM64.
