# Refonte du style des cours Model 2 et Model 3

## Ce qui change à l'écran (onglet « Leçon »)

Le texte du manuel n'est plus affiché comme une suite de cartes identiques : il est découpé et mis en forme selon sa nature.

- **En-têtes de chapitre** : pastille colorée avec emoji, repère « ÉTAPE 1 » / « NOTION 1.1 », titre en grand et filet doré. Une bande « Au programme » défilante résume les chapitres.
- **Encadrés** : Objectif 🎯, À retenir 📌, Conseil / Méthode 💡, Attention ⚠️, Règle 📏, chacun avec sa couleur. La phrase d'introduction identique dans les 16 leçons du Model 2 est supprimée.
- **Tableaux** : vrais tableaux avec en-tête coloré et lignes alternées. Les cellules espagnoles sont cliquables pour être écoutées. Les en-têtes répétés à chaque page du PDF sont fusionnés.
- **Exemples** (Model 2) : paires espagnol / français avec bouton d'écoute.
- **Dialogues** : bulles de conversation alternées (A / B, Vendedora / Cliente…), cliquables, avec traduction à révéler.
- **Lectures** : carte « Lecture » avec texte en italique, bouton d'écoute et traduction à révéler.
- **Questions de compréhension** : liste numérotée (les questions en espagnol sont écoutables).
- **Exercices et activités** (Model 3) : cartes dorées avec titre.
- **Fiches de grammaire** : sous-titres A, B, C… en pastilles.
- **Auto-évaluation** : cases « Oui / Pas encore » interactives.
- **Semaine type** (Model 2, leçon 16) : liste J1 à J7.
- Les citations « … » et les phrases ¿…? ¡…! sont mises en valeur dans les paragraphes.
- La note technique « Contenu officiel intégré depuis le manuel… » n'est plus affichée.

## Corrections au passage

- Les titres numérotés du Model 2 (« 1. Comprendre la règle », etc.) n'étaient pas reconnus comme titres : ils le sont maintenant.
- « Travail personnel » et « Auto-évaluation » disparaissaient de l'écran à cause de l'ancien filtre des quiz : ils sont de nouveau affichés.
- Les puces coupées sur deux lignes dans le texte source sont recollées.

## Fichiers

- `app/src/main/java/com/linguavibe/app/ui/ManualStyle.kt` (nouveau : découpage du texte et composants)
- `app/src/main/java/com/linguavibe/app/ui/LessonScreen.kt` (utilise `ManualCourse`, ancien affichage retiré)
- `app/build.gradle.kts` (correction du doublon sherpa-onnx, tour précédent)

Les JSON, les identifiants de leçons, les progressions, les quiz et le moteur vocal ne sont pas modifiés.

## Limites

Compilation et rendu sur téléphone non vérifiés ici (pas de Gradle ni de SDK Android). Le découpage du texte a été testé sur les 16 leçons du Model 2 et les 4 unités du Model 3 avec un équivalent Python de la logique. Compilez dans Android Studio avant installation.
