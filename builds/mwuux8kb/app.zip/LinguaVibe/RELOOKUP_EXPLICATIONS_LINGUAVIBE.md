# Refonte visuelle des explications LinguaVibe

## Changements
- Remplacement du bloc d'introduction simple par une carte « Le cours en clair » avec dégradé, hiérarchie typographique et repère visuel.
- Refonte des sections issues du contenu du manuel : en-têtes colorés, numérotation, titres mieux hiérarchisés, espaces plus généreux et paragraphes plus lisibles.
- Mise en évidence des éléments présentés sous forme de puces dans des encadrés légers.
- Conservation du texte pédagogique et des exemples existants : cette intervention porte sur la présentation dans l'application, pas sur la réécriture du contenu du manuel.
- Ajout de la récupération du contexte Android dans l'écran de leçon pour charger correctement une illustration locale.

## Vérification
Les sources Kotlin ont été modifiées et relues. La compilation Android et le rendu sur appareil n'ont pas pu être exécutés dans cet environnement : le projet ne contient pas le Gradle Wrapper (`gradlew` / `gradle-wrapper.jar`) et aucun Gradle système n'est disponible.
