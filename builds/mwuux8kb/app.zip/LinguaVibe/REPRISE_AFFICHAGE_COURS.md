# Reprise de l'affichage des cours Model 2 et Model 3

## Corrections apportées

- Suppression de l'affichage brut du texte extrait du PDF dans une seule grande carte.
- Présentation du contenu en sections et paragraphes distincts, avec titres hiérarchisés et espacement mobile.
- Suppression des mentions techniques « PAGE 1 », « PAGE 2 », etc. dans l'écran de leçon.
- Les quiz et corrigés extraits du texte ne sont plus répétés dans l'onglet du cours : l'entraînement reste dans l'onglet Quiz dédié.
- L'écran de sélection des modèles 2 et 3 n'affiche plus le bandeau Alphabet ni les fausses rubriques « À venir » propres au parcours général.
- Le titre de l'écran de cours devient « Programme du cours » plutôt que « Parcours du manuel PDF ».

## Fichiers modifiés

- `app/src/main/java/com/linguavibe/app/ui/LessonScreen.kt`
- `app/src/main/java/com/linguavibe/app/ui/Screens.kt`

Les ressources pédagogiques JSON, les identifiants de cours, les progressions et le moteur TTS n'ont pas été remplacés dans cette reprise.

## Vérifications et limites

- Vérification de présence des deux ressources `es_model2.json` et `es_model3.json` et de leurs contenus.
- Vérification de l'absence de pagination PDF dans le rendu prévu par le nouvel affichage (les lignes PAGE sont filtrées à l'affichage).
- Compilation Gradle non exécutée : aucun exécutable `gradlew`, aucun `gradle-wrapper.jar` et aucune installation Gradle ne sont présents dans l'environnement.
- Aucun test sur appareil Android n'a été effectué.

Cette reprise corrige la présentation et la séparation des contenus ; elle ne prétend pas valider la compilation ou le rendu sur un téléphone.
