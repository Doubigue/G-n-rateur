# Amélioration des MODEL 2 et 3, dialogues illustrés et correction du lexique

## 1. Nouveau style des leçons MODEL 2 et MODEL 3
Les leçons du manuel ont maintenant un style « manuel africain » qui les distingue du MODEL 1 :
- palette **Portfolio DL VIBE STUDIO** : papier crème, orange brûlé, brun profond ; couleurs de niveau en tons de terre (terre cuite, ocre, brique, brun, bordeaux) ;
- fond papier quadrillé léger et **frises bogolan** (zigzags + points) sous les onglets et dans les cartes ;
- nouvel en-tête de leçon : grande scène lineart animée, numéro de leçon, niveau, nombre de dialogues, de mots et de questions ;
- la liste des leçons des MODEL 2 et 3 reprend le même style.
Le MODEL 1 et les autres langues ne changent pas.

## 2. Dialogues illustrés en couleur
- **15 illustrations en couleur** (aplats, style album jeunesse ivoirien) : cour du collège avec le drapeau ivoirien, famille à table, village et case au toit de chaume, génie de la forêt qui emporte Kadjo, veillée autour du feu, marché avec parasol, salle de classe, maquis (kedjenou, attiéké, alloco), gare routière avec le car pour Korhogo, centre de santé, appel téléphonique, couturier et pagnes, fête au djembé, bureau, place à l'horloge. Personnages aux pagnes wax, kente et bogolan, foulards noués, bulles en espagnol. Aperçu : `SCENES_DIALOGUES_APERCU.png`.
- Les images sont dans `app/src/main/assets/scenes/*.webp` (≈ 700 Ko au total), générées par `tools/flat_scenes.py` (modifiable puis relancer). Un léger zoom lent les anime à l'écran. Les anciens dessins lineart (`ui/Scenes.kt`) ne servent plus que de secours si une image manque.
- Chaque leçon a désormais **2 scènes (MODEL 2) ou 3 scènes (MODEL 3)**, avec titre, mise en situation et personnages nommés (Fatou, Koffi, Silué, Kadjo, Abolé, Api, Aya, Moussa…), à Abidjan, Bouaké, Korhogo, Man, Daloa…
- Écran Dialogue : onglets de scènes, illustration qui se dessine, chips des personnages (« Koffi (vous) »), bulles avec nom et initiale, bouton « Écouter la scène », traduction affichable ou masquable, jeu de rôle au micro sur les répliques de l'apprenant, puis « Scène suivante ».
- L'export PDF affiche les scènes, leur contexte et le nom des personnages.

## 3. Leçons enrichies
| | MODEL 2 (16 leçons) | MODEL 3 (4 unités) |
|---|---|---|
| Scènes de dialogue | 32 (235 répliques) | 12 (91 répliques) |
| Vocabulaire | 96 → 224 mots, tous avec exemple | 67 → 113 mots |
| Points de grammaire | 16 → 48 | 0 → 14 |
| Devoirs | 16 → 48 | 0 → 12 |
| Questions de quiz | 64 → 112 | 62 → 75 |

Le **MODEL 3** suit les pages du manuel photographiées : « Me llamo Fatou » (Koffi, Silué de Korhogo, éste / ésta), « Mi familia » (Abolé 45 ans, Fatou 44, Api 14, Adou 12, Yéli 10), l'esquisse grammaticale (formes, couleurs, taille), « J'intègre » (carnet sur la famille d'un ami) et « Escucha a tus padres » (Kadjo, le génie de la forêt, la morale du conte).
La prononciation figurée est calculée partout (vocabulaire, exemples, dialogues, phrases, lectures).

## 4. Lexique corrigé
Les 10 000 entrées ont été relues. Au-delà des 500 premières (bonnes), une grande partie venait d'un alignement automatique avec des sens faux (« despedir » = « déchirer, larme », « fustigar » = « interrupteur », « desnudez » = « déshabiller », « empresario » = « employeur »…).
- **2 414 traductions corrigées** (sens faux, listes de synonymes incohérentes, coquilles, fautes d'orthographe espagnoles comme « farina » → « harina », « década »).
- **2 354 entrées retirées** : noms de personnes célèbres (George Bush, Gustav Mahler…), noms latins d'espèces (« género Alectura », « familia Suidae »…), lettres isolées et lignes illisibles.
- Le lexique compte maintenant **7 646 mots fiables**. Les numéros d'origine sont conservés : les mots appris et les favoris ne sont pas perdus.
- Le classeur contient une nouvelle feuille **« Corrections traductions »** qui liste chaque modification (avant / après).
- Le nom du fichier ne change pas (`Lexique_10000.xlsx`) ; l'accueil affiche « 7 600 mots ».

## Fichiers
- `app/src/main/java/com/linguavibe/app/ui/ManualTheme.kt` (nouveau : style, en-tête, écran des dialogues en scènes)
- `app/src/main/assets/scenes/*.webp` (nouveau) et `ui/Scenes.kt` (secours lineart)
- `ui/LessonScreen.kt`, `ui/LessonDecor.kt`, `ui/Screens.kt`, `ui/LexiqueScreen.kt`, `data/Models.kt`, `export/PdfExporter.kt`
- `app/src/main/assets/courses/es_model2.json`, `es_model3.json`, `assets/lexique/Lexique_10000.xlsx`
- `tools/flat_scenes.py`, `tools/scenes.py`, `tools/content_m2.py`, `tools/content_m3.py`, `tools/enrich_m2_m3.py`, `firebase/FORMAT.md`

## Limites
Compilation Android et rendu sur téléphone non vérifiés ici (pas de SDK Android ni de dépendances en ligne). Les sources modifiées ont passé une vérification de syntaxe avec le compilateur Kotlin 2.0. Compilez dans Android Studio avant installation.
