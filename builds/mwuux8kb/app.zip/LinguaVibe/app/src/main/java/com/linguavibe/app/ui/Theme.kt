package com.linguavibe.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import com.linguavibe.app.R
import com.linguavibe.app.speech.Speaker

// ------------------------------------------------------------------ Typographie
// Poppins (texte), Inter Display Black (grands titres façon affiche), Lora italique (mots d'accent).
// Polices libres (licence SIL Open Font License), intégrées dans res/font.

val Poppins = FontFamily(
    Font(R.font.poppins_regular, FontWeight.Normal),
    Font(R.font.poppins_regular, FontWeight.Light),
    Font(R.font.poppins_medium, FontWeight.Medium),
    Font(R.font.poppins_bold, FontWeight.SemiBold),
    Font(R.font.poppins_bold, FontWeight.Bold),
    Font(R.font.poppins_bold, FontWeight.ExtraBold)
)

val Display = FontFamily(
    Font(R.font.display_extrabold, FontWeight.ExtraBold),
    Font(R.font.display_extrabold, FontWeight.Bold),
    Font(R.font.display_black, FontWeight.Black)
)

val Accent = FontFamily(
    Font(R.font.accent_italic, FontWeight.Normal, FontStyle.Italic),
    Font(R.font.accent_italic, FontWeight.SemiBold, FontStyle.Italic),
    Font(R.font.accent_italic, FontWeight.Bold, FontStyle.Italic)
)

// ------------------------------------------------------------------ Couleurs
// Inspirées des affiches de référence et du logo DL VIBE STUDIO : bleu nuit, or, rouge,
// vert forêt ; fond papier chaud. Les anciens noms restent pour tout le code existant.

val Night = Color(0xFF0B1230)
val Navy = Color(0xFF14215B)
val Gold = Color(0xFFF5B800)
val GoldSoft = Color(0xFFFFE27A)
val Ruby = Color(0xFFE53935)
val Forest = Color(0xFF0B5D3B)
val Paper = Color(0xFFF7F4EC)
val Sand = Color(0xFFEDE6D3)

val Indigo = Navy
val IndigoDark = Night
val Coral = Ruby
val Cream = Paper
val Ink = Color(0xFF101A3A)
val InkSoft = Color(0xFF5D6380)
val Good = Color(0xFF1E8E5A)
val Warn = Color(0xFFF29A00)
val Bad = Color(0xFFE53935)

private val scheme = lightColorScheme(
    primary = Navy,
    onPrimary = Color.White,
    secondary = Gold,
    onSecondary = Night,
    tertiary = Ruby,
    background = Paper,
    onBackground = Ink,
    surface = Color.White,
    onSurface = Ink,
    surfaceVariant = Sand,
    onSurfaceVariant = InkSoft,
    outline = Color(0xFFD9D1BC),
    error = Bad
)

private val base = TextStyle(fontFamily = Poppins)

private val typography = Typography(
    displayLarge = base.copy(fontFamily = Display, fontWeight = FontWeight.Black),
    displayMedium = base.copy(fontFamily = Display, fontWeight = FontWeight.Black),
    displaySmall = base.copy(fontFamily = Display, fontWeight = FontWeight.ExtraBold),
    headlineLarge = base.copy(fontFamily = Display, fontWeight = FontWeight.ExtraBold),
    headlineMedium = base.copy(fontFamily = Display, fontWeight = FontWeight.ExtraBold),
    headlineSmall = base.copy(fontWeight = FontWeight.Bold),
    titleLarge = base.copy(fontWeight = FontWeight.Bold),
    titleMedium = base.copy(fontWeight = FontWeight.SemiBold),
    titleSmall = base.copy(fontWeight = FontWeight.Medium),
    bodyLarge = base,
    bodyMedium = base,
    bodySmall = base,
    labelLarge = base.copy(fontWeight = FontWeight.SemiBold),
    labelMedium = base.copy(fontWeight = FontWeight.Medium),
    labelSmall = base.copy(fontWeight = FontWeight.Medium)
)

/** Couleurs d'un niveau, du vert (débutant) au rouge profond (maîtrise). */
fun levelColor(level: String): Color = when (level) {
    "A1" -> Color(0xFF1E8E5A)
    "A2" -> Color(0xFF0E7C9A)
    "B1" -> Color(0xFF2B3FA0)
    "B2" -> Color(0xFF7B2FBF)
    "C1" -> Color(0xFFE65100)
    "C2" -> Color(0xFFB3121B)
    else -> Navy
}

/** Ambiance « affiche » propre à chaque langue : deux teintes de fond et une couleur d'accent. */
data class PosterTheme(val start: Color, val end: Color, val accent: Color, val onAccent: Color = Night)

fun posterTheme(code: String): PosterTheme = when (code) {
    "es" -> PosterTheme(Color(0xFFB71C1C), Color(0xFFEF6C00), Color(0xFFFFD54F))
    "en" -> PosterTheme(Color(0xFF0E1A4F), Color(0xFF1E3A8A), Gold)
    "pt" -> PosterTheme(Color(0xFF0B5D3B), Color(0xFF15885A), Color(0xFFE8F25C))
    "ru" -> PosterTheme(Color(0xFF17303F), Color(0xFF2E5A73), Color(0xFFA8DCF5))
    "zh" -> PosterTheme(Color(0xFF8E0E14), Color(0xFFD7263D), Color(0xFFF2C14E))
    "ar" -> PosterTheme(Color(0xFF0B5446), Color(0xFF13896B), Color(0xFFF4D58D))
    else -> PosterTheme(Night, Navy, Gold)
}

fun scoreColor(score: Int): Color = when {
    score >= 80 -> Good
    score >= 50 -> Warn
    else -> Bad
}

val LocalSpeaker = staticCompositionLocalOf<Speaker> { error("Speaker manquant") }
val LocalOpenModels = staticCompositionLocalOf<() -> Unit> { {} }

/** Ouvre le conjugueur (avec un verbe déjà saisi, ou vide). */
val LocalOpenConjugator = staticCompositionLocalOf<(String) -> Unit> { {} }

@Composable
fun LinguaTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, typography = typography, content = content)
}
