package com.linguavibe.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linguavibe.app.data.LanguageInfo
import java.util.Locale

// =====================================================================================
//  Cours Model 2 et Model 3 : mise en page stylée du texte du manuel.
//  Le texte brut (sourceContent) est découpé en blocs typés (chapitres, tableaux,
//  dialogues en bulles, encadrés, lectures avec traduction, exercices, auto-évaluation…)
//  puis chaque bloc a son propre rendu. Les quiz et corrigés restent dans l'onglet Quiz.
// =====================================================================================

internal sealed interface MBlock {
    data class Chapter(val label: String, val title: String) : MBlock
    data class SubHeading(val letter: String, val title: String) : MBlock
    data class Minor(val title: String) : MBlock
    data class Para(val text: String) : MBlock
    data class Bullets(val items: List<String>) : MBlock
    data class Callout(val label: String, val text: String) : MBlock
    data class Table(val header: List<String>?, val rows: List<List<String>>) : MBlock
    data class Pairs(val items: List<Pair<String, String>>) : MBlock
    data class Dialogue(val turns: List<Pair<String, String>>, val translation: String?) : MBlock
    data class Reading(val title: String, val spanish: String, val french: String?) : MBlock
    data class Questions(val intro: String?, val items: List<String>) : MBlock
    data class Exercise(val label: String, val title: String?, val text: String) : MBlock
    data class Days(val items: List<Pair<String, String>>) : MBlock
    data class SelfCheck(val items: List<String>) : MBlock
}

/** Clé de rapprochement entre un exercice du manuel et son atelier (« Exercice écrit 2 » → « exercice 2 »). */
internal fun practiceKey(label: String): String =
    label.lowercase(Locale.ROOT).replace("oral", "").replace("écrit", "").replace(Regex("\\s+"), " ").trim()

/** Étiquettes des exercices présents dans le texte du manuel. */
internal fun manualExerciseKeys(raw: String): Set<String> =
    ManualParser.parse(raw).filterIsInstance<MBlock.Exercise>().map { practiceKey(it.label) }.toSet()

// ------------------------------------------------------------------------- Parseur

internal object ManualParser {
    private val GAP = Regex("""\S {3,}\S""")
    private val SPLIT_GAP = Regex("""\s{3,}""")
    private val PAGE = Regex("""(?i)^PAGE\s+\d+.*""")
    private val PAGE_ONLY = Regex("""(?i)^Page\s+\d+$""")
    private val BRAND = Regex("""(?i)^LinguaVibe\s*·.*""")
    private val RUNNING = Regex("""^LEÇON \d+ · (VOCABULAIRE ET LECTURE|ENTRAÎNEMENT)$""")
    private val START = Regex("""(?i)^([A-C][12]\s*[·.]\s*)?(LEÇON|UNITÉ)\s+\d+.*""")
    private val KICKER = Regex("""(?i)^([A-C][12]\s*[·.]\s*)?LEÇON\s+\d+\s*$""")
    private val UNIT = Regex("""(?i)^UNITÉ\s+\d+.*""")
    private val QUIZ = Regex("""^(\d+\.\s+)?(QUIZ|CORRIGÉ|CORRECTION)""")
    private val RESUME_WORDS = Regex("""(?i)travail|auto-|production|activité|atelier""")
    private val H1 = Regex("""^([1-9])\.\s+([A-ZÀ-Ü][^?.:]{2,52})$""")
    private val H2 = Regex("""^(\d+\.\d+)\s+(\S.{1,80})$""")
    private val H3 = Regex("""^([A-H])\.\s+([A-ZÀ-Ü][^.?!:]{3,60})$""")
    private val CAPS = Regex("""^(?=.*[A-ZÀ-Ü]{3})[A-ZÀ-Ü0-9][A-ZÀ-Ü0-9 ·’'—:()\-]{7,}$""")
    private val MINOR = Regex(
        """^(Mini-dialogue à lire|Petit paragraphe modèle|Texte de lecture|Expressions à reconnaître|""" +
            """Traduction française|Questions de compréhension|Auto-évaluation|Repères de prononciation|""" +
            """Routine hebdomadaire suggérée)\s*$"""
    )
    private val CALL = Regex(
        """^(Objectif|À retenir|Conseil de méthode|Conseil final|Conseil|Attention|Règle importante|""" +
            """Règle \d+|Méthode|Traduction|Questions de compréhension)\s*:?\s+(.*)$"""
    )
    private val DLG = Regex("""^([A-D]|[A-ZÁÉÍÓÚ][a-záéíóúñ]{2,11})\s:\s+(\S.*)$""")
    private val NOT_SPEAKERS = setOf(
        "Objectif", "Traduction", "Conseil", "Attention", "Règle", "Méthode", "Exemple", "Exemples",
        "Conjugaison", "Jour", "Questions", "Date", "Prix", "Rappel", "Note", "Astuce"
    )
    private val EXERCISE = Regex("""(Exercice(?:\s+(?:oral|écrit)s?)?\s*\d+|Activité\s*\d+)\s*:\s*""")
    private val EXERCISE_TITLE = Regex("""^([a-zàâçéèêëîïôûùüœ][^.:?!¿¡]*?)\s+(?=[A-ZÀ-Ü¿¡])""")
    private val READ_TITLES = setOf("Petit paragraphe modèle", "Texte de lecture")
    private val WHITESPACE = Regex("""\s+""")

    private fun String.squash(): String = replace(WHITESPACE, " ").trim()

    private fun dialogueTurn(line: String): Pair<String, String>? {
        val m = DLG.matchEntire(line) ?: return null
        val who = m.groupValues[1]
        if (who in NOT_SPEAKERS) return null
        return who to m.groupValues[2]
    }

    private fun isPlain(l: String): Boolean =
        !(QUIZ.containsMatchIn(l.uppercase(Locale.ROOT)) || H1.matches(l) || H2.matches(l) || H3.matches(l) ||
            CAPS.matches(l) || MINOR.matches(l) || GAP.containsMatchIn(l) || dialogueTurn(l) != null ||
            l.startsWith("•") || CALL.matches(l))

    private fun clean(raw: String): List<String> {
        val kept = raw.lineSequence().map { it.trim() }.filter { l ->
            l.isNotEmpty() && !PAGE.matches(l) && !PAGE_ONLY.matches(l) && !l.startsWith("━") &&
                !RUNNING.matches(l) && !BRAND.matches(l)
        }.toList()
        val first = kept.indexOfFirst { START.matches(it) }
        val start = if (first < 0) 0 else first
        val out = mutableListOf<String>()
        var skipTitle = false
        for (l in kept.drop(start)) {
            if (KICKER.matches(l)) { skipTitle = true; continue }
            if (skipTitle) { skipTitle = false; continue }
            if (UNIT.matches(l)) continue
            out += l
        }
        return out
    }

    private fun prettyCaps(s: String): String =
        s.lowercase(Locale.ROOT).replaceFirstChar { it.uppercase(Locale.ROOT) }

    private fun buildTable(rows: List<List<String>>): MBlock.Table {
        val width = rows.maxOf { it.size }
        val first = rows.first()
        val hasHeader = rows.size > 1 && first.all { c ->
            c.any { it.isLetter() } && !c.all { it.isDigit() || it.isWhitespace() }
        }
        val body = (if (hasHeader) rows.drop(1) else rows)
            .filter { !hasHeader || it != first }
            .map { r -> r + List(width - r.size) { "" } }
        val header = if (hasHeader) first + List(width - first.size) { "" } else null
        return MBlock.Table(header, body)
    }

    fun parse(raw: String): List<MBlock> {
        val lines = clean(raw)
        val blocks = mutableListOf<MBlock>()
        val para = mutableListOf<String>()
        var chapterTitle = ""
        var chapterCount = 0
        var skipping = false

        fun flush() {
            if (para.isEmpty()) return
            val ls = para.toList()
            para.clear()
            val joined = ls.joinToString(" ").squash()
            val low = chapterTitle.lowercase(Locale.ROOT)
            if (low.contains("exemples") && ls.size >= 2 && ls.size % 2 == 0 &&
                ls.all { it.length < 100 } && ls.none { it.contains(" = ") }
            ) {
                blocks += MBlock.Pairs(ls.chunked(2).map { it[0] to it[1] })
                return
            }
            if (low.contains("lecture") && ls.size >= 2 && ls[0].length <= 60 && ls[0].last() !in ".?!:;»)") {
                blocks += MBlock.Reading(ls[0], ls.drop(1).joinToString(" ").squash(), null)
                return
            }
            val ex = EXERCISE.findAll(joined).toList()
            if (ex.isNotEmpty()) {
                val head = joined.substring(0, ex[0].range.first).trim()
                if (head.isNotEmpty()) blocks += MBlock.Para(head)
                ex.forEachIndexed { idx, m ->
                    val end = if (idx + 1 < ex.size) ex[idx + 1].range.first else joined.length
                    val body = joined.substring(m.range.last + 1, end).trim()
                    val t = EXERCISE_TITLE.find(body)
                    if (t != null && t.groupValues[1].length <= 60) {
                        val title = t.groupValues[1].replaceFirstChar { it.uppercase(Locale.ROOT) }
                        blocks += MBlock.Exercise(m.groupValues[1], title, body.substring(t.range.last + 1).trim())
                    } else {
                        blocks += MBlock.Exercise(m.groupValues[1], null, body)
                    }
                }
                return
            }
            blocks += MBlock.Para(joined)
        }

        var i = 0
        while (i < lines.size) {
            val l = lines[i]
            val upper = l.uppercase(Locale.ROOT)

            if (QUIZ.containsMatchIn(upper)) {
                flush(); skipping = true; i++; continue
            }
            if (skipping) {
                val resume = (H1.matches(l) && RESUME_WORDS.containsMatchIn(l)) || CAPS.matches(l) ||
                    H2.matches(l) || l == "Auto-évaluation"
                if (resume) skipping = false else { i++; continue }
            }

            val h1 = H1.matchEntire(l)
            if (h1 != null) {
                flush()
                chapterCount++
                chapterTitle = h1.groupValues[2]
                blocks += MBlock.Chapter(chapterCount.toString(), chapterTitle)
                i++; continue
            }
            val h2 = H2.matchEntire(l)
            if (h2 != null && !GAP.containsMatchIn(l) && l.length < 90) {
                flush()
                chapterTitle = h2.groupValues[2]
                blocks += MBlock.Chapter(h2.groupValues[1], chapterTitle)
                i++; continue
            }
            if (CAPS.matches(l)) {
                flush()
                chapterTitle = prettyCaps(l)
                blocks += MBlock.Chapter("", chapterTitle)
                i++; continue
            }
            val h3 = H3.matchEntire(l)
            if (h3 != null) {
                flush()
                blocks += MBlock.SubHeading(h3.groupValues[1], h3.groupValues[2])
                i++; continue
            }
            if (MINOR.matches(l)) {
                flush()
                blocks += MBlock.Minor(l.trim())
                i++; continue
            }
            if (GAP.containsMatchIn(l)) {
                flush()
                val rows = mutableListOf<List<String>>()
                while (i < lines.size && GAP.containsMatchIn(lines[i])) {
                    rows += lines[i].split(SPLIT_GAP).map { it.trim() }
                    i++
                }
                blocks += buildTable(rows)
                continue
            }
            if (dialogueTurn(l) != null) {
                flush()
                val turns = mutableListOf<Pair<String, String>>()
                while (i < lines.size) {
                    val turn = dialogueTurn(lines[i]) ?: break
                    turns += turn
                    i++
                }
                if (turns.size >= 2) blocks += MBlock.Dialogue(turns, null)
                else para += "${turns[0].first} : ${turns[0].second}"
                continue
            }
            if (l.startsWith("•")) {
                flush()
                val items = mutableListOf<String>()
                while (i < lines.size) {
                    val cur = lines[i]
                    if (cur.startsWith("•")) {
                        items += cur.removePrefix("•").trim()
                    } else if (items.isNotEmpty() && isPlain(cur) && cur.first().isLowerCase()) {
                        // Puce coupée sur deux lignes dans le texte source : on la recolle.
                        items[items.size - 1] = items.last() + " " + cur
                    } else break
                    i++
                }
                blocks += MBlock.Bullets(items)
                continue
            }
            val call = CALL.matchEntire(l)
            if (call != null) {
                flush()
                val label = call.groupValues[1]
                val buf = mutableListOf(call.groupValues[2])
                i++
                while (i < lines.size && isPlain(lines[i])) {
                    buf += lines[i]
                    i++
                }
                val text = buf.joinToString(" ").squash()
                when {
                    // Phrase d'introduction identique dans toutes les leçons : sans intérêt pour l'élève.
                    label.startsWith("À retenir") && text.startsWith("Lis les règles") -> Unit
                    label.startsWith("Questions") -> blocks += questions(text)
                    else -> {
                        val shown = if (label.startsWith("Conseil") || label.startsWith("Règle") || label.startsWith("Méthode"))
                            text.replaceFirstChar { it.uppercase(Locale.ROOT) } else text
                        blocks += MBlock.Callout(label, shown)
                    }
                }
                continue
            }
            para += l
            i++
        }
        flush()
        return refine(blocks)
    }

    private fun questions(text: String): MBlock.Questions {
        val first = Regex("""\d\)""").find(text)
        if (first != null) {
            val intro = text.substring(0, first.range.first).trim().ifEmpty { null }
            val items = Regex("""\d\)\s*""").split(text.substring(first.range.first))
                .map { it.trim() }.filter { it.isNotEmpty() }
            return MBlock.Questions(intro, items)
        }
        val items = text.split(Regex("""(?<=\?)\s+""")).map { it.trim() }.filter { it.isNotEmpty() }
        return MBlock.Questions(null, items)
    }

    private fun days(text: String): MBlock {
        val dayLine = Regex("""^Jour\s*(\d+)\s*:\s*(.*)$""")
        val items = Regex("""(?=Jour\s*\d+\s*:)""").split(text).map { it.trim() }.filter { it.isNotEmpty() }
            .mapNotNull { piece -> dayLine.matchEntire(piece)?.let { "J" + it.groupValues[1] to it.groupValues[2].trim() } }
        return if (items.size >= 2) MBlock.Days(items) else MBlock.Para(text)
    }

    private fun selfCheck(text: String): MBlock {
        val items = if (text.contains("□")) {
            Regex("""(.+?)\s*:\s*□\s*Oui\s*□\s*Pas encore\s*""").findAll(text)
                .map { it.groupValues[1].trim() }.toList()
        } else {
            text.split(Regex("""(?<=\.)\s+(?=Je )""")).map { it.trim() }.filter { it.isNotEmpty() }
        }
        return if (items.isEmpty()) MBlock.Para(text) else MBlock.SelfCheck(items)
    }

    /** Regroupe les blocs voisins : texte + traduction, dialogue + traduction, questions, auto-évaluation. */
    private fun refine(src: List<MBlock>): List<MBlock> {
        val out = mutableListOf<MBlock>()
        var i = 0
        while (i < src.size) {
            val b = src[i]
            val next = src.getOrNull(i + 1)
            val after = src.getOrNull(i + 2)
            when {
                b is MBlock.Reading && b.french == null && next is MBlock.Minor &&
                    next.title == "Traduction française" && after is MBlock.Para -> {
                    out += b.copy(french = after.text)
                    i += 3
                }
                b is MBlock.Minor && b.title in READ_TITLES && next is MBlock.Para -> {
                    val tr = after as? MBlock.Callout
                    val fr = if (tr != null && tr.label.startsWith("Traduction")) tr.text else null
                    out += MBlock.Reading(b.title, next.text, fr)
                    i += if (fr != null) 3 else 2
                }
                b is MBlock.Minor && b.title == "Questions de compréhension" && next is MBlock.Para -> {
                    out += questions(next.text)
                    i += 2
                }
                b is MBlock.Minor && b.title == "Routine hebdomadaire suggérée" && next is MBlock.Para -> {
                    out += days(next.text)
                    i += 2
                }
                b is MBlock.Minor && b.title == "Auto-évaluation" && next is MBlock.Para -> {
                    out += selfCheck(next.text)
                    i += 2
                }
                b is MBlock.Dialogue && b.translation == null && next is MBlock.Callout &&
                    next.label.startsWith("Traduction") -> {
                    out += b.copy(translation = next.text)
                    i += 2
                }
                else -> {
                    out += b
                    i++
                }
            }
        }
        return out
    }
}

// ------------------------------------------------------------------------- Rendu

private val HIGHLIGHT = Regex("""«[^»]{1,120}»|¿[^?]{1,140}\?|¡[^!]{1,140}!""")
private val SPEAK_HEADER = Regex("""(?i)espagnol|español|exemple""")

/** Met en valeur les citations « … » et les phrases espagnoles ¿…? ¡…! dans un texte. */
private fun rich(text: String, color: Color): AnnotatedString = buildAnnotatedString {
    var last = 0
    for (m in HIGHLIGHT.findAll(text)) {
        append(text.substring(last, m.range.first))
        withStyle(SpanStyle(color = color, fontWeight = FontWeight.SemiBold)) { append(m.value) }
        last = m.range.last + 1
    }
    append(text.substring(last))
}

private fun chapterEmoji(title: String): String {
    val t = title.lowercase(Locale.ROOT)
    return when {
        "mémoriser" in t -> "🧠"
        "règle" in t || "comprendre" in t || "structure" in t -> "💡"
        "exemple" in t -> "💬"
        "vocabulaire" in t || "expressions" in t -> "🗂️"
        "lecture" in t || "texte" in t -> "📖"
        "travail" in t || "atelier" in t || "production" in t || "exercice" in t -> "✍️"
        "grammaire" in t || "fiche" in t -> "📐"
        "salut" in t || "revoir" in t || "dialogue" in t -> "👋"
        "nombre" in t || "chiffre" in t || "dizaine" in t || "zéro" in t || "onze" in t -> "🔢"
        "famille" in t -> "👪"
        else -> "✦"
    }
}

@Composable
internal fun ManualCourse(
    raw: String, color: Color, lang: LanguageInfo,
    practice: List<com.linguavibe.app.data.PracticeSet> = emptyList()
) {
    val blocks = remember(raw) { ManualParser.parse(raw) }
    val speaker = LocalSpeaker.current
    val say: (String) -> Unit = { text -> speaker.speak(text, lang.locale) }
    val chapters = remember(blocks) { blocks.filterIsInstance<MBlock.Chapter>() }
    val firstChapter = remember(blocks) { blocks.indexOfFirst { it is MBlock.Chapter } }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text("LE COURS", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = color, letterSpacing = 1.4.sp)
            Text("Les explications", style = PosterTitle, fontSize = 26.sp, color = Ink)
            Text(
                "Touchez un mot, une phrase ou une bulle pour l'écouter.",
                style = AccentText, fontSize = 13.sp, color = InkSoft
            )
        }
        if (chapters.size >= 3) Programme(chapters, color)
        blocks.forEachIndexed { index, block ->
            when (block) {
                is MBlock.Chapter -> ChapterHeader(block, color, index == firstChapter)
                is MBlock.SubHeading -> SubHeadingRow(block, color)
                is MBlock.Minor -> MinorHeading(block.title)
                is MBlock.Para -> Text(rich(block.text, color), fontSize = 15.sp, lineHeight = 25.sp, color = Ink)
                is MBlock.Bullets -> BulletsCard(block.items, color)
                is MBlock.Callout -> CalloutCard(block, color)
                is MBlock.Table -> TableCard(block, color, say)
                is MBlock.Pairs -> PairsCard(block, color, say)
                is MBlock.Dialogue -> DialogueBubbles(block, color, say)
                is MBlock.Reading -> ReadingCard(block, color, say)
                is MBlock.Questions -> QuestionsCard(block, color, say)
                is MBlock.Exercise -> {
                    ExerciseCard(block)
                    practice.firstOrNull { practiceKey(it.ref) == practiceKey(block.label) }?.let {
                        PracticeCard(it, lang, color, attached = true)
                    }
                }
                is MBlock.Days -> DaysCard(block, color)
                is MBlock.SelfCheck -> SelfCheckCard(block, color)
            }
        }
        if (blocks.isEmpty()) {
            CardBox { Text("Le contenu détaillé de cette leçon sera bientôt disponible.", fontSize = 14.sp, color = InkSoft) }
        }
    }
}

@Composable
private fun SpeakDot(color: Color, size: Dp = 34.dp, onClick: () -> Unit) {
    Box(
        Modifier.size(size).clip(CircleShape).background(color).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { LineIcon(Art.icVoice, Color.White, size * 0.58f, accent = GoldSoft) }
}

@Composable
private fun Programme(chapters: List<MBlock.Chapter>, color: Color) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Sand.copy(alpha = 0.55f)).padding(vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            "AU PROGRAMME", Modifier.padding(horizontal = 14.dp),
            fontSize = 10.5.sp, fontWeight = FontWeight.ExtraBold, color = InkSoft, letterSpacing = 1.3.sp
        )
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            chapters.forEach { c ->
                Box(Modifier.clip(CircleShape).background(Color.White).border(1.dp, color.copy(alpha = 0.25f), CircleShape).padding(horizontal = 12.dp, vertical = 7.dp)) {
                    Text(
                        if (c.label.isBlank()) c.title else "${c.label} · ${c.title}",
                        fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = color
                    )
                }
            }
        }
    }
}

@Composable
private fun ChapterHeader(c: MBlock.Chapter, color: Color, first: Boolean) {
    val kicker = when {
        c.label.contains('.') -> "NOTION ${c.label}"
        c.label.isNotBlank() -> "ÉTAPE ${c.label}"
        else -> "À PRATIQUER"
    }
    Column(Modifier.fillMaxWidth().padding(top = if (first) 0.dp else 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(
                Modifier.size(46.dp).clip(RoundedCornerShape(16.dp))
                    .background(Brush.linearGradient(listOf(color, color.copy(alpha = 0.72f)))),
                contentAlignment = Alignment.Center
            ) {
                Text(chapterEmoji(c.title), fontSize = 22.sp)
            }
            Column(Modifier.weight(1f)) {
                Text(kicker, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, color = color, letterSpacing = 1.3.sp)
                Text(c.title, style = PosterTitle, fontSize = 19.sp, lineHeight = 23.sp, color = Ink)
            }
        }
        Box(
            Modifier.fillMaxWidth().height(3.dp).clip(CircleShape)
                .background(Brush.horizontalGradient(listOf(color, Gold, Color.Transparent)))
        )
    }
}

@Composable
private fun SubHeadingRow(h: MBlock.SubHeading, color: Color) {
    Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.size(28.dp).clip(CircleShape).background(color), contentAlignment = Alignment.Center) {
            Text(h.letter, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold)
        }
        Text(h.title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Ink, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun MinorHeading(title: String) {
    Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
        Box(Modifier.width(4.dp).height(20.dp).clip(CircleShape).background(Gold))
        Text(title, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Ink)
    }
}

@Composable
private fun BulletsCard(items: List<String>, color: Color) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(color.copy(alpha = 0.07f)).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        items.forEach { item ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.padding(top = 8.dp).size(7.dp).clip(CircleShape).background(color))
                Text(rich(item, color), Modifier.weight(1f), fontSize = 14.5.sp, lineHeight = 22.sp, color = Ink)
            }
        }
    }
}

private data class CalloutLook(val emoji: String, val title: String, val tint: Color)

private fun calloutLook(label: String, base: Color): CalloutLook = when {
    label.startsWith("Objectif") -> CalloutLook("🎯", "OBJECTIF", base)
    label.startsWith("À retenir") -> CalloutLook("📌", "À RETENIR", Color(0xFFC79100))
    label.startsWith("Conseil") || label.startsWith("Méthode") ->
        CalloutLook("💡", label.uppercase(Locale.ROOT), Forest)
    label.startsWith("Attention") -> CalloutLook("⚠️", "ATTENTION", Ruby)
    label.startsWith("Règle") -> CalloutLook("📏", label.uppercase(Locale.ROOT), Navy)
    label.startsWith("Traduction") -> CalloutLook("🇫🇷", "TRADUCTION", InkSoft)
    else -> CalloutLook("✦", label.uppercase(Locale.ROOT), base)
}

@Composable
private fun CalloutCard(c: MBlock.Callout, base: Color) {
    val look = calloutLook(c.label, base)
    Row(
        Modifier.fillMaxWidth().height(IntrinsicSize.Min).clip(RoundedCornerShape(16.dp))
            .background(look.tint.copy(alpha = 0.10f))
    ) {
        Box(Modifier.width(5.dp).fillMaxHeight().background(look.tint))
        Column(Modifier.weight(1f).padding(horizontal = 14.dp, vertical = 11.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                "${look.emoji}  ${look.title}",
                fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = look.tint, letterSpacing = 1.1.sp
            )
            Text(rich(c.text, look.tint), fontSize = 14.5.sp, lineHeight = 22.sp, color = Ink)
        }
    }
}

@Composable
private fun TableCard(t: MBlock.Table, color: Color, say: (String) -> Unit) {
    val speakCols = remember(t) {
        t.header?.mapIndexedNotNull { i, h -> if (SPEAK_HEADER.containsMatchIn(h)) i else null }?.toSet() ?: emptySet()
    }
    fun canSpeak(col: Int, cell: String): Boolean =
        if (cell.isBlank()) false
        else if (t.header != null) col in speakCols
        else cell.all { it.isLetter() || it == ' ' }

    val shape = RoundedCornerShape(18.dp)
    Column(Modifier.fillMaxWidth().clip(shape).background(Color.White).border(1.dp, color.copy(alpha = 0.22f), shape)) {
        t.header?.let { header ->
            Row(
                Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(color, color.copy(alpha = 0.8f))))
                    .padding(horizontal = 12.dp, vertical = 9.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                header.forEach { cell ->
                    Text(
                        cell.uppercase(Locale.ROOT), Modifier.weight(1f),
                        color = Color.White, fontSize = 10.5.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.6.sp
                    )
                }
            }
        }
        t.rows.forEachIndexed { r, row ->
            Row(
                Modifier.fillMaxWidth()
                    .background(if (r % 2 == 1) color.copy(alpha = 0.06f) else Color.White)
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                row.forEachIndexed { c, cell ->
                    val speak = canSpeak(c, cell)
                    Row(
                        Modifier.weight(1f).then(if (speak) Modifier.clickable { say(cell) } else Modifier),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            cell, Modifier.weight(1f, fill = false),
                            fontSize = 14.sp, lineHeight = 19.sp,
                            fontWeight = if (speak) FontWeight.SemiBold else FontWeight.Normal,
                            color = if (speak || t.header == null) Ink else InkSoft
                        )
                        if (speak) LineIcon(Art.icVoice, color, 15.dp)
                    }
                }
            }
        }
    }
}

@Composable
private fun PairsCard(p: MBlock.Pairs, color: Color, say: (String) -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Column(Modifier.fillMaxWidth().clip(shape).background(Color.White).border(1.dp, color.copy(alpha = 0.22f), shape)) {
        p.items.forEachIndexed { idx, (es, fr) ->
            if (idx > 0) Box(Modifier.fillMaxWidth().height(1.dp).background(Sand))
            Row(
                Modifier.fillMaxWidth().clickable { say(es) }.padding(horizontal = 14.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(es, fontSize = 15.sp, lineHeight = 21.sp, fontWeight = FontWeight.SemiBold, color = Ink)
                    Text(fr, fontSize = 13.sp, lineHeight = 18.sp, fontStyle = FontStyle.Italic, color = InkSoft)
                }
                SpeakDot(color, 34.dp) { say(es) }
            }
        }
    }
}

@Composable
private fun TranslationReveal(text: String, color: Color) {
    var open by rememberSaveable(text) { mutableStateOf(false) }
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Sand.copy(alpha = 0.6f))
            .clickable { open = !open }.padding(horizontal = 14.dp, vertical = 11.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            if (open) "▾  Traduction française" else "▸  Voir la traduction",
            fontSize = 12.5.sp, fontWeight = FontWeight.Bold, color = color
        )
        if (open) Text(text, fontSize = 14.sp, lineHeight = 22.sp, fontStyle = FontStyle.Italic, color = InkSoft)
    }
}

@Composable
private fun DialogueBubbles(d: MBlock.Dialogue, color: Color, say: (String) -> Unit) {
    val order = remember(d) { d.turns.map { it.first }.distinct() }
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        d.turns.forEach { (who, text) ->
            val right = order.indexOf(who) % 2 == 1
            val shape = RoundedCornerShape(
                topStart = 18.dp, topEnd = 18.dp,
                bottomStart = if (right) 18.dp else 4.dp, bottomEnd = if (right) 4.dp else 18.dp
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = if (right) Arrangement.End else Arrangement.Start) {
                Column(
                    Modifier.widthIn(max = 310.dp).clip(shape)
                        .background(if (right) color.copy(alpha = 0.14f) else Color.White)
                        .border(1.dp, color.copy(alpha = 0.25f), shape)
                        .clickable { say(text) }
                        .padding(horizontal = 13.dp, vertical = 9.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Text(who.uppercase(Locale.ROOT), fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, color = color, letterSpacing = 1.sp)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(text, Modifier.weight(1f, fill = false), fontSize = 15.sp, lineHeight = 22.sp, color = Ink)
                        LineIcon(Art.icVoice, color, 16.dp)
                    }
                }
            }
        }
        d.translation?.let { TranslationReveal(it, color) }
    }
}

@Composable
private fun ReadingCard(r: MBlock.Reading, color: Color, say: (String) -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Column(Modifier.fillMaxWidth().clip(shape).background(Color.White).border(1.dp, color.copy(alpha = 0.22f), shape)) {
        Row(
            Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(color, color.copy(alpha = 0.78f)))).padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("📖  LECTURE", fontSize = 10.5.sp, fontWeight = FontWeight.ExtraBold, color = GoldSoft, letterSpacing = 1.3.sp)
                Text(r.title, style = PosterTitle, fontSize = 18.sp, lineHeight = 22.sp, color = Color.White)
            }
            Box(
                Modifier.size(42.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.22f)).clickable { say(r.spanish) },
                contentAlignment = Alignment.Center
            ) { LineIcon(Art.icVoice, Color.White, 25.dp, accent = GoldSoft) }
        }
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(r.spanish, style = AccentText, fontWeight = FontWeight.Normal, fontSize = 16.sp, lineHeight = 27.sp, color = Ink)
            r.french?.let { TranslationReveal(it, color) }
        }
    }
}

@Composable
private fun QuestionsCard(q: MBlock.Questions, color: Color, say: (String) -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        Modifier.fillMaxWidth().clip(shape).background(Gold.copy(alpha = 0.10f)).border(1.dp, Gold.copy(alpha = 0.45f), shape).padding(15.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("❓  POUR VÉRIFIER SA COMPRÉHENSION", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF8A6200), letterSpacing = 1.1.sp)
        q.intro?.let { Text(it, fontSize = 13.sp, fontStyle = FontStyle.Italic, color = InkSoft) }
        q.items.forEachIndexed { idx, item ->
            Row(
                Modifier.fillMaxWidth().then(if (item.startsWith("¿")) Modifier.clickable { say(item) } else Modifier),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.Top
            ) {
                Box(Modifier.size(24.dp).clip(CircleShape).background(color), contentAlignment = Alignment.Center) {
                    Text("${idx + 1}", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
                }
                Text(item, Modifier.weight(1f).padding(top = 1.dp), fontSize = 14.5.sp, lineHeight = 21.sp, color = Ink)
            }
        }
    }
}

@Composable
private fun ExerciseCard(e: MBlock.Exercise) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        Modifier.fillMaxWidth().clip(shape).background(Color.White).border(1.dp, Gold.copy(alpha = 0.6f), shape).padding(15.dp),
        verticalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        Box(Modifier.clip(CircleShape).background(Gold).padding(horizontal = 11.dp, vertical = 4.dp)) {
            Text("✍️  " + e.label.uppercase(Locale.ROOT), fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = Night, letterSpacing = 0.8.sp)
        }
        e.title?.let { Text(it, fontSize = 16.sp, lineHeight = 21.sp, fontWeight = FontWeight.Bold, color = Ink) }
        Text(e.text, fontSize = 14.5.sp, lineHeight = 22.sp, color = Ink)
    }
}

@Composable
private fun DaysCard(d: MBlock.Days, color: Color) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        Modifier.fillMaxWidth().clip(shape).background(Color.White).border(1.dp, color.copy(alpha = 0.22f), shape).padding(15.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("🗓️  UNE SEMAINE TYPE", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = color, letterSpacing = 1.2.sp)
        d.items.forEach { (day, what) ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(34.dp).clip(RoundedCornerShape(11.dp)).background(color.copy(alpha = 0.12f)), contentAlignment = Alignment.Center) {
                    Text(day, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = color)
                }
                Text(what, Modifier.weight(1f), fontSize = 14.5.sp, lineHeight = 21.sp, color = Ink)
            }
        }
    }
}

@Composable
private fun ChoiceChip(label: String, selected: Boolean, tint: Color, onClick: () -> Unit) {
    Box(
        Modifier.clip(CircleShape)
            .background(if (selected) tint else tint.copy(alpha = 0.10f))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 7.dp)
    ) {
        Text(label, fontSize = 12.5.sp, fontWeight = FontWeight.Bold, color = if (selected) Color.White else tint)
    }
}

@Composable
private fun SelfCheckCard(s: MBlock.SelfCheck, color: Color) {
    val shape = RoundedCornerShape(22.dp)
    Column(
        Modifier.fillMaxWidth().clip(shape).background(Color.White).border(1.dp, color.copy(alpha = 0.22f), shape).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text("✅  AUTO-ÉVALUATION", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = color, letterSpacing = 1.2.sp)
            Text("Soyez honnête : cochez ce que vous maîtrisez déjà.", fontSize = 12.5.sp, fontStyle = FontStyle.Italic, color = InkSoft)
        }
        s.items.forEach { item ->
            var state by rememberSaveable(item) { mutableStateOf(0) }
            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text(item, fontSize = 14.5.sp, lineHeight = 21.sp, color = Ink)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ChoiceChip("Oui", state == 1, Good) { state = if (state == 1) 0 else 1 }
                    ChoiceChip("Pas encore", state == 2, Warn) { state = if (state == 2) 0 else 2 }
                }
            }
        }
        Spacer(Modifier.height(0.dp))
    }
}
