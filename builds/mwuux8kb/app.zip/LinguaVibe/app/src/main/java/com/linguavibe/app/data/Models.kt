package com.linguavibe.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue

/** Un modèle Vosk téléchargeable (alphacephei.com/vosk/models). */
data class VoskModel(val name: String, val size: String, val label: String, val note: String) {
    val url: String get() = "https://alphacephei.com/vosk/models/$name.zip"
}

/** Une langue proposée par l'application, avec ses modèles Vosk (le plus précis en premier). */
data class LanguageInfo(
    val code: String,
    val name: String,
    val nativeName: String,
    val flag: String,
    val ttsTag: String,
    val models: List<VoskModel>,
    val available: Boolean,
    /** Langue maternelle de l'apprenant : pas de cours, sert aux réponses orales. */
    val native: Boolean = false
) {
    val locale: Locale get() = Locale.forLanguageTag(ttsTag)
}

object Languages {
    private const val BEST = "⭐ Précision maximale"
    private const val MID = "⚖️ Équilibré"
    private const val LIGHT = "🪶 Léger"
    private const val BIG_NOTE =
        "Modèle complet, le plus précis. Très gourmand en mémoire : réservé aux appareils haut de gamme " +
            "(8 Go de RAM ou plus). Si l'application se ferme au chargement, prenez le modèle suivant."
    private const val LIGHT_NOTE = "Conçu pour les téléphones : rapide, fonctionne sur tous les appareils."

    val all = listOf(
        LanguageInfo(
            "es", "Espagnol", "Español", "🇪🇸", "es-ES",
            listOf(
                VoskModel("vosk-model-es-0.42", "1,4 Go", BEST, BIG_NOTE),
                VoskModel("vosk-model-small-es-0.42", "39 Mo", LIGHT, LIGHT_NOTE)
            ), true
        ),
        LanguageInfo(
            "en", "Anglais", "English", "🇬🇧", "en-US",
            listOf(
                VoskModel("vosk-model-en-us-0.22", "1,8 Go", BEST, BIG_NOTE),
                VoskModel(
                    "vosk-model-en-us-0.22-lgraph", "128 Mo", MID,
                    "Nettement plus précis que le modèle léger tout en restant utilisable sur un bon téléphone " +
                        "(4 Go de RAM ou plus)."
                ),
                VoskModel("vosk-model-small-en-us-0.15", "40 Mo", LIGHT, LIGHT_NOTE)
            ), true
        ),
        LanguageInfo(
            "ru", "Russe", "Русский", "🇷🇺", "ru-RU",
            listOf(
                VoskModel("vosk-model-ru-0.42", "1,8 Go", BEST, BIG_NOTE),
                VoskModel("vosk-model-small-ru-0.22", "45 Mo", LIGHT, LIGHT_NOTE)
            ), true
        ),
        LanguageInfo(
            "pt", "Portugais", "Português", "🇧🇷", "pt-BR",
            listOf(
                VoskModel("vosk-model-pt-fb-v0.1.1-20220516_2113", "1,6 Go", BEST, BIG_NOTE),
                VoskModel("vosk-model-small-pt-0.3", "31 Mo", LIGHT, LIGHT_NOTE)
            ), true
        ),
        LanguageInfo(
            "zh", "Chinois", "中文", "🇨🇳", "zh-CN",
            listOf(
                VoskModel("vosk-model-cn-0.22", "1,3 Go", BEST, BIG_NOTE),
                VoskModel("vosk-model-small-cn-0.22", "42 Mo", LIGHT, LIGHT_NOTE)
            ), true
        ),
        LanguageInfo(
            "ar", "Arabe", "العربية", "🇸🇦", "ar",
            listOf(
                VoskModel("vosk-model-ar-0.22-linto-1.1.0", "1,3 Go", BEST, BIG_NOTE),
                VoskModel(
                    "vosk-model-ar-mgb2-0.4", "318 Mo", MID,
                    "Le plus petit modèle d'arabe standard : prévoir un téléphone avec 4 Go de RAM ou plus."
                )
            ), true
        ),
        LanguageInfo(
            "fr", "Français", "Français", "🇫🇷", "fr-FR",
            listOf(
                VoskModel("vosk-model-fr-0.22", "1,4 Go", BEST, BIG_NOTE),
                VoskModel("vosk-model-small-fr-0.22", "41 Mo", LIGHT, LIGHT_NOTE)
            ), available = false, native = true
        )
    )

    /** Langues qui ont (ou auront) un cours. */
    val courses: List<LanguageInfo> get() = all.filter { !it.native }

    /** Langue maternelle de l'apprenant (français). */
    val native: LanguageInfo get() = all.first { it.native }

    fun byCode(code: String): LanguageInfo = all.first { it.code == code }
}

/** Les champs « pron » donnent la prononciation figurée (vide si elle est déjà dans la traduction). */
data class Vocab(
    val word: String,
    val translation: String,
    val emoji: String,
    val example: String,
    val exampleTr: String,
    val pron: String = "",
    val examplePron: String = ""
)

data class GrammarExample(val text: String, val translation: String, val pron: String = "")

data class GrammarPoint(
    val title: String,
    val explanation: String,
    val examples: List<GrammarExample>
)

data class DialogueLine(
    val speaker: String,
    val text: String,
    val translation: String,
    val pron: String = "",
    /** Nom du personnage (Fatou, Koffi, Papá…) ; vide pour les dialogues A / B sans personnage. */
    val name: String = ""
) {
    /** Le rôle « B » est joué par l'apprenant. */
    val isUser: Boolean get() = speaker == "B"

    /** Nom affiché dans la bulle. */
    val label: String get() = name.ifBlank { if (isUser) "Vous" else "A" }
}

/**
 * Une scène de dialogue illustrée (MODEL 2 et 3) : un lieu dessiné en lineart ([scene] = identifiant
 * de Scenes), un titre, une mise en situation et les répliques. Le rôle B est joué par l'apprenant.
 */
data class DialogueScene(
    val title: String,
    val titleTr: String,
    val scene: String?,
    val context: String,
    val lines: List<DialogueLine>
) {
    /** Personnages dans l'ordre d'apparition. */
    val characters: List<Pair<String, Boolean>>
        get() = lines.map { it.label to it.isUser }.distinctBy { it.first }
}

/**
 * Question de quiz ou exercice d'atelier. [explain] est la petite explication affichée après la réponse.
 * Types : mcq (choix), typed (réponse écrite), listen (écoute), order (remettre les mots dans l'ordre),
 * fill (phrase à trou), match (associer des paires), speak (dire au micro), write (production libre).
 */
sealed class QuizItem {
    abstract val explain: String

    data class Mcq(val question: String, val correct: String, val wrong: List<String>, override val explain: String = "") : QuizItem()
    data class Typed(
        val prompt: String, val answers: List<String>, override val explain: String = "", val instruction: String = ""
    ) : QuizItem()
    data class Listen(val phrase: String, val correct: String, val wrong: List<String>, override val explain: String = "") : QuizItem()
    /** [words] dans le bon ordre ; l'application les mélange. */
    data class Order(val words: List<String>, val translation: String, override val explain: String = "") : QuizItem()
    /** [sentence] contient « ___ ». Sans [wrong], l'élève tape le mot manquant. */
    data class Fill(
        val sentence: String, val answers: List<String>, val wrong: List<String>, val translation: String,
        override val explain: String = ""
    ) : QuizItem()
    data class Match(val pairs: List<Pair<String, String>>, val title: String = "", override val explain: String = "") : QuizItem()
    data class Speak(val text: String, val translation: String, override val explain: String = "") : QuizItem()
    data class Write(
        val prompt: String, val model: String, val keywords: List<String>, val minWords: Int, override val explain: String = ""
    ) : QuizItem()

    /** Libellé court du type, pour les filtres et les statistiques. */
    val kind: String
        get() = when (this) {
            is Mcq -> "Choix"
            is Typed -> "Écrire"
            is Listen -> "Écoute"
            is Order -> "Ordre"
            is Fill -> "Trou"
            is Match -> "Paires"
            is Speak -> "Oral"
            is Write -> "Rédaction"
        }

    val isValid: Boolean
        get() = when (this) {
            is Mcq -> correct.isNotBlank()
            is Typed -> answers.isNotEmpty()
            is Listen -> correct.isNotBlank()
            is Order -> words.size >= 2
            is Fill -> answers.isNotEmpty() && sentence.contains("___")
            is Match -> pairs.size >= 2
            is Speak -> text.isNotBlank()
            is Write -> prompt.isNotBlank()
        }
}

/** Atelier « À pratiquer » : une consigne et des exercices faisables directement dans l'application. */
data class PracticeSet(
    /** Étiquette de l'exercice du manuel auquel l'atelier est rattaché (« Exercice 3 », « Activité 1 »), sinon vide. */
    val ref: String,
    val title: String,
    val instruction: String,
    val items: List<QuizItem>
)

data class Homework(val prompt: String, val model: String, val keywords: List<String>)

data class Phrase(val text: String, val translation: String, val pron: String = "")

/** Une phrase du texte de lecture : texte, prononciation figurée, traduction. */
data class ReadingSentence(val text: String, val pron: String, val translation: String)

/** Texte de lecture de la leçon. */
data class Reading(val title: String, val titleTr: String, val sentences: List<ReadingSentence>)

data class Lesson(
    val id: String,
    val level: String,
    val number: Int,
    val title: String,
    val titleTr: String,
    val emoji: String,
    val intro: String,
    val vocab: List<Vocab>,
    val grammar: List<GrammarPoint>,
    val dialogue: List<DialogueLine>,
    val quiz: List<QuizItem>,
    val homework: List<Homework>,
    val phrases: List<Phrase>,
    val reading: Reading? = null,
    /** Illustration lineart choisie (facultatif) ; sinon elle est déduite du titre. */
    val art: String? = null,
    /** Contenu intégral extrait du manuel PDF officiel. */
    val sourceContent: String = "",
    /** Illustration originale du manuel, stockée dans les assets de l'application. */
    val illustrationAsset: String? = null,
    /** Dialogues illustrés en plusieurs scènes (MODEL 2 et 3). Vide : on utilise [dialogue]. */
    val scenes: List<DialogueScene> = emptyList(),
    /** Ateliers interactifs « À pratiquer ». */
    val practice: List<PracticeSet> = emptyList(),
    /** Tableaux de conjugaison (MODEL 4). */
    val conjugations: List<ConjTable> = emptyList()
)

/** Un temps conjugué (MODEL 4) : six formes (yo … ellos), règle du temps, formes irrégulières marquées. */
data class ConjTense(
    val id: String,
    val name: String,
    val nameEs: String,
    val mood: String,
    val rule: String,
    val forms: List<String>,
    /** « 1 » pour chaque forme irrégulière (même ordre que [forms]). */
    val irregular: String = ""
) {
    fun isIrregular(i: Int) = irregular.getOrNull(i) == '1'
    val isImperative: Boolean get() = id.startsWith("imperativo")
}

/** Tableau de conjugaison d'un verbe à tous les temps (MODEL 4). */
data class ConjTable(
    val verb: String,
    val translation: String,
    val group: String,
    val note: String,
    val gerund: String,
    val participle: String,
    val tenses: List<ConjTense>
)

data class Course(val lang: String, val lessons: List<Lesson>) {
    fun lesson(id: String): Lesson? = lessons.firstOrNull { it.id == id }
}

object Levels {
    val order = listOf("A1", "A2", "B1", "B2", "C1", "C2")
    fun label(level: String): String = when (level) {
        "A1" -> "Débutant"
        "A2" -> "Élémentaire"
        "B1" -> "Intermédiaire"
        "B2" -> "Avancé"
        "C1" -> "Autonome"
        "C2" -> "Maîtrise"
        else -> level
    }
}

/**
 * Charge les cours : d'abord ceux téléchargés depuis Firebase (files/courses/<code>.json),
 * sinon ceux intégrés à l'application (assets/courses/<code>.json).
 */
/** Parcours indépendants, lus uniquement depuis les assets (jamais remplacés par Firebase). */
val STANDALONE_MODELS = setOf("model2", "model3", "model4")

/** Nom affiché d'un parcours d'espagnol. */
fun modelLabelOf(modelId: String): String = when (modelId) {
    "model2" -> "MODEL 2"; "model3" -> "MODEL 3"; "model4" -> "MODEL 4"; else -> "MODEL 1"
}

object CourseRepository {
    private val cache = HashMap<String, Course>()

    /** Incrémenté quand les cours changent (téléchargement Firebase) pour rafraîchir l'interface. */
    var version by androidx.compose.runtime.mutableIntStateOf(0)
        private set

    fun reload() {
        synchronized(cache) { cache.clear() }
        version++
    }

    fun load(context: Context, lang: String, modelId: String = "model1"): Course {
        val cacheKey = "$lang:$modelId"
        synchronized(cache) { cache[cacheKey]?.let { return it } }
        val course = try {
            if (modelId in STANDALONE_MODELS) {
                // Les modèles 2 et 3 sont des parcours indépendants : ils ne doivent jamais être écrasés par Firebase/MODEL 1.
                loadAsset(context, "${lang}_${modelId}", lang)
            } else {
                val downloaded = java.io.File(java.io.File(context.filesDir, "courses"), "$lang.json")
                if (downloaded.isFile) parse(lang, JSONObject(downloaded.readText(Charsets.UTF_8)))
                else loadAsset(context, lang, lang)
            }
        } catch (e: Exception) {
            try {
                loadAsset(context, if (modelId in STANDALONE_MODELS) "${lang}_${modelId}" else lang, lang)
            } catch (_: Exception) {
                Course(lang, emptyList())
            }
        }
        synchronized(cache) { cache[cacheKey] = course }
        return course
    }

    private fun loadAsset(context: Context, assetName: String, lang: String): Course {
        val text = context.assets.open("courses/$assetName.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
        return parse(lang, JSONObject(text))
    }

    // Firebase supprime les listes vides et peut renvoyer une liste sous forme d'objet {"0": ..., "1": ...} :
    // la lecture accepte les deux formes et tolère les champs absents.
    private fun JSONObject.list(name: String): List<Any> {
        val v = opt(name) ?: return emptyList()
        return when (v) {
            is JSONArray -> (0 until v.length()).mapNotNull { v.opt(it)?.takeIf { x -> x != JSONObject.NULL } }
            is JSONObject -> v.keys().asSequence().sortedBy { it.toIntOrNull() ?: Int.MAX_VALUE }
                .mapNotNull { v.opt(it) }.toList()
            else -> emptyList()
        }
    }

    private fun JSONObject.objects(name: String): List<JSONObject> = list(name).filterIsInstance<JSONObject>()
    private fun JSONObject.strings(name: String): List<String> = list(name).map { it.toString() }

    fun parse(lang: String, root: JSONObject): Course {
        val lessons = root.objects("lessons").mapIndexed { index, o ->
            Lesson(
                id = o.optString("id").ifBlank { "$lang-${index + 1}" },
                level = o.optString("level", "A1"),
                number = o.optInt("number", index + 1),
                title = o.optString("title"),
                titleTr = o.optString("titleTr"),
                emoji = o.optString("emoji", "📘"),
                intro = o.optString("intro"),
                vocab = o.objects("vocab").map {
                    Vocab(
                        it.optString("word"), it.optString("translation"), it.optString("emoji", "🔤"),
                        it.optString("example"), it.optString("exampleTr"),
                        it.optString("pron"), it.optString("examplePron")
                    )
                },
                grammar = o.objects("grammar").map { g ->
                    GrammarPoint(
                        g.optString("title"), g.optString("explanation"),
                        g.objects("examples").map {
                            GrammarExample(it.optString("text"), it.optString("translation"), it.optString("pron"))
                        }
                    )
                },
                dialogue = o.objects("dialogue").map { parseLine(it) },
                quiz = o.objects("quiz").mapNotNull { parseQuiz(it) },
                homework = o.objects("homework").map {
                    Homework(it.optString("prompt"), it.optString("model"), it.strings("keywords"))
                },
                phrases = o.objects("phrases").map {
                    Phrase(it.optString("text"), it.optString("translation"), it.optString("pron"))
                },
                reading = o.optJSONObject("reading")?.let { r ->
                    Reading(
                        r.optString("title"), r.optString("titleTr"),
                        r.objects("sentences").map {
                            ReadingSentence(it.optString("text"), it.optString("pron"), it.optString("translation"))
                        }
                    ).takeIf { it.sentences.isNotEmpty() }
                },
                art = o.optString("art").takeIf { it.isNotBlank() },
                sourceContent = o.optString("sourceContent"),
                illustrationAsset = o.optString("illustrationAsset").takeIf { it.isNotBlank() },
                scenes = o.objects("scenes").map { s ->
                    DialogueScene(
                        title = s.optString("title"),
                        titleTr = s.optString("titleTr"),
                        scene = s.optString("scene").takeIf { it.isNotBlank() },
                        context = s.optString("context"),
                        lines = s.objects("lines").map { parseLine(it) }
                    )
                }.filter { it.lines.isNotEmpty() },
                practice = o.objects("practice").map { p ->
                    PracticeSet(
                        p.optString("ref"), p.optString("title"), p.optString("instruction"),
                        p.objects("items").mapNotNull { parseQuiz(it) }
                    )
                }.filter { it.items.isNotEmpty() },
                conjugations = o.objects("conjugations").map { c ->
                    ConjTable(
                        c.optString("verb"), c.optString("translation"), c.optString("group"), c.optString("note"),
                        c.optString("gerund"), c.optString("participle"),
                        c.objects("tenses").map { t ->
                            ConjTense(
                                t.optString("id"), t.optString("name"), t.optString("nameEs"), t.optString("mood"),
                                t.optString("rule"), t.strings("forms"), t.optString("irregular")
                            )
                        }.filter { it.forms.size == 6 }
                    )
                }
            )
        }
        return Course(lang, lessons)
    }

    /** Lit une question (quiz ou atelier) ; une question incomplète est ignorée. */
    private fun parseQuiz(q: JSONObject): QuizItem? {
        val explain = q.optString("explain")
        val item = when (q.optString("type")) {
            "typed" -> QuizItem.Typed(q.optString("prompt"), q.strings("answers"), explain, q.optString("instruction"))
            "listen" -> QuizItem.Listen(q.optString("phrase"), q.optString("correct"), q.strings("wrong"), explain)
            "order" -> QuizItem.Order(q.strings("words"), q.optString("translation"), explain)
            "fill" -> QuizItem.Fill(q.optString("sentence"), q.strings("answers"), q.strings("wrong"), q.optString("translation"), explain)
            "match" -> QuizItem.Match(
                q.optJSONArray("pairs")?.let { arr ->
                    (0 until arr.length()).mapNotNull { i ->
                        arr.optJSONArray(i)?.let { p -> if (p.length() >= 2) p.optString(0) to p.optString(1) else null }
                    }
                } ?: emptyList(),
                q.optString("title"), explain
            )
            "speak" -> QuizItem.Speak(q.optString("text"), q.optString("translation"), explain)
            "write" -> QuizItem.Write(q.optString("prompt"), q.optString("model"), q.strings("keywords"), q.optInt("minWords", 0), explain)
            else -> QuizItem.Mcq(q.optString("question"), q.optString("correct"), q.strings("wrong"), explain)
        }
        return item.takeIf { it.isValid }
    }

    private fun parseLine(o: JSONObject) = DialogueLine(
        o.optString("speaker", "A"), o.optString("text"), o.optString("translation"),
        o.optString("pron"), o.optString("name")
    )
}
