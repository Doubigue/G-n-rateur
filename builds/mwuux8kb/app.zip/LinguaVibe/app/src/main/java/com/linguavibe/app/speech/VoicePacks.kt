package com.linguavibe.app.speech

import android.content.Context
import androidx.compose.runtime.mutableStateMapOf
import com.linguavibe.app.data.CourseRepository
import com.linguavibe.app.data.Languages
import com.linguavibe.app.lexique.LexiqueRepository
import com.linguavibe.app.ui.CourseNarration
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File

data class PackProgress(val done: Int, val total: Int, val running: Boolean, val message: String? = null)

/** Un pack de voix : [id] sert de clé (« es », « es:conj »…), [voice] est la langue de la voix. */
data class VoicePack(val id: String, val voice: String, val title: String, val subtitle: String)

/**
 * Téléchargement des voix, une seule fois : tout l'audio que l'appli peut faire entendre est enregistré
 * dans le dossier de langue durable, puis lu sans Internet. Les phrases déjà enregistrées sont sautées :
 * un téléchargement interrompu reprend où il s'était arrêté, et quand de nouvelles leçons arrivent,
 * « Compléter » ne télécharge que les phrases manquantes. Le travail tourne en arrière-plan (LangDownloads).
 */
object VoicePacks {
    val progress = mutableStateMapOf<String, PackProgress>()

    /** Nombre de phrases encore absentes, par pack (calculé à l'ouverture de l'écran). */
    val missing = mutableStateMapOf<String, Int>()

    fun packs(): List<VoicePack> = Languages.all.map {
        VoicePack(
            it.code, it.code, it.name,
            if (it.code == "fr") "Narration des cours, lexique en français" else "Leçons, dialogues, quiz, ateliers et manuels"
        )
    } + listOf(
        VoicePack("es:conj", "es", "Espagnol · conjugaison", "Toutes les formes des verbes du Model 4"),
        VoicePack("es:lex", "es", "Espagnol · lexique", "Les 7 600 mots du lexique")
    )

    fun voiceOf(pack: String) = pack.substringBefore(':')

    private fun marker(context: Context, pack: String) =
        File(LangStorage.dir(context, "voice-packs"), pack.replace(':', '_') + ".done")

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences("voice_packs", Context.MODE_PRIVATE)

    /** Le pack a été téléchargé au moins une fois (il peut lui manquer les phrases ajoutées depuis). */
    fun isDone(context: Context, pack: String): Boolean =
        marker(context, pack).exists() || prefs(context).getBoolean("done_$pack", false)

    private fun courses(context: Context, lang: String) = buildList {
        add(CourseRepository.load(context, lang, "model1"))
        if (lang == "es") {
            add(CourseRepository.load(context, lang, "model2"))
            add(CourseRepository.load(context, lang, "model3"))
            add(CourseRepository.load(context, lang, "model4"))
        }
    }

    /** Toutes les phrases du pack. */
    fun texts(context: Context, pack: String): List<String> {
        val lexSpoken: (String) -> String = { it.replace(" / ", ", ").replace("/", ", ") }
        val out = when (pack) {
            "es:conj" -> courses(context, "es").flatMap { it.lessons }.flatMap { l -> l.conjugations.flatMap { SpokenTexts.conjugation(it) } }
            "es:lex" -> runCatching { LexiqueRepository.load(context).map { lexSpoken(it.es) } }.getOrDefault(emptyList())
            "fr" -> {
                val intro = listOf("Bonjour et bienvenue dans LinguaVibe.", "Écoutez la phrase, puis répétez-la à voix haute.")
                intro + CourseNarration.frenchTexts(context) +
                    runCatching { LexiqueRepository.load(context).map { lexSpoken(it.fr) } }.getOrDefault(emptyList())
            }
            else -> courses(context, pack).flatMap { it.lessons }.flatMap { SpokenTexts.lesson(it) }
        }
        return SpokenTexts.clean(out)
    }

    /** Compte les phrases du pack qui ne sont pas encore sur le téléphone. */
    suspend fun countMissing(context: Context, pack: String): Int = withContext(Dispatchers.IO) {
        val voice = voiceOf(pack)
        val n = texts(context, pack).count { !GoogleVoice.isCached(context, it, voice) }
        missing[pack] = n
        n
    }

    /** Lance (ou relance) le téléchargement en arrière-plan. */
    fun start(context: Context, pack: String) {
        progress[pack] = progress[pack]?.copy(running = true, message = null) ?: PackProgress(0, 0, true)
        LangDownloads.enqueue(context, LangDownloads.KIND_PACK, pack, replace = true)
    }

    /**
     * Le vrai travail, exécuté par le worker. Lève [VoiceNetworkException] si le réseau tombe :
     * le worker réessaie plus tard et reprend à la première phrase manquante.
     */
    suspend fun run(context: Context, pack: String, onProgress: (Int, Int) -> Unit) {
        val app = context.applicationContext
        val voice = voiceOf(pack)
        progress[pack] = PackProgress(0, 0, true)
        val all = texts(app, pack)
        val total = all.size
        var done = 0
        var failed = 0
        progress[pack] = PackProgress(0, total, true)
        for (text in all) {
            val cached = GoogleVoice.isCached(app, text, voice)
            if (!cached) {
                try {
                    GoogleVoice.speechFile(app, text, voice)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: VoiceNetworkException) {
                    progress[pack] = PackProgress(done, total, false, "En attente du réseau : le téléchargement reprendra tout seul.")
                    throw e
                } catch (_: Throwable) {
                    failed++ // phrase refusée par le service : on passe à la suivante
                }
            }
            done++
            if (done % 5 == 0 || done == total) {
                progress[pack] = PackProgress(done, total, true)
                onProgress(done, total)
            }
            if (!cached) delay(120)
        }
        marker(app, pack).writeText("$total\n")
        missing[pack] = failed
        progress[pack] = PackProgress(total, total, false, if (failed > 0) "$failed phrase(s) refusée(s) par le service : la voix du téléphone les lira." else null)
    }

    fun cancel(context: Context, pack: String) {
        LangDownloads.cancel(context, LangDownloads.KIND_PACK, pack)
        progress[pack]?.let { progress[pack] = it.copy(running = false, message = "Téléchargement arrêté.") }
    }

    /** À appeler quand l'audio enregistré est vidé. */
    fun resetAll(context: Context) {
        LangDownloads.cancelAll(context, LangDownloads.KIND_PACK)
        progress.clear()
        missing.clear()
        prefs(context).edit().clear().apply()
        File(LangStorage.root(context), "voice-packs").listFiles()?.forEach { it.delete() }
    }
}
