package com.linguavibe.app.speech

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import java.io.File

/**
 * Où sont rangées les données de langue (modèles Vosk, voix Supertonic et chinoise, audios des phrases).
 *
 * Le dossier privé de l'appli est effacé par Android à la désinstallation. Avec l'accès au stockage,
 * tout va dans le dossier public « LinguaVibe » à la racine du téléphone : il reste après une
 * désinstallation, et l'appli réinstallée retrouve ses langues sans rien retélécharger.
 * Sans cet accès, on garde le dossier privé (comportement d'avant).
 */
object LangStorage {
    const val FOLDER = "LinguaVibe"

    /** Sous-dossiers de données de langue (mêmes noms dans le dossier privé et le dossier public). */
    val parts = listOf("vosk", "tts-models", "google-voice", "tts", "voice-packs", "downloads")

    /** Change quand le dossier utilisé change (accès accordé, migration terminée). */
    var version by mutableIntStateOf(0)
        private set

    /** Message de migration en cours, sinon null. */
    var migrating by mutableStateOf<String?>(null)
        private set

    fun publicDir(): File = File(Environment.getExternalStorageDirectory(), FOLDER)

    /** Vrai si l'appli peut écrire dans le dossier public durable. */
    fun hasDurableAccess(context: Context): Boolean = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED
        }
    } catch (_: Throwable) {
        false
    }

    /** Dossier racine des données de langue. */
    fun root(context: Context): File {
        if (hasDurableAccess(context)) {
            val dir = publicDir()
            if (dir.isDirectory || dir.mkdirs()) {
                ensureMarkers(dir)
                return dir
            }
        }
        return context.applicationContext.filesDir
    }

    fun dir(context: Context, part: String): File = File(root(context), part).apply { mkdirs() }

    /** Vrai si les données vont réellement dans le dossier public durable. */
    fun isDurable(context: Context): Boolean = root(context).absolutePath.startsWith(publicDir().absolutePath)

    /** Écran système à ouvrir pour accorder l'accès (Android 11 et plus). */
    fun accessIntent(context: Context): Intent? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return null
        return Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
            .setData(Uri.parse("package:${context.packageName}"))
    }

    fun fallbackAccessIntent(): Intent? =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION) else null

    private fun ensureMarkers(dir: File) {
        try {
            // Les audios ne doivent pas apparaître dans la musique du téléphone.
            File(dir, ".nomedia").takeIf { !it.exists() }?.createNewFile()
            val readme = File(dir, "LISEZ-MOI.txt")
            if (!readme.exists()) {
                readme.writeText(
                    "Données de langue de l'application LinguaVibe (modèles de reconnaissance vocale, voix et audios des leçons).\n" +
                        "Ce dossier est conservé même si l'application est désinstallée : après une réinstallation, " +
                        "accordez l'accès au stockage dans l'appli et vos langues sont retrouvées sans rien télécharger.\n" +
                        "Supprimez ce dossier uniquement si vous voulez effacer définitivement ces données.\n"
                )
            }
        } catch (_: Throwable) {
        }
    }

    /** Taille totale des données de langue, en Mo. */
    fun sizeMb(context: Context): Long =
        parts.sumOf { p -> File(root(context), p).walkTopDown().filter { it.isFile }.sumOf { it.length() } } / (1024 * 1024)

    /**
     * Déplace les données du dossier privé vers le dossier public quand l'accès vient d'être accordé.
     * À appeler hors du fil principal. Sans effet s'il n'y a rien à déplacer.
     */
    @Synchronized
    fun migrateToDurable(context: Context) {
        if (!hasDurableAccess(context)) return
        val from = context.applicationContext.filesDir
        val to = publicDir().apply { mkdirs() }
        ensureMarkers(to)
        val todo = parts.map { File(from, it) }.filter { d -> d.isDirectory && (d.list()?.isNotEmpty() == true) }
        if (todo.isEmpty()) return
        try {
            for (src in todo) {
                migrating = "Mise à l'abri des données : ${src.name}…"
                val dst = File(to, src.name)
                src.walkTopDown().forEach { f ->
                    val target = File(dst, f.relativeTo(src).path)
                    if (f.isDirectory) {
                        target.mkdirs()
                    } else if (!(target.exists() && target.length() == f.length())) {
                        target.parentFile?.mkdirs()
                        val tmp = File(target.path + ".copy")
                        f.copyTo(tmp, overwrite = true)
                        if (!tmp.renameTo(target)) {
                            tmp.copyTo(target, overwrite = true)
                            tmp.delete()
                        }
                    }
                }
                src.deleteRecursively()
            }
        } finally {
            migrating = null
            version++
        }
    }

    /** À appeler quand l'accès a pu changer (retour des paramètres système). */
    fun refresh() {
        version++
    }
}
