package com.linguavibe.app.speech

import android.content.Context
import com.k2fsa.sherpa.onnx.GenerationConfig
import com.k2fsa.sherpa.onnx.OfflineTts
import com.k2fsa.sherpa.onnx.OfflineTtsConfig
import com.k2fsa.sherpa.onnx.OfflineTtsModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsVitsModelConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest

/** VITS Icefall AISHELL-3 : synthèse Mandarin hors ligne, 174 identifiants de speaker. */
object ChineseVitsTts {
    private val lock = Any(); private var engine: OfflineTts? = null; private var loadedPath: String? = null
    suspend fun speechFile(context: Context, text: String, speakerId: Int, speed: Float): File = withContext(Dispatchers.Default) {
        check(ChineseVoiceManager.isInstalled(context)) { "Téléchargez le modèle chinois dans Paramètres > Voix." }
        val model = ChineseVoiceManager.modelDir(context)
        val key = MessageDigest.getInstance("SHA-1").digest("zh|$speakerId|$speed|${text.trim()}".toByteArray()).joinToString("") { "%02x".format(it) }
        val cache = File(context.filesDir, "tts-supertonic/cache").apply { mkdirs() }; val out = File(cache, "zh_$key.wav")
        if (out.length() > 512L) return@withContext out
        synchronized(lock) {
            if (engine == null || loadedPath != model.absolutePath) {
                engine?.release()
                val vits = OfflineTtsVitsModelConfig(model = File(model, "model.onnx").absolutePath, lexicon = File(model, "lexicon.txt").absolutePath, tokens = File(model, "tokens.txt").absolutePath, noiseScale = 0.667f, noiseScaleW = 0.8f)
                val ruleFiles = listOf("phone.fst", "date.fst", "number.fst").map { File(model, it) }.filter { it.exists() }
                val config = OfflineTtsConfig(model = OfflineTtsModelConfig(vits = vits, numThreads = 2, debug = false), ruleFsts = ruleFiles.joinToString(",") { it.absolutePath })
                engine = OfflineTts(config = config); loadedPath = model.absolutePath
            }
            val gen = GenerationConfig(sid = speakerId.coerceIn(0, 173), speed = speed.coerceIn(0.5f, 1.5f))
            engine!!.generateWithConfig(text.trim(), gen).save(out.absolutePath)
        }
        check(out.length() > 512L) { "La synthèse chinoise n'a pas produit d'audio." }; out
    }
    fun release() = synchronized(lock) { engine?.release(); engine = null; loadedPath = null }
}
