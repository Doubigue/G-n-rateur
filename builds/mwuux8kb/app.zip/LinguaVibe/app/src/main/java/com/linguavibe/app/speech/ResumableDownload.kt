package com.linguavibe.app.speech

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Téléchargement qui reprend où il s'était arrêté : les octets reçus sont gardés dans « fichier.part »
 * et la suite est demandée au serveur (en-tête Range). Une coupure réseau, l'arrêt de l'appli ou du
 * téléphone ne font donc jamais repartir de zéro.
 */
object ResumableDownload {

    /**
     * Télécharge [url] dans [dest]. [onProgress] reçoit (octets reçus, taille totale ou -1).
     * Lève [VoiceNetworkException] en cas de problème réseau (on peut réessayer plus tard).
     */
    suspend fun fetch(url: String, dest: File, onProgress: (Long, Long) -> Unit): File = withContext(Dispatchers.IO) {
        if (dest.length() > 0) return@withContext dest
        dest.parentFile?.mkdirs()
        val part = File(dest.path + ".part")
        var attempt = 0
        while (true) {
            try {
                download(url, part, onProgress)
                break
            } catch (e: HttpRangeIgnored) {
                part.delete()
                if (++attempt > 1) throw IllegalStateException("Le serveur refuse la reprise du téléchargement.")
            }
        }
        if (!part.renameTo(dest)) {
            part.copyTo(dest, overwrite = true)
            part.delete()
        }
        dest
    }

    private class HttpRangeIgnored : Exception()

    private suspend fun download(url: String, part: File, onProgress: (Long, Long) -> Unit) {
        val already = part.length()
        val connection = try {
            (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 20_000
                readTimeout = 60_000
                instanceFollowRedirects = true
                if (already > 0) setRequestProperty("Range", "bytes=$already-")
            }
        } catch (e: IOException) {
            throw VoiceNetworkException("Connexion impossible : le téléchargement reprendra dès que le réseau revient.")
        }
        try {
            val code = try {
                connection.responseCode
            } catch (e: IOException) {
                throw VoiceNetworkException("Connexion impossible : le téléchargement reprendra dès que le réseau revient.")
            }
            if (code == 416 && already > 0) return // déjà complet
            if (code !in 200..299) throw IllegalStateException("Téléchargement impossible (code $code).")
            val resumed = already > 0 && code == 206
            if (already > 0 && !resumed) throw HttpRangeIgnored()
            val length = connection.contentLengthLong
            val total = if (length > 0) length + (if (resumed) already else 0) else -1L
            val free = part.parentFile?.usableSpace ?: Long.MAX_VALUE
            if (length > 0 && free < length * 23 / 10) {
                throw IllegalStateException("Espace insuffisant : libérez environ ${length * 23 / 10 / (1024 * 1024)} Mo.")
            }
            var done = if (resumed) already else 0L
            var last = 0L
            val buffer = ByteArray(64 * 1024)
            try {
                connection.inputStream.use { input ->
                    FileOutputStream(part, resumed).use { out ->
                        while (true) {
                            currentCoroutineContext().ensureActive()
                            val n = input.read(buffer)
                            if (n < 0) break
                            out.write(buffer, 0, n)
                            done += n
                            if (done - last > 256 * 1024) {
                                last = done
                                onProgress(done, total)
                            }
                        }
                    }
                }
            } catch (e: IOException) {
                throw VoiceNetworkException("Connexion interrompue : le téléchargement reprendra où il s'est arrêté.")
            }
            if (total > 0 && done < total) {
                throw VoiceNetworkException("Téléchargement incomplet : il reprendra où il s'est arrêté.")
            }
            onProgress(done, total)
        } finally {
            connection.disconnect()
        }
    }
}
