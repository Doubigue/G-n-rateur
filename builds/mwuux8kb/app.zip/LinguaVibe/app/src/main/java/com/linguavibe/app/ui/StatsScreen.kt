package com.linguavibe.app.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linguavibe.app.data.Conjugator
import com.linguavibe.app.data.Languages
import com.linguavibe.app.data.Levels
import com.linguavibe.app.data.ProgressStore
import com.linguavibe.app.study.StudyReminder
import com.linguavibe.app.study.StudyStore
import kotlinx.coroutines.launch
import java.util.Calendar

private val StatsColor = Color(0xFF0E7C86)

/** Tableau de bord : temps d'étude, réussite, série, calendrier, cartes, temps de conjugaison, examens, rappel. */
@Composable
fun StatsScreen(progress: ProgressStore, onBack: () -> Unit) {
    val context = LocalContext.current
    val version = StudyStore.version
    val week = remember(version) { StudyStore.lastDays(context, 7) }
    val month = remember(version) { StudyStore.lastDays(context, 35) }
    val totals = remember(version) { StudyStore.totals(context) }
    val cards = remember(version) { StudyStore.allCards(context) }
    val studyStreak = remember(version) { StudyStore.studyStreak(context) }
    val tenses = remember { runCatching { Conjugator.tenses(context) }.getOrDefault(emptyList()) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopBar("Mes statistiques", "Progression et habitudes", StatsColor, onBack)
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(GridGap)) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatBox("${progress.xp}", "XP", Gold, Modifier.weight(1f))
                StatBox("$studyStreak 🔥", "jours de suite", Ruby, Modifier.weight(1f))
                StatBox(minutesLabel(totals.first), "d'étude", StatsColor, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                val rate = if (totals.second == 0) "—" else "${totals.third * 100 / totals.second} %"
                StatBox(rate, "de réussite", Good, Modifier.weight(1f))
                StatBox("${totals.second}", "réponses", Navy, Modifier.weight(1f))
                StatBox("${cards.count { it.learned }}", "mots appris", Color(0xFF6A3FB5), Modifier.weight(1f))
            }

            CardBox {
                Text("Cette semaine", style = PosterTitle, fontSize = 17.sp, color = Ink)
                val max = week.maxOf { it.minutes }.coerceAtLeast(10)
                Row(Modifier.fillMaxWidth().height(130.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom) {
                    week.forEach { d ->
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("${d.minutes}", fontSize = 10.sp, color = InkSoft)
                            Box(
                                Modifier.fillMaxWidth().height((90f * d.minutes / max).coerceAtLeast(3f).dp)
                                    .clip(RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))
                                    .background(if (d.day == StudyStore.today()) Gold else StatsColor)
                            )
                            Text(dayLetter(d.day), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Ink)
                        }
                    }
                }
                Text("Minutes d'étude par jour (l'appli compte le temps passé ouverte).", fontSize = 12.sp, color = InkSoft)
            }

            CardBox {
                Text("Calendrier des 5 dernières semaines", style = PosterTitle, fontSize = 17.sp, color = Ink)
                month.chunked(7).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        row.forEach { d ->
                            val level = when {
                                d.minutes == 0 && d.answers == 0 -> 0f
                                d.minutes < 5 -> 0.3f
                                d.minutes < 15 -> 0.6f
                                else -> 1f
                            }
                            Box(
                                Modifier.weight(1f).aspectRatio(1f).clip(RoundedCornerShape(6.dp))
                                    .background(if (level == 0f) Sand else Good.copy(alpha = 0.25f + 0.75f * level)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(dayOfMonth(d.day), fontSize = 10.sp, color = if (level >= 0.6f) Color.White else InkSoft)
                            }
                        }
                    }
                }
                Text("Plus la case est foncée, plus vous avez étudié ce jour-là.", fontSize = 12.sp, color = InkSoft)
            }

            CardBox {
                Text("Révision espacée", style = PosterTitle, fontSize = 17.sp, color = Ink)
                val due = cards.count { it.due <= StudyStore.today() }
                Text("${cards.size} cartes · ${cards.count { it.learned }} bien sues · $due à revoir aujourd'hui", fontSize = 14.sp, color = InkSoft)
                StudyStore.INTERVALS.indices.forEach { box ->
                    val n = cards.count { it.box == box }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Boîte ${box + 1} (${StudyStore.INTERVALS[box]} j)", Modifier.width(120.dp), fontSize = 12.sp, color = Ink)
                        RateBar(if (cards.isEmpty()) 0f else n.toFloat() / cards.size, Color(0xFF6A3FB5), Modifier.weight(1f))
                        Text("$n", fontSize = 12.sp, color = InkSoft)
                    }
                }
            }

            if (tenses.isNotEmpty()) CardBox {
                Text("Réussite par temps de conjugaison", style = PosterTitle, fontSize = 17.sp, color = Ink)
                Text("Entraînez-vous depuis les fiches de révision par temps (espagnol).", fontSize = 12.sp, color = InkSoft)
                tenses.forEach { t ->
                    val (good, total) = remember(version, t.id) { StudyStore.tense(context, t.id) }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(t.name, Modifier.width(140.dp), fontSize = 12.sp, color = Ink, maxLines = 1)
                        RateBar(if (total == 0) 0f else good.toFloat() / total, if (total > 0 && good * 100 / total < 60) Bad else Good, Modifier.weight(1f))
                        Text(if (total == 0) "—" else "${good * 100 / total} %", Modifier.width(40.dp), fontSize = 12.sp, color = InkSoft, textAlign = TextAlign.End)
                    }
                }
            }

            CardBox {
                Text("Examens réussis", style = PosterTitle, fontSize = 17.sp, color = Ink)
                var any = false
                Languages.courses.filter { it.available }.forEach { l ->
                    val passed = Levels.order.mapNotNull { lv -> StudyStore.examScore(context, l.code, lv).takeIf { it >= ProgressStore.PASS_SCORE }?.let { "$lv ($it %)" } }
                    if (passed.isNotEmpty()) {
                        any = true
                        Text("${l.flag} ${l.name} : ${passed.joinToString(" · ")}", fontSize = 14.sp, color = Ink)
                    }
                }
                if (!any) Text("Aucun examen réussi pour l'instant. Passez un examen de niveau depuis l'accueil.", fontSize = 13.sp, color = InkSoft)
            }

            ReminderCard()
        }
    }
}

@Composable
private fun ReminderCard() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var enabled by remember { mutableStateOf(StudyReminder.isEnabled(context)) }
    var hour by remember { mutableIntStateOf(StudyReminder.hour(context)) }
    var minute by remember { mutableIntStateOf(StudyReminder.minute(context)) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) { enabled = true; StudyReminder.setEnabled(context, true) }
    }
    CardBox {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Rappel quotidien", style = PosterTitle, fontSize = 17.sp, color = Ink)
                Text("Une notification avec un mini-quiz de 3 questions.", fontSize = 13.sp, color = InkSoft)
            }
            Switch(checked = enabled, onCheckedChange = { on ->
                if (on && Build.VERSION.SDK_INT >= 33 && !StudyReminder.hasPermission(context)) {
                    permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                } else {
                    enabled = on; StudyReminder.setEnabled(context, on)
                }
            })
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Heure :", fontSize = 14.sp, color = Ink)
            StepButton("−") { hour = (hour + 23) % 24; StudyReminder.setTime(context, hour, minute) }
            Text("%02d:%02d".format(hour, minute), style = PosterTitle, fontSize = 20.sp, color = StatsColor)
            StepButton("+") { hour = (hour + 1) % 24; StudyReminder.setTime(context, hour, minute) }
            StepButton(":${"%02d".format((minute + 15) % 60)}") { minute = (minute + 15) % 60; StudyReminder.setTime(context, hour, minute) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(7, 12, 18, 20).forEach { h ->
                StepButton("$h h") { hour = h; minute = 0; StudyReminder.setTime(context, h, 0) }
            }
        }
        PillButton("Tester la notification", Art.icPlay, StatsColor, Modifier.fillMaxWidth(), filled = false) {
            scope.launch { StudyReminder.notifyNow(context) }
        }
    }
}

@Composable
private fun StepButton(label: String, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(12.dp)).background(StatsColor.copy(alpha = 0.12f)).clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) { Text(label, fontWeight = FontWeight.Bold, color = StatsColor, fontSize = 14.sp) }
}

@Composable
fun StatBox(value: String, label: String, color: Color, modifier: Modifier = Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(18.dp)).background(Color.White).padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(value, style = PosterTitle, fontSize = 20.sp, color = color, maxLines = 1)
        Text(label, fontSize = 11.5.sp, color = InkSoft, textAlign = TextAlign.Center)
    }
}

@Composable
fun RateBar(fraction: Float, color: Color, modifier: Modifier = Modifier) {
    Box(modifier.height(10.dp).clip(RoundedCornerShape(50)).background(color.copy(alpha = 0.12f))) {
        Box(Modifier.fillMaxHeight().fillMaxWidth(fraction.coerceIn(0f, 1f)).clip(RoundedCornerShape(50)).background(color))
    }
}

private fun minutesLabel(m: Int) = if (m < 60) "$m min" else "${m / 60} h ${"%02d".format(m % 60)}"

private fun calOf(day: Long): Calendar = Calendar.getInstance().apply {
    // [day] est compté en jours locaux : on revient à midi pour éviter les décalages d'heure.
    timeInMillis = day * 86_400_000L + 12 * 3_600_000L - (get(Calendar.ZONE_OFFSET) + get(Calendar.DST_OFFSET))
}

private fun dayLetter(day: Long) = when (calOf(day).get(Calendar.DAY_OF_WEEK)) {
    Calendar.MONDAY -> "L"; Calendar.TUESDAY -> "M"; Calendar.WEDNESDAY -> "M"; Calendar.THURSDAY -> "J"
    Calendar.FRIDAY -> "V"; Calendar.SATURDAY -> "S"; else -> "D"
}

private fun dayOfMonth(day: Long) = calOf(day).get(Calendar.DAY_OF_MONTH).toString()
