package com.linguavibe.app.speech

import com.linguavibe.app.data.ConjTable
import com.linguavibe.app.data.ConjTense
import com.linguavibe.app.data.Lesson
import com.linguavibe.app.data.QuizItem
import com.linguavibe.app.ui.CourseNarration
import com.linguavibe.app.ui.MBlock
import com.linguavibe.app.ui.ManualParser

/**
 * Tous les textes que l'appli fait lire à voix haute, écrits exactement comme ils sont envoyés à la voix.
 * Sert aux packs de voix : une phrase absente de cette liste ne serait pas disponible hors ligne.
 */
object SpokenTexts {
    private val PRONOUNS = listOf("yo", "tú", "él", "nosotros", "vosotros", "ellos")

    /** Ce que lit une carte de vocabulaire. */
    fun vocabSpoken(word: String, example: String): String =
        if (word.any { it == '+' || it == '…' }) example else word

    /** Ce que lit une ligne d'un tableau de conjugaison (« yo tengo », ou la forme seule à l'impératif). */
    fun conjugated(tense: ConjTense, person: Int): String {
        val f = tense.forms[person]
        return if (tense.isImperative) f else "${PRONOUNS[person]} $f"
    }

    /** Ce que lit la narration pour un temps entier (« yo tengo, tú tienes… »). */
    fun conjugatedLine(tense: ConjTense): String =
        tense.forms.indices.filter { tense.forms[it] != "—" }.joinToString(", ") { conjugated(tense, it) } + "."

    fun conjugation(table: ConjTable): List<String> = buildList {
        add(table.verb)
        table.tenses.forEach { t -> t.forms.indices.filter { t.forms[it] != "—" }.forEach { add(conjugated(t, it)) } }
    }

    /** Ce qu'une question fait entendre (réponse, phrase complète, phrase à écouter…). */
    fun quiz(q: QuizItem): List<String> = when (q) {
        is QuizItem.Mcq -> listOf(q.correct)
        is QuizItem.Typed -> listOf(q.answers.first())
        is QuizItem.Listen -> listOf(q.phrase)
        is QuizItem.Order -> listOf(q.words.joinToString(" "))
        is QuizItem.Fill -> listOf(q.sentence.replace("___", q.answers.first()))
        is QuizItem.Match -> q.pairs.map { it.first }
        is QuizItem.Speak -> listOf(q.text)
        is QuizItem.Write -> listOf(q.model)
    }

    /** Phrases du texte de manuel que l'on peut toucher pour les écouter. */
    fun manual(raw: String): List<String> {
        if (raw.isBlank()) return emptyList()
        return ManualParser.parse(raw).flatMap { b ->
            when (b) {
                is MBlock.Pairs -> b.items.map { it.first }
                is MBlock.Days -> b.items.map { it.first }
                is MBlock.Table -> b.rows.flatMap { it }
                is MBlock.Dialogue -> b.turns.map { it.second }
                is MBlock.Reading -> listOf(b.spanish)
                is MBlock.Questions -> b.items.filter { it.startsWith("¿") }
                else -> emptyList()
            }
        }
    }

    /** Tout ce qu'une leçon peut faire entendre dans sa langue (sans les tableaux de conjugaison). */
    fun lesson(lesson: Lesson): List<String> = buildList {
        lesson.vocab.forEach { add(vocabSpoken(it.word, it.example)); add(it.example) }
        lesson.grammar.forEach { g -> g.examples.forEach { add(it.text) } }
        lesson.dialogue.forEach { add(it.text) }
        lesson.scenes.forEach { s -> s.lines.forEach { add(it.text) } }
        lesson.phrases.forEach { add(it.text) }
        lesson.reading?.sentences?.forEach { add(it.text) }
        lesson.homework.forEach { add(it.model) }
        lesson.quiz.forEach { addAll(quiz(it)) }
        lesson.practice.forEach { p -> p.items.forEach { addAll(quiz(it)) } }
        lesson.conjugations.forEach { add(it.verb) }
        addAll(manual(lesson.sourceContent))
        // Parties de la narration lues avec la voix de la langue étudiée.
        CourseNarration.build(lesson, frenchOnly = false).filter { it.foreign }.forEach { add(it.text) }
    }

    fun clean(list: List<String>): List<String> = list.map { it.trim() }.filter { it.isNotEmpty() && it != "—" }.distinct()
}
