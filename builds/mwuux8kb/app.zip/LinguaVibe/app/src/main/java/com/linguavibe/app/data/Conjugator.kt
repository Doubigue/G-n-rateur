package com.linguavibe.app.data

import android.content.Context
import org.json.JSONObject
import java.text.Normalizer

/**
 * Conjugueur espagnol : n'importe quel verbe à tous les temps.
 * - 890 verbes (lexique + MODEL 4) sont lus dans assets/conjugations/es_verbs.json, générés par tools/verbdb.py,
 *   avec leurs irrégularités repérées.
 * - Les verbes pronominaux (levantarse, irse…) sont conjugués à partir du verbe simple : me levanto, levántate…
 * - Un verbe absent de la base est conjugué selon la règle des verbes réguliers (l'écran le signale).
 */
object Conjugator {
    data class TenseMeta(val id: String, val name: String, val nameEs: String, val mood: String, val rule: String)
    private data class Entry(val inf: String, val fr: String, val gerund: String, val participle: String, val forms: List<String>, val irr: List<String>)

    data class Result(
        val query: String,
        val table: ConjTable,
        /** Faux : verbe absent de la base, conjugué comme un verbe régulier. */
        val known: Boolean,
        val reflexive: Boolean
    )

    private var tenses: List<TenseMeta> = emptyList()
    private var verbs: Map<String, Entry> = emptyMap()
    private var alias: Map<String, Pair<String, String>> = emptyMap()
    private var keys: List<Pair<String, String>> = emptyList() // (clé sans accents, infinitif affiché)

    @Synchronized
    private fun load(context: Context) {
        if (verbs.isNotEmpty()) return
        val o = JSONObject(context.assets.open("conjugations/es_verbs.json").bufferedReader(Charsets.UTF_8).use { it.readText() })
        val ts = o.getJSONArray("tenses")
        tenses = (0 until ts.length()).map { i ->
            val t = ts.getJSONObject(i)
            TenseMeta(t.getString("id"), t.getString("name"), t.getString("nameEs"), t.getString("mood"), t.getString("rule"))
        }
        val vs = o.getJSONArray("verbs")
        val map = LinkedHashMap<String, Entry>(vs.length() * 2)
        for (i in 0 until vs.length()) {
            val v = vs.getJSONObject(i)
            val t = v.getJSONArray("t")
            val x = v.getJSONArray("x")
            map[v.getString("i")] = Entry(
                v.getString("i"), v.getString("f"), v.getString("g"), v.getString("p"),
                (0 until t.length()).map { t.getString(it) }, (0 until x.length()).map { x.getString(it) }
            )
        }
        val al = o.getJSONObject("alias")
        alias = al.keys().asSequence().associateWith { k -> al.getJSONArray(k).let { it.getString(0) to it.getString(1) } }
        verbs = map
        keys = (map.keys + alias.keys).map { fold(it) to it }.sortedBy { it.first }
    }

    fun tenses(context: Context): List<TenseMeta> {
        load(context); return tenses
    }

    /** Minuscules et sans accents, pour chercher « tener », « TENER » ou « tenér ». */
    fun fold(s: String): String =
        Normalizer.normalize(s.lowercase().trim(), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")

    /** Suggestions : infinitifs qui commencent par la saisie, puis verbes dont la traduction contient le mot. */
    fun suggest(context: Context, query: String, limit: Int = 10): List<Pair<String, String>> {
        load(context)
        val q = fold(query)
        if (q.length < 2) return emptyList()
        val byVerb = keys.filter { it.first.startsWith(q) }.map { it.second }
        val byMeaning = if (q.length >= 3) verbs.values.filter { fold(it.fr).split(Regex("[^a-z]+")).any { w -> w.startsWith(q) } }.map { it.inf } else emptyList()
        return (byVerb + byMeaning).distinct().take(limit).map { it to (verbs[it]?.fr ?: alias[it]?.second ?: "") }
    }

    fun count(context: Context): Int {
        load(context); return verbs.size + alias.size
    }

    /** Conjugue [raw] (infinitif, pronominal ou non). Renvoie null si ce n'est pas un infinitif espagnol. */
    fun conjugate(context: Context, raw: String): Result? {
        load(context)
        var q = raw.lowercase().trim().replace(Regex("\\s+"), " ")
        if (q.startsWith("se ")) q = q.removePrefix("se ") + "se"
        val f = fold(q)
        // Retrouver l'orthographe exacte (avec accents) si l'utilisateur ne les a pas tapés.
        val exact = keys.firstOrNull { it.first == f }?.second ?: q
        var reflexive = false
        var base = exact
        var fr: String? = null
        alias[exact]?.let { (b, t) -> base = b; fr = t; reflexive = true }
        if (!reflexive && exact.endsWith("se") && exact.dropLast(2).matches(Regex(".*(ar|er|ir|ír)"))) {
            base = exact.dropLast(2); reflexive = true
        }
        if (!base.matches(Regex("[a-záéíóúñü]+(ar|er|ir|ír)"))) return null
        val entry = verbs[base]
        val table = if (entry != null) {
            ConjTable(
                verb = base, translation = fr ?: entry.fr, group = "-" + base.takeLast(2).replace("ír", "ir"),
                note = "", gerund = entry.gerund, participle = entry.participle,
                tenses = tenses.mapIndexed { i, m ->
                    ConjTense(m.id, m.name, m.nameEs, m.mood, m.rule, entry.forms[i].split('|'), entry.irr.getOrElse(i) { "" })
                }
            )
        } else regular(base)
        val result = if (reflexive) reflexiveOf(table, exact, fr) else table
        return Result(raw.trim(), result, entry != null, reflexive)
    }

    // ------------------------------------------------------------------ verbes réguliers inconnus

    private val END = mapOf(
        "presente" to mapOf("ar" to listOf("o", "as", "a", "amos", "áis", "an"), "er" to listOf("o", "es", "e", "emos", "éis", "en"), "ir" to listOf("o", "es", "e", "imos", "ís", "en")),
        "imperfecto" to mapOf("ar" to listOf("aba", "abas", "aba", "ábamos", "abais", "aban"), "er" to listOf("ía", "ías", "ía", "íamos", "íais", "ían"), "ir" to listOf("ía", "ías", "ía", "íamos", "íais", "ían")),
        "indefinido" to mapOf("ar" to listOf("é", "aste", "ó", "amos", "asteis", "aron"), "er" to listOf("í", "iste", "ió", "imos", "isteis", "ieron"), "ir" to listOf("í", "iste", "ió", "imos", "isteis", "ieron")),
        "subj" to mapOf("ar" to listOf("e", "es", "e", "emos", "éis", "en"), "er" to listOf("a", "as", "a", "amos", "áis", "an"), "ir" to listOf("a", "as", "a", "amos", "áis", "an"))
    )
    private val HABER = mapOf(
        "preterito_perfecto" to listOf("he", "has", "ha", "hemos", "habéis", "han"),
        "pluscuamperfecto" to listOf("había", "habías", "había", "habíamos", "habíais", "habían"),
        "futuro_perfecto" to listOf("habré", "habrás", "habrá", "habremos", "habréis", "habrán"),
        "condicional_perfecto" to listOf("habría", "habrías", "habría", "habríamos", "habríais", "habrían"),
        "subj_perfecto" to listOf("haya", "hayas", "haya", "hayamos", "hayáis", "hayan"),
        "subj_pluscuam" to listOf("hubiera", "hubieras", "hubiera", "hubiéramos", "hubierais", "hubieran")
    )

    /** Changements d'orthographe des verbes réguliers devant e (car, gar, zar) ou a / o (ger, gir, guir, consonne + cer). */
    private fun ortho(stem: String, next: Char, group: String): String = when {
        group == "ar" && next in "eé" && stem.endsWith("gu") -> stem.dropLast(1) + "ü"
        group == "ar" && next in "eé" && stem.endsWith("c") -> stem.dropLast(1) + "qu"
        group == "ar" && next in "eé" && stem.endsWith("g") -> stem + "u"
        group == "ar" && next in "eé" && stem.endsWith("z") -> stem.dropLast(1) + "c"
        group != "ar" && next in "aoáó" && stem.endsWith("gu") -> stem.dropLast(1)
        group != "ar" && next in "aoáó" && stem.endsWith("g") -> stem.dropLast(1) + "j"
        group != "ar" && next in "aoáó" && stem.endsWith("c") && stem.length > 1 && stem[stem.length - 2] !in "aeiouáéíóú" -> stem.dropLast(1) + "z"
        else -> stem
    }

    private fun regular(inf: String): ConjTable {
        val group = inf.takeLast(2).replace("ír", "ir")
        val stem = inf.dropLast(2)
        val f = HashMap<String, List<String>>()
        f["presente"] = END["presente"]!![group]!!.mapIndexed { i, e -> (if (i == 0) ortho(stem, 'o', group) else stem) + e }
        f["imperfecto"] = END["imperfecto"]!![group]!!.map { stem + it }
        f["indefinido"] = END["indefinido"]!![group]!!.mapIndexed { i, e -> (if (i == 0) ortho(stem, e[0], group) else stem) + e }
        val fut = inf.replace("ír", "ir")
        f["futuro"] = listOf("é", "ás", "á", "emos", "éis", "án").map { fut + it }
        f["condicional"] = listOf("ía", "ías", "ía", "íamos", "íais", "ían").map { fut + it }
        f["subj_presente"] = END["subj"]!![group]!!.map { e -> ortho(stem, e[0], group) + e }
        val third = f["indefinido"]!![5].dropLast(3)
        val acc = mapOf('a' to 'á', 'e' to 'é')
        f["subj_imperfecto"] = listOf("ra", "ras", "ra").map { third + it } + (third.dropLast(1) + (acc[third.last()] ?: third.last()) + "ramos") + listOf("rais", "ran").map { third + it }
        val part = stem + if (group == "ar") "ado" else "ido"
        HABER.forEach { (k, aux) -> f[k] = aux.map { "$it $part" } }
        val sp = f["subj_presente"]!!
        f["imperativo"] = listOf("—", f["presente"]!![2], sp[2], sp[3], fut.dropLast(1) + "d", sp[5])
        f["imperativo_neg"] = listOf("—") + (1..5).map { "no " + sp[it] }
        return ConjTable(
            inf, "", "-$group",
            "Verbe absent de la base : conjugué selon la règle des verbes réguliers en -$group. S'il est irrégulier, certaines formes peuvent être fausses.",
            stem + if (group == "ar") "ando" else "iendo", part,
            tenses.map { m -> ConjTense(m.id, m.name, m.nameEs, m.mood, m.rule, f[m.id] ?: List(6) { "—" }, "") }
        )
    }

    // ------------------------------------------------------------------ verbes pronominaux

    private val PRON = listOf("me", "te", "se", "nos", "os", "se")

    private fun reflexiveOf(t: ConjTable, inf: String, fr: String?): ConjTable {
        val isIr = t.verb == "ir"
        val tenses = t.tenses.map { tense ->
            val forms = tense.forms.mapIndexed { i, f ->
                when {
                    f == "—" -> f
                    tense.id == "imperativo" -> when (i) {
                        1 -> enclitic(f, "te")
                        2, 5 -> enclitic(f, "se")
                        3 -> enclitic(if (f.endsWith("s")) f.dropLast(1) else f, "nos")
                        4 -> when {
                            isIr -> "idos"
                            t.group == "-ir" && f.endsWith("id") -> f.dropLast(2) + "íos"
                            f.endsWith("d") -> f.dropLast(1) + "os"
                            else -> f + "os"
                        }
                        else -> f
                    }
                    tense.id == "imperativo_neg" -> "no ${PRON[i]} " + f.removePrefix("no ")
                    else -> "${PRON[i]} $f"
                }
            }
            tense.copy(forms = forms)
        }
        return t.copy(
            verb = inf, translation = fr ?: t.translation, tenses = tenses,
            gerund = enclitic(t.gerund, "se"),
            note = (t.note + " Verbe pronominal : le pronom (me, te, se, nos, os, se) se place devant le verbe, " +
                "et se colle à la fin à l'impératif affirmatif et au gérondif.").trim()
        )
    }

    private val VOWELS = "aeiouáéíóúü"
    private val STRONG = "aeoáéó"

    /** Ajoute un pronom à la fin d'une forme verbale, avec l'accent écrit si l'accent tonique recule (levanta → levántate). */
    fun enclitic(form: String, pron: String): String {
        if (form.any { it in "áéíóú" }) return form + pron
        val nuclei = mutableListOf<IntRange>()
        var i = 0
        while (i < form.length) {
            val c = form[i]
            val silentU = c == 'u' && i > 0 && (form[i - 1] == 'q' || (form[i - 1] == 'g' && i + 1 < form.length && form[i + 1] in "eiéí"))
            if (c in VOWELS && !silentU) {
                var j = i
                while (j + 1 < form.length && form[j + 1] in VOWELS && !(form[j] in STRONG && form[j + 1] in STRONG)) j++
                nuclei.add(i..j)
                i = j + 1
            } else i++
        }
        val stressedPenult = form.last() in "aeiouns"
        if (nuclei.size < 2 || !stressedPenult) return form + pron
        val n = nuclei[nuclei.size - 2]
        val part = form.substring(n.first, n.last + 1)
        val idx = part.indexOfFirst { it in "aeo" }.let { if (it >= 0) it else part.length - 1 }
        val pos = n.first + idx
        val accented = mapOf('a' to 'á', 'e' to 'é', 'i' to 'í', 'o' to 'ó', 'u' to 'ú')[form[pos]] ?: form[pos]
        return form.substring(0, pos) + accented + form.substring(pos + 1) + pron
    }
}
