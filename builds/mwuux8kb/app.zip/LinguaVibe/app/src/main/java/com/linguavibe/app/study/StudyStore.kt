package com.linguavibe.app.study

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import com.linguavibe.app.data.QuizItem
import com.linguavibe.app.speech.SpokenTexts
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/**
 * Données d'étude, enregistrées sur le téléphone :
 * - révision espacée (cartes des erreurs, qui reviennent après 1, 3, 7, 14, 30 puis 60 jours) ;
 * - statistiques du jour (minutes d'étude, réponses, bonnes réponses) ;
 * - réussite par temps de conjugaison ;
 * - dernière langue étudiée, nom pour les certificats, rappel du mini-quiz.
 */
object StudyStore {
    /** Intervalles en jours selon la « boîte » de la carte (0 = nouvelle erreur). */
    val INTERVALS = intArrayOf(1, 3, 7, 14, 30, 60)
    private const val MAX_CARDS = 2000

    data class Card(
        val id: String,
        val lang: String,
        val front: String,
        val back: String,
        val audio: String,
        val box: Int,
        val due: Long,
        val source: String
    ) {
        val learned: Boolean get() = box >= 3
    }

    data class Day(val day: Long, val minutes: Int, val answers: Int, val correct: Int)

    /** Incrémenté à chaque changement, pour rafraîchir l'interface. */
    var version by mutableIntStateOf(0)
        private set

    private var cards: MutableMap<String, Card>? = null

    private fun sp(context: Context) = context.applicationContext.getSharedPreferences("study", Context.MODE_PRIVATE)

    fun today(): Long {
        val c = Calendar.getInstance()
        return (c.timeInMillis + c.get(Calendar.ZONE_OFFSET) + c.get(Calendar.DST_OFFSET)) / 86_400_000L
    }

    // ------------------------------------------------------------------ révision espacée

    @Synchronized
    private fun cards(context: Context): MutableMap<String, Card> {
        cards?.let { return it }
        val map = LinkedHashMap<String, Card>()
        val raw = sp(context).getString("cards", null)
        if (raw != null) runCatching {
            val a = JSONArray(raw)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val c = Card(
                    o.getString("id"), o.optString("lang", "es"), o.getString("f"), o.getString("b"), o.optString("a"),
                    o.optInt("x"), o.optLong("d"), o.optString("s")
                )
                map[c.id] = c
            }
        }
        cards = map
        return map
    }

    @Synchronized
    private fun saveCards(context: Context) {
        val a = JSONArray()
        cards(context).values.forEach { c ->
            a.put(JSONObject().put("id", c.id).put("lang", c.lang).put("f", c.front).put("b", c.back).put("a", c.audio)
                .put("x", c.box).put("d", c.due).put("s", c.source))
        }
        sp(context).edit().putString("cards", a.toString()).apply()
        version++
    }

    /** Ajoute (ou remet à zéro) une carte à revoir demain. */
    fun addCard(context: Context, lang: String, front: String, back: String, audio: String = "", source: String = "") {
        if (front.isBlank() || back.isBlank()) return
        val id = "$lang|" + (front.trim() + "→" + back.trim()).hashCode().toString(16)
        val map = cards(context)
        map[id] = Card(id, lang, front.trim(), back.trim(), audio.trim(), 0, today() + 1, source)
        if (map.size > MAX_CARDS) {
            // On retire d'abord les cartes les mieux apprises.
            map.values.sortedByDescending { it.box }.take(map.size - MAX_CARDS).forEach { map.remove(it.id) }
        }
        saveCards(context)
    }

    /** Une question de quiz ratée devient une carte de révision. */
    fun addMistake(context: Context, lang: String, item: QuizItem, source: String) {
        val (front, back) = when (item) {
            is QuizItem.Mcq -> item.question to item.correct
            is QuizItem.Typed -> item.prompt to item.answers.first()
            is QuizItem.Listen -> item.phrase to item.correct
            is QuizItem.Order -> item.translation.ifBlank { "Remettez dans l'ordre" } to item.words.joinToString(" ")
            is QuizItem.Fill -> item.sentence to item.sentence.replace("___", item.answers.first())
            is QuizItem.Match -> (item.title.ifBlank { "Associez" }) to item.pairs.joinToString("\n") { "${it.first} = ${it.second}" }
            is QuizItem.Speak -> item.translation.ifBlank { "Dites la phrase" } to item.text
            is QuizItem.Write -> return
        }
        val audio = if (item is QuizItem.Mcq) "" else SpokenTexts.quiz(item).firstOrNull().orEmpty()
        addCard(context, lang, front, back, audio, source)
    }

    fun allCards(context: Context): List<Card> = cards(context).values.toList()

    fun dueCards(context: Context, lang: String? = null): List<Card> {
        val t = today()
        return cards(context).values.filter { it.due <= t && (lang == null || it.lang == lang) }.sortedBy { it.due }
    }

    fun dueCount(context: Context): Int = dueCards(context).size

    /** Réponse à une carte : connue → boîte suivante ; ratée → retour à demain. */
    fun grade(context: Context, card: Card, known: Boolean) {
        val map = cards(context)
        val box = if (known) (card.box + 1).coerceAtMost(INTERVALS.lastIndex) else 0
        map[card.id] = card.copy(box = box, due = today() + INTERVALS[box])
        recordAnswer(context, known)
        saveCards(context)
    }

    fun removeCard(context: Context, card: Card) {
        cards(context).remove(card.id)
        saveCards(context)
    }

    // ------------------------------------------------------------------ statistiques

    private fun dayKey(d: Long) = "day_$d"

    fun dayOf(context: Context, d: Long): Day {
        val parts = (sp(context).getString(dayKey(d), "0|0|0") ?: "0|0|0").split('|').map { it.toIntOrNull() ?: 0 }
        return Day(d, parts.getOrElse(0) { 0 }, parts.getOrElse(1) { 0 }, parts.getOrElse(2) { 0 })
    }

    private fun saveDay(context: Context, day: Day) {
        sp(context).edit().putString(dayKey(day.day), "${day.minutes}|${day.answers}|${day.correct}").apply()
        version++
    }

    fun recordAnswer(context: Context, ok: Boolean) {
        val d = dayOf(context, today())
        saveDay(context, d.copy(answers = d.answers + 1, correct = d.correct + if (ok) 1 else 0))
    }

    fun addMinute(context: Context) {
        val d = dayOf(context, today())
        saveDay(context, d.copy(minutes = d.minutes + 1))
    }

    fun lastDays(context: Context, n: Int): List<Day> {
        val t = today()
        return (n - 1 downTo 0).map { dayOf(context, t - it) }
    }

    /** Jours consécutifs d'étude jusqu'à aujourd'hui (ou hier si rien aujourd'hui). */
    fun studyStreak(context: Context): Int {
        var d = today()
        if (!dayOf(context, d).active) d--
        var n = 0
        while (dayOf(context, d).active) { n++; d-- }
        return n
    }

    private val Day.active: Boolean get() = minutes > 0 || answers > 0

    fun totals(context: Context): Triple<Int, Int, Int> {
        var m = 0; var a = 0; var c = 0
        sp(context).all.forEach { (k, v) ->
            if (k.startsWith("day_") && v is String) {
                val p = v.split('|').map { it.toIntOrNull() ?: 0 }
                m += p.getOrElse(0) { 0 }; a += p.getOrElse(1) { 0 }; c += p.getOrElse(2) { 0 }
            }
        }
        return Triple(m, a, c)
    }

    // ------------------------------------------------------------------ réussite par temps

    fun recordTense(context: Context, tenseId: String, ok: Boolean) {
        val (good, total) = tense(context, tenseId)
        sp(context).edit().putString("tense_$tenseId", "${good + if (ok) 1 else 0}|${total + 1}").apply()
        recordAnswer(context, ok)
    }

    fun tense(context: Context, tenseId: String): Pair<Int, Int> {
        val p = (sp(context).getString("tense_$tenseId", "0|0") ?: "0|0").split('|').map { it.toIntOrNull() ?: 0 }
        return p.getOrElse(0) { 0 } to p.getOrElse(1) { 0 }
    }

    // ------------------------------------------------------------------ divers

    fun lastLang(context: Context): String = sp(context).getString("last_lang", "es") ?: "es"
    fun setLastLang(context: Context, lang: String) { sp(context).edit().putString("last_lang", lang).apply() }

    fun learnerName(context: Context): String = sp(context).getString("name", "") ?: ""
    fun setLearnerName(context: Context, name: String) { sp(context).edit().putString("name", name.trim()).apply() }

    /** Meilleur score à l'examen de [level] dans la langue [lang]. */
    fun examScore(context: Context, lang: String, level: String): Int = sp(context).getInt("exam_${lang}_$level", -1)
    fun saveExam(context: Context, lang: String, level: String, score: Int) {
        if (score > examScore(context, lang, level)) sp(context).edit().putInt("exam_${lang}_$level", score).apply()
        version++
    }
}
