package com.linguavibe.app.speech

import android.content.Context
import com.k2fsa.sherpa.onnx.GenerationConfig
import com.k2fsa.sherpa.onnx.OfflineTts
import com.k2fsa.sherpa.onnx.OfflineTtsConfig
import com.k2fsa.sherpa.onnx.OfflineTtsModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsSupertonicModelConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest

/** Synthèse Supertonic 3 : le texte est généré localement, sans appel réseau. */
object SupertonicTts {
    private val lock = Any()
    private var engine: OfflineTts? = null
    private var loadedPath: String? = null
    private val languages = setOf("en", "es", "pt", "fr", "ru", "zh", "ar")

    suspend fun speechFile(context: Context, text: String, language: String, speakerId: Int, speed: Float): File = withContext(Dispatchers.Default) {
        require(language in languages) { "Langue non prise en charge par Supertonic 3 : $language" }
        check(SupertonicVoiceManager.isInstalled(context)) { "Installez d'abord le modèle vocal Supertonic 3 dans les paramètres." }
        val model = SupertonicVoiceManager.modelDir(context)
        val hash = sha1("$language|$speakerId|$speed|${text.trim()}")
        val cache = File(context.filesDir, "tts-supertonic/cache").apply { mkdirs() }
        val output = File(cache, "$hash.wav")
        if (output.length() > 512L) return@withContext output
        synchronized(lock) {
            if (engine == null || loadedPath != model.absolutePath) {
                engine?.release()
                val m = OfflineTtsSupertonicModelConfig(
                    durationPredictor = File(model, "duration_predictor.int8.onnx").absolutePath,
                    textEncoder = File(model, "text_encoder.int8.onnx").absolutePath,
                    vectorEstimator = File(model, "vector_estimator.int8.onnx").absolutePath,
                    vocoder = File(model, "vocoder.int8.onnx").absolutePath,
                    ttsJson = File(model, "tts.json").absolutePath,
                    unicodeIndexer = File(model, "unicode_indexer.bin").absolutePath,
                    voiceStyle = File(model, "voice.bin").absolutePath
                )
                val config = OfflineTtsConfig(model = OfflineTtsModelConfig(supertonic = m, numThreads = 2, debug = false))
                engine = OfflineTts(config = config)
                loadedPath = model.absolutePath
            }
            val gen = GenerationConfig(sid = speakerId.coerceIn(0, 9), speed = speed.coerceIn(0.5f, 1.5f), numSteps = 8, extra = mapOf("lang" to language))
            val audio = engine!!.generateWithConfig(text.trim(), gen)
            audio.save(output.absolutePath)
        }
        check(output.length() > 512L) { "La synthèse vocale n'a pas produit de fichier audio." }
        output
    }

    fun clearCache(context: Context) = File(context.filesDir, "tts-supertonic/cache").deleteRecursively()
    fun cacheSizeMb(context: Context): Long = (File(context.filesDir, "tts-supertonic/cache").walkTopDown().filter { it.isFile }.sumOf { it.length() } / (1024 * 1024))
    fun release() = synchronized(lock) { engine?.release(); engine = null; loadedPath = null }

    private fun sha1(value: String) = MessageDigest.getInstance("SHA-1").digest(value.toByteArray()).joinToString("") { "%02x".format(it) }
}
