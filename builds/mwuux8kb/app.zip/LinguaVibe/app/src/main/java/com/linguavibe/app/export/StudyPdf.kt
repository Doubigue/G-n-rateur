package com.linguavibe.app.export

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import java.io.OutputStream
import java.text.DateFormat
import java.util.Date

/** PDF simples des outils d'étude : fiches de révision par temps et certificat d'examen. */
object StudyPdf {
    private const val W = 595
    private const val H = 842
    private const val M = 48f
    private val NAVY = Color.rgb(0x14, 0x21, 0x5B)
    private val GOLD = Color.rgb(0xF5, 0xB8, 0x00)
    private val INK = Color.rgb(0x10, 0x1A, 0x3A)
    private val SOFT = Color.rgb(0x5D, 0x63, 0x80)

    private fun paint(size: Float, color: Int, bold: Boolean = false) = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = size; this.color = color
        typeface = Typeface.create(Typeface.SANS_SERIF, if (bold) Typeface.BOLD else Typeface.NORMAL)
    }

    private fun layout(text: String, p: TextPaint, width: Int, align: Layout.Alignment = Layout.Alignment.ALIGN_NORMAL) =
        StaticLayout.Builder.obtain(text, 0, text.length, p, width).setAlignment(align).setLineSpacing(2f, 1f).build()

    /** Une section de fiche : titre et lignes de texte. */
    data class Block(val title: String, val lines: List<String>)

    /** Une fiche : nom du temps, sous-titre et blocs. */
    data class Sheet(val title: String, val subtitle: String, val blocks: List<Block>)

    fun sheets(sheets: List<Sheet>, footer: String, out: OutputStream) {
        val doc = PdfDocument()
        var pageNo = 0
        var page: PdfDocument.Page? = null
        var canvas: Canvas? = null
        var y = 0f
        val cw = (W - 2 * M).toInt()

        fun finish() {
            page?.let { p ->
                val c = p.canvas
                c.drawText("$footer · page $pageNo", M, H - 24f, paint(9f, SOFT))
                doc.finishPage(p)
            }
            page = null
        }

        fun newPage() {
            finish()
            pageNo++
            page = doc.startPage(PdfDocument.PageInfo.Builder(W, H, pageNo).create())
            canvas = page!!.canvas
            canvas!!.drawRect(0f, 0f, W.toFloat(), 8f, Paint().apply { color = GOLD })
            y = M
        }

        fun put(l: StaticLayout, x: Float = M) {
            if (y + l.height > H - 50f) newPage()
            canvas!!.save(); canvas!!.translate(x, y); l.draw(canvas!!); canvas!!.restore()
            y += l.height
        }

        newPage()
        sheets.forEachIndexed { i, s ->
            if (i > 0) newPage()
            val head = layout(s.title, paint(24f, Color.WHITE, true), cw - 24)
            val sub = layout(s.subtitle, paint(12f, GOLD, true), cw - 24)
            val h = head.height + sub.height + 24f
            canvas!!.drawRoundRect(RectF(M, y, W - M, y + h), 14f, 14f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = NAVY })
            y += 12f
            put(head, M + 12f); put(sub, M + 12f)
            y += 22f
            s.blocks.forEach { b ->
                val t = layout(b.title.uppercase(), paint(11f, NAVY, true), cw)
                if (y + t.height + 30f > H - 50f) newPage()
                put(t); y += 4f
                canvas!!.drawRect(M, y, M + 40f, y + 2f, Paint().apply { color = GOLD })
                y += 8f
                b.lines.forEach { line -> put(layout(line, paint(11.5f, INK), cw)); y += 3f }
                y += 12f
            }
        }
        finish()
        doc.writeTo(out)
        doc.close()
    }

    /** Certificat de réussite d'un examen de niveau (format paysage). */
    fun certificate(name: String, languageName: String, level: String, levelLabel: String, score: Int, out: OutputStream) {
        val doc = PdfDocument()
        val pw = H; val ph = W
        val page = doc.startPage(PdfDocument.PageInfo.Builder(pw, ph, 1).create())
        val c = page.canvas
        val bg = Paint().apply { color = Color.rgb(0xF7, 0xF4, 0xEC) }
        c.drawRect(0f, 0f, pw.toFloat(), ph.toFloat(), bg)
        val frame = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 10f; color = NAVY }
        c.drawRect(22f, 22f, pw - 22f, ph - 22f, frame)
        frame.strokeWidth = 2f; frame.color = GOLD
        c.drawRect(38f, 38f, pw - 38f, ph - 38f, frame)

        fun centered(text: String, p: TextPaint, top: Float): Float {
            val l = layout(text, p, pw - 160, Layout.Alignment.ALIGN_CENTER)
            c.save(); c.translate(80f, top); l.draw(c); c.restore()
            return top + l.height
        }

        var y = 70f
        y = centered("LINGUAVIBE", paint(14f, GOLD, true), y) + 10f
        y = centered("Certificat de réussite", paint(38f, NAVY, true), y) + 22f
        y = centered("Ce certificat est décerné à", paint(14f, SOFT), y) + 8f
        y = centered(name.ifBlank { "l'apprenant" }, paint(32f, INK, true), y) + 6f
        c.drawRect(pw / 2f - 140f, y, pw / 2f + 140f, y + 2f, Paint().apply { color = GOLD })
        y += 18f
        y = centered("pour avoir réussi l'examen de niveau $level ($levelLabel) en $languageName", paint(16f, INK), y) + 6f
        y = centered("avec un score de $score %", paint(16f, NAVY, true), y) + 30f
        // Sceau
        val cx = pw - 140f; val cy = ph - 130f
        c.drawCircle(cx, cy, 52f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = GOLD })
        c.drawCircle(cx, cy, 44f, Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f; color = Color.WHITE })
        val seal = paint(26f, NAVY, true).apply { textAlign = Paint.Align.CENTER }
        c.drawText(level, cx, cy + 9f, seal)
        val date = DateFormat.getDateInstance(DateFormat.LONG).format(Date())
        c.drawText("Délivré le $date", 80f, ph - 110f, paint(12f, SOFT))
        c.drawText("Examen passé dans l'application LinguaVibe (cadre européen A1 à C2).", 80f, ph - 90f, paint(10f, SOFT))
        doc.finishPage(page)
        doc.writeTo(out)
        doc.close()
    }
}
