package com.linguavibe.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linguavibe.app.data.ConjTense
import com.linguavibe.app.data.Conjugator
import com.linguavibe.app.data.Languages
import com.linguavibe.app.export.StudyPdf
import com.linguavibe.app.study.StudyStore

private val SheetColor = Color(0xFF1E6F8E)
private val PERS = listOf("yo", "tú", "él / ella / usted", "nosotros", "vosotros", "ellos / ellas / ustedes")
private val PERS_IMP = listOf("", "tú", "usted", "nosotros", "vosotros", "ustedes")

/** Verbes utilisés pour les modèles, les irréguliers et l'entraînement (les plus fréquents). */
private val COMMON = listOf(
    "ser", "estar", "ir", "tener", "hacer", "poder", "decir", "poner", "venir", "querer", "saber", "dar", "ver", "salir",
    "pedir", "dormir", "conocer", "traer", "oír", "jugar", "volver", "pensar", "empezar", "seguir", "sentir", "conducir",
    "caer", "andar", "elegir", "construir", "morir", "leer", "hablar", "comer", "vivir", "trabajar", "estudiar", "aprender",
    "escribir", "abrir", "llegar", "buscar", "pagar", "llamar", "mirar", "beber", "correr", "recibir", "cerrar", "encontrar"
)

private fun persons(t: ConjTense) = if (t.isImperative) PERS_IMP else PERS

/** Contenu d'une fiche, partagé par l'écran et le PDF. */
private class SheetData(val tense: ConjTense, val models: List<Pair<String, List<String>>>, val irregular: List<Pair<String, String>>)

private fun sheetData(context: android.content.Context, index: Int): SheetData? {
    val models = listOf("hablar", "comer", "vivir").mapNotNull { v ->
        Conjugator.conjugate(context, v)?.table?.tenses?.getOrNull(index)?.let { v to it.forms }
    }
    val tense = Conjugator.conjugate(context, "hablar")?.table?.tenses?.getOrNull(index) ?: return null
    val irregular = COMMON.mapNotNull { v ->
        val t = Conjugator.conjugate(context, v)?.table?.tenses?.getOrNull(index) ?: return@mapNotNull null
        if (t.irregular.contains('1')) v to t.forms.filter { it != "—" }.joinToString(", ") else null
    }.take(14)
    return SheetData(tense, models, irregular)
}

/** Liste des 15 temps, regroupés par mode, avec le taux de réussite à l'entraînement. */
@Composable
fun TenseSheetsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val tenses = remember { Conjugator.tenses(context) }
    var open by remember { mutableStateOf<Int?>(null) }
    val exportPdf = rememberPdfExporter()
    open?.let { i ->
        TenseSheet(i, onBack = { open = null })
        return
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopBar("Fiches par temps", "Règles, terminaisons, irréguliers", SheetColor, onBack, action = {
            PdfTopButton {
                exportPdf("LinguaVibe_fiches_conjugaison.pdf") { out ->
                    val sheets = tenses.indices.mapNotNull { sheetData(context, it)?.let(::pdfSheet) }
                    StudyPdf.sheets(sheets, "LinguaVibe · Fiches de conjugaison espagnole", out)
                }
            }
        })
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Une fiche par temps : formation, emploi, modèles -ar / -er / -ir, verbes irréguliers les plus courants, puis un entraînement de 10 formes.",
                fontSize = 13.sp, color = InkSoft)
            tenses.groupBy { it.mood }.forEach { (mood, list) ->
                Text(mood.uppercase(), fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.2.sp, color = SheetColor,
                    modifier = Modifier.padding(top = 6.dp))
                list.forEach { t ->
                    val i = tenses.indexOf(t)
                    val (good, total) = remember(StudyStore.version, t.id) { StudyStore.tense(context, t.id) }
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color.White).clickable { open = i }.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(SheetColor.copy(alpha = 0.12f)), contentAlignment = Alignment.Center) {
                            Text("${i + 1}", fontWeight = FontWeight.ExtraBold, color = SheetColor)
                        }
                        Column(Modifier.weight(1f)) {
                            Text(t.name, style = PosterTitle, fontSize = 16.sp, color = Ink)
                            Text(t.nameEs, style = AccentText, fontSize = 13.sp, color = SheetColor)
                        }
                        Text(if (total == 0) "Nouveau" else "${good * 100 / total} %", fontSize = 13.sp, fontWeight = FontWeight.Bold,
                            color = when { total == 0 -> InkSoft; good * 100 / total >= 70 -> Good; else -> Bad })
                    }
                }
            }
        }
    }
}

private fun pdfSheet(d: SheetData): StudyPdf.Sheet {
    val t = d.tense
    val p = persons(t)
    return StudyPdf.Sheet(
        "${t.name} · ${t.nameEs}", t.mood,
        listOf(
            StudyPdf.Block("Règle", listOf(t.rule)),
            StudyPdf.Block("Modèles réguliers", p.indices.mapNotNull { i ->
                val forms = d.models.map { it.second.getOrElse(i) { "—" } }
                if (forms.all { it == "—" }) null else "${p[i].ifBlank { "—" }} : ${forms.joinToString("  |  ")}"
            }.let { listOf("hablar  |  comer  |  vivir") + it }),
            StudyPdf.Block("Irréguliers fréquents", d.irregular.map { "${it.first} : ${it.second}" }.ifEmpty { listOf("Pas d'irrégularité propre à ce temps parmi les verbes courants.") })
        )
    )
}

@Composable
private fun TenseSheet(index: Int, onBack: () -> Unit) {
    val context = LocalContext.current
    val speaker = LocalSpeaker.current
    val es = remember { Languages.byCode("es") }
    val data = remember(index) { sheetData(context, index) }
    var drill by remember(index) { mutableStateOf(false) }
    val exportPdf = rememberPdfExporter()
    if (data == null) { Text("Fiche indisponible.", Modifier.padding(24.dp), color = InkSoft); return }
    val t = data.tense
    if (drill) {
        TenseDrill(index, t, onBack = { drill = false })
        return
    }
    val p = persons(t)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopBar(t.name, "${t.nameEs} · ${t.mood}", SheetColor, onBack, action = {
            PdfTopButton {
                exportPdf("LinguaVibe_fiche_${t.id}.pdf") { out -> StudyPdf.sheets(listOf(pdfSheet(data)), "LinguaVibe · Fiche de conjugaison", out) }
            }
        })
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(GridGap)) {
            CardBox {
                Text("Règle", style = PosterTitle, fontSize = 17.sp, color = Ink)
                Text(t.rule, fontSize = 14.sp, lineHeight = 20.sp, color = Ink)
            }
            CardBox {
                Text("Modèles réguliers", style = PosterTitle, fontSize = 17.sp, color = Ink)
                Row {
                    Spacer(Modifier.weight(0.9f))
                    data.models.forEach { Text(it.first, Modifier.weight(1f), fontWeight = FontWeight.ExtraBold, color = SheetColor, fontSize = 13.sp) }
                }
                p.indices.forEach { i ->
                    if (data.models.all { it.second.getOrElse(i) { "—" } == "—" }) return@forEach
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(if (i % 2 == 0) SheetColor.copy(alpha = 0.06f) else Color.Transparent).padding(vertical = 4.dp)) {
                        Text(p[i], Modifier.weight(0.9f), fontSize = 12.sp, color = InkSoft)
                        data.models.forEach { (_, forms) ->
                            val f = forms.getOrElse(i) { "—" }
                            Text(f, Modifier.weight(1f).clickable { speaker.speak(f, es.locale) }, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Ink)
                        }
                    }
                }
                Text("Touchez une forme pour l'écouter.", fontSize = 12.sp, color = InkSoft)
            }
            CardBox {
                Text("Irréguliers fréquents", style = PosterTitle, fontSize = 17.sp, color = Ink)
                if (data.irregular.isEmpty()) Text("Pas d'irrégularité propre à ce temps parmi les verbes courants.", fontSize = 13.sp, color = InkSoft)
                data.irregular.forEach { (v, forms) ->
                    Column(Modifier.fillMaxWidth().clickable { speaker.speak(forms.replace(",", ""), es.locale) }) {
                        Text(v, fontWeight = FontWeight.ExtraBold, color = Bad, fontSize = 14.sp)
                        Text(forms, fontSize = 13.sp, color = Ink)
                    }
                }
            }
            PillButton("M'entraîner : 10 formes", Art.icQuiz, SheetColor, Modifier.fillMaxWidth(), big = true) { drill = true }
            val open = LocalOpenConjugator.current
            PillButton("Ouvrir le conjugueur", Art.icBook, SheetColor, Modifier.fillMaxWidth(), filled = false) { open("") }
        }
    }
}

/** Entraînement : 10 formes à écrire (verbe + personne), comptées dans la réussite par temps. */
@Composable
private fun TenseDrill(index: Int, tense: ConjTense, onBack: () -> Unit) {
    val context = LocalContext.current
    val speaker = LocalSpeaker.current
    val es = remember { Languages.byCode("es") }
    var round by remember { mutableIntStateOf(0) }
    val questions = remember(round) {
        COMMON.shuffled().mapNotNull { v ->
            val t = Conjugator.conjugate(context, v)?.table ?: return@mapNotNull null
            val forms = t.tenses.getOrNull(index)?.forms ?: return@mapNotNull null
            val i = forms.indices.filter { forms[it] != "—" && forms[it].isNotBlank() }.randomOrNull() ?: return@mapNotNull null
            Triple("$v (${t.translation})", i, forms[i])
        }.take(10)
    }
    var q by remember(round) { mutableIntStateOf(0) }
    var good by remember(round) { mutableIntStateOf(0) }
    var input by remember(round, q) { mutableStateOf("") }
    var verdict by remember(round, q) { mutableStateOf<Boolean?>(null) }
    val p = persons(tense)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopBar("Entraînement", "${tense.name} · ${tense.nameEs}", SheetColor, onBack)
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (q >= questions.size) {
                ScoreRing(good * 100 / questions.size.coerceAtLeast(1), 110.dp)
                Text("$good / ${questions.size} formes justes", style = PosterTitle, fontSize = 22.sp, color = Ink,
                    modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                Text("Les formes ratées sont ajoutées à votre révision du jour.", fontSize = 13.sp, color = InkSoft,
                    modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                PillButton("Encore 10 formes", Art.icRefresh, SheetColor, Modifier.fillMaxWidth()) { round++ }
                PillButton("Retour à la fiche", Art.icBook, SheetColor, Modifier.fillMaxWidth(), filled = false) { onBack() }
                return@Column
            }
            val (verb, person, answer) = questions[q]
            AnimatedBar(q.toFloat() / questions.size, SheetColor)
            Text("Forme ${q + 1} / ${questions.size}", fontSize = 13.sp, color = InkSoft)
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Color.White).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(verb, style = PosterTitle, fontSize = 24.sp, color = Ink)
                Text("${p[person].ifBlank { "—" }} · ${tense.name}", style = AccentText, fontSize = 16.sp, color = SheetColor)
            }
            OutlinedTextField(
                value = input, onValueChange = { input = it }, enabled = verdict == null, singleLine = true,
                modifier = Modifier.fillMaxWidth(), label = { Text("Forme conjuguée") }
            )
            if (verdict == null) {
                PillButton("Valider", Art.icCheck, SheetColor, Modifier.fillMaxWidth(), enabled = input.isNotBlank()) {
                    val typed = input.trim().lowercase().replace(Regex("\\s+"), " ")
                    val ok = Conjugator.fold(typed) == Conjugator.fold(answer)
                    verdict = ok
                    if (ok) good++ else StudyStore.addCard(context, "es", "$verb · ${p[person].ifBlank { "—" }} · ${tense.name}", answer, answer, "Conjugaison")
                    StudyStore.recordTense(context, tense.id, ok)
                    speaker.speak(answer, es.locale)
                }
            } else {
                val exact = input.trim().lowercase() == answer.lowercase()
                Text(
                    when {
                        verdict == true && exact -> "✔ Juste : $answer"
                        verdict == true -> "✔ Juste, attention aux accents : $answer"
                        else -> "✘ La bonne forme : $answer"
                    },
                    fontSize = 17.sp, fontWeight = FontWeight.Bold, color = if (verdict == true) Good else Bad
                )
                if (verdict == false) Text("Relisez la fiche : ${tense.rule.take(140)}…", fontSize = 12.sp, fontStyle = FontStyle.Italic, color = InkSoft)
                PillButton(if (q >= questions.lastIndex) "Voir le résultat" else "Suivant", Art.icPlay, SheetColor, Modifier.fillMaxWidth()) { q++ }
            }
        }
    }
}
