package com.linguavibe.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linguavibe.app.data.CourseRepository
import com.linguavibe.app.data.LanguageInfo
import com.linguavibe.app.data.Languages
import com.linguavibe.app.data.Levels
import com.linguavibe.app.data.ProgressStore
import com.linguavibe.app.data.QuizItem
import com.linguavibe.app.export.StudyPdf
import com.linguavibe.app.study.StudyStore

private val ExamColor = Color(0xFF7A5A00)
private const val EXAM_SIZE = 30

/** Questions de l'examen : toutes les leçons du niveau, dans tous les parcours de la langue (sans oral ni rédaction). */
private fun examItems(context: android.content.Context, lang: String, level: String): List<QuizItem> {
    val models = if (lang == "es") listOf("model1", "model2", "model3", "model4") else listOf("model1")
    val lessons = models.flatMap { m -> runCatching { CourseRepository.load(context, lang, m).lessons }.getOrDefault(emptyList()) }
        .filter { it.level.equals(level, ignoreCase = true) }
    val pool = lessons.flatMap { it.quiz }.filter { it !is QuizItem.Speak && it !is QuizItem.Write && it.isValid }
    // Mélange équilibré : on tire tour à tour dans chaque type de question.
    val byKind = pool.shuffled().groupBy { it.kind }.mapValues { it.value.toMutableList() }
    val out = ArrayList<QuizItem>()
    while (out.size < EXAM_SIZE && byKind.values.any { it.isNotEmpty() }) {
        byKind.values.shuffled().forEach { if (it.isNotEmpty() && out.size < EXAM_SIZE) out.add(it.removeAt(0)) }
    }
    return out.shuffled()
}

/** Examens de fin de niveau A1 à C2, avec certificat PDF à partir de 70 %. */
@Composable
fun ExamScreen(progress: ProgressStore, onBack: () -> Unit) {
    val context = LocalContext.current
    var lang by remember { mutableStateOf(Languages.byCode(StudyStore.lastLang(context))) }
    var level by remember { mutableStateOf<String?>(null) }
    val current = level
    if (current != null) {
        ExamRun(lang, current, progress, onBack = { level = null })
        return
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopBar("Examens de niveau", "A1 à C2 · certificat PDF", ExamColor, onBack)
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("$EXAM_SIZE questions tirées de toutes les leçons du niveau. Il faut ${ProgressStore.PASS_SCORE} % pour réussir et recevoir un certificat.",
                fontSize = 13.sp, color = InkSoft)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Languages.courses.filter { it.available }.forEach { l ->
                    Box(
                        Modifier.clip(RoundedCornerShape(14.dp)).background(if (l.code == lang.code) ExamColor.copy(alpha = 0.18f) else Color.White)
                            .clickable { lang = l }.padding(horizontal = 10.dp, vertical = 8.dp)
                    ) { Text("${l.flag}", fontSize = 22.sp) }
                }
            }
            Text(lang.name, style = PosterTitle, fontSize = 20.sp, color = Ink)
            Levels.order.forEach { lv ->
                val best = remember(StudyStore.version, lang.code, lv) { StudyStore.examScore(context, lang.code, lv) }
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color.White).clickable { level = lv }.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(ExamColor.copy(alpha = 0.12f)), contentAlignment = Alignment.Center) {
                        Text(lv, fontWeight = FontWeight.ExtraBold, color = ExamColor, fontSize = 18.sp)
                    }
                    Column(Modifier.weight(1f)) {
                        Text("Examen $lv · ${Levels.label(lv)}", style = PosterTitle, fontSize = 16.sp, color = Ink)
                        Text(
                            when {
                                best < 0 -> "Pas encore passé"
                                best >= ProgressStore.PASS_SCORE -> "Réussi ($best %) · certificat disponible"
                                else -> "Meilleur score : $best %"
                            },
                            fontSize = 12.sp, color = if (best >= ProgressStore.PASS_SCORE) Good else InkSoft
                        )
                    }
                    if (best >= ProgressStore.PASS_SCORE) Text("🏅", fontSize = 22.sp)
                }
            }
        }
    }
}

@Composable
private fun ExamRun(lang: LanguageInfo, level: String, progress: ProgressStore, onBack: () -> Unit) {
    val context = LocalContext.current
    val items = remember(lang.code, level) { examItems(context, lang.code, level) }
    var index by remember { mutableIntStateOf(0) }
    var correct by remember { mutableIntStateOf(0) }
    var finished by remember { mutableStateOf(false) }
    val exportPdf = rememberPdfExporter()

    if (items.size < 10) {
        Column(Modifier.fillMaxSize()) {
            TopBar("Examen $level", lang.name, ExamColor, onBack)
            Text("Pas encore assez de leçons de niveau $level en ${lang.name.lowercase()} pour un examen.", Modifier.padding(20.dp), color = InkSoft)
        }
        return
    }
    if (finished) {
        val score = correct * 100 / items.size
        val passed = score >= ProgressStore.PASS_SCORE
        var name by remember { mutableStateOf(StudyStore.learnerName(context)) }
        Box(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                TopBar("Résultat · $level", lang.name, ExamColor, onBack)
                Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    ScoreRing(score, 130.dp)
                    Text(if (passed) "Examen $level réussi !" else "Examen non validé", style = PosterTitle, fontSize = 26.sp, color = Ink)
                    Text("$correct bonnes réponses sur ${items.size}.", fontSize = 15.sp, color = InkSoft, textAlign = TextAlign.Center)
                    if (passed) {
                        OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("Votre nom sur le certificat") }, singleLine = true)
                        PillButton("Télécharger mon certificat (PDF)", Art.icDownload, ExamColor, Modifier.fillMaxWidth(), big = true) {
                            StudyStore.setLearnerName(context, name)
                            exportPdf("Certificat_LinguaVibe_${lang.code}_$level.pdf") { out ->
                                StudyPdf.certificate(name, lang.name.lowercase(), level, Levels.label(level), score, out)
                            }
                        }
                    } else {
                        Text("Il faut ${ProgressStore.PASS_SCORE} %. Vos erreurs sont dans la révision du jour : revoyez-les puis retentez l'examen.",
                            fontSize = 14.sp, color = InkSoft, textAlign = TextAlign.Center)
                    }
                    PillButton("Retour aux examens", Art.icPlay, ExamColor, Modifier.fillMaxWidth(), filled = false) { onBack() }
                }
            }
            if (passed) Confetti()
        }
        return
    }
    Column(Modifier.fillMaxSize()) {
        TopBar("Examen $level", "${lang.name} · question ${index + 1} / ${items.size}", ExamColor, onBack)
        Column(Modifier.weight(1f).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            AnimatedBar(index.toFloat() / items.size, ExamColor)
            val item = items[index]
            QuizQuestion(
                item = item, lang = lang, color = ExamColor, key = "exam-${lang.code}-$level-$index",
                modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()),
                onAnswered = { ok ->
                    StudyStore.recordAnswer(context, ok)
                    if (ok) correct++ else StudyStore.addMistake(context, lang.code, item, "Examen $level")
                },
                continueLabel = if (index >= items.lastIndex) "Voir le résultat" else "Continuer",
                onContinue = {
                    if (index >= items.lastIndex) {
                        val score = correct * 100 / items.size
                        StudyStore.saveExam(context, lang.code, level, score)
                        progress.addXp(if (score >= ProgressStore.PASS_SCORE) 100 else 20)
                        finished = true
                    } else index++
                }
            )
        }
    }
}
