package com.linguavibe.app.ui

import android.os.StatFs
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linguavibe.app.data.LanguageInfo
import com.linguavibe.app.data.Languages
import com.linguavibe.app.speech.ChineseVoiceManager
import com.linguavibe.app.speech.LangDownloads
import com.linguavibe.app.speech.LangStorage
import com.linguavibe.app.speech.SupertonicVoiceManager
import com.linguavibe.app.speech.VoicePacks
import com.linguavibe.app.speech.VoskManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val OfflineColor = Color(0xFF2D6A4F)

/** Taille moyenne d'une phrase enregistrée (MP3), pour estimer la place des packs audio. */
private const val KB_PER_PHRASE = 14
private const val SUPERTONIC_MB = 120
private const val CHINESE_MB = 130

/** Un élément à télécharger pour être 100 % hors ligne. */
private data class Piece(val label: String, val sizeMb: Int, val installed: Boolean, val start: () -> Unit)

private fun sizeToMb(size: String): Int {
    val n = size.filter { it.isDigit() || it == ',' || it == '.' }.replace(',', '.').toDoubleOrNull() ?: return 50
    return if (size.contains("Go")) (n * 1024).toInt() else n.toInt()
}

/** Écran « Tout télécharger » : micro, voix hors ligne et audios d'une langue en un seul bouton. */
@Composable
fun OfflineScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val startDownload = rememberDownloadStarter()
    var refresh by remember { mutableIntStateOf(0) }
    val freeMb = remember(refresh) {
        runCatching { StatFs(LangStorage.root(context).absolutePath).availableBytes / (1024 * 1024) }.getOrDefault(-1L)
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopBar("Tout télécharger", "Une langue 100 % hors ligne", OfflineColor, onBack)
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(GridGap)) {
            CardBox {
                Text("Un bouton par langue télécharge en arrière-plan le micro (modèle léger), la voix hors ligne et tous les audios " +
                    "des cours. La place nécessaire est indiquée avant. Les fichiers vont dans le dossier « ${LangStorage.FOLDER} ».",
                    fontSize = 13.sp, color = InkSoft)
                Text(if (freeMb >= 0) "Espace libre sur le téléphone : ${mb(freeMb.toInt())}" else "Espace libre inconnu",
                    fontWeight = FontWeight.Bold, color = Ink, fontSize = 14.sp)
            }
            DurableStorageCard()
            Languages.all.filter { it.available || it.native }.forEach { lang ->
                LanguageOfflineCard(lang, freeMb, startDownload) { refresh++ }
            }
        }
    }
}

@Composable
private fun LanguageOfflineCard(lang: LanguageInfo, freeMb: Long, startDownload: (() -> Unit) -> Unit, onStarted: () -> Unit) {
    val context = LocalContext.current
    val voskVersion = VoskManager.installsVersion
    var pieces by remember(lang.code, voskVersion) { mutableStateOf<List<Piece>?>(null) }
    LaunchedEffect(lang.code, voskVersion) {
        pieces = withContext(Dispatchers.IO) {
            buildList {
                if (!lang.native) {
                    val light = lang.models.last()
                    add(Piece("Micro (${light.name})", sizeToMb(light.size), VoskManager.isInstalled(context, lang.code)) {
                        LangDownloads.enqueue(context, LangDownloads.KIND_VOSK, lang.code, light.url, replace = true)
                    })
                }
                if (lang.code == "zh") {
                    add(Piece("Voix chinoise hors ligne", CHINESE_MB, ChineseVoiceManager.isInstalled(context)) {
                        LangDownloads.enqueue(context, LangDownloads.KIND_ZH)
                    })
                } else {
                    add(Piece("Voix hors ligne Supertonic (toutes langues)", SUPERTONIC_MB, SupertonicVoiceManager.isInstalled(context)) {
                        LangDownloads.enqueue(context, LangDownloads.KIND_SUPERTONIC)
                    })
                }
                VoicePacks.packs().filter { VoicePacks.voiceOf(it.id) == lang.code }.forEach { p ->
                    val missing = runCatching { VoicePacks.countMissing(context, p.id) }.getOrDefault(0)
                    add(Piece("Audios · ${p.title} ($missing phrases)", (missing * KB_PER_PHRASE + 1023) / 1024, missing == 0) {
                        VoicePacks.start(context, p.id)
                    })
                }
            }
        }
    }
    CardBox {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(lang.flag, fontSize = 26.sp)
            Spacer(Modifier.width(10.dp))
            Text(lang.name, style = PosterTitle, fontSize = 18.sp, color = Ink, modifier = Modifier.weight(1f))
        }
        val list = pieces
        if (list == null) {
            Text("Calcul de la place nécessaire…", fontSize = 12.sp, color = InkSoft)
            LinearProgressIndicator(Modifier.fillMaxWidth())
            return@CardBox
        }
        list.forEach { p ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (p.installed) "✔" else "•", color = if (p.installed) Good else InkSoft, fontWeight = FontWeight.Bold, modifier = Modifier.width(18.dp))
                Text(p.label, fontSize = 13.sp, color = Ink, modifier = Modifier.weight(1f))
                Text(if (p.installed) "installé" else "≈ ${mb(p.sizeMb)}", fontSize = 12.sp, color = if (p.installed) Good else InkSoft)
            }
        }
        val need = list.filter { !it.installed }.sumOf { it.sizeMb }
        if (need == 0) {
            Text("Tout est prêt hors ligne pour cette langue.", color = Good, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        } else {
            val enough = freeMb < 0 || freeMb > need + 200
            Text("À télécharger : ≈ ${mb(need)}" + if (!enough) " · place insuffisante, libérez de l'espace." else "",
                fontSize = 13.sp, fontWeight = FontWeight.Bold, color = if (enough) Ink else Bad)
            PillButton("Tout télécharger (${mb(need)})", Art.icDownload, OfflineColor, Modifier.fillMaxWidth(), enabled = enough) {
                startDownload {
                    list.filter { !it.installed }.forEach { it.start() }
                    onStarted()
                }
            }
            Text("Le téléchargement continue en arrière-plan, même appli fermée. Suivez-le dans la notification.", fontSize = 11.5.sp, color = InkSoft)
        }
        LangDownloads.states.filterKeys { k -> k.substringAfter(':').substringBefore(':') == lang.code || k == "${LangDownloads.KIND_SUPERTONIC}:" }.forEach { (k, s) ->
            if (s.running || s.error != null) {
                Text("${LangDownloads.title(k.substringBefore(':'), k.substringAfter(':'))} : ${s.error ?: s.label}", fontSize = 12.sp,
                    color = if (s.error != null) Bad else InkSoft)
                if (s.running) {
                    if (s.fraction >= 0f) LinearProgressIndicator(progress = { s.fraction }, modifier = Modifier.fillMaxWidth())
                    else LinearProgressIndicator(Modifier.fillMaxWidth())
                }
            }
        }
    }
}

private fun mb(n: Int): String = if (n >= 1024) "%.1f Go".format(n / 1024f).replace('.', ',') else "$n Mo"
