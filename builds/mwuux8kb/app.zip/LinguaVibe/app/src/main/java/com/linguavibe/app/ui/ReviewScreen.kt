package com.linguavibe.app.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linguavibe.app.data.CourseRepository
import com.linguavibe.app.data.Languages
import com.linguavibe.app.data.ProgressStore
import com.linguavibe.app.data.QuizItem
import com.linguavibe.app.study.StudyStore

private val ReviewColor = Color(0xFF6A3FB5)

/** Carte d'accueil « Révision du jour » : nombre de cartes à revoir et accès au mini-quiz. */
@Composable
fun DailyReviewCard(onOpen: () -> Unit) {
    val context = LocalContext.current
    val version = StudyStore.version
    val due = remember(version) { StudyStore.dueCount(context) }
    val total = remember(version) { StudyStore.allCards(context).size }
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(listOf(ReviewColor, Color(0xFF3B1F78))))
            .waxPattern(alpha = 0.07f)
            .clickable(onClick = onOpen).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("RÉVISION DU JOUR", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.3.sp, color = GoldSoft)
            Text(
                when {
                    due > 0 -> "$due carte${if (due > 1) "s" else ""} à revoir"
                    total > 0 -> "Tout est révisé pour aujourd'hui"
                    else -> "Mini-quiz du jour"
                },
                style = PosterTitle, fontSize = 20.sp, color = Color.White
            )
            Text(
                if (total == 0) "Vos erreurs aux quiz deviendront des cartes qui reviennent après 1, 3, 7, 14 jours…"
                else "Plus le mini-quiz de 3 questions. Les cartes reviennent après 1, 3, 7, 14, 30 jours.",
                fontSize = 12.5.sp, color = Color.White.copy(alpha = 0.85f)
            )
        }
        Box(Modifier.size(54.dp).clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = 0.15f)), contentAlignment = Alignment.Center) {
            Text(if (due > 0) "$due" else "🎯", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
        }
    }
}

/** Écran de révision : cartes à revoir (révision espacée) et mini-quiz du jour. */
@Composable
fun ReviewScreen(progress: ProgressStore, onBack: () -> Unit, startWithQuiz: Boolean = false) {
    val context = LocalContext.current
    val version = StudyStore.version
    val due = remember(version) { StudyStore.dueCount(context) }
    var tab by remember { mutableIntStateOf(if (startWithQuiz || due == 0) 1 else 0) }
    Column(Modifier.fillMaxSize()) {
        TopBar("Révision du jour", "Révision espacée et mini-quiz", ReviewColor, onBack)
        Row(Modifier.padding(horizontal = 16.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TabChip("Cartes ($due)", tab == 0) { tab = 0 }
            TabChip("Mini-quiz", tab == 1) { tab = 1 }
        }
        Box(Modifier.weight(1f)) {
            if (tab == 0) CardsReview(onQuiz = { tab = 1 }) else MiniQuiz(progress)
        }
    }
}

@Composable
private fun TabChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(50)).background(if (selected) ReviewColor else ReviewColor.copy(alpha = 0.10f))
            .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 9.dp)
    ) { Text(label, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = if (selected) Color.White else ReviewColor) }
}

@Composable
private fun CardsReview(onQuiz: () -> Unit) {
    val context = LocalContext.current
    val speaker = LocalSpeaker.current
    // Liste figée au début de la séance : une carte ratée revient en fin de séance.
    val queue = remember { mutableStateListOf<StudyStore.Card>().apply { addAll(StudyStore.dueCards(context)) } }
    var done by remember { mutableIntStateOf(0) }
    var known by remember { mutableIntStateOf(0) }
    val start = remember { queue.size }

    if (queue.isEmpty()) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            LineArt(Art.trophy, Modifier.size(110.dp), color = Ink, accent = Gold, strokeWidth = 2.4.dp)
            Text(if (start > 0) "Révision terminée !" else "Aucune carte à revoir aujourd'hui", style = PosterTitle, fontSize = 24.sp, color = Ink, textAlign = TextAlign.Center)
            Text(
                if (start > 0) "$known réponse${if (known > 1) "s" else ""} connue${if (known > 1) "s" else ""} sur $done. Les cartes reviendront au bon moment."
                else "Faites des quiz dans les leçons : chaque erreur devient une carte qui revient demain, puis de plus en plus tard si vous la connaissez.",
                fontSize = 14.sp, color = InkSoft, textAlign = TextAlign.Center
            )
            PillButton("Faire le mini-quiz du jour", Art.icQuiz, ReviewColor, Modifier.fillMaxWidth()) { onQuiz() }
        }
        return
    }

    val card = queue.first()
    var revealed by remember(card.id, done) { mutableStateOf(false) }
    val lang = remember(card.lang) { runCatching { Languages.byCode(card.lang) }.getOrNull() }
    LaunchedEffect(card.id, revealed) {
        if (revealed && card.audio.isNotBlank() && lang != null) speaker.speak(card.audio, lang.locale)
    }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        AnimatedBar(done.toFloat() / (done + queue.size).coerceAtLeast(1), ReviewColor)
        Text("${queue.size} carte${if (queue.size > 1) "s" else ""} restante${if (queue.size > 1) "s" else ""} · ${lang?.flag ?: ""} ${lang?.name ?: card.lang}",
            fontSize = 13.sp, color = InkSoft)
        AnimatedContent(targetState = card.id to revealed, label = "card") { (_, open) ->
            Column(
                Modifier.fillMaxWidth().heightIn(min = 240.dp).clip(RoundedCornerShape(26.dp)).background(Color.White)
                    .border(2.dp, ReviewColor.copy(alpha = 0.25f), RoundedCornerShape(26.dp))
                    .clickable { revealed = true }.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (card.source.isNotBlank()) Text(card.source, fontSize = 12.sp, color = InkSoft, textAlign = TextAlign.Center)
                Text(card.front, style = PosterTitle, fontSize = 21.sp, lineHeight = 27.sp, color = Ink, textAlign = TextAlign.Center)
                if (open) {
                    Box(Modifier.fillMaxWidth().height(1.dp).background(ReviewColor.copy(alpha = 0.2f)))
                    Text(card.back, fontSize = 20.sp, lineHeight = 26.sp, fontWeight = FontWeight.SemiBold, color = ReviewColor, textAlign = TextAlign.Center)
                } else {
                    Text("Touchez pour voir la réponse", fontSize = 13.sp, color = ReviewColor)
                }
            }
        }
        if (revealed) {
            if (card.audio.isNotBlank() && lang != null) {
                PillButton("Réécouter", Art.icVoice, ReviewColor, Modifier.fillMaxWidth(), filled = false) { speaker.speak(card.audio, lang.locale) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PillButton("À revoir", Art.icRefresh, Bad, Modifier.weight(1f)) {
                    StudyStore.grade(context, card, false)
                    queue.removeAt(0); queue.add(card.copy(box = 0)); done++
                }
                PillButton("Je savais", Art.icCheck, Good, Modifier.weight(1f)) {
                    StudyStore.grade(context, card, true)
                    queue.removeAt(0); done++; known++
                }
            }
            val next = StudyStore.INTERVALS[(card.box + 1).coerceAtMost(StudyStore.INTERVALS.lastIndex)]
            Text("« Je savais » : elle revient dans $next jour${if (next > 1) "s" else ""}. « À revoir » : demain.",
                fontSize = 12.sp, color = InkSoft, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        } else {
            PillButton("Voir la réponse", Art.icBook, ReviewColor, Modifier.fillMaxWidth()) { revealed = true }
        }
        Text("Retirer cette carte", Modifier.clickable { StudyStore.removeCard(context, card); queue.removeAt(0) },
            fontSize = 12.sp, color = InkSoft)
    }
}

/** Trois questions tirées des leçons de la dernière langue étudiée (en priorité les leçons commencées). */
fun miniQuizItems(context: android.content.Context, progress: ProgressStore, lang: String): List<QuizItem> {
    val models = if (lang == "es") listOf("model1", "model2", "model3", "model4") else listOf("model1")
    val lessons = models.flatMap { m -> runCatching { CourseRepository.load(context, lang, m).lessons }.getOrDefault(emptyList()) }
    val started = lessons.filter { progress.bestScore(it.id) != null }
    val pool = (started.ifEmpty { lessons.take(6) }).flatMap { it.quiz }
        .filter { it is QuizItem.Mcq || it is QuizItem.Listen || it is QuizItem.Typed || it is QuizItem.Fill || it is QuizItem.Order }
    return pool.shuffled().take(3)
}

@Composable
private fun MiniQuiz(progress: ProgressStore) {
    val context = LocalContext.current
    var langCode by remember { mutableStateOf(StudyStore.lastLang(context)) }
    val lang = remember(langCode) { Languages.byCode(langCode) }
    var round by remember { mutableIntStateOf(0) }
    val items = remember(langCode, round) { miniQuizItems(context, progress, langCode) }
    var index by remember(items) { mutableIntStateOf(0) }
    var correct by remember(items) { mutableIntStateOf(0) }
    var finished by remember(items) { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
            Languages.courses.filter { it.available }.forEach { l ->
                Box(
                    Modifier.clip(RoundedCornerShape(50)).background(if (l.code == langCode) ReviewColor.copy(alpha = 0.18f) else Color.Transparent)
                        .clickable { langCode = l.code; StudyStore.setLastLang(context, l.code) }.padding(6.dp)
                ) { Text(l.flag, fontSize = 20.sp) }
            }
        }
        if (items.isEmpty()) {
            Text("Pas encore de questions pour cette langue.", color = InkSoft)
            return@Column
        }
        if (finished) {
            Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)) {
                ScoreRing(correct * 100 / items.size, 110.dp)
                Text("$correct / ${items.size} · +${5 + correct * 5} XP", style = PosterTitle, fontSize = 22.sp, color = Ink)
                Text("Revenez demain pour un nouveau mini-quiz. Les erreurs sont ajoutées à vos cartes.", fontSize = 14.sp, color = InkSoft, textAlign = TextAlign.Center)
                PillButton("Encore 3 questions", Art.icRefresh, ReviewColor, Modifier.fillMaxWidth()) { round++ }
            }
            return@Column
        }
        AnimatedBar(index.toFloat() / items.size, ReviewColor)
        Text("Question ${index + 1} / ${items.size}", style = PosterTitle, fontSize = 18.sp, color = Ink)
        val item = items[index]
        QuizQuestion(
            item = item, lang = lang, color = ReviewColor, key = "mini-$langCode-$round-$index",
            modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()),
            onAnswered = { ok ->
                StudyStore.recordAnswer(context, ok)
                if (ok) correct++ else StudyStore.addMistake(context, langCode, item, "Mini-quiz")
            },
            continueLabel = if (index >= items.lastIndex) "Voir le résultat" else "Continuer",
            onContinue = {
                if (index >= items.lastIndex) {
                    progress.addXp(5 + correct * 5)
                    finished = true
                } else index++
            }
        )
    }
}
