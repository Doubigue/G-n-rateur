package com.linguavibe.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linguavibe.app.data.Conjugator
import com.linguavibe.app.data.Languages
import com.linguavibe.app.data.ProgressStore
import com.linguavibe.app.study.StudyStore
import kotlinx.coroutines.delay

private val ConvColor = Color(0xFFB5462A)

/**
 * Une question de conversation guidée. [keys] : groupes de mots attendus ; un groupe est satisfait
 * si la réponse contient l'un de ses mots (sans tenir compte des accents). [model] : exemple de réponse.
 */
private class ConvQ(val es: String, val fr: String, val keys: List<List<String>>, val model: String, val tip: String)
private class ConvTopic(val emoji: String, val title: String, val level: String, val questions: List<ConvQ>)

private fun q(es: String, fr: String, keys: String, model: String, tip: String) =
    ConvQ(es, fr, keys.split(';').map { g -> g.split('|').map { it.trim() } }.filter { it.first().isNotEmpty() }, model, tip)

private val TOPICS = listOf(
    ConvTopic("👋🏾", "Se présenter", "A1", listOf(
        q("¡Hola! ¿Cómo te llamas?", "Salut ! Comment t'appelles-tu ?", "me llamo|soy|mi nombre", "Me llamo Awa.", "Commencez par « Me llamo… »."),
        q("¿De dónde eres?", "D'où es-tu ?", "soy de|vivo en|de", "Soy de Lagunabé.", "Soy de + ville ou pays."),
        q("¿Cuántos años tienes?", "Quel âge as-tu ?", "tengo;años", "Tengo veinte años.", "En espagnol, on « a » ses années : tengo … años."),
        q("¿A qué te dedicas?", "Que fais-tu dans la vie ?", "soy|trabajo|estudio", "Soy estudiante. Estudio informática.", "Soy + métier, ou trabajo / estudio…"),
        q("¿Qué idiomas hablas?", "Quelles langues parles-tu ?", "hablo", "Hablo francés y un poco de español.", "Hablo + langue (sans article).")
    )),
    ConvTopic("👨‍👩‍👧", "La famille", "A1", listOf(
        q("¿Tienes hermanos?", "As-tu des frères et sœurs ?", "tengo|no tengo|hermano|hermana", "Sí, tengo dos hermanos y una hermana.", "Tengo + nombre + hermanos."),
        q("¿Cómo se llama tu madre?", "Comment s'appelle ta mère ?", "se llama|mi madre", "Mi madre se llama Fatou.", "Se llama + prénom."),
        q("¿Dónde vive tu familia?", "Où vit ta famille ?", "vive|viven|en", "Mi familia vive en Kanzikro.", "Mi familia vive en + lieu."),
        q("¿Qué hacéis juntos los domingos?", "Que faites-vous ensemble le dimanche ?", "comemos|vamos|jugamos|hablamos|vemos|cocinamos|visitamos", "Comemos juntos y vamos a la iglesia o al mercado.", "Verbes en -amos / -emos / -imos.")
    )),
    ConvTopic("⏰", "Ma journée", "A2", listOf(
        q("¿A qué hora te levantas?", "À quelle heure te lèves-tu ?", "me levanto;a las|a la", "Me levanto a las seis.", "Me levanto a las + heure."),
        q("¿Qué desayunas?", "Que prends-tu au petit-déjeuner ?", "desayuno|como|bebo|tomo", "Desayuno pan con café.", "Desayuno + aliment."),
        q("¿Cómo vas al trabajo o a clase?", "Comment vas-tu au travail ou en cours ?", "voy|tomo|camino|en|a pie", "Voy en gbaka o a pie.", "Voy en + transport / a pie."),
        q("¿Qué haces por la tarde?", "Que fais-tu l'après-midi ?", "estudio|trabajo|juego|descanso|veo|hago|leo|voy", "Por la tarde estudio y después juego al fútbol.", "Utilisez le présent : estudio, juego…"),
        q("¿A qué hora te acuestas?", "À quelle heure te couches-tu ?", "me acuesto;a las|a la", "Me acuesto a las diez y media.", "Me acuesto a las + heure.")
    )),
    ConvTopic("🍲", "La cuisine", "A2", listOf(
        q("¿Cuál es tu plato favorito?", "Quel est ton plat préféré ?", "mi plato|es|me gusta|favorito", "Mi plato favorito es el attiéké con pescado.", "Mi plato favorito es…"),
        q("¿Sabes cocinar?", "Sais-tu cuisiner ?", "sé|no sé|cocino|cocinar", "Sí, sé cocinar arroz y salsa de cacahuete.", "Sé / no sé + infinitif."),
        q("¿Qué no te gusta comer?", "Qu'est-ce que tu n'aimes pas manger ?", "no me gusta|no me gustan|odio", "No me gustan las verduras amargas.", "No me gusta + singulier / no me gustan + pluriel."),
        q("¿Prefieres comer en casa o en un restaurante?", "Préfères-tu manger à la maison ou au restaurant ?", "prefiero", "Prefiero comer en casa porque es más barato.", "Prefiero… porque…")
    )),
    ConvTopic("🏖️", "Le week-end dernier", "B1", listOf(
        q("¿Qué hiciste el fin de semana pasado?", "Qu'as-tu fait le week-end dernier ?", "fui|visité|jugué|comí|vi|estuve|hice|salí|descansé|trabajé", "El sábado fui al mercado y el domingo visité a mis abuelos.", "Passé simple : fui, visité, comí…"),
        q("¿Con quién saliste?", "Avec qui es-tu sorti(e) ?", "con|salí|fui", "Salí con mis amigos del barrio.", "Salí con + personne."),
        q("¿Qué tal lo pasaste?", "Comment ça s'est passé ?", "lo pasé|fue|estuvo|bien|mal|genial", "Lo pasé muy bien, fue un día genial.", "Lo pasé bien / fue genial."),
        q("¿Qué comiste?", "Qu'as-tu mangé ?", "comí|probé|tomé", "Comí pollo braisé con alloco.", "Comí + plat.")
    )),
    ConvTopic("🚀", "Mes projets", "B1", listOf(
        q("¿Qué vas a hacer mañana?", "Que vas-tu faire demain ?", "voy a|iré|haré", "Mañana voy a estudiar y después voy a ver a mi tía.", "Voy a + infinitif."),
        q("¿Dónde te gustaría viajar?", "Où aimerais-tu voyager ?", "me gustaría|quiero|quisiera", "Me gustaría viajar a Valdeluna.", "Me gustaría + infinitif."),
        q("¿Qué trabajo quieres tener en el futuro?", "Quel métier veux-tu avoir plus tard ?", "quiero|seré|me gustaría|ser", "Quiero ser ingeniera.", "Quiero ser + métier (sans article)."),
        q("¿Qué harás si ganas dinero?", "Que feras-tu si tu gagnes de l'argent ?", "compraré|ayudaré|viajaré|ahorraré|construiré|haré|daré", "Si gano dinero, ayudaré a mi familia y compraré una casa.", "Si + présent, futur : compraré, ayudaré…")
    )),
    ConvTopic("💬", "Donner son avis", "B2", listOf(
        q("¿Qué opinas de las redes sociales?", "Que penses-tu des réseaux sociaux ?", "creo que|pienso que|opino que|en mi opinión|me parece", "Creo que son útiles, pero pasamos demasiado tiempo en ellas.", "Creo que / En mi opinión…"),
        q("¿Es importante aprender idiomas? ¿Por qué?", "Est-il important d'apprendre des langues ? Pourquoi ?", "es importante|porque|ya que|para", "Sí, es importante porque podemos trabajar en otros países.", "Justifiez avec porque / ya que."),
        q("¿Qué cambiarías en tu ciudad?", "Que changerais-tu dans ta ville ?", "cambiaría|haría|construiría|pondría|mejoraría", "Construiría más parques y mejoraría el transporte.", "Conditionnel : cambiaría, haría…"),
        q("¿Crees que es mejor vivir en el campo o en la ciudad?", "Vaut-il mieux vivre à la campagne ou en ville ?", "creo que|es mejor|prefiero|depende", "Creo que es mejor vivir en el campo porque es más tranquilo, aunque hay menos trabajo.", "Comparez : más… que, aunque…")
    ))
)

private class Turn(val fromApp: Boolean, val text: String, val sub: String = "", val ok: Boolean? = null)

/** Conversation guidée au micro (espagnol) : l'appli pose des questions, l'apprenant répond librement. */
@Composable
fun ConversationScreen(progress: ProgressStore, onBack: () -> Unit) {
    var topic by remember { mutableStateOf<ConvTopic?>(null) }
    val current = topic
    if (current == null) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            TopBar("Conversation libre", "Répondez au micro, comme vous voulez", ConvColor, onBack)
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("L'application vous pose des questions en espagnol. Répondez par une phrase complète, au micro ou au clavier : " +
                    "elle vérifie que la réponse contient l'essentiel et vous propose un exemple.", fontSize = 13.sp, color = InkSoft)
                TOPICS.forEach { t ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color.White).clickable { topic = t }.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(t.emoji, fontSize = 28.sp)
                        Column(Modifier.weight(1f)) {
                            Text(t.title, style = PosterTitle, fontSize = 17.sp, color = Ink)
                            Text("${t.questions.size} questions", fontSize = 12.sp, color = InkSoft)
                        }
                        Chip(t.level, ConvColor)
                    }
                }
            }
        }
        return
    }
    ConversationChat(current, progress, onBack = { topic = null })
}

@Composable
private fun ConversationChat(topic: ConvTopic, progress: ProgressStore, onBack: () -> Unit) {
    val context = LocalContext.current
    val speaker = LocalSpeaker.current
    val es = remember { Languages.byCode("es") }
    val turns = remember(topic) { mutableStateListOf<Turn>() }
    var index by remember(topic) { mutableIntStateOf(0) }
    var waiting by remember(topic) { mutableStateOf(true) }
    var good by remember(topic) { mutableIntStateOf(0) }
    var input by remember(topic, index) { mutableStateOf("") }
    val scroll = rememberScrollState()
    val done = index >= topic.questions.size

    LaunchedEffect(topic, index) {
        if (done) {
            turns.add(Turn(true, "¡Muy bien! Hemos terminado. ¡Hasta pronto!", "Très bien ! Nous avons terminé. À bientôt !"))
            progress.addXp(10 + good * 5)
            speaker.speak("¡Muy bien! Hemos terminado. ¡Hasta pronto!", es.locale)
        } else {
            val qn = topic.questions[index]
            delay(500)
            turns.add(Turn(true, qn.es, qn.fr))
            speaker.speak(qn.es, es.locale)
            waiting = true
        }
        delay(100); scroll.animateScrollTo(scroll.maxValue)
    }

    fun answer(text: String) {
        if (done || text.isBlank()) return
        val qn = topic.questions[index]
        val f = Conjugator.fold(text)
        val words = text.trim().split(Regex("\\s+")).size
        val missing = qn.keys.filter { g -> g.none { k -> f.contains(Conjugator.fold(k)) } }
        val ok = missing.isEmpty() && words >= 2
        turns.add(Turn(false, text.trim(), ok = ok))
        StudyStore.recordAnswer(context, ok)
        val reaction = when {
            ok -> listOf("¡Muy bien!", "¡Perfecto!", "¡Genial!", "¡Qué interesante!").random()
            words < 2 -> "Faites une phrase complète."
            else -> "Presque ! ${qn.tip}"
        }
        turns.add(Turn(true, reaction, if (ok) "" else "Exemple : ${qn.model}", ok))
        if (ok) { good++; speaker.speak(reaction, es.locale) } else StudyStore.addCard(context, "es", "Répondez : ${qn.es} (${qn.fr})", qn.model, qn.model, "Conversation")
        waiting = false
    }

    Column(Modifier.fillMaxSize()) {
        TopBar(topic.title, "Conversation · ${topic.level}", ConvColor, onBack)
        Column(Modifier.weight(1f).verticalScroll(scroll).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            turns.forEach { t ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (t.fromApp) Arrangement.Start else Arrangement.End) {
                    Column(
                        Modifier.fillMaxWidth(0.85f).clip(RoundedCornerShape(18.dp))
                            .background(
                                when {
                                    !t.fromApp -> ConvColor
                                    t.ok == false -> Bad.copy(alpha = 0.10f)
                                    t.ok == true -> Good.copy(alpha = 0.12f)
                                    else -> Color.White
                                }
                            )
                            .clickable { if (t.fromApp) speaker.speak(t.text, es.locale) }
                            .padding(12.dp)
                    ) {
                        Text(t.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = if (t.fromApp) Ink else Color.White)
                        if (t.sub.isNotBlank()) Text(t.sub, fontSize = 13.sp, fontStyle = FontStyle.Italic, color = if (t.fromApp) InkSoft else Color.White.copy(alpha = 0.85f))
                    }
                }
            }
        }
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp)).background(Color.White)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            when {
                done -> {
                    Text("$good bonne${if (good > 1) "s" else ""} réponse${if (good > 1) "s" else ""} sur ${topic.questions.size} · +${10 + good * 5} XP",
                        fontWeight = FontWeight.Bold, color = ConvColor)
                    PillButton("Choisir un autre sujet", Art.icChat, ConvColor, Modifier.fillMaxWidth()) { onBack() }
                }
                waiting -> {
                    MicControl("conv-${topic.title}-$index", es, ConvColor) { heard -> answer(heard) }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(input, { input = it }, Modifier.weight(1f), label = { Text("ou tapez votre réponse") }, singleLine = true)
                        PillButton("OK", Art.icCheck, ConvColor, enabled = input.isNotBlank()) { answer(input) }
                    }
                }
                else -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PillButton("Réessayer", Art.icRefresh, ConvColor, Modifier.weight(1f), filled = false) { waiting = true }
                    PillButton("Question suivante", Art.icPlay, ConvColor, Modifier.weight(1f)) { index++ }
                }
            }
        }
    }
}
