package com.linguavibe.app.ui

import android.graphics.BitmapFactory
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linguavibe.app.data.DialogueLine
import com.linguavibe.app.data.DialogueScene
import com.linguavibe.app.data.LanguageInfo
import com.linguavibe.app.data.Lesson
import com.linguavibe.app.data.Levels
import com.linguavibe.app.speech.VoskManager
import kotlinx.coroutines.delay

// =============================================================================
// Style « manuel africain » des MODEL 2 et 3.
// Les scènes des dialogues sont des illustrations en couleur (assets/scenes), le lineart reste en secours.
// Palette « Portfolio » DL VIBE STUDIO (crème, orange brûlé, brun) + frises bogolan.
// Les leçons du MODEL 1 gardent leur style d'origine.
// =============================================================================

object Manual {
    val Bg = Color(0xFFFFF8EF)
    val Bg2 = Color(0xFFFFEEDD)
    val Card = Color(0xFFFFFFFF)
    val Surface2 = Color(0xFFF6E6D3)
    val Ink = Color(0xFF3A0E05)
    val Muted = Color(0xFF7D5A4A)
    val Accent = Color(0xFFE8590C)
    val Accent2 = Color(0xFFC2410C)
    val Line = Color(0x1A3A0E05)
    val Cream = Color(0xFFFFD8A8)

    /** Bandeau du haut : brun profond vers terre cuite. */
    val poster = PosterTheme(start = Ink, end = Accent2, accent = Cream, onAccent = Ink)
}

fun isManualModel(modelId: String) = modelId == "model2" || modelId == "model3"

/** Couleurs de niveau en tons de terre (contraste suffisant sous du texte blanc). */
fun manualLevelColor(level: String): Color = when (level) {
    "A1" -> Color(0xFFC2410C)
    "A2" -> Color(0xFFB45309)
    "B1" -> Color(0xFF9A3412)
    "B2" -> Color(0xFF7C2D12)
    "C1" -> Color(0xFF8A1C1C)
    "C2" -> Color(0xFF5B1A0B)
    else -> Manual.Accent2
}

/** Fond papier crème avec un léger quadrillage, comme une page de manuel. */
fun Modifier.manualPaper(): Modifier = this
    .background(Brush.verticalGradient(listOf(Manual.Bg, Manual.Bg2)))
    .drawBehind {
        val step = 22.dp.toPx()
        val c = Manual.Ink.copy(alpha = 0.035f)
        var x = step
        while (x < size.width) { drawLine(c, Offset(x, 0f), Offset(x, size.height), 1f); x += step }
        var y = step
        while (y < size.height) { drawLine(c, Offset(0f, y), Offset(size.width, y), 1f); y += step }
    }

/** Frise bogolan : zigzag + rangée de points, en couleur d'accent. */
@Composable
fun BogolanBand(color: Color = Manual.Accent2, modifier: Modifier = Modifier) {
    Canvas(modifier.fillMaxWidth().height(14.dp)) {
        val u = 9.dp.toPx()
        val stroke = Stroke(1.4.dp.toPx())
        val zig = Path()
        var x = 0f
        val y = size.height * 0.55f
        zig.moveTo(0f, y)
        while (x < size.width) { zig.lineTo(x + u / 2, y - u / 2.4f); zig.lineTo(x + u, y); x += u }
        drawPath(zig, color.copy(alpha = 0.75f), style = stroke)
        var px = u / 2
        while (px < size.width) { drawCircle(color.copy(alpha = 0.6f), 1.3.dp.toPx(), Offset(px, size.height - 1.5.dp.toPx())); px += u }
    }
}

/**
 * Illustration en couleur d'une scène (assets/scenes/<id>.webp, générée par tools/flat_scenes.py),
 * avec un léger zoom lent. Si l'image manque, on retombe sur le dessin lineart.
 */
@Composable
fun SceneImage(sceneId: String?, fallback: LineDrawing, color: Color, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val bitmap = remember(sceneId) {
        sceneId?.let { id ->
            runCatching { context.assets.open("scenes/$id.webp").use { BitmapFactory.decodeStream(it)?.asImageBitmap() } }.getOrNull()
        }
    }
    if (bitmap == null) {
        LineArt(fallback, modifier, color = Manual.Ink, accent = color, strokeWidth = 1.6.dp, drawMillis = 2200, float = false)
        return
    }
    val transition = rememberInfiniteTransition(label = "scene")
    val zoom by transition.animateFloat(
        initialValue = 1f, targetValue = 1.07f,
        animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Reverse),
        label = "zoom"
    )
    Box(modifier.clip(RoundedCornerShape(18.dp))) {
        Image(
            bitmap = bitmap,
            contentDescription = "Illustration de la scène",
            modifier = Modifier.fillMaxSize().graphicsLayer { scaleX = zoom; scaleY = zoom },
            contentScale = ContentScale.Crop
        )
    }
}

/** En-tête de leçon du manuel : scène lineart en grand, numéro, titres, niveau. */
@Composable
fun ManualHero(lesson: Lesson, color: Color) {
    val drawing = remember(lesson.id) {
        Scenes.byId(lesson.scenes.firstOrNull()?.scene) ?: Art.forLesson(lesson)
    }
    val wide = lesson.scenes.isNotEmpty()
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(26.dp))
            .background(Manual.Card)
            .border(1.dp, color.copy(alpha = 0.25f), RoundedCornerShape(26.dp))
    ) {
        Box(
            Modifier.fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Manual.Bg, Manual.Bg2)))
                .padding(horizontal = 10.dp, vertical = 8.dp)
        ) {
            if (wide) {
                SceneImage(lesson.scenes.first().scene, drawing, color, Modifier.fillMaxWidth().aspectRatio(1.6f))
            } else {
                LineArt(drawing, Modifier.fillMaxWidth().height(150.dp), color = Manual.Ink, accent = color,
                    strokeWidth = 1.6.dp, drawMillis = 2200, float = false)
            }
        }
        BogolanBand(color)
        Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.clip(RoundedCornerShape(50)).background(color).padding(horizontal = 10.dp, vertical = 3.dp)) {
                    Text("LEÇON ${lesson.number.toString().padStart(2, '0')}", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold,
                        color = Color.White, letterSpacing = 1.4.sp)
                }
                Text("${lesson.level} · ${Levels.label(lesson.level)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Manual.Muted)
            }
            Text(lesson.title, style = PosterTitle, fontSize = 25.sp, lineHeight = 28.sp, color = Manual.Ink)
            if (lesson.titleTr.isNotBlank() && lesson.titleTr != lesson.title) {
                Text(lesson.titleTr, style = AccentText, fontSize = 16.sp, color = color)
            }
            if (lesson.scenes.isNotEmpty()) {
                Text(
                    "${lesson.scenes.size} dialogue${if (lesson.scenes.size > 1) "s" else ""} illustré${if (lesson.scenes.size > 1) "s" else ""} · " +
                        "${lesson.vocab.size} mots · ${lesson.quiz.size} questions",
                    fontSize = 12.sp, color = Manual.Muted
                )
            }
        }
    }
}

// =============================================================================
// Dialogues illustrés en scènes
// =============================================================================

/** Couleur stable par personnage (l'apprenant prend la couleur du niveau). */
private fun characterColor(name: String, user: Boolean, color: Color): Color {
    if (user) return color
    val palette = listOf(Manual.Ink, Color(0xFF0F5E59), Color(0xFF6D28D9), Color(0xFF1D4ED8), Color(0xFF92400E))
    return palette[(name.hashCode() and 0x7fffffff) % palette.size]
}

@Composable
private fun Initial(name: String, tint: Color, filled: Boolean) {
    Box(
        Modifier.size(36.dp).clip(RoundedCornerShape(50))
            .background(if (filled) tint else tint.copy(alpha = 0.12f))
            .border(1.5.dp, tint, RoundedCornerShape(50)),
        contentAlignment = Alignment.Center
    ) {
        Text(name.take(1).uppercase(), fontWeight = FontWeight.ExtraBold, fontSize = 16.sp,
            color = if (filled) Color.White else tint)
    }
}

/** Onglets des scènes (« 1. Me llamo Fatou », « 2. Buenos días, abuela »…). */
@Composable
private fun SceneTabs(scenes: List<DialogueScene>, selected: Int, color: Color, onSelect: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        scenes.forEachIndexed { i, sc ->
            val active = i == selected
            val bg by animateColorAsState(if (active) Manual.Ink else Manual.Card, label = "sceneTab")
            Column(
                Modifier.widthIn(max = 220.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(bg)
                    .border(1.dp, if (active) Manual.Ink else Manual.Line, RoundedCornerShape(16.dp))
                    .clickable { onSelect(i) }
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Text("SCÈNE ${i + 1}", fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.2.sp,
                    color = if (active) Manual.Cream else color)
                Text(sc.title, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1,
                    color = if (active) Color.White else Manual.Ink)
            }
        }
    }
}

/** Carte de la scène : grand dessin lineart, titre, mise en situation, distribution des rôles. */
@Composable
private fun SceneCard(lesson: Lesson, sc: DialogueScene, index: Int, color: Color) {
    val drawing = remember(lesson.id, index) { Scenes.byId(sc.scene) ?: Art.forLesson(lesson) }
    val shape = RoundedCornerShape(24.dp)
    Column(Modifier.fillMaxWidth().clip(shape).background(Manual.Card).border(1.dp, color.copy(alpha = 0.22f), shape)) {
        Box(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Manual.Bg, Manual.Bg2))).padding(8.dp)) {
            key(index) {
                SceneImage(sc.scene, drawing, color, Modifier.fillMaxWidth().aspectRatio(1.6f))
            }
        }
        BogolanBand(color)
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(sc.title, style = PosterTitle, fontSize = 21.sp, color = Manual.Ink)
            if (sc.titleTr.isNotBlank()) Text(sc.titleTr, style = AccentText, fontSize = 15.sp, color = color)
            if (sc.context.isNotBlank()) Text(sc.context, fontSize = 14.sp, lineHeight = 20.sp, color = Manual.Muted)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                sc.characters.forEach { (name, user) ->
                    val tint = characterColor(name, user, color)
                    Row(
                        Modifier.clip(RoundedCornerShape(50)).background(tint.copy(alpha = 0.10f)).padding(end = 10.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Initial(name, tint, user)
                        Text(if (user) "$name (vous)" else name, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = tint)
                    }
                }
            }
        }
    }
}

@Composable
private fun RoleChip(label: String, selected: Boolean, color: Color, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(50)).background(if (selected) color else color.copy(alpha = 0.10f))
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(label, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = if (selected) Color.White else color)
    }
}

/** Bulle avec le nom du personnage et son initiale ; [hidden] masque le texte (mode mémoire). */
@Composable
private fun NamedBubble(line: DialogueLine, color: Color, showTranslation: Boolean, hidden: Boolean = false, onClick: () -> Unit) {
    val tint = characterColor(line.label, line.isUser, color)
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (line.isUser) Arrangement.End else Arrangement.Start,
        verticalAlignment = Alignment.Bottom
    ) {
        if (!line.isUser) { Initial(line.label, tint, false); Spacer(Modifier.width(8.dp)) }
        Column(
            Modifier
                .fillMaxWidth(0.86f)
                .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp,
                    bottomStart = if (line.isUser) 20.dp else 4.dp, bottomEnd = if (line.isUser) 4.dp else 20.dp))
                .background(if (line.isUser) Brush.linearGradient(listOf(color, color.copy(alpha = 0.82f)))
                    else Brush.linearGradient(listOf(Manual.Card, Manual.Card)))
                .border(1.dp, if (line.isUser) Color.Transparent else tint.copy(alpha = 0.25f),
                    RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp,
                        bottomStart = if (line.isUser) 20.dp else 4.dp, bottomEnd = if (line.isUser) 4.dp else 20.dp))
                .clickable(onClick = onClick)
                .padding(12.dp)
        ) {
            val textColor = if (line.isUser) Color.White else Manual.Ink
            Text(line.label.uppercase(), fontSize = 10.5.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.1.sp,
                color = if (line.isUser) Manual.Cream else tint)
            if (hidden) {
                Text("• • •  à dire de mémoire", fontWeight = FontWeight.SemiBold, fontSize = 16.sp, color = textColor)
            } else {
                Text(line.text, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, color = textColor)
                PronLine(line.pron, color, onDark = line.isUser)
            }
            if (showTranslation) {
                Text(line.translation, fontSize = 13.sp, color = textColor.copy(alpha = 0.78f), fontStyle = FontStyle.Italic)
            }
        }
        if (line.isUser) { Spacer(Modifier.width(8.dp)); Initial(line.label, tint, true) }
    }
}

/**
 * Étape « Dialogue » des MODEL 2 et 3 : choix de la scène, illustration, puis jeu de rôle réplique par réplique.
 * L'application joue les autres personnages ; l'apprenant dit les répliques de son personnage (rôle B) au micro.
 */
@Composable
fun SceneDialogueStep(lesson: Lesson, lang: LanguageInfo, color: Color, onNext: () -> Unit) {
    val speaker = LocalSpeaker.current
    var sceneIndex by rememberSaveable(lesson.id) { mutableIntStateOf(0) }
    val sc = lesson.scenes[sceneIndex.coerceIn(0, lesson.scenes.lastIndex)]
    // Rôle joué par l'apprenant : B (par défaut) ou A. On inverse les rôles des répliques.
    var playB by rememberSaveable(lesson.id) { mutableStateOf(true) }
    // Mode mémoire : la réplique de l'apprenant est cachée, seule la traduction est montrée.
    var memory by rememberSaveable(lesson.id) { mutableStateOf(false) }
    val lines = remember(sc, playB) {
        if (playB) sc.lines else sc.lines.map { it.copy(speaker = if (it.speaker == "B") "A" else "B") }
    }
    val nameA = sc.lines.firstOrNull { it.speaker == "A" }?.name?.ifBlank { null } ?: "A"
    val nameB = sc.lines.firstOrNull { it.speaker == "B" }?.name?.ifBlank { null } ?: "B"
    var shown by remember(lesson.id, sceneIndex, playB) { mutableIntStateOf(1) }
    var revealed by remember(lesson.id, sceneIndex, playB, shown) { mutableStateOf(false) }
    var translations by rememberSaveable(lesson.id) { mutableStateOf(true) }
    val scroll = rememberScrollState()
    val current = lines[(shown - 1).coerceIn(0, lines.lastIndex)]
    val lastLine = shown >= lines.size
    val lastScene = sceneIndex >= lesson.scenes.lastIndex

    LaunchedEffect(sceneIndex, shown, playB) {
        delay(if (shown == 1) 900 else 200)
        if (shown > 1) scroll.animateScrollTo(scroll.maxValue)
        if (!current.isUser) speaker.speak(current.text, lang.locale)
    }
    LaunchedEffect(sceneIndex) {
        speaker.stop()
        VoskManager.cancel()
        scroll.scrollTo(0)
    }

    Column(Modifier.fillMaxSize()) {
        Column(
            Modifier.weight(1f).verticalScroll(scroll).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (lesson.scenes.size > 1) SceneTabs(lesson.scenes, sceneIndex, color) { sceneIndex = it }
            SceneCard(lesson, sc, sceneIndex, color)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PillButton(
                    if (speaker.sequencePlaying) "Arrêter" else "Écouter la scène",
                    if (speaker.sequencePlaying) Art.icStop else Art.icVoice,
                    if (speaker.sequencePlaying) Bad else Manual.Ink, Modifier.weight(1f)
                ) {
                    if (speaker.sequencePlaying) speaker.stop() else speaker.speakAll(lines.map { it.text }, lang.locale)
                }
                PillButton(if (translations) "Masquer FR" else "Voir FR", Art.icBook, color, Modifier.weight(1f), filled = false) {
                    translations = !translations
                }
            }
            Text("JE JOUE", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.2.sp, color = Manual.Muted)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                RoleChip(nameB, playB, color) { playB = true }
                RoleChip(nameA, !playB, color) { playB = false }
                RoleChip(if (memory) "🧠 Mode mémoire : oui" else "🧠 Mode mémoire", memory, Manual.Ink) { memory = !memory }
            }
            Text(
                if (memory) "Mode mémoire : vos répliques sont cachées. Lisez le sens en français et dites la phrase de mémoire, puis vérifiez."
                else "Jeu de rôle : l'application joue les autres personnages, vous dites les répliques colorées. Touchez une bulle pour la réécouter.",
                style = AccentText, fontSize = 13.sp, color = Manual.Muted
            )
            lines.take(shown).forEachIndexed { i, line ->
                key(sceneIndex, playB, i) {
                    val hide = memory && line.isUser && i == shown - 1 && !revealed
                    StaggerIn(0) {
                        NamedBubble(line, color, translations || hide, hidden = hide) {
                            if (!hide) speaker.speak(line.text, lang.locale)
                        }
                    }
                }
            }
            if (lastLine) {
                Text(
                    if (lastScene) "Bravo, vous avez joué toutes les scènes !" else "Scène terminée. Passez à la scène suivante.",
                    modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center,
                    style = AccentText, fontSize = 15.sp, color = color
                )
            }
        }
        Column(
            Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp))
                .background(Manual.Card)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val hidden = memory && current.isUser && !revealed
            if (current.isUser) {
                Text(
                    if (hidden) "À vous (${current.label}) ! Dites de mémoire : « ${current.translation} »"
                    else "À vous (${current.label}) ! Dites la phrase colorée :",
                    style = PosterTitle, fontSize = 16.sp, color = color
                )
                PronounceBlock("dialogue-${lesson.id}-$sceneIndex-$playB-$shown", current.text, lang, color)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (hidden) {
                    PillButton("Voir la phrase", Art.icBook, color, Modifier.weight(1f), filled = false) { revealed = true }
                } else PillButton("Réécouter", Art.icSlow, color, Modifier.weight(1f), filled = false) {
                    speaker.speak(current.text, lang.locale, slow = true)
                }
                val label = when {
                    !lastLine -> "Continuer"
                    !lastScene -> "Scène suivante"
                    else -> "Terminer"
                }
                PillButton(label, if (lastLine && lastScene) Art.icCheck else Art.icPlay, color, Modifier.weight(1f)) {
                    when {
                        !lastLine -> shown++
                        !lastScene -> sceneIndex++
                        else -> onNext()
                    }
                }
            }
        }
    }
}
