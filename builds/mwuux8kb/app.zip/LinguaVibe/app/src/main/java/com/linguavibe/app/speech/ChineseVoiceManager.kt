package com.linguavibe.app.speech

import android.content.Context
import androidx.compose.runtime.mutableStateOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import java.io.BufferedInputStream
import java.io.File

/** Pack chinois dédié : modèle VITS Icefall AISHELL-3 (non Piper, non Kokoro). */
object ChineseVoiceManager {
    const val MODEL_ID = "vits-icefall-zh-aishell3"
    const val MODEL_URL = "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/$MODEL_ID.tar.bz2"
    val progress = mutableStateOf(SupertonicVoiceManager.DownloadProgress())
    fun modelDir(context: Context) = File(LangStorage.dir(context, "tts-models"), MODEL_ID)
    fun isInstalled(context: Context) = listOf("model.onnx", "lexicon.txt", "tokens.txt").all { File(modelDir(context), it).length() > 0 }

    suspend fun install(context: Context, onProgress: (Long, Long) -> Unit = { _, _ -> }) = withContext(Dispatchers.IO) {
        if (isInstalled(context)) return@withContext
        val root = LangStorage.dir(context, "tts-models")
        val archive = File(LangStorage.dir(context, "downloads"), "$MODEL_ID.tar.bz2")
        progress.value = SupertonicVoiceManager.DownloadProgress(running = true)
        try {
            var count = 0L
            var total = 0L
            ResumableDownload.fetch(MODEL_URL, archive) { done, size ->
                count = done; total = size
                progress.value = SupertonicVoiceManager.DownloadProgress(done, size, true)
                onProgress(done, size)
            }
            if (archive.length() < 1024L) throw IllegalStateException("Archive chinoise vide ou incomplète.")
            val staging = File(root, "$MODEL_ID.extracting").apply { deleteRecursively(); mkdirs() }
            BZip2CompressorInputStream(BufferedInputStream(archive.inputStream())).use { bz ->
                TarArchiveInputStream(bz).use { tar ->
                    while (true) {
                        val entry = tar.nextTarEntry ?: break
                        val out = File(staging, entry.name).canonicalFile
                        require(out.path.startsWith(staging.canonicalPath + File.separator) || out == staging) { "Archive chinoise invalide." }
                        if (entry.isDirectory) out.mkdirs() else { out.parentFile?.mkdirs(); out.outputStream().use { tar.copyTo(it) } }
                    }
                }
            }
            val extracted = File(staging, MODEL_ID).takeIf { it.isDirectory } ?: staging
            val destination = modelDir(context); destination.deleteRecursively()
            if (!extracted.renameTo(destination)) extracted.walkTopDown().forEach { f -> val target = File(destination, f.relativeTo(extracted).path); if (f.isDirectory) target.mkdirs() else { target.parentFile?.mkdirs(); f.copyTo(target, true) } }
            staging.deleteRecursively(); archive.delete()
            if (!isInstalled(context)) throw IllegalStateException("Fichiers du modèle chinois manquants après extraction.")
            progress.value = SupertonicVoiceManager.DownloadProgress(count, total, false)
        } catch (t: Throwable) {
            progress.value = SupertonicVoiceManager.DownloadProgress(error = t.message ?: "Installation du chinois impossible.")
            throw t
        }
    }

    fun remove(context: Context) { modelDir(context).deleteRecursively() }
}
