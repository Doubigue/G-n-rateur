package com.linguavibe.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linguavibe.app.data.LanguageInfo
import com.linguavibe.app.data.Languages
import com.linguavibe.app.data.Lesson

private const val TAG = "narration"

/**
 * « Écouter le cours en français » : un narrateur français lit toute la leçon (présentation, manuel,
 * vocabulaire, grammaire, dialogues, lecture), avec les exemples dans la langue étudiée.
 */
@Composable
fun CourseListenCard(lesson: Lesson, lang: LanguageInfo, color: Color) {
    val speaker = LocalSpeaker.current
    var frenchOnly by rememberSaveable { mutableStateOf(false) }
    var examples by rememberSaveable { mutableStateOf(true) }
    val segs = remember(lesson.id, frenchOnly, examples) { CourseNarration.build(lesson, frenchOnly, examples) }
    val sections = remember(segs) { segs.map { it.section }.distinct() }
    val french = Languages.native.locale
    val playing = speaker.sequencePlaying && speaker.sequenceTag == TAG
    val index = if (playing) speaker.sequenceIndex.coerceIn(0, segs.lastIndex) else -1

    fun play(from: Int) {
        speaker.speakSegments(segs.map { it.text to if (it.foreign) lang.locale else french }, TAG, from = from.coerceIn(0, segs.lastIndex))
    }

    CardBox {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            LangBadge("fr", 36.dp)
            Column(Modifier.weight(1f)) {
                Text("Écouter le cours en français", style = PosterTitle, fontSize = 17.sp, color = Ink)
                Text(
                    "Un narrateur explique toute la leçon en français" +
                        if (frenchOnly) "." else ", et les exemples sont lus en ${lang.name.lowercase()}.",
                    fontSize = 12.sp, color = InkSoft
                )
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !frenchOnly, onClick = { if (playing) speaker.stop(); frenchOnly = false },
                label = { Text("Français + ${lang.name.lowercase()}") })
            FilterChip(selected = frenchOnly, onClick = { if (playing) speaker.stop(); frenchOnly = true },
                label = { Text("Tout en français") })
        }
        FilterChip(selected = examples, onClick = { if (playing) speaker.stop(); examples = !examples },
            label = { Text("Lire les exemples du vocabulaire") })

        Text("Commencer à :", fontSize = 12.sp, color = InkSoft)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            sections.forEach { s ->
                val current = playing && segs.getOrNull(index)?.section == s
                FilterChip(selected = current, onClick = { play(segs.indexOfFirst { it.section == s }) }, label = { Text(s) })
            }
        }

        PillButton(
            if (playing) "Arrêter la narration" else "Écouter tout le cours (${segs.size} passages)",
            if (playing) Art.icStop else Art.icPlay,
            if (playing) Bad else color,
            Modifier.fillMaxWidth(), big = true
        ) { if (playing) speaker.stop() else play(0) }

        if (playing && index >= 0) {
            val seg = segs[index]
            LinearProgressIndicator(
                progress = { (index + 1f) / segs.size },
                modifier = Modifier.fillMaxWidth(), color = color
            )
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(color.copy(alpha = 0.08f)).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    "${seg.section.uppercase()} · ${index + 1} / ${segs.size}",
                    fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, color = color
                )
                Text(
                    seg.text, fontSize = 15.sp, lineHeight = 21.sp,
                    color = Ink, fontWeight = if (seg.foreign) FontWeight.Bold else FontWeight.Normal
                )
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                TextButton(onClick = { play(index - 1) }, enabled = index > 0) { Text("◀ Précédent") }
                TextButton(onClick = { play(index) }) { Text("↻ Répéter") }
                TextButton(onClick = { play(index + 1) }, enabled = index < segs.lastIndex) { Text("Suivant ▶") }
            }
        }
        Text(
            "Hors ligne : téléchargez le pack « Français » (et celui de la langue) dans Paramètres › Voix, " +
                "ou installez la voix Supertonic 3.",
            fontSize = 11.sp, color = InkSoft
        )
    }
}
