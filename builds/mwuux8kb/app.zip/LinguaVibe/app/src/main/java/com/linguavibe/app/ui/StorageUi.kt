package com.linguavibe.app.ui

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.linguavibe.app.speech.LangDownloads
import com.linguavibe.app.speech.LangStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Carte « Conserver mes langues » : demande l'accès au stockage pour ranger les données de langue dans
 * le dossier public LinguaVibe, qui survit à la désinstallation, puis y déplace ce qui est déjà téléchargé.
 */
@Composable
fun DurableStorageCard() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    val version = LangStorage.version

    fun afterGrant() {
        LangStorage.refresh()
        tick++
        scope.launch { withContext(Dispatchers.IO) { LangStorage.migrateToDurable(context) } }
    }

    val settingsLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { afterGrant() }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { afterGrant() }

    // Retour des paramètres système : on revérifie l'accès.
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    val durable = remember(tick, version) { LangStorage.isDurable(context) }
    val size = remember(tick, version) { LangStorage.sizeMb(context) }

    CardBox {
        Text("Conserver mes langues", style = PosterTitle, fontSize = 17.sp, color = Ink)
        if (durable) {
            Text(
                "✔ Les modèles vocaux, voix et audios sont rangés dans le dossier « ${LangStorage.FOLDER} » du téléphone " +
                    "($size Mo). Ils restent même si vous désinstallez l'appli : après une réinstallation, accordez de nouveau " +
                    "l'accès et tout est retrouvé sans Internet.",
                fontSize = 13.sp, color = Good, fontWeight = FontWeight.SemiBold
            )
        } else {
            Text(
                "Aujourd'hui, les langues téléchargées ($size Mo) sont dans le dossier privé de l'appli : Android les efface " +
                    "si vous désinstallez LinguaVibe. Autorisez l'accès au stockage pour les ranger dans un dossier « ${LangStorage.FOLDER} » " +
                    "qui reste sur le téléphone. Si vous réinstallez l'appli, touchez ce bouton : vos langues reviennent sans téléchargement.",
                fontSize = 13.sp, color = InkSoft
            )
            Button(onClick = {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    try {
                        LangStorage.accessIntent(context)?.let { settingsLauncher.launch(it) }
                    } catch (_: ActivityNotFoundException) {
                        LangStorage.fallbackAccessIntent()?.let { runCatching { settingsLauncher.launch(it) } }
                    }
                } else {
                    permLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                }
            }, modifier = Modifier.fillMaxWidth()) { Text("Conserver mes langues après désinstallation") }
            Text(
                "Sur Android 11 et plus, activez « Autoriser l'accès pour gérer tous les fichiers » pour LinguaVibe, puis revenez.",
                fontSize = 12.sp, color = InkSoft
            )
        }
        LangStorage.migrating?.let {
            Text(it, fontSize = 12.sp, color = InkSoft)
            LinearProgressIndicator(Modifier.fillMaxWidth())
        }
    }
}

/**
 * Demande l'autorisation des notifications (Android 13+) avant un téléchargement, pour voir son
 * avancement quand l'appli est fermée. Le téléchargement démarre dans tous les cas.
 */
@Composable
fun rememberDownloadStarter(): (() -> Unit) -> Unit {
    val context = LocalContext.current
    var pending by remember { mutableStateOf<(() -> Unit)?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        pending?.invoke()
        pending = null
    }
    return { action ->
        LangDownloads.createChannel(context)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            pending = action
            launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            action()
        }
    }
}

/** Barre et texte d'état d'un téléchargement en arrière-plan. */
@Composable
fun DownloadStatus(state: LangDownloads.State?, color: androidx.compose.ui.graphics.Color) {
    if (state == null) return
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        if (state.running) {
            if (state.fraction >= 0f) {
                LinearProgressIndicator(progress = { state.fraction.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth(), color = color)
            } else {
                LinearProgressIndicator(Modifier.fillMaxWidth(), color = color)
            }
        }
        if (state.label.isNotBlank()) {
            Text(
                state.label + if (state.running) " · continue même appli fermée" else "",
                fontSize = 12.sp,
                color = when {
                    state.error != null -> Bad
                    state.finished -> Good
                    else -> InkSoft
                }
            )
        }
    }
}
