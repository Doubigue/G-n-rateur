package com.linguavibe.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AssistChip
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linguavibe.app.data.ConjTable
import com.linguavibe.app.data.ConjTense
import com.linguavibe.app.data.Conjugator
import com.linguavibe.app.data.LanguageInfo
import com.linguavibe.app.data.Languages
import com.linguavibe.app.speech.SpokenTexts
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val ConjBlue = Color(0xFF1E6F8E)
private val PERSONS_ALL = listOf("yo", "tú", "él / ella / usted", "nosotros", "vosotros", "ellos / ellas / ustedes")
private val PERSONS_IMP_ALL = listOf("", "tú", "usted", "nosotros", "vosotros", "ustedes")
private val IrregularRed = Color(0xFFC0392B)

/** Le conjugueur : tapez n'importe quel verbe espagnol, il s'affiche à tous les temps. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ConjugatorScreen(onBack: () -> Unit, start: String = "") {
    val context = LocalContext.current
    val lang = Languages.byCode("es")
    val focus = LocalFocusManager.current
    var query by rememberSaveable { mutableStateOf(start) }
    var shown by rememberSaveable { mutableStateOf(start) }
    var suggestions by androidx.compose.runtime.remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var result by androidx.compose.runtime.remember { mutableStateOf<Conjugator.Result?>(null) }
    var error by androidx.compose.runtime.remember { mutableStateOf<String?>(null) }
    var total by androidx.compose.runtime.remember { mutableStateOf(0) }

    LaunchedEffect(Unit) { total = withContext(Dispatchers.IO) { Conjugator.count(context) } }
    LaunchedEffect(query) {
        suggestions = withContext(Dispatchers.Default) { Conjugator.suggest(context, query) }
    }
    LaunchedEffect(shown) {
        if (shown.isBlank()) { result = null; error = null; return@LaunchedEffect }
        val r = withContext(Dispatchers.Default) { Conjugator.conjugate(context, shown) }
        result = r
        error = if (r == null) "« $shown » n'est pas un infinitif espagnol (il doit finir par -ar, -er, -ir, ou -arse, -erse, -irse)." else null
    }

    fun go(v: String) {
        query = v; shown = v; focus.clearFocus()
    }

    Column(Modifier.fillMaxSize()) {
        TopBar("Conjugueur espagnol", "N'importe quel verbe, à tous les temps", ConjBlue, onBack)
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                CardBox {
                    Text("Quel verbe voulez-vous conjuguer ?", style = PosterTitle, fontSize = 18.sp, color = Ink)
                    Text(
                        "Tapez un infinitif (tener, levantarse…) ou un mot français (manger). " +
                            if (total > 0) "$total verbes dans la base, et tous les verbes réguliers." else "",
                        fontSize = 12.sp, color = InkSoft
                    )
                    OutlinedTextField(
                        value = query, onValueChange = { query = it }, singleLine = true,
                        label = { Text("Verbe à l'infinitif") }, modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { go(query.trim()) })
                    )
                    if (suggestions.isNotEmpty() && query != shown) {
                        suggestions.forEach { (v, fr) ->
                            Row(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable { go(v) }.padding(horizontal = 8.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(v, fontWeight = FontWeight.Bold, color = ConjBlue, modifier = Modifier.weight(0.45f))
                                Text(fr, fontSize = 13.sp, color = InkSoft, modifier = Modifier.weight(0.55f))
                            }
                        }
                    }
                    PillButton("Conjuguer", Art.icBook, ConjBlue, Modifier.fillMaxWidth(), enabled = query.isNotBlank()) { go(query.trim()) }
                    if (shown.isBlank()) {
                        Text("Essayez :", fontSize = 12.sp, color = InkSoft)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("ser", "ir", "tener", "hacer", "levantarse", "construir", "conducir", "dormir", "enviar", "reír").forEach {
                                AssistChip(onClick = { go(it) }, label = { Text(it) })
                            }
                        }
                    }
                }
            }
            error?.let { e -> item { CardBox { Text(e, color = Bad, fontSize = 14.sp) } } }
            result?.let { r ->
                item { ConjugationHeader(r.table, lang, ConjBlue, r.known, r.reflexive) }
                items(r.table.tenses.map { it.mood }.distinct()) { mood ->
                    MoodBlock(mood, r.table.tenses.filter { it.mood == mood }, lang, ConjBlue)
                }
            }
        }
    }
}

@Composable
private fun ConjugationHeader(t: ConjTable, lang: LanguageInfo, color: Color, known: Boolean, reflexive: Boolean) {
    val speaker = LocalSpeaker.current
    CardBox {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(t.verb, style = PosterTitle, fontSize = 32.sp, color = color)
                if (t.translation.isNotBlank()) Text(t.translation, fontSize = 15.sp, color = Ink, fontWeight = FontWeight.SemiBold)
                Text("Verbe en ${t.group}${if (reflexive) " · pronominal" else ""} · gérondif ${t.gerund} · participe ${t.participle}", fontSize = 12.sp, color = InkSoft)
            }
            PillButton("Écouter", Art.icVoice, color, filled = false) { speaker.speak(t.verb, lang.locale) }
        }
        val irr = t.tenses.sumOf { tt -> tt.forms.indices.count { tt.isIrregular(it) } }
        Text(
            when {
                !known -> "⚠ " + t.note
                irr == 0 -> "Verbe régulier : il suit exactement la règle de son groupe."
                else -> "$irr formes irrégulières (en rouge). Touchez une forme pour l'écouter."
            },
            fontSize = 13.sp, color = if (!known) Bad else Ink,
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(color.copy(alpha = 0.08f)).padding(12.dp)
        )
        if (known && reflexive && t.note.isNotBlank()) Text(t.note, fontSize = 12.sp, color = InkSoft)
    }
}

/** Un mode (Indicatif, Subjonctif…) : tous ses temps, chacun dans une petite carte. */
@Composable
fun MoodBlock(mood: String, tenses: List<ConjTense>, lang: LanguageInfo, color: Color) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(mood.uppercase(), fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp, color = color)
        tenses.chunked(2).forEach { pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                pair.forEach { TenseMiniCard(it, lang, color, Modifier.weight(1f)) }
                if (pair.size == 1) androidx.compose.foundation.layout.Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
fun TenseMiniCard(t: ConjTense, lang: LanguageInfo, color: Color, modifier: Modifier = Modifier) {
    val speaker = LocalSpeaker.current
    var showRule by rememberSaveable(t.id) { mutableStateOf(false) }
    Column(
        modifier.clip(RoundedCornerShape(16.dp)).background(Color.White).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        Text(t.name, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Ink, modifier = Modifier.clickable { showRule = !showRule })
        Text(t.nameEs, fontSize = 11.sp, fontStyle = FontStyle.Italic, color = InkSoft)
        t.forms.forEachIndexed { i, f ->
            if (f != "—") {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).clickable { speaker.speak(SpokenTexts.conjugated(t, i), lang.locale) }.padding(vertical = 2.dp)
                ) {
                    Text(
                        (if (t.isImperative) PERSONS_IMP_ALL else PERSONS_ALL)[i].substringBefore(" /"),
                        fontSize = 11.sp, color = InkSoft, modifier = Modifier.weight(0.38f)
                    )
                    Text(f, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = if (t.isIrregular(i)) IrregularRed else Ink, modifier = Modifier.weight(0.62f))
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("▶ Écouter", fontSize = 12.sp, color = color, fontWeight = FontWeight.Bold, modifier = Modifier.clickable {
                speaker.speakAll(t.forms.indices.filter { t.forms[it] != "—" }.map { SpokenTexts.conjugated(t, it) }, lang.locale)
            })
            Text(if (showRule) "Masquer la règle" else "Règle", fontSize = 12.sp, color = InkSoft, modifier = Modifier.clickable { showRule = !showRule })
        }
        if (showRule) Text(t.rule, fontSize = 11.sp, lineHeight = 15.sp, color = Ink)
    }
}

/** Tous les temps d'un tableau, groupés par mode (pour la vue d'ensemble des leçons du MODEL 4). */
@Composable
fun AllTenses(table: ConjTable, lang: LanguageInfo, color: Color) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        table.tenses.map { it.mood }.distinct().forEach { mood ->
            MoodBlock(mood, table.tenses.filter { it.mood == mood }, lang, color)
        }
    }
}
