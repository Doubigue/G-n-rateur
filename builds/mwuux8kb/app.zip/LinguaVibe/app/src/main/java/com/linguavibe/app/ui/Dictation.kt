package com.linguavibe.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linguavibe.app.data.LanguageInfo
import com.linguavibe.app.data.Lesson
import com.linguavibe.app.speech.Pronunciation
import com.linguavibe.app.study.StudyStore
import kotlinx.coroutines.delay

/** Une phrase de dictée et sa traduction. */
data class DictationLine(val text: String, val translation: String)

/** Phrases de la leçon adaptées à la dictée (3 à 14 mots). */
fun dictationLines(lesson: Lesson): List<DictationLine> = buildList {
    lesson.phrases.forEach { add(DictationLine(it.text, it.translation)) }
    lesson.dialogue.forEach { add(DictationLine(it.text, it.translation)) }
    lesson.scenes.forEach { sc -> sc.lines.forEach { add(DictationLine(it.text, it.translation)) } }
    lesson.reading?.sentences?.forEach { add(DictationLine(it.text, it.translation)) }
    lesson.vocab.forEach { if (it.example.isNotBlank()) add(DictationLine(it.example, it.exampleTr)) }
}.filter { it.text.split(" ").size in 3..14 }.distinctBy { it.text }

/** État d'un mot attendu après correction. */
enum class WordMark { Ok, Accent, Wrong }

private fun plainWord(w: String) = w.lowercase().filter { it.isLetterOrDigit() }

/**
 * Correction mot à mot : alignement des mots tapés sur les mots attendus (plus longue sous-suite commune).
 * Un mot juste à un accent près est marqué [WordMark.Accent].
 */
fun correctDictation(expected: String, typed: String, lang: String): List<Pair<String, WordMark>> {
    val exp = expected.split(Regex("\\s+")).filter { it.isNotBlank() }
    val got = typed.split(Regex("\\s+")).filter { it.isNotBlank() }
    val ke = exp.map { Pronunciation.matchKey(it, lang) }
    val kg = got.map { Pronunciation.matchKey(it, lang) }
    val n = ke.size; val m = kg.size
    val dp = Array(n + 1) { IntArray(m + 1) }
    for (i in n - 1 downTo 0) for (j in m - 1 downTo 0) {
        dp[i][j] = if (ke[i].isNotEmpty() && ke[i] == kg[j]) dp[i + 1][j + 1] + 1 else maxOf(dp[i + 1][j], dp[i][j + 1])
    }
    val marks = MutableList(n) { WordMark.Wrong }
    var i = 0; var j = 0
    while (i < n && j < m) {
        when {
            ke[i].isNotEmpty() && ke[i] == kg[j] -> {
                marks[i] = if (plainWord(exp[i]) == plainWord(got[j])) WordMark.Ok else WordMark.Accent
                i++; j++
            }
            dp[i + 1][j] >= dp[i][j + 1] -> i++
            else -> j++
        }
    }
    // Les signes seuls (¿ ¡ —) ne comptent pas.
    exp.forEachIndexed { k, w -> if (ke[k].isEmpty()) marks[k] = WordMark.Ok }
    return exp.zip(marks)
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DictationSession(lesson: Lesson, lang: LanguageInfo, color: Color, onClose: () -> Unit, onNext: () -> Unit) {
    val context = LocalContext.current
    val speaker = LocalSpeaker.current
    val lines = remember(lesson.id) { dictationLines(lesson).shuffled().take(10) }
    if (lines.isEmpty()) {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("Pas assez de phrases pour une dictée dans cette leçon.", fontSize = 16.sp, color = InkSoft)
            PillButton("Retour au quiz", Art.icRefresh, color) { onClose() }
        }
        return
    }
    var index by remember(lesson.id) { mutableIntStateOf(0) }
    var total by remember(lesson.id) { mutableIntStateOf(0) }
    var finished by remember(lesson.id) { mutableStateOf(false) }

    if (finished) {
        val score = total / lines.size
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ScoreRing(score, 120.dp)
            Text(if (score >= 80) "Excellente dictée !" else "Continuez à vous entraîner", style = PosterTitle, fontSize = 26.sp, color = Ink)
            Text("Les phrases ratées sont ajoutées à votre révision du jour.", fontSize = 14.sp, color = InkSoft, textAlign = TextAlign.Center)
            PillButton("Nouvelle dictée", Art.icRefresh, color, Modifier.fillMaxWidth(), filled = false) {
                index = 0; total = 0; finished = false
            }
            PillButton("Retour au quiz", Art.icPlay, color, Modifier.fillMaxWidth(), filled = false) { onClose() }
            NextButton("Faire le devoir", color, onNext)
        }
        return
    }

    val line = lines[index]
    var input by remember(lesson.id, index) { mutableStateOf("") }
    var result by remember(lesson.id, index) { mutableStateOf<List<Pair<String, WordMark>>?>(null) }
    var showTr by remember(lesson.id, index) { mutableStateOf(false) }
    LaunchedEffect(lesson.id, index) { delay(400); speaker.speak(line.text, lang.locale) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        AnimatedBar(index.toFloat() / lines.size, color)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Dictée ${index + 1}", style = PosterTitle, fontSize = 18.sp, color = Ink)
            Text(" / ${lines.size}", style = AccentText, fontSize = 15.sp, color = InkSoft)
            Spacer(Modifier.weight(1f))
            Text("✕", Modifier.clip(RoundedCornerShape(50)).clickable { onClose() }.padding(6.dp), fontSize = 18.sp, color = InkSoft)
        }
        Text("Écoutez la phrase et écrivez-la avec les accents et la ponctuation.", fontSize = 14.sp, color = InkSoft)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PillButton("Écouter", Art.icVoice, color, Modifier.weight(1f)) { speaker.speak(line.text, lang.locale) }
            PillButton("Lentement", Art.icSlow, color, Modifier.weight(1f), filled = false) { speaker.speak(line.text, lang.locale, slow = true) }
        }
        if (line.translation.isNotBlank()) {
            if (showTr || result != null) Text(line.translation, fontSize = 14.sp, fontStyle = FontStyle.Italic, color = InkSoft)
            else Text("Voir le sens en français", Modifier.clickable { showTr = true }, fontSize = 13.sp, color = color, fontWeight = FontWeight.Bold)
        }
        OutlinedTextField(
            value = input, onValueChange = { input = it }, enabled = result == null,
            modifier = Modifier.fillMaxWidth(), label = { Text("Ce que vous entendez") }, minLines = 2
        )
        val r = result
        if (r == null) {
            PillButton("Corriger", Art.icCheck, color, Modifier.fillMaxWidth(), enabled = input.isNotBlank()) {
                val marks = correctDictation(line.text, input, lang.code)
                result = marks
                val pct = marks.count { it.second != WordMark.Wrong } * 100 / marks.size.coerceAtLeast(1)
                total += pct
                val ok = pct >= 80
                StudyStore.recordAnswer(context, ok)
                if (!ok) StudyStore.addCard(context, lang.code, "Dictée : ${line.translation.ifBlank { "écrivez la phrase entendue" }}", line.text, line.text, lesson.title)
            }
        } else {
            val good = r.count { it.second != WordMark.Wrong }
            val pct = good * 100 / r.size.coerceAtLeast(1)
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color.White).padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("$pct % · $good mots justes sur ${r.size}", fontWeight = FontWeight.Bold, color = if (pct >= 80) Good else Bad)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    r.forEach { (w, mark) ->
                        val c = when (mark) { WordMark.Ok -> Good; WordMark.Accent -> Gold; WordMark.Wrong -> Bad }
                        Text(
                            w, Modifier.clip(RoundedCornerShape(8.dp)).background(c.copy(alpha = 0.16f)).padding(horizontal = 8.dp, vertical = 4.dp),
                            fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = if (mark == WordMark.Accent) Ink else c
                        )
                    }
                }
                Text("Vert : juste · Jaune : accent ou majuscule à revoir · Rouge : mot manquant ou faux", fontSize = 12.sp, color = InkSoft)
            }
            PillButton(if (index >= lines.lastIndex) "Voir le résultat" else "Phrase suivante", Art.icPlay, color, Modifier.fillMaxWidth()) {
                if (index >= lines.lastIndex) finished = true else index++
            }
        }
    }
}
