package com.linguavibe.app.export

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.StaticLayout
import android.text.TextPaint
import androidx.compose.ui.graphics.toArgb
import androidx.core.content.res.ResourcesCompat
import androidx.core.graphics.ColorUtils
import com.linguavibe.app.R
import com.linguavibe.app.data.DialogueLine
import com.linguavibe.app.data.LanguageInfo
import com.linguavibe.app.data.Lesson
import com.linguavibe.app.data.Levels
import com.linguavibe.app.data.QuizItem
import com.linguavibe.app.ui.levelColor
import com.linguavibe.app.ui.posterTheme
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

private const val PW = 595
private const val PH = 842
private const val MARGIN = 40f
private const val CW = 515f
private const val TOP = 34f
private const val BOTTOM = 800f

private val INK = 0xFF101A3A.toInt()
private val INK_SOFT = 0xFF5D6380.toInt()
private val NIGHT = 0xFF0B1230.toInt()
private val GOLD = 0xFFF5B800.toInt()
private val BUBBLE = 0xFFF1EEE6.toInt()

/**
 * Export PDF des cours : couverture, sommaire, puis pour chaque leçon un bandeau coloré par niveau,
 * le vocabulaire, la grammaire, le dialogue, la lecture, les phrases utiles, le quiz avec son corrigé et les devoirs.
 * Utilise uniquement l'API PdfDocument d'Android (aucune bibliothèque externe).
 */
object PdfExporter {

    /** Une seule leçon. */
    fun exportLesson(context: Context, lang: LanguageInfo, courseLabel: String, lesson: Lesson, out: OutputStream) {
        val doc = PdfDocument()
        try {
            val pdf = PdfPages(context, doc, footerOf(lang, courseLabel), levelColor(lesson.level).toArgb())
            pdf.lesson(lesson)
            pdf.endPage()
            doc.writeTo(out)
            out.flush()
        } finally {
            doc.close()
        }
    }

    /** Un cours complet : couverture, sommaire avec numéros de page, toutes les leçons. */
    fun exportCourse(context: Context, lang: LanguageInfo, courseLabel: String, lessons: List<Lesson>, out: OutputStream) {
        // Premier passage (document jeté) pour connaître la page de départ de chaque leçon.
        val starts = HashMap<String, Int>()
        val scratch = PdfDocument()
        try {
            render(context, scratch, lang, courseLabel, lessons, emptyMap(), starts)
        } finally {
            scratch.close()
        }
        val doc = PdfDocument()
        try {
            render(context, doc, lang, courseLabel, lessons, starts, HashMap())
            doc.writeTo(out)
            out.flush()
        } finally {
            doc.close()
        }
    }

    private fun footerOf(lang: LanguageInfo, courseLabel: String) =
        "LinguaVibe · ${lang.name}" + if (courseLabel.isBlank()) "" else " · $courseLabel"

    private fun render(
        context: Context, doc: PdfDocument, lang: LanguageInfo, courseLabel: String, lessons: List<Lesson>,
        known: Map<String, Int>, starts: MutableMap<String, Int>
    ) {
        val theme = posterTheme(lang.code)
        val pdf = PdfPages(context, doc, footerOf(lang, courseLabel), theme.start.toArgb())
        val levels = lessons.map { it.level }.distinct().sortedBy { Levels.order.indexOf(it) }
        val range = if (levels.size > 1) "${levels.first()} à ${levels.last()}" else levels.firstOrNull().orEmpty()
        pdf.cover(
            lang.name, lang.nativeName,
            listOfNotNull(
                courseLabel.takeIf { it.isNotBlank() },
                "${lessons.size} leçons",
                range.takeIf { it.isNotBlank() }
            ).joinToString("  ·  "),
            theme.start.toArgb(), theme.end.toArgb()
        )
        pdf.toc(lessons, known)
        lessons.forEach { l ->
            starts[l.id] = pdf.pageNo + 1
            pdf.lesson(l)
        }
        pdf.endPage()
    }
}

// ============================================================================ Mise en page

private class Fonts(private val context: Context) {
    private fun load(id: Int): Typeface = (try {
        ResourcesCompat.getFont(context, id)
    } catch (_: Exception) {
        null
    }) ?: Typeface.DEFAULT

    val regular = load(R.font.poppins_regular)
    val medium = load(R.font.poppins_medium)
    val bold = load(R.font.poppins_bold)
    val display = load(R.font.display_extrabold)
    val accent = load(R.font.accent_italic)
}

private fun textPaint(size: Float, color: Int, face: Typeface): TextPaint =
    TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = size
        this.color = color
        typeface = face
    }

/** Écrit les pages une par une, avec saut de page automatique. */
private class PdfPages(
    private val context: Context,
    private val doc: PdfDocument,
    private val footerLabel: String,
    private var accent: Int
) {
    private val fonts = Fonts(context)
    private var page: PdfDocument.Page? = null
    private lateinit var canvas: Canvas
    private var y = TOP
    private var withChrome = true
    var pageNo = 0
        private set

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

    private val pBody = textPaint(11.5f, INK, fonts.regular)
    private val pBodyBold = textPaint(11.5f, INK, fonts.bold)
    private val pWord = textPaint(12.5f, INK, fonts.bold)
    private val pPron = textPaint(10.5f, INK_SOFT, fonts.accent)
    private val pSmall = textPaint(10.5f, INK_SOFT, fonts.regular)
    private val pFoot = textPaint(8.5f, INK_SOFT, fonts.regular)
    private val pFootRight = textPaint(8.5f, INK_SOFT, fonts.regular).apply { textAlign = Paint.Align.RIGHT }
    private val pTag = textPaint(9.5f, 0xFFFFFFFF.toInt(), fonts.bold).apply { letterSpacing = 0.12f }
    private val pTitle = textPaint(25f, 0xFFFFFFFF.toInt(), fonts.display)
    private val pTitleSub = textPaint(13f, GOLD, fonts.accent)
    private val pH2 = textPaint(15f, INK, fonts.bold)
    private val pTocRight = textPaint(11f, INK_SOFT, fonts.medium).apply { textAlign = Paint.Align.RIGHT }

    // ---------------------------------------------------------------- Pages

    fun newPage(chrome: Boolean = true) {
        endPage()
        pageNo++
        val p = doc.startPage(PdfDocument.PageInfo.Builder(PW, PH, pageNo).create())
        page = p
        canvas = p.canvas
        withChrome = chrome
        if (chrome) {
            fill.shader = null
            fill.color = accent
            canvas.drawRect(0f, 0f, PW.toFloat(), 9f, fill)
        }
        y = TOP
    }

    fun endPage() {
        val p = page ?: return
        if (withChrome) {
            stroke.color = 0xFFE3DCC8.toInt()
            stroke.strokeWidth = 0.8f
            canvas.drawLine(MARGIN, PH - 38f, PW - MARGIN, PH - 38f, stroke)
            canvas.drawText(footerLabel, MARGIN, PH - 24f, pFoot)
            canvas.drawText("$pageNo", PW - MARGIN, PH - 24f, pFootRight)
        }
        doc.finishPage(p)
        page = null
    }

    private fun need(h: Float) {
        if (y + h > BOTTOM) newPage()
    }

    private fun lay(text: String, paint: TextPaint, width: Float): StaticLayout =
        StaticLayout.Builder.obtain(text, 0, text.length, paint, width.toInt().coerceAtLeast(10))
            .setLineSpacing(0f, 1.18f)
            .setIncludePad(false)
            .build()

    private fun put(l: StaticLayout, x: Float, top: Float) {
        canvas.save()
        canvas.translate(x, top)
        l.draw(canvas)
        canvas.restore()
    }

    private fun rect(x: Float, top: Float, w: Float, h: Float, radius: Float, color: Int) {
        fill.shader = null
        fill.color = color
        canvas.drawRoundRect(RectF(x, top, x + w, top + h), radius, radius, fill)
    }

    private fun tint(alpha: Int = 26) = ColorUtils.setAlphaComponent(accent, alpha)
    private fun darker(c: Int) = ColorUtils.blendARGB(c, NIGHT, 0.42f)

    /** Paragraphe qui peut se couper d'une page à l'autre. */
    private fun flow(l: StaticLayout, x: Float = MARGIN) {
        var line = 0
        val n = l.lineCount
        while (line < n) {
            var end = line
            val avail = BOTTOM - y
            while (end < n && l.getLineBottom(end) - l.getLineTop(line) <= avail) end++
            if (end == line) {
                newPage()
                continue
            }
            val top = l.getLineTop(line).toFloat()
            val bottom = l.getLineBottom(end - 1).toFloat()
            canvas.save()
            canvas.translate(x, y - top)
            canvas.clipRect(0f, top, l.width.toFloat(), bottom)
            l.draw(canvas)
            canvas.restore()
            y += bottom - top
            line = end
            if (line < n) newPage()
        }
    }

    private fun paragraph(text: String, paint: TextPaint, x: Float = MARGIN, width: Float = CW, after: Float = 6f) {
        if (text.isBlank()) return
        flow(lay(text, paint, width), x)
        y += after
    }

    // ---------------------------------------------------------------- Couverture et sommaire

    fun cover(title: String, native: String, line: String, start: Int, end: Int) {
        newPage(chrome = false)
        fill.shader = LinearGradient(0f, 0f, PW.toFloat(), PH.toFloat(), start, end, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, PW.toFloat(), PH.toFloat(), fill)
        fill.shader = null
        fill.color = ColorUtils.setAlphaComponent(0xFFFFFFFF.toInt(), 22)
        canvas.drawCircle(PW - 40f, 120f, 190f, fill)
        canvas.drawCircle(60f, PH - 150f, 230f, fill)
        fill.color = ColorUtils.setAlphaComponent(GOLD, 70)
        canvas.drawCircle(PW - 120f, PH - 260f, 90f, fill)

        val brand = textPaint(12f, GOLD, fonts.bold).apply { letterSpacing = 0.35f }
        put(lay("LINGUAVIBE", brand, CW), MARGIN + 10, 150f)
        val big = textPaint(54f, 0xFFFFFFFF.toInt(), fonts.display)
        val t = lay(title, big, CW - 20)
        put(t, MARGIN + 10, 185f)
        val nat = lay(native, textPaint(24f, GOLD, fonts.accent), CW - 20)
        put(nat, MARGIN + 10, 185f + t.height + 8f)
        rect(MARGIN + 10, 185f + t.height + nat.height + 34f, 64f, 5f, 3f, GOLD)
        val info = lay("Cours complet", textPaint(18f, 0xFFFFFFFF.toInt(), fonts.bold), CW - 20)
        put(info, MARGIN + 10, 185f + t.height + nat.height + 56f)
        val sub = lay(line, textPaint(13f, ColorUtils.setAlphaComponent(0xFFFFFFFF.toInt(), 215), fonts.regular), CW - 20)
        put(sub, MARGIN + 10, 185f + t.height + nat.height + 56f + info.height + 6f)
        val date = SimpleDateFormat("d MMMM yyyy", Locale.FRENCH).format(Date())
        put(lay(date, textPaint(11f, ColorUtils.setAlphaComponent(0xFFFFFFFF.toInt(), 200), fonts.regular), CW), MARGIN + 10, PH - 70f)
    }

    fun toc(lessons: List<Lesson>, pages: Map<String, Int>) {
        accent = 0xFF14215B.toInt()
        newPage()
        section("Sommaire")
        lessons.forEach { l ->
            need(22f)
            fill.shader = null
            fill.color = levelColor(l.level).toArgb()
            canvas.drawCircle(MARGIN + 5f, y + 8f, 4f, fill)
            val label = "${l.level} · ${l.number}. ${l.title}"
            val tl = lay(label, pBody, CW - 60f)
            put(tl, MARGIN + 18f, y + 1f)
            canvas.drawText("${pages[l.id] ?: ""}", PW - MARGIN, y + 13f, pTocRight)
            y += max(tl.height + 6f, 20f)
        }
    }

    // ---------------------------------------------------------------- Éléments

    private fun section(title: String) {
        need(90f)
        y += 8f
        val l = lay(title.uppercase(), pTag, 420f)
        val w = l.getLineWidth(0) + 26f
        val h = l.height + 11f
        rect(MARGIN, y, w, h, h / 2, accent)
        put(l, MARGIN + 13f, y + 5.5f)
        y += h + 10f
    }

    private fun pairRow(left: String, leftSub: String, right: String, extras: List<Pair<String, TextPaint>>, shade: Boolean) {
        val pad = 10f
        val inner = CW - 2 * pad
        val lw = inner * 0.45f
        val rw = inner - lw - 12f
        val a = lay(left, pWord, lw)
        val b = if (leftSub.isBlank()) null else lay(leftSub, pPron, lw)
        val r = lay(right, pBody, rw)
        val ex = extras.filter { it.first.isNotBlank() }.map { lay(it.first, it.second, inner) }
        val leftH = a.height + (b?.height ?: 0) + if (b != null) 2 else 0
        val exH = ex.sumOf { it.height } + 2 * ex.size
        val h = pad * 2 + max(leftH, r.height) + (if (ex.isEmpty()) 0f else exH + 4f)
        need(h)
        if (shade) rect(MARGIN, y, CW, h, 9f, tint(18))
        put(a, MARGIN + pad, y + pad)
        if (b != null) put(b, MARGIN + pad, y + pad + a.height + 2f)
        put(r, MARGIN + pad + lw + 12f, y + pad)
        var ey = y + pad + max(leftH, r.height) + 4f
        ex.forEach {
            put(it, MARGIN + pad, ey)
            ey += it.height + 2f
        }
        y += h + 3f
    }

    private fun bubble(line: DialogueLine) {
        val w = CW * 0.8f
        val pad = 10f
        val inner = w - 2 * pad
        val whoText = when {
            line.name.isNotBlank() -> line.name.uppercase() + if (line.isUser) " · VOUS" else ""
            line.isUser -> "B · VOUS"
            else -> "A"
        }
        val who = lay(whoText, textPaint(8.5f, if (line.isUser) accent else INK_SOFT, fonts.bold), inner)
        val t = lay(line.text, pWord, inner)
        val p = if (line.pron.isBlank()) null else lay(line.pron, pPron, inner)
        val tr = if (line.translation.isBlank()) null else lay(line.translation, pSmall, inner)
        val h = pad * 2 + who.height + 2f + t.height + (p?.height ?: 0) + (tr?.height ?: 0) + 4f
        need(h)
        val x = if (line.isUser) MARGIN + CW - w else MARGIN
        rect(x, y, w, h, 12f, if (line.isUser) tint(40) else BUBBLE)
        var yy = y + pad
        put(who, x + pad, yy); yy += who.height + 2f
        put(t, x + pad, yy); yy += t.height
        if (p != null) { put(p, x + pad, yy); yy += p.height }
        if (tr != null) { put(tr, x + pad, yy + 2f) }
        y += h + 6f
    }

    /** Ligne avec une barre colorée à gauche : exemples de grammaire, phrases de lecture. */
    private fun barRow(text: String, pron: String, translation: String) {
        val x = MARGIN + 14f
        val w = CW - 14f
        val a = lay(text, pBodyBold, w)
        val b = if (pron.isBlank()) null else lay(pron, pPron, w)
        val c = if (translation.isBlank()) null else lay(translation, pSmall, w)
        val h = a.height + (b?.height ?: 0) + (c?.height ?: 0) + 4f
        need(h + 4f)
        rect(MARGIN + 2f, y, 3f, h, 1.5f, accent)
        var yy = y
        put(a, x, yy); yy += a.height
        if (b != null) { put(b, x, yy); yy += b.height }
        if (c != null) put(c, x, yy)
        y += h + 6f
    }

    // ---------------------------------------------------------------- Une leçon

    fun lesson(l: Lesson) {
        accent = levelColor(l.level).toArgb()
        newPage()

        // Bandeau de titre
        val inner = CW - 44f
        val tag = lay("${l.level} · ${Levels.label(l.level).uppercase()} · LEÇON ${l.number}", pTag, inner)
        val title = lay(l.title, pTitle, inner)
        val sub = if (l.titleTr.isBlank()) null else lay(l.titleTr, pTitleSub, inner)
        val h = 22f + tag.height + 8f + title.height + (sub?.let { it.height + 4f } ?: 0f) + 22f
        fill.shader = LinearGradient(MARGIN, y, MARGIN + CW, y + h, accent, darker(accent), Shader.TileMode.CLAMP)
        canvas.drawRoundRect(RectF(MARGIN, y, MARGIN + CW, y + h), 20f, 20f, fill)
        fill.shader = null
        fill.color = ColorUtils.setAlphaComponent(0xFFFFFFFF.toInt(), 28)
        canvas.drawCircle(MARGIN + CW - 30f, y + 20f, 70f, fill)
        var yy = y + 22f
        put(tag, MARGIN + 22f, yy); yy += tag.height + 8f
        put(title, MARGIN + 22f, yy); yy += title.height + 4f
        if (sub != null) put(sub, MARGIN + 22f, yy)
        y += h + 14f

        if (l.intro.isNotBlank()) {
            val il = lay(l.intro, pBody, CW - 28f)
            if (il.height + 24f < BOTTOM - TOP) {
                need(il.height + 24f)
                rect(MARGIN, y, CW, il.height + 24f, 12f, tint(22))
                put(il, MARGIN + 14f, y + 12f)
                y += il.height + 34f
            } else paragraph(l.intro, pBody)
        }

        l.conjugations.forEach { c ->
            section("Conjugaison de ${c.verb} · ${c.translation}")
            pairRow("Gérondif / participe", "", "${c.gerund} · ${c.participle}", listOf(c.note to pSmall), shade = true)
            val persons = listOf("yo", "tú", "él", "nosotros", "vosotros", "ellos")
            val impPersons = listOf("", "tú", "usted", "nosotros", "vosotros", "ustedes")
            c.tenses.forEachIndexed { i, t ->
                val who = if (t.isImperative) impPersons else persons
                val forms = t.forms.mapIndexedNotNull { k, f -> if (f == "—") null else "${who[k]} $f".trim() }.joinToString(" · ")
                pairRow(t.name, t.nameEs, forms, emptyList(), shade = i % 2 == 1)
            }
        }

        if (l.vocab.isNotEmpty()) {
            section("Vocabulaire · ${l.vocab.size} mots")
            l.vocab.forEachIndexed { i, v ->
                pairRow(
                    v.word, v.pron, v.translation,
                    listOf(v.example to pBody, v.examplePron to pPron, v.exampleTr to pSmall),
                    shade = i % 2 == 0
                )
            }
        }

        if (l.grammar.isNotEmpty()) {
            section("Grammaire")
            l.grammar.forEach { g ->
                need(70f)
                paragraph(g.title, pH2, after = 3f)
                paragraph(g.explanation, pBody, after = 6f)
                g.examples.forEach { barRow(it.text, it.pron, it.translation) }
                y += 6f
            }
        }

        if (l.scenes.isNotEmpty()) {
            section("Dialogues")
            l.scenes.forEachIndexed { i, sc ->
                need(60f)
                paragraph("Scène ${i + 1} · ${sc.title}", pH2, after = 2f)
                if (sc.titleTr.isNotBlank()) paragraph(sc.titleTr, pPron, after = 3f)
                if (sc.context.isNotBlank()) paragraph(sc.context, pBody, after = 6f)
                sc.lines.forEach { bubble(it) }
                y += 6f
            }
        } else if (l.dialogue.isNotEmpty()) {
            section("Dialogue")
            l.dialogue.forEach { bubble(it) }
        }

        l.reading?.let { r ->
            if (r.sentences.isNotEmpty()) {
                section("Lecture")
                paragraph(r.title, pH2, after = 2f)
                paragraph(r.titleTr, pPron, after = 8f)
                r.sentences.forEach { barRow(it.text, it.pron, it.translation) }
            }
        }

        if (l.phrases.isNotEmpty()) {
            section("Phrases utiles")
            l.phrases.forEachIndexed { i, p -> pairRow(p.text, p.pron, p.translation, emptyList(), shade = i % 2 == 0) }
        }

        if (l.quiz.isNotEmpty()) quiz(l.quiz)

        if (l.homework.isNotEmpty()) {
            section("Devoirs")
            l.homework.forEachIndexed { i, hw ->
                paragraph("${i + 1}. ${hw.prompt}", pBodyBold, after = 3f)
                if (hw.keywords.isNotEmpty()) paragraph("Mots-clés : " + hw.keywords.joinToString(", "), pPron, after = 4f)
                if (hw.model.isNotBlank()) {
                    val m = lay(hw.model, pBody, CW - 28f)
                    if (m.height + 38f < BOTTOM - TOP) {
                        need(m.height + 38f)
                        rect(MARGIN, y, CW, m.height + 34f, 12f, tint(22))
                        put(lay("EXEMPLE DE RÉPONSE", textPaint(8.5f, accent, fonts.bold).apply { letterSpacing = 0.1f }, CW), MARGIN + 14f, y + 9f)
                        put(m, MARGIN + 14f, y + 22f)
                        y += m.height + 44f
                    } else paragraph(hw.model, pBody)
                }
            }
        }
    }

    private fun quiz(items: List<QuizItem>) {
        section("Quiz · ${items.size} questions")
        val key = ArrayList<String>()
        items.forEachIndexed { i, q ->
            val n = i + 1
            val blocks = ArrayList<StaticLayout>()
            when (q) {
                is QuizItem.Mcq -> {
                    val options = (listOf(q.correct) + q.wrong).shuffled(java.util.Random(q.question.hashCode().toLong()))
                    blocks.add(lay("$n. ${q.question}", pBodyBold, CW))
                    options.forEachIndexed { j, o -> blocks.add(lay("${'A' + j})  $o", pBody, CW - 16f)) }
                    key.add("$n. ${'A' + options.indexOf(q.correct)} : ${q.correct}")
                }
                is QuizItem.Typed -> {
                    blocks.add(lay("$n. ${q.prompt}", pBodyBold, CW))
                    blocks.add(lay("Réponse : ________________________", pSmall, CW - 16f))
                    key.add("$n. ${q.answers.joinToString(" / ")}")
                }
                is QuizItem.Listen -> {
                    val options = (listOf(q.correct) + q.wrong).shuffled(java.util.Random(q.phrase.hashCode().toLong()))
                    blocks.add(lay("$n. Écoutez la phrase puis choisissez la bonne réponse.", pBodyBold, CW))
                    options.forEachIndexed { j, o -> blocks.add(lay("${'A' + j})  $o", pBody, CW - 16f)) }
                    key.add("$n. ${'A' + options.indexOf(q.correct)} : ${q.correct}  (phrase : ${q.phrase})")
                }
                is QuizItem.Order -> {
                    val mixed = q.words.shuffled(java.util.Random(q.words.hashCode().toLong()))
                    blocks.add(lay("$n. Remettez dans l'ordre : ${mixed.joinToString("  /  ")}", pBodyBold, CW))
                    if (q.translation.isNotBlank()) blocks.add(lay("(${q.translation})", pSmall, CW - 16f))
                    key.add("$n. ${q.words.joinToString(" ")}")
                }
                is QuizItem.Fill -> {
                    blocks.add(lay("$n. Complétez : ${q.sentence}", pBodyBold, CW))
                    if (q.wrong.isNotEmpty()) {
                        val options = (q.wrong + q.answers.first()).shuffled(java.util.Random(q.sentence.hashCode().toLong()))
                        blocks.add(lay(options.joinToString("   ·   "), pBody, CW - 16f))
                    }
                    key.add("$n. ${q.answers.first()}")
                }
                is QuizItem.Match -> {
                    blocks.add(lay("$n. Associez : " + q.pairs.joinToString("  ·  ") { it.first }, pBodyBold, CW))
                    blocks.add(lay(q.pairs.map { it.second }.shuffled(java.util.Random(q.pairs.hashCode().toLong())).joinToString("  ·  "), pBody, CW - 16f))
                    key.add("$n. " + q.pairs.joinToString(" ; ") { "${it.first} = ${it.second}" })
                }
                is QuizItem.Speak -> {
                    blocks.add(lay("$n. À dire à voix haute : ${q.text}", pBodyBold, CW))
                    key.add("$n. ${q.text}  (${q.translation})")
                }
                is QuizItem.Write -> {
                    blocks.add(lay("$n. ${q.prompt}", pBodyBold, CW))
                    blocks.add(lay("______________________________________________", pSmall, CW - 16f))
                    key.add("$n. Modèle : ${q.model}")
                }
            }
            val total = blocks.sumOf { it.height } + 2f * blocks.size + 6f
            need(total)
            blocks.forEachIndexed { j, b ->
                put(b, if (j == 0) MARGIN else MARGIN + 16f, y)
                y += b.height + 2f
            }
            y += 6f
        }
        need(60f)
        paragraph("CORRIGÉ", textPaint(9f, accent, fonts.bold).apply { letterSpacing = 0.12f }, after = 3f)
        paragraph(key.joinToString("\n"), pSmall, after = 8f)
    }
}
