package com.linguavibe.app.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linguavibe.app.data.LanguageInfo
import com.linguavibe.app.data.Languages
import com.linguavibe.app.data.Lesson
import com.linguavibe.app.data.PracticeSet
import com.linguavibe.app.data.ProgressStore
import com.linguavibe.app.data.QuizItem
import com.linguavibe.app.speech.Pronunciation
import com.linguavibe.app.speech.PronunciationResult
import com.linguavibe.app.speech.VoskManager
import com.linguavibe.app.study.StudyStore
import kotlinx.coroutines.delay

// =============================================================================
//  Quiz et ateliers interactifs.
//  - QuizStep : menu (série rapide, série complète, tout, mes erreurs, filtre par type),
//    série de questions avec série de bonnes réponses, bilan avec révision des erreurs.
//  - QuizQuestion : affiche n'importe quel type de question (choix, écrit, écoute, ordre,
//    phrase à trou, paires, oral au micro, rédaction) avec explication après la réponse.
//  - PracticeCard : atelier « À pratiquer » faisable directement dans la leçon.
// =============================================================================

/** Réponse attendue, en texte, pour le bilan et les corrigés. */
fun QuizItem.answerText(): String = when (this) {
    is QuizItem.Mcq -> correct
    is QuizItem.Typed -> answers.first()
    is QuizItem.Listen -> "$phrase = $correct"
    is QuizItem.Order -> words.joinToString(" ")
    is QuizItem.Fill -> sentence.replace("___", answers.first())
    is QuizItem.Match -> pairs.joinToString(" · ") { "${it.first} = ${it.second}" }
    is QuizItem.Speak -> text
    is QuizItem.Write -> model
}

/** Intitulé de la question, pour le bilan. */
fun QuizItem.promptText(): String = when (this) {
    is QuizItem.Mcq -> question
    is QuizItem.Typed -> prompt
    is QuizItem.Listen -> "Écoute : $phrase"
    is QuizItem.Order -> "Remettre dans l'ordre${if (translation.isNotBlank()) " : $translation" else ""}"
    is QuizItem.Fill -> sentence
    is QuizItem.Match -> title.ifBlank { "Associer les paires" }
    is QuizItem.Speak -> "Dire : $text"
    is QuizItem.Write -> prompt
}

/** Indice progressif : niveau 1 = premières lettres de chaque mot, 2 = moitié de chaque mot, 3 = tout sauf la fin. */
private fun hintOf(answer: String, level: Int): String = answer.split(" ").joinToString(" ") { w ->
    val letters = w.count { it.isLetter() }
    val keep = when (level) { 1 -> 1; 2 -> (letters + 1) / 2; else -> (letters - 1).coerceAtLeast(1) }
    var seen = 0
    w.map { c -> if (!c.isLetter()) c else if (seen++ < keep) c else '_' }.joinToString("")
}

private fun same(a: String, b: String, lang: String) = Pronunciation.matchKey(a, lang) == Pronunciation.matchKey(b, lang)

// ============================================================================= QuizStep

private enum class QuizMode(val label: String) { Quick("Série rapide"), Full("Série de 20"), All("Tout le quiz"), Mistakes("Mes erreurs"), Timed("Contre la montre"), Dictation("Dictée") }

/** Secondes par question en mode « Contre la montre ». */
private const val TIMED_SECONDS = 25

@Composable
internal fun QuizStep(
    lesson: Lesson, lang: LanguageInfo, color: Color, progress: ProgressStore, progressScope: String, onNext: () -> Unit
) {
    val bank = lesson.quiz
    if (bank.isEmpty()) {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("Cette leçon n'a pas encore de quiz.", fontSize = 16.sp, color = InkSoft)
            NextButton("Faire le devoir", color, onNext)
        }
        return
    }
    // Indices des questions ratées, gardés pendant la visite de la leçon.
    var mistakesRaw by rememberSaveable(lesson.id) { mutableStateOf("") }
    val mistakes = mistakesRaw.split(',').mapNotNull { it.toIntOrNull() }.filter { it in bank.indices }.distinct()
    var session by remember(lesson.id) { mutableStateOf<List<Int>?>(null) }
    var kindFilter by rememberSaveable(lesson.id) { mutableStateOf("Tous") }
    var timed by remember(lesson.id) { mutableStateOf(false) }
    var dictation by remember(lesson.id) { mutableStateOf(false) }
    if (dictation) {
        DictationSession(lesson, lang, color, onClose = { dictation = false }, onNext = onNext)
        return
    }

    val current = session
    if (current == null) {
        QuizMenu(bank, mistakes.size, kindFilter, color, onFilter = { kindFilter = it }) { mode ->
            if (mode == QuizMode.Dictation) { dictation = true; return@QuizMenu }
            val pool = bank.indices.filter { kindFilter == "Tous" || bank[it].kind == kindFilter }.ifEmpty { bank.indices.toList() }
            timed = mode == QuizMode.Timed
            session = when (mode) {
                QuizMode.Timed -> balanced(
                    pool.filter { bank[it] !is QuizItem.Speak && bank[it] !is QuizItem.Write }.ifEmpty { pool }, bank, 15
                )
                QuizMode.Quick -> balanced(pool, bank, 10)
                QuizMode.Full -> balanced(pool, bank, 20)
                QuizMode.All -> pool.shuffled()
                QuizMode.Mistakes -> mistakes.shuffled()
                QuizMode.Dictation -> emptyList()
            }
        }
        return
    }
    QuizSession(
        lesson, current, lang, color, progress, progressScope, timed,
        onFinish = { missed, played ->
            val kept = (mistakes.filter { it !in played } + missed).distinct()
            mistakesRaw = kept.joinToString(",")
        },
        onMenu = { session = null },
        onRetry = { session = it },
        onNext = onNext
    )
}

/** Tire [n] questions en mélangeant les types (pas trois fois le même type d'affilée si possible). */
private fun balanced(pool: List<Int>, bank: List<QuizItem>, n: Int): List<Int> {
    val byKind = pool.shuffled().groupBy { bank[it].kind }.mapValues { it.value.toMutableList() }.toMutableMap()
    val out = ArrayList<Int>()
    while (out.size < n && byKind.values.any { it.isNotEmpty() }) {
        for (k in byKind.keys.shuffled()) {
            val list = byKind[k] ?: continue
            if (list.isNotEmpty() && out.size < n) out.add(list.removeAt(0))
        }
    }
    return out.shuffled()
}

@Composable
private fun QuizMenu(
    bank: List<QuizItem>, mistakeCount: Int, filter: String, color: Color,
    onFilter: (String) -> Unit, onStart: (QuizMode) -> Unit
) {
    val kinds = remember(bank) { bank.groupingBy { it.kind }.eachCount() }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
                .background(Brush.linearGradient(listOf(color, color.copy(alpha = 0.78f))))
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text("QUIZ", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.5.sp, color = Color.White.copy(alpha = 0.85f))
            Text("${bank.size} questions", style = PosterTitle, fontSize = 28.sp, color = Color.White)
            Text(
                "Choix, écoute, phrases à remettre dans l'ordre, mots à compléter, paires, oral au micro et petites rédactions. " +
                    "Chaque série est tirée au hasard : refaites-la pour voir de nouvelles questions.",
                fontSize = 13.5.sp, lineHeight = 19.sp, color = Color.White.copy(alpha = 0.92f)
            )
        }
        Text("TYPE DE QUESTIONS", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.2.sp, color = InkSoft)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            QuizChip("Tous (${bank.size})", filter == "Tous", color) { onFilter("Tous") }
            kinds.forEach { (k, n) -> QuizChip("$k ($n)", filter == k, color) { onFilter(k) } }
        }
        val poolSize = if (filter == "Tous") bank.size else kinds[filter] ?: 0
        ModeCard("⚡", "Série rapide", "10 questions variées, environ 3 minutes.", color) { onStart(QuizMode.Quick) }
        if (poolSize > 10) ModeCard("🎯", "Série de 20", "Pour valider la leçon (${ProgressStore.PASS_SCORE} % requis).", color) { onStart(QuizMode.Full) }
        ModeCard("⏱", "Contre la montre", "15 questions, $TIMED_SECONDS secondes chacune. Bonus pour les réponses rapides.", color) { onStart(QuizMode.Timed) }
        ModeCard("✍️", "Dictée", "Écoutez 10 phrases de la leçon et écrivez-les. Correction mot à mot.", color) { onStart(QuizMode.Dictation) }
        ModeCard("📚", "Tout le quiz", "$poolSize questions dans le désordre.", color) { onStart(QuizMode.All) }
        if (mistakeCount > 0) {
            ModeCard("🔁", "Mes erreurs", "$mistakeCount question${if (mistakeCount > 1) "s" else ""} ratée${if (mistakeCount > 1) "s" else ""} à retravailler.", Bad) {
                onStart(QuizMode.Mistakes)
            }
        }
    }
}

@Composable
private fun ModeCard(emoji: String, title: String, subtitle: String, color: Color, onClick: () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape).background(Color.White).border(1.dp, color.copy(alpha = 0.25f), shape)
            .clickable(onClick = onClick).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(color.copy(alpha = 0.12f)), contentAlignment = Alignment.Center) {
            Text(emoji, fontSize = 22.sp)
        }
        Column(Modifier.weight(1f)) {
            Text(title, style = PosterTitle, fontSize = 17.sp, color = Ink)
            Text(subtitle, fontSize = 13.sp, color = InkSoft)
        }
        LineIcon(Art.icPlay, color, 20.dp)
    }
}

@Composable
private fun QuizChip(label: String, selected: Boolean, color: Color, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(50)).background(if (selected) color else color.copy(alpha = 0.10f))
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(label, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = if (selected) Color.White else color)
    }
}

@Composable
private fun QuizSession(
    lesson: Lesson, order: List<Int>, lang: LanguageInfo, color: Color,
    progress: ProgressStore, progressScope: String, timed: Boolean,
    onFinish: (missed: List<Int>, played: List<Int>) -> Unit,
    onMenu: () -> Unit, onRetry: (List<Int>) -> Unit, onNext: () -> Unit
) {
    val items = lesson.quiz
    val context = LocalContext.current
    var index by remember(order) { mutableIntStateOf(0) }
    var correct by remember(order) { mutableIntStateOf(0) }
    var streak by remember(order) { mutableIntStateOf(0) }
    var best by remember(order) { mutableIntStateOf(0) }
    var missed by remember(order) { mutableStateOf(listOf<Int>()) }
    var finished by remember(order) { mutableStateOf(false) }
    var gained by remember(order) { mutableIntStateOf(0) }
    var bonus by remember(order) { mutableIntStateOf(0) }
    var timeLeft by remember(order, index) { mutableIntStateOf(TIMED_SECONDS) }
    var answeredNow by remember(order, index) { mutableStateOf(false) }
    val goNext: (Int) -> Unit = { i ->
        if (i >= order.lastIndex) {
            gained = progress.recordQuiz(lesson.id, correct * 100 / order.size, progressScope) + bonus
            onFinish(missed, order)
            finished = true
        } else index = i + 1
    }
    // Mode chrono : le temps file ; à zéro, la question compte comme ratée et on passe à la suivante.
    LaunchedEffect(order, index, timed) {
        if (!timed || finished) return@LaunchedEffect
        while (timeLeft > 0 && !answeredNow) { delay(1000); if (!answeredNow) timeLeft-- }
        if (!answeredNow) {
            streak = 0
            missed = missed + order[index]
            StudyStore.recordAnswer(context, false)
            StudyStore.addMistake(context, lang.code, items[order[index]], lesson.title)
            goNext(index)
        }
    }

    if (finished) {
        val score = correct * 100 / order.size
        val passed = score >= ProgressStore.PASS_SCORE
        Box(Modifier.fillMaxSize()) {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                LineArt(if (passed) Art.trophy else Art.effort, Modifier.size(110.dp), color = Ink, accent = if (passed) Gold else Ruby, strokeWidth = 2.4.dp)
                ScoreRing(score, 120.dp)
                Text(if (passed) "Bravo !" else "Encore un effort", style = PosterTitle, fontSize = 28.sp, color = Ink)
                Text(
                    "$correct bonnes réponses sur ${order.size} · meilleure série : $best 🔥" +
                        (if (timed) "\nBonus de vitesse : +$bonus XP" else "") +
                        if (passed) "" else "\nIl faut ${ProgressStore.PASS_SCORE} % pour valider la leçon.",
                    fontSize = 15.sp, color = InkSoft, textAlign = TextAlign.Center
                )
                Pill("+$gained XP")
                if (missed.isNotEmpty()) {
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color.White).padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("À REVOIR", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.2.sp, color = Bad)
                        missed.forEach { i ->
                            val q = items[i]
                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(q.promptText(), fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Ink)
                                Text("✔ ${q.answerText()}", fontSize = 14.sp, color = Good)
                                if (q.explain.isNotBlank()) Text(q.explain, fontSize = 12.5.sp, fontStyle = FontStyle.Italic, color = InkSoft)
                            }
                        }
                    }
                    PillButton("Refaire mes ${missed.size} erreurs", Art.icRefresh, Bad, Modifier.fillMaxWidth()) { onRetry(missed.shuffled()) }
                }
                PillButton("Nouvelle série", Art.icRefresh, color, Modifier.fillMaxWidth(), filled = false) { onMenu() }
                NextButton("Faire le devoir", color, onNext)
            }
            if (passed) Confetti()
        }
        return
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        AnimatedBar(index.toFloat() / order.size, color)
        if (timed) AnimatedBar(timeLeft.toFloat() / TIMED_SECONDS, if (timeLeft <= 5) Bad else Gold)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Question ${index + 1}", style = PosterTitle, fontSize = 18.sp, color = Ink)
            Text(" / ${order.size}", style = AccentText, fontSize = 15.sp, color = InkSoft)
            Spacer(Modifier.weight(1f))
            if (streak >= 2) Pill("🔥 $streak", bg = Gold.copy(alpha = 0.25f), fg = Ink)
            Spacer(Modifier.width(6.dp))
            if (timed) {
                Pill("⏱ $timeLeft s", bg = if (timeLeft <= 5) Bad.copy(alpha = 0.18f) else color.copy(alpha = 0.12f), fg = if (timeLeft <= 5) Bad else color)
                Spacer(Modifier.width(6.dp))
            }
            Pill(items[order[index]].kind, bg = color.copy(alpha = 0.12f), fg = color)
            Spacer(Modifier.width(6.dp))
            Text("✕", Modifier.clip(RoundedCornerShape(50)).clickable { onMenu() }.padding(6.dp), fontSize = 18.sp, color = InkSoft)
        }
        AnimatedContent(
            targetState = index,
            modifier = Modifier.weight(1f),
            transitionSpec = { (fadeIn(tween(260)) + slideInHorizontally(tween(260)) { it / 5 }) togetherWith fadeOut(tween(140)) },
            label = "question"
        ) { i ->
            val qi = order[i.coerceIn(0, order.lastIndex)]
            QuizQuestion(
                item = items[qi], lang = lang, color = color, key = "quiz-${lesson.id}-$qi-$i",
                modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                onAnswered = { ok ->
                    answeredNow = true
                    StudyStore.recordAnswer(context, ok)
                    if (!ok) StudyStore.addMistake(context, lang.code, items[qi], lesson.title)
                    if (ok) {
                        correct++; streak++; best = maxOf(best, streak)
                        if (timed) bonus += (timeLeft / 5).coerceAtLeast(1)
                    } else { streak = 0; missed = missed + qi }
                },
                continueLabel = if (i >= order.lastIndex) "Voir le résultat" else "Continuer",
                onContinue = { goNext(i) }
            )
        }
    }
}

// ============================================================================= Une question

/**
 * Affiche une question de n'importe quel type. [onAnswered] est appelé une seule fois.
 * Si [onContinue] est fourni, un bouton apparaît après la réponse.
 */
@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun QuizQuestion(
    item: QuizItem,
    lang: LanguageInfo,
    color: Color,
    key: String,
    modifier: Modifier = Modifier,
    onAnswered: (Boolean) -> Unit,
    continueLabel: String = "Continuer",
    onContinue: (() -> Unit)? = null
) {
    val speaker = LocalSpeaker.current
    var answered by remember(key) { mutableStateOf(false) }
    var wasCorrect by remember(key) { mutableStateOf(false) }
    var note by remember(key) { mutableStateOf("") }
    val submit: (Boolean, String) -> Unit = { ok, message ->
        if (!answered) {
            answered = true
            wasCorrect = ok
            note = message
            onAnswered(ok)
        }
    }

    Column(modifier, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        when (item) {
            is QuizItem.Mcq -> {
                Text(item.question, style = PosterTitle, fontSize = 20.sp, color = Ink, lineHeight = 25.sp)
                ChoiceList(key, item.correct, item.wrong, answered, color) { ok -> submit(ok, item.correct) }
            }

            is QuizItem.Listen -> {
                LaunchedEffect(key) { delay(350); speaker.speak(item.phrase, lang.locale) }
                Text("Écoutez et choisissez le sens", style = PosterTitle, fontSize = 20.sp, color = Ink)
                ListenButtons(item.phrase, lang, color)
                ChoiceList(key, item.correct, item.wrong, answered, color, voiceId = "quiz-voice-$key") { ok ->
                    submit(ok, "${item.phrase} = ${item.correct}")
                }
            }

            is QuizItem.Typed -> {
                var input by remember(key) { mutableStateOf("") }
                var hints by remember(key) { mutableIntStateOf(0) }
                Text(item.instruction.ifBlank { "Traduisez en ${lang.name.lowercase()}" }, fontSize = 14.sp, color = InkSoft)
                Text(item.prompt, style = PosterTitle, fontSize = 20.sp, color = Ink, lineHeight = 25.sp)
                if (hints > 0 && !answered) {
                    Text("Indice : ${hintOf(item.answers.first(), hints)}", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = color)
                }
                OutlinedTextField(
                    value = input, onValueChange = { input = it }, enabled = !answered,
                    modifier = Modifier.fillMaxWidth(), label = { Text("Votre réponse") }
                )
                if (!answered) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PillButton("Indice", Art.icBook, color, Modifier.weight(1f), filled = false, enabled = hints < 3) { hints++ }
                        PillButton("Valider", Art.icCheck, color, Modifier.weight(1f), enabled = input.isNotBlank()) {
                        val ok = item.answers.any { same(it, input, lang.code) }
                        val exact = item.answers.any {
                            Pronunciation.clean(it).replace(" ", "") == Pronunciation.clean(input).replace(" ", "")
                        }
                        submit(ok, if (ok && !exact) "${item.answers.first()}  (attention aux accents)" else item.answers.first())
                        }
                    }
                }
            }

            is QuizItem.Order -> {
                val shuffled = remember(key) {
                    var s = item.words.indices.shuffled()
                    var tries = 0
                    while (s == item.words.indices.toList() && tries++ < 5) s = item.words.indices.shuffled()
                    s
                }
                var chosen by remember(key) { mutableStateOf(listOf<Int>()) }
                Text("Remettez les mots dans l'ordre", style = PosterTitle, fontSize = 20.sp, color = Ink)
                if (item.translation.isNotBlank()) Text(item.translation, fontSize = 14.sp, fontStyle = FontStyle.Italic, color = InkSoft)
                val zone = RoundedCornerShape(18.dp)
                FlowRow(
                    Modifier.fillMaxWidth().heightIn(min = 62.dp).clip(zone)
                        .background(color.copy(alpha = 0.06f)).border(1.5.dp, color.copy(alpha = 0.35f), zone).padding(10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (chosen.isEmpty()) Text("Touchez les mots ci-dessous…", fontSize = 13.sp, color = InkSoft)
                    chosen.forEach { w ->
                        WordTile(item.words[w], filled = true, color = if (answered) (if (wasCorrect) Good else Bad) else color) {
                            if (!answered) chosen = chosen - w
                        }
                    }
                }
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    shuffled.filter { it !in chosen }.forEach { w ->
                        WordTile(item.words[w], filled = false, color = color) { if (!answered) chosen = chosen + w }
                    }
                }
                if (!answered) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PillButton("Effacer", Art.icRefresh, color, Modifier.weight(1f), filled = false, enabled = chosen.isNotEmpty()) { chosen = emptyList() }
                        PillButton("Valider", Art.icCheck, color, Modifier.weight(1f), enabled = chosen.size == item.words.size) {
                            val built = chosen.joinToString(" ") { item.words[it] }
                            val target = item.words.joinToString(" ")
                            submit(same(built, target, lang.code), target)
                            speaker.speak(target, lang.locale)
                        }
                    }
                }
            }

            is QuizItem.Fill -> {
                var picked by remember(key) { mutableStateOf<String?>(null) }
                var input by remember(key) { mutableStateOf("") }
                Text("Complétez la phrase", style = PosterTitle, fontSize = 20.sp, color = Ink)
                val shown = item.sentence.replace("___", picked?.let { "[$it]" } ?: if (input.isNotBlank()) "[$input]" else "_____")
                Text(shown, fontSize = 20.sp, lineHeight = 28.sp, fontWeight = FontWeight.SemiBold, color = Ink)
                if (item.translation.isNotBlank()) Text(item.translation, fontSize = 14.sp, fontStyle = FontStyle.Italic, color = InkSoft)
                val full = item.sentence.replace("___", item.answers.first())
                if (item.wrong.isNotEmpty()) {
                    val options = remember(key) { (item.wrong + item.answers.first()).distinct().shuffled() }
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        options.forEach { o ->
                            val tint = when {
                                !answered -> color
                                item.answers.any { same(it, o, lang.code) } -> Good
                                o == picked -> Bad
                                else -> InkSoft
                            }
                            WordTile(o, filled = answered && tint != InkSoft, color = tint) {
                                if (!answered) {
                                    picked = o
                                    submit(item.answers.any { same(it, o, lang.code) }, full)
                                    speaker.speak(full, lang.locale)
                                }
                            }
                        }
                    }
                } else {
                    OutlinedTextField(
                        value = input, onValueChange = { input = it }, enabled = !answered,
                        modifier = Modifier.fillMaxWidth(), label = { Text("Mot manquant") }
                    )
                    if (!answered) {
                        PillButton("Valider", Art.icCheck, color, enabled = input.isNotBlank()) {
                            submit(item.answers.any { same(it, input, lang.code) }, full)
                            speaker.speak(full, lang.locale)
                        }
                    }
                }
            }

            is QuizItem.Match -> MatchGame(item, key, lang, color, answered) { ok -> submit(ok, item.answerText()) }

            is QuizItem.Speak -> {
                var result by remember(key) { mutableStateOf<PronunciationResult?>(null) }
                Text("Dites la phrase au micro", style = PosterTitle, fontSize = 20.sp, color = Ink)
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(color.copy(alpha = 0.08f)).padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(item.text, fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Ink)
                    if (item.translation.isNotBlank()) Text(item.translation, fontSize = 14.sp, fontStyle = FontStyle.Italic, color = InkSoft)
                }
                ListenButtons(item.text, lang, color)
                if (!answered) {
                    MicControl("speak-$key", lang, color) { heard ->
                        val r = Pronunciation.evaluate(item.text, heard, lang.code)
                        result = r
                        if (r.score >= 60) submit(true, "${item.text}  (score ${r.score} %)")
                    }
                    result?.let { r ->
                        PronunciationFeedback(r)
                        if (r.score < 60) {
                            Text("Score ${r.score} % : il faut 60 %. Réécoutez puis réessayez.", fontSize = 13.sp, color = Bad)
                            PillButton("Passer", Art.icPlay, Bad, filled = false) { submit(false, item.text) }
                        }
                    }
                    if (result == null) {
                        PillButton("Je n'ai pas de micro : je l'ai dit", Art.icCheck, InkSoft, filled = false) {
                            submit(true, "${item.text}  (auto-évaluation)")
                        }
                    }
                } else result?.let { PronunciationFeedback(it) }
            }

            is QuizItem.Write -> {
                var input by remember(key) { mutableStateOf("") }
                var found by remember(key) { mutableStateOf<List<String>?>(null) }
                Text("Rédigez en ${lang.name.lowercase()}", fontSize = 14.sp, color = InkSoft)
                Text(item.prompt, style = PosterTitle, fontSize = 19.sp, lineHeight = 24.sp, color = Ink)
                if (item.keywords.isNotEmpty()) {
                    Text("À utiliser : " + item.keywords.joinToString(" · "), fontSize = 13.sp, color = color)
                }
                OutlinedTextField(
                    value = input, onValueChange = { input = it }, enabled = !answered,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp), label = { Text("Votre texte") }
                )
                val words = input.trim().split(Regex("\\s+")).count { it.isNotBlank() }
                if (item.minWords > 0) Text("$words / ${item.minWords} mots minimum", fontSize = 12.sp, color = if (words >= item.minWords) Good else InkSoft)
                if (!answered) {
                    PillButton("Corriger", Art.icCheck, color, enabled = input.isNotBlank()) {
                        val key0 = Pronunciation.matchKey(input, lang.code)
                        val ok = item.keywords.filter { key0.contains(Pronunciation.matchKey(it, lang.code)) }
                        found = ok
                        val need = (item.keywords.size * 0.6).let { kotlin.math.ceil(it).toInt() }
                        submit(ok.size >= need && words >= item.minWords, item.model)
                    }
                }
                found?.let { ok ->
                    Text(
                        "Mots utilisés : ${ok.size} / ${item.keywords.size}" +
                            (item.keywords - ok.toSet()).let { if (it.isEmpty()) "" else "\nÀ ajouter : " + it.joinToString(", ") },
                        fontSize = 13.sp, color = Ink
                    )
                }
            }
        }

        AnimatedVisibility(visible = answered) {
            val fb = if (wasCorrect) Good else Bad
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(fb.copy(alpha = 0.12f)).padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    LineIcon(if (wasCorrect) Art.icCheck else Art.icCross, fb, 20.dp)
                    Spacer(Modifier.width(8.dp))
                    Text(if (wasCorrect) "Bravo !" else "Pas tout à fait", style = PosterTitle, color = fb, fontSize = 17.sp)
                }
                Text(
                    (if (item is QuizItem.Write) "Exemple de réponse : " else "Réponse : ") + note,
                    color = Ink, fontSize = 15.sp, modifier = Modifier.clickable {
                        if (item !is QuizItem.Mcq || lang.code != "fr") speaker.speak(note.substringBefore("  ("), lang.locale)
                    }
                )
                if (item.explain.isNotBlank()) Text("💡 ${item.explain}", fontSize = 13.5.sp, lineHeight = 19.sp, color = InkSoft)
            }
        }
        if (answered && onContinue != null) NextButton(continueLabel, color, onContinue)
    }
}

@Composable
private fun ListenButtons(text: String, lang: LanguageInfo, color: Color) {
    val speaker = LocalSpeaker.current
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        PillButton("Écouter", Art.icVoice, color) { speaker.speak(text, lang.locale) }
        PillButton("Lentement", Art.icSlow, color, filled = false) { speaker.speak(text, lang.locale, slow = true) }
    }
}

@Composable
private fun WordTile(text: String, filled: Boolean, color: Color, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Text(
        text,
        Modifier.clip(shape).background(if (filled) color else Color.White).border(1.5.dp, color.copy(alpha = if (filled) 1f else 0.45f), shape)
            .clickable(onClick = onClick).padding(horizontal = 13.dp, vertical = 9.dp),
        fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = if (filled) Color.White else Ink
    )
}

@Composable
private fun ChoiceList(
    key: String, correct: String, wrong: List<String>, answered: Boolean, color: Color,
    voiceId: String? = null, onPick: (Boolean) -> Unit
) {
    val context = LocalContext.current
    val options = remember(key) { (wrong + correct).distinct().shuffled() }
    var picked by remember(key) { mutableStateOf<String?>(null) }
    var voiceNote by remember(key) { mutableStateOf<String?>(null) }
    options.forEachIndexed { i, option ->
        val highlight = when {
            !answered -> null
            option == correct -> Good
            option == picked -> Bad
            else -> null
        }
        val bg by animateColorAsState(highlight?.copy(alpha = 0.16f) ?: Color.White, label = "optionBg")
        val shape = RoundedCornerShape(16.dp)
        Row(
            Modifier.fillMaxWidth().clip(shape).background(bg).border(1.5.dp, highlight ?: Sand, shape)
                .clickable(enabled = !answered) { picked = option; onPick(option == correct) }.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                Modifier.size(28.dp).clip(RoundedCornerShape(50)).background((highlight ?: color).copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
            ) { Text("${'A' + i}", fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, color = highlight ?: color) }
            Text(option, Modifier.weight(1f), fontSize = 16.sp, color = Ink,
                fontWeight = if (highlight != null) FontWeight.Bold else FontWeight.Normal)
        }
    }
    // Réponse à voix haute dans la langue maternelle, si son modèle vocal est installé.
    val native = Languages.native
    val version = VoskManager.installsVersion
    val nativeReady = remember(version) { VoskManager.isInstalled(context, native.code) }
    if (voiceId != null && nativeReady && !answered) {
        Text("…ou dites la réponse en ${native.name.lowercase()} :", fontSize = 13.sp, color = InkSoft)
        MicControl(voiceId, native, Navy) { heard ->
            val best = options.maxByOrNull { Pronunciation.evaluate(it, heard, native.code).score }
            val score = if (best == null) 0 else Pronunciation.evaluate(best, heard, native.code).score
            if (best != null && score >= 60) { picked = best; onPick(best == correct) }
            else voiceNote = "Je n'ai reconnu aucune des réponses (entendu : « $heard »). Réessayez ou touchez une réponse."
        }
        voiceNote?.let { Text(it, fontSize = 13.sp, color = Bad) }
    }
}

/** Jeu des paires : touchez un mot à gauche puis sa traduction à droite. Réussi sans erreur = bonne réponse. */
@Composable
private fun MatchGame(item: QuizItem.Match, key: String, lang: LanguageInfo, color: Color, answered: Boolean, onDone: (Boolean) -> Unit) {
    val speaker = LocalSpeaker.current
    val right = remember(key) { item.pairs.indices.shuffled() }
    var left by remember(key) { mutableStateOf<Int?>(null) }
    var done by remember(key) { mutableStateOf(setOf<Int>()) }
    var errors by remember(key) { mutableIntStateOf(0) }
    var flash by remember(key) { mutableStateOf<Int?>(null) }
    LaunchedEffect(flash) { if (flash != null) { delay(450); flash = null } }

    Text(item.title.ifBlank { "Associez chaque mot à sa traduction" }, style = PosterTitle, fontSize = 20.sp, color = Ink)
    Text("Erreurs : $errors · ${done.size} / ${item.pairs.size}", fontSize = 13.sp, color = if (errors == 0) InkSoft else Bad)
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item.pairs.forEachIndexed { i, p ->
                MatchTile(p.first, when { i in done -> Good; left == i -> color; else -> null }, enabled = i !in done && !answered) {
                    left = i
                    speaker.speak(p.first, lang.locale)
                }
            }
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            right.forEach { j ->
                MatchTile(item.pairs[j].second, when { j in done -> Good; flash == j -> Bad; else -> null }, enabled = j !in done && !answered) {
                    val l = left ?: return@MatchTile
                    if (l == j) {
                        done = done + j
                        left = null
                        if (done.size == item.pairs.size) onDone(errors == 0)
                    } else {
                        errors++
                        flash = j
                    }
                }
            }
        }
    }
}

@Composable
private fun MatchTile(text: String, tint: Color?, enabled: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    val bg by animateColorAsState(tint?.copy(alpha = 0.15f) ?: Color.White, label = "match")
    Text(
        text,
        Modifier.fillMaxWidth().heightIn(min = 48.dp).clip(shape).background(bg).border(1.5.dp, tint ?: Sand, shape)
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 10.dp, vertical = 12.dp),
        fontSize = 14.5.sp, fontWeight = if (tint != null) FontWeight.Bold else FontWeight.Normal, color = Ink, textAlign = TextAlign.Center
    )
}

// ============================================================================= Ateliers « À pratiquer »

/**
 * Atelier interactif : les exercices défilent un par un dans la carte, avec correction immédiate,
 * score et possibilité de recommencer. S'utilise dans le fil de la leçon.
 */
@Composable
fun PracticeCard(set: PracticeSet, lang: LanguageInfo, color: Color, attached: Boolean = false) {
    var round by rememberSaveable(set.title + set.ref) { mutableIntStateOf(0) }
    var index by remember(set, round) { mutableIntStateOf(0) }
    var score by remember(set, round) { mutableIntStateOf(0) }
    var answered by remember(set, round, index) { mutableStateOf(false) }
    var open by rememberSaveable(set.title + set.ref + "open") { mutableStateOf(attached) }
    val shape = RoundedCornerShape(22.dp)
    val finished = index >= set.items.size

    Column(
        Modifier.fillMaxWidth().clip(shape).background(Color.White).border(1.5.dp, color.copy(alpha = 0.45f), shape),
        verticalArrangement = Arrangement.spacedBy(0.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(color, color.copy(alpha = 0.75f))))
                .clickable { open = !open }.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("🎯", fontSize = 22.sp)
            Column(Modifier.weight(1f)) {
                Text(
                    if (attached) "À FAIRE ICI · ${set.items.size} EXERCICES" else "ATELIER INTERACTIF · ${set.items.size} EXERCICES",
                    fontSize = 10.5.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.1.sp, color = Color.White.copy(alpha = 0.88f)
                )
                Text(set.title, style = PosterTitle, fontSize = 17.sp, color = Color.White)
            }
            Text(if (open) "▲" else if (finished) "✓" else "▶", fontSize = 16.sp, color = Color.White)
        }
        AnimatedVisibility(visible = open) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (set.instruction.isNotBlank()) Text(set.instruction, fontSize = 14.sp, lineHeight = 20.sp, color = InkSoft)
                AnimatedBar(index.coerceAtMost(set.items.size).toFloat() / set.items.size, color)
                if (!finished) {
                    Text("Exercice ${index + 1} / ${set.items.size} · ${set.items[index].kind}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = color)
                    key(round, index) {
                        QuizQuestion(
                            item = set.items[index], lang = lang, color = color,
                            key = "practice-${set.title}-$round-$index",
                            modifier = Modifier.fillMaxWidth(),
                            onAnswered = { ok -> answered = true; if (ok) score++ },
                            continueLabel = if (index == set.items.lastIndex) "Terminer l'atelier" else "Exercice suivant",
                            onContinue = { index++ }
                        )
                    }
                } else {
                    val pct = score * 100 / set.items.size
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        ScoreRing(pct, 72.dp)
                        Column(Modifier.weight(1f)) {
                            Text(
                                when { pct >= 90 -> "Excellent !"; pct >= 70 -> "Très bien !"; pct >= 50 -> "Pas mal !"; else -> "On recommence ?" },
                                style = PosterTitle, fontSize = 20.sp, color = Ink
                            )
                            Text("$score réussis sur ${set.items.size}", fontSize = 14.sp, color = InkSoft)
                        }
                    }
                    PillButton("Recommencer l'atelier", Art.icRefresh, color, Modifier.fillMaxWidth(), filled = false) { round++ }
                }
            }
        }
    }
}

/** Ateliers non rattachés à un exercice du manuel : regroupés sous le cours. */
@Composable
fun PracticeSection(sets: List<PracticeSet>, lang: LanguageInfo, color: Color) {
    if (sets.isEmpty()) return
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("À PRATIQUER", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = color, letterSpacing = 1.4.sp)
        Text("Ateliers interactifs", style = PosterTitle, fontSize = 24.sp, color = Ink)
        Text(
            "Faites les exercices directement ici : correction immédiate, écoute, micro et explications.",
            style = AccentText, fontSize = 13.sp, color = InkSoft
        )
        sets.forEach { PracticeCard(it, lang, color) }
    }
}
