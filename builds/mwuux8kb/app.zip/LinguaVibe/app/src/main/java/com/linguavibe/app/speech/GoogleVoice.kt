package com.linguavibe.app.speech

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest

/**
 * Voix en ligne gratuite, sans clé : le service de lecture vocale de Google Traduction.
 * Chaque phrase est demandée une seule fois puis gardée sur le téléphone (lecture ensuite
 * instantanée et hors ligne).
 */
/** Pas de réseau ou serveur injoignable (par opposition à un refus du service pour une phrase). */
class VoiceNetworkException(message: String) : Exception(message)

object GoogleVoice {
    private const val MAX_CHUNK = 180

    private val tags = mapOf(
        "es" to "es", "en" to "en", "pt" to "pt", "fr" to "fr",
        "ru" to "ru", "zh" to "zh-CN", "ar" to "ar"
    )

    // Dossier de langue durable (LangStorage) : les voix téléchargées restent, même après désinstallation.
    private fun dir(context: Context) = LangStorage.dir(context, "google-voice")

    private fun fileFor(context: Context, text: String, lang: String) =
        File(dir(context), hash("${tags[lang] ?: lang}|${text.trim()}") + ".mp3")

    /** Vrai si cette phrase est déjà enregistrée sur le téléphone. */
    fun isCached(context: Context, text: String, lang: String): Boolean =
        fileFor(context, text, lang).length() > 0

    /** Coupe un long texte en morceaux acceptés par le service, sans casser les phrases. */
    private fun chunks(text: String): List<String> {
        val out = mutableListOf<String>()
        var current = StringBuilder()
        fun flush() {
            if (current.isNotBlank()) out.add(current.toString().trim())
            current = StringBuilder()
        }
        val pieces = text.split(Regex("(?<=[.!?。！？؟;:,،、])\\s+|\\n+"))
        for (piece in pieces) {
            var rest = piece
            while (rest.length > MAX_CHUNK) {
                val cut = rest.lastIndexOf(' ', MAX_CHUNK).takeIf { it > 0 } ?: MAX_CHUNK
                if (current.length + cut > MAX_CHUNK) flush()
                current.append(rest.substring(0, cut)).append(' ')
                flush()
                rest = rest.substring(cut).trim()
            }
            if (current.length + rest.length + 1 > MAX_CHUNK) flush()
            if (rest.isNotEmpty()) current.append(rest).append(' ')
        }
        flush()
        return out
    }

    private fun fetch(chunk: String, tag: String): ByteArray {
        val url = "https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=$tag" +
            "&q=" + URLEncoder.encode(chunk, "UTF-8")
        val connection = URL(url).openConnection() as HttpURLConnection
        try {
            connection.connectTimeout = 8_000
            connection.readTimeout = 15_000
            connection.setRequestProperty(
                "User-Agent",
                "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Mobile Safari/537.36"
            )
            val code = connection.responseCode
            if (code != 200) throw IllegalStateException("Voix Google indisponible (code $code).")
            val bytes = ByteArrayOutputStream()
            connection.inputStream.use { it.copyTo(bytes) }
            if (bytes.size() == 0) throw IllegalStateException("Voix Google : réponse vide.")
            return bytes.toByteArray()
        } finally {
            connection.disconnect()
        }
    }

    /** Renvoie le fichier MP3 de [text] dans la langue [lang] (code à deux lettres). */
    suspend fun speechFile(context: Context, text: String, lang: String): File = withContext(Dispatchers.IO) {
        val tag = tags[lang] ?: lang
        val file = fileFor(context, text, lang)
        if (file.length() > 0) return@withContext file
        val tmp = File(file.path + ".part")
        try {
            tmp.outputStream().use { out ->
                for (chunk in chunks(text.trim())) out.write(fetch(chunk, tag))
            }
        } catch (e: java.net.UnknownHostException) {
            tmp.delete()
            throw VoiceNetworkException("Pas de connexion Internet : cette phrase n'a pas encore été téléchargée.")
        } catch (e: java.io.IOException) {
            tmp.delete()
            throw VoiceNetworkException("Connexion impossible à la voix Google.")
        } catch (e: Throwable) {
            tmp.delete()
            throw e
        }
        if (tmp.length() == 0L || !tmp.renameTo(file)) {
            tmp.delete()
            throw IllegalStateException("Voix Google : audio vide.")
        }
        file
    }

    fun cacheSizeMb(context: Context): Long =
        dir(context).listFiles()?.sumOf { it.length() }?.div(1024 * 1024) ?: 0

    fun clearCache(context: Context) {
        dir(context).listFiles()?.forEach { it.delete() }
    }

    private fun hash(text: String): String =
        MessageDigest.getInstance("SHA-1").digest(text.toByteArray()).joinToString("") { "%02x".format(it) }
}
