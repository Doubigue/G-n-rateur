package com.linguavibe.app.speech

import android.content.Context
import androidx.compose.runtime.mutableStateOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import java.io.BufferedInputStream
import java.io.File

/** Gestionnaire d'installation du modèle multilingue Supertonic 3 dans le dossier de langue durable (LangStorage). */
object SupertonicVoiceManager {
    const val MODEL_ID = "sherpa-onnx-supertonic-3-tts-int8-2026-05-11"
    const val MODEL_URL = "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/$MODEL_ID.tar.bz2"
    val progress = mutableStateOf(DownloadProgress())

    data class DownloadProgress(val downloaded: Long = 0L, val total: Long = 0L, val running: Boolean = false, val error: String? = null)

    fun modelDir(context: Context) = File(LangStorage.dir(context, "tts-models"), MODEL_ID)
    fun isInstalled(context: Context): Boolean {
        val d = modelDir(context)
        return listOf("duration_predictor.int8.onnx", "text_encoder.int8.onnx", "vector_estimator.int8.onnx", "vocoder.int8.onnx", "tts.json", "unicode_indexer.bin", "voice.bin").all { File(d, it).length() > 0 }
    }

    suspend fun install(context: Context, onProgress: (Long, Long) -> Unit = { _, _ -> }) = withContext(Dispatchers.IO) {
        if (isInstalled(context)) return@withContext
        val root = LangStorage.dir(context, "tts-models")
        val finalArchive = File(LangStorage.dir(context, "downloads"), "$MODEL_ID.tar.bz2")
        progress.value = DownloadProgress(running = true)
        try {
            var count = 0L
            var total = 0L
            ResumableDownload.fetch(MODEL_URL, finalArchive) { done, size ->
                count = done; total = size
                progress.value = DownloadProgress(done, size, true)
                onProgress(done, size)
            }
            if (finalArchive.length() < 1024L) throw IllegalStateException("Archive vocale vide ou incomplète.")
            val staging = File(root, "$MODEL_ID.extracting").apply { deleteRecursively(); mkdirs() }
            extract(finalArchive, staging)
            val extracted = File(staging, MODEL_ID).takeIf { it.isDirectory } ?: staging
            val destination = modelDir(context)
            destination.deleteRecursively()
            if (extracted != staging) {
                if (!extracted.renameTo(destination)) copyDirectory(extracted, destination)
                staging.deleteRecursively()
            } else {
                if (!staging.renameTo(destination)) copyDirectory(staging, destination)
            }
            finalArchive.delete()
            if (!isInstalled(context)) throw IllegalStateException("Le modèle a été extrait mais certains fichiers sont manquants.")
            progress.value = DownloadProgress(count, total, false)
        } catch (t: Throwable) {
            progress.value = DownloadProgress(error = t.message ?: "Installation impossible.")
            throw t
        }
    }

    private fun extract(archive: File, destination: File) {
        BZip2CompressorInputStream(BufferedInputStream(archive.inputStream())).use { bz ->
            TarArchiveInputStream(bz).use { tar ->
                while (true) {
                    val entry = tar.nextTarEntry ?: break
                    val out = File(destination, entry.name).canonicalFile
                    require(out.path.startsWith(destination.canonicalPath + File.separator) || out == destination) { "Entrée d'archive invalide." }
                    if (entry.isDirectory) out.mkdirs() else {
                        out.parentFile?.mkdirs()
                        out.outputStream().use { tar.copyTo(it) }
                    }
                }
            }
        }
    }

    private fun copyDirectory(from: File, to: File) {
        to.mkdirs()
        from.walkTopDown().forEach { f ->
            val target = File(to, f.relativeTo(from).path)
            if (f.isDirectory) target.mkdirs() else f.copyTo(target, overwrite = true)
        }
    }

    fun remove(context: Context) {
        modelDir(context).deleteRecursively()
        File(LangStorage.dir(context, "downloads"), "$MODEL_ID.tar.bz2").delete()
    }
}
