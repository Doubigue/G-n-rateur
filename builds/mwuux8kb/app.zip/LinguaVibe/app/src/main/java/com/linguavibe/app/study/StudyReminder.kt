package com.linguavibe.app.study

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.compose.runtime.mutableStateOf
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.linguavibe.app.MainActivity
import com.linguavibe.app.R
import com.linguavibe.app.data.CourseRepository
import com.linguavibe.app.data.Languages
import com.linguavibe.app.lexique.LexiqueReminder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Calendar
import java.util.concurrent.TimeUnit

/**
 * Rappel quotidien « Mini-quiz du jour » : une notification à l'heure choisie, avec une question en avant-goût.
 * La toucher ouvre directement le mini-quiz de 3 questions (et les cartes à réviser).
 */
object StudyReminder {
    const val CHANNEL_ID = "mini_quiz"
    const val EXTRA_OPEN = "linguavibe.open"
    const val OPEN_REVIEW = "review"
    private const val WORK_NAME = "mini_quiz_quotidien"
    private const val NOTIF_ID = 4301

    /** Écran demandé par une notification ; lu puis remis à null par l'interface. */
    val pendingOpen = mutableStateOf<String?>(null)

    private fun sp(context: Context) = context.applicationContext.getSharedPreferences("study", Context.MODE_PRIVATE)
    fun isEnabled(context: Context) = sp(context).getBoolean("reminder_on", false)
    fun hour(context: Context) = sp(context).getInt("reminder_hour", 18)
    fun minute(context: Context) = sp(context).getInt("reminder_minute", 0)

    fun setTime(context: Context, hour: Int, minute: Int) {
        sp(context).edit().putInt("reminder_hour", hour).putInt("reminder_minute", minute).apply()
        if (isEnabled(context)) schedule(context)
    }

    fun setEnabled(context: Context, enabled: Boolean) {
        sp(context).edit().putBoolean("reminder_on", enabled).apply()
        if (enabled) schedule(context) else WorkManager.getInstance(context.applicationContext).cancelUniqueWork(WORK_NAME)
    }

    fun hasPermission(context: Context) = LexiqueReminder.hasPermission(context)

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel(CHANNEL_ID, "Mini-quiz du jour", NotificationManager.IMPORTANCE_DEFAULT)
        channel.description = "Un rappel par jour avec un quiz de 3 questions"
        manager.createNotificationChannel(channel)
    }

    private fun delayUntilNext(hour: Int, minute: Int): Long {
        val now = System.currentTimeMillis()
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        if (cal.timeInMillis <= now + 1_000L) cal.add(Calendar.DAY_OF_MONTH, 1)
        return cal.timeInMillis - now
    }

    fun schedule(context: Context) {
        val app = context.applicationContext
        if (!isEnabled(app)) return
        createChannel(app)
        val request = PeriodicWorkRequestBuilder<MiniQuizWorker>(1, TimeUnit.DAYS)
            .setInitialDelay(delayUntilNext(hour(app), minute(app)), TimeUnit.MILLISECONDS)
            .build()
        WorkManager.getInstance(app).enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.CANCEL_AND_REENQUEUE, request)
    }

    /** Lit l'intention d'ouverture (notification) et la mémorise pour l'interface. */
    fun handleIntent(intent: Intent?) {
        intent?.getStringExtra(EXTRA_OPEN)?.let { pendingOpen.value = it }
    }

    suspend fun notifyNow(context: Context) {
        val app = context.applicationContext
        if (!hasPermission(app) || !NotificationManagerCompat.from(app).areNotificationsEnabled()) return
        createChannel(app)
        val (title, text) = withContext(Dispatchers.IO) {
            val lang = StudyStore.lastLang(app)
            val name = runCatching { Languages.byCode(lang).name.lowercase() }.getOrDefault("")
            val due = StudyStore.dueCount(app)
            val teaser = runCatching {
                val v = CourseRepository.load(app, lang).lessons.flatMap { it.vocab }.random()
                "Que veut dire « ${v.word} » ? "
            }.getOrDefault("")
            "Mini-quiz du jour 🎯" to
                "${teaser}3 questions d'$name vous attendent (2 minutes)." + if (due > 0) " $due carte${if (due > 1) "s" else ""} à réviser." else ""
        }
        val open = PendingIntent.getActivity(
            app, 7, Intent(app, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra(EXTRA_OPEN, OPEN_REVIEW),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(app, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_reminder)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(app).notify(NOTIF_ID, n)
        } catch (_: SecurityException) {
        }
    }
}

class MiniQuizWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        if (!StudyReminder.isEnabled(applicationContext)) return Result.success()
        return try {
            StudyReminder.notifyNow(applicationContext); Result.success()
        } catch (_: Exception) {
            Result.retry()
        }
    }
}
