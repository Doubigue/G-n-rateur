# MODEL 4 : la conjugaison espagnole

Une nouvelle carte « MODEL 4 » sur l'écran Espagnol. Chaque leçon est consacrée à un verbe,
du plus utilisé au moins utilisé (80 verbes, A1 à C2).

## Contenu de chaque leçon
1. **Conjugaison** : le tableau du verbe à 15 temps.
   - Indicatif : présent, passé composé, imparfait, passé simple, plus-que-parfait, futur, futur antérieur.
   - Conditionnel : présent et passé.
   - Subjonctif : présent, passé, imparfait, plus-que-parfait.
   - Impératif : affirmatif et négatif.

   Le tableau donne aussi le gérondif et le participe. Pour chaque temps, l'écran affiche :
   - la règle (formation et emploi) ;
   - les formes irrégulières en rouge ;
   - l'écoute de chaque forme ou du temps entier, aussi en version lente ;
   - un mode révision qui cache les formes jusqu'à ce qu'on les touche.

   Viennent ensuite les particularités du verbe, son emploi et la narration en français.
2. **Exemples** : des phrases rédigées, à plusieurs temps, avec leur traduction.
3. **Prononciation** : les exemples, à répéter au micro.
4. **Exercices** : 5 ateliers corrigés tout de suite. Présent ; temps du passé ; futur et conditionnel ;
   subjonctif et impératif ; le verbe en contexte.
5. **Quiz** : environ 45 questions par verbe. Il y en a de 8 types :
   - choisir la forme ;
   - l'écrire ;
   - reconnaître le temps ;
   - associer les personnes et les formes ;
   - donner le participe et le gérondif ;
   - compléter une phrase à trou ;
   - écouter ;
   - remettre dans l'ordre.
6. **Devoir** : écrire des phrases avec le verbe, recopier de mémoire.

## Les 80 verbes (chapitres A1 à C2 = rang de fréquence ; 41 à 80 dans tools/model4_verbs2.py)
| Chapitre | Verbes |
|---|---|
| 1 à 10 | ser, estar, haber, tener, hacer, poder, decir, ir, ver, dar |
| 11 à 20 | saber, querer, llegar, pasar, deber, poner, parecer, quedar, creer, hablar |
| 21 à 30 | llevar, dejar, seguir, encontrar, llamar, venir, pensar, salir, volver, tomar |
| 31 à 40 | conocer, vivir, sentir, mirar, contar, empezar, esperar, buscar, trabajar, escribir |

## Outils
- `tools/conjugator.py` : le conjugueur.
  - Il gère les verbes réguliers et les diphtongues e → ie, o → ue, e → i, avec leurs effets sur les verbes en -ir.
  - Il gère aussi les changements d'orthographe : car, gar, zar, guir et cer en zc.
  - Pour les verbes irréguliers, il connaît les radicaux du passé simple, du futur et du subjonctif, les participes et les impératifs.
- `tools/model4_verbs.py` : la liste des verbes, leurs particularités et leurs exemples.
- `tools/build_model4.py` : génère `assets/courses/es_model4.json`. La commande est `python3 tools/build_model4.py`.
- Pour ajouter des verbes : complétez VERBS dans model4_verbs.py, puis relancez le script. Les verbes 41 à 50 iront dans le chapitre C1.

## Conjugueur (tous les verbes, tous les temps)
- `tools/verbdb.py` génère `assets/conjugations/es_verbs.json` : environ 890 verbes du lexique + 90 pronominaux (levantarse…), 15 temps, formes irrégulières marquées.
- `data/Conjugator.kt` charge la base, propose des suggestions, conjugue un verbe inconnu comme un verbe régulier (avec un avertissement) et gère les pronominaux (me levanto, levántate, no te levantes).
- `ui/ConjugatorScreen.kt` : recherche, puis tous les temps groupés par mode, irrégularités en rouge, touche pour écouter. Accès : tuile « Conjugueur » (espagnol), bouton du MODEL 4, et « Tous les temps » dans chaque carte de conjugaison.
