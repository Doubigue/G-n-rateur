# Intégration des manuels PDF Model 2 et Model 3

## Modifications effectuées

- Le parcours espagnol `model2` conserve son identifiant, ses 16 identifiants de leçons et son espace de progression `es_model2`. Son contenu JSON a été remplacé par le contenu source du PDF, pages 2 à 51.
- Le nouveau parcours `model3` est chargé depuis `assets/courses/es_model3.json`, avec 4 unités, un espace de progression indépendant `es_model3` et une route de navigation dédiée.
- Le sélecteur de parcours espagnol affiche maintenant Model 1, Model 2, Model 3 et le lexique.
- Les écrans de leçon affichent le contenu intégral du manuel dans une section dédiée. Les leçons Model 2 disposent aussi de leur illustration originale extraite du PDF. La couverture du Model 3 est intégrée comme illustration d'ouverture.
- Les vocabulaires, exemples, lectures, devoirs et quiz ont été structurés dans le modèle de données existant lorsque le format de la source le permettait. Le texte intégral source reste conservé dans chaque leçon pour éviter toute perte de détail.
- Les quiz Model 2 comptent 4 questions par leçon (64 au total). Les quiz Model 3 reprennent les 62 questions numérotées dans les pages de quiz et leurs réponses dans les pages de corrigés.
- Les contenus sont des ressources `assets` de l'application : leur consultation ne nécessite pas de connexion Internet.

## TTS

Le moteur vocal existant de LinguaVibe (`Speaker` et ses composants associés) est conservé. Aucun moteur Piper ou Kokoro n'a été ajouté et le moteur TTS n'a pas été remplacé. Les phrases espagnoles extraites et les lectures structurées sont connectées aux commandes de lecture existantes. La disponibilité hors ligne de la voix dépend toujours du moteur et des voix Android installées/téléchargées.

## Fichiers principaux modifiés

- `app/src/main/assets/courses/es_model2.json`
- `app/src/main/assets/courses/es_model3.json` (nouveau)
- `app/src/main/assets/manual_images/` (illustrations Model 2 et couverture Model 3)
- `app/src/main/java/com/linguavibe/app/data/Models.kt`
- `app/src/main/java/com/linguavibe/app/ui/Screens.kt`
- `app/src/main/java/com/linguavibe/app/ui/LessonScreen.kt`

## Limites et vérifications

- Le PDF annonce « plus de 80 questions corrigées » sur la couverture du Model 3, mais les pages de quiz visibles contiennent 62 questions numérotées (1 à 62). Les 62 questions présentes et leurs réponses ont été intégrées ; aucune question supplémentaire n'a été inventée.
- Les pages du Model 3 ne contiennent pas d'illustrations pédagogiques individuelles dans les unités ; seule sa couverture illustrée est disponible. Les pages Model 2 contiennent 16 illustrations individuelles, intégrées.
- Validation effectuée : les deux JSON sont valides, Model 2 contient 16 leçons, Model 3 contient 4 unités, les quiz contiennent 64 et 62 questions respectivement, et les ressources images référencées existent.
- Compilation Android non vérifiée dans cet environnement : le ZIP source ne contient ni `gradlew` ni `gradle-wrapper.jar`, et aucune installation de Gradle n'est disponible. Aucun appareil Android ou émulateur n'était disponible. Il n'est donc pas possible de certifier ici la compilation finale ou l'exécution sur appareil.
