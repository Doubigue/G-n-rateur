# Prompt de suite (à coller dans la prochaine conversation)

Voici mon projet LinguaVibe (zip joint). Dernière étape faite : style « manuel africain » des MODEL 2 et 3
(palette Portfolio DL VIBE, frises bogolan), 44 dialogues illustrés en scènes lineart (ui/Scenes.kt généré par
tools/scenes.py), leçons enrichies (tools/content_m2.py, content_m3.py, fusion par tools/enrich_m2_m3.py),
lexique corrigé (7 646 mots, feuille « Corrections traductions »). Voir AMELIORATION_MODEL2_MODEL3_LEXIQUE.md.

Pour la suite, je voudrais :
1. Compiler et corriger les éventuelles erreurs Android Studio.
2. Ajouter au MODEL 3 les leçons suivantes du manuel (je joindrai les photos des pages).
3. Compléter le lexique au-delà de la lettre H (le fichier s'arrête à « hy… ») pour revenir à 10 000 mots fiables.
4. Donner aux autres langues (anglais, portugais, russe, chinois, arabe) les mêmes dialogues illustrés en scènes.
Envoie-moi le projet en zip à la fin, avec un nouveau prompt de suite.

## Suite après « Quiz et pratique »
Reprends LinguaVibe (zip joint). Les quiz ont 8 types et les ateliers « À pratiquer » sont jouables dans l'appli (QuizPlay.kt, tools/quiz_practice.py, QUIZ_ET_PRATIQUE.md). Prochaine étape : [ex. ateliers rédigés à la main pour chaque leçon du MODEL 2 / sauvegarde du score des ateliers / mode défi chronométré].

## Suite après « Téléchargement durable, cours augmentés, écoute en français »
Reprends LinguaVibe (zip joint). Les téléchargements de langue passent par WorkManager avec reprise (LangDownloads, ResumableDownload) et sont rangés dans /LinguaVibe (LangStorage), qui reste après la désinstallation. Le MODEL 3 a 8 unités (tools/content_plus.py) et chaque leçon peut s'écouter en français (CourseNarration, CourseListen). Voir TELECHARGEMENT_COURS_ECOUTE.md. Prochaine étape : [ex. vrai texte de manuel pour les unités 5 à 8 / narration surlignant le texte dans la page / sauvegarde de la progression dans /LinguaVibe].

## Suite après « MODEL 4 conjugaison »
Reprends LinguaVibe (zip joint). Le MODEL 4 contient 80 verbes (model4_verbs.py + model4_verbs2.py), avec un conjugueur complet (verbdb.py → es_verbs.json, Conjugator.kt, ConjugatorScreen.kt). Le MODEL 2 a 38 leçons (content_m2_more2.py : 29 à 34, content_m2_more3.py : 35 à 38). Outils d'étude : voir OUTILS_ETUDE.md (révision espacée, stats, fiches par temps, dictée, conversation, examens + certificat, tout télécharger, rappel mini-quiz). Les packs audio sont complets (SpokenTexts.kt, VoicePacks.kt). Quiz : questions de dialogue, mode chrono, indices ; dialogue : choix du rôle et mode mémoire. Prochaines idées : leçons M2 35+, fiches de révision par temps, statistiques de progression.
