#!/usr/bin/env python3
"""Base de conjugaison du conjugueur de l'appli : tous les verbes du lexique et du MODEL 4, à tous les temps.

Usage : python3 tools/verbdb.py
Écrit app/src/main/assets/conjugations/es_verbs.json :
  {"tenses": [...métadonnées...], "verbs": [{"i": infinitif, "f": traduction, "g": gérondif, "p": participe,
   "t": ["f1|…|f6" × 15 temps], "x": ["010010" × 15]}], "alias": {"levantarse": ["levantar", "se lever"]}}
Les verbes pronominaux sont conjugués dans l'appli à partir du verbe simple (me levanto, levántate…).
"""
import json
import re
import sys
from pathlib import Path

import openpyxl

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from build_model4 import TENSES, irregular_marks  # noqa: E402
from conjugator import conjugate  # noqa: E402
from model4_verbs import VERBS as M4  # noqa: E402

ROOT = HERE.parent / "app" / "src" / "main" / "assets"
OUT = ROOT / "conjugations" / "es_verbs.json"

# ----------------------------------------------------------------------------- familles de verbes

IE = """pensar cerrar comenzar empezar despertar sentar sentarse entender perder querer encender defender preferir sentir
mentir divertir convertir advertir sugerir referir herir negar nevar recomendar regar atravesar calentar gobernar apretar
confesar fregar tropezar ascender descender extender tender acertar merendar sembrar manifestar enterrar quebrar
temblar despertarse arrepentirse consentir hervir invertir requerir digerir adquirir atender verter
adherir conferir desalentar desatender desconcertar desenterrar desmentir desterrar diferir disentir encerrar encomendar
enmendar""".split()
UE = """contar encontrar recordar volver poder dormir morir mover llover soñar probar costar mostrar almorzar colgar rogar
sonar volar acostar devolver resolver envolver doler soler demostrar aprobar comprobar renovar acordar morder
promover remover absolver disolver forzar esforzar consolar tostar rodar soldar revolver descolgar apostar demoler descollar""".split()
EI = """pedir servir repetir seguir conseguir perseguir vestir medir competir corregir elegir despedir impedir gemir rendir
teñir ceñir reñir regir expedir derretir""".split()
IAR = """enviar confiar guiar criar variar ampliar desviar esquiar fotografiar resfriar vaciar espiar desconfiar enfriar
liar fiar averiar chirriar desafiar expiar hastiar estriar descarriar gloriar""".split()
NO_ACCENT_UAR = {"averiguar", "apaciguar", "atestiguar", "adecuar", "evacuar", "licuar", "menguar", "santiguar"}
PART = {"abrir": "abierto", "cubrir": "cubierto", "descubrir": "descubierto", "encubrir": "encubierto", "escribir": "escrito",
        "describir": "descrito", "inscribir": "inscrito", "suscribir": "suscrito", "romper": "roto", "morir": "muerto",
        "volver": "vuelto", "devolver": "devuelto", "envolver": "envuelto", "revolver": "revuelto", "resolver": "resuelto",
        "disolver": "disuelto", "absolver": "absuelto", "freír": "frito", "imprimir": "impreso", "proveer": "provisto"}

# Verbes entièrement décrits à la main (ou par préfixe).
SPECIAL = {
    "caber": dict(pres=["quepo", "cabes", "cabe", "cabemos", "cabéis", "caben"], pret_stem="cup", fut_stem="cabr", subj_stem="quep"),
    "andar": dict(pret_stem="anduv"),
    "valer": dict(yo="valgo", fut_stem="valdr", subj_stem="valg"),
    "oír": dict(pres=["oigo", "oyes", "oye", "oímos", "oís", "oyen"], pret=["oí", "oíste", "oyó", "oímos", "oísteis", "oyeron"],
                subj_stem="oig", gerund="oyendo", participle="oído", imp_tu="oye", imp_vos="oíd"),
    "oler": dict(pres=["huelo", "hueles", "huele", "olemos", "oléis", "huelen"], subj=["huela", "huelas", "huela", "olamos", "oláis", "huelan"], imp_tu="huele"),
    "caer": dict(yo="caigo", vowel_stem=True, subj_stem="caig"),
    "jugar": dict(stem_change="ue"),
    "errar": dict(pres=["yerro", "yerras", "yerra", "erramos", "erráis", "yerran"], subj=["yerre", "yerres", "yerre", "erremos", "erréis", "yerren"], imp_tu="yerra"),
    "satisfacer": dict(yo="satisfago", pret=["satisfice", "satisficiste", "satisfizo", "satisficimos", "satisficisteis", "satisficieron"],
                       fut_stem="satisfar", participle="satisfecho", imp_tu="satisfaz", subj_stem="satisfag"),
}


def reir(prefix):
    return dict(pres=[prefix + x for x in ("río", "ríes", "ríe", "reímos", "reís", "ríen")],
                pret=[prefix + x for x in ("reí", "reíste", "rio", "reímos", "reísteis", "rieron")],
                subj=[prefix + x for x in ("ría", "rías", "ría", "riamos", "riais", "rían")],
                gerund=prefix + "riendo", participle=prefix + ("frito" if prefix == "f" else "reído"), imp_tu=prefix + "ríe", imp_vos=prefix + "reíd")


def compound(base_traits, prefix, base):
    """Composés : obtener (tener), proponer (poner), convenir (venir), deshacer (hacer), atraer (traer)…"""
    out = {}
    for k, val in base_traits.items():
        if isinstance(val, list):
            out[k] = [prefix + x for x in val]
        elif isinstance(val, str) and k not in ("stem_change",):
            out[k] = prefix + val
        else:
            out[k] = val
    # accent écrit sur les formes courtes devenues longues : obtén, propón, convén
    if base in ("tener", "venir", "poner"):
        out["imp_tu"] = prefix + {"tener": "tén", "venir": "vén", "poner": "pón"}[base]
    if base == "hacer":
        out["imp_tu"] = prefix + "haz"
    return out


M4_TRAITS = {v["inf"]: v["traits"] for v in M4}
BASES = {"tener": M4_TRAITS["tener"], "poner": M4_TRAITS["poner"], "venir": M4_TRAITS["venir"], "hacer": M4_TRAITS["hacer"],
         "decir": M4_TRAITS["decir"], "traer": dict(yo="traigo", pret_stem="traj", gerund="trayendo", participle="traído", subj_stem="traig"),
         "salir": M4_TRAITS["salir"], "ver": M4_TRAITS["ver"]}
NOT_COMPOUND = {"detener": None}  # detener est bien un composé (gardé)


def traits_for(inf):
    if inf in M4_TRAITS:
        return dict(M4_TRAITS[inf])
    if inf in SPECIAL:
        return dict(SPECIAL[inf])
    if inf in BASES:
        return dict(BASES[inf])
    for p in ("son", "f", ""):
        if inf == p + "reír":
            return reir(p)
    for base, tr in BASES.items():
        if inf.endswith(base) and inf != base and len(inf) > len(base):
            prefix = inf[: -len(base)]
            if base == "ver" and prefix not in ("pre", "re", "entre"):
                continue
            if base == "decir" and prefix not in ("pre", "contra", "ben", "mal"):
                continue
            if base == "salir" and prefix not in ("sobre",):
                continue
            if base == "hacer" and prefix not in ("des", "re"):
                continue
            t = compound(tr, prefix, base)
            if base == "decir" and prefix in ("pre", "contra"):
                t["imp_tu"] = prefix + "dice"
            return t
    t = {}
    stem = inf[:-2]
    g = inf[-2:].replace("ír", "ir")
    if inf in IE:
        t["stem_change"] = "ie"
    elif inf in UE:
        t["stem_change"] = "ue"
    elif inf in EI:
        t["stem_change"] = "i"
    if inf.endswith("ducir"):
        t.update(zc=True, pret_stem=stem[:-1] + "j")
    elif g in ("er", "ir") and re.search(r"[aeiou]c$", stem) and inf not in ("hacer", "cocer", "mecer", "recocer", "escocer"):
        t["zc"] = True
    if inf.endswith("uir") and not inf.endswith(("guir", "quir")):
        b = stem  # constru
        t.update(pres=[b + "yo", b + "yes", b + "ye", b + "imos", b + "ís", b + "yen"],
                 pret=[b + "í", b + "iste", b + "yó", b + "imos", b + "isteis", b + "yeron"],
                 subj_stem=b + "y", gerund=b + "yendo", imp_tu=b + "ye")
    if inf.endswith("eer"):
        t["vowel_stem"] = True
    if inf in IAR or (inf.endswith("uar") and inf not in NO_ACCENT_UAR):
        weak = stem[-1]
        acc = {"i": "í", "u": "ú"}[weak]
        b = stem[:-1]
        t.update(pres=[b + acc + "o", b + acc + "as", b + acc + "a", stem + "amos", stem + "áis", b + acc + "an"],
                 subj=[b + acc + "e", b + acc + "es", b + acc + "e", stem + "emos", stem + "éis", b + acc + "en"],
                 imp_tu=b + acc + "a")
    if inf in PART:
        t["participle"] = PART[inf]
    return t


# ----------------------------------------------------------------------------- liste des verbes

NOT_VERBS = {"azúcar", "carácter", "curricular", "escapular", "escolar", "espectacular", "funicular", "collar", "particular",
             "regular", "somier", "telar", "familiar", "alquiler", "almíbar", "lunar", "solar", "polar", "militar", "popular", "similar",
             "titular", "singular", "auxiliar", "peculiar", "muscular", "vulgar", "circular", "celular", "molecular", "nuclear", "lugar",
             "hogar", "mujer", "placer", "deber_", "poder_", "amanecer_", "atardecer_", "taller", "cráter", "líder", "suéter", "póster"}


def is_verb(es, fr):
    if es in NOT_VERBS:
        return False
    if not re.fullmatch(r"[a-záéíóúñü]+(ar|er|ir|ír)(se)?", es):
        return False
    first = fr.strip().lower().split(",")[0].split()[0] if fr.strip() else ""
    return first.startswith(("se ", "s'")) or fr.lower().startswith(("se ", "s'", "(se)")) or re.search(r"(er|ir|re|oir)$", first) is not None


def lexicon_verbs():
    wb = openpyxl.load_workbook(ROOT / "lexique" / "Lexique_10000.xlsx", read_only=True)
    out = {}
    for row in wb.active.iter_rows(values_only=True):
        if not row or not row[1] or not row[2]:
            continue
        es, fr = str(row[1]).strip(), str(row[2]).strip()
        if is_verb(es, fr) and es not in out:
            out[es] = fr
    return out


def build():
    verbs = lexicon_verbs()
    for v in M4:
        verbs.setdefault(v["inf"], v["tr"])
    extra = {"caber": "tenir (dans), rentrer", "andar": "marcher", "valer": "valoir", "oír": "entendre", "oler": "sentir (odeur)",
             "caer": "tomber", "traer": "apporter", "reír": "rire", "sonreír": "sourire", "jugar": "jouer", "pedir": "demander",
             "dormir": "dormir", "morir": "mourir", "leer": "lire", "abrir": "ouvrir", "comer": "manger", "beber": "boire",
             "construir": "construire", "conducir": "conduire", "traducir": "traduire", "producir": "produire", "obtener": "obtenir",
             "mantener": "maintenir", "proponer": "proposer", "suponer": "supposer", "componer": "composer", "convenir": "convenir",
             "elegir": "choisir", "corregir": "corriger", "enviar": "envoyer", "continuar": "continuer", "nacer": "naître",
             "crecer": "grandir", "ofrecer": "offrir", "servir": "servir", "repetir": "répéter", "vestirse": "s'habiller",
             "levantarse": "se lever", "acostarse": "se coucher", "despertarse": "se réveiller", "ducharse": "se doucher",
             "llamarse": "s'appeler", "sentarse": "s'asseoir", "irse": "s'en aller", "quedarse": "rester", "lavarse": "se laver",
             "preferir": "préférer", "mentir": "mentir", "atraer": "attirer", "distraer": "distraire", "detener": "arrêter",
             "contener": "contenir", "prevenir": "prévenir", "deshacer": "défaire", "predecir": "prédire", "incluir": "inclure",
             "destruir": "détruire", "huir": "fuir", "influir": "influencer", "contribuir": "contribuer", "distribuir": "distribuer"}
    for k, v in extra.items():
        verbs.setdefault(k, v)

    alias = {}
    base_list = {}
    for inf, fr in verbs.items():
        if inf.endswith("se") and inf[:-2][-2:] in ("ar", "er", "ir", "ír"):
            base = inf[:-2]
            alias[inf] = [base, fr]
            base_list.setdefault(base, re.sub(r"^(se |s')", "", fr))
        else:
            base_list[inf] = fr

    out = []
    for inf in sorted(base_list):
        try:
            c = conjugate(inf, **traits_for(inf))
        except Exception as e:  # verbe mal formé : ignoré
            print("ignoré", inf, e)
            continue
        marks = irregular_marks(inf, c)
        out.append({"i": inf, "f": base_list[inf], "g": c["gerund"], "p": c["participle"],
                    "t": ["|".join(c["tenses"][tid]) for tid, *_ in TENSES],
                    "x": [marks[tid] for tid, *_ in TENSES]})
    doc = {"tenses": [{"id": a, "name": b, "nameEs": c_, "mood": d, "rule": e} for a, b, c_, d, e in TENSES],
           "verbs": out, "alias": alias}
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(doc, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    print(OUT.name, len(out), "verbes,", len(alias), "pronominaux,", OUT.stat().st_size // 1024, "Ko")
    return {v["i"]: v for v in out}


if __name__ == "__main__":
    db = build()
    for inf in ("obtener", "proponer", "convenir", "construir", "conducir", "enviar", "continuar", "reír", "oír", "caber",
                "elegir", "nacer", "jugar", "dormir", "pedir", "atraer", "predecir", "deshacer", "andar", "leer", "abrir"):
        if inf in db:
            t = db[inf]["t"]
            print(f"{inf:10} PRES {t[0]} | INDEF {t[3]} | FUT {t[5].split('|')[0]} | SUBJ {t[9]} | IMP {t[13]} | {db[inf]['g']} {db[inf]['p']}")
