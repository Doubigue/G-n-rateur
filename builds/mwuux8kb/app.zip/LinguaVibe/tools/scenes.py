#!/usr/bin/env python3
"""Générateur des scènes lineart « style africain » pour les dialogues (Model 2 et 3).

Chaque scène est une liste de traits (chemin SVG, épaisseur, type) dans un cadre 240 × 150.
type : 's' trait encre, 'a' trait accent (or), 'f' remplissage accent.
Sorties : previews/<nom>.svg (+ .png via rsvg-convert) et Scenes.kt (bibliothèque Compose).
"""
import math
import os
import subprocess
import sys

W, H = 240, 150
GROUND = 132


def f2(v):
    return f"{v:.1f}".rstrip("0").rstrip(".")


class Scene:
    def __init__(self):
        self.items = []

    def s(self, d, w=1.0):
        self.items.append((d, w, "s"))

    def a(self, d, w=1.0):
        self.items.append((d, w, "a"))

    def f(self, d):
        self.items.append((d, 1.0, "f"))

    # ---------------------------------------------------------------- primitives
    def circle(self, cx, cy, r, kind="s", w=1.0):
        d = f"M{f2(cx - r)} {f2(cy)} a{f2(r)} {f2(r)} 0 1 0 {f2(2 * r)} 0 a{f2(r)} {f2(r)} 0 1 0 {f2(-2 * r)} 0"
        self.items.append((d, w, kind))

    def dot(self, cx, cy, w=1.5):
        # Petit point d'encre : un cercle minuscule tracé épais.
        self.s(f"M{f2(cx - .35)} {f2(cy)} a0.35 0.35 0 1 0 0.7 0 a0.35 0.35 0 1 0 -0.7 0", w)

    def line(self, pts, kind="s", w=1.0, close=False):
        d = "M" + " L".join(f"{f2(x)} {f2(y)}" for x, y in pts) + (" Z" if close else "")
        self.items.append((d, w, kind))

    def zigzag(self, x0, x1, y, amp=2.5, step=4, kind="a", w=0.8):
        pts, x, up = [], x0, True
        while x <= x1 + .01:
            pts.append((x, y - amp if up else y))
            up = not up
            x += step
        self.line(pts, kind, w)

    def dots_row(self, x0, x1, y, step=4, r=0.9):
        x = x0
        while x <= x1 + .01:
            self.circle(x, y, r, "f")
            x += step

    def ground(self, x0=6, x1=234, border=True):
        self.s(f"M{x0} {GROUND} H{x1}", 1.1)
        if border:
            self.zigzag(x0 + 4, x1 - 4, GROUND + 9, 3, 5, "a", 0.8)
            self.dots_row(x0 + 6.5, x1 - 6, GROUND + 13.5, 5, 0.8)

    # ---------------------------------------------------------------- décor
    def sun(self, cx, cy, r=8):
        self.circle(cx, cy, r, "a", 1.0)
        for k in range(10):
            t = k * math.pi / 5
            self.a(f"M{f2(cx + math.cos(t) * (r + 3))} {f2(cy + math.sin(t) * (r + 3))} "
                   f"L{f2(cx + math.cos(t) * (r + 6))} {f2(cy + math.sin(t) * (r + 6))}", 0.8)

    def moon(self, cx, cy, r=7):
        self.a(f"M{f2(cx)} {f2(cy - r)} a{r} {r} 0 1 0 {f2(r * .2)} {f2(2 * r)} "
               f"a{f2(r * .75)} {f2(r * .75)} 0 1 1 {f2(-r * .2)} {f2(-2 * r)}", 1.0)

    def stars(self, pts):
        for x, y in pts:
            self.a(f"M{f2(x - 2)} {f2(y)} H{f2(x + 2)} M{f2(x)} {f2(y - 2)} V{f2(y + 2)}", 0.6)

    def birds(self, pts):
        for x, y in pts:
            self.s(f"M{f2(x - 4)} {f2(y)} q2 -2.5 4 0 q2 -2.5 4 0", 0.7)

    def cloud(self, x, y, s=1.0):
        self.s(f"M{f2(x)} {f2(y)} q{f2(2 * s)} {f2(-7 * s)} {f2(9 * s)} {f2(-5 * s)} "
               f"q{f2(4 * s)} {f2(-7 * s)} {f2(11 * s)} {f2(-1 * s)} q{f2(7 * s)} {f2(-1 * s)} {f2(6 * s)} {f2(6 * s)} Z", 0.8)

    def hut(self, x, w=46, h=30, roof=24):
        """Case ronde au toit de chaume conique. x = bord gauche."""
        y0 = GROUND
        self.s(f"M{f2(x)} {y0} V{f2(y0 - h)} M{f2(x + w)} {y0} V{f2(y0 - h)}", 1.0)
        # toit
        self.s(f"M{f2(x - 6)} {f2(y0 - h + 2)} L{f2(x + w / 2)} {f2(y0 - h - roof)} L{f2(x + w + 6)} {f2(y0 - h + 2)} "
               f"Q{f2(x + w / 2)} {f2(y0 - h + 7)} {f2(x - 6)} {f2(y0 - h + 2)} Z", 1.1)
        for k in range(1, 6):
            t = k / 6
            xa = x - 6 + (w + 12) * t
            self.s(f"M{f2(xa)} {f2(y0 - h + 3 + 2.5 * math.sin(t * math.pi))} L{f2(x + w / 2 + (xa - x - w / 2) * .35)} "
                   f"{f2(y0 - h - roof * .62)}", 0.5)
        # porte
        dx = x + w * .55
        self.s(f"M{f2(dx)} {y0} V{f2(y0 - 17)} q6 -5 12 0 V{y0}", 0.9)
        # frise bogolan
        self.zigzag(x + 2, x + w - 2, y0 - h + 9, 2.2, 4, "a", 0.7)
        self.dots_row(x + 4, x + w * .5, y0 - 8, 4, 0.7)

    def house(self, x, w=60, h=34, door=True, window=True):
        """Maison en banco au toit de tôle."""
        y0 = GROUND
        self.line([(x, y0), (x, y0 - h), (x + w, y0 - h), (x + w, y0)], "s", 1.0)
        self.s(f"M{f2(x - 5)} {f2(y0 - h)} L{f2(x + 4)} {f2(y0 - h - 12)} H{f2(x + w - 4)} L{f2(x + w + 5)} {f2(y0 - h)} Z", 1.0)
        for k in range(1, 8):
            xx = x + 4 + (w - 8) * k / 8
            self.s(f"M{f2(xx)} {f2(y0 - h - 11.5)} L{f2(xx + (xx - x - w / 2) * .12)} {f2(y0 - h - .5)}", 0.45)
        if door:
            self.line([(x + w * .62, y0), (x + w * .62, y0 - 21), (x + w * .62 + 11, y0 - 21), (x + w * .62 + 11, y0)], "s", 0.9)
            self.dot(x + w * .62 + 8.5, y0 - 10, 1.8)
        if window:
            wx, wy = x + w * .14, y0 - h + 8
            self.line([(wx, wy), (wx + 13, wy), (wx + 13, wy + 11), (wx, wy + 11)], "s", 0.9, close=True)
            self.s(f"M{f2(wx + 6.5)} {f2(wy)} V{f2(wy + 11)}", 0.6)
            self.a(f"M{f2(wx - 1)} {f2(wy - 2)} H{f2(wx + 14)}", 0.8)
        self.zigzag(x + 2, x + w - 2, y0 - 4, 2, 4, "a", 0.6)

    def baobab(self, x, scale=1.0):
        s = scale
        y0 = GROUND
        self.s(f"M{f2(x - 9 * s)} {y0} C{f2(x - 7 * s)} {f2(y0 - 20 * s)} {f2(x - 9 * s)} {f2(y0 - 38 * s)} {f2(x - 6 * s)} {f2(y0 - 52 * s)} "
               f"M{f2(x + 9 * s)} {y0} C{f2(x + 7 * s)} {f2(y0 - 20 * s)} {f2(x + 9 * s)} {f2(y0 - 38 * s)} {f2(x + 6 * s)} {f2(y0 - 52 * s)}", 1.2)
        for dx, dy, c in ((-6, -52, (-22, -66, -30, -64)), (-2, -53, (-10, -72, -16, -76)), (2, -53, (8, -70, 14, -78)), (6, -52, (20, -64, 30, -66))):
            self.s(f"M{f2(x + dx * s)} {f2(y0 + dy * s)} Q{f2(x + c[0] * s)} {f2(y0 + c[1] * s)} {f2(x + c[2] * s)} {f2(y0 + c[3] * s)}", 0.9)
        for cx, cy in ((-30, -66), (-16, -78), (14, -80), (30, -68), (0, -74)):
            self.cloud(x + cx * s - 6 * s, y0 + cy * s + 2 * s, 0.55 * s)
        self.s(f"M{f2(x - 4 * s)} {f2(y0 - 18 * s)} q3 2 6 0 M{f2(x - 2 * s)} {f2(y0 - 30 * s)} q3 2 5 0", 0.5)

    def palm(self, x, scale=1.0):
        s = scale
        y0 = GROUND
        top = (x + 6 * s, y0 - 58 * s)
        self.s(f"M{f2(x)} {y0} Q{f2(x - 3 * s)} {f2(y0 - 30 * s)} {f2(top[0])} {f2(top[1])}", 1.2)
        for k in range(6):
            self.s(f"M{f2(x - 2 * s)} {f2(y0 - 8 * s - 8 * k * s)} l{f2(4 * s)} {f2(-1.5 * s)}", 0.5)
        for ang, ln in ((-160, 26), (-130, 22), (-95, 18), (-60, 22), (-25, 26), (10, 20), (190, 20)):
            t = math.radians(ang)
            ex, ey = top[0] + math.cos(t) * ln * s, top[1] + math.sin(t) * ln * s
            mx, my = top[0] + math.cos(t) * ln * .5 * s, top[1] + math.sin(t) * ln * .5 * s - 6 * s
            self.s(f"M{f2(top[0])} {f2(top[1])} Q{f2(mx)} {f2(my)} {f2(ex)} {f2(ey)}", 0.9)
        self.circle(top[0] - 2 * s, top[1] + 4 * s, 2 * s, "f")
        self.circle(top[0] + 2.5 * s, top[1] + 5 * s, 2 * s, "f")

    def tree(self, x, scale=1.0):
        s = scale
        y0 = GROUND
        self.s(f"M{f2(x - 3 * s)} {y0} L{f2(x - 2 * s)} {f2(y0 - 30 * s)} M{f2(x + 3 * s)} {y0} L{f2(x + 2 * s)} {f2(y0 - 30 * s)}", 1.1)
        self.s(f"M{f2(x - 24 * s)} {f2(y0 - 34 * s)} q-2 -14 12 -18 q4 -14 20 -10 q14 -6 18 8 q12 4 6 18 q-2 8 -18 6 q-10 6 -22 0 q-14 2 -16 -4 Z", 1.0)
        self.s(f"M{f2(x)} {f2(y0 - 30 * s)} l-8 -8 M{f2(x)} {f2(y0 - 32 * s)} l7 -9", 0.6)

    def bushes(self, x, w):
        k = int(w // 12)
        for i in range(k):
            bx = x + i * 12
            self.s(f"M{f2(bx)} {GROUND} q1 -11 6 -10 q5 -1 6 10", 0.8)
        for i in range(k):
            self.a(f"M{f2(x + 4 + i * 12)} {GROUND - 7} a1.6 1.6 0 1 0 3.2 0 a1.6 1.6 0 1 0 -3.2 0", 0.7)

    def flag(self, x, h=62):
        y0 = GROUND
        self.s(f"M{f2(x)} {y0} V{f2(y0 - h)}", 1.1)
        self.circle(x, y0 - h - 1.5, 1.5, "f")
        top = y0 - h + 2
        self.s(f"M{f2(x)} {f2(top)} q8 -3 16 0 t16 0 v14 q-8 3 -16 0 t-16 0", 0.9)
        self.s(f"M{f2(x + 11)} {f2(top - 1)} v15 M{f2(x + 22)} {f2(top - 1)} v15", 0.6)
        self.f(f"M{f2(x + 22)} {f2(top - 0.5)} q5 -1.5 10 0 v14 q-5 1.5 -10 0 Z")

    def fire(self, x, y=None):
        y = GROUND if y is None else y
        self.s(f"M{f2(x - 12)} {f2(y)} L{f2(x + 10)} {f2(y - 5)} M{f2(x - 10)} {f2(y - 5)} L{f2(x + 12)} {f2(y)}", 1.1)
        self.f(f"M{f2(x - 6)} {f2(y - 4)} q-4 -10 4 -18 q-1 7 4 9 q2 -5 0 -9 q8 6 4 18 Z")
        self.s(f"M{f2(x - 6)} {f2(y - 4)} q-4 -10 4 -18 q-1 7 4 9 q2 -5 0 -9 q8 6 4 18 Z", 0.8)
        for k, (dx, dy) in enumerate(((-4, -26), (3, -30), (8, -24))):
            self.a(f"M{f2(x + dx)} {f2(y + dy)} l1 -2", 0.9)

    def stool(self, x, y=None, w=14):
        y = GROUND if y is None else y
        self.s(f"M{f2(x)} {f2(y - 9)} H{f2(x + w)} M{f2(x + 2)} {f2(y)} L{f2(x + 3)} {f2(y - 9)} M{f2(x + w - 2)} {f2(y)} L{f2(x + w - 3)} {f2(y - 9)} "
               f"M{f2(x + w / 2)} {f2(y)} V{f2(y - 9)}", 1.0)

    def round_table(self, cx, w=56, h=22, food=True):
        y0 = GROUND
        top = y0 - h
        self.s(f"M{f2(cx - w / 2)} {f2(top)} Q{f2(cx)} {f2(top - 7)} {f2(cx + w / 2)} {f2(top)} Q{f2(cx)} {f2(top + 7)} {f2(cx - w / 2)} {f2(top)} Z", 1.0)
        # nappe festonnée
        self.s(f"M{f2(cx - w / 2)} {f2(top)} V{f2(top + 10)} " + " ".join(
            f"q{f2(w / 12)} 3 {f2(w / 6)} 0" for _ in range(6)) + f" V{f2(top)}", 0.9)
        self.dots_row(cx - w / 2 + 4, cx + w / 2 - 4, top + 6, 5, 0.7)
        self.s(f"M{f2(cx - 10)} {f2(top + 11)} L{f2(cx - 12)} {y0} M{f2(cx + 10)} {f2(top + 11)} L{f2(cx + 12)} {y0}", 1.0)
        if food:
            self.s(f"M{f2(cx - 9)} {f2(top - 2)} q9 -12 18 0", 1.0)  # plat (attiéké / foutou)
            self.s(f"M{f2(cx - 11)} {f2(top - 2)} H{f2(cx + 11)}", 0.8)
            self.a(f"M{f2(cx - 4)} {f2(top - 8)} q2 -4 0 -7 M{f2(cx + 3)} {f2(top - 8)} q2 -4 0 -7", 0.7)
            for dx in (-w / 2 + 8, w / 2 - 12):
                self.s(f"M{f2(cx + dx)} {f2(top - 1)} h5 l-1 -5 h-3 Z", 0.7)

    def chair(self, x, facing=1, y=None):
        y = GROUND if y is None else y
        b = x - 6 * facing
        self.s(f"M{f2(b)} {f2(y)} V{f2(y - 30)} M{f2(b)} {f2(y - 14)} H{f2(b + 13 * facing)} V{f2(y)}", 1.0)
        self.s(f"M{f2(b)} {f2(y - 24)} h{f2(-1 * facing)}", 0.5)

    def blackboard(self, x, y, w=70, h=40, text_lines=None):
        self.line([(x, y), (x + w, y), (x + w, y + h), (x, y + h)], "s", 1.1, close=True)
        self.line([(x + 3, y + 3), (x + w - 3, y + 3), (x + w - 3, y + h - 3), (x + 3, y + h - 3)], "s", 0.5, close=True)
        self.s(f"M{f2(x + 6)} {f2(y + h)} v4 h10 v-4", 0.6)
        for i, ln in enumerate(text_lines or []):
            self.a(ln.format(x=x, y=y), 0.8)

    def stall(self, x, w=74, h=26):
        """Étal de marché : planche, paniers et tas de fruits, parasol."""
        y0 = GROUND
        top = y0 - h
        self.s(f"M{f2(x)} {f2(top)} H{f2(x + w)} M{f2(x + 4)} {f2(top)} V{y0} M{f2(x + w - 4)} {f2(top)} V{y0}", 1.1)
        self.s(f"M{f2(x)} {f2(top + 4)} H{f2(x + w)}", 0.6)
        # tas de tomates / oranges
        for i, cx in enumerate((x + 12, x + 30, x + 50)):
            for (dx, dy) in ((-5, -3), (0, -3), (5, -3), (-2.5, -7.5), (2.5, -7.5), (0, -11.5)):
                self.circle(cx + dx, top + dy, 2.4, "s" if i == 1 else "f", 0.7)
        # panier
        bx = x + w - 18
        self.s(f"M{f2(bx)} {f2(top)} l2 -10 h12 l2 10", 0.9)
        self.zigzag(bx + 2, bx + 14, top - 4, 2, 3, "a", 0.6)
        self.s(f"M{f2(bx + 3)} {f2(top - 10)} q5 -9 10 0", 0.7)
        # parasol
        px = x + w * .45
        self.s(f"M{f2(px)} {f2(top - 14)} V{f2(top - 46)}", 0.9)
        self.s(f"M{f2(px - 36)} {f2(top - 40)} Q{f2(px)} {f2(top - 62)} {f2(px + 36)} {f2(top - 40)} "
               + " ".join("q-6 4 -12 0" for _ in range(6)), 1.0)
        self.a(f"M{f2(px - 24)} {f2(top - 44)} L{f2(px)} {f2(top - 55)} L{f2(px + 24)} {f2(top - 44)}", 0.7)

    def bus(self, x, w=92):
        """Gbaka / car de gare routière."""
        y0 = GROUND - 5
        h = 36
        self.s(f"M{f2(x)} {f2(y0)} V{f2(y0 - h + 6)} q0 -6 6 -6 H{f2(x + w - 12)} q8 0 10 10 l2 14 V{f2(y0)} Z", 1.1)
        for i in range(4):
            wx = x + 6 + i * 17
            self.line([(wx, y0 - h + 5), (wx + 13, y0 - h + 5), (wx + 13, y0 - h + 17), (wx, y0 - h + 17)], "s", 0.8, close=True)
        self.s(f"M{f2(x + w - 16)} {f2(y0 - h + 5)} h6 l4 12 h-10 Z", 0.8)
        self.zigzag(x + 3, x + w - 3, y0 - 9, 2, 4, "a", 0.7)
        for wx in (x + 18, x + w - 20):
            self.circle(wx, y0, 6, "s", 1.1)
            self.circle(wx, y0, 2, "f")
        # bagages sur le toit
        self.s(f"M{f2(x + 14)} {f2(y0 - h)} v-7 h20 v7 M{f2(x + 38)} {f2(y0 - h)} v-5 h14 v5", 0.8)
        self.a(f"M{f2(x + 14)} {f2(y0 - h - 3.5)} h20", 0.6)

    def clock(self, cx, cy, r=8, hh=3, mm=0):
        self.circle(cx, cy, r, "s", 1.0)
        for k in range(12):
            t = k * math.pi / 6
            self.s(f"M{f2(cx + math.sin(t) * (r - 1.5))} {f2(cy - math.cos(t) * (r - 1.5))} L{f2(cx + math.sin(t) * (r - .4))} {f2(cy - math.cos(t) * (r - .4))}", 0.5)
        th = (hh % 12 + mm / 60) * math.pi / 6
        tm = mm * math.pi / 30
        self.a(f"M{f2(cx)} {f2(cy)} L{f2(cx + math.sin(th) * r * .5)} {f2(cy - math.cos(th) * r * .5)}", 1.0)
        self.a(f"M{f2(cx)} {f2(cy)} L{f2(cx + math.sin(tm) * r * .78)} {f2(cy - math.cos(tm) * r * .78)}", 0.8)

    def bubble(self, x, y, w=34, h=16, tail=-1):
        """Bulle de parole vide (pointillés à l'intérieur)."""
        self.s(f"M{f2(x + 5)} {f2(y)} H{f2(x + w - 5)} q5 0 5 5 v{f2(h - 10)} q0 5 -5 5 "
               f"H{f2(x + w / 2 + 6 if tail > 0 else x + w / 2 + 2)} l{f2(4 * tail)} 6 l{f2(-1 * tail)} -6 "
               f"H{f2(x + 5)} q-5 0 -5 -5 v{f2(-(h - 10))} q0 -5 5 -5 Z", 0.8)
        for k in range(3):
            self.circle(x + w / 2 - 6 + k * 6, y + h / 2, 1.1, "f")

    # ---------------------------------------------------------------- personnages
    def person(self, x, kind="man", h=70, facing=1, arms=("down", "down"), seated=False, pattern="dots", mouth="smile"):
        """Personnage debout (ou assis) : x = centre, pieds au sol.
        kind : man, woman, boy, girl, elder, grandma, teacher, nurse, vendor, father."""
        y0 = GROUND
        s = h / 70.0
        hr = 6.4 * s                       # rayon de la tête
        leg = 0 if seated else 24 * s
        hip = y0 - (11 * s if seated else leg)
        sh = hip - 24 * s                  # épaules
        hy = sh - hr - 2.5 * s             # centre de la tête
        fx = facing
        robe = kind in ("woman", "grandma", "girl", "vendor", "nurse", "teacher_w")
        boubou = kind in ("elder",)
        # --- tête
        self.circle(x, hy, hr, "s", 1.0)
        # yeux, bouche
        ex = 2.2 * s
        self.dot(x - ex + fx * .8 * s, hy - .3 * s)
        self.dot(x + ex + fx * .8 * s, hy - .3 * s)
        if mouth == "smile":
            self.s(f"M{f2(x - 1.8 * s + fx * .8 * s)} {f2(hy + 2.4 * s)} q{f2(1.8 * s)} {f2(1.6 * s)} {f2(3.6 * s)} 0", 0.7)
        elif mouth == "open":
            self.circle(x + fx * .8 * s, hy + 2.8 * s, 1.0 * s, "s", 0.7)
        elif mouth == "sad":
            self.s(f"M{f2(x - 1.8 * s + fx * .8 * s)} {f2(hy + 3.4 * s)} q{f2(1.8 * s)} {f2(-1.5 * s)} {f2(3.6 * s)} 0", 0.7)
        # --- coiffe
        if kind in ("woman", "vendor", "grandma", "teacher_w"):
            # foulard noué (gele) haut
            self.s(f"M{f2(x - hr - .6)} {f2(hy - 1 * s)} C{f2(x - hr - 2 * s)} {f2(hy - 13 * s)} {f2(x + hr + 2 * s)} {f2(hy - 13 * s)} "
                   f"{f2(x + hr + .6)} {f2(hy - 1 * s)}", 1.0)
            self.s(f"M{f2(x - hr)} {f2(hy - 3.5 * s)} Q{f2(x)} {f2(hy - 6.5 * s)} {f2(x + hr)} {f2(hy - 3.5 * s)}", 0.6)
            kx = x - fx * (hr - 1)
            self.a(f"M{f2(kx)} {f2(hy - 9 * s)} c{f2(-fx * 6 * s)} {f2(-6 * s)} {f2(-fx * 10 * s)} {f2(1 * s)} {f2(-fx * 3 * s)} {f2(3 * s)} "
                   f"M{f2(kx)} {f2(hy - 9 * s)} c{f2(fx * 2 * s)} {f2(-7 * s)} {f2(fx * 9 * s)} {f2(-6 * s)} {f2(fx * 5 * s)} {f2(-1 * s)}", 0.9)
            self.dots_row(x - hr + 2 * s, x + hr - 2 * s, hy - 8.2 * s, 3 * s, 0.6 * s)
            if kind == "grandma":
                self.s(f"M{f2(x - 3.5 * s)} {f2(hy + .2 * s)} h{f2(2.6 * s)} M{f2(x + .9 * s)} {f2(hy + .2 * s)} h{f2(2.6 * s)}", 0.5)
        elif kind == "girl":
            # tresses / couettes
            self.s(f"M{f2(x - hr)} {f2(hy - 1 * s)} Q{f2(x)} {f2(hy - 11 * s)} {f2(x + hr)} {f2(hy - 1 * s)}", 1.0)
            for side in (-1, 1):
                bx = x + side * (hr + 1.5 * s)
                self.s(f"M{f2(x + side * hr * .8)} {f2(hy - 4 * s)} q{f2(side * 4 * s)} {f2(-3 * s)} {f2(side * 4 * s)} {f2(3 * s)}", 0.8)
                self.circle(bx + side * 1.4 * s, hy - .5 * s, 1.6 * s, "a", 0.8)
            for k in (-2.5, 0, 2.5):
                self.s(f"M{f2(x + k * s)} {f2(hy - hr - .5)} l{f2(k * .2 * s)} {f2(-3 * s)}", 0.6)
        elif kind in ("man", "father", "teacher"):
            self.s(f"M{f2(x - hr + .4)} {f2(hy - 1.5 * s)} Q{f2(x)} {f2(hy - 9.5 * s)} {f2(x + hr - .4)} {f2(hy - 1.5 * s)}", 1.4)
            if kind == "teacher":
                self.s(f"M{f2(x - 4.2 * s)} {f2(hy - .3 * s)} a{f2(1.8 * s)} {f2(1.8 * s)} 0 1 0 {f2(3.6 * s)} 0 a{f2(1.8 * s)} {f2(1.8 * s)} 0 1 0 {f2(-3.6 * s)} 0 "
                       f"M{f2(x + .6 * s)} {f2(hy - .3 * s)} a{f2(1.8 * s)} {f2(1.8 * s)} 0 1 0 {f2(3.6 * s)} 0 a{f2(1.8 * s)} {f2(1.8 * s)} 0 1 0 {f2(-3.6 * s)} 0", 0.6)
            if kind == "father":
                self.s(f"M{f2(x - 2.4 * s + fx * .8 * s)} {f2(hy + 1.5 * s)} h{f2(4.8 * s)}", 0.8)  # moustache
        elif kind == "elder":
            # bonnet (kufi) brodé + barbe
            self.s(f"M{f2(x - hr)} {f2(hy - 2.5 * s)} V{f2(hy - 7.5 * s)} Q{f2(x)} {f2(hy - 11 * s)} {f2(x + hr)} {f2(hy - 7.5 * s)} V{f2(hy - 2.5 * s)} Z", 1.0)
            self.zigzag(x - hr + 1, x + hr - 1, hy - 4, 1.6 * s, 2.4 * s, "a", 0.6)
            self.s(f"M{f2(x - hr + 1)} {f2(hy + 2 * s)} q{f2(hr - 1)} {f2(9 * s)} {f2(2 * hr - 2)} 0", 0.8)
            self.s(f"M{f2(x - 2 * s)} {f2(hy + 5 * s)} l1 3 M{f2(x + 1 * s)} {f2(hy + 5.5 * s)} l0 3", 0.5)
        elif kind == "boy":
            self.s(f"M{f2(x - hr + .6)} {f2(hy - 2 * s)} Q{f2(x)} {f2(hy - 8.5 * s)} {f2(x + hr - .6)} {f2(hy - 2 * s)}", 1.2)
        elif kind == "nurse":
            self.s(f"M{f2(x - hr)} {f2(hy - 3 * s)} h{f2(2 * hr)} l{f2(-1.5 * s)} {f2(-5 * s)} h{f2(-2 * hr + 3 * s)} Z", 0.9)
            self.a(f"M{f2(x)} {f2(hy - 7 * s)} v3 M{f2(x - 1.5 * s)} {f2(hy - 5.5 * s)} h3", 0.8)
        # --- cou
        self.s(f"M{f2(x)} {f2(hy + hr)} V{f2(sh)}", 0.9)
        # --- corps
        if robe or boubou:
            width = 13 * s if boubou else 11 * s
            bottom = (y0 - 1) if not seated else hip + 4 * s
            if seated:
                bottom = hip + 2 * s
            self.s(f"M{f2(x - 6 * s)} {f2(sh)} Q{f2(x - width)} {f2((sh + bottom) / 2)} {f2(x - width - 2 * s)} {f2(bottom)} "
                   f"H{f2(x + width + 2 * s)} Q{f2(x + width)} {f2((sh + bottom) / 2)} {f2(x + 6 * s)} {f2(sh)} Z", 1.0)
            # motif wax
            band = sh + (bottom - sh) * .55
            if pattern == "dots":
                self.dots_row(x - width + 2 * s, x + width - 1 * s, band, 3.2 * s, 0.75 * s)
                self.dots_row(x - width + 3.5 * s, x + width - 2.5 * s, band + 5 * s, 3.2 * s, 0.75 * s)
            elif pattern == "zigzag":
                self.zigzag(x - width + 1 * s, x + width - 1 * s, band, 2.2 * s, 3 * s, "a", 0.8)
                self.zigzag(x - width, x + width, band + 6 * s, 2.2 * s, 3 * s, "a", 0.8)
            elif pattern == "kente":
                for k in range(-2, 3):
                    self.a(f"M{f2(x + k * 3.6 * s)} {f2(sh + 6 * s)} V{f2(bottom - 2)}", 0.6)
            if boubou:
                self.a(f"M{f2(x - 4 * s)} {f2(sh + 1 * s)} Q{f2(x)} {f2(sh + 9 * s)} {f2(x + 4 * s)} {f2(sh + 1 * s)}", 0.9)
            if not seated:
                self.s(f"M{f2(x - 4 * s)} {f2(bottom)} V{y0} M{f2(x + 4 * s)} {f2(bottom)} V{y0}", 0.9)
                self.s(f"M{f2(x - 4 * s)} {y0} h{f2(-4 * s * (1 if fx > 0 else -.3))} M{f2(x + 4 * s)} {y0} h{f2(4 * s * (1 if fx > 0 else -.3) * fx)}", 0.9)
        else:
            # chemise + pantalon / short
            self.s(f"M{f2(x - 7 * s)} {f2(sh + 1 * s)} L{f2(x - 7.5 * s)} {f2(hip)} H{f2(x + 7.5 * s)} L{f2(x + 7 * s)} {f2(sh + 1 * s)} Z", 1.0)
            self.s(f"M{f2(x - 2.5 * s)} {f2(sh + .5 * s)} L{f2(x)} {f2(sh + 4 * s)} L{f2(x + 2.5 * s)} {f2(sh + .5 * s)}", 0.7)
            if pattern == "dots":
                self.dots_row(x - 4.5 * s, x + 5 * s, sh + 10 * s, 3.2 * s, 0.7 * s)
            elif pattern == "zigzag":
                self.zigzag(x - 6 * s, x + 6 * s, sh + 12 * s, 2 * s, 3 * s, "a", 0.7)
            elif pattern == "kente":
                self.a(f"M{f2(x - 7.2 * s)} {f2(sh + 14 * s)} H{f2(x + 7.2 * s)} M{f2(x - 7.3 * s)} {f2(sh + 17 * s)} H{f2(x + 7.3 * s)}", 0.7)
            if seated:
                self.s(f"M{f2(x - 6 * s)} {f2(hip)} h{f2(fx * 13 * s)} V{y0} M{f2(x + 2 * s)} {f2(hip)} h{f2(fx * 9 * s)} V{y0}", 1.0)
            else:
                short = kind == "boy"
                knee = hip + (10 * s if short else 0)
                if short:
                    self.s(f"M{f2(x - 7.5 * s)} {f2(hip)} L{f2(x - 8 * s)} {f2(knee)} H{f2(x - .5 * s)} L{f2(x)} {f2(hip + 3 * s)} "
                           f"L{f2(x + .5 * s)} {f2(knee)} H{f2(x + 8 * s)} L{f2(x + 7.5 * s)} {f2(hip)}", 1.0)
                    self.s(f"M{f2(x - 4.5 * s)} {f2(knee)} V{y0} M{f2(x + 4.5 * s)} {f2(knee)} V{y0}", 0.9)
                else:
                    self.s(f"M{f2(x - 7.5 * s)} {f2(hip)} L{f2(x - 6 * s)} {y0} M{f2(x - 1 * s)} {y0} L{f2(x)} {f2(hip + 5 * s)} "
                           f"L{f2(x + 1 * s)} {y0} M{f2(x + 6 * s)} {y0} L{f2(x + 7.5 * s)} {f2(hip)}", 1.0)
                    if kind == "father":  # bottes
                        self.s(f"M{f2(x - 6.5 * s)} {f2(y0 - 7 * s)} h{f2(6 * s)} M{f2(x + .5 * s)} {f2(y0 - 7 * s)} h{f2(6 * s)}", 0.8)
                self.s(f"M{f2(x - 4 * s)} {y0} h{f2(fx * 4.5 * s)} M{f2(x + 4 * s)} {y0} h{f2(fx * 4.5 * s)}", 1.0)
        # --- bras
        for side, pose in ((-1, arms[0]), (1, arms[1])):
            sx = x + side * (6.5 * s if not (robe or boubou) else 6 * s)
            sy = sh + 2 * s
            L = 20 * s
            if pose == "down":
                ex_, ey_ = sx + side * 3 * s, sy + L
                self.s(f"M{f2(sx)} {f2(sy)} Q{f2(sx + side * 4 * s)} {f2(sy + L * .5)} {f2(ex_)} {f2(ey_)}", 0.9)
            elif pose == "wave":
                ex_, ey_ = sx + side * 8 * s, sy - 16 * s
                self.s(f"M{f2(sx)} {f2(sy)} Q{f2(sx + side * 10 * s)} {f2(sy - 2 * s)} {f2(ex_)} {f2(ey_)}", 0.9)
                self.s(f"M{f2(ex_ - 2 * s)} {f2(ey_ - 1 * s)} l{f2(-1 * s)} {f2(-4 * s)} M{f2(ex_)} {f2(ey_ - 1.5 * s)} v{f2(-4.5 * s)} "
                       f"M{f2(ex_ + 2 * s)} {f2(ey_ - 1 * s)} l{f2(1 * s)} {f2(-4 * s)}", 0.6)
                self.a(f"M{f2(ex_ + side * 5 * s)} {f2(ey_ - 4 * s)} q{f2(side * 2 * s)} {f2(2 * s)} 0 {f2(4 * s)}", 0.6)
            elif pose == "point":
                ex_, ey_ = sx + side * 18 * s, sy + 2 * s
                self.s(f"M{f2(sx)} {f2(sy)} Q{f2(sx + side * 9 * s)} {f2(sy + 4 * s)} {f2(ex_)} {f2(ey_)} l{f2(side * 4 * s)} {f2(-1 * s)}", 0.9)
            elif pose == "hip":
                self.s(f"M{f2(sx)} {f2(sy)} L{f2(sx + side * 7 * s)} {f2(sy + 9 * s)} L{f2(sx + side * 1 * s)} {f2(sy + 17 * s)}", 0.9)
            elif pose == "hold":
                ex_, ey_ = sx + side * 9 * s, sy + 12 * s
                self.s(f"M{f2(sx)} {f2(sy)} Q{f2(sx + side * 3 * s)} {f2(sy + 10 * s)} {f2(ex_)} {f2(ey_)}", 0.9)
            elif pose == "chin":
                self.s(f"M{f2(sx)} {f2(sy)} Q{f2(sx + side * 6 * s)} {f2(sy + 12 * s)} {f2(x + side * 2 * s)} {f2(hy + hr + 1 * s)}", 0.9)
            elif pose == "mouth":   # main en porte-voix
                self.s(f"M{f2(sx)} {f2(sy)} Q{f2(sx + side * 8 * s)} {f2(sy + 4 * s)} {f2(x + side * 5 * s)} {f2(hy + 3 * s)}", 0.9)
                self.s(f"M{f2(x + side * 5 * s)} {f2(hy + .5 * s)} l{f2(side * 4 * s)} {f2(-2.5 * s)} v{f2(7 * s)} Z", 0.7)
            elif pose == "phone":
                self.s(f"M{f2(sx)} {f2(sy)} Q{f2(sx + side * 7 * s)} {f2(sy + 6 * s)} {f2(x + side * 6 * s)} {f2(hy + 1 * s)}", 0.9)
                self.s(f"M{f2(x + side * 5 * s)} {f2(hy - 4 * s)} h{f2(side * 3 * s)} v{f2(8 * s)} h{f2(-side * 3 * s)} Z", 0.9)
            elif pose == "machete":
                ex_, ey_ = sx + side * 5 * s, sy + L
                self.s(f"M{f2(sx)} {f2(sy)} Q{f2(sx + side * 4 * s)} {f2(sy + L * .5)} {f2(ex_)} {f2(ey_)}", 0.9)
                self.s(f"M{f2(ex_)} {f2(ey_)} l{f2(side * 2 * s)} {f2(3 * s)} q{f2(side * 2 * s)} {f2(12 * s)} {f2(side * 9 * s)} {f2(15 * s)} "
                       f"q{f2(-side * 2 * s)} {f2(-8 * s)} {f2(-side * 7 * s)} {f2(-15 * s)}", 0.8)
            elif pose == "basket":  # bassine sur la tête, bras levé
                self.s(f"M{f2(sx)} {f2(sy)} Q{f2(sx + side * 6 * s)} {f2(sy - 8 * s)} {f2(x + side * 7 * s)} {f2(hy - 11 * s)}", 0.9)
            elif pose == "cane":
                ex_, ey_ = sx + side * 8 * s, sy + 14 * s
                self.s(f"M{f2(sx)} {f2(sy)} Q{f2(sx + side * 4 * s)} {f2(sy + 10 * s)} {f2(ex_)} {f2(ey_)}", 0.9)
                self.s(f"M{f2(ex_)} {f2(ey_ - 3 * s)} L{f2(ex_ + side * 2 * s)} {y0}", 1.0)
            elif pose == "book":
                ex_, ey_ = x + side * 3 * s, sy + 11 * s
                self.s(f"M{f2(sx)} {f2(sy)} Q{f2(sx + side * 5 * s)} {f2(sy + 10 * s)} {f2(ex_)} {f2(ey_)}", 0.9)
                if side == 1:
                    self.s(f"M{f2(x - 6 * s)} {f2(sy + 12 * s)} l{f2(6 * s)} {f2(2 * s)} l{f2(6 * s)} {f2(-2 * s)} v{f2(-7 * s)} l{f2(-6 * s)} {f2(2 * s)} l{f2(-6 * s)} {f2(-2 * s)} Z "
                           f"M{f2(x)} {f2(sy + 14 * s)} v{f2(-7 * s)}", 0.8)
        if "basket" in arms:
            self.s(f"M{f2(x - 9 * s)} {f2(hy - 11 * s)} H{f2(x + 9 * s)} l{f2(-3 * s)} {f2(-6 * s)} H{f2(x - 6 * s)} Z", 1.0)
            for k in range(-2, 3):
                self.circle(x + k * 3 * s, hy - 19 * s, 1.7 * s, "f")

    def boy_lying(self, x, y=None):
        """Enfant allongé, épuisé (Kadjo retrouvé)."""
        y = GROUND - 4 if y is None else y
        self.circle(x, y - 4, 5.2, "s", 1.0)
        self.dot(x + 1.5, y - 5)
        self.s(f"M{f2(x + .5)} {f2(y - 1.5)} q1.5 -1 3 0", 0.6)
        self.s(f"M{f2(x - 4.8)} {f2(y - 6.5)} Q{f2(x)} {f2(y - 12)} {f2(x + 4.8)} {f2(y - 6.5)}", 1.1)
        self.s(f"M{f2(x + 5)} {f2(y - 2)} L{f2(x + 24)} {f2(y - 1)} L{f2(x + 25)} {f2(y + 5)} L{f2(x + 5)} {f2(y + 4)} Z", 1.0)
        self.s(f"M{f2(x + 25)} {f2(y)} L{f2(x + 42)} {f2(y + 2)} M{f2(x + 25)} {f2(y + 4)} L{f2(x + 41)} {f2(y + 5)}", 0.9)
        self.s(f"M{f2(x + 10)} {f2(y - 1)} q2 -8 -5 -9", 0.8)
        self.dots_row(x + 9, x + 21, y + 1.5, 3, 0.6)
        # taches (sale)
        self.a(f"M{f2(x + 14)} {f2(y + 6)} l2 0 M{f2(x + 33)} {f2(y + 3)} l1.5 .5", 0.8)

    def spirit(self, x, y):
        """Génie de la forêt (conte) — silhouette ailée stylisée, plutôt masque qu'effrayante."""
        self.s(f"M{f2(x)} {f2(y)} q-30 -8 -42 6 q14 -2 22 4 q-10 2 -14 10 q12 -6 22 -4 Z", 0.9)
        self.s(f"M{f2(x + 10)} {f2(y)} q30 -8 42 6 q-14 -2 -22 4 q10 2 14 10 q-12 -6 -22 -4 Z", 0.9)
        # masque
        self.s(f"M{f2(x - 2)} {f2(y - 14)} q7 -6 14 0 v14 q-7 9 -14 0 Z", 1.0)
        self.a(f"M{f2(x)} {f2(y - 8)} l3 -2 M{f2(x + 10)} {f2(y - 8)} l-3 -2", 0.9)
        self.zigzag(x - 1, x + 11, y + 1, 1.6, 2.4, "a", 0.6)
        for k in range(3):
            self.a(f"M{f2(x + 1 + k * 4)} {f2(y - 15)} v-5", 0.7)
        self.s(f"M{f2(x)} {f2(y + 6)} q5 10 10 0", 0.8)


# =============================================================================== scènes

def scene_patio():
    """Cour d'école : drapeau, bâtiment, haies — Fatou se présente (Me llamo Fatou)."""
    sc = Scene()
    sc.ground()
    sc.house(150, 78, 40, door=True, window=True)
    sc.flag(18, 68)
    sc.bushes(46, 36)
    sc.sun(212, 20, 7)
    sc.birds([(110, 22), (124, 16)])
    sc.person(64, "girl", 54, 1, ("down", "wave"), pattern="dots")
    sc.person(86, "boy", 56, -1, ("down", "down"), pattern="zigzag")
    sc.person(118, "woman", 60, 1, ("hip", "down"), pattern="kente")
    sc.person(138, "man", 64, -1, ("wave", "down"), pattern="dots")
    sc.bubble(40, 22, 34, 15, 1)
    return sc


def scene_familia():
    """La famille à table (Mi familia) : père, mère, trois enfants, table ronde."""
    sc = Scene()
    sc.ground(border=True)
    # rideaux et fenêtre
    sc.s("M86 18 H156 V60 H86 Z", 0.9)
    sc.s("M121 18 V60", 0.6)
    sc.s("M84 16 q10 20 0 46 M158 16 q-10 20 0 46", 0.8)
    sc.a("M80 14 H162", 1.0)
    sc.zigzag(88, 154, 66, 2, 4, "a", 0.6)
    # TV
    sc.s("M194 96 h30 v22 h-30 Z M197 99 h20 v16 h-20 Z M190 118 h38 v14 M190 118 v14", 0.8)
    sc.round_table(121, 64, 24)
    sc.person(70, "father", 66, 1, ("down", "point"), pattern="kente")
    sc.person(100, "girl", 46, 1, ("down", "hold"), seated=False, pattern="dots")
    sc.person(143, "boy", 44, -1, ("hold", "down"), pattern="zigzag")
    sc.person(170, "woman", 64, -1, ("hold", "hip"), pattern="dots")
    sc.person(28, "girl", 40, 1, ("wave", "down"), pattern="zigzag")
    return sc


def scene_campo():
    """Le village : le père part au champ, Kadjo refuse (Escucha a tus padres)."""
    sc = Scene()
    sc.ground()
    sc.hut(150, 52, 32, 26)
    sc.palm(30, 1.0)
    sc.tree(214, 0.9)
    sc.sun(108, 22, 7)
    sc.person(82, "father", 70, 1, ("point", "machete"), pattern="kente")
    sc.person(132, "boy", 52, -1, ("chin", "down"), pattern="dots", mouth="sad")
    sc.bubble(60, 14, 38, 15, 1)
    sc.bubble(126, 40, 30, 14, -1)
    return sc


def scene_selva():
    """La forêt : le génie emporte l'enfant ; les villageois cherchent (« ¡Kadjo! ¿Dónde estás? »)."""
    sc = Scene()
    sc.ground()
    sc.baobab(40, 1.15)
    sc.palm(214, 0.95)
    sc.tree(172, 1.0)
    sc.spirit(98, 36)
    sc.circle(103, 50, 3.4, "s", 0.9)
    sc.s("M103 53.4 l-1 9 M100 57 l-5 3 M106 57 l5 2 M102 62 l-3 6 M102 62 l3 6", 0.8)
    sc.person(118, "man", 64, 1, ("mouth", "machete"), pattern="dots", mouth="open")
    sc.person(150, "woman", 60, -1, ("mouth", "down"), pattern="zigzag", mouth="open")
    sc.person(78, "man", 62, 1, ("down", "mouth"), pattern="kente", mouth="open")
    sc.a("M168 52 q6 -2 6 -8 M172 56 q9 -3 9 -12", 0.8)
    sc.a("M60 50 q-6 -2 -6 -8 M56 54 q-9 -3 -9 -12", 0.8)
    return sc


def scene_veillee():
    """Veillée au village : le grand-père raconte, les enfants écoutent autour du feu."""
    sc = Scene()
    sc.ground()
    sc.moon(206, 22, 8)
    sc.stars([(22, 18), (48, 30), (150, 14), (176, 34), (120, 26)])
    sc.hut(176, 48, 28, 22)
    sc.stool(30)
    sc.person(40, "elder", 66, 1, ("cane", "point"), seated=True, pattern="kente", mouth="open")
    sc.fire(102)
    sc.person(76, "boy", 42, 1, ("down", "chin"), seated=True, pattern="dots")
    sc.person(128, "girl", 42, -1, ("chin", "down"), seated=True, pattern="zigzag")
    sc.person(152, "boy", 44, -1, ("down", "hold"), seated=True, pattern="kente")
    return sc


def scene_mercado():
    """Marché : vendeuse derrière son étal, cliente avec bassine sur la tête."""
    sc = Scene()
    sc.ground()
    sc.stall(86, 80, 26)
    sc.person(128, "vendor", 64, -1, ("point", "down"), pattern="dots")
    sc.person(52, "woman", 66, 1, ("basket", "point"), pattern="zigzag")
    sc.person(22, "girl", 40, 1, ("down", "hold"), pattern="dots")
    sc.palm(214, 0.9)
    sc.sun(190, 18, 6)
    return sc


def scene_aula():
    """Salle de classe : tableau, professeur, élèves."""
    sc = Scene()
    sc.s("M6 132 H234", 1.1)
    sc.blackboard(78, 18, 92, 46, [
        "M{x}+0 0", ])
    sc.items.pop()  # retire la ligne factice
    sc.a("M92 28 v14 M92 35 h8 M100 28 v14 M118 28 v14 M134 32 v10", 0.9)
    sc.circle(109, 37.5, 4.5, "a", 0.9)
    sc.circle(129.5, 37.5, 4.5, "a", 0.9)
    sc.a("M141 28 v9 M141 41 v1 M85 33 v9 M85 28 v1", 0.9)
    sc.a("M90 52 H156", 0.6)
    sc.zigzag(8, 232, 140, 3, 5, "a", 0.8)
    sc.person(62, "teacher", 70, 1, ("point", "book"), pattern="kente", mouth="open")
    # pupitres + élèves
    for i, (xx, kind, pat) in enumerate(((120, "girl", "dots"), (162, "boy", "zigzag"), (204, "girl", "kente"))):
        sc.s(f"M{xx - 14} 112 H{xx + 14} M{xx - 12} 112 V132 M{xx + 12} 112 V132", 1.0)
        sc.person(xx, kind, 44, -1, ("hold", "wave" if i == 1 else "down"), seated=True, pattern=pat)
    sc.clock(212, 24, 8, 8, 0)
    return sc


def scene_maquis():
    """Maquis (restaurant) : serveuse et deux clients à table, ardoise du menu."""
    sc = Scene()
    sc.ground()
    sc.s("M14 40 H96 M18 40 V20 Q55 6 92 20 V40 M22 40 V132 M90 40 V132", 1.0)
    sc.zigzag(20, 90, 26, 2.2, 4, "a", 0.7)
    sc.blackboard(176, 36, 44, 34)
    sc.a("M182 46 h20 M182 52 h28 M182 58 h16 M182 64 h24", 0.7)
    sc.s("M196 70 v62", 0.8)
    sc.round_table(110, 52, 22)
    sc.chair(72, 1)
    sc.chair(148, -1)
    sc.person(78, "man", 50, 1, ("down", "hold"), seated=True, pattern="dots")
    sc.person(142, "woman", 50, -1, ("hold", "down"), seated=True, pattern="zigzag")
    sc.person(30, "vendor", 64, 1, ("down", "hold"), pattern="kente", mouth="open")
    sc.s("M36 92 h12 M42 92 v-4 q-4 -2 0 -5 q4 3 0 5", 0.7)
    return sc


def scene_gare():
    """Gare routière : car / gbaka chargé, voyageuse avec bagage, apprenti."""
    sc = Scene()
    sc.ground()
    sc.bus(116, 100)
    sc.person(44, "woman", 64, 1, ("basket", "down"), pattern="kente")
    sc.person(88, "boy", 58, -1, ("mouth", "point"), pattern="dots", mouth="open")
    sc.s("M12 132 v-16 h18 v16", 0.9)
    sc.a("M12 122 h18", 0.7)
    sc.clock(26, 30, 8, 7, 30)
    sc.s("M26 38 v94", 0.7)
    sc.birds([(180, 24), (196, 18)])
    return sc


def scene_dispensaire():
    """Centre de santé : infirmière, patient, croix sur le mur."""
    sc = Scene()
    sc.ground()
    sc.house(140, 86, 50, door=True, window=False)
    sc.s("M170 98 h18 v-18 h-18 Z", 0.8)
    sc.a("M179 83 v12 M173 89 h12", 1.2)
    sc.person(70, "nurse", 64, 1, ("hold", "point"), pattern="none")
    sc.person(110, "man", 62, -1, ("hip", "chin"), pattern="dots", mouth="sad")
    sc.s("M84 106 h10 v3 h-10 Z", 0.7)
    sc.tree(26, 0.9)
    return sc


def scene_telefono():
    """Conversation au téléphone : deux personnes dans deux cadres reliés par des ondes."""
    sc = Scene()
    sc.s("M10 132 H112 M128 132 H230", 1.1)
    sc.s("M10 20 H112 V132 M128 20 H230 V132", 0.6)
    sc.zigzag(14, 108, 140, 3, 5, "a", 0.8)
    sc.zigzag(132, 226, 140, 3, 5, "a", 0.8)
    sc.person(58, "girl", 70, 1, ("down", "phone"), pattern="dots", mouth="open")
    sc.person(182, "man", 72, -1, ("phone", "down"), pattern="kente")
    for k in range(3):
        sc.a(f"M{78 + k * 6} {58 - k * 2} q4 6 0 12", 0.8)
        sc.a(f"M{162 - k * 6} {58 - k * 2} q-4 6 0 12", 0.8)
    sc.house(86, 22, 16, door=False, window=False)
    sc.palm(214, 0.6)
    return sc


def scene_couture():
    """Atelier de couture : couturier, pagnes suspendus (couleurs, tailles, formes)."""
    sc = Scene()
    sc.ground()
    sc.s("M14 22 H226", 0.9)
    for i, (xx, pat) in enumerate(((22, "dots"), (60, "zig"), (98, "kente"))):
        sc.s(f"M{xx} 22 v34 q14 6 28 0 v-34", 0.9)
        if pat == "dots":
            for r in range(3):
                sc.dots_row(xx + 4, xx + 25, 30 + r * 8, 5, 1.0)
        elif pat == "zig":
            for r in range(3):
                sc.zigzag(xx + 2, xx + 26, 32 + r * 8, 2.5, 4, "a", 0.8)
        else:
            for r in range(5):
                sc.a(f"M{xx + 4 + r * 5} 24 v30", 0.8)
    # machine à coudre sur table
    sc.s("M150 104 H214 M154 104 V132 M210 104 V132", 1.0)
    sc.s("M162 104 v-16 h34 v8 h-6 v8 M164 88 q-2 -8 8 -8 h22 q6 0 6 8", 0.9)
    sc.circle(204, 92, 4, "s", 0.8)
    sc.person(186, "man", 56, -1, ("hold", "hold"), seated=True, pattern="kente")
    sc.person(84, "woman", 66, 1, ("down", "point"), pattern="zigzag")
    sc.person(124, "girl", 48, -1, ("hold", "down"), pattern="dots")
    return sc


def scene_fete():
    """Fête et chansons : joueur de djembé, danseuses, guirlande."""
    sc = Scene()
    sc.ground()
    sc.s("M10 18 Q120 44 230 18", 0.8)
    for k in range(10):
        x = 22 + k * 21
        y = 18 + 26 * math.sin(math.pi * (x - 10) / 220) * .95
        sc.f(f"M{f2(x - 4)} {f2(y)} h8 l-4 8 Z")
    # djembé
    sc.s("M44 132 l-4 -18 h22 l-4 18 Z M40 114 q11 -6 22 0", 1.0)
    sc.zigzag(42, 60, 124, 2, 3, "a", 0.7)
    sc.person(36, "man", 56, 1, ("hold", "hold"), seated=True, pattern="kente", mouth="open")
    sc.person(104, "woman", 64, 1, ("wave", "wave"), pattern="dots", mouth="open")
    sc.person(140, "girl", 52, -1, ("wave", "hip"), pattern="zigzag", mouth="open")
    sc.person(180, "woman", 66, -1, ("hip", "wave"), pattern="kente", mouth="open")
    sc.a("M120 70 q4 -6 8 0 v-12 M210 60 q4 -6 8 0 v-12", 0.9)
    sc.circle(120, 70, 2, "f")
    sc.circle(210, 60, 2, "f")
    return sc


def scene_bureau():
    """Bureau / entretien : deux personnes autour d'un bureau, dossier, ordinateur."""
    sc = Scene()
    sc.s("M6 132 H234", 1.1)
    sc.zigzag(8, 232, 140, 3, 5, "a", 0.8)
    sc.s("M60 100 H180 M66 100 V132 M174 100 V132 M66 112 h30 v20", 1.0)
    sc.s("M110 100 v-4 h20 v4 M106 96 l4 -26 h24 l4 26", 0.9)  # écran
    sc.a("M116 76 h12 M116 82 h8", 0.7)
    sc.s("M146 98 l14 -2 l2 4", 0.8)  # dossier
    sc.person(46, "woman", 56, 1, ("hold", "point"), seated=True, pattern="kente", mouth="open")
    sc.chair(52, 1)
    sc.person(196, "man", 58, -1, ("hold", "chin"), seated=True, pattern="dots")
    sc.chair(190, -1)
    sc.line([(150, 18), (226, 18), (226, 56), (150, 56)], "s", 0.8, close=True)
    sc.a("M156 48 L170 36 L182 42 L196 28 L210 34 L220 24", 0.9)  # graphique au mur
    sc.clock(28, 28, 8, 10, 10)
    return sc


def scene_place():
    """Place du quartier avec horloge : rendez-vous, heure, dates."""
    sc = Scene()
    sc.ground()
    sc.s("M108 132 V44 h24 V132 M104 44 h32 l-16 -16 Z", 1.0)
    sc.clock(120, 60, 9, 4, 15)
    sc.zigzag(110, 130, 80, 2, 4, "a", 0.6)
    sc.dots_row(112, 128, 92, 4, 0.8)
    sc.person(70, "girl", 60, 1, ("down", "point"), pattern="dots", mouth="open")
    sc.person(170, "boy", 60, -1, ("phone", "down"), pattern="zigzag")
    sc.tree(26, 0.85)
    sc.palm(214, 0.85)
    sc.s("M140 132 h20 v-10 h-20 Z M144 122 v-4 h12 v4", 0.7)  # banc
    return sc


SCENES = {
    "patio": scene_patio,
    "familia": scene_familia,
    "campo": scene_campo,
    "selva": scene_selva,
    "veillee": scene_veillee,
    "mercado": scene_mercado,
    "aula": scene_aula,
    "maquis": scene_maquis,
    "gare": scene_gare,
    "dispensaire": scene_dispensaire,
    "telefono": scene_telefono,
    "couture": scene_couture,
    "fete": scene_fete,
    "bureau": scene_bureau,
    "place": scene_place,
}


def to_svg(sc, ink="#1E140B", accent="#C2410C"):
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W * 4}" height="{H * 4}">',
           f'<rect width="{W}" height="{H}" fill="#FFF8EF"/>']
    for d, w, kind in sc.items:
        if kind == "f":
            out.append(f'<path d="{d}" fill="{accent}"/>')
        else:
            col = accent if kind == "a" else ink
            out.append(f'<path d="{d}" fill="none" stroke="{col}" stroke-width="{1.15 * w}" stroke-linecap="round" stroke-linejoin="round"/>')
    out.append("</svg>")
    return "\n".join(out)


def to_kotlin(scenes):
    lines = [
        "package com.linguavibe.app.ui",
        "",
        "// Fichier généré par tools/scenes.py : scènes lineart « style africain » des dialogues",
        "// (cour d'école, famille à table, village, forêt, veillée, marché, classe, maquis, gare…).",
        "// Cadre 240 × 150. Ne pas modifier à la main : relancer le script.",
        "",
        "private fun s(d: String, w: Float = 1f) = LineStroke(d, w)",
        "private fun a(d: String, w: Float = 1f) = LineStroke(d, w, accent = true)",
        "private fun f(d: String) = LineStroke(d, accent = true, fill = true)",
        "",
        "object Scenes {",
    ]
    for name, sc in scenes.items():
        lines.append(f"    val {name} by lazy {{")
        lines.append(f"        LineDrawing({W}f, {H}f, listOf(")
        for d, w, kind in sc.items:
            wtxt = "" if abs(w - 1) < 1e-6 or kind == "f" else f", {f2(w)}f"
            lines.append(f'            {kind}("{d}"{wtxt}),')
        lines.append("        ))")
        lines.append("    }")
        lines.append("")
    lines.append("    /** Scène par identifiant (champ « scene » des dialogues dans les JSON). */")
    lines.append("    fun byId(id: String?): LineDrawing? = when (id) {")
    for name in scenes:
        lines.append(f'        "{name}" -> {name}')
    lines.append("        else -> null")
    lines.append("    }")
    lines.append("")
    lines.append("    val ids: List<String> = listOf(" + ", ".join(f'"{n}"' for n in scenes) + ")")
    lines.append("}")
    return "\n".join(lines) + "\n"


if __name__ == "__main__":
    outdir = sys.argv[1] if len(sys.argv) > 1 else "previews"
    kt = sys.argv[2] if len(sys.argv) > 2 else None
    os.makedirs(outdir, exist_ok=True)
    built = {n: fn() for n, fn in SCENES.items()}
    for n, sc in built.items():
        p = os.path.join(outdir, n + ".svg")
        open(p, "w").write(to_svg(sc))
        subprocess.run(["rsvg-convert", p, "-o", p[:-4] + ".png"], check=True)
        print(n, len(sc.items), "traits")
    if kt:
        open(kt, "w").write(to_kotlin(built))
