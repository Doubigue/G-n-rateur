#!/usr/bin/env python3
"""Illustrations en couleur (aplats, style manuel scolaire ivoirien) pour les dialogues des MODEL 2 et 3.

Chaque scène est un SVG 960 × 600 rendu en WebP dans app/src/main/assets/scenes/<id>.webp.
Usage : python3 tools/flat_scenes.py [dossier_previews]
Nécessite rsvg-convert et Pillow.
"""
import io
import math
import os
import random
import subprocess
import sys
from pathlib import Path

from PIL import Image

W, H = 960, 600
GY = 500  # ligne du sol

SKINS = ["#6B3E26", "#8D5524", "#5A3420", "#7A4A2E", "#4E2C1C", "#A0643C"]
INK = "#2B160C"

# ---------------------------------------------------------------- motifs (wax, kente, bogolan)
PATTERNS = """
<pattern id="waxA" width="28" height="28" patternUnits="userSpaceOnUse">
  <rect width="28" height="28" fill="#E8590C"/>
  <circle cx="14" cy="14" r="8" fill="#FFC72C"/><circle cx="14" cy="14" r="4" fill="#1E5B3A"/>
  <circle cx="0" cy="0" r="4" fill="#7A1A0E"/><circle cx="28" cy="0" r="4" fill="#7A1A0E"/>
  <circle cx="0" cy="28" r="4" fill="#7A1A0E"/><circle cx="28" cy="28" r="4" fill="#7A1A0E"/>
</pattern>
<pattern id="waxB" width="30" height="30" patternUnits="userSpaceOnUse">
  <rect width="30" height="30" fill="#1D4E89"/>
  <path d="M0 15 Q7.5 3 15 15 T30 15" fill="none" stroke="#FFD166" stroke-width="4"/>
  <circle cx="15" cy="26" r="3" fill="#F25C54"/><circle cx="0" cy="4" r="3" fill="#F25C54"/><circle cx="30" cy="4" r="3" fill="#F25C54"/>
</pattern>
<pattern id="waxC" width="26" height="26" patternUnits="userSpaceOnUse">
  <rect width="26" height="26" fill="#2A9D8F"/>
  <path d="M13 2 L24 13 L13 24 L2 13 Z" fill="#F4A261"/><circle cx="13" cy="13" r="3.5" fill="#264653"/>
</pattern>
<pattern id="waxD" width="24" height="24" patternUnits="userSpaceOnUse">
  <rect width="24" height="24" fill="#8E2C48"/>
  <circle cx="6" cy="6" r="4" fill="#F7C548"/><circle cx="18" cy="18" r="4" fill="#F7C548"/>
  <circle cx="18" cy="6" r="2" fill="#FFF3E0"/><circle cx="6" cy="18" r="2" fill="#FFF3E0"/>
</pattern>
<pattern id="kente" width="36" height="36" patternUnits="userSpaceOnUse">
  <rect width="36" height="36" fill="#F2B705"/>
  <rect x="0" y="0" width="12" height="36" fill="#1B7F3A"/><rect x="24" y="0" width="6" height="36" fill="#B3261E"/>
  <rect x="0" y="14" width="36" height="8" fill="#111" opacity=".85"/><rect x="0" y="16" width="36" height="2" fill="#F2B705"/>
</pattern>
<pattern id="bogolan" width="30" height="30" patternUnits="userSpaceOnUse">
  <rect width="30" height="30" fill="#5B3A1E"/>
  <path d="M0 8 l5 -5 l5 5 l5 -5 l5 5 l5 -5 l5 5" fill="none" stroke="#EAD7B7" stroke-width="2.5"/>
  <circle cx="7" cy="20" r="2.2" fill="#EAD7B7"/><circle cx="15" cy="20" r="2.2" fill="#EAD7B7"/><circle cx="23" cy="20" r="2.2" fill="#EAD7B7"/>
</pattern>
<pattern id="stripesW" width="20" height="20" patternUnits="userSpaceOnUse">
  <rect width="20" height="20" fill="#F7F3EA"/><rect width="20" height="4" fill="#D9CBB0"/>
</pattern>
<pattern id="thatch" width="16" height="12" patternUnits="userSpaceOnUse">
  <rect width="16" height="12" fill="#C99A4B"/>
  <path d="M0 12 L4 0 M6 12 L10 0 M12 12 L16 0" stroke="#A8762F" stroke-width="2"/>
</pattern>
<pattern id="tiles" width="40" height="40" patternUnits="userSpaceOnUse">
  <rect width="40" height="40" fill="#E9D8BD"/><rect width="20" height="20" fill="#DDC7A5"/><rect x="20" y="20" width="20" height="20" fill="#DDC7A5"/>
</pattern>
<linearGradient id="skyDay" x1="0" y1="0" x2="0" y2="1">
  <stop offset="0" stop-color="#7EC8E3"/><stop offset="1" stop-color="#FCE9C7"/>
</linearGradient>
<linearGradient id="skyWarm" x1="0" y1="0" x2="0" y2="1">
  <stop offset="0" stop-color="#F6A04D"/><stop offset=".65" stop-color="#FFD58A"/><stop offset="1" stop-color="#FFF1D6"/>
</linearGradient>
<linearGradient id="skyNight" x1="0" y1="0" x2="0" y2="1">
  <stop offset="0" stop-color="#0F1B3D"/><stop offset=".7" stop-color="#2E2A5A"/><stop offset="1" stop-color="#5B3A55"/>
</linearGradient>
<linearGradient id="forest" x1="0" y1="0" x2="0" y2="1">
  <stop offset="0" stop-color="#2F6B3B"/><stop offset="1" stop-color="#A7C957"/>
</linearGradient>
<linearGradient id="wallIn" x1="0" y1="0" x2="0" y2="1">
  <stop offset="0" stop-color="#F3C9A8"/><stop offset="1" stop-color="#E9B48A"/>
</linearGradient>
<linearGradient id="earth" x1="0" y1="0" x2="0" y2="1">
  <stop offset="0" stop-color="#D98E4F"/><stop offset="1" stop-color="#B8693A"/>
</linearGradient>
<radialGradient id="fireGlow" cx=".5" cy=".5" r=".5">
  <stop offset="0" stop-color="#FFB347" stop-opacity=".75"/><stop offset="1" stop-color="#FFB347" stop-opacity="0"/>
</radialGradient>
"""


def shade(hexc, k):
    """Assombrit (k < 0) ou éclaircit (k > 0) une couleur."""
    hexc = hexc.lstrip("#")
    r, g, b = (int(hexc[i:i + 2], 16) for i in (0, 2, 4))
    if k < 0:
        r, g, b = (int(c * (1 + k)) for c in (r, g, b))
    else:
        r, g, b = (int(c + (255 - c) * k) for c in (r, g, b))
    return f"#{r:02X}{g:02X}{b:02X}"


class S:
    def __init__(self, sky="skyDay"):
        self.parts = []
        self.sky = sky

    def add(self, s):
        self.parts.append(s)

    def svg(self):
        return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}">'
                f"<defs>{PATTERNS}</defs>" + "".join(self.parts) + "</svg>")

    # ---------------------------------------------------------------- fonds
    def sky_bg(self, kind=None):
        self.add(f'<rect width="{W}" height="{H}" fill="url(#{kind or self.sky})"/>')

    def ground(self, color="#D9A05B", top=GY, grass=True):
        self.add(f'<path d="M0 {top} Q240 {top - 14} 480 {top - 4} T960 {top - 8} V600 H0 Z" fill="{color}"/>')
        self.add(f'<path d="M0 {top + 40} Q300 {top + 26} 560 {top + 42} T960 {top + 36} V600 H0 Z" fill="{shade(color, -0.12)}"/>')
        if grass:
            rnd = random.Random(top)
            for _ in range(46):
                x = rnd.uniform(0, W)
                y = top + rnd.uniform(-6, 70)
                self.add(f'<path d="M{x:.0f} {y:.0f} l-4 -12 M{x:.0f} {y:.0f} l2 -15 M{x:.0f} {y:.0f} l7 -10" '
                         f'stroke="{shade("#6A994E", rnd.uniform(-0.2, 0.15))}" stroke-width="2.4" stroke-linecap="round"/>')

    def floor_in(self, top=GY - 20):
        self.add(f'<rect y="{top}" width="{W}" height="{H - top}" fill="url(#tiles)"/>')
        self.add(f'<rect y="{top}" width="{W}" height="8" fill="#C9A27A"/>')

    def wall_in(self, color="url(#wallIn)"):
        self.add(f'<rect width="{W}" height="{H}" fill="{color}"/>')

    def hills(self, color="#9BBF6A", y=380):
        self.add(f'<path d="M0 {y} Q160 {y - 70} 330 {y - 20} T640 {y - 40} T960 {y - 10} V{GY} H0 Z" fill="{color}" opacity=".85"/>')
        self.add(f'<path d="M0 {y + 40} Q200 {y - 10} 420 {y + 30} T960 {y + 20} V{GY} H0 Z" fill="{shade(color, -0.12)}"/>')

    def sun(self, x, y, r=46, color="#FFD23F"):
        self.add(f'<circle cx="{x}" cy="{y}" r="{r + 26}" fill="{color}" opacity=".18"/>')
        self.add(f'<circle cx="{x}" cy="{y}" r="{r}" fill="{color}"/>')

    def moon(self, x, y, r=34):
        self.add(f'<circle cx="{x}" cy="{y}" r="{r}" fill="#FFF4C8"/><circle cx="{x + 14}" cy="{y - 8}" r="{r}" fill="#1A2448"/>')

    def stars(self, n=30, seed=4):
        rnd = random.Random(seed)
        for _ in range(n):
            x, y, r = rnd.uniform(0, W), rnd.uniform(0, 260), rnd.uniform(1.2, 2.8)
            self.add(f'<circle cx="{x:.0f}" cy="{y:.0f}" r="{r:.1f}" fill="#FFF8DC" opacity="{rnd.uniform(.5, 1):.2f}"/>')

    def cloud(self, x, y, s=1.0):
        self.add(f'<g transform="translate({x} {y}) scale({s})" fill="#FFFFFF" opacity=".9">'
                 '<ellipse cx="0" cy="0" rx="60" ry="22"/><ellipse cx="-30" cy="-12" rx="30" ry="22"/>'
                 '<ellipse cx="18" cy="-20" rx="34" ry="28"/><ellipse cx="50" cy="-4" rx="26" ry="18"/></g>')

    def birds(self, pts):
        for x, y in pts:
            self.add(f'<path d="M{x - 12} {y} q6 -8 12 0 q6 -8 12 0" fill="none" stroke="#3A2A1A" stroke-width="2.5" stroke-linecap="round"/>')

    # ---------------------------------------------------------------- décor
    def palm(self, x, h=260, s=1.0):
        y0 = GY + 6
        tx, ty = x + 26 * s, y0 - h * s
        self.add(f'<path d="M{x - 9 * s} {y0} Q{x - 14 * s} {y0 - h * .5 * s} {tx - 6 * s} {ty} L{tx + 6 * s} {ty} '
                 f'Q{x} {y0 - h * .5 * s} {x + 9 * s} {y0} Z" fill="#8B5A2B"/>')
        for k in range(8):
            yy = y0 - (k + 1) * h * s / 9
            self.add(f'<path d="M{x - 8 * s + k * 2.6 * s} {yy:.0f} q10 -4 18 0" stroke="#6B4220" stroke-width="3" fill="none"/>')
        for ang, ln, col in ((-170, 130, "#2E7D32"), (-140, 120, "#388E3C"), (-105, 100, "#43A047"), (-75, 105, "#2E7D32"),
                             (-40, 125, "#388E3C"), (-10, 125, "#43A047"), (20, 95, "#2E7D32"), (200, 90, "#388E3C")):
            t = math.radians(ang)
            ex, ey = tx + math.cos(t) * ln * s, ty + math.sin(t) * ln * s
            mx, my = tx + math.cos(t) * ln * .55 * s, ty + math.sin(t) * ln * .55 * s - 28 * s
            nx, ny = -math.sin(t) * 16 * s, math.cos(t) * 16 * s
            self.add(f'<path d="M{tx} {ty} Q{mx + nx:.0f} {my + ny:.0f} {ex:.0f} {ey:.0f} Q{mx - nx * .2:.0f} {my - ny * .2:.0f} {tx} {ty} Z" fill="{col}"/>')
        for dx in (-8, 6, 0):
            self.add(f'<circle cx="{tx + dx * s}" cy="{ty + 12 * s}" r="{8 * s}" fill="#6D4C1F"/>')

    def baobab(self, x, s=1.0):
        y0 = GY + 8
        self.add(f'<path d="M{x - 55 * s} {y0} C{x - 40 * s} {y0 - 120 * s} {x - 60 * s} {y0 - 200 * s} {x - 34 * s} {y0 - 250 * s} '
                 f'L{x + 34 * s} {y0 - 250 * s} C{x + 60 * s} {y0 - 200 * s} {x + 40 * s} {y0 - 120 * s} {x + 55 * s} {y0} Z" fill="#9C7A5B"/>')
        self.add(f'<path d="M{x + 10 * s} {y0} C{x + 30 * s} {y0 - 120 * s} {x + 10 * s} {y0 - 200 * s} {x + 34 * s} {y0 - 250 * s} '
                 f'L{x + 34 * s} {y0 - 250 * s} C{x + 60 * s} {y0 - 200 * s} {x + 40 * s} {y0 - 120 * s} {x + 55 * s} {y0} Z" fill="#7E5E43"/>')
        for bx, by, ex, ey in ((-30, -240, -110, -300), (-10, -248, -40, -330), (12, -248, 50, -332), (30, -240, 120, -296)):
            self.add(f'<path d="M{x + bx * s} {y0 + by * s} Q{x + (bx + ex) / 2 * s} {y0 + (by + ey) / 2 * s - 20 * s} {x + ex * s} {y0 + ey * s}" '
                     f'stroke="#8C6B4E" stroke-width="{16 * s}" stroke-linecap="round" fill="none"/>')
            self.add(f'<ellipse cx="{x + ex * s}" cy="{y0 + ey * s - 10 * s}" rx="{42 * s}" ry="{22 * s}" fill="#5C8A3A"/>')
            self.add(f'<ellipse cx="{x + ex * s + 10 * s}" cy="{y0 + ey * s - 20 * s}" rx="{26 * s}" ry="{14 * s}" fill="#78A84B"/>')

    def tree(self, x, s=1.0, col="#4F8A3C"):
        y0 = GY + 6
        self.add(f'<path d="M{x - 12 * s} {y0} L{x - 8 * s} {y0 - 130 * s} L{x + 8 * s} {y0 - 130 * s} L{x + 12 * s} {y0} Z" fill="#7A5230"/>')
        for dx, dy, r, c in ((-50, -150, 62, col), (40, -160, 66, col), (-5, -205, 74, shade(col, .12)), (-10, -150, 60, shade(col, -.1))):
            self.add(f'<circle cx="{x + dx * s}" cy="{y0 + dy * s}" r="{r * s}" fill="{c}"/>')
        rnd = random.Random(int(x))
        for _ in range(7):
            self.add(f'<circle cx="{x + rnd.uniform(-80, 80) * s:.0f}" cy="{y0 - rnd.uniform(140, 240) * s:.0f}" r="{6 * s:.0f}" fill="#F4A259"/>')

    def bush(self, x, w=160, col="#5E9C45", flowers="#E63946"):
        y0 = GY + 10
        n = int(w // 40) + 1
        for i in range(n):
            cx = x + i * w / n + 20
            self.add(f'<circle cx="{cx:.0f}" cy="{y0 - 22}" r="30" fill="{shade(col, (i % 2) * 0.1)}"/>')
        rnd = random.Random(int(x) + 7)
        for _ in range(int(w / 14)):
            self.add(f'<circle cx="{x + rnd.uniform(5, w):.0f}" cy="{y0 - rnd.uniform(15, 48):.0f}" r="5" fill="{flowers}"/>'
                     f'<circle cx="{x + rnd.uniform(5, w):.0f}" cy="{y0 - rnd.uniform(15, 48):.0f}" r="3" fill="#FFE066"/>')

    def hut(self, x, w=190, h=110, roof=110, wall="#C8834B"):
        y0 = GY + 4
        self.add(f'<rect x="{x}" y="{y0 - h}" width="{w}" height="{h}" fill="{wall}"/>')
        self.add(f'<rect x="{x + w * .55}" y="{y0 - h}" width="{w * .45}" height="{h}" fill="{shade(wall, -.12)}"/>')
        self.add(f'<rect x="{x}" y="{y0 - h + 28}" width="{w}" height="18" fill="url(#bogolan)"/>')
        self.add(f'<path d="M{x + w * .38} {y0} V{y0 - 62} Q{x + w * .38 + 24} {y0 - 82} {x + w * .38 + 48} {y0 - 62} V{y0} Z" fill="#4A2A15"/>')
        self.add(f'<path d="M{x - 30} {y0 - h + 6} L{x + w / 2} {y0 - h - roof} L{x + w + 30} {y0 - h + 6} Q{x + w / 2} {y0 - h + 26} {x - 30} {y0 - h + 6} Z" fill="url(#thatch)"/>')
        self.add(f'<path d="M{x + w / 2} {y0 - h - roof} L{x + w + 30} {y0 - h + 6} Q{x + w * .75} {y0 - h + 22} {x + w / 2} {y0 - h + 22} Z" fill="#000" opacity=".12"/>')

    def house(self, x, w=300, h=170, wall="#F2E3C6", roof="#B5473A", door=True, windows=2, sign=None):
        y0 = GY + 4
        self.add(f'<rect x="{x}" y="{y0 - h}" width="{w}" height="{h}" fill="{wall}"/>')
        self.add(f'<rect x="{x}" y="{y0 - 26}" width="{w}" height="26" fill="{shade(wall, -.15)}"/>')
        self.add(f'<path d="M{x - 20} {y0 - h + 4} L{x + 14} {y0 - h - 46} H{x + w - 14} L{x + w + 20} {y0 - h + 4} Z" fill="{roof}"/>')
        for k in range(1, 12):
            xx = x + 14 + (w - 28) * k / 12
            self.add(f'<path d="M{xx:.0f} {y0 - h - 44} L{xx + (xx - x - w / 2) * .1:.0f} {y0 - h + 2}" stroke="{shade(roof, -.2)}" stroke-width="3"/>')
        if door:
            dx = x + w * .62
            self.add(f'<rect x="{dx}" y="{y0 - 104}" width="54" height="104" fill="#2F6690"/><circle cx="{dx + 44}" cy="{y0 - 52}" r="4" fill="#FFD166"/>')
        for i in range(windows):
            wx = x + 26 + i * 92
            self.add(f'<rect x="{wx}" y="{y0 - h + 34}" width="62" height="54" fill="#8ECAE6"/>'
                     f'<path d="M{wx + 31} {y0 - h + 34} v54 M{wx} {y0 - h + 61} h62" stroke="{shade(wall, -.35)}" stroke-width="4"/>'
                     f'<rect x="{wx - 6}" y="{y0 - h + 86}" width="74" height="8" fill="{shade(wall, -.25)}"/>')
        if sign:
            self.add(f'<rect x="{x + w * .2}" y="{y0 - h - 30}" width="{w * .6}" height="34" rx="6" fill="#FFFFFF" stroke="{roof}" stroke-width="4"/>'
                     f'<text x="{x + w / 2}" y="{y0 - h - 6}" font-family="DejaVu Sans" font-weight="bold" font-size="{min(20, w * .6 / (len(sign) * .66)):.0f}" text-anchor="middle" fill="{roof}">{sign}</text>')

    def flag_ci(self, x, h=300):
        y0 = GY + 6
        self.add(f'<rect x="{x - 4}" y="{y0 - h}" width="8" height="{h}" fill="#8D8D8D"/><circle cx="{x}" cy="{y0 - h - 6}" r="9" fill="#D4AF37"/>')
        fy = y0 - h + 8
        for i, c in enumerate(("#F77F00", "#FFFFFF", "#009E60")):
            self.add(f'<path d="M{x + 4 + i * 40} {fy + (6 if i == 1 else 0)} q20 -10 40 0 v86 q-20 -10 -40 0 Z" fill="{c}"/>')
        self.add(f'<path d="M{x + 4} {fy} q60 -14 120 0 v86 q-60 -14 -120 0 Z" fill="none" stroke="#00000022" stroke-width="2"/>')

    def round_table(self, cx, y, w=300, cloth="url(#waxC)", food=True):
        self.add(f'<ellipse cx="{cx}" cy="{y + 58}" rx="{w * .38}" ry="14" fill="#000" opacity=".12"/>')
        self.add(f'<path d="M{cx - w / 2} {y} Q{cx} {y + 28} {cx + w / 2} {y} L{cx + w / 2 - 8} {y + 54} Q{cx} {y + 74} {cx - w / 2 + 8} {y + 54} Z" fill="{cloth}"/>')
        self.add(f'<ellipse cx="{cx}" cy="{y}" rx="{w / 2}" ry="26" fill="#FFF7EC"/>')
        self.add(f'<rect x="{cx - 70}" y="{y + 60}" width="12" height="{GY - y - 40}" fill="#6B4220"/><rect x="{cx + 58}" y="{y + 60}" width="12" height="{GY - y - 40}" fill="#6B4220"/>')
        if food:
            self.add(f'<ellipse cx="{cx}" cy="{y - 4}" rx="54" ry="16" fill="#E9ECEF"/><path d="M{cx - 40} {y - 8} Q{cx} {y - 46} {cx + 40} {y - 8} Z" fill="#F6E7B0"/>')
            self.add(f'<path d="M{cx - 28} {y - 14} q14 -10 28 0 q14 -10 28 0" stroke="#E07A1F" stroke-width="5" fill="none"/>')
            for dx in (-110, 100):
                self.add(f'<ellipse cx="{cx + dx}" cy="{y}" rx="26" ry="9" fill="#FFFFFF"/><rect x="{cx + dx - 6}" y="{y - 30}" width="14" height="26" rx="3" fill="#90E0EF" opacity=".85"/>')
            for k in range(3):
                self.add(f'<path d="M{cx - 16 + k * 16} {y - 54} q-8 -12 0 -24 q8 -12 0 -24" stroke="#FFFFFF" stroke-width="3" fill="none" opacity=".7"/>')

    def stall(self, x, w=330):
        y = GY - 70
        self.add(f'<rect x="{x}" y="{y}" width="{w}" height="18" fill="#8B5A2B"/><rect x="{x + 12}" y="{y + 18}" width="12" height="{GY - y - 14}" fill="#6B4220"/>'
                 f'<rect x="{x + w - 24}" y="{y + 18}" width="12" height="{GY - y - 14}" fill="#6B4220"/><rect x="{x}" y="{y + 18}" width="{w}" height="40" fill="url(#waxB)" opacity=".95"/>')
        rnd = random.Random(x)
        for i, (cx, col) in enumerate(((x + 60, "#E63946"), (x + 150, "#F77F00"), (x + 238, "#80B918"))):
            for row in range(3):
                for j in range(4 - row):
                    px = cx - 30 + j * 20 + row * 10
                    py = y - 10 - row * 17
                    self.add(f'<circle cx="{px}" cy="{py}" r="11" fill="{shade(col, rnd.uniform(-.1, .1))}"/>'
                             f'<circle cx="{px - 3}" cy="{py - 3}" r="3" fill="#FFFFFF" opacity=".5"/>')
        bx = x + w - 60
        self.add(f'<path d="M{bx - 30} {y} l8 -46 h44 l8 46 Z" fill="#C8963E"/><path d="M{bx - 26} {y - 16} h52 M{bx - 24} {y - 32} h48" stroke="#9C6B23" stroke-width="4"/>')
        # parasol
        px = x + w * .45
        self.add(f'<rect x="{px - 4}" y="{y - 230}" width="8" height="230" fill="#555"/>')
        self.add(f'<path d="M{px - 200} {y - 170} Q{px} {y - 320} {px + 200} {y - 170} Z" fill="#E63946"/>')
        for k in range(5):
            a = px - 200 + k * 100
            self.add(f'<path d="M{px} {y - 245} L{a} {y - 170} L{a + 50} {y - 170} Z" fill="#FFFFFF" opacity="{.85 if k % 2 == 0 else 0}"/>')
        self.add(f'<path d="M{px - 200} {y - 170} ' + " ".join("q20 16 40 0" for _ in range(10)) + '" fill="#C1121F"/>')

    def blackboard(self, x, y, w=330, h=170, text="¡Hola!"):
        self.add(f'<rect x="{x - 12}" y="{y - 12}" width="{w + 24}" height="{h + 24}" rx="6" fill="#8B5A2B"/>'
                 f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="#1F4E3D"/>'
                 f'<text x="{x + w / 2}" y="{y + h / 2 + 18}" font-family="DejaVu Sans" font-size="58" font-weight="bold" text-anchor="middle" fill="#F8F9FA" opacity=".92">{text}</text>'
                 f'<path d="M{x + 40} {y + h - 34} h{w - 80}" stroke="#F8F9FA" stroke-width="3" opacity=".6"/>'
                 f'<rect x="{x + 20}" y="{y + h + 12}" width="40" height="8" fill="#F8F9FA"/>')

    def desk(self, x, w=130, y=GY - 60):
        self.add(f'<rect x="{x}" y="{y}" width="{w}" height="16" fill="#A0673A"/><rect x="{x + 10}" y="{y + 16}" width="10" height="{GY - y + 4}" fill="#7A4A26"/>'
                 f'<rect x="{x + w - 20}" y="{y + 16}" width="10" height="{GY - y + 4}" fill="#7A4A26"/><rect x="{x + 6}" y="{y + 16}" width="{w - 12}" height="26" fill="#8A5530"/>')

    def bus(self, x, w=400):
        y0 = GY - 4
        h = 150
        self.add(f'<ellipse cx="{x + w / 2}" cy="{y0 + 6}" rx="{w / 2}" ry="10" fill="#000" opacity=".15"/>')
        self.add(f'<path d="M{x} {y0 - 20} V{y0 - h + 20} Q{x} {y0 - h} {x + 22} {y0 - h} H{x + w - 50} Q{x + w - 14} {y0 - h} {x + w - 6} {y0 - h + 50} L{x + w} {y0 - 20} Z" fill="#F2C14E"/>')
        self.add(f'<rect x="{x}" y="{y0 - 60}" width="{w}" height="40" fill="#2A9D8F"/><rect x="{x}" y="{y0 - 66}" width="{w}" height="6" fill="#E76F51"/>')
        for i in range(5):
            wx = x + 18 + i * 66
            self.add(f'<rect x="{wx}" y="{y0 - h + 24}" width="54" height="50" rx="6" fill="#A9D6E5"/><path d="M{wx + 6} {y0 - h + 30} l16 0 l-16 20 Z" fill="#FFFFFF" opacity=".5"/>')
        self.add(f'<path d="M{x + w - 50} {y0 - h + 24} h26 q10 0 14 20 l4 30 h-44 Z" fill="#A9D6E5"/>')
        for wx in (x + 80, x + w - 90):
            self.add(f'<circle cx="{wx}" cy="{y0 - 14}" r="30" fill="#2B2B2B"/><circle cx="{wx}" cy="{y0 - 14}" r="13" fill="#BDBDBD"/>')
        self.add(f'<rect x="{x + 40}" y="{y0 - h - 34}" width="120" height="34" rx="4" fill="url(#waxD)"/><rect x="{x + 170}" y="{y0 - h - 26}" width="80" height="26" rx="4" fill="#8D6E63"/>'
                 f'<rect x="{x + 260}" y="{y0 - h - 30}" width="60" height="30" rx="4" fill="url(#waxA)"/>')
        self.add(f'<text x="{x + w / 2 - 20}" y="{y0 - 34}" font-family="DejaVu Sans" font-weight="bold" font-size="22" text-anchor="middle" fill="#FFFFFF">PORT-LUMÉ</text>')

    def clock_post(self, x, h=230, hh=4, mm=15):
        y0 = GY + 6
        self.add(f'<rect x="{x - 5}" y="{y0 - h}" width="10" height="{h}" fill="#3D405B"/>')
        cy = y0 - h - 26
        self.add(f'<circle cx="{x}" cy="{cy}" r="34" fill="#3D405B"/><circle cx="{x}" cy="{cy}" r="27" fill="#FFFFFF"/>')
        th = (hh % 12 + mm / 60) * math.pi / 6
        tm = mm * math.pi / 30
        self.add(f'<path d="M{x} {cy} L{x + math.sin(th) * 14:.1f} {cy - math.cos(th) * 14:.1f}" stroke="#222" stroke-width="5" stroke-linecap="round"/>'
                 f'<path d="M{x} {cy} L{x + math.sin(tm) * 21:.1f} {cy - math.cos(tm) * 21:.1f}" stroke="#E63946" stroke-width="3" stroke-linecap="round"/>')

    def fire(self, x, y=GY + 6):
        self.add(f'<circle cx="{x}" cy="{y - 40}" r="160" fill="url(#fireGlow)"/>')
        self.add(f'<path d="M{x - 60} {y} L{x + 50} {y - 22} M{x - 50} {y - 22} L{x + 60} {y}" stroke="#5D3A1A" stroke-width="12" stroke-linecap="round"/>')
        self.add(f'<path d="M{x - 34} {y - 12} Q{x - 50} {y - 70} {x - 6} {y - 120} Q{x - 4} {y - 80} {x + 16} {y - 70} Q{x + 22} {y - 96} {x + 8} {y - 118} '
                 f'Q{x + 60} {y - 70} {x + 34} {y - 12} Z" fill="#F77F00"/>')
        self.add(f'<path d="M{x - 18} {y - 12} Q{x - 26} {y - 50} {x} {y - 78} Q{x + 28} {y - 46} {x + 18} {y - 12} Z" fill="#FFD23F"/>')
        rnd = random.Random(3)
        for _ in range(10):
            self.add(f'<circle cx="{x + rnd.uniform(-50, 50):.0f}" cy="{y - rnd.uniform(130, 220):.0f}" r="{rnd.uniform(2, 4):.1f}" fill="#FFB703"/>')

    def stool(self, x, w=70, y=GY + 4, h=44):
        self.add(f'<path d="M{x} {y - h} h{w} l-10 14 h-{w - 20} Z" fill="#7F4F24"/><path d="M{x + 14} {y - h + 14} l-6 {h - 14} M{x + w - 14} {y - h + 14} l6 {h - 14} M{x + w / 2} {y - h + 14} v{h - 14}" stroke="#6B3F1D" stroke-width="9"/>')

    def chair(self, x, facing=1, y=GY + 4):
        b = x - 30 * facing
        self.add(f'<path d="M{b} {y} V{y - 140}" stroke="#7A4A26" stroke-width="10"/>'
                 f'<path d="M{b} {y - 70} H{b + 70 * facing}" stroke="#8A5530" stroke-width="14"/>'
                 f'<path d="M{b + 66 * facing} {y - 70} V{y}" stroke="#7A4A26" stroke-width="10"/>')

    def bubble(self, x, y, text, w=None, tail=1):
        w = w or 24 + 15 * len(text)
        bx = x + w / 2 - 18 * tail
        self.add(f'<g><rect x="{x}" y="{y}" width="{w}" height="58" rx="26" fill="#FFFFFF" stroke="#2B160C" stroke-width="3"/>'
                 f'<path d="M{bx - 12} {y + 56} L{bx + tail * 26} {y + 88} L{bx + 12} {y + 56}" fill="#FFFFFF" stroke="#2B160C" stroke-width="3" stroke-linejoin="round"/>'
                 f'<path d="M{bx - 10} {y + 56.5} H{bx + 10}" stroke="#FFFFFF" stroke-width="5"/>'
                 f'<text x="{x + w / 2}" y="{y + 38}" font-family="DejaVu Sans" font-weight="bold" font-size="24" text-anchor="middle" fill="#2B160C">{text}</text></g>')

    # ---------------------------------------------------------------- personnages
    def person(self, x, kind="man", h=250, facing=1, skin=None, cloth="url(#waxA)", pants="#2F3E46",
               arms=("down", "down"), seated=False, mouth="smile", hair="#1B1B1B", accessory=None):
        """Personnage en aplats. x = centre, pieds au sol. kind : man, woman, boy, girl, elder, grandma, teacher, nurse."""
        g = []
        skin = skin or SKINS[0]
        dsk = shade(skin, -.22)
        s = h / 250.0
        y0 = GY + 8
        female = kind in ("woman", "girl", "grandma", "nurse")
        child = kind in ("boy", "girl")
        long_robe = kind in ("woman", "grandma", "elder", "nurse")
        hr = 27 * s
        if seated:
            hip = y0 - 82 * s
        else:
            hip = y0 - 112 * s
        sh = hip - (92 if not child else 80) * s
        hy = sh - hr - 12 * s
        # ombre au sol
        g.append(f'<ellipse cx="{x}" cy="{y0 + 2}" rx="{48 * s}" ry="{9 * s}" fill="#000" opacity=".16"/>')
        # ---- jambes
        if seated:
            fx = facing
            g.append(f'<path d="M{x - 18 * s} {hip} h{fx * 70 * s} v{y0 - hip - 8 * s}" stroke="{pants if not long_robe else skin}" stroke-width="{26 * s}" fill="none" stroke-linejoin="round"/>')
            g.append(f'<path d="M{x + 4 * s} {hip + 6 * s} h{fx * 56 * s} v{y0 - hip - 14 * s}" stroke="{shade(pants if not long_robe else skin, -.15)}" stroke-width="{24 * s}" fill="none" stroke-linejoin="round"/>')
            for dx in (52, 74):
                g.append(f'<ellipse cx="{x + fx * dx * s}" cy="{y0 - 4 * s}" rx="{18 * s}" ry="{8 * s}" fill="#3A2A1A"/>')
        else:
            legc = skin if (long_robe or child) else pants
            g.append(f'<rect x="{x - 24 * s}" y="{hip}" width="{20 * s}" height="{y0 - hip - 8 * s}" rx="{8 * s}" fill="{legc}"/>')
            g.append(f'<rect x="{x + 4 * s}" y="{hip}" width="{20 * s}" height="{y0 - hip - 8 * s}" rx="{8 * s}" fill="{shade(legc, -.12)}"/>')
            if kind == "boy":
                g.append(f'<path d="M{x - 30 * s} {hip - 6 * s} h{60 * s} l4 {44 * s} h-{30 * s} l-4 -{22 * s} l-4 {22 * s} h-{30 * s} Z" fill="{pants}"/>')
            for dx in (-14, 14):
                g.append(f'<ellipse cx="{x + dx * s + facing * 6 * s}" cy="{y0 - 6 * s}" rx="{17 * s}" ry="{8 * s}" fill="{"#3A2A1A" if dx < 0 else "#2A1A0E"}"/>')
        # ---- corps
        if long_robe:
            bottom = y0 - 14 * s if not seated else hip + 26 * s
            wide = 52 * s if kind != "elder" else 60 * s
            g.append(f'<path d="M{x - 26 * s} {sh} Q{x - wide} {(sh + bottom) / 2} {x - wide - 6 * s} {bottom} H{x + wide + 6 * s} '
                     f'Q{x + wide} {(sh + bottom) / 2} {x + 26 * s} {sh} Z" fill="{cloth}"/>')
            g.append(f'<path d="M{x + 6 * s} {sh} Q{x + wide} {(sh + bottom) / 2} {x + wide + 6 * s} {bottom} H{x + 22 * s} Z" fill="#000" opacity=".14"/>')
            if kind in ("woman", "grandma"):
                g.append(f'<path d="M{x - wide - 4 * s} {sh + (bottom - sh) * .52} H{x + wide + 4 * s}" stroke="#FFF3E0" stroke-width="{5 * s}" opacity=".7"/>')
            if kind == "elder":
                g.append(f'<path d="M{x - 14 * s} {sh + 2 * s} Q{x} {sh + 40 * s} {x + 14 * s} {sh + 2 * s}" stroke="#F2C14E" stroke-width="{5 * s}" fill="none"/>')
            if kind == "nurse":
                g.append(f'<rect x="{x - 9 * s}" y="{sh + 26 * s}" width="{18 * s}" height="{18 * s}" fill="#FFFFFF"/>'
                         f'<path d="M{x} {sh + 29 * s} v{12 * s} M{x - 6 * s} {sh + 35 * s} h{12 * s}" stroke="#E63946" stroke-width="{4 * s}"/>')
        else:
            g.append(f'<path d="M{x - 34 * s} {sh + 6 * s} Q{x - 38 * s} {hip - 30 * s} {x - 32 * s} {hip + 4 * s} H{x + 32 * s} '
                     f'Q{x + 38 * s} {hip - 30 * s} {x + 34 * s} {sh + 6 * s} Q{x} {sh - 8 * s} {x - 34 * s} {sh + 6 * s} Z" fill="{cloth}"/>')
            g.append(f'<path d="M{x + 8 * s} {sh} Q{x + 38 * s} {hip - 30 * s} {x + 32 * s} {hip + 4 * s} H{x + 14 * s} Z" fill="#000" opacity=".14"/>')
            g.append(f'<path d="M{x - 10 * s} {sh - 1 * s} L{x} {sh + 14 * s} L{x + 10 * s} {sh - 1 * s}" fill="{dsk}"/>')
        # ---- bras
        for side, pose in ((-1, arms[0]), (1, arms[1])):
            sx = x + side * 30 * s
            sy = sh + 14 * s
            sleeve = cloth
            tw = 15 * s
            if pose == "down":
                pts = [(sx, sy), (sx + side * 8 * s, sy + 44 * s), (sx + side * 6 * s, sy + 82 * s)]
            elif pose == "wave":
                pts = [(sx, sy), (sx + side * 34 * s, sy - 16 * s), (sx + side * 42 * s, sy - 62 * s)]
            elif pose == "point":
                pts = [(sx, sy), (sx + side * 44 * s, sy + 12 * s), (sx + side * 82 * s, sy + 2 * s)]
            elif pose == "hip":
                pts = [(sx, sy), (sx + side * 26 * s, sy + 36 * s), (sx + side * 4 * s, sy + 64 * s)]
            elif pose == "hold":
                pts = [(sx, sy), (sx + side * 10 * s, sy + 46 * s), (sx + side * 40 * s, sy + 52 * s)]
            elif pose == "mouth":
                pts = [(sx, sy), (sx + side * 30 * s, sy + 26 * s), (x + side * 20 * s, hy + 10 * s)]
            elif pose == "phone":
                pts = [(sx, sy), (sx + side * 26 * s, sy + 34 * s), (x + side * 22 * s, hy + 6 * s)]
            elif pose == "chin":
                pts = [(sx, sy), (sx + side * 22 * s, sy + 44 * s), (x + side * 8 * s, hy + hr + 4 * s)]
            elif pose == "basket":
                pts = [(sx, sy), (sx + side * 26 * s, sy - 30 * s), (x + side * 26 * s, hy - hr - 18 * s)]
            elif pose == "cane":
                pts = [(sx, sy), (sx + side * 22 * s, sy + 36 * s), (sx + side * 34 * s, sy + 58 * s)]
            elif pose == "machete":
                pts = [(sx, sy), (sx + side * 10 * s, sy + 44 * s), (sx + side * 10 * s, sy + 82 * s)]
            else:
                pts = [(sx, sy), (sx + side * 8 * s, sy + 44 * s), (sx + side * 6 * s, sy + 82 * s)]
            (ax, ay), (bx, by), (cx, cy) = pts
            g.append(f'<path d="M{ax:.0f} {ay:.0f} L{bx:.0f} {by:.0f}" stroke="{sleeve}" stroke-width="{tw * 1.35:.0f}" stroke-linecap="round"/>')
            g.append(f'<path d="M{bx:.0f} {by:.0f} L{cx:.0f} {cy:.0f}" stroke="{skin}" stroke-width="{tw:.0f}" stroke-linecap="round"/>')
            g.append(f'<circle cx="{cx:.0f}" cy="{cy:.0f}" r="{9 * s:.1f}" fill="{skin}"/>')
            if pose == "phone":
                g.append(f'<rect x="{cx - 7 * s:.0f}" y="{cy - 22 * s:.0f}" width="{14 * s:.0f}" height="{28 * s:.0f}" rx="3" fill="#222"/>')
            if pose == "cane":
                g.append(f'<path d="M{cx:.0f} {cy - 10 * s:.0f} L{cx + side * 8 * s:.0f} {y0}" stroke="#6B3F1D" stroke-width="{7 * s:.0f}" stroke-linecap="round"/>')
            if pose == "machete":
                g.append(f'<path d="M{cx:.0f} {cy:.0f} l{side * 4 * s:.0f} {12 * s:.0f} q{side * 12 * s:.0f} {40 * s:.0f} {side * 30 * s:.0f} {52 * s:.0f} '
                         f'q{-side * 8 * s:.0f} {-30 * s:.0f} {-side * 24 * s:.0f} {-56 * s:.0f} Z" fill="#C0C6CC" stroke="#7D8590" stroke-width="2"/>')
            if pose == "hold" and side == 1 and accessory == "book":
                g.append(f'<rect x="{cx - 34 * s:.0f}" y="{cy - 30 * s:.0f}" width="{40 * s:.0f}" height="{30 * s:.0f}" rx="3" fill="#E63946"/>'
                         f'<rect x="{cx - 30 * s:.0f}" y="{cy - 27 * s:.0f}" width="{32 * s:.0f}" height="{24 * s:.0f}" fill="#FFF"/>')
        if "basket" in arms:
            g.append(f'<path d="M{x - 46 * s} {hy - hr - 14 * s} H{x + 46 * s} l-12 {-24 * s} H{x - 34 * s} Z" fill="#C8963E"/>')
            for k in range(-3, 4):
                g.append(f'<circle cx="{x + k * 11 * s}" cy="{hy - hr - 42 * s}" r="{9 * s}" fill="{"#F77F00" if k % 2 else "#E63946"}"/>')
        # ---- cou, tête
        g.append(f'<rect x="{x - 9 * s}" y="{hy + hr - 6 * s}" width="{18 * s}" height="{20 * s}" fill="{dsk}"/>')
        g.append(f'<ellipse cx="{x - hr}" cy="{hy + 2 * s}" rx="{6 * s}" ry="{8 * s}" fill="{skin}"/><ellipse cx="{x + hr}" cy="{hy + 2 * s}" rx="{6 * s}" ry="{8 * s}" fill="{skin}"/>')
        g.append(f'<ellipse cx="{x}" cy="{hy}" rx="{hr}" ry="{hr * 1.08}" fill="{skin}"/>')
        g.append(f'<path d="M{x + hr * .2} {hy - hr} Q{x + hr * 1.1} {hy} {x + hr * .3} {hy + hr * 1.05} Q{x + hr} {hy} {x + hr * .2} {hy - hr} Z" fill="#000" opacity=".10"/>')
        # cheveux / coiffes
        if kind in ("woman", "grandma", "nurse"):
            wrap = {"woman": "url(#waxB)", "grandma": "url(#waxD)", "nurse": "#FFFFFF"}[kind]
            if kind == "nurse":
                g.append(f'<path d="M{x - hr - 2} {hy - hr * .35} Q{x} {hy - hr * 1.75} {x + hr + 2} {hy - hr * .35} Z" fill="{hair}"/>'
                         f'<path d="M{x - hr * .9} {hy - hr * .9} h{hr * 1.8} l-6 -{18 * s} h-{hr * 1.8 - 12} Z" fill="#FFFFFF"/>'
                         f'<path d="M{x} {hy - hr * 1.5} v{10 * s} M{x - 5 * s} {hy - hr * 1.5 + 5 * s} h{10 * s}" stroke="#E63946" stroke-width="{3 * s}"/>')
            else:
                g.append(f'<path d="M{x - hr - 4 * s} {hy - hr * .2} C{x - hr - 12 * s} {hy - hr * 2.1} {x + hr + 14 * s} {hy - hr * 2.2} {x + hr + 4 * s} {hy - hr * .2} '
                         f'Q{x} {hy - hr * .7} {x - hr - 4 * s} {hy - hr * .2} Z" fill="{wrap}"/>')
                kx = x - facing * hr * .2
                g.append(f'<path d="M{kx} {hy - hr * 1.55} c{-facing * 40 * s} {-34 * s} {-facing * 62 * s} {10 * s} {-facing * 18 * s} {16 * s} Z" fill="{wrap}"/>'
                         f'<path d="M{kx} {hy - hr * 1.55} c{facing * 20 * s} {-44 * s} {facing * 58 * s} {-30 * s} {facing * 30 * s} {4 * s} Z" fill="{wrap}"/>')
                g.append(f'<path d="M{x - hr - 4 * s} {hy - hr * .2} Q{x} {hy - hr * .7} {x + hr + 4 * s} {hy - hr * .2}" stroke="#000" stroke-opacity=".2" stroke-width="{3 * s}" fill="none"/>')
        elif kind == "girl":
            g.append(f'<path d="M{x - hr - 2} {hy - hr * .1} Q{x - hr} {hy - hr * 1.35} {x} {hy - hr * 1.2} Q{x + hr} {hy - hr * 1.35} {x + hr + 2} {hy - hr * .1} '
                     f'Q{x} {hy - hr * .75} {x - hr - 2} {hy - hr * .1} Z" fill="{hair}"/>')
            for side in (-1, 1):
                bx = x + side * (hr + 8 * s)
                g.append(f'<circle cx="{bx}" cy="{hy - hr * .7}" r="{12 * s}" fill="{hair}"/><circle cx="{bx}" cy="{hy - hr * .7 + 12 * s}" r="{5 * s}" fill="#E63946"/>')
            for k in (-1, 0, 1):
                g.append(f'<path d="M{x + k * 10 * s} {hy - hr * 1.15} v{14 * s}" stroke="{shade(hair, .25)}" stroke-width="2"/>')
        elif kind == "elder":
            g.append(f'<path d="M{x - hr - 1} {hy - hr * .35} V{hy - hr * 1.05} Q{x} {hy - hr * 1.6} {x + hr + 1} {hy - hr * 1.05} V{hy - hr * .35} Z" fill="url(#kente)"/>')
            g.append(f'<path d="M{x - hr * .85} {hy + hr * .35} Q{x} {hy + hr * 1.75} {x + hr * .85} {hy + hr * .35} Q{x} {hy + hr * .95} {x - hr * .85} {hy + hr * .35} Z" fill="#EDEDED"/>')
        else:
            g.append(f'<path d="M{x - hr - 1} {hy - hr * .05} Q{x - hr * 1.05} {hy - hr * 1.3} {x} {hy - hr * 1.18} Q{x + hr * 1.05} {hy - hr * 1.3} {x + hr + 1} {hy - hr * .05} '
                     f'Q{x + hr * .6} {hy - hr * .78} {x} {hy - hr * .8} Q{x - hr * .6} {hy - hr * .78} {x - hr - 1} {hy - hr * .05} Z" fill="{hair}"/>')
            if kind == "teacher":
                for side in (-1, 1):
                    g.append(f'<circle cx="{x + side * 11 * s + facing * 3 * s}" cy="{hy - 1 * s}" r="{9 * s}" fill="none" stroke="#2B2B2B" stroke-width="{2.6 * s}"/>')
                g.append(f'<path d="M{x - 2 * s + facing * 3 * s} {hy - 1 * s} h{4 * s}" stroke="#2B2B2B" stroke-width="{2.6 * s}"/>')
        # visage
        ex = 10 * s
        ox = facing * 3 * s
        for side in (-1, 1):
            g.append(f'<ellipse cx="{x + side * ex + ox}" cy="{hy - 1 * s}" rx="{5.2 * s}" ry="{6 * s}" fill="#FFFFFF"/>'
                     f'<circle cx="{x + side * ex + ox + facing * 1.4 * s}" cy="{hy}" r="{3.3 * s}" fill="#1A0F08"/>'
                     f'<circle cx="{x + side * ex + ox + facing * 1.4 * s + 1}" cy="{hy - 1.4 * s}" r="{1 * s}" fill="#FFFFFF"/>')
            g.append(f'<path d="M{x + side * ex + ox - 6 * s} {hy - 11 * s} q{6 * s} {-4 * s} {12 * s} 0" stroke="{shade(hair, 0) if kind != "elder" else "#DDD"}" stroke-width="{2.6 * s}" fill="none" stroke-linecap="round"/>')
        g.append(f'<path d="M{x + ox - 3 * s} {hy + 8 * s} q{3 * s} {4 * s} {7 * s} 0" stroke="{dsk}" stroke-width="{2.6 * s}" fill="none" stroke-linecap="round"/>')
        my = hy + 16 * s
        if mouth == "smile":
            g.append(f'<path d="M{x + ox - 9 * s} {my} Q{x + ox} {my + 9 * s} {x + ox + 9 * s} {my} Z" fill="#7A1F1F"/>'
                     f'<path d="M{x + ox - 7 * s} {my + 1 * s} Q{x + ox} {my + 4 * s} {x + ox + 7 * s} {my + 1 * s}" stroke="#FFFFFF" stroke-width="{2 * s}" fill="none"/>')
        elif mouth == "open":
            g.append(f'<ellipse cx="{x + ox}" cy="{my + 2 * s}" rx="{6 * s}" ry="{7 * s}" fill="#7A1F1F"/><ellipse cx="{x + ox}" cy="{my + 5 * s}" rx="{4 * s}" ry="{3 * s}" fill="#D9534F"/>')
        elif mouth == "sad":
            g.append(f'<path d="M{x + ox - 8 * s} {my + 5 * s} Q{x + ox} {my - 3 * s} {x + ox + 8 * s} {my + 5 * s}" stroke="#7A1F1F" stroke-width="{3 * s}" fill="none" stroke-linecap="round"/>')
        else:
            g.append(f'<path d="M{x + ox - 7 * s} {my + 2 * s} h{14 * s}" stroke="#7A1F1F" stroke-width="{3 * s}" stroke-linecap="round"/>')
        if female:
            g.append(f'<circle cx="{x - 16 * s + ox}" cy="{hy + 9 * s}" r="{5 * s}" fill="#E07A5F" opacity=".35"/><circle cx="{x + 16 * s + ox}" cy="{hy + 9 * s}" r="{5 * s}" fill="#E07A5F" opacity=".35"/>')
            if kind in ("woman", "grandma"):
                g.append(f'<circle cx="{x - hr - 1}" cy="{hy + 12 * s}" r="{4 * s}" fill="#F2C14E"/><circle cx="{x + hr + 1}" cy="{hy + 12 * s}" r="{4 * s}" fill="#F2C14E"/>')
        if kind == "man" and accessory == "moustache":
            g.append(f'<path d="M{x + ox - 11 * s} {my - 3 * s} q{11 * s} {-7 * s} {22 * s} 0" stroke="{hair}" stroke-width="{4 * s}" fill="none" stroke-linecap="round"/>')
        self.add("<g>" + "".join(g) + "</g>")

    def child_lying(self, x, y=GY - 6, skin=SKINS[1]):
        self.add(f'<ellipse cx="{x + 60}" cy="{y + 16}" rx="90" ry="12" fill="#000" opacity=".18"/>')
        self.add(f'<rect x="{x + 18}" y="{y - 22}" width="92" height="38" rx="16" fill="#E9C46A"/>'
                 f'<circle cx="{x + 44}" cy="{y - 6}" r="5" fill="#8D6E63"/><circle cx="{x + 74}" cy="{y + 4}" r="6" fill="#8D6E63"/><circle cx="{x + 92}" cy="{y - 12}" r="4" fill="#8D6E63"/>')
        self.add(f'<rect x="{x + 104}" y="{y - 12}" width="70" height="16" rx="8" fill="{skin}"/><rect x="{x + 104}" y="{y + 6}" width="66" height="14" rx="7" fill="{shade(skin, -.12)}"/>')
        self.add(f'<circle cx="{x}" cy="{y - 6}" r="26" fill="{skin}"/><path d="M{x - 26} {y - 10} Q{x - 20} {y - 38} {x + 4} {y - 32} Q{x + 22} {y - 28} {x + 24} {y - 14} Z" fill="#1B1B1B"/>'
                 f'<path d="M{x + 2} {y - 4} q6 4 12 0 M{x - 16} {y - 4} q6 4 12 0" stroke="#1A0F08" stroke-width="2.6" fill="none"/>'
                 f'<path d="M{x - 4} {y + 10} q6 -4 12 0" stroke="#7A1F1F" stroke-width="3" fill="none"/>')

    def genie(self, x, y):
        self.add(f'<path d="M{x} {y} Q{x - 160} {y - 70} {x - 230} {y + 10} Q{x - 160} {y - 10} {x - 120} {y + 30} Q{x - 70} {y + 10} {x} {y + 30} Z" fill="#5E3A1E"/>'
                 f'<path d="M{x} {y} Q{x + 160} {y - 70} {x + 230} {y + 10} Q{x + 160} {y - 10} {x + 120} {y + 30} Q{x + 70} {y + 10} {x} {y + 30} Z" fill="#4A2D16"/>')
        self.add(f'<path d="M{x - 40} {y - 10} Q{x} {y - 30} {x + 40} {y - 10} L{x + 30} {y + 110} Q{x} {y + 130} {x - 30} {y + 110} Z" fill="url(#bogolan)"/>')
        self.add(f'<path d="M{x - 34} {y - 70} Q{x} {y - 100} {x + 34} {y - 70} L{x + 30} {y - 4} Q{x} {y + 16} {x - 30} {y - 4} Z" fill="#B5651D"/>'
                 f'<path d="M{x - 22} {y - 46} l14 -6 l2 10 Z M{x + 22} {y - 46} l-14 -6 l-2 10 Z" fill="#FFD23F"/>'
                 f'<path d="M{x - 14} {y - 14} q14 10 28 0" stroke="#2B160C" stroke-width="4" fill="none"/>'
                 f'<path d="M{x - 30} {y - 80} l-10 -40 l20 26 l10 -36 l10 34 l12 -30 l2 40 Z" fill="#E63946"/>')
        # l'enfant emporté
        self.add(f'<circle cx="{x + 50}" cy="{y + 70}" r="18" fill="{SKINS[1]}"/><path d="M{x + 32} {y + 66} Q{x + 50} {y + 44} {x + 68} {y + 66} Z" fill="#1B1B1B"/>'
                 f'<rect x="{x + 38}" y="{y + 86}" width="26" height="42" rx="8" fill="#F2C14E"/>'
                 f'<path d="M{x + 42} {y + 126} l-6 24 M{x + 58} {y + 126} l6 24" stroke="{SKINS[1]}" stroke-width="9" stroke-linecap="round"/>'
                 f'<path d="M{x + 40} {y + 64} q4 4 8 0 M{x + 52} {y + 64} q4 4 8 0" stroke="#1A0F08" stroke-width="2" fill="none"/>'
                 f'<ellipse cx="{x + 50}" cy="{y + 78}" rx="4" ry="5" fill="#7A1F1F"/>')

    def frame(self):
        """Liseré wax en bas de l'image."""
        self.add(f'<rect y="{H - 22}" width="{W}" height="22" fill="url(#kente)"/>')


# =============================================================================== scènes

def sc_patio():
    s = S("skyDay"); s.sky_bg(); s.cloud(160, 90); s.cloud(640, 70, .8); s.sun(860, 90)
    s.ground("#D9A05B"); s.house(660, 280, 190, wall="#F4E1C1", roof="#C0392B", windows=2, sign="COLEGIO")
    s.flag_ci(70, 330); s.bush(150, 200)
    s.person(250, "girl", 230, 1, skin=SKINS[1], cloth="url(#waxC)", arms=("down", "wave"), mouth="open")
    s.person(360, "boy", 235, -1, skin=SKINS[0], cloth="#FFFFFF", pants="#2B4C7E", arms=("down", "down"))
    s.person(475, "woman", 250, 1, skin=SKINS[3], cloth="url(#waxB)", arms=("hip", "down"))
    s.person(600, "man", 265, -1, skin=SKINS[2], cloth="#E9F5DB", pants="#3D405B", arms=("down", "wave"))
    s.bubble(130, 150, "¡Hola! Me llamo Fatou.", tail=1); s.frame(); return s


def sc_familia():
    s = S(); s.wall_in()
    s.add('<rect x="330" y="70" width="300" height="190" fill="#8ECAE6"/><path d="M330 70 h300 v190 h-300 Z" fill="none" stroke="#FFFFFF" stroke-width="10"/>'
          '<path d="M480 70 v190" stroke="#FFFFFF" stroke-width="8"/>')
    s.add('<path d="M300 50 q40 120 0 230 h40 q-30 -110 0 -230 Z M660 50 q-40 120 0 230 h-40 q30 -110 0 -230 Z" fill="url(#waxD)"/><rect x="290" y="44" width="380" height="12" rx="6" fill="#7A4A26"/>')
    s.add('<rect x="730" y="300" width="170" height="110" rx="8" fill="#3D405B"/><rect x="745" y="315" width="140" height="80" fill="#5FA8D3"/><rect x="720" y="410" width="190" height="90" fill="#8A5530"/>')
    s.floor_in(480)
    s.person(170, "man", 270, 1, skin=SKINS[2], cloth="url(#kente)", pants="#2F3E46", arms=("down", "point"), accessory="moustache")
    s.round_table(480, 400, 320)
    s.person(345, "girl", 190, 1, skin=SKINS[1], cloth="#E63946", arms=("down", "hold"), seated=False)
    s.person(610, "boy", 180, -1, skin=SKINS[0], cloth="#FFD166", pants="#1D3557", arms=("hold", "down"))
    s.person(800, "woman", 260, -1, skin=SKINS[3], cloth="url(#waxA)", arms=("hold", "hip"))
    s.person(60, "girl", 150, 1, skin=SKINS[5], cloth="url(#waxC)", arms=("wave", "down"))
    s.frame(); return s


def sc_campo():
    s = S("skyWarm"); s.sky_bg(); s.sun(740, 120, 50); s.hills("#B5C96A", 390)
    s.ground("#D08C4A"); s.hut(600, 200, 115, 115); s.palm(90, 300); s.tree(880, .8, "#3E7C3A")
    s.person(330, "man", 275, 1, skin=SKINS[2], cloth="url(#waxC)", pants="#5C4033", arms=("machete", "point"), mouth="open", accessory="moustache")
    s.person(520, "boy", 200, -1, skin=SKINS[1], cloth="#F2C14E", pants="#457B9D", arms=("chin", "down"), mouth="sad")
    s.bubble(170, 120, "¡Vamos al campo!", tail=1); s.bubble(470, 170, "No voy.", tail=-1)
    s.frame(); return s


def sc_selva():
    s = S(); s.sky_bg("forest")
    for i, x in enumerate((60, 260, 460, 700, 900)):
        s.add(f'<rect x="{x - 14}" y="80" width="28" height="430" fill="#5A3E2B" opacity=".55"/><circle cx="{x}" cy="90" r="110" fill="#1F4D2B" opacity=".6"/>')
    s.ground("#7FA650"); s.baobab(120, 1.05); s.palm(880, 290); s.bush(560, 200, "#3F7D3A", "#F4A259")
    s.genie(470, 120)
    s.person(330, "man", 255, 1, skin=SKINS[0], cloth="#E9F5DB", pants="#3D405B", arms=("mouth", "machete"), mouth="open")
    s.person(640, "woman", 245, -1, skin=SKINS[3], cloth="url(#waxB)", arms=("mouth", "down"), mouth="open")
    s.person(760, "man", 260, -1, skin=SKINS[2], cloth="url(#kente)", pants="#5C4033", arms=("down", "mouth"), mouth="open")
    s.bubble(40, 160, "¡Kadjo! ¿Dónde estás?", tail=1); s.frame(); return s


def sc_veillee():
    s = S("skyNight"); s.sky_bg(); s.stars(45); s.moon(830, 90)
    s.hills("#2C3E50", 400); s.ground("#6B4A3A", grass=False); s.hut(770, 170, 100, 95, wall="#8D5B3C")
    s.fire(470)
    s.stool(90)
    s.person(130, "elder", 255, 1, skin=SKINS[4], cloth="url(#bogolan)", arms=("cane", "point"), seated=True, mouth="open")
    for sx in (300, 560, 700):
        s.stool(sx - 10, 60, h=36)
    s.person(320, "boy", 175, 1, skin=SKINS[1], cloth="#FFD166", pants="#264653", arms=("down", "chin"), seated=True)
    s.person(580, "girl", 170, -1, skin=SKINS[5], cloth="url(#waxA)", arms=("chin", "down"), seated=True)
    s.person(720, "boy", 175, -1, skin=SKINS[0], cloth="#90BE6D", pants="#3D405B", arms=("down", "hold"), seated=True)
    s.add(f'<rect width="{W}" height="{H}" fill="#1A1033" opacity=".12"/>')
    s.frame(); return s


def sc_mercado():
    s = S("skyDay"); s.sky_bg(); s.sun(120, 80, 40); s.cloud(700, 80)
    s.ground("#D9A05B"); s.palm(900, 290)
    s.add('<rect x="600" y="250" width="240" height="250" fill="#F4E1C1"/><path d="M590 250 h260 l-20 -40 h-220 Z" fill="#2A9D8F"/>'
          '<rect x="630" y="300" width="80" height="200" fill="#E76F51"/><rect x="735" y="300" width="80" height="70" fill="#8ECAE6"/>')
    s.stall(300, 340)
    s.person(500, "woman", 250, -1, skin=SKINS[2], cloth="url(#waxA)", arms=("point", "down"), mouth="open")
    s.person(190, "woman", 265, 1, skin=SKINS[3], cloth="url(#waxC)", arms=("basket", "point"))
    s.person(90, "girl", 160, 1, skin=SKINS[1], cloth="#E63946", arms=("down", "hold"))
    s.bubble(380, 110, "¿Cuánto cuesta?", tail=-1); s.frame(); return s


def sc_aula():
    s = S(); s.wall_in("#F6E7C8")
    s.add('<rect y="0" width="960" height="40" fill="url(#kente)" opacity=".9"/>')
    s.blackboard(300, 90, 360, 180, "¡Hola!")
    s.add('<circle cx="840" cy="140" r="42" fill="#3D405B"/><circle cx="840" cy="140" r="34" fill="#FFFFFF"/><path d="M840 140 v-22 M840 140 h16" stroke="#222" stroke-width="5" stroke-linecap="round"/>')
    s.add('<rect x="60" y="80" width="150" height="110" fill="#FFFFFF" stroke="#8B5A2B" stroke-width="8"/><path d="M80 170 q30 -60 60 -20 t50 -40" stroke="#2A9D8F" stroke-width="6" fill="none"/>')
    s.floor_in(470)
    s.person(200, "teacher", 270, 1, skin=SKINS[2], cloth="url(#waxB)", pants="#2F3E46", arms=("point", "hold"), mouth="open", accessory="book")
    for i, (xx, kind, cl, sk) in enumerate(((470, "girl", "url(#waxC)", SKINS[1]), (650, "boy", "#FFFFFF", SKINS[0]), (830, "girl", "url(#waxD)", SKINS[5]))):
        s.person(xx, kind, 170, -1, skin=sk, cloth=cl, pants="#2B4C7E", arms=("hold", "wave" if i == 1 else "down"), seated=True)
        s.desk(xx - 110, 120)
    s.frame(); return s


def sc_maquis():
    s = S("skyWarm"); s.sky_bg(); s.sun(820, 110, 44)
    s.ground("#CF8A4C")
    s.add('<rect x="40" y="170" width="16" height="330" fill="#6B4220"/><rect x="560" y="170" width="16" height="330" fill="#6B4220"/>')
    s.add('<path d="M10 190 L300 90 L600 190 Q300 215 10 190 Z" fill="url(#thatch)"/>')
    s.add('<rect x="660" y="230" width="190" height="150" rx="10" fill="#2B2B2B"/><text x="755" y="275" font-family="DejaVu Sans" font-weight="bold" font-size="24" text-anchor="middle" fill="#FFD166">MAQUIS</text>'
          '<text x="755" y="310" font-family="DejaVu Sans" font-size="18" text-anchor="middle" fill="#FFFFFF">Kedjenou · Attiéké</text><text x="755" y="338" font-family="DejaVu Sans" font-size="18" text-anchor="middle" fill="#FFFFFF">Alloco · Bissap</text>'
          '<rect x="748" y="380" width="14" height="120" fill="#555"/>')
    s.chair(200, 1); s.chair(500, -1)
    s.person(230, "man", 210, 1, skin=SKINS[0], cloth="url(#waxC)", pants="#3D405B", arms=("down", "hold"), seated=True, mouth="open")
    s.person(470, "woman", 210, -1, skin=SKINS[3], cloth="url(#waxD)", arms=("hold", "down"), seated=True)
    s.round_table(350, 400, 240, cloth="url(#waxA)")
    s.person(100, "woman", 255, 1, skin=SKINS[2], cloth="url(#kente)", arms=("down", "hold"), mouth="open")
    s.frame(); return s


def sc_gare():
    s = S("skyDay"); s.sky_bg(); s.cloud(200, 90); s.birds([(700, 70), (740, 55)])
    s.ground("#C9B79C", grass=False); s.add('<rect y="505" width="960" height="95" fill="#A89070"/>')
    s.bus(470, 420); s.clock_post(80, 240, 7, 30)
    s.person(190, "woman", 260, 1, skin=SKINS[3], cloth="url(#waxB)", arms=("basket", "down"))
    s.person(360, "boy", 225, -1, skin=SKINS[0], cloth="#E76F51", pants="#264653", arms=("mouth", "point"), mouth="open")
    s.add('<rect x="250" y="450" width="70" height="52" rx="6" fill="url(#waxA)"/>')
    s.frame(); return s


def sc_dispensaire():
    s = S("skyDay"); s.sky_bg(); s.sun(130, 80, 36); s.cloud(500, 70)
    s.ground("#D9A05B"); s.house(560, 360, 200, wall="#FFFFFF", roof="#2A9D8F", windows=2, sign="CENTRO DE SALUD")
    s.add('<rect x="580" y="270" width="54" height="54" rx="8" fill="#E63946"/><path d="M607 280 v34 M590 297 h34" stroke="#FFFFFF" stroke-width="9"/>')
    s.tree(90, .85)
    s.person(290, "nurse", 255, 1, skin=SKINS[2], cloth="#FFFFFF", arms=("hold", "point"), mouth="open")
    s.person(440, "man", 255, -1, skin=SKINS[0], cloth="url(#waxC)", pants="#3D405B", arms=("hip", "chin"), mouth="sad")
    s.frame(); return s


def sc_telefono():
    s = S(); s.add(f'<rect width="480" height="{H}" fill="url(#skyDay)"/><rect x="480" width="480" height="{H}" fill="url(#skyWarm)"/>')
    s.add('<g clip-path="none">')
    s.add('<rect x="0" y="500" width="480" height="100" fill="#D9A05B"/><rect x="480" y="500" width="480" height="100" fill="#CF8A4C"/>')
    s.add('<rect x="40" y="290" width="160" height="210" fill="#F4E1C1"/><path d="M30 290 h180 l-20 -40 h-140 Z" fill="#C0392B"/>')
    s.palm(880, 270); s.add('<rect x="560" y="320" width="130" height="180" fill="#F4E1C1"/><path d="M550 320 h150 l-20 -36 h-110 Z" fill="#2A9D8F"/>')
    s.add('<rect x="474" y="0" width="12" height="600" fill="#FFFFFF"/>')
    s.person(300, "girl", 245, 1, skin=SKINS[1], cloth="url(#waxC)", arms=("down", "phone"), mouth="open")
    s.person(740, "man", 265, -1, skin=SKINS[2], cloth="url(#kente)", pants="#2F3E46", arms=("phone", "down"))
    for k in range(3):
        s.add(f'<path d="M{350 + k * 18} {180 - k * 6} q14 22 0 44" stroke="#E63946" stroke-width="5" fill="none" stroke-linecap="round"/>')
        s.add(f'<path d="M{690 - k * 18} {175 - k * 6} q-14 22 0 44" stroke="#1D3557" stroke-width="5" fill="none" stroke-linecap="round"/>')
    s.add('</g>'); s.frame(); return s


def sc_couture():
    s = S(); s.wall_in("#F3DDBF")
    s.add('<path d="M20 70 H940" stroke="#6B4220" stroke-width="6"/>')
    for i, pat in enumerate(("waxA", "waxB", "waxC", "waxD", "kente", "bogolan")):
        x = 40 + i * 150
        s.add(f'<path d="M{x} 70 h110 v150 q-55 24 -110 0 Z" fill="url(#{pat})"/><circle cx="{x + 10}" cy="72" r="6" fill="#444"/><circle cx="{x + 100}" cy="72" r="6" fill="#444"/>')
    s.floor_in(480)
    s.add('<rect x="620" y="380" width="280" height="18" fill="#8A5530"/><rect x="636" y="398" width="14" height="110" fill="#6B4220"/><rect x="870" y="398" width="14" height="110" fill="#6B4220"/>'
          '<path d="M660 380 v-64 h120 v20 h-30 v44 Z" fill="#2B2B2B"/><path d="M660 316 q0 -24 30 -24 h80 q30 0 30 24" fill="#2B2B2B"/><circle cx="818" cy="350" r="18" fill="#9E9E9E"/>'
          '<rect x="700" y="372" width="140" height="10" fill="url(#waxA)"/>')
    s.person(790, "man", 220, -1, skin=SKINS[4], cloth="url(#kente)", pants="#3D405B", arms=("hold", "hold"), seated=True)
    s.person(260, "woman", 265, 1, skin=SKINS[3], cloth="url(#waxB)", arms=("down", "point"), mouth="open")
    s.person(440, "girl", 190, -1, skin=SKINS[1], cloth="#E63946", arms=("hold", "down"))
    s.frame(); return s


def sc_fete():
    s = S("skyWarm"); s.sky_bg(); s.sun(480, 140, 60); s.hills("#B5C96A", 410)
    s.ground("#D08C4A")
    s.add('<path d="M0 70 Q480 170 960 70" stroke="#5C4033" stroke-width="3" fill="none"/>')
    cols = ["#E63946", "#F77F00", "#FFD23F", "#2A9D8F", "#1D4E89"]
    for k in range(12):
        x = 30 + k * 80
        y = 70 + 100 * math.sin(math.pi * x / 960) * .95
        s.add(f'<path d="M{x - 18} {y - 2} h36 l-18 34 Z" fill="{cols[k % 5]}"/>')
    s.add('<path d="M110 505 l-20 -90 h90 l-20 90 Z" fill="#8B5A2B"/><ellipse cx="135" cy="415" rx="45" ry="12" fill="#F1E3C6"/><path d="M95 450 l80 30 M95 480 l80 -30" stroke="#5C3A1A" stroke-width="4"/>')
    s.person(70, "man", 210, 1, skin=SKINS[4], cloth="url(#bogolan)", pants="#3D405B", arms=("hold", "hold"), seated=True, mouth="open")
    s.person(370, "woman", 255, 1, skin=SKINS[3], cloth="url(#waxA)", arms=("wave", "wave"), mouth="open")
    s.person(530, "girl", 200, -1, skin=SKINS[1], cloth="url(#waxC)", arms=("wave", "hip"), mouth="open")
    s.person(700, "woman", 260, -1, skin=SKINS[2], cloth="url(#kente)", arms=("hip", "wave"), mouth="open")
    s.person(860, "elder", 255, -1, skin=SKINS[0], cloth="url(#waxB)", arms=("down", "cane"))
    for x, y in ((450, 150), (620, 120), (240, 200)):
        s.add(f'<path d="M{x} {y} v-40 l22 -6 v34" stroke="#2B160C" stroke-width="4" fill="none"/><circle cx="{x - 6}" cy="{y}" r="8" fill="#2B160C"/><circle cx="{x + 16}" cy="{y - 6}" r="8" fill="#2B160C"/>')
    s.frame(); return s


def sc_bureau():
    s = S(); s.wall_in("#EAF2F8")
    s.add('<rect x="560" y="70" width="320" height="200" fill="#8ECAE6"/><path d="M560 70 h320 v200 h-320 Z" fill="none" stroke="#FFFFFF" stroke-width="12"/>'
          '<path d="M600 250 v-60 h40 v60 M660 250 v-110 h44 v110 M724 250 v-80 h40 v80 M784 250 v-140 h50 v140" fill="#5C7A99"/>')
    s.add('<rect x="80" y="90" width="200" height="130" fill="#FFFFFF" stroke="#3D405B" stroke-width="6"/><path d="M100 200 L140 160 L180 175 L220 130 L260 140" stroke="#E63946" stroke-width="6" fill="none"/>')
    s.floor_in(480)
    s.add('<rect x="250" y="370" width="460" height="24" fill="#8A5530"/><rect x="270" y="394" width="16" height="110" fill="#6B4220"/><rect x="674" y="394" width="16" height="110" fill="#6B4220"/>'
          '<rect x="420" y="270" width="140" height="92" rx="8" fill="#2B2B2B"/><rect x="430" y="280" width="120" height="70" fill="#5FA8D3"/><rect x="470" y="362" width="40" height="10" fill="#444"/>'
          '<rect x="590" y="352" width="70" height="18" fill="#F2C14E"/><rect x="595" y="340" width="60" height="14" fill="#E9C46A"/>')
    s.chair(190, 1); s.chair(780, -1)
    s.person(210, "woman", 230, 1, skin=SKINS[3], cloth="url(#kente)", arms=("hold", "point"), seated=True, mouth="open")
    s.person(760, "man", 235, -1, skin=SKINS[2], cloth="#FFFFFF", pants="#2F3E46", arms=("hold", "chin"), seated=True)
    s.frame(); return s


def sc_place():
    s = S("skyDay"); s.sky_bg(); s.cloud(700, 90); s.sun(110, 80, 36)
    s.ground("#D9A05B"); s.house(640, 280, 160, wall="#F4E1C1", roof="#2A9D8F", windows=1)
    s.add('<rect x="440" y="150" width="90" height="355" fill="#C1666B"/><path d="M425 150 h120 l-60 -70 Z" fill="#7A2E33"/>'
          '<circle cx="485" cy="220" r="36" fill="#FFFFFF" stroke="#3D405B" stroke-width="7"/><path d="M485 220 v-24 M485 220 l18 10" stroke="#222" stroke-width="5" stroke-linecap="round"/>'
          '<rect x="440" y="300" width="90" height="18" fill="url(#kente)"/>')
    s.tree(110, .85)
    s.add('<rect x="560" y="455" width="110" height="14" fill="#8A5530"/><rect x="570" y="469" width="10" height="36" fill="#6B4220"/><rect x="650" y="469" width="10" height="36" fill="#6B4220"/>')
    s.person(310, "girl", 240, 1, skin=SKINS[1], cloth="url(#waxD)", arms=("down", "point"), mouth="open")
    s.person(780, "boy", 235, -1, skin=SKINS[0], cloth="url(#waxC)", pants="#264653", arms=("phone", "down"))
    s.frame(); return s


SCENES = {
    "patio": sc_patio, "familia": sc_familia, "campo": sc_campo, "selva": sc_selva, "veillee": sc_veillee,
    "mercado": sc_mercado, "aula": sc_aula, "maquis": sc_maquis, "gare": sc_gare, "dispensaire": sc_dispensaire,
    "telefono": sc_telefono, "couture": sc_couture, "fete": sc_fete, "bureau": sc_bureau, "place": sc_place,
}


def render(name, out_dir, preview_dir=None):
    svg = SCENES[name]().svg()
    png = subprocess.run(["rsvg-convert", "-w", "1200", "-h", "750", "-f", "png"], input=svg.encode(), capture_output=True, check=True).stdout
    im = Image.open(io.BytesIO(png)).convert("RGB")
    out = Path(out_dir) / f"{name}.webp"
    im.save(out, "WEBP", quality=82, method=6)
    if preview_dir:
        Path(preview_dir, f"{name}.svg").write_text(svg)
        im.save(Path(preview_dir) / f"{name}.png")
    return out


if __name__ == "__main__":
    here = Path(__file__).resolve().parent
    out_dir = here.parent / "app" / "src" / "main" / "assets" / "scenes"
    out_dir.mkdir(parents=True, exist_ok=True)
    prev = sys.argv[1] if len(sys.argv) > 1 else None
    if prev:
        os.makedirs(prev, exist_ok=True)
    only = sys.argv[2:] or list(SCENES)
    for n in only:
        p = render(n, out_dir, prev)
        print(n, p.stat().st_size // 1024, "Ko")
