"""Noms de lieux fictifs pour les cours des MODEL 2 et 3.

Les villes, communes et quartiers réels sont remplacés par des noms inventés, partout : textes du manuel,
dialogues, vocabulaire, lectures, quiz, ateliers et devoirs. Les pays (Côte d'Ivoire, España…) sont gardés.
La prononciation figurée des phrases modifiées est recalculée.

Appliqué par tools/quiz_practice.py juste avant l'écriture des JSON.
"""
import re

from pron_es import pron

# (motif, nom fictif). Les formes espagnoles et françaises d'une même ville donnent le même nom.
PLACES = [
    (r"Abidjan|Abiyán", "Lagunabé"),
    (r"Yamoussoukro|Yamusukro", "Kanzikro"),
    (r"San[- ]?\s*P[eé]dro", "Port-Lumé"),
    (r"Grand-\s*Bassam", "Bassilé-Plage"),
    (r"Bouaké", "Sanbara"),
    (r"Korhogo", "Siméla"),
    (r"Bingerville", "Mangoville"),
    (r"Daloa", "Gbaléa"),
    (r"Katiola", "Kanéla"),
    (r"Bouaflé", "Koflé"),
    (r"Cocody", "Lomana"),
    (r"Marcory", "Tiéméla"),
    (r"Treichville", "Kotiba"),
    (r"Yopougon", "Wassakro"),
    (r"Adjamé", "Kossiba"),
    (r"\bPlateau\b", "Bel-Horizon"),
    (r"\bKong\b", "Kandiara"),
    (r"\bMan\b", "Tonkimé"),
    (r"Madrid", "Valdeluna"),
    (r"Radio Lagunes", "Radio Arc-en-ciel"),
    (r"Radio Lagunas", "Radio Arcoíris"),
]
_RX = [(re.compile(p), r) for p, r in PLACES]

# Champs texte → champ de prononciation figurée à recalculer.
PRON_OF = {"text": "pron", "word": "pron", "example": "examplePron"}


_ELISION = re.compile(r"\b([dDlL])['’](?=(Lagunabé|Kossiba)\b)")


def rename(t):
    for rx, r in _RX:
        t = rx.sub(r, t)
    # « d'Abidjan » → « de Lagunabé » : plus d'élision devant une consonne.
    return _ELISION.sub(lambda m: m.group(1) + ("e " if m.group(1) in "dD" else "a "), t)


def fictionalize(node):
    """Remplace les lieux réels dans tout le document (modifié sur place)."""
    if isinstance(node, list):
        for i, v in enumerate(node):
            if isinstance(v, str):
                node[i] = rename(v)
            else:
                fictionalize(v)
    elif isinstance(node, dict):
        changed = []
        for k, v in list(node.items()):
            if isinstance(v, str):
                nv = rename(v)
                if nv != v:
                    node[k] = nv
                    changed.append(k)
            else:
                fictionalize(v)
        for k in changed:
            p = PRON_OF.get(k)
            if p and p in node:
                node[p] = pron(node[k])
    return node
