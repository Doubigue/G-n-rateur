"""MODEL 2 : quatre nouvelles leçons (17 à 20), au même format que les 16 chapitres du guide.

17 Voyager : transports et hébergement (B1)
18 La santé : chez le médecin et à la pharmacie (B1)
19 Le travail : métiers, CV et entretien d'embauche (B2)
20 L'environnement et la ville durable (C1)

Chaque leçon a aussi un texte de manuel (sourceContent) généré au format du guide : règle, règles à mémoriser,
exemples commentés, vocabulaire, lecture guidée, quiz, corrigé, travail personnel et auto-évaluation.
"""
from content_m3 import V, G, S, H


def Qx(question, correct, wrong, explain=""):
    return {"type": "mcq", "question": question, "correct": correct, "wrong": wrong, "explain": explain}


M2_NEW = [
    # ======================================================================= Leçon 17
    {
        "id": "m2-es-17", "level": "B1", "number": 17, "emoji": "🚌", "art": None,
        "title": "Voyager : transports et hébergement",
        "titleTr": "Voyager : transports et hébergement",
        "objective": "Acheter un billet, demander des horaires, réserver une chambre et se débrouiller en voyage.",
        "intro": "Mariam part de Yamoussoukro pour passer un week-end à San Pedro : elle achète son billet à la gare routière, "
                 "puis demande une chambre à la réception d'un hôtel. Vous apprenez les transports, les horaires, la durée d'un trajet "
                 "et les formules polies pour réserver.",
        "rule": [
            "Pour dire comment on voyage, on emploie en + moyen de transport : en autobús, en tren, en avión, en coche, en moto, en barco. "
            "Exception : a pie (à pied) et a caballo. Les verbes de mouvement se construisent avec a pour la destination "
            "(voy a San Pedro, llego a Abiyán) et de ou desde pour le point de départ (salgo de Yamusukro).",
            "Pour la durée d'un trajet, on emploie tardar : ¿Cuánto tarda el autobús? — Tarda cinco horas. "
            "Pour l'horaire : ¿A qué hora sale / llega el tren? — Sale a las siete y media.",
            "Pour réserver ou demander poliment, on préfère le conditionnel : quisiera (je voudrais), ¿podría…? (pourriez-vous… ?), "
            "me gustaría (j'aimerais). C'est plus courtois que quiero.",
        ],
        "memo": [
            "en autobús, en tren, en avión… mais a pie.",
            "ir a + destination ; salir de + point de départ.",
            "¿Cuánto tarda…? — Tarda + durée.",
            "¿A qué hora sale / llega…? — A las + heure.",
            "Politesse : quisiera, ¿podría…?, me gustaría.",
        ],
        "vocab": [
            V("la estación de autobuses", "la gare routière", "La estación de autobuses está en el centro.", "La gare routière est au centre-ville.", "🚏"),
            V("el billete de ida y vuelta", "le billet aller-retour", "Quisiera un billete de ida y vuelta a San Pedro.", "Je voudrais un aller-retour pour San Pedro.", "🎟️"),
            V("salir / llegar", "partir / arriver", "El autobús sale a las siete y llega a las doce.", "Le bus part à sept heures et arrive à midi.", "🕖"),
            V("tardar", "mettre (du temps), durer", "El viaje tarda cinco horas.", "Le voyage dure cinq heures.", "⏱️"),
            V("el asiento", "la place assise, le siège", "¿Este asiento está libre?", "Cette place est libre ?", "💺"),
            V("la maleta", "la valise", "Mi maleta pesa mucho.", "Ma valise est très lourde.", "🧳"),
            V("el hotel", "l'hôtel", "El hotel está cerca de la playa.", "L'hôtel est près de la plage.", "🏨"),
            V("reservar una habitación", "réserver une chambre", "Quisiera reservar una habitación doble.", "Je voudrais réserver une chambre double.", "🛎️"),
            V("la habitación individual / doble", "la chambre simple / double", "Una habitación individual para dos noches.", "Une chambre simple pour deux nuits.", "🛏️"),
            V("el desayuno incluido", "le petit déjeuner compris", "¿El desayuno está incluido?", "Le petit déjeuner est-il compris ?", "☕"),
            V("la llave", "la clé", "Aquí tiene la llave de su habitación.", "Voici la clé de votre chambre.", "🔑"),
            V("el viajero / la viajera", "le voyageur / la voyageuse", "Los viajeros esperan en el andén.", "Les voyageurs attendent sur le quai.", "🧍🏾"),
            V("el mapa", "la carte, le plan", "Mira el mapa de la ciudad.", "Regarde le plan de la ville.", "🗺️"),
            V("de vacaciones", "en vacances", "Estamos de vacaciones en Grand-Bassam.", "Nous sommes en vacances à Grand-Bassam.", "🏖️"),
        ],
        "grammar": [
            G("Comprendre la règle",
              "En + moyen de transport (en autobús, en avión), mais a pie. Ir / llegar a + destination ; salir de + départ. "
              "Tardar donne la durée d'un trajet : el viaje tarda cuatro horas.",
              [("Voy a San Pedro en autobús.", "Je vais à San Pedro en bus."),
               ("Salgo de Yamusukro a las siete.", "Je pars de Yamoussoukro à sept heures."),
               ("Al colegio voy a pie.", "Au collège, je vais à pied.")]),
            G("Horaires et durée : ¿A QUÉ HORA…? ¿CUÁNTO TARDA…?",
              "On demande l'heure de départ ou d'arrivée avec ¿A qué hora sale / llega…? et la durée avec ¿Cuánto tarda…? "
              "ou ¿Cuánto dura el viaje? Réponses : sale a las ocho, llega a mediodía, tarda unas tres horas (environ trois heures).",
              [("¿A qué hora sale el autobús para San Pedro? — A las siete y media.", "À quelle heure part le bus pour San Pedro ? — À sept heures et demie."),
               ("¿Cuánto tarda el viaje? — Unas cinco horas.", "Combien de temps dure le voyage ? — Environ cinq heures."),
               ("El tren llega a Bouaké a mediodía.", "Le train arrive à Bouaké à midi.")]),
            G("Réserver poliment : QUISIERA, ¿PODRÍA…?, ME GUSTARÍA",
              "Le conditionnel adoucit une demande. Quisiera (de querer) = je voudrais ; ¿Podría + infinitif? = pourriez-vous… ? ; "
              "me gustaría + infinitif = j'aimerais. On vouvoie (usted) à la réception d'un hôtel ou au guichet.",
              [("Quisiera reservar una habitación doble para el sábado.", "Je voudrais réserver une chambre double pour samedi."),
               ("¿Podría darme un horario de los autobuses?", "Pourriez-vous me donner les horaires des bus ?"),
               ("Me gustaría una habitación con vista al mar.", "J'aimerais une chambre avec vue sur la mer.")]),
        ],
        "scenes": [
            S("En la estación de autobuses", "À la gare routière", "gare",
              "Gare routière de Yamoussoukro, vendredi matin. Mariam veut partir à San Pedro pour le week-end.",
              {"A": "Taquillero", "B": "Mariam"},
              [("A", "Buenos días, señora. ¿Adónde va?", "Bonjour, madame. Où allez-vous ?"),
               ("B", "Buenos días. Quisiera un billete de ida y vuelta a San Pedro.", "Bonjour. Je voudrais un aller-retour pour San Pedro."),
               ("A", "¿Para hoy?", "Pour aujourd'hui ?"),
               ("B", "Sí. ¿A qué hora sale el próximo autobús?", "Oui. À quelle heure part le prochain bus ?"),
               ("A", "Sale a las nueve y media, dentro de veinte minutos.", "Il part à neuf heures et demie, dans vingt minutes."),
               ("B", "¿Y cuánto tarda el viaje?", "Et combien de temps dure le voyage ?"),
               ("A", "Unas cinco horas. Llega a las dos y media.", "Environ cinq heures. Il arrive à deux heures et demie."),
               ("B", "Perfecto. ¿Cuánto cuesta el billete?", "Parfait. Combien coûte le billet ?"),
               ("A", "Doce mil francos, ida y vuelta. Su asiento es el catorce.", "Douze mille francs, aller-retour. Votre place est la quatorze."),
               ("B", "Aquí tiene. ¡Gracias!", "Voici. Merci !")]),
            S("En la recepción del hotel", "À la réception de l'hôtel", "hotel",
              "Arrivée à San Pedro en fin d'après-midi, Mariam entre dans un petit hôtel près du port.",
              {"A": "Recepcionista", "B": "Mariam"},
              [("A", "¡Buenas tardes! Bienvenida al Hotel del Puerto. ¿En qué puedo ayudarle?", "Bonjour ! Bienvenue à l'Hôtel du Port. En quoi puis-je vous aider ?"),
               ("B", "Buenas tardes. Quisiera una habitación individual para dos noches.", "Bonjour. Je voudrais une chambre simple pour deux nuits."),
               ("A", "¿Tiene usted reserva?", "Avez-vous une réservation ?"),
               ("B", "No, no tengo reserva. ¿Hay habitaciones libres?", "Non, je n'ai pas de réservation. Avez-vous des chambres libres ?"),
               ("A", "Sí, tenemos una con vista al mar. Son veinticinco mil francos por noche.", "Oui, nous en avons une avec vue sur la mer. C'est vingt-cinq mille francs la nuit."),
               ("B", "Perfecto. ¿El desayuno está incluido?", "Parfait. Le petit déjeuner est-il compris ?"),
               ("A", "Sí, el desayuno está incluido, de siete a diez. ¿Me da su documento de identidad?", "Oui, le petit déjeuner est compris, de sept à dix heures. Vous me donnez votre pièce d'identité ?"),
               ("B", "Aquí tiene.", "Voici."),
               ("A", "Gracias. Aquí tiene la llave: habitación doce, en el primer piso.", "Merci. Voici la clé : chambre douze, au premier étage."),
               ("B", "Muchas gracias. ¿Podría llamar a un taxi mañana a las nueve?", "Merci beaucoup. Pourriez-vous appeler un taxi demain à neuf heures ?")]),
        ],
        "phrases_add": [
            ("Quisiera un billete de ida y vuelta.", "Je voudrais un billet aller-retour."),
            ("¿A qué hora sale el próximo autobús?", "À quelle heure part le prochain bus ?"),
            ("¿Cuánto tarda el viaje?", "Combien de temps dure le voyage ?"),
            ("¿Este asiento está libre?", "Cette place est libre ?"),
            ("Quisiera reservar una habitación doble.", "Je voudrais réserver une chambre double."),
            ("¿El desayuno está incluido?", "Le petit déjeuner est-il compris ?"),
            ("¿Podría llamar a un taxi, por favor?", "Pourriez-vous appeler un taxi, s'il vous plaît ?"),
        ],
        "reading_title": "Un fin de semana en San Pedro",
        "reading": [
            ("El viernes por la mañana, Mariam sale de Yamusukro en autobús.", "Le vendredi matin, Mariam part de Yamoussoukro en bus."),
            ("El viaje tarda unas cinco horas y el paisaje es muy verde.", "Le voyage dure environ cinq heures et le paysage est très vert."),
            ("En San Pedro, se aloja en un pequeño hotel cerca del puerto.", "À San Pedro, elle loge dans un petit hôtel près du port."),
            ("Su habitación es sencilla, pero tiene vista al mar.", "Sa chambre est simple, mais elle a vue sur la mer."),
            ("El sábado visita el mercado y pasea por la playa.", "Le samedi, elle visite le marché et se promène sur la plage."),
            ("El domingo por la tarde vuelve a casa, cansada pero contenta.", "Le dimanche après-midi, elle rentre chez elle, fatiguée mais contente."),
        ],
        "questions": "1) ¿De dónde sale Mariam? 2) ¿Cuánto tarda el viaje? 3) ¿Dónde está el hotel? 4) ¿Qué hace el sábado?",
        "homework": [
            H("Écris un dialogue au guichet d'une gare (8 répliques) : destination, heure de départ, durée, prix, place.",
              "— Buenos días. Quisiera un billete a Bouaké. — ¿Ida o ida y vuelta? — Solo ida. ¿A qué hora sale el tren? — A las ocho. — ¿Cuánto tarda? — Cuatro horas. — ¿Cuánto cuesta? — Siete mil francos.",
              ["quisiera", "a qué hora", "cuánto tarda", "cuánto cuesta"]),
            H("Écris un courriel pour réserver une chambre d'hôtel : dates, type de chambre, petit déjeuner, heure d'arrivée.",
              "Buenos días: quisiera reservar una habitación doble para el 12 y el 13 de diciembre. ¿El desayuno está incluido? Llegaré hacia las cuatro de la tarde. Muchas gracias. Saludos, Koffi Yao.",
              ["quisiera reservar", "habitación", "desayuno", "llegaré"]),
            H("Raconte en 6 phrases un voyage que tu as fait ou que tu aimerais faire en Côte d'Ivoire.",
              "Me gustaría viajar a Man en autobús. El viaje tarda unas seis horas. Allí visitaría las cascadas y la Dent de Man. Me alojaría en un hotel pequeño.",
              ["viajar", "en autobús", "tarda", "hotel"]),
        ],
        "quiz_add": [
            Qx("« Je vais à Bouaké en train » :", "Voy a Bouaké en tren.", ["Voy en Bouaké en tren.", "Voy a Bouaké por tren de.", "Voy a Bouaké a tren."], "Destination : a ; moyen de transport : en."),
            Qx("« À pied » se dit :", "a pie", ["en pie", "de pie a", "por pies"], "Exception : a pie (et non en pie)."),
            Qx("« Combien de temps dure le voyage ? »", "¿Cuánto tarda el viaje?", ["¿Cuánto cuesta el viaje?", "¿Qué hora tarda el viaje?", "¿Cuándo tarda el viaje?"], "Tardar = mettre du temps."),
            Qx("La forme la plus polie pour réserver :", "Quisiera reservar una habitación.", ["Quiero una habitación ya.", "Dame una habitación.", "Reservo habitación."], "Quisiera (conditionnel / subjonctif de politesse)."),
            Qx("« Le petit déjeuner est compris » :", "El desayuno está incluido.", ["El desayuno es incluido de.", "El desayuno tiene incluido.", "El almuerzo está incluido."]),
        ],
        "manual_quiz": [
            ("Comment dit-on « en avion » ?", "en avión", ["a avión", "por avión", "de avión"], "On emploie en + moyen de transport."),
            ("Quel verbe donne la durée d'un trajet ?", "tardar", ["tomar", "llevar a", "salir"], "¿Cuánto tarda el viaje?"),
            ("Quelle formule est la plus polie ?", "¿Podría ayudarme?", ["¡Ayúdame!", "Quiero ayuda.", "Ayuda ahora."], "Le conditionnel adoucit la demande."),
            ("Quelle préposition introduit le point de départ ?", "de", ["a", "en", "para"], "Salgo de Yamusukro."),
        ],
        "selfcheck": ["Je peux acheter un billet et demander un horaire", "Je peux réserver une chambre poliment", "Je peux raconter un trajet"],
    },
    # ======================================================================= Leçon 18
    {
        "id": "m2-es-18", "level": "B1", "number": 18, "emoji": "🩺", "art": None,
        "title": "La santé : chez le médecin et à la pharmacie",
        "titleTr": "La santé : chez le médecin et à la pharmacie",
        "objective": "Prendre rendez-vous, décrire ce qu'on ressent, comprendre les consignes du médecin et du pharmacien.",
        "intro": "Ibrahim ne se sent pas bien : il appelle le dispensaire pour un rendez-vous, explique au médecin ce qu'il ressent, "
                 "puis passe à la pharmacie. Vous apprenez le vocabulaire du corps et de la santé, à dire depuis quand vous êtes malade "
                 "(desde hace) et à comprendre les consignes données au vouvoiement.",
        "rule": [
            "Pour décrire un symptôme, on combine trois structures : tener + nom (tengo fiebre, tengo tos, tengo dolor de cabeza), "
            "estar + adjectif pour un état passager (estoy cansado, estoy mareada) et doler, qui se construit comme gustar "
            "(me duele la garganta, me duelen los ojos).",
            "Pour dire depuis quand, on emploie desde hace + durée (estoy enfermo desde hace dos días) ou desde + date "
            "(desde el lunes). Question : ¿Desde cuándo…?",
            "Le médecin vouvoie le patient et donne ses consignes à l'impératif de usted : tome, beba, descanse, vuelva. "
            "Les pronoms se collent à la fin de l'impératif affirmatif : tómelo, descánse (avec un accent écrit pour garder l'accent tonique).",
        ],
        "memo": [
            "tener fiebre / tos / dolor de… ; estar cansado / mareado.",
            "me duele + singulier ; me duelen + pluriel.",
            "desde hace + durée ; desde + date ; ¿Desde cuándo…?",
            "Impératif de usted : tome, beba, descanse, vuelva.",
            "Pronom collé : tómelo, cuídese.",
        ],
        "vocab": [
            V("la cita", "le rendez-vous", "Quisiera pedir una cita con el médico.", "Je voudrais prendre rendez-vous avec le médecin.", "📅"),
            V("el dispensario", "le dispensaire", "El dispensario abre a las ocho.", "Le dispensaire ouvre à huit heures.", "🏥"),
            V("la fiebre", "la fièvre", "Tengo fiebre desde ayer.", "J'ai de la fièvre depuis hier.", "🌡️"),
            V("la tos", "la toux", "Tiene mucha tos por la noche.", "Il tousse beaucoup la nuit.", "😷"),
            V("el dolor de cabeza", "le mal de tête", "Tengo dolor de cabeza.", "J'ai mal à la tête.", "🤕"),
            V("la garganta", "la gorge", "Me duele la garganta.", "J'ai mal à la gorge.", "🗣️"),
            V("el estómago", "l'estomac, le ventre", "Me duele el estómago.", "J'ai mal au ventre.", "🫃🏾"),
            V("cansado / cansada", "fatigué / fatiguée", "Estoy muy cansado.", "Je suis très fatigué.", "🥱"),
            V("enfermo / enferma", "malade", "Mi hermana está enferma.", "Ma sœur est malade.", "🤒"),
            V("la receta", "l'ordonnance", "El médico me da una receta.", "Le médecin me donne une ordonnance.", "📄"),
            V("el medicamento", "le médicament", "Tome este medicamento después de comer.", "Prenez ce médicament après avoir mangé.", "💊"),
            V("el farmacéutico / la farmacéutica", "le pharmacien / la pharmacienne", "La farmacéutica explica la receta.", "La pharmacienne explique l'ordonnance.", "🧑🏾‍⚕️"),
            V("curarse", "guérir", "Se cura en pocos días.", "On guérit en quelques jours.", "🌿"),
            V("¡Que te mejores!", "Bon rétablissement !", "¡Que te mejores pronto, Ibrahim!", "Bon rétablissement, Ibrahim !", "💐"),
        ],
        "grammar": [
            G("Comprendre la règle",
              "Tener + nom (tengo fiebre), estar + adjectif (estoy cansado) et doler comme gustar (me duele la garganta, me duelen los pies) "
              "servent à décrire ce qu'on ressent.",
              [("Tengo fiebre y tos.", "J'ai de la fièvre et je tousse."),
               ("Estoy cansada y un poco mareada.", "Je suis fatiguée et j'ai un peu la tête qui tourne."),
               ("Me duelen los ojos.", "J'ai mal aux yeux.")]),
            G("Depuis quand ? DESDE HACE, DESDE, HACE… QUE",
              "Desde hace + durée : desde hace tres días (depuis trois jours). Desde + moment précis : desde el lunes, desde ayer. "
              "On peut aussi dire hace + durée + que + présent : hace tres días que tengo fiebre. Question : ¿Desde cuándo…?",
              [("¿Desde cuándo tiene usted fiebre? — Desde hace dos días.", "Depuis quand avez-vous de la fièvre ? — Depuis deux jours."),
               ("Me duele la cabeza desde el lunes.", "J'ai mal à la tête depuis lundi."),
               ("Hace una semana que tengo tos.", "Cela fait une semaine que je tousse.")]),
            G("Les consignes : l'impératif de USTED",
              "Pour vouvoyer, l'impératif prend la voyelle « opposée » : -ar → -e (tome, descanse), -er / -ir → -a (beba, vuelva, abra). "
              "Négatif : no + même forme (no coma, no salga). Les pronoms se collent à la forme affirmative (tómelo, cuídese) "
              "et se placent devant à la forme négative (no lo tome).",
              [("Descanse y beba mucha agua.", "Reposez-vous et buvez beaucoup d'eau."),
               ("Tome este medicamento dos veces al día.", "Prenez ce médicament deux fois par jour."),
               ("No salga de casa hasta el viernes.", "Ne sortez pas de chez vous avant vendredi."),
               ("Cuídese mucho.", "Prenez bien soin de vous.")]),
        ],
        "scenes": [
            S("Pedir una cita", "Prendre rendez-vous", "telefono",
              "Lundi matin. Ibrahim se sent mal ; il appelle le dispensaire de son quartier.",
              {"A": "Enfermera", "B": "Ibrahim"},
              [("A", "Dispensario de Cocody, buenos días.", "Dispensaire de Cocody, bonjour."),
               ("B", "Buenos días. Quisiera pedir una cita con el médico, por favor.", "Bonjour. Je voudrais prendre rendez-vous avec le médecin, s'il vous plaît."),
               ("A", "¿Qué le pasa?", "Qu'est-ce qui ne va pas ?"),
               ("B", "Tengo fiebre y me duele mucho la cabeza.", "J'ai de la fièvre et j'ai très mal à la tête."),
               ("A", "¿Desde cuándo tiene fiebre?", "Depuis quand avez-vous de la fièvre ?"),
               ("B", "Desde hace dos días.", "Depuis deux jours."),
               ("A", "Puede venir hoy a las diez. ¿Cómo se llama?", "Vous pouvez venir aujourd'hui à dix heures. Comment vous appelez-vous ?"),
               ("B", "Ibrahim Coulibaly. Muchas gracias, hasta luego.", "Ibrahim Coulibaly. Merci beaucoup, à tout à l'heure.")]),
            S("En la consulta", "En consultation", "dispensaire",
              "Au dispensaire, la docteure Koné examine Ibrahim.",
              {"A": "Doctora Koné", "B": "Ibrahim"},
              [("A", "Buenos días, señor Coulibaly. Siéntese, por favor. ¿Qué le duele?", "Bonjour, monsieur Coulibaly. Asseyez-vous, je vous prie. Où avez-vous mal ?"),
               ("B", "Me duelen la cabeza y la garganta, y estoy muy cansado.", "J'ai mal à la tête et à la gorge, et je suis très fatigué."),
               ("A", "Abra la boca, por favor… Sí, tiene la garganta roja.", "Ouvrez la bouche, s'il vous plaît… Oui, vous avez la gorge rouge."),
               ("B", "¿Es grave, doctora?", "C'est grave, docteure ?"),
               ("A", "No, no es grave. Le hago una receta.", "Non, ce n'est pas grave. Je vous fais une ordonnance."),
               ("B", "¿Qué tengo que hacer?", "Que dois-je faire ?"),
               ("A", "Descanse tres días, beba mucha agua y tome el medicamento como dice la receta.", "Reposez-vous trois jours, buvez beaucoup d'eau et prenez le médicament comme l'indique l'ordonnance."),
               ("B", "De acuerdo. Muchas gracias, doctora.", "D'accord. Merci beaucoup, docteure."),
               ("A", "De nada. ¡Que se mejore!", "Je vous en prie. Bon rétablissement !")]),
            S("En la farmacia", "À la pharmacie", "farmacia",
              "Avec son ordonnance, Ibrahim passe à la pharmacie du quartier.",
              {"A": "Farmacéutica", "B": "Ibrahim"},
              [("A", "Buenos días. ¿Qué desea?", "Bonjour. Que désirez-vous ?"),
               ("B", "Buenos días. Tengo esta receta de la doctora.", "Bonjour. J'ai cette ordonnance de la docteure."),
               ("A", "Muy bien. Aquí tiene el medicamento y un jarabe para la tos.", "Très bien. Voici le médicament et un sirop pour la toux."),
               ("B", "¿Cómo tengo que tomarlos?", "Comment dois-je les prendre ?"),
               ("A", "Como dice la receta: después de las comidas. Y no los tome con el estómago vacío.", "Comme l'indique l'ordonnance : après les repas. Et ne les prenez pas à jeun."),
               ("B", "Entendido. ¿Cuánto es?", "Compris. Combien ça coûte ?"),
               ("A", "Son cuatro mil quinientos francos.", "Ça fait quatre mille cinq cents francs."),
               ("B", "Aquí tiene. Gracias.", "Voici. Merci."),
               ("A", "A usted. ¡Que se mejore pronto!", "Merci à vous. Bon rétablissement !")]),
        ],
        "phrases_add": [
            ("Quisiera pedir una cita con el médico.", "Je voudrais prendre rendez-vous avec le médecin."),
            ("Me duele la cabeza.", "J'ai mal à la tête."),
            ("Tengo fiebre desde hace dos días.", "J'ai de la fièvre depuis deux jours."),
            ("¿Qué le pasa?", "Qu'est-ce qui ne va pas ?"),
            ("Descanse y beba mucha agua.", "Reposez-vous et buvez beaucoup d'eau."),
            ("¿Dónde está la farmacia más cercana?", "Où est la pharmacie la plus proche ?"),
            ("¡Que te mejores!", "Bon rétablissement !"),
        ],
        "reading_title": "Una semana difícil",
        "reading": [
            ("La semana pasada, Ibrahim estaba enfermo.", "La semaine dernière, Ibrahim était malade."),
            ("Tenía fiebre, tos y le dolía mucho la garganta.", "Il avait de la fièvre, il toussait et il avait très mal à la gorge."),
            ("Fue al dispensario y la doctora le hizo una receta.", "Il est allé au dispensaire et la docteure lui a fait une ordonnance."),
            ("En la farmacia, la farmacéutica le explicó cómo tomar el medicamento.", "À la pharmacie, la pharmacienne lui a expliqué comment prendre le médicament."),
            ("Ibrahim descansó tres días y bebió mucha agua.", "Ibrahim s'est reposé trois jours et a bu beaucoup d'eau."),
            ("Ahora está curado y vuelve al trabajo con energía.", "Maintenant, il est guéri et retourne au travail plein d'énergie."),
        ],
        "questions": "1) ¿Qué síntomas tenía Ibrahim? 2) ¿Adónde fue? 3) ¿Qué le explicó la farmacéutica? 4) ¿Cómo está ahora?",
        "homework": [
            H("Écris un dialogue chez le médecin (8 répliques) : symptômes, depuis quand, consignes.",
              "— ¿Qué le pasa? — Me duele el estómago. — ¿Desde cuándo? — Desde hace un día. — ¿Tiene fiebre? — No. — Descanse y beba agua. — Gracias, doctor.",
              ["me duele", "desde hace", "descanse"]),
            H("Donne 5 conseils de santé à un ami en vouvoyant (impératif de usted).",
              "Duerma ocho horas. Beba mucha agua. Coma fruta. Haga deporte. No trabaje demasiado.", ["beba", "coma", "duerma", "no"]),
            H("Raconte en 5 phrases une fois où tu as été malade (passé).",
              "El año pasado estuve enfermo. Tenía fiebre y me dolía la cabeza. Fui al médico. Descansé una semana. Después me curé.",
              ["tenía", "me dolía", "fui", "descansé"]),
        ],
        "quiz_add": [
            Qx("« J'ai mal aux yeux » :", "Me duelen los ojos.", ["Me duele los ojos.", "Tengo duelen los ojos.", "Yo duelo los ojos."], "Doler comme gustar : nom pluriel → duelen."),
            Qx("« Depuis trois jours » :", "desde hace tres días", ["hace desde tres días", "por tres días hace", "desde tres días hace"], "Desde hace + durée."),
            Qx("Le médecin (usted) : « Buvez de l'eau » :", "Beba agua.", ["Bebe agua.", "Bebed agua.", "Bebas agua."], "-er → -a à l'impératif de usted."),
            Qx("« Ne sortez pas » (usted) :", "No salga.", ["No sale.", "No salgas.", "No salir usted."], "Négatif de usted : no + salga."),
            Qx("« Je suis fatigué » :", "Estoy cansado.", ["Soy cansado.", "Tengo cansado.", "Me duele cansado."], "État passager : estar."),
        ],
        "manual_quiz": [
            ("Comment dit-on « j'ai mal à la gorge » ?", "Me duele la garganta.", ["Tengo duele la garganta.", "Me duelen la garganta.", "Estoy garganta."], "Doler + nom singulier : duele."),
            ("Quelle structure signifie « depuis deux jours » ?", "desde hace dos días", ["hace desde dos días", "por dos días", "durante hace dos días"], "Desde hace + durée."),
            ("Quel est l'impératif de usted de « descansar » ?", "descanse", ["descansa", "descansad", "descansas"], "-ar → -e."),
            ("Quel verbe pour un état passager ?", "estar", ["ser", "tener", "doler"], "Estoy cansado, estoy enfermo."),
        ],
        "selfcheck": ["Je peux décrire ce que je ressens", "Je peux dire depuis quand je suis malade", "Je comprends les consignes du médecin"],
    },
    # ======================================================================= Leçon 19
    {
        "id": "m2-es-19", "level": "B2", "number": 19, "emoji": "💼", "art": None,
        "title": "Le travail : métiers, CV et entretien d'embauche",
        "titleTr": "Le travail : métiers, CV et entretien d'embauche",
        "objective": "Parler de son parcours, présenter ses compétences et réussir un entretien d'embauche.",
        "intro": "Aïcha, jeune diplômée en gestion, répond à une offre d'emploi d'une entreprise de cacao à Abidjan. "
                 "Elle prépare son CV, puis passe l'entretien avec le directeur des ressources humaines. Vous apprenez à parler "
                 "de votre expérience (llevar + durée, he trabajado), de vos qualités et de vos objectifs professionnels.",
        "rule": [
            "Pour parler d'une activité qui dure encore, l'espagnol emploie llevar + durée + gérondif : llevo dos años trabajando aquí "
            "(je travaille ici depuis deux ans). On peut aussi dire trabajo aquí desde hace dos años.",
            "Pour faire le bilan de son expérience jusqu'à aujourd'hui, on emploie le passé composé (pretérito perfecto) : "
            "he trabajado, he aprendido, he dirigido un equipo. Pour une période terminée et datée, le passé simple : "
            "en 2022 trabajé en un banco.",
            "Pour présenter ses qualités et ses projets : se me da bien + nom ou infinitif (je suis doué pour), soy capaz de + infinitif, "
            "me gustaría + infinitif, mi objetivo es + infinitif.",
        ],
        "memo": [
            "llevar + durée + gérondif : llevo un año estudiando.",
            "Bilan : he trabajado, he aprendido (passé composé).",
            "Période datée et finie : trabajé, estudié (passé simple).",
            "se me da bien… ; soy capaz de… ; me gustaría…",
            "Métiers au féminin : el contable → la contable, el ingeniero → la ingeniera.",
        ],
        "vocab": [
            V("la oferta de empleo", "l'offre d'emploi", "He visto una oferta de empleo en internet.", "J'ai vu une offre d'emploi sur internet.", "📰"),
            V("el currículum", "le CV", "Envío mi currículum por correo electrónico.", "J'envoie mon CV par e-mail.", "📄"),
            V("la entrevista de trabajo", "l'entretien d'embauche", "Mañana tengo una entrevista de trabajo.", "Demain, j'ai un entretien d'embauche.", "🤝"),
            V("el puesto", "le poste", "Me interesa el puesto de contable.", "Le poste de comptable m'intéresse.", "🪑"),
            V("la empresa", "l'entreprise", "Es una empresa de exportación de cacao.", "C'est une entreprise d'exportation de cacao.", "🏢"),
            V("el sueldo", "le salaire", "El sueldo depende de la experiencia.", "Le salaire dépend de l'expérience.", "💵"),
            V("la experiencia", "l'expérience", "Tengo tres años de experiencia.", "J'ai trois ans d'expérience.", "📈"),
            V("las prácticas", "le stage", "Hice prácticas en un banco.", "J'ai fait un stage dans une banque.", "🎓"),
            V("el equipo", "l'équipe", "Me gusta trabajar en equipo.", "J'aime travailler en équipe.", "👥"),
            V("contratar", "embaucher", "La empresa va a contratar a dos personas.", "L'entreprise va embaucher deux personnes.", "✍🏾"),
            V("el contable / la contable", "le comptable / la comptable", "Mi madre es contable.", "Ma mère est comptable.", "🧮"),
            V("el ingeniero / la ingeniera", "l'ingénieur / l'ingénieure", "Mi hermana es ingeniera agrónoma.", "Ma sœur est ingénieure agronome.", "👷🏾‍♀️"),
            V("responsable", "responsable, sérieux", "Soy una persona responsable y puntual.", "Je suis une personne sérieuse et ponctuelle.", "✅"),
            V("el objetivo", "l'objectif", "Mi objetivo es dirigir un equipo.", "Mon objectif est de diriger une équipe.", "🎯"),
        ],
        "grammar": [
            G("Comprendre la règle",
              "Llevar + durée + gérondif décrit une activité qui dure encore : llevo dos años trabajando aquí. "
              "Le passé composé fait le bilan (he trabajado en tres empresas) ; le passé simple raconte une période finie et datée (en 2022 trabajé en un banco).",
              [("Llevo dos años trabajando en esta empresa.", "Je travaille dans cette entreprise depuis deux ans."),
               ("He trabajado en tres empresas diferentes.", "J'ai travaillé dans trois entreprises différentes."),
               ("En 2022 hice prácticas en un banco de Abiyán.", "En 2022, j'ai fait un stage dans une banque d'Abidjan.")]),
            G("Présenter ses qualités : SE ME DA BIEN, SOY CAPAZ DE",
              "Se me da bien + nom ou infinitif = je suis doué(e) pour ; se me dan bien + nom pluriel. "
              "Soy capaz de + infinitif = je suis capable de. Pour un défaut, on le présente positivement : a veces soy demasiado perfeccionista.",
              [("Se me dan bien los números.", "Je suis doué pour les chiffres."),
               ("Se me da bien trabajar en equipo.", "Je suis doué pour le travail en équipe."),
               ("Soy capaz de organizar un proyecto de principio a fin.", "Je suis capable d'organiser un projet du début à la fin.")]),
            G("Les métiers au féminin",
              "Les noms en -o font -a : el ingeniero → la ingeniera, el abogado → la abogada. Ceux en -or ajoutent -a : el director → la directora. "
              "Les noms en -e ou -ista ne changent que l'article : el / la contable, el / la periodista, el / la estudiante. "
              "Après ser, pas d'article devant un métier : soy contable.",
              [("Mi madre es directora de una escuela.", "Ma mère est directrice d'une école."),
               ("Aïcha quiere ser contable.", "Aïcha veut être comptable."),
               ("La periodista entrevista a la ingeniera.", "La journaliste interviewe l'ingénieure.")]),
        ],
        "scenes": [
            S("La oferta de empleo", "L'offre d'emploi", "bureau",
              "Aïcha montre à son amie Nadia une offre d'emploi trouvée sur internet.",
              {"A": "Nadia", "B": "Aïcha"},
              [("B", "Mira, Nadia: una empresa de cacao busca una contable.", "Regarde, Nadia : une entreprise de cacao cherche une comptable."),
               ("A", "¡Es perfecto para ti! ¿Qué piden?", "C'est parfait pour toi ! Qu'est-ce qu'ils demandent ?"),
               ("B", "Un título en gestión, dos años de experiencia y nivel intermedio de español.", "Un diplôme en gestion, deux ans d'expérience et un niveau intermédiaire en espagnol."),
               ("A", "Tú llevas dos años trabajando en el banco, ¿no?", "Tu travailles à la banque depuis deux ans, non ?"),
               ("B", "Sí, y he hecho cursos de español todo el año.", "Oui, et j'ai suivi des cours d'espagnol toute l'année."),
               ("A", "Entonces, ¡envía tu currículum hoy mismo!", "Alors, envoie ton CV dès aujourd'hui !"),
               ("B", "Me da un poco de miedo la entrevista.", "L'entretien me fait un peu peur."),
               ("A", "Vamos a practicar juntas. ¡Vas a conseguirlo!", "On va s'entraîner ensemble. Tu vas y arriver !")]),
            S("La entrevista de trabajo", "L'entretien d'embauche", "entrevista",
              "Une semaine plus tard, Aïcha passe l'entretien avec monsieur Kouamé, directeur des ressources humaines.",
              {"A": "Señor Kouamé", "B": "Aïcha"},
              [("A", "Buenos días, señorita Diallo. Siéntese. Hábleme un poco de usted.", "Bonjour, mademoiselle Diallo. Asseyez-vous. Parlez-moi un peu de vous."),
               ("B", "Tengo un título en gestión y llevo dos años trabajando como contable en un banco.", "J'ai un diplôme en gestion et je travaille comme comptable dans une banque depuis deux ans."),
               ("A", "¿Por qué le interesa este puesto?", "Pourquoi ce poste vous intéresse-t-il ?"),
               ("B", "Porque me gustaría trabajar en el sector del cacao, que es muy importante para el país.", "Parce que j'aimerais travailler dans le secteur du cacao, qui est très important pour le pays."),
               ("A", "¿Cuáles son sus puntos fuertes?", "Quels sont vos points forts ?"),
               ("B", "Se me dan bien los números, soy responsable y me gusta trabajar en equipo.", "Je suis douée pour les chiffres, je suis sérieuse et j'aime travailler en équipe."),
               ("A", "¿Y cuál es su objetivo dentro de cinco años?", "Et quel est votre objectif dans cinq ans ?"),
               ("B", "Me gustaría dirigir el departamento de contabilidad.", "J'aimerais diriger le service comptabilité."),
               ("A", "Muy bien. Le llamaremos la próxima semana.", "Très bien. Nous vous appellerons la semaine prochaine."),
               ("B", "Muchas gracias por su tiempo.", "Merci beaucoup pour votre temps.")]),
        ],
        "phrases_add": [
            ("Me interesa el puesto de contable.", "Le poste de comptable m'intéresse."),
            ("Llevo dos años trabajando en un banco.", "Je travaille dans une banque depuis deux ans."),
            ("He trabajado en equipo muchas veces.", "J'ai souvent travaillé en équipe."),
            ("Se me dan bien los números.", "Je suis doué pour les chiffres."),
            ("Soy una persona responsable y puntual.", "Je suis une personne sérieuse et ponctuelle."),
            ("Me gustaría dirigir un equipo.", "J'aimerais diriger une équipe."),
            ("Muchas gracias por su tiempo.", "Merci beaucoup pour votre temps."),
        ],
        "reading_title": "Del banco al cacao",
        "reading": [
            ("Aïcha Diallo tiene veinticinco años y es contable.", "Aïcha Diallo a vingt-cinq ans et elle est comptable."),
            ("Estudió gestión en la universidad de Abiyán y después hizo prácticas en un banco.", "Elle a étudié la gestion à l'université d'Abidjan puis a fait un stage dans une banque."),
            ("Lleva dos años trabajando allí y ha aprendido mucho.", "Elle y travaille depuis deux ans et elle a beaucoup appris."),
            ("Este mes ha enviado su currículum a una empresa de exportación de cacao.", "Ce mois-ci, elle a envoyé son CV à une entreprise d'exportation de cacao."),
            ("En la entrevista habló de su experiencia y de sus objetivos.", "Pendant l'entretien, elle a parlé de son expérience et de ses objectifs."),
            ("La empresa la ha contratado y empieza el lunes.", "L'entreprise l'a embauchée et elle commence lundi."),
        ],
        "questions": "1) ¿Qué estudió Aïcha? 2) ¿Cuánto tiempo lleva en el banco? 3) ¿A qué empresa envió su currículum? 4) ¿Cuándo empieza?",
        "homework": [
            H("Rédige ton CV en espagnol : datos personales, formación, experiencia, idiomas, cualidades.",
              "Datos personales: Koffi Yao, 22 años, Abiyán. Formación: título en informática. Experiencia: prácticas en una empresa de telefonía (2024). Idiomas: francés, inglés, español. Cualidades: responsable, creativo.",
              ["formación", "experiencia", "idiomas"]),
            H("Écris une lettre de motivation courte (6 phrases) pour un poste de ton choix.",
              "Estimado señor: me interesa el puesto de técnico informático. Llevo un año trabajando en una empresa de telefonía. He aprendido a resolver problemas. Se me da bien trabajar en equipo. Me gustaría crecer en su empresa. Atentamente, Koffi Yao.",
              ["me interesa", "llevo", "he aprendido", "me gustaría"]),
            H("Prépare tes réponses à trois questions d'entretien : ¿Por qué le interesa el puesto? ¿Cuáles son sus puntos fuertes? ¿Dónde se ve en cinco años?",
              "Me interesa porque me gusta la tecnología. Mis puntos fuertes son la paciencia y el trabajo en equipo. En cinco años me gustaría dirigir un equipo.",
              ["me interesa", "puntos fuertes", "me gustaría"]),
        ],
        "quiz_add": [
            Qx("« Je travaille ici depuis deux ans » :", "Llevo dos años trabajando aquí.", ["Llevo dos años trabajar aquí.", "Tengo dos años trabajando aquí.", "Hace dos años trabajo desde aquí."], "Llevar + durée + gérondif."),
            Qx("« J'ai travaillé dans trois entreprises » (bilan) :", "He trabajado en tres empresas.", ["Trabajaba en tres empresas.", "He trabajo en tres empresas.", "Hube trabajado en tres empresas."], "Passé composé : haber + participe."),
            Qx("« Je suis douée pour les chiffres » :", "Se me dan bien los números.", ["Se me da bien los números.", "Me doy bien los números.", "Soy bien los números."], "Nom pluriel : se me dan bien."),
            Qx("Le féminin de el director :", "la directora", ["la directriz", "la directore", "la director"], "-or → -ora."),
            Qx("« Elle est comptable » :", "Es contable.", ["Es una contable de.", "Está contable.", "Es la contable de profesión."], "Pas d'article devant le métier après ser."),
        ],
        "manual_quiz": [
            ("Quelle structure exprime une activité qui dure encore ?", "llevar + durée + gérondif", ["ir a + infinitif", "acabar de + infinitif", "haber + participe"], "Llevo un año trabajando aquí."),
            ("Quel temps pour faire le bilan de son expérience ?", "le passé composé", ["l'imparfait", "le futur", "le conditionnel"], "He trabajado, he aprendido."),
            ("Le féminin de el ingeniero :", "la ingeniera", ["la ingeniero", "la ingenieresa", "la ingenieriza"], "-o → -a."),
            ("Quelle phrase présente un objectif ?", "Me gustaría dirigir un equipo.", ["Llevo un año aquí.", "He hecho prácticas.", "Se me dan bien los números."], "Me gustaría + infinitif."),
        ],
        "selfcheck": ["Je peux présenter mon parcours", "Je peux parler de mes qualités", "Je peux répondre aux questions d'un entretien"],
    },
    # ======================================================================= Leçon 20
    {
        "id": "m2-es-20", "level": "C1", "number": 20, "emoji": "🌍", "art": None,
        "title": "L'environnement et la ville durable",
        "titleTr": "L'environnement et la ville durable",
        "objective": "Débattre d'un problème environnemental : en expliquer les causes et les conséquences, proposer des solutions.",
        "intro": "Le conseil des jeunes de la commune organise un débat sur la propreté du quartier et le recyclage des déchets plastiques. "
                 "Yao et Fanta défendent leurs idées. Vous apprenez à exprimer la cause et la conséquence, la voix passive et le se impersonnel, "
                 "et les hypothèses avec si.",
        "rule": [
            "Pour expliquer une cause, on emploie porque, ya que, puesto que (+ verbe) ou debido a, a causa de (+ nom). "
            "Pour une conséquence : así que, por eso, por lo tanto, de modo que.",
            "Quand on ne précise pas qui fait l'action, on emploie se + verbe à la 3e personne : se recicla el plástico, se reciclan las botellas "
            "(le verbe s'accorde avec la chose). La voix passive avec ser + participe accordé existe aussi, surtout à l'écrit : "
            "el parque fue construido en 2020.",
            "Pour une hypothèse réalisable : si + présent, futur (si reciclamos, habrá menos basura). Pour une hypothèse irréelle dans le présent : "
            "si + imparfait du subjonctif, conditionnel (si recicláramos más, la ciudad estaría más limpia).",
        ],
        "memo": [
            "Cause : porque, ya que + verbe ; debido a, a causa de + nom.",
            "Conséquence : así que, por eso, por lo tanto.",
            "Se impersonnel : se recicla / se reciclan (accord avec la chose).",
            "Passif : ser + participe accordé (fue construida).",
            "Si + présent → futur ; si + imparfait du subjonctif → conditionnel.",
        ],
        "vocab": [
            V("el medio ambiente", "l'environnement", "Debemos proteger el medio ambiente.", "Nous devons protéger l'environnement.", "🌍"),
            V("la basura", "les ordures, les déchets", "Hay mucha basura en la calle.", "Il y a beaucoup d'ordures dans la rue.", "🗑️"),
            V("reciclar", "recycler", "En mi barrio se recicla el plástico.", "Dans mon quartier, on recycle le plastique.", "♻️"),
            V("el plástico", "le plastique", "Las bolsas de plástico contaminan los ríos.", "Les sacs plastiques polluent les rivières.", "🛍️"),
            V("contaminar", "polluer", "Los coches viejos contaminan mucho.", "Les vieilles voitures polluent beaucoup.", "🏭"),
            V("la contaminación", "la pollution", "La contaminación del aire es un problema.", "La pollution de l'air est un problème.", "🌫️"),
            V("el cambio climático", "le changement climatique", "El cambio climático afecta a la agricultura.", "Le changement climatique touche l'agriculture.", "🌡️"),
            V("la sequía", "la sécheresse", "La sequía destruye las cosechas.", "La sécheresse détruit les récoltes.", "🏜️"),
            V("las inundaciones", "les inondations", "Las inundaciones son frecuentes en la temporada de lluvias.", "Les inondations sont fréquentes à la saison des pluies.", "🌊"),
            V("plantar árboles", "planter des arbres", "Los jóvenes plantan árboles en la escuela.", "Les jeunes plantent des arbres à l'école.", "🌳"),
            V("la energía solar", "l'énergie solaire", "La energía solar es limpia y barata.", "L'énergie solaire est propre et bon marché.", "☀️"),
            V("ahorrar agua", "économiser l'eau", "Hay que ahorrar agua en casa.", "Il faut économiser l'eau à la maison.", "🚰"),
            V("sostenible", "durable", "Queremos una ciudad sostenible.", "Nous voulons une ville durable.", "🌱"),
            V("la conciencia", "la prise de conscience", "Hace falta más conciencia ecológica.", "Il faut une plus grande prise de conscience écologique.", "💡"),
        ],
        "grammar": [
            G("Comprendre la règle",
              "Cause : porque, ya que, puesto que + verbe ; debido a, a causa de + nom. Conséquence : así que, por eso, por lo tanto. "
              "Ces connecteurs structurent un argument.",
              [("Las calles se inundan porque los canales están llenos de basura.", "Les rues sont inondées parce que les caniveaux sont pleins d'ordures."),
               ("Debido a la sequía, el precio del maíz ha subido.", "À cause de la sécheresse, le prix du maïs a augmenté."),
               ("Usamos muchas bolsas de plástico; por eso hay que reciclar.", "Nous utilisons beaucoup de sacs plastiques ; c'est pourquoi il faut recycler.")]),
            G("Le SE impersonnel et la voix passive",
              "Se + verbe à la 3e personne présente une action sans dire qui la fait ; le verbe s'accorde avec la chose : se recicla el papel, "
              "se reciclan las botellas. La voix passive se forme avec ser + participe accordé, et l'agent est introduit par por : "
              "el parque fue construido por el ayuntamiento.",
              [("En esta escuela se separa la basura.", "Dans cette école, on trie les déchets."),
               ("Se venden botellas de vidrio reutilizables.", "On vend des bouteilles en verre réutilisables."),
               ("El nuevo parque fue inaugurado por la alcaldesa.", "Le nouveau parc a été inauguré par la maire.")]),
            G("Les hypothèses : SI + présent / SI + imparfait du subjonctif",
              "Hypothèse réalisable : si + présent de l'indicatif, futur ou présent (si reciclamos, habrá menos basura). "
              "Hypothèse irréelle ou peu probable : si + imparfait du subjonctif, conditionnel (si todos recicláramos, la ciudad estaría limpia). "
              "Imparfait du subjonctif : 3e pers. pluriel du passé simple − ron + ra : reciclaron → reciclara, tuvieron → tuviera. "
              "On ne met jamais de futur ni de conditionnel juste après si.",
              [("Si plantamos árboles, tendremos más sombra.", "Si nous plantons des arbres, nous aurons plus d'ombre."),
               ("Si todos recicláramos, habría menos basura en las calles.", "Si tout le monde recyclait, il y aurait moins d'ordures dans les rues."),
               ("Si tuviera dinero, instalaría paneles solares.", "Si j'avais de l'argent, j'installerais des panneaux solaires.")]),
        ],
        "scenes": [
            S("El debate del consejo juvenil", "Le débat du conseil des jeunes", "reciclaje",
              "Sur la place de la commune, le conseil des jeunes débat de la propreté du quartier.",
              {"A": "Yao", "B": "Fanta"},
              [("A", "El problema principal es la basura: las calles se inundan cada vez que llueve.", "Le problème principal, ce sont les ordures : les rues sont inondées chaque fois qu'il pleut."),
               ("B", "Estoy de acuerdo. Ya que los canales están llenos de plástico, el agua no puede pasar.", "Je suis d'accord. Comme les caniveaux sont pleins de plastique, l'eau ne peut pas passer."),
               ("A", "Por eso propongo una jornada de limpieza cada mes.", "C'est pourquoi je propose une journée de nettoyage chaque mois."),
               ("B", "Es una buena idea, pero no basta. Hay que reciclar el plástico.", "C'est une bonne idée, mais ça ne suffit pas. Il faut recycler le plastique."),
               ("A", "¿Y cómo se recicla el plástico aquí?", "Et comment recycle-t-on le plastique ici ?"),
               ("B", "Hay una cooperativa de mujeres que lo transforma en ladrillos.", "Il y a une coopérative de femmes qui le transforme en briques."),
               ("A", "Si todos separáramos la basura en casa, ellas tendrían más material.", "Si tout le monde triait ses déchets à la maison, elles auraient plus de matière."),
               ("B", "Exactamente. Si empezamos este mes, el barrio estará más limpio antes de las lluvias.", "Exactement. Si nous commençons ce mois-ci, le quartier sera plus propre avant les pluies.")]),
            S("En el campo", "Au champ", "campo",
              "Fanta rend visite à son grand-père, cultivateur près de Bouaflé, qui lui parle du climat.",
              {"A": "Abuelo", "B": "Fanta"},
              [("A", "Antes, las lluvias llegaban siempre en marzo. Ahora nunca se sabe.", "Avant, les pluies arrivaient toujours en mars. Maintenant, on ne sait jamais."),
               ("B", "Es debido al cambio climático, abuelo.", "C'est à cause du changement climatique, grand-père."),
               ("A", "El año pasado, la sequía destruyó la mitad de mi maíz.", "L'année dernière, la sécheresse a détruit la moitié de mon maïs."),
               ("B", "En la escuela aprendimos que plantar árboles protege la tierra.", "À l'école, nous avons appris que planter des arbres protège la terre."),
               ("A", "Es verdad. Los árboles dan sombra y guardan el agua.", "C'est vrai. Les arbres donnent de l'ombre et retiennent l'eau."),
               ("B", "Si plantamos árboles alrededor del campo, el suelo estará más húmedo.", "Si nous plantons des arbres autour du champ, le sol sera plus humide."),
               ("A", "Entonces, ¡manos a la obra! Mañana plantamos los primeros.", "Alors, au travail ! Demain, nous plantons les premiers."),
               ("B", "¡Trato hecho, abuelo!", "Marché conclu, grand-père !")]),
        ],
        "phrases_add": [
            ("Debemos proteger el medio ambiente.", "Nous devons protéger l'environnement."),
            ("Las calles se inundan porque los canales están llenos de basura.", "Les rues sont inondées parce que les caniveaux sont pleins d'ordures."),
            ("Por eso hay que reciclar el plástico.", "C'est pourquoi il faut recycler le plastique."),
            ("En mi barrio se separa la basura.", "Dans mon quartier, on trie les déchets."),
            ("Si todos recicláramos, habría menos basura.", "Si tout le monde recyclait, il y aurait moins d'ordures."),
            ("Estoy de acuerdo, pero no basta.", "Je suis d'accord, mais ça ne suffit pas."),
            ("Propongo plantar árboles en la escuela.", "Je propose de planter des arbres à l'école."),
        ],
        "reading_title": "Ladrillos de plástico",
        "reading": [
            ("En muchas ciudades africanas, el plástico es un problema grave.", "Dans beaucoup de villes africaines, le plastique est un problème grave."),
            ("Las bolsas y las botellas bloquean los canales y provocan inundaciones.", "Les sacs et les bouteilles bouchent les caniveaux et provoquent des inondations."),
            ("En Abiyán, una empresa transforma el plástico reciclado en ladrillos.", "À Abidjan, une entreprise transforme le plastique recyclé en briques."),
            ("Con estos ladrillos se construyen aulas para las escuelas.", "Avec ces briques, on construit des salles de classe pour les écoles."),
            ("Así, la ciudad está más limpia y muchas mujeres tienen trabajo recogiendo plástico.", "Ainsi, la ville est plus propre et beaucoup de femmes ont un travail en collectant le plastique."),
            ("Si este modelo se aplicara en todo el país, los beneficios serían enormes.", "Si ce modèle était appliqué dans tout le pays, les bénéfices seraient énormes."),
        ],
        "questions": "1) ¿Qué problemas causa el plástico? 2) ¿Qué hace la empresa de Abiyán? 3) ¿Qué se construye con los ladrillos? 4) ¿Qué pasaría si el modelo se aplicara en todo el país?",
        "homework": [
            H("Écris un court discours (8 phrases) pour convaincre ton quartier de trier ses déchets : problème, causes, conséquences, solutions.",
              "Queridos vecinos: nuestro barrio tiene un problema de basura. Los canales se bloquean porque tiramos plástico. Por eso, cada vez que llueve, las calles se inundan. Propongo separar la basura en casa. Si todos lo hacemos, la cooperativa podrá reciclar más. Así, el barrio estará más limpio. ¡Contamos con ustedes!",
              ["porque", "por eso", "si", "propongo"]),
            H("Écris 5 phrases avec si + imparfait du subjonctif + conditionnel sur ce que tu ferais pour l'environnement.",
              "Si fuera alcalde, plantaría árboles en todas las calles. Si tuviera dinero, compraría paneles solares. Si todos recicláramos, habría menos basura.",
              ["si", "fuera", "tuviera", "habría"]),
            H("Décris ce qu'on fait (se impersonnel) dans ton école ou ta ville pour l'environnement.",
              "En mi escuela se separa la basura, se plantan árboles y se ahorra agua. En mi ciudad se recicla el plástico.",
              ["se separa", "se plantan", "se recicla"]),
        ],
        "quiz_add": [
            Qx("« On recycle les bouteilles » :", "Se reciclan las botellas.", ["Se recicla las botellas.", "Se reciclamos las botellas.", "Reciclan se las botellas."], "Le verbe s'accorde avec la chose : se reciclan."),
            Qx("« À cause de la sécheresse » :", "debido a la sequía", ["porque la sequía", "por eso la sequía", "así que la sequía"], "Debido a + nom."),
            Qx("« Si tout le monde recyclait, il y aurait moins d'ordures » :", "Si todos recicláramos, habría menos basura.", ["Si todos reciclaríamos, habría menos basura.", "Si todos reciclamos, habría menos basura.", "Si todos reciclarán, hubiera menos basura."],
               "Hypothèse irréelle : si + imparfait du subjonctif, conditionnel."),
            Qx("Connecteur de conséquence :", "por lo tanto", ["ya que", "debido a", "puesto que"], "Ya que / puesto que / debido a expriment la cause."),
            Qx("« Le parc a été inauguré par la maire » :", "El parque fue inaugurado por la alcaldesa.", ["El parque fue inaugurada por la alcaldesa.", "El parque estuvo inaugurado de la alcaldesa.", "El parque se fue inaugurado por la alcaldesa."],
               "Passif : ser + participe accordé avec le sujet (parque, masculin)."),
        ],
        "manual_quiz": [
            ("Quel connecteur introduit une cause suivie d'un verbe ?", "ya que", ["así que", "por eso", "por lo tanto"], "Ya que + verbe = puisque."),
            ("« On vend des fruits » :", "Se venden frutas.", ["Se vende frutas.", "Se venden de frutas.", "Venden se frutas."], "Se + verbe accordé avec la chose."),
            ("Après si (hypothèse irréelle), on emploie :", "l'imparfait du subjonctif", ["le conditionnel", "le futur", "le présent du subjonctif"], "Si tuviera… jamais si tendría."),
            ("Imparfait du subjonctif de tener (yo) :", "tuviera", ["teniera", "tendría", "tuvo"], "tuvieron → tuviera."),
        ],
        "selfcheck": ["Je peux expliquer les causes et les conséquences d'un problème", "Je peux employer se impersonnel et la voix passive", "Je peux formuler des hypothèses avec si"],
    },
]


def manual_text(d):
    """Texte de manuel au format du guide MODEL 2 (lu par ManualParser)."""
    n = d["number"]
    p1, p2, p3 = 3 * n, 3 * n + 1, 3 * n + 2
    sep = "━━━━━━━━━━━━━━━━━━━━"
    out = [f"PAGE {p1}", f"{d['level']} · LEÇON {n}", "", d["title"], "",
           f"Objectif : {d['objective']}", "",
           "À retenir Lis les règles, observe les exemples et repère les formes qui reviennent dans les dialogues et dans la lecture.", "",
           "1. Comprendre la règle", ""]
    for para in d["rule"]:
        out += [para, ""]
    out += ["2. Les règles à mémoriser", ""]
    out += [f"• {m}" for m in d["memo"]] + [""]
    out += ["3. Exemples commentés", ""]
    ex = [e for g in d["grammar"][1:] for e in g["examples"]][:6]
    for e in ex:
        out += [e["text"], e["translation"]]
    out += ["", sep, "", f"PAGE {p2}", f"LEÇON {n} · VOCABULAIRE ET LECTURE", "", "4. Vocabulaire essentiel", "",
            "Espagnol" + " " * 40 + "Français", ""]
    for v in d["vocab"][:10]:
        out.append(v["word"] + " " * max(4, 46 - len(v["word"])) + v["translation"])
    out += ["", "5. Lecture guidée", "", d["reading_title"], " ".join(t for t, _ in d["reading"]), "",
            "Traduction française", "", " ".join(f for _, f in d["reading"]), "",
            "Questions de compréhension", "", f"Réponds en espagnol si possible : {d['questions']}", "",
            sep, "", f"PAGE {p3}", f"LEÇON {n} · ENTRAÎNEMENT", "", "6. Quiz de vérification", "",
            "Choisis une seule réponse pour chaque question.", ""]
    for i, (q, c, w, _) in enumerate(d["manual_quiz"], 1):
        opts = [c] + w
        out.append(f"{i}. {q} " + " ".join(f"{'ABCD'[k]}. {o}" for k, o in enumerate(opts)))
    out += ["", "7. Corrigé expliqué", ""]
    for i, (_, c, _, e) in enumerate(d["manual_quiz"], 1):
        out.append(f"{i}. Réponse A. {e}")
    out += ["", "8. Travail personnel", "", d["homework"][0]["prompt"], "", "Auto-évaluation", "",
            " ".join(f"{s} : □ Oui □ Pas encore" for s in d["selfcheck"])]
    return "\n".join(out)
