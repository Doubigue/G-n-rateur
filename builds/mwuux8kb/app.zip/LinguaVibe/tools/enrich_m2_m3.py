#!/usr/bin/env python3
"""Fusionne l'enrichissement (content_m2.py, content_m3.py) dans les JSON des MODEL 2 et 3.

Usage : python3 tools/enrich_m2_m3.py
- ajoute vocabulaire (avec exemples), grammaire, dialogues illustrés (« scenes »), phrases, devoirs, quiz ;
- reconstruit « dialogue » (liste à plat) à partir des scènes pour la lecture continue et l'export PDF ;
- calcule la prononciation figurée (tools/pron_es.py) partout où elle manque.
À lancer une seule fois sur les JSON d'origine (option : dossier source en argument, sortie dans assets/courses).
"""
import copy
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from pron_es import pron  # noqa: E402
from content_m2 import M2, FIX  # noqa: E402
from content_m3 import M3  # noqa: E402

ASSETS = HERE.parent / "app" / "src" / "main" / "assets" / "courses"


def es_city(t):
    return re.sub(r"\bAbidjan\b", "Abiyán", t)


def P(t):
    return pron(t) if t else ""


def enrich(lesson, data, fix):
    for k in ("title", "titleTr", "intro"):
        if k in data:
            lesson[k] = data[k]
    # --- vocabulaire
    vocab = lesson.get("vocab") or []
    for v in vocab:
        f = fix.get(v["word"])
        if f:
            v["translation"], v["example"], v["exampleTr"] = f
        if v["word"] in data.get("vocab_fix", {}):
            v["translation"] = data["vocab_fix"][v["word"]]
    seen = {v["word"].lower() for v in vocab}
    for v in data.get("vocab", []):
        if v["word"].lower() not in seen:
            vocab.append(copy.deepcopy(v))
            seen.add(v["word"].lower())
    for v in vocab:
        v["example"] = es_city(v.get("example", ""))
        v["pron"] = v.get("pron") or P(v["word"])
        v["examplePron"] = v.get("examplePron") or P(v.get("example", ""))
    lesson["vocab"] = vocab
    # --- grammaire
    grammar = [g for g in (lesson.get("grammar") or [])]
    grammar += copy.deepcopy(data.get("grammar", []))
    for g in grammar:
        for e in g.get("examples", []):
            e["text"] = es_city(e["text"])
            e["pron"] = e.get("pron") or P(e["text"])
    lesson["grammar"] = grammar
    # --- dialogues illustrés
    scenes = copy.deepcopy(data.get("scenes", []))
    flat = []
    for sc in scenes:
        cast = sc.pop("cast")
        for ln in sc["lines"]:
            ln["text"] = es_city(ln["text"])
            ln["name"] = cast.get(ln["speaker"], "")
            ln["pron"] = P(ln["text"])
            flat.append(dict(ln))
        sc["cast"] = cast
    if scenes:
        lesson["scenes"] = scenes
        lesson["dialogue"] = flat
    # --- phrases, devoirs, quiz
    phrases = lesson.get("phrases") or []
    have = {p["text"] for p in phrases}
    for t, f in data.get("phrases_add", []):
        t = es_city(t)
        if t not in have:
            phrases.append({"text": t, "translation": f, "pron": ""})
    for p in phrases:
        p["pron"] = p.get("pron") or P(p["text"])
    lesson["phrases"] = phrases
    lesson["homework"] = (lesson.get("homework") or []) + copy.deepcopy(data.get("homework", []))
    lesson["quiz"] = (lesson.get("quiz") or []) + copy.deepcopy(data.get("quiz_add", []))
    # --- lecture : prononciation manquante
    r = lesson.get("reading")
    if r:
        for s in r.get("sentences", []):
            s["pron"] = s.get("pron") or P(s.get("text", ""))


def run(name, table, fixes, src=ASSETS):
    path = ASSETS / f"{name}.json"
    doc = json.loads((Path(src) / f"{name}.json").read_text(encoding="utf-8"))
    n = 0
    for lesson in doc["lessons"]:
        data = table.get(lesson["id"])
        if data:
            enrich(lesson, data, fixes.get(lesson["id"], {}))
            n += 1
    path.write_text(json.dumps(doc, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"{name}: {n} leçons enrichies")


if __name__ == "__main__":
    src = sys.argv[1] if len(sys.argv) > 1 else ASSETS
    run("es_model2", M2, FIX, src)
    run("es_model3", M3, {}, src)
