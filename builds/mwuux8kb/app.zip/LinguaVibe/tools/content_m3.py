"""Enrichissement du MODEL 3 (manuel « 6e » : Saluer, Mi familia, Escucha a tus padres, Los números).

Contenu aligné sur les pages du manuel photographiées : « Me llamo Fatou » (Koffi, Silué de Korhogo),
« Mi familia » (Abolé 45 años, Fatou 44, Api 14, Adou 12, Yéli 10), « Escucha a tus padres » (Kadjo),
« Esquisse grammaticale » (formes, couleurs, taille) et « J'intègre » (carnet sur la famille d'un ami).
"""


def V(word, tr, ex="", extr="", emoji="🔤"):
    return {"word": word, "translation": tr, "emoji": emoji, "example": ex, "exampleTr": extr}


def G(title, expl, examples):
    return {"title": title, "explanation": expl, "examples": [{"text": t, "translation": f} for t, f in examples]}


def S(title, titleTr, scene, context, cast, lines):
    return {"title": title, "titleTr": titleTr, "scene": scene, "context": context, "cast": cast,
            "lines": [{"speaker": s, "text": t, "translation": f} for s, t, f in lines]}


def H(prompt, model="", keywords=()):
    return {"prompt": prompt, "model": model, "keywords": list(keywords)}


def Q(question, correct, wrong):
    return {"type": "mcq", "question": question, "correct": correct, "wrong": wrong}


M3 = {
    # ------------------------------------------------------------------ Unité 1
    "m3-es-01": {
        "title": "Saludos y presentaciones",
        "titleTr": "Saluer, se présenter et prendre congé",
        "intro": "Au collège, Fatou se présente à Koffi, puis lui présente Silué, venu de Korhogo. "
                 "Dans cette unité, vous apprenez à saluer selon le moment de la journée, à dire votre nom, "
                 "à présenter quelqu'un et à prendre congé poliment.",
        "vocab_fix": {"¡Buenas tardes!": "Bon après-midi ! / Bonsoir !"},
        "vocab": [
            V("Me llamo…", "Je m'appelle…", "Me llamo Fatou.", "Je m'appelle Fatou.", "🙋"),
            V("¿Cómo te llamas?", "Comment t'appelles-tu ?", "¡Hola! ¿Cómo te llamas?", "Salut ! Comment t'appelles-tu ?", "❓"),
            V("Soy de…", "Je suis de… / Je viens de…", "Soy de Abidjan.", "Je suis d'Abidjan.", "📍"),
            V("Éste es… / Ésta es…", "Voici… (pour présenter quelqu'un)", "Éste es Silué. Es de Korhogo.", "Voici Silué. Il est de Korhogo.", "👉"),
            V("Encantado / Encantada", "Enchanté / Enchantée", "Encantada, Silué.", "Enchantée, Silué.", "🤝"),
            V("Mucho gusto", "Ravi(e) de faire ta / votre connaissance", "Mucho gusto, señora.", "Ravi de vous connaître, madame.", "😊"),
            V("el colegio", "le collège", "Fatou y Koffi están en el colegio.", "Fatou et Koffi sont au collège.", "🏫"),
            V("el compañero / la compañera", "le camarade / la camarade", "Koffi es mi compañero de clase.", "Koffi est mon camarade de classe.", "🧒"),
            V("¡Bienvenido! / ¡Bienvenida!", "Bienvenue !", "¡Bienvenido al colegio, Silué!", "Bienvenue au collège, Silué !", "🎉"),
            V("¿Qué tal?", "Ça va ? / Comment ça va ?", "¿Qué tal, Koffi?", "Ça va, Koffi ?", "👋"),
        ],
        "grammar": [
            G("Se présenter : LLAMARSE et SER DE",
              "Pour dire son nom, on emploie le verbe pronominal llamarse : me llamo (je m'appelle), te llamas (tu t'appelles), "
              "se llama (il / elle s'appelle). Pour dire d'où l'on vient : ser de + ville ou pays : soy de, eres de, es de. "
              "Attention : on ne dit pas « yo llamo Fatou » ; le pronom me est obligatoire.",
              [("Me llamo Fatou. Soy de Bouaké.", "Je m'appelle Fatou. Je suis de Bouaké."),
               ("¿Cómo te llamas? — Me llamo Koffi.", "Comment t'appelles-tu ? — Je m'appelle Koffi."),
               ("Se llama Silué. Es de Korhogo.", "Il s'appelle Silué. Il est de Korhogo.")]),
            G("Présenter quelqu'un : ÉSTE / ÉSTA / ÉSTOS / ÉSTAS",
              "Pour présenter une personne, on la montre avec un démonstratif suivi de es (singulier) ou son (pluriel) : "
              "éste es (garçon, homme), ésta es (fille, femme), éstos son (plusieurs, dont au moins un garçon), "
              "éstas son (uniquement des filles). Le manuel écrit ces pronoms avec un accent ; l'usage moderne l'accepte aussi sans accent : este, esta.",
              [("Éste es Silué.", "Voici Silué."),
               ("Ésta es Aya, mi compañera.", "Voici Aya, ma camarade."),
               ("Éstos son mis amigos, Koffi y Silué.", "Voici mes amis, Koffi et Silué."),
               ("Éstas son Fatou y Aya.", "Voici Fatou et Aya.")]),
            G("Saluer selon le moment : BUENOS / BUENAS",
              "Día est masculin : ¡Buenos días! (le matin, jusqu'à midi environ). Tarde et noche sont féminins : "
              "¡Buenas tardes! (l'après-midi, jusqu'à la tombée de la nuit), ¡Buenas noches! (le soir pour saluer et pour se quitter). "
              "Pour partir : ¡Adiós! (au revoir), ¡Hasta luego! (à tout à l'heure / à plus tard), ¡Hasta mañana! (à demain).",
              [("¡Buenos días, señor profesor!", "Bonjour, monsieur le professeur !"),
               ("¡Buenas tardes, abuela!", "Bonjour, grand-mère ! (l'après-midi)"),
               ("¡Buenas noches! ¡Hasta mañana!", "Bonne nuit ! À demain !")]),
        ],
        "scenes": [
            S("Me llamo Fatou", "Je m'appelle Fatou", "patio",
              "La rentrée au collège. Dans la cour, devant le drapeau, Fatou aborde un nouvel élève.",
              {"A": "Fatou", "B": "Koffi"},
              [("A", "¡Hola! Me llamo Fatou. ¿Cómo te llamas?", "Salut ! Je m'appelle Fatou. Comment t'appelles-tu ?"),
               ("B", "¡Hola! Me llamo Koffi.", "Salut ! Je m'appelle Koffi."),
               ("A", "¿De dónde eres, Koffi?", "D'où es-tu, Koffi ?"),
               ("B", "Soy de Abidjan. ¿Y tú?", "Je suis d'Abidjan. Et toi ?"),
               ("A", "Yo soy de Bouaké. Mira, éste es Silué. Es de Korhogo.", "Moi, je suis de Bouaké. Regarde, voici Silué. Il est de Korhogo."),
               ("B", "¡Encantado, Silué! ¡Bienvenido al colegio!", "Enchanté, Silué ! Bienvenue au collège !"),
               ("A", "Silué está en nuestra clase.", "Silué est dans notre classe."),
               ("B", "¡Qué bien! Somos compañeros.", "Super ! Nous sommes camarades.")]),
            S("Buenos días, abuela", "Bonjour, grand-mère", "familia",
              "Le matin, avant de partir à l'école, Koffi salue poliment sa grand-mère. On vouvoie les aînés : ¿Cómo está usted?",
              {"A": "Abuela", "B": "Koffi"},
              [("B", "¡Buenos días, abuela! ¿Cómo está usted?", "Bonjour, grand-mère ! Comment allez-vous ?"),
               ("A", "Muy bien, hijo, gracias. ¿Y tú, cómo estás?", "Très bien, mon fils, merci. Et toi, comment vas-tu ?"),
               ("B", "Estoy bien, gracias. Me voy al colegio.", "Je vais bien, merci. Je pars au collège."),
               ("A", "¡Que tengas un buen día! Estudia mucho.", "Passe une bonne journée ! Travaille bien."),
               ("B", "Sí, abuela. ¡Hasta luego!", "Oui, grand-mère. À tout à l'heure !"),
               ("A", "¡Adiós, Koffi!", "Au revoir, Koffi !")]),
            S("Hasta mañana", "À demain", "veillee",
              "Le soir, après la veillée, les enfants se disent au revoir. On utilise ¡Buenas noches! pour se quitter.",
              {"A": "Aya", "B": "Fatou"},
              [("A", "Ya es tarde. Me voy a casa.", "Il est déjà tard. Je rentre à la maison."),
               ("B", "¡Buenas noches, Aya!", "Bonne nuit, Aya !"),
               ("A", "¡Buenas noches! ¿Nos vemos mañana en el colegio?", "Bonne nuit ! On se voit demain au collège ?"),
               ("B", "Sí, ¡hasta mañana!", "Oui, à demain !"),
               ("A", "¡Hasta mañana, Fatou! Saludos a tu familia.", "À demain, Fatou ! Salue ta famille."),
               ("B", "¡Gracias! ¡Adiós!", "Merci ! Au revoir !")]),
        ],
        "phrases_add": [
            ("Me llamo Koffi y soy de Abidjan.", "Je m'appelle Koffi et je suis d'Abidjan."),
            ("Éste es Silué. Es de Korhogo.", "Voici Silué. Il est de Korhogo."),
            ("Encantada de conocerte.", "Enchantée de faire ta connaissance."),
            ("¿Cómo está usted, señora?", "Comment allez-vous, madame ?"),
        ],
        "homework": [
            H("Complète le dialogue du manuel (p. 10) avec tes camarades : ¡Hola! … / Yo … / Me … / Éste / ésta … / Éstos / éstas …",
              "¡Hola! Me llamo Awa. Yo soy de Yamoussoukro. Me llamo Awa Traoré. Ésta es Aya, es de Man. Éstos son Koffi y Silué.",
              ["me llamo", "soy de", "este", "esta", "estos"]),
            H("Écris un petit texte de 4 phrases : tu te présentes, puis tu présentes un camarade (nom, ville).",
              "Hola, me llamo Adou. Soy de Daloa. Éste es mi compañero Yao. Es de San-Pédro.",
              ["me llamo", "soy de", "este es", "es de"]),
            H("Écris la salutation adaptée : à ton professeur à 8 h, à ta grand-mère à 15 h, à ton ami à 21 h avant de partir.",
              "¡Buenos días, señor profesor! / ¡Buenas tardes, abuela! / ¡Buenas noches, hasta mañana!",
              ["buenos días", "buenas tardes", "buenas noches"]),
        ],
        "quiz_add": [
            Q("Comment présente-t-on une fille ?", "Ésta es Aya.", ["Éste es Aya.", "Éstos son Aya.", "Me llamo Aya."]),
            Q("Silué est de Korhogo. Comment le dire ?", "Es de Korhogo.", ["Soy de Korhogo.", "Se llama Korhogo.", "Está Korhogo."]),
            Q("Que répond-on à « ¿Cómo te llamas? » ?", "Me llamo Koffi.", ["Soy bien.", "Estoy Koffi.", "Hasta luego."]),
        ],
    },
    # ------------------------------------------------------------------ Unité 2
    "m3-es-02": {
        "title": "Mi familia",
        "titleTr": "Ma famille",
        "intro": "Voici la famille de Fatou autour de la table : le père Abolé (45 ans), la mère Fatou (44 ans) et leurs trois "
                 "enfants Api (14 ans), Adou (12 ans) et Yéli (10 ans). Vous apprenez à identifier les membres d'une famille, "
                 "à dire leur âge, et à décrire les formes, les couleurs et la taille (esquisse grammaticale du manuel).",
        "vocab": [
            V("¿Cuántos años tienes?", "Quel âge as-tu ?", "¿Cuántos años tienes, Adou? — Tengo doce años.", "Quel âge as-tu, Adou ? — J'ai douze ans.", "🎂"),
            V("tener … años", "avoir … ans", "Abolé tiene cuarenta y cinco años.", "Abolé a quarante-cinq ans.", "🔢"),
            V("el mayor / la mayor", "l'aîné / l'aînée", "Api es la mayor.", "Api est l'aînée.", "⬆️"),
            V("el menor / la menor", "le cadet / la cadette (le plus jeune)", "Yéli es la menor.", "Yéli est la plus jeune.", "⬇️"),
            V("redondo / redonda", "rond / ronde", "La mesa es redonda.", "La table est ronde.", "⚪"),
            V("cuadrado / cuadrada", "carré / carrée", "El salón es cuadrado.", "Le salon est carré.", "🟥"),
            V("rectangular", "rectangulaire", "El comedor es rectangular.", "La salle à manger est rectangulaire.", "▭"),
            V("azul", "bleu / bleue", "un paño azul", "un pagne bleu", "🔵"),
            V("amarillo / amarilla", "jaune", "una camiseta amarilla", "un tee-shirt jaune", "🟡"),
            V("rojo / roja", "rouge", "una falda roja", "une jupe rouge", "🔴"),
            V("verde", "vert / verte", "un vestido verde", "une robe verte", "🟢"),
            V("blanco / blanca", "blanc / blanche", "una camisa blanca", "une chemise blanche", "⚪"),
            V("alto / alta", "grand / grande (taille)", "La chica es alta.", "La fille est grande.", "📏"),
            V("bajo / baja", "petit / petite (taille)", "El chico es bajo.", "Le garçon est petit.", "📐"),
            V("de estatura mediana", "de taille moyenne", "Api es de estatura mediana.", "Api est de taille moyenne.", "↕️"),
            V("el paño", "le pagne", "Mamá lleva un paño azul.", "Maman porte un pagne bleu.", "🧣"),
        ],
        "grammar": [
            G("Présenter sa famille : ESTE ES MI… / ESTA ES MI…",
              "Este es mi padre (voici mon père), esta es mi madre (voici ma mère), estos son mis hermanos (voici mes frères et sœurs). "
              "Le possessif mi devient mis au pluriel : mi hermano → mis hermanos. Pour la famille de quelqu'un d'autre : su padre (son père), "
              "sus hijos (ses enfants).",
              [("Este es mi padre. Se llama Abolé.", "Voici mon père. Il s'appelle Abolé."),
               ("Esta es mi madre. Se llama Fatou.", "Voici ma mère. Elle s'appelle Fatou."),
               ("Estos son mis hermanos: Adou y Yéli.", "Voici mon frère et ma sœur : Adou et Yéli.")]),
            G("Dire l'âge : TENER … AÑOS",
              "En espagnol comme en français, on « a » un âge : tengo (j'ai), tienes (tu as), tiene (il / elle a). "
              "Question : ¿Cuántos años tienes? (quel âge as-tu ?). Attention à l'accord : un año, mais veintiún años, treinta y un años.",
              [("Abolé tiene cuarenta y cinco años.", "Abolé a quarante-cinq ans."),
               ("Fatou tiene cuarenta y cuatro años.", "Fatou a quarante-quatre ans."),
               ("Api tiene catorce años, Adou tiene doce y Yéli tiene diez.", "Api a quatorze ans, Adou en a douze et Yéli dix.")]),
            G("Les formes et les couleurs : l'adjectif s'accorde",
              "L'adjectif se place en général après le nom et s'accorde en genre et en nombre : una falda roja, unas faldas rojas. "
              "Les adjectifs en -o changent (rojo → roja), ceux en -e ou en consonne ne changent pas au féminin (verde, azul, gris). "
              "Au pluriel on ajoute -s après une voyelle (rojas) et -es après une consonne (azules, rectangulares).",
              [("La mesa es redonda.", "La table est ronde."),
               ("La sala de comer es rectangular.", "La salle à manger est rectangulaire."),
               ("un paño azul / dos paños azules", "un pagne bleu / deux pagnes bleus"),
               ("una camiseta amarilla y una falda roja", "un tee-shirt jaune et une jupe rouge")]),
            G("La taille : ALTO, BAJO, DE ESTATURA MEDIANA",
              "Pour décrire une personne on utilise ser + adjectif (caractéristique stable) : el chico es bajo, la chica es alta, "
              "la chica es de estatura mediana. Pour comparer : más alto que (plus grand que), menos alto que (moins grand que), tan alto como (aussi grand que).",
              [("El chico es bajo.", "Le garçon est petit."),
               ("La chica es de estatura mediana.", "La fille est de taille moyenne."),
               ("Api es más alta que Yéli.", "Api est plus grande que Yéli.")]),
        ],
        "scenes": [
            S("La familia de Fatou a la mesa", "La famille de Fatou à table", "familia",
              "Koffi vient déjeuner chez son amie Api. Elle lui présente sa famille autour de la table ronde.",
              {"A": "Api", "B": "Koffi"},
              [("A", "Koffi, esta es mi familia.", "Koffi, voici ma famille."),
               ("A", "Este es mi padre, Abolé. Tiene cuarenta y cinco años.", "Voici mon père, Abolé. Il a quarante-cinq ans."),
               ("B", "Mucho gusto, señor Abolé.", "Enchanté, monsieur Abolé."),
               ("A", "Y esta es mi madre, Fatou. Tiene cuarenta y cuatro años.", "Et voici ma mère, Fatou. Elle a quarante-quatre ans."),
               ("B", "Encantado, señora. ¿Y estos niños?", "Enchanté, madame. Et ces enfants ?"),
               ("A", "Son mis hermanos: Adou tiene doce años y Yéli tiene diez.", "Ce sont mon frère et ma sœur : Adou a douze ans et Yéli dix."),
               ("B", "Entonces tú eres la mayor. ¿Cuántos años tienes?", "Alors c'est toi l'aînée. Quel âge as-tu ?"),
               ("A", "Tengo catorce años. ¡Siéntate con nosotros!", "J'ai quatorze ans. Assieds-toi avec nous !"),
               ("B", "Gracias. ¡Qué familia tan simpática!", "Merci. Quelle famille sympathique !")]),
            S("Mi carnet sobre la familia de mi amiga", "Mon carnet sur la famille de mon amie", "telefono",
              "J'intègre : de retour chez lui, Koffi téléphone à son cousin pour raconter sa journée chez Api et note les informations dans son carnet.",
              {"A": "Yao", "B": "Koffi"},
              [("A", "¿Qué tal en casa de Api?", "Comment ça s'est passé chez Api ?"),
               ("B", "Muy bien. Su familia es grande y simpática.", "Très bien. Sa famille est grande et sympathique."),
               ("A", "¿Cuántos son en su familia?", "Combien sont-ils dans sa famille ?"),
               ("B", "Son cinco: el padre, la madre y tres hijos.", "Ils sont cinq : le père, la mère et trois enfants."),
               ("A", "¿Cómo es su padre?", "Comment est son père ?"),
               ("B", "Es alto y lleva una camisa blanca. Es muy amable.", "Il est grand et porte une chemise blanche. Il est très gentil."),
               ("A", "¿Y su madre?", "Et sa mère ?"),
               ("B", "Es de estatura mediana. Lleva un paño azul muy bonito.", "Elle est de taille moyenne. Elle porte un très joli pagne bleu.")]),
            S("En el taller de costura", "Chez le couturier", "couture",
              "Fatou (la mère) et sa fille Yéli choisissent des vêtements pour la fête. Couleurs, formes et tailles.",
              {"A": "Sastre", "B": "Yéli"},
              [("A", "Buenas tardes. ¿Qué desean?", "Bonjour. Que désirez-vous ?"),
               ("B", "Buenas tardes. Quiero una falda roja.", "Bonjour. Je voudrais une jupe rouge."),
               ("A", "Aquí tienes una falda roja. ¿Y para tu mamá?", "Voici une jupe rouge. Et pour ta maman ?"),
               ("B", "Mi mamá prefiere un paño azul.", "Ma maman préfère un pagne bleu."),
               ("A", "¿Y una camiseta amarilla para tu hermano?", "Et un tee-shirt jaune pour ton frère ?"),
               ("B", "Sí, pero mi hermano es bajo: talla pequeña, por favor.", "Oui, mais mon frère est petit : petite taille, s'il vous plaît."),
               ("A", "Muy bien. ¡Son colores muy alegres!", "Très bien. Ce sont des couleurs très gaies !"),
               ("B", "¡Gracias, señor!", "Merci, monsieur !")]),
        ],
        "phrases_add": [
            ("Este es mi padre. Tiene cuarenta y cinco años.", "Voici mon père. Il a quarante-cinq ans."),
            ("Estos son mis hermanos.", "Voici mes frères et sœurs."),
            ("La mesa es redonda.", "La table est ronde."),
            ("La chica es alta y el chico es bajo.", "La fille est grande et le garçon est petit."),
        ],
        "homework": [
            H("En paires : identifie deux membres de la famille d'Abolé ; ton voisin dit leur lien (ex. : Api y Adou → son hermanos).",
              "Abolé y Fatou son los padres. Api es la hermana de Adou. Yéli es la hija de Abolé.",
              ["padre", "madre", "hermano", "hermana", "hija"]),
            H("J'intègre : tu passes une journée chez ton ami(e). Rédige dans ton carnet 5 phrases sur sa famille (noms, âges, taille, vêtements).",
              "La familia de mi amiga Aya es grande. Su padre se llama Yao y tiene cincuenta años. Es alto. Su madre lleva un paño verde. "
              "Aya tiene dos hermanos.",
              ["su padre", "su madre", "tiene", "años", "es"]),
            H("Décris trois objets de ta maison avec une forme et une couleur.",
              "La mesa es redonda y blanca. El salón es cuadrado. Mi cuaderno es rectangular y azul.",
              ["redonda", "cuadrado", "rectangular"]),
        ],
        "quiz_add": [
            Q("Quel âge a Abolé ?", "Cuarenta y cinco años", ["Cuarenta y cuatro años", "Catorce años", "Cincuenta años"]),
            Q("Comment dit-on « une jupe rouge » ?", "una falda roja", ["una falda rojo", "un rojo falda", "una roja falda"]),
            Q("« La chica es … » (grande taille)", "alta", ["baja", "redonda", "amarilla"]),
            Q("Pluriel de « un paño azul » ?", "dos paños azules", ["dos paños azul", "dos paño azules", "dos paños azuls"]),
        ],
    },
    # ------------------------------------------------------------------ Unité 3
    "m3-es-03": {
        "title": "Escucha a tus padres",
        "titleTr": "Écoute tes parents",
        "intro": "Un conte de veillée : il était une fois un enfant, Kadjo, qui n'écoutait pas les conseils de ses parents. "
                 "Un jour il refuse d'aller au champ… Vous apprenez à raconter (érase una vez), à refuser (no voy), "
                 "à donner un conseil ou un ordre (escucha, escuchad) et à dire « avoir faim » (tener hambre).",
        "vocab": [
            V("Érase una vez", "Il était une fois", "Érase una vez un niño llamado Kadjo.", "Il était une fois un enfant nommé Kadjo.", "📜"),
            V("el consejo", "le conseil", "No escuchaba los consejos de sus padres.", "Il n'écoutait pas les conseils de ses parents.", "💬"),
            V("el campo", "le champ / la campagne", "Kadjo, vamos al campo.", "Kadjo, allons au champ.", "🌾"),
            V("la selva", "la forêt (vierge)", "El genio lo lleva al fondo de la selva.", "Le génie l'emporte au fond de la forêt.", "🌳"),
            V("el genio", "le génie (esprit du conte)", "El genio de la selva es muy grande.", "Le génie de la forêt est très grand.", "👺"),
            V("llevar", "emmener / emporter", "Te llevo al fondo de la selva.", "Je t'emmène au fond de la forêt.", "🪽"),
            V("buscar", "chercher", "Los hombres buscan a Kadjo.", "Les hommes cherchent Kadjo.", "🔎"),
            V("¿Dónde estás?", "Où es-tu ?", "¡Kadjo! ¿Dónde estás?", "Kadjo ! Où es-tu ?", "📣"),
            V("sucio / sucia", "sale", "¡Mira cómo está sucio!", "Regarde comme il est sale !", "🟤"),
            V("tener hambre", "avoir faim", "El niño tiene hambre.", "L'enfant a faim.", "🍲"),
            V("¡Pobre niño!", "Pauvre enfant !", "¡Pobre niño! Está cansado.", "Pauvre enfant ! Il est fatigué.", "😢"),
            V("obedecer", "obéir", "Hay que obedecer a los padres.", "Il faut obéir aux parents.", "🙇"),
            V("el abuelo", "le grand-père / le vieux sage", "El abuelo cuenta un cuento.", "Le grand-père raconte un conte.", "👴"),
            V("el cuento", "le conte", "Es un cuento con una lección.", "C'est un conte avec une morale.", "📖"),
        ],
        "grammar": [
            G("L'impératif : ESCUCHA (tú) / ESCUCHAD (vosotros)",
              "Pour conseiller une seule personne qu'on tutoie : on prend la 3e personne du présent : escucha (écoute), come (mange), ven (viens, irrégulier). "
              "Pour plusieurs personnes (usage de l'Espagne) : on remplace le -r final de l'infinitif par -d : escuchar → escuchad, comer → comed, venir → venid. "
              "En Amérique latine et souvent en Afrique hispanophone, on dit plutôt escuchen (ustedes).",
              [("Kadjo, escucha a tus padres.", "Kadjo, écoute tes parents."),
               ("¡Niños, escuchad los consejos de vuestros padres!", "Les enfants, écoutez les conseils de vos parents !"),
               ("Ven al campo con nosotros.", "Viens au champ avec nous.")]),
            G("Refuser : NO + verbe",
              "La négation se place juste devant le verbe conjugué : voy → no voy (je n'y vais pas). Pour répondre : No, papá; no voy. "
              "Dans le conte, l'imparfait no escuchaba décrit une habitude passée : il n'écoutait pas (jamais).",
              [("No, papá; no voy.", "Non, papa ; je n'y vais pas."),
               ("Kadjo no escucha a su padre.", "Kadjo n'écoute pas son père."),
               ("No escuchaba los consejos de sus padres.", "Il n'écoutait pas les conseils de ses parents.")]),
            G("Raconter un conte : ÉRASE UNA VEZ + imparfait",
              "Les contes commencent par Érase una vez… (il était une fois) ou Había una vez… L'imparfait (-aba, -ía) décrit la situation : "
              "vivía (il vivait), escuchaba (il écoutait). Les événements qui font avancer l'histoire seront au passé simple dans les leçons suivantes.",
              [("Érase una vez un niño llamado Kadjo.", "Il était une fois un enfant appelé Kadjo."),
               ("Vivía en un pueblo cerca de la selva.", "Il vivait dans un village près de la forêt.")]),
            G("TENER : avoir faim, avoir peur, avoir froid",
              "Beaucoup de sensations se disent avec tener + nom : tener hambre (avoir faim), tener sed (avoir soif), tener miedo (avoir peur), "
              "tener frío (avoir froid), tener sueño (avoir sommeil).",
              [("Kadjo tiene hambre y tiene miedo.", "Kadjo a faim et il a peur."),
               ("¿Tienes sed? Aquí tienes agua.", "Tu as soif ? Voici de l'eau.")]),
        ],
        "scenes": [
            S("Kadjo, vamos al campo", "Kadjo, allons au champ", "campo",
              "Au village, le père de Kadjo, machette à la main, part travailler au champ. Kadjo refuse de l'accompagner.",
              {"A": "Papá", "B": "Kadjo"},
              [("A", "Kadjo, vamos al campo.", "Kadjo, allons au champ."),
               ("B", "No, papá; no voy.", "Non, papa ; je n'y vais pas."),
               ("A", "Hijo, hay mucho trabajo. Ven con nosotros.", "Mon fils, il y a beaucoup de travail. Viens avec nous."),
               ("B", "No quiero. Prefiero jugar aquí.", "Je ne veux pas. Je préfère jouer ici."),
               ("A", "Escucha a tus padres, Kadjo. Es un buen consejo.", "Écoute tes parents, Kadjo. C'est un bon conseil."),
               ("B", "¡No voy, papá!", "Je n'y vais pas, papa !"),
               ("A", "Muy bien. Nos vamos sin ti.", "Très bien. Nous partons sans toi.")]),
            S("¡Kadjo! ¿Dónde estás?", "Kadjo ! Où es-tu ?", "selva",
              "Le génie de la forêt a emporté Kadjo « parce qu'il ne va pas au champ avec ses parents ». Les villageois le cherchent puis le retrouvent sous un arbre.",
              {"A": "Papá", "B": "Vecino"},
              [("A", "¡Kadjo! ¿Dónde estás?", "Kadjo ! Où es-tu ?"),
               ("B", "¡Oh, oh, oh! ¡Kadjo!", "Oh, oh, oh ! Kadjo !"),
               ("A", "No está en el pueblo. Busquemos en la selva.", "Il n'est pas au village. Cherchons dans la forêt."),
               ("B", "¡Mira! ¡Allí, debajo del árbol!", "Regarde ! Là, sous l'arbre !"),
               ("A", "¡Pobre niño! Mira cómo está sucio.", "Pauvre enfant ! Regarde comme il est sale."),
               ("B", "Tiene hambre. Dale agua y un poco de comida.", "Il a faim. Donne-lui de l'eau et un peu à manger."),
               ("A", "Hijo mío, ¿estás bien?", "Mon fils, ça va ?"),
               ("B", "Vamos a casa. Ya está a salvo.", "Rentrons à la maison. Il est sain et sauf.")]),
            S("Niños, escuchad los consejos", "Les enfants, écoutez les conseils", "veillee",
              "Autour du feu, le vieux sage termine le conte et en tire la morale pour les enfants.",
              {"A": "Abuelo", "B": "Niños"},
              [("A", "Érase una vez un niño llamado Kadjo. No escuchaba los consejos de sus padres.", "Il était une fois un enfant nommé Kadjo. Il n'écoutait pas les conseils de ses parents."),
               ("B", "¿Y qué pasó, abuelo?", "Et que s'est-il passé, grand-père ?"),
               ("A", "Un genio lo llevó al fondo de la selva.", "Un génie l'a emporté au fond de la forêt."),
               ("B", "¡Qué miedo! ¿Y sus padres?", "Quelle peur ! Et ses parents ?"),
               ("A", "Lo buscaron toda la noche y lo encontraron con hambre.", "Ils l'ont cherché toute la nuit et l'ont trouvé affamé."),
               ("B", "Pobre Kadjo… Ahora escucha a sus padres.", "Pauvre Kadjo… Maintenant il écoute ses parents."),
               ("A", "¡Niños, escuchad los consejos de vuestros padres!", "Les enfants, écoutez les conseils de vos parents !"),
               ("B", "¡Sí, abuelo! Vamos a escuchar.", "Oui, grand-père ! Nous allons écouter.")]),
        ],
        "phrases_add": [
            ("Érase una vez un niño llamado Kadjo.", "Il était une fois un enfant nommé Kadjo."),
            ("Kadjo, vamos al campo. — No, papá; no voy.", "Kadjo, allons au champ. — Non, papa ; je n'y vais pas."),
            ("¡Pobre niño! Tiene hambre.", "Pauvre enfant ! Il a faim."),
            ("Niños, escuchad los consejos de vuestros padres.", "Les enfants, écoutez les conseils de vos parents."),
        ],
        "homework": [
            H("Je découvre : relève dans les bulles l'expression liée à « donner des conseils ».",
              "Niños, escuchad los consejos de vuestros padres.", ["escuchad", "consejos"]),
            H("Raconte l'histoire de Kadjo en 5 phrases (début : Érase una vez…).",
              "Érase una vez un niño llamado Kadjo. No escuchaba a sus padres. Un día no fue al campo. Un genio lo llevó a la selva. "
              "Sus padres lo encontraron sucio y con hambre.",
              ["érase una vez", "no escuchaba", "campo", "selva", "hambre"]),
            H("Écris 3 conseils à un petit frère avec l'impératif (escucha, come, estudia…).",
              "Escucha a papá y a mamá. Come bien. Estudia tus lecciones.", ["escucha", "come", "estudia"]),
        ],
        "quiz_add": [
            Q("Comment Kadjo refuse-t-il ?", "No, papá; no voy.", ["Sí, papá; voy.", "Vamos al campo.", "¿Dónde estás?"]),
            Q("Impératif « écoutez » (plusieurs personnes, Espagne) :", "escuchad", ["escucha", "escuchar", "escuchas"]),
            Q("« Il était une fois » se dit :", "Érase una vez", ["Una vez más", "Había mañana", "Hasta la vista"]),
        ],
    },
    # ------------------------------------------------------------------ Unité 4
    "m3-es-04": {
        "title": "Los números",
        "titleTr": "Les nombres",
        "intro": "Au marché, à l'école et à la gare routière, les nombres sont partout : prix en francs CFA, âges, numéros de téléphone, "
                 "heures de départ. Apprenez-les par petits groupes et dites-les à voix haute.",
        "vocab": [
            V("¿Cuánto cuesta?", "Combien ça coûte ?", "¿Cuánto cuesta el kilo de tomates?", "Combien coûte le kilo de tomates ?", "💰"),
            V("el franco", "le franc (CFA)", "Cuesta quinientos francos.", "Ça coûte cinq cents francs.", "🪙"),
            V("caro / cara", "cher / chère", "¡Es muy caro!", "C'est très cher !", "📈"),
            V("barato / barata", "bon marché", "Las naranjas son baratas hoy.", "Les oranges sont bon marché aujourd'hui.", "📉"),
            V("mil", "mille", "dos mil francos", "deux mille francs", "🔢"),
            V("el número de teléfono", "le numéro de téléphone", "¿Cuál es tu número de teléfono?", "Quel est ton numéro de téléphone ?", "📱"),
            V("¿A qué hora…?", "À quelle heure… ?", "¿A qué hora sale el autobús?", "À quelle heure part le car ?", "⏰"),
            V("el asiento", "la place assise / le siège", "Tengo el asiento número doce.", "J'ai la place numéro douze.", "💺"),
            V("la vuelta", "la monnaie (rendue)", "Aquí tiene la vuelta.", "Voici votre monnaie.", "🔁"),
        ],
        "grammar": [
            G("Compter de 16 à 99",
              "De 16 à 29 on écrit en un seul mot : dieciséis, diecisiete, veinte, veintiuno, veintidós… "
              "À partir de 31, on relie dizaine et unité par y : treinta y uno, cuarenta y cinco, noventa y nueve. "
              "Jamais de y après cien ou mil : ciento cinco, mil doscientos.",
              [("veintidós alumnos", "vingt-deux élèves"),
               ("cuarenta y cinco años", "quarante-cinq ans"),
               ("noventa y nueve francos", "quatre-vingt-dix-neuf francs")]),
            G("CIEN ou CIENTO ? Les centaines s'accordent",
              "Cien s'emploie seul ou devant un nom / mil : cien francos, cien mil. Ciento s'emploie devant une autre unité : ciento veinte. "
              "Les centaines de 200 à 900 s'accordent avec le nom : doscientos francos, doscientas personas. "
              "Formes irrégulières : quinientos (500), setecientos (700), novecientos (900).",
              [("cien francos / ciento cincuenta francos", "cent francs / cent cinquante francs"),
               ("doscientas naranjas", "deux cents oranges"),
               ("quinientos francos", "cinq cents francs")]),
            G("UNO devient UN devant un nom masculin",
              "un libro, veintiún años, treinta y un alumnos ; mais una mesa, veintiuna personas. Pour l'heure : es la una, son las dos.",
              [("Tengo veintiún años.", "J'ai vingt et un ans."),
               ("Es la una y media.", "Il est une heure et demie."),
               ("Son las siete en punto.", "Il est sept heures pile.")]),
        ],
        "scenes": [
            S("En el mercado de Adjamé", "Au marché d'Adjamé", "mercado",
              "La mère de Yéli fait ses courses. Elle demande les prix et négocie avec la vendeuse.",
              {"A": "Vendedora", "B": "Cliente"},
              [("A", "¡Buenos días, señora! Tomates frescos, naranjas dulces.", "Bonjour, madame ! Tomates fraîches, oranges sucrées."),
               ("B", "Buenos días. ¿Cuánto cuesta el kilo de tomates?", "Bonjour. Combien coûte le kilo de tomates ?"),
               ("A", "Quinientos francos el kilo.", "Cinq cents francs le kilo."),
               ("B", "¡Es un poco caro! ¿Cuatrocientos?", "C'est un peu cher ! Quatre cents ?"),
               ("A", "Bueno, cuatrocientos cincuenta para usted.", "Bon, quatre cent cinquante pour vous."),
               ("B", "De acuerdo. Y diez naranjas, por favor.", "D'accord. Et dix oranges, s'il vous plaît."),
               ("A", "Son trescientos francos. En total, setecientos cincuenta.", "Cela fait trois cents francs. Au total, sept cent cinquante."),
               ("B", "Aquí tiene mil francos.", "Voici mille francs."),
               ("A", "Y doscientos cincuenta de vuelta. ¡Gracias!", "Et deux cent cinquante de monnaie. Merci !")]),
            S("En clase: los números de teléfono", "En classe : les numéros de téléphone", "aula",
              "Le professeur prépare la liste de la classe. Chaque élève donne son âge et son numéro de téléphone.",
              {"A": "Profesor", "B": "Alumno"},
              [("A", "Silué, ¿cuántos años tienes?", "Silué, quel âge as-tu ?"),
               ("B", "Tengo doce años, señor.", "J'ai douze ans, monsieur."),
               ("A", "¿Y cuál es el número de teléfono de tus padres?", "Et quel est le numéro de téléphone de tes parents ?"),
               ("B", "Es el cero siete, cuarenta y cinco, treinta y dos, dieciocho, noventa.", "C'est le 07 45 32 18 90."),
               ("A", "¿Cuántos alumnos hay en la clase hoy?", "Combien d'élèves y a-t-il dans la classe aujourd'hui ?"),
               ("B", "Hay treinta y ocho alumnos.", "Il y a trente-huit élèves."),
               ("A", "¡Muy bien, gracias!", "Très bien, merci !")]),
            S("En la estación de autobuses", "À la gare routière", "gare",
              "Fatou part pour Korhogo voir la famille de Silué. Elle achète son billet et demande l'heure du départ.",
              {"A": "Taquillero", "B": "Fatou"},
              [("B", "Buenas tardes. Un billete para Korhogo, por favor.", "Bonjour. Un billet pour Korhogo, s'il vous plaît."),
               ("A", "Son ocho mil quinientos francos.", "Cela fait huit mille cinq cents francs."),
               ("B", "¿A qué hora sale el autobús?", "À quelle heure part le car ?"),
               ("A", "Sale a las siete y media de la mañana.", "Il part à sept heures et demie du matin."),
               ("B", "¿Y cuántas horas dura el viaje?", "Et combien d'heures dure le voyage ?"),
               ("A", "Unas nueve horas. Su asiento es el número veintiuno.", "Environ neuf heures. Votre place est la numéro vingt et un."),
               ("B", "¡Perfecto, gracias! ¡Hasta luego!", "Parfait, merci ! Au revoir !")]),
        ],
        "phrases_add": [
            ("¿Cuánto cuesta? — Cuesta quinientos francos.", "Combien ça coûte ? — Ça coûte cinq cents francs."),
            ("Tengo veintiún años.", "J'ai vingt et un ans."),
            ("El autobús sale a las siete y media.", "Le car part à sept heures et demie."),
        ],
        "homework": [
            H("Écris en lettres : 15 – 21 – 45 – 100 – 150 – 500 – 1 000 – 8 500.",
              "quince, veintiuno, cuarenta y cinco, cien, ciento cincuenta, quinientos, mil, ocho mil quinientos",
              ["quince", "veintiuno", "cuarenta y cinco", "cien", "quinientos", "mil"]),
            H("Au marché : écris un mini-dialogue de 4 répliques pour acheter deux produits et demander le prix total.",
              "— ¿Cuánto cuesta el kilo de arroz? — Seiscientos francos. — Y un litro de aceite, ¿cuánto es? — Mil francos. En total, mil seiscientos.",
              ["cuánto cuesta", "francos", "en total"]),
        ],
        "quiz_add": [
            Q("Comment dit-on 500 ?", "quinientos", ["cincocientos", "cincuenta", "quinientas mil"]),
            Q("Comment dit-on 21 ans ?", "veintiún años", ["veintiuno años", "veinte y un años", "veintiuna años"]),
            Q("« ¿A qué hora sale el autobús? » signifie :", "À quelle heure part le car ?", ["Combien coûte le car ?", "Où est le car ?", "Quel car part ?"]),
        ],
    },
}
