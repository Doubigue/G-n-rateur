package com.reverse.apkdecompiler.engine

import java.io.File
import java.io.FileInputStream

/** Collecte et classe les chaînes intéressantes (URLs, IPs, emails, clés). */
class FindingsCollector {
    private val data = LinkedHashMap<String, LinkedHashMap<String, String>>()

    private fun add(category: String, value: String, source: String) {
        val m = data.getOrPut(category) { LinkedHashMap() }
        if (m.size < MAX_PER_CATEGORY && !m.containsKey(value)) m[value] = source
    }

    fun feed(s: String, source: String) {
        if (s.contains("://")) {
            URL.findAll(s).forEach { add(CAT_URL, it.value.trimEnd('.', ',', ')', ';', '\''), source) }
        }
        if (s.length >= 7 && s.indexOf('.') > 0 && s.any { it.isDigit() }) {
            IPV4.findAll(s).forEach {
                val v = it.value
                if (!v.startsWith("0.")) add(CAT_IP, v, source)
            }
        }
        if (s.indexOf('@') > 0) {
            EMAIL.findAll(s).forEach { add(CAT_EMAIL, it.value, source) }
        }
        if (s.length >= 8) {
            for ((label, rx) in KEY_PATTERNS) {
                rx.findAll(s).forEach { add(CAT_KEY, "$label: ${it.value.take(200)}", source) }
            }
        }
    }

    fun snapshot(): Map<String, List<Pair<String, String>>> =
        data.mapValues { (_, m) -> m.entries.map { it.key to it.value } }

    companion object {
        const val CAT_URL = "URLs"
        const val CAT_IP = "Adresses IP"
        const val CAT_EMAIL = "Emails"
        const val CAT_KEY = "Clés & secrets"
        private const val MAX_PER_CATEGORY = 5000

        private val URL = Regex("""https?://[A-Za-z0-9._~:/?#\[\]@!$&'()*+,;=%-]{4,}""")
        private val IPV4 = Regex(
            """(?<![\d.])(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(?!\d|\.\d)"""
        )
        private val EMAIL = Regex("""[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}""")
        private val KEY_PATTERNS = listOf(
            "Google API key" to Regex("""AIza[0-9A-Za-z_\-]{35}"""),
            "AWS access key" to Regex("""\b(?:AKIA|ASIA)[0-9A-Z]{16}\b"""),
            "Stripe live key" to Regex("""\bsk_live_[0-9a-zA-Z]{24,}"""),
            "Slack token" to Regex("""xox[baprs]-[0-9A-Za-z-]{10,}"""),
            "GitHub token" to Regex("""\bgh[pousr]_[0-9A-Za-z]{36,}"""),
            "JWT" to Regex("""\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}"""),
            "Clé privée PEM" to Regex("""-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----"""),
            "Firebase DB" to Regex("""https://[a-z0-9-]+\.firebaseio\.com"""),
            "Secret générique" to Regex(
                """(?i)(?:api[_-]?key|secret|token|passwd|password)\s*[=:]\s*["']?[A-Za-z0-9_\-/+=]{12,}"""
            )
        )
    }
}

object StringScanner {
    private const val MIN_LEN = 6
    private const val MAX_LEN = 4096
    private const val MAX_LINES = 1_500_000

    /**
     * Extrait les chaînes ASCII (et UTF-16LE si [utf16], ex. AndroidManifest binaire)
     * de [src], les écrit dans [out] (une par ligne) et alimente [collector].
     * @return nombre de lignes écrites.
     */
    fun scanFile(
        src: File,
        source: String,
        out: File?,
        utf16: Boolean,
        collector: FindingsCollector?,
        check: () -> Unit,
        onString: ((String) -> Unit)? = null
    ): Int {
        var count = 0
        val w = out?.bufferedWriter(Charsets.UTF_8)
        try {
            val emit: (String) -> Unit = { str ->
                if (w != null && count < MAX_LINES) {
                    w.write(str); w.newLine()
                }
                count++
                collector?.feed(str, source)
                onString?.invoke(str)
            }
            scanAscii(src, emit, check)
            if (utf16) scanUtf16(src.readBytes(), emit)
        } finally {
            w?.close()
        }
        return count
    }

    private fun scanAscii(f: File, emit: (String) -> Unit, check: () -> Unit) {
        val sb = StringBuilder()
        fun flush() {
            if (sb.length >= MIN_LEN) emit(sb.toString())
            sb.setLength(0)
        }
        FileInputStream(f).use { ins ->
            val buf = ByteArray(128 * 1024)
            while (true) {
                val n = ins.read(buf)
                if (n < 0) break
                for (i in 0 until n) {
                    val b = buf[i].toInt() and 0xFF
                    if (b in 0x20..0x7E || b == 0x09) {
                        sb.append(b.toChar())
                        if (sb.length >= MAX_LEN) flush()
                    } else flush()
                }
                check()
            }
            flush()
        }
    }

    private fun scanUtf16(data: ByteArray, emit: (String) -> Unit) {
        val sb = StringBuilder()
        fun flush() {
            if (sb.length >= MIN_LEN) emit(sb.toString())
            sb.setLength(0)
        }
        var i = 0
        while (i + 1 < data.size) {
            val lo = data[i].toInt() and 0xFF
            val hi = data[i + 1].toInt()
            if (hi == 0 && (lo in 0x20..0x7E)) {
                sb.append(lo.toChar()); i += 2
                if (sb.length >= MAX_LEN) flush()
            } else {
                flush(); i += 1
            }
        }
        flush()
    }
}
