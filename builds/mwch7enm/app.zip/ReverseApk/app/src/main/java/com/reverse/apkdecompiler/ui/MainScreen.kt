package com.reverse.apkdecompiler.ui

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Email
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.FolderZip
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.ManageSearch
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material.icons.rounded.Settings as SettingsIcon
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.reverse.apkdecompiler.R
import com.reverse.apkdecompiler.engine.AssetSorter
import com.reverse.apkdecompiler.engine.ExtractionReport
import com.reverse.apkdecompiler.engine.FindingsCollector
import java.io.File
import java.text.DateFormat
import java.util.Calendar
import java.util.Date

// ===================================================================== racine

@Composable
fun MainScreen(vm: MainViewModel) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val ctx = LocalContext.current

    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) vm.refreshAccess() }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.analyze(uri)
    }
    val legacyPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        vm.refreshAccess()
    }

    fun requestAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val uri = Uri.fromParts("package", ctx.packageName, null)
            try {
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, uri))
            } catch (e: Exception) {
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else legacyPerm.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
    }

    fun share(file: File) {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "application/zip"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(i, "Partager l'archive"))
    }

    BackHandler(enabled = ui.screen != Screen.HOME) { vm.back() }

    when (ui.screen) {
        Screen.HOME -> HomeScreen(ui, onOpen = vm::navigate)

        Screen.ANALYSE -> SubScreen("Analyser un APK", vm::back) { pad ->
            AnalyseScreen(
                ui, pad,
                onPick = { picker.launch(arrayOf("*/*")) },
                onCancel = vm::cancel,
                onGrant = ::requestAccess,
                onZip = vm::zip,
                onShare = { ui.zipFile?.let(::share) },
                onGo = vm::navigate,
                onOpenFolder = vm::openResultFolder,
                onHowItWorks = vm::showHowItWorks
            )
        }

        Screen.EXPLORER -> SubScreen("Explorateur", vm::back) { pad -> ExplorerScreen(ui, vm, pad) }

        Screen.SECRETS -> SubScreen("Chaînes & secrets", vm::back) { pad -> SecretsScreen(ui, pad, vm::navigate) }

        Screen.PROJECTS -> SubScreen("Mes décompilations", vm::back) { pad ->
            ProjectsScreen(ui, pad, onOpen = vm::openProject, onDelete = vm::requestDelete, onGo = vm::navigate)
        }

        Screen.ARCHIVES -> SubScreen("Archives ZIP", vm::back) { pad ->
            ArchivesScreen(ui, pad, onZip = vm::zip, onShare = ::share, onDelete = vm::requestDelete)
        }

        Screen.SETTINGS -> SubScreen("Réglages", vm::back) { pad -> SettingsScreen(ui, pad, ::requestAccess, vm::setScanSecrets) }
    }

    ui.preview?.let { p ->
        AlertDialog(
            onDismissRequest = vm::closePreview,
            confirmButton = { TextButton(onClick = vm::closePreview) { Text("Fermer") } },
            title = { Text(p.title, maxLines = 2) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    SelectionContainer { Mono(p.body, 11) }
                }
            }
        )
    }

    ui.pendingDelete?.let { f ->
        AlertDialog(
            onDismissRequest = vm::cancelDelete,
            title = { Text("Supprimer « ${f.name} » ?") },
            text = { Text("Les fichiers seront effacés définitivement de ton téléphone.") },
            confirmButton = { TextButton(onClick = vm::confirmDelete) { Text("Supprimer") } },
            dismissButton = { TextButton(onClick = vm::cancelDelete) { Text("Garder") } }
        )
    }
}

// ===================================================================== accueil

private data class Tile(
    val screen: Screen,
    val title: String,
    val caption: String,
    val icon: ImageVector,
    val color: Color
)

private val Tiles = listOf(
    Tile(Screen.ANALYSE, "Analyser", "Ouvre un APK et récupère tout ce qu'il contient", Icons.Rounded.ManageSearch, Color(0xFF4DB6AC)),
    Tile(Screen.EXPLORER, "Explorateur", "Fouille les fichiers extraits", Icons.Rounded.FolderOpen, Color(0xFFFFB74D)),
    Tile(Screen.SECRETS, "Chaînes & secrets", "URLs, adresses IP, clés repérées", Icons.Rounded.Key, Color(0xFFFF8A65)),
    Tile(Screen.PROJECTS, "Mes décompilations", "Tout ce que tu as déjà ouvert", Icons.Rounded.History, Color(0xFF9FA8DA)),
    Tile(Screen.ARCHIVES, "Archives ZIP", "Prêtes à être partagées", Icons.Rounded.FolderZip, Color(0xFFAED581)),
    Tile(Screen.SETTINGS, "Réglages", "Accès aux fichiers, dossier de sortie", Icons.Rounded.SettingsIcon, Color(0xFF4FC3F7))
)

@Composable
private fun HomeScreen(ui: UiState, onOpen: (Screen) -> Unit) {
    val hour = remember { Calendar.getInstance().get(Calendar.HOUR_OF_DAY) }
    val greeting = when {
        hour < 5 -> "Encore debout ?"
        hour < 12 -> "Bonjour !"
        hour < 18 -> "Salut !"
        else -> "Bonsoir !"
    }

    Scaffold(containerColor = MaterialTheme.colorScheme.background) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Box(Modifier.size(72.dp).clip(RoundedCornerShape(22.dp)).background(Color.White)) {
                    Image(
                        painterResource(R.drawable.ic_launcher_foreground),
                        contentDescription = "Logo Reverse APK",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize().scale(1.7f)
                    )
                }
                Column {
                    Text(greeting, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text(
                        "Ouvre un APK, regarde ce qu'il a dans le ventre.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            val r = ui.report
            if (ui.running || r != null) {
                val pct = if (ui.total > 0) ui.done * 100 / ui.total else null
                val title = if (ui.running) "Analyse en cours" else "Dernière analyse"
                val sub = if (ui.running) ui.phase + (pct?.let { " · $it %" } ?: "")
                else "${r?.appName} · ${(r?.extracted ?: 0) + (r?.partial ?: 0)} fichiers récupérés"
                Card(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).clickable { onOpen(Screen.ANALYSE) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Icon(
                            if (ui.running) Icons.Rounded.ManageSearch else Icons.Rounded.CheckCircle,
                            null, tint = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Column(Modifier.weight(1f)) {
                            Text(title, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer, maxLines = 1)
                        }
                    }
                }
            }

            Tiles.chunked(2).forEach { rowTiles ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    rowTiles.forEach { t -> MenuTile(t, Modifier.weight(1f)) { onOpen(t.screen) } }
                }
            }

            Text(
                "Tout reste sur ton téléphone. Rien n'est envoyé nulle part.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}

@Composable
private fun MenuTile(t: Tile, modifier: Modifier, onClick: () -> Unit) {
    Card(
        modifier.height(158.dp).clip(RoundedCornerShape(26.dp)).clickable(onClick = onClick),
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.SpaceBetween) {
            IconChip(t.icon, t.color)
            Column {
                Text(t.title, style = MaterialTheme.typography.titleMedium, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text(t.caption, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
            }
        }
    }
}

@Composable
private fun IconChip(icon: ImageVector, color: Color, size: Int = 48) {
    Box(
        Modifier.size(size.dp).clip(CircleShape).background(color.copy(alpha = 0.16f)),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = color) }
}

// ===================================================================== écran générique

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SubScreen(title: String, onBack: () -> Unit, content: @Composable (PaddingValues) -> Unit) {
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text(title, fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Retour") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        content = content
    )
}

@Composable
private fun EmptyState(
    icon: ImageVector, title: String, text: String,
    actionLabel: String? = null, onAction: () -> Unit = {}
) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        IconChip(icon, MaterialTheme.colorScheme.onSurfaceVariant, 72)
        Spacer(Modifier.height(16.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        Text(text, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (actionLabel != null) {
            Spacer(Modifier.height(16.dp))
            Button(onClick = onAction) { Text(actionLabel) }
        }
    }
}

// ===================================================================== analyse

@Composable
private fun AnalyseScreen(
    ui: UiState, pad: PaddingValues,
    onPick: () -> Unit, onCancel: () -> Unit, onGrant: () -> Unit,
    onZip: () -> Unit, onShare: () -> Unit, onGo: (Screen) -> Unit,
    onOpenFolder: (String) -> Unit, onHowItWorks: () -> Unit
) {
    val busy = ui.running || ui.zipping
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 20.dp, end = 20.dp, top = pad.calculateTopPadding() + 8.dp,
            bottom = pad.calculateBottomPadding() + 24.dp
        ),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        if (!ui.hasAccess) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF3A2E14))) {
                    Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Icon(Icons.Rounded.Warning, null, tint = Color(0xFFFFB74D))
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                "Sans l'accès aux fichiers, je range tout dans le dossier privé de l'appli.",
                                style = MaterialTheme.typography.bodyMedium
                            )
                            OutlinedButton(onClick = onGrant) { Text("Donner l'accès") }
                        }
                    }
                }
            }
        }

        item {
            Card(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).clickable(enabled = !busy, onClick = onPick),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    IconChip(Icons.Rounded.UploadFile, MaterialTheme.colorScheme.primary, 56)
                    Column {
                        Text("Choisir un APK", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text(
                            ui.selectedName ?: "Pioche-le dans tes fichiers, rien à installer.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 2
                        )
                    }
                }
            }
        }

        if (busy) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(ui.phase, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                        if (ui.total > 0) {
                            LinearProgressIndicator(progress = { ui.done.toFloat() / ui.total }, modifier = Modifier.fillMaxWidth())
                            Text("${ui.done} sur ${ui.total}", style = MaterialTheme.typography.bodySmall)
                        } else LinearProgressIndicator(Modifier.fillMaxWidth())
                        if (ui.current.isNotEmpty()) Mono(ui.current, 11)
                        if (ui.running) TextButton(onClick = onCancel) { Text("Annuler") }
                    }
                }
            }
        }

        ui.error?.let { err ->
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                    Text(err, Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onErrorContainer)
                }
            }
        }

        ui.report?.let { r ->
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            IconChip(Icons.Rounded.CheckCircle, Color(0xFFAED581))
                            Column {
                                Text(r.appName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                                Mono(r.packageName ?: "package illisible (manifeste protégé ?)", 11)
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Stat("Fichiers", (r.extracted + r.partial).toString(), Modifier.weight(1f))
                            Stat("DEX", r.dexCount.toString(), Modifier.weight(1f))
                            Stat("Libs .so", r.nativeLibCount.toString(), Modifier.weight(1f))
                        }
                        Text(
                            "${r.partial} partiel(s), ${r.failed} échec(s) · ${fmt(r.totalBytes)} · ${r.mode}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Mono(r.outputDir.absolutePath, 11)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { onGo(Screen.EXPLORER) }) { Text("Explorer") }
                            if (r.secretsScanned) OutlinedButton(onClick = { onGo(Screen.SECRETS) }) { Text("Secrets") }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = onZip, enabled = !ui.zipping) { Text("Créer le ZIP") }
                            if (ui.zipFile != null) OutlinedButton(onClick = onShare) { Text("Partager") }
                        }
                        ui.zipFile?.let { Mono(it.absolutePath, 11) }
                    }
                }
            }
        }

        ui.report?.let { r ->
            item { TechCard(r, onOpenFolder, onHowItWorks) }
        }

        if (ui.logs.isNotEmpty()) {
            item { LogsCard(ui.logs) }
        }
    }
}

@Composable
private fun TechCard(r: ExtractionReport, onOpenFolder: (String) -> Unit, onHowItWorks: () -> Unit) {
    val t = r.tech
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                IconChip(Icons.Rounded.Code, Color(0xFFBA68C8))
                Column {
                    Text("Technologies", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text(t.primaryTech, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Text("Langage principal", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(t.primaryLanguage, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
            if (t.languages.size > 1) {
                Text("Aussi : " + t.languages.drop(1).joinToString(" · "), style = MaterialTheme.typography.bodySmall)
            }
            if (t.technologies.isNotEmpty()) {
                Text(
                    "Moteurs / frameworks : " + t.technologies.joinToString(", ") { it.name },
                    style = MaterialTheme.typography.bodySmall
                )
            }
            t.uiToolkit?.let { Text("Interface : $it", style = MaterialTheme.typography.bodySmall) }
            if (t.obfuscated) {
                Text("Code Java/Kotlin obfusqué", style = MaterialTheme.typography.bodySmall, color = Color(0xFFFFB74D))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Stat("Fichiers moteur", r.sorted.engineFiles.toString(), Modifier.weight(1f))
                Stat("Modèles 3D", r.sorted.models.toString(), Modifier.weight(1f))
                Stat("SDK tiers", t.sdks.size.toString(), Modifier.weight(1f))
            }
            if (r.sorted.carvedGlb > 0) {
                Text(
                    "${r.sorted.carvedGlb} .glb retrouvé(s) à l'intérieur d'archives du jeu",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Button(onClick = onHowItWorks, modifier = Modifier.fillMaxWidth()) { Text("Comment l'appli fonctionne") }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { onOpenFolder(AssetSorter.ENGINES_DIR) },
                    enabled = r.sorted.engineFiles > 0,
                    modifier = Modifier.weight(1f)
                ) { Text("Moteurs") }
                OutlinedButton(
                    onClick = { onOpenFolder(AssetSorter.MODELS_DIR) },
                    enabled = r.sorted.models > 0,
                    modifier = Modifier.weight(1f)
                ) { Text("Modèles 3D") }
            }
        }
    }
}

@Composable
private fun LogsCard(logs: List<String>) {
    var open by remember { mutableStateOf(false) }
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth().clickable { open = !open }, verticalAlignment = Alignment.CenterVertically) {
                Text("Détails techniques", Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                Icon(if (open) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore, null)
            }
            if (open) logs.takeLast(40).forEach { Mono(it, 11) }
        }
    }
}

@Composable
private fun Stat(label: String, value: String, modifier: Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.background).padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ===================================================================== explorateur

@Composable
private fun ExplorerScreen(ui: UiState, vm: MainViewModel, pad: PaddingValues) {
    val root = ui.explorerRoot
    val cur = ui.explorerDir
    if (root == null || cur == null) {
        Box(Modifier.padding(pad)) {
            EmptyState(
                Icons.Rounded.FolderOpen, "Rien à explorer pour l'instant",
                "Analyse un APK, ou rouvre une ancienne décompilation.",
                "Mes décompilations"
            ) { vm.navigate(Screen.PROJECTS) }
        }
        return
    }
    Column(Modifier.fillMaxSize().padding(pad)) {
        Mono(cur.relativeTo(root.parentFile ?: root).path, 12, Modifier.padding(20.dp, 4.dp, 20.dp, 8.dp))
        LazyColumn(Modifier.fillMaxSize()) {
            if (cur != root) {
                item {
                    FileRow(Icons.Rounded.ArrowUpward, MaterialTheme.colorScheme.onSurfaceVariant, "Dossier parent", null) { vm.up() }
                }
            }
            items(ui.explorerEntries, key = { it.absolutePath }) { f ->
                FileRow(
                    if (f.isDirectory) Icons.Rounded.Folder else Icons.Rounded.Description,
                    if (f.isDirectory) Color(0xFFFFB74D) else MaterialTheme.colorScheme.onSurfaceVariant,
                    f.name,
                    if (f.isFile) fmt(f.length()) else null
                ) { if (f.isDirectory) vm.openDir(f) else vm.openFile(f) }
            }
        }
    }
}

@Composable
private fun FileRow(icon: ImageVector, tint: Color, name: String, meta: String?, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Icon(icon, null, tint = tint)
        Text(name, Modifier.weight(1f), maxLines = 1)
        if (meta != null) Text(meta, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ===================================================================== secrets

@Composable
private fun SecretsScreen(ui: UiState, pad: PaddingValues, onGo: (Screen) -> Unit) {
    val r = ui.report
    if (r == null) {
        Box(Modifier.padding(pad)) {
            EmptyState(
                Icons.Rounded.Key, "Pas encore de chaînes à te montrer",
                "Lance une analyse : je trie les URLs, adresses IP, emails et clés trouvées dans le code.",
                "Analyser un APK"
            ) { onGo(Screen.ANALYSE) }
        }
        return
    }
    if (!r.secretsScanned) {
        Box(Modifier.padding(pad)) {
            EmptyState(
                Icons.Rounded.Lock, "Recherche désactivée",
                "Les emails, clés, URLs et IP sont ignorés. Active-la dans Réglages puis relance l'analyse.",
                "Ouvrir les réglages"
            ) { onGo(Screen.SETTINGS) }
        }
        return
    }
    if (r.findings.isEmpty()) {
        Box(Modifier.padding(pad)) {
            EmptyState(Icons.Rounded.Lock, "Rien de notable", "Aucune URL, IP ou clé repérée dans ${r.appName}.")
        }
        return
    }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 20.dp, end = 20.dp, top = pad.calculateTopPadding() + 8.dp,
            bottom = pad.calculateBottomPadding() + 24.dp
        ),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                "Trouvé dans ${r.appName}. La liste complète est dans _analysis/findings.json.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        r.findings.forEach { (cat, items) ->
            item(key = cat) { FindingsSection(cat, items) }
        }
    }
}

private fun categoryStyle(cat: String): Pair<ImageVector, Color> = when (cat) {
    FindingsCollector.CAT_URL -> Icons.Rounded.Link to Color(0xFF4FC3F7)
    FindingsCollector.CAT_IP -> Icons.Rounded.Public to Color(0xFF9FA8DA)
    FindingsCollector.CAT_EMAIL -> Icons.Rounded.Email to Color(0xFFAED581)
    else -> Icons.Rounded.Key to Color(0xFFFF8A65)
}

@Composable
private fun FindingsSection(title: String, items: List<Pair<String, String>>) {
    var open by remember { mutableStateOf(false) }
    val (icon, color) = categoryStyle(title)
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                Modifier.fillMaxWidth().clickable { open = !open },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                IconChip(icon, color, 40)
                Text("$title · ${items.size}", Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                Icon(if (open) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore, null)
            }
            if (open) {
                SelectionContainer {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items.take(100).forEach { (v, src) ->
                            Column {
                                Mono(v, 12)
                                Text("dans $src", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
                if (items.size > 100) {
                    Text("… et ${items.size - 100} autres dans findings.json", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

// ===================================================================== projets

@Composable
private fun ProjectsScreen(
    ui: UiState, pad: PaddingValues,
    onOpen: (File) -> Unit, onDelete: (File) -> Unit, onGo: (Screen) -> Unit
) {
    if (ui.projects.isEmpty()) {
        Box(Modifier.padding(pad)) {
            EmptyState(
                Icons.Rounded.History, "Ton historique est vide",
                "Les APK que tu analyses apparaîtront ici.",
                "Analyser un APK"
            ) { onGo(Screen.ANALYSE) }
        }
        return
    }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 20.dp, end = 20.dp, top = pad.calculateTopPadding() + 8.dp,
            bottom = pad.calculateBottomPadding() + 24.dp
        ),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(ui.projects, key = { it.dir.absolutePath }) { p ->
            ListCard(
                Icons.Rounded.Folder, Color(0xFFFFB74D), p.dir.name,
                "${fmtDate(p.modified)} · ${fmt(p.size)}",
                onClick = { onOpen(p.dir) }
            ) {
                IconButton(onClick = { onDelete(p.dir) }) { Icon(Icons.Rounded.Delete, "Supprimer") }
            }
        }
    }
}

// ===================================================================== archives

@Composable
private fun ArchivesScreen(
    ui: UiState, pad: PaddingValues,
    onZip: () -> Unit, onShare: (File) -> Unit, onDelete: (File) -> Unit
) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(
            start = 20.dp, end = 20.dp, top = pad.calculateTopPadding() + 8.dp,
            bottom = pad.calculateBottomPadding() + 24.dp
        ),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Button(onClick = onZip, enabled = ui.report != null && !ui.zipping, modifier = Modifier.fillMaxWidth()) {
                Text(if (ui.report != null) "Archiver « ${ui.report.appName} »" else "Analyse d'abord un APK pour l'archiver")
            }
        }
        if (ui.zipping) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
        if (ui.archives.isEmpty()) {
            item {
                Text(
                    "Aucune archive pour le moment.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 12.dp)
                )
            }
        }
        items(ui.archives, key = { it.absolutePath }) { f ->
            ListCard(
                Icons.Rounded.FolderZip, Color(0xFFAED581), f.name,
                "${fmtDate(f.lastModified())} · ${fmt(f.length())}",
                onClick = { onShare(f) }
            ) {
                Row {
                    IconButton(onClick = { onShare(f) }) { Icon(Icons.Rounded.Share, "Partager") }
                    IconButton(onClick = { onDelete(f) }) { Icon(Icons.Rounded.Delete, "Supprimer") }
                }
            }
        }
    }
}

@Composable
private fun ListCard(
    icon: ImageVector, color: Color, title: String, subtitle: String,
    onClick: () -> Unit, trailing: @Composable () -> Unit
) {
    Card(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            IconChip(icon, color)
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            trailing()
        }
    }
}

// ===================================================================== réglages

@Composable
private fun SettingsScreen(ui: UiState, pad: PaddingValues, onGrant: () -> Unit, onScanSecrets: (Boolean) -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    IconChip(
                        if (ui.hasAccess) Icons.Rounded.CheckCircle else Icons.Rounded.Warning,
                        if (ui.hasAccess) Color(0xFFAED581) else Color(0xFFFFB74D)
                    )
                    Text(
                        if (ui.hasAccess) "Accès aux fichiers accordé" else "Accès aux fichiers refusé",
                        style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold
                    )
                }
                Text(
                    if (ui.hasAccess) "Les décompilations sont rangées à la racine de ton stockage."
                    else "Sans cet accès, tout est rangé dans le dossier privé de l'appli, plus dur à retrouver.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (!ui.hasAccess) Button(onClick = onGrant) { Text("Donner l'accès") }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Dossier de sortie", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                SelectionContainer { Mono(ui.outputBase, 12) }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Row(
                Modifier.fillMaxWidth().clickable { onScanSecrets(!ui.scanSecrets) }.padding(20.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Chercher emails, clés, URLs et IP", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Text(
                        if (ui.scanSecrets) "Activé : les chaînes du code sont listées dans « Secrets »."
                        else "Ignoré : analyse plus rapide, rien n'est collecté. Les moteurs et langages restent détectés.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(checked = ui.scanSecrets, onCheckedChange = onScanSecrets)
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("À propos", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text("Reverse APK · version 1.1", style = MaterialTheme.typography.bodyMedium)
                Text(
                    "Extraction tolérante aux erreurs : un manifeste corrompu n'empêche jamais de récupérer le reste.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

// ===================================================================== utilitaires

@Composable
private fun Mono(text: String, size: Int = 12, modifier: Modifier = Modifier) {
    Text(text, modifier = modifier, fontFamily = FontFamily.Monospace, fontSize = size.sp)
}

private fun fmt(b: Long): String = when {
    b >= 1L shl 30 -> "%.1f Go".format(b / 1073741824.0)
    b >= 1L shl 20 -> "%.1f Mo".format(b / 1048576.0)
    b >= 1L shl 10 -> "%.1f Ko".format(b / 1024.0)
    else -> "$b o"
}

private fun fmtDate(ms: Long): String =
    DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(ms))
