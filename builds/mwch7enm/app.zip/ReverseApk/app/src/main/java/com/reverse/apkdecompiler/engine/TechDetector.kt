package com.reverse.apkdecompiler.engine

/**
 * Identifie le(s) moteur(s) / framework(s) et le(s) langage(s) d'un APK
 * à partir :
 *   - des chemins des fichiers extraits (lib/<abi>/libunity.so, assets/flutter_assets/…)
 *   - des noms de classes trouvés dans les .dex (Lkotlin/…, Landroidx/compose/…)
 *   - des permissions / composants du manifeste.
 *
 * 100 % JVM (aucune dépendance Android) → testable hors téléphone.
 */
class TechDetector {

    /** Une technologie connue : comment la reconnaître et quels fichiers forment son « moteur ». */
    class Signature(
        val name: String,
        val kind: String,
        val language: String,
        /** Un seul chemin qui correspond suffit à détecter la techno. */
        val detect: List<Regex>,
        /** Fichiers rangés dans _moteurs/<name>/ (par défaut : ceux de [detect]). */
        val engineFiles: List<Regex> = detect,
        /** Préfixes de paquets Java (format dex « a/b/c ») qui confirment la techno. */
        val dexPackages: List<String> = emptyList(),
        val howItWorks: String,
        val whereToLook: String
    )

    data class Detected(
        val name: String,
        val kind: String,
        val language: String,
        val evidence: List<String>,
        val howItWorks: String,
        val whereToLook: String
    )

    private val dexPrefixes = HashSet<String>()
    private var dexClassCount = 0
    private var obfuscatedClassCount = 0
    private val manifestStrings = LinkedHashSet<String>()

    // ------------------------------------------------------------------ alimentation

    /** Chaîne extraite d'un .dex. */
    fun feedDexString(s: String) {
        if (s.indexOf('/') < 0 || s.indexOf(';') < 0) return
        DESCRIPTOR.findAll(s).forEach { m ->
            val path = m.groupValues[1]
            dexClassCount++
            val segs = path.split('/')
            if (segs.size >= 2 && segs.dropLast(1).all { it.length <= 2 } && segs.last().length <= 3) {
                obfuscatedClassCount++
            }
            if (dexPrefixes.size < MAX_PREFIXES) {
                // a, a/b, a/b/c → permet de tester n'importe quelle profondeur de préfixe
                val pk = segs.dropLast(1)
                for (d in 1..minOf(pk.size, 4)) dexPrefixes.add(pk.take(d).joinToString("/"))
            }
        }
    }

    /** Chaîne extraite de l'AndroidManifest binaire. */
    fun feedManifestString(s: String) {
        if (manifestStrings.size < 20_000) manifestStrings.add(s.trim())
    }

    private fun hasDex(prefix: String) = dexPrefixes.contains(prefix.trimEnd('/'))

    // ------------------------------------------------------------------ analyse

    /**
     * @param paths chemins relatifs (séparateur « / ») de tous les fichiers extraits.
     * @param pmPermissions / pmActivities… : infos lues par Android si le manifeste est lisible.
     */
    fun analyze(
        paths: List<String>,
        pmPermissions: List<String> = emptyList(),
        pmActivities: List<String> = emptyList(),
        pmServices: List<String> = emptyList(),
        pmReceivers: List<String> = emptyList(),
        pmProviders: List<String> = emptyList()
    ): TechProfile {
        val lower = paths.map { it.lowercase() }

        // ---- moteurs / frameworks
        val detected = ArrayList<Detected>()
        val ownerOf = HashMap<String, String>() // chemin relatif → nom du moteur
        for (sig in SIGNATURES) {
            val ev = LinkedHashSet<String>()
            lower.forEachIndexed { i, p -> if (sig.detect.any { it.containsMatchIn(p) }) ev.add(paths[i]) }
            sig.dexPackages.filter { hasDex(it) }.forEach { ev.add("classes : ${it.replace('/', '.')}.*") }
            if (ev.isEmpty()) continue
            // un paquet dex seul ne suffit pas pour les moteurs natifs (ex. SDK Unity Ads ≠ jeu Unity)
            val fileEvidence = ev.any { !it.startsWith("classes : ") }
            if (!fileEvidence && sig.kind == KIND_GAME) continue
            detected += Detected(
                sig.name, sig.kind, refineLanguage(sig, lower), ev.take(8).toList(),
                sig.howItWorks, sig.whereToLook
            )
            lower.forEachIndexed { i, p ->
                if (sig.engineFiles.any { it.containsMatchIn(p) }) ownerOf.putIfAbsent(paths[i], sig.name)
            }
        }

        // ---- code natif non revendiqué → C/C++ NDK
        val soFiles = paths.filter { it.lowercase().endsWith(".so") }
        val unclaimedSo = soFiles.filter { it !in ownerOf.keys && !isSupportLib(it) }

        // ---- langages
        val dexCount = lower.count { it.endsWith(".dex") }
        val languages = ArrayList<String>()
        detected.filter { it.kind != KIND_LIB3D }.forEach { languages.add(it.language) }
        val kotlin = hasDex("kotlin") || lower.any { it.endsWith(".kotlin_module") || it.endsWith(".kotlin_builtins") }
        if (dexCount > 0) {
            if (kotlin) languages.add("Kotlin (code Android / JVM)")
            languages.add(
                if (kotlin) "Java (bibliothèques + code Android)" else "Java (code Android / JVM)"
            )
        }
        if (unclaimedSo.isNotEmpty()) languages.add("C / C++ natif (NDK) — ${unclaimedSo.size} lib(s) .so")
        val distinctLang = languages.distinct()

        val ui = when {
            detected.any { it.kind == KIND_GAME } -> "Rendu par le moteur de jeu (OpenGL ES / Vulkan)"
            detected.any { it.name == "Flutter" } -> "Widgets Flutter (dessinés par le moteur Skia/Impeller)"
            detected.any { it.name == "React Native" } -> "Composants React Native (vues Android natives)"
            detected.any { it.kind == KIND_WEB } -> "Pages web (HTML/CSS) dans une WebView"
            hasDex("androidx/compose") -> "Jetpack Compose"
            dexCount > 0 -> "Vues Android classiques (XML / View)"
            else -> null
        }

        val abis = paths.mapNotNull { ABI.find(it)?.groupValues?.get(1) }.distinct().sorted()

        val sdks = SDKS.filter { (_, prefixes) -> prefixes.any { hasDex(it) } }.map { it.first }

        // ---- manifeste (Android d'abord, sinon chaînes brutes)
        val perms = (pmPermissions.ifEmpty {
            manifestStrings.filter { PERMISSION.matches(it) }
        }).distinct()
        val compRaw = manifestStrings.filter { CLASSNAME.matches(it) }
        val activities = pmActivities.ifEmpty {
            compRaw.filter { c -> c.endsWith("Activity") || KNOWN_ENTRIES.any { c.endsWith(it) } }
        }.distinct()
        val services = pmServices.ifEmpty { compRaw.filter { it.endsWith("Service") } }.distinct()
        val receivers = pmReceivers.ifEmpty { compRaw.filter { it.endsWith("Receiver") } }.distinct()
        val providers = pmProviders.ifEmpty { compRaw.filter { it.endsWith("Provider") } }.distinct()

        val entry = activities.firstOrNull { a -> KNOWN_ENTRIES.any { a.contains(it) } }
            ?: activities.firstOrNull { it.endsWith(".MainActivity") }
            ?: activities.firstOrNull()

        val obfuscated = dexClassCount > 200 && obfuscatedClassCount.toDouble() / dexClassCount > 0.30

        return TechProfile(
            technologies = detected,
            languages = distinctLang,
            uiToolkit = ui,
            abis = abis,
            sdks = sdks,
            permissions = perms,
            activities = activities,
            services = services,
            receivers = receivers,
            providers = providers,
            entryActivity = entry,
            dexCount = dexCount,
            nativeLibs = soFiles.size,
            unclaimedNativeLibs = unclaimedSo,
            obfuscated = obfuscated,
            engineFileOwner = ownerOf
        )
    }

    private fun refineLanguage(sig: Signature, lower: List<String>): String = when (sig.name) {
        "Unity" -> if (lower.any { it.endsWith("libil2cpp.so") })
            "C# (Unity, compilé en C++ natif via IL2CPP)"
        else "C# (Unity, scripting Mono — DLL .NET lisibles)"
        "Godot" -> if (lower.any { it.contains("godotsharp") || it.contains("libmonosgen") || it.contains(".godot/mono") })
            "GDScript + C# (Godot .NET)" else "GDScript (Godot)"
        "Cocos2d-x / Cocos Creator" -> when {
            lower.any { it.endsWith("libcocos2djs.so") || it.endsWith(".jsc") } -> "JavaScript / TypeScript (Cocos)"
            lower.any { it.endsWith("libcocos2dlua.so") || it.endsWith(".luac") } -> "Lua (Cocos)"
            else -> "C++ (Cocos2d-x)"
        }
        "React Native" -> if (lower.any { it.endsWith("libhermes.so") })
            "JavaScript / TypeScript (bytecode Hermes)" else "JavaScript / TypeScript"
        else -> sig.language
    }

    private fun isSupportLib(p: String): Boolean {
        val n = p.substringAfterLast('/').lowercase()
        return SUPPORT_SO.any { n.startsWith(it) }
    }

    companion object {
        const val KIND_GAME = "Moteur de jeu"
        const val KIND_APP = "Framework d'application"
        const val KIND_WEB = "Application web (hybride)"
        const val KIND_LIB3D = "Bibliothèque 3D / AR"

        private const val MAX_PREFIXES = 60_000
        private val DESCRIPTOR = Regex("""L([A-Za-z_$][\w$]*(?:/[\w$]+)+);""")
        private val ABI = Regex("""^lib/([^/]+)/[^/]+\.so$""", RegexOption.IGNORE_CASE)
        private val PERMISSION = Regex("""^[a-zA-Z][\w.]*\.permission\.[A-Z0-9_]+$""")
        private val CLASSNAME = Regex("""^[a-zA-Z_][\w]*(\.[\w$]+){1,}$""")

        private fun so(vararg names: String) = names.map { Regex("""(^|/)lib/[^/]+/${it}$""") }
        private fun r(vararg p: String) = p.map { Regex(it) }

        private val KNOWN_ENTRIES = listOf(
            "UnityPlayerActivity", "UnityPlayerGameActivity", "org.godotengine.godot.GodotApp",
            "godot.GodotApp", "FlutterActivity", "MainActivity", "GameActivity", "SplashActivity",
            "AppActivity", "RunnerActivity", "NativeActivity"
        )

        /** Libs natives utilitaires qui ne trahissent pas un langage particulier. */
        private val SUPPORT_SO = listOf(
            "libc++_shared", "libcrashlytics", "libdatastore", "libimage_processing_util",
            "libsurface_util", "libjnidispatch", "libsqlcipher", "libtensorflowlite", "libbarhopper",
            "libmlkit", "libandroidx.graphics.path", "libpl_droidsonroids_gif", "libgifimage"
        )

        val SIGNATURES: List<Signature> = listOf(
            Signature(
                "Unity", KIND_GAME, "C# (Unity)",
                detect = so("libunity\\.so") + r("^assets/bin/data/(globalgamemanagers|data\\.unity3d|unity default resources)"),
                engineFiles = so("libunity\\.so", "libil2cpp\\.so", "libmain\\.so", "libmono[\\w.-]*\\.so", "libmonobdwgc[\\w.-]*\\.so") +
                    r("global-metadata\\.dat$", "^assets/bin/data/managed/[^/]+\\.dll$", "^assets/bin/data/(globalgamemanagers|data\\.unity3d)$"),
                dexPackages = listOf("com/unity3d/player"),
                howItWorks = "Le code Java/Kotlin n'est qu'une coquille Android : UnityPlayerActivity démarre, charge " +
                    "libunity.so (le moteur) puis le code du jeu. Avec IL2CPP, les scripts C# sont convertis en C++ et " +
                    "compilés dans libil2cpp.so ; les noms des classes/méthodes C# restent dans global-metadata.dat. " +
                    "Avec Mono, les scripts sont des DLL .NET (Assembly-CSharp.dll) dans assets/bin/Data/Managed. " +
                    "Scènes, textures, sons et modèles 3D sont empaquetés dans assets/bin/Data (fichiers .assets / data.unity3d).",
                whereToLook = "IL2CPP : Il2CppDumper avec libil2cpp.so + global-metadata.dat. Mono : ouvrir Assembly-CSharp.dll " +
                    "dans ILSpy/dnSpy. Ressources : AssetStudio sur assets/bin/Data."
            ),
            Signature(
                "Unreal Engine", KIND_GAME, "C++ (Unreal Engine, + Blueprints)",
                detect = so("libue4\\.so", "libunreal\\.so") + r("/content/paks/[^/]+\\.pak$"),
                engineFiles = so("libue4\\.so", "libunreal\\.so") + r("\\.pak$", "ue4commandline\\.txt$"),
                dexPackages = listOf("com/epicgames/ue4", "com/epicgames/unreal"),
                howItWorks = "GameActivity (Java) lance libUE4.so / libUnreal.so, qui contient TOUT le jeu compilé en C++ " +
                    "(moteur + logique + Blueprints convertis). Les ressources (maps, meshes, textures) sont dans des archives .pak, " +
                    "souvent dans l'OBB ou dans assets/.",
                whereToLook = "Les .pak s'ouvrent avec FModel / UModel (UE Viewer). La logique est en code machine ARM dans la .so " +
                    "(Ghidra / IDA)."
            ),
            Signature(
                "Godot", KIND_GAME, "GDScript (Godot)",
                detect = so("libgodot_android\\.so") + r("\\.pck$", "^assets/project\\.binary$", "^assets/\\.godot/"),
                engineFiles = so("libgodot_android\\.so", "libmonosgen[\\w.-]*\\.so") +
                    r("\\.pck$", "^assets/project\\.binary$", "^assets/\\.godot/global_script_class_cache\\.cfg$",
                        "^assets/\\.godot/uid_cache\\.bin$", "godotsharp\\.dll$"),
                dexPackages = listOf("org/godotengine/godot"),
                howItWorks = "GodotApp (Java/Kotlin) démarre et charge libgodot_android.so (le moteur, en C++). Le jeu lui-même " +
                    "est dans assets/ (ou un .pck) : project.binary = réglages du projet, scènes .tscn/.scn, scripts .gd/.gdc " +
                    "(GDScript, parfois compilé en tokens), ressources importées dans .godot/imported/ (meshes, textures). " +
                    "Les modèles .glb sont généralement convertis en .scn/.mesh à l'export.",
                whereToLook = "GDRE Tools (gdsdecomp) récupère un projet Godot complet (scripts .gd, scènes, et reconvertit " +
                    "souvent les meshes en .glb)."
            ),
            Signature(
                "Flutter", KIND_APP, "Dart (Flutter)",
                detect = so("libflutter\\.so") + r("^assets/flutter_assets/"),
                engineFiles = so("libflutter\\.so", "libapp\\.so") +
                    r("^assets/flutter_assets/(kernel_blob\\.bin|isolate_snapshot_data|vm_snapshot_data|assetmanifest\\.(json|bin)|fontmanifest\\.json|nativeassetsmanifest\\.json)$"),
                dexPackages = listOf("io/flutter"),
                howItWorks = "MainActivity hérite de FlutterActivity. libflutter.so est le moteur (C++/Skia ou Impeller) qui dessine " +
                    "tout l'écran lui-même. Le code Dart de l'appli est compilé AOT en code machine dans libapp.so (version release) " +
                    "ou en kernel_blob.bin (debug). Images, polices et JSON sont dans assets/flutter_assets/.",
                whereToLook = "Release : blutter (ou reFlutter) sur libapp.so pour retrouver classes et fonctions Dart. " +
                    "Debug : les chaînes du code sont lisibles dans kernel_blob.bin."
            ),
            Signature(
                "React Native", KIND_APP, "JavaScript / TypeScript",
                detect = so("libreactnativejni\\.so", "libreactnative\\.so", "libhermes\\.so", "libjsc\\.so") +
                    r("^assets/index\\.android\\.bundle$"),
                engineFiles = so("libreactnativejni\\.so", "libreactnative\\.so", "libhermes\\.so", "libhermes_executor\\.so", "libjsc\\.so") +
                    r("^assets/index\\.android\\.bundle$"),
                dexPackages = listOf("com/facebook/react"),
                howItWorks = "MainActivity (ReactActivity) lance le moteur JavaScript (Hermes ou JSC). Toute la logique de l'appli " +
                    "est dans assets/index.android.bundle (JS ou bytecode Hermes) et pilote des vues Android natives via le « bridge ».",
                whereToLook = "Si le bundle est du JS texte : l'ouvrir directement (le formater). Si c'est du bytecode Hermes : " +
                    "hermes-dec / hbctool."
            ),
            Signature(
                "Xamarin / .NET MAUI", KIND_APP, "C# (.NET)",
                detect = so("libmonodroid\\.so", "libxamarin-app\\.so", "libmonosgen-2\\.0\\.so", "libassemblies\\.[\\w-]+\\.blob\\.so") +
                    r("^assemblies/[^/]+\\.dll$", "assemblies\\.blob$"),
                engineFiles = so("libmonodroid\\.so", "libxamarin-app\\.so", "libmonosgen-2\\.0\\.so", "libassemblies\\.[\\w-]+\\.blob\\.so") +
                    r("^assemblies/.*\\.(dll|blob|manifest)$"),
                dexPackages = listOf("mono/android", "crc64"),
                howItWorks = "Le runtime Mono/.NET (libmonodroid.so + libmonosgen) charge les assemblies C# (.dll) au démarrage. " +
                    "Les classes Java « crc64… » ne sont que des ponts générés vers le code C#.",
                whereToLook = "Extraire les .dll (pyxamstore pour assemblies.blob), puis les ouvrir dans ILSpy / dnSpy."
            ),
            Signature(
                "Capacitor / Ionic", KIND_WEB, "HTML / CSS / JavaScript (TypeScript)",
                detect = r("^assets/capacitor\\.config\\.json$", "^assets/public/index\\.html$"),
                engineFiles = r("^assets/capacitor\\.config\\.json$", "^assets/capacitor\\.plugins\\.json$", "^assets/public/index\\.html$"),
                dexPackages = listOf("com/getcapacitor"),
                howItWorks = "L'appli est un site web embarqué : BridgeActivity ouvre une WebView qui charge assets/public/index.html. " +
                    "Les plugins Capacitor font le pont vers les fonctions natives (caméra, fichiers…).",
                whereToLook = "Tout le code est lisible dans assets/public/ (JS souvent minifié : le reformater)."
            ),
            Signature(
                "Cordova / PhoneGap", KIND_WEB, "HTML / CSS / JavaScript",
                detect = r("^assets/www/cordova\\.js$", "^assets/www/index\\.html$"),
                engineFiles = r("^assets/www/cordova\\.js$", "^assets/www/cordova_plugins\\.js$", "^res/xml/config\\.xml$"),
                dexPackages = listOf("org/apache/cordova"),
                howItWorks = "CordovaActivity ouvre une WebView qui charge assets/www/index.html ; les plugins Cordova " +
                    "exposent les fonctions natives au JavaScript.",
                whereToLook = "Code lisible dans assets/www/."
            ),
            Signature(
                "Cocos2d-x / Cocos Creator", KIND_GAME, "C++ (Cocos2d-x)",
                detect = so("libcocos2dcpp\\.so", "libcocos2djs\\.so", "libcocos2dlua\\.so", "libcocos\\.so", "libcocos2d\\.so"),
                engineFiles = so("libcocos2dcpp\\.so", "libcocos2djs\\.so", "libcocos2dlua\\.so", "libcocos\\.so", "libcocos2d\\.so") +
                    r("\\.jsc$", "\\.luac$"),
                dexPackages = listOf("org/cocos2dx"),
                howItWorks = "AppActivity (Cocos2dxActivity) charge la lib native Cocos. Selon la variante, la logique du jeu est " +
                    "en C++ dans la .so, ou en scripts JS (.js/.jsc) / Lua (.lua/.luac) dans assets/.",
                whereToLook = ".jsc/.luac sont souvent chiffrés (XXTEA) : la clé se trouve dans la .so."
            ),
            Signature(
                "libGDX", KIND_GAME, "Java / Kotlin (libGDX)",
                detect = so("libgdx\\.so", "libgdx64\\.so"),
                engineFiles = so("libgdx\\.so", "libgdx64\\.so", "libgdx-box2d\\.so", "libgdx-bullet\\.so", "libgdx-freetype\\.so"),
                dexPackages = listOf("com/badlogic/gdx"),
                howItWorks = "Moteur de jeu Java : AndroidLauncher démarre l'appli libGDX ; la logique du jeu est dans les .dex " +
                    "(donc décompilable), les .so ne contiennent que la partie native du moteur (maths, physique).",
                whereToLook = "jadx sur les classes.dex ; ressources dans assets/."
            ),
            Signature(
                "Defold", KIND_GAME, "Lua (Defold)",
                detect = so("libdmengine\\.so", "libdmengine_release\\.so"),
                engineFiles = so("libdmengine\\.so", "libdmengine_release\\.so") + r("^assets/game\\.(arcd|arci|dmanifest|projectc|public\\.der)$"),
                howItWorks = "libdmengine.so exécute les scripts Lua compilés et les ressources rangées dans assets/game.arcd.",
                whereToLook = "Archives game.arcd/game.arci (format Defold)."
            ),
            Signature(
                "GameMaker", KIND_GAME, "GML (GameMaker Language)",
                detect = so("libyoyo\\.so") + r("game\\.droid$"),
                engineFiles = so("libyoyo\\.so") + r("game\\.droid$"),
                dexPackages = listOf("com/yoyogames"),
                howItWorks = "libyoyo.so (runner GameMaker) lit game.droid, qui contient le bytecode GML, les sprites et les sons.",
                whereToLook = "UndertaleModTool ouvre game.droid."
            ),
            Signature(
                "Solar2D (Corona)", KIND_GAME, "Lua",
                detect = so("libcorona\\.so", "libsolar2d\\.so") + r("resource\\.car$"),
                engineFiles = so("libcorona\\.so", "libsolar2d\\.so", "liblua\\.so") + r("resource\\.car$"),
                dexPackages = listOf("com/ansca/corona"),
                howItWorks = "libcorona.so exécute les scripts Lua compilés stockés dans resource.car.",
                whereToLook = "resource.car (archive Lua compilé)."
            ),
            Signature(
                "Kivy / Python", KIND_APP, "Python",
                detect = so("libpython[\\d.]+m?\\.so", "libchaquopy_java\\.so") + r("^assets/private\\.tar$", "^assets/chaquopy/"),
                engineFiles = so("libpython[\\d.]+m?\\.so", "libmain\\.so", "libsdl2\\.so", "libchaquopy_java\\.so") +
                    r("^assets/private\\.tar$", "^assets/chaquopy/"),
                dexPackages = listOf("org/kivy", "com/chaquo/python"),
                howItWorks = "Un interpréteur Python (libpython.so) est embarqué ; le code Python de l'appli est dans " +
                    "assets/private.tar (Kivy/python-for-android) ou assets/chaquopy/ (Chaquopy), souvent en .pyc.",
                whereToLook = "Décompresser private.tar ; décompiler les .pyc avec pycdc / uncompyle6."
            ),
            Signature(
                "Qt", KIND_APP, "C++ / QML (Qt)",
                detect = so("libqt[56]core[\\w.-]*\\.so") + r("--added-by-androiddeployqt--"),
                engineFiles = so("libqt[56][\\w.-]*\\.so"),
                dexPackages = listOf("org/qtproject/qt"),
                howItWorks = "QtActivity charge les libs Qt puis la lib de l'appli (C++). L'interface est souvent en QML " +
                    "(fichiers .qml, parfois compilés dans la .so en ressources qrc).",
                whereToLook = "Fichiers .qml dans assets/ ; sinon ressources qrc dans la .so."
            ),
            Signature(
                "SDL2", KIND_GAME, "C / C++ (SDL2)",
                detect = so("libsdl2\\.so"),
                engineFiles = so("libsdl2\\.so", "libsdl2_\\w+\\.so", "libmain\\.so"),
                dexPackages = listOf("org/libsdl/app"),
                howItWorks = "SDLActivity charge libSDL2.so puis libmain.so, qui contient le programme C/C++.",
                whereToLook = "libmain.so dans Ghidra / IDA."
            ),
            Signature(
                "Filament / SceneView", KIND_LIB3D, "C++ (rendu 3D Filament)",
                detect = so("libfilament-jni\\.so", "libgltfio-jni\\.so", "libfilament-utils-jni\\.so"),
                engineFiles = so("libfilament[\\w-]*\\.so", "libgltfio[\\w-]*\\.so"),
                dexPackages = listOf("com/google/android/filament", "io/github/sceneview"),
                howItWorks = "Moteur de rendu 3D de Google utilisé depuis Kotlin/Java. Les modèles sont presque toujours des " +
                    ".glb/.gltf chargés depuis assets/ (et rangés dans _modeles_3d).",
                whereToLook = "Les .glb s'ouvrent dans Blender ou https://gltf-viewer.donmccurdy.com."
            ),
            Signature(
                "ARCore", KIND_LIB3D, "C / C++ (réalité augmentée)",
                detect = so("libarcore_sdk_c\\.so", "libarcore_sdk_jni\\.so"),
                engineFiles = so("libarcore_sdk_[\\w]+\\.so"),
                dexPackages = listOf("com/google/ar/core"),
                howItWorks = "Bibliothèque de réalité augmentée de Google (suivi caméra, détection de plans).",
                whereToLook = "—"
            ),
            Signature(
                "three.js / Babylon.js (WebGL)", KIND_LIB3D, "JavaScript (3D WebGL)",
                detect = r("(^|/)three(\\.module|\\.min|\\.core)?\\.js$", "(^|/)babylon(\\.max)?\\.js$"),
                howItWorks = "Bibliothèque 3D JavaScript qui tourne dans la WebView.",
                whereToLook = "Fichiers JS dans assets/ ; modèles .glb/.gltf rangés dans _modeles_3d."
            )
        )

        /** SDK tiers reconnus par leurs paquets Java. */
        val SDKS: List<Pair<String, List<String>>> = listOf(
            "Kotlin Coroutines" to listOf("kotlinx/coroutines"),
            "Jetpack Compose" to listOf("androidx/compose"),
            "Firebase" to listOf("com/google/firebase"),
            "Firebase Crashlytics" to listOf("com/google/firebase/crashlytics"),
            "Google AdMob (pubs)" to listOf("com/google/android/gms/ads"),
            "Google Play Billing (achats intégrés)" to listOf("com/android/billingclient"),
            "Google Play Games" to listOf("com/google/android/gms/games"),
            "Google Maps" to listOf("com/google/android/gms/maps"),
            "Google Sign-In" to listOf("com/google/android/gms/auth"),
            "Facebook SDK" to listOf("com/facebook/login", "com/facebook/share", "com/facebook/appevents"),
            "Unity Ads" to listOf("com/unity3d/ads", "com/unity3d/services"),
            "AppLovin" to listOf("com/applovin"),
            "ironSource / LevelPlay" to listOf("com/ironsource"),
            "Vungle / Liftoff" to listOf("com/vungle"),
            "Pangle (TikTok Ads)" to listOf("com/bytedance/sdk/openadsdk"),
            "OneSignal (notifications)" to listOf("com/onesignal"),
            "AppsFlyer" to listOf("com/appsflyer"),
            "Adjust" to listOf("com/adjust/sdk"),
            "OkHttp (réseau)" to listOf("okhttp3"),
            "Retrofit (API REST)" to listOf("retrofit2"),
            "Ktor (réseau)" to listOf("io/ktor"),
            "Volley (réseau)" to listOf("com/android/volley"),
            "Gson (JSON)" to listOf("com/google/gson"),
            "Moshi (JSON)" to listOf("com/squareup/moshi"),
            "Glide (images)" to listOf("com/bumptech/glide"),
            "Coil (images)" to listOf("coil", "coil3"),
            "Picasso (images)" to listOf("com/squareup/picasso"),
            "Room (base SQLite)" to listOf("androidx/room"),
            "Realm (base de données)" to listOf("io/realm"),
            "ExoPlayer / Media3 (vidéo)" to listOf("com/google/android/exoplayer2", "androidx/media3"),
            "Dagger / Hilt (injection)" to listOf("dagger"),
            "Koin (injection)" to listOf("org/koin"),
            "RxJava" to listOf("io/reactivex"),
            "Supabase" to listOf("io/github/jan/supabase"),
            "Stripe (paiement)" to listOf("com/stripe/android"),
            "Agora (audio/vidéo temps réel)" to listOf("io/agora"),
            "Socket.IO" to listOf("io/socket"),
            "WebRTC" to listOf("org/webrtc"),
            "Sentry" to listOf("io/sentry"),
            "ML Kit" to listOf("com/google/mlkit"),
            "TensorFlow Lite" to listOf("org/tensorflow/lite"),
            "Lottie (animations)" to listOf("com/airbnb/lottie"),
            "Expo" to listOf("expo/modules")
        )

        /** Explication courte des permissions courantes. */
        val PERMISSION_HINTS = mapOf(
            "INTERNET" to "accès Internet",
            "ACCESS_NETWORK_STATE" to "savoir si le réseau est disponible",
            "ACCESS_WIFI_STATE" to "infos Wi-Fi",
            "CAMERA" to "caméra",
            "RECORD_AUDIO" to "micro",
            "ACCESS_FINE_LOCATION" to "position GPS précise",
            "ACCESS_COARSE_LOCATION" to "position approximative",
            "ACCESS_BACKGROUND_LOCATION" to "position en arrière-plan",
            "READ_EXTERNAL_STORAGE" to "lire les fichiers",
            "WRITE_EXTERNAL_STORAGE" to "écrire des fichiers",
            "MANAGE_EXTERNAL_STORAGE" to "accès à tous les fichiers",
            "READ_MEDIA_IMAGES" to "lire les photos",
            "READ_MEDIA_VIDEO" to "lire les vidéos",
            "READ_MEDIA_AUDIO" to "lire la musique",
            "READ_CONTACTS" to "lire les contacts",
            "READ_PHONE_STATE" to "état/identité du téléphone",
            "CALL_PHONE" to "passer des appels",
            "SEND_SMS" to "envoyer des SMS",
            "READ_SMS" to "lire les SMS",
            "RECEIVE_SMS" to "recevoir des SMS",
            "POST_NOTIFICATIONS" to "afficher des notifications",
            "VIBRATE" to "vibreur",
            "WAKE_LOCK" to "empêcher la mise en veille",
            "FOREGROUND_SERVICE" to "service au premier plan",
            "RECEIVE_BOOT_COMPLETED" to "démarrer avec le téléphone",
            "REQUEST_INSTALL_PACKAGES" to "installer des APK",
            "SYSTEM_ALERT_WINDOW" to "s'afficher par-dessus les autres applis",
            "BLUETOOTH" to "Bluetooth",
            "BLUETOOTH_CONNECT" to "se connecter en Bluetooth",
            "BLUETOOTH_SCAN" to "chercher des appareils Bluetooth",
            "NFC" to "NFC",
            "USE_BIOMETRIC" to "empreinte / visage",
            "BILLING" to "achats intégrés Google Play",
            "AD_ID" to "identifiant publicitaire",
            "QUERY_ALL_PACKAGES" to "voir toutes les applis installées",
            "BIND_ACCESSIBILITY_SERVICE" to "service d'accessibilité (contrôle de l'écran)"
        )
    }
}

data class TechProfile(
    val technologies: List<TechDetector.Detected>,
    /** Langage principal en premier. */
    val languages: List<String>,
    val uiToolkit: String?,
    val abis: List<String>,
    val sdks: List<String>,
    val permissions: List<String>,
    val activities: List<String>,
    val services: List<String>,
    val receivers: List<String>,
    val providers: List<String>,
    val entryActivity: String?,
    val dexCount: Int,
    val nativeLibs: Int,
    val unclaimedNativeLibs: List<String>,
    val obfuscated: Boolean,
    /** chemin relatif d'un fichier extrait → nom du moteur auquel il appartient. */
    val engineFileOwner: Map<String, String>
) {
    val primaryLanguage: String get() = languages.firstOrNull() ?: "Inconnu"
    val primaryTech: String
        get() = technologies.firstOrNull { it.kind != TechDetector.KIND_LIB3D }?.name
            ?: if (dexCount > 0) "Android natif" else "Inconnu"

    companion object {
        val EMPTY = TechProfile(
            emptyList(), emptyList(), null, emptyList(), emptyList(), emptyList(), emptyList(),
            emptyList(), emptyList(), emptyList(), null, 0, 0, emptyList(), false, emptyMap()
        )
    }
}
