package com.reverse.apkdecompiler.engine

/** Rédige _analysis/fonctionnement.txt : langage, moteur, démarrage, SDK, permissions, où regarder. */
object HowItWorksReport {

    fun build(
        appName: String,
        packageName: String?,
        p: TechProfile,
        sorted: AssetSorter.Summary,
        secretsScanned: Boolean = true
    ): String = buildString {
        val line = "─".repeat(60)
        appendLine("COMMENT FONCTIONNE « $appName »")
        packageName?.let { appendLine("Package : $it") }
        appendLine(line)

        // 1. résumé
        appendLine("1. EN BREF")
        appendLine("   Technologie principale : ${p.primaryTech}")
        appendLine("   Langage principal      : ${p.primaryLanguage}")
        if (p.languages.size > 1) {
            appendLine("   Autres langages        :")
            p.languages.drop(1).forEach { appendLine("     • $it") }
        }
        p.uiToolkit?.let { appendLine("   Interface              : $it") }
        if (p.abis.isNotEmpty()) appendLine("   Processeurs (ABI)      : ${p.abis.joinToString(", ")}")
        appendLine("   Code Java/Kotlin       : ${p.dexCount} fichier(s) .dex" + if (p.obfuscated) " — OBFUSQUÉ (noms de classes a/b/c…)" else "")
        appendLine("   Bibliothèques natives  : ${p.nativeLibs} fichier(s) .so")
        appendLine()

        // 2. moteurs
        appendLine("2. MOTEURS / FRAMEWORKS DÉTECTÉS")
        if (p.technologies.isEmpty()) {
            appendLine("   Aucun moteur multiplateforme : appli Android « classique » écrite en Kotlin/Java.")
            appendLine("   Le code se trouve dans les classes*.dex, l'interface dans res/ (layouts XML) ou en Jetpack Compose.")
        }
        p.technologies.forEach { t ->
            appendLine("   ▸ ${t.name}  [${t.kind}]  — ${t.language}")
            appendLine(wrap(t.howItWorks, "     "))
            appendLine("     Indices :")
            t.evidence.forEach { appendLine("       - $it") }
            appendLine()
        }
        if (p.unclaimedNativeLibs.isNotEmpty()) {
            appendLine("   ▸ Code natif C/C++ (NDK) propre à l'appli :")
            p.unclaimedNativeLibs.take(30).forEach { appendLine("       - $it") }
            appendLine()
        }

        // 3. démarrage
        appendLine("3. DÉMARRAGE & COMPOSANTS")
        appendLine("   Écran de lancement probable : ${p.entryActivity ?: "(manifeste illisible)"}")
        listOf(
            "Écrans (Activities)" to p.activities,
            "Services (tâches de fond)" to p.services,
            "Récepteurs (événements système)" to p.receivers,
            "Fournisseurs de contenu" to p.providers
        ).forEach { (label, list) ->
            if (list.isNotEmpty()) {
                appendLine("   $label : ${list.size}")
                list.take(25).forEach { appendLine("     - $it") }
                if (list.size > 25) appendLine("     … +${list.size - 25}")
            }
        }
        appendLine()

        // 4. sdk
        appendLine("4. BIBLIOTHÈQUES & SERVICES TIERS")
        if (p.sdks.isEmpty()) appendLine("   Aucun SDK connu repéré (ou code obfusqué).")
        else p.sdks.forEach { appendLine("   • $it") }
        appendLine()

        // 5. permissions
        appendLine("5. PERMISSIONS DEMANDÉES (${p.permissions.size})")
        p.permissions.forEach { perm ->
            val short = perm.substringAfterLast('.')
            val hint = TechDetector.PERMISSION_HINTS[short]
            appendLine("   • $short" + (hint?.let { " — $it" } ?: "") + if (!perm.startsWith("android.permission.")) "  ($perm)" else "")
        }
        appendLine()

        // 6. rangement
        appendLine("6. FICHIERS RANGÉS")
        appendLine("   ${AssetSorter.ENGINES_DIR}/ : ${sorted.engineFiles} fichier(s) moteur")
        sorted.perEngine.forEach { (k, v) -> appendLine("     - $k : $v") }
        appendLine("   ${AssetSorter.MODELS_DIR}/ : ${sorted.models} modèle(s) 3D")
        sorted.perModelExt.forEach { (k, v) -> appendLine("     - .$k : $v") }
        if (sorted.carvedGlb > 0) appendLine("     dont ${sorted.carvedGlb} .glb extrait(s) de l'intérieur d'archives")
        if (sorted.models == 0) appendLine("     (aucun modèle 3D brut : le moteur les a peut-être convertis dans son propre format)")
        appendLine()

        // 7. où regarder
        appendLine("7. OÙ REGARDER ENSUITE")
        if (p.dexCount > 0) appendLine(wrap("Code Java/Kotlin : ouvrir l'APK ou les classes*.dex dans jadx (jadx-gui) pour le relire en Java.", "   • "))
        p.technologies.forEach { appendLine(wrap("${it.name} : ${it.whereToLook}", "   • ")) }
        if (secretsScanned) appendLine(wrap("Chaînes, URLs et clés trouvées : _analysis/findings.json et _analysis/strings/.", "   • "))
    }

    private fun wrap(text: String, indent: String, width: Int = 96): String {
        val out = StringBuilder()
        var cur = StringBuilder(indent)
        val pad = " ".repeat(indent.length)
        for (w in text.split(' ')) {
            if (cur.length + w.length + 1 > width && cur.length > indent.length) {
                out.appendLine(cur.toString().trimEnd()); cur = StringBuilder(pad)
            }
            cur.append(w).append(' ')
        }
        out.append(cur.toString().trimEnd())
        return out.toString()
    }
}
