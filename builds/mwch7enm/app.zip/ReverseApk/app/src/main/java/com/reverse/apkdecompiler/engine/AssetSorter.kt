package com.reverse.apkdecompiler.engine

import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Range dans des dossiers dédiés, à la racine du dossier de l'appli :
 *
 *   _moteurs/<Moteur>/<chemin d'origine>   → libunity.so, libil2cpp.so, global-metadata.dat, libflutter.so, .pck…
 *   _modeles_3d/<ext>/<nom>                → .glb, .gltf (+ .bin / textures), .fbx, .obj…
 *   _modeles_3d/glb/extraits_d_archives/   → .glb retrouvés À L'INTÉRIEUR d'autres fichiers (.pck, .pak, .bundle…)
 *
 * Les fichiers sont COPIÉS : l'arborescence d'origine de l'APK reste intacte.
 * 100 % JVM (aucune dépendance Android).
 */
object AssetSorter {
    const val ENGINES_DIR = "_moteurs"
    const val MODELS_DIR = "_modeles_3d"
    private const val CARVED_DIR = "extraits_d_archives"

    /** true = déplacer au lieu de copier (gagne de la place mais casse l'arborescence d'origine). */
    var moveInsteadOfCopy = false

    val MODEL_EXT = setOf(
        "glb", "gltf", "fbx", "obj", "dae", "blend", "3ds", "max", "stl", "ply",
        "usdz", "usd", "usda", "usdc", "vrm", "x3d", "abc", "3mf", "mesh", "md2", "md3", "md5mesh"
    )

    /** Fichiers susceptibles de contenir des .glb empaquetés. */
    private val CONTAINER_EXT = setOf(
        "pck", "pak", "bundle", "unity3d", "assets", "resource", "ress", "obb", "bin", "dat",
        "data", "blob", "arc", "arcd", "res", "pkg", "pack", "car", "droid"
    )

    private const val GLB_MAGIC = 0x46546C67   // "glTF" en little-endian
    private const val CHUNK_JSON = 0x4E4F534A  // "JSON"
    private const val MAX_CARVE_PER_FILE = 2000

    data class Summary(
        val engineFiles: Int,
        val engineBytes: Long,
        /** moteur → nombre de fichiers rangés */
        val perEngine: Map<String, Int>,
        val models: Int,
        val modelBytes: Long,
        /** extension → nombre de modèles */
        val perModelExt: Map<String, Int>,
        val carvedGlb: Int,
        val errors: List<String>
    ) {
        companion object { val EMPTY = Summary(0, 0, emptyMap(), 0, 0, emptyMap(), 0, emptyList()) }
    }

    /**
     * @param files (fichier extrait, chemin relatif « / ») de tout l'APK
     */
    fun sort(
        out: File,
        files: List<Pair<File, String>>,
        profile: TechProfile,
        onProgress: (Progress) -> Unit,
        check: () -> Unit
    ): Summary {
        val enginesRoot = File(out, ENGINES_DIR)
        val modelsRoot = File(out, MODELS_DIR)
        val perEngine = LinkedHashMap<String, Int>()
        val perExt = LinkedHashMap<String, Int>()
        val errors = ArrayList<String>()
        var engineFiles = 0; var engineBytes = 0L
        var models = 0; var modelBytes = 0L; var carved = 0
        val alreadyModel = HashSet<String>()

        files.forEachIndexed { i, (f, rel) ->
            check()
            onProgress(Progress("Rangement moteurs & 3D", i, files.size, rel))
            if (rel.startsWith("_") || !f.isFile) return@forEachIndexed
            try {
                // ---- moteur
                profile.engineFileOwner[rel]?.let { engine ->
                    val dest = File(File(enginesRoot, OutputPaths.sanitizeSegment(engine)), rel)
                    place(f, dest, keepSource = true)
                    engineFiles++; engineBytes += f.length()
                    perEngine[engine] = (perEngine[engine] ?: 0) + 1
                }

                // ---- modèle 3D (par extension, ou par signature glTF si le nom est obfusqué)
                val ext = f.extension.lowercase()
                val isGlbByMagic = ext !in MODEL_EXT && f.length() >= 20 && readInt(f, 0) == GLB_MAGIC
                if (ext in MODEL_EXT || isGlbByMagic) {
                    val kind = if (isGlbByMagic) "glb" else ext
                    val name = if (isGlbByMagic) f.name + ".glb" else f.name
                    val dest = uniqueFile(File(File(modelsRoot, kind), name))
                    place(f, dest, keepSource = false)
                    if (kind == "gltf") copyGltfDependencies(f, dest.parentFile!!)
                    if (kind == "obj") copyObjMaterials(f, dest.parentFile!!)
                    models++; modelBytes += f.length()
                    perExt[kind] = (perExt[kind] ?: 0) + 1
                    alreadyModel.add(rel)
                }
            } catch (e: Throwable) {
                if (e is java.util.concurrent.CancellationException) throw e
                if (errors.size < 200) errors.add("Rangement $rel : ${e.javaClass.simpleName} ${e.message ?: ""}")
            }
        }

        // ---- .glb cachés dans des archives / conteneurs
        val containers = files.filter { (f, rel) ->
            !rel.startsWith("_") && rel !in alreadyModel && f.isFile && f.length() > 64 &&
                (f.extension.lowercase() in CONTAINER_EXT || f.extension.isEmpty())
        }
        containers.forEachIndexed { i, (f, rel) ->
            check()
            onProgress(Progress("Recherche de .glb dans les archives", i, containers.size, rel))
            try {
                val n = carveGlb(f, rel, File(File(modelsRoot, "glb"), CARVED_DIR), check)
                if (n > 0) {
                    carved += n; models += n
                    perExt["glb"] = (perExt["glb"] ?: 0) + n
                }
            } catch (e: Throwable) {
                if (e is java.util.concurrent.CancellationException) throw e
                if (errors.size < 200) errors.add("Recherche glb $rel : ${e.message}")
            }
        }
        onProgress(Progress("Rangement moteurs & 3D", 1, 1))

        return Summary(engineFiles, engineBytes, perEngine, models, modelBytes, perExt, carved, errors)
    }

    // ------------------------------------------------------------------ copie

    /**
     * Copie (ou déplace si [moveInsteadOfCopy]) [src] vers [dest].
     * [keepSource] force la copie (les fichiers moteurs restent toujours à leur place d'origine
     * pour qu'ils puissent aussi être rangés comme modèle s'ils en sont un).
     */
    private fun place(src: File, dest: File, keepSource: Boolean) {
        dest.parentFile?.mkdirs()
        if (moveInsteadOfCopy && !keepSource && src.renameTo(dest)) return
        src.copyTo(dest, overwrite = true)
        if (moveInsteadOfCopy && !keepSource) src.delete()
    }

    private fun uniqueFile(f: File): File {
        if (!f.exists()) return f
        val ext = f.extension.let { if (it.isEmpty()) "" else ".$it" }
        val base = f.nameWithoutExtension
        var i = 2
        while (true) {
            val c = File(f.parentFile, "${base}_$i$ext")
            if (!c.exists()) return c
            i++
        }
    }

    /** Un .gltf référence des .bin et des textures par chemin relatif : on les copie à côté. */
    private fun copyGltfDependencies(gltf: File, destDir: File) {
        val txt = try { gltf.readText() } catch (e: Throwable) { return }
        URI.findAll(txt).map { it.groupValues[1] }
            .filter { !it.startsWith("data:") && !it.contains("://") }
            .distinct()
            .forEach { uri ->
                val clean = java.net.URLDecoder.decode(uri, "UTF-8").replace('\\', '/')
                if (clean.split('/').any { it == ".." }) return@forEach
                val src = File(gltf.parentFile, clean)
                val dst = File(destDir, clean)
                if (src.isFile && !dst.exists()) { dst.parentFile?.mkdirs(); src.copyTo(dst) }
            }
    }

    /** Un .obj référence un .mtl (matériaux) qui lui-même référence des textures. */
    private fun copyObjMaterials(obj: File, destDir: File) {
        val lines = try { obj.bufferedReader().useLines { s -> s.filter { it.startsWith("mtllib ") }.toList() } }
        catch (e: Throwable) { return }
        lines.map { it.removePrefix("mtllib ").trim() }.forEach { name ->
            if (name.contains("..")) return@forEach
            val mtl = File(obj.parentFile, name)
            if (mtl.isFile) {
                val d = File(destDir, name)
                if (!d.exists()) { d.parentFile?.mkdirs(); mtl.copyTo(d) }
                try {
                    mtl.readLines().mapNotNull { l -> MTL_MAP.find(l.trim())?.groupValues?.get(1) }
                        .filter { !it.contains("..") }
                        .forEach { t ->
                            val s = File(mtl.parentFile, t); val dd = File(destDir, t)
                            if (s.isFile && !dd.exists()) { dd.parentFile?.mkdirs(); s.copyTo(dd) }
                        }
                } catch (_: Throwable) {}
            }
        }
    }

    // ------------------------------------------------------------------ carving .glb

    /**
     * Cherche l'en-tête binaire glTF 2.0 (« glTF », version, longueur totale, chunk JSON)
     * partout dans [f] et recopie chaque modèle trouvé en .glb autonome.
     */
    fun carveGlb(f: File, rel: String, destDir: File, check: () -> Unit): Int {
        val size = f.length()
        val candidates = ArrayList<Long>()
        FileInputStream(f).use { ins ->
            val buf = ByteArray(256 * 1024)
            var win = 0
            var pos = 0L
            while (true) {
                val n = ins.read(buf)
                if (n < 0) break
                for (i in 0 until n) {
                    win = (win shl 8) or (buf[i].toInt() and 0xFF)
                    pos++
                    // « glTF » lu en big-endian dans la fenêtre glissante = 0x676C5446
                    if (win == 0x676C5446 && candidates.size < MAX_CARVE_PER_FILE) candidates.add(pos - 4)
                }
                check()
            }
        }
        if (candidates.isEmpty()) return 0

        var found = 0
        val base = OutputPaths.sanitizeSegment(rel.replace('/', '_')).take(120)
        RandomAccessFile(f, "r").use { raf ->
            var skipUntil = -1L
            for (off in candidates) {
                check()
                if (off < skipUntil) continue
                if (off + 20 > size) continue
                // un .glb entier qui commence à 0 a déjà été rangé par sa signature
                if (off == 0L && f.extension.lowercase() == "glb") continue
                val h = ByteArray(20)
                raf.seek(off); raf.readFully(h)
                val bb = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN)
                val version = bb.getInt(4)
                val length = bb.getInt(8).toLong() and 0xFFFFFFFFL
                val chunkLen = bb.getInt(12).toLong() and 0xFFFFFFFFL
                val chunkType = bb.getInt(16)
                if (version != 2 || chunkType != CHUNK_JSON) continue
                if (length < 28 || off + length > size || chunkLen + 20 > length) continue

                destDir.mkdirs()
                val dest = uniqueFile(File(destDir, "${base}@${off}.glb"))
                FileOutputStream(dest).use { o ->
                    raf.seek(off)
                    val b = ByteArray(64 * 1024)
                    var left = length
                    while (left > 0) {
                        val n = raf.read(b, 0, minOf(b.size.toLong(), left).toInt())
                        if (n <= 0) break
                        o.write(b, 0, n); left -= n
                    }
                }
                found++
                skipUntil = off + length
            }
        }
        return found
    }

    private fun readInt(f: File, at: Long): Int = try {
        RandomAccessFile(f, "r").use { raf ->
            raf.seek(at)
            val b = ByteArray(4); raf.readFully(b)
            ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).int
        }
    } catch (e: Throwable) { 0 }

    private val URI = Regex(""""uri"\s*:\s*"([^"]+)"""")
    private val MTL_MAP = Regex("""^(?:map_\w+|bump|disp|decal|refl)\s+(?:-\S+\s+\S+\s+)*(\S+)$""")
}
