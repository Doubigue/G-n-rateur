package com.reverse.apkdecompiler.engine

import java.io.File

data class Progress(
    val phase: String,
    val done: Int,
    val total: Int,
    val current: String = ""
)

data class ExtractionReport(
    val appName: String,
    val packageName: String?,
    val sha256: String,
    val outputDir: File,
    val mode: String,
    val extracted: Int,
    val partial: Int,
    val failed: Int,
    val totalBytes: Long,
    val manifestReadable: Boolean,
    val dexCount: Int,
    val nativeLibCount: Int,
    /** catégorie -> liste de (valeur, fichier source) */
    val findings: Map<String, List<Pair<String, String>>>,
    /** false si la recherche URLs / emails / clés a été désactivée dans les Réglages. */
    val secretsScanned: Boolean = true,
    val errors: List<String>,
    /** Moteurs, langages, SDK, permissions… */
    val tech: TechProfile = TechProfile.EMPTY,
    /** Ce qui a été rangé dans _moteurs/ et _modeles_3d/ */
    val sorted: AssetSorter.Summary = AssetSorter.Summary.EMPTY
)
