# Assistant vocal hors-ligne (Kotlin)

## Mise en route
1. Télécharger **vosk-model-small-fr-0.22** : https://alphacephei.com/vosk/models
2. Garder le modèle sous forme de ZIP sur le téléphone. **Ne pas l'ajouter à `assets`**.
3. Ouvrir l'application installée et appuyer sur **« Importer le modèle Vosk (.zip) »**.
4. Sélectionner le ZIP du modèle. L'application le décompresse et le vérifie automatiquement.
5. Dans l'app : autoriser le micro, l'affichage par-dessus les autres apps et le service d'accessibilité, puis « Démarrer l'assistant ».
6. Installer la voix française TTS hors-ligne si besoin (Réglages > Synthèse vocale).

## Utilisation
- Clic simple sur la bulle : parler. Triple clic : sirène SOS (re-triple clic pour l'arrêter).
- Exemples : « allume la torche », « niveau de batterie », « stockage », « note acheter du pain »,
  « programme une alarme à sept heures trente », « ouvre YouTube », « éteins le téléphone ».

## Modèle
Le modèle est stocké dans l'espace privé de l'application après import. Il n'est donc plus inclus dans l'APK, ce qui évite la limite de taille imposée par certains outils de compilation.
