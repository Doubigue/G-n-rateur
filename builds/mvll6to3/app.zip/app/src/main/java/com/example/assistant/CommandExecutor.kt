package com.example.assistant

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import android.provider.Settings

/** Exécute une [Command] et retourne la phrase que l'assistant doit prononcer. */
class CommandExecutor(
    private val context: Context,
    private val notes: NoteManager,
    private val status: SystemStatusReporter,
    private val torch: TorchController
) {

    fun execute(cmd: Command): String = when (cmd) {
        is Command.Torch -> when {
            !torch.hasTorch -> "Ce téléphone n'a pas de lampe torche."
            torch.set(cmd.on) -> if (cmd.on) "Torche allumée" else "Torche éteinte"
            else -> "Impossible de contrôler la torche."
        }
        Command.Battery -> status.batteryReport()
        Command.Storage -> status.storageReport()
        is Command.Note ->
            if (cmd.text.isBlank()) "Que dois-je noter ?"
            else if (notes.addNote(cmd.text)) "Note enregistrée" else "Impossible d'enregistrer la note."
        is Command.Alarm -> setAlarm(cmd.hour, cmd.minute)
        is Command.OpenApp -> openApp(cmd.name)
        Command.PowerMenu ->
            if (PowerAccessibilityService.showPowerDialog()) "Menu d'alimentation affiché"
            else {
                // Service d'accessibilité inactif : on ouvre ses réglages
                launch(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                "Veuillez activer le service d'accessibilité de l'assistant."
            }
        is Command.Unknown -> "Je n'ai pas compris."
    }

    // ---- Alarme (AlarmClock.ACTION_SET_ALARM) ----
    private fun setAlarm(hour: Int?, minute: Int?): String {
        if (hour == null || minute == null) return "Je n'ai pas compris l'heure de l'alarme."
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, "Assistant")
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        }
        val spoken = if (minute == 0) "$hour heures" else "$hour heures $minute"
        return if (launch(intent)) "Alarme programmée à $spoken" else "Aucune application d'alarme trouvée."
    }

    // ---- Ouverture d'application par son nom affiché ----
    private fun openApp(name: String): String {
        val pm = context.packageManager
        val target = VoiceCommandParser.normalizeName(name)
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)

        @Suppress("DEPRECATION")
        val best = pm.queryIntentActivities(launcher, 0).mapNotNull { ri ->
            val label = VoiceCommandParser.normalizeName(ri.loadLabel(pm).toString())
            val score = when {
                label == target -> 3
                label.startsWith(target) -> 2
                label.contains(target) -> 1
                else -> 0
            }
            if (score > 0) Triple(score, label.length, ri.activityInfo.packageName) else null
        }.sortedWith(compareByDescending<Triple<Int, Int, String>> { it.first }.thenBy { it.second })
            .firstOrNull()

        val intent = best?.let { pm.getLaunchIntentForPackage(it.third) }
            ?: return "Je ne trouve pas l'application $name."
        return if (launch(intent)) "J'ouvre $name" else "Impossible d'ouvrir $name."
    }

    /**
     * Lance une activité depuis le service. Autorisé en arrière-plan car l'app détient
     * SYSTEM_ALERT_WINDOW (exemption des restrictions de lancement d'activité).
     */
    private fun launch(intent: Intent): Boolean = try {
        context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: ActivityNotFoundException) { false } catch (e: SecurityException) { false }
}
