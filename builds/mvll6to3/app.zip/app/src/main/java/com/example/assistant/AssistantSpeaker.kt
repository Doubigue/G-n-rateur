package com.example.assistant

import android.content.Context
import android.media.AudioAttributes
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Synthèse vocale (TextToSpeech) en français.
 * Fonctionne hors-ligne si une voix française est installée sur le téléphone
 * (Réglages > Langue > Synthèse vocale).
 */
class AssistantSpeaker(context: Context) : TextToSpeech.OnInitListener {

    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = TextToSpeech(context.applicationContext, this)
    private var ready = false
    private val pending = ArrayDeque<Pair<String, (() -> Unit)?>>()
    private val callbacks = ConcurrentHashMap<String, () -> Unit>()

    override fun onInit(status: Int) {
        val engine = tts ?: return
        if (status != TextToSpeech.SUCCESS) {
            Log.e(TAG, "Initialisation TTS échouée")
            while (pending.isNotEmpty()) pending.removeFirst().second?.let { main.post(it) }
            return
        }
        val r = engine.setLanguage(Locale.FRENCH)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            Log.w(TAG, "Voix française absente : installez-la dans les réglages TTS")
        }
        engine.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
        )
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) = finish(utteranceId)
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) = finish(utteranceId)
        })
        ready = true
        while (pending.isNotEmpty()) {
            val (text, cb) = pending.removeFirst()
            doSpeak(text, cb)
        }
    }

    /** Prononce [text]. [onDone] est appelé sur le thread principal à la fin de la phrase. */
    fun speak(text: String, onDone: (() -> Unit)? = null) {
        if (!ready) pending.addLast(text to onDone) else doSpeak(text, onDone)
    }

    private fun doSpeak(text: String, onDone: (() -> Unit)?) {
        val id = UUID.randomUUID().toString()
        if (onDone != null) callbacks[id] = onDone
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
    }

    private fun finish(id: String?) {
        id?.let { callbacks.remove(it) }?.let { main.post(it) }
    }

    fun stop() {
        callbacks.clear()
        tts?.stop()
    }

    fun shutdown() {
        stop()
        tts?.shutdown()
        tts = null
        ready = false
    }

    private companion object { const val TAG = "AssistantSpeaker" }
}
