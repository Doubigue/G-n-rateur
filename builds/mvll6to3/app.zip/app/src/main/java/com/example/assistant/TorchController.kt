package com.example.assistant

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager

/** Contrôle de la lampe torche via CameraManager (aucune permission CAMERA requise). */
class TorchController(context: Context) {

    private val manager = context.getSystemService(CameraManager::class.java)

    private val cameraId: String? = try {
        manager.cameraIdList.firstOrNull { id ->
            val c = manager.getCameraCharacteristics(id)
            c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        }
    } catch (e: Exception) { null }

    val hasTorch: Boolean get() = cameraId != null

    var isOn = false
        private set

    /** Allume / éteint la torche. Retourne false en cas d'échec. */
    fun set(on: Boolean): Boolean {
        val id = cameraId ?: return false
        return try {
            manager.setTorchMode(id, on)
            isOn = on
            true
        } catch (e: Exception) { false }
    }
}
