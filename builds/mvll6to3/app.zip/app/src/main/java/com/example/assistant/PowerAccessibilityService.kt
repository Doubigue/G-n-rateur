package com.example.assistant

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/**
 * Service d'accessibilité minimal : il ne lit AUCUN contenu d'écran.
 * Son seul rôle est d'exécuter l'action globale "menu d'alimentation"
 * (éteindre / redémarrer) sans droits root.
 */
class PowerAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* non utilisé */ }

    override fun onInterrupt() { /* non utilisé */ }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    companion object {
        /** Instance active (null tant que l'utilisateur n'a pas activé le service). */
        @Volatile
        var instance: PowerAccessibilityService? = null
            private set

        /** Affiche le menu d'alimentation natif. Retourne false si le service est inactif. */
        fun showPowerDialog(): Boolean =
            instance?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_POWER_DIALOG) ?: false
    }
}
