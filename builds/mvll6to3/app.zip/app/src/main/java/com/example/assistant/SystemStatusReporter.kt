package com.example.assistant

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import java.util.Locale
import kotlin.math.roundToInt

/** Produit des phrases prêtes à être prononcées sur la batterie et le stockage. */
class SystemStatusReporter(private val context: Context) {

    /** Niveau + statut de la batterie via l'intent collant ACTION_BATTERY_CHANGED. */
    fun batteryReport(): String {
        val i = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?: return "Impossible de lire l'état de la batterie."
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        if (level < 0 || scale <= 0) return "Impossible de lire l'état de la batterie."
        val percent = (level * 100f / scale).roundToInt()

        val source = when (i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)) {
            BatteryManager.BATTERY_PLUGGED_AC -> " sur secteur"
            BatteryManager.BATTERY_PLUGGED_USB -> " en USB"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> " sans fil"
            else -> ""
        }
        val state = when (i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)) {
            BatteryManager.BATTERY_STATUS_CHARGING -> ", en charge$source"
            BatteryManager.BATTERY_STATUS_FULL -> ", complètement chargée"
            BatteryManager.BATTERY_STATUS_DISCHARGING -> ", en décharge"
            BatteryManager.BATTERY_STATUS_NOT_CHARGING -> ", branchée mais sans charge"
            else -> ""
        }
        return "La batterie est à $percent pour cent$state."
    }

    /** Espace libre / total de la partition de données (StatFs). */
    fun storageReport(): String {
        val stat = StatFs(Environment.getDataDirectory().path)
        val gb = 1024.0 * 1024.0 * 1024.0
        val free = stat.availableBlocksLong * stat.blockSizeLong / gb
        val total = stat.blockCountLong * stat.blockSizeLong / gb
        return String.format(Locale.FRANCE, "Il reste %.1f gigaoctets libres sur %.1f au total.", free, total)
    }
}
