package com.example.assistant

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Log
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File
import java.io.FileNotFoundException
import java.util.zip.ZipInputStream

/**
 * Vosk hors-ligne. Le modèle n'est pas inclus dans l'APK :
 * l'utilisateur importe son ZIP depuis l'écran principal.
 */
class VoskEngine(private val context: Context) {

    private val main = Handler(Looper.getMainLooper())
    @Volatile
    private var model: Model? = null
    private var service: SpeechService? = null

    @Volatile
    var isReady = false
        private set

    fun loadAsync(onDone: (Boolean) -> Unit) {
        Thread {
            val ok = try {
                model = Model(modelDir().absolutePath)
                true
            } catch (t: Throwable) {
                Log.e(TAG, "Chargement du modèle impossible", t)
                false
            }
            isReady = ok
            main.post { onDone(ok) }
        }.start()
    }

    fun listen(onText: (String) -> Unit, onError: (String) -> Unit) {
        val m = model ?: return onError("Modèle vocal non chargé")
        cancel()
        try {
            val recognizer = Recognizer(m, SAMPLE_RATE)
            val s = SpeechService(recognizer, SAMPLE_RATE)
            service = s
            s.startListening(object : RecognitionListener {
                override fun onPartialResult(hypothesis: String?) {}
                override fun onResult(hypothesis: String?) {
                    val text = extractText(hypothesis)
                    if (text.isNotBlank()) { cancel(); onText(text) }
                }
                override fun onFinalResult(hypothesis: String?) {}
                override fun onError(exception: Exception?) {
                    cancel()
                    onError(exception?.message ?: "Erreur micro")
                }
                override fun onTimeout() { cancel(); onError("") }
            }, LISTEN_TIMEOUT_MS)
        } catch (e: Exception) {
            cancel()
            onError(e.message ?: "Erreur micro")
        }
    }

    fun cancel() {
        service?.let { it.cancel(); it.shutdown() }
        service = null
    }

    fun release() {
        cancel()
        model?.close()
        model = null
        isReady = false
    }

    private fun extractText(json: String?): String =
        try { JSONObject(json ?: "{}").optString("text", "").trim() } catch (_: Exception) { "" }

    private fun modelDir(): File {
        val dir = File(context.filesDir, MODEL_DIR)
        if (!isValidModel(dir)) throw FileNotFoundException("Modèle Vosk non importé")
        return dir
    }

    companion object {
        private const val TAG = "VoskEngine"
        private const val MODEL_DIR = "vosk-model-fr"
        private const val SAMPLE_RATE = 16000f
        private const val LISTEN_TIMEOUT_MS = 10_000

        fun isModelInstalled(context: Context): Boolean =
            isValidModel(File(context.filesDir, MODEL_DIR))

        private fun isValidModel(dir: File): Boolean =
            dir.isDirectory && File(dir, "am").isDirectory && File(dir, "conf").isDirectory

        /**
         * Importe un ZIP Vosk depuis le sélecteur de fichiers.
         * Accepte aussi bien :
         *   am/, conf/, graph/, ...
         * que vosk-model-small-fr-0.22/am/, conf/, ...
         */
        fun importZip(context: Context, uri: Uri): Result<Unit> {
            val filesDir = context.filesDir
            val temp = File(filesDir, "vosk-model-fr.importing")
            val target = File(filesDir, MODEL_DIR)

            return try {
                temp.deleteRecursively()
                temp.mkdirs()

                val entries = mutableListOf<String>()
                context.contentResolver.openInputStream(uri)?.use { raw ->
                    ZipInputStream(raw.buffered()).use { zip ->
                        var e = zip.nextEntry
                        while (e != null) {
                            if (!e.isDirectory) entries += e.name.replace('\\', '/')
                            e = zip.nextEntry
                        }
                    }
                } ?: return Result.failure(IllegalArgumentException("Impossible d'ouvrir le fichier."))

                val stripRoot = commonRootToStrip(entries)
                    ?: return Result.failure(IllegalArgumentException("Ce ZIP ne contient pas un modèle Vosk valide (dossier am manquant).")).also { temp.deleteRecursively() }

                context.contentResolver.openInputStream(uri)?.use { raw ->
                    ZipInputStream(raw.buffered()).use { zip ->
                        var entry = zip.nextEntry
                        while (entry != null) {
                            val original = entry.name.replace('\\', '/')
                            val relative = normalizeEntry(original, stripRoot)
                            if (relative != null && relative.isNotEmpty()) {
                                val dest = File(temp, relative)
                                val canonicalRoot = temp.canonicalFile
                                val canonicalDest = dest.canonicalFile
                                if (!canonicalDest.path.startsWith(canonicalRoot.path + File.separator)) {
                                    throw SecurityException("Archive invalide")
                                }

                                if (entry.isDirectory) {
                                    dest.mkdirs()
                                } else {
                                    dest.parentFile?.mkdirs()
                                    dest.outputStream().use { out -> zip.copyTo(out) }
                                }
                            }
                            zip.closeEntry()
                            entry = zip.nextEntry
                        }
                    }
                }

                if (!isValidModel(temp)) {
                    temp.deleteRecursively()
                    Result.failure(IllegalArgumentException("Ce ZIP ne contient pas un modèle Vosk valide (dossier am manquant)."))
                } else {
                    target.deleteRecursively()
                    if (!temp.renameTo(target)) {
                        target.deleteRecursively()
                        temp.copyRecursively(target, overwrite = true)
                        temp.deleteRecursively()
                    }
                    Result.success(Unit)
                }
            } catch (t: Throwable) {
                temp.deleteRecursively()
                Log.e(TAG, "Import du modèle échoué", t)
                Result.failure(t)
            }
        }

        /**
         * Cherche le dossier "am" le moins profond et renvoie le préfixe qui le précède
         * ("" si am/ est à la racine, null si introuvable). Ignore __MACOSX et les fichiers cachés.
         */
        private fun commonRootToStrip(entries: List<String>): String? {
            var best: List<String>? = null
            for (name in entries) {
                val parts = name.trim('/').split('/')
                if (parts.firstOrNull() == "__MACOSX") continue
                val idx = parts.indexOf("am")
                if (idx in 0 until parts.size - 1 && (best == null || idx < best.size)) {
                    best = parts.subList(0, idx)
                }
            }
            return best?.joinToString("/")
        }

        private fun normalizeEntry(name: String, stripRoot: String?): String? {
            var p = name.trim('/')
            if (p.startsWith("__MACOSX/")) return null
            if (!stripRoot.isNullOrEmpty()) {
                val prefix = "$stripRoot/"
                if (!p.startsWith(prefix)) return null   // hors du dossier du modèle
                p = p.removePrefix(prefix)
            }
            if (p.isEmpty() || p == "." || p == ".." || p.startsWith("../") || p.contains("/../")) return null
            return p
        }
    }
}
