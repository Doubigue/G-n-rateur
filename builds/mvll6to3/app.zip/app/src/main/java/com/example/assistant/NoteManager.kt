package com.example.assistant

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Enregistre les notes vocales horodatées dans filesDir/voice_notes.txt (stockage privé, hors-ligne). */
class NoteManager(context: Context) {

    private val file = File(context.filesDir, "voice_notes.txt")
    private val fmt = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.FRANCE)

    /** Ajoute une ligne "[date] texte". Retourne false en cas d'erreur d'écriture. */
    @Synchronized
    fun addNote(text: String): Boolean = try {
        file.appendText("[${fmt.format(Date())}] $text\n", Charsets.UTF_8)
        true
    } catch (e: Exception) {
        false
    }

    @Synchronized
    fun readAll(): List<String> =
        if (file.exists()) file.readLines(Charsets.UTF_8) else emptyList()

    fun path(): String = file.absolutePath
}
