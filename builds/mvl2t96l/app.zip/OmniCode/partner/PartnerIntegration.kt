// ─────────────────────────────────────────────────────────────
// À COPIER DANS L'APP PARTENAIRE
// 1) Ajouter OmniCodeContract.kt (même fichier que l'éditeur)
// 2) Ajouter dans AndroidManifest.xml (obligatoire Android 11+) :
//
//    <queries>
//        <intent>
//            <action android:name="com.omnicode.editor.ACTION_EDIT_CODE" />
//        </intent>
//    </queries>
// ─────────────────────────────────────────────────────────────
package com.partner.app

import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.omnicode.contract.OmniCodeContract

class PartnerActivity : ComponentActivity() {

    private var currentCode by mutableStateOf("<h1>Bonjour</h1>\n<p>Code initial</p>")

    // 4) Récupération du résultat
    private val editorLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                result.data?.getStringExtra(OmniCodeContract.EXTRA_UPDATED_CODE)?.let { updated ->
                    currentCode = updated   // ← traiter/enregistrer ici
                }
            }
            // RESULT_CANCELED : l'utilisateur a annulé ou l'accès a été refusé
        }

    // 2) + 3) Lancement avec code, langage et clé
    private fun openEditor(code: String, language: String) {
        val intent = Intent(OmniCodeContract.ACTION_EDIT_CODE).apply {
            setPackage(OmniCodeContract.EDITOR_PACKAGE) // empêche une app tierce d'intercepter la clé
            putExtra(OmniCodeContract.EXTRA_CODE_CONTENT, code)
            putExtra(OmniCodeContract.EXTRA_FILE_LANGUAGE, language)
            putExtra(OmniCodeContract.EXTRA_API_KEY, OmniCodeContract.VALID_API_KEY)
        }
        try {
            editorLauncher.launch(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "OmniCode Studio n'est pas installé.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = { openEditor(currentCode, "html") }) { Text("Éditer avec OmniCode") }
                    Text("Code actuel :", style = MaterialTheme.typography.labelLarge)
                    Text(currentCode)
                }
            }
        }
    }
}
