package com.omnicode.editor

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import com.omnicode.contract.OmniCodeContract
import java.security.MessageDigest

class MainActivity : ComponentActivity() {

    private val vm: EditorViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        // Après rotation (savedInstanceState != null), le ViewModel garde déjà le code.
        if (savedInstanceState == null && !handleIntent(intent)) return

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                EditorScreen(
                    vm = vm,
                    onValidate = ::validateAndFinish,
                    onCancel = ::cancelAndFinish
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    /** @return false si l'accès est refusé (l'activité est alors fermée). */
    private fun handleIntent(intent: Intent?): Boolean {
        if (intent?.action != OmniCodeContract.ACTION_EDIT_CODE) {
            // Lancement autonome : exemple par défaut, sans écraser un travail en cours
            if (!vm.isLoaded) vm.load(SAMPLE_HTML, "html")
            return true
        }

        val key = intent.getStringExtra(OmniCodeContract.EXTRA_API_KEY)
        val valid = key != null && MessageDigest.isEqual(
            key.toByteArray(), OmniCodeContract.VALID_API_KEY.toByteArray()
        )
        if (!valid) {
            Toast.makeText(this, "Accès refusé : clé API absente ou invalide.", Toast.LENGTH_LONG).show()
            setResult(RESULT_CANCELED)
            finish()
            return false
        }

        vm.load(
            code = intent.getStringExtra(OmniCodeContract.EXTRA_CODE_CONTENT).orEmpty(),
            language = intent.getStringExtra(OmniCodeContract.EXTRA_FILE_LANGUAGE) ?: "html"
        )
        return true
    }

    private fun validateAndFinish(code: String) {
        val result = Intent().putExtra(OmniCodeContract.EXTRA_UPDATED_CODE, code)
        setResult(RESULT_OK, result)
        finish()
    }

    private fun cancelAndFinish() {
        setResult(RESULT_CANCELED)
        finish()
    }

    private companion object {
        const val SAMPLE_HTML = """<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: sans-serif; text-align: center; }
    h1 { color: #6200ee; }
  </style>
</head>
<body>
  <h1>Hello OmniCode</h1>
  <button onclick="alert('Salut !')">Clique-moi</button>
</body>
</html>"""
    }
}
