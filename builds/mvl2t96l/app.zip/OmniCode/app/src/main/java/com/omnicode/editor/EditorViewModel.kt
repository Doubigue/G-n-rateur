package com.omnicode.editor

import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.*

data class EditorUiState(
    val code: TextFieldValue = TextFieldValue(""),
    val language: String = "html",
    val showPreview: Boolean = false
)

@OptIn(FlowPreview::class)
class EditorViewModel : ViewModel() {

    private val _state = MutableStateFlow(EditorUiState())
    val state: StateFlow<EditorUiState> = _state.asStateFlow()

    var isLoaded = false
        private set

    /** HTML de l'aperçu, recalculé 300 ms après la dernière frappe. */
    val previewHtml: StateFlow<String> = _state
        .map { it.code.text to it.language }
        .distinctUntilChanged()
        .debounce(300)
        .map { (code, lang) -> PreviewBuilder.build(code, lang) }
        .flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.Eagerly, "")

    fun load(code: String, language: String) {
        isLoaded = true
        _state.value = EditorUiState(TextFieldValue(code), language.lowercase())
    }

    fun onCodeChange(value: TextFieldValue) = _state.update { it.copy(code = value) }

    fun setPreview(show: Boolean) = _state.update { it.copy(showPreview = show) }

    /** Insère un symbole à la position du curseur (remplace la sélection). */
    fun insert(symbol: String) = _state.update { s ->
        val v = s.code
        val start = v.selection.min
        val newText = v.text.replaceRange(start, v.selection.max, symbol)
        s.copy(code = TextFieldValue(newText, TextRange(start + symbol.length)))
    }
}
