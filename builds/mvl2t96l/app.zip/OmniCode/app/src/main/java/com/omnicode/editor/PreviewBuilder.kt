package com.omnicode.editor

object PreviewBuilder {

    fun build(code: String, lang: String): String = when (lang.lowercase()) {
        "html", "htm" -> code
        "css" -> page(
            "<style>$code</style>",
            "<h1>Titre h1</h1><h2>Titre h2</h2><p>Un paragraphe avec <a href='#'>un lien</a>.</p>" +
                "<button>Bouton</button><ul><li>Item 1</li><li>Item 2</li></ul>"
        )
        "javascript", "js" -> jsConsole(code)
        "markdown", "md" -> page("<style>body{font-family:sans-serif;padding:12px;line-height:1.5}" +
            "pre{background:#eee;padding:8px;overflow:auto}code{background:#eee}</style>", markdownToHtml(code))
        "svg" -> page("<style>body{margin:0;display:flex;justify-content:center}</style>", code)
        else -> page("<style>pre{white-space:pre-wrap}</style>", "<pre>${esc(code)}</pre>")
    }

    private fun page(head: String, body: String) =
        "<!DOCTYPE html><html><head><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">" +
            "$head</head><body>$body</body></html>"

    private fun jsConsole(code: String): String = """<!DOCTYPE html><html><head>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>body{font-family:monospace;padding:12px}.err{color:#c00}</style></head><body>
<div id="out"></div>
<script>
var out=document.getElementById('out');
function log(c,a){var s=Array.prototype.map.call(a,function(x){try{return typeof x==='object'?JSON.stringify(x):String(x)}catch(e){return String(x)}}).join(' ');var d=document.createElement('div');d.className=c;d.textContent=s;out.appendChild(d);}
console.log=function(){log('',arguments)};
console.error=function(){log('err',arguments)};
window.onerror=function(m,u,l){log('err',['Erreur ligne '+l+' : '+m])};
</script>
<script>
${code.replace("</script", "<\\/script")}
</script></body></html>"""

    private fun esc(s: String) =
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    private fun inline(s: String): String = esc(s)
        .replace(Regex("`([^`]+)`"), "<code>\$1</code>")
        .replace(Regex("\\*\\*(.+?)\\*\\*"), "<b>\$1</b>")
        .replace(Regex("\\*(.+?)\\*"), "<i>\$1</i>")
        .replace(Regex("\\[(.+?)]\\((.+?)\\)"), "<a href=\"\$2\">\$1</a>")

    /** Convertisseur Markdown minimal (titres, listes, citations, code, gras/italique, liens). */
    private fun markdownToHtml(md: String): String {
        val sb = StringBuilder()
        var inCode = false
        var inList = false
        fun closeList() { if (inList) { sb.append("</ul>"); inList = false } }

        for (raw in md.lines()) {
            if (raw.trimStart().startsWith("```")) {
                closeList()
                sb.append(if (inCode) "</code></pre>" else "<pre><code>")
                inCode = !inCode
                continue
            }
            if (inCode) { sb.append(esc(raw)).append('\n'); continue }

            val line = raw.trim()
            when {
                line.isEmpty() -> closeList()
                line.startsWith("#") -> {
                    closeList()
                    val n = line.takeWhile { it == '#' }.length.coerceIn(1, 6)
                    sb.append("<h$n>${inline(line.drop(n).trim())}</h$n>")
                }
                line.startsWith("- ") || line.startsWith("* ") -> {
                    if (!inList) { sb.append("<ul>"); inList = true }
                    sb.append("<li>${inline(line.drop(2))}</li>")
                }
                line.startsWith("> ") -> { closeList(); sb.append("<blockquote>${inline(line.drop(2))}</blockquote>") }
                else -> { closeList(); sb.append("<p>${inline(line)}</p>") }
            }
        }
        closeList()
        if (inCode) sb.append("</code></pre>")
        return sb.toString()
    }
}
