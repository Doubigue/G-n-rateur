package com.omnicode.editor

import android.annotation.SuppressLint
import android.webkit.WebView
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

private val EditorBg = Color(0xFF1E1E1E)
private val GutterBg = Color(0xFF252526)
private val Fg = Color(0xFFD4D4D4)
private val GutterFg = Color(0xFF858585)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(
    vm: EditorViewModel,
    onValidate: (String) -> Unit,
    onCancel: () -> Unit
) {
    val state by vm.state.collectAsState()
    val html by vm.previewHtml.collectAsState()

    BackHandler(onBack = onCancel)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(state.language.uppercase(), style = MaterialTheme.typography.titleMedium) },
                navigationIcon = { TextButton(onClick = onCancel) { Text("Annuler") } },
                actions = {
                    Button(onClick = { onValidate(state.code.text) }) { Text("Valider & Enregistrer") }
                    Spacer(Modifier.width(8.dp))
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().imePadding()) {
            TabRow(selectedTabIndex = if (state.showPreview) 1 else 0) {
                Tab(selected = !state.showPreview, onClick = { vm.setPreview(false) }, text = { Text("Éditeur") })
                Tab(selected = state.showPreview, onClick = { vm.setPreview(true) }, text = { Text("Preview") })
            }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (state.showPreview) {
                    PreviewWebView(html, Modifier.fillMaxSize())
                } else {
                    CodeEditor(state.code, state.language, vm::onCodeChange, Modifier.fillMaxSize())
                }
            }
            if (!state.showPreview) SymbolBar(onSymbol = vm::insert)
        }
    }
}

@Composable
fun CodeEditor(
    value: TextFieldValue,
    language: String,
    onChange: (TextFieldValue) -> Unit,
    modifier: Modifier = Modifier
) {
    val transformation = remember(language) {
        VisualTransformation { text ->
            TransformedText(SyntaxHighlighter.highlight(text.text, language), OffsetMapping.Identity)
        }
    }
    val mono = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 14.sp, lineHeight = 20.sp, color = Fg)
    val lineCount = remember(value.text) { value.text.count { it == '\n' } + 1 }

    BoxWithConstraints(modifier.background(EditorBg)) {
        val minH = maxHeight
        Row(Modifier.verticalScroll(rememberScrollState())) {
            Text(
                text = (1..lineCount).joinToString("\n"),
                style = mono.copy(color = GutterFg, textAlign = TextAlign.End),
                modifier = Modifier
                    .background(GutterBg)
                    .heightIn(min = minH)
                    .widthIn(min = 40.dp)
                    .padding(horizontal = 8.dp, vertical = 8.dp)
            )
            Box(Modifier.weight(1f).horizontalScroll(rememberScrollState())) {
                BasicTextField(
                    value = value,
                    onValueChange = onChange,
                    textStyle = mono,
                    cursorBrush = SolidColor(Color.White),
                    visualTransformation = transformation,
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.None,
                        autoCorrectEnabled = false,
                        keyboardType = KeyboardType.Text
                    ),
                    modifier = Modifier
                        .widthIn(min = 300.dp)
                        .heightIn(min = minH)
                        .padding(8.dp)
                )
            }
        }
    }
}

private val SYMBOLS = listOf(
    "Tab" to "  ", "{" to "{", "}" to "}", "<" to "<", ">" to ">", "/" to "/",
    "=" to "=", "[" to "[", "]" to "]", "\"" to "\"", "'" to "'"
)

@Composable
fun SymbolBar(onSymbol: (String) -> Unit) {
    Surface(tonalElevation = 4.dp) {
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            SYMBOLS.forEach { (label, insert) ->
                TextButton(
                    onClick = { onSymbol(insert) },
                    contentPadding = PaddingValues(horizontal = 14.dp)
                ) { Text(label, fontFamily = FontFamily.Monospace) }
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun PreviewWebView(html: String, modifier: Modifier = Modifier) {
    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            WebView(ctx).apply {
                settings.javaScriptEnabled = true
                settings.allowFileAccess = false      // pas d'accès au système de fichiers
                settings.allowContentAccess = false
                setBackgroundColor(android.graphics.Color.WHITE)
            }
        },
        update = { web ->
            if (web.tag != html) {                     // évite les rechargements inutiles
                web.tag = html
                web.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
            }
        },
        onRelease = { it.destroy() }
    )
}
