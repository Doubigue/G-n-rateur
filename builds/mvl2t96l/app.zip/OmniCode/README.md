# OmniCode Studio

Projet Android (Gradle Kotlin DSL) prêt à ouvrir dans Android Studio.

## Ouvrir et lancer
1. Android Studio : File > Open > dossier `OmniCode` (celui qui contient `settings.gradle.kts`).
2. Laisser la synchronisation Gradle se terminer (JDK 17 requis, celui d'Android Studio convient).
3. Run > `app`.

## Structure
```
settings.gradle.kts
build.gradle.kts
gradle.properties
gradle/wrapper/gradle-wrapper.properties
app/
  build.gradle.kts
  src/main/AndroidManifest.xml
  src/main/java/com/omnicode/editor/     (MainActivity, EditorScreen, ViewModel, ...)
  src/main/java/com/omnicode/contract/   (OmniCodeContract.kt, à copier aussi dans l'app partenaire)
partner/PartnerIntegration.kt            (exemple pour l'autre app, non compilé ici)
```

Versions : Gradle 8.9, AGP 8.7.3, Kotlin 2.0.21, Compose BOM 2024.12.01, minSdk 24, compileSdk 35.
`applicationId` : `com.omnicode.editor` (à garder identique à `EDITOR_PACKAGE`).
