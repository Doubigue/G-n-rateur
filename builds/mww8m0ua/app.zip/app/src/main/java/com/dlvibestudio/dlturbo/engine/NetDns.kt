package com.dlvibestudio.dlturbo.engine

import com.dlvibestudio.dlturbo.data.Settings
import okhttp3.Dns
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.dnsoverhttps.DnsOverHttps
import java.net.InetAddress
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/**
 * DNS personnalisé (comme 1DM) : les adresses des serveurs sont demandées à un service DNS chiffré (DNS sur HTTPS)
 * au lieu de celui de l'opérateur, ce qui contourne les blocages par DNS. En cas d'échec, DNS du téléphone.
 * S'applique aux moteurs de téléchargement de l'appli (fichiers, HLS, analyse des flux), pas au navigateur.
 */
class TurboDns(private val settings: Settings) : Dns {

    private class Provider(val url: String, val bootstrap: List<String>)

    private val providers = mapOf(
        "cloudflare" to Provider("https://cloudflare-dns.com/dns-query", listOf("1.1.1.1", "1.0.0.1")),
        "google" to Provider("https://dns.google/dns-query", listOf("8.8.8.8", "8.8.4.4")),
        "adguard" to Provider("https://dns.adguard-dns.com/dns-query", listOf("94.140.14.14", "94.140.15.15")),
        "quad9" to Provider("https://dns.quad9.net/dns-query", listOf("9.9.9.9", "149.112.112.112")),
    )

    /** Client sans DNS personnalisé : sert uniquement à interroger le service DNS. */
    private val bootstrapClient by lazy {
        OkHttpClient.Builder().connectTimeout(8, TimeUnit.SECONDS).readTimeout(8, TimeUnit.SECONDS).build()
    }
    private val resolvers = ConcurrentHashMap<String, Dns>()

    override fun lookup(hostname: String): List<InetAddress> {
        val mode = settings.value.dnsMode
        val p = providers[mode] ?: return Dns.SYSTEM.lookup(hostname)
        val doh = resolvers.getOrPut(mode) {
            DnsOverHttps.Builder()
                .client(bootstrapClient)
                .url(p.url.toHttpUrl())
                .bootstrapDnsHosts(p.bootstrap.map { InetAddress.getByName(it) })
                .includeIPv6(true)
                .build()
        }
        return runCatching { doh.lookup(hostname) }.getOrNull()?.takeIf { it.isNotEmpty() }
            ?: Dns.SYSTEM.lookup(hostname)
    }

    companion object {
        val OPTIONS = listOf(
            "system" to "Téléphone", "cloudflare" to "Cloudflare", "google" to "Google",
            "adguard" to "AdGuard (anti-pub)", "quad9" to "Quad9",
        )
    }
}

/**
 * Nombre maximal de connexions par site (comme 1DM) : certains serveurs bloquent ou ralentissent au-delà.
 * Réglage texte, une règle par ligne : « site.com=4 ». S'applique aussi aux sous-domaines.
 */
object DomainLimits {
    fun parse(text: String): Map<String, Int> {
        val out = LinkedHashMap<String, Int>()
        for (line in text.split('\n', ',', ';')) {
            val k = line.substringBefore('=').trim().lowercase().removePrefix("www.").removePrefix("*.")
            val v = line.substringAfter('=', "").trim().toIntOrNull() ?: continue
            if (k.isNotEmpty() && '.' in k) out[k] = v.coerceIn(1, 32)
        }
        return out
    }

    fun limitFor(text: String, host: String?): Int? {
        val h = host?.lowercase() ?: return null
        if (text.isBlank()) return null
        return parse(text).entries.firstOrNull { (d, _) -> h == d || h.endsWith(".$d") }?.value
    }
}
