package com.dlvibestudio.dlturbo.engine

import android.content.Context
import com.dlvibestudio.dlturbo.data.DlStatus
import com.dlvibestudio.dlturbo.data.DlType
import com.dlvibestudio.dlturbo.data.DownloadItem
import com.dlvibestudio.dlturbo.data.DownloadRepository
import com.dlvibestudio.dlturbo.data.Settings
import com.dlvibestudio.dlturbo.data.SettingsData
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec
import kotlin.coroutines.coroutineContext

/**
 * Moteur HLS intégré (comme celui de 1DM) : la liste .m3u8 est lue ici, les morceaux sont téléchargés en
 * parallèle (plusieurs connexions), déchiffrés s'ils sont en AES-128, gardés sur le disque (reprise exacte
 * après une pause ou une coupure), puis assemblés en MP4 par ffmpeg. Piste audio séparée prise en charge.
 * Ce qu'il ne sait pas faire (direct, DRM, SAMPLE-AES, autre format) est confié à yt-dlp ([NotHandled]).
 */
class HlsEngine(
    private val context: Context,
    private val repo: DownloadRepository,
    private val settings: Settings,
    private val limiter: RateLimiter,
    private val client: OkHttpClient,
) {
    /** Ce lien n'est pas pour ce moteur : yt-dlp prend le relais (rien n'est perdu). */
    class NotHandled(message: String) : IOException(message)

    /** Échecs du moteur par téléchargement : après deux, on laisse yt-dlp essayer. */
    private val failures = ConcurrentHashMap<String, Int>()

    /** Flux repéré dans une page (pas un site connu de yt-dlp), qualité vidéo, moteur activé. */
    fun canTry(item: DownloadItem): Boolean {
        val cfg = settings.value
        if (!cfg.nativeHls || item.type != DlType.VIDEO || item.playlist) return false
        if (!item.referer.startsWith("http") || Links.isVideoSite(item.url)) return false
        if (VideoEngine.isAudioQuality(item.quality.ifBlank { cfg.videoQuality })) return false
        // Fichier vidéo ordinaire ou flux DASH : rien à faire ici (évite de le télécharger pour rien).
        val path = runCatching { java.net.URI(item.url).path }.getOrNull().orEmpty().lowercase()
        if (NOT_HLS.any { path.endsWith(it) }) return false
        return (failures[item.id] ?: 0) < 2
    }

    /** Téléchargement supprimé : ses morceaux déjà reçus sont effacés. */
    fun forget(id: String) {
        failures.remove(id)
        runCatching { File(context.getExternalFilesDir(null) ?: context.filesDir, "hls/$id").deleteRecursively() }
    }

    private companion object {
        val NOT_HLS = listOf(".mp4", ".m4v", ".mkv", ".webm", ".mov", ".flv", ".avi", ".mpd", ".mp3", ".m4a", ".aac", ".ogg", ".ts")
    }

    private class Task(val track: String, val name: String, val url: String, val range: LongRange?, val key: Hls.Key?, val seq: Long)

    suspend fun run(id: String): File = withContext(Dispatchers.IO) {
        try {
            download(id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: NotHandled) {
            throw e
        } catch (e: IOException) {
            failures[id] = (failures[id] ?: 0) + 1
            throw e
        }
    }

    private suspend fun download(id: String): File {
        val item = repo.get(id) ?: throw FatalDownloadException("Téléchargement introuvable")
        val cfg = settings.value
        repo.update(id) { it.copy(info = "Moteur HLS : lecture de la liste…", speed = 0) }

        val top = text(item, item.url) ?: throw NotHandled("Ce lien n'est pas une liste HLS")
        if (!Hls.isPlaylist(top)) throw NotHandled("Ce lien n'est pas une liste HLS")
        var videoUrl = item.url
        var videoText = top
        var audioUrl: String? = null
        if (Hls.isMaster(top)) {
            val master = Hls.parseMaster(item.url, top)
            val v = Hls.choose(master.variants, item.quality.ifBlank { cfg.videoQuality })
                ?: throw NotHandled("Aucune qualité dans la liste")
            videoUrl = v.uri
            videoText = text(item, v.uri) ?: throw IOException("Liste de la qualité choisie illisible")
            audioUrl = master.audioFor(v)?.uri
        }
        val video = Hls.parseMedia(videoUrl, videoText)
        val audio = audioUrl?.let { u -> Hls.parseMedia(u, text(item, u) ?: throw IOException("Piste audio illisible")) }
        for (m in listOfNotNull(video, audio)) {
            if (!m.ended) throw NotHandled("Vidéo en direct : confiée à yt-dlp")
            if (m.unsupportedKey) throw NotHandled("Chiffrement non pris en charge (DRM / SAMPLE-AES)")
            if (m.segments.isEmpty()) throw NotHandled("Liste vide")
        }

        // Dossier de travail : un fichier par morceau. Gardé entre deux lancements (reprise), sauf si la liste a changé.
        val work = File(context.getExternalFilesDir(null) ?: context.filesDir, "hls/$id").apply { mkdirs() }
        val signature = "${video.segments.size}|${audio?.segments?.size ?: 0}|${video.fragmentedMp4}"
        val sigFile = File(work, "liste.txt")
        if (sigFile.exists() && sigFile.readText() != signature) work.listFiles()?.forEach { it.delete() }
        sigFile.writeText(signature)

        val tasks = ArrayList<Task>()
        fun addTrack(track: String, m: Hls.Media) {
            var lastInit: Hls.Init? = null
            m.segments.forEachIndexed { i, s ->
                val init = s.init
                if (init != null && init != lastInit) {
                    tasks.add(Task(track, "%s_init_%05d".format(track, i), init.uri, init.range, init.key, s.seq))
                    lastInit = init
                }
                tasks.add(Task(track, "%s_%05d".format(track, i), s.uri, s.range, s.key, s.seq))
            }
        }
        addTrack("v", video)
        audio?.let { addTrack("a", it) }

        val total = tasks.size
        val doneCount = AtomicInteger(0)
        val doneBytes = AtomicLong(0)
        val received = AtomicLong(0)
        for (t in tasks) {
            val f = File(work, t.name)
            if (f.isFile) {
                doneCount.incrementAndGet()
                doneBytes.addAndGet(f.length())
            }
        }
        val host = runCatching { java.net.URI(videoUrl).host }.getOrNull()
        val connections = minOf(cfg.connections, DomainLimits.limitFor(cfg.domainLimits, host) ?: Int.MAX_VALUE, 16).coerceAtLeast(1)
        val next = AtomicInteger(0)
        val keys = ConcurrentHashMap<String, ByteArray>()
        val started = System.currentTimeMillis()
        val bytesAtStart = doneBytes.get()
        val duration = video.duration

        repo.update(id) {
            it.copy(status = DlStatus.RUNNING, info = "Moteur HLS : ${doneCount.get()}/$total morceaux", sizeEstimated = true)
        }
        coroutineScope {
            val reporter = launch {
                var lastBytes = received.get()
                var lastAt = System.currentTimeMillis()
                while (isActive) {
                    delay(700)
                    val now = System.currentTimeMillis()
                    val r = received.get()
                    val speed = if (now > lastAt) (r - lastBytes) * 1000 / (now - lastAt) else 0
                    lastBytes = r
                    lastAt = now
                    val n = doneCount.get()
                    val bytes = doneBytes.get()
                    // Taille estimée : moyenne des morceaux reçus × nombre de morceaux (affinée au fil du téléchargement).
                    val estimate = if (n > 0) bytes * total / n else item.expectedBytes
                    repo.update(id) {
                        it.copy(
                            downloadedBytes = bytes, totalBytes = maxOf(estimate, bytes), speed = speed,
                            percent = n * 100f / total, sizeEstimated = n < total,
                            info = "Moteur HLS : $n/$total morceaux · $connections connexions",
                        )
                    }
                }
            }
            val workers = (1..connections).map {
                launch {
                    while (true) {
                        val i = next.getAndIncrement()
                        if (i >= tasks.size) break
                        val t = tasks[i]
                        val out = File(work, t.name)
                        if (out.isFile) continue
                        val bytes = fetchWithRetries(item, t, keys, received, cfg)
                        val tmp = File(work, t.name + ".tmp")
                        tmp.writeBytes(bytes)
                        if (!tmp.renameTo(out)) throw IOException("Écriture impossible dans ${work.path}")
                        doneBytes.addAndGet(bytes.size.toLong())
                        doneCount.incrementAndGet()
                    }
                }
            }
            workers.forEach { it.join() }
            reporter.cancel()
        }

        // ---------------------------------------------------------------- Assemblage
        repo.update(id) { it.copy(info = "Assemblage en MP4…", speed = 0, percent = 100f) }
        val ext = if (video.fragmentedMp4) "mp4" else "ts"
        val vFile = File(work, "video.$ext")
        concat(tasks.filter { it.track == "v" }.map { File(work, it.name) }, vFile)
        val aFile = audio?.let { a ->
            val aExt = when {
                a.fragmentedMp4 -> "mp4"
                a.segments.first().uri.substringBefore('?').endsWith(".aac", true) -> "aac"
                else -> "ts"
            }
            File(work, "audio.$aExt").also { concat(tasks.filter { t -> t.track == "a" }.map { t -> File(work, t.name) }, it) }
        }

        val dir = File(item.dir).apply { mkdirs() }
        val base = Links.sanitize(item.outName.ifBlank { item.fileName }).ifBlank { "Vidéo" }.take(150)
        val reserved = repo.items.value.filter { it.id != id }.map { File(it.dir, it.fileName).path }.toSet()
        var target = Links.uniqueFile(dir, "$base.mp4", reserved)
        val args = ArrayList<String>()
        args += listOf("-y", "-hide_banner", "-loglevel", "error", "-i", vFile.path)
        if (aFile != null) args += listOf("-i", aFile.path, "-map", "0:v:0?", "-map", "1:a:0?")
        args += listOf("-c", "copy")
        // Audio AAC « ADTS » (morceaux .ts ou .aac) : converti au format attendu par le MP4.
        val adts = (aFile == null && !video.fragmentedMp4) || aFile?.extension == "aac" || aFile?.extension == "ts"
        if (adts) args += listOf("-bsf:a", "aac_adtstoasc")
        args += listOf("-movflags", "+faststart", target.path)
        val (code, log) = FFmpegRunner.run(context, args)
        if (code != 0 || !target.isFile || target.length() == 0L) {
            target.delete()
            if (aFile != null) throw FatalDownloadException("Assemblage impossible (ffmpeg) : ${log.lines().lastOrNull { it.isNotBlank() } ?: code}")
            // Sans ffmpeg, une vidéo à piste unique reste lisible telle quelle (TS ou MP4 fragmenté).
            target = Links.uniqueFile(dir, "$base.$ext", reserved)
            if (!vFile.renameTo(target)) vFile.copyTo(target, overwrite = true)
        }
        work.deleteRecursively()
        failures.remove(id)
        val size = target.length()
        repo.update(id) {
            it.copy(
                fileName = target.name, dir = dir.path, totalBytes = size, downloadedBytes = size,
                sizeEstimated = false, info = "", speed = 0, autoName = false,
                expectedBytes = if (duration > 0) size else it.expectedBytes,
            )
        }
        return target
    }

    private suspend fun fetchWithRetries(
        item: DownloadItem, t: Task, keys: ConcurrentHashMap<String, ByteArray>, received: AtomicLong, cfg: SettingsData,
    ): ByteArray {
        var attempt = 0
        while (true) {
            coroutineContext.ensureActive()
            try {
                var data = get(item, t.url, t.range, received)
                val key = t.key
                if (key != null) {
                    val k = keys[key.uri!!] ?: get(item, key.uri, null, null).also {
                        if (it.size != 16) throw FatalDownloadException("Clé de déchiffrement invalide")
                        keys[key.uri] = it
                    }
                    data = decrypt(data, k, key.iv ?: Hls.sequenceIv(t.seq))
                }
                return data
            } catch (e: CancellationException) {
                throw e
            } catch (e: FatalDownloadException) {
                throw e
            } catch (e: IOException) {
                attempt++
                if (attempt > cfg.retries.coerceIn(2, 30)) throw e
                delay(minOf(1000L * attempt, 8000L))
            }
        }
    }

    private fun decrypt(data: ByteArray, key: ByteArray, iv: ByteArray): ByteArray {
        val spec = SecretKeySpec(key, "AES")
        return runCatching {
            Cipher.getInstance("AES/CBC/PKCS5Padding").apply { init(Cipher.DECRYPT_MODE, spec, IvParameterSpec(iv)) }.doFinal(data)
        }.getOrElse {
            // Certains serveurs n'ajoutent pas de bourrage : on déchiffre alors sans le retirer.
            Cipher.getInstance("AES/CBC/NoPadding").apply { init(Cipher.DECRYPT_MODE, spec, IvParameterSpec(iv)) }
                .doFinal(data.copyOf(data.size - data.size % 16))
        }
    }

    private fun request(item: DownloadItem, url: String): Request.Builder {
        val b = Request.Builder().url(url)
            .header("User-Agent", settings.value.userAgent.ifBlank { SettingsData.DEFAULT_UA })
            .header("Accept", "*/*")
        if (item.referer.startsWith("http")) {
            b.header("Referer", item.referer)
            runCatching { java.net.URI(item.referer) }.getOrNull()?.let { u ->
                if (u.scheme != null && u.host != null) b.header("Origin", "${u.scheme}://${u.host}" + if (u.port > 0) ":${u.port}" else "")
            }
        }
        val cookie = item.cookie.ifBlank { runCatching { android.webkit.CookieManager.getInstance().getCookie(url) }.getOrNull().orEmpty() }
        if (cookie.isNotBlank()) b.header("Cookie", cookie)
        Headers.apply(b, item.headers)
        return b
    }

    private suspend fun text(item: DownloadItem, url: String): String? {
        val bytes = runCatching { get(item, url, null, null, max = 20L shl 20) }.getOrElse {
            if (it is CancellationException) throw it
            if (it is FatalDownloadException) throw it
            return null
        }
        return String(bytes, Charsets.UTF_8)
    }

    private suspend fun get(item: DownloadItem, url: String, range: LongRange?, received: AtomicLong?, max: Long = 512L shl 20): ByteArray {
        val b = request(item, url)
        if (range != null) b.header("Range", "bytes=${range.first}-${range.last}")
        client.newCall(b.build()).execute().use { r ->
            if (r.code == 401 || r.code == 403 || r.code == 410) {
                throw ExpiredLinkException("Accès refusé par le serveur (HTTP ${r.code}) : le lien a peut-être expiré")
            }
            if (!r.isSuccessful) throw IOException("Erreur du serveur (HTTP ${r.code})")
            val body = r.body ?: throw IOException("Réponse vide")
            val out = java.io.ByteArrayOutputStream(body.contentLength().takeIf { it in 1..max }?.toInt() ?: 256 * 1024)
            val buf = ByteArray(64 * 1024)
            body.byteStream().use { input ->
                while (true) {
                    coroutineContext.ensureActive()
                    val n = input.read(buf)
                    if (n < 0) break
                    if (received != null) limiter.acquire(n)
                    out.write(buf, 0, n)
                    received?.addAndGet(n.toLong())
                    if (out.size() > max) throw IOException("Morceau trop volumineux")
                }
            }
            // Le serveur a ignoré la plage demandée : on découpe nous-mêmes.
            if (range != null && r.code == 200) {
                val all = out.toByteArray()
                val end = minOf(all.size.toLong(), range.last + 1).toInt()
                return all.copyOfRange(range.first.toInt().coerceAtMost(end), end)
            }
            return out.toByteArray()
        }
    }

    private fun concat(parts: List<File>, out: File) {
        out.outputStream().buffered(1 shl 20).use { o ->
            for (p in parts) {
                if (!p.isFile) throw IOException("Morceau manquant : ${p.name}")
                p.inputStream().use { it.copyTo(o, 1 shl 20) }
            }
        }
    }
}

/**
 * Lance le ffmpeg embarqué par la bibliothèque vidéo (libffmpeg.so) directement, sans passer par yt-dlp.
 * Renvoie (code de sortie, fin du journal).
 */
object FFmpegRunner {
    fun run(context: Context, args: List<String>): Pair<Int, String> {
        val bin = File(context.applicationInfo.nativeLibraryDir, "libffmpeg.so")
        if (!bin.exists()) return -1 to "ffmpeg absent"
        runCatching { com.yausername.ffmpeg.FFmpeg.getInstance().init(context) }
        val packages = File(context.noBackupFilesDir, "youtubedl-android/packages")
        val libs = listOf(File(packages, "ffmpeg/usr/lib"), File(packages, "python/usr/lib"))
            .filter { it.isDirectory }.joinToString(":") { it.path }
        return try {
            val pb = ProcessBuilder(listOf(bin.path) + args).redirectErrorStream(true)
            if (libs.isNotEmpty()) pb.environment()["LD_LIBRARY_PATH"] = libs
            val p = pb.start()
            val log = p.inputStream.bufferedReader().readText()
            p.waitFor() to log.takeLast(2000)
        } catch (t: Throwable) {
            -1 to (t.message ?: t.javaClass.simpleName)
        }
    }
}
