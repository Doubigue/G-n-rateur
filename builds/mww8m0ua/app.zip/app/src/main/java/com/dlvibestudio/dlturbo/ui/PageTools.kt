package com.dlvibestudio.dlturbo.ui

import android.net.Uri
import com.dlvibestudio.dlturbo.engine.Links
import com.dlvibestudio.dlturbo.engine.Mega
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Famille d'un lien, pour les filtres des listes « Ressources » et « Grabber ». */
enum class LinkKind(val label: String) {
    VIDEO("Vidéo"), AUDIO("Audio"), IMAGE("Image"), DOCUMENT("Document"), ARCHIVE("Archive"),
    APK("Appli"), TORRENT("Torrent"), MEGA("Mega"), PAGE("Page"), OTHER("Autre");

    companion object {
        /** Familles cochées par défaut (les fichiers qu'on veut en général). */
        val FILES = setOf(VIDEO, AUDIO, IMAGE, DOCUMENT, ARCHIVE, APK, TORRENT, MEGA)
    }
}

/** Un lien trouvé dans une page. [mediaKind] : HLS, DASH, MP4… quand c'est un média reconnu. */
data class LinkEntry(
    val url: String,
    val kind: LinkKind,
    val text: String = "",
    val mediaKind: String = "",
    val headers: Map<String, String> = emptyMap(),
    val referer: String = "",
    val level: Int = 1,
) {
    val extension: String get() = PageTools.extension(url)
    val isStream: Boolean
        get() = mediaKind == "HLS" || mediaKind == "DASH" || extension == "m3u8" || extension == "mpd"
    val displayName: String
        get() = text.takeIf { it.isNotBlank() && kind != LinkKind.IMAGE }
            ?: runCatching { Uri.decode(Uri.parse(url).lastPathSegment ?: "") }.getOrNull()?.takeIf { it.isNotBlank() }
            ?: url
}

/** Un élément de la page lue en « mode lecture ». */
data class ReaderBlock(val type: String, val text: String)

data class ReaderDoc(val title: String, val site: String, val url: String, val blocks: List<ReaderBlock>)

object PageTools {

    private val EXT = mapOf(
        LinkKind.VIDEO to "mp4 m4v mkv webm mov avi flv wmv 3gp ts m3u8 mpd mpeg mpg",
        LinkKind.AUDIO to "mp3 m4a aac ogg oga opus wav flac wma amr",
        LinkKind.IMAGE to "jpg jpeg png gif webp bmp svg avif heic ico tif tiff",
        LinkKind.DOCUMENT to "pdf doc docx xls xlsx ppt pptx txt epub csv odt ods odp rtf srt vtt ass",
        LinkKind.ARCHIVE to "zip rar 7z tar gz bz2 xz tgz iso",
        LinkKind.APK to "apk xapk apks apkm obb",
        LinkKind.TORRENT to "torrent",
        LinkKind.PAGE to "html htm php asp aspx jsp shtml xhtml",
    ).flatMap { (k, v) -> v.split(' ').map { it to k } }.toMap()

    fun extension(url: String): String {
        val path = runCatching { Uri.parse(url).path }.getOrNull().orEmpty()
        val last = path.substringAfterLast('/')
        val dot = last.lastIndexOf('.')
        return if (dot in 0 until last.length - 1) last.substring(dot + 1).lowercase() else ""
    }

    fun kindOf(url: String, mediaKind: String = ""): LinkKind {
        if (url.startsWith("magnet:", true)) return LinkKind.TORRENT
        when (mediaKind) {
            "HLS", "DASH", "MP4", "WEBM", "MKV", "MOV", "FLV" -> return LinkKind.VIDEO
            "MP3", "M4A", "AAC", "OGG" -> return LinkKind.AUDIO
        }
        if (Mega.parse(url) != null) return LinkKind.MEGA
        val ext = extension(url)
        EXT[ext]?.let { return it }
        if (ext.isEmpty()) return LinkKind.PAGE
        return LinkKind.OTHER
    }

    /** Liste JSON [{u, t}] renvoyée par [GRAB_SCRIPT]. */
    fun parseGrab(json: String?, referer: String): List<LinkEntry> {
        val arr = runCatching { JSONArray(json ?: "") }.getOrNull() ?: return emptyList()
        val out = ArrayList<LinkEntry>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val u = o.optString("u")
            if (u.isBlank()) continue
            out.add(LinkEntry(u, kindOf(u), o.optString("t"), referer = referer))
        }
        return out
    }

    private val ATTR = Regex("""(?i)(?:href|src|data-src|data-href|data-url|data-file|file|url|content)\s*[=:]\s*["']([^"'<>\s]{4,2000})["']""")
    private val BARE = Regex("""(?i)(?:https?:)?//[^\s"'<>()\\]+?\.(?:mp4|m4v|mkv|webm|mov|avi|flv|m3u8|mpd|mp3|m4a|aac|flac|wav|ogg|zip|rar|7z|apk|xapk|pdf|epub|torrent|iso)(?:\?[^\s"'<>\\]*)?""")

    /**
     * Grabber sur plusieurs niveaux (comme 1DM) : les pages du même site trouvées au premier niveau sont lues
     * (jusqu'à [maxPages]) et leurs liens ajoutés. [progress] reçoit (pages lues, pages à lire).
     */
    suspend fun grabDeeper(
        client: OkHttpClient, pages: List<String>, ua: String, cookieOf: (String) -> String,
        maxPages: Int = 30, progress: (Int, Int) -> Unit,
    ): List<LinkEntry> = withContext(Dispatchers.IO) {
        val todo = pages.distinct().take(maxPages)
        val c = client.newBuilder().callTimeout(20, TimeUnit.SECONDS).build()
        val gate = Semaphore(4)
        var done = 0
        progress(0, todo.size)
        coroutineScope {
            todo.map { page ->
                async {
                    gate.withPermit {
                        val found = runCatching { linksOf(c, page, ua, cookieOf(page)) }.getOrDefault(emptyList())
                        synchronized(this@PageTools) { done++; progress(done, todo.size) }
                        found
                    }
                }
            }.awaitAll().flatten()
        }
    }

    private fun linksOf(c: OkHttpClient, page: String, ua: String, cookie: String): List<LinkEntry> {
        val req = Request.Builder().url(page).header("User-Agent", ua).header("Accept", "text/html,*/*")
        if (cookie.isNotBlank()) req.header("Cookie", cookie)
        val html = c.newCall(req.build()).execute().use { r ->
            val type = r.header("Content-Type").orEmpty()
            if (!r.isSuccessful || (type.isNotEmpty() && !type.contains("html") && !type.contains("text"))) return emptyList()
            val body = r.body ?: return emptyList()
            body.source().apply { request(3_000_000) }.buffer.clone().readUtf8()
        }
        val base = page.toHttpUrlOrNull() ?: return emptyList()
        val seen = HashSet<String>()
        val out = ArrayList<LinkEntry>()
        fun add(raw: String) {
            val clean = raw.replace("&amp;", "&").replace("\\/", "/").trim()
            if (clean.startsWith("#") || clean.startsWith("javascript:", true) || clean.startsWith("data:", true)) return
            val abs = if (clean.startsWith("magnet:", true)) clean else base.resolve(clean)?.toString() ?: return
            if (!abs.startsWith("http") && !abs.startsWith("magnet:", true)) return
            if (seen.add(abs)) out.add(LinkEntry(abs, kindOf(abs), referer = page, level = 2))
        }
        ATTR.findAll(html).forEach { add(it.groupValues[1]) }
        BARE.findAll(html).forEach { add(it.value) }
        return out
    }

    fun parseReader(json: String?): ReaderDoc? {
        val o = runCatching { JSONObject(json ?: "") }.getOrNull() ?: return null
        val arr = o.optJSONArray("b") ?: return null
        val blocks = (0 until arr.length()).mapNotNull { i ->
            val b = arr.optJSONObject(i) ?: return@mapNotNull null
            ReaderBlock(b.optString("k", "p"), b.optString("x")).takeIf { it.text.isNotBlank() }
        }
        if (blocks.count { it.type == "p" } < 2) return null
        val url = o.optString("u")
        return ReaderDoc(o.optString("t"), Links.hostOf(url), url, blocks)
    }

    /** Tous les liens d'une page : liens, images, médias, cadres, attributs data-*, adresses écrites dans le code. */
    val GRAB_SCRIPT: String = """
        (function(){
          var out = [], seen = {};
          function add(u, t){
            if (!u) return;
            u = String(u).trim();
            if (!/^magnet:/i.test(u)) { try { u = new URL(u, document.baseURI).href; } catch(e) { return; } }
            if (!/^(https?|magnet):/i.test(u) || seen[u]) return;
            seen[u] = 1;
            out.push({ u: u, t: String(t || '').replace(/\s+/g, ' ').trim().slice(0, 120) });
          }
          var q = function(s){ return document.querySelectorAll(s); };
          q('a[href]').forEach(function(a){ add(a.getAttribute('href'), a.textContent || a.title); });
          q('img').forEach(function(i){
            add(i.currentSrc, i.alt); add(i.getAttribute('src'), i.alt);
            ['data-src','data-original','data-lazy-src','data-full'].forEach(function(k){ add(i.getAttribute(k), i.alt); });
            var ss = i.getAttribute('srcset');
            if (ss) ss.split(',').forEach(function(p){ add(p.trim().split(/\s+/)[0], i.alt); });
          });
          q('video,audio,source,track').forEach(function(m){ add(m.currentSrc || m.src); if (m.poster) add(m.poster); });
          q('iframe[src],embed[src],object[data]').forEach(function(f){ add(f.src || f.data); });
          q('[data-href],[data-url],[data-file],[data-video],[data-link],[data-download]').forEach(function(e){
            ['data-href','data-url','data-file','data-video','data-link','data-download'].forEach(function(k){
              var v = e.getAttribute(k); if (v && /^(https?:|\/|magnet:)/i.test(v)) add(v, e.textContent);
            });
          });
          q('meta[content]').forEach(function(m){ var c = m.getAttribute('content'); if (/^https?:\/\//i.test(c)) add(c); });
          try {
            var html = document.documentElement.innerHTML.slice(0, 3000000).replace(/\\\//g, '/');
            var re = /(?:https?:)?\/\/[^\s"'<>()\\]+?\.(?:mp4|m4v|mkv|webm|mov|avi|flv|m3u8|mpd|mp3|m4a|aac|flac|wav|ogg|zip|rar|7z|apk|xapk|pdf|epub|torrent|iso)(?:\?[^\s"'<>\\]*)?/gi, m;
            while ((m = re.exec(html)) && out.length < 4000) add(m[0]);
          } catch(e) {}
          return JSON.stringify(out.slice(0, 4000));
        })();
    """.trimIndent()

    /** Mode lecture : garde le bloc qui contient le plus de texte en paragraphes (titres, listes, citations). */
    val READER_SCRIPT: String = """
        (function(){
          function txt(e){ return (e.innerText || e.textContent || '').replace(/\s+/g, ' ').trim(); }
          var best = null, top = 0;
          document.querySelectorAll('p').forEach(function(p){
            var len = txt(p).length; if (len < 40) return;
            var e = p.parentElement, w = 1;
            while (e && e !== document.body && w > 0.2) {
              e.__dltScore = (e.__dltScore || 0) + len * w;
              if (e.__dltScore > top) { top = e.__dltScore; best = e; }
              e = e.parentElement; w = w / 2;
            }
          });
          var root = document.querySelector('article') || best;
          if (best && root !== best && txt(root).length < txt(best).length * 0.8) root = best;
          if (!root) return '';
          var bad = /comment|share|social|related|footer|sidebar|promo|newsletter|cookie|advert|\bad\b|banner/i;
          var blocks = [];
          root.querySelectorAll('h1,h2,h3,h4,p,li,blockquote,pre').forEach(function(e){
            var c = e.closest('[class],[id]');
            if (c && c !== root && bad.test((c.className || '') + ' ' + (c.id || ''))) return;
            if (e.tagName === 'P' && e.closest('li,blockquote')) return;
            var t = txt(e); if (!t) return;
            var k = /^H/.test(e.tagName) ? 'h' : e.tagName === 'LI' ? 'li' : e.tagName === 'BLOCKQUOTE' ? 'q' : 'p';
            blocks.push({ k: k, x: t.slice(0, 6000) });
          });
          var title = (document.querySelector('h1') && txt(document.querySelector('h1'))) || document.title || '';
          return JSON.stringify({ t: title, u: location.href, b: blocks.slice(0, 1500) });
        })();
    """.trimIndent()

    /** Sélecteur de zone à masquer : appui sur la page, « Agrandir » pour remonter d'un niveau, « Masquer ». */
    val PICKER_SCRIPT: String = """
        (function(){
          if (window.__dltPick) return; window.__dltPick = true;
          var box = document.createElement('div');
          box.style.cssText = 'position:fixed;z-index:2147483646;pointer-events:none;border:2px solid #F5B301;' +
            'background:rgba(245,179,1,.25);display:none;box-sizing:border-box';
          var bar = document.createElement('div');
          bar.style.cssText = 'position:fixed;left:8px;right:8px;bottom:12px;z-index:2147483647;background:#1d1d24;' +
            'color:#fff;border-radius:14px;padding:10px;font:15px sans-serif;display:flex;gap:8px;align-items:center;' +
            'box-shadow:0 2px 12px rgba(0,0,0,.6)';
          var label = document.createElement('span');
          label.style.flex = '1'; label.textContent = 'Touchez la zone à masquer';
          bar.appendChild(label);
          function button(t, bg, fn){
            var b = document.createElement('button'); b.type = 'button'; b.textContent = t;
            b.style.cssText = 'border:0;border-radius:10px;padding:8px 10px;font:600 14px sans-serif;color:#1a1300;background:' + bg;
            b.addEventListener('click', function(e){ e.preventDefault(); e.stopPropagation(); fn(); }, true);
            bar.appendChild(b);
          }
          var cur = null;
          function show(el){
            cur = el; var r = el.getBoundingClientRect();
            box.style.display = 'block'; box.style.left = r.left + 'px'; box.style.top = r.top + 'px';
            box.style.width = r.width + 'px'; box.style.height = r.height + 'px';
            label.textContent = el.tagName.toLowerCase() + (el.id ? '#' + el.id : '');
          }
          function stable(c){ return c && !/\d{3,}|^(active|hover|focus|show|open|visible|selected)$/i.test(c) && c.length < 40; }
          function selector(el){
            var parts = [], e = el;
            while (e && e.nodeType === 1 && e !== document.body && e !== document.documentElement && parts.length < 6) {
              if (e.id && stable(e.id)) { parts.unshift('#' + CSS.escape(e.id)); break; }
              var s = e.tagName.toLowerCase();
              var cls = Array.prototype.filter.call(e.classList, stable).slice(0, 3);
              if (cls.length) s += '.' + cls.map(function(c){ return CSS.escape(c); }).join('.');
              var p = e.parentElement;
              if (p) {
                var same = Array.prototype.filter.call(p.children, function(x){ return x.tagName === e.tagName; });
                if (same.length > 1 && !cls.length) s += ':nth-of-type(' + (same.indexOf(e) + 1) + ')';
              }
              parts.unshift(s);
              var sel = parts.join(' > ');
              try { if (document.querySelectorAll(sel).length === 1) return sel; } catch(x) {}
              e = p;
            }
            return parts.join(' > ');
          }
          function onTap(e){
            if (bar.contains(e.target)) return;
            e.preventDefault(); e.stopPropagation();
            box.style.display = 'none';
            var el = document.elementFromPoint(e.clientX, e.clientY);
            if (el && el !== document.body && el !== document.documentElement && el !== bar) show(el);
          }
          function end(){
            document.removeEventListener('click', onTap, true);
            box.remove(); bar.remove(); window.__dltPick = false;
          }
          button('Agrandir', '#d9d9e3', function(){
            if (cur && cur.parentElement && cur.parentElement !== document.body) show(cur.parentElement);
          });
          button('Masquer', '#F5B301', function(){
            if (!cur) return;
            var sel = selector(cur);
            try { document.querySelectorAll(sel).forEach(function(x){ x.style.setProperty('display', 'none', 'important'); }); } catch(x) {}
            try { DLP.hide(location.hostname, sel); } catch(x) {}
            end();
          });
          button('Annuler', '#d9d9e3', end);
          document.documentElement.appendChild(box);
          document.documentElement.appendChild(bar);
          document.addEventListener('click', onTap, true);
        })();
    """.trimIndent()

    /** Placé au début de chaque page : applique les zones masquées du site (demandées au pont « DLP »). */
    val HIDE_SCRIPT: String = """
        (function(){
          try {
            if (!window.DLP) return;
            var css = DLP.css(location.hostname);
            if (!css) return;
            function put(){
              try {
                var root = document.head || document.documentElement;
                if (!root || document.getElementById('__dlt_hide')) return;
                var s = document.createElement('style'); s.id = '__dlt_hide'; s.textContent = css;
                root.appendChild(s);
              } catch(e) {}
            }
            document.addEventListener('DOMContentLoaded', put);
            window.addEventListener('load', put);
            put();
            if (!document.documentElement) {
              var mo = new MutationObserver(function(){ if (document.documentElement) { mo.disconnect(); put(); } });
              mo.observe(document, { childList: true });
            }
          } catch(e) {}
        })();
    """.trimIndent()

    /** N'exécute [script] que si le site (celui de la page principale, même dans un cadre) n'a pas coupé [flag]. */
    fun unlessSite(flag: String, script: String): String = """
(function(){
  try {
    var h = location.hostname;
    try { var a = location.ancestorOrigins; if (a && a.length) h = new URL(a[a.length - 1]).hostname; } catch(e) {}
    if (window.DLP && DLP.off(h, '$flag')) return;
  } catch(e) {}
$script
})();"""
}
