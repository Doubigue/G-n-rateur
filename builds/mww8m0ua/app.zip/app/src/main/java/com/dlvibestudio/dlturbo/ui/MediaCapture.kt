package com.dlvibestudio.dlturbo.ui

import android.webkit.JavascriptInterface
import android.webkit.MimeTypeMap
import java.io.File
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Base64
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Capture renforcée : complète l'observation du trafic (qui ne voit que les adresses) par un script placé
 * dans chaque page et chaque lecteur intégré. Il regarde ce que la page REÇOIT (type du contenu, début
 * des listes HLS / DASH) et ce que ses lecteurs annoncent : les flux sans extension sont ainsi repérés.
 * Les vidéos protégées par DRM ne sont pas concernées.
 */
class CaptureBridge(
    private val blobs: BlobReceiver? = null,
    private val onFound: (MediaHit) -> Unit,
) {

    /** Appelé par le script (hors du fil principal). Les valeurs viennent de la page : jamais exécutées. */
    @JavascriptInterface
    fun found(url: String?, mime: String?, disposition: String?, size: String?, page: String?) {
        val u = url ?: return
        if (u.length > 8_000) return
        val hit = MediaSniffer.fromResponse(
            u, mime.orEmpty(), disposition.orEmpty(), size?.toLongOrNull() ?: 0L, page.orEmpty().take(8_000),
        ) ?: return
        onFound(hit)
    }

    /** Fichier « blob: » / « data: » créé par la page : envoyé par morceaux (voir [BlobReceiver]). */
    @JavascriptInterface
    fun blobStart(name: String?, mime: String?, size: String?, page: String?): String =
        blobs?.start(name.orEmpty(), mime.orEmpty(), size?.toLongOrNull() ?: -1, page.orEmpty()) ?: ""

    @JavascriptInterface
    fun blobChunk(id: String?, base64: String?): Boolean = blobs?.chunk(id.orEmpty(), base64.orEmpty()) ?: false

    @JavascriptInterface
    fun blobEnd(id: String?, ok: Boolean) {
        blobs?.end(id.orEmpty(), ok)
    }

    companion object {
        /** Nom du pont vu par le script. */
        const val NAME = "DLC"

        val SCRIPT: String = """
        (function(){
          var MEDIA = /mpegurl|dash\+xml|^video\/|^audio\//i;
          var EXT = /\.(m3u8|mpd|mp4|m4v|webm|mkv|mov|flv|mp3|m4a|aac|ogg)(\?|#|${'$'})/i;
          var SKIP_BODY = /^(image|font)\/|javascript|css|^application\/(json|wasm)/i;
          var sent = {}, count = 0;

          /* Les sites qui vérifient si fetch / XHR ont été modifiés voient la fonction d'origine. */
          function disguise(fake, real){
            try { fake.toString = function(){ return Function.prototype.toString.call(real); }; } catch(e) {}
            return fake;
          }
          function pageOf(w){
            try { var h = w.location.href; if (h.indexOf('http') === 0) return h; } catch(e) {}
            try { return pageOf(w.parent); } catch(e) {}
            return '';
          }
          function bridgeOf(w){
            try { if (w.DLC) return w.DLC; } catch(e) {}
            try { if (w.parent !== w) return bridgeOf(w.parent); } catch(e) {}
            return null;
          }
          function manifestType(text){
            var head = String(text || '').slice(0, 600).replace(/^﻿/, '').trim();
            if (head.indexOf('#EXTM3U') === 0) return 'application/vnd.apple.mpegurl';
            if (/^(<\?xml[^>]*>\s*)?(<!--[\s\S]*?-->\s*)*<MPD[\s>]/.test(head)) return 'application/dash+xml';
            return '';
          }
          function bytesText(buf){
            try { var b = new Uint8Array(buf, 0, Math.min(600, buf.byteLength)); return String.fromCharCode.apply(null, b); }
            catch(e) { return ''; }
          }
          function totalSize(range, length){
            var m = /\/(\d+)\s*${'$'}/.exec(range || '');
            if (m) return parseInt(m[1], 10);
            if (range) return 0;
            return parseInt(length, 10) || 0;
          }

          function install(window){
            if (!window || window.__dltCap) return;
            try { window.__dltCap = true; } catch(e) { return; }
            var document = window.document;

            function report(u, mime, disposition, size){
              try {
                u = new URL(String(u), document.baseURI).href;
                if (u.indexOf('http') !== 0 || sent[u] || count >= 120) return;
                var bridge = bridgeOf(window);
                if (!bridge) return;
                sent[u] = 1; count++;
                bridge.found(u, String(mime || ''), String(disposition || ''), String(size || 0), pageOf(window));
              } catch(e) {}
            }

            /* 1. fetch : type annoncé, sinon les premiers octets (sans lire tout le fichier) */
            var nativeFetch = window.fetch;
            if (typeof nativeFetch === 'function') {
              window.fetch = disguise(function(){
                var p = nativeFetch.apply(this, arguments);
                try {
                  p.then(function(r){
                    try {
                      if (!r || !r.ok) return;
                      var type = r.headers.get('content-type') || '';
                      var disp = r.headers.get('content-disposition') || '';
                      if (MEDIA.test(type) || /filename/i.test(disp)) {
                        report(r.url, type, disp, totalSize(r.headers.get('content-range'), r.headers.get('content-length')));
                        return;
                      }
                      if (SKIP_BODY.test(type) || r.bodyUsed || !r.body) return;
                      var reader = r.clone().body.getReader();
                      reader.read().then(function(c){
                        try { reader.cancel(); } catch(e) {}
                        var m = c && c.value ? manifestType(bytesText(c.value.buffer.slice(c.value.byteOffset, c.value.byteOffset + 600))) : '';
                        if (m) report(r.url, m, '', 0);
                      }, function(){});
                    } catch(e) {}
                  }, function(){});
                } catch(e) {}
                return p;
              }, nativeFetch);
            }

            /* 2. XMLHttpRequest (hls.js, dash.js, Shaka, Video.js…) */
            var X = window.XMLHttpRequest;
            if (X && X.prototype) {
              var nativeSend = X.prototype.send;
              X.prototype.send = disguise(function(){
                var x = this;
                try {
                  if (!x.__dltWatched) {
                    x.__dltWatched = true;
                    x.addEventListener('load', function(){
                      try {
                        if (x.status < 200 || x.status >= 300 || !x.responseURL) return;
                        var type = x.getResponseHeader('content-type') || '';
                        var disp = x.getResponseHeader('content-disposition') || '';
                        var rt = x.responseType, text = '';
                        if (rt === '' || rt === 'text') text = String(x.responseText).slice(0, 600);
                        else if (rt === 'arraybuffer' && x.response) text = bytesText(x.response);
                        var m = manifestType(text);
                        if (m) report(x.responseURL, m, '', 0);
                        else if (MEDIA.test(type) || /filename/i.test(disp)) {
                          report(x.responseURL, type, disp,
                            totalSize(x.getResponseHeader('content-range'), x.getResponseHeader('content-length')));
                        }
                      } catch(e) {}
                    });
                  }
                } catch(e) {}
                return nativeSend.apply(this, arguments);
              }, nativeSend);
            }

            /* 3. Lecteurs, y compris dans un « shadow DOM » */
            var roots = [];
            var E = window.Element;
            var nativeAttach = E && E.prototype.attachShadow;
            if (nativeAttach) {
              E.prototype.attachShadow = disguise(function(){
                var root = nativeAttach.apply(this, arguments);
                try { if (roots.length < 200) { roots.push(root); root.addEventListener('play', onMedia, true); } } catch(e) {}
                return root;
              }, nativeAttach);
            }
            function element(el){
              if (!el || (el.tagName !== 'VIDEO' && el.tagName !== 'AUDIO')) return;
              var kind = el.tagName === 'VIDEO' ? 'element/video' : 'element/audio';
              var list = el.getElementsByTagName('source');
              for (var i = 0; i < list.length; i++) {
                var t = list[i].type || '';
                if (list[i].src) report(list[i].src, MEDIA.test(t) ? t : kind, '', 0);
              }
              var src = el.currentSrc || el.src;
              if (src) report(src, kind, '', 0);
            }
            function onMedia(e){ element(e.target); }
            document.addEventListener('play', onMedia, true);
            document.addEventListener('loadedmetadata', onMedia, true);

            function players(){
              try {
                if (typeof window.jwplayer === 'function') {
                  var pl = window.jwplayer().getPlaylist() || [];
                  for (var i = 0; i < pl.length && i < 5; i++) {
                    var s = pl[i].sources || [];
                    for (var j = 0; j < s.length; j++) {
                      if (!s[j].file) continue;
                      var t = s[j].type || '';
                      report(s[j].file, t === 'hls' ? 'application/vnd.apple.mpegurl' : t === 'dash' ? 'application/dash+xml'
                        : 'element/video', '', 0);
                    }
                  }
                }
              } catch(e) {}
              try {
                var all = window.videojs && window.videojs.getPlayers ? window.videojs.getPlayers() : {};
                for (var k in all) {
                  var cur = all[k] && all[k].currentSource ? all[k].currentSource() : null;
                  if (cur && cur.src) report(cur.src, MEDIA.test(cur.type || '') ? cur.type : 'element/video', '', 0);
                }
              } catch(e) {}
              try {
                var metas = document.querySelectorAll('meta[property="og:video"],meta[property="og:video:url"],meta[property="og:video:secure_url"]');
                for (var m = 0; m < metas.length; m++) {
                  var c = metas[m].getAttribute('content') || '';
                  if (EXT.test(c)) report(c, '', '', 0);
                }
              } catch(e) {}
            }

            /* 4. Fichiers créés par la page (« blob: », « data: ») : lus ici et envoyés à l'application. */
            var blobs = {}, blobKeys = [], saving = {};
            var U = window.URL;
            var nativeCreate = U && U.createObjectURL, nativeRevoke = U && U.revokeObjectURL;
            if (nativeCreate) {
              U.createObjectURL = disguise(function(o){
                var u = nativeCreate.apply(this, arguments);
                try {
                  if (o && typeof o.size === 'number' && typeof o.slice === 'function') {
                    blobs[u] = o; blobKeys.push(u);
                    if (blobKeys.length > 60) delete blobs[blobKeys.shift()];
                  }
                } catch(e) {}
                return u;
              }, nativeCreate);
            }
            if (nativeRevoke) {
              U.revokeObjectURL = disguise(function(u){
                /* Gardé quelques secondes : la page révoque souvent juste après avoir lancé le téléchargement. */
                try { setTimeout(function(){ delete blobs[u]; }, 15000); } catch(e) {}
                return nativeRevoke.apply(this, arguments);
              }, nativeRevoke);
            }
            function send(blob, name){
              var bridge = bridgeOf(window);
              if (!bridge || !bridge.blobStart) return false;
              if (!name && blob.name) name = blob.name;
              var id = bridge.blobStart(String(name || ''), String(blob.type || ''), String(blob.size), pageOf(window));
              if (!id) return false;
              var off = 0, CH = 524288;
              function next(){
                if (off >= blob.size) { bridge.blobEnd(id, true); return; }
                var r = new window.FileReader();
                r.onload = function(){
                  var s = String(r.result), c = s.indexOf(',');
                  if (!bridge.blobChunk(id, c >= 0 ? s.substring(c + 1) : '')) return;
                  off += CH; setTimeout(next, 0);
                };
                r.onerror = function(){ bridge.blobEnd(id, false); };
                r.readAsDataURL(blob.slice(off, off + CH));
              }
              next();
              return true;
            }
            function saveBlob(u, name){
              u = String(u || '');
              if (!/^(blob|data):/i.test(u) || saving[u]) return !!saving[u];
              saving[u] = 1;
              setTimeout(function(){ delete saving[u]; }, 20000);
              if (blobs[u]) return send(blobs[u], name);
              try {
                (nativeFetch || window.fetch).call(window, u).then(function(r){ return r.blob(); })
                  .then(function(b){ send(b, name); }, function(){ delete saving[u]; });
              } catch(e) { delete saving[u]; return false; }
              return true;
            }
            window.__dltSaveBlob = saveBlob;
            function anchorSave(a){
              try {
                var h = a.href || '';
                if (/^(blob|data):/i.test(h) && a.hasAttribute('download')) saveBlob(h, a.getAttribute('download') || '');
              } catch(e) {}
            }
            document.addEventListener('click', function(e){
              try { var a = e.target && e.target.closest ? e.target.closest('a') : null; if (a) anchorSave(a); } catch(x) {}
            }, true);
            var A = window.HTMLAnchorElement;
            if (A && A.prototype.click) {
              var nativeClick = A.prototype.click;
              A.prototype.click = disguise(function(){ anchorSave(this); return nativeClick.apply(this, arguments); }, nativeClick);
            }

            /* 5. Cadres vides (about:blank, srcdoc) remplis par la page : le script n'y est pas placé tout seul. */
            function frames(){
              try {
                var fs = document.getElementsByTagName('iframe');
                for (var i = 0; i < fs.length; i++) {
                  var f = fs[i];
                  if (!f.__dltLoad) { f.__dltLoad = true; f.addEventListener('load', frames); }
                  try { var w = f.contentWindow; if (w && w.document && !w.__dltCap) install(w); } catch(e) {}
                }
              } catch(e) {}
            }

            function scan(){
              try {
                [document].concat(roots).forEach(function(r){
                  var v = r.querySelectorAll('video,audio');
                  for (var i = 0; i < v.length; i++) element(v[i]);
                });
              } catch(e) {}
              players();
              frames();
            }
            frames();
            window.setInterval(scan, 1500);

            /* 6. Listes chargées autrement (journal des ressources du navigateur) */
            try {
              new window.PerformanceObserver(function(l){
                l.getEntries().forEach(function(e){
                  if (/\.(m3u8|mpd)(\?|#|${'$'})/i.test(e.name)) report(e.name, '', '', 0);
                });
              }).observe({ type: 'resource', buffered: true });
            } catch(e) {}
          }

          install(window);
        })();
""".trimIndent()
    }
}

/**
 * Reçoit les fichiers « blob: » / « data: » d'une page (images générées, fichiers déchiffrés, exports…),
 * comme 1DM : la page les lit par morceaux de 512 Ko, ils sont écrits dans le dossier de téléchargement
 * puis affichés comme téléchargements terminés.
 */
class BlobReceiver(
    private val dir: () -> File,
    private val onDone: (file: File, name: String, source: String) -> Unit,
    private val toast: (String) -> Unit,
) {
    private class Session(val file: File, val out: OutputStream, val name: String, val source: String) {
        var written = 0L
    }

    private val sessions = ConcurrentHashMap<String, Session>()

    /** Heure du dernier fichier commencé (sert à signaler un échec quand rien n'arrive). */
    @Volatile
    var lastStart = 0L
        private set

    fun start(name: String, mime: String, size: Long, page: String): String {
        if (sessions.size >= 6) return ""
        val folder = dir()
        folder.mkdirs()
        if (size > 0 && folder.usableSpace in 1 until size + MARGIN) {
            toast("Espace de stockage insuffisant")
            return ""
        }
        val id = UUID.randomUUID().toString().replace("-", "").take(16)
        val file = File(folder, ".blob_$id.part")
        val out = runCatching { file.outputStream().buffered(1 shl 20) }.getOrNull() ?: return ""
        val display = fileName(name, mime)
        sessions[id] = Session(file, out, display, page.ifBlank { "Fichier créé par la page" })
        lastStart = System.currentTimeMillis()
        toast("Enregistrement de « $display »…")
        return id
    }

    fun chunk(id: String, base64: String): Boolean {
        val s = sessions[id] ?: return false
        return try {
            val bytes = Base64.getDecoder().decode(base64)
            s.out.write(bytes)
            s.written += bytes.size
            true
        } catch (t: Throwable) {
            abort(id)
            false
        }
    }

    fun end(id: String, ok: Boolean) {
        val s = sessions.remove(id) ?: return
        runCatching { s.out.close() }
        if (!ok) {
            s.file.delete()
            toast("Le fichier « ${s.name} » n'a pas pu être récupéré")
            return
        }
        try {
            onDone(s.file, s.name, s.source)
            toast("Fichier enregistré : ${s.name}")
        } catch (t: Throwable) {
            s.file.delete()
            toast("Enregistrement impossible : ${t.message ?: t.javaClass.simpleName}")
        }
    }

    /** Lien « data: » reçu directement par l'application (sans passer par la page). */
    fun saveData(url: String, source: String): Boolean {
        val comma = url.indexOf(',')
        if (!url.startsWith("data:", true) || comma < 0) return false
        val meta = url.substring(5, comma)
        val mime = meta.substringBefore(';')
        val bytes = runCatching {
            if (meta.contains(";base64", true)) Base64.getMimeDecoder().decode(url.substring(comma + 1))
            else android.net.Uri.decode(url.substring(comma + 1)).toByteArray()
        }.getOrNull() ?: return false
        val folder = dir().apply { mkdirs() }
        val file = File(folder, ".blob_" + UUID.randomUUID().toString().take(8) + ".part")
        file.writeBytes(bytes)
        val name = fileName("", mime)
        onDone(file, name, source)
        toast("Fichier enregistré : $name")
        return true
    }

    private fun abort(id: String) {
        val s = sessions.remove(id) ?: return
        runCatching { s.out.close() }
        s.file.delete()
    }

    private fun fileName(name: String, mime: String): String {
        val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime.substringBefore(';').trim().lowercase()).orEmpty()
        var n = name.substringAfterLast('/').trim()
        if (n.isBlank()) n = "fichier_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        if (ext.isNotBlank() && !n.contains('.')) n = "$n.$ext"
        return n
    }

    companion object {
        private const val MARGIN = 50L * 1024 * 1024
    }
}
