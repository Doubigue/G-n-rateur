package com.dlvibestudio.dlturbo.engine

import android.net.Uri
import android.webkit.MimeTypeMap
import java.io.File
import java.net.URLDecoder

/** Reconnaissance des liens et utilitaires de noms de fichiers. */
object Links {

    private val VIDEO_HOSTS = listOf(
        "youtube.com", "youtu.be", "youtube-nocookie.com",
        "instagram.com", "instagr.am",
        "facebook.com", "fb.watch", "fb.com",
        "tiktok.com",
        "pinterest.", "pin.it",
        "twitter.com", "x.com", "t.co",
        "vimeo.com", "dailymotion.com", "dai.ly",
        "twitch.tv", "reddit.com", "redd.it",
        "soundcloud.com", "snapchat.com", "threads.net", "threads.com",
        "likee.video", "bilibili.com", "vk.com", "ok.ru", "rumble.com",
        "linkedin.com", "tumblr.com", "streamable.com", "kwai.com", "bsky.app",
        // Telegram : messages des canaux et groupes publics (t.me/canal/1234)
        "t.me", "telegram.me", "telegram.dog",
    )

    private val URL_REGEX = Regex("""(magnet:\?[^\s]+|https?://[^\s]+)""", RegexOption.IGNORE_CASE)

    fun isMagnet(url: String) = url.startsWith("magnet:", ignoreCase = true)

    fun isTorrentUrl(url: String): Boolean {
        val path = runCatching { Uri.parse(url).path }.getOrNull() ?: return false
        return path.endsWith(".torrent", ignoreCase = true)
    }

    fun isVideoSite(url: String): Boolean {
        val host = runCatching { Uri.parse(url).host }.getOrNull()?.lowercase() ?: return false
        return VIDEO_HOSTS.any { host == it || host.endsWith(".$it") || (it.endsWith(".") && host.contains(it)) }
    }

    /** Extrait tous les liens d'un texte (texte partagé, presse-papiers, plusieurs lignes…). */
    fun extract(text: String): List<String> =
        URL_REGEX.findAll(text).map { telegramPost(it.value.trim().trimEnd(',', ';', ')', '"', '\'')) }
            .distinct().toList()

    /**
     * Lien de message Telegram public : t.me/s/canal/123 (aperçu web) ou telegram.me/… → t.me/canal/123,
     * forme reconnue par l'extracteur vidéo. Les autres liens sont rendus tels quels.
     */
    fun telegramPost(url: String): String {
        val m = Regex("""(?i)^https?://(?:www\.)?(?:t\.me|telegram\.me|telegram\.dog)/(?:s/)?([A-Za-z0-9_]{4,})/(\d+)""").find(url)
            ?: return url
        val single = if (url.contains("single", ignoreCase = true)) "?single" else ""
        return "https://t.me/${m.groupValues[1]}/${m.groupValues[2]}$single"
    }

    fun hostOf(url: String): String =
        runCatching { Uri.parse(url).host }.getOrNull()?.removePrefix("www.") ?: "lien"

    /** Nom de fichier à partir de l'en-tête Content-Disposition, sinon de l'URL. */
    fun fileName(url: String, contentDisposition: String?, mime: String?): String {
        var name: String? = null
        if (contentDisposition != null) {
            val star = Regex("""filename\*\s*=\s*(?:UTF-8|utf-8)''([^;]+)""").find(contentDisposition)
            val plain = Regex("""filename\s*=\s*"?([^";]+)"?""").find(contentDisposition)
            name = when {
                star != null -> runCatching { URLDecoder.decode(star.groupValues[1], "UTF-8") }.getOrNull()
                plain != null -> plain.groupValues[1].trim()
                else -> null
            }
        }
        if (name.isNullOrBlank()) {
            name = runCatching { Uri.parse(url).lastPathSegment }.getOrNull()
        }
        if (name.isNullOrBlank()) name = "fichier"
        name = sanitize(name)
        if (!name.contains('.') || name.substringAfterLast('.').length > 6) {
            val ext = mime?.substringBefore(';')?.trim()?.let {
                MimeTypeMap.getSingleton().getExtensionFromMimeType(it)
            }
            if (!ext.isNullOrBlank() && ext != "bin") name = "$name.$ext"
        }
        return name
    }

    fun isFacebook(url: String): Boolean {
        val host = runCatching { Uri.parse(url).host?.lowercase() }.getOrNull() ?: return false
        return host == "fb.watch" || host == "fb.com" || host.endsWith(".fb.com") ||
            host == "facebook.com" || host.endsWith(".facebook.com")
    }

    /** Variantes mobiles de Facebook (m., mbasic., touch., web.) : ramenées à www.facebook.com, mieux reconnu. */
    fun normalizeVideoUrl(url: String): String {
        if (!isFacebook(url)) return url
        val uri = runCatching { Uri.parse(url) }.getOrNull() ?: return url
        val host = uri.host?.lowercase() ?: return url
        if (host in setOf("m.facebook.com", "mbasic.facebook.com", "touch.facebook.com", "web.facebook.com", "mobile.facebook.com", "facebook.com")) {
            return uri.buildUpon().scheme("https").authority("www.facebook.com").build().toString()
        }
        return url
    }

    /**
     * Début des titres Facebook : « 174K views · 1.4K reactions | », « 3,2 M vues · 68 K réactions | »…
     * (syntaxe commune Java / Python : sert aussi pour yt-dlp).
     */
    const val FB_STATS_PREFIX =
        """(?i)^(?:[^|]*?\d[^|]*?(?:views?|reactions?|shares?|comments?|plays?|likes?|vues?|réactions?|partages?|commentaires?|lectures?|j'aime|j’aime)[^|]*\|\s*)+"""

    private val FB_STATS = Regex(FB_STATS_PREFIX)

    /**
     * Titre propre pour nommer le fichier : sans les vues, réactions et partages de Facebook, sans le nom de la page
     * ajouté à la fin (« … | Nom de la page »), sans l'identifiant « [1499…] ».
     */
    fun cleanVideoTitle(title: String, uploader: String = ""): String {
        var t = title.trim()
        val noStats = t.replace(FB_STATS, "").trim()
        if (noStats.isNotBlank()) t = noStats
        if (uploader.isNotBlank()) {
            val parts = t.split('|').map { it.trim() }
            if (parts.size >= 2 && parts.last().equals(uploader.trim(), ignoreCase = true)) {
                t = parts.dropLast(1).joinToString(" | ")
            }
        }
        t = t.replace(Regex("""\s*\[[0-9]{6,}]\s*$"""), "")
        return t.replace(Regex("\\s+"), " ").trim().trim('|', '·', '-', ' ')
    }

    fun isYoutube(url: String): Boolean {
        val host = runCatching { Uri.parse(url).host?.lowercase() }.getOrNull() ?: return false
        return host == "youtu.be" || host == "youtube.com" || host.endsWith(".youtube.com")
    }

    /**
     * Nom d'une vidéo YouTube : le titre tel quel. Seuls les caractères que le stockage Android refuse sont remplacés,
     * par leur équivalent pleine chasse (« ? » → « ？ », « : » → « ： »…), comme le fait yt-dlp : le nom reste identique à l'œil.
     */
    fun youtubeName(title: String): String {
        val map = mapOf(
            '/' to '⧸', '\\' to '⧹', ':' to '：', '*' to '＊', '?' to '？', '"' to '＂',
            '<' to '＜', '>' to '＞', '|' to '｜', '%' to '％',
        )
        val sb = StringBuilder()
        for (ch in title) {
            when {
                ch.code < 32 -> sb.append(' ')
                else -> sb.append(map[ch] ?: ch)
            }
        }
        var out = sb.toString().replace(Regex("\\s+"), " ").trim().trim('.').trim()
        if (out.isBlank()) return "Vidéo"
        // 230 octets au plus (limite de 255 pour le nom complet, extension comprise).
        while (out.toByteArray(Charsets.UTF_8).size > 230) out = out.dropLast(1)
        return out.trim()
    }

    fun sanitize(name: String): String {
        val cleaned = name.replace(Regex("""[\\/:*?"<>|\u0000-\u001f]"""), "_").trim().trim('.')
        return (if (cleaned.isBlank()) "fichier" else cleaned).take(180)
    }

    /** Évite d'écraser un fichier existant : « nom (1).ext », « nom (2).ext »… */
    fun uniqueFile(dir: File, name: String, reserved: Set<String> = emptySet()): File {
        var candidate = File(dir, name)
        if (!taken(candidate, reserved)) return candidate
        val base = name.substringBeforeLast('.', name)
        val ext = if (name.contains('.')) "." + name.substringAfterLast('.') else ""
        var i = 1
        while (true) {
            candidate = File(dir, "$base ($i)$ext")
            if (!taken(candidate, reserved)) return candidate
            i++
        }
    }

    private fun taken(f: File, reserved: Set<String>) =
        f.exists() || File(f.path + PART_SUFFIX).exists() || reserved.contains(f.path)

    const val PART_SUFFIX = ".dlpart"

    fun mimeOf(fileName: String): String {
        val ext = fileName.substringAfterLast('.', "").lowercase()
        if (ext == "apk") return "application/vnd.android.package-archive"
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
    }

    /** Sous-dossier de rangement selon le type de fichier. */
    fun category(fileName: String): String {
        return when (fileName.substringAfterLast('.', "").lowercase()) {
            "mp4", "mkv", "webm", "avi", "mov", "flv", "3gp", "m4v", "ts", "wmv" -> "Vidéos"
            "mp3", "m4a", "aac", "flac", "wav", "ogg", "opus", "wma" -> "Musique"
            "jpg", "jpeg", "png", "gif", "webp", "bmp", "svg", "heic", "avif" -> "Images"
            "apk", "xapk", "apks", "apkm" -> "APK"
            "zip", "rar", "7z", "tar", "gz", "bz2", "xz", "iso" -> "Archives"
            "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "epub", "csv" -> "Documents"
            "exe", "msi", "dmg", "deb", "rpm", "appimage", "pkg" -> "Logiciels"
            else -> "Autres"
        }
    }
}
