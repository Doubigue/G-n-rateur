package com.dlvibestudio.dlturbo.engine

import okhttp3.Request

/**
 * En-têtes envoyés par le lecteur d'une page (User-Agent, Origin, Authorization, jetons « X-… ») :
 * renvoyés tels quels au téléchargement, sinon beaucoup d'hébergeurs répondent 403.
 * Stockés en texte « Nom: valeur », une ligne par en-tête.
 */
object Headers {

    /** Gérés par le moteur de téléchargement lui-même, ou propres à l'application : jamais recopiés. */
    private val DROP = setOf(
        "range", "if-range", "cookie", "host", "connection", "content-length", "content-type",
        "accept-encoding", "transfer-encoding", "upgrade-insecure-requests", "x-requested-with",
        "sec-fetch-user", "te", "keep-alive", "proxy-authorization",
    )

    fun keep(map: Map<String, String>?): Map<String, String> {
        if (map.isNullOrEmpty()) return emptyMap()
        val out = LinkedHashMap<String, String>()
        for ((k, v) in map) {
            val name = k.trim()
            if (name.isEmpty() || name.lowercase() in DROP || v.isBlank()) continue
            if (name.any { it == '\n' || it == '\r' || it == ':' } || v.any { it == '\n' || it == '\r' }) continue
            out[name] = v.trim()
        }
        return out
    }

    fun encode(map: Map<String, String>): String =
        keep(map).entries.joinToString("\n") { "${it.key}: ${it.value}" }

    fun decode(text: String): Map<String, String> {
        if (text.isBlank()) return emptyMap()
        val out = LinkedHashMap<String, String>()
        for (line in text.lines()) {
            val i = line.indexOf(':')
            if (i <= 0) continue
            out[line.substring(0, i).trim()] = line.substring(i + 1).trim()
        }
        return keep(out)
    }

    /** Valeur d'un en-tête, sans tenir compte des majuscules. */
    fun get(map: Map<String, String>, name: String): String? =
        map.entries.firstOrNull { it.key.equals(name, ignoreCase = true) }?.value

    /** Ajoute les en-têtes enregistrés à une requête (ils remplacent ceux par défaut, User-Agent compris). */
    fun apply(builder: Request.Builder, text: String) {
        for ((k, v) in decode(text)) runCatching { builder.header(k, v) }
    }
}
