package com.dlvibestudio.dlturbo.engine

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Liens de fichiers Mega (mega.nz/file/ID#CLÉ). Le fichier est stocké chiffré : on demande à Mega son
 * adresse de téléchargement, on le télécharge comme un fichier normal (plusieurs connexions, reprise),
 * puis on le déchiffre (AES-CTR) avec la clé contenue dans le lien. Les dossiers ne sont pas pris en charge.
 */
object Mega {

    class Link(val id: String, val key: ByteArray) {
        /** Clé AES : les deux moitiés de la clé du lien combinées. */
        val aesKey: ByteArray get() = ByteArray(16) { (key[it].toInt() xor key[it + 16].toInt()).toByte() }

        /** Compteur de départ : 8 octets de la clé, puis 8 octets à zéro. */
        val iv: ByteArray get() = key.copyOfRange(16, 24) + ByteArray(8)
    }

    class Info(val url: String, val size: Long, val name: String)

    private val FILE = Regex(
        """mega(?:\.co)?\.(?:nz|io|app)/(?:file/([A-Za-z0-9_-]{8})#([A-Za-z0-9_-]{43})|(?:#|embed/?#?)!([A-Za-z0-9_-]{8})!([A-Za-z0-9_-]{43}))""",
        RegexOption.IGNORE_CASE,
    )

    fun isMega(url: String): Boolean = Regex("""(^|[/.])mega(\.co)?\.(nz|io|app)([/#?]|$)""", RegexOption.IGNORE_CASE)
        .containsMatchIn(url.substringAfter("://").substringBefore('/') + "/")

    fun isFolder(url: String): Boolean = isMega(url) && (url.contains("/folder/") || url.contains("#F!"))

    fun parse(url: String): Link? {
        val m = FILE.find(url) ?: return null
        val id = m.groupValues[1].ifEmpty { m.groupValues[3] }
        val k = m.groupValues[2].ifEmpty { m.groupValues[4] }
        val key = runCatching { Base64.getUrlDecoder().decode(k) }.getOrNull() ?: return null
        if (key.size != 32) return null
        return Link(id, key)
    }

    /** Demande à Mega l'adresse (temporaire) du fichier, sa taille et son nom. */
    fun resolve(client: OkHttpClient, link: Link): Info {
        val body = JSONArray().put(JSONObject().put("a", "g").put("g", 1).put("ssl", 2).put("p", link.id)).toString()
        val req = Request.Builder()
            .url("https://g.api.mega.co.nz/cs?id=" + (System.currentTimeMillis() % 1_000_000_000))
            .post(body.toRequestBody("application/json".toMediaType()))
            .build()
        val text = client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw IOException("Mega ne répond pas (HTTP ${r.code})")
            r.body?.string() ?: throw IOException("Réponse vide de Mega")
        }
        val value: Any = runCatching { JSONArray(text).get(0) }.getOrElse { text.trim().toIntOrNull() ?: throw IOException("Réponse inattendue de Mega") }
        if (value is Number) throw FatalDownloadException(errorMessage(value.toInt()))
        val o = value as? JSONObject ?: throw IOException("Réponse inattendue de Mega")
        val url = o.optString("g").takeIf { it.startsWith("http") }
            ?: throw FatalDownloadException("Fichier Mega indisponible (supprimé ou bloqué)")
        val name = runCatching { attributes(o.optString("at"), link) }.getOrNull()
            ?.takeIf { it.isNotBlank() } ?: "Mega_${link.id}"
        return Info(url, o.optLong("s", -1), name)
    }

    private fun errorMessage(code: Int) = when (code) {
        -9 -> "Fichier Mega introuvable (supprimé ou lien incorrect)"
        -11 -> "Accès refusé par Mega"
        -16 -> "Fichier Mega bloqué (signalé ou compte suspendu)"
        -17 -> "Quota de transfert Mega dépassé : réessayez plus tard"
        -18 -> "Mega est temporairement indisponible : réessayez plus tard"
        else -> "Erreur Mega ($code)"
    }

    /** Nom du fichier : attributs chiffrés en AES-CBC, au format « MEGA{"n":"nom"} ». */
    internal fun attributes(at: String, link: Link): String {
        val raw = Base64.getUrlDecoder().decode(at)
        val c = Cipher.getInstance("AES/CBC/NoPadding")
        c.init(Cipher.DECRYPT_MODE, SecretKeySpec(link.aesKey, "AES"), IvParameterSpec(ByteArray(16)))
        val plain = String(c.doFinal(raw), Charsets.UTF_8).trimEnd('\u0000')
        if (!plain.startsWith("MEGA{")) return ""
        return JSONObject(plain.removePrefix("MEGA")).optString("n")
    }

    /** Déchiffre [src] dans [dst]. [progress] reçoit le nombre d'octets traités. */
    fun decrypt(src: File, dst: File, link: Link, progress: (Long) -> Unit = {}) {
        val c = Cipher.getInstance("AES/CTR/NoPadding")
        c.init(Cipher.DECRYPT_MODE, SecretKeySpec(link.aesKey, "AES"), IvParameterSpec(link.iv))
        src.inputStream().buffered(1 shl 20).use { input ->
            dst.outputStream().buffered(1 shl 20).use { out ->
                val buf = ByteArray(1 shl 20)
                var done = 0L
                var last = 0L
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(c.update(buf, 0, n) ?: ByteArray(0))
                    done += n
                    if (done - last > (8 shl 20)) { last = done; progress(done) }
                }
                c.doFinal()?.let { out.write(it) }
            }
        }
    }
}
