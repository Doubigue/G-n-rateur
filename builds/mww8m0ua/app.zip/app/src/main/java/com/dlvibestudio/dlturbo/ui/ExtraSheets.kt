@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.dlvibestudio.dlturbo.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.dlvibestudio.dlturbo.engine.Links

/** Liste ouverte : « Ressources de la page » ou « Grabber » (liens de la page, sur 1 ou 2 niveaux). */
class LinksRequest(val title: String, val tab: WebTab, val grabber: Boolean) {
    val entries = mutableStateListOf<LinkEntry>()
    val loading = mutableStateOf(false)
    val level = mutableIntStateOf(1)
    val progress = mutableStateOf("")
}

/** Liste de liens à cocher, avec filtres par famille, par extension et par texte (comme le grabber de 1DM). */
@Composable
fun LinksSheet(hub: WebHub, req: LinksRequest, onDismiss: () -> Unit) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var kinds by remember(req) { mutableStateOf(LinkKind.FILES) }
    var extFilter by remember(req) { mutableStateOf("") }
    var search by remember(req) { mutableStateOf("") }
    // Cochés : par adresse (la liste peut grandir pendant l'exploration du niveau 2).
    val unchecked = remember(req) { mutableStateListOf<String>() }

    val exts = extFilter.split(',', ' ', ';').map { it.trim().trimStart('.').lowercase() }.filter { it.isNotEmpty() }.toSet()
    val shown = req.entries.filter { e ->
        val byKind = if (exts.isNotEmpty()) e.extension in exts else e.kind in kinds
        byKind && (search.isBlank() || e.url.contains(search, true) || e.text.contains(search, true))
    }
    val selected = shown.filter { it.url !in unchecked }
    val counts = req.entries.groupingBy { it.kind }.eachCount()

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding()) {
            Text(
                "${req.title} (${req.entries.size})",
                style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
            )
            if (req.grabber) {
                Row(
                    Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text("Niveau :", style = MaterialTheme.typography.bodyMedium)
                    FilterChip(selected = req.level.intValue == 1, onClick = {}, label = { Text("1 (cette page)") })
                    FilterChip(
                        selected = req.level.intValue == 2,
                        onClick = { if (req.level.intValue == 1) hub.grabDeeper(req) },
                        label = { Text("2 (+ pages liées)") },
                        enabled = !req.loading.value,
                    )
                }
                if (req.loading.value) {
                    LinearProgressIndicator(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp))
                    Text(
                        req.progress.value, style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(horizontal = 20.dp),
                    )
                }
            }
            FlowRow(
                Modifier.padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                LinkKind.entries.forEach { k ->
                    val n = counts[k] ?: 0
                    if (n > 0) {
                        FilterChip(
                            selected = k in kinds && exts.isEmpty(),
                            onClick = { kinds = if (k in kinds) kinds - k else kinds + k },
                            label = { Text("${k.label} $n") },
                        )
                    }
                }
            }
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = extFilter, onValueChange = { extFilter = it }, singleLine = true,
                    label = { Text("Extensions") }, placeholder = { Text("pdf, srt") },
                    modifier = Modifier.weight(1f),
                )
                OutlinedTextField(
                    value = search, onValueChange = { search = it }, singleLine = true,
                    label = { Text("Rechercher") }, modifier = Modifier.weight(1f),
                )
            }
            Row(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = false, onClick = { unchecked.removeAll(shown.map { it.url }.toSet()) }, label = { Text("Tout cocher") })
                FilterChip(
                    selected = false,
                    onClick = { shown.forEach { if (it.url !in unchecked) unchecked.add(it.url) } },
                    label = { Text("Tout décocher") },
                )
            }
            if (shown.isEmpty()) {
                Text(
                    "Aucun lien pour ces filtres.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(20.dp),
                )
            }
            LazyColumn(Modifier.weight(1f, fill = false).heightIn(max = 440.dp)) {
                items(shown, key = { it.url }) { e ->
                    val on = e.url !in unchecked
                    Row(
                        Modifier.fillMaxWidth()
                            .clickable { if (on) unchecked.add(e.url) else unchecked.remove(e.url) }
                            .padding(horizontal = 8.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Checkbox(checked = on, onCheckedChange = { if (it) unchecked.remove(e.url) else unchecked.add(e.url) })
                        Column(Modifier.weight(1f)) {
                            Text(e.displayName, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                            Text(
                                buildString {
                                    append(e.kind.label)
                                    val ext = e.mediaKind.ifBlank { e.extension.uppercase() }
                                    if (ext.isNotBlank()) append(" · ").append(ext)
                                    append(" · ").append(Links.hostOf(e.url))
                                    if (e.level > 1) append(" · niveau 2")
                                },
                                maxLines = 1, overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
            Button(
                onClick = {
                    hub.downloadLinks(req.tab, selected)
                    onDismiss()
                },
                enabled = selected.isNotEmpty(),
                modifier = Modifier.fillMaxWidth().padding(16.dp),
            ) {
                Icon(Icons.Filled.Download, null, modifier = Modifier.size(18.dp))
                Text("  Télécharger ${selected.size} élément(s)")
            }
        }
    }
}

/** Réglages d'un site : pubs, pop-ups, JavaScript, version ordinateur, zones masquées. */
@Composable
fun SiteSettingsDialog(hub: WebHub, site: String, onPickElement: (() -> Unit)?, onDismiss: () -> Unit) {
    @Suppress("UNUSED_VARIABLE") val v = hub.sites.version.intValue // relu à chaque modification
    val rules = hub.sites.of(site)
    var changed by remember(site) { mutableStateOf(false) }
    fun update(r: SiteRules) {
        hub.sites.set(site, r)
        changed = true
    }
    val close = {
        if (changed) hub.applySite(site)
        onDismiss()
    }
    AlertDialog(
        onDismissRequest = close,
        title = { Text(site) },
        text = {
            LazyColumn(Modifier.heightIn(max = 460.dp)) {
                item { SwitchRow("Bloquer les publicités", rules.ads) { update(rules.copy(ads = it)) } }
                item { SwitchRow("Bloquer les pop-ups", rules.popups) { update(rules.copy(popups = it)) } }
                item { SwitchRow("JavaScript", rules.js) { update(rules.copy(js = it)) } }
                item { SwitchRow("Version ordinateur", rules.desktop) { update(rules.copy(desktop = it)) } }
                item {
                    HorizontalDivider(Modifier.padding(vertical = 8.dp))
                    Text("Zones masquées (${rules.hidden.size})", fontWeight = FontWeight.SemiBold)
                    if (rules.hidden.isEmpty()) {
                        Text(
                            "Aucune. « Masquer un élément » dans le menu du navigateur.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                items(rules.hidden) { sel ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            sel, maxLines = 2, overflow = TextOverflow.Ellipsis, fontFamily = FontFamily.Monospace,
                            style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f),
                        )
                        IconButton(onClick = { update(rules.copy(hidden = rules.hidden - sel)) }) {
                            Icon(Icons.Filled.Close, contentDescription = "Afficher de nouveau")
                        }
                    }
                }
                if (onPickElement != null) {
                    item {
                        OutlinedButton(onClick = { onDismiss(); onPickElement() }, modifier = Modifier.fillMaxWidth()) {
                            Text("Masquer un élément…")
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = close) { Text("OK") } },
        dismissButton = {
            if (!rules.isDefault) {
                TextButton(onClick = { update(SiteRules()) }) { Text("Réinitialiser") }
            }
        },
    )
}

@Composable
private fun SwitchRow(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!value) }.padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, modifier = Modifier.weight(1f))
        Switch(checked = value, onCheckedChange = onChange)
    }
}

/** Tous les sites qui ont des réglages particuliers. */
@Composable
fun SitesListDialog(hub: WebHub, onOpen: (String) -> Unit, onDismiss: () -> Unit) {
    @Suppress("UNUSED_VARIABLE") val v = hub.sites.version.intValue
    val all = hub.sites.all()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Réglages des sites") },
        text = {
            if (all.isEmpty()) {
                Text("Aucun site réglé. Ouvrez un site puis menu ⋮ → « Réglages de ce site ».")
            } else {
                LazyColumn(Modifier.heightIn(max = 420.dp)) {
                    items(all, key = { it.first }) { (site, r) ->
                        Column(Modifier.fillMaxWidth().clickable { onOpen(site) }.padding(vertical = 8.dp)) {
                            Text(site, fontWeight = FontWeight.SemiBold)
                            Text(
                                listOfNotNull(
                                    "pubs autorisées".takeIf { !r.ads }, "pop-ups autorisés".takeIf { !r.popups },
                                    "JavaScript coupé".takeIf { !r.js }, "version ordinateur".takeIf { r.desktop },
                                    "${r.hidden.size} zone(s) masquée(s)".takeIf { r.hidden.isNotEmpty() },
                                ).joinToString(" · "),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fermer") } },
    )
}

/** Mode lecture : l'article seul, taille du texte réglable, fond clair ou sombre. */
@Composable
fun ReaderScreen(doc: ReaderDoc, onDismiss: () -> Unit) {
    var size by remember { mutableFloatStateOf(18f) }
    var dark by remember { mutableStateOf(true) }
    val bg = if (dark) Color(0xFF15151B) else Color(0xFFF7F3EA)
    val fg = if (dark) Color(0xFFE8E6E1) else Color(0xFF1E1E1E)
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = bg) {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                Row(Modifier.fillMaxWidth().padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onDismiss) { Icon(Icons.Filled.Close, "Fermer", tint = fg) }
                    Text(doc.site, color = fg.copy(alpha = .7f), modifier = Modifier.weight(1f), maxLines = 1)
                    IconButton(onClick = { size = (size - 2f).coerceAtLeast(12f) }) { Icon(Icons.Filled.ZoomOut, "Texte plus petit", tint = fg) }
                    IconButton(onClick = { size = (size + 2f).coerceAtMost(32f) }) { Icon(Icons.Filled.ZoomIn, "Texte plus grand", tint = fg) }
                    TextButton(onClick = { dark = !dark }) { Text(if (dark) "Clair" else "Sombre", color = fg) }
                }
                LazyColumn(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
                    item {
                        Text(doc.title, color = fg, fontSize = (size + 8).sp, fontWeight = FontWeight.Bold, lineHeight = (size + 14).sp)
                        Spacer(Modifier.height(16.dp))
                    }
                    items(doc.blocks) { b ->
                        when (b.type) {
                            "h" -> Text(
                                b.text, color = fg, fontSize = (size + 3).sp, fontWeight = FontWeight.Bold,
                                lineHeight = (size + 9).sp, modifier = Modifier.padding(top = 14.dp, bottom = 6.dp),
                            )
                            "li" -> Text("•  " + b.text, color = fg, fontSize = size.sp, lineHeight = (size * 1.5f).sp, modifier = Modifier.padding(start = 8.dp, bottom = 6.dp))
                            "q" -> Text(
                                b.text, color = fg.copy(alpha = .85f), fontSize = size.sp, fontStyle = FontStyle.Italic,
                                lineHeight = (size * 1.5f).sp,
                                modifier = Modifier.padding(vertical = 8.dp).background(fg.copy(alpha = .06f), RoundedCornerShape(8.dp)).padding(12.dp),
                            )
                            else -> Text(b.text, color = fg, fontSize = size.sp, lineHeight = (size * 1.55f).sp, modifier = Modifier.padding(bottom = 12.dp))
                        }
                    }
                    item { Spacer(Modifier.height(40.dp)) }
                }
            }
        }
    }
}
