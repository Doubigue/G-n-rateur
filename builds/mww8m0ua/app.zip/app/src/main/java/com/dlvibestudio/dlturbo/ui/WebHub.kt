package com.dlvibestudio.dlturbo.ui

import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.net.Uri
import android.os.Message
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.ServiceWorkerClient
import android.webkit.ServiceWorkerController
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import androidx.webkit.ProfileStore
import androidx.webkit.ScriptHandler
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import com.dlvibestudio.dlturbo.App
import com.dlvibestudio.dlturbo.data.SettingsData
import com.dlvibestudio.dlturbo.engine.Headers
import com.dlvibestudio.dlturbo.engine.Links
import com.dlvibestudio.dlturbo.engine.Mega
import kotlinx.coroutines.launch
import java.io.ByteArrayInputStream
import java.net.URLEncoder

/** Un onglet : une WebView + l'état affiché par l'interface. */
/** Une requête vue dans la page (liste « Ressources de la page »). [mediaKind] : HLS, MP4… si c'est un média. */
data class PageResource(val url: String, val headers: Map<String, String>, val referer: String, val mediaKind: String = "")

class WebTab(val id: Int, val kind: Kind, val incognito: Boolean = false) {
    enum class Kind { BROWSER, YOUTUBE }

    lateinit var webView: WebView
    var title by mutableStateOf("")
    var url by mutableStateOf("")
    var progress by mutableIntStateOf(100)
    var canGoBack by mutableStateOf(false)
    var canGoForward by mutableStateOf(false)
    var desktop by mutableStateOf(false)

    /** Augmente quand la WebView est recréée (processus de rendu planté) : l'interface se rattache. */
    var generation by mutableIntStateOf(0)
    val handlers = ArrayList<ScriptHandler>()

    /** La page a fini de charger (une page qui s'envoie seule ailleurs après coup est une publicité). */
    @Volatile
    var pageDone = false

    /** Flux vidéo/audio repérés dans le trafic de la page (y compris ses lecteurs intégrés). */
    val media = mutableStateListOf<MediaHit>()

    /** Un lecteur vidéo est visible dans la page (même à l'arrêt). */
    var hasVideo by mutableStateOf(false)

    /** Adresse du lecteur intégré (iframe) sur lequel l'utilisateur a appuyé. */
    var embed by mutableStateOf("")

    fun addMedia(hit: MediaHit) {
        if (media.any { it.url == hit.url }) return
        // Liste pleine : on retire d'abord un fichier simple, pour ne pas perdre la liste principale d'un flux.
        if (media.size >= 40) media.removeAt(media.indexOfFirst { !it.isStream }.coerceAtLeast(0))
        media.add(hit)
    }

    /** Requêtes de la page (adresse → en-têtes envoyés), lues depuis plusieurs fils. */
    private val resources = object : LinkedHashMap<String, PageResource>(64, 0.75f, false) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, PageResource>?) = size > 800
    }

    fun record(r: PageResource) {
        synchronized(resources) {
            val old = resources[r.url]
            if (old == null) {
                resources[r.url] = r
            } else if (old.mediaKind.isEmpty() && r.mediaKind.isNotEmpty()) {
                resources[r.url] = old.copy(mediaKind = r.mediaKind)
            }
        }
    }

    fun headersFor(url: String): Map<String, String> = synchronized(resources) { resources[url]?.headers } ?: emptyMap()

    fun resourceList(): List<PageResource> = synchronized(resources) { resources.values.toList() }

    fun resetMedia() {
        synchronized(resources) { resources.clear() }
        media.clear()
        hasVideo = false
        embed = ""
    }
}

/** Élément sous le doigt lors d'un appui long (image ou lien). */
data class HitInfo(val url: String, val isImage: Boolean)

/**
 * Gère toutes les WebViews de l'application : onglets du navigateur, page YouTube,
 * blocage des pubs / traqueurs / pop-ups, plein écran vidéo, téléchargements.
 * Les WebViews restent en vie quand on change d'onglet de l'application.
 */
class WebHub(private val activity: ComponentActivity, private val app: App) {

    val blocker = AdBlocker(activity)

    val tabs = mutableStateListOf<WebTab>()
    var currentIndex by mutableIntStateOf(0)
    var blocked by mutableIntStateOf(0)

    /** Lien pour lequel le sélecteur de formats doit s'ouvrir. */
    val formatRequest = mutableStateOf<String?>(null)
    val hit = mutableStateOf<HitInfo?>(null)
    val fullscreen = mutableStateOf(false)

    /** Demande de changement d'onglet de l'application (0 = Téléchargements … 3 = Fichiers). */
    val requestTab = mutableStateOf<Int?>(null)

    val yt = YtModel(app)

    /**
     * User-Agent du vrai moteur du téléphone, sans les marqueurs « ; wv » et « Version/4.0 » : les sites
     * (Google, YouTube…) nous traitent alors comme Chrome et non comme une application à remplacer.
     */
    val mobileUa: String = runCatching {
        android.webkit.WebSettings.getDefaultUserAgent(activity)
            .replace("; wv)", ")").replace(Regex("""\sVersion/\d+\.\d+"""), "")
    }.getOrDefault(SettingsData.DEFAULT_UA)

    /** User-Agent d'origine du moteur, sans retouche : exigé par Cloudflare (voir [Cloudflare]). */
    val defaultUa: String = runCatching { android.webkit.WebSettings.getDefaultUserAgent(activity) }
        .getOrDefault(SettingsData.DEFAULT_UA)

    val cloudflare = Cloudflare(activity)

    /** Identité à utiliser pour [url] : d'origine sur les sites protégés par Cloudflare, sinon « Chrome ». */
    fun uaFor(url: String): String {
        val host = runCatching { Uri.parse(url).host }.getOrNull() ?: return mobileUa
        if (sites.of(host).desktop) return DESKTOP_UA
        return if (cloudflare.isCompat(site(host)) || StrictSites.isStrict(host)) defaultUa else mobileUa
    }

    /** Onglet pour lequel la liste des médias détectés est affichée. */
    val mediaSheet = mutableStateOf<WebTab?>(null)

    /** Épisodes trouvés dans la page, en attente de sélection. */
    val episodes = mutableStateOf<EpisodeList?>(null)

    /** Images trouvées dans la page, en attente de sélection. */
    val images = mutableStateOf<List<PageImage>?>(null)

    val crawler = EpisodeCrawler(activity, app, blocker).also { c -> c.uaFor = { u -> uaFor(u) } }

    init {
        // Lien signé expiré : le gestionnaire rouvre la page d'origine dans le navigateur invisible pour récupérer
        // la nouvelle adresse du flux, puis reprend le téléchargement à l'octet près.
        app.manager.linkRefresher = { page ->
            crawler.sniff(page).filter { !MediaSniffer.noisy(it.url) }.map { it.url to it.kind }
        }
    }
    val bookmarks = Bookmarks(activity)

    /** Réglages par site (pubs, pop-ups, JavaScript, version ordinateur, zones masquées). */
    val sites = SiteSettings(activity)

    /** Fichiers « blob: » / « data: » créés par les pages. */
    val blobs = BlobReceiver(
        dir = { app.manager.baseDir },
        onDone = { file, name, source -> app.manager.addFinishedFile(file, name, source) },
        toast = { toast(it) },
    )

    /** Liste « Ressources de la page » ou « Grabber » ouverte. */
    val links = mutableStateOf<LinksRequest?>(null)

    /** Article affiché en mode lecture. */
    val reader = mutableStateOf<ReaderDoc?>(null)

    /** Site dont les réglages sont ouverts, et liste de tous les sites réglés. */
    val siteDialog = mutableStateOf<String?>(null)
    val sitesOpen = mutableStateOf(false)

    fun adsOn(host: String?) = app.settings.value.blockAds && sites.of(host).ads
    fun popupsOn(host: String?) = app.settings.value.blockPopups && sites.of(host).popups

    init {
        // Requêtes faites par les « service workers » des sites : elles ne passent pas par le WebViewClient.
        runCatching {
            ServiceWorkerController.getInstance().setServiceWorkerClient(object : ServiceWorkerClient() {
                override fun shouldInterceptRequest(request: WebResourceRequest): WebResourceResponse? {
                    val kind = MediaSniffer.classify(request.url) ?: return null
                    val u = request.url.toString()
                    if (MediaSniffer.noisy(u)) return null
                    val referer = request.requestHeaders?.get("Referer").orEmpty()
                    val headers = Headers.keep(request.requestHeaders)
                    activity.runOnUiThread { onWorkerMedia(MediaHit(u, kind, referer, headers)) }
                    return null
                }
            })
        }
    }

    /** Liste d'attente : pages (épisodes, films) à télécharger ensemble. */
    val waitList = WaitList(activity)
    val waitOpen = mutableStateOf(false)

    private var nextId = 1
    private var youtubeTab: WebTab? = null
    private var customView: View? = null
    private var customCallback: WebChromeClient.CustomViewCallback? = null

    val youtube: WebTab
        get() = youtubeTab ?: createTab(WebTab.Kind.YOUTUBE).also { youtubeTab = it }

    /** Onglet affiché dans le navigateur (null tant qu'aucun n'a été créé). */
    val current: WebTab?
        get() = tabs.getOrNull(currentIndex.coerceIn(0, (tabs.size - 1).coerceAtLeast(0)))

    init {
        activity.lifecycleScope.launch {
            app.settings.data.collect { applyAll() }
        }
        // Session privée restée d'un arrêt brutal : effacée au démarrage.
        if (WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            runCatching { ProfileStore.getInstance().deleteProfile(PRIVATE_PROFILE) }
        }
    }

    // ---------------------------------------------------------------- Onglets

    fun newBrowserTab(url: String? = null, select: Boolean = true, incognito: Boolean = false): WebTab {
        if (tabs.size >= MAX_TABS && !incognito) {
            val last = tabs.last()
            url?.let { load(last, it) }
            currentIndex = tabs.size - 1
            return last
        }
        if (tabs.size >= MAX_TABS) closeTab(tabs.indexOfFirst { !it.incognito }.coerceAtLeast(0))
        val tab = createTab(WebTab.Kind.BROWSER, incognito)
        tabs.add(tab)
        if (select) currentIndex = tabs.size - 1
        if (!url.isNullOrBlank()) load(tab, url)
        return tab
    }

    fun closeTab(index: Int) {
        if (index !in tabs.indices) return
        val tab = tabs.removeAt(index)
        destroy(tab)
        if (tab.incognito && tabs.none { it.incognito }) wipePrivate()
        if (tabs.isEmpty()) {
            newBrowserTab()
        } else {
            currentIndex = currentIndex.coerceIn(0, tabs.size - 1)
            if (index < currentIndex) currentIndex--
        }
    }

    fun load(tab: WebTab, input: String) {
        val target = resolve(input)
        if (target.isBlank()) return
        if (Links.isMagnet(target)) {
            app.manager.enqueue(target)
            toast("Torrent ajouté aux téléchargements")
            return
        }
        if (isSearch(input) && !tab.incognito) app.library.addWebSearch(input)
        if (!tab.desktop && tab.kind == WebTab.Kind.BROWSER) tab.webView.settings.userAgentString = uaFor(target)
        if (tab.kind == WebTab.Kind.BROWSER) {
            tab.webView.settings.javaScriptEnabled = sites.of(runCatching { Uri.parse(target).host }.getOrNull()).js
        }
        tab.webView.loadUrl(target)
    }

    /** Vrai si [input] est une recherche (et non une adresse ou un lien magnet). */
    private fun isSearch(input: String): Boolean {
        val t = input.trim()
        if (t.isEmpty()) return false
        if (Regex("^[a-zA-Z][a-zA-Z0-9+.-]*:").containsMatchIn(t) && !t.contains(' ')) return false
        if (!t.contains(' ') && t.contains('.') && !t.endsWith(".")) return false
        return true
    }

    /** Recherches récentes du navigateur (la plus récente en premier). */
    val recentSearches get() = app.library.recentWeb
    fun removeRecentSearch(q: String) = app.library.removeWebSearch(q)
    fun clearRecentSearches() = app.library.clearWebSearches()

    /** Adresse saisie -> URL, ou recherche avec le moteur choisi. */
    fun resolve(input: String): String {
        val t = input.trim()
        if (t.isEmpty()) return ""
        if (Regex("^[a-zA-Z][a-zA-Z0-9+.-]*:").containsMatchIn(t) && !t.contains(' ')) return t
        if (!t.contains(' ') && t.contains('.') && !t.endsWith(".")) return "https://$t"
        val q = URLEncoder.encode(t, "UTF-8")
        return when (app.settings.value.searchEngine) {
            "duckduckgo" -> "https://duckduckgo.com/?q=$q"
            "bing" -> "https://www.bing.com/search?q=$q"
            else -> "https://www.google.com/search?q=$q"
        }
    }

    fun setDesktop(tab: WebTab, enabled: Boolean) {
        tab.desktop = enabled
        tab.webView.settings.userAgentString = if (enabled) DESKTOP_UA else mobileUa
        tab.webView.settings.useWideViewPort = true
        tab.webView.settings.loadWithOverviewMode = enabled
        tab.webView.reload()
    }

    // ---------------------------------------------------------- Création

    @SuppressLint("SetJavaScriptEnabled", "AddJavascriptInterface")
    private fun createTab(kind: WebTab.Kind, incognito: Boolean = false): WebTab {
        val tab = WebTab(nextId++, kind, incognito)
        tab.webView = buildWebView(tab)
        return tab
    }

    @SuppressLint("SetJavaScriptEnabled", "AddJavascriptInterface")
    private fun buildWebView(tab: WebTab): WebView {
        val wv = WebView(activity)
        if (tab.incognito) usePrivateProfile(wv)
        wv.setBackgroundColor(android.graphics.Color.parseColor("#0E0E12"))
        with(wv.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            setSupportMultipleWindows(true)
            javaScriptCanOpenWindowsAutomatically = true
            mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            builtInZoomControls = true
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = false
            allowFileAccess = false
            allowContentAccess = false
            userAgentString = if (tab.desktop) DESKTOP_UA else mobileUa
            if (tab.incognito) cacheMode = android.webkit.WebSettings.LOAD_NO_CACHE
        }
        CookieManager.getInstance().setAcceptCookie(true)
        wv.webViewClient = client(tab)
        wv.webChromeClient = chrome(tab)
        wv.setDownloadListener { url, ua, disposition, mime, _ -> onDownload(tab, url, ua, disposition, mime) }
        wv.setOnLongClickListener {
            val r = wv.hitTestResult
            val extra = r.extra
            when {
                extra == null -> false
                r.type == WebView.HitTestResult.IMAGE_TYPE ||
                    r.type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE -> {
                    hit.value = HitInfo(extra, true)
                    true
                }
                r.type == WebView.HitTestResult.SRC_ANCHOR_TYPE -> {
                    hit.value = HitInfo(extra, false)
                    true
                }
                else -> false
            }
        }
        wv.addJavascriptInterface(PageBridge(), "DLP")
        if (tab.kind == WebTab.Kind.YOUTUBE) wv.addJavascriptInterface(YtBridge(), "DLT")
        else {
            wv.addJavascriptInterface(MediaBridge(tab), "DLM")
            wv.addJavascriptInterface(CaptureBridge(blobs) { hit -> onCaptured(tab, hit) }, CaptureBridge.NAME)
        }
        applyScripts(tab, wv)
        applyCookiePolicy(wv)
        return wv
    }

    private fun applyAll() {
        val list = ArrayList<WebTab>(tabs)
        youtubeTab?.let { list.add(it) }
        for (tab in list) {
            applyScripts(tab, tab.webView)
            applyCookiePolicy(tab.webView)
        }
    }

    private fun applyCookiePolicy(wv: WebView, url: String? = null) {
        // Les cookies de sites tiers servent surtout au suivi publicitaire… mais les vérifications (Cloudflare
        // Turnstile, hCaptcha, reCAPTCHA) en ont besoin dans leur cadre : toujours autorisés sur les sites de
        // streaming / torrent et sur les sites déjà passés en « mode compatible ».
        val host = runCatching { Uri.parse(url ?: wv.url ?: "").host }.getOrNull()
        val captchaSite = host != null && (StrictSites.isStrict(host) || cloudflare.isCompat(site(host)))
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, !app.settings.value.blockAds || captchaSite)
    }

    /** Scripts exécutés avant ceux de la page, selon les paramètres. Effet à la page suivante. */
    private fun applyScripts(tab: WebTab, wv: WebView) {
        tab.handlers.forEach { runCatching { it.remove() } }
        tab.handlers.clear()
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) return
        val s = app.settings.value
        fun add(script: String) {
            runCatching { tab.handlers.add(WebViewCompat.addDocumentStartJavaScript(wv, Cloudflare.guard(script), setOf("*"))) }
        }
        add(PageTools.HIDE_SCRIPT)
        if (s.blockAds || s.blockPopups) add(PageTools.unlessSite("all", StrictSites.JS))
        if (s.blockPopups) add(PageTools.unlessSite("popups", AdBlocker.POPUP_SCRIPT))
        if (s.blockAds) {
            add(PageTools.unlessSite("ads", AdGuard.JS))
            add(PageTools.unlessSite("ads", AdBlocker.COSMETIC_SCRIPT))
            if (tab.kind == WebTab.Kind.YOUTUBE) add(PageTools.unlessSite("ads", AdBlocker.YOUTUBE_SCRIPT))
        }
        if (tab.kind == WebTab.Kind.YOUTUBE) {
            add(AdGuard.YOUTUBE_APP_PROMO_SCRIPT)
            add(AdBlocker.YOUTUBE_BUTTONS_SCRIPT)
        } else {
            add(MediaSniffer.MEDIA_BUTTON_SCRIPT)
            add(CaptureBridge.SCRIPT)
        }
    }

    /**
     * Page de vérification Cloudflare : cookies tiers autorisés pour cet onglet (cadre Turnstile) et,
     * la première fois pour ce site, passage en identité d'origine puis rechargement.
     */
    private fun onChallenge(tab: WebTab, view: WebView, url: String) {
        CookieManager.getInstance().setAcceptThirdPartyCookies(view, true)
        val host = runCatching { Uri.parse(url).host }.getOrNull() ?: return
        if (cloudflare.add(site(host)) && !tab.desktop && view.settings.userAgentString != defaultUa) {
            view.settings.userAgentString = defaultUa
            toast("Vérification Cloudflare : passage en mode compatible…")
            view.reload()
        }
    }

    /** Anciens WebView sans prise en charge des scripts « document start » : injection au chargement. */
    private fun injectFallback(tab: WebTab, view: WebView) {
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) return
        val s = app.settings.value
        if (s.blockAds || s.blockPopups) view.evaluateJavascript(Cloudflare.guard(StrictSites.JS), null)
        if (s.blockPopups) view.evaluateJavascript(Cloudflare.guard(AdBlocker.POPUP_SCRIPT), null)
        if (s.blockAds) {
            view.evaluateJavascript(Cloudflare.guard(AdGuard.JS), null)
            view.evaluateJavascript(Cloudflare.guard(AdBlocker.COSMETIC_SCRIPT), null)
            if (tab.kind == WebTab.Kind.YOUTUBE) view.evaluateJavascript(Cloudflare.guard(AdBlocker.YOUTUBE_SCRIPT), null)
        }
        if (tab.kind == WebTab.Kind.YOUTUBE) {
            view.evaluateJavascript(AdGuard.YOUTUBE_APP_PROMO_SCRIPT, null)
            view.evaluateJavascript(AdBlocker.YOUTUBE_BUTTONS_SCRIPT, null)
        } else {
            view.evaluateJavascript(MediaSniffer.MEDIA_BUTTON_SCRIPT, null)
            view.evaluateJavascript(Cloudflare.guard(CaptureBridge.SCRIPT), null)
        }
    }

    // ------------------------------------------------------------ Clients

    private fun client(tab: WebTab) = object : WebViewClient() {

        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
            val pageHost = runCatching { Uri.parse(tab.url).host }.getOrNull()
            if (adsOn(pageHost) && (
                    blocker.shouldBlock(request.url, pageHost) ||
                        (AdRules.isAdHost(request.url.host) && !AdRules.isAdHost(pageHost)) ||
                        (AdRules.isGamblingHost(request.url.host) && !AdRules.isGamblingHost(pageHost)) ||
                        (!request.isForMainFrame && AdRules.looksLikeAdResource(request.url))
                    )
            ) {
                activity.runOnUiThread { blocked++ }
                return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
            }
            if (tab.kind == WebTab.Kind.BROWSER && !request.isForMainFrame) {
                val kind = MediaSniffer.classify(request.url)
                val u = request.url.toString()
                val referer = request.requestHeaders?.get("Referer")?.takeIf { it.isNotBlank() } ?: tab.url
                val headers = Headers.keep(request.requestHeaders)
                tab.record(PageResource(u, headers, referer, kind.orEmpty()))
                if (kind != null && !MediaSniffer.noisy(u)) {
                    activity.runOnUiThread { tab.addMedia(MediaHit(u, kind, referer, headers)) }
                }
            }
            return null
        }

        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            val uri = request.url
            val scheme = uri.scheme?.lowercase()
            when (scheme) {
                "http", "https" -> Unit
                "magnet" -> {
                    app.manager.enqueue(uri.toString())
                    toast("Torrent ajouté aux téléchargements")
                    return true
                }
                "tel", "mailto", "sms", "geo" -> {
                    if (request.hasGesture()) {
                        runCatching {
                            activity.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        }
                    }
                    return true
                }
                // intent:, market:, applications tierces… : les sites s'en servent pour détourner vers une
                // appli ou une publicité. Seule exception : un lien YouTube, rouvert ici en version web.
                else -> {
                    val web = webFallback(uri.toString())
                    if (web != null && (tab.kind == WebTab.Kind.YOUTUBE || request.hasGesture())) {
                        view.post { view.loadUrl(web) }
                    } else {
                        activity.runOnUiThread { blocked++ }
                    }
                    return true
                }
            }
            if (!request.isForMainFrame) return false
            // Étapes de la vérification Cloudflare (jeton __cf_chl, dossier /cdn-cgi/) : jamais retouchées, sinon elle recommence.
            if (CaptchaRules.isCaptchaUrl(uri) || (uri.query ?: "").contains("__cf_chl")) return false

            val s = app.settings.value
            // Navigation de la page entière vers une régie publicitaire : jamais.
            if ((s.blockAds || s.blockPopups) && tab.url.isNotBlank() && !AdRules.isAdUrl(tab.url) &&
                (AdRules.isAdUrl(uri.toString()) || AdRules.looksLikeAdResource(uri))
            ) {
                activity.runOnUiThread { blocked++ }
                return true
            }
            // Sites de streaming / torrent : la page ne quitte jamais son site, même après un clic (pubs au clic).
            if ((s.blockAds || s.blockPopups) && StrictSites.isStrictUrl(tab.url) && !request.isRedirect &&
                !AdRules.sameSite(tab.url, uri.toString()) && !AdRules.isAuthHost(uri.host) &&
                !StrictSites.isStrict(uri.host) // nouvelle adresse du même site (miroir)
            ) {
                activity.runOnUiThread { blocked++ }
                return true
            }
            // Page déjà affichée qui s'envoie seule sur un autre site, sans clic : bloquée (sauf connexion).
            if (s.blockRedirects && tab.pageDone && !request.hasGesture() && !request.isRedirect &&
                tab.url.isNotBlank() && !AdRules.sameSite(tab.url, uri.toString()) && !AdRules.isAuthHost(uri.host)
            ) {
                activity.runOnUiThread { blocked++ }
                return true
            }

            // Site protégé par Cloudflare : on change d'identité avant d'y aller (pages GET seulement).
            if (tab.kind == WebTab.Kind.BROWSER && !tab.desktop && request.method.equals("GET", ignoreCase = true)) {
                val want = uaFor(uri.toString())
                if (view.settings.userAgentString != want) {
                    view.settings.userAgentString = want
                    view.loadUrl(uri.toString())
                    return true
                }
            }

            // L'onglet YouTube reste sur YouTube : les liens externes s'ouvrent dans le navigateur.
            if (tab.kind == WebTab.Kind.YOUTUBE && !isYoutubeFamily(uri.host)) {
                openInBrowser(uri.toString())
                return true
            }
            return false
        }

        override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
            if (url != tab.url) tab.resetMedia()
            // JavaScript coupé ou rétabli pour ce site : la page est rechargée une fois avec le bon réglage.
            if (tab.kind == WebTab.Kind.BROWSER && url.startsWith("http")) {
                val wantJs = sites.of(runCatching { Uri.parse(url).host }.getOrNull()).js
                if (view.settings.javaScriptEnabled != wantJs) {
                    view.settings.javaScriptEnabled = wantJs
                    view.post { view.reload() }
                }
            }
            tab.pageDone = false
            tab.url = url
            tab.progress = 5
            applyCookiePolicy(view, url)
            injectFallback(tab, view)
        }

        override fun onPageFinished(view: WebView, url: String) {
            tab.pageDone = true
            CookieManager.getInstance().flush() // garde les sessions (Google, sites) après fermeture de l'appli
            if (app.settings.value.blockAds) view.evaluateJavascript(Cloudflare.guard(AdGuard.JS), null)
            if (tab.kind == WebTab.Kind.YOUTUBE) view.evaluateJavascript(AdGuard.YOUTUBE_APP_PROMO_SCRIPT, null)
            if (tab.kind == WebTab.Kind.BROWSER && url.startsWith("http")) {
                view.evaluateJavascript(Cloudflare.DETECT) { r -> if (r?.contains("1") == true) onChallenge(tab, view, url) }
                // Widget de vérification dans une page normale (formulaire, lecteur) : cookies tiers autorisés.
                view.evaluateJavascript(CaptchaRules.DETECT_WIDGET) { r ->
                    if (r?.contains("1") == true) CookieManager.getInstance().setAcceptThirdPartyCookies(view, true)
                }
            }
            tab.url = url
            tab.title = view.title ?: ""
            tab.progress = 100
            tab.canGoBack = view.canGoBack()
            tab.canGoForward = view.canGoForward()
        }

        override fun doUpdateVisitedHistory(view: WebView, url: String, isReload: Boolean) {
            tab.url = url
            tab.canGoBack = view.canGoBack()
            tab.canGoForward = view.canGoForward()
        }

        override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
            val url = tab.url
            activity.runOnUiThread {
                val old = tab.webView
                (old.parent as? ViewGroup)?.removeView(old)
                old.destroy()
                tab.webView = buildWebView(tab)
                tab.generation++
                if (url.isNotBlank()) tab.webView.loadUrl(url)
            }
            return true
        }
    }

    private fun chrome(tab: WebTab) = object : WebChromeClient() {

        override fun onProgressChanged(view: WebView, newProgress: Int) {
            tab.progress = newProgress
        }

        override fun onReceivedTitle(view: WebView, title: String?) {
            tab.title = title ?: ""
        }

        override fun onCreateWindow(
            view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message,
        ): Boolean {
            // Comme dans MyDM : le pop-up s'ouvre dans une fenêtre jetable qui ne charge rien ; on lit seulement
            // l'adresse visée. Lien du même site cliqué par vous → ouvert dans cet onglet ; tout le reste est ignoré.
            if (popupsOn(runCatching { Uri.parse(tab.url).host }.getOrNull())) return handlePopup(tab, view, isUserGesture, resultMsg)
            if (tab.kind == WebTab.Kind.YOUTUBE) return false
            val fresh = newBrowserTab(incognito = tab.incognito)
            val transport = resultMsg.obj as WebView.WebViewTransport
            transport.webView = fresh.webView
            resultMsg.sendToTarget()
            return true
        }

        override fun onShowCustomView(view: View, callback: CustomViewCallback) {
            if (customView != null) {
                callback.onCustomViewHidden()
                return
            }
            customView = view
            customCallback = callback
            val decor = activity.window.decorView as FrameLayout
            view.setBackgroundColor(android.graphics.Color.BLACK)
            decor.addView(
                view,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT,
                ),
            )
            val controller = WindowCompat.getInsetsController(activity.window, decor)
            controller.hide(WindowInsetsCompat.Type.systemBars())
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            fullscreen.value = true
        }

        override fun onHideCustomView() {
            exitFullscreen()
        }
    }

    private fun handlePopup(tab: WebTab, view: WebView, userGesture: Boolean, msg: Message): Boolean {
        val cur = view.url.orEmpty()
        // Sites de streaming / torrent : aucune fenêtre, jamais.
        if (StrictSites.isStrictUrl(cur) || StrictSites.isStrictUrl(tab.url)) {
            blocked++
            return false
        }
        val probe = WebView(activity)
        probe.settings.javaScriptEnabled = false
        var handled = false
        fun decide(u: String?) {
            if (handled || u.isNullOrBlank() || u == "about:blank") return
            handled = true
            val uri = runCatching { Uri.parse(u) }.getOrNull()
            val ok = userGesture && uri != null && u.startsWith("http") &&
                !AdRules.isAdUrl(u) && !AdRules.looksLikeAdResource(uri) &&
                (AdRules.sameSite(cur, u) || AdRules.isAuthHost(uri.host))
            view.post {
                if (ok) {
                    if (tab.kind == WebTab.Kind.YOUTUBE && !isYoutubeFamily(uri?.host) && !AdRules.isAuthHost(uri?.host)) {
                        openInBrowser(u)
                    } else {
                        view.loadUrl(u)
                    }
                } else {
                    blocked++
                }
                probe.stopLoading()
                probe.destroy()
            }
        }
        probe.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                decide(r.url.toString())
                return true
            }

            override fun onPageStarted(v: WebView, u: String?, f: Bitmap?) {
                decide(u)
            }
        }
        (msg.obj as WebView.WebViewTransport).webView = probe
        msg.sendToTarget()
        view.postDelayed({
            if (!handled) {
                handled = true
                blocked++
                probe.stopLoading()
                probe.destroy()
            }
        }, 4000)
        return true
    }

    /**
     * Lien « intent:// » ou « vnd.youtube: » : renvoie l'adresse web équivalente si c'est du YouTube
     * (ou l'adresse de secours prévue par le site, si elle reste sur YouTube), sinon null.
     */
    private fun webFallback(url: String): String? {
        if (url.startsWith("vnd.youtube:")) {
            val id = url.removePrefix("vnd.youtube:").removePrefix("//").substringBefore('?').substringBefore('#')
            return if (id.matches(Regex("[A-Za-z0-9_-]{6,20}"))) "https://m.youtube.com/watch?v=$id&app=m" else null
        }
        if (!url.startsWith("intent://")) return null
        val intent = runCatching { Intent.parseUri(url, Intent.URI_INTENT_SCHEME) }.getOrNull() ?: return null
        val fallback = intent.getStringExtra("browser_fallback_url")
        if (fallback != null && fallback.startsWith("http") && isYoutubeFamily(Uri.parse(fallback).host)) return fallback
        val data = intent.data ?: return null
        if (!isYoutubeFamily(data.host)) return null
        return data.buildUpon().scheme("https").build().toString()
    }

    fun exitFullscreen() {
        val view = customView ?: return
        (view.parent as? ViewGroup)?.removeView(view)
        customCallback?.onCustomViewHidden()
        customView = null
        customCallback = null
        val decor = activity.window.decorView
        WindowCompat.getInsetsController(activity.window, decor).show(WindowInsetsCompat.Type.systemBars())
        activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        fullscreen.value = false
    }

    // -------------------------------------------------------- Téléchargements

    private fun onDownload(tab: WebTab, url: String, ua: String?, disposition: String?, mime: String?) {
        if (url.startsWith("data:", true)) {
            activity.lifecycleScope.launch(kotlinx.coroutines.Dispatchers.IO) {
                if (!blobs.saveData(url, tab.url)) toast("Ce fichier n'a pas pu être récupéré")
            }
            return
        }
        if (url.startsWith("blob:", true)) {
            // Le script de la page l'a peut-être déjà pris en charge (lien « download ») ; sinon on le lui demande.
            val name = Regex("""filename\*?=(?:UTF-8'')?["']?([^"';]+)""", RegexOption.IGNORE_CASE)
                .find(disposition.orEmpty())?.groupValues?.get(1)?.let { Uri.decode(it) }.orEmpty()
            val asked = System.currentTimeMillis()
            tab.webView.evaluateJavascript(
                "window.__dltSaveBlob && window.__dltSaveBlob(${org.json.JSONObject.quote(url)}, ${org.json.JSONObject.quote(name)})", null,
            )
            tab.webView.postDelayed({
                if (blobs.lastStart < asked - 3_000) toast("Ce fichier n'a pas pu être récupéré (il vient d'un cadre de la page)")
            }, 5_000)
            return
        }
        val cookie = cookieFor(tab, url)
        val headers = tab.headersFor(url).toMutableMap()
        if (!ua.isNullOrBlank()) headers["User-Agent"] = ua
        app.manager.enqueueFromBrowser(url, cookie, tab.url, disposition, mime, Headers.encode(headers))
        toast("Téléchargement ajouté")
    }

    /** Pont JavaScript de la page YouTube : l'icône de téléchargement d'une miniature appelle download(). */
    inner class YtBridge {
        @JavascriptInterface
        fun download(url: String?) {
            val u = url ?: return
            val host = runCatching { Uri.parse(u).host }.getOrNull()
            if (!isYoutubeFamily(host)) return
            activity.runOnUiThread { formatRequest.value = u }
        }
    }

    /** Pont JavaScript des pages web : l'icône posée sur un lecteur vidéo appelle tap(). */
    inner class MediaBridge(private val tab: WebTab) {
        @JavascriptInterface
        fun tap(src: String?, kind: String?) {
            val u = src.orEmpty()
            activity.runOnUiThread {
                if (u.startsWith("http")) {
                    val k = MediaSniffer.classify(Uri.parse(u))
                    if (k != null) tab.addMedia(MediaHit(u, k, tab.url, tab.headersFor(u)))
                    else if (kind == "iframe") tab.embed = u
                }
                mediaSheet.value = tab
            }
        }

        @JavascriptInterface
        fun seen(count: Int) {
            if (count > 0) activity.runOnUiThread { tab.hasVideo = true }
        }
    }

    /** Média signalé par le script de capture d'un onglet (appelé hors du fil principal). */
    private fun onCaptured(tab: WebTab, hit: MediaHit) {
        tab.record(PageResource(hit.url, tab.headersFor(hit.url), hit.referer.ifBlank { tab.url }, hit.kind))
        activity.runOnUiThread {
            tab.addMedia(hit.copy(referer = hit.referer.ifBlank { tab.url }, headers = tab.headersFor(hit.url)))
        }
    }

    /**
     * Média vu par un service worker : Android n'indique pas l'onglet. Il va au navigateur invisible si la
     * requête vient du site qu'il explore, sinon à l'onglet affiché.
     */
    private fun onWorkerMedia(hit: MediaHit) {
        if (crawler.offer(hit)) return
        val tab = tabs.getOrNull(currentIndex) ?: return
        tab.addMedia(if (hit.referer.isBlank()) hit.copy(referer = tab.url) else hit)
    }

    // ------------------------------------------------------ Fonctions reprises de 1DM

    /** Pont des pages (tous les onglets) : réglages par site lus par les scripts, zone masquée choisie. */
    inner class PageBridge {
        @JavascriptInterface
        fun off(host: String?, what: String?): Boolean {
            val r = sites.of(host)
            return when (what) {
                "ads" -> !r.ads
                "popups" -> !r.popups
                "all" -> !r.ads && !r.popups
                else -> false
            }
        }

        @JavascriptInterface
        fun css(host: String?): String = sites.css(host)

        @JavascriptInterface
        fun hide(host: String?, selector: String?) {
            val sel = selector.orEmpty()
            if (sel.isBlank() || sel.length > 400) return
            sites.hide(host, sel)
            toast("Zone masquée sur ce site (Réglages du site pour l'afficher de nouveau)")
        }
    }

    /** Cookies de la bonne session : celle de la navigation privée pour un onglet privé. */
    fun cookieFor(tab: WebTab?, url: String): String {
        if (tab?.incognito == true && WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            return runCatching { ProfileStore.getInstance().getProfile(PRIVATE_PROFILE)?.cookieManager?.getCookie(url) }
                .getOrNull().orEmpty()
        }
        return runCatching { CookieManager.getInstance().getCookie(url) }.getOrNull().orEmpty()
    }

    /** Navigation privée : session séparée (cookies, stockage) si le moteur du téléphone le permet. */
    private fun usePrivateProfile(wv: WebView) {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            toast("Navigation privée limitée : mettez à jour « Android System WebView » pour séparer les cookies")
            return
        }
        runCatching {
            ProfileStore.getInstance().getOrCreateProfile(PRIVATE_PROFILE)
            WebViewCompat.setProfile(wv, PRIVATE_PROFILE)
        }
    }

    /** Dernier onglet privé fermé : cookies et données de la session privée effacés. */
    private fun wipePrivate() {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) return
        runCatching {
            ProfileStore.getInstance().getProfile(PRIVATE_PROFILE)?.let { p ->
                p.cookieManager.removeAllCookies(null)
                p.webStorage.deleteAllData()
            }
        }
        activity.window.decorView.postDelayed({
            if (tabs.none { it.incognito }) runCatching { ProfileStore.getInstance().deleteProfile(PRIVATE_PROFILE) }
        }, 2_000)
    }

    /** Toutes les requêtes de la page (vidéos, images, fichiers…), à cocher et télécharger. */
    fun showResources(tab: WebTab) {
        val list = tab.resourceList().map { r ->
            LinkEntry(r.url, PageTools.kindOf(r.url, r.mediaKind), mediaKind = r.mediaKind, headers = r.headers, referer = r.referer)
        }.reversed()
        if (list.isEmpty()) {
            toast("Aucune ressource : rechargez la page ou lancez la vidéo")
            return
        }
        links.value = LinksRequest("Ressources de la page", tab, grabber = false).apply { entries.addAll(list) }
    }

    /** Grabber : tous les liens de la page ; [deep] = lit aussi les pages du même site trouvées (niveau 2). */
    fun grabLinks(tab: WebTab, deep: Boolean = false) {
        tab.webView.evaluateJavascript(PageTools.GRAB_SCRIPT) { raw ->
            val found = PageTools.parseGrab(unwrap(raw), tab.url)
            if (found.isEmpty()) {
                toast("Aucun lien trouvé sur cette page")
                return@evaluateJavascript
            }
            val req = LinksRequest("Liens de la page", tab, grabber = true).apply { entries.addAll(found) }
            links.value = req
            if (deep) grabDeeper(req)
        }
    }

    fun grabDeeper(req: LinksRequest) {
        if (req.loading.value) return
        val pages = req.entries.filter { it.kind == LinkKind.PAGE && it.level == 1 && AdRules.sameSite(it.url, req.tab.url) }
            .map { it.url }.filter { it.substringBefore('#') != req.tab.url.substringBefore('#') }
        if (pages.isEmpty()) {
            toast("Aucune page du même site à explorer")
            return
        }
        req.loading.value = true
        req.level.intValue = 2
        activity.lifecycleScope.launch {
            try {
                val more = PageTools.grabDeeper(
                    app.manager.http.client, pages, req.tab.webView.settings.userAgentString ?: mobileUa,
                    cookieOf = { cookieFor(req.tab, it) },
                ) { done, total -> activity.runOnUiThread { req.progress.value = "$done / $total pages lues" } }
                val known = req.entries.map { it.url }.toHashSet()
                req.entries.addAll(more.filter { known.add(it.url) })
            } finally {
                req.loading.value = false
                req.progress.value = ""
            }
        }
    }

    /** Télécharge les liens cochés selon leur type (flux, torrent, Mega, page vidéo, fichier). */
    fun downloadLinks(tab: WebTab, list: List<LinkEntry>) {
        val title = cleanPageTitle(tab.title).ifBlank { Links.hostOf(tab.url) }
        var n = 0
        list.forEachIndexed { i, e ->
            val headers = e.headers.ifEmpty { tab.headersFor(e.url) }
            when {
                e.kind == LinkKind.TORRENT || e.kind == LinkKind.MEGA || e.kind == LinkKind.PAGE -> app.manager.enqueue(e.url)
                e.isStream -> app.manager.enqueueStream(
                    e.url, e.referer.ifBlank { tab.url }, cookieFor(tab, e.url),
                    if (list.size > 1) "$title ${i + 1}" else title, "best", headers = Headers.encode(headers),
                )
                else -> downloadFile(tab, e.url, null, e.referer.ifBlank { tab.url }, headers)
            }
            n++
        }
        toast("$n téléchargement(s) ajouté(s)")
    }

    /** Mode lecture : texte de l'article seulement. */
    fun openReader(tab: WebTab) {
        if (!tab.webView.settings.javaScriptEnabled) {
            toast("Le mode lecture a besoin de JavaScript (Réglages du site)")
            return
        }
        tab.webView.evaluateJavascript(PageTools.READER_SCRIPT) { raw ->
            val doc = PageTools.parseReader(unwrap(raw))
            if (doc == null) toast("Pas d'article à afficher en mode lecture sur cette page")
            else reader.value = doc
        }
    }

    /** Choisir une zone de la page à masquer définitivement sur ce site. */
    fun pickElement(tab: WebTab) {
        if (!tab.webView.settings.javaScriptEnabled) {
            toast("Cette fonction a besoin de JavaScript (Réglages du site)")
            return
        }
        tab.webView.evaluateJavascript(PageTools.PICKER_SCRIPT, null)
    }

    /** Réglages du site changés : on recharge les onglets de ce site pour les appliquer. */
    fun applySite(site: String) {
        for (t in tabs) {
            val h = runCatching { Uri.parse(t.url).host }.getOrNull() ?: continue
            if (SiteSettings.key(h) != site) continue
            if (!t.desktop) t.webView.settings.userAgentString = uaFor(t.url)
            t.webView.settings.javaScriptEnabled = sites.of(h).js
            t.webView.reload()
        }
    }

    fun isMegaPage(tab: WebTab) = Mega.parse(tab.url) != null

    /** Cherche les épisodes de la page courante (séries, listes de lecture) et ouvre la sélection. */
    fun scanEpisodes(tab: WebTab) {
        tab.webView.evaluateJavascript(MediaSniffer.EPISODES_SCRIPT) { raw ->
            val json = unwrap(raw)
            val list = runCatching {
                val o = org.json.JSONObject(json ?: "")
                val arr = o.getJSONArray("items")
                val items = ArrayList<EpisodeItem>()
                for (i in 0 until arr.length()) {
                    val e = arr.getJSONObject(i)
                    items.add(EpisodeItem(e.getString("t"), e.getString("u"), e.optInt("n", 0)))
                }
                EpisodeList(o.optString("page"), tab.url, items)
            }.getOrNull()
            if (list == null || list.items.isEmpty()) toast("Aucun épisode trouvé sur cette page")
            else episodes.value = list
        }
    }

    /** Cherche les images de la page courante et ouvre la sélection. */
    fun scanImages(tab: WebTab) {
        tab.webView.evaluateJavascript(MediaSniffer.IMAGES_SCRIPT) { raw ->
            val json = unwrap(raw)
            val list = runCatching {
                val arr = org.json.JSONArray(json ?: "")
                (0 until arr.length()).map { i ->
                    val o = arr.getJSONObject(i)
                    PageImage(o.getString("u"), o.optInt("w", 0))
                }
            }.getOrNull()
            if (list.isNullOrEmpty()) toast("Aucune image trouvée sur cette page")
            else images.value = list
        }
    }

    /** Télécharge un fichier de la page avec les cookies et la page d'origine (liens protégés). */
    fun downloadFile(
        tab: WebTab, url: String, disposition: String? = null, referer: String? = null,
        headers: Map<String, String> = tab.headersFor(url),
    ) {
        app.manager.enqueueFromBrowser(url, cookieFor(tab, url), referer ?: tab.url, disposition, null, Headers.encode(headers))
    }

    /** Télécharge un flux détecté. [audio] : extraire en MP3. */
    fun downloadMedia(tab: WebTab, hit: MediaHit, audio: Boolean) {
        val title = tab.title.ifBlank { Links.hostOf(tab.url) }
        val cookie = cookieFor(tab, hit.url)
        if (!hit.isStream && !audio) {
            val name = Links.sanitize(title).take(100) + "." + hit.extension
            downloadFile(tab, hit.url, "attachment; filename=\"$name\"", hit.referer, hit.headers)
        } else {
            app.manager.enqueueStream(hit.url, hit.referer, cookie, title, if (audio) "mp3" else "best", headers = Headers.encode(hit.headers))
        }
        toast("Téléchargement ajouté")
    }

    /** Formats (qualités + taille estimée) des flux repérés dans une page. */
    suspend fun analyzeStreams(hits: List<MediaHit>): StreamAnalysis =
        StreamProbe.analyze(app.manager.http.client, hits, mobileUa)

    /** Télécharge une qualité précise (vidéo) ou l'audio ([quality] = best, mp3, m4a, wav). */
    fun downloadVariant(tab: WebTab, v: StreamVariant, quality: String, name: String = "") {
        val title = name.trim().ifBlank { cleanPageTitle(tab.title) }.ifBlank { Links.hostOf(tab.url) }
        val cookie = cookieFor(tab, v.url)
        if (!v.isStream && quality == "best") {
            val ext = v.container.lowercase().takeIf { it in setOf("mp4", "webm", "mkv", "mov", "flv", "mp3", "m4a", "aac", "ogg") } ?: "mp4"
            val name = Links.sanitize(title).take(100) + "." + ext
            downloadFile(tab, v.url, "attachment; filename=\"$name\"", v.referer, v.headers)
        } else {
            app.manager.enqueueStream(
                v.url, v.referer, cookie, title, quality, if (quality == "best") v.sizeBytes else 0, Headers.encode(v.headers),
            )
        }
        toast("Téléchargement ajouté")
    }

    /** Ajoute la page affichée à la liste d'attente. */
    fun addToWaitList(tab: WebTab) {
        if (tab.url.isBlank() || tab.url == "about:blank") return
        val added = waitList.add(cleanPageTitle(tab.title).ifBlank { tab.url }, tab.url)
        toast(if (added) "Ajouté à la liste d'attente (${waitList.items.size})" else "Déjà dans la liste d'attente")
    }

    /** Analyse impossible avec l'extracteur : on cherche le flux dans la page (lecteur intégré) à la place. */
    fun fallbackToStreams(url: String): Boolean {
        if (isYoutubeFamily(runCatching { Uri.parse(url).host }.getOrNull())) return false
        val tab = tabs.firstOrNull { it.url == url } ?: tabs.firstOrNull { AdRules.sameSite(it.url, url) } ?: return false
        mediaSheet.value = tab
        return true
    }

    private fun unwrap(raw: String?): String? {
        if (raw == null || raw == "null") return null
        return runCatching { org.json.JSONTokener(raw).nextValue() as? String }.getOrNull()
    }

    private fun openInBrowser(url: String) {
        activity.runOnUiThread {
            newBrowserTab(url)
            requestTab.value = TAB_BROWSER
        }
    }

    // ------------------------------------------------------------ Divers

    fun clearData() {
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        WebStorage.getInstance().deleteAllData()
        val all = ArrayList<WebTab>(tabs)
        youtubeTab?.let { all.add(it) }
        all.forEach {
            it.webView.clearCache(true)
            it.webView.clearHistory()
            it.webView.clearFormData()
        }
    }

    fun pause() {
        tabs.forEach { it.webView.onPause() }
        youtubeTab?.webView?.onPause()
    }

    fun resume() {
        tabs.forEach { it.webView.onResume() }
        youtubeTab?.webView?.onResume()
    }

    fun destroyAll() {
        exitFullscreen()
        crawler.cancel()
        tabs.toList().forEach { destroy(it) }
        tabs.clear()
        youtubeTab?.let { destroy(it) }
        youtubeTab = null
    }

    private fun destroy(tab: WebTab) {
        runCatching {
            tab.handlers.forEach { it.remove() }
            tab.handlers.clear()
            val wv = tab.webView
            (wv.parent as? ViewGroup)?.removeView(wv)
            wv.stopLoading()
            wv.destroy()
        }
    }

    private fun toast(message: String) {
        activity.runOnUiThread { Toast.makeText(activity, message, Toast.LENGTH_SHORT).show() }
    }

    private fun site(host: String): String {
        val parts = host.lowercase().split('.')
        return if (parts.size <= 2) host.lowercase() else parts.takeLast(2).joinToString(".")
    }

    companion object {
        const val MAX_TABS = 12
        const val PRIVATE_PROFILE = "turbo_private"
        const val TAB_BROWSER = 2
        const val DESKTOP_UA =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"

        fun isYoutubeFamily(host: String?): Boolean {
            val h = host?.lowercase() ?: return false
            return listOf(
                "youtube.com", "youtu.be", "google.com", "gstatic.com", "ytimg.com",
                "googleusercontent.com", "googlevideo.com", "ggpht.com", "youtube-nocookie.com",
            ).any { h == it || h.endsWith(".$it") }
        }
    }
}
