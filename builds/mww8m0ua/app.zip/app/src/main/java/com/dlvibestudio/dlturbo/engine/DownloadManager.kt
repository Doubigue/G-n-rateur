package com.dlvibestudio.dlturbo.engine

import android.content.Context
import android.media.MediaScannerConnection
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Environment
import com.dlvibestudio.dlturbo.data.DlStatus
import com.dlvibestudio.dlturbo.data.DlType
import com.dlvibestudio.dlturbo.data.DownloadItem
import com.dlvibestudio.dlturbo.data.DownloadRepository
import com.dlvibestudio.dlturbo.data.Settings
import com.dlvibestudio.dlturbo.service.DownloadService
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.io.IOException
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Chef d'orchestre : file d'attente, nombre de téléchargements simultanés,
 * pause / reprise / suppression, attente du réseau, et choix du bon moteur
 * (HTTP multi-connexions, torrent ou extracteur vidéo).
 */
class DownloadManager(
    private val context: Context,
    val repo: DownloadRepository,
    val settings: Settings,
    private val scope: CoroutineScope,
    val library: Library,
) {
    private val limiter = RateLimiter { settings.value.speedLimit }
    val http = HttpDownloader(repo, settings, limiter)
    val torrents = TorrentEngine(context, repo, settings, http)
    val videos = VideoEngine(context, repo, settings, scope)
    val hls = HlsEngine(context, repo, settings, limiter, http.client)

    private val jobs = ConcurrentHashMap<String, Job>()

    /**
     * Rafraîchissement d'un lien expiré (jetons signés). Fourni par l'interface : ouvre la page d'origine dans le
     * navigateur invisible et renvoie les flux vus passer, sous forme (adresse, type : HLS / DASH / MP4…).
     */
    @Volatile
    var linkRefresher: (suspend (pageUrl: String) -> List<Pair<String, String>>)? = null

    /** Nombre de rafraîchissements déjà faits par téléchargement (évite une boucle infinie). */
    private val linkRefreshes = ConcurrentHashMap<String, Int>()

    /** Nouveaux essais automatiques déjà faits après un échec, par téléchargement. */
    private val autoRetries = ConcurrentHashMap<String, Int>()
    private val lock = Any()
    private var resumedOnce = false

    /** Dossier public : Téléchargements/Turbo Download (visible dans la galerie et les gestionnaires de fichiers). */
    val baseDir: File
        get() = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            "Turbo Download",
        )

    /** Au moins un téléchargement a tourné depuis la dernière « fin de tout ». */
    @Volatile
    private var hadWork = false

    init {
        // Widget d'écran d'accueil : mis à jour au plus toutes les 2 secondes.
        scope.launch {
            var last: List<DownloadItem>? = null
            while (true) {
                val now = repo.items.value
                if (now !== last) {
                    last = now
                    runCatching { com.dlvibestudio.dlturbo.service.DownloadsWidget.refresh(context, now) }
                }
                delay(2000)
            }
        }
        migrateOldFolder()
        // Ménage des fichiers de travail laissés par les anciennes versions (.part, .ytdl, fragments).
        scope.launch(Dispatchers.IO) { cleanLeftovers() }
        // Session torrent démarrée tôt : le réseau DHT est prêt quand un magnet arrive.
        if (repo.items.value.any { it.type == DlType.TORRENT && it.status != DlStatus.COMPLETED }) torrents.warmUp()
        scope.launch {
            settings.data.collect {
                torrents.applyLimits()
                enforceNetworkPolicy()
                retryWaiting()
                schedule()
            }
        }
        registerNetworkCallback()
        // Filet de sécurité : Android ne signale pas toujours le retour d'Internet sur un réseau resté connecté
        // (forfait rechargé, box qui revient). On vérifie toutes les 30 s tant que quelque chose attend.
        scope.launch {
            while (true) {
                delay(30_000)
                if (repo.items.value.any { it.status == DlStatus.WAITING_NETWORK }) runCatching { retryWaiting() }
            }
        }
        // Téléchargements programmés : on vérifie l'heure toutes les 30 secondes.
        scope.launch {
            while (true) {
                delay(30_000)
                if (settings.value.scheduleOn || repo.items.value.any { it.info.startsWith("Planifié") }) applyWindow()
            }
        }
    }

    // ---------------------------------------------------------------- Ajout

    /** Ajoute tous les liens trouvés dans [text]. Renvoie le nombre de liens ajoutés. */
    fun enqueueText(text: String, quality: String = ""): Int {
        val urls = Links.extract(text)
        urls.forEach { enqueue(it, quality) }
        return urls.size
    }

    fun enqueue(url: String, quality: String = "") {
        if (Mega.isMega(url) && (Mega.parse(url) != null || Mega.isFolder(url))) {
            enqueueMega(url)
            return
        }
        val cfg = settings.value
        val sorted = cfg.sortByCategory
        val item = when {
            Links.isMagnet(url) || Links.isTorrentUrl(url) -> DownloadItem(
                id = newId(), type = DlType.TORRENT, url = url,
                fileName = magnetName(url),
                dir = (if (sorted) File(baseDir, "Torrents") else baseDir).path,
            )

            Links.isVideoSite(url) -> newVideoItem(url, quality)

            else -> DownloadItem(
                id = newId(), type = DlType.HTTP, url = url,
                fileName = Links.fileName(url, null, null),
                dir = baseDir.path,
                videoFallback = true,
            )
        }
        if (item.type == DlType.TORRENT) torrents.warmUp()
        repo.add(item)
        schedule()
    }

    /** Ajoute un fichier .torrent choisi sur le téléphone. */
    fun enqueueTorrentFile(bytes: ByteArray, displayName: String) {
        val id = newId()
        torrents.torrentFile(id).writeBytes(bytes)
        val sorted = settings.value.sortByCategory
        repo.add(
            DownloadItem(
                id = id, type = DlType.TORRENT, url = "fichier .torrent",
                fileName = displayName.removeSuffix(".torrent").removeSuffix(".torrent").ifBlank { "Torrent" },
                dir = (if (sorted) File(baseDir, "Torrents") else baseDir).path,
            )
        )
        schedule()
    }

    private fun newVideoItem(
        url: String, quality: String, id: String = newId(), title: String = "", playlist: Boolean = false,
        folder: String = "", customName: Boolean = false,
    ): DownloadItem {
        val cfg = settings.value
        val q = quality.ifBlank { cfg.videoQuality }
        val audio = VideoEngine.isAudioQuality(q)
        val root = when {
            !cfg.sortByCategory -> baseDir
            audio -> File(baseDir, "Musique")
            else -> File(baseDir, "Vidéos")
        }
        // Option « un dossier par site » : Vidéos/youtube.com, Musique/tiktok.com…
        val site = if (cfg.folderBySite) File(root, Links.sanitize(Links.hostOf(url))) else root
        // Venu d'une liste de lecture : dossier au nom de la liste ; s'il existe déjà, on y range aussi ce fichier.
        val dir = if (folder.isNotBlank()) File(site, Links.sanitize(folder).take(100)) else site
        // YouTube : le fichier porte exactement le titre de la vidéo (sans identifiant, sans troncature).
        // Nom saisi avant le téléchargement : utilisé tel quel, quel que soit le site.
        val exact = if ((Links.isYoutube(url) || customName) && title.isNotBlank() && !playlist)
            uniqueVideoName(dir, Links.youtubeName(title)) else ""
        val label = if (exact.isNotBlank()) exact
        else if (title.isNotBlank()) Links.sanitize(title)
        else (if (audio) "Audio · " else "Vidéo · ") + Links.hostOf(url)
        return DownloadItem(
            id = id, type = DlType.VIDEO, url = url, fileName = label,
            dir = dir.path, quality = q, playlist = playlist, folder = folder, outName = exact,
        )
    }

    /** Évite que deux vidéos au même titre (dans le même dossier) s'écrasent : « Titre », « Titre (1) »… */
    private fun uniqueVideoName(dir: File, base: String): String {
        val taken = HashSet<String>()
        dir.listFiles()?.forEach { taken.add(it.nameWithoutExtension.lowercase()) }
        repo.items.value.filter { it.dir == dir.path }.forEach {
            taken.add(it.fileName.substringBeforeLast('.').lowercase())
            if (it.outName.isNotBlank()) taken.add(it.outName.lowercase())
        }
        var name = base
        var i = 1
        while (name.lowercase() in taken) {
            name = "$base ($i)"
            i++
        }
        return name
    }

    /**
     * Renomme un téléchargement terminé, en pause ou en erreur (pas les torrents ni YouTube : leurs noms sont conservés).
     * [base] : nom sans extension, l'extension actuelle est conservée. Renvoie null si c'est fait, sinon le message d'erreur.
     */
    fun rename(id: String, base: String): String? {
        val item = repo.get(id) ?: return "Téléchargement introuvable"
        if (item.type == DlType.TORRENT) return "Les torrents ne se renomment pas ici"
        if (Links.isYoutube(item.url)) return "Les noms des vidéos YouTube sont conservés"
        if (item.status.isActive) return "Mettez le téléchargement en pause avant de le renommer"
        val clean = Links.sanitize(base).trim()
        if (clean.isBlank()) return "Le nom est vide"
        val ext = item.fileName.substringAfterLast('.', "")
            .takeIf { it.isNotEmpty() && it.length <= 6 && !it.contains(' ') }?.let { ".$it" } ?: ""
        val newName = if (ext.isNotEmpty() && clean.endsWith(ext, ignoreCase = true)) clean else clean + ext
        if (newName == item.fileName) return null
        val dir = File(item.dir)
        val target = File(dir, newName)
        if (target.exists()) return "Un fichier porte déjà ce nom"
        if (item.status == DlStatus.COMPLETED) {
            val file = File(dir, item.fileName)
            if (!file.exists() || !file.renameTo(target)) return "Impossible de renommer le fichier"
            MediaScannerConnection.scanFile(context, arrayOf(target.path), null, null)
        } else if (item.type == DlType.HTTP) {
            // Le fichier partiel suit le nouveau nom : la reprise continue où elle s'était arrêtée.
            val part = File(dir, item.fileName + Links.PART_SUFFIX)
            if (part.exists() && !part.renameTo(File(dir, newName + Links.PART_SUFFIX))) return "Impossible de renommer"
        }
        repo.update(id) {
            it.copy(fileName = newName, autoName = false, outName = if (it.type == DlType.VIDEO) newName.removeSuffix(ext) else it.outName)
        }
        repo.saveNow()
        return null
    }

    /** Vidéo ou audio choisi dans le sélecteur de formats (YouTube, Instagram, TikTok…). */
    fun enqueueVideo(
        url: String, quality: String, playlist: Boolean = false, title: String = "", folder: String = "",
        customName: Boolean = false,
    ) {
        repo.add(newVideoItem(url, quality, title = title, playlist = playlist, folder = folder, customName = customName))
        schedule()
    }

    /**
     * Flux détecté dans une page (HLS .m3u8, DASH .mpd, mp4…) : yt-dlp le télécharge avec la page
     * d'origine comme « referer » et les cookies de la session. [quality] : best, mp3, m4a, wav…
     */
    fun enqueueStream(
        url: String, referer: String, cookie: String, title: String, quality: String = "best", expectedBytes: Long = 0,
        headers: String = "",
    ) {
        val base = newVideoItem(url, quality, title = title)
        val clean = Links.sanitize(title).take(120).trim()
        repo.add(
            base.copy(
                referer = referer, cookie = cookie, outName = if (title.isBlank()) "" else clean, headers = headers,
                expectedBytes = expectedBytes.coerceAtLeast(0),
                totalBytes = if (expectedBytes > 0) expectedBytes else base.totalBytes,
                sizeEstimated = expectedBytes > 0,
            )
        )
        schedule()
    }

    /** Fichier proposé par le navigateur (APK, image, PDF…), avec les cookies de la session. */
    fun enqueueFromBrowser(
        url: String, cookie: String, referer: String, disposition: String?, mime: String?, headers: String = "",
    ) {
        if (Links.isMagnet(url) || Mega.parse(url) != null) {
            enqueue(url)
            return
        }
        // Fichier .torrent d'un site (Torrent9…) : téléchargé avec les cookies de la session, puis
        // transformé automatiquement en torrent (voir runItem). Sans les cookies, le site renvoie une page.
        repo.add(
            DownloadItem(
                id = newId(), type = DlType.HTTP, url = url,
                fileName = Links.fileName(url, disposition, mime),
                dir = baseDir.path, cookie = cookie, referer = referer, headers = headers,
            )
        )
        schedule()
    }

    /**
     * Fichier partagé par une autre application (vidéo Telegram, WhatsApp, galerie…) : copié dans
     * Téléchargements/DLTurbo (Vidéos, Musique, Images… selon le type) et affiché dans les téléchargements.
     */
    fun importShared(uri: Uri, displayName: String?, mime: String?, size: Long) {
        val ext = android.webkit.MimeTypeMap.getSingleton().getExtensionFromMimeType(mime ?: "") ?: ""
        val raw = displayName?.takeIf { it.isNotBlank() }
            ?: ("Telegram_" + java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(java.util.Date()) +
                if (ext.isNotBlank()) ".$ext" else "")
        val name = Links.sanitize(raw).ifBlank { "fichier" }
        val dir = if (settings.value.sortByCategory) File(baseDir, Links.category(name)) else baseDir
        val id = newId()
        val target = run {
            dir.mkdirs()
            val reserved = repo.items.value.map { File(it.dir, it.fileName).path }.toSet()
            Links.uniqueFile(dir, name, reserved)
        }
        repo.add(
            DownloadItem(
                id = id, type = DlType.HTTP, url = uri.toString(), fileName = target.name, dir = dir.path,
                totalBytes = size, status = DlStatus.RUNNING, info = "Copie du fichier partagé…", autoName = false,
            )
        )
        scope.launch(Dispatchers.IO) {
            try {
                var done = 0L
                var last = 0L
                val started = System.currentTimeMillis()
                context.contentResolver.openInputStream(uri)?.use { input ->
                    target.outputStream().use { out ->
                        val buf = ByteArray(256 * 1024)
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            val now = System.currentTimeMillis()
                            if (now - last > 400) {
                                last = now
                                val secs = ((now - started) / 1000).coerceAtLeast(1)
                                repo.update(id) { it.copy(downloadedBytes = done, speed = done / secs) }
                            }
                        }
                    }
                } ?: throw IOException("Fichier partagé illisible")
                repo.update(id) {
                    it.copy(
                        status = DlStatus.COMPLETED, downloadedBytes = done, totalBytes = done, speed = 0,
                        info = "", finishedAt = System.currentTimeMillis(), url = "Partagé depuis une autre application",
                    )
                }
                MediaScannerConnection.scanFile(context, arrayOf(target.path), null, null)
            } catch (t: Throwable) {
                target.delete()
                repo.update(id) {
                    it.copy(
                        status = DlStatus.ERROR, speed = 0, info = "",
                        error = "Copie impossible : partagez à nouveau le fichier (${t.message ?: t.javaClass.simpleName})",
                    )
                }
            } finally {
                repo.saveNow()
            }
        }
    }

    /** Lien de fichier Mega : téléchargé chiffré, puis déchiffré à la fin (voir [Mega]). */
    fun enqueueMega(url: String) {
        val link = Mega.parse(url)
        repo.add(
            DownloadItem(
                id = newId(), type = DlType.HTTP, url = url,
                fileName = "Mega_" + (link?.id ?: "dossier"), dir = baseDir.path, mega = url,
                status = if (link == null) DlStatus.ERROR else DlStatus.QUEUED,
                error = if (link == null) "Les dossiers Mega ne sont pas pris en charge : ouvrez le dossier et copiez le lien de chaque fichier" else null,
            )
        )
        if (link != null) schedule()
    }

    /** Fichier déjà complet produit dans l'appli (fichier « blob » d'une page…) : rangé et affiché comme terminé. */
    fun addFinishedFile(src: File, displayName: String, source: String) {
        val name = Links.sanitize(displayName).ifBlank { "fichier" }
        val dir = if (settings.value.sortByCategory) File(baseDir, Links.category(name)) else baseDir
        dir.mkdirs()
        val reserved = repo.items.value.map { File(it.dir, it.fileName).path }.toSet()
        val target = Links.uniqueFile(dir, name, reserved)
        if (!src.renameTo(target)) {
            src.copyTo(target, overwrite = true)
            src.delete()
        }
        val size = target.length()
        repo.add(
            DownloadItem(
                id = newId(), type = DlType.HTTP, url = source, fileName = target.name, dir = dir.path,
                totalBytes = size, downloadedBytes = size, status = DlStatus.COMPLETED, autoName = false,
                resumable = false, finishedAt = System.currentTimeMillis(),
            )
        )
        MediaScannerConnection.scanFile(context, arrayOf(target.path), null, null)
        checkAllDone()
    }

    /** Mega : nouvelle adresse de téléchargement à chaque lancement (elle expire), nom réel du fichier au premier. */
    private fun megaPrepare(id: String) {
        val item = repo.get(id) ?: return
        val link = Mega.parse(item.mega) ?: throw FatalDownloadException("Lien Mega incorrect")
        repo.update(id) { it.copy(info = "Connexion à Mega…") }
        val info = Mega.resolve(http.client, link)
        val fresh = item.segments.isEmpty() || !File(item.dir, item.fileName + Links.PART_SUFFIX).exists()
        repo.update(id) {
            if (!fresh) it.copy(url = info.url, etag = null)
            else {
                val dir = if (settings.value.sortByCategory) File(baseDir, Links.category(info.name)) else baseDir
                val reserved = repo.items.value.filter { o -> o.id != id }.map { o -> File(o.dir, o.fileName).path }.toSet()
                it.copy(
                    url = info.url, fileName = Links.uniqueFile(dir, Links.sanitize(info.name), reserved).name,
                    dir = dir.path, autoName = false, videoFallback = false, segments = emptyList(),
                    totalBytes = info.size,
                )
            }
        }
        repo.saveNow()
    }

    /** Mega : le fichier reçu est chiffré, on le déchiffre à sa place. */
    private fun megaFinish(id: String, file: File) {
        val item = repo.get(id) ?: return
        val link = Mega.parse(item.mega) ?: return
        repo.update(id) { it.copy(info = "Déchiffrement Mega…", speed = 0) }
        val tmp = File(file.parentFile, file.name + ".dec")
        try {
            Mega.decrypt(file, tmp, link) { done ->
                repo.update(id) { it.copy(info = "Déchiffrement Mega… " + (if (it.totalBytes > 0) "${done * 100 / it.totalBytes} %" else "")) }
            }
            if (!file.delete() || !tmp.renameTo(file)) throw IOException("Impossible de remplacer le fichier chiffré")
        } catch (t: Throwable) {
            tmp.delete()
            throw FatalDownloadException("Déchiffrement Mega impossible : ${t.message ?: t.javaClass.simpleName}")
        }
    }

    private fun magnetName(url: String): String {
        val dn = runCatching { Uri.parse(url.replaceFirst("magnet:?", "magnet://x/?")).getQueryParameter("dn") }
            .getOrNull()
        return if (!dn.isNullOrBlank()) Links.sanitize(dn)
        else if (Links.isMagnet(url)) "Torrent (magnet)"
        else Links.fileName(url, null, null).removeSuffix(".torrent")
    }

    private fun newId() = UUID.randomUUID().toString().replace("-", "").take(16)

    // ------------------------------------------------------ Pause / reprise

    fun pause(id: String) {
        repo.update(id) {
            // En erreur avec un nouvel essai prévu : la pause annule ce nouvel essai.
            if (it.status.isActive || it.status == DlStatus.ERROR) it.copy(status = DlStatus.PAUSED, speed = 0, info = "") else it
        }
        jobs[id]?.cancel()
        repo.saveNow()
    }

    fun resume(id: String) {
        autoRetries.remove(id) // relance manuelle : le compteur d'essais automatiques repart de zéro
        repo.update(id) {
            if (it.status == DlStatus.PAUSED || it.status == DlStatus.ERROR || it.status == DlStatus.WAITING_NETWORK)
                it.copy(status = DlStatus.QUEUED, error = null, info = "")
            else it
        }
        schedule()
    }

    fun pauseAll() {
        repo.items.value.filter { it.status.isActive }.forEach { pause(it.id) }
    }

    fun resumeAll() {
        repo.updateAll {
            if (it.status == DlStatus.PAUSED || it.status == DlStatus.ERROR)
                it.copy(status = DlStatus.QUEUED, error = null, info = "")
            else it
        }
        schedule()
    }

    /** Relance, une seule fois au lancement, ce qui a été coupé par la fermeture de l'application. */
    fun resumeInterrupted() {
        if (resumedOnce) return
        resumedOnce = true
        if (!settings.value.autoResume) return
        repo.updateAll {
            if (it.status == DlStatus.PAUSED && it.info == DownloadRepository.INTERRUPTED)
                it.copy(status = DlStatus.QUEUED, info = "")
            else it
        }
        schedule()
    }

    fun remove(id: String, deleteFile: Boolean) {
        val item = repo.get(id) ?: return
        val job = jobs[id]
        autoRetries.remove(id)
        repo.remove(id)
        if (item.type == DlType.VIDEO) runCatching { videos.tempDir(id).deleteRecursively() }
        if (item.type == DlType.VIDEO) scope.launch(Dispatchers.IO) { job?.join(); hls.forget(id) }
        job?.cancel()
        runCatching {
            context.getSystemService(android.app.NotificationManager::class.java)
                ?.cancel(com.dlvibestudio.dlturbo.service.Notifications.idFor(item))
        }
        scope.launch(Dispatchers.IO) {
            job?.join()
            if (item.type == DlType.TORRENT) torrents.remove(id)
            runCatching {
                // Les fichiers partiels d'un téléchargement direct sont toujours nettoyés.
                if (item.type == DlType.HTTP && item.status != DlStatus.COMPLETED) {
                    File(item.dir, item.fileName + Links.PART_SUFFIX).delete()
                }
                // Le nom doit avoir été confirmé par le moteur avant toute suppression de fichier.
                if (deleteFile && !item.autoName && item.fileName.isNotBlank()) {
                    val target = File(item.dir, item.fileName)
                    if (target != File(item.dir) && target.exists()) target.deleteRecursively()
                }
            }
            schedule()
        }
    }

    fun clearCompleted() {
        repo.items.value.filter { it.status == DlStatus.COMPLETED }.forEach { repo.remove(it.id) }
    }

    // ----------------------------------------------------------------- File

    /** Vrai si l'heure actuelle est dans la plage des téléchargements programmés (ou si aucune plage n'est réglée). */
    fun windowOpen(): Boolean {
        val s = settings.value
        if (!s.scheduleOn) return true
        val c = java.util.Calendar.getInstance()
        val now = c.get(java.util.Calendar.HOUR_OF_DAY) * 60 + c.get(java.util.Calendar.MINUTE)
        val a = s.scheduleStart
        val b = s.scheduleEnd
        return when {
            a == b -> true
            a < b -> now in a until b
            else -> now >= a || now < b
        }
    }

    private fun windowLabel(): String {
        val a = settings.value.scheduleStart
        return "Planifié · démarre à %02d:%02d".format(a / 60, a % 60)
    }

    /** Hors plage : ce qui est en cours est remis en attente ; dans la plage : l'attente reprend. */
    private fun applyWindow() {
        if (windowOpen()) {
            if (repo.items.value.any { it.info.startsWith("Planifié") }) {
                repo.updateAll {
                    if (it.status == DlStatus.QUEUED && it.info.startsWith("Planifié")) it.copy(info = "") else it
                }
            }
            schedule()
        } else {
            val label = windowLabel()
            repo.items.value.filter { it.status.isActive && jobs.containsKey(it.id) }.forEach { item ->
                repo.update(item.id) {
                    if (it.status.isActive) it.copy(status = DlStatus.QUEUED, speed = 0, info = label) else it
                }
                jobs[item.id]?.cancel()
            }
            schedule()
        }
    }

    fun schedule() {
        if (!windowOpen()) {
            val label = windowLabel()
            repo.updateAll { if (it.status == DlStatus.QUEUED && it.info != label) it.copy(info = label) else it }
            // Le service reste actif (notification) pour que la file démarre toute seule à l'heure dite.
            if (repo.items.value.any { it.status == DlStatus.QUEUED }) DownloadService.start(context)
            return
        }
        synchronized(lock) {
            val max = if (batterySaverActive()) 1 else settings.value.maxParallel
            while (jobs.size < max) {
                // La liste est triée du plus récent au plus ancien : on sert le plus ancien d'abord.
                val next = repo.items.value.lastOrNull {
                    it.status == DlStatus.QUEUED && !jobs.containsKey(it.id)
                } ?: break
                if (!networkOk()) {
                    repo.update(next.id) { it.copy(status = DlStatus.WAITING_NETWORK, info = waitingLabel()) }
                    DownloadService.start(context)
                    continue
                }
                start(next.id)
            }
        }
    }

    private fun start(id: String) {
        hadWork = true
        DownloadService.start(context)
        val job = scope.launch(Dispatchers.IO, start = CoroutineStart.LAZY) { runItem(id) }
        jobs[id] = job
        job.invokeOnCompletion {
            jobs.remove(id, job)
            schedule()
            // Seulement après un téléchargement réellement terminé (pas après une pause).
            if (repo.get(id)?.status == DlStatus.COMPLETED) checkAllDone()
        }
        job.start()
    }

    private suspend fun runItem(id: String) {
        val item = repo.get(id) ?: return
        // Mis en pause entre la mise en file et le démarrage : on ne touche à rien.
        if (item.status != DlStatus.QUEUED) return
        repo.update(id) {
            if (it.status == DlStatus.QUEUED) it.copy(status = DlStatus.CONNECTING, error = null, info = "Connexion…")
            else it
        }
        try {
            if (item.url.startsWith("content:")) {
                throw FatalDownloadException("Copie interrompue : partagez à nouveau le fichier")
            }
            val file: File? = when (item.type) {
                DlType.HTTP -> {
                    if (item.mega.isNotBlank()) megaPrepare(id)
                    http.run(id).also { if (item.mega.isNotBlank()) megaFinish(id, it) }
                }
                DlType.TORRENT -> {
                    torrents.run(id)
                    null
                }
                DlType.VIDEO -> {
                    videos.attempts[id] = autoRetries[id] ?: 0
                    val current = repo.get(id) ?: item
                    if (hls.canTry(current)) {
                        try {
                            hls.run(id)
                        } catch (e: HlsEngine.NotHandled) {
                            // Direct, DRM, autre format : yt-dlp s'en charge.
                            repo.update(id) { it.copy(info = "Moteur yt-dlp (${e.message})", percent = -1f) }
                            videos.run(id)
                        }
                    } else {
                        videos.run(id)
                    }
                }
            }
            repo.update(id) {
                it.copy(
                    status = DlStatus.COMPLETED, speed = 0, error = null, info = "",
                    finishedAt = System.currentTimeMillis(),
                    downloadedBytes = if (it.totalBytes > 0) it.totalBytes else it.downloadedBytes,
                )
            }
            autoRetries.remove(id)
            linkRefreshes.remove(id)
            // Un lien direct qui était en fait un fichier .torrent : on lance le torrent (saison entière comprise).
            if (item.type == DlType.HTTP) {
                val got = file ?: repo.get(id)?.let { File(it.dir, it.fileName) }
                if (got != null && looksLikeTorrent(got)) {
                    convertToTorrent(id, got)
                    return
                }
            }
            val done = repo.get(id)
            if (done != null && done.type == DlType.VIDEO && !done.playlist) library.markDownloaded(done.url)
            val target = file ?: done?.let { File(it.dir, it.fileName) }
            if (target != null && target.isFile) {
                MediaScannerConnection.scanFile(context, arrayOf(target.path), null, null)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: HtmlPageException) {
            // Ce n'est pas un fichier mais une page web : on tente l'extracteur vidéo.
            val video = newVideoItem(item.url, "", id)
            repo.update(id) {
                it.copy(
                    type = DlType.VIDEO, status = DlStatus.QUEUED, fileName = video.fileName,
                    dir = video.dir, quality = video.quality, videoFallback = false,
                    segments = emptyList(), info = "",
                )
            }
        } catch (t: Throwable) {
            // Lien signé expiré : on récupère une nouvelle adresse depuis la page d'origine et on reprend où on en était.
            if (isExpiredLink(t, item) && refreshExpiredLink(id)) return
            // Coupure (même longue : une heure, une journée) : on attend le retour d'Internet sans limite de durée,
            // les fichiers partiels sont conservés et le téléchargement reprend là où il s'était arrêté.
            val offline = t !is FatalDownloadException &&
                (!networkOk() || (NetCheck.looksLikeNetwork(t) && !NetCheck.online(http.client)))
            if (offline) {
                repo.update(id) {
                    it.copy(status = DlStatus.WAITING_NETWORK, speed = 0, info = waitingLabel())
                }
            } else {
                val message = t.message?.takeIf { it.isNotBlank() } ?: t.javaClass.simpleName
                val tries = autoRetries[id] ?: 0
                val canRetry = tries < RETRY_DELAYS.size &&
                    (t !is FatalDownloadException || item.type == DlType.VIDEO) &&
                    !PERMANENT_ERROR.containsMatchIn(message)
                if (canRetry) {
                    scheduleAutoRetry(id, item.type, tries, message)
                } else {
                    repo.update(id) {
                        it.copy(
                            status = DlStatus.ERROR, speed = 0, error = message,
                            info = if (tries > 0) "Échec après $tries nouvel(s) essai(s) automatique(s)" else "",
                        )
                    }
                }
            }
        } finally {
            repo.saveNow()
        }
    }

    /** Erreur qui évoque un jeton expiré : HTTP 401 / 403 / 410 (moteur HTTP) ou message équivalent (yt-dlp). */
    private fun isExpiredLink(t: Throwable, item: DownloadItem): Boolean {
        if (item.referer.isBlank() || !item.referer.startsWith("http")) return false
        if (t is ExpiredLinkException) return true
        val m = t.message.orEmpty()
        return item.type == DlType.VIDEO && EXPIRED_MESSAGE.containsMatchIn(m)
    }

    /**
     * Recharge la page d'origine en arrière-plan, repère la nouvelle adresse signée du même média et remet le
     * téléchargement en file : les segments déjà reçus sont gardés quand il s'agit bien du même fichier.
     * Renvoie false si rien n'a pu être récupéré (l'erreur normale s'affiche alors).
     */
    private suspend fun refreshExpiredLink(id: String): Boolean {
        val refresher = linkRefresher ?: return false
        val item = repo.get(id) ?: return false
        val tries = linkRefreshes[id] ?: 0
        if (tries >= MAX_LINK_REFRESHES) return false
        linkRefreshes[id] = tries + 1
        repo.update(id) { it.copy(info = "Lien expiré : actualisation depuis la page…", speed = 0) }
        val hits = runCatching { refresher(item.referer) }.getOrDefault(emptyList())
        val fresh = pickRefreshed(item.url, hits) ?: return false
        val cookie = runCatching { android.webkit.CookieManager.getInstance().getCookie(fresh) }.getOrNull().orEmpty()
        val sameFile = samePath(item.url, fresh)
        repo.update(id) {
            it.copy(
                url = fresh,
                cookie = cookie.ifBlank { it.cookie },
                status = DlStatus.QUEUED, error = null, speed = 0,
                info = "Lien actualisé, reprise…",
                // Autre fichier : on repart de zéro plutôt que de mélanger deux contenus.
                segments = if (sameFile) it.segments else emptyList(),
                downloadedBytes = if (sameFile) it.downloadedBytes else 0,
            )
        }
        if (!sameFile && item.type == DlType.HTTP) {
            runCatching { File(item.dir, item.fileName + Links.PART_SUFFIX).delete() }
        }
        repo.saveNow()
        return true
    }

    private fun pathOf(url: String): String = runCatching { Uri.parse(url).path.orEmpty() }.getOrDefault("")

    private fun samePath(a: String, b: String): Boolean = pathOf(a).isNotEmpty() && pathOf(a) == pathOf(b)

    /** Choisit, parmi les flux repérés, celui qui correspond au lien expiré (même chemin > même nom > même type). */
    private fun pickRefreshed(oldUrl: String, hits: List<Pair<String, String>>): String? {
        if (hits.isEmpty()) return null
        val oldPath = pathOf(oldUrl)
        val oldName = oldPath.substringAfterLast('/')
        val oldKind = oldPath.substringAfterLast('.', "").lowercase()
        hits.firstOrNull { pathOf(it.first) == oldPath }?.let { return it.first }
        if (oldName.isNotEmpty()) hits.firstOrNull { pathOf(it.first).substringAfterLast('/') == oldName }?.let { return it.first }
        return hits.lastOrNull { pathOf(it.first).substringAfterLast('.', "").lowercase() == oldKind }?.first
    }

    /**
     * Échec : nouvel essai automatique après une attente croissante (10 s, 30 s, 1 min, 3 min, 10 min).
     * Pour une vidéo, le moteur (yt-dlp) est d'abord mis à jour : c'est souvent la cause quand un site change.
     */
    private fun scheduleAutoRetry(id: String, type: DlType, tries: Int, message: String) {
        val wait = RETRY_DELAYS[tries]
        autoRetries[id] = tries + 1
        repo.update(id) {
            it.copy(
                status = DlStatus.ERROR, speed = 0, error = message,
                info = "Nouvel essai automatique dans ${wait / 1000} s (${tries + 1}/${RETRY_DELAYS.size})",
            )
        }
        scope.launch(Dispatchers.IO) {
            if (type == DlType.VIDEO) {
                repo.update(id) { if (it.status == DlStatus.ERROR) it.copy(info = "Mise à jour du moteur vidéo…") else it }
                // Premier échec : vérification si la dernière date de plus de 30 min ; ensuite, au plus toutes les 2 h.
                val updated = runCatching { videos.autoUpdate(if (tries == 0) 30 * 60_000L else 2 * 3600_000L) }
                    .getOrDefault(false)
                repo.update(id) {
                    if (it.status == DlStatus.ERROR) it.copy(
                        info = (if (updated) "Moteur vidéo mis à jour · " else "") +
                            "nouvel essai (${tries + 1}/${RETRY_DELAYS.size})",
                    ) else it
                }
                if (updated) {
                    delay(2_000)
                } else {
                    delay(wait)
                }
            } else {
                delay(wait)
            }
            var restart = false
            repo.update(id) {
                if (it.status == DlStatus.ERROR) {
                    restart = true
                    it.copy(status = DlStatus.QUEUED, error = null, info = "Nouvel essai ${tries + 1}/${RETRY_DELAYS.size}…")
                } else it
            }
            if (restart) schedule()
        }
    }

    private fun looksLikeTorrent(f: File): Boolean {
        if (!f.isFile || f.length() < 50 || f.length() > 20L * 1024 * 1024) return false
        if (f.name.endsWith(".torrent", ignoreCase = true)) return true
        return runCatching {
            val head = f.inputStream().use { s -> ByteArray(4096).let { b -> String(b, 0, s.read(b).coerceAtLeast(0), Charsets.ISO_8859_1) } }
            head.startsWith("d") && (head.contains("8:announce") || head.contains("4:info"))
        }.getOrDefault(false)
    }

    private fun convertToTorrent(id: String, f: File) {
        val bytes = f.readBytes()
        torrents.torrentFile(id).writeBytes(bytes)
        f.delete()
        val sorted = settings.value.sortByCategory
        repo.update(id) {
            it.copy(
                type = DlType.TORRENT, status = DlStatus.QUEUED, error = null, info = "Torrent reçu",
                fileName = f.name.removeSuffix(".torrent").ifBlank { "Torrent" },
                dir = (if (sorted) File(baseDir, "Torrents") else baseDir).path,
                totalBytes = -1, downloadedBytes = 0, percent = -1f, segments = emptyList(), autoName = true,
            )
        }
        torrents.warmUp()
    }

    /** Torrent terminé (ou en pause) dont on veut récupérer un fichier qui était en pause : on le relance. */
    fun restartTorrent(id: String) {
        autoRetries.remove(id)
        repo.update(id) {
            if (it.type == DlType.TORRENT && !it.status.isActive) it.copy(status = DlStatus.QUEUED, error = null, info = "")
            else it
        }
        schedule()
    }

    /**
     * Ancien dossier « DLTurbo » : renommé en « Turbo Download » (les téléchargements en mémoire suivent).
     * Si Android refuse le renommage, les anciens fichiers restent où ils sont et les nouveaux vont dans
     * « Turbo Download ».
     */
    private fun migrateOldFolder() {
        val old = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "DLTurbo")
        val now = baseDir
        if (!old.isDirectory || now.exists()) return
        if (!runCatching { old.renameTo(now) }.getOrDefault(false)) return
        val oldPath = old.path
        repo.items.value.filter { it.dir == oldPath || it.dir.startsWith("$oldPath/") }.forEach { item ->
            repo.update(item.id) { it.copy(dir = now.path + it.dir.removePrefix(oldPath)) }
        }
        repo.saveNow()
    }

    /**
     * Fichiers de travail de l'extracteur vidéo (« … .part », « .part-Frag12 », « .ytdl ») restés dans le
     * dossier public avec les anciennes versions : ils ne servent plus (le travail se fait maintenant dans
     * le dossier privé de l'appli) et sont supprimés. Les fichiers .dlpart des liens directs en cours sont gardés.
     */
    private fun cleanLeftovers() {
        val junk = Regex("""(?i)(\.part(-frag\d+)?(\.part)?|\.ytdl|\.part\.temp)$""")
        listOf(baseDir, File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "DLTurbo"))
            .filter { it.isDirectory }
            .forEach { root ->
                root.walkTopDown()
                    .onEnter { it.name != "Torrents" }
                    .filter { it.isFile && junk.containsMatchIn(it.name) }
                    .forEach { runCatching { it.delete() } }
            }
    }

    /** Plus rien en cours ni en attente : action de fin choisie dans les paramètres (alarme, Wi-Fi). */
    private fun checkAllDone() {
        if (!hadWork) return
        val items = repo.items.value
        val busy = items.any {
            it.status.isActive || it.status == DlStatus.QUEUED || it.status == DlStatus.WAITING_NETWORK ||
                (it.status == DlStatus.ERROR && autoRetries.containsKey(it.id) && it.info.startsWith("Nouvel essai"))
        }
        if (busy || jobs.isNotEmpty()) return
        hadWork = false
        val done = items.count { it.status == DlStatus.COMPLETED }
        if (done == 0) return
        runCatching { com.dlvibestudio.dlturbo.service.AllDone.trigger(context, settings.value.onAllDone, done) }
    }

    /** Économie de batterie : sous 20 % et hors charge, une seule tâche à la fois. */
    private fun batterySaverActive(): Boolean {
        if (!settings.value.batterySaver) return false
        val intent = context.registerReceiver(null, android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED))
            ?: return false
        val level = intent.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, 100)
        val status = intent.getIntExtra(android.os.BatteryManager.EXTRA_STATUS, -1)
        val charging = status == android.os.BatteryManager.BATTERY_STATUS_CHARGING ||
            status == android.os.BatteryManager.BATTERY_STATUS_FULL
        return level >= 0 && level * 100 / scale.coerceAtLeast(1) < 20 && !charging
    }

    // --------------------------------------------------------------- Réseau

    private fun waitingLabel() =
        if (settings.value.wifiOnly) "En attente du Wi-Fi" else "En attente du réseau"

    fun networkOk(): Boolean {
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return true
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) return false
        return !settings.value.wifiOnly || caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
    }

    /** Remet en file ce qui attendait le réseau, dès qu'il est de retour (et qu'Internet répond vraiment). */
    private suspend fun retryWaiting() {
        if (!networkOk()) return
        if (repo.items.value.none { it.status == DlStatus.WAITING_NETWORK }) return
        if (!NetCheck.online(http.client)) return
        if (repo.items.value.none { it.status == DlStatus.WAITING_NETWORK }) return
        repo.updateAll {
            if (it.status == DlStatus.WAITING_NETWORK) it.copy(status = DlStatus.QUEUED, info = "") else it
        }
        schedule()
    }

    /** Mode « Wi-Fi uniquement » : suspend tout si on bascule sur les données mobiles. */
    private fun enforceNetworkPolicy() {
        if (!settings.value.wifiOnly || networkOk()) return
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return
        if (cm.activeNetwork == null) return // simple coupure : les moteurs réessaient d'eux-mêmes
        repo.items.value.filter { jobs.containsKey(it.id) }.forEach { item ->
            repo.update(item.id) {
                if (it.status.isActive) it.copy(status = DlStatus.WAITING_NETWORK, speed = 0, info = waitingLabel())
                else it
            }
            jobs[item.id]?.cancel()
        }
    }

    private fun registerNetworkCallback() {
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return
        runCatching {
            cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    scope.launch { retryWaiting() }
                }

                override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                    scope.launch {
                        enforceNetworkPolicy()
                        retryWaiting()
                    }
                }
            })
        }
    }

    companion object {
        /** Attentes avant chaque nouvel essai automatique (5 essais au plus). */
        private const val MAX_LINK_REFRESHES = 3

        /** Messages d'un moteur vidéo quand l'adresse signée n'est plus acceptée. */
        private val EXPIRED_MESSAGE = Regex("""(?i)(http error 40[13]|http error 410|\b40[13]\b|\b410\b|forbidden|expired|signature)""")

        private val RETRY_DELAYS = longArrayOf(10_000, 30_000, 60_000, 180_000, 600_000)

        /** Erreurs qu'un nouvel essai ne corrigera pas (vidéo privée, supprimée, espace plein…). */
        private val PERMANENT_ERROR = Regex(
            """(?i)(private video|vidéo privée|video unavailable|has been removed|copyright|members-only|""" +
                """sign in to confirm your age|espace de stockage insuffisant|écriture impossible|impossible de créer le dossier|""" +
                """le fichier a changé|introuvable|http error 404|\b404\b|\b410\b)"""
        )
    }
}
