package com.dlvibestudio.dlturbo.ui

import android.content.Context
import androidx.compose.runtime.mutableIntStateOf
import org.json.JSONArray
import org.json.JSONObject

/** Réglages propres à un site (comme 1DM) : ce qui diffère des réglages généraux du navigateur. */
data class SiteRules(
    val ads: Boolean = true,
    val popups: Boolean = true,
    val js: Boolean = true,
    val desktop: Boolean = false,
    /** Sélecteurs CSS des zones masquées par l'utilisateur. */
    val hidden: List<String> = emptyList(),
) {
    val isDefault: Boolean get() = this == SiteRules()

    fun toJson(): JSONObject = JSONObject()
        .put("ads", ads).put("popups", popups).put("js", js).put("desktop", desktop)
        .put("hidden", JSONArray(hidden))

    companion object {
        fun fromJson(o: JSONObject): SiteRules {
            val arr = o.optJSONArray("hidden") ?: JSONArray()
            return SiteRules(
                ads = o.optBoolean("ads", true), popups = o.optBoolean("popups", true),
                js = o.optBoolean("js", true), desktop = o.optBoolean("desktop", false),
                hidden = (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() },
            )
        }
    }
}

/**
 * Réglages par site, enregistrés sur le téléphone. Lus aussi par les scripts des pages (pont « DLP »),
 * donc depuis plusieurs fils : accès synchronisés.
 */
class SiteSettings(context: Context) {
    private val prefs = context.getSharedPreferences("dlturbo_sites", Context.MODE_PRIVATE)
    private val map = HashMap<String, SiteRules>()

    /** Change à chaque modification : l'interface se met à jour. */
    val version = mutableIntStateOf(0)

    init {
        runCatching {
            val o = JSONObject(prefs.getString("sites", "{}") ?: "{}")
            for (k in o.keys()) map[k] = SiteRules.fromJson(o.getJSONObject(k))
        }
    }

    @Synchronized
    fun of(host: String?): SiteRules = map[key(host)] ?: SiteRules()

    @Synchronized
    fun set(host: String?, rules: SiteRules) {
        val k = key(host)
        if (k.isBlank()) return
        if (rules.isDefault) map.remove(k) else map[k] = rules
        save()
    }

    fun hide(host: String?, selector: String) {
        val sel = selector.trim().take(400)
        if (sel.isBlank()) return
        val r = of(host)
        if (sel !in r.hidden) set(host, r.copy(hidden = (r.hidden + sel).takeLast(200)))
    }

    @Synchronized
    fun all(): List<Pair<String, SiteRules>> = map.entries.sortedBy { it.key }.map { it.key to it.value }

    /** Feuille de style qui masque les zones choisies sur ce site ("" s'il n'y en a pas). */
    fun css(host: String?): String {
        val h = of(host).hidden
        if (h.isEmpty()) return ""
        return h.joinToString("\n") { "$it { display: none !important; }" }
    }

    private fun save() {
        val o = JSONObject()
        map.forEach { (k, v) -> o.put(k, v.toJson()) }
        prefs.edit().putString("sites", o.toString()).apply()
        version.intValue++
    }

    companion object {
        private val SECOND_LEVEL = setOf("co", "com", "net", "org", "gov", "gouv", "edu", "ac", "or", "ne")

        /** Site « racine » (exemple.com pour www.exemple.com, m.exemple.com…). */
        fun key(host: String?): String {
            val h = host?.lowercase()?.trim()?.removePrefix("www.") ?: return ""
            val parts = h.split('.')
            if (parts.size <= 2) return h
            // Domaines du type exemple.co.uk, exemple.com.br : on garde trois parties.
            val second = parts[parts.size - 2]
            return if (second in SECOND_LEVEL && parts.last().length == 2) parts.takeLast(3).joinToString(".")
            else parts.takeLast(2).joinToString(".")
        }
    }
}
