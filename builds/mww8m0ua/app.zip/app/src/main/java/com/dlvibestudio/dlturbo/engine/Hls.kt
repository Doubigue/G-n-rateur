package com.dlvibestudio.dlturbo.engine

import java.net.URI

/**
 * Lecture des listes HLS (.m3u8) : liste maître (qualités, pistes audio séparées) et liste de morceaux
 * (durées, plages d'octets, clés AES-128, segment d'initialisation fMP4). Sans dépendance Android.
 */
object Hls {

    data class Variant(val uri: String, val bandwidth: Long, val height: Int, val audioGroup: String?, val codecs: String)

    data class Rendition(val groupId: String, val uri: String?, val isDefault: Boolean, val language: String, val name: String)

    data class Master(val variants: List<Variant>, val audio: List<Rendition>) {
        /** Piste audio séparée d'une qualité (null si l'audio est déjà dans les morceaux vidéo). */
        fun audioFor(v: Variant): Rendition? {
            val group = v.audioGroup ?: return null
            val list = audio.filter { it.groupId == group && it.uri != null }
            return list.firstOrNull { it.isDefault } ?: list.firstOrNull()
        }
    }

    /** Clé de chiffrement. [method] : AES-128 (pris en charge) ou autre (SAMPLE-AES, DRM : non pris en charge). */
    data class Key(val method: String, val uri: String?, val iv: ByteArray?, val keyFormat: String) {
        val supported: Boolean get() = method == "AES-128" && uri != null && (keyFormat.isEmpty() || keyFormat == "identity")
        override fun equals(other: Any?) = other is Key && method == other.method && uri == other.uri &&
            (iv?.contentEquals(other.iv) ?: (other.iv == null)) && keyFormat == other.keyFormat
        override fun hashCode() = (uri ?: method).hashCode()
    }

    data class Init(val uri: String, val range: LongRange?, val key: Key?)

    data class Segment(val uri: String, val duration: Double, val range: LongRange?, val key: Key?, val seq: Long, val init: Init?)

    data class Media(val segments: List<Segment>, val ended: Boolean, val targetDuration: Double) {
        val duration: Double get() = segments.sumOf { it.duration }
        val unsupportedKey: Boolean
            get() = segments.any { s -> (s.key?.supported == false) || (s.init?.key?.supported == false) }
        val fragmentedMp4: Boolean get() = segments.any { it.init != null }
    }

    fun isPlaylist(text: String?): Boolean = text?.trimStart('﻿', ' ', '\n', '\r', '\t')?.startsWith("#EXTM3U") == true

    fun isMaster(text: String): Boolean = text.contains("#EXT-X-STREAM-INF")

    fun resolve(base: String, ref: String): String =
        runCatching { URI(base).resolve(URI(ref.trim().replace(" ", "%20"))).toString() }.getOrDefault(ref.trim())

    /** Attributs « CLÉ=valeur,CLÉ="valeur, avec virgule" ». */
    fun attributes(text: String): Map<String, String> {
        val out = HashMap<String, String>()
        var i = 0
        while (i < text.length) {
            val eq = text.indexOf('=', i)
            if (eq < 0) break
            val key = text.substring(i, eq).trim().trimStart(',').trim().uppercase()
            var j = eq + 1
            val value: String
            if (j < text.length && text[j] == '"') {
                val end = text.indexOf('"', j + 1).let { if (it < 0) text.length else it }
                value = text.substring(j + 1, end)
                j = end + 1
            } else {
                val end = text.indexOf(',', j).let { if (it < 0) text.length else it }
                value = text.substring(j, end).trim()
                j = end
            }
            if (key.isNotEmpty()) out[key] = value
            i = j + 1
        }
        return out
    }

    fun parseMaster(base: String, text: String): Master {
        val lines = text.lines().map { it.trim() }
        val variants = ArrayList<Variant>()
        val audio = ArrayList<Rendition>()
        for ((i, line) in lines.withIndex()) {
            when {
                line.startsWith("#EXT-X-STREAM-INF:") -> {
                    val a = attributes(line.substringAfter(':'))
                    val uri = lines.drop(i + 1).firstOrNull { it.isNotEmpty() && !it.startsWith("#") } ?: continue
                    val bw = (a["AVERAGE-BANDWIDTH"] ?: a["BANDWIDTH"])?.toLongOrNull() ?: 0L
                    val h = a["RESOLUTION"]?.substringAfter('x', "")?.toIntOrNull() ?: 0
                    variants.add(Variant(resolve(base, uri), bw, h, a["AUDIO"], a["CODECS"].orEmpty()))
                }
                line.startsWith("#EXT-X-MEDIA:") -> {
                    val a = attributes(line.substringAfter(':'))
                    if (a["TYPE"] != "AUDIO") continue
                    audio.add(
                        Rendition(
                            a["GROUP-ID"].orEmpty(), a["URI"]?.let { resolve(base, it) }, a["DEFAULT"] == "YES",
                            a["LANGUAGE"].orEmpty(), a["NAME"].orEmpty(),
                        )
                    )
                }
            }
        }
        // Les listes « I-frame only » et les doublons (même adresse) ne sont pas des qualités à télécharger.
        return Master(variants.distinctBy { it.uri }, audio)
    }

    fun parseMedia(base: String, text: String): Media {
        val segments = ArrayList<Segment>()
        var seq = 0L
        var duration = 0.0
        var target = 0.0
        var key: Key? = null
        var init: Init? = null
        var range: LongRange? = null
        var ended = false
        val lastRangeEnd = HashMap<String, Long>()
        var pendingRange: String? = null
        for (raw in text.lines()) {
            val line = raw.trim()
            when {
                line.isEmpty() -> Unit
                line.startsWith("#EXT-X-MEDIA-SEQUENCE:") -> seq = line.substringAfter(':').trim().toLongOrNull() ?: 0L
                line.startsWith("#EXT-X-TARGETDURATION:") -> target = line.substringAfter(':').trim().toDoubleOrNull() ?: 0.0
                line.startsWith("#EXTINF:") -> duration = line.substringAfter(':').substringBefore(',').trim().toDoubleOrNull() ?: 0.0
                line.startsWith("#EXT-X-ENDLIST") -> ended = true
                line.startsWith("#EXT-X-PLAYLIST-TYPE:") -> if (line.substringAfter(':').trim() == "VOD") ended = true
                line.startsWith("#EXT-X-BYTERANGE:") -> pendingRange = line.substringAfter(':').trim()
                line.startsWith("#EXT-X-KEY:") -> {
                    val a = attributes(line.substringAfter(':'))
                    val method = a["METHOD"].orEmpty()
                    key = if (method == "NONE" || method.isEmpty()) null else Key(
                        method, a["URI"]?.let { resolve(base, it) }, a["IV"]?.let { hexIv(it) }, a["KEYFORMAT"].orEmpty(),
                    )
                }
                line.startsWith("#EXT-X-MAP:") -> {
                    val a = attributes(line.substringAfter(':'))
                    val u = a["URI"]?.let { resolve(base, it) }
                    init = if (u == null) null else Init(u, a["BYTERANGE"]?.let { byteRange(it, 0L) }, key)
                }
                line.startsWith("#") -> Unit
                else -> {
                    val uri = resolve(base, line)
                    range = pendingRange?.let { byteRange(it, lastRangeEnd[uri] ?: 0L) }
                    range?.let { lastRangeEnd[uri] = it.last + 1 }
                    segments.add(Segment(uri, duration, range, key, seq, init))
                    seq++
                    duration = 0.0
                    pendingRange = null
                }
            }
        }
        return Media(segments, ended, target)
    }

    /** « longueur[@début] » ; sans début, la plage suit la précédente du même fichier. */
    fun byteRange(spec: String, defaultStart: Long): LongRange? {
        val len = spec.substringBefore('@').trim().toLongOrNull() ?: return null
        val start = if (spec.contains('@')) spec.substringAfter('@').trim().toLongOrNull() ?: return null else defaultStart
        if (len <= 0) return null
        return start until start + len
    }

    private fun hexIv(s: String): ByteArray? {
        val h = s.removePrefix("0x").removePrefix("0X")
        if (h.length != 32) return null
        return runCatching { ByteArray(16) { h.substring(it * 2, it * 2 + 2).toInt(16).toByte() } }.getOrNull()
    }

    /** Vecteur d'initialisation implicite : numéro de séquence du morceau sur 16 octets. */
    fun sequenceIv(seq: Long): ByteArray = ByteArray(16).also { b -> for (i in 0 until 8) b[15 - i] = (seq ushr (8 * i)).toByte() }

    /** Qualité demandée : « best », ou une hauteur maximale (« 720 »…). */
    fun choose(variants: List<Variant>, quality: String): Variant? {
        if (variants.isEmpty()) return null
        val order = compareBy<Variant>({ it.height }, { it.bandwidth })
        val max = quality.toIntOrNull()
        if (max == null) return variants.maxWithOrNull(order)
        val fitting = variants.filter { it.height in 1..max }
        return fitting.maxWithOrNull(order)
            ?: if (variants.all { it.height == 0 }) variants.maxByOrNull { it.bandwidth } else variants.minWithOrNull(order)
    }
}
