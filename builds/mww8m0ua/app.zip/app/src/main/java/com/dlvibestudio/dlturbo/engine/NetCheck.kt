package com.dlvibestudio.dlturbo.engine

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

/**
 * Coupures de connexion : Android peut annoncer un réseau « présent » (Wi-Fi connecté, données mobiles actives)
 * alors qu'Internet ne passe plus (forfait épuisé, box sans connexion, signal trop faible). On reconnaît ici les
 * erreurs dues au réseau et on vérifie qu'Internet répond vraiment, pour mettre le téléchargement « en attente
 * du réseau » (sans limite de durée) au lieu de le passer en échec.
 */
object NetCheck {

    private val NET_MESSAGE = Regex(
        """(?i)(unable to resolve host|unknownhost|name or service not known|temporary failure in name resolution|""" +
            """no address associated|getaddrinfo|nodename nor servname|network is unreachable|no route to host|""" +
            """connection (reset|refused|aborted|timed out|closed)|timed? ?out|timeout|failed to establish|""" +
            """remote end closed|broken pipe|software caused connection abort|unexpected end of stream|""" +
            """connectionerror|transporterror|incompleteread|errno (7|101|103|104|110|111|113)|""" +
            """unable to download (webpage|video data|json)|connexion interrompue|réseau|ssl.*(eof|handshake))"""
    )

    /** L'erreur ressemble-t-elle à une coupure réseau (et non à un fichier introuvable, une vidéo privée…) ? */
    fun looksLikeNetwork(t: Throwable): Boolean {
        var e: Throwable? = t
        var depth = 0
        while (e != null && depth < 6) {
            if (e is java.net.UnknownHostException || e is java.net.SocketTimeoutException ||
                e is java.net.ConnectException || e is java.net.NoRouteToHostException ||
                e is java.net.SocketException || e is javax.net.ssl.SSLException ||
                e is java.io.EOFException || e is java.io.InterruptedIOException
            ) return true
            if (NET_MESSAGE.containsMatchIn(e.message.orEmpty())) return true
            e = e.cause
            depth++
        }
        return false
    }

    private val PROBES = listOf(
        "https://connectivitycheck.gstatic.com/generate_204",
        "https://cp.cloudflare.com/generate_204",
        "http://connectivitycheck.android.com/generate_204",
    )

    @Volatile private var lastResult = true
    @Volatile private var lastCheck = 0L

    /** Internet répond-il vraiment ? (résultat gardé 5 s pour ne pas multiplier les requêtes) */
    suspend fun online(base: OkHttpClient): Boolean = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        if (now - lastCheck < 5_000) return@withContext lastResult
        val client = base.newBuilder()
            .connectTimeout(6, TimeUnit.SECONDS)
            .readTimeout(6, TimeUnit.SECONDS)
            .callTimeout(8, TimeUnit.SECONDS)
            .followRedirects(false)
            .build()
        var ok = false
        for (url in PROBES) {
            ok = runCatching {
                client.newCall(Request.Builder().url(url).header("Cache-Control", "no-cache").build()).execute()
                    .use { it.code == 204 || (it.code == 200 && (it.body?.contentLength() ?: -1L) == 0L) }
            }.getOrDefault(false)
            if (ok) break
        }
        lastCheck = System.currentTimeMillis()
        lastResult = ok
        ok
    }
}
