# Media Studio (Kotlin / Compose / Media3)
Ouvrir le dossier dans Android Studio (Ladybug+), laisser Gradle synchroniser, lancer sur un appareil (API 26+).

- MP4→MP3, WAV→MP3 : MediaCodec (décodage) + LAME (TAndroidLame)
- Compression MP4 : Media3 Transformer, H.264 matériel, hauteur + débit réglables
- Musique+Vidéo : 2 séquences Media3, musique bouclée
- Coller : séquence Media3 (ordre modifiable)

## Ajouts
- Découpe, filtres (8), texte superposé, fondu entre clips, volumes, découpe musique, aperçu
- Icône adaptative (res/mipmap-anydpi-v26) + notifications de progression / fin d'export

## Images d'une vidéo (pilotage par LinkShare)

Le routeur accepte deux nouvelles actions explicites :
- `com.mediastudio.app.action.FRAME_COUNT` : compte les échantillons de la piste vidéo et exporte un rapport texte `*_nombre_images.txt`.
- `com.mediastudio.app.action.EXTRACT_FRAMES` : extrait les images en JPEG et crée une archive ZIP `*_images.zip`. L'archive contient un dossier portant le nom de la vidéo, avec `image_000001.jpg`, etc.

Ces actions sont destinées à être déclenchées depuis LinkShare, qui transmet le fichier source via `content://` et reçoit l'URI du résultat.


## Extraction vidéo : images et métadonnées

L'action `EXTRACT_FRAMES` produit une archive ZIP contenant un dossier au nom de la vidéo,
les images JPEG numérotées, un `metadata.txt` (FPS, dimensions, durée, codec, débit,
rotation, nombre d'images et informations audio) et `audio_originale.m4a` lorsque la
piste source est en AAC compatible MP4. Les pistes audio décodables par les codecs disponibles sur Android sont normalisées en AAC/M4A via Media3 Transformer ; si le codec n’est pas décodable, l’échec est indiqué dans les métadonnées.

La reconstruction vidéo depuis le dossier/ZIP sélectionné nécessite encore son pipeline
d'encodage et son action de routeur dédiée : elle n'est pas annoncée comme disponible dans
cette livraison. Une reconstruction ré-encode les images et ne peut donc pas garantir
une identité binaire avec le fichier original.


### Métadonnées d'extraction détaillées

`metadata.txt` consigne maintenant le MIME du conteneur, le codec vidéo, la durée en millisecondes et secondes, le FPS déclaré et le FPS moyen calculé, le nombre d'images extraites, la résolution, le débit, le profil/niveau du codec, les informations de couleur et la rotation. Pour l'audio, le rapport indique la présence, le codec, la fréquence d'échantillonnage, le nombre de canaux et le débit lorsque Android expose ces valeurs. La piste AAC (`audio/mp4a-latm`) est copiée dans `audio_originale.m4a` sans réencodage. Les autres codecs sont signalés mais ne sont pas exportés par cette version.

La qualité perceptuelle exacte ne peut pas être déduite d'un seul champ : le rapport fournit les indicateurs techniques disponibles. Le moteur de reconstruction MP4 et son action LinkShare restent à développer/tester séparément.


## Reconstruction vidéo depuis un paquet d'images

L'action `REBUILD_VIDEO` accepte l'archive ZIP produite par `EXTRACT_FRAMES`. Elle vérifie `metadata.txt`,
contrôle le nombre d'images, les trie par numéro, lit le FPS et la durée, puis reconstruit un MP4 via
Media3 Transformer. Si `audio_originale.m4a` est présent, il est ajouté comme piste audio ; l'audio extrait
est normalisé en AAC/M4A par Transformer afin de prendre en charge les formats audio décodables par Android.
LinkShare propose « Reconstruire une vidéo » lorsque l'utilisateur sélectionne le ZIP d'extraction.

Limites : la reconstruction réencode les images en vidéo H.264/AAC ; elle ne peut pas être identique bit à bit
à l'originale. Le rendu exact dépend des codecs et capacités MediaCodec de l'appareil. La reconstruction est
limitée à 50 000 images par paquet pour éviter une consommation mémoire excessive.
