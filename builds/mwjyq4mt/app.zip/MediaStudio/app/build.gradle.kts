plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.mediastudio.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.mediastudio.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    signingConfigs {
        create("release") {
            storeFile = rootProject.file("keystore/mediastudio-release.jks")
            storePassword = providers.environmentVariable("MEDIA_STUDIO_STORE_PASSWORD").orNull ?: ""
            keyAlias = "mediastudio-release"
            keyPassword = providers.environmentVariable("MEDIA_STUDIO_KEY_PASSWORD").orNull
                ?: providers.environmentVariable("MEDIA_STUDIO_STORE_PASSWORD").orNull
                ?: ""
        }
    }
    buildTypes {
        getByName("release") {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = false
        }
    }
    buildFeatures { compose = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    packaging { resources { excludes += setOf("META-INF/DEPENDENCIES", "META-INF/LICENSE*", "META-INF/NOTICE*", "META-INF/*.kotlin_module") } }
}
// TAndroidLame (2015) embarque l'ancienne support-library : doublons avec AndroidX -> exclue.
configurations.configureEach { exclude(group = "com.android.support") }

dependencies {
    val media3 = "1.5.1"
    implementation("androidx.media3:media3-transformer:$media3")
    implementation("androidx.media3:media3-effect:$media3")
    implementation("androidx.media3:media3-common:$media3")
    implementation("androidx.media3:media3-exoplayer:$media3")
    implementation("androidx.media3:media3-ui:$media3")
    implementation("com.github.naman14:TAndroidLame:1.1") // LAME (MP3 encoder)
    implementation("com.tom-roush:pdfbox-android:2.0.27.0") // PDF -> Word (extraction du texte)
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
}
