package app.arpenteur

import android.content.Context
import android.content.Intent
import android.content.res.Resources
import android.graphics.*
import android.graphics.Color as AColor
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.drawToBitmap
import org.osmdroid.tileprovider.cachemanager.CacheManager
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.MapTileIndex
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.Projection
import org.osmdroid.views.overlay.Overlay
import kotlin.math.abs
import org.osmdroid.util.GeoPoint as OsmPoint

/** Imagerie satellite Esri (mise en cache par osmdroid). */
object EsriSat : OnlineTileSourceBase(
    "EsriWorldImagery", 0, 19, 256, ".jpg",
    arrayOf("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/"), "© Esri"
) {
    override fun getTileURLString(t: Long) =
        baseUrl + MapTileIndex.getZoom(t) + "/" + MapTileIndex.getY(t) + "/" + MapTileIndex.getX(t)
}

/** Dessine le polygone, les distances et les bornes numérotées par-dessus la carte. */
class ParcelOverlay(private val pts: List<GeoPoint>) : Overlay() {
    private val d = Resources.getSystem().displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = AColor.argb(70, 61, 220, 132) }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = AColor.parseColor("#3DDC84"); style = Paint.Style.STROKE; strokeWidth = 3 * d; strokeJoin = Paint.Join.ROUND }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; isFakeBoldText = true }

    override fun draw(c: Canvas, pj: Projection) {
        val px = pts.map { pj.toPixels(OsmPoint(it.lat, it.lon), null) }
        val path = Path().apply { moveTo(px[0].x.toFloat(), px[0].y.toFloat()); px.drop(1).forEach { lineTo(it.x.toFloat(), it.y.toFloat()) }; close() }
        c.drawPath(path, fill); c.drawPath(path, line)
        val seg = GeoCalculator.segments(pts, true)
        txt.textSize = 11 * d
        px.indices.forEach { i ->
            val a = px[i]; val b = px[(i + 1) % px.size]
            val s = if (seg[i] >= 1000) "%.2f km".format(seg[i] / 1000) else "%.1f m".format(seg[i])
            val mx = (a.x + b.x) / 2f; val my = (a.y + b.y) / 2f - 6 * d
            txt.style = Paint.Style.STROKE; txt.strokeWidth = 3 * d; txt.color = AColor.BLACK; c.drawText(s, mx, my, txt)
            txt.style = Paint.Style.FILL; txt.color = AColor.parseColor("#FFC857"); c.drawText(s, mx, my, txt)
        }
        px.forEachIndexed { i, q ->
            dot.color = AColor.WHITE; c.drawCircle(q.x.toFloat(), q.y.toFloat(), 11 * d, dot)
            dot.color = if (i == 0) AColor.parseColor("#FFC857") else AColor.parseColor("#3DDC84"); c.drawCircle(q.x.toFloat(), q.y.toFloat(), 9 * d, dot)
            txt.color = AColor.BLACK; txt.textSize = 10 * d; c.drawText("${i + 1}", q.x.toFloat(), q.y + 3.5f * d, txt)
        }
    }
}

private val BgC = Color(0xFF0B1410)
private val CardC = Color(0xFF14221B)
private val AccentC = Color(0xFF3DDC84)

@Composable
fun MapScreen(points: List<GeoPoint>, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf("Ma parcelle") }
    var sat by remember { mutableStateOf(true) }
    var withMap by remember { mutableStateOf(true) }
    var status by remember { mutableStateOf<String?>(null) }
    val osmPts = remember { points.map { OsmPoint(it.lat, it.lon) } }
    val mapView = remember {
        MapView(ctx).apply {
            setMultiTouchControls(true); minZoomLevel = 3.0; maxZoomLevel = 20.0
            zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
            overlays.add(ParcelOverlay(points))
            val bb = BoundingBox.fromGeoPoints(osmPts).increaseByScale(1.35f)
            addOnFirstLayoutListener { _, _, _, _, _ -> zoomToBoundingBox(bb, false) }
        }
    }
    DisposableEffect(Unit) { mapView.onResume(); onDispose { mapView.onPause(); mapView.onDetach() } }
    LaunchedEffect(sat) { mapView.setTileSource(if (sat) Tiles.sat else Tiles.plan); mapView.invalidate() }

    fun download() {
        val bb = BoundingBox.fromGeoPoints(osmPts).increaseByScale(1.6f)
        val cm = CacheManager(mapView)
        var zmax = 19
        while (zmax > 15 && cm.possibleTilesInArea(bb, 14, zmax) > 1500) zmax--
        status = "Téléchargement de ${cm.possibleTilesInArea(bb, 14, zmax)} tuiles…"
        cm.downloadAreaAsync(ctx, bb, 14, zmax, object : CacheManager.CacheManagerCallback {
            override fun onTaskComplete() { mapView.post { status = "Carte disponible hors ligne ✓" } }
            override fun onTaskFailed(errors: Int) { mapView.post { status = "Terminé avec $errors erreur(s) — connexion requise" } }
            override fun updateProgress(progress: Int, currentZoomLevel: Int, zoomMin: Int, zoomMax: Int) { mapView.post { status = "Zoom $currentZoomLevel… $progress tuiles" } }
            override fun downloadStarted() {}
            override fun setPossibleTilesInArea(total: Int) {}
        })
    }

    fun export(pdf: Boolean) {
        val snap = if (withMap) runCatching { mapView.drawToBitmap() }.getOrNull() else null
        var ppm: Double? = null
        if (snap != null) { // échelle réelle de la vue : px par mètre
            val c = mapView.mapCenter; val pj = mapView.projection
            val east = OsmPoint(c.latitude, c.longitude + 100.0 / (111320.0 * Math.cos(Math.toRadians(c.latitude))))
            ppm = abs(pj.toPixels(east, null).x - pj.toPixels(OsmPoint(c.latitude, c.longitude), null).x) / 100.0
        }
        val credit = if (snap == null) "Plan GPS hors ligne" else (if (sat) Tiles.sat else Tiles.plan).copyrightNotice ?: ""
        val data = ReportData(name.ifBlank { "Parcelle" }, Exporter.now(), points,
            GeoCalculator.areaM2(points), GeoCalculator.perimeter(points), credit)
        val safe = name.replace(Regex("[^A-Za-z0-9_-]"), "_").ifBlank { "parcelle" }
        val uri = if (pdf) Exporter.writeBytes(ctx, "$safe-rapport.pdf", "application/pdf", ReportRenderer.toPdf(data, snap, ppm))
        else Exporter.writeBytes(ctx, "$safe-carte.png", "image/png", ReportRenderer.toPng(data, snap, ppm))
        if (uri != null) {
            Toast.makeText(ctx, "Enregistré dans Téléchargements/Arpenteur", Toast.LENGTH_LONG).show()
            ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = if (pdf) "application/pdf" else "image/png"
                putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }, "Partager"))
        }
    }

    Column(Modifier.fillMaxSize().background(BgC).systemBarsPadding().padding(12.dp)) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            TextButton(onClose) { Text("← Retour") }
            Text("Carte & rapport", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = AccentC)
            Spacer(Modifier.width(72.dp))
        }
        OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Nom de la parcelle") })
        Spacer(Modifier.height(10.dp))
        AndroidView({ mapView }, Modifier.fillMaxWidth().aspectRatio(4f / 3f).clip(RoundedCornerShape(20.dp)))
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(8.dp)) {
            FilterChip(sat, { sat = true }, { Text("Satellite") }, Modifier.weight(1f))
            FilterChip(!sat, { sat = false }, { Text("Plan") }, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Switch(withMap, { withMap = it }); Spacer(Modifier.width(8.dp))
            Text("Fond de carte dans le rapport", fontSize = 13.sp)
        }
        status?.let { Text(it, fontSize = 12.sp, color = AccentC, modifier = Modifier.padding(vertical = 4.dp)) }
        OutlinedButton(::download, Modifier.fillMaxWidth()) { Text("Télécharger la carte (hors ligne)") }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(8.dp)) {
            Button({ export(true) }, Modifier.weight(1f).height(52.dp)) { Text("Rapport PDF", fontWeight = FontWeight.Bold) }
            Button({ export(false) }, Modifier.weight(1f).height(52.dp)) { Text("Image PNG", fontWeight = FontWeight.Bold) }
        }
        Text(if (Tiles.hasKey) "Tuiles MapTiler (clé dédiée). Connexion requise une seule fois ; elles restent ensuite en cache." else "Aucune clé dédiée : tuiles publiques Esri/OSM (usage léger). Connexion requise une seule fois.",
            fontSize = 10.sp, color = Color.White.copy(.5f), modifier = Modifier.padding(top = 6.dp))
    }
}
