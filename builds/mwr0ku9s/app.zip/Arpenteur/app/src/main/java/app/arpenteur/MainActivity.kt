package app.arpenteur

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import org.osmdroid.config.Configuration
import java.io.File

private val Bg = Color(0xFF0B1410)
private val Card = Color(0xFF14221B)
private val Accent = Color(0xFF3DDC84)
private val Warn = Color(0xFFFFC857)
private val Bad = Color(0xFFFF6B6B)

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().apply { // cache de tuiles dans le stockage de l'app
            userAgentValue = packageName
            val base = File(getExternalFilesDir(null) ?: filesDir, "osmdroid")
            osmdroidBasePath = base; osmdroidTileCache = File(base, "tiles")
            tileFileSystemCacheMaxBytes = 500L * 1024 * 1024
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) // écran allumé sur le terrain
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Card, onPrimary = Color.Black)) {
                val ctx = androidx.compose.ui.platform.LocalContext.current
                var granted by remember {
                    mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)
                }
                var showMap by remember { mutableStateOf(false) }
                val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
                LaunchedEffect(Unit) { if (!granted) launcher.launch(Manifest.permission.ACCESS_FINE_LOCATION) }
                LaunchedEffect(granted) { if (granted) vm.startGps() }
                LaunchedEffect(vm.message) { vm.message?.let { Toast.makeText(ctx, it, Toast.LENGTH_SHORT).show(); vm.message = null } }

                if (!granted) PermissionScreen { launcher.launch(Manifest.permission.ACCESS_FINE_LOCATION) }
                else if (showMap) { BackHandler { showMap = false }; MapScreen(vm.points.toList()) { showMap = false } }
                else Screen(vm, onMap = { showMap = true }) { name, pts, geo ->
                    vm.export(name, pts, geo)?.let { uri ->
                        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                            type = if (geo) "application/geo+json" else "text/csv"
                            putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }, "Exporter"))
                        Toast.makeText(ctx, "Enregistré dans Téléchargements/Arpenteur", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }
}

@Composable
fun PermissionScreen(onAsk: () -> Unit) = Column(
    Modifier.fillMaxSize().background(Bg).padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally
) {
    Text("Arpenteur", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Accent)
    Spacer(Modifier.height(12.dp))
    Text("L'accès à la position (GPS) est nécessaire pour mesurer votre parcelle. Aucune donnée ne quitte le téléphone.", color = Color.White.copy(.8f))
    Spacer(Modifier.height(24.dp))
    Button(onAsk) { Text("Autoriser le GPS") }
}

@Composable
fun Screen(vm: MainViewModel, onMap: () -> Unit, onExport: (String, List<GeoPoint>, Boolean) -> Unit) {
    var showSettings by remember { mutableStateOf(false) }
    var showParcels by remember { mutableStateOf(false) }
    var showSave by remember { mutableStateOf(false) }
    val a = vm.area; val per = vm.perimeter

    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Bg, Color(0xFF0F1D16)))).systemBarsPadding().padding(12.dp)) {
        // En-tête
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text("Arpenteur", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Accent)
            GpsChip(vm)
            Row {
                TextButton({ showParcels = true }) { Text("Parcelles") }
                TextButton({ showSettings = true }) { Text("Réglages") }
            }
        }
        Spacer(Modifier.height(8.dp))

        // Tracé en direct
        Box(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color(0xFF0A130E))) {
            PlotCanvas(vm.points, vm.fix, vm.closed, Modifier.fillMaxSize(),
                polygon = vm.measure == Measure.PARCELLE,
                closeRadius = if (vm.measure == Measure.PARCELLE) vm.closeRadius else 0f,
                letters = vm.measure == Measure.DISTANCE)
            vm.avgProgress?.let {
                Column(Modifier.align(Alignment.BottomCenter).padding(16.dp).fillMaxWidth(.7f).background(Card.copy(.95f), RoundedCornerShape(12.dp)).padding(12.dp)) {
                    Text("Moyenne GPS en cours… ne bougez pas", fontSize = 12.sp)
                    LinearProgressIndicator(progress = { it }, Modifier.fillMaxWidth().padding(top = 6.dp))
                }
            }
            if (vm.measure == Measure.PARCELLE && vm.points.size >= 3 && !vm.closed)
                Text("PROVISOIRE", Modifier.align(Alignment.TopStart).padding(12.dp), fontSize = 10.sp, color = Warn, fontWeight = FontWeight.Bold)
            if (vm.nearStart && !vm.closed)
                Text("Départ atteint", Modifier.align(Alignment.BottomEnd).padding(12.dp).background(Accent, RoundedCornerShape(50)).padding(horizontal = 10.dp, vertical = 4.dp), fontSize = 11.sp, color = Color.Black, fontWeight = FontWeight.Bold)
            if (vm.intersects)
                Text("⚠ tracé croisé", Modifier.align(Alignment.TopCenter).padding(12.dp), fontSize = 11.sp, color = Bad)
        }
        Spacer(Modifier.height(10.dp))

        // Type de mesure
        Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(8.dp)) {
            FilterChip(vm.measure == Measure.DISTANCE, { vm.selectMeasure(Measure.DISTANCE) }, { Text("Distance A→B") }, Modifier.weight(1f))
            FilterChip(vm.measure == Measure.PARCELLE, { vm.selectMeasure(Measure.PARCELLE) }, { Text("Parcelle (tour)") }, Modifier.weight(1f))
        }
        Spacer(Modifier.height(4.dp))

        // Résultats
        if (vm.measure == Measure.DISTANCE) {
            Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(8.dp)) {
                Stat("Distance A→B", fmtDist(vm.distAB), Modifier.weight(1.3f), big = true)
                Stat("Parcours", fmtDist(vm.pathLength), Modifier.weight(1f))
                Stat("Depuis dernier pt", vm.liveFromLast?.let(::fmtDist) ?: "—", Modifier.weight(1f))
            }
        } else {
            Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(8.dp)) {
                Stat("Périmètre", fmtDist(per), Modifier.weight(1f))
                Stat("Surface", "%.4f ha".format(GeoCalculator.ha(a)), Modifier.weight(1.2f), big = true)
                Stat("Surface", "%,.0f m²".format(a), Modifier.weight(1f))
            }
        }
        val n = vm.points.size
        val hint = if (vm.measure == Measure.DISTANCE) when {
            n == 0 -> "Placez-vous au point A et appuyez sur « Marquer »"
            n == 1 -> "Marchez jusqu'au point B puis marquez-le"
            else -> "Distance en ligne droite de A au dernier point"
        } else when {
            vm.closed -> "Parcelle fermée • %d bornes • ≈ %.2f acres".format(n, GeoCalculator.acres(a))
            n == 0 -> "Marquez le point de départ, puis faites le tour du terrain"
            n < 3 -> "Continuez le tour : encore ${3 - n} borne(s) minimum"
            else -> "Revenez au point 1 pour boucler" + (vm.distToStart?.let { " • à %.0f m du départ".format(it) } ?: "")
        }
        Text(hint, Modifier.align(Alignment.CenterHorizontally).padding(top = 4.dp), fontSize = 11.sp, color = Color.White.copy(.7f))
        Spacer(Modifier.height(8.dp))

        // Mode
        Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(8.dp)) {
            FilterChip(vm.mode == Mode.MANUEL, { vm.mode = Mode.MANUEL; vm.recording = false }, { Text("Bornage (points)") }, Modifier.weight(1f))
            FilterChip(vm.mode == Mode.AUTO, { vm.mode = Mode.AUTO }, { Text("Auto (marche)") }, Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))

        // Contrôles principaux
        Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(8.dp)) {
            if (vm.mode == Mode.MANUEL)
                Button({ vm.markCorner() }, Modifier.weight(2f).height(54.dp), enabled = !vm.closed && vm.avgProgress == null) { Text(if (vm.measure == Measure.DISTANCE) when (vm.points.size) { 0 -> "Marquer le point A"; 1 -> "Marquer le point B"; else -> "Ajouter un point" } else "Marquer une borne", fontWeight = FontWeight.Bold) }
            else
                Button({ vm.toggleRecording() }, Modifier.weight(2f).height(54.dp), enabled = !vm.closed,
                    colors = ButtonDefaults.buttonColors(containerColor = if (vm.recording) Warn else Accent)) {
                    Text(if (vm.recording) "Pause" else "Démarrer", fontWeight = FontWeight.Bold)
                }
            OutlinedButton({ vm.undo() }, Modifier.weight(1f).height(54.dp), enabled = vm.points.isNotEmpty()) { Text("Annuler") }
        }
        if (vm.closed && vm.measure == Measure.PARCELLE) {
            Spacer(Modifier.height(6.dp))
            Button(onMap, Modifier.fillMaxWidth().height(50.dp), colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)) { Text("Carte & rapport pro", fontWeight = FontWeight.Bold) }
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(6.dp)) {
            if (vm.measure == Measure.PARCELLE) OutlinedButton({ vm.toggleClose() }, Modifier.weight(1f),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = if (vm.nearStart && !vm.closed) Accent else LocalContentColor.current)) { Text(if (vm.closed) "Rouvrir" else "Fermer", fontSize = 12.sp) }
            OutlinedButton({ showSave = true }, Modifier.weight(1f), enabled = vm.points.size >= 3 && vm.measure == Measure.PARCELLE) { Text("Enreg.", fontSize = 12.sp) }
            OutlinedButton({ onExport("parcelle", vm.points.toList(), true) }, Modifier.weight(1f), enabled = vm.points.size >= 3 && vm.measure == Measure.PARCELLE) { Text("GeoJSON", fontSize = 12.sp) }
            OutlinedButton({ onExport("parcelle", vm.points.toList(), false) }, Modifier.weight(1f), enabled = vm.points.size >= 3 && vm.measure == Measure.PARCELLE) { Text("CSV", fontSize = 12.sp) }
            TextButton({ vm.reset() }, enabled = vm.points.isNotEmpty()) { Text("Effacer", color = Bad, fontSize = 12.sp) }
        }
    }

    if (showSettings) AlertDialog(onDismissRequest = { showSettings = false }, confirmButton = { TextButton({ showSettings = false }) { Text("OK") } },
        title = { Text("Réglages du filtre GPS") }, text = {
            Column {
                Text("Précision max acceptée : %.1f m".format(vm.maxAcc)); Slider(vm.maxAcc, { vm.maxAcc = it }, valueRange = 2f..20f)
                Text("Déplacement minimum : %.1f m".format(vm.minMove)); Slider(vm.minMove, { vm.minMove = it }, valueRange = 0.5f..5f)
                Text("Pas du mode Auto : %.0f m".format(vm.autoStep)); Slider(vm.autoStep, { vm.autoStep = it }, valueRange = 2f..30f)
            }
        })

    if (showSave) {
        var name by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { showSave = false },
            confirmButton = { TextButton({ vm.save(name); showSave = false }) { Text("Enregistrer") } },
            dismissButton = { TextButton({ showSave = false }) { Text("Annuler") } },
            title = { Text("Nom de la parcelle") },
            text = { OutlinedTextField(name, { name = it }, singleLine = true, placeholder = { Text("Ex : Cacaoyère nord") }) })
    }

    if (showParcels) AlertDialog(onDismissRequest = { showParcels = false }, confirmButton = { TextButton({ showParcels = false }) { Text("Fermer") } },
        title = { Text("Parcelles enregistrées") }, text = {
            if (vm.parcels.isEmpty()) Text("Aucune parcelle pour l'instant.")
            else LazyColumn(Modifier.heightIn(max = 380.dp)) {
                items(vm.parcels, key = { it.id }) { p ->
                    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                        Text(p.name, fontWeight = FontWeight.Bold)
                        Text("%s • %.3f ha • %.0f m".format(p.date, p.areaM2 / 10000, p.perimeterM), fontSize = 12.sp, color = Color.White.copy(.7f))
                        Row {
                            TextButton({ vm.load(p); showParcels = false }) { Text("Ouvrir", fontSize = 12.sp) }
                            TextButton({ onExport(p.name, p.points, true) }) { Text("GeoJSON", fontSize = 12.sp) }
                            TextButton({ onExport(p.name, p.points, false) }) { Text("CSV", fontSize = 12.sp) }
                            TextButton({ vm.delete(p) }) { Text("Suppr.", fontSize = 12.sp, color = Bad) }
                        }
                        HorizontalDivider()
                    }
                }
            }
        })
}

@Composable
fun GpsChip(vm: MainViewModel) {
    val acc = vm.fix?.acc
    val color = when {
        !vm.gpsOn -> Bad
        acc == null -> Warn
        acc <= vm.maxAcc -> Accent
        acc <= vm.maxAcc * 2 -> Warn
        else -> Bad
    }
    val label = when {
        !vm.gpsOn -> "GPS désactivé"
        acc == null -> "Recherche… ${vm.sats.first}/${vm.sats.second} sat"
        else -> "± %.1f m • %d/%d sat".format(acc, vm.sats.first, vm.sats.second)
    }
    Row(Modifier.clip(RoundedCornerShape(50)).background(Card).padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(9.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(6.dp)); Text(label, fontSize = 11.sp)
    }
}

@Composable
fun Stat(label: String, value: String, modifier: Modifier, big: Boolean = false) = Column(
    modifier.clip(RoundedCornerShape(14.dp)).background(Card).padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally
) {
    Text(label, fontSize = 10.sp, color = Color.White.copy(.6f))
    Text(value, fontSize = if (big) 18.sp else 14.sp, fontWeight = FontWeight.Bold, color = if (big) Accent else Color.White)
}

fun fmtDist(m: Double) = if (m >= 1000) "%.3f km".format(m / 1000) else "%.1f m".format(m)
