package com.linkshare.core

import android.net.Uri
import android.util.Base64
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.serialization.Serializable
import java.io.File
import java.net.Inet4Address
import java.net.NetworkInterface
import java.security.SecureRandom

/** Port HTTP (navigation, miniatures, lecture en streaming). */
const val PORT = 8765
/** Port de la « voie rapide » : transferts de fichiers en TCP brut, plusieurs flux en parallèle. */
const val FAST_PORT = 8766
const val BUF = 1024 * 1024

@Serializable data class DeviceInfo(val name: String, val version: Int = 2, val fastPort: Int = FAST_PORT)
@Serializable data class FileEntry(val name: String, val path: String, val isDir: Boolean, val size: Long, val modified: Long)
@Serializable data class Listing(val path: String, val entries: List<FileEntry>)
@Serializable data class AppEntry(
    val name: String, val pkg: String, val version: String,
    val size: Long, val isSystem: Boolean, val split: Boolean,
)

/** Présentation envoyée par le téléphone qui a scanné : l'autre peut alors parcourir ses fichiers à son tour. */
@Serializable data class Hello(val name: String, val port: Int, val fastPort: Int, val token: String, val host: String = "")

/** Fichiers d'une application installée (APK de base + APK partiels). */
@Serializable data class AppFile(val name: String, val path: String, val size: Long)

private val IMG = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp")
private val AV = setOf("mp4", "mkv", "webm", "3gp", "mov", "avi", "mp3", "m4a", "aac", "ogg", "opus", "wav", "flac")
fun FileEntry.ext() = name.substringAfterLast('.', "").lowercase()
fun FileEntry.isImage() = ext() in IMG
fun FileEntry.isAv() = ext() in AV

/**
 * Données du QR code : linkshare://host:port?token=…&name=…&fp=8766[&ssid=…&pass=…&sec=wpa3]
 * ssid / pass : point d'accès créé par l'appli ; le téléphone qui scanne s'y connecte tout seul.
 */
data class Connection(
    val host: String, val port: Int, val token: String, val name: String,
    val fastPort: Int = FAST_PORT, val ssid: String? = null, val pass: String? = null, val wpa3: Boolean = false,
) {
    companion object {
        fun parse(s: String): Connection? {
            val u = Uri.parse(s)
            if (u.scheme != "linkshare") return null
            val host = u.host ?: return null
            val port = u.port.takeIf { it > 0 } ?: return null
            val token = u.getQueryParameter("token") ?: return null
            return Connection(
                host, port, token, u.getQueryParameter("name") ?: host,
                fastPort = u.getQueryParameter("fp")?.toIntOrNull() ?: FAST_PORT,
                ssid = u.getQueryParameter("ssid")?.takeIf { it.isNotEmpty() },
                pass = u.getQueryParameter("pass"),
                wpa3 = u.getQueryParameter("sec") == "wpa3",
            )
        }
    }
}

data class ShareInfo(
    val host: String, val port: Int, val token: String, val name: String,
    val fastPort: Int = FAST_PORT, val ssid: String? = null, val pass: String? = null,
    val wpa3: Boolean = false, val band: String? = null,
) {
    fun toUri(): String {
        val b = StringBuilder("linkshare://$host:$port?token=$token&name=${Uri.encode(name)}&fp=$fastPort")
        if (ssid != null) {
            b.append("&ssid=").append(Uri.encode(ssid)).append("&pass=").append(Uri.encode(pass ?: ""))
            if (wpa3) b.append("&sec=wpa3")
        }
        return b.toString()
    }
}

object ShareState {
    val info = MutableStateFlow<ShareInfo?>(null)
    /** Nombre de requêtes HTTP en cours côté serveur. */
    val active = MutableStateFlow(0)
    fun newToken(): String {
        val b = ByteArray(24).also { SecureRandom().nextBytes(it) }
        return Base64.encodeToString(b, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    }
}

/** Racine partagée + protection contre ../ et les liens symboliques. */
class SharedRoot(val root: File) {
    private val canon = root.canonicalFile
    fun resolve(rel: String): File? {
        val f = File(canon, rel).canonicalFile
        return if (f == canon || f.path.startsWith(canon.path + File.separator)) f else null
    }
    fun relative(f: File): String = f.relativeTo(canon).path.replace(File.separatorChar, '/')
    val dir get() = canon
}

object NetUtil {
    private fun candidates(): List<Pair<String, String>> =
        runCatching { NetworkInterface.getNetworkInterfaces()?.toList().orEmpty() }.getOrDefault(emptyList())
            .filter { runCatching { it.isUp && !it.isLoopback }.getOrDefault(false) }
            .flatMap { ni ->
                ni.inetAddresses.toList().filterIsInstance<Inet4Address>()
                    .filter { it.isSiteLocalAddress }.map { ni.name to it.hostAddress!! }
            }

    /** IP locale (Wi-Fi, point d'accès ou groupe Wi-Fi Direct). */
    fun localIp(): String {
        val cands = candidates()
        val preferred = cands.firstOrNull { (n, _) ->
            n.startsWith("wlan") || n.startsWith("ap") || n.startsWith("swlan") || n.startsWith("p2p")
        }
        return (preferred ?: cands.firstOrNull())?.second ?: "0.0.0.0"
    }

    private fun isApName(n: String) =
        n.startsWith("swlan") || n.startsWith("ap") || n.startsWith("softap") || n == "wlan1" || n == "wlan2"

    /** IP de l'interface « point d'accès » (point d'accès local de l'appli ou partage de connexion du système). */
    fun apIp(): String? = candidates().firstOrNull { isApName(it.first) }?.second

    /** Vrai si une interface de point d'accès est active (souvent le partage de connexion du système). */
    fun apInterfaceUp(): Boolean =
        candidates().any { (n, _) -> n.startsWith("swlan") || n.startsWith("ap") || n.startsWith("softap") }
}
