package com.linkshare.core

import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import com.linkshare.client.RemoteClient
import com.linkshare.server.ShareService
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.first

/** Écrans d'une session connectée. */
enum class SessionScreen { PEERS, REMOTE, LOCAL, TRANSFERS }

/**
 * Connexion à double sens entre deux téléphones, indépendante de l'écran :
 * elle survit à l'écran éteint, à l'appli quittée et à la recréation de l'activité.
 *
 * 1. A affiche le QR (son point d'accès + son jeton).
 * 2. B scanne, rejoint le point d'accès, démarre son propre serveur, puis envoie « hello » avec SON jeton.
 * 3. A se connecte en retour à B : chacun peut parcourir, télécharger et envoyer chez l'autre.
 */
object Session {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var app: Context

    var client by mutableStateOf<RemoteClient?>(null); private set
    var peerName by mutableStateOf("")
    var screen by mutableStateOf(SessionScreen.PEERS)
    /** Texte affiché pendant la connexion (null = pas de connexion en cours). */
    var connecting by mutableStateOf<String?>(null); private set
    /** Messages courts (connexion, déconnexion…) à afficher en toast. */
    val events = MutableSharedFlow<String>(extraBufferCapacity = 16)

    val myName: String get() = Build.MODEL ?: "Téléphone"
    private var heartbeat: Job? = null

    fun init(ctx: Context) {
        if (!::app.isInitialized) app = ctx.applicationContext
        WifiJoin.onLost = { scope.launch { lost() } }
    }

    /** Démarre le service de session (serveurs HTTP + voie rapide) et attend qu'il soit prêt. */
    suspend fun startServer(ctx: Context, hotspot: Boolean = false): ShareInfo {
        init(ctx)
        val i = Intent(app, ShareService::class.java)
        if (hotspot) i.action = ShareService.ACTION_HOTSPOT
        ContextCompat.startForegroundService(app, i)
        return withTimeout(8_000) { ShareState.info.filterNotNull().first() }
    }

    /** Côté « scanner » : rejoint le point d'accès si besoin, puis se présente à l'autre téléphone. */
    suspend fun connect(ctx: Context, c: Connection) {
        init(ctx)
        connecting = "Connexion à ${c.name}…"
        try {
            if (c.ssid != null && !withContext(Dispatchers.IO) { WifiJoin.reachable(c.host, c.port) }) {
                // Le point d'accès de l'appli de l'autre téléphone n'est plus utile ici : on évite les conflits
                if (Hotspot.isActive()) Hotspot.stop()
                connecting = "Connexion au point d'accès « ${c.ssid} »… accepte la demande d'Android"
                if (!WifiJoin.join(app, c.ssid, c.pass ?: "", c.wpa3)) {
                    throw IllegalStateException("Connexion au point d'accès de ${c.name} impossible ou refusée")
                }
                connecting = "Connexion à ${c.name}…"
                var ok = false
                for (i in 0 until 25) {
                    ok = withContext(Dispatchers.IO) { WifiJoin.reachable(c.host, c.port, 1000) }
                    if (ok) break
                    delay(300)
                }
                if (!ok) throw IllegalStateException("${c.name} ne répond pas sur son point d'accès")
            }
            val me = startServer(app)
            val rc = RemoteClient(c)
            val info = try { rc.info() } catch (e: Exception) { rc.close(); throw e }
            // Le jeton de NOTRE serveur part chez l'autre : il pourra parcourir nos fichiers à son tour
            try { rc.hello(Hello(myName, me.port, me.fastPort, me.token, NetUtil.localIp())) } catch (e: Exception) { rc.close(); throw e }
            attach(rc, info.name)
        } catch (e: Exception) {
            if (client == null) WifiJoin.release(app)
            throw e
        } finally {
            connecting = null
        }
    }

    /** Côté « QR » : l'autre s'est présenté → on se connecte en retour à son serveur. */
    fun onHello(h: Hello, remote: String) {
        scope.launch {
            val host = remote.takeIf { it.isNotBlank() && it != "unknown" } ?: h.host
            val rc = RemoteClient(Connection(host, h.port, h.token, h.name, h.fastPort))
            var ok = false
            for (i in 0 until 4) {
                ok = runCatching { withTimeout(6_000) { rc.info() } }.isSuccess
                if (ok) break
                delay(700)
            }
            if (!ok) { rc.close(); events.tryEmit("${h.name} s'est connecté, mais ses fichiers ne sont pas joignables"); return@launch }
            attach(rc, h.name)
            events.tryEmit("${h.name} est connecté")
        }
    }

    private fun attach(rc: RemoteClient, name: String) {
        val old = client
        heartbeat?.cancel()
        client = rc
        peerName = name
        screen = SessionScreen.PEERS
        if (old != null && old !== rc) old.close()
        heartbeat = scope.launch {
            var fails = 0
            while (isActive) {
                delay(5_000)
                val ok = runCatching { withTimeout(7_000) { rc.info() } }.isSuccess
                fails = if (ok) 0 else fails + 1
                if (fails >= 4 && client === rc) { lost(); break }
            }
        }
    }

    /** Déconnexion volontaire : prévient l'autre téléphone, coupe le point d'accès et le service. */
    fun disconnect(notify: Boolean = true) {
        if (!::app.isInitialized) return
        val rc = client
        heartbeat?.cancel(); heartbeat = null
        client = null
        screen = SessionScreen.PEERS
        TransferHub.cancelAll()
        WifiJoin.release(app)
        if (rc != null) CoroutineScope(Dispatchers.IO).launch {
            if (notify) runCatching { withTimeout(1_500) { rc.bye() } }
            rc.close()
        }
        app.stopService(Intent(app, ShareService::class.java))
    }

    /** L'autre téléphone s'est déconnecté. */
    fun onBye() {
        scope.launch {
            val name = peerName
            if (client != null) {
                disconnect(notify = false)
                events.tryEmit("$name s'est déconnecté")
            }
        }
    }

    private fun lost() {
        if (client == null) return
        val name = peerName
        disconnect(notify = false)
        events.tryEmit("Connexion perdue avec $name")
    }
}
