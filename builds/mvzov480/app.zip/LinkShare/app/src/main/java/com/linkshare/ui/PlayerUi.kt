package com.linkshare.ui

import android.Manifest
import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.media.AudioManager
import android.net.Uri
import android.provider.Settings
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player as M3Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.linkshare.R
import com.linkshare.server.PlaybackService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.roundToInt

/** Contrôleur de la lecture en cours (renseigné par [Player]) : sert à arrêter la lecture quand on ferme le lecteur. */
internal object PlayerHost {
    var controller: MediaController? = null

    /** Arrête la lecture et retire la notification (fermeture du lecteur par l'utilisateur). */
    fun stop() {
        val c = controller ?: return
        c.stop()
        c.clearMediaItems()
    }
}

private fun MediaItem.uriString(): String? = (localConfiguration?.uri ?: requestMetadata.mediaUri)?.toString()

private fun fmtTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec) else String.format(Locale.US, "%d:%02d", m, sec)
}

/** Lecteur d'un seul fichier (ouverture depuis une autre appli). */
@Composable
internal fun Player(url: String, title: String = "", onClose: () -> Unit = {}) {
    Player(listOf(url), listOf(title), 0, onClose = onClose)
}

/**
 * Lecteur plein écran branché sur [PlaybackService] : la lecture continue en arrière-plan (écran éteint, appli quittée
 * avec Accueil), avec les commandes dans la barre de notification et sur l'écran verrouillé, vidéo comme audio.
 *
 * Commandes à l'écran (toucher = afficher / masquer, elles se masquent seules pendant la lecture d'une vidéo) :
 * retour, titre, bouton de **rotation** (portrait ↔ paysage, imposé par l'appli : il ne dépend ni du capteur ni du
 * réglage « rotation automatique » du téléphone), précédent / −10 s / lecture-pause / +10 s / suivant, barre de
 * progression, modes Aléatoire / Boucle / Tout.
 *
 * Gestes : balayage horizontal = média suivant / précédent ; balayage vertical = volume (moitié droite) ou luminosité
 * (moitié gauche) ; double toucher à gauche / à droite = −10 s / +10 s.
 *
 * [urls] forme une liste de lecture à partir de [startIndex]. [titles] sert à la notification et à l'écran de
 * verrouillage, [names] à l'affichage dans l'appli. [onIndexChange] est appelé quand le média en cours change.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun Player(
    urls: List<String>,
    titles: List<String>,
    startIndex: Int,
    names: List<String> = titles,
    onClose: () -> Unit = {},
    onIndexChange: (Int) -> Unit = {},
) {
    val ctx = LocalContext.current
    val activity = ctx.findActivity()
    val window = activity?.window
    val start = startIndex.coerceIn(0, (urls.size - 1).coerceAtLeast(0))
    var controller by remember { mutableStateOf<MediaController?>(null) }
    val audioOnly = remember {
        val name = names.getOrElse(start) { "" }.ifEmpty { titles.getOrElse(start) { "" } }
        val ext = if (name.contains('.')) name.substringAfterLast('.')
        else Uri.parse(urls[start]).lastPathSegment?.substringAfterLast('.', "").orEmpty()
        categoryOfExt(ext.lowercase()) == Category.MUSIC
    }
    val indexChanged by rememberUpdatedState(onIndexChange)
    val closeNow by rememberUpdatedState(onClose)

    // Modes de lecture (mémorisés) : Aléatoire, Boucle (le titre en cours), Tout (toute la liste)
    val prefs = remember { ctx.getSharedPreferences("linkshare", android.content.Context.MODE_PRIVATE) }
    var shuffle by remember { mutableStateOf(prefs.getBoolean("pl_shuffle", false)) }
    var repeat by remember { mutableIntStateOf(prefs.getInt("pl_repeat", M3Player.REPEAT_MODE_OFF)) }

    // État de lecture
    var current by remember { mutableIntStateOf(start) }
    var wantsPlay by remember { mutableStateOf(true) }
    var buffering by remember { mutableStateOf(false) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var scrubbing by remember { mutableStateOf(false) }
    var scrubValue by remember { mutableFloatStateOf(0f) }

    // Audio : image de fond tirée au hasard parmi les photos de l'appareil photo, différente à chaque titre
    val photos by produceState(emptyList<File>(), audioOnly) { if (audioOnly) value = withContext(Dispatchers.IO) { cameraPhotos(ctx) } }
    var trackTick by remember { mutableIntStateOf(0) }
    var bg by remember { mutableStateOf<File?>(null) }
    LaunchedEffect(photos, trackTick) {
        if (photos.isNotEmpty()) bg = photos.filter { it != bg }.randomOrNull() ?: photos.first()
    }

    // Retours visuels des gestes
    var volume by remember { mutableStateOf<Float?>(null) }
    var volumeTick by remember { mutableIntStateOf(0) }
    LaunchedEffect(volumeTick) { if (volumeTick > 0) { delay(900); volume = null } }
    var brightness by remember { mutableStateOf<Float?>(null) }
    var brightnessTick by remember { mutableIntStateOf(0) }
    LaunchedEffect(brightnessTick) { if (brightnessTick > 0) { delay(900); brightness = null } }
    var seekHud by remember { mutableStateOf<String?>(null) }
    var seekHudTick by remember { mutableIntStateOf(0) }
    LaunchedEffect(seekHudTick) { if (seekHudTick > 0) { delay(700); seekHud = null } }

    // Commandes visibles : l'audio les garde toujours, la vidéo les masque après quelques secondes de lecture
    var visible by remember { mutableStateOf(true) }
    var hideTick by remember { mutableIntStateOf(0) }
    val show = visible || audioOnly
    LaunchedEffect(visible, hideTick, wantsPlay, scrubbing) {
        if (visible && wantsPlay && !scrubbing && !audioOnly) { delay(3500); visible = false }
    }
    // Position et durée, rafraîchies tant que la barre est visible
    LaunchedEffect(controller, show) {
        val c = controller ?: return@LaunchedEffect
        while (show) {
            if (!scrubbing) {
                position = c.currentPosition.coerceAtLeast(0)
                duration = c.duration.takeIf { it != C.TIME_UNSET && it > 0 } ?: 0L
            }
            delay(250)
        }
    }

    // ── Rotation : imposée par l'appli (ignore le capteur et le réglage « rotation automatique »)
    val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    fun rotate() {
        activity?.requestedOrientation =
            if (isLandscape) ActivityInfo.SCREEN_ORIENTATION_PORTRAIT else ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        hideTick++
    }
    // En quittant le lecteur, l'appli reprend l'orientation normale du téléphone
    DisposableEffect(Unit) {
        onDispose { activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED }
    }
    // Vidéo : plein écran sans barres système (elles reviennent d'un balayage depuis le bord)
    DisposableEffect(audioOnly) {
        val w = window
        if (audioOnly || w == null) return@DisposableEffect onDispose {}
        val ic = WindowCompat.getInsetsController(w, w.decorView)
        ic.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        ic.hide(WindowInsetsCompat.Type.systemBars())
        onDispose { ic.show(WindowInsetsCompat.Type.systemBars()) }
    }
    // La luminosité réglée au balayage ne vaut que pour le lecteur : on rend la main au système en le quittant
    DisposableEffect(Unit) {
        onDispose { window?.let { w -> w.attributes = w.attributes.apply { screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE } } }
    }

    // Android 13+ : sans cette autorisation, la notification de lecture n'apparaît pas
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) { if (needsNotifPermission(ctx)) notif.launch(Manifest.permission.POST_NOTIFICATIONS) }
    BackHandler { closeNow() }

    DisposableEffect(urls) {
        var disposed = false
        var attached: MediaController? = null
        var listener: M3Player.Listener? = null
        val token = SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        val future = MediaController.Builder(ctx, token).buildAsync()
        future.addListener({
            if (disposed) return@addListener
            val c = runCatching { future.get() }.getOrNull() ?: return@addListener
            // Même liste déjà en cours (activité recréée, retour depuis l'écran d'accueil) : on se rattache
            // sans relancer la lecture, au lieu de repartir de zéro.
            val already = c.mediaItemCount == urls.size &&
                (0 until c.mediaItemCount).all { c.getMediaItemAt(it).uriString() == urls[it] }
            if (!already) {
                val items = urls.mapIndexed { i, u ->
                    MediaItem.Builder()
                        .setUri(u)
                        .setRequestMetadata(MediaItem.RequestMetadata.Builder().setMediaUri(Uri.parse(u)).build())
                        .setMediaMetadata(MediaMetadata.Builder().setTitle(titles.getOrElse(i) { "" }).build())
                        .build()
                }
                c.setMediaItems(items, start, C.TIME_UNSET)
                c.prepare(); c.playWhenReady = true
            } else indexChanged(c.currentMediaItemIndex)
            c.shuffleModeEnabled = shuffle
            c.repeatMode = repeat
            current = c.currentMediaItemIndex
            wantsPlay = c.playWhenReady
            buffering = c.playbackState == M3Player.STATE_BUFFERING
            val l = object : M3Player.Listener {
                override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                    current = c.currentMediaItemIndex
                    indexChanged(c.currentMediaItemIndex); trackTick++
                }
                override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) { shuffle = shuffleModeEnabled }
                override fun onRepeatModeChanged(repeatMode: Int) { repeat = repeatMode }
                override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) { wantsPlay = playWhenReady }
                override fun onPlaybackStateChanged(playbackState: Int) { buffering = playbackState == M3Player.STATE_BUFFERING }
            }
            c.addListener(l)
            attached = c; listener = l
            PlayerHost.controller = c
            controller = c
        }, ContextCompat.getMainExecutor(ctx))
        onDispose {
            disposed = true
            val a = attached; val l = listener
            if (a != null && l != null) a.removeListener(l)
            if (PlayerHost.controller === controller) PlayerHost.controller = null
            controller = null
            MediaController.releaseFuture(future)
        }
    }

    fun seekBy(deltaMs: Long) {
        val c = controller ?: return
        var to = (c.currentPosition + deltaMs).coerceAtLeast(0)
        if (c.duration != C.TIME_UNSET && c.duration > 0) to = to.coerceAtMost(c.duration)
        c.seekTo(to)
        position = to
        seekHud = if (deltaMs > 0) "+${deltaMs / 1000} s" else "−${-deltaMs / 1000} s"
        seekHudTick++
    }
    fun togglePlay() {
        val c = controller ?: return
        if (c.playWhenReady) c.pause() else {
            // Fin de liste atteinte : on repart du début plutôt que de ne rien faire
            if (c.playbackState == M3Player.STATE_ENDED) c.seekToDefaultPosition(0)
            c.play()
        }
        hideTick++
    }
    fun previous() {
        val c = controller ?: return
        if (c.currentPosition > 3000 || !c.hasPreviousMediaItem()) c.seekTo(0) else c.seekToPreviousMediaItem()
        hideTick++
    }
    fun next() {
        val c = controller ?: return
        if (c.hasNextMediaItem()) c.seekToNextMediaItem()
        hideTick++
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (audioOnly) {
            // Fond du lecteur audio : photo au hasard (logo tant qu'aucune photo n'est trouvée), assombrie pour garder les commandes lisibles
            Crossfade(bg, label = "fond") { f ->
                if (f != null) AsyncImage(model = f, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                else Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
                    Image(painterResource(R.drawable.ic_logo), null, Modifier.size(140.dp))
                }
            }
            Box(Modifier.fillMaxSize().background(Color(0x66000000)))
        }
        AndroidView(
            factory = { c ->
                PlayerView(c).apply {
                    useController = false // commandes dessinées par l'appli (voir plus bas)
                    keepScreenOn = !audioOnly
                    if (audioOnly) {
                        setShutterBackgroundColor(android.graphics.Color.TRANSPARENT) // laisse voir la photo de fond
                        @Suppress("DEPRECATION") setUseArtwork(false)
                    } else {
                        setShutterBackgroundColor(android.graphics.Color.BLACK)
                        defaultArtwork = ContextCompat.getDrawable(c, R.drawable.ic_logo)
                    }
                    attachGestures(
                        this, window,
                        onVolume = { v -> volume = v; volumeTick++ },
                        onBrightness = { v -> brightness = v; brightnessTick++ },
                        onTap = { visible = !visible; hideTick++ },
                        onDoubleTap = { forward -> seekBy(if (forward) 10_000L else -10_000L) },
                    )
                }
            },
            update = { it.player = controller },
            modifier = Modifier.fillMaxSize(),
        )

        AnimatedVisibility(
            visible = show, modifier = Modifier.fillMaxSize(),
            enter = fadeIn(tween(150)), exit = fadeOut(tween(220)),
        ) {
            Box(Modifier.fillMaxSize()) {
                // Voiles dégradés : gardent les commandes lisibles sur n'importe quelle image
                Box(
                    Modifier.align(Alignment.TopCenter).fillMaxWidth().height(120.dp)
                        .background(Brush.verticalGradient(listOf(Color(0xCC000000), Color.Transparent)))
                )
                Box(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(190.dp)
                        .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xE6000000))))
                )

                // ── Haut : retour, titre, rotation
                Row(
                    Modifier.align(Alignment.TopCenter).fillMaxWidth()
                        .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Top + WindowInsetsSides.Horizontal))
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    RoundBtn(Ic.Back, "Retour") { closeNow() }
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text(
                            names.getOrElse(current) { "" }, color = Color.White, fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                        if (urls.size > 1) Text("${current + 1} / ${urls.size}", color = Color(0xCCFFFFFF), fontSize = 11.sp)
                    }
                    if (!audioOnly) RoundBtn(
                        if (isLandscape) Ic.Phone else Ic.PhoneLandscape,
                        if (isLandscape) "Passer en portrait" else "Passer en paysage",
                    ) { rotate() }
                }

                // ── Centre : précédent, −10 s, lecture / pause, +10 s, suivant
                Row(
                    Modifier.align(Alignment.Center),
                    horizontalArrangement = Arrangement.spacedBy(18.dp), verticalAlignment = Alignment.CenterVertically,
                ) {
                    val multi = urls.size > 1
                    RoundBtn(Ic.SkipPrev, "Précédent", size = 46.dp, bg = Color.Transparent, modifier = Modifier.alpha(if (multi) 1f else 0.35f)) { previous() }
                    SeekBtn("10", forward = false) { seekBy(-10_000L); hideTick++ }
                    Box(
                        Modifier.size(72.dp).clip(CircleShape).background(LS.Blue).clickable { togglePlay() },
                        contentAlignment = Alignment.Center,
                    ) {
                        if (buffering) CircularProgressIndicator(Modifier.size(34.dp), color = LS.OnBlue, strokeWidth = 3.dp)
                        else Icon(if (wantsPlay) Ic.Pause else Ic.Play, if (wantsPlay) "Pause" else "Lecture", Modifier.size(38.dp), tint = LS.OnBlue)
                    }
                    SeekBtn("10", forward = true) { seekBy(10_000L); hideTick++ }
                    RoundBtn(Ic.SkipNext, "Suivant", size = 46.dp, bg = Color.Transparent, modifier = Modifier.alpha(if (multi) 1f else 0.35f)) { next() }
                }

                // ── Bas : progression, modes de lecture
                Column(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                        .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Bottom + WindowInsetsSides.Horizontal))
                        .padding(horizontal = 18.dp).padding(bottom = 8.dp),
                ) {
                    val dur = duration.coerceAtLeast(1L)
                    val shown = if (scrubbing) (scrubValue * dur).toLong() else position
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(fmtTime(shown), color = Color.White, fontSize = 12.sp)
                        Spacer(Modifier.weight(1f))
                        Text(if (duration > 0) fmtTime(duration) else "--:--", color = Color(0xCCFFFFFF), fontSize = 12.sp)
                    }
                    Slider(
                        value = if (scrubbing) scrubValue else (position.toFloat() / dur).coerceIn(0f, 1f),
                        onValueChange = { scrubbing = true; scrubValue = it; hideTick++ },
                        onValueChangeFinished = {
                            val to = (scrubValue * dur).toLong()
                            controller?.seekTo(to)
                            position = to
                            scrubbing = false
                        },
                        enabled = duration > 0,
                        colors = SliderDefaults.colors(
                            thumbColor = LS.Blue, activeTrackColor = LS.Blue, inactiveTrackColor = Color(0x44FFFFFF),
                            disabledThumbColor = Color(0x66FFFFFF), disabledActiveTrackColor = Color(0x44FFFFFF),
                            disabledInactiveTrackColor = Color(0x22FFFFFF),
                        ),
                    )
                    Row(
                        Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        ModeBtn(Ic.Shuffle, "Aléatoire", shuffle) {
                            shuffle = !shuffle
                            controller?.shuffleModeEnabled = shuffle
                            prefs.edit().putBoolean("pl_shuffle", shuffle).apply()
                            Toast.makeText(ctx, "Aléatoire " + if (shuffle) "activé" else "désactivé", Toast.LENGTH_SHORT).show()
                            hideTick++
                        }
                        Spacer(Modifier.width(14.dp))
                        ModeBtn(Ic.RepeatOne, "Boucle", repeat == M3Player.REPEAT_MODE_ONE) {
                            repeat = if (repeat == M3Player.REPEAT_MODE_ONE) M3Player.REPEAT_MODE_OFF else M3Player.REPEAT_MODE_ONE
                            controller?.repeatMode = repeat
                            prefs.edit().putInt("pl_repeat", repeat).apply()
                            Toast.makeText(ctx, "Boucle " + if (repeat == M3Player.REPEAT_MODE_ONE) "activée" else "désactivée", Toast.LENGTH_SHORT).show()
                            hideTick++
                        }
                        Spacer(Modifier.width(14.dp))
                        ModeBtn(Ic.Repeat, "Tout", repeat == M3Player.REPEAT_MODE_ALL) {
                            repeat = if (repeat == M3Player.REPEAT_MODE_ALL) M3Player.REPEAT_MODE_OFF else M3Player.REPEAT_MODE_ALL
                            controller?.repeatMode = repeat
                            prefs.edit().putInt("pl_repeat", repeat).apply()
                            Toast.makeText(ctx, "Répéter tout " + if (repeat == M3Player.REPEAT_MODE_ALL) "activé" else "désactivé", Toast.LENGTH_SHORT).show()
                            hideTick++
                        }
                    }
                }
            }
        }

        seekHud?.let { t ->
            Text(
                t, Modifier.align(Alignment.Center).offset(y = (-96).dp).clip(RoundedCornerShape(18.dp))
                    .background(Color(0xCC000000)).padding(horizontal = 16.dp, vertical = 8.dp),
                color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
            )
        }
        volume?.let { LevelHud(Ic.Volume, it, Modifier.align(Alignment.Center)) }
        brightness?.let { LevelHud(Ic.Brightness, it, Modifier.align(Alignment.Center)) }
    }
}

@Composable
private fun RoundBtn(
    icon: ImageVector, desc: String, size: Dp = 44.dp, bg: Color = Color(0x66000000),
    modifier: Modifier = Modifier, onClick: () -> Unit,
) {
    Box(
        modifier.size(size).clip(CircleShape).background(bg).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, desc, Modifier.size(size * 0.5f), tint = Color.White) }
}

/** Saut de 10 s : flèche + « 10 ». */
@Composable
private fun SeekBtn(label: String, forward: Boolean, onClick: () -> Unit) {
    Column(
        Modifier.size(50.dp).clip(CircleShape).clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
    ) {
        Icon(if (forward) Ic.Chevron else Ic.Back, if (forward) "Avancer de 10 secondes" else "Reculer de 10 secondes", Modifier.size(22.dp), tint = Color.White)
        Text(label + " s", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** Bouton de mode (Aléatoire / Boucle / Tout) : rond, accentué quand il est actif. */
@Composable
private fun ModeBtn(icon: ImageVector, desc: String, on: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(42.dp).clip(CircleShape).background(if (on) LS.Blue else Color(0x66000000)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, desc, Modifier.size(20.dp), tint = if (on) LS.OnBlue else Color.White) }
}

/**
 * Gestes sur l'écran du lecteur (les boutons et la barre de progression gardent la priorité, ils reçoivent le toucher en premier) :
 * toucher = commandes ; double toucher = ±10 s (moitié droite / gauche) ; balayage horizontal = média suivant / précédent ;
 * balayage vertical = volume (moitié droite) ou luminosité de l'écran (moitié gauche).
 */
@SuppressLint("ClickableViewAccessibility")
private fun attachGestures(
    pv: PlayerView, window: android.view.Window?,
    onVolume: (Float) -> Unit, onBrightness: (Float) -> Unit,
    onTap: () -> Unit, onDoubleTap: (forward: Boolean) -> Unit,
) {
    val ctx = pv.context
    val audio = ctx.getSystemService(AudioManager::class.java)
    val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    val swipeDistance = ctx.resources.displayMetrics.density * 72f
    val taps = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true
        override fun onSingleTapConfirmed(e: MotionEvent): Boolean { onTap(); return true }
        override fun onDoubleTap(e: MotionEvent): Boolean { onDoubleTap(e.x > pv.width / 2f); return true }
    })
    pv.setOnTouchListener(object : View.OnTouchListener {
        var x0 = 0f
        var y0 = 0f
        var mode = 0 // 0 = pas encore décidé, 1 = horizontal (changer de média), 2 = vertical (volume), 3 = vertical (luminosité)
        var bri0 = 0.5f
        var maxVol = 1
        var vol0 = 0f
        var lastStep = -1

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            taps.onTouchEvent(e)
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    x0 = e.x; y0 = e.y; mode = 0
                    maxVol = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                    lastStep = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
                    vol0 = lastStep.toFloat() / maxVol
                    // Luminosité de départ : celle de la fenêtre, sinon celle du système
                    bri0 = window?.attributes?.screenBrightness?.takeIf { it >= 0f }
                        ?: (Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128) / 255f)
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.x - x0
                    val dy = e.y - y0
                    if (mode == 0 && hypot(dx, dy) > slop) mode = if (abs(dx) > abs(dy)) 1 else if (x0 < v.width / 2f) 3 else 2
                    if (mode == 3 && window != null) {
                        // Un balayage sur toute la hauteur de l'écran ≈ 130 % de la luminosité (minimum 1 % : jamais noir)
                        val level = (bri0 - dy / v.height.coerceAtLeast(1) * 1.3f).coerceIn(0.01f, 1f)
                        window.attributes = window.attributes.apply { screenBrightness = level }
                        onBrightness(level)
                    }
                    if (mode == 2) {
                        // Un balayage sur toute la hauteur de l'écran ≈ 130 % du volume
                        val level = (vol0 - dy / v.height.coerceAtLeast(1) * 1.3f).coerceIn(0f, 1f)
                        val step = (level * maxVol).roundToInt()
                        if (step != lastStep) {
                            lastStep = step
                            audio.setStreamVolume(AudioManager.STREAM_MUSIC, step, 0)
                        }
                        onVolume(step.toFloat() / maxVol)
                    }
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    val dx = e.x - x0
                    if (mode == 1 && abs(dx) > swipeDistance) {
                        val p = pv.player
                        if (p != null) {
                            if (dx < 0) { if (p.hasNextMediaItem()) p.seekToNextMediaItem() }
                            else if (p.hasPreviousMediaItem()) p.seekToPreviousMediaItem()
                        }
                    }
                    mode = 0
                    return true
                }
                MotionEvent.ACTION_CANCEL -> { mode = 0; return true }
            }
            return false
        }
    })
}

@Composable
private fun LevelHud(icon: ImageVector, level: Float, modifier: Modifier = Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(18.dp)).background(Color(0xCC000000)).padding(horizontal = 22.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, null, Modifier.size(28.dp), tint = Color.White)
        Spacer(Modifier.height(10.dp))
        LinearProgressIndicator(
            progress = { level }, modifier = Modifier.width(120.dp),
            color = LS.Blue, trackColor = Color.White.copy(alpha = 0.25f),
        )
        Spacer(Modifier.height(8.dp))
        Text("${(level * 100).roundToInt()} %", color = Color.White, fontSize = 13.sp)
    }
}
