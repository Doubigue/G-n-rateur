package com.example.mydm.ui

import android.view.ViewGroup
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import android.webkit.CookieManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import com.example.mydm.browser.BrowserManager
import com.example.mydm.browser.BrowserTab
import com.example.mydm.browser.EpisodeLink
import com.example.mydm.browser.PageScanner
import com.example.mydm.core.FileChooserBridge
import com.example.mydm.core.Prefs
import com.example.mydm.downloader.DownloadService
import kotlinx.coroutines.launch
import org.json.JSONTokener

// ───────────── Navigateur (avec onglets) ─────────────
@Composable
fun BrowserScreen(manager: BrowserManager, onOpenSettings: () -> Unit) {
    val tab = manager.tabs.getOrNull(manager.currentIndex) ?: return
    var address by remember(tab.id) { mutableStateOf(tab.url) }
    LaunchedEffect(tab.id, tab.url) { address = tab.url }
    var showSheet by remember { mutableStateOf(false) }
    var showTabs by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var showConsole by remember { mutableStateOf(false) }
    var series by remember { mutableStateOf<Pair<List<EpisodeLink>, String>?>(null) }
    val ctx = LocalContext.current; val app = appInstance(); val scope = rememberCoroutineScope()

    // Recherche par photo : la photo choisie est envoyée automatiquement au bouton « importer » du moteur
    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) { FileChooserBridge.pendingImage = uri; manager.newTab(Prefs.imageEngine.url) }
    }

    // Télécharge la page (HTML, CSS, JS, images…) + la console en ZIP
    fun archiveSite() {
        val web = tab.web
        val pageUrl = web.url ?: return
        if (!pageUrl.startsWith("http")) { Toast.makeText(ctx, "Ouvrez d'abord une page web", Toast.LENGTH_SHORT).show(); return }
        web.evaluateJavascript("document.documentElement.outerHTML") { raw ->
            val dom = runCatching { JSONTokener(raw).nextValue() as? String }.getOrNull().orEmpty()
            val log = tab.console.joinToString("\n") { "[${it.level}] ${it.message} (${it.source})" }
            scope.launch {
                val id = app.downloadEngine.enqueueSite(pageUrl, tab.title, web.settings.userAgentString, CookieManager.getInstance().getCookie(pageUrl), dom, log)
                DownloadService.start(ctx, id)
                Toast.makeText(ctx, "Archive du site ajoutée aux téléchargements", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Série : cherche les épisodes dans la page affichée (instantané, sans recharger)
    fun openSeries() {
        scope.launch {
            val eps = PageScanner.episodesOf(tab.web, tab.web.url ?: tab.url)
            if (eps.size >= 2) series = eps to tab.title
            else Toast.makeText(ctx, "Aucune liste d'épisodes détectée sur cette page", Toast.LENGTH_SHORT).show()
        }
    }

    fun go() { tab.web.loadUrl(Prefs.resolveInput(address)) }

    // Retour : fermer le sélecteur → page précédente → fermer l'onglet (s'il y en a plusieurs)
    val canGoBack = remember(tab.id, tab.url) { tab.web.canGoBack() }
    BackHandler(enabled = showTabs || canGoBack || manager.tabs.size > 1) {
        when {
            showTabs -> showTabs = false
            tab.web.canGoBack() -> tab.web.goBack()
            else -> manager.close(manager.currentIndex)
        }
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                BarButton("◀") { if (tab.web.canGoBack()) tab.web.goBack() }
                OutlinedTextField(address, { address = it }, Modifier.weight(1f), singleLine = true, shape = RoundedCornerShape(24.dp),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = { go() }))
                BarButton(if (tab.progress in 0..99) "✕" else "⟳") {
                    if (tab.progress in 0..99) tab.web.stopLoading() else tab.web.reload()
                }
                // Compteur d'onglets
                Box(Modifier.size(40.dp).clickable { tab.captureThumb(); showTabs = true }, contentAlignment = Alignment.Center) {
                    Box(Modifier.size(24.dp).border(2.dp, Accent, RoundedCornerShape(6.dp)), contentAlignment = Alignment.Center) {
                        Text("${manager.tabs.size}", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Box {
                    BarButton("⋮") { menu = true }
                    DropdownMenu(menu, { menu = false }) {
                        DropdownMenuItem({ Text("Nouvel onglet") }, { menu = false; manager.newTab() })
                        DropdownMenuItem({ Text("Fermer l'onglet") }, { menu = false; manager.close(manager.currentIndex) })
                        DropdownMenuItem({ Text("Page suivante") }, { menu = false; if (tab.web.canGoForward()) tab.web.goForward() })
                        DropdownMenuItem({ Text("📺 Série : télécharger tous les épisodes") }, { menu = false; openSeries() })
                        DropdownMenuItem({ Text("🔎 Analyser cette page (sans lire)") }, { menu = false; showSheet = true })
                        DropdownMenuItem({ Text("⬇ Télécharger le site (ZIP)") }, { menu = false; archiveSite() })
                        DropdownMenuItem({ Text("Console (${tab.console.size})") }, { menu = false; showConsole = true })
                        DropdownMenuItem({ Text("📷 Rechercher par photo") }, { menu = false; pickPhoto.launch("image/*") })
                        DropdownMenuItem({ Text("Paramètres") }, { menu = false; onOpenSettings() })
                    }
                }
            }
            if (tab.progress in 0..99) LinearProgressIndicator({ tab.progress / 100f }, Modifier.fillMaxWidth().height(2.dp))

            Box(Modifier.weight(1f)) {
                // key = id : chaque onglet réattache sa propre WebView
                key(tab.id) {
                    AndroidView({ (tab.web.parent as? ViewGroup)?.removeView(tab.web); tab.web }, Modifier.fillMaxSize())
                }
                // Pastille « téléchargeur » (médias de l'onglet courant)
                Row(
                    Modifier.align(Alignment.BottomEnd).padding(16.dp)
                        .clip(RoundedCornerShape(50)).background(Accent)
                        .clickable { showSheet = true }
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("⬇", color = OnAccent, fontSize = 16.sp)
                    Spacer(Modifier.width(8.dp))
                    Text(if (tab.found.isEmpty()) "Télécharger" else "${tab.found.size} média(s)", color = OnAccent, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
        if (showTabs) TabSwitcher(manager) { showTabs = false }
    }
    if (showConsole) ConsoleSheet(tab) { showConsole = false }
    if (showSheet) DownloadSheet(tab.found, tab.web.url ?: address, { showSheet = false }) { eps, t -> series = eps to t }
    series?.let { (eps, t) -> SeriesSheet(eps, t) { series = null } }
}

@Composable
private fun BarButton(label: String, onClick: () -> Unit) =
    Box(Modifier.size(40.dp).clip(RoundedCornerShape(50)).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(label, color = Accent, fontSize = 18.sp)
    }

// ───────────── Sélecteur d'onglets ─────────────
@Composable
private fun TabSwitcher(manager: BrowserManager, onClose: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 12.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Onglets (${manager.tabs.size})", color = Txt, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton({ manager.newTab(); onClose() }) { Text("＋ Nouvel onglet") }
            TextButton(onClose) { Text("OK") }
        }
        LazyVerticalGrid(GridCells.Fixed(2), contentPadding = PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            itemsIndexed(manager.tabs, key = { _, t -> t.id }) { i, t ->
                val selected = i == manager.currentIndex
                Column(
                    Modifier.fillMaxWidth().glass()
                        .border(if (selected) 2.dp else 0.dp, if (selected) Accent else Color.Transparent, RoundedCornerShape(20.dp))
                        .clickable { manager.select(i); onClose() }
                ) {
                    Row(Modifier.padding(start = 12.dp, top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(t.title.ifBlank { t.url }, color = Txt, fontSize = 12.sp, maxLines = 1,
                            overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        Box(Modifier.size(36.dp).clickable { manager.close(i) }, contentAlignment = Alignment.Center) {
                            Text("✕", color = Muted, fontSize = 14.sp)
                        }
                    }
                    Box(Modifier.fillMaxWidth().height(130.dp).background(Color(0x22FFFFFF)), contentAlignment = Alignment.Center) {
                        val th = t.thumb
                        if (th != null) Image(th, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, alignment = Alignment.TopCenter)
                        else Text(t.url.substringAfter("://").substringBefore('/').ifBlank { "Nouvel onglet" },
                            color = Muted, fontSize = 12.sp, modifier = Modifier.padding(8.dp), maxLines = 2)
                    }
                }
            }
        }
    }
}


// ───────────── Console de la page ─────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ConsoleSheet(tab: BrowserTab, onDismiss: () -> Unit) {
    val clip = LocalClipboardManager.current
    var expr by remember { mutableStateOf("") }
    fun run() {
        val e = expr.trim(); if (e.isEmpty()) return
        tab.console.add(com.example.mydm.browser.ConsoleLine("INPUT", "> $e", ""))
        tab.web.evaluateJavascript(e) { r -> tab.console.add(com.example.mydm.browser.ConsoleLine("RESULT", r ?: "undefined", "")) }
        expr = ""
    }
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true), containerColor = Bg) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Console", color = Txt, fontSize = 20.sp, modifier = Modifier.weight(1f))
                TextButton({ tab.console.clear() }) { Text("Effacer") }
                TextButton({ clip.setText(AnnotatedString(tab.console.joinToString("\n") { "[${it.level}] ${it.message} ${it.source}" })) }) { Text("Copier") }
                TextButton({
                    tab.web.evaluateJavascript("document.documentElement.outerHTML") { raw ->
                        val html = runCatching { JSONTokener(raw).nextValue() as? String }.getOrNull().orEmpty()
                        clip.setText(AnnotatedString(html))
                    }
                }) { Text("HTML") }
            }
            LazyColumn(Modifier.fillMaxWidth().heightIn(max = 420.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                if (tab.console.isEmpty()) item { Text("Aucun message. Les console.log, erreurs JS et avertissements de la page s'affichent ici.", color = Muted, fontSize = 12.sp) }
                items(tab.console.reversed()) { l ->
                    val c = when (l.level) { "ERROR" -> Danger; "WARNING" -> Color(0xFFFFD180); "INPUT" -> Accent; "RESULT" -> Color(0xFF80D8FF); else -> Txt }
                    Text(l.message + (if (l.source.isNotBlank() && l.source != ":0") "   ${l.source}" else ""), color = c, fontSize = 12.sp)
                }
            }
            OutlinedTextField(expr, { expr = it }, Modifier.fillMaxWidth().padding(vertical = 8.dp), singleLine = true,
                placeholder = { Text("Exécuter du JavaScript…") },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go), keyboardActions = KeyboardActions(onGo = { run() }))
            Spacer(Modifier.height(16.dp))
        }
    }
}
