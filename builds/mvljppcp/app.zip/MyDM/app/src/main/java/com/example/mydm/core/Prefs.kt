package com.example.mydm.core

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray

enum class SearchEngine(val label: String, val template: String) {
    GOOGLE("Google", "https://www.google.com/search?q="),
    DUCKDUCKGO("DuckDuckGo", "https://duckduckgo.com/?q="),
    BING("Bing", "https://www.bing.com/search?q="),
    ECOSIA("Ecosia", "https://www.ecosia.org/search?q=")
}

/** Moteurs de recherche par photo : la page s'ouvre et la photo choisie est envoyée au bouton « importer ». */
enum class ImageEngine(val label: String, val url: String) {
    LENS("Google Lens", "https://lens.google.com/"),
    BING("Bing Visual", "https://www.bing.com/visualsearch"),
    TINEYE("TinEye", "https://tineye.com/"),
    YANDEX("Yandex", "https://yandex.com/images/")
}

enum class ThemeMode(val label: String) { SYSTEM("Auto"), DARK("Sombre"), AMOLED("Noir pur"), LIGHT("Clair") }

enum class AccentColor(val label: String, val argb: Long) {
    VIOLET("Violet", 0xFF8B7CFF), CYAN("Cyan", 0xFF22D3EE), ROSE("Rose", 0xFFFF6B9D),
    VERT("Vert", 0xFF3DDC97), ORANGE("Orange", 0xFFFFA24C), BLEU("Bleu", 0xFF4C8DFF)
}

/** Réglages de l'application (SharedPreferences + état Compose, donc l'UI se met à jour seule). */
object Prefs {
    const val DEFAULT_HOME = "https://www.google.com"
    lateinit var sp: SharedPreferences; private set

    // ── Navigateur
    var homeUrl by mutableStateOf(DEFAULT_HOME); private set
    var searchEngine by mutableStateOf(SearchEngine.GOOGLE); private set
    var imageEngine by mutableStateOf(ImageEngine.LENS); private set
    var desktopMode by mutableStateOf(false); private set
    var blockPopups by mutableStateOf(false); private set
    var restoreTabs by mutableStateOf(true); private set
    var jsEnabled by mutableStateOf(true); private set
    var loadImages by mutableStateOf(true); private set
    var textZoom by mutableIntStateOf(100); private set
    var blockAds by mutableStateOf(false); private set
    var externalNewTab by mutableStateOf(true); private set
    // ── Téléchargements
    var maxSegments by mutableIntStateOf(8); private set
    var maxParallel by mutableIntStateOf(3); private set
    var wifiOnly by mutableStateOf(false); private set
    var speedLimitKbps by mutableIntStateOf(0); private set     // 0 = illimité (par téléchargement)
    var rootFolder by mutableStateOf("MyDM"); private set
    var notifLines by mutableIntStateOf(5); private set
    var notifyDone by mutableStateOf(true); private set
    // ── Détection
    var detectVideo by mutableStateOf(true); private set
    var detectAudio by mutableStateOf(true); private set
    var detectFiles by mutableStateOf(true); private set
    // ── Apparence
    var themeMode by mutableStateOf(ThemeMode.DARK); private set
    var accent by mutableStateOf(AccentColor.VIOLET); private set
    // ── Analyse de pages / séries
    var prefetchLinks by mutableStateOf(true); private set     // pré-analyse YouTube/Facebook/TikTok dès l'ouverture de la page
    var clipboardWatch by mutableStateOf(true); private set    // propose les liens copiés
    var scanSeconds by mutableIntStateOf(8); private set       // durée max d'analyse d'une page (sans la lire)
    var scanEmbeds by mutableIntStateOf(3); private set        // lecteurs intégrés (iframes) analysés par page
    var seriesParallel by mutableIntStateOf(2); private set    // épisodes analysés en même temps
    var seriesFolders by mutableStateOf(true); private set     // un dossier par série
    // ── Lecteur
    var autoPlayNext by mutableStateOf(true); private set
    var resumePlayback by mutableStateOf(true); private set
    var keepScreenOn by mutableStateOf(true); private set
    var confirmDelete by mutableStateOf(true); private set
    // ── Moteur yt-dlp
    var autoUpdateYt by mutableStateOf(true); private set
    // ── Développeur
    var captureConsole by mutableStateOf(true); private set
    var siteMaxMb by mutableIntStateOf(100); private set

    fun init(ctx: Context) {
        sp = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
        homeUrl = sp.getString("home", DEFAULT_HOME) ?: DEFAULT_HOME
        searchEngine = runCatching { SearchEngine.valueOf(sp.getString("engine", "GOOGLE")!!) }.getOrDefault(SearchEngine.GOOGLE)
        imageEngine = runCatching { ImageEngine.valueOf(sp.getString("imgEngine", "LENS")!!) }.getOrDefault(ImageEngine.LENS)
        desktopMode = sp.getBoolean("desktop", false)
        blockPopups = sp.getBoolean("blockPopups", false)
        restoreTabs = sp.getBoolean("restoreTabs", true)
        jsEnabled = sp.getBoolean("js", true)
        loadImages = sp.getBoolean("images", true)
        textZoom = sp.getInt("textZoom", 100)
        blockAds = sp.getBoolean("blockAds", false)
        externalNewTab = sp.getBoolean("externalNewTab", true)
        maxSegments = sp.getInt("segments", 8)
        maxParallel = sp.getInt("parallel", 3)
        wifiOnly = sp.getBoolean("wifiOnly", false)
        speedLimitKbps = sp.getInt("speedLimit", 0)
        rootFolder = sp.getString("root", "MyDM") ?: "MyDM"
        notifLines = sp.getInt("notifLines", 5)
        notifyDone = sp.getBoolean("notifyDone", true)
        detectVideo = sp.getBoolean("detVideo", true)
        detectAudio = sp.getBoolean("detAudio", true)
        detectFiles = sp.getBoolean("detFiles", true)
        themeMode = runCatching { ThemeMode.valueOf(sp.getString("theme", "DARK")!!) }.getOrDefault(ThemeMode.DARK)
        accent = runCatching { AccentColor.valueOf(sp.getString("accent", "VIOLET")!!) }.getOrDefault(AccentColor.VIOLET)
        prefetchLinks = sp.getBoolean("prefetch", true)
        clipboardWatch = sp.getBoolean("clipboard", true)
        scanSeconds = sp.getInt("scanSec", 8)
        scanEmbeds = sp.getInt("scanEmbeds", 3)
        seriesParallel = sp.getInt("seriesPar", 2)
        seriesFolders = sp.getBoolean("seriesFolders", true)
        autoPlayNext = sp.getBoolean("autoNext", true)
        resumePlayback = sp.getBoolean("resume", true)
        keepScreenOn = sp.getBoolean("keepOn", true)
        confirmDelete = sp.getBoolean("confirmDel", true)
        autoUpdateYt = sp.getBoolean("autoYt", true)
        captureConsole = sp.getBoolean("console", true)
        siteMaxMb = sp.getInt("siteMaxMb", 100)
    }

    private fun b(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()
    private fun i(k: String, v: Int) = sp.edit().putInt(k, v).apply()

    fun updateHomeUrl(v: String) {
        val t = v.trim().ifEmpty { DEFAULT_HOME }
        homeUrl = if (t.startsWith("http://") || t.startsWith("https://")) t else "https://$t"
        sp.edit().putString("home", homeUrl).apply()
    }
    fun updateSearchEngine(v: SearchEngine) { searchEngine = v; sp.edit().putString("engine", v.name).apply() }
    fun updateImageEngine(v: ImageEngine) { imageEngine = v; sp.edit().putString("imgEngine", v.name).apply() }
    fun updateDesktopMode(v: Boolean) { desktopMode = v; b("desktop", v) }
    fun updateBlockPopups(v: Boolean) { blockPopups = v; b("blockPopups", v) }
    fun updateRestoreTabs(v: Boolean) { restoreTabs = v; b("restoreTabs", v) }
    fun updateJs(v: Boolean) { jsEnabled = v; b("js", v) }
    fun updateLoadImages(v: Boolean) { loadImages = v; b("images", v) }
    fun updateTextZoom(v: Int) { textZoom = v; i("textZoom", v) }
    fun updateBlockAds(v: Boolean) { blockAds = v; b("blockAds", v) }
    fun updateExternalNewTab(v: Boolean) { externalNewTab = v; b("externalNewTab", v) }
    fun updateMaxSegments(v: Int) { maxSegments = v; i("segments", v) }
    fun updateMaxParallel(v: Int) { maxParallel = v; i("parallel", v) }
    fun updateWifiOnly(v: Boolean) { wifiOnly = v; b("wifiOnly", v) }
    fun updateSpeedLimit(v: Int) { speedLimitKbps = v; i("speedLimit", v) }
    fun updateRootFolder(v: String) {
        rootFolder = v.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifEmpty { "MyDM" }
        sp.edit().putString("root", rootFolder).apply()
    }
    fun updateNotifLines(v: Int) { notifLines = v; i("notifLines", v) }
    fun updateNotifyDone(v: Boolean) { notifyDone = v; b("notifyDone", v) }
    fun updateDetectVideo(v: Boolean) { detectVideo = v; b("detVideo", v) }
    fun updateDetectAudio(v: Boolean) { detectAudio = v; b("detAudio", v) }
    fun updateDetectFiles(v: Boolean) { detectFiles = v; b("detFiles", v) }
    fun updateThemeMode(v: ThemeMode) { themeMode = v; sp.edit().putString("theme", v.name).apply() }
    fun updateAccent(v: AccentColor) { accent = v; sp.edit().putString("accent", v.name).apply() }
    fun updatePrefetch(v: Boolean) { prefetchLinks = v; b("prefetch", v) }
    fun updateClipboardWatch(v: Boolean) { clipboardWatch = v; b("clipboard", v) }
    fun updateScanSeconds(v: Int) { scanSeconds = v; i("scanSec", v) }
    fun updateScanEmbeds(v: Int) { scanEmbeds = v; i("scanEmbeds", v) }
    fun updateSeriesParallel(v: Int) { seriesParallel = v; i("seriesPar", v) }
    fun updateSeriesFolders(v: Boolean) { seriesFolders = v; b("seriesFolders", v) }
    fun updateAutoPlayNext(v: Boolean) { autoPlayNext = v; b("autoNext", v) }
    fun updateResumePlayback(v: Boolean) { resumePlayback = v; b("resume", v) }
    fun updateKeepScreenOn(v: Boolean) { keepScreenOn = v; b("keepOn", v) }
    fun updateConfirmDelete(v: Boolean) { confirmDelete = v; b("confirmDel", v) }
    fun updateAutoUpdateYt(v: Boolean) { autoUpdateYt = v; b("autoYt", v) }
    fun updateCaptureConsole(v: Boolean) { captureConsole = v; b("console", v) }
    fun updateSiteMaxMb(v: Int) { siteMaxMb = v; i("siteMaxMb", v) }

    /** Transforme ce que tape l'utilisateur en URL : adresse, domaine ou recherche. */
    fun resolveInput(input: String): String {
        val t = input.trim()
        return when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            "." in t && " " !in t -> "https://$t"
            else -> searchEngine.template + android.net.Uri.encode(t)
        }
    }

    // ── Positions de lecture (reprise)
    fun savePosition(key: String, ms: Long) { sp.edit().putLong("pos_" + key.hashCode(), ms).apply() }
    fun position(key: String): Long = sp.getLong("pos_" + key.hashCode(), 0L)
    fun lastYtUpdate(): Long = sp.getLong("ytUpdated", 0L)
    fun markYtUpdated() { sp.edit().putLong("ytUpdated", System.currentTimeMillis()).apply() }

    // ── Onglets ouverts (restaurés au démarrage si l'option est active)
    fun saveTabs(urls: List<String>, current: Int) {
        sp.edit().putString("tabs", JSONArray(urls).toString()).putInt("tabIndex", current).apply()
    }
    fun savedTabs(): List<String> = runCatching {
        val a = JSONArray(sp.getString("tabs", "[]"))
        List(a.length()) { a.getString(it) }.filter { it.startsWith("http") }
    }.getOrDefault(emptyList())
    fun savedTabIndex(): Int = sp.getInt("tabIndex", 0)
}
