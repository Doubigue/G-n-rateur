package com.example.mydm.ui

import android.content.Context
import com.example.mydm.App
import com.example.mydm.core.*
import com.example.mydm.downloader.DownloadService

object DownloadActions {
    /** Met un média détecté en file d'attente (direct ou HLS via yt-dlp) et lance le service. */
    suspend fun queue(ctx: Context, app: App, m: DetectedMedia, subFolder: String? = null, name: String? = null) {
        val id = if (m.type == MediaType.HLS)
            app.downloadEngine.enqueueYt(m.url, name ?: m.displayName(), QualityOption("HLS", null, false, "b"), m.referer, m.userAgent, subFolder)
        else app.downloadEngine.enqueue(m, subFolder, name)
        DownloadService.start(ctx, id)
    }
}
