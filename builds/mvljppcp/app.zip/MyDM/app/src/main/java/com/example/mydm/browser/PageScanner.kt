package com.example.mydm.browser

import android.content.Context
import android.net.Uri
import android.os.SystemClock
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebView
import com.example.mydm.core.DetectedMedia
import com.example.mydm.core.MediaDetector
import com.example.mydm.core.MediaResolver
import com.example.mydm.core.MediaType
import com.example.mydm.core.Prefs
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import org.json.JSONTokener
import kotlin.coroutines.resume

data class EpisodeLink(val url: String, val label: String, val season: Int?, val episode: Int?)

data class PageScan(
    val title: String,
    val media: List<DetectedMedia>,   // flux vidéo / audio / fichiers trouvés
    val embeds: List<String>,         // lecteurs intégrés (iframes) de la page
    val episodes: List<EpisodeLink>   // liens qui ressemblent à d'autres épisodes
)

/**
 * Analyse une page SANS la lire : une WebView invisible charge la page, lance les lecteurs en sourdine,
 * écoute le réseau (comme le navigateur) et lit le DOM (video, iframes, scripts, liens d'épisodes).
 */
object PageScanner {

    private const val COLLECT_JS = """
(function(){
  var out={title:document.title||'',media:[],iframes:[],links:[]};
  function abs(u){try{return new URL(u,location.href).href}catch(e){return null}}
  function push(a,u){var x=abs(u); if(x&&a.indexOf(x)<0)a.push(x)}
  document.querySelectorAll('video,audio').forEach(function(v){
    if(v.currentSrc)push(out.media,v.currentSrc); if(v.src)push(out.media,v.src);
    v.querySelectorAll('source').forEach(function(s){if(s.src)push(out.media,s.src)});
  });
  document.querySelectorAll('iframe').forEach(function(f){
    var s=f.src||f.getAttribute('data-src')||f.getAttribute('data-lazy-src'); if(s)push(out.iframes,s)});
  document.querySelectorAll('[data-embed],[data-link],[data-url],[data-player]').forEach(function(e){
    ['data-embed','data-link','data-url','data-player'].forEach(function(k){
      var v=e.getAttribute(k); if(v&&/^(https?:)?\/\//.test(v))push(out.iframes,v)})});
  try{
    var html=document.documentElement.innerHTML;
    var re=/https?:(?:\\?\/){2}[^"'\s<>\\]+?\.(?:m3u8|mp4|webm|mkv|mp3|m4a)(?:\?[^"'\s<>\\]*)?/gi;
    var m,n=0; while((m=re.exec(html))&&n<40){push(out.media,m[0].replace(/\\\//g,'/')); n++}
  }catch(e){}
  var seen={};
  document.querySelectorAll('a[href]').forEach(function(a){
    var u=abs(a.href); if(!u||seen[u]||out.links.length>=1500)return; seen[u]=1;
    out.links.push({u:u,t:(a.innerText||a.title||a.getAttribute('aria-label')||'').replace(/\s+/g,' ').trim().slice(0,90)})});
  document.querySelectorAll('select option[value]').forEach(function(o){
    var u=abs(o.value); if(u&&!seen[u]&&/^https?:/.test(u)&&out.links.length<1500){
      seen[u]=1; out.links.push({u:u,t:(o.textContent||'').trim().slice(0,90)})}});
  return JSON.stringify(out);
})()
"""

    private const val PLAY_JS = """
(function(){
  document.querySelectorAll('video,audio').forEach(function(v){
    try{v.muted=true;var p=v.play();if(p&&p.catch)p.catch(function(){})}catch(e){}});
  ['.vjs-big-play-button','.jw-icon-display','.jw-display-icon-container','.plyr__control--overlaid','.fp-play',
   '.dplayer-play-icon','.mejs__overlay-button','.play-button','.btn-play','.bigplay','.ytp-large-play-button',
   '.video-js','#player','.play','[aria-label=Play]','[title=Play]'].forEach(function(s){
    try{var e=document.querySelector(s); if(e)e.click()}catch(x){}});
  return 'ok';
})()
"""

    private val badEmbedHosts = listOf("youtube.com", "youtu.be", "facebook.com", "twitter.com", "x.com", "instagram.com",
        "google.com", "gstatic.com", "doubleclick.net", "disqus.com", "recaptcha.net", "googlesyndication.com",
        "adservice.google.com", "taboola.com", "outbrain.com", "popads.net", "histats.com", "addthis.com")

    private fun embedOk(u: String): Boolean {
        if (!u.startsWith("http")) return false
        val host = Uri.parse(u).host?.lowercase() ?: return false
        if (badEmbedHosts.any { host == it || host.endsWith(".$it") }) return false
        return !Regex("\\.(js|css|png|jpe?g|gif|webp|svg|ico)(\\?|#|$)", RegexOption.IGNORE_CASE).containsMatchIn(Uri.parse(u).path ?: "")
    }

    /** Lit le DOM d'une WebView déjà chargée (onglet courant) : médias, iframes, liens. Thread principal. */
    suspend fun collectFrom(web: WebView): JSONObject? {
        val raw = withTimeoutOrNull(4000) {
            suspendCancellableCoroutine<String?> { c -> web.evaluateJavascript(COLLECT_JS) { c.resume(it) } }
        } ?: return null
        val txt = runCatching { JSONTokener(raw).nextValue() as? String }.getOrNull() ?: return null
        return runCatching { JSONObject(txt) }.getOrNull()
    }

    /** Épisodes de la page affichée dans un onglet (instantané : pas de nouveau chargement). */
    suspend fun episodesOf(web: WebView, pageUrl: String): List<EpisodeLink> =
        collectFrom(web)?.let { parseEpisodes(it, pageUrl) } ?: emptyList()

    // ───────────── Analyse complète d'une page
    suspend fun scan(ctx: Context, url: String, referer: String? = null, withEmbeds: Boolean = true): PageScan {
        val first = scanOne(ctx, url, referer)
        if (!withEmbeds) return first
        val media = LinkedHashMap<String, DetectedMedia>()
        first.media.forEach { media[it.url] = it }
        val embeds = first.embeds.filter(::embedOk).distinct()
        for (e in embeds.take(Prefs.scanEmbeds)) {
            if (media.values.any { it.type == MediaType.VIDEO || it.type == MediaType.HLS }) break
            val r = runCatching { scanOne(ctx, e, url) }.getOrNull() ?: continue
            r.media.forEach { media.putIfAbsent(it.url, it) }
        }
        return first.copy(media = media.values.toList(), embeds = embeds)
    }

    private suspend fun scanOne(ctx: Context, url: String, referer: String?): PageScan = withContext(Dispatchers.Main) {
        val web = SnifferWebView(ctx.applicationContext)
        val found = ArrayList<DetectedMedia>()
        // Écoute dès maintenant : le flux n'a pas de relecture
        val collector = launch(start = CoroutineStart.UNDISPATCHED) { web.detectedMedia.collect { found.add(it) } }
        try {
            // WebView hors écran : on lui donne une taille pour que les lecteurs se chargent
            web.measure(View.MeasureSpec.makeMeasureSpec(1080, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(1920, View.MeasureSpec.EXACTLY))
            web.layout(0, 0, 1080, 1920)
            web.onResume()
            var progress = 0
            web.onProgress = { progress = it }
            if (referer != null) web.loadUrl(url, mapOf("Referer" to referer)) else web.loadUrl(url)

            val limit = Prefs.scanSeconds * 1000L
            val t0 = SystemClock.uptimeMillis()
            var played = 0
            var foundAt = -1L
            while (true) {
                delay(400)
                val el = SystemClock.uptimeMillis() - t0
                if (el >= limit) break
                if ((progress >= 100 || el > 6000) && played < 3 && el >= 1200L * (played + 1)) {
                    web.evaluateJavascript(PLAY_JS, null); played++
                }
                val hasVideo = found.any { it.type == MediaType.VIDEO || it.type == MediaType.HLS }
                if (hasVideo && foundAt < 0) foundAt = el
                if (foundAt >= 0 && el - foundAt > 1500) break
            }

            val js = collectFrom(web)
            val pageUrl = web.url ?: url
            val title = js?.optString("title").orEmpty().ifBlank { web.title.orEmpty() }
            val ua = web.settings.userAgentString
            val all = LinkedHashMap<String, DetectedMedia>()
            found.forEach { all[it.url] = it }
            js?.optJSONArray("media")?.let { a ->
                for (i in 0 until a.length()) {
                    val u = a.optString(i)
                    if (!u.startsWith("http") || u in all) continue
                    val type = MediaDetector.detect(u) ?: continue
                    all[u] = DetectedMedia(u, type, pageUrl, title, ua, CookieManager.getInstance().getCookie(u), pageUrl)
                }
            }
            val embeds = ArrayList<String>()
            js?.optJSONArray("iframes")?.let { a -> for (i in 0 until a.length()) embeds += a.optString(i) }
            PageScan(title, all.values.toList(), embeds, js?.let { parseEpisodes(it, pageUrl) } ?: emptyList())
        } finally {
            collector.cancel()
            runCatching { web.stopLoading(); web.loadUrl("about:blank"); web.destroy() }
        }
    }

    // ───────────── Épisodes
    private val epRe = Regex(
        """(?:s(?:aison|eason)?\s*0*(\d{1,2})[-_.x\s]*e(?:p(?:isode)?)?[-_.\s]*0*(\d{1,3}))|(?:\b(?:[eé]pisode|[eé]p\.?|e)[-_.\s]*0*(\d{1,3})\b)""",
        RegexOption.IGNORE_CASE)
    private val seasonRe = Regex("""(?:saison|season|\bs)[-_.\s]*0*(\d{1,2})\b""", RegexOption.IGNORE_CASE)

    private fun hostKey(u: String) = Uri.parse(u).host?.lowercase()?.removePrefix("www.")

    fun parseEpisodes(js: JSONObject, pageUrl: String): List<EpisodeLink> {
        val links = js.optJSONArray("links") ?: return emptyList()
        val pageHost = hostKey(pageUrl)
        val out = LinkedHashMap<String, EpisodeLink>()
        for (i in 0 until links.length()) {
            val o = links.optJSONObject(i) ?: continue
            val u = o.optString("u").substringBefore('#')
            val t = o.optString("t")
            if (!u.startsWith("http") || u == pageUrl.substringBefore('#') || hostKey(u) != pageHost) continue
            val path = Uri.decode(Uri.parse(u).path.orEmpty())
            val m = epRe.find("$t ${path.substringAfterLast('/')}") ?: continue
            val season = (m.groupValues[1].toIntOrNull()
                ?: seasonRe.find("$t $path")?.groupValues?.get(1)?.toIntOrNull())
            val ep = m.groupValues[2].toIntOrNull() ?: m.groupValues[3].toIntOrNull() ?: continue
            if (u !in out) out[u] = EpisodeLink(u, t.ifBlank { "Épisode $ep" }, season, ep)
        }
        // Un seul lien « épisode » = probablement « suivant » : on n'en fait pas une série
        if (out.size < 2) return emptyList()
        return out.values.sortedWith(compareBy({ it.season ?: 0 }, { it.episode ?: Int.MAX_VALUE }))
    }

    /** Meilleur flux parmi ceux trouvés : on écarte les petits clips (publicités). */
    suspend fun pickBest(list: List<DetectedMedia>): DetectedMedia? {
        val vids = list.filter { it.type == MediaType.VIDEO || it.type == MediaType.HLS }
        if (vids.isEmpty()) return null
        val scored = vids.map { m ->
            val size = m.sizeBytes ?: if (m.type == MediaType.VIDEO) MediaResolver.probeSize(m) else null
            m to (if (m.type == MediaType.HLS) 400_000_000L + (if ("master" in m.url) 1L else 0L) else size ?: 0L)
        }
        val big = scored.filter { it.second >= 5_000_000L }
        return (big.ifEmpty { scored }).maxByOrNull { it.second }?.first
    }
}
