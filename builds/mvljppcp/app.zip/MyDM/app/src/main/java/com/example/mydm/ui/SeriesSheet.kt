package com.example.mydm.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.mydm.browser.EpisodeLink
import com.example.mydm.downloader.BState

/** Série : choisir les épisodes puis tout télécharger d'un coup (analyse automatique de chaque page). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SeriesSheet(episodes: List<EpisodeLink>, pageTitle: String, onDismiss: () -> Unit) {
    val app = appInstance()
    val batchItems by app.batch.items.collectAsStateWithLifecycle()
    val running by app.batch.running.collectAsStateWithLifecycle()
    val showProgress = running || batchItems.isNotEmpty()

    var title by remember { mutableStateOf(guessSeriesName(pageTitle)) }
    var selected by remember { mutableStateOf(episodes.map { it.url }.toSet()) }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true), containerColor = Bg) {
        LazyColumn(Modifier.fillMaxWidth(), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item { Text("📺 Série", color = Txt, fontSize = 20.sp) }

            if (!showProgress) {
                item {
                    Column(Modifier.fillMaxWidth().glass().padding(12.dp)) {
                        Text("Nom de la série (nom du dossier)", color = Muted, fontSize = 12.sp)
                        OutlinedTextField(title, { title = it }, Modifier.fillMaxWidth(), singleLine = true)
                        Text("${episodes.size} épisodes trouvés sur la page. MyDM ouvre chaque épisode en arrière-plan, trouve la vidéo sans la lire, " +
                            "et l'ajoute aux téléchargements.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
                    }
                }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton({ selected = if (selected.size == episodes.size) emptySet() else episodes.map { it.url }.toSet() }) {
                            Text(if (selected.size == episodes.size) "Tout désélectionner" else "Tout sélectionner")
                        }
                        Spacer(Modifier.weight(1f))
                        Text("${selected.size} sélectionné(s)", color = Muted, fontSize = 12.sp)
                    }
                }
                items(episodes, key = { it.url }) { ep ->
                    Row(Modifier.fillMaxWidth().glass().clickable { selected = if (ep.url in selected) selected - ep.url else selected + ep.url }.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(ep.url in selected, { c -> selected = if (c) selected + ep.url else selected - ep.url })
                        Column(Modifier.weight(1f)) {
                            Text(ep.label, color = Txt, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(buildString {
                                ep.season?.let { append("Saison $it  ") }
                                ep.episode?.let { append("Épisode $it") }
                            }, color = Muted, fontSize = 11.sp)
                        }
                    }
                }
                item {
                    Button({ app.batch.start(title.ifBlank { "Série" }, episodes.filter { it.url in selected }) },
                        Modifier.fillMaxWidth().padding(top = 4.dp), enabled = selected.isNotEmpty()) {
                        Text("⬇ Télécharger ${selected.size} épisode(s)")
                    }
                }
            } else {
                val done = batchItems.count { it.state == BState.DONE }
                val failed = batchItems.count { it.state == BState.FAIL }
                item {
                    Column(Modifier.fillMaxWidth().glass().padding(12.dp)) {
                        Text(app.batch.series.value, color = Accent, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        LinearProgressIndicator({ (done + failed).toFloat() / batchItems.size.coerceAtLeast(1) }, Modifier.fillMaxWidth().padding(vertical = 8.dp))
                        Text((if (running) "Analyse en cours : " else "Terminé : ") + "$done ajouté(s)" + (if (failed > 0) " • $failed échec(s)" else "") + " sur ${batchItems.size}",
                            color = Muted, fontSize = 12.sp)
                        if (running) Text("Gardez l'application ouverte pendant l'analyse.", color = Muted, fontSize = 11.sp)
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (running) OutlinedButton({ app.batch.cancel() }) { Text("Arrêter") }
                        else {
                            Button({ onDismiss() }) { Text("Voir les téléchargements") }
                            OutlinedButton({ app.batch.clear() }) { Text("Nouvelle sélection") }
                        }
                    }
                }
                items(batchItems, key = { it.ep.url }) { b ->
                    Row(Modifier.fillMaxWidth().glass().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(when (b.state) { BState.WAIT -> "⏳"; BState.SCAN -> "🔎"; BState.DONE -> "✅"; BState.FAIL -> "⚠️" }, fontSize = 18.sp)
                        Column(Modifier.weight(1f).padding(start = 10.dp)) {
                            Text(b.ep.label, color = Txt, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            b.note?.let { n -> Text(n, color = if (b.state == BState.FAIL) Danger else Muted, fontSize = 11.sp) }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

/** « Ma Série - Saison 1 - Streaming » → « Ma Série ». */
fun guessSeriesName(pageTitle: String): String =
    pageTitle.replace(Regex("(?i)\\s*[-–|:]\\s*(streaming|saison|season|épisode|episode|voir|regarder|vf|vostfr).*"), "")
        .replace(Regex("(?i)\\s+(en\\s+)?streaming.*"), "")
        .trim().ifBlank { "Série" }
