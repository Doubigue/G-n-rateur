# MyDM — Navigateur & Gestionnaire de téléchargements (Kotlin / Compose)

Ouvrir le dossier dans **Android Studio (Ladybug+)**, laisser la synchro Gradle se faire (génère le wrapper), puis Run sur un appareil Android 10+ (API 29).

- `browser/` WebView + sniffer (shouldInterceptRequest + JS injecté)
- `downloader/` moteur multi-segments (Range) + Foreground Service
- `whatsapp/` statuts via Storage Access Framework
- `torrent/` jlibtorrent (magnet / .torrent, sélection de fichiers, stats temps réel)
- `ui/` thème sombre « glass » + écrans Compose

Limites connues : HLS (.m3u8) détecté mais pas téléchargé ; pas de DRM ; vérifier les signatures jlibtorrent selon la version.

## Téléchargeur (pastille ⬇)
- Détection par extension, balises vidéo/audio **et Content-Type** (fichiers sans extension).
- Pastille « ⬇ » sur le navigateur : liste des médias, taille au clic, bouton Télécharger.
- Liens YouTube / Facebook / TikTok / HLS (m3u8) : analyse par yt-dlp (qualités + tailles), MP4 / M4A / MP3.
- Statuts WhatsApp : tous les dossiers `.Statuses` sont fusionnés et triés du plus récent au plus ancien.

## Onglets & paramètres
- Onglets : bouton compteur dans la barre d'adresse → grille d'onglets (miniatures, fermer, nouvel onglet). Les liens `target=_blank` / `window.open` ouvrent un nouvel onglet. Chaque onglet a sa propre liste de médias détectés.
- Paramètres (menu ⋮ du navigateur) : page d'accueil, moteur de recherche, mode ordinateur, blocage des pop-ups, restauration des onglets, nombre de connexions par téléchargement, effacement cookies/cache/médias.

## Version 2 — nouveautés
- **Page Téléchargements** : 3 onglets — *À télécharger* (médias détectés dans tous les onglets, taille, « Tout télécharger »), *Téléchargements* (en cours / terminés), *Dossiers*.
- **Pastille** sur l'onglet Téléchargements (nombre en cours, sinon médias détectés) et sur Torrent.
- **Dossiers** : `Download/MyDM/` → `Vidéo made/Statuts` (photos, vidéos), `Vidéo`, `Torrent/<Vidéos|Applications|Logiciels|Jeux|Documents|…>`, `Documents`, `Images`, `Musiques`, `Autres` (+ `Autres/Sites` pour les ZIP de sites). Classement automatique par type de fichier.
- **Notification** : « N en cours • % • vitesse », 5 premières lignes (nom • % • taille), « +N autres », pastille (setNumber), bouton « Tout mettre en pause ».
- **ZIP d'un site** (menu ⋮ du navigateur) : index.html (DOM rendu, liens réécrits en local), source.html, CSS/JS/images/polices, console.txt, _info.txt.
- **Console** (menu ⋮) : console.log / erreurs de la page, exécution de JavaScript, copie du HTML.
- **Liens externes** : http/https (navigateur par défaut), partage de texte/lien, `magnet:`, fichiers `.torrent`, partage d'une photo (recherche par image).
- **Recherche par photo** : Google Lens / Bing Visual / TinEye / Yandex ; la photo choisie est envoyée automatiquement au bouton « importer » de la page.
- **Extensions** : scripts utilisateur (type Tampermonkey) — Paramètres > Développeur. Les extensions Chrome (.crx) ne tournent pas dans une WebView.
- **Paramètres** : limite de vitesse, téléchargements simultanés, Wi-Fi uniquement, dossier principal, JS/images/zoom, blocage pubs, types détectés, etc.

## Version 2.1 — nouveautés
- **Analyse de liens plus rapide** (YouTube / Facebook / TikTok) : pré-analyse dès l'ouverture de la page vidéo, cache 15 min, analyse automatique à l'ouverture de la fenêtre, options yt-dlp « rapides », mise à jour de yt-dlp au plus 1×/jour et différée (elle ne concurrence plus la 1re analyse), 8 fragments simultanés au téléchargement.
- **Télécharger sans lire la vidéo** (cinezzz, papadustream…) : « Analyser » charge la page dans une WebView invisible, lance les lecteurs en sourdine, écoute le réseau, lit le DOM et teste les lecteurs intégrés (iframes) ; repli yt-dlp pour les hébergeurs connus (voe, streamtape, doodstream, uqload, vidoza…).
- **Séries d'un coup** : menu ⋮ → « 📺 Série », ou détection automatique dans « Analyser ». Choix des épisodes, nom de série, puis analyse en arrière-plan de chaque épisode et mise en file des téléchargements dans `Vidéo/<Série>/` (S01E05…).
- **Lecteur intégré** : vidéo / audio (Media3 ExoPlayer, reprise de position, lecture suivante auto), images (balayage, zoom), PDF, texte, **installation d'APK**.
- **Fichiers externes** : MyDM apparaît dans « Ouvrir avec » pour vidéo, audio, image, PDF, texte, APK ; partage de fichiers vers MyDM ; bouton « Ouvrir un fichier du téléphone » (Dossiers).
- **Bibliothèque** : miniatures, recherche, tri, espace disque, confirmation de suppression.
- **Nouveau design** : thèmes Auto / Sombre / Noir pur / Clair, 6 couleurs d'accent, cartes arrondies.
- **Paramètres** : Apparence, Analyse & séries, Lecteur intégré, bandeau « lien copié », mise à jour yt-dlp.

Limites : les sites protégés (Cloudflare, captcha, DRM) peuvent bloquer l'analyse automatique ; ouvrez la page une fois dans le navigateur pour valider le contrôle, puis relancez. Le lecteur ne gère pas AVI/WMV (bouton « Ouvrir avec… »).
