package com.dlvibestudio.dlturbo.engine

import android.content.Context
import com.dlvibestudio.dlturbo.data.DlStatus
import com.dlvibestudio.dlturbo.data.DownloadRepository
import com.dlvibestudio.dlturbo.data.Settings
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.runInterruptible
import kotlinx.coroutines.withContext
import java.io.File
import org.json.JSONObject
import java.io.IOException
import java.util.UUID
import kotlin.coroutines.coroutineContext

/**
 * Téléchargement de vidéos depuis les sites de partage (YouTube, Instagram, Facebook,
 * TikTok, Pinterest, X/Twitter et plus d'un millier d'autres) grâce à yt-dlp + ffmpeg.
 */
class VideoEngine(
    private val context: Context,
    private val repo: DownloadRepository,
    private val settings: Settings,
    scope: CoroutineScope,
) {
    /** null = prêt ; sinon, l'erreur d'initialisation. */
    private val ready = CompletableDeferred<Throwable?>()

    init {
        scope.launch(Dispatchers.IO) {
            val error = try {
                YoutubeDL.getInstance().init(context)
                FFmpeg.getInstance().init(context)
                null
            } catch (t: Throwable) {
                t
            }
            ready.complete(error)
            // Les sites changent souvent : yt-dlp vérifie tout seul s'il existe une nouvelle version
            // (au démarrage après une courte pause, puis toutes les 6 h tant que l'appli tourne).
            if (error == null) {
                kotlinx.coroutines.delay(15_000)
                while (true) {
                    autoUpdate(12 * 3600_000L)
                    kotlinx.coroutines.delay(6 * 3600_000L)
                }
            }
        }
    }

    /** Dossier de travail privé d'un téléchargement vidéo (fichiers partiels, reprise). */
    fun tempDir(id: String): File =
        File(context.getExternalFilesDir(null) ?: context.filesDir, "ytdlp-tmp/$id")

    // ------------------------------------------------------------------ Analyse déjà faite

    private val infoDir: File get() = File(context.cacheDir, "ytinfo")

    private fun infoFile(url: String): File {
        val md = java.security.MessageDigest.getInstance("MD5").digest(url.toByteArray())
        return File(infoDir, md.joinToString("") { "%02x".format(it) } + ".json")
    }

    /**
     * Garde l'analyse faite par le sélecteur de formats : le téléchargement lancé juste après la réutilise
     * au lieu d'interroger le site une deuxième fois (départ quasi immédiat).
     */
    fun rememberInfo(url: String, json: JSONObject) {
        if (json.optString("_type") == "playlist" || json.has("entries")) return
        runCatching {
            infoDir.mkdirs()
            infoDir.listFiles()?.filter { System.currentTimeMillis() - it.lastModified() > INFO_MAX_AGE }?.forEach { it.delete() }
            infoFile(url).writeText(json.toString())
        }
    }

    private fun cachedInfo(url: String): File? =
        infoFile(url).takeIf { it.isFile && System.currentTimeMillis() - it.lastModified() < INFO_MAX_AGE }

    suspend fun run(id: String): File? {
        val item = repo.get(id) ?: throw FatalDownloadException("Téléchargement introuvable")
        val cached = if (!item.playlist && !settings.value.wholePlaylist) cachedInfo(item.url) else null
        if (cached == null) return runOnce(id, null)
        return try {
            runOnce(id, cached)
        } catch (e: IOException) {
            if (e is FatalDownloadException) throw e
            // Adresses de la vidéo expirées entre-temps : nouvelle analyse complète.
            cached.delete()
            coroutineContext.ensureActive()
            runOnce(id, null)
        }
    }

    private suspend fun runOnce(id: String, info: File?): File? {
        val item = repo.get(id) ?: throw FatalDownloadException("Téléchargement introuvable")
        val cfg = settings.value
        repo.update(id) {
            it.copy(info = if (info != null) "Démarrage…" else "Recherche de l'adresse de la vidéo…")
        }

        ready.await()?.let {
            throw FatalDownloadException("Module vidéo indisponible : ${it.message ?: it.javaClass.simpleName}")
        }

        val dir = File(item.dir)
        if (!dir.exists() && !dir.mkdirs() && !dir.exists()) {
            throw FatalDownloadException("Impossible de créer le dossier ${dir.path}")
        }

        val quality = item.quality.ifBlank { cfg.videoQuality }
        val wholePlaylist = item.playlist || cfg.wholePlaylist
        val request = if (info != null) YoutubeDLRequest(emptyList<String>()) else YoutubeDLRequest(item.url)
        if (info != null) request.addOption("--load-info-json", info.path)
        val template = if (wholePlaylist && item.folder.isNotBlank())
            "%(playlist_index|)s %(title).100B [%(id)s].%(ext)s"
        else if (wholePlaylist)
            "%(playlist_title|Playlist).80B/%(playlist_index|)s %(title).100B [%(id)s].%(ext)s"
        else if (item.outName.isNotBlank()) item.outName.replace("%", "") + ".%(ext)s"
        else "%(title).120B [%(id)s].%(ext)s"
        // Fichiers de travail (.part, .ytdl, fragments) dans le dossier privé de l'appli : Android refuse
        // parfois leur création dans Téléchargements (« Permission denied » sur le .ytdl), surtout s'il en
        // reste d'une ancienne installation. Seul le fichier terminé est placé dans DLTurbo.
        val tmp = tempDir(id).apply { mkdirs() }
        request.addOption("-P", "home:${dir.path}")
        request.addOption("--paths", "temp:${tmp.path}")
        request.addOption("-o", template)
        request.addOption("--no-mtime")
        request.addOption("--continue")
        request.addOption("--newline")
        request.addOption("--retries", cfg.retries.coerceAtLeast(1))
        request.addOption("--fragment-retries", cfg.retries.coerceAtLeast(1))
        request.addOption("--concurrent-fragments", cfg.videoFragments)
        // User-Agent de navigateur seulement pour un flux repéré dans une page (le serveur attend le même
        // navigateur) ; ailleurs yt-dlp choisit lui-même, c'est indispensable pour YouTube.
        if (item.referer.isNotBlank()) {
            request.addOption("--user-agent", cfg.userAgent.ifBlank { com.dlvibestudio.dlturbo.data.SettingsData.DEFAULT_UA })
        }
        if (wholePlaylist) {
            request.addOption("--yes-playlist")
            request.addOption("--ignore-errors") // une vidéo indisponible ne bloque pas les autres
        } else {
            request.addOption("--no-playlist")
        }
        if (item.referer.isNotBlank()) request.addOption("--referer", item.referer)
        if (item.cookie.isNotBlank()) request.addOption("--add-header", "Cookie:" + item.cookie)
        if (cfg.speedLimit > 0) request.addOption("--limit-rate", "${cfg.speedLimit / 1024}K")
        // SponsorBlock : la base communautaire indique les passages sponsorisés des vidéos YouTube ; ils sont coupés.
        if (cfg.sponsorBlock && Links.hostOf(item.url).let { it.contains("youtube") || it.contains("youtu.be") }) {
            request.addOption("--sponsorblock-remove", "sponsor,selfpromo,interaction")
        }

        when (quality) {
            "audio", "mp3" -> {
                request.addOption("-f", "ba/b")
                request.addOption("-x")
                request.addOption("--audio-format", "mp3")
                request.addOption("--audio-quality", "0")
            }
            "wav" -> {
                request.addOption("-f", "ba/b")
                request.addOption("-x")
                request.addOption("--audio-format", "wav")
            }
            "m4a" -> {
                request.addOption("-f", "ba[ext=m4a]/ba/b")
                request.addOption("-x")
                request.addOption("--audio-format", "m4a")
            }
            "best" -> request.addOption("-f", "bv*+ba/b")
            else -> {
                val h = quality.toIntOrNull() ?: 720
                request.addOption("-f", "bv*[height<=$h]+ba/b[height<=$h]/bv*+ba/b")
            }
        }
        if (!isAudioQuality(quality) && cfg.preferMp4) {
            request.addOption("-S", "ext:mp4:m4a")
            request.addOption("--merge-output-format", "mp4")
        }

        if (isAudioQuality(quality)) {
            // Pochette, titre et artiste intégrés au fichier audio.
            if (cfg.embedMeta) {
                request.addOption("--embed-metadata")
                if (quality != "wav") request.addOption("--embed-thumbnail")
            }
        } else if (cfg.subtitles) {
            val langs = cfg.subtitleLangs.split(',').map { it.trim() }.filter { it.isNotEmpty() }
                .joinToString(",") { "$it.*" }.ifBlank { "fr.*,en.*" }
            request.addOption("--write-subs")
            request.addOption("--write-auto-subs")
            request.addOption("--sub-langs", langs)
            if (cfg.preferMp4) request.addOption("--embed-subs") else request.addOption("--convert-subs", "srt")
        }

        var outputPath: String? = null
        var lastUpdate = 0L

        try {
            runInterruptible(Dispatchers.IO) {
                YoutubeDL.getInstance().execute(request, id) { progress, _, line ->
                    parseDestination(line)?.let { path ->
                        outputPath = path
                        val name = File(path).name
                        repo.update(id) { it.copy(fileName = name, autoName = false) }
                    }
                    val now = System.currentTimeMillis()
                    if (now - lastUpdate >= 400) {
                        lastUpdate = now
                        val total = parseSize(TOTAL_REGEX, line)
                        val speed = parseSize(SPEED_REGEX, line)
                        val position = ITEM_REGEX.find(line)
                        val stage = when {
                            position != null -> "Vidéo ${position.groupValues[1]}/${position.groupValues[2]}"
                            line.startsWith("[Merger]") -> "Fusion vidéo + audio…"
                            line.startsWith("[ExtractAudio]") -> "Conversion audio…"
                            line.startsWith("[download]") -> "Téléchargement"
                            else -> null
                        }
                        repo.update(id) {
                            it.copy(
                                status = if (it.status == DlStatus.CONNECTING || it.status == DlStatus.QUEUED)
                                    DlStatus.RUNNING else it.status,
                                percent = if (progress >= 0f) progress else it.percent,
                                totalBytes = if (total > 0) total else it.totalBytes,
                                downloadedBytes = if (total > 0 && progress >= 0f)
                                    (total * (progress / 100f)).toLong() else it.downloadedBytes,
                                speed = if (speed >= 0) speed else it.speed,
                                info = stage ?: it.info,
                            )
                        }
                    }
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: InterruptedException) {
            throw CancellationException("Annulé")
        } catch (e: Exception) {
            // Processus arrêté volontairement (pause / suppression) : ce n'est pas une erreur.
            if (e.javaClass.simpleName == "CanceledException") throw CancellationException("Annulé")
            coroutineContext.ensureActive()
            throw IOException(cleanError(e.message))
        } finally {
            // Arrête le processus yt-dlp s'il tourne encore (pause, suppression).
            // Les fichiers partiels (.part) restent sur le disque : la reprise continue dessus.
            runCatching { YoutubeDL.getInstance().destroyProcessById(id) }
            repo.update(id) { it.copy(speed = 0) }
        }

        // Le chemin annoncé peut être celui du dossier de travail : on retrouve le fichier déplacé dans DLTurbo.
        val file = outputPath?.let { p ->
            val inTmp = p.startsWith(tmp.path + "/")
            val moved = if (inTmp) File(dir, p.removePrefix(tmp.path + "/")) else File(p)
            moved.takeIf { it.exists() } ?: File(p).takeIf { it.exists() }
        }
        if (file != null && !wholePlaylist) runCatching { tmp.deleteRecursively() }
        if (file != null) {
            val length = file.length()
            repo.update(id) {
                it.copy(fileName = file.name, totalBytes = length, downloadedBytes = length, percent = 100f)
            }
        }
        return file
    }

    /**
     * Convertit un fichier local grâce à yt-dlp + ffmpeg (fichier lu comme une adresse « file:// »).
     * [mode] : "mp3", "compress" (720p, plus léger) ou "cut" (extrait [startSec]–[endSec]).
     * Le résultat est écrit à côté de l'original ; renvoie le fichier créé.
     */
    suspend fun convert(input: File, mode: String, startSec: Int = 0, endSec: Int = 0): File = withContext(Dispatchers.IO) {
        ready.await()?.let { throw IOException("Module vidéo indisponible : ${it.message ?: it.javaClass.simpleName}") }
        val stem = input.nameWithoutExtension + when (mode) {
            "mp3" -> ""
            "compress" -> " (léger)"
            else -> " (extrait)"
        }
        val dir = input.parentFile ?: throw IOException("Dossier introuvable")
        val started = System.currentTimeMillis()
        val request = YoutubeDLRequest(input.toURI().toString())
        request.addOption("--enable-file-urls")
        request.addOption("--no-playlist")
        request.addOption("--no-mtime")
        request.addOption("-o", File(dir, "$stem.%(ext)s").path)
        when (mode) {
            "mp3" -> {
                request.addOption("-x")
                request.addOption("--audio-format", "mp3")
                request.addOption("--audio-quality", "0")
            }
            "compress" -> {
                request.addOption("--recode-video", "mp4")
                request.addOption("--postprocessor-args", "VideoConvertor:-vf scale=-2:720 -c:v libx264 -crf 28 -preset veryfast -c:a aac -b:a 128k")
            }
            else -> {
                if (endSec <= startSec) throw IOException("La fin doit être après le début")
                request.addOption("--download-sections", "*$startSec-$endSec")
                request.addOption("--force-keyframes-at-cuts")
            }
        }
        val processId = "conv-" + UUID.randomUUID().toString().take(8)
        try {
            runInterruptible(Dispatchers.IO) { YoutubeDL.getInstance().execute(request, processId, null) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            throw IOException(cleanError(e.message))
        } finally {
            runCatching { YoutubeDL.getInstance().destroyProcessById(processId) }
        }
        dir.listFiles { f -> f.isFile && f.name.startsWith(stem + ".") && f.lastModified() >= started - 2000 }
            ?.maxByOrNull { it.lastModified() }
            ?: throw IOException("La conversion n'a produit aucun fichier")
    }

    private val updateLock = kotlinx.coroutines.sync.Mutex()
    private val prefs get() = context.getSharedPreferences("ytdlp", Context.MODE_PRIVATE)

    /**
     * Mise à jour automatique du moteur vidéo, si la dernière vérification date d'au moins [minAgeMs].
     * Appelée au démarrage, régulièrement, et après un échec de téléchargement vidéo.
     * Renvoie true si une nouvelle version vient d'être installée.
     */
    suspend fun autoUpdate(minAgeMs: Long): Boolean = withContext(Dispatchers.IO) {
        if (ready.await() != null) return@withContext false
        updateLock.lock()
        try {
            val now = System.currentTimeMillis()
            if (now - prefs.getLong("checkedAt", 0L) < minAgeMs) return@withContext false
            prefs.edit().putLong("checkedAt", now).apply()
            val status = runCatching { YoutubeDL.getInstance().updateYoutubeDL(context) }.getOrNull()
            if (status != null) prefs.edit().putLong("updatedAt", now).apply()
            status?.toString() == "DONE"
        } finally {
            updateLock.unlock()
        }
    }

    /** Met à jour yt-dlp (les sites changent souvent : à faire quand un site ne marche plus). */
    suspend fun update(): String = withContext(Dispatchers.IO) {
        ready.await()?.let { return@withContext "Module vidéo indisponible : ${it.message}" }
        try {
            prefs.edit().putLong("checkedAt", System.currentTimeMillis()).apply()
            val status = YoutubeDL.getInstance().updateYoutubeDL(context)
            val version = YoutubeDL.getInstance().version(context) ?: ""
            if (status?.toString() == "ALREADY_UP_TO_DATE") "yt-dlp est déjà à jour ($version)"
            else "yt-dlp mis à jour ($version)"
        } catch (e: Throwable) {
            "Échec de la mise à jour : ${e.message ?: "erreur inconnue"}"
        }
    }

    private fun parseDestination(line: String): String? {
        for (regex in DEST_REGEXES) {
            regex.find(line)?.let { return it.groupValues[1].trim() }
        }
        return null
    }

    private fun parseSize(regex: Regex, line: String): Long {
        val m = regex.find(line) ?: return -1
        val value = m.groupValues[1].toDoubleOrNull() ?: return -1
        val factor = when (m.groupValues[2]) {
            "KiB" -> 1024.0
            "MiB" -> 1024.0 * 1024
            "GiB" -> 1024.0 * 1024 * 1024
            else -> 1.0
        }
        return (value * factor).toLong()
    }

    private fun cleanError(message: String?): String {
        if (message.isNullOrBlank()) return "Échec de l'extraction de la vidéo"
        val line = message.lines().lastOrNull { it.contains("ERROR") } ?: message.lines().last { it.isNotBlank() }
        return line.replace("ERROR:", "").trim().take(240)
    }

    /**
     * Interroge yt-dlp et renvoie son résultat JSON (`-J`) : infos d'une vidéo, formats disponibles,
     * résultats de recherche ou contenu d'une playlist. Annulable.
     */
    suspend fun dumpJson(url: String, vararg options: Pair<String, String?>): JSONObject {
        ready.await()?.let {
            throw IOException("Module vidéo indisponible : ${it.message ?: it.javaClass.simpleName}")
        }
        val cfg = settings.value
        val request = YoutubeDLRequest(url)
        request.addOption("-J")
        request.addOption("--no-warnings")
        // Pas de User-Agent imposé : yt-dlp choisit lui-même celui qui convient à chaque site (YouTube surtout).
        request.addOption("--socket-timeout", "15")
        request.addOption("--extractor-retries", "1")
        for ((key, value) in options) {
            if (value == null) request.addOption(key) else request.addOption(key, value)
        }
        val processId = "info-" + UUID.randomUUID().toString().take(8)
        try {
            val response = runInterruptible(Dispatchers.IO) {
                YoutubeDL.getInstance().execute(request, processId, null)
            }
            val text = response.out.trim()
            val start = text.indexOf('{')
            if (start < 0) throw IOException("Réponse vide du moteur vidéo")
            return JSONObject(text.substring(start))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            if (e.javaClass.simpleName == "CanceledException") throw CancellationException("Annulé")
            coroutineContext.ensureActive()
            if (e is IOException) throw e
            throw IOException(cleanError(e.message))
        } finally {
            runCatching { YoutubeDL.getInstance().destroyProcessById(processId) }
        }
    }

    companion object {
        /** Les adresses fournies par YouTube & co. expirent au bout de quelques heures. */
        private const val INFO_MAX_AGE = 2 * 3600_000L

        private val ITEM_REGEX = Regex("""Downloading item (\d+) of (\d+)""")

        fun isAudioQuality(q: String) = q == "audio" || q == "mp3" || q == "wav" || q == "m4a"

        private val DEST_REGEXES = listOf(
            Regex("""^\[Merger\] Merging formats into "(.+)"\s*$"""),
            Regex("""^\[ExtractAudio\] Destination: (.+)$"""),
            Regex("""^\[download\] Destination: (.+)$"""),
            Regex("""^\[download\] (.+) has already been downloaded$"""),
        )
        private val TOTAL_REGEX = Regex("""of\s+~?\s*([\d.]+)\s*(KiB|MiB|GiB|B)""")
        private val SPEED_REGEX = Regex("""at\s+([\d.]+)\s*(KiB|MiB|GiB|B)/s""")
    }
}
