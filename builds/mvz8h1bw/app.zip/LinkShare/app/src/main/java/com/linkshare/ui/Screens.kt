package com.linkshare.ui

import android.Manifest
import android.content.Context
import android.annotation.SuppressLint
import android.content.Intent
import android.media.AudioManager
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.provider.Settings
import android.text.format.Formatter
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.Toast
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player as M3Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.common.MediaMetadata
import android.content.ComponentName
import com.linkshare.server.PlaybackService
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import com.linkshare.core.*
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp
import com.linkshare.R
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import com.linkshare.server.ShareService

@Composable
fun LinkShareApp(vm: MainViewModel) {
    val ex: ExplorerViewModel = viewModel()
    // Coffre ouvert : pas de captures d'écran ni d'aperçu dans les apps récentes
    val act = LocalContext.current.findActivity()
    DisposableEffect(VaultLock.unlocked) {
        if (VaultLock.unlocked) act?.window?.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        onDispose { act?.window?.clearFlags(WindowManager.LayoutParams.FLAG_SECURE) }
    }
    var splash by rememberSaveable { mutableStateOf(ExternalOpen.uri == null && ExternalOpen.folder == null) }
    Crossfade(targetState = splash, label = "splash") { showSplash ->
        if (showSplash) SplashScreen { splash = false }
        else when {
            ExternalOpen.uri != null -> ExternalViewerScreen()
            ex.viewing != null -> LocalViewerScreen(ex)
            vm.viewer != null -> ViewerScreen(vm)
            vm.client != null -> RemoteScreen(vm)
            else -> FilesApp(vm)
        }
    }
}

@Composable
fun SplashScreen(onDone: () -> Unit) {
    val scale = remember { Animatable(0.5f) }
    val logoAlpha = remember { Animatable(0f) }
    val credit = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        launch { scale.animateTo(1f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow)) }
        launch { logoAlpha.animateTo(1f, tween(700)) }
        delay(500)
        credit.animateTo(1f, tween(700))
        delay(1300)
        onDone()
    }
    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF1E6FEB), Color(0xFF123F96))))
            .systemBarsPadding()
    ) {
        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier.size(190.dp).scale(scale.value).alpha(logoAlpha.value)
                    .clip(CircleShape).background(Color.White.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center,
            ) {
                Image(painterResource(R.drawable.ic_launcher_foreground), null, Modifier.size(170.dp))
            }
            Spacer(Modifier.height(20.dp))
            Text("LinkShare", Modifier.alpha(logoAlpha.value), color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.ExtraBold)
            Text("Partage ultra-rapide", Modifier.alpha(logoAlpha.value), color = Color.White.copy(alpha = 0.8f), fontSize = 15.sp)
        }
        Column(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 36.dp).alpha(credit.value),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("Created by", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
            Text("DL VIBE STUDIO", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 3.sp)
            Text("Doubigue Loubikoa", color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp)
        }
    }
}

internal fun ensureAllFiles(ctx: Context): Boolean {
    if (Environment.isExternalStorageManager()) return true
    ctx.startActivity(
        Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${ctx.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    )
    Toast.makeText(ctx, "Autorise l'accès à tous les fichiers, puis réessaie", Toast.LENGTH_LONG).show()
    return false
}

/** Demande une seule fois d'ignorer l'optimisation de batterie (évite que le système tue le partage). */
internal fun askBatteryExemptionOnce(ctx: Context) {
    val prefs = ctx.getSharedPreferences("linkshare", Context.MODE_PRIVATE)
    val pm = ctx.getSystemService(PowerManager::class.java)
    if (pm.isIgnoringBatteryOptimizations(ctx.packageName) || prefs.getBoolean("battery_asked", false)) return
    prefs.edit().putBoolean("battery_asked", true).apply()
    ctx.startActivity(
        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    )
}

internal fun needsNotifPermission(ctx: Context) =
    Build.VERSION.SDK_INT >= 33 &&
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED

internal fun qr(text: String): Bitmap {
    val n = 640
    val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, n, n)
    return Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888).also { b ->
        for (x in 0 until n) for (y in 0 until n)
            b.setPixel(x, y, if (m.get(x, y)) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
    }
}

internal fun scan(ctx: Context, onResult: (Connection) -> Unit) {
    val opts = GmsBarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()
    GmsBarcodeScanning.getClient(ctx, opts).startScan()
        .addOnSuccessListener { b ->
            val c = Connection.parse(b.rawValue ?: "")
            if (c != null) onResult(c) else Toast.makeText(ctx, "QR non reconnu", Toast.LENGTH_SHORT).show()
        }
}


@Composable
fun ViewerScreen(vm: MainViewModel) {
    val e = vm.viewer ?: return
    val client = vm.client ?: return
    // Autres fichiers du même type dans le dossier : on y passe en balayant
    val list = vm.viewerList.ifEmpty { listOf(e) }
    val urls = remember(list) { list.map { client.fileUrl(it.path) } }
    val start = remember { list.indexOfFirst { it.path == e.path }.coerceAtLeast(0) }
    fun close() { PlayerHost.stop(); vm.viewer = null; vm.viewerList = emptyList() }
    BackHandler { close() }
    if (!e.isImage()) {
        // Vidéo / audio : lecteur plein écran, avec ses propres commandes (retour, titre, rotation…)
        Player(urls, list.map { it.name }, start, onClose = { close() }) { vm.viewer = list[it] }
        return
    }
    Column(Modifier.fillMaxSize().background(LS.Bg).systemBarsPadding()) {
        Row(Modifier.padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ close() }) { Icon(Ic.Back, "Retour", tint = LS.Blue) }
            Text(e.name, Modifier.weight(1f), maxLines = 1, color = LS.Blue, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            if (list.size > 1) Text(
                "${list.indexOfFirst { it.path == e.path } + 1}/${list.size}",
                Modifier.padding(end = 12.dp), color = LS.Muted, fontSize = 12.sp,
            )
        }
        ImagePager(urls, start) { vm.viewer = list[it] }
    }
}
