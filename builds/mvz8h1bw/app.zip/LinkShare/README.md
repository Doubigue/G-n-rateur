# LinkShare

Partage rapide Android (Kotlin / Compose / Ktor) avec accès distant aux fichiers et applications.

## Lancer
1. Ouvrir le dossier dans Android Studio (Ladybug ou plus récent, JDK 17) et laisser Gradle synchroniser.
2. Installer sur deux téléphones (Android 11+).
3. Téléphone A : « Partager mon téléphone » (autoriser l'accès à tous les fichiers) → un QR s'affiche.
4. Téléphone B : « Scanner un QR » → parcourir fichiers et apps, lire vidéos / audio / images en streaming,
   télécharger fichiers ou dossiers, envoyer fichiers ou dossiers (ils arrivent dans Download/LinkShare).

## Interface (explorateur façon Files by Google)
Thème sombre. Accueil : carrousel de fichiers récents (miniatures image/vidéo), Catégories (Téléchargements, Images, Vidéos,
Audio, Documents, Applications) avec la taille occupée, Collections (Favoris, Dossier sécurisé), Stockage total (interne,
carte SD si présente, autre téléphone via LinkShare).

La **pilule** est la barre grise arrondie flottante en bas de l'accueil, avec deux boutons : **Partager** à gauche (LinkShare : envoyer / recevoir) et **Scanner** à droite (scan de documents en PDF, ML Kit, enregistré dans Documents/LinkShare Scans).
- Partager ouvre une feuille : Envoyer (QR + radar), Recevoir (scan d'un QR), Se connecter avec un lien. Ces écrans sont
  propres à l'explorateur : pas d'accueil, de barre de navigation ni de profil LinkShare. Une fois connecté, la liste distante
  (fichiers, apps, envoi/téléchargement) s'affiche.
- Explorateur : dossiers en grille de grandes icônes (bascule liste), recherche récursive, tri, lecture intégrée,
  ZIP, favoris, dossier sécurisé (verrouillage du téléphone), suppression.

## Onglets « Tout » + dossiers, APK non installés
- **Images, Vidéos, Audio, Documents** : une rangée d'onglets sous la recherche. **Tout** liste tous les fichiers de la catégorie ;
  chaque onglet suivant est un dossier qui en contient (avec le nombre de fichiers) et n'affiche que ceux de ce dossier.
- **Applications** : même rangée d'onglets. **Tout** = applications installées + section « Fichiers APK non installés »
  (icône, nom, version et taille lus dans l'APK ; ceux dont l'appli est déjà installée sont masqués) ; les autres onglets = dossiers contenant des APK.
  Toucher un APK ouvre l'installateur Android (la première fois, autoriser LinkShare à « installer des applis inconnues »).

## Lecteur vidéo / audio
Lecteur plein écran aux commandes dessinées par l'appli (fond noir, voiles dégradés, bouton de lecture bleu). Toucher l'écran affiche
ou masque les commandes ; en vidéo elles se masquent seules après quelques secondes de lecture, et les barres système disparaissent
(un balayage depuis le bord les ramène).
- **Haut** : retour, titre (avec « 2 / 10 » quand il y a une liste) et **bouton de rotation** (vidéo) : il passe l'écran en
  **paysage** ou en **portrait** d'un seul toucher. La rotation est imposée par l'appli : elle ne dépend ni du capteur ni du réglage
  « rotation automatique » du téléphone, et on n'a pas à pencher l'appareil. En quittant le lecteur, l'appli reprend l'orientation normale.
- **Centre** : précédent, −10 s, lecture / pause, +10 s, suivant.
- **Bas** : temps écoulé / durée, barre de progression, puis trois boutons ronds **Aléatoire**, **Boucle** (répète le titre en cours) et
  **Tout** (répète toute la liste). Boucle et Tout s'excluent ; les choix sont mémorisés.
- **Audio** : une photo tirée au hasard parmi celles de l'appareil photo (`DCIM/Camera`) sert de fond, assombrie, et change à chaque titre.
  Sans photo trouvée, le logo s'affiche. Les commandes restent toujours visibles.

## Fichiers web (https)
- **Ouvrir un lien** : l'icône « lien » en haut de l'accueil (à gauche de l'engrenage) ouvre une boîte où coller une adresse
  `https://…` (ou `http://`). Vidéo et audio (mp4, mkv, webm, mp3, m4a, flux HLS `.m3u8` et DASH `.mpd`…) passent dans le lecteur
  plein écran, les images s'affichent, les textes (txt, json, srt…) se lisent. Sans extension reconnaissable, le type est demandé au
  serveur. Les autres formats (PDF, ZIP…) proposent d'ouvrir avec une autre appli, d'enregistrer dans `Download/LinkShare`
  ou de décompresser (ZIP).
- **Depuis une autre appli** : un lien web vers un fichier vidéo, audio, image ou texte peut s'ouvrir avec LinkShare, même quand
  l'appli d'origine n'annonce pas de type (le lien doit se terminer par l'extension du fichier).

## Pages web (HTML)
Les fichiers `.html`, `.htm`, `.xhtml` et `.svg` s'affichent comme dans un navigateur (lecteur web intégré), au lieu de leur code source :
- **Dans l'explorateur**, toucher un fichier HTML l'ouvre en page ; ses images, styles et scripts rangés à côté se chargent.
- **Liens https / http** (icône « lien » de l'accueil, ou lien reçu d'une autre appli) : la page s'affiche, avec navigation entre
  les pages (retour = page précédente, puis fermeture), actualisation et barre de chargement. Le type est vérifié auprès du
  serveur si le lien n'a pas d'extension. Un fichier à télécharger part dans `Download/LinkShare`.
- **« Ouvrir avec »** : un fichier ou un lien HTML reçu d'une autre appli s'ouvre de la même façon. Les liens `mailto:`, `tel:`…
  sont confiés à l'appli qui convient.

## Intégration au système
- **« Ouvrir avec »** : en plus de vidéo, audio, image et texte, LinkShare se déclare pour PDF, Word / Excel / PowerPoint, OpenDocument,
  RTF, ZIP, RAR, 7z, GZ et TAR. Comme elle n'affiche pas ces formats, elle propose : ouvrir avec une autre appli (LinkShare exclue de la liste),
  enregistrer dans Download/LinkShare, décompresser (ZIP), partager.
- **Sélecteur de fichiers Android** (`FilesDocumentsProvider`) : « LinkShare » apparaît parmi les emplacements quand une appli demande un fichier
  (Joindre, Importer, Enregistrer sous…). Le stockage interne y est parcourable, avec recherche, miniatures, création, renommage et suppression.
  Les dossiers cachés (commençant par un point) sont masqués. Il faut l'accès à tous les fichiers ; sans lui l'emplacement n'est pas proposé.

## Grille, copier / déplacer, balayage
- **Grille** (bouton en haut à droite) : dossiers en grandes cases, fichiers en miniatures (image et vidéo : aperçu ; audio,
  documents : icône + nom). Fonctionne aussi dans Images, Vidéos, Audio et Documents.
- **Copier / Déplacer** : appui long pour sélectionner (fichiers et dossiers), puis « Copier » ou « Déplacer » dans la barre
  bleue (elle défile vers la droite) → choisir le dossier de destination (« Nouveau dossier » possible) → « Copier ici » /
  « Déplacer ici ». Un homonyme devient « nom (1) » ; un dossier ne peut pas être mis dans lui-même.
- **Images** : balayer vers la gauche / la droite pour passer à l'image suivante / précédente (même dossier ou même catégorie).
- **Vidéo et audio** : balayer vers la gauche / la droite = média suivant / précédent (liste de lecture du dossier, aussi
  depuis la notification) ; balayer vers le haut / le bas = volume ; double toucher à gauche / à droite = −10 s / +10 s ;
  toucher = afficher / masquer les commandes. Même chose pour les fichiers lus depuis l'autre téléphone.

## Lecture, ouverture depuis d'autres applis, partage
- **Lecture en arrière-plan** (service Media3, `PlaybackService`) : notification de lecture dans la barre d'état
  (icône LinkShare, titre, lecture/pause/avance), commandes sur l'écran verrouillé, la lecture continue écran éteint ou
  appli quittée avec Accueil (vidéo comme audio). Le Wi-Fi reste actif écran éteint, donc un flux venant de l'autre
  téléphone ne se coupe pas. Toucher la notification rouvre l'appli. La flèche retour du lecteur arrête la lecture.
  Le nom d'un fichier du dossier sécurisé n'est pas affiché sur l'écran verrouillé.
- **Appli par défaut / « Ouvrir avec »** : LinkShare se déclare pour vidéo, audio, image, texte (fichiers locaux, `content://`
  ou `file://`), vidéo/audio en streaming (liens http/https), dossiers, Téléchargements et « Parcourir » (Réglages › Stockage).
  Pour en faire l'appli par défaut : ouvrir un fichier depuis une autre appli, choisir LinkShare puis « Toujours »
  (ou Réglages › Applis › LinkShare › Ouvrir par défaut).
- **Partager** (menu Android) fichiers et dossiers : appui long pour sélectionner, puis « Partager ». Les dossiers partent
  en ZIP (un ZIP par dossier). Aussi disponible dans le menu ⋮ des récents (fichiers).
- **Logo** : `res/drawable/ic_launcher_*` (icône adaptative + monochrome), `ic_logo` (appli, lecteur audio), `ic_stat_logo`
  (barre d'état) ; sources dans `branding/` (SVG + PNG 512).

## Paramètres, coffre et corbeille
- **Paramètres** : toucher l'en-tête de l'accueil (logo + « LinkShare / Explorateur de fichiers », engrenage à droite).
- **Verrouillage du coffre** (Paramètres › Sécurité) : par défaut le verrouillage du téléphone ; on peut définir un **schéma** ou un **code**
  propres au coffre (stockés en PBKDF2 salé, 30 s d'attente après 5 échecs). Pour ouvrir ce réglage et le changer, l'appli demande
  d'abord l'**empreinte du verrouillage d'écran** du téléphone (ou son code si l'empreinte échoue). Option « Ouvrir aussi avec l'empreinte » :
  elle utilise les doigts enregistrés dans le téléphone (Android ne permet pas d'enregistrer une empreinte propre à l'appli).
- **Corbeille** (Paramètres › Fichiers) : « Suppr. » place les éléments dans la corbeille (dossier caché `.LinkShare-Corbeille`) ;
  restauration à l'emplacement d'origine, suppression définitive ou « Vider » ; vidée automatiquement après 30 jours.
- **Luminosité** : dans le lecteur vidéo / audio, balayer vers le haut / le bas sur la **moitié gauche** de l'écran règle la luminosité,
  sur la **moitié droite** le volume.

## Dossier sécurisé (coffre)
- **Fichiers et dossiers** : appui long dans l'explorateur, puis « Sécurisé ». Un dossier entier est rangé avec son contenu, et on
  peut l'ouvrir dans le coffre (flèche retour = dossier parent, puis verrouillage). Les éléments rangés disparaissent aussitôt des
  galeries et des catégories.
- **Grille par défaut** (bouton en haut à droite pour passer en liste) : dossiers en grandes cases, fichiers en miniatures.
- **Tri** (bouton en haut à droite) : nom, date, taille, type, dans les deux sens, plus « Tout sélectionner ». Le tri du coffre est
  indépendant de celui de l'explorateur.
- **Restaurer** remet chaque élément **dans le dossier d'où il vient** (le dossier est recréé s'il n'existe plus ; un homonyme devient
  « nom (1) »). L'emplacement d'origine est mémorisé à la mise au coffre dans `files/vault_index.properties` (hors du coffre). Les
  éléments rangés avec une ancienne version, dont l'origine est inconnue, vont dans `Download/Restauré du coffre`.

## Réseau
Même Wi-Fi, ou B connecté au point d'accès de A (le plus rapide, sans routeur).

## À faire ensuite
- TLS (certificat auto-signé épinglé dans le QR) : actuellement HTTP + jeton aléatoire de 192 bits.
- Wi-Fi Direct (WifiP2pManager) pour une connexion sans routeur ni hotspot manuel.
- Choix des dossiers partagés + écran de consentement / révocation.
- Visionneuse texte/PDF, reprise des transferts, installation directe des APK.
