import * as THREE from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
const $=id=>document.getElementById(id),R=(a,b)=>a+Math.random()*(b-a),pick=a=>a[Math.random()*a.length|0],cl=(v,a,b)=>Math.max(a,Math.min(b,v)),H=Math.hypot;
const D=await (await fetch('data/abidjan.json')).json(),N=D.nodes,[X0,Z0,X1,Z1]=D.b;
const rend=new THREE.WebGLRenderer({antialias:true});rend.setSize(innerWidth,innerHeight);document.body.prepend(rend.domElement);
const scene=new THREE.Scene();scene.background=new THREE.Color(0x9ecbe8);scene.fog=new THREE.Fog(0x9ecbe8,80,420);
const cam=new THREE.PerspectiveCamera(65,innerWidth/innerHeight,.5,900);
const hemi=new THREE.HemisphereLight(0xffffff,0x887755,1.2);scene.add(hemi);const sun=new THREE.DirectionalLight(0xfff2d0,1.5);sun.position.set(100,200,60);scene.add(sun);
const mat=c=>new THREE.MeshStandardMaterial({color:c});
const gr=new THREE.Mesh(new THREE.PlaneGeometry(4000,4000),mat(0x9a8a62));gr.rotation.x=-Math.PI/2;scene.add(gr);
// routes
const pos=[],adj=N.map(()=>[]),nm=[],big=[];
for(const r of D.roads){const w=r.w/2;for(let i=0;i<r.n.length;i++){const a=N[r.n[i]];nm[r.n[i]]=r.name||nm[r.n[i]];if(r.w>=7)big.push(r.n[i]);if(i<r.n.length-1){const b=N[r.n[i+1]];const l=H(b[0]-a[0],b[1]-a[1])||1,px=-(b[1]-a[1])/l*w,pz=(b[0]-a[0])/l*w;
pos.push(a[0]+px,.05,a[1]+pz,a[0]-px,.05,a[1]-pz,b[0]+px,.05,b[1]+pz,b[0]+px,.05,b[1]+pz,a[0]-px,.05,a[1]-pz,b[0]-px,.05,b[1]-pz);adj[r.n[i]].push(r.n[i+1]);adj[r.n[i+1]].push(r.n[i])}}}
const rg=new THREE.BufferGeometry();rg.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));scene.add(new THREE.Mesh(rg,new THREE.MeshBasicMaterial({color:0x2c2c30,side:2})));
// bâtiments + collisions
const CS=60,grid=new Map(),pal=[0xe8d9b5,0xd9a066,0xcfcfcf,0xb5c9a0,0xe0b0a0,0xa9b8c9];
for(const bd of D.buildings){const sh=new THREE.Shape(bd.p.map(p=>new THREE.Vector2(p[0],-p[1])));const g=new THREE.ExtrudeGeometry(sh,{depth:bd.h,bevelEnabled:false});g.rotateX(-Math.PI/2);scene.add(new THREE.Mesh(g,mat(pick(pal))));
 const xs=bd.p.map(p=>p[0]),zs=bd.p.map(p=>p[1]);bd.x0=Math.min(...xs);bd.x1=Math.max(...xs);bd.z0=Math.min(...zs);bd.z1=Math.max(...zs);
 for(let i=Math.floor((bd.x0-4)/CS);i<=Math.floor((bd.x1+4)/CS);i++)for(let j=Math.floor((bd.z0-4)/CS);j<=Math.floor((bd.z1+4)/CS);j++){const k=i+','+j;(grid.get(k)||grid.set(k,[]).get(k)).push(bd)}}
const inside=(p,P)=>{let c=false;for(let i=0,j=P.length-1;i<P.length;j=i++)if((P[i][1]>p.z)!=(P[j][1]>p.z)&&p.x<(P[j][0]-P[i][0])*(p.z-P[i][1])/(P[j][1]-P[i][1])+P[i][0])c=!c;return c};
function pushOut(p,r){let hit=false;for(const b of grid.get(Math.floor(p.x/CS)+','+Math.floor(p.z/CS))||[]){if(p.x<b.x0-r||p.x>b.x1+r||p.z<b.z0-r||p.z>b.z1+r)continue;
 let best=1e9,bx=0,bz=0;const P=b.p;for(let i=0;i<P.length;i++){const a=P[i],c=P[(i+1)%P.length],dx=c[0]-a[0],dz=c[1]-a[1];const t=cl(((p.x-a[0])*dx+(p.z-a[1])*dz)/(dx*dx+dz*dz||1),0,1),qx=a[0]+dx*t,qz=a[1]+dz*t,d=H(p.x-qx,p.z-qz);if(d<best){best=d;bx=qx;bz=qz}}
 const ins=inside(p,P);if(ins||best<r){let nx=p.x-bx,nz=p.z-bz;const l=H(nx,nz)||1;nx/=l;nz/=l;if(ins){nx=-nx;nz=-nz}const k=ins?best+r:r-best;p.x+=nx*k;p.z+=nz*k;hit=true}}return hit}
const statics=[];function circ(p,q,r){const d=H(p.x-q.x,p.z-q.z);if(d<r&&d>0){const k=(r-d)/d;p.x+=(p.x-q.x)*k;p.z+=(p.z-q.z)*k;return true}return false}
// modèles
const gl=new GLTFLoader();function load(u,len,cb){gl.load(u,g=>{const m=g.scene,w=new THREE.Group();let b=new THREE.Box3().setFromObject(m),s=b.getSize(new THREE.Vector3());if(s.x>s.z)m.rotation.y=Math.PI/2;w.add(m);b.setFromObject(w);s=b.getSize(new THREE.Vector3());m.scale.setScalar(len/s.z);b.setFromObject(w);const c=b.getCenter(new THREE.Vector3());m.position.set(-c.x,-b.min.y,-c.z);cb(w)},0,()=>{})}
function mkCar(col){const g=new THREE.Group(),b=new THREE.Mesh(new THREE.BoxGeometry(1.9,.8,4.2),mat(col));b.position.y=.7;const c=new THREE.Mesh(new THREE.BoxGeometry(1.6,.6,2.2),mat(0x223344));c.position.set(0,1.3,-.2);g.add(b,c);scene.add(g);return g}
const pv=new THREE.Group();scene.add(pv);pv.add(mkCar(0xd62828));let pm=pv.children[0];scene.remove(pm);
load('models/taxi.glb',4.4,w=>{pv.clear();pm=w;pv.add(w)});let copModel=null;load('models/police.glb',4.6,w=>copModel=w);
// état
const G={money:5000,fuel:100,energy:100,dmg:0,rep:50,love:0,heat:0,drunk:0},P={x:0,z:0,h:0,v:0,s:0};let paused=true,T=0,M=null,cool={},k={};
const near=(x,z,l)=>{let b=0,bd=1e9;for(const i of l){const d=H(N[i][0]-x,N[i][1]-z);if(d<bd){bd=d;b=i}}return b};
const rnode=(x,z,a,b)=>{for(let i=0;i<200;i++){const n=pick(big),d=H(N[n][0]-x,N[n][1]-z);if(d>a&&d<b)return n}return pick(big)};
const s0=rnode(0,0,0,150);P.x=N[s0][0];P.z=N[s0][1];{const a=N[adj[s0][0]]||[P.x,P.z+1];P.h=Math.atan2(a[0]-P.x,a[1]-P.z)}
const msg=t=>{const d=document.createElement('div');d.textContent=t;$('log').prepend(d);setTimeout(()=>d.remove(),6000)};
const spend=n=>G.money>=n?(G.money-=n,true):(msg('Pas assez de FCFA !'),false);
function say(t,x,ch){paused=true;$('dlg').style.display='flex';$('dt').textContent=t;$('dx').innerHTML=x;$('dc').innerHTML='';ch.forEach(([l,f])=>{const b=document.createElement('button');b.textContent=l;b.onclick=()=>{$('dlg').style.display='none';paused=false;f&&f()};$('dc').append(b)})}
// marqueurs
function marker(x,z,col,txt){const g=new THREE.Group(),m=new THREE.Mesh(new THREE.CylinderGeometry(6,6,.4,24),new THREE.MeshBasicMaterial({color:col,transparent:true,opacity:.5})),b=new THREE.Mesh(new THREE.CylinderGeometry(.5,.5,35,8),new THREE.MeshBasicMaterial({color:col,transparent:true,opacity:.4}));b.position.y=17;g.add(m,b);g.position.set(x,.2,z);scene.add(g);if(txt){const c=document.createElement('canvas');c.width=256;c.height=48;const q=c.getContext('2d');q.fillStyle='#000a';q.fillRect(0,0,256,48);q.fillStyle='#fff';q.font='22px sans-serif';q.textAlign='center';q.fillText(txt,128,32);const s=new THREE.Sprite(new THREE.SpriteMaterial({map:new THREE.CanvasTexture(c)}));s.scale.set(16,3,1);s.position.y=12;g.add(s)}return g}
const spots=[];const nmq=['Maquis Chez Tantie Awa','Maquis Le Parrain','Chez Maman Adjoua','Maquis La Reine'],fuelN=['Station Total','Station Petroci'];let ci=0,fi=0;
for(const q of D.pois){const n=near(q.p[0],q.p[1],big);const f=q.k=='fuel';spots.push({k:f?'fuel':'maquis',x:N[n][0],z:N[n][1],n:q.n||(f?pick(fuelN):nmq[ci++%4])})}
if(!spots.some(s=>s.k=='fuel'))for(let i=0;i<2;i++){const n=pick(big);spots.push({k:'fuel',x:N[n][0],z:N[n][1],n:fuelN[i]})}
while(spots.filter(s=>s.k=='maquis').length<3){const n=pick(big);spots.push({k:'maquis',x:N[n][0],z:N[n][1],n:nmq[ci++%4]})}
spots.forEach(s=>marker(s.x,s.z,s.k=='fuel'?0xff3030:0xffaa00,(s.k=='fuel'?'⛽ ':'🍗 ')+s.n));
const mk=marker(0,-9999,0x30ff60);
// barrages
const cps=[];for(let i=0;i<5;i++){const n=rnode(P.x,P.z,150,900),a=N[n],b=N[adj[n][0]]||[a[0],a[1]+1],l=H(b[0]-a[0],b[1]-a[1])||1,dx=(b[0]-a[0])/l,dz=(b[1]-a[1])/l,px=-dz,pz=dx;
 for(let o=-5;o<=5;o+=1.6){if(Math.abs(o)<2.3)continue;const c=new THREE.Mesh(new THREE.ConeGeometry(.35,.8,8),mat(0xff6a00));c.position.set(a[0]+px*o,.4,a[1]+pz*o);scene.add(c);statics.push({x:a[0]+px*o,z:a[1]+pz*o,r:.6})}
 for(const o of[-2.8,2.8]){const c=new THREE.Mesh(new THREE.BoxGeometry(.6,1.8,.6),mat(0x1d3b8b));c.position.set(a[0]+px*o,.9,a[1]+pz*o);scene.add(c);statics.push({x:a[0]+px*o,z:a[1]+pz*o,r:.7})}
 cps.push({x:a[0],z:a[1],n:nm[n]});marker(a[0],a[1],0x3060ff,'🚓 Barrage')}
// trafic
const adjs=adj.map(a=>a),traf=[];for(let i=0;i<28;i++){const a=pick(big);if(!adj[a].length)continue;traf.push({a,b:pick(adj[a]),t:Math.random(),stun:0,x:0,z:0,m:mkCar(pick([0xffffff,0x2255aa,0x111111,0x888888,0xd62828,0x44aa44,0xf5c400]))})}
function updTraf(dt){for(const c of traf){const A=N[c.a],B=N[c.b],l=H(B[0]-A[0],B[1]-A[1])||1,fx=(B[0]-A[0])/l,fz=(B[1]-A[1])/l;let sp=8;const dx=P.x-c.x,dz=P.z-c.z,al=dx*fx+dz*fz,la=Math.abs(-dx*fz+dz*fx);if(al>0&&al<9&&la<2.8)sp=0;c.stun-=dt;if(c.stun>0)sp=0;c.t+=sp*dt/l;
 if(c.t>=1){const o=adj[c.b].filter(x=>x!=c.a);const nx=o.length?pick(o):c.a;c.a=c.b;c.b=nx;c.t=0}
 c.x=A[0]+(B[0]-A[0])*c.t-fz*2.2;c.z=A[1]+(B[1]-A[1])*c.t+fx*2.2;c.m.position.set(c.x,0,c.z);c.m.rotation.y=Math.atan2(fx,fz)}}
// police
const cops=[];let catchT=0,farT=0;
function chase(){G.heat=1;if(cops.length)return;msg('🚨 Course-poursuite ! Semez la police !');for(let i=0;i<2;i++){const n=rnode(P.x,P.z,70,130),m=copModel?copModel.clone():mkCar(0xffffff),l=new THREE.Mesh(new THREE.BoxGeometry(1.2,.25,.4),new THREE.MeshBasicMaterial({color:0xff0000}));l.position.y=1.8;m.add(l);scene.add(m);cops.push({x:N[n][0],z:N[n][1],h:0,v:0,m,l})}}
function updCops(dt){if(!cops.length)return;let d0=1e9;for(const c of cops){const dx=P.x-c.x,dz=P.z-c.z,d=H(dx,dz);d0=Math.min(d0,d);let df=Math.atan2(dx,dz)-c.h;df=Math.atan2(Math.sin(df),Math.cos(df));c.h+=cl(df,-1,1)*2.2*dt;c.v=Math.min(c.v+7*dt,20);const o={x:c.x,z:c.z};c.x+=Math.sin(c.h)*c.v*dt;c.z+=Math.cos(c.h)*c.v*dt;if(pushOut(c,1.3))c.v*=.6;for(const s of statics)circ(c,s,s.r+1.2);for(const t of traf)circ(c,t,3);
 if(circ(P,c,3.2)){P.v*=.7;G.dmg+=1.5;msg('💥 Choc avec la police')}c.m.position.set(c.x,0,c.z);c.m.rotation.y=c.h;c.l.material.color.setHex(Math.floor(T*5)%2?0xff0000:0x0000ff)}
 if(d0<6&&Math.abs(P.v)<9)catchT+=dt;else catchT=Math.max(0,catchT-dt);if(catchT>2.5)arrest();farT=d0>150?farT+dt:0;if(farT>8){cops.forEach(c=>scene.remove(c.m));cops.length=0;G.heat=0;msg('✅ Vous avez semé la police !')}}
function clearCops(){cops.forEach(c=>scene.remove(c.m));cops.length=0;G.heat=0;catchT=0;P.v=0}
function arrest(){clearCops();say('🚓 Arrêté !','« Descends de là ! Délit de fuite, refus d\'obtempérer… ça fait <b>15 000 FCFA</b>. »',[['Payer l\'amende (15 000)',()=>{if(spend(15000))msg('Amende payée');else{G.money=0;G.rep-=10}}],['Négocier : « Chef, on est ensemble… » (5 000)',()=>{if(!spend(5000))return;if(Math.random()<.55)say('Policier','« Bon… la prochaine fois je ne te rate pas. »',[['Merci chef',0]]);else{G.money=Math.max(0,G.money-15000);say('Policier','« Tu me prends pour un enfant ? Ça fait 15 000 en plus ! »',[['Aïe…',0]])}}],['Pleurer et supplier',()=>{if(Math.random()<.3)msg('Il a pitié de vous.');else{G.money=Math.floor(G.money*.7);G.rep-=5;msg('Il vous prend 30% de votre argent.')}}]])}
function barrage(c){cool['cp'+c.x]=100;const f=Math.random()<.5||G.drunk>8;say('🚓 Barrage de police','« Bonjour monsieur, contrôle. Vos papiers ! »'+(f?'<br>Il fronce les sourcils : <b>assurance expirée</b>.':''),[['Présenter les papiers',()=>f?offense(5000):say('Policier','« C\'est bon, circulez. »',[['Merci chef',0]])],['Discuter avec le policier',()=>talk(f?5000:0)],['Glisser un « café » discret',()=>bribe(f?5000:0)],['Foncer !',chase]])}
const offense=f=>say('Contravention',`« ${f} FCFA, ou on va au commissariat. »`,[['Payer '+f,()=>spend(f)],['Négocier / arrangement',()=>bribe(f)]]);
function talk(f){say('Policier',pick(['« Tu es de quel quartier, mon frère ? Moi c\'est Abobo. »','« Ça va ? Le match d\'hier là, l\'arbitre a volé les Éléphants ! »','« La vie est dure, chef. La ration du jour n\'est pas encore sortie… »']),[['Parler foot avec lui (gratuit)',()=>Math.random()<.5?say('Policier','« Tu es un frère ! Allez, passe. »',[['Merci !',()=>G.rep+=2]]):offense(f||2000)],['Offrir 500 FCFA pour son « déjeuner »',()=>{if(spend(500))Math.random()<.85?msg('« Merci mon frère, bonne route. »'):offense(f||3000)}],['Retour',()=>barrage({x:0})]])}
function bribe(f){say('Arrangement','Combien glissez-vous discrètement ?',[500,1000,2000].map(a=>[a+' FCFA',()=>{if(!spend(a))return;const ch=(a==500?.4:a==1000?.65:.85)+(f?0:.1);if(Math.random()<ch)msg('« Ça va, passe. » (arrangement réussi)');else{G.rep-=3;say('Policier','« Tu veux m\'acheter ?! Corruption d\'agent ! »',[['Oups…',()=>spend(f?f*1.5:6000)||chase()]])}}]))}
// accident
function crash(t){if(cool.acc>0)return;cool.acc=25;t.stun=4;say('💥 Accident !','Vous avez accroché une voiture. Le conducteur sort en criant : « Tu ne vois pas ou quoi ?! »',[['Constat à l\'amiable (3 000)',()=>spend(3000)],['Négocier « à l\'ivoirienne »',()=>Math.random()<.6?(spend(1500),msg('On s\'est serré la main.')):(spend(6000),G.rep-=3)],['Prendre la fuite !',()=>{G.rep-=10;chase()}]])}
// lieux
function spot(s){cool[s.n]=60;if(s.k=='fuel')return say('⛽ '+s.n,'Faire le plein ?',[[`Plein (${Math.round((100-G.fuel)*60)} FCFA)`,()=>{if(spend(Math.round((100-G.fuel)*60)))G.fuel=100}],['Partir',0]]);
 say('🍗 '+s.n,'Ambiance coupé-décalé, ça sent le poulet braisé !',[['Poulet braisé + alloco (2 500)',()=>{if(spend(2500))G.energy=Math.min(100,G.energy+60)}],['Bière Solibra (800)',()=>{if(spend(800)){G.drunk+=30;msg('🍺 Attention au volant…')}}],['Draguer la serveuse (cadeau 1 000)',()=>{if(!spend(1000))return;if(Math.random()<.5){G.love+=2;say('Serveuse','« Hmm… tu es mignon. Voici mon numéro. »',[['❤️',0]])}else{G.rep-=2;say('Serveuse','« Mon frère, j\'ai déjà un gars. » (lapin)',[['Aïe',0]])}}],['Danser sur du coupé-décalé',()=>{G.energy=Math.min(100,G.energy+10);G.love+=.5}],['Partir',0]])}
// missions
const nms=['Koffi','Awa','Yao','Adjoua','Moussa','Aya','Kouassi','Fatou','Serge','Mariam'];let rideT=0;
function startMission(){const f=rnode(P.x,P.z,120,450),t=rnode(N[f][0],N[f][1],300,800),d=H(N[f][0]-N[t][0],N[f][1]-N[t][1]),taxi=Math.random()<.6;M={taxi,from:f,to:t,name:pick(nms),fem:Math.random()<.5,price:Math.round((600+d*4)/100)*100,limit:d/6+35,state:'go',dmg0:0};mk.position.set(N[f][0],.2,N[f][1]);msg(taxi?`🚖 ${M.name} veut une course !`:`📦 Colis à récupérer pour ${M.name}`)}
function haggle(){let o=Math.round(M.price*R(.6,.8)/100)*100,r=0;const ask=()=>say(M.name,`« Grand frère, ${nm[M.to]||'là-bas'}, je te donne ${o} FCFA. »<br><small>Tarif normal : ${M.price}</small>`,[[`Accepter ${o}`,()=>{M.price=o;beginRide()}],['Marchander (« c\'est le prix du goudron ! »)',()=>{r++;if(Math.random()<.75-r*.22){o=Math.round(Math.min(M.price*1.15,o*R(1.1,1.3))/100)*100;ask()}else say(M.name,'« Laisse, je prends woro-woro ! »',[['Tant pis',()=>{G.rep-=3;M=null;mk.position.y=-99;setTimeout(startMission,1500)}]])}],['Refuser la course',()=>{M=null;mk.position.y=-99;setTimeout(startMission,1500)}]]);ask()}
function beginRide(){M.state='ride';M.dmg0=G.dmg;M.t0=T;mk.position.set(N[M.to][0],.2,N[M.to][1]);msg('Direction : '+(nm[M.to]||'destination'));rideT=R(12,20)}
function rideChat(){if(!M.taxi)return;if(M.fem)say(M.name,'« Eh, tu conduis bien toi… tu es célibataire ? »',[['Draguer : « Pour toi je roule jusqu\'à Bassam »',()=>{Math.random()<.55?(G.love+=2,msg('❤️ Elle sourit et te donne son numéro')):msg('Elle rit : « Concentre-toi sur la route ! »')}],['Rester pro',0]]);else say(M.name,'« Mets-moi la radio, c\'est Magic System ! »',[['Mettre du coupé-décalé',()=>G.rep+=2],['Silence',0]])}
function endRide(){if(M.taxi&&!M.sc&&Math.random()<.12){M.sc=1;return say('💵 Billet suspect','Le client te tend un billet qui a l\'air faux (brouteur ?).',[['Vérifier le billet',()=>{if(Math.random()<.7){msg('Faux billet repéré, il paie en vrai !');endRide()}else{G.rep-=2;msg('Il s\'enfuit en courant !');M=null;mk.position.y=-99;setTimeout(startMission,1500)}}],['Accepter sans regarder',()=>{M.price=0;G.money=Math.max(0,G.money-1000);endRide()}]])}const late=T-M.t0>M.limit,d=G.dmg-M.dmg0;let p=M.price*(late?.7:1)*(d>15?.8:1),tip=(!late&&d<5&&M.taxi)?500:0;if(!M.taxi)p+=300;G.money+=Math.round(p+tip);G.rep+=late?-2:3;msg(`💰 +${Math.round(p+tip)} FCFA${late?' (en retard)':''}`);M=null;mk.position.y=-99;setTimeout(startMission,2500)}
function rnd(){const e=pick([0,1,2,3,4,5]);if(e==3)return say('🌹 Rendez-vous','Ta chérie t\'attend au maquis ce soir.',[['Offrir un cadeau (2 000)',()=>{if(spend(2000)){G.love+=3;msg('❤️ Elle est ravie !')}}],['Oublier le rendez-vous',()=>G.love-=2]]);if(e==4){rain=60;return msg('🌧️ Il se met à pleuvoir : route glissante !')}if(e==5)return say('Un gbaka te coupe la route','Le gbaka s\'arrête net devant toi ! « Adjamé Adjamé ! » crie le receveur.',[['Klaxonner et attendre',0],['Dépasser en force',()=>{G.dmg+=8;G.rep-=1}]]);if(e==0)say('📞 Ta chérie appelle','« Tu es où encore ?! Tu ne m\'aimes plus ? »',[['Décrocher et rassurer',()=>G.love+=1],['Ignorer',()=>G.love-=1]]);else if(e==1)say('Un woro-woro te klaxonne','Le chauffeur crie : « Doucement le taxi ! »',[['Répondre',()=>G.rep-=1],['Sourire',0]]);else say('Pétrole… Essence !','Un jeune vend de l\'essence en bidon au bord de la route.',[['Acheter 3 000 (+30%)',()=>spend(3000)&&(G.fuel=Math.min(100,G.fuel+30))],['Non merci',0]])}
// audio + entrées
let ac,osc,gn,mg,hg;$('go').onclick=()=>{$('start').style.display='none';paused=false;try{ac=new AudioContext();mg=ac.createGain();mg.gain.value=muted?0:1;mg.connect(ac.destination);const lp=ac.createBiquadFilter();lp.type='lowpass';lp.frequency.value=300;osc=ac.createOscillator();gn=ac.createGain();osc.type='triangle';gn.gain.value=.015;osc.connect(lp).connect(gn).connect(mg);osc.start();hg=ac.createGain();hg.gain.value=0;[420,520].forEach(f=>{const o=ac.createOscillator();o.frequency.value=f;o.connect(hg);o.start()});hg.connect(mg)}catch(e){}startMission()};
addEventListener('keydown',e=>{k[e.code]=1;if(e.code=='KeyC')cock=!cock;if(e.code=='KeyV')pm.rotation.y+=Math.PI;if(e.code=='KeyR'){const n=near(P.x,P.z,big);P.x=N[n][0];P.z=N[n][1];P.v=0}if(e.code=='KeyH'||e.code=='Space')e.preventDefault()});addEventListener('keyup',e=>k[e.code]=0);
addEventListener('resize',()=>{rend.setSize(innerWidth,innerHeight);cam.aspect=innerWidth/innerHeight;cam.updateProjectionMatrix()});
// minimap
const rc=document.createElement('canvas');rc.width=X1-X0;rc.height=Z1-Z0;{const q=rc.getContext('2d');q.fillStyle='#4a4535';q.fillRect(0,0,rc.width,rc.height);q.strokeStyle='#bbb';q.lineCap='round';for(const r of D.roads){q.lineWidth=r.w*.8;q.beginPath();r.n.forEach((i,j)=>j?q.lineTo(N[i][0]-X0,N[i][1]-Z0):q.moveTo(N[i][0]-X0,N[i][1]-Z0));q.stroke()}}
const mq=$('mm').getContext('2d');function minimap(){const s=.7;mq.clearRect(0,0,190,190);mq.save();mq.beginPath();mq.arc(95,95,95,0,7);mq.clip();mq.drawImage(rc,95-(P.x-X0)*s,95-(P.z-Z0)*s,rc.width*s,rc.height*s);const dot=(x,z,c,r=4)=>{mq.fillStyle=c;mq.beginPath();mq.arc(95+(x-P.x)*s,95+(z-P.z)*s,r,0,7);mq.fill()};spots.forEach(o=>dot(o.x,o.z,o.k=='fuel'?'#f33':'#fa0'));cps.forEach(c=>dot(c.x,c.z,'#36f'));cops.forEach(c=>dot(c.x,c.z,'#f0f',5));if(M){const n=N[M.state=='go'?M.from:M.to];dot(n[0],n[1],'#3f6',6)}mq.translate(95,95);mq.rotate(-P.h);mq.fillStyle='#ff0';mq.beginPath();mq.moveTo(0,8);mq.lineTo(-5,-5);mq.lineTo(5,-5);mq.fill();mq.restore()}
// boucle
let last=performance.now();
function loop(now){requestAnimationFrame(loop);const dt=Math.min(.05,(now-last)/1e3);last=now;if(!paused)step(dt);rend.render(scene,cam)}
function step(dt){T+=dt;for(const c in cool)cool[c]-=dt;
 const gp=(navigator.getGamepads?.()||[]).find(g=>g);let th=(k.KeyW||k.ArrowUp||k.KeyZ)?1:0,br=(k.KeyS||k.ArrowDown)?1:0,st=((k.KeyA||k.KeyQ||k.ArrowLeft)?1:0)-((k.KeyD||k.ArrowRight)?1:0),hb=k.Space,hn=k.KeyH;
 if(gp){const dz=v=>Math.abs(v)<.08?0:v;st-=dz(gp.axes[0]||0);th=Math.max(th,gp.buttons[7]?.value||0,dz(-(gp.axes[1]||0))>0?-gp.axes[1]:0);br=Math.max(br,gp.buttons[6]?.value||0,(gp.axes[1]||0)>.15?gp.axes[1]:0);hb=hb||gp.buttons[1]?.pressed;hn=hn||gp.buttons[0]?.pressed}
 th=Math.max(th,tc.th);br=Math.max(br,tc.br);st+=tc.st;hn=hn||tc.hn;st=cl(st+Math.sin(T*3)*G.drunk*.004,-1,1);P.s+=(st-P.s)*Math.min(1,dt*6);
 const lim=(G.energy<15?.7:1)*24;let a=0;if(G.fuel<=0){a=-3;if(!cool.out){cool.out=60;say('⛽ Panne sèche !','Plus d\'essence. Un gamin vend un bidon.',[['Acheter 3 000 FCFA',()=>{if(spend(3000))G.fuel=40}],['Attendre (dépanneur)',()=>{G.fuel=25;G.money=Math.max(0,G.money-1000)}]])}}else a=th*9-(P.v>0?br*14:0)+(br&&P.v<=0.1?-4*br:0);
 P.v+=a*dt;if(!th&&!br)P.v*=1-.35*dt;if(hb)P.v*=1-3*dt;P.v=cl(P.v,-7,lim);
 P.h+=P.s*.55*(P.v/3.6)*dt;const f={x:Math.sin(P.h),z:Math.cos(P.h)};let hit=false;P.x+=f.x*P.v*dt;P.z+=f.z*P.v*dt;
 for(const o of[1.3,-1.3]){const q={x:P.x+f.x*o,z:P.z+f.z*o},x0=q.x,z0=q.z;if(pushOut(q,1)){P.x+=q.x-x0;P.z+=q.z-z0;hit=true}}
 for(const s of statics)if(circ(P,s,s.r+1))hit=true;
 for(const t of traf)if(circ(P,t,3.3)){hit=true;if(Math.abs(P.v)>6)crash(t);t.stun=Math.max(t.stun,1.5)}
 P.x=cl(P.x,X0,X1);P.z=cl(P.z,Z0,Z1);if(hit){if(Math.abs(P.v)>4){G.dmg+=Math.abs(P.v)*.25;msg('💥 Choc !')}P.v*=.35}
 G.fuel=Math.max(0,G.fuel-Math.abs(P.v)*dt*.004);G.energy=Math.max(0,G.energy-dt*.03);G.drunk=Math.max(0,G.drunk-dt*.4);G.heat?0:0;
 if(G.dmg>=100){G.dmg=0;G.money=Math.max(0,G.money-15000);P.v=0;say('🔧 Épave !','Votre taxi est HS. Garage de Treichville : -15 000 FCFA.',[['Réparer',0]])}
 const vs=Math.abs(P.v);
 if(!G.heat)for(const c of cps){const d=H(P.x-c.x,P.z-c.z);if(d<14&&(cool['cp'+c.x]||0)<=0&&vs<4){barrage(c);return}if(d<7&&vs>=6&&(cool['cp'+c.x]||0)<=0){cool['cp'+c.x]=60;msg('🚨 Vous avez forcé le barrage !');chase()}}
 if(!G.heat)for(const s of spots)if(H(P.x-s.x,P.z-s.z)<9&&vs<2&&(cool[s.n]||0)<=0){spot(s);return}
 if(M){const n=N[M.state=='go'?M.from:M.to];if(H(P.x-n[0],P.z-n[1])<9&&vs<2.5){if(M.state=='go'){if(M.taxi){haggle();M.state='talk'}else{beginRide();msg('📦 Colis récupéré')}}else endRide()}if(M.state=='ride'&&M.taxi&&(rideT-=dt)<0){rideT=R(25,40);rideChat()}}
 if(!cool.ev)cool.ev=R(50,90);if(cool.ev<=0&&!G.heat){cool.ev=R(60,100);rnd()}
 updTraf(dt);updCops(dt);updPeds(dt);updEnv(dt);
 pv.position.set(P.x,0,P.z);pv.rotation.y=P.h;const cx=P.x-f.x*9,cz=P.z-f.z*9;camUpd(f,dt,cx,cz);
 if(osc){osc.frequency.setTargetAtTime(32+vs*2.2+th*6,ac.currentTime,.1);gn.gain.setTargetAtTime(.01+.015*th,ac.currentTime,.1);hg.gain.setTargetAtTime(hn?.04:0,ac.currentTime,.03)}
 const tg=M&&N[M.state=='ride'?M.to:M.from];$('obj').innerHTML=M?(M.state=='ride'?(M.taxi?'🚖 Course':'📦 Livraison')+` pour ${M.name} → ${nm[M.to]||'destination'}<br>${Math.round(H(P.x-tg[0],P.z-tg[1]))} m • ${Math.max(0,Math.round(M.limit-(T-M.t0)))} s • ${M.price} FCFA`:`Allez chercher ${M.name} : ${Math.round(H(P.x-tg[0],P.z-tg[1]))} m (${nm[M.from]||'?'})`):'Cherchez une mission…';
 $('hud').innerHTML=`💰 ${Math.round(G.money)} FCFA<br>🚗 ${Math.round(vs*3.6)} km/h ⛽ ${Math.round(G.fuel)}%<br>🍗 ${Math.round(G.energy)}% 🔧 dégâts ${Math.round(G.dmg)}%<br>🕒 ${clock()} ${rain>0?'🌧️':''}<br>⭐ rép. ${Math.round(G.rep)} ❤️ ${Math.round(G.love)}${G.heat?'<br>🚨 RECHERCHÉ':''}${G.drunk>1?'<br>🍺 ivre':''}`;$('wh').style.transform=`rotate(${-P.s*120}deg)`;minimap()}
// ===== v2 : piétons, jour/nuit, pluie, cockpit =====
const peds=[];for(let i=0;i<45;i++){const a=pick(big);if(!adj[a].length)continue;const m=new THREE.Mesh(new THREE.CylinderGeometry(.3,.3,1.7,8),mat(pick([0xc0392b,0x2980b9,0xf1c40f,0x27ae60,0xecf0f1,0x8e44ad])));m.position.y=.85;scene.add(m);peds.push({a,b:pick(adj[a]),t:Math.random(),side:Math.random()<.5?6.5:-6.5,x:0,z:0,m,down:0})}
let hitCool=0;
function updPeds(dt){hitCool-=dt;for(const p of peds){const A=N[p.a],B=N[p.b],l=H(B[0]-A[0],B[1]-A[1])||1,fx=(B[0]-A[0])/l,fz=(B[1]-A[1])/l;
 if(p.down>0){p.down-=dt;p.m.rotation.z=1.5;p.m.position.y=.3;continue}p.m.rotation.z=0;p.m.position.y=.85;
 const d=H(P.x-p.x,P.z-p.z);p.t+=(d<7&&Math.abs(P.v)>3?0:1.4)*dt/l;
 if(p.t>=1){const o=adj[p.b].filter(x=>x!=p.a);const nx=o.length?pick(o):p.a;p.a=p.b;p.b=nx;p.t=0}
 p.x=A[0]+(B[0]-A[0])*p.t-fz*p.side;p.z=A[1]+(B[1]-A[1])*p.t+fx*p.side;p.m.position.x=p.x;p.m.position.z=p.z;
 if(d<2){if(Math.abs(P.v)>4&&hitCool<=0){p.down=8;hitCool=15;P.v*=.5;G.rep-=15;G.heat?0:say('😱 Piéton renversé !','Une foule se rassemble. Le piéton se relève en boitant.',[['Descendre l\'aider et payer 5 000 FCFA',()=>{spend(5000)||(G.rep-=5)}],['Prendre la fuite !',()=>{G.rep-=15;chase()}]])}else circ(P,p,1.9)}}}
const head=new THREE.SpotLight(0xfff0c0,0,80,.6,.5);head.position.set(0,1,1.5);const ht=new THREE.Object3D();ht.position.set(0,0,14);pv.add(head,ht);head.target=ht;
let rain=0,day=1;const cN=new THREE.Color(0x0a1030),cD=new THREE.Color(0x9ecbe8),cR=new THREE.Color(0x7a8591),cc=new THREE.Color();
const clock=()=>{const h=((T+60)/240%1)*24;return String(Math.floor(h)).padStart(2,'0')+':'+String(Math.floor(h%1*60)).padStart(2,'0')};
function updEnv(dt){day=cl(Math.sin(((T+60)/240%1)*2*Math.PI)*1.4+.35,0,1);if(rain>0){rain-=dt;if(P.v>18)P.v=18}
 cc.copy(cN).lerp(rain>0?cR:cD,day);scene.background.copy(cc);scene.fog.color.copy(cc);scene.fog.far=rain>0?200:420;hemi.intensity=.3+.9*day;sun.intensity=.1+1.4*day;head.intensity=(1-day)*400}
let cock=false;cam.near=.1;cam.updateProjectionMatrix();const ws=new THREE.Group();cam.add(ws);scene.add(cam);ws.position.set(0,-.38,-.75);ws.rotation.x=-.5;load('models/steering_wheel.glb',.38,w=>ws.add(w));
function camUpd(f,dt,cx,cz){pm.visible=!cock;ws.visible=cock;if(cock){cam.position.set(P.x+f.x*.2,1.3,P.z+f.z*.2);cam.lookAt(P.x+f.x*20,1.2,P.z+f.z*20);ws.rotation.z=-P.s*2.2}else{cam.position.lerp(new THREE.Vector3(cx,4.8,cz),Math.min(1,dt*5));cam.lookAt(P.x+f.x*6,1.5,P.z+f.z*6)}}
// ===== commandes tactiles =====
const tc={st:0,th:0,br:0,hn:0};let muted=false;
const hold=(id,k)=>{const e=$(id);e.addEventListener('pointerdown',ev=>{ev.preventDefault();e.setPointerCapture(ev.pointerId);tc[k]=1});['pointerup','pointercancel'].forEach(t=>e.addEventListener(t,()=>tc[k]=0))};
hold('bg','th');hold('bb','br');hold('bh','hn');
$('bc').onclick=()=>cock=!cock;$('bm').onclick=()=>{muted=!muted;if(mg)mg.gain.value=muted?0:1;$('bm').textContent=muted?'🔇':'🔊'};
const wh=$('wh'),wp=ev=>{const r=wh.getBoundingClientRect();tc.st=-cl((ev.clientX-(r.left+r.width/2))/(wh.offsetWidth*.5),-1,1)};
wh.addEventListener('pointerdown',ev=>{ev.preventDefault();wh.setPointerCapture(ev.pointerId);wp(ev)});wh.addEventListener('pointermove',ev=>{if(wh.hasPointerCapture(ev.pointerId))wp(ev)});['pointerup','pointercancel'].forEach(t=>wh.addEventListener(t,()=>tc.st=0));
requestAnimationFrame(loop);
