export default {base:'./',build:{target:'esnext',outDir:'dist'}}
