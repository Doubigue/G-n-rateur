import xml.etree.ElementTree as ET,json,math,random,glob
fs=sorted(glob.glob('osm/*.xml'));t=ET.parse(fs[0]).getroot();b=t.find('bounds')
for f in fs[1:]:t.extend(list(ET.parse(f).getroot()))
la0=(float(b.get('minlat'))+float(b.get('maxlat')))/2;lo0=(float(b.get('minlon'))+float(b.get('maxlon')))/2
K=111320;c=math.cos(math.radians(la0))
P=lambda la,lo:(round((lo-lo0)*K*c,1),round(-(la-la0)*K,1))
nd={};pois=[]
for n in t.iter('node'):
    nd[n.get('id')]=P(float(n.get('lat')),float(n.get('lon')))
    tg={x.get('k'):x.get('v') for x in n.findall('tag')}
    if tg.get('amenity') in('fuel','restaurant','bar','cafe','fast_food','pub','nightclub'):
        pois.append({'k':'fuel' if tg['amenity']=='fuel' else 'food','n':tg.get('name',''),'p':nd[n.get('id')]})
W={'motorway':14,'trunk':12,'primary':10,'secondary':9,'tertiary':8,'residential':7,'unclassified':7,'living_street':5,'service':5}
idx={};nodes=[];roads=[];bl=[]
for w in t.iter('way'):
    tg={x.get('k'):x.get('v') for x in w.findall('tag')};r=[x.get('ref') for x in w.findall('nd') if x.get('ref') in nd]
    h=tg.get('highway','').replace('_link','')
    if h in W and len(r)>1:
        ids=[]
        for q in r:
            if q not in idx:idx[q]=len(nodes);nodes.append(nd[q])
            ids.append(idx[q])
        roads.append({'w':W[h],'n':ids,'name':tg.get('name','')})
    elif 'building' in tg and len(r)>3:
        lv=tg.get('building:levels');hh=float(lv)*3.2 if lv and lv.replace('.','').isdigit() else random.uniform(6,16)
        bl.append({'p':[nd[q] for q in r[:-1]],'h':round(hh,1)})
xs=[p[0] for p in nodes];zs=[p[1] for p in nodes]
json.dump({'b':[min(xs)-60,min(zs)-60,max(xs)+60,max(zs)+60],'nodes':nodes,'roads':roads,'buildings':bl,'pois':pois},open('public/data/abidjan.json','w'),separators=(',',':'))
print(len(nodes),len(roads),len(bl),len(pois))
