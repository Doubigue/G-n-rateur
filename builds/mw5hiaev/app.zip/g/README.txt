TAXI ABIDJAN (Three.js + Vite + GitHub Actions)

GitHub :
 1. Créer un dépôt, y pousser tout ce dossier (branche main).
 2. Settings > Pages > Source : "GitHub Actions".
 3. Chaque push compile (python conv.py -> npm run build) et publie sur GitHub Pages.
    Le dossier compilé est aussi téléchargeable dans Actions > artefact "taxi-abidjan-dist".

Local : python3 conv.py && npm install && npm run dev   (http://localhost:5173)
Build : npm run build -> dist/ (three.js inclus, plus de CDN)

Plus de quartiers : exporter des zones depuis openstreetmap.org, déposer les .xml dans osm/, pousser.
Commandes : ZQSD/flèches, Espace frein à main, H klaxon, R remise sur route, C cockpit, V inverser le modèle.
Manette/volant : axe 0 direction, gâchettes ou axe 1 pédales, A klaxon.
