package com.dlvibe.dlphone

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.text.TextPaint
import android.text.TextUtils
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.core.graphics.PathParser
import kotlin.math.hypot

/**
 * Îlot d'appel autour de la caméra frontale.
 * - Touche rouge = refuser, touche verte = répondre
 * - 1 doigt maintenu = refuser (anneau rouge), 2 doigts = répondre (anneau vert)
 * - Toucher le centre = ouvrir / réduire l'îlot
 */
class IslandModel(val label: String, a: String, b: String, back: String, val effect: Int) {
    val first = Color.parseColor(a)
    val second = Color.parseColor(b)
    val background = Color.parseColor(back)
}

val ISLAND_MODELS = listOf(
    IslandModel("Classique", "#1FB45A", "#E5484D", "#000000", 0),
    IslandModel("Néon", "#00F0FF", "#FF2BD6", "#0A0014", 1),
    IslandModel("Océan", "#2EE6C5", "#2F7BFF", "#03142B", 2),
    IslandModel("Galaxie", "#A98BFF", "#4FC3FF", "#0C0824", 3),
    IslandModel("Feu", "#FFD23F", "#FF4E1F", "#1A0600", 4),
    IslandModel("Or", "#FFE9A8", "#C99700", "#12100A", 5),
    IslandModel("Cœurs", "#FF8FB8", "#FF2D6F", "#20040F", 6),
    IslandModel("Matrix", "#39FF14", "#0B8F2A", "#000A02", 7),
    IslandModel("Neige", "#FFFFFF", "#8FD3FF", "#0B1E33", 8),
    IslandModel("Arc-en-ciel", "#FFD600", "#B04BFF", "#0D0D0D", 9),
    IslandModel("Battement", "#FF5263", "#FF9AA5", "#140305", 10),
    IslandModel("Bulles", "#7CF5FF", "#4A9DFF", "#021824", 11)
)

object CallIsland {
    private var view: IslandView? = null
    private var wm: WindowManager? = null

    fun canShow(ctx: Context): Boolean = Settings.canDrawOverlays(ctx)

    fun overlaySettings(ctx: Context) {
        runCatching {
            ctx.startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    /** Écran allumé et déverrouillé : l'îlot remplace l'écran d'appel plein écran. */
    fun deviceInUse(ctx: Context): Boolean {
        val km = ctx.getSystemService(KeyguardManager::class.java)
        val pm = ctx.getSystemService(PowerManager::class.java)
        return pm?.isInteractive == true && km?.isKeyguardLocked != true
    }

    @Suppress("DEPRECATION")
    fun show(ctx: Context, number: String, name: String?, preview: Boolean = false): Boolean {
        if (!canShow(ctx)) return false
        hide()
        val app = ctx.applicationContext
        val w = app.getSystemService(WindowManager::class.java) ?: return false
        val dm = app.resources.displayMetrics
        val sb = statusBarHeight(app)
        var camX = dm.widthPixels / 2f
        var camY = sb / 2f
        if (Build.VERSION.SDK_INT >= 29) {
            val rect = runCatching { w.defaultDisplay?.cutout?.boundingRects }.getOrNull()
                ?.filter { it.top < sb * 2 }
                ?.minByOrNull { it.top }
            if (rect != null) {
                camX = rect.exactCenterX()
                camY = rect.exactCenterY()
            }
        }
        val v = IslandView(app, name ?: number.ifBlank { "Numéro masqué" }, preview, camX, camY, sb)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.x = v.windowOffset()
        lp.y = 0
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return try {
            w.addView(v, lp)
            view = v
            wm = w
            true
        } catch (_: Exception) {
            false
        }
    }

    fun hide() {
        val v = view ?: return
        view = null
        v.release()
        runCatching { wm?.removeView(v) }
    }

    internal fun relayout(v: IslandView) {
        val lp = v.layoutParams as? WindowManager.LayoutParams ?: return
        lp.x = v.windowOffset()
        runCatching { wm?.updateViewLayout(v, lp) }
    }

    @SuppressLint("DiscouragedApi", "InternalInsetResource")
    private fun statusBarHeight(ctx: Context): Int {
        val id = ctx.resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) ctx.resources.getDimensionPixelSize(id) else (24 * ctx.resources.displayMetrics.density).toInt()
    }

    /** Ce qui se passe quand l'îlot est validé. */
    internal fun act(ctx: Context, answer: Boolean, preview: Boolean) {
        if (preview) {
            Toast.makeText(ctx, if (answer) "Répondu (essai)" else "Refusé (essai)", Toast.LENGTH_SHORT).show()
        } else if (answer) {
            CallManager.answer()
            runCatching {
                ctx.startActivity(Intent(ctx, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        } else {
            CallManager.ringing()?.reject(false, null)
        }
        hide()
    }
}

@SuppressLint("ViewConstructor")
class IslandView(
    ctx: Context,
    private val title: String,
    private val preview: Boolean,
    private val camX: Float,
    private val camY: Float,
    private val sb: Int
) : View(ctx) {
    companion object {
        private val RED = Color.parseColor("#E5484D")
        private val GREEN = Color.parseColor("#1FB45A")
        private val ORANGE = Color.parseColor("#FF7A00")
        private const val ONE =
            "M10 13V4.5a1.5 1.5 0 0 1 3 0V12M13 11.5a1.5 1.5 0 0 1 3 0V13M16 12.5a1.5 1.5 0 0 1 3 0V16a6 6 0 0 1-6 6h-1a6 6 0 0 1-5.2-3l-2.3-4a1.5 1.5 0 0 1 2.6-1.5L10 15"
        private const val TWO =
            "M9 12V4.5a1.5 1.5 0 0 1 3 0V11M12 11l2.3-6.6a1.5 1.5 0 0 1 2.8 1L15 12M15 12a1.5 1.5 0 0 1 3 0v4a6 6 0 0 1-6 6h-1a6 6 0 0 1-5.2-3l-2.3-4a1.5 1.5 0 0 1 2.6-1.5L9 15"
    }

    private val d = resources.displayMetrics.density
    private val model = ISLAND_MODELS[Prefs.islandStyle.coerceIn(0, ISLAND_MODELS.lastIndex)]
    private val screenW = resources.displayMetrics.widthPixels
    private var expanded = false
    private var progress = 0f
    private var holdColor = RED
    private var maxFingers = 0
    private var downTime = 0L
    private var done = false
    private var pulse = 0f
    private var holdAnim: ValueAnimator? = null
    private var pulseAnim: ValueAnimator? = null
    private val uiHandler = Handler(Looper.getMainLooper())

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.5f * d }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 4f * d; strokeCap = Paint.Cap.ROUND
    }
    private val icon = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = Color.WHITE; strokeWidth = 2f
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val nameP = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }
    private val subP = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = ORANGE }
    private val hintP = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#A8A8A8") }
    private val oneFinger: Path? = runCatching { PathParser.createPathFromPathData(ONE) }.getOrNull()
    private val twoFingers: Path? = runCatching { PathParser.createPathFromPathData(TWO) }.getOrNull()

    init {
        isHapticFeedbackEnabled = true
        if (preview) uiHandler.postDelayed({ CallIsland.hide() }, 20_000)
    }

    // ---- Géométrie ----
    private fun widthPx(): Int = if (expanded) screenW - (24 * d).toInt() else (236 * d).toInt()
    private fun heightPx(): Int = sb + ((if (expanded) 112 else 44) * d).toInt()
    fun windowOffset(): Int {
        if (expanded) return 0
        val half = (screenW - widthPx()) / 2
        return (camX - screenW / 2f).toInt().coerceIn(-half, half)
    }

    private fun leftOnScreen(): Float = (screenW - widthPx()) / 2f + windowOffset()
    private fun btnR(): Float = (if (expanded) 26f else 15f) * d
    private fun btnCy(): Float = if (expanded) sb + 46 * d else heightPx() - 22 * d
    private fun redCx(): Float = 8 * d + btnR()
    private fun greenCx(): Float = widthPx() - 8 * d - btnR()

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(widthPx(), heightPx())
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        alpha = 0f
        translationY = -40f * d
        animate().alpha(1f).translationY(0f).setDuration(450)
            .setInterpolator(android.view.animation.OvershootInterpolator()).start()
        pulseAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1200
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener {
                pulse = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    fun release() {
        uiHandler.removeCallbacksAndMessages(null)
        holdAnim?.cancel()
        pulseAnim?.cancel()
    }

    override fun onDetachedFromWindow() {
        release()
        super.onDetachedFromWindow()
    }

    // ---- Dessin ----
    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = 24 * d
        bg.color = model.background
        c.drawRoundRect(RectF(0f, 0f, w, h), r, r, bg)
        val t = SystemClock.uptimeMillis()
        // Lumière automatique : passe du vert au rouge sans aucun appui
        val wave = (kotlin.math.sin(t % 1800L / 1800.0 * 2 * Math.PI).toFloat() * 1.6f).coerceIn(-1f, 1f)
        val live = if (progress > 0f) holdColor
        else ArgbEvaluator().evaluate((wave + 1f) / 2f, model.second, model.first) as Int
        border.strokeWidth = 2.5f * d
        border.shader = if (progress > 0f) null else SweepGradient(
            w / 2, h / 2, intArrayOf(model.first, Color.TRANSPARENT, model.second, Color.TRANSPARENT, model.first), null
        ).apply { setLocalMatrix(Matrix().apply { setRotate(t % 2400L * 0.15f, w / 2, h / 2) }) }
        border.color = if (progress > 0f) holdColor else Color.WHITE
        val inset = border.strokeWidth / 2
        c.drawRoundRect(RectF(inset, inset, w - inset, h - inset), r, r, border)

        // Caméra : halo qui pulse, puis anneau de progression
        val cx = camX - leftOnScreen()
        val cy = camY
        // Deux ondes décalées
        ring.strokeWidth = 2f * d
        for (k in 0..1) {
            val q = (pulse + k * 0.5f) % 1f
            ring.color = withAlpha(live, ((1f - q) * 200).toInt())
            c.drawCircle(cx, cy, (12f + 10f * q) * d, ring)
        }
        // Halo lumineux puis anneau plein
        ring.strokeWidth = 8f * d
        ring.color = withAlpha(live, 60)
        c.drawCircle(cx, cy, 14f * d, ring)
        ring.strokeWidth = 3f * d
        ring.color = live
        c.drawCircle(cx, cy, 14f * d, ring)
        // Comète blanche en orbite
        val orbit = RectF(cx - 14f * d, cy - 14f * d, cx + 14f * d, cy + 14f * d)
        ring.color = Color.WHITE
        c.drawArc(orbit, t % 1100L * 360f / 1100f, 55f, false, ring)

        drawEffect(c, t, cx, cy, live)
        if (progress > 0f) {
            ring.strokeWidth = 4f * d
            ring.color = holdColor
            val rr = 17f * d
            c.drawArc(RectF(cx - rr, cy - rr, cx + rr, cy + rr), -90f, 360f * progress, false, ring)
        }

        // Boutons rouge (1 doigt) et vert (2 doigts)
        val by = btnCy()
        fill.color = withAlpha(RED, ((1f - pulse) * 130).toInt())
        c.drawCircle(redCx(), by, btnR() + 7 * d * pulse, fill)
        fill.color = withAlpha(GREEN, ((1f - pulse) * 130).toInt())
        c.drawCircle(greenCx(), by, btnR() + 7 * d * pulse, fill)
        fill.color = RED
        c.drawCircle(redCx(), by, btnR(), fill)
        drawIcon(c, oneFinger, redCx(), by, btnR() * 1.15f)
        fill.color = GREEN
        c.drawCircle(greenCx(), by, btnR(), fill)
        drawIcon(c, twoFingers, greenCx(), by, btnR() * 1.15f)

        if (!expanded) {
            nameP.textSize = 12f * d
            val avail = greenCx() - redCx() - 2 * btnR() - 16 * d
            val t = TextUtils.ellipsize(title, nameP, avail, TextUtils.TruncateAt.END).toString()
            c.drawText(t, (redCx() + greenCx()) / 2f - nameP.measureText(t) / 2f, by + 4.5f * d, nameP)
        } else {
            nameP.textSize = 17f * d
            subP.textSize = 12f * d
            hintP.textSize = 11f * d
            val tx = redCx() + btnR() + 16 * d
            val avail = greenCx() - btnR() - 12 * d - tx
            val t = TextUtils.ellipsize(title, nameP, avail, TextUtils.TruncateAt.END).toString()
            c.drawText(t, tx, by - 2 * d, nameP)
            c.drawText(if (preview) "Essai de l'îlot" else "Appel entrant…", tx, by + 16 * d, subP)
            val hint = "Maintenir 1 doigt = refuser · 2 doigts = répondre"
            val ht = TextUtils.ellipsize(hint, hintP, w - 24 * d, TextUtils.TruncateAt.END).toString()
            c.drawText(ht, w / 2f - hintP.measureText(ht) / 2f, h - 12 * d, hintP)
        }
    }

    /** Décor animé propre à chaque modèle. */
    private fun drawEffect(c: Canvas, t: Long, cx: Float, cy: Float, color: Int) {
        val time = (t % 600_000L).toFloat()
        fill.color = color
        when (model.effect) {
            0 -> for (i in 0..3) { // égaliseur
                val bh = (3f + 6f * kotlin.math.abs(kotlin.math.sin(time / 170f + i * 0.9f))) * d
                for (side in intArrayOf(-1, 1)) {
                    val x = cx + side * (34f + i * 7f) * d
                    c.drawRoundRect(RectF(x - 1.5f * d, cy - bh, x + 1.5f * d, cy + bh), 2 * d, 2 * d, fill)
                }
            }
            1 -> for (i in 0..5) { // satellites autour de la caméra
                val angle = time / 350f + i * 1.047f
                fill.color = if (i % 2 == 0) model.first else model.second
                c.drawCircle(cx + kotlin.math.cos(angle) * 22f * d, cy + kotlin.math.sin(angle) * 11f * d, 2.5f * d, fill)
            }
            2 -> for (i in 0..15) { // vagues
                val y = cy + kotlin.math.sin(time / 220f - i * 0.5f) * 7f * d
                for (side in intArrayOf(-1, 1)) c.drawCircle(cx + side * (28f + i * 3f) * d, y, 2f * d, fill)
            }
            3 -> for (i in 0..27) { // étoiles scintillantes
                val glow = kotlin.math.abs(kotlin.math.sin(time / 400f + i))
                fill.color = withAlpha(if (i % 3 == 0) Color.WHITE else color, (glow * 220).toInt())
                c.drawCircle((i * 73 % 101) / 101f * width, (i * 37 % 89) / 89f * height, (0.8f + glow) * d, fill)
            }
            4 -> for (i in 0..21) { // étincelles qui montent
                val q = (time / 1400f + i * 0.137f) % 1f
                fill.color = withAlpha(if (i % 2 == 0) model.first else model.second, ((1f - q) * 230).toInt())
                c.drawCircle((i * 47 % 97) / 97f * width, height * (1f - q), (3f - 2f * q) * d, fill)
            }
            5 -> for (i in 0..2) { // reflets dorés
                val q = (time / 1600f + i / 3f) % 1f
                fill.color = withAlpha(color, ((1f - q) * 255).toInt())
                for (side in intArrayOf(-1, 1)) c.drawCircle(cx + side * (24f + 36f * q) * d, cy, 2.5f * d, fill)
            }
            6 -> for (i in 0..9) { // cœurs qui s'envolent
                val q = (time / 2200f + i * 0.31f) % 1f
                val x = (i * 47 % 97) / 97f * width
                val y = height * (1f - q)
                val s = (3f + i % 3) * d
                fill.color = withAlpha(if (i % 2 == 0) model.first else model.second, ((1f - q) * 255).toInt())
                val heart = Path().apply {
                    moveTo(x, y + s)
                    cubicTo(x - 2 * s, y - s / 2, x - s / 2, y - 1.6f * s, x, y - s / 2)
                    cubicTo(x + s / 2, y - 1.6f * s, x + 2 * s, y - s / 2, x, y + s)
                    close()
                }
                c.drawPath(heart, fill)
            }
            7 -> for (i in 0..17) { // pluie numérique
                val q = (time / (900f + i % 5 * 220f) + i * 0.17f) % 1f
                val x = (i + 0.5f) / 18f * width
                for (k in 0..3) {
                    fill.color = withAlpha(color, 220 - k * 60)
                    val y = q * height - k * 7 * d
                    c.drawRect(x - d, y, x + d, y + 5 * d, fill)
                }
            }
            8 -> for (i in 0..29) { // neige qui tombe
                val q = (time / (2600f + i % 4 * 500f) + i * 0.113f) % 1f
                val x = (i * 61 % 103) / 103f * width + kotlin.math.sin(time / 500f + i) * 4 * d
                fill.color = withAlpha(Color.WHITE, 200)
                c.drawCircle(x, q * height, (1f + i % 3 * 0.6f) * d, fill)
            }
            9 -> for (i in 0..5) { // égaliseur multicolore
                val bh = (3f + 7f * kotlin.math.abs(kotlin.math.sin(time / 190f + i * 0.7f))) * d
                for (side in intArrayOf(-1, 1)) {
                    fill.color = Color.HSVToColor(floatArrayOf((time / 8f + i * 45f) % 360f, 0.9f, 1f))
                    val x = cx + side * (30f + i * 6f) * d
                    c.drawRoundRect(RectF(x - 2 * d, cy - bh, x + 2 * d, cy + bh), 2 * d, 2 * d, fill)
                }
            }
            10 -> for (i in 0..23) { // tracé cardiaque
                val spike = when ((i - (time / 45f).toInt()).mod(12)) {
                    0 -> -10f
                    1 -> 7f
                    2 -> -3f
                    else -> 0f
                }
                for (side in intArrayOf(-1, 1)) c.drawCircle(cx + side * (26f + i * 2.5f) * d, cy + spike * d, 1.6f * d, fill)
            }
            else -> for (i in 0..13) { // bulles
                val q = (time / 2000f + i * 0.219f) % 1f
                fill.color = withAlpha(color, ((1f - q) * 130).toInt())
                c.drawCircle((i * 53 % 97) / 97f * width, height * (1f - q), (2f + i % 4 * 1.5f) * d, fill)
            }
        }
    }

    private fun withAlpha(color: Int, a: Int): Int = (color and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

    private fun drawIcon(c: Canvas, p: Path?, cx: Float, cy: Float, size: Float) {
        if (p == null) return
        c.save()
        c.translate(cx - size / 2f, cy - size / 2f)
        c.scale(size / 24f, size / 24f)
        c.drawPath(p, icon)
        c.restore()
    }

    // ---- Gestes ----
    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (done) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                maxFingers = 1
                downTime = SystemClock.uptimeMillis()
                startHold(if (hit(e.x, e.y, greenCx())) GREEN else RED)
            }

            MotionEvent.ACTION_POINTER_DOWN -> {
                if (e.pointerCount > maxFingers) {
                    maxFingers = e.pointerCount
                    if (maxFingers >= 2) startHold(GREEN)
                }
            }

            MotionEvent.ACTION_UP -> {
                val quick = SystemClock.uptimeMillis() - downTime < 300
                cancelHold()
                if (quick && maxFingers == 1) {
                    when {
                        hit(e.x, e.y, redCx()) -> finish(false)
                        hit(e.x, e.y, greenCx()) -> finish(true)
                        else -> toggle()
                    }
                }
            }

            MotionEvent.ACTION_CANCEL -> cancelHold()
        }
        return true
    }

    private fun hit(x: Float, y: Float, cx: Float): Boolean = hypot(x - cx, y - btnCy()) <= btnR() + 10 * d

    private fun startHold(color: Int) {
        holdAnim?.cancel()
        holdColor = color
        progress = 0f
        val anim = ValueAnimator.ofFloat(0f, 1f)
        anim.duration = 800
        anim.startDelay = 150
        var cancelled = false
        anim.addUpdateListener {
            progress = it.animatedValue as Float
            invalidate()
        }
        anim.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationCancel(animation: Animator) {
                cancelled = true
            }

            override fun onAnimationEnd(animation: Animator) {
                if (!cancelled && !done) finish(holdColor == GREEN)
            }
        })
        holdAnim = anim
        anim.start()
    }

    private fun cancelHold() {
        holdAnim?.cancel()
        holdAnim = null
        progress = 0f
        invalidate()
    }

    private fun toggle() {
        expanded = !expanded
        requestLayout()
        CallIsland.relayout(this)
        invalidate()
    }

    private fun finish(answer: Boolean) {
        if (done) return
        done = true
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        CallIsland.act(context, answer, preview)
    }
}

/** Caméra couverte pendant la sonnerie (capteur de proximité à côté de la caméra). */
object CoverGesture {
    const val NONE = 0
    const val SILENCE = 1
    const val ANSWER = 2
    const val REJECT = 3

    private var sm: SensorManager? = null
    private var listener: SensorEventListener? = null
    private val handler = Handler(Looper.getMainLooper())

    fun start(ctx: Context) {
        stop()
        val action = Prefs.coverAction
        if (action == NONE) return
        val app = ctx.applicationContext
        val manager = app.getSystemService(SensorManager::class.java) ?: return
        val sensor = manager.getDefaultSensor(Sensor.TYPE_PROXIMITY) ?: return
        val l = object : SensorEventListener {
            var seenFar = false
            override fun onSensorChanged(e: SensorEvent) {
                val near = e.values[0] < minOf(5f, sensor.maximumRange)
                if (!near) {
                    seenFar = true
                    handler.removeCallbacksAndMessages(null)
                } else if (seenFar) {
                    handler.removeCallbacksAndMessages(null)
                    handler.postDelayed({ perform(app, action) }, 600)
                }
            }

            override fun onAccuracyChanged(s: Sensor?, accuracy: Int) {}
        }
        manager.registerListener(l, sensor, SensorManager.SENSOR_DELAY_NORMAL)
        sm = manager
        listener = l
    }

    private fun perform(ctx: Context, action: Int) {
        if (CallManager.ringing() == null) return
        when (action) {
            SILENCE -> MagicEffects.silence(ctx)
            ANSWER -> CallIsland.act(ctx, answer = true, preview = false)
            REJECT -> CallIsland.act(ctx, answer = false, preview = false)
        }
        stop()
    }

    fun stop() {
        handler.removeCallbacksAndMessages(null)
        listener?.let { sm?.unregisterListener(it) }
        listener = null
    }
}
