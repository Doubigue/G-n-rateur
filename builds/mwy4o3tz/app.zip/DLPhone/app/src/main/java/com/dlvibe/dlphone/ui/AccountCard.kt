package com.dlvibe.dlphone.ui

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter

private fun granted(ctx: Context, permission: String) =
    ctx.checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED

/** Numéro enregistré sur la puce ; vide si l'opérateur ne l'a pas inscrit. */
@SuppressLint("MissingPermission")
@Suppress("DEPRECATION")
private fun simNumber(ctx: Context): String = runCatching {
    if (Build.VERSION.SDK_INT >= 33) {
        ctx.getSystemService(SubscriptionManager::class.java)!!
            .getPhoneNumber(SubscriptionManager.getDefaultVoiceSubscriptionId())
    } else {
        ctx.getSystemService(TelephonyManager::class.java)!!.line1Number.orEmpty()
    }
}.getOrDefault("")

private fun qrBitmap(text: String): Bitmap {
    val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, 360, 360)
    val pixels = IntArray(360 * 360) { if (m.get(it % 360, it / 360)) -0x1000000 else -1 }
    return Bitmap.createBitmap(pixels, 360, 360, Bitmap.Config.ARGB_8888)
}

@SuppressLint("MissingPermission")
private fun askBalance(ctx: Context, code: String, onResult: (String) -> Unit) {
    if (!granted(ctx, Manifest.permission.CALL_PHONE)) return onResult("Autorisation d'appel refusée")
    val base = ctx.getSystemService(TelephonyManager::class.java) ?: return onResult("Réseau indisponible")
    val subId = SubscriptionManager.getDefaultVoiceSubscriptionId()
    val tm = if (subId >= 0) base.createForSubscriptionId(subId) else base
    runCatching {
        tm.sendUssdRequest(code, object : TelephonyManager.UssdResponseCallback() {
            override fun onReceiveUssdResponse(t: TelephonyManager, request: String, response: CharSequence) =
                onResult(response.toString())

            override fun onReceiveUssdResponseFailed(t: TelephonyManager, request: String, failureCode: Int) =
                onResult("Le réseau n'a pas répondu au code $request")
        }, Handler(Looper.getMainLooper()))
    }.onFailure { onResult("Consultation impossible sur ce téléphone") }
}

/** Carte du haut : numéro, crédit, minutes et QR code. */
@Composable
fun AccountCard() {
    val ctx = LocalContext.current
    val p = LocalPalette.current
    val store = remember { ctx.getSharedPreferences("account", Context.MODE_PRIVATE) }
    var number by remember { mutableStateOf(store.getString("number", "") ?: "") }
    var code by remember { mutableStateOf(store.getString("code", "#122#") ?: "#122#") }
    var answer by remember { mutableStateOf(store.getString("answer", "") ?: "") }
    var editing by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }

    fun refresh() {
        if (number.isBlank()) number = simNumber(ctx)
        loading = true
        askBalance(ctx, code) {
            loading = false
            answer = it
            store.edit().putString("answer", it).apply()
        }
    }
    val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh() }
    val permissions = arrayOf(
        Manifest.permission.READ_PHONE_STATE,
        Manifest.permission.READ_PHONE_NUMBERS,
        Manifest.permission.CALL_PHONE
    )
    LaunchedEffect(Unit) {
        if (permissions.all { granted(ctx, it) }) refresh() else ask.launch(permissions)
    }

    val credit = Regex("(\\d[\\d .,\u00A0]*)\\s*(?:FCFA|F CFA|XOF|F\\b)", RegexOption.IGNORE_CASE)
        .find(answer)?.groupValues?.get(1)?.trim()
    val minutes = Regex("(\\d+)\\s*(?:minutes?|min|mn)\\b", RegexOption.IGNORE_CASE)
        .find(answer)?.groupValues?.get(1)

    DlCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(number.ifBlank { "Numéro non détecté" }, color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text("${credit ?: "—"} FCFA", color = p.text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Text("Minutes : ${minutes ?: "—"}", color = p.muted, fontSize = 13.sp)
                TextButton(onClick = { ask.launch(permissions) }, enabled = !loading) {
                    Text(if (loading) "Consultation…" else "Actualiser  ›", color = p.accent)
                }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    Modifier
                        .size(128.dp)
                        .border(4.dp, p.accent, RoundedCornerShape(18.dp))
                        .padding(10.dp)
                        .background(Color.White),
                    contentAlignment = Alignment.Center
                ) {
                    if (number.isNotBlank()) {
                        val qr = remember(number) { qrBitmap("tel:$number").asImageBitmap() }
                        Image(qr, "QR code de mon numéro", Modifier.fillMaxSize())
                    } else {
                        Text("?", color = Color.Black, fontSize = 32.sp)
                    }
                }
                Text("Mon numéro", color = p.text, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
            }
        }
        if (answer.isNotBlank()) Text(answer, color = p.muted, fontSize = 11.sp)
        TextButton(onClick = { editing = !editing }) { Text("Modifier le numéro ou le code", color = p.muted, fontSize = 12.sp) }
        if (editing) {
            OutlinedTextField(number, {
                number = it
                store.edit().putString("number", it).apply()
            }, label = { Text("Mon numéro") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(code, {
                code = it
                store.edit().putString("code", it).apply()
            }, label = { Text("Code de consultation du solde") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        }
    }
}

/** Grille de raccourcis ; chaque tuile fait défiler jusqu'à sa section. */
@Composable
fun ServiceTiles(onOpen: (Int) -> Unit) {
    val p = LocalPalette.current
    val tiles: List<Triple<String, ImageVector, Int>> = listOf(
        Triple("Général", Icons.Filled.Settings, 3), Triple("Voix", Icons.Filled.RecordVoiceOver, 4),
        Triple("Îlot", Icons.Filled.TouchApp, 6), Triple("Thèmes", Icons.Filled.Wallpaper, 8),
        Triple("Style", Icons.Filled.Palette, 9), Triple("Effets", Icons.Filled.AutoAwesome, 10),
        Triple("Blocage", Icons.Filled.Shield, 11), Triple("Réponses", Icons.Filled.Message, 12)
    )
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Services", color = p.text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        tiles.chunked(4).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { (label, icon, index) ->
                    val shape = RoundedCornerShape(16.dp)
                    Column(
                        Modifier
                            .weight(1f)
                            .height(96.dp)
                            .clip(shape)
                            .background(p.card)
                            .border(1.dp, p.line, shape)
                            .clickable { onOpen(index) },
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(icon, null, tint = p.accent, modifier = Modifier.size(34.dp))
                        Text(label, color = p.text, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    }
                }
            }
        }
    }
}
