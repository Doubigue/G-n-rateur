import 'package:firebase_core/firebase_core.dart';

/// Config Firebase du projet "ma-camera-e2e8b" (app Android com.doubigue.macamera).
/// Aucun plugin Gradle requis : indispensable avec APK Studio, qui ignore android/.
const firebaseOptions = FirebaseOptions(
  apiKey: 'AIzaSyAOoZ26wTKz2dsXfoSwLGMYrBzv5u8VLyA',
  appId: '1:108967247898:android:6f3fb4abb9b864fa0f11a3',
  messagingSenderId: '108967247898',
  projectId: 'ma-camera-e2e8b',
);
