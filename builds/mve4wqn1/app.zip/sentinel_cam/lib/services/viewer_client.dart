import 'dart:async';
import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'rtc_config.dart';

enum ViewerStatus { idle, connecting, live, paused, error }

class ViewerClient {
  final _db = FirebaseFirestore.instance;
  final status = ValueNotifier<ViewerStatus>(ViewerStatus.idle);
  final renderer = RTCVideoRenderer();

  RTCPeerConnection? _pc;
  DocumentReference<Map<String, dynamic>>? _doc;
  StreamSubscription? _sessionSub, _candSub;
  String _id = '';
  bool _gotOffer = false, _remoteSet = false;
  final List<RTCIceCandidate> _pending = [];

  Future<void> init() => renderer.initialize();

  Future<void> connect(String rawCode) async {
    await disconnect();
    final code = rawCode.replaceAll(RegExp(r'\D'), '');
    final doc = _db.collection('sessions').doc(code.isEmpty ? '_' : code);
    if (code.length != 6 || !(await doc.get()).exists) throw 'Code introuvable';

    _doc = doc;
    _id = '${DateTime.now().microsecondsSinceEpoch}${Random().nextInt(9999)}';
    status.value = ViewerStatus.connecting;

    final pc = _pc = await createPeerConnection(rtcConfig);
    pc.onTrack = (e) {
      if (e.track.kind == 'video' && e.streams.isNotEmpty) {
        renderer.srcObject = e.streams.first;
      }
    };
    pc.onIceCandidate = (c) {
      if (c.candidate != null) {
        doc.collection('viewCandidates').add({...c.toMap(), 'viewer': _id});
      }
    };
    pc.onConnectionState = (s) {
      if (s == RTCPeerConnectionState.RTCPeerConnectionStateConnected) {
        status.value = ViewerStatus.live;
      } else if (s == RTCPeerConnectionState.RTCPeerConnectionStateFailed) {
        status.value = ViewerStatus.error;
      }
    };

    _candSub = doc
        .collection('hostCandidates')
        .where('viewer', isEqualTo: _id)
        .snapshots()
        .listen((qs) async {
      for (final ch in qs.docChanges.where((c) => c.type == DocumentChangeType.added)) {
        final m = ch.doc.data()!;
        final cand = RTCIceCandidate(m['candidate'], m['sdpMid'], m['sdpMLineIndex']);
        _remoteSet ? await _pc?.addCandidate(cand) : _pending.add(cand);
      }
    });

    _sessionSub = doc.snapshots().listen((s) async {
      final d = s.data();
      if (d == null) {
        status.value = ViewerStatus.error; // caméra arrêtée
        return;
      }
      final offer = d['offer'];
      if (offer is Map && offer['viewer'] == _id && !_gotOffer) {
        _gotOffer = true;
        await pc.setRemoteDescription(RTCSessionDescription(offer['sdp'], offer['type']));
        _remoteSet = true;
        for (final c in _pending) {
          await pc.addCandidate(c);
        }
        _pending.clear();
        final answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);
        await doc.update({
          'answer': {'sdp': answer.sdp, 'type': answer.type, 'viewer': _id}
        });
      }
    });

    // Déclenche la création de l'offre côté caméra
    await doc.update({'join': _id, 'paused': false});
  }

  /// Coupe / réactive réellement le flux (la caméra n'émet plus que du noir).
  Future<void> setPaused(bool p) async {
    await _doc?.update({'paused': p});
    status.value = p ? ViewerStatus.paused : ViewerStatus.live;
  }

  Future<void> disconnect() async {
    await _sessionSub?.cancel();
    await _candSub?.cancel();
    try {
      await _doc?.update({'join': FieldValue.delete()});
    } catch (_) {}
    await _pc?.close();
    _pc = null;
    _doc = null;
    _gotOffer = _remoteSet = false;
    _pending.clear();
    renderer.srcObject = null;
    status.value = ViewerStatus.idle;
  }

  Future<void> dispose() async {
    await disconnect();
    await renderer.dispose();
  }
}
