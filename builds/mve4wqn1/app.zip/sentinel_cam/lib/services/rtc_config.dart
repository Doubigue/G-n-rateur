/// STUN public Google. Pour les réseaux 4G très restrictifs (NAT symétrique),
/// ajoutez un serveur TURN ici.
const Map<String, dynamic> rtcConfig = {
  'iceServers': [
    {
      'urls': [
        'stun:stun.l.google.com:19302',
        'stun:stun1.l.google.com:19302',
      ]
    },
    // {'urls': 'turn:votre-serveur:3478', 'username': 'u', 'credential': 'p'},
  ],
  'sdpSemantics': 'unified-plan',
};

const int maxBitrate = 400000; // 400 kbit/s
const int maxFps = 15;
