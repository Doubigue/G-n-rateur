import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import '../services/viewer_client.dart';

class ViewerScreen extends StatefulWidget {
  const ViewerScreen({super.key});
  @override
  State<ViewerScreen> createState() => _ViewerScreenState();
}

class _ViewerScreenState extends State<ViewerScreen> {
  final client = ViewerClient();
  final ctrl = TextEditingController();
  String? error;

  @override
  void initState() {
    super.initState();
    client.init().then((_) => mounted ? setState(() {}) : null);
  }

  @override
  void dispose() {
    client.dispose();
    ctrl.dispose();
    super.dispose();
  }

  Future<void> _connect() async {
    setState(() => error = null);
    try {
      await client.connect(ctrl.text);
    } catch (e) {
      setState(() => error = '$e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mode Visionneur')),
      body: ValueListenableBuilder(
        valueListenable: client.status,
        builder: (_, s, __) => (s == ViewerStatus.idle) ? _form() : _player(s),
      ),
    );
  }

  Widget _form() => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          TextField(
            controller: ctrl,
            keyboardType: TextInputType.number,
            textAlign: TextAlign.center,
            maxLength: 6,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            style: const TextStyle(fontSize: 40, letterSpacing: 8),
            decoration: InputDecoration(
                hintText: '000000', errorText: error, border: const OutlineInputBorder()),
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: FilledButton(onPressed: _connect, child: const Text('Se connecter')),
          ),
        ]),
      );

  Widget _player(ViewerStatus s) => Stack(fit: StackFit.expand, children: [
        const ColoredBox(color: Colors.black),
        RTCVideoView(client.renderer,
            objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitContain),
        if (s == ViewerStatus.connecting)
          const Center(child: CircularProgressIndicator()),
        if (s == ViewerStatus.error)
          const Center(child: Text('Connexion perdue ou caméra arrêtée')),
        if (s == ViewerStatus.paused)
          const Center(child: Icon(Icons.pause_circle, size: 80, color: Colors.white54)),
        Positioned(
          left: 0, right: 0, bottom: 24,
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            FloatingActionButton(
              heroTag: 'pause',
              onPressed: (s == ViewerStatus.live || s == ViewerStatus.paused)
                  ? () => client.setPaused(s == ViewerStatus.live)
                  : null,
              child: Icon(s == ViewerStatus.paused ? Icons.play_arrow : Icons.pause),
            ),
            const SizedBox(width: 24),
            FloatingActionButton(
              heroTag: 'stop',
              backgroundColor: Colors.red.shade700,
              onPressed: client.disconnect,
              child: const Icon(Icons.call_end),
            ),
          ]),
        ),
      ]);
}
