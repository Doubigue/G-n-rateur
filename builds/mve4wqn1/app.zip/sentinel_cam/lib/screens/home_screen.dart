import 'package:flutter/material.dart';
import 'camera_screen.dart';
import 'viewer_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    Widget big(IconData i, String t, String sub, Widget page) => Expanded(
          child: Card(
            child: InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => page)),
              child: Center(
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Icon(i, size: 64),
                  const SizedBox(height: 12),
                  Text(t, style: Theme.of(context).textTheme.titleLarge),
                  Text(sub, style: Theme.of(context).textTheme.bodySmall),
                ]),
              ),
            ),
          ),
        );
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(children: [
            Text('Sentinel Cam', style: Theme.of(context).textTheme.headlineMedium),
            const SizedBox(height: 20),
            big(Icons.videocam, 'Mode Caméra', 'Filmer et générer un code', const CameraScreen()),
            big(Icons.visibility, 'Mode Visionneur', 'Entrer un code et regarder', const ViewerScreen()),
          ]),
        ),
      ),
    );
  }
}
