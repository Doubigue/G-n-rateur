# Sentinel Cam (Flutter)

## Installation
1. `flutter create --org com.example --platforms=android sentinel_cam` dans un dossier temporaire,
   puis copiez `lib/`, `pubspec.yaml` et `android/app/src/main/AndroidManifest.xml` dans votre projet
   (conservez le `package` de votre MainActivity).
2. Dans `android/app/build.gradle(.kts)` : `minSdk = 23`, `compileSdk = 35`.
3. Créez un projet Firebase, ajoutez l'app Android et copiez ses 4 valeurs dans `lib/firebase_options.dart`.
4. Créez une base **Firestore** dans la console Firebase et publiez vos règles depuis l'onglet Règles.
5. `flutter pub get && flutter run` sur deux téléphones physiques.

## Architecture
- `camera_host.dart` : capture 640x480, code à 6 chiffres, offre WebRTC, plafond 400 kbit/s / 15 fps.
- `viewer_client.dart` : saisie du code, réponse WebRTC, pause réelle du flux.
- `background_service.dart` : Foreground Service (type camera) + WakeLock + WifiLock + exemption batterie.
- Signalisation : Firestore `sessions/{code}` (join, offer, answer, paused) + `hostCandidates` / `viewCandidates`.
- Vidéo : WebRTC P2P (STUN Google), codec VP8/H.264 matériel, chiffré DTLS-SRTP.

## Icône
Le logo est dans `assets/` (icon.png 1024 px + logo.svg). Après `flutter pub get` :
`dart run flutter_launcher_icons`

## Compilation avec APK Studio
1. Remplacez `.github/scripts/android_setup.py` de votre dépôt par la version du dossier `apk-studio-patch`
   (service de premier plan de type *camera*, permissions caméra/batterie, minSdk 23).
2. Remplissez `lib/firebase_options.dart` : APK Studio ignore le dossier `android/` et `google-services.json`.
3. Zippez le projet, lancez la compilation Flutter et cochez Caméra + Notifications.
