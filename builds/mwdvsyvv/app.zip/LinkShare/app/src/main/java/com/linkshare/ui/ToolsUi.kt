package com.linkshare.ui

import android.content.Context
import android.os.Environment
import android.os.StatFs
import android.os.storage.StorageManager
import android.text.format.Formatter
import android.widget.Toast
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

// ═══════════════════════════ Autres stockages ═══════════════════════════

private class VolumeInfo(val label: String, val dir: File, val primary: Boolean, val removable: Boolean, val total: Long, val free: Long)

private fun volumes(ctx: Context): List<VolumeInfo> = runCatching {
    ctx.getSystemService(StorageManager::class.java).storageVolumes
        .filter { it.state == Environment.MEDIA_MOUNTED || it.state == Environment.MEDIA_MOUNTED_READ_ONLY }
        .mapNotNull { v ->
            val d = v.directory ?: return@mapNotNull null
            val st = runCatching { StatFs(d.path) }.getOrNull()
            VolumeInfo(
                v.getDescription(ctx) ?: d.name, d, v.isPrimary, v.isRemovable,
                st?.totalBytes ?: 0L, st?.availableBytes ?: 0L,
            )
        }
}.getOrDefault(emptyList())

/** Tous les volumes montés : mémoire interne, carte SD, clé USB (OTG)… Toucher un volume l'ouvre dans l'explorateur. */
@Composable
internal fun VolumesScreen(ex: ExplorerViewModel, onBack: () -> Unit, onOpen: (File) -> Unit) {
    val ctx = LocalContext.current
    val list = remember(AppEvents.resumeTick) { volumes(ctx) }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Ic.Back, "Retour", tint = LS.Text) }
            Text("Autres stockages", color = LS.Text, fontSize = 20.sp, fontWeight = FontWeight.Medium)
        }
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            items(list, key = { it.dir.path }) { v -> VolumeCard(v) { onOpen(v.dir) } }
            if (list.none { it.removable }) item(key = "hint") {
                Column(
                    Modifier.fillMaxWidth().lsCard(RoundedCornerShape(UiStyle.r(22.dp))).padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        IconBadge(Ic.SdCard, LS.Orange, 44.dp)
                        IconBadge(Ic.Usb, LS.Teal, 44.dp)
                    }
                    Text("Aucune carte SD ni clé USB détectée", color = LS.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                    Text(
                        "Insère une carte SD ou branche une clé USB (câble OTG) : elle apparaîtra ici automatiquement.",
                        color = LS.Muted, fontSize = 12.sp, textAlign = TextAlign.Center,
                    )
                }
            }
            item(key = "folders") {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Dossiers système", Modifier.padding(start = 4.dp, top = 8.dp), color = LS.Blue, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    listOf(
                        Triple(Environment.DIRECTORY_DCIM, "Appareil photo (DCIM)", Ic.Image),
                        Triple(Environment.DIRECTORY_MOVIES, "Films", Ic.Video),
                        Triple(Environment.DIRECTORY_MUSIC, "Musique", Ic.Music),
                        Triple("Android/media", "Médias des applications", Ic.Apps),
                    ).forEach { (path, label, icon) ->
                        val d = File(ex.root, path)
                        if (d.isDirectory) ToolRow(icon, label, d.path.removePrefix(ex.root.path).trimStart('/'), LS.Blue) { onOpen(d) }
                    }
                }
            }
        }
    }
}

@Composable
private fun VolumeCard(v: VolumeInfo, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val used = (v.total - v.free).coerceAtLeast(0L)
    val frac = if (v.total > 0) used.toFloat() / v.total else 0f
    val anim by animateFloatAsState(frac, tween(900), label = "vol")
    val tint = when {
        v.primary -> LS.Blue
        v.removable && v.label.contains("USB", true) -> LS.Teal
        else -> LS.Orange
    }
    Row(
        Modifier.fillMaxWidth().lsCard(RoundedCornerShape(UiStyle.r(24.dp))).clickable(onClick = onClick).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(72.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val w = 8.dp.toPx()
                val tl = Offset(w / 2, w / 2)
                val arc = Size(size.width - w, size.height - w)
                drawArc(LS.Card2, -90f, 360f, false, tl, arc, style = Stroke(w))
                drawArc(tint, -90f, 360f * anim, false, tl, arc, style = Stroke(w, cap = StrokeCap.Round))
            }
            Icon(
                when {
                    v.primary -> Ic.Phone
                    v.label.contains("USB", true) -> Ic.Usb
                    else -> Ic.SdCard
                }, null, Modifier.size(26.dp), tint = tint,
            )
        }
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(if (v.primary) "Stockage interne" else v.label, color = LS.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                Formatter.formatShortFileSize(ctx, used) + " utilisés sur " + Formatter.formatShortFileSize(ctx, v.total),
                color = LS.Muted, fontSize = 12.sp, maxLines = 1,
            )
            Spacer(Modifier.height(6.dp))
            Chip("${(frac * 100).toInt()} % · " + Formatter.formatShortFileSize(ctx, v.free) + " libres", tint)
        }
        Icon(Ic.Chevron, "Ouvrir", Modifier.size(22.dp), tint = LS.Muted)
    }
}

@Composable
private fun ToolRow(icon: ImageVector, title: String, sub: String, tint: Color, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().lsCard(RoundedCornerShape(UiStyle.r(20.dp))).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconBadge(icon, tint, 40.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = LS.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(sub, color = LS.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Icon(Ic.Chevron, null, Modifier.size(20.dp), tint = LS.Muted)
    }
}

// ═══════════════════════════ Nettoyeur ═══════════════════════════

/** Un groupe de fichiers à nettoyer. [trash] = passe par la corbeille (restaurable) ; sinon effacé directement. */
private class CleanGroup(
    val key: String, val title: String, val sub: String, val icon: ImageVector, val tint: Color,
    val files: List<File>, val bytes: Long, val trash: Boolean,
)

private suspend fun scanJunk(ctx: Context, ex: ExplorerViewModel): List<CleanGroup> {
    val root = ex.root
    val empty = ArrayList<File>()
    val temp = ArrayList<File>()
    val tempExt = setOf("tmp", "temp", "crdownload", "partial")
    // Parcours unique : dossiers vides et fichiers temporaires (hors données des applis et dossiers cachés)
    fun walk(d: File, depth: Int): Boolean {
        val kids = d.listFiles() ?: return false
        var hasContent = false
        for (k in kids) {
            if (k.isDirectory) {
                if (k.name.startsWith(".") || depth > 12 || (d.name == "Android" && depth == 1)) { hasContent = true; continue }
                val sub = walk(k, depth + 1)
                if (!sub && empty.size < 3000) empty += k else hasContent = true
            } else {
                hasContent = true
                if (k.extension.lowercase() in tempExt && temp.size < 3000) temp += k
            }
        }
        return hasContent
    }
    currentCoroutineContext().ensureActive()
    walk(root, 0)
    // Ne garder que les dossiers vides « les plus hauts » (supprimer le parent supprime les enfants)
    val emptyTop = empty.filter { e -> empty.none { o -> o !== e && e.path.startsWith(o.path + "/") } }

    val thumbs = listOf("DCIM/.thumbnails", "Pictures/.thumbnails", "Movies/.thumbnails", "Music/.thumbnails")
        .map { File(root, it) }.filter { it.isDirectory }
    val thumbBytes = thumbs.sumOf { d -> d.walkTopDown().filter { it.isFile }.sumOf { it.length() } }

    val pm = ctx.packageManager
    val installedApks = ex.findApks().filter { f ->
        runCatching {
            val info = pm.getPackageArchiveInfo(f.path, 0) ?: return@runCatching false
            val inst = pm.getPackageInfo(info.packageName, 0)
            inst.longVersionCode >= info.longVersionCode
        }.getOrDefault(false)
    }
    val cache = ex.appCacheSize()

    return listOf(
        CleanGroup("apk", "APK déjà installés", "Fichiers d'installation devenus inutiles", Ic.Apps, LS.Green, installedApks, installedApks.sumOf { it.length() }, true),
        CleanGroup("thumbs", "Miniatures en cache", "Recréées automatiquement par Android", Ic.Image, LS.Pink, thumbs, thumbBytes, false),
        CleanGroup("temp", "Fichiers temporaires", ".tmp, téléchargements interrompus…", Ic.Clock, LS.Orange, temp, temp.sumOf { it.length() }, true),
        CleanGroup("empty", "Dossiers vides", "Dossiers qui ne contiennent rien", Ic.Folder, LS.Blue, emptyTop, 0L, false),
        CleanGroup("cache", "Cache de LinkShare", "Aperçus et fichiers de partage temporaires", Ic.Storage, LS.Teal, emptyList(), cache, false),
    )
}

@Composable
internal fun CleanerScreen(ex: ExplorerViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var groups by remember { mutableStateOf<List<CleanGroup>?>(null) }
    var tick by remember { mutableIntStateOf(0) }
    val checked = remember { mutableStateMapOf<String, Boolean>() }
    LaunchedEffect(tick) {
        groups = null
        groups = withContext(Dispatchers.IO) { runCatching { scanJunk(ctx, ex) }.getOrDefault(emptyList()) }
    }
    val g = groups
    fun isOn(c: CleanGroup) = checked[c.key] ?: (c.key != "empty" || c.files.isNotEmpty())
    val chosen = g.orEmpty().filter { isOn(it) && (it.files.isNotEmpty() || (it.key == "cache" && it.bytes > 0)) }
    val total = chosen.sumOf { it.bytes }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Ic.Back, "Retour", tint = LS.Text) }
            Text("Nettoyeur", Modifier.weight(1f), color = LS.Text, fontSize = 20.sp, fontWeight = FontWeight.Medium)
            IconButton({ tick++ }) { Icon(Ic.Refresh, "Analyser à nouveau", tint = LS.Blue) }
        }
        ex.busy?.let { b ->
            Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                Text(b, color = LS.Text, fontSize = 11.sp)
                Spacer(Modifier.height(4.dp))
                LinearProgressIndicator(Modifier.fillMaxWidth(), color = LS.Blue)
            }
        }
        if (g == null) {
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                CircularProgressIndicator(color = LS.Blue)
                Spacer(Modifier.height(14.dp))
                Text("Analyse du stockage…", color = LS.Muted, fontSize = 13.sp)
            }
            return@Column
        }
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item(key = "summary") {
                Column(
                    Modifier.fillMaxWidth().lsCard(RoundedCornerShape(UiStyle.r(26.dp))).padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    IconBadge(Ic.Broom, LS.Green, 60.dp)
                    Spacer(Modifier.height(10.dp))
                    Text(Formatter.formatShortFileSize(ctx, total), color = LS.Text, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                    Text("peuvent être libérés", color = LS.Muted, fontSize = 13.sp)
                }
            }
            items(g, key = { it.key }) { c ->
                val n = if (c.key == "cache") 0 else c.files.size
                val empty = c.files.isEmpty() && !(c.key == "cache" && c.bytes > 0)
                Row(
                    Modifier.fillMaxWidth().lsCard(RoundedCornerShape(UiStyle.r(20.dp)))
                        .clickable(enabled = !empty) { checked[c.key] = !isOn(c) }.padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconBadge(c.icon, c.tint, 42.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(c.title, color = LS.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                        Text(
                            if (empty) "Rien à nettoyer"
                            else listOfNotNull(
                                if (n > 0) plural(n, "élément", "éléments") else null,
                                if (c.bytes > 0) Formatter.formatShortFileSize(ctx, c.bytes) else null,
                            ).joinToString(" · ") + " — " + c.sub,
                            color = LS.Muted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
                        )
                    }
                    Checkbox(
                        checked = !empty && isOn(c), enabled = !empty, onCheckedChange = { checked[c.key] = it },
                        colors = CheckboxDefaults.colors(checkedColor = LS.Blue, checkmarkColor = LS.OnBlue),
                    )
                }
            }
            item(key = "note") {
                Text(
                    "Les APK et fichiers temporaires passent par la corbeille (restaurables $TRASH_DAYS jours). " +
                        "Les miniatures, dossiers vides et le cache sont effacés directement.",
                    Modifier.padding(horizontal = 6.dp), color = LS.Muted, fontSize = 11.sp,
                )
            }
        }
        Button(
            onClick = {
                val trash = chosen.filter { it.trash }.flatMap { it.files }
                val delete = chosen.filter { !it.trash && it.key != "cache" }.flatMap { it.files }
                if (chosen.any { it.key == "cache" }) scope.launch(Dispatchers.IO) { ex.clearAppCache() }
                if (trash.isEmpty() && delete.isEmpty()) {
                    Toast.makeText(ctx, "Cache vidé", Toast.LENGTH_SHORT).show(); tick++
                } else ex.clean(trash, delete) { tick++ }
            },
            enabled = chosen.isNotEmpty() && ex.busy == null,
            modifier = Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp).height(54.dp),
            shape = RoundedCornerShape(UiStyle.r(18.dp)),
            colors = ButtonDefaults.buttonColors(containerColor = LS.Blue, contentColor = LS.OnBlue),
        ) {
            Icon(Ic.Broom, null, Modifier.size(20.dp))
            Spacer(Modifier.width(10.dp))
            Text("Nettoyer " + Formatter.formatShortFileSize(ctx, total), fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}
