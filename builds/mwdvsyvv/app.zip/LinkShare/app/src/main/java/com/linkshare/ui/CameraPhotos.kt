package com.linkshare.ui

import android.content.Context
import android.provider.MediaStore
import java.io.File

/** Photos prises avec l'appareil photo du téléphone (DCIM/Camera), les plus récentes d'abord. */
internal fun cameraPhotos(ctx: Context): List<File> {
    fun query(like: String, not: String? = null): List<File> {
        val out = ArrayList<File>()
        val d = MediaStore.Images.Media.DATA
        val sel = "$d LIKE ? AND ${MediaStore.Images.Media.SIZE} > 0" + if (not != null) " AND $d NOT LIKE ?" else ""
        val args = if (not != null) arrayOf(like, not) else arrayOf(like)
        try {
            ctx.contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, arrayOf(d), sel, args,
                "${MediaStore.Images.Media.DATE_ADDED} DESC",
            )?.use { c ->
                while (c.moveToNext() && out.size < 3000) {
                    val p = c.getString(0) ?: continue
                    val f = File(p)
                    if (f.isFile) out += f
                }
            }
        } catch (_: Exception) {}
        return out
    }
    // Certains téléphones rangent les photos dans DCIM/100MEDIA, DCIM/Camera2… : repli sur tout DCIM (sans les captures d'écran)
    return query("%/DCIM/Camera/%").ifEmpty { query("%/DCIM/%", "%/Screenshots/%") }
}
