package com.linkshare.ui

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.webkit.DownloadListener
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

/** Extensions de fichiers web que l'explorateur affiche comme des pages (et non comme du texte). */
internal val VIEW_WEB = setOf("html", "htm", "xhtml", "svg")

/** Types MIME des pages web (liens https, « Ouvrir avec »). */
internal fun isWebPageMime(m: String) = m == "text/html" || m == "application/xhtml+xml" || m == "image/svg+xml"

/**
 * Page web plein écran (WebView) : fichier .html / .htm local (les images, styles et scripts voisins se chargent),
 * lien https / http ou page reçue d'une autre appli. Retour = page précédente puis fermeture ; les liens vers d'autres
 * applis (mailto:, tel:…) s'ouvrent dans l'appli qui convient ; un fichier à télécharger part dans Download/LinkShare.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
internal fun WebPage(url: String, title: String, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var web by remember { mutableStateOf<WebView?>(null) }
    var pageTitle by remember { mutableStateOf(title) }
    var progress by remember { mutableIntStateOf(0) }
    val closeNow by rememberUpdatedState(onClose)

    BackHandler { val w = web; if (w != null && w.canGoBack()) w.goBack() else closeNow() }
    DisposableEffect(Unit) { onDispose { web?.let { it.stopLoading(); it.destroy() } } }

    Column(Modifier.fillMaxSize().background(LS.Bg).systemBarsPadding()) {
        Row(Modifier.padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ closeNow() }) { Icon(Ic.Back, "Fermer", tint = LS.Blue) }
            Text(
                pageTitle.ifBlank { title }, Modifier.weight(1f), color = LS.Blue,
                fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            IconButton({ web?.reload() }) { Icon(Ic.Refresh, "Actualiser", tint = LS.Blue) }
        }
        if (progress in 1..99) LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth(), color = LS.Blue)
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { c ->
                WebView(c).apply {
                    settings.apply {
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        allowFileAccess = true      // pages locales : images et styles du même dossier
                        allowContentAccess = true   // pages reçues d'une autre appli (content://)
                        builtInZoomControls = true
                        displayZoomControls = false
                        useWideViewPort = true
                        loadWithOverviewMode = true
                        mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                    }
                    webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                            val u = request.url
                            when (u.scheme?.lowercase()) {
                                "http", "https", "file", "content", "about", "data", "blob" -> return false
                            }
                            try { ctx.startActivity(Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
                            return true
                        }
                    }
                    webChromeClient = object : WebChromeClient() {
                        override fun onProgressChanged(view: WebView, newProgress: Int) { progress = newProgress }
                        override fun onReceivedTitle(view: WebView, t: String?) { if (!t.isNullOrBlank()) pageTitle = t }
                    }
                    setDownloadListener(DownloadListener { dl, _, cd, mime, _ ->
                        try {
                            val name = URLUtil.guessFileName(dl, cd, mime)
                            val req = DownloadManager.Request(Uri.parse(dl))
                                .setMimeType(mime)
                                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "LinkShare/$name")
                            ctx.getSystemService(DownloadManager::class.java).enqueue(req)
                            Toast.makeText(ctx, "Téléchargement dans Download/LinkShare", Toast.LENGTH_SHORT).show()
                        } catch (e: Exception) {
                            Toast.makeText(ctx, "Téléchargement impossible", Toast.LENGTH_SHORT).show()
                        }
                    })
                    web = this
                    loadUrl(url)
                }
            },
        )
    }
}
