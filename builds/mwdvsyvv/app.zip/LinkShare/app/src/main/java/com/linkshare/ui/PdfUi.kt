package com.linkshare.ui

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.util.LruCache
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

// ═══════════════════════════ Aperçus (1re page) ═══════════════════════════

/** Miniatures de PDF déjà calculées (clé : chemin + date), limitées à ~24 Mo. */
private object PdfThumbs {
    val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }
    /** Pas plus de 2 PDF ouverts à la fois pour les miniatures (mémoire). */
    val gate = Semaphore(2)
}

/** Rend une page sur fond blanc à la largeur [widthPx] ; null si le PDF est illisible ou protégé. */
private fun renderPage(r: PdfRenderer, index: Int, widthPx: Int): Bitmap? = runCatching {
    r.openPage(index).use { p ->
        val w = widthPx.coerceIn(64, 2200)
        val h = (w.toFloat() * p.height / p.width.coerceAtLeast(1)).toInt().coerceIn(1, 4000)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(android.graphics.Color.WHITE)
        p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
        bmp
    }
}.getOrNull()

private fun openPdf(f: File): Pair<ParcelFileDescriptor, PdfRenderer>? = runCatching {
    val fd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
    try { fd to PdfRenderer(fd) } catch (e: Exception) { fd.close(); throw e }
}.getOrNull()

private suspend fun pdfFirstPage(f: File, widthPx: Int): Bitmap? {
    val key = f.path + "@" + f.lastModified() + "#" + widthPx
    PdfThumbs.cache.get(key)?.let { return it }
    return PdfThumbs.gate.withPermit {
        withContext(Dispatchers.IO) {
            val d = openPdf(f)
            if (d == null) null
            else try {
                if (d.second.pageCount == 0) null else renderPage(d.second, 0, widthPx)
            } finally {
                runCatching { d.second.close() }; runCatching { d.first.close() }
            }
        }
    }?.also { PdfThumbs.cache.put(key, it) }
}

/**
 * Aperçu de la première page d'un PDF (grille, liste, récents, infos). Tant qu'il se charge — ou si le PDF est protégé
 * par mot de passe — on garde la pastille « document ».
 */
@Composable
internal fun PdfThumb(f: File, modifier: Modifier, widthPx: Int = 360, crop: Boolean = true, fallback: @Composable () -> Unit) {
    val bmp by produceState<Bitmap?>(null, f.path, widthPx) { value = pdfFirstPage(f, widthPx) }
    val b = bmp
    if (b == null) fallback()
    else Image(
        b.asImageBitmap(), "Aperçu de ${f.name}", modifier.background(Color.White),
        contentScale = if (crop) ContentScale.Crop else ContentScale.Fit, alignment = Alignment.TopCenter,
    )
}

// ═══════════════════════════ Lecteur PDF ═══════════════════════════

/**
 * Lecteur PDF intégré : toutes les pages à la suite (défilement vertical), zoom à deux doigts (jusqu'à ×5),
 * double toucher = zoom ×2,5 / retour, numéro de page, ouverture avec une autre appli.
 */
@Composable
internal fun PdfViewer(ex: ExplorerViewModel, f: File, onClose: () -> Unit) {
    BackHandler { onClose() }
    val density = LocalDensity.current
    val screenW = with(density) { LocalConfiguration.current.screenWidthDp.dp.roundToPx() }
    // Rendu un peu plus large que l'écran : le texte reste net quand on zoome
    val renderW = (screenW * 1.6f).toInt().coerceAtMost(2200)

    // Ouverture du document ; PdfRenderer ne supporte qu'une page ouverte à la fois → verrou
    val lock = remember { Mutex() }
    var doc by remember(f.path) { mutableStateOf<Pair<ParcelFileDescriptor, PdfRenderer>?>(null) }
    var failed by remember(f.path) { mutableStateOf(false) }
    LaunchedEffect(f.path) {
        val d = withContext(Dispatchers.IO) { openPdf(f) }
        if (d == null || d.second.pageCount == 0) failed = true else doc = d
    }
    DisposableEffect(doc) {
        val d = doc
        onDispose {
            // Fermeture après le rendu en cours (jamais pendant qu'une page est ouverte)
            if (d != null) kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                lock.withLock { runCatching { d.second.close() }; runCatching { d.first.close() } }
            }
        }
    }
    val pages = remember { object : LruCache<Int, Bitmap>(8) {} }
    // Proportions de chaque page (hauteur / largeur) : la place est réservée avant le rendu
    val ratios by produceState<List<Float>>(emptyList(), doc) {
        val r = doc?.second ?: return@produceState
        value = withContext(Dispatchers.IO) {
            lock.withLock {
                (0 until r.pageCount).map { i ->
                    runCatching { r.openPage(i).use { p -> p.height.toFloat() / p.width.coerceAtLeast(1) } }.getOrDefault(1.414f)
                }
            }
        }
    }

    val list = rememberLazyListState()
    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var boxW by remember { mutableIntStateOf(1) }
    fun clampX(x: Float) = x.coerceIn(-(scale - 1f) * boxW / 2f, (scale - 1f) * boxW / 2f)

    Column(Modifier.fillMaxSize().background(Color(0xFF2B2B2B))) {
        // ── Barre du haut
        Row(
            Modifier.fillMaxWidth().background(LS.Bg).statusBarsPadding().padding(horizontal = 6.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClose) { Icon(Ic.Back, "Retour", tint = LS.Text) }
            Column(Modifier.weight(1f)) {
                Text(f.name, color = LS.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (ratios.isNotEmpty()) Text(
                    "Page ${(list.firstVisibleItemIndex + 1).coerceAtMost(ratios.size)} / ${ratios.size}" +
                        if (scale > 1.01f) " · ×" + String.format(java.util.Locale.US, "%.1f", scale) else "",
                    color = LS.Muted, fontSize = 12.sp,
                )
            }
            IconButton({ ex.shareFiles(listOf(f)) }) { Icon(Ic.Share, "Partager", tint = LS.Blue) }
            IconButton({ ex.external(f) }) { Icon(Ic.OpenIn, "Ouvrir avec une autre appli", tint = LS.Blue) }
        }

        Box(
            Modifier.weight(1f).fillMaxWidth().onSizeChanged { boxW = it.width.coerceAtLeast(1) }
                // Zoom à deux doigts (passe « Initial » : la liste ne défile pas pendant le pincement)
                .pointerInput(Unit) {
                    awaitEachGesture {
                        awaitFirstDown(requireUnconsumed = false)
                        do {
                            val ev = awaitPointerEvent(PointerEventPass.Initial)
                            val fingers = ev.changes.count { it.pressed }
                            if (fingers >= 2) {
                                scale = (scale * ev.calculateZoom()).coerceIn(1f, 5f)
                                offsetX = clampX(offsetX + ev.calculatePan().x)
                                ev.changes.forEach { it.consume() }
                            } else if (fingers == 1 && scale > 1f) {
                                // Zoomé : un doigt déplace aussi la page de gauche à droite
                                val c = ev.changes.first()
                                offsetX = clampX(offsetX + (c.position.x - c.previousPosition.x))
                            }
                        } while (ev.changes.any { it.pressed })
                        if (scale < 1.02f) { scale = 1f; offsetX = 0f }
                    }
                }
                .pointerInput(Unit) {
                    detectTapGestures(onDoubleTap = {
                        if (scale > 1.01f) { scale = 1f; offsetX = 0f } else scale = 2.5f
                    })
                },
        ) {
            val d = doc
            if (failed) PdfError(ex, f)
            else if (d == null || ratios.isEmpty()) CircularProgressIndicator(Modifier.align(Alignment.Center), color = LS.Blue)
            else {
                val renderer: PdfRenderer = d.second
                LazyColumn(
                    Modifier.fillMaxSize().graphicsLayer {
                        scaleX = scale; scaleY = scale; translationX = offsetX
                    },
                    state = list,
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    items(ratios.size, key = { it }) { i ->
                        val bmp by produceState<Bitmap?>(pages.get(i), i, renderer) {
                            if (value == null) value = withContext(Dispatchers.IO) {
                                lock.withLock { renderPage(renderer, i, renderW) }
                            }?.also { pages.put(i, it) }
                        }
                        Box(
                            Modifier.fillMaxWidth().aspectRatio(1f / ratios[i].coerceIn(0.2f, 5f))
                                .shadow(4.dp, RoundedCornerShape(4.dp)).background(Color.White),
                            contentAlignment = Alignment.Center,
                        ) {
                            val b = bmp
                            if (b != null) Image(b.asImageBitmap(), "Page ${i + 1}", Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
                            else CircularProgressIndicator(Modifier.size(28.dp), color = Color(0xFF9E9E9E), strokeWidth = 2.dp)
                        }
                    }
                }
            }
        }
    }
}

/** PDF illisible (protégé par mot de passe, abîmé) : on propose une autre appli. */
@Composable
private fun PdfError(ex: ExplorerViewModel, f: File) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
    ) {
        IconBadge(Ic.Doc, LS.Red, 64.dp)
        Spacer(Modifier.height(14.dp))
        Text("Impossible d'afficher ce PDF", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        Text(
            "Il est peut-être protégé par un mot de passe ou endommagé.",
            color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp, textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(16.dp))
        Button({ ex.external(f) }, colors = ButtonDefaults.buttonColors(containerColor = LS.Blue, contentColor = LS.OnBlue)) {
            Text("Ouvrir avec une autre appli")
        }
    }
}

/** Petite pastille « PDF » posée sur les aperçus. */
@Composable
internal fun PdfBadge(modifier: Modifier) {
    Text(
        "PDF",
        modifier.clip(RoundedCornerShape(6.dp)).background(Color(0xFFE53935)).padding(horizontal = 5.dp, vertical = 1.dp),
        color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold,
    )
}
