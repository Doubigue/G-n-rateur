package com.linkshare.ui

import android.widget.Toast
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linkshare.core.*

// Écrans de partage LinkShare, intégrés à l'explorateur (pas d'accueil, de barre de navigation ni de profil).

@Composable
fun Radar(diameter: Dp) {
    val t = rememberInfiniteTransition(label = "radar")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(2600, easing = LinearEasing)), label = "p")
    Box(Modifier.size(diameter), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val maxR = this.size.minDimension / 2
            for (i in 0..2) {
                val f = (p + i / 3f) % 1f
                drawCircle(LS.Blue.copy(alpha = (1f - f) * 0.28f), radius = maxR * (0.3f + 0.7f * f))
            }
        }
        Box(Modifier.size(diameter * 0.36f).clip(CircleShape).background(LS.BlueLight), contentAlignment = Alignment.Center) {
            Icon(Ic.Person, null, Modifier.size(diameter * 0.22f), tint = LS.Blue)
        }
    }
}

/** Écran « Partager mes fichiers » : QR + radar, ouvert depuis le bouton Partager de l'explorateur. */
@Composable
fun ShareScreen(info: ShareInfo?, onBack: () -> Unit, onStart: () -> Unit, onStop: () -> Unit) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val busy by ShareState.active.collectAsState()
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Ic.Back, "Retour", tint = LS.Text) }
            Text("Partager mes fichiers", color = LS.Text, fontSize = 20.sp, fontWeight = FontWeight.Medium)
        }
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            if (info == null) {
                Spacer(Modifier.height(24.dp))
                Radar(190.dp)
                Text("Partage arrêté", color = LS.Blue, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Démarre le partage pour afficher un QR code : l'autre téléphone pourra parcourir tes fichiers.",
                    color = LS.Muted, fontSize = 13.sp, textAlign = TextAlign.Center,
                )
                Button(
                    onStart, Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = LS.Blue),
                ) { Text("Démarrer le partage") }
            } else {
                val bmp = remember(info) { qr(info.toUri()) }
                Image(
                    bmp.asImageBitmap(), "QR code",
                    Modifier.size(230.dp).clip(RoundedCornerShape(18.dp)).background(Color.White),
                )
                Text("Scanne ce QR pour te connecter", color = LS.Blue, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                Text("${info.host}:${info.port}", color = LS.Text, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Radar(140.dp)
                Text(
                    if (busy > 0) "Transfert en cours…" else "En attente d'un téléphone…",
                    color = LS.Blue, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                )
                Text(
                    "Quiconque scanne ce code accède à tes fichiers. Arrête le partage quand tu as fini.",
                    color = LS.Muted, fontSize = 12.sp, textAlign = TextAlign.Center,
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        {
                            clip.setText(AnnotatedString(info.toUri()))
                            Toast.makeText(ctx, "Lien copié", Toast.LENGTH_SHORT).show()
                        },
                        Modifier.weight(1f).height(50.dp), shape = RoundedCornerShape(16.dp),
                    ) { Icon(Ic.Copy, null, Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)); Text("Copier le lien") }
                    Button(
                        onStop, Modifier.weight(1f).height(50.dp), shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = LS.Blue),
                    ) { Icon(Ic.Stop, null, Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)); Text("Arrêter") }
                }
            }
        }
    }
}

/** Connexion par lien « linkshare://… » (alternative au scan du QR). */
@Composable
internal fun LinkDialog(onDismiss: () -> Unit, onConnect: (Connection) -> Unit) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    var text by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Se connecter avec un lien") },
        text = {
            Column {
                OutlinedTextField(
                    value = text, onValueChange = { text = it }, singleLine = true,
                    placeholder = { Text("linkshare://…") }, modifier = Modifier.fillMaxWidth(),
                )
                TextButton({ clip.getText()?.text?.let { text = it } }) { Text("Coller") }
            }
        },
        confirmButton = {
            TextButton({
                val c = Connection.parse(text.trim())
                if (c != null) onConnect(c) else Toast.makeText(ctx, "Lien non reconnu", Toast.LENGTH_SHORT).show()
            }) { Text("Se connecter") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Annuler") } },
    )
}

/** Ouvre un fichier web (https ou http) dans l'explorateur : vidéo, audio, image, texte ; les autres formats se téléchargent. */
@Composable
internal fun WebLinkDialog(onDismiss: () -> Unit, onOpen: (android.net.Uri) -> Unit) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    var text by remember { mutableStateOf("") }
    fun go() {
        var t = text.trim()
        if (t.isNotEmpty() && !t.contains("://")) t = "https://$t"
        val u = android.net.Uri.parse(t)
        if (ExternalOpen.isWeb(u) && !u.host.isNullOrEmpty()) onOpen(u)
        else Toast.makeText(ctx, "Lien web non reconnu", Toast.LENGTH_SHORT).show()
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Ouvrir un lien web") },
        text = {
            Column {
                OutlinedTextField(
                    value = text, onValueChange = { text = it }, singleLine = true,
                    placeholder = { Text("https://…/video.mp4") }, modifier = Modifier.fillMaxWidth(),
                )
                TextButton({ clip.getText()?.text?.let { text = it } }) { Text("Coller") }
            }
        },
        confirmButton = { TextButton({ go() }) { Text("Ouvrir") } },
        dismissButton = { TextButton(onDismiss) { Text("Annuler") } },
    )
}
