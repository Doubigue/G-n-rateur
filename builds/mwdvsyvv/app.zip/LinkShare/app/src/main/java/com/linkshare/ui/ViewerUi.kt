package com.linkshare.ui

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage

/**
 * Images plein écran : on passe à la suivante / précédente en balayant vers la gauche / la droite.
 * [models] : fichiers locaux (File) ou URL distantes (String), dans l'ordre d'affichage.
 * [onPage] est appelé à chaque changement d'image (sert à mettre à jour le titre).
 */
@Composable
internal fun ImagePager(models: List<Any>, start: Int, onPage: (Int) -> Unit) {
    val first = start.coerceIn(0, (models.size - 1).coerceAtLeast(0))
    val pager = rememberPagerState(initialPage = first) { models.size }
    val onPageNow by rememberUpdatedState(onPage)
    LaunchedEffect(pager) { snapshotFlow { pager.currentPage }.collect { onPageNow(it) } }
    HorizontalPager(state = pager, modifier = Modifier.fillMaxSize(), beyondViewportPageCount = 1) { i ->
        AsyncImage(
            model = models[i], contentDescription = null,
            modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit,
        )
    }
}
