package com.linkshare.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.text.format.Formatter
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Une version publiée, trouvée à la source des mises à jour. */
internal class RemoteVersion(
    val name: String,            // « 1.2 »
    val code: Long,              // versionCode s'il est connu (manifeste JSON), sinon 0
    val apkUrl: String,
    val size: Long,
    val notes: String,
    val published: Long,         // date de publication (ms), 0 si inconnue
    val viaApi: Boolean,         // lien d'API GitHub (dépôt privé : demande le jeton)
)

/**
 * Mise à jour intégrée : cherche une nouvelle version, la télécharge puis lance l'installation.
 *
 * Source (Paramètres › Mises à jour) :
 *  - un dépôt GitHub « propriétaire/dépôt » (ou son lien) : on lit ses *Releases* et on prend le premier fichier .apk
 *    (de préférence celui dont le nom contient « LinkShare ») ;
 *  - ou le lien d'un manifeste JSON : `{"versionCode": 12, "versionName": "1.2", "url": "https://…/app.apk", "notes": "…"}`.
 *
 * Avant d'installer, l'APK téléchargé est vérifié : même appli (com.linkshare) et numéro de version plus grand.
 * Grâce à la clé de signature dédiée, Android l'installe par-dessus la version actuelle (données conservées).
 */
internal object AppUpdate {
    var checking by mutableStateOf(false)
    var available by mutableStateOf<RemoteVersion?>(null)
    var progress by mutableStateOf<Float?>(null)   // téléchargement en cours (0..1), null sinon
    var status by mutableStateOf<String?>(null)    // dernier résultat lisible (« À jour », erreur…)
    var dismissed by mutableStateOf(false)          // bandeau de l'accueil masqué pour cette session

    // Réglages
    var source by mutableStateOf("")
    var token by mutableStateOf("")
    var autoCheck by mutableStateOf(true)

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("linkshare", Context.MODE_PRIVATE)

    fun load(ctx: Context) {
        val p = prefs(ctx)
        source = p.getString("up_source", "") ?: ""
        token = p.getString("up_token", "") ?: ""
        autoCheck = p.getBoolean("up_auto", true)
    }

    fun save(ctx: Context) {
        prefs(ctx).edit().putString("up_source", source.trim()).putString("up_token", token.trim())
            .putBoolean("up_auto", autoCheck).apply()
    }

    fun currentName(ctx: Context): String =
        runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "?"

    fun currentCode(ctx: Context): Long =
        runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).longVersionCode }.getOrDefault(0L)

    private fun installedAt(ctx: Context): Long =
        runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).lastUpdateTime }.getOrDefault(0L)

    private var launchChecked = false

    /** Vérification automatique au lancement de l'appli (une fois par lancement). */
    suspend fun checkOnLaunch(ctx: Context) {
        if (launchChecked || !autoCheck || source.isBlank()) return
        launchChecked = true
        check(ctx, quiet = true)
    }

    /** Cherche une nouvelle version. [quiet] : pas de message « à jour » (vérification automatique). */
    suspend fun check(ctx: Context, quiet: Boolean = false) {
        if (checking) return
        if (source.isBlank()) { status = "Indique d'abord la source des mises à jour"; return }
        checking = true
        if (!quiet) status = "Recherche…"
        try {
            val remote = withContext(Dispatchers.IO) { fetch() }
            prefs(ctx).edit().putLong("up_last", System.currentTimeMillis()).apply()
            available = if (remote != null && isNewer(ctx, remote)) remote else null
            status = when {
                remote == null -> "Aucune version trouvée à cette source"
                available != null -> "Version ${remote.name} disponible"
                else -> "LinkShare est à jour (${currentName(ctx)})"
            }
        } catch (e: Exception) {
            if (!quiet) status = "Vérification impossible : " + (e.message ?: e.javaClass.simpleName)
        } finally {
            checking = false
        }
    }

    private fun isNewer(ctx: Context, r: RemoteVersion): Boolean {
        if (r.code > 0) return r.code > currentCode(ctx)
        val cmp = compareVersions(r.name, currentName(ctx))
        if (cmp != null) return cmp > 0
        // Pas de numéro exploitable : on se fie à la date de publication
        return r.published > installedAt(ctx) + 60_000L
    }

    /** Compare « 1.10 » et « 1.9 » chiffre par chiffre ; null si l'un des deux n'a aucun chiffre. */
    private fun compareVersions(a: String, b: String): Int? {
        fun parts(s: String) = Regex("\\d+").findAll(s).map { it.value.toLongOrNull() ?: 0L }.toList()
        val x = parts(a); val y = parts(b)
        if (x.isEmpty() || y.isEmpty()) return null
        for (i in 0 until maxOf(x.size, y.size)) {
            val d = x.getOrElse(i) { 0L }.compareTo(y.getOrElse(i) { 0L })
            if (d != 0) return d
        }
        return 0
    }

    private fun open(url: String, json: Boolean): HttpURLConnection {
        var u = url
        repeat(6) {
            val c = (URL(u).openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = false
                connectTimeout = 15_000; readTimeout = 30_000
                setRequestProperty("User-Agent", "LinkShare-Updater")
                if (json) setRequestProperty("Accept", "application/vnd.github+json")
                else setRequestProperty("Accept", "application/octet-stream")
                // Le jeton ne part que vers GitHub (jamais vers le serveur de fichiers après redirection)
                if (token.isNotBlank() && (u.contains("api.github.com") || u.contains("github.com/")))
                    setRequestProperty("Authorization", "Bearer ${token.trim()}")
            }
            val code = c.responseCode
            if (code in 300..399) {
                val loc = c.getHeaderField("Location") ?: throw IllegalStateException("Redirection sans adresse")
                c.disconnect()
                u = URL(URL(u), loc).toString()
            } else {
                if (code !in 200..299) {
                    c.disconnect()
                    throw IllegalStateException(
                        when (code) {
                            401, 403 -> "accès refusé (dépôt privé ? ajoute un jeton GitHub)"
                            404 -> "introuvable (vérifie la source)"
                            else -> "erreur HTTP $code"
                        }
                    )
                }
                return c
            }
        }
        throw IllegalStateException("Trop de redirections")
    }

    private fun readText(url: String): String {
        val c = open(url, json = true)
        return try { c.inputStream.bufferedReader().use { it.readText() } } finally { c.disconnect() }
    }

    /** « propriétaire/dépôt » à partir de « owner/repo », « github.com/owner/repo » ou d'un lien complet. */
    private fun githubRepo(s: String): String? {
        val t = s.trim().removeSuffix("/").removeSuffix(".git")
        Regex("github\\.com/([^/\\s]+)/([^/\\s#?]+)").find(t)?.let { return it.groupValues[1] + "/" + it.groupValues[2] }
        return if (Regex("^[\\w.-]+/[\\w.-]+$").matches(t)) t else null
    }

    private fun fetch(): RemoteVersion? {
        val s = source.trim()
        val repo = if (s.startsWith("http") && !s.contains("github.com/")) null else githubRepo(s)
        if (repo != null) {
            val arr = JSONArray(readText("https://api.github.com/repos/$repo/releases?per_page=20"))
            for (i in 0 until arr.length()) {
                val rel = arr.getJSONObject(i)
                if (rel.optBoolean("draft")) continue
                val assets = rel.optJSONArray("assets") ?: continue
                val apks = (0 until assets.length()).map { assets.getJSONObject(it) }
                    .filter { it.optString("name").endsWith(".apk", true) }
                if (apks.isEmpty()) continue
                val a = apks.firstOrNull { it.optString("name").contains("linkshare", true) } ?: apks.first()
                val name = rel.optString("tag_name").ifBlank { rel.optString("name") }
                val private = token.isNotBlank()
                return RemoteVersion(
                    name = name.removePrefix("v").removePrefix("V"),
                    code = 0L,
                    apkUrl = if (private) a.optString("url") else a.optString("browser_download_url"),
                    size = a.optLong("size"),
                    notes = rel.optString("body").take(1500),
                    published = parseDate(rel.optString("published_at")),
                    viaApi = private,
                )
            }
            return null
        }
        if (s.endsWith(".apk", true)) {
            return RemoteVersion("nouvelle version", 0L, s, 0L, "", System.currentTimeMillis(), false)
        }
        // Manifeste JSON
        val o = JSONObject(readText(s))
        val url = o.optString("url").ifBlank { o.optString("apkUrl") }
        if (url.isBlank()) return null
        return RemoteVersion(
            name = o.optString("versionName", ""),
            code = o.optLong("versionCode", 0L),
            apkUrl = url, size = o.optLong("size", 0L), notes = o.optString("notes", ""),
            published = 0L, viaApi = false,
        )
    }

    private fun parseDate(s: String): Long = runCatching { java.time.Instant.parse(s).toEpochMilli() }.getOrDefault(0L)

    /** Télécharge l'APK, le vérifie puis ouvre l'installeur d'Android. */
    suspend fun downloadAndInstall(ctx: Context) {
        val r = available ?: return
        if (progress != null) return
        // Android doit autoriser LinkShare à installer des applis (une seule fois)
        if (!ctx.packageManager.canRequestPackageInstalls()) {
            Toast.makeText(ctx, "Autorise LinkShare à installer des applications, puis touche à nouveau « Installer »", Toast.LENGTH_LONG).show()
            ctx.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return
        }
        progress = 0f
        status = "Téléchargement…"
        try {
            val apk = withContext(Dispatchers.IO) {
                val dir = File(ctx.cacheDir, "update").apply { deleteRecursively(); mkdirs() }
                val out = File(dir, "LinkShare-${r.name.ifBlank { "maj" }.replace(Regex("[^\\w.-]"), "_")}.apk")
                val c = open(r.apkUrl, json = false)
                try {
                    val total = c.contentLengthLong.takeIf { it > 0 } ?: r.size
                    c.inputStream.use { input ->
                        out.outputStream().use { o ->
                            val buf = ByteArray(64 * 1024)
                            var done = 0L
                            var lastShown = 0L
                            while (true) {
                                currentCoroutineContext().ensureActive()
                                val n = input.read(buf)
                                if (n < 0) break
                                o.write(buf, 0, n)
                                done += n
                                if (total > 0 && done - lastShown > 256 * 1024) {
                                    lastShown = done
                                    progress = (done.toFloat() / total).coerceIn(0f, 1f)
                                    status = "Téléchargement · " + Formatter.formatShortFileSize(ctx, done) +
                                        " / " + Formatter.formatShortFileSize(ctx, total)
                                }
                            }
                        }
                    }
                } finally { c.disconnect() }
                out
            }
            // Vérification : bien LinkShare, et plus récent que la version installée
            val info = ctx.packageManager.getPackageArchiveInfo(apk.path, 0)
            when {
                info == null -> { status = "Le fichier téléchargé n'est pas un APK valide"; apk.delete(); return }
                info.packageName != ctx.packageName -> {
                    status = "Cet APK n'est pas LinkShare (${info.packageName})"; apk.delete(); return
                }
                info.longVersionCode <= currentCode(ctx) -> {
                    status = "Déjà à jour : la version publiée n'est pas plus récente (n° ${info.longVersionCode})"
                    available = null; apk.delete(); return
                }
            }
            status = "Installation de la version ${info?.versionName ?: r.name}…"
            val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", apk)
            ctx.startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            status = "Téléchargement impossible : " + (e.message ?: e.javaClass.simpleName)
        } finally {
            progress = null
        }
    }
}

// ═══════════════════════════ Interface ═══════════════════════════

/** Bandeau de l'accueil quand une nouvelle version est disponible. */
@Composable
internal fun UpdateBanner() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val r = AppUpdate.available
    AnimatedVisibility(r != null && !AppUpdate.dismissed) {
        val v = r ?: return@AnimatedVisibility
        val p = AppUpdate.progress
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(UiStyle.r(22.dp)))
                .background(Brush.linearGradient(listOf(LS.Blue.copy(alpha = 0.32f), LS.Card)))
                .border(1.dp, LS.Blue.copy(alpha = 0.5f), RoundedCornerShape(UiStyle.r(22.dp)))
                .padding(14.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconBadge(Ic.Download, LS.Blue, 42.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Nouvelle version ${v.name}", color = LS.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        "Installée : ${AppUpdate.currentName(ctx)}" + if (v.size > 0) " · " + Formatter.formatShortFileSize(ctx, v.size) else "",
                        color = LS.Muted, fontSize = 12.sp,
                    )
                }
                if (p == null) Icon(
                    Ic.Close, "Plus tard",
                    Modifier.clip(CircleShape).clickable { AppUpdate.dismissed = true }.padding(6.dp).size(18.dp), tint = LS.Muted,
                )
            }
            if (v.notes.isNotBlank()) Text(
                v.notes, Modifier.padding(top = 8.dp), color = LS.Text.copy(alpha = 0.85f), fontSize = 12.sp,
                maxLines = 3, overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(10.dp))
            if (p != null) {
                LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth().clip(CircleShape), color = LS.Blue)
                Text(AppUpdate.status ?: "", Modifier.padding(top = 4.dp), color = LS.Muted, fontSize = 11.sp)
            } else Button(
                { scope.launch { AppUpdate.downloadAndInstall(ctx) } },
                Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = LS.Blue, contentColor = LS.OnBlue),
            ) {
                Icon(Ic.Download, null, Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Installer la mise à jour", fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

/** Carte « Mises à jour » des Paramètres. */
@Composable
internal fun UpdateSettingsCard() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var editing by remember { mutableStateOf(false) }
    val r = AppUpdate.available
    val p = AppUpdate.progress
    Column(
        Modifier.fillMaxWidth().lsCard(RoundedCornerShape(UiStyle.r(22.dp))).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBadge(Ic.Download, LS.Blue, 42.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Version ${AppUpdate.currentName(ctx)} (n° ${AppUpdate.currentCode(ctx)})", color = LS.Text, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                Text(
                    AppUpdate.status ?: if (AppUpdate.source.isBlank()) "Source des mises à jour non définie" else "Source : ${AppUpdate.source}",
                    color = if (r != null) LS.Blue else LS.Muted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
                )
            }
            if (AppUpdate.checking) CircularProgressIndicator(Modifier.size(20.dp), color = LS.Blue, strokeWidth = 2.dp)
        }
        if (p != null) LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth().clip(CircleShape), color = LS.Blue)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (r != null) Button(
                { scope.launch { AppUpdate.downloadAndInstall(ctx) } }, Modifier.weight(1f), enabled = p == null,
                colors = ButtonDefaults.buttonColors(containerColor = LS.Blue, contentColor = LS.OnBlue),
            ) { Text("Installer ${r.name}", maxLines = 1, overflow = TextOverflow.Ellipsis) }
            else Button(
                {
                    if (AppUpdate.source.isBlank()) editing = true
                    else scope.launch { AppUpdate.check(ctx) }
                },
                Modifier.weight(1f), enabled = !AppUpdate.checking && p == null,
                colors = ButtonDefaults.buttonColors(containerColor = LS.Blue, contentColor = LS.OnBlue),
            ) { Text("Rechercher une mise à jour", maxLines = 1) }
            OutlinedButton({ editing = true }) { Text("Source", color = LS.Blue) }
        }
        Row(Modifier.fillMaxWidth().clickable { AppUpdate.autoCheck = !AppUpdate.autoCheck; AppUpdate.save(ctx) }, verticalAlignment = Alignment.CenterVertically) {
            Text("Vérifier au démarrage", Modifier.weight(1f), color = LS.Text, fontSize = 14.sp)
            Switch(
                AppUpdate.autoCheck, { AppUpdate.autoCheck = it; AppUpdate.save(ctx) },
                colors = SwitchDefaults.colors(checkedThumbColor = LS.OnBlue, checkedTrackColor = LS.Blue),
            )
        }
    }

    if (editing) {
        var src by remember { mutableStateOf(AppUpdate.source) }
        var tok by remember { mutableStateOf(AppUpdate.token) }
        AlertDialog(
            onDismissRequest = { editing = false },
            title = { Text("Source des mises à jour") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Dépôt GitHub où tu publies l'APK dans les « Releases » (ex. : Doubigue/LinkShare), " +
                            "ou lien d'un fichier JSON / d'un APK.",
                        fontSize = 13.sp,
                    )
                    OutlinedTextField(src, { src = it }, label = { Text("Dépôt ou lien") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(
                        tok, { tok = it }, label = { Text("Jeton GitHub (dépôt privé, facultatif)") },
                        singleLine = true, modifier = Modifier.fillMaxWidth(),
                        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                    )
                }
            },
            confirmButton = {
                TextButton({
                    AppUpdate.source = src.trim(); AppUpdate.token = tok.trim(); AppUpdate.save(ctx)
                    AppUpdate.available = null; AppUpdate.status = null
                    editing = false
                    if (AppUpdate.source.isNotBlank()) scope.launch { AppUpdate.check(ctx) }
                }) { Text("Enregistrer et vérifier") }
            },
            dismissButton = { TextButton({ editing = false }) { Text("Annuler") } },
        )
    }
}
