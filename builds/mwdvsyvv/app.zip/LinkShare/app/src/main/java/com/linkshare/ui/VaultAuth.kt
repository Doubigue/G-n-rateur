package com.linkshare.ui

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.os.CancellationSignal
import android.os.SystemClock
import android.util.Base64
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

// ═══════════════════════════ Verrouillage propre au coffre ═══════════════════════════

enum class VaultMode(val label: String) {
    PHONE("Verrouillage du téléphone"),
    PATTERN("Schéma propre au coffre"),
    PIN("Code propre au coffre"),
}

/**
 * Méthode de déverrouillage du coffre, réglée dans Paramètres.
 * Le schéma / code est stocké sous forme d'empreinte PBKDF2 salée (jamais en clair).
 * L'empreinte digitale ne peut pas être « propre » à l'appli : Android n'enregistre les doigts qu'au niveau du téléphone ;
 * elle sert donc seulement de raccourci devant le schéma / code du coffre.
 */
object VaultAuth {
    private const val MAX_FAILS = 5
    private const val LOCK_MS = 30_000L
    private var fails = 0
    private var lockedUntil = 0L

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("linkshare_vault", Context.MODE_PRIVATE)

    fun mode(ctx: Context): VaultMode =
        runCatching { VaultMode.valueOf(prefs(ctx).getString("mode", VaultMode.PHONE.name)!!) }.getOrDefault(VaultMode.PHONE)

    fun fingerprint(ctx: Context) = prefs(ctx).getBoolean("fingerprint", false)
    fun setFingerprint(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean("fingerprint", on).apply()

    private fun hash(secret: String, salt: ByteArray): ByteArray =
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(PBEKeySpec(secret.toCharArray(), salt, 60_000, 256)).encoded

    /** Enregistre la méthode ; [secret] = schéma (chiffres des points) ou code, null pour le verrouillage du téléphone. */
    fun set(ctx: Context, mode: VaultMode, secret: String?) {
        val e = prefs(ctx).edit().putString("mode", mode.name)
        if (secret == null) {
            e.remove("salt").remove("hash").putBoolean("fingerprint", false)
        } else {
            val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
            e.putString("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
                .putString("hash", Base64.encodeToString(hash(secret, salt), Base64.NO_WRAP))
        }
        e.apply()
        fails = 0; lockedUntil = 0L
    }

    /** Secondes d'attente restantes après trop d'échecs (0 = on peut essayer). */
    fun waitSeconds(): Int {
        val left = lockedUntil - SystemClock.elapsedRealtime()
        return if (left <= 0) 0 else (left / 1000L + 1).toInt()
    }

    fun check(ctx: Context, secret: String): Boolean {
        if (waitSeconds() > 0) return false
        val p = prefs(ctx)
        val salt = p.getString("salt", null)?.let { Base64.decode(it, Base64.NO_WRAP) } ?: return false
        val expected = p.getString("hash", null)?.let { Base64.decode(it, Base64.NO_WRAP) } ?: return false
        val ok = java.security.MessageDigest.isEqual(hash(secret, salt), expected)
        if (ok) { fails = 0 }
        else if (++fails >= MAX_FAILS) { fails = 0; lockedUntil = SystemClock.elapsedRealtime() + LOCK_MS }
        return ok
    }
}

// ═══════════════════════════ Authentification Android (empreinte / verrouillage d'écran) ═══════════════════════════

/**
 * Demande l'empreinte du verrouillage d'écran du téléphone (ou, à défaut, son code / schéma / mot de passe).
 * Sert à protéger l'accès au réglage du coffre.
 */
internal fun authenticateWithPhoneLock(act: Activity, title: String, subtitle: String, onOk: () -> Unit) {
    val km = act.getSystemService(KeyguardManager::class.java)
    if (!km.isDeviceSecure) {
        Toast.makeText(act, "Configure d'abord un verrouillage d'écran (empreinte, code, schéma ou mot de passe)", Toast.LENGTH_LONG).show()
        return
    }
    val allowed = BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL
    val prompt = BiometricPrompt.Builder(act).setTitle(title).setSubtitle(subtitle).setAllowedAuthenticators(allowed).build()
    prompt.authenticate(CancellationSignal(), act.mainExecutor, object : BiometricPrompt.AuthenticationCallback() {
        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { onOk() }
        override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
            val cancelled = errorCode == BiometricPrompt.BIOMETRIC_ERROR_USER_CANCELED || errorCode == BiometricPrompt.BIOMETRIC_ERROR_CANCELED
            if (!cancelled) Toast.makeText(act, errString, Toast.LENGTH_SHORT).show()
        }
    })
}

internal fun fingerprintAvailable(ctx: Context): Boolean =
    ctx.getSystemService(BiometricManager::class.java)
        ?.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS

/** Raccourci empreinte devant le schéma / code du coffre ; [onFallback] = bouton « schéma / code » ou erreur. */
internal fun authenticateWithFingerprint(act: Activity, title: String, negative: String, onOk: () -> Unit, onFallback: () -> Unit) {
    if (!fingerprintAvailable(act)) { onFallback(); return }
    val prompt = BiometricPrompt.Builder(act).setTitle(title)
        .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
        .setNegativeButton(negative, act.mainExecutor) { _, _ -> onFallback() }
        .build()
    prompt.authenticate(CancellationSignal(), act.mainExecutor, object : BiometricPrompt.AuthenticationCallback() {
        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { onOk() }
        override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { onFallback() }
    })
}

// ═══════════════════════════ Grille de schéma ═══════════════════════════

/** Grille 3 × 3 : le doigt relie les points ; [onComplete] reçoit les numéros (0‑8) dans l'ordre. */
@Composable
internal fun PatternPad(modifier: Modifier = Modifier, onComplete: (List<Int>) -> Unit) {
    val path = remember { mutableStateListOf<Int>() }
    var finger by remember { mutableStateOf<Offset?>(null) }
    var box by remember { mutableStateOf(IntSize.Zero) }
    val done by rememberUpdatedState(onComplete)
    val blue = LS.Blue

    fun dotCenter(i: Int): Offset {
        val cw = box.width / 3f; val ch = box.height / 3f
        return Offset((i % 3 + 0.5f) * cw, (i / 3 + 0.5f) * ch)
    }
    fun hit(p: Offset) {
        val radius = box.width / 3f * 0.32f
        for (i in 0..8) if (i !in path && (dotCenter(i) - p).getDistance() < radius) { path.add(i); break }
    }

    Canvas(
        modifier.onSizeChanged { box = it }.pointerInput(Unit) {
            detectDragGestures(
                onDragStart = { o -> path.clear(); finger = o; hit(o) },
                onDrag = { change, _ -> finger = change.position; hit(change.position) },
                onDragEnd = { val p = path.toList(); path.clear(); finger = null; if (p.isNotEmpty()) done(p) },
                onDragCancel = { path.clear(); finger = null },
            )
        },
    ) {
        for (i in 0..8) {
            val on = i in path
            drawCircle(if (on) blue else Color(0xFF8A8A8A), radius = if (on) 14.dp.toPx() else 8.dp.toPx(), center = dotCenter(i))
        }
        for (k in 1 until path.size) drawLine(blue, dotCenter(path[k - 1]), dotCenter(path[k]), strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round)
        finger?.let { f -> path.lastOrNull()?.let { drawLine(blue.copy(alpha = 0.6f), dotCenter(it), f, strokeWidth = 5.dp.toPx(), cap = StrokeCap.Round) } }
    }
}

internal fun List<Int>.asSecret() = joinToString("")

// ═══════════════════════════ Boîtes de dialogue ═══════════════════════════

/** Définir un schéma : le tracer deux fois (4 points minimum). */
@Composable
internal fun PatternSetupDialog(onDismiss: () -> Unit, onSet: (String) -> Unit) {
    var first by remember { mutableStateOf<String?>(null) }
    var msg by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (first == null) "Dessine un schéma" else "Redessine-le pour confirmer") },
        text = {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Text(msg ?: "Relie au moins 4 points.", color = if (msg != null) Color(0xFFF28B82) else LS.Muted, fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                PatternPad(Modifier.size(240.dp)) { p ->
                    val s = p.asSecret()
                    when {
                        p.size < 4 -> msg = "Il faut au moins 4 points."
                        first == null -> { first = s; msg = null }
                        first == s -> onSet(s)
                        else -> { first = null; msg = "Les deux schémas sont différents, recommence." }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onDismiss) { Text("Annuler") } },
    )
}

/** Définir un code (4 à 8 chiffres), à saisir deux fois. */
@Composable
internal fun PinSetupDialog(onDismiss: () -> Unit, onSet: (String) -> Unit) {
    var a by remember { mutableStateOf("") }
    var b by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Code du coffre") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    a, { a = it.filter(Char::isDigit).take(8) }, label = { Text("Code (4 à 8 chiffres)") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                )
                OutlinedTextField(
                    b, { b = it.filter(Char::isDigit).take(8) }, label = { Text("Confirmer le code") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                )
                msg?.let { Text(it, color = Color(0xFFF28B82), fontSize = 12.sp) }
            }
        },
        confirmButton = {
            TextButton({
                when {
                    a.length < 4 -> msg = "Il faut au moins 4 chiffres."
                    a != b -> msg = "Les deux codes sont différents."
                    else -> onSet(a)
                }
            }) { Text("Enregistrer") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Annuler") } },
    )
}

/** Ouverture du coffre quand une méthode propre est définie (schéma ou code), avec l'empreinte en raccourci si activée. */
@Composable
internal fun VaultUnlockDialog(mode: VaultMode, onDismiss: () -> Unit, onUnlocked: () -> Unit) {
    val ctx = LocalContext.current
    val act = ctx.findActivity()
    var pin by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf<String?>(null) }
    var showFingerprint by remember { mutableStateOf(VaultAuth.fingerprint(ctx)) }

    fun attempt(secret: String) {
        val wait = VaultAuth.waitSeconds()
        when {
            wait > 0 -> msg = "Trop d'essais, réessaie dans $wait s."
            VaultAuth.check(ctx, secret) -> onUnlocked()
            else -> { msg = if (VaultAuth.waitSeconds() > 0) "Trop d'essais, réessaie dans ${VaultAuth.waitSeconds()} s." else "Incorrect."; pin = "" }
        }
    }

    // Empreinte : proposée d'abord ; « Utiliser … » ou une erreur ramène au schéma / code
    LaunchedEffect(showFingerprint) {
        if (showFingerprint && act != null) {
            authenticateWithFingerprint(
                act, "Dossier sécurisé", if (mode == VaultMode.PATTERN) "Utiliser le schéma" else "Utiliser le code",
                onOk = onUnlocked, onFallback = { showFingerprint = false },
            )
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Dossier sécurisé") },
        text = {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                if (mode == VaultMode.PATTERN) {
                    Text(msg ?: "Dessine ton schéma", color = if (msg != null) Color(0xFFF28B82) else LS.Muted, fontSize = 13.sp, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(12.dp))
                    PatternPad(Modifier.size(240.dp)) { attempt(it.asSecret()) }
                } else {
                    OutlinedTextField(
                        pin, { pin = it.filter(Char::isDigit).take(8) }, label = { Text("Code") }, singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    )
                    msg?.let { Text(it, color = Color(0xFFF28B82), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) }
                }
            }
        },
        confirmButton = { if (mode == VaultMode.PIN) TextButton({ attempt(pin) }) { Text("Ouvrir") } },
        dismissButton = { TextButton(onDismiss) { Text("Annuler") } },
    )
}
