package com.linkshare.ui

import android.Manifest
import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.BitmapFactory
import android.media.AudioManager
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player as M3Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.linkshare.R
import com.linkshare.server.PlaybackService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.roundToInt

/** Contrôleur de la lecture en cours (renseigné par [Player]) : sert à arrêter la lecture quand on ferme le lecteur. */
internal object PlayerHost {
    var controller: MediaController? = null

    /** Arrête la lecture et retire la notification (fermeture du lecteur par l'utilisateur). */
    fun stop() {
        val c = controller ?: return
        c.stop()
        c.clearMediaItems()
    }
}

private fun MediaItem.uriString(): String? = (localConfiguration?.uri ?: requestMetadata.mediaUri)?.toString()

private fun fmtTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec) else String.format(Locale.US, "%d:%02d", m, sec)
}

private val SPEEDS = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f)
private val RESIZE_NAMES = listOf("Ajuster", "Remplir", "Étirer")
private val SLEEP_MINUTES = listOf(0, 10, 15, 30, 45, 60, 90)

private fun speedLabel(s: Float) = if (s == 1f) "1x" else (if (s % 1f == 0f) "${s.toInt()}x" else "${s}x")

/** Clé de mémorisation de la position de lecture (reprise). */
private fun resumeKey(url: String) = "rp_" + url.hashCode()

/** Titre, artiste, album et pochette intégrés au fichier audio (fichiers locaux uniquement). */
private class TrackMeta(val title: String?, val artist: String?, val album: String?, val art: ImageBitmap?)

private fun readMeta(url: String): TrackMeta? {
    val u = Uri.parse(url)
    if (u.scheme != "file") return null
    val path = u.path ?: return null
    val r = MediaMetadataRetriever()
    return try {
        r.setDataSource(path)
        fun meta(k: Int) = r.extractMetadata(k)?.trim()?.takeIf { it.isNotEmpty() }
        val art = r.embeddedPicture?.let { bytes ->
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            var sample = 1
            while (bounds.outWidth / sample > 900 || bounds.outHeight / sample > 900) sample *= 2
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })?.asImageBitmap()
        }
        TrackMeta(
            meta(MediaMetadataRetriever.METADATA_KEY_TITLE), meta(MediaMetadataRetriever.METADATA_KEY_ARTIST),
            meta(MediaMetadataRetriever.METADATA_KEY_ALBUM), art,
        )
    } catch (e: Exception) {
        null
    } finally {
        runCatching { r.release() }
    }
}

/** Lecteur d'un seul fichier (ouverture depuis une autre appli). */
@Composable
internal fun Player(url: String, title: String = "", onClose: () -> Unit = {}) {
    Player(listOf(url), listOf(title), 0, onClose = onClose)
}

/**
 * Lecteur plein écran branché sur [PlaybackService] : la lecture continue en arrière-plan (écran éteint, appli quittée
 * avec Accueil), avec les commandes dans la barre de notification et sur l'écran verrouillé, vidéo comme audio.
 *
 * **Vidéo** : commandes en verre dépoli (toucher = afficher / masquer, elles se masquent seules), vitesse de lecture,
 * format d'image (ajuster / remplir / étirer), verrouillage de l'écran, rotation imposée par l'appli, saut ±N s, barre de
 * progression épaisse, modes Aléatoire / Boucle / Tout, file d'attente. Gestes : balayage horizontal = média suivant /
 * précédent ; vertical = volume (droite) ou luminosité (gauche) ; double toucher = ±N s.
 *
 * **Musique** : fond flou animé tiré de la pochette (ou d'une photo), disque vinyle qui tourne / pochette / anneaux
 * (Paramètres › Lecteur), égaliseur animé, titre et artiste lus dans le fichier, vitesse, minuterie de mise en veille.
 *
 * [urls] forme une liste de lecture à partir de [startIndex]. [titles] sert à la notification et à l'écran de
 * verrouillage, [names] à l'affichage dans l'appli. [onIndexChange] est appelé quand le média en cours change.
 */
@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
internal fun Player(
    urls: List<String>,
    titles: List<String>,
    startIndex: Int,
    names: List<String> = titles,
    onClose: () -> Unit = {},
    onIndexChange: (Int) -> Unit = {},
) {
    val ctx = LocalContext.current
    val activity = ctx.findActivity()
    val window = activity?.window
    val start = startIndex.coerceIn(0, (urls.size - 1).coerceAtLeast(0))
    var controller by remember { mutableStateOf<MediaController?>(null) }
    val audioOnly = remember {
        val name = names.getOrElse(start) { "" }.ifEmpty { titles.getOrElse(start) { "" } }
        val ext = if (name.contains('.')) name.substringAfterLast('.')
        else Uri.parse(urls[start]).lastPathSegment?.substringAfterLast('.', "").orEmpty()
        categoryOfExt(ext.lowercase()) == Category.MUSIC || ext.lowercase() in AUD_EXT
    }
    val indexChanged by rememberUpdatedState(onIndexChange)
    val closeNow by rememberUpdatedState(onClose)

    // Modes de lecture (mémorisés) : Aléatoire, Boucle (le titre en cours), Tout (toute la liste)
    val prefs = remember { ctx.getSharedPreferences("linkshare", android.content.Context.MODE_PRIVATE) }
    var shuffle by remember { mutableStateOf(prefs.getBoolean("pl_shuffle", false)) }
    var repeat by remember { mutableIntStateOf(prefs.getInt("pl_repeat", M3Player.REPEAT_MODE_OFF)) }

    // État de lecture
    var current by remember { mutableIntStateOf(start) }
    var wantsPlay by remember { mutableStateOf(true) }
    var buffering by remember { mutableStateOf(false) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var scrubbing by remember { mutableStateOf(false) }
    var scrubValue by remember { mutableFloatStateOf(0f) }
    var speed by remember { mutableFloatStateOf(1f) }
    var resize by remember { mutableIntStateOf(prefs.getInt("pl_resize", 0)) }
    var locked by remember { mutableStateOf(false) }
    val lockedNow by rememberUpdatedState(locked)
    var speedMenu by remember { mutableStateOf(false) }
    var sleepMenu by remember { mutableStateOf(false) }
    var queueOpen by remember { mutableStateOf(false) }
    var sleepAt by remember { mutableStateOf<Long?>(null) }

    // Audio : image de fond tirée au hasard parmi les photos de l'appareil photo, différente à chaque titre
    val photos by produceState(emptyList<File>(), audioOnly) { if (audioOnly) value = withContext(Dispatchers.IO) { cameraPhotos(ctx) } }
    var trackTick by remember { mutableIntStateOf(0) }
    var bg by remember { mutableStateOf<File?>(null) }
    LaunchedEffect(photos, trackTick) {
        if (photos.isNotEmpty()) bg = photos.filter { it != bg }.randomOrNull() ?: photos.first()
    }
    // Audio : titre, artiste et pochette lus dans le fichier
    val meta by produceState<TrackMeta?>(null, current, audioOnly) {
        value = null
        if (audioOnly) value = withContext(Dispatchers.IO) { urls.getOrNull(current)?.let { readMeta(it) } }
    }

    // Retours visuels des gestes
    var volume by remember { mutableStateOf<Float?>(null) }
    var volumeTick by remember { mutableIntStateOf(0) }
    LaunchedEffect(volumeTick) { if (volumeTick > 0) { delay(900); volume = null } }
    var brightness by remember { mutableStateOf<Float?>(null) }
    var brightnessTick by remember { mutableIntStateOf(0) }
    LaunchedEffect(brightnessTick) { if (brightnessTick > 0) { delay(900); brightness = null } }
    var seekHud by remember { mutableStateOf<String?>(null) }
    var seekHudTick by remember { mutableIntStateOf(0) }
    LaunchedEffect(seekHudTick) { if (seekHudTick > 0) { delay(700); seekHud = null } }

    // Commandes visibles : l'audio les garde toujours, la vidéo les masque après quelques secondes de lecture
    var visible by remember { mutableStateOf(true) }
    var hideTick by remember { mutableIntStateOf(0) }
    val show = visible || audioOnly
    LaunchedEffect(visible, hideTick, wantsPlay, scrubbing, speedMenu) {
        if (visible && wantsPlay && !scrubbing && !speedMenu && !audioOnly) { delay(3500); visible = false }
    }
    // Position et durée, rafraîchies tant que la barre est visible
    LaunchedEffect(controller, show) {
        val c = controller ?: return@LaunchedEffect
        while (show) {
            if (!scrubbing) {
                position = c.currentPosition.coerceAtLeast(0)
                duration = c.duration.takeIf { it != C.TIME_UNSET && it > 0 } ?: 0L
            }
            delay(250)
        }
    }

    // ── Reprise de lecture : la position est mémorisée régulièrement
    fun savePosition(c: MediaController) {
        val url = urls.getOrNull(c.currentMediaItemIndex) ?: return
        val dur = c.duration
        val pos = c.currentPosition
        val e = prefs.edit()
        if (UiStyle.resumePlayback && dur != C.TIME_UNSET && dur > 30_000L && pos > 5_000L && pos < dur - 8_000L) e.putLong(resumeKey(url), pos)
        else e.remove(resumeKey(url))
        e.apply()
    }
    LaunchedEffect(controller) {
        val c = controller ?: return@LaunchedEffect
        while (true) { delay(4000); if (c.isPlaying) savePosition(c) }
    }

    // ── Minuterie de mise en veille
    LaunchedEffect(sleepAt) {
        val t = sleepAt ?: return@LaunchedEffect
        delay((t - System.currentTimeMillis()).coerceAtLeast(0L))
        controller?.pause()
        sleepAt = null
        Toast.makeText(ctx, "Minuterie : lecture mise en pause", Toast.LENGTH_SHORT).show()
    }

    // ── Rotation : imposée par l'appli (ignore le capteur et le réglage « rotation automatique »)
    val isLandscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    fun rotate() {
        activity?.requestedOrientation =
            if (isLandscape) ActivityInfo.SCREEN_ORIENTATION_PORTRAIT else ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        hideTick++
    }
    // En quittant le lecteur, l'appli reprend l'orientation normale du téléphone
    DisposableEffect(Unit) {
        onDispose { activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED }
    }
    // Vidéo : plein écran sans barres système (elles reviennent d'un balayage depuis le bord)
    DisposableEffect(audioOnly) {
        val w = window
        if (audioOnly || w == null) return@DisposableEffect onDispose {}
        val ic = WindowCompat.getInsetsController(w, w.decorView)
        ic.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        ic.hide(WindowInsetsCompat.Type.systemBars())
        onDispose { ic.show(WindowInsetsCompat.Type.systemBars()) }
    }
    // Le lecteur de musique est toujours sombre : icônes claires dans la barre d'état
    DisposableEffect(Unit) {
        val w = window
        val ic = w?.let { WindowCompat.getInsetsController(it, it.decorView) }
        val wasLight = ic?.isAppearanceLightStatusBars ?: false
        ic?.isAppearanceLightStatusBars = false
        onDispose { ic?.isAppearanceLightStatusBars = wasLight }
    }
    // La luminosité réglée au balayage ne vaut que pour le lecteur : on rend la main au système en le quittant
    DisposableEffect(Unit) {
        onDispose { window?.let { w -> w.attributes = w.attributes.apply { screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE } } }
    }

    // Android 13+ : sans cette autorisation, la notification de lecture n'apparaît pas
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) { if (needsNotifPermission(ctx)) notif.launch(Manifest.permission.POST_NOTIFICATIONS) }
    BackHandler {
        when {
            locked -> { visible = true; hideTick++ }
            else -> closeNow()
        }
    }

    DisposableEffect(urls) {
        var disposed = false
        var attached: MediaController? = null
        var listener: M3Player.Listener? = null
        val token = SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        val future = MediaController.Builder(ctx, token).buildAsync()
        future.addListener({
            if (disposed) return@addListener
            val c = runCatching { future.get() }.getOrNull() ?: return@addListener
            // Même liste déjà en cours (activité recréée, retour depuis l'écran d'accueil) : on se rattache
            // sans relancer la lecture, au lieu de repartir de zéro.
            val already = c.mediaItemCount == urls.size &&
                (0 until c.mediaItemCount).all { c.getMediaItemAt(it).uriString() == urls[it] }
            if (!already) {
                val items = urls.mapIndexed { i, u ->
                    MediaItem.Builder()
                        .setUri(u)
                        .setRequestMetadata(MediaItem.RequestMetadata.Builder().setMediaUri(Uri.parse(u)).build())
                        .setMediaMetadata(MediaMetadata.Builder().setTitle(titles.getOrElse(i) { "" }).build())
                        .build()
                }
                // Reprise : on repart là où ce média avait été laissé
                val saved = if (UiStyle.resumePlayback) prefs.getLong(resumeKey(urls[start]), 0L) else 0L
                c.setMediaItems(items, start, if (saved > 3_000L) saved else C.TIME_UNSET)
                c.setPlaybackParameters(PlaybackParameters(1f))
                c.prepare(); c.playWhenReady = true
                if (saved > 3_000L) Toast.makeText(ctx, "Reprise à " + fmtTime(saved), Toast.LENGTH_SHORT).show()
            } else indexChanged(c.currentMediaItemIndex)
            c.shuffleModeEnabled = shuffle
            c.repeatMode = repeat
            current = c.currentMediaItemIndex
            wantsPlay = c.playWhenReady
            buffering = c.playbackState == M3Player.STATE_BUFFERING
            speed = c.playbackParameters.speed
            val l = object : M3Player.Listener {
                override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                    current = c.currentMediaItemIndex
                    indexChanged(c.currentMediaItemIndex); trackTick++
                }
                override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) { shuffle = shuffleModeEnabled }
                override fun onRepeatModeChanged(repeatMode: Int) { repeat = repeatMode }
                override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) { wantsPlay = playWhenReady }
                override fun onPlaybackStateChanged(playbackState: Int) {
                    buffering = playbackState == M3Player.STATE_BUFFERING
                    if (playbackState == M3Player.STATE_ENDED) urls.getOrNull(c.currentMediaItemIndex)?.let { prefs.edit().remove(resumeKey(it)).apply() }
                }
                override fun onPlaybackParametersChanged(playbackParameters: PlaybackParameters) { speed = playbackParameters.speed }
            }
            c.addListener(l)
            attached = c; listener = l
            PlayerHost.controller = c
            controller = c
        }, ContextCompat.getMainExecutor(ctx))
        onDispose {
            disposed = true
            val a = attached; val l = listener
            if (a != null) runCatching { savePosition(a) }
            if (a != null && l != null) a.removeListener(l)
            if (PlayerHost.controller === controller) PlayerHost.controller = null
            controller = null
            MediaController.releaseFuture(future)
        }
    }

    fun seekBy(deltaMs: Long) {
        val c = controller ?: return
        var to = (c.currentPosition + deltaMs).coerceAtLeast(0)
        if (c.duration != C.TIME_UNSET && c.duration > 0) to = to.coerceAtMost(c.duration)
        c.seekTo(to)
        position = to
        seekHud = if (deltaMs > 0) "+${deltaMs / 1000} s" else "−${-deltaMs / 1000} s"
        seekHudTick++
    }
    val stepMs = UiStyle.seekStep * 1000L
    fun togglePlay() {
        val c = controller ?: return
        if (c.playWhenReady) c.pause() else {
            // Fin de liste atteinte : on repart du début plutôt que de ne rien faire
            if (c.playbackState == M3Player.STATE_ENDED) c.seekToDefaultPosition(0)
            c.play()
        }
        hideTick++
    }
    fun previous() {
        val c = controller ?: return
        if (c.currentPosition > 3000 || !c.hasPreviousMediaItem()) c.seekTo(0) else c.seekToPreviousMediaItem()
        hideTick++
    }
    fun next() {
        val c = controller ?: return
        if (c.hasNextMediaItem()) c.seekToNextMediaItem()
        hideTick++
    }
    fun toggleShuffle() {
        shuffle = !shuffle
        controller?.shuffleModeEnabled = shuffle
        prefs.edit().putBoolean("pl_shuffle", shuffle).apply()
        Toast.makeText(ctx, "Aléatoire " + if (shuffle) "activé" else "désactivé", Toast.LENGTH_SHORT).show()
        hideTick++
    }
    fun setRepeat(mode: Int) {
        repeat = mode
        controller?.repeatMode = mode
        prefs.edit().putInt("pl_repeat", mode).apply()
        Toast.makeText(
            ctx,
            when (mode) {
                M3Player.REPEAT_MODE_ONE -> "Boucle sur ce titre"
                M3Player.REPEAT_MODE_ALL -> "Répéter toute la liste"
                else -> "Répétition désactivée"
            },
            Toast.LENGTH_SHORT,
        ).show()
        hideTick++
    }
    fun setSpeed(s: Float) {
        speed = s
        controller?.setPlaybackParameters(PlaybackParameters(s))
        hideTick++
    }
    fun scrubTo(f: Float) { scrubbing = true; scrubValue = f; hideTick++ }
    fun scrubEnd() {
        val to = (scrubValue * duration.coerceAtLeast(1L)).toLong()
        controller?.seekTo(to)
        position = to
        scrubbing = false
    }

    val dur = duration.coerceAtLeast(1L)
    val shownPos = if (scrubbing) (scrubValue * dur).toLong() else position
    val frac = if (scrubbing) scrubValue else (position.toFloat() / dur).coerceIn(0f, 1f)
    val playing = wantsPlay && !buffering
    val name = names.getOrElse(current) { "" }

    @Composable
    fun SpeedMenu() = DropdownMenu(speedMenu, { speedMenu = false }) {
        SPEEDS.forEach { s ->
            DropdownMenuItem(
                text = { Text(speedLabel(s) + if (s == speed) "  ✓" else "") },
                onClick = { setSpeed(s); speedMenu = false },
            )
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (audioOnly) {
            // ═══════════════ Lecteur de musique ═══════════════
            AudioBackdrop(meta?.art, bg)
            Column(
                Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing).padding(horizontal = 22.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    GlassBtn(Ic.Expand, "Fermer") { closeNow() }
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("EN LECTURE", color = Color.White.copy(alpha = 0.65f), fontSize = 11.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 2.sp)
                        if (urls.size > 1) Text("${current + 1} / ${urls.size}", color = Color.White, fontSize = 12.sp)
                    }
                    GlassBtn(Ic.Queue, "File d'attente", enabled = urls.size > 1) { queueOpen = true }
                }
                Box(Modifier.weight(1f).fillMaxWidth().padding(vertical = 14.dp), contentAlignment = Alignment.Center) {
                    val art = Modifier.aspectRatio(1f, matchHeightConstraintsFirst = true)
                    when (UiStyle.audioStyle) {
                        1 -> CoverArt(playing, meta?.art, bg, art)
                        2 -> RingsArt(playing, meta?.art, bg, art)
                        else -> Vinyl(playing, meta?.art, bg, art)
                    }
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            meta?.title ?: name.substringBeforeLast('.'), color = Color.White, fontSize = 22.sp,
                            fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            listOfNotNull(meta?.artist, meta?.album).joinToString(" · ").ifEmpty { "Artiste inconnu" },
                            color = Color.White.copy(alpha = 0.7f), fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Equalizer(playing, LS.Blue, Modifier.size(width = 26.dp, height = 24.dp))
                }
                Spacer(Modifier.height(16.dp))
                SeekBar(frac, duration > 0, ::scrubTo, ::scrubEnd)
                Row(Modifier.fillMaxWidth()) {
                    Text(fmtTime(shownPos), color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
                    Spacer(Modifier.weight(1f))
                    Text(if (duration > 0) "−" + fmtTime(duration - shownPos) else "--:--", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    ModeBtn(Ic.Shuffle, "Aléatoire", shuffle) { toggleShuffle() }
                    IconTap(Ic.SkipPrev, "Précédent", 46.dp) { previous() }
                    PlayButton(wantsPlay, buffering, 76.dp) { togglePlay() }
                    IconTap(Ic.SkipNext, "Suivant", 46.dp, enabled = urls.size > 1) { next() }
                    ModeBtn(
                        if (repeat == M3Player.REPEAT_MODE_ONE) Ic.RepeatOne else Ic.Repeat, "Répéter",
                        repeat != M3Player.REPEAT_MODE_OFF,
                    ) {
                        setRepeat(
                            when (repeat) {
                                M3Player.REPEAT_MODE_OFF -> M3Player.REPEAT_MODE_ALL
                                M3Player.REPEAT_MODE_ALL -> M3Player.REPEAT_MODE_ONE
                                else -> M3Player.REPEAT_MODE_OFF
                            }
                        )
                    }
                }
                Spacer(Modifier.height(16.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)) {
                    GlassChip(Ic.Back, "${UiStyle.seekStep} s") { seekBy(-stepMs) }
                    Box {
                        GlassChip(Ic.Speed, speedLabel(speed), on = speed != 1f) { speedMenu = true }
                        SpeedMenu()
                    }
                    Box {
                        val left = sleepAt?.let { ((it - System.currentTimeMillis()) / 60_000L + 1).coerceAtLeast(1) }
                        GlassChip(Ic.Timer, if (left != null) "$left min" else "Veille", on = left != null) { sleepMenu = true }
                        DropdownMenu(sleepMenu, { sleepMenu = false }) {
                            SLEEP_MINUTES.forEach { m ->
                                DropdownMenuItem(
                                    text = { Text(if (m == 0) "Désactivée" else "$m minutes") },
                                    onClick = {
                                        sleepMenu = false
                                        sleepAt = if (m == 0) null else System.currentTimeMillis() + m * 60_000L
                                        if (m > 0) Toast.makeText(ctx, "Pause automatique dans $m min", Toast.LENGTH_SHORT).show()
                                    },
                                )
                            }
                        }
                    }
                    GlassChip(Ic.Forward, "${UiStyle.seekStep} s") { seekBy(stepMs) }
                }
                Spacer(Modifier.height(14.dp))
            }
        } else {
            // ═══════════════ Lecteur vidéo ═══════════════
            AndroidView(
                factory = { c ->
                    PlayerView(c).apply {
                        useController = false // commandes dessinées par l'appli (voir plus bas)
                        setShutterBackgroundColor(android.graphics.Color.BLACK)
                        defaultArtwork = ContextCompat.getDrawable(c, R.drawable.ic_logo)
                        attachGestures(
                            this, window,
                            isLocked = { lockedNow },
                            onVolume = { v -> volume = v; volumeTick++ },
                            onBrightness = { v -> brightness = v; brightnessTick++ },
                            onTap = { visible = !visible; hideTick++ },
                            onDoubleTap = { forward -> seekBy(if (forward) UiStyle.seekStep * 1000L else -UiStyle.seekStep * 1000L) },
                        )
                    }
                },
                update = {
                    it.player = controller
                    it.keepScreenOn = UiStyle.keepScreenOn
                    it.resizeMode = when (resize) {
                        1 -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                        2 -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                        else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                    }
                },
                modifier = Modifier.fillMaxSize(),
            )

            AnimatedVisibility(
                visible = show && !locked, modifier = Modifier.fillMaxSize(),
                enter = fadeIn(tween(160)), exit = fadeOut(tween(240)),
            ) {
                Box(Modifier.fillMaxSize()) {
                    // Voiles dégradés : gardent les commandes lisibles sur n'importe quelle image
                    Box(
                        Modifier.align(Alignment.TopCenter).fillMaxWidth().height(130.dp)
                            .background(Brush.verticalGradient(listOf(Color(0xD9000000), Color.Transparent)))
                    )
                    Box(
                        Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(200.dp)
                            .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xEB000000))))
                    )

                    // ── Haut : retour, titre, vitesse, format, verrou, rotation
                    Row(
                        Modifier.align(Alignment.TopCenter).fillMaxWidth()
                            .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Top + WindowInsetsSides.Horizontal))
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        GlassBtn(Ic.Back, "Retour") { closeNow() }
                        Column(Modifier.weight(1f).padding(horizontal = 6.dp)) {
                            Text(name, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (urls.size > 1) Text("${current + 1} / ${urls.size}", color = Color(0xCCFFFFFF), fontSize = 11.sp)
                        }
                        Box {
                            GlassBtn(Ic.Speed, "Vitesse : ${speedLabel(speed)}", on = speed != 1f) { speedMenu = true }
                            SpeedMenu()
                        }
                        GlassBtn(Ic.AspectRatio, "Format de l'image") {
                            resize = (resize + 1) % RESIZE_NAMES.size
                            prefs.edit().putInt("pl_resize", resize).apply()
                            Toast.makeText(ctx, "Image : " + RESIZE_NAMES[resize], Toast.LENGTH_SHORT).show()
                            hideTick++
                        }
                        GlassBtn(Ic.Lock, "Verrouiller l'écran") {
                            locked = true; visible = true; hideTick++
                            Toast.makeText(ctx, "Écran verrouillé : touche le cadenas pour déverrouiller", Toast.LENGTH_SHORT).show()
                        }
                        GlassBtn(
                            if (isLandscape) Ic.Phone else Ic.PhoneLandscape,
                            if (isLandscape) "Passer en portrait" else "Passer en paysage",
                        ) { rotate() }
                    }

                    // ── Centre : précédent, −N s, lecture / pause, +N s, suivant
                    Row(
                        Modifier.align(Alignment.Center),
                        horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically,
                    ) {
                        IconTap(Ic.SkipPrev, "Précédent", 44.dp, enabled = urls.size > 1) { previous() }
                        SeekBtn(UiStyle.seekStep, forward = false) { seekBy(-stepMs); hideTick++ }
                        PlayButton(wantsPlay, buffering, 70.dp) { togglePlay() }
                        SeekBtn(UiStyle.seekStep, forward = true) { seekBy(stepMs); hideTick++ }
                        IconTap(Ic.SkipNext, "Suivant", 44.dp, enabled = urls.size > 1) { next() }
                    }

                    // ── Bas : progression, modes de lecture
                    Column(
                        Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                            .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Bottom + WindowInsetsSides.Horizontal))
                            .padding(horizontal = 18.dp).padding(bottom = 8.dp),
                    ) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(fmtTime(shownPos), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Text(" / " + (if (duration > 0) fmtTime(duration) else "--:--"), color = Color(0xB3FFFFFF), fontSize = 12.sp)
                            Spacer(Modifier.weight(1f))
                            if (speed != 1f) Text(
                                speedLabel(speed), Modifier.clip(CircleShape).background(LS.Blue).padding(horizontal = 8.dp, vertical = 2.dp),
                                color = LS.OnBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                            )
                        }
                        SeekBar(frac, duration > 0, ::scrubTo, ::scrubEnd)
                        Row(
                            Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            ModeBtn(Ic.Shuffle, "Aléatoire", shuffle) { toggleShuffle() }
                            ModeBtn(Ic.RepeatOne, "Boucle", repeat == M3Player.REPEAT_MODE_ONE) {
                                setRepeat(if (repeat == M3Player.REPEAT_MODE_ONE) M3Player.REPEAT_MODE_OFF else M3Player.REPEAT_MODE_ONE)
                            }
                            ModeBtn(Ic.Repeat, "Tout", repeat == M3Player.REPEAT_MODE_ALL) {
                                setRepeat(if (repeat == M3Player.REPEAT_MODE_ALL) M3Player.REPEAT_MODE_OFF else M3Player.REPEAT_MODE_ALL)
                            }
                            Spacer(Modifier.weight(1f))
                            if (urls.size > 1) ModeBtn(Ic.Queue, "File d'attente", false) { queueOpen = true }
                        }
                    }
                }
            }

            // Écran verrouillé : seuls le cadenas (et l'affichage) répondent
            if (locked) AnimatedVisibility(
                visible = visible, modifier = Modifier.fillMaxSize(),
                enter = fadeIn(tween(160)), exit = fadeOut(tween(240)),
            ) {
                Box(Modifier.fillMaxSize()) {
                    Column(
                        Modifier.align(Alignment.CenterStart).padding(start = 28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        GlassBtn(Ic.LockOpen, "Déverrouiller", size = 58.dp) { locked = false; visible = true; hideTick++ }
                        Spacer(Modifier.height(6.dp))
                        Text("Verrouillé", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
                    }
                }
            }
        }

        seekHud?.let { t ->
            Text(
                t, Modifier.align(Alignment.Center).offset(y = (-104).dp).clip(RoundedCornerShape(18.dp))
                    .background(Color(0xCC000000)).padding(horizontal = 16.dp, vertical = 8.dp),
                color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
            )
        }
        volume?.let { LevelHud(Ic.Volume, it, Modifier.align(Alignment.Center)) }
        brightness?.let { LevelHud(Ic.Brightness, it, Modifier.align(Alignment.Center)) }
    }

    // ── File d'attente : toucher un titre le lance
    if (queueOpen) ModalBottomSheet(
        onDismissRequest = { queueOpen = false },
        containerColor = Color(0xFF141414), contentColor = Color.White,
    ) {
        Text(
            "File d'attente · ${urls.size}", Modifier.padding(start = 20.dp, bottom = 8.dp),
            color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
        )
        LazyColumn(Modifier.fillMaxWidth().heightIn(max = 520.dp).navigationBarsPadding(), contentPadding = PaddingValues(bottom = 16.dp)) {
            itemsIndexed(urls) { i, _ ->
                val on = i == current
                Row(
                    Modifier.fillMaxWidth().clickable {
                        controller?.let { c -> c.seekToDefaultPosition(i); c.play() }
                        queueOpen = false
                    }.background(if (on) LS.Blue.copy(alpha = 0.16f) else Color.Transparent)
                        .padding(horizontal = 20.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.width(30.dp), contentAlignment = Alignment.CenterStart) {
                        if (on) Equalizer(playing, LS.Blue, Modifier.size(width = 18.dp, height = 16.dp))
                        else Text("${i + 1}", color = Color.White.copy(alpha = 0.5f), fontSize = 13.sp)
                    }
                    Text(
                        names.getOrElse(i) { titles.getOrElse(i) { "" } }, Modifier.weight(1f),
                        color = if (on) LS.Blue else Color.White, fontSize = 15.sp,
                        fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal,
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
    }
}

// ═══════════════════════════ Éléments du lecteur ═══════════════════════════

/** Fond du lecteur de musique : pochette (ou photo) très floutée, halos de couleur qui dérivent lentement. */
@Composable
private fun AudioBackdrop(art: ImageBitmap?, photo: File?) {
    val accent = LS.Blue
    val second = LS.Pink
    val inf = rememberInfiniteTransition(label = "fond")
    val t by inf.animateFloat(
        0f, if (UiStyle.animations) 1f else 0f,
        infiniteRepeatable(tween(16000, easing = LinearEasing), RepeatMode.Reverse), label = "drift",
    )
    val blurOk = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
    Box(Modifier.fillMaxSize()) {
        val m = Modifier.fillMaxSize().scale(1.35f).blur(60.dp)
        when {
            art != null -> Image(art, null, m, contentScale = ContentScale.Crop)
            photo != null -> AsyncImage(model = photo, contentDescription = null, modifier = m, contentScale = ContentScale.Crop)
        }
        Canvas(Modifier.fillMaxSize()) {
            val r = size.maxDimension * 0.7f
            val c1 = Offset(size.width * (0.15f + 0.7f * t), size.height * 0.22f)
            val c2 = Offset(size.width * (0.85f - 0.7f * t), size.height * 0.78f)
            drawCircle(Brush.radialGradient(listOf(accent.copy(alpha = 0.42f), Color.Transparent), c1, r), r, c1)
            drawCircle(Brush.radialGradient(listOf(second.copy(alpha = 0.30f), Color.Transparent), c2, r), r, c2)
        }
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    listOf(
                        Color.Black.copy(alpha = if (blurOk) 0.45f else 0.7f),
                        Color.Black.copy(alpha = if (blurOk) 0.25f else 0.55f),
                        Color.Black.copy(alpha = 0.9f),
                    )
                )
            )
        )
    }
}

/** Pochette du titre, sinon photo, sinon logo sur dégradé. */
@Composable
private fun ArtImage(art: ImageBitmap?, photo: File?, modifier: Modifier) {
    when {
        art != null -> Image(art, null, modifier, contentScale = ContentScale.Crop)
        photo != null -> AsyncImage(model = photo, contentDescription = null, modifier = modifier, contentScale = ContentScale.Crop)
        else -> Box(
            modifier.background(Brush.linearGradient(listOf(lerp(LS.Blue, Color.Black, 0.2f), lerp(LS.Purple, Color.Black, 0.4f)))),
            contentAlignment = Alignment.Center,
        ) { Image(painterResource(R.drawable.ic_logo), null, Modifier.fillMaxSize(0.55f)) }
    }
}

/** Disque vinyle qui tourne pendant la lecture, pochette au centre. */
@Composable
private fun Vinyl(playing: Boolean, art: ImageBitmap?, photo: File?, modifier: Modifier) {
    val rot = remember { Animatable(0f) }
    LaunchedEffect(playing, UiStyle.animations) {
        if (!playing || !UiStyle.animations) return@LaunchedEffect
        while (true) {
            rot.snapTo(rot.value % 360f)
            rot.animateTo(rot.value + 360f, tween(12000, easing = LinearEasing))
        }
    }
    val glow = LS.Blue
    Box(modifier, contentAlignment = Alignment.Center) {
        Box(Modifier.fillMaxSize().background(Brush.radialGradient(listOf(glow.copy(alpha = 0.38f), Color.Transparent))))
        Box(
            Modifier.fillMaxSize(0.9f).shadow(24.dp, CircleShape).graphicsLayer { rotationZ = rot.value }
                .clip(CircleShape).background(Color(0xFF0A0A0A)),
            contentAlignment = Alignment.Center,
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val rMax = size.minDimension / 2f
                for (i in 0 until 22) {
                    drawCircle(
                        Color.White.copy(alpha = if (i % 4 == 0) 0.07f else 0.035f),
                        radius = rMax * (0.40f + i * 0.027f), style = Stroke(1.dp.toPx()),
                    )
                }
                drawCircle(glow.copy(alpha = 0.55f), radius = rMax * 0.395f, style = Stroke(3.dp.toPx()))
            }
            ArtImage(art, photo, Modifier.fillMaxSize(0.38f).clip(CircleShape))
            Box(Modifier.size(12.dp).clip(CircleShape).background(Color(0xFF0A0A0A)).border(2.dp, Color.White.copy(alpha = 0.35f), CircleShape))
        }
        // Reflet fixe (ne tourne pas) : donne l'effet de disque brillant
        Canvas(Modifier.fillMaxSize(0.9f)) {
            drawArc(
                Brush.sweepGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.10f), Color.Transparent)),
                startAngle = -70f, sweepAngle = 50f, useCenter = true,
            )
            drawArc(
                Brush.sweepGradient(listOf(Color.Transparent, Color.White.copy(alpha = 0.07f), Color.Transparent)),
                startAngle = 110f, sweepAngle = 50f, useCenter = true,
            )
        }
    }
}

/** Grande pochette arrondie qui « respire » : pleine taille en lecture, plus petite en pause. */
@Composable
private fun CoverArt(playing: Boolean, art: ImageBitmap?, photo: File?, modifier: Modifier) {
    val s by animateFloatAsState(if (playing) 1f else 0.84f, spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessLow), label = "cover")
    val shape = RoundedCornerShape(30.dp)
    Box(modifier.padding(8.dp), contentAlignment = Alignment.Center) {
        Box(
            Modifier.fillMaxSize().graphicsLayer { scaleX = s; scaleY = s }
                .shadow(36.dp, shape, ambientColor = LS.Blue, spotColor = LS.Blue).clip(shape).background(Color(0xFF151515)),
        ) { ArtImage(art, photo, Modifier.fillMaxSize()) }
    }
}

/** Pochette ronde entourée d'ondes qui s'élargissent au rythme de la lecture. */
@Composable
private fun RingsArt(playing: Boolean, art: ImageBitmap?, photo: File?, modifier: Modifier) {
    val inf = rememberInfiniteTransition(label = "rings")
    val p by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2600, easing = LinearEasing)), label = "ring")
    val accent = LS.Blue
    val on = playing && UiStyle.animations
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val rMax = size.minDimension / 2f
            repeat(3) { k ->
                val t = if (on) (p + k / 3f) % 1f else 0.3f + k * 0.2f
                drawCircle(accent.copy(alpha = (1f - t) * 0.45f), radius = rMax * (0.42f + 0.58f * t), style = Stroke(2.5.dp.toPx()))
            }
        }
        ArtImage(art, photo, Modifier.fillMaxSize(0.56f).shadow(20.dp, CircleShape).clip(CircleShape))
    }
}

/** Petit égaliseur animé (barres qui dansent pendant la lecture). */
@Composable
private fun Equalizer(playing: Boolean, color: Color, modifier: Modifier) {
    val inf = rememberInfiniteTransition(label = "eq")
    val bars = listOf(
        inf.animateFloat(0.2f, 1f, infiniteRepeatable(tween(420, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "b0"),
        inf.animateFloat(0.2f, 1f, infiniteRepeatable(tween(560, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "b1"),
        inf.animateFloat(0.2f, 1f, infiniteRepeatable(tween(350, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "b2"),
        inf.animateFloat(0.2f, 1f, infiniteRepeatable(tween(480, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "b3"),
    )
    val on = playing && UiStyle.animations
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.Bottom) {
        bars.forEachIndexed { i, h ->
            Box(
                Modifier.weight(1f).fillMaxHeight(if (on) h.value else 0.25f + 0.1f * i)
                    .clip(RoundedCornerShape(topStart = 2.dp, topEnd = 2.dp)).background(color)
            )
        }
    }
}

/** Gros bouton lecture / pause : dégradé de l'accent, halo qui pulse pendant la lecture, effet d'appui. */
@Composable
private fun PlayButton(playing: Boolean, buffering: Boolean, size: Dp, onClick: () -> Unit) {
    val inf = rememberInfiniteTransition(label = "halo")
    val g by inf.animateFloat(0.82f, 1.12f, infiniteRepeatable(tween(1300), RepeatMode.Reverse), label = "g")
    val halo = if (playing && UiStyle.animations) g else 0.9f
    val press = remember { MutableInteractionSource() }
    val pressed by press.collectIsPressedAsState()
    val s by animateFloatAsState(if (pressed) 0.88f else 1f, spring(dampingRatio = 0.5f), label = "press")
    val accent = LS.Blue
    Box(Modifier.size(size * 1.45f), contentAlignment = Alignment.Center) {
        Box(
            Modifier.fillMaxSize().graphicsLayer { scaleX = halo; scaleY = halo }
                .background(Brush.radialGradient(listOf(accent.copy(alpha = 0.5f), Color.Transparent)), CircleShape)
        )
        Box(
            Modifier.size(size).graphicsLayer { scaleX = s; scaleY = s }.clip(CircleShape)
                .background(Brush.linearGradient(listOf(lerp(accent, Color.White, 0.3f), accent, lerp(accent, LS.Purple, 0.45f))))
                .clickable(interactionSource = press, indication = null, onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            if (buffering) CircularProgressIndicator(Modifier.size(size * 0.46f), color = LS.OnBlue, strokeWidth = 3.dp)
            else Crossfade(playing, label = "pp") { p ->
                Icon(if (p) Ic.Pause else Ic.Play, if (p) "Pause" else "Lecture", Modifier.size(size * 0.5f), tint = LS.OnBlue)
            }
        }
    }
}

/**
 * Barre de progression : piste épaisse en dégradé de l'accent, pastille qui grossit pendant qu'on la fait glisser.
 * Toucher = aller directement à cet endroit.
 */
@Composable
private fun SeekBar(fraction: Float, enabled: Boolean, onScrub: (Float) -> Unit, onScrubEnd: () -> Unit) {
    var w by remember { mutableIntStateOf(1) }
    var dragging by remember { mutableStateOf(false) }
    val scrub by rememberUpdatedState(onScrub)
    val end by rememberUpdatedState(onScrubEnd)
    val h by animateDpAsState(if (dragging) 8.dp else 5.dp, label = "track")
    val thumb by animateDpAsState(if (dragging) 20.dp else 14.dp, label = "thumb")
    val accent = LS.Blue
    val f = fraction.coerceIn(0f, 1f)
    Box(
        Modifier.fillMaxWidth().height(32.dp).onSizeChanged { w = it.width.coerceAtLeast(1) }
            .pointerInput(enabled) {
                if (!enabled) return@pointerInput
                detectTapGestures { o -> scrub((o.x / w).coerceIn(0f, 1f)); end() }
            }
            .pointerInput(enabled) {
                if (!enabled) return@pointerInput
                detectHorizontalDragGestures(
                    onDragStart = { o -> dragging = true; scrub((o.x / w).coerceIn(0f, 1f)) },
                    onDragEnd = { dragging = false; end() },
                    onDragCancel = { dragging = false; end() },
                ) { change, _ ->
                    change.consume()
                    scrub((change.position.x / w).coerceIn(0f, 1f))
                }
            },
        contentAlignment = Alignment.CenterStart,
    ) {
        Box(Modifier.fillMaxWidth().height(h).clip(CircleShape).background(Color.White.copy(alpha = 0.22f)))
        Box(
            Modifier.fillMaxWidth(f).height(h).clip(CircleShape)
                .background(Brush.horizontalGradient(listOf(lerp(accent, LS.Purple, 0.5f), accent)))
        )
        Box(
            Modifier.offset { IntOffset((f * w - thumb.toPx() / 2f).roundToInt(), 0) }
                .size(thumb).shadow(6.dp, CircleShape).clip(CircleShape).background(Color.White)
        )
    }
}

/** Bouton rond « verre dépoli ». */
@Composable
private fun GlassBtn(
    icon: ImageVector, desc: String, size: Dp = 42.dp, on: Boolean = false, enabled: Boolean = true,
    modifier: Modifier = Modifier, onClick: () -> Unit,
) {
    Box(
        modifier.size(size).alpha(if (enabled) 1f else 0.35f).clip(CircleShape)
            .background(if (on) LS.Blue else Color.White.copy(alpha = 0.14f))
            .border(1.dp, Color.White.copy(alpha = 0.16f), CircleShape)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, desc, Modifier.size(size * 0.5f), tint = if (on) LS.OnBlue else Color.White) }
}

/** Pastille « verre » avec icône + texte (vitesse, minuterie, saut). */
@Composable
private fun GlassChip(icon: ImageVector, label: String, on: Boolean = false, onClick: () -> Unit) {
    Row(
        Modifier.clip(CircleShape).background(if (on) LS.Blue else Color.White.copy(alpha = 0.12f))
            .border(1.dp, Color.White.copy(alpha = 0.14f), CircleShape)
            .clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, Modifier.size(16.dp), tint = if (on) LS.OnBlue else Color.White)
        Spacer(Modifier.width(5.dp))
        Text(label, color = if (on) LS.OnBlue else Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

/** Icône seule, sans fond (précédent / suivant). */
@Composable
private fun IconTap(icon: ImageVector, desc: String, size: Dp, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        Modifier.size(size).alpha(if (enabled) 1f else 0.35f).clip(CircleShape).clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, desc, Modifier.size(size * 0.62f), tint = Color.White) }
}

/** Saut de N s : flèche + « N s ». */
@Composable
private fun SeekBtn(seconds: Int, forward: Boolean, onClick: () -> Unit) {
    Column(
        Modifier.size(50.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.08f)).clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
    ) {
        Icon(
            if (forward) Ic.Chevron else Ic.Back,
            if (forward) "Avancer de $seconds secondes" else "Reculer de $seconds secondes", Modifier.size(22.dp), tint = Color.White,
        )
        Text("$seconds s", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
    }
}

/** Bouton de mode (Aléatoire / Boucle / Tout) : rond, accentué quand il est actif. */
@Composable
private fun ModeBtn(icon: ImageVector, desc: String, on: Boolean, onClick: () -> Unit) {
    val bg by androidx.compose.animation.animateColorAsState(if (on) LS.Blue else Color.White.copy(alpha = 0.12f), tween(220), label = "mode")
    Box(
        Modifier.size(42.dp).clip(CircleShape).background(bg).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, desc, Modifier.size(20.dp), tint = if (on) LS.OnBlue else Color.White) }
}

/**
 * Gestes sur l'écran du lecteur (les boutons et la barre de progression gardent la priorité, ils reçoivent le toucher en premier) :
 * toucher = commandes ; double toucher = ±N s (moitié droite / gauche) ; balayage horizontal = média suivant / précédent ;
 * balayage vertical = volume (moitié droite) ou luminosité de l'écran (moitié gauche).
 */
@SuppressLint("ClickableViewAccessibility")
private fun attachGestures(
    pv: PlayerView, window: android.view.Window?,
    isLocked: () -> Boolean,
    onVolume: (Float) -> Unit, onBrightness: (Float) -> Unit,
    onTap: () -> Unit, onDoubleTap: (forward: Boolean) -> Unit,
) {
    val ctx = pv.context
    val audio = ctx.getSystemService(AudioManager::class.java)
    val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    val swipeDistance = ctx.resources.displayMetrics.density * 72f
    val taps = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true
        override fun onSingleTapConfirmed(e: MotionEvent): Boolean { onTap(); return true }
        override fun onDoubleTap(e: MotionEvent): Boolean { if (!isLocked()) onDoubleTap(e.x > pv.width / 2f); return true }
    })
    pv.setOnTouchListener(object : View.OnTouchListener {
        var x0 = 0f
        var y0 = 0f
        var mode = 0 // 0 = pas encore décidé, 1 = horizontal (changer de média), 2 = vertical (volume), 3 = vertical (luminosité)
        var bri0 = 0.5f
        var maxVol = 1
        var vol0 = 0f
        var lastStep = -1

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            taps.onTouchEvent(e)
            // Écran verrouillé : seul le toucher simple (afficher le cadenas) est pris en compte
            if (isLocked()) { mode = 0; return true }
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    x0 = e.x; y0 = e.y; mode = 0
                    maxVol = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                    lastStep = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
                    vol0 = lastStep.toFloat() / maxVol
                    // Luminosité de départ : celle de la fenêtre, sinon celle du système
                    bri0 = window?.attributes?.screenBrightness?.takeIf { it >= 0f }
                        ?: (Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128) / 255f)
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.x - x0
                    val dy = e.y - y0
                    if (mode == 0 && hypot(dx, dy) > slop) mode = if (abs(dx) > abs(dy)) 1 else if (x0 < v.width / 2f) 3 else 2
                    if (mode == 3 && window != null) {
                        // Un balayage sur toute la hauteur de l'écran ≈ 130 % de la luminosité (minimum 1 % : jamais noir)
                        val level = (bri0 - dy / v.height.coerceAtLeast(1) * 1.3f).coerceIn(0.01f, 1f)
                        window.attributes = window.attributes.apply { screenBrightness = level }
                        onBrightness(level)
                    }
                    if (mode == 2) {
                        // Un balayage sur toute la hauteur de l'écran ≈ 130 % du volume
                        val level = (vol0 - dy / v.height.coerceAtLeast(1) * 1.3f).coerceIn(0f, 1f)
                        val step = (level * maxVol).roundToInt()
                        if (step != lastStep) {
                            lastStep = step
                            audio.setStreamVolume(AudioManager.STREAM_MUSIC, step, 0)
                        }
                        onVolume(step.toFloat() / maxVol)
                    }
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    val dx = e.x - x0
                    if (mode == 1 && abs(dx) > swipeDistance) {
                        val p = pv.player
                        if (p != null) {
                            if (dx < 0) { if (p.hasNextMediaItem()) p.seekToNextMediaItem() }
                            else if (p.hasPreviousMediaItem()) p.seekToPreviousMediaItem()
                        }
                    }
                    mode = 0
                    return true
                }
                MotionEvent.ACTION_CANCEL -> { mode = 0; return true }
            }
            return false
        }
    })
}

@Composable
private fun LevelHud(icon: ImageVector, level: Float, modifier: Modifier = Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(18.dp)).background(Color(0xCC000000)).padding(horizontal = 22.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, null, Modifier.size(28.dp), tint = Color.White)
        Spacer(Modifier.height(10.dp))
        LinearProgressIndicator(
            progress = { level }, modifier = Modifier.width(120.dp).clip(CircleShape),
            color = LS.Blue, trackColor = Color.White.copy(alpha = 0.25f),
        )
        Spacer(Modifier.height(8.dp))
        Text("${(level * 100).roundToInt()} %", color = Color.White, fontSize = 13.sp)
    }
}
