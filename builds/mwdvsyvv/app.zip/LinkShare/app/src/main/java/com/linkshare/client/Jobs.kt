package com.linkshare.client

import android.content.Context
import android.content.pm.ApplicationInfo
import android.media.MediaScannerConnection
import android.net.Uri
import android.provider.OpenableColumns
import androidx.documentfile.provider.DocumentFile
import com.linkshare.core.*
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.io.File
import java.io.IOException
import java.util.UUID

/**
 * Tous les transferts d'une session, dans les deux sens et en même temps.
 * Chaque élément (fichier, dossier, appli) a sa fiche dans [TransferHub] : pourcentage, débit, annulation.
 */
object Jobs {
    /** Éléments traités en même temps (chaque gros fichier utilise en plus 4 connexions parallèles). */
    private val slots = Semaphore(4)
    private val illegal = Regex("[\\\\/:*?\"<>|\\u0000]")

    private fun clean(n: String) = n.replace(illegal, "_").trim().ifEmpty { "fichier" }
    private fun conn(): Connection = Session.client?.conn ?: throw IOException("Pas de téléphone connecté")
    private fun newId() = UUID.randomUUID().toString()

    private fun scan(ctx: Context, files: List<File>) {
        if (files.isEmpty()) return
        runCatching { MediaScannerConnection.scanFile(ctx, files.map { it.path }.toTypedArray(), null, null) }
    }

    /** Lance un élément : il attend une place libre, puis s'exécute ; la fiche suit son état. */
    private fun run(ctx: Context, rec: Xfer, okText: String, block: suspend () -> Unit) {
        val job = TransferManager.launch(ctx, onError = { }) {
            try {
                slots.withPermit {
                    if (rec.state != XState.RUNNING) return@withPermit
                    block()
                }
                if (rec.state == XState.RUNNING) { rec.finish(); TransferManager.report(true, okText) }
            } catch (e: CancellationException) {
                rec.cancel(); throw e
            } catch (e: Exception) {
                rec.fail(e.message ?: e.toString()); throw e
            }
        }
        rec.canceller = { job.cancel() }
    }

    // ───────────────────────────── Réception (fichiers de l'autre) ─────────────────────────────

    fun download(ctx: Context, e: FileEntry) {
        val app = ctx.applicationContext
        val c = conn(); val rc = Session.client ?: return
        val id = newId()
        if (e.isDir) {
            val rec = TransferHub.track("cli:$id", e.name, Dir.DOWN, -1, Session.peerName)
            run(app, rec, "Dossier ${e.name} reçu dans Download/LinkShare") {
                val files = rc.tree(e.path)
                val total = files.sumOf { it.size }
                rec.total = total
                val g = Group(id, e.name, total)
                val base = uniqueFile(File(receiveDir(), clean(e.name)))
                val prefix = e.path.trimEnd('/') + "/"
                val got = java.util.Collections.synchronizedList(mutableListOf<File>())
                val inner = Semaphore(6) // petits fichiers (photos) : 6 à la fois pour ne jamais laisser le Wi-Fi au repos
                coroutineScope {
                    files.map { f ->
                        async {
                            inner.withPermit {
                                val rel = f.path.removePrefix(prefix)
                                got += FastClient.get(c, f.path, f.size, File(base, rel), rec, g)
                            }
                        }
                    }.awaitAll()
                }
                scan(app, got)
            }
        } else {
            val rec = TransferHub.track("cli:$id", e.name, Dir.DOWN, e.size, Session.peerName)
            run(app, rec, "${e.name} reçu dans Download/LinkShare") {
                val f = FastClient.get(c, e.path, e.size, File(receiveDir(), clean(e.name)), rec, Group(id, e.name, e.size))
                scan(app, listOf(f))
            }
        }
    }

    fun downloadApp(ctx: Context, a: AppEntry) {
        val app = ctx.applicationContext
        val c = conn(); val rc = Session.client ?: return
        val id = newId()
        val rec = TransferHub.track("cli:$id", "${a.name} (appli)", Dir.DOWN, a.size, Session.peerName)
        run(app, rec, "${a.name} (APK) reçu dans Download/LinkShare") {
            val files = rc.appFiles(a.pkg)
            val total = files.sumOf { it.size }
            rec.total = total
            val g = Group(id, "${a.name} (appli)", total)
            if (files.size == 1) {
                FastClient.get(c, files[0].path, files[0].size, File(receiveDir(), clean(a.name) + ".apk"), rec, g, app = true)
            } else {
                // Appli en plusieurs morceaux (APK partiels) : rangés ensemble dans un dossier
                val dir = uniqueFile(File(receiveDir(), clean(a.name) + " (APKs)"))
                for (f in files) FastClient.get(c, f.path, f.size, File(dir, clean(f.name)), rec, g, app = true)
            }
        }
    }

    // ───────────────────────────── Envoi (mes fichiers) ─────────────────────────────

    /** Envoie des fichiers et dossiers de ce téléphone (chemins absolus). */
    fun sendFiles(ctx: Context, items: List<File>) {
        val app = ctx.applicationContext
        val c = conn()
        for (f in items) {
            val id = newId()
            if (f.isDirectory) {
                val rec = TransferHub.track("cli:$id", f.name, Dir.UP, -1, Session.peerName)
                run(app, rec, "Dossier ${f.name} envoyé à ${Session.peerName}") {
                    val files = withContext(Dispatchers.IO) { f.walkTopDown().filter { it.isFile }.toList() }
                    val total = files.sumOf { it.length() }
                    rec.total = total
                    val g = Group(id, f.name, total)
                    val inner = Semaphore(6) // petits fichiers (photos) : 6 à la fois pour ne jamais laisser le Wi-Fi au repos
                    coroutineScope {
                        files.map { x ->
                            async {
                                inner.withPermit {
                                    val rel = clean(f.name) + "/" + x.relativeTo(f).path.replace(File.separatorChar, '/')
                                    FastClient.put(app, c, Source.F(x), rel, x.length(), rec, g)
                                }
                            }
                        }.awaitAll()
                    }
                }
            } else {
                val size = f.length()
                val rec = TransferHub.track("cli:$id", f.name, Dir.UP, size, Session.peerName)
                run(app, rec, "${f.name} envoyé à ${Session.peerName}") {
                    FastClient.put(app, c, Source.F(f), clean(f.name), size, rec, Group(id, f.name, size))
                }
            }
        }
    }

    /** Documents choisis dans le sélecteur Android (photos, fichiers d'autres applis, cloud…). */
    fun sendUris(ctx: Context, uris: List<Uri>) {
        val app = ctx.applicationContext
        val c = conn()
        for (u in uris) {
            val id = newId()
            val name = clean(displayName(app, u))
            val size = FastClient.sizeOf(app, Source.U(u))
            val rec = TransferHub.track("cli:$id", name, Dir.UP, size, Session.peerName)
            run(app, rec, "$name envoyé à ${Session.peerName}") {
                FastClient.put(app, c, Source.U(u), name, size, rec, Group(id, name, size))
            }
        }
    }

    /** Dossier choisi dans le sélecteur Android. */
    fun sendTree(ctx: Context, tree: Uri) {
        val app = ctx.applicationContext
        val c = conn()
        val root = DocumentFile.fromTreeUri(app, tree) ?: return
        val id = newId()
        val rootName = clean(root.name ?: "Dossier")
        val rec = TransferHub.track("cli:$id", rootName, Dir.UP, -1, Session.peerName)
        run(app, rec, "Dossier $rootName envoyé à ${Session.peerName}") {
            val items = mutableListOf<Pair<DocumentFile, String>>()
            fun walk(d: DocumentFile, prefix: String) {
                d.listFiles().forEach {
                    if (it.isDirectory) walk(it, "$prefix${clean(it.name ?: "dossier")}/") else items += it to "$prefix${clean(it.name ?: "fichier")}"
                }
            }
            withContext(Dispatchers.IO) { walk(root, "$rootName/") }
            val total = items.sumOf { it.first.length() }
            rec.total = total
            val g = Group(id, rootName, total)
            val inner = Semaphore(6) // petits fichiers (photos) : 6 à la fois pour ne jamais laisser le Wi-Fi au repos
            coroutineScope {
                items.map { (d, n) ->
                    async { inner.withPermit { FastClient.put(app, c, Source.U(d.uri), n, d.length(), rec, g) } }
                }.awaitAll()
            }
        }
    }

    /** Envoie des applis installées sur ce téléphone (APK ; les applis en plusieurs morceaux partent dans un dossier). */
    fun sendApps(ctx: Context, apps: List<ApplicationInfo>) {
        val app = ctx.applicationContext
        val c = conn()
        val pm = app.packageManager
        for (ai in apps) {
            val id = newId()
            val label = clean(pm.getApplicationLabel(ai).toString())
            val paths = listOf(ai.sourceDir) + (ai.splitSourceDirs?.toList() ?: emptyList())
            val files = paths.map { File(it) }
            val total = files.sumOf { it.length() }
            val rec = TransferHub.track("cli:$id", "$label (appli)", Dir.UP, total, Session.peerName)
            val g = Group(id, "$label (appli)", total)
            run(app, rec, "$label envoyée à ${Session.peerName}") {
                if (files.size == 1) FastClient.put(app, c, Source.F(files[0]), "$label.apk", files[0].length(), rec, g)
                else for (f in files) FastClient.put(app, c, Source.F(f), "$label (APKs)/${f.name}", f.length(), rec, g)
            }
        }
    }

    private fun displayName(ctx: Context, u: Uri): String =
        runCatching {
            ctx.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else null
            }
        }.getOrNull() ?: u.lastPathSegment?.substringAfterLast('/') ?: "fichier"
}
