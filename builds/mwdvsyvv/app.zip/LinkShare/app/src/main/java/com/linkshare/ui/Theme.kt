package com.linkshare.ui

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.Dp

/** Un thème complet de l'appli (fond, cartes, textes, accent par défaut). */
class Palette(
    val name: String,
    val light: Boolean,
    val accent: Color,
    val bg: Color,
    val card: Color,
    val cardTop: Color,
    val card2: Color,
    val text: Color,
    val muted: Color,
    val pill: Color,
    val sheet: Color,
    val line: Color,
)

/**
 * Styles réglables dans Paramètres › Apparence (mémorisés). Toutes les valeurs sont des états Compose :
 * changer un réglage redessine aussitôt toute l'appli.
 */
object UiStyle {
    val themes = listOf(
        Palette("Graphite", false, Color(0xFF8AB4F8), Color(0xFF262626), Color(0xFF151515), Color(0xFF1E1E1E), Color(0xFF343434), Color(0xFFF2F2F2), Color(0xFFA9A9A9), Color(0xFFD9D9D9), Color(0xFF1D1D1D), Color(0x1AFFFFFF)),
        Palette("Noir AMOLED", false, Color(0xFF8AB4F8), Color(0xFF000000), Color(0xFF0D0D0D), Color(0xFF161616), Color(0xFF262626), Color(0xFFF2F2F2), Color(0xFF9E9E9E), Color(0xFFD9D9D9), Color(0xFF0F0F0F), Color(0x17FFFFFF)),
        Palette("Nuit bleue", false, Color(0xFF7AA2FF), Color(0xFF0F1626), Color(0xFF0A101C), Color(0xFF141E33), Color(0xFF1F2A42), Color(0xFFEAF0FF), Color(0xFF93A0BD), Color(0xFFD6E0FF), Color(0xFF121A2C), Color(0x1F9DB4FF)),
        Palette("Forêt", false, Color(0xFF7FD69B), Color(0xFF14201A), Color(0xFF0C1510), Color(0xFF16251C), Color(0xFF22342A), Color(0xFFEAF5EE), Color(0xFF98B1A2), Color(0xFFD3EEDC), Color(0xFF101A14), Color(0x1F9BE0B4)),
        Palette("Prune", false, Color(0xFFD69BFF), Color(0xFF1E1526), Color(0xFF140D1A), Color(0xFF22182C), Color(0xFF33263F), Color(0xFFF4ECFA), Color(0xFFB09DBF), Color(0xFFEADBF6), Color(0xFF1A1221), Color(0x1FE0B4FF)),
        Palette("Or DL Vibe", false, Color(0xFFE8C163), Color(0xFF17140E), Color(0xFF0E0C08), Color(0xFF1F1B12), Color(0xFF2E281B), Color(0xFFFFF7E6), Color(0xFFBDAF8F), Color(0xFFF0DFB0), Color(0xFF15120C), Color(0x24E8C163)),
        Palette("Braise", false, Color(0xFFFF8A65), Color(0xFF1F1513), Color(0xFF140D0B), Color(0xFF261915), Color(0xFF382621), Color(0xFFFFEFEA), Color(0xFFBFA39B), Color(0xFFF6D9CF), Color(0xFF1A110E), Color(0x1FFF8A65)),
        Palette("Clair", true, Color(0xFF1A73E8), Color(0xFFF1F3F7), Color(0xFFFFFFFF), Color(0xFFFFFFFF), Color(0xFFE2E6EE), Color(0xFF1B1D21), Color(0xFF5F6670), Color(0xFFD6DEEA), Color(0xFFFFFFFF), Color(0x14000000)),
        Palette("Sable", true, Color(0xFFB7791F), Color(0xFFF6F0E6), Color(0xFFFFFCF6), Color(0xFFFFFCF6), Color(0xFFEADFCB), Color(0xFF2A2218), Color(0xFF6E6252), Color(0xFFE6D9C2), Color(0xFFFFFCF6), Color(0x14000000)),
    )

    /** Couleurs d'accent proposées (index 0 = celle du thème). */
    val accents = listOf(
        "Thème" to Color.Unspecified,
        "Bleu" to Color(0xFF8AB4F8),
        "Violet" to Color(0xFFC58AF9),
        "Rose" to Color(0xFFFF8BCB),
        "Rouge" to Color(0xFFF28B82),
        "Orange" to Color(0xFFFCAD70),
        "Or" to Color(0xFFE8C163),
        "Vert" to Color(0xFF81C995),
        "Turquoise" to Color(0xFF78D9EC),
    )

    val cornerNames = listOf("Arrondis", "Très ronds", "Carrés")
    val cardNames = listOf("Dégradé", "Plat", "Contour")
    val audioNames = listOf("Vinyle", "Pochette", "Minimal")
    val carouselNames = listOf("Rapide", "Normal", "Lent")
    private val carouselSeconds = listOf(3, 5, 8)
    val seekSteps = listOf(5, 10, 15, 30)

    // ── Apparence
    var themeIndex by mutableIntStateOf(0)
    var accentIndex by mutableIntStateOf(0)
    var corner by mutableIntStateOf(0)
    var cardStyle by mutableIntStateOf(0)
    var denseGrid by mutableStateOf(false)
    // ── Animations
    var animations by mutableStateOf(true)
    var carouselSpeed by mutableIntStateOf(1)
    var videoPreview by mutableStateOf(true)
    // ── Accueil
    var showRecents by mutableStateOf(true)
    var showTools by mutableStateOf(true)
    // ── Fichiers
    var showHidden by mutableStateOf(false)
    var deepScan by mutableStateOf(true)
    var defaultGrid by mutableStateOf(true)
    var confirmDelete by mutableStateOf(true)
    // ── Lecteur
    var resumePlayback by mutableStateOf(true)
    var seekStep by mutableIntStateOf(10)
    var audioStyle by mutableIntStateOf(0)
    var keepScreenOn by mutableStateOf(true)

    val pal: Palette get() = themes[themeIndex.coerceIn(0, themes.lastIndex)]

    val accent: Color
        get() {
            val p = pal
            val c = accents.getOrNull(accentIndex)?.second?.takeIf { it != Color.Unspecified } ?: return p.accent
            // Les accents pastel manquent de contraste sur fond clair : on les fonce
            return if (p.light) lerp(c, Color.Black, 0.38f) else c
        }

    val onAccent: Color
        get() = if (accent.luminance() > 0.45f) lerp(accent, Color.Black, 0.78f) else Color.White

    /** Couleurs de contenu (images, vidéos…) adaptées au thème clair. */
    fun tone(c: Color): Color = if (pal.light) lerp(c, Color.Black, 0.35f) else c

    /** Rayon des coins selon le réglage « Forme des coins ». */
    fun r(d: Dp): Dp = when (corner) {
        1 -> d * 1.4f
        2 -> d * 0.4f
        else -> d
    }

    val carouselMs: Long get() = carouselSeconds.getOrElse(carouselSpeed) { 5 } * 1000L

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("linkshare", Context.MODE_PRIVATE)

    fun load(ctx: Context) {
        val p = prefs(ctx)
        themeIndex = p.getInt("st_theme", 0)
        accentIndex = p.getInt("st_accent", 0)
        corner = p.getInt("st_corner", 0)
        cardStyle = p.getInt("st_card", 0)
        denseGrid = p.getBoolean("st_dense", false)
        animations = p.getBoolean("st_anim", true)
        carouselSpeed = p.getInt("st_carousel", 1)
        videoPreview = p.getBoolean("st_vprev", true)
        showRecents = p.getBoolean("st_recents", true)
        showTools = p.getBoolean("st_tools", true)
        showHidden = p.getBoolean("st_hidden", false)
        deepScan = p.getBoolean("st_deep", true)
        defaultGrid = p.getBoolean("st_grid", true)
        confirmDelete = p.getBoolean("st_confirm", true)
        resumePlayback = p.getBoolean("st_resume", true)
        seekStep = p.getInt("st_seek", 10)
        audioStyle = p.getInt("st_audio", 0)
        keepScreenOn = p.getBoolean("st_screen", true)
    }

    fun save(ctx: Context) {
        prefs(ctx).edit()
            .putInt("st_theme", themeIndex).putInt("st_accent", accentIndex).putInt("st_corner", corner)
            .putInt("st_card", cardStyle).putBoolean("st_dense", denseGrid).putBoolean("st_anim", animations)
            .putInt("st_carousel", carouselSpeed).putBoolean("st_vprev", videoPreview).putBoolean("st_recents", showRecents)
            .putBoolean("st_tools", showTools).putBoolean("st_hidden", showHidden).putBoolean("st_deep", deepScan)
            .putBoolean("st_grid", defaultGrid).putBoolean("st_confirm", confirmDelete).putBoolean("st_resume", resumePlayback)
            .putInt("st_seek", seekStep).putInt("st_audio", audioStyle).putBoolean("st_screen", keepScreenOn)
            .apply()
    }

    /** Modifie un réglage puis l'enregistre. */
    fun edit(ctx: Context, block: UiStyle.() -> Unit) { block(); save(ctx) }

    fun reset(ctx: Context) {
        prefs(ctx).edit().apply { prefs(ctx).all.keys.filter { it.startsWith("st_") }.forEach { remove(it) } }.apply()
        load(ctx)
    }
}
