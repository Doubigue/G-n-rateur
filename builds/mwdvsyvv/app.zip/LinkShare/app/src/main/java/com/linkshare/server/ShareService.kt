package com.linkshare.server

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.text.format.Formatter
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.linkshare.MainActivity
import com.linkshare.R
import com.linkshare.core.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.conflate

/**
 * Service de session, au premier plan tant que le partage est actif :
 * serveur HTTP + voie rapide, point d'accès, verrous Wi-Fi et processeur.
 * Les transferts continuent écran éteint ou appli quittée ; la notification affiche le pourcentage.
 */
/**
 * Serveurs HTTP + voie rapide : démarrés une seule fois par processus et jamais arrêtés.
 * Fini les plantages « port déjà utilisé » quand on arrête puis relance le partage rapidement :
 * hors session, ils refusent simplement toute requête (ShareState.open = false).
 */
object Servers {
    @Volatile private var http: ShareServer? = null
    @Volatile private var fast: FastServer? = null

    @Synchronized
    fun ensure(ctx: Context): Boolean {
        val app = ctx.applicationContext
        if (http == null) http = retry { ShareServer(app).also { it.start() } }
        if (fast == null) fast = retry { FastServer(app).also { it.start() } }
        return http != null && fast != null
    }

    private fun <T> retry(block: () -> T): T? {
        repeat(8) {
            try { return block() } catch (e: Exception) { Thread.sleep(400) }
        }
        return null
    }
}

class ShareService : Service() {
    private var wifiLocks = mutableListOf<WifiManager.WifiLock>()
    private var wakeLock: PowerManager.WakeLock? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val nm by lazy { getSystemService(NotificationManager::class.java) }
    private var token = ""
    private var lastText = ""
    private var started = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Session.init(this)
        nm.createNotificationChannel(
            NotificationChannel(CH, "Partage et transferts", NotificationManager.IMPORTANCE_LOW).apply { setShowBadge(false) }
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Toujours appeler startForeground en premier (obligatoire après startForegroundService).
        // Android 12+ peut le refuser (appli en arrière-plan, quota Android 15) : on s'arrête sans planter.
        try {
            ServiceCompat.startForeground(this, ID, build("LinkShare", "Préparation…", -1), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } catch (e: Exception) {
            stopSelf(); return START_NOT_STICKY
        }
        try {
            when (intent?.action) {
                ACTION_STOP -> { Session.disconnect(); stopSelf(); return START_NOT_STICKY }
                ACTION_CANCEL -> TransferHub.cancelAll()
                ACTION_HOTSPOT -> Hotspot.start(this)
                ACTION_HOTSPOT_OFF -> Hotspot.stop()
            }
        } catch (e: Exception) {
            Hotspot.error.value = e.message ?: "Point d'accès impossible"
        }
        if (!started) { started = true; begin() }
        return START_NOT_STICKY
    }

    private fun publish(hs: Hotspot.State?) {
        if (!ShareState.open) return
        val name = Build.MODEL ?: "Téléphone"
        ShareState.info.value = if (hs == null) ShareInfo(NetUtil.localIp(), PORT, token, name, FAST_PORT)
        else ShareInfo(hs.host, PORT, token, name, FAST_PORT, hs.ssid, hs.pass, hs.wpa3, hs.band, hs.kind == Hotspot.KIND_P2P, hs.freq)
    }

    private fun begin() {
        token = ShareState.newToken()
        ShareState.token = token

        // Démarrage des serveurs hors du fil principal (pas de gel de l'écran)
        scope.launch {
            val ok = withContext(Dispatchers.IO) { Servers.ensure(applicationContext) }
            if (!ok) {
                Session.events.tryEmit("Impossible de démarrer le partage : redémarre l'appli")
                stopSelf(); return@launch
            }
            ShareState.open = true
            // Le QR suit le point d'accès : nom, mot de passe et adresse de l'interface du point d'accès
            Hotspot.state.collect { publish(it) }
        }

        // Wi-Fi pleine puissance + faible latence : pas de mise en veille de la radio pendant la session
        runCatching {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            @Suppress("DEPRECATION")
            listOf(WifiManager.WIFI_MODE_FULL_HIGH_PERF, WifiManager.WIFI_MODE_FULL_LOW_LATENCY).forEach { mode ->
                runCatching { wm.createWifiLock(mode, "linkshare:$mode").apply { setReferenceCounted(false); acquire() } }
                    .getOrNull()?.let { wifiLocks += it }
            }
        }
        // Processeur éveillé pendant toute la session : l'autre téléphone peut parcourir et télécharger écran éteint
        runCatching {
            wakeLock = getSystemService(PowerManager::class.java)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "linkshare:session")
                .apply { setReferenceCounted(false); acquire(65 * 60_000L) }
        }
        scope.launch {
            while (isActive) {
                delay(60 * 60_000L)
                runCatching { wakeLock?.acquire(65 * 60_000L) }
            }
        }
        scope.launch { tick() }
    }

    override fun onDestroy() {
        scope.cancel()
        ShareState.open = false
        ShareState.token = ""
        runCatching { Hotspot.stop() }
        wifiLocks.forEach { runCatching { if (it.isHeld) it.release() } }
        wifiLocks.clear()
        runCatching { wakeLock?.takeIf { it.isHeld }?.release() }
        ShareState.info.value = null
        ShareState.active.value = 0
        super.onDestroy()
    }

    // Android 14/15 coupe les services dataSync après 6 h : on s'arrête proprement et on prévient l'utilisateur
    override fun onTimeout(startId: Int) = handleTimeout()
    override fun onTimeout(startId: Int, fgsType: Int) = handleTimeout()

    private fun handleTimeout() {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        nm.notify(
            ID_INFO,
            NotificationCompat.Builder(this, CH)
                .setSmallIcon(R.drawable.ic_stat_share)
                .setContentTitle("Partage arrêté")
                .setContentText("Android limite les partages à 6 h. Rouvre l'app pour relancer.")
                .setContentIntent(open)
                .setAutoCancel(true)
                .build()
        )
        Session.disconnect()
        stopSelf()
    }

    private fun size(b: Long) = Formatter.formatShortFileSize(this, b)

    /** Notification mise à jour chaque seconde : pourcentage d'envoi et de réception, débit. */
    private suspend fun tick() {
        combine(TransferHub.up, TransferHub.down, Hotspot.state, ShareState.info) { u, d, hs, info -> Quad(u, d, hs, info) }
            .conflate()
            .collect { (u, d, hs, info) ->
                val peer = Session.client?.let { Session.peerName }
                val (title, text, pct) = when {
                    u.running > 0 && d.running > 0 -> Triple(
                        "↑ ${u.percent} %   ↓ ${d.percent} %",
                        "Envoi ${size(u.speed)}/s · Réception ${size(d.speed)}/s",
                        (((u.done + d.done) * 100) / (u.total + d.total).coerceAtLeast(1)).toInt(),
                    )
                    u.running > 0 -> Triple(
                        "Envoi ${u.percent} % · ${u.running} élément(s)",
                        "${size(u.done)} / ${size(u.total)} · ${size(u.speed)}/s" + (peer?.let { " → $it" } ?: ""), u.percent,
                    )
                    d.running > 0 -> Triple(
                        "Réception ${d.percent} % · ${d.running} élément(s)",
                        "${size(d.done)} / ${size(d.total)} · ${size(d.speed)}/s" + (peer?.let { " ← $it" } ?: ""), d.percent,
                    )
                    peer != null -> Triple("Connecté à $peer", "Prêt à envoyer et recevoir", -1)
                    hs != null -> Triple("Point d'accès actif (${hs.band})", "En attente de l'autre téléphone…", -1)
                    else -> Triple("Partage actif", info?.let { "${it.host}:${it.port}" } ?: "", -1)
                }
                val key = "$title|$text|$pct"
                if (key != lastText) {
                    lastText = key
                    runCatching { nm.notify(ID, build(title, text, pct)) }
                    delay(1000) // une mise à jour par seconde au plus
                }
            }
    }

    private data class Quad<A, B, C, D>(val a: A, val b: B, val c: C, val d: D)

    private fun build(title: String, text: String, percent: Int): Notification {
        val stop = PendingIntent.getService(this, 0, Intent(this, ShareService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val cancel = PendingIntent.getService(this, 1, Intent(this, ShareService::class.java).setAction(ACTION_CANCEL), PendingIntent.FLAG_IMMUTABLE)
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat_share)
            .setColor(0xFF1E6FEB.toInt())
            .setContentTitle(title)
            .setContentText(text)
            .apply { if (percent >= 0) setProgress(100, percent, false).addAction(0, "Annuler les transferts", cancel) }
            .setContentIntent(open)
            .addAction(0, "Se déconnecter", stop)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setCategory(if (percent >= 0) NotificationCompat.CATEGORY_PROGRESS else NotificationCompat.CATEGORY_SERVICE)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    companion object {
        const val CH = "session"
        const val ID = 1
        const val ID_INFO = 3
        const val ACTION_STOP = "com.linkshare.STOP"
        const val ACTION_CANCEL = "com.linkshare.CANCEL_TRANSFER"
        const val ACTION_HOTSPOT = "com.linkshare.HOTSPOT_ON"
        const val ACTION_HOTSPOT_OFF = "com.linkshare.HOTSPOT_OFF"
    }
}
