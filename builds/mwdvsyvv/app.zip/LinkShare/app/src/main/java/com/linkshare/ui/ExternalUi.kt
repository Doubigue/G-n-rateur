package com.linkshare.ui

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.compose.ui.text.style.TextAlign
import com.linkshare.MainActivity
import kotlinx.coroutines.launch
import java.util.zip.ZipInputStream
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.selection.SelectionContainer
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

/** Demandes d'ouverture venant d'autres applications (renseignées par MainActivity). */
object ExternalOpen {
    var uri by mutableStateOf<Uri?>(null)
    var mime by mutableStateOf<String?>(null)
    var folder by mutableStateOf<File?>(null)
    /** Vrai quand le lien a été ouvert depuis l'explorateur lui-même (fermer le lecteur ne quitte alors pas l'appli). */
    var inApp by mutableStateOf(false)

    fun isWeb(u: Uri) = u.scheme.equals("http", true) || u.scheme.equals("https", true)

    /** Type d'un fichier web d'après l'extension du lien (sans la requête « ?… »), ou null. */
    fun guessMime(u: Uri): String? {
        val ext = (u.lastPathSegment ?: "").substringAfterLast('.', "").lowercase()
        if (ext.isEmpty()) return null
        return when (ext) {
            "m3u8" -> "application/x-mpegURL"
            "mpd" -> "application/dash+xml"
            "mkv" -> "video/x-matroska"
            "opus" -> "audio/ogg"
            "log", "srt", "md", "csv" -> "text/plain"
            "html", "htm" -> "text/html"
            "xhtml" -> "application/xhtml+xml"
            "svg" -> "image/svg+xml"
            else -> MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
        }
    }

    private fun connect(u: Uri, method: String): HttpURLConnection =
        (URL(u.toString()).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 15_000; readTimeout = 20_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "LinkShare")
        }

    /** Type annoncé par le serveur (requête HEAD) quand l'extension ne permet pas de deviner ; null si inconnu. */
    fun probeMime(u: Uri): String? = try {
        val c = connect(u, "HEAD")
        try { c.contentType?.substringBefore(';')?.trim()?.lowercase()?.takeIf { it.isNotEmpty() } } finally { c.disconnect() }
    } catch (e: Exception) { null }

    /** Flux du contenu : réseau pour un lien http(s), sinon le fournisseur de contenu. À appeler hors du thread principal. */
    fun openStream(ctx: Context, u: Uri): InputStream? {
        if (!isWeb(u)) return ctx.contentResolver.openInputStream(u)
        val c = connect(u, "GET")
        val code = c.responseCode
        if (code !in 200..299) { c.disconnect(); error("Le serveur a répondu $code") }
        return c.inputStream
    }

    /** content://…externalstorage.documents/… ou file:// → dossier réel, si on sait le retrouver. */
    fun resolveFolder(u: Uri): File? {
        if (u.scheme == "file") return u.path?.let { File(it) }?.takeIf { it.isDirectory }
        // Racine d'un volume (Réglages › Stockage › Parcourir) : content://…externalstorage.documents/root/<volume>
        val seg = u.pathSegments
        if (u.authority == "com.android.externalstorage.documents" && seg.size >= 2 && seg[0] == "root") {
            val root = if (seg[1] == "primary") Environment.getExternalStorageDirectory() else File("/storage/${seg[1]}")
            return root.takeIf { it.isDirectory }
        }
        val id = runCatching { DocumentsContract.getDocumentId(u) }.getOrNull()
            ?: runCatching { DocumentsContract.getTreeDocumentId(u) }.getOrNull() ?: return null
        val vol = id.substringBefore(':')
        val rel = id.substringAfter(':', "")
        val f = if (vol == "primary") File(Environment.getExternalStorageDirectory(), rel) else File("/storage/$vol/$rel")
        return f.takeIf { it.isDirectory }
    }
}

private fun displayName(ctx: Context, u: Uri): String =
    runCatching {
        ctx.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    }.getOrNull() ?: u.lastPathSegment ?: "Fichier"

/** Lecteur plein écran pour un fichier ouvert depuis une autre appli ou un lien web (retour = on revient d'où l'on vient). */
@Composable
fun ExternalViewerScreen() {
    val ctx = LocalContext.current
    val uri = ExternalOpen.uri ?: return
    val web = ExternalOpen.isWeb(uri)
    val given = ExternalOpen.mime?.takeIf { it.isNotBlank() && !(web && it == "application/octet-stream") }
    // Lien web : type d'après le serveur à défaut de l'extension ; null = en cours de vérification
    val mimeNow by produceState<String?>(
        if (web) given ?: ExternalOpen.guessMime(uri) else given ?: ctx.contentResolver.getType(uri) ?: "", uri,
    ) {
        if (value == null) value = withContext(Dispatchers.IO) { ExternalOpen.probeMime(uri) } ?: ""
    }
    val loading = mimeNow == null
    val mime = mimeNow ?: ""
    val name = remember(uri) { displayName(ctx, uri) }
    fun close() {
        PlayerHost.stop()
        val inApp = ExternalOpen.inApp
        ExternalOpen.uri = null; ExternalOpen.mime = null; ExternalOpen.inApp = false
        if (!inApp) ctx.findActivity()?.finish()
    }
    BackHandler { close() }
    if (!loading && isWebPageMime(mime)) {
        // Page web (lien https, fichier .html reçu d'une autre appli) : rendue comme dans un navigateur
        WebPage(uri.toString(), name, onClose = { close() })
        return
    }
    val streamable = mime.startsWith("video/") || mime.startsWith("audio/") || mime == "application/ogg" ||
        mime.contains("mpegurl", true) || mime == "application/dash+xml"
    if (!loading && streamable) {
        // Vidéo / audio (y compris en streaming https, HLS et DASH) : lecteur plein écran avec ses commandes
        Player(uri.toString(), name, onClose = { close() })
        return
    }
    Column(Modifier.fillMaxSize().background(LS.Bg).systemBarsPadding()) {
        Row(Modifier.padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ close() }) { Icon(Ic.Back, "Retour", tint = LS.Blue) }
            Text(name, color = LS.Blue, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        when {
            loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = LS.Blue) }
            mime.startsWith("image/") -> AsyncImage(uri, name, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            mime.startsWith("text/") || mime == "application/json" || mime == "application/xml" -> ExternalText(uri)
            else -> UnsupportedFile(uri, mime, name)
        }
    }
}

@Composable
private fun ExternalText(uri: Uri) {
    val ctx = LocalContext.current
    val text by produceState("Chargement…", uri) {
        value = withContext(Dispatchers.IO) {
            try {
                ExternalOpen.openStream(ctx, uri)?.bufferedReader()?.use { r ->
                    val buf = CharArray(300_000)
                    val n = r.read(buf)
                    if (n > 0) String(buf, 0, n) else ""
                } ?: "Lecture impossible"
            } catch (e: Exception) { "Lecture impossible : ${e.message}" }
        }
    }
    SelectionContainer {
        Text(
            text, Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            color = LS.Text, fontSize = 12.sp, fontFamily = FontFamily.Monospace,
        )
    }
}

// ═══════════════════════════ Documents et archives ═══════════════════════════

private val ZIP_MIMES = setOf("application/zip", "application/x-zip-compressed")

private fun safeFileName(n: String) = n.replace('/', '_').trim().ifEmpty { "fichier" }

private fun uniqueFile(f: File): File {
    if (!f.exists()) return f
    val ext = f.extension.let { if (it.isEmpty()) "" else ".$it" }
    return generateSequence(1) { it + 1 }.map { File(f.parentFile, "${f.nameWithoutExtension} ($it)$ext") }.first { !it.exists() }
}

private fun downloadFolder(): File =
    File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "LinkShare").apply { mkdirs() }

/** Copie le fichier reçu dans le cache : une appli tierce ne peut pas relire l'autorisation temporaire reçue. */
private fun copyToCache(ctx: Context, uri: Uri, name: String): File {
    val dir = File(ctx.cacheDir, "external").apply { deleteRecursively(); mkdirs() }
    val out = File(dir, safeFileName(name))
    val input = ExternalOpen.openStream(ctx, uri) ?: error("Fichier illisible")
    input.use { i -> out.outputStream().use { i.copyTo(it, 64 * 1024) } }
    return out
}

private fun mimeFor(mime: String, f: File) =
    mime.ifEmpty { MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*" }

/** Décompression protégée contre les chemins « ../ » (zip-slip). Renvoie le nombre de fichiers extraits. */
private fun extractZip(ctx: Context, uri: Uri, target: File): Int {
    target.mkdirs()
    val base = target.canonicalPath + File.separator
    var n = 0
    val input = ExternalOpen.openStream(ctx, uri) ?: error("Archive illisible")
    ZipInputStream(input.buffered()).use { zin ->
        var e = zin.nextEntry
        while (e != null) {
            val out = File(target, e.name).canonicalFile
            if (out.path.startsWith(base)) {
                if (e.isDirectory) out.mkdirs()
                else { out.parentFile?.mkdirs(); out.outputStream().use { zin.copyTo(it, 64 * 1024) }; n++ }
            }
            zin.closeEntry()
            e = zin.nextEntry
        }
    }
    MediaScannerConnection.scanFile(ctx, arrayOf(target.path), null, null)
    return n
}

/** Formats que LinkShare ne sait pas afficher (PDF, Office, archives…) : on propose des actions plutôt qu'une impasse. */
@Composable
private fun UnsupportedFile(uri: Uri, mime: String, name: String) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf<String?>(null) }
    val isZip = mime in ZIP_MIMES || name.lowercase().endsWith(".zip")

    fun job(label: String, block: suspend () -> String?) {
        if (busy != null) return
        scope.launch {
            busy = label
            val msg = try { block() } catch (e: Exception) { e.message ?: e.toString() }
            busy = null
            msg?.let { Toast.makeText(ctx, it, Toast.LENGTH_LONG).show() }
        }
    }

    fun openElsewhere() = job("Préparation…") {
        val f = withContext(Dispatchers.IO) { copyToCache(ctx, uri, name) }
        val shared = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
        val view = Intent(Intent.ACTION_VIEW).setDataAndType(shared, mimeFor(mime, f)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        // LinkShare est exclue de la liste, sinon on reviendrait ici
        val chooser = Intent.createChooser(view, "Ouvrir avec")
            .putExtra(Intent.EXTRA_EXCLUDE_COMPONENTS, arrayOf(ComponentName(ctx, MainActivity::class.java)))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { ctx.startActivity(chooser); null } catch (e: Exception) { "Aucune application pour ouvrir ce fichier" }
    }

    fun save() = job("Enregistrement…") {
        val out = withContext(Dispatchers.IO) {
            val dest = uniqueFile(File(downloadFolder(), safeFileName(name)))
            val input = ExternalOpen.openStream(ctx, uri) ?: error("Fichier illisible")
            input.use { i -> dest.outputStream().use { i.copyTo(it, 64 * 1024) } }
            MediaScannerConnection.scanFile(ctx, arrayOf(dest.path), null, null)
            dest
        }
        "Enregistré dans Download/LinkShare/${out.name}"
    }

    fun extract() = job("Décompression…") {
        val (dir, n) = withContext(Dispatchers.IO) {
            val d = uniqueFile(File(downloadFolder(), safeFileName(name).substringBeforeLast('.')))
            d to extractZip(ctx, uri, d)
        }
        "$n fichier(s) décompressé(s) dans Download/LinkShare/${dir.name}"
    }

    fun share() = job("Préparation…") {
        val f = withContext(Dispatchers.IO) { copyToCache(ctx, uri, name) }
        val shared = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
        val send = Intent(Intent.ACTION_SEND).setType(mimeFor(mime, f)).putExtra(Intent.EXTRA_STREAM, shared)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(send, "Partager").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        null
    }

    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically),
    ) {
        Icon(if (isZip) Ic.Archive else Ic.Doc, null, Modifier.size(72.dp), tint = LS.Blue)
        Text(name, color = LS.Text, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
        Text("LinkShare ne peut pas afficher ce format.", color = LS.Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
        busy?.let { b ->
            Text(b, color = LS.Text, fontSize = 12.sp)
            LinearProgressIndicator(Modifier.fillMaxWidth(), color = LS.Blue)
        }
        Spacer(Modifier.height(4.dp))
        Button({ openElsewhere() }, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = LS.Blue, contentColor = LS.OnBlue)) {
            Text("Ouvrir avec une autre appli")
        }
        if (isZip) Button({ extract() }, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = LS.Card, contentColor = LS.Text)) {
            Text("Décompresser dans Téléchargements")
        }
        Button({ save() }, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = LS.Card, contentColor = LS.Text)) {
            Text("Enregistrer dans Téléchargements")
        }
        Button({ share() }, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = LS.Card, contentColor = LS.Text)) {
            Text("Partager")
        }
    }
}
