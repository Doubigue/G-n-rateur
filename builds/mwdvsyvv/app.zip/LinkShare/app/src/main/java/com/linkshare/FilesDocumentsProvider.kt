package com.linkshare

import android.content.res.AssetFileDescriptor
import android.database.Cursor
import android.database.MatrixCursor
import android.graphics.Bitmap
import android.graphics.Point
import android.media.MediaScannerConnection
import android.media.ThumbnailUtils
import android.os.CancellationSignal
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.DocumentsContract.Document
import android.provider.DocumentsContract.Root
import android.provider.DocumentsProvider
import android.util.Size
import android.webkit.MimeTypeMap
import java.io.File
import java.io.FileNotFoundException

/**
 * Expose le stockage interne dans le sélecteur de fichiers d'Android : toute appli qui demande un fichier
 * (« Joindre », « Importer », « Enregistrer sous »…) propose « LinkShare » parmi les emplacements.
 * L'identifiant d'un document est son chemin ; l'accès reste soumis à « Accès à tous les fichiers ».
 */
class FilesDocumentsProvider : DocumentsProvider() {
    private val rootDir: File get() = Environment.getExternalStorageDirectory()

    private companion object {
        const val ROOT_ID = "linkshare"
        val ROOT_COLUMNS = arrayOf(
            Root.COLUMN_ROOT_ID, Root.COLUMN_FLAGS, Root.COLUMN_ICON, Root.COLUMN_TITLE, Root.COLUMN_SUMMARY,
            Root.COLUMN_DOCUMENT_ID, Root.COLUMN_AVAILABLE_BYTES, Root.COLUMN_MIME_TYPES,
        )
        val DOC_COLUMNS = arrayOf(
            Document.COLUMN_DOCUMENT_ID, Document.COLUMN_DISPLAY_NAME, Document.COLUMN_SIZE,
            Document.COLUMN_MIME_TYPE, Document.COLUMN_LAST_MODIFIED, Document.COLUMN_FLAGS,
        )
    }

    override fun onCreate() = true

    // ── Outils

    /** Fichier désigné par [id], refusé s'il sort du stockage (../, liens symboliques). */
    private fun fileFor(id: String): File {
        val f = File(id)
        if (!inRoot(f)) throw FileNotFoundException("Hors du stockage : $id")
        if (!f.exists()) throw FileNotFoundException("Introuvable : $id")
        return f
    }

    private fun inRoot(f: File): Boolean {
        val root = rootDir.canonicalFile
        val c = f.canonicalFile
        return c == root || c.path.startsWith(root.path + File.separator)
    }

    private fun mimeOf(f: File): String {
        if (f.isDirectory) return Document.MIME_TYPE_DIR
        val ext = f.extension.lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    private fun hidden(f: File) = f.name.startsWith(".")

    private fun safeName(n: String) = n.replace('/', '_').replace('\u0000', '_').trim().ifEmpty { "Sans nom" }

    private fun unique(f: File): File {
        if (!f.exists()) return f
        val ext = f.extension.let { if (it.isEmpty()) "" else ".$it" }
        return generateSequence(1) { it + 1 }.map { File(f.parentFile, "${f.nameWithoutExtension} ($it)$ext") }.first { !it.exists() }
    }

    private fun include(c: MatrixCursor, f: File) {
        val isRoot = f.path == rootDir.path
        var flags = 0
        if (f.isDirectory) { if (f.canWrite()) flags = flags or Document.FLAG_DIR_SUPPORTS_CREATE }
        else if (f.canWrite()) flags = flags or Document.FLAG_SUPPORTS_WRITE
        if (!isRoot && f.parentFile?.canWrite() == true) flags = flags or Document.FLAG_SUPPORTS_DELETE or Document.FLAG_SUPPORTS_RENAME
        val mime = mimeOf(f)
        if (mime.startsWith("image/") || mime.startsWith("video/")) flags = flags or Document.FLAG_SUPPORTS_THUMBNAIL
        c.newRow()
            .add(Document.COLUMN_DOCUMENT_ID, f.path)
            .add(Document.COLUMN_DISPLAY_NAME, if (isRoot) "Stockage interne" else f.name)
            .add(Document.COLUMN_SIZE, if (f.isDirectory) 0L else f.length())
            .add(Document.COLUMN_MIME_TYPE, mime)
            .add(Document.COLUMN_LAST_MODIFIED, f.lastModified())
            .add(Document.COLUMN_FLAGS, flags)
    }

    // ── Racines et listes

    override fun queryRoots(projection: Array<out String>?): Cursor {
        val c = MatrixCursor(projection ?: ROOT_COLUMNS)
        // Sans « Accès à tous les fichiers », on ne propose pas l'emplacement
        if (!Environment.isExternalStorageManager()) return c
        c.newRow()
            .add(Root.COLUMN_ROOT_ID, ROOT_ID)
            .add(Root.COLUMN_FLAGS, Root.FLAG_SUPPORTS_CREATE or Root.FLAG_SUPPORTS_SEARCH or Root.FLAG_SUPPORTS_IS_CHILD or Root.FLAG_LOCAL_ONLY)
            .add(Root.COLUMN_ICON, R.drawable.ic_logo)
            .add(Root.COLUMN_TITLE, "LinkShare")
            .add(Root.COLUMN_SUMMARY, "Stockage interne")
            .add(Root.COLUMN_DOCUMENT_ID, rootDir.path)
            .add(Root.COLUMN_AVAILABLE_BYTES, rootDir.freeSpace)
            .add(Root.COLUMN_MIME_TYPES, "*/*")
        return c
    }

    override fun queryDocument(documentId: String, projection: Array<out String>?): Cursor =
        MatrixCursor(projection ?: DOC_COLUMNS).also { include(it, fileFor(documentId)) }

    override fun queryChildDocuments(parentDocumentId: String, projection: Array<out String>?, sortOrder: String?): Cursor {
        val c = MatrixCursor(projection ?: DOC_COLUMNS)
        val parent = fileFor(parentDocumentId)
        parent.listFiles()?.filter { !hidden(it) }?.forEach { include(c, it) }
        return c
    }

    override fun querySearchDocuments(rootId: String, query: String, projection: Array<out String>?): Cursor {
        val c = MatrixCursor(projection ?: DOC_COLUMNS)
        val queue = ArrayList<File>().apply { add(rootDir) }
        var i = 0; var found = 0
        while (i < queue.size && found < 50) {
            val kids = queue[i++].listFiles() ?: continue
            for (k in kids) {
                if (hidden(k)) continue
                if (k.name.contains(query, ignoreCase = true) && found < 50) { include(c, k); found++ }
                if (k.isDirectory) queue.add(k)
            }
        }
        return c
    }

    override fun isChildDocument(parentDocumentId: String, documentId: String): Boolean {
        val p = File(parentDocumentId).canonicalFile
        val d = File(documentId).canonicalFile
        return d.path.startsWith(p.path + File.separator)
    }

    override fun getDocumentType(documentId: String): String = mimeOf(fileFor(documentId))

    // ── Lecture, écriture, miniatures

    override fun openDocument(documentId: String, mode: String, signal: CancellationSignal?): ParcelFileDescriptor {
        val f = fileFor(documentId)
        val m = ParcelFileDescriptor.parseMode(mode)
        if (!mode.contains('w')) return ParcelFileDescriptor.open(f, m)
        // Écriture : on signale le fichier à Android à la fermeture pour qu'il apparaisse dans Images, Vidéos, Documents…
        return ParcelFileDescriptor.open(f, m, Handler(Looper.getMainLooper())) {
            context?.let { MediaScannerConnection.scanFile(it, arrayOf(f.path), null, null) }
        }
    }

    override fun openDocumentThumbnail(documentId: String, sizeHint: Point, signal: CancellationSignal?): AssetFileDescriptor {
        val f = fileFor(documentId)
        val size = Size(sizeHint.x.coerceAtLeast(32), sizeHint.y.coerceAtLeast(32))
        val bmp: Bitmap = try {
            if (mimeOf(f).startsWith("video/")) ThumbnailUtils.createVideoThumbnail(f, size, signal)
            else ThumbnailUtils.createImageThumbnail(f, size, signal)
        } catch (e: Exception) { throw FileNotFoundException("Pas de miniature") }
        val dir = File(context!!.cacheDir, "docthumbs").apply { mkdirs() }
        val tmp = File.createTempFile("t", ".jpg", dir)
        tmp.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
        val pfd = ParcelFileDescriptor.open(tmp, ParcelFileDescriptor.MODE_READ_ONLY)
        tmp.delete() // le descripteur reste lisible une fois le fichier supprimé
        return AssetFileDescriptor(pfd, 0, AssetFileDescriptor.UNKNOWN_LENGTH)
    }

    // ── Création, suppression, renommage

    override fun createDocument(parentDocumentId: String, mimeType: String, displayName: String): String {
        val parent = fileFor(parentDocumentId)
        if (!parent.isDirectory) throw FileNotFoundException("Ce n'est pas un dossier")
        val target = unique(File(parent, safeName(displayName)))
        val ok = if (mimeType == Document.MIME_TYPE_DIR) target.mkdirs() else target.createNewFile()
        if (!ok) throw FileNotFoundException("Création impossible")
        return target.path
    }

    override fun deleteDocument(documentId: String) {
        val f = fileFor(documentId)
        if (f.path == rootDir.path || !f.deleteRecursively()) throw FileNotFoundException("Suppression impossible")
        context?.let { MediaScannerConnection.scanFile(it, arrayOf(f.path), null, null) }
    }

    override fun renameDocument(documentId: String, displayName: String): String? {
        val f = fileFor(documentId)
        val target = File(f.parentFile, safeName(displayName))
        if (target.path == f.path) return null
        if (target.exists() || !f.renameTo(target)) throw FileNotFoundException("Renommage impossible")
        context?.let { MediaScannerConnection.scanFile(it, arrayOf(f.path, target.path), null, null) }
        return target.path
    }
}
