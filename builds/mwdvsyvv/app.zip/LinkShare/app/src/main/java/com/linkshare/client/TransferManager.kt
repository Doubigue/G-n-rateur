package com.linkshare.client

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.linkshare.core.TransferHub
import com.linkshare.server.ShareService
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update

/**
 * Exécute les transferts dans un scope indépendant de l'écran, protégé par le service de session au premier plan :
 * les envois/téléchargements continuent même si l'app passe en arrière-plan ou si l'écran s'éteint.
 */
object TransferManager {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    val active = MutableStateFlow(0)
    val label = MutableStateFlow("")

    data class Result(val ok: Boolean, val text: String)
    private val results = java.util.concurrent.ConcurrentLinkedQueue<Result>()

    /** Vrai quand l'écran de l'app est visible (pas besoin de notification de fin dans ce cas). */
    @Volatile var appVisible = false

    fun report(ok: Boolean, text: String) { results.add(Result(ok, text)) }

    fun launch(ctx: Context, onError: (Throwable) -> Unit, block: suspend () -> Unit): Job {
        val app = ctx.applicationContext
        active.update { it + 1 }
        runCatching { ContextCompat.startForegroundService(app, Intent(app, ShareService::class.java)) }
        return scope.launch {
            try { block() }
            catch (e: CancellationException) { report(false, "Transfert annulé"); throw e }
            catch (e: Exception) { report(false, e.message ?: e.toString()); onError(e) }
            finally {
                active.update { it - 1 }
                if (active.value == 0) {
                    label.value = ""
                    val batch = generateSequence { results.poll() }.toList()
                    if (!appVisible) TransferNotifier.post(app, batch)
                }
            }
        }
    }

    fun cancelAll() {
        TransferHub.cancelAll()
        scope.coroutineContext[Job]?.children?.forEach { it.cancel() }
    }
}
