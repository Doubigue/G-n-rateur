# LinkShare

Partage rapide Android (Kotlin / Compose / Ktor) avec accès distant aux fichiers et applications.

## Lancer
1. Ouvrir le dossier dans Android Studio (Ladybug ou plus récent, JDK 17) et laisser Gradle synchroniser.
2. Installer sur deux téléphones (Android 11+).
3. Téléphone A : « Partager mon téléphone » (autoriser l'accès à tous les fichiers) → un QR s'affiche.
4. Téléphone B : « Scanner un QR » → parcourir fichiers et apps, lire vidéos / audio / images en streaming,
   télécharger fichiers ou dossiers, envoyer fichiers ou dossiers (ils arrivent dans Download/LinkShare).

## Interface
Style « Data Transfer With Ease » : accueil (stockage réel, catégories, Partager / Recevoir / Lien, transferts récents),
barre bleue Accueil · Stockage · Partage · Profil, écran de partage avec QR + radar, et liste distante groupée
avec cases à cocher (téléchargement groupé), filtre par catégorie, recherche et bascule Récents / Dossiers / Apps.

## Stockage (explorateur local)
Tableau de bord (récents, catégories, coffre-fort, scanner) + explorateur : dossiers en grille par défaut (bascule liste),
recherche récursive, tri (nom/date/taille/type, croissant/décroissant), lecture intégrée (images, vidéos, audio, texte),
ouverture externe des autres documents (PDF, Office…), compression/décompression ZIP, scan de documents en PDF
(ML Kit), coffre-fort dans l'espace privé de l'appli ouvert via le verrouillage du téléphone.

## Réseau
Même Wi-Fi, ou B connecté au point d'accès de A (le plus rapide, sans routeur).

## À faire ensuite
- TLS (certificat auto-signé épinglé dans le QR) : actuellement HTTP + jeton aléatoire de 192 bits.
- Wi-Fi Direct (WifiP2pManager) pour une connexion sans routeur ni hotspot manuel.
- Choix des dossiers partagés + écran de consentement / révocation.
- Visionneuse texte/PDF, reprise des transferts, installation directe des APK.
