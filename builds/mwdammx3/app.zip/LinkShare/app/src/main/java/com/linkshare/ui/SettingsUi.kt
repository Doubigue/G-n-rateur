package com.linkshare.ui

import android.text.format.Formatter
import android.widget.Toast
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.border
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.DateFormat
import java.util.Date

// ═══════════════════════════ Paramètres de l'explorateur ═══════════════════════════

@Composable
internal fun SettingsScreen(ex: ExplorerViewModel, onBack: () -> Unit, onTrash: () -> Unit) {
    val ctx = LocalContext.current
    val act = ctx.findActivity()
    var mode by remember { mutableStateOf(VaultAuth.mode(ctx)) }
    var fingerprint by remember { mutableStateOf(VaultAuth.fingerprint(ctx)) }
    var options by remember { mutableStateOf(false) }
    var setup by remember { mutableStateOf<VaultMode?>(null) }

    fun applyMode(m: VaultMode, secret: String?) {
        VaultAuth.set(ctx, m, secret)
        mode = m; fingerprint = VaultAuth.fingerprint(ctx)
        setup = null; options = false
        Toast.makeText(ctx, "Verrouillage du coffre : ${m.label.lowercase()}", Toast.LENGTH_SHORT).show()
    }

    LaunchedEffect(Unit) { ex.loadTrash() }
    val scope = rememberCoroutineScope()
    var cacheSize by remember { mutableStateOf<Long?>(null) }
    var cacheTick by remember { mutableIntStateOf(0) }
    LaunchedEffect(cacheTick) { cacheSize = withContext(Dispatchers.IO) { runCatching { ex.appCacheSize() }.getOrNull() } }
    var confirmReset by remember { mutableStateOf(false) }
    fun set(block: UiStyle.() -> Unit) = UiStyle.edit(ctx, block)
    val version = remember {
        runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "?"
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Ic.Back, "Retour", tint = LS.Text) }
            Text("Paramètres", color = LS.Text, fontSize = 20.sp, fontWeight = FontWeight.Medium)
        }
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            // ── Apparence
            item { SettingsHeading("Apparence") }
            item {
                SettingsBlock(Ic.PaletteIcon, "Thème", UiStyle.pal.name) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 4.dp)) {
                        itemsIndexed(UiStyle.themes) { i, p -> ThemeSwatch(p, UiStyle.themeIndex == i) { set { themeIndex = i } } }
                    }
                }
            }
            item {
                SettingsBlock(Ic.Brightness, "Couleur d'accent", UiStyle.accents[UiStyle.accentIndex.coerceIn(0, UiStyle.accents.lastIndex)].first) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 4.dp)) {
                        itemsIndexed(UiStyle.accents) { i, (name, c) ->
                            AccentDot(if (c == Color.Unspecified) UiStyle.pal.accent else c, name, UiStyle.accentIndex == i) { set { accentIndex = i } }
                        }
                    }
                }
            }
            item {
                SettingsBlock(Ic.GridView, "Forme des coins", null) {
                    Segmented(UiStyle.cornerNames, UiStyle.corner) { set { corner = it } }
                }
            }
            item {
                SettingsBlock(Ic.Storage, "Style des cartes", null) {
                    Segmented(UiStyle.cardNames, UiStyle.cardStyle) { set { cardStyle = it } }
                }
            }
            item { SettingsSwitch(Ic.Apps, "Grille compacte", "4 fichiers par ligne au lieu de 3", UiStyle.denseGrid) { set { denseGrid = it } } }

            // ── Animations
            item { SettingsHeading("Animations") }
            item { SettingsSwitch(Ic.Animation, "Animations", "Carrousels, diaporamas, effets de zoom", UiStyle.animations) { set { animations = it } } }
            item {
                SettingsBlock(Ic.Clock, "Vitesse des diaporamas", "Récents, Images et Vidéos de l'accueil") {
                    Segmented(UiStyle.carouselNames, UiStyle.carouselSpeed, enabled = UiStyle.animations) { set { carouselSpeed = it } }
                }
            }
            item { SettingsSwitch(Ic.Video, "Aperçus vidéo animés", "Les miniatures des vidéos défilent toutes seules", UiStyle.videoPreview, enabled = UiStyle.animations) { set { videoPreview = it } } }

            // ── Accueil
            item { SettingsHeading("Accueil") }
            item { SettingsSwitch(Ic.Clock, "Fichiers récents", "Afficher le carrousel des récents", UiStyle.showRecents) { set { showRecents = it } } }
            item { SettingsSwitch(Ic.Broom, "Outils", "Archives, grands fichiers, doublons, nettoyeur", UiStyle.showTools) { set { showTools = it } } }

            // ── Fichiers
            item { SettingsHeading("Fichiers") }
            item {
                SettingsSwitch(Ic.Search, "Analyse approfondie", "Trouve aussi les photos, vidéos et musiques non indexées par Android (WhatsApp, Telegram, dossiers .nomedia…)", UiStyle.deepScan) {
                    set { deepScan = it }; ex.forgetScans()
                }
            }
            item { SettingsSwitch(Ic.Info, "Fichiers cachés", "Afficher les fichiers et dossiers commençant par un point", UiStyle.showHidden) { set { showHidden = it }; ex.forgetScans(); ex.reload() } }
            item { SettingsSwitch(Ic.GridView, "Grille par défaut", "Sinon, les dossiers s'ouvrent en liste", UiStyle.defaultGrid) { set { defaultGrid = it }; ex.grid = it } }
            item { SettingsSwitch(Ic.Delete, "Confirmer la suppression", "Demander avant de placer dans la corbeille", UiStyle.confirmDelete) { set { confirmDelete = it } } }
            item {
                SettingsRow(
                    Ic.Lock, "Verrouillage du coffre", mode.label,
                ) {
                    // Pour ouvrir ce réglage : empreinte (ou code) du verrouillage d'écran du téléphone
                    if (act != null) authenticateWithPhoneLock(
                        act, "Verrouillage du coffre", "Confirme avec le verrouillage de ton téléphone",
                    ) { options = true }
                }
            }
            item { SettingsHeading("Fichiers") }
            item {
                val sub = if (ex.trashCount == 0) "Vide" else "${ex.trashCount} élément(s) · vidée après $TRASH_DAYS jours"
                SettingsRow(Ic.Delete, "Corbeille", sub, onTrash)
            }
            item {
                SettingsRow(Ic.Refresh, "Vider le cache", cacheSize?.let { "Aperçus et fichiers temporaires · " + Formatter.formatShortFileSize(ctx, it) } ?: "Calcul…") {
                    scope.launch {
                        val freed = withContext(Dispatchers.IO) { ex.clearAppCache() }
                        Toast.makeText(ctx, Formatter.formatShortFileSize(ctx, freed) + " libérés", Toast.LENGTH_SHORT).show()
                        cacheTick++
                    }
                }
            }

            // ── Lecteur
            item { SettingsHeading("Lecteur vidéo et musique") }
            item {
                SettingsBlock(Ic.Music, "Style du lecteur de musique", null) {
                    Segmented(UiStyle.audioNames, UiStyle.audioStyle) { set { audioStyle = it } }
                }
            }
            item {
                SettingsBlock(Ic.Forward, "Saut avant / arrière", "Boutons et double toucher") {
                    Segmented(UiStyle.seekSteps.map { "$it s" }, UiStyle.seekSteps.indexOf(UiStyle.seekStep).coerceAtLeast(0)) { set { seekStep = UiStyle.seekSteps[it] } }
                }
            }
            item { SettingsSwitch(Ic.Restore, "Reprendre la lecture", "Une vidéo ou une musique repart où tu l'avais laissée", UiStyle.resumePlayback) { set { resumePlayback = it } } }
            item { SettingsSwitch(Ic.Brightness, "Garder l'écran allumé", "Pendant la lecture d'une vidéo", UiStyle.keepScreenOn) { set { keepScreenOn = it } } }

            // ── À propos
            item { SettingsHeading("À propos") }
            item { SettingsRow(Ic.Info, "LinkShare $version", "Explorateur et partage de fichiers · DL VIBE STUDIO") {} }
            item { SettingsRow(Ic.Restore, "Réinitialiser l'apparence", "Revenir au thème et aux réglages d'origine") { confirmReset = true } }
        }
    }

    if (confirmReset) AlertDialog(
        onDismissRequest = { confirmReset = false },
        title = { Text("Réinitialiser ?") },
        text = { Text("Le thème, l'accent, les animations et les réglages du lecteur reviennent aux valeurs d'origine.") },
        confirmButton = { TextButton({ confirmReset = false; UiStyle.reset(ctx); ex.forgetScans() }) { Text("Réinitialiser") } },
        dismissButton = { TextButton({ confirmReset = false }) { Text("Annuler") } },
    )

    // ── Choix de la méthode (accessible seulement après la confirmation du téléphone)
    if (options) AlertDialog(
        onDismissRequest = { options = false },
        title = { Text("Verrouillage du coffre") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                VaultMode.values().forEach { m ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable {
                            when (m) {
                                VaultMode.PHONE -> applyMode(VaultMode.PHONE, null)
                                else -> setup = m
                            }
                        }.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(mode == m, onClick = null)
                        Spacer(Modifier.width(10.dp))
                        Text(m.label, color = LS.Text, fontSize = 15.sp)
                    }
                }
                if (mode != VaultMode.PHONE) {
                    HorizontalDivider(Modifier.padding(vertical = 8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Ouvrir aussi avec l'empreinte", color = LS.Text, fontSize = 15.sp)
                            Text(
                                if (fingerprintAvailable(ctx)) "Utilise les empreintes enregistrées dans le téléphone : Android ne permet pas d'en enregistrer une propre à l'appli."
                                else "Aucune empreinte enregistrée sur le téléphone.",
                                color = LS.Muted, fontSize = 11.sp,
                            )
                        }
                        Switch(
                            fingerprint, enabled = fingerprintAvailable(ctx),
                            onCheckedChange = { fingerprint = it; VaultAuth.setFingerprint(ctx, it) },
                        )
                    }
                }
            }
        },
        confirmButton = { TextButton({ options = false }) { Text("Fermer") } },
    )

    when (setup) {
        VaultMode.PATTERN -> PatternSetupDialog({ setup = null }) { applyMode(VaultMode.PATTERN, it) }
        VaultMode.PIN -> PinSetupDialog({ setup = null }) { applyMode(VaultMode.PIN, it) }
        else -> {}
    }
}

@Composable
private fun SettingsHeading(title: String) {
    Text(title, Modifier.padding(top = 8.dp, start = 4.dp), color = LS.Blue, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
}

@Composable
private fun SettingsIcon(icon: ImageVector) {
    Box(Modifier.size(42.dp).clip(CircleShape).background(LS.Card2), contentAlignment = Alignment.Center) {
        Icon(icon, null, Modifier.size(22.dp), tint = LS.Blue)
    }
}

@Composable
private fun SettingsSwitch(icon: ImageVector, title: String, sub: String, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().lsCard(RoundedCornerShape(UiStyle.r(22.dp))).clickable(enabled = enabled) { onChange(!checked) }
            .padding(horizontal = 16.dp, vertical = 12.dp).alpha(if (enabled) 1f else 0.45f),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        SettingsIcon(icon)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = LS.Text, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Text(sub, color = LS.Muted, fontSize = 12.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.width(8.dp))
        Switch(
            checked, onCheckedChange = onChange, enabled = enabled,
            colors = SwitchDefaults.colors(checkedThumbColor = LS.OnBlue, checkedTrackColor = LS.Blue),
        )
    }
}

/** Réglage avec un contenu libre en dessous (nuancier, choix segmentés…). */
@Composable
private fun SettingsBlock(icon: ImageVector, title: String, sub: String?, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().lsCard(RoundedCornerShape(UiStyle.r(22.dp))).padding(horizontal = 16.dp, vertical = 12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SettingsIcon(icon)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = LS.Text, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                if (sub != null) Text(sub, color = LS.Muted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
        Spacer(Modifier.height(10.dp))
        content()
    }
}

/** Choix exclusifs en pastilles (l'option choisie glisse en couleur d'accent). */
@Composable
private fun Segmented(options: List<String>, selected: Int, enabled: Boolean = true, onSelect: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(CircleShape).background(LS.Card2).padding(3.dp).alpha(if (enabled) 1f else 0.45f),
        horizontalArrangement = Arrangement.spacedBy(3.dp),
    ) {
        options.forEachIndexed { i, label ->
            val on = i == selected
            val bg by animateColorAsState(if (on) LS.Blue else Color.Transparent, tween(250), label = "seg")
            Box(
                Modifier.weight(1f).clip(CircleShape).background(bg).clickable(enabled = enabled) { onSelect(i) }.padding(vertical = 9.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    label, color = if (on) LS.OnBlue else LS.Text, fontSize = 12.sp,
                    fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

/** Aperçu miniature d'un thème : fond, carte et accent. */
@Composable
private fun ThemeSwatch(p: Palette, on: Boolean, onClick: () -> Unit) {
    val border by animateColorAsState(if (on) LS.Blue else LS.Line, tween(250), label = "sw")
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(76.dp)) {
        Box(
            Modifier.size(width = 70.dp, height = 92.dp).clip(RoundedCornerShape(16.dp)).background(p.bg)
                .border(if (on) 2.5.dp else 1.dp, border, RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(8.dp),
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Box(Modifier.fillMaxWidth().height(22.dp).clip(RoundedCornerShape(6.dp)).background(Brush.verticalGradient(listOf(p.cardTop, p.card))))
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Box(Modifier.weight(1f).height(16.dp).clip(RoundedCornerShape(5.dp)).background(p.card2))
                    Box(Modifier.weight(1f).height(16.dp).clip(RoundedCornerShape(5.dp)).background(p.card2))
                }
                Box(Modifier.width(30.dp).height(6.dp).clip(CircleShape).background(p.text.copy(alpha = 0.7f)))
            }
            Box(Modifier.align(Alignment.BottomEnd).size(18.dp).clip(CircleShape).background(p.accent), contentAlignment = Alignment.Center) {
                if (on) Icon(Ic.Check, null, Modifier.size(12.dp), tint = if (p.light) Color.White else Color(0xFF111111))
            }
        }
        Spacer(Modifier.height(5.dp))
        Text(p.name, color = if (on) LS.Blue else LS.Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun AccentDot(c: Color, name: String, on: Boolean, onClick: () -> Unit) {
    val size by animateDpAsState(if (on) 44.dp else 38.dp, tween(200), label = "dot")
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(56.dp)) {
        Box(Modifier.size(46.dp), contentAlignment = Alignment.Center) {
            Box(
                Modifier.size(size).clip(CircleShape).background(c)
                    .border(if (on) 3.dp else 0.dp, LS.Text.copy(alpha = if (on) 0.9f else 0f), CircleShape).clickable(onClick = onClick),
                contentAlignment = Alignment.Center,
            ) { if (on) Icon(Ic.Check, name, Modifier.size(20.dp), tint = Color(0xFF111111)) }
        }
        Text(name, color = if (on) LS.Text else LS.Muted, fontSize = 10.sp, maxLines = 1)
    }
}

@Composable
private fun SettingsRow(icon: ImageVector, title: String, sub: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().lsCard(RoundedCornerShape(UiStyle.r(22.dp))).clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(42.dp).clip(CircleShape).background(LS.Card2), contentAlignment = Alignment.Center) {
            Icon(icon, null, Modifier.size(22.dp), tint = LS.Blue)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = LS.Text, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Text(sub, color = LS.Muted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        Icon(Ic.Chevron, null, Modifier.size(22.dp), tint = LS.Muted)
    }
}

// ═══════════════════════════ Corbeille ═══════════════════════════

@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun TrashScreen(ex: ExplorerViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val sel = remember { mutableStateListOf<String>() }
    var confirmEmpty by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { ex.loadTrash() }
    // Un élément disparu de la corbeille (restauré, supprimé) quitte la sélection
    LaunchedEffect(ex.trashItems) { sel.retainAll(ex.trashItems.map { it.dir.path }.toSet()) }
    val picked = ex.trashItems.filter { it.dir.path in sel }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton({ if (sel.isNotEmpty()) sel.clear() else onBack() }) { Icon(Ic.Back, "Retour", tint = LS.Text) }
                Text("Corbeille", Modifier.weight(1f), color = LS.Text, fontSize = 20.sp, fontWeight = FontWeight.Medium)
                if (ex.trashItems.isNotEmpty()) TextButton({ confirmEmpty = true }) { Text("Vider", color = LS.Blue) }
            }
            ex.busy?.let { b ->
                Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                    Text(b, color = LS.Text, fontSize = 11.sp)
                    Spacer(Modifier.height(4.dp))
                    LinearProgressIndicator(Modifier.fillMaxWidth(), color = LS.Blue)
                }
            }
            Text(
                "Les éléments supprimés restent ici $TRASH_DAYS jours, puis sont effacés définitivement.",
                Modifier.padding(horizontal = 20.dp, vertical = 6.dp), color = LS.Muted, fontSize = 12.sp,
            )
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 6.dp, bottom = if (sel.isNotEmpty()) 104.dp else 32.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                if (ex.trashItems.isEmpty()) item(key = "empty") {
                    Text("La corbeille est vide", Modifier.fillMaxWidth().padding(24.dp), color = LS.Muted, fontSize = 13.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                }
                items(ex.trashItems, key = { it.dir.path }) { t ->
                    val on = t.dir.path in sel
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(if (on) LS.BlueLight else androidx.compose.ui.graphics.Color.Transparent)
                            .combinedClickable(
                                onClick = { if (sel.isNotEmpty()) { if (!sel.remove(t.dir.path)) sel.add(t.dir.path) } else sel.add(t.dir.path) },
                                onLongClick = { if (!sel.remove(t.dir.path)) sel.add(t.dir.path) },
                            ).padding(4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(Modifier.size(52.dp).clip(RoundedCornerShape(10.dp)).background(LS.Card), contentAlignment = Alignment.Center) {
                            Icon(if (t.isDir) Ic.Folder else t.file.category().icon(), null, Modifier.size(28.dp), tint = if (t.isDir) LS.Blue else LS.Muted)
                        }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(t.file.name, color = LS.Text, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                Formatter.formatShortFileSize(ctx, t.size) + " · supprimé le " + DateFormat.getDateInstance(DateFormat.SHORT).format(Date(t.deletedAt)),
                                color = LS.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            )
                        }
                        if (on) Icon(Ic.Check, null, Modifier.padding(end = 8.dp).size(20.dp), tint = LS.Blue)
                    }
                }
            }
        }
        if (sel.isNotEmpty()) SelectionBar(
            sel.size,
            listOf(
                BarAction("Restaurer", Ic.Restore) { ex.restoreFromTrash(picked); sel.clear() },
                BarAction("Suppr.", Ic.Delete) { confirmDelete = true },
            ),
            Modifier.align(Alignment.BottomCenter).navigationBarsPadding(),
            onCancel = { sel.clear() },
        )
    }

    if (confirmEmpty) AlertDialog(
        onDismissRequest = { confirmEmpty = false },
        title = { Text("Vider la corbeille ?") },
        text = { Text("${ex.trashItems.size} élément(s) seront supprimés définitivement.") },
        confirmButton = { TextButton({ confirmEmpty = false; sel.clear(); ex.emptyTrash() }) { Text("Vider") } },
        dismissButton = { TextButton({ confirmEmpty = false }) { Text("Annuler") } },
    )
    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("Supprimer définitivement ?") },
        text = { Text("${picked.size} élément(s) seront supprimés définitivement.") },
        confirmButton = { TextButton({ confirmDelete = false; ex.deleteTrashForever(picked); sel.clear() }) { Text("Supprimer") } },
        dismissButton = { TextButton({ confirmDelete = false }) { Text("Annuler") } },
    )
}
