package com.example.mediaconverter

import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFprobeKit
import com.arthenica.ffmpegkit.ReturnCode
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

enum class Operation(val label: String) {
    TO_MP3("MP4 → MP3"),
    TO_WAV("MP4 → WAV"),
    TO_VIDEO("MP4 → autre format vidéo"),
    COMPRESS("Compresser la vidéo"),
    ADD_AUDIO("Ajouter un son à la vidéo"),
    EXTRACT_VOICE("Extraire la voix (IA, lent)"),
    EXTRACT_VOICE_FAST("Extraire la voix (filtre rapide)"),
}

enum class VideoFormat(val label: String, val ext: String, val mime: String, val muxer: String) {
    MKV("MKV", "mkv", "video/x-matroska", "matroska"),
    MOV("MOV", "mov", "video/quicktime", "mov"),
    WEBM("WebM", "webm", "video/webm", "webm"),
    AVI("AVI", "avi", "video/x-msvideo", "avi"),
}

enum class CompressLevel(val label: String, val crf: Int, val mpeg4Q: Int, val maxHeight: Int?) {
    LIGHT("Légère", 26, 4, null),
    MEDIUM("Moyenne (720p max)", 28, 7, 720),
    STRONG("Forte (480p max)", 32, 12, 480),
}

enum class VoiceOutput(val label: String) {
    VOICE("Voix seule (WAV)"),
    MUSIC("Tout sauf la voix : musique/ambiance (WAV)"),
    VIDEO_NO_VOICE("Vidéo sans la voix (MP4)"),
}

data class OutputSpec(val ext: String, val mime: String, val suffix: String)

fun outputSpec(op: Operation, fmt: VideoFormat, vo: VoiceOutput = VoiceOutput.VOICE): OutputSpec = when (op) {
    Operation.TO_MP3 -> OutputSpec("mp3", "audio/mpeg", "")
    Operation.TO_WAV -> OutputSpec("wav", "audio/x-wav", "")
    Operation.TO_VIDEO -> OutputSpec(fmt.ext, fmt.mime, "")
    Operation.COMPRESS -> OutputSpec("mp4", "video/mp4", "_compressé")
    Operation.ADD_AUDIO -> OutputSpec("mp4", "video/mp4", "_avec_son")
    Operation.EXTRACT_VOICE -> when (vo) {
        VoiceOutput.VOICE -> OutputSpec("wav", "audio/x-wav", "_voix")
        VoiceOutput.MUSIC -> OutputSpec("wav", "audio/x-wav", "_sans_voix")
        VoiceOutput.VIDEO_NO_VOICE -> OutputSpec("mp4", "video/mp4", "_sans_voix")
    }
    Operation.EXTRACT_VOICE_FAST -> OutputSpec("wav", "audio/x-wav", "_voix")
}

class MediaConverter {

    // Liste des encodeurs réellement présents dans le build FFmpeg embarqué
    private val encoders: String by lazy {
        FFmpegKit.execute("-hide_banner -encoders").allLogsAsString ?: ""
    }
    private fun hasEncoder(name: String) = encoders.contains(" $name ")

    /** input / output / audio sont des chemins "saf:..." fournis par FFmpegKitConfig. */
    suspend fun convert(
        op: Operation,
        input: String,
        output: String,
        audio: String?,
        videoFormat: VideoFormat,
        level: CompressLevel,
        mixOriginal: Boolean,
        onProgress: (Float) -> Unit,
    ): Result<Unit> {
        val durationMs = (FFprobeKit.getMediaInformation(input).mediaInformation
            ?.duration?.toDoubleOrNull()?.times(1000))?.toLong() ?: 0L

        val args = try {
            buildArgs(op, input, output, audio, videoFormat, level, mixOriginal)
        } catch (e: IllegalStateException) {
            return Result.failure(e)
        }
        return run(args, durationMs, onProgress)
    }

    private fun buildArgs(
        op: Operation, input: String, output: String, audio: String?,
        fmt: VideoFormat, level: CompressLevel, mix: Boolean,
    ): List<String> {
        val a = mutableListOf("-y", "-i", input)
        when (op) {
            Operation.TO_MP3 -> {
                check(hasEncoder("libmp3lame")) { NO_MP3 }
                a += listOf("-vn", "-c:a", "libmp3lame", "-q:a", "2", "-f", "mp3")
            }
            Operation.TO_WAV ->
                a += listOf("-vn", "-c:a", "pcm_s16le", "-ar", "44100", "-f", "wav")

            Operation.TO_VIDEO -> a += when (fmt) {
                // MKV / MOV : simple changement de conteneur (rapide, sans perte)
                VideoFormat.MKV, VideoFormat.MOV -> listOf("-c", "copy", "-f", fmt.muxer)
                VideoFormat.WEBM -> listOf(
                    "-c:v", "libvpx-vp9", "-b:v", "0", "-crf", "33",
                    "-deadline", "realtime", "-cpu-used", "8",
                    "-c:a", "libopus", "-f", "webm",
                )
                VideoFormat.AVI -> listOf("-c:v", "mpeg4", "-q:v", "5", "-c:a", "ac3", "-f", "avi")
            }

            Operation.COMPRESS -> {
                level.maxHeight?.let { a += listOf("-vf", "scale=-2:min($it\\,ih)") }
                a += if (hasEncoder("libx264"))
                    listOf("-c:v", "libx264", "-crf", "${level.crf}", "-preset", "veryfast", "-pix_fmt", "yuv420p")
                else // repli : encodeur MPEG-4 natif (moins efficace que H.264)
                    listOf("-c:v", "mpeg4", "-q:v", "${level.mpeg4Q}")
                a += listOf("-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", "-f", "mp4")
            }

            Operation.ADD_AUDIO -> {
                checkNotNull(audio) { "Choisissez d'abord un fichier audio." }
                a += listOf("-i", audio)
                a += if (mix) listOf(
                    "-filter_complex", "[0:a][1:a]amix=inputs=2:duration=first:dropout_transition=2[a]",
                    "-map", "0:v:0", "-map", "[a]",
                ) else listOf("-map", "0:v:0", "-map", "1:a:0", "-shortest")
                a += listOf("-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-f", "mp4")
            }

            Operation.EXTRACT_VOICE -> error("Géré par VoiceSeparator")

            // Filtre passe-bande + débruitage + normalisation (pas de vraie séparation)
            Operation.EXTRACT_VOICE_FAST -> a += listOf(
                "-vn", "-af", "highpass=f=120,lowpass=f=3800,afftdn=nf=-25,loudnorm",
                "-ar", "44100", "-c:a", "pcm_s16le", "-f", "wav",
            )
        }
        a += output
        return a
    }

    private suspend fun run(
        args: List<String>, durationMs: Long, onProgress: (Float) -> Unit,
    ): Result<Unit> = suspendCancellableCoroutine { cont ->
        val session = FFmpegKit.executeWithArgumentsAsync(
            args.toTypedArray(),
            { s ->
                if (cont.isActive) {
                    if (ReturnCode.isSuccess(s.returnCode)) cont.resume(Result.success(Unit))
                    else cont.resume(Result.failure(Exception(s.allLogsAsString.orEmpty().takeLast(500))))
                }
            },
            null,
            { st -> if (durationMs > 0) onProgress((st.time / durationMs.toFloat()).coerceIn(0f, 1f)) },
        )
        cont.invokeOnCancellation { FFmpegKit.cancel(session.sessionId) }
    }

    companion object {
        const val NO_MP3 = "Ce build FFmpeg n'inclut pas l'encodeur MP3 (libmp3lame). " +
            "Utilisez un tier payant du fork, ou exportez en WAV."
    }
}
