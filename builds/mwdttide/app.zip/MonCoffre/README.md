# MonCoffre

Application Android (Kotlin + Jetpack Compose) pour garder au même endroit vos comptes
(Google, WhatsApp, Facebook, Instagram, TikTok…), leurs mots de passe et tout ce qui sert
à les récupérer.

## Fonctions

- **Comptes** : identifiant, mot de passe, numéro et e-mail de récupération, notes.
- **Autres méthodes de récupération** : suggestions selon le service (clé Authenticator,
  appareil de confiance, passkey, clé de sécurité, date de création du compte, question
  secrète, PIN WhatsApp…) et champs personnalisés illimités.
- **Codes de secours** : import du fichier `.txt` téléchargé depuis le compte, ajout de
  nouveaux codes à tout moment, case « utilisé » pour chaque code.
- **Contacts** : lus automatiquement depuis le téléphone (après autorisation).
- **PDF** : cartes mises en page, aperçu avant enregistrement, au choix comptes seuls,
  contacts seuls ou les deux, avec ou sans les mots de passe.
- **Sauvegarde chiffrée** (`.mcoffre`) protégée par mot de passe, pour changer de téléphone.

## Sécurité

- Coffre chiffré en AES-256-GCM, clé dans l'Android Keystore.
- Ouverture par empreinte / visage ou par le code du téléphone ; reverrouillage après
  une minute hors de l'appli.
- Captures d'écran bloquées, aucune permission Internet : rien ne quitte le téléphone.
- Le PDF, lui, n'est **pas** chiffré : à ranger en lieu sûr.

## Compiler

**Android Studio** : ouvrir le dossier, laisser Gradle se synchroniser, puis Run.

**GitHub Actions** : pousser le projet sur un dépôt **privé** (branche `main`). Le workflow
« Compiler l'APK » produit l'APK dans les artefacts de l'exécution.

**Ligne de commande** : `./gradlew assembleDebug` → `app/build/outputs/apk/debug/`.

## Clé de signature

`keystore/moncoffre.jks` signe toutes les compilations avec la même clé : une nouvelle
version s'installe par-dessus l'ancienne sans effacer le coffre. Gardez ce fichier
(et le dépôt) privés, et ne le remplacez pas.
