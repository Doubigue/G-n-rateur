package com.moncoffre.app

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.moncoffre.app.data.Account
import com.moncoffre.app.data.PhoneContact
import com.moncoffre.app.data.Services
import com.moncoffre.app.data.Vault
import com.moncoffre.app.data.readContacts
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class VaultViewModel(app: Application) : AndroidViewModel(app) {

    private val vault = Vault(app)

    var accounts by mutableStateOf<List<Account>>(emptyList())
        private set

    var contacts by mutableStateOf<List<PhoneContact>>(emptyList())
        private set

    var contactsLoaded by mutableStateOf(false)
        private set

    /** Le fichier du coffre existait mais n'a pas pu être déchiffré. */
    var loadError by mutableStateOf(false)
        private set

    /** Le téléphone n'a ni code, ni schéma, ni empreinte : l'appli ne peut pas se verrouiller. */
    var deviceUnsecured by mutableStateOf(false)

    init {
        accounts = try {
            sorted(vault.load())
        } catch (e: Exception) {
            vault.quarantine()
            loadError = true
            emptyList()
        }
    }

    private fun sorted(list: List<Account>): List<Account> = list.sortedWith(
        compareBy<Account>(
            { a -> Services.all.indexOf(a.service).let { if (it < 0) 999 else it } },
            { a -> a.displayName.lowercase() },
        )
    )

    private fun commit(list: List<Account>) {
        accounts = sorted(list)
        vault.save(accounts)
    }

    fun upsert(account: Account) {
        val updated = account.copy(updatedAt = System.currentTimeMillis())
        commit(accounts.filter { it.id != account.id } + updated)
    }

    fun delete(id: String) = commit(accounts.filter { it.id != id })

    /** Fusionne une sauvegarde : un compte déjà présent (même id) est remplacé. */
    fun importAccounts(imported: List<Account>): Int {
        val ids = imported.map { it.id }.toSet()
        commit(accounts.filter { it.id !in ids } + imported)
        return imported.size
    }

    fun loadContacts() {
        viewModelScope.launch {
            val list = withContext(Dispatchers.IO) {
                runCatching { readContacts(getApplication()) }.getOrDefault(emptyList())
            }
            contacts = list
            contactsLoaded = true
        }
    }
}
