@file:OptIn(ExperimentalMaterial3Api::class)

package com.moncoffre.app.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.moncoffre.app.VaultViewModel
import com.moncoffre.app.data.Account
import com.moncoffre.app.data.BackupCode
import com.moncoffre.app.data.ExtraField
import com.moncoffre.app.data.Services
import com.moncoffre.app.data.parseBackupCodes
import java.text.DateFormat
import java.util.Date
import java.util.Locale

// ------------------------------------------------------------------
// Fiche d'un compte
// ------------------------------------------------------------------

@Composable
fun DetailScreen(vm: VaultViewModel, id: String, onBack: () -> Unit, onEdit: () -> Unit) {
    val account = vm.accounts.firstOrNull { it.id == id }
    if (account == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }
    var confirmDelete by remember { mutableStateOf(false) }
    BackHandler(onBack = onBack)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(account.service) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                    }
                },
                actions = {
                    IconButton(onClick = onEdit) {
                        Icon(Icons.Default.Edit, contentDescription = "Modifier")
                    }
                    IconButton(onClick = { confirmDelete = true }) {
                        Icon(Icons.Default.Delete, contentDescription = "Supprimer")
                    }
                },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ServiceBadge(account.service, size = 56.dp)
                Spacer(Modifier.width(16.dp))
                Column {
                    Text(account.displayName, style = MaterialTheme.typography.titleLarge)
                    Text(
                        text = "Modifié le " + DateFormat
                            .getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT, Locale.FRANCE)
                            .format(Date(account.updatedAt)),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            SectionCard("Connexion") {
                if (account.login.isNotBlank()) ValueRow("Identifiant", account.login)
                if (account.password.isNotBlank()) ValueRow("Mot de passe", account.password, secret = true)
                if (account.login.isBlank() && account.password.isBlank()) {
                    Text("Aucun identifiant enregistré", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            val hasRecovery = account.recoveryPhone.isNotBlank() || account.recoveryEmail.isNotBlank() ||
                account.fields.any { it.value.isNotBlank() }
            if (hasRecovery) {
                SectionCard("Récupération du compte") {
                    if (account.recoveryPhone.isNotBlank()) {
                        ValueRow("Numéro de récupération", account.recoveryPhone)
                    }
                    if (account.recoveryEmail.isNotBlank()) {
                        ValueRow("E-mail de récupération", account.recoveryEmail)
                    }
                    account.fields.filter { it.value.isNotBlank() }.forEach { field ->
                        ValueRow(field.label.ifBlank { "Autre" }, field.value, secret = field.secret)
                    }
                }
            }

            SectionCard("Codes de secours") {
                BackupCodesSection(
                    codes = account.backupCodes,
                    editable = false,
                    onChange = { vm.upsert(account.copy(backupCodes = it)) },
                )
            }

            if (account.notes.isNotBlank()) {
                SectionCard("Notes") { Text(account.notes) }
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Supprimer ce compte ?") },
            text = { Text("« ${account.displayName} » et tous ses codes seront effacés du coffre. Cette action est définitive.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    vm.delete(account.id)
                    onBack()
                }) { Text("Supprimer", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) { Text("Annuler") }
            },
        )
    }
}

// ------------------------------------------------------------------
// Codes de secours : import .txt, ajout à tout moment, suivi « utilisé »
// ------------------------------------------------------------------

@Composable
fun BackupCodesSection(
    codes: List<BackupCode>,
    editable: Boolean,
    onChange: (List<BackupCode>) -> Unit,
) {
    val context = LocalContext.current
    var showAdd by remember { mutableStateOf(false) }

    fun merge(text: String) {
        val known = codes.map { it.code }.toSet()
        val fresh = parseBackupCodes(text).filter { it !in known }
        if (fresh.isEmpty()) {
            toast(context, "Aucun nouveau code trouvé")
        } else {
            onChange(codes + fresh.map { BackupCode(it) })
            toast(context, "${fresh.size} code(s) ajouté(s)")
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val text = runCatching {
                context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            }.getOrNull()
            if (text == null) toast(context, "Impossible de lire ce fichier") else merge(text.take(200_000))
        }
    }

    if (codes.isEmpty()) {
        Text(
            text = "Aucun code. Importez le fichier .txt téléchargé depuis votre compte, ou saisissez-les.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    } else {
        Text(
            text = "${codes.count { !it.used }} restant(s) sur ${codes.size} — cochez un code après l'avoir utilisé",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Column {
            codes.forEachIndexed { index, code ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = code.used,
                        onCheckedChange = { used ->
                            onChange(codes.mapIndexed { i, c -> if (i == index) c.copy(used = used) else c })
                        },
                    )
                    Text(
                        text = code.code,
                        modifier = Modifier.weight(1f),
                        fontFamily = FontFamily.Monospace,
                        style = MaterialTheme.typography.bodyLarge,
                        textDecoration = if (code.used) TextDecoration.LineThrough else null,
                        color = if (code.used) MaterialTheme.colorScheme.onSurfaceVariant
                        else MaterialTheme.colorScheme.onSurface,
                    )
                    TextButton(onClick = { copyToClipboard(context, code.code) }) { Text("Copier") }
                    if (editable) {
                        IconButton(onClick = { onChange(codes.filterIndexed { i, _ -> i != index }) }) {
                            Icon(Icons.Default.Close, contentDescription = "Retirer ce code")
                        }
                    }
                }
            }
        }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = { picker.launch(arrayOf("text/plain", "text/*")) }) {
            Text("Importer un .txt")
        }
        OutlinedButton(onClick = { showAdd = true }) { Text("Ajouter des codes") }
    }

    if (showAdd) {
        var input by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("Ajouter des codes") },
            text = {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    label = { Text("Un code par ligne") },
                    minLines = 4,
                    modifier = Modifier.fillMaxWidth(),
                )
            },
            confirmButton = {
                TextButton(
                    enabled = input.isNotBlank(),
                    onClick = {
                        showAdd = false
                        merge(input)
                    },
                ) { Text("Ajouter") }
            },
            dismissButton = {
                TextButton(onClick = { showAdd = false }) { Text("Annuler") }
            },
        )
    }
}

// ------------------------------------------------------------------
// Création / modification
// ------------------------------------------------------------------

@Composable
fun EditScreen(vm: VaultViewModel, id: String?, onDone: (String?) -> Unit) {
    val initial = remember(id) { vm.accounts.firstOrNull { it.id == id } ?: Account() }
    var draft by remember(id) { mutableStateOf(initial) }
    var showPassword by remember { mutableStateOf(false) }
    var confirmLeave by remember { mutableStateOf(false) }

    val canSave = draft.login.isNotBlank() || draft.title.isNotBlank()
    val leave: () -> Unit = {
        if (draft != initial) {
            confirmLeave = true
        } else {
            onDone(id)
        }
    }
    BackHandler(onBack = leave)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (id == null) "Nouveau compte" else "Modifier") },
                navigationIcon = {
                    IconButton(onClick = leave) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                    }
                },
                actions = {
                    TextButton(
                        enabled = canSave,
                        onClick = {
                            val cleaned = draft.copy(
                                fields = draft.fields.filter { it.label.isNotBlank() || it.value.isNotBlank() },
                            )
                            vm.upsert(cleaned)
                            onDone(cleaned.id)
                        },
                    ) { Text("Enregistrer") }
                },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
        ) {
            LazyRow(
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(Services.all) { service ->
                    FilterChip(
                        selected = draft.service == service,
                        onClick = { draft = draft.copy(service = service) },
                        label = { Text(service) },
                    )
                }
            }

            Column(
                modifier = Modifier.padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp),
            ) {
                SectionCard("Connexion") {
                    OutlinedTextField(
                        value = draft.title,
                        onValueChange = { draft = draft.copy(title = it) },
                        label = { Text("Nom du compte (facultatif)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = draft.login,
                        onValueChange = { draft = draft.copy(login = it) },
                        label = { Text("E-mail, numéro ou identifiant") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = draft.password,
                        onValueChange = { draft = draft.copy(password = it) },
                        label = { Text("Mot de passe") },
                        singleLine = true,
                        visualTransformation = if (showPassword) VisualTransformation.None
                        else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        trailingIcon = {
                            TextButton(onClick = { showPassword = !showPassword }) {
                                Text(if (showPassword) "Masquer" else "Voir")
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }

                SectionCard("Récupération du compte") {
                    OutlinedTextField(
                        value = draft.recoveryPhone,
                        onValueChange = { draft = draft.copy(recoveryPhone = it) },
                        label = { Text("Numéro de récupération") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = draft.recoveryEmail,
                        onValueChange = { draft = draft.copy(recoveryEmail = it) },
                        label = { Text("E-mail de récupération") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        modifier = Modifier.fillMaxWidth(),
                    )

                    draft.fields.forEach { field ->
                        key(field.id) {
                            ExtraFieldEditor(
                                field = field,
                                onChange = { changed ->
                                    draft = draft.copy(
                                        fields = draft.fields.map { if (it.id == changed.id) changed else it },
                                    )
                                },
                                onRemove = {
                                    draft = draft.copy(fields = draft.fields.filter { it.id != field.id })
                                },
                            )
                        }
                    }

                    Text(
                        text = "Ajouter une autre méthode",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    val suggestions = Services.presets(draft.service)
                        .filter { preset -> draft.fields.none { it.label == preset } }
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(suggestions) { preset ->
                            AssistChip(
                                onClick = {
                                    draft = draft.copy(
                                        fields = draft.fields +
                                            ExtraField(label = preset, secret = Services.isSecretLabel(preset)),
                                    )
                                },
                                label = { Text(preset) },
                            )
                        }
                    }
                    OutlinedButton(onClick = { draft = draft.copy(fields = draft.fields + ExtraField()) }) {
                        Text("Champ personnalisé")
                    }
                }

                SectionCard("Codes de secours") {
                    BackupCodesSection(
                        codes = draft.backupCodes,
                        editable = true,
                        onChange = { draft = draft.copy(backupCodes = it) },
                    )
                }

                SectionCard("Notes") {
                    OutlinedTextField(
                        value = draft.notes,
                        onValueChange = { draft = draft.copy(notes = it) },
                        label = { Text("Notes libres") },
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }

    if (confirmLeave) {
        AlertDialog(
            onDismissRequest = { confirmLeave = false },
            title = { Text("Quitter sans enregistrer ?") },
            text = { Text("Vos modifications seront perdues.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmLeave = false
                    onDone(id)
                }) { Text("Quitter") }
            },
            dismissButton = {
                TextButton(onClick = { confirmLeave = false }) { Text("Continuer") }
            },
        )
    }
}

@Composable
private fun ExtraFieldEditor(
    field: ExtraField,
    onChange: (ExtraField) -> Unit,
    onRemove: () -> Unit,
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = field.label,
                onValueChange = { onChange(field.copy(label = it)) },
                label = { Text("Intitulé") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = field.value,
                onValueChange = { onChange(field.copy(value = it)) },
                label = { Text("Valeur") },
                modifier = Modifier.fillMaxWidth(),
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(
                    checked = field.secret,
                    onCheckedChange = { onChange(field.copy(secret = it)) },
                )
                Text("Masquer la valeur", modifier = Modifier.weight(1f))
                TextButton(onClick = onRemove) {
                    Text("Retirer", color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}
