@file:OptIn(ExperimentalMaterial3Api::class)

package com.moncoffre.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.moncoffre.app.VaultViewModel
import com.moncoffre.app.data.Account

private sealed interface Screen {
    data object Home : Screen
    data class Detail(val id: String) : Screen
    data class Edit(val id: String?) : Screen
}

@Composable
fun MonCoffreApp(vm: VaultViewModel) {
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }
    var tab by rememberSaveable { mutableIntStateOf(0) }

    when (val s = screen) {
        Screen.Home -> HomeScreen(
            vm = vm,
            tab = tab,
            onTab = { tab = it },
            onOpen = { screen = Screen.Detail(it) },
            onAdd = { screen = Screen.Edit(null) },
        )
        is Screen.Detail -> DetailScreen(
            vm = vm,
            id = s.id,
            onBack = { screen = Screen.Home },
            onEdit = { screen = Screen.Edit(s.id) },
        )
        is Screen.Edit -> EditScreen(
            vm = vm,
            id = s.id,
            onDone = { id -> screen = if (id != null) Screen.Detail(id) else Screen.Home },
        )
    }
}

@Composable
private fun HomeScreen(
    vm: VaultViewModel,
    tab: Int,
    onTab: (Int) -> Unit,
    onOpen: (String) -> Unit,
    onAdd: () -> Unit,
) {
    val titles = listOf("Mes comptes", "Contacts", "Exporter")
    Scaffold(
        topBar = {
            TopAppBar(title = { Text(titles[tab], fontWeight = FontWeight.Bold) })
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == 0,
                    onClick = { onTab(0) },
                    icon = { Icon(Icons.Default.Lock, contentDescription = null) },
                    label = { Text("Comptes") },
                )
                NavigationBarItem(
                    selected = tab == 1,
                    onClick = { onTab(1) },
                    icon = { Icon(Icons.Default.Person, contentDescription = null) },
                    label = { Text("Contacts") },
                )
                NavigationBarItem(
                    selected = tab == 2,
                    onClick = { onTab(2) },
                    icon = { Icon(Icons.Default.Share, contentDescription = null) },
                    label = { Text("Exporter") },
                )
            }
        },
        floatingActionButton = {
            if (tab == 0) {
                ExtendedFloatingActionButton(
                    onClick = onAdd,
                    icon = { Icon(Icons.Default.Add, contentDescription = null) },
                    text = { Text("Ajouter") },
                )
            }
        },
    ) { padding ->
        val modifier = Modifier.padding(padding)
        when (tab) {
            0 -> AccountsList(vm, onOpen, modifier)
            1 -> ContactsScreen(vm, modifier)
            else -> ExportScreen(vm, modifier)
        }
    }
}

@Composable
private fun AccountsList(vm: VaultViewModel, onOpen: (String) -> Unit, modifier: Modifier) {
    var query by rememberSaveable { mutableStateOf("") }
    var filter by rememberSaveable { mutableStateOf("") }
    val services = vm.accounts.map { it.service }.distinct()
    val shown = vm.accounts.filter { a ->
        (filter.isEmpty() || a.service == filter) &&
            (query.isBlank() || a.title.contains(query, true) ||
                a.login.contains(query, true) || a.service.contains(query, true))
    }

    Column(modifier.fillMaxSize()) {
        if (vm.loadError) {
            Notice("Le coffre enregistré n'a pas pu être lu. Il a été mis de côté ; restaurez une sauvegarde depuis l'onglet Exporter.")
        }
        if (vm.deviceUnsecured) {
            Notice("Ce téléphone n'a pas de verrouillage d'écran : MonCoffre s'ouvre sans contrôle. Activez un code, un schéma ou l'empreinte dans les paramètres.")
        }
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            placeholder = { Text("Rechercher un compte") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            singleLine = true,
            shape = RoundedCornerShape(28.dp),
        )
        if (services.size > 1) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(top = 8.dp),
            ) {
                item {
                    FilterChip(
                        selected = filter.isEmpty(),
                        onClick = { filter = "" },
                        label = { Text("Tous") },
                    )
                }
                items(services) { service ->
                    FilterChip(
                        selected = filter == service,
                        onClick = { filter = if (filter == service) "" else service },
                        label = { Text(service) },
                    )
                }
            }
        }
        if (shown.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Text(
                    text = if (vm.accounts.isEmpty()) "Aucun compte pour l'instant" else "Aucun résultat",
                    style = MaterialTheme.typography.titleMedium,
                )
                if (vm.accounts.isEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "Touchez « Ajouter » pour enregistrer un e-mail, un compte WhatsApp, Facebook, TikTok…",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                    )
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(shown, key = { it.id }) { account ->
                    AccountItem(account, onClick = { onOpen(account.id) })
                }
            }
        }
    }
}

@Composable
private fun AccountItem(account: Account, onClick: () -> Unit) {
    val tint = androidx.compose.ui.graphics.Color(com.moncoffre.app.data.Services.color(account.service))
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        border = androidx.compose.foundation.BorderStroke(1.dp, tint.copy(alpha = 0.35f)),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            modifier = Modifier
                .background(
                    androidx.compose.ui.graphics.Brush.horizontalGradient(
                        listOf(tint.copy(alpha = 0.22f), tint.copy(alpha = 0.02f))
                    )
                )
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            ServiceBadge(account.service)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    text = account.displayName,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                val remaining = account.backupCodes.count { !it.used }
                Text(
                    text = account.service +
                        if (account.backupCodes.isNotEmpty()) " · $remaining code(s) de secours" else "",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Icon(
                Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
fun Notice(text: String, modifier: Modifier = Modifier) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.primaryContainer,
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onPrimaryContainer,
            modifier = Modifier.padding(12.dp),
        )
    }
}

@Composable
fun LockScreen(onUnlock: () -> Unit, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Icon(
                Icons.Default.Lock,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(56.dp),
            )
            Spacer(Modifier.height(16.dp))
            Text("MonCoffre", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(
                text = "Vos comptes sont verrouillés",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(28.dp))
            Button(onClick = onUnlock) { Text("Déverrouiller") }
        }
    }
}
