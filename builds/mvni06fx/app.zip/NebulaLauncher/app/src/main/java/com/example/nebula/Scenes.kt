package com.example.nebula

import android.graphics.*
import java.util.Calendar
import kotlin.math.*
import kotlin.random.Random

private fun c(v: Long) = v.toInt()

/**
 * Scènes animées dessinées en code (aucune image) :
 * 6 papillon · 7 oiseaux · 8 printemps · 9 été · 10 automne · 11 hiver · 12 saison automatique
 * 13 fleur qui naît, grandit et fleurit · 14 plage selon l'heure réelle · 15 nuit étoilée et vraie lune
 * (8-15 : rendu photo-réaliste dans PhotoScenes.kt)
 */
class SceneRenderer {
    private var w = 0; private var h = 0; private var sc = 1f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()
    private val rnd = Random(7)

    private class Star(val x: Float, val y: Float, val ph: Float, val r: Float)
    private class Bld(val x: Float, val w: Float, val h: Float, val cols: Int, val rows: Int, val lit: BooleanArray)
    private class Fp(var x: Float, var y: Float, val vy: Float, val ph: Float, val s: Float, val col: Int)
    private class Bird(val off: Float, val yb: Float, val sp: Float, val s: Float, val ph: Float)
    private val stars = ArrayList<Star>(); private val blds = ArrayList<Bld>()
    private val fall = ArrayList<Fp>(); private var fallKind = -1
    private val birds = ArrayList<Bird>()
    private val photo = PhotoScenes()
    private var bx = -1f; private var by = -1f
    private var lastStyle = -1; private var t0 = 0L

    fun resize(w: Int, h: Int) {
        this.w = w; this.h = h; sc = min(w, h) / 720f; photo.resize(w, h)
        stars.clear(); blds.clear(); birds.clear(); fallKind = -1; bx = -1f
        if (w == 0 || h == 0) return
        repeat(140) { stars += Star(rnd.nextFloat() * w, rnd.nextFloat() * h * 0.55f, rnd.nextFloat() * 6.28f, 1f + rnd.nextFloat() * 2f) }
        var x = -10f
        while (x < w) {
            val bw = (30 + rnd.nextInt(50)) * sc * 1.4f; val bh = h * (0.05f + rnd.nextFloat() * 0.18f)
            val cols = max(2, (bw / (14 * sc * 1.4f)).toInt()); val rows = max(2, (bh / (18 * sc * 1.4f)).toInt())
            blds += Bld(x, bw, bh, cols, rows, BooleanArray(cols * rows) { rnd.nextFloat() < 0.55f }); x += bw + 2 * sc
        }
        repeat(9) { birds += Bird(rnd.nextFloat(), 0.1f + rnd.nextFloat() * 0.3f, 0.03f + rnd.nextFloat() * 0.03f, (14 + rnd.nextInt(14)) * sc * 1.4f, rnd.nextFloat() * 6.28f) }
    }

    fun draw(cv: Canvas, style: Int, tx: Float, ty: Float) {
        if (w == 0) return
        if (style != lastStyle) { lastStyle = style; t0 = System.nanoTime(); fallKind = -1 }
        val t = (System.nanoTime() - t0) / 1e9f
        p.shader = null; p.style = Paint.Style.FILL
        when (style) {
            6 -> butterfly(cv, t, tx, ty)
            7 -> birdsScene(cv, t)
            8, 9, 10, 11, 13, 14, 15 -> photo.draw(cv, style, t, tx, ty)
            12 -> photo.draw(cv, 8 + autoSeason(), t, tx, ty)
            else -> photo.draw(cv, 14, t, tx, ty)
        }
    }

    // ───────── utilitaires ─────────
    private fun grad(cv: Canvas, top: Int, bot: Int, y0: Float = 0f, y1: Float = h.toFloat()) {
        p.style = Paint.Style.FILL; p.shader = LinearGradient(0f, y0, 0f, y1, top, bot, Shader.TileMode.CLAMP)
        cv.drawRect(0f, y0, w.toFloat(), y1, p); p.shader = null
    }
    private fun lerp(a: Int, b: Int, f: Float): Int {
        val k = f.coerceIn(0f, 1f)
        return Color.argb(255, (Color.red(a) + (Color.red(b) - Color.red(a)) * k).toInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * k).toInt(), (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).toInt())
    }
    private fun col(c: Int, a: Int) = (c and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)
    private fun smooth(x: Float): Float { val k = x.coerceIn(0f, 1f); return k * k * (3f - 2f * k) }
    private fun hill(cv: Canvas, baseY: Float, amp: Float, freq: Float, phase: Float, color: Int) {
        path.reset(); path.moveTo(0f, h.toFloat()); var x = 0f
        while (x <= w + 10) { path.lineTo(x, baseY + sin(x * freq + phase) * amp); x += 10f }
        path.lineTo(w + 10f, h.toFloat()); path.close(); p.style = Paint.Style.FILL; p.color = color; cv.drawPath(path, p)
    }
    private fun cloud(cv: Canvas, cx: Float, cy: Float, s: Float, alpha: Int) {
        p.style = Paint.Style.FILL; p.color = col(Color.WHITE, alpha)
        cv.drawCircle(cx, cy, s * 0.5f, p); cv.drawCircle(cx + s * 0.4f, cy + s * 0.08f, s * 0.4f, p)
        cv.drawCircle(cx - s * 0.4f, cy + s * 0.1f, s * 0.35f, p); cv.drawCircle(cx + s * 0.1f, cy + s * 0.15f, s * 0.45f, p)
    }
    private fun glowDisc(cv: Canvas, x: Float, y: Float, r: Float, color: Int, glow: Float, alpha: Int = 255) {
        p.shader = RadialGradient(x, y, glow, col(color, alpha * 150 / 255), col(color, 0), Shader.TileMode.CLAMP)
        cv.drawCircle(x, y, glow, p); p.shader = null
        p.color = col(color, alpha); cv.drawCircle(x, y, r, p)
    }
    /** 24 h découpées en 4 blocs de 6 h : 00-06 hiver, 06-12 printemps, 12-18 été, 18-24 automne. */
    private fun autoSeason(): Int = when (Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) { in 6..11 -> 0; in 12..17 -> 1; in 18..23 -> 2; else -> 3 }

    // ───────── 6 · Papillon ─────────
    private fun butterfly(cv: Canvas, t: Float, tx: Float, ty: Float) {
        grad(cv, c(0xFF7EC8F2), c(0xFFD6F5C8))
        cloud(cv, ((t * 10 * sc) % (w + 400f)) - 200f, h * 0.12f, 130f * sc, 190)
        hill(cv, h * 0.72f, h * 0.03f, 0.006f, 0f, c(0xFF7FD17A)); hill(cv, h * 0.8f, h * 0.025f, 0.009f, 2f, c(0xFF4FB05A))
        val fc = intArrayOf(c(0xFFFF6FA5), c(0xFFFFD93D), c(0xFFFFFFFF), c(0xFFB28DFF))
        var x = 20f * sc; var i = 0
        while (x < w) {
            val sw = sin(t * 1.5f + i) * 6f * sc; val y0 = h * 0.9f
            p.style = Paint.Style.STROKE; p.strokeWidth = 3f * sc; p.color = c(0xFF2E8B3E); cv.drawLine(x, h.toFloat(), x + sw, y0, p)
            p.style = Paint.Style.FILL; p.color = fc[i % 4]; cv.drawCircle(x + sw, y0, 8f * sc, p)
            p.color = c(0xFFFFB300); cv.drawCircle(x + sw, y0, 3f * sc, p); x += 38f * sc; i++
        }
        val gx = if (tx >= 0) tx else w / 2f + sin(t * 0.6f) * w * 0.32f + sin(t * 1.7f) * w * 0.05f
        val gy = if (tx >= 0) ty else h * 0.4f + sin(t * 0.9f) * h * 0.12f + sin(t * 2.3f) * h * 0.02f
        if (bx < 0) { bx = w / 2f; by = h / 2f }
        val px = bx; bx += (gx - bx) * 0.03f; by += (gy - by) * 0.03f
        cv.save(); cv.translate(bx, by + sin(t * 12f) * 3f * sc); cv.rotate(((bx - px) * 3f).coerceIn(-18f, 18f))
        val s = sc * 1.6f; cv.scale(s, s)
        val flap = abs(sin(t * 12f)) * 0.85f + 0.15f
        for (side in intArrayOf(-1, 1)) {
            cv.save(); cv.scale(side * flap, 1f)
            p.style = Paint.Style.FILL; p.color = c(0xFFFF9F1C); rect.set(4f, -78f, 98f, 6f); cv.drawOval(rect, p)
            p.color = c(0xFFE85D04); rect.set(4f, -2f, 70f, 58f); cv.drawOval(rect, p)
            p.color = col(Color.WHITE, 190); cv.drawCircle(56f, -38f, 9f, p); cv.drawCircle(40f, 28f, 6f, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 4f; p.color = c(0xFF2B1B17); rect.set(4f, -78f, 98f, 6f); cv.drawOval(rect, p)
            cv.restore()
        }
        p.style = Paint.Style.FILL; p.color = c(0xFF2B1B17); rect.set(-5f, -40f, 5f, 44f); cv.drawRoundRect(rect, 5f, 5f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 2.5f; cv.drawLine(0f, -40f, -14f, -62f, p); cv.drawLine(0f, -40f, 14f, -62f, p)
        cv.restore(); p.style = Paint.Style.FILL
    }

    // ───────── 7 · Oiseaux ─────────
    private fun birdsScene(cv: Canvas, t: Float) {
        grad(cv, c(0xFF4A90D9), c(0xFFFFD9A8))
        p.shader = RadialGradient(w * 0.75f, h * 0.55f, h * 0.35f, c(0x88FFE9A8), c(0x00FFE9A8), Shader.TileMode.CLAMP)
        cv.drawCircle(w * 0.75f, h * 0.55f, h * 0.35f, p); p.shader = null
        for (i in 0..3) cloud(cv, ((t * (10 + i * 4) * sc + i * w / 3f) % (w + 400f)) - 200f, h * (0.12f + 0.1f * i), 140f * sc, 190)
        hill(cv, h * 0.86f, h * 0.03f, 0.007f, 1f, c(0xFF2D4A3E))
        for (b in birds) {
            val x = (((t * b.sp + b.off) % 1.3f) - 0.15f) * w
            val y = h * b.yb + sin(t * 1.2f + b.ph) * h * 0.02f
            drawBird(cv, x, y, b.s, sin(t * 7f + b.ph))
        }
    }
    private fun drawBird(cv: Canvas, x: Float, y: Float, s: Float, f: Float) {
        p.style = Paint.Style.STROKE; p.strokeWidth = max(2f, s * 0.14f); p.strokeCap = Paint.Cap.ROUND; p.color = c(0xFF1B1B2F)
        path.reset(); path.moveTo(x - s, y - f * s * 0.6f)
        path.quadTo(x - s * 0.5f, y - f * s * 0.9f - s * 0.25f, x, y)
        path.quadTo(x + s * 0.5f, y - f * s * 0.9f - s * 0.25f, x + s, y - f * s * 0.6f)
        cv.drawPath(path, p); p.style = Paint.Style.FILL
    }

    // ───────── 8-12 · Saisons ─────────
    private fun season(cv: Canvas, k: Int, t: Float, tx: Float) {
        when (k) {
            0 -> grad(cv, c(0xFF9AD0F5), c(0xFFFFE3EE)); 1 -> grad(cv, c(0xFF1E88E5), c(0xFFBDEBFF))
            2 -> grad(cv, c(0xFFE9762B), c(0xFFFFE0B2)); else -> grad(cv, c(0xFF2B3A55), c(0xFFB8C6DB))
        }
        val sx = if (k == 2) w * 0.2f else w * 0.8f; val sy = if (k == 2) h * 0.3f else h * 0.17f
        when (k) {
            1 -> {
                for (i in 0 until 12) {
                    val a = t * 0.12f + i * PI.toFloat() / 6f
                    p.style = Paint.Style.STROKE; p.strokeWidth = 6f * sc; p.color = col(c(0xFFFFF176), 130)
                    cv.drawLine(sx + cos(a) * 70f * sc, sy + sin(a) * 70f * sc, sx + cos(a) * 130f * sc, sy + sin(a) * 130f * sc, p)
                }
                p.style = Paint.Style.FILL; glowDisc(cv, sx, sy, 50f * sc, c(0xFFFFEB3B), 220f * sc)
            }
            3 -> glowDisc(cv, sx, sy, 38f * sc, c(0xFFF5F7FF), 160f * sc)
            2 -> glowDisc(cv, sx, sy, 50f * sc, c(0xFFFF8A3D), 220f * sc)
            else -> glowDisc(cv, sx, sy, 42f * sc, c(0xFFFFF3B0), 170f * sc)
        }
        for (i in 0..2) cloud(cv, ((t * (8 + i * 4) * sc + i * w * 0.4f) % (w + 500f)) - 250f, h * (0.1f + 0.09f * i), 130f * sc * (1 + i * 0.2f), if (k == 3) 120 else 200)
        val far = intArrayOf(c(0xFFA8E6A1), c(0xFFB5D96B), c(0xFFC98A4B), c(0xFFE8EEF7))
        val near = intArrayOf(c(0xFF7BD389), c(0xFF8FBF3A), c(0xFF9A5B2E), c(0xFFFFFFFF))
        hill(cv, h * 0.72f, h * 0.04f, 0.005f, 0.5f, far[k]); hill(cv, h * 0.82f, h * 0.03f, 0.008f, 2f, near[k])
        val canopy = intArrayOf(c(0xFFFFB7D5), c(0xFF3E9B3E), c(0xFFE98A15), 0)
        if (k == 3) { pine(cv, w * 0.2f, h * 0.8f, h * 0.3f); pine(cv, w * 0.82f, h * 0.82f, h * 0.25f); pine(cv, w * 0.12f, h * 0.84f, h * 0.18f) }
        else { tree(cv, w * 0.2f, h * 0.8f, h * 0.3f, canopy[k], t); tree(cv, w * 0.8f, h * 0.82f, h * 0.25f, canopy[k], t) }
        fallingStuff(cv, k, t, tx)
    }
    private fun tree(cv: Canvas, x: Float, baseY: Float, s: Float, canopy: Int, t: Float) {
        val sw = sin(t * 0.8f + x) * s * 0.01f
        p.style = Paint.Style.FILL; p.color = c(0xFF6D4C41)
        rect.set(x - s * 0.05f, baseY - s * 0.55f, x + s * 0.05f, baseY); cv.drawRoundRect(rect, 6f, 6f, p)
        p.color = canopy
        cv.drawCircle(x + sw, baseY - s * 0.72f, s * 0.3f, p)
        cv.drawCircle(x - s * 0.22f + sw, baseY - s * 0.55f, s * 0.22f, p); cv.drawCircle(x + s * 0.22f + sw, baseY - s * 0.56f, s * 0.22f, p)
    }
    private fun pine(cv: Canvas, x: Float, baseY: Float, s: Float) {
        p.style = Paint.Style.FILL; p.color = c(0xFF5D4037); rect.set(x - s * 0.04f, baseY - s * 0.15f, x + s * 0.04f, baseY); cv.drawRect(rect, p)
        for (i in 0..2) {
            val by0 = baseY - s * (0.1f + 0.25f * i); val half = s * (0.3f - 0.07f * i); val top = by0 - s * 0.38f
            p.color = c(0xFF1F4D3A); path.reset(); path.moveTo(x - half, by0); path.lineTo(x, top); path.lineTo(x + half, by0); path.close(); cv.drawPath(path, p)
            p.color = Color.WHITE; path.reset(); path.moveTo(x - half * 0.45f, by0 - s * 0.2f); path.lineTo(x, top); path.lineTo(x + half * 0.45f, by0 - s * 0.2f); path.close(); cv.drawPath(path, p)
        }
    }
    private fun ensureFall(kind: Int) {
        if (fallKind == kind) return; fallKind = kind; fall.clear()
        val pal = when (kind) {
            0 -> intArrayOf(c(0xFFFFB7D5), c(0xFFFFD1E6), c(0xFFFFFFFF)); 1 -> intArrayOf(c(0xFFFFF59D), c(0xFFFFE082))
            2 -> intArrayOf(c(0xFFE4572E), c(0xFFF2A541), c(0xFFB5651D), c(0xFFD94F04)); else -> intArrayOf(Color.WHITE)
        }
        repeat(when (kind) { 0 -> 45; 1 -> 35; 2 -> 40; else -> 90 }) {
            fall += Fp(rnd.nextFloat() * w, rnd.nextFloat() * h, (0.8f + rnd.nextFloat() * 1.6f) * sc * 1.5f, rnd.nextFloat() * 6.28f,
                (4 + rnd.nextFloat() * 7) * sc * 1.5f, pal[rnd.nextInt(pal.size)])
        }
    }
    private fun fallingStuff(cv: Canvas, kind: Int, t: Float, tx: Float) {
        ensureFall(kind)
        for (f in fall) {
            f.y += if (kind == 1) -f.vy * 0.25f else f.vy
            f.x += sin(t * 0.9f + f.ph) * 1.3f * sc
            if (tx >= 0) { val d = f.x - tx; if (abs(d) < 200f) f.x += sign(d) * 1.5f }
            if (f.y > h + 20) { f.y = -20f; f.x = rnd.nextFloat() * w }
            if (f.y < -20) { f.y = h + 20f }
            if (f.x < -20) f.x = w + 20f; if (f.x > w + 20) f.x = -20f
            p.style = Paint.Style.FILL
            when (kind) {
                0, 2 -> { p.color = f.col; cv.save(); cv.translate(f.x, f.y); cv.rotate(t * 60f * sin(f.ph) + f.ph * 57f)
                    rect.set(-f.s, -f.s * 0.5f, f.s, f.s * 0.5f); cv.drawOval(rect, p); cv.restore() }
                1 -> { p.color = col(f.col, (120 + 100 * sin(t * 3f + f.ph)).toInt()); cv.drawCircle(f.x, f.y, f.s * 0.5f, p) }
                else -> { p.color = f.col; cv.drawCircle(f.x, f.y, f.s * 0.4f, p) }
            }
        }
    }

    // ───────── 13 · Fleur qui naît, grandit, fleurit ─────────
    private fun flower(cv: Canvas, t: Float) {
        grad(cv, c(0xFF8EC5FC), c(0xFFE0C3FC))
        val baseY = h * 0.82f; val cx = w / 2f; val maxH = h * 0.42f
        hill(cv, h * 0.8f, 6f * sc, 0.02f, 0f, c(0xFF4CAF50))
        p.style = Paint.Style.FILL; p.color = c(0xFF5A3A22); cv.drawRect(0f, baseY + 8f * sc, w.toFloat(), h.toFloat(), p)
        val cycle = 42f; val ph = (t % cycle) / cycle
        val fade = ((ph - 0.94f) / 0.06f).coerceIn(0f, 1f)
        val layer = cv.saveLayerAlpha(0f, 0f, w.toFloat(), h.toFloat(), ((1f - fade) * 255).toInt())
        if (ph < 0.12f) { p.color = c(0xFF8D6E63); cv.drawCircle(cx, baseY + 22f * sc, 9f * sc, p) } // la graine
        drawPlant(cv, cx, baseY, maxH, smooth((ph - 0.06f) / 0.5f), smooth((ph - 0.25f) / 0.3f), smooth((ph - 0.55f) / 0.2f), t, c(0xFFFF4D8D), c(0xFFFFD166))
        val offs = floatArrayOf(-0.32f, -0.18f, 0.2f, 0.34f); val hs = floatArrayOf(0.35f, 0.22f, 0.27f, 0.4f)
        val cols = intArrayOf(c(0xFFFFFFFF), c(0xFFFFB347), c(0xFFB28DFF), c(0xFFFF6B6B))
        for (i in 0..3) {
            val g = smooth((ph - 0.70f - i * 0.04f) / 0.12f)
            if (g > 0f) drawPlant(cv, cx + w * offs[i], baseY, maxH * hs[i], g, g, g, t + i, cols[i], c(0xFFFFD166))
        }
        cv.restoreToCount(layer)
    }
    private fun drawPlant(cv: Canvas, x: Float, baseY: Float, maxH: Float, stem: Float, leaf: Float, open: Float, t: Float, petal: Int, center: Int) {
        if (stem <= 0.01f) return
        val len = maxH * stem; val sway = sin(t * 1.1f + x * 0.01f) * len * 0.04f
        val topX = x + sway; val topY = baseY - len
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = max(4f, 12f * sc * (0.6f + 0.4f * stem)); p.color = c(0xFF3E9B4F)
        path.reset(); path.moveTo(x, baseY); path.quadTo(x - len * 0.05f, baseY - len * 0.5f, topX, topY); cv.drawPath(path, p)
        p.style = Paint.Style.FILL
        if (leaf > 0f) for (side in intArrayOf(-1, 1)) {
            val fy = baseY - len * (if (side < 0) 0.35f else 0.55f); val ll = maxH * 0.28f * leaf
            cv.save(); cv.translate(x + sway * 0.4f, fy); cv.scale(side.toFloat(), 1f); cv.rotate(-30f + sin(t + side) * 3f)
            p.color = c(0xFF58B368); rect.set(0f, -ll * 0.3f, ll, ll * 0.3f); cv.drawOval(rect, p); cv.restore()
        }
        val r = maxH * 0.16f
        if (open <= 0.03f) { p.color = c(0xFF6FBF73); cv.drawCircle(topX, topY, max(3f, r * 0.25f * stem), p); return }
        for (layer in 0..1) {
            val n = 10; val size = 1f - 0.25f * layer
            p.color = lerp(petal, Color.WHITE, 0.25f * layer)
            for (i in 0 until n) {
                cv.save(); cv.translate(topX, topY); cv.rotate(i * 360f / n + layer * 18f + sin(t * 0.3f) * 3f)
                rect.set(r * 0.15f, -r * 0.22f * open * size, r * (0.15f + 0.95f * open) * size, r * 0.22f * open * size); cv.drawOval(rect, p); cv.restore()
            }
        }
        p.color = center; cv.drawCircle(topX, topY, r * 0.3f * open, p)
    }

    // ───────── 14 · Plage + ville : le ciel suit l'heure réelle ─────────
    private val hrs = floatArrayOf(0f, 5f, 6.5f, 9f, 17f, 19f, 20.5f, 22f, 24f)
    private val tops = intArrayOf(c(0xFF050A24), c(0xFF0F1B45), c(0xFF4A6FA5), c(0xFF3FA9F5), c(0xFF3FA9F5), c(0xFF5B6FB5), c(0xFF1A2150), c(0xFF0A1030), c(0xFF050A24))
    private val bots = intArrayOf(c(0xFF0F1B45), c(0xFF5B4B8A), c(0xFFFFB07A), c(0xFFA8E0FF), c(0xFFA8E0FF), c(0xFFFF8F5B), c(0xFF6A3D7A), c(0xFF1A2150), c(0xFF0F1B45))
    private val WIN = c(0xFFFFE08A)
    private fun nightFactor(hf: Float) = when { hf < 5f || hf > 21.5f -> 1f; hf < 7f -> 1f - (hf - 5f) / 2f; hf > 19.5f -> (hf - 19.5f) / 2f; else -> 0f }

    private fun beachCity(cv: Canvas, t: Float, tx: Float) {
        val cal = Calendar.getInstance()
        // Toucher l'écran = faire défiler les heures (aperçu) ; sinon heure réelle
        val hf = if (tx >= 0) tx / w * 24f else cal.get(Calendar.HOUR_OF_DAY) + cal.get(Calendar.MINUTE) / 60f + cal.get(Calendar.SECOND) / 3600f
        var i = 0; while (i < hrs.size - 2 && hf > hrs[i + 1]) i++
        val f = (hf - hrs[i]) / (hrs[i + 1] - hrs[i])
        val top = lerp(tops[i], tops[i + 1], f); val bot = lerp(bots[i], bots[i + 1], f)
        val hor = h * 0.58f; val nf = nightFactor(hf); val seaEnd = h * 0.92f
        grad(cv, top, bot, 0f, hor)
        p.style = Paint.Style.FILL
        for (s in stars) {
            val a = nf * (0.45f + 0.55f * sin(t * 2f + s.ph))
            if (a > 0.02f && s.y < hor * 0.95f) { p.color = col(Color.WHITE, (a * 255).toInt()); cv.drawCircle(s.x, s.y, s.r * sc * 1.2f, p) }
        }
        var rx = -1f; var rI = 0f; var rc = Color.WHITE
        val sunUp = hf in 5.5f..20.5f && nf < 0.6f
        if (hf in 5.5f..20.5f) {
            val d = (hf - 5.5f) / 15f; val sx = w * (0.08f + 0.84f * d); val sy = hor - sin(PI.toFloat() * d) * hor * 0.8f
            val low = 1f - sin(PI.toFloat() * d); val scol = lerp(c(0xFFFFF1B0), c(0xFFFF7A3C), low * low)
            glowDisc(cv, sx, sy, 34f * sc * 1.3f, scol, h * 0.22f)
            if (sunUp) { rx = sx; rI = (0.35f + sin(PI.toFloat() * d)).coerceAtMost(1f); rc = scol }
        }
        if (hf >= 18f || hf <= 7f) {
            val m = if (hf >= 18f) (hf - 18f) / 13f else (hf + 6f) / 13f
            val mx = w * (0.08f + 0.84f * m); val my = hor - sin(PI.toFloat() * m) * hor * 0.8f
            if (nf > 0.02f) {
                glowDisc(cv, mx, my, 30f * sc * 1.3f, c(0xFFF5F7FF), h * 0.18f, (255 * nf).toInt())
                p.color = col(c(0xFFCBD3E8), (150 * nf).toInt())
                cv.drawCircle(mx - 8f * sc, my - 6f * sc, 6f * sc, p); cv.drawCircle(mx + 10f * sc, my + 8f * sc, 8f * sc, p)
                if (!sunUp) { rx = mx; rI = nf; rc = c(0xFFEAF0FF) }
            }
        }
        if (nf < 0.8f) for (k in 0..2) cloud(cv, ((t * (6 + k * 3) * sc + k * w * 0.4f) % (w + 500f)) - 250f, h * (0.1f + 0.12f * k), 150f * sc, ((1f - nf) * 150).toInt())
        // ville
        val bc = lerp(c(0xFF3C4B66), c(0xFF0B1022), nf)
        for (b in blds) {
            p.color = bc; cv.drawRect(b.x, hor - b.h, b.x + b.w, hor, p)
            val cw = b.w / b.cols; val rh = b.h / b.rows
            for (r in 0 until b.rows) for (cI in 0 until b.cols) {
                val wx = b.x + cI * cw + cw * 0.28f; val wy = hor - b.h + r * rh + rh * 0.25f
                if (b.lit[r * b.cols + cI] && nf > 0.05f) { p.color = col(WIN, (255 * nf).toInt()); cv.drawRect(wx, wy, wx + cw * 0.44f, wy + rh * 0.5f, p) }
                else if (nf < 0.9f) { p.color = col(c(0xFFBFD9F2), (70 * (1f - nf)).toInt()); cv.drawRect(wx, wy, wx + cw * 0.44f, wy + rh * 0.5f, p) }
            }
        }
        // mer
        grad(cv, lerp(bot, c(0xFF0E5E8A), 0.4f), lerp(c(0xFF0B7FB0), c(0xFF031528), nf), hor, seaEnd)
        p.style = Paint.Style.STROKE; p.strokeWidth = 2f * sc; p.color = col(Color.WHITE, (45 * (1f - nf) + 18).toInt())
        for (k in 1..6) {
            val y0 = hor + k * (seaEnd - hor) / 7f; path.reset(); path.moveTo(0f, y0); var x = 0f
            while (x <= w) { path.lineTo(x, y0 + sin(x * 0.02f * (1 + k * 0.1f) + t * 1.2f + k) * 3f * sc * k * 0.5f); x += 14f }
            cv.drawPath(path, p)
        }
        p.style = Paint.Style.FILL
        if (rx >= 0f && rI > 0f) for (k in 0 until 40) { // reflet du soleil / de la lune
            val y = hor + 6f + k * (seaEnd - hor) / 40f; val spread = (k + 2) * 3f * sc
            val lx = rx + sin(t * 2f + k * 0.7f) * spread; val len = (10 + k * 1.5f) * sc
            p.color = col(rc, (rI * (1f - k / 40f) * 210 * (0.5f + 0.5f * sin(t * 3f + k))).toInt())
            cv.drawRect(lx - len, y, lx + len, y + 2.5f * sc, p)
        }
        if (nf > 0.05f) for (b in blds) { // lumières de la ville qui se reflètent dans l'eau
            val cw = b.w / b.cols; val rh = b.h / b.rows
            for (r in 0 until b.rows) for (cI in 0 until b.cols) if (b.lit[r * b.cols + cI]) {
                val wy = hor - b.h + r * rh + rh * 0.25f; val ry = hor + (hor - wy) * 0.8f
                if (ry < seaEnd) {
                    val wob = sin(t * 2f + wy * 0.05f) * 3f * sc; val wx = b.x + cI * cw + cw * 0.28f + wob
                    p.color = col(WIN, (120 * nf * (1f - (ry - hor) / (seaEnd - hor))).toInt()); cv.drawRect(wx, ry, wx + cw * 0.44f, ry + rh * 0.4f, p)
                }
            }
        }
        if (nf < 0.6f) { // petit voilier
            val bxp = ((t * 6f * sc) % (w + 200f)) - 100f; val byp = hor + 24f * sc + sin(t * 1.5f) * 3f
            p.color = c(0xFF4E342E); path.reset(); path.moveTo(bxp - 16f * sc, byp); path.lineTo(bxp + 16f * sc, byp); path.lineTo(bxp + 10f * sc, byp + 7f * sc); path.lineTo(bxp - 10f * sc, byp + 7f * sc); path.close(); cv.drawPath(path, p)
            p.color = Color.WHITE; path.reset(); path.moveTo(bxp, byp - 26f * sc); path.lineTo(bxp + 13f * sc, byp - 2f * sc); path.lineTo(bxp, byp - 2f * sc); path.close(); cv.drawPath(path, p)
        }
        // plage
        path.reset(); path.moveTo(0f, h.toFloat()); var x = 0f
        while (x <= w + 10) { path.lineTo(x, h * 0.88f + sin(x * 0.01f + t * 0.7f) * 6f * sc); x += 10f }
        path.lineTo(w + 10f, h.toFloat()); path.close()
        p.color = lerp(c(0xFFF2D49B), c(0xFF3A3328), nf); cv.drawPath(path, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 4f * sc; p.color = col(Color.WHITE, (170 * (1f - nf * 0.6f)).toInt())
        path.reset(); x = 0f
        while (x <= w + 10) { val yy = h * 0.88f + sin(x * 0.01f + t * 0.7f) * 6f * sc; if (x == 0f) path.moveTo(x, yy) else path.lineTo(x, yy); x += 10f }
        cv.drawPath(path, p); p.style = Paint.Style.FILL
    }
}
