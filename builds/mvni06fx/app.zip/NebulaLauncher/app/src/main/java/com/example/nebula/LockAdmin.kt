package com.example.nebula

import android.app.admin.DeviceAdminReceiver

/** Permet de verrouiller l'écran (double-tap) avec une simple fenêtre « Activer », sans passer par les réglages d'accessibilité. */
class NebulaAdmin : DeviceAdminReceiver()
