package com.example.nebula

import android.graphics.*
import java.util.Calendar
import kotlin.math.*
import kotlin.random.Random

private const val TAU = 6.2831855f
private fun hx(v: Long) = v.toInt()
private fun withA(c: Int, a: Int) = (c and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)
private fun mix(a: Int, b: Int, f: Float): Int {
    val k = f.coerceIn(0f, 1f)
    return Color.argb(255, (Color.red(a) + (Color.red(b) - Color.red(a)) * k).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * k).toInt(), (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).toInt())
}
private fun sstep(a: Float, b: Float, x: Float): Float { val k = ((x - a) / (b - a)).coerceIn(0f, 1f); return k * k * (3f - 2f * k) }
private fun hash2(x: Int, y: Int): Float {
    var n = x * 374761393 + y * 668265263
    n = (n xor (n ushr 13)) * 1274126177
    n = n xor (n ushr 16)
    return (n and 0xFFFFFF) / 16777215f
}
private fun vnoise(x: Float, y: Float): Float {
    val xi = floor(x).toInt(); val yi = floor(y).toInt(); val xf = x - xi; val yf = y - yi
    val u = xf * xf * (3f - 2f * xf); val v = yf * yf * (3f - 2f * yf)
    val a = hash2(xi, yi); val b = hash2(xi + 1, yi); val c = hash2(xi, yi + 1); val d = hash2(xi + 1, yi + 1)
    return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v
}
private fun fbm(x: Float, y: Float, oct: Int = 4): Float {
    var s = 0f; var amp = 0.5f; var f = 1f; var norm = 0f
    repeat(oct) { s += vnoise(x * f, y * f) * amp; norm += amp; amp *= 0.5f; f *= 2f }
    return s / norm
}
private fun gauss(r: Random) = (r.nextFloat() + r.nextFloat() + r.nextFloat() - 1.5f) * 1.15f

/** Flou "boîte" pondéré par l'alpha, pour fabriquer les sprites hors-focus (profondeur de champ). */
private fun blurred(src: Bitmap, r: Int): Bitmap {
    val w = src.width; val h = src.height
    val px = IntArray(w * h); src.getPixels(px, 0, w, 0, 0, w, h)
    var ch = Array(4) { FloatArray(w * h) }
    for (i in px.indices) {
        val a = Color.alpha(px[i]) / 255f
        ch[0][i] = a; ch[1][i] = Color.red(px[i]) / 255f * a; ch[2][i] = Color.green(px[i]) / 255f * a; ch[3][i] = Color.blue(px[i]) / 255f * a
    }
    fun pass(a: FloatArray, horiz: Boolean): FloatArray {
        val o = FloatArray(a.size); val n = (2 * r + 1).toFloat()
        for (y in 0 until h) for (x in 0 until w) {
            var s = 0f
            for (k in -r..r) {
                val xx = if (horiz) x + k else x; val yy = if (horiz) y else y + k
                if (xx in 0 until w && yy in 0 until h) s += a[yy * w + xx]
            }
            o[y * w + x] = s / n
        }
        return o
    }
    ch = Array(4) { pass(pass(pass(ch[it], true), false), true) }
    val out = IntArray(w * h)
    for (i in out.indices) {
        val a = ch[0][i].coerceIn(0f, 1f)
        out[i] = if (a < 0.003f) 0 else Color.argb((a * 255).toInt(), (ch[1][i] / a * 255).toInt().coerceIn(0, 255),
            (ch[2][i] / a * 255).toInt().coerceIn(0, 255), (ch[3][i] / a * 255).toInt().coerceIn(0, 255))
    }
    return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
}

/**
 * Scènes "photo" : tout est rendu en code mais avec de vrais effets de lumière
 * (halo, rayons, éblouissement, profondeur de champ, texture de lune calculée, Voie lactée, écume…).
 * 8 printemps · 9 été · 10 automne · 11 hiver · 13 fleur qui éclot · 14 plage (heure réelle) · 15 nuit & vraie lune
 */
class PhotoScenes {
    private class Item(val x: Float, val y: Float, val z: Float, val ph: Float, val s: Float, val k: Int, val col: Int = 0)

    private var w = 0; private var h = 0; private var sc = 1f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val path = Path(); private val rect = RectF()
    private val screen = PorterDuffXfermode(PorterDuff.Mode.SCREEN)
    private val cal = Calendar.getInstance()
    private var rnd = Random(1)
    private var built = -1
    private var back: Bitmap? = null
    private var milky: Bitmap? = null
    private val sprites = HashMap<String, Bitmap>()
    private val filters = HashMap<Int, PorterDuffColorFilter>()
    private var vig: RadialGradient? = null
    private var sandShader: BitmapShader? = null
    private var moonIllum = 1f
    private var blossoms = ArrayList<Item>()
    private var meadow = ArrayList<Item>()
    private var drops = ArrayList<Item>()
    private var bok = ArrayList<Item>()
    private var stars = ArrayList<Item>()

    fun resize(w: Int, h: Int) {
        this.w = w; this.h = h; sc = min(w, h) / 720f
        back?.recycle(); back = null; milky?.recycle(); milky = null; built = -1; vig = null
    }

    fun draw(cv: Canvas, style: Int, t: Float, tx: Float, ty: Float) {
        if (w == 0 || h == 0) return
        if (built != style) build(style)
        p.shader = null; p.xfermode = null; p.colorFilter = null; p.style = Paint.Style.FILL
        val b = back
        if (b != null) cv.drawBitmap(b, 0f, 0f, null)
        else if (style != 14) { p.color = hx(0xFF2A3A4A); cv.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p) }
        when (style) {
            8 -> spring(cv, t, tx); 9 -> summer(cv, t, tx); 10 -> autumn(cv, t, tx); 11 -> winter(cv, t, tx)
            13 -> garden(cv, t); 14 -> beach(cv, t, tx); 15 -> night(cv, t)
        }
        vignette(cv)
    }

    // ═════════════════════════ construction ═════════════════════════
    private fun build(style: Int) {
        back?.recycle(); back = null; milky?.recycle(); milky = null; built = style
        rnd = Random(100 + style)
        blossoms = ArrayList(); meadow = ArrayList(); drops = ArrayList(); bok = ArrayList(); stars = ArrayList()
        if (w <= 0 || h <= 0) return
        try {
            if (style != 14) {
                val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); val c = Canvas(b)
                when (style) { 8 -> backSpring(c); 9 -> backSummer(c); 10 -> backAutumn(c); 11 -> backWinter(c); 13 -> backGarden(c); 15 -> backNight(c) }
                back = b
            }
            if (style == 14 || style == 15) milky = makeMilky(w, (h * (if (style == 15) 0.72f else 0.5f)).toInt())
        } catch (e: OutOfMemoryError) { back = null; milky = null }
        populate(style)
    }

    private fun need(key: String, f: () -> Bitmap) { if (!sprites.containsKey(key)) sprites[key] = f() }

    private fun populate(style: Int) {
        when (style) {
            8 -> {
                need("blossom") { makeBlossom(192, hx(0xFFE98FA9), hx(0xFFFFF3F6)) }
                need("blossomB") { blurred(makeBlossom(192, hx(0xFFE98FA9), hx(0xFFFFF3F6)), 7) }
                need("petal") { makePetal(64, hx(0xFFF2A3B8), hx(0xFFFFF1F4)) }
                need("petalB") { blurred(makePetal(64, hx(0xFFF2A3B8), hx(0xFFFFF1F4)), 4) }
                need("daisy") { makeDaisy(160) }; need("daisyB") { blurred(makeDaisy(160), 5) }; need("poppy") { makePoppy(160) }
                need("bokeh") { makeBokeh(96) }; need("cloud0") { makeCloud(3) }; need("cloud1") { makeCloud(8) }
                for (b in 0..1) repeat(34) { blossoms += Item(0.04f + rnd.nextFloat() * 0.96f, rnd.nextFloat() - .5f, 0.6f + rnd.nextFloat() * 0.8f, rnd.nextFloat() * TAU, rnd.nextFloat() - .5f, b) }
                repeat(16) { bok += Item(rnd.nextFloat() * w, rnd.nextFloat() * h * 0.7f, rnd.nextFloat(), rnd.nextFloat() * TAU, (20f + rnd.nextFloat() * 70f) * sc, rnd.nextInt(3)) }
                grassAndFlowers(0.80f, 320, 22, false)
                repeat(46) { drops += Item(rnd.nextFloat() * w, rnd.nextFloat() * h, rnd.nextFloat(), rnd.nextFloat() * TAU, 28f + rnd.nextFloat() * 40f, 0) }
            }
            9 -> {
                need("sunflower") { makeSunflower(256) }; need("sunflowerB") { blurred(makeSunflower(256), 9) }
                for (i in 0..4) need("cloud$i") { makeCloud(20 + i * 7) }
                grassAndFlowers(0.70f, 0, 0, true)
            }
            10 -> {
                for (i in 0..2) { val col = intArrayOf(hx(0xFFD2481E), hx(0xFFF2A81D), hx(0xFFB5381C))[i]
                    need("leaf$i") { makeLeaf(96, col) }; need("leaf${i}B") { blurred(makeLeaf(96, col), 5) } }
                need("mist") { makeMist() }
                repeat(40) { drops += Item(rnd.nextFloat() * w, rnd.nextFloat() * h, rnd.nextFloat(), rnd.nextFloat() * TAU, 30f + rnd.nextFloat() * 50f, rnd.nextInt(3)) }
            }
            11 -> {
                need("softdot") { makeSoftDot(64) }
                repeat(110) { drops += Item(rnd.nextFloat() * w, rnd.nextFloat() * h, rnd.nextFloat(), rnd.nextFloat() * TAU, 25f + rnd.nextFloat() * 55f, 0) }
                repeat(60) { stars += Item(rnd.nextFloat() * w, h * (0.72f + 0.2f * rnd.nextFloat()), rnd.nextFloat(), rnd.nextFloat() * TAU, 1f, 0) }
            }
            13 -> {
                val deep = intArrayOf(hx(0xFFD81B60), hx(0xFFC9C9C9), hx(0xFFE65100), hx(0xFF5E35B1), hx(0xFFB71C1C))
                val tip = intArrayOf(hx(0xFFFF9EC0), hx(0xFFFFFFFF), hx(0xFFFFB74D), hx(0xFFC9A7FF), hx(0xFFFF7A7A))
                for (i in 0..4) need("bloom$i") { makeBloom(200, deep[i], tip[i]) }
                need("leafG") { makeGardenLeaf() }
            }
            14 -> {
                need("cloud0") { makeCloud(5) }; need("cloud1") { makeCloud(12) }; need("cloud2") { makeCloud(31) }
                sprites["moon"]?.recycle(); sprites["moon"] = makeMoon(224, moonPhase())
                need("sand") { makeSand(256) }
                sandShader = BitmapShader(sprites["sand"]!!, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
                repeat(150) { stars += Item(rnd.nextFloat() * w, rnd.nextFloat() * h * 0.5f, rnd.nextFloat(), rnd.nextFloat() * TAU, 0.6f + rnd.nextFloat() * 1.4f, rnd.nextInt(4)) }
                repeat(16) { bok += Item(rnd.nextFloat() * 0.5f * w, 0f, rnd.nextFloat(), rnd.nextFloat() * TAU, 1f, 0) }
            }
            15 -> {
                sprites["moon"]?.recycle(); sprites["moon"] = makeMoon(224, moonPhase())
                repeat(240) { stars += Item(rnd.nextFloat() * w, rnd.nextFloat() * h * 0.68f, 0.15f + 0.85f * rnd.nextFloat().pow(2.2f), rnd.nextFloat() * TAU, 0.6f + rnd.nextFloat() * 1.3f, rnd.nextInt(4)) }
            }
        }
    }

    private fun grassAndFlowers(top: Float, blades: Int, flowers: Int, sun: Boolean) {
        val span = 1f - top
        if (sun) {
            repeat(220) {
                val y = h * (top + span * rnd.nextFloat()); val z = (y - h * top) / (h * span)
                val col = mix(mix(hx(0xFF9DA83A), hx(0xFFE2CF6A), rnd.nextFloat()), hx(0xFFC9DDB0), (1f - z) * 0.4f)
                meadow += Item(rnd.nextFloat() * w, y, z, rnd.nextFloat() * TAU, h * (0.05f + 0.10f * z) * (0.6f + 0.6f * rnd.nextFloat()), 0, col)
            }
            repeat(15) {
                val y = h * (top + 0.02f + (span - 0.02f) * rnd.nextFloat().pow(0.8f)); val z = (y - h * top) / (h * span)
                meadow += Item(rnd.nextFloat() * w, y, z, rnd.nextFloat() * TAU, h * (0.10f + 0.20f * z), 3)
            }
        } else {
            repeat(blades) {
                val y = h * (top + span * rnd.nextFloat()); val z = (y - h * top) / (h * span)
                val col = mix(mix(hx(0xFF2E6B2C), hx(0xFF8FD14F), rnd.nextFloat()), hx(0xFFBFE3B4), (1f - z) * 0.45f)
                meadow += Item(rnd.nextFloat() * w, y, z, rnd.nextFloat() * TAU, h * (0.045f + 0.11f * (0.5f + 0.5f * z)) * (0.6f + 0.6f * rnd.nextFloat()), 0, col)
            }
            repeat(flowers) {
                val y = h * (top + 0.04f + (span - 0.06f) * rnd.nextFloat()); val z = (y - h * top) / (h * span)
                meadow += Item(rnd.nextFloat() * w, y, z, rnd.nextFloat() * TAU, h * (0.08f + 0.16f * z), if (rnd.nextFloat() < 0.6f) 1 else 2)
            }
        }
        meadow.sortBy { it.y }
    }

    // ═════════════════════════ sprites ═════════════════════════
    private fun newBmp(s: Int) = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
    private fun petalPath(R: Float) = Path().apply {
        moveTo(0f, 0f)
        cubicTo(-0.30f * R, -0.22f * R, -0.50f * R, -0.78f * R, -0.14f * R, -0.99f * R)
        lineTo(0f, -0.86f * R)
        lineTo(0.14f * R, -0.99f * R)
        cubicTo(0.50f * R, -0.78f * R, 0.30f * R, -0.22f * R, 0f, 0f)
        close()
    }

    private fun makeBlossom(S: Int, inner: Int, outer: Int): Bitmap {
        val bmp = newBmp(S); val c = Canvas(bmp); val pp = Paint(Paint.ANTI_ALIAS_FLAG); val R = S * 0.48f
        c.translate(S / 2f, S / 2f); val pt = petalPath(R)
        for (i in 0 until 5) {
            c.save(); c.rotate(i * 72f + 8f)
            pp.style = Paint.Style.FILL
            pp.shader = RadialGradient(0f, 0f, R, intArrayOf(inner, mix(inner, outer, .45f), outer), floatArrayOf(0f, .5f, 1f), Shader.TileMode.CLAMP)
            c.drawPath(pt, pp); pp.shader = null
            pp.style = Paint.Style.STROKE; pp.strokeWidth = S * 0.006f; pp.color = withA(inner, 80)
            c.drawLine(0f, 0f, 0f, -0.8f * R, pp); c.drawLine(0f, -0.15f * R, -0.12f * R, -0.65f * R, pp); c.drawLine(0f, -0.15f * R, 0.12f * R, -0.65f * R, pp)
            pp.strokeWidth = S * 0.008f; pp.color = withA(Color.WHITE, 70); c.drawPath(pt, pp)
            c.restore()
        }
        pp.style = Paint.Style.FILL
        pp.shader = RadialGradient(0f, 0f, R * 0.24f, intArrayOf(hx(0xFFB5304F), hx(0xFFE4708E), withA(hx(0xFFE4708E), 0)), floatArrayOf(0f, .6f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(0f, 0f, R * 0.24f, pp); pp.shader = null
        val sr = Random(5)
        for (i in 0 until 14) {
            val a = sr.nextFloat() * TAU; val l = R * (0.28f + sr.nextFloat() * 0.22f)
            pp.style = Paint.Style.STROKE; pp.strokeWidth = S * 0.007f; pp.color = withA(hx(0xFFE57394), 200); c.drawLine(0f, 0f, cos(a) * l, sin(a) * l, pp)
            pp.style = Paint.Style.FILL; pp.color = hx(0xFFFFD54F); c.drawCircle(cos(a) * l, sin(a) * l, S * 0.011f, pp)
        }
        return bmp
    }

    private fun makePetal(S: Int, inner: Int, outer: Int): Bitmap {
        val bmp = newBmp(S); val c = Canvas(bmp); val pp = Paint(Paint.ANTI_ALIAS_FLAG); val R = S * 0.48f
        c.translate(S / 2f, S / 2f + R * 0.5f)
        pp.shader = RadialGradient(0f, 0f, R, intArrayOf(inner, outer), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
        c.drawPath(petalPath(R), pp); return bmp
    }

    private fun makeDaisy(S: Int): Bitmap {
        val bmp = newBmp(S); val c = Canvas(bmp); val pp = Paint(Paint.ANTI_ALIAS_FLAG); val R = S * 0.48f
        c.translate(S / 2f, S / 2f)
        for (ring in 0..1) for (i in 0 until 18) {
            c.save(); c.rotate(i * 20f + ring * 10f)
            val len = R * (0.98f - 0.10f * ring)
            pp.shader = LinearGradient(0f, -R * 0.2f, 0f, -len, hx(0xFFE4E2D2), Color.WHITE, Shader.TileMode.CLAMP)
            rect.set(-R * 0.075f, -len, R * 0.075f, -R * 0.18f); c.drawOval(rect, pp); c.restore()
        }
        pp.shader = RadialGradient(-R * 0.05f, -R * 0.05f, R * 0.26f, hx(0xFFFFEB3B), hx(0xFFE8960C), Shader.TileMode.CLAMP)
        c.drawCircle(0f, 0f, R * 0.24f, pp); pp.shader = null
        val sr = Random(9); pp.color = withA(hx(0xFF9A5A00), 150)
        for (i in 0 until 40) { val a = sr.nextFloat() * TAU; val d = sqrt(sr.nextFloat()) * R * 0.22f; c.drawCircle(cos(a) * d, sin(a) * d, S * 0.007f, pp) }
        return bmp
    }

    private fun makePoppy(S: Int): Bitmap {
        val bmp = newBmp(S); val c = Canvas(bmp); val pp = Paint(Paint.ANTI_ALIAS_FLAG); val R = S * 0.48f
        c.translate(S / 2f, S / 2f)
        for (i in 0 until 4) {
            c.save(); c.rotate(i * 90f + 14f)
            pp.shader = RadialGradient(0f, 0f, R, intArrayOf(hx(0xFF7E0C0C), hx(0xFFD32F2F), hx(0xFFF0605C)), floatArrayOf(0f, .55f, 1f), Shader.TileMode.CLAMP)
            rect.set(-R * 0.55f, -R, R * 0.55f, -R * 0.02f); c.drawOval(rect, pp); pp.shader = null
            pp.style = Paint.Style.STROKE; pp.strokeWidth = S * 0.004f; pp.color = withA(hx(0xFF6A0A0A), 90)
            for (k in -2..2) c.drawLine(0f, -R * 0.1f, k * R * 0.14f, -R * 0.88f, pp)
            pp.style = Paint.Style.FILL; c.restore()
        }
        pp.color = hx(0xFF1B1B1B); c.drawCircle(0f, 0f, R * 0.15f, pp)
        val sr = Random(4)
        for (i in 0 until 22) { val a = i * TAU / 22f; pp.color = hx(0xFF2B2B2B); pp.style = Paint.Style.STROKE; pp.strokeWidth = S * 0.005f
            c.drawLine(cos(a) * R * 0.12f, sin(a) * R * 0.12f, cos(a) * R * 0.27f, sin(a) * R * 0.27f, pp)
            pp.style = Paint.Style.FILL; pp.color = withA(hx(0xFFC9B27A), 220); c.drawCircle(cos(a) * R * 0.27f, sin(a) * R * 0.27f, S * 0.008f * (0.8f + sr.nextFloat()), pp) }
        return bmp
    }

    private fun makeSunflower(S: Int): Bitmap {
        val bmp = newBmp(S); val c = Canvas(bmp); val pp = Paint(Paint.ANTI_ALIAS_FLAG); val R = S * 0.49f
        c.translate(S / 2f, S / 2f)
        for (ring in 0..1) for (i in 0 until 26) {
            c.save(); c.rotate(i * (360f / 26f) + ring * 6.9f)
            val l = R * (1f - 0.12f * ring)
            pp.shader = LinearGradient(0f, -R * 0.3f, 0f, -l, if (ring == 0) hx(0xFFD98A00) else hx(0xFFF2AE0B), if (ring == 0) hx(0xFFFFD21F) else hx(0xFFFFE066), Shader.TileMode.CLAMP)
            path.reset(); path.moveTo(0f, -R * 0.3f); path.quadTo(-R * 0.17f, -R * 0.68f, 0f, -l); path.quadTo(R * 0.17f, -R * 0.68f, 0f, -R * 0.3f)
            c.drawPath(path, pp)
            pp.shader = null; pp.style = Paint.Style.STROKE; pp.strokeWidth = S * 0.0035f; pp.color = withA(hx(0xFF9A5A00), 90); c.drawLine(0f, -R * 0.32f, 0f, -l * 0.9f, pp); pp.style = Paint.Style.FILL
            c.restore()
        }
        val dr = R * 0.40f
        pp.shader = RadialGradient(0f, 0f, dr, hx(0xFF5A3A12), hx(0xFF24150A), Shader.TileMode.CLAMP); c.drawCircle(0f, 0f, dr, pp); pp.shader = null
        val n = 560
        for (i in 0 until n) {
            val f = i / n.toFloat(); val rr = dr * sqrt(f); val a = i * 2.3999631f
            pp.color = if (f > 0.84f) mix(hx(0xFF7A4A12), hx(0xFFC27A1A), hash2(i, 3)) else mix(hx(0xFF2E1B0A), hx(0xFF7A5020), hash2(i, 7) * (0.4f + f))
            c.drawCircle(cos(a) * rr, sin(a) * rr, R * 0.026f * (0.55f + 0.9f * f), pp)
        }
        pp.shader = RadialGradient(-dr * 0.35f, -dr * 0.4f, dr * 0.9f, withA(Color.WHITE, 46), withA(Color.WHITE, 0), Shader.TileMode.CLAMP); c.drawCircle(0f, 0f, dr, pp)
        return bmp
    }

    private fun makeLeaf(S: Int, base: Int): Bitmap {
        val bmp = newBmp(S); val c = Canvas(bmp); val pp = Paint(Paint.ANTI_ALIAS_FLAG); val R = S * 0.44f
        c.translate(S / 2f, S * 0.54f)
        path.reset(); var first = true
        var d = -135
        while (d <= 135) {
            val th = d * 0.0174533f; val lobe = abs(cos(2.5f * th)).pow(0.7f)
            val r = R * (0.36f + 0.64f * lobe) * (1f - 0.32f * abs(d) / 135f)
            val x = sin(th) * r; val y = -cos(th) * r
            if (first) { path.moveTo(x, y); first = false } else path.lineTo(x, y); d += 3
        }
        path.lineTo(R * 0.07f, R * 0.28f); path.lineTo(-R * 0.07f, R * 0.28f); path.close()
        pp.shader = LinearGradient(-R, -R, R, R * 0.6f, mix(base, Color.WHITE, 0.18f), mix(base, Color.BLACK, 0.35f), Shader.TileMode.CLAMP)
        c.drawPath(path, pp); pp.shader = null
        pp.style = Paint.Style.STROKE; pp.strokeCap = Paint.Cap.ROUND; pp.strokeWidth = S * 0.012f; pp.color = withA(mix(base, Color.BLACK, 0.6f), 140)
        for (a in intArrayOf(0, -72, 72, -144, 144)) { val th = a * 0.0174533f; c.drawLine(0f, R * 0.25f, sin(th) * R * 0.75f, -cos(th) * R * 0.75f, pp) }
        pp.strokeWidth = S * 0.02f; pp.color = hx(0xFF5A3A22); c.drawLine(0f, R * 0.25f, 0f, R * 0.55f, pp)
        return bmp
    }

    private fun makeCloud(seed: Int): Bitmap {
        val bw = 512; val bh = 256
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888); val c = Canvas(bmp)
        val r = Random(seed); val pp = Paint(Paint.ANTI_ALIAS_FLAG)
        for (i in 0 until 72) {
            val u = r.nextFloat(); val cx = bw * (0.16f + 0.68f * u); val bulge = sin(u * PI.toFloat())
            val rad = bh * (0.10f + 0.20f * bulge * (0.5f + r.nextFloat() * 0.6f))
            val cy = bh * 0.70f - rad * (0.3f + r.nextFloat() * 1.3f) * bulge
            pp.shader = RadialGradient(cx, cy, rad, intArrayOf(withA(Color.WHITE, 125), withA(Color.WHITE, 60), withA(Color.WHITE, 0)), floatArrayOf(0f, .55f, 1f), Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, rad, pp)
        }
        pp.shader = LinearGradient(0f, bh * 0.22f, 0f, bh * 0.78f, withA(Color.WHITE, 0), withA(hx(0xFF8FA3BF), 160), Shader.TileMode.CLAMP)
        pp.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP); c.drawRect(0f, 0f, bw.toFloat(), bh.toFloat(), pp)
        return bmp
    }

    private fun makeMist(): Bitmap {
        val bw = 512; val bh = 128
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888); val c = Canvas(bmp); val pp = Paint(Paint.ANTI_ALIAS_FLAG); val r = Random(2)
        for (i in 0 until 40) {
            val cx = r.nextFloat() * bw; val cy = bh * (0.5f + gauss(r) * 0.16f); val rad = bh * (0.25f + 0.3f * r.nextFloat())
            pp.shader = RadialGradient(cx, cy, rad, withA(Color.WHITE, 46), withA(Color.WHITE, 0), Shader.TileMode.CLAMP); c.drawCircle(cx, cy, rad, pp)
        }
        return bmp
    }

    private fun makeBokeh(S: Int): Bitmap {
        val bmp = newBmp(S); val c = Canvas(bmp); val pp = Paint(Paint.ANTI_ALIAS_FLAG)
        pp.shader = RadialGradient(S / 2f, S / 2f, S / 2f, intArrayOf(withA(Color.WHITE, 60), withA(Color.WHITE, 80), withA(Color.WHITE, 170), withA(Color.WHITE, 0)),
            floatArrayOf(0f, .8f, .93f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(S / 2f, S / 2f, S / 2f, pp); return bmp
    }

    private fun makeSoftDot(S: Int): Bitmap {
        val bmp = newBmp(S); val c = Canvas(bmp); val pp = Paint(Paint.ANTI_ALIAS_FLAG)
        pp.shader = RadialGradient(S / 2f, S / 2f, S / 2f, intArrayOf(Color.WHITE, withA(Color.WHITE, 150), withA(Color.WHITE, 0)), floatArrayOf(0f, .4f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(S / 2f, S / 2f, S / 2f, pp); return bmp
    }

    private fun makeSand(S: Int): Bitmap {
        val px = IntArray(S * S)
        for (y in 0 until S) for (x in 0 until S) {
            val g = hash2(x, y) * 0.6f + fbm(x * 0.09f, y * 0.09f, 3) * 0.4f
            val v = (g * 255).toInt().coerceIn(0, 255)
            px[y * S + x] = Color.argb(255, v, (v * 0.94f).toInt(), (v * 0.82f).toInt())
        }
        return Bitmap.createBitmap(px, S, S, Bitmap.Config.ARGB_8888)
    }

    private fun makeBloom(S: Int, deep: Int, tip: Int): Bitmap {
        val bmp = newBmp(S); val c = Canvas(bmp); val pp = Paint(Paint.ANTI_ALIAS_FLAG); val R = S * 0.49f
        c.translate(S / 2f, S / 2f)
        val counts = intArrayOf(13, 11, 9); val lens = floatArrayOf(1f, 0.82f, 0.62f)
        for (ring in 0..2) for (i in 0 until counts[ring]) {
            c.save(); c.rotate(i * 360f / counts[ring] + ring * 13f)
            val l = R * lens[ring]
            pp.style = Paint.Style.FILL
            pp.shader = LinearGradient(0f, -R * 0.1f, 0f, -l, mix(deep, Color.BLACK, 0.12f * ring), mix(tip, deep, 0.1f * ring), Shader.TileMode.CLAMP)
            path.reset(); path.moveTo(0f, -R * 0.08f); path.cubicTo(-R * 0.26f, -l * 0.35f, -R * 0.2f, -l * 0.92f, 0f, -l); path.cubicTo(R * 0.2f, -l * 0.92f, R * 0.26f, -l * 0.35f, 0f, -R * 0.08f)
            c.drawPath(path, pp); pp.shader = null
            pp.style = Paint.Style.STROKE; pp.strokeWidth = S * 0.004f; pp.color = withA(deep, 80); c.drawLine(0f, -R * 0.1f, 0f, -l * 0.9f, pp)
            c.restore()
        }
        pp.style = Paint.Style.FILL
        val dr = R * 0.2f
        pp.shader = RadialGradient(0f, 0f, dr, hx(0xFFE8B21A), hx(0xFF7A4A08), Shader.TileMode.CLAMP); c.drawCircle(0f, 0f, dr, pp); pp.shader = null
        for (i in 0 until 90) { val f = i / 90f; val rr = dr * 0.95f * sqrt(f); val a = i * 2.39996f
            pp.color = mix(hx(0xFF5A3306), hx(0xFFF2C94C), hash2(i, 1)); c.drawCircle(cos(a) * rr, sin(a) * rr, S * 0.006f, pp) }
        return bmp
    }

    private fun makeGardenLeaf(): Bitmap {
        val bw = 160; val bh = 80
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888); val c = Canvas(bmp); val pp = Paint(Paint.ANTI_ALIAS_FLAG)
        path.reset(); path.moveTo(0f, bh / 2f); path.cubicTo(30f, 0f, 110f, 4f, bw.toFloat(), bh / 2f); path.cubicTo(110f, bh - 4f, 30f, bh.toFloat(), 0f, bh / 2f); path.close()
        pp.shader = LinearGradient(0f, 0f, 0f, bh.toFloat(), hx(0xFF7BD06E), hx(0xFF2F8A3F), Shader.TileMode.CLAMP); c.drawPath(path, pp); pp.shader = null
        pp.style = Paint.Style.STROKE; pp.strokeWidth = 2f; pp.color = withA(hx(0xFFD7F5C4), 190); c.drawLine(2f, bh / 2f, bw - 8f, bh / 2f, pp)
        pp.strokeWidth = 1.2f; pp.color = withA(hx(0xFF1F6A2E), 110)
        for (k in 1..5) { val x = k * 24f; c.drawLine(x, bh / 2f, x + 18f, 10f, pp); c.drawLine(x, bh / 2f, x + 18f, bh - 10f, pp) }
        return bmp
    }

    private fun moonPhase(): Float {
        val days = (System.currentTimeMillis() - 947182440000L) / 86400000.0
        val ph = (days / 29.530588853) % 1.0
        return (if (ph < 0) ph + 1.0 else ph).toFloat()
    }

    /** Vraie lune : relief et cratères calculés, éclairée selon la phase réelle du jour. */
    private fun makeMoon(D: Int, phase: Float): Bitmap {
        val px = IntArray(D * D)
        val a = TAU * phase; val lx = sin(a); val lz = -cos(a)
        moonIllum = 0.5f - 0.5f * cos(a)
        val cn = 70; val cr = Random(77)
        val cxs = FloatArray(cn); val cys = FloatArray(cn); val crs = FloatArray(cn)
        for (i in 0 until cn) { val rr = sqrt(cr.nextFloat()) * 0.92f; val th = cr.nextFloat() * TAU; cxs[i] = cos(th) * rr; cys[i] = sin(th) * rr; crs[i] = 0.02f + 0.075f * cr.nextFloat() * cr.nextFloat() }
        for (y in 0 until D) for (x in 0 until D) {
            val nx = (x + 0.5f) / D * 2f - 1f; val ny = (y + 0.5f) / D * 2f - 1f; val rr2 = nx * nx + ny * ny
            if (rr2 >= 1f) continue
            val nz = sqrt(1f - rr2)
            val lit = max(0f, nx * lx + nz * lz)
            var alb = 0.80f + 0.40f * (fbm(nx * 6f + 3f, ny * 6f + 9f, 4) - 0.5f)
            alb *= 1f - 0.42f * sstep(0.52f, 0.62f, fbm(nx * 1.7f + 5.2f, ny * 1.7f + 1.3f, 3))
            for (i in 0 until cn) {
                val dx = nx - cxs[i]; val dy = ny - cys[i]; val d = sqrt(dx * dx + dy * dy) / crs[i]
                if (d < 1.4f) { alb += 0.11f * exp(-(d - 1f) * (d - 1f) * 14f); if (d < 1f) alb -= 0.10f * (1f - d) }
            }
            val shade = (0.03f + 0.97f * lit.pow(0.85f)) * (0.84f + 0.16f * nz)
            val v = alb * shade * 255f
            val edge = sstep(1f, 0.975f, sqrt(rr2))
            px[y * D + x] = Color.argb((edge * 255).toInt(), v.toInt().coerceIn(0, 255), (v * 0.965f).toInt().coerceIn(0, 255), (v * 0.90f + 9f * (1f - lit)).toInt().coerceIn(0, 255))
        }
        return Bitmap.createBitmap(px, D, D, Bitmap.Config.ARGB_8888)
    }

    private fun makeMilky(mw: Int, mh: Int): Bitmap {
        val bmp = Bitmap.createBitmap(mw, mh, Bitmap.Config.ARGB_8888); val c = Canvas(bmp); val pp = Paint(Paint.ANTI_ALIAS_FLAG); val r = Random(5)
        c.save(); c.rotate(-24f, mw * .5f, mh * .5f)
        val bw = mw * 1.5f
        for (i in 0 until 46) {
            val x = mw * .5f + (r.nextFloat() - .5f) * bw; val y = mh * .5f + gauss(r) * mh * 0.06f; val rad = mw * (0.10f + 0.12f * r.nextFloat())
            val col = if (i % 3 == 0) hx(0xFFFFE0B0) else hx(0xFFB8C8FF)
            pp.shader = RadialGradient(x, y, rad, withA(col, 18), withA(col, 0), Shader.TileMode.CLAMP); c.drawCircle(x, y, rad, pp)
        }
        pp.xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
        for (i in 0 until 14) {
            val x = mw * .5f + (r.nextFloat() - .5f) * bw; val y = mh * .5f + gauss(r) * mh * 0.04f; val rad = mw * (0.04f + 0.06f * r.nextFloat())
            pp.shader = RadialGradient(x, y, rad, withA(Color.BLACK, 46), withA(Color.BLACK, 0), Shader.TileMode.CLAMP); c.drawCircle(x, y, rad, pp)
        }
        pp.xfermode = null; pp.shader = null
        for (i in 0 until 2600) {
            val x = mw * .5f + (r.nextFloat() - .5f) * bw; val y = mh * .5f + gauss(r) * mh * 0.09f
            pp.color = withA(mix(Color.WHITE, hx(0xFFFFE6C0), r.nextFloat()), 40 + r.nextInt(160)); c.drawCircle(x, y, 0.5f + r.nextFloat() * 0.8f, pp)
        }
        c.restore(); return bmp
    }

    // ═════════════════════════ outils de dessin ═════════════════════════
    private fun skyGrad(c: Canvas, cols: IntArray, pos: FloatArray, y1: Float) {
        p.style = Paint.Style.FILL; p.shader = LinearGradient(0f, 0f, 0f, y1, cols, pos, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p); p.shader = null
    }

    private fun ridge(c: Canvas, baseY: Float, amp: Float, freq: Float, seed: Float, color: Int, top: Int = color, rim: Int = 0) {
        path.reset(); path.moveTo(0f, h.toFloat()); var x = 0f
        while (x <= w + 8) { path.lineTo(x, baseY - amp * (fbm(x * freq + seed, seed * 0.7f, 4) - 0.5f) * 2f); x += 6f }
        path.lineTo(w + 8f, h.toFloat()); path.close()
        p.style = Paint.Style.FILL
        if (top != color) p.shader = LinearGradient(0f, baseY - amp, 0f, baseY + amp * 2f, top, color, Shader.TileMode.CLAMP) else p.color = color
        c.drawPath(path, p); p.shader = null
        if (rim != 0) {
            path.reset(); x = 0f
            while (x <= w + 8) { val y = baseY - amp * (fbm(x * freq + seed, seed * 0.7f, 4) - 0.5f) * 2f; if (x == 0f) path.moveTo(x, y) else path.lineTo(x, y); x += 6f }
            p.style = Paint.Style.STROKE; p.strokeWidth = 2f * sc; p.color = rim; c.drawPath(path, p); p.style = Paint.Style.FILL
        }
    }

    private fun spr(cv: Canvas, key: String, cx: Float, cy: Float, size: Float, rot: Float = 0f, alpha: Int = 255, sx: Float = 1f) {
        val b = sprites[key] ?: return
        cv.save(); cv.translate(cx, cy); if (rot != 0f) cv.rotate(rot)
        cv.scale(size / b.width * sx, size / b.width)
        bp.alpha = alpha; cv.drawBitmap(b, -b.width / 2f, -b.height / 2f, bp); bp.alpha = 255; cv.restore()
    }

    private fun vignette(cv: Canvas) {
        var v = vig
        if (v == null) { v = RadialGradient(w / 2f, h / 2f, hypot(w.toFloat(), h.toFloat()) * 0.62f, intArrayOf(0x00000000, 0x00000000, 0x66000000), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP); vig = v }
        p.shader = v; p.style = Paint.Style.FILL; cv.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p); p.shader = null
    }

    /** Soleil : halo large, disque éblouissant, étoile de diffraction. */
    private fun sun(cv: Canvas, x: Float, y: Float, r: Float, warm: Int, power: Float, t: Float) {
        p.xfermode = screen; p.style = Paint.Style.FILL
        p.shader = RadialGradient(x, y, r * 9f, intArrayOf(withA(warm, (150 * power).toInt()), withA(warm, (55 * power).toInt()), withA(warm, 0)), floatArrayOf(0f, .18f, 1f), Shader.TileMode.CLAMP)
        cv.drawCircle(x, y, r * 9f, p)
        p.shader = RadialGradient(x, y, r * 2.2f, intArrayOf(Color.WHITE, withA(mix(Color.WHITE, warm, .5f), 200), withA(warm, 0)), floatArrayOf(0f, .35f, 1f), Shader.TileMode.CLAMP)
        cv.drawCircle(x, y, r * 2.2f, p)
        val l = r * 12f
        p.shader = RadialGradient(x, y, l, withA(Color.WHITE, (80 * power).toInt()), withA(Color.WHITE, 0), Shader.TileMode.CLAMP)
        for (i in 0 until 6) {
            val a = t * 0.02f + i * PI.toFloat() / 3f; val wd = r * 0.09f
            path.reset(); path.moveTo(x - sin(a) * wd, y + cos(a) * wd); path.lineTo(x + cos(a) * l, y + sin(a) * l); path.lineTo(x + sin(a) * wd, y - cos(a) * wd); path.close()
            cv.drawPath(path, p)
        }
        p.shader = null; p.xfermode = null
    }

    /** Faisceaux de lumière à travers l'air. */
    private fun rays(cv: Canvas, x: Float, y: Float, t: Float, power: Float, a0: Float, color: Int) {
        val len = hypot(w.toFloat(), h.toFloat())
        p.xfermode = screen; p.style = Paint.Style.FILL
        p.shader = RadialGradient(x, y, len * 0.9f, withA(color, (70 * power).toInt()), withA(color, 0), Shader.TileMode.CLAMP)
        for (i in 0 until 9) {
            val a = a0 + (i - 4) * 0.16f + sin(t * 0.12f + i * 1.9f) * 0.05f; val wd = 0.035f + 0.02f * sin(t * 0.3f + i)
            path.reset(); path.moveTo(x, y); path.lineTo(x + cos(a - wd) * len, y + sin(a - wd) * len); path.lineTo(x + cos(a + wd) * len, y + sin(a + wd) * len); path.close()
            p.alpha = (140 + 115 * sin(t * 0.35f + i * 2.3f)).toInt().coerceIn(30, 255); cv.drawPath(path, p)
        }
        p.alpha = 255; p.shader = null; p.xfermode = null
    }

    private fun flare(cv: Canvas, sx: Float, sy: Float, power: Float) {
        val cx = w / 2f; val cy = h / 2f; p.xfermode = screen; p.style = Paint.Style.FILL
        val ks = floatArrayOf(0.45f, 0.8f, 1.35f, 1.9f); val rs = floatArrayOf(34f, 20f, 48f, 26f)
        val cs = intArrayOf(hx(0xFFFFC27A), hx(0xFF9FD8FF), hx(0xFFFFE6A0), hx(0xFFB4FFB0))
        for (i in 0..3) {
            val x = sx + (cx - sx) * ks[i]; val y = sy + (cy - sy) * ks[i]; val r = rs[i] * sc
            p.shader = RadialGradient(x, y, r, intArrayOf(withA(cs[i], 10), withA(cs[i], (40 * power).toInt()), withA(cs[i], 0)), floatArrayOf(0f, .72f, 1f), Shader.TileMode.CLAMP)
            cv.drawCircle(x, y, r, p)
        }
        p.shader = null; p.xfermode = null
    }

    private fun cloud(cv: Canvas, key: String, x: Float, y: Float, width: Float, alpha: Int, tint: Int = 0) {
        val b = sprites[key] ?: return
        rect.set(x - width / 2f, y - width / 4f, x + width / 2f, y + width / 4f)
        bp.alpha = alpha; if (tint != 0) bp.colorFilter = PorterDuffColorFilter(tint, PorterDuff.Mode.MULTIPLY)
        cv.drawBitmap(b, null, rect, bp); bp.colorFilter = null; bp.alpha = 255
    }

    private fun bokehDraw(cv: Canvas, t: Float, cols: IntArray) {
        for (b in bok) {
            val x = ((b.x + t * (4f + 6f * b.z) * sc) % (w + 160f * sc)) - 80f * sc; val y = b.y + sin(t * 0.3f + b.ph) * 14f * sc
            val col = cols[b.k % cols.size]
            bp.colorFilter = filters.getOrPut(col) { PorterDuffColorFilter(col, PorterDuff.Mode.SRC_IN) }
            spr(cv, "bokeh", x, y, b.s, 0f, (40 + 90 * b.z).toInt())
        }
        bp.colorFilter = null
    }

    private fun bez(a: Float, b: Float, c: Float, d: Float, u: Float): Float { val v = 1f - u; return v * v * v * a + 3f * v * v * u * b + 3f * v * u * u * c + u * u * u * d }

    private fun meadowDraw(cv: Canvas, t: Float, tx: Float, sunny: Boolean) {
        for (g in meadow) {
            var push = 0f
            if (tx >= 0f) { val d = abs(g.x - tx); if (d < 130f * sc) push = sign(g.x - tx) * (1f - d / (130f * sc)) * g.s * 0.4f }
            val bend = sin(t * 1.3f + g.x * 0.004f + g.ph) * g.s * 0.14f + push
            p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND
            if (g.k == 0) {
                p.strokeWidth = (1.6f + 3.2f * g.z) * sc; p.color = g.col
                path.reset(); path.moveTo(g.x, g.y); path.quadTo(g.x + bend * 0.25f, g.y - g.s * 0.55f, g.x + bend, g.y - g.s); cv.drawPath(path, p)
            } else {
                val big = g.k == 3
                p.strokeWidth = (if (big) 5f + 12f * g.z else 2f + 3f * g.z) * sc; p.color = if (big) hx(0xFF4A7A2A) else hx(0xFF3F7F38)
                path.reset(); path.moveTo(g.x, g.y); path.quadTo(g.x + bend * 0.2f, g.y - g.s * 0.5f, g.x + bend, g.y - g.s); cv.drawPath(path, p)
                p.style = Paint.Style.FILL; p.color = if (big) hx(0xFF5B8F33) else hx(0xFF4E9443)
                val lk = (if (big) 2.2f else 1f) * (1f + g.z)
                for (sd in intArrayOf(-1, 1)) { cv.save(); cv.translate(g.x + bend * 0.2f, g.y - g.s * (if (sd < 0) 0.30f else 0.5f)); cv.scale(sd.toFloat(), 1f); cv.rotate(-35f)
                    rect.set(0f, -4f * sc * lk, 34f * sc * lk, 4f * sc * lk); cv.drawOval(rect, p); cv.restore(); if (!big) break }
                val rot = bend / g.s * 40f + sin(t * 0.7f + g.ph) * 4f
                when (g.k) {
                    1 -> spr(cv, if (g.z < 0.25f) "daisyB" else "daisy", g.x + bend, g.y - g.s, (34f + 60f * g.z) * sc, rot)
                    2 -> spr(cv, "poppy", g.x + bend, g.y - g.s, (34f + 60f * g.z) * sc, rot)
                    else -> spr(cv, if (g.z > 0.9f) "sunflowerB" else "sunflower", g.x + bend, g.y - g.s, (46f + 190f * g.z) * sc, rot)
                }
            }
        }
        p.style = Paint.Style.FILL
    }

    private fun fall(cv: Canvas, t: Float, tx: Float, keys: Array<String>, size0: Float, size1: Float, drift: Float) {
        for (d in drops) {
            val sp = d.s * sc
            val y = ((d.y + t * sp) % (h + 80f)) - 40f
            var x = d.x + sin(t * 0.7f + d.ph) * 38f * sc * (0.4f + d.z) + t * drift * sc * (0.3f + d.z)
            x = ((x % (w + 80f)) + w + 80f) % (w + 80f) - 40f
            if (tx >= 0f) { val dx = x - tx; if (abs(dx) < 200f) x += sign(dx) * (1f - abs(dx) / 200f) * 70f * sc }
            val flut = max(0.28f, abs(cos(t * 2.6f + d.ph)))
            val key = keys[d.k % keys.size] + (if (d.z > 0.78f) "B" else "")
            spr(cv, key, x, y, (size0 + (size1 - size0) * d.z) * sc, 50f * sin(t * 1.4f + d.ph) + d.ph * 40f, (140 + 115 * d.z).toInt(), flut)
        }
    }

    // ═════════════════════════ PRINTEMPS : cerisiers en fleurs ═════════════════════════
    private fun backSpring(c: Canvas) {
        skyGrad(c, intArrayOf(hx(0xFF7DB9E8), hx(0xFFB5DCF2), hx(0xFFFBE3EA)), floatArrayOf(0f, .5f, .78f), h.toFloat())
        p.shader = RadialGradient(w * .85f, h * .1f, h * .7f, withA(hx(0xFFFFF3C4), 150), withA(hx(0xFFFFF3C4), 0), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p); p.shader = null
        ridge(c, h * 0.66f, h * 0.07f, 0.0035f, 1.7f, hx(0xFFA9CDB8), hx(0xFFC4DDD0))
        ridge(c, h * 0.73f, h * 0.06f, 0.005f, 8.2f, hx(0xFF8FC48F), hx(0xFFA6D2A0))
        ridge(c, h * 0.80f, h * 0.045f, 0.007f, 4.4f, hx(0xFF6FB36A), hx(0xFF86C47E))
        p.shader = LinearGradient(0f, h * .8f, 0f, h.toFloat(), hx(0xFF5FA45C), hx(0xFF2F6B35), Shader.TileMode.CLAMP)
        c.drawRect(0f, h * .8f, w.toFloat(), h.toFloat(), p); p.shader = null
    }

    private fun branchPts(i: Int): FloatArray = if (i == 0) floatArrayOf(-0.06f * w, 0.04f * h, 0.22f * w, 0f, 0.38f * w, 0.22f * h, 0.72f * w, 0.16f * h)
        else floatArrayOf(1.06f * w, 0.36f * h, 0.86f * w, 0.30f * h, 0.68f * w, 0.40f * h, 0.46f * w, 0.30f * h)

    private fun spring(cv: Canvas, t: Float, tx: Float) {
        val sx = w * .85f; val sy = h * .1f
        bokehDraw(cv, t, intArrayOf(Color.WHITE, hx(0xFFFFE9F0), hx(0xFFFFF6C8)))
        sun(cv, sx, sy, 20f * sc, hx(0xFFFFF0B8), 0.8f, t)
        rays(cv, sx, sy, t, 0.9f, 1.95f, hx(0xFFFFF3C8))
        cloud(cv, "cloud0", ((t * 7f * sc) % (w + 500f)) - 250f, h * 0.20f, 360f * sc, 170)
        cloud(cv, "cloud1", ((t * 4f * sc + w * 0.6f) % (w + 500f)) - 250f, h * 0.33f, 280f * sc, 130)
        for (b in 0..1) {
            val q = branchPts(b); val n = 30
            p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND
            for (j in 0 until n) {
                val u0 = j / n.toFloat(); val u1 = (j + 1) / n.toFloat()
                val x0 = bez(q[0], q[2], q[4], q[6], u0); val y0 = bez(q[1], q[3], q[5], q[7], u0)
                val x1 = bez(q[0], q[2], q[4], q[6], u1); val y1 = bez(q[1], q[3], q[5], q[7], u1)
                val wd = (18f - 14f * u0) * sc
                p.strokeWidth = wd; p.color = hx(0xFF45302A); cv.drawLine(x0, y0, x1, y1, p)
                p.strokeWidth = wd * 0.35f; p.color = withA(hx(0xFF8A6A55), 150); cv.drawLine(x0, y0 - wd * 0.18f, x1, y1 - wd * 0.18f, p)
            }
            p.style = Paint.Style.FILL
        }
        for (b in blossoms) {
            val q = branchPts(b.k)
            val px = bez(q[0], q[2], q[4], q[6], b.x) + b.s * 70f * sc + sin(t * 0.6f + b.ph) * 2.5f * sc
            val py = bez(q[1], q[3], q[5], q[7], b.x) + b.y * 70f * sc + cos(t * 0.5f + b.ph) * 2f * sc
            spr(cv, "blossom", px, py, 86f * b.z * sc, b.ph * 57f + sin(t * 0.8f + b.ph) * 4f)
        }
        meadowDraw(cv, t, tx, false)
        fall(cv, t, tx, arrayOf("petal"), 12f, 38f, 9f)
        spr(cv, "blossomB", w * 0.04f, h * 0.07f, w * 0.55f, 18f + sin(t * 0.2f) * 2f, 200)
        spr(cv, "blossomB", w * 1.0f, h * 0.60f, w * 0.40f, -25f, 150)
    }

    // ═════════════════════════ ÉTÉ : soleil & tournesols ═════════════════════════
    private fun backSummer(c: Canvas) {
        skyGrad(c, intArrayOf(hx(0xFF1565C0), hx(0xFF3F9BE6), hx(0xFFBFE6FF)), floatArrayOf(0f, .35f, .66f), h.toFloat())
        ridge(c, h * 0.62f, h * 0.05f, 0.004f, 2.2f, hx(0xFF8DB7C9), hx(0xFFA9CCD8))
        ridge(c, h * 0.67f, h * 0.045f, 0.006f, 6.7f, hx(0xFF6FA37A), hx(0xFF86B58C))
        p.shader = LinearGradient(0f, h * .68f, 0f, h.toFloat(), hx(0xFFB9C94C), hx(0xFF5E8A26), Shader.TileMode.CLAMP)
        c.drawRect(0f, h * .68f, w.toFloat(), h.toFloat(), p); p.shader = null
        p.style = Paint.Style.STROKE; p.strokeWidth = 2f * sc; p.color = withA(hx(0xFF3E5E14), 40)
        for (i in -14..14) c.drawLine(w * .5f, h * .68f, w * .5f + i * w * 0.16f, h.toFloat(), p)
        p.style = Paint.Style.FILL
    }

    private fun summer(cv: Canvas, t: Float, tx: Float) {
        val sx = w * 0.78f; val sy = h * 0.14f
        sun(cv, sx, sy, 26f * sc, hx(0xFFFFE9A8), 1f, t)
        for (i in 0..4) cloud(cv, "cloud$i", ((t * (5f + i * 2f) * sc + i * w * 0.33f) % (w + 600f)) - 300f, h * (0.10f + 0.09f * i), (240f + i * 40f) * sc, 215 - i * 15)
        rays(cv, sx, sy, t, 1f, 1.95f, hx(0xFFFFF3C8))
        meadowDraw(cv, t, tx, true)
        flare(cv, sx, sy, 1f)
    }

    // ═════════════════════════ AUTOMNE : forêt dorée ═════════════════════════
    private fun forestLayer(c: Canvas, seed: Int, baseY: Float, count: Int, hMin: Float, hMax: Float, fog: Float) {
        val r = Random(seed * 13 + 1)
        val pal = intArrayOf(hx(0xFFD2481E), hx(0xFFE8731A), hx(0xFFF2A81D), hx(0xFFB5381C), hx(0xFFE0A030), hx(0xFF8C5A1E))
        val fogCol = hx(0xFFF0C090)
        for (i in 0 until count) {
            val x = (i + r.nextFloat() * 0.8f) / count * w; val th = hMin + r.nextFloat() * (hMax - hMin)
            p.style = Paint.Style.FILL; p.color = mix(hx(0xFF3A2416), fogCol, fog)
            rect.set(x - th * 0.018f, baseY - th * 0.6f, x + th * 0.018f, baseY); c.drawRect(rect, p)
            for (b in 0 until 16) {
                val cx = x + gauss(r) * th * 0.16f; val cy = baseY - th * (0.70f + gauss(r) * 0.14f); val rad = th * (0.10f + 0.07f * r.nextFloat())
                var col = pal[r.nextInt(pal.size)]
                col = mix(col, hx(0xFF4A1A0A), (0.30f * ((cy - (baseY - th * 0.9f)) / (th * 0.4f))).coerceIn(0f, 0.3f))
                if (cx < x) col = mix(col, hx(0xFFFFE0A0), 0.2f)
                col = mix(col, fogCol, fog)
                p.shader = RadialGradient(cx, cy, rad, intArrayOf(withA(col, 255), withA(col, 235), withA(col, 0)), floatArrayOf(0f, .75f, 1f), Shader.TileMode.CLAMP)
                c.drawCircle(cx, cy, rad, p)
            }
            p.shader = null
        }
    }

    private fun backAutumn(c: Canvas) {
        skyGrad(c, intArrayOf(hx(0xFF5F86B5), hx(0xFFE8A46C), hx(0xFFFFD6A0)), floatArrayOf(0f, .5f, .72f), h.toFloat())
        val sx = w * 0.24f; val sy = h * 0.46f
        p.shader = RadialGradient(sx, sy, h * 0.55f, intArrayOf(withA(hx(0xFFFFF0C0), 235), withA(hx(0xFFFFB866), 120), withA(hx(0xFFFFB866), 0)), floatArrayOf(0f, .16f, 1f), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p); p.shader = null
        forestLayer(c, 0, h * 0.60f, 16, h * 0.20f, h * 0.30f, 0.62f)
        forestLayer(c, 1, h * 0.70f, 12, h * 0.28f, h * 0.40f, 0.35f)
        forestLayer(c, 2, h * 0.84f, 7, h * 0.45f, h * 0.62f, 0f)
        path.reset(); path.moveTo(0f, h.toFloat()); var x = 0f
        while (x <= w + 8) { path.lineTo(x, h * 0.86f + (fbm(x * 0.006f, 4f, 3) - .5f) * h * 0.03f); x += 8f }
        path.lineTo(w + 8f, h.toFloat()); path.close()
        p.shader = LinearGradient(0f, h * .85f, 0f, h.toFloat(), hx(0xFF8A4F1E), hx(0xFF2E1A0C), Shader.TileMode.CLAMP); c.drawPath(path, p); p.shader = null
        val r = Random(9); val pal = intArrayOf(hx(0xFFD2481E), hx(0xFFF2A81D), hx(0xFFB5381C), hx(0xFFE8731A), hx(0xFF8C5A1E))
        for (i in 0 until 520) {
            val lx = r.nextFloat() * w; val ly = h * (0.87f + 0.13f * r.nextFloat()); val s = (4f + 9f * ((ly - h * 0.87f) / (h * 0.13f))) * sc
            p.color = withA(pal[r.nextInt(pal.size)], 235); c.save(); c.translate(lx, ly); c.rotate(r.nextFloat() * 180f)
            rect.set(-s, -s * 0.5f, s, s * 0.5f); c.drawOval(rect, p); c.restore()
        }
    }

    private fun autumn(cv: Canvas, t: Float, tx: Float) {
        val sx = w * 0.24f; val sy = h * 0.46f
        rays(cv, sx, sy, t, 0.9f, 0.55f, hx(0xFFFFD79A))
        for (i in 0..2) {
            val y = h * (0.62f + 0.09f * i); val ww = w * 1.7f
            rect.set(((t * (5f + 4f * i) * sc + i * 200f) % (ww)) - ww, y - 40f * sc, ((t * (5f + 4f * i) * sc + i * 200f) % ww), y + 40f * sc)
            bp.alpha = 110 - i * 20; bp.colorFilter = PorterDuffColorFilter(hx(0xFFFFE2B8), PorterDuff.Mode.MULTIPLY)
            cv.drawBitmap(sprites["mist"]!!, null, rect, bp)
            rect.offset(ww, 0f); cv.drawBitmap(sprites["mist"]!!, null, rect, bp)
            bp.colorFilter = null; bp.alpha = 255
        }
        fall(cv, t, tx, arrayOf("leaf0", "leaf1", "leaf2"), 16f, 56f, 14f)
    }

    // ═════════════════════════ HIVER : neige & aurore ═════════════════════════
    private fun pine(c: Canvas, x: Float, base: Float, hh: Float, dark: Int, light: Int) {
        val tiers = 6; val tw = hh * 0.30f
        p.style = Paint.Style.FILL; p.shader = null; p.color = hx(0xFF2B1D14); c.drawRect(x - hh * 0.02f, base - hh * 0.12f, x + hh * 0.02f, base, p)
        for (i in 0 until tiers) {
            val yb = base - hh * (0.10f + 0.15f * i); val th = hh * 0.34f * (1f - 0.09f * i); val hw = tw * (1f - 0.15f * i); val yt = yb - th
            p.shader = LinearGradient(0f, yt, 0f, yb, light, dark, Shader.TileMode.CLAMP)
            path.reset(); path.moveTo(x - hw, yb); path.lineTo(x, yt); path.lineTo(x + hw, yb); path.close(); c.drawPath(path, p)
            p.shader = null; p.color = withA(hx(0xFFEAF2FF), 235)
            path.reset(); path.moveTo(x, yt); path.lineTo(x - hw * 0.62f, yt + th * 0.62f)
            path.quadTo(x - hw * 0.3f, yt + th * 0.5f, x - hw * 0.1f, yt + th * 0.66f); path.quadTo(x + hw * 0.2f, yt + th * 0.5f, x + hw * 0.4f, yt + th * 0.68f)
            path.lineTo(x + hw * 0.62f, yt + th * 0.62f); path.close(); c.drawPath(path, p)
        }
    }

    private fun backWinter(c: Canvas) {
        skyGrad(c, intArrayOf(hx(0xFF0B1636), hx(0xFF2D4A7A), hx(0xFFD6A5B8)), floatArrayOf(0f, .45f, .72f), h.toFloat())
        val r = Random(3)
        for (i in 0 until 90) { p.color = withA(Color.WHITE, 60 + r.nextInt(160)); c.drawCircle(r.nextFloat() * w, r.nextFloat() * h * 0.4f, (0.5f + r.nextFloat() * 1.1f) * sc, p) }
        ridge(c, h * 0.60f, h * 0.12f, 0.003f, 1.3f, hx(0xFF3A4F78), hx(0xFFC9D6EE))
        ridge(c, h * 0.67f, h * 0.07f, 0.005f, 5.1f, hx(0xFF24385E), hx(0xFF8FA6C8))
        for (i in 0 until 14) pine(c, (i + r.nextFloat() * 0.6f) / 14f * w, h * 0.70f, h * (0.07f + 0.03f * r.nextFloat()), hx(0xFF16301F), hx(0xFF2F5A3E))
        ridge(c, h * 0.77f, h * 0.025f, 0.004f, 2.6f, hx(0xFFB8C9E6), hx(0xFFE6EEFA))
        for (i in 0 until 9) pine(c, (i + r.nextFloat() * 0.7f) / 9f * w, h * 0.82f, h * (0.16f + 0.05f * r.nextFloat()), hx(0xFF0F2619), hx(0xFF2A5238))
        ridge(c, h * 0.88f, h * 0.02f, 0.004f, 7.7f, hx(0xFFA9BCDD), hx(0xFFF4F8FF))
        pine(c, w * 0.12f, h * 0.97f, h * 0.42f, hx(0xFF0B1F14), hx(0xFF24472F)); pine(c, w * 0.9f, h * 1.0f, h * 0.36f, hx(0xFF0B1F14), hx(0xFF24472F))
    }

    private fun aurora(cv: Canvas, t: Float) {
        p.xfermode = screen; p.style = Paint.Style.FILL
        for (i in 0..2) {
            val baseY = h * (0.14f + 0.07f * i); val amp = h * 0.05f; val thick = h * (0.20f + 0.05f * i)
            val g = if (i == 1) hx(0xFF7CFFB2) else hx(0xFF39E58C); val v = if (i == 2) hx(0xFFFF6FD8) else hx(0xFF8A5CFF)
            p.shader = LinearGradient(0f, baseY - amp, 0f, baseY + thick + amp, intArrayOf(withA(g, 0), withA(g, 120), withA(v, 70), withA(v, 0)), floatArrayOf(0f, .25f, .7f, 1f), Shader.TileMode.CLAMP)
            p.alpha = (170 + 70 * sin(t * 0.5f + i)).toInt().coerceIn(0, 255)
            path.reset(); var x = 0f; var first = true
            while (x <= w + 14) {
                val yT = baseY + sin(x * 0.004f * (1f + i * .3f) + t * 0.25f + i * 2f) * amp + sin(x * 0.011f + t * 0.4f + i) * amp * 0.4f
                if (first) { path.moveTo(x, yT); first = false } else path.lineTo(x, yT); x += 14f
            }
            x = w + 14f
            while (x >= 0f) {
                val yT = baseY + sin(x * 0.004f * (1f + i * .3f) + t * 0.25f + i * 2f) * amp + sin(x * 0.011f + t * 0.4f + i) * amp * 0.4f
                path.lineTo(x, yT + thick * (0.7f + 0.3f * sin(x * 0.007f + t * 0.3f + i))); x -= 14f
            }
            path.close(); cv.drawPath(path, p)
        }
        p.shader = null; p.alpha = 255; p.xfermode = null
    }

    private fun winter(cv: Canvas, t: Float, tx: Float) {
        aurora(cv, t)
        p.xfermode = screen
        for (s in stars) { val a = (0.25f + 0.75f * abs(sin(t * (1.2f + s.z * 2f) + s.ph))); p.color = withA(hx(0xFFDDEBFF), (a * 200).toInt()); cv.drawCircle(s.x, s.y + sin(s.ph) * 2f, (0.8f + 1.4f * s.z) * sc, p) }
        p.xfermode = null
        for (d in drops) {
            val sp = d.s * sc; val y = ((d.y + t * sp) % (h + 40f)) - 20f
            var x = d.x + sin(t * 0.6f + d.ph) * (18f + 30f * d.z) * sc + t * (6f + 10f * d.z) * sc
            x = ((x % (w + 40f)) + w + 40f) % (w + 40f) - 20f
            if (tx >= 0f) { val dx = x - tx; if (abs(dx) < 160f) x += sign(dx) * (1f - abs(dx) / 160f) * 50f * sc }
            spr(cv, "softdot", x, y, (2.6f + 9f * d.z) * sc, 0f, (110 + 140 * d.z).toInt())
        }
    }

    // ═════════════════════════ NUIT : vraie lune & Voie lactée ═════════════════════════
    private fun backNight(c: Canvas) {
        skyGrad(c, intArrayOf(hx(0xFF02040C), hx(0xFF0A1730), hx(0xFF1C3358)), floatArrayOf(0f, .55f, .8f), h.toFloat())
        val mk = milky; if (mk != null) { bp.alpha = 235; c.drawBitmap(mk, 0f, 0f, bp); bp.alpha = 255 }
        ridge(c, h * 0.66f, h * 0.09f, 0.004f, 2.9f, hx(0xFF0A1424), hx(0xFF16243E), withA(hx(0xFFB8CCFF), 70))
        ridge(c, h * 0.72f, h * 0.05f, 0.006f, 9.1f, hx(0xFF060C16), hx(0xFF0B1424), withA(hx(0xFFB8CCFF), 50))
        p.shader = LinearGradient(0f, h * 0.78f, 0f, h.toFloat(), hx(0xFF0B1B33), hx(0xFF040A14), Shader.TileMode.CLAMP)
        c.drawRect(0f, h * 0.78f, w.toFloat(), h.toFloat(), p); p.shader = null
        pine(c, w * 0.06f, h * 1.01f, h * 0.45f, hx(0xFF02050A), hx(0xFF050B14)); pine(c, w * 0.95f, h * 1.02f, h * 0.38f, hx(0xFF02050A), hx(0xFF050B14))
    }

    private fun night(cv: Canvas, t: Float) {
        val cols = intArrayOf(hx(0xFFFFFFFF), hx(0xFFBFD4FF), hx(0xFFFFE9C0), hx(0xFFFFC9A0))
        p.style = Paint.Style.FILL
        for (s in stars) {
            val a = s.z * (0.6f + 0.4f * sin(t * (1.5f + s.z * 2f) + s.ph))
            p.color = withA(cols[s.k], (a * 255).toInt()); cv.drawCircle(s.x, s.y, s.s * sc * (0.7f + s.z * 0.8f), p)
            if (s.z > 0.88f) { p.strokeWidth = sc; p.style = Paint.Style.STROKE; p.color = withA(cols[s.k], (a * 120).toInt())
                cv.drawLine(s.x - 6f * sc, s.y, s.x + 6f * sc, s.y, p); cv.drawLine(s.x, s.y - 6f * sc, s.x, s.y + 6f * sc, p); p.style = Paint.Style.FILL }
        }
        val tt = t % 11f
        if (tt < 0.9f) {
            val f = tt / 0.9f; val seed = floor(t / 11f).toInt()
            val x0 = w * (0.15f + 0.6f * hash2(seed, 1)); val y0 = h * (0.05f + 0.15f * hash2(seed, 2)); val len = w * 0.22f
            val hxp = x0 + f * len * 1.6f; val hyp = y0 + f * len * 0.7f; val txp = hxp - len * 0.8f; val typ = hyp - len * 0.35f
            p.shader = LinearGradient(txp, typ, hxp, hyp, withA(Color.WHITE, 0), withA(Color.WHITE, (230 * (1f - f * 0.6f)).toInt()), Shader.TileMode.CLAMP)
            p.style = Paint.Style.STROKE; p.strokeWidth = 2.2f * sc; p.strokeCap = Paint.Cap.ROUND; cv.drawLine(txp, typ, hxp, hyp, p); p.shader = null; p.style = Paint.Style.FILL
        }
        val mx = w * 0.68f; val my = h * 0.24f; val md = min(w, h) * 0.30f
        p.xfermode = screen
        p.shader = RadialGradient(mx, my, md * 2.2f, intArrayOf(withA(hx(0xFFBFD4FF), (70 * (0.25f + 0.75f * moonIllum)).toInt()), withA(hx(0xFFBFD4FF), (24 * moonIllum).toInt()), withA(hx(0xFFBFD4FF), 0)), floatArrayOf(0f, .25f, 1f), Shader.TileMode.CLAMP)
        cv.drawCircle(mx, my, md * 2.2f, p); p.shader = null; p.xfermode = null
        spr(cv, "moon", mx, my, md)
        val lakeY = h * 0.78f
        for (i in 0 until 60) {
            val d = i / 60f; val y = lakeY + 4f + d * (h - lakeY); val spread = (8f + d * 60f) * sc
            val xx = mx + sin(t * 1.6f + i * 0.9f) * spread * 0.5f; val len = md * 0.30f * (1f - d * 0.4f) * (0.6f + 0.4f * sin(t * 2.3f + i * 1.3f))
            p.color = withA(hx(0xFFDCE6FF), (120 * (1f - d) * (0.2f + 0.8f * moonIllum)).toInt()); cv.drawRect(xx - abs(len), y, xx + abs(len), y + (2f + d * 3f) * sc, p)
        }
    }

    // ═════════════════════════ FLEUR QUI ÉCLOT (time-lapse) ═════════════════════════
    private fun backGarden(c: Canvas) {
        skyGrad(c, intArrayOf(hx(0xFFBFE3F4), hx(0xFFFFF2D8), hx(0xFFD7EBC0)), floatArrayOf(0f, .55f, .85f), h.toFloat())
        val r = Random(31)
        for (i in 0 until 26) {
            val cx = r.nextFloat() * w; val cy = h * (0.35f + 0.5f * r.nextFloat()); val rad = (60f + 160f * r.nextFloat()) * sc; val col = mix(hx(0xFF6DBE6A), hx(0xFFB8DB7A), r.nextFloat())
            p.shader = RadialGradient(cx, cy, rad, withA(col, 150), withA(col, 0), Shader.TileMode.CLAMP); c.drawCircle(cx, cy, rad, p)
        }
        for (i in 0 until 14) {
            val cx = r.nextFloat() * w; val cy = r.nextFloat() * h * 0.7f; val rad = (14f + 40f * r.nextFloat()) * sc
            p.shader = RadialGradient(cx, cy, rad, withA(hx(0xFFFFF3B0), 70), withA(hx(0xFFFFF3B0), 0), Shader.TileMode.CLAMP); c.drawCircle(cx, cy, rad, p)
        }
        p.shader = RadialGradient(w * 0.15f, h * 0.05f, h * 0.8f, withA(hx(0xFFFFF0B0), 170), withA(hx(0xFFFFF0B0), 0), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p); p.shader = null
        val soilTop = h * 0.82f
        path.reset(); path.moveTo(0f, h.toFloat()); var x = 0f
        while (x <= w + 8) { path.lineTo(x, soilTop + (fbm(x * 0.01f, 1f, 3) - .5f) * 14f * sc); x += 8f }
        path.lineTo(w + 8f, h.toFloat()); path.close()
        p.shader = LinearGradient(0f, soilTop, 0f, h.toFloat(), hx(0xFF6B4A32), hx(0xFF2E1F14), Shader.TileMode.CLAMP); c.drawPath(path, p); p.shader = null
        for (i in 0 until 1600) {
            val gx = r.nextFloat() * w; val gy = soilTop + 6f * sc + r.nextFloat() * (h - soilTop); val rr = (1f + 3f * r.nextFloat()) * sc
            p.color = withA(mix(hx(0xFF3A2616), hx(0xFF9A7350), r.nextFloat()), 200); rect.set(gx - rr, gy - rr * 0.7f, gx + rr, gy + rr * 0.7f); c.drawOval(rect, p)
        }
    }

    private fun plant(cv: Canvas, x: Float, baseY: Float, maxH: Float, stem: Float, leaf: Float, open: Float, t: Float, kind: Int) {
        if (stem <= 0.01f) return
        val len = maxH * stem; val sway = sin(t * 1.1f + x * 0.01f) * len * 0.04f
        val topX = x + sway; val topY = baseY - len; val cxq = x - len * 0.06f; val cyq = baseY - len * 0.5f
        val sw = max(4f, 13f * sc * (0.6f + 0.4f * stem))
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND
        path.reset(); path.moveTo(x, baseY + 4f * sc); path.quadTo(cxq, cyq, topX, topY)
        p.strokeWidth = sw + 3f * sc; p.color = hx(0xFF2A5E32); cv.drawPath(path, p)
        p.strokeWidth = sw; p.color = hx(0xFF4FA550); cv.drawPath(path, p)
        p.strokeWidth = sw * 0.3f; p.color = withA(hx(0xFFB5E69A), 170)
        path.reset(); path.moveTo(x - sw * 0.15f, baseY); path.quadTo(cxq - sw * 0.15f, cyq, topX - sw * 0.15f, topY); cv.drawPath(path, p)
        p.style = Paint.Style.FILL
        val lb = sprites["leafG"]
        if (leaf > 0f && lb != null) for (side in intArrayOf(-1, 1)) {
            val fy = baseY - len * (if (side < 0) 0.34f else 0.55f); val ll = maxH * 0.30f * leaf
            cv.save(); cv.translate(x + sway * 0.3f, fy); cv.scale(side.toFloat(), 1f); cv.rotate(-28f + sin(t + side) * 3f)
            cv.scale(ll / 160f, ll / 160f); cv.drawBitmap(lb, 0f, -lb.height / 2f, bp); cv.restore()
        }
        if (stem > 0.6f) for (u in floatArrayOf(0.3f, 0.5f, 0.7f, 0.86f)) {
            val v = 1f - u; val dx = v * v * x + 2f * v * u * cxq + u * u * topX + sw * 0.55f; val dy = v * v * baseY + 2f * v * u * cyq + u * u * topY
            val dr = 3.4f * sc
            p.color = withA(Color.WHITE, 70); cv.drawCircle(dx, dy, dr, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 0.9f * sc; p.color = withA(hx(0xFF1F4D2A), 140); cv.drawCircle(dx, dy, dr, p)
            p.style = Paint.Style.FILL; p.color = withA(Color.WHITE, 235); cv.drawCircle(dx - dr * 0.35f, dy - dr * 0.35f, dr * 0.32f, p)
        }
        val r = maxH * 0.17f
        cv.save(); cv.translate(topX, topY); cv.rotate(sway * 0.4f)
        val sepal = max(3f, r * 0.3f * stem)
        p.color = hx(0xFF5FAE5C); p.alpha = (255 * (1f - sstep(0.1f, 0.5f, open))).toInt()
        rect.set(-sepal, -sepal * 1.6f, sepal, sepal * 0.6f); cv.drawOval(rect, p); p.alpha = 255
        cv.restore()
        if (open > 0.03f) spr(cv, "bloom$kind", topX, topY, 2.2f * r * (0.2f + 0.8f * open), sin(t * 0.3f) * 3f + sway * 0.5f)
    }

    private fun garden(cv: Canvas, t: Float) {
        val baseY = h * 0.82f; val cx = w / 2f; val maxH = h * 0.42f
        val cycle = 42f; val ph = (t % cycle) / cycle
        val fade = ((ph - 0.94f) / 0.06f).coerceIn(0f, 1f)
        val layer = cv.saveLayerAlpha(0f, 0f, w.toFloat(), h.toFloat(), ((1f - fade) * 255).toInt())
        if (ph < 0.12f) { p.color = hx(0xFF8D6E63); rect.set(cx - 10f * sc, baseY + 14f * sc, cx + 10f * sc, baseY + 28f * sc); cv.drawOval(rect, p) }
        plant(cv, cx, baseY, maxH, sstep(0f, 1f, (ph - 0.06f) / 0.5f), sstep(0f, 1f, (ph - 0.25f) / 0.3f), sstep(0f, 1f, (ph - 0.55f) / 0.2f), t, 0)
        val offs = floatArrayOf(-0.32f, -0.18f, 0.2f, 0.34f); val hs = floatArrayOf(0.35f, 0.22f, 0.27f, 0.4f)
        for (i in 0..3) {
            val g = sstep(0f, 1f, (ph - 0.70f - i * 0.04f) / 0.12f)
            if (g > 0f) plant(cv, cx + w * offs[i], baseY, maxH * hs[i], g, g, g, t + i, i + 1)
        }
        cv.restoreToCount(layer)
    }

    // ═════════════════════════ PLAGE : ciel à l'heure réelle ═════════════════════════
    private val hrs = floatArrayOf(0f, 5f, 6.5f, 9f, 17f, 19f, 20.5f, 22f, 24f)
    private val tops = intArrayOf(hx(0xFF050A24), hx(0xFF0F1B45), hx(0xFF4A6FA5), hx(0xFF2F8FE0), hx(0xFF2F8FE0), hx(0xFF4B5FA5), hx(0xFF1A2150), hx(0xFF0A1030), hx(0xFF050A24))
    private val bots = intArrayOf(hx(0xFF0F1B45), hx(0xFF5B4B8A), hx(0xFFFFB07A), hx(0xFFA8E0FF), hx(0xFFA8E0FF), hx(0xFFFF8F5B), hx(0xFF6A3D7A), hx(0xFF1A2150), hx(0xFF0F1B45))
    private fun nightFactor(hf: Float) = when { hf < 5f || hf > 21.5f -> 1f; hf < 7f -> 1f - (hf - 5f) / 2f; hf > 19.5f -> (hf - 19.5f) / 2f; else -> 0f }

    private fun palm(cv: Canvas, x: Float, base: Float, hh: Float, lean: Float, t: Float, col: Int) {
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.color = col
        var px = x; var py = base; val n = 14
        for (j in 1..n) {
            val u = j / n.toFloat(); val xx = x + lean * hh * u * u; val yy = base - hh * u
            p.strokeWidth = (15f - 8f * u) * sc; cv.drawLine(px, py, xx, yy, p); px = xx; py = yy
        }
        val topX = px; val topY = py; val L = hh * 0.55f
        p.strokeWidth = 3.5f * sc
        for (i in 0 until 9) {
            val a = (-185f + i * 22f) * 0.0174533f + sin(t * 0.8f + i) * 0.04f
            val ex = topX + cos(a) * L; val ey = topY + sin(a) * L + L * 0.30f; val qx = topX + cos(a) * L * 0.6f; val qy = topY + sin(a) * L * 0.6f - L * 0.2f
            path.reset(); path.moveTo(topX, topY); path.quadTo(qx, qy, ex, ey); cv.drawPath(path, p)
            p.strokeWidth = 1.6f * sc
            for (k in 1..11) {
                val u = k / 12f; val v = 1f - u
                val bx = v * v * topX + 2f * v * u * qx + u * u * ex; val by = v * v * topY + 2f * v * u * qy + u * u * ey
                val tl = 0.26f * L * (1f - u * 0.7f)
                cv.drawLine(bx, by, bx - tl * 0.3f, by + tl, p); cv.drawLine(bx, by, bx + tl * 0.3f, by + tl, p)
            }
            p.strokeWidth = 3.5f * sc
        }
        p.style = Paint.Style.FILL
    }

    private fun beach(cv: Canvas, t: Float, tx: Float) {
        cal.timeInMillis = System.currentTimeMillis()
        val hf = if (tx >= 0f) tx / w * 24f else cal.get(Calendar.HOUR_OF_DAY) + cal.get(Calendar.MINUTE) / 60f + cal.get(Calendar.SECOND) / 3600f
        var i = 0; while (i < hrs.size - 2 && hf > hrs[i + 1]) i++
        val f = (hf - hrs[i]) / (hrs[i + 1] - hrs[i]); val top = mix(tops[i], tops[i + 1], f); val bot = mix(bots[i], bots[i + 1], f)
        val nf = nightFactor(hf); val hor = h * 0.52f; val shore = h * 0.80f
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, 0f, hor, intArrayOf(top, mix(top, bot, 0.6f), bot), floatArrayOf(0f, .6f, 1f), Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, w.toFloat(), hor, p); p.shader = null
        val mk = milky; if (mk != null && nf > 0.05f) { bp.alpha = (230 * nf).toInt(); cv.drawBitmap(mk, 0f, 0f, bp); bp.alpha = 255 }
        for (s in stars) { val a = nf * s.z * (0.55f + 0.45f * sin(t * 2f + s.ph)); if (a > 0.03f && s.y < hor * 0.97f) { p.color = withA(Color.WHITE, (a * 255).toInt()); cv.drawCircle(s.x, s.y, s.s * sc, p) } }
        var rx = -1f; var rI = 0f; var rc = Color.WHITE
        if (hf in 5.5f..20.5f) {
            val d = (hf - 5.5f) / 15f; val e = sin(PI.toFloat() * d); val sx = w * (0.1f + 0.8f * d); val sy = hor - e * hor * 0.78f
            val warm = mix(hx(0xFFFF8A3C), hx(0xFFFFF4D0), sstep(0f, 0.5f, e))
            if (nf < 0.75f) { sun(cv, sx, sy, 22f * sc, warm, (0.55f + 0.45f * e) * (1f - nf), t); rx = sx; rI = (0.4f + 0.6f * e) * (1f - nf); rc = warm }
        }
        if ((hf >= 18f || hf <= 7f) && nf > 0.02f) {
            val m = if (hf >= 18f) (hf - 18f) / 13f else (hf + 6f) / 13f
            val mx = w * (0.1f + 0.8f * m); val my = hor - sin(PI.toFloat() * m) * hor * 0.78f; val md = min(w, h) * 0.17f
            p.xfermode = screen; p.shader = RadialGradient(mx, my, md * 2.4f, intArrayOf(withA(hx(0xFFBFD4FF), (80 * nf * (0.25f + 0.75f * moonIllum)).toInt()), withA(hx(0xFFBFD4FF), 0)), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
            cv.drawCircle(mx, my, md * 2.4f, p); p.shader = null; p.xfermode = null
            spr(cv, "moon", mx, my, md, 0f, (255 * nf).toInt())
            if (rx < 0f) { rx = mx; rI = nf * (0.3f + 0.7f * moonIllum); rc = hx(0xFFEAF0FF) }
        }
        val ctint = mix(mix(Color.WHITE, mix(bot, Color.WHITE, 0.55f), (1f - nf) * 0.5f), hx(0xFF28304A), nf * 0.85f)
        if (nf < 0.95f) for (k in 0..2) cloud(cv, "cloud$k", ((t * (4f + k * 2f) * sc + k * w * 0.4f) % (w + 600f)) - 300f, h * (0.08f + 0.1f * k), (250f + 40f * k) * sc, ((1f - nf) * 220).toInt(), ctint)
        // presqu'île lointaine
        path.reset(); path.moveTo(0f, hor)
        var x = 0f; val lim = 0.55f * w
        while (x <= lim) { path.lineTo(x, hor - h * 0.04f * (1f - x / lim).pow(0.8f) * (0.6f + 0.4f * fbm(x * 0.01f, 3f, 3))); x += 8f }
        path.lineTo(lim, hor); path.close(); p.color = mix(hx(0xFF4A6B8A), hx(0xFF05080F), nf); cv.drawPath(path, p)
        if (nf > 0.1f) for (b in bok) { val lx = b.x; val ly = hor - h * 0.04f * (1f - lx / lim).coerceIn(0f, 1f).pow(0.8f) * 0.5f; p.color = withA(hx(0xFFFFD27A), (230 * nf * (0.6f + 0.4f * sin(t * 2f + b.ph))).toInt()); cv.drawCircle(lx, ly, 1.6f * sc, p) }
        // sable (sous la mer)
        val dry = mix(hx(0xFFE9CF9B), hx(0xFF1B1F2A), nf); val near = mix(hx(0xFFD9B77C), hx(0xFF0E1118), nf)
        p.shader = LinearGradient(0f, shore - h * 0.02f, 0f, h.toFloat(), dry, near, Shader.TileMode.CLAMP)
        cv.drawRect(0f, shore - h * 0.02f, w.toFloat(), h.toFloat(), p); p.shader = null
        val ss = sandShader
        if (ss != null) { p.shader = ss; p.alpha = (90 * (1f - nf * 0.7f)).toInt(); cv.drawRect(0f, shore - h * 0.02f, w.toFloat(), h.toFloat(), p); p.shader = null; p.alpha = 255 }
        // mer
        val cyc = (t * 0.16f) % 1f
        val adv = if (cyc < 0.35f) sstep(0f, 1f, cyc / 0.35f) else 1f - sstep(0f, 1f, (cyc - 0.35f) / 0.65f)
        val waterY = shore + adv * h * 0.05f
        val seaTop = mix(mix(bot, hx(0xFF1D5F86), 0.55f), hx(0xFF020814), nf * 0.92f)
        val seaNear = mix(mix(hx(0xFF1AA6B7), bot, 0.15f * (1f - nf)), hx(0xFF031428), nf * 0.93f)
        path.reset(); path.moveTo(0f, hor); path.lineTo(w.toFloat(), hor)
        x = w.toFloat()
        while (x >= 0f) { path.lineTo(x, waterY + sin(x * 0.012f + t * 0.8f) * 5f * sc + sin(x * 0.031f - t * 1.3f) * 2.5f * sc); x -= 10f }
        path.close()
        p.shader = LinearGradient(0f, hor, 0f, waterY, seaTop, seaNear, Shader.TileMode.CLAMP); cv.drawPath(path, p); p.shader = null
        p.style = Paint.Style.STROKE
        for (k in 1..16) {
            val u = k / 16f; val y0 = hor + (shore - hor) * u.pow(1.7f); val amp = (0.6f + 4f * u) * sc
            path.reset(); path.moveTo(0f, y0); x = 0f
            while (x <= w + 14) { path.lineTo(x, y0 + sin(x * (0.03f - 0.02f * u) + t * (0.9f + u) + k * 1.7f) * amp); x += 14f }
            p.strokeWidth = (0.8f + 2.2f * u) * sc; p.color = withA(Color.WHITE, ((26 + 40 * u) * (1f - nf * 0.8f)).toInt()); cv.drawPath(path, p)
        }
        p.style = Paint.Style.FILL
        if (rx >= 0f && rI > 0.02f) {
            p.xfermode = screen
            for (k in 0 until 170) {
                val d = k / 170f; val y = hor + 3f + d.pow(1.5f) * (shore - hor); val spread = (6f + d * 70f) * sc
                val lx = rx + (hash2(k, 11) - 0.5f) * 2f * spread; val len = (3f + d * 26f) * sc * (0.5f + hash2(k, 5))
                val a = rI * (1f - d * 0.55f) * max(0f, sin(t * 4f + k * 1.7f)) * 230
                p.color = withA(rc, a.toInt()); cv.drawRect(lx - len, y, lx + len, y + (1.2f + d * 2.2f) * sc, p)
            }
            p.xfermode = null
        }
        // sable mouillé, reflet du ciel et écume
        p.shader = LinearGradient(0f, waterY, 0f, waterY + h * 0.06f, withA(mix(hx(0xFF8A6B3E), hx(0xFF0A0C12), nf), 175), withA(hx(0xFF8A6B3E), 0), Shader.TileMode.CLAMP)
        path.reset(); path.moveTo(0f, waterY + h * 0.06f); x = 0f
        while (x <= w + 10) { path.lineTo(x, waterY + sin(x * 0.012f + t * 0.8f) * 5f * sc + sin(x * 0.031f - t * 1.3f) * 2.5f * sc); x += 10f }
        path.lineTo(w + 10f, waterY + h * 0.06f); path.close(); cv.drawPath(path, p); p.shader = null
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND
        for (pass in 0..1) {
            path.reset(); x = 0f
            while (x <= w + 10) { val yy = waterY + sin(x * 0.012f + t * 0.8f) * 5f * sc + sin(x * 0.031f - t * 1.3f) * 2.5f * sc + pass * 5f * sc; if (x == 0f) path.moveTo(x, yy) else path.lineTo(x, yy); x += 10f }
            p.strokeWidth = (if (pass == 0) 5f else 2.4f) * sc; p.color = withA(Color.WHITE, ((if (pass == 0) 215 else 120) * (1f - nf * 0.5f)).toInt()); cv.drawPath(path, p)
        }
        p.style = Paint.Style.FILL
        for (k in 0 until 40) {
            val fx = ((k * 53.7f + sin(t * 0.5f + k) * 20f) % w + w) % w
            val fy = waterY + sin(fx * 0.012f + t * 0.8f) * 5f * sc + hash2(k, 9) * h * 0.03f
            p.color = withA(Color.WHITE, ((60 + 90 * hash2(k, 4)) * (1f - nf * 0.5f)).toInt()); cv.drawCircle(fx, fy, (1.2f + 3.4f * hash2(k, 6)) * sc, p)
        }
        val pc = mix(hx(0xFF1F3B22), hx(0xFF050807), nf)
        palm(cv, w * 0.88f, h * 0.94f, h * 0.36f, -0.14f, t, pc)
        palm(cv, w * 1.0f, h * 1.0f, h * 0.27f, -0.22f, t + 2f, mix(hx(0xFF17301B), hx(0xFF030504), nf))
    }
}
