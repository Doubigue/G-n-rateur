import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'services/file_transfer_service.dart';
import 'services/nearby_service.dart';
import 'services/screen_share_service.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const LocalShareApp());
}

class LocalShareApp extends StatefulWidget {
  const LocalShareApp({super.key});
  @override
  State<LocalShareApp> createState() => _LocalShareAppState();
}

class _LocalShareAppState extends State<LocalShareApp> {
  // Services créés une seule fois, dès le lancement : ils écoutent les payloads
  // avant même l'ouverture de l'écran de transfert (aucun message perdu).
  late final NearbyService nearby = NearbyService();
  late final FileTransferService files = FileTransferService(nearby);
  late final ScreenShareService screen = ScreenShareService(nearby);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'LocalShare',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorSchemeSeed: Colors.indigo, useMaterial3: true),
      darkTheme: ThemeData(
        colorSchemeSeed: Colors.indigo,
        brightness: Brightness.dark,
        useMaterial3: true,
      ),
      home: HomeScreen(nearby: nearby, files: files, screen: screen),
    );
  }
}
