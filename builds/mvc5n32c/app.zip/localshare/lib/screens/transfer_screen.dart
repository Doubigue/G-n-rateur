import 'package:flutter/material.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import '../services/file_transfer_service.dart';
import '../services/nearby_service.dart';
import '../services/screen_share_service.dart';

class TransferScreen extends StatefulWidget {
  const TransferScreen({
    super.key,
    required this.nearby,
    required this.files,
    required this.screen,
  });
  final NearbyService nearby;
  final FileTransferService files;
  final ScreenShareService screen;

  @override
  State<TransferScreen> createState() => _TransferScreenState();
}

class _TransferScreenState extends State<TransferScreen> {
  @override
  void initState() {
    super.initState();
    widget.screen.init();
    widget.nearby.addListener(_watchConnection);
  }

  /// Retour automatique à l'accueil si l'autre appareil se déconnecte.
  void _watchConnection() {
    if (!widget.nearby.isConnected && mounted) Navigator.of(context).maybePop();
  }

  @override
  void dispose() {
    widget.nearby.removeListener(_watchConnection);
    super.dispose();
  }

  String _fmt(int b) {
    if (b < 1024) return '$b o';
    if (b < 1024 * 1024) return '${(b / 1024).toStringAsFixed(1)} Ko';
    if (b < 1024 * 1024 * 1024) return '${(b / 1024 / 1024).toStringAsFixed(1)} Mo';
    return '${(b / 1024 / 1024 / 1024).toStringAsFixed(2)} Go';
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final n = widget.nearby, files = widget.files, screen = widget.screen;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Connecté'),
        actions: [
          IconButton(
            tooltip: 'Se déconnecter',
            icon: const Icon(Icons.link_off),
            onPressed: () async {
              if (screen.isSharing) await screen.stopSharing();
              await n.disconnect();
            },
          ),
        ],
      ),
      body: ListenableBuilder(
        listenable: Listenable.merge([n, files, screen]),
        builder: (context, _) => Column(
          children: [
            // ----- Vue du flux d'écran distant
            Padding(
              padding: const EdgeInsets.all(16),
              child: AspectRatio(
                aspectRatio: 16 / 10,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: ColoredBox(
                    color: cs.surfaceContainerHighest,
                    child: screen.isViewing
                        ? RTCVideoView(
                            screen.remoteRenderer,
                            objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitContain,
                          )
                        : Center(
                            child: Column(mainAxisSize: MainAxisSize.min, children: [
                              Icon(Icons.cast, size: 48, color: cs.outline),
                              const SizedBox(height: 8),
                              Text(
                                screen.isSharing
                                    ? 'Votre écran est partagé'
                                    : "L'écran distant apparaîtra ici",
                                style: TextStyle(color: cs.outline),
                              ),
                            ]),
                          ),
                  ),
                ),
              ),
            ),
            // ----- Actions
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(children: [
                Expanded(
                  child: FilledButton.icon(
                    onPressed: files.pickAndSend,
                    icon: const Icon(Icons.upload_file),
                    label: const Text('Envoyer'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: FilledButton.tonalIcon(
                    onPressed: screen.isSharing ? screen.stopSharing : screen.startSharing,
                    icon: Icon(screen.isSharing ? Icons.stop_screen_share : Icons.screen_share),
                    label: Text(screen.isSharing ? 'Arrêter' : 'Partager écran'),
                  ),
                ),
              ]),
            ),
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 20, 16, 8),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text('Transferts', style: TextStyle(fontWeight: FontWeight.w600)),
              ),
            ),
            // ----- Liste des transferts avec progression
            Expanded(
              child: files.items.isEmpty
                  ? Center(child: Text('Aucun transfert', style: TextStyle(color: cs.outline)))
                  : ListView.builder(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      itemCount: files.items.length,
                      itemBuilder: (_, i) {
                        final t = files.items[i];
                        final inProgress = t.status == TransferStatus.inProgress;
                        return Card(
                          elevation: 0,
                          color: cs.surfaceContainerHigh,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                          child: Padding(
                            padding: const EdgeInsets.all(14),
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Row(children: [
                                Icon(t.outgoing ? Icons.arrow_upward : Icons.arrow_downward,
                                    size: 18, color: cs.primary),
                                const SizedBox(width: 8),
                                Expanded(child: Text(t.name, overflow: TextOverflow.ellipsis)),
                                if (t.status == TransferStatus.done)
                                  const Icon(Icons.check_circle, color: Colors.green, size: 20),
                                if (t.status == TransferStatus.failed)
                                  Icon(Icons.error, color: cs.error, size: 20),
                              ]),
                              const SizedBox(height: 10),
                              LinearProgressIndicator(
                                value: inProgress ? t.progress : 1,
                                borderRadius: BorderRadius.circular(4),
                              ),
                              const SizedBox(height: 6),
                              Text(
                                '${_fmt(t.transferred)} / ${_fmt(t.total)}'
                                '${inProgress ? "  •  ${(t.progress * 100).toStringAsFixed(0)} %" : ""}',
                                style: Theme.of(context).textTheme.bodySmall,
                              ),
                            ]),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
