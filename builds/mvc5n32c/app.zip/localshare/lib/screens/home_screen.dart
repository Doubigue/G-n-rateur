import 'package:flutter/material.dart';
import '../models/peer.dart';
import '../services/nearby_service.dart';
import '../services/file_transfer_service.dart';
import '../services/screen_share_service.dart';
import 'transfer_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({
    super.key,
    required this.nearby,
    required this.files,
    required this.screen,
  });
  final NearbyService nearby;
  final FileTransferService files;
  final ScreenShareService screen;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  NearbyService get n => widget.nearby;
  bool _transferOpen = false;

  @override
  void initState() {
    super.initState();
    n.init();
    n.addListener(_onChange);
  }

  /// Navigue automatiquement vers l'écran de transfert dès la connexion.
  void _onChange() {
    if (n.isConnected && mounted && !_transferOpen) {
      _transferOpen = true;
      Navigator.of(context)
          .push(MaterialPageRoute(
            builder: (_) => TransferScreen(
              nearby: n,
              files: widget.files,
              screen: widget.screen,
            ),
          ))
          .then((_) {
        _transferOpen = false;
        if (n.isConnected) n.disconnect();
      });
    }
  }

  @override
  void dispose() {
    n.removeListener(_onChange);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('LocalShare'), centerTitle: true),
      body: ListenableBuilder(
        listenable: n,
        builder: (context, _) => Column(
          children: [
            if (!NearbyService.supported)
              Container(
                width: double.infinity,
                margin: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: cs.errorContainer,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  'Nearby Connections est Android uniquement. Sur iOS, voir le README.',
                  style: TextStyle(color: cs.onErrorContainer),
                ),
              ),
            // ----- Boutons d'action
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(children: [
                Expanded(
                  child: FilledButton.icon(
                    onPressed: n.isAdvertising ? n.stopAdvertising : n.startAdvertising,
                    icon: Icon(n.isAdvertising ? Icons.visibility_off : Icons.visibility),
                    label: Text(n.isAdvertising ? 'Masquer' : 'Visible'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: FilledButton.tonalIcon(
                    onPressed: n.isDiscovering ? n.stopDiscovery : n.startDiscovery,
                    icon: Icon(n.isDiscovering ? Icons.stop : Icons.radar),
                    label: Text(n.isDiscovering ? 'Arrêter' : 'Scanner'),
                  ),
                ),
              ]),
            ),
            if (n.isAdvertising || n.isDiscovering) const LinearProgressIndicator(),
            // ----- Liste des appareils
            Expanded(
              child: n.peers.isEmpty
                  ? Center(
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        Icon(Icons.devices, size: 72, color: cs.outline),
                        const SizedBox(height: 12),
                        Text('Aucun appareil à proximité',
                            style: TextStyle(color: cs.outline)),
                      ]),
                    )
                  : ListView.separated(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      itemCount: n.peers.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 8),
                      itemBuilder: (_, i) => _PeerTile(peer: n.peers[i], onTap: () => n.connectTo(n.peers[i])),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PeerTile extends StatelessWidget {
  const _PeerTile({required this.peer, required this.onTap});
  final Peer peer;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Card(
      elevation: 0,
      color: cs.surfaceContainerHigh,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: cs.primaryContainer,
          child: Icon(Icons.smartphone, color: cs.onPrimaryContainer),
        ),
        title: Text(peer.name),
        subtitle: Text(switch (peer.state) {
          PeerState.discovered => 'Appuyez pour se connecter',
          PeerState.connecting => 'Connexion…',
          PeerState.connected => 'Connecté',
        }),
        trailing: peer.state == PeerState.connecting
            ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
            : Icon(peer.state == PeerState.connected ? Icons.check_circle : Icons.chevron_right,
                color: peer.state == PeerState.connected ? Colors.green : null),
        onTap: peer.state == PeerState.discovered ? onTap : null,
      ),
    );
  }
}
