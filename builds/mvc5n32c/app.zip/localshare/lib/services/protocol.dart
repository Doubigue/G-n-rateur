import 'dart:convert';
import 'dart:typed_data';
import 'package:nearby_connections/nearby_connections.dart';

/// Messages JSON échangés en BYTES payload (max ~32 Ko par message).
///   {"t":"file","id":<payloadId>,"name":"x.mp4","size":123}   métadonnées fichier
///   {"t":"offer"|"answer","sdp":"...","type":"..."}            signalisation WebRTC
///   {"t":"ice","c":{candidate,sdpMid,sdpMLineIndex}}           candidat ICE
///   {"t":"ss_stop"}                                            fin du partage d'écran
class Protocol {
  static Uint8List encode(Map<String, dynamic> m) =>
      Uint8List.fromList(utf8.encode(jsonEncode(m)));

  /// Retourne null si le payload n'est pas un message JSON valide.
  static Map<String, dynamic>? decode(Payload p) {
    if (p.type != PayloadType.BYTES || p.bytes == null) return null;
    try {
      final d = jsonDecode(utf8.decode(p.bytes!));
      return d is Map<String, dynamic> ? d : null;
    } catch (_) {
      return null;
    }
  }
}
