import 'dart:async';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:nearby_connections/nearby_connections.dart';
import 'package:path_provider/path_provider.dart';
import 'nearby_service.dart';
import 'protocol.dart';

enum TransferStatus { inProgress, done, failed }

class TransferItem {
  TransferItem({
    required this.payloadId,
    required this.name,
    required this.outgoing,
    this.total = 0,
  });
  final int payloadId;
  String name;
  final bool outgoing;
  int total;
  int transferred = 0;
  TransferStatus status = TransferStatus.inProgress;
  String? savedPath; // destination finale (réception)

  double get progress => total == 0 ? 0 : (transferred / total).clamp(0.0, 1.0);
}

/// Envoi / réception de fichiers via les payloads Nearby.
/// Les fichiers sont streamés par Nearby : pas de limite de taille pratique,
/// et la progression est fournie des deux côtés.
class FileTransferService extends ChangeNotifier {
  FileTransferService(this._nearby) {
    _subs.add(_nearby.onPayload.listen(_onPayload));
    _subs.add(_nearby.onProgress.listen(_onProgress));
  }

  final NearbyService _nearby;
  final List<StreamSubscription> _subs = [];
  final Map<int, TransferItem> _items = {};
  final Map<int, String> _names = {}; // payloadId -> nom d'origine (métadonnées)
  final Map<int, String> _sources = {}; // payloadId -> uri/chemin temporaire reçu

  /// Plus récents en premier.
  List<TransferItem> get items => _items.values.toList().reversed.toList();

  // ------------------------------------------------------------------ envoi
  Future<void> pickAndSend() async {
    final res = await FilePicker.platform.pickFiles(allowMultiple: true);
    if (res == null) return;

    for (final f in res.files) {
      final path = f.path;
      if (path == null) continue;
      final id = await _nearby.sendFile(path);
      if (id == null) continue;

      _items[id] = TransferItem(
        payloadId: id,
        name: f.name,
        outgoing: true,
        total: f.size,
      );
      notifyListeners();

      // Métadonnées (nom du fichier) envoyées dans un second payload.
      await _nearby.sendBytes(
        Protocol.encode({'t': 'file', 'id': id, 'name': f.name, 'size': f.size}),
      );
    }
  }

  // -------------------------------------------------------------- réception
  void _onPayload((String, Payload) event) {
    final payload = event.$2;

    if (payload.type == PayloadType.BYTES) {
      final msg = Protocol.decode(payload);
      if (msg == null || msg['t'] != 'file') return;
      final id = msg['id'] as int;
      _names[id] = msg['name'] as String;
      _items[id]?.name = _names[id]!;
      notifyListeners();
    } else if (payload.type == PayloadType.FILE) {
      _sources[payload.id] = payload.uri ?? payload.filePath ?? '';
      _items[payload.id] = TransferItem(
        payloadId: payload.id,
        name: _names[payload.id] ?? 'Réception…',
        outgoing: false,
      );
      notifyListeners();
    }
  }

  Future<void> _onProgress((String, PayloadTransferUpdate) event) async {
    final u = event.$2;
    final item = _items[u.id];
    if (item == null) return; // payload bytes (signalisation) : ignoré

    item.total = u.totalBytes > 0 ? u.totalBytes : item.total;
    item.transferred = u.bytesTransferred;

    switch (u.status) {
      case PayloadStatus.IN_PROGRESS:
        break;
      case PayloadStatus.SUCCESS:
        item.transferred = item.total;
        if (item.outgoing) {
          item.status = TransferStatus.done;
        } else {
          await _saveReceived(item);
        }
        break;
      case PayloadStatus.FAILURE:
      case PayloadStatus.CANCELED:
        item.status = TransferStatus.failed;
        break;
      default:
        break;
    }
    notifyListeners();
  }

  /// Déplace le fichier reçu (dossier temporaire Nearby) vers le dossier final.
  Future<void> _saveReceived(TransferItem item) async {
    try {
      final base = await getExternalStorageDirectory() ??
          await getApplicationDocumentsDirectory();
      final dir = Directory('${base.path}/Received');
      await dir.create(recursive: true);

      final name = _names[item.payloadId] ?? 'file_${item.payloadId}';
      item.name = name;
      final dest = _uniquePath(dir.path, name);

      final ok = await _nearby.moveReceivedFile(_sources[item.payloadId] ?? '', dest);
      item.savedPath = ok ? dest : null;
      item.status = ok ? TransferStatus.done : TransferStatus.failed;
    } catch (e) {
      debugPrint('saveReceived error: $e');
      item.status = TransferStatus.failed;
    }
  }

  String _uniquePath(String dir, String name) {
    var path = '$dir/$name';
    var i = 1;
    final dot = name.lastIndexOf('.');
    final stem = dot > 0 ? name.substring(0, dot) : name;
    final ext = dot > 0 ? name.substring(dot) : '';
    while (File(path).existsSync()) {
      path = '$dir/$stem ($i)$ext';
      i++;
    }
    return path;
  }

  @override
  void dispose() {
    for (final s in _subs) {
      s.cancel();
    }
    super.dispose();
  }
}
