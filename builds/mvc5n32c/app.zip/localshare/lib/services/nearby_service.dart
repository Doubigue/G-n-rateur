import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:nearby_connections/nearby_connections.dart';
import 'package:permission_handler/permission_handler.dart';
import '../models/peer.dart';

/// Rôle de cet appareil dans la session.
enum NearbyRole { none, host, client }

/// Gère découverte, connexion et échange de payloads.
/// Host  = celui qui s'annonce (advertising)
/// Client = celui qui scanne (discovery) et demande la connexion
class NearbyService extends ChangeNotifier {
  static const _serviceId = 'com.example.localshare'; // = applicationId
  static const _strategy = Strategy.P2P_POINT_TO_POINT; // 1-à-1, meilleur débit

  final Nearby _nearby = Nearby();
  final Map<String, Peer> _peers = {};
  NearbyRole role = NearbyRole.none;
  bool isAdvertising = false;
  bool isDiscovering = false;
  String? connectedId;
  String deviceName = 'Appareil';

  /// Flux de payloads reçus (bytes = signalisation / métadonnées, file = fichier)
  final _payloadCtrl = StreamController<(String, Payload)>.broadcast();
  final _progressCtrl = StreamController<(String, PayloadTransferUpdate)>.broadcast();
  Stream<(String, Payload)> get onPayload => _payloadCtrl.stream;
  Stream<(String, PayloadTransferUpdate)> get onProgress => _progressCtrl.stream;

  List<Peer> get peers => _peers.values.toList();
  bool get isConnected => connectedId != null;

  /// nearby_connections n'existe que sur Android (voir README pour iOS).
  static bool get supported => Platform.isAndroid;

  // ---------------------------------------------------------------- init
  Future<void> init() async {
    if (Platform.isAndroid) {
      final info = await DeviceInfoPlugin().androidInfo;
      deviceName = '${info.brand} ${info.model}';
    }
  }

  /// Demande toutes les permissions nécessaires selon la version d'Android.
  Future<bool> requestPermissions() async {
    final perms = <Permission>[
      Permission.location,
      Permission.bluetooth,
      Permission.bluetoothAdvertise,
      Permission.bluetoothConnect,
      Permission.bluetoothScan,
      Permission.nearbyWifiDevices, // Android 13+
    ];
    final res = await perms.request();
    // Certaines permissions n'existent pas selon la version : on tolère "restricted"
    final critical = [Permission.location, Permission.bluetoothScan, Permission.bluetoothConnect];
    return critical.every((p) => res[p]?.isGranted ?? true);
  }

  // ------------------------------------------------------- advertising (Hôte)
  Future<void> startAdvertising() async {
    if (!supported) return;
    if (!await requestPermissions()) return;
    try {
      isAdvertising = await _nearby.startAdvertising(
        deviceName,
        _strategy,
        serviceId: _serviceId,
        onConnectionInitiated: _onConnectionInitiated,
        onConnectionResult: _onConnectionResult,
        onDisconnected: _onDisconnected,
      );
      if (isAdvertising) role = NearbyRole.host;
    } catch (e) {
      debugPrint('startAdvertising error: $e');
    }
    notifyListeners();
  }

  Future<void> stopAdvertising() async {
    await _nearby.stopAdvertising();
    isAdvertising = false;
    notifyListeners();
  }

  // --------------------------------------------------------- discovery (Client)
  Future<void> startDiscovery() async {
    if (!supported) return;
    if (!await requestPermissions()) return;
    _peers.removeWhere((_, p) => p.state != PeerState.connected);
    try {
      isDiscovering = await _nearby.startDiscovery(
        deviceName,
        _strategy,
        serviceId: _serviceId,
        onEndpointFound: (id, name, _) {
          _peers[id] = Peer(id, name);
          notifyListeners();
        },
        onEndpointLost: (id) {
          if (id != null) _peers.remove(id);
          notifyListeners();
        },
      );
    } catch (e) {
      debugPrint('startDiscovery error: $e');
    }
    notifyListeners();
  }

  Future<void> stopDiscovery() async {
    await _nearby.stopDiscovery();
    isDiscovering = false;
    notifyListeners();
  }

  // ------------------------------------------------------------- connexion
  Future<void> connectTo(Peer peer) async {
    peer.state = PeerState.connecting;
    notifyListeners();
    try {
      await _nearby.requestConnection(
        deviceName,
        peer.id,
        onConnectionInitiated: _onConnectionInitiated,
        onConnectionResult: _onConnectionResult,
        onDisconnected: _onDisconnected,
      );
      role = NearbyRole.client;
    } catch (e) {
      peer.state = PeerState.discovered;
      debugPrint('requestConnection error: $e');
      notifyListeners();
    }
  }

  /// Acceptation automatique des deux côtés (style AirDrop "tout le monde").
  /// Pour plus de sécurité : afficher info.authenticationToken et demander confirmation.
  void _onConnectionInitiated(String id, ConnectionInfo info) {
    _peers.putIfAbsent(id, () => Peer(id, info.endpointName));
    _peers[id]!.state = PeerState.connecting;
    notifyListeners();

    _nearby.acceptConnection(
      id,
      onPayLoadRecieved: (endpointId, payload) => _payloadCtrl.add((endpointId, payload)),
      onPayloadTransferUpdate: (endpointId, update) => _progressCtrl.add((endpointId, update)),
    );
  }

  void _onConnectionResult(String id, Status status) {
    if (status == Status.CONNECTED) {
      connectedId = id;
      _peers[id]?.state = PeerState.connected;
      // Une fois connecté, on arrête de s'annoncer / scanner (économie batterie)
      _nearby.stopAdvertising();
      _nearby.stopDiscovery();
      isAdvertising = isDiscovering = false;
    } else {
      _peers[id]?.state = PeerState.discovered;
      role = NearbyRole.none;
    }
    notifyListeners();
  }

  void _onDisconnected(String id) {
    _peers.remove(id);
    if (connectedId == id) connectedId = null;
    role = NearbyRole.none;
    notifyListeners();
  }

  Future<void> disconnect() async {
    if (connectedId != null) await _nearby.disconnectFromEndpoint(connectedId!);
    await _nearby.stopAllEndpoints();
    connectedId = null;
    role = NearbyRole.none;
    _peers.clear();
    notifyListeners();
  }

  // --------------------------------------------------------------- envoi
  Future<void> sendBytes(Uint8List data) async {
    if (connectedId != null) await _nearby.sendBytesPayload(connectedId!, data);
  }

  /// Retourne l'id du payload (pour suivre la progression).
  Future<int?> sendFile(String path) async {
    if (connectedId == null) return null;
    return _nearby.sendFilePayload(connectedId!, path);
  }

  /// Android 10+ : les fichiers reçus arrivent dans un dossier temporaire,
  /// il faut les déplacer vers leur emplacement final.
  /// [sourceUri] = payload.uri (Android 10+) ou payload.filePath.
  Future<bool> moveReceivedFile(String sourceUri, String destPath) =>
      _nearby.copyFileAndDeleteOriginal(sourceUri, destPath);

  @override
  void dispose() {
    _payloadCtrl.close();
    _progressCtrl.close();
    super.dispose();
  }
}
