enum PeerState { discovered, connecting, connected }

class Peer {
  final String id;
  final String name;
  PeerState state;
  Peer(this.id, this.name, {this.state = PeerState.discovered});
}
