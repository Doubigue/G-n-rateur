import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';

/// Protection anti-plantage : avant chaque étape « native » risquée on écrit
/// son nom dans un fichier. Si l'appli est tuée pendant l'étape, le nom reste
/// là ; au lancement suivant l'étape fautive est désactivée (au lieu de
/// replanter en boucle) et un message l'indique.
class CrashGuard {
  CrashGuard._();

  static File? _mark;
  static File? _off;
  static final Set<String> disabled = {};
  static String? notice;
  static int _token = 0;

  static const _labels = {
    'notifications': 'les notifications',
    'advertise': 'la visibilité (advertising)',
    'discover': 'la recherche d\u2019appareils',
    'foreground_service': 'le service d\u2019arrière-plan',
  };

  static Future<void> init() async {
    try {
      final d = await getApplicationDocumentsDirectory();
      _mark = File('${d.path}/boot_step.txt');
      _off = File('${d.path}/disabled_steps.txt');
      if (await _off!.exists()) {
        disabled.addAll((await _off!.readAsLines()).where((l) => l.trim().isNotEmpty));
      }
      if (await _mark!.exists()) {
        final s = (await _mark!.readAsString()).trim();
        if (s.isNotEmpty && s != 'ok') {
          disabled.add(s);
          await _off!.writeAsString(disabled.join('\n'), flush: true);
          await _mark!.writeAsString('ok', flush: true);
        }
      }
      if (disabled.isNotEmpty) {
        notice = 'Protection anti-plantage : ${disabled.map((e) => _labels[e] ?? e).join(', ')} '
            '${disabled.length > 1 ? 'ont été désactivés' : 'a été désactivé'} car '
            '${disabled.length > 1 ? 'ils ont' : 'il a'} fait fermer l\u2019appli. '
            'Étape fautive : ${disabled.join(', ')}.';
      }
    } catch (e) {
      debugPrint('CrashGuard.init: $e');
    }
  }

  static Future<void> _write(String s) async {
    try {
      await _mark?.writeAsString(s, flush: true);
    } catch (_) {}
  }

  /// Exécute [fn] sous surveillance. Retourne null si l'étape est désactivée.
  static Future<T?> run<T>(String step, Future<T> Function() fn) async {
    if (disabled.contains(step)) return null;
    final my = ++_token;
    await _write(step);
    try {
      return await fn();
    } finally {
      // Un crash natif arrive parfois quelques ms après le retour : on attend.
      Future.delayed(const Duration(seconds: 4), () {
        if (_token == my) _write('ok');
      });
    }
  }
}
