import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';
import '../services/nearby_service.dart';

/// Feuille affichant le QR code de cet appareil (visible tant qu'il est « Visible »).
class QrSheet extends StatefulWidget {
  const QrSheet({super.key, required this.nearby});
  final NearbyService nearby;

  @override
  State<QrSheet> createState() => _QrSheetState();
}

class _QrSheetState extends State<QrSheet> {
  bool _closing = false;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return ListenableBuilder(
      listenable: widget.nearby,
      builder: (context, _) {
        final qr = widget.nearby.myQr;
        if (qr == null) {
          if (!_closing) {
            _closing = true;
            WidgetsBinding.instance.addPostFrameCallback((_) {
              if (mounted && Navigator.of(context).canPop()) Navigator.of(context).pop();
            });
          }
          return const SizedBox(height: 80);
        }
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(24, 8, 24, 20),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Text('Mon QR code', style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 4),
              Text(
                'Scannez-le avec l\u2019autre appareil pour vous connecter instantanément.',
                textAlign: TextAlign.center,
                style: TextStyle(color: cs.outline),
              ),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: QrImageView(
                  data: qr.encode(),
                  size: 240,
                  backgroundColor: Colors.white,
                  errorCorrectionLevel: QrErrorCorrectLevel.M,
                ),
              ),
              const SizedBox(height: 12),
              Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.smartphone, size: 18, color: cs.primary),
                const SizedBox(width: 6),
                Text(qr.name, style: const TextStyle(fontWeight: FontWeight.w600)),
              ]),
              const SizedBox(height: 16),
              OutlinedButton.icon(
                onPressed: widget.nearby.stopAdvertising,
                icon: const Icon(Icons.visibility_off),
                label: const Text('Ne plus être visible'),
              ),
            ]),
          ),
        );
      },
    );
  }
}
