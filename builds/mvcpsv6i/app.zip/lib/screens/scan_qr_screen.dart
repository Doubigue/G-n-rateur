import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import '../models/qr_payload.dart';

/// Scanner de QR code. Retourne le texte brut du QR (via Navigator.pop).
class ScanQrScreen extends StatefulWidget {
  const ScanQrScreen({super.key});
  @override
  State<ScanQrScreen> createState() => _ScanQrScreenState();
}

class _ScanQrScreenState extends State<ScanQrScreen> with SingleTickerProviderStateMixin {
  final MobileScannerController _ctrl = MobileScannerController(
    formats: const [BarcodeFormat.qrCode],
    detectionSpeed: DetectionSpeed.noDuplicates,
  );
  late final AnimationController _line =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 2200))
        ..repeat(reverse: true);
  bool _done = false;
  bool _torch = false;
  String? _err;

  void _onDetect(BarcodeCapture cap) {
    if (_done) return;
    for (final b in cap.barcodes) {
      final raw = b.rawValue;
      if (raw == null) continue;
      if (QrPayload.parse(raw) != null) {
        _done = true;
        HapticFeedback.mediumImpact();
        Navigator.of(context).pop(raw);
        return;
      }
    }
    setState(() => _err = 'Ce QR code n\u2019est pas un code LocalShare.');
  }

  @override
  void dispose() {
    _line.dispose();
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        foregroundColor: Colors.white,
        title: const Text('Scanner un QR code'),
        actions: [
          IconButton(
            tooltip: 'Lampe',
            icon: Icon(_torch ? Icons.flash_on : Icons.flash_off),
            onPressed: () async {
              await _ctrl.toggleTorch();
              setState(() => _torch = !_torch);
            },
          ),
        ],
      ),
      body: Stack(fit: StackFit.expand, children: [
        MobileScanner(
          controller: _ctrl,
          onDetect: _onDetect,
          errorBuilder: (context, error, _) => const Center(
            child: Padding(
              padding: EdgeInsets.all(32),
              child: Text(
                'Caméra indisponible. Autorisez l\u2019accès à la caméra dans les réglages.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white),
              ),
            ),
          ),
        ),
        AnimatedBuilder(
          animation: _line,
          builder: (_, __) => CustomPaint(painter: _OverlayPainter(_line.value)),
        ),
        Positioned(
          left: 24,
          right: 24,
          bottom: 56,
          child: Text(
            _err ?? 'Placez le QR code de l\u2019autre appareil dans le cadre.',
            textAlign: TextAlign.center,
            style: TextStyle(color: _err != null ? Colors.amberAccent : Colors.white, fontSize: 15),
          ),
        ),
      ]),
    );
  }
}

class _OverlayPainter extends CustomPainter {
  _OverlayPainter(this.progress);
  final double progress;

  @override
  void paint(Canvas canvas, Size size) {
    final side = size.shortestSide * 0.68;
    final box = Rect.fromCenter(
      center: Offset(size.width / 2, size.height * 0.45),
      width: side,
      height: side,
    );
    final rr = RRect.fromRectAndRadius(box, const Radius.circular(24));

    // Voile sombre avec découpe
    canvas.drawPath(
      Path.combine(
        PathOperation.difference,
        Path()..addRect(Offset.zero & size),
        Path()..addRRect(rr),
      ),
      Paint()..color = Colors.black.withOpacity(0.6),
    );

    // Coins
    const cyan = Color(0xFF00E5FF);
    final p = Paint()
      ..color = cyan
      ..style = PaintingStyle.stroke
      ..strokeWidth = 5
      ..strokeCap = StrokeCap.round;
    const l = 34.0;
    for (final (dx, dy) in [(-1, -1), (1, -1), (1, 1), (-1, 1)]) {
      final corner = Offset(dx < 0 ? box.left : box.right, dy < 0 ? box.top : box.bottom);
      canvas.drawLine(corner, corner + Offset(-dx * l, 0), p);
      canvas.drawLine(corner, corner + Offset(0, -dy * l), p);
    }

    // Ligne de balayage
    final y = box.top + 12 + (box.height - 24) * progress;
    canvas.drawLine(
      Offset(box.left + 14, y),
      Offset(box.right - 14, y),
      Paint()
        ..strokeWidth = 3
        ..shader = LinearGradient(colors: [
          cyan.withOpacity(0),
          cyan,
          cyan.withOpacity(0),
        ]).createShader(Rect.fromLTWH(box.left, y, box.width, 1)),
    );
  }

  @override
  bool shouldRepaint(covariant _OverlayPainter old) => old.progress != progress;
}
