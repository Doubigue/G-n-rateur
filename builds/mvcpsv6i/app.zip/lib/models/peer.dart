enum PeerState { discovered, connecting, connected }

class Peer {
  final String id;
  final String name;

  /// Identifiant public court annoncé par l'hôte (sert à retrouver l'appareil
  /// après un scan de QR code). Ce n'est PAS le secret.
  final String rid;
  PeerState state;

  Peer(this.id, this.name, {this.rid = '', this.state = PeerState.discovered});
}
