/// Contenu du QR code affiché par l'appareil « Visible ».
///   doubigue://join?r=<rid>&k=<secret>&n=<nom>&v=1
/// - rid    : identifiant public annoncé en Nearby (permet de retrouver l'appareil)
/// - secret : jeton aléatoire à usage de session, présent UNIQUEMENT dans le QR.
///            Celui qui le présente est accepté automatiquement, les autres
///            doivent être validés manuellement par l'hôte.
class QrPayload {
  QrPayload({required this.rid, required this.secret, required this.name});
  final String rid;
  final String secret;
  final String name;

  String encode() => Uri(
        scheme: 'doubigue',
        host: 'join',
        queryParameters: {'r': rid, 'k': secret, 'n': name, 'v': '1'},
      ).toString();

  static QrPayload? parse(String raw) {
    try {
      final u = Uri.parse(raw.trim());
      if (u.scheme != 'doubigue' || u.host != 'join') return null;
      final r = u.queryParameters['r'];
      final k = u.queryParameters['k'];
      if (r == null || r.isEmpty || k == null || k.isEmpty) return null;
      return QrPayload(rid: r, secret: k, name: u.queryParameters['n'] ?? 'Appareil');
    } catch (_) {
      return null;
    }
  }
}
