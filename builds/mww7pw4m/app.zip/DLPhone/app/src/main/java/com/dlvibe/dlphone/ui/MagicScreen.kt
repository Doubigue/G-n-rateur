package com.dlvibe.dlphone.ui

import android.os.Build
import android.provider.CallLog
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dlvibe.dlphone.CallEntry
import com.dlvibe.dlphone.Prefs
import java.util.Calendar

@Composable
fun MagicScreen(
    calls: List<CallEntry>,
    isDefault: Boolean,
    onRequestDefault: () -> Unit,
    onRequestScreening: () -> Unit
) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { ScreenHeader("Magie ✦", "Les pouvoirs cachés de DL Phone") }
        item { StatsCard(calls) }
        item { StyleCard() }
        item { EffectsCard(isDefault, onRequestDefault) }
        item { ShieldCard(onRequestScreening) }
        item { RepliesCard() }
        item { SpeedDialCard() }
        item { Signature() }
    }
}

@Composable
private fun MagicSwitch(icon: ImageVector, title: String, sub: String, initial: Boolean, onChange: (Boolean) -> Unit) {
    val p = LocalPalette.current
    var v by remember { mutableStateOf(initial) }
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { v = !v; onChange(v) }
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconPill(icon, p.accent, 38.dp)
        Column(
            Modifier
                .weight(1f)
                .padding(horizontal = 12.dp)
        ) {
            Text(title, color = p.text, fontWeight = FontWeight.Medium)
            Text(sub, color = p.muted, fontSize = 12.sp)
        }
        Switch(
            checked = v,
            onCheckedChange = { v = it; onChange(it) },
            colors = SwitchDefaults.colors(
                checkedThumbColor = p.onAccent, checkedTrackColor = p.accent,
                uncheckedThumbColor = p.muted, uncheckedTrackColor = p.surface2, uncheckedBorderColor = p.line
            )
        )
    }
}

@Composable
private fun StatsCard(calls: List<CallEntry>) {
    val p = LocalPalette.current
    val stats = remember(calls) {
        val since = System.currentTimeMillis() - 30L * 24 * 3600 * 1000
        val recent = calls.filter { it.date >= since }
        val talk = recent.sumOf { it.duration }
        val missed = recent.count { it.type == CallLog.Calls.MISSED_TYPE }
        val top = recent.filter { it.number.isNotBlank() }
            .groupBy { Prefs.norm(it.number) }
            .map { (_, l) -> (l.firstOrNull { it.name != null }?.name ?: l.first().number) to l.size }
            .sortedByDescending { it.second }
            .take(3)
        val start = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
        val dayMs = 24L * 3600 * 1000
        val days = (6 downTo 0).map { d ->
            val from = start - d * dayMs
            val letter = Calendar.getInstance().apply { timeInMillis = from }.get(Calendar.DAY_OF_WEEK)
            val names = arrayOf("", "D", "L", "M", "M", "J", "V", "S")
            names[letter] to calls.count { it.date >= from && it.date < from + dayMs }
        }
        Stats(recent.size, talk, missed, top, days)
    }
    DlCard {
        SectionLabel("📊 Vos 30 derniers jours")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            StatBox("${stats.total}", "appels")
            StatBox(durationShort(stats.talk), "de conversation")
            StatBox("${stats.missed}", "manqués")
        }
        Spacer(Modifier.height(14.dp))
        val max = (stats.days.maxOfOrNull { it.second } ?: 0).coerceAtLeast(1)
        Row(
            Modifier
                .fillMaxWidth()
                .height(90.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            stats.days.forEach { (label, n) ->
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$n", color = p.muted, fontSize = 10.sp)
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height((4 + 56f * n / max).dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(Brush.verticalGradient(listOf(p.accent, p.accent.copy(alpha = 0.35f))))
                    )
                    Text(label, color = p.muted, fontSize = 11.sp)
                }
            }
        }
        if (stats.top.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Text("Vos contacts les plus appelés", color = p.muted, fontSize = 12.sp)
            stats.top.forEachIndexed { i, (who, n) ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("${i + 1}", color = p.accent, fontWeight = FontWeight.Black, modifier = Modifier.width(22.dp))
                    Avatar(who, 30.dp)
                    Text(who, color = p.text, modifier = Modifier
                        .weight(1f)
                        .padding(start = 10.dp), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("$n appels", color = p.muted, fontSize = 12.sp)
                }
            }
        }
    }
}

private data class Stats(
    val total: Int,
    val talk: Long,
    val missed: Int,
    val top: List<Pair<String, Int>>,
    val days: List<Pair<String, Int>>
)

private fun durationShort(s: Long): String = when {
    s < 60 -> "${s}s"
    s < 3600 -> "${s / 60} min"
    else -> "${s / 3600}h${"%02d".format((s % 3600) / 60)}"
}

@Composable
private fun StatBox(value: String, label: String) {
    val p = LocalPalette.current
    Column {
        Text(value, color = p.text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text(label, color = p.muted, fontSize = 11.sp)
    }
}

@Composable
private fun StyleCard() {
    val p = LocalPalette.current
    DlCard {
        SectionLabel("🎨 Style DL VIBE")
        Text("Touchez une affiche pour changer les couleurs de l'appli.", color = p.muted, fontSize = 12.sp)
        Spacer(Modifier.height(10.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            itemsIndexed(Palettes) { i, s ->
                Column(
                    Modifier
                        .width(64.dp)
                        .clickable {
                            ThemeState.index = i
                            Prefs.style = i
                        },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(Brush.verticalGradient(listOf(s.bg, s.bg2)))
                            .border(if (ThemeState.index == i) 3.dp else 1.dp, if (ThemeState.index == i) p.accent else p.line, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            Modifier
                                .size(20.dp)
                                .clip(CircleShape)
                                .background(s.accent)
                        )
                    }
                    Text(s.name, color = p.text, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
        MagicSwitch(Icons.Filled.Shuffle, "Style surprise", "Un style au hasard à chaque ouverture", Prefs.randomStyle) {
            Prefs.randomStyle = it
        }
    }
}

@Composable
private fun EffectsCard(isDefault: Boolean, onRequestDefault: () -> Unit) {
    val p = LocalPalette.current
    DlCard {
        SectionLabel("✨ Effets magiques")
        if (!isDefault) {
            Text(
                "Ces effets marchent quand DL Phone est l'appli Téléphone par défaut.",
                color = p.muted, fontSize = 12.sp
            )
            TextButton(onClick = onRequestDefault) { Text("Définir par défaut", color = p.accent) }
        }
        MagicSwitch(Icons.Filled.FlashOn, "Flash magique", "Le flash clignote quand on vous appelle", Prefs.flash) { Prefs.flash = it }
        MagicSwitch(Icons.Filled.RecordVoiceOver, "Annonce vocale", "Le téléphone dit qui vous appelle", Prefs.announce) { Prefs.announce = it }
        MagicSwitch(Icons.Filled.ScreenRotation, "Retourner = silence", "Posez le téléphone face cachée pour couper la sonnerie", Prefs.flipToSilence) { Prefs.flipToSilence = it }
        MagicSwitch(Icons.Filled.Vibration, "Vibration de décroché", "Vibre quand votre correspondant répond", Prefs.vibrateOnConnect) { Prefs.vibrateOnConnect = it }
        MagicSwitch(Icons.Filled.NotificationsActive, "Appels manqués", "Notification avec « Rappeler » et « Dans 10 min »", Prefs.missedNotif) { Prefs.missedNotif = it }
    }
}

@Composable
private fun ShieldCard(onRequestScreening: () -> Unit) {
    val p = LocalPalette.current
    var list by remember { mutableStateOf(Prefs.blacklist()) }
    var input by remember { mutableStateOf("") }
    DlCard {
        SectionLabel("🛡️ Bouclier anti-indésirables")
        Text("${Prefs.blockedCount} appel(s) déjà bloqué(s)", color = p.muted, fontSize = 12.sp)
        MagicSwitch(Icons.Filled.VisibilityOff, "Bloquer les numéros masqués", "Rejette les appels sans numéro", Prefs.blockHidden) { Prefs.blockHidden = it }
        MagicSwitch(Icons.Filled.PersonOff, "Bloquer les inconnus", "Seuls vos contacts peuvent vous appeler", Prefs.blockUnknown) { Prefs.blockUnknown = it }
        if (Build.VERSION.SDK_INT >= 29) {
            TextButton(onClick = onRequestScreening) { Text("Activer le filtrage avant la sonnerie", color = p.accent) }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                placeholder = { Text("Numéro à bloquer") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                shape = RoundedCornerShape(16.dp),
                colors = dlTextFieldColors(),
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = {
                if (input.isNotBlank()) {
                    Prefs.block(input); input = ""; list = Prefs.blacklist()
                }
            }) { Icon(Icons.Filled.Add, "Ajouter", tint = p.accent) }
        }
        list.forEach { n ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Block, null, tint = p.muted, modifier = Modifier.size(18.dp))
                Text(n, color = p.text, modifier = Modifier
                    .weight(1f)
                    .padding(start = 10.dp))
                IconButton(onClick = { Prefs.unblock(n); list = Prefs.blacklist() }) {
                    Icon(Icons.Filled.Delete, "Retirer", tint = p.muted)
                }
            }
        }
    }
}

@Composable
private fun RepliesCard() {
    val p = LocalPalette.current
    var list by remember { mutableStateOf(Prefs.quickReplies()) }
    var input by remember { mutableStateOf("") }
    DlCard {
        SectionLabel("💬 Réponses rapides par SMS")
        Text("Envoyées en un geste quand vous refusez un appel.", color = p.muted, fontSize = 12.sp)
        list.forEach { r ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("« $r »", color = p.text, fontSize = 14.sp, modifier = Modifier.weight(1f))
                IconButton(onClick = {
                    list = list - r; Prefs.setQuickReplies(list)
                }) { Icon(Icons.Filled.Delete, "Retirer", tint = p.muted) }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it.replace("\n", " ") },
                placeholder = { Text("Nouvelle réponse") },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                colors = dlTextFieldColors(),
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = {
                if (input.isNotBlank()) {
                    list = list + input.trim(); Prefs.setQuickReplies(list); input = ""
                }
            }) { Icon(Icons.Filled.Add, "Ajouter", tint = p.accent) }
        }
    }
}

@Composable
private fun SpeedDialCard() {
    val p = LocalPalette.current
    var refresh by remember { mutableIntStateOf(0) }
    val slots = remember(refresh) { (2..9).map { it to Prefs.speedDial(it) } }
    DlCard {
        SectionLabel("⚡ Numérotation rapide")
        Text(
            "Sur le clavier, tapez un numéro puis restez appuyé sur 2 à 9 pour l'enregistrer. Ensuite, un appui long suffit pour appeler.",
            color = p.muted, fontSize = 12.sp
        )
        slots.filter { it.second != null }.forEach { (d, n) ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(p.accent),
                    contentAlignment = Alignment.Center
                ) { Text("$d", color = p.onAccent, fontWeight = FontWeight.Bold) }
                Text(n ?: "", color = p.text, modifier = Modifier
                    .weight(1f)
                    .padding(start = 12.dp))
                IconButton(onClick = { Prefs.setSpeedDial(d, null); refresh++ }) {
                    Icon(Icons.Filled.Delete, "Retirer", tint = p.muted)
                }
            }
        }
        if (slots.none { it.second != null }) {
            Text("Aucune touche enregistrée.", color = p.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
        }
    }
}
