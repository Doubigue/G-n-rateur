package com.dlvibe.dlphone

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioAttributes
import android.os.Build
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.tts.TextToSpeech
import android.telecom.TelecomManager
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

/** Les effets « magiques » déclenchés pendant les appels. */
object MagicEffects {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var flashJob: Job? = null
    private var tts: TextToSpeech? = null
    private var sensorManager: SensorManager? = null
    private var flipListener: SensorEventListener? = null

    fun onIncoming(ctx: Context, number: String, name: String?) {
        val app = ctx.applicationContext
        if (Prefs.flash) startFlash(app)
        if (Prefs.announce) announce(app, name ?: spell(number))
        if (Prefs.flipToSilence) startFlip(app)
    }

    private fun spell(n: String): String =
        if (n.isBlank()) "un numéro masqué"
        else "le " + n.filter { it.isDigit() }.chunked(2).joinToString(", ")

    /** 🔦 Le flash clignote au rythme de l'appel. */
    private fun startFlash(ctx: Context) {
        flashJob?.cancel()
        val cm = ctx.getSystemService(CameraManager::class.java) ?: return
        val id = try {
            cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
        } catch (_: Exception) {
            null
        } ?: return
        flashJob = scope.launch {
            try {
                repeat(150) { i ->
                    runCatching { cm.setTorchMode(id, true) }
                    delay(110)
                    runCatching { cm.setTorchMode(id, false) }
                    delay(if (i % 3 == 2) 600 else 140)
                }
            } finally {
                runCatching { cm.setTorchMode(id, false) }
            }
        }
    }

    /** 🗣️ Annonce vocale du nom de l'appelant. */
    private fun announce(ctx: Context, who: String) {
        stopTts()
        var engine: TextToSpeech? = null
        engine = TextToSpeech(ctx) { status ->
            val t = engine
            if (t != null && status == TextToSpeech.SUCCESS) {
                t.setLanguage(Locale.FRENCH)
                t.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                t.speak("Appel de $who", TextToSpeech.QUEUE_FLUSH, null, "dl1")
                t.playSilentUtterance(1500, TextToSpeech.QUEUE_ADD, "dl_pause")
                t.speak("Appel de $who", TextToSpeech.QUEUE_ADD, null, "dl2")
            }
        }
        tts = engine
    }

    /** 🙃 Retourner le téléphone face contre table coupe la sonnerie. */
    private fun startFlip(ctx: Context) {
        stopFlip()
        val sm = ctx.getSystemService(SensorManager::class.java) ?: return
        val acc = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return
        val l = object : SensorEventListener {
            var seenUp = false
            var downSince = 0L
            override fun onSensorChanged(e: SensorEvent) {
                val z = e.values[2]
                when {
                    z > 3f -> {
                        seenUp = true; downSince = 0L
                    }

                    z < -8f && seenUp -> {
                        val now = SystemClock.elapsedRealtime()
                        if (downSince == 0L) downSince = now
                        else if (now - downSince > 400) silence(ctx)
                    }

                    else -> downSince = 0L
                }
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }
        sm.registerListener(l, acc, SensorManager.SENSOR_DELAY_UI)
        sensorManager = sm
        flipListener = l
    }

    fun silence(ctx: Context) {
        try {
            ctx.getSystemService(TelecomManager::class.java)?.silenceRinger()
        } catch (_: Exception) {
        }
        stopAll()
    }

    /** 📳 Petite vibration quand votre correspondant décroche. */
    fun vibrateConnected(ctx: Context) {
        val v: Vibrator? = if (Build.VERSION.SDK_INT >= 31) {
            ctx.getSystemService(VibratorManager::class.java)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
        runCatching { v?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 70, 90, 70), -1)) }
    }

    private fun stopTts() {
        tts?.let { runCatching { it.stop(); it.shutdown() } }
        tts = null
    }

    private fun stopFlip() {
        flipListener?.let { sensorManager?.unregisterListener(it) }
        flipListener = null
    }

    fun stopAll() {
        flashJob?.cancel()
        flashJob = null
        stopTts()
        stopFlip()
    }
}

/** ⏰ « Rappelle-moi dans 10 min ». */
object Reminders {
    fun schedule(ctx: Context, number: String, name: String?, minutes: Int = 10) {
        if (number.isBlank()) return
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return
        val i = Intent(ctx, CallActionReceiver::class.java)
            .setAction(CallActionReceiver.ACTION_REMIND_FIRE)
            .putExtra("number", number)
            .putExtra("name", name)
        val pi = PendingIntent.getBroadcast(
            ctx, number.hashCode(), i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + minutes * 60_000L, pi)
        Toast.makeText(ctx, "Rappel dans $minutes min ⏰", Toast.LENGTH_SHORT).show()
    }
}
