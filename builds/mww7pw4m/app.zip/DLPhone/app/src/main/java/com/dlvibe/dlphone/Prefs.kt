package com.dlvibe.dlphone

import android.content.Context
import android.content.SharedPreferences

/** Réglages de DL Phone (fonctions magiques, liste noire, numérotation rapide…). */
object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(context: Context) {
        if (!::sp.isInitialized) {
            sp = context.applicationContext.getSharedPreferences("dl_phone", Context.MODE_PRIVATE)
        }
    }

    private fun getB(key: String, def: Boolean): Boolean = sp.getBoolean(key, def)
    private fun putB(key: String, v: Boolean) {
        sp.edit().putBoolean(key, v).apply()
    }

    var flash: Boolean
        get() = getB("flash", true)
        set(v) = putB("flash", v)

    var announce: Boolean
        get() = getB("announce", true)
        set(v) = putB("announce", v)

    var flipToSilence: Boolean
        get() = getB("flip", true)
        set(v) = putB("flip", v)

    var vibrateOnConnect: Boolean
        get() = getB("vibrate_connect", true)
        set(v) = putB("vibrate_connect", v)

    var missedNotif: Boolean
        get() = getB("missed_notif", true)
        set(v) = putB("missed_notif", v)

    var blockHidden: Boolean
        get() = getB("block_hidden", false)
        set(v) = putB("block_hidden", v)

    var blockUnknown: Boolean
        get() = getB("block_unknown", false)
        set(v) = putB("block_unknown", v)

    var randomStyle: Boolean
        get() = getB("random_style", false)
        set(v) = putB("random_style", v)

    var askedDefault: Boolean
        get() = getB("asked_default", false)
        set(v) = putB("asked_default", v)

    var style: Int
        get() = sp.getInt("style", 0)
        set(v) {
            sp.edit().putInt("style", v).apply()
        }

    var blockedCount: Int
        get() = sp.getInt("blocked_count", 0)
        set(v) {
            sp.edit().putInt("blocked_count", v).apply()
        }

    /** Clé de comparaison d'un numéro : les 9 derniers chiffres (ignore +225, 0, espaces…). */
    fun norm(n: String?): String = (n ?: "").filter { it.isDigit() }.takeLast(9)

    fun blacklist(): List<String> = sp.getStringSet("blacklist", emptySet())?.sorted() ?: emptyList()

    fun isBlocked(n: String?): Boolean {
        val k = norm(n)
        if (k.length < 3) return false
        return blacklist().any { norm(it) == k }
    }

    fun block(n: String) {
        val s = blacklist().toMutableSet()
        s.add(n.trim())
        sp.edit().putStringSet("blacklist", s).apply()
    }

    fun unblock(n: String) {
        val k = norm(n)
        val s = blacklist().filter { norm(it) != k }.toSet()
        sp.edit().putStringSet("blacklist", s).apply()
    }

    val DEFAULT_REPLIES = listOf(
        "Je ne peux pas répondre, je te rappelle.",
        "Je suis en réunion, envoie-moi un message.",
        "Je conduis, je te rappelle plus tard.",
        "J'arrive dans 5 minutes."
    )

    fun quickReplies(): List<String> {
        val raw = sp.getString("replies", null) ?: return DEFAULT_REPLIES
        return raw.split("\n").filter { it.isNotBlank() }
    }

    fun setQuickReplies(list: List<String>) {
        sp.edit().putString("replies", list.joinToString("\n")).apply()
    }

    fun speedDial(d: Int): String? = sp.getString("sd_$d", null)

    fun setSpeedDial(d: Int, n: String?) {
        val e = sp.edit()
        if (n == null) e.remove("sd_$d") else e.putString("sd_$d", n)
        e.apply()
    }
}
