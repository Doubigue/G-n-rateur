package com.dlvibe.dlphone

import android.app.Application
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.dlvibe.dlphone.ui.Palettes
import com.dlvibe.dlphone.ui.ThemeState
import kotlin.random.Random

object Notif {
    private const val CH_INCOMING = "dl_incoming"
    private const val CH_ONGOING = "dl_ongoing"
    private const val CH_MISSED = "dl_missed"
    private const val CH_REMIND = "dl_remind"
    const val ID_INCOMING = 1001
    const val ID_ONGOING = 1002
    private const val ORANGE = 0xFFFF7A00.toInt()

    fun channels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannels(
            listOf(
                NotificationChannel(CH_INCOMING, "Appels entrants", NotificationManager.IMPORTANCE_HIGH).apply {
                    setSound(null, null)
                    enableVibration(false)
                },
                NotificationChannel(CH_ONGOING, "Appel en cours", NotificationManager.IMPORTANCE_LOW),
                NotificationChannel(CH_MISSED, "Appels manqués", NotificationManager.IMPORTANCE_DEFAULT),
                NotificationChannel(CH_REMIND, "Rappels d'appel", NotificationManager.IMPORTANCE_HIGH)
            )
        )
    }

    private fun post(ctx: Context, id: Int, n: Notification) {
        try {
            NotificationManagerCompat.from(ctx).notify(id, n)
        } catch (_: SecurityException) {
        }
    }

    private fun act(ctx: Context, req: Int, i: Intent): PendingIntent =
        PendingIntent.getActivity(ctx, req, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    private fun br(ctx: Context, req: Int, action: String, number: String = "", name: String? = null, notif: Int = 0): PendingIntent {
        val i = Intent(ctx, CallActionReceiver::class.java).setAction(action)
            .putExtra("number", number).putExtra("name", name).putExtra("notif", notif)
        return PendingIntent.getBroadcast(ctx, req, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun callBack(ctx: Context, number: String, req: Int): PendingIntent =
        act(ctx, req, Intent(ctx, MainActivity::class.java).putExtra(MainActivity.EXTRA_CALL, number)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    private fun title(number: String, name: String?) = name ?: number.ifBlank { "Numéro masqué" }

    fun incoming(ctx: Context, number: String, name: String?) {
        val full = act(ctx, 1, Intent(ctx, InCallActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_USER_ACTION))
        val answer = act(ctx, 2, Intent(ctx, InCallActivity::class.java)
            .setAction(InCallActivity.ACTION_ANSWER).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        val n = NotificationCompat.Builder(ctx, CH_INCOMING)
            .setSmallIcon(R.drawable.ic_call)
            .setColor(ORANGE)
            .setContentTitle(title(number, name))
            .setContentText("Appel entrant · DL Phone ✦")
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setOngoing(true)
            .setFullScreenIntent(full, true)
            .setContentIntent(full)
            .addAction(0, "Refuser", br(ctx, 3, CallActionReceiver.ACTION_DECLINE))
            .addAction(0, "Répondre", answer)
            .build()
        post(ctx, ID_INCOMING, n)
    }

    fun ongoing(ctx: Context, number: String, name: String?) {
        val open = act(ctx, 4, Intent(ctx, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        val n = NotificationCompat.Builder(ctx, CH_ONGOING)
            .setSmallIcon(R.drawable.ic_call)
            .setColor(ORANGE)
            .setContentTitle(title(number, name))
            .setContentText("Appel en cours · touchez pour revenir")
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setOngoing(true)
            .setUsesChronometer(true)
            .setContentIntent(open)
            .addAction(0, "Raccrocher", br(ctx, 5, CallActionReceiver.ACTION_HANGUP))
            .build()
        post(ctx, ID_ONGOING, n)
    }

    fun missed(ctx: Context, number: String, name: String?) {
        val id = 2000 + (number.hashCode() and 0xFFFF)
        val open = act(ctx, 6, Intent(ctx, MainActivity::class.java).putExtra(MainActivity.EXTRA_TAB, 1)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        val b = NotificationCompat.Builder(ctx, CH_MISSED)
            .setSmallIcon(R.drawable.ic_call)
            .setColor(ORANGE)
            .setContentTitle("Appel manqué")
            .setContentText(title(number, name))
            .setCategory(NotificationCompat.CATEGORY_MISSED_CALL)
            .setAutoCancel(true)
            .setContentIntent(open)
        if (number.isNotBlank()) {
            b.addAction(0, "Rappeler", callBack(ctx, number, id))
            b.addAction(0, "Dans 10 min", br(ctx, id, CallActionReceiver.ACTION_REMIND, number, name, id))
        }
        post(ctx, id, b.build())
    }

    fun reminder(ctx: Context, number: String, name: String?) {
        val id = 3000 + (number.hashCode() and 0xFFFF)
        val n = NotificationCompat.Builder(ctx, CH_REMIND)
            .setSmallIcon(R.drawable.ic_call)
            .setColor(ORANGE)
            .setContentTitle("⏰ Pensez à rappeler")
            .setContentText(title(number, name))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(callBack(ctx, number, id))
            .addAction(0, "Appeler maintenant", callBack(ctx, number, id + 1))
            .build()
        post(ctx, id, n)
    }

    fun cancelIncoming(ctx: Context) = NotificationManagerCompat.from(ctx).cancel(ID_INCOMING)

    fun cancelCallNotifs(ctx: Context) {
        val nm = NotificationManagerCompat.from(ctx)
        nm.cancel(ID_INCOMING)
        nm.cancel(ID_ONGOING)
    }
}

class CallActionReceiver : BroadcastReceiver() {
    companion object {
        const val ACTION_DECLINE = "com.dlvibe.dlphone.DECLINE"
        const val ACTION_HANGUP = "com.dlvibe.dlphone.HANGUP"
        const val ACTION_REMIND = "com.dlvibe.dlphone.REMIND"
        const val ACTION_REMIND_FIRE = "com.dlvibe.dlphone.REMIND_FIRE"
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        Prefs.init(ctx)
        val number = intent.getStringExtra("number") ?: ""
        val name = intent.getStringExtra("name")
        when (intent.action) {
            ACTION_DECLINE -> CallManager.ringing()?.reject(false, null)
            ACTION_HANGUP -> CallManager.primary()?.disconnect()
            ACTION_REMIND -> {
                Reminders.schedule(ctx, number, name, 10)
                NotificationManagerCompat.from(ctx).cancel(intent.getIntExtra("notif", 0))
            }

            ACTION_REMIND_FIRE -> Notif.reminder(ctx, number, name)
        }
    }
}

class DlPhoneApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        ThemeState.index = if (Prefs.randomStyle) Random.nextInt(Palettes.size) else Prefs.style.coerceIn(0, Palettes.size - 1)
        Notif.channels(this)
    }
}
