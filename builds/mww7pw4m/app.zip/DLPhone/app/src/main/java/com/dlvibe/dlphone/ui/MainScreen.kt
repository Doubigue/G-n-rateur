package com.dlvibe.dlphone.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.Dialpad
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dlvibe.dlphone.CallEntry
import com.dlvibe.dlphone.Contact
import com.dlvibe.dlphone.ContactsRepo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun MainScreen(
    refreshKey: Int,
    prefill: String,
    navKey: Int,
    startTab: Int,
    isDefault: Boolean,
    onCall: (String) -> Unit,
    onRequestDefault: () -> Unit,
    onRequestScreening: () -> Unit,
    onRefresh: () -> Unit
) {
    val ctx = LocalContext.current
    val p = LocalPalette.current
    var tab by remember { mutableIntStateOf(0) }
    LaunchedEffect(navKey) { if (navKey > 0) tab = startTab }

    var contacts by remember { mutableStateOf<List<Contact>>(emptyList()) }
    var calls by remember { mutableStateOf<List<CallEntry>>(emptyList()) }
    LaunchedEffect(refreshKey) {
        val r = withContext(Dispatchers.IO) { ContactsRepo.contacts(ctx) to ContactsRepo.calls(ctx) }
        contacts = r.first
        calls = r.second
    }

    val tabs = listOf(
        Triple("Clavier", Icons.Filled.Dialpad, 0),
        Triple("Récents", Icons.Filled.History, 1),
        Triple("Contacts", Icons.Filled.Contacts, 2),
        Triple("Magie", Icons.Filled.AutoAwesome, 3)
    )

    Box(
        Modifier
            .fillMaxSize()
            .background(bgBrush(p))
    ) {
        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = {
                NavigationBar(containerColor = p.sheet, tonalElevation = 0.dp) {
                    tabs.forEach { (label, icon, i) ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Icon(icon, label) },
                            label = { Text(label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = p.onAccent,
                                indicatorColor = p.accent,
                                selectedTextColor = p.accent,
                                unselectedIconColor = p.muted,
                                unselectedTextColor = p.muted
                            )
                        )
                    }
                }
            }
        ) { pad ->
            Column(
                Modifier
                    .padding(pad)
                    .fillMaxSize()
            ) {
                if (!isDefault) DefaultBanner(onRequestDefault)
                when (tab) {
                    0 -> DialerScreen(
                        contacts = contacts,
                        prefill = prefill,
                        navKey = navKey,
                        lastNumber = calls.firstOrNull { it.type == android.provider.CallLog.Calls.OUTGOING_TYPE }?.number,
                        onCall = onCall
                    )

                    1 -> RecentsScreen(calls, onCall, onRefresh)
                    2 -> ContactsScreen(contacts, onCall, onRefresh)
                    else -> MagicScreen(calls, isDefault, onRequestDefault, onRequestScreening)
                }
            }
        }
    }
}

@Composable
private fun DefaultBanner(onClick: () -> Unit) {
    val p = LocalPalette.current
    Row(
        Modifier
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(p.accent)
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.PhoneAndroid, null, tint = p.onAccent)
        Column(
            Modifier
                .weight(1f)
                .padding(start = 12.dp)
        ) {
            Text("Activer la magie", color = p.onAccent, fontWeight = FontWeight.Bold)
            Text("Définir DL Phone comme appli Téléphone par défaut", color = p.onAccent, fontSize = 12.sp)
        }
    }
}
