# DL Phone ✦ — appli Téléphone magique (Kotlin)

Created by **DL VIBE STUDIO** · Doubigue Loubikoa

Application Android native (Kotlin + Jetpack Compose) qui remplace l'appli Téléphone du système.

## Fonctions
**Téléphone complet**
- Clavier avec tonalités, recherche **T9** sur les noms, initiales et numéros
- Récents groupés par jour, filtres (Manqués, Entrants, Sortants, Bloqués), appui long : SMS, copier, bloquer, ajouter
- Contacts avec favoris ★, recherche, index alphabétique
- Écran d'appel : répondre/refuser, muet, haut-parleur, Bluetooth, attente, clavier DTMF, double appel, choix de SIM (double SIM)
- Écran qui s'éteint contre l'oreille (capteur de proximité), affichage par-dessus l'écran verrouillé

**Fonctions magiques ✨**
- 🔦 **Flash magique** : le flash clignote à l'appel entrant
- 🗣️ **Annonce vocale** : « Appel de Maman »
- 🙃 **Retourner = silence** : posez le téléphone face cachée pour couper la sonnerie
- 📳 **Vibration de décroché** quand votre correspondant répond
- 💬 **Refuser avec un SMS** (réponses personnalisables)
- ⏰ **« Dans 10 min »** : refuse et vous rappelle de rappeler
- 🛡️ **Bouclier** : liste noire, blocage des numéros masqués et des inconnus
- ⚡ **Numérotation rapide** : appui long sur 2 à 9 ; appui long sur 1 = messagerie, sur 0 = « + »
- 🔁 Bouton d'appel sur clavier vide = recompose le dernier numéro
- 📊 **Statistiques** des 30 derniers jours (graphe 7 jours, top contacts)
- 🎨 **9 styles DL VIBE** (Orange Studio, Mamba, Émeraude, Festin, Crépuscule, Portfolio, Losanges, Cramoisi, Black Friday) + style surprise

## Compilation (GitHub Actions)
1. Envoyez ce dossier dans un dépôt GitHub (ou passez-le par APK Studio).
2. Le workflow `.github/workflows/build.yml` compile l'APK **signé** à chaque push.
3. Téléchargez l'APK dans l'onglet **Actions → DL-Phone-APK**.

En local avec Android Studio : `./gradlew assembleRelease` → `app/build/outputs/apk/release/app-release.apk`.

## Clé de signature
- Fichier : `app/dlphone-release.jks` (PKCS12, RSA 2048, valable 10 000 jours)
- Alias : `dlphone`
- Mot de passe (magasin et clé) : dans `keystore.properties`
- Titulaire : CN=Doubigue Loubikoa, O=DL VIBE STUDIO, C=CI
- SHA-256 : `4A:43:5D:77:DB:F6:A8:BC:ED:1F:F9:9D:54:39:FD:8A:67:A4:23:6F:D1:6F:1A:E4:BA:28:19:7C:EF:CD:06:E8`

⚠️ Gardez une copie de la clé et du mot de passe en lieu sûr : sans eux, impossible de publier une mise à jour. Utilisez un dépôt **privé** (ou mettez la clé dans les secrets GitHub).

## Premier lancement
Acceptez « Définir DL Phone comme appli Téléphone par défaut », puis les autorisations. Pour le filtrage avant la sonnerie (Android 10+), touchez « Activer le filtrage » dans l'onglet Magie.
