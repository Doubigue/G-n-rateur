// ============ Boîte de réception : compte les nouveautés par catégorie ============
// Catégories : « chat » (conversation avec l'éditeur) + une par section d'annonces.
import { fetchCollection, watchThread, watchReads, markRead } from "../shared/firebase-config.js";
import { DEFAULT_SECTIONS, annTime } from "../shared/announce.js";
import { livePage } from "../shared/ads.js";
import { hasAny, AUTHOR, READER, PRO } from "../shared/roles.js";

const ms = t => t?.toMillis ? t.toMillis() : (t?.seconds ? t.seconds * 1000 : 0);
const audienceOk = (p, a) => !a || a === "all" || (a === "authors" && hasAny(p, AUTHOR)) || (a === "readers" && (hasAny(p, READER) || !p?.roles?.length && !p?.role)) || (a === "pros" && hasAny(p, PRO));

/** Démarre l'écoute. cb({ sections, anns, pads, counts, total, reads, thread }). Retourne la fonction d'arrêt. */
export function startInbox(user, profile, cb) {
  const S = { thread: null, anns: [], secs: [], reads: {}, pads: [] }, got = new Set(); let started = false;
  const emit = key => {
    if (key) got.add(key);
    if (!started && got.size < 5) return;           // on attend les 4 sources avant le premier calcul (évite les fausses notifications)
    const initial = !started; started = true;
    const sections = [...DEFAULT_SECTIONS, ...S.secs.filter(s => !DEFAULT_SECTIONS.some(d => d.id === s.id)).sort((a, b) => (a.order || 0) - (b.order || 0) || (ms(a.createdAt) - ms(b.createdAt)))];
    const anns = S.anns.filter(a => a.active !== false && audienceOk(profile, a.audience)).sort((a, b) => annTime(b) - annTime(a));
    const pads = S.pads.filter(livePage).sort((a, b) => annTime(b) - annTime(a));
    const counts = { chat: S.thread?.lastFrom === "admin" && (ms(S.thread.updatedAt) || Date.now()) > (S.reads.chat || 0) ? 1 : 0 };
    for (const s of sections) counts[s.id] = anns.filter(a => (a.sectionId || sectionOfKind(a)) === s.id && annTime(a) > (S.reads[s.id] || 0)).length;
    counts["site-ads"] = pads.filter(a => annTime(a) > (S.reads["site-ads"] || 0)).length;
    const total = Object.values(counts).reduce((x, y) => x + y, 0);
    cb({ sections, anns, pads, counts, total, reads: S.reads, thread: S.thread, initial });
  };
  const sectionOfKind = a => DEFAULT_SECTIONS.find(s => s.kind === a.kind)?.id || "s-calls";
  const stops = [
    watchThread(user.uid, t => { S.thread = t; emit("t"); }),
    watchReads(user.uid, r => { S.reads = r || {}; emit("r"); }),
    fetchCollection("announcements", l => { S.anns = l || []; emit("a"); }),
    fetchCollection("msgSections", l => { S.secs = l || []; emit("s"); }),
    fetchCollection("siteAnnouncements", l => { S.pads = l || []; emit("p"); })
  ];
  // Si une source ne répond pas (règles non publiées…), on affiche quand même ce qu'on a au bout de 3 s.
  const fb = setTimeout(() => { if (!started) { ["t", "r", "a", "s", "p"].forEach(k => got.add(k)); emit(); } }, 3000);
  return () => { clearTimeout(fb); stops.forEach(x => x && x()); };
}
/** Section d'une annonce (ou section par défaut selon son type si aucune n'est choisie). */
export const sectionIdOf = a => a.sectionId || (DEFAULT_SECTIONS.find(s => s.kind === a.kind)?.id || "s-calls");
/** Marque une catégorie comme lue (au moment de l'ouverture). latest = date du plus récent élément affiché. */
export const readCat = (uid, key, latest = 0) => markRead(uid, key, Math.max(Date.now(), latest)).catch(() => {});
