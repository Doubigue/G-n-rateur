// ============ Liseuse e-book protégée ============
// - Lecture page par page (balayage, flèches, boutons) et sommaire des chapitres.
// - Chapitre + page quittés enregistrés (Firestore + copie locale) : le lecteur reprend exactement là où il s'est arrêté,
//   sur n'importe quel appareil.
// - Protection (dissuasion maximale possible dans un navigateur, voir README) : contenu masqué dès que la fenêtre perd le focus,
//   capture d'écran / impression / copie neutralisées, filigrane au nom du lecteur.
import { getEbookMeta, getEbookChapter, getReadingProgress, saveReadingProgress } from "../shared/firebase-config.js";
import { friendly } from "../shared/errors.js";

const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const CSS = `
#ebr{position:fixed;inset:0;z-index:2000;background:#f6f0e4;color:#1d1a14;display:flex;flex-direction:column;font-family:Georgia,serif;
 -webkit-user-select:none;user-select:none;-webkit-touch-callout:none;touch-action:pan-y}
#ebr *{-webkit-user-select:none;user-select:none;-webkit-user-drag:none}
#ebr .bar{flex:none;display:flex;align-items:center;gap:8px;padding:10px 12px calc(10px);padding-top:calc(10px + env(safe-area-inset-top));background:#10281e;color:#fff;font-family:Inter,system-ui,sans-serif}
#ebr .bar b{flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font:600 15px Georgia,serif;text-align:center}
#ebr .bar button,#ebr .foot button{border:0;border-radius:999px;background:rgba(255,255,255,.12);color:#fff;padding:9px 14px;font:600 13px Inter,system-ui,sans-serif;cursor:pointer}
#ebr .view{flex:1;min-height:0;position:relative;overflow:hidden}
#ebr .cols{position:absolute;column-fill:auto;transition:transform .22s ease;font-size:var(--fs,19px);line-height:1.7;hyphens:auto;-webkit-hyphens:auto;text-align:justify;overflow-wrap:break-word}
#ebr .cols p{margin:0 0 .85em}#ebr .cols h3{margin:.4em 0 .7em;font-size:1.12em;text-align:left;break-after:avoid}
#ebr .cols h2{margin:0 0 1em;font-size:1.35em;text-align:left;break-after:avoid;color:#10281e}
#ebr .foot{flex:none;display:flex;align-items:center;gap:10px;padding:10px 12px;padding-bottom:calc(10px + env(safe-area-inset-bottom));background:#10281e;color:#fff;font-family:Inter,system-ui,sans-serif}
#ebr .foot .pos{flex:1;text-align:center;font-size:12px;line-height:1.35;opacity:.9}
#ebr .foot .go{background:#d4af37;color:#10281e}
#ebr .foot button:disabled{opacity:.35}
#ebr .prog{height:3px;background:rgba(255,255,255,.15)}#ebr .prog i{display:block;height:100%;background:#d4af37;width:0}
#ebr .wm{position:absolute;inset:-50%;z-index:3;pointer-events:none;display:flex;flex-wrap:wrap;gap:56px 46px;transform:rotate(-24deg);opacity:.11;font:600 13px system-ui;color:#10281e;overflow:hidden;align-content:flex-start}
#ebr .cover{position:absolute;inset:0;z-index:9;background:#10281e;color:#f6efdc;display:none;align-items:center;justify-content:center;text-align:center;padding:30px;font:600 17px Inter,system-ui,sans-serif;line-height:1.5}
#ebr.hide .cover{display:flex}#ebr.hide .view>.cols,#ebr.hide .wm{visibility:hidden}
#ebr .toc{position:absolute;inset:0;z-index:6;background:#faf8f5;overflow-y:auto;overscroll-behavior:contain;padding:14px 16px;display:none;font-family:Inter,system-ui,sans-serif}
#ebr .toc.on{display:block}#ebr .toc h4{font:600 20px Georgia,serif;margin:4px 0 12px}
#ebr .toc button{display:flex;gap:10px;width:100%;text-align:left;border:0;background:#fff;border:1px solid #e7e1d7;border-radius:14px;padding:12px 14px;margin-bottom:8px;font:600 14px Inter,system-ui,sans-serif;color:#17201b;cursor:pointer}
#ebr .toc button.cur{background:#10281e;color:#e8cb6a;border-color:#10281e}#ebr .toc button span{margin-left:auto;font-weight:500;opacity:.65;white-space:nowrap}
#ebr .toast{position:absolute;left:50%;top:14px;transform:translateX(-50%);z-index:8;background:#10281e;color:#fff;padding:9px 16px;border-radius:999px;font:600 13px Inter,system-ui,sans-serif;border:1px solid #d4af37;max-width:90%;text-align:center}
@media print{body *{display:none!important}body::after{content:"Impression interdite";display:block;font-size:30px;padding:40px}}
`;

let live = null;

/** Ouvre la liseuse. user = utilisateur connecté (uid, email). */
export async function openEbook({ user, bookId, title = "" }) {
  if (live) return;
  if (!document.getElementById("ebr-css")) document.head.append(Object.assign(document.createElement("style"), { id: "ebr-css", textContent: CSS }));
  const root = document.createElement("div");
  root.id = "ebr"; root.setAttribute("role", "dialog"); root.setAttribute("aria-label", "Liseuse");
  root.oncontextmenu = () => false;
  root.innerHTML = `<div class="bar"><button type="button" data-x>✕ Fermer</button><b>${esc(title)}</b><button type="button" data-toc>☰ Chapitres</button></div>
  <div class="prog"><i></i></div>
  <div class="view"><div class="cols"></div><div class="wm"></div><div class="toc"></div><div class="cover">🔒 Contenu protégé<br><small style="font-weight:500;opacity:.8">Revenez sur cette page pour continuer la lecture.</small></div></div>
  <div class="foot"><button type="button" data-prev>← Précédent</button><div class="pos"></div><button type="button" class="go" data-next>Suivant →</button></div>`;
  document.body.append(root);
  document.documentElement.style.overflow = "hidden";
  // Application Android/iOS (Capacitor) : le plugin « PrivacyScreen » bloque réellement captures et enregistrements d'écran.
  const privacy = globalThis.Capacitor?.Plugins?.PrivacyScreen;
  try { privacy?.enable?.(); } catch {}
  const $ = s => root.querySelector(s), view = $(".view"), cols = $(".cols"), pos = $(".pos");
  const state = { meta: null, ch: 0, page: 0, pages: 1, cache: new Map(), alive: true, saveT: 0, lastSave: "", step: 0 };
  live = state;
  const offs = [];
  $(".wm").innerHTML = Array(260).fill(`<span>${esc(user.email)} · ${new Date().toLocaleDateString("fr-FR")}</span>`).join("");
  let fs = +(localStorage.getItem("ebr-fs") || 19); cols.style.setProperty("--fs", fs + "px");
  const toast = t => { root.querySelector(".toast")?.remove(); const d = Object.assign(document.createElement("div"), { className: "toast", textContent: t }); view.append(d); setTimeout(() => d.remove(), 3800); };

  // ----- chargement du livre -----
  try {
    const meta = await getEbookMeta(bookId);
    if (!meta) throw new Error("Ce livre n'est pas encore disponible en lecture.");
    state.meta = meta.toc?.length ? meta : { ...meta, toc: (meta.chapters || []).map((_, i) => `Chapitre ${i + 1}`), count: (meta.chapters || []).length, legacy: true };
    if (!state.meta.count) throw new Error("Ce livre n'est pas encore disponible en lecture.");
  } catch (err) { close(); alert(err.code === "permission-denied" ? "Ce livre n'est pas dans votre bibliothèque. Si vous venez de l'acheter, il sera débloqué dès que l'éditeur aura confirmé votre paiement." : friendly(err, "Lecture impossible pour le moment.")); return; }

  const getChapter = async n => {
    if (state.cache.has(n)) return state.cache.get(n);
    const c = state.meta.legacy ? { title: state.meta.toc[n], text: state.meta.chapters[n] } : await getEbookChapter(bookId, n);
    if (!c) throw new Error("Chapitre introuvable.");
    state.cache.set(n, c); return c;
  };

  // ----- mise en page : colonnes CSS = pages -----
  function layout() {
    const W = view.clientWidth, H = view.clientHeight, padX = W < 600 ? 22 : 56, padY = 20;
    const colW = Math.min(W - 2 * padX, 680), left = Math.round((W - colW) / 2), gap = W - colW;
    Object.assign(cols.style, { top: padY + "px", left: left + "px", width: colW + "px", height: H - 2 * padY + "px", columnWidth: colW + "px", columnGap: gap + "px" });
    state.step = W;
    state.pages = Math.max(1, Math.round((cols.scrollWidth + gap) / W));
  }
  const goto = (p, animate = true) => {
    state.page = Math.max(0, Math.min(state.pages - 1, p));
    cols.style.transition = animate ? "" : "none";
    cols.style.transform = `translateX(${-state.page * state.step}px)`;
    paint(); queueSave();
  };
  function paint() {
    const m = state.meta, frac = (state.ch + (state.page + 1) / state.pages) / m.count;
    pos.innerHTML = `Chapitre ${state.ch + 1} / ${m.count} · Page ${state.page + 1} / ${state.pages}<br><span style="opacity:.7">${esc(m.toc[state.ch] || "")}</span>`;
    $(".prog i").style.width = Math.round(frac * 100) + "%";
    $("[data-prev]").disabled = state.ch === 0 && state.page === 0;
    $("[data-next]").disabled = state.ch === m.count - 1 && state.page === state.pages - 1;
  }
  const render = c => {
    const body = String(c.text).split(/\n{2,}/).map(p => p.startsWith("# ") ? `<h3>${esc(p.slice(2))}</h3>` : `<p>${esc(p)}</p>`).join("");
    cols.innerHTML = `<h2>${esc(c.title || "")}</h2>` + body;
  };
  /** at : numéro de page, « last » ou { frac } (position relative, pour retrouver sa page si l'écran a changé). */
  async function loadChapter(n, at = 0) {
    n = Math.max(0, Math.min(state.meta.count - 1, n));
    cols.style.opacity = ".35";
    try {
      const c = await getChapter(n); state.ch = n; render(c);
      layout();
      const p = at === "last" ? state.pages - 1 : typeof at === "object" ? Math.round(at.frac * state.pages) : at;
      goto(p, false);
      if (n + 1 < state.meta.count) getChapter(n + 1).catch(() => {});   // préchargement
    } catch (err) { toast(friendly(err, "Chapitre indisponible. Vérifiez votre connexion.")); }
    cols.style.opacity = "";
  }
  const next = () => state.page < state.pages - 1 ? goto(state.page + 1) : state.ch < state.meta.count - 1 ? loadChapter(state.ch + 1, 0) : toast("🎉 Fin du livre");
  const prev = () => state.page > 0 ? goto(state.page - 1) : state.ch > 0 ? loadChapter(state.ch - 1, "last") : 0;

  // ----- enregistrement de la progression -----
  const lsKey = `ebr:${user.uid}:${bookId}`;
  function snapshot() {
    const m = state.meta;
    return { chapter: state.ch, page: state.page, pages: state.pages, frac: state.pages ? state.page / state.pages : 0, chapterTitle: m.toc[state.ch] || "", totalChapters: m.count, percent: Math.round((state.ch + (state.page + 1) / state.pages) / m.count * 100), at: Date.now() };
  }
  function saveNow() {
    clearTimeout(state.saveT); if (!state.meta || !state.pages) return;
    const d = snapshot(), sig = d.chapter + ":" + d.page; if (sig === state.lastSave) return; state.lastSave = sig;
    try { localStorage.setItem(lsKey, JSON.stringify(d)); } catch {}
    saveReadingProgress(user.uid, bookId, d).catch(() => {});
  }
  function queueSave() { clearTimeout(state.saveT); state.saveT = setTimeout(saveNow, 1200); }

  // ----- reprise là où le lecteur s'était arrêté -----
  let start = null;
  try { start = JSON.parse(localStorage.getItem(lsKey) || "null"); } catch {}
  const remote = await Promise.race([getReadingProgress(user.uid, bookId), new Promise(r => setTimeout(() => r(null), 3500))]);
  if (remote && (!start || (remote.at || 0) >= (start.at || 0))) start = remote;
  if (start && start.chapter >= 0 && start.chapter < state.meta.count && (start.chapter > 0 || start.page > 0)) {
    await loadChapter(start.chapter, { frac: start.frac || 0 });
    toast(`Reprise : chapitre ${state.ch + 1}, page ${state.page + 1}`);
  } else await loadChapter(0, 0);
  state.lastSave = state.ch + ":" + state.page;

  // ----- commandes -----
  $("[data-next]").onclick = next; $("[data-prev]").onclick = prev;
  const toc = $(".toc");
  $("[data-toc]").onclick = () => {
    toc.innerHTML = `<h4>Chapitres</h4>` + state.meta.toc.map((t, i) => `<button type="button" data-c="${i}" class="${i === state.ch ? "cur" : ""}">${i + 1}. ${esc(t)}${i === state.ch ? `<span>Vous êtes ici</span>` : ""}</button>`).join("");
    toc.classList.toggle("on"); if (toc.classList.contains("on")) toc.querySelector(".cur")?.scrollIntoView({ block: "center" });
  };
  toc.onclick = e => { const b = e.target.closest("[data-c]"); if (b) { toc.classList.remove("on"); loadChapter(+b.dataset.c, 0); } };
  view.addEventListener("click", e => { if (toc.classList.contains("on")) return; const r = view.getBoundingClientRect(), x = (e.clientX - r.left) / r.width; if (x > .66) next(); else if (x < .34) prev(); });
  let tx = null, ty = 0;
  view.addEventListener("touchstart", e => { tx = e.touches[0].clientX; ty = e.touches[0].clientY; }, { passive: true });
  // 3 doigts ou plus (geste de capture d'écran de nombreux téléphones) : contenu masqué le temps du geste
  const multi = e => { if (e.touches.length >= 3) { hide(2500); poison(); } };
  view.addEventListener("touchstart", multi, { passive: true }); view.addEventListener("touchmove", multi, { passive: true });
  view.addEventListener("touchend", e => { if (tx === null) return; const dx = e.changedTouches[0].clientX - tx, dy = e.changedTouches[0].clientY - ty; tx = null; if (Math.abs(dx) > 45 && Math.abs(dx) > Math.abs(dy) * 1.4) { dx < 0 ? next() : prev(); } }, { passive: true });
  const relayout = () => { if (!state.alive) return; const f = state.pages ? state.page / state.pages : 0; layout(); goto(Math.round(f * state.pages), false); };
  let rt; const onResize = () => { clearTimeout(rt); rt = setTimeout(relayout, 150); }; addEventListener("resize", onResize);

  // ----- protection -----
  const on = (t, ev, fn, o) => { t.addEventListener(ev, fn, o); offs.push(() => t.removeEventListener(ev, fn, o)); };
  let holdT = 0;
  const hide = (ms = 0) => { root.classList.add("hide"); clearTimeout(holdT); if (ms) holdT = setTimeout(show, ms); };
  const show = () => { if (document.hasFocus() && !document.hidden) root.classList.remove("hide"); };
  const poison = () => { try { navigator.clipboard?.writeText("Contenu protégé — reproduction interdite").catch(() => {}); } catch {} };
  // Changement soudain de taille de la fenêtre (outil d'enregistrement, mode flottant) : masquage préventif
  on(window, "orientationchange", () => hide(900));
  on(window, "blur", () => hide()); on(window, "focus", show); on(window, "pagehide", () => { hide(); saveNow(); });
  on(document, "visibilitychange", () => { if (document.hidden) { hide(); saveNow(); } else show(); });
  on(window, "beforeprint", () => hide(3000));
  ["copy", "cut", "dragstart", "selectstart", "contextmenu"].forEach(ev => on(document, ev, e => { if (root.contains(e.target) || ev === "copy" || ev === "cut") e.preventDefault(); }));
  on(document, "keydown", e => {
    const k = e.key.toLowerCase();
    if (k === "escape") return;
    if (k === "arrowright" || k === " " || k === "pagedown") { e.preventDefault(); return next(); }
    if (k === "arrowleft" || k === "pageup") { e.preventDefault(); return prev(); }
    // Raccourcis de capture : le contenu est masqué AVANT que la touche n'aboutisse (Cmd/Maj+Cmd+3-5, Win+Maj+S…)
    if (k === "printscreen" || k === "meta" || k === "os" || k === "shift" || (e.ctrlKey || e.metaKey) && ["c", "x", "a", "p", "s", "u"].includes(k) || k === "f12" || (e.ctrlKey && e.shiftKey && ["i", "j", "s"].includes(k))) { e.preventDefault(); hide(1800); poison(); }
  });
  on(document, "keyup", e => { if (e.key === "PrintScreen" || e.key === "Meta" || e.key === "Shift") { poison(); hide(1500); } });

  function close() {
    state.alive = false; saveNow(); offs.forEach(f => f()); removeEventListener("resize", onResize);
    clearTimeout(holdT); try { privacy?.disable?.(); } catch {}
    root.remove(); document.documentElement.style.overflow = ""; live = null; window.dispatchEvent(new Event("ebook-closed"));
  }
  $("[data-x]").onclick = close;
  on(document, "keydown", e => { if (e.key === "Escape") { if (toc.classList.contains("on")) toc.classList.remove("on"); else close(); } });
  if (!document.hasFocus()) hide();
}
