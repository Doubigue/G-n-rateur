// ============ Menu du bas partagé : Accueil · Catalogue · Auteurs · Messagerie · Plus ============
// Utilisé par index.html (via app.js) et par espace.html. Styles injectés ici : aucune dépendance à style.css.
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const ic = d => `<svg viewBox="0 0 24 24" aria-hidden="true">${d}</svg>`;
const I = {
  home: ic('<path d="M3 11.5 12 4l9 7.5"/><path d="M5 10v10h14V10"/><path d="M10 20v-5h4v5"/>'),
  book: ic('<path d="M4 19.5V5a2 2 0 0 1 2-2h13v15H6a2 2 0 0 0-2 2Zm0 0A2 2 0 0 0 6 21h13"/><path d="M9 7h6"/>'),
  users: ic('<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0M16 4.5a3.5 3.5 0 0 1 0 7M18 14.5a6.5 6.5 0 0 1 3.5 5.5"/>'),
  chat: ic('<path d="M21 12a8 8 0 0 1-11.6 7.1L3 21l1.9-5.4A8 8 0 1 1 21 12Z"/>'),
  more: ic('<circle cx="5" cy="12" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="19" cy="12" r="1.6"/>'),
  user: ic('<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>'),
  doc: ic('<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8Z"/><path d="M14 3v5h5M9 13h6M9 17h4"/>'),
  track: ic('<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>'),
  shop: ic('<path d="M3 9l1.5-5h15L21 9"/><path d="M4 9v11h16V9"/><path d="M3 9a3 3 0 0 0 6 0 3 3 0 0 0 6 0 3 3 0 0 0 6 0"/>'),
  mail: ic('<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>'),
  news: ic('<path d="M4 5h16M4 10h10M4 15h16M4 20h10"/>'),
  faq: ic('<circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.7.4-1 .9-1 1.7M12 17h.01"/>'),
  quote: ic('<path d="M7 17c-2 0-3-1.3-3-3.2C4 11 5.800 8.600 9 7M17 17c-2 0-3-1.300-3-3.200 0-2.800 1.800-5.200 5-6.800"/>'),
  pin: ic('<path d="M12 21s7-6.200 7-11.500A7 7 0 0 0 5 9.500C5 14.800 12 21 12 21Z"/><circle cx="12" cy="9.500" r="2.500"/>'),
  megaphone: ic('<path d="M3 11v2a1 1 0 0 0 1 1h2l5 4V6L6 10H4a1 1 0 0 0-1 1Z"/><path d="M15 9a4 4 0 0 1 0 6M18 6.5a8 8 0 0 1 0 11"/>'),
  out: ic('<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>')
};

const CSS = `
.msg-fab{position:fixed;right:16px;bottom:calc(92px + env(safe-area-inset-bottom));z-index:44;width:58px;height:58px;border:0;border-radius:50%;background:linear-gradient(150deg,#10281e,#1d4a37);color:#e8cb6a;display:grid;place-items:center;cursor:pointer;box-shadow:0 10px 26px rgba(16,40,30,.38),0 0 0 2px #d4af37;transition:transform .18s,opacity .18s}
.msg-fab:hover{transform:translateY(-2px) scale(1.04)}.msg-fab:active{transform:scale(.94)}
.msg-fab svg{width:26px;height:26px;stroke:currentColor;fill:none;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}
.msg-fab[hidden]{display:none}
.msg-fab-badge{position:absolute;top:-4px;right:-4px;min-width:22px;height:22px;padding:0 6px;border-radius:99px;background:#e5484d;color:#fff;font:800 11.5px/22px Inter,system-ui,sans-serif;text-align:center;box-shadow:0 0 0 2px #fff;display:none;font-style:normal}
.msg-fab-badge.show{display:block;animation:pnPop .45s cubic-bezier(.34,1.56,.64,1)}
@media(min-width:769px){.msg-fab{bottom:24px;right:24px}}
@media print{.msg-fab{display:none}}
.pnav,.pnav *,.pn-sheet,.pn-sheet *{box-sizing:border-box}
@media(min-width:769px){.pnav,.pn-scrim,.pn-sheet{display:none!important}}
.pnav{position:fixed;left:50%;transform:translateX(-50%);bottom:calc(12px + env(safe-area-inset-bottom));z-index:45;width:min(600px,calc(100% - 20px));display:flex;justify-content:space-between;gap:2px;padding:8px;border-radius:28px;background:rgba(16,40,30,.9);-webkit-backdrop-filter:blur(18px) saturate(1.4);backdrop-filter:blur(18px) saturate(1.4);border:1px solid rgba(212,175,55,.28);box-shadow:0 18px 40px -10px rgba(16,40,30,.6)}
.pnav>a,.pnav>button{flex:1;min-width:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;padding:9px 2px 7px;border-radius:20px;color:rgba(255,255,255,.6);font:600 10.5px/1.2 Inter,system-ui,sans-serif;text-decoration:none;background:none;border:0;cursor:pointer;position:relative;transition:color .25s,background .25s;-webkit-tap-highlight-color:transparent}
.pnav svg{width:22px;height:22px;stroke:currentColor;fill:none;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}
.pnav .lbl{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%}
.pnav>a:hover,.pnav>button:hover{color:#fff}
.pnav>.active{background:linear-gradient(160deg,#d4af37,#e8cb6a);color:#10281e}
.pnav>a:focus-visible,.pnav>button:focus-visible{outline:2px solid #e8cb6a;outline-offset:1px}
@media(max-width:430px){.pnav{padding:6px 4px}.pnav>a,.pnav>button{font-size:10px;padding:9px 0 7px}.pnav .lbl{text-overflow:clip}}
@media(max-width:360px){.pnav>a,.pnav>button{font-size:9.5px}.pnav svg{width:20px;height:20px}}
.pn-scrim{position:fixed;inset:0;z-index:60;background:rgba(10,20,15,.55);opacity:0;pointer-events:none;transition:opacity .25s}
.pn-scrim.open{opacity:1;pointer-events:auto}
.pn-sheet{position:fixed;left:50%;bottom:0;z-index:61;width:min(600px,100%);max-height:82vh;overflow-y:auto;transform:translate(-50%,105%);transition:transform .32s cubic-bezier(.2,.8,.2,1);background:#faf8f5;color:#17201b;border-radius:26px 26px 0 0;padding:10px 16px calc(22px + env(safe-area-inset-bottom));box-shadow:0 -20px 50px -12px rgba(16,40,30,.5);font-family:Inter,system-ui,sans-serif}
.pn-sheet.open{transform:translate(-50%,0)}
.pn-grip{width:44px;height:5px;border-radius:9px;background:#d8d1c5;margin:2px auto 12px}
.pn-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px}
.pn-head b{font:600 22px Georgia,serif}
.pn-x{width:34px;height:34px;border-radius:50%;background:#f0ebe1;border:0;font-size:18px;line-height:1;cursor:pointer}
.pn-me{display:flex;align-items:center;gap:12px;width:100%;padding:12px 14px;border-radius:18px;background:#10281e;color:#fff;text-decoration:none;border:0;text-align:left;cursor:pointer;font:inherit;margin-bottom:12px}
.pn-me .t{display:block;font-weight:700;font-size:15px}.pn-me .s{display:block;font-size:12px;color:rgba(255,255,255,.65);margin-top:1px}
.pn-me .ico{width:42px;height:42px;border-radius:50%;background:#d4af37;color:#10281e;display:grid;place-items:center;flex:none;overflow:hidden}
.pn-me .ico svg{width:22px;height:22px;stroke:currentColor;fill:none;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}
.pn-me .ico img{width:100%;height:100%;object-fit:cover}
.pn-grp{margin:0 0 14px}
.pn-grp>h4{margin:0 0 8px 4px;font:800 10.5px/1 Inter,system-ui,sans-serif;letter-spacing:.14em;text-transform:uppercase;color:#8b6a32}
.pn-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:9px}
.pn-item{display:flex;flex-direction:column;align-items:center;justify-content:flex-start;gap:8px;min-height:92px;padding:13px 6px 10px;border-radius:18px;background:#fff;border:1px solid #e7e1d7;color:#17201b;text-decoration:none;font:600 11.5px/1.2 Inter,system-ui,sans-serif;text-align:center;text-wrap:balance;-webkit-tap-highlight-color:transparent;box-shadow:0 6px 14px -12px rgba(16,40,30,.5);transition:background .15s,transform .15s,border-color .15s;opacity:0;transform:translateY(10px)}
.pn-sheet.open .pn-item{opacity:1;transform:none;transition:opacity .35s ease calc(var(--k,0)*35ms + 120ms),transform .45s cubic-bezier(.2,.8,.2,1) calc(var(--k,0)*35ms + 120ms),background .15s,border-color .15s}
.pn-item:hover{background:#faf6ec;border-color:#d4af37}.pn-sheet.open .pn-item:active{transform:scale(.95);transition-delay:0s}
.pn-item span{display:block;max-width:100%;overflow-wrap:anywhere}
.pn-item.is-feat{background:linear-gradient(150deg,#10281e,#1d4332);border-color:#10281e;color:#f6efdc}
.pn-item.is-feat i{background:linear-gradient(150deg,#d4af37,#e8cb6a);color:#10281e}
.pn-item i{width:40px;height:40px;border-radius:13px;background:#f6eed3;color:#10281e;display:grid;place-items:center;flex:none}
.pn-item svg{width:21px;height:21px;stroke:currentColor;fill:none;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}
.pn-out{display:flex;align-items:center;justify-content:center;gap:8px;width:100%;margin-top:14px;padding:12px;border-radius:999px;background:#f0ebe1;border:0;color:#b42318;font:600 14px Inter,system-ui,sans-serif;cursor:pointer}
.pn-out svg{width:18px;height:18px;stroke:currentColor;fill:none;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}
.pnav>button[data-k=msg]{position:relative}
.pn-badge{position:absolute;top:2px;left:calc(50% + 4px);min-width:18px;height:18px;padding:0 5px;border-radius:99px;background:#e5484d;color:#fff;font:800 10.5px/18px Inter,system-ui,sans-serif;text-align:center;box-shadow:0 0 0 2px #10281e;display:none;pointer-events:none}
.pn-badge.show{display:block;animation:pnPop .45s cubic-bezier(.34,1.56,.64,1),pnRing 2s 0.45s ease-out infinite}
@keyframes pnPop{from{transform:scale(0)}to{transform:scale(1)}}
@keyframes pnRing{0%{box-shadow:0 0 0 2px #10281e,0 0 0 2px rgba(229,72,77,.7)}70%,100%{box-shadow:0 0 0 2px #10281e,0 0 0 9px rgba(229,72,77,0)}}
.pnav>button[data-k=msg].ring svg{animation:pnBell .8s ease-in-out 2}
@keyframes pnBell{0%,100%{transform:rotate(0)}20%{transform:rotate(-14deg)}40%{transform:rotate(12deg)}60%{transform:rotate(-8deg)}80%{transform:rotate(5deg)}}
.pn-toast{position:fixed;left:50%;bottom:calc(86px + env(safe-area-inset-bottom));transform:translate(-50%,24px);opacity:0;z-index:70;max-width:min(520px,calc(100% - 28px));display:flex;align-items:center;gap:10px;padding:12px 18px;border-radius:999px;background:#10281e;color:#fff;border:1.5px solid #d4af37;font:600 14px Inter,system-ui,sans-serif;box-shadow:0 14px 30px rgba(0,0,0,.35);cursor:pointer;transition:transform .35s cubic-bezier(.2,.8,.2,1),opacity .35s}
.pn-toast.in{transform:translate(-50%,0);opacity:1}
@media(prefers-reduced-motion:reduce){.pn-sheet,.pn-scrim,.pn-item{transition:none!important}.pn-item{opacity:1;transform:none}.pn-badge.show,.pnav>button[data-k=msg].ring svg{animation:none}}
`;

/**
 * @param {object} o
 * @param {string} [o.home]        préfixe des liens de section ("" sur index.html, "index.html" ailleurs)
 * @param {boolean} [o.track]      surligne l'onglet selon la section visible (page d'accueil)
 * @param {string} [o.accountHref] page de l'espace ("espace.html" ; "#" si on y est déjà)
 * @param {Function} o.onLogin     clic « Connexion » (visiteur)
 * @param {Function} o.onLogout    clic « Déconnexion »
 * @param {Function} o.onMessages  clic « Messagerie »
 */
export function mountBottomNav({ home = "", track = false, accountHref = "espace.html", onLogin, onLogout, onMessages } = {}) {
  if (!document.getElementById("pn-style")) document.head.append(Object.assign(document.createElement("style"), { id: "pn-style", textContent: CSS }));
  const h = id => `${home}#${id}`;
  // [id, libellé court, icône, libellé complet (accessibilité)]
  const GROUPS = [
    ["À la une", [["annonces", "Annonces", I.megaphone, "Annonces"], ["actualites", "Actualités", I.news, "Actualités"], ["temoignages", "Témoignages", I.quote, "Témoignages"]]],
    ["Publier avec nous", [["manuscrit", "Soumettre un manuscrit", I.doc, "Soumettre un manuscrit"], ["suivi", "Suivre mon manuscrit", I.track, "Suivre mon manuscrit"], ["partenaires", "Libraires & partenaires", I.shop, "Libraires & partenaires"]]],
    ["La maison", [["contact", "Contact", I.mail, "Contact"], ["faq", "FAQ", I.faq, "FAQ"], ["localisation", "Nos agences", I.pin, "Nos agences"]]]
  ];
  const MORE = GROUPS.flatMap(g => g[1]);
  const nav = Object.assign(document.createElement("nav"), { className: "pnav", ariaLabel: "Navigation du site" });
  nav.innerHTML = `
    <a href="${h("accueil")}" data-k="home" aria-label="Accueil">${I.home}<span class="lbl">Accueil</span></a>
    <a href="${h("catalogue")}" data-k="catalogue" aria-label="Catalogue">${I.book}<span class="lbl">Catalogue</span></a>
    <a href="${h("auteurs")}" data-k="authors" aria-label="Auteurs">${I.users}<span class="lbl">Auteurs</span></a>
    <button type="button" data-k="msg" aria-label="Messagerie">${I.chat}<span class="lbl">Messagerie</span><i class="pn-badge" aria-hidden="true"></i></button>
    <button type="button" data-k="more" aria-label="Plus d'options" aria-haspopup="dialog" aria-expanded="false">${I.more}<span class="lbl">Plus</span></button>`;
  const scrim = Object.assign(document.createElement("div"), { className: "pn-scrim" });
  const sheet = document.createElement("div");
  sheet.className = "pn-sheet"; sheet.setAttribute("role", "dialog"); sheet.setAttribute("aria-modal", "true"); sheet.setAttribute("aria-label", "Plus d'options"); sheet.setAttribute("aria-hidden", "true"); sheet.inert = true;
  sheet.innerHTML = `<div class="pn-grip"></div><div class="pn-head"><b>Plus</b><button type="button" class="pn-x" aria-label="Fermer">✕</button></div>
    <div id="pn-me-slot"></div>
    ${(k => GROUPS.map(([gt, items]) => `<section class="pn-grp"><h4>${gt}</h4><div class="pn-grid">${items.map(([id, t, i, full]) => `<a class="pn-item${id === "annonces" ? " is-feat" : ""}" style="--k:${k++}" href="${id === "annonces" ? "annonces.html" : h(id)}" aria-label="${esc(full)}"><i>${i}</i><span>${t}</span></a>`).join("")}</div></section>`).join(""))(0)}
    <div id="pn-out-slot"></div>`;
  document.body.append(nav, scrim, sheet);
  // Icône de messagerie flottante (toutes les pages) : même pastille « nouveau » que la barre du bas
  const fab = Object.assign(document.createElement("button"), { type: "button", className: "msg-fab", innerHTML: `${I.chat}<i class="msg-fab-badge" aria-hidden="true"></i>` });
  fab.setAttribute("aria-label", "Messagerie"); document.body.append(fab);

  const $k = k => nav.querySelector(`[data-k="${k}"]`), moreBtn = $k("more");
  let lastFocus = null;
  const open = () => { lastFocus = document.activeElement; sheet.inert = false; sheet.setAttribute("aria-hidden", "false"); scrim.classList.add("open"); sheet.classList.add("open"); moreBtn.setAttribute("aria-expanded", "true"); setTimeout(() => sheet.querySelector(".pn-me,.pn-item")?.focus(), 60); };
  const close = () => { scrim.classList.remove("open"); sheet.classList.remove("open"); sheet.inert = true; sheet.setAttribute("aria-hidden", "true"); moreBtn.setAttribute("aria-expanded", "false"); (lastFocus && lastFocus.focus) && lastFocus.focus(); };
  moreBtn.onclick = () => sheet.classList.contains("open") ? close() : open();
  scrim.onclick = close; sheet.querySelector(".pn-x").onclick = close;
  document.addEventListener("keydown", e => { if (e.key === "Escape" && sheet.classList.contains("open")) close(); });
  sheet.addEventListener("click", e => { if (e.target.closest("a.pn-item")) { sheet.classList.remove("open"); scrim.classList.remove("open"); sheet.inert = true; moreBtn.setAttribute("aria-expanded", "false"); } });
  $k("msg").onclick = () => { close(); onMessages && onMessages(); };
  fab.onclick = () => $k("msg").click();

  const setActive = k => { nav.querySelectorAll("[data-k]").forEach(x => x.classList.toggle("active", x.dataset.k === k)); fab.hidden = k === "msg"; };
  setActive(track ? "home" : null);

  // Compte : « Connexion » (visiteur) ou « Mon espace » avec la photo de profil
  function setUser(u, p) {
    const slot = sheet.querySelector("#pn-me-slot"), out = sheet.querySelector("#pn-out-slot");
    if (!u) {
      slot.innerHTML = `<button type="button" class="pn-me" id="pn-login"><span class="ico">${I.user}</span><span><span class="t">Connexion</span><span class="s">Se connecter ou créer un compte</span></span></button>`;
      out.innerHTML = "";
      slot.querySelector("#pn-login").onclick = () => { close(); onLogin && onLogin(); };
      return;
    }
    const name = p?.name || u.email;
    slot.innerHTML = `<a class="pn-me" href="${accountHref}"><span class="ico">${p?.photoURL ? `<img src="${esc(p.photoURL)}" alt="">` : esc((name || "?")[0].toUpperCase())}</span><span style="min-width:0"><span class="t">${esc(name)}</span><span class="s">Mon espace</span></span></a>`;
    out.innerHTML = `<button type="button" class="pn-out">${I.out}Se déconnecter</button>`;
    slot.querySelector(".pn-me").addEventListener("click", e => { if (accountHref === "#") { e.preventDefault(); scrollTo({ top: 0, behavior: "smooth" }); } close(); });
    out.querySelector(".pn-out").onclick = () => { close(); onLogout && onLogout(); };
  }
  setUser(null);

  // Pastille « nouveau » sur Messagerie (+ petit message quand quelque chose arrive pendant la visite)
  let lastN = null, toastT = null;
  function setBadge(n, label = "Nouveau message", silent = false) {
    n = Math.max(0, n | 0);
    const b = $k("msg").querySelector(".pn-badge"), btn = $k("msg");
    b.textContent = n > 99 ? "99+" : n; b.classList.toggle("show", n > 0);
    const fb = fab.querySelector(".msg-fab-badge"); fb.textContent = n > 99 ? "99+" : n; fb.classList.toggle("show", n > 0);
    fab.setAttribute("aria-label", n > 0 ? `Messagerie, ${n} nouveau${n > 1 ? "x" : ""}` : "Messagerie");
    btn.setAttribute("aria-label", n > 0 ? `Messagerie, ${n} nouveau${n > 1 ? "x" : ""}` : "Messagerie");
    if (!silent && lastN !== null && n > lastN) {
      btn.classList.remove("ring"); void btn.offsetWidth; btn.classList.add("ring");
      document.querySelector(".pn-toast")?.remove(); clearTimeout(toastT);
      const t = Object.assign(document.createElement("div"), { className: "pn-toast", role: "status", innerHTML: `<span aria-hidden="true">🔔</span><span>${esc(label)}</span>` });
      t.onclick = () => { t.remove(); onMessages && onMessages(); };
      document.body.append(t); requestAnimationFrame(() => t.classList.add("in"));
      toastT = setTimeout(() => { t.classList.remove("in"); setTimeout(() => t.remove(), 400); }, 4500);
      navigator.vibrate && navigator.vibrate(60);
    }
    lastN = n;
  }

  // Surbrillance selon la section visible (accueil : « Plus » pour toutes les sections secondaires)
  if (track && "IntersectionObserver" in window) {
    const KEY = { accueil: "home", catalogue: "catalogue", auteurs: "authors" };
    const io = new IntersectionObserver(es => es.forEach(en => { if (en.isIntersecting) setActive(KEY[en.target.id] || "more"); }), { rootMargin: "-45% 0px -50% 0px" });
    ["accueil", "catalogue", "auteurs", ...MORE.map(m => m[0]), "cta-auteurs"].forEach(id => { const el = document.getElementById(id); el && io.observe(el); });
  }
  return { setUser, setActive, setBadge, open, close };
}
