# Éditions Baobab — organisation du projet

```
public/   Site public + espace client   (index.html, espace.html, annonces.html, app.js, nav.js, inbox.js, ebook-reader.js, style.css…)
admin/    Administration                (index.html, admin-orders.js, admin-scan.js, ebook-import.js, ads-sample.js, sample-data.js)
shared/   Utilisé par les deux           (firebase-config.js, errors.js, orders.js, roles.js, statuses.js, invoice-pdf.js, download.js, announce.js, ads.js, avatar.js)
docs/     Anciennes notes (non publiées)
firestore.rules · vercel.json · .vercelignore
```

Une seule publication Vercel : le site public est à `/`, l'administration à `/admin/` (non indexée par Google).
Les règles `firestore.rules` doivent être **republiées** (nouvelles collections : chapitres d'e-book et progression de lecture).

## Sessions séparées admin / public
L'administration utilise sa propre session (`data-scope="admin"` dans `admin/index.html`). Se connecter ou se déconnecter
dans l'admin ne touche plus le compte du site public, et inversement. **Première fois après la mise à jour :** reconnectez-vous
une fois dans l'admin, et déconnectez puis reconnectez le compte client sur le site public.

## E-book : import automatique
Admin › Livres › fiche du livre › « Version e-book » : cocher **« Proposer ce livre en E-book à l'achat »** (c'est ce qui affiche le choix Livre papier / E-book au client), puis **Importer le fichier** (EPUB, PDF texte, Word .docx, TXT, Markdown, HTML).
Le texte et les chapitres sont détectés automatiquement (sommaire EPUB, titres Word, signets PDF, « Chapitre N »…), puis enregistrés
avec le livre. Rien à saisir. Un prix e-book distinct est facultatif. Pour remplacer l'e-book : réimporter ; pour le retirer : bouton dédié.
Un PDF scanné (images) ne contient pas de texte : utilisez un EPUB, un Word ou un PDF avec texte sélectionnable.

## Achat
À l'ajout au panier, le client choisit **Livre papier** ou **E-book** (si le livre a un e-book). Une commande 100 % e-book n'a ni retrait ni
livraison : le client règle à l'agence ; dès que l'admin clique « Paiement reçu », l'e-book est débloqué automatiquement dans « Ma bibliothèque ».

## Liseuse
Lecture page par page, sommaire, taille du texte. Le **chapitre et la page** sont enregistrés (compte du lecteur + appareil) : à la réouverture,
« Reprise : chapitre X, page Y ». « Mes achats » est une liste ; un clic ouvre le détail (articles, format, facture, suivi, bouton Lire).

## Protection contre les captures — ce qui est (et n'est pas) possible
Un navigateur ne permet **pas** de bloquer à 100 % une capture d'écran (touche système, capture matérielle, autre appareil photo).
Mesures en place : contenu masqué dès que la fenêtre perd le focus ou que l'onglet est caché, masquage préventif sur les raccourcis de capture
(Cmd/Maj/Win/PrintScreen), presse-papiers neutralisé, copie/clic droit/sélection/impression bloqués, filigrane avec l'e-mail du lecteur
(dissuade et permet de tracer une fuite). Pour un blocage réel des captures sur téléphone, il faut une application native
(drapeau Android `FLAG_SECURE`, protection iOS), par exemple en encapsulant le site avec Capacitor.
