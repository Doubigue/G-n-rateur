// ============ Annonces de la messagerie : types, styles animés, rendu ============
// Utilisé par espace.html (messagerie des comptes) et admin.html (aperçu en direct).
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

export const KINDS = {
  call:    ["📣", "Appel à manuscrits"],
  new:     ["✨", "Nouvelle parution"],
  soon:    ["📅", "À paraître"],
  partner: ["🤝", "Demande de partenariat"],
  info:    ["🔔", "Information"]
};
export const ANN_STYLES = [
  ["aurora", "Aurore", "Dégradé vivant qui ondule"],
  ["prestige", "Prestige", "Or sur nuit, reflet qui glisse"],
  ["editorial", "Éditorial", "Papier crème et tampon"],
  ["neon", "Néon", "Bordure lumineuse pulsante"],
  ["ribbon", "Festif", "Ruban et confettis"]
];
// Sections intégrées (les sections personnalisées sont stockées dans Firestore : « msgSections »)
export const DEFAULT_SECTIONS = [
  { id: "s-calls", name: "Appels à manuscrits", icon: "📣", builtin: true, kind: "call" },
  { id: "s-new", name: "Nouvelles parutions", icon: "✨", builtin: true, kind: "new" },
  { id: "s-soon", name: "À paraître", icon: "📅", builtin: true, kind: "soon" },
  { id: "s-partner", name: "Partenariats", icon: "🤝", builtin: true, kind: "partner" }
];
export const AUDIENCES = [["all", "Tous les comptes"], ["authors", "Auteurs"], ["readers", "Lecteurs"], ["pros", "Professionnels & partenaires"]];
export const QUICK_LINKS = [
  ["Soumettre un manuscrit", "index.html#manuscrit"], ["Suivre mon manuscrit", "index.html#suivi"],
  ["Libraires & partenaires", "index.html#partenaires"], ["Catalogue", "index.html#catalogue"], ["Actualités", "index.html#actualites"]
];

const safeUrl = u => { u = String(u || "").trim(); return (/^(?:https?:\/\/|mailto:|tel:|#)/i.test(u) || /^[\w\-./]+\.html(?:[?#][\w=&%.\-]*)?$/i.test(u)) ? u : ""; };
const ms = t => t?.toMillis ? t.toMillis() : (t?.seconds ? t.seconds * 1000 : 0);
export const annTime = a => ms(a.createdAt) || Date.now();

/** Carte d'annonce. opts : { isNew, index } */
export function annCard(a, { isNew = false, index = 0 } = {}) {
  const [ico, kindName] = KINDS[a.kind] || KINDS.info, style = ANN_STYLES.some(s => s[0] === a.style) ? a.style : "aurora";
  const url = safeUrl(a.ctaUrl), ext = /^https?:/i.test(url);
  const d = a.createdAt?.toDate ? a.createdAt.toDate().toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" }) : "";
  return `<article class="ann ann-${style}${isNew ? " is-new" : ""}" style="--i:${index}">
    <div class="ann-fx" aria-hidden="true"><i></i><i></i><i></i></div>
    ${isNew ? `<span class="ann-new">Nouveau</span>` : ""}
    <span class="ann-kind"><b>${ico}</b>${esc(kindName)}</span>
    <h3 class="ann-title">${esc(a.title || "Titre de l'annonce")}</h3>
    ${a.image ? `<img class="ann-img" src="${esc(a.image)}" alt="" loading="lazy">` : ""}
    ${a.body ? `<p class="ann-body">${esc(a.body)}</p>` : ""}
    <div class="ann-foot"><span class="ann-date">${esc(d)}</span>${url && a.ctaLabel ? `<a class="ann-cta" href="${esc(url)}"${ext ? ' target="_blank" rel="noopener"' : ""}>${esc(a.ctaLabel)} <span aria-hidden="true">→</span></a>` : ""}</div>
  </article>`;
}

const CSS = `
.ann{position:relative;overflow:hidden;isolation:isolate;border-radius:24px;padding:22px 20px 18px;margin:0 0 16px;box-shadow:0 16px 34px -18px rgba(16,40,30,.55);animation:annIn .75s cubic-bezier(.2,.8,.2,1) both;animation-delay:calc(var(--i,0)*100ms)}
@keyframes annIn{from{opacity:0;transform:translateY(28px) scale(.95)}to{opacity:1;transform:none}}
.ann-fx{position:absolute;inset:0;z-index:-1;overflow:hidden;pointer-events:none}
.ann-kind{display:inline-flex;align-items:center;gap:7px;font:700 11px/1 Inter,system-ui,sans-serif;letter-spacing:.09em;text-transform:uppercase;padding:7px 12px 7px 9px;border-radius:99px;background:rgba(255,255,255,.2);-webkit-backdrop-filter:blur(5px);backdrop-filter:blur(5px)}
.ann-kind b{font-size:15px;display:inline-block;animation:annBob 2.6s ease-in-out infinite}
@keyframes annBob{0%,100%{transform:translateY(0) rotate(0)}50%{transform:translateY(-2px) rotate(-8deg)}}
.ann-title{font:700 25px/1.15 Georgia,serif;margin:14px 0 8px;letter-spacing:-.01em}
.ann-img{display:block;width:100%;max-height:210px;object-fit:cover;border-radius:16px;margin:10px 0}
.ann-body{font:400 14.5px/1.58 Inter,system-ui,sans-serif;white-space:pre-wrap;word-break:break-word;opacity:.93;margin:0}
.ann-foot{display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;margin-top:16px}
.ann-date{font:500 12px Inter,system-ui,sans-serif;opacity:.7}
.ann-cta{display:inline-flex;align-items:center;gap:8px;padding:11px 18px;border-radius:99px;font:700 14px Inter,system-ui,sans-serif;text-decoration:none;transition:transform .2s,box-shadow .2s}
.ann-cta span{transition:transform .2s}.ann-cta:hover span{transform:translateX(4px)}.ann-cta:active{transform:scale(.97)}
.ann-new{position:absolute;top:14px;right:14px;font:800 10px/1 Inter,system-ui,sans-serif;letter-spacing:.1em;text-transform:uppercase;padding:6px 10px;border-radius:99px;background:#e5484d;color:#fff;animation:annPing 1.8s ease-out infinite}
@keyframes annPing{0%{box-shadow:0 0 0 0 rgba(229,72,77,.65)}80%,100%{box-shadow:0 0 0 12px rgba(229,72,77,0)}}

/* 1 · Aurore */
.ann-aurora{color:#fff;background:linear-gradient(125deg,#7d1f2b,#173b3a,#2f2a3d,#8b6a32,#7d1f2b);background-size:320% 320%;animation:annIn .75s cubic-bezier(.2,.8,.2,1) both,annFlow 12s ease-in-out infinite;animation-delay:calc(var(--i,0)*100ms),0s}
@keyframes annFlow{0%,100%{background-position:0 50%}50%{background-position:100% 50%}}
.ann-aurora .ann-fx i{position:absolute;border-radius:50%;filter:blur(30px);opacity:.55;animation:annFloat 9s ease-in-out infinite}
.ann-aurora .ann-fx i:nth-child(1){width:150px;height:150px;background:#f4c76a;top:-50px;right:-30px}
.ann-aurora .ann-fx i:nth-child(2){width:120px;height:120px;background:#4fd1c5;bottom:-40px;left:-30px;animation-delay:-3s}
.ann-aurora .ann-fx i:nth-child(3){width:90px;height:90px;background:#f06595;top:40%;left:55%;animation-delay:-6s}
@keyframes annFloat{0%,100%{transform:translate(0,0) scale(1)}50%{transform:translate(-22px,18px) scale(1.25)}}
.ann-aurora .ann-cta{background:#fff;color:#2f2a3d}.ann-aurora .ann-cta:hover{box-shadow:0 8px 22px rgba(0,0,0,.3)}

/* 2 · Prestige */
.ann-prestige{color:#f6efdc;background:radial-gradient(120% 90% at 0 0,#1d4332,#10281e 55%,#0a1a13);box-shadow:inset 0 0 0 1.5px #d4af37,inset 0 0 0 5px #10281e,inset 0 0 0 6px rgba(212,175,55,.55),0 16px 34px -18px rgba(0,0,0,.6)}
.ann-prestige .ann-title{color:#e8cb6a}
.ann-prestige .ann-kind{background:rgba(212,175,55,.16);color:#e8cb6a}
.ann-prestige .ann-fx i:nth-child(1){position:absolute;top:-20%;bottom:-20%;width:46%;left:-60%;background:linear-gradient(105deg,transparent,rgba(255,255,255,.2),transparent);transform:skewX(-18deg);animation:annSweep 5.5s ease-in-out infinite}
@keyframes annSweep{0%,30%{left:-60%}70%,100%{left:130%}}
.ann-prestige .ann-fx i:nth-child(2){position:absolute;right:-30px;top:-30px;width:110px;height:110px;border:1.5px solid rgba(212,175,55,.35);border-radius:50%;animation:annSpin 22s linear infinite;border-style:dashed}
@keyframes annSpin{to{transform:rotate(360deg)}}
.ann-prestige .ann-cta{background:linear-gradient(135deg,#d4af37,#f0d77a);color:#10281e}.ann-prestige .ann-cta:hover{box-shadow:0 8px 22px rgba(212,175,55,.45)}

/* 3 · Éditorial */
.ann-editorial{color:#10281e;background:repeating-linear-gradient(0deg,transparent 0 27px,rgba(16,40,30,.05) 27px 28px),#fbf6e6;border:1px solid #e3d8b8;box-shadow:6px 6px 0 #10281e;border-radius:6px 24px 6px 24px}
.ann-editorial .ann-kind{background:#10281e;color:#f6efdc}
.ann-editorial .ann-title{font-style:italic}
.ann-editorial .ann-fx i:nth-child(1){position:absolute;right:16px;bottom:62px;width:84px;height:84px;border:3px double #b42318;border-radius:50%;opacity:0;transform:rotate(-16deg) scale(2.2);animation:annStamp .6s .5s cubic-bezier(.2,1.4,.4,1) forwards}
.ann-editorial .ann-fx i:nth-child(1)::after{content:"ÉDITIONS";position:absolute;inset:0;display:grid;place-items:center;font:800 11px Inter,sans-serif;letter-spacing:.12em;color:#b42318}
@keyframes annStamp{to{opacity:.8;transform:rotate(-16deg) scale(1)}}
.ann-editorial .ann-cta{background:#10281e;color:#fbf6e6;border-radius:6px}.ann-editorial .ann-cta:hover{box-shadow:4px 4px 0 #d4af37}

/* 4 · Néon */
.ann-neon{--g:#39ffb6;color:#e8fff7;background:#080d12;border:2px solid var(--g);animation:annIn .75s cubic-bezier(.2,.8,.2,1) both,annGlow 2.6s ease-in-out infinite;animation-delay:calc(var(--i,0)*100ms),0s}
@keyframes annGlow{0%,100%{box-shadow:0 0 6px rgba(57,255,182,.5),0 0 22px rgba(57,255,182,.25),inset 0 0 14px rgba(57,255,182,.12)}50%{box-shadow:0 0 12px rgba(57,255,182,.9),0 0 42px rgba(57,255,182,.45),inset 0 0 26px rgba(57,255,182,.22)}}
.ann-neon .ann-title{color:var(--g);text-shadow:0 0 12px rgba(57,255,182,.7)}
.ann-neon .ann-kind{background:transparent;border:1px solid var(--g);color:var(--g)}
.ann-neon .ann-fx i:nth-child(1){position:absolute;left:0;right:0;height:60px;top:-60px;background:linear-gradient(180deg,transparent,rgba(57,255,182,.14),transparent);animation:annScan 4.5s linear infinite}
@keyframes annScan{to{transform:translateY(420px)}}
.ann-neon .ann-cta{background:transparent;color:var(--g);border:1.5px solid var(--g)}.ann-neon .ann-cta:hover{background:var(--g);color:#06100c;box-shadow:0 0 20px var(--g)}

/* 5 · Festif */
.ann-ribbon{color:#2b1200;background:linear-gradient(135deg,#ffd166,#ff9f1c 55%,#ff6b35)}
.ann-ribbon .ann-kind{background:rgba(43,18,0,.88);color:#ffe9b8}
.ann-ribbon .ann-fx i{position:absolute;width:12px;height:12px;border-radius:3px;opacity:.85;animation:annFall 6s linear infinite}
.ann-ribbon .ann-fx i:nth-child(1){left:14%;background:#fff;animation-delay:-1s}
.ann-ribbon .ann-fx i:nth-child(2){left:52%;background:#7d1f2b;border-radius:50%;animation-delay:-3.2s}
.ann-ribbon .ann-fx i:nth-child(3){left:84%;background:#173b3a;animation-delay:-4.6s}
@keyframes annFall{from{transform:translateY(-30px) rotate(0)}to{transform:translateY(340px) rotate(540deg)}}
.ann-ribbon::after{content:"";position:absolute;left:-40px;top:20px;width:120px;height:14px;background:rgba(255,255,255,.35);transform:rotate(-38deg)}
.ann-ribbon .ann-cta{background:#2b1200;color:#ffe9b8}.ann-ribbon .ann-cta:hover{box-shadow:0 8px 20px rgba(43,18,0,.4)}
.ann-ribbon.is-new .ann-new{background:#2b1200}

@media (prefers-reduced-motion:reduce){.ann,.ann *,.ann::after{animation:none!important;transition:none!important}.ann-editorial .ann-fx i:nth-child(1){opacity:.8;transform:rotate(-16deg)}}
`;
export function injectAnnCss() {
  if (document.getElementById("ann-style")) return;
  document.head.append(Object.assign(document.createElement("style"), { id: "ann-style", textContent: CSS }));
}
