// ============ Facture PDF (jsPDF) + envoi Cloudinary ============
// Nom, logo, cachet, tampon, filigrane, signature et tampons « PAYÉ » / « NON PAYÉ » viennent UNIQUEMENT de l'admin
// (onglet Identité > Facture). Rien n'est dessiné ni écrit par défaut.
import { fmtF, fdate, MODE_LABEL, PAY_LABEL, itemLabel, modeLabel, isDigitalOnly } from "./orders.js";

const JSPDF_URL = "https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js";
const CLOUD_URL = "https://api.cloudinary.com/v1_1/iayfluiq/auto/upload", CLOUD_PRESET = "blognews_unsigned";
export const DEFAULT_BRAND = "";
const A = { brand: "", img: {} };
export const invoiceAssets = () => A;
/** À appeler avec le document settings/site (admin) : nom + images de la facture. */
export function applyInvoiceSettings(s = {}) {
  A.brand = s.footerName || "";
  A.img = { logo: s.invoiceLogoUrl || s.logoUrl || "", seal: s.invoiceSealUrl || "", stamp: s.invoiceStampUrl || "", watermark: s.invoiceWatermarkUrl || "", paid: s.invoicePaidImg || "", unpaid: s.invoiceUnpaidImg || "", signature: s.invoiceSignatureUrl || "" };
}

let jsLoad = null;
export function loadJsPdf() {
  if (window.jspdf?.jsPDF) return Promise.resolve(window.jspdf.jsPDF);
  return jsLoad ||= new Promise((res, rej) => {
    const s = document.createElement("script"); s.src = JSPDF_URL;
    s.onload = () => res(window.jspdf.jsPDF);
    s.onerror = () => { jsLoad = null; rej(new Error("Module PDF indisponible (connexion ?).")); };
    document.head.append(s);
  });
}
/** Texte sûr pour les polices standard du PDF (Latin-1) */
export const T = s => String(s ?? "").replace(/[\u202f\u00a0]/g, " ").replace(/[’‘]/g, "'").replace(/[“”«»]/g, '"').replace(/[–—]/g, "-").replace(/…/g, "...").replace(/[^\x20-\x7e\u00a1-\u00ff]/g, "");

const loadImg = src => !src ? Promise.resolve(null) : new Promise(r => { const i = new Image(); if (/^https?:/i.test(src)) i.crossOrigin = "anonymous"; i.onload = () => r(i.naturalWidth ? i : null); i.onerror = () => r(null); i.src = new URL(src, location.href).href; });
const cv = (w, h) => Object.assign(document.createElement("canvas"), { width: w, height: h });
function rr(x, X, Y, W, H, r) { x.beginPath(); x.moveTo(X + r, Y); x.arcTo(X + W, Y, X + W, Y + H, r); x.arcTo(X + W, Y + H, X, Y + H, r); x.arcTo(X, Y + H, X, Y, r); x.arcTo(X, Y, X + W, Y, r); x.closePath(); }
/** Redessine une image (ou un canvas) avec rotation / transparence → PNG */
function prep(img, { rot = 0, alpha = 1, max = 700 } = {}) {
  const k = Math.min(1, max / Math.max(img.width, img.height)), w = img.width * k, h = img.height * k, a = rot * Math.PI / 180;
  const W = Math.ceil(Math.abs(w * Math.cos(a)) + Math.abs(h * Math.sin(a))), H = Math.ceil(Math.abs(w * Math.sin(a)) + Math.abs(h * Math.cos(a)));
  const c = cv(W, H), x = c.getContext("2d"); x.globalAlpha = alpha; x.translate(W / 2, H / 2); x.rotate(a); x.drawImage(img, -w / 2, -h / 2, w, h);
  return { url: c.toDataURL("image/png"), w: W, h: H };
}
const wrapWords = (s, n) => { const L = []; let cur = ""; for (const w of String(s).split(/\s+/)) { if ((cur + " " + w).trim().length > n && cur) { L.push(cur); cur = w; } else cur = (cur + " " + w).trim(); } cur && L.push(cur); return L; };

const fbPaid = () => { const c = cv(560, 260), x = c.getContext("2d"); x.strokeStyle = x.fillStyle = "#1f7a3d"; x.lineWidth = 10; rr(x, 8, 8, 544, 244, 28); x.stroke(); x.lineWidth = 3; rr(x, 24, 24, 512, 212, 20); x.stroke(); x.font = "bold 150px Georgia, serif"; x.textAlign = "center"; x.textBaseline = "middle"; x.fillText("PAYÉ", 280, 140); return c; };
const fbUnpaid = () => { const c = cv(560, 260), x = c.getContext("2d"); x.strokeStyle = x.fillStyle = "#b91c1c"; x.lineWidth = 10; rr(x, 8, 8, 544, 244, 28); x.stroke(); x.lineWidth = 3; rr(x, 24, 24, 512, 212, 20); x.stroke(); x.textAlign = "center"; x.textBaseline = "middle"; let f = 130; do { x.font = `bold ${f -= 4}px Georgia, serif`; } while (x.measureText("IMPAYÉ").width > 460 && f > 40); x.fillText("IMPAYÉ", 280, 140); return c; };
const fbStamp = when => { const c = cv(460, 220), x = c.getContext("2d"); x.strokeStyle = x.fillStyle = "#243b8a"; x.lineWidth = 8; rr(x, 8, 8, 444, 204, 18); x.stroke(); x.textAlign = "center"; x.textBaseline = "middle"; x.font = "bold 62px Georgia, serif"; x.fillText("ENCAISSÉ", 230, 92); x.font = "30px Georgia, serif"; x.fillText(when, 230, 152); return c; };
/** Image (par défaut ou importée dans l'admin) inscrite dans un cadre de taille FIXE : même taille quelle que soit l'image. 10 px = 1 mm. */
function fitBox(src, bw, bh, rot = 0) {
  const c = cv(Math.round(bw * 10), Math.round(bh * 10)), x = c.getContext("2d"), k = Math.min(c.width / src.width, c.height / src.height), w = src.width * k, h = src.height * k;
  x.drawImage(src, (c.width - w) / 2, (c.height - h) / 2, w, h);
  return prep(c, { rot, max: 4000 });
}
const BOX = { status: [58, 58 * 260 / 560], stamp: [52, 52 * 220 / 460], seal: [38, 38], sign: [50, 22] };

// ---------- QR de validation (logo de la maison au centre) ----------
const QR_URL = "https://cdnjs.cloudflare.com/ajax/libs/qrcode-generator/1.4.4/qrcode.min.js";
let qrLoad = null;
const loadQr = () => window.qrcode ? Promise.resolve(window.qrcode) : (qrLoad ||= new Promise(res => { const s = document.createElement("script"); s.src = QR_URL; s.onload = () => res(window.qrcode); s.onerror = () => { qrLoad = null; res(null); }; document.head.append(s); }));
/** QR niveau H (30 % de redondance) : le logo central ne gêne pas la lecture. Retourne un PNG (data URL) ou null. */
function makeQr(qrcode, text, logo) {
  const q = qrcode(0, "H"); q.addData(text); q.make();
  const n = q.getModuleCount(), px = 12, S = (n + 2) * px, c = cv(S, S), x = c.getContext("2d");
  x.fillStyle = "#fff"; x.fillRect(0, 0, S, S); x.fillStyle = "#10281e";
  for (let r = 0; r < n; r++) for (let k = 0; k < n; k++) if (q.isDark(r, k)) x.fillRect((k + 1) * px, (r + 1) * px, px, px);
  const L = S * .22, X = (S - L) / 2;
  x.fillStyle = "#fff"; rr(x, X - 8, X - 8, L + 16, L + 16, 18); x.fill();
  if (logo) { const k = Math.min(L / logo.width, L / logo.height), w = logo.width * k, h = logo.height * k; x.drawImage(logo, (S - w) / 2, (S - h) / 2, w, h); }
  else { x.fillStyle = "#10281e"; rr(x, X, X, L, L, 14); x.fill(); x.fillStyle = "#d4af37"; x.font = `bold ${L * .6}px Georgia,serif`; x.textAlign = "center"; x.textBaseline = "middle"; x.fillText("\u2726", S / 2, S / 2 + 2); }
  return c.toDataURL("image/png");
}

const FOREST = [16, 40, 30], GOLD = [176, 139, 46], INK = [23, 32, 27], MUTED = [117, 111, 103], LINE = [226, 220, 208], GREEN = [31, 122, 61], AMBER = [180, 100, 10];

export const invoiceName = (o, paid) => `${o.invoice}${paid ? "-PAYEE" : ""}`;

/** Génère la facture. paid=false : « À RÉGLER » ; paid=true : tampon PAYÉ + tampon + cachet + signature. Retourne un Blob PDF. */
export async function buildInvoicePdf(o, { paid = false, brand = A.brand } = {}) {
  const JsPDF = await loadJsPdf();
  const im = Object.fromEntries(await Promise.all(Object.entries(A.img).map(async ([k, v]) => [k, await loadImg(v)])));
  const doc = new JsPDF({ unit: "mm", format: "a4", compress: true });
  const W = 210, H = 297, M = 16, paidAt = o.paidAt || Date.now();
  const wm = im.watermark ? prep(im.watermark, { alpha: .07, max: 900 }) : null;
  const frame = () => { const w = 130; if (wm) doc.addImage(wm.url, "PNG", (W - w) / 2, (H - w * wm.h / wm.w) / 2, w, w * wm.h / wm.w); doc.setFillColor(...FOREST); doc.rect(0, 0, W, 5, "F"); doc.setFillColor(...GOLD); doc.rect(0, 5, W, .9, "F"); };
  const txt = (s, x, y, o2 = {}) => doc.text(T(s), x, y, o2);
  const font = (st, sz, col = INK) => { doc.setFont("helvetica", st); doc.setFontSize(sz); doc.setTextColor(...col); };
  const footer = (p, n) => { doc.setDrawColor(...LINE); doc.setLineWidth(.3); doc.line(M, H - 16, W - M, H - 16); font("normal", 7.5, MUTED); txt(`${brand ? brand + "  ·  " : ""}Facture ${o.invoice}`, M, H - 11); txt("Merci de votre confiance.", M, H - 7.5); txt(`Page ${p}/${n}`, W - M, H - 11, { align: "right" }); };
  frame();

  // --- En-tête ---
  let y = 15;
  if (im.logo) { const l = prep(im.logo, { max: 500 }); let h = 16, w = h * l.w / l.h; if (w > 58) { w = 58; h = w * l.h / l.w; } doc.addImage(l.url, "PNG", M, y, w, h); if (brand) { font("normal", 8, MUTED); txt(brand, M, y + h + 4.5); } }
  else if (brand) { font("bold", 15, FOREST); txt(brand, M, y + 7); }
  font("bold", 26, FOREST); txt("FACTURE", W - M, y + 8, { align: "right" });
  font("normal", 9.5, MUTED); txt(`N° ${o.invoice}`, W - M, y + 14.5, { align: "right" });

  // --- QR de validation (scanné dans l'admin pour confirmer / remettre la facture) ---
  try { const qc = await loadQr(); if (qc) { const d = makeQr(qc, `EDM:${o.invoice}`, im.logo); doc.addImage(d, "PNG", W - M - 25, 31, 25, 25); } } catch { }

  // --- Blocs d'information ---
  y = 60;
  const block = (title, lines, x) => { font("bold", 7.5, GOLD); txt(title.toUpperCase(), x, y); font("normal", 9.5, INK); let yy = y + 5.5; for (const l of lines.filter(Boolean)) for (const s of doc.splitTextToSize(T(l), 54)) { txt(s, x, yy); yy += 4.7; } return yy; };
  const dig = isDigitalOnly(o), mode = modeLabel(o) || "Retrait en agence";
  const e1 = block("Facturé à", [`${o.name || ""} ${o.surname || ""}`.trim(), o.email, o.phone, o.mode === "delivery" ? o.address : "", o.mode === "delivery" ? [o.city, o.country].filter(Boolean).join(", ") : ""], M);
  const e2 = block("Commande", [`Date : ${fdate(o.date, true)}`, `Mode : ${mode}`, PAY_LABEL], M + 62);
  const e3 = block(dig ? "Règlement à l'agence" : o.mode === "delivery" ? "Livraison depuis l'agence" : "Retrait à l'agence", [o.agencyName, o.agencyAddress, o.agencyCity, o.agencyPhone], M + 124);
  y = Math.max(e1, e2, e3) + 6;

  // --- Tableau ---
  const cP = M + 3, cA = M + 84, cQ = M + 118, cU = M + 146, cT = W - M - 3;
  const head = () => { doc.setFillColor(...FOREST); doc.roundedRect(M, y, W - 2 * M, 8.5, 1.5, 1.5, "F"); font("bold", 8, [255, 255, 255]); txt("PUBLICATION", cP, y + 5.6); txt("AUTEUR", cA, y + 5.6); txt("QTÉ", cQ, y + 5.6, { align: "right" }); txt("PRIX UNIT.", cU, y + 5.6, { align: "right" }); txt("TOTAL", cT, y + 5.6, { align: "right" }); y += 8.5; };
  let pages = 1; const pageBreak = () => { doc.addPage(); pages++; frame(); y = 20; head(); };
  head();
  (o.items || []).forEach((it, i) => {
    const tl = doc.splitTextToSize(T(itemLabel(it)), 76).slice(0, 2), al = doc.splitTextToSize(T(it.author || ""), 26).slice(0, 2), rh = Math.max(tl.length, al.length) * 4.6 + 4.4;
    if (y + rh > H - 24) pageBreak();
    if (i % 2) { doc.setFillColor(250, 247, 240); doc.rect(M, y, W - 2 * M, rh, "F"); }
    font("bold", 9.5, INK); tl.forEach((s, k) => txt(s, cP, y + 5.2 + k * 4.6));
    font("normal", 8.5, MUTED); al.forEach((s, k) => txt(s, cA, y + 5.2 + k * 4.6));
    font("normal", 9.5, INK); txt(String(it.qty), cQ, y + 5.2, { align: "right" }); txt(fmtF(it.unit), cU, y + 5.2, { align: "right" });
    font("bold", 9.5, INK); txt(fmtF(it.unit * it.qty), cT, y + 5.2, { align: "right" });
    doc.setDrawColor(...LINE); doc.setLineWidth(.2); doc.line(M, y + rh, W - M, y + rh); y += rh;
  });

  // --- Totaux ---
  if (y > H - 100) pageBreak();
  y += 7;
  const bx = W - M - 82; doc.setFillColor(246, 240, 224); doc.roundedRect(bx, y, 82, paid ? 25 : 19, 2, 2, "F");
  font("bold", 9, MUTED); txt("TOTAL TTC", bx + 5, y + 8); font("bold", 15, FOREST); txt(fmtF(o.total), bx + 77, y + 8.4, { align: "right" });
  font("normal", 9, paid ? GREEN : AMBER);
  if (paid) { txt(`Réglé le ${fdate(paidAt, true)}`, bx + 5, y + 15.5); txt("Reste à payer : 0 F CFA", bx + 5, y + 20.5); }
  else txt(`Reste à payer : ${fmtF(o.total)}`, bx + 5, y + 15);
  font("bold", 7.5, GOLD); txt("MODALITÉ DE RÈGLEMENT", M, y + 3.5);
  font("normal", 9, INK); doc.splitTextToSize(T(`${PAY_LABEL} ${o.mode === "delivery" ? "à la livraison" : "au retrait en agence"}. Le paiement en ligne n'est pas disponible pour le moment.`), 88).forEach((s, k) => txt(s, M, y + 9 + k * 4.6));
  const totalsY = y; y += (paid ? 25 : 19) + 12;

  // --- Cachets : « ENCAISSÉ » + « PAYÉ » (payée) ou « IMPAYÉ » (à régler) par défaut ; images de l'admin si importées, à taille identique ---
  if (y > H - 78) { pageBreak(); }
  const sy = y, put = (src, [bw, bh], cx, cy, rot) => { const r = fitBox(src, bw, bh, rot); doc.addImage(r.url, "PNG", cx - r.w / 20, cy - r.h / 20, r.w / 10, r.h / 10); };
  if (im.seal) put(im.seal, BOX.seal, M + 21, sy + 19, -8);
  if (paid) put(im.stamp || fbStamp(fdate(paidAt)), BOX.stamp, M + 76, sy + 15.5, -6);
  put(paid ? (im.paid || fbPaid()) : (im.unpaid || fbUnpaid()), BOX.status, W - M - 29, sy + 9.5, -14);
  if (im.signature) put(im.signature, BOX.sign, W - M - 27, sy + 40, 0);
  for (let p = 1; p <= pages; p++) { doc.setPage(p); footer(p, pages); }
  return doc.output("blob");
}

/** Envoi du PDF sur Cloudinary (dossier « factures »). Retourne l'URL sécurisée. */
export async function uploadPdf(blob, name) {
  const fd = new FormData(); fd.append("file", blob, `${name}.pdf`); fd.append("upload_preset", CLOUD_PRESET); fd.append("folder", "factures"); fd.append("public_id", `${name}.pdf`);
  // Type « raw » : les PDF envoyés comme « image » sont bloqués en lecture par Cloudinary (erreur 401 « deny or ACL failure »)
  const res = await fetch(CLOUD_URL.replace(/\/(auto|image)\/upload/, "/raw/upload"), { method: "POST", body: fd }), d = await res.json().catch(() => ({}));
  if (!res.ok || !d.secure_url) throw new Error(d?.error?.message || "échec de l'envoi Cloudinary");
  return d.secure_url;
}
/** Lien de téléchargement direct (nom de fichier propre) pour une URL Cloudinary */
export const dlUrl = (u, name = "facture") => u && /res\.cloudinary\.com/.test(u) && u.includes("/image/upload/") && !u.includes("fl_attachment")
  ? u.replace("/upload/", `/upload/fl_attachment:${encodeURIComponent(String(name).replace(/[^\w-]/g, "_"))}/`) : u;
