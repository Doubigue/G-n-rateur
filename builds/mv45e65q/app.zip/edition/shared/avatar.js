// ============ Photo de profil : recadrage carré + envoi Cloudinary (même preset que le reste du site) ============
const UPLOAD_URL = "https://api.cloudinary.com/v1_1/iayfluiq/image/upload", PRESET = "blognews_unsigned", MAX_MB = 10;
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

/** Recadre au centre en carré et réduit (≤ 480 px) : fichier léger, même depuis un téléphone. */
export function cropSquare(file, size = 480) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file), img = new Image();
    img.onload = () => {
      const s = Math.min(img.width, img.height), c = document.createElement("canvas");
      c.width = c.height = Math.min(size, s);
      c.getContext("2d").drawImage(img, (img.width - s) / 2, (img.height - s) / 2, s, s, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      c.toBlob(b => b ? resolve(b) : reject(new Error("Image illisible.")), "image/jpeg", .88);
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error("Image illisible. Choisissez une photo JPG ou PNG.")); };
    img.src = url;
  });
}
export function checkImage(file) {
  if (!file.type.startsWith("image/")) throw new Error("Veuillez choisir une image.");
  if (file.size > MAX_MB * 1048576) throw new Error(`Photo trop lourde (max ${MAX_MB} Mo).`);
}
export async function uploadAvatar(file) {
  checkImage(file);
  const fd = new FormData();
  fd.append("file", await cropSquare(file), "profil.jpg"); fd.append("upload_preset", PRESET); fd.append("folder", "profils");
  const res = await fetch(UPLOAD_URL, { method: "POST", body: fd }), d = await res.json().catch(() => ({}));
  if (!res.ok || !d.secure_url) throw new Error(d?.error?.message || "échec du téléversement de la photo");
  return d.secure_url;
}
/** Pastille ronde : photo si disponible, sinon initiale. Styles en ligne (utilisable partout). */
export function avatarHtml(name, url, size = 40) {
  const base = `width:${size}px;height:${size}px;border-radius:50%;flex:none`;
  return url
    ? `<img src="${esc(url)}" alt="" style="${base};object-fit:cover;background:#f3efe8" loading="lazy">`
    : `<span style="${base};display:grid;place-items:center;background:#d4af37;color:#10281e;font-weight:700;font-size:${Math.round(size * .42)}px">${esc((name || "?").trim()[0]?.toUpperCase() || "?")}</span>`;
}
