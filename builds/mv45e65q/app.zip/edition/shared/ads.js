// ============ Module Annonces dynamiques : 8 styles, slider, compte à rebours, bandeau ============
// Collection Firestore : « siteAnnouncements » (lecture publique, écriture admin). Utilisé par app.js (site) et admin.html (aperçu).
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const safeUrl = u => { u = String(u || "").trim(); return (/^(?:https?:\/\/|mailto:|tel:|#|\/)/i.test(u) || /^[\w\-./]+\.html(?:[?#][\w=&%.\-]*)?$/i.test(u)) ? u : ""; };

export const AD_TYPES = {
  manuscrit:   ["📣", "Appel à manuscrits",   "Néon animé · puce clignotante"],
  partenariat: ["🤝", "Appel à partenariats", "Verre dépoli · flottement"],
  parution:    ["✨", "Nouvelle parution",     "Livre 3D qui se redresse"],
  paraitre:    ["⏳", "À paraître",            "Slider + compte à rebours"],
  ticker:      ["⚡", "Bandeau défilant",      "Flash info en haut de page"],
  event:       ["📅", "Événement / dédicace",  "Date, lieu, horaire"],
  quote:       ["❤️", "Coup de cœur",          "Citation du comité"],
  banner:      ["🎪", "Bannière promo / salon","Large, fond sombre"]
};
// Deux visibilités indépendantes (anciennes annonces : isActive vaut pour les deux)
export const liveSite = a => a && (a.showOnSite ?? a.isActive !== false) !== false;
export const livePage = a => a && (a.showInPage ?? a.isActive !== false) !== false;
const ts = t => t?.toMillis ? t.toMillis() : (t?.seconds ? t.seconds * 1000 : 0);
export const sortAds = l => [...l].sort((a, b) => (b.createdAt ? ts(b.createdAt) : Date.now()) - (a.createdAt ? ts(a.createdAt) : Date.now()));
const imgs = a => (Array.isArray(a.images) ? a.images : String(a.images || "").split(/\n+/)).map(s => String(s).trim()).filter(s => /^(https?:\/\/|data:image\/)/i.test(s));
const when = a => { const d = new Date(a.targetDate); return isNaN(d) ? null : d; };

const btn = a => { const u = safeUrl(a.btnUrl); return u && a.btnText ? `<a class="ad-btn" href="${esc(u)}"${/^https?:/i.test(u) ? ' target="_blank" rel="noopener"' : ""}>${esc(a.btnText)} <span aria-hidden="true">→</span></a>` : ""; };
const badge = (a, cls = "") => `<span class="ad-badge ${cls}">${a.badgeText ? esc(a.badgeText) : AD_TYPES[a.type][0] + " " + AD_TYPES[a.type][1]}</span>`;
const head = a => `<h3 class="ad-title">${esc(a.title || "Titre de l'annonce")}</h3>${a.subtitle ? `<p class="ad-sub">${esc(a.subtitle)}</p>` : ""}${a.description ? `<p class="ad-desc">${esc(a.description)}</p>` : ""}`;

/** Slider : 1 image = image fixe ; plusieurs = carrousel (auto 4 s, flèches ❮ ❯, points générés). */
function slider(a) {
  const l = imgs(a); if (!l.length) return "";
  const m = l.length > 1;
  return `<div class="ad-sl" data-n="${l.length}" data-i="0"><div class="ad-sl-track">${l.map((u, i) => `<img src="${esc(u)}" alt="${esc(a.title)} — visuel ${i + 1}" loading="lazy">`).join("")}</div>${m ? `<button type="button" class="ad-sl-p" data-d="-1" aria-label="Précédent">❮</button><button type="button" class="ad-sl-n" data-d="1" aria-label="Suivant">❯</button><div class="ad-sl-dots">${l.map((_, i) => `<button type="button" data-g="${i}" class="${i ? "" : "on"}" aria-label="Image ${i + 1}"></button>`).join("")}</div>` : ""}</div>`;
}
const countdown = a => { const d = when(a); return d ? `<div class="ad-cd" data-t="${d.getTime()}" role="timer" aria-label="Compte à rebours"><div class="ad-cd-end">Terminé</div>${["Jours", "Heures", "Minutes", "Secondes"].map((n, i) => `<div class="ad-cd-u"><b data-u="${i}">00</b><span>${n}</span></div>`).join('<i>:</i>')}</div>` : ""; };

export function renderAd(a) {
  const t = AD_TYPES[a.type] ? a.type : "banner", x = { ...a, type: t }, d = when(x), im = imgs(x);
  const body = {
    manuscrit: () => `<div class="ad-in">${badge(x, "ad-live")}${head(x)}${btn(x)}</div>`,
    partenariat: () => `<div class="ad-blob"></div><div class="ad-glass">${badge(x)}${head(x)}${btn(x)}</div>`,
    parution: () => `<div class="ad-book" tabindex="0" aria-label="Aperçu 3D">${im[0] ? `<img src="${esc(im[0])}" alt="Couverture de ${esc(x.title)}">` : `<div class="ad-nocover">${esc(x.title)}</div>`}</div><div class="ad-txt">${badge(x)}${head(x)}${btn(x)}</div>`,
    paraitre: () => `<div class="ad-media">${slider(x)}</div><div class="ad-txt">${badge(x)}${head(x)}${countdown(x)}${btn(x)}</div>`,
    event: () => `<div class="ad-date ${d && d < Date.now() ? "past" : ""}"><b>${d ? d.getDate() : "—"}</b><span>${d ? d.toLocaleDateString("fr-FR", { month: "short" }).replace(".", "") : ""}</span></div><div class="ad-txt">${badge(x)}${head(x)}<ul class="ad-meta">${x.location ? `<li>📍 ${esc(x.location)}</li>` : ""}${d ? `<li>🕒 ${d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }).replace(":", "h")}</li>` : ""}</ul>${btn(x)}</div>`,
    quote: () => `<span class="ad-qm" aria-hidden="true">“</span><div class="ad-txt">${badge(x, "ad-reco")}<blockquote class="ad-q">${esc(x.description || "")}</blockquote><p class="ad-sign">— <b>${esc(x.title || "")}</b>${x.subtitle ? `, ${esc(x.subtitle)}` : ""}</p>${btn(x)}</div>${im[0] ? `<img class="ad-thumb" src="${esc(im[0])}" alt="">` : ""}`,
    banner: () => `${im[0] ? `<img class="ad-bg" src="${esc(im[0])}" alt="" loading="lazy">` : ""}<div class="ad-in">${badge(x)}${head(x)}${btn(x)}</div>`,
    ticker: () => renderTicker([x], true)
  }[t]();
  return t === "ticker" ? body : `<article class="ad ad-${t}" data-id="${esc(a.id || "")}">${body}</article>`;
}


/** Carrousel des annonces : défilement horizontal de gauche à droite d'une annonce à l'autre (swipe, flèches, points, auto 6 s). */
export function renderCarousel(list) {
  const slides = list.map(renderAd).filter(Boolean), n = slides.length;
  if (!n) return "";
  const bar = n > 1 ? `<div class="ad-car-bar"><button type="button" class="ad-car-b" data-c="-1" aria-label="Annonce précédente">❮</button><div class="ad-car-dots">${slides.map((_, i) => `<button type="button" data-cg="${i}" class="${i ? "" : "on"}" aria-label="Annonce ${i + 1}"><u></u></button>`).join("")}</div><span class="ad-car-count" aria-hidden="true">1 / ${n}</span><button type="button" class="ad-car-b" data-c="1" aria-label="Annonce suivante">❯</button></div>` : "";
  return `<div class="ad-car" data-n="${n}" data-i="0" role="region" aria-roledescription="carrousel" aria-label="Annonces"><div class="ad-car-vp" tabindex="0"><div class="ad-car-track">${slides.map((h, i) => `<div class="ad-car-slide${i ? "" : " is-active"}" role="group" aria-roledescription="diapositive" aria-label="${i + 1} sur ${n}">${h}</div>`).join("")}</div></div>${bar}</div>`;
}

/** Bandeau défilant. inline=true : version aperçu (admin) ; sinon fixé sous l'en-tête. */
export function renderTicker(list, inline = false) {
  const items = list.map(a => { const u = safeUrl(a.btnUrl), inner = `<b>${esc(a.badgeText || "⚡ Flash")}</b> ${esc(a.title)}${a.description ? " — " + esc(a.description) : ""}`; return u ? `<a href="${esc(u)}">${inner}</a>` : `<span>${inner}</span>`; }).join("");
  if (!items) return "";
  const run = `<div class="ad-tk-run">${items}</div>`;
  return `<div class="ad-tk${inline ? " inline" : ""}" role="region" aria-label="Actualités flash"><div class="ad-tk-track">${run}${run.replace('class="ad-tk-run"', 'class="ad-tk-run" aria-hidden="true"')}</div>${inline ? "" : '<button type="button" class="ad-tk-x" aria-label="Fermer le bandeau">✕</button>'}</div>`;
}

/** Montage du bandeau en haut de page (site public). */
export function mountTicker(host, list) {
  const live = list.filter(a => liveSite(a) && a.type === "ticker"), closed = (() => { try { return sessionStorage.getItem("ad-tk-x") === "1"; } catch { return false; } })();
  host.innerHTML = live.length && !closed ? renderTicker(live) : "";
  const bar = host.firstElementChild, hdr = document.querySelector("header");
  const set = () => { document.documentElement.style.setProperty("--tk-top", (hdr?.offsetHeight || 0) + "px"); document.documentElement.style.setProperty("--tk-h", bar ? "38px" : "0px"); };
  set(); if (bar) { addEventListener("resize", set); bar.querySelector(".ad-tk-x").onclick = () => { try { sessionStorage.setItem("ad-tk-x", "1"); } catch {} host.innerHTML = ""; set(); }; }
  const dur = bar ? Math.max(18, bar.querySelector(".ad-tk-run").textContent.length * 0.22) : 0; if (bar) bar.style.setProperty("--tk-d", dur + "s");
}

// ---------- Comportements (une seule fois) : slider auto 4 s + compte à rebours 1 s ----------
const go = (sl, i) => { const n = +sl.dataset.n; i = (i + n) % n; sl.dataset.i = i; sl.querySelector(".ad-sl-track").style.transform = `translateX(-${i * 100}%)`; sl.querySelectorAll(".ad-sl-dots button").forEach((b, k) => b.classList.toggle("on", k === i)); };
const pad = n => String(Math.max(0, n)).padStart(2, "0");
function tick() {
  document.querySelectorAll(".ad-cd").forEach(c => {
    const s = Math.floor((+c.dataset.t - Date.now()) / 1e3), end = s <= 0, v = [Math.floor(s / 86400), Math.floor(s % 86400 / 3600), Math.floor(s % 3600 / 60), s % 60];
    c.classList.toggle("done", end); c.querySelectorAll("[data-u]").forEach((b, i) => b.textContent = pad(end ? 0 : v[i]));
  });
}

// ---------- Carrousel d'annonces ----------
const CAR_MS = 6000, reduced = () => matchMedia("(prefers-reduced-motion:reduce)").matches;
const carStep = car => { const s = car.querySelectorAll(".ad-car-slide"); return s.length > 1 ? s[1].offsetLeft - s[0].offsetLeft : car.querySelector(".ad-car-vp").clientWidth; };
function carSet(car, i) {
  const n = +car.dataset.n; if (+car.dataset.i === i && car._init) return; car._init = true; car.dataset.i = i; car._next = Date.now() + CAR_MS;
  car.querySelectorAll(".ad-car-slide").forEach((s, k) => s.classList.toggle("is-active", k === i));
  car.querySelectorAll(".ad-car-dots button").forEach((b, k) => b.classList.toggle("on", k === i));
  const c = car.querySelector(".ad-car-count"); if (c) c.textContent = `${i + 1} / ${n}`;
}
function carGo(car, i, user) {
  const n = +car.dataset.n; i = (i + n) % n; if (user) car._pause = Date.now() + 8000;
  car.querySelector(".ad-car-vp").scrollTo({ left: i * carStep(car), behavior: reduced() ? "auto" : "smooth" }); carSet(car, i);
}
function startCarousels() {
  document.addEventListener("click", e => {
    const car = e.target.closest(".ad-car"); if (!car) return;
    const b = e.target.closest("[data-c]"), g = e.target.closest("[data-cg]");
    if (b) carGo(car, +car.dataset.i + +b.dataset.c, true); else if (g) carGo(car, +g.dataset.cg, true);
  });
  let raf = 0;
  document.addEventListener("scroll", e => {
    const vp = e.target; if (!vp.classList || !vp.classList.contains("ad-car-vp")) return;
    cancelAnimationFrame(raf); raf = requestAnimationFrame(() => { const car = vp.closest(".ad-car"), st = carStep(car); if (st > 0) carSet(car, Math.max(0, Math.min(+car.dataset.n - 1, Math.round(vp.scrollLeft / st)))); });
  }, true);
  ["pointerdown", "wheel", "touchstart"].forEach(t => document.addEventListener(t, e => { const car = e.target.closest && e.target.closest(".ad-car"); if (car) car._pause = Date.now() + 8000; }, { passive: true }));
  document.addEventListener("keydown", e => { const vp = e.target.closest && e.target.closest(".ad-car-vp"); if (!vp || (e.key !== "ArrowLeft" && e.key !== "ArrowRight")) return; e.preventDefault(); const car = vp.closest(".ad-car"); carGo(car, +car.dataset.i + (e.key === "ArrowRight" ? 1 : -1), true); });
  setInterval(() => document.querySelectorAll(".ad-car").forEach(car => {
    if (+car.dataset.n < 2 || reduced() || document.hidden) return;
    if (!car._next) car._next = Date.now() + CAR_MS;
    const r = car.getBoundingClientRect(), seen = r.bottom > 0 && r.top < innerHeight;
    if (!seen || car.matches(":hover") || car.contains(document.activeElement) || Date.now() < (car._pause || 0)) { car._next = Math.max(car._next, Date.now() + 400); return; }
    if (Date.now() >= car._next) carGo(car, +car.dataset.i + 1);
  }), 300);
}

let started = false;
export function startAds() {
  if (started) return; started = true;
  document.addEventListener("click", e => {
    const sl = e.target.closest(".ad-sl"); if (!sl) return;
    const d = e.target.closest("[data-d]"), g = e.target.closest("[data-g]");
    if (d) go(sl, +sl.dataset.i + +d.dataset.d); else if (g) go(sl, +g.dataset.g);
    sl.dataset.pause = Date.now() + 6000;
  });
  document.addEventListener("touchstart", e => { const sl = e.target.closest(".ad-sl"); if (sl) sl._x = e.touches[0].clientX; }, { passive: true });
  document.addEventListener("touchend", e => { const sl = e.target.closest(".ad-sl"); if (sl && sl._x != null && sl.dataset.n > 1) { const dx = e.changedTouches[0].clientX - sl._x; if (Math.abs(dx) > 40) go(sl, +sl.dataset.i + (dx < 0 ? 1 : -1)); sl._x = null; } });
  setInterval(() => document.querySelectorAll(".ad-sl").forEach(sl => { if (+sl.dataset.n > 1 && !sl.matches(":hover") && Date.now() > +(sl.dataset.pause || 0)) go(sl, +sl.dataset.i + 1); }), 4000);
  startCarousels();
  setInterval(tick, 1000); tick();
}
export const refreshAds = () => { startAds(); tick(); };

const CSS = `
.ad,.ad *,.ad-tk,.ad-tk *{box-sizing:border-box}
.ad{position:relative;overflow:hidden;isolation:isolate;border-radius:24px;margin:0;font-family:Inter,system-ui,sans-serif;animation:adIn .7s cubic-bezier(.2,.8,.2,1) both}
@keyframes adIn{from{opacity:0;transform:translateY(22px)}to{opacity:1;transform:none}}
.ad-title{font:700 clamp(22px,3.4vw,30px)/1.15 Georgia,serif;margin:12px 0 6px}.ad-sub{font-size:13px;font-weight:600;opacity:.75;margin:0 0 8px}.ad-desc{font-size:15px;line-height:1.55;margin:0 0 4px;opacity:.92;white-space:pre-wrap;word-break:break-word}
.ad-badge{display:inline-flex;align-items:center;gap:8px;font:700 11px/1 Inter,sans-serif;letter-spacing:.08em;text-transform:uppercase;padding:7px 12px;border-radius:99px;background:rgba(255,255,255,.18)}
.ad-btn{display:inline-flex;align-items:center;gap:8px;margin-top:16px;padding:12px 20px;border-radius:99px;font:700 14px Inter,sans-serif;text-decoration:none;background:#d4af37;color:#10281e;transition:transform .2s,box-shadow .2s}.ad-btn:hover{transform:translateY(-2px);box-shadow:0 10px 24px -8px rgba(212,175,55,.7)}.ad-btn span{transition:transform .2s}.ad-btn:hover span{transform:translateX(4px)}
.ad-txt{min-width:0}
/* 1 · Appel à manuscrits : bordure conique animée + puce clignotante */
@property --a{syntax:"<angle>";initial-value:0deg;inherits:false}
.ad-manuscrit{color:#e8fff7;border:2.5px solid transparent;background:linear-gradient(#0b1712,#0b1712) padding-box,conic-gradient(from var(--a),#39ffb6,#d4af37,#7d1f2b,#39ffb6) border-box;animation:adIn .7s both,adSpin 4s linear infinite;box-shadow:0 0 28px -6px rgba(57,255,182,.45)}
@keyframes adSpin{to{--a:360deg}}
.ad-in{padding:26px 24px}.ad-manuscrit .ad-title{color:#7dffd0}
.ad-live::before{content:"";width:9px;height:9px;border-radius:50%;background:#39ffb6;animation:adDot 1.4s ease-out infinite}
@keyframes adDot{0%{box-shadow:0 0 0 0 rgba(57,255,182,.8)}100%{box-shadow:0 0 0 10px rgba(57,255,182,0)}}
/* 2 · Partenariats : glassmorphism flottant */
.ad-partenariat{padding:28px 20px;color:#fff;background:linear-gradient(135deg,#173b3a,#2f2a3d 55%,#7d1f2b)}
.ad-blob{position:absolute;inset:auto -40px -60px auto;width:220px;height:220px;border-radius:50%;background:#d4af37;filter:blur(50px);opacity:.5;z-index:-1;animation:adFloat 8s ease-in-out infinite}
.ad-glass{padding:24px;border-radius:20px;background:rgba(255,255,255,.14);border:1px solid rgba(255,255,255,.3);-webkit-backdrop-filter:blur(14px);backdrop-filter:blur(14px);box-shadow:0 20px 40px -20px rgba(0,0,0,.5);animation:adFloat 6s ease-in-out infinite}
@keyframes adFloat{50%{transform:translateY(-8px)}}
/* 3 · Nouvelle parution : livre 3D */
.ad-parution{display:grid;grid-template-columns:auto 1fr;gap:28px;align-items:center;padding:26px;background:#f4ecd8;color:#10281e}
.ad-parution .ad-badge{background:#10281e;color:#f4ecd8}
.ad-book{width:150px;perspective:700px;outline:0}.ad-book img,.ad-nocover{display:block;width:100%;aspect-ratio:2/3;object-fit:cover;border-radius:3px 8px 8px 3px;transform:rotateY(-32deg) rotateX(4deg);transform-origin:left center;transition:transform .55s cubic-bezier(.2,.8,.2,1),box-shadow .55s;box-shadow:-14px 14px 26px rgba(16,40,30,.4)}
.ad-nocover{display:grid;place-items:center;padding:10px;text-align:center;background:#10281e;color:#d4af37;font:700 15px Georgia,serif}
.ad-book:hover img,.ad-book:focus img,.ad-parution:hover .ad-book img,.ad-book:hover .ad-nocover{transform:rotateY(0) rotateX(0) scale(1.05);box-shadow:0 18px 30px rgba(16,40,30,.35)}
/* 4 · À paraître : slider + compte à rebours */
.ad-paraitre{display:grid;grid-template-columns:minmax(0,.9fr) minmax(0,1.1fr);gap:24px;align-items:center;padding:22px;background:linear-gradient(135deg,#10281e,#1b3d2d);color:#f6efdc}
.ad-sl{position:relative;overflow:hidden;border-radius:16px;aspect-ratio:4/3;background:#0a1a13}.ad-sl-track{display:flex;height:100%;transition:transform .6s cubic-bezier(.2,.8,.2,1)}.ad-sl-track img{flex:0 0 100%;width:100%;height:100%;object-fit:cover}
.ad-sl-p,.ad-sl-n{position:absolute;top:50%;transform:translateY(-50%);width:36px;height:36px;border:0;border-radius:50%;background:rgba(16,40,30,.7);color:#fff;font-size:15px;cursor:pointer}.ad-sl-p{left:8px}.ad-sl-n{right:8px}.ad-sl-p:hover,.ad-sl-n:hover{background:#d4af37;color:#10281e}
.ad-sl-dots{position:absolute;bottom:10px;left:0;right:0;display:flex;justify-content:center;gap:7px}.ad-sl-dots button{width:9px;height:9px;padding:0;border:0;border-radius:99px;background:rgba(255,255,255,.55);cursor:pointer;transition:width .25s,background .25s}.ad-sl-dots .on{width:24px;background:#d4af37}
.ad-cd{display:flex;align-items:flex-start;gap:6px;margin-top:14px;flex-wrap:wrap}.ad-cd-u{min-width:58px;text-align:center;padding:9px 6px;border-radius:12px;background:rgba(255,255,255,.12)}.ad-cd-u b{display:block;font:700 26px/1 Georgia,serif;font-variant-numeric:tabular-nums;color:#e8cb6a}.ad-cd-u span{font-size:10px;text-transform:uppercase;letter-spacing:.08em;opacity:.75}.ad-cd>i{font-style:normal;font-size:22px;padding-top:8px;opacity:.6}
.ad-cd-end{display:none;font:700 18px Georgia,serif;color:#e8cb6a;padding:10px 0}.ad-cd.done .ad-cd-u,.ad-cd.done>i{display:none}.ad-cd.done .ad-cd-end{display:block}
/* 5 · Bandeau défilant */
.ad-tk{position:fixed;left:0;right:0;top:var(--tk-top,60px);z-index:39;height:38px;display:flex;align-items:center;overflow:hidden;background:linear-gradient(90deg,#7d1f2b,#b42318);color:#fff;font:600 13.5px Inter,sans-serif;box-shadow:0 6px 16px -8px rgba(0,0,0,.5)}
.ad-tk.inline{position:relative;top:auto;border-radius:12px}
body{padding-top:var(--tk-h,0px)}
.ad-tk-track{display:flex;width:max-content;animation:adMarq var(--tk-d,25s) linear infinite}.ad-tk:hover .ad-tk-track{animation-play-state:paused}.ad-tk-run{display:flex;gap:56px;padding-right:56px;white-space:nowrap}.ad-tk-run a,.ad-tk-run span{color:#fff;text-decoration:none}.ad-tk-run b{background:rgba(255,255,255,.2);padding:3px 8px;border-radius:99px;margin-right:6px;font-size:11px}
@keyframes adMarq{to{transform:translateX(-50%)}}
.ad-tk-x{position:absolute;right:0;top:0;bottom:0;width:38px;border:0;background:linear-gradient(90deg,transparent,#b42318 40%);color:#fff;cursor:pointer}
/* 6 · Événement / dédicace */
.ad-event{display:flex;gap:20px;align-items:center;padding:22px;background:#fff;color:#10281e;border:1px solid #e7e1d7;box-shadow:0 14px 30px -20px rgba(16,40,30,.5)}
.ad-event .ad-badge{background:#f6eed3}.ad-date{flex:none;width:84px;text-align:center;border-radius:18px;overflow:hidden;background:#10281e;color:#d4af37;box-shadow:0 8px 18px -8px rgba(16,40,30,.6)}.ad-date b{display:block;font:700 38px/1 Georgia,serif;padding:14px 0 4px}.ad-date span{display:block;padding:5px 0 8px;background:#d4af37;color:#10281e;font:800 12px Inter,sans-serif;text-transform:uppercase;letter-spacing:.12em}.ad-date.past{filter:grayscale(1);opacity:.6}
.ad-meta{list-style:none;margin:6px 0 0;padding:0;display:flex;flex-wrap:wrap;gap:6px 16px;font-size:14px;font-weight:600}
.ad-event .ad-btn{background:#10281e;color:#fff}
/* 7 · Coup de cœur : citation */
.ad-quote{display:flex;gap:18px;align-items:center;padding:28px 24px 24px;background:#fffaf0;color:#3b2a1a;border:2.5px dotted #c9962b}
.ad-qm{position:absolute;top:-16px;left:14px;font:700 120px/1 Georgia,serif;color:#c9962b;opacity:.28;z-index:-1}
.ad-reco{background:#b42318;color:#fff}.ad-q{margin:14px 0 8px;font:italic 500 clamp(18px,2.6vw,22px)/1.5 Georgia,serif;white-space:pre-wrap}.ad-sign{font-size:14px;margin:0}.ad-quote .ad-btn{background:#3b2a1a;color:#fffaf0}
.ad-thumb{flex:none;width:96px;aspect-ratio:2/3;object-fit:cover;border-radius:6px;box-shadow:6px 8px 16px -6px rgba(0,0,0,.45);transform:rotate(3deg)}
/* 8 · Bannière promo / salon */
.ad-banner{color:#fff;background:linear-gradient(120deg,#0a1a13,#1b3d2d 55%,#2f2a3d);min-height:210px;display:flex;align-items:center}
.ad-bg{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;opacity:.32;z-index:-1}.ad-banner .ad-in{max-width:640px;padding:34px 28px}.ad-banner .ad-title{font-size:clamp(26px,4.2vw,40px)}
/* Mobile : MÊME disposition que sur ordinateur, simplement proportionnée à l'écran */
@media(max-width:640px){
.ad{border-radius:20px}.ad-in{padding:20px 16px}.ad-title{font-size:clamp(19px,5.4vw,24px);margin:10px 0 5px}.ad-sub{font-size:12px}.ad-desc{font-size:13px;line-height:1.5}
.ad-badge{font-size:9.5px;padding:6px 9px;letter-spacing:.06em}.ad-btn{padding:10px 15px;font-size:12.5px;margin-top:12px}
.ad-partenariat{padding:18px 12px}.ad-glass{padding:18px}
.ad-parution{grid-template-columns:minmax(0,34%) minmax(0,1fr);gap:16px;padding:18px 16px}.ad-book{width:100%}
.ad-paraitre{grid-template-columns:minmax(0,.8fr) minmax(0,1.2fr);gap:14px;padding:16px 14px}.ad-sl{border-radius:12px;aspect-ratio:3/4}.ad-sl-p,.ad-sl-n{width:26px;height:26px;font-size:11px}.ad-sl-p{left:5px}.ad-sl-n{right:5px}
.ad-cd{flex-wrap:nowrap;gap:4px;margin-top:10px}.ad-cd>i{display:none}.ad-cd-u{flex:1;min-width:0;padding:6px 1px;border-radius:9px}.ad-cd-u b{font-size:16px}.ad-cd-u span{display:block;font-size:7px;letter-spacing:0;overflow:hidden;text-overflow:ellipsis}
.ad-event{gap:14px;padding:18px 16px;align-items:center}.ad-date{width:62px;border-radius:14px}.ad-date b{font-size:28px;padding:10px 0 3px}.ad-date span{font-size:10px;padding:4px 0 6px}.ad-meta{font-size:12.5px;gap:4px 12px}
.ad-quote{gap:12px;padding:24px 16px 20px}.ad-q{font-size:15.5px;margin:10px 0 6px}.ad-sign{font-size:12.5px}.ad-thumb{width:64px;align-self:center}
.ad-banner{min-height:170px}.ad-banner .ad-in{padding:24px 18px}.ad-banner .ad-title{font-size:clamp(21px,6.4vw,28px)}
}
/* Section publique */
.ad-tabs{display:flex;gap:8px;overflow-x:auto;padding:4px 2px 10px;margin:22px 0 6px;scrollbar-width:none}.ad-tabs::-webkit-scrollbar{display:none}
.ad-tab{flex:none;padding:8px 16px;border-radius:99px;border:1px solid rgba(16,40,30,.25);background:#fff;color:#10281e;font:600 13px Inter,sans-serif;cursor:pointer;transition:background .2s,color .2s}.ad-tab.on{background:#10281e;color:#d4af37;border-color:#10281e}.ad-tab i{font-style:normal;opacity:.6;margin-left:4px}
.ad-list{display:block}
/* Carrousel : défilement horizontal stylé d'une annonce à l'autre */
.ad-car{position:relative;max-width:100%}
.ad-car-vp{overflow-x:auto;overflow-y:hidden;scroll-snap-type:x mandatory;scroll-padding-inline:14px;overscroll-behavior-x:contain;-webkit-overflow-scrolling:touch;scrollbar-width:none;padding:12px 14px 26px;margin:-12px -14px -10px;outline:0}
.ad-car-vp::-webkit-scrollbar{display:none}
.ad-car-vp:focus-visible{box-shadow:0 0 0 2px #d4af37;border-radius:26px}
.ad-car-track{display:flex;gap:18px}
.ad-car-slide{flex:0 0 100%;min-width:0;display:flex;scroll-snap-align:start;scroll-snap-stop:always;transform:translateX(0) scale(.92);opacity:.45;filter:saturate(.7) blur(.4px);transition:transform .7s cubic-bezier(.2,.8,.2,1),opacity .6s ease,filter .6s ease}
.ad-car-slide.is-active{transform:none;opacity:1;filter:none}
.ad-car-slide>.ad{flex:1;min-width:0}
.ad-sl{touch-action:pan-y}
.ad-car-bar{display:flex;align-items:center;justify-content:center;gap:12px;margin-top:8px}
.ad-car-b{flex:none;width:38px;height:38px;border:0;border-radius:50%;background:#10281e;color:#e8cb6a;font-size:14px;cursor:pointer;display:grid;place-items:center;box-shadow:0 8px 16px -8px rgba(16,40,30,.7);transition:transform .2s,background .2s,color .2s;-webkit-tap-highlight-color:transparent}
.ad-car-b:hover{background:#d4af37;color:#10281e}.ad-car-b:active{transform:scale(.9)}
.ad-car-dots{display:flex;align-items:center;gap:7px;min-width:0;overflow:hidden;padding:4px}
.ad-car-dots button{position:relative;flex:none;width:9px;height:9px;padding:0;border:0;border-radius:99px;background:rgba(16,40,30,.22);cursor:pointer;overflow:hidden;transition:width .4s cubic-bezier(.2,.8,.2,1),background .3s}
.ad-car-dots button u{position:absolute;inset:0;border-radius:inherit;background:#8b6a32;transform:scaleX(0);transform-origin:left}
.ad-car-dots button.on{width:34px;background:rgba(16,40,30,.16)}
.ad-car-dots button.on u{animation:adProg 6s linear forwards}
.ad-car:hover .ad-car-dots button.on u{animation-play-state:paused}
@keyframes adProg{to{transform:scaleX(1)}}
.ad-car-count{flex:none;font:700 12px Inter,sans-serif;letter-spacing:.06em;color:rgba(16,40,30,.6);min-width:38px;text-align:center;font-variant-numeric:tabular-nums}
@media(max-width:380px){.ad-car-count{display:none}}
@media(prefers-reduced-motion:reduce){.ad-car-slide{transition:none;transform:none;opacity:1;filter:none}.ad-car-dots button.on u{animation:none;transform:scaleX(1)}}
@media(prefers-reduced-motion:reduce){.ad,.ad *,.ad-tk-track{animation:none!important;transition:none!important}.ad-tk-track{overflow-x:auto}}
`;
export function injectAdsCss() { if (!document.getElementById("ads-style")) document.head.append(Object.assign(document.createElement("style"), { id: "ads-style", textContent: CSS })); }
