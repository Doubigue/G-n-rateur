// Étapes du parcours d'un manuscrit (ordre = progression)
export const STATUSES = [
  ["pending", "Manuscrit reçu"],
  ["consultation", "En consultation"],
  ["reading25", "En lecture — 25 %"], ["reading50", "En lecture — 50 %"], ["reading75", "En lecture — 75 %"], ["reading100", "En lecture — 100 %"], ["accepted", "Manuscrit accepté"],
  ["correction25", "En correction — 25 %"], ["correction50", "En correction — 50 %"], ["correction75", "En correction — 75 %"], ["correction100", "En correction — 100 %"],
  ["editing", "En cours d'édition"], ["edited", "Édition terminée"],
  ["printed", "Impression terminée"],
  ["publishing", "En cours de publication"], ["published", "Publication terminée"]
];
export const GROUPS = [
  ["Réception", ["pending", "consultation"]],
  ["Lecture", ["reading25", "reading50", "reading75", "reading100"]],
  ["Décision", ["accepted", "rejected"]],
  ["Correction", ["correction25", "correction50", "correction75", "correction100"]],
  ["Production", ["editing", "edited", "printed", "publishing", "published"]]
];
const LEGACY = { reading: "En lecture", correction: "En correction", rejected: "Manuscrit refusé" };
export const LABEL = { ...LEGACY, ...Object.fromEntries(STATUSES) };
export const label = k => LABEL[k] || k || "Manuscrit reçu";
export const progress = k => { const i = STATUSES.findIndex(s => s[0] === k); return i < 0 ? 0 : Math.round(i / (STATUSES.length - 1) * 100); };
export const bar = k => {
  const rej = k === "rejected", p = rej ? progress("accepted") : progress((typeof LEGACY_KEY !== "undefined" && LEGACY_KEY[k]) || k);
  const col = rej ? "linear-gradient(90deg,#b42318,#e63b2e)" : "linear-gradient(90deg,#d4af37,#e8cb6a)";
  const track = rej ? "#fde4e1" : "rgba(127,127,127,.25)";
  return `<div role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${p}" style="height:8px;border-radius:99px;background:${track};overflow:hidden;margin-top:8px"><div class="pg-fill" style="height:100%;width:${Math.max(4, p)}%;background:${col};border-radius:99px"></div></div>${rej ? `<p style="margin-top:6px;font-size:12px;font-weight:600;color:#b42318">⛔ Dossier clos — progression bloquée à ${p} %</p>` : `<span style="font-size:11px;opacity:.7">${p} % du parcours</span>`}`;
};

// ---- Étapes principales (frise) ----
export const PHASES = [
  ["Réception", ["pending", "consultation"]],
  ["Lecture", ["reading", "reading25", "reading50", "reading75", "reading100"]],
  ["Décision", ["accepted", "rejected"]],
  ["Correction", ["correction", "correction25", "correction50", "correction75", "correction100"]],
  ["Production", ["editing", "edited", "printed", "publishing", "published"]]
];
export const phaseIndex = k => { const i = PHASES.findIndex(([, ks]) => ks.includes(k)); return i < 0 ? 0 : i; };
/** Frise numérotée (cercles + traits), état actuel en rouge. Styles en ligne : utilisable sur toutes les pages. */
export function stepper(k) {
  const rej = k === "rejected", fin = k === "published", cur = fin ? PHASES.length : phaseIndex(k);
  const RED = "#e63b2e", DARK = "#10281e";
  const items = PHASES.map(([name], i) => {
    const done = i < cur, on = i === cur;
    const bg = done ? DARK : on ? (rej ? "#b42318" : RED) : "#eef2f8";
    const fg = done ? "#d4af37" : on ? "#fff" : "#94a3b8";
    const txt = done ? "✓" : on && rej ? "✕" : i + 1;
    const circle = `<div class="pg-pop${on ? " pg-pulse" : ""}${on && rej ? " pg-bad" : ""}" style="--d:${(i * 0.14).toFixed(2)}s;width:44px;height:44px;border-radius:50%;background:${bg};color:${fg};display:grid;place-items:center;font-weight:700;font-size:17px;flex:none">${txt}</div>`;
    const lab = `<span style="margin-top:8px;font-size:11px;font-weight:600;white-space:nowrap;color:${on ? "#0f172a" : done ? "#334155" : "#94a3b8"}">${name}</span>`;
    const col = `<div style="display:flex;flex-direction:column;align-items:center;width:44px;flex:none">${circle}${lab}</div>`;
    const line = i < PHASES.length - 1 ? `<div class="${i < cur ? "pg-line" : ""}" style="--d:${(i * 0.14 + 0.1).toFixed(2)}s;flex:1;min-width:6px;height:3px;margin:20px 6px 0;border-radius:3px;background:${i < cur ? DARK : "#e2e8f0"}"></div>` : "";
    return col + line;
  }).join("");
  return `<div class="pg ${ANIM ? "pg-a" : ""}" style="border:1px solid ${rej ? "#f3b4ae" : "#e7ebf3"};border-radius:22px;padding:20px 16px 16px;background:${rej ? "#fff8f7" : "#fff"};color:#0f172a;text-align:left"><div style="display:flex;align-items:flex-start;padding-bottom:6px">${items}</div><p style="margin-top:14px;font-size:13px">Étape actuelle : <b>${label(k)}</b></p>${bar(k)}</div>`;
}

// =====================================================================
//  NIVEAUX DE PROGRESSION + STYLES D'AFFICHAGE (pilotés par l'administration)
//  Champs Firestore d'un manuscrit : currentLevelId ("lvl-2"…), displayStyle
//  ("stepper" | "timeline" | "circular"), updatedAt.
// =====================================================================
const escH = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const RED = "#e63b2e", ALERT = "#b42318", DARK = "#10281e", GOLD = "#d4af37";

/** lvl-1 … lvl-16 = STATUSES dans l'ordre ; "lvl-refuse" = manuscrit refusé (isRefuse). */
export const LEVELS = [
  ...STATUSES.map(([key, name], i) => ({ id: `lvl-${i + 1}`, key, label: name })),
  { id: "lvl-refuse", key: "rejected", label: "Manuscrit refusé", isRefuse: true }
];
const LEVEL_BY_ID = Object.fromEntries(LEVELS.map(l => [l.id, l]));
const LEVEL_BY_KEY = Object.fromEntries(LEVELS.map(l => [l.key, l]));
const LEGACY_KEY = { reading: "reading25", correction: "correction25" };
export const levelOfKey = k => LEVEL_BY_KEY[LEGACY_KEY[k] || k] || LEVELS[0];
/** Niveau d'un manuscrit : currentLevelId en priorité, sinon l'ancien champ status. */
export const levelOf = m => LEVEL_BY_ID[m?.currentLevelId] || levelOfKey(m?.status);
export const isRefuse = m => levelOf(m).isRefuse === true;

export const STYLES = [
  ["stepper", "Stepper horizontal", "Cercles numérotés"],
  ["timeline", "Timeline verticale", "Étapes empilées"],
  ["circular", "Jauge circulaire", "Anneau de pourcentage"]
];
export const DEFAULT_STYLE = "stepper";
export const styleOf = m => STYLES.some(s => s[0] === m?.displayStyle) ? m.displayStyle : DEFAULT_STYLE;

const cardCss = rej => `border:1px solid ${rej ? "#f3b4ae" : "#e7ebf3"};border-radius:22px;padding:20px 18px;background:${rej ? "#fff8f7" : "#fff"};color:#0f172a;text-align:left`;

/** Timeline verticale : 5 phases ; la phase en cours déroule ses sous-niveaux. */
export function timelineView(k) {
  const rej = k === "rejected", fin = k === "published", cur = fin ? PHASES.length : phaseIndex(k);
  const curIdx = STATUSES.findIndex(s => s[0] === (LEGACY_KEY[k] || k));
  const items = PHASES.map(([name], i) => {
    const done = i < cur, on = i === cur, last = i === PHASES.length - 1;
    const bg = done ? DARK : on ? (rej ? ALERT : RED) : "#eef2f8";
    const fg = done ? GOLD : on ? "#fff" : "#94a3b8";
    const txt = done ? "✓" : on && rej ? "✕" : i + 1;
    const dot = `<div class="pg-pop${on ? " pg-pulse" : ""}${on && rej ? " pg-bad" : ""}" style="--d:${(i * 0.16).toFixed(2)}s;width:30px;height:30px;border-radius:50%;background:${bg};color:${fg};display:grid;place-items:center;font-weight:700;font-size:13px;flex:none${on ? `;box-shadow:0 0 0 5px ${rej ? "#fde4e1" : "#fdeae8"}` : ""}">${txt}</div>`;
    const rail = last ? "" : `<div class="${done ? "pg-rail" : ""}" style="--d:${(i * 0.16 + 0.1).toFixed(2)}s;flex:1;width:3px;min-height:22px;margin:4px 0;border-radius:3px;background:${done ? DARK : "#e2e8f0"}"></div>`;
    let sub = "";
    if (on) {
      const keys = name === "Décision" ? [rej ? "rejected" : "accepted"] : (GROUPS.find(g => g[0] === name)?.[1] || []);
      sub = keys.map(key => {
        const idx = STATUSES.findIndex(s => s[0] === key), isCur = rej ? key === "rejected" : idx === curIdx, isDone = !rej && idx < curIdx;
        const mark = isDone ? "✓" : isCur ? "●" : "○";
        const col = isCur ? (rej ? ALERT : RED) : isDone ? "#334155" : "#94a3b8";
        return `<div style="display:flex;gap:8px;align-items:center;margin-top:5px;font-size:12.5px;font-weight:${isCur ? 700 : 500};color:${col}"><span style="width:14px;text-align:center">${mark}</span>${escH(LABEL[key])}</div>`;
      }).join("");
    } else if (done) sub = `<div style="font-size:12px;color:#64748b;margin-top:-4px">Terminé</div>`;
    else if (rej) sub = `<div style="font-size:12px;color:#94a3b8;margin-top:-4px">🔒 Bloqué</div>`;
    const nameCol = on ? "#0f172a" : done ? "#334155" : "#94a3b8";
    return `<div class="pg-slide" style="--d:${(i * 0.16).toFixed(2)}s;display:flex;gap:14px"><div style="display:flex;flex-direction:column;align-items:center">${dot}${rail}</div><div style="flex:1;min-width:0;padding-bottom:${last ? 0 : 16}px"><div style="line-height:30px;font-size:14px;font-weight:${on ? 700 : 600};color:${nameCol}">${name}</div>${sub}</div></div>`;
  }).join("");
  return `<div class="pg ${ANIM ? "pg-a" : ""}" style="${cardCss(rej)}">${items}<p style="margin-top:14px;font-size:13px">Étape actuelle : <b>${escH(label(k))}</b></p>${bar(k)}</div>`;
}

/** Jauge circulaire : anneau SVG de pourcentage. Refus = anneau rouge figé au point de décision. */
export function circularView(k) {
  const rej = k === "rejected", key = LEGACY_KEY[k] || k;
  const pct = rej ? progress("accepted") : progress(key);
  const R = 70, C = 2 * Math.PI * R, off = C * (1 - pct / 100), col = rej ? ALERT : GOLD;
  const ph = PHASES[phaseIndex(k)]?.[0] || "";
  const center = rej
    ? `<div style="font-size:44px;font-weight:700;color:${ALERT};line-height:1">✕</div><div style="font-size:11px;color:${ALERT};margin-top:4px;font-weight:600">Dossier clos</div>`
    : `<div style="font-family:Georgia,serif;font-size:40px;font-weight:700;color:${DARK};line-height:1">${pct}<span style="font-size:20px">%</span></div><div style="font-size:11px;color:#64748b;margin-top:4px">du parcours</div>`;
  return `<div class="pg ${ANIM ? "pg-a" : ""}" style="${cardCss(rej)};display:flex;flex-direction:column;align-items:center;text-align:center">
    <div style="position:relative;width:176px;height:176px">
      <svg viewBox="0 0 176 176" width="176" height="176" role="img" aria-label="${rej ? "Manuscrit refusé" : pct + " % du parcours"}" style="transform:rotate(-90deg)">
        <circle cx="88" cy="88" r="${R}" fill="none" stroke="${rej ? "#fde4e1" : "#eef0f4"}" stroke-width="14"/>
        <circle cx="88" cy="88" r="${R}" fill="none" stroke="${col}" stroke-width="14" stroke-linecap="round" class="pg-ring" stroke-dasharray="${C.toFixed(2)}" stroke-dashoffset="${off.toFixed(2)}" style="--c:${C.toFixed(2)};--o:${off.toFixed(2)}"/>
      </svg>
      <div class="pg-center" style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center">${center}</div>
    </div>
    <p style="margin-top:14px;font-size:15px;font-weight:700;color:${rej ? ALERT : "#0f172a"}">${escH(label(k))}</p>
    <p style="margin-top:4px;font-size:12px;color:#64748b">${rej ? "Progression bloquée" : `Phase ${phaseIndex(k) + 1} sur ${PHASES.length} · ${ph}`}</p>
    <div style="width:100%;margin-top:14px;text-align:left">${bar(k)}</div>
  </div>`;
}

const refuseBanner = note => `<div role="alert" class="pg-shake" style="display:flex;gap:10px;align-items:flex-start;background:#fee2e2;border:1px solid #f3b4ae;color:${ALERT};border-radius:14px;padding:11px 14px;margin-bottom:10px;font-size:13px;font-weight:600;text-align:left"><span>⛔</span><span>Manuscrit refusé — le parcours est interrompu.${note ? `<br><span style="font-weight:500">Motif : ${escH(note)}</span>` : ""}</span></div>`;

// ---- Animations (injectées une fois ; respectent prefers-reduced-motion) ----
const PG_CSS = `
@keyframes pg-pop{0%{transform:scale(.3);opacity:0}60%{transform:scale(1.14);opacity:1}100%{transform:scale(1);opacity:1}}
@keyframes pg-grow{from{transform:scaleX(0)}to{transform:scaleX(1)}}
@keyframes pg-growy{from{transform:scaleY(0)}to{transform:scaleY(1)}}
@keyframes pg-slide{from{opacity:0;transform:translateX(-14px)}to{opacity:1;transform:none}}
@keyframes pg-ring{from{stroke-dashoffset:var(--c)}to{stroke-dashoffset:var(--o)}}
@keyframes pg-center{0%{opacity:0;transform:scale(.7)}100%{opacity:1;transform:scale(1)}}
@keyframes pg-fill{from{transform:scaleX(0)}to{transform:scaleX(1)}}
@keyframes pg-pulse{0%{box-shadow:0 0 0 0 rgba(230,59,46,.5)}70%{box-shadow:0 0 0 10px rgba(230,59,46,0)}100%{box-shadow:0 0 0 0 rgba(230,59,46,0)}}
@keyframes pg-pulse-bad{0%{box-shadow:0 0 0 0 rgba(180,35,24,.55)}70%{box-shadow:0 0 0 10px rgba(180,35,24,0)}100%{box-shadow:0 0 0 0 rgba(180,35,24,0)}}
@keyframes pg-shake{0%,100%{transform:none}20%{transform:translateX(-6px)}40%{transform:translateX(5px)}60%{transform:translateX(-3px)}80%{transform:translateX(2px)}}
.pg-pulse{animation:pg-pulse 2.2s ease-out 1s infinite}
.pg-pulse.pg-bad{animation-name:pg-pulse-bad}
.pg-a .pg-pop{animation:pg-pop .55s cubic-bezier(.34,1.56,.64,1) both;animation-delay:var(--d,0s)}
.pg-a .pg-pop.pg-pulse{animation:pg-pop .55s cubic-bezier(.34,1.56,.64,1) var(--d,0s) both,pg-pulse 2.2s ease-out calc(var(--d,0s) + 1s) infinite}
.pg-a .pg-pop.pg-pulse.pg-bad{animation:pg-pop .55s cubic-bezier(.34,1.56,.64,1) var(--d,0s) both,pg-pulse-bad 2.2s ease-out calc(var(--d,0s) + 1s) infinite}
.pg-a .pg-line{transform-origin:left center;animation:pg-grow .5s ease-out both;animation-delay:var(--d,0s)}
.pg-a .pg-rail{transform-origin:top center;animation:pg-growy .5s ease-out both;animation-delay:var(--d,0s)}
.pg-a .pg-slide{animation:pg-slide .5s ease-out both;animation-delay:var(--d,0s)}
.pg-a .pg-ring{animation:pg-ring 1.3s cubic-bezier(.4,0,.2,1) .15s both}
.pg-a .pg-center{animation:pg-center .6s ease-out .3s both}
.pg-fill{transform-origin:left center}
.pg-a .pg-fill{animation:pg-fill 1.1s cubic-bezier(.4,0,.2,1) .2s both}
.pg-shake{animation:pg-shake .5s ease-in-out 1}
@media (prefers-reduced-motion:reduce){.pg-a *,.pg-pulse,.pg-shake{animation:none!important}}
`;
function ensureCss() {
  if (typeof document === "undefined" || document.getElementById("pg-css")) return;
  const st = document.createElement("style"); st.id = "pg-css"; st.textContent = PG_CSS; document.head.append(st);
}
// L'animation ne joue qu'à la 1re apparition ou quand niveau/style changent (pas à chaque synchro temps réel).
let ANIM = true;
const SEEN = new Map();

/** Point d'entrée unique : affiche UNIQUEMENT le style choisi par l'admin (m.displayStyle) au niveau m.currentLevelId. */
export function renderProgress(m) {
  ensureCss();
  const lv = levelOf(m), k = lv.key, st = styleOf(m);
  const id = m?.manuscriptId || m?.id || m?.trackingCode || "anon", sig = lv.id + "|" + st;
  ANIM = SEEN.get(id) !== sig; SEEN.set(id, sig);
  const body = st === "timeline" ? timelineView(k) : st === "circular" ? circularView(k) : stepper(k);
  return (lv.isRefuse ? refuseBanner(m?.statusNote) : "") + body;
}
