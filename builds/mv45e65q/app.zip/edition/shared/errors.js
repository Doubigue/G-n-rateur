// ============ Messages d'erreur lisibles (jamais de jargon technique ni de mention « Firebase ») ============
const OFFLINE = "Connexion impossible pour le moment. Vérifiez votre accès internet puis réessayez.";

/** Vrai si l'erreur vient du réseau / de l'indisponibilité du service (et non d'une erreur de saisie de l'utilisateur). */
export const isNetworkError = err => {
  const c = String(err?.code || ""), m = String(err?.message || err || "");
  return (typeof navigator !== "undefined" && navigator.onLine === false) || /network|unavailable|deadline|timeout|failed to fetch|offline|internal-error|app-check|quota/i.test(c + " " + m) || /^functions\//.test(c);
};

/** Message de connexion / d'inscription → { text, soft }  (soft = simple information discrète, pas une alerte rouge). */
export function authMessage(err) {
  const c = String(err?.code || "");
  if (["auth/invalid-credential", "auth/wrong-password", "auth/user-not-found", "auth/invalid-login-credentials"].includes(c)) return { text: "E-mail ou mot de passe incorrect.", soft: false };
  if (c === "auth/email-already-in-use") return { text: "Cet e-mail a déjà un compte.", soft: false };
  if (c === "auth/weak-password") return { text: "Mot de passe trop court (6 caractères min.).", soft: false };
  if (c === "auth/invalid-email") return { text: "Adresse e-mail invalide.", soft: false };
  if (c === "auth/user-disabled") return { text: "Ce compte est désactivé. Contactez l'éditeur.", soft: false };
  if (c === "auth/too-many-requests") return { text: "Trop de tentatives. Réessayez dans quelques minutes.", soft: true };
  if (isNetworkError(err)) return { text: OFFLINE, soft: true };
  const m = String(err?.message || "");
  if (m && !/firebase|firestore|auth\/|googleapis|gstatic|permission|\(.*\)/i.test(m)) return { text: m, soft: false };   // message de notre propre code (ex. « Choisissez au moins un rôle. »)
  return { text: "Connexion impossible pour le moment. Réessayez dans un instant.", soft: true };
}

/** Affiche le message dans un élément : rouge pour une erreur de saisie, gris discret pour un problème de réseau. */
export function showAuthError(el, err) {
  if (!el) return;
  const { text, soft } = authMessage(err);
  el.textContent = text;
  el.style.color = soft ? "#6b655c" : "#b42318";
  el.style.fontSize = ".85rem";
}
export const clearAuthError = el => { if (el) { el.textContent = ""; el.style.color = ""; } };

/** Message pour une action quelconque (enregistrer, envoyer…). */
export function friendly(err, fallback = "Une erreur est survenue. Réessayez dans un instant.") {
  if (err?.code === "permission-denied") return "Action non autorisée avec ce compte.";
  if (isNetworkError(err)) return OFFLINE;
  const m = String(err?.message || "");
  return m && !/firebase|firestore|googleapis|gstatic|\(auth\/|\(.*\/.*\)/i.test(m) ? m : fallback;
}
