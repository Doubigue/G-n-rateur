// ============ Firebase : config + opérations Firestore/Auth ============
// 1) Console Firebase > Paramètres du projet > Vos applications (Web) > copiez la config ci-dessous.
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getFirestore, collection, onSnapshot, addDoc, updateDoc, deleteDoc, doc, setDoc, writeBatch, query, orderBy, serverTimestamp, getDoc, where, getDocs, arrayUnion, increment }
  from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { initializeAuth, indexedDBLocalPersistence, browserLocalPersistence, browserSessionPersistence, signInWithEmailAndPassword, signOut, onAuthStateChanged, createUserWithEmailAndPassword }
  from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";

import { label as statusLabel, levelOf, levelOfKey, styleOf, DEFAULT_STYLE, STYLES } from "./statuses.js";
const firebaseConfig = {
  apiKey: "AIzaSyBJPG2thg1E10BeqFL163KcpgSSyjJacqA",
  authDomain: "maison-b6a19.firebaseapp.com",
  projectId: "maison-b6a19",
  storageBucket: "maison-b6a19.firebasestorage.app",
  messagingSenderId: "262883547068",
  appId: "1:262883547068:web:f7b2b5aadcdd92825afdb9"
};
export const configured = !firebaseConfig.apiKey.startsWith("VOTRE");
/** Deux sessions totalement séparées : l'administration (<html data-scope="admin">) et le site public.
 *  Firebase range chaque session sous « firebase:authUser:<clé>:<nom de l'app> » : en donnant un nom différent à l'app admin,
 *  se connecter / se déconnecter dans l'admin n'affecte JAMAIS le compte connecté sur le site public (et inversement). */
export const SCOPE = (typeof document !== "undefined" && document.documentElement.dataset.scope === "admin") ? "admin" : "public";
const app = configured ? (SCOPE === "admin" ? initializeApp(firebaseConfig, "admin") : initializeApp(firebaseConfig)) : null;
const db = app && getFirestore(app);
// Session conservée sur l'appareil (rafraîchissement, fermeture du navigateur, redémarrage) jusqu'au clic sur « Déconnexion ».
// Stockage durable choisi dès l'initialisation (IndexedDB, sinon localStorage, sinon session) : plus fiable que setPersistence() après coup.
const auth = app && initializeAuth(app, { persistence: [indexedDBLocalPersistence, browserLocalPersistence, browserSessionPersistence] });
const persistReady = Promise.resolve();
// Demande au navigateur de ne pas purger les données du site (évite une déconnexion silencieuse sur mobile).
try { navigator.storage?.persist?.(); } catch {}
/** Mémorise localement « déjà connecté » pour ne pas afficher l'écran de connexion avant la réponse de Firebase. */
export const AUTH_HINT = SCOPE === "admin" ? "ems-admin-signed-in" : "ems-signed-in";
export const setAuthHint = on => { try { on ? localStorage.setItem(AUTH_HINT, "1") : localStorage.removeItem(AUTH_HINT); } catch {} };
export const hasAuthHint = () => { try { return localStorage.getItem(AUTH_HINT) === "1"; } catch { return false; } };
/** Normalise un code de suivi saisi à la main : MS-2026-12345 (espaces, casse, tirets typographiques tolérés). */
export const normCode = s => String(s || "").trim().toUpperCase().replace(/[\u2010-\u2015\u2212\s_]+/g, "-").replace(/^MS-?/, "MS-").replace(/-+/g, "-").replace(/^MS-(\d{4})(\d{4,6})$/, "MS-$1-$2");

/** Livres en temps réel. cb reçoit un tableau [{id,...}]. Retourne la fonction d'arrêt. */
export function fetchBooks(cb, onError = console.error) {
  if (!configured) return (cb(null), () => {});
  return onSnapshot(query(collection(db, "books"), orderBy("createdAt", "desc")),
    s => cb(s.docs.map(d => ({ id: d.id, ...d.data() }))), onError);
}
export const addBook = data => addDoc(collection(db, "books"), { ...data, hidden: false, createdAt: serverTimestamp() });
export const updateBook = (id, data) => updateDoc(doc(db, "books", id), data);
export const deleteBook = id => deleteDoc(doc(db, "books", id));
export async function submitManuscript(data, user) {
  if (!user) throw new Error("Connexion requise pour soumettre un manuscrit.");
  const code = `MS-${new Date().getFullYear()}-${Math.floor(10000 + Math.random() * 90000)}`;
  const email = user.email.toLowerCase();
  const msRef = doc(collection(db, "manuscripts"));
  const trRef = doc(db, "manuscriptTracking", code);
  const thRef = doc(db, "threads", user.uid);
  const msgRef = doc(collection(db, "threads", user.uid, "messages"));
  const batch = writeBatch(db);
  batch.set(msRef, { ...data, manuscriptId: msRef.id, authorName: data.name || "", email, uid: user.uid, status: "pending", currentLevelId: "lvl-1", displayStyle: DEFAULT_STYLE, trackingCode: code, createdAt: serverTimestamp(), updatedAt: serverTimestamp() });
  batch.set(trRef, { status: "pending", currentLevelId: "lvl-1", displayStyle: DEFAULT_STYLE, updatedAt: serverTimestamp() });
  const text = `✅ Votre manuscrit « ${data.title} » a bien été reçu.\nVotre code de suivi : ${code}\nConservez-le : il permet de suivre l'avancement de votre dossier. Vous pouvez aussi écrire à l'éditeur ici.`;
  batch.set(thRef, { name: data.name || "", email, lastText: text.slice(0, 80), lastFrom: "system", updatedAt: serverTimestamp() }, { merge: true });
  batch.set(msgRef, { from: "system", text, trackingCode: code, createdAt: serverTimestamp() });
  await batch.commit();
  return code;
}
export async function trackManuscript(code) {
  if (!configured) return null;
  const snap = await getDoc(doc(db, "manuscriptTracking", normCode(code)));
  return snap.exists() ? snap.data() : null;
}
export function watchManuscripts(cb, onErr = console.error) {
  if (!configured) return () => {};
  // Pas de orderBy côté serveur : il masquait les dossiers sans createdAt. Tri côté client.
  return onSnapshot(collection(db, "manuscripts"), s => cb(s.docs.map(d => ({ id: d.id, ...d.data() })).sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0))), onErr);
}
export async function submitPartnerRequest(data, user) {
  if (!user) throw new Error("Connexion requise.");
  return addDoc(collection(db, "partnerRequests"), { ...data, email: user.email.toLowerCase(), uid: user.uid, status: "new", createdAt: serverTimestamp() });
}
export const watchPartnerRequests = (cb, onErr = console.error) => onSnapshot(collection(db, "partnerRequests"), s => cb(s.docs.map(d => ({ id: d.id, ...d.data() }))), onErr);
export const setPartnerStatus = (id, status) => updateDoc(doc(db, "partnerRequests", id), { status });
export async function setManuscriptStatus(m, status, note = "") {
  const batch = writeBatch(db);
  const lv = levelOfKey(status);
  batch.update(doc(db, "manuscripts", m.id), { status, currentLevelId: lv.id, statusNote: note || "", updatedAt: serverTimestamp() });
  if (m.trackingCode) batch.set(doc(db, "manuscriptTracking", m.trackingCode), { status, currentLevelId: lv.id, displayStyle: styleOf(m), updatedAt: serverTimestamp() }, { merge: true });
  await batch.commit();
  const msg = status === "rejected" ? `⛔ Après examen, nous ne pouvons pas retenir votre manuscrit « ${m.title} ».${note ? "\nMotif : " + note : ""}\nMerci de votre confiance et de l'intérêt porté à notre maison.`
    : status === "accepted" ? `🎉 Bonne nouvelle : votre manuscrit « ${m.title} » est accepté !`
    : `📌 Mise à jour de votre manuscrit « ${m.title} » : ${statusLabel(status)}`;
  if (m.uid) await sendMessage(m.uid, "admin", msg);
}
/** Admin : choisit le style de suivi que l'auteur verra (stepper | timeline | circular). Aucun message envoyé. */
export async function setManuscriptStyle(m, style) {
  if (!STYLES.some(x => x[0] === style)) throw new Error("Style d'affichage inconnu.");
  const batch = writeBatch(db);
  batch.update(doc(db, "manuscripts", m.id), { displayStyle: style, updatedAt: serverTimestamp() });
  if (m.trackingCode) batch.set(doc(db, "manuscriptTracking", m.trackingCode), { status: m.status || "pending", currentLevelId: levelOf(m).id, displayStyle: style, updatedAt: serverTimestamp() }, { merge: true });
  await batch.commit();
}
export const addContent = (collectionName, data) => addDoc(collection(db, collectionName), { ...data, createdAt: serverTimestamp() });
export const updateContent = (collectionName, id, data) => updateDoc(doc(db, collectionName, id), data);
export const deleteContent = (collectionName, id) => deleteDoc(doc(db, collectionName, id));
export const saveSiteSettings = data => setDoc(doc(db, "settings", "site"), { ...data, updatedAt: serverTimestamp() }, { merge: true });
export const watchSiteSettings = cb => {
  if (!configured) return (cb({}), () => {});
  return onSnapshot(doc(db, "settings", "site"), s => cb(s.exists() ? s.data() : {}), console.error);
};
export async function deleteSampleData(sample) {
  if (!configured) throw new Error("Firebase n'est pas configuré.");
  const batch = writeBatch(db); let n = 0;
  for (const [col, items] of Object.entries(sample)) {
    for (const item of items) {
      if (!item?.id) continue;
      batch.delete(doc(db, col, item.id)); n++;
    }
  }
  // Le document de configuration de démonstration porte cet identifiant.
  batch.delete(doc(db, "settings", "site")); n++;
  await batch.commit(); return n;
}
export const login = async (email, pw) => { await persistReady; return signInWithEmailAndPassword(auth, email, pw); };
export const logout = () => signOut(auth);
export const onAuth = cb => configured ? onAuthStateChanged(auth, u => { setAuthHint(!!u); cb(u); }) : cb(null);

/** Lecture temps réel d'une collection quelconque (authors, news…). */
export function fetchCollection(name, cb) {
  if (!configured) return (cb(null), () => {});
  return onSnapshot(collection(db, name), s => cb(s.docs.map(d => ({ id: d.id, ...d.data() }))), console.error);
}
/** Importe les données d'exemple (ids fixes : relancer ne crée pas de doublons). */
export async function seedSampleData(sample) {
  const batch = writeBatch(db); let n = 0;
  for (const [col, items] of Object.entries(sample)) for (const { id, ...data } of items) {
    batch.set(doc(db, col, id), { ...data, ...(col === "manuscripts" ? { status: "pending", currentLevelId: "lvl-1", displayStyle: DEFAULT_STYLE, updatedAt: serverTimestamp() } : {}), createdAt: serverTimestamp() }); n++;
  }
  await batch.commit(); return n;
}

// ============ Espace auteurs / lecteurs ============
const snapList = cb => s => cb(s.docs.map(d => ({ id: d.id, ...d.data() })));
export const signup = async (email, pw) => { await persistReady; return createUserWithEmailAndPassword(auth, email, pw); };
export const getProfile = async uid => { const s = await getDoc(doc(db, "users", uid)); return s.exists() ? s.data() : null; };
export const createProfile = (uid, data) => setDoc(doc(db, "users", uid), { role: "reader", ...data, createdAt: serverTimestamp() });
/** Commandes publiques : créées au statut pending, puis confirmées côté serveur après notification du prestataire de paiement. */
export const createOrder = data => addDoc(collection(db, "orders"), { ...data, status: "pending", createdAt: serverTimestamp() });

// ============ Achats (paiement à la remise, connexion obligatoire) ============
export const newOrderRef = () => doc(collection(db, "orders"));
/** Enregistre la commande + envoie la facture dans la messagerie du client, en une seule écriture atomique. */
export async function placeOrder(ref, order, user, invoiceUrl = "") {
  if (!user) throw new Error("Connexion requise pour acheter.");
  const batch = writeBatch(db), email = user.email.toLowerCase();
  batch.set(ref, { ...order, uid: user.uid, email, status: "pending", paymentMethod: "cash", invoiceUrl: invoiceUrl || "", invoicePaidUrl: "", history: [{ s: "pending", at: Date.now(), by: "client" }], createdAt: serverTimestamp() });
  const where = order.digitalOnly ? `Règlement en espèces à l'agence : ${order.agencyName}.\nMontant à régler : ${order.totalLabel}.\n` : `${order.mode === "delivery" ? "Livraison depuis" : "Retrait à"} l'agence : ${order.agencyName}.\nMontant à régler à la remise : ${order.totalLabel}.\n`;
  const text = `🧾 Commande ${order.invoice} enregistrée.\n${where}${order.hasEbook ? "Vos e-books seront débloqués dans « Ma bibliothèque » dès la confirmation du paiement.\n" : ""}` + (invoiceUrl ? "Votre facture PDF est disponible ci-dessous." : "Votre facture PDF vous sera transmise ici par l'éditeur.");
  batch.set(doc(db, "threads", user.uid), { name: `${order.name || ""} ${order.surname || ""}`.trim(), email, lastText: text.slice(0, 80), lastFrom: "system", updatedAt: serverTimestamp() }, { merge: true });
  batch.set(doc(collection(db, "threads", user.uid, "messages")), { from: "system", text, kind: "invoice", orderId: ref.id, invoiceNo: order.invoice, invoiceUrl: invoiceUrl || "", createdAt: serverTimestamp() });
  await batch.commit();
}
export const watchOrders = (cb, onErr = console.error) => onSnapshot(collection(db, "orders"), s => cb(s.docs.map(d => ({ id: d.id, ...d.data() }))), onErr);
/** Admin : modifie une commande et ajoute une trace datée dans son historique. */
export const updateOrder = (id, patch, entry) => updateDoc(doc(db, "orders", id), { ...patch, ...(entry ? { history: arrayUnion({ ...entry, at: Date.now(), by: "admin" }) } : {}), updatedAt: serverTimestamp() });
/** Admin : message dans la messagerie du client, avec pièce jointe facture (lien PDF). */
export async function sendInvoiceMessage(uid, text, extra = {}) {
  await setDoc(doc(db, "threads", uid), { lastText: text.slice(0, 80), lastFrom: "admin", updatedAt: serverTimestamp() }, { merge: true });
  await addDoc(collection(db, "threads", uid, "messages"), { from: "admin", text, ...extra, createdAt: serverTimestamp() });
}

/** L'utilisateur change sa propre photo (seul champ qu'il peut modifier, cf. firestore.rules). */
export const setMyPhoto = (uid, photoURL) => updateDoc(doc(db, "users", uid), { photoURL });
export const isAdmin = async uid => (await getDoc(doc(db, "admins", uid))).exists();
export const watchByField = (col, field, val, cb) => onSnapshot(query(collection(db, col), where(field, "==", val)), snapList(cb), console.error);
export const watchMessages = (uid, cb) => onSnapshot(query(collection(db, "threads", uid, "messages"), orderBy("createdAt")), snapList(cb), console.error);
export async function sendMessage(uid, from, text, meta = {}) {
  await setDoc(doc(db, "threads", uid), { ...meta, lastText: text.slice(0, 80), lastFrom: from, updatedAt: serverTimestamp(), ...(from === "admin" ? {} : { unreadAdmin: increment(1) }) }, { merge: true });
  await addDoc(collection(db, "threads", uid, "messages"), { from, text, createdAt: serverTimestamp() });
}
// --- admin ---
/** L'admin a ouvert la conversation : le compteur de messages non lus repart à zéro. */
export const markThreadRead = uid => updateDoc(doc(db, "threads", uid), { unreadAdmin: 0 }).catch(() => {});
export const watchUsers = cb => onSnapshot(collection(db, "users"), s => cb(s.docs.map(d => ({ uid: d.id, ...d.data() }))), console.error);
export const setUserData = (uid, data) => updateDoc(doc(db, "users", uid), data);
export const grantBook = (uid, bookId, bookTitle = "") => setDoc(doc(db, "purchases", uid + "_" + bookId), { uid, bookId, bookTitle, createdAt: serverTimestamp() });
export const revokeBook = (uid, bookId) => deleteDoc(doc(db, "purchases", uid + "_" + bookId));

// ============ E-books ============
// ebooks/{livre}                 : { title, toc:[titres], count, words, sourceName, updatedAt }
// ebooks/{livre}/chapters/{0000} : { n, title, text }   (un document par chapitre : pas de limite de taille du livre)
const chId = n => String(n).padStart(4, "0");
export const getEbookMeta = async id => { const s = await getDoc(doc(db, "ebooks", id)); return s.exists() ? s.data() : null; };
export const getEbookChapter = async (id, n) => { const s = await getDoc(doc(db, "ebooks", id, "chapters", chId(n))); return s.exists() ? s.data() : null; };
/** Admin : enregistre le contenu extrait automatiquement d'un fichier (EPUB, PDF, DOCX, TXT…). chapters = [{title,text}] */
export async function saveEbookContent(bookId, { title = "", chapters, sourceName = "" }, onProgress = () => {}) {
  if (!chapters?.length) throw new Error("Aucun chapitre à enregistrer.");
  const old = await getDocs(collection(db, "ebooks", bookId, "chapters")).catch(() => ({ docs: [] }));
  const ops = [];
  chapters.forEach((c, i) => ops.push(b => b.set(doc(db, "ebooks", bookId, "chapters", chId(i)), { n: i, title: c.title || `Chapitre ${i + 1}`, text: c.text })));
  old.docs.forEach(d => { if (+d.id >= chapters.length) ops.push(b => b.delete(d.ref)); });
  for (let i = 0; i < ops.length; i += 20) {   // lots de 20 : on reste sous la limite de taille d'une écriture groupée
    const b = writeBatch(db); ops.slice(i, i + 20).forEach(f => f(b)); await b.commit();
    onProgress(Math.min(100, Math.round((i + 20) / ops.length * 100)));
  }
  const words = chapters.reduce((s, c) => s + (c.text.match(/\S+/g) || []).length, 0);
  // Le document principal est écrit en dernier : un lecteur ne voit jamais un sommaire sans chapitres.
  await setDoc(doc(db, "ebooks", bookId), { title, toc: chapters.map((c, i) => c.title || `Chapitre ${i + 1}`), count: chapters.length, words, sourceName, updatedAt: serverTimestamp() });
  return { count: chapters.length, words };
}
export async function deleteEbookContent(bookId) {
  const old = await getDocs(collection(db, "ebooks", bookId, "chapters")).catch(() => ({ docs: [] }));
  for (let i = 0; i < old.docs.length; i += 200) { const b = writeBatch(db); old.docs.slice(i, i + 200).forEach(d => b.delete(d.ref)); await b.commit(); }
  await deleteDoc(doc(db, "ebooks", bookId)).catch(() => {});
}
/** Progression de lecture (chapitre + page) : retrouvée sur tous les appareils du lecteur. */
export const readingId = (uid, bookId) => uid + "_" + bookId;
export const getReadingProgress = async (uid, bookId) => { try { const s = await getDoc(doc(db, "readingProgress", readingId(uid, bookId))); return s.exists() ? s.data() : null; } catch { return null; } };
export const saveReadingProgress = (uid, bookId, data) => setDoc(doc(db, "readingProgress", readingId(uid, bookId)), { uid, bookId, ...data, updatedAt: serverTimestamp() }, { merge: true });
export const watchThreads = cb => onSnapshot(collection(db, "threads"), s => cb(s.docs.map(d => ({ uid: d.id, ...d.data() }))), console.error);

export const clearRoleRequest = uid => updateDoc(doc(db, "threads", uid), { roleRequest: null });

// --- Comptes révoqués (suppression côté site : accès bloqué + motif affiché à la connexion) ---
export const getRevocation = async uid => { const s = await getDoc(doc(db, "revokedAccounts", uid)); return s.exists() ? s.data() : null; };
export const revokeAccount = (u, reason) => setDoc(doc(db, "revokedAccounts", u.uid), { uid: u.uid, email: u.email || "", name: u.name || "", reason, createdAt: serverTimestamp() });
export const restoreAccount = uid => deleteDoc(doc(db, "revokedAccounts", uid));
export const watchRevoked = (cb, onErr = console.error) => onSnapshot(collection(db, "revokedAccounts"), s => cb(s.docs.map(d => ({ uid: d.id, ...d.data() }))), onErr);

// ============ Messagerie : annonces, sections, accusés de lecture ============
/** Document de fil de discussion de l'utilisateur (dernier message, expéditeur, date). */
export const watchThread = (uid, cb) => onSnapshot(doc(db, "threads", uid), s => cb(s.exists() ? s.data() : null), () => cb(null));
/** Lecture : { chat: ms, "<sectionId>": ms } — sert à savoir ce qui est nouveau pour ce compte, sur tous ses appareils. */
export const watchReads = (uid, cb) => onSnapshot(doc(db, "userReads", uid), s => cb(s.exists() ? s.data() : {}), () => cb({}));
export const markRead = (uid, key, ts = Date.now()) => setDoc(doc(db, "userReads", uid), { [key]: ts }, { merge: true });

/** Le client peut annuler sa propre commande tant qu'elle est en attente de paiement. */
export async function cancelOwnOrder(uid, orderId) {
  if (!uid || !orderId || !db) throw new Error("Session ou base de données indisponible.");
  const ref = doc(db, "orders", orderId);
  const snap = await getDoc(ref);
  if (!snap.exists()) throw new Error("Commande introuvable.");
  const o = snap.data();
  if (o.uid !== uid) throw new Error("Cette commande ne vous appartient pas.");
  if (o.status !== "pending") throw new Error("Seules les commandes en attente de paiement peuvent être annulées depuis votre espace.");
  await updateDoc(ref, { status: "cancelled", history: arrayUnion({ at: Date.now(), s: "cancelled", by: "client" }) });
}
