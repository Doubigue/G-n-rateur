// Rôles (plusieurs possibles par compte). Choisis à l'inscription, ensuite modifiables uniquement via l'éditeur.
export const ROLES = [
  ["Particuliers", [["reader","Lecteur"],["author","Auteur"],["author_reader","Auteur-lecteur"]]],
  ["Professionnels & partenaires", [["partner","Partenaire"],["bookseller","Libraire"],["librarian","Bibliothécaire"],["mediatheque","Médiathèque"],["school","École"],["association","Association"],["institution","Autre institution"]]]
];
export const ROLE_LABEL = Object.fromEntries(ROLES.flatMap(([, l]) => l));
export const AUTHOR = ["author", "author_reader"];   // peuvent soumettre un manuscrit
export const READER = ["reader", "author_reader"];   // ont une bibliothèque
export const PRO = ROLES[1][1].map(r => r[0]);        // peuvent envoyer une demande partenaire
export const rolesOf = p => Array.isArray(p?.roles) && p.roles.length ? p.roles : (p?.role ? [p.role] : []);
export const hasAny = (p, list) => rolesOf(p).some(r => list.includes(r));
export const rolesLabel = p => rolesOf(p).map(r => ROLE_LABEL[r] || r).join(" · ") || "Aucun rôle";
export const roleLabel = r => ROLE_LABEL[r] || "Non défini";
export const canSubmitMs = p => hasAny(p, AUTHOR);
export const canPartner = p => hasAny(p, PRO);
/** Cases à cocher (plusieurs rôles). cls = classe commune pour relire les valeurs. */
export const roleChecks = (selected = [], cls = "role-cb") => ROLES.map(([g, l]) =>
  `<fieldset class="col-span-2"><legend class="text-xs font-semibold text-stone-500 mt-2 mb-1">${g}</legend><div class="grid grid-cols-2 gap-x-3 gap-y-1">` +
  l.map(([k, n]) => `<label class="flex items-center gap-2 text-sm"><input type="checkbox" class="${cls}" value="${k}" ${selected.includes(k) ? "checked" : ""}> ${n}</label>`).join("") + `</div></fieldset>`).join("");
export const checked = (root, cls = "role-cb") => [...root.querySelectorAll("." + cls + ":checked")].map(x => x.value);
export const PSTATUS = { new: "Reçue", inprogress: "En cours de traitement", done: "Traitée" };
