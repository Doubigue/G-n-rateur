// ============ Achats : libellés et formats partagés (site, espace client, admin) ============
export const ORDER_ST = {
  pending:   ["En attente de paiement", "wip"],
  paid:      ["Payée", "ok"],
  delivered: ["Remise / livrée", "ok"],
  cancelled: ["Annulée", "ko"]
};
export const MODE_LABEL = { pickup: "Retrait en agence", delivery: "Livraison", digital: "E-book (numérique)" };
/** Libellé du mode d'une commande (une commande 100 % e-book n'a ni retrait ni livraison). */
export const modeLabel = o => o?.digitalOnly || isDigitalOnly(o) ? MODE_LABEL.digital : (MODE_LABEL[o?.mode] || "");
export const PAY_LABEL = "Paiement à la remise (espèces)";
/** Format d'un article acheté : « paper » (livre papier, par défaut pour les anciennes commandes) ou « ebook ». */
export const FORMAT_LABEL = { paper: "Livre papier", ebook: "E-book" };
export const FORMAT_ICON = { paper: "📕", ebook: "📖" };
export const fmtOf = it => (it && it.format === "ebook") ? "ebook" : "paper";
export const isDigitalOnly = o => !!o && ((o.items || []).length > 0) && (o.items || []).every(i => fmtOf(i) === "ebook");
/** « L'Éclat des Mots (E-book) » */
export const itemLabel = it => `${it.title || ""} (${FORMAT_LABEL[fmtOf(it)]})`;
/** 12 500 F CFA — espace classique (compatible PDF) */
export const fmtF = n => String(Math.round(Number(n) || 0)).replace(/\B(?=(\d{3})+(?!\d))/g, " ") + " F CFA";
export const tsMs = t => t?.toMillis ? t.toMillis() : (t?.seconds ? t.seconds * 1000 : (typeof t === "number" ? t : 0));
export const orderMs = o => o.date || tsMs(o.createdAt) || 0;
export const fdate = (ms, time = false) => {
  if (!ms) return "—";
  const d = new Date(ms), p = n => String(n).padStart(2, "0");
  return `${p(d.getDate())}/${p(d.getMonth() + 1)}/${d.getFullYear()}` + (time ? ` ${p(d.getHours())}:${p(d.getMinutes())}` : "");
};
