// ============ Logique du site public ============
import { renderProgress } from "../shared/statuses.js";
import { mountBottomNav } from "./nav.js";
import { normCode, hasAuthHint, fetchCollection, fetchBooks, submitManuscript, trackManuscript, watchSiteSettings, onAuth, login, logout, getRevocation, getProfile, submitPartnerRequest, newOrderRef, placeOrder, configured } from "../shared/firebase-config.js";
import { startInbox } from "./inbox.js";
import { AD_TYPES, renderCarousel, mountTicker, liveSite, sortAds, injectAdsCss, refreshAds } from "../shared/ads.js";
import { saveBlob } from "../shared/download.js";
import { buildInvoicePdf, uploadPdf, invoiceName, dlUrl, DEFAULT_BRAND, applyInvoiceSettings, invoiceAssets } from "../shared/invoice-pdf.js";
import { fmtF, MODE_LABEL, FORMAT_LABEL, FORMAT_ICON, modeLabel } from "../shared/orders.js";
import { showAuthError, clearAuthError, friendly } from "../shared/errors.js";
import { roleLabel, rolesLabel, rolesOf, PRO, canSubmitMs, canPartner } from "../shared/roles.js";

const WHATSAPP = "33600000000"; // ← votre numéro, format international sans +
const GENRES = ["Roman", "Essai", "Poésie", "Jeunesse"];
const REAL_COVERS = ["https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&w=700&q=88", "https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=700&q=88", "https://images.unsplash.com/photo-1495446815901-a7297e633e8d?auto=format&fit=crop&w=700&q=88", "https://images.unsplash.com/photo-1519682337058-a94d519337bc?auto=format&fit=crop&w=700&q=88"];
const DEMO = [
  { id: "d1", title: "L'Éclat des Mots", author: "Anya Sharma", genre: "Roman", price: 18, status: "Disponible", summary: "Une traductrice retrouve les carnets de sa mère et, avec eux, une langue qu'elle croyait perdue.", cover: REAL_COVERS[0] },
  { id: "d2", title: "Sous la Cendre", author: "Moussa Diallo", genre: "Essai", price: 22, status: "Disponible", summary: "Une enquête sur la mémoire des villes après l'incendie.", cover: REAL_COVERS[1] },
  { id: "d3", title: "Marées", author: "Lina Verhaeghe", genre: "Poésie", price: 14, status: "Disponible", summary: "Soixante poèmes écrits entre deux ports.", cover: REAL_COVERS[2] },
  { id: "d4", title: "À Paraître", author: "Anya Sharma", genre: "Jeunesse", price: 12, status: "À paraître", summary: "Le prochain récit d'Anya Sharma, pour les plus jeunes.", cover: REAL_COVERS[3] },
];
const AUTHORS = [
  { name: "Anya Sharma", bio: "Romancière et traductrice, elle écrit sur l'héritage des langues." },
  { name: "Moussa Diallo", bio: "Journaliste devenu essayiste, il explore la mémoire urbaine." },
  { name: "Lina Verhaeghe", bio: "Poète, elle publie depuis 2015 des recueils nés de ses voyages." },
];
let authors = AUTHORS, news = [], books = DEMO, genre = "Tous", q = "", newOnly = false;
let promoIndex = 0, promoTimer = null;
const $ = s => document.querySelector(s);
const toast = (m) => { const t = Object.assign(document.createElement("div"), { className: "toast fixed bottom-28 left-1/2 -translate-x-1/2 bg-forest text-cream px-5 py-3 rounded-full z-50", textContent: m }); document.body.append(t); setTimeout(() => t.remove(), 3500); };
const wa = b => `https://wa.me/${WHATSAPP}?text=${encodeURIComponent(`Bonjour, je souhaite ${b.status === "À paraître" ? "précommander" : "acheter"} « ${b.title} » de ${b.author} (${b.price} €).`)}`;
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));



// --- Panier, commande (connexion obligatoire, agence choisie, paiement à la remise) et facture PDF ---
const CART_KEY = "editions-baobab-cart-v1";
let BRAND = DEFAULT_BRAND, pendingCheckout = false, coAgency = null;
let cart = [];
try { cart = JSON.parse(localStorage.getItem(CART_KEY) || "[]"); } catch { cart = []; }
// Anciens paniers (sans format) → livre papier. Un e-book est toujours en un seul exemplaire.
cart = (Array.isArray(cart) ? cart : []).filter(x => x && x.id).map(x => x.fmt === "ebook" ? { id: x.id, fmt: "ebook", qty: 1 } : { id: x.id, fmt: "paper", qty: Math.max(1, x.qty | 0) });
const money = n => `${Math.round(Number(n)||0).toLocaleString("fr-FR")} F CFA`;
const bookAmount = b => Math.max(0, Math.round(Number(b.priceXof || (Number(b.price)||0) * 655.957)));
const hasEbook = b => !!(b && b.hasEbook);
/** Prix de l'e-book : prix propre s'il est renseigné dans l'admin, sinon celui du livre papier. */
const ebookAmount = b => (b.ebookPrice === null || b.ebookPrice === undefined || b.ebookPrice === "") ? bookAmount(b) : Math.max(0, Math.round((Number(b.ebookPrice) || 0) * 655.957));
const unitAmount = (b, fmt) => fmt === "ebook" ? ebookAmount(b) : bookAmount(b);
const rowKey = x => `${x.id}::${x.fmt}`;
const findRow = key => cart.find(x => rowKey(x) === key);
const cartKinds = () => { const rows = cart.filter(x => books.some(b => b.id === x.id)); return { paper: rows.some(x => x.fmt !== "ebook"), ebook: rows.some(x => x.fmt === "ebook"), digitalOnly: rows.length > 0 && rows.every(x => x.fmt === "ebook") }; };
function saveCart(){ localStorage.setItem(CART_KEY, JSON.stringify(cart)); updateCartUI(); }
function addToCart(id, fmt = "paper"){
  const b=books.find(x=>x.id===id); if(!b) return;
  if(fmt==="ebook" && !hasEbook(b)){ toast("Le format e-book n’est pas disponible pour ce livre. Choisissez le livre papier ou sélectionnez un autre titre."); return; }
  const row=cart.find(x=>x.id===id && x.fmt===fmt);
  if(row){ if(fmt==="ebook"){ toast(`L'e-book « ${b.title} » est déjà dans votre panier`); return } row.qty++; }
  else cart.push({id,fmt,qty:1});
  saveCart(); window.cartFx?.pop(); toast(`« ${b.title} » (${FORMAT_LABEL[fmt]}) ajouté au panier`);
}
function removeFromCart(key){ cart=cart.filter(x=>rowKey(x)!==key); saveCart(); }
/** Passe une ligne du papier à l'e-book (ou l'inverse), en fusionnant avec une ligne identique déjà présente. */
function swapFormat(key){
  const r=findRow(key); if(!r) return; const b=books.find(y=>y.id===r.id); const to=r.fmt==="ebook"?"paper":"ebook";
  if(!b||(to==="ebook"&&!hasEbook(b))) return;
  const other=cart.find(x=>x.id===r.id&&x.fmt===to);
  if(other){ if(to==="paper") other.qty+=r.qty; cart=cart.filter(x=>x!==r); } else { r.fmt=to; if(to==="ebook") r.qty=1; }
  saveCart();
}
function cartTotal(){ return cart.reduce((s,x)=>{const b=books.find(y=>y.id===x.id); return s+(b?unitAmount(b,x.fmt)*x.qty:0)},0); }
function updateCartUI(){
  const count=cart.reduce((s,x)=>s+x.qty,0), el=$("#cart-count"), mini=$("#cart-mini-count"), total=$("#cart-total"), items=$("#cart-items");
  if(el){el.textContent=count;el.classList.toggle("show",count>0)}
  if(mini) mini.textContent=`${count} article${count>1?"s":""}`;
  if(total) total.textContent=money(cartTotal());
  if(items) items.innerHTML=cart.length?cart.map(x=>{
    const b=books.find(y=>y.id===x.id); if(!b)return "";
    const k=rowKey(x), eb=x.fmt==="ebook";
    return `<div class="cart-item"><img src="${esc(b.cover||"")}" alt=""><div class="cart-item-main"><strong>${esc(b.title)}</strong><small>${esc(b.author||"")}</small><div style="margin:5px 0 2px;display:flex;gap:8px;align-items:center;flex-wrap:wrap"><span class="fmt-chip ${eb?"ebook":""}">${FORMAT_ICON[eb?"ebook":"paper"]} ${FORMAT_LABEL[eb?"ebook":"paper"]}</span>${hasEbook(b)?`<button type="button" class="fmt-swap" data-cart-swap="${esc(k)}">${eb?"Choisir le livre papier":"Choisir l'e-book"}</button>`:""}</div><div class="cart-line"><span>${money(unitAmount(b,x.fmt))}</span>${eb?`<small style="opacity:.7">1 exemplaire numérique</small>`:`<div class="qty"><button data-cart-dec="${esc(k)}">−</button><b>${x.qty}</b><button data-cart-inc="${esc(k)}">+</button></div>`}</div></div><button class="cart-remove" data-cart-remove="${esc(k)}" aria-label="Supprimer">×</button></div>`;
  }).join(""):`<div class="cart-empty"><div>🛒</div><h3 class="serif">Votre panier est vide</h3><p>Ajoutez une publication pour commencer.</p></div>`;
}
function openCart(){updateCartUI();$("#cart-modal").classList.add("open");$("#cart-modal").setAttribute("aria-hidden","false")}
function closeCart(){ $("#cart-modal").classList.remove("open");$("#cart-modal").setAttribute("aria-hidden","true") }
function renderCheckoutAgencies(){
  const box=$("#co-agencies"), f=$("#checkout-form"); if(!box||!f)return;
  if(coAgency&&!agencyList.some(a=>a.id===coAgency))coAgency=null;
  box.innerHTML=agencyList.map(a=>`<button type="button" class="co-ag${a.id===coAgency?" on":""}" role="radio" aria-checked="${a.id===coAgency}" data-co-agency="${esc(a.id)}">${a.image?`<img src="${esc(a.image)}" alt="" loading="lazy">`:`<span class="noimg">🏛️</span>`}<span style="min-width:0"><span class="t">${esc(a.name)}</span><span class="s">${esc([a.address,a.city].filter(Boolean).join(", "))}</span>${a.phone?`<span class="s">${esc(a.phone)}</span>`:""}</span><span class="tick">${a.id===coAgency?"✓":""}</span></button>`).join("")||`<p style="font-size:13px;color:#9b3b35">Aucune agence n'est disponible pour le moment. Réessayez plus tard.</p>`;
  f.elements.agencyId.value=coAgency||""; box.classList.remove("err");
}
function syncMode(){
  const k=cartKinds(), f=$("#checkout-form"), del=!k.digitalOnly && f.elements.mode.value==="delivery";
  $("#co-delivery").classList.toggle("hidden",!del);
  $("#co-step-mode").classList.toggle("hidden",k.digitalOnly);
  $("#co-mode-hint").textContent=k.ebook&&k.paper?"(pour vos livres papier)":"";
  $("#co-agency-legend").innerHTML=k.digitalOnly?"<b>1</b> Agence de règlement":"<b>2</b> Choisissez votre agence";
  $("#co-pay-text").textContent=k.digitalOnly?"Vous réglez en espèces dans l'agence choisie. Votre e-book est débloqué dans « Ma bibliothèque » dès que l'éditeur confirme votre paiement.":k.ebook?"Vous réglez en espèces à l'agence. Vos livres papier sont remis ou livrés ; vos e-books sont débloqués dès la confirmation du paiement.":"Vous réglez en espèces au retrait ou à la livraison. Le paiement en ligne n'est pas disponible pour le moment.";
}
function openCheckout(){
  if(!cart.length){toast("Votre panier est vide.");return}
  if(!msUser){
    if(!authReady&&hasAuthHint()){toast("Vérification de votre connexion… réessayez dans un instant.");return}
    closeCart(); pendingCheckout=true; showWelcome("🔒 Connectez-vous ou créez un compte pour finaliser votre achat. Votre panier est conservé.");return;
  }
  closeCart();
  const f=$("#checkout-form"), parts=String(msProfile?.name||"").trim().split(/\s+/).filter(Boolean);
  f.elements.email.value=msUser.email;
  if(!f.elements.surname.value&&parts.length>1)f.elements.surname.value=parts[0];
  if(!f.elements.name.value&&parts.length)f.elements.name.value=parts.length>1?parts.slice(1).join(" "):parts[0];
  syncMode(); renderCheckoutAgencies();
  {const k=cartKinds(),np=cart.filter(x=>x.fmt!=="ebook").reduce((a,x)=>a+x.qty,0),ne=cart.filter(x=>x.fmt==="ebook").length;
    $("#checkout-summary").innerHTML=`<span><strong>${cart.reduce((a,x)=>a+x.qty,0)} article(s)</strong><span class="fmt-lines">${[np?`${np} livre${np>1?"s":""} papier`:"",ne?`${ne} e-book${ne>1?"s":""}`:""].filter(Boolean).join(" · ")}</span></span><span>${money(cartTotal())}</span>`}
  $("#checkout-modal").classList.add("open"); $("#checkout-modal").setAttribute("aria-hidden","false");
}
function closeCheckout(){ $("#checkout-modal").classList.remove("open");$("#checkout-modal").setAttribute("aria-hidden","true") }
function makeInvoice(order, paid=false){
  const dig=order.digitalOnly;
  const date=new Date(order.date||Date.now()).toLocaleDateString("fr-FR",{dateStyle:"long"});
  return `<div class="invoice"><div class="invoice-brand"><div><span>FACTURE</span>${BRAND?`<h1>${esc(BRAND)}</h1>`:""}</div>${(()=>{const u=paid?invoiceAssets().img.paid:invoiceAssets().img.unpaid;return u?`<img src="${esc(u)}" alt="${paid?"Payé":"Impayé"}" style="width:150px;height:70px;object-fit:contain">`:`<div class="invoice-status ${paid?"paid":""}">${paid?"PAYÉ":"IMPAYÉ"}</div>`})()}</div>
  <div class="invoice-meta"><div><b>Facture</b><span>${esc(order.invoice)}</span><span>${date}</span></div><div><b>${dig?"Règlement à":order.mode==="delivery"?"Livraison depuis":"Retrait à"}</b><span>${esc(order.agencyName)}</span><span>${esc(order.agencyCity||"")}</span></div><div><b>Client</b><span>${esc(order.name)} ${esc(order.surname)}</span><span>${esc(order.email)}</span><span>${esc(order.phone)}</span></div></div>
  <table><thead><tr><th>Publication</th><th>Qté</th><th>Prix</th><th>Total</th></tr></thead><tbody>${order.items.map(i=>`<tr><td>${esc(i.title)} <small>(${FORMAT_LABEL[i.format==="ebook"?"ebook":"paper"]})</small></td><td>${i.qty}</td><td>${money(i.unit)}</td><td>${money(i.unit*i.qty)}</td></tr>`).join("")}</tbody></table>
  <div class="invoice-total"><span>Total TTC</span><strong>${money(order.total)}</strong></div>
  <div class="invoice-foot">${esc(modeLabel(order))} • Paiement à la remise (espèces).<br>Conservez cette facture comme justificatif de commande.</div></div>`;
}
function showInvoice(order,{url="",blob=null}={}){
  const a=$("#invoice-pdf"); a.classList.remove("hidden"); a.href="#";
  // La facture est fabriquée sur le téléphone puis enregistrée directement (sans passer par un serveur)
  a.onclick=ev=>{ev.preventDefault();saveBlob(blob||buildInvoicePdf(order,{paid:false,brand:BRAND}),order.invoice+".pdf")};
  $("#invoice-content").innerHTML=`<div class="invoice-ok"><span aria-hidden="true">✅</span><div><strong>Commande enregistrée</strong><p>${url?"Votre facture PDF est aussi disponible dans votre messagerie.":"Votre facture vous sera transmise dans votre messagerie."} Réglez ${esc(money(order.total))} ${order.digitalOnly?"":order.mode==="delivery"?"à la livraison ":"au retrait "}à l'agence ${esc(order.agencyName)}.${order.hasEbook?" Vos e-books seront disponibles dans « Mon espace › Ma bibliothèque » dès la confirmation du paiement.":""}</p></div></div>`+makeInvoice(order,false);
  $("#invoice-modal").classList.add("open");$("#invoice-modal").setAttribute("aria-hidden","false");
}
function closeInvoice(){$("#invoice-modal").classList.remove("open");$("#invoice-modal").setAttribute("aria-hidden","true")}
function buildOrder(data){
  const items=cart.map(x=>{const b=books.find(y=>y.id===x.id);return {id:x.id,format:x.fmt==="ebook"&&hasEbook(b)?"ebook":"paper",title:b?.title||"",author:b?.author||"",qty:x.fmt==="ebook"?1:x.qty,unit:b?unitAmount(b,x.fmt==="ebook"&&hasEbook(b)?"ebook":"paper"):0}}).filter(x=>x.title);
  const total=items.reduce((s,i)=>s+i.unit*i.qty,0), hasEb=items.some(i=>i.format==="ebook"), hasPap=items.some(i=>i.format!=="ebook");
  return {invoice:`FAC-${new Date().getFullYear()}-${Math.random().toString(36).slice(2,8).toUpperCase()}`,date:Date.now(),...data,items,total,totalLabel:fmtF(total),currency:"XOF",hasEbook:hasEb,hasPaper:hasPap,digitalOnly:hasEb&&!hasPap};
}
$("#cart-btn")?.addEventListener("click",openCart);
$("#cart-close")?.addEventListener("click",closeCart);
$("#checkout-btn")?.addEventListener("click",openCheckout);
$("#checkout-close")?.addEventListener("click",closeCheckout);
$("#invoice-close")?.addEventListener("click",closeInvoice);
$("#invoice-done")?.addEventListener("click",closeInvoice);
$("#cart-items")?.addEventListener("click",e=>{
  const inc=e.target.closest("[data-cart-inc]"), dec=e.target.closest("[data-cart-dec]"), rem=e.target.closest("[data-cart-remove]"), sw=e.target.closest("[data-cart-swap]");
  if(sw){swapFormat(sw.dataset.cartSwap);return}
  const key=inc?.dataset.cartInc||dec?.dataset.cartDec||rem?.dataset.cartRemove; if(!key)return;
  const r=findRow(key); if(!r)return;
  if(inc){r.qty++;window.cartFx?.pop()} if(dec){r.qty--;if(r.qty<1)cart=cart.filter(x=>x!==r)} if(rem)cart=cart.filter(x=>x!==r); saveCart();
});
$("#checkout-form")?.addEventListener("change",e=>{ if(e.target.name==="mode")syncMode(); });
$("#co-agencies")?.addEventListener("click",e=>{ const b=e.target.closest("[data-co-agency]"); if(!b)return; coAgency=b.dataset.coAgency; renderCheckoutAgencies(); });
$("#checkout-form")?.addEventListener("submit",async e=>{
  e.preventDefault(); const form=e.target, btn=$("#checkout-submit");
  if(!msUser){closeCheckout();pendingCheckout=true;showWelcome("🔒 Connectez-vous pour finaliser votre achat.");return}
  const ag=agencyList.find(a=>a.id===coAgency);
  if(!ag){const box=$("#co-agencies");box.classList.add("err");box.scrollIntoView({block:"center",behavior:"smooth"});toast("Choisissez l'agence de retrait ou de livraison.");return}
  if(!form.reportValidity())return;
  const d=Object.fromEntries(new FormData(form)), digital=cartKinds().digitalOnly, del=!digital&&d.mode==="delivery";
  if(del&&!String(d.address||"").trim()){toast("Indiquez votre adresse de livraison.");form.elements.address.focus();return}
  const order=buildOrder({name:d.name.trim(),surname:d.surname.trim(),phone:d.phone.trim(),email:msUser.email.toLowerCase(),mode:del?"delivery":"pickup",address:del?d.address.trim():"",city:del?(d.city||"").trim():"",country:del?(d.country||"").trim():"",agencyId:ag.id,agencyName:ag.name||"",agencyAddress:ag.address||"",agencyCity:ag.city||"",agencyPhone:ag.phone||""});
  if(!order.items.length){toast("Les articles de votre panier ne sont plus disponibles.");return}
  const label=btn.textContent; btn.disabled=true; btn.textContent="Création de votre facture…";
  let url="",blob=null;
  try{ blob=await buildInvoicePdf(order,{paid:false,brand:BRAND}); btn.textContent="Envoi de la facture…"; url=await uploadPdf(blob,invoiceName(order,false)); }
  catch(err){ console.warn("Facture PDF :",err); }
  btn.textContent="Enregistrement…";
  try{ await placeOrder(newOrderRef(),order,msUser,url); }
  catch(err){ toast("Commande impossible : "+friendly(err,"réessayez dans un instant.")); btn.disabled=false; btn.textContent=label; return }
  btn.disabled=false; btn.textContent=label;
  cart=[]; saveCart(); closeCheckout(); await window.cartFx?.splash(3000); showInvoice(order,{url,blob});
});
updateCartUI();
addEventListener("scroll",()=>document.querySelector(".site-hdr")?.classList.toggle("scrolled",scrollY>12),{passive:true});

// --- Bannière publications : image réelle + palette éditoriale fixe ---
const PROMO_THEMES = [
  { color:"#7d1f2b", soft:"#f3d9dd", text:"#ffffff", muted:"rgba(255,255,255,.78)" },
  { color:"#173b3a", soft:"#d7ebe8", text:"#ffffff", muted:"rgba(255,255,255,.78)" },
  { color:"#8b6a32", soft:"#f4ead0", text:"#ffffff", muted:"rgba(255,255,255,.82)" },
  { color:"#2f2a3d", soft:"#e8e1f3", text:"#ffffff", muted:"rgba(255,255,255,.80)" }
];
function visiblePublications() { return books.filter(b => !b.hidden); }
function renderPromo() {
  const list = visiblePublications();
  if (!list.length) return;
  if (promoIndex >= list.length) promoIndex = 0;
  const b = list[promoIndex];
  const slider = $("#publication-slider"), img = $("#promo-cover");
  const theme = PROMO_THEMES[promoIndex % PROMO_THEMES.length];

  $("#promo-title").innerHTML = `${esc(b.title || "Publication")}<br><em>${esc(b.genre || "")}</em>`;
  $("#promo-author").textContent = b.author ? `par ${b.author}` : "Publication des Éditions";
  $("#promo-summary").textContent = b.summary || "";
  img.src = b.cover || "";
  img.alt = `Couverture de ${b.title || "publication"}`;
  $("#promo-more").onclick = () => openBook(b.id);

  slider.style.setProperty("--slide-color", theme.color);
  slider.style.setProperty("--slide-soft", theme.soft);
  slider.style.setProperty("--slide-text", theme.text);
  slider.style.setProperty("--slide-muted", theme.muted);

  $("#promo-dots").innerHTML = list.map((x,i) =>
    `<button type="button" class="promo-dot ${i===promoIndex ? "active":""}" data-promo-index="${i}" aria-label="Afficher ${esc(x.title)}" aria-current="${i===promoIndex}"></button>`
  ).join("");
}
function changePromo(step) {
  const list = visiblePublications(); if (!list.length) return;
  promoIndex = (promoIndex + step + list.length) % list.length;
  renderPromo();
  seoBooks();
  restartPromo();
}
function restartPromo() {
  clearInterval(promoTimer);
  const list = visiblePublications();
  if (list.length > 1) promoTimer = setInterval(() => {
    promoIndex = (promoIndex + 1) % list.length;
    renderPromo();
  }, 6500);
}
$("#promo-prev").onclick = () => changePromo(-1);
$("#promo-next").onclick = () => changePromo(1);
$("#promo-dots").addEventListener("click", e => {
  const btn = e.target.closest("[data-promo-index]"); if (!btn) return;
  promoIndex = Number(btn.dataset.promoIndex); renderPromo(); restartPromo();
});
const promoSlider = $("#publication-slider");
promoSlider.addEventListener("mouseenter", () => clearInterval(promoTimer));
promoSlider.addEventListener("mouseleave", restartPromo);

// --- Rendu du catalogue ---
function render() {
  const list = books.filter(b => !b.hidden && (genre === "Tous" || b.genre === genre) && (!newOnly || b.status === "À paraître" || b.status === "Disponible") &&
    (`${b.title} ${b.author}`.toLowerCase().includes(q.toLowerCase())));
  $("#books").innerHTML = list.map(b => `
    <article class="book-card" data-id="${b.id}" tabindex="0" aria-label="Voir ${esc(b.title)} de ${esc(b.author)}">
      <div class="book-cover-frame">
        <img src="${esc(b.cover)}" alt="Couverture de ${esc(b.title)}" class="book-cover" loading="lazy" onerror="this.style.display='none';this.parentElement.classList.add('cover-missing')">
        <div class="book-cover-shade" aria-hidden="true"></div>
        <span class="book-status ${b.status === "Disponible" ? "is-available" : "is-coming"}">${esc(b.status)}</span>
        <span class="book-genre">${esc(b.genre)}</span>${b.hasEbook?`<span class="book-ebook">📖 E-book</span>`:""}
        <div class="book-caption">
          <p class="book-kicker">Dernière parution</p>
          <h3 class="book-title">${esc(b.title)}</h3>
          <p class="book-author">${esc(b.author)}</p>
          <div class="book-meta"><span>${esc(b.price)} €</span><span class="book-discover">Découvrir&nbsp;→</span></div>
        </div>
        <span class="book-overlay">Voir le livre <b>→</b></span>
      </div>
    </article>`).join("");
  $("#empty").classList.toggle("hidden", list.length > 0);
  $("#genres").innerHTML = ["Tous", ...GENRES].map(g => `<button data-g="${g}" class="px-4 py-1.5 rounded-full border border-moss/30 text-sm ${g === genre ? "bg-forest text-cream" : "bg-white"}">${g}</button>`).join("");
  const f = books.find(b => !b.hidden) || DEMO[0];
  // L'ancien hero a été remplacé par le slider de publications : on ne touche aux éléments que s'ils existent.
  if ($("#hero-title")) { $("#hero-title").textContent = f.title; $("#hero-author").textContent = f.author; $("#hero-cover").src = f.cover; $("#hero-buy").href = wa(f); }
  if ($("#hero-more")) $("#hero-more").onclick = () => openBook(f.id);
  renderPromo();
}
function openBook(id) {
  const b = books.find(x => x.id === id); if (!b) return;
  openModal(`<div class="flex gap-5 flex-col sm:flex-row"><img src="${esc(b.cover)}" alt="" class="w-40 self-center shadow-lg">
    <div><h3 class="serif text-3xl">${esc(b.title)}</h3><p class="italic">${esc(b.author)}</p>${b.isbn ? `<p class="text-xs text-forest/60">ISBN ${esc(b.isbn)}</p>` : ""}
    <p class="mt-3">${esc(b.summary)}</p>${b.extract ? `<p class="dropcap serif text-lg mt-4 leading-relaxed">${esc(b.extract)}</p>` : ""}
    <div class="fmt-fieldset mt-4"><label for="book-format-${esc(b.id)}" class="block font-semibold mb-2">Quel format préférez-vous ?</label>
      <select id="book-format-${esc(b.id)}" name="fmt" class="w-full rounded-xl border border-forest/30 bg-white text-forest px-4 py-3" aria-label="Choisir le format du livre">
        <option value="" selected>— Choisir un format —</option>
        <option value="paper">📕 Livre papier — ${money(bookAmount(b))}</option>
        <option value="ebook" ${hasEbook(b) ? "" : "disabled"}>📖 E-book — ${hasEbook(b) ? money(ebookAmount(b)) : "Indisponible"}</option>
      </select>
      <p id="format-help" class="text-sm mt-2 text-forest/70">Sélectionnez un format dans la liste pour continuer.</p>
    </div>
    <button type="button" data-add-cart="${b.id}" data-fmt="" class="inline-block mt-5 bg-forest text-cream rounded-full px-6 py-3" disabled style="opacity:.65;cursor:not-allowed">Choisissez un format</button></div></div>`);
}
const openModal = html => {
  $("#modal-body").innerHTML = html;
  $("#modal").classList.add("open");
  $("#modal").setAttribute("aria-hidden", "false");
  document.body.classList.add("modal-open");
};
const closeModal = () => {
  $("#modal").classList.remove("open");
  $("#modal").setAttribute("aria-hidden", "true");
  document.body.classList.remove("modal-open");
};

// --- Événements ---
$("#books").addEventListener("click", e => { const c = e.target.closest("[data-id]"); c && openBook(c.dataset.id); });
$("#books").addEventListener("keydown", e => { if (e.key === "Enter") e.target.click(); });
$("#books").addEventListener("mousemove", e => { const c = e.target.closest(".book-card"); if (!c) return; const r = c.getBoundingClientRect();
  c.style.setProperty("--ry", ((e.clientX - r.left) / r.width - .5) * 10 + "deg"); c.style.setProperty("--rx", (.5 - (e.clientY - r.top) / r.height) * 10 + "deg"); });
$("#books").addEventListener("mouseout", e => { const c = e.target.closest(".book-card"); c && (c.style.setProperty("--rx", "0"), c.style.setProperty("--ry", "0")); });
$("#genres").addEventListener("click", e => { if (e.target.dataset.g) { genre = e.target.dataset.g; newOnly = false; render(); } });
$("#search").addEventListener("input", e => { q = e.target.value; render(); });
$("#modal-close").onclick = closeModal; $("#modal").onclick = e => e.target.id === "modal" && closeModal();
document.addEventListener("keydown", e => e.key === "Escape" && closeModal());
$("#nl-form").onsubmit = e => { e.preventDefault(); e.target.reset(); toast("Inscription enregistrée"); };
$("[name=genre]").innerHTML = GENRES.map(g => `<option>${g}</option>`).join("");
const avatar = a => a.photo ? `<img src="${esc(a.photo)}" alt="${esc(a.name)}" class="w-24 h-24 rounded-full object-cover mx-auto" loading="lazy">` : `<div class="w-24 h-24 rounded-full bg-moss text-gold serif text-4xl flex items-center justify-center mx-auto">${esc(a.name[0])}</div>`;
function renderAuthors() {
  $("#authors").innerHTML = authors.map((a, i) => `<button data-i="${i}" class="author-card text-center"><div>${avatar(a)}</div><h3 class="serif text-2xl mt-3">${esc(a.name)}</h3><p class="text-sm mt-1 text-forest/70 line-clamp-3">${esc(a.bio)}</p><span class="text-sm underline">Page de l'auteur</span></button>`).join("");
}
$("#authors").addEventListener("click", e => { const c = e.target.closest("[data-i]"); if (!c) return; const a = authors[c.dataset.i];
  const theirs = books.filter(b => b.author === a.name && !b.hidden);
  openModal(`<div class="text-center">${avatar(a)}<h3 class="serif text-3xl mt-3">${esc(a.name)}</h3><p class="mt-3 text-left">${esc(a.bio)}</p></div>${theirs.length ? `<h4 class="serif text-xl mt-5">Ses livres</h4><div class="flex gap-3 mt-2 overflow-x-auto">${theirs.map(b => `<button data-id="${b.id}" class="w-24 shrink-0 text-xs"><img src="${esc(b.cover)}" alt="${esc(b.title)}" class="shadow">${esc(b.title)}</button>`).join("")}</div>` : ""}`); });
function updateBookFormatChoice(select) {
  if (!select || select.name !== "fmt") return;
  const modal = $("#modal-body");
  const btn = modal.querySelector("[data-add-cart]"), b = books.find(x => x.id === btn?.dataset.addCart);
  if (!btn || !b) return;
  const value = select.value;
  if (!value || (value === "ebook" && !hasEbook(b))) {
    btn.disabled = true; btn.style.opacity = ".65"; btn.style.cursor = "not-allowed";
    btn.textContent = "Choisissez un format"; btn.dataset.fmt = "";
    const help = modal.querySelector("#format-help");
    if (help) help.textContent = "Sélectionnez un format dans la liste pour continuer.";
    return;
  }
  btn.dataset.fmt = value;
  btn.disabled = false; btn.style.opacity = "1"; btn.style.cursor = "pointer";
  btn.textContent = `${b.status === "À paraître" ? "Précommander" : "Ajouter au panier"} — ${money(unitAmount(b, value))}`;
  const help = modal.querySelector("#format-help");
  if (help) help.textContent = value === "paper" ? "Livre papier : retrait en agence ou livraison." : "E-book : lecture en ligne dans votre espace.";
}
document.addEventListener("change", e => {
  if (e.target instanceof HTMLSelectElement && e.target.matches('#modal-body select[name="fmt"]')) {
    updateBookFormatChoice(e.target);
  }
});
document.addEventListener("click", e => {
  const add = e.target.closest("#modal-body [data-add-cart]");
  if (add) {
    const selected = document.querySelector('#modal-body select[name="fmt"]');
    if (!selected || !selected.value) { toast("Veuillez d’abord choisir un format dans la liste."); return; }
    const id = add.dataset.addCart;
    const b = books.find(x => x.id === id);
    if (selected.value === "ebook" && !hasEbook(b)) { toast("Ce livre n’est pas disponible en e-book."); return; }
    addToCart(id, selected.value); closeModal(); return;
  }
  const card = e.target.closest("#modal-body [data-id]");
  if (card) openBook(card.dataset.id);
});
function renderNews() {
  $("#news").innerHTML = [...news].sort((a,b)=>(b.date||"").localeCompare(a.date||"")).map(n => `
    <article class="horizontal-card bg-white rounded-2xl overflow-hidden shadow-sm">
      ${n.image ? `<img src="${esc(n.image)}" alt="" class="w-full h-48 object-cover" loading="lazy">` : ""}
      <div class="p-5"><p class="text-xs text-forest/60">${esc(n.date ? new Date(n.date).toLocaleDateString("fr-FR",{dateStyle:"long"}) : "")}</p>
      <h3 class="serif text-2xl mt-1">${esc(n.title)}</h3><p class="text-sm mt-2 text-forest/80">${esc(n.text)}</p></div>
    </article>`).join("") || `<p class="text-center text-forest/70">Aucune actualité pour le moment.</p>`;
}
function renderTestimonials(list) {
  $("#testimonials").innerHTML = (list || []).map(t => `
    <article class="testimonial-card">
      ${t.photo ? `<img src="${esc(t.photo)}" alt="${esc(t.name)}" class="testimonial-photo">` : `<div class="testimonial-photo fallback">${esc((t.name||"?")[0])}</div>`}
      <p>« ${esc(t.text)} »</p><cite>— ${esc(t.name)}${t.role ? `, ${esc(t.role)}` : ""}</cite>
    </article>`).join("") || `<p class="text-forest/70">Aucun témoignage pour le moment.</p>`;
}
function renderFaq(list) {
  $("#faqs").innerHTML = (list || []).map(f => `<details class="faq-card"><summary>${esc(f.question)}</summary><p>${esc(f.answer)}</p></details>`).join("") || `<p class="text-forest/70">Aucune question pour le moment.</p>`;
}
let agencyList = [], selectedAgency = null;
function renderAgencies(list) {
  agencyList = list || [];
  const cnt = $("#agency-count"); if (cnt) cnt.textContent = agencyList.length;
  $("#agencies").innerHTML = agencyList.map(a => `<button type="button" role="option" aria-selected="${a.id === selectedAgency}" data-agency="${esc(a.id)}" class="agency-card${a.id === selectedAgency ? " selected" : ""}">
    ${a.image ? `<img src="${esc(a.image)}" alt="" loading="lazy">` : `<div class="agency-noimg">🏛️</div>`}
    <div class="agency-body"><h3 class="serif">${esc(a.name)}</h3><p class="city">${esc(a.city)}</p><p class="addr">${esc(a.address)}</p>${a.phone ? `<p class="tel">${esc(a.phone)}</p>` : ""}</div>
    <span class="agency-go" aria-hidden="true">📍</span>
  </button>`).join("") || `<p class="text-forest/60 p-4">Aucune agence pour le moment.</p>`;
  if (selectedAgency && !agencyList.some(a => a.id === selectedAgency)) selectedAgency = null;
  renderCheckoutAgencies();
}
function selectAgency(id) {
  const a = agencyList.find(x => x.id === id); if (!a) return;
  selectedAgency = id;
  document.querySelectorAll(".agency-card").forEach(c => { const on = c.dataset.agency === id; c.classList.toggle("selected", on); c.setAttribute("aria-selected", on); });
  const q = [a.address, a.city].filter(Boolean).join(", ") || a.name;
  const map = $("#agency-map");
  map.src = "https://www.google.com/maps?q=" + encodeURIComponent(q) + "&z=15&output=embed";
  map.classList.remove("hidden"); $("#agency-map-empty").classList.add("hidden");
  $("#map-name").textContent = a.name; $("#map-addr").textContent = q;
  $("#map-route").href = "https://www.google.com/maps/dir/?api=1&destination=" + encodeURIComponent(q);
  $("#agency-map-bar").classList.remove("hidden");
}
document.addEventListener("click", e => { const c = e.target.closest("[data-agency]"); if (c) selectAgency(c.dataset.agency); });
function applySiteSettings(s) {
  BRAND = s.footerName || DEFAULT_BRAND; applyInvoiceSettings(s);
  const brand = $("#site-brand");
  if (brand) {
    if (s.logoUrl) {
      brand.innerHTML = `<img src="${esc(s.logoUrl)}" alt="${esc(s.footerName || "Maison d'édition")}" class="site-logo logo-${esc(s.logoStyle||"horizontal")}">`;
      brand.classList.remove("serif");
    } else {
      brand.innerHTML = esc(s.footerName || "");
      brand.classList.add("serif");
    }
  }
  const fav = $("#dynamic-favicon"); if (fav && s.faviconUrl) fav.href = s.faviconUrl;
  $("#footer-brand").textContent = s.footerName || "";
  const wt = $("#wl-title"); if (wt) wt.textContent = s.footerName || "";
  $("#footer-tagline").textContent = s.footerTagline || "";
  $("#footer-links-title").textContent = s.footerLinksTitle || "Liens rapides";
  $("#footer-info-title").textContent = s.footerInfoTitle || "Informations";
  $("#footer-copyright").textContent = s.footerCopyright || "";
  const footer = document.querySelector(".site-footer"); if (footer) footer.dataset.style = s.footerStyle || "classic";
}

let msUser = null, msProfile = null;
const AV_OFF = `<span class="acc-ava"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg></span>`;
let accPop = null;
function closeAcc() { accPop?.classList.remove("open"); $("#account-btn")?.setAttribute("aria-expanded", "false"); }
function paintAccount(u, p) {
  const b = $("#account-btn"); if (!b) return;
  closeAcc();
  if (!u) { b.className = "account-btn off"; b.title = "Non connecté — cliquez pour vous connecter"; b.innerHTML = AV_OFF; return; }
  const n = p?.name || u.email, ph = p?.photoURL || u.photoURL;
  b.className = "account-btn on"; b.title = "Connecté — cliquez pour voir votre compte";
  b.innerHTML = ph ? `<img class="acc-ava" src="${esc(ph)}" alt="">` : `<span class="acc-ava">${esc(n[0].toUpperCase())}</span>`;
}
function openAcc() {
  if (!msUser) return showWelcome();
  const u = msUser, p = msProfile, n = p?.name || u.email, ph = p?.photoURL || u.photoURL;
  if (!accPop) { accPop = document.createElement("div"); accPop.className = "acc-pop"; accPop.setAttribute("role", "dialog"); accPop.setAttribute("aria-label", "Mon compte"); document.body.appendChild(accPop); }
  accPop.innerHTML = `<div class="acc-pop-head"><button type="button" class="acc-pop-x" aria-label="Fermer">×</button>
    <div class="acc-pop-ph">${ph ? `<img src="${esc(ph)}" alt="">` : esc(n[0].toUpperCase())}</div>
    <div class="acc-pop-name">${esc(n)}</div><div class="acc-pop-mail">${esc(u.email || "")}</div><span class="acc-pop-st">Connecté</span></div>
    <div class="acc-pop-body"><div class="acc-pop-row"><b>Rôle</b><span>${esc(rolesLabel(p))}</span></div>${p?.organization ? `<div class="acc-pop-row"><b>Structure</b><span>${esc(p.organization)}</span></div>` : ""}</div>
    <div class="acc-pop-act"><a href="espace.html">Mon espace</a><button type="button" data-acc-out>Se déconnecter</button></div>`;
  requestAnimationFrame(() => accPop.classList.add("open")); $("#account-btn").setAttribute("aria-expanded", "true");
}
document.addEventListener("click", e => {
  if (e.target.closest(".acc-pop-x")) return closeAcc();
  if (e.target.closest("[data-acc-out]")) { closeAcc(); logout().catch(() => {}); return; }
  if (accPop?.classList.contains("open") && !e.target.closest(".acc-pop") && !e.target.closest("#account-btn")) closeAcc();
});
document.addEventListener("keydown", e => { if (e.key === "Escape") closeAcc(); });
function gate(boxSel, form, u, p, allowed, anchor, textOut, textWrong) {
  const box = $(boxSel), ok = !!u && allowed(p);
  box.classList.toggle("hidden", ok); form.toggleAttribute("inert", !ok);
  if (ok) return;
  box.innerHTML = !u
    ? `<div><div class="ms-lock" aria-hidden="true"><svg class="ms-key" viewBox="0 0 64 64" role="presentation"><circle cx="20" cy="32" r="11"></circle><path d="M28 32h28M45 32v8M51 32v5"></path></svg></div><h3 class="serif">Connexion requise</h3><p>${textOut}</p><button type="button" data-login class="gold-button">Se connecter / Créer un compte</button></div>`
    : `<div><div class="ms-lock">🔒</div><h3 class="serif">Rôle non autorisé</h3><p>Votre compte est enregistré comme « ${esc(rolesLabel(p))} ». ${textWrong} Pour obtenir ce rôle, envoyez une demande à l'éditeur depuis votre espace.</p><a href="espace.html#role" class="gold-button">Demander ce rôle à l'éditeur</a></div>`;
}
// --- Accueil : se connecter ou continuer en visiteur ---
const W = $("#welcome"); let pendingMsg = "";
const getG = () => { try { return sessionStorage.getItem("guest-ok"); } catch { return null; } };
const setG = () => { try { sessionStorage.setItem("guest-ok", "1"); } catch {} };
let authReady = false; // vrai dès que Firebase a répondu (connecté ou non)
function showWelcome(msg) {
  // Tant que Firebase n'a pas confirmé l'état de connexion d'un utilisateur déjà connecté, on n'affiche rien.
  if (!authReady && hasAuthHint() && !msg && !pendingMsg) return;
  const m = msg ?? pendingMsg; pendingMsg = ""; if (m) $("#wl-err").textContent = m;
  W.classList.remove("hidden"); document.body.classList.add("locked");
}
function hideWelcome() { W.classList.add("hidden"); document.documentElement.classList.remove("pre-welcome"); document.body.classList.remove("locked"); }
$("#wl-guest").onclick = () => { setG(); hideWelcome(); };
document.addEventListener("click", e => { if (e.target.closest("[data-login]")) { e.preventDefault(); showWelcome(); } });
$("#account-btn").addEventListener("click", e => { e.preventDefault(); accPop?.classList.contains("open") ? closeAcc() : openAcc(); });
$("#wl-form").onsubmit = async e => {
  e.preventDefault(); const f = Object.fromEntries(new FormData(e.target)), err = $("#wl-err"), btn = $("#wl-submit");
  clearAuthError(err); btn.disabled = true; btn.textContent = "Connexion…";
  try { await login(f.email, f.pw); e.target.reset(); }
  catch (ex) { showAuthError(err, ex); }
  btn.disabled = false; btn.textContent = "Se connecter";
};
if (!getG() && !hasAuthHint()) showWelcome();

// --- Menu du bas : Accueil · Catalogue · Auteurs · Messagerie · Plus ---
const nav = mountBottomNav({
  home: "", track: true,
  onLogin: () => showWelcome(),
  onLogout: () => logout().catch(() => {}),
  onMessages: () => { if (!authReady && hasAuthHint()) { location.href = "espace.html#chat"; return; } if (msUser) location.href = "espace.html#chat"; else showWelcome("Connectez-vous pour accéder à votre messagerie."); }
});

let stopInbox = null;
function watchInbox(u, p) {
  stopInbox && stopInbox(); stopInbox = null;
  if (!u) { nav.setBadge(0, "", true); return; }
  stopInbox = startInbox(u, p, st => {
    const label = st.counts.chat && st.total === st.counts.chat ? "Nouveau message de l'éditeur" : "Nouvelle annonce dans votre messagerie";
    nav.setBadge(st.total, label, st.initial);
  });
}
onAuth(async u => {
  authReady = true;
  let rv = null;
  if (u) { try { rv = await getRevocation(u.uid); } catch {} }
  if (rv) { pendingMsg = "⛔ Votre compte a été révoqué. Motif : " + (rv.reason || "non précisé."); nav.setUser(null); watchInbox(null); showWelcome(); await logout().catch(() => {}); return; }
  msUser = u; msProfile = null;
  if (u) for (let i = 0; i < 4 && !(msProfile = await getProfile(u.uid).catch(() => null)); i++) await new Promise(r => setTimeout(r, 400));
  if (u) hideWelcome(); else if (!getG()) showWelcome();
  paintAccount(u, msProfile); nav.setUser(u, msProfile); watchInbox(u, msProfile);
  const f = $("#ms-form"), pf = $("#partner-form"), tf = $("#tracking-form");
  gate("#ms-gate", f, u, msProfile, canSubmitMs, "manuscrit", "Pour soumettre un manuscrit, connectez-vous avec un compte <b>auteur</b> ou <b>auteur-lecteur</b>. Votre code de suivi sera placé dans votre messagerie.", "Seuls les comptes auteur ou auteur-lecteur peuvent soumettre un manuscrit.");
  gate("#tracking-gate", tf, u, msProfile, canSubmitMs, "suivi", "Le suivi de manuscrits est réservé aux comptes <b>auteur</b> ou <b>auteur-lecteur</b>. Connectez-vous pour consulter vos dossiers.", "Seuls les comptes auteur ou auteur-lecteur peuvent consulter le suivi de leurs manuscrits.");
  gate("#pt-gate", pf, u, msProfile, canPartner, "partenaires", "Cet espace est réservé aux comptes professionnels : partenaire, libraire, bibliothécaire, médiathèque, école, association…", "Cet espace est réservé aux comptes professionnels (partenaire, libraire, médiathèque, école, association…).");
  if (u && pendingCheckout && cart.length) { pendingCheckout = false; setTimeout(openCheckout, 300); }
  if (!u) return;
  f.email.value = u.email; f.email.readOnly = true;
  pf.email.value = u.email; pf.email.readOnly = true;
  if (msProfile?.name && !f.name.value) f.name.value = msProfile.name;
  if (msProfile?.organization && !pf.organization.value) pf.organization.value = msProfile.organization;
});

// --- Téléversement du manuscrit (Cloudinary) ---
const MS_UPLOAD_URL = "https://api.cloudinary.com/v1_1/iayfluiq/auto/upload", MS_PRESET = "blognews_unsigned", MS_MAX_MB = 10;
$("#ms-upload").onclick = () => {
  const st = $("#ms-upload-status"), form = $("#ms-form");
  const p = document.createElement("input"); p.type = "file"; p.accept = ".pdf,.doc,.docx,.odt,.rtf,.txt,.epub";
  p.onchange = async () => {
    const file = p.files?.[0]; if (!file) return;
    if (file.size > MS_MAX_MB * 1048576) { st.textContent = `❌ Fichier trop lourd (max ${MS_MAX_MB} Mo).`; return; }
    const btn = $("#ms-upload"); btn.disabled = true; st.textContent = "⏳ Téléversement de « " + file.name + " »…";
    try {
      const fd = new FormData(); fd.append("file", file); fd.append("upload_preset", MS_PRESET); fd.append("folder", "manuscrits");
      const res = await fetch(MS_UPLOAD_URL, { method: "POST", body: fd }), d = await res.json();
      if (!res.ok || !d.secure_url) throw new Error(d?.error?.message || "échec du téléversement");
      form.link.value = d.secure_url; form.fileName.value = file.name; st.textContent = "✅ « " + file.name + " » téléversé.";
    } catch (err) { st.textContent = "❌ " + friendly(err, "échec du téléversement"); }
    btn.disabled = false;
  };
  p.click();
};
$("#ms-form").onsubmit = async e => {
  e.preventDefault(); const form = e.target, data = Object.fromEntries(new FormData(form));
  try {
    if (!configured) throw new Error("Firebase n'est pas configuré.");
    if (!msUser) throw new Error("Veuillez vous connecter.");
    if (!canSubmitMs(msProfile)) throw new Error("votre rôle ne permet pas de soumettre un manuscrit.");
    if (!data.link) throw new Error("Ajoutez un lien vers votre manuscrit ou téléversez le fichier.");
    const code = await submitManuscript(data, msUser);
    form.reset(); form.email.value = msUser.email; $("#ms-upload-status").textContent = "";
    toast(`Manuscrit envoyé. Code de suivi : ${code}`);
    const result = $("#ms-result");
    result.classList.remove("hidden");
    result.innerHTML = `Dossier enregistré sous <strong>${esc(code)}</strong>. Ce code a été envoyé dans votre messagerie. <a href="espace.html#chat" style="text-decoration:underline;font-weight:700">Ouvrir ma messagerie →</a>`;
  } catch (err) { toast("Envoi impossible : " + friendly(err)); }
};
// --- Suivi de manuscrit public ---
$("#tracking-form")?.addEventListener("submit", async e => {
  e.preventDefault();
  const code = normCode(new FormData(e.target).get("code"));
  const box = $("#tracking-result");
  if (!code) return;
  box.classList.remove("hidden");
  box.textContent = "Recherche du dossier…";
  try {
    const item = await trackManuscript(code);
    box.innerHTML = item
      ? `<div style="margin-bottom:10px"><strong>${esc(code)}</strong></div>${renderProgress(item)}${item.updatedAt?.toDate ? `<span class="block text-sm mt-2 opacity-70">Dernière mise à jour : ${item.updatedAt.toDate().toLocaleString("fr-FR")}</span>` : ""}`
    : `Aucun dossier public ne correspond à <strong>${esc(code)}</strong>. Vérifiez le code transmis par notre équipe.`;
  } catch (err) {
    box.textContent = "Le suivi est momentanément indisponible. Réessayez dans quelques instants.";
  }
});

// --- Espace libraires & partenaires (comptes professionnels) ---
$("#partner-form")?.addEventListener("submit", async e => {
  e.preventDefault(); const form = e.target;
  try {
    if (!msUser) throw new Error("veuillez vous connecter.");
    if (!canPartner(msProfile)) throw new Error("réservé aux comptes professionnels.");
    await submitPartnerRequest({ ...Object.fromEntries(new FormData(form)), role: rolesOf(msProfile).find(r => PRO.includes(r)), roleLabel: rolesOf(msProfile).filter(r => PRO.includes(r)).map(roleLabel).join(" · ") }, msUser);
    form.reset(); form.email.value = msUser.email;
    toast("Votre demande a bien été enregistrée. Notre équipe vous répondra rapidement.");
  } catch (err) { toast("Envoi impossible : " + friendly(err)); }
});

// --- Données en temps réel ---
fetchCollection("authors", l => { if (l && l.length) authors = l; renderAuthors(); });
fetchCollection("news", l => { if (l) news = l; renderNews(); });
fetchCollection("testimonials", l => { if (l) renderTestimonials(l); });
fetchCollection("faqs", l => { if (l) renderFaq(l); });
fetchCollection("agencies", l => { if (l) renderAgencies(l); });
watchSiteSettings(s => { if (s) applySiteSettings(s); });
renderAuthors(); renderNews();
renderTestimonials([]);
// --- SEO : données structurées JSON-LD générées depuis les données (livres, événements) ---
function setJsonLd(id, data) {
  let el = document.getElementById(id);
  if (!data) { el?.remove(); return; }
  if (!el) { el = document.createElement("script"); el.type = "application/ld+json"; el.id = id; document.head.append(el); }
  el.textContent = JSON.stringify(data);
}
const pageUrl = h => new URL(h, location.href).href;
function seoBooks() {
  const l = books === DEMO ? [] : books.filter(b => !b.hidden && b.title).slice(0, 30); // jamais de données structurées pour les livres de démonstration
  setJsonLd("ld-books", l.length ? { "@context": "https://schema.org", "@type": "ItemList", itemListElement: l.map((b, i) => ({ "@type": "ListItem", position: i + 1, item: { "@type": "Book", name: b.title, author: { "@type": "Person", name: b.author || "" }, genre: b.genre || undefined, image: /^https?:/.test(b.cover || "") ? b.cover : undefined, description: b.summary || undefined, url: pageUrl("index.html#catalogue"), offers: b.price ? { "@type": "Offer", price: String(b.price), priceCurrency: "EUR", availability: b.status === "Disponible" ? "https://schema.org/InStock" : "https://schema.org/PreOrder" } : undefined } })) } : null);
}
function seoEvents(cards) {
  const ev = cards.filter(a => a.type === "event" && !String(a.id).startsWith("ad-ex-") && !isNaN(new Date(a.targetDate)));
  setJsonLd("ld-events", ev.length ? ev.map(a => ({ "@context": "https://schema.org", "@type": "Event", name: a.title, description: a.description || undefined, startDate: new Date(a.targetDate).toISOString(), eventAttendanceMode: "https://schema.org/OfflineEventAttendanceMode", eventStatus: "https://schema.org/EventScheduled", location: a.location ? { "@type": "Place", name: a.location, address: a.location } : undefined, organizer: { "@type": "Organization", name: document.title.split(" — ")[0] }, url: pageUrl("annonces.html") })) : null);
}

// --- Annonces dynamiques (collection « siteAnnouncements ») : bandeau flash + onglets par style ---
injectAdsCss();
let allAds = [], adTab = "all";
function renderAds() {
  mountTicker($("#ad-ticker"), allAds);
  const cards = sortAds(allAds.filter(a => liveSite(a) && a.type !== "ticker" && AD_TYPES[a.type]));
  if ($("#annonces")) $("#annonces").classList.toggle("hidden", !cards.length);
  seoEvents(cards);
  if (!cards.length) return;
  const types = Object.keys(AD_TYPES).filter(t => cards.some(a => a.type === t));
  if (adTab !== "all" && !types.includes(adTab)) adTab = "all";
  $("#ad-tabs").innerHTML = [["all", "Toutes", cards.length], ...types.map(t => [t, AD_TYPES[t][0] + " " + AD_TYPES[t][1], cards.filter(a => a.type === t).length])]
    .map(([k, n, c]) => `<button type="button" role="tab" aria-selected="${k === adTab}" data-ad="${k}" class="ad-tab${k === adTab ? " on" : ""}">${esc(n)}<i>${c}</i></button>`).join("");
  $("#ad-list").innerHTML = renderCarousel(cards.filter(a => adTab === "all" || a.type === adTab));
  refreshAds();
}
if ($("#ad-tabs")) $("#ad-tabs").addEventListener("click", e => { const b = e.target.closest("[data-ad]"); if (b) { adTab = b.dataset.ad; renderAds(); } });
fetchCollection("siteAnnouncements", l => { allAds = l || []; renderAds(); });

renderFaq([]);
renderAgencies([]);
fetchBooks(list => { if (list && list.length) books = list; render(); });
render();
