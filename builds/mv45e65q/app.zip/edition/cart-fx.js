(function(){
var ctx;
function ac(){ctx=ctx||new(window.AudioContext||window.webkitAudioContext)();if(ctx.state==="suspended")ctx.resume();return ctx}
function tone(c,type,f0,f1,at,dur,vol){var o=c.createOscillator(),g=c.createGain(),t=c.currentTime+at;o.type=type;o.frequency.setValueAtTime(f0,t);if(f1!==f0)o.frequency.exponentialRampToValueAtTime(f1,t+dur*.6);g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(vol,t+.012);g.gain.exponentialRampToValueAtTime(.0001,t+dur);o.connect(g);g.connect(c.destination);o.start(t);o.stop(t+dur+.03)}
function pop(){try{var c=ac();tone(c,"sine",380,820,0,.1,.22);tone(c,"sine",1318,1318,.09,.42,.16);tone(c,"sine",1976,1976,.09,.3,.07)}catch(e){}}
var css='#ds{position:fixed;inset:0;z-index:100000;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:18px;background:radial-gradient(circle at 50% 40%,#1b3d2d 0%,#10281e 70%);color:#faf8f5;font-family:inherit;animation:dsFade .3s ease-out}'+
'#ds.out{opacity:0;transition:opacity .3s}@keyframes dsFade{from{opacity:0}}'+
'#ds svg{width:min(520px,92vw);height:auto;overflow:visible}'+
'#ds .k{font-size:.8rem;letter-spacing:.18em;text-transform:uppercase;color:#d4af37}'+
'#ds h2{font-size:clamp(1.3rem,5vw,1.9rem);font-weight:700;text-align:center;padding:0 16px}'+
'#ds h2 i{font-style:normal;display:inline-block;animation:dsDot 1s infinite}#ds h2 i:nth-of-type(2){animation-delay:.2s}#ds h2 i:nth-of-type(3){animation-delay:.4s}'+
'@keyframes dsDot{0%,60%,100%{opacity:.2;transform:none}30%{opacity:1;transform:translateY(-4px)}}'+
'#ds .bar{width:min(300px,70vw);height:6px;border-radius:9px;background:rgba(255,255,255,.12);overflow:hidden}'+
'#ds .bar i{display:block;height:100%;width:0;background:linear-gradient(90deg,#d4af37,#f3dc86);border-radius:9px;animation:dsBar 3s linear forwards}@keyframes dsBar{to{width:100%}}'+
'#ds .tr{animation:dsIn .9s cubic-bezier(.2,.8,.2,1) both}@keyframes dsIn{from{transform:translateX(-330px)}}'+
'#ds .bn{animation:dsB .32s ease-in-out infinite alternate}@keyframes dsB{to{transform:translateY(-2.5px)}}'+
'#ds .wh{animation:dsW .45s linear infinite}@keyframes dsW{to{transform:rotate(360deg)}}'+
'#ds .rd{animation:dsR .5s linear infinite}@keyframes dsR{to{transform:translateX(-48px)}}'+
'#ds .ct{animation:dsC 4s linear infinite}@keyframes dsC{to{transform:translateX(-400px)}}'+
'#ds .sp{animation:dsS .6s linear infinite}@keyframes dsS{from{transform:translateX(30px);opacity:0}30%{opacity:.8}to{transform:translateX(-60px);opacity:0}}'+
'@media(prefers-reduced-motion:reduce){#ds .bn,#ds .wh,#ds .rd,#ds .ct,#ds .sp{animation:none}}';
var scene='<svg viewBox="0 0 400 220" aria-hidden="true"><circle cx="300" cy="60" r="34" fill="#d4af37" opacity=".16"/>'+
'<defs><g id="dsb"><rect x="10" y="95" width="34" height="75" fill="#0d2118"/><rect x="52" y="70" width="40" height="100" fill="#0b1c14"/><rect x="100" y="105" width="30" height="65" fill="#0d2118"/><rect x="140" y="80" width="46" height="90" fill="#0b1c14"/><rect x="196" y="110" width="34" height="60" fill="#0d2118"/><rect x="240" y="60" width="38" height="110" fill="#0b1c14"/><rect x="288" y="98" width="42" height="72" fill="#0d2118"/><rect x="340" y="84" width="40" height="86" fill="#0b1c14"/>'+
'<g fill="#d4af37" opacity=".5"><rect x="60" y="82" width="6" height="6"/><rect x="74" y="100" width="6" height="6"/><rect x="150" y="94" width="6" height="6"/><rect x="164" y="114" width="6" height="6"/><rect x="250" y="76" width="6" height="6"/><rect x="262" y="98" width="6" height="6"/><rect x="350" y="98" width="6" height="6"/></g></g></defs>'+
'<g class="ct"><use href="#dsb"/><use href="#dsb" x="400"/><use href="#dsb" x="800"/></g>'+
'<rect x="0" y="170" width="400" height="50" fill="#07140d"/><g class="rd"><line x1="0" y1="198" x2="560" y2="198" stroke="#d4af37" stroke-width="3" stroke-dasharray="26 22"/></g>'+
'<g class="sp" stroke="#faf8f5" stroke-width="2" stroke-linecap="round"><line x1="60" y1="120" x2="90" y2="120"/></g><g class="sp" style="animation-delay:.2s" stroke="#faf8f5" stroke-width="2" stroke-linecap="round"><line x1="50" y1="140" x2="84" y2="140"/></g><g class="sp" style="animation-delay:.4s" stroke="#faf8f5" stroke-width="2" stroke-linecap="round"><line x1="66" y1="156" x2="96" y2="156"/></g>'+
'<g class="tr"><g class="bn"><rect x="88" y="96" width="150" height="70" rx="7" fill="#faf8f5"/><rect x="88" y="142" width="150" height="7" fill="#d4af37"/>'+
'<g transform="translate(139 106)"><rect width="46" height="30" rx="3" fill="#10281e"/><rect x="5" y="5" width="16" height="20" rx="1.5" fill="#d4af37"/><rect x="25" y="5" width="16" height="20" rx="1.5" fill="#f3dc86"/></g>'+
'<path d="M238 114h40l24 30v22h-64z" fill="#d4af37"/><path d="M250 122h22l14 20h-36z" fill="#10281e" opacity=".85"/><rect x="296" y="150" width="6" height="8" rx="2" fill="#fff6c8"/></g>'+
'<g class="wh" style="transform-origin:128px 170px"><circle cx="128" cy="170" r="17" fill="#1b1b1b" stroke="#d4af37" stroke-width="3"/><line x1="128" y1="158" x2="128" y2="182" stroke="#d4af37" stroke-width="2.5"/><line x1="116" y1="170" x2="140" y2="170" stroke="#d4af37" stroke-width="2.5"/></g>'+
'<g class="wh" style="transform-origin:262px 170px"><circle cx="262" cy="170" r="17" fill="#1b1b1b" stroke="#d4af37" stroke-width="3"/><line x1="262" y1="158" x2="262" y2="182" stroke="#d4af37" stroke-width="2.5"/><line x1="250" y1="170" x2="274" y2="170" stroke="#d4af37" stroke-width="2.5"/></g></g></svg>';
function splash(ms){return new Promise(function(res){
ms=ms||3000;var st=document.createElement("style");st.textContent=css;
var el=document.createElement("div");el.id="ds";el.setAttribute("role","status");el.setAttribute("aria-live","polite");
el.innerHTML=scene+'<div class="k">Commande validée ✓</div><h2>Votre livraison est en route<i>.</i><i>.</i><i>.</i></h2><div class="bar"><i></i></div>';
el.appendChild(st);document.body.appendChild(el);
setTimeout(function(){el.classList.add("out")},ms-300);
setTimeout(function(){el.remove();res()},ms)})}

var css2='#ds .sk{position:absolute;top:calc(14px + env(safe-area-inset-top,0px));right:16px;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.22);color:#faf8f5;border-radius:999px;padding:7px 14px;font-size:.8rem;cursor:pointer}'+
'#ds .ln{stroke:#10281e;stroke-width:1.8;stroke-linecap:round;stroke-dasharray:100;stroke-dashoffset:100;animation:dsLn .8s linear forwards}@keyframes dsLn{to{stroke-dashoffset:0}}'+
'#ds .wr{transform-origin:170px 132px;animation:dsWr .45s ease-in-out infinite alternate}@keyframes dsWr{from{transform:rotate(-7deg)}to{transform:rotate(7deg)}}'+
'#ds .br{animation:dsBr 1.6s ease-in-out infinite alternate}@keyframes dsBr{to{transform:translateY(-2px)}}'+
'#ds .sm path{animation:dsSm 1.6s ease-in-out infinite}@keyframes dsSm{0%{opacity:0;transform:translateY(6px)}50%{opacity:.7}100%{opacity:0;transform:translateY(-6px)}}'+
'@media(prefers-reduced-motion:reduce){#ds .wr,#ds .br,#ds .sm path{animation:none}}';
var writer='<svg viewBox="0 0 400 220" aria-hidden="true"><circle cx="320" cy="55" r="30" fill="#d4af37" opacity=".16"/><rect x="0" y="170" width="400" height="50" fill="#07140d"/><rect x="0" y="168" width="400" height="3" fill="#d4af37" opacity=".5"/>'+
'<rect x="26" y="140" width="52" height="10" fill="#1b3d2d" stroke="#d4af37"/><rect x="30" y="150" width="56" height="10" fill="#d4af37"/><rect x="36" y="160" width="50" height="10" fill="#faf8f5"/>'+
'<polygon points="200,172 214,146 338,146 332,172" fill="#faf8f5"/>'+
'<line class="ln" pathLength="100" x1="222" y1="153" x2="324" y2="153" style="animation-delay:.2s"/><line class="ln" pathLength="100" x1="218" y1="159" x2="322" y2="159" style="animation-delay:.95s"/><line class="ln" pathLength="100" x1="214" y1="165" x2="290" y2="165" style="animation-delay:1.7s"/>'+
'<g class="br"><rect x="112" y="112" width="68" height="62" rx="24" fill="#d4af37"/><circle cx="148" cy="92" r="21" fill="#f2c9a0"/><path d="M127 92a21 21 0 0 1 42 0c-8-10-30-12-42 0z" fill="#3a2a1d"/><circle cx="160" cy="95" r="2" fill="#10281e"/></g>'+
'<g class="wr"><line x1="170" y1="132" x2="228" y2="156" stroke="#d4af37" stroke-width="13" stroke-linecap="round"/><circle cx="232" cy="158" r="7" fill="#f2c9a0"/><line x1="232" y1="158" x2="248" y2="140" stroke="#faf8f5" stroke-width="3" stroke-linecap="round"/><circle cx="249" cy="139" r="2.2" fill="#d4af37"/></g>'+
'<rect x="346" y="148" width="22" height="22" rx="4" fill="#faf8f5"/><path d="M368 154q9 2 0 12" fill="none" stroke="#faf8f5" stroke-width="3"/>'+
'<g class="sm" fill="none" stroke="#faf8f5" stroke-width="2" stroke-linecap="round"><path d="M352 140q-4-6 0-12q4-6 0-12"/><path d="M362 140q-4-6 0-12q4-6 0-12" style="animation-delay:.4s"/></g></svg>';
var dots='<i>.</i><i>.</i><i>.</i>';
function intro(){
try{if(sessionStorage.getItem("intro-ok"))return;sessionStorage.setItem("intro-ok","1")}catch(e){}
var de=document.documentElement,st=document.createElement("style");st.textContent=css+css2;
var el=document.createElement("div");el.id="ds";el.setAttribute("role","status");el.setAttribute("aria-live","polite");
el.innerHTML='<button type="button" class="sk">Passer</button><div class="sc">'+writer+'</div><div class="k">Écriture</div><h2>Un auteur écrit'+dots+'</h2><div class="bar"><i style="animation-duration:5s"></i></div>';
el.appendChild(st);de.appendChild(el);de.style.overflow="hidden";
var done=false,t1,t2;
function end(){if(done)return;done=true;clearTimeout(t1);clearTimeout(t2);el.classList.add("out");setTimeout(function(){el.remove();de.style.overflow=""},300)}
t1=setTimeout(function(){el.querySelector(".sc").innerHTML=scene;el.querySelector(".k").textContent="Livraison";el.querySelector("h2").innerHTML="Votre livre est livré"+dots},2500);
t2=setTimeout(end,4700);
el.querySelector(".sk").onclick=end;
}
intro();
window.cartFx={pop:pop,splash:splash};
})();
