# Bloquer réellement les captures d'écran : application mobile (Capacitor)

Dans un navigateur, aucune page web ne peut empêcher une capture d'écran. Seule une application native le peut
(Android : drapeau `FLAG_SECURE`, iOS : écran de confidentialité). Le site fonctionne tel quel dans une application :
la liseuse détecte l'application et active le blocage automatiquement (`PrivacyScreen.enable()` à l'ouverture, `disable()` à la fermeture).

```bash
npm init -y
npm i @capacitor/core @capacitor/cli @capacitor/android @capacitor/ios @capacitor-community/privacy-screen
npx cap init "Editions Baobab" online.loubikoa.editions --web-dir=public
# Option 1 (recommandée) : l'application charge le site en ligne → dans capacitor.config.json ajouter :
#   "server": { "url": "https://editions.loubikoa.online", "cleartext": false }
npx cap add android && npx cap add ios
npx cap sync
npx cap open android    # puis Build > Generate Signed Bundle (Google Play)
```
Résultat : dans l'application, une capture d'écran donne une image noire et l'enregistrement d'écran est vide ;
dans le navigateur, la liseuse garde les protections de dissuasion (masquage, filigrane, copie bloquée).
