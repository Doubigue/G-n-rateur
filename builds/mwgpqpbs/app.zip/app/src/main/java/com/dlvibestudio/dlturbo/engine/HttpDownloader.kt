package com.dlvibestudio.dlturbo.engine

import com.dlvibestudio.dlturbo.data.DlStatus
import com.dlvibestudio.dlturbo.data.DownloadItem
import com.dlvibestudio.dlturbo.data.DownloadRepository
import com.dlvibestudio.dlturbo.data.Segment
import com.dlvibestudio.dlturbo.data.Settings
import com.dlvibestudio.dlturbo.data.SettingsData
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.Call
import okhttp3.ConnectionPool
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Request
import okhttp3.Response
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.util.concurrent.TimeUnit
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import kotlin.coroutines.coroutineContext
import kotlin.math.max
import kotlin.math.min

/** Le lien pointe vers une page web et non vers un fichier. */
class HtmlPageException : IOException("Page web")

/** Erreur définitive : inutile de réessayer. */
class FatalDownloadException(message: String) : IOException(message)

/** Limiteur de débit partagé par toutes les connexions. */
class RateLimiter(private val rate: () -> Long) {
    private var nextFree = 0L

    fun acquire(bytes: Int) {
        val r = rate()
        if (r <= 0) return
        val sleepNs = synchronized(this) {
            val now = System.nanoTime()
            val start = max(now, nextFree)
            nextFree = start + bytes * 1_000_000_000L / r
            start - now
        }
        if (sleepNs > 0) {
            try {
                Thread.sleep(min(sleepNs / 1_000_000L, 2000L))
            } catch (_: InterruptedException) {
            }
        }
    }
}

/**
 * Téléchargement HTTP/HTTPS accéléré : le fichier est découpé en segments, chacun
 * téléchargé par sa propre connexion (requêtes « Range »). L'avancement de chaque
 * segment est sauvegardé : après une pause, une coupure réseau ou un redémarrage,
 * chaque connexion reprend exactement à l'octet où elle s'était arrêtée.
 */
class HttpDownloader(
    private val repo: DownloadRepository,
    private val settings: Settings,
    private val limiter: RateLimiter,
) {
    val client: OkHttpClient = OkHttpClient.Builder()
        // HTTP/1.1 : une vraie connexion TCP par segment (HTTP/2 les regrouperait sur une seule).
        .protocols(listOf(Protocol.HTTP_1_1))
        .connectionPool(ConnectionPool(64, 2, TimeUnit.MINUTES))
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .retryOnConnectionFailure(true)
        .build()

    /** Client des segments : même réglage, pool de connexions plus grand (3 fichiers × 32 connexions). */
    private val ioClient: OkHttpClient = client.newBuilder()
        .connectionPool(ConnectionPool(128, 5, TimeUnit.MINUTES))
        .build()

    /**
     * Pool de fils élargi : Dispatchers.IO plafonne à 64 fils. Avec 3 téléchargements × 16–32 connexions (lectures
     * bloquantes), une partie des connexions attendrait un fil libre au lieu de lire en parallèle.
     */
    @OptIn(ExperimentalCoroutinesApi::class)
    private val ioDispatcher = Dispatchers.IO.limitedParallelism(256)

    /** Segment vivant : sa fin peut reculer quand une autre connexion vient l'aider (découpage dynamique). */
    private class Seg(val start: Long, @Volatile var end: Long, initialDone: Long) {
        /** Octets de ce segment déjà écrits sur le disque. */
        val done = AtomicLong(initialDone)
        @Volatile var active = false
        fun pos(): Long = start + done.get()
        fun remaining(): Long = if (end < 0) Long.MAX_VALUE else end - pos() + 1
    }

    private class State(
        val segs: CopyOnWriteArrayList<Seg>,
        val resumable: Boolean,
        val etag: String?,
        val part: File,
        val cookie: String = "",
        val referer: String = "",
    ) {
        /** Octets reçus du réseau (sert au calcul de la vitesse, plus fin que les octets écrits par blocs). */
        val received = AtomicLong(0)
        fun total(): Long = segs.sumOf { it.done.get() }
        fun snapshot(): List<Segment> =
            segs.sortedBy { it.start }.map { Segment(it.start, it.end, it.done.get()) }
    }

    /**
     * Nombre de connexions adaptatif (comme MyDM) : le serveur répond 429 / 503, coupe ou fait expirer des
     * connexions → on divise le nombre de connexions par 2 ; après quelques secondes calmes, on le remonte
     * progressivement jusqu'au réglage choisi.
     */
    private class Control(val max: Int, val adaptive: Boolean, startAt: Int) {
        val running = AtomicInteger(0)
        val target = AtomicInteger(startAt.coerceIn(1, max))
        @Volatile var lastThrottle = 0L
        @Volatile var lastChange = System.currentTimeMillis()

        fun throttled() {
            if (!adaptive) return
            val now = System.currentTimeMillis()
            synchronized(this) {
                if (now - lastThrottle < 4_000) return          // plusieurs connexions échouent en même temps : une seule baisse
                lastThrottle = now; lastChange = now
                val t = target.get()
                if (t > 1) target.set(maxOf(1, t / 2))
            }
        }

        /** Vrai si cette connexion doit s'arrêter (trop nombreuses par rapport à la cible) ; elle est alors déjà décomptée. */
        fun tryYield(): Boolean {
            if (!adaptive) return false
            while (true) {
                val r = running.get()
                if (r <= target.get() || r <= 1) return false
                if (running.compareAndSet(r, r - 1)) return true
            }
        }

        /** Cette connexion n'arrive pas à finir : on la retire (et on baisse la cible) tant qu'il en reste une autre. */
        fun retire(): Boolean {
            if (!adaptive) return false
            while (true) {
                val r = running.get()
                if (r <= 1) return false
                if (running.compareAndSet(r, r - 1)) {
                    synchronized(this) { target.set(maxOf(1, minOf(target.get(), r - 1))); lastThrottle = System.currentTimeMillis() }
                    return true
                }
            }
        }

        /** Remontée progressive après une période calme. Renvoie le nombre de connexions à ajouter. */
        fun maybeGrow(now: Long): Int {
            if (!adaptive) return 0
            return synchronized(this) {
                val t = target.get()
                if (t >= max || now - lastThrottle < 10_000 || now - lastChange < 8_000) return@synchronized 0
                val next = minOf(max, t + maxOf(1, t / 2))
                target.set(next); lastChange = now
                next - t
            }
        }
    }

    /** Signal interne : cette connexion se retire (le segment est repris par une autre). Ce n'est pas une erreur. */
    private class YieldSignal : RuntimeException(null, null, false, false)

    /** Nombre de connexions retenu pour chaque téléchargement après une baisse (conservé d'une relance à l'autre). */
    private val learned = ConcurrentHashMap<String, Int>()

    /** Télécharge l'élément [id] jusqu'au bout et renvoie le fichier final. */
    suspend fun run(id: String): File {
        var item = repo.get(id) ?: throw FatalDownloadException("Téléchargement introuvable")
        val cfg = settings.value
        repo.update(id) { it.copy(info = "Connexion…") }

        val existingPart = File(item.dir, item.fileName + Links.PART_SUFFIX)
        val canContinue = item.resumable && item.segments.isNotEmpty() && existingPart.exists()
        if (!canContinue) {
            item = prepare(item, cfg)
            val prepared = item
            repo.update(id) {
                it.copy(
                    fileName = prepared.fileName, dir = prepared.dir,
                    totalBytes = prepared.totalBytes, resumable = prepared.resumable,
                    etag = prepared.etag, segments = prepared.segments,
                    downloadedBytes = 0, autoName = false, videoFallback = false,
                )
            }
            repo.saveNow()
        }

        val state = State(
            segs = CopyOnWriteArrayList(item.segments.map { Seg(it.start, it.end, it.done) }),
            resumable = item.resumable,
            etag = item.etag,
            part = File(item.dir, item.fileName + Links.PART_SUFFIX),
            cookie = item.cookie,
            referer = item.referer,
        )
        val maxConn = if (state.resumable) cfg.connections.coerceIn(1, 32) else 1
        val startAt = if (cfg.adaptive && state.resumable) minOf(maxConn, learned[id] ?: maxConn) else maxConn
        val ctl = Control(maxConn, cfg.adaptive && state.resumable, startAt)
        val url = item.url

        try {
            coroutineScope {
                val scope = this
                val workers = CopyOnWriteArrayList<Job>()
                fun spawn() {
                    ctl.running.incrementAndGet()
                    workers.add(scope.launch(ioDispatcher) { worker(url, state, cfg, ctl) })
                }

                val ticker = launch {
                    // Vitesse : moyenne glissante sur ~3 s (les connexions arrivent par à-coups) puis lissage.
                    val samples = java.util.ArrayDeque<LongArray>()   // [temps ns, octets reçus]
                    samples.addLast(longArrayOf(System.nanoTime(), state.received.get()))
                    var smooth = 0.0
                    var lastLabel = ""
                    while (isActive) {
                        delay(500)
                        val time = System.nanoTime()
                        val rec = state.received.get()
                        samples.addLast(longArrayOf(time, rec))
                        while (samples.size > 7) samples.removeFirst()
                        val first = samples.first()
                        val instant = (rec - first[1]) * 1e9 / max(1L, time - first[0])
                        smooth = if (smooth == 0.0) instant else smooth * 0.5 + instant * 0.5

                        // Remontée progressive du nombre de connexions si le serveur ne proteste plus.
                        if (state.segs.any { it.remaining() > 0 }) {
                            repeat(ctl.maybeGrow(System.currentTimeMillis())) { spawn() }
                        }
                        val n = ctl.running.get()
                        val label = if (n > 1) "$n connexions" else "1 connexion"
                        val doneNow = state.total()
                        repo.update(id) {
                            it.copy(
                                downloadedBytes = doneNow,
                                speed = smooth.toLong(),
                                segments = state.snapshot(),
                                info = if (it.status == DlStatus.RUNNING && label != lastLabel) label else it.info,
                            )
                        }
                        lastLabel = label
                    }
                }
                try {
                    val initial = if (state.resumable) ctl.target.get() else 1
                    repeat(initial) { spawn() }
                    // Attend la fin de TOUTES les connexions, y compris celles ajoutées en cours de route.
                    while (true) {
                        val j = workers.firstOrNull { it.isActive } ?: break
                        j.join()
                    }
                } finally {
                    ticker.cancel()
                }
            }
        } finally {
            if (ctl.adaptive) learned[id] = ctl.target.get()
            // Toujours enregistrer la position exacte (pause, erreur, fin).
            repo.update(id) {
                it.copy(downloadedBytes = state.total(), segments = state.snapshot(), speed = 0)
            }
            repo.saveNow()
        }
        learned.remove(id)

        val done = state.total()
        if (item.totalBytes > 0 && done < item.totalBytes) {
            throw IOException("Téléchargement incomplet")
        }
        val dir = File(item.dir)
        var target = File(dir, item.fileName)
        if (target.exists()) target = Links.uniqueFile(dir, item.fileName)
        if (!state.part.renameTo(target)) {
            throw FatalDownloadException("Impossible d'enregistrer le fichier final")
        }
        val finalName = target.name
        repo.update(id) {
            it.copy(fileName = finalName, totalBytes = done, downloadedBytes = done, segments = emptyList())
        }
        return target
    }

    /** Interroge le serveur : taille, reprise possible, nom du fichier ; puis prépare le fichier. */
    private suspend fun prepare(item: DownloadItem, cfg: SettingsData): DownloadItem {
        val request = baseRequest(item.url, cfg, item.cookie, item.referer).header("Range", "bytes=0-0").build()
        var total = -1L
        var resumable = false
        var etag: String? = null
        var mime: String? = null
        var disposition: String? = null
        var finalUrl = item.url

        withCall(client.newCall(request)) { resp, _ ->
            if (!resp.isSuccessful) throw httpError(resp.code)
            mime = resp.header("Content-Type")
            disposition = resp.header("Content-Disposition")
            finalUrl = resp.request.url.toString()
            if (resp.code == 206) {
                total = resp.header("Content-Range")?.substringAfterLast('/')?.trim()?.toLongOrNull() ?: -1
                resumable = total > 0
            } else {
                total = resp.header("Content-Length")?.toLongOrNull() ?: -1
            }
            etag = resp.header("ETag")?.takeIf { !it.startsWith("W/") }
        }

        if (item.videoFallback && mime?.startsWith("text/html", ignoreCase = true) == true) {
            throw HtmlPageException()
        }

        var dirPath = item.dir
        var name = item.fileName
        if (item.autoName) {
            name = Links.fileName(finalUrl, disposition, mime)
            if (cfg.sortByCategory) dirPath = File(item.dir, Links.category(name)).path
            val reserved = repo.items.value.filter { it.id != item.id }
                .map { File(it.dir, it.fileName).path }.toSet()
            name = Links.uniqueFile(File(dirPath), name, reserved).name
        }
        val dir = File(dirPath)
        if (!dir.exists() && !dir.mkdirs() && !dir.exists()) {
            throw FatalDownloadException("Impossible de créer le dossier ${dir.path}")
        }
        if (total > 0 && dir.usableSpace in 1 until total) {
            throw FatalDownloadException("Espace de stockage insuffisant")
        }

        val count = if (resumable && total >= 2L * 1024 * 1024)
            min(cfg.connections.toLong(), max(1L, total / (1024 * 1024))).toInt()
        else 1
        val segments = ArrayList<Segment>(count)
        if (total > 0) {
            val chunk = total / count
            for (i in 0 until count) {
                val start = i * chunk
                val end = if (i == count - 1) total - 1 else start + chunk - 1
                segments.add(Segment(start, end, 0))
            }
        } else {
            segments.add(Segment(0, -1, 0))
        }

        val part = File(dir, name + Links.PART_SUFFIX)
        try {
            RandomAccessFile(part, "rw").use { it.setLength(if (total > 0) total else 0) }
        } catch (e: IOException) {
            throw FatalDownloadException("Écriture impossible dans ${dir.path}")
        }

        return item.copy(
            fileName = name, dir = dirPath, totalBytes = total, resumable = resumable,
            etag = etag, segments = segments, downloadedBytes = 0,
        )
    }

    /**
     * Segment libre à reprendre ; à défaut, découpage dynamique : on « vole » la moitié du plus gros reste d'une autre
     * connexion. Toutes les connexions travaillent donc jusqu'à la dernière seconde (pas de fin au ralenti).
     */
    private fun nextSeg(state: State): Seg? = synchronized(state) {
        val free = state.segs.filter { !it.active && it.remaining() > 0 }.minByOrNull { it.start }
        if (free != null) { free.active = true; return@synchronized free }
        if (!state.resumable) return@synchronized null
        val victim = state.segs.filter { it.active }.maxByOrNull { it.remaining() } ?: return@synchronized null
        val rest = victim.remaining()
        if (rest < 2 * MIN_SPLIT) return@synchronized null
        val mid = victim.pos() + rest / 2
        val fresh = Seg(mid, victim.end, 0)
        victim.end = mid - 1                      // la connexion d'origine s'arrêtera à mi-chemin
        fresh.active = true
        state.segs.add(fresh)
        fresh
    }

    private suspend fun worker(url: String, state: State, cfg: SettingsData, ctl: Control) {
        var counted = true
        try {
            while (true) {
                if (ctl.tryYield()) { counted = false; return }
                val seg = nextSeg(state) ?: return
                try {
                    segmentLoop(url, seg, state, cfg, ctl)
                } finally {
                    seg.active = false
                }
            }
        } catch (_: YieldSignal) {
            counted = false                       // déjà décomptée par tryYield() / retire()
        } finally {
            if (counted) ctl.running.decrementAndGet()
        }
    }

    /** Erreur typique d'un serveur qui limite le nombre de connexions : surcharge, coupure, expiration sans octet reçu. */
    private fun looksThrottled(e: IOException, progressed: Boolean): Boolean {
        val m = e.message.orEmpty()
        if (Regex("HTTP (429|5\\d\\d)").containsMatchIn(m)) return true
        if (progressed) return false
        return e is java.net.SocketException || e is java.net.SocketTimeoutException ||
            e is javax.net.ssl.SSLException || e is java.io.EOFException || m.contains("unexpected end of stream", true)
    }

    /** Télécharge un segment, avec nouvelles tentatives et reprise à l'octet près. */
    private suspend fun segmentLoop(url: String, seg: Seg, state: State, cfg: SettingsData, ctl: Control) {
        var attempt = 0
        while (true) {
            if (!state.resumable) seg.done.set(0)
            val before = seg.done.get()
            val end = seg.end
            if (end >= 0 && seg.start + before > end) return
            try {
                fetch(url, seg, state, cfg, ctl)
                val e2 = seg.end
                if (e2 < 0) return
                if (seg.start + seg.done.get() > e2) return
                if (seg.done.get() == before) throw IOException("Connexion interrompue")
                attempt = 0
            } catch (e: FatalDownloadException) {
                throw e
            } catch (e: IOException) {
                currentCoroutineContext().ensureActive()
                val progressed = seg.done.get() > before
                if (progressed) attempt = 0
                attempt++
                if (looksThrottled(e, progressed)) ctl.throttled()
                if (attempt > cfg.retries) {
                    if (ctl.retire()) throw YieldSignal()     // d'autres connexions continuent : celle-ci s'efface
                    throw e
                }
                if (ctl.tryYield()) throw YieldSignal()      // la cible vient de baisser
                delay(min(1000L shl min(attempt, 4), 15_000L))
            }
        }
    }

    private suspend fun fetch(url: String, seg: Seg, state: State, cfg: SettingsData, ctl: Control) {
        val pos0 = seg.pos()
        val builder = baseRequest(url, cfg, state.cookie, state.referer)
        if (state.resumable) {
            val end0 = seg.end
            builder.header("Range", "bytes=$pos0-" + if (end0 >= 0) end0.toString() else "")
            state.etag?.let { builder.header("If-Range", it) }
        }
        withCall(ioClient.newCall(builder.build())) { resp, active ->
            if (state.resumable) {
                if (resp.code == 200) {
                    throw FatalDownloadException("Le fichier a changé sur le serveur : relancez le téléchargement")
                }
                if (resp.code != 206) throw httpError(resp.code)
            } else if (!resp.isSuccessful) {
                throw httpError(resp.code)
            }
            val body = resp.body ?: throw IOException("Réponse vide")
            RandomAccessFile(state.part, "rw").use { raf ->
                if (!state.resumable) raf.setLength(0)
                // Tampon de 256 Ko : le réseau livre des paquets de ~8 Ko ; on écrit sur le disque par gros blocs
                // (moins d'appels système → moins de CPU, débit plus régulier).
                val buf = ByteArray(WRITE_BUFFER)
                var filled = 0
                var lastFlush = System.nanoTime()
                fun flush() {
                    if (filled <= 0) return
                    raf.seek(seg.start + seg.done.get())
                    raf.write(buf, 0, filled)
                    seg.done.addAndGet(filled.toLong())
                    filled = 0
                    lastFlush = System.nanoTime()
                }
                try {
                    val input = body.byteStream()
                    while (true) {
                        // La fin a pu reculer : une autre connexion a pris la suite de ce segment.
                        val allowed = if (seg.end >= 0) seg.end - (seg.start + seg.done.get() + filled) + 1 else Long.MAX_VALUE
                        if (allowed <= 0) break
                        val n = input.read(buf, filled, min((buf.size - filled).toLong(), allowed).toInt())
                        if (n < 0) break
                        filled += n
                        state.received.addAndGet(n.toLong())
                        limiter.acquire(n)
                        if (filled >= FLUSH_AT || System.nanoTime() - lastFlush > 300_000_000L) flush()
                        if (!active()) throw IOException("Annulé")
                        if (ctl.tryYield()) { flush(); throw YieldSignal() }
                    }
                } catch (t: Throwable) {
                    runCatching { flush() }                 // pause, coupure : les octets déjà reçus sont conservés
                    throw t
                }
                flush()
            }
        }
    }

    private fun baseRequest(
        url: String, cfg: SettingsData, cookie: String = "", referer: String = "",
    ): Request.Builder {
        val b = Request.Builder().url(url)
            .header("User-Agent", cfg.userAgent.ifBlank { SettingsData.DEFAULT_UA })
            .header("Accept", "*/*")
            .header("Accept-Encoding", "identity")
        if (cookie.isNotBlank()) b.header("Cookie", cookie)
        if (referer.isNotBlank()) b.header("Referer", referer)
        return b
    }

    private fun httpError(code: Int): IOException {
        val retryable = code >= 500 || code == 408 || code == 429
        val message = when (code) {
            401, 403 -> "Accès refusé par le serveur (HTTP $code) : le lien a peut-être expiré"
            404, 410 -> "Fichier introuvable (HTTP $code)"
            416 -> "Reprise refusée par le serveur (HTTP 416)"
            else -> "Erreur du serveur (HTTP $code)"
        }
        return if (retryable) IOException(message) else FatalDownloadException(message)
    }

    /** Petit téléchargement en mémoire (fichiers .torrent distants). */
    suspend fun fetchBytes(
        url: String, maxBytes: Int = 20 * 1024 * 1024, cookie: String = "", referer: String = "",
    ): ByteArray {
        val request = baseRequest(url, settings.value, cookie, referer).build()
        var bytes = ByteArray(0)
        withCall(client.newCall(request)) { resp, _ ->
            if (!resp.isSuccessful) throw httpError(resp.code)
            val body = resp.body ?: throw IOException("Réponse vide")
            if (body.contentLength() > maxBytes) throw FatalDownloadException("Fichier trop volumineux")
            bytes = body.bytes()
        }
        return bytes
    }

    /**
     * Exécute un appel bloquant OkHttp de façon annulable : si la coroutine est annulée
     * (pause, suppression), l'appel est coupé immédiatement, même en pleine lecture.
     */
    private suspend fun withCall(call: Call, block: (Response, () -> Boolean) -> Unit) {
        coroutineScope {
            val watcher = launch(start = CoroutineStart.UNDISPATCHED) {
                try {
                    awaitCancellation()
                } finally {
                    call.cancel()
                }
            }
            try {
                call.execute().use { resp -> block(resp) { isActive } }
            } catch (e: IOException) {
                ensureActive()
                throw e
            } finally {
                watcher.cancel()
            }
        }
    }

    companion object {
        private const val WRITE_BUFFER = 256 * 1024
        private const val FLUSH_AT = 128 * 1024
        private const val MIN_SPLIT = 2L * 1024 * 1024      // on ne découpe pas un reste de moins de 2 × 2 Mo
    }
}
