# HTML → MP4

1. `flutter create .` (génère android/ et ios/ si absents), puis `flutter pub get`
2. Android : minSdkVersion 24 ; dans AndroidManifest.xml, balise <application> : android:usesCleartextTraffic="true"
   (Android 9 ou moins : permission WRITE_EXTERNAL_STORAGE avec android:maxSdkVersion="28")
3. iOS (14+) : dans Info.plist ajouter
   - NSPhotoLibraryAddUsageDescription et NSPhotoLibraryUsageDescription
   - NSAppTransportSecurity > NSAllowsLocalNetworking = true
4. `flutter run`

Projet .zip : un index.html + ses dossiers (sons, images…). Exemple : spot_html2mp4.zip (720x1280, 30 FPS, 12 s).

Note : flutter_inappwebview 6.2.0-beta.3 est requis (la 6.1.5 échoue avec AGP 9 :
"getDefaultProguardFile('proguard-android.txt') is no longer supported").

## Correctifs (octobre 2026)
- Boutons d'upload : sélecteur FileType.any + contrôle d'extension, erreurs affichées à l'écran.
- Conversion : captures à la largeur demandée (snapshotWidth), erreur galerie non bloquante.
- Android release : compiler avec `flutter build apk --release --no-shrink` (R8 casse FFmpegKit :
  l'appli se ferme au premier appel FFmpeg). Règles dans android/app/proguard-rules.pro (voir ci-dessous).

android/app/proguard-rules.pro :
    -keep class com.antonkarpenko.** { *; }
    -keep class com.arthenica.** { *; }
    -dontwarn com.antonkarpenko.**
    -dontwarn com.arthenica.**

## Aperçu
Après l'export, l'écran « Aperçu de la vidéo » s'ouvre automatiquement (package video_player) :
lecture/pause, barre de progression, ±1 s, boucle, vitesse (×0,25 à ×2), partage.
Le bouton « Aperçu » reste disponible sous la barre de progression.

## Orientation et durée automatique (octobre 2026)
- Choix Portrait (720x1280) ou Paysage YouTube (1280x720) ; Largeur/Hauteur restent modifiables.
- Durée automatique (activée par défaut) : la page est simulée en temps virtuel (sans capture) et
  la durée est déduite des animations CSS/SVG finies, des timers, des boucles rAF qui s'arrêtent et de
  la longueur des sons joués. Animation uniquement en boucle : un cycle complet. Boucle infinie
  non mesurable : 10 s. Résultat borné de 1 à 120 s. Bouton « Détecter » pour la voir avant l'export ;
  désactive l'interrupteur pour saisir une durée à la main.
- Version web : voir web/html2mp4.html (ouvrir dans Chrome / Edge).

## Aperçu avec le son + application plus légère (octobre 2026)
- **Aperçu avant conversion** : bouton « Aperçu avec le son (avant conversion) ». La page tourne en temps réel
  avec ses sons, la musique de fond et la voix off importées (jouées en synchro), durée = durée automatique.
- **Poids de l'appli** : `ffmpeg_kit_flutter_new` embarque TOUTES les bibliothèques (variante full-gpl). Le projet
  utilise maintenant `ffmpeg_kit_flutter_new_min_gpl` (FFmpeg minimal + x264), qui suffit (x264, AAC, filtres audio).
- **Compiler léger** (à faire en plus) :
  `flutter build apk --release --split-per-abi --obfuscate --split-debug-info=build/symbols`
  puis installer `app-arm64-v8a-release.apk` (la quasi-totalité des téléphones récents).
  Dans `android/app/build.gradle(.kts)` : `ndk { abiFilters += listOf("arm64-v8a") }` (dans `defaultConfig`)
  pour ne packager qu'une architecture, ou `flutter build appbundle` pour le Play Store.
- Si une erreur `filter not found` apparaît à l'export avec min-gpl, repasser sur `ffmpeg_kit_flutter_new` et me le dire.
