import 'dart:async';
import 'dart:collection';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:video_player/video_player.dart';

/// Aperçu AVANT conversion : la page tourne en temps réel, avec ses sons,
/// la musique de fond et la voix off importées (jouées en synchro).
class LivePreviewPage extends StatefulWidget {
  const LivePreviewPage({
    super.key,
    this.url,
    this.html,
    required this.w,
    required this.h,
    required this.durationSec,
    this.musicPath,
    this.voicePath,
    this.voiceStartSec = 0,
  });

  final String? url; // projet .zip servi en local
  final String? html; // code collé / fichier .html
  final double w, h, durationSec, voiceStartSec;
  final String? musicPath, voicePath;

  @override
  State<LivePreviewPage> createState() => _LivePreviewPageState();
}

class _LivePreviewPageState extends State<LivePreviewPage> {
  InAppWebViewController? _ctl;
  VideoPlayerController? _music, _voice;
  Timer? _tick, _voiceTimer;
  final _sw = Stopwatch();
  bool _ended = false;

  @override
  void initState() {
    super.initState();
    _initAudio();
  }

  Future<VideoPlayerController?> _open(String? path) async {
    if (path == null) return null;
    try {
      final c = VideoPlayerController.file(File(path));
      await c.initialize();
      return c;
    } catch (_) {
      return null; // fichier illisible : on ignore
    }
  }

  Future<void> _initAudio() async {
    _music = await _open(widget.musicPath);
    _voice = await _open(widget.voicePath);
    await _music?.setLooping(true);
    await _music?.setVolume(_voice != null ? 0.3 : 1.0);
    await _voice?.setVolume(1.0);
  }

  Future<void> _stopAll() async {
    _tick?.cancel();
    _voiceTimer?.cancel();
    _sw..stop()..reset();
    await _music?.pause();
    await _voice?.pause();
  }

  /// Démarre musique, voix et chrono au moment où la page est chargée.
  Future<void> _start() async {
    await _stopAll();
    if (!mounted) return;
    setState(() => _ended = false);
    _sw.start();
    await _music?.seekTo(Duration.zero);
    await _music?.play();
    await _voice?.seekTo(Duration.zero);
    _voiceTimer = Timer(
      Duration(milliseconds: (widget.voiceStartSec * 1000).round()),
      () => _voice?.play(),
    );
    _tick = Timer.periodic(const Duration(milliseconds: 100), (_) async {
      if (!mounted) return;
      if (_sw.elapsedMilliseconds / 1000 >= widget.durationSec) {
        await _stopAll();
        if (mounted) setState(() => _ended = true);
      } else {
        setState(() {});
      }
    });
  }

  Future<void> _replay() async {
    await _stopAll();
    final c = _ctl;
    if (c == null) return;
    if (widget.url != null) {
      await c.loadUrl(urlRequest: URLRequest(url: WebUri(widget.url!)));
    } else {
      await c.loadData(data: widget.html ?? '');
    }
    // _start() est rappelé par onLoadStop
  }

  @override
  void dispose() {
    _tick?.cancel();
    _voiceTimer?.cancel();
    _music?.dispose();
    _voice?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final el = (_sw.elapsedMilliseconds / 1000).clamp(0.0, widget.durationSec);
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: const Text('Aperçu avec le son'),
      ),
      body: SafeArea(
        child: Column(children: [
          Expanded(
            child: Center(
              child: FittedBox(
                child: SizedBox(
                  width: widget.w,
                  height: widget.h,
                  child: InAppWebView(
                    initialSettings: InAppWebViewSettings(
                      mediaPlaybackRequiresUserGesture: false,
                      allowsInlineMediaPlayback: true,
                      javaScriptEnabled: true,
                    ),
                    initialUserScripts: UnmodifiableListView([
                      // masque l'astuce « touchez pour activer le son » des pages
                      UserScript(
                        source: 'window.__seek=window.__seek||function(){};',
                        injectionTime: UserScriptInjectionTime.AT_DOCUMENT_START,
                      ),
                    ]),
                    initialUrlRequest: widget.url != null
                        ? URLRequest(url: WebUri(widget.url!))
                        : null,
                    initialData: widget.url == null
                        ? InAppWebViewInitialData(data: widget.html ?? '')
                        : null,
                    onWebViewCreated: (c) => _ctl = c,
                    onLoadStop: (c, u) => _start(),
                  ),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(children: [
              Text('${el.toStringAsFixed(1)} s',
                  style: const TextStyle(color: Colors.white)),
              Expanded(
                child: Slider(
                  value: el.toDouble(),
                  min: 0,
                  max: widget.durationSec <= 0 ? 1 : widget.durationSec,
                  onChanged: null,
                ),
              ),
              Text('${widget.durationSec.toStringAsFixed(1)} s',
                  style: const TextStyle(color: Colors.white)),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              FilledButton.icon(
                onPressed: _replay,
                icon: Icon(_ended ? Icons.replay : Icons.restart_alt),
                label: Text(_ended ? 'Rejouer' : 'Recommencer'),
              ),
              const SizedBox(width: 12),
              OutlinedButton.icon(
                onPressed: () => Navigator.of(context).pop(),
                icon: const Icon(Icons.close),
                label: const Text('Fermer'),
              ),
            ]),
          ),
        ]),
      ),
    );
  }
}
