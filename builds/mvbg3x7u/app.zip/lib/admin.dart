import 'dart:math';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'data.dart';
import 'entry.dart';
import 'notif.dart';
import 'settings.dart';

class AdminGate extends StatefulWidget {
  final Widget Function(VoidCallback logout) builder;
  const AdminGate({super.key, required this.builder});
  static final unlocked = ValueNotifier<bool>(false); // déverrouillage hors-ligne partagé entre Admin et Paramètres
  @override
  State<AdminGate> createState() => _AdminGateState();
}

class _AdminGateState extends State<AdminGate> {
  bool loading = false;
  final email = TextEditingController(), pwd = TextEditingController();
  String? err;

  void _login() async {
    setState(() { loading = true; err = null; });
    try {
      if (await Repo.online()) {
        await FirebaseAuth.instance.signInWithEmailAndPassword(email: email.text.trim(), password: pwd.text);
        await Repo.flush(); // envoie les données saisies hors-ligne
      } else {
        final saved = Repo.p.getString('admin_pwd');
        if (saved == null) { await Repo.p.setString('admin_pwd', pwd.text); AdminGate.unlocked.value = true; }
        else if (saved == pwd.text) { AdminGate.unlocked.value = true; }
        else { err = 'Mot de passe incorrect'; }
      }
    } on FirebaseAuthException catch (e) { err = e.message; }
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext c) => ValueListenableBuilder<bool>(valueListenable: AdminGate.unlocked, builder: (_, offlineUnlocked, __) => StreamBuilder<User?>(
        stream: FirebaseAuth.instance.authStateChanges(),
        builder: (_, snap) {
          if (snap.data != null || offlineUnlocked) return widget.builder(() async { AdminGate.unlocked.value = false; await FirebaseAuth.instance.signOut(); if (mounted) setState(() {}); });
          return FutureBuilder<bool>(
            future: Repo.online(),
            builder: (_, on) {
              final isOn = on.data ?? false;
              return Scaffold(
                body: Container(
                  decoration: const BoxDecoration(gradient: LinearGradient(colors: [Color(0xFF1B5E20), Color(0xFF81C784)], begin: Alignment.topCenter, end: Alignment.bottomCenter)),
                  child: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: Card(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
                    const Icon(Icons.lock_outline, size: 48),
                    Text(isOn ? 'Connexion administrateur' : 'Mode hors-ligne', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                    Text(isOn ? 'Email et mot de passe' : (Repo.p.getString('admin_pwd') == null ? 'Créez un mot de passe local' : 'Entrez votre mot de passe local'), textAlign: TextAlign.center),
                    const SizedBox(height: 16),
                    if (isOn) TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Email', border: OutlineInputBorder())),
                    const SizedBox(height: 12),
                    TextField(controller: pwd, obscureText: true, decoration: const InputDecoration(labelText: 'Mot de passe', border: OutlineInputBorder())),
                    if (err != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(err!, style: const TextStyle(color: Colors.red))),
                    const SizedBox(height: 16),
                    SizedBox(width: double.infinity, child: FilledButton(onPressed: loading ? null : _login, child: loading ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Text('Entrer'))),
                    TextButton(onPressed: () => setState(() {}), child: const Text('Actualiser la connexion')),
                  ]))))),
                ),
              );
            },
          );
        },
      ));
}

class AdminPanel extends StatelessWidget {
  final VoidCallback onLogout;
  const AdminPanel({super.key, required this.onLogout});
  @override
  Widget build(BuildContext c) => DefaultTabController(
        length: 4,
        child: Scaffold(
          appBar: AppBar(
            title: const Text('Administration'),
            actions: [
              ValueListenableBuilder(valueListenable: Repo.pendingCount, builder: (_, n, __) => n == 0 ? const SizedBox() : Chip(avatar: const Icon(Icons.cloud_off, size: 16), label: Text('$n en attente'))),
              IconButton(icon: const Icon(Icons.logout), onPressed: onLogout),
            ],
            bottom: const TabBar(isScrollable: true, tabs: [Tab(text: 'Animaux'), Tab(text: 'Œufs'), Tab(text: 'Dépenses'), Tab(text: 'Alarmes')]),
          ),
          body: TabBarView(children: [EntryTab(), EggTab(), ExpenseTab(), ReminderTab()]),
        ),
      );
}

String today() => DateFormat('yyyy-MM-dd').format(DateTime.now());
void snack(BuildContext c, String m) => saved(c, m);

class ExpenseTab extends StatefulWidget {
  const ExpenseTab({super.key});
  @override
  State<ExpenseTab> createState() => _ExpenseTabState();
}

class _ExpenseTabState extends State<ExpenseTab> {
  String cat = expenseCats.first;
  final m = TextEditingController(), n = TextEditingController();
  @override
  Widget build(BuildContext c) => ListView(padding: const EdgeInsets.all(16), children: [
        DropdownButtonFormField<String>(value: cat, decoration: const InputDecoration(labelText: 'Catégorie', border: OutlineInputBorder()), items: [for (final e in expenseCats) DropdownMenuItem(value: e, child: Text(e))], onChanged: (v) => setState(() => cat = v!)),
        const SizedBox(height: 12),
        TextField(controller: m, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Montant (${AppSettings.currency})', border: OutlineInputBorder())),
        const SizedBox(height: 12),
        TextField(controller: n, decoration: const InputDecoration(labelText: 'Note (ex: employé Jean, facture mars)', border: OutlineInputBorder())),
        const SizedBox(height: 12),
        FilledButton.icon(icon: const Icon(Icons.add), label: const Text('Ajouter la dépense'), onPressed: () async {
          if (m.text.isEmpty) return toast(c, 'Entrez le montant', error: true);
          final montant = num.tryParse(m.text.replaceAll(',', '.')) ?? 0;
          await Repo.add('expenses', {'c': cat, 'm': montant, 'n': n.text, 'd': today()});
          m.clear(); n.clear();
          if (c.mounted) saved(c, 'Enregistré ✔ $cat • ${money(montant)}');
        }),
        const Divider(height: 32),
        ValueListenableBuilder(valueListenable: Repo.expenses, builder: (_, l, __) => Column(children: [
          for (final e in l.take(30)) ListTile(
            leading: Icon(e['pending'] == true ? Icons.cloud_off : Icons.receipt_long), title: Text('${e['c']} • ${money(e['m'] ?? 0)}'), subtitle: Text('${e['d']} ${e['n'] ?? ''}'),
            trailing: e['pending'] == true ? null : IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => Repo.remove('expenses', e['id'])),
          ),
        ])),
      ]);
}

class ToolsTab extends StatelessWidget {
  const ToolsTab({super.key});
  @override
  Widget build(BuildContext c) => Column(children: [
        Card(child: ListTile(leading: const Icon(Icons.auto_awesome), title: const Text('Utiliser les données d\'exemple'), subtitle: const Text('Ajoute 30 jours de données fictives'), onTap: () async { await _sample(); if (c.mounted) snack(c, 'Données d\'exemple ajoutées'); })),
        Card(child: ListTile(leading: const Icon(Icons.sync), title: const Text('Synchroniser maintenant'), subtitle: ValueListenableBuilder(valueListenable: Repo.pendingCount, builder: (_, n, __) => Text('$n enregistrements en attente')), onTap: () async { await Repo.flush(); if (c.mounted) saved(c, 'Synchronisation terminée ✔'); })),
        Card(child: ListTile(leading: const Icon(Icons.password), title: const Text('Mot de passe hors-ligne'), subtitle: const Text('Utilisé quand il n\'y a pas d\'internet'), onTap: () async {
          final t = TextEditingController();
          await showDialog(context: c, builder: (_) => AlertDialog(title: const Text('Nouveau mot de passe'), content: TextField(controller: t, obscureText: true), actions: [TextButton(onPressed: () async { if (t.text.length >= 4) { await Repo.p.setString('admin_pwd', t.text); if (c.mounted) saved(c, 'Mot de passe enregistré ✔'); } if (c.mounted) Navigator.pop(c); }, child: const Text('OK'))]));
        })),
      ]);

  Future<void> _sample() async {
    final r = Random(7);
    final df = DateFormat('yyyy-MM-dd');
    for (final a in animals) {
      await Repo.add('records', {'a': a.key, 'k': 'achat', 'q': a.poultry ? 200 + r.nextInt(300) : 5 + r.nextInt(30), 'm': 150000 + r.nextInt(900000), 'n': 'Lot ${a.key.toUpperCase()}-01', 'd': df.format(DateTime.now().subtract(const Duration(days: 40)))});
    }
    for (var i = 29; i >= 0; i--) {
      final d = df.format(DateTime.now().subtract(Duration(days: i)));
      for (final a in animals.where((a) => a.eggs)) {
        final o = 60 + r.nextInt(80);
        await Repo.add('records', {'a': a.key, 'k': 'oeufs', 'q': o, 'm': 0, 'n': '', 'd': d});
        await Repo.add('records', {'a': a.key, 'k': 'casses', 'q': r.nextInt(6), 'm': 0, 'n': '', 'd': d});
      }
      await Repo.add('records', {'a': 'chair', 'k': 'mort', 'q': r.nextInt(4), 'm': 0, 'n': '', 'd': d});
      if (i % 7 == 0) {
        await Repo.add('records', {'a': 'chair', 'k': 'vente', 'q': 40, 'm': 140000, 'n': 'Vente marché', 'd': d});
        await Repo.add('records', {'a': 'porc', 'k': 'vente', 'q': 2, 'm': 180000, 'n': 'Vente boucher', 'd': d});
        await Repo.add('records', {'a': 'pondeuse', 'k': 'eclosion', 'q': 25, 'm': 0, 'n': 'Lot E-${i + 1}', 'd': d});
        await Repo.add('expenses', {'c': 'Nourriture', 'm': 60000 + r.nextInt(40000), 'n': 'Sacs aliment', 'd': d});
        await Repo.add('expenses', {'c': 'Piqûres / vétérinaire', 'm': 15000, 'n': 'Vaccin', 'd': d});
      }
    }
    await Repo.add('expenses', {'c': 'Loyer', 'm': 100000, 'n': 'Loyer du mois', 'd': today()});
    await Repo.add('expenses', {'c': 'Électricité', 'm': 35000, 'n': 'Facture', 'd': today()});
    await Repo.add('expenses', {'c': 'Salaires', 'm': 150000, 'n': '2 employés', 'd': today()});
  }
}

class EmployeeTab extends StatefulWidget {
  const EmployeeTab({super.key});
  @override
  State<EmployeeTab> createState() => _EmployeeTabState();
}

class _EmployeeTabState extends State<EmployeeTab> {
  final nm = TextEditingController(), ro = TextEditingController(), sa = TextEditingController();
  static const roles = ['Gérant', 'Ouvrier', 'Vétérinaire', 'Gardien', 'Vendeur', 'Comptable'];

  @override
  Widget build(BuildContext c) => ListView(padding: const EdgeInsets.all(16), children: [
      TextField(controller: nm, decoration: const InputDecoration(labelText: 'Nom', border: OutlineInputBorder())),
      const SizedBox(height: 8),
      TextField(controller: ro, decoration: const InputDecoration(labelText: 'Rôle (ex : gérant, ouvrier…)', border: OutlineInputBorder())),
      Wrap(spacing: 6, children: [for (final r in roles) ActionChip(label: Text(r), onPressed: () => setState(() => ro.text = r))]),
      const SizedBox(height: 8),
      TextField(controller: sa, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: 'Salaire mensuel (${AppSettings.currency})', border: const OutlineInputBorder())),
      const SizedBox(height: 8),
      FilledButton.icon(icon: const Icon(Icons.person_add), label: const Text('Ajouter l\'employé'), onPressed: () async {
        if (nm.text.trim().isEmpty) return toast(c, 'Entrez le nom de l\'employé', error: true);
        final nom = nm.text.trim();
        await Repo.add('employees', {'name': nom, 'role': ro.text.trim(), 'salary': num.tryParse(sa.text) ?? 0, 'd': today()});
        nm.clear(); ro.clear(); sa.clear();
        if (c.mounted) saved(c, 'Enregistré ✔ Employé : $nom');
      }),
      const Divider(height: 28),
      ValueListenableBuilder(valueListenable: Repo.employees, builder: (_, l, __) => Column(children: [
        for (final e in l) Card(child: ListTile(
          leading: const CircleAvatar(child: Icon(Icons.person)), title: Text('${e['name']}'), subtitle: Text('${(e['role'] ?? '').toString().isEmpty ? 'Rôle non précisé' : e['role']} • ${money(e['salary'] ?? 0)} / mois'),
          trailing: Row(mainAxisSize: MainAxisSize.min, children: [
            FilledButton.tonal(onPressed: () async {
              await Repo.add('expenses', {'c': 'Salaires', 'm': e['salary'], 'n': 'Salaire ${e['name']} ${DateFormat('MM/yyyy').format(DateTime.now())}', 'd': today()});
              if (c.mounted) saved(c, 'Salaire payé ✔ et ajouté aux dépenses');
            }, child: const Text('Payer')),
            if (e['pending'] != true) IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => Repo.remove('employees', e['id'])),
          ]),
        )),
      ])),
    ]);
}
