# DL Débit

Affiche la vitesse de connexion en haut de l'écran, à côté de LTE (Android 8 et plus).

## Compiler
Envoyer ce dossier (contenu à la racine, dossier `.github` compris) dans un dépôt GitHub,
puis ouvrir l'onglet **Actions** > **Compiler APK**. L'APK est dans les *Artifacts* (`DL-Debit-apk`).

## Installer et activer
1. Installer l'APK.
2. Ouvrir DL Débit > « Activer l'affichage à côté de LTE ».
3. Si le réglage est grisé (Android 13+) : fiche de l'appli > menu ⋮ > « Autoriser les paramètres restreints ».
4. Ajuster la position avec les curseurs.

## À savoir
- La valeur est le trafic réel du téléphone à l'instant : 0 si rien ne se télécharge.
  Ce n'est pas un test de débit maximal, et l'appli ne consomme pas de données.
- L'accessibilité sert uniquement à dessiner sur la barre d'état ; le contenu de l'écran n'est pas lu.
- APK de test (signature debug) : si une nouvelle version refuse de s'installer, désinstaller l'ancienne.
