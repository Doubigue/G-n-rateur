package com.dlvibe.debit;

import java.util.Locale;

/** Mise en forme des débits (aucune dépendance Android). */
final class Format {
    private Format() {}

    /** Retourne {valeur, unité}. bits=true : kb/s, Mb/s ; sinon Ko/s, Mo/s. */
    static String[] parts(long bytesPerSecond, boolean bits) {
        double v = Math.max(0, bytesPerSecond) * (bits ? 8.0 : 1.0) / 1000.0;
        String[] units = bits ? new String[]{"kb/s", "Mb/s", "Gb/s"}
                              : new String[]{"Ko/s", "Mo/s", "Go/s"};
        int i = 0;
        while (v >= 999.5 && i < units.length - 1) {
            v /= 1000.0;
            i++;
        }
        // Une décimale seulement sous 10 Mo/s, pour que le texte reste court.
        String value = (i > 0 && v < 9.95)
                ? String.format(Locale.FRANCE, "%.1f", v)
                : String.valueOf(Math.round(v));
        return new String[]{value, units[i]};
    }

    static String text(long bytesPerSecond, boolean bits) {
        String[] p = parts(bytesPerSecond, bits);
        return p[0] + " " + p[1];
    }
}
