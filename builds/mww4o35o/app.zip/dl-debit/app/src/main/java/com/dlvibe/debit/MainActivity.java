package com.dlvibe.debit;

import android.Manifest;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private LinearLayout root;
    private TextView status;
    private Switch notifSwitch;

    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        prefs = Prefs.get(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(32));

        title("DL Débit", 28);
        status = label("");

        button("1. Activer l'affichage à côté de LTE", v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        label("Dans la liste, ouvrez « DL Débit » (parfois sous « Applications installées ») "
                + "puis activez-le.");
        button("Réglage grisé ? Ouvrir la fiche de l'appli", v ->
                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + getPackageName()))));
        label("Android 13 et plus : sur la fiche, touchez ⋮ puis « Autoriser les paramètres "
                + "restreints », et revenez à l'étape 1.");

        title("Position et style", 18);
        int screenDp = Math.round(getResources().getDisplayMetrics().widthPixels
                / getResources().getDisplayMetrics().density);
        slider("Horizontal (vers la gauche)", Prefs.X, 0, screenDp - 40, 105);
        slider("Vertical (milieu = normal)", Prefs.Y, 0, 60, Prefs.Y_ZERO);
        slider("Taille du texte", Prefs.SIZE, 8, 18, 11);
        spinner("Valeur affichée", Prefs.MODE,
                new String[]{"Réception ↓", "Réception ↓ et envoi ↑", "Total ↕"});
        spinner("Couleur", Prefs.COLOR, new String[]{"Blanc", "Noir", "Or", "Vert"});
        toggle("Fond contrasté", Prefs.BACKGROUND, false);
        toggle("Masquer en paysage (vidéos, jeux)", Prefs.HIDE_LANDSCAPE, true);
        toggle("Unité en bits (Mb/s) au lieu d'octets (Mo/s)", Prefs.BITS, false);

        title("Autre méthode (sans accessibilité)", 18);
        label("Affiche le débit en icône de notification, à gauche de la barre d'état.");
        notifSwitch = toggle("Icône de notification", Prefs.NOTIF, false);
        notifSwitch.setOnCheckedChangeListener((b, on) -> setNotif(on));

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);

        if (prefs.getBoolean(Prefs.NOTIF, false)) {
            startForegroundService(new Intent(this, NotifService.class));
        }
    }

    @Override protected void onResume() {
        super.onResume();
        boolean on = overlayEnabled();
        status.setText(on ? "● Affichage activé" : "○ Affichage désactivé");
        status.setTextColor(on ? 0xFF4CE67A : 0xFFE6B84C);
    }

    private boolean overlayEnabled() {
        String list = Settings.Secure.getString(getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (list == null) return false;
        ComponentName mine = new ComponentName(this, OverlayService.class);
        for (String s : list.split(":")) {
            if (mine.equals(ComponentName.unflattenFromString(s))) return true;
        }
        return false;
    }

    private void setNotif(boolean on) {
        prefs.edit().putBoolean(Prefs.NOTIF, on).apply();
        Intent service = new Intent(this, NotifService.class);
        if (!on) {
            stopService(service);
            return;
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(
                Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
            return;
        }
        startForegroundService(service);
    }

    @Override public void onRequestPermissionsResult(int code, String[] p, int[] results) {
        super.onRequestPermissionsResult(code, p, results);
        if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
            startForegroundService(new Intent(this, NotifService.class));
        } else {
            notifSwitch.setChecked(false);
        }
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void add(View v) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(10);
        root.addView(v, p);
    }

    private TextView label(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(14);
        add(t);
        return t;
    }

    private void title(String text, int size) {
        TextView t = label(text);
        t.setTextSize(size);
        t.setTextColor(getColor(R.color.or));
        t.setPadding(0, dp(12), 0, 0);
    }

    private void button(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        add(b);
    }

    private void slider(String text, String key, int min, int max, int def) {
        label(text);
        SeekBar s = new SeekBar(this);
        s.setMin(min);
        s.setMax(max);
        s.setProgress(prefs.getInt(key, def));
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int value, boolean fromUser) {
                if (fromUser) prefs.edit().putInt(key, value).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar bar) {}
            @Override public void onStopTrackingTouch(SeekBar bar) {}
        });
        add(s);
    }

    private void spinner(String text, String key, String[] choices) {
        label(text);
        Spinner s = new Spinner(this);
        ArrayAdapter<String> a = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, choices);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(a);
        s.setSelection(prefs.getInt(key, 0));
        s.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                prefs.edit().putInt(key, pos).apply();
            }
            @Override public void onNothingSelected(AdapterView<?> p) {}
        });
        add(s);
    }

    private Switch toggle(String text, String key, boolean def) {
        Switch s = new Switch(this);
        s.setText(text);
        s.setChecked(prefs.getBoolean(key, def));
        CompoundButton.OnCheckedChangeListener l =
                (b, on) -> prefs.edit().putBoolean(key, on).apply();
        s.setOnCheckedChangeListener(l);
        add(s);
        return s;
    }
}
