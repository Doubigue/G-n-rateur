package com.dlvibe.debit;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Relance le mode notification au démarrage (l'accessibilité redémarre seule). */
public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        String a = i.getAction();
        if (!Intent.ACTION_BOOT_COMPLETED.equals(a)
                && !Intent.ACTION_MY_PACKAGE_REPLACED.equals(a)) return;
        if (Prefs.get(c).getBoolean(Prefs.NOTIF, false)) {
            c.startForegroundService(new Intent(c, NotifService.class));
        }
    }
}
