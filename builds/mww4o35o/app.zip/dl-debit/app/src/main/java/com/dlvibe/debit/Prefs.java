package com.dlvibe.debit;

import android.content.Context;
import android.content.SharedPreferences;

final class Prefs {
    static final String X = "x";                 // distance depuis le bord droit (dp)
    static final String Y = "y";                 // décalage vertical (dp), 20 = zéro
    static final String SIZE = "size";           // taille du texte (dp)
    static final String MODE = "mode";           // 0 réception, 1 les deux, 2 total
    static final String COLOR = "color";
    static final String BITS = "bits";
    static final String BACKGROUND = "background";
    static final String HIDE_LANDSCAPE = "hide_landscape";
    static final String NOTIF = "notif";

    static final int Y_ZERO = 20;

    static SharedPreferences get(Context c) {
        return c.getSharedPreferences("reglages", Context.MODE_PRIVATE);
    }
}
