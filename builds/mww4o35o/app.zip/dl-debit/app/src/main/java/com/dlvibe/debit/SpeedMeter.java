package com.dlvibe.debit;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.LinkProperties;
import android.net.Network;
import android.net.TrafficStats;
import android.os.Build;
import android.os.SystemClock;

/** Mesure le trafic réel du téléphone (ne consomme aucune donnée). */
final class SpeedMeter {
    private final ConnectivityManager cm;
    private String iface;
    private long lastRx, lastTx, lastTime;

    /** Débits en octets par seconde. */
    long down, up;

    SpeedMeter(Context c) {
        cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
    }

    void reset() {
        lastTime = 0;
        down = up = 0;
    }

    void sample() {
        String current = activeInterface();
        long rx = -1, tx = -1;
        if (current != null && Build.VERSION.SDK_INT >= 31) {
            rx = TrafficStats.getRxBytes(current);
            tx = TrafficStats.getTxBytes(current);
        }
        if (rx < 0 || tx < 0) {
            current = null;
            rx = TrafficStats.getTotalRxBytes();
            tx = TrafficStats.getTotalTxBytes();
        }
        long now = SystemClock.elapsedRealtime();
        boolean sameSource = current == null ? iface == null : current.equals(iface);
        if (lastTime > 0 && sameSource && now > lastTime) {
            down = Math.max(0, rx - lastRx) * 1000 / (now - lastTime);
            up = Math.max(0, tx - lastTx) * 1000 / (now - lastTime);
        } else {
            down = up = 0;
        }
        iface = current;
        lastRx = rx;
        lastTx = tx;
        lastTime = now;
    }

    private String activeInterface() {
        if (cm == null) return null;
        Network n = cm.getActiveNetwork();
        if (n == null) return null;
        LinkProperties lp = cm.getLinkProperties(n);
        return lp == null ? null : lp.getInterfaceName();
    }
}
