package com.dlvibe.debit;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

/** Mode secours : le débit apparaît comme icône de notification (à gauche de la barre). */
public class NotifService extends Service {
    private static final String CHANNEL = "debit";
    private static final int ID = 1;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private SpeedMeter meter;
    private NotificationManager nm;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            meter.sample();
            nm.notify(ID, build());
            handler.postDelayed(this, 1000);
        }
    };

    private final BroadcastReceiver screen = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            handler.removeCallbacks(tick);
            if (Intent.ACTION_SCREEN_ON.equals(i.getAction())) {
                meter.reset();
                handler.post(tick);
            }
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        meter = new SpeedMeter(this);
        nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel ch = new NotificationChannel(
                CHANNEL, "Débit en direct", NotificationManager.IMPORTANCE_LOW);
        ch.setShowBadge(false);
        nm.createNotificationChannel(ch);
        IntentFilter f = new IntentFilter(Intent.ACTION_SCREEN_OFF);
        f.addAction(Intent.ACTION_SCREEN_ON);
        registerReceiver(screen, f);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(ID, build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(ID, build());
        }
        handler.removeCallbacks(tick);
        if (((PowerManager) getSystemService(POWER_SERVICE)).isInteractive()) handler.post(tick);
        return START_STICKY;
    }

    private Notification build() {
        boolean bits = Prefs.get(this).getBoolean(Prefs.BITS, false);
        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(icon(Format.parts(meter.down, bits)))
                .setContentTitle("↓ " + Format.text(meter.down, bits)
                        + "   ↑ " + Format.text(meter.up, bits))
                .setContentIntent(open)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .build();
    }

    private Icon icon(String[] parts) {
        Bitmap b = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.WHITE);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        draw(c, p, parts[0], 58, 52);
        draw(c, p, parts[1], 38, 92);
        return Icon.createWithBitmap(b);
    }

    private void draw(Canvas c, Paint p, String s, float size, float y) {
        p.setTextSize(size);
        float w = p.measureText(s);
        if (w > 94) p.setTextSize(size * 94 / w);
        c.drawText(s, 48, y, p);
    }

    @Override public void onDestroy() {
        handler.removeCallbacks(tick);
        unregisterReceiver(screen);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) {
        return null;
    }
}
