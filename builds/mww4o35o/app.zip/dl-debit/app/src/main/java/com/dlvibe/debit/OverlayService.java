package com.dlvibe.debit;

import android.accessibilityservice.AccessibilityService;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.TextView;

/**
 * Seul un service d'accessibilité peut dessiner PAR-DESSUS la barre d'état :
 * une superposition classique passe en dessous.
 */
public class OverlayService extends AccessibilityService
        implements SharedPreferences.OnSharedPreferenceChangeListener {

    static final int[] COLORS = {Color.WHITE, Color.BLACK, 0xFFE6B84C, 0xFF4CE67A};

    private final Handler handler = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private TextView view;
    private WindowManager.LayoutParams params;
    private SpeedMeter meter;
    private SharedPreferences prefs;
    private boolean receiverRegistered;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            meter.sample();
            render();
            handler.postDelayed(this, 1000);
        }
    };

    // Pause quand l'écran est éteint, pour économiser la batterie.
    private final BroadcastReceiver screen = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            if (Intent.ACTION_SCREEN_OFF.equals(i.getAction())) handler.removeCallbacks(tick);
            else start();
        }
    };

    @Override protected void onServiceConnected() {
        cleanup();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        meter = new SpeedMeter(this);
        prefs = Prefs.get(this);

        view = new TextView(this);
        view.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        view.setGravity(Gravity.CENTER);
        view.setIncludeFontPadding(false);
        view.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);

        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.RIGHT;
        if (Build.VERSION.SDK_INT >= 30) {
            params.setFitInsetsTypes(0);
            params.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        } else if (Build.VERSION.SDK_INT >= 28) {
            params.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }

        wm.addView(view, params);
        prefs.registerOnSharedPreferenceChangeListener(this);
        IntentFilter f = new IntentFilter(Intent.ACTION_SCREEN_OFF);
        f.addAction(Intent.ACTION_SCREEN_ON);
        registerReceiver(screen, f);
        receiverRegistered = true;

        applyStyle();
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm.isInteractive()) start();
    }

    private void start() {
        handler.removeCallbacks(tick);
        meter.reset();
        handler.post(tick);
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private int statusBarHeight() {
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : dp(24);
    }

    private void applyStyle() {
        if (view == null) return;
        int color = COLORS[Math.floorMod(prefs.getInt(Prefs.COLOR, 0), COLORS.length)];
        view.setTextColor(color);
        // En dp et non en sp : la barre d'état ne grandit pas avec la police système.
        // Deux lignes : texte réduit pour tenir dans la hauteur de la barre.
        float size = prefs.getInt(Prefs.SIZE, 11)
                * (prefs.getInt(Prefs.MODE, 0) == 1 ? 0.8f : 1f);
        view.setTextSize(TypedValue.COMPLEX_UNIT_DIP, size);
        if (prefs.getBoolean(Prefs.BACKGROUND, false)) {
            view.setBackgroundColor(color == Color.BLACK ? 0xCCFFFFFF : 0xCC000000);
        } else {
            view.setBackground(null);
        }
        view.setPadding(dp(3), 0, dp(3), 0);
        view.setMinHeight(statusBarHeight());
        params.x = dp(prefs.getInt(Prefs.X, 105));
        params.y = dp(prefs.getInt(Prefs.Y, Prefs.Y_ZERO) - Prefs.Y_ZERO);
        boolean landscape = getResources().getConfiguration().orientation
                == Configuration.ORIENTATION_LANDSCAPE;
        view.setVisibility(landscape && prefs.getBoolean(Prefs.HIDE_LANDSCAPE, true)
                ? View.GONE : View.VISIBLE);
        wm.updateViewLayout(view, params);
        render();
    }

    private void render() {
        if (view == null) return;
        boolean bits = prefs.getBoolean(Prefs.BITS, false);
        int mode = prefs.getInt(Prefs.MODE, 0);
        String s;
        if (mode == 1) {
            s = "↓" + Format.text(meter.down, bits) + "\n↑" + Format.text(meter.up, bits);
        } else {
            s = mode == 2 ? "↕ " + Format.text(meter.down + meter.up, bits)
                          : "↓ " + Format.text(meter.down, bits);
        }
        view.setText(s);
    }

    @Override public void onSharedPreferenceChanged(SharedPreferences p, String key) {
        applyStyle();
    }

    @Override public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        applyStyle();
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {}

    @Override public void onInterrupt() {}

    @Override public boolean onUnbind(Intent intent) {
        cleanup();
        return super.onUnbind(intent);
    }

    @Override public void onDestroy() {
        cleanup();
        super.onDestroy();
    }

    private void cleanup() {
        handler.removeCallbacks(tick);
        if (prefs != null) prefs.unregisterOnSharedPreferenceChangeListener(this);
        if (receiverRegistered) {
            unregisterReceiver(screen);
            receiverRegistered = false;
        }
        if (view != null) {
            wm.removeView(view);
            view = null;
        }
    }
}
