package com.mediastudio.app

import android.graphics.Color
import android.graphics.BitmapFactory
import android.content.Context
import android.text.SpannableString
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import androidx.media3.common.Effect
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Brightness
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.StaticOverlaySettings
import androidx.media3.effect.Presentation
import androidx.media3.effect.RgbAdjustment
import androidx.media3.effect.RgbFilter
import androidx.media3.effect.RgbMatrix
import androidx.media3.effect.TextOverlay
import androidx.media3.effect.TextureOverlay
import com.google.common.collect.ImmutableList

/** Fondu au noir : entrée et/ou sortie de 0,5 s (transition « fondu enchaîné via noir » entre clips). */
@UnstableApi
class FadeMatrix(private val durationUs: Long, private val fadeIn: Boolean, private val fadeOut: Boolean) : RgbMatrix {
    override fun getMatrix(presentationTimeUs: Long, useHdr: Boolean): FloatArray {
        val d = 500_000f
        val a = if (fadeIn) presentationTimeUs / d else 1f
        val b = if (fadeOut) (durationUs - presentationTimeUs) / d else 1f
        val f = minOf(a, b).coerceIn(0f, 1f)
        return floatArrayOf(
            f, 0f, 0f, 0f,
            0f, f, 0f, 0f,
            0f, 0f, f, 0f,
            0f, 0f, 0f, 1f)
    }
}

/** Filtre + texte (+ fondu + redimensionnement) d'un clip, dans cet ordre. */
@UnstableApi
fun videoEffects(
    c: Clip, fadeIn: Boolean = false, fadeOut: Boolean = false, maxHeight: Int? = null,
    context: Context? = null
): List<Effect> = buildList {
    when (c.filter) {
        Filter.NOIR -> add(RgbFilter.createGrayscaleFilter())
        Filter.INVERT -> add(RgbFilter.createInvertedFilter())
        Filter.WARM -> add(RgbAdjustment.Builder().setRedScale(1.12f).setBlueScale(0.85f).build())
        Filter.COOL -> add(RgbAdjustment.Builder().setRedScale(0.88f).setBlueScale(1.15f).build())
        Filter.VIVID -> add(HslAdjustment.Builder().adjustSaturation(35f).build())
        Filter.CONTRAST -> add(Contrast(0.35f))
        Filter.BRIGHT -> add(Brightness(0.15f))
        Filter.NONE -> {}
    }
    if (c.text.isNotBlank()) {
        val s = SpannableString(c.text)
        val flag = Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        s.setSpan(ForegroundColorSpan(Color.WHITE), 0, s.length, flag)
        s.setSpan(BackgroundColorSpan(0x99000000.toInt()), 0, s.length, flag)
        s.setSpan(AbsoluteSizeSpan(64, false), 0, s.length, flag)
        val settings = StaticOverlaySettings.Builder().setBackgroundFrameAnchor(0f, c.textPos.y).build()
        add(OverlayEffect(ImmutableList.of<TextureOverlay>(TextOverlay.createStaticTextOverlay(s, settings))))
    }
    c.logoUri?.let { uri ->
        if (context != null) {
            val bitmap = runCatching {
                context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            }.getOrNull()
            if (bitmap != null) {
                val x = c.logoPosition.x
                val settings = StaticOverlaySettings.Builder()
                    .setBackgroundFrameAnchor(x, 0.82f)
                    .setOverlayFrameAnchor(if (x < 0f) -1f else 1f, 1f)
                    .setScale(c.logoScale.coerceIn(0.08f, 0.45f), c.logoScale.coerceIn(0.08f, 0.45f))
                    .build()
                add(OverlayEffect(ImmutableList.of<TextureOverlay>(
                    BitmapOverlay.createStaticBitmapOverlay(bitmap, settings)
                )))
            }
        }
    }
    if (fadeIn || fadeOut) add(FadeMatrix(c.lengthMs * 1000, fadeIn, fadeOut))
    maxHeight?.let { add(Presentation.createForHeight(it)) }
}
