package com.example.mydm.ui

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.mydm.App
import com.example.mydm.core.*
import com.example.mydm.downloader.DownloadService
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DownloadSheet(found: SnapshotStateList<DetectedMedia>, pageUrl: String, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val app = ctx.applicationContext as App
    val scope = rememberCoroutineScope()

    var link by remember { mutableStateOf(if (MediaResolver.isSupportedPage(pageUrl)) pageUrl else "") }
    var loading by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf<YtInfo?>(null) }
    var infoUrl by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var expanded by remember { mutableStateOf<String?>(null) }
    val sizes = remember { mutableStateMapOf<String, Long?>() }
    val ytState by app.ytState.collectAsState()

    fun analyze() {
        val u = link.trim()
        if (u.isEmpty()) return
        loading = true; error = null; info = null
        scope.launch {
            runCatching { MediaResolver.ytInfo(app, u) }
                .onSuccess { info = it; infoUrl = u }
                .onFailure { error = (it.message ?: "Analyse impossible").take(240) }
            loading = false
        }
    }

    fun downloadYt(opt: QualityOption) {
        val i = info ?: return
        scope.launch {
            val id = app.downloadEngine.enqueueYt(infoUrl, i.title, opt)
            DownloadService.start(ctx, id)
            Toast.makeText(ctx, "Téléchargement ajouté", Toast.LENGTH_SHORT).show()
            onDismiss()
        }
    }

    fun downloadDirect(m: DetectedMedia) {
        scope.launch {
            DownloadActions.queue(ctx, app, m)
            found.remove(m)
            Toast.makeText(ctx, "Téléchargement ajouté", Toast.LENGTH_SHORT).show()
            onDismiss()
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = Bg
    ) {
        LazyColumn(
            Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item { Text("Télécharger", color = Color.White, fontSize = 20.sp) }

            // ── Lien YouTube / Facebook / TikTok
            item {
                Column(Modifier.fillMaxWidth().glass().padding(12.dp)) {
                    Text("Lien vidéo (YouTube, Facebook, TikTok…)", color = Muted, fontSize = 12.sp)
                    OutlinedTextField(link, { link = it }, Modifier.fillMaxWidth(), singleLine = true,
                        placeholder = { Text("Collez un lien ici") })
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button({ analyze() }, enabled = link.isNotBlank() && !loading) { Text("Analyser") }
                        Spacer(Modifier.width(10.dp))
                        if (ytState == "loading") Text("Moteur en préparation…", color = Muted, fontSize = 11.sp)
                        else if (ytState.startsWith("error:")) Text("Moteur indisponible", color = Color(0xFFFF8A80), fontSize = 11.sp)
                    }
                }
            }
            if (loading) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
            error?.let { e -> item { Text(e, color = Color(0xFFFF8A80), fontSize = 12.sp) } }

            info?.let { i ->
                item { Text(i.title + (i.uploader?.let { " — $it" } ?: ""), color = Accent, maxLines = 2, overflow = TextOverflow.Ellipsis) }
                items(i.options) { o ->
                    Row(Modifier.fillMaxWidth().glass().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(o.label, color = Color.White)
                            Text(o.sizeBytes?.let { (if (o.approx) "~" else "") + formatSize(it) } ?: "taille inconnue",
                                color = Muted, fontSize = 12.sp)
                        }
                        Button({ downloadYt(o) }) { Text("Télécharger") }
                    }
                }
            }

            // ── Médias détectés dans la page
            item { Text("Médias détectés (${found.size})", color = Color.White, modifier = Modifier.padding(top = 8.dp)) }
            if (found.isEmpty()) item {
                Text("Lancez une vidéo dans la page : elle apparaîtra ici.", color = Muted, fontSize = 12.sp)
            }
            items(found.toList(), key = { it.url }) { m ->
                Column(
                    Modifier.fillMaxWidth().glass().clickable {
                        expanded = if (expanded == m.url) null else m.url
                        if (expanded == m.url && m.sizeBytes == null && m.url !in sizes) {
                            scope.launch { sizes[m.url] = MediaResolver.probeSize(m) }
                        }
                    }.padding(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(m.type.name, color = Accent, fontSize = 11.sp, modifier = Modifier.width(64.dp))
                        Text(m.displayName(), color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                    }
                    if (expanded == m.url) {
                        val size = m.sizeBytes ?: sizes[m.url]
                        Spacer(Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                "Taille : " + (size?.let { formatSize(it) } ?: if (m.url in sizes) "inconnue" else "calcul…"),
                                color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f)
                            )
                            Button({ downloadDirect(m) }) { Text("Télécharger") }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}
