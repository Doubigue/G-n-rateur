package com.example.mydm.downloader

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.mydm.App
import com.example.mydm.MainActivity
import com.example.mydm.core.*
import kotlinx.coroutines.*

class DownloadService : Service() {
    private val engine get() = (application as App).downloadEngine
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    @Volatile private var started = false

    override fun onBind(i: Intent?) = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Téléchargements", NotificationManager.IMPORTANCE_LOW).apply { setShowBadge(true) })
        startForeground(NOTIF_ID, base().setContentTitle("MyDM").setContentText("Préparation…").build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        scope.launch {
            while (isActive) {
                delay(1000)
                val tasks = engine.activeTasks()
                val map = engine.progress.value
                val n = tasks.size
                if (started && n == 0 && engine.activeCount == 0) { stopSelf(); break }

                fun frac(t: DownloadTask): Float {
                    val p = map[t.id] ?: return 0f
                    return if (p.total > 0) (p.downloaded.toFloat() / p.total).coerceIn(0f, 1f) else 0f
                }
                val lines = tasks.take(Prefs.notifLines.coerceAtLeast(1)).map { t ->
                    val p = map[t.id]
                    val name = t.fileName.let { if (it.length > 34) it.take(31) + "…" else it }
                    val detail = when {
                        t.status == Status.MERGING -> "assemblage…"
                        p == null -> t.error ?: "en attente"
                        p.real && p.total > 0 -> "${(frac(t) * 100).toInt()}% • ${formatSize(p.downloaded)} / ${formatSize(p.total)}"
                        else -> "${(frac(t) * 100).toInt()}%" + if (t.totalBytes > 0) " • ${formatSize(t.totalBytes)}" else ""
                    }
                    "$name — $detail"
                }
                val speed = map.values.sumOf { it.speedBps }
                val avg = if (tasks.isEmpty()) 0 else (tasks.sumOf { frac(it).toDouble() } / tasks.size * 100).toInt()
                val style = NotificationCompat.InboxStyle().also { s -> lines.forEach { l -> s.addLine(l) } }
                    .setBigContentTitle("$n téléchargement${if (n > 1) "s" else ""} en cours • $avg%")
                    .also { if (n > lines.size) it.setSummaryText("+${n - lines.size} autre${if (n - lines.size > 1) "s" else ""}") }
                nm.notify(NOTIF_ID, base()
                    .setContentTitle("$n en cours • $avg% • ${speed / 1024} Ko/s")
                    .setContentText(lines.firstOrNull() ?: "")
                    .setStyle(style).setNumber(n)
                    .setProgress(100, avg, tasks.all { map[it.id] == null })
                    .addAction(0, "Tout mettre en pause", PendingIntent.getService(this@DownloadService, 1,
                        Intent(this@DownloadService, DownloadService::class.java).setAction(ACTION_PAUSE_ALL), PendingIntent.FLAG_IMMUTABLE))
                    .build())
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val id = intent?.getStringExtra(EXTRA_ID)
        when (intent?.action) {
            ACTION_START -> id?.let { engine.start(it); started = true }
            ACTION_PAUSE -> id?.let(engine::pause)
            ACTION_PAUSE_ALL -> engine.pauseAll()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() { scope.cancel() }

    private fun base() = NotificationCompat.Builder(this, CH).setSmallIcon(android.R.drawable.stat_sys_download)
        .setOngoing(true).setOnlyAlertOnce(true).setNumber(0)
        .setContentIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))

    companion object {
        const val CH = "downloads"; const val NOTIF_ID = 42
        const val ACTION_START = "start"; const val ACTION_PAUSE = "pause"; const val ACTION_PAUSE_ALL = "pause_all"; const val EXTRA_ID = "id"
        fun start(ctx: Context, taskId: String) = ContextCompat.startForegroundService(
            ctx, Intent(ctx, DownloadService::class.java).setAction(ACTION_START).putExtra(EXTRA_ID, taskId))
    }
}
