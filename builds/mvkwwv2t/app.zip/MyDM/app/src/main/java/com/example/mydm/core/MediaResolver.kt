package com.example.mydm.core

import android.net.Uri
import com.example.mydm.App
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.mapper.VideoFormat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

data class QualityOption(
    val label: String, val sizeBytes: Long?, val approx: Boolean,
    val selector: String, val mp3: Boolean = false
)

data class YtInfo(val title: String, val uploader: String?, val options: List<QualityOption>)

object MediaResolver {
    private val client = OkHttpClient.Builder().connectTimeout(10, TimeUnit.SECONDS).readTimeout(10, TimeUnit.SECONDS).build()

    private val supportedHosts = listOf("youtube.com", "youtu.be", "facebook.com", "fb.watch", "fb.com", "tiktok.com")

    fun isSupportedPage(url: String): Boolean {
        val host = Uri.parse(url).host?.lowercase() ?: return false
        return supportedHosts.any { host == it || host.endsWith(".$it") }
    }

    /** Taille d'un fichier direct (Content-Range / Content-Length). */
    suspend fun probeSize(m: DetectedMedia): Long? = withContext(Dispatchers.IO) {
        runCatching {
            val rb = Request.Builder().url(m.url).header("Range", "bytes=0-0").header("User-Agent", m.userAgent)
            m.referer?.let { rb.header("Referer", it) }
            m.cookies?.let { rb.header("Cookie", it) }
            client.newCall(rb.build()).execute().use { r ->
                r.header("Content-Range")?.substringAfter('/')?.toLongOrNull()
                    ?: if (r.code == 200) r.header("Content-Length")?.toLongOrNull() else null
            }
        }.getOrNull()
    }

    /** Analyse un lien YouTube / Facebook / TikTok / HLS avec yt-dlp et liste les qualités + tailles. */
    suspend fun ytInfo(app: App, url: String): YtInfo = withContext(Dispatchers.IO) {
        withTimeoutOrNull(90_000) { app.ytState.first { it != "loading" } }
            ?: error("Moteur en cours d'initialisation, réessayez dans un instant.")
        val st = app.ytState.value
        if (st.startsWith("error:")) error("Moteur indisponible : ${st.removePrefix("error:")}")

        val info = YoutubeDL.getInstance().getInfo(url)
        val fmts = info.formats.orEmpty()

        fun exact(f: VideoFormat): Long? = f.fileSize.takeIf { it > 0 } ?: f.fileSizeApproximate.takeIf { it > 0 }
        fun est(f: VideoFormat): Pair<Long?, Boolean> {
            exact(f)?.let { return it to false }
            return if (f.tbr > 0 && info.duration > 0) (f.tbr * 1000L / 8 * info.duration) to true else (null to false)
        }

        val videos = fmts.filter { it.height > 0 && it.vcodec != "none" }
        val audios = fmts.filter { it.vcodec == "none" && it.acodec != "none" }
        val bestAudio = audios.maxByOrNull { maxOf(it.abr, it.tbr) }
        val audioEst = bestAudio?.let { est(it) }

        val opts = mutableListOf<QualityOption>()
        videos.groupBy { it.height }.toSortedMap(compareByDescending<Int> { it }).entries.take(6).forEach { (h, group) ->
            val best = group.maxByOrNull { it.tbr } ?: group.first()
            val (s, approx) = est(best)
            val needsAudio = best.acodec == "none"
            val total = s?.plus(if (needsAudio) (audioEst?.first ?: 0L) else 0L)
            val fps = if (best.fps > 30) " ${best.fps}fps" else ""
            val ext = if (needsAudio) "MP4" else (best.ext ?: "mp4").uppercase()
            opts += QualityOption("${h}p$fps • $ext", total, approx || (needsAudio && audioEst?.second == true),
                "bv*[height<=$h][ext=mp4]+ba[ext=m4a]/bv*[height<=$h]+ba/b[height<=$h]")
        }
        if (opts.isEmpty()) {
            val sz = info.fileSize.takeIf { it > 0 } ?: info.fileSizeApproximate.takeIf { it > 0 }
            opts += QualityOption("Meilleure qualité", sz, false, "b/best")
        }
        if (bestAudio != null || videos.isNotEmpty()) {
            opts += QualityOption("Audio M4A", audioEst?.first, audioEst?.second ?: true, "ba[ext=m4a]/ba/b")
            opts += QualityOption("Audio MP3", audioEst?.first, true, "ba/b", mp3 = true)
        }
        YtInfo(info.title ?: info.fulltitle ?: "video", info.uploader, opts)
    }
}
