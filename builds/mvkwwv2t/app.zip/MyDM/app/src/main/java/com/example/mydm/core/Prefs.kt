package com.example.mydm.core

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray

enum class SearchEngine(val label: String, val template: String) {
    GOOGLE("Google", "https://www.google.com/search?q="),
    DUCKDUCKGO("DuckDuckGo", "https://duckduckgo.com/?q="),
    BING("Bing", "https://www.bing.com/search?q="),
    ECOSIA("Ecosia", "https://www.ecosia.org/search?q=")
}

/** Moteurs de recherche par photo : la page s'ouvre et la photo choisie est envoyée au bouton « importer ». */
enum class ImageEngine(val label: String, val url: String) {
    LENS("Google Lens", "https://lens.google.com/"),
    BING("Bing Visual", "https://www.bing.com/visualsearch"),
    TINEYE("TinEye", "https://tineye.com/"),
    YANDEX("Yandex", "https://yandex.com/images/")
}

/** Réglages de l'application (SharedPreferences + état Compose, donc l'UI se met à jour seule). */
object Prefs {
    const val DEFAULT_HOME = "https://www.google.com"
    lateinit var sp: SharedPreferences; private set

    // ── Navigateur
    var homeUrl by mutableStateOf(DEFAULT_HOME); private set
    var searchEngine by mutableStateOf(SearchEngine.GOOGLE); private set
    var imageEngine by mutableStateOf(ImageEngine.LENS); private set
    var desktopMode by mutableStateOf(false); private set
    var blockPopups by mutableStateOf(false); private set
    var restoreTabs by mutableStateOf(true); private set
    var jsEnabled by mutableStateOf(true); private set
    var loadImages by mutableStateOf(true); private set
    var textZoom by mutableIntStateOf(100); private set
    var blockAds by mutableStateOf(false); private set
    var externalNewTab by mutableStateOf(true); private set
    // ── Téléchargements
    var maxSegments by mutableIntStateOf(8); private set
    var maxParallel by mutableIntStateOf(3); private set
    var wifiOnly by mutableStateOf(false); private set
    var speedLimitKbps by mutableIntStateOf(0); private set     // 0 = illimité (par téléchargement)
    var rootFolder by mutableStateOf("MyDM"); private set
    var notifLines by mutableIntStateOf(5); private set
    var notifyDone by mutableStateOf(true); private set
    // ── Détection
    var detectVideo by mutableStateOf(true); private set
    var detectAudio by mutableStateOf(true); private set
    var detectFiles by mutableStateOf(true); private set
    // ── Développeur
    var captureConsole by mutableStateOf(true); private set
    var siteMaxMb by mutableIntStateOf(100); private set

    fun init(ctx: Context) {
        sp = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
        homeUrl = sp.getString("home", DEFAULT_HOME) ?: DEFAULT_HOME
        searchEngine = runCatching { SearchEngine.valueOf(sp.getString("engine", "GOOGLE")!!) }.getOrDefault(SearchEngine.GOOGLE)
        imageEngine = runCatching { ImageEngine.valueOf(sp.getString("imgEngine", "LENS")!!) }.getOrDefault(ImageEngine.LENS)
        desktopMode = sp.getBoolean("desktop", false)
        blockPopups = sp.getBoolean("blockPopups", false)
        restoreTabs = sp.getBoolean("restoreTabs", true)
        jsEnabled = sp.getBoolean("js", true)
        loadImages = sp.getBoolean("images", true)
        textZoom = sp.getInt("textZoom", 100)
        blockAds = sp.getBoolean("blockAds", false)
        externalNewTab = sp.getBoolean("externalNewTab", true)
        maxSegments = sp.getInt("segments", 8)
        maxParallel = sp.getInt("parallel", 3)
        wifiOnly = sp.getBoolean("wifiOnly", false)
        speedLimitKbps = sp.getInt("speedLimit", 0)
        rootFolder = sp.getString("root", "MyDM") ?: "MyDM"
        notifLines = sp.getInt("notifLines", 5)
        notifyDone = sp.getBoolean("notifyDone", true)
        detectVideo = sp.getBoolean("detVideo", true)
        detectAudio = sp.getBoolean("detAudio", true)
        detectFiles = sp.getBoolean("detFiles", true)
        captureConsole = sp.getBoolean("console", true)
        siteMaxMb = sp.getInt("siteMaxMb", 100)
    }

    private fun b(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()
    private fun i(k: String, v: Int) = sp.edit().putInt(k, v).apply()

    fun updateHomeUrl(v: String) {
        val t = v.trim().ifEmpty { DEFAULT_HOME }
        homeUrl = if (t.startsWith("http://") || t.startsWith("https://")) t else "https://$t"
        sp.edit().putString("home", homeUrl).apply()
    }
    fun updateSearchEngine(v: SearchEngine) { searchEngine = v; sp.edit().putString("engine", v.name).apply() }
    fun updateImageEngine(v: ImageEngine) { imageEngine = v; sp.edit().putString("imgEngine", v.name).apply() }
    fun updateDesktopMode(v: Boolean) { desktopMode = v; b("desktop", v) }
    fun updateBlockPopups(v: Boolean) { blockPopups = v; b("blockPopups", v) }
    fun updateRestoreTabs(v: Boolean) { restoreTabs = v; b("restoreTabs", v) }
    fun updateJs(v: Boolean) { jsEnabled = v; b("js", v) }
    fun updateLoadImages(v: Boolean) { loadImages = v; b("images", v) }
    fun updateTextZoom(v: Int) { textZoom = v; i("textZoom", v) }
    fun updateBlockAds(v: Boolean) { blockAds = v; b("blockAds", v) }
    fun updateExternalNewTab(v: Boolean) { externalNewTab = v; b("externalNewTab", v) }
    fun updateMaxSegments(v: Int) { maxSegments = v; i("segments", v) }
    fun updateMaxParallel(v: Int) { maxParallel = v; i("parallel", v) }
    fun updateWifiOnly(v: Boolean) { wifiOnly = v; b("wifiOnly", v) }
    fun updateSpeedLimit(v: Int) { speedLimitKbps = v; i("speedLimit", v) }
    fun updateRootFolder(v: String) {
        rootFolder = v.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifEmpty { "MyDM" }
        sp.edit().putString("root", rootFolder).apply()
    }
    fun updateNotifLines(v: Int) { notifLines = v; i("notifLines", v) }
    fun updateNotifyDone(v: Boolean) { notifyDone = v; b("notifyDone", v) }
    fun updateDetectVideo(v: Boolean) { detectVideo = v; b("detVideo", v) }
    fun updateDetectAudio(v: Boolean) { detectAudio = v; b("detAudio", v) }
    fun updateDetectFiles(v: Boolean) { detectFiles = v; b("detFiles", v) }
    fun updateCaptureConsole(v: Boolean) { captureConsole = v; b("console", v) }
    fun updateSiteMaxMb(v: Int) { siteMaxMb = v; i("siteMaxMb", v) }

    /** Transforme ce que tape l'utilisateur en URL : adresse, domaine ou recherche. */
    fun resolveInput(input: String): String {
        val t = input.trim()
        return when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            "." in t && " " !in t -> "https://$t"
            else -> searchEngine.template + android.net.Uri.encode(t)
        }
    }

    // ── Onglets ouverts (restaurés au démarrage si l'option est active)
    fun saveTabs(urls: List<String>, current: Int) {
        sp.edit().putString("tabs", JSONArray(urls).toString()).putInt("tabIndex", current).apply()
    }
    fun savedTabs(): List<String> = runCatching {
        val a = JSONArray(sp.getString("tabs", "[]"))
        List(a.length()) { a.getString(it) }.filter { it.startsWith("http") }
    }.getOrDefault(emptyList())
    fun savedTabIndex(): Int = sp.getInt("tabIndex", 0)
}
