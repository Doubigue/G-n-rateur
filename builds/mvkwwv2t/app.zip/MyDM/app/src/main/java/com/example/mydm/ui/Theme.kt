package com.example.mydm.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

val Bg = Color(0xFF0B0D12)
val Accent = Color(0xFF7CF5C8)
val Muted = Color(0xFFB0B8C8)

@Composable
fun MyDMTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Bg, onSurface = Color.White),
    content = content
)

/** Effet "glassmorphism" : dégradé translucide + liseré clair. */
fun Modifier.glass(): Modifier = this
    .clip(RoundedCornerShape(20.dp))
    .background(Brush.linearGradient(listOf(Color(0x33FFFFFF), Color(0x0DFFFFFF))))
    .border(1.dp, Color(0x40FFFFFF), RoundedCornerShape(20.dp))
