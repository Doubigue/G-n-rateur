package com.example.mydm.ui

import android.content.Intent
import android.net.Uri
import java.util.Date
import java.text.DateFormat
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.RoundedCornerShape
import android.view.ViewGroup
import androidx.compose.runtime.snapshots.SnapshotStateList
import android.util.Size
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.mydm.App
import com.example.mydm.browser.SnifferWebView
import com.example.mydm.core.*
import com.example.mydm.downloader.DownloadService
import com.example.mydm.torrent.TorrentFile
import com.example.mydm.torrent.TorrentService
import com.example.mydm.whatsapp.ScanResult
import com.example.mydm.whatsapp.StatusItem
import com.example.mydm.whatsapp.WaApp
import com.frostwire.jlibtorrent.TorrentInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable internal fun appInstance() = LocalContext.current.applicationContext as App

// ───────────── Statuts WhatsApp ─────────────
@Composable
fun StatusScreen() {
    val ctx = LocalContext.current; val repo = appInstance().statusRepo
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf(WaApp.WHATSAPP) }
    var scan by remember { mutableStateOf<ScanResult?>(null) }
    var granted by remember { mutableStateOf(repo.hasGrant(tab)) }
    var loading by remember { mutableStateOf(false) }
    var reload by remember { mutableIntStateOf(0) }

    LaunchedEffect(tab, reload) {
        granted = repo.hasGrant(tab)
        scan = null
        if (granted) {
            loading = true
            scan = runCatching { repo.scan(tab) }.getOrElse { ScanResult(emptyList(), "Erreur : ${it.message}") }
            loading = false
        }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) { repo.persistGrant(tab, uri); reload++ }
    }

    Column(Modifier.fillMaxSize()) {
        TabRow(WaApp.entries.indexOf(tab), containerColor = Bg) {
            WaApp.entries.forEach { a -> Tab(tab == a, { tab = a }, text = { Text(a.label) }) }
        }
        val s = scan ?: ScanResult(emptyList(), "")
        when {
            !granted -> Centered("Autorisez l'accès au dossier Android/media/${tab.pkg}\n(appuyez sur « Utiliser ce dossier »)") {
                Button({ picker.launch(repo.initialUri(tab)) }) { Text("Autoriser l'accès") }
            }
            loading || scan == null -> Centered("Recherche des statuts…")
            s.items.isEmpty() -> Centered(s.message) {
                Row {
                    Button({ reload++ }) { Text("Actualiser") }
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton({ picker.launch(repo.initialUri(tab)) }) { Text("Changer de dossier") }
                }
            }
            else -> LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    Row {
                        TextButton({ reload++ }) { Text("Actualiser (${s.items.size})") }
                        TextButton({ picker.launch(repo.initialUri(tab)) }) { Text("Changer de dossier") }
                    }
                }
                if (s.info.isNotBlank()) item { Text(s.info, color = Muted, fontSize = 11.sp) }
                items(s.items, key = { it.uri.toString() }) { st ->
                    val thumb by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, st.uri) {
                        value = withContext(Dispatchers.IO) {
                            runCatching { ctx.contentResolver.loadThumbnail(st.uri, Size(256, 256), null).asImageBitmap() }.getOrNull()
                        }
                    }
                    Row(Modifier.fillMaxWidth().glass().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(72.dp).background(Color(0x22FFFFFF))) {
                            thumb?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
                        }
                        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                            Text(if (st.isVideo) "Vidéo" else "Photo", color = Accent)
                            Text("${st.size / 1024} Ko • ${fmtDate(st.modified)}", color = Muted, fontSize = 12.sp)
                        }
                        Button({
                            scope.launch {
                                runCatching { repo.save(st) }
                                    .onSuccess { Toast.makeText(ctx, "Enregistré dans ${Prefs.rootFolder}/Vidéo made/Statuts", Toast.LENGTH_SHORT).show() }
                                    .onFailure { Toast.makeText(ctx, "Échec : ${it.message}", Toast.LENGTH_LONG).show() }
                            }
                        }) { Text("Enregistrer") }
                    }
                }
            }
        }
    }
}

// ───────────── Torrent ─────────────
@Composable
fun TorrentScreen() {
    val ctx = LocalContext.current; val engine = appInstance().torrentEngine
    val scope = rememberCoroutineScope()
    val states by engine.states.collectAsStateWithLifecycle()
    var source by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<TorrentInfo?>(null) }
    var files by remember { mutableStateOf<List<TorrentFile>>(emptyList()) }
    var selected by remember { mutableStateOf<Set<Int>>(emptySet()) }

    fun inspect(src: String) = scope.launch {
        busy = true
        runCatching { engine.inspect(src) }
            .onSuccess { ti -> pending = ti; files = engine.listFiles(ti); selected = files.map { it.index }.toSet() }
            .onFailure { Toast.makeText(ctx, "Erreur : ${it.message}", Toast.LENGTH_LONG).show() }
        busy = false
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { inspect(it.toString()) }
    }
    // Lien magnet / fichier .torrent reçu d'une autre application
    LaunchedEffect(Incoming.torrent) {
        Incoming.torrent?.let { source = if (it.startsWith("magnet:")) it else source; inspect(it); Incoming.torrent = null }
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Column(Modifier.fillMaxWidth().glass().padding(14.dp)) {
                OutlinedTextField(source, { source = it }, Modifier.fillMaxWidth(), label = { Text("Lien magnet:?xt=urn:btih:…") })
                Row {
                    Button({ inspect(source.trim()) }, enabled = source.startsWith("magnet:") && !busy) { Text("Analyser") }
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton({ picker.launch(arrayOf("*/*")) }, enabled = !busy) { Text("Fichier .torrent") }
                }
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))
            }
        }
        pending?.let { ti ->
            item {
                Column(Modifier.fillMaxWidth().glass().padding(14.dp)) {
                    Text(ti.name(), color = Color.White)
                    files.forEach { f ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(f.index in selected, { c -> selected = if (c) selected + f.index else selected - f.index })
                            Text("${f.path}  (${f.size / 1_048_576} Mo)", color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
                        }
                    }
                    Button({
                        engine.download(ti, selected); TorrentService.start(ctx); pending = null
                    }, enabled = selected.isNotEmpty()) { Text("Télécharger") }
                }
            }
        }
        items(states.values.toList(), key = { it.infoHash }) { s ->
            Column(Modifier.fillMaxWidth().glass().padding(14.dp)) {
                Text(s.name, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                LinearProgressIndicator({ s.progress }, Modifier.fillMaxWidth().padding(vertical = 8.dp))
                Text("${(s.progress * 100).toInt()}% • ${s.state} • ↓ ${s.downloadRate / 1024} Ko/s • ↑ ${s.uploadRate / 1024} Ko/s • ${s.peers} pairs",
                    color = Muted, fontSize = 12.sp)
                Row {
                    TextButton({ engine.pause(s.infoHash) }) { Text("Pause") }
                    TextButton({ engine.resume(s.infoHash) }) { Text("Reprendre") }
                    TextButton({ engine.remove(s.infoHash) }) { Text("Retirer") }
                }
            }
        }
    }
}

@Composable
internal fun Centered(text: String, extra: @Composable () -> Unit = {}) =
    Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Text(text, color = Muted); Spacer(Modifier.height(12.dp)); extra()
    }

private fun fmtDate(ms: Long): String =
    if (ms <= 0) "date inconnue" else DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(ms))
