package com.example.mydm.downloader

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.core.app.NotificationCompat
import com.example.mydm.MainActivity
import com.example.mydm.core.*
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import okhttp3.*
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** [real] = false : « total » est fictif (yt-dlp, archive de site) → on affiche le % mais pas de taille. */
data class Progress(val downloaded: Long, val total: Long, val speedBps: Long, val real: Boolean = true)

class DownloadEngine(
    private val context: Context,
    private val dao: DownloadDao,
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build()
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val jobs = ConcurrentHashMap<String, Job>()
    private val _progress = MutableStateFlow<Map<String, Progress>>(emptyMap())
    val progress: StateFlow<Map<String, Progress>> = _progress
    val activeCount get() = jobs.values.count { it.isActive }

    private val partsDir get() = File(context.getExternalFilesDir(null), "parts").apply { mkdirs() }
    private fun part(id: String, i: Int) = File(partsDir, "$id.part$i")

    // ── File d'attente : N téléchargements simultanés max, option « Wi-Fi uniquement »
    private val lock = Any()
    private var running = 0
    private fun tryAcquire() = synchronized(lock) { if (running < Prefs.maxParallel) { running++; true } else false }
    private fun release() = synchronized(lock) { if (running > 0) running-- }

    private fun networkState(): String? {   // null = OK, sinon raison de l'attente
        val cm = context.getSystemService(ConnectivityManager::class.java)
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return "En attente du réseau…"
        if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) return "En attente du réseau…"
        if (Prefs.wifiOnly && !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)) return "En attente du Wi-Fi…"
        return null
    }

    fun start(id: String) {
        if (jobs[id]?.isActive == true) return
        jobs[id] = scope.launch {
            var acquired = false
            try {
                dao.setStatus(id, Status.QUEUED, null)
                var lastMsg: String? = null
                while (true) {
                    val wait = networkState()
                    if (wait == null && tryAcquire()) { acquired = true; break }
                    val msg = wait ?: "En file d'attente…"
                    if (msg != lastMsg) { dao.setStatus(id, Status.QUEUED, msg); lastMsg = msg }
                    delay(700)
                }
                runTask(id)
            } catch (e: CancellationException) {
                withContext(NonCancellable) { dao.setStatus(id, Status.PAUSED, null) }
                _progress.update { it - id }
                throw e
            } catch (e: Exception) {
                dao.setStatus(id, Status.FAILED, friendlyError(e.message))
                _progress.update { it - id }
            } finally { if (acquired) release() }
        }
    }

    fun pause(id: String) { jobs.remove(id)?.cancel() }   // les .part restent => reprise possible
    fun pauseAll() { jobs.keys.toList().forEach(::pause) }

    fun cancel(id: String) {
        pause(id)
        scope.launch {
            partsDir.listFiles { f -> f.name.startsWith(id) }?.forEach { it.delete() }
            File(context.getExternalFilesDir(null), "ytdlp/$id").deleteRecursively()
            File(context.getExternalFilesDir(null), "site/$id").deleteRecursively()
            dao.deleteSegments(id); dao.delete(id)
        }
    }

    suspend fun activeTasks(): List<DownloadTask> = dao.active()

    private fun friendlyError(m: String?): String {
        val s = m ?: return "Erreur inconnue"
        return when {
            "Errno 7" in s || "No address associated" in s || "UnknownHost" in s || "Unable to resolve host" in s ->
                "Pas d'accès Internet (DNS). Vérifiez le Wi-Fi / les données (ou le DNS privé / VPN), puis « Reprendre »."
            "timeout" in s.lowercase() || "timed out" in s.lowercase() -> "Délai dépassé : connexion trop lente. Réessayez."
            "HTTP 403" in s -> "Accès refusé par le serveur (403). Rouvrez la page puis relancez le téléchargement."
            "HTTP 404" in s -> "Fichier introuvable (404)."
            else -> s.take(300)
        }
    }

    // ───────────── Création des tâches
    /** Crée la tâche en base (headers rejoués : UA, cookies, referer). */
    suspend fun enqueue(m: DetectedMedia): String {
        val headers = JSONObject().apply {
            put("User-Agent", m.userAgent)
            m.cookies?.let { put("Cookie", it) }
            m.referer?.let { put("Referer", it) }
        }.toString()
        val task = DownloadTask(url = m.url, fileName = fileNameFor(m),
            mimeType = null, headersJson = headers, maxSegments = Prefs.maxSegments)
        dao.upsert(task)
        return task.id
    }

    /** Tâche gérée par yt-dlp : page YouTube/Facebook/TikTok ou flux HLS. */
    suspend fun enqueueYt(pageUrl: String, title: String, opt: QualityOption, referer: String? = null): String {
        val h = JSONObject().put("ytdlpFormat", opt.selector).put("ytdlpMp3", opt.mp3)
        referer?.let { h.put("ytdlpReferer", it) }
        val q = opt.label.substringBefore(" •")
        val task = DownloadTask(url = pageUrl, fileName = cleanName("$title [$q]").ifBlank { "video" },
            mimeType = null, headersJson = h.toString())
        dao.upsert(task)
        return task.id
    }

    /** Archive ZIP d'un site : HTML (source + DOM rendu), CSS, JS, images, polices… + journal de la console. */
    suspend fun enqueueSite(pageUrl: String, title: String, ua: String, cookies: String?, dom: String, console: String): String =
        withContext(Dispatchers.IO) {
            val host = pageUrl.toHttpUrlOrNull()?.host ?: "site"
            val task = DownloadTask(url = pageUrl, fileName = cleanName("Site $host - ${title.ifBlank { "page" }}").take(100) + ".zip",
                mimeType = "application/zip",
                headersJson = JSONObject().put("siteZip", true).put("User-Agent", ua).apply { cookies?.let { put("Cookie", it) } }.toString())
            val dir = File(context.getExternalFilesDir(null), "site/${task.id}").apply { mkdirs() }
            File(dir, "rendered.html").writeText(dom)
            File(dir, "console.txt").writeText(console)
            dao.upsert(task)
            task.id
        }

    // ───────────── yt-dlp
    private suspend fun runYtDlp(task: DownloadTask) {
        val id = task.id
        val o = JSONObject(task.headersJson)
        val dir = File(context.getExternalFilesDir(null), "ytdlp/$id").apply { mkdirs() }
        dao.setStatus(id, Status.RUNNING, null)

        val req = YoutubeDLRequest(task.url).apply {
            addOption("-f", o.getString("ytdlpFormat"))
            addOption("--no-playlist")
            addOption("-N", 4)
            addOption("-o", dir.absolutePath + "/out.%(ext)s")
            if (o.optBoolean("ytdlpMp3")) { addOption("-x"); addOption("--audio-format", "mp3") }
            else addOption("--merge-output-format", "mp4")
            o.optString("ytdlpReferer").takeIf { it.isNotEmpty() }?.let { addOption("--referer", it) }
        }
        val handle = currentCoroutineContext()[Job]!!.invokeOnCompletion { YoutubeDL.getInstance().destroyProcessById(id) }
        try {
            var attempt = 0
            while (true) {
                try {
                    YoutubeDL.getInstance().execute(req, id) { p, _, _ ->
                        _progress.update { it + (id to Progress((p.coerceIn(0f, 100f) * 10).toLong(), 1000, 0, real = false)) }
                    }
                    break
                } catch (e: Exception) {
                    if (!currentCoroutineContext().isActive) throw CancellationException("pause")
                    val dnsLike = e.message?.let { "Errno 7" in it || "No address associated" in it } == true
                    if (!dnsLike || ++attempt > 3) throw e
                    dao.setStatus(id, Status.RUNNING, "Nouvelle tentative ($attempt/3)…")
                    delay(3000L * attempt)
                }
            }
        } finally { handle.dispose() }

        val out = dir.listFiles()
            ?.filter { it.isFile && it.name.startsWith("out.") && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") }
            ?.maxByOrNull { it.length() } ?: error("Fichier de sortie introuvable")
        dao.setStatus(id, Status.MERGING, null)
        val name = cleanName(task.fileName) + "." + out.extension
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(out.extension)
        val uri = saveToLibrary(out, name, mime)
        dao.upsert(dao.task(id)!!.copy(fileName = name, mimeType = mime, status = Status.COMPLETED, resultUri = uri.toString(), error = null))
        dir.deleteRecursively()
        _progress.update { it - id }
        done(name, true)
    }

    /** Copie un fichier terminé dans Download/<racine>/<catégorie>. */
    private fun saveToLibrary(file: File, name: String, mime: String?): Uri {
        val uri = Storage.create(context, name, mime, Storage.rel(categoryFor(name, mime)))
        context.contentResolver.openOutputStream(uri)!!.use { out -> file.inputStream().use { it.copyTo(out, 256 * 1024) } }
        Storage.finish(context, uri)
        return uri
    }

    // ───────────── Téléchargement direct multi-segments
    private suspend fun runTask(id: String) {
        val task = dao.task(id) ?: return
        if (task.headersJson.contains("ytdlpFormat")) { runYtDlp(task); return }
        if (task.headersJson.contains("siteZip")) { runSite(task); return }
        val headers = task.headersJson.toHeaders()
        dao.setStatus(id, Status.RUNNING, null)

        var segs = dao.segments(id)
        var total = task.totalBytes
        if (segs.isEmpty()) {
            val probe = probe(task.url, headers)
            total = probe.length
            segs = plan(id, probe, task.maxSegments)
            dao.insertSegments(segs)
            dao.upsert(task.copy(totalBytes = total, status = Status.RUNNING))
        }
        val ranged = total > 0 && segs.first().end >= 0

        val ticker = scope.launch {
            var last = segs.sumOf { part(id, it.idx).length() }; var lastT = System.nanoTime()
            while (isActive) {
                delay(500)
                val done = segs.sumOf { part(id, it.idx).length() }
                val now = System.nanoTime()
                val speed = ((done - last) * 1_000_000_000L) / (now - lastT).coerceAtLeast(1)
                last = done; lastT = now
                _progress.update { it + (id to Progress(done, total, speed)) }
            }
        }
        try {
            coroutineScope { segs.map { s -> async { downloadSegment(task.url, headers, id, s, ranged, segs.size) } }.awaitAll() }
        } finally { ticker.cancel() }

        dao.setStatus(id, Status.MERGING, null)
        val uri = merge(task, segs)
        dao.upsert(dao.task(id)!!.copy(status = Status.COMPLETED, resultUri = uri.toString(), error = null))
        _progress.update { it - id }
        done(task.fileName, true)
    }

    private data class Probe(val length: Long, val acceptsRanges: Boolean)

    private fun probe(url: String, headers: Headers): Probe {
        val req = Request.Builder().url(url).headers(headers).header("Range", "bytes=0-0").build()
        client.newCall(req).execute().use { r ->
            return when {
                r.code == 206 -> {
                    val total = r.header("Content-Range")?.substringAfter('/')?.toLongOrNull() ?: -1
                    Probe(total, total > 0)
                }
                r.isSuccessful -> Probe(r.header("Content-Length")?.toLongOrNull() ?: -1, false)
                else -> throw IOException("HTTP ${r.code}")
            }
        }
    }

    private fun plan(id: String, p: Probe, maxSeg: Int): List<Segment> {
        if (!p.acceptsRanges || p.length <= 0) return listOf(Segment(id, 0, 0, -1))
        val n = if (p.length < 1_000_000) 1 else maxSeg
        val size = p.length / n
        return (0 until n).map { i ->
            Segment(id, i, i * size, if (i == n - 1) p.length - 1 else (i + 1) * size - 1)
        }
    }

    private suspend fun downloadSegment(url: String, headers: Headers, id: String, s: Segment, ranged: Boolean, segCount: Int) {
        val file = part(id, s.idx)
        var attempt = 0
        while (true) {
            try {
                val already = if (ranged && file.exists()) file.length() else 0L
                if (ranged && s.start + already > s.end) return          // segment déjà complet

                val rb = Request.Builder().url(url).headers(headers)
                if (ranged) rb.header("Range", "bytes=${s.start + already}-${s.end}")
                val call = client.newCall(rb.build())
                val h = currentCoroutineContext()[Job]!!.invokeOnCompletion { call.cancel() }
                try {
                    call.execute().use { r ->
                        if (ranged && r.code != 206) throw IOException("Range non respecté (${r.code})")
                        if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
                        // Limite de vitesse : budget réparti entre les segments
                        val cap = if (Prefs.speedLimitKbps > 0) Prefs.speedLimitKbps * 1024L / segCount else 0L
                        val t0 = System.nanoTime(); var sent = 0L
                        FileOutputStream(file, ranged).use { out ->
                            val buf = ByteArray(64 * 1024)
                            val input = r.body!!.byteStream()
                            while (true) {
                                currentCoroutineContext().ensureActive()
                                val n = input.read(buf); if (n < 0) break
                                out.write(buf, 0, n)
                                if (cap > 0) {
                                    sent += n
                                    val wait = sent * 1000 / cap - (System.nanoTime() - t0) / 1_000_000
                                    if (wait > 0) delay(wait)
                                }
                            }
                        }
                    }
                } finally { h.dispose() }
                return
            } catch (e: CancellationException) { throw e }
            catch (e: IOException) {
                if (++attempt >= 5) throw e
                delay(1000L * attempt)
            }
        }
    }

    private fun merge(task: DownloadTask, segs: List<Segment>): Uri {
        val uri = Storage.create(context, task.fileName, task.mimeType, Storage.rel(categoryFor(task.fileName, task.mimeType)))
        context.contentResolver.openOutputStream(uri)!!.use { out ->
            segs.sortedBy { it.idx }.forEach { s ->
                part(task.id, s.idx).inputStream().use { it.copyTo(out, 256 * 1024) }
            }
        }
        Storage.finish(context, uri)
        segs.forEach { part(task.id, it.idx).delete() }
        return uri
    }

    // ───────────── Archive ZIP d'un site web
    private val tagRe = Regex("<(script|link|img|source|video|audio|iframe)\\b[^>]*>", RegexOption.IGNORE_CASE)
    private val attrRe = Regex("\\b(src|href|data-src|poster|srcset)\\s*=\\s*([\"'])(.*?)\\2", RegexOption.IGNORE_CASE)
    private val cssUrlRe = Regex("url\\(\\s*['\"]?([^)'\"]+?)['\"]?\\s*\\)", RegexOption.IGNORE_CASE)
    private val cssImportRe = Regex("@import\\s+['\"]([^'\"]+)['\"]", RegexOption.IGNORE_CASE)

    private fun resolveUrl(base: String, raw: String): String? {
        val r = raw.trim()
        if (r.isEmpty() || r.startsWith("#") || r.startsWith("data:") || r.startsWith("javascript:") ||
            r.startsWith("mailto:") || r.startsWith("blob:") || r.startsWith("about:")) return null
        return base.toHttpUrlOrNull()?.resolve(r)?.toString()?.substringBefore('#')
    }

    /** Applique [f] à chaque URL de ressource trouvée dans les balises (src, href des <link>, srcset, poster). */
    private fun mapTags(html: String, f: (String) -> String): String = tagRe.replace(html) { tag ->
        val isLink = tag.groupValues[1].equals("link", true)
        val relOk = !isLink || Regex("rel\\s*=\\s*[\"'][^\"']*(stylesheet|icon|preload|manifest)", RegexOption.IGNORE_CASE).containsMatchIn(tag.value)
        val isMedia = tag.groupValues[1].lowercase().let { it == "video" || it == "audio" || it == "iframe" }
        if (!relOk) tag.value else attrRe.replace(tag.value) { a ->
            val name = a.groupValues[1].lowercase(); val q = a.groupValues[2]; val v = a.groupValues[3]
            when {
                isMedia && name != "poster" -> a.value                      // pas de vidéo/iframe dans l'archive
                name == "srcset" -> "srcset=$q" + v.split(",").joinToString(",") { c ->
                    val t = c.trim().split(Regex("\\s+"), 2); " " + f(t[0]) + (t.getOrNull(1)?.let { " $it" } ?: "")
                }.trim() + q
                else -> "${a.groupValues[1]}=$q${f(v)}$q"
            }
        }
    }

    private fun localPath(abs: String, taken: MutableSet<String>): String {
        val u = abs.toHttpUrlOrNull()!!
        var p = u.encodedPath.trim('/').ifEmpty { "index" }
        if (u.encodedPath.endsWith("/")) p += "/index"
        var name = Uri.decode(u.host + "/" + p)
        u.query?.let { q ->
            val ext = name.substringAfterLast('.', "").takeIf { it.length in 1..5 && '/' !in it }
            val h = Integer.toHexString(q.hashCode())
            name = if (ext != null) name.removeSuffix(".$ext") + "_$h.$ext" else name + "_$h"
        }
        name = name.replace(Regex("[^A-Za-z0-9._/-]"), "_")
        if (name.substringAfterLast('/').let { !it.contains('.') }) name += ".bin"
        var path = "assets/$name"; var n = 1
        while (!taken.add(path)) path = "assets/" + name.substringBeforeLast('.') + "_${n++}." + name.substringAfterLast('.')
        return path
    }

    private fun relative(fromFile: String, toFile: String): String {
        val from = java.nio.file.Paths.get(fromFile).parent ?: java.nio.file.Paths.get("")
        return from.relativize(java.nio.file.Paths.get(toFile)).toString().replace('\\', '/')
    }

    private suspend fun runSite(task: DownloadTask) {
        val id = task.id
        val o = JSONObject(task.headersJson)
        val ua = o.optString("User-Agent"); val cookie = o.optString("Cookie")
        val base = task.url
        val work = File(context.getExternalFilesDir(null), "site/$id")
        dao.setStatus(id, Status.RUNNING, null)

        fun req(u: String) = Request.Builder().url(u).header("User-Agent", ua)
            .header("Referer", base).apply { if (cookie.isNotEmpty()) header("Cookie", cookie) }.build()

        val source = client.newCall(req(base)).execute().use { r ->
            if (!r.isSuccessful) throw IOException("HTTP ${r.code}"); r.body!!.string()
        }
        val dom = File(work, "rendered.html").takeIf { it.exists() }?.readText()?.takeIf { it.length > 200 } ?: source
        val consoleLog = File(work, "console.txt").takeIf { it.exists() }?.readText().orEmpty()

        // 1) Découverte des ressources du DOM rendu (JS exécuté) + url() des styles inline
        val found = LinkedHashMap<String, String>()          // url absolue -> chemin local
        val taken = HashSet<String>()
        fun register(abs: String?): String? {
            abs ?: return null
            return found.getOrPut(abs) { localPath(abs, taken) }
        }
        mapTags(dom) { v -> register(resolveUrl(base, v)); v }
        cssUrlRe.findAll(dom).forEach { register(resolveUrl(base, it.groupValues[1])) }

        // 2) Téléchargement (8 en parallèle), CSS analysés pour leurs url()/@import
        val maxBytes = Prefs.siteMaxMb * 1_048_576L
        val files = LinkedHashMap<String, ByteArray>()        // chemin local -> contenu
        val failed = mutableListOf<String>()
        var totalBytes = 0L
        var processed = 0
        val queue = ArrayDeque(found.keys.toList())
        val seenAbs = HashSet(found.keys)
        val gate = kotlinx.coroutines.sync.Semaphore(8)
        val startT = System.nanoTime()
        while (queue.isNotEmpty() && files.size < 500 && totalBytes < maxBytes) {
            val batch = List(minOf(16, queue.size)) { queue.removeFirst() }
            coroutineScope {
                batch.map { abs ->
                    async {
                        gate.acquire()
                        try {
                            val bytes = runCatching {
                                client.newCall(req(abs)).execute().use { r ->
                                    if (!r.isSuccessful) error("HTTP ${r.code}")
                                    r.body!!.bytes() to (r.header("Content-Type") ?: "")
                                }
                            }.getOrNull()
                            synchronized(files) {
                                if (bytes == null) failed += abs
                                else {
                                    val (data, ct) = bytes
                                    var out = data
                                    val local = found[abs]!!
                                    if (local.endsWith(".css") || ct.contains("text/css")) {
                                        // découvrir puis réécrire les url() du CSS
                                        var css = data.toString(Charsets.UTF_8)
                                        val refs = (cssUrlRe.findAll(css).map { it.groupValues[1] } + cssImportRe.findAll(css).map { it.groupValues[1] }).toSet()
                                        refs.forEach { raw ->
                                            val a = resolveUrl(abs, raw) ?: return@forEach
                                            val lp = register(a)!!
                                            if (seenAbs.add(a)) queue.addLast(a)
                                            css = css.replace(raw, relative(local, lp))
                                        }
                                        out = css.toByteArray(Charsets.UTF_8)
                                    }
                                    files[local] = out; totalBytes += out.size
                                }
                                processed++
                            }
                        } finally { gate.release() }
                    }
                }.awaitAll()
            }
            val all = processed + queue.size
            val speed = (totalBytes * 1_000_000_000L) / (System.nanoTime() - startT).coerceAtLeast(1)
            _progress.update { it + (id to Progress((processed * 1000L / all.coerceAtLeast(1)), 1000, speed, real = false)) }
        }

        // 3) Réécriture du HTML puis écriture du ZIP
        dao.setStatus(id, Status.MERGING, null)
        var index = mapTags(dom) { v -> resolveUrl(base, v)?.let { found[it] }?.takeIf { it in files } ?: v }
        index = cssUrlRe.replace(index) { m ->
            val local = resolveUrl(base, m.groupValues[1])?.let { found[it] }?.takeIf { it in files }
            if (local != null) "url($local)" else m.value
        }
        val uri = Storage.create(context, task.fileName, "application/zip", Storage.rel(Category.AUTRES, "Sites"))
        ZipOutputStream(context.contentResolver.openOutputStream(uri)!!.buffered()).use { z ->
            fun put(name: String, data: ByteArray) { z.putNextEntry(ZipEntry(name)); z.write(data); z.closeEntry() }
            put("index.html", index.toByteArray())
            put("source.html", source.toByteArray())
            if (consoleLog.isNotBlank()) put("console.txt", consoleLog.toByteArray())
            files.forEach { (n, d) -> put(n, d) }
            put("_info.txt", ("URL : $base\nFichiers : ${files.size}\nTaille : ${formatSize(totalBytes)}\n" +
                "Échecs : ${failed.size}\n" + failed.joinToString("\n")).toByteArray())
        }
        Storage.finish(context, uri)
        dao.upsert(dao.task(id)!!.copy(status = Status.COMPLETED, resultUri = uri.toString(), totalBytes = totalBytes, error = null))
        work.deleteRecursively()
        _progress.update { it - id }
        done(task.fileName, true)
    }

    // ───────────── Notification de fin
    private fun done(name: String, ok: Boolean) {
        if (!Prefs.notifyDone) return
        val nm = context.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("done", "Téléchargements terminés", NotificationManager.IMPORTANCE_DEFAULT))
        val pi = PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        nm.notify(name.hashCode(), NotificationCompat.Builder(context, "done").setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle(if (ok) "Téléchargement terminé" else "Échec").setContentText(name)
            .setContentIntent(pi).setAutoCancel(true).build())
    }

    private fun String.toHeaders(): Headers {
        val b = Headers.Builder(); val o = JSONObject(this)
        o.keys().forEach { b.add(it, o.getString(it)) }; return b.build()
    }
}
