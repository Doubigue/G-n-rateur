package com.example.mydm.ui

import android.content.Context
import com.example.mydm.App
import com.example.mydm.core.*
import com.example.mydm.downloader.DownloadService

object DownloadActions {
    /** Met un média détecté en file d'attente (direct ou HLS via yt-dlp) et lance le service. */
    suspend fun queue(ctx: Context, app: App, m: DetectedMedia) {
        val id = if (m.type == MediaType.HLS)
            app.downloadEngine.enqueueYt(m.url, m.displayName(), QualityOption("HLS", null, false, "b"), m.referer)
        else app.downloadEngine.enqueue(m)
        DownloadService.start(ctx, id)
    }
}
