extends Node
# Sons et musique générés par code, sans fichier audio (autoload "Sfx").

const RATE := 22050
const MUSIC_RATE := 16000

var _streams := {}
var _players: Array = []
var _next: int = 0
var _music: AudioStreamPlayer
var _thread: Thread


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for i in 8:
		var p := AudioStreamPlayer.new()
		add_child(p)
		_players.append(p)
	_music = AudioStreamPlayer.new()
	add_child(_music)
	_build_sfx()
	Settings.changed.connect(_on_setting)
	_thread = Thread.new()
	_thread.start(_music_job)


func _exit_tree() -> void:
	if _thread != null and _thread.is_started():
		_thread.wait_to_finish()


func play(id: String, pitch_var: float = 0.05) -> void:
	if bool(Settings.get_v("muted")):
		return
	if not _streams.has(id):
		return
	var p: AudioStreamPlayer = _players[_next]
	_next = (_next + 1) % _players.size()
	p.stream = _streams[id]
	p.pitch_scale = randf_range(1.0 - pitch_var, 1.0 + pitch_var)
	p.volume_db = linear_to_db(maxf(0.001, float(Settings.get_v("sfx_volume"))))
	p.play()


func vibrate(ms: int) -> void:
	if bool(Settings.get_v("vibration")):
		Input.vibrate_handheld(ms)


func _on_setting(key: String) -> void:
	if key == "music_volume" or key == "muted":
		_apply_music()


func _apply_music() -> void:
	if _music.stream == null:
		return
	var vol: float = float(Settings.get_v("music_volume"))
	var off: bool = bool(Settings.get_v("muted")) or vol <= 0.01
	_music.volume_db = linear_to_db(maxf(0.001, vol * 0.7))
	if off:
		_music.stop()
	elif not _music.playing:
		_music.play()


func _music_job() -> void:
	var st := _build_music()
	call_deferred("_music_ready", st)


func _music_ready(st: AudioStreamWAV) -> void:
	_thread.wait_to_finish()
	_music.stream = st
	_apply_music()


# ---------------------------------------------------------------- synthèse

func _buf(seconds: float, rate: int) -> PackedFloat32Array:
	var b := PackedFloat32Array()
	b.resize(int(seconds * float(rate)))
	b.fill(0.0)
	return b


func _wav(buf: PackedFloat32Array, rate: int) -> AudioStreamWAV:
	var bytes := PackedByteArray()
	bytes.resize(buf.size() * 2)
	for i in buf.size():
		var v := int(clampf(buf[i], -1.0, 1.0) * 32767.0)
		bytes.encode_s16(i * 2, v)
	var st := AudioStreamWAV.new()
	st.format = AudioStreamWAV.FORMAT_16_BITS
	st.mix_rate = rate
	st.stereo = false
	st.data = bytes
	return st


func _tone(buf: PackedFloat32Array, rate: int, start: float, freq: float, dur: float, amp: float, decay: float, wrap: bool = false) -> void:
	var n := buf.size()
	var i0 := int(start * float(rate))
	var cnt := int(dur * float(rate))
	var w := TAU * freq / float(rate)
	for i in cnt:
		var idx := i0 + i
		if idx >= n:
			if wrap:
				idx = idx % n
			else:
				break
		var t := float(i) / float(rate)
		var env := exp(-t * decay) * minf(1.0, float(i) / 40.0) * minf(1.0, float(cnt - i) / 60.0)
		buf[idx] += sin(w * float(i)) * env * amp


func _sweep(buf: PackedFloat32Array, rate: int, start: float, f0: float, f1: float, dur: float, amp: float, decay: float) -> void:
	var n := buf.size()
	var i0 := int(start * float(rate))
	var cnt := int(dur * float(rate))
	var phase := 0.0
	for i in cnt:
		var idx := i0 + i
		if idx >= n:
			break
		var k := float(i) / float(cnt)
		phase += TAU * lerpf(f0, f1, k) / float(rate)
		var t := float(i) / float(rate)
		var env := exp(-t * decay) * minf(1.0, float(i) / 40.0) * minf(1.0, float(cnt - i) / 60.0)
		buf[idx] += sin(phase) * env * amp


func _noise(buf: PackedFloat32Array, rate: int, start: float, dur: float, amp: float, decay: float) -> void:
	var n := buf.size()
	var i0 := int(start * float(rate))
	var cnt := int(dur * float(rate))
	var last := 0.0
	for i in cnt:
		var idx := i0 + i
		if idx >= n:
			break
		var t := float(i) / float(rate)
		last = lerpf(last, randf_range(-1.0, 1.0), 0.55)
		buf[idx] += last * exp(-t * decay) * amp


func _build_sfx() -> void:
	var b: PackedFloat32Array

	b = _buf(0.08, RATE)
	_tone(b, RATE, 0.0, 900.0, 0.07, 0.45, 45.0)
	_streams["click"] = _wav(b, RATE)

	b = _buf(0.13, RATE)
	_tone(b, RATE, 0.0, 420.0, 0.11, 0.55, 38.0)
	_tone(b, RATE, 0.0, 840.0, 0.06, 0.2, 60.0)
	_noise(b, RATE, 0.0, 0.02, 0.35, 160.0)
	_streams["step"] = _wav(b, RATE)

	b = _buf(1.0, RATE)
	var t := 0.0
	var gap := 0.05
	while t < 0.82:
		_noise(b, RATE, t, 0.05, 0.6 * (1.0 - t * 0.6), 90.0)
		_tone(b, RATE, t, randf_range(1400.0, 2200.0), 0.03, 0.22, 120.0)
		t += gap
		gap *= 1.22
	_streams["dice"] = _wav(b, RATE)

	b = _buf(0.4, RATE)
	_tone(b, RATE, 0.0, 523.25, 0.2, 0.4, 12.0)
	_tone(b, RATE, 0.12, 783.99, 0.26, 0.4, 10.0)
	_streams["enter"] = _wav(b, RATE)

	b = _buf(0.5, RATE)
	_sweep(b, RATE, 0.0, 640.0, 110.0, 0.4, 0.55, 5.0)
	_noise(b, RATE, 0.0, 0.12, 0.5, 30.0)
	_streams["capture"] = _wav(b, RATE)

	b = _buf(0.9, RATE)
	_tone(b, RATE, 0.0, 783.99, 0.5, 0.35, 6.0)
	_tone(b, RATE, 0.12, 987.77, 0.5, 0.35, 6.0)
	_tone(b, RATE, 0.24, 1174.66, 0.6, 0.35, 5.0)
	_streams["home"] = _wav(b, RATE)

	b = _buf(0.5, RATE)
	_tone(b, RATE, 0.0, 1318.5, 0.45, 0.3, 8.0)
	_tone(b, RATE, 0.0, 1760.0, 0.45, 0.2, 9.0)
	_streams["six"] = _wav(b, RATE)

	b = _buf(1.9, RATE)
	var notes := [523.25, 659.25, 783.99, 1046.5, 783.99, 1046.5]
	var times := [0.0, 0.15, 0.3, 0.45, 0.75, 0.9]
	for i in notes.size():
		var f: float = notes[i]
		var tt: float = times[i]
		_tone(b, RATE, tt, f, 0.9, 0.28, 3.5)
		_tone(b, RATE, tt, f * 2.0, 0.6, 0.08, 5.0)
	_streams["win"] = _wav(b, RATE)

	b = _buf(0.22, RATE)
	_tone(b, RATE, 0.0, 150.0, 0.2, 0.5, 8.0)
	_tone(b, RATE, 0.0, 157.0, 0.2, 0.4, 8.0)
	_streams["error"] = _wav(b, RATE)


func _build_music() -> AudioStreamWAV:
	var beat := 0.5
	var bars := 8
	var total := beat * 4.0 * float(bars)
	var buf := _buf(total, MUSIC_RATE)
	var gamme := [261.63, 293.66, 329.63, 392.0, 440.0, 523.25, 587.33, 659.25, 783.99]
	var roots := [130.81, 110.0, 87.31, 98.0, 130.81, 110.0, 87.31, 98.0]
	var rng := RandomNumberGenerator.new()
	rng.seed = 20261110
	var note := 4
	for bar in bars:
		var t0 := float(bar) * beat * 4.0
		var root: float = roots[bar]
		_tone(buf, MUSIC_RATE, t0, root, 1.6, 0.22, 1.6, true)
		_tone(buf, MUSIC_RATE, t0 + beat * 2.0, root * 1.5, 1.2, 0.13, 2.0, true)
		for h in 8:
			if h % 2 == 1 and rng.randf() < 0.3:
				continue
			note = clampi(note + rng.randi_range(-2, 2), 0, gamme.size() - 1)
			var f: float = gamme[note]
			var tt := t0 + float(h) * beat * 0.5
			_tone(buf, MUSIC_RATE, tt, f, 0.9, 0.15, 4.5, true)
			_tone(buf, MUSIC_RATE, tt, f * 2.0, 0.5, 0.045, 7.0, true)
	var st := _wav(buf, MUSIC_RATE)
	st.loop_mode = AudioStreamWAV.LOOP_FORWARD
	st.loop_begin = 0
	st.loop_end = buf.size()
	return st
