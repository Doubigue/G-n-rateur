extends Node3D
# Chef d'orchestre : construit la scène, gère les tours, les entrées tactiles et les animations.

const Rules = preload("res://scripts/ludo_rules.gd")
const AI = preload("res://scripts/ludo_ai.gd")
const Board = preload("res://scripts/board_3d.gd")
const Token = preload("res://scripts/token_3d.gd")
const Dice = preload("res://scripts/dice_3d.gd")
const CamRig = preload("res://scripts/camera_rig.gd")
const Hud = preload("res://scripts/hud.gd")
const Menu = preload("res://scripts/menu.gd")

enum St { MENU, WAIT_ROLL, BUSY, WAIT_MOVE, OVER }

var state: int = St.MENU
var rules
var board
var rig
var dice
var hud
var menu
var tokens_root: Node3D

var _tokens: Array = []
var _pending: Array = []
var _last_dice: int = 0
var _gen: int = 0
var _touches := {}
var _moved: float = 0.0
var _tap_ms: int = 0
var _pinch_last: float = 0.0
var _shake_ms: int = 0


func _ready() -> void:
	randomize()
	get_tree().quit_on_go_back = false

	board = Board.new()
	add_child(board)
	board.build(int(Settings.get_v("theme")))

	rig = CamRig.new()
	add_child(rig)

	dice = Dice.new()
	add_child(dice)
	dice.build()
	dice.visible = false

	tokens_root = Node3D.new()
	add_child(tokens_root)

	hud = Hud.new()
	add_child(hud)
	hud.build()
	hud.visible = false
	hud.roll_pressed.connect(_on_roll_pressed)
	hud.view_pressed.connect(_on_view_pressed)
	hud.pause_changed.connect(_on_pause_changed)
	hud.restart_pressed.connect(_on_restart)
	hud.quit_pressed.connect(_on_quit)

	menu = Menu.new()
	add_child(menu)
	menu.build()
	menu.start_requested.connect(_on_start_requested)
	menu.continue_requested.connect(_on_continue)

	Settings.changed.connect(_on_setting)
	_enter_menu()


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		if state == St.MENU:
			if not menu.back():
				get_tree().quit()
		elif state != St.OVER:
			hud.set_paused(not hud.is_paused())


# ---------------------------------------------------------------- menus et réglages

func _enter_menu() -> void:
	_gen += 1
	get_tree().paused = false
	state = St.MENU
	_clear_tokens()
	hud.reset()
	hud.visible = false
	dice.visible = false
	rig.reset_view()
	rig.attract = true
	menu.show_screen("main")


func _on_start_requested(config: Dictionary) -> void:
	Settings.clear_game()
	_start_game(config, {})


func _on_continue() -> void:
	var saved: Dictionary = Settings.load_game()
	if saved.is_empty():
		menu.show_screen("main")
		return
	_start_game({}, saved)


func _on_restart() -> void:
	if rules == null:
		return
	var config: Dictionary = rules.to_config()
	Settings.clear_game()
	_start_game(config, {})


func _on_quit() -> void:
	_enter_menu()


func _on_pause_changed(p: bool) -> void:
	get_tree().paused = p


func _on_view_pressed() -> void:
	rig.cycle_view()


func _on_setting(key: String) -> void:
	if key == "theme" or key == "shadows":
		board.build(int(Settings.get_v("theme")))


func _speed() -> float:
	var speeds := [1.0, 1.6, 2.4]
	var s: float = speeds[clampi(int(Settings.get_v("speed")), 0, 2)]
	return s


func _wait(seconds: float) -> void:
	await get_tree().create_timer(seconds / _speed(), false).timeout


# ---------------------------------------------------------------- partie

func _start_game(config: Dictionary, saved: Dictionary) -> void:
	_gen += 1
	get_tree().paused = false
	var r = Rules.new()
	if saved.is_empty():
		r.setup(config)
	elif not r.from_dict(saved):
		Settings.clear_game()
		menu.show_screen("main")
		return
	rules = r
	_spawn_tokens()
	menu.hide_all()
	hud.reset()
	hud.visible = true
	hud.setup_players(rules)
	rig.attract = false
	rig.reset_view()
	dice.visible = true
	_touches.clear()
	state = St.BUSY
	_begin_turn()


func _clear_tokens() -> void:
	for ch in tokens_root.get_children():
		tokens_root.remove_child(ch)
		ch.queue_free()
	_tokens.clear()


func _spawn_tokens() -> void:
	_clear_tokens()
	for pi in rules.players.size():
		var p: Dictionary = rules.players[pi]
		var col: Color = Board.PLAYER_COLORS[int(p["color"])]
		var row: Array = []
		for ti in rules.tokens_per_player:
			var tok = Token.new()
			tokens_root.add_child(tok)
			tok.player_index = pi
			tok.token_index = ti
			tok.setup(col)
			row.append(tok)
		_tokens.append(row)
	_layout_tokens(true)


func _token(pi: int, ti: int):
	return _tokens[pi][ti]


# Replace chaque pion sur sa case ; les pions qui partagent une case se serrent en cercle.
func _layout_tokens(instant: bool) -> void:
	var groups := {}
	for pi in rules.players.size():
		var p: Dictionary = rules.players[pi]
		var col: int = int(p["color"])
		for ti in rules.tokens_per_player:
			var s: int = int(p["tokens"][ti])
			var key: String
			if s < 0 or s >= 56:
				key = "u%d_%d" % [pi, ti]
			elif s > 50:
				key = "h%d_%d" % [col, s]
			else:
				key = "l%d" % int(rules.abs_index(col, s))
			if not groups.has(key):
				groups[key] = []
			groups[key].append([pi, ti, col, s])
	for gk in groups.keys():
		var arr: Array = groups[gk]
		var n: int = arr.size()
		for i in n:
			var e: Array = arr[i]
			var pos: Vector3 = board.token_position(int(e[2]), int(e[3]), int(e[1]))
			var sc := 1.0
			if int(e[3]) >= 56:
				sc = 0.62
			if n > 1:
				var ang := TAU * float(i) / float(n) + 0.6
				pos += Vector3(cos(ang), 0.0, sin(ang)) * 0.25
				sc = 0.7
			_token(int(e[0]), int(e[1])).settle(pos, sc, instant)


func _highlight(moves: Array) -> void:
	if not bool(Settings.get_v("show_hints")):
		return
	for mv in moves:
		_token(rules.current, int(mv["token"])).set_highlight(true)


func _highlight_off() -> void:
	for row in _tokens:
		for tok in row:
			tok.set_highlight(false)


func _begin_turn() -> void:
	var g: int = _gen
	var p: Dictionary = rules.players[rules.current]
	var col: int = int(p["color"])
	hud.set_current(rules.current)
	hud.update_players(rules)
	dice.place_at(board.base_center(col))
	if bool(Settings.get_v("auto_camera")):
		rig.face_color(col)
	Settings.save_game(rules.to_dict())
	if int(p["ai"]) > 0:
		state = St.BUSY
		hud.set_roll_enabled(false)
		hud.set_message("%s réfléchit…" % str(p["name"]))
		await _wait(0.7)
		if g != _gen:
			return
		_roll()
	else:
		state = St.WAIT_ROLL
		hud.set_roll_enabled(true)
		hud.set_message("%s : lancez le dé" % str(p["name"]))


func _on_roll_pressed() -> void:
	if state == St.WAIT_ROLL:
		_roll()


func _roll() -> void:
	var g: int = _gen
	state = St.BUSY
	hud.set_roll_enabled(false)
	var pi: int = rules.current
	var p: Dictionary = rules.players[pi]
	var pname: String = str(p["name"])
	var v: int = randi_range(1, 6)
	Sfx.play("dice")
	await dice.roll(v, 0.9 / _speed())
	if g != _gen:
		return
	_last_dice = v
	Settings.add_stat("rolls", 1)
	if v == 6:
		rules.six_streak += 1
		Settings.add_stat("sixes", 1)
		Sfx.play("six")
	else:
		rules.six_streak = 0

	if v == 6 and rules.opt("three_six_lose") and rules.six_streak >= 3:
		hud.set_message("%s : trois 6 de suite, tour perdu !" % pname)
		Sfx.play("error")
		await _wait(1.3)
		if g != _gen:
			return
		_end_turn(false)
		return

	var moves: Array = rules.legal_moves(pi, v)
	if moves.is_empty():
		hud.set_message("%s a fait %d : aucun coup possible" % [pname, v])
		await _wait(1.0)
		if g != _gen:
			return
		_end_turn(v == 6 and rules.opt("six_again"))
		return

	if int(p["ai"]) > 0:
		hud.set_message("%s a fait %d" % [pname, v])
		await _wait(0.45)
		if g != _gen:
			return
		var mv: Dictionary = AI.choose(rules, pi, moves, int(p["ai"]))
		_play_move(mv)
		return

	var same := true
	for m in moves:
		if int(m["from"]) != int(moves[0]["from"]):
			same = false
	if (moves.size() == 1 or same) and bool(Settings.get_v("auto_move")):
		hud.set_message("%s a fait %d" % [pname, v])
		await _wait(0.3)
		if g != _gen:
			return
		_play_move(moves[0])
		return

	_pending = moves
	state = St.WAIT_MOVE
	_highlight(moves)
	hud.set_message("%s a fait %d : touchez un pion" % [pname, v])


func _play_move(mv: Dictionary) -> void:
	var g: int = _gen
	state = St.BUSY
	_pending = []
	_highlight_off()
	var pi: int = rules.current
	var p: Dictionary = rules.players[pi]
	var col: int = int(p["color"])
	var ti: int = int(mv["token"])
	var from: int = int(mv["from"])
	var to: int = int(mv["to"])
	var tok = _token(pi, ti)
	var step_t: float = 0.2 / _speed()

	if from < 0:
		Sfx.play("enter")
		var p0: Vector3 = board.token_position(col, 0, ti)
		await tok.hop_to(p0, step_t * 1.8, 1.3)
		if g != _gen:
			return
	else:
		for s in range(from + 1, to + 1):
			var ps: Vector3 = board.token_position(col, s, ti)
			await tok.hop_to(ps, step_t, 0.45)
			if g != _gen:
				return
			Sfx.play("step", 0.1)

	var res: Dictionary = rules.apply_move(pi, ti, to)
	var caps: Array = res["captured"]
	if not caps.is_empty():
		Sfx.play("capture")
		Sfx.vibrate(120)
		hud.toast("Capturé !")
		Settings.add_stat("captures", caps.size())
		for c in caps:
			var vp: Dictionary = rules.players[int(c[0])]
			var back: Vector3 = board.token_position(int(vp["color"]), -1, int(c[1]))
			_token(int(c[0]), int(c[1])).hop_to(back, 0.45, 2.6)
		await get_tree().create_timer(0.55, false).timeout
		if g != _gen:
			return

	if bool(res["home"]):
		Sfx.play("home")
		var pc: Color = Board.PLAYER_COLORS[col]
		_burst(tok.position + Vector3(0.0, 0.5, 0.0), pc, 50)
		hud.toast("Arrivé !")

	_layout_tokens(false)
	hud.update_players(rules)

	if bool(res["finished"]):
		hud.set_message("%s a rentré tous ses pions !" % str(p["name"]))
		Sfx.play("win")
		await _wait(1.2)
		if g != _gen:
			return

	if rules.is_game_over():
		_game_over()
		return

	var extra := false
	if not bool(res["finished"]):
		if _last_dice == 6 and rules.opt("six_again"):
			extra = true
		if not caps.is_empty() and rules.opt("capture_again"):
			extra = true
		if bool(res["home"]) and rules.opt("home_again"):
			extra = true
	_end_turn(extra)


func _end_turn(extra: bool) -> void:
	if extra:
		hud.toast("Rejouez !")
	else:
		rules.six_streak = 0
		rules.next_player()
	_begin_turn()


func _game_over() -> void:
	state = St.OVER
	rules.finalize_ranking()
	Settings.clear_game()
	Settings.add_stat("games", 1)
	var winner: Dictionary = rules.players[int(rules.ranking[0])]
	if int(winner["ai"]) > 0:
		Settings.add_stat("wins_ai", 1)
	else:
		Settings.add_stat("wins_human", 1)
	hud.set_roll_enabled(false)
	hud.set_message("%s gagne la partie !" % str(winner["name"]))
	hud.update_players(rules)
	Sfx.play("win")
	Sfx.vibrate(300)
	for i in 4:
		var pc: Color = Board.PLAYER_COLORS[i]
		_burst(Vector3(randf_range(-3.0, 3.0), 1.0, randf_range(-3.0, 3.0)), pc, 70)
	rig.attract = true
	hud.show_end(rules)


# Gerbe de confettis.
func _burst(pos: Vector3, col: Color, amount: int) -> void:
	var p := CPUParticles3D.new()
	var m := BoxMesh.new()
	m.size = Vector3(0.14, 0.02, 0.14)
	var mat := StandardMaterial3D.new()
	mat.albedo_color = col
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.material = mat
	p.mesh = m
	p.amount = amount
	p.one_shot = true
	p.explosiveness = 0.95
	p.lifetime = 1.8
	p.direction = Vector3.UP
	p.spread = 55.0
	p.initial_velocity_min = 5.0
	p.initial_velocity_max = 10.0
	p.gravity = Vector3(0.0, -12.0, 0.0)
	p.position = pos
	add_child(p)
	p.emitting = true
	get_tree().create_timer(3.5).timeout.connect(p.queue_free)


# ---------------------------------------------------------------- entrées

func _process(_delta: float) -> void:
	if state != St.WAIT_ROLL:
		return
	if not bool(Settings.get_v("shake_to_roll")):
		return
	var now: int = Time.get_ticks_msec()
	if now - _shake_ms < 900:
		return
	if Input.get_accelerometer().length() > 21.0:
		_shake_ms = now
		_roll()


func _pinch_dist() -> float:
	var pts: Array = _touches.values()
	if pts.size() < 2:
		return 0.0
	var a: Vector2 = pts[0]
	var b: Vector2 = pts[1]
	return a.distance_to(b)


func _input(event: InputEvent) -> void:
	if state == St.MENU:
		return
	if event is InputEventScreenTouch:
		var pos: Vector2 = event.position
		var index: int = event.index
		if event.pressed:
			if hud.is_point_on_ui(pos):
				return
			_touches[index] = pos
			if _touches.size() == 1:
				_moved = 0.0
				_tap_ms = Time.get_ticks_msec()
			elif _touches.size() == 2:
				_pinch_last = _pinch_dist()
		elif _touches.has(index):
			var single: bool = _touches.size() == 1
			_touches.erase(index)
			if single and _moved < 18.0 and Time.get_ticks_msec() - _tap_ms < 500:
				_on_tap(pos)
	elif event is InputEventScreenDrag:
		var index: int = event.index
		if not _touches.has(index):
			return
		_touches[index] = event.position
		var rel: Vector2 = event.relative
		if _touches.size() == 1:
			_moved += rel.length()
			if _moved >= 18.0:
				rig.drag(rel)
		else:
			var d: float = _pinch_dist()
			if _pinch_last > 1.0 and d > 1.0:
				rig.zoom_by(_pinch_last / d)
			_pinch_last = d
	elif event is InputEventMouseButton:
		if event.pressed and event.button_index == MOUSE_BUTTON_WHEEL_UP:
			rig.zoom_by(0.92)
		elif event.pressed and event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			rig.zoom_by(1.08)


func _screen_pos(world: Vector3) -> Vector2:
	var cam: Camera3D = rig.cam
	if cam.is_position_behind(world):
		return Vector2(-9999.0, -9999.0)
	return cam.unproject_position(world)


func _on_tap(pos: Vector2) -> void:
	if state == St.WAIT_ROLL:
		if _screen_pos(dice.global_position).distance_to(pos) < 120.0:
			_roll()
	elif state == St.WAIT_MOVE:
		var best = null
		var best_d := 100.0
		for mv in _pending:
			var tok = _token(rules.current, int(mv["token"]))
			var wp: Vector3 = tok.global_position + Vector3(0.0, 0.4, 0.0)
			var d: float = _screen_pos(wp).distance_to(pos)
			if d < best_d:
				best_d = d
				best = mv
		if best != null:
			_play_move(best)
