extends Node3D
# Plateau 3D construit par code : table, cadre, cases, bases, centre, lumières et ciel.
# Grille 15 x 15, une case = 1 unité, centre du plateau à l'origine.

const PLAYER_COLORS := [
	Color(0.85, 0.13, 0.15),
	Color(0.1, 0.62, 0.28),
	Color(0.96, 0.76, 0.08),
	Color(0.11, 0.42, 0.86),
]
const COLOR_NAMES := ["Rouge", "Vert", "Jaune", "Bleu"]
const START := [0, 13, 26, 39]
const STARS := [8, 21, 34, 47]
const BASE_CENTERS := [Vector2(2.5, 2.5), Vector2(11.5, 2.5), Vector2(11.5, 11.5), Vector2(2.5, 11.5)]
const SPOTS := [Vector2(-1, -1), Vector2(1, -1), Vector2(-1, 1), Vector2(1, 1)]
const HOME_DIRS := [Vector2(-1, 0), Vector2(0, -1), Vector2(1, 0), Vector2(0, 1)]

const THEMES := [
	{
		"name": "Classique",
		"cell": Color(0.96, 0.95, 0.9), "frame": Color(0.36, 0.2, 0.1),
		"table": Color(0.1, 0.34, 0.2), "table2": Color(0.06, 0.24, 0.14),
		"sky_top": Color(0.22, 0.42, 0.72), "sky_hor": Color(0.74, 0.82, 0.9),
		"sun": 1.25, "sun_color": Color(1.0, 0.96, 0.88), "ambient": 0.9, "lamp": 0.0,
	},
	{
		"name": "Bois précieux",
		"cell": Color(0.93, 0.84, 0.66), "frame": Color(0.24, 0.11, 0.05),
		"table": Color(0.47, 0.28, 0.13), "table2": Color(0.3, 0.16, 0.07),
		"sky_top": Color(0.45, 0.33, 0.25), "sky_hor": Color(0.95, 0.8, 0.62),
		"sun": 1.2, "sun_color": Color(1.0, 0.86, 0.68), "ambient": 0.8, "lamp": 0.0,
	},
	{
		"name": "Nuit",
		"cell": Color(0.8, 0.82, 0.9), "frame": Color(0.09, 0.09, 0.13),
		"table": Color(0.07, 0.08, 0.14), "table2": Color(0.03, 0.04, 0.08),
		"sky_top": Color(0.01, 0.02, 0.06), "sky_hor": Color(0.05, 0.07, 0.16),
		"sun": 0.3, "sun_color": Color(0.6, 0.7, 1.0), "ambient": 0.35, "lamp": 3.2,
	},
]

var loop: Array = []


func _init() -> void:
	loop = _build_loop()


# Les 52 cases du circuit, dans le sens des aiguilles d'une montre, à partir du départ rouge.
func _build_loop() -> Array:
	var p: Array = []
	for c in range(1, 6):
		p.append(Vector2i(c, 6))
	for r in range(5, -1, -1):
		p.append(Vector2i(6, r))
	p.append(Vector2i(7, 0))
	for r in range(0, 6):
		p.append(Vector2i(8, r))
	for c in range(9, 15):
		p.append(Vector2i(c, 6))
	p.append(Vector2i(14, 7))
	for c in range(14, 8, -1):
		p.append(Vector2i(c, 8))
	for r in range(9, 15):
		p.append(Vector2i(8, r))
	p.append(Vector2i(7, 14))
	for r in range(14, 8, -1):
		p.append(Vector2i(6, r))
	for c in range(5, -1, -1):
		p.append(Vector2i(c, 8))
	p.append(Vector2i(0, 7))
	p.append(Vector2i(0, 6))
	return p


func _world(cell: Vector2, y: float) -> Vector3:
	return Vector3(cell.x - 7.0, y, cell.y - 7.0)


func home_cell(color: int, k: int) -> Vector2:
	var d: Vector2 = HOME_DIRS[color]
	return Vector2(7, 7) + d * float(7 - k)


func base_center(color: int) -> Vector3:
	var bc: Vector2 = BASE_CENTERS[color]
	return _world(bc, 0.07)


# Position 3D d'un pion selon son avancement.
func token_position(color: int, step: int, token_index: int) -> Vector3:
	if step < 0:
		var sp: Vector2 = SPOTS[token_index % 4]
		var bc: Vector2 = BASE_CENTERS[color]
		return _world(bc + sp, 0.09)
	if step <= 50:
		var cell: Vector2i = loop[(int(START[color]) + step) % 52]
		return _world(Vector2(cell.x, cell.y), 0.05)
	if step <= 55:
		return _world(home_cell(color, step - 50), 0.05)
	var d: Vector2 = HOME_DIRS[color]
	var perp := Vector2(-d.y, d.x)
	return _world(Vector2(7, 7) + d * 0.95 + perp * (float(token_index) - 1.5) * 0.42, 0.06)


# ---------------------------------------------------------------- construction

func build(theme_id: int) -> void:
	for ch in get_children():
		remove_child(ch)
		ch.queue_free()
	var th: Dictionary = THEMES[clampi(theme_id, 0, THEMES.size() - 1)]
	_build_environment(th)

	# Table
	var table_mat := _mat(th["table"], 0.85, 0.0)
	var noise := FastNoiseLite.new()
	noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	noise.frequency = 0.012
	var grad := Gradient.new()
	grad.set_color(0, th["table2"])
	grad.set_color(1, th["table"])
	var tex := NoiseTexture2D.new()
	tex.width = 256
	tex.height = 256
	tex.seamless = true
	tex.noise = noise
	tex.color_ramp = grad
	table_mat.albedo_color = Color.WHITE
	table_mat.albedo_texture = tex
	table_mat.uv1_scale = Vector3(3.0, 14.0, 1.0)
	_box(Vector3(70.0, 0.5, 70.0), Vector3(0.0, -0.75, 0.0), table_mat, false)

	# Cadre du plateau
	var frame_mat := _mat(th["frame"], 0.45, 0.0)
	frame_mat.clearcoat_enabled = true
	frame_mat.clearcoat = 0.5
	_box(Vector3(16.6, 0.5, 16.6), Vector3(0.0, -0.25, 0.0), frame_mat, true)
	_box(Vector3(16.6, 0.2, 0.42), Vector3(0.0, 0.1, 8.09), frame_mat, true)
	_box(Vector3(16.6, 0.2, 0.42), Vector3(0.0, 0.1, -8.09), frame_mat, true)
	_box(Vector3(0.42, 0.2, 15.76), Vector3(8.09, 0.1, 0.0), frame_mat, true)
	_box(Vector3(0.42, 0.2, 15.76), Vector3(-8.09, 0.1, 0.0), frame_mat, true)

	var cell_mat := _mat(th["cell"], 0.55, 0.0)
	var color_mats: Array = []
	for i in 4:
		var pc: Color = PLAYER_COLORS[i]
		color_mats.append(_mat(pc, 0.45, 0.0))
	var gold := _mat(Color(0.95, 0.72, 0.18), 0.3, 0.7)
	gold.cull_mode = BaseMaterial3D.CULL_DISABLED

	# Circuit
	for i in loop.size():
		var cell: Vector2i = loop[i]
		var m: Material = cell_mat
		var k: int = START.find(i)
		if k >= 0:
			m = color_mats[k]
		_box(Vector3(0.94, 0.05, 0.94), _world(Vector2(cell.x, cell.y), 0.025), m, false)
		if STARS.has(i):
			_star(_world(Vector2(cell.x, cell.y), 0.056), 0.36, gold)

	# Couloirs finaux, bases et centre
	var white := _mat(Color(0.97, 0.97, 0.95), 0.5, 0.0)
	_box(Vector3(2.94, 0.05, 2.94), Vector3(0.0, 0.02, 0.0), _mat(Color(0.15, 0.15, 0.18), 0.6, 0.0), false)
	for c in 4:
		var cm: Material = color_mats[c]
		for k in range(1, 6):
			_box(Vector3(0.94, 0.05, 0.94), _world(home_cell(c, k), 0.025), cm, false)
		var bc: Vector2 = BASE_CENTERS[c]
		_box(Vector3(5.94, 0.05, 5.94), _world(bc, 0.025), cm, false)
		_box(Vector3(4.3, 0.02, 4.3), _world(bc, 0.06), white, false)
		for sp in SPOTS:
			var spot: Vector2 = sp
			_disc(_world(bc + spot, 0.08), 0.45, cm)
		_triangle(c, cm)


func _build_environment(th: Dictionary) -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sm := ProceduralSkyMaterial.new()
	sm.sky_top_color = th["sky_top"]
	sm.sky_horizon_color = th["sky_hor"]
	sm.ground_horizon_color = th["sky_hor"]
	sm.ground_bottom_color = th["table2"]
	sky.sky_material = sm
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = float(th["ambient"])
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.glow_enabled = true
	env.glow_intensity = 0.35
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-52.0, -38.0, 0.0)
	sun.light_energy = float(th["sun"])
	sun.light_color = th["sun_color"]
	sun.shadow_enabled = bool(Settings.get_v("shadows"))
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
	sun.directional_shadow_max_distance = 70.0
	add_child(sun)

	if float(th["lamp"]) > 0.0:
		var lamp := OmniLight3D.new()
		lamp.position = Vector3(0.0, 9.0, 0.0)
		lamp.omni_range = 30.0
		lamp.light_energy = float(th["lamp"])
		lamp.light_color = Color(1.0, 0.85, 0.6)
		lamp.shadow_enabled = bool(Settings.get_v("shadows"))
		add_child(lamp)


func _mat(col: Color, rough: float, metal: float) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = col
	m.roughness = rough
	m.metallic = metal
	return m


func _box(size: Vector3, pos: Vector3, mat: Material, shadows: bool) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = mat
	mi.position = pos
	if not shadows:
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)
	return mi


func _disc(pos: Vector3, radius: float, mat: Material) -> void:
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = radius
	cm.bottom_radius = radius
	cm.height = 0.02
	cm.radial_segments = 32
	mi.mesh = cm
	mi.material_override = mat
	mi.position = pos
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)


func _flat_mesh(points: Array, pos: Vector3, mat: Material) -> void:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for p in points:
		var v: Vector3 = p
		st.set_normal(Vector3.UP)
		st.add_vertex(v)
	var mi := MeshInstance3D.new()
	mi.mesh = st.commit()
	mi.material_override = mat
	mi.position = pos
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)


func _star(pos: Vector3, radius: float, mat: Material) -> void:
	var rim: Array = []
	for i in 10:
		var ang := -PI / 2.0 + float(i) * TAU / 10.0
		var rr := radius
		if i % 2 == 1:
			rr = radius * 0.45
		rim.append(Vector3(cos(ang) * rr, 0.0, sin(ang) * rr))
	var pts: Array = []
	for i in 10:
		pts.append(Vector3.ZERO)
		pts.append(rim[i])
		pts.append(rim[(i + 1) % 10])
	_flat_mesh(pts, pos, mat)


# Triangle coloré du centre, pointe vers le milieu du plateau.
func _triangle(color: int, mat: Material) -> void:
	var d: Vector2 = HOME_DIRS[color]
	var perp := Vector2(-d.y, d.x)
	var a := d * 1.47 + perp * 1.47
	var b := d * 1.47 - perp * 1.47
	var m := StandardMaterial3D.new()
	var pc: Color = PLAYER_COLORS[color]
	m.albedo_color = pc
	m.roughness = 0.45
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	_flat_mesh([Vector3.ZERO, Vector3(a.x, 0.0, a.y), Vector3(b.x, 0.0, b.y)], Vector3(0.0, 0.052, 0.0), m)
