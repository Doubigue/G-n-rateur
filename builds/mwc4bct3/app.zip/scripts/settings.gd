extends Node
# Réglages, statistiques et sauvegarde de partie (autoload "Settings").

signal changed(key: String)

const CFG_PATH := "user://reglages.cfg"
const SAVE_PATH := "user://partie.json"

var _cfg := ConfigFile.new()
var _values := {
	"music_volume": 0.5,
	"sfx_volume": 0.9,
	"muted": false,
	"vibration": true,
	"theme": 0,
	"speed": 0,
	"auto_move": true,
	"auto_camera": false,
	"shake_to_roll": true,
	"shadows": true,
	"show_hints": true,
}
var _stats := {
	"games": 0,
	"wins_human": 0,
	"wins_ai": 0,
	"captures": 0,
	"sixes": 0,
	"rolls": 0,
}


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	if _cfg.load(CFG_PATH) == OK:
		for k in _values.keys():
			_values[k] = _cfg.get_value("reglages", k, _values[k])
		for k in _stats.keys():
			_stats[k] = int(_cfg.get_value("stats", k, 0))


func get_v(key: String):
	return _values.get(key)


func set_v(key: String, value) -> void:
	_values[key] = value
	_cfg.set_value("reglages", key, value)
	_cfg.save(CFG_PATH)
	changed.emit(key)


func get_stat(key: String) -> int:
	return int(_stats.get(key, 0))


func add_stat(key: String, amount: int) -> void:
	_stats[key] = int(_stats.get(key, 0)) + amount
	_cfg.set_value("stats", key, _stats[key])
	_cfg.save(CFG_PATH)


func reset_stats() -> void:
	for k in _stats.keys():
		_stats[k] = 0
		_cfg.set_value("stats", k, 0)
	_cfg.save(CFG_PATH)


func default_opts() -> Dictionary:
	return {
		"exit_with_one": false,
		"six_again": true,
		"capture_again": true,
		"home_again": true,
		"three_six_lose": true,
		"double_safe": false,
	}


func default_setup() -> Dictionary:
	return {
		"players": [
			{"name": "Rouge", "type": 0},
			{"name": "Vert", "type": 2},
			{"name": "Jaune", "type": 2},
			{"name": "Bleu", "type": 2},
		],
		"mode": 0,
		"opts": default_opts(),
	}


func get_setup() -> Dictionary:
	var s = _cfg.get_value("partie", "setup", null)
	if s is Dictionary and s.has("players") and s.has("opts") and s["players"] is Array and s["players"].size() == 4:
		var d: Dictionary = default_opts()
		for k in d.keys():
			if not s["opts"].has(k):
				s["opts"][k] = d[k]
		if not s.has("mode"):
			s["mode"] = 0
		return s
	return default_setup()


func set_setup(s: Dictionary) -> void:
	_cfg.set_value("partie", "setup", s)
	_cfg.save(CFG_PATH)


func has_save() -> bool:
	return FileAccess.file_exists(SAVE_PATH)


func save_game(d: Dictionary) -> void:
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f == null:
		return
	f.store_string(JSON.stringify(d))
	f.close()


func load_game() -> Dictionary:
	if not FileAccess.file_exists(SAVE_PATH):
		return {}
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		return {}
	var parsed = JSON.parse_string(f.get_as_text())
	f.close()
	if parsed is Dictionary:
		return parsed
	return {}


func clear_game() -> void:
	if FileAccess.file_exists(SAVE_PATH):
		DirAccess.remove_absolute(SAVE_PATH)
