extends Node3D
# Dé 3D avec points sur les six faces et animation de lancer.
# Faces : +Y = 1, -Y = 6, +X = 2, -X = 5, +Z = 3, -Z = 4.

const SIZE := 0.9

var rolling: bool = false
var _rest: Vector3 = Vector3(0.0, SIZE * 0.5 + 0.07, 0.0)
var _move_tween: Tween


func build() -> void:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(SIZE, SIZE, SIZE)
	mi.mesh = bm
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.97, 0.96, 0.92)
	mat.roughness = 0.18
	mat.clearcoat_enabled = true
	mat.clearcoat = 0.9
	mi.material_override = mat
	add_child(mi)

	var dark := StandardMaterial3D.new()
	dark.albedo_color = Color(0.08, 0.08, 0.1)
	dark.roughness = 0.4
	var red := StandardMaterial3D.new()
	red.albedo_color = Color(0.8, 0.1, 0.12)
	red.roughness = 0.4

	var faces := {
		1: [Vector3.UP, Vector3.RIGHT, Vector3.BACK],
		6: [Vector3.DOWN, Vector3.RIGHT, Vector3.BACK],
		2: [Vector3.RIGHT, Vector3.UP, Vector3.BACK],
		5: [Vector3.LEFT, Vector3.UP, Vector3.BACK],
		3: [Vector3.BACK, Vector3.RIGHT, Vector3.UP],
		4: [Vector3.FORWARD, Vector3.RIGHT, Vector3.UP],
	}
	var layouts := {
		1: [Vector2(0, 0)],
		2: [Vector2(-1, -1), Vector2(1, 1)],
		3: [Vector2(-1, -1), Vector2(0, 0), Vector2(1, 1)],
		4: [Vector2(-1, -1), Vector2(1, -1), Vector2(-1, 1), Vector2(1, 1)],
		5: [Vector2(-1, -1), Vector2(1, -1), Vector2(0, 0), Vector2(-1, 1), Vector2(1, 1)],
		6: [Vector2(-1, -1), Vector2(-1, 0), Vector2(-1, 1), Vector2(1, -1), Vector2(1, 0), Vector2(1, 1)],
	}
	for value in faces.keys():
		var f: Array = faces[value]
		var n: Vector3 = f[0]
		var u: Vector3 = f[1]
		var v: Vector3 = f[2]
		var pts: Array = layouts[value]
		for pt in pts:
			var p2: Vector2 = pt
			var pip := MeshInstance3D.new()
			var cm := CylinderMesh.new()
			var r := 0.075
			if int(value) == 1:
				r = 0.12
			cm.top_radius = r
			cm.bottom_radius = r
			cm.height = 0.02
			cm.radial_segments = 16
			pip.mesh = cm
			if int(value) == 1:
				pip.material_override = red
			else:
				pip.material_override = dark
			pip.position = n * (SIZE * 0.5 + 0.004) + u * p2.x * SIZE * 0.26 + v * p2.y * SIZE * 0.26
			if absf(n.x) > 0.5:
				pip.rotation.z = PI / 2.0
			elif absf(n.z) > 0.5:
				pip.rotation.x = PI / 2.0
			pip.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			add_child(pip)
	position = _rest


# Rotation qui amène la face "value" vers le haut.
func _face_basis(value: int) -> Basis:
	match value:
		6:
			return Basis(Vector3.RIGHT, PI)
		2:
			return Basis(Vector3.BACK, PI / 2.0)
		5:
			return Basis(Vector3.BACK, -PI / 2.0)
		3:
			return Basis(Vector3.RIGHT, -PI / 2.0)
		4:
			return Basis(Vector3.RIGHT, PI / 2.0)
	return Basis.IDENTITY


# Pose le dé au-dessus d'un point du plateau (la base du joueur courant).
func place_at(ground: Vector3) -> void:
	_rest = ground + Vector3(0.0, SIZE * 0.5, 0.0)
	if rolling:
		return
	if _move_tween != null and _move_tween.is_valid():
		_move_tween.kill()
	_move_tween = create_tween()
	_move_tween.tween_property(self, "position", _rest, 0.3)


# Lance le dé et l'arrête sur "value" (à attendre avec await).
func roll(value: int, duration: float) -> void:
	rolling = true
	if _move_tween != null and _move_tween.is_valid():
		_move_tween.kill()
	var axis := Vector3(randf_range(-1.0, 1.0), randf_range(-1.0, 1.0), randf_range(-1.0, 1.0))
	if axis.length() < 0.1:
		axis = Vector3(1.0, 0.3, 0.2)
	axis = axis.normalized()
	var t := 0.0
	while t < duration:
		await get_tree().process_frame
		if get_tree().paused:
			continue
		var dt := get_process_delta_time()
		t += dt
		var k := clampf(t / duration, 0.0, 1.0)
		rotate(axis, (1.0 - k * 0.6) * 15.0 * dt)
		var bounce := absf(cos(k * PI * 2.5)) * (1.0 - k) * (1.0 - k) * 3.5
		position = _rest + Vector3(0.0, bounce, 0.0)
	position = _rest
	var target := Basis(Vector3.UP, randf() * TAU) * _face_basis(value)
	var tw := create_tween()
	tw.tween_property(self, "quaternion", target.get_rotation_quaternion(), 0.16)
	await tw.finished
	rolling = false
