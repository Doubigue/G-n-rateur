extends Node3D
# Caméra orbitale autour du plateau : glisser pour tourner, pincer pour zoomer.

const PITCH_MIN := 0.35
const PITCH_MAX := 1.5

var cam: Camera3D
var attract: bool = false

var _yaw: float = 0.0
var _pitch: float = 1.0
var _zoom: float = 1.0
var _t_yaw: float = 0.0
var _t_pitch: float = 1.0
var _t_zoom: float = 1.0
var _view: int = 0


func _ready() -> void:
	cam = Camera3D.new()
	cam.fov = 50.0
	cam.near = 0.1
	cam.far = 300.0
	add_child(cam)
	cam.current = true
	_update(1.0)


func _process(delta: float) -> void:
	if attract:
		_t_yaw += delta * 0.18
	_update(clampf(delta * 6.0, 0.0, 1.0))


func _update(k: float) -> void:
	_yaw = lerp_angle(_yaw, _t_yaw, k)
	_pitch = lerpf(_pitch, _t_pitch, k)
	_zoom = lerpf(_zoom, _t_zoom, k)
	var vs: Vector2 = get_viewport().get_visible_rect().size
	var aspect := vs.x / maxf(vs.y, 1.0)
	# Distance pour que tout le plateau tienne dans la largeur (portrait) ou la hauteur (paysage).
	var fit := 10.5 / (tan(deg_to_rad(cam.fov * 0.5)) * minf(aspect, 1.0))
	var dir := Vector3(sin(_yaw) * cos(_pitch), sin(_pitch), cos(_yaw) * cos(_pitch))
	cam.position = dir * fit * _zoom
	cam.look_at(Vector3.ZERO, Vector3.UP)


func drag(rel: Vector2) -> void:
	_t_yaw -= rel.x * 0.006
	_t_pitch = clampf(_t_pitch + rel.y * 0.005, PITCH_MIN, PITCH_MAX)


func zoom_by(factor: float) -> void:
	_t_zoom = clampf(_t_zoom * factor, 0.45, 1.4)


func reset_view() -> void:
	_view = 0
	_t_yaw = 0.0
	_t_pitch = 1.0
	_t_zoom = 1.0


# Alterne : vue inclinée, vue de dessus, vue rasante.
func cycle_view() -> void:
	_view = (_view + 1) % 3
	if _view == 0:
		_t_pitch = 1.0
		_t_zoom = 1.0
	elif _view == 1:
		_t_pitch = PITCH_MAX
		_t_zoom = 0.95
	else:
		_t_pitch = 0.6
		_t_zoom = 0.85


# Tourne le plateau pour mettre la base de cette couleur en bas à gauche de l'écran.
func face_color(color: int) -> void:
	var yaws := [270.0, 180.0, 90.0, 0.0]
	var y: float = yaws[color]
	_t_yaw = deg_to_rad(y)
