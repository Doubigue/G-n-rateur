extends Node3D
# Pion 3D : socle, corps conique, tête, anneau lumineux quand il est jouable.

var player_index: int = 0
var token_index: int = 0

var _body: Node3D
var _ring: MeshInstance3D
var _highlight: bool = false
var _time: float = 0.0
var _hop_from: Vector3 = Vector3.ZERO
var _hop_target: Vector3 = Vector3.ZERO
var _hop_height: float = 0.5
var _settle_tween: Tween


func setup(col: Color) -> void:
	_body = Node3D.new()
	add_child(_body)
	var mat := StandardMaterial3D.new()
	mat.albedo_color = col
	mat.roughness = 0.2
	mat.metallic = 0.05
	mat.clearcoat_enabled = true
	mat.clearcoat = 0.8
	_part(_cyl(0.30, 0.34, 0.10), 0.05, mat)
	_part(_cyl(0.085, 0.27, 0.50), 0.35, mat)
	_part(_cyl(0.15, 0.15, 0.05), 0.60, mat)
	var head := SphereMesh.new()
	head.radius = 0.17
	head.height = 0.34
	head.radial_segments = 24
	head.rings = 12
	_part(head, 0.75, mat)

	_ring = MeshInstance3D.new()
	var tm := TorusMesh.new()
	tm.inner_radius = 0.38
	tm.outer_radius = 0.5
	_ring.mesh = tm
	var rm := StandardMaterial3D.new()
	rm.albedo_color = Color(1.0, 0.92, 0.5)
	rm.emission_enabled = true
	rm.emission = Color(1.0, 0.85, 0.3)
	rm.emission_energy_multiplier = 2.5
	_ring.material_override = rm
	_ring.position = Vector3(0.0, 0.04, 0.0)
	_ring.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_ring.visible = false
	add_child(_ring)


func _cyl(top: float, bottom: float, height: float) -> CylinderMesh:
	var cm := CylinderMesh.new()
	cm.top_radius = top
	cm.bottom_radius = bottom
	cm.height = height
	cm.radial_segments = 24
	return cm


func _part(mesh: Mesh, y: float, mat: Material) -> void:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.position = Vector3(0.0, y, 0.0)
	_body.add_child(mi)


func _process(delta: float) -> void:
	if not _highlight:
		return
	_time += delta
	_body.position.y = absf(sin(_time * 5.0)) * 0.22
	var s := 1.0 + sin(_time * 6.0) * 0.12
	_ring.scale = Vector3(s, 1.0, s)


func set_highlight(on: bool) -> void:
	_highlight = on
	_ring.visible = on
	if not on:
		_body.position.y = 0.0


func _hop_step(k: float) -> void:
	position = _hop_from.lerp(_hop_target, k) + Vector3(0.0, sin(k * PI) * _hop_height, 0.0)


# Saut en cloche vers une position (à attendre avec await).
func hop_to(target: Vector3, dur: float, height: float) -> void:
	if _settle_tween != null and _settle_tween.is_valid():
		_settle_tween.kill()
	_hop_from = position
	_hop_target = target
	_hop_height = height
	var tw := create_tween()
	tw.tween_method(_hop_step, 0.0, 1.0, dur)
	await tw.finished


# Glisse doucement vers sa place définitive (pions empilés sur une même case).
func settle(target: Vector3, sc: float, instant: bool) -> void:
	if _settle_tween != null and _settle_tween.is_valid():
		_settle_tween.kill()
	if instant:
		position = target
		scale = Vector3(sc, sc, sc)
		return
	_settle_tween = create_tween()
	_settle_tween.set_parallel(true)
	_settle_tween.tween_property(self, "position", target, 0.18)
	_settle_tween.tween_property(self, "scale", Vector3(sc, sc, sc), 0.18)
