extends CanvasLayer
# Interface en jeu : joueurs, message, bouton du dé, pause, fin de partie.

signal roll_pressed
signal view_pressed
signal pause_changed(paused: bool)
signal restart_pressed
signal quit_pressed

const UI = preload("res://scripts/ui_kit.gd")
const Board = preload("res://scripts/board_3d.gd")

var _root: Control
var _chips: Array = []
var _msg: Label
var _roll: Button
var _sound_btn: Button
var _toast: Label
var _toast_tween: Tween
var _pause: Control
var _end: Control
var _end_list: VBoxContainer
var _blockers: Array = []
var _current: int = -1


func build() -> void:
	layer = 5
	process_mode = Node.PROCESS_MODE_ALWAYS
	_root = Control.new()
	UI.full(_root)
	_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.theme = UI.make_theme(24)
	add_child(_root)

	# Bandeau des joueurs
	var top := HBoxContainer.new()
	UI.place(top, 0.0, 0.0, 1.0, 0.0, 12.0, 44.0, -12.0, 150.0)
	top.add_theme_constant_override("separation", 8)
	_root.add_child(top)
	_blockers.append(top)
	for i in 4:
		var panel := PanelContainer.new()
		panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var sb := UI.box(Color(0.2, 0.2, 0.2), 16, 8)
		panel.add_theme_stylebox_override("panel", sb)
		var vb := VBoxContainer.new()
		vb.alignment = BoxContainer.ALIGNMENT_CENTER
		panel.add_child(vb)
		var nm := UI.label("", 22, Color.WHITE, true)
		nm.clip_text = true
		var sc := UI.label("", 20, Color.WHITE, true)
		vb.add_child(nm)
		vb.add_child(sc)
		top.add_child(panel)
		_chips.append({"panel": panel, "style": sb, "name": nm, "score": sc})

	# Message
	_msg = UI.label("", 28, Color.WHITE, true, true)
	UI.place(_msg, 0.0, 0.0, 1.0, 0.0, 20.0, 160.0, -20.0, 250.0)
	_msg.add_theme_constant_override("outline_size", 8)
	_msg.add_theme_color_override("font_outline_color", Color(0.0, 0.0, 0.0, 0.9))
	_root.add_child(_msg)

	# Annonce centrale
	_toast = UI.label("", 44, UI.C_ACCENT, true)
	UI.place(_toast, 0.0, 0.5, 1.0, 0.5, 20.0, -330.0, -20.0, -260.0)
	_toast.add_theme_constant_override("outline_size", 10)
	_toast.add_theme_color_override("font_outline_color", Color(0.0, 0.0, 0.0, 0.9))
	_toast.modulate.a = 0.0
	_root.add_child(_toast)

	# Bouton du dé
	_roll = UI.button("LANCER LE DÉ", UI.C_ACCENT, 36, 100.0)
	UI.place(_roll, 0.0, 1.0, 1.0, 1.0, 130.0, -250.0, -130.0, -144.0)
	_roll.pressed.connect(func() -> void: roll_pressed.emit())
	_root.add_child(_roll)
	_blockers.append(_roll)

	# Barre du bas
	var bottom := HBoxContainer.new()
	UI.place(bottom, 0.0, 1.0, 1.0, 1.0, 16.0, -124.0, -16.0, -34.0)
	bottom.add_theme_constant_override("separation", 12)
	_root.add_child(bottom)
	_blockers.append(bottom)
	var b_pause := UI.button("Pause", UI.C_BTN, 26, 80.0)
	b_pause.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b_pause.pressed.connect(func() -> void: set_paused(true))
	bottom.add_child(b_pause)
	var b_view := UI.button("Vue", UI.C_BTN, 26, 80.0)
	b_view.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b_view.pressed.connect(func() -> void: view_pressed.emit())
	bottom.add_child(b_view)
	_sound_btn = UI.button("", UI.C_BTN, 26, 80.0)
	_sound_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_sound_btn.pressed.connect(_toggle_sound)
	bottom.add_child(_sound_btn)
	_refresh_sound()

	_build_pause()
	_build_end()


func _overlay(title: String, height: float) -> VBoxContainer:
	var holder := Control.new()
	UI.full(holder)
	holder.visible = false
	_root.add_child(holder)
	var dim := ColorRect.new()
	dim.color = Color(0.02, 0.03, 0.06, 0.7)
	UI.full(dim)
	holder.add_child(dim)
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", UI.box(UI.C_PANEL, 28, 28))
	UI.place(panel, 0.5, 0.5, 0.5, 0.5, -290.0, -height * 0.5, 290.0, height * 0.5)
	holder.add_child(panel)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 16)
	panel.add_child(vb)
	vb.add_child(UI.label(title, 44, UI.C_ACCENT, true))
	vb.set_meta("holder", holder)
	return vb


func _build_pause() -> void:
	var vb := _overlay("Pause", 520.0)
	_pause = vb.get_meta("holder")
	var b1 := UI.button("Reprendre", UI.C_GOOD)
	b1.pressed.connect(func() -> void: set_paused(false))
	vb.add_child(b1)
	var b2 := UI.button("Recommencer")
	b2.pressed.connect(func() -> void:
		_pause.visible = false
		restart_pressed.emit()
	)
	vb.add_child(b2)
	var b3 := UI.button("Menu principal", UI.C_BAD)
	b3.pressed.connect(func() -> void:
		_pause.visible = false
		quit_pressed.emit()
	)
	vb.add_child(b3)


func _build_end() -> void:
	var vb := _overlay("Partie terminée", 720.0)
	_end = vb.get_meta("holder")
	_end_list = VBoxContainer.new()
	_end_list.add_theme_constant_override("separation", 10)
	_end_list.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vb.add_child(_end_list)
	var b1 := UI.button("Rejouer", UI.C_GOOD)
	b1.pressed.connect(func() -> void:
		_end.visible = false
		restart_pressed.emit()
	)
	vb.add_child(b1)
	var b2 := UI.button("Menu principal")
	b2.pressed.connect(func() -> void:
		_end.visible = false
		quit_pressed.emit()
	)
	vb.add_child(b2)


func _toggle_sound() -> void:
	Settings.set_v("muted", not bool(Settings.get_v("muted")))
	_refresh_sound()


func _refresh_sound() -> void:
	if bool(Settings.get_v("muted")):
		_sound_btn.text = "Son : non"
	else:
		_sound_btn.text = "Son : oui"


# Vrai si ce point de l'écran est sur un bouton ou un panneau (le plateau ne doit pas réagir).
func is_point_on_ui(p: Vector2) -> bool:
	if _pause.visible or _end.visible:
		return true
	for c in _blockers:
		var ctrl: Control = c
		if ctrl.is_visible_in_tree() and ctrl.get_global_rect().has_point(p):
			return true
	return false


func is_paused() -> bool:
	return _pause.visible


func set_paused(p: bool) -> void:
	if _end.visible:
		return
	_pause.visible = p
	pause_changed.emit(p)


func reset() -> void:
	_pause.visible = false
	_end.visible = false
	_toast.modulate.a = 0.0
	_refresh_sound()


func setup_players(rules) -> void:
	for i in 4:
		var chip: Dictionary = _chips[i]
		var panel: PanelContainer = chip["panel"]
		panel.visible = i < rules.players.size()
		if not panel.visible:
			continue
		var p: Dictionary = rules.players[i]
		var col: Color = Board.PLAYER_COLORS[int(p["color"])]
		var sb: StyleBoxFlat = chip["style"]
		sb.bg_color = col.darkened(0.25)
		var nm: Label = chip["name"]
		var txt: String = str(p["name"])
		if int(p["ai"]) > 0:
			txt += " (IA)"
		nm.text = txt
	_current = -1
	update_players(rules)


func update_players(rules) -> void:
	for i in rules.players.size():
		var chip: Dictionary = _chips[i]
		var sc: Label = chip["score"]
		var n: int = rules.home_count(i)
		var place: int = rules.ranking.find(i)
		if place >= 0:
			sc.text = "Terminé n°%d" % (place + 1)
		else:
			sc.text = "%d / %d arrivés" % [n, rules.tokens_per_player]


func set_current(index: int) -> void:
	_current = index
	for i in 4:
		var chip: Dictionary = _chips[i]
		var sb: StyleBoxFlat = chip["style"]
		var panel: PanelContainer = chip["panel"]
		if i == index:
			sb.border_color = Color.WHITE
			sb.set_border_width_all(5)
			panel.modulate = Color(1.0, 1.0, 1.0, 1.0)
		else:
			sb.set_border_width_all(0)
			panel.modulate = Color(1.0, 1.0, 1.0, 0.6)


func set_message(text: String) -> void:
	_msg.text = text


func set_roll_enabled(on: bool) -> void:
	_roll.disabled = not on


func toast(text: String) -> void:
	_toast.text = text
	_toast.modulate.a = 1.0
	if _toast_tween != null and _toast_tween.is_valid():
		_toast_tween.kill()
	_toast_tween = create_tween()
	_toast_tween.tween_interval(0.9)
	_toast_tween.tween_property(_toast, "modulate:a", 0.0, 0.5)


func show_end(rules) -> void:
	for ch in _end_list.get_children():
		_end_list.remove_child(ch)
		ch.queue_free()
	var titles := ["Vainqueur", "2e", "3e", "4e"]
	for i in rules.ranking.size():
		var pi: int = int(rules.ranking[i])
		var p: Dictionary = rules.players[pi]
		var col: Color = Board.PLAYER_COLORS[int(p["color"])]
		var size := 30
		if i == 0:
			size = 40
		var t: String = titles[i]
		var l := UI.label("%s : %s" % [t, str(p["name"])], size, col.lightened(0.25), true)
		_end_list.add_child(l)
	_pause.visible = false
	_end.visible = true
