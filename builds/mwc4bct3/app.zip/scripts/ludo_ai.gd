extends RefCounted
# Intelligence artificielle : note chaque coup possible et choisit le meilleur.
# Niveau 1 = facile (souvent au hasard), 2 = moyen, 3 = difficile.


# Nombre de pions adverses pouvant atteindre la case du circuit "a" en un lancer.
static func danger(rules, pi: int, a: int) -> int:
	var n := 0
	for pj in rules.players.size():
		if pj == pi or rules.ranking.has(pj):
			continue
		var col: int = rules.players[pj]["color"]
		for s in rules.players[pj]["tokens"]:
			var st: int = int(s)
			if st < 0 or st > 50:
				continue
			var d: int = posmod(a - int(rules.abs_index(col, st)), 52)
			if d >= 1 and d <= 6 and st + d <= 50:
				n += 1
	return n


static func score(rules, pi: int, mv: Dictionary, level: int) -> float:
	var col: int = rules.players[pi]["color"]
	var from: int = mv["from"]
	var to: int = mv["to"]
	var s := 0.0
	if from == -1:
		s += 45.0
	if to == 56:
		s += 70.0
	elif to > 50:
		if from <= 50:
			s += 25.0
	else:
		var a: int = rules.abs_index(col, to)
		var caps: Array = rules.captures_at(pi, to)
		for c in caps:
			var victim: int = int(rules.players[c[0]]["tokens"][c[1]])
			s += 85.0 + float(victim) * 0.6
		if rules.is_safe_abs(a):
			s += 22.0
		else:
			var risk: float = 14.0
			if level >= 3:
				risk = 24.0
			s -= risk * float(danger(rules, pi, a))
	if from >= 0 and from <= 50:
		var fa: int = rules.abs_index(col, from)
		if not rules.is_safe_abs(fa):
			s += 12.0 * float(danger(rules, pi, fa))
	s += float(to) * 0.4
	return s


static func choose(rules, pi: int, moves: Array, level: int) -> Dictionary:
	if moves.size() == 1:
		return moves[0]
	if level <= 1 and randf() < 0.6:
		return moves[randi() % moves.size()]
	var noise := 2.0
	if level == 2:
		noise = 18.0
	elif level <= 1:
		noise = 30.0
	var best: Dictionary = moves[0]
	var best_score := -99999.0
	for mv in moves:
		var sc: float = score(rules, pi, mv, level) + randf_range(-noise, noise)
		if sc > best_score:
			best_score = sc
			best = mv
	return best
