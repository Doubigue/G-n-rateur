extends CanvasLayer
# Menus : accueil, nouvelle partie, options, règles, statistiques.

signal start_requested(config: Dictionary)
signal continue_requested

const UI = preload("res://scripts/ui_kit.gd")
const Board = preload("res://scripts/board_3d.gd")

const TYPES := ["Humain", "IA facile", "IA moyenne", "IA difficile", "Absent"]
const YES_NO := ["Non", "Oui"]

var _root: Control
var _screens := {}
var _current: String = "main"
var _continue_btn: Button
var _setup: Dictionary = {}
var _name_edits: Array = []
var _error: Label
var _stats_label: Label


func build() -> void:
	layer = 10
	process_mode = Node.PROCESS_MODE_ALWAYS
	_root = Control.new()
	UI.full(_root)
	_root.theme = UI.make_theme(26)
	add_child(_root)
	var dim := ColorRect.new()
	dim.color = Color(0.03, 0.04, 0.08, 0.66)
	UI.full(dim)
	_root.add_child(dim)
	_setup = Settings.get_setup()
	_build_main()
	_build_setup()
	_build_options()
	_build_rules()
	_build_stats()
	show_screen("main")


func show_screen(id: String) -> void:
	visible = true
	_current = id
	for k in _screens.keys():
		var c: Control = _screens[k]
		c.visible = (k == id)
	if id == "main":
		_continue_btn.visible = Settings.has_save()
	elif id == "stats":
		_refresh_stats()
	elif id == "setup":
		_error.text = ""


func hide_all() -> void:
	visible = false


# Bouton retour d'Android : renvoie false s'il n'y a plus rien à fermer.
func back() -> bool:
	if _current != "main":
		show_screen("main")
		return true
	return false


func notify(text: String) -> void:
	show_screen("setup")
	_error.text = text


func _screen(id: String, title: String) -> VBoxContainer:
	var holder := Control.new()
	UI.full(holder)
	_root.add_child(holder)
	_screens[id] = holder
	var scroll := ScrollContainer.new()
	UI.place(scroll, 0.0, 0.0, 1.0, 1.0, 36.0, 70.0, -36.0, -40.0)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	holder.add_child(scroll)
	var vb := VBoxContainer.new()
	vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vb.add_theme_constant_override("separation", 14)
	scroll.add_child(vb)
	vb.add_child(UI.label(title, 52, UI.C_ACCENT, true))
	return vb


func _spacer(vb: VBoxContainer, h: float) -> void:
	var s := Control.new()
	s.custom_minimum_size = Vector2(0.0, h)
	s.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vb.add_child(s)


func _back_button(vb: VBoxContainer) -> void:
	_spacer(vb, 10.0)
	var b := UI.button("Retour")
	b.pressed.connect(func() -> void: show_screen("main"))
	vb.add_child(b)


# ---------------------------------------------------------------- accueil

func _build_main() -> void:
	var vb := _screen("main", "LUDO 3D ROYAL")
	vb.add_child(UI.label("Le jeu des petits chevaux, en relief", 26, UI.C_MUTED, true))
	_spacer(vb, 120.0)
	_continue_btn = UI.button("Continuer la partie", UI.C_GOOD, 34, 96.0)
	_continue_btn.pressed.connect(func() -> void: continue_requested.emit())
	vb.add_child(_continue_btn)
	var b_new := UI.button("Nouvelle partie", UI.C_ACCENT, 34, 96.0)
	b_new.pressed.connect(func() -> void: show_screen("setup"))
	vb.add_child(b_new)
	var b_opt := UI.button("Options")
	b_opt.pressed.connect(func() -> void: show_screen("options"))
	vb.add_child(b_opt)
	var b_rules := UI.button("Règles du jeu")
	b_rules.pressed.connect(func() -> void: show_screen("rules"))
	vb.add_child(b_rules)
	var b_stats := UI.button("Statistiques")
	b_stats.pressed.connect(func() -> void: show_screen("stats"))
	vb.add_child(b_stats)
	var b_quit := UI.button("Quitter", UI.C_BAD)
	b_quit.pressed.connect(func() -> void: get_tree().quit())
	vb.add_child(b_quit)


# ---------------------------------------------------------------- nouvelle partie

func _build_setup() -> void:
	var vb := _screen("setup", "Nouvelle partie")
	vb.add_child(UI.label("Joueurs", 30, UI.C_TEXT))
	for i in 4:
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 10)
		var sw := ColorRect.new()
		var pc: Color = Board.PLAYER_COLORS[i]
		sw.color = pc
		sw.custom_minimum_size = Vector2(56.0, 72.0)
		row.add_child(sw)
		var edit := LineEdit.new()
		var pl: Dictionary = _setup["players"][i]
		edit.text = str(pl["name"])
		edit.max_length = 12
		edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		edit.custom_minimum_size = Vector2(0.0, 72.0)
		edit.add_theme_font_size_override("font_size", 28)
		row.add_child(edit)
		_name_edits.append(edit)
		var idx: int = i
		var tb := UI.cycle("", TYPES, int(pl["type"]), func(v: int) -> void: _set_player_type(idx, v))
		tb.custom_minimum_size = Vector2(250.0, 72.0)
		row.add_child(tb)
		vb.add_child(row)

	_spacer(vb, 6.0)
	vb.add_child(UI.label("Mode et règles", 30, UI.C_TEXT))
	vb.add_child(UI.cycle("Mode", ["Classique (4 pions)", "Rapide (2 pions)"], int(_setup["mode"]), func(v: int) -> void: _setup["mode"] = v))
	var exit_idx := 0
	if bool(_setup["opts"]["exit_with_one"]):
		exit_idx = 1
	vb.add_child(UI.cycle("Sortie de base", ["6 seulement", "1 ou 6"], exit_idx, func(v: int) -> void: _setup["opts"]["exit_with_one"] = (v == 1)))
	_rule_toggle(vb, "Rejouer après un 6", "six_again")
	_rule_toggle(vb, "Rejouer après une capture", "capture_again")
	_rule_toggle(vb, "Rejouer après une arrivée", "home_again")
	_rule_toggle(vb, "Trois 6 de suite = tour perdu", "three_six_lose")
	_rule_toggle(vb, "Deux pions ensemble protégés", "double_safe")

	_error = UI.label("", 26, Color(1.0, 0.5, 0.45), true, true)
	vb.add_child(_error)
	var b_go := UI.button("Commencer", UI.C_ACCENT, 36, 100.0)
	b_go.pressed.connect(_on_start)
	vb.add_child(b_go)
	_back_button(vb)


func _set_player_type(index: int, value: int) -> void:
	_setup["players"][index]["type"] = value


func _rule_toggle(vb: VBoxContainer, text: String, key: String) -> void:
	var idx := 0
	if bool(_setup["opts"][key]):
		idx = 1
	vb.add_child(UI.cycle(text, YES_NO, idx, func(v: int) -> void: _setup["opts"][key] = (v == 1)))


func _on_start() -> void:
	var players: Array = []
	for i in 4:
		var t: int = int(_setup["players"][i]["type"])
		var edit: LineEdit = _name_edits[i]
		var nm: String = edit.text.strip_edges()
		if nm == "":
			nm = str(Board.COLOR_NAMES[i])
		_setup["players"][i]["name"] = nm
		if t == 4:
			continue
		players.append({"color": i, "name": nm, "ai": t})
	if players.size() < 2:
		_error.text = "Il faut au moins 2 joueurs."
		Sfx.play("error")
		return
	Settings.set_setup(_setup)
	var tokens := 4
	if int(_setup["mode"]) == 1:
		tokens = 2
	var opts: Dictionary = _setup["opts"]
	start_requested.emit({"players": players, "tokens": tokens, "opts": opts.duplicate()})


# ---------------------------------------------------------------- options

func _build_options() -> void:
	var vb := _screen("options", "Options")
	_slider(vb, "Volume de la musique", "music_volume")
	_slider(vb, "Volume des effets", "sfx_volume")
	_toggle(vb, "Vibrations", "vibration")
	var names: Array = []
	for th in Board.THEMES:
		names.append(str(th["name"]))
	_choice(vb, "Thème du plateau", "theme", names)
	_choice(vb, "Vitesse du jeu", "speed", ["Normale", "Rapide", "Très rapide"])
	_toggle(vb, "Jouer seul le coup unique", "auto_move")
	_toggle(vb, "Caméra tournée vers le joueur", "auto_camera")
	_toggle(vb, "Secouer pour lancer le dé", "shake_to_roll")
	_toggle(vb, "Ombres", "shadows")
	_toggle(vb, "Pions jouables en surbrillance", "show_hints")
	_back_button(vb)


func _slider(vb: VBoxContainer, text: String, key: String) -> void:
	vb.add_child(UI.label(text, 26, UI.C_TEXT))
	var s := HSlider.new()
	s.min_value = 0.0
	s.max_value = 1.0
	s.step = 0.05
	s.value = float(Settings.get_v(key))
	s.custom_minimum_size = Vector2(0.0, 60.0)
	s.value_changed.connect(func(v: float) -> void: Settings.set_v(key, v))
	vb.add_child(s)


func _toggle(vb: VBoxContainer, text: String, key: String) -> void:
	var idx := 0
	if bool(Settings.get_v(key)):
		idx = 1
	vb.add_child(UI.cycle(text, YES_NO, idx, func(v: int) -> void: Settings.set_v(key, v == 1)))


func _choice(vb: VBoxContainer, text: String, key: String, options: Array) -> void:
	vb.add_child(UI.cycle(text, options, int(Settings.get_v(key)), func(v: int) -> void: Settings.set_v(key, v)))


# ---------------------------------------------------------------- règles

func _build_rules() -> void:
	var vb := _screen("rules", "Règles du jeu")
	var lines := [
		"But : amener tous ses pions de la base jusqu'au centre du plateau avant les autres.",
		"Sortir : il faut un 6 pour sortir un pion de sa base (ou un 1 si la règle est activée).",
		"Avancer : le pion avance du nombre indiqué par le dé, dans le sens des aiguilles d'une montre.",
		"Capturer : arriver sur une case occupée par un adversaire renvoie son pion à sa base.",
		"Cases sûres : les cases de départ colorées et les cases à étoile dorée protègent de la capture.",
		"Arrivée : après un tour complet, le pion entre dans le couloir de sa couleur. Il faut le nombre exact pour atteindre le centre.",
		"Rejouer : selon les règles choisies, un 6, une capture ou une arrivée donne un lancer de plus.",
		"Commandes : touchez le dé ou le bouton pour lancer (ou secouez le téléphone), touchez un pion pour le jouer, glissez pour tourner le plateau, pincez pour zoomer.",
	]
	for line in lines:
		var txt: String = line
		vb.add_child(UI.label(txt, 26, UI.C_TEXT, false, true))
	_back_button(vb)


# ---------------------------------------------------------------- statistiques

func _build_stats() -> void:
	var vb := _screen("stats", "Statistiques")
	_stats_label = UI.label("", 30, UI.C_TEXT, true, true)
	vb.add_child(_stats_label)
	_spacer(vb, 20.0)
	var b := UI.button("Remettre à zéro", UI.C_BAD)
	b.pressed.connect(func() -> void:
		Settings.reset_stats()
		_refresh_stats()
	)
	vb.add_child(b)
	_back_button(vb)


func _refresh_stats() -> void:
	var t := ""
	t += "Parties terminées : %d\n" % Settings.get_stat("games")
	t += "Victoires des joueurs : %d\n" % Settings.get_stat("wins_human")
	t += "Victoires de l'IA : %d\n" % Settings.get_stat("wins_ai")
	t += "Pions capturés : %d\n" % Settings.get_stat("captures")
	t += "Lancers de dé : %d\n" % Settings.get_stat("rolls")
	t += "Nombre de 6 : %d" % Settings.get_stat("sixes")
	_stats_label.text = t
