extends RefCounted
# Petite boîte à outils pour construire l'interface par code.

const C_PANEL := Color(0.1, 0.12, 0.18, 0.95)
const C_ACCENT := Color(0.95, 0.72, 0.18)
const C_TEXT := Color(0.96, 0.96, 0.98)
const C_MUTED := Color(0.72, 0.75, 0.82)
const C_BTN := Color(0.2, 0.24, 0.34)
const C_GOOD := Color(0.16, 0.6, 0.32)
const C_BAD := Color(0.7, 0.2, 0.2)


static func box(color: Color, radius: int = 18, margin: int = 14) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = color
	sb.set_corner_radius_all(radius)
	sb.set_content_margin_all(float(margin))
	return sb


static func full(c: Control) -> void:
	place(c, 0.0, 0.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0)


# Ancres (0..1) puis décalages en pixels : gauche, haut, droite, bas.
static func place(c: Control, al: float, at: float, ar: float, ab: float, ol: float, ot: float, o_r: float, ob: float) -> void:
	c.anchor_left = al
	c.anchor_top = at
	c.anchor_right = ar
	c.anchor_bottom = ab
	c.offset_left = ol
	c.offset_top = ot
	c.offset_right = o_r
	c.offset_bottom = ob


static func label(text: String, size: int = 26, color: Color = C_TEXT, center: bool = false, wrap: bool = false) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	if center:
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	if wrap:
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l


static func button(text: String, color: Color = C_BTN, font_size: int = 30, min_h: float = 84.0) -> Button:
	var b := Button.new()
	b.text = text
	b.focus_mode = Control.FOCUS_NONE
	b.custom_minimum_size = Vector2(0.0, min_h)
	b.add_theme_font_size_override("font_size", font_size)
	b.add_theme_stylebox_override("normal", box(color))
	b.add_theme_stylebox_override("hover", box(color.lightened(0.08)))
	b.add_theme_stylebox_override("pressed", box(color.darkened(0.25)))
	b.add_theme_stylebox_override("disabled", box(Color(color.r, color.g, color.b, 0.35)))
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	var fc: Color = C_TEXT
	if color.get_luminance() > 0.55:
		fc = Color(0.1, 0.1, 0.12)
	b.add_theme_color_override("font_color", fc)
	b.add_theme_color_override("font_hover_color", fc)
	b.add_theme_color_override("font_pressed_color", fc)
	b.add_theme_color_override("font_focus_color", fc)
	b.add_theme_color_override("font_disabled_color", Color(fc.r, fc.g, fc.b, 0.5))
	b.pressed.connect(func() -> void: Sfx.play("click"))
	return b


# Bouton qui fait défiler une liste de choix : "Libellé : valeur".
static func cycle(prefix: String, options: Array, index: int, on_change: Callable, font_size: int = 26) -> Button:
	var b := button("", C_BTN, font_size, 72.0)
	var start: int = clampi(index, 0, options.size() - 1)
	b.set_meta("idx", start)
	b.text = cycle_text(prefix, str(options[start]))
	b.pressed.connect(func() -> void:
		var i: int = (int(b.get_meta("idx")) + 1) % options.size()
		b.set_meta("idx", i)
		var txt: String = str(options[i])
		if prefix != "":
			txt = "%s : %s" % [prefix, txt]
		b.text = txt
		on_change.call(i)
	)
	return b


static func cycle_text(prefix: String, value: String) -> String:
	if prefix == "":
		return value
	return "%s : %s" % [prefix, value]


static func make_theme(font_size: int) -> Theme:
	var th := Theme.new()
	th.default_font_size = font_size
	return th
