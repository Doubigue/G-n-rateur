extends RefCounted
# Règles du Ludo (logique pure, sans affichage).
# Position d'un pion ("step") : -1 = base, 0..50 = circuit, 51..55 = couloir final, 56 = arrivée.

const START := [0, 13, 26, 39]
const SAFE := [0, 8, 13, 21, 26, 34, 39, 47]
const BASE := -1
const LAST_LOOP := 50
const HOME := 56

var players: Array = []
var current: int = 0
var tokens_per_player: int = 4
var ranking: Array = []
var six_streak: int = 0
var opts: Dictionary = {}


func setup(config: Dictionary) -> void:
	players.clear()
	ranking.clear()
	tokens_per_player = int(config.get("tokens", 4))
	var o = config.get("opts", {})
	opts = o.duplicate()
	for pc in config["players"]:
		var toks: Array = []
		for i in tokens_per_player:
			toks.append(BASE)
		players.append({
			"color": int(pc["color"]),
			"name": str(pc["name"]),
			"ai": int(pc["ai"]),
			"tokens": toks,
		})
	current = 0
	six_streak = 0


func opt(key: String) -> bool:
	return bool(opts.get(key, false))


func abs_index(color: int, step: int) -> int:
	return (int(START[color]) + step) % 52


func is_safe_abs(a: int) -> bool:
	return SAFE.has(a)


func legal_moves(pi: int, dice: int) -> Array:
	var res: Array = []
	var toks: Array = players[pi]["tokens"]
	for i in toks.size():
		var s: int = toks[i]
		if s == HOME:
			continue
		if s == BASE:
			if dice == 6 or (dice == 1 and opt("exit_with_one")):
				res.append({"token": i, "from": BASE, "to": 0})
		elif s + dice <= HOME:
			res.append({"token": i, "from": s, "to": s + dice})
	return res


func captures_at(pi: int, to: int) -> Array:
	var out: Array = []
	if to < 0 or to > LAST_LOOP:
		return out
	var a: int = abs_index(players[pi]["color"], to)
	if SAFE.has(a):
		return out
	for pj in players.size():
		if pj == pi:
			continue
		var found: Array = []
		var toks: Array = players[pj]["tokens"]
		for tj in toks.size():
			var s: int = toks[tj]
			if s >= 0 and s <= LAST_LOOP and abs_index(players[pj]["color"], s) == a:
				found.append([pj, tj])
		if found.size() >= 2 and opt("double_safe"):
			continue
		out.append_array(found)
	return out


func apply_move(pi: int, token: int, to: int) -> Dictionary:
	var caps: Array = captures_at(pi, to)
	for c in caps:
		players[c[0]]["tokens"][c[1]] = BASE
	players[pi]["tokens"][token] = to
	var finished := false
	if to == HOME and is_finished(pi) and not ranking.has(pi):
		ranking.append(pi)
		finished = true
	return {"captured": caps, "home": to == HOME, "finished": finished}


func is_finished(pi: int) -> bool:
	for s in players[pi]["tokens"]:
		if int(s) != HOME:
			return false
	return true


func home_count(pi: int) -> int:
	var n := 0
	for s in players[pi]["tokens"]:
		if int(s) == HOME:
			n += 1
	return n


func is_game_over() -> bool:
	return ranking.size() >= players.size() - 1


func finalize_ranking() -> void:
	for pi in players.size():
		if not ranking.has(pi):
			ranking.append(pi)


func next_player() -> void:
	for i in players.size():
		current = (current + 1) % players.size()
		if not ranking.has(current):
			return


func to_config() -> Dictionary:
	var ps: Array = []
	for p in players:
		ps.append({"color": p["color"], "name": p["name"], "ai": p["ai"]})
	return {"players": ps, "tokens": tokens_per_player, "opts": opts.duplicate()}


func to_dict() -> Dictionary:
	return {
		"players": players,
		"current": current,
		"tokens": tokens_per_player,
		"ranking": ranking,
		"six_streak": six_streak,
		"opts": opts,
	}


# Recharge une partie sauvegardée (JSON : les nombres reviennent en float). Renvoie false si invalide.
func from_dict(d: Dictionary) -> bool:
	if not (d.has("players") and d["players"] is Array and d.has("opts") and d["opts"] is Dictionary):
		return false
	var src: Array = d["players"]
	if src.size() < 2 or src.size() > 4:
		return false
	players.clear()
	ranking.clear()
	tokens_per_player = int(d.get("tokens", 4))
	for p in src:
		if not (p is Dictionary and p.has("tokens") and p["tokens"] is Array):
			return false
		var toks: Array = []
		for s in p["tokens"]:
			toks.append(clampi(int(s), BASE, HOME))
		if toks.size() != tokens_per_player:
			return false
		players.append({
			"color": clampi(int(p.get("color", 0)), 0, 3),
			"name": str(p.get("name", "Joueur")),
			"ai": clampi(int(p.get("ai", 0)), 0, 3),
			"tokens": toks,
		})
	for r in d.get("ranking", []):
		ranking.append(int(r))
	current = clampi(int(d.get("current", 0)), 0, players.size() - 1)
	six_streak = int(d.get("six_streak", 0))
	opts = d["opts"].duplicate()
	if ranking.has(current):
		next_player()
	return not is_game_over()
