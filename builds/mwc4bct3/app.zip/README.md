# Ludo 3D Royal

Jeu de Ludo (petits chevaux) en 3D pour Android, fait avec **Godot 4.4** et GDScript.
Tout est généré par code : plateau, pions, dé, sons et musique. Le projet ne contient aucun fichier image, modèle 3D ou audio.

## Fonctionnalités

- 2 à 4 joueurs, chacun humain ou IA (facile, moyenne, difficile), noms modifiables
- Plateau 3D avec ombres, ciel, matériaux brillants, 3 thèmes (Classique, Bois précieux, Nuit)
- Dé 3D animé : bouton, toucher le dé, ou secouer le téléphone
- Pions animés case par case, captures, confettis à l'arrivée et à la victoire
- Caméra : glisser pour tourner, pincer pour zoomer, 3 vues, rotation automatique vers le joueur
- Sons et musique synthétisés, volumes séparés, vibrations
- Modes Classique (4 pions) et Rapide (2 pions)
- Règles au choix : sortie sur 6 ou sur 1 et 6, rejouer après 6 / capture / arrivée, trois 6 = tour perdu, paires protégées
- Sauvegarde automatique et bouton « Continuer la partie »
- Classement de fin de partie, statistiques, pause, vitesse de jeu, aide visuelle, bouton retour Android

## Ouvrir et tester

1. Installer Godot 4.4 (version standard).
2. Importer le dossier (fichier `project.godot`).
3. Appuyer sur F5. La souris remplace le doigt, la molette zoome.

## Obtenir l'APK

**Avec GitHub Actions** : pousser le projet sur un dépôt GitHub. Le fichier `.github/workflows/build-android.yml` exporte un APK de test et le publie dans les artefacts de l'exécution (`Ludo3D-apk`).

**Depuis Godot** : Projet > Exporter > Android (le préréglage est déjà dans `export_presets.cfg`), après avoir installé les modèles d'exportation et indiqué le SDK Android dans les paramètres de l'éditeur.

L'identifiant du paquet est `com.dlvibestudio.ludo3d` ; il se change dans `export_presets.cfg`.

## Organisation

| Fichier | Rôle |
| --- | --- |
| `scripts/game.gd` | Déroulement des tours, entrées tactiles, animations |
| `scripts/ludo_rules.gd` | Règles du jeu (sans affichage) |
| `scripts/ludo_ai.gd` | Choix des coups de l'IA |
| `scripts/board_3d.gd` | Plateau, lumières, thèmes |
| `scripts/token_3d.gd`, `scripts/dice_3d.gd` | Pions et dé |
| `scripts/camera_rig.gd` | Caméra orbitale |
| `scripts/hud.gd`, `scripts/menu.gd`, `scripts/ui_kit.gd` | Interface |
| `scripts/settings.gd`, `scripts/sfx.gd` | Réglages, sauvegarde, sons |

Si le jeu ne démarre pas sur un vieux téléphone, remplacer `mobile` par `gl_compatibility` dans la section `[rendering]` de `project.godot`.
