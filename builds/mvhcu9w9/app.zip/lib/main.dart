import 'dart:async';
import 'dart:collection';
import 'dart:convert';
import 'dart:io';

import 'package:archive/archive.dart';
import 'package:ffmpeg_kit_flutter_new/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_new/return_code.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:gal/gal.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shelf/shelf_io.dart' as shelf_io;
import 'package:shelf_static/shelf_static.dart';

import 'preview_page.dart';

void main() {
  runZonedGuarded(
    () => runApp(
      MaterialApp(
        theme: ThemeData(colorSchemeSeed: Colors.indigo, useMaterial3: true),
        home: const Home(),
      ),
    ),
    (e, st) => debugPrint('Erreur non gérée : $e\n$st'),
  );
}

/// Horloge virtuelle + enregistreur audio, injectés AVANT le chargement de la page.
///
/// Temps : requestAnimationFrame, setTimeout, setInterval, Date.now,
/// performance.now, animations CSS / Web Animations / SVG sont pilotés par
/// window.__seek(t) (t en ms).
///
/// Audio : les sons lancés par la page (new Audio().play(), <audio>, <video>,
/// Web Audio AudioBufferSourceNode.start) ne sont PAS joués : ils sont
/// enregistrés avec leur instant virtuel dans window.__audioEvents, puis
/// mixés dans la vidéo par FFmpeg.
const _shim = r'''
(function () {
  let virtual = 0, id = 0, uid = 0, tid = 0, rafs = [], rafCount = 0,
      toCount = 0, ivCount = 0, saw = false, autoDone = false;
  const d0 = Date.now();
  const timers = new Map();
  const audioEvents = window.__audioEvents = [];

  ['animationstart', 'transitionstart'].forEach(e =>
    document.addEventListener(e, () => { saw = true; }, true));

  // ---- Horloge virtuelle
  window.requestAnimationFrame = cb => { rafCount++; rafs.push([++id, cb]); return id; };
  window.cancelAnimationFrame = i => { rafs = rafs.filter(r => r[0] !== i); };
  const mk = s => (typeof s === 'function' ? s : () => (0, eval)(String(s)));
  window.setTimeout = (cb, ms, ...a) => {
    toCount++;
    timers.set(++tid, { due: virtual + Math.max(+ms || 0, 0), cb: mk(cb), a, iv: 0 });
    return tid;
  };
  window.setInterval = (cb, ms, ...a) => {
    ivCount++;
    const iv = Math.max(+ms || 0, 1);
    timers.set(++tid, { due: virtual + iv, cb: mk(cb), a, iv });
    return tid;
  };
  window.clearTimeout = window.clearInterval = i => { timers.delete(i); };
  performance.now = () => virtual;
  Date.now = () => d0 + virtual;

  // ---- Enregistrement audio : éléments <audio>/<video>
  const mid = new WeakMap();
  const idOf = el => { if (!mid.has(el)) mid.set(el, ++uid); return mid.get(el); };
  HTMLMediaElement.prototype.play = function () {
    let s = this.currentSrc || this.src;
    if (!s) { const so = this.querySelector('source'); if (so) s = so.src; }
    if (s) {
      audioEvents.push({
        k: 'play', id: idOf(this), src: new URL(s, document.baseURI).href,
        t: virtual, off: this.currentTime || 0, loop: !!this.loop,
        rate: this.playbackRate || 1, vol: this.muted ? 0 : this.volume
      });
    }
    return Promise.resolve();
  };
  HTMLMediaElement.prototype.pause = function () {
    audioEvents.push({ k: 'stop', id: idOf(this), t: virtual });
  };

  // ---- Enregistrement audio : Web Audio API
  const abUrl = new WeakMap(), bufUrl = new WeakMap();
  const of = window.fetch;
  if (of) {
    window.fetch = function (input) {
      let url = null;
      try { url = new URL(typeof input === 'string' ? input : input.url, document.baseURI).href; } catch (e) {}
      return of.apply(this, arguments).then(res => {
        const ab = res.arrayBuffer.bind(res);
        res.arrayBuffer = () => ab().then(b => { if (url) abUrl.set(b, url); return b; });
        return res;
      });
    };
  }
  const oo = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (m, u) {
    this.addEventListener('load', () => {
      try {
        if (this.response instanceof ArrayBuffer)
          abUrl.set(this.response, new URL(u, document.baseURI).href);
      } catch (e) {}
    });
    return oo.apply(this, arguments);
  };
  const AC = window.BaseAudioContext || window.AudioContext || window.webkitAudioContext;
  if (AC) {
    const od = AC.prototype.decodeAudioData;
    AC.prototype.decodeAudioData = function (ab, ok, err) {
      const url = abUrl.get(ab);
      const tag = b => { if (url && b) bufUrl.set(b, url); return b; };
      const p = od.call(this, ab, ok ? b => ok(tag(b)) : undefined, err);
      return p && p.then ? p.then(tag) : p;
    };
  }
  const ASN = window.AudioBufferSourceNode;
  if (ASN) {
    const rel = (node, when) => {
      const now = node.context.currentTime;
      return when && when > now ? (when - now) * 1000 : 0;
    };
    ASN.prototype.start = function (when, offset, dur) {
      const url = bufUrl.get(this.buffer);
      if (url) {
        this.__id = ++uid;
        audioEvents.push({
          k: 'play', id: this.__id, src: url, t: virtual + rel(this, when),
          off: offset || 0, loop: !!this.loop, rate: this.playbackRate.value,
          vol: 1, dur: dur
        });
      }
    };
    ASN.prototype.stop = function (when) {
      if (this.__id)
        audioEvents.push({ k: 'stop', id: this.__id, t: virtual + rel(this, when) });
    };
  }

  window.__isAnimated = () =>
    saw || rafCount > 0 || ivCount > 0 || toCount > 1 ||
    document.getAnimations().length > 0 ||
    !!document.querySelector('animate,animateTransform,animateMotion,set');

  window.__seek = function (t) {
    let guard = 0;
    while (guard++ < 20000) {
      let best = null, bid = null;
      timers.forEach((v, k) => { if (v.due <= t && (!best || v.due < best.due)) { best = v; bid = k; } });
      if (!best) break;
      virtual = Math.max(virtual, best.due);
      if (best.iv) best.due += best.iv; else timers.delete(bid);
      try { best.cb(...best.a); } catch (e) {}
    }
    virtual = t;
    if (!autoDone) {
      autoDone = true;
      document.querySelectorAll('audio[autoplay],video[autoplay]').forEach(el => el.play());
    }
    document.getAnimations().forEach(a => { try { a.pause(); a.currentTime = t; } catch (e) {} });
    document.querySelectorAll('svg').forEach(s => {
      try { s.pauseAnimations(); s.setCurrentTime(t / 1000); } catch (e) {}
    });
    const cbs = rafs; rafs = [];
    cbs.forEach(([_, cb]) => { try { cb(virtual); } catch (e) {} });
  };
})();
''';

const _sample = '''
<html><body style="margin:0;background:#111;display:grid;place-items:center;height:100vh">
<div style="width:120px;height:120px;border-radius:24px;background:#6c8cff;
animation:m 2s ease-in-out infinite alternate">
</div>
<style>@keyframes m{from{transform:translateX(-120px) rotate(0)}
to{transform:translateX(120px) rotate(360deg);background:#ff6c9a}}</style>
</body></html>
''';

/// Un son joué par la page, avec son instant de départ (ms) dans la vidéo.
class _Snd {
  _Snd(this.file, this.t, this.off, this.vol, this.rate, this.loop, this.dur);
  final String file;
  final double t, off, vol, rate;
  final bool loop;
  double? dur; // secondes
}

String _n(double v) => v.toStringAsFixed(3);

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final _html = TextEditingController(text: _sample);
  final _w = TextEditingController(text: '720');
  final _h = TextEditingController(text: '1280');
  final _fps = TextEditingController(text: '30');
  final _dur = TextEditingController(text: '4');

  InAppWebViewController? _ctl;
  Completer<void>? _loaded;
  HttpServer? _server;
  bool _busy = false;
  double _progress = 0;
  String _status = '';

  // Projet zip (HTML + dossiers de sons, images…) servi en local
  String? _projectDir; // dossier extrait
  String? _entryUrl; // http://127.0.0.1:PORT/index.html
  String? _projectName;

  String? _audioPath; // musique ajoutée par l'utilisateur
  String? _audioName;
  String? _lastOut;

  double get _wv => double.tryParse(_w.text) ?? 720;
  double get _hv => double.tryParse(_h.text) ?? 1280;

  @override
  void dispose() {
    _server?.close(force: true);
    super.dispose();
  }

  /// Exécute une action en affichant l'erreur à l'écran au lieu de l'avaler en silence.
  Future<void> _safe(Future<void> Function() f) async {
    try {
      await f();
    } catch (e) {
      if (mounted) {
        setState(() {
          _busy = false;
          _status = 'Erreur : $e';
        });
      }
    }
  }

  /// Ouvre le sélecteur Android. FileType.any + contrôle de l'extension :
  /// le filtre par extension grise parfois les fichiers selon l'explorateur.
  Future<PlatformFile?> _choose(List<String> exts, String label) async {
    final r = await FilePicker.platform.pickFiles(
      type: FileType.any,
      allowMultiple: false,
      withData: false,
    );
    final f = r?.files.single;
    if (f == null || f.path == null) return null; // annulé
    final low = f.name.toLowerCase();
    if (!exts.any((e) => low.endsWith('.$e'))) {
      _snack('Choisis un fichier $label');
      return null;
    }
    return f;
  }

  void _openPreview() {
    final p = _lastOut;
    if (p == null) return;
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => PreviewPage(path: p)),
    );
  }

  void _snack(String msg) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));

  /// Charge la source courante (projet ou code collé) et attend qu'elle soit prête.
  Future<void> _load() async {
    _loaded = Completer<void>();
    if (_projectDir != null) {
      await _ctl!.loadUrl(urlRequest: URLRequest(url: WebUri(_entryUrl!)));
    } else {
      await _ctl!.loadData(data: _html.text);
    }
    await _loaded!.future.timeout(const Duration(seconds: 20));
    await Future.delayed(const Duration(milliseconds: 800)); // décodage audio, etc.
  }

  Future<bool> _isAnimated() async {
    final r = await _ctl!.evaluateJavascript(source: 'window.__isAnimated()');
    return r == true || r.toString() == 'true';
  }

  /// Essaie une nouvelle source ; la garde seulement si elle est animée.
  Future<bool> _tryOpen(
      {String? dir, String? url, String? name, String? html}) async {
    final prevDir = _projectDir, prevUrl = _entryUrl, prevName = _projectName;
    final prevHtml = _html.text;
    _projectDir = dir;
    _entryUrl = url;
    _projectName = name;
    if (html != null) _html.text = html;
    try {
      await _load();
      if (await _isAnimated()) return true;
    } catch (_) {}
    _projectDir = prevDir;
    _entryUrl = prevUrl;
    _projectName = prevName;
    _html.text = prevHtml;
    try {
      await _load();
    } catch (_) {}
    return false;
  }

  Future<void> _pickHtml() => _safe(_pickHtmlImpl);

  Future<void> _pickHtmlImpl() async {
    final f = await _choose(['html', 'htm'], '.html');
    final path = f?.path;
    if (path == null) return;
    setState(() {
      _busy = true;
      _status = 'Vérification de l\'animation…';
    });
    final ok = await _tryOpen(html: File(path).readAsStringSync());
    setState(() {
      _busy = false;
      _status = ok ? 'HTML animé accepté ✓' : '';
    });
    if (!ok) _snack('Refusé : ce HTML ne contient aucune animation.');
  }

  /// Projet = .zip contenant le HTML et ses dossiers (sons, images, scripts…).
  Future<void> _pickProject() => _safe(_pickProjectImpl);

  Future<void> _pickProjectImpl() async {
    final file = await _choose(['zip'], '.zip');
    if (file?.path == null) return;
    setState(() {
      _busy = true;
      _status = 'Extraction du projet…';
    });
    HttpServer? srv;
    try {
      final tmp = await getTemporaryDirectory();
      final root = Directory('${tmp.path}/project');
      if (root.existsSync()) root.deleteSync(recursive: true);
      root.createSync(recursive: true);

      final htmls = <String>[];
      final arc = ZipDecoder().decodeBytes(File(file!.path!).readAsBytesSync());
      for (final f in arc) {
        if (!f.isFile || f.name.contains('..') || f.name.startsWith('__MACOSX')) {
          continue;
        }
        File('${root.path}/${f.name}')
          ..createSync(recursive: true)
          ..writeAsBytesSync(f.content as List<int>);
        final low = f.name.toLowerCase();
        if (low.endsWith('.html') || low.endsWith('.htm')) htmls.add(f.name);
      }
      if (htmls.isEmpty) throw Exception('aucun fichier .html dans le zip');

      // Entrée = index.html le moins profond, sinon le premier .html
      htmls.sort((a, b) {
        final da = '/'.allMatches(a).length, db = '/'.allMatches(b).length;
        if (da != db) return da.compareTo(db);
        final ia = a.toLowerCase().endsWith('index.html') ? 0 : 1;
        final ib = b.toLowerCase().endsWith('index.html') ? 0 : 1;
        return ia.compareTo(ib);
      });
      final entry = htmls.first;

      srv = await shelf_io.serve(
          createStaticHandler(root.path), InternetAddress.loopbackIPv4, 0);
      final url = 'http://127.0.0.1:${srv.port}/'
          '${entry.split('/').map(Uri.encodeComponent).join('/')}';

      setState(() => _status = 'Vérification de l\'animation…');
      final ok = await _tryOpen(
          dir: root.path, url: url, name: '${file.name} → $entry');
      if (ok) {
        await _server?.close(force: true);
        _server = srv;
        setState(() => _status = 'Projet animé accepté ✓');
      } else {
        await srv.close(force: true);
        setState(() => _status = '');
        _snack('Refusé : ce projet ne contient aucune animation.');
      }
    } catch (e) {
      await srv?.close(force: true);
      setState(() => _status = 'Erreur : $e');
    } finally {
      setState(() => _busy = false);
    }
  }

  Future<void> _closeProject() async {
    setState(() {
      _projectDir = null;
      _entryUrl = null;
      _projectName = null;
    });
    try {
      await _load();
    } catch (_) {}
  }

  Future<void> _pickAudio() => _safe(_pickAudioImpl);

  Future<void> _pickAudioImpl() async {
    final r = await FilePicker.platform
        .pickFiles(type: FileType.any, allowMultiple: false, withData: false);
    final f = r?.files.single;
    if (f == null || f.path == null) return;
    setState(() {
      _audioPath = f!.path;
      _audioName = f.name;
    });
  }

  /// URL vue par la page -> chemin du fichier dans le projet extrait.
  String? _localFile(String src) {
    final dir = _projectDir;
    final u = Uri.tryParse(src);
    if (dir == null || u == null || u.host != '127.0.0.1') return null;
    final rel = Uri.decodeComponent(u.path);
    if (rel.contains('..')) return null;
    final f = File('$dir$rel');
    return f.existsSync() ? f.path : null;
  }

  List<_Snd> _parseSounds(String json, double totalSec) {
    final open = <int, _Snd>{};
    final out = <_Snd>[];
    for (final e in jsonDecode(json) as List) {
      final id = (e['id'] as num).toInt();
      final t = (e['t'] as num).toDouble();
      if (e['k'] == 'play') {
        final file = _localFile(e['src'] as String);
        final vol = (e['vol'] as num?)?.toDouble() ?? 1;
        if (file == null || vol <= 0 || t / 1000 >= totalSec) continue;
        final s = _Snd(
          file,
          t,
          (e['off'] as num?)?.toDouble() ?? 0,
          vol.clamp(0.0, 1.0).toDouble(),
          ((e['rate'] as num?)?.toDouble() ?? 1).clamp(0.5, 2.0).toDouble(),
          e['loop'] == true,
          (e['dur'] as num?)?.toDouble(),
        );
        open[id] = s;
        out.add(s);
      } else if (e['k'] == 'stop') {
        final s = open.remove(id);
        if (s != null && s.dur == null && t > s.t) s.dur = (t - s.t) / 1000;
      }
    }
    return out.take(64).toList();
  }

  Future<void> _export() async {
    final fps = int.tryParse(_fps.text) ?? 30;
    final dur = double.tryParse(_dur.text) ?? 4;
    final total = (dur * fps).round();

    setState(() {
      _busy = true;
      _progress = 0;
      _lastOut = null;
      _status = 'Chargement de la page…';
    });

    try {
      final tmp = await getTemporaryDirectory();
      final dir = Directory('${tmp.path}/frames');
      if (dir.existsSync()) dir.deleteSync(recursive: true);
      dir.createSync(recursive: true);

      await _load();
      if (!await _isAnimated()) {
        throw Exception('ce HTML n\'est pas animé, export refusé');
      }

      // 1) Capture image par image (les sons sont enregistrés par le shim)
      for (var i = 0; i < total; i++) {
        await _ctl!
            .evaluateJavascript(source: 'window.__seek(${i * 1000 / fps});');
        await Future.delayed(const Duration(milliseconds: 40));
        final png = await _ctl!.takeScreenshot(
          screenshotConfiguration: ScreenshotConfiguration(
            compressFormat: CompressFormat.PNG,
            snapshotWidth: _wv,
          ),
        );
        if (png == null) throw Exception('capture impossible (image $i)');
        File('${dir.path}/frame_${i.toString().padLeft(5, '0')}.png')
            .writeAsBytesSync(png);
        setState(() {
          _progress = (i + 1) / total * 0.8;
          _status = 'Capture ${i + 1}/$total';
        });
      }

      // 2) Récupère les sons joués par la page
      final raw = (await _ctl!.evaluateJavascript(
                  source: 'JSON.stringify(window.__audioEvents||[])'))
              ?.toString() ??
          '[]';
      final sounds = _parseSounds(raw, dur);

      // 3) Construit le mixage FFmpeg : musique + sons de la page
      setState(() => _status = 'Encodage MP4 (${sounds.length} son(s) mixé(s))…');
      final args = <String>[
        '-y', '-framerate', '$fps', '-i', '${dir.path}/frame_%05d.png',
      ];
      final chains = <String>['[0:v]scale=trunc(iw/2)*2:trunc(ih/2)*2[v]'];
      final mix = <String>[];
      var idx = 1;
      const fmt = 'aformat=sample_rates=44100:channel_layouts=stereo';

      if (_audioPath != null) {
        args.addAll(['-stream_loop', '-1', '-i', _audioPath!]);
        final fade = dur > 2 ? ',afade=t=out:st=${_n(dur - 1)}:d=1' : '';
        final mv = sounds.isEmpty ? 1.0 : 0.6; // musique plus basse sous les sons
        chains.add('[$idx:a]$fmt,atrim=duration=${_n(dur)},'
            'asetpts=PTS-STARTPTS,volume=${_n(mv)}$fade[m]');
        mix.add('[m]');
        idx++;
      }

      for (var j = 0; j < sounds.length; j++) {
        final s = sounds[j];
        if (s.loop) args.addAll(['-stream_loop', '-1']);
        args.addAll(['-i', s.file]);
        final remain = dur - s.t / 1000;
        final sd = s.dur;
        final d = (sd != null && sd < remain) ? sd : remain;
        chains.add('[$idx:a]$fmt'
            '${s.off > 0 ? ',atrim=start=${_n(s.off)}' : ''}'
            ',asetpts=PTS-STARTPTS'
            '${s.rate != 1 ? ',atempo=${_n(s.rate)}' : ''}'
            ',atrim=duration=${_n(d)},volume=${_n(s.vol)}'
            ',adelay=${s.t.round()}:all=1[s$j]');
        mix.add('[s$j]');
        idx++;
      }

      if (mix.isNotEmpty) {
        chains.add('${mix.join()}amix=inputs=${mix.length}:duration=longest'
            ':normalize=0,alimiter=limit=0.95,atrim=duration=${_n(dur)}[aout]');
      }

      final out =
          '${tmp.path}/export_${DateTime.now().millisecondsSinceEpoch}.mp4';
      args.addAll(['-filter_complex', chains.join(';'), '-map', '[v]']);
      if (mix.isNotEmpty) {
        args.addAll(['-map', '[aout]', '-c:a', 'aac', '-b:a', '192k']);
      }
      args.addAll([
        '-c:v', 'libx264', '-pix_fmt', 'yuv420p',
        '-t', _n(dur), '-movflags', '+faststart', out,
      ]);

      final session = await FFmpegKit.executeWithArguments(args);
      if (!ReturnCode.isSuccess(await session.getReturnCode())) {
        final logs = await session.getAllLogsAsString() ?? '';
        final tail = logs.length > 300 ? logs.substring(logs.length - 300) : logs;
        throw Exception('FFmpeg a échoué\n$tail');
      }
      dir.deleteSync(recursive: true);

      // 4) Enregistrement direct dans la galerie
      setState(() => _status = 'Enregistrement dans la galerie…');
      try {
        if (!await Gal.hasAccess(toAlbum: true)) {
          await Gal.requestAccess(toAlbum: true);
        }
        await Gal.putVideo(out, album: 'HTML2MP4');
      } catch (e) {
        setState(() => _status = 'Galerie indisponible ($e), utilise Partager.');
      }

      setState(() {
        _progress = 1;
        _lastOut = out;
        _status = 'Vidéo terminée ✓'
            '${sounds.isEmpty ? '' : ' (${sounds.length} son(s) de la page mixé(s))'}';
      });
      if (mounted) _openPreview(); // ouvre le lecteur d'aperçu
    } catch (e) {
      setState(() => _status = 'Erreur : $e');
    } finally {
      setState(() => _busy = false);
    }
  }

  Widget _num(String label, TextEditingController c) => Expanded(
        child: Padding(
          padding: const EdgeInsets.only(right: 8),
          child: TextField(
            controller: c,
            enabled: !_busy,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(labelText: label, isDense: true),
            onChanged: (_) => setState(() {}),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('HTML animé → MP4')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            height: 240,
            color: Colors.black12,
            child: FittedBox(
              child: SizedBox(
                width: _wv,
                height: _hv,
                child: InAppWebView(
                  initialData: InAppWebViewInitialData(data: _html.text),
                  initialUserScripts: UnmodifiableListView([
                    UserScript(
                      source: _shim,
                      injectionTime: UserScriptInjectionTime.AT_DOCUMENT_START,
                    ),
                  ]),
                  onWebViewCreated: (c) => _ctl = c,
                  onLoadStop: (c, u) {
                    if (_loaded != null && !_loaded!.isCompleted) {
                      _loaded!.complete();
                    }
                  },
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Row(children: [
            _num('Largeur', _w),
            _num('Hauteur', _h),
            _num('FPS', _fps),
            _num('Durée (s)', _dur),
          ]),
          const SizedBox(height: 12),
          if (_projectName != null)
            Align(
              alignment: Alignment.centerLeft,
              child: InputChip(
                avatar: const Icon(Icons.folder_zip, size: 18),
                label: Text('Projet : $_projectName'),
                onDeleted: _busy ? null : _closeProject,
              ),
            )
          else
            TextField(
              controller: _html,
              enabled: !_busy,
              maxLines: 6,
              decoration: const InputDecoration(
                labelText: 'Code HTML (animé uniquement)',
                border: OutlineInputBorder(),
              ),
            ),
          const SizedBox(height: 8),
          Wrap(spacing: 8, runSpacing: 8, children: [
            OutlinedButton.icon(
              onPressed: _busy ? null : _pickHtml,
              icon: const Icon(Icons.html),
              label: const Text('Ouvrir un .html'),
            ),
            OutlinedButton.icon(
              onPressed: _busy ? null : _pickProject,
              icon: const Icon(Icons.folder_zip),
              label: const Text('Projet .zip (HTML + sons)'),
            ),
          ]),
          const Padding(
            padding: EdgeInsets.only(top: 4),
            child: Text(
              'Zippez le HTML avec son dossier de sons : les sons que la page '
              'joue sont détectés et mixés automatiquement.',
              style: TextStyle(fontSize: 12),
            ),
          ),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _busy ? null : _pickAudio,
                icon: const Icon(Icons.music_note),
                label: Text(
                  _audioName ?? 'Ajouter une musique de fond',
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ),
            if (_audioPath != null)
              IconButton(
                onPressed: _busy
                    ? null
                    : () => setState(() {
                          _audioPath = null;
                          _audioName = null;
                        }),
                icon: const Icon(Icons.close),
                tooltip: 'Retirer la musique',
              ),
          ]),
          const SizedBox(height: 8),
          FilledButton.icon(
            onPressed: _busy ? null : _export,
            icon: const Icon(Icons.movie),
            label: const Text('Convertir et enregistrer'),
          ),
          if (_busy || _progress > 0) ...[
            const SizedBox(height: 16),
            LinearProgressIndicator(value: _busy ? _progress : 1),
          ],
          if (_status.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text(_status),
            ),
          if (_lastOut != null)
            Wrap(spacing: 8, children: [
              TextButton.icon(
                onPressed: _openPreview,
                icon: const Icon(Icons.play_circle),
                label: const Text('Aperçu'),
              ),
              TextButton.icon(
                onPressed: () => Share.shareXFiles([XFile(_lastOut!)]),
                icon: const Icon(Icons.share),
                label: const Text('Partager la vidéo'),
              ),
            ]),
        ],
      ),
    );
  }
}
