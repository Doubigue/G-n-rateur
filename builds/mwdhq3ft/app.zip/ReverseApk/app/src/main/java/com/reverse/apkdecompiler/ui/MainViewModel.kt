package com.reverse.apkdecompiler.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.reverse.apkdecompiler.engine.ApkDecompilerEngine
import com.reverse.apkdecompiler.engine.ExtractionReport
import com.reverse.apkdecompiler.engine.OutputPaths
import com.reverse.apkdecompiler.engine.ZipExporter
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class Screen { HOME, ANALYSE, EXPLORER, SECRETS, PROJECTS, ARCHIVES, SETTINGS }

data class Preview(val title: String, val body: String)

data class ProjectItem(val dir: File, val modified: Long, val size: Long)

data class UiState(
    val screen: Screen = Screen.HOME,
    val selectedName: String? = null,
    val running: Boolean = false,
    val phase: String = "",
    val done: Int = 0,
    val total: Int = 0,
    val current: String = "",
    val logs: List<String> = emptyList(),
    val report: ExtractionReport? = null,
    val zipFile: File? = null,
    val zipping: Boolean = false,
    val error: String? = null,
    val hasAccess: Boolean = false,
    val outputBase: String = "",
    val explorerRoot: File? = null,
    val explorerDir: File? = null,
    val explorerEntries: List<File> = emptyList(),
    val preview: Preview? = null,
    val projects: List<ProjectItem> = emptyList(),
    val archives: List<File> = emptyList(),
    val pendingDelete: File? = null
)

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val engine = ApkDecompilerEngine(app)
    private val _ui = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> = _ui.asStateFlow()
    private var job: Job? = null

    init { refreshAccess() }

    fun refreshAccess() {
        val ctx = getApplication<Application>()
        _ui.update {
            it.copy(
                hasAccess = OutputPaths.hasFullAccess(ctx),
                outputBase = OutputPaths.baseDir(ctx, create = false).absolutePath
            )
        }
    }

    private fun log(m: String) = _ui.update { it.copy(logs = (it.logs + m).takeLast(200)) }

    // ---------------------------------------------------------------- navigation

    fun navigate(s: Screen) {
        _ui.update { it.copy(screen = s) }
        when (s) {
            Screen.PROJECTS -> refreshProjects()
            Screen.ARCHIVES -> refreshArchives()
            else -> {}
        }
    }

    fun back() {
        val s = _ui.value
        if (s.screen == Screen.EXPLORER && s.explorerRoot != null && s.explorerDir != s.explorerRoot) up()
        else navigate(Screen.HOME)
    }

    // ---------------------------------------------------------------- analyse

    fun analyze(uri: Uri) {
        if (_ui.value.running) return
        _ui.update {
            it.copy(
                screen = Screen.ANALYSE,
                running = true, report = null, zipFile = null, error = null, logs = emptyList(),
                phase = "Démarrage", done = 0, total = 0, current = ""
            )
        }
        job = viewModelScope.launch {
            try {
                _ui.update { it.copy(selectedName = engine.displayName(uri)) }
                val report = engine.run(
                    uri,
                    onProgress = { p ->
                        _ui.update { it.copy(phase = p.phase, done = p.done, total = p.total, current = p.current) }
                    },
                    onLog = ::log
                )
                _ui.update {
                    it.copy(
                        running = false, report = report, phase = "Terminé",
                        explorerRoot = report.outputDir, explorerDir = report.outputDir,
                        explorerEntries = list(report.outputDir)
                    )
                }
            } catch (e: CancellationException) {
                _ui.update { it.copy(running = false, phase = "Annulé") }
                log("Analyse annulée (les fichiers déjà extraits sont conservés)")
                throw e
            } catch (e: Throwable) {
                _ui.update { it.copy(running = false, error = e.message ?: e.javaClass.simpleName) }
            }
        }
    }

    fun cancel() { job?.cancel() }

    // ---------------------------------------------------------------- zip

    fun zip() {
        val r = _ui.value.report ?: return
        if (_ui.value.zipping) return
        _ui.update { it.copy(zipping = true, phase = "Création de l'archive ZIP", done = 0, total = 0, current = "", error = null) }
        viewModelScope.launch {
            try {
                val z = withContext(Dispatchers.IO) {
                    ZipExporter.zipFolder(
                        r.outputDir,
                        onProgress = { d, t -> _ui.update { it.copy(done = d, total = t) } },
                        check = { ensureActive() }
                    )
                }
                _ui.update { it.copy(zipping = false, zipFile = z, phase = "Archive créée") }
                log("ZIP : ${z.absolutePath}")
            } catch (e: Throwable) {
                _ui.update { it.copy(zipping = false, error = "ZIP : ${e.message ?: e.javaClass.simpleName}") }
            }
        }
    }

    // ---------------------------------------------------------------- listes

    private fun baseDir() = OutputPaths.baseDir(getApplication(), create = false)

    fun refreshProjects() {
        viewModelScope.launch {
            val items = withContext(Dispatchers.IO) {
                baseDir().listFiles { f -> f.isDirectory }
                    ?.map { d ->
                        ProjectItem(d, d.lastModified(), d.walkTopDown().filter { it.isFile }.sumOf { it.length() })
                    }
                    ?.sortedByDescending { it.modified }
                    ?: emptyList()
            }
            _ui.update { it.copy(projects = items) }
        }
    }

    fun refreshArchives() {
        viewModelScope.launch {
            val items = withContext(Dispatchers.IO) {
                baseDir().listFiles { f -> f.isFile && f.extension.equals("zip", ignoreCase = true) }
                    ?.sortedByDescending { it.lastModified() }
                    ?: emptyList()
            }
            _ui.update { it.copy(archives = items) }
        }
    }

    fun requestDelete(f: File) = _ui.update { it.copy(pendingDelete = f) }
    fun cancelDelete() = _ui.update { it.copy(pendingDelete = null) }

    fun confirmDelete() {
        val f = _ui.value.pendingDelete ?: return
        _ui.update { it.copy(pendingDelete = null) }
        viewModelScope.launch {
            withContext(Dispatchers.IO) { f.deleteRecursively() }
            _ui.update { s ->
                val wasRoot = s.explorerRoot == f
                s.copy(
                    explorerRoot = if (wasRoot) null else s.explorerRoot,
                    explorerDir = if (wasRoot) null else s.explorerDir,
                    explorerEntries = if (wasRoot) emptyList() else s.explorerEntries,
                    report = if (s.report?.outputDir == f) null else s.report,
                    zipFile = if (s.zipFile == f) null else s.zipFile
                )
            }
            refreshProjects()
            refreshArchives()
        }
    }

    // ---------------------------------------------------------------- explorateur

    private fun list(dir: File): List<File> =
        dir.listFiles()?.sortedWith(compareByDescending<File> { it.isDirectory }.thenBy { it.name.lowercase() })
            ?: emptyList()

    fun openProject(dir: File) {
        _ui.update { it.copy(screen = Screen.EXPLORER, explorerRoot = dir, explorerDir = dir, explorerEntries = list(dir)) }
    }

    fun openDir(dir: File) = _ui.update { it.copy(explorerDir = dir, explorerEntries = list(dir)) }

    fun up() {
        val s = _ui.value
        val root = s.explorerRoot ?: return
        val cur = s.explorerDir ?: return
        if (cur != root) cur.parentFile?.let { openDir(it) }
    }

    fun openFile(f: File) {
        viewModelScope.launch {
            val p = withContext(Dispatchers.IO) { buildPreview(f) }
            _ui.update { it.copy(preview = p) }
        }
    }

    fun closePreview() = _ui.update { it.copy(preview = null) }

    private fun buildPreview(f: File): Preview {
        return try {
            val bytes = f.inputStream().use { ins ->
                val buf = ByteArray(64 * 1024)
                val n = ins.read(buf)
                if (n <= 0) ByteArray(0) else buf.copyOf(n)
            }
            val ctrl = bytes.count { b ->
                val v = b.toInt() and 0xFF
                v < 9 || (v in 14..31) || v == 127
            }
            val isText = bytes.isEmpty() || ctrl.toDouble() / bytes.size < 0.05
            if (isText) Preview(f.name, String(bytes, Charsets.UTF_8))
            else Preview("${f.name} (binaire, vue hexadécimale)", hexDump(bytes.copyOf(minOf(bytes.size, 1024))))
        } catch (e: Throwable) {
            Preview(f.name, "Lecture impossible : ${e.message}")
        }
    }

    private fun hexDump(b: ByteArray): String = buildString {
        for (i in b.indices step 16) {
            append("%08x  ".format(i))
            val end = minOf(i + 16, b.size)
            for (j in i until i + 16) append(if (j < end) "%02x ".format(b[j]) else "   ")
            append(" ")
            for (j in i until end) {
                val c = b[j].toInt() and 0xFF
                append(if (c in 0x20..0x7E) c.toChar() else '.')
            }
            append('\n')
        }
    }
}
