package com.reverse.apkdecompiler.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val Charcoal = Color(0xFF14171A)
private val Slate = Color(0xFF1E2327)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF4DB6AC),
    onPrimary = Color(0xFF00201D),
    primaryContainer = Color(0xFF1B3A37),
    onPrimaryContainer = Color(0xFFB2DFDB),
    secondary = Color(0xFFFFB74D),
    background = Charcoal,
    onBackground = Color(0xFFECEFF1),
    surface = Charcoal,
    onSurface = Color(0xFFECEFF1),
    surfaceVariant = Slate,
    onSurfaceVariant = Color(0xFF9AA5AC),
    outline = Color(0xFF3A4349),
    error = Color(0xFFFFB4AB),
    errorContainer = Color(0xFF5C1A14),
    onErrorContainer = Color(0xFFFFDAD6)
)

/** Thème sombre chaleureux (toujours actif). */
@Composable
fun ReverseTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColors,
        shapes = Shapes(
            small = RoundedCornerShape(14.dp),
            medium = RoundedCornerShape(20.dp),
            large = RoundedCornerShape(28.dp)
        ),
        content = content
    )
}
