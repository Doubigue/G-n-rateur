package com.moncoffre.app

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.moncoffre.app.data.Account
import com.moncoffre.app.data.AppSigningKey
import com.moncoffre.app.data.AppSigningKeyVault
import com.moncoffre.app.data.DeviceAccount
import com.moncoffre.app.data.PhoneContact
import com.moncoffre.app.data.normalizeLogin
import com.moncoffre.app.data.readDeviceAccounts
import com.moncoffre.app.data.Services
import com.moncoffre.app.data.Vault
import com.moncoffre.app.data.readContacts
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class VaultViewModel(app: Application) : AndroidViewModel(app) {

    private val vault = Vault(app)
    private val signingKeyVault = AppSigningKeyVault(app)

    var accounts by mutableStateOf<List<Account>>(emptyList())
        private set

    var appSigningKeys by mutableStateOf<List<AppSigningKey>>(emptyList())
        private set

    var contacts by mutableStateOf<List<PhoneContact>>(emptyList())
        private set

    var contactsLoaded by mutableStateOf(false)
        private set

    var deviceAccounts by mutableStateOf<List<DeviceAccount>>(emptyList())
        private set

    /** Le fichier du coffre existait mais n'a pas pu être déchiffré. */
    var loadError by mutableStateOf(false)
        private set

    /** Le téléphone n'a ni code, ni schéma, ni empreinte : l'appli ne peut pas se verrouiller. */
    var deviceUnsecured by mutableStateOf(false)

    init {
        appSigningKeys = runCatching { signingKeyVault.load() }.getOrDefault(emptyList())
        accounts = try {
            sorted(vault.load())
        } catch (e: Exception) {
            vault.quarantine()
            loadError = true
            emptyList()
        }
    }

    private fun sorted(list: List<Account>): List<Account> = list.sortedWith(
        compareBy<Account>(
            { a -> Services.all.indexOf(a.service).let { if (it < 0) 999 else it } },
            { a -> a.displayName.lowercase() },
        )
    )

    private fun commit(list: List<Account>) {
        accounts = sorted(list)
        vault.save(accounts)
    }

    /** Vrai si cet identifiant est déjà enregistré dans un autre compte (casse ignorée). */
    fun loginExists(login: String, exceptId: String? = null): Boolean {
        val key = normalizeLogin(login)
        return key.isNotEmpty() && accounts.any { it.id != exceptId && normalizeLogin(it.login) == key }
    }

    /** Enregistre le compte ; refuse (false) si son identifiant existe déjà. */
    fun upsert(account: Account): Boolean {
        if (loginExists(account.login, account.id)) return false
        val updated = account.copy(updatedAt = System.currentTimeMillis())
        commit(accounts.filter { it.id != account.id } + updated)
        return true
    }

    fun delete(id: String) = commit(accounts.filter { it.id != id })

    /** Fusionne une sauvegarde : même id = remplacé ; identifiant déjà présent sous un autre id = ignoré. */
    fun importAccounts(imported: List<Account>): Int {
        val ids = imported.map { it.id }.toSet()
        val kept = accounts.filter { it.id !in ids }
        val seen = kept.map { normalizeLogin(it.login) }.filter { it.isNotEmpty() }.toMutableSet()
        val toAdd = imported.filter { a ->
            val k = normalizeLogin(a.login)
            k.isEmpty() || seen.add(k)
        }
        commit(kept + toAdd)
        return toAdd.size
    }

    fun loadDeviceAccounts() {
        viewModelScope.launch {
            deviceAccounts = withContext(Dispatchers.IO) {
                runCatching { readDeviceAccounts(getApplication()) }.getOrDefault(emptyList())
            }
        }
    }

    /** Ajoute les comptes de l'appareil pas encore enregistrés. Retourne le nombre ajouté. */
    fun addDeviceAccounts(list: List<DeviceAccount>): Int {
        val seen = accounts.map { normalizeLogin(it.login) }.filter { it.isNotEmpty() }.toMutableSet()
        val toAdd = list.filter { seen.add(normalizeLogin(it.name)) }
            .map { Account(service = it.service, login = it.name) }
        if (toAdd.isNotEmpty()) commit(accounts + toAdd)
        return toAdd.size
    }

    fun upsertAppSigningKey(item: AppSigningKey) {
        val updated = item.copy(updatedAt = System.currentTimeMillis())
        appSigningKeys = (appSigningKeys.filterNot { it.id == item.id } + updated)
            .sortedBy { it.appName.lowercase() }
        signingKeyVault.save(appSigningKeys)
    }

    fun deleteAppSigningKey(id: String) {
        appSigningKeys = appSigningKeys.filterNot { it.id == id }
        signingKeyVault.save(appSigningKeys)
    }

    fun loadContacts() {
        viewModelScope.launch {
            val list = withContext(Dispatchers.IO) {
                runCatching { readContacts(getApplication()) }.getOrDefault(emptyList())
            }
            contacts = list
            contactsLoaded = true
        }
    }
}
