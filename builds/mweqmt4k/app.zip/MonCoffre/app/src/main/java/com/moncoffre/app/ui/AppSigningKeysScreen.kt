package com.moncoffre.app.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.moncoffre.app.VaultViewModel
import com.moncoffre.app.data.AppSigningKey
import com.moncoffre.app.pdf.AppSigningKeyPdfExporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun AppSigningKeysScreen(vm: VaultViewModel, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var editing by remember { mutableStateOf<AppSigningKey?>(null) }
    var adding by remember { mutableStateOf(false) }
    var exporting by remember { mutableStateOf(false) }
    var includePasswords by remember { mutableStateOf(false) }
    var confirmExport by remember { mutableStateOf(false) }
    val pdfLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        if (uri != null) {
            exporting = true
            val records = vm.appSigningKeys.toList()
            val reveal = includePasswords
            scope.launch {
                val success = withContext(Dispatchers.IO) {
                    runCatching {
                        context.contentResolver.openOutputStream(uri)!!.use { output ->
                            AppSigningKeyPdfExporter().export(output, records, reveal)
                        }
                    }.isSuccess
                }
                exporting = false
                Toast.makeText(context, if (success) "PDF créé" else "Erreur pendant la création du PDF", Toast.LENGTH_LONG).show()
            }
        }
    }

    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            "Enregistrez les informations de signature de vos applications Android : fichier .jks/.keystore, alias, mots de passe et empreintes.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { adding = true }) { Text("Ajouter une clé") }
            OutlinedButton(enabled = vm.appSigningKeys.isNotEmpty() && !exporting, onClick = { confirmExport = true }) {
                Text(if (exporting) "Création…" else "Générer PDF")
            }
        }
        if (vm.appSigningKeys.isEmpty()) {
            Card {
                Text("Aucune clé d'application enregistrée.", Modifier.padding(18.dp), style = MaterialTheme.typography.bodyMedium)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(vm.appSigningKeys, key = { it.id }) { item ->
                    Card(
                        onClick = { editing = item },
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(item.appName, style = MaterialTheme.typography.titleMedium)
                            Text(item.packageName.ifBlank { "Package non renseigné" }, style = MaterialTheme.typography.bodySmall)
                            Text("Alias : ${item.keyAlias.ifBlank { "Non renseigné" }}", style = MaterialTheme.typography.bodySmall)
                            Text("Fichier : ${item.keystoreFileName.ifBlank { "Non renseigné" }}", style = MaterialTheme.typography.bodySmall)
                            Text("Toucher pour modifier ou supprimer", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        }
    }

    if (adding || editing != null) {
        SigningKeyDialog(
            initial = editing ?: AppSigningKey(),
            onDismiss = { adding = false; editing = null },
            onSave = {
                vm.upsertAppSigningKey(it)
                adding = false
                editing = null
                Toast.makeText(context, "Clé enregistrée dans le coffre chiffré", Toast.LENGTH_SHORT).show()
            },
            onDelete = { id ->
                vm.deleteAppSigningKey(id)
                adding = false
                editing = null
                Toast.makeText(context, "Fiche supprimée", Toast.LENGTH_SHORT).show()
            },
            canDelete = editing != null,
        )
    }

    if (confirmExport) {
        AlertDialog(
            onDismissRequest = { confirmExport = false },
            title = { Text("Générer le PDF") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Le PDF peut contenir les mots de passe de vos clés de signature. Il ne sera pas chiffré automatiquement.")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { includePasswords = false }) { Text(if (!includePasswords) "✓ Masquer" else "Masquer") }
                        TextButton(onClick = { includePasswords = true }) { Text(if (includePasswords) "✓ Inclure" else "Inclure") }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    confirmExport = false
                    pdfLauncher.launch("MonCoffre_Cles_Applications.pdf")
                }) { Text("Continuer") }
            },
            dismissButton = { TextButton(onClick = { confirmExport = false }) { Text("Annuler") } },
        )
    }
}

@Composable
private fun SigningKeyDialog(
    initial: AppSigningKey,
    onDismiss: () -> Unit,
    onSave: (AppSigningKey) -> Unit,
    onDelete: (String) -> Unit,
    canDelete: Boolean,
) {
    var appName by remember(initial.id) { mutableStateOf(initial.appName) }
    var packageName by remember(initial.id) { mutableStateOf(initial.packageName) }
    var fileName by remember(initial.id) { mutableStateOf(initial.keystoreFileName) }
    var alias by remember(initial.id) { mutableStateOf(initial.keyAlias) }
    var storePassword by remember(initial.id) { mutableStateOf(initial.storePassword) }
    var keyPassword by remember(initial.id) { mutableStateOf(initial.keyPassword) }
    var algorithm by remember(initial.id) { mutableStateOf(initial.keyAlgorithm) }
    var validity by remember(initial.id) { mutableStateOf(initial.validity) }
    var sha1 by remember(initial.id) { mutableStateOf(initial.sha1) }
    var sha256 by remember(initial.id) { mutableStateOf(initial.sha256) }
    var notes by remember(initial.id) { mutableStateOf(initial.notes) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (canDelete) "Modifier la clé d'application" else "Nouvelle clé d'application") },
        text = {
            Column(
                Modifier.fillMaxWidth().height(520.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                androidx.compose.foundation.rememberScrollState().let { scroll ->
                    Column(Modifier.fillMaxSize().verticalScroll(scroll), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(appName, { appName = it }, label = { Text("Nom de l'application *") }, singleLine = true)
                        OutlinedTextField(packageName, { packageName = it }, label = { Text("Nom du package") }, singleLine = true)
                        OutlinedTextField(fileName, { fileName = it }, label = { Text("Fichier .jks / .keystore") }, singleLine = true)
                        OutlinedTextField(alias, { alias = it }, label = { Text("Alias de la clé *") }, singleLine = true)
                        OutlinedTextField(storePassword, { storePassword = it }, label = { Text("Mot de passe du keystore") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
                        OutlinedTextField(keyPassword, { keyPassword = it }, label = { Text("Mot de passe de la clé") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
                        OutlinedTextField(algorithm, { algorithm = it }, label = { Text("Algorithme (RSA, EC…)") }, singleLine = true)
                        OutlinedTextField(validity, { validity = it }, label = { Text("Durée de validité") }, singleLine = true)
                        OutlinedTextField(sha1, { sha1 = it }, label = { Text("Empreinte SHA-1") })
                        OutlinedTextField(sha256, { sha256 = it }, label = { Text("Empreinte SHA-256") })
                        OutlinedTextField(notes, { notes = it }, label = { Text("Notes") }, minLines = 2)
                        Text("Les informations sont enregistrées localement dans un fichier chiffré avec Android Keystore.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        },
        confirmButton = {
            Button(enabled = appName.isNotBlank() && alias.isNotBlank(), onClick = {
                onSave(initial.copy(
                    appName = appName.trim(), packageName = packageName.trim(),
                    keystoreFileName = fileName.trim(), keyAlias = alias.trim(),
                    storePassword = storePassword, keyPassword = keyPassword,
                    keyAlgorithm = algorithm.trim().ifBlank { "RSA" }, validity = validity.trim(),
                    sha1 = sha1.trim(), sha256 = sha256.trim(), notes = notes.trim(),
                ))
            }) { Text("Enregistrer") }
        },
        dismissButton = {
            Row {
                if (canDelete) TextButton(onClick = { onDelete(initial.id) }) { Text("Supprimer") }
                TextButton(onClick = onDismiss) { Text("Annuler") }
            }
        },
    )
}
