package com.html2mp4.app

import android.content.Context
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/**
 * Moteur d'export : capture image par image de la page (temps virtuel) puis encodage FFmpeg.
 * run() et measureDuration() s'exécutent sur le thread principal (WebView).
 */
class Exporter(
    private val ctx: Context,
    private val host: PageHost,
    private val isForeground: () -> Boolean,
    private val onProgress: (Prog) -> Unit
) {
    @Volatile
    var cancelled = false

    private val main = Handler(Looper.getMainLooper())

    private fun report(v: Double, phase: String, detail: String, thumb: Bitmap? = null, paused: Boolean = false) {
        onProgress(Prog(v.coerceIn(0.0, 1.0), phase, detail, thumb, paused))
    }

    fun cancel() {
        cancelled = true
        report(0.0, "Annulation…", "Arrêt en cours")
        Ffmpeg.cancel()
    }

    // -------------------------------------------------------------------- audio

    private fun parseSounds(json: String, totalSec: Double): List<Snd> {
        val open = HashMap<Int, Snd>()
        val out = ArrayList<Snd>()
        val arr = JSONArray(json)
        for (i in 0 until arr.length()) {
            val e = arr.getJSONObject(i)
            val id = e.getInt("id")
            val t = e.getDouble("t")
            val kind = e.optString("k")
            if (kind == "play") {
                val file = host.localFile(e.getString("src")) ?: continue
                val vol = e.optDouble("vol", 1.0)
                if (vol <= 0 || t / 1000 >= totalSec) continue
                val dur = if (e.has("dur") && !e.isNull("dur")) e.getDouble("dur") else null
                val s = Snd(
                    file.path, t, e.optDouble("off", 0.0),
                    vol.coerceIn(0.0, 1.0), e.optDouble("rate", 1.0).coerceIn(0.5, 2.0),
                    e.optBoolean("loop", false), dur
                )
                open[id] = s
                out.add(s)
            } else if (kind == "stop") {
                val s = open.remove(id)
                if (s != null && s.dur == null && t > s.t) s.dur = (t - s.t) / 1000
            }
        }
        return out.take(64)
    }

    /** Simule la page (temps virtuel) pour connaître sa durée. Résultat borné de 1 à 120 s. */
    suspend fun measureDuration(): Double {
        val maxSec = 120.0
        val m = host.measure((maxSec * 1000).roundToInt())
        var endMs = m.optDouble("end", 0.0)
        val loopMs = m.optDouble("loop", 0.0)

        // Fin des sons joués par la page
        val audio = m.optJSONArray("audio")
        if (audio != null) {
            for (i in 0 until audio.length()) {
                val e = audio.getJSONObject(i)
                if (e.optString("k") != "play" || e.optBoolean("loop", false)) continue
                val file = host.localFile(e.getString("src")) ?: continue
                val fd = withContext(Dispatchers.IO) { Ffmpeg.duration(file.path) } ?: continue
                val rate = e.optDouble("rate", 1.0).coerceIn(0.5, 2.0)
                val off = e.optDouble("off", 0.0)
                val len = if (e.has("dur") && !e.isNull("dur")) e.getDouble("dur") else fd - off
                endMs = maxOf(endMs, e.getDouble("t") + len / rate * 1000)
            }
        }

        val sec = when {
            endMs > 0 -> endMs / 1000        // il y a une fin réelle
            loopMs > 0 -> loopMs / 1000      // animation en boucle : un cycle complet
            else -> 10.0                     // boucle infinie non mesurable
        }
        return Math.ceil(sec.coerceIn(1.0, maxSec) * 10) / 10
    }

    // ------------------------------------------------------------------- export

    private fun thumbOf(src: Bitmap): Bitmap {
        val tw = 160
        val th = (tw.toDouble() * src.height / src.width).roundToInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(src, tw, th, true)
    }

    private fun checkCancel() {
        if (cancelled) throw ExportCancelled()
    }

    suspend fun run(st: ExportSettings): ExportResult {
        cancelled = false
        val fps = st.fps
        var dur = st.durSec
        val q = QPS.getValue(st.quality)
        val gif = st.out == Out.GIF
        val t0 = System.currentTimeMillis()
        val framesDir = File(ctx.cacheDir, "frames")

        try {
            withContext(Dispatchers.IO) {
                framesDir.deleteRecursively()
                framesDir.mkdirs()
            }
            report(0.0, "Préparation", "Chargement de la page…")
            host.resizeView(st.w, st.h)
            host.awaitSize()
            host.load()
            if (!host.isAnimated()) throw IllegalStateException("ce HTML n'est pas animé, export refusé")
            if (st.autoDur) {
                report(0.01, "Préparation", "Calcul de la durée…")
                dur = measureDuration()
                host.load() // état propre avant la capture
            }
            val total = (dur * fps).roundToInt().coerceIn(1, 100000)
            checkCancel()

            // 1) Capture image par image (les sons sont enregistrés par le shim)
            val ext = if (q.png) "png" else "jpg"
            val fmt = if (q.png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG
            val capStart = System.currentTimeMillis()
            coroutineScope {
                val ring = 3
                val bmps = Array(ring) { Bitmap.createBitmap(st.w, st.h, Bitmap.Config.ARGB_8888) }
                val jobs = arrayOfNulls<Deferred<Unit>>(ring)
                try {
                    for (i in 0 until total) {
                        checkCancel()
                        // Hors écran, le WebView ne peint plus : on attend le retour de l'utilisateur.
                        if (!isForeground()) {
                            while (!isForeground()) {
                                checkCancel()
                                report(
                                    0.03 + i.toDouble() / total * 0.72, "En pause",
                                    "Rouvre l'appli pour continuer la capture ($i / $total)", null, true
                                )
                                delay(400)
                            }
                            host.web.onResume()
                            host.web.resumeTimers()
                            delay(500)
                        }
                        host.seek(i * 1000.0 / fps, q.rafs)
                        val k = i % ring
                        jobs[k]?.await()
                        host.capture(bmps[k])
                        val bmp = bmps[k]
                        val file = File(framesDir, "frame_" + i.toString().padStart(5, '0') + "." + ext)
                        jobs[k] = async(Dispatchers.IO) {
                            FileOutputStream(file).use { bmp.compress(fmt, q.jpg, it) }
                            Unit
                        }
                        val done = i + 1
                        val perMs = (System.currentTimeMillis() - capStart).toDouble() / done
                        val eta = ((total - done) * perMs / 1000).roundToInt().toLong()
                        val ips = 1000 / (if (perMs > 0) perMs else 1.0)
                        report(
                            0.03 + done.toDouble() / total * 0.72, "Capture des images",
                            "$done / $total · ${String.format(Locale.US, "%.1f", ips)} img/s · reste ~${fmtSec(eta)}",
                            if (done % 4 == 1) thumbOf(bmp) else null
                        )
                    }
                    jobs.forEach { it?.await() }
                } finally {
                    jobs.forEach { it?.cancel() }
                }
                bmps.forEach { it.recycle() }
            }
            checkCancel()

            // 2) Récupère les sons joués par la page
            val sounds = if (gif) emptyList() else parseSounds(host.audioEventsJson(), dur)

            // 3) Construit la commande FFmpeg
            val exp = File(ctx.filesDir, "exports")
            exp.mkdirs()
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val out = File(exp, "html2mp4_$stamp." + (if (gif) "gif" else "mp4")).path
            val args = buildArgs(st, q, dur, fps, framesDir.path, ext, gif, sounds, out)

            // 4) Encodage avec progression réelle
            val label = if (gif) "GIF" else "MP4"
            val extra = if (sounds.isEmpty()) "" else " · ${sounds.size} son(s) mixé(s)"
            report(0.75, "Encodage $label", "0 %$extra")
            val encStart = System.currentTimeMillis()
            val res = Ffmpeg.run(args) { ms ->
                val r = (ms / (dur * 1000)).coerceIn(0.0, 1.0)
                val eta = if (r > 0.03) ((System.currentTimeMillis() - encStart) / r * (1 - r) / 1000).roundToInt().toLong() else null
                main.post {
                    if (!cancelled) {
                        report(
                            0.75 + r * 0.22, "Encodage $label",
                            "${(r * 100).roundToInt()} %" + (if (eta == null) "" else " · reste ~${fmtSec(eta)}")
                        )
                    }
                }
            }
            if (res.cancelled || cancelled) throw ExportCancelled()
            if (!res.ok) throw IllegalStateException("FFmpeg a échoué\n" + res.logTail)

            // 5) Enregistrement direct dans la galerie
            report(0.98, "Enregistrement", "Ajout à la galerie…")
            val note = withContext(Dispatchers.IO) { Gallery.save(ctx, File(out), gif) }

            val secs = (System.currentTimeMillis() - t0) / 1000
            report(1.0, "Terminé", "en ${fmtSec(secs)}")
            return ExportResult(out, gif, sounds.size, note, secs, dur)
        } finally {
            withContext(kotlinx.coroutines.NonCancellable + Dispatchers.IO) {
                framesDir.deleteRecursively()
            }
        }
    }

    private fun buildArgs(
        st: ExportSettings, q: QP, dur: Double, fps: Int, dir: String, ext: String,
        gif: Boolean, sounds: List<Snd>, out: String
    ): List<String> {
        val args = ArrayList<String>()
        args.addAll(listOf("-y", "-framerate", "$fps", "-i", "$dir/frame_%05d.$ext"))

        if (gif) {
            val gfps = if (fps > 20) 20 else fps
            val gw = if (st.w > 540) 540 else st.w
            args.addAll(
                listOf(
                    "-filter_complex",
                    "[0:v]fps=$gfps,scale=$gw:-1:flags=lanczos,split[a][b];" +
                        "[a]palettegen=stats_mode=diff[p];" +
                        "[b][p]paletteuse=dither=bayer:bayer_scale=5[v]",
                    "-map", "[v]", "-loop", "0", out
                )
            )
            return args
        }

        val fadeV = if (st.fade && dur > 1.5)
            ",fade=t=in:st=0:d=0.4,fade=t=out:st=${n3(dur - 0.4)}:d=0.4" else ""
        val chains = ArrayList<String>()
        chains.add("[0:v]scale=trunc(iw/2)*2:trunc(ih/2)*2,format=yuv420p$fadeV[v]")
        val mix = ArrayList<String>()
        var idx = 1
        val fmtA = "aformat=sample_rates=44100:channel_layouts=stereo"

        val music = st.musicPath
        if (music != null) {
            args.addAll(listOf("-stream_loop", "-1", "-i", music))
            val fade = if (dur > 2) ",afade=t=out:st=${n3(dur - 1)}:d=1" else ""
            val mv = (if (sounds.isEmpty()) 1.0 else 0.6) * st.musicVol
            chains.add(
                "[$idx:a]$fmtA,atrim=duration=${n3(dur)},asetpts=PTS-STARTPTS,volume=${n3(mv)}$fade[m]"
            )
            mix.add("[m]")
            idx++
        }

        for ((j, s) in sounds.withIndex()) {
            if (s.loop) args.addAll(listOf("-stream_loop", "-1"))
            args.addAll(listOf("-i", s.file))
            val remain = dur - s.t / 1000
            val sd = s.dur
            val d = if (sd != null && sd < remain) sd else remain
            chains.add(
                "[$idx:a]$fmtA" +
                    (if (s.off > 0) ",atrim=start=${n3(s.off)}" else "") +
                    ",asetpts=PTS-STARTPTS" +
                    (if (s.rate != 1.0) ",atempo=${n3(s.rate)}" else "") +
                    ",atrim=duration=${n3(d)},volume=${n3(s.vol)}" +
                    ",adelay=${s.t.roundToInt()}:all=1[s$j]"
            )
            mix.add("[s$j]")
            idx++
        }

        if (mix.isNotEmpty()) {
            chains.add(
                mix.joinToString("") + "amix=inputs=${mix.size}:duration=longest" +
                    ":normalize=0,alimiter=limit=0.95,atrim=duration=${n3(dur)}[aout]"
            )
        }

        args.addAll(listOf("-filter_complex", chains.joinToString(";"), "-map", "[v]"))
        if (mix.isNotEmpty()) {
            args.addAll(listOf("-map", "[aout]", "-c:a", "aac", "-b:a", "192k"))
        }
        args.addAll(
            listOf(
                "-c:v", "libx264", "-preset", q.preset, "-crf", "${q.crf}",
                "-threads", "0", "-pix_fmt", "yuv420p",
                "-t", n3(dur), "-movflags", "+faststart", out
            )
        )
        return args
    }
}
