package com.html2mp4.app

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.net.Uri
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.MimeTypeMap
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import org.json.JSONTokener
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream
import java.util.Locale
import kotlin.coroutines.resume
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Page web pilotée par une horloge virtuelle (shim.js).
 *
 * Toutes les ressources passent par shouldInterceptRequest sur une origine virtuelle :
 *  - le HTML collé dans l'appli,
 *  - les fichiers d'un projet .zip extrait (HTML, sons, images…).
 * Le shim est injecté dans chaque page HTML AVANT ses propres scripts.
 *
 * À appeler depuis le thread principal uniquement.
 */
@SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
class PageHost(ctx: Context, val web: WebView) {

    companion object {
        const val HOST = "appassets.androidplatform.net"
        const val INLINE = "/__inline__.html"
    }

    var projectDir: File? = null
    var entryPath: String = INLINE   // chemin relatif du HTML d'entrée (projet) ou INLINE
    var inlineHtml: String = ""      // HTML collé (quand aucun projet n'est ouvert)

    var viewW = 720
        private set
    var viewH = 1280
        private set

    private val shim: String =
        ctx.assets.open("shim.js").bufferedReader(Charsets.UTF_8).use { it.readText() }

    @Volatile
    private var loaded: CompletableDeferred<Unit>? = null

    @Volatile
    private var pending: CompletableDeferred<Unit>? = null

    private var scalePercent = 100

    private inner class Bridge {
        @JavascriptInterface
        fun ready() {
            pending?.complete(Unit)
        }
    }

    init {
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.useWideViewPort = false
        s.loadWithOverviewMode = false
        s.textZoom = 100
        s.cacheMode = WebSettings.LOAD_NO_CACHE
        s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        web.setBackgroundColor(Color.WHITE)
        web.isVerticalScrollBarEnabled = false
        web.isHorizontalScrollBarEnabled = false
        web.overScrollMode = View.OVER_SCROLL_NEVER
        web.setOnTouchListener { _, _ -> true } // aperçu non interactif
        web.setInitialScale(scalePercent)
        web.addJavascriptInterface(Bridge(), "H2M")
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? = if (request == null) null else intercept(request)

            override fun onPageFinished(view: WebView?, url: String?) {
                loaded?.complete(Unit)
            }
        }
    }

    // ------------------------------------------------------------ serveur virtuel

    private fun headers(): Map<String, String> =
        mapOf("Access-Control-Allow-Origin" to "*", "Cache-Control" to "no-store")

    private fun notFound(): WebResourceResponse =
        WebResourceResponse("text/plain", "utf-8", 404, "Not Found", headers(), ByteArrayInputStream(ByteArray(0)))

    private fun inject(html: String): String {
        val tag = "<script>" + shim + "</script>"
        val opts = setOf(RegexOption.IGNORE_CASE)
        for (rx in listOf(Regex("<head(\\s[^>]*)?>", opts), Regex("<html(\\s[^>]*)?>", opts), Regex("<!doctype[^>]*>", opts))) {
            val m = rx.find(html)
            if (m != null) {
                val at = m.range.last + 1
                return html.substring(0, at) + tag + html.substring(at)
            }
        }
        return tag + html
    }

    private fun htmlResponse(html: String): WebResourceResponse =
        WebResourceResponse(
            "text/html", "utf-8", 200, "OK", headers(),
            ByteArrayInputStream(inject(html).toByteArray(Charsets.UTF_8))
        )

    private fun mimeOf(name: String): String {
        return when (val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)) {
            "js", "mjs" -> "text/javascript"
            "css" -> "text/css"
            "json" -> "application/json"
            "svg" -> "image/svg+xml"
            "wasm" -> "application/wasm"
            "mp3" -> "audio/mpeg"
            "wav" -> "audio/wav"
            "ogg", "oga" -> "audio/ogg"
            "m4a" -> "audio/mp4"
            "mp4" -> "video/mp4"
            "webm" -> "video/webm"
            "woff" -> "font/woff"
            "woff2" -> "font/woff2"
            "ttf" -> "font/ttf"
            "otf" -> "font/otf"
            else -> MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
        }
    }

    private fun intercept(req: WebResourceRequest): WebResourceResponse? {
        val u = req.url
        if (u.host != HOST) return null          // ressources externes : réseau normal
        if (req.method != "GET") return null
        var path = u.path ?: "/"
        val dir = projectDir
        if (dir == null) {
            return if (path == INLINE) htmlResponse(inlineHtml) else notFound()
        }
        if (path.endsWith("/")) path += "index.html"
        val rootPath = dir.canonicalPath + File.separator
        val f = try {
            File(dir, path.trimStart('/')).canonicalFile
        } catch (_: Exception) {
            return notFound()
        }
        if (!f.path.startsWith(rootPath) || !f.isFile) return notFound()
        val low = f.name.lowercase(Locale.ROOT)
        if (low.endsWith(".html") || low.endsWith(".htm")) {
            return htmlResponse(f.readText(Charsets.UTF_8))
        }
        return WebResourceResponse(mimeOf(f.name), null, 200, "OK", headers(), FileInputStream(f))
    }

    /** URL vue par la page -> fichier du projet extrait (null si ce n'est pas un fichier local). */
    fun localFile(src: String): File? {
        val dir = projectDir ?: return null
        val u = try {
            Uri.parse(src)
        } catch (_: Exception) {
            return null
        }
        if (u.host != HOST) return null
        val rel = u.path ?: return null
        if (rel.contains("..")) return null
        val f = File(dir, rel.trimStart('/'))
        return if (f.isFile) f else null
    }

    // ------------------------------------------------------------------ chargement

    private fun entryUrl(): String {
        return if (projectDir == null) {
            "https://$HOST$INLINE"
        } else {
            "https://$HOST/" + entryPath.split('/').joinToString("/") { Uri.encode(it) }
        }
    }

    private suspend fun loadRaw() {
        val d = CompletableDeferred<Unit>()
        loaded = d
        web.loadUrl(entryUrl())
        withTimeoutOrNull(20_000) { d.await() }
            ?: throw IllegalStateException("la page ne se charge pas (délai dépassé)")
        delay(500) // décodage audio, etc.
    }

    /** Charge la source courante et attend qu'elle soit prête. */
    suspend fun load() {
        loadRaw()
        calibrate()
    }

    /**
     * Vérifie que 1 px CSS = 1 px écran (la page voit bien une fenêtre de viewW px) ;
     * sinon corrige le facteur de zoom initial du WebView et recharge.
     */
    private suspend fun calibrate() {
        repeat(2) {
            if (web.width != viewW) return
            val iw = eval("window.innerWidth")?.toDoubleOrNull() ?: return
            if (iw <= 0 || abs(iw - viewW) / viewW <= 0.02) return
            scalePercent = (scalePercent * iw / viewW).roundToInt().coerceIn(5, 800)
            web.setInitialScale(scalePercent)
            loadRaw()
        }
    }

    /** Dimensionne le WebView à w x h pixels (= taille de la vidéo). */
    fun resizeView(w: Int, h: Int) {
        viewW = w
        viewH = h
        val lp = web.layoutParams ?: FrameLayout.LayoutParams(w, h)
        lp.width = w
        lp.height = h
        web.layoutParams = lp
    }

    /** Attend que le WebView ait réellement la taille demandée (mise en page terminée). */
    suspend fun awaitSize() {
        var tries = 0
        while ((web.width != viewW || web.height != viewH) && tries++ < 60) delay(50)
    }

    // ----------------------------------------------------------------- JavaScript

    suspend fun eval(js: String): String? = suspendCancellableCoroutine { c ->
        web.evaluateJavascript(js) { r -> if (c.isActive) c.resume(r) }
    }

    private fun unquote(r: String?): String? {
        if (r == null || r == "null") return null
        return JSONTokener(r).nextValue() as? String
    }

    suspend fun isAnimated(): Boolean = eval("window.__isAnimated()") == "true"

    /** Positionne la page à l'instant [ms] puis attend un vrai rendu. */
    suspend fun seek(ms: Double, rafs: Int) {
        val d = CompletableDeferred<Unit>()
        pending = d
        web.evaluateJavascript(
            "try{window.__seek(" + n3(ms) + ");}catch(e){}" +
                "window.__paint(" + rafs + ").then(function(){H2M.ready();},function(){H2M.ready();});",
            null
        )
        withTimeoutOrNull(4_000) { d.await() }
    }

    /** Simule la page en temps virtuel : { end, loop, infinite, audio }. */
    suspend fun measure(maxMs: Int): JSONObject {
        val s = unquote(eval("window.__measure($maxMs)"))
            ?: throw IllegalStateException("mesure de la durée impossible (shim absent ?)")
        return JSONObject(s)
    }

    suspend fun audioEventsJson(): String =
        unquote(eval("JSON.stringify(window.__audioEvents||[])")) ?: "[]"

    // -------------------------------------------------------------------- capture

    /** Dessine la page dans [bmp] (même taille que le WebView -> pas de mise à l'échelle). */
    fun capture(bmp: Bitmap) {
        if (web.width <= 0 || web.height <= 0) return
        bmp.eraseColor(Color.WHITE)
        val c = Canvas(bmp)
        val sx = bmp.width.toFloat() / web.width
        val sy = bmp.height.toFloat() / web.height
        if (sx != 1f || sy != 1f) c.scale(sx, sy)
        web.draw(c)
    }
}
