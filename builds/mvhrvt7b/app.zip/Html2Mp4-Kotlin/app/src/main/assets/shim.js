(function () {
  let virtual = 0, id = 0, uid = 0, tid = 0, rafs = [], rafCount = 0,
      toCount = 0, ivCount = 0, saw = false, autoDone = false;
  const d0 = Date.now();
  // Références réelles : servent à attendre un vrai rendu après chaque __seek.
  const realRaf = window.requestAnimationFrame.bind(window);
  const realSt = window.setTimeout.bind(window);
  window.__paint = n => new Promise(res => {
    let d = false; const f = () => { if (!d) { d = true; res(1); } };
    realSt(f, 150);
    const step = k => (k <= 0 ? f() : realRaf(() => step(k - 1)));
    step(n || 1);
  });
  const timers = new Map();
  const audioEvents = window.__audioEvents = [];

  ['animationstart', 'transitionstart'].forEach(e =>
    document.addEventListener(e, () => { saw = true; }, true));

  // ---- Horloge virtuelle
  window.requestAnimationFrame = cb => { rafCount++; rafs.push([++id, cb]); return id; };
  window.cancelAnimationFrame = i => { rafs = rafs.filter(r => r[0] !== i); };
  const mk = s => (typeof s === 'function' ? s : () => (0, eval)(String(s)));
  window.setTimeout = (cb, ms, ...a) => {
    toCount++;
    timers.set(++tid, { due: virtual + Math.max(+ms || 0, 0), cb: mk(cb), a, iv: 0 });
    return tid;
  };
  window.setInterval = (cb, ms, ...a) => {
    ivCount++;
    const iv = Math.max(+ms || 0, 1);
    timers.set(++tid, { due: virtual + iv, cb: mk(cb), a, iv });
    return tid;
  };
  window.clearTimeout = window.clearInterval = i => { timers.delete(i); };
  performance.now = () => virtual;
  Date.now = () => d0 + virtual;

  // ---- Enregistrement audio : éléments <audio>/<video>
  const mid = new WeakMap();
  const idOf = el => { if (!mid.has(el)) mid.set(el, ++uid); return mid.get(el); };
  HTMLMediaElement.prototype.play = function () {
    let s = this.currentSrc || this.src;
    if (!s) { const so = this.querySelector('source'); if (so) s = so.src; }
    if (s) {
      audioEvents.push({
        k: 'play', id: idOf(this), src: new URL(s, document.baseURI).href,
        t: virtual, off: this.currentTime || 0, loop: !!this.loop,
        rate: this.playbackRate || 1, vol: this.muted ? 0 : this.volume
      });
    }
    return Promise.resolve();
  };
  HTMLMediaElement.prototype.pause = function () {
    audioEvents.push({ k: 'stop', id: idOf(this), t: virtual });
  };

  // ---- Enregistrement audio : Web Audio API
  const abUrl = new WeakMap(), bufUrl = new WeakMap();
  const of = window.fetch;
  if (of) {
    window.fetch = function (input) {
      let url = null;
      try { url = new URL(typeof input === 'string' ? input : input.url, document.baseURI).href; } catch (e) {}
      return of.apply(this, arguments).then(res => {
        const ab = res.arrayBuffer.bind(res);
        res.arrayBuffer = () => ab().then(b => { if (url) abUrl.set(b, url); return b; });
        return res;
      });
    };
  }
  const oo = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (m, u) {
    this.addEventListener('load', () => {
      try {
        if (this.response instanceof ArrayBuffer)
          abUrl.set(this.response, new URL(u, document.baseURI).href);
      } catch (e) {}
    });
    return oo.apply(this, arguments);
  };
  const AC = window.BaseAudioContext || window.AudioContext || window.webkitAudioContext;
  if (AC) {
    const od = AC.prototype.decodeAudioData;
    AC.prototype.decodeAudioData = function (ab, ok, err) {
      const url = abUrl.get(ab);
      const tag = b => { if (url && b) bufUrl.set(b, url); return b; };
      const p = od.call(this, ab, ok ? b => ok(tag(b)) : undefined, err);
      return p && p.then ? p.then(tag) : p;
    };
  }
  const ASN = window.AudioBufferSourceNode;
  if (ASN) {
    const rel = (node, when) => {
      const now = node.context.currentTime;
      return when && when > now ? (when - now) * 1000 : 0;
    };
    ASN.prototype.start = function (when, offset, dur) {
      const url = bufUrl.get(this.buffer);
      if (url) {
        this.__id = ++uid;
        audioEvents.push({
          k: 'play', id: this.__id, src: url, t: virtual + rel(this, when),
          off: offset || 0, loop: !!this.loop, rate: this.playbackRate.value,
          vol: 1, dur: dur
        });
      }
    };
    ASN.prototype.stop = function (when) {
      if (this.__id)
        audioEvents.push({ k: 'stop', id: this.__id, t: virtual + rel(this, when) });
    };
  }

  window.__isAnimated = () =>
    saw || rafCount > 0 || ivCount > 0 || toCount > 1 ||
    document.getAnimations().length > 0 ||
    !!document.querySelector('animate,animateTransform,animateMotion,set');

  // ---- Mesure de la durée : simule le temps virtuel sans capture.
  // Retourne { end, loop, infinite } en ms.
  window.__measure = function (maxMs) {
    const step = 1000 / 30;
    let endFinite = 0, loopLen = 0, lastActive = 0, stillActive = false;
    for (let t = 0; t <= maxMs; t += step) {
      window.__seek(t);
      if (rafs.length > 0 || timers.size > 0) { lastActive = t; stillActive = true; }
      else stillActive = false;
      document.getAnimations().forEach(a => {
        try {
          const ct = a.effect.getComputedTiming();
          const dur = +ct.duration || 0, del = +ct.delay || 0, ed = +ct.endDelay || 0;
          if (ct.iterations === Infinity) {
            const alt = /alternate/.test(ct.direction) ? 2 : 1;
            loopLen = Math.max(loopLen, del + dur * alt);
          } else if (isFinite(ct.endTime)) {
            endFinite = Math.max(endFinite, ct.endTime + ed);
          }
        } catch (e) {}
      });
    }
    document.querySelectorAll('animate,animateTransform,animateMotion,set').forEach(n => {
      const p = v => { v = String(v || '').trim(); const m = v.match(/^([\d.]+)(ms|s)?$/);
        return m ? parseFloat(m[1]) * (m[2] === 'ms' ? 1 : 1000) : 0; };
      const b = p((n.getAttribute('begin') || '0').split(';')[0]);
      const d = p(n.getAttribute('dur'));
      const rc = n.getAttribute('repeatCount'), rd = p(n.getAttribute('repeatDur'));
      if (rc === 'indefinite' || n.getAttribute('repeatDur') === 'indefinite') loopLen = Math.max(loopLen, b + d);
      else endFinite = Math.max(endFinite, b + (rd || d * (parseFloat(rc) || 1)));
    });
    // tâche JS (rAF / timers) qui s'arrête d'elle-même
    if (!stillActive && lastActive > 0) endFinite = Math.max(endFinite, lastActive + step);
    return JSON.stringify({
      end: endFinite, loop: loopLen,
      infinite: stillActive, audio: audioEvents.slice()
    });
  };

  window.__seek = function (t) {
    let guard = 0;
    while (guard++ < 20000) {
      let best = null, bid = null;
      timers.forEach((v, k) => { if (v.due <= t && (!best || v.due < best.due)) { best = v; bid = k; } });
      if (!best) break;
      virtual = Math.max(virtual, best.due);
      if (best.iv) best.due += best.iv; else timers.delete(bid);
      try { best.cb(...best.a); } catch (e) {}
    }
    virtual = t;
    if (!autoDone) {
      autoDone = true;
      document.querySelectorAll('audio[autoplay],video[autoplay]').forEach(el => el.play());
    }
    document.getAnimations().forEach(a => { try { a.pause(); a.currentTime = t; } catch (e) {} });
    document.querySelectorAll('svg').forEach(s => {
      try { s.pauseAnimations(); s.setCurrentTime(t / 1000); } catch (e) {}
    });
    const cbs = rafs; rafs = [];
    cbs.forEach(([_, cb]) => { try { cb(virtual); } catch (e) {} });
  };
})();
