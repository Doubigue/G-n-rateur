package com.example.nebula

import android.app.AlertDialog
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadataRetriever
import android.media.ThumbnailUtils
import android.net.Uri
import android.os.Build
import android.util.LruCache
import android.util.Size
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.util.concurrent.Executors
import java.util.zip.ZipInputStream

/** Pack de vidéos importé depuis un .zip : les fichiers sont copiés dans le stockage privé de Nebula. */
object VideoPack {
    private val exts = setOf("mp4", "m4v", "webm", "mkv", "3gp", "mov")
    fun dir(c: Context) = File(c.filesDir, "videos").apply { mkdirs() }
    fun list(c: Context): List<File> =
        dir(c).listFiles { f -> f.isFile && f.extension.lowercase() in exts }?.sortedBy { it.name.lowercase() } ?: emptyList()

    /** Extrait les vidéos du zip (sous-dossiers ignorés, noms nettoyés). Retourne le nombre de vidéos importées. */
    fun importZip(c: Context, uri: Uri, progress: (Int) -> Unit): Int {
        var n = 0; val seen = HashSet<String>()
        c.contentResolver.openInputStream(uri)?.use { ins ->
            ZipInputStream(ins.buffered()).use { zin ->
                var e = zin.nextEntry
                while (e != null) {
                    val raw = e.name
                    val name = File(raw).name
                    val ext = File(name).extension.lowercase()
                    if (!e.isDirectory && !raw.contains("__MACOSX") && !name.startsWith(".") && ext in exts) {
                        var target = name; var k = 1
                        while (!seen.add(target.lowercase())) { target = "${File(name).nameWithoutExtension}_$k.$ext"; k++ }
                        File(dir(c), target).outputStream().use { zin.copyTo(it) }
                        n++; progress(n)
                    }
                    zin.closeEntry(); e = zin.nextEntry
                }
            }
        }
        return n
    }

    fun thumb(f: File): Bitmap? = try {
        if (Build.VERSION.SDK_INT >= 29) ThumbnailUtils.createVideoThumbnail(f, Size(480, 270), null)
        else {
            val r = MediaMetadataRetriever()
            try { r.setDataSource(f.path); r.getFrameAtTime(1_000_000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) } finally { r.release() }
        }
    } catch (_: Throwable) { null }
}

/** Écran de choix des vidéos du pack (grille de miniatures). Toucher = choisir, appui long = supprimer. */
class VideoPickerView(
    ctx: Context, private val t: NebulaTheme, private val current: () -> String?,
    private val onPick: (File) -> Unit, private val onImport: () -> Unit, private val onClose: () -> Unit
) : LinearLayout(ctx) {
    private val ex = Executors.newFixedThreadPool(2)
    private val cache = LruCache<String, Bitmap>(30)
    private var files = listOf<File>()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private inner class Ad : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        override fun getItemCount() = files.size
        override fun onCreateViewHolder(p: android.view.ViewGroup, vt: Int): RecyclerView.ViewHolder {
            val card = FrameLayout(p.context).apply {
                layoutParams = RecyclerView.LayoutParams(-1, dp(130)); setPadding(dp(4), dp(4), dp(4), dp(4))
            }
            val round = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(Color.argb(60, 255, 255, 255)) }
            card.addView(ImageView(p.context).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP; background = round; clipToOutline = true
                outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
            }, FrameLayout.LayoutParams(-1, -1))
            card.addView(TextView(p.context).apply {
                textSize = 11f; setSingleLine(); ellipsize = android.text.TextUtils.TruncateAt.END; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), 0, dp(10), 0)
                background = GradientDrawable().apply { setColor(Color.argb(150, 0, 0, 0)); cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, dp(14).toFloat(), dp(14).toFloat(), dp(14).toFloat(), dp(14).toFloat()) }
            }, FrameLayout.LayoutParams(-1, dp(26), Gravity.BOTTOM))
            return object : RecyclerView.ViewHolder(card) {}
        }
        override fun onBindViewHolder(vh: RecyclerView.ViewHolder, i: Int) {
            val f = files[i]; val card = vh.itemView as FrameLayout
            val img = card.getChildAt(0) as ImageView; val lab = card.getChildAt(1) as TextView
            val on = current() == Uri.fromFile(f).toString()
            lab.text = (if (on) "▶ " else "") + f.nameWithoutExtension; lab.setTextColor(if (on) t.accent2 else Color.WHITE)
            img.tag = f.path; val cached = cache.get(f.path); img.setImageBitmap(cached)
            if (cached == null) ex.execute {
                val b = VideoPack.thumb(f)
                if (b != null) { cache.put(f.path, b); img.post { if (img.tag == f.path) img.setImageBitmap(b) } }
            }
            card.setOnClickListener { onPick(f) }
            card.setOnLongClickListener {
                AlertDialog.Builder(context).setTitle(f.name).setItems(arrayOf("🗑️ Supprimer cette vidéo")) { _, _ -> f.delete(); cache.remove(f.path); refresh() }.show(); true
            }
        }
    }

    private val ad = Ad()
    private val title = TextView(ctx).apply { setTextColor(t.accent2); textSize = 18f }
    private val empty = TextView(ctx).apply {
        setTextColor(t.text); alpha = .7f; textSize = 14f; gravity = Gravity.CENTER
        text = "Aucune vidéo.\nAppuyez sur « ＋ Zip » pour importer un pack."
    }
    private val grid = RecyclerView(ctx).apply { layoutManager = GridLayoutManager(ctx, 2) }

    private fun chip(txt: String, click: () -> Unit) = TextView(context).apply {
        text = txt; setTextColor(t.text); textSize = 14f; setPadding(dp(14), dp(8), dp(14), dp(8))
        background = GradientDrawable().apply { cornerRadius = dp(18).toFloat(); setColor(Color.argb(60, 255, 255, 255)) }
        setOnClickListener { click() }
        layoutParams = LayoutParams(-2, -2).apply { marginStart = dp(8) }
    }

    init {
        orientation = VERTICAL; isClickable = true; visibility = View.GONE
        setBackgroundColor(Color.argb(240, Color.red(t.bgTop), Color.green(t.bgTop), Color.blue(t.bgTop)))
        setPadding(dp(12), dp(56), dp(12), dp(12))
        grid.adapter = ad
        val bar = LinearLayout(ctx).apply { gravity = Gravity.CENTER_VERTICAL }
        bar.addView(title, LayoutParams(0, -2, 1f)); bar.addView(chip("＋ Zip") { onImport() }); bar.addView(chip("✕") { onClose() })
        addView(bar)
        addView(empty, LayoutParams(-1, dp(120)).apply { topMargin = dp(30) })
        addView(grid, LayoutParams(-1, 0, 1f).apply { topMargin = dp(10) })
        refresh()
    }

    fun setStatus(s: String) { title.text = s }
    fun refresh() {
        files = VideoPack.list(context); ad.notifyDataSetChanged()
        title.text = "🎞️ Mes vidéos (${files.size})"
        empty.visibility = if (files.isEmpty()) View.VISIBLE else View.GONE
        grid.visibility = if (files.isEmpty()) View.GONE else View.VISIBLE
    }
}
