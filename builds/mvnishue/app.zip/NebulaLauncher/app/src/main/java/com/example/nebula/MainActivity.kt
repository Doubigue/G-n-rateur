package com.example.nebula

import android.Manifest
import android.app.AlertDialog
import android.app.AppOpsManager
import android.app.WallpaperManager
import android.app.admin.DevicePolicyManager
import java.io.File
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.app.usage.UsageStatsManager
import android.content.*
import android.content.pm.PackageManager
import android.graphics.*
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.provider.Settings
import android.text.TextUtils
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.WindowCompat
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs

class MainActivity : ComponentActivity() {
    private lateinit var prefs: Prefs
    private lateinit var t: NebulaTheme
    private lateinit var repo: AppRepo
    private lateinit var tilt: Tilt
    private lateinit var root: FrameLayout
    private lateinit var home: LinearLayout
    private lateinit var particles: ParticleView
    private lateinit var bgImage: ImageView
    private lateinit var bgVideo: VideoView
    private lateinit var clock: TextView
    private lateinit var weather: TextView
    private lateinit var focusLabel: TextView
    private lateinit var homeMedia: MediaCard
    private lateinit var ccMedia: MediaCard
    private lateinit var dock: LinearLayout
    private lateinit var drawer: LinearLayout
    private lateinit var grid: RecyclerView
    private lateinit var drawerSearch: EditText
    private lateinit var sortBtn: TextView
    private lateinit var searchPanel: LinearLayout
    private lateinit var searchEdit: EditText
    private lateinit var results: LinearLayout
    private lateinit var cc: LinearLayout
    private lateinit var ccInfo: TextView
    private lateinit var ccStorage: ProgressBar
    private val adapter = AppAdapter()
    private var apps = listOf<AppItem>()
    private var cat = Cat.ALL
    private var query = ""
    private var drawerOpen = false; private var searchOpen = false; private var ccOpen = false; private var videosOpen = false; private var settingsOpen = false
    private lateinit var settingsPanel: LinearLayout
    private lateinit var settingsGrid: LinearLayout
    private lateinit var videoPicker: VideoPickerView
    private val h = Handler(Looper.getMainLooper())
    private var pickKind = 0
    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            prefs.bgUri = uri.toString(); prefs.bgMode = if (pickKind == 0) 4 else 5; applyBackground()
        }
    }
    private val zipPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) importPack(uri) }
    private val loop = object : Runnable { override fun run() { tick(); h.postDelayed(this, 500) } }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun haptic(v: View = root) = v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    private fun ml(w: Int = -1, hh: Int = -2) = LinearLayout.LayoutParams(w, hh)

    private fun chip(text: String, on: Boolean = false, click: () -> Unit) = TextView(this).apply {
        this.text = text; setTextColor(t.text); textSize = 13f; setPadding(dp(14), dp(8), dp(14), dp(8))
        background = glassBg(t, dp(18).toFloat(), if (on) 130 else 45)
        setOnClickListener { haptic(it); click() }
        layoutParams = LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(8) }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        prefs = Prefs(this); t = Themes.all[prefs.theme.coerceIn(0, Themes.all.size - 1)]
        repo = AppRepo(this, prefs); tilt = Tilt(this)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        root = FrameLayout(this)
        particles = ParticleView(this)
        bgImage = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; visibility = View.GONE; setColorFilter(Color.argb(90, 0, 0, 0)) }
        bgVideo = VideoView(this).apply { visibility = View.GONE }
        root.addView(particles, FrameLayout.LayoutParams(-1, -1)); root.addView(bgImage, FrameLayout.LayoutParams(-1, -1))
        root.addView(bgVideo, FrameLayout.LayoutParams(-1, -1))

        buildHome(); buildDrawer(); buildSearchPanel(); buildControlCenter(); buildSettings(); buildVideoPicker()
        setContentView(root)
        applyBackground(); applyFocusVisual()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { // ne ferme jamais le launcher
                when { videosOpen -> closeVideos(); settingsOpen -> closeSettings(); ccOpen -> closeCC(); searchOpen -> closeSearch(); drawerOpen -> closeDrawer() }
            }
        })

        val need = mutableListOf(Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) need += Manifest.permission.POST_NOTIFICATIONS
        val missing = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 1)
        if (prefs.lockEnabled && Settings.canDrawOverlays(this)) startForegroundService(Intent(this, LockService::class.java))
        reloadApps()
    }

    // ───────────────────────── Accueil ─────────────────────────
    private fun buildHome() {
        home = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(72), dp(20), dp(36)) }
        clock = TextView(this).apply {
            textSize = 72f; setTextColor(t.accent2); typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
            setShadowLayer(26f, 0f, 0f, t.accent2)
        }
        tilt.add(clock)
        weather = TextView(this).apply { setTextColor(t.text); textSize = 18f; text = prefs.weather }
        focusLabel = TextView(this).apply { setTextColor(t.accent); textSize = 14f; visibility = View.GONE }
        homeMedia = MediaCard(this, t); homeMedia.tiltOnTouch()
        homeMedia.onOtherFling = { vx, vy -> handleFling(vx, vy) }
        dock = LinearLayout(this).apply { background = glassBg(t, dp(32).toFloat(), 55); gravity = Gravity.CENTER; setPadding(dp(12), dp(12), dp(12), dp(8)) }
        home.addView(clock); home.addView(weather); home.addView(focusLabel)
        home.addView(homeMedia, ml().apply { topMargin = dp(28) })
        home.addView(View(this), ml(-1, 0).apply { weight = 1f })
        home.addView(dock, ml())
        root.addView(home, FrameLayout.LayoutParams(-1, -1))
        root.addView(TextView(this).apply {
            text = "⚙️"; textSize = 20f; gravity = Gravity.CENTER; background = glassBg(t, dp(22).toFloat(), 90)
            setOnClickListener { haptic(it); openSettings() }
        }, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.TOP or Gravity.END).apply { topMargin = dp(52); marginEnd = dp(16) })

        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onFling(a: MotionEvent?, b: MotionEvent, vx: Float, vy: Float) = handleFling(vx, vy)
            override fun onDoubleTap(e: MotionEvent): Boolean { lockPhone(); return true }
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean { nextSeason(); return true }
        })
        home.setOnTouchListener { _, ev -> particles.touch(ev); gd.onTouchEvent(ev) }
    }

    /** Tap sur le bureau (fond de saison) : Printemps → Été → Automne → Hiver → Auto (selon l'heure) → … */
    private fun nextSeason() {
        val m = prefs.bgMode; if (m !in 8..12) return
        val n = if (m == 12) 8 else m + 1
        prefs.bgMode = n; applyBackground(); haptic()
        Toast.makeText(this, arrayOf("🌸 Printemps", "☀️ Été", "🍂 Automne", "❄️ Hiver", "🕒 Auto : suit l'heure")[n - 8], Toast.LENGTH_SHORT).show()
    }

    private fun handleFling(vx: Float, vy: Float): Boolean {
        if (abs(vy) > abs(vx)) {
            if (vy < -1200) openDrawer() else if (vy > 1200) openSearch() else return false
        } else if (vx < -1200) openCC() else return false
        return true
    }

    private fun refreshDock() {
        dock.removeAllViews()
        val pinned = prefs.dock.split(",").filter { it.isNotEmpty() }.mapNotNull { p -> apps.firstOrNull { it.pkg == p } }
        (if (pinned.isEmpty()) apps.take(4) else pinned).forEach { a ->
            val v = ReflectionIcon(this, a.icon)
            v.setOnClickListener { launch(a) }; v.setOnLongClickListener { appMenu(a); true }
            tilt.add(v); dock.addView(v, ml(0, dp(80)).apply { weight = 1f })
        }
    }

    // ───────────────────────── Tiroir intelligent ─────────────────────────
    private fun buildDrawer() {
        drawer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE; isClickable = true
            setBackgroundColor(Color.argb(215, Color.red(t.bgTop), Color.green(t.bgTop), Color.blue(t.bgTop)))
            setPadding(dp(12), dp(56), dp(12), dp(12))
        }
        drawerSearch = EditText(this).apply {
            hint = "Rechercher…"; setHintTextColor(Color.GRAY); setTextColor(t.text); background = glassBg(t, dp(20).toFloat(), 50)
            setPadding(dp(16), dp(12), dp(16), dp(12)); setSingleLine()
            doAfterTextChanged { query = it.toString(); refreshDrawer() }
        }
        sortBtn = chip("A–Z") { prefs.sort = (prefs.sort + 1) % 3; refreshDrawer() }
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        row.addView(drawerSearch, ml(0, -2).apply { weight = 1f; marginEnd = dp(8) }); row.addView(sortBtn)
        grid = RecyclerView(this).apply { layoutManager = GridLayoutManager(this@MainActivity, 4); this.adapter = this@MainActivity.adapter }
        drawer.addView(row, ml().apply { bottomMargin = dp(8) })
        drawer.addView(grid, ml(-1, 0).apply { weight = 1f })
        root.addView(drawer, FrameLayout.LayoutParams(-1, -1))
        tilt.onChange = { rx, ry ->
            if (drawerOpen) for (i in 0 until grid.childCount) { val c = grid.getChildAt(i); c.rotationX = rx * .6f; c.rotationY = ry * .6f }
        }
    }

    private fun refreshDrawer() {
        val hidden = if (prefs.focus) setOf(Cat.SOCIAL, Cat.GAMES) else emptySet()
        var list = apps.filter { it.cat !in hidden && (cat == Cat.ALL || it.cat == cat) && it.label.contains(query, true) }
        list = if (query.isNotEmpty())
            list.sortedWith(compareByDescending<AppItem> { it.label.startsWith(query, true) }.thenByDescending { prefs.launches(it.pkg) })
        else repo.sort(list, prefs.sort)
        adapter.submit(list)
        sortBtn.text = arrayOf("A–Z", "Fréquence", "Couleur")[prefs.sort]
    }

    private inner class AppAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        var data = listOf<AppItem>()
        fun submit(l: List<AppItem>) { data = l; notifyDataSetChanged() }
        override fun getItemCount() = data.size
        override fun onCreateViewHolder(p: ViewGroup, vt: Int): RecyclerView.ViewHolder {
            val v = LinearLayout(p.context).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(10)); cameraDistance = 12000f
                addView(ImageView(context), LinearLayout.LayoutParams(dp(52), dp(52)))
                addView(TextView(context).apply { setTextColor(t.text); textSize = 11f; maxLines = 1; gravity = Gravity.CENTER; ellipsize = TextUtils.TruncateAt.END })
                layoutParams = RecyclerView.LayoutParams(-1, -2)
            }
            return object : RecyclerView.ViewHolder(v) {}
        }
        override fun onBindViewHolder(vh: RecyclerView.ViewHolder, i: Int) {
            val a = data[i]; val v = vh.itemView as LinearLayout
            (v.getChildAt(0) as ImageView).setImageDrawable(a.icon.copy()); (v.getChildAt(1) as TextView).text = a.label
            v.rotationX = tilt.rx * .6f; v.rotationY = tilt.ry * .6f
            v.setOnClickListener { haptic(it); launch(a) }
            v.setOnLongClickListener { appMenu(a); true }
        }
    }

    private fun launch(a: AppItem) { prefs.addLaunch(a.pkg); try { startActivity(a.intent) } catch (_: Exception) {} }

    private fun appMenu(a: AppItem) {
        AlertDialog.Builder(this).setTitle(a.label).setItems(arrayOf("📌 Épingler au dock", "ℹ️ Infos", "🗑️ Désinstaller")) { _, i ->
            when (i) {
                0 -> {
                    val l = prefs.dock.split(",").filter { it.isNotEmpty() }.toMutableList(); l.remove(a.pkg); l.add(0, a.pkg)
                    prefs.dock = l.take(5).joinToString(","); refreshDock()
                }
                1 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}")))
                2 -> startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}")))
            }
        }.show()
    }

    // ───────────────────────── Panneau de recherche (swipe bas) ─────────────────────────
    private fun buildSearchPanel() {
        searchPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE; isClickable = true
            background = glassBg(t, dp(28).toFloat(), 190); setPadding(dp(16), dp(56), dp(16), dp(16))
        }
        searchEdit = EditText(this).apply {
            hint = "Recherche prédictive…"; setHintTextColor(Color.GRAY); setTextColor(t.text); setSingleLine()
            background = glassBg(t, dp(20).toFloat(), 50); setPadding(dp(16), dp(12), dp(16), dp(12))
            doAfterTextChanged { updateResults(it.toString()) }
        }
        val shortcuts = LinearLayout(this)
        shortcuts.addView(chip("📞") { startActivity(Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) })
        shortcuts.addView(chip("📷") { try { startActivity(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)) } catch (_: Exception) {} })
        shortcuts.addView(chip("⚙️") { startActivity(Intent(Settings.ACTION_SETTINGS)) })
        shortcuts.addView(chip("🎯 Focus") { setFocus(!prefs.focus); closeSearch() })
        results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        searchPanel.addView(searchEdit); searchPanel.addView(shortcuts, ml().apply { topMargin = dp(10) })
        searchPanel.addView(results, ml().apply { topMargin = dp(10) })
        root.addView(searchPanel, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onFling(a: MotionEvent?, b: MotionEvent, vx: Float, vy: Float): Boolean { if (vy < -1000) { closeSearch(); return true }; return false }
        })
        searchPanel.setOnTouchListener { _, e -> gd.onTouchEvent(e); false }
    }

    private fun updateResults(q: String) {
        results.removeAllViews()
        val hidden = if (prefs.focus) setOf(Cat.SOCIAL, Cat.GAMES) else emptySet()
        val l = apps.filter { it.cat !in hidden && it.label.contains(q, true) }
            .sortedWith(compareByDescending<AppItem> { it.label.startsWith(q, true) }.thenByDescending { prefs.launches(it.pkg) }).take(5)
        l.forEach { a ->
            val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(6)) }
            r.addView(ImageView(this).apply { setImageDrawable(a.icon.copy()) }, LinearLayout.LayoutParams(dp(40), dp(40)))
            r.addView(TextView(this).apply { text = a.label; setTextColor(t.text); textSize = 15f; setPadding(dp(12), 0, 0, 0) })
            r.setOnClickListener { haptic(it); closeSearch(); launch(a) }
            results.addView(r)
        }
    }

    // ───────────────────────── Centre de contrôle (swipe gauche) ─────────────────────────
    private fun buildControlCenter() {
        cc = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE; isClickable = true
            background = glassBg(t, dp(28).toFloat(), 190); setPadding(dp(16), dp(64), dp(16), dp(16))
        }
        ccMedia = MediaCard(this, t)
        ccInfo = TextView(this).apply { setTextColor(t.text); textSize = 14f }
        ccStorage = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progressTintList = android.content.res.ColorStateList.valueOf(t.accent)
        }
        val r1 = LinearLayout(this); val r2 = LinearLayout(this)
        r1.addView(chip("📶 Wi-Fi") { openWifiPanel() })
        r1.addView(chip("🔷 Bluetooth") { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) })
        r1.addView(chip("🔦") { toggleTorch() })
        r2.addView(chip("🎯 Focus") { setFocus(!prefs.focus); closeCC() })
        r2.addView(chip("🔒 Lock") { lockPhone() })
        cc.addView(TextView(this).apply { text = "Centre de contrôle"; setTextColor(t.accent2); textSize = 18f })
        cc.addView(ccMedia, ml().apply { topMargin = dp(12) })
        cc.addView(ccInfo, ml().apply { topMargin = dp(16) })
        cc.addView(ccStorage, ml(-1, dp(10)).apply { topMargin = dp(6) })
        cc.addView(r1, ml().apply { topMargin = dp(16) }); cc.addView(r2, ml().apply { topMargin = dp(8) })
        root.addView(cc, FrameLayout.LayoutParams(dp(300), -1, Gravity.END))
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onFling(a: MotionEvent?, b: MotionEvent, vx: Float, vy: Float): Boolean { if (vx > 1000) { closeCC(); return true }; return false }
        })
        cc.setOnTouchListener { _, e -> gd.onTouchEvent(e); false }
    }

    private fun refreshCC() {
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        val st = StatFs(Environment.getDataDirectory().path)
        val total = st.totalBytes; val used = total - st.availableBytes
        ccStorage.progress = (used * 100 / total).toInt()
        ccInfo.text = "🔋 Batterie ${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)}%\n💾 Stockage ${used shr 30} / ${total shr 30} Go"
        ccMedia.refresh()
    }

    // ───────────────────────── Ouverture / fermeture des panneaux ─────────────────────────
    private fun openDrawer() {
        if (drawerOpen) return; drawerOpen = true; haptic(); refreshDrawer()
        drawer.visibility = View.VISIBLE; drawer.translationY = root.height.toFloat()
        drawer.animate().translationY(0f).setDuration(300).setInterpolator(android.view.animation.DecelerateInterpolator(1.6f)).start()
        if (Build.VERSION.SDK_INT >= 31) home.setRenderEffect(RenderEffect.createBlurEffect(40f, 40f, Shader.TileMode.CLAMP))
    }
    private fun closeDrawer() {
        drawerOpen = false; drawerSearch.setText(""); cat = Cat.ALL
        drawer.animate().translationY(root.height.toFloat()).setDuration(220).withEndAction { drawer.visibility = View.GONE }.start()
        if (Build.VERSION.SDK_INT >= 31) home.setRenderEffect(null)
    }
    private fun openSearch() {
        if (searchOpen) return; searchOpen = true; haptic(); updateResults("")
        searchPanel.visibility = View.VISIBLE; searchPanel.translationY = -root.height.toFloat()
        searchPanel.animate().translationY(0f).setDuration(260).start()
        searchEdit.requestFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(searchEdit, 0)
    }
    private fun closeSearch() {
        searchOpen = false; searchEdit.setText("")
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(searchEdit.windowToken, 0)
        searchPanel.animate().translationY(-root.height.toFloat()).setDuration(220).withEndAction { searchPanel.visibility = View.GONE }.start()
    }
    private fun openCC() {
        if (ccOpen) return; ccOpen = true; haptic(); refreshCC()
        cc.visibility = View.VISIBLE; cc.translationX = dp(300).toFloat(); cc.animate().translationX(0f).setDuration(260).start()
    }
    private fun closeCC() {
        ccOpen = false
        cc.animate().translationX(dp(300).toFloat()).setDuration(220).withEndAction { cc.visibility = View.GONE }.start()
    }

    // ───────────────────────── Fond d'écran ─────────────────────────
    private fun applyBackground() {
        val m = prefs.bgMode
        particles.engine.theme = t; if (m < 4 || m >= 6) particles.engine.style = m; particles.engine.rebuild()
        particles.visibility = if (m < 4 || m >= 6) View.VISIBLE else View.GONE
        bgImage.visibility = View.GONE; bgVideo.visibility = View.GONE; bgVideo.stopPlayback()
        val uri = prefs.bgUri?.let { Uri.parse(it) } ?: return
        try {
            if (m == 4) { bgImage.setImageURI(uri); bgImage.visibility = View.VISIBLE }
            if (m == 5) {
                bgVideo.visibility = View.VISIBLE; bgVideo.setVideoURI(uri)
                bgVideo.setOnPreparedListener { it.isLooping = true; it.setVolume(0f, 0f) }
                bgVideo.setOnErrorListener { _, _, _ -> bgVideo.visibility = View.GONE; particles.visibility = View.VISIBLE
                    Toast.makeText(this, "Vidéo illisible (lien ou format)", Toast.LENGTH_LONG).show(); true }
                bgVideo.start()
            }
        } catch (_: Exception) { particles.visibility = View.VISIBLE }
    }

    // ───────────────────────── Mode Focus / Détox ─────────────────────────
    private fun setFocus(on: Boolean) {
        prefs.focus = on; if (on) prefs.focusSince = System.currentTimeMillis()
        haptic(); applyFocusVisual(); refreshDrawer()
    }
    private fun applyFocusVisual() {
        val p = Paint().apply { colorFilter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(0f) }) }
        root.setLayerType(if (prefs.focus) View.LAYER_TYPE_HARDWARE else View.LAYER_TYPE_NONE, if (prefs.focus) p else null)
        focusLabel.visibility = if (prefs.focus) View.VISIBLE else View.GONE
    }
    private fun screenTimeMs(): Long = try {
        val usm = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
        val cal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0) }
        usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, cal.timeInMillis, System.currentTimeMillis()).sumOf { it.totalTimeInForeground }
    } catch (_: Throwable) { 0L }

    private fun tick() {
        clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        homeMedia.refresh(); if (ccOpen) ccMedia.refresh()
        if (prefs.focus) {
            val s = (System.currentTimeMillis() - prefs.focusSince) / 1000; val st = screenTimeMs() / 60000
            focusLabel.text = "🎯 Focus %02d:%02d  •  Écran aujourd'hui : %s".format(s / 60, s % 60, if (st > 0) "${st / 60} h ${st % 60} min" else "(autoriser dans le menu)")
        }
    }

    // ───────────────────────── Menu & actions système ─────────────────────────
    private fun adminName() = ComponentName(this, NebulaAdmin::class.java)
    private fun dpm() = getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager
    private fun askAdmin() = startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
        .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminName())
        .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Permet à Nebula de verrouiller l'écran d'un double-tap."))
    private fun lockPhone() {
        val s = LockAccessibilityService.instance
        when {
            s != null -> s.lock()
            dpm().isAdminActive(adminName()) -> dpm().lockNow()
            else -> askAdmin() // une seule fenêtre « Activer », pas de réglages à fouiller
        }
    }
    private fun hasUsageAccess(): Boolean = try {
        val ao = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        ao.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    } catch (_: Throwable) { false }
    private fun openWifiPanel() {
        try { startActivity(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)) } // volet par-dessus l'appli : on bascule le Wi-Fi sans quitter Nebula
        catch (_: Exception) { startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) }
    }
    private var torchOn = false
    private fun toggleTorch() {
        try {
            val cm = getSystemService(CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true } ?: return
            torchOn = !torchOn; cm.setTorchMode(id, torchOn); haptic()
        } catch (_: Exception) { torchOn = false; Toast.makeText(this, "Lampe indisponible", Toast.LENGTH_SHORT).show() }
    }
    // ───────────────────────── Pack de vidéos (zip) ─────────────────────────
    private fun buildVideoPicker() {
        videoPicker = VideoPickerView(this, t, { prefs.bgUri }, { f ->
            prefs.bgUri = Uri.fromFile(f).toString(); prefs.bgMode = 5; applyBackground(); closeVideos()
            Toast.makeText(this, "🎬 ${f.nameWithoutExtension}", Toast.LENGTH_SHORT).show()
        }, { zipPicker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")) }, { closeVideos() })
        root.addView(videoPicker, FrameLayout.LayoutParams(-1, -1))
    }
    private fun openVideos() {
        if (videosOpen) return; videosOpen = true; haptic(); videoPicker.refresh()
        videoPicker.alpha = 0f; videoPicker.visibility = View.VISIBLE; videoPicker.animate().alpha(1f).setDuration(220).start()
    }
    private fun closeVideos() {
        videosOpen = false
        videoPicker.animate().alpha(0f).setDuration(180).withEndAction { videoPicker.visibility = View.GONE }.start()
    }
    private fun importPack(uri: Uri) {
        Toast.makeText(this, "Import du pack en cours…", Toast.LENGTH_SHORT).show()
        Thread {
            val n = try { VideoPack.importZip(this, uri) { c -> h.post { videoPicker.setStatus("Import… $c vidéo(s)") } } } catch (e: Throwable) { -1 }
            h.post {
                videoPicker.refresh()
                Toast.makeText(this, when { n < 0 -> "Import impossible (zip illisible ou stockage plein)"; n == 0 -> "Aucune vidéo trouvée dans ce zip (mp4, webm, mkv, 3gp)"
                    else -> "✔ $n vidéo(s) importée(s)" }, Toast.LENGTH_LONG).show()
                if (n > 0) openVideos()
            }
        }.start()
    }
    private fun askVideoUrl() {
        val et = EditText(this).apply { hint = "https://…/video.mp4"; setSingleLine(); setText(prefs.bgUri?.takeIf { it.startsWith("https://") } ?: "") }
        AlertDialog.Builder(this).setTitle("Lien d'une vraie vidéo (mp4, https)").setView(et)
            .setPositiveButton("OK") { _, _ ->
                val u = et.text.toString().trim()
                if (u.startsWith("https://")) { prefs.bgUri = u; prefs.bgMode = 5; applyBackground() }
                else Toast.makeText(this, "Le lien doit commencer par https://", Toast.LENGTH_LONG).show()
            }.setNegativeButton("Annuler", null).show()
    }

    // ───────────────────────── Réglages Nebula : un écran de tuiles, chaque tuile agit directement ─────────────────────────
    private class Tile(val icon: String, val title: String, val state: String?, val on: Boolean?, val act: () -> Unit)

    private val bgNames = listOf("Particules", "Vagues fluides", "Motifs géométriques", "Nébuleuse", "Image de la galerie…", "Vidéo de la galerie…",
        "🦋 Papillon", "🐦 Oiseaux", "🌸 Printemps (cerisiers & fleurs)", "☀️ Été (soleil & tournesols)", "🍂 Automne (forêt dorée)", "❄️ Hiver (neige & aurore)",
        "🕒 Saisons selon l'heure (6 h chacune)", "🌱 Fleur qui naît et fleurit", "🏖️ Plage (soleil, lune, heure réelle)",
        "🌙 Nuit étoilée & vraie lune", "🌐 Vraie vidéo depuis un lien (https)…", "🎞️ Mes vidéos (pack importé)…")

    private fun buildSettings() {
        settingsPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE; isClickable = true
            setBackgroundColor(Color.argb(240, Color.red(t.bgTop), Color.green(t.bgTop), Color.blue(t.bgTop)))
            setPadding(dp(14), dp(56), dp(14), dp(12))
        }
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        bar.addView(TextView(this).apply { text = "⚙️ Nebula"; setTextColor(t.accent2); textSize = 20f }, ml(0, -2).apply { weight = 1f })
        bar.addView(chip("✕") { closeSettings() })
        settingsGrid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        settingsPanel.addView(bar)
        settingsPanel.addView(ScrollView(this).apply { addView(settingsGrid) }, ml(-1, 0).apply { weight = 1f; topMargin = dp(12) })
        root.addView(settingsPanel, FrameLayout.LayoutParams(-1, -1))
    }
    private fun openSettings() {
        if (settingsOpen) return; settingsOpen = true; refreshSettings()
        settingsPanel.alpha = 0f; settingsPanel.visibility = View.VISIBLE; settingsPanel.animate().alpha(1f).setDuration(200).start()
    }
    private fun closeSettings() {
        settingsOpen = false; settingsPanel.animate().alpha(0f).setDuration(160).withEndAction { settingsPanel.visibility = View.GONE }.start()
    }
    private fun bgMenu() = pick(bgNames) { k ->
        when {
            k == 16 -> askVideoUrl()
            k == 17 -> { closeSettings(); openVideos() }
            k < 4 || k >= 6 -> { prefs.bgMode = k; applyBackground() }
            else -> { pickKind = k - 4; picker.launch(arrayOf(if (k == 4) "image/*" else "video/*")) }
        }
    }
    private fun iconMenu() {
        val packs = IconPacks.available(packageManager)
        pick(listOf("Par défaut") + packs.map { it.second }) { k -> prefs.iconPack = if (k == 0) "" else packs[k - 1].first; reloadApps() }
    }
    private fun liveWallpaper() = try {
        startActivity(Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
            .putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, ComponentName(this, NebulaWallpaperService::class.java)))
    } catch (_: Exception) { startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER)) }

    private fun refreshSettings() {
        val dbl = LockAccessibilityService.instance != null || dpm().isAdminActive(adminName())
        val tiles = listOf(
            Tile("🎨", "Thème", Themes.all[prefs.theme.coerceIn(0, Themes.all.size - 1)].name, null) { pick(Themes.all.map { it.name }) { prefs.theme = it; recreate() } },
            Tile("🖼️", "Fond d'écran", bgNames.getOrNull(prefs.bgMode)?.substringAfter(' ') ?: "", null) { bgMenu() },
            Tile("🎞️", "Mes vidéos", "${VideoPack.list(this).size} vidéo(s)", null) { closeSettings(); openVideos() },
            Tile("📦", "Importer un pack", "fichier .zip", null) { zipPicker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")) },
            Tile("🧩", "Pack d'icônes", if (prefs.iconPack.isEmpty()) "Par défaut" else "Personnalisé", null) { iconMenu() },
            Tile("↕️", "Tri du tiroir", arrayOf("A–Z", "Fréquence", "Couleur")[prefs.sort.coerceIn(0, 2)], null) { pick(listOf("A–Z", "Fréquence d'utilisation", "Couleur dominante")) { prefs.sort = it; refreshDrawer() } },
            Tile("🔒", "Écran de verrouillage", null, prefs.lockEnabled) { toggleLock() },
            Tile("👆", "Double-tap = veille", null, dbl) { if (dbl && LockAccessibilityService.instance == null) { dpm().removeActiveAdmin(adminName()); Toast.makeText(this, "Double-tap désactivé", Toast.LENGTH_SHORT).show() } else if (!dbl) askAdmin() },
            Tile("⏱️", "Temps d'écran", null, hasUsageAccess()) { if (!hasUsageAccess()) startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS, Uri.parse("package:$packageName"))) },
            Tile("🎯", "Mode Focus", null, prefs.focus) { setFocus(!prefs.focus) },
            Tile("🌌", "Fond animé système", "live wallpaper", null) { liveWallpaper() },
            Tile("🔦", "Lampe", null, torchOn) { toggleTorch() },
            Tile("📶", "Wi-Fi", "volet rapide", null) { openWifiPanel() },
            Tile("🔷", "Bluetooth", null, null) { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
        )
        settingsGrid.removeAllViews()
        tiles.chunked(2).forEach { pair ->
            val row = LinearLayout(this)
            pair.forEach { tl -> row.addView(tileView(tl), ml(0, -2).apply { weight = 1f; setMargins(dp(4), dp(4), dp(4), dp(4)) }) }
            if (pair.size == 1) row.addView(View(this), ml(0, 1).apply { weight = 1f })
            settingsGrid.addView(row)
        }
    }
    private fun tileView(tl: Tile) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14))
        background = glassBg(t, dp(20).toFloat(), if (tl.on == true) 150 else 55)
        addView(TextView(context).apply { text = tl.icon; textSize = 26f })
        addView(TextView(context).apply { text = tl.title; setTextColor(t.text); textSize = 14f; setPadding(0, dp(6), 0, 0) })
        val st = tl.state ?: tl.on?.let { if (it) "ON" else "OFF" }
        if (st != null) addView(TextView(context).apply { text = st; setTextColor(if (tl.on == true) t.accent2 else t.text); alpha = if (tl.on == true) 1f else .65f; textSize = 12f })
        setOnClickListener { haptic(it); tl.act(); h.postDelayed({ if (settingsOpen) refreshSettings() }, 350) }
    }
    private fun pick(items: List<String>, cb: (Int) -> Unit) =
        AlertDialog.Builder(this).setItems(items.toTypedArray()) { _, i -> cb(i) }.show()

    private fun toggleLock() {
        if (!prefs.lockEnabled) {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Autorise « Affichage par-dessus d'autres applis »", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); return
            }
            prefs.lockEnabled = true; startForegroundService(Intent(this, LockService::class.java))
            if (!MediaHelper.hasAccess(this)) {
                if (Build.VERSION.SDK_INT >= 30) startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS)
                    .putExtra(Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME, ComponentName(this, MediaListener::class.java).flattenToString()))
                else startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        } else { prefs.lockEnabled = false; stopService(Intent(this, LockService::class.java)) }
    }

    private fun reloadApps() {
        Thread {
            val l = repo.load()
            h.post { apps = l; refreshDock(); refreshDrawer() }
        }.start()
    }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); if (ccOpen) closeCC(); if (searchOpen) closeSearch(); if (drawerOpen) closeDrawer() }
    override fun onRequestPermissionsResult(rc: Int, p: Array<String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r); Weather.fetch(this) { s -> h.post { weather.text = s } }
    }
    override fun onResume() {
        super.onResume(); tilt.start(); h.post(loop)
        Weather.fetch(this) { s -> h.post { weather.text = s } }
        if (prefs.bgMode == 5) try { bgVideo.start() } catch (_: Exception) {}
        if (settingsOpen) refreshSettings()
    }
    override fun onPause() { super.onPause(); tilt.stop(); h.removeCallbacks(loop) }
}
