package com.example.mydm.core

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray

enum class SearchEngine(val label: String, val template: String) {
    GOOGLE("Google", "https://www.google.com/search?q="),
    DUCKDUCKGO("DuckDuckGo", "https://duckduckgo.com/?q="),
    BING("Bing", "https://www.bing.com/search?q="),
    ECOSIA("Ecosia", "https://www.ecosia.org/search?q=")
}

/** Réglages de l'application (SharedPreferences + état Compose, donc l'UI se met à jour seule). */
object Prefs {
    const val DEFAULT_HOME = "https://www.google.com"
    private lateinit var sp: SharedPreferences

    var homeUrl by mutableStateOf(DEFAULT_HOME); private set
    var searchEngine by mutableStateOf(SearchEngine.GOOGLE); private set
    var desktopMode by mutableStateOf(false); private set
    var blockPopups by mutableStateOf(false); private set
    var restoreTabs by mutableStateOf(true); private set
    var maxSegments by mutableIntStateOf(8); private set

    fun init(ctx: Context) {
        sp = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
        homeUrl = sp.getString("home", DEFAULT_HOME) ?: DEFAULT_HOME
        searchEngine = runCatching { SearchEngine.valueOf(sp.getString("engine", "GOOGLE")!!) }.getOrDefault(SearchEngine.GOOGLE)
        desktopMode = sp.getBoolean("desktop", false)
        blockPopups = sp.getBoolean("blockPopups", false)
        restoreTabs = sp.getBoolean("restoreTabs", true)
        maxSegments = sp.getInt("segments", 8)
    }

    fun setHomeUrl(v: String) {
        val t = v.trim().ifEmpty { DEFAULT_HOME }
        homeUrl = if (t.startsWith("http://") || t.startsWith("https://")) t else "https://$t"
        sp.edit().putString("home", homeUrl).apply()
    }
    fun setSearchEngine(v: SearchEngine) { searchEngine = v; sp.edit().putString("engine", v.name).apply() }
    fun setDesktopMode(v: Boolean) { desktopMode = v; sp.edit().putBoolean("desktop", v).apply() }
    fun setBlockPopups(v: Boolean) { blockPopups = v; sp.edit().putBoolean("blockPopups", v).apply() }
    fun setRestoreTabs(v: Boolean) { restoreTabs = v; sp.edit().putBoolean("restoreTabs", v).apply() }
    fun setMaxSegments(v: Int) { maxSegments = v; sp.edit().putInt("segments", v).apply() }

    /** Transforme ce que tape l'utilisateur en URL : adresse, domaine ou recherche. */
    fun resolveInput(input: String): String {
        val t = input.trim()
        return when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            "." in t && " " !in t -> "https://$t"
            else -> searchEngine.template + android.net.Uri.encode(t)
        }
    }

    // ── Onglets ouverts (restaurés au démarrage si l'option est active)
    fun saveTabs(urls: List<String>, current: Int) {
        sp.edit().putString("tabs", JSONArray(urls).toString()).putInt("tabIndex", current).apply()
    }
    fun savedTabs(): List<String> = runCatching {
        val a = JSONArray(sp.getString("tabs", "[]"))
        List(a.length()) { a.getString(it) }.filter { it.startsWith("http") }
    }.getOrDefault(emptyList())
    fun savedTabIndex(): Int = sp.getInt("tabIndex", 0)
}
