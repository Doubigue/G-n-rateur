package com.example.mydm.ui

import android.webkit.CookieManager
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.mydm.browser.BrowserManager
import com.example.mydm.core.Prefs
import com.example.mydm.core.SearchEngine

@Composable
fun SettingsScreen(manager: BrowserManager, onBack: () -> Unit) {
    val ctx = LocalContext.current
    fun toast(m: String) = Toast.makeText(ctx, m, Toast.LENGTH_SHORT).show()
    var home by remember { mutableStateOf(Prefs.homeUrl) }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 4.dp, top = 8.dp, end = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onBack) { Text("◀", fontSize = 18.sp) }
            Text("Paramètres", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {

            item {
                Section("Navigateur") {
                    Text("Page d'accueil", color = Color.White)
                    OutlinedTextField(home, { home = it }, Modifier.fillMaxWidth().padding(top = 6.dp), singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { Prefs.setHomeUrl(home); home = Prefs.homeUrl; toast("Enregistré") }))
                    Row {
                        TextButton({ Prefs.setHomeUrl(home); home = Prefs.homeUrl; toast("Enregistré") }) { Text("Enregistrer") }
                        TextButton({ Prefs.setHomeUrl(manager.current.url); home = Prefs.homeUrl; toast("Page actuelle définie") }) { Text("Utiliser la page actuelle") }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Moteur de recherche", color = Color.White)
                    SearchEngine.entries.forEach { e ->
                        Row(Modifier.fillMaxWidth().clickable { Prefs.setSearchEngine(e) }, verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(Prefs.searchEngine == e, { Prefs.setSearchEngine(e) })
                            Text(e.label, color = Color.White)
                        }
                    }
                    SwitchRow("Mode ordinateur", "Affiche la version bureau des sites (recharge les onglets)", Prefs.desktopMode) {
                        Prefs.setDesktopMode(it)
                    }
                    SwitchRow("Bloquer les pop-ups", "Ignore les fenêtres ouvertes sans clic de votre part", Prefs.blockPopups) {
                        Prefs.setBlockPopups(it)
                    }
                    SwitchRow("Rouvrir les onglets au démarrage", "Retrouve vos onglets à la prochaine ouverture", Prefs.restoreTabs) {
                        Prefs.setRestoreTabs(it)
                    }
                }
            }

            item {
                Section("Téléchargements") {
                    Text("Connexions simultanées par fichier", color = Color.White)
                    Text("Plus il y en a, plus c'est rapide (si le serveur l'accepte). S'applique aux nouveaux téléchargements.",
                        color = Muted, fontSize = 12.sp)
                    Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(4, 8, 16).forEach { n ->
                            FilterChip(Prefs.maxSegments == n, { Prefs.setMaxSegments(n) }, label = { Text("$n") })
                        }
                    }
                }
            }

            item {
                Section("Données") {
                    TextButton({ CookieManager.getInstance().removeAllCookies(null); CookieManager.getInstance().flush(); toast("Cookies effacés") }) {
                        Text("Effacer les cookies")
                    }
                    TextButton({ manager.clearCacheAndHistory(); toast("Cache et historique effacés") }) {
                        Text("Effacer le cache et l'historique")
                    }
                    TextButton({ manager.clearDetected(); toast("Liste des médias vidée") }) {
                        Text("Vider les médias détectés")
                    }
                }
            }
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) =
    Column(Modifier.fillMaxWidth().glass().padding(16.dp)) {
        Text(title, color = Accent, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Spacer(Modifier.height(10.dp))
        content()
    }

@Composable
private fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) =
    Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, color = Color.White)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
        Switch(checked, onChange)
    }
