package com.example.mydm.ui

import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.mydm.browser.PageScan
import com.example.mydm.browser.PageScanner
import com.example.mydm.core.*
import kotlinx.coroutines.launch

/**
 * Fenêtre « Télécharger » :
 *  • lien YouTube / Facebook / TikTok → qualités + tailles (analyse pré-chargée, donc quasi instantanée) ;
 *  • autre page (cinezzz, papadustream…) → analyse SANS lecture de la vidéo ;
 *  • médias détectés pendant la navigation.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DownloadSheet(
    found: SnapshotStateList<DetectedMedia>, pageUrl: String, onDismiss: () -> Unit
) {
    val ctx = LocalContext.current
    val app = appInstance()
    val scope = rememberCoroutineScope()

    var link by remember { mutableStateOf(if (pageUrl.startsWith("http")) pageUrl else "") }
    var loading by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf(MediaResolver.cached(link)) }
    var scan by remember { mutableStateOf<PageScan?>(null) }
    var infoUrl by remember { mutableStateOf(link) }
    var error by remember { mutableStateOf<String?>(null) }
    val sizes = remember { mutableStateMapOf<String, Long?>() }
    val ytState by app.ytState.collectAsState()
    var startAt by remember { mutableStateOf<Long?>(null) }          // null = tout de suite
    var showSchedule by remember { mutableStateOf(false) }
    fun addedMsg() = startAt?.let { "Programmé : ${formatWhen(it)}" } ?: "Téléchargement ajouté"

    fun analyze() {
        val u = link.trim()
        if (u.isEmpty()) return
        val url = if (u.startsWith("http")) u else Prefs.resolveInput(u)
        loading = true; error = null; info = null; scan = null
        scope.launch {
            if (MediaResolver.isSupportedPage(url)) {
                runCatching { MediaResolver.ytInfo(app, url) }
                    .onSuccess { info = it; infoUrl = url }
                    .onFailure { error = (it.message ?: "Analyse impossible").take(240) }
            } else {
                runCatching { PageScanner.scan(ctx, url, null, true) }
                    .onSuccess {
                        scan = it; infoUrl = url
                        if (it.media.isEmpty() && it.embeds.isEmpty())
                            error = "Aucun média trouvé. Essayez de lancer la vidéo dans la page, ou augmentez la durée d'analyse (Paramètres)."
                    }
                    .onFailure { error = (it.message ?: "Analyse impossible").take(240) }
            }
            loading = false
        }
    }

    // Ouverture : analyse automatique (YouTube/Facebook/TikTok : déjà pré-chargée ; autre page : analyse sans lecture)
    LaunchedEffect(Unit) {
        if (link.isBlank() || info != null) return@LaunchedEffect
        if (MediaResolver.isSupportedPage(link)) { if (MediaResolver.isVideoPage(link)) analyze() }
        // autre page : aucune analyse automatique — c'est vous qui choisissez le lecteur ; on affiche la vidéo en lecture
    }

    fun downloadYt(opt: QualityOption) {
        val i = info ?: return
        scope.launch {
            val id = app.downloadEngine.enqueueYt(infoUrl, i.title, opt, durationSec = i.durationSec, sizeBytes = opt.sizeBytes)
            DownloadActions.launch(ctx, app, id, startAt)
            Toast.makeText(ctx, addedMsg(), Toast.LENGTH_SHORT).show()
            onDismiss()
        }
    }

    fun downloadDirect(m: DetectedMedia, variant: HlsVariant? = null) {
        scope.launch {
            DownloadActions.queue(ctx, app, m, variant = variant, startAt = startAt)
            Toast.makeText(ctx, addedMsg(), Toast.LENGTH_SHORT).show()
        }
    }

    fun downloadEmbed(embed: String) {
        scope.launch {
            val name = cleanName(scan?.title.orEmpty()).ifBlank { "video" }
            val id = app.downloadEngine.enqueueYt(embed, name, QualityOption("", null, false, "bv*+ba/b"), infoUrl)
            DownloadActions.launch(ctx, app, id, startAt)
            Toast.makeText(ctx, startAt?.let { "Programmé : ${formatWhen(it)}" } ?: "Ajouté (yt-dlp)", Toast.LENGTH_SHORT).show()
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = Bg
    ) {
        LazyColumn(
            Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item { Text("Télécharger", color = Txt, fontSize = 20.sp) }

            item {
                Column(Modifier.fillMaxWidth().glass().padding(12.dp)) {
                    Text("Lien ou page (YouTube, Facebook, TikTok, site de séries…)", color = Muted, fontSize = 12.sp)
                    OutlinedTextField(link, { link = it }, Modifier.fillMaxWidth(), singleLine = true,
                        placeholder = { Text("Collez un lien ici") })
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button({ analyze() }, enabled = link.isNotBlank() && !loading) { Text("Analyser") }
                        Spacer(Modifier.width(10.dp))
                        if (ytState == "loading") Text("Moteur en préparation…", color = Muted, fontSize = 11.sp)
                        else if (ytState.startsWith("error:")) Text("Moteur yt-dlp indisponible", color = Danger, fontSize = 11.sp)
                        else Text("Pour un lien collé", color = Muted, fontSize = 11.sp)
                    }
                }
            }
            item { ScheduleBar(startAt, { showSchedule = true }, { startAt = null }) }
            if (loading) item {
                Column {
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                    Text(if (MediaResolver.isSupportedPage(link)) "Analyse du lien…" else "Analyse de la page en arrière-plan…", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
                }
            }
            error?.let { e -> item { Text(e, color = Danger, fontSize = 12.sp) } }

            // ── YouTube / Facebook / TikTok
            info?.let { i ->
                item { Text(i.title + (i.uploader?.let { " — $it" } ?: "") + (if (i.durationSec > 0) "  •  ⏱ ${formatDuration(i.durationSec)}" else ""), color = Accent, maxLines = 2, overflow = TextOverflow.Ellipsis) }
                items(i.options) { o ->
                    Row(Modifier.fillMaxWidth().glass().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(o.label, color = Txt)
                            Text(o.sizeBytes?.let { (if (o.approx) "~" else "") + formatSize(it) } ?: "taille inconnue", color = Muted, fontSize = 12.sp)
                        }
                        Button({ downloadYt(o) }) { Text("Télécharger") }
                    }
                }
            }

            // ── Page analysée sans lecture
            scan?.let { sc ->
                if (sc.title.isNotBlank()) item { Text(sc.title, color = Accent, maxLines = 2, overflow = TextOverflow.Ellipsis) }
                if (sc.media.isNotEmpty()) {
                    item { Text("Vidéos et fichiers trouvés (${sc.media.size})", color = Txt, modifier = Modifier.padding(top = 4.dp)) }
                    items(sc.media, key = { "s" + it.url }) { m -> MediaRow(m, sizes) { downloadDirect(m) } }
                }
                if (sc.media.none { it.type == MediaType.VIDEO || it.type == MediaType.HLS } && sc.embeds.isNotEmpty()) {
                    item {
                        Text("Lecteurs intégrés (yt-dlp peut en extraire certains)", color = Txt, modifier = Modifier.padding(top = 4.dp))
                    }
                    items(sc.embeds.take(6), key = { "e" + it }) { e ->
                        Row(Modifier.fillMaxWidth().glass().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text((Uri.parse(e).host ?: e) + if (MediaResolver.isKnownHoster(e)) "  ✓" else "", color = Txt, fontSize = 13.sp,
                                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                            Button({ downloadEmbed(e) }) { Text("Essayer") }
                        }
                    }
                }
            }

            // ── Médias détectés pendant la navigation
            item { Text("Vidéo en cours de lecture", color = Txt, modifier = Modifier.padding(top = 8.dp)) }
            if (found.isEmpty()) item {
                Text("Aucune vidéo en lecture. Choisissez le lecteur dans la page et lancez la vidéo, puis rouvrez ce panneau.", color = Muted, fontSize = 12.sp)
            }
            items(found.toList(), key = { "f" + it.url }) { m -> PlayingCard(m, sizes) { v -> downloadDirect(m, v) } }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
    if (showSchedule) ScheduleDialog(onDismiss = { showSchedule = false }) { startAt = it; showSchedule = false }
}

@Composable
private fun MediaRow(m: DetectedMedia, sizes: MutableMap<String, Long?>, onGet: () -> Unit) {
    LaunchedEffect(m.url) { if (m.sizeBytes == null && m.url !in sizes) sizes[m.url] = MediaResolver.sizeOf(m) }
    val size = m.sizeBytes ?: sizes[m.url]
    Row(Modifier.fillMaxWidth().glass().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(m.displayName(), color = Txt, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
            Text(m.type.name + " • " + m.sizeText(size, m.url in sizes) +
                " • " + (Uri.parse(m.url).host ?: ""), color = Muted, fontSize = 11.sp, maxLines = 1)
        }
        Button(onGet, contentPadding = PaddingValues(horizontal = 12.dp)) { Text("⬇") }
    }
}

/** La vidéo en cours de lecture : durée, taille et — seulement si le flux en propose plusieurs — choix de la qualité. */
@Composable
private fun PlayingCard(m: DetectedMedia, sizes: MutableMap<String, Long?>, onGet: (HlsVariant?) -> Unit) {
    var meta by remember(m.url) { mutableStateOf(MediaResolver.cachedMeta(m.url)) }
    LaunchedEffect(m.url) { if (meta == null) meta = MediaResolver.probeMeta(m) }
    LaunchedEffect(m.url) { if (m.type != MediaType.HLS && m.sizeBytes == null && m.url !in sizes) sizes[m.url] = MediaResolver.probeSize(m) }
    // Fichier direct : taille exacte ; flux HLS : taille estimée (débit × durée ou segments mesurés), « ~ » devant
    val size = m.sizeBytes ?: if (m.type == MediaType.HLS) meta?.sizeBytes else sizes[m.url]
    val probed = if (m.type == MediaType.HLS) meta != null else m.url in sizes
    val dur = meta?.durationSec
    val variants = meta?.variants.orEmpty()
    Column(Modifier.fillMaxWidth().glass().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(m.displayName(), color = Txt, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
        Text(buildString {
            append(m.type.name)
            append(if (dur != null) "  •  ⏱ ${formatDuration(dur)}" else if (meta == null) "  •  durée…" else "")
            append("  •  " + m.sizeText(size, probed))
            append("  •  " + (Uri.parse(m.url).host ?: ""))
        }, color = Muted, fontSize = 11.sp, maxLines = 2)
        if (variants.size >= 2) {
            Text("Choisissez la qualité", color = Muted, fontSize = 12.sp)
            variants.forEach { v ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(v.label, color = Txt)
                        Text(v.estimatedSize(dur)?.let { "~" + formatSize(it) } ?: "taille inconnue", color = Muted, fontSize = 11.sp)
                    }
                    Button({ onGet(v) }, contentPadding = PaddingValues(horizontal = 12.dp)) { Text("⬇ Télécharger") }
                }
            }
        } else Button({ onGet(null) }, Modifier.fillMaxWidth()) { Text("⬇ Télécharger") }
    }
}
