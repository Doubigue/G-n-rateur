# MonBudget CI

Application web de gestion financière personnelle, conçue pour fonctionner localement et hors ligne.

## Fichiers
- `index.html` : application complète (interface, styles et logique).
- `sw.js` : service worker de mise en cache hors ligne.
- `manifest.webmanifest` : métadonnées PWA.

## Lancer l'application
Pour tester rapidement, ouvrez `index.html` dans un navigateur moderne. IndexedDB et les fonctions PWA sont plus fiables lorsque le site est servi via HTTPS ou `localhost`. Le Service Worker ne peut pas s'activer depuis `file://`.

Sur téléphone, hébergez ces fichiers sur un hébergement statique HTTPS pour l'installation PWA, tout en gardant les données financières stockées localement sur chaque appareil. L'hébergement sert uniquement les fichiers de l'application ; les opérations ne sont pas envoyées à un serveur.

## Première utilisation
1. Ouvrez **Administration** et déverrouillez avec le PIN initial `1234`.
2. Changez immédiatement ce PIN.
3. Ajoutez vos revenus et renseignez les soldes initiaux des comptes si nécessaire.
4. Exportez régulièrement une sauvegarde JSON depuis **Sauvegarde**.

## Notes importantes
- Les données sont stockées dans IndexedDB, avec une copie de secours dans localStorage.
- La restauration remplace les données existantes après confirmation.
- Le PIN est une barrière d'interface locale, pas un chiffrement. Les données du navigateur ne sont pas chiffrées par cette application.
- Les avatars sont des URL externes et peuvent ne pas s'afficher hors ligne.
- Les transferts valident le solde disponible. Les dépenses aussi : saisissez un solde initial ou un revenu avant d'enregistrer une dépense.
- Conservez le fichier JSON en lieu sûr : effacer les données du navigateur ou désinstaller l'application peut supprimer les données locales.
