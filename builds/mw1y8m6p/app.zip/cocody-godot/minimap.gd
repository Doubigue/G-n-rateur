extends Control
## Mini-carte de Cocody, orientée selon la caméra.

var g = null
const K := 0.4

func _w2m(p: Vector2, pp: Vector2, th: float, clamp_edge: bool) -> Array:
	var d = ((p - pp) * K).rotated(th)
	var R = size.x / 2.0
	var out = d.length() > R - 12.0
	if clamp_edge and out:
		d = d.normalized() * (R - 12.0)
	return [Vector2(R, R) + d, out]

func _pin(p: Vector2, pp: Vector2, th: float, col: Color, clamp_edge := true, r := 7.0) -> void:
	var w = _w2m(p, pp, th, clamp_edge)
	if w[1] and not clamp_edge:
		return
	draw_circle(w[0], r + 2.0, Color(0, 0, 0, 0.6))
	draw_circle(w[0], r, col)

func _draw() -> void:
	if g == null or not g.started:
		return
	var S = size
	var R = S.x / 2.0
	var pp = g.player_pos()
	var th = g.cam_yaw - PI
	draw_rect(Rect2(Vector2.ZERO, S), Color(0.33, 0.42, 0.26))
	var off = Vector2(R, R) - (pp * K).rotated(th)
	draw_set_transform(off, th, Vector2(K, K))
	draw_rect(Rect2(-1500.0, 244.0, 3000.0, 1500.0), Color(0.16, 0.42, 0.56))
	var road = Color(0.22, 0.23, 0.25)
	for t in g.tile_count():
		var c = g.tile_center(t)
		draw_rect(Rect2(c.x - 120.0, c.y - 120.0, 240.0, 240.0), g.dist_col(t))
		for ln in g.road_lines():
			var w = ln[1]
			draw_rect(Rect2(c.x + ln[0] - w / 2.0, c.y - 120.0, w, 240.0), road)
			draw_rect(Rect2(c.x - 120.0, c.y + ln[0] - w / 2.0, 240.0, w), road)
		draw_circle(c, 19.0, road)
		draw_circle(c, 13.0, Color(0.45, 0.62, 0.38))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	_pin(g.GPT, pp, th, Color(0.27, 0.82, 0.42))
	_pin(g.PST, pp, th, Color(0.3, 0.64, 1.0), false, 5.0)
	if g.mk_taxi.visible:
		_pin(g.TAXI, pp, th, Color(0.25, 0.66, 1.0), false)
	if g.mk_main.visible:
		_pin(Vector2(g.mk_main.position.x, g.mk_main.position.z), pp, th, Color(1.0, 0.82, 0.25))
	if g.mgoal != null:
		var blink = Color(1.0, 0.82, 0.25) if int(g.T * 3.0) % 2 == 0 else Color(1.0, 0.6, 0.0)
		_pin(g.mgoal, pp, th, blink)
	for v in g.VEH:
		if v.ai == "police" and not v.wreck:
			var pc = Color(0.25, 0.48, 1.0)
			if g.stars > 0 and int(g.T * 4.0) % 2 == 0:
				pc = Color(1.0, 0.23, 0.23)
			_pin(v.p, pp, th, pc, false, 4.5)
	var h = g.pcar.h if g.pmode == "car" else g.pyaw
	var a = PI - (h - th)
	var c2 = Vector2(R, R)
	var pts = PackedVector2Array([c2 + Vector2(0, -11).rotated(a), c2 + Vector2(8, 8).rotated(a), c2 + Vector2(0, 4).rotated(a), c2 + Vector2(-8, 8).rotated(a)])
	draw_colored_polygon(pts, Color.WHITE)
	var outline = PackedVector2Array(pts)
	outline.append(pts[0])
	draw_polyline(outline, Color.BLACK, 2.0)
	draw_rect(Rect2(Vector2.ZERO, S), Color.WHITE, false, 3.0)
