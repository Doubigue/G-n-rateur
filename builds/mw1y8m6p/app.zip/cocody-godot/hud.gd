extends Control
## Dessin du HUD : étoiles de recherche, joystick, barre d'arrestation, état du véhicule.

var g = null

func _star(c: Vector2, r: float, col: Color) -> void:
	var pts = PackedVector2Array()
	for i in 10:
		var a = -PI / 2.0 + i * PI / 5.0
		var rr = r if i % 2 == 0 else r * 0.45
		pts.append(c + Vector2(cos(a), sin(a)) * rr)
	draw_colored_polygon(pts, col)

func _draw() -> void:
	if g == null or not g.started or g.paused:
		return
	var s = size
	for i in 5:
		var on = i < g.stars
		var col = Color(1.0, 0.82, 0.25) if on else Color(1, 1, 1, 0.25)
		if on and not g.w_seen and int(g.T * 4.0) % 2 == 0:
			col = Color(1, 1, 1, 0.25)
		var c = Vector2(s.x - 228 + i * 30, 72)
		_star(c + Vector2(1.5, 2.0), 13.0, Color(0, 0, 0, 0.5))
		_star(c, 12.0, col)
	var base = Vector2(150, s.y - 150)
	var knob = base
	if g.jp != -1:
		base = g.j0
		knob = g.jcur
	draw_circle(base, 66.0, Color(1, 1, 1, 0.12))
	draw_arc(base, 66.0, 0.0, TAU, 48, Color(1, 1, 1, 0.45), 2.5)
	draw_circle(knob, 26.0, Color(1, 1, 1, 0.8))
	if g.w_bust > 0.05:
		var w = 260.0
		var r = Rect2(s.x / 2.0 - w / 2.0, s.y - 210, w, 12)
		draw_rect(r, Color(0, 0, 0, 0.6))
		draw_rect(Rect2(r.position, Vector2(w * clampf(g.w_bust / 2.2, 0.0, 1.0), 12)), Color(0.9, 0.22, 0.2))
		draw_string(get_theme_default_font(), Vector2(s.x / 2.0 - 80, s.y - 222), "ARRESTATION…", HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color(1, 0.45, 0.45))
	if g.pmode == "car" and g.pcar != null:
		var w2 = 170.0
		var r2 = Rect2(s.x / 2.0 - w2 / 2.0, s.y - 30, w2, 9)
		draw_rect(r2, Color(0, 0, 0, 0.6))
		var hp = g.pcar.hp / 100.0
		var hc = Color(0.36, 0.89, 0.49)
		if hp <= 0.25:
			hc = Color(1, 0.35, 0.31)
		elif hp <= 0.5:
			hc = Color(1, 0.76, 0.25)
		draw_rect(Rect2(r2.position, Vector2(w2 * hp, 9)), hc)
