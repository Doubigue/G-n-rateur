extends Node3D
## Cité Libre — Cocody (Abidjan). Godot 4.3, rendu Mobile.
## Décor, véhicules et personnages : modèles GLB du dossier res://assets.

const MapScript = preload("res://minimap.gd")
const HudScript = preload("res://hud.gd")
const ColData = preload("res://collision_data.gd")

# ---------------- Monde ----------------
## Quartiers posés en grille 3 x 2 (240 m chacun). Nord = -Z, la lagune Ébrié est au sud.
const TILES := [
	{"f": "Deux_Plateaux", "n": "Deux Plateaux", "x": -240.0, "z": -120.0, "dens": 1.2},
	{"f": "Angre", "n": "Angré", "x": 0.0, "z": -120.0, "dens": 1.4},
	{"f": "Riviera", "n": "Riviera", "x": 240.0, "z": -120.0, "dens": 1.3},
	{"f": "Saint_Jean", "n": "Saint-Jean", "x": -240.0, "z": 120.0, "dens": 1.6},
	{"f": "Cocody_Centre", "n": "Cocody Centre", "x": 0.0, "z": 120.0, "dens": 2.0},
	{"f": "M_Badon", "n": "M'Badon", "x": 240.0, "z": 120.0, "dens": 1.0},
]
const TCOL := [Color(0.62, 0.72, 0.52), Color(0.66, 0.74, 0.55), Color(0.6, 0.71, 0.5), Color(0.7, 0.72, 0.55), Color(0.72, 0.75, 0.58), Color(0.63, 0.73, 0.53)]
## Rues de chaque quartier (position locale, largeur).
const LINES := [[-80.0, 9.0], [-40.0, 5.0], [0.0, 12.0], [40.0, 5.0], [80.0, 9.0]]
## Grandes rues utilisées par le trafic (coordonnées globales).
const XL := [-320.0, -240.0, -160.0, -80.0, 0.0, 80.0, 160.0, 240.0, 320.0]
const ZL := [-200.0, -120.0, -40.0, 40.0, 120.0, 200.0]
const RB_R := 16.5
const GW := 720
const GH := 480
const GX0 := -360.0
const GZ0 := -240.0

# ---------------- Véhicules ----------------
const VFILE := {"sedan": "berline_realiste", "taxi": "berline_realiste", "police": "berline_realiste", "pickup": "pickup_realiste", "van": "fourgon_realiste", "moto": "moto_sportive", "scooter": "scooter"}
const STATS := {"sedan": [32.0, 13.0], "taxi": [30.0, 13.0], "police": [40.0, 17.0], "pickup": [30.0, 12.0], "van": [24.0, 9.0], "moto": [44.0, 22.0], "scooter": [22.0, 14.0]}
const CARCOL := {
	"sedan": [0x2367b4, 0xd9d9d9, 0x1e1f24, 0x8a1c1c, 0x6d7a83, 0xe8e2d0, 0x2e6b3f],
	"taxi": [0xe8641b], "police": [0xf2f2f2], "pickup": [0xbf5c1f, 0xffffff, 0x3d4a5c, 0x7a1f1f],
	"van": [0xf2c200, 0x1f8a4c, 0xffffff, 0x2e86c1], "moto": [0xbf1a24, 0x111111, 0x1e5fbf], "scooter": [0x2459a1, 0xe0e0e0, 0xd35400],
}
const PEDFILES := ["PNJ_Chauffeur", "PNJ_Commercant", "PNJ_Habitant_01", "PNJ_Habitante_02", "PNJ_Pieton_03", "PNJ_Pietonne_04"]
const QL := [
	{"n": "Bas", "scale": 0.7, "shadow": false, "peds": 6, "cars": 7, "fog": 0.006},
	{"n": "Moyen", "scale": 0.85, "shadow": true, "peds": 10, "cars": 11, "fog": 0.0045},
	{"n": "Haut", "scale": 1.0, "shadow": true, "peds": 16, "cars": 15, "fog": 0.0035},
]

class Hum:
	var root = null
	var body = null
	var hipL = null
	var hipR = null
	var kneeL = null
	var kneeR = null
	var shL = null
	var shR = null
	var elL = null
	var elR = null
	var ph := 0.0

class Veh:
	var root = null
	var body = null
	var mesh_inst = null
	var lb := []
	var paint = null
	var smoke = null
	var kind := "sedan"
	var two := false
	var rad := 2.1
	var base := Color.WHITE
	var p := Vector2.ZERO
	var y := 0.0
	var h := 0.0
	var spd := 0.0
	var hp := 100.0
	var steer := 0.0
	var ai := ""
	var driver := false
	var wreck := false
	var stop_t := 0.0
	var pitch := 0.0
	var roll := 0.0
	var acc := 0.0
	var cruise := 11.0
	var node := Vector2i.ZERO
	var dir := Vector2i(1, 0)
	var routed := false
	var wps := []
	var tilt := 0.0
	var stuck := 0.0
	var rev := 0.0
	var seek := false
	var see := false
	var ign := 0.0
	var mine := false
	var vmax := 30.0
	var vacc := 13.0

class Ped:
	var hum = null
	var p := Vector2.ZERO
	var y := 0.12
	var s := 0.0
	var dir := 1.0
	var spd := 1.4
	var st := "walk"
	var t := 0.0
	var r := Rect2()
	var tile := 0
	var free := false
	var f := Vector2.ZERO
	var yaw := 0.0
	var on := true

# ---------------- État ----------------
var grid := PackedByteArray()
var VEH := []
var PEDS := []
var VMODEL := {}
var HMODEL := {}
var BLOCKS := []
var cam: Camera3D
var sun: DirectionalLight3D
var env: Environment
var sav := {"money": 0, "mi": 0, "car": null, "q": 1}
var Q: Dictionary = {}
var pop := 1.0
var paused := true
var started := false
var T := 0.0
var fps_t := 0.0
var M_vcol: StandardMaterial3D
var M_smoke: StandardMaterial3D
var MS := {}
# joueur
var P_h = null
var pp := Vector2.ZERO
var py := 0.12
var pvy := 0.0
var pyaw := PI
var pmode := "foot"
var pcar = null
var prun := false
var pstun := 0.0
var pbusted := 0.0
var pspd := 0.0
# recherche
var stars := 0
var w_lost := 0.0
var w_seen := false
var w_bust := 0.0
var w_cool := 0.0
var w_los := 0.0
var w_spawn := 0.0
var hit_cool := 0.0
# missions
var MIS := []
var mact = null
var mstep := 0
var mt := 0.0
var mcp := 0
var mcool := 0.0
var mgoal = null
var in_gar := false
var comet = null
var TAXI := Vector2(247.0, -150.0)
var GPT := Vector2(40.0, 150.0)
var PST := Vector2(-233.0, 148.0)
var SPAWN := Vector2(7.0, 160.0)
var cur_dist := -1
# caméra
var cam_yaw := PI
var cam_pitch := 0.3
var drag_t := 9.0
var shake := 0.0
var cam_pos := Vector3(0, 10, 0)
var cam_fov := 62.0
# entrées
var JX := 0.0
var JY := 0.0
var jp := -1
var j0 := Vector2.ZERO
var jcur := Vector2.ZERO
var cpid := -1
var in_x := 0.0
var in_y := 0.0
var hb_btn := false
var jump_req := false
var btn_rects := []
# objets
var mk_main = null
var mk_goal = null
var mk_taxi = null
var mk_gar = null
var cashes := []
# interface
var hud = null
var minimap = null
var ui := {}
var toast_t := 0.0
var big_t := 0.0
var dist_t := 0.0

# ================= Outils =================
func hexc(hv: int) -> Color:
	return Color(((hv >> 16) & 255) / 255.0, ((hv >> 8) & 255) / 255.0, (hv & 255) / 255.0)

func angd(a: float, b: float) -> float:
	return wrapf(b - a, -PI, PI)

func pick(arr: Array):
	return arr[randi() % arr.size()]

func mat(c: Color, metal := 0.0, rough := 0.8) -> StandardMaterial3D:
	var m = StandardMaterial3D.new()
	m.albedo_color = c
	m.metallic = metal
	m.roughness = rough
	return m

func emat(c: Color, energy := 2.0) -> StandardMaterial3D:
	var m = StandardMaterial3D.new()
	m.albedo_color = c
	m.emission_enabled = true
	m.emission = c
	m.emission_energy_multiplier = energy
	return m

func mi(mesh: Mesh, m: Material, parent: Node3D, pos := Vector3.ZERO, shadow := true) -> MeshInstance3D:
	var o = MeshInstance3D.new()
	o.mesh = mesh
	if m != null:
		o.material_override = m
	o.position = pos
	if not shadow:
		o.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(o)
	return o

func box_mesh(size: Vector3) -> BoxMesh:
	var b = BoxMesh.new()
	b.size = size
	return b

## Index du quartier (0..5) contenant le point.
func tile_of(p: Vector2) -> int:
	var tx = clampi(int(floor((p.x + 360.0) / 240.0)), 0, 2)
	var tz = clampi(int(floor((p.y + 240.0) / 240.0)), 0, 1)
	return tz * 3 + tx

func tile_center(t: int) -> Vector2:
	return Vector2(TILES[t]["x"], TILES[t]["z"])

func gy(p: Vector2) -> float:
	var l = p - tile_center(tile_of(p))
	var r = l.length()
	if r < 13.0:
		return 0.23
	if r < 19.5:
		return 0.0
	for ln in LINES:
		if absf(l.x - ln[0]) < ln[1] / 2.0 or absf(l.y - ln[0]) < ln[1] / 2.0:
			return 0.0
	return 0.12

## Demi-largeur de voie selon la rue (12 m -> 3 m, 9 m -> 2.25 m).
func lane_x(xv: float) -> float:
	var local = xv - round(xv / 240.0) * 240.0
	return 3.0 if absf(local) < 1.0 else 2.25

func lane_z(zv: float) -> float:
	var local = zv - (round((zv - 120.0) / 240.0) * 240.0 + 120.0)
	return 3.0 if absf(local) < 1.0 else 2.25

func is_rb(i: int, j: int) -> bool:
	var lx = XL[i] - round(XL[i] / 240.0) * 240.0
	var lz = ZL[j] - (round((ZL[j] - 120.0) / 240.0) * 240.0 + 120.0)
	return absf(lx) < 1.0 and absf(lz) < 1.0

func dist_col(i: int) -> Color:
	return TCOL[i]

func tile_count() -> int:
	return TILES.size()

func road_lines() -> Array:
	return LINES

# ================= Démarrage =================
func _ready() -> void:
	randomize()
	load_save()
	Q = QL[clampi(int(sav["q"]), 0, 2)]
	setup_env()
	build_materials()
	build_grid()
	build_world()
	build_blocks()
	build_player()
	build_objects()
	build_missions()
	build_hud()
	spawn_parked()
	apply_quality()
	hud_mode()
	update_money()
	cam_pos = Vector3(pp.x, 8, pp.y + 8)
	get_viewport().size_changed.connect(layout)
	layout()

func load_save() -> void:
	if FileAccess.file_exists("user://save_cocody.json"):
		var f = FileAccess.open("user://save_cocody.json", FileAccess.READ)
		if f != null:
			var d = JSON.parse_string(f.get_as_text())
			if typeof(d) == TYPE_DICTIONARY:
				for k in d:
					sav[k] = d[k]
	sav["money"] = int(sav.get("money", 0))
	sav["mi"] = int(sav.get("mi", 0))
	sav["q"] = int(sav.get("q", 1))

func store() -> void:
	var f = FileAccess.open("user://save_cocody.json", FileAccess.WRITE)
	if f != null:
		f.store_string(JSON.stringify(sav))

func setup_env() -> void:
	env = Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky = Sky.new()
	var sm = ProceduralSkyMaterial.new()
	sm.sky_top_color = Color(0.3, 0.53, 0.85)
	sm.sky_horizon_color = Color(0.8, 0.86, 0.92)
	sm.ground_horizon_color = Color(0.72, 0.76, 0.78)
	sm.ground_bottom_color = Color(0.3, 0.32, 0.3)
	sky.sky_material = sm
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.9
	env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.tonemap_white = 6.0
	env.glow_enabled = true
	env.glow_intensity = 0.5
	env.fog_enabled = true
	env.fog_light_color = Color(0.8, 0.85, 0.9)
	env.fog_density = 0.0045
	env.fog_sky_affect = 0.2
	var we = WorldEnvironment.new()
	we.environment = env
	add_child(we)
	sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-52, -30, 0)
	sun.light_color = Color(1.0, 0.95, 0.86)
	sun.light_energy = 1.3
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 70.0
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
	add_child(sun)
	cam = Camera3D.new()
	cam.fov = 62.0
	cam.near = 0.25
	cam.far = 600.0
	add_child(cam)
	cam.make_current()

func build_materials() -> void:
	M_vcol = StandardMaterial3D.new()
	M_vcol.vertex_color_use_as_albedo = true
	M_vcol.roughness = 0.8
	var img = Image.create(64, 64, false, Image.FORMAT_RGBA8)
	for yy in 64:
		for xx in 64:
			var d = Vector2(xx - 31.5, yy - 31.5).length() / 31.5
			img.set_pixel(xx, yy, Color(1, 1, 1, clampf(1.0 - d, 0.0, 1.0)))
	M_smoke = StandardMaterial3D.new()
	M_smoke.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	M_smoke.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	M_smoke.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	M_smoke.vertex_color_use_as_albedo = true
	M_smoke.albedo_texture = ImageTexture.create_from_image(img)
	var q = QuadMesh.new()
	q.size = Vector2(1, 1)
	MS["smoke"] = q
	MS["lbar"] = box_mesh(Vector3(0.42, 0.14, 0.3))
	MS["sign"] = box_mesh(Vector3(0.8, 0.26, 0.3))

# ================= Grille de collision =================
func build_grid() -> void:
	grid.resize(GW * GH)
	grid.fill(0)
	for t in TILES.size():
		var ox = int(TILES[t]["x"] - 120.0 - GX0)
		var oz = int(TILES[t]["z"] - 120.0 - GZ0)
		var data = ColData.DATA.get(TILES[t]["f"], "")
		var k = 0
		for tok in data.split(" ", false):
			var parts = tok.split("x")
			var v = int(parts[0])
			var c = int(parts[1])
			if v > 0:
				for q in c:
					var idx = k + q
					var ix = idx % 240
					var iz = idx / 240
					grid[(oz + iz) * GW + ox + ix] = v
			k += c

func cell(ix: int, iz: int) -> int:
	if ix < 0 or iz < 0 or ix >= GW or iz >= GH:
		return 0
	return grid[iz * GW + ix]

var po_n := Vector2.ZERO
var po_hit := false

func push_out(p: Vector2, r: float) -> Vector2:
	var n = Vector2.ZERO
	var hit = false
	var x0 = int(floor(p.x - r - GX0))
	var x1 = int(floor(p.x + r - GX0))
	var z0 = int(floor(p.y - r - GZ0))
	var z1 = int(floor(p.y + r - GZ0))
	for iz in range(z0, z1 + 1):
		for ix in range(x0, x1 + 1):
			if cell(ix, iz) == 0:
				continue
			var bx0 = GX0 + ix
			var bz0 = GZ0 + iz
			var bx1 = bx0 + 1.0
			var bz1 = bz0 + 1.0
			if p.x + r <= bx0 or p.x - r >= bx1 or p.y + r <= bz0 or p.y - r >= bz1:
				continue
			var cx = clampf(p.x, bx0, bx1)
			var cz = clampf(p.y, bz0, bz1)
			var dv = Vector2(p.x - cx, p.y - cz)
			var l = dv.length()
			if l > 0.00001:
				if l >= r:
					continue
				dv = dv / l
				p = Vector2(cx, cz) + dv * r
			else:
				var a = [p.x - bx0, bx1 - p.x, p.y - bz0, bz1 - p.y]
				var m = min(min(a[0], a[1]), min(a[2], a[3]))
				if m == a[0]:
					dv = Vector2(-1, 0)
					p.x = bx0 - r
				elif m == a[1]:
					dv = Vector2(1, 0)
					p.x = bx1 + r
				elif m == a[2]:
					dv = Vector2(0, -1)
					p.y = bz0 - r
				else:
					dv = Vector2(0, 1)
					p.y = bz1 + r
			n += dv
			hit = true
	var lo_x = GX0 + 2.0 + r
	var hi_x = -GX0 - 2.0 - r
	var lo_z = GZ0 + 2.0 + r
	var hi_z = -GZ0 - 2.0 - r
	if p.x < lo_x:
		p.x = lo_x
		n.x += 1
		hit = true
	if p.x > hi_x:
		p.x = hi_x
		n.x -= 1
		hit = true
	if p.y < lo_z:
		p.y = lo_z
		n.y += 1
		hit = true
	if p.y > hi_z:
		p.y = hi_z
		n.y -= 1
		hit = true
	po_hit = hit
	po_n = n.normalized() if hit else Vector2.ZERO
	return p

func solid_at(x: float, y: float, z: float) -> bool:
	var h = cell(int(floor(x - GX0)), int(floor(z - GZ0)))
	return h > 0 and y < h + 0.3

func los(a: Vector2, b: Vector2) -> bool:
	var d = b - a
	var n = int(d.length())
	if n < 1:
		return true
	var st = d / n
	var q = a
	for k in n:
		q += st
		if cell(int(floor(q.x - GX0)), int(floor(q.y - GZ0))) > 3:
			return false
	return true

# ================= Monde =================
func build_world() -> void:
	var land = PlaneMesh.new()
	land.size = Vector2(3000, 3000)
	mi(land, mat(Color(0.33, 0.42, 0.26), 0.0, 0.95), self, Vector3(0, -0.35, 0), false)
	var water = PlaneMesh.new()
	water.size = Vector2(3000, 1400)
	mi(water, mat(Color(0.1, 0.36, 0.48), 0.4, 0.1), self, Vector3(0, -0.25, 244.0 + 700.0), false)
	for t in TILES:
		var path = "res://assets/quartiers/" + t["f"] + ".glb"
		if ResourceLoader.exists(path):
			var ps = load(path)
			if ps is PackedScene:
				var inst = ps.instantiate()
				add_child(inst)
				inst.position = Vector3(t["x"], 0, t["z"])

## Boucles de trottoir (entre grandes rues) pour les piétons.
func build_blocks() -> void:
	for i in XL.size() - 1:
		for j in ZL.size() - 1:
			var x0 = XL[i] + lane_x(XL[i]) * 2.0 + 1.0
			var x1 = XL[i + 1] - lane_x(XL[i + 1]) * 2.0 - 1.0
			var z0 = ZL[j] + lane_z(ZL[j]) * 2.0 + 1.0
			var z1 = ZL[j + 1] - lane_z(ZL[j + 1]) * 2.0 - 1.0
			BLOCKS.append(Rect2(x0, z0, x1 - x0, z1 - z0))

# ================= Modèles GLB =================
## Parcourt une scène importée et regroupe ses maillages.
## mode "aabb" : mesure les pièces ; mode "build" : ajoute les sommets aux groupes.
func _walk(n: Node, xf: Transform3D, bake: Transform3D, key_fn: Callable, mode: String, out: Dictionary) -> void:
	var t = xf
	if n is Node3D:
		t = xf * n.transform
	if n is MeshInstance3D and n.mesh != null:
		var m = n.mesh
		var full = bake * t
		var nm = str(n.name)
		for s in m.get_surface_count():
			var arr = m.surface_get_arrays(s)
			var verts = arr[Mesh.ARRAY_VERTEX]
			if verts == null or verts.size() == 0:
				continue
			if mode == "aabb":
				var bb = AABB(full * verts[0], Vector3.ZERO)
				for v in verts:
					bb = bb.expand(full * v)
				if out.has(nm):
					out[nm] = out[nm].merge(bb)
				else:
					out[nm] = bb
				continue
			var mt_ = n.get_active_material(s)
			var info = key_fn.call(nm, mt_)
			var key = info[0]
			var off = info[1]
			if not out.has(key):
				out[key] = {"v": PackedVector3Array(), "n": PackedVector3Array(), "c": PackedColorArray(), "i": PackedInt32Array(), "mat": mt_, "col": false}
			var b = out[key]
			var VV: PackedVector3Array = b["v"]
			var NN: PackedVector3Array = b["n"]
			var CC: PackedColorArray = b["c"]
			var II: PackedInt32Array = b["i"]
			var base = VV.size()
			var norms = arr[Mesh.ARRAY_NORMAL]
			var cols = arr[Mesh.ARRAY_COLOR]
			var idx = arr[Mesh.ARRAY_INDEX]
			var has_n = norms != null and norms.size() == verts.size()
			var has_c = cols != null and cols.size() == verts.size()
			if has_c:
				b["col"] = true
			for k in verts.size():
				VV.append(full * verts[k] - off)
				if has_n:
					NN.append((full.basis * norms[k]).normalized())
				else:
					NN.append(Vector3.UP)
				CC.append(cols[k] if has_c else Color.WHITE)
			if idx != null and idx.size() > 0:
				for k in idx.size():
					II.append(idx[k] + base)
			else:
				for k in verts.size():
					II.append(base + k)
			b["v"] = VV
			b["n"] = NN
			b["c"] = CC
			b["i"] = II
	for c in n.get_children():
		_walk(c, t, bake, key_fn, mode, out)

func _to_mesh(b: Dictionary) -> ArrayMesh:
	var a = []
	a.resize(Mesh.ARRAY_MAX)
	a[Mesh.ARRAY_VERTEX] = b["v"]
	a[Mesh.ARRAY_NORMAL] = b["n"]
	if b["col"]:
		a[Mesh.ARRAY_COLOR] = b["c"]
	a[Mesh.ARRAY_INDEX] = b["i"]
	var am = ArrayMesh.new()
	am.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, a)
	return am

## Véhicule : un seul maillage, une surface par matériau. Avant tourné vers +Z.
func veh_model(kind: String):
	var file = VFILE[kind]
	if VMODEL.has(file):
		return VMODEL[file]
	var path = "res://assets/vehicules/" + file + ".glb"
	var res = null
	if ResourceLoader.exists(path):
		var ps = load(path)
		if ps is PackedScene:
			var inst = ps.instantiate()
			var bake = Transform3D(Basis(Vector3(-1, 0, 0), Vector3(0, 1, 0), Vector3(0, 0, -1)), Vector3.ZERO)
			var groups = {}
			var kf = func(_nm: String, m): return [str(m.get_instance_id()) if m != null else "none", Vector3.ZERO]
			_walk(inst, Transform3D.IDENTITY, bake, kf, "build", groups)
			var am = ArrayMesh.new()
			var paint_idx = -1
			for key in groups:
				var b = groups[key]
				var a = []
				a.resize(Mesh.ARRAY_MAX)
				a[Mesh.ARRAY_VERTEX] = b["v"]
				a[Mesh.ARRAY_NORMAL] = b["n"]
				a[Mesh.ARRAY_INDEX] = b["i"]
				am.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, a)
				var si = am.get_surface_count() - 1
				if b["mat"] != null:
					am.surface_set_material(si, b["mat"])
					if str(b["mat"].resource_name).to_lower().contains("paint"):
						paint_idx = si
			res = {"mesh": am, "paint": paint_idx, "aabb": am.get_aabb()}
			inst.free()
	VMODEL[file] = res
	return res

## Personnage : corps + membres articulés (hanches, genoux, épaules, coudes).
const LEG_UP := ["thigh", "knee"]
const LEG_LO := ["shin", "shoe"]
const ARM_UP := ["upperarm", "elbow"]
const ARM_LO := ["forearm", "hand"]

func _part_group(nm: String) -> String:
	for side in ["L", "R"]:
		for p in LEG_UP:
			if nm == side + "_" + p:
				return side + "legup"
		for p in LEG_LO:
			if nm == side + "_" + p:
				return side + "leglo"
		for p in ARM_UP:
			if nm == side + "_" + p:
				return side + "armup"
		for p in ARM_LO:
			if nm == side + "_" + p:
				return side + "armlo"
	return "body"

func hum_model(file: String):
	if HMODEL.has(file):
		return HMODEL[file]
	var path = "res://assets/personnages/" + file + ".glb"
	var res = null
	if ResourceLoader.exists(path):
		var ps = load(path)
		if ps is PackedScene:
			var inst = ps.instantiate()
			var s = 0.88
			var bake = Transform3D(Basis(Vector3(s, 0, 0), Vector3(0, 0, -s), Vector3(0, s, 0)), Vector3.ZERO)
			var bbs = {}
			_walk(inst, Transform3D.IDENTITY, bake, Callable(), "aabb", bbs)
			var piv = {}
			for side in ["L", "R"]:
				piv[side + "legup"] = _top_center(bbs, side + "_thigh", Vector3(0.12 if side == "R" else -0.12, 0.8, 0))
				piv[side + "leglo"] = _top_center(bbs, side + "_shin", Vector3(0.12 if side == "R" else -0.12, 0.46, 0))
				piv[side + "armup"] = _top_center(bbs, side + "_upperarm", Vector3(0.3 if side == "R" else -0.3, 1.32, 0))
				piv[side + "armlo"] = _top_center(bbs, side + "_forearm", Vector3(0.33 if side == "R" else -0.33, 1.05, 0))
			piv["body"] = Vector3.ZERO
			var kf = func(nm: String, _m):
				var g = _part_group(nm)
				return [g, piv[g]]
			var groups = {}
			_walk(inst, Transform3D.IDENTITY, bake, kf, "build", groups)
			var meshes = {}
			for key in groups:
				meshes[key] = _to_mesh(groups[key])
			res = {"meshes": meshes, "piv": piv}
			inst.free()
	HMODEL[file] = res
	return res

func _top_center(bbs: Dictionary, nm: String, dflt: Vector3) -> Vector3:
	if not bbs.has(nm):
		return dflt
	var bb = bbs[nm]
	var c = bb.get_center()
	return Vector3(c.x, bb.position.y + bb.size.y, c.z)

func add_human(file: String) -> Hum:
	var h = Hum.new()
	var r = Node3D.new()
	add_child(r)
	h.root = r
	var md = hum_model(file)
	if md == null:
		var cap = CapsuleMesh.new()
		cap.radius = 0.25
		cap.height = 1.7
		h.body = mi(cap, mat(Color(0.8, 0.5, 0.3)), r, Vector3(0, 0.85, 0))
		for k in ["hipL", "hipR", "kneeL", "kneeR", "shL", "shR", "elL", "elR"]:
			var nd = Node3D.new()
			r.add_child(nd)
			h.set(k, nd)
		return h
	var ms = md["meshes"]
	var pv = md["piv"]
	if ms.has("body"):
		h.body = mi(ms["body"], M_vcol, r)
		h.body.visibility_range_end = 95.0
	for side in ["L", "R"]:
		var up = Node3D.new()
		up.position = pv[side + "legup"]
		r.add_child(up)
		if ms.has(side + "legup"):
			mi(ms[side + "legup"], M_vcol, up).visibility_range_end = 95.0
		var lo = Node3D.new()
		lo.position = pv[side + "leglo"] - pv[side + "legup"]
		up.add_child(lo)
		if ms.has(side + "leglo"):
			mi(ms[side + "leglo"], M_vcol, lo).visibility_range_end = 95.0
		var au = Node3D.new()
		au.position = pv[side + "armup"]
		r.add_child(au)
		if ms.has(side + "armup"):
			mi(ms[side + "armup"], M_vcol, au).visibility_range_end = 95.0
		var al = Node3D.new()
		al.position = pv[side + "armlo"] - pv[side + "armup"]
		au.add_child(al)
		if ms.has(side + "armlo"):
			mi(ms[side + "armlo"], M_vcol, al).visibility_range_end = 95.0
		if side == "L":
			h.hipL = up
			h.kneeL = lo
			h.shL = au
			h.elL = al
		else:
			h.hipR = up
			h.kneeR = lo
			h.shR = au
			h.elR = al
	return h

func anim_h(h: Hum, sp: float, dt: float, flee: bool) -> void:
	h.ph += dt * maxf(sp, 0.001) * 2.2
	var a = sin(h.ph) * minf(0.7, sp * 0.15)
	h.hipL.rotation.x = a
	h.hipR.rotation.x = -a
	h.kneeL.rotation.x = maxf(0.0, -sin(h.ph - 0.6)) * minf(0.9, sp * 0.2)
	h.kneeR.rotation.x = maxf(0.0, sin(h.ph - 0.6)) * minf(0.9, sp * 0.2)
	if flee:
		h.shL.rotation.x = -2.6 + sin(h.ph * 2.0) * 0.3
		h.shR.rotation.x = -2.6 - sin(h.ph * 2.0) * 0.3
		h.elL.rotation.x = -0.3
		h.elR.rotation.x = -0.3
	else:
		h.shL.rotation.x = -a * 0.8
		h.shR.rotation.x = a * 0.8
		h.elL.rotation.x = -0.15 - maxf(0.0, a) * 0.4
		h.elR.rotation.x = -0.15 - maxf(0.0, -a) * 0.4

func pose_seated(h: Hum) -> void:
	h.hipL.rotation.x = -1.35
	h.hipR.rotation.x = -1.35
	h.kneeL.rotation.x = 1.45
	h.kneeR.rotation.x = 1.45
	h.shL.rotation.x = -0.95
	h.shR.rotation.x = -0.95
	h.elL.rotation.x = -0.45
	h.elR.rotation.x = -0.45

func build_player() -> void:
	P_h = add_human("Personnage_Principal")
	pp = SPAWN
	py = 0.12
	pyaw = PI

# ================= Véhicules =================
func add_veh(kind: String, cv: int, p: Vector2, h: float, ai: String) -> Veh:
	var v = Veh.new()
	v.kind = kind
	v.two = kind == "moto" or kind == "scooter"
	v.rad = 1.0 if v.two else 2.1
	v.base = hexc(cv)
	v.p = p
	v.h = h
	v.ai = ai
	v.driver = ai == "traffic" or ai == "police"
	v.vmax = STATS[kind][0]
	v.vacc = STATS[kind][1]
	var root = Node3D.new()
	add_child(root)
	v.root = root
	var body = Node3D.new()
	root.add_child(body)
	v.body = body
	var pm = StandardMaterial3D.new()
	pm.albedo_color = v.base
	pm.metallic = 0.5
	pm.roughness = 0.28
	pm.clearcoat_enabled = true
	pm.clearcoat = 1.0
	pm.clearcoat_roughness = 0.08
	v.paint = pm
	var md = veh_model(kind)
	var top = 1.5
	if md != null:
		var o = mi(md["mesh"], null, body)
		o.visibility_range_end = 160.0
		v.mesh_inst = o
		if md["paint"] >= 0:
			o.set_surface_override_material(md["paint"], pm)
		top = md["aabb"].position.y + md["aabb"].size.y
	else:
		var bm = box_mesh(Vector3(1.9, 1.1, 4.4))
		mi(bm, pm, body, Vector3(0, 0.75, 0))
	if kind == "police":
		for sx in [-1.0, 1.0]:
			var lm = emat(Color(1, 0.1, 0.1) if sx < 0.0 else Color(0.1, 0.3, 1.0), 3.0)
			v.lb.append(mi(MS["lbar"], lm, body, Vector3(sx * 0.25, top + 0.08, -0.18), false))
	elif kind == "taxi":
		mi(MS["sign"], emat(Color(1.0, 0.85, 0.3), 1.2), body, Vector3(0, top + 0.13, -0.18), false)
	VEH.append(v)
	vis_veh(v, 0.0)
	return v

func del_veh(v: Veh) -> void:
	if is_instance_valid(v.root):
		v.root.queue_free()
	VEH.erase(v)

func paint_veh(v: Veh) -> void:
	var f = 0.18 if v.wreck else 1.0 - (1.0 - v.hp / 100.0) * 0.5
	v.paint.albedo_color = Color(v.base.r * f, v.base.g * f, v.base.b * f)
	v.paint.roughness = 0.28 + (1.0 - f) * 0.6
	if v.hp < 45.0 and v.smoke == null:
		var p = CPUParticles3D.new()
		p.mesh = MS["smoke"]
		p.material_override = M_smoke
		p.amount = 14
		p.lifetime = 1.4
		p.direction = Vector3(0, 1, 0)
		p.spread = 18.0
		p.initial_velocity_min = 1.0
		p.initial_velocity_max = 2.2
		p.gravity = Vector3(0, 0.4, 0)
		p.scale_amount_min = 0.8
		p.scale_amount_max = 2.0
		var gr = Gradient.new()
		gr.set_color(0, Color(0.45, 0.45, 0.45, 0.55))
		gr.set_color(1, Color(0.3, 0.3, 0.3, 0.0))
		p.color_ramp = gr
		p.position = Vector3(0, 1.0, 1.0 if v.two else 1.6)
		v.root.add_child(p)
		v.smoke = p
	if v.smoke != null:
		v.smoke.emitting = v.hp < 45.0
		if v.hp < 20.0:
			v.smoke.color_ramp.set_color(0, Color(0.12, 0.12, 0.12, 0.7))

func dmg(v: Veh, a: float) -> void:
	if v.wreck or a <= 0.0:
		return
	v.hp = maxf(0.0, v.hp - a)
	v.tilt = clampf(v.tilt + (randf() - 0.5) * a * 0.002, -0.08, 0.08)
	if v.hp <= 0.0:
		v.wreck = true
		v.spd *= 0.3
		if v == pcar:
			exit_car()
			toast("Véhicule détruit !")
	paint_veh(v)

func vis_veh(v: Veh, dt: float) -> void:
	v.y = lerpf(v.y, gy(v.p), 0.3)
	v.root.position = Vector3(v.p.x, v.y, v.p.y)
	v.root.rotation.y = v.h
	var k = clampf(dt * 6.0, 0.0, 1.0)
	v.pitch = lerpf(v.pitch, clampf(-v.acc * 0.008, -0.06, 0.06), k)
	var lean = v.steer * v.spd * (0.012 if v.two else -0.0028)
	v.roll = lerpf(v.roll, clampf(lean, -0.45 if v.two else -0.06, 0.45 if v.two else 0.06), clampf(dt * 5.0, 0.0, 1.0))
	v.body.rotation = Vector3(v.pitch, 0, v.roll + v.tilt)

# ================= IA de circulation =================
func node_xz(i: int, j: int) -> Vector2:
	return Vector2(XL[i], ZL[j])

func valid_dir(i: int, j: int, dv: Vector2i) -> bool:
	return i + dv.x >= 0 and i + dv.x < XL.size() and j + dv.y >= 0 and j + dv.y < ZL.size()

## Décalage vers la voie de droite pour une direction donnée au nœud (i, j).
func lane_off(dv: Vector2i, i: int, j: int) -> Vector2:
	var mag = lane_z(ZL[j]) if dv.x != 0 else lane_x(XL[i])
	return Vector2(-dv.y, dv.x) * mag

func next_dir(v: Veh, toward) -> Vector2i:
	var i = v.node.x
	var j = v.node.y
	var opts = []
	for dv in DIRS4():
		if dv == -v.dir:
			continue
		if valid_dir(i, j, dv):
			opts.append(dv)
	if opts.is_empty():
		return -v.dir
	if toward != null:
		var best = opts[0]
		var bd = 1e9
		for dv in opts:
			var q = node_xz(i + dv.x, j + dv.y).distance_to(toward) + randf() * 25.0
			if q < bd:
				bd = q
				best = dv
		return best
	if opts.has(v.dir) and randf() < 0.5:
		return v.dir
	return pick(opts)

func DIRS4() -> Array:
	return [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]

## Prépare les points de passage pour franchir le prochain carrefour (ou rond-point).
func plan_next(v: Veh, toward) -> void:
	var i = v.node.x
	var j = v.node.y
	var c = node_xz(i, j)
	var nd = next_dir(v, toward)
	var d_in = Vector2(v.dir.x, v.dir.y)
	var d_out = Vector2(nd.x, nd.y)
	var o_in = lane_off(v.dir, i, j)
	var o_out = lane_off(nd, i, j)
	v.wps = []
	if is_rb(i, j):
		var e_in = -d_in * RB_R + o_in
		var e_out = d_out * RB_R + o_out
		v.wps.append(c - d_in * (RB_R + 6.0) + o_in)
		v.wps.append(c + e_in)
		var a_in = atan2(e_in.y, e_in.x)
		var a_out = atan2(e_out.y, e_out.x)
		while a_out >= a_in:
			a_out -= TAU
		var a = a_in - 0.45
		while a > a_out:
			v.wps.append(c + Vector2(cos(a), sin(a)) * RB_R)
			a -= 0.45
		v.wps.append(c + e_out)
		v.wps.append(c + d_out * (RB_R + 6.0) + o_out)
	else:
		v.wps.append(c - d_in * 3.0 + o_in)
		v.wps.append(c + d_out * 9.0 + o_out)
	v.node = v.node + nd
	v.dir = nd

func road_follow(v: Veh, dt: float, want: float, toward) -> void:
	if v.wps.is_empty():
		plan_next(v, toward)
	var t = v.wps[0]
	if v.p.distance_to(t) < 3.5:
		v.wps.pop_front()
		if v.wps.is_empty():
			plan_next(v, toward)
		t = v.wps[0]
	var c = node_xz(clampi(v.node.x - v.dir.x, 0, XL.size() - 1), clampi(v.node.y - v.dir.y, 0, ZL.size() - 1))
	if is_rb(clampi(v.node.x - v.dir.x, 0, XL.size() - 1), clampi(v.node.y - v.dir.y, 0, ZL.size() - 1)) and v.p.distance_to(c) < RB_R + 8.0:
		want = minf(want, 8.0)
	steer_to(v, t, dt, want)

func steer_to(v: Veh, t: Vector2, dt: float, want: float) -> void:
	var des = atan2(t.x - v.p.x, t.y - v.p.y)
	var df = angd(v.h, des)
	var rate = 2.3 * clampf(absf(v.spd) / 5.0, 0.25, 1.0)
	v.h += clampf(df, -rate * dt, rate * dt)
	v.steer = lerpf(v.steer, clampf(-df * 1.6, -1.0, 1.0), 0.2)
	var w = want * (0.5 if absf(df) > 0.6 else 1.0)
	var o = v.spd
	v.spd = lerpf(v.spd, w, clampf(dt * (2.6 if w < v.spd else 1.1), 0.0, 1.0))
	v.acc = (v.spd - o) / maxf(dt, 0.001)
	mv(v, dt)

func mv(v: Veh, dt: float) -> void:
	v.p += Vector2(sin(v.h), cos(v.h)) * v.spd * dt

func place_on_road(v: Veh, i: int, j: int, dv: Vector2i, along: float) -> void:
	v.p = node_xz(i, j) + lane_off(dv, i, j) + Vector2(dv.x, dv.y) * along
	v.h = atan2(dv.x, dv.y)
	v.node = Vector2i(i, j) + dv
	v.dir = dv
	v.wps = []
	v.routed = true

func spawn_traffic(v, init: bool):
	var ppos = player_pos()
	for k in 60:
		var i = randi() % XL.size()
		var j = randi() % ZL.size()
		var d = node_xz(i, j).distance_to(ppos)
		if init:
			if d > 230.0 or d < 25.0:
				continue
		elif d < 95.0 or d > 210.0:
			continue
		var o = []
		for dv in DIRS4():
			if valid_dir(i, j, dv):
				o.append(dv)
		var dv2 = pick(o)
		if v == null:
			var kind = "sedan"
			var r = randf()
			if r < 0.18:
				kind = "taxi"
			elif r < 0.3:
				kind = "van"
			elif r < 0.42:
				kind = "pickup"
			v = add_veh(kind, pick(CARCOL[kind]), Vector2.ZERO, 0.0, "traffic")
		place_on_road(v, i, j, dv2, 24.0 + randf() * 32.0)
		v.cruise = 10.0 + randf() * 4.0
		v.spd = v.cruise * 0.6
		v.hp = 100.0
		v.wreck = false
		v.stop_t = 0.0
		v.driver = true
		v.ai = "traffic"
		v.tilt = 0.0
		paint_veh(v)
		return v
	return v

func upd_traffic(v: Veh, dt: float) -> void:
	if v.wreck:
		v.spd *= 1.0 - dt * 2.0
		mv(v, dt)
		return
	if v.stop_t > 0.0:
		v.stop_t -= dt
		v.spd = lerpf(v.spd, 0.0, clampf(dt * 3.0, 0.0, 1.0))
		mv(v, dt)
		return
	var cr = v.cruise
	var fw = Vector2(sin(v.h), cos(v.h))
	v.ign -= dt
	if v.ign <= 0.0:
		for o in VEH:
			if o == v or absf(o.p.x - v.p.x) > 13.0 or absf(o.p.y - v.p.y) > 13.0:
				continue
			cr = _obst(v, fw, o.p, cr)
		if pmode == "foot":
			cr = _obst(v, fw, pp, cr)
	if v.spd < 0.5 and cr < 1.0:
		v.stuck += dt
		if v.stuck > 4.0:
			v.ign = 2.5
			v.stuck = 0.0
	else:
		v.stuck = 0.0
	road_follow(v, dt, cr, null)

func _obst(v: Veh, fw: Vector2, q: Vector2, cr: float) -> float:
	var d = q - v.p
	var a = d.dot(fw)
	if a > 0.0 and a < 12.0 and absf(d.x * fw.y - d.y * fw.x) < 2.2:
		return minf(cr, 0.0 if a < 5.5 else (a - 5.5) * 1.6)
	return cr

func nearest_node(p: Vector2) -> Vector2i:
	var bi = 0
	var bj = 0
	for i in XL.size():
		if absf(XL[i] - p.x) < absf(XL[bi] - p.x):
			bi = i
	for j in ZL.size():
		if absf(ZL[j] - p.y) < absf(ZL[bj] - p.y):
			bj = j
	return Vector2i(bi, bj)

func to_road(v: Veh) -> void:
	var nn = nearest_node(v.p)
	var fw = Vector2(sin(v.h), cos(v.h))
	var best = Vector2i(1, 0)
	var bd = -9.0
	for dv in DIRS4():
		var q = dv.x * fw.x + dv.y * fw.y
		if q > bd and valid_dir(nn.x, nn.y, dv):
			bd = q
			best = dv
	var to = node_xz(nn.x, nn.y) - v.p
	if to.dot(fw) > 0.0:
		v.node = nn
	else:
		v.node = nn + best
	v.dir = best
	v.wps = []
	v.routed = true

func upd_police(v: Veh, dt: float) -> void:
	if v.wreck:
		v.spd *= 1.0 - dt * 2.0
		mv(v, dt)
		return
	var on = stars > 0
	if v.lb.size() == 2:
		var fl = on and int(T * 6.0) % 2 == 1
		v.lb[0].material_override.emission_energy_multiplier = 4.0 if (on and fl) else (0.4 if on else 0.2)
		v.lb[1].material_override.emission_energy_multiplier = 4.0 if (on and not fl) else (0.4 if on else 0.2)
	var ppos = player_pos()
	var d = v.p.distance_to(ppos)
	if v.rev > 0.0:
		v.rev -= dt
		v.spd = lerpf(v.spd, -7.0, clampf(dt * 4.0, 0.0, 1.0))
		v.h += dt * 1.2
		mv(v, dt)
		v.p = push_out(v.p, 2.0)
		return
	if not on:
		if not v.routed:
			to_road(v)
		road_follow(v, dt, 12.0, null)
		return
	var sp = 20.0 + stars * 3.5
	if d < 44.0 and v.see:
		v.seek = true
		var t = ppos
		if pmode == "car":
			t += Vector2(sin(pcar.h), cos(pcar.h)) * pcar.spd * 0.5
		var want = sp * (0.75 if d < 20.0 else 1.0)
		if d < 9.0:
			want = maxf(0.0, absf(pcar.spd) * 0.9) if pmode == "car" else 0.0
		steer_to(v, t, dt, want)
	else:
		if v.seek or not v.routed:
			v.seek = false
			to_road(v)
		road_follow(v, dt, sp, ppos)
	v.p = push_out(v.p, 2.0)
	if po_hit:
		v.spd *= 0.9
	if absf(v.spd) < 1.2 and d > 10.0:
		v.stuck += dt
		if v.stuck > 2.0:
			v.rev = 1.3
			v.stuck = 0.0
			v.seek = false
			v.routed = false
	else:
		v.stuck = 0.0

func spawn_police(close: bool) -> void:
	var ppos = player_pos()
	for k in 50:
		var i = randi() % XL.size()
		var j = randi() % ZL.size()
		if is_rb(i, j):
			continue
		var d = node_xz(i, j).distance_to(ppos)
		if d < (55.0 if close else 95.0) or d > (140.0 if close else 210.0):
			continue
		var best = Vector2i(1, 0)
		var bd = 1e9
		for dv in DIRS4():
			if not valid_dir(i, j, dv):
				continue
			var e = node_xz(i + dv.x, j + dv.y).distance_to(ppos)
			if e < bd:
				bd = e
				best = dv
		var v = add_veh("police", 0xf2f2f2, Vector2.ZERO, 0.0, "police")
		place_on_road(v, i, j, best, 8.0)
		v.spd = 12.0
		return

# ================= Piétons =================
func path_pt(r: Rect2, s: float) -> Vector2:
	var w = r.size.x
	var hh = r.size.y
	var L = 2.0 * (w + hh)
	s = fposmod(s, L)
	if s < w:
		return Vector2(r.position.x + s, r.position.y)
	s -= w
	if s < hh:
		return Vector2(r.position.x + w, r.position.y + s)
	s -= hh
	if s < w:
		return Vector2(r.position.x + w - s, r.position.y + hh)
	s -= w
	return Vector2(r.position.x, r.position.y + hh - s)

func add_ped() -> void:
	var p = Ped.new()
	place_ped(p, true)
	p.hum = add_human(pick(PEDFILES))
	set_ped(p)
	PEDS.append(p)

func place_ped(p: Ped, init: bool) -> void:
	var ppos = player_pos()
	var cands = []
	for k in BLOCKS.size():
		var b = BLOCKS[k]
		var d = b.get_center().distance_to(ppos)
		if d > 190.0:
			continue
		if not init and d < 70.0:
			continue
		cands.append(k)
	if cands.is_empty():
		for k in BLOCKS.size():
			cands.append(k)
	var chosen = cands[0]
	for k in 12:
		var c = pick(cands)
		if randf() * 2.2 < TILES[tile_of(BLOCKS[c].get_center())]["dens"]:
			chosen = c
			break
	p.r = BLOCKS[chosen]
	p.tile = tile_of(p.r.get_center())
	p.s = randf() * 2.0 * (p.r.size.x + p.r.size.y)
	p.dir = -1.0 if randf() < 0.5 else 1.0
	p.spd = 1.1 + randf() * 0.5
	p.st = "walk"
	p.free = false
	p.t = 0.0

func set_ped(p: Ped) -> void:
	p.p = path_pt(p.r, p.s)
	p.y = gy(p.p)
	p.hum.root.rotation = Vector3.ZERO
	p.hum.root.position = Vector3(p.p.x, p.y, p.p.y)

func scare(c: Vector2, r: float) -> void:
	for p in PEDS:
		if not p.on or p.st == "down":
			continue
		var d = p.p.distance_to(c)
		if d > r:
			continue
		if p.free:
			p.f = (p.p - c).normalized()
		else:
			var a = path_pt(p.r, p.s + 1.0)
			var b = path_pt(p.r, p.s - 1.0)
			p.dir = 1.0 if a.distance_to(c) > b.distance_to(c) else -1.0
		p.st = "flee"
		p.t = 4.0 + randf() * 3.0

func upd_ped(p: Ped, dt: float) -> void:
	var h = p.hum
	if p.st == "down":
		p.t -= dt
		if p.t > 0.0:
			return
		h.root.rotation.x = 0.0
		p.st = "flee"
		p.t = 5.0
	if p.st == "idle":
		p.t -= dt
		anim_h(h, 0.0, dt, false)
		if p.t < 0.0:
			p.st = "walk"
		return
	var sp = p.spd
	var flee = p.st == "flee"
	if flee:
		p.t -= dt
		sp = 5.0
		if p.t < 0.0:
			p.st = "walk"
	elif randf() < dt * 0.025:
		p.st = "idle"
		p.t = 2.0 + randf() * 4.0
		return
	if p.free:
		if not flee:
			sp = 1.2
		p.p += p.f * sp * dt
		p.p = push_out(p.p, 0.35)
		p.yaw = atan2(p.f.x, p.f.y)
	else:
		p.s += p.dir * sp * dt
		var q = path_pt(p.r, p.s)
		var dv = q - p.p
		if dv.length() > 0.0001:
			p.yaw = atan2(dv.x, dv.y)
		p.p = q
	p.y = gy(p.p)
	h.root.position = Vector3(p.p.x, p.y, p.p.y)
	h.root.rotation.y = p.yaw
	anim_h(h, sp, dt, flee)

func knock(p: Ped) -> void:
	if p.st == "down":
		return
	p.st = "down"
	p.t = 3.0
	p.hum.root.rotation.x = -PI / 2.0
	p.hum.root.position.y = p.y + 0.25
	scare(p.p, 20.0)

# ================= Objets =================
func marker(c: Color) -> Node3D:
	var g = Node3D.new()
	add_child(g)
	var m = StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	m.albedo_color = Color(c.r, c.g, c.b, 0.3)
	var cy = CylinderMesh.new()
	cy.top_radius = 2.4
	cy.bottom_radius = 2.4
	cy.height = 3.2
	cy.cap_top = false
	cy.cap_bottom = false
	cy.radial_segments = 28
	mi(cy, m, g, Vector3(0, 1.6, 0), false)
	var m2 = StandardMaterial3D.new()
	m2.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m2.albedo_color = c
	var to = TorusMesh.new()
	to.inner_radius = 2.1
	to.outer_radius = 2.6
	var ring = mi(to, m2, g, Vector3(0, 0.3, 0), false)
	ring.scale = Vector3(1, 0.25, 1)
	g.visible = false
	return g

func build_objects() -> void:
	mk_main = marker(Color(1.0, 0.82, 0.25))
	mk_goal = marker(Color(1.0, 0.69, 0.0))
	mk_taxi = marker(Color(0.25, 0.66, 1.0))
	mk_gar = marker(Color(0.27, 0.82, 0.42))
	mk_gar.position = Vector3(GPT.x, 0, GPT.y)
	mk_gar.visible = true
	mk_taxi.position = Vector3(TAXI.x, 0, TAXI.y)
	var cm = box_mesh(Vector3(0.75, 0.42, 0.42))
	var cmat = mat(Color(0.18, 0.62, 0.29), 0.0, 0.6)
	var rng = RandomNumberGenerator.new()
	rng.seed = 4242
	for k in 18:
		var b = BLOCKS[rng.randi() % BLOCKS.size()]
		var p = path_pt(b, rng.randf() * 2.0 * (b.size.x + b.size.y))
		cashes.append(mi(cm, cmat, self, Vector3(p.x, 0.8, p.y)))

## Véhicules garés sur les petites rues (largeur 5 m), hors du trafic.
func spawn_parked() -> void:
	var rng = RandomNumberGenerator.new()
	rng.seed = 777
	var narrow_x = [-280.0, -200.0, -40.0, 40.0, 200.0, 280.0]
	for k in 12:
		var x = narrow_x[rng.randi() % narrow_x.size()] + 1.2
		var z = -230.0 + rng.randf() * 460.0
		for tries in 20:
			var ok = true
			for zl in [-200.0, -160.0, -120.0, -80.0, -40.0, 40.0, 80.0, 120.0, 160.0, 200.0]:
				if absf(z - zl) < 12.0:
					ok = false
			if ok:
				break
			z = -230.0 + rng.randf() * 460.0
		var r = rng.randf()
		var kind = "sedan"
		if r < 0.2:
			kind = "pickup"
		elif r < 0.35:
			kind = "scooter"
		elif r < 0.45:
			kind = "moto"
		var v = add_veh(kind, CARCOL[kind][rng.randi() % CARCOL[kind].size()], Vector2(x, z), 0.0, "")
		v.p = push_out(v.p, v.rad)
		v.driver = false
	var mine = add_veh("sedan", 0x2367b4, Vector2(20.0, 161.2), PI / 2.0, "")
	mine.mine = true
	var sc = add_veh("scooter", 0xd35400, Vector2(14.0, 158.8), PI / 2.0, "")
	sc.mine = true
	if sav["car"] != null and typeof(sav["car"]) == TYPE_DICTIONARY:
		var c = sav["car"]
		var kk = str(c.get("kind", "sedan"))
		if not STATS.has(kk):
			kk = "sedan"
		var sv2 = add_veh(kk, int(c.get("color", 0x2367b4)), Vector2(41.2, 135.0), 0.0, "")
		sv2.mine = true
		if kk == "moto" and int(c.get("color", 0)) == 0xbf1a24:
			comet = sv2

# ================= Recherche (police) =================
func player_pos() -> Vector2:
	return pcar.p if pmode == "car" else pp

func police_near(p: Vector2, r: float) -> bool:
	for v in VEH:
		if v.ai == "police" and not v.wreck and v.p.distance_to(p) < r:
			return true
	return false

func add_heat(n: int, why: String) -> void:
	if pbusted > 0.0:
		return
	var b = stars
	stars = mini(5, stars + n)
	w_lost = 0.0
	w_seen = true
	if stars > b:
		toast(why)
		if stars >= 3 and b < 3:
			big("RENFORTS EN ROUTE", "")

func upd_wanted(dt: float) -> void:
	var ppos = player_pos()
	var cops = []
	for v in VEH:
		if v.ai == "police":
			cops.append(v)
	w_cool -= dt
	if stars == 0:
		for c in cops:
			if c.p.distance_to(ppos) > 170.0:
				del_veh(c)
	if stars > 0:
		var want = [0, 1, 2, 3, 4, 4][stars]
		var alive = 0
		for c in cops:
			if not c.wreck:
				alive += 1
		w_spawn -= dt
		if alive < want and w_spawn < 0.0:
			spawn_police(stars >= 3)
			w_spawn = 3.0 if stars >= 3 else 6.0
		w_los -= dt
		if w_los < 0.0:
			w_los = 0.3
			w_seen = false
			for c in cops:
				c.see = not c.wreck and c.p.distance_to(ppos) < 55.0 + stars * 12.0 and los(c.p, ppos)
				if c.see:
					w_seen = true
		if w_seen:
			w_lost = 0.0
		else:
			w_lost += dt
			if w_lost > 7.0 + stars * 1.6:
				stars -= 1
				w_lost = 0.0
				toast("Ils perdent ta trace…" if stars > 0 else "Tu as semé la police !")
		var near = false
		for c in cops:
			if not c.wreck and c.p.distance_to(ppos) < 7.5:
				near = true
		var slow = pmode == "foot" or absf(pcar.spd) < 3.5
		if near and slow:
			w_bust += dt
			if w_bust > 2.2:
				busted()
		else:
			w_bust = maxf(0.0, w_bust - dt * 1.5)
	else:
		w_bust = 0.0

func busted() -> void:
	var fine = int(round(sav["money"] * 0.1))
	sav["money"] -= fine
	store()
	update_money()
	pbusted = 2.8
	stars = 0
	w_bust = 0.0
	ui["bust_sub"].text = ("Amende : -%d $" % fine) if fine > 0 else ""
	ui["bust"].visible = true
	if mact != null:
		fail_mission("Arrêté par la police")

func after_bust() -> void:
	ui["bust"].visible = false
	if pmode == "car":
		exit_car()
	pp = PST
	py = 0.12
	pvy = 0.0
	pyaw = PI
	cam_yaw = PI
	for v in VEH.duplicate():
		if v.ai == "police":
			del_veh(v)

# ================= Missions =================
func build_missions() -> void:
	MIS = [
		{"n": "Bienvenue à Cocody", "s": Vector2(7.0, 152.0), "r": 100, "steps": [{"k": "go", "p": Vector2(-233.0, 85.0), "txt": "Rejoins le marché de Saint-Jean à pied (repère jaune sur la carte)."}]},
		{"n": "Livraison express", "s": Vector2(-233.0, 72.0), "r": 250, "steps": [{"k": "car", "txt": "Monte dans un véhicule : approche-toi d'une voiture et appuie sur MONTER."}, {"k": "go", "p": Vector2(243.0, -160.0), "car": true, "time": 120.0, "txt": "Livre le colis à la Riviera avant la fin du chrono."}]},
		{"n": "La moto rouge", "s": Vector2(247.0, -104.0), "r": 400, "save": true, "steps": [{"k": "spawn"}, {"k": "enter", "txt": "Récupère la moto rouge garée à Angré."}, {"k": "go", "p": GPT, "comet": true, "txt": "Ramène la moto au garage de Cocody Centre (repère vert) sans l'abîmer."}]},
		{"n": "Contre la montre", "s": Vector2(-233.0, -150.0), "r": 500, "steps": [{"k": "car", "txt": "Prends un véhicule pour la course."}, {"k": "cp", "pts": [Vector2(-240.0, -200.0), Vector2(-80.0, -200.0), Vector2(-80.0, -40.0), Vector2(-160.0, -40.0), Vector2(-320.0, -40.0)], "time": 100.0, "car": true, "txt": "Passe tous les points de contrôle"}]},
		{"n": "Semer la police", "s": Vector2(7.0, -160.0), "r": 700, "steps": [{"k": "heat", "n": 2}, {"k": "lose", "txt": "Sème la police : éloigne-toi et cache-toi derrière les immeubles."}]},
		{"n": "Le grand tour de Cocody", "s": Vector2(-7.0, 90.0), "r": 1000, "steps": [{"k": "car", "txt": "Trouve un véhicule."}, {"k": "cp", "pts": [Vector2(-160.0, -200.0), Vector2(80.0, -200.0), Vector2(320.0, -200.0), Vector2(320.0, 200.0), Vector2(80.0, 200.0), Vector2(-320.0, 200.0)], "time": 260.0, "car": true, "txt": "Traverse les 6 quartiers"}]},
	]

func start_mission(m: Dictionary) -> void:
	mact = m
	mstep = 0
	if m.get("taxi", false):
		big("TAXI COMPTEUR", "")
	else:
		big(str(m["n"]).to_upper(), "Mission %d / %d" % [sav["mi"] + 1, MIS.size()])
	begin_step()

func begin_step() -> void:
	var s = mact["steps"][mstep]
	mt = float(s.get("time", 0.0))
	mcp = 0
	if s["k"] == "spawn":
		if comet != null and comet != pcar and VEH.has(comet):
			del_veh(comet)
		comet = add_veh("moto", 0xbf1a24, Vector2(41.2, -150.0), 0.0, "")
		comet.driver = false
		next_step()
		return
	if s["k"] == "heat":
		add_heat(int(s["n"]), "La police te recherche !")
		next_step()
		return
	objective(s.get("txt", ""))

func next_step() -> void:
	mstep += 1
	if mstep >= mact["steps"].size():
		complete_mission()
	else:
		begin_step()

func complete_mission() -> void:
	var m = mact
	sav["money"] += int(m["r"])
	if not m.get("taxi", false):
		sav["mi"] += 1
	if m.get("save", false) and comet != null:
		sav["car"] = {"kind": "moto", "color": 0xbf1a24}
		toast("La moto est à toi : elle t'attend au garage.")
	store()
	update_money()
	big("MISSION RÉUSSIE", "+%d $" % int(m["r"]))
	end_mission()

func fail_mission(why: String) -> void:
	big("MISSION ÉCHOUÉE", why)
	end_mission()

func end_mission() -> void:
	mact = null
	mcool = 3.0
	set_goal(null)
	objective("")

func set_goal(p) -> void:
	mgoal = p
	mk_goal.visible = p != null
	if p != null:
		mk_goal.position = Vector3(p.x, 0, p.y)

func upd_missions(dt: float) -> void:
	var ppos = player_pos()
	var in_car = pmode == "car"
	mcool -= dt
	var av = MIS[sav["mi"]] if sav["mi"] < MIS.size() else null
	mk_main.visible = mact == null and av != null
	if av != null:
		mk_main.position = Vector3(av["s"].x, 0, av["s"].y)
	mk_taxi.visible = mact == null
	if mact == null:
		set_goal(null)
		ui["timer"].text = ""
		if mcool > 0.0:
			return
		if av != null and ppos.distance_to(av["s"]) < 3.4:
			if stars > 0:
				if mcool < -2.0:
					toast("Sème d'abord la police !")
					mcool = 2.0
			else:
				start_mission(av)
		elif ppos.distance_to(TAXI) < 4.5:
			if not in_car:
				if mcool < -2.0:
					toast("Viens en voiture pour faire le taxi.")
					mcool = 2.0
			else:
				start_taxi()
		return
	var s = mact["steps"][mstep]
	if s.has("time"):
		mt -= dt
		ui["timer"].text = "%d s" % int(ceil(mt))
		if mt <= 0.0:
			fail_mission("Temps écoulé")
			return
	else:
		ui["timer"].text = ""
	if comet != null and comet.wreck:
		for q in mact["steps"]:
			if q.get("comet", false) or q["k"] == "enter":
				fail_mission("La moto est détruite")
				return
	var ok = false
	var k = s["k"]
	if k == "go":
		set_goal(s["p"])
		ok = ppos.distance_to(s["p"]) < (6.5 if in_car else 3.0) and (not s.get("car", false) or in_car) and (not s.get("comet", false) or pcar == comet)
		if s.get("car", false) and not in_car:
			ui["obj"].text = "Remonte dans un véhicule !"
		else:
			ui["obj"].text = s["txt"]
	elif k == "car":
		set_goal(null)
		ok = in_car
	elif k == "enter":
		set_goal(comet.p)
		ok = pcar == comet
	elif k == "cp":
		set_goal(s["pts"][mcp])
		ui["obj"].text = "%s (%d/%d)" % [s["txt"], mcp, s["pts"].size()]
		if in_car and ppos.distance_to(s["pts"][mcp]) < 9.0:
			mcp += 1
			toast("Point %d / %d" % [mcp, s["pts"].size()])
			if mcp >= s["pts"].size():
				ok = true
	elif k == "lose":
		set_goal(null)
		ok = stars == 0
	if ok:
		next_step()

func start_taxi() -> void:
	var p = Vector2.ZERO
	var d = 0.0
	for k in 40:
		var i = randi() % XL.size()
		var j = randi() % ZL.size()
		if is_rb(i, j):
			continue
		p = node_xz(i, j)
		d = p.distance_to(TAXI)
		if d > 160.0 and d < 480.0:
			break
	start_mission({"n": "Taxi", "taxi": true, "r": int(round(d * 1.6 / 10.0)) * 10, "steps": [{"k": "go", "p": p, "car": true, "time": round(d / 11.0 + 30.0), "txt": "Dépose ton client à destination (%d m)." % int(d)}]})

# ================= Interface =================
func lbl(fsize: int, colr := Color.WHITE, outline := 8) -> Label:
	var l = Label.new()
	l.add_theme_font_size_override("font_size", fsize)
	l.add_theme_color_override("font_color", colr)
	l.add_theme_constant_override("outline_size", outline)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.85))
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l

func circle_tex(r: int, fill: Color, edge: Color) -> ImageTexture:
	var s = r * 2
	var img = Image.create(s, s, false, Image.FORMAT_RGBA8)
	img.fill(Color(0, 0, 0, 0))
	for yy in s:
		for xx in s:
			var d = Vector2(xx - r + 0.5, yy - r + 0.5).length()
			if d <= r - 4:
				img.set_pixel(xx, yy, fill)
			elif d <= r:
				img.set_pixel(xx, yy, edge)
	return ImageTexture.create_from_image(img)

func tbtn(name_: String, r: int, fill: Color, text: String, on_press: Callable, on_release: Callable) -> TouchScreenButton:
	var b = TouchScreenButton.new()
	b.texture_normal = circle_tex(r, fill, Color(1, 1, 1, 0.75))
	b.texture_pressed = circle_tex(r, fill.lightened(0.25), Color(1, 1, 1, 0.95))
	var sh = CircleShape2D.new()
	sh.radius = r
	b.shape = sh
	b.pressed.connect(on_press)
	b.released.connect(on_release)
	var l = lbl(15 if r < 45 else 17, Color.WHITE, 4)
	l.text = text
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.size = Vector2(r * 2, r * 2)
	b.add_child(l)
	ui[name_] = b
	ui[name_ + "_l"] = l
	ui[name_ + "_r"] = r
	return b

func _noop() -> void:
	pass

func build_hud() -> void:
	var layer = CanvasLayer.new()
	add_child(layer)
	ui["layer"] = layer
	hud = HudScript.new()
	hud.g = self
	hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.set_anchors_preset(Control.PRESET_FULL_RECT)
	layer.add_child(hud)
	minimap = MapScript.new()
	minimap.g = self
	minimap.mouse_filter = Control.MOUSE_FILTER_IGNORE
	minimap.clip_contents = true
	minimap.position = Vector2(16, 14)
	minimap.size = Vector2(176, 176)
	layer.add_child(minimap)
	var money = lbl(34, Color(0.56, 0.96, 0.6))
	money.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	layer.add_child(money)
	ui["money"] = money
	var panel = PanelContainer.new()
	var sb = StyleBoxFlat.new()
	sb.bg_color = Color(0, 0, 0, 0.62)
	sb.set_corner_radius_all(14)
	sb.content_margin_left = 16
	sb.content_margin_right = 16
	sb.content_margin_top = 8
	sb.content_margin_bottom = 8
	sb.border_width_left = 4
	sb.border_color = Color(1.0, 0.82, 0.25)
	panel.add_theme_stylebox_override("panel", sb)
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var vb = VBoxContainer.new()
	vb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.add_child(vb)
	var obj = lbl(19, Color.WHITE, 0)
	obj.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	obj.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	obj.custom_minimum_size = Vector2(440, 0)
	vb.add_child(obj)
	var timer = lbl(24, Color(1.0, 0.82, 0.25), 0)
	timer.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(timer)
	layer.add_child(panel)
	ui["obj_panel"] = panel
	ui["obj"] = obj
	ui["timer"] = timer
	panel.visible = false
	for key in ["toast", "big", "big_sub", "dist", "speed"]:
		var l = lbl({"toast": 22, "big": 54, "big_sub": 24, "dist": 36, "speed": 46}[key], Color(1.0, 0.82, 0.25) if key == "big" else Color.WHITE, 10)
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		layer.add_child(l)
		ui[key] = l
	var bust = ColorRect.new()
	bust.color = Color(0, 0, 0, 0.55)
	bust.set_anchors_preset(Control.PRESET_FULL_RECT)
	bust.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var bl = lbl(80, Color(0.3, 0.64, 1.0), 12)
	bl.text = "ARRÊTÉ"
	bl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	bust.add_child(bl)
	var bs = lbl(26)
	bs.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	bust.add_child(bs)
	bust.visible = false
	layer.add_child(bust)
	ui["bust"] = bust
	ui["bust_t"] = bl
	ui["bust_sub"] = bs
	layer.add_child(tbtn("bA", 54, Color(1.0, 0.35, 0.18, 0.9), "MONTER", action, _noop))
	layer.add_child(tbtn("bJ", 42, Color(0, 0, 0, 0.55), "SAUT", _on_bj, _on_bj_up))
	layer.add_child(tbtn("bR", 42, Color(0, 0, 0, 0.55), "COURIR", _on_br, _noop))
	layer.add_child(tbtn("bP", 26, Color(0, 0, 0, 0.55), "II", func(): set_pause(true), _noop))
	build_menus(layer)

func _on_bj() -> void:
	if pmode == "car":
		hb_btn = true
	else:
		jump_req = true

func _on_bj_up() -> void:
	hb_btn = false

func _on_br() -> void:
	prun = not prun

func menu_btn(text: String, cb: Callable, primary := true) -> Button:
	var b = Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(340, 66)
	b.add_theme_font_size_override("font_size", 24)
	var sb = StyleBoxFlat.new()
	sb.bg_color = Color(1.0, 0.35, 0.18) if primary else Color(1, 1, 1, 0.12)
	sb.set_corner_radius_all(33)
	b.add_theme_stylebox_override("normal", sb)
	b.add_theme_stylebox_override("hover", sb)
	var sb2 = sb.duplicate()
	sb2.bg_color = sb.bg_color.lightened(0.2)
	b.add_theme_stylebox_override("pressed", sb2)
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	b.pressed.connect(cb)
	return b

func overlay(layer: CanvasLayer) -> Array:
	var bg = ColorRect.new()
	bg.color = Color(0.07, 0.07, 0.09, 0.86)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	layer.add_child(bg)
	var cc = CenterContainer.new()
	cc.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg.add_child(cc)
	var vb = VBoxContainer.new()
	vb.add_theme_constant_override("separation", 14)
	vb.alignment = BoxContainer.ALIGNMENT_CENTER
	cc.add_child(vb)
	return [bg, vb]

func build_menus(layer: CanvasLayer) -> void:
	var t = overlay(layer)
	ui["title"] = t[0]
	var vb = t[1]
	var l1 = lbl(80, Color.WHITE, 0)
	l1.text = "CITÉ LIBRE"
	l1.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(l1)
	var l2 = lbl(64, Color(1.0, 0.35, 0.18), 0)
	l2.text = "COCODY"
	l2.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(l2)
	var sub = lbl(20, Color(0.8, 0.8, 0.84), 0)
	sub.text = "Abidjan · Angré · Riviera · Deux Plateaux · Saint-Jean · M'Badon"
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(sub)
	var has_prog = sav["mi"] > 0 or sav["money"] > 0
	vb.add_child(menu_btn("CONTINUER" if has_prog else "JOUER", start_game))
	var help = lbl(16, Color(0.65, 0.65, 0.7), 0)
	help.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	help.text = ("Progression : %d / %d missions · %d $\n" % [mini(sav["mi"], 6), 6, sav["money"]] if has_prog else "") + "Joystick à gauche · glisse à droite pour la caméra · bouton orange : monter/sortir"
	vb.add_child(help)
	var m = overlay(layer)
	ui["menu"] = m[0]
	var mv_ = m[1]
	var lp = lbl(56, Color.WHITE, 0)
	lp.text = "PAUSE"
	lp.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	mv_.add_child(lp)
	mv_.add_child(menu_btn("Reprendre", func(): set_pause(false)))
	var ql = lbl(20, Color(0.8, 0.8, 0.84), 0)
	ql.text = "Qualité graphique"
	ql.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	mv_.add_child(ql)
	var hb = HBoxContainer.new()
	hb.alignment = BoxContainer.ALIGNMENT_CENTER
	hb.add_theme_constant_override("separation", 10)
	mv_.add_child(hb)
	ui["qbtns"] = []
	for i in 3:
		var b = menu_btn(QL[i]["n"], func(): set_quality(i), false)
		b.custom_minimum_size = Vector2(110, 54)
		hb.add_child(b)
		ui["qbtns"].append(b)
	mv_.add_child(menu_btn("Effacer la progression", reset_progress, false))
	ui["menu"].visible = false

func start_game() -> void:
	started = true
	paused = false
	ui["title"].visible = false
	upd_btns()
	cam_yaw = PI
	cam_pitch = 0.3
	big("COCODY", "Rejoins le repère jaune pour commencer" if sav["mi"] < MIS.size() else "Toutes les missions sont faites : fais le taxi !")

func set_pause(on: bool) -> void:
	if not started:
		return
	paused = on
	ui["menu"].visible = on
	upd_btns()

func set_quality(i: int) -> void:
	sav["q"] = i
	store()
	apply_quality()

func reset_progress() -> void:
	sav = {"money": 0, "mi": 0, "car": null, "q": sav["q"]}
	store()
	get_tree().reload_current_scene()

func apply_quality() -> void:
	Q = QL[clampi(int(sav["q"]), 0, 2)]
	get_viewport().scaling_3d_scale = Q["scale"]
	sun.shadow_enabled = Q["shadow"]
	env.fog_density = Q["fog"]
	if ui.has("qbtns"):
		for i in 3:
			var sb = ui["qbtns"][i].get_theme_stylebox("normal").duplicate()
			sb.bg_color = Color(1.0, 0.35, 0.18) if i == int(sav["q"]) else Color(1, 1, 1, 0.12)
			ui["qbtns"][i].add_theme_stylebox_override("normal", sb)
			ui["qbtns"][i].add_theme_stylebox_override("hover", sb)
	population()

func layout() -> void:
	var s = get_viewport().get_visible_rect().size
	ui["money"].position = Vector2(s.x - 340, 12)
	ui["money"].size = Vector2(250, 40)
	ui["obj_panel"].position = Vector2(s.x / 2.0 - 240, 12)
	ui["obj_panel"].size = Vector2(480, 0)
	ui["toast"].position = Vector2(0, s.y * 0.27)
	ui["toast"].size = Vector2(s.x, 40)
	ui["big"].position = Vector2(0, s.y * 0.32)
	ui["big"].size = Vector2(s.x, 70)
	ui["big_sub"].position = Vector2(0, s.y * 0.32 + 72)
	ui["big_sub"].size = Vector2(s.x, 36)
	ui["dist"].position = Vector2(0, s.y - 170)
	ui["dist"].size = Vector2(s.x, 50)
	ui["speed"].position = Vector2(0, s.y - 96)
	ui["speed"].size = Vector2(s.x, 60)
	ui["bust_t"].position = Vector2(s.x / 2.0 - 300, s.y / 2.0 - 70)
	ui["bust_t"].size = Vector2(600, 100)
	ui["bust_sub"].position = Vector2(s.x / 2.0 - 300, s.y / 2.0 + 30)
	ui["bust_sub"].size = Vector2(600, 40)
	var a = ui["bA_r"]
	var j = ui["bJ_r"]
	ui["bA"].position = Vector2(s.x - 24 - a * 2, s.y - 24 - a * 2)
	ui["bJ"].position = Vector2(s.x - 48 - a * 2 - j * 2, s.y - 20 - j * 2)
	ui["bR"].position = Vector2(s.x - 30 - a - j, s.y - 40 - a * 2 - j * 2)
	ui["bP"].position = Vector2(s.x - 70, 12)
	btn_rects = []
	for k in ["bA", "bJ", "bR", "bP"]:
		var r = ui[k + "_r"]
		btn_rects.append(Rect2(ui[k].position, Vector2(r * 2, r * 2)))

func toast(m: String) -> void:
	ui["toast"].text = m
	ui["toast"].visible = true
	toast_t = 2.4

func big(a: String, b: String) -> void:
	ui["big"].text = a
	ui["big_sub"].text = b
	ui["big"].visible = true
	ui["big_sub"].visible = true
	big_t = 3.0

func objective(t: String) -> void:
	ui["obj"].text = t
	ui["obj_panel"].visible = t != ""

func update_money() -> void:
	ui["money"].text = str(sav["money"]) + " $"

func hud_mode() -> void:
	var c = pmode == "car"
	ui["bJ_l"].text = "FREIN" if c else "SAUT"
	ui["bA_l"].text = "SORTIR" if c else "MONTER"
	upd_btns()

func upd_btns() -> void:
	var play = started and not paused
	for k in ["bA", "bJ", "bP"]:
		ui[k].visible = play
	ui["bR"].visible = play and pmode == "foot"

# ================= Entrées =================
func _on_button(pos: Vector2) -> bool:
	var keys = ["bA", "bJ", "bR", "bP"]
	for i in btn_rects.size():
		if ui[keys[i]].visible and btn_rects[i].has_point(pos):
			return true
	return false

func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.physical_keycode == KEY_E or event.physical_keycode == KEY_F:
			action()
		elif event.physical_keycode == KEY_SPACE and pmode == "foot":
			jump_req = true
		elif event.physical_keycode == KEY_ESCAPE:
			set_pause(not paused)
	if paused:
		return
	if event is InputEventScreenTouch:
		if event.pressed:
			if _on_button(event.position):
				return
			var w = get_viewport().get_visible_rect().size.x
			if event.position.x < w * 0.42 and jp == -1:
				jp = event.index
				j0 = event.position
				jcur = event.position
			elif cpid == -1:
				cpid = event.index
		else:
			if event.index == jp:
				jp = -1
				JX = 0.0
				JY = 0.0
			if event.index == cpid:
				cpid = -1
	elif event is InputEventScreenDrag:
		if event.index == jp:
			var d = event.position - j0
			var m = 64.0
			if d.length() > m:
				d = d.normalized() * m
			jcur = j0 + d
			JX = d.x / m
			JY = -d.y / m
		elif event.index == cpid:
			cam_yaw -= event.relative.x * 0.0065
			cam_pitch = clampf(cam_pitch + event.relative.y * 0.004, -0.1, 1.05)
			drag_t = 0.0

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST or what == NOTIFICATION_APPLICATION_PAUSED:
		set_pause(true)

func read_input() -> void:
	var kx = 0.0
	var ky = 0.0
	if Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_RIGHT):
		kx += 1.0
	if Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_Q) or Input.is_physical_key_pressed(KEY_LEFT):
		kx -= 1.0
	if Input.is_physical_key_pressed(KEY_W) or Input.is_physical_key_pressed(KEY_Z) or Input.is_physical_key_pressed(KEY_UP):
		ky += 1.0
	if Input.is_physical_key_pressed(KEY_S) or Input.is_physical_key_pressed(KEY_DOWN):
		ky -= 1.0
	in_x = clampf(JX + kx, -1.0, 1.0)
	in_y = clampf(JY + ky, -1.0, 1.0)

func hb_on() -> bool:
	return pmode == "car" and (hb_btn or Input.is_physical_key_pressed(KEY_SPACE))

func run_on() -> bool:
	return prun or Input.is_physical_key_pressed(KEY_SHIFT)

# ================= Actions =================
func near_car():
	var best = null
	var bd = 3.8
	for v in VEH:
		if v.wreck:
			continue
		var d = v.p.distance_to(pp)
		if d < bd and absf(v.spd) < 4.0:
			bd = d
			best = v
	return best

func action() -> void:
	if paused or pbusted > 0.0:
		return
	if pmode == "car":
		exit_car()
		return
	var v = near_car()
	if v != null:
		enter_car(v)

func enter_car(v: Veh) -> void:
	if v.driver:
		var far = null
		var fd = -1.0
		for q in PEDS:
			if q.on and q.p.distance_to(pp) > fd:
				fd = q.p.distance_to(pp)
				far = q
		if far != null:
			far.free = true
			far.p = v.p + Vector2(cos(v.h), -sin(v.h)) * 2.4
			far.hum.root.rotation.x = 0.0
			far.f = (far.p - pp).normalized()
			far.st = "flee"
			far.t = 6.0
		if v.ai == "police":
			add_heat(2, "Vol de voiture de police !")
		else:
			add_heat(1, "Vol de véhicule !")
	elif v != comet and not v.mine and police_near(v.p, 70.0):
		add_heat(1, "Vol repéré par la police")
	v.ai = ""
	v.driver = false
	v.stop_t = 0.0
	v.mine = true
	pcar = v
	pmode = "car"
	if v.two:
		pose_seated(P_h)
		P_h.root.visible = true
	else:
		P_h.root.visible = false
	drag_t = 9.0
	prun = false
	hud_mode()

func exit_car() -> void:
	var v = pcar
	if v == null:
		return
	pmode = "foot"
	pcar = null
	P_h.root.visible = true
	P_h.root.rotation = Vector3.ZERO
	pp = v.p + Vector2(cos(v.h), -sin(v.h)) * (1.4 if v.two else 2.4)
	py = gy(pp) + 0.2
	pvy = 0.0
	pyaw = v.h
	v.spd = 0.0
	v.steer = 0.0
	v.roll = 0.0
	pp = push_out(pp, 0.45)
	hud_mode()

func upd_foot(dt: float) -> void:
	var mag = minf(1.0, Vector2(in_x, in_y).length())
	var f = Vector2(sin(cam_yaw), cos(cam_yaw))
	var r = Vector2(-f.y, f.x)
	var m = f * in_y + r * in_x
	var sp = 0.0
	if m.length() > 0.05 and pstun <= 0.0:
		sp = mag * (7.8 if run_on() else 4.0)
		pp += m.normalized() * sp * dt
		pyaw += angd(pyaw, atan2(m.x, m.y)) * minf(1.0, dt * 12.0)
	pstun -= dt
	var g = gy(pp)
	var on_g = py <= g + 0.02
	if jump_req and on_g:
		pvy = 6.5
	jump_req = false
	pvy -= 20.0 * dt
	py += pvy * dt
	if py < g:
		py = g
		pvy = 0.0
	pp = push_out(pp, 0.38)
	for v in VEH:
		var d = v.p.distance_to(pp)
		var rr = v.rad + 0.25
		if d < rr and d > 0.01:
			pp += (pp - v.p) / d * (rr - d)
			if absf(v.spd) > 5.0 and pstun <= 0.0:
				pstun = 1.0
				pvy = 4.0
				v.spd *= 0.6
	for p in PEDS:
		if p.on and p.st == "walk" and p.p.distance_to(pp) < 1.1:
			scare(pp, 3.0)
	P_h.root.position = Vector3(pp.x, py, pp.y)
	P_h.root.rotation.y = pyaw
	anim_h(P_h, sp if on_g else 0.0, dt, false)
	if not on_g:
		P_h.hipL.rotation.x = -0.5
		P_h.hipR.rotation.x = 0.3
	pspd = sp

func upd_car(v: Veh, dt: float) -> void:
	var mx = v.vmax * (0.6 if v.hp < 30.0 else 1.0)
	var thr = 0.0 if v.wreck else in_y
	var o = v.spd
	var hb = hb_on()
	if thr > 0.05:
		if v.spd < 0.0:
			v.spd += 28.0 * dt * thr
		else:
			v.spd += v.vacc * dt * thr * (1.0 - v.spd / mx)
	elif thr < -0.05:
		if v.spd > 0.0:
			v.spd += 30.0 * dt * thr
		else:
			v.spd = maxf(-9.0 if not v.two else -3.0, v.spd + 9.0 * dt * thr)
	else:
		v.spd *= 1.0 - 0.5 * dt
	if hb:
		v.spd *= 1.0 - 2.2 * dt
	var sf = clampf(absf(v.spd) / 6.0, 0.0, 1.0) * (1.0 if v.spd >= 0.0 else -1.0)
	v.steer = lerpf(v.steer, in_x, clampf(dt * 8.0, 0.0, 1.0))
	v.h -= v.steer * (2.2 if v.two else 1.9) * sf * dt * (1.6 if hb else 1.0) * (1.0 - minf(0.45, absf(v.spd) / 90.0))
	mv(v, dt)
	v.acc = (v.spd - o) / maxf(dt, 0.001)
	v.p = push_out(v.p, v.rad)
	if po_hit:
		var vn = -(sin(v.h) * po_n.x + cos(v.h) * po_n.y) * v.spd
		if vn > 3.0:
			dmg(v, vn * 1.1)
			v.spd *= -0.25
			shake = minf(1.0, vn / 20.0)
		else:
			v.spd *= 0.97
	hit_cool -= dt
	for o2 in VEH:
		if o2 == v:
			continue
		var dv = o2.p - v.p
		var d = dv.length()
		var rr = v.rad + o2.rad
		if d > rr or d < 0.001:
			continue
		var n = dv / d
		var ov = rr - d
		o2.p += n * ov * 0.6
		v.p -= n * ov * 0.4
		var vr = (sin(v.h) * v.spd - sin(o2.h) * o2.spd) * n.x + (cos(v.h) * v.spd - cos(o2.h) * o2.spd) * n.y
		if vr > 2.0:
			v.spd *= 0.6
			o2.spd *= 0.4
			if vr > 6.0:
				dmg(v, vr * 1.1)
				dmg(o2, vr * 1.5)
				shake = minf(1.0, vr / 18.0)
				crash(o2)
	if absf(v.spd) > 3.5:
		for p in PEDS:
			if not p.on or p.st == "down":
				continue
			if p.p.distance_to(v.p) < v.rad:
				knock(p)
				v.spd *= 0.85
				if hit_cool <= 0.0:
					add_heat(1, "Piéton renversé !")
					hit_cool = 3.0
	pp = v.p
	if v.two and pcar == v:
		P_h.root.global_transform = v.body.global_transform * Transform3D(Basis(), Vector3(0, 0.68, -0.5))

func crash(o: Veh) -> void:
	scare(o.p, 18.0)
	if o.ai == "traffic":
		o.stop_t = 3.0 + randf() * 3.0
		if police_near(o.p, 80.0) and hit_cool <= 0.0:
			add_heat(1, "Accident repéré par la police")
			hit_cool = 3.0
	elif o.ai == "police" and w_cool <= 0.0:
		add_heat(1, "Agression d'un policier !")
		w_cool = 4.0

# ================= Caméra =================
func upd_cam(dt: float) -> void:
	var car = pmode == "car"
	var tg = Vector3(pcar.p.x, pcar.y, pcar.p.y) if car else Vector3(pp.x, py, pp.y)
	drag_t += dt
	if not started:
		cam_yaw += dt * 0.12
		cam_pitch = 0.38
	elif car and drag_t > 1.2:
		cam_yaw += angd(cam_yaw, pcar.h + (PI if pcar.spd < -2.0 else 0.0)) * minf(1.0, dt * 3.2)
		cam_pitch = lerpf(cam_pitch, 0.2, dt * 2.0)
	var d = 5.6
	if car:
		d = (6.0 if pcar.two else 8.6) + absf(pcar.spd) * 0.07
	var ty = tg.y + (1.7 if car else 1.5)
	var cp = cos(cam_pitch)
	var sp = sin(cam_pitch)
	var e = Vector3(tg.x - sin(cam_yaw) * d * cp, maxf(0.6, ty + d * sp), tg.z - cos(cam_yaw) * d * cp)
	var tgt = Vector3(tg.x, ty, tg.z)
	for k in range(1, 11):
		var f = k / 10.0
		var q = tgt.lerp(e, f)
		if solid_at(q.x, q.y, q.z):
			e = tgt.lerp(e, maxf(0.15, (k - 1.5) / 10.0))
			break
	var s = 1.0 - exp(-dt * (9.0 if car else 14.0))
	cam_pos = cam_pos.lerp(e, s)
	shake = maxf(0.0, shake - dt * 2.0)
	var sk = shake * 0.35
	cam.position = cam_pos + Vector3(randf() - 0.5, randf() - 0.5, randf() - 0.5) * sk
	if cam.position.distance_to(tgt) > 0.05:
		cam.look_at(tgt, Vector3.UP)
	var fv = 62.0
	if car:
		fv += minf(14.0, absf(pcar.spd) * 0.35)
	cam_fov = lerpf(cam_fov, fv, dt * 3.0)
	cam.fov = cam_fov

# ================= Population =================
func population() -> void:
	var np = int(round(Q["peds"] * pop))
	while PEDS.size() < np:
		add_ped()
	for i in PEDS.size():
		PEDS[i].on = i < np
		PEDS[i].hum.root.visible = PEDS[i].on
	var nc = int(round(Q["cars"] * pop))
	var tr = []
	for v in VEH:
		if v.ai == "traffic":
			tr.append(v)
	for i in range(tr.size(), nc):
		spawn_traffic(null, not started)
	for i in range(nc, tr.size()):
		if tr[i].p.distance_to(player_pos()) > 60.0:
			del_veh(tr[i])

# ================= Boucle =================
func _process(delta: float) -> void:
	var dt = minf(delta, 0.05)
	if not paused:
		update_game(dt)
	upd_cam(dt)
	hud.queue_redraw()
	minimap.queue_redraw()
	fps_t += delta
	if fps_t > 3.0:
		fps_t = 0.0
		if started and not paused:
			var fps = Engine.get_frames_per_second()
			if fps < 28.0 and pop > 0.4:
				pop -= 0.15
				population()
			elif fps > 50.0 and pop < 1.0:
				pop = minf(1.0, pop + 0.1)
				population()

func update_game(dt: float) -> void:
	T += dt
	read_input()
	if pbusted > 0.0:
		pbusted -= dt
		if pbusted <= 0.0:
			after_bust()
	elif pmode == "car":
		upd_car(pcar, dt)
	else:
		upd_foot(dt)
	var ppos = player_pos()
	for v in VEH.duplicate():
		if v == pcar:
			vis_veh(v, dt)
			if v.two:
				P_h.root.global_transform = v.body.global_transform * Transform3D(Basis(), Vector3(0, 0.68, -0.5))
			continue
		var d = v.p.distance_to(ppos)
		if v.ai == "traffic":
			if d > 240.0:
				spawn_traffic(v, false)
				continue
			if d < 190.0:
				upd_traffic(v, dt)
		elif v.ai == "police":
			upd_police(v, dt)
		elif absf(v.spd) > 0.1:
			v.spd *= 1.0 - dt * 2.0
			mv(v, dt)
		if VEH.has(v):
			vis_veh(v, dt)
	for p in PEDS:
		if not p.on:
			continue
		var d = p.p.distance_to(ppos)
		if d > 160.0:
			place_ped(p, false)
			set_ped(p)
			continue
		if d < 120.0:
			upd_ped(p, dt)
	upd_wanted(dt)
	upd_missions(dt)
	for m in [mk_main, mk_goal, mk_taxi, mk_gar]:
		m.rotation.y = T
	for c in cashes:
		if not c.visible:
			continue
		c.rotation.y = T * 2.0
		c.position.y = 0.8 + sin(T * 3.0 + c.position.x) * 0.15
		if Vector2(c.position.x, c.position.z).distance_to(ppos) < (3.0 if pmode == "car" else 1.6):
			c.visible = false
			var gain = 10 * (2 + randi() % 7)
			sav["money"] += gain
			store()
			update_money()
			toast("+%d $" % gain)
	if pmode == "car" and ppos.distance_to(GPT) < 4.5 and absf(pcar.spd) < 6.0:
		if not in_gar:
			in_gar = true
			var v = pcar
			var msg = "Véhicule sauvegardé au garage"
			if v.hp < 100.0:
				if sav["money"] >= 100:
					sav["money"] -= 100
					v.hp = 100.0
					v.tilt = 0.0
					paint_veh(v)
					msg += " · réparé (-100 $)"
				else:
					msg += " · pas assez d'argent pour le réparer"
			sav["car"] = {"kind": v.kind, "color": v.base.to_rgba32() >> 8}
			store()
			update_money()
			toast(msg)
	elif ppos.distance_to(GPT) > 7.0:
		in_gar = false
	var di = tile_of(ppos)
	if di != cur_dist:
		cur_dist = di
		ui["dist"].text = TILES[di]["n"]
		ui["dist"].visible = true
		dist_t = 2.5
	if pmode == "car":
		ui["speed"].text = str(int(round(absf(pcar.spd) * 3.6))) + " km/h"
		ui["speed"].visible = true
	else:
		ui["speed"].visible = false
	ui["bA"].modulate.a = 1.0 if (pmode == "car" or near_car() != null) else 0.35
	toast_t -= dt
	if toast_t < 0.0:
		ui["toast"].visible = false
	big_t -= dt
	if big_t < 0.0:
		ui["big"].visible = false
		ui["big_sub"].visible = false
	dist_t -= dt
	if dist_t < 0.0:
		ui["dist"].visible = false
