# LocalShare 4.0 — améliorations

- Dossier visible `LocalShare` dans le stockage, créé automatiquement.
- Sous-dossiers automatiques : `Vidéo`, `Documents`, `Musique`, `Application`, `Autres`.
- Les fichiers reçus sont classés automatiquement selon leur extension.
- Le partage Android `Partager → Local Share` reste pris en charge pour `SEND` et `SEND_MULTIPLE` : le fichier arrive dans la file d'envoi à l'ouverture de l'application.
- Progression et notifications de transfert conservées, avec ouverture du fichier reçu depuis la notification lorsqu'un fichier unique est terminé.
- Nouvelle apparence `Système / Clair / Sombre`.
- Interface claire plus lumineuse, tout en conservant le thème sombre.
- Les fonctions existantes (Wi‑Fi Direct, hotspot, serveur web/QR, explorateur de fichiers, etc.) sont conservées.
