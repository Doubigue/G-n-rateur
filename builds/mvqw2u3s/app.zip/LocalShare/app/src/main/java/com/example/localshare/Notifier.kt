package com.example.localshare

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import java.io.File

object Notifier {
    private const val CH_LINK = "link"
    private const val CH_REQ = "requests"
    private const val CH_PROG = "progress"
    private const val CH_DONE = "done"

    const val ID_LINK = 2
    const val ID_REQUEST = 3
    const val ID_FS = 4
    const val ID_SEND = 5
    const val ID_RECV = 6
    const val ID_SEND_DONE = 7
    const val ID_RECV_DONE = 8

    fun init(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_LINK, "Connexion", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_REQ, "Demandes", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CH_PROG, "Progression", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_DONE, "Transferts terminés", NotificationManager.IMPORTANCE_DEFAULT))
    }

    private fun openApp(ctx: Context, cls: Class<*>, req: Int): PendingIntent = PendingIntent.getActivity(
        ctx, req, Intent(ctx, cls).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun post(ctx: Context, id: Int, n: Notification) {
        try {
            NotificationManagerCompat.from(ctx).notify(id, n)
        } catch (_: SecurityException) {
        }
    }

    fun cancel(ctx: Context, id: Int) {
        try {
            NotificationManagerCompat.from(ctx).cancel(id)
        } catch (_: Exception) {
        }
    }

    /** Notification permanente du service Wi-Fi Direct. */
    fun linkNotification(ctx: Context, text: String): Notification {
        val quit = PendingIntent.getService(
            ctx, 1, Intent(ctx, P2pService::class.java).setAction(P2pService.ACTION_QUIT),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(ctx, CH_LINK)
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentTitle("LocalShare")
            .setContentText(text)
            .setContentIntent(openApp(ctx, MainActivity::class.java, 10))
            .addAction(0, "Quitter", quit)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    fun showConnectionRequest(ctx: Context, name: String, code: String) {
        post(
            ctx, ID_REQUEST,
            NotificationCompat.Builder(ctx, CH_REQ)
                .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
                .setContentTitle("Demande de connexion")
                .setContentText("« $name » veut se connecter · code $code")
                .setContentIntent(openApp(ctx, MainActivity::class.java, 11))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setTimeoutAfter(60_000)
                .build()
        )
    }

    fun showFsRequest(ctx: Context, name: String) {
        post(
            ctx, ID_FS,
            NotificationCompat.Builder(ctx, CH_REQ)
                .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
                .setContentTitle("Accès à vos fichiers")
                .setContentText("« $name » demande à parcourir vos fichiers et applications")
                .setContentIntent(openApp(ctx, SessionActivity::class.java, 12))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .build()
        )
    }

    fun showProgress(ctx: Context, outgoing: Boolean, title: String, body: String, percent: Int, indeterminate: Boolean) {
        post(
            ctx, if (outgoing) ID_SEND else ID_RECV,
            NotificationCompat.Builder(ctx, CH_PROG)
                .setSmallIcon(if (outgoing) android.R.drawable.stat_sys_upload else android.R.drawable.stat_sys_download)
                .setContentTitle(title)
                .setContentText(body)
                .setProgress(100, percent, indeterminate)
                .setContentIntent(openApp(ctx, SessionActivity::class.java, 13))
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .build()
        )
    }

    fun showDone(ctx: Context, outgoing: Boolean, title: String, body: String, openPath: String?) {
        val pi = if (openPath != null && File(openPath).exists()) {
            PendingIntent.getActivity(
                ctx, 14, Storage.viewIntent(ctx, File(openPath)),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        } else openApp(ctx, SessionActivity::class.java, 13)
        post(
            ctx, if (outgoing) ID_SEND_DONE else ID_RECV_DONE,
            NotificationCompat.Builder(ctx, CH_DONE)
                .setSmallIcon(if (outgoing) android.R.drawable.stat_sys_upload_done else android.R.drawable.stat_sys_download_done)
                .setContentTitle(title)
                .setContentText(body)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
        )
    }
}
