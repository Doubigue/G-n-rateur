package com.example.localshare

import android.content.Context
import android.content.pm.ApplicationInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import java.io.ByteArrayOutputStream
import java.io.File

class LocalApp(
    val name: String,
    val pkg: String,
    val version: String,
    val system: Boolean,
    val icon: ByteArray?
)

object AppsLister {

    @Suppress("DEPRECATION")
    fun list(ctx: Context): List<LocalApp> {
        val pm = ctx.packageManager
        return pm.getInstalledApplications(0).map { ai ->
            val system = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                    (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
            val ver = try {
                pm.getPackageInfo(ai.packageName, 0).versionName ?: ""
            } catch (_: Exception) {
                ""
            }
            LocalApp(
                ai.loadLabel(pm).toString(), ai.packageName, ver, system,
                try { iconPng(pm.getApplicationIcon(ai)) } catch (_: Exception) { null }
            )
        }.sortedBy { it.name.lowercase() }
    }

    fun iconPng(d: Drawable, size: Int = 64): ByteArray? = try {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        d.mutate().setBounds(0, 0, size, size)
        d.draw(Canvas(bmp))
        val bo = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, bo)
        bmp.recycle()
        bo.toByteArray()
    } catch (_: Throwable) {
        null
    }

    /** APK de base + éventuels splits (App Bundle), avec le nom sous lequel les envoyer. */
    fun apkFiles(ctx: Context, pkg: String): List<Pair<File, String>> {
        val pm = ctx.packageManager
        val ai = pm.getApplicationInfo(pkg, 0)
        val label = ai.loadLabel(pm).toString().replace(Regex("[\\\\/:*?\"<>|]"), "_")
        val out = mutableListOf(File(ai.sourceDir) to "$label.apk")
        ai.splitSourceDirs?.forEach { out += File(it) to "${label}_${File(it).name}" }
        return out
    }
}
