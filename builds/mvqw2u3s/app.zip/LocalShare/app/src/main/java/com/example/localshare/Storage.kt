package com.example.localshare

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.webkit.MimeTypeMap
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File

/** Stockage LocalShare : un dossier visible avec des sous-dossiers automatiques par type. */
object Storage {
    const val FOLDER = "LocalShare"
    const val VIDEO = "Vidéo"
    const val DOCUMENTS = "Documents"
    const val MUSIC = "Musique"
    const val APPLICATION = "Application"
    const val OTHER = "Autres"

    private val CATEGORIES = listOf(VIDEO, DOCUMENTS, MUSIC, APPLICATION, OTHER)

    val root: File get() = Environment.getExternalStorageDirectory()

    /** Android 11+ : MANAGE_EXTERNAL_STORAGE. Android 10- : READ/WRITE_EXTERNAL_STORAGE. */
    fun hasAccess(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_EXTERNAL_STORAGE) ==
                    PackageManager.PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                    PackageManager.PERMISSION_GRANTED
        }

    fun requestAccess(a: Activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                a.startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:${a.packageName}")
                    )
                )
            } catch (e: Exception) {
                a.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else {
            ActivityCompat.requestPermissions(
                a,
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE),
                100
            )
        }
    }

    /** <stockage>/LocalShare ; repli dans le dossier externe privé de l'appli si l'accès est refusé. */
    fun shareDir(ctx: Context): File {
        if (hasAccess(ctx)) {
            try {
                val d = File(root, FOLDER)
                if (d.isDirectory || d.mkdirs()) return d
            } catch (_: Exception) {
            }
        }
        val base = ctx.getExternalFilesDir(null) ?: ctx.filesDir
        return File(base, FOLDER).also { it.mkdirs() }
    }

    /** Crée les sous-dossiers de réception dès le premier démarrage. */
    fun ensureFolders(ctx: Context) {
        val rootDir = shareDir(ctx)
        CATEGORIES.forEach { File(rootDir, it).mkdirs() }
    }

    /** Choisit automatiquement le sous-dossier selon le type de fichier reçu. */
    fun categoryFor(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return when (ext) {
            "mp4", "mkv", "avi", "mov", "webm", "m4v", "3gp", "3g2", "ts", "mts", "m2ts" -> VIDEO
            "mp3", "wav", "flac", "ogg", "oga", "m4a", "aac", "opus", "wma" -> MUSIC
            "apk", "xapk", "apks" -> APPLICATION
            "pdf", "doc", "docx", "odt", "rtf", "txt", "csv",
            "xls", "xlsx", "ods", "ppt", "pptx", "odp",
            "epub", "md", "json", "xml" -> DOCUMENTS
            else -> OTHER
        }
    }

    fun categoryDir(ctx: Context, name: String): File {
        return File(shareDir(ctx), categoryFor(name)).also { it.mkdirs() }
    }

    fun mimeOf(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
    }

    fun viewIntent(ctx: Context, file: File): Intent {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
        return Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, mimeOf(file.name))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    /** « Ouvrir avec… » pour tous les formats (vidéo, audio, PDF, image, texte…). */
    fun open(ctx: Context, file: File) {
        try {
            ctx.startActivity(
                Intent.createChooser(viewIntent(ctx, file), "Ouvrir avec…").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {
        }
    }

    fun safeName(raw: String): String {
        val n = raw.replace('\\', '/').substringAfterLast('/')
            .replace(Regex("[<>:\"|?*\\x00-\\x1F]"), "_").trim()
        return if (n.isEmpty() || n == "." || n == "..") "fichier" else n
    }

    fun uniqueFile(dir: File, name: String): File {
        var f = File(dir, name)
        if (!f.exists() && !File(dir, "$name.part").exists()) return f
        val dot = name.lastIndexOf('.')
        val stem = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var i = 1
        while (f.exists() || File(dir, f.name + ".part").exists()) {
            f = File(dir, "$stem ($i)$ext")
            i++
        }
        return f
    }
}
