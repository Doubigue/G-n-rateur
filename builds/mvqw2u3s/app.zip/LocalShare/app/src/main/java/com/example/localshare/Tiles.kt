package com.example.localshare

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.annotation.DrawableRes
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.card.MaterialCardView

/** Une carte du tableau de bord : icône, titre, sous-titre, pastille verte si « actif ». */
data class Tile(
    @DrawableRes val icon: Int,
    val title: String,
    val sub: String,
    val active: Boolean = false,
    val danger: Boolean = false,
    val onClick: () -> Unit
)

class TileHolder(v: View) : RecyclerView.ViewHolder(v) {
    val card: MaterialCardView = v.findViewById(R.id.card)
    val icon: ImageView = v.findViewById(R.id.tileIcon)
    val title: TextView = v.findViewById(R.id.tileTitle)
    val sub: TextView = v.findViewById(R.id.tileSub)
    val dot: View = v.findViewById(R.id.tileDot)
}

class TileAdapter : RecyclerView.Adapter<TileHolder>() {
    private var items: List<Tile> = emptyList()

    fun submit(list: List<Tile>) {
        // Évite de redessiner (et d'interrompre un appui) quand seul le code des clics a changé.
        val same = list.size == items.size && list.indices.all {
            val a = list[it]; val b = items[it]
            a.icon == b.icon && a.title == b.title && a.sub == b.sub && a.active == b.active && a.danger == b.danger
        }
        items = list
        if (!same) notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        TileHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_tile, parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: TileHolder, position: Int) {
        val t = items[position]
        val ctx = h.itemView.context
        h.icon.setImageResource(t.icon)
        if (t.danger) h.icon.setColorFilter(ContextCompat.getColor(ctx, R.color.ls_err)) else h.icon.clearColorFilter()
        h.title.text = t.title
        h.sub.text = t.sub
        h.dot.visibility = if (t.active) View.VISIBLE else View.GONE
        h.card.strokeColor = ContextCompat.getColor(ctx, if (t.active) R.color.ls_accent else R.color.ls_line)
        h.card.setOnClickListener { t.onClick() }
    }
}

/** Grille de cartes : 2 colonnes sur téléphone, davantage sur grand écran. */
fun RecyclerView.setupTiles(adapter: TileAdapter) {
    val dp = resources.displayMetrics
    val cols = (dp.widthPixels / dp.density / 170f).toInt().coerceIn(2, 4)
    layoutManager = GridLayoutManager(context, cols)
    this.adapter = adapter
    itemAnimator = null
}

