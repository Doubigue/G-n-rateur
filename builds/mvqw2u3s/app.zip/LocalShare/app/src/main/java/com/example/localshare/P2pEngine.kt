package com.example.localshare

import android.Manifest
import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.wifi.WifiManager
import android.net.wifi.WpsInfo
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pManager
import android.net.wifi.p2p.nsd.WifiP2pDnsSdServiceInfo
import android.net.wifi.p2p.nsd.WifiP2pDnsSdServiceRequest
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import androidx.core.location.LocationManagerCompat
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject
import java.io.IOException
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors

enum class NearbyRole { NONE, HOST, CLIENT }
enum class PeerState { DISCOVERED, CONNECTING, CONNECTED }

data class Peer(val id: String, val name: String, val rid: String = "", val state: PeerState = PeerState.DISCOVERED)

/** Demande de connexion entrante : le code est identique sur les deux téléphones. */
data class PendingConnection(val name: String, val code: String)

data class P2pState(
    val deviceName: String = "Appareil",
    val peers: List<Peer> = emptyList(),
    val advertising: Boolean = false,
    val discovering: Boolean = false,
    val connectedId: String? = null,
    val connectedName: String = "",
    val status: String? = null,
    val statusNeedsSettings: Boolean = false,
    val info: String? = null,
    val pending: PendingConnection? = null,
    val outgoingCode: String? = null
) {
    val isConnected: Boolean get() = connectedId != null
}

/**
 * Découverte, connexion et échanges en Wi-Fi Direct uniquement (aucun Bluetooth).
 *
 *  - Visible + recherche automatiques (annonce DNS-SD Wi-Fi Direct, type _localshare._tcp).
 *  - Toucher un appareil lance l'invitation Wi-Fi Direct (bouton poussoir, sans mot de passe) ;
 *    l'autre téléphone l'accepte, puis LocalShare demande une confirmation avec un code à 4 chiffres
 *    identique des deux côtés.
 *  - Le groupe est créé même si le téléphone est déjà sur un Wi-Fi : le trafic est forcé sur le
 *    réseau Wi-Fi Direct, puis un lien TCP direct (port 8988) transporte tout.
 *
 * Tout l'état est modifié sur le thread principal. Les écritures réseau (sendXxxSync) sont bloquantes
 * et doivent être appelées HORS du thread principal.
 */
@SuppressLint("MissingPermission")
class P2pEngine(private val ctx: Context) {

    companion object {
        const val SERVICE_TYPE = "_localshare._tcp"
        private const val WIFI_OFF_MSG = "Wi-Fi désactivé : activez-le pour utiliser le Wi-Fi Direct."
    }

    val state = MutableStateFlow(P2pState())

    /** Messages JSON applicatifs (text, file, fs_*, ls, get, apps…) — appelés sur le thread du lien. */
    val jsonListeners = CopyOnWriteArrayList<(JSONObject) -> Unit>()
    @Volatile var chunkHandler: ((Int, ByteArray) -> Unit)? = null
    @Volatile var endHandler: ((Int) -> Unit)? = null
    @Volatile var cancelHandler: ((Int) -> Unit)? = null

    /** Appelé (thread principal) quand la session se termine. */
    val sessionEnded = CopyOnWriteArrayList<() -> Unit>()

    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newCachedThreadPool()
    private val ctl = Executors.newSingleThreadExecutor()

    private var manager: WifiP2pManager? = null
    private var channel: WifiP2pManager.Channel? = null
    private var receiver: BroadcastReceiver? = null
    private var boundToP2p = false

    // --- état (thread principal)
    private val peers = LinkedHashMap<String, Peer>()
    private val seen = HashMap<String, Long>()
    private var role = NearbyRole.NONE
    private var advertising = false
    private var discovering = false
    private var wantDiscover = true
    private var wantVisible = true
    @Volatile private var connectedId: String? = null
    private var deviceName = "Appareil"
    private var status: String? = null
    private var statusNeedsSettings = false
    private var info: String? = null
    private var pending: PendingConnection? = null
    private var outgoingCode: String? = null
    private var rid: String? = null
    private var starting = false
    private var linking = false
    private var p2pOn = true
    private var hasP2p = true
    private var refreshing = false
    private var myNonce = ""
    private var peerName: String? = null
    private var code: String? = null

    @Volatile private var ready = false
    @Volatile private var initiated: Peer? = null
    @Volatile private var link: DirectLink? = null
    @Volatile private var serverSocket: ServerSocket? = null

    val isConnected: Boolean get() = connectedId != null

    private val connectTimeout = Runnable {
        val p = initiated
        if (!isConnected && p != null) failConnect("${p.name} n’a pas répondu.")
    }
    private val pendingTimeout = Runnable { if (pending != null) rejectPending() }
    private val restartRunnable = Runnable { start() }
    private val refreshRunnable = object : Runnable {
        override fun run() {
            refreshDiscovery()
            main.postDelayed(this, 20_000)
        }
    }

    private class Act(val done: (Boolean, Int) -> Unit) : WifiP2pManager.ActionListener {
        override fun onSuccess() = done(true, 0)
        override fun onFailure(reason: Int) = done(false, reason)
    }

    // ================================================================= init
    fun init() {
        val custom = ctx.getSharedPreferences("localshare", Context.MODE_PRIVATE).getString("device_name", null)
        deviceName = if (!custom.isNullOrBlank()) custom
        else "${Build.MANUFACTURER} ${Build.MODEL}".replace("#", "").replaceFirstChar { it.uppercase() }
        hasP2p = ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_WIFI_DIRECT)
        p2pOn = wifi().isWifiEnabled
        publish()
    }

    private fun wifi() = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

    fun renameDevice(raw: String) {
        var name = raw.replace("#", "").trim()
        if (name.length > 30) name = name.substring(0, 30)
        if (name.isEmpty()) return
        deviceName = name
        ctx.getSharedPreferences("localshare", Context.MODE_PRIVATE).edit().putString("device_name", name).apply()
        publish()
        if (!isConnected) restart()
    }

    // ============================================================ permissions
    fun requiredPermissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.NEARBY_WIFI_DEVICES)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

    fun hasPermission(): Boolean = requiredPermissions().all {
        ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun permissionLabel() = if (Build.VERSION.SDK_INT >= 33) "Appareils Wi-Fi à proximité" else "Localisation"

    private fun locationEnabled(): Boolean =
        LocationManagerCompat.isLocationEnabled(ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager)

    private fun setStatus(msg: String?, settings: Boolean = false) {
        status = msg
        statusNeedsSettings = settings
        publish()
    }

    private fun explain(reason: Int): String = when (reason) {
        WifiP2pManager.P2P_UNSUPPORTED -> "Ce téléphone ne gère pas le Wi-Fi Direct."
        WifiP2pManager.BUSY -> "Wi-Fi Direct occupé. Patientez quelques secondes puis touchez « Réessayer »."
        else -> "Erreur Wi-Fi Direct (code $reason). Touchez « Réessayer »."
    }

    /** Message à afficher si le Wi-Fi Direct ne peut pas démarrer (null = tout est prêt). */
    private fun blockingProblem(): Pair<String, Boolean>? {
        if (!hasP2p) return "Ce téléphone ne gère pas le Wi-Fi Direct." to false
        if (!hasPermission()) {
            return "LocalShare a besoin de la permission « ${permissionLabel()} » pour trouver les appareils " +
                    "en Wi-Fi Direct. Autorisez-la dans les réglages de l’appli." to true
        }
        if (Build.VERSION.SDK_INT < 33 && !locationEnabled()) {
            return "Activez la localisation (GPS) dans les réglages rapides : Android l’exige pour le " +
                    "Wi-Fi Direct (aucune position n’est utilisée). Puis touchez « Réessayer »." to false
        }
        p2pOn = wifi().isWifiEnabled
        if (!p2pOn) {
            return "Activez le Wi-Fi (inutile d’être connecté à un réseau) : le Wi-Fi Direct en a besoin. " +
                    "Puis touchez « Réessayer »." to false
        }
        return null
    }

    // ============================================== démarrage automatique
    fun start() {
        if (starting || isConnected || linking) return
        starting = true
        try {
            val problem = blockingProblem()
            if (problem != null) {
                setStatus(problem.first, problem.second)
                return
            }
            status = null
            statusNeedsSettings = false
            if (!ensure()) {
                setStatus("Wi-Fi Direct indisponible sur ce téléphone.")
                return
            }
            if (wantVisible && !advertising) advertise()
            if (wantDiscover && !discovering) discover()
            P2pService.start(ctx)
        } finally {
            starting = false
            publish()
        }
    }

    fun restart() {
        if (isConnected || linking) return
        manager?.let { m -> channel?.let { ch -> m.clearLocalServices(ch, null) } }
        stopP2pDiscovery()
        advertising = false
        discovering = false
        wantDiscover = true
        peers.entries.removeIf { it.value.state != PeerState.CONNECTED }
        publish()
        start()
    }

    private fun scheduleRestart() {
        main.removeCallbacks(restartRunnable)
        main.postDelayed(restartRunnable, 1200)
    }

    private fun ensure(): Boolean {
        if (manager == null) manager = ctx.getSystemService(Context.WIFI_P2P_SERVICE) as? WifiP2pManager
        val m = manager ?: return false
        if (channel == null) {
            channel = m.initialize(ctx, Looper.getMainLooper(), WifiP2pManager.ChannelListener { channel = null })
        }
        registerReceiverOnce()
        return channel != null
    }

    private fun registerReceiverOnce() {
        if (receiver != null) return
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                when (i.action) {
                    WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION -> onP2pState(
                        i.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE, -1) == WifiP2pManager.WIFI_P2P_STATE_ENABLED
                    )
                    WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION -> requestInfo()
                }
            }
        }
        receiver = r
        val f = IntentFilter().apply {
            addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
            addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
        }
        ContextCompat.registerReceiver(ctx, r, f, ContextCompat.RECEIVER_EXPORTED)
    }

    private fun onP2pState(enabled: Boolean) {
        p2pOn = enabled
        if (!enabled) {
            advertising = false
            discovering = false
            setStatus(WIFI_OFF_MSG)
        } else if (status == WIFI_OFF_MSG) {
            status = null
            scheduleRestart()
        }
        publish()
    }

    private fun requestInfo() {
        val m = manager ?: return
        val ch = channel ?: return
        try {
            m.requestConnectionInfo(ch) { i ->
                if (i != null && i.groupFormed && i.groupOwnerAddress != null) {
                    onGroupFormed(i.isGroupOwner, i.groupOwnerAddress.hostAddress)
                } else if (link != null || connectedId != null) {
                    onLinkClosed()
                }
            }
        } catch (_: SecurityException) {
        }
    }

    // ================================================== annonce (visible)
    private fun advertise() {
        val m = manager ?: return
        val ch = channel ?: return
        val r = randomHex(4)
        rid = r
        val txt = mapOf("n" to deviceName, "r" to r, "v" to "1")
        val si = WifiP2pDnsSdServiceInfo.newInstance("ls$r", SERVICE_TYPE, txt)
        m.clearLocalServices(ch, Act { _, _ ->
            m.addLocalService(ch, si, Act { ok, reason ->
                advertising = ok
                if (!ok) {
                    rid = null
                    setStatus(explain(reason))
                }
                publish()
            })
        })
    }

    fun setVisible(v: Boolean) {
        wantVisible = v
        if (v) {
            if (blockingProblem() == null && ensure()) advertise()
        } else {
            manager?.let { m -> channel?.let { ch -> m.clearLocalServices(ch, null) } }
            advertising = false
            rid = null
        }
        publish()
    }

    // =================================================== recherche
    private val serviceListener = WifiP2pManager.DnsSdServiceResponseListener { instanceName, regType, device ->
        if (regType == null || !regType.startsWith(SERVICE_TYPE) || device == null) return@DnsSdServiceResponseListener
        val r = if (instanceName != null && instanceName.startsWith("ls")) instanceName.substring(2) else ""
        onFound(device.deviceAddress ?: "", "", r)
    }

    private val txtListener = WifiP2pManager.DnsSdTxtRecordListener { _, txt, device ->
        if (txt == null || device == null || !txt.containsKey("r")) return@DnsSdTxtRecordListener
        onFound(device.deviceAddress ?: "", txt["n"] ?: "", txt["r"] ?: "")
    }

    private fun discover() {
        val m = manager ?: return
        val ch = channel ?: return
        m.setDnsSdResponseListeners(ch, serviceListener, txtListener)
        m.clearServiceRequests(ch, Act { _, _ ->
            m.addServiceRequest(ch, WifiP2pDnsSdServiceRequest.newInstance(), Act { ok2, r2 ->
                if (!ok2) {
                    discovering = false
                    setStatus(explain(r2))
                    return@Act
                }
                // discoverPeers d'abord : sur beaucoup de téléphones, discoverServices seul ne trouve rien.
                m.discoverPeers(ch, Act { _, _ ->
                    m.discoverServices(ch, Act { ok4, r4 ->
                        if (ok4 || r4 == WifiP2pManager.BUSY) {
                            discovering = true
                        } else {
                            discovering = false
                            setStatus(explain(r4))
                        }
                        publish()
                    })
                })
            })
        })
        if (!refreshing) {
            refreshing = true
            main.postDelayed(refreshRunnable, 20_000)
        }
    }

    /** Android arrête la découverte au bout de ~2 min : on la relance et on retire les appareils muets. */
    private fun refreshDiscovery() {
        if (isConnected || linking || !discovering) return
        val now = System.currentTimeMillis()
        peers.entries.removeIf { (id, p) ->
            p.state == PeerState.DISCOVERED && now - (seen[id] ?: now) > 75_000
        }
        publish()
        discover()
    }

    private fun stopP2pDiscovery() {
        val m = manager ?: return
        val ch = channel ?: return
        m.clearServiceRequests(ch, null)
        m.stopPeerDiscovery(ch, null)
    }

    private fun onFound(addr: String, rawName: String, rid: String) {
        if (isConnected || linking || addr.isEmpty()) return
        val name = rawName.replace("#", "").trim()
        val ex = peers[addr]
        if (ex == null) {
            peers[addr] = Peer(addr, name.ifEmpty { "Appareil" }, rid)
        } else if (ex.state == PeerState.DISCOVERED && name.isNotEmpty() && ex.name != name) {
            peers[addr] = Peer(addr, name, rid)
        }
        seen[addr] = System.currentTimeMillis()
        publish()
    }

    // ===================================================== connexion
    fun connectTo(peerId: String) {
        val peer = peers[peerId] ?: return
        if (peer.state == PeerState.CONNECTING || isConnected || linking) return
        val m = manager ?: return
        val ch = channel ?: return

        val p = peer.copy(state = PeerState.CONNECTING)
        peers[peerId] = p
        initiated = p
        status = null
        info = "Invitation Wi-Fi Direct envoyée à ${peer.name}… L’autre téléphone doit toucher « Accepter »."
        publish()

        main.removeCallbacks(connectTimeout)
        main.postDelayed(connectTimeout, 60_000)

        discovering = false
        stopP2pDiscovery()
        val cfg = WifiP2pConfig().apply {
            deviceAddress = peerId
            @Suppress("DEPRECATION")
            wps.setup = WpsInfo.PBC // bouton poussoir : aucun mot de passe ni PIN
        }
        m.connect(ch, cfg, Act { ok, reason ->
            if (ok) role = NearbyRole.CLIENT else failConnect(explain(reason))
        })
    }

    private fun failConnect(msg: String) {
        cleanupSession()
        disconnectP2p()
        setStatus(msg)
        scheduleRestart()
    }

    /** Groupe Wi-Fi Direct formé : le propriétaire ouvre un serveur TCP, l'autre s'y connecte. */
    private fun onGroupFormed(owner: Boolean, addr: String?) {
        if (linking || link != null || isConnected) return
        linking = true
        discovering = false
        stopP2pDiscovery()
        publish()
        io.execute {
            try {
                bindToP2pWithRetry() // même connecté à un Wi-Fi / données mobiles : trafic forcé sur le Wi-Fi Direct
                val sock: Socket = if (owner) {
                    acceptOne()
                } else {
                    if (addr == null) throw IOException("adresse du groupe inconnue")
                    connectWithRetry(addr)
                }
                attach(sock)
            } catch (e: Exception) {
                main.post { if (!isConnected) failConnect("Connexion Wi-Fi Direct impossible. Réessayez des deux côtés.") }
            }
        }
    }

    private fun acceptOne(): Socket {
        val ss = ServerSocket()
        ss.reuseAddress = true
        ss.bind(InetSocketAddress(Protocol.PORT))
        ss.soTimeout = 50_000
        serverSocket = ss
        try {
            return ss.accept()
        } finally {
            try { ss.close() } catch (_: IOException) { }
            serverSocket = null
        }
    }

    private fun connectWithRetry(addr: String): Socket {
        var last: Exception? = null
        repeat(25) {
            try {
                val s = Socket()
                s.connect(InetSocketAddress(addr, Protocol.PORT), 4000)
                return s
            } catch (e: Exception) {
                last = e
                Thread.sleep(600)
            }
        }
        throw last ?: IOException("connexion impossible")
    }

    /** Appelé hors thread principal. */
    private fun attach(sock: Socket) {
        try { sock.tcpNoDelay = true } catch (_: Exception) { }
        val nonce = randomHex(16)
        val l = DirectLink(
            sock,
            onJson = ::onLinkJson,
            onChunk = { id, d -> chunkHandler?.invoke(id, d) },
            onEnd = { id -> endHandler?.invoke(id) },
            onCancel = { id -> cancelHandler?.invoke(id) },
            onClosed = { main.post { onLinkClosed() } }
        )
        link = l
        main.post {
            myNonce = nonce
            ready = false
            peerName = null
            code = null
        }
        l.start()
        try {
            l.sendJson(JSONObject().put("t", "hello").put("name", deviceName).put("nonce", nonce).put("v", 1))
        } catch (_: IOException) {
        }
    }

    /** Thread du lien. Les messages de connexion passent par le thread principal, le reste est transmis tel quel. */
    private fun onLinkJson(m: JSONObject) {
        when (m.optString("t")) {
            "hello" -> main.post { onHello(m) }
            "accept" -> {
                if (initiated != null && !ready) {
                    ready = true // immédiat : les messages suivants ne doivent pas être perdus
                    main.post { markConnected(peerName ?: initiated?.name ?: "Appareil") }
                }
            }
            "bye" -> main.post { onLinkClosed() }
            "reject" -> main.post { failConnect("${peerName ?: "L’autre appareil"} a refusé la connexion.") }
            else -> if (ready) {
                for (l in jsonListeners) {
                    try { l(m) } catch (_: Exception) { }
                }
            }
        }
    }

    private fun onHello(m: JSONObject) {
        val nonce = m.optString("nonce")
        if (nonce.isEmpty() || peerName != null) return
        val raw = m.optString("name").replace("#", "").trim()
        val name = raw.ifEmpty { "Appareil" }
        peerName = name

        val pair = listOf(myNonce, nonce).sorted()
        val d = MessageDigest.getInstance("SHA-256").digest(pair.joinToString(":").toByteArray())
        val num = ((d[0].toInt() and 0xFF) shl 8) or (d[1].toInt() and 0xFF)
        val c = (num % 10000).toString().padStart(4, '0')
        code = c

        if (initiated == null) {
            // Demande entrante : à valider manuellement.
            role = NearbyRole.HOST
            peers["link"] = Peer("link", name, state = PeerState.CONNECTING)
            pending = PendingConnection(name, c)
            Notifier.showConnectionRequest(ctx, name, c)
            main.removeCallbacks(connectTimeout)
            main.removeCallbacks(pendingTimeout)
            main.postDelayed(pendingTimeout, 60_000)
        } else {
            outgoingCode = c
            info = "En attente de l’accord de $name…"
        }
        publish()
    }

    fun acceptPending() {
        val pc = pending ?: return
        pending = null
        main.removeCallbacks(pendingTimeout)
        Notifier.cancel(ctx, Notifier.ID_REQUEST)
        markConnected(pc.name)
        ctl.execute { try { link?.sendJson(JSONObject().put("t", "accept")) } catch (_: Exception) { } }
    }

    fun rejectPending() {
        if (pending == null) return
        pending = null
        main.removeCallbacks(pendingTimeout)
        Notifier.cancel(ctx, Notifier.ID_REQUEST)
        val l = link
        ctl.execute {
            try { l?.sendJson(JSONObject().put("t", "reject")) } catch (_: Exception) { }
            main.post {
                cleanupSession()
                disconnectP2p()
                scheduleRestart()
            }
        }
    }

    private fun markConnected(name: String) {
        main.removeCallbacks(connectTimeout)
        main.removeCallbacks(pendingTimeout)
        ready = true
        linking = false
        val id = initiated?.id ?: "link"
        peers.clear()
        peers[id] = Peer(id, name, state = PeerState.CONNECTED)
        connectedId = id
        pending = null
        outgoingCode = null
        info = null
        status = null
        statusNeedsSettings = false
        advertising = false
        discovering = false
        rid = null
        manager?.let { m -> channel?.let { ch -> m.clearLocalServices(ch, null) } }
        publish()
    }

    private fun onLinkClosed() {
        val wasConnected = connectedId != null
        val wasLinking = initiated != null || link != null
        if (!wasConnected && !wasLinking) return
        cleanupSession()
        disconnectP2p()
        scheduleRestart()
        publish()
    }

    private fun cleanupSession() {
        main.removeCallbacks(connectTimeout)
        main.removeCallbacks(pendingTimeout)
        try { serverSocket?.close() } catch (_: IOException) { }
        serverSocket = null
        val l = link
        val wasLinked = l != null || connectedId != null
        link = null
        ready = false
        linking = false
        initiated = null
        pending = null
        outgoingCode = null
        connectedId = null
        role = NearbyRole.NONE
        info = null
        advertising = false
        discovering = false
        rid = null
        peerName = null
        peers.clear()
        Notifier.cancel(ctx, Notifier.ID_REQUEST)
        l?.close() // état déjà remis à zéro : onLinkClosed ne fait donc rien
        if (wasLinked) {
            for (s in sessionEnded) {
                try { s() } catch (_: Exception) { }
            }
        }
        publish()
    }

    fun disconnect() {
        val l = link
        ctl.execute {
            try { l?.sendJson(JSONObject().put("t", "bye")) } catch (_: Exception) { }
            main.post {
                cleanupSession()
                disconnectP2p()
                scheduleRestart()
            }
        }
    }

    /** Arrêt complet (« Quitter »). */
    fun shutdown() {
        main.removeCallbacks(restartRunnable)
        main.removeCallbacks(refreshRunnable)
        refreshing = false
        cleanupSession()
        manager?.let { m -> channel?.let { ch -> m.clearLocalServices(ch, null) } }
        stopP2pDiscovery()
        disconnectP2p()
        peers.clear()
        publish()
    }

    private fun disconnectP2p() {
        val m = manager
        val ch = channel
        if (m != null && ch != null) {
            m.cancelConnect(ch, null)
            m.removeGroup(ch, null)
        }
        unbindNetwork()
    }

    // ================================================ trafic sur le Wi-Fi Direct
    @Suppress("DEPRECATION")
    private fun bindToP2p(): Boolean {
        return try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            for (n in cm.allNetworks) {
                val name = cm.getLinkProperties(n)?.interfaceName
                if (name != null && name.contains("p2p")) {
                    boundToP2p = cm.bindProcessToNetwork(n)
                    return boundToP2p
                }
            }
            false
        } catch (_: Throwable) {
            false
        }
    }

    private fun bindToP2pWithRetry() {
        repeat(6) {
            if (bindToP2p()) return
            Thread.sleep(300)
        }
    }

    private fun unbindNetwork() {
        try {
            if (boundToP2p) {
                (ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).bindProcessToNetwork(null)
            }
        } catch (_: Throwable) {
        }
        boundToP2p = false
    }

    // ===================================================== envoi (hors thread principal)
    @Throws(IOException::class)
    private fun activeLink(): DirectLink {
        val l = link
        if (!ready || l == null || l.closed) throw IOException("Pas de connexion")
        return l
    }

    @Throws(IOException::class)
    fun sendJsonSync(m: JSONObject) = activeLink().sendJson(m)

    @Throws(IOException::class)
    fun sendChunkSync(id: Int, buf: ByteArray, len: Int) = activeLink().sendChunk(id, buf, len)

    @Throws(IOException::class)
    fun sendEndSync(id: Int) = activeLink().sendEnd(id)

    @Throws(IOException::class)
    fun sendCancelSync(id: Int) = activeLink().sendCancel(id)

    /** Envoi asynchrone d'un message de contrôle (utilisable depuis le thread principal). */
    fun send(m: JSONObject) {
        ctl.execute { try { sendJsonSync(m) } catch (_: Exception) { } }
    }

    fun sendCancel(id: Int) {
        ctl.execute { try { sendCancelSync(id) } catch (_: Exception) { } }
    }

    // ===================================================== utilitaires
    private fun publish() {
        val cn = peers[connectedId]?.name ?: peerName ?: "Appareil"
        state.value = P2pState(
            deviceName, peers.values.toList(), advertising, discovering, connectedId,
            if (connectedId != null) cn else "", status, statusNeedsSettings, info, pending, outgoingCode
        )
    }

    private fun randomHex(n: Int): String {
        val r = SecureRandom()
        return buildString { repeat(n) { append(r.nextInt(16).toString(16)) } }
    }
}
