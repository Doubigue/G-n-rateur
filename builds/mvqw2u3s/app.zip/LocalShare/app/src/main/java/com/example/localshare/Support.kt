package com.example.localshare

import android.graphics.Bitmap
import android.graphics.Color
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import java.net.Inet4Address
import java.net.NetworkInterface
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** État du serveur web (accès par navigateur), partagé entre ShareService et WebServerActivity. */
data class ServerStatus(
    val running: Boolean = false,
    val port: Int = 8080,
    val token: String = "",
    val error: String? = null
)

object ServerState {
    val status = MutableStateFlow(ServerStatus())
}

object NetUtils {
    private data class Cand(val name: String, val ip: String, val prio: Int)

    private fun scan(): List<Cand> {
        val out = mutableListOf<Cand>()
        try {
            for (nif in NetworkInterface.getNetworkInterfaces()?.toList().orEmpty()) {
                if (!nif.isUp || nif.isLoopback) continue
                val name = nif.name.lowercase()
                if (name.startsWith("rmnet") || name.startsWith("ccmni") ||
                    name.startsWith("tun") || name.startsWith("dummy") || name.startsWith("v4-")
                ) continue
                for (addr in nif.inetAddresses) {
                    if (addr is Inet4Address && !addr.isLoopbackAddress && addr.isSiteLocalAddress) {
                        val prio = when {
                            name.startsWith("wlan") || name.startsWith("swlan") || name.startsWith("ap") -> 0
                            name.startsWith("eth") -> 1
                            else -> 2
                        }
                        out += Cand(name, addr.hostAddress!!, prio)
                    }
                }
            }
        } catch (_: Exception) {
        }
        return out
    }

    /** IPv4 locale utilisable par un autre appareil : Wi-Fi client, point d'accès, Ethernet. */
    fun localIp(): String? = scan().minByOrNull { it.prio }?.ip

    /**
     * IPv4 du point d'accès (hotspot) de ce téléphone : interface « ap0 », « swlan0 » ou une « wlanN » autre que wlan0
     * (hotspot système ou hotspot local créé par l'appli). Null si aucun point d'accès n'est actif.
     */
    fun hotspotIp(): String? = scan().firstOrNull {
        it.name.startsWith("ap") || it.name.startsWith("swlan") || (it.name.startsWith("wlan") && it.name != "wlan0")
    }?.ip

    /** Adresse à communiquer pour le serveur web : le hotspot s'il est actif, sinon le réseau Wi-Fi. */
    fun shareIp(): String? = hotspotIp() ?: localIp()
}

/** QR Codes (adresse web, connexion Wi-Fi). */
object Qr {
    suspend fun make(text: String, size: Int = 900): Bitmap = withContext(Dispatchers.Default) {
        val hints = mapOf<EncodeHintType, Any>(
            EncodeHintType.MARGIN to 1,
            EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M,
            EncodeHintType.CHARACTER_SET to "UTF-8"
        )
        val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size, hints)
        val w = m.width
        val h = m.height
        val px = IntArray(w * h)
        for (y in 0 until h) for (x in 0 until w) px[y * w + x] = if (m.get(x, y)) Color.BLACK else Color.WHITE
        Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    /** Format standard reconnu par les appareils photo : scanner = rejoindre le Wi-Fi. */
    fun wifi(ssid: String, password: String): String {
        fun esc(v: String) = v.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace(":", "\\:").replace("\"", "\\\"")
        return if (password.isEmpty()) "WIFI:T:nopass;S:${esc(ssid)};;" else "WIFI:T:WPA;S:${esc(ssid)};P:${esc(password)};;"
    }
}

/** Formats d'affichage et utilitaires de date (filtre par jour). */
object Fmt {
    fun bytes(n: Long): String = when {
        n < 1024 -> "$n o"
        n < 1024L * 1024 -> String.format(Locale.FRANCE, "%.1f Ko", n / 1024.0)
        n < 1024L * 1024 * 1024 -> String.format(Locale.FRANCE, "%.1f Mo", n / 1024.0 / 1024.0)
        else -> String.format(Locale.FRANCE, "%.2f Go", n / 1024.0 / 1024.0 / 1024.0)
    }

    fun date(ms: Long): String = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE).format(Date(ms))

    fun day(ms: Long): String = SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE).format(Date(ms))

    fun sameDay(a: Long, b: Long): Boolean {
        val x = Calendar.getInstance().apply { timeInMillis = a }
        val y = Calendar.getInstance().apply { timeInMillis = b }
        return x.get(Calendar.YEAR) == y.get(Calendar.YEAR) &&
                x.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR)
    }

    fun startOfDay(offsetDays: Int = 0): Long = Calendar.getInstance().apply {
        add(Calendar.DAY_OF_YEAR, offsetDays)
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    fun displayPath(path: String): String = path.replaceFirst("/storage/emulated/0", "Stockage interne")
}
