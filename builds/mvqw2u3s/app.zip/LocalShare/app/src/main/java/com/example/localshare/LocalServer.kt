package com.example.localshare

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.SystemClock
import android.util.LruCache
import android.webkit.MimeTypeMap
import fi.iki.elonen.NanoHTTPD
import fi.iki.elonen.NanoHTTPD.IHTTPSession
import fi.iki.elonen.NanoHTTPD.Method
import fi.iki.elonen.NanoHTTPD.Response
import fi.iki.elonen.NanoHTTPD.Response.Status
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedOutputStream
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.PipedInputStream
import java.io.PipedOutputStream
import java.net.URLEncoder
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Serveur HTTP embarqué.
 *
 * Routes (toutes protégées par le jeton de session, voir [route]) :
 *   GET  /                      -> assets/index.html
 *   GET  /static/<fichier>      -> assets/<fichier>
 *   GET  /api/info              -> infos appareil + stockage
 *   GET  /api/list?path=        -> contenu d'un dossier
 *   GET  /api/file?path=&dl=1   -> lecture / téléchargement (Range supporté : streaming vidéo/audio)
 *   POST /api/upload?path=&name -> corps brut = contenu du fichier (écrit en flux, sans copie temporaire)
 *   GET  /api/apps              -> applications installées
 *   GET  /api/icon?pkg=         -> icône PNG
 *   GET  /api/apk?pkg=          -> APK (ou .apks zip si l'app est découpée en splits)
 */
class LocalServer(
    private val ctx: Context,
    port: Int,
    private val token: String
) : NanoHTTPD(port) {

    private val root: File = Environment.getExternalStorageDirectory().canonicalFile
    private val pm: PackageManager = ctx.packageManager

    private val iconCache = object : LruCache<String, ByteArray>(8 * 1024 * 1024) {
        override fun sizeOf(key: String, value: ByteArray) = value.size
    }

    @Volatile
    private var appsCache: Pair<Long, JSONArray>? = null

    // ---------------------------------------------------------------- routage

    override fun serve(session: IHTTPSession): Response =
        try {
            route(session)
        } catch (e: Exception) {
            err(Status.INTERNAL_ERROR, e.message ?: "Erreur interne")
        }

    private fun tokenOk(value: String?): Boolean =
        value != null && MessageDigest.isEqual(value.toByteArray(), token.toByteArray())

    private fun route(s: IHTTPSession): Response {
        val uri = s.uri
        val queryToken = s.parameters["t"]?.firstOrNull()
        val cookieToken = s.headers["cookie"]
            ?.split(";")?.map { it.trim() }
            ?.firstOrNull { it.startsWith("ls_token=") }
            ?.substringAfter("=")

        if (!tokenOk(queryToken) && !tokenOk(cookieToken)) {
            return newFixedLengthResponse(Status.FORBIDDEN, "text/html; charset=utf-8", DENIED_HTML)
        }

        val resp = when {
            uri == "/" || uri == "/index.html" -> asset("index.html", "text/html; charset=utf-8")
            uri.startsWith("/static/") -> {
                val n = uri.removePrefix("/static/")
                asset(n, mimeOf(n))
            }
            uri == "/api/info" -> info()
            uri == "/api/list" -> list(s)
            uri == "/api/file" -> file(s)
            uri == "/api/upload" && s.method == Method.POST -> upload(s)
            uri == "/api/apps" -> json(Status.OK, loadApps())
            uri == "/api/icon" -> icon(s)
            uri == "/api/apk" -> apk(s)
            else -> err(Status.NOT_FOUND, "Introuvable")
        }

        // Première visite via le QR Code : on pose un cookie, l'URL avec ?t= n'est plus nécessaire.
        if (tokenOk(queryToken) && !tokenOk(cookieToken)) {
            resp.addHeader("Set-Cookie", "ls_token=$token; Path=/; SameSite=Lax; HttpOnly")
        }
        return resp
    }

    // ---------------------------------------------------------------- helpers

    private fun json(status: Status, body: Any): Response =
        newFixedLengthResponse(status, "application/json; charset=utf-8", body.toString())

    private fun err(status: Status, msg: String): Response =
        json(status, JSONObject().put("error", msg))

    private fun param(s: IHTTPSession, name: String): String? = s.parameters[name]?.firstOrNull()

    /** Résout un chemin relatif au stockage et refuse toute sortie de la racine (../, symlink). */
    private fun resolve(rel: String?): File? {
        val f = File(root, (rel ?: "").trimStart('/')).canonicalFile
        return if (f.path == root.path || f.path.startsWith(root.path + File.separator)) f else null
    }

    private fun relPath(f: File): String =
        if (f.path == root.path) "/" else "/" + f.path.removePrefix(root.path).trimStart('/')

    private fun mimeOf(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: when (ext) {
            "mkv" -> "video/x-matroska"
            "js" -> "text/javascript"
            "css" -> "text/css"
            "json" -> "application/json"
            "md", "log", "txt" -> "text/plain"
            "apk" -> "application/vnd.android.package-archive"
            else -> "application/octet-stream"
        }
    }

    private fun dispo(name: String, inline: Boolean): String {
        val ascii = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val enc = URLEncoder.encode(name, "UTF-8").replace("+", "%20")
        return "${if (inline) "inline" else "attachment"}; filename=\"$ascii\"; filename*=UTF-8''$enc"
    }

    private fun asset(name: String, mime: String): Response {
        if (name.contains("..")) return err(Status.NOT_FOUND, "Introuvable")
        val bytes = try {
            ctx.assets.open(name).use { it.readBytes() }
        } catch (e: IOException) {
            return err(Status.NOT_FOUND, "Introuvable")
        }
        return newFixedLengthResponse(Status.OK, mime, ByteArrayInputStream(bytes), bytes.size.toLong())
            .apply { addHeader("Cache-Control", "no-cache") }
    }

    // ---------------------------------------------------------------- API fichiers

    private fun info(): Response {
        val st = StatFs(root.path)
        return json(
            Status.OK, JSONObject()
                .put("device", "${Build.MANUFACTURER} ${Build.MODEL}")
                .put("free", st.availableBytes)
                .put("total", st.totalBytes)
        )
    }

    private fun list(s: IHTTPSession): Response {
        val dir = resolve(param(s, "path")) ?: return err(Status.FORBIDDEN, "Chemin interdit")
        if (!dir.isDirectory) return err(Status.NOT_FOUND, "Dossier introuvable")
        val entries = JSONArray()
        (dir.listFiles() ?: emptyArray())
            .sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
            .forEach { f ->
                entries.put(
                    JSONObject()
                        .put("name", f.name)
                        .put("dir", f.isDirectory)
                        .put("size", if (f.isDirectory) 0 else f.length())
                        .put("mtime", f.lastModified())
                        .put("mime", if (f.isDirectory) "" else mimeOf(f.name))
                )
            }
        return json(Status.OK, JSONObject().put("path", relPath(dir)).put("entries", entries))
    }

    private fun file(s: IHTTPSession): Response {
        val f = resolve(param(s, "path")) ?: return err(Status.FORBIDDEN, "Chemin interdit")
        if (!f.isFile || !f.canRead()) return err(Status.NOT_FOUND, "Fichier introuvable")
        val download = param(s, "dl") == "1"
        return serveFile(f, mimeOf(f.name), s.headers["range"], if (download) f.name else null)
    }

    /** Sert un fichier avec support des requêtes Range (indispensable pour lire/seek une vidéo). */
    private fun serveFile(f: File, mime: String, range: String?, downloadName: String?): Response {
        val len = f.length()
        var start = 0L
        var end = len - 1
        var partial = false

        if (range != null && range.startsWith("bytes=")) {
            val spec = range.removePrefix("bytes=").substringBefore(",").trim()
            val a = spec.substringBefore("-")
            val b = spec.substringAfter("-", "")
            try {
                if (a.isEmpty()) {
                    start = maxOf(0L, len - b.toLong())
                } else {
                    start = a.toLong()
                    if (b.isNotEmpty()) end = minOf(b.toLong(), len - 1)
                }
                partial = true
            } catch (e: NumberFormatException) {
                start = 0; end = len - 1; partial = false
            }
            if (partial && (start > end || start >= len)) {
                return newFixedLengthResponse(Status.RANGE_NOT_SATISFIABLE, "text/plain", "")
                    .apply { addHeader("Content-Range", "bytes */$len") }
            }
        }

        val count = end - start + 1
        val fis = FileInputStream(f)
        if (start > 0) fis.channel.position(start)

        val resp = newFixedLengthResponse(
            if (partial) Status.PARTIAL_CONTENT else Status.OK, mime, fis, count
        )
        resp.setGzipEncoding(false)
        resp.addHeader("Accept-Ranges", "bytes")
        if (partial) resp.addHeader("Content-Range", "bytes $start-$end/$len")
        resp.addHeader("Content-Disposition", dispo(downloadName ?: f.name, inline = downloadName == null))
        return resp
    }

    /**
     * Upload : le corps de la requête EST le fichier (pas de multipart).
     * On lit exactement Content-Length octets depuis la socket et on écrit directement
     * dans un fichier .part, renommé à la fin -> débit maximal, aucune copie temporaire.
     */
    private fun upload(s: IHTTPSession): Response {
        val dir = resolve(param(s, "path")) ?: return err(Status.FORBIDDEN, "Chemin interdit")
        if (!dir.isDirectory) return err(Status.NOT_FOUND, "Dossier introuvable")

        val name = (param(s, "name") ?: "")
            .substringAfterLast('/').substringAfterLast('\\').trim()
        if (name.isEmpty() || name == "." || name == "..") return err(Status.BAD_REQUEST, "Nom invalide")

        val total = s.headers["content-length"]?.toLongOrNull()
            ?: return err(Status.BAD_REQUEST, "Content-Length manquant")

        val target = uniqueFile(dir, name)
        val part = File(dir, target.name + ".part")
        var remaining = total
        try {
            BufferedOutputStream(FileOutputStream(part), BUF).use { out ->
                val buf = ByteArray(BUF)
                val input = s.inputStream
                while (remaining > 0) {
                    val n = input.read(buf, 0, minOf(buf.size.toLong(), remaining).toInt())
                    if (n < 0) throw IOException("Connexion interrompue")
                    out.write(buf, 0, n)
                    remaining -= n
                }
            }
            if (!part.renameTo(target)) throw IOException("Impossible d'écrire le fichier")
        } catch (e: Exception) {
            part.delete()
            // Le corps n'a pas été lu en entier : on coupe la connexion pour ne pas désynchroniser le flux.
            return err(Status.INTERNAL_ERROR, e.message ?: "Échec de l'envoi")
                .apply { addHeader("Connection", "close") }
        }

        MediaScannerConnection.scanFile(ctx, arrayOf(target.path), null, null)
        return json(Status.OK, JSONObject().put("ok", true).put("name", target.name).put("size", total))
    }

    private fun uniqueFile(dir: File, name: String): File {
        var f = File(dir, name)
        if (!f.exists()) return f
        val base = name.substringBeforeLast('.', name)
        val ext = if (name.contains('.')) "." + name.substringAfterLast('.') else ""
        var i = 1
        while (f.exists()) f = File(dir, "$base ($i)$ext").also { i++ }
        return f
    }

    // ---------------------------------------------------------------- API applications

    private fun loadApps(): JSONArray {
        val now = SystemClock.elapsedRealtime()
        appsCache?.let { if (now - it.first < 15_000) return it.second }

        @Suppress("DEPRECATION")
        val list = pm.getInstalledApplications(0)
        val sorted = list.map { ai ->
            val splits = ai.splitSourceDirs ?: emptyArray()
            var size = File(ai.sourceDir).length()
            splits.forEach { size += File(it).length() }
            val system = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                    (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
            JSONObject()
                .put("pkg", ai.packageName)
                .put("name", ai.loadLabel(pm).toString())
                .put("size", size)
                .put("system", system)
                .put("splits", splits.size)
        }.sortedBy { it.getString("name").lowercase() }

        val arr = JSONArray()
        sorted.forEach { arr.put(it) }
        appsCache = now to arr
        return arr
    }

    private fun icon(s: IHTTPSession): Response {
        val pkg = param(s, "pkg") ?: return err(Status.BAD_REQUEST, "pkg manquant")
        val bytes = iconCache.get(pkg) ?: try {
            val d = pm.getApplicationIcon(pkg).mutate()
            val bmp = Bitmap.createBitmap(ICON_PX, ICON_PX, Bitmap.Config.ARGB_8888)
            d.setBounds(0, 0, ICON_PX, ICON_PX)
            d.draw(Canvas(bmp))
            val bos = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.PNG, 100, bos)
            bmp.recycle()
            bos.toByteArray().also { iconCache.put(pkg, it) }
        } catch (e: Exception) {
            return err(Status.NOT_FOUND, "Icône introuvable")
        }
        return newFixedLengthResponse(Status.OK, "image/png", ByteArrayInputStream(bytes), bytes.size.toLong())
            .apply { addHeader("Cache-Control", "max-age=3600") }
    }

    private fun apk(s: IHTTPSession): Response {
        val pkg = param(s, "pkg") ?: return err(Status.BAD_REQUEST, "pkg manquant")
        val ai = try {
            pm.getApplicationInfo(pkg, 0)
        } catch (e: PackageManager.NameNotFoundException) {
            return err(Status.NOT_FOUND, "Application introuvable")
        }
        val label = ai.loadLabel(pm).toString().replace(Regex("[\\\\/:*?\"<>|]"), "_")
        val splits = ai.splitSourceDirs

        // APK unique : envoi direct.
        if (splits.isNullOrEmpty()) {
            return serveFile(File(ai.sourceDir), "application/vnd.android.package-archive", null, "$label.apk")
        }

        // App découpée (App Bundle) : l'APK de base seul ne s'installe pas -> on envoie un .apks (zip de tous les APK).
        val pin = PipedInputStream(1 shl 20)
        val pout = PipedOutputStream(pin)
        Thread {
            try {
                ZipOutputStream(BufferedOutputStream(pout, BUF)).use { zip ->
                    zip.setLevel(0)
                    (listOf(ai.sourceDir) + splits).forEach { p ->
                        val f = File(p)
                        zip.putNextEntry(ZipEntry(f.name))
                        f.inputStream().use { it.copyTo(zip, BUF) }
                        zip.closeEntry()
                    }
                }
            } catch (e: IOException) {
                try { pout.close() } catch (_: IOException) { }
            }
        }.start()

        return newChunkedResponse(Status.OK, "application/zip", pin).apply {
            setGzipEncoding(false)
            addHeader("Content-Disposition", dispo("$label.apks", inline = false))
        }
    }

    companion object {
        private const val BUF = 256 * 1024
        private const val ICON_PX = 96
        private const val DENIED_HTML = """<!doctype html><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<body style="font-family:system-ui;background:#0f1520;color:#e8ecf3;display:grid;place-items:center;height:100vh;margin:0;text-align:center">
<div><h2>Accès refusé</h2><p>Scannez le QR Code affiché sur le téléphone<br>pour ouvrir cette page.</p></div></body>"""
    }
}
