package com.example.localshare

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Service de premier plan du Wi-Fi Direct : l'appli reste visible et connectée écran éteint
 * (notification permanente + verrou CPU).
 */
class P2pService : Service() {

    companion object {
        const val ACTION_QUIT = "com.example.localshare.QUIT"

        fun start(ctx: Context) {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, P2pService::class.java))
            } catch (_: Exception) {
            }
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var wakeLock: PowerManager.WakeLock? = null
    private var observing = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val p2p = app.p2p
        if (intent?.action == ACTION_QUIT) {
            p2p.shutdown()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        val n = Notifier.linkNotification(this, label(p2p.state.value))
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(Notifier.ID_LINK, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
        } else {
            startForeground(Notifier.ID_LINK, n)
        }

        if (wakeLock == null) {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LocalShare:p2p").apply {
                setReferenceCounted(false)
                acquire()
            }
        }
        if (!observing) {
            observing = true
            scope.launch {
                p2p.state.collect { s ->
                    try {
                        NotificationManagerCompat.from(this@P2pService)
                            .notify(Notifier.ID_LINK, Notifier.linkNotification(this@P2pService, label(s)))
                    } catch (_: SecurityException) {
                    }
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun label(s: P2pState): String = when {
        s.isConnected -> "Connecté à ${s.connectedName}"
        s.advertising -> "Visible comme « ${s.deviceName} »"
        s.discovering -> "Recherche d’appareils…"
        else -> "En attente"
    }

    override fun onDestroy() {
        scope.cancel()
        try { wakeLock?.takeIf { it.isHeld }?.release() } catch (_: Exception) { }
        wakeLock = null
        super.onDestroy()
    }
}
