package com.example.localshare

import android.content.Context
import android.util.Base64
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicLong

enum class RemoteAccess { NONE, REQUESTING, GRANTED, DENIED }

class RemoteEntry(val name: String, val isDir: Boolean, val size: Long, val modified: Long)

class RemoteApp(val name: String, val pkg: String, val version: String, val system: Boolean, val icon: ByteArray?)

/**
 * Accès aux fichiers et applications de l'autre téléphone, comme un téléphone branché à un PC.
 *
 *  - Côté « serveur » (mon téléphone exposé) : l'accès doit être AUTORISÉ explicitement, il est limité
 *    au stockage interne, valable pour la session en cours, et révocable.
 *  - Côté « client » : navigation dossier par dossier, filtre par jour, téléchargement dans DoubigueShare
 *    (même canal que l'envoi de fichiers), liste des applications et récupération de leur APK.
 *
 * Les états sont lus par l'interface ; [tick] signale chaque changement.
 */
class RemoteFs(private val ctx: Context, private val p2p: P2pEngine, private val transfers: TransferManager) {

    val tick = MutableStateFlow(0L)
    private val counter = AtomicLong()
    private val exec = Executors.newCachedThreadPool()

    private fun changed() {
        tick.value = counter.incrementAndGet()
    }

    val root: String = Storage.root.path

    // ------------------------------------------------ état « serveur » (mon téléphone)
    @Volatile var accessGranted = false
    @Volatile var pendingRequest = false

    // ------------------------------------------------ état « client » (téléphone de l'autre)
    @Volatile var access = RemoteAccess.NONE
    @Volatile var currentPath = root
    @Volatile var entries: List<RemoteEntry> = emptyList()
    @Volatile var loading = false
    @Volatile var error: String? = null
    @Volatile var apps: List<RemoteApp> = emptyList()
    @Volatile var appsLoading = false
    @Volatile var appsError: String? = null
    @Volatile private var appsWanted = false
    @Volatile private var req = 0

    val atRoot: Boolean get() = currentPath == root

    init {
        p2p.jsonListeners.add { onMessage(it) }
        p2p.sessionEnded.add { reset() }
    }

    private fun reset() {
        Notifier.cancel(ctx, Notifier.ID_FS)
        accessGranted = false
        pendingRequest = false
        access = RemoteAccess.NONE
        currentPath = root
        entries = emptyList()
        loading = false
        error = null
        apps = emptyList()
        appsLoading = false
        appsError = null
        appsWanted = false
        changed()
    }

    // ================================================================ client
    fun requestAccess() {
        access = RemoteAccess.REQUESTING
        error = null
        changed()
        p2p.send(JSONObject().put("t", "fs_req"))
    }

    fun loadApps() {
        if (access != RemoteAccess.GRANTED) {
            appsWanted = true
            if (access != RemoteAccess.REQUESTING) requestAccess()
            return
        }
        apps = emptyList()
        appsLoading = true
        appsError = null
        changed()
        p2p.send(JSONObject().put("t", "apps"))
    }

    fun list(path: String) {
        req++
        loading = true
        error = null
        entries = emptyList()
        currentPath = path
        changed()
        p2p.send(JSONObject().put("t", "ls").put("r", req).put("p", path))
    }

    fun up() {
        if (atRoot) return
        list(File(currentPath).parent ?: root)
    }

    fun refresh() = list(currentPath)

    fun download(remotePaths: Collection<String>) {
        for (p in remotePaths) p2p.send(JSONObject().put("t", "get").put("p", p))
    }

    fun downloadApk(pkg: String) {
        p2p.send(JSONObject().put("t", "getapk").put("p", pkg))
    }

    // ================================================================ serveur
    /** Réponse de l'utilisateur à la demande d'accès (le droit « tous les fichiers » doit être accordé avant). */
    fun respond(ok: Boolean) {
        Notifier.cancel(ctx, Notifier.ID_FS)
        pendingRequest = false
        accessGranted = ok
        changed()
        p2p.send(JSONObject().put("t", "fs_grant").put("ok", ok))
    }

    fun revoke() {
        accessGranted = false
        changed()
        p2p.send(JSONObject().put("t", "fs_revoke"))
    }

    /** Refuse tout chemin hors du stockage interne (« .. », liens symboliques, autre racine…). */
    private fun safe(path: String): File? = try {
        val r = File(root).canonicalFile
        val f = File(path).canonicalFile
        if (f.path == r.path || f.path.startsWith(r.path + File.separator)) f else null
    } catch (_: Exception) {
        null
    }

    private fun serveList(r: Int, path: String) {
        fun reply(extra: JSONObject.() -> Unit) {
            val o = JSONObject().put("t", "ls_r").put("r", r).put("p", path)
                .put("pg", 0).put("more", false).put("e", JSONArray())
            o.extra()
            try { p2p.sendJsonSync(o) } catch (_: Exception) { }
        }

        val dir = safe(path)
        if (!accessGranted || dir == null) {
            reply { put("err", "Accès refusé") }
            return
        }
        val files = dir.listFiles()
        if (files == null) {
            reply { put("err", "Dossier illisible") }
            return
        }
        val list = files.filter { !it.name.startsWith(".") }
            .sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))

        // Pagination : messages de taille raisonnable.
        var page = JSONArray()
        var size = 0
        var pg = 0
        fun flush(more: Boolean) {
            val cur = page
            val n = pg++
            reply { put("p", dir.path); put("pg", n); put("more", more); put("e", cur) }
            page = JSONArray()
            size = 0
        }
        for (f in list) {
            val approx = f.name.toByteArray().size + 60
            if (size + approx > 20000) flush(true)
            page.put(
                JSONObject().put("n", f.name).put("d", if (f.isDirectory) 1 else 0)
                    .put("s", if (f.isDirectory) 0L else f.length()).put("m", f.lastModified())
            )
            size += approx
        }
        flush(false)
    }

    private fun serveApps() {
        fun reply(extra: JSONObject.() -> Unit) {
            val o = JSONObject().put("t", "apps_r").put("pg", 0).put("more", false).put("e", JSONArray())
            o.extra()
            try { p2p.sendJsonSync(o) } catch (_: Exception) { }
        }
        if (!accessGranted) {
            reply { put("err", "Accès refusé") }
            return
        }
        try {
            val list = AppsLister.list(ctx)
            val pageSize = 25
            var pg = 0
            var i = 0
            while (i < list.size) {
                val chunk = list.subList(i, minOf(i + pageSize, list.size))
                val arr = JSONArray()
                for (a in chunk) {
                    arr.put(
                        JSONObject().put("n", a.name).put("p", a.pkg).put("v", a.version)
                            .put("s", if (a.system) 1 else 0)
                            .put("i", a.icon?.let { Base64.encodeToString(it, Base64.NO_WRAP) } ?: "")
                    )
                }
                val more = i + pageSize < list.size
                val n = pg++
                reply { put("pg", n); put("more", more); put("e", arr) }
                i += pageSize
            }
            if (list.isEmpty()) reply { }
        } catch (_: Exception) {
            reply { put("err", "Liste des applications indisponible") }
        }
    }

    private fun serveGet(path: String) {
        val f = safe(path) ?: return
        if (accessGranted && f.isFile) transfers.sendFile(f)
    }

    private fun serveApk(pkg: String) {
        if (!accessGranted) return
        try {
            for ((f, name) in AppsLister.apkFiles(ctx, pkg)) transfers.sendFile(f, name)
        } catch (_: Exception) {
        }
    }

    // ============================================================ réception
    private fun onMessage(m: JSONObject) {
        try {
            when (m.optString("t")) {
                // ----- côté serveur
                "fs_req" -> {
                    if (accessGranted) {
                        respond(true)
                    } else {
                        pendingRequest = true
                        Notifier.showFsRequest(ctx, p2pName())
                        changed()
                    }
                }
                "ls" -> {
                    val r = m.getInt("r")
                    val p = m.getString("p")
                    exec.execute { serveList(r, p) }
                }
                "get" -> {
                    val p = m.getString("p")
                    exec.execute { serveGet(p) }
                }
                "getapk" -> {
                    val p = m.getString("p")
                    exec.execute { serveApk(p) }
                }
                "apps" -> exec.execute { serveApps() }

                // ----- côté client
                "fs_grant" -> {
                    if (m.optBoolean("ok")) {
                        access = RemoteAccess.GRANTED
                        changed()
                        if (appsWanted) {
                            appsWanted = false
                            loadApps()
                        } else {
                            list(root)
                        }
                    } else {
                        appsWanted = false
                        appsLoading = false
                        access = RemoteAccess.DENIED
                        changed()
                    }
                }
                "fs_revoke" -> {
                    access = RemoteAccess.DENIED
                    entries = emptyList()
                    apps = emptyList()
                    appsLoading = false
                    currentPath = root
                    loading = false
                    changed()
                }
                "apps_r" -> {
                    if (m.has("err")) {
                        appsError = m.getString("err")
                        appsLoading = false
                    } else {
                        val arr = m.getJSONArray("e")
                        val add = ArrayList<RemoteApp>(arr.length())
                        for (i in 0 until arr.length()) {
                            val j = arr.getJSONObject(i)
                            val icon = j.optString("i").takeIf { it.isNotEmpty() }?.let {
                                try { Base64.decode(it, Base64.DEFAULT) } catch (_: Exception) { null }
                            }
                            add += RemoteApp(j.optString("n"), j.optString("p"), j.optString("v"), j.optInt("s") == 1, icon)
                        }
                        apps = apps + add
                        appsLoading = m.optBoolean("more")
                    }
                    changed()
                }
                "ls_r" -> {
                    if (m.optInt("r") != req) return // réponse périmée
                    if (m.has("err")) {
                        error = m.getString("err")
                        loading = false
                    } else {
                        if (m.optInt("pg") == 0) currentPath = m.getString("p")
                        val arr = m.getJSONArray("e")
                        val add = ArrayList<RemoteEntry>(arr.length())
                        for (i in 0 until arr.length()) {
                            val j = arr.getJSONObject(i)
                            add += RemoteEntry(j.getString("n"), j.optInt("d") == 1, j.optLong("s"), j.optLong("m"))
                        }
                        entries = entries + add
                        loading = m.optBoolean("more")
                    }
                    changed()
                }
            }
        } catch (_: Exception) {
            // Message mal formé venant de l'autre appareil : ignoré.
        }
    }

    private fun p2pName(): String = p2p.state.value.connectedName.ifEmpty { "Un appareil" }
}
