package com.example.localshare

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.launch
import java.io.File

/** Session connectée : envoi de fichiers/texte, transferts en cours, accès à ses fichiers et applications. */
class SessionActivity : AppCompatActivity() {

    private val p2p get() = app.p2p
    private val transfers get() = app.transfers
    private val remoteFs get() = app.remoteFs

    private lateinit var tvTitle: TextView
    private lateinit var tvEmpty: TextView
    private lateinit var tiles: TileAdapter
    private lateinit var adapter: RowAdapter<Any>

    private var fsDialog: AlertDialog? = null
    private var allowAfterPermission = false

    private val pickFiles =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris -> sendPicked(uris) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_session)
        tvTitle = findViewById(R.id.tvTitle)
        tvEmpty = findViewById(R.id.tvEmpty)

        adapter = RowAdapter(
            bind = { h, it -> bindRow(h, it) },
            onClick = { onRowClick(it) }
        )
        findViewById<RecyclerView>(R.id.list).apply {
            layoutManager = LinearLayoutManager(this@SessionActivity)
            adapter = this@SessionActivity.adapter
        }

        tiles = TileAdapter()
        findViewById<RecyclerView>(R.id.tiles).setupTiles(tiles)
        buildTiles()

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { p2p.state.collect { s ->
                    if (!s.isConnected) finish() else tvTitle.text = "Connecté à ${s.connectedName}"
                } }
                launch { transfers.tick.collect { renderFeed() } }
                launch { remoteFs.tick.collect { renderAccess() } }
            }
        }
    }

    private fun buildTiles() {
        val list = mutableListOf(
            Tile(R.drawable.ic_upload, "Envoyer des fichiers", "Choisir dans le téléphone") { pickFiles.launch(arrayOf("*/*")) },
            Tile(R.drawable.ic_text, "Envoyer du texte", "Message ou lien") { askText() },
            Tile(R.drawable.ic_folder, "Ses fichiers", "Parcourir et télécharger") {
                startActivity(Intent(this, BrowserActivity::class.java).putExtra(BrowserActivity.EXTRA_MODE, BrowserActivity.MODE_REMOTE))
            },
            Tile(R.drawable.ic_apps, "Ses applications", "Liste et APK") { startActivity(Intent(this, AppsActivity::class.java)) },
            Tile(R.drawable.ic_download, "Reçus", "Dossier ${Storage.FOLDER}") {
                startActivity(Intent(this, BrowserActivity::class.java).putExtra(BrowserActivity.EXTRA_MODE, BrowserActivity.MODE_LOCAL))
            }
        )
        if (remoteFs.accessGranted) {
            list += Tile(R.drawable.ic_shield, "Révoquer l’accès", "Il voit vos fichiers", active = true) { remoteFs.revoke() }
        }
        list += Tile(R.drawable.ic_power, "Déconnecter", "Fermer la session", danger = true) { p2p.disconnect() }
        tiles.submit(list)
    }

    override fun onResume() {
        super.onResume()
        if (allowAfterPermission) {
            allowAfterPermission = false
            remoteFs.respond(Storage.hasAccess(this))
        }
    }

    // ---------------------------------------------------------------- envoi
    private fun sendPicked(uris: List<Uri>) {
        for (u in uris) {
            try {
                contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {
            }
            var name: String? = null
            var size = 0L
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use {
                if (it.moveToFirst()) {
                    name = it.getString(0)
                    if (!it.isNull(1)) size = it.getLong(1)
                }
            }
            transfers.sendUri(u, name, size)
        }
    }

    private fun askText() {
        val et = EditText(this).apply { hint = "Message, lien…"; minLines = 3 }
        MaterialAlertDialogBuilder(this)
            .setTitle("Envoyer du texte")
            .setView(et)
            .setPositiveButton("Envoyer") { _, _ -> transfers.sendText(et.text.toString()) }
            .setNegativeButton("Annuler", null)
            .show()
    }

    // ---------------------------------------------------------------- liste des transferts
    private fun renderFeed() {
        val feed = transfers.feed()
        adapter.submit(feed)
        tvEmpty.visibility = if (feed.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun bindRow(h: RowHolder, it: Any) {
        when (it) {
            is TransferItem -> {
                h.title.text = (if (it.outgoing) "↑ " else "↓ ") + it.name
                h.sub.text = when (it.status) {
                    TStatus.DONE -> "Terminé · ${Fmt.bytes(it.total)}" +
                            if (!it.outgoing) " · enregistré dans ${Storage.FOLDER}" else ""
                    TStatus.FAILED -> "Échec ou annulé"
                    TStatus.IN_PROGRESS -> progressText(it)
                }
                if (it.status == TStatus.IN_PROGRESS) {
                    h.progress.visibility = View.VISIBLE
                    h.progress.isIndeterminate = it.total <= 0
                    h.progress.progress = (it.progress * 1000).toInt()
                }
            }
            is TextItem -> {
                h.title.text = it.text
                h.sub.text = if (it.outgoing) "Envoyé" else "Reçu · touchez pour copier"
            }
        }
    }

    private fun progressText(it: TransferItem): String {
        val pct = if (it.total > 0) "${(it.progress * 100).toInt()} % · " else ""
        val sp = if (it.speed > 0) "${Fmt.bytes(it.speed.toLong())}/s" else "…"
        val eta = it.etaSeconds?.let { s -> " · reste ${if (s >= 60) "${s / 60} min ${s % 60} s" else "$s s"}" } ?: ""
        return "$pct${Fmt.bytes(it.transferred)} · $sp$eta"
    }

    private fun onRowClick(it: Any) {
        when (it) {
            is TransferItem -> when {
                it.status == TStatus.IN_PROGRESS -> MaterialAlertDialogBuilder(this)
                    .setTitle("Annuler ce transfert ?")
                    .setMessage(it.name)
                    .setPositiveButton("Annuler le transfert") { _, _ -> transfers.cancel(it) }
                    .setNegativeButton("Continuer", null)
                    .show()
                it.status == TStatus.DONE && !it.outgoing && it.savedPath != null -> Storage.open(this, File(it.savedPath!!))
            }
            is TextItem -> {
                (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
                    .setPrimaryClip(ClipData.newPlainText("LocalShare", it.text))
                Toast.makeText(this, "Copié", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ---------------------------------------------------------------- accès demandé par l'autre
    private fun renderAccess() {
        buildTiles()
        if (remoteFs.pendingRequest) {
            if (fsDialog?.isShowing != true) {
                val who = p2p.state.value.connectedName
                fsDialog = MaterialAlertDialogBuilder(this)
                    .setTitle("Accès à vos fichiers et applications")
                    .setMessage(
                        "« $who » veut parcourir vos fichiers (stockage interne) et voir vos applications.\n\n" +
                                "L’accès dure jusqu’à la déconnexion et peut être révoqué à tout moment."
                    )
                    .setCancelable(false)
                    .setPositiveButton("Autoriser") { _, _ -> allow() }
                    .setNegativeButton("Refuser") { _, _ -> remoteFs.respond(false) }
                    .show()
            }
        } else {
            fsDialog?.dismiss()
            fsDialog = null
        }
    }

    /** Demande d'abord « Accès à tous les fichiers » si nécessaire, puis répond à l'autre téléphone. */
    private fun allow() {
        if (Storage.hasAccess(this)) {
            remoteFs.respond(true)
        } else {
            allowAfterPermission = true
            Toast.makeText(this, "Autorisez l’accès à tous les fichiers, puis revenez dans LocalShare", Toast.LENGTH_LONG).show()
            Storage.requestAccess(this)
        }
    }

    override fun onDestroy() {
        fsDialog?.dismiss()
        super.onDestroy()
    }
}
