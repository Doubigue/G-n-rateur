package com.example.localshare

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class RowHolder(v: View) : RecyclerView.ViewHolder(v) {
    val icon: ImageView = v.findViewById(R.id.icon)
    val title: TextView = v.findViewById(R.id.title)
    val sub: TextView = v.findViewById(R.id.sub)
    val progress: ProgressBar = v.findViewById(R.id.progress)
}

/** Adaptateur unique pour toutes les listes : une ligne = icône optionnelle, titre, sous-titre, barre optionnelle. */
class RowAdapter<T>(
    private val bind: (RowHolder, T) -> Unit,
    private val onClick: (T) -> Unit = {},
    private val onLongClick: ((T) -> Unit)? = null
) : RecyclerView.Adapter<RowHolder>() {

    private var items: List<T> = emptyList()

    fun submit(list: List<T>) {
        items = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        RowHolder(LayoutInflater.from(parent.context).inflate(R.layout.row_item, parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: RowHolder, position: Int) {
        val item = items[position]
        h.icon.visibility = View.GONE
        h.icon.setImageDrawable(null)
        h.progress.visibility = View.GONE
        h.sub.visibility = View.VISIBLE
        bind(h, item)
        h.itemView.setOnClickListener { onClick(item) }
        h.itemView.setOnLongClickListener(
            if (onLongClick != null) View.OnLongClickListener { onLongClick.invoke(item); true } else null
        )
    }
}
