package com.example.localshare

import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.IOException
import java.net.Socket
import java.nio.ByteBuffer
import java.util.Timer
import java.util.TimerTask

/**
 * Protocole LocalShare sur le lien TCP Wi-Fi Direct (port 8988), compatible avec LocalShare 2.0 Flutter.
 *
 * Trame : [type:1][id:4][longueur:4][données]   (entiers en gros-boutiste)
 *   1 = message JSON, 2 = morceau de fichier (id), 3 = fin de fichier,
 *   4 = annulation de fichier, 5 = ping (détection de coupure).
 *
 * Messages JSON ({"t": ...}) :
 *   hello {name, nonce, v} · accept · reject · bye · text {m} · file {id, name, size}
 *   fs_req · fs_grant {ok} · fs_revoke · ls {r, p} · ls_r {r, p, pg, more, e:[{n,d,s,m}], err}
 *   get {p} · apps · apps_r {pg, more, e:[{n,p,v,s,i}], err}
 *   getapk {p}   (extension de cette version : récupérer l'APK d'une application)
 */
object Protocol {
    const val PORT = 8988
}

class DirectLink(
    private val socket: Socket,
    private val onJson: (JSONObject) -> Unit,
    private val onChunk: (Int, ByteArray) -> Unit,
    private val onEnd: (Int) -> Unit,
    private val onCancel: (Int) -> Unit,
    private val onClosed: () -> Unit
) {
    companion object {
        private const val T_JSON = 1
        private const val T_CHUNK = 2
        private const val T_END = 3
        private const val T_CANCEL = 4
        private const val T_PING = 5
        private const val MAX_FRAME = 4 * 1024 * 1024
        private const val IO_BUF = 256 * 1024
        private val EMPTY = ByteArray(0)
    }

    @Volatile
    var closed = false
        private set

    @Volatile
    private var lastRx = System.currentTimeMillis()

    private val input = DataInputStream(BufferedInputStream(socket.getInputStream(), IO_BUF))
    private val output = BufferedOutputStream(socket.getOutputStream(), IO_BUF)
    private val writeLock = Any()
    private val timer = Timer("link-timer", true)

    fun start() {
        Thread({ readLoop() }, "link-reader").apply { isDaemon = true; start() }
        timer.schedule(object : TimerTask() {
            override fun run() {
                try {
                    write(T_PING, 0, null, 0, 0)
                } catch (_: IOException) {
                }
            }
        }, 8000, 8000)
        timer.schedule(object : TimerTask() {
            override fun run() {
                if (System.currentTimeMillis() - lastRx > 30_000) close()
            }
        }, 5000, 5000)
    }

    // ------------------------------------------------------------ réception
    private fun readLoop() {
        try {
            val hdr = ByteArray(9)
            while (!closed) {
                input.readFully(hdr)
                val type = hdr[0].toInt() and 0xFF
                val bb = ByteBuffer.wrap(hdr)
                val id = bb.getInt(1)
                val len = bb.getInt(5)
                if (len < 0 || len > MAX_FRAME) break
                val body = if (len == 0) EMPTY else ByteArray(len).also { input.readFully(it) }
                lastRx = System.currentTimeMillis()
                try {
                    when (type) {
                        T_JSON -> onJson(JSONObject(String(body, Charsets.UTF_8)))
                        T_CHUNK -> onChunk(id, body)
                        T_END -> onEnd(id)
                        T_CANCEL -> onCancel(id)
                    }
                } catch (_: Exception) {
                    // Trame illisible : ignorée, le lien reste ouvert.
                }
            }
        } catch (_: IOException) {
        } finally {
            close()
        }
    }

    // --------------------------------------------------------------- envoi (bloquant, thread-safe)
    @Throws(IOException::class)
    private fun write(type: Int, id: Int, buf: ByteArray?, off: Int, len: Int) {
        if (closed) throw IOException("Lien fermé")
        val hdr = ByteBuffer.allocate(9).put(type.toByte()).putInt(id).putInt(len).array()
        try {
            synchronized(writeLock) {
                output.write(hdr)
                if (buf != null && len > 0) output.write(buf, off, len)
                output.flush()
            }
        } catch (e: IOException) {
            close()
            throw e
        }
    }

    @Throws(IOException::class)
    fun sendJson(m: JSONObject) {
        val b = m.toString().toByteArray(Charsets.UTF_8)
        write(T_JSON, 0, b, 0, b.size)
    }

    @Throws(IOException::class)
    fun sendChunk(id: Int, buf: ByteArray, len: Int) = write(T_CHUNK, id, buf, 0, len)

    @Throws(IOException::class)
    fun sendEnd(id: Int) = write(T_END, id, null, 0, 0)

    @Throws(IOException::class)
    fun sendCancel(id: Int) = write(T_CANCEL, id, null, 0, 0)

    fun close() {
        if (closed) return
        closed = true
        timer.cancel()
        try {
            socket.close()
        } catch (_: IOException) {
        }
        onClosed()
    }
}
