package com.example.localshare

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import kotlinx.coroutines.launch

/** « Ses applications » : grille/liste des applications installées sur l'autre téléphone + récupération de l'APK. */
class AppsActivity : AppCompatActivity() {

    private val p2p get() = app.p2p
    private val remoteFs get() = app.remoteFs

    private lateinit var tvState: TextView
    private lateinit var etSearch: EditText
    private lateinit var swSystem: MaterialSwitch
    private lateinit var adapter: RowAdapter<RemoteApp>
    private val icons = HashMap<String, Bitmap?>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_apps)
        tvState = findViewById(R.id.tvState)
        etSearch = findViewById(R.id.etSearch)
        swSystem = findViewById(R.id.swSystem)
        findViewById<TextView>(R.id.tvTitle).text = "Applications de ${p2p.state.value.connectedName}"

        adapter = RowAdapter(
            bind = { h, a ->
                h.title.text = a.name
                h.sub.text = a.pkg + if (a.version.isNotEmpty()) " · v${a.version}" else ""
                val bmp = icons.getOrPut(a.pkg) {
                    a.icon?.let { BitmapFactory.decodeByteArray(it, 0, it.size) }
                }
                if (bmp != null) {
                    h.icon.setImageBitmap(bmp)
                    h.icon.visibility = android.view.View.VISIBLE
                }
            },
            onClick = { a ->
                MaterialAlertDialogBuilder(this)
                    .setTitle(a.name)
                    .setMessage("Récupérer l’APK de cette application ? Il arrivera dans ${Storage.FOLDER}.\n(Les applications découpées en plusieurs APK arrivent en plusieurs fichiers.)")
                    .setPositiveButton("Télécharger") { _, _ ->
                        remoteFs.downloadApk(a.pkg)
                        Toast.makeText(this, "Demande envoyée", Toast.LENGTH_SHORT).show()
                    }
                    .setNegativeButton("Annuler", null)
                    .show()
            }
        )
        findViewById<RecyclerView>(R.id.list).apply {
            layoutManager = LinearLayoutManager(this@AppsActivity)
            adapter = this@AppsActivity.adapter
        }
        etSearch.doAfterTextChanged { render() }
        swSystem.setOnCheckedChangeListener { _, _ -> render() }

        remoteFs.loadApps()

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { remoteFs.tick.collect { render() } }
                launch { p2p.state.collect { if (!it.isConnected) finish() } }
            }
        }
    }

    private fun render() {
        val q = etSearch.text.toString().trim().lowercase()
        val sys = swSystem.isChecked
        val list = remoteFs.apps.filter { (sys || !it.system) && (q.isEmpty() || (it.name + " " + it.pkg).lowercase().contains(q)) }
        adapter.submit(list)
        tvState.text = when {
            remoteFs.access == RemoteAccess.DENIED -> "Accès refusé ou révoqué."
            remoteFs.access != RemoteAccess.GRANTED -> "En attente de l’autorisation de ${p2p.state.value.connectedName}…"
            remoteFs.appsError != null -> remoteFs.appsError
            remoteFs.appsLoading -> "Chargement… (${list.size})"
            list.isEmpty() -> "Aucune application"
            else -> "${list.size} application(s)"
        }
    }
}
