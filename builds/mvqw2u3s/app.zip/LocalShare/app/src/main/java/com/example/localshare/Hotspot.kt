package com.example.localshare

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow

data class HotspotInfo(
    val active: Boolean = false,
    val starting: Boolean = false,
    val ssid: String = "",
    val password: String = "",
    val error: String? = null
)

/**
 * Point d'accès (hotspot) créé par l'appli : LocalOnlyHotspot (Android 8+). Les autres appareils rejoignent ce
 * Wi-Fi (QR Code ou mot de passe), puis ouvrent l'adresse du serveur web : aucune box, aucun Internet.
 * La réservation vit autant que le processus ; elle est fermée par [stop].
 */
object HotspotController {
    val state = MutableStateFlow(HotspotInfo())
    private var reservation: WifiManager.LocalOnlyHotspotReservation? = null

    val supported: Boolean get() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O

    fun requiredPermission(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.NEARBY_WIFI_DEVICES else Manifest.permission.ACCESS_FINE_LOCATION

    fun hasPermission(ctx: Context) =
        ContextCompat.checkSelfPermission(ctx, requiredPermission()) == PackageManager.PERMISSION_GRANTED

    /** Android 12 et moins : la localisation doit être activée pour créer un point d'accès local. */
    fun locationOk(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT >= 33) return true
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as android.location.LocationManager
        return if (Build.VERSION.SDK_INT >= 28) lm.isLocationEnabled
        else lm.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER) ||
                lm.isProviderEnabled(android.location.LocationManager.NETWORK_PROVIDER)
    }

    @SuppressLint("MissingPermission", "NewApi")
    fun start(ctx: Context) {
        if (!supported) {
            state.value = HotspotInfo(error = "Création automatique impossible avant Android 8 : utilisez le point d’accès d’Android.")
            return
        }
        if (reservation != null || state.value.starting) return
        state.value = HotspotInfo(starting = true)
        try {
            val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            wm.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
                override fun onStarted(r: WifiManager.LocalOnlyHotspotReservation) {
                    reservation = r
                    val (ssid, pass) = read(r)
                    state.value = HotspotInfo(active = true, ssid = ssid, password = pass)
                }

                override fun onStopped() {
                    reservation = null
                    state.value = HotspotInfo()
                }

                override fun onFailed(reason: Int) {
                    reservation = null
                    state.value = HotspotInfo(
                        error = when (reason) {
                            WifiManager.LocalOnlyHotspotCallback.ERROR_NO_CHANNEL -> "Aucun canal Wi-Fi disponible."
                            WifiManager.LocalOnlyHotspotCallback.ERROR_INCOMPATIBLE_MODE -> "Incompatible avec le mode actuel : coupez le point d’accès d’Android ou le Wi-Fi Direct, puis réessayez."
                            WifiManager.LocalOnlyHotspotCallback.ERROR_TETHERING_DISALLOWED -> "Le partage de connexion est interdit sur cet appareil."
                            else -> "Impossible de créer le point d’accès (vérifiez que la localisation est activée)."
                        }
                    )
                }
            }, Handler(Looper.getMainLooper()))
        } catch (e: SecurityException) {
            state.value = HotspotInfo(error = "Autorisation refusée.")
        } catch (e: Exception) {
            state.value = HotspotInfo(error = e.message ?: "Erreur inconnue.")
        }
    }

    fun stop() {
        try { reservation?.close() } catch (_: Exception) { }
        reservation = null
        state.value = HotspotInfo()
    }

    @Suppress("DEPRECATION")
    private fun read(r: WifiManager.LocalOnlyHotspotReservation): Pair<String, String> =
        if (Build.VERSION.SDK_INT >= 30) {
            val c = r.softApConfiguration
            (c.ssid ?: "") to (c.passphrase ?: "")
        } else {
            val c = r.wifiConfiguration
            (c?.SSID ?: "").trim('"') to (c?.preSharedKey ?: "").trim('"')
        }
}
