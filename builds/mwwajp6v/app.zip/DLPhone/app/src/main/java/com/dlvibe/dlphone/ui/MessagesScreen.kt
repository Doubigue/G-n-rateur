package com.dlvibe.dlphone.ui

import android.database.ContentObserver
import android.os.Handler
import android.os.Looper
import android.provider.Telephony
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dlvibe.dlphone.Prefs
import com.dlvibe.dlphone.ThemeEditorActivity
import com.dlvibe.dlphone.sms.Conversation
import com.dlvibe.dlphone.sms.ConversationActivity
import com.dlvibe.dlphone.sms.SmsBus
import com.dlvibe.dlphone.sms.SmsMsg
import com.dlvibe.dlphone.sms.SmsRepo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun shortTime(t: Long): String {
    val label = dayLabel(t)
    return when (label) {
        "Aujourd'hui" -> SimpleDateFormat("HH:mm", Locale.FRENCH).format(Date(t))
        "Hier" -> "Hier"
        else -> SimpleDateFormat("d MMM", Locale.FRENCH).format(Date(t))
    }
}

/** Rafraîchit quand la base des SMS change. */
@Composable
fun rememberSmsObserverTick(): Int {
    val ctx = LocalContext.current
    var t by remember { mutableIntStateOf(0) }
    DisposableEffect(Unit) {
        val obs = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean) {
                t++
            }
        }
        runCatching { ctx.contentResolver.registerContentObserver(Telephony.Sms.CONTENT_URI, true, obs) }
        onDispose { runCatching { ctx.contentResolver.unregisterContentObserver(obs) } }
    }
    return t
}

@Composable
fun MessagesScreen(refreshKey: Int) {
    val ctx = LocalContext.current
    val p = LocalPalette.current
    val tick by SmsBus.tick.collectAsState()
    val obsTick = rememberSmsObserverTick()
    var convs by remember { mutableStateOf<List<Conversation>>(emptyList()) }
    var loaded by remember { mutableStateOf(false) }
    LaunchedEffect(refreshKey, tick, obsTick) {
        delay(120)
        convs = withContext(Dispatchers.IO) { SmsRepo.conversations(ctx) }
        loaded = true
    }
    val canRead = remember(refreshKey) { SmsRepo.canRead(ctx) }
    var q by remember { mutableStateOf("") }
    val shown = remember(convs, q) {
        val base = if (Prefs.smsHideBlocked) convs.filter { !Prefs.isBlocked(it.address) } else convs
        if (q.isBlank()) base else {
            val cq = q.trim().lowercase()
            base.filter {
                (it.name ?: "").lowercase().contains(cq) || it.address.contains(cq) || it.snippet.lowercase().contains(cq)
            }
        }
    }
    var found by remember { mutableStateOf<List<SmsMsg>>(emptyList()) }
    LaunchedEffect(q) {
        delay(300)
        found = if (q.trim().length >= 3) withContext(Dispatchers.IO) { SmsRepo.search(ctx, q.trim()) } else emptyList()
    }
    val unread = convs.sumOf { it.unread }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            ScreenHeader("Messages", if (unread > 0) "$unread non lu(s)" else "Tout est lu")
            if (!canRead) {
                Text(
                    "Accès aux SMS non autorisé (voir Réglages > Général).",
                    color = p.muted, fontSize = 13.sp, modifier = Modifier.padding(20.dp)
                )
            }
            OutlinedTextField(
                value = q,
                onValueChange = { q = it },
                placeholder = { Text("Rechercher dans les messages") },
                leadingIcon = { Icon(Icons.Filled.Search, null) },
                singleLine = true,
                shape = RoundedCornerShape(28.dp),
                colors = dlTextFieldColors(),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            )
            if (loaded && shown.isEmpty() && found.isEmpty() && canRead) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(if (q.isBlank()) "Aucune conversation" else "Aucun résultat", color = p.muted)
                }
            } else {
                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 90.dp)) {
                    items(shown, key = { "t${it.threadId}" }) { c -> ConversationRow(c) }
                    if (found.isNotEmpty()) {
                        item(key = "found_h") { SectionLabel("Dans le texte des messages", Modifier.padding(start = 20.dp, top = 10.dp)) }
                        items(found, key = { "m${it.id}" }) { m ->
                            val title = m.address
                            ListRow(
                                title = title,
                                leading = { Avatar(title, 40.dp, number = m.address) },
                                subtitle = { Text(m.body, color = p.muted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis) },
                                trailing = { Text(shortTime(m.date), color = p.muted, fontSize = 11.sp) },
                                onClick = { ConversationActivity.open(ctx, m.address) }
                            )
                        }
                    }
                }
            }
        }
        FloatingActionButton(
            onClick = { ConversationActivity.open(ctx, null) },
            containerColor = p.accent,
            contentColor = p.onAccent,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
        ) { Icon(Icons.Filled.Edit, "Nouveau message") }
    }
}

@Composable
private fun ConversationRow(c: Conversation) {
    val ctx = LocalContext.current
    val p = LocalPalette.current
    var menu by remember { mutableStateOf(false) }
    val title = c.name ?: c.address
    Box {
        ListRow(
            title = title,
            leading = { Avatar(title, 48.dp, number = c.address) },
            subtitle = {
                Text(
                    (if (c.lastOutgoing) "Vous : " else "") + c.snippet.replace('\n', ' '),
                    color = if (c.unread > 0) p.text else p.muted,
                    fontWeight = if (c.unread > 0) FontWeight.SemiBold else FontWeight.Normal,
                    fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            },
            trailing = {
                Column(horizontalAlignment = Alignment.End) {
                    Text(shortTime(c.date), color = if (c.unread > 0) p.accent else p.muted, fontSize = 11.sp)
                    if (c.unread > 0) {
                        Box(
                            Modifier
                                .padding(top = 4.dp)
                                .defaultMinSize(minWidth = 20.dp, minHeight = 20.dp)
                                .clip(CircleShape)
                                .background(p.accent)
                                .padding(horizontal = 6.dp),
                            contentAlignment = Alignment.Center
                        ) { Text("${c.unread}", color = p.onAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                    }
                }
            },
            onClick = { ConversationActivity.open(ctx, c.address) },
            onLongClick = { menu = true }
        )
        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
            val blocked = Prefs.isBlocked(c.address)
            DropdownMenuItem(text = { Text("Marquer comme lu") }, onClick = {
                menu = false
                SmsRepo.markRead(ctx, c.address)
                SmsBus.changed()
            })
            DropdownMenuItem(text = { Text("Personnaliser l'appel") }, onClick = {
                menu = false
                ThemeEditorActivity.open(ctx, c.address, c.name)
            })
            DropdownMenuItem(text = { Text(if (blocked) "Débloquer" else "Bloquer ce numéro") }, onClick = {
                menu = false
                if (blocked) Prefs.unblock(c.address) else Prefs.block(c.address)
                SmsBus.changed()
            })
            DropdownMenuItem(text = { Text("Supprimer la conversation", color = HangupRed) }, onClick = {
                menu = false
                if (SmsRepo.deleteThread(ctx, c.address)) SmsBus.changed()
                else Toast.makeText(ctx, "Possible quand Téléphone est l'appli SMS par défaut", Toast.LENGTH_LONG).show()
            })
        }
    }
}
