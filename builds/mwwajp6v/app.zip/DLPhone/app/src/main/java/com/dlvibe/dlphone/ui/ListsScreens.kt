@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.dlvibe.dlphone.ui

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.CallLog
import android.provider.ContactsContract
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallMade
import androidx.compose.material.icons.filled.CallMissed
import androidx.compose.material.icons.filled.CallReceived
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Voicemail
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dlvibe.dlphone.CallEntry
import com.dlvibe.dlphone.Contact
import com.dlvibe.dlphone.Prefs
import com.dlvibe.dlphone.T9
import com.dlvibe.dlphone.ThemeEditorActivity
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val FR = Locale.FRENCH

fun dayLabel(t: Long): String {
    val c = Calendar.getInstance().apply { timeInMillis = t }
    val now = Calendar.getInstance()
    fun same(a: Calendar, b: Calendar) =
        a.get(Calendar.YEAR) == b.get(Calendar.YEAR) && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)
    if (same(c, now)) return "Aujourd'hui"
    now.add(Calendar.DAY_OF_YEAR, -1)
    if (same(c, now)) return "Hier"
    return SimpleDateFormat("EEEE d MMMM", FR).format(Date(t)).replaceFirstChar { it.uppercase() }
}

fun hourLabel(t: Long): String = SimpleDateFormat("HH:mm", FR).format(Date(t))

fun durationLabel(s: Long): String = when {
    s <= 0 -> ""
    s < 60 -> "$s s"
    s < 3600 -> "${s / 60} min ${"%02d".format(s % 60)} s"
    else -> "${s / 3600} h ${"%02d".format((s % 3600) / 60)} min"
}

private fun typeColor(type: Int, light: Boolean): Color {
    val c = when (type) {
        CallLog.Calls.MISSED_TYPE, CallLog.Calls.REJECTED_TYPE -> Color(0xFFF28B82)
        CallLog.Calls.INCOMING_TYPE -> Color(0xFF81C995)
        CallLog.Calls.OUTGOING_TYPE -> Color(0xFF78D9EC)
        else -> Color(0xFFFDD663)
    }
    return if (light) lerp(c, Color.Black, 0.35f) else c
}

private fun typeIcon(type: Int) = when (type) {
    CallLog.Calls.MISSED_TYPE, CallLog.Calls.REJECTED_TYPE -> Icons.Filled.CallMissed
    CallLog.Calls.INCOMING_TYPE -> Icons.Filled.CallReceived
    CallLog.Calls.OUTGOING_TYPE -> Icons.Filled.CallMade
    CallLog.Calls.VOICEMAIL_TYPE -> Icons.Filled.Voicemail
    else -> Icons.Filled.Block
}

fun safeStart(ctx: Context, i: Intent) {
    try {
        ctx.startActivity(i)
    } catch (_: Exception) {
        Toast.makeText(ctx, "Aucune appli pour cette action", Toast.LENGTH_SHORT).show()
    }
}

@Composable
fun RecentsScreen(calls: List<CallEntry>, onCall: (String) -> Unit, onChanged: () -> Unit) {
    val p = LocalPalette.current
    var filter by remember { mutableIntStateOf(0) }
    val labels = listOf("Tous", "Manqués", "Entrants", "Sortants", "Bloqués")
    val groups = remember(calls, filter) {
        calls.filter {
            when (filter) {
                1 -> it.type == CallLog.Calls.MISSED_TYPE || it.type == CallLog.Calls.REJECTED_TYPE
                2 -> it.type == CallLog.Calls.INCOMING_TYPE
                3 -> it.type == CallLog.Calls.OUTGOING_TYPE
                4 -> it.type == CallLog.Calls.BLOCKED_TYPE
                else -> true
            }
        }.groupBy { dayLabel(it.date) }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Récents", "${calls.size} appels dans le journal")
        Row(
            Modifier
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            labels.forEachIndexed { i, l ->
                FilterChip(
                    selected = filter == i,
                    onClick = { filter = i },
                    label = { Text(l) },
                    colors = FilterChipDefaults.filterChipColors(
                        containerColor = p.surface2, labelColor = p.text,
                        selectedContainerColor = p.accent, selectedLabelColor = p.onAccent
                    )
                )
            }
        }
        if (groups.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Aucun appel ici pour l'instant", color = p.muted)
            }
        } else {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
                groups.forEach { (label, list) ->
                    item(key = "h_$label") {
                        SectionLabel(label, Modifier.padding(start = 20.dp, top = 10.dp))
                    }
                    items(list, key = { it.id }) { e -> RecentRow(e, onCall, onChanged) }
                }
            }
        }
    }
}

@Composable
private fun RecentRow(e: CallEntry, onCall: (String) -> Unit, onChanged: () -> Unit) {
    val ctx = LocalContext.current
    val p = LocalPalette.current
    val clipboard = LocalClipboardManager.current
    var menu by remember { mutableStateOf(false) }
    val title = e.name ?: e.number.ifBlank { "Numéro masqué" }
    val tc = typeColor(e.type, p.light)
    Box {
        ListRow(
            title = title,
            leading = { Avatar(title, 44.dp, photo = e.photo, number = e.number) },
            subtitle = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(typeIcon(e.type), null, tint = tc, modifier = Modifier.size(14.dp))
                    val d = durationLabel(e.duration)
                    Text(
                        " " + hourLabel(e.date) + (if (d.isNotEmpty()) " · $d" else "") +
                                (if (e.name != null) " · ${e.number}" else ""),
                        color = p.muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
            },
            trailing = {
                if (e.number.isNotBlank()) IconButton(onClick = { onCall(e.number) }) {
                    Icon(Icons.Filled.Call, "Appeler", tint = p.accent)
                }
            },
            onClick = { if (e.number.isNotBlank()) onCall(e.number) },
            onLongClick = { if (e.number.isNotBlank()) menu = true }
        )
        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
            val blocked = Prefs.isBlocked(e.number)
            DropdownMenuItem(text = { Text("Personnaliser l'appel") }, onClick = {
                menu = false
                ThemeEditorActivity.open(ctx, e.number, e.name)
            })
            DropdownMenuItem(text = { Text("Envoyer un SMS") }, onClick = {
                menu = false
                safeStart(ctx, Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${e.number}")))
            })
            DropdownMenuItem(text = { Text("Copier le numéro") }, onClick = {
                menu = false
                clipboard.setText(AnnotatedString(e.number))
            })
            DropdownMenuItem(text = { Text(if (blocked) "Débloquer" else "Bloquer ce numéro") }, onClick = {
                menu = false
                if (blocked) Prefs.unblock(e.number) else Prefs.block(e.number)
                Toast.makeText(ctx, if (blocked) "Numéro débloqué" else "Numéro bloqué", Toast.LENGTH_SHORT).show()
                onChanged()
            })
            if (e.name == null) DropdownMenuItem(text = { Text("Ajouter aux contacts") }, onClick = {
                menu = false
                safeStart(ctx, Intent(Intent.ACTION_INSERT, ContactsContract.Contacts.CONTENT_URI)
                    .putExtra(ContactsContract.Intents.Insert.PHONE, e.number))
            })
        }
    }
}

@Composable
fun ContactsScreen(contacts: List<Contact>, onCall: (String) -> Unit, onChanged: () -> Unit) {
    val ctx = LocalContext.current
    val p = LocalPalette.current
    var q by remember { mutableStateOf("") }
    val shown = remember(q, contacts) {
        if (q.isBlank()) contacts else {
            val cq = T9.clean(q.trim())
            val dq = q.filter { it.isDigit() }
            contacts.filter { T9.clean(it.name).contains(cq) || (dq.isNotEmpty() && it.number.filter { d -> d.isDigit() }.contains(dq)) }
        }
    }
    val favs = remember(contacts) { contacts.filter { it.starred }.distinctBy { it.id } }
    val groups = remember(shown) {
        shown.groupBy { c -> c.name.firstOrNull()?.uppercaseChar()?.takeIf { it.isLetter() } ?: '#' }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Contacts", "${contacts.distinctBy { it.id }.size} contacts") {
            IconButton(onClick = { safeStart(ctx, Intent(Intent.ACTION_INSERT, ContactsContract.Contacts.CONTENT_URI)) }) {
                Icon(Icons.Filled.PersonAdd, "Nouveau contact", tint = p.accent)
            }
        }
        OutlinedTextField(
            value = q,
            onValueChange = { q = it },
            placeholder = { Text("Rechercher un nom ou un numéro") },
            leadingIcon = { Icon(Icons.Filled.Search, null) },
            singleLine = true,
            shape = RoundedCornerShape(28.dp),
            colors = dlTextFieldColors(),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp)
        )
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
            if (q.isBlank() && favs.isNotEmpty()) {
                item(key = "favs") {
                    Column {
                        SectionLabel("Favoris", Modifier.padding(start = 20.dp, top = 6.dp))
                        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            items(favs, key = { it.id }) { f ->
                                Column(
                                    Modifier
                                        .width(68.dp)
                                        .clickable { onCall(f.number) },
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Avatar(f.name, 58.dp, photo = f.photo, number = f.number)
                                    Text(f.name.substringBefore(' '), color = p.text, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                    }
                }
            }
            groups.forEach { (letter, list) ->
                item(key = "L_$letter") {
                    SectionLabel(letter.toString(), Modifier.padding(start = 20.dp, top = 8.dp))
                }
                items(list, key = { "${it.id}-${it.number}" }) { c -> ContactRow(c, onCall, onChanged) }
            }
        }
    }
}

@Composable
private fun ContactRow(c: Contact, onCall: (String) -> Unit, onChanged: () -> Unit) {
    val ctx = LocalContext.current
    val p = LocalPalette.current
    var menu by remember { mutableStateOf(false) }
    Box {
        ListRow(
            title = c.name,
            leading = { Avatar(c.name, 44.dp, photo = c.photo, number = c.number) },
            subtitle = { Text(c.number, color = p.muted, fontSize = 12.sp) },
            trailing = {
                IconButton(onClick = { onCall(c.number) }) { Icon(Icons.Filled.Call, "Appeler", tint = p.accent) }
            },
            onClick = { onCall(c.number) },
            onLongClick = { menu = true }
        )
        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
            DropdownMenuItem(text = { Text("Personnaliser l'appel") }, onClick = {
                menu = false
                ThemeEditorActivity.open(ctx, c.number, c.name)
            })
            DropdownMenuItem(text = { Text("Ouvrir la fiche") }, onClick = {
                menu = false
                safeStart(ctx, Intent(Intent.ACTION_VIEW, ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, c.id)))
            })
            DropdownMenuItem(text = { Text("Envoyer un SMS") }, onClick = {
                menu = false
                safeStart(ctx, Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${c.number}")))
            })
            val blocked = Prefs.isBlocked(c.number)
            DropdownMenuItem(text = { Text(if (blocked) "Débloquer" else "Bloquer") }, onClick = {
                menu = false
                if (blocked) Prefs.unblock(c.number) else Prefs.block(c.number)
                onChanged()
            })
        }
    }
}
