# SafeEmail Keeper
Gardez tous vos comptes email, clés de secours et méthodes de sécurité au même endroit, chiffrés sur votre téléphone.

## Fonctions
- 📧 **Comptes email** : ajoutez et modifiez vos adresses avec mot de passe et numéro de récupération.
- 🔑 **Clés de secours** : chaque clé est une puce que l'on peut ajouter, retirer ou mettre à jour.
- ✂️ **Barrer une clé** : un simple tap barre la clé déjà utilisée, avec une rayure animée.
- 🛡️ **Méthodes de sécurité** : notez 2FA, YubiKey, questions secrètes et email de secours.
- 👁️ **Mot de passe** : affichez, masquez ou copiez le mot de passe en un geste.
- 🔒 **Verrouillage** : l'appli s'ouvre avec le verrouillage du téléphone (empreinte, visage, schéma, PIN, mot de passe). Sans verrouillage, elle s'ouvre directement.
- 📜 **Journal** : suivez chaque action dans une frise animée.
- 📄 **Export PDF global** : un seul PDF élégant avec tous les comptes.
- 🗜️ **Export ZIP** : une archive avec un PDF stylé par email.

## Comment l'utiliser
1. Déverrouillez l'appli avec le verrouillage de votre téléphone.
2. Touchez le bouton + pour ajouter un compte.
3. Saisissez l'email, le mot de passe et le numéro de récupération.
4. Ajoutez vos clés de secours une à une.
5. Touchez une clé utilisée pour la barrer.
6. Ajoutez vos méthodes de sécurité.
7. Touchez Enregistrer pour valider.
8. Ouvrez l'onglet Journal pour revoir l'historique.
9. Ouvrez Export pour créer le PDF global ou le ZIP.

## Astuces
> Appui long sur une clé : elle est supprimée.
> Masquez les mots de passe avant de partager un PDF.

## Captures
- 01-accueil.png : liste des comptes
- 02-compte.png : saisie d'un compte
- 03-cles.png : clés de secours, une barrée
- 04-journal.png : journal d'activités
- 05-export.png : export PDF et ZIP
