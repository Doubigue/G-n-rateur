package com.safeemail.keeper
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import java.io.*
import java.util.zip.*

object PdfExport {
    private const val W = 595; private const val H = 842
    private fun paint(size: Float, color: Int, bold: Boolean = false) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = size; this.color = color; typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT }

    private fun page(doc: PdfDocument, n: Int, title: String): Canvas {
        val c = doc.startPage(PdfDocument.PageInfo.Builder(W, H, n).create()).let { pageRef = it; it.canvas }
        c.drawColor(Color.parseColor("#0B0F1A"))
        c.drawRect(0f, 0f, W.toFloat(), 90f, Paint().apply { shader = LinearGradient(0f, 0f, W.toFloat(), 0f, Color.parseColor("#7C3AED"), Color.parseColor("#06B6D4"), Shader.TileMode.CLAMP) })
        c.drawText("SafeEmail Keeper", 32f, 42f, paint(24f, Color.WHITE, true))
        c.drawText(title, 32f, 68f, paint(13f, Color.parseColor("#E0F2FE")))
        return c
    }
    private var pageRef: PdfDocument.Page? = null

    private fun drawAccounts(doc: PdfDocument, list: List<Account>, hide: Boolean, title: String) {
        var n = 1; var c = page(doc, n, title); var y = 125f
        for (a in list) {
            val need = 150f + a.keys.size * 20f + a.methods.size * 18f
            if (y + need > H - 30) { doc.finishPage(pageRef!!); c = page(doc, ++n, title); y = 125f }
            c.drawRoundRect(24f, y - 22f, W - 24f, y + need - 30f, 16f, 16f, Paint().apply { color = Color.parseColor("#151B2E") })
            c.drawText(a.email, 40f, y, paint(17f, Color.WHITE, true)); y += 24f
            c.drawText("Mot de passe : " + if (hide) "••••••••••" else a.password, 40f, y, paint(13f, Color.parseColor("#94A3B8"))); y += 20f
            c.drawText("Récupération : " + a.phone.ifBlank { "—" }, 40f, y, paint(13f, Color.parseColor("#94A3B8"))); y += 24f
            c.drawText("CLÉS DE SECOURS", 40f, y, paint(11f, Color.parseColor("#06B6D4"), true)); y += 18f
            for (k in a.keys) {
                val p = paint(13f, if (k.used) Color.parseColor("#64748B") else Color.parseColor("#A7F3D0"))
                c.drawText(k.text + if (k.used) "   (utilisée)" else "   (valide)", 48f, y, p)
                if (k.used) c.drawLine(48f, y - 4f, 48f + p.measureText(k.text), y - 4f, Paint().apply { color = Color.parseColor("#F43F5E"); strokeWidth = 1.6f })
                y += 20f }
            y += 6f; c.drawText("SÉCURITÉ", 40f, y, paint(11f, Color.parseColor("#A78BFA"), true)); y += 18f
            for (m in a.methods) { c.drawText("• $m", 48f, y, paint(13f, Color.WHITE)); y += 18f }
            y += 40f
        }
        doc.finishPage(pageRef!!)
    }

    fun bytes(list: List<Account>, hide: Boolean, title: String): ByteArray {
        val doc = PdfDocument(); drawAccounts(doc, list, hide, title)
        return ByteArrayOutputStream().also { doc.writeTo(it); doc.close() }.toByteArray()
    }

    fun share(ctx: Context, list: List<Account>, hide: Boolean, zip: Boolean) {
        val f = File(ctx.cacheDir, if (zip) "comptes.zip" else "comptes.pdf")
        if (zip) ZipOutputStream(f.outputStream()).use { z -> list.forEach { a ->
            z.putNextEntry(ZipEntry(a.email.replace(Regex("[^A-Za-z0-9@._-]"), "_") + ".pdf"))
            z.write(bytes(listOf(a), hide, a.email)); z.closeEntry() } }
        else f.writeBytes(bytes(list, hide, "Export global — ${list.size} comptes"))
        val uri = FileProvider.getUriForFile(ctx, "com.safeemail.keeper.files", f)
        ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType(if (zip) "application/zip" else "application/pdf")
            .putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Exporter"))
    }
}
