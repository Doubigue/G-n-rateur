package com.safeemail.keeper
import android.content.*
import android.os.Bundle
import android.view.HapticFeedbackConstants
import androidx.fragment.app.FragmentActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK
import androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import android.provider.Settings
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.input.*
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*

val BG = Color(0xFF0B0F1A); val Card = Color(0xFF151B2E); val Violet = Color(0xFF7C3AED)
val Cyan = Color(0xFF06B6D4); val Rose = Color(0xFFF43F5E); val Mint = Color(0xFF34D399); val Muted = Color(0xFF94A3B8)
val Neon = Brush.horizontalGradient(listOf(Violet, Cyan))

class MainActivity : FragmentActivity() {
    override fun onCreate(s: Bundle?) { super.onCreate(s)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        val store = Store(this)
        setContent { MaterialTheme(colorScheme = darkColorScheme(background = BG, surface = Card, primary = Cyan)) {
            Surface(Modifier.fillMaxSize(), color = BG) { Gate(this) { App(store) } } } } }
}

@Composable fun Glass(mod: Modifier = Modifier, c: @Composable ColumnScope.() -> Unit) =
    Column(mod.clip(RoundedCornerShape(20.dp)).background(Color(0x22FFFFFF))
        .border(1.dp, Brush.linearGradient(listOf(Violet.copy(.7f), Cyan.copy(.3f))), RoundedCornerShape(20.dp)).padding(16.dp), content = c)

@Composable fun App(store: Store) {
    var accounts by remember { mutableStateOf(store.accounts()) }
    var logs by remember { mutableStateOf(store.logs()) }
    var tab by remember { mutableStateOf(0) }
    var editing by remember { mutableStateOf<Account?>(null) }
    var saved by remember { mutableStateOf(false) }
    val ctx = LocalContext.current; val view = LocalView.current
    fun persist(l: List<Account>, msg: String) { accounts = l; store.save(l); store.log(msg); logs = store.logs() }

    Box(Modifier.fillMaxSize().systemBarsPadding()) {
        Column(Modifier.fillMaxSize()) {
            Text("SafeEmail Keeper", Modifier.padding(20.dp, 16.dp), fontSize = 26.sp, fontWeight = FontWeight.Bold,
                style = androidx.compose.ui.text.TextStyle(brush = Neon))
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Comptes", "Journal", "Export").forEachIndexed { i, t ->
                    FilterChip(tab == i, { tab = i; view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP) }, { Text(t) }) } }
            AnimatedContent(tab, transitionSpec = { fadeIn(tween(300)) + slideInVertically { it / 12 } togetherWith fadeOut(tween(150)) }) { t ->
                when (t) {
                    0 -> LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(accounts, key = { it.id }) { a ->
                            Glass(Modifier.fillMaxWidth().clickable { editing = a }) {
                                Text(a.email, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                                Text("${a.keys.count { !it.used }}/${a.keys.size} clés valides · ${a.methods.size} méthodes", color = Muted, fontSize = 13.sp)
                                Text("Récup. ${a.phone.ifBlank { "—" }}", color = Cyan, fontSize = 13.sp) } } }
                    1 -> LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp)) {
                        itemsIndexed(logs) { i, l ->
                            var vis by remember { mutableStateOf(false) }; LaunchedEffect(Unit) { kotlinx.coroutines.delay(i * 40L); vis = true }
                            AnimatedVisibility(vis, enter = fadeIn() + slideInHorizontally { -it / 3 }) {
                                Row(Modifier.padding(vertical = 6.dp)) {
                                    Box(Modifier.padding(top = 6.dp).size(10.dp).clip(CircleShape).background(Neon))
                                    Spacer(Modifier.width(12.dp))
                                    Column { Text(l.text); Text(l.time, color = Muted, fontSize = 12.sp) } } } } }
                    else -> Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        var hide by remember { mutableStateOf(true) }
                        Row(verticalAlignment = Alignment.CenterVertically) { Switch(hide, { hide = it }); Spacer(Modifier.width(8.dp)); Text("Masquer les mots de passe") }
                        Button({ PdfExport.share(ctx, accounts, hide, false); store.log("Export PDF global"); logs = store.logs() }, Modifier.fillMaxWidth()) { Icon(Icons.Default.PictureAsPdf, null); Text("  PDF global") }
                        Button({ PdfExport.share(ctx, accounts, hide, true); store.log("Export ZIP (1 PDF / compte)"); logs = store.logs() }, Modifier.fillMaxWidth()) { Icon(Icons.Default.FolderZip, null); Text("  ZIP : un PDF par email") } } } }
        }
        if (tab == 0) FloatingActionButton({ editing = Account(email = "", password = "") }, Modifier.align(Alignment.BottomEnd).padding(20.dp), containerColor = Violet) { Icon(Icons.Default.Add, "Ajouter") }
        AnimatedVisibility(editing != null, enter = slideInVertically { it } + fadeIn(), exit = slideOutVertically { it } + fadeOut()) {
            editing?.let { src -> Editor(src, { editing = null }, { a ->
                val isNew = accounts.none { it.id == a.id }
                persist(if (isNew) accounts + a else accounts.map { if (it.id == a.id) a else it }, (if (isNew) "Compte ajouté : " else "Compte mis à jour : ") + a.email)
                editing = null; saved = true }, { a -> persist(accounts.filter { it.id != a.id }, "Compte supprimé : ${a.email}"); editing = null }) } }
        AnimatedVisibility(saved, enter = scaleIn(spring(Spring.DampingRatioMediumBouncy)) + fadeIn(), exit = fadeOut(), modifier = Modifier.align(Alignment.Center)) {
            LaunchedEffect(saved) { kotlinx.coroutines.delay(1100); saved = false }
            Icon(Icons.Default.CheckCircle, null, Modifier.size(96.dp).background(Color(0xCC000000), CircleShape).padding(8.dp), tint = Mint) }
    }
}

@OptIn(ExperimentalLayoutApi::class, ExperimentalFoundationApi::class)
@Composable fun Editor(src: Account, onClose: () -> Unit, onSave: (Account) -> Unit, onDelete: (Account) -> Unit) {
    var email by remember { mutableStateOf(src.email) }; var pwd by remember { mutableStateOf(src.password) }
    var show by remember { mutableStateOf(false) }; var phone by remember { mutableStateOf(src.phone) }
    var keys by remember { mutableStateOf(src.keys) }; var newKey by remember { mutableStateOf("") }
    var methods by remember { mutableStateOf(src.methods) }; var newM by remember { mutableStateOf("") }
    val cb = LocalClipboardManager.current; val view = LocalView.current
    Column(Modifier.fillMaxSize().background(BG).systemBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row { IconButton(onClose) { Icon(Icons.Default.Close, null) }; Text("Compte email", Modifier.padding(top = 12.dp), fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        OutlinedTextField(email, { email = it }, Modifier.fillMaxWidth(), label = { Text("Adresse email") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email))
        OutlinedTextField(pwd, { pwd = it }, Modifier.fillMaxWidth(), label = { Text("Mot de passe") },
            visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
            trailingIcon = { Row { IconButton({ show = !show }) { Icon(if (show) Icons.Default.VisibilityOff else Icons.Default.Visibility, null) }
                IconButton({ cb.setText(androidx.compose.ui.text.AnnotatedString(pwd)) }) { Icon(Icons.Default.ContentCopy, null) } } })
        OutlinedTextField(phone, { phone = it }, Modifier.fillMaxWidth(), label = { Text("Numéro de récupération" ) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
        Text("Clés de secours — touchez pour barrer", color = Cyan, fontSize = 13.sp)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            keys.forEachIndexed { i, k ->
                val col by animateColorAsState(if (k.used) Color(0xFF2A1A24) else Color(0xFF12332B), tween(350), label = "c")
                val strike by animateFloatAsState(if (k.used) 1f else 0f, tween(450), label = "s")
                Box(Modifier.clip(RoundedCornerShape(50)).background(col).drawWithContent { drawContent()
                    if (strike > 0f) drawLine(Rose, Offset(12f, size.height / 2), Offset(12f + (size.width - 24f) * strike, size.height / 2), 4f) }
                    .combinedClickable(onClick = { view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS); keys = keys.toMutableList().also { it[i] = k.copy(used = !k.used) } },
                        onLongClick = { keys = keys.filterIndexed { j, _ -> j != i } }).padding(14.dp, 8.dp)) {
                    Text(k.text, color = if (k.used) Muted else Mint, fontSize = 14.sp) } } }
        OutlinedTextField(newKey, { newKey = it }, Modifier.fillMaxWidth(), label = { Text("Ajouter une clé (appui long = supprimer)") },
            trailingIcon = { IconButton({ if (newKey.isNotBlank()) { keys = keys + Key(newKey.trim()); newKey = "" } }) { Icon(Icons.Default.Add, null) } })
        Text("Autres méthodes de sécurité", color = Cyan, fontSize = 13.sp)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { methods.forEach { m -> AssistChip({ methods = methods - m }, { Text(m) }) } }
        OutlinedTextField(newM, { newM = it }, Modifier.fillMaxWidth(), label = { Text("2FA, YubiKey, email de secours…") },
            trailingIcon = { IconButton({ if (newM.isNotBlank()) { methods = methods + newM.trim(); newM = "" } }) { Icon(Icons.Default.Add, null) } })
        Button({ onSave(src.copy(email = email.trim(), password = pwd, phone = phone, keys = keys, methods = methods)) }, Modifier.fillMaxWidth().height(52.dp), enabled = email.isNotBlank(),
            colors = ButtonDefaults.buttonColors(containerColor = Violet)) { Text("Enregistrer") }
        if (src.email.isNotBlank()) TextButton({ onDelete(src) }, Modifier.fillMaxWidth()) { Text("Supprimer ce compte", color = Rose) }
    }
}

@Composable fun Gate(act: FragmentActivity, content: @Composable () -> Unit) {
    var unlocked by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    val auth = BIOMETRIC_WEAK or DEVICE_CREDENTIAL  // empreinte, visage, schéma, PIN, mot de passe du téléphone
    fun prompt() {
        if (busy) return
        when (BiometricManager.from(act).canAuthenticate(auth)) {
            BiometricManager.BIOMETRIC_SUCCESS -> {}
            BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED, BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE -> { unlocked = true; return }  // téléphone sans verrouillage : l'appli s'ouvre
            else -> { msg = "Verrouillage momentanément indisponible. Réessayez."; return }
        }
        busy = true; msg = ""
        BiometricPrompt(act, ContextCompat.getMainExecutor(act), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult) { busy = false; unlocked = true }
            override fun onAuthenticationError(code: Int, e: CharSequence) { busy = false; msg = e.toString() }
        }).authenticate(BiometricPrompt.PromptInfo.Builder().setTitle("SafeEmail Keeper")
            .setSubtitle("Déverrouillez pour accéder à vos comptes").setAllowedAuthenticators(auth).build())
    }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val ob = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_START && !unlocked) prompt()
            if (e == Lifecycle.Event.ON_STOP && !busy) unlocked = false }
        owner.lifecycle.addObserver(ob); onDispose { owner.lifecycle.removeObserver(ob) }
    }
    if (unlocked) content() else Column(Modifier.fillMaxSize().padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Icon(Icons.Default.Lock, null, Modifier.size(88.dp), tint = Cyan)
        Spacer(Modifier.height(16.dp))
        Text("SafeEmail Keeper", fontSize = 26.sp, fontWeight = FontWeight.Bold, style = androidx.compose.ui.text.TextStyle(brush = Neon))
        if (msg.isNotBlank()) Text(msg, Modifier.padding(top = 12.dp), color = Muted, fontSize = 13.sp)
        Button({ prompt() }, Modifier.padding(top = 24.dp), colors = ButtonDefaults.buttonColors(containerColor = Violet)) { Text("Déverrouiller") }
        TextButton({ act.startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS)) }) { Text("Réglages de sécurité") }
    }
}
