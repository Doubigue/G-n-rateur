import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:share_plus/share_plus.dart';
import '../services/background_service.dart';
import '../services/camera_host.dart';
import '../services/update_service.dart';

class CameraScreen extends StatefulWidget {
  const CameraScreen({super.key});
  @override
  State<CameraScreen> createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen> {
  final host = CameraHost();
  String? error;

  @override
  void initState() {
    super.initState();
    UpdateService.enabled = false;
    _boot();
  }

  Future<void> _boot() async {
    try {
      if (!(await Permission.camera.request()).isGranted) throw 'Permission caméra refusée';
      await BackgroundService.requestPermissions();
      await BackgroundService.start(); // service AVANT d'ouvrir la caméra
      await host.start();
      if (mounted) setState(() {});
    } catch (e) {
      if (mounted) setState(() => error = '$e');
    }
  }

  @override
  void dispose() {
    UpdateService.enabled = true;
    host.stop();
    BackgroundService.stop();
    super.dispose();
  }

  String get _pretty {
    final c = host.code;
    return c == null ? '--- ---' : '${c.substring(0, 3)}-${c.substring(3)}';
  }

  void _blackout() {
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    Navigator.push(
      context,
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => GestureDetector(
          behavior: HitTestBehavior.opaque,
          onDoubleTap: () => Navigator.pop(context),
          child: const ColoredBox(
            color: Colors.black,
            child: Center(
              child: Text('Double-tap pour réveiller',
                  style: TextStyle(color: Color(0xFF1E1E1E))),
            ),
          ),
        ),
      ),
    ).then((_) => SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge));
  }

  static const _labels = {
    HostStatus.starting: 'Démarrage...',
    HostStatus.waiting: 'En attente de connexion...',
    HostStatus.connecting: 'Connexion en cours...',
    HostStatus.live: 'En direct',
    HostStatus.error: 'Erreur',
  };

  @override
  Widget build(BuildContext context) {
    return WithForegroundTask(
      child: PopScope(
        canPop: false, // retour = mise en arrière-plan, le service continue
        onPopInvokedWithResult: (_, __) => FlutterForegroundTask.minimizeApp(),
        child: Scaffold(
          appBar: AppBar(title: const Text('Mode Caméra')),
          body: SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: error != null
                  ? Center(child: Text(error!, textAlign: TextAlign.center))
                  : Column(children: [
                      ValueListenableBuilder(
                        valueListenable: host.status,
                        builder: (_, s, __) => Chip(
                          avatar: Icon(Icons.circle, size: 12,
                              color: s == HostStatus.live ? Colors.redAccent : Colors.amber),
                          label: Text(_labels[s]!),
                        ),
                      ),
                      const SizedBox(height: 16),
                      FittedBox(
                        child: Text(_pretty,
                            style: const TextStyle(
                                fontSize: 64, fontWeight: FontWeight.w800, letterSpacing: 6)),
                      ),
                      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                        TextButton.icon(
                          icon: const Icon(Icons.copy),
                          label: const Text('Copier'),
                          onPressed: host.code == null
                              ? null
                              : () {
                                  Clipboard.setData(ClipboardData(text: host.code!));
                                  ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(content: Text('Code copié')));
                                },
                        ),
                        TextButton.icon(
                          icon: const Icon(Icons.share),
                          label: const Text('Partager'),
                          onPressed: host.code == null
                              ? null
                              : () => Share.share('Code Sentinel Cam : $_pretty'),
                        ),
                      ]),
                      const SizedBox(height: 12),
                      Expanded(
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(16),
                          child: ColoredBox(
                            color: Colors.black,
                            child: RTCVideoView(host.preview,
                                objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitContain),
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      Row(children: [
                        Expanded(
                          child: FilledButton.tonalIcon(
                            icon: const Icon(Icons.screen_lock_portrait),
                            label: const Text('Écran noir'),
                            onPressed: _blackout,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: FilledButton.icon(
                            style: FilledButton.styleFrom(backgroundColor: Colors.red.shade700),
                            icon: const Icon(Icons.stop),
                            label: const Text('Arrêter'),
                            onPressed: () => Navigator.of(context).pop(),
                          ),
                        ),
                      ]),
                    ]),
            ),
          ),
        ),
      ),
    );
  }
}
