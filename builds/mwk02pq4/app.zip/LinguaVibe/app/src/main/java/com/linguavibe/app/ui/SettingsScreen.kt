package com.linguavibe.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linguavibe.app.data.Languages
import com.linguavibe.app.speech.ElevenLabs
import com.linguavibe.app.speech.ElevenVoice
import kotlinx.coroutines.launch

/** Paramètres : clé API ElevenLabs, choix de la voix réaliste, cache audio. */
@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val speaker = LocalSpeaker.current
    val settings = speaker.settings
    val scope = rememberCoroutineScope()

    var keyInput by remember { mutableStateOf(settings.apiKey) }
    var voiceInput by remember { mutableStateOf(settings.voiceId) }
    var showKey by remember { mutableStateOf(false) }
    var voices by remember { mutableStateOf<List<ElevenVoice>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var cacheVersion by remember { mutableIntStateOf(0) }
    val cacheMb = remember(cacheVersion) { ElevenLabs.cacheSizeMb(context) }

    Column(Modifier.fillMaxSize()) {
        TopBar("Paramètres", "Voix réaliste ElevenLabs", IndigoDark, onBack)
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            CardBox {
                Text("Voix réaliste multilingue", fontWeight = FontWeight.Bold, color = Ink)
                Text(
                    "Avec une clé API ElevenLabs, les mots, les exemples et les dialogues sont lus par une voix " +
                        "naturelle dans toutes les langues. Sans clé (ou sans connexion), l'application utilise " +
                        "la voix du téléphone.\n" +
                        "• Créez la clé sur elevenlabs.io (Paramètres › Clés API).\n" +
                        "• Chaque phrase n'est demandée qu'une fois, puis relue depuis le téléphone.\n" +
                        "• La clé reste sur ce téléphone ; elle n'est envoyée qu'à ElevenLabs.",
                    fontSize = 14.sp, color = InkSoft
                )
            }

            CardBox {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Utiliser la voix ElevenLabs", fontWeight = FontWeight.Bold, color = Ink,
                        modifier = Modifier.weight(1f)
                    )
                    Switch(checked = settings.enabled, onCheckedChange = { settings.updateEnabled(it) })
                }
                OutlinedTextField(
                    value = keyInput,
                    onValueChange = { keyInput = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Clé API ElevenLabs") },
                    visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        settings.updateApiKey(keyInput)
                        if (settings.apiKey.isNotBlank()) settings.updateEnabled(true)
                        message = if (settings.apiKey.isBlank()) "Clé effacée." else "Clé enregistrée."
                    }) { Text("Enregistrer") }
                    TextButton(onClick = { showKey = !showKey }) { Text(if (showKey) "Masquer" else "Afficher") }
                }
            }

            CardBox {
                Text("Voix", fontWeight = FontWeight.Bold, color = Ink)
                if (settings.voiceId.isNotBlank()) {
                    Chip("✅ Voix choisie : ${settings.voiceName.ifBlank { settings.voiceId }}", Good)
                } else {
                    Chip("Aucune voix choisie", Warn)
                }
                OutlinedButton(
                    enabled = !loading && settings.apiKey.isNotBlank(),
                    onClick = {
                        scope.launch {
                            loading = true
                            message = "Chargement des voix…"
                            try {
                                voices = ElevenLabs.listVoices(settings.apiKey)
                                message = if (voices.isEmpty()) "Aucune voix sur ce compte." else "Touchez une voix pour la choisir."
                            } catch (e: Exception) {
                                message = "❌ ${e.message ?: "Impossible de charger les voix"}"
                            } finally {
                                loading = false
                            }
                        }
                    }
                ) { Text("📋 Charger mes voix") }
                voices.forEach { voice ->
                    val selected = voice.id == settings.voiceId
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (selected) Good.copy(alpha = 0.14f) else Cream)
                            .clickable {
                                settings.updateVoice(voice.id, voice.name)
                                voiceInput = voice.id
                            }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(voice.name, fontWeight = FontWeight.SemiBold, color = Ink)
                            if (voice.category.isNotBlank()) Text(voice.category, fontSize = 12.sp, color = InkSoft)
                        }
                        if (selected) Text("✅")
                    }
                }
                OutlinedTextField(
                    value = voiceInput,
                    onValueChange = { voiceInput = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("…ou collez un identifiant de voix") }
                )
                TextButton(onClick = {
                    settings.updateVoice(voiceInput, "")
                    message = "Voix enregistrée."
                }) { Text("Utiliser cet identifiant") }
            }

            CardBox {
                Text("Modèle", fontWeight = FontWeight.Bold, color = Ink)
                listOf(
                    ElevenLabs.MODEL_QUALITY to "Qualité maximale (multilingue v2)",
                    ElevenLabs.MODEL_FAST to "Rapide et économique (flash v2.5)"
                ).forEach { (id, label) ->
                    val selected = settings.model == id
                    Text(
                        (if (selected) "🔘  " else "⚪  ") + label,
                        color = Ink,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (selected) Indigo.copy(alpha = 0.10f) else Color.Transparent)
                            .clickable { settings.updateModel(id) }
                            .padding(12.dp)
                    )
                }
            }

            CardBox {
                Text("Essayer la voix", fontWeight = FontWeight.Bold, color = Ink)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        speaker.speak("Hola, bienvenido a tu clase de español.", Languages.byCode("es").locale)
                    }) { Text("🇪🇸") }
                    Button(onClick = {
                        speaker.speak("Hello, welcome to your English lesson.", Languages.byCode("en").locale)
                    }) { Text("🇬🇧") }
                    Button(onClick = {
                        speaker.speak("Здравствуйте, добро пожаловать на урок.", Languages.byCode("ru").locale)
                    }) { Text("🇷🇺") }
                    Button(onClick = {
                        speaker.speak("Olá, bem-vindo à sua aula de português.", Languages.byCode("pt").locale)
                    }) { Text("🇧🇷") }
                }
                if (!settings.ready) {
                    Text(
                        "Voix du téléphone utilisée : activez l'option, enregistrez une clé et choisissez une voix.",
                        fontSize = 13.sp, color = InkSoft
                    )
                }
                speaker.lastError?.let { Text("⚠️ $it", fontSize = 13.sp, color = Bad) }
            }

            CardBox {
                Text("Audio enregistré : $cacheMb Mo", color = Ink)
                TextButton(onClick = {
                    speaker.stop()
                    ElevenLabs.clearCache(context)
                    cacheVersion++
                }) { Text("🗑 Vider l'audio enregistré", color = Bad) }
            }

            message?.let { Text(it, fontSize = 14.sp, color = Ink) }
        }
    }
}
