package com.linguavibe.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.linguavibe.app.data.ProgressStore
import com.linguavibe.app.speech.Speaker
import com.linguavibe.app.speech.VoskManager
import com.linguavibe.app.ui.AppRoot
import com.linguavibe.app.ui.LinguaTheme

class MainActivity : ComponentActivity() {
    private lateinit var speaker: Speaker

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        speaker = Speaker(this)
        val progress = ProgressStore(this)
        setContent {
            LinguaTheme {
                AppRoot(speaker, progress)
            }
        }
    }

    override fun onStop() {
        super.onStop()
        // On libère le micro quand l'application passe en arrière-plan.
        VoskManager.cancel()
        speaker.stop()
    }

    override fun onDestroy() {
        speaker.shutdown()
        super.onDestroy()
    }
}
