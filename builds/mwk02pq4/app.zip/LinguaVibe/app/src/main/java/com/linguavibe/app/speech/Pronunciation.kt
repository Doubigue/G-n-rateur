package com.linguavibe.app.speech

import java.text.Normalizer
import kotlin.math.max
import kotlin.math.min

enum class WordStatus { OK, CLOSE, MISSED }

data class WordResult(val word: String, val status: WordStatus, val heard: String?)

data class PronunciationResult(val words: List<WordResult>, val score: Int, val heardText: String) {
    val feedback: String
        get() = when {
            heardText.isBlank() -> "Je n'ai rien entendu. Rapprochez le micro et réessayez."
            score >= 90 -> "Excellent ! Prononciation très claire."
            score >= 70 -> "Bien ! Retravaillez les mots en orange ou en rouge."
            score >= 40 -> "Pas mal. Écoutez le modèle au ralenti puis répétez."
            else -> "Écoutez d'abord la phrase, puis répétez lentement mot par mot."
        }
}

/**
 * Corrige la prononciation en comparant la phrase attendue avec ce que
 * le moteur Vosk a réellement compris (alignement mot à mot).
 */
object Pronunciation {

    private val punctuation = Regex("[\\p{P}\\p{S}]")
    private val marks = Regex("\\p{Mn}+")
    private val spaces = Regex("\\s+")

    /** Minuscules, sans ponctuation ; les accents sont conservés. */
    fun clean(text: String): String =
        punctuation.replace(text.lowercase(), " ").replace(spaces, " ").trim()

    /** Forme « tolérante » : sans accents ni signes diacritiques (y compris les voyelles arabes). */
    fun loose(text: String): String {
        val decomposed = Normalizer.normalize(clean(text), Normalizer.Form.NFD)
        return marks.replace(decomposed, "")
            .replace("ـ", "")                 // tatweel arabe
            .replace(Regex("[آأإ]"), "ا") // variantes de l'alif
            .replace(spaces, " ")
            .trim()
    }

    /**
     * Clé de comparaison pour les réponses écrites : sans accents ni tons,
     * et sans espaces pour le chinois (caractères ou pinyin, « ni hao » = « nihao »).
     */
    fun matchKey(text: String, lang: String): String {
        val key = loose(text)
        return if (lang == "zh") key.replace(" ", "") else key
    }

    private fun tokens(text: String, lang: String): List<String> {
        val c = clean(text)
        if (c.isEmpty()) return emptyList()
        // Le chinois s'écrit sans espaces : on compare caractère par caractère.
        return if (lang == "zh") c.filter { !it.isWhitespace() }.map { it.toString() }
        else c.split(' ').filter { it.isNotEmpty() }
    }

    private fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = min(min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost)
            }
            val tmp = prev; prev = cur; cur = tmp
        }
        return prev[b.length]
    }

    private fun similarity(a: String, b: String): Float {
        val longest = max(a.length, b.length)
        if (longest == 0) return 1f
        return 1f - levenshtein(a, b).toFloat() / longest
    }

    fun evaluate(expected: String, heard: String, lang: String): PronunciationResult {
        val exp = tokens(expected, lang)
        val got = tokens(heard, lang)
        val expL = exp.map { loose(it) }
        val gotL = got.map { loose(it) }
        val n = exp.size
        val m = got.size
        if (n == 0) return PronunciationResult(emptyList(), 0, heard)

        // Alignement par programmation dynamique (distance d'édition sur les mots).
        val d = Array(n + 1) { FloatArray(m + 1) }
        for (i in 0..n) d[i][0] = i.toFloat()
        for (j in 0..m) d[0][j] = j.toFloat()
        for (i in 1..n) for (j in 1..m) {
            val sub = 1f - similarity(expL[i - 1], gotL[j - 1])
            d[i][j] = min(min(d[i - 1][j] + 1f, d[i][j - 1] + 1f), d[i - 1][j - 1] + sub)
        }

        val results = arrayOfNulls<WordResult>(n)
        var i = n
        var j = m
        while (i > 0) {
            if (j > 0) {
                val sim = similarity(expL[i - 1], gotL[j - 1])
                val diag = d[i - 1][j - 1] + (1f - sim)
                if (d[i][j] == diag && diag <= d[i - 1][j] + 1f && diag <= d[i][j - 1] + 1f) {
                    val status = when {
                        sim >= 0.999f -> WordStatus.OK
                        sim >= 0.6f -> WordStatus.CLOSE
                        else -> WordStatus.MISSED
                    }
                    results[i - 1] = WordResult(exp[i - 1], status, got[j - 1])
                    i--; j--
                    continue
                }
                if (d[i][j] == d[i][j - 1] + 1f) { // mot en trop
                    j--
                    continue
                }
            }
            results[i - 1] = WordResult(exp[i - 1], WordStatus.MISSED, null)
            i--
        }

        val words = results.map { it!! }
        val points = words.sumOf {
            when (it.status) {
                WordStatus.OK -> 1.0
                WordStatus.CLOSE -> 0.5
                WordStatus.MISSED -> 0.0
            }
        }
        // Légère pénalité si beaucoup de mots en trop ont été prononcés.
        val extra = max(0, m - n)
        val raw = points / n - 0.05 * extra
        val score = (raw.coerceIn(0.0, 1.0) * 100).toInt()
        return PronunciationResult(words, score, heard)
    }
}
