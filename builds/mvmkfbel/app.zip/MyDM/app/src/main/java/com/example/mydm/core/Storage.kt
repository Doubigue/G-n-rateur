package com.example.mydm.core

import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore

/** Dossiers de l'application : Download/<racine>/<dossier>[/<sous-dossier>] */
enum class Category(val label: String, val folder: String, val icon: String) {
    VIDEO_MADE("Vidéo made", "Vidéo made", "🎬"),   // Statuts (photos + vidéos)
    VIDEO("Vidéo", "Vidéo", "🎞️"),                  // vidéos téléchargées
    TORRENT("Torrent", "Torrent", "🧲"),            // vidéo, app, logiciel, document, jeux…
    DOCUMENTS("Documents", "Documents", "📄"),
    IMAGES("Images", "Images", "🖼️"),
    MUSIQUES("Musiques", "Musiques", "🎵"),
    AUTRES("Autres", "Autres", "📦")
}

internal val videoExt = setOf("mp4", "mkv", "webm", "mov", "avi", "m4v", "3gp", "ts", "flv", "wmv", "mpg", "mpeg")
internal val audioExt = setOf("mp3", "m4a", "aac", "ogg", "opus", "wav", "flac", "wma")
internal val imageExt = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "svg", "heic", "avif")
internal val docExt = setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "epub", "csv", "odt", "rtf", "md", "mobi")

internal val textExt = setOf("txt", "md", "csv", "log", "json", "xml", "srt", "vtt", "ini", "html", "htm", "yml", "yaml")
fun extOf(name: String) = name.substringAfterLast('.', "").lowercase()

fun categoryFor(name: String, mime: String? = null): Category {
    val e = extOf(name)
    return when {
        e in videoExt || mime?.startsWith("video/") == true -> Category.VIDEO
        e in audioExt || mime?.startsWith("audio/") == true -> Category.MUSIQUES
        e in imageExt || mime?.startsWith("image/") == true -> Category.IMAGES
        e in docExt -> Category.DOCUMENTS
        else -> Category.AUTRES
    }
}

/** Sous-dossier d'un fichier de torrent : Vidéos / Applications / Logiciels / Jeux / Documents / Musiques / Images / Autres. */
fun torrentSubFolder(name: String): String {
    val e = extOf(name)
    return when {
        e == "apk" || e == "xapk" || e == "apks" -> "Applications"
        e in setOf("exe", "msi", "dmg", "deb", "rpm", "appimage", "pkg") -> "Logiciels"
        e in setOf("iso", "nsp", "xci", "rom", "bin", "cue", "pak", "gba", "nds") -> "Jeux"
        else -> when (categoryFor(name)) {
            Category.VIDEO -> "Vidéos"; Category.MUSIQUES -> "Musiques"; Category.IMAGES -> "Images"
            Category.DOCUMENTS -> "Documents"; else -> "Autres"
        }
    }
}

data class LibFile(val uri: Uri, val name: String, val size: Long, val modified: Long, val mime: String?, val folder: String)

object Storage {
    fun rel(cat: Category, sub: String? = null): String =
        "${Environment.DIRECTORY_DOWNLOADS}/${Prefs.rootFolder}/${cat.folder}" + (sub?.let { "/$it" } ?: "")

    /** Crée une entrée MediaStore « en attente » ; à finaliser avec [finish]. */
    fun create(ctx: Context, name: String, mime: String?, relPath: String): Uri {
        val v = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            mime?.let { put(MediaStore.Downloads.MIME_TYPE, it) }
            put(MediaStore.Downloads.RELATIVE_PATH, relPath)
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        return ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)!!
    }

    fun finish(ctx: Context, uri: Uri) {
        ctx.contentResolver.update(uri, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
    }

    fun list(ctx: Context, cat: Category): List<LibFile> {
        val base = rel(cat) + "/"
        val out = mutableListOf<LibFile>()
        val proj = arrayOf(MediaStore.Downloads._ID, MediaStore.Downloads.DISPLAY_NAME, MediaStore.Downloads.SIZE,
            MediaStore.Downloads.DATE_MODIFIED, MediaStore.Downloads.MIME_TYPE, MediaStore.Downloads.RELATIVE_PATH)
        runCatching {
            ctx.contentResolver.query(MediaStore.Downloads.EXTERNAL_CONTENT_URI, proj,
                "${MediaStore.Downloads.RELATIVE_PATH} LIKE ?", arrayOf("$base%"),
                "${MediaStore.Downloads.DATE_MODIFIED} DESC")?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    out += LibFile(
                        Uri.withAppendedPath(MediaStore.Downloads.EXTERNAL_CONTENT_URI, id.toString()),
                        c.getString(1) ?: "?", c.getLong(2), c.getLong(3) * 1000, c.getString(4),
                        (c.getString(5) ?: "").removePrefix(base).trim('/')
                    )
                }
            }
        }
        return out
    }

    /** Espace libre / total du stockage principal. */
    fun space(): Pair<Long, Long> = runCatching {
        val f = android.os.StatFs(Environment.getExternalStorageDirectory().path)
        f.availableBytes to f.totalBytes
    }.getOrDefault(0L to 0L)

    fun count(ctx: Context, cat: Category): Int = list(ctx, cat).size
    fun delete(ctx: Context, f: LibFile) = runCatching { ctx.contentResolver.delete(f.uri, null, null) }.getOrDefault(0)
}
