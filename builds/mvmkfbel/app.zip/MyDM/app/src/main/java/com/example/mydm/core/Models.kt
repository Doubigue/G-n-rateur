package com.example.mydm.core

import android.net.Uri
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import java.util.UUID

enum class MediaType { VIDEO, HLS, AUDIO, APK, PDF, ARCHIVE, SUBTITLE }

data class DetectedMedia(
    val url: String, val type: MediaType, val pageUrl: String?, val pageTitle: String?,
    val userAgent: String, val cookies: String?, val referer: String?,
    val name: String? = null, val sizeBytes: Long? = null
)

object MediaDetector {
    private val extMap = mapOf(
        "mp4" to MediaType.VIDEO, "webm" to MediaType.VIDEO, "mkv" to MediaType.VIDEO,
        "m3u8" to MediaType.HLS, "mp3" to MediaType.AUDIO, "m4a" to MediaType.AUDIO,
        "apk" to MediaType.APK, "pdf" to MediaType.PDF,
        "zip" to MediaType.ARCHIVE, "rar" to MediaType.ARCHIVE,
        "vtt" to MediaType.SUBTITLE, "srt" to MediaType.SUBTITLE
    )
    fun detect(url: String): MediaType? {
        val path = Uri.parse(url).path ?: return null
        return extMap[path.lowercase().substringAfterLast('.', "")]
    }
}

enum class Status { QUEUED, RUNNING, PAUSED, MERGING, COMPLETED, FAILED }

@Entity(tableName = "tasks")
data class DownloadTask(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val url: String, val fileName: String, val mimeType: String?,
    val totalBytes: Long = -1, val status: Status = Status.QUEUED,
    val headersJson: String = "{}", val maxSegments: Int = 8,
    val resultUri: String? = null, val error: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val subFolder: String? = null,         // ex. nom d'une série => Vidéo/<série>/
    val durationSec: Long = 0              // durée de la vidéo (0 = inconnue)
)

@Entity(tableName = "segments", primaryKeys = ["taskId", "idx"])
data class Segment(val taskId: String, val idx: Int, val start: Long, val end: Long)

@Dao
interface DownloadDao {
    @Query("SELECT * FROM tasks ORDER BY createdAt DESC") fun observeTasks(): Flow<List<DownloadTask>>
    @Query("SELECT * FROM tasks WHERE id = :id") suspend fun task(id: String): DownloadTask?
    @Upsert suspend fun upsert(t: DownloadTask)
    @Query("UPDATE tasks SET status = :s, error = :e WHERE id = :id") suspend fun setStatus(id: String, s: Status, e: String?)
    @Query("SELECT * FROM segments WHERE taskId = :id ORDER BY idx") suspend fun segments(id: String): List<Segment>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertSegments(s: List<Segment>)
    @Query("DELETE FROM tasks WHERE id = :id") suspend fun delete(id: String)
    @Query("SELECT * FROM tasks WHERE status IN ('RUNNING','QUEUED','MERGING') ORDER BY createdAt") suspend fun active(): List<DownloadTask>
    @Query("SELECT COUNT(*) FROM tasks WHERE status IN ('RUNNING','QUEUED','MERGING')") fun observeActiveCount(): Flow<Int>
    @Query("DELETE FROM tasks WHERE status = 'COMPLETED'") suspend fun clearCompleted()
    @Query("DELETE FROM segments WHERE taskId = :id") suspend fun deleteSegments(id: String)
}

class Converters {
    @TypeConverter fun toStatus(v: String) = Status.valueOf(v)
    @TypeConverter fun fromStatus(s: Status) = s.name
}

@Database(entities = [DownloadTask::class, Segment::class], version = 3, exportSchema = false)
@TypeConverters(Converters::class)
abstract class AppDb : RoomDatabase() { abstract fun downloadDao(): DownloadDao }


// ───── Utilitaires de noms / tailles
fun cleanName(s: String): String =
    s.replace(Regex("[\\\\/:*?\"<>|\\n\\r]"), "_").trim().take(120)

fun DetectedMedia.displayName(): String {
    name?.takeIf { it.isNotBlank() }?.let { return it }
    // Vidéo / flux HLS d'un site : le nom du film (le fichier s'appelle « v.mp4 », « master.m3u8 »…)
    if ((type == MediaType.VIDEO || type == MediaType.HLS) && !pageTitle.isNullOrBlank())
        TitleCleaner.fileTitle(pageTitle, pageUrl).takeIf { it.isNotBlank() }?.let { return it }
    return Uri.parse(url).lastPathSegment?.takeIf { it.contains('.') }
        ?: pageTitle?.takeIf { it.isNotBlank() }
        ?: url.substringAfter("://").take(40)
}

fun fileNameFor(m: DetectedMedia): String {
    val known = mapOf(
        MediaType.VIDEO to listOf("mp4", "webm", "mkv", "m4v", "mov"),
        MediaType.AUDIO to listOf("mp3", "m4a", "aac", "ogg", "wav"),
        MediaType.HLS to listOf("mp4"), MediaType.APK to listOf("apk"),
        MediaType.PDF to listOf("pdf"), MediaType.ARCHIVE to listOf("zip", "rar", "7z"),
        MediaType.SUBTITLE to listOf("vtt", "srt")
    )
    val default = mapOf(MediaType.VIDEO to "mp4", MediaType.AUDIO to "mp3", MediaType.HLS to "mp4",
        MediaType.APK to "apk", MediaType.PDF to "pdf", MediaType.ARCHIVE to "zip", MediaType.SUBTITLE to "vtt")
    val base = cleanName(m.displayName()).ifBlank { "fichier" }
    val ext = base.substringAfterLast('.', "").lowercase()
    return if (ext in known.getValue(m.type)) base else base + "." + default.getValue(m.type)
}

/** 83 → « 1:23 » ; 3725 → « 1:02:05 » */
fun formatDuration(sec: Long): String {
    val s = sec.coerceAtLeast(0)
    val h = s / 3600; val mi = (s % 3600) / 60; val se = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, mi, se) else "%d:%02d".format(mi, se)
}

/** « • ⏱ 24:13 • reste 2:05 » (parties omises si inconnues). */
fun timingSuffix(durationSec: Long, etaSec: Long?): String = buildString {
    if (durationSec > 0) append(" • ⏱ ").append(formatDuration(durationSec))
    if (etaSec != null && etaSec > 0) append(" • reste ").append(formatDuration(etaSec))
}

fun etaSeconds(downloaded: Long, total: Long, speedBps: Long): Long? =
    if (total > 0 && speedBps > 0 && downloaded in 0 until total) (total - downloaded) / speedBps else null

fun formatSize(b: Long): String = when {
    b >= 1L shl 30 -> "%.2f Go".format(b / 1073741824.0)
    b >= 1L shl 20 -> "%.1f Mo".format(b / 1048576.0)
    else -> "${b / 1024} Ko"
}
