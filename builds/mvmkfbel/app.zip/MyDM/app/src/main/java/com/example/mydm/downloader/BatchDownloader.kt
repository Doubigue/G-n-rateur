package com.example.mydm.downloader

import com.example.mydm.App
import com.example.mydm.browser.EpisodeLink
import com.example.mydm.browser.PageScanner
import com.example.mydm.core.MediaResolver
import com.example.mydm.core.Prefs
import com.example.mydm.core.QualityOption
import com.example.mydm.core.cleanName
import com.example.mydm.ui.DownloadActions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.util.Locale

enum class BState { WAIT, SCAN, DONE, FAIL }

data class BatchItem(val ep: EpisodeLink, val state: BState, val note: String? = null)

/**
 * Télécharge toute une saison d'un coup : pour chaque épisode, la page est analysée en arrière-plan
 * (sans la lire), le meilleur flux est mis en file de téléchargement, dans un dossier au nom de la série.
 */
class BatchDownloader(private val app: App) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null

    val items = MutableStateFlow<List<BatchItem>>(emptyList())
    val series = MutableStateFlow("")
    val running = MutableStateFlow(false)

    fun start(seriesName: String, eps: List<EpisodeLink>) {
        if (eps.isEmpty()) return
        job?.cancel()
        series.value = seriesName
        items.value = eps.map { BatchItem(it, BState.WAIT) }
        running.value = true
        job = scope.launch {
            val gate = Semaphore(Prefs.seriesParallel.coerceAtLeast(1))
            try {
                coroutineScope {
                    eps.map { ep -> async { gate.withPermit { processOne(seriesName, ep) } } }.awaitAll()
                }
            } finally { running.value = false }
        }
    }

    fun cancel() {
        job?.cancel()
        running.value = false
        items.update { l -> l.map { if (it.state == BState.WAIT || it.state == BState.SCAN) it.copy(state = BState.FAIL, note = "Annulé") else it } }
    }

    fun clear() { if (!running.value) items.value = emptyList() }

    private fun set(ep: EpisodeLink, st: BState, note: String? = null) =
        items.update { l -> l.map { if (it.ep.url == ep.url) it.copy(state = st, note = note) else it } }

    private fun episodeName(series: String, ep: EpisodeLink): String = when {
        ep.season != null && ep.episode != null -> "$series " + String.format(Locale.ROOT, "S%02dE%02d", ep.season, ep.episode)
        ep.episode != null -> "$series - Épisode " + String.format(Locale.ROOT, "%02d", ep.episode)
        else -> "$series - ${ep.label}"
    }

    private suspend fun processOne(seriesName: String, ep: EpisodeLink) {
        set(ep, BState.SCAN)
        val name = cleanName(episodeName(seriesName, ep))
        val sub = if (Prefs.seriesFolders) cleanName(seriesName).ifBlank { "" }.ifEmpty { null }?.let { s -> ep.season?.let { n -> s + "/" + String.format(Locale.ROOT, "Saison %02d", n) } ?: s } else null
        try {
            val scan = PageScanner.scan(app, ep.url, null, true, autoPlayer = true)
            val best = PageScanner.pickBest(scan.media)
            if (best != null) {
                DownloadActions.queue(app, app, best, sub, name)
                set(ep, BState.DONE, if (best.type.name == "HLS") "Flux HLS" else "Fichier direct")
                return
            }
            // Repli : yt-dlp sait extraire de nombreux hébergeurs (lecteurs intégrés) au moment du téléchargement
            val emb = scan.embeds.firstOrNull { MediaResolver.isKnownHoster(it) }
            if (emb != null) {
                val id = app.downloadEngine.enqueueYt(emb, name, QualityOption("", null, false, "bv*+ba/b"), ep.url, null, sub)
                runCatching { DownloadService.start(app, id) }
                set(ep, BState.DONE, "via yt-dlp (lecteur intégré)")
            } else set(ep, BState.FAIL, if (scan.embeds.isEmpty()) "Aucun lecteur trouvé (page bloquée ?)" else "Flux vidéo introuvable (lecteur protégé)")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            set(ep, BState.FAIL, (e.message ?: "Erreur").take(80))
        }
    }
}
