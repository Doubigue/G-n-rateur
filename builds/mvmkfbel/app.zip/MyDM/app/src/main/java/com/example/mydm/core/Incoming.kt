package com.example.mydm.core

import android.content.Intent
import android.net.Uri
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Liens / fichiers / images reçus d'autres applications (VIEW, SEND, magnet, .torrent). */
object Incoming {
    var url by mutableStateOf<String?>(null)
    var torrent by mutableStateOf<String?>(null)
    var image by mutableStateOf<Uri?>(null)
    /** Fichier externe à lire dans la visionneuse intégrée (vidéo, audio, image, PDF, texte, APK…). */
    var file by mutableStateOf<ViewItem?>(null)
    lateinit var appContext: android.content.Context

    fun handle(i: Intent?) {
        i ?: return
        when (i.action) {
            Intent.ACTION_VIEW -> {
                val d = i.data ?: return
                when (d.scheme) {
                    "magnet" -> torrent = d.toString()
                    "content", "file" -> {
                        val t = i.type ?: ""
                        val isTorrent = t == "application/x-bittorrent" || (d.lastPathSegment ?: "").endsWith(".torrent", true)
                        if (isTorrent) torrent = d.toString() else file = Viewer.fromExternal(appContext, d, t)
                    }
                    else -> url = d.toString()
                }
            }
            Intent.ACTION_SEND -> {
                val t0 = i.type ?: ""
                if (!t0.startsWith("image/") && !t0.startsWith("text/") && i.hasExtra(Intent.EXTRA_STREAM)) {
                    @Suppress("DEPRECATION") val u = i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
                    if (u != null) file = Viewer.fromExternal(appContext, u, t0)
                } else if (t0.startsWith("image/")) {
                    @Suppress("DEPRECATION") image = i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
                } else {
                    val t = i.getStringExtra(Intent.EXTRA_TEXT)?.trim() ?: return
                    val magnet = Regex("magnet:\\?\\S+").find(t)?.value
                    if (magnet != null) torrent = magnet
                    else url = Regex("https?://\\S+").find(t)?.value ?: Prefs.resolveInput(t)
                }
            }
        }
    }
}

/** Sélecteur de fichiers des pages web (<input type=file>) ; sert aussi à la recherche par photo. */
object FileChooserBridge {
    /** Photo choisie pour la recherche : renvoyée automatiquement au prochain bouton « importer » du site. */
    var pendingImage: Uri? = null
    var launcher: ((Intent) -> Unit)? = null
    private var callback: ValueCallback<Array<Uri>>? = null

    fun show(cb: ValueCallback<Array<Uri>>, intent: Intent): Boolean {
        pendingImage?.let { cb.onReceiveValue(arrayOf(it)); pendingImage = null; return true }
        callback?.onReceiveValue(null); callback = cb
        return runCatching { launcher!!.invoke(intent); true }.getOrElse { callback = null; cb.onReceiveValue(null); false }
    }

    fun result(code: Int, data: Intent?) {
        callback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(code, data)); callback = null
    }
}
