package com.example.mydm

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.activity.compose.BackHandler
import com.example.mydm.browser.BrowserManager
import android.content.Intent
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.mydm.core.FileChooserBridge
import com.example.mydm.core.Incoming
import com.example.mydm.core.Prefs
import com.example.mydm.core.MediaResolver
import com.example.mydm.core.Viewer
import com.example.mydm.browser.EpisodeLink
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.foundation.clickable
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.style.TextOverflow
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import com.example.mydm.ui.*
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) Incoming.handle(intent)   // lien / magnet / image reçu d'une autre appli
        setContent { MyDMTheme { Root() } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        Incoming.handle(intent)
    }
}

private val tabs = listOf("\uD83C\uDF10" to "Navigateur", "\uD83C\uDFAC" to "Vidéos", "\u2B07\uFE0F" to "Téléchargements", "\uD83D\uDCAC" to "Statuts", "\uD83E\uDDF2" to "Torrent")

@Composable
private fun Root() {
    val ctx = LocalContext.current
    var tab by rememberSaveable { mutableIntStateOf(0) }

    // Les onglets (WebViews + médias détectés) vivent ici : ils survivent au changement d'écran
    val manager = remember { BrowserManager(ctx) }
    DisposableEffect(manager) { onDispose { manager.destroy() } }
    var showSettings by rememberSaveable { mutableStateOf(false) }
    BackHandler(showSettings) { showSettings = false }
    // Mode ordinateur : réapplique les réglages à tous les onglets
    LaunchedEffect(Prefs.desktopMode, Prefs.jsEnabled, Prefs.loadImages, Prefs.textZoom) { manager.applyPrefsToAll() }

    // Sélecteur de fichiers des pages web (envoi de photo, caméra…)
    val chooser = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { FileChooserBridge.result(it.resultCode, it.data) }
    LaunchedEffect(Unit) { FileChooserBridge.launcher = { chooser.launch(it) } }

    // Contenus reçus d'autres applications
    LaunchedEffect(Incoming.url) {
        Incoming.url?.let {
            if (Prefs.externalNewTab) manager.newTab(it) else manager.current.web.loadUrl(it)
            tab = 0; showSettings = false; Incoming.url = null
        }
    }
    LaunchedEffect(Incoming.torrent) { if (Incoming.torrent != null) { tab = 4; showSettings = false } }
    LaunchedEffect(Incoming.image) {
        Incoming.image?.let {
            FileChooserBridge.pendingImage = it
            manager.newTab(Prefs.imageEngine.url); tab = 0; showSettings = false; Incoming.image = null
        }
    }

    // Fichier externe (vidéo, audio, image, PDF, texte, APK) : lecteur intégré
    LaunchedEffect(Incoming.file) {
        Incoming.file?.let { Viewer.open(listOf(it)); Incoming.file = null; showSettings = false }
    }

    // Pastilles de la barre du bas
    val app = ctx.applicationContext as App

    // Pré-analyse des liens YouTube / Facebook / TikTok dès que la page est ouverte
    val curUrl = manager.tabs.getOrNull(manager.currentIndex)?.url
    LaunchedEffect(curUrl) {
        if (Prefs.prefetchLinks && !curUrl.isNullOrBlank()) { delay(700); MediaResolver.prefetch(app, curUrl) }
    }

    // Lien copié : bandeau « Analyser »
    val clipboard = LocalClipboardManager.current
    val owner = LocalLifecycleOwner.current
    val uiScope = rememberCoroutineScope()
    var clipLink by remember { mutableStateOf<String?>(null) }
    var lastClip by rememberSaveable { mutableStateOf("") }
    var analyzeLink by remember { mutableStateOf<String?>(null) }
    var series by remember { mutableStateOf<Pair<List<EpisodeLink>, String>?>(null) }
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME && Prefs.clipboardWatch) uiScope.launch {
                delay(500)   // Android ne laisse lire le presse-papiers qu'une fois la fenêtre active
                val t = runCatching { clipboard.getText()?.text?.trim() }.getOrNull().orEmpty()
                val link = Regex("https?://\\S+").find(t)?.value
                if (link != null && link != lastClip) { lastClip = link; clipLink = link }
            }
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    val activeDl by app.db.downloadDao().observeActiveCount().collectAsStateWithLifecycle(0)
    val torrents by app.torrentEngine.states.collectAsStateWithLifecycle()
    // Téléchargements : nombre en cours ; sinon nombre de médias détectés prêts à télécharger
    val badges = listOf(0, 0, if (activeDl > 0) activeDl else manager.allFound().size, 0, torrents.size)

    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) notif.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    // Affiche l'erreur du dernier plantage, s'il y en a eu un
    val crashFile = remember { File(ctx.filesDir, "crash.txt") }
    var crash by remember { mutableStateOf(runCatching { if (crashFile.exists()) crashFile.readText() else null }.getOrNull()) }
    crash?.let { log ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text("Dernier plantage") },
            text = {
                Box(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())) {
                    SelectionContainer { Text(log.take(4000), fontSize = 10.sp) }
                }
            },
            confirmButton = { TextButton({ crashFile.delete(); crash = null }) { Text("Fermer") } }
        )
    }

    Box(Modifier.fillMaxSize()) {
    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Surface1) {
                tabs.forEachIndexed { i, (icon, label) ->
                    NavigationBarItem(tab == i && !showSettings, { tab = i; showSettings = false },
                        icon = { BadgedBox(badge = { if (badges[i] > 0) Badge { Text(if (badges[i] > 99) "99+" else "${badges[i]}") } }) { Text(icon) } },
                        label = { Text(label, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(indicatorColor = Accent.copy(alpha = 0.22f), selectedTextColor = Accent, unselectedTextColor = Muted))
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (showSettings) SettingsScreen(manager) { showSettings = false }
            else when (tab) {
                0 -> BrowserScreen(manager) { showSettings = true }
                1 -> VideoHubScreen(manager, { tab = 0 }) { tab = 2 }
                2 -> DownloadsScreen(manager)
                3 -> StatusScreen()
                4 -> TorrentScreen()
            }
            // Bandeau : lien trouvé dans le presse-papiers
            clipLink?.let { l ->
                Row(Modifier.align(Alignment.TopCenter).padding(10.dp).fillMaxWidth().glass().padding(start = 14.dp, top = 4.dp, bottom = 4.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Text("🔗 " + l.substringAfter("://").take(38), color = Txt, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    TextButton({ analyzeLink = l; clipLink = null }) { Text("Analyser") }
                    TextButton({ clipLink = null }) { Text("✕", color = Muted) }
                }
            }
        }
    }
    // Lecteur intégré par-dessus toute l'application
    if (Viewer.active) ViewerScreen()
    }
    analyzeLink?.let { l -> DownloadSheet(manager.current.found, l, { analyzeLink = null }) { eps, t -> series = eps to t } }
    series?.let { (eps, t) -> SeriesSheet(eps, t) { series = null; tab = 2 } }
}
