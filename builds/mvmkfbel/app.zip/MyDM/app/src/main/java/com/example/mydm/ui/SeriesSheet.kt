package com.example.mydm.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.mydm.browser.EpisodeLink
import com.example.mydm.core.Prefs
import com.example.mydm.downloader.BState

/** Série : choisir les épisodes puis tout télécharger d'un coup (analyse automatique de chaque page). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SeriesSheet(episodes: List<EpisodeLink>, pageTitle: String, onDismiss: () -> Unit) {
    val app = appInstance()
    val batchItems by app.batch.items.collectAsStateWithLifecycle()
    val running by app.batch.running.collectAsStateWithLifecycle()
    val showProgress = running || batchItems.isNotEmpty()

    val tTitle = pageTitle.substringBefore("\n")
    val tUrl = pageTitle.substringAfter("\n", "").ifBlank { null }
    var title by remember { mutableStateOf(guessSeriesName(tTitle, tUrl)) }
    var frOnly by remember { mutableStateOf(Prefs.seriesFrenchOnly) }
    fun defaults(fr: Boolean) = episodes.filter { !fr || it.lang != "VOSTFR" }.map { it.url }.toSet()
    var selected by remember { mutableStateOf(defaults(frOnly)) }
    val seasons = remember(episodes) { episodes.mapNotNull { it.season }.distinct().sorted() }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true), containerColor = Bg) {
        LazyColumn(Modifier.fillMaxWidth(), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item { Text("📺 Série", color = Txt, fontSize = 20.sp) }

            if (!showProgress) {
                item {
                    Column(Modifier.fillMaxWidth().glass().padding(12.dp)) {
                        Text("Nom de la série (nom du dossier)", color = Muted, fontSize = 12.sp)
                        OutlinedTextField(title, { title = it }, Modifier.fillMaxWidth(), singleLine = true)
                        Text("${episodes.size} épisodes trouvés. MyDM ouvre chaque épisode en arrière-plan, choisit le lecteur (Uqload en français, sinon le premier) " +
                            "et l'ajoute aux téléchargements, dans un dossier par saison.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
                    }
                }
                item {
                    FilterChip(frOnly, { frOnly = !frOnly }, label = { Text("🇫🇷 Français seulement", fontSize = 12.sp) })
                }
                // Une carte par saison : un seul bouton télécharge toute la saison
                val bySeason = episodes.groupBy { it.season ?: 0 }.toSortedMap()
                bySeason.forEach { (s, eps) ->
                    val chosen = eps.filter { !frOnly || it.lang != "VOSTFR" }
                    item(key = "season$s") {
                        Column(Modifier.fillMaxWidth().glass().padding(12.dp)) {
                            Text(if (s == 0) "Épisodes" else "Saison $s", color = Txt, fontSize = 16.sp)
                            Text("${chosen.size} épisode(s)" + (eps.size - chosen.size).takeIf { it > 0 }?.let { " • $it VOSTFR ignoré(s)" }.orEmpty() +
                                (chosen.mapNotNull { it.episode }.let { n -> if (n.isNotEmpty()) " • E${n.min()}–E${n.max()}" else "" }),
                                color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
                            Button({ app.batch.start(title.ifBlank { "Série" }, chosen) }, Modifier.fillMaxWidth().padding(top = 8.dp), enabled = chosen.isNotEmpty()) {
                                Text("⬇ Télécharger la saison" + if (s != 0) " $s" else "")
                            }
                        }
                    }
                }
                if (bySeason.size > 1) item {
                    OutlinedButton({ app.batch.start(title.ifBlank { "Série" }, episodes.filter { !frOnly || it.lang != "VOSTFR" }) }, Modifier.fillMaxWidth()) {
                        Text("Toutes les saisons (${bySeason.size})")
                    }
                }
                item { Text("Pour une autre saison, ouvrez-la dans le navigateur puis relancez « Série : télécharger une saison ».", color = Muted, fontSize = 11.sp) }
            } else {
                val done = batchItems.count { it.state == BState.DONE }
                val failed = batchItems.count { it.state == BState.FAIL }
                item {
                    Column(Modifier.fillMaxWidth().glass().padding(12.dp)) {
                        Text(app.batch.series.value, color = Accent, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        LinearProgressIndicator({ (done + failed).toFloat() / batchItems.size.coerceAtLeast(1) }, Modifier.fillMaxWidth().padding(vertical = 8.dp))
                        Text((if (running) "Analyse en cours : " else "Terminé : ") + "$done ajouté(s)" + (if (failed > 0) " • $failed échec(s)" else "") + " sur ${batchItems.size}",
                            color = Muted, fontSize = 12.sp)
                        if (running) Text("Gardez l'application ouverte pendant l'analyse.", color = Muted, fontSize = 11.sp)
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (running) OutlinedButton({ app.batch.cancel() }) { Text("Arrêter") }
                        else {
                            Button({ onDismiss() }) { Text("Voir les téléchargements") }
                            OutlinedButton({ app.batch.clear() }) { Text("Nouvelle sélection") }
                        }
                    }
                }
                items(batchItems, key = { it.ep.url }) { b ->
                    Row(Modifier.fillMaxWidth().glass().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(when (b.state) { BState.WAIT -> "⏳"; BState.SCAN -> "🔎"; BState.DONE -> "✅"; BState.FAIL -> "⚠️" }, fontSize = 18.sp)
                        Column(Modifier.weight(1f).padding(start = 10.dp)) {
                            Text(b.ep.label, color = Txt, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            b.note?.let { n -> Text(n, color = if (b.state == BState.FAIL) Danger else Muted, fontSize = 11.sp) }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

/** « Ma Série - Saison 1 - Streaming » → « Ma Série ». */
fun guessSeriesName(pageTitle: String, pageUrl: String? = null): String =
    com.example.mydm.core.TitleCleaner.name(pageTitle, pageUrl).ifBlank { "Série" }
