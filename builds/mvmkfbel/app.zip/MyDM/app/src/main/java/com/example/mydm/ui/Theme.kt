package com.example.mydm.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.mydm.core.AccentColor
import com.example.mydm.core.Prefs
import com.example.mydm.core.ThemeMode

/** Palette courante (état Compose : toute l'UI se met à jour quand le thème change). */
object Ui {
    var dark by mutableStateOf(true)
    var amoled by mutableStateOf(false)
    var accent by mutableStateOf(Color(0xFF8B7CFF))
}

// Couleurs lues partout dans l'application (getters => suivent le thème choisi)
val Bg: Color get() = when { !Ui.dark -> Color(0xFFF4F5FB); Ui.amoled -> Color(0xFF000000); else -> Color(0xFF0D0F1C) }
val Surface1: Color get() = when { !Ui.dark -> Color(0xFFFFFFFF); Ui.amoled -> Color(0xFF0E0E14); else -> Color(0xFF171A2E) }
val Surface2: Color get() = when { !Ui.dark -> Color(0xFFE9EBF7); Ui.amoled -> Color(0xFF181822); else -> Color(0xFF212545) }
val Txt: Color get() = if (Ui.dark) Color(0xFFF2F4FF) else Color(0xFF14172B)
val Muted: Color get() = if (Ui.dark) Color(0xFF9AA3C7) else Color(0xFF5B627F)
val Accent: Color get() = Ui.accent
val OnAccent: Color get() = Color(0xFF0D0F1C)
val Outline: Color get() = if (Ui.dark) Color(0x2AFFFFFF) else Color(0x22000000)
val Danger: Color get() = Color(0xFFFF6B7A)
val Success: Color get() = Color(0xFF3DDC97)
val Warn: Color get() = Color(0xFFFFC857)

fun accentOf(a: AccentColor) = Color(a.argb)

@Composable
fun MyDMTheme(content: @Composable () -> Unit) {
    val dark = when (Prefs.themeMode) {
        ThemeMode.DARK, ThemeMode.AMOLED -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }
    val amoled = Prefs.themeMode == ThemeMode.AMOLED
    val acc = accentOf(Prefs.accent)
    if (Ui.dark != dark) Ui.dark = dark
    if (Ui.amoled != amoled) Ui.amoled = amoled
    if (Ui.accent != acc) Ui.accent = acc

    val scheme = if (dark) darkColorScheme(
        primary = acc, onPrimary = OnAccent, secondary = acc, tertiary = Color(0xFF22D3EE),
        background = Bg, onBackground = Txt, surface = Surface1, onSurface = Txt,
        surfaceVariant = Surface2, onSurfaceVariant = Muted, outline = Outline,
        surfaceContainer = Surface1, surfaceContainerHigh = Surface2, surfaceContainerHighest = Surface2,
        error = Danger
    ) else lightColorScheme(
        primary = acc, onPrimary = Color.White, secondary = acc, tertiary = Color(0xFF0891B2),
        background = Bg, onBackground = Txt, surface = Surface1, onSurface = Txt,
        surfaceVariant = Surface2, onSurfaceVariant = Muted, outline = Outline,
        surfaceContainer = Surface1, surfaceContainerHigh = Surface2, surfaceContainerHighest = Surface2,
        error = Danger
    )
    MaterialTheme(
        colorScheme = scheme,
        shapes = Shapes(small = RoundedCornerShape(12.dp), medium = RoundedCornerShape(16.dp), large = RoundedCornerShape(24.dp)),
        content = content
    )
}

/** Carte arrondie (surface + liseré discret). Garde le nom historique « glass ». */
fun Modifier.glass(): Modifier = this
    .clip(RoundedCornerShape(18.dp))
    .background(Surface1)
    .border(1.dp, Outline, RoundedCornerShape(18.dp))
