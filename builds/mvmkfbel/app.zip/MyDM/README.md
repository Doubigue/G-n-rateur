# MyDM — Navigateur & Gestionnaire de téléchargements (Kotlin / Compose)

Ouvrir le dossier dans **Android Studio (Ladybug+)**, laisser la synchro Gradle se faire (génère le wrapper), puis Run sur un appareil Android 10+ (API 29).

- `browser/` WebView + sniffer (shouldInterceptRequest + JS injecté)
- `downloader/` moteur multi-segments (Range) + Foreground Service
- `whatsapp/` statuts via Storage Access Framework
- `torrent/` jlibtorrent (magnet / .torrent, sélection de fichiers, stats temps réel)
- `ui/` thème sombre « glass » + écrans Compose

Limites connues : HLS (.m3u8) détecté mais pas téléchargé ; pas de DRM ; vérifier les signatures jlibtorrent selon la version.

## Téléchargeur (pastille ⬇)
- Détection par extension, balises vidéo/audio **et Content-Type** (fichiers sans extension).
- Pastille « ⬇ » sur le navigateur : liste des médias, taille au clic, bouton Télécharger.
- Liens YouTube / Facebook / TikTok / HLS (m3u8) : analyse par yt-dlp (qualités + tailles), MP4 / M4A / MP3.
- Statuts WhatsApp : tous les dossiers `.Statuses` sont fusionnés et triés du plus récent au plus ancien.

## Onglets & paramètres
- Onglets : bouton compteur dans la barre d'adresse → grille d'onglets (miniatures, fermer, nouvel onglet). Les liens `target=_blank` / `window.open` ouvrent un nouvel onglet. Chaque onglet a sa propre liste de médias détectés.
- Paramètres (menu ⋮ du navigateur) : page d'accueil, moteur de recherche, mode ordinateur, blocage des pop-ups, restauration des onglets, nombre de connexions par téléchargement, effacement cookies/cache/médias.

## Version 2 — nouveautés
- **Page Téléchargements** : 3 onglets — *À télécharger* (médias détectés dans tous les onglets, taille, « Tout télécharger »), *Téléchargements* (en cours / terminés), *Dossiers*.
- **Pastille** sur l'onglet Téléchargements (nombre en cours, sinon médias détectés) et sur Torrent.
- **Dossiers** : `Download/MyDM/` → `Vidéo made/Statuts` (photos, vidéos), `Vidéo`, `Torrent/<Vidéos|Applications|Logiciels|Jeux|Documents|…>`, `Documents`, `Images`, `Musiques`, `Autres` (+ `Autres/Sites` pour les ZIP de sites). Classement automatique par type de fichier.
- **Notification** : « N en cours • % • vitesse », 5 premières lignes (nom • % • taille), « +N autres », pastille (setNumber), bouton « Tout mettre en pause ».
- **ZIP d'un site** (menu ⋮ du navigateur) : index.html (DOM rendu, liens réécrits en local), source.html, CSS/JS/images/polices, console.txt, _info.txt.
- **Console** (menu ⋮) : console.log / erreurs de la page, exécution de JavaScript, copie du HTML.
- **Liens externes** : http/https (navigateur par défaut), partage de texte/lien, `magnet:`, fichiers `.torrent`, partage d'une photo (recherche par image).
- **Recherche par photo** : Google Lens / Bing Visual / TinEye / Yandex ; la photo choisie est envoyée automatiquement au bouton « importer » de la page.
- **Extensions** : scripts utilisateur (type Tampermonkey) — Paramètres > Développeur. Les extensions Chrome (.crx) ne tournent pas dans une WebView.
- **Paramètres** : limite de vitesse, téléchargements simultanés, Wi-Fi uniquement, dossier principal, JS/images/zoom, blocage pubs, types détectés, etc.

## Version 2.1 — nouveautés
- **Analyse de liens plus rapide** (YouTube / Facebook / TikTok) : pré-analyse dès l'ouverture de la page vidéo, cache 15 min, analyse automatique à l'ouverture de la fenêtre, options yt-dlp « rapides », mise à jour de yt-dlp au plus 1×/jour et différée (elle ne concurrence plus la 1re analyse), 8 fragments simultanés au téléchargement.
- **Télécharger sans lire la vidéo** (cinezzz, papadustream…) : « Analyser » charge la page dans une WebView invisible, lance les lecteurs en sourdine, écoute le réseau, lit le DOM et teste les lecteurs intégrés (iframes) ; repli yt-dlp pour les hébergeurs connus (voe, streamtape, doodstream, uqload, vidoza…).
- **Séries d'un coup** : menu ⋮ → « 📺 Série », ou détection automatique dans « Analyser ». Choix des épisodes, nom de série, puis analyse en arrière-plan de chaque épisode et mise en file des téléchargements dans `Vidéo/<Série>/` (S01E05…).
- **Lecteur intégré** : vidéo / audio (Media3 ExoPlayer, reprise de position, lecture suivante auto), images (balayage, zoom), PDF, texte, **installation d'APK**.
- **Fichiers externes** : MyDM apparaît dans « Ouvrir avec » pour vidéo, audio, image, PDF, texte, APK ; partage de fichiers vers MyDM ; bouton « Ouvrir un fichier du téléphone » (Dossiers).
- **Bibliothèque** : miniatures, recherche, tri, espace disque, confirmation de suppression.
- **Nouveau design** : thèmes Auto / Sombre / Noir pur / Clair, 6 couleurs d'accent, cartes arrondies.
- **Paramètres** : Apparence, Analyse & séries, Lecteur intégré, bandeau « lien copié », mise à jour yt-dlp.

Limites : les sites protégés (Cloudflare, captcha, DRM) peuvent bloquer l'analyse automatique ; ouvrez la page une fois dans le navigateur pour valider le contrôle, puis relancez. Le lecteur ne gère pas AVI/WMV (bouton « Ouvrir avec… »).

## Version 2.2 — correctifs
- **Séries** : seuls les épisodes de la série affichée sont proposés (les « derniers épisodes » d'autres séries sont écartés) ; à la racine d'une saison, seule cette saison est listée ; un épisode en double garde sa version française ; épisodes VOSTFR/VO décochés par défaut (puces 🇫🇷 Français et S1, S2… dans la feuille Série).
- **Pop-ups / pages bizarres** : blocage activé par défaut. Pop-ups et redirections automatiques vers d'autres sites ignorés ; un lien du même site cliqué par vous s'ouvre dans l'onglet courant ; schémas intent:// / market:// refusés ; liste de régies publicitaires étendue ; la WebView d'analyse ne suit aucune fenêtre ni détournement.
- **Analyse d'un épisode** : lecteurs triés (hébergeurs connus d'abord), lecteurs imbriqués explorés, 5 lecteurs / 10 s par défaut ; plus de téléchargement yt-dlp lancé sur un lecteur inconnu (message clair à la place de « flux vidéo absent »).
- **Plus d'ajout automatique** à « À télécharger » : Paramètres > Types détectés > « Détection automatique en naviguant » (désactivé par défaut). Le bouton ⬇ lance l'analyse de la page.
- **Choix du lecteur (cinezzz…)** : sur une page d'épisode, la liste des lecteurs est lue (nom + drapeau). Ordre d'essai : **Uqload en français**, sinon le **premier lecteur français** (VOE…), puis les suivants si rien n'est trouvé (3 lecteurs au plus) ; la version VO/anglaise n'est utilisée qu'en dernier.
- **Séries** : le téléchargement de plusieurs épisodes est désactivé (menu retiré, carte « épisodes détectés » masquée). L'application ne propose que la vidéo en cours de lecture sur la page.
- **Plus de choix automatique de lecteur** : vous choisissez le lecteur dans la page. La fenêtre ⬇ affiche uniquement **la vidéo en cours de lecture** (la dernière détectée dans l'onglet, effacée au changement de page). Aucune analyse automatique à l'ouverture sur les sites de séries ; « Analyser » ne sert plus que pour un lien collé.
- **Durée / minutage** : la durée de la vidéo est lue (playlist HLS ou métadonnées du fichier). Les vidéos de **2 min ou moins** détectées en navigation sont ignorées (publicités) — pas sur YouTube, Facebook, TikTok, Instagram, X/Twitter, Vimeo, Dailymotion, Twitch. La durée et le temps restant s'affichent dans la liste des téléchargements et **dans la notification**.
- **Qualité** : si le flux HLS en propose plusieurs (720p, 1080p…), la fenêtre ⬇ liste les qualités ; sinon un seul bouton Télécharger.
- **Onglet « Vidéos »** (à côté du navigateur, comme VidMate) : recherche YouTube (Vidéos / Listes de lecture) ou collage d'un lien de vidéo, playlist, chaîne ou compte. La liste est lue « à plat » par yt-dlp (des centaines d'entrées en quelques secondes) ; cochez une par une ou « Tout », choisissez la qualité commune (meilleure, 1080p…360p, MP3, M4A) et téléchargez en un seul geste. Une liste ouverte crée un dossier du nom de la playlist. Les téléchargements respectent le nombre de simultanés réglé dans les paramètres (3 par défaut) ; les autres attendent en file.

## Version 2.3 — capture « comme 1DM »
- **Capture complète pendant la lecture** : dès que vous lancez la vidéo dans le lecteur de la page, tout ce qu'il charge est listé par onglet — flux HLS (une ligne **par qualité** : résolution 1916x1076 / 1280x720 / 640x360, taille estimée, nombre de pièces, durée), fichiers vidéo et **sous-titres** (.vtt / .srt). La pastille ⬇ affiche « N fichier(s) détecté(s) ».
- **Fenêtre « Fichier(s) détectés ! »** : cases à cocher + « Tout sélectionner », menu ⋮ (copier le lien, retirer), TOUT EFFACER, TRIER (arrivée / type / nom), FERMER.
- **Fenêtre « Télécharger le(s) fichier(s) ! »** : lien (copiable), nom = titre de la page (modifiable), extension, taille (pièces, durée), stockage libre, dossier de destination, COMMENCER. Plusieurs fichiers cochés = un seul geste.
- La liste se vide au changement de page ; les vidéos de 2 min ou moins (publicités) restent ignorées.

### Onglet « Vidéos » refait comme VidMate (v2.3)
- Barre : ‹ retour, recherche arrondie, ⬇ (téléchargements). Onglets : **Tout / Liste de lecture / Instagram / Facebook / Image / Google**.
- **Tout** : grandes cartes 16:9 (miniature, durée, ▶), ligne titre + chaîne + bouton ⬇ (choix de la qualité) ; playlists en carte « pile » avec « N Vidéos » ; puces Durée et Pertinence/Durée.
- **Liste de lecture** : lignes compactes (miniature + nombre de vidéos + ⬇).
- **Écran « Sélectionné »** (playlist, chaîne ou lien collé) : toutes les vidéos cochées, « Tout Sélectionner », compteur 100/100, bouton rouge **FAIT** → qualité → file de téléchargement dans un dossier du nom de la liste.
- Instagram / Facebook / Image / Google : recherche ouverte dans un onglet du navigateur.
- **Sites de streaming (cinezzz, papadustream…)** : (1) le téléchargement rejoue maintenant le **Referer / Origin réel du lecteur** (uqload, voe… refusaient l'adresse de la page) ; (2) le script de détection est injecté **dans les iframes** (androidx.webkit) et repère aussi les playlists/vidéos sans extension via leur Content-Type ; (3) les **pubs** (hôtes publicitaires, adresses vast / preroll / ads, fichiers < 3 Mo sans durée, ≤ 2 min) ne sont plus captées ; (4) la vidéo affichée n'est plus « la dernière détectée » mais **la meilleure** (durée longue, flux maître HLS, gros fichier, hébergeur connu) et passe en tête de « Fichier(s) détectés ».
- **Clip « Direct HLS needs Premium » (uqload)** : c'est le message que l'hébergeur renvoie quand la requête n'a pas les en-têtes de son vrai lecteur. Le téléchargement rejoue désormais Referer + Origin + **cookies** + User-Agent du lecteur (aussi pour les flux HLS via yt-dlp) ; si le script de l'iframe connaît un référent plus précis que la requête, il remplace l'ancien.
- **Nom des fichiers** : le titre de la page est nettoyé (« Regarder Mon Film (2023) en streaming VF complet HD - Cinezzz : synopsis… » → « Mon Film (2023) »), en s'aidant de l'adresse de la page ; saison/épisode ajoutés au format `Ma Série S02E05`. Utilisé dans la fenêtre « Télécharger le(s) fichier(s) », la liste des fichiers détectés et les téléchargements.
- **Séries par saison** : menu ⋮ → « 📺 Série : télécharger une saison » (ou carte « Série » dans l'analyse de page). Une carte par saison avec un seul bouton ; l'analyse choisit le lecteur de chaque épisode (Uqload en français, sinon le premier, jusqu'à 3 essais) et classe dans `Série/Saison 02/`. Les épisodes VOSTFR sont ignorés par défaut.
