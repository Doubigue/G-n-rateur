package com.example.voskcaptions.services

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.voskcaptions.R
import com.example.voskcaptions.VoskApp
import com.example.voskcaptions.data.AppSettings
import com.example.voskcaptions.data.SubtitleBus
import com.example.voskcaptions.data.SubtitleSource
import com.example.voskcaptions.data.SubtitleState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/** Fenêtre flottante (TYPE_APPLICATION_OVERLAY) déplaçable, affichant sous-titres et traductions. */
class SubtitleOverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.example.voskcaptions.action.STOP_OVERLAY"
        private const val CHANNEL_ID = "subtitle_overlay"
        private const val NOTIFICATION_ID = 1002

        private val _running = MutableStateFlow(false)
        val running: StateFlow<Boolean> = _running.asStateFlow()

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, SubtitleOverlayService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, SubtitleOverlayService::class.java))
        }
    }

    private val app: VoskApp get() = applicationContext as VoskApp
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private lateinit var wm: WindowManager
    private var rootView: View? = null
    private lateinit var params: WindowManager.LayoutParams
    private lateinit var bg: GradientDrawable
    private lateinit var tvLabel: TextView
    private lateinit var tvOriginal: TextView
    private lateinit var tvTranslated: TextView
    private var settings = AppSettings()
    private var lastState = SubtitleState()
    private var clearJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForegroundCompat()                       // toujours, suite à startForegroundService()
        if (intent?.action == ACTION_STOP || !Settings.canDrawOverlays(this)) {
            stopSelf(); return START_NOT_STICKY
        }
        if (rootView == null) setupOverlay()
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, n)
        }
    }

    @SuppressLint("InflateParams")
    private fun setupOverlay() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val view = LayoutInflater.from(this).inflate(R.layout.overlay_subtitles, null)
        tvLabel = view.findViewById(R.id.tvLabel)
        tvOriginal = view.findViewById(R.id.tvOriginal)
        tvTranslated = view.findViewById(R.id.tvTranslated)

        val dm = resources.displayMetrics
        bg = GradientDrawable().apply { cornerRadius = 16f * dm.density }
        view.background = bg

        settings = app.settings.state.value
        val width = (dm.widthPixels * 0.9f).toInt()
        params = WindowManager.LayoutParams(
            width,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = if (settings.overlayX >= 0) settings.overlayX else (dm.widthPixels - width) / 2
            y = if (settings.overlayY >= 0) settings.overlayY else (dm.heightPixels * 0.65f).toInt()
        }

        installDragHandler(view)
        applySettings(settings)
        wm.addView(view, params)
        rootView = view
        _running.value = true

        scope.launch { app.settings.state.collect { settings = it; applySettings(it); render(lastState) } }
        scope.launch { SubtitleBus.state.collect { lastState = it; render(it) } }

        SubtitleBus.publish(
            SubtitleState(original = "Sous-titres prêts — déplacez cette fenêtre avec le doigt")
        )
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun installDragHandler(view: View) {
        view.setOnTouchListener(object : View.OnTouchListener {
            private var startX = 0
            private var startY = 0
            private var touchX = 0f
            private var touchY = 0f

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                val dm = resources.displayMetrics
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x; startY = params.y
                        touchX = e.rawX; touchY = e.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = (startX + (e.rawX - touchX).toInt())
                            .coerceIn(0, (dm.widthPixels - v.width).coerceAtLeast(0))
                        params.y = (startY + (e.rawY - touchY).toInt())
                            .coerceIn(0, (dm.heightPixels - v.height).coerceAtLeast(0))
                        wm.updateViewLayout(v, params)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        app.settings.update { it.copy(overlayX = params.x, overlayY = params.y) }
                        v.performClick()
                        return true
                    }
                }
                return false
            }
        })
    }

    private fun applySettings(s: AppSettings) {
        tvOriginal.setTextSize(TypedValue.COMPLEX_UNIT_SP, s.textSizeSp * 0.8f)
        tvTranslated.setTextSize(TypedValue.COMPLEX_UNIT_SP, s.textSizeSp.toFloat())
        bg.setColor(Color.argb(s.bgOpacity * 255 / 100, 0, 0, 0))
    }

    private fun render(state: SubtitleState) {
        val view = rootView ?: return
        val hasOriginal = state.original.isNotBlank()
        val hasTranslated = state.translated.isNotBlank()
        val showOriginal = hasOriginal && (settings.showOriginal || !hasTranslated)

        tvLabel.text = state.label
        tvLabel.visibility = if (state.label.isNotBlank()) View.VISIBLE else View.GONE
        tvOriginal.text = state.original
        tvOriginal.visibility = if (showOriginal) View.VISIBLE else View.GONE
        tvOriginal.alpha = if (state.partial) 0.75f else 1f
        tvTranslated.text = state.translated
        tvTranslated.visibility = if (hasTranslated) View.VISIBLE else View.GONE
        view.visibility = if (hasOriginal || hasTranslated) View.VISIBLE else View.GONE

        clearJob?.cancel()
        if (hasOriginal || hasTranslated) {
            clearJob = scope.launch {
                delay(if (state.source == SubtitleSource.MESSAGE) 12_000 else 7_000)
                SubtitleBus.clear()
            }
        }
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Fenêtre de sous-titres", NotificationManager.IMPORTANCE_LOW)
        )
        val stopPi = PendingIntent.getService(
            this, 2,
            Intent(this, SubtitleOverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Fenêtre de sous-titres active")
            .setOngoing(true)
            .addAction(0, "Fermer", stopPi)
            .build()
    }

    override fun onDestroy() {
        scope.cancel()
        rootView?.let { runCatching { wm.removeView(it) } }
        rootView = null
        _running.value = false
        super.onDestroy()
    }
}
