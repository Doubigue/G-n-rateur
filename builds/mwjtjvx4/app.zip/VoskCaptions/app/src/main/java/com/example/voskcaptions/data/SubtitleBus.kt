package com.example.voskcaptions.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class SubtitleSource { SPEECH, MESSAGE }

data class SubtitleState(
    val source: SubtitleSource = SubtitleSource.SPEECH,
    val label: String = "",          // ex. "WhatsApp · Alice" pour les messages
    val original: String = "",
    val translated: String = "",
    val partial: Boolean = false,
    val stamp: Long = 0L             // force une nouvelle émission même si le texte est identique
)

/** Bus unique entre les producteurs (audio, notifications) et l'overlay. */
object SubtitleBus {
    private val _state = MutableStateFlow(SubtitleState())
    val state: StateFlow<SubtitleState> = _state.asStateFlow()

    fun publish(s: SubtitleState) { _state.value = s.copy(stamp = System.nanoTime()) }
    fun clear() = publish(SubtitleState())
}
