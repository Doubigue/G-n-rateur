package com.example.voskcaptions.services

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.voskcaptions.MainActivity
import com.example.voskcaptions.VoskApp
import com.example.voskcaptions.audio.PcmResampler
import com.example.voskcaptions.data.SubtitleBus
import com.example.voskcaptions.data.SubtitleState
import com.example.voskcaptions.managers.LanguageModelMissingException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.vosk.Recognizer
import java.util.concurrent.atomic.AtomicLong
import kotlin.coroutines.coroutineContext
import kotlin.math.max

/**
 * Capture l'audio interne (MediaProjection + AudioPlaybackCapture), le convertit en
 * 16 kHz / mono / PCM16 et le passe à Vosk. Publie sous-titres + traduction sur [SubtitleBus].
 */
class AudioCaptureService : Service() {

    companion object {
        const val ACTION_START = "com.example.voskcaptions.action.START_CAPTURE"
        const val ACTION_STOP = "com.example.voskcaptions.action.STOP_CAPTURE"
        private const val EXTRA_RESULT_CODE = "result_code"
        private const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL_ID = "audio_capture"
        private const val NOTIFICATION_ID = 1001
        private const val TARGET_RATE = 16_000

        private val _running = MutableStateFlow(false)
        val running: StateFlow<Boolean> = _running.asStateFlow()

        fun startIntent(ctx: Context, resultCode: Int, data: Intent): Intent =
            Intent(ctx, AudioCaptureService::class.java)
                .setAction(ACTION_START)
                .putExtra(EXTRA_RESULT_CODE, resultCode)
                .putExtra(EXTRA_RESULT_DATA, data)

        fun stopIntent(ctx: Context): Intent =
            Intent(ctx, AudioCaptureService::class.java).setAction(ACTION_STOP)
    }

    private val app: VoskApp get() = applicationContext as VoskApp
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mainHandler = Handler(Looper.getMainLooper())

    private var captureJob: Job? = null
    private var partialJob: Job? = null
    private var projection: MediaProjection? = null

    private val seqCounter = AtomicLong()
    private var shownSeq = 0L
    private var lastPartial = ""
    @Volatile private var lastTranslation = ""

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
            }
            ACTION_START -> {
                // Android 14 : startForeground(type=mediaProjection) AVANT getMediaProjection()
                startForeground(
                    NOTIFICATION_ID, buildNotification(),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                )
                if (captureJob?.isActive != true) {
                    val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                    val data = readResultData(intent)
                    if (data == null || resultCode != Activity.RESULT_OK) stopSelf()
                    else startCapture(resultCode, data)
                }
            }
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun readResultData(intent: Intent): Intent? =
        if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        else intent.getParcelableExtra(EXTRA_RESULT_DATA)

    private fun startCapture(resultCode: Int, data: Intent) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toast("Permission micro (RECORD_AUDIO) manquante"); stopSelf(); return
        }
        val recognizer: Recognizer? = try { app.modelManager.createRecognizer() } catch (e: Exception) { null }
        if (recognizer == null) {
            toast("Aucun modèle Vosk chargé"); stopSelf(); return
        }
        val proj = try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mpm.getMediaProjection(resultCode, data).also { p ->
                p.registerCallback(object : MediaProjection.Callback() {
                    override fun onStop() { stopSelf() }
                }, mainHandler)
            }
        } catch (e: Exception) {
            recognizer.close()
            toast("Projection média refusée : ${e.message}"); stopSelf(); return
        }
        projection = proj
        captureJob = scope.launch { runPipeline(proj, recognizer) }.also { it.invokeOnCompletion { stopSelf() } }
    }

    // ------------------------------------------------------------------ pipeline audio → Vosk

    @SuppressLint("MissingPermission")
    private fun buildRecord(proj: MediaProjection): Pair<AudioRecord, Int>? {
        val config = AudioPlaybackCaptureConfiguration.Builder(proj)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()
        for (rate in intArrayOf(48_000, 44_100, 16_000)) {
            val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
            if (min <= 0) continue
            try {
                val format = AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(rate)
                    .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                    .build()
                val record = AudioRecord.Builder()
                    .setAudioFormat(format)
                    .setBufferSizeInBytes(max(min * 4, rate * 4 / 2))   // ~0,5 s
                    .setAudioPlaybackCaptureConfig(config)
                    .build()
                if (record.state == AudioRecord.STATE_INITIALIZED) return record to rate
                record.release()
            } catch (_: Exception) { /* essaie la fréquence suivante */ }
        }
        return null
    }

    private suspend fun runPipeline(proj: MediaProjection, recognizer: Recognizer) {
        var record: AudioRecord? = null
        try {
            val built = buildRecord(proj)
            if (built == null) {
                toast("Capture audio interne impossible sur cet appareil"); return
            }
            val (rec, inRate) = built
            record = rec
            val resampler = PcmResampler(inRate, TARGET_RATE, channels = 2)
            val chunk = ShortArray(inRate / 10 * 2)                              // 100 ms stéréo
            val out = ShortArray(chunk.size / 2 * TARGET_RATE / inRate + 16)     // 100 ms mono 16 kHz

            rec.startRecording()
            _running.value = true

            while (coroutineContext.isActive) {
                val n = rec.read(chunk, 0, chunk.size)           // bloquant (~100 ms)
                if (n < 0) { toast("Erreur de lecture audio ($n)"); break }
                if (n == 0) continue
                val outN = resampler.process(chunk, n, out)
                if (outN == 0) continue
                if (recognizer.acceptWaveForm(out, outN)) {
                    onFinal(JSONObject(recognizer.result).optString("text"))
                } else {
                    onPartial(JSONObject(recognizer.partialResult).optString("partial"))
                }
            }
        } finally {
            withContext(NonCancellable) {
                record?.let { runCatching { it.stop() }; runCatching { it.release() } }
                runCatching { recognizer.close() }        // libération mémoire native
                runCatching { proj.stop() }
                _running.value = false
                SubtitleBus.clear()
            }
        }
    }

    // ------------------------------------------------------------------ résultats + traduction

    @Synchronized
    private fun publish(seq: Long, state: SubtitleState) {
        if (seq >= shownSeq) {
            shownSeq = seq
            SubtitleBus.publish(state)
        }
    }

    private fun onPartial(text: String) {
        if (text.isBlank() || text == lastPartial) return
        lastPartial = text
        val seq = seqCounter.incrementAndGet()
        publish(seq, SubtitleState(original = text, translated = lastTranslation, partial = true))
        partialJob?.cancel()
        partialJob = scope.launch {
            val tr = safeTranslate(text)
            publish(seq, SubtitleState(original = text, translated = tr, partial = true))
        }
    }

    private fun onFinal(text: String) {
        lastPartial = ""
        partialJob?.cancel()
        if (text.isBlank()) return
        val seq = seqCounter.incrementAndGet()
        publish(seq, SubtitleState(original = text, translated = lastTranslation, partial = false))
        scope.launch {
            val tr = safeTranslate(text)
            publish(seq, SubtitleState(original = text, translated = tr, partial = false))
            lastTranslation = ""
        }
    }

    private suspend fun safeTranslate(text: String): String {
        val s = app.settings.state.value
        if (s.sourceLang == s.targetLang) return ""
        return try {
            app.translationManager.translate(text, s.sourceLang, s.targetLang).also { lastTranslation = it }
        } catch (e: LanguageModelMissingException) {
            "⚠ Pack de langue manquant : ${app.translationManager.displayName(e.lang)}"
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            ""
        }
    }

    // ------------------------------------------------------------------ divers

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Sous-titrage en direct", NotificationManager.IMPORTANCE_LOW)
        )
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val stopPi = PendingIntent.getService(this, 0, stopIntent(this), flags)
        val openPi = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), flags)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Sous-titrage en direct actif")
            .setContentText("Capture de l'audio interne en cours")
            .setOngoing(true)
            .setContentIntent(openPi)
            .addAction(0, "Arrêter", stopPi)
            .build()
    }

    private fun toast(msg: String) = mainHandler.post {
        Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        scope.cancel()            // le bloc finally du pipeline ferme AudioRecord, Recognizer et la projection
        if (captureJob == null) _running.value = false
        super.onDestroy()
    }
}
