package com.example.voskcaptions

import android.app.Application
import android.content.Context
import com.example.voskcaptions.data.SettingsRepository
import com.example.voskcaptions.managers.TranslationManager
import com.example.voskcaptions.managers.VoskModelManager
import org.vosk.LibVosk
import org.vosk.LogLevel

/** Conteneur de singletons partagés entre l'UI et les services. */
class VoskApp : Application() {
    lateinit var settings: SettingsRepository
        private set
    lateinit var modelManager: VoskModelManager
        private set
    lateinit var translationManager: TranslationManager
        private set

    override fun onCreate() {
        super.onCreate()
        LibVosk.setLogLevel(LogLevel.WARNINGS)
        settings = SettingsRepository(this)
        modelManager = VoskModelManager(this, settings)
        translationManager = TranslationManager(this, settings)
    }
}

val Context.voskApp: VoskApp get() = applicationContext as VoskApp
