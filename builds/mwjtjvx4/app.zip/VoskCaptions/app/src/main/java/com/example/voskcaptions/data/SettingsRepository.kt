package com.example.voskcaptions.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class AppSettings(
    val textSizeSp: Int = 20,
    val bgOpacity: Int = 70,            // 0..100
    val showOriginal: Boolean = true,
    val translateNotifications: Boolean = true,
    val sourceLang: String = "en",      // tag ML Kit
    val targetLang: String = "fr",      // tag ML Kit
    val lastModel: String? = null,
    val overlayX: Int = -1,             // -1 = position par défaut
    val overlayY: Int = -1
)

class SettingsRepository(context: Context) {
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(load())
    val state: StateFlow<AppSettings> = _state.asStateFlow()

    private fun load(): AppSettings {
        val d = AppSettings()
        return AppSettings(
            textSizeSp = prefs.getInt("textSize", d.textSizeSp),
            bgOpacity = prefs.getInt("bgOpacity", d.bgOpacity),
            showOriginal = prefs.getBoolean("showOriginal", d.showOriginal),
            translateNotifications = prefs.getBoolean("translateNotif", d.translateNotifications),
            sourceLang = prefs.getString("sourceLang", d.sourceLang) ?: d.sourceLang,
            targetLang = prefs.getString("targetLang", d.targetLang) ?: d.targetLang,
            lastModel = prefs.getString("lastModel", null),
            overlayX = prefs.getInt("overlayX", d.overlayX),
            overlayY = prefs.getInt("overlayY", d.overlayY)
        )
    }

    @Synchronized
    fun update(transform: (AppSettings) -> AppSettings) {
        val new = transform(_state.value)
        if (new == _state.value) return
        _state.value = new
        prefs.edit()
            .putInt("textSize", new.textSizeSp)
            .putInt("bgOpacity", new.bgOpacity)
            .putBoolean("showOriginal", new.showOriginal)
            .putBoolean("translateNotif", new.translateNotifications)
            .putString("sourceLang", new.sourceLang)
            .putString("targetLang", new.targetLang)
            .putString("lastModel", new.lastModel)
            .putInt("overlayX", new.overlayX)
            .putInt("overlayY", new.overlayY)
            .apply()
    }
}
