extends Node3D
class_name Monde
## Chargement de la ville (modèle GLB), génération des collisions,
## éclairage / ciel / brume et accès aux points de route pour les missions.

signal progression(valeur: float, texte: String)

const CHEMIN_VILLE := "res://assets/models/ville.glb"
const CHEMIN_DONNEES := "res://assets/data/city_data.json"

var points_route := PackedVector3Array()
var points_zone := PackedVector3Array()
var depart := Vector3.ZERO
var cap_depart := 0.0
var limites := Rect2(-1700, -1710, 3410, 3420)  # x, z, largeur, profondeur (minimap)
var ville: Node3D
var soleil: DirectionalLight3D
var environnement: WorldEnvironment
var _mat_couleurs: StandardMaterial3D


func charger() -> void:
	progression.emit(0.02, "Lecture des données de la ville…")
	_lire_donnees()
	_creer_environnement()
	_creer_sol()
	await get_tree().process_frame

	progression.emit(0.05, "Chargement de la ville…")
	var err := ResourceLoader.load_threaded_request(CHEMIN_VILLE)
	var scene: PackedScene
	if err == OK:
		var prog := []
		while true:
			var st := ResourceLoader.load_threaded_get_status(CHEMIN_VILLE, prog)
			if st == ResourceLoader.THREAD_LOAD_IN_PROGRESS:
				var p: float = prog[0] if prog.size() > 0 else 0.0
				progression.emit(0.05 + p * 0.45, "Chargement de la ville… %d %%" % int(p * 100.0))
				await get_tree().process_frame
			elif st == ResourceLoader.THREAD_LOAD_LOADED:
				scene = ResourceLoader.load_threaded_get(CHEMIN_VILLE)
				break
			else:
				break
	if scene == null:
		scene = load(CHEMIN_VILLE)
	if scene == null:
		push_error("Impossible de charger la ville : " + CHEMIN_VILLE)
		progression.emit(1.0, "Erreur : ville introuvable")
		return

	# Le modèle de ville est modélisé « Z vers le haut » : on le redresse.
	var support := Node3D.new()
	support.name = "Ville"
	support.rotation_degrees.x = -90.0
	add_child(support)
	ville = scene.instantiate()
	support.add_child(ville)
	await get_tree().process_frame
	await _generer_collisions()
	progression.emit(1.0, "Prêt !")


func _lire_donnees() -> void:
	var f := FileAccess.open(CHEMIN_DONNEES, FileAccess.READ)
	if f == null:
		push_error("Données de ville manquantes")
		return
	var d = JSON.parse_string(f.get_as_text())
	if not (d is Dictionary):
		return
	for p in d.get("road_points", []):
		points_route.append(Vector3(p[0], p[1], p[2]))
	for p in d.get("zone_points", []):
		points_zone.append(Vector3(p[0], p[1], p[2]))
	var s: Array = d.get("spawn", [0, 0, 0])
	depart = Vector3(s[0], s[1], s[2])
	cap_depart = PI * 0.5 if d.get("spawn_axis", "x") == "x" else 0.0
	var b: Array = d.get("bounds", [-1700, 1710, -1710, 1710])
	limites = Rect2(b[0], b[2], b[1] - b[0], b[3] - b[2])


func _generer_collisions() -> void:
	var corps := StaticBody3D.new()
	corps.name = "CollisionsVille"
	var mat_phys := PhysicsMaterial.new()
	mat_phys.friction = 1.0
	corps.physics_material_override = mat_phys
	add_child(corps)

	_mat_couleurs = StandardMaterial3D.new()
	_mat_couleurs.vertex_color_use_as_albedo = true
	_mat_couleurs.roughness = 0.85

	var meshes: Array = []
	var pile: Array = [ville]
	while not pile.is_empty():
		var n: Node = pile.pop_back()
		for c in n.get_children():
			pile.append(c)
		if n is MeshInstance3D and (n as MeshInstance3D).mesh != null:
			meshes.append(n)

	var eau := RegEx.new()
	eau.compile("(?i)water|sea|river|lake|eau")
	var total := meshes.size()
	for i in total:
		var mi: MeshInstance3D = meshes[i]
		_ameliorer_materiaux(mi)
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
		var nom := String(mi.name) + " " + String(mi.get_parent().name)
		if eau.search(nom) == null:
			var faces: PackedVector3Array = mi.mesh.get_faces()
			if faces.size() >= 3:
				var forme := ConcavePolygonShape3D.new()
				forme.backface_collision = true
				forme.set_faces(mi.global_transform * faces)
				var cs := CollisionShape3D.new()
				cs.shape = forme
				corps.add_child(cs)
		if i % 80 == 0:
			progression.emit(0.5 + 0.5 * float(i) / float(total), "Construction des collisions… %d / %d" % [i, total])
			await get_tree().process_frame


func _ameliorer_materiaux(mi: MeshInstance3D) -> void:
	var m := mi.mesh
	for s in m.get_surface_count():
		var a_couleurs := false
		if m is ArrayMesh:
			a_couleurs = ((m as ArrayMesh).surface_get_format(s) & Mesh.ARRAY_FORMAT_COLOR) != 0
		var mat := mi.get_active_material(s)
		if a_couleurs and (mat == null or not (mat is BaseMaterial3D) or not (mat as BaseMaterial3D).vertex_color_use_as_albedo):
			mi.set_surface_override_material(s, _mat_couleurs)
		elif mat is StandardMaterial3D:
			var sm := mat as StandardMaterial3D
			if sm.albedo_color.b > sm.albedo_color.r + 0.2 and sm.albedo_color.a >= 0.99:
				# Eau / vitrage : légèrement brillant
				sm.roughness = 0.08
				sm.metallic_specular = 0.8
			else:
				sm.roughness = maxf(sm.roughness, 0.6)


func _creer_environnement() -> void:
	var haute := GameData.qualite_haute
	var ciel_mat := ProceduralSkyMaterial.new()
	ciel_mat.sky_top_color = Color(0.25, 0.45, 0.78)
	ciel_mat.sky_horizon_color = Color(0.68, 0.76, 0.86)
	ciel_mat.ground_horizon_color = Color(0.6, 0.62, 0.62)
	ciel_mat.ground_bottom_color = Color(0.25, 0.25, 0.25)
	ciel_mat.sun_angle_max = 25.0
	ciel_mat.sky_curve = 0.12
	var ciel := Sky.new()
	ciel.sky_material = ciel_mat

	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	env.sky = ciel
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.9
	env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
	env.tonemap_mode = Environment.TONE_MAPPER_ACES
	env.tonemap_exposure = 1.05
	env.tonemap_white = 6.0
	env.glow_enabled = true
	env.glow_intensity = 0.4
	env.glow_bloom = 0.05
	env.fog_enabled = true
	env.fog_light_color = Color(0.7, 0.77, 0.86)
	env.fog_density = 0.0009
	env.fog_aerial_perspective = 0.35
	env.fog_sky_affect = 0.15
	env.adjustment_enabled = true
	env.adjustment_saturation = 1.08
	env.adjustment_contrast = 1.05
	if haute:
		env.ssao_enabled = true
		env.ssao_radius = 1.5
		env.ssao_intensity = 1.6
		env.ssil_enabled = false
	environnement = WorldEnvironment.new()
	environnement.environment = env
	add_child(environnement)

	soleil = DirectionalLight3D.new()
	soleil.name = "Soleil"
	soleil.rotation_degrees = Vector3(-48.0, -38.0, 0.0)
	soleil.light_energy = 1.25
	soleil.light_color = Color(1.0, 0.96, 0.9)
	soleil.shadow_enabled = true
	soleil.shadow_blur = 1.2
	soleil.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS if haute else DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
	soleil.directional_shadow_max_distance = 260.0 if haute else 110.0
	add_child(soleil)


func _creer_sol() -> void:
	# Grand terrain de sécurité autour de la ville (évite de tomber dans le vide).
	var niveau := -1.25
	var sol := StaticBody3D.new()
	sol.name = "Terrain"
	var cs := CollisionShape3D.new()
	cs.shape = WorldBoundaryShape3D.new()
	sol.add_child(cs)
	sol.position.y = niveau
	add_child(sol)
	var plan := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(9000, 9000)
	plan.mesh = pm
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.36, 0.42, 0.27)
	mat.roughness = 1.0
	var bruit := FastNoiseLite.new()
	bruit.frequency = 0.08
	var tex := NoiseTexture2D.new()
	tex.noise = bruit
	tex.seamless = true
	tex.width = 256
	tex.height = 256
	tex.color_ramp = Gradient.new()
	tex.color_ramp.set_color(0, Color(0.75, 0.78, 0.65))
	tex.color_ramp.set_color(1, Color(1.0, 1.0, 0.92))
	mat.albedo_texture = tex
	mat.uv1_scale = Vector3(600, 600, 1)
	plan.material_override = mat
	plan.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	sol.add_child(plan)


# --- Requêtes pour les missions -------------------------------------------

func point_aleatoire(rng: RandomNumberGenerator, centre: Vector3, dmin: float, dmax: float, sur_route := true, eviter: Array = [], ecart_min := 60.0) -> Vector3:
	var source := points_route if sur_route or points_zone.is_empty() else points_zone
	if source.is_empty():
		return depart
	var candidats: Array = []
	for p in source:
		var d := Vector2(p.x - centre.x, p.z - centre.z).length()
		if d < dmin or d > dmax:
			continue
		var ok := true
		for e in eviter:
			if Vector2(p.x - e.x, p.z - e.z).length() < ecart_min:
				ok = false
				break
		if ok:
			candidats.append(p)
	if candidats.is_empty():
		# On élargit progressivement la recherche
		if dmax < 4000.0:
			return point_aleatoire(rng, centre, dmin * 0.5, dmax * 1.8, sur_route, eviter, ecart_min * 0.5)
		return source[rng.randi() % source.size()]
	return candidats[rng.randi() % candidats.size()]


func point_le_plus_proche(pos: Vector3) -> Vector3:
	var meilleur := depart
	var dmin := INF
	for p in points_route:
		var d := pos.distance_squared_to(p)
		if d < dmin:
			dmin = d
			meilleur = p
	return meilleur


func cap_route(pos: Vector3, cap_actuel: float) -> float:
	## Renvoie l'orientation de la route au point donné, la plus proche du cap actuel.
	var dir_actuelle := Vector2(sin(cap_actuel), cos(cap_actuel))
	var meilleur := cap_actuel
	var score_max := -INF
	for p in points_route:
		var v := Vector2(p.x - pos.x, p.z - pos.z)
		var d := v.length()
		if d < 6.0 or d > 30.0:
			continue
		var s := v.normalized().dot(dir_actuelle)
		if s > score_max:
			score_max = s
			meilleur = atan2(v.x, v.y)
	return meilleur
