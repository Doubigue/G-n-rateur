extends Node
## Synthèse sonore en temps réel : moteur (selon régime et charge),
## crissement des pneus, vent, klaxon et chocs. Aucun fichier audio requis.

const TAUX := 22050.0

var voiture: Voiture
var _lecteur_moteur: AudioStreamPlayer
var _lecteur_ambiance: AudioStreamPlayer
var _gen_moteur: AudioStreamGeneratorPlayback
var _gen_ambiance: AudioStreamGeneratorPlayback
var _lecteur_choc: AudioStreamPlayer

var _phase := 0.0
var _phase_sub := 0.0
var _freq := 40.0
var _amp := 0.2
var _bruit_lp := 0.0
var _pneu_lp := 0.0
var _pneu_hp := 0.0
var _vent_lp := 0.0
var _phase_k1 := 0.0
var _phase_k2 := 0.0
var _phase_crisse := 0.0
var _rng := RandomNumberGenerator.new()
var _cylindres := 8
var _grave := 1.0
var _delai_choc := 0.0


func _ready() -> void:
	voiture = get_parent() as Voiture
	_cylindres = int(voiture.def.get("cylindres", 8))
	_grave = float(voiture.def.get("son_grave", 1.0))
	_lecteur_moteur = _creer_generateur(-4.0)
	_gen_moteur = _lecteur_moteur.get_stream_playback()
	_lecteur_ambiance = _creer_generateur(-6.0)
	_gen_ambiance = _lecteur_ambiance.get_stream_playback()
	_lecteur_choc = AudioStreamPlayer.new()
	_lecteur_choc.stream = _creer_son_choc()
	add_child(_lecteur_choc)
	voiture.choc.connect(_sur_choc)


func _creer_generateur(volume_db: float) -> AudioStreamPlayer:
	var lecteur := AudioStreamPlayer.new()
	var flux := AudioStreamGenerator.new()
	flux.mix_rate = TAUX
	flux.buffer_length = 0.1
	lecteur.stream = flux
	lecteur.volume_db = volume_db
	add_child(lecteur)
	lecteur.play()
	return lecteur


func _creer_son_choc() -> AudioStreamWAV:
	var n := int(TAUX * 0.45)
	var data := PackedByteArray()
	data.resize(n * 2)
	var lp := 0.0
	for i in n:
		var t := float(i) / TAUX
		var env := exp(-t * 11.0)
		var bruit := _rng.randf_range(-1.0, 1.0)
		lp += (bruit - lp) * 0.35
		var s := (lp * 0.8 + sin(t * TAU * 70.0) * 0.6 * exp(-t * 20.0)) * env
		data.encode_s16(i * 2, int(clampf(s, -1.0, 1.0) * 30000.0))
	var wav := AudioStreamWAV.new()
	wav.format = AudioStreamWAV.FORMAT_16_BITS
	wav.mix_rate = int(TAUX)
	wav.stereo = false
	wav.data = data
	return wav


func _sur_choc(intensite: float) -> void:
	if _delai_choc > 0.0:
		return
	_delai_choc = 0.25
	_lecteur_choc.volume_db = linear_to_db(clampf(intensite / 12.0, 0.15, 1.0))
	_lecteur_choc.pitch_scale = _rng.randf_range(0.8, 1.15)
	_lecteur_choc.play()


func _process(delta: float) -> void:
	if voiture == null:
		return
	_delai_choc = maxf(0.0, _delai_choc - delta)
	_remplir_moteur()
	_remplir_ambiance()


func _remplir_moteur() -> void:
	var n := _gen_moteur.get_frames_available()
	if n <= 0:
		return
	var cible_f := voiture.regime / 60.0 * _cylindres * 0.5 / _grave
	var cible_a := 0.16 + 0.30 * voiture.charge_moteur + 0.06 * (voiture.regime / float(voiture.def["regime_max"]))
	var buf := PackedVector2Array()
	buf.resize(n)
	var f0 := _freq
	var a0 := _amp
	for i in n:
		var k := float(i) / float(n)
		var f := lerpf(f0, cible_f, k)
		var a := lerpf(a0, cible_a, k)
		_phase = fmod(_phase + TAU * f / TAUX, TAU * 64.0)
		_phase_sub = fmod(_phase_sub + TAU * f * 0.5 / TAUX, TAU)
		var bruit := _rng.randf_range(-1.0, 1.0)
		_bruit_lp += (bruit - _bruit_lp) * 0.25
		var s := sin(_phase) * 0.55
		s += sin(_phase * 2.0 + 0.4) * 0.30
		s += sin(_phase * 3.0 + 1.1) * 0.16
		s += sin(_phase * 4.0) * 0.07
		s += sin(_phase_sub) * 0.35 * _grave
		# Grondement irrégulier (combustion) plus marqué sous charge
		s *= 0.85 + 0.15 * sin(_phase_sub * 3.0 + _bruit_lp * 2.0)
		s += _bruit_lp * (0.10 + 0.25 * voiture.charge_moteur)
		s = tanh(s * 1.4) * a
		buf[i] = Vector2(s, s)
	_freq = cible_f
	_amp = cible_a
	_gen_moteur.push_buffer(buf)


func _remplir_ambiance() -> void:
	var n := _gen_ambiance.get_frames_available()
	if n <= 0:
		return
	var v := voiture.vitesse
	var crisse := voiture.glissement * clampf(v / 8.0, 0.0, 1.0)
	var vent := clampf(v / 60.0, 0.0, 1.0)
	vent *= vent
	var klaxon := voiture.controle_actif and Input.is_action_pressed("klaxon")
	var buf := PackedVector2Array()
	buf.resize(n)
	for i in n:
		var b := _rng.randf_range(-1.0, 1.0)
		# Pneus : bruit filtré passe-bande + sifflement
		_pneu_lp += (b - _pneu_lp) * 0.5
		_pneu_hp = _pneu_lp - _pneu_hp * 0.0
		_phase_crisse = fmod(_phase_crisse + TAU * (820.0 + 60.0 * sin(_phase_crisse * 0.001)) / TAUX, TAU)
		var s := (_pneu_lp * 0.5 + sin(_phase_crisse) * 0.25) * crisse * 0.7
		# Vent
		_vent_lp += (b - _vent_lp) * 0.04
		s += _vent_lp * vent * 1.6
		# Klaxon double ton
		if klaxon:
			_phase_k1 = fmod(_phase_k1 + TAU * 415.0 / TAUX, TAU)
			_phase_k2 = fmod(_phase_k2 + TAU * 523.0 / TAUX, TAU)
			s += (signf(sin(_phase_k1)) * 0.5 + signf(sin(_phase_k2)) * 0.5) * 0.18
		buf[i] = Vector2(s, s)
	_gen_ambiance.push_buffer(buf)
