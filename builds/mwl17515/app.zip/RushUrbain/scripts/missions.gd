extends Node
class_name Missions
## Logique des modes de jeu : Course contre la montre, Livraison, Taxi et Balade libre.

signal fin_course(titre: String, texte: String)

const CIRCUITS := {
	1: {"nom": "Sprint urbain", "graine": 1107, "points": 6, "dmin": 110.0, "dmax": 240.0},
	2: {"nom": "Grand tour", "graine": 2026, "points": 10, "dmin": 150.0, "dmax": 330.0},
	3: {"nom": "Marathon de l'autoroute", "graine": 777, "points": 14, "dmin": 220.0, "dmax": 520.0},
}

const COULEUR_COURSE := Color(1.0, 0.78, 0.1)
const COULEUR_DEPOT := Color(0.25, 0.6, 1.0)
const COULEUR_LIVRAISON := Color(1.0, 0.45, 0.1)
const COULEUR_CLIENT := Color(0.25, 1.0, 0.4)
const COULEUR_DEST := Color(0.95, 0.3, 0.9)

var monde: Monde
var voiture: Voiture
var hud: HUD
var mode := ""
var circuit := 1
var etat := "inactif"
var rng := RandomNumberGenerator.new()
var quartiers: Array = []

var _marqueurs: Array = []
var _temps := 0.0
var _decompte := 0.0
var _attente := 0.0

# Course
var _points: Array = []
var _index := 0
var _temps_par := 0.0

# Livraison
var _depot := Vector3.ZERO
var _destination := Vector3.ZERO
var _colis_charge := false
var _integrite := 100.0
var _temps_limite := 0.0
var _distance_mission := 0.0
var _serie := 0
var _type_colis := ""

# Taxi
var _client: Pieton
var _pos_client := Vector3.ZERO
var _client_a_bord := false
var _compteur_prix := 0.0
var _confort := 100.0
var _temps_estime := 0.0
var _dist_depart := 0.0
var _delai_parole := 0.0
var _nom_dest := ""

const COLIS := ["des pizzas brûlantes", "un colis fragile (vaisselle)", "des médicaments urgents", "un bouquet de fleurs", "un ordinateur portable", "des documents juridiques", "un gâteau d'anniversaire", "des pièces détachées"]
const PAROLES_DEBUT := ["Bonjour ! Emmenez-moi à %s, s'il vous plaît.", "Vite, je suis en retard ! Direction %s !", "Bonsoir, %s s'il vous plaît. Pas trop vite, hein.", "Salut ! %s, et vite fait bien fait !"]
const PAROLES_CHOC := ["Aïe ! Faites attention !", "Vous avez votre permis ?!", "Mon café s'est renversé…", "Hé ! Doucement avec la voiture !"]
const PAROLES_VITE := ["Waouh, on n'est pas sur un circuit !", "Ralentissez, j'ai le mal des transports…", "C'est un taxi ou une fusée ?"]
const PAROLES_CALME := ["Belle ville, n'est-ce pas ?", "Vous travaillez depuis longtemps comme chauffeur ?", "Il fait beau aujourd'hui.", "J'adore ce quartier."]


func _ready() -> void:
	rng.randomize()


func initialiser(m: Monde, v: Voiture, h: HUD) -> void:
	monde = m
	voiture = v
	hud = h
	quartiers = []
	var f := FileAccess.open("res://assets/data/city_data.json", FileAccess.READ)
	if f:
		var d = JSON.parse_string(f.get_as_text())
		if d is Dictionary:
			quartiers = d.get("quartiers", [])


func changer_voiture(v: Voiture) -> void:
	voiture = v
	if not v.choc.is_connected(_sur_choc):
		v.choc.connect(_sur_choc)


func nom_lieu(p: Vector3) -> String:
	var meilleur := "Centre-ville"
	var dmin := INF
	for q in quartiers:
		var d := Vector2(q["x"] - p.x, q["z"] - p.z).length()
		if d < dmin:
			dmin = d
			meilleur = q["nom"]
	return meilleur


# =====================================================================
func demarrer(nouveau_mode: String, num_circuit := 1) -> void:
	arreter()
	mode = nouveau_mode
	circuit = num_circuit
	if not voiture.choc.is_connected(_sur_choc):
		voiture.choc.connect(_sur_choc)
	match mode:
		"course":
			_demarrer_course()
		"livraison":
			_serie = 0
			_nouvelle_livraison()
		"taxi":
			_serie = 0
			_nouveau_client()
		_:
			etat = "libre"
			hud.afficher_mission("BALADE LIBRE", "Explorez la ville librement.\nAppuyez sur Échap pour le menu.", "", "")


func arreter() -> void:
	for m in _marqueurs:
		if is_instance_valid(m):
			m.queue_free()
	_marqueurs.clear()
	if _client and is_instance_valid(_client):
		_client.queue_free()
	_client = null
	_client_a_bord = false
	_colis_charge = false
	etat = "inactif"
	if hud:
		hud.cible = Vector3.INF
		hud.cible_suivante = Vector3.INF
		hud.afficher_mission("", "", "", "")
	if voiture:
		voiture.controle_actif = true


func recommencer() -> void:
	var m := mode
	var c := circuit
	if m == "course":
		voiture.placer(monde.depart + Vector3.UP * 0.6, monde.cap_depart)
	demarrer(m, c)


func _marqueur(pos: Vector3, c: Color, texte: String, r := 7.0) -> Marqueur:
	var m := Marqueur.new().configurer(c, texte, r)
	monde.add_child(m)
	m.global_position = pos
	_marqueurs.append(m)
	return m


func _vider_marqueurs() -> void:
	for m in _marqueurs:
		if is_instance_valid(m):
			m.queue_free()
	_marqueurs.clear()


func _arrete_dans(p: Vector3, rayon: float) -> bool:
	var v := voiture.global_position
	return Vector2(v.x - p.x, v.z - p.z).length() < rayon and abs(v.y - p.y) < 6.0 and voiture.vitesse < 2.5


func _dans(p: Vector3, rayon: float) -> bool:
	var v := voiture.global_position
	return Vector2(v.x - p.x, v.z - p.z).length() < rayon and abs(v.y - p.y) < 8.0


# =====================================================================
# COURSE CONTRE LA MONTRE
func _demarrer_course() -> void:
	var c: Dictionary = CIRCUITS.get(circuit, CIRCUITS[1])
	var r := RandomNumberGenerator.new()
	r.seed = c["graine"]
	_points.clear()
	var prec := monde.depart
	var eviter: Array = [monde.depart]
	var longueur := 0.0
	for i in int(c["points"]):
		var p := monde.point_aleatoire(r, prec, c["dmin"], c["dmax"], true, eviter, 90.0)
		_points.append(p)
		eviter.append(p)
		longueur += prec.distance_to(p)
		prec = p
	_temps_par = longueur * 1.3 / 24.0 + 6.0
	_index = 0
	voiture.placer(monde.depart + Vector3.UP * 0.6, monde.cap_depart)
	voiture.controle_actif = false
	_maj_marqueurs_course()
	etat = "decompte"
	_decompte = 3.99
	_temps = 0.0
	var record: float = GameData.meilleurs_temps.get("circuit_%d" % circuit, INF)
	hud.afficher_mission("COURSE • " + c["nom"], "Passez par tous les points de contrôle le plus vite possible.", "00:00.00",
		"Point 0 / %d   •   Record : %s" % [_points.size(), GameData.formater_temps(record)])


func _maj_marqueurs_course() -> void:
	_vider_marqueurs()
	if _index < _points.size():
		var dernier := _index == _points.size() - 1
		_marqueur(_points[_index], COULEUR_COURSE if not dernier else Color(1, 1, 1), "ARRIVÉE" if dernier else "POINT %d" % (_index + 1), 9.0)
		hud.cible = _points[_index]
		hud.couleur_cible = COULEUR_COURSE
	if _index + 1 < _points.size():
		var m := _marqueur(_points[_index + 1], Color(1, 1, 1, 0.5), "", 6.0)
		m.scale = Vector3.ONE * 0.6
		hud.cible_suivante = _points[_index + 1]
	else:
		hud.cible_suivante = Vector3.INF


func _maj_course(delta: float) -> void:
	if etat == "decompte":
		var avant := int(ceil(_decompte))
		_decompte -= delta
		var apres := int(ceil(_decompte))
		if apres != avant and apres > 0:
			hud.message(str(apres), "", 0.6, Color(1, 0.85, 0.2))
		if _decompte <= 0.0:
			etat = "en_cours"
			voiture.controle_actif = true
			hud.message("PARTEZ !", "", 0.9, Color(0.3, 1, 0.4))
		return
	if etat != "en_cours":
		return
	_temps += delta
	hud.definir_chrono(GameData.formater_temps(_temps), _temps > _temps_par * 1.45)
	if _dans(_points[_index], 10.0):
		_index += 1
		if _index >= _points.size():
			_finir_course()
			return
		var ecart := _temps - _temps_par * float(_index) / float(_points.size())
		hud.message("POINT %d / %d" % [_index, _points.size()], ("%+.1f s" % ecart), 1.2, COULEUR_COURSE)
		_maj_marqueurs_course()
	var record: float = GameData.meilleurs_temps.get("circuit_%d" % circuit, INF)
	hud.definir_info("Point %d / %d   •   Record : %s" % [_index, _points.size(), GameData.formater_temps(record)])


func _finir_course() -> void:
	etat = "fini"
	_vider_marqueurs()
	hud.cible = Vector3.INF
	hud.cible_suivante = Vector3.INF
	var medaille := ""
	var gain := 400
	if _temps <= _temps_par:
		medaille = "MÉDAILLE D'OR"
		gain = 3000
	elif _temps <= _temps_par * 1.2:
		medaille = "MÉDAILLE D'ARGENT"
		gain = 1800
	elif _temps <= _temps_par * 1.45:
		medaille = "MÉDAILLE DE BRONZE"
		gain = 1000
	else:
		medaille = "Course terminée"
	var record := GameData.enregistrer_temps("circuit_%d" % circuit, _temps)
	if record:
		gain += 500
	GameData.stats["courses"] += 1
	GameData.gagner(gain)
	var texte := "%s\n\nTemps : %s\nTemps de référence (or) : %s\n%s\nGain : +%s" % [
		medaille, GameData.formater_temps(_temps), GameData.formater_temps(_temps_par),
		"NOUVEAU RECORD ! (+500 $)" if record else "Record : " + GameData.formater_temps(GameData.meilleurs_temps.get("circuit_%d" % circuit, INF)),
		GameData.formater_argent(gain)]
	voiture.controle_actif = false
	fin_course.emit("ARRIVÉE !", texte)


# =====================================================================
# LIVRAISON
func _nouvelle_livraison() -> void:
	_vider_marqueurs()
	_colis_charge = false
	_integrite = 100.0
	_depot = monde.point_aleatoire(rng, voiture.global_position, 120.0, 450.0, true)
	_marqueur(_depot, COULEUR_DEPOT, "DÉPÔT", 8.0)
	hud.cible = _depot
	hud.couleur_cible = COULEUR_DEPOT
	hud.cible_suivante = Vector3.INF
	_type_colis = COLIS[rng.randi() % COLIS.size()]
	etat = "vers_depot"
	hud.afficher_mission("LIVRAISON", "Rendez-vous au dépôt (%s) pour charger %s." % [nom_lieu(_depot), _type_colis], "", "Livraisons réussies : %d" % _serie)


func _maj_livraison(delta: float) -> void:
	match etat:
		"vers_depot":
			if _arrete_dans(_depot, 9.0):
				etat = "chargement"
				_attente = 2.0
				hud.message("Chargement…", "Restez immobile", 1.6, COULEUR_DEPOT)
		"chargement":
			if voiture.vitesse > 2.5:
				etat = "vers_depot"
				hud.message("Chargement interrompu", "Arrêtez-vous dans la zone", 1.5, Color(1, 0.4, 0.3))
				return
			_attente -= delta
			if _attente <= 0.0:
				_colis_charge = true
				_vider_marqueurs()
				_destination = monde.point_aleatoire(rng, voiture.global_position, 380.0, 1300.0, true, [_depot], 200.0)
				_distance_mission = voiture.global_position.distance_to(_destination)
				_temps_limite = _distance_mission * 1.45 / 15.0 + 25.0
				_temps = 0.0
				_marqueur(_destination, COULEUR_LIVRAISON, "LIVRAISON", 8.0)
				hud.cible = _destination
				hud.couleur_cible = COULEUR_LIVRAISON
				etat = "livraison"
				hud.definir_objectif("Livrez %s à %s avant la fin du temps imparti. Évitez les chocs !" % [_type_colis, nom_lieu(_destination)])
				hud.message("Colis chargé !", "Destination : " + nom_lieu(_destination), 2.2, COULEUR_LIVRAISON)
		"livraison":
			_temps += delta
			var reste := _temps_limite - _temps
			hud.definir_chrono(GameData.formater_temps(maxf(reste, 0.0)), reste < 15.0)
			hud.definir_info("État du colis : %d %%   •   Livraisons : %d" % [int(_integrite), _serie])
			if reste <= 0.0:
				_echec_livraison("Temps écoulé !", "Le client a annulé la commande.")
			elif _integrite <= 0.0:
				_echec_livraison("Colis détruit !", "Conduisez plus prudemment…")
			elif _arrete_dans(_destination, 9.0):
				_reussite_livraison(reste)
		"pause_mission":
			_attente -= delta
			if _attente <= 0.0:
				_nouvelle_livraison()


func _reussite_livraison(reste: float) -> void:
	var base := 250.0 + _distance_mission * 1.2
	var paye := int(base * (_integrite / 100.0) + reste * 6.0)
	_serie += 1
	GameData.stats["livraisons"] += 1
	GameData.gagner(paye)
	_vider_marqueurs()
	hud.cible = Vector3.INF
	hud.message("Livraison réussie ! +" + GameData.formater_argent(paye), "Colis : %d %%   •   Bonus de temps : %d s restantes" % [int(_integrite), int(reste)], 3.0, Color(0.4, 1, 0.5))
	etat = "pause_mission"
	_attente = 3.0


func _echec_livraison(titre: String, sous: String) -> void:
	_vider_marqueurs()
	hud.cible = Vector3.INF
	_serie = 0
	hud.message(titre, sous, 3.0, Color(1, 0.35, 0.3))
	etat = "pause_mission"
	_attente = 3.0


# =====================================================================
# TAXI
func _nouveau_client() -> void:
	_vider_marqueurs()
	_client_a_bord = false
	_confort = 100.0
	_compteur_prix = 0.0
	_pos_client = monde.point_aleatoire(rng, voiture.global_position, 100.0, 420.0, true)
	_marqueur(_pos_client, COULEUR_CLIENT, "CLIENT", 7.0)
	if _client and is_instance_valid(_client):
		_client.queue_free()
	_client = Pieton.new()
	monde.add_child(_client)
	_client.global_position = _pos_client + Vector3.UP * 0.05
	hud.cible = _pos_client
	hud.couleur_cible = COULEUR_CLIENT
	hud.cible_suivante = Vector3.INF
	etat = "vers_client"
	hud.afficher_mission("TAXI", "Un client vous attend à %s. Arrêtez-vous à côté de lui." % nom_lieu(_pos_client), "", "Clients transportés : %d" % _serie)


func _maj_taxi(delta: float) -> void:
	match etat:
		"vers_client":
			if _client and is_instance_valid(_client) and _client.global_position.distance_to(voiture.global_position) < 40.0:
				_client.look_at(Vector3(voiture.global_position.x, _client.global_position.y, voiture.global_position.z), Vector3.UP, true)
			if _arrete_dans(_pos_client, 10.0):
				etat = "embarquement"
				voiture.controle_actif = false
				_attente = 4.0
				var porte := voiture.to_global(Vector3(1.4, 0, 0))
				_client.marcher_vers(porte, _client_embarque)
		"embarquement":
			_attente -= delta
			if _attente <= 0.0:
				_client_embarque()
		"course_taxi":
			_temps += delta
			_compteur_prix += voiture.vitesse * delta * 0.018 + delta * 0.15
			_delai_parole -= delta
			var reste := _temps_estime - _temps
			# Confort : vitesse excessive, dérapages
			var kmh := voiture.vitesse_kmh()
			if kmh > 140.0:
				_confort -= delta * 4.0
				_parler(PAROLES_VITE)
			if voiture.glissement > 0.5:
				_confort -= delta * 6.0
			_confort = clampf(_confort, 0.0, 100.0)
			if _delai_parole < -25.0:
				_parler(PAROLES_CALME)
			hud.definir_chrono(GameData.formater_temps(maxf(reste, 0.0)), reste < 10.0)
			hud.definir_info("Compteur : %s   •   Confort : %d %%" % [GameData.formater_argent(int(_compteur_prix)), int(_confort)])
			if reste < -_temps_estime * 0.6:
				_client_part("Le client en a eu assez et descend !", "Course non payée.")
			elif _arrete_dans(_destination, 10.0):
				_fin_course_taxi(reste)
		"pause_mission":
			_attente -= delta
			if _attente <= 0.0:
				_nouveau_client()


func _client_embarque() -> void:
	if etat != "embarquement":
		return
	if _client and is_instance_valid(_client):
		_client.queue_free()
	_client = null
	voiture.controle_actif = true
	_client_a_bord = true
	_vider_marqueurs()
	_destination = monde.point_aleatoire(rng, voiture.global_position, 350.0, 1400.0, true, [_pos_client], 200.0)
	_dist_depart = voiture.global_position.distance_to(_destination)
	_temps_estime = _dist_depart * 1.4 / 14.0 + 20.0
	_temps = 0.0
	_delai_parole = 8.0
	_nom_dest = nom_lieu(_destination)
	_marqueur(_destination, COULEUR_DEST, "DESTINATION", 8.0)
	hud.cible = _destination
	hud.couleur_cible = COULEUR_DEST
	etat = "course_taxi"
	var phrase: String = PAROLES_DEBUT[rng.randi() % PAROLES_DEBUT.size()] % _nom_dest
	hud.definir_objectif("Conduisez votre client à %s. Roulez vite mais en douceur pour un bon pourboire." % _nom_dest)
	hud.message("Client à bord", "« " + phrase + " »", 3.5, COULEUR_CLIENT)


func _parler(liste: Array) -> void:
	if _delai_parole > 0.0:
		return
	_delai_parole = 9.0
	hud.message("", "« " + str(liste[rng.randi() % liste.size()]) + " »", 2.5)


func _fin_course_taxi(reste: float) -> void:
	var prix := int(_compteur_prix + 8.0 + _dist_depart * 0.25)
	var pourboire := 0
	if reste > 0.0:
		pourboire = int((_confort / 100.0) * prix * 0.5 + reste * 2.0)
	var total := prix + pourboire
	_serie += 1
	GameData.stats["clients"] += 1
	GameData.gagner(total)
	_vider_marqueurs()
	hud.cible = Vector3.INF
	var etoiles := 5 if _confort > 85 and reste > 0 else (4 if _confort > 65 else (3 if _confort > 45 else (2 if _confort > 25 else 1)))
	var avis := "%d/5" % etoiles
	hud.message("Course terminée ! +" + GameData.formater_argent(total), "Prix : %s • Pourboire : %s • Avis client : %s" % [GameData.formater_argent(prix), GameData.formater_argent(pourboire), avis], 3.5, Color(0.4, 1, 0.5))
	# Le client descend
	var p := Pieton.new()
	monde.add_child(p)
	p.global_position = voiture.to_global(Vector3(1.4, 0, 0))
	p.fait_signe = false
	p.marcher_vers(p.global_position + voiture.global_basis.x * 6.0, p.queue_free)
	etat = "pause_mission"
	_attente = 3.5


func _client_part(titre: String, sous: String) -> void:
	_vider_marqueurs()
	hud.cible = Vector3.INF
	_serie = 0
	hud.message(titre, sous, 3.0, Color(1, 0.35, 0.3))
	etat = "pause_mission"
	_attente = 3.0


# =====================================================================
func _sur_choc(intensite: float) -> void:
	match mode:
		"livraison":
			if etat == "livraison":
				var perte := intensite * 3.2
				_integrite = maxf(0.0, _integrite - perte)
				if perte > 4.0:
					hud.message("", "Colis endommagé ! (%d %%)" % int(_integrite), 1.2, Color(1, 0.5, 0.3))
		"taxi":
			if etat == "course_taxi":
				_confort = maxf(0.0, _confort - intensite * 3.5)
				_delai_parole = 0.0
				_parler(PAROLES_CHOC)


func _process(delta: float) -> void:
	if voiture == null or not is_instance_valid(voiture):
		return
	match mode:
		"course":
			_maj_course(delta)
		"livraison":
			_maj_livraison(delta)
		"taxi":
			_maj_taxi(delta)
