extends CanvasLayer
class_name CommandesTactiles
## Commandes tactiles multi-points pour Android / iOS :
## direction à gauche, pédales à droite, frein à main, caméra, replacer, pause.

var _boutons: Array = []  # [TouchScreenButton, ancre(Vector2 0..1), décalage(Vector2), rayon]


func _ready() -> void:
	layer = 4
	process_mode = Node.PROCESS_MODE_ALWAYS
	var r := 78.0
	_ajouter("gauche", "◀", Vector2(0, 1), Vector2(110, -120), r, Color(0.2, 0.6, 1.0))
	_ajouter("droite", "▶", Vector2(0, 1), Vector2(290, -120), r, Color(0.2, 0.6, 1.0))
	_ajouter("accelerer", "GAZ", Vector2(1, 1), Vector2(-110, -150), r * 1.05, Color(0.2, 0.85, 0.35))
	_ajouter("freiner", "FREIN", Vector2(1, 1), Vector2(-290, -105), r, Color(0.95, 0.25, 0.2))
	_ajouter("frein_main", "FM", Vector2(1, 1), Vector2(-120, -330), r * 0.62, Color(0.95, 0.6, 0.15))
	_ajouter("camera", "CAM", Vector2(1, 0), Vector2(-60, 330), r * 0.48, Color(0.6, 0.6, 0.7))
	_ajouter("reinitialiser", "↺", Vector2(1, 0), Vector2(-160, 330), r * 0.48, Color(0.6, 0.6, 0.7))
	_ajouter("klaxon", "♪", Vector2(0, 1), Vector2(200, -290), r * 0.5, Color(0.8, 0.8, 0.3))
	_ajouter("pause", "II", Vector2(0.5, 0), Vector2(170, 50), r * 0.45, Color(0.6, 0.6, 0.7))
	_ajouter("carte", "▦", Vector2(0.5, 0), Vector2(-170, 50), r * 0.45, Color(0.6, 0.6, 0.7))
	get_viewport().size_changed.connect(_disposer)
	_disposer()


func _ajouter(action: String, texte: String, ancre: Vector2, decalage: Vector2, rayon: float, c: Color) -> void:
	var b := TouchScreenButton.new()
	b.action = action
	b.texture_normal = _texture_cercle(int(rayon), Color(c.r, c.g, c.b, 0.35))
	b.texture_pressed = _texture_cercle(int(rayon), Color(c.r, c.g, c.b, 0.75))
	var forme := CircleShape2D.new()
	forme.radius = rayon
	b.shape = forme
	b.shape_centered = true
	b.passby_press = true
	var l := Label.new()
	l.text = texte
	l.size = Vector2(rayon * 2, rayon * 2)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", int(clampf(rayon * 0.42, 14, 34)))
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
	l.add_theme_constant_override("outline_size", 6)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	b.add_child(l)
	add_child(b)
	_boutons.append([b, ancre, decalage, rayon])


func _texture_cercle(r: int, c: Color) -> ImageTexture:
	var d := r * 2
	var img := Image.create(d, d, false, Image.FORMAT_RGBA8)
	img.fill(Color(0, 0, 0, 0))
	var centre := Vector2(r, r)
	for y in d:
		for x in d:
			var dist := Vector2(x + 0.5, y + 0.5).distance_to(centre)
			if dist <= r:
				var bord := clampf(r - dist, 0.0, 1.0)
				var col := c
				if dist > r - 4:
					col = Color(1, 1, 1, 0.7)
				col.a *= bord
				img.set_pixel(x, y, col)
	return ImageTexture.create_from_image(img)


func _disposer() -> void:
	var taille := get_viewport().get_visible_rect().size
	for e in _boutons:
		var b: TouchScreenButton = e[0]
		var ancre: Vector2 = e[1]
		var dec: Vector2 = e[2]
		var r: float = e[3]
		b.position = ancre * taille + dec - Vector2(r, r)
