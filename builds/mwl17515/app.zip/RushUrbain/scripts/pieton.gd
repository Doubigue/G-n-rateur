extends Node3D
class_name Pieton
## Personnage simple (client du taxi ou destinataire d'un colis) qui fait signe.

var couleur_haut := Color(0.2, 0.4, 0.8)
var _bras: Node3D
var _temps := 0.0
var fait_signe := true
var _cible_marche := Vector3.ZERO
var _marche := false
var _fin_marche: Callable


func _ready() -> void:
	var rng := RandomNumberGenerator.new()
	rng.randomize()
	var hauts := [Color(0.8, 0.15, 0.15), Color(0.15, 0.35, 0.8), Color(0.1, 0.55, 0.3), Color(0.9, 0.6, 0.1), Color(0.5, 0.2, 0.6), Color(0.9, 0.9, 0.9)]
	var peaux := [Color(0.36, 0.22, 0.14), Color(0.55, 0.36, 0.24), Color(0.85, 0.66, 0.5), Color(0.27, 0.16, 0.1)]
	couleur_haut = hauts[rng.randi() % hauts.size()]
	var peau: Color = peaux[rng.randi() % peaux.size()]
	var bas := Color(0.12, 0.13, 0.2)

	_ajouter(_capsule(0.17, 0.85, bas), Vector3(0, 0.45, 0))
	_ajouter(_capsule(0.24, 0.75, couleur_haut), Vector3(0, 1.15, 0))
	var tete := MeshInstance3D.new()
	var sph := SphereMesh.new()
	sph.radius = 0.13
	sph.height = 0.27
	tete.mesh = sph
	tete.material_override = _mat(peau)
	_ajouter(tete, Vector3(0, 1.66, 0))
	_ajouter(_capsule(0.06, 0.6, couleur_haut), Vector3(-0.3, 1.15, 0))
	_bras = Node3D.new()
	_bras.position = Vector3(0.28, 1.45, 0)
	add_child(_bras)
	var b := _capsule(0.06, 0.6, couleur_haut)
	b.position = Vector3(0, -0.25, 0)
	_bras.add_child(b)


func _capsule(r: float, h: float, c: Color) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var cm := CapsuleMesh.new()
	cm.radius = r
	cm.height = h
	mi.mesh = cm
	mi.material_override = _mat(c)
	return mi


func _mat(c: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = 0.9
	return m


func _ajouter(n: Node3D, p: Vector3) -> void:
	n.position = p
	add_child(n)


func marcher_vers(cible: Vector3, fin: Callable) -> void:
	_cible_marche = cible
	_marche = true
	fait_signe = false
	_fin_marche = fin


func _process(delta: float) -> void:
	_temps += delta
	if _bras:
		if fait_signe:
			_bras.rotation.z = 2.6 + sin(_temps * 7.0) * 0.4
		else:
			_bras.rotation.z = lerpf(_bras.rotation.z, 0.0, delta * 5.0)
	if _marche:
		var d := _cible_marche - global_position
		d.y = 0.0
		if d.length() < 0.6:
			_marche = false
			if _fin_marche.is_valid():
				_fin_marche.call()
		else:
			global_position += d.normalized() * 2.2 * delta
			look_at(global_position + d.normalized(), Vector3.UP, true)
			position.y += sin(_temps * 12.0) * 0.004
