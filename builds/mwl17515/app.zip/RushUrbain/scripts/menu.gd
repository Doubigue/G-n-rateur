extends CanvasLayer
class_name MenuPrincipal
## Menu principal : choix du mode, du circuit, du véhicule (achat), options.

signal jouer(mode: String, circuit: int)
signal vehicule_change(id: String)

var _mode := "course"
var _circuit := 1
var _index_vehicule := 0
var _boutons_mode := {}
var _racine: Control
var _panneau_options: Control
var _argent: Label
var _nom_vehicule: Label
var _desc_vehicule: Label
var _prix: Label
var _bouton_achat: Button
var _bouton_jouer: Button
var _barres := {}
var _circuits: OptionButton
var _ligne_circuit: Control
var _desc_mode: Label
var _record: Label
var _stats_joueur: Label

const MODES := [
	["course", "Course contre la montre", "Enchaînez les points de contrôle le plus vite possible. Médailles et records à la clé."],
	["livraison", "Livraison", "Chargez un colis au dépôt et livrez-le à temps… sans le casser !"],
	["taxi", "Taxi", "Prenez des clients et conduisez-les à destination. Rapidité et confort = gros pourboires."],
	["libre", "Balade libre", "Explorez la ville sans contrainte."],
]


func _ready() -> void:
	layer = 10
	process_mode = Node.PROCESS_MODE_ALWAYS
	_index_vehicule = maxi(0, GameData.ordre_vehicules.find(GameData.vehicule_choisi))
	_racine = Control.new()
	_racine.set_anchors_preset(Control.PRESET_FULL_RECT)
	_racine.theme = HUD.Theme_.creer()
	_racine.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_racine)

	var degrade := TextureRect.new()
	var g := Gradient.new()
	g.set_color(0, Color(0.02, 0.03, 0.05, 0.92))
	g.set_color(1, Color(0.02, 0.03, 0.05, 0.0))
	var gt := GradientTexture2D.new()
	gt.gradient = g
	gt.fill_from = Vector2(0, 0)
	gt.fill_to = Vector2(1, 0)
	degrade.texture = gt
	degrade.stretch_mode = TextureRect.STRETCH_SCALE
	degrade.set_anchors_preset(Control.PRESET_LEFT_WIDE)
	degrade.offset_right = 900
	degrade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_racine.add_child(degrade)

	var marge := MarginContainer.new()
	marge.set_anchors_preset(Control.PRESET_FULL_RECT)
	for cote in ["left", "right", "top", "bottom"]:
		marge.add_theme_constant_override("margin_" + cote, 40)
	marge.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_racine.add_child(marge)
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 30)
	h.mouse_filter = Control.MOUSE_FILTER_IGNORE
	marge.add_child(h)

	# ---- Colonne gauche : titre + modes ----
	var gauche := VBoxContainer.new()
	gauche.custom_minimum_size = Vector2(520, 0)
	gauche.add_theme_constant_override("separation", 12)
	h.add_child(gauche)
	var titre := Label.new()
	titre.text = "RUSH URBAIN"
	titre.add_theme_font_size_override("font_size", 72)
	titre.add_theme_color_override("font_color", Color(1, 0.8, 0.15))
	titre.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	titre.add_theme_constant_override("outline_size", 12)
	gauche.add_child(titre)
	var st := Label.new()
	st.text = "Course • Livraison • Taxi"
	st.add_theme_font_size_override("font_size", 26)
	st.add_theme_color_override("font_color", Color(0.85, 0.9, 1.0))
	gauche.add_child(st)
	_argent = Label.new()
	_argent.add_theme_font_size_override("font_size", 30)
	_argent.add_theme_color_override("font_color", Color(0.5, 1.0, 0.55))
	gauche.add_child(_argent)
	gauche.add_child(_espace(10))

	var groupe := ButtonGroup.new()
	for m in MODES:
		var b := Button.new()
		b.text = m[1]
		b.toggle_mode = true
		b.button_group = groupe
		b.custom_minimum_size = Vector2(480, 58)
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		var id: String = m[0]
		b.pressed.connect(func(): _choisir_mode(id))
		gauche.add_child(b)
		_boutons_mode[id] = b

	_ligne_circuit = HBoxContainer.new()
	gauche.add_child(_ligne_circuit)
	var lc := Label.new()
	lc.text = "Circuit : "
	_ligne_circuit.add_child(lc)
	_circuits = OptionButton.new()
	for k in Missions.CIRCUITS.keys():
		_circuits.add_item("%d. %s" % [k, Missions.CIRCUITS[k]["nom"]], k)
	_circuits.custom_minimum_size = Vector2(360, 50)
	_circuits.item_selected.connect(_sur_circuit)
	_ligne_circuit.add_child(_circuits)

	_desc_mode = Label.new()
	_desc_mode.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_desc_mode.custom_minimum_size = Vector2(480, 60)
	_desc_mode.add_theme_font_size_override("font_size", 19)
	_desc_mode.add_theme_color_override("font_color", Color(0.8, 0.85, 0.95))
	gauche.add_child(_desc_mode)
	_record = Label.new()
	_record.add_theme_font_size_override("font_size", 19)
	_record.add_theme_color_override("font_color", Color(1, 0.85, 0.4))
	gauche.add_child(_record)

	var vide := Control.new()
	vide.size_flags_vertical = Control.SIZE_EXPAND_FILL
	gauche.add_child(vide)
	_bouton_jouer = Button.new()
	_bouton_jouer.text = "JOUER"
	_bouton_jouer.custom_minimum_size = Vector2(480, 76)
	_bouton_jouer.add_theme_font_size_override("font_size", 34)
	_bouton_jouer.pressed.connect(_jouer)
	gauche.add_child(_bouton_jouer)
	var bas := HBoxContainer.new()
	bas.add_theme_constant_override("separation", 12)
	gauche.add_child(bas)
	var bo := Button.new()
	bo.text = "Options"
	bo.custom_minimum_size = Vector2(234, 54)
	bo.pressed.connect(func(): _panneau_options.visible = true)
	bas.add_child(bo)
	var bq := Button.new()
	bq.text = "Quitter"
	bq.custom_minimum_size = Vector2(234, 54)
	bq.pressed.connect(func(): get_tree().quit())
	bas.add_child(bq)

	# ---- Colonne droite : véhicule ----
	var espace := Control.new()
	espace.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	espace.mouse_filter = Control.MOUSE_FILTER_IGNORE
	h.add_child(espace)
	var droite := VBoxContainer.new()
	droite.custom_minimum_size = Vector2(440, 0)
	droite.alignment = BoxContainer.ALIGNMENT_END
	h.add_child(droite)
	var carte := PanelContainer.new()
	droite.add_child(carte)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 8)
	carte.add_child(vb)
	var nav := HBoxContainer.new()
	vb.add_child(nav)
	var bp := Button.new()
	bp.text = "  <  "
	bp.pressed.connect(func(): _changer_vehicule(-1))
	nav.add_child(bp)
	_nom_vehicule = Label.new()
	_nom_vehicule.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_nom_vehicule.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_nom_vehicule.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_nom_vehicule.add_theme_font_size_override("font_size", 24)
	_nom_vehicule.add_theme_color_override("font_color", Color(1, 0.85, 0.3))
	nav.add_child(_nom_vehicule)
	var bs := Button.new()
	bs.text = "  >  "
	bs.pressed.connect(func(): _changer_vehicule(1))
	nav.add_child(bs)
	_desc_vehicule = Label.new()
	_desc_vehicule.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_desc_vehicule.custom_minimum_size = Vector2(400, 54)
	_desc_vehicule.add_theme_font_size_override("font_size", 17)
	vb.add_child(_desc_vehicule)
	for s in ["Vitesse max", "Accélération", "Adhérence", "Maniabilité"]:
		var ligne := HBoxContainer.new()
		var l := Label.new()
		l.text = s
		l.custom_minimum_size = Vector2(150, 0)
		l.add_theme_font_size_override("font_size", 17)
		ligne.add_child(l)
		var pb := ProgressBar.new()
		pb.max_value = 100
		pb.show_percentage = false
		pb.custom_minimum_size = Vector2(240, 18)
		pb.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		var fond := StyleBoxFlat.new()
		fond.bg_color = Color(1, 1, 1, 0.1)
		fond.set_corner_radius_all(6)
		var plein := StyleBoxFlat.new()
		plein.bg_color = Color(1, 0.75, 0.15)
		plein.set_corner_radius_all(6)
		pb.add_theme_stylebox_override("background", fond)
		pb.add_theme_stylebox_override("fill", plein)
		ligne.add_child(pb)
		vb.add_child(ligne)
		_barres[s] = pb
	_prix = Label.new()
	_prix.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_prix.add_theme_font_size_override("font_size", 20)
	vb.add_child(_prix)
	_bouton_achat = Button.new()
	_bouton_achat.custom_minimum_size = Vector2(400, 54)
	_bouton_achat.pressed.connect(_acheter)
	vb.add_child(_bouton_achat)
	_stats_joueur = Label.new()
	_stats_joueur.add_theme_font_size_override("font_size", 15)
	_stats_joueur.add_theme_color_override("font_color", Color(0.7, 0.75, 0.85))
	_stats_joueur.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(_stats_joueur)

	_creer_options()
	_boutons_mode[_mode].button_pressed = true
	_choisir_mode(_mode)


func _espace(h: float) -> Control:
	var c := Control.new()
	c.custom_minimum_size = Vector2(0, h)
	return c


func _creer_options() -> void:
	var fond := ColorRect.new()
	fond.color = Color(0, 0, 0, 0.6)
	fond.set_anchors_preset(Control.PRESET_FULL_RECT)
	fond.visible = false
	_racine.add_child(fond)
	_panneau_options = fond
	var centre := CenterContainer.new()
	centre.set_anchors_preset(Control.PRESET_FULL_RECT)
	fond.add_child(centre)
	var p := PanelContainer.new()
	centre.add_child(p)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 14)
	vb.custom_minimum_size = Vector2(560, 0)
	p.add_child(vb)
	var t := Label.new()
	t.text = "OPTIONS"
	t.add_theme_font_size_override("font_size", 40)
	t.add_theme_color_override("font_color", Color(1, 0.82, 0.2))
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(t)

	var lv := Label.new()
	lv.text = "Volume général"
	vb.add_child(lv)
	var sv := HSlider.new()
	sv.min_value = 0.0
	sv.max_value = 1.0
	sv.step = 0.05
	sv.value = GameData.volume_general
	sv.custom_minimum_size = Vector2(500, 36)
	sv.value_changed.connect(_sur_volume)
	vb.add_child(sv)

	var cq := CheckButton.new()
	cq.text = "Graphismes haute qualité (ombres, occlusion)"
	cq.button_pressed = GameData.qualite_haute
	cq.toggled.connect(_sur_qualite)
	vb.add_child(cq)

	var cb := CheckButton.new()
	cb.text = "Boîte automatique (sinon E / F)"
	cb.button_pressed = GameData.boite_auto
	cb.toggled.connect(func(v): GameData.boite_auto = v)
	vb.add_child(cb)

	var ck := CheckButton.new()
	ck.text = "Vitesse en km/h (sinon mph)"
	ck.button_pressed = GameData.unite_kmh
	ck.toggled.connect(func(v): GameData.unite_kmh = v)
	vb.add_child(ck)

	var lt := Label.new()
	lt.text = "Commandes tactiles"
	vb.add_child(lt)
	var ot := OptionButton.new()
	ot.add_item("Automatique", 0)
	ot.add_item("Toujours affichées", 1)
	ot.add_item("Jamais", 2)
	ot.selected = GameData.commandes_tactiles
	ot.item_selected.connect(func(i): GameData.commandes_tactiles = i)
	vb.add_child(ot)

	var info := Label.new()
	info.text = "Clavier : Z/W ou ↑ accélérer • S ou ↓ freiner/reculer • Q/A et D tourner\nEspace frein à main • C caméra • R replacer • H klaxon • M carte\nManette prise en charge (gâchettes, stick gauche, A = frein à main)."
	info.add_theme_font_size_override("font_size", 15)
	info.add_theme_color_override("font_color", Color(0.75, 0.8, 0.9))
	vb.add_child(info)

	var br := Button.new()
	br.text = "Retour"
	br.custom_minimum_size = Vector2(300, 56)
	br.pressed.connect(_fermer_options)
	vb.add_child(br)


func _sur_circuit(i: int) -> void:
	_circuit = _circuits.get_item_id(i)
	_maj()


func _sur_volume(v: float) -> void:
	GameData.volume_general = v
	GameData.appliquer_volume()


func _sur_qualite(v: bool) -> void:
	GameData.qualite_haute = v
	_appliquer_qualite()


func _fermer_options() -> void:
	GameData.sauvegarder()
	_panneau_options.visible = false


func _appliquer_qualite() -> void:
	var m := get_tree().get_first_node_in_group("monde")
	if m is Monde:
		var mo := m as Monde
		mo.environnement.environment.ssao_enabled = GameData.qualite_haute
		mo.soleil.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS if GameData.qualite_haute else DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
		mo.soleil.directional_shadow_max_distance = 260.0 if GameData.qualite_haute else 110.0


func _choisir_mode(id: String) -> void:
	_mode = id
	for m in MODES:
		if m[0] == id:
			_desc_mode.text = m[2]
	_ligne_circuit.visible = id == "course"
	_maj()


func _changer_vehicule(sens: int) -> void:
	var n := GameData.ordre_vehicules.size()
	_index_vehicule = (_index_vehicule + sens + n) % n
	var id: String = GameData.ordre_vehicules[_index_vehicule]
	if id in GameData.vehicules_possedes:
		GameData.vehicule_choisi = id
		GameData.sauvegarder()
	vehicule_change.emit(id)
	_maj()


func _acheter() -> void:
	var id: String = GameData.ordre_vehicules[_index_vehicule]
	if id in GameData.vehicules_possedes:
		return
	if GameData.acheter(id):
		GameData.vehicule_choisi = id
		GameData.sauvegarder()
	_maj()


func _jouer() -> void:
	var id: String = GameData.ordre_vehicules[_index_vehicule]
	if not (id in GameData.vehicules_possedes):
		return
	GameData.vehicule_choisi = id
	GameData.sauvegarder()
	jouer.emit(_mode, _circuit)


func montrer(v: bool) -> void:
	visible = v
	_racine.visible = v
	if v:
		_index_vehicule = maxi(0, GameData.ordre_vehicules.find(GameData.vehicule_choisi))
		_maj()


func _maj() -> void:
	if _argent == null:
		return
	_argent.text = "Argent : " + GameData.formater_argent(GameData.argent)
	var id: String = GameData.ordre_vehicules[_index_vehicule]
	var d := GameData.definition(id)
	_nom_vehicule.text = d["nom"]
	_desc_vehicule.text = d["description"]
	var s := _statistiques(d)
	_barres["Vitesse max"].value = clampf((s["vmax"] - 150.0) / 200.0 * 100.0, 8.0, 100.0)
	_barres["Accélération"].value = clampf(s["accel"] / 12.0 * 100.0, 8.0, 100.0)
	_barres["Adhérence"].value = clampf((float(d["adherence"]) - 1.2) / 1.2 * 100.0, 8.0, 100.0)
	_barres["Maniabilité"].value = clampf(100.0 - (float(d["masse"]) - 900.0) / 1100.0 * 70.0, 8.0, 100.0)
	var possede: bool = id in GameData.vehicules_possedes
	if possede:
		_prix.text = "Vitesse max ≈ %d km/h" % int(s["vmax"])
		_bouton_achat.text = "Sélectionné" if GameData.vehicule_choisi == id else "Possédé"
		_bouton_achat.disabled = true
	else:
		_prix.text = "Prix : " + GameData.formater_argent(int(d["prix"])) + "   •   ≈ %d km/h" % int(s["vmax"])
		_bouton_achat.text = "Acheter"
		_bouton_achat.disabled = GameData.argent < int(d["prix"])
	_bouton_jouer.disabled = not possede
	_bouton_jouer.text = "JOUER" if possede else "VÉHICULE VERROUILLÉ"
	if _mode == "course":
		_record.text = "Record : " + GameData.formater_temps(GameData.meilleurs_temps.get("circuit_%d" % _circuit, INF))
	else:
		_record.text = ""
	var st: Dictionary = GameData.stats
	_stats_joueur.text = "Courses : %d  •  Livraisons : %d  •  Clients : %d" % [st["courses"], st["livraisons"], st["clients"]]


func _statistiques(d: Dictionary) -> Dictionary:
	var rapports: Array = d["rapports"]
	var rmax: float = d["regime_max"]
	var r: float = d["rayon"]
	var pont: float = d["pont"]
	var omega := rmax / 60.0 * TAU
	var puissance := float(d["couple"]) * 0.9 * omega * 0.9
	var v_trainee := pow(puissance / float(d["trainee"]), 1.0 / 3.0)
	var v_boite := omega / (float(rapports[rapports.size() - 1]) * pont) * r
	var vmax := minf(v_trainee, v_boite) * 3.6
	var accel := minf(float(d["couple"]) * float(rapports[0]) * pont * 0.88 / r / float(d["masse"]), float(d["adherence"]) * 9.81 * (1.0 if d["transmission"] == "integrale" else 0.6))
	return {"vmax": vmax, "accel": accel}
