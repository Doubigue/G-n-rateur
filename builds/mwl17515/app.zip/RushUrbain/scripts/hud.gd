extends CanvasLayer
class_name HUD
## Interface en jeu : compteur, mission, chrono, argent, boussole, minicarte,
## messages, écran de pause et écran de résultat.

signal reprendre
signal recommencer
signal retour_menu
signal continuer

var voiture: Voiture
var camera: Camera3D
var monde: Monde
var cible := Vector3.INF          # objectif principal
var cible_suivante := Vector3.INF # objectif d'après (course)
var couleur_cible := Color(1, 0.8, 0.1)

var _racine: Control
var _compteur: Compteur
var _titre: Label
var _objectif: Label
var _chrono: Label
var _info: Label
var _argent: Label
var _boussole: Boussole
var _distance: Label
var _message: Label
var _sous_message: Label
var _minicarte: MiniCarte
var _grande_carte: MiniCarte
var _pause: Control
var _resultat: Control
var _res_titre: Label
var _res_texte: Label
var _tween_msg: Tween
var _panneau_mission: PanelContainer


func _ready() -> void:
	layer = 5
	process_mode = Node.PROCESS_MODE_ALWAYS
	_racine = Control.new()
	_racine.set_anchors_preset(Control.PRESET_FULL_RECT)
	_racine.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_racine.theme = Theme_.creer()
	add_child(_racine)
	var tactile := GameData.utiliser_tactile()

	# Panneau de mission (haut gauche)
	_panneau_mission = PanelContainer.new()
	_panneau_mission.position = Vector2(20, 20)
	_panneau_mission.custom_minimum_size = Vector2(360, 0)
	_panneau_mission.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_racine.add_child(_panneau_mission)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 2)
	_panneau_mission.add_child(vb)
	_titre = _label(vb, 26, Color(1, 0.82, 0.2))
	_objectif = _label(vb, 19, Color.WHITE)
	_objectif.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_objectif.custom_minimum_size = Vector2(330, 0)
	_chrono = _label(vb, 30, Color.WHITE)
	_info = _label(vb, 18, Color(0.8, 0.9, 1.0))

	# Argent (haut droite)
	_argent = Label.new()
	_argent.add_theme_font_size_override("font_size", 28)
	_argent.add_theme_color_override("font_color", Color(0.5, 1.0, 0.55))
	_argent.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.85))
	_argent.add_theme_constant_override("outline_size", 8)
	_argent.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_placer(_argent, Control.PRESET_TOP_RIGHT, Vector2(-320, 20), Vector2(300, 40))
	_racine.add_child(_argent)

	# Boussole (haut centre)
	_boussole = Boussole.new()
	_placer(_boussole, Control.PRESET_CENTER_TOP, Vector2(-45, 14), Vector2(90, 90))
	_racine.add_child(_boussole)
	_distance = Label.new()
	_distance.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_placer(_distance, Control.PRESET_CENTER_TOP, Vector2(-120, 104), Vector2(240, 30))
	_distance.add_theme_font_size_override("font_size", 22)
	_distance.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	_distance.add_theme_constant_override("outline_size", 8)
	_racine.add_child(_distance)

	# Messages (centre)
	_message = Label.new()
	_message.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_placer(_message, Control.PRESET_CENTER, Vector2(-600, -190), Vector2(1200, 100))
	_message.add_theme_font_size_override("font_size", 58)
	_message.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	_message.add_theme_constant_override("outline_size", 14)
	_message.modulate.a = 0.0
	_racine.add_child(_message)
	_sous_message = Label.new()
	_sous_message.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_sous_message.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_placer(_sous_message, Control.PRESET_CENTER, Vector2(-500, -100), Vector2(1000, 80))
	_sous_message.add_theme_font_size_override("font_size", 26)
	_sous_message.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	_sous_message.add_theme_constant_override("outline_size", 8)
	_sous_message.modulate.a = 0.0
	_racine.add_child(_sous_message)

	# Compteur
	_compteur = Compteur.new()
	var taille_compteur := 200.0 if tactile else 250.0
	_racine.add_child(_compteur)
	var tc := Vector2(taille_compteur, taille_compteur)
	if tactile:
		_placer(_compteur, Control.PRESET_CENTER_BOTTOM, Vector2(-taille_compteur * 0.5, -taille_compteur - 6), tc)
	else:
		_placer(_compteur, Control.PRESET_BOTTOM_RIGHT, Vector2(-taille_compteur - 24, -taille_compteur - 20), tc)

	# Minicarte
	_minicarte = MiniCarte.new()
	var tm := 220.0 if tactile else 260.0
	_minicarte.hud = self
	_racine.add_child(_minicarte)
	if tactile:
		_placer(_minicarte, Control.PRESET_TOP_RIGHT, Vector2(-tm - 20, 64), Vector2(tm, tm))
	else:
		_placer(_minicarte, Control.PRESET_BOTTOM_LEFT, Vector2(24, -tm - 24), Vector2(tm, tm))

	_grande_carte = MiniCarte.new()
	_grande_carte.complete = true
	_grande_carte.hud = self
	_grande_carte.visible = false
	_racine.add_child(_grande_carte)
	_placer(_grande_carte, Control.PRESET_CENTER, Vector2(-380, -380), Vector2(760, 760))

	_creer_pause()
	_creer_resultat()
	afficher_mission("", "", "", "")


func _placer(c: Control, preset: Control.LayoutPreset, pos: Vector2, taille: Vector2) -> void:
	c.set_anchors_preset(preset)
	c.offset_left = pos.x
	c.offset_top = pos.y
	c.offset_right = pos.x + taille.x
	c.offset_bottom = pos.y + taille.y


func _label(parent: Node, taille: int, c: Color) -> Label:
	var l := Label.new()
	l.add_theme_font_size_override("font_size", taille)
	l.add_theme_color_override("font_color", c)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.7))
	l.add_theme_constant_override("outline_size", 5)
	parent.add_child(l)
	return l


func _creer_pause() -> void:
	_pause = _ecran_modal("PAUSE")
	var vb := _pause.get_node("Centre/Panneau/VBox") as VBoxContainer
	for d in [["Reprendre", reprendre], ["Recommencer la mission", recommencer], ["Menu principal", retour_menu]]:
		var b := Button.new()
		b.text = d[0]
		b.custom_minimum_size = Vector2(380, 64)
		var sig: Signal = d[1]
		b.pressed.connect(func(): sig.emit())
		vb.add_child(b)
	var aide := Label.new()
	aide.text = "Clavier : Z/W ou ↑ accélérer • S ou ↓ freiner / reculer\nQ/A et D ou ←→ tourner • Espace frein à main\nC caméra • R replacer • H klaxon • M carte • Échap pause"
	aide.add_theme_font_size_override("font_size", 16)
	aide.add_theme_color_override("font_color", Color(0.75, 0.8, 0.9))
	aide.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(aide)


func _creer_resultat() -> void:
	_resultat = _ecran_modal("RÉSULTAT")
	var vb := _resultat.get_node("Centre/Panneau/VBox") as VBoxContainer
	_res_titre = vb.get_child(0) as Label
	_res_texte = Label.new()
	_res_texte.add_theme_font_size_override("font_size", 24)
	_res_texte.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_res_texte.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_res_texte.custom_minimum_size = Vector2(560, 0)
	vb.add_child(_res_texte)
	var b1 := Button.new()
	b1.text = "Rejouer"
	b1.custom_minimum_size = Vector2(380, 64)
	b1.pressed.connect(func(): continuer.emit())
	vb.add_child(b1)
	var b2 := Button.new()
	b2.text = "Menu principal"
	b2.custom_minimum_size = Vector2(380, 64)
	b2.pressed.connect(func(): retour_menu.emit())
	vb.add_child(b2)


func _ecran_modal(titre: String) -> Control:
	var fond := ColorRect.new()
	fond.color = Color(0, 0, 0, 0.55)
	fond.set_anchors_preset(Control.PRESET_FULL_RECT)
	fond.visible = false
	_racine.add_child(fond)
	var centre := CenterContainer.new()
	centre.name = "Centre"
	centre.set_anchors_preset(Control.PRESET_FULL_RECT)
	fond.add_child(centre)
	var p := PanelContainer.new()
	p.name = "Panneau"
	centre.add_child(p)
	var vb := VBoxContainer.new()
	vb.name = "VBox"
	vb.alignment = BoxContainer.ALIGNMENT_CENTER
	vb.add_theme_constant_override("separation", 14)
	p.add_child(vb)
	var t := Label.new()
	t.text = titre
	t.add_theme_font_size_override("font_size", 44)
	t.add_theme_color_override("font_color", Color(1, 0.82, 0.2))
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(t)
	return fond


# --- API ---------------------------------------------------------------

func definir(v: Voiture, cam: Camera3D, m: Monde) -> void:
	voiture = v
	camera = cam
	monde = m
	_compteur.voiture = v


func afficher_mission(titre: String, objectif: String, chrono: String, info: String) -> void:
	_titre.text = titre
	_objectif.text = objectif
	_chrono.text = chrono
	_info.text = info
	_chrono.visible = chrono != ""
	_info.visible = info != ""
	_panneau_mission.visible = titre != ""


func definir_chrono(t: String, urgent := false) -> void:
	_chrono.text = t
	_chrono.visible = t != ""
	_chrono.add_theme_color_override("font_color", Color(1, 0.35, 0.3) if urgent else Color.WHITE)


func definir_info(t: String) -> void:
	_info.text = t
	_info.visible = t != ""


func definir_objectif(t: String) -> void:
	_objectif.text = t


func message(texte: String, sous := "", duree := 2.5, c := Color.WHITE) -> void:
	_message.text = texte
	_message.add_theme_color_override("font_color", c)
	_sous_message.text = sous
	if _tween_msg:
		_tween_msg.kill()
	_message.modulate.a = 1.0
	_sous_message.modulate.a = 1.0 if sous != "" else 0.0
	_message.scale = Vector2.ONE
	_tween_msg = create_tween()
	_tween_msg.tween_interval(duree)
	_tween_msg.tween_property(_message, "modulate:a", 0.0, 0.5)
	_tween_msg.parallel().tween_property(_sous_message, "modulate:a", 0.0, 0.5)


func montrer_pause(v: bool) -> void:
	_pause.visible = v


func montrer_resultat(titre: String, texte: String) -> void:
	_res_titre.text = titre
	_res_texte.text = texte
	_resultat.visible = true


func cacher_resultat() -> void:
	_resultat.visible = false


func resultat_visible() -> bool:
	return _resultat.visible


func basculer_carte() -> void:
	_grande_carte.visible = not _grande_carte.visible


func montrer_jeu(v: bool) -> void:
	_racine.visible = v


func _process(_delta: float) -> void:
	if not _racine.visible:
		return
	_argent.text = GameData.formater_argent(GameData.argent)
	_compteur.queue_redraw()
	_minicarte.queue_redraw()
	if _grande_carte.visible:
		_grande_carte.queue_redraw()
	if voiture and camera and cible != Vector3.INF:
		var v := cible - voiture.global_position
		var avant := -camera.global_basis.z
		var cap_cam := atan2(avant.x, avant.z)
		var cap_cible := atan2(v.x, v.z)
		_boussole.angle = wrapf(cap_cam - cap_cible, -PI, PI)
		_boussole.couleur = couleur_cible
		_boussole.visible = true
		var d := Vector2(v.x, v.z).length()
		_distance.text = ("%d m" % int(d)) if d < 1000.0 else ("%.1f km" % (d / 1000.0))
		_distance.visible = true
	else:
		_boussole.visible = false
		_distance.visible = false


# =====================================================================
class Compteur extends Control:
	var voiture: Voiture

	func _draw() -> void:
		if voiture == null:
			return
		var c := size * 0.5
		var r := size.x * 0.44
		var police := ThemeDB.fallback_font
		draw_circle(c, r + 8, Color(0.04, 0.05, 0.07, 0.72))
		var a0 := deg_to_rad(135.0)
		var a1 := deg_to_rad(405.0)
		draw_arc(c, r - 6, a0, a1, 64, Color(1, 1, 1, 0.12), 10.0, true)
		var rmax: float = voiture.def["regime_max"]
		var rouge := a0 + (a1 - a0) * 0.88
		draw_arc(c, r - 6, rouge, a1, 16, Color(0.9, 0.15, 0.1, 0.5), 10.0, true)
		var k := clampf(voiture.regime / rmax, 0.0, 1.0)
		var col := Color(0.3, 0.85, 1.0).lerp(Color(1.0, 0.25, 0.15), clampf((k - 0.75) * 4.0, 0.0, 1.0))
		draw_arc(c, r - 6, a0, a0 + (a1 - a0) * k, 64, col, 10.0, true)
		# Graduations (x1000 tr/min)
		var n := int(ceil(rmax / 1000.0))
		for i in n + 1:
			var a := a0 + (a1 - a0) * (float(i) * 1000.0 / rmax)
			if a > a1 + 0.01:
				break
			var p1 := c + Vector2(cos(a), sin(a)) * (r - 18)
			var p2 := c + Vector2(cos(a), sin(a)) * (r - 26)
			draw_line(p1, p2, Color(1, 1, 1, 0.6), 2.0)
			draw_string(police, c + Vector2(cos(a), sin(a)) * (r - 40) - Vector2(6, -6), str(i), HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color(1, 1, 1, 0.6))
		var v := voiture.vitesse_kmh() if GameData.unite_kmh else voiture.vitesse_kmh() * 0.621
		var txt := str(int(round(v)))
		var fs := int(size.x * 0.26)
		draw_string(police, Vector2(0, c.y + fs * 0.32), txt, HORIZONTAL_ALIGNMENT_CENTER, size.x, fs, Color.WHITE)
		draw_string(police, Vector2(0, c.y + fs * 0.32 + 26), "km/h" if GameData.unite_kmh else "mph", HORIZONTAL_ALIGNMENT_CENTER, size.x, 18, Color(1, 1, 1, 0.7))
		var g := "R" if voiture.rapport < 0 else str(voiture.rapport)
		if voiture.vitesse < 0.5 and voiture.accelerateur < 0.05 and voiture.pedale_frein < 0.05:
			g = "N"
		draw_string(police, Vector2(0, c.y + r * 0.78), g, HORIZONTAL_ALIGNMENT_CENTER, size.x, 30, Color(1, 0.82, 0.2))


# =====================================================================
class Boussole extends Control:
	var angle := 0.0
	var couleur := Color(1, 0.8, 0.1)

	func _draw() -> void:
		var c := size * 0.5
		draw_circle(c, 40, Color(0.04, 0.05, 0.07, 0.6))
		var pts := PackedVector2Array([Vector2(0, -30), Vector2(20, 18), Vector2(0, 8), Vector2(-20, 18)])
		var rot := Transform2D(angle, c)
		var tr := PackedVector2Array()
		for p in pts:
			tr.append(rot * p)
		draw_colored_polygon(tr, couleur)
		draw_polyline(tr + PackedVector2Array([tr[0]]), Color(0, 0, 0, 0.8), 2.0, true)

	func _process(_d: float) -> void:
		queue_redraw()


# =====================================================================
class MiniCarte extends Control:
	var hud: HUD
	var complete := false
	var texture: Texture2D = preload("res://assets/ui/minimap.png")

	func _ready() -> void:
		clip_contents = true
		mouse_filter = Control.MOUSE_FILTER_IGNORE

	func _draw() -> void:
		if hud == null or hud.voiture == null or hud.monde == null:
			return
		var lim: Rect2 = hud.monde.limites
		var pos := hud.voiture.global_position
		var c := size * 0.5
		draw_rect(Rect2(Vector2.ZERO, size), Color(0.1, 0.12, 0.1, 0.85))
		var phi := 0.0
		var echelle := 0.0
		var centre_monde := Vector2(pos.x, pos.z)
		if complete:
			echelle = size.x / 1400.0
			centre_monde = Vector2(0, 0)
		else:
			echelle = size.x / 420.0
			var cap := hud.voiture.cap()
			if hud.camera:
				var av := -hud.camera.global_basis.z
				cap = atan2(av.x, av.z)
			phi = -PI * 0.5 - atan2(cos(cap), sin(cap))
		draw_set_transform(c, phi, Vector2(echelle, echelle))
		draw_texture_rect(texture, Rect2(lim.position - centre_monde, lim.size), false, Color(1, 1, 1, 0.95))
		draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
		var rot := Transform2D(phi, c)
		# Objectifs
		if hud.cible_suivante != Vector3.INF:
			_point(rot, echelle, centre_monde, hud.cible_suivante, Color(1, 1, 1, 0.7), 6.0)
		if hud.cible != Vector3.INF:
			_point(rot, echelle, centre_monde, hud.cible, hud.couleur_cible, 9.0)
		# Joueur
		var pj := rot * ((Vector2(pos.x, pos.z) - centre_monde) * echelle)
		var cap_v := hud.voiture.cap()
		var dir := Vector2(sin(cap_v), cos(cap_v)).rotated(phi)
		var perp := Vector2(-dir.y, dir.x)
		var tri := PackedVector2Array([pj + dir * 11, pj - dir * 7 + perp * 7, pj - dir * 7 - perp * 7])
		draw_colored_polygon(tri, Color(1, 1, 1))
		draw_polyline(tri + PackedVector2Array([tri[0]]), Color(0, 0, 0), 1.5, true)
		draw_rect(Rect2(Vector2.ZERO, size), Color(1, 1, 1, 0.5), false, 2.0)

	func _point(rot: Transform2D, echelle: float, centre_monde: Vector2, p: Vector3, col: Color, r: float) -> void:
		var sp := rot * ((Vector2(p.x, p.z) - centre_monde) * echelle)
		var c := size * 0.5
		var marge := 10.0
		var hors := sp.x < marge or sp.y < marge or sp.x > size.x - marge or sp.y > size.y - marge
		if hors:
			var d := sp - c
			var k := minf((c.x - marge) / maxf(absf(d.x), 0.001), (c.y - marge) / maxf(absf(d.y), 0.001))
			sp = c + d * k
		draw_circle(sp, r + 2, Color(0, 0, 0, 0.8))
		draw_circle(sp, r, col)


# =====================================================================
class Theme_:
	static func creer() -> Theme:
		var t := Theme.new()
		t.default_font_size = 22
		var panneau := StyleBoxFlat.new()
		panneau.bg_color = Color(0.05, 0.06, 0.09, 0.78)
		panneau.set_corner_radius_all(14)
		panneau.set_content_margin_all(16)
		panneau.border_color = Color(1, 0.82, 0.2, 0.35)
		panneau.set_border_width_all(1)
		t.set_stylebox("panel", "PanelContainer", panneau)
		t.set_stylebox("panel", "Panel", panneau)
		var bn := StyleBoxFlat.new()
		bn.bg_color = Color(0.13, 0.15, 0.2, 0.95)
		bn.set_corner_radius_all(12)
		bn.set_content_margin_all(12)
		bn.border_color = Color(1, 1, 1, 0.12)
		bn.set_border_width_all(1)
		var bh := bn.duplicate() as StyleBoxFlat
		bh.bg_color = Color(0.22, 0.25, 0.32, 0.98)
		bh.border_color = Color(1, 0.82, 0.2, 0.8)
		var bp := bn.duplicate() as StyleBoxFlat
		bp.bg_color = Color(0.95, 0.72, 0.1, 1.0)
		var bd := bn.duplicate() as StyleBoxFlat
		bd.bg_color = Color(0.1, 0.1, 0.12, 0.7)
		t.set_stylebox("normal", "Button", bn)
		t.set_stylebox("hover", "Button", bh)
		t.set_stylebox("focus", "Button", bh)
		t.set_stylebox("pressed", "Button", bp)
		t.set_stylebox("disabled", "Button", bd)
		t.set_color("font_pressed_color", "Button", Color(0.1, 0.1, 0.1))
		t.set_color("font_hover_color", "Button", Color(1, 0.9, 0.5))
		t.set_color("font_focus_color", "Button", Color(1, 0.9, 0.5))
		t.set_font_size("font_size", "Button", 24)
		t.set_font_size("font_size", "Label", 22)
		return t
