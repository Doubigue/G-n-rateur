extends VehicleBody3D
class_name Voiture
## Véhicule physique : suspension, boîte de vitesses, aérodynamique,
## direction progressive, frein à main et détection des chocs.

signal choc(intensite: float)
signal rapport_change(rapport: int)

const REPOS_SUSPENSION := 0.22
const COURSE_SUSPENSION := 0.18

var id_vehicule := "taxi"
var def: Dictionary = {}
var roues: Array[VehicleWheel3D] = []
var roues_avant: Array[VehicleWheel3D] = []
var roues_arriere: Array[VehicleWheel3D] = []
var roues_motrices: Array[VehicleWheel3D] = []
var modele: Node3D
var roues_visuelles: Array = []  # [Node3D, Transform3D de base, est_avant]

# Pilotage
var controle_actif := true
var accelerateur := 0.0
var pedale_frein := 0.0
var direction := 0.0
var frein_a_main := false
var rapport := 1          # -1 = marche arrière, 1..n = rapports avant
var regime := 800.0
var vitesse := 0.0        # m/s (norme)
var vitesse_long := 0.0   # m/s (signée, vers l'avant)
var glissement := 0.0     # 0..1, pour le son des pneus
var au_sol := true
var charge_moteur := 0.0  # 0..1, pour le son
var distance_parcourue := 0.0

var _v_prec := Vector3.ZERO
var _temps_coupure := 0.0
var _temps_retourne := 0.0
var _angle_roue := 0.0
var _frames := 0


func configurer(id: String) -> void:
	id_vehicule = id
	def = GameData.definition(id)
	name = "Voiture"
	mass = def["masse"]
	center_of_mass_mode = RigidBody3D.CENTER_OF_MASS_MODE_CUSTOM
	center_of_mass = Vector3(0.0, 0.38, def["centre_z"] + 0.05)
	angular_damp = 0.4
	linear_damp = 0.0
	continuous_cd = true
	can_sleep = false
	contact_monitor = true
	max_contacts_reported = 4
	var mat_phys := PhysicsMaterial.new()
	mat_phys.friction = 0.35
	mat_phys.bounce = 0.05
	physics_material_override = mat_phys

	_creer_collisions()
	_creer_modele()
	_creer_roues()

	var audio = preload("res://scripts/son_moteur.gd").new()
	audio.name = "SonMoteur"
	add_child(audio)


func _creer_collisions() -> void:
	var t: Vector3 = def["taille"]
	var bas := 0.30
	var h1: float = t.y * 0.42
	var caisse := CollisionShape3D.new()
	var b1 := BoxShape3D.new()
	b1.size = Vector3(t.x - 0.2, h1, t.z - 0.15)
	caisse.shape = b1
	caisse.position = Vector3(0, bas + h1 * 0.5, def["centre_z"])
	add_child(caisse)
	var h2: float = max(t.y - bas - h1 - 0.05, 0.25)
	var habitacle := CollisionShape3D.new()
	var b2 := BoxShape3D.new()
	b2.size = Vector3(t.x * 0.72, h2, t.z * 0.48)
	habitacle.shape = b2
	habitacle.position = Vector3(0, bas + h1 + h2 * 0.5, def["centre_z"] - 0.1)
	add_child(habitacle)


func _creer_modele() -> void:
	modele = Node3D.new()
	modele.name = "Modele"
	modele.position = def["decalage"]
	modele.rotation_degrees.y = def["rotation_y"]
	add_child(modele)
	var scene: PackedScene = load(def["modele"])
	if scene == null:
		push_error("Modèle introuvable : %s" % def["modele"])
		return
	var inst := scene.instantiate()
	if inst is Node3D:
		(inst as Node3D).scale = Vector3.ONE * float(def["echelle"])
	modele.add_child(inst)
	_chercher_roues_visuelles(inst)


func _chercher_roues_visuelles(racine: Node) -> void:
	# Roues séparées dans le modèle (ex. taxi : lgnWFL, lgnWFR, lgnWRL, lgnWRR)
	var re := RegEx.new()
	re.compile("(?i)^lgnW([FR])([LR])")
	var pile: Array = [racine]
	while not pile.is_empty():
		var n: Node = pile.pop_back()
		for c in n.get_children():
			pile.append(c)
		if n is Node3D:
			var m := re.search(n.name)
			if m:
				roues_visuelles.append([n, (n as Node3D).transform, m.get_string(1).to_upper() == "F"])


func _creer_roues() -> void:
	var k: float = def["suspension"]
	var compression_statique := 9.81 / (4.0 * k)
	var y: float = def["roue_y"] + REPOS_SUSPENSION - compression_statique
	var integrale: bool = def["transmission"] == "integrale"
	for avant in [true, false]:
		for cote in [-1.0, 1.0]:
			var w := VehicleWheel3D.new()
			w.name = ("Roue" + ("Av" if avant else "Ar") + ("G" if cote > 0 else "D"))
			w.position = Vector3(cote * float(def["roue_x"]), y, def["roue_av_z"] if avant else def["roue_ar_z"])
			w.wheel_radius = def["rayon"]
			w.wheel_rest_length = REPOS_SUSPENSION
			w.suspension_travel = COURSE_SUSPENSION
			w.suspension_stiffness = k
			w.damping_compression = 0.35 * sqrt(k)
			w.damping_relaxation = 0.5 * sqrt(k)
			w.suspension_max_force = float(def["masse"]) * 16.0
			w.wheel_roll_influence = 0.08
			w.wheel_friction_slip = float(def["adherence"]) * (1.0 if avant else 1.06)
			w.use_as_steering = avant
			w.use_as_traction = integrale or not avant
			add_child(w)
			roues.append(w)
			if avant:
				roues_avant.append(w)
			else:
				roues_arriere.append(w)
			if w.use_as_traction:
				roues_motrices.append(w)


func _physics_process(delta: float) -> void:
	_frames += 1
	var fwd := global_basis.z
	vitesse = linear_velocity.length()
	vitesse_long = linear_velocity.dot(fwd)
	distance_parcourue += vitesse * delta

	_lire_commandes()
	_gerer_boite(delta)
	_appliquer_moteur_freins(delta)
	_appliquer_direction(delta)
	_aerodynamique()
	_etat_pneus()
	_detecter_choc(delta)
	_verifier_retournement(delta)


func _lire_commandes() -> void:
	if not controle_actif:
		accelerateur = 0.0
		pedale_frein = 1.0
		direction = 0.0
		frein_a_main = true
		return
	accelerateur = Input.get_action_strength("accelerer")
	pedale_frein = Input.get_action_strength("freiner")
	direction = Input.get_action_strength("gauche") - Input.get_action_strength("droite")
	frein_a_main = Input.is_action_pressed("frein_main")


func _gerer_boite(delta: float) -> void:
	var rapports: Array = def["rapports"]
	var n := rapports.size()
	_temps_coupure = max(0.0, _temps_coupure - delta)
	# Passage marche arrière / marche avant
	if rapport >= 1 and pedale_frein > 0.1 and accelerateur < 0.1 and vitesse_long < 0.8:
		rapport = -1
		rapport_change.emit(rapport)
	elif rapport == -1 and accelerateur > 0.1 and vitesse_long > -0.8:
		rapport = 1
		rapport_change.emit(rapport)

	var ratio := _ratio_actuel()
	var tours_roue: float = abs(vitesse_long) / float(def["rayon"]) * 60.0 / TAU
	var ralenti: float = def["regime_ralenti"]
	var rmax: float = def["regime_max"]
	var cible: float = tours_roue * ratio * float(def["pont"])
	# Patinage d'embrayage au démarrage
	var gaz := accelerateur if rapport >= 1 else pedale_frein
	if abs(rapport) == 1 or not au_sol:
		cible = max(cible, ralenti + gaz * rmax * (0.45 if au_sol else 0.9))
	cible = clamp(cible, ralenti, rmax * 1.02)
	regime = lerp(regime, cible, clamp(delta * 12.0, 0.0, 1.0))

	if rapport >= 1:
		if GameData.boite_auto:
			if regime > rmax * 0.93 and rapport < n and _temps_coupure <= 0.0 and au_sol:
				rapport += 1
				_temps_coupure = 0.25
				rapport_change.emit(rapport)
			elif rapport > 1 and _temps_coupure <= 0.0:
				var ratio_inf: float = rapports[rapport - 2] * float(def["pont"])
				var regime_inf := tours_roue * ratio_inf
				if regime_inf < rmax * 0.62:
					rapport -= 1
					_temps_coupure = 0.15
					rapport_change.emit(rapport)
		else:
			if Input.is_action_just_pressed("rapport_plus") and rapport < n:
				rapport += 1
				_temps_coupure = 0.2
				rapport_change.emit(rapport)
			if Input.is_action_just_pressed("rapport_moins") and rapport > 1:
				rapport -= 1
				rapport_change.emit(rapport)


func _ratio_actuel() -> float:
	var rapports: Array = def["rapports"]
	if rapport == -1:
		return 3.2
	return rapports[clamp(rapport, 1, rapports.size()) - 1]


func _couple(r: float) -> float:
	var rmax: float = def["regime_max"]
	if r >= rmax:
		return 0.0
	var x := r / rmax
	return float(def["couple"]) * clamp(0.6 + 1.2 * x - 0.9 * x * x, 0.3, 1.0)


func _appliquer_moteur_freins(delta: float) -> void:
	var gaz := 0.0
	var frein := 0.0
	if rapport >= 1:
		gaz = accelerateur
		frein = pedale_frein
	else:
		gaz = pedale_frein
		frein = accelerateur
	if _temps_coupure > 0.0:
		gaz *= 0.1
	charge_moteur = gaz

	var force := _couple(regime) * gaz * _ratio_actuel() * float(def["pont"]) * 0.88 / float(def["rayon"])
	# Vitesse max en marche arrière ~ 35 km/h
	if rapport == -1:
		force = -force
		if vitesse_long < -10.0:
			force = 0.0
	var par_roue: float = force / float(maxi(1, roues_motrices.size()))
	for w in roues:
		w.engine_force = par_roue if w.use_as_traction else 0.0

	# Freinage : impulsion par roue (dépend du pas physique)
	var impulsion_max := float(def["masse"]) * 11.0 * delta / 4.0
	var frein_moteur := 0.0
	if gaz < 0.05 and vitesse > 1.0:
		frein_moteur = 0.05
	for w in roues:
		var f: float = max(frein, frein_moteur)
		var repartition := 1.15 if w.use_as_steering else 0.85
		w.brake = f * impulsion_max * repartition

	# Frein à main : bloque l'arrière et réduit l'adhérence (dérapage)
	var adh: float = def["adherence"]
	for w in roues_arriere:
		if frein_a_main:
			w.brake = max(w.brake, impulsion_max * 1.4)
			w.wheel_friction_slip = adh * 0.5
			w.engine_force = 0.0 if def["transmission"] != "integrale" else w.engine_force * 0.3
		else:
			w.wheel_friction_slip = lerp(w.wheel_friction_slip, adh * 1.06, 0.08)

	# À l'arrêt complet sans commande : on immobilise
	if gaz < 0.02 and frein < 0.02 and vitesse < 0.4 and au_sol:
		for w in roues:
			w.brake = impulsion_max * 0.6


func _appliquer_direction(delta: float) -> void:
	var v_kmh := vitesse * 3.6
	var facteur: float = lerp(1.0, 0.18, clamp(v_kmh / 190.0, 0.0, 1.0))
	var cible: float = direction * float(def["braquage"]) * facteur
	var vitesse_volant := 2.2 if abs(cible) > abs(steering) else 3.5
	steering = move_toward(steering, cible, delta * vitesse_volant)
	_animer_roues(delta)


func _animer_roues(delta: float) -> void:
	if roues_visuelles.is_empty():
		return
	_angle_roue += vitesse_long / float(def["rayon"]) * delta
	_angle_roue = wrapf(_angle_roue, -TAU, TAU)
	for rv in roues_visuelles:
		var n: Node3D = rv[0]
		if not is_instance_valid(n):
			continue
		var base: Transform3D = rv[1]
		var parent := n.get_parent() as Node3D
		if parent == null:
			continue
		var inv := parent.global_basis.inverse()
		var axe := (inv * global_basis.x).normalized()
		var haut := (inv * global_basis.y).normalized()
		var b := Basis(axe, _angle_roue) * base.basis.orthonormalized()
		if rv[2]:
			b = Basis(haut, steering) * b
		n.transform = Transform3D(b.scaled(base.basis.get_scale()), base.origin)


func _aerodynamique() -> void:
	var v := linear_velocity
	var trainee: float = def["trainee"]
	apply_central_force(-v * v.length() * trainee)
	if au_sol:
		apply_central_force(-global_basis.y * float(def["appui"]) * vitesse * vitesse)
		if vitesse > 0.5:
			apply_central_force(-v.normalized() * mass * 0.12)
		# Légère aide anti-tête-à-queue : amortit la rotation en lacet excessive
		var lacet := angular_velocity.dot(global_basis.y)
		if not frein_a_main and vitesse > 8.0:
			apply_torque(-global_basis.y * lacet * mass * 0.35)


func _etat_pneus() -> void:
	var contact := 0
	var mini := 1.0
	for w in roues:
		if w.is_in_contact():
			contact += 1
			mini = min(mini, w.get_skidinfo())
	au_sol = contact >= 2
	var derive := 0.0
	if vitesse > 3.0:
		var lat: float = abs(linear_velocity.dot(global_basis.x))
		derive = clamp((lat - 2.0) / 8.0, 0.0, 1.0)
	var g: float = clampf(1.0 - mini, 0.0, 1.0)
	if contact == 0:
		g = 0.0
		derive = 0.0
	glissement = lerp(glissement, max(g, derive), 0.2)


func _detecter_choc(delta: float) -> void:
	if _frames > 30:
		var dv := (linear_velocity - _v_prec).length()
		var attendu := 32.0 * delta
		if dv > attendu + 2.5:
			choc.emit(dv)
	_v_prec = linear_velocity


func _verifier_retournement(delta: float) -> void:
	if global_basis.y.y < 0.35 and vitesse < 3.0:
		_temps_retourne += delta
		if _temps_retourne > 2.5:
			_temps_retourne = 0.0
			remettre_droit()
	else:
		_temps_retourne = 0.0


func remettre_droit() -> void:
	var yaw := atan2(global_basis.z.x, global_basis.z.z)
	placer(global_position + Vector3.UP * 1.5, yaw)


func placer(pos: Vector3, yaw: float) -> void:
	global_transform = Transform3D(Basis(Vector3.UP, yaw), pos)
	linear_velocity = Vector3.ZERO
	angular_velocity = Vector3.ZERO
	_v_prec = Vector3.ZERO
	_frames = 0
	steering = 0.0
	rapport = 1
	for w in roues:
		w.engine_force = 0.0
		w.brake = 0.0


func vitesse_kmh() -> float:
	return vitesse * 3.6


func cap() -> float:
	return atan2(global_basis.z.x, global_basis.z.z)
