extends Node
## Données globales : véhicules, sauvegarde, réglages et touches.

const SAVE_PATH := "user://sauvegarde.cfg"

## Définition des véhicules jouables.
## Les valeurs de modèle (échelle, rotation, roues) ont été mesurées dans les fichiers GLB.
## Convention : l'avant du véhicule est l'axe +Z du VehicleBody3D.
var vehicules := {
	"taxi": {
		"nom": "Taxi Jaune",
		"description": "Berline robuste et confortable. Idéale pour transporter des clients.",
		"modele": "res://assets/models/taxi.glb",
		"echelle": 1.0,
		"rotation_y": 180.0,
		"decalage": Vector3(0.0, 0.0, 0.0),
		"taille": Vector3(2.0, 1.75, 4.65),
		"centre_z": -0.13,
		"roue_x": 0.66, "roue_av_z": 1.34, "roue_ar_z": -1.53, "roue_y": 0.36, "rayon": 0.36,
		"masse": 1750.0,
		"couple": 380.0, "regime_max": 5600.0, "regime_ralenti": 750.0,
		"rapports": [3.4, 2.1, 1.45, 1.1, 0.86],
		"pont": 3.3,
		"transmission": "propulsion",
		"adherence": 1.7,
		"trainee": 0.60,
		"appui": 0.02,
		"suspension": 38.0,
		"braquage": 0.58,
		"cylindres": 8,
		"prix": 0,
		"son_grave": 0.85,
	},
	"alfa": {
		"nom": "Alfa Romeo Giulia GTAm",
		"description": "Berline sportive italienne de 540 ch. Précise et agile.",
		"modele": "res://assets/models/alfa_romeo_giulia_gtam.glb",
		"echelle": 100.0,
		"rotation_y": 0.0,
		"decalage": Vector3(0.0, 0.0, 0.0),
		"taille": Vector3(2.0, 1.42, 4.65),
		"centre_z": -0.02,
		"roue_x": 0.72, "roue_av_z": 1.50, "roue_ar_z": -1.32, "roue_y": 0.33, "rayon": 0.33,
		"masse": 1580.0,
		"couple": 600.0, "regime_max": 7000.0, "regime_ralenti": 850.0,
		"rapports": [3.6, 2.35, 1.7, 1.3, 1.0, 0.82],
		"pont": 3.1,
		"transmission": "propulsion",
		"adherence": 2.0,
		"trainee": 0.40,
		"appui": 0.08,
		"suspension": 52.0,
		"braquage": 0.55,
		"cylindres": 6,
		"prix": 25000,
		"son_grave": 1.0,
	},
	"lambo": {
		"nom": "Lamborghini Sesto Elemento (Police)",
		"description": "Supercar en carbone, 570 ch, transmission intégrale. Une fusée.",
		"modele": "res://assets/models/lamborghini_police.glb",
		"echelle": 100.0,
		"rotation_y": 0.0,
		"decalage": Vector3(0.0, -1.02, 0.0),
		"taille": Vector3(1.98, 1.23, 4.3),
		"centre_z": 0.03,
		"roue_x": 0.80, "roue_av_z": 1.11, "roue_ar_z": -1.41, "roue_y": 0.34, "rayon": 0.34,
		"masse": 1000.0,
		"couple": 540.0, "regime_max": 8500.0, "regime_ralenti": 1000.0,
		"rapports": [3.1, 2.15, 1.6, 1.25, 1.0, 0.8],
		"pont": 3.5,
		"transmission": "integrale",
		"adherence": 2.3,
		"trainee": 0.36,
		"appui": 0.18,
		"suspension": 70.0,
		"braquage": 0.52,
		"cylindres": 10,
		"prix": 60000,
		"son_grave": 1.15,
	},
}

var ordre_vehicules := ["taxi", "alfa", "lambo"]

# --- Progression ---
var argent: int = 2000
var vehicule_choisi: String = "taxi"
var vehicules_possedes: Array = ["taxi"]
var meilleurs_temps := {}  # "circuit_1" -> secondes
var stats := {"courses": 0, "livraisons": 0, "clients": 0, "distance_km": 0.0}

# --- Réglages ---
var volume_general: float = 0.8
var qualite_haute: bool = true
var commandes_tactiles: int = 0  # 0 = auto, 1 = toujours, 2 = jamais
var boite_auto: bool = true
var unite_kmh: bool = true


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_creer_touches()
	if OS.has_feature("mobile"):
		qualite_haute = false
	charger()
	appliquer_volume()


func _creer_touches() -> void:
	_action("accelerer", [KEY_W, KEY_UP], [], JOY_AXIS_TRIGGER_RIGHT, 1.0)
	_action("freiner", [KEY_S, KEY_DOWN], [], JOY_AXIS_TRIGGER_LEFT, 1.0)
	_action("gauche", [KEY_A, KEY_LEFT], [], JOY_AXIS_LEFT_X, -1.0)
	_action("droite", [KEY_D, KEY_RIGHT], [], JOY_AXIS_LEFT_X, 1.0)
	_action("frein_main", [KEY_SPACE], [JOY_BUTTON_A])
	_action("camera", [KEY_C], [JOY_BUTTON_Y])
	_action("reinitialiser", [KEY_R], [JOY_BUTTON_BACK])
	_action("pause", [KEY_ESCAPE, KEY_P], [JOY_BUTTON_START])
	_action("klaxon", [KEY_H], [JOY_BUTTON_LEFT_STICK])
	_action("carte", [KEY_M], [JOY_BUTTON_X])
	_action("rapport_plus", [KEY_E], [JOY_BUTTON_RIGHT_SHOULDER])
	_action("rapport_moins", [KEY_F], [JOY_BUTTON_LEFT_SHOULDER])


func _action(nom: String, touches: Array, boutons: Array, axe: int = -1, sens: float = 0.0) -> void:
	if not InputMap.has_action(nom):
		InputMap.add_action(nom, 0.2)
	for k in touches:
		var ev := InputEventKey.new()
		ev.physical_keycode = k
		InputMap.action_add_event(nom, ev)
	for b in boutons:
		var jb := InputEventJoypadButton.new()
		jb.button_index = b
		InputMap.action_add_event(nom, jb)
	if axe >= 0:
		var ja := InputEventJoypadMotion.new()
		ja.axis = axe
		ja.axis_value = sens
		InputMap.action_add_event(nom, ja)


func definition(id: String) -> Dictionary:
	return vehicules.get(id, vehicules["taxi"])


func gagner(somme: int) -> void:
	argent = max(0, argent + somme)
	sauvegarder()


func acheter(id: String) -> bool:
	if id in vehicules_possedes:
		return true
	var prix: int = definition(id)["prix"]
	if argent < prix:
		return false
	argent -= prix
	vehicules_possedes.append(id)
	sauvegarder()
	return true


func enregistrer_temps(circuit: String, temps: float) -> bool:
	var ancien: float = meilleurs_temps.get(circuit, INF)
	if temps < ancien:
		meilleurs_temps[circuit] = temps
		sauvegarder()
		return true
	return false


func appliquer_volume() -> void:
	var bus := AudioServer.get_bus_index("Master")
	AudioServer.set_bus_volume_db(bus, linear_to_db(max(volume_general, 0.001)))


func utiliser_tactile() -> bool:
	match commandes_tactiles:
		1: return true
		2: return false
	return DisplayServer.is_touchscreen_available() or OS.has_feature("mobile")


func formater_temps(t: float) -> String:
	if t == INF or t < 0.0:
		return "--:--.--"
	var m := int(t / 60.0)
	var s := t - m * 60.0
	return "%02d:%05.2f" % [m, s]


func formater_argent(v: int) -> String:
	var s := str(abs(v))
	var out := ""
	var n := 0
	for i in range(s.length() - 1, -1, -1):
		out = s[i] + out
		n += 1
		if n % 3 == 0 and i > 0:
			out = " " + out
	return ("-" if v < 0 else "") + out + " $"


func sauvegarder() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("joueur", "argent", argent)
	cfg.set_value("joueur", "vehicule_choisi", vehicule_choisi)
	cfg.set_value("joueur", "vehicules_possedes", vehicules_possedes)
	cfg.set_value("joueur", "meilleurs_temps", meilleurs_temps)
	cfg.set_value("joueur", "stats", stats)
	cfg.set_value("reglages", "volume", volume_general)
	cfg.set_value("reglages", "qualite_haute", qualite_haute)
	cfg.set_value("reglages", "tactile", commandes_tactiles)
	cfg.set_value("reglages", "boite_auto", boite_auto)
	cfg.set_value("reglages", "kmh", unite_kmh)
	cfg.save(SAVE_PATH)


func charger() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SAVE_PATH) != OK:
		return
	argent = cfg.get_value("joueur", "argent", argent)
	vehicule_choisi = cfg.get_value("joueur", "vehicule_choisi", vehicule_choisi)
	vehicules_possedes = cfg.get_value("joueur", "vehicules_possedes", vehicules_possedes)
	meilleurs_temps = cfg.get_value("joueur", "meilleurs_temps", meilleurs_temps)
	var st = cfg.get_value("joueur", "stats", stats)
	if st is Dictionary:
		stats.merge(st, true)
	volume_general = cfg.get_value("reglages", "volume", volume_general)
	qualite_haute = cfg.get_value("reglages", "qualite_haute", qualite_haute)
	commandes_tactiles = cfg.get_value("reglages", "tactile", commandes_tactiles)
	boite_auto = cfg.get_value("reglages", "boite_auto", boite_auto)
	unite_kmh = cfg.get_value("reglages", "kmh", unite_kmh)
	if not vehicules.has(vehicule_choisi) or not (vehicule_choisi in vehicules_possedes):
		vehicule_choisi = "taxi"
