extends Node3D
class_name Marqueur
## Balise d'objectif : colonne lumineuse, anneau au sol, flèche flottante et texte.

var couleur := Color(1.0, 0.8, 0.1)
var texte := ""
var rayon := 7.0
var _fleche: MeshInstance3D
var _anneau: MeshInstance3D
var _temps := 0.0


func configurer(c: Color, t: String, r: float = 7.0) -> Marqueur:
	couleur = c
	texte = t
	rayon = r
	return self


func _ready() -> void:
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	mat.albedo_color = Color(couleur.r, couleur.g, couleur.b, 0.22)
	mat.disable_receive_shadows = true

	var colonne := MeshInstance3D.new()
	var cyl := CylinderMesh.new()
	cyl.top_radius = rayon * 0.55
	cyl.bottom_radius = rayon * 0.55
	cyl.height = 70.0
	cyl.cap_top = false
	cyl.cap_bottom = false
	cyl.radial_segments = 32
	colonne.mesh = cyl
	colonne.material_override = mat
	colonne.position.y = 35.0
	colonne.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(colonne)

	var mat_vif := StandardMaterial3D.new()
	mat_vif.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat_vif.albedo_color = couleur
	mat_vif.emission_enabled = true
	mat_vif.emission = couleur
	mat_vif.emission_energy_multiplier = 2.0

	_anneau = MeshInstance3D.new()
	var tore := TorusMesh.new()
	tore.inner_radius = rayon - 0.35
	tore.outer_radius = rayon
	tore.rings = 48
	_anneau.mesh = tore
	_anneau.material_override = mat_vif
	_anneau.position.y = 0.15
	_anneau.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(_anneau)

	_fleche = MeshInstance3D.new()
	var prisme := PrismMesh.new()
	prisme.size = Vector3(1.6, 1.6, 0.4)
	_fleche.mesh = prisme
	_fleche.material_override = mat_vif
	_fleche.rotation_degrees.z = 180.0
	_fleche.position.y = 5.0
	add_child(_fleche)

	if texte != "":
		var l := Label3D.new()
		l.text = texte
		l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		l.fixed_size = false
		l.pixel_size = 0.02
		l.font_size = 96
		l.outline_size = 18
		l.modulate = Color.WHITE
		l.outline_modulate = Color(0, 0, 0, 0.8)
		l.position.y = 7.2
		l.no_depth_test = true
		add_child(l)


func _process(delta: float) -> void:
	_temps += delta
	if _fleche:
		_fleche.position.y = 5.0 + sin(_temps * 3.0) * 0.4
		_fleche.rotation.y += delta * 2.0
	if _anneau:
		var s := 1.0 + sin(_temps * 4.0) * 0.04
		_anneau.scale = Vector3(s, 1, s)
