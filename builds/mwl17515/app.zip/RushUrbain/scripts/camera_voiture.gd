extends Camera3D
class_name CameraVoiture
## Caméra de poursuite avec lissage, collision avec les bâtiments,
## champ de vision dynamique, secousses lors des chocs et vue orbitale (menu).

const MODES := ["Poursuite", "Poursuite lointaine", "Capot"]

var cible: Voiture
var mode := 0
var orbite := false
var _angle_orbite := 0.0
var _cap := 0.0
var _secousse := 0.0
var _rng := RandomNumberGenerator.new()


func _ready() -> void:
	top_level = true
	fov = 70.0
	near = 0.08
	far = 4000.0


func suivre(v: Voiture) -> void:
	cible = v
	_cap = v.cap()
	if not v.choc.is_connected(secouer):
		v.choc.connect(secouer)
	_placer_immediatement()


func secouer(intensite: float) -> void:
	_secousse = clampf(_secousse + intensite * 0.025, 0.0, 0.5)


func changer_mode() -> void:
	mode = (mode + 1) % MODES.size()


func _placer_immediatement() -> void:
	if cible == null:
		return
	var dir := Vector3(sin(_cap), 0, cos(_cap))
	global_position = cible.global_position - dir * 7.0 + Vector3.UP * 2.5
	look_at(cible.global_position + Vector3.UP, Vector3.UP)


func _process(delta: float) -> void:
	if cible == null or not is_instance_valid(cible):
		return
	var pos_v := cible.global_position
	if orbite:
		_angle_orbite += delta * 0.22
		var p := pos_v + Vector3(sin(_angle_orbite) * 7.5, 2.0, cos(_angle_orbite) * 7.5)
		global_position = global_position.lerp(p, 1.0 - exp(-delta * 3.0))
		look_at(pos_v + Vector3.UP * 0.7, Vector3.UP)
		fov = lerpf(fov, 55.0, delta * 2.0)
		return

	var vitesse_kmh := cible.vitesse_kmh()
	if mode == 2:
		var t: Vector3 = cible.def["taille"]
		var p_capot := cible.to_global(Vector3(0, t.y * 0.68, float(cible.def["roue_av_z"]) * 0.55))
		global_transform = Transform3D(cible.global_basis * Basis(Vector3.UP, PI), p_capot)
		fov = lerpf(fov, 75.0 + clampf(vitesse_kmh / 250.0, 0.0, 1.0) * 12.0, delta * 3.0)
		_appliquer_secousse(delta)
		return

	# Cap lissé : suit la direction du véhicule (ou du déplacement en marche arrière)
	var cap_cible := cible.cap()
	_cap = lerp_angle(_cap, cap_cible, 1.0 - exp(-delta * (3.0 + vitesse_kmh / 60.0)))
	var dist := 6.2 if mode == 0 else 10.0
	var haut := 2.1 if mode == 0 else 3.4
	dist += clampf(vitesse_kmh / 200.0, 0.0, 1.0) * 1.5
	var dir := Vector3(sin(_cap), 0, cos(_cap))
	var pivot := pos_v + Vector3.UP * 1.3
	var voulu := pos_v - dir * dist + Vector3.UP * haut

	# Évite de traverser les murs
	var espace := get_world_3d().direct_space_state
	var req := PhysicsRayQueryParameters3D.create(pivot, voulu)
	req.exclude = [cible.get_rid()]
	var hit := espace.intersect_ray(req)
	if not hit.is_empty():
		voulu = hit["position"] + (pivot - voulu).normalized() * 0.4

	global_position = global_position.lerp(voulu, 1.0 - exp(-delta * 9.0))
	if global_position.distance_to(pivot) > 40.0:
		global_position = voulu
	look_at(pivot + dir * 3.0, Vector3.UP)
	fov = lerpf(fov, 68.0 + clampf(vitesse_kmh / 240.0, 0.0, 1.0) * 18.0, delta * 3.0)
	_appliquer_secousse(delta)


func _appliquer_secousse(delta: float) -> void:
	if _secousse <= 0.001:
		return
	_secousse = maxf(0.0, _secousse - delta * 0.9)
	var o := Vector3(_rng.randf_range(-1, 1), _rng.randf_range(-1, 1), _rng.randf_range(-1, 1)) * _secousse * 0.35
	global_position += o
