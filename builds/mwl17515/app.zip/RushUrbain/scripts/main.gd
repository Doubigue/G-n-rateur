extends Node
## Point d'entrée : chargement, menu, création du véhicule, pause et commandes globales.

var monde: Monde
var voiture: Voiture
var camera: CameraVoiture
var hud: HUD
var menu: MenuPrincipal
var missions: Missions
var tactile: CommandesTactiles
var en_jeu := false

var _chargement: CanvasLayer
var _barre: ProgressBar
var _texte_chargement: Label
var _delai_alerte := 0.0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_creer_ecran_chargement()
	await get_tree().process_frame

	monde = Monde.new()
	monde.name = "Monde"
	monde.process_mode = Node.PROCESS_MODE_PAUSABLE
	monde.add_to_group("monde")
	add_child(monde)
	monde.progression.connect(_maj_chargement)
	await monde.charger()

	camera = CameraVoiture.new()
	camera.name = "Camera"
	camera.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(camera)
	camera.current = true

	hud = HUD.new()
	add_child(hud)
	missions = Missions.new()
	missions.name = "Missions"
	missions.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(missions)

	_creer_voiture(GameData.vehicule_choisi)
	missions.initialiser(monde, voiture, hud)
	missions.fin_course.connect(_sur_fin_course)

	hud.reprendre.connect(_reprendre)
	hud.recommencer.connect(_recommencer)
	hud.retour_menu.connect(_retour_menu)
	hud.continuer.connect(_rejouer)

	menu = MenuPrincipal.new()
	add_child(menu)
	menu.jouer.connect(_lancer)
	menu.vehicule_change.connect(_sur_vehicule_change)

	tactile = CommandesTactiles.new()
	add_child(tactile)

	_afficher_menu()
	var t := create_tween()
	t.tween_property(_chargement.get_child(0), "modulate:a", 0.0, 0.6)
	t.tween_callback(_chargement.queue_free)


# --- Chargement ------------------------------------------------------

func _creer_ecran_chargement() -> void:
	_chargement = CanvasLayer.new()
	_chargement.layer = 50
	add_child(_chargement)
	var fond := ColorRect.new()
	fond.color = Color(0.04, 0.05, 0.07)
	fond.set_anchors_preset(Control.PRESET_FULL_RECT)
	_chargement.add_child(fond)
	var c := CenterContainer.new()
	c.set_anchors_preset(Control.PRESET_FULL_RECT)
	fond.add_child(c)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 18)
	c.add_child(vb)
	var titre := Label.new()
	titre.text = "RUSH URBAIN"
	titre.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	titre.add_theme_font_size_override("font_size", 80)
	titre.add_theme_color_override("font_color", Color(1, 0.8, 0.15))
	vb.add_child(titre)
	var st := Label.new()
	st.text = "Course • Livraison • Taxi"
	st.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	st.add_theme_font_size_override("font_size", 26)
	vb.add_child(st)
	_barre = ProgressBar.new()
	_barre.custom_minimum_size = Vector2(620, 26)
	_barre.max_value = 1.0
	_barre.step = 0.001
	_barre.show_percentage = false
	vb.add_child(_barre)
	_texte_chargement = Label.new()
	_texte_chargement.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_texte_chargement.add_theme_font_size_override("font_size", 20)
	_texte_chargement.text = "Préparation…"
	vb.add_child(_texte_chargement)


func _maj_chargement(v: float, texte: String) -> void:
	if is_instance_valid(_barre):
		_barre.value = v
		_texte_chargement.text = texte


# --- Véhicule --------------------------------------------------------

func _creer_voiture(id: String) -> void:
	var pos := monde.depart + Vector3.UP * 0.6
	var cap := monde.cap_depart
	if voiture and is_instance_valid(voiture):
		voiture.queue_free()
	voiture = Voiture.new()
	voiture.configurer(id)
	voiture.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(voiture)
	voiture.placer(pos, cap)
	camera.suivre(voiture)
	hud.definir(voiture, camera, monde)
	missions.changer_voiture(voiture)


func _sur_vehicule_change(id: String) -> void:
	_creer_voiture(id)
	voiture.controle_actif = false


# --- États de jeu ----------------------------------------------------

func _afficher_menu() -> void:
	en_jeu = false
	get_tree().paused = false
	menu.montrer(true)
	hud.montrer_jeu(false)
	hud.montrer_pause(false)
	hud.cacher_resultat()
	tactile.visible = false
	camera.orbite = true
	voiture.controle_actif = false
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


func _lancer(mode: String, circuit: int) -> void:
	if voiture.id_vehicule != GameData.vehicule_choisi:
		_creer_voiture(GameData.vehicule_choisi)
	menu.montrer(false)
	hud.montrer_jeu(true)
	tactile.visible = GameData.utiliser_tactile()
	camera.orbite = false
	voiture.controle_actif = true
	voiture.placer(monde.depart + Vector3.UP * 0.6, monde.cap_depart)
	en_jeu = true
	missions.demarrer(mode, circuit)
	var noms := {"course": "Course contre la montre", "livraison": "Livraison", "taxi": "Taxi", "libre": "Balade libre"}
	if mode != "course":
		hud.message(noms.get(mode, ""), "Bonne route !", 2.0, Color(1, 0.82, 0.2))


func _reprendre() -> void:
	get_tree().paused = false
	hud.montrer_pause(false)


func _recommencer() -> void:
	_reprendre()
	hud.cacher_resultat()
	voiture.placer(monde.depart + Vector3.UP * 0.6, monde.cap_depart)
	missions.recommencer()


func _rejouer() -> void:
	hud.cacher_resultat()
	missions.recommencer()


func _retour_menu() -> void:
	missions.arreter()
	voiture.placer(monde.depart + Vector3.UP * 0.6, monde.cap_depart)
	_afficher_menu()


func _sur_fin_course(titre: String, texte: String) -> void:
	hud.montrer_resultat(titre, texte)


# --- Commandes globales ----------------------------------------------

func _process(delta: float) -> void:
	if not en_jeu or voiture == null:
		return
	if Input.is_action_just_pressed("pause") and not hud.resultat_visible():
		var p := not get_tree().paused
		get_tree().paused = p
		hud.montrer_pause(p)
	if get_tree().paused:
		return
	if Input.is_action_just_pressed("camera"):
		camera.changer_mode()
		hud.message("", "Caméra : " + CameraVoiture.MODES[camera.mode], 1.0)
	if Input.is_action_just_pressed("carte"):
		hud.basculer_carte()
	if Input.is_action_just_pressed("reinitialiser") and voiture.controle_actif:
		_replacer()

	# Sortie de la ville / chute
	_delai_alerte = maxf(0.0, _delai_alerte - delta)
	var y := voiture.global_position.y
	if y < -40.0:
		_replacer()
	elif y < -0.95 and _delai_alerte <= 0.0:
		_delai_alerte = 6.0
		hud.message("", "Vous êtes hors de la ville : appuyez sur R (ou ↺) pour revenir sur la route.", 3.0, Color(1, 0.8, 0.4))


func _replacer() -> void:
	var p := monde.point_le_plus_proche(voiture.global_position)
	var cap := monde.cap_route(p, voiture.cap())
	voiture.placer(p + Vector3.UP * 0.8, cap)
	hud.message("", "Véhicule replacé sur la route", 1.2)
