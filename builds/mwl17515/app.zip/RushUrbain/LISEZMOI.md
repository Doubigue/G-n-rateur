# RUSH URBAIN — Course • Livraison • Taxi (Godot 4)

Jeu de conduite réaliste en français, dans une grande ville américaine (≈ 3,4 km × 3,4 km).

## Ouvrir le projet
1. Installer **Godot 4.3 ou plus récent** (version standard, pas besoin de .NET).
2. Godot → *Importer* → choisir `project.godot`.
3. Attendre la fin de l'import des modèles (la ville et les 3 voitures), puis **F5**.

## Modes de jeu
| Mode | Objectif | Gains |
|---|---|---|
| **Course contre la montre** | 3 circuits (Sprint urbain, Grand tour, Marathon de l'autoroute). Enchaîner les points de contrôle. | Médaille or / argent / bronze + bonus record |
| **Livraison** | Charger un colis au dépôt, le livrer avant la fin du chrono. Chaque choc abîme le colis. | Distance × état du colis + bonus de temps |
| **Taxi** | Récupérer un client (il fait signe), le déposer à destination. Compteur, confort, avis client. | Prix de la course + pourboire (rapidité + douceur) |
| **Balade libre** | Explorer la ville. | — |

Les gains permettent d'acheter les véhicules : **Taxi** (offert), **Alfa Romeo Giulia GTAm** (25 000 $), **Lamborghini Sesto Elemento Police** (60 000 $). Sauvegarde automatique (argent, véhicules, records, réglages).

## Commandes
| Action | Clavier (AZERTY/QWERTY) | Manette |
|---|---|---|
| Accélérer | Z (W en QWERTY) / ↑ | Gâchette droite |
| Freiner / marche arrière | S / ↓ | Gâchette gauche |
| Tourner | Q (A) et D / ← → | Stick gauche |
| Frein à main | Espace | A |
| Caméra (poursuite, lointaine, capot) | C | Y |
| Replacer sur la route | R | Back |
| Klaxon | H | Clic stick gauche |
| Grande carte | M | X |
| Rapports (boîte manuelle) | E / F | RB / LB |
| Pause | Échap / P | Start |

Les touches sont « positionnelles » : ZQSD en AZERTY = WASD en QWERTY.
Sur téléphone/tablette, des **commandes tactiles multi-points** s'affichent automatiquement (réglable dans Options).

## Réalisme
- `VehicleBody3D` avec suspension amortie calculée par véhicule, adhérence des pneus réaliste, frein à main qui fait décrocher l'arrière, propulsion ou transmission intégrale.
- Moteur simulé : courbe de couple, régime, **boîte automatique** (ou manuelle), coupure au passage de rapport, rupteur, frein moteur.
- Traînée aérodynamique, appui (supercar), résistance au roulement, assistance anti-tête-à-queue légère.
- **Son moteur synthétisé en temps réel** selon le régime, la charge et le nombre de cylindres (V8 taxi, V6 Alfa, V10 Lamborghini) + crissement de pneus, vent, chocs, klaxon — aucun fichier audio requis.
- Ciel procédural, soleil avec ombres, brume atmosphérique, SSAO, tonemapping ACES (qualité réduite automatiquement sur mobile).

## Structure
```
project.godot            configuration (autoload GameData, rendu Forward+ / Mobile)
scenes/main.tscn         scène principale
scripts/
  main.gd                chargement, menu, pause, replacement
  game_data.gd           véhicules, sauvegarde, réglages, touches
  monde.gd               ville GLB, collisions, ciel, lumière, points de route
  voiture.gd             physique du véhicule, boîte, direction, chocs
  son_moteur.gd          synthèse audio moteur/pneus/vent/klaxon
  camera_voiture.gd      caméras de poursuite / capot / orbite du menu
  missions.gd            course, livraison, taxi, balade
  hud.gd                 compteur, minicarte, boussole, messages, pause, résultats
  menu.gd                menu principal, garage, options
  tactile.gd             commandes tactiles
  marqueur.gd, pieton.gd balises d'objectif, clients
assets/models/           ville.glb, taxi.glb, alfa_romeo_giulia_gtam.glb, lamborghini_police.glb
assets/data/city_data.json  points de route praticables, départ, quartiers (pré-calculés)
assets/ui/minimap.png    minicarte générée depuis la ville
outils/                  scripts Python ayant servi à analyser la ville
```

## Notes techniques
- Le modèle de ville est en « Z vers le haut » : il est redressé de −90° sur X au chargement.
- Les collisions de la ville sont générées automatiquement au lancement (écran de chargement).
- Les objectifs sont placés uniquement sur les routes connectées et accessibles (analyse de hauteur/marches faite hors-ligne → `city_data.json`).
- Si vous changez de ville, relancez `outils/raster.py ville.glb dossier_sortie` pour régénérer les données et la minicarte.

## Export Android
Projet → Exporter → Ajouter… → Android (installer les modèles d'export et configurer le SDK/keystore dans les paramètres de l'éditeur). Le rendu passe automatiquement en « Mobile ».
