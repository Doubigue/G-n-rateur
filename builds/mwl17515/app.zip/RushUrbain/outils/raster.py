import sys,json,re; sys.path.insert(0, __import__('os').path.dirname(__file__))
from glbinfo import *
from scipy import ndimage
from PIL import Image
j,b=load(sys.argv[1]); OUT=sys.argv[2]
mats=j['materials']
RES=2.0
X0,X1,Y0,Y1=-1700,1710,-1710,1710
NX=int((X1-X0)/RES); NY=int((Y1-Y0)/RES)
top=np.full((NY,NX),-1e9); col=np.zeros((NY,NX,3)); water=np.zeros((NY,NX),bool)
def colof(p,P,W,base):
    if 'COLOR_0' in p['attributes']:
        C=acc(j,b,p['attributes']['COLOR_0']).astype(float)
        if C.max()>1.5: C/=255. if C.max()<=255 else 65535.
        return C[:,:3]
    return np.tile(base[:3],(len(P),1))
WATER_RE=re.compile(r'water|sea|river|lake',re.I)
for i,n,M in walk(j):
    if 'mesh' not in n: continue
    isw=bool(WATER_RE.search(n.get('name','')))
    for p in j['meshes'][n['mesh']]['primitives']:
        P=acc(j,b,p['attributes']['POSITION']).astype(float)
        W=(M[:3,:3]@P.T).T+M[:3,3]
        base=np.array(mats[p['material']]['pbrMetallicRoughness'].get('baseColorFactor',[1,1,1,1])) if 'material' in p else np.ones(4)
        if 'material' in p and mats[p['material']].get('name')=='Water': isw2=True
        else: isw2=isw
        C=colof(p,P,W,base)
        I=acc(j,b,p['indices']).reshape(-1,3) if 'indices' in p else np.arange(len(P)).reshape(-1,3)
        T=W[I]; TC=C[I].mean(1)
        lo=T.min(1); hi=T.max(1)
        for k in range(len(T)):
            x0=int((lo[k,0]-X0)/RES); x1=int((hi[k,0]-X0)/RES)+1
            y0=int((lo[k,1]-Y0)/RES); y1=int((hi[k,1]-Y0)/RES)+1
            x0=max(x0,0);y0=max(y0,0);x1=min(x1,NX);y1=min(y1,NY)
            if x0>=x1 or y0>=y1: continue
            z=hi[k,2]
            sub=top[y0:y1,x0:x1]; m=z>sub
            sub[m]=z; col[y0:y1,x0:x1][m]=TC[k]
            if isw2:
                ws=water[y0:y1,x0:x1]; ws[m]=True
            else:
                ws=water[y0:y1,x0:x1]; ws[m]=False
has=top>-1e8
c=col
blue=(c[...,2]>c[...,0]+0.2)&(c[...,2]>c[...,1]+0.05)
water|=blue&(top<1.5)&has
open_=has&(top<0.45)&~water
# step connectivity: label regions where neighbor height diff <=0.3
er=ndimage.binary_erosion(open_,structure=np.ones((3,3)))
# build components respecting steps: break edges with large dh by marking "cliff" cells
gy,gx=np.gradient(np.where(has,top,0))
cliff=(np.abs(gx)>0.3)|(np.abs(gy)>0.3)
drv=er&~ndimage.binary_dilation(cliff&has,iterations=0) if False else er&~cliff
lab,nl=ndimage.label(drv)
sizes=ndimage.sum(drv,lab,range(1,nl+1))
big=np.argmax(sizes)+1
comp=lab==big
print('cells open',open_.sum(),'drv',drv.sum(),'largest',sizes.max(),'n',nl)
# road-like: dark grey
lum=c.mean(-1); sat=c.max(-1)-c.min(-1)
road=comp&(lum<0.32)&(sat<0.08)
print('road cells',road.sum())
ys,xs=np.nonzero(road)
# subsample every ~10m
keep=((ys%5)==0)&((xs%5)==0)
pts=[]
for y,x in zip(ys[keep],xs[keep]):
    gxw=X0+(x+0.5)*RES; gyw=Y0+(y+0.5)*RES
    pts.append([round(gxw,1),round(float(top[y,x]),2),round(-gyw,1)])  # godot (x, z, -y)
# spawn: road cell nearest origin
d=(xs*RES+X0)**2+(ys*RES+Y0)**2; s=np.argmin(d)
spawn=[X0+(xs[s]+0.5)*RES, float(top[ys[s],xs[s]]), -(Y0+(ys[s]+0.5)*RES)]
# road direction at spawn: count road extent along x vs y
y,x=ys[s],xs[s]
ex=road[y,max(0,x-15):x+15].sum(); ey=road[max(0,y-15):y+15,x].sum()
zy,zx=np.nonzero(comp&((np.arange(NY)[:,None]%7)==0)&((np.arange(NX)[None,:]%7)==0))
zone=[[round(X0+(x+0.5)*RES,1),round(float(top[y,x]),2),round(-(Y0+(y+0.5)*RES),1)] for y,x in zip(zy,zx)]
print('zone',len(zone))
json.dump({'zone_points':zone,'res':RES,'bounds':[X0,X1,-Y1,-Y0],'spawn':spawn,'spawn_axis':'x' if ex>ey else 'z','road_points':pts},open(OUT+'/city_data.json','w'))
print('points',len(pts),'spawn',spawn,ex,ey)
# minimap image: godot X right, godot Z down (= -y) -> image row = flipud of y
img=np.where(has[...,None],c,np.array([0.12,0.14,0.12]))
img=np.where(water[...,None],np.array([0.18,0.45,0.65]),img)
blk=has&(top>=0.45)&~water
img=np.where(blk[...,None],img*0.6+0.25,img)
img=np.where(road[...,None],np.array([0.30,0.31,0.34]),img)
img=np.flipud(img)  # row0 = max y = min godot z
im=Image.fromarray((np.clip(img,0,1)**(1/1.4)*255).astype(np.uint8))
im=im.resize((1024,1024),Image.LANCZOS); im.save(OUT+'/minimap.png')
dbg=np.flipud(np.dstack([blk,comp,water]).astype(np.uint8)*255); pass
