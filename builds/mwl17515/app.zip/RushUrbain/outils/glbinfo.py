import json,struct,sys,numpy as np
CT={5126:np.float32,5123:np.uint16,5125:np.uint32,5121:np.uint8}
NC={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}
def load(f):
    d=open(f,'rb').read(); l=struct.unpack('<I',d[12:16])[0]
    j=json.loads(d[20:20+l]); off=20+l; bl=struct.unpack('<I',d[off:off+4])[0]
    return j,d[off+8:off+8+bl]
def acc(j,b,i):
    a=j['accessors'][i]; bv=j['bufferViews'][a['bufferView']]
    n=NC[a['type']]; dt=CT[a['componentType']]
    o=bv.get('byteOffset',0)+a.get('byteOffset',0)
    st=bv.get('byteStride',0); isz=np.dtype(dt).itemsize*n
    if st and st!=isz:
        raw=np.frombuffer(b,np.uint8,a['count']*st,o).reshape(-1,st)[:,:isz]
        return np.ascontiguousarray(raw).view(dt).reshape(-1,n)
    return np.frombuffer(b,dt,a['count']*n,o).reshape(-1,n)
def q2m(q):
    x,y,z,w=q
    return np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]])
def local(n):
    if 'matrix' in n: return np.array(n['matrix']).reshape(4,4).T
    M=np.eye(4)
    if 'rotation' in n: M[:3,:3]=q2m(n['rotation'])
    if 'scale' in n: M[:3,:3]=M[:3,:3]@np.diag(n['scale'])
    if 'translation' in n: M[:3,3]=n['translation']
    return M
def walk(j):
    out=[]
    sc=j['scenes'][j.get('scene',0)]
    st=[(r,np.eye(4)) for r in sc['nodes']]
    while st:
        i,P=st.pop(); n=j['nodes'][i]; M=P@local(n)
        out.append((i,n,M))
        for c in n.get('children',[]): st.append((c,M))
    return out
