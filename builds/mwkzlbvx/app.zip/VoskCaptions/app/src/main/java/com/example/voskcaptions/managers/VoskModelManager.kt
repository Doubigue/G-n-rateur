package com.example.voskcaptions.managers

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.example.voskcaptions.data.SettingsRepository
import com.google.mlkit.nl.translate.TranslateLanguage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.vosk.Model
import org.vosk.Recognizer
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.util.Locale
import java.util.zip.ZipInputStream

data class ModelInfo(
    val name: String,
    val path: String,
    val sizeBytes: Long,
    val voskLangCode: String?,
    val languageName: String,
    val mlKitLang: String?
)

sealed interface ModelState {
    data object Idle : ModelState
    /** percent = -1 si la taille de l'archive est inconnue. */
    data class Extracting(val percent: Int, val message: String) : ModelState
    data class Loading(val name: String) : ModelState
    data class Ready(val info: ModelInfo) : ModelState
    data class Error(val message: String) : ModelState
}

class VoskModelManager(
    private val context: Context,
    private val settings: SettingsRepository
) {
    companion object {
        const val SAMPLE_RATE = 16_000f
        private const val BUFFER_SIZE = 1 shl 16          // 64 Kio : RAM constante quelle que soit la taille du zip
        private const val IMPORT_PREFIX = ".import_"
    }

    private val modelsDir = File(context.filesDir, "vosk_models").apply { mkdirs() }

    private val _state = MutableStateFlow<ModelState>(ModelState.Idle)
    val state: StateFlow<ModelState> = _state.asStateFlow()

    private val _installed = MutableStateFlow<List<ModelInfo>>(emptyList())
    val installed: StateFlow<List<ModelInfo>> = _installed.asStateFlow()

    private val mutex = Mutex()
    private val modelLock = Any()
    private var model: Model? = null
    private var currentPath: String? = null

    // ---------------------------------------------------------------- API publique

    suspend fun refreshInstalled() = withContext(Dispatchers.IO) { refreshInstalledBlocking() }

    /** Recharge automatiquement le dernier modèle utilisé (si présent). */
    suspend fun restoreLastModel() {
        val name = settings.state.value.lastModel ?: return
        if (File(modelsDir, name).isDirectory) loadModel(name)
    }

    /**
     * Importe une archive .zip de modèle Vosk (n'importe quelle taille / langue),
     * détecte la racine valide, valide le modèle puis le charge.
     */
    suspend fun importZip(uri: Uri): Result<ModelInfo> = mutex.withLock {
        withContext(Dispatchers.IO) {
            val tmp = File(modelsDir, IMPORT_PREFIX + System.currentTimeMillis())
            try {
                val displayName = queryDisplayName(uri)
                val baseName = sanitize(displayName.removeSuffix(".zip").removeSuffix(".ZIP"))
                _state.value = ModelState.Extracting(0, displayName)

                extractZip(uri, tmp, querySize(uri), displayName)

                val root = findModelRoot(tmp)
                    ?: error("Aucune racine de modèle Vosk valide trouvée dans l'archive (dossiers am/conf/graph ou final.mdl introuvables).")
                validate(root)

                val target = File(modelsDir, baseName)
                if (target.exists()) {
                    if (currentPath == target.absolutePath) closeModelBlocking()
                    target.deleteRecursively()
                }
                if (!root.renameTo(target)) {
                    root.copyRecursively(target, overwrite = true)
                }
                tmp.deleteRecursively()

                refreshInstalledBlocking()
                Result.success(loadBlocking(target.name))
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                _state.value = ModelState.Error(friendly(t))
                Result.failure(Exception(friendly(t), t))
            } finally {
                if (tmp.exists()) tmp.deleteRecursively()
            }
        }
    }

    /** Charge (de façon asynchrone sur Dispatchers.IO) un modèle déjà installé. */
    suspend fun loadModel(name: String): Result<ModelInfo> = mutex.withLock {
        withContext(Dispatchers.IO) {
            try {
                Result.success(loadBlocking(name))
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                _state.value = ModelState.Error(friendly(t))
                Result.failure(Exception(friendly(t), t))
            }
        }
    }

    suspend fun deleteModel(name: String) = mutex.withLock {
        withContext(Dispatchers.IO) {
            val dir = File(modelsDir, name)
            if (currentPath == dir.absolutePath) {
                closeModelBlocking()
                _state.value = ModelState.Idle
                settings.update { it.copy(lastModel = null) }
            }
            dir.deleteRecursively()
            refreshInstalledBlocking()
        }
    }

    /** Crée un Recognizer 16 kHz mono sur le modèle courant (null si aucun modèle chargé). */
    fun createRecognizer(): Recognizer? = synchronized(modelLock) {
        model?.let { Recognizer(it, SAMPLE_RATE) }
    }

    /** Libère le modèle natif (Model.close()). Le Recognizer doit être fermé par son propriétaire. */
    fun release() {
        synchronized(modelLock) { closeModelBlocking() }
        _state.value = ModelState.Idle
    }

    // ---------------------------------------------------------------- chargement

    private fun loadBlocking(name: String): ModelInfo {
        val dir = File(modelsDir, name)
        require(dir.isDirectory) { "Modèle introuvable : $name" }
        _state.value = ModelState.Loading(name)
        closeModelBlocking()                    // libère l'ancien modèle AVANT d'allouer le nouveau
        val info = describe(dir)
        val loaded = Model(dir.absolutePath)    // peut durer plusieurs dizaines de secondes (gros modèles)
        synchronized(modelLock) {
            model = loaded
            currentPath = dir.absolutePath
        }
        settings.update { s ->
            s.copy(lastModel = name, sourceLang = info.mlKitLang ?: s.sourceLang)
        }
        _state.value = ModelState.Ready(info)
        return info
    }

    private fun closeModelBlocking() {
        synchronized(modelLock) {
            model?.let { runCatching { it.close() } }
            model = null
            currentPath = null
        }
        System.gc()
    }

    // ---------------------------------------------------------------- extraction ZIP en flux

    private class CountingInputStream(input: InputStream) : FilterInputStream(input) {
        var count = 0L
        override fun read(): Int = super.read().also { if (it >= 0) count++ }
        override fun read(b: ByteArray, off: Int, len: Int): Int =
            super.read(b, off, len).also { if (it > 0) count += it }
    }

    private suspend fun extractZip(uri: Uri, destDir: File, totalBytes: Long, label: String) {
        destDir.mkdirs()
        if (totalBytes > 0 && destDir.usableSpace < totalBytes * 2) {
            throw IOException("Espace de stockage insuffisant pour extraire ce modèle.")
        }
        val destCanonical = destDir.canonicalPath + File.separator
        val raw = context.contentResolver.openInputStream(uri) ?: throw IOException("Impossible d'ouvrir l'archive.")
        val counting = CountingInputStream(raw)
        val buf = ByteArray(BUFFER_SIZE)
        var lastPercent = -2

        ZipInputStream(BufferedInputStream(counting, BUFFER_SIZE)).use { zis ->
            while (true) {
                currentCoroutineContext().ensureActive()
                val entry = zis.nextEntry ?: break
                val entryName = entry.name.replace('\\', '/')
                if (entryName.startsWith("__MACOSX/") || entryName.endsWith(".DS_Store")) continue

                val out = File(destDir, entryName)
                if (!out.canonicalPath.startsWith(destCanonical)) {
                    throw SecurityException("Entrée ZIP invalide : $entryName")   // zip-slip
                }
                if (entry.isDirectory) {
                    out.mkdirs()
                    continue
                }
                out.parentFile?.mkdirs()
                FileOutputStream(out).use { fos ->
                    while (true) {
                        val n = zis.read(buf)
                        if (n < 0) break
                        fos.write(buf, 0, n)
                        val pct = if (totalBytes > 0) (counting.count * 100 / totalBytes).toInt().coerceIn(0, 99) else -1
                        if (pct != lastPercent) {
                            lastPercent = pct
                            _state.value = ModelState.Extracting(pct, label)
                        }
                    }
                }
                zis.closeEntry()
            }
        }
    }

    // ---------------------------------------------------------------- détection / validation

    private fun isModelRoot(d: File): Boolean {
        val hasAm = File(d, "am").isDirectory
        val hasConf = File(d, "conf").isDirectory
        val hasGraph = File(d, "graph").isDirectory
        val hasFinal = File(d, "am/final.mdl").isFile || File(d, "final.mdl").isFile
        return hasFinal || (hasAm && (hasConf || hasGraph)) || (hasConf && hasGraph)
    }

    /** Parcours en largeur : retourne le répertoire le moins profond qui ressemble à une racine de modèle Vosk. */
    fun findModelRoot(start: File): File? {
        val queue = ArrayDeque<File>()
        queue.add(start)
        while (queue.isNotEmpty()) {
            val dir = queue.removeFirst()
            if (isModelRoot(dir)) return dir
            dir.listFiles()?.filter { it.isDirectory }?.sortedBy { it.name }?.let { queue.addAll(it) }
        }
        return null
    }

    private fun validate(root: File) {
        val hasFinal = File(root, "am/final.mdl").isFile || File(root, "final.mdl").isFile
        if (!hasFinal) throw IOException("Modèle invalide : fichier final.mdl absent.")
        val conf = File(root, "conf")
        if (!conf.isDirectory || !(File(conf, "model.conf").isFile || File(conf, "mfcc.conf").isFile)) {
            throw IOException("Modèle invalide : dossier conf/ incomplet.")
        }
        if (!File(root, "graph").isDirectory && !File(root, "HCLG.fst").isFile) {
            throw IOException("Modèle invalide : dossier graph/ absent.")
        }
    }

    // ---------------------------------------------------------------- métadonnées

    private fun refreshInstalledBlocking() {
        _installed.value = modelsDir.listFiles { f -> f.isDirectory && !f.name.startsWith(IMPORT_PREFIX) }
            .orEmpty()
            .sortedBy { it.name.lowercase() }
            .map { describe(it) }
    }

    private fun describe(dir: File): ModelInfo {
        val code = detectLangCode(dir.name)
        val iso = code?.substringBefore('-')?.let { mapOf("cn" to "zh", "vn" to "vi", "kz" to "kk").getOrDefault(it, it) }
        return ModelInfo(
            name = dir.name,
            path = dir.absolutePath,
            sizeBytes = dir.walkTopDown().filter { it.isFile }.sumOf { it.length() },
            voskLangCode = code,
            languageName = languageName(iso, code),
            mlKitLang = iso?.let { TranslateLanguage.fromLanguageTag(it) }
        )
    }

    private val nameRegex = Regex("(?i)vosk-model(?:-small|-big|-spk|-lgraph)*-([a-z]{2,3}(?:-[a-z]{2,3})?)(?:-|$)")

    private fun detectLangCode(name: String): String? =
        nameRegex.find(name)?.groupValues?.get(1)?.lowercase()

    private fun languageName(iso: String?, code: String?): String {
        if (iso == null) return "Inconnue"
        val n = Locale.forLanguageTag(iso).getDisplayLanguage(Locale.getDefault())
        return if (n.isBlank() || n.equals(iso, true)) (code ?: iso) else n.replaceFirstChar { it.uppercase() }
    }

    private fun sanitize(s: String) = s.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "model_${System.currentTimeMillis()}" }

    private fun queryDisplayName(uri: Uri): String =
        context.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) c.getString(i) else null
        } ?: uri.lastPathSegment ?: "model.zip"

    private fun querySize(uri: Uri): Long =
        context.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.SIZE)
            if (i >= 0 && c.moveToFirst() && !c.isNull(i)) c.getLong(i) else -1L
        } ?: -1L

    private fun friendly(t: Throwable): String = when (t) {
        is OutOfMemoryError -> "Mémoire insuffisante pour charger ce modèle. Essayez un modèle plus léger."
        else -> t.message ?: t.javaClass.simpleName
    }
}
