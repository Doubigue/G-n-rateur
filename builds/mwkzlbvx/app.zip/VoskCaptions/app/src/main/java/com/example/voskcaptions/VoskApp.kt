package com.example.voskcaptions

import android.app.Application
import android.content.Context
import com.example.voskcaptions.data.HistoryRepository
import com.example.voskcaptions.data.SettingsRepository
import com.example.voskcaptions.managers.TranslationManager
import com.example.voskcaptions.managers.VoskModelManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.vosk.LibVosk
import org.vosk.LogLevel

/** Conteneur de singletons partagés entre l'UI et les services. */
class VoskApp : Application() {
    lateinit var settings: SettingsRepository
        private set
    lateinit var history: HistoryRepository
        private set
    lateinit var modelManager: VoskModelManager
        private set
    lateinit var translationManager: TranslationManager
        private set

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()
        LibVosk.setLogLevel(LogLevel.WARNINGS)
        settings = SettingsRepository(this)
        history = HistoryRepository(this)
        modelManager = VoskModelManager(this, settings)
        translationManager = TranslationManager(this, settings)

        // Le raccourci flottant peut démarrer le processus seul : on recharge donc le modèle ici.
        appScope.launch {
            modelManager.refreshInstalled()
            runCatching { translationManager.refreshDownloaded() }
            modelManager.restoreLastModel()
        }
    }
}

val Context.voskApp: VoskApp get() = applicationContext as VoskApp
