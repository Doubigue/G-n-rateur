package com.example.voskcaptions.util

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.widget.Toast

object ClipboardUtil {
    fun copy(context: Context, text: String, label: String = "Transcription") {
        if (text.isBlank()) return
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(label, text))
        // Android 13+ affiche déjà sa propre confirmation
        if (Build.VERSION.SDK_INT < 33) Toast.makeText(context, "Copié", Toast.LENGTH_SHORT).show()
    }
}
