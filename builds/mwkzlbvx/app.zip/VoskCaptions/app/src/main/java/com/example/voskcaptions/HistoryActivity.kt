package com.example.voskcaptions

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.text.format.DateFormat
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.voskcaptions.data.HistoryItem
import com.example.voskcaptions.databinding.ActivityHistoryBinding
import com.example.voskcaptions.databinding.ItemHistoryBinding
import com.example.voskcaptions.util.ClipboardUtil
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class HistoryActivity : AppCompatActivity() {

    private lateinit var b: ActivityHistoryBinding
    private val repo get() = voskApp.history
    private val query = MutableStateFlow("")
    private var items: List<HistoryItem> = emptyList()

    private val adapter = HistoryAdapter(
        onCopy = { ClipboardUtil.copy(this, it) },
        onDelete = { item -> lifecycleScope.launch(Dispatchers.IO) { repo.delete(item.id) } }
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.recycler.layoutManager = LinearLayoutManager(this)
        b.recycler.adapter = adapter

        b.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b4: Int, c: Int) { query.value = s?.toString().orEmpty() }
            override fun afterTextChanged(s: Editable?) {}
        })
        b.btnCopyAll.setOnClickListener { ClipboardUtil.copy(this, exportText(), "Historique") }
        b.btnShare.setOnClickListener {
            val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, exportText())
            startActivity(Intent.createChooser(send, "Exporter l'historique"))
        }
        b.btnClearAll.setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle("Vider tout l'historique ?")
                .setMessage("Cette action est définitive.")
                .setPositiveButton("Vider") { _, _ -> lifecycleScope.launch(Dispatchers.IO) { repo.clear() } }
                .setNegativeButton("Annuler", null)
                .show()
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                combine(repo.changes, query) { _, q -> q }.collect { q ->
                    val list = withContext(Dispatchers.IO) { repo.query(q) }
                    items = list
                    adapter.submitList(list)
                    b.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
                }
            }
        }
    }

    private fun exportText(): String = items.joinToString("\n\n") { i ->
        buildString {
            append("[").append(DateFormat.format("dd/MM/yyyy HH:mm:ss", i.timestamp)).append("]")
            if (i.label.isNotBlank()) append(" ").append(i.label)
            append("\n").append(i.original)
            if (i.translated.isNotBlank()) append("\n→ ").append(i.translated)
        }
    }
}

private class HistoryAdapter(
    private val onCopy: (String) -> Unit,
    private val onDelete: (HistoryItem) -> Unit
) : ListAdapter<HistoryItem, HistoryAdapter.VH>(object : DiffUtil.ItemCallback<HistoryItem>() {
    override fun areItemsTheSame(a: HistoryItem, b: HistoryItem) = a.id == b.id
    override fun areContentsTheSame(a: HistoryItem, b: HistoryItem) = a == b
}) {
    class VH(val b: ItemHistoryBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemHistoryBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        val i = getItem(position)
        val date = DateFormat.format("dd/MM HH:mm:ss", i.timestamp)
        h.b.tvMeta.text = if (i.label.isNotBlank()) "$date · ${i.label}" else date
        h.b.tvOriginal.text = i.original
        h.b.tvTranslated.text = i.translated
        h.b.rowTranslated.visibility = if (i.translated.isBlank()) View.GONE else View.VISIBLE
        h.b.btnCopyOriginal.setOnClickListener { onCopy(i.original) }
        h.b.btnCopyTranslated.setOnClickListener { onCopy(i.translated) }
        h.b.btnDelete.setOnClickListener { onDelete(i) }
    }
}
