package com.example.voskcaptions.ui

import android.graphics.Color
import androidx.core.graphics.ColorUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlin.math.max

enum class ColorMode(val key: String, val label: String) {
    AUTO("auto", "Auto — s'adapte à la vidéo"),
    CLASSIC("classic", "Blanc + jaune sur noir"),
    CONTRAST("contrast", "Jaune sur noir opaque"),
    CYAN("cyan", "Cyan sur noir"),
    GREEN("green", "Vert sur noir"),
    LIGHT("light", "Texte sombre sur blanc"),
    NIGHT("night", "Blanc sur bleu nuit");

    companion object {
        fun fromKey(k: String) = entries.firstOrNull { it.key == k } ?: AUTO
    }
}

data class OverlayScheme(
    val original: Int,
    val translated: Int,
    val label: Int,
    val icon: Int,
    val background: Int      // ARGB avec alpha
)

/** Couleur moyenne (RGB) de la zone d'écran voisine de la fenêtre flottante, mesurée par AudioCaptureService. */
object SceneColorBus {
    val avgColor = MutableStateFlow<Int?>(null)
}

object AdaptiveColors {
    private fun c(v: Long) = v.toInt()
    private val WHITE = Color.WHITE
    private val YELLOW = c(0xFFFFEB3B)

    /** Hystérésis pour éviter le clignotement entre thème clair et sombre. */
    fun isLightScene(avg: Int, previouslyLight: Boolean): Boolean {
        val l = ColorUtils.calculateLuminance(avg)
        return if (previouslyLight) l > 0.20 else l > 0.30
    }

    fun resolve(mode: ColorMode, avg: Int?, lightScene: Boolean, opacityPercent: Int): OverlayScheme {
        val a = (opacityPercent * 255 / 100).coerceIn(0, 255)
        return when (mode) {
            ColorMode.CLASSIC -> OverlayScheme(WHITE, YELLOW, c(0xFFFFB74D), WHITE, Color.argb(a, 0, 0, 0))
            ColorMode.CONTRAST -> OverlayScheme(WHITE, YELLOW, c(0xFFFFB74D), WHITE, Color.BLACK)
            ColorMode.CYAN -> OverlayScheme(WHITE, c(0xFF4DD0E1), c(0xFF80DEEA), WHITE, Color.argb(a, 0, 0, 0))
            ColorMode.GREEN -> OverlayScheme(WHITE, c(0xFF69F0AE), c(0xFFB9F6CA), WHITE, Color.argb(a, 0, 0, 0))
            ColorMode.LIGHT -> OverlayScheme(c(0xFF111111), c(0xFF0D47A1), c(0xFFE65100), c(0xFF111111), Color.argb(max(a, 150), 255, 255, 255))
            ColorMode.NIGHT -> OverlayScheme(WHITE, c(0xFFFFE082), c(0xFF90CAF9), WHITE, Color.argb(max(a, 120), 13, 27, 62))
            ColorMode.AUTO -> auto(avg, lightScene, a)
        }
    }

    private fun auto(avg: Int?, light: Boolean, userAlpha: Int): OverlayScheme {
        if (avg == null) return resolve(ColorMode.CLASSIC, null, false, userAlpha * 100 / 255)
        val video = avg or c(0xFF000000)
        return if (light) {
            // Vidéo claire : fond blanc quasi opaque + texte sombre
            val scrim = Color.argb(max(userAlpha, 205), 255, 255, 255)
            val eff = ColorUtils.compositeColors(scrim, video)
            val orig = pick(eff, listOf(c(0xFF111111), Color.BLACK))
            val tr = pick(eff, listOf(c(0xFF0D47A1), c(0xFF1B5E20), c(0xFF4A148C), c(0xFFB71C1C), Color.BLACK))
            val label = pick(eff, listOf(c(0xFFBF360C), c(0xFF424242), Color.BLACK))
            OverlayScheme(orig, tr, label, orig, scrim)
        } else {
            // Vidéo sombre : fond noir léger + texte clair
            val scrim = Color.argb(max(userAlpha, 115), 0, 0, 0)
            val eff = ColorUtils.compositeColors(scrim, video)
            val orig = pick(eff, listOf(WHITE, c(0xFFF5F5F5)))
            val tr = pick(eff, listOf(YELLOW, c(0xFF80DEEA), c(0xFFB9F6CA), WHITE))
            val label = pick(eff, listOf(c(0xFFFFB74D), c(0xFFFFE0B2), WHITE))
            OverlayScheme(orig, tr, label, orig, scrim)
        }
    }

    /** Premier candidat avec un contraste WCAG ≥ 4,5, sinon le meilleur. */
    private fun pick(bg: Int, candidates: List<Int>): Int =
        candidates.firstOrNull { ColorUtils.calculateContrast(it, bg) >= 4.5 }
            ?: candidates.maxBy { ColorUtils.calculateContrast(it, bg) }
}
