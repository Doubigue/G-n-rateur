package com.example.voskcaptions.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.atomic.AtomicLong

enum class SubtitleSource { SPEECH, MESSAGE }

data class SubtitleState(
    val source: SubtitleSource = SubtitleSource.SPEECH,
    val label: String = "",          // ex. "WhatsApp · Alice" pour les messages
    val original: String = "",
    val translated: String = "",
    val partial: Boolean = false,
    val stamp: Long = 0L,            // force une nouvelle émission même si le texte est identique
    val id: Long = 0L                // identifiant du segment (voir SubtitleBus.nextId) : une phrase publiée 2 fois (texte puis traduction) garde le même id
)

/** Une phrase (ou un message) de la transcription. */
data class Segment(val id: Long, val label: String, val original: String, val translated: String)

/** Transcription cumulée : phrases terminées + phrase en cours de reconnaissance. */
data class Transcript(val segments: List<Segment> = emptyList(), val partial: Segment? = null) {
    val isEmpty: Boolean get() = segments.isEmpty() && partial == null
}

/**
 * Bus unique entre les producteurs (audio, notifications) et l'overlay.
 * La transcription est CUMULÉE et conservée ici (donc même si la fenêtre flottante est fermée puis rouverte) :
 * elle ne se vide que lorsque l'utilisateur appuie sur « vider » (ou si l'effacement automatique est activé).
 */
object SubtitleBus {
    private const val MAX_SEGMENTS = 40

    private val ids = AtomicLong()
    fun nextId(): Long = ids.incrementAndGet()

    private val _state = MutableStateFlow(SubtitleState())
    val state: StateFlow<SubtitleState> = _state.asStateFlow()

    private val _transcript = MutableStateFlow(Transcript())
    val transcript: StateFlow<Transcript> = _transcript.asStateFlow()

    /** Tout segment d'id ≤ floorId est ignoré : une traduction tardive ne doit pas ressusciter un texte vidé. */
    private var floorId = 0L
    private var lastFinalId = 0L

    @Synchronized
    fun publish(s: SubtitleState) {
        if (s.original.isBlank() && s.translated.isBlank()) {          // « vider »
            floorId = ids.get()
            lastFinalId = floorId
            _transcript.value = Transcript()
            _state.value = s.copy(stamp = System.nanoTime())
            return
        }
        if (s.id in 1..floorId) return                                  // segment antérieur au dernier « vider »

        val cur = _transcript.value
        val seg = Segment(s.id, s.label, s.original, s.translated)
        if (s.partial) {
            val p = cur.partial
            if (s.id <= lastFinalId) return                             // partiel dépassé par une phrase terminée
            if (p != null && s.id < p.id) return                        // traduction tardive d'un ancien partiel
            _transcript.value = cur.copy(partial = seg)
        } else {
            val list = cur.segments.toMutableList()
            val idx = if (s.id > 0) list.indexOfFirst { it.id == s.id } else -1
            if (idx >= 0) list[idx] = seg else list += seg
            while (list.size > MAX_SEGMENTS) list.removeAt(0)
            if (s.id > lastFinalId) lastFinalId = s.id
            val p = cur.partial
            _transcript.value = Transcript(list, if (p != null && p.id <= s.id) null else p)
        }
        _state.value = s.copy(stamp = System.nanoTime())
    }

    fun clear() = publish(SubtitleState())
}
