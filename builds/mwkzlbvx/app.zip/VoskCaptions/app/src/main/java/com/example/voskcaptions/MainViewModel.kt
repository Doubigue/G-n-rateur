package com.example.voskcaptions

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.voskcaptions.services.AudioCaptureService
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as VoskApp
    private val models = app.modelManager
    private val translation = app.translationManager

    val modelState = models.state
    val installedModels = models.installed
    val settings = app.settings.state
    val downloadedLangs = translation.downloaded

    private val _langBusy = MutableStateFlow<String?>(null)
    val langBusy: StateFlow<String?> = _langBusy.asStateFlow()

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    init {
        viewModelScope.launch {
            models.refreshInstalled()
            runCatching { translation.refreshDownloaded() }
        }
    }

    private fun capturing() = AudioCaptureService.running.value

    // ---- Modèles Vosk
    fun importModel(uri: Uri) {
        if (capturing()) { _messages.tryEmit("Arrêtez le sous-titrage avant de changer de modèle"); return }
        viewModelScope.launch { models.importZip(uri).onFailure { _messages.tryEmit(it.message ?: "Échec de l'import") } }
    }

    fun loadModel(name: String) {
        if (capturing()) { _messages.tryEmit("Arrêtez le sous-titrage avant de changer de modèle"); return }
        viewModelScope.launch { models.loadModel(name).onFailure { _messages.tryEmit(it.message ?: "Échec du chargement") } }
    }

    fun deleteModel(name: String) {
        if (capturing()) { _messages.tryEmit("Arrêtez le sous-titrage avant de supprimer un modèle"); return }
        viewModelScope.launch { models.deleteModel(name) }
    }

    // ---- Traduction
    fun setSourceLang(tag: String) { app.settings.update { it.copy(sourceLang = tag) }; translation.closeAll() }
    fun setTargetLang(tag: String) { app.settings.update { it.copy(targetLang = tag) }; translation.closeAll() }

    fun downloadLanguages(tags: List<String>) {
        if (_langBusy.value != null) return
        viewModelScope.launch {
            for (tag in tags.distinct()) {
                if (tag in translation.downloaded.value) continue
                _langBusy.value = tag
                try {
                    translation.downloadLanguage(tag)
                } catch (e: Exception) {
                    _messages.tryEmit("Téléchargement impossible (${translation.displayName(tag)}) : ${e.message}")
                    break
                }
            }
            _langBusy.value = null
        }
    }

    fun deleteLanguage(tag: String) {
        viewModelScope.launch {
            try { translation.deleteLanguage(tag) }
            catch (e: Exception) { _messages.tryEmit("Suppression impossible : ${e.message}") }
        }
    }

    // ---- Overlay
    fun setTextSize(sp: Int) = app.settings.update { it.copy(textSizeSp = sp) }
    fun setOpacity(percent: Int) = app.settings.update { it.copy(bgOpacity = percent) }
    fun setShowOriginal(v: Boolean) = app.settings.update { it.copy(showOriginal = v) }
    fun setTranslateNotifications(v: Boolean) = app.settings.update { it.copy(translateNotifications = v) }
    fun setColorMode(key: String) = app.settings.update { it.copy(colorMode = key) }
    fun setAutoClear(on: Boolean) = app.settings.update { it.copy(autoClearSeconds = if (on) 10 else 0) }
    fun setShortcutEnabled(on: Boolean) = app.settings.update { it.copy(shortcutEnabled = on) }
}
