package com.example.voskcaptions.audio

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import kotlin.math.max

/**
 * Mesure la couleur moyenne d'une zone de l'écran via un VirtualDisplay basse résolution (1/8)
 * alimenté par la MediaProjection déjà accordée pour la capture audio.
 */
class ScreenColorSampler(
    private val context: Context,
    private val projection: MediaProjection,
    private val handler: Handler
) {
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var screenW = 1
    private var w = 64
    private var h = 64
    private var ema: FloatArray? = null

    fun start() {
        val dm = context.resources.displayMetrics
        screenW = dm.widthPixels
        w = max(64, dm.widthPixels / 8)
        h = max(64, dm.heightPixels / 8)
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader = r
        display = projection.createVirtualDisplay(
            "color-sampler", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, handler
        )
    }

    /** @return couleur moyenne lissée de [band] (coordonnées écran), ou null s'il n'y a pas de nouvelle image. */
    fun sample(band: Rect): Int? {
        val image = reader?.acquireLatestImage() ?: return null
        return try { readBand(image, band) } finally { image.close() }
    }

    private fun readBand(image: Image, band: Rect): Int? {
        val plane = image.planes[0]
        val buf = plane.buffer
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        val scale = w.toFloat() / screenW
        val x0 = (band.left * scale).toInt().coerceIn(0, w - 1)
        val x1 = (band.right * scale).toInt().coerceIn(x0 + 1, w)
        val y0 = (band.top * scale).toInt().coerceIn(0, h - 1)
        val y1 = (band.bottom * scale).toInt().coerceIn(y0 + 1, h)

        var r = 0L; var g = 0L; var b = 0L; var n = 0
        var y = y0
        while (y < y1) {
            var x = x0
            while (x < x1) {
                val o = y * rowStride + x * pixelStride
                if (o + 2 < buf.limit()) {
                    r += buf.get(o).toInt() and 0xFF
                    g += buf.get(o + 1).toInt() and 0xFF
                    b += buf.get(o + 2).toInt() and 0xFF
                    n++
                }
                x += 2
            }
            y += 2
        }
        if (n == 0) return null
        val cur = floatArrayOf(r.toFloat() / n, g.toFloat() / n, b.toFloat() / n)
        val e = ema?.let { old -> FloatArray(3) { old[it] + 0.5f * (cur[it] - old[it]) } } ?: cur
        ema = e
        return Color.rgb(e[0].toInt(), e[1].toInt(), e[2].toInt())
    }

    fun release() {
        runCatching { display?.release() }
        runCatching { reader?.close() }
        display = null; reader = null
    }
}
