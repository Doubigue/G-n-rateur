package com.example.voskcaptions

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.voskcaptions.managers.ModelState
import com.example.voskcaptions.services.AudioCaptureService
import com.example.voskcaptions.services.SubtitleOverlayService

/**
 * Activité transparente : Android impose une confirmation « Commencer l'enregistrement » à chaque
 * session de capture, qui ne peut être demandée que depuis une activité.
 */
class CaptureLauncherActivity : AppCompatActivity() {

    private val launcher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == RESULT_OK && data != null) {
            SubtitleOverlayService.start(this)
            ContextCompat.startForegroundService(this, AudioCaptureService.startIntent(this, r.resultCode, data))
        } else {
            toast("Capture refusée")
        }
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        when {
            voskApp.modelManager.state.value is ModelState.Loading -> {
                toast("Modèle en cours de chargement, réessayez dans un instant"); finish()
            }
            voskApp.modelManager.state.value !is ModelState.Ready -> openMain("Chargez d'abord un modèle Vosk")
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED ->
                openMain("Autorisez d'abord le micro dans l'application")
            !Settings.canDrawOverlays(this) -> openMain("Autorisez d'abord l'affichage par-dessus")
            else -> {
                val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                launcher.launch(mpm.createScreenCaptureIntent())
            }
        }
    }

    private fun openMain(msg: String) {
        toast(msg)
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
