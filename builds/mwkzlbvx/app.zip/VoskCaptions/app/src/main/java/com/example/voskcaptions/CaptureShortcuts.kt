package com.example.voskcaptions

import android.content.Context
import android.content.Intent
import com.example.voskcaptions.services.AudioCaptureService

/** Action unique « démarrer / arrêter » utilisée par la bulle flottante et le bouton d'accessibilité. */
object CaptureShortcuts {
    fun toggle(context: Context) {
        val app = context.applicationContext
        if (AudioCaptureService.running.value) {
            app.stopService(Intent(app, AudioCaptureService::class.java))
            return
        }
        app.startActivity(
            Intent(app, CaptureLauncherActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
        )
    }
}
