package com.example.voskcaptions

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.format.Formatter
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.example.voskcaptions.data.AppSettings
import com.example.voskcaptions.databinding.ActivityMainBinding
import com.example.voskcaptions.managers.ModelInfo
import com.example.voskcaptions.managers.ModelState
import com.example.voskcaptions.services.AudioCaptureService
import com.example.voskcaptions.services.FloatingShortcutService
import com.example.voskcaptions.services.SubtitleOverlayService
import com.example.voskcaptions.ui.ColorMode
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private val vm: MainViewModel by viewModels()

    private var installed: List<ModelInfo> = emptyList()
    private var langTags: List<String> = emptyList()
    private var downloaded: Set<String> = emptySet()
    private var modelBusy = false

    // ------------------------------------------------------------ Activity Result API

    private val pickZip = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let { vm.importModel(it) }
    }

    private val requestRuntime = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        refreshPermissions()
    }

    private val projectionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == RESULT_OK && data != null) {
            SubtitleOverlayService.start(this)
            ContextCompat.startForegroundService(this, AudioCaptureService.startIntent(this, r.resultCode, data))
        } else {
            toast("Capture de l'audio refusée")
        }
    }

    // ------------------------------------------------------------ cycle de vie

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        langTags = voskApp.translationManager.allLanguages()
        val names = langTags.map { voskApp.translationManager.displayName(it) }
        b.spSource.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        b.spTarget.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        renderPacks()
        b.spColorMode.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, ColorMode.entries.map { it.label }
        )

        setupListeners()
        observe()
    }

    override fun onResume() {
        super.onResume()
        refreshPermissions()
    }

    // ------------------------------------------------------------ listeners

    private fun setupListeners() {
        b.btnImport.setOnClickListener {
            pickZip.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))
        }
        b.btnLoad.setOnClickListener {
            installed.getOrNull(b.spInstalled.selectedItemPosition)?.let { vm.loadModel(it.name) }
        }
        b.btnDeleteModel.setOnClickListener {
            val m = installed.getOrNull(b.spInstalled.selectedItemPosition) ?: return@setOnClickListener
            MaterialAlertDialogBuilder(this)
                .setTitle("Supprimer le modèle ?")
                .setMessage(m.name)
                .setPositiveButton("Supprimer") { _, _ -> vm.deleteModel(m.name) }
                .setNegativeButton("Annuler", null)
                .show()
        }

        b.spSource.onItemSelectedListener = onSelected { pos ->
            val tag = langTags[pos]
            if (tag != vm.settings.value.sourceLang) vm.setSourceLang(tag)
        }
        b.spTarget.onItemSelectedListener = onSelected { pos ->
            val tag = langTags[pos]
            if (tag != vm.settings.value.targetLang) vm.setTargetLang(tag)
        }
        b.btnDownloadPair.setOnClickListener {
            val s = vm.settings.value
            vm.downloadLanguages(listOf(s.sourceLang, s.targetLang, "en"))
        }
        b.btnDownloadPack.setOnClickListener {
            langTags.getOrNull(b.spPack.selectedItemPosition)?.let { vm.downloadLanguages(listOf(it)) }
        }
        b.btnDeletePack.setOnClickListener {
            langTags.getOrNull(b.spPack.selectedItemPosition)?.let { vm.deleteLanguage(it) }
        }

        b.seekTextSize.setOnSeekBarChangeListener(onSeek { p -> vm.setTextSize(p + 12) })
        b.seekOpacity.setOnSeekBarChangeListener(onSeek { p -> vm.setOpacity(p) })
        b.swOriginal.setOnCheckedChangeListener { _, v -> vm.setShowOriginal(v) }
        b.swNotif.setOnCheckedChangeListener { _, v -> vm.setTranslateNotifications(v) }

        b.btnOverlay.setOnClickListener {
            when {
                SubtitleOverlayService.running.value -> SubtitleOverlayService.stop(this)
                !Settings.canDrawOverlays(this) -> requestOverlayPermission()
                else -> SubtitleOverlayService.start(this)
            }
        }

        b.btnPermAudio.setOnClickListener { requestRuntimePermissions() }
        b.btnPermOverlay.setOnClickListener { requestOverlayPermission() }
        b.btnPermNotif.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        b.spColorMode.onItemSelectedListener = onSelected { pos ->
            val key = ColorMode.entries[pos].key
            if (key != vm.settings.value.colorMode) vm.setColorMode(key)
        }
        b.swAutoClear.setOnCheckedChangeListener { _, v -> vm.setAutoClear(v) }
        b.swShortcut.setOnCheckedChangeListener { _, v ->
            if (v && !Settings.canDrawOverlays(this)) requestOverlayPermission()
            vm.setShortcutEnabled(v)
        }
        b.btnHistory.setOnClickListener { startActivity(Intent(this, HistoryActivity::class.java)) }
        b.btnPermAccess.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }

        b.btnStartStop.setOnClickListener { onStartStop() }
    }

    private fun onSelected(block: (Int) -> Unit) = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(p: AdapterView<*>?, v: View?, position: Int, id: Long) = block(position)
        override fun onNothingSelected(p: AdapterView<*>?) {}
    }

    private fun onSeek(block: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) { if (fromUser) block(progress) }
        override fun onStartTrackingTouch(s: SeekBar?) {}
        override fun onStopTrackingTouch(s: SeekBar?) {}
    }

    // ------------------------------------------------------------ observation des états

    private fun observe() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { vm.modelState.collect { renderModelState(it) } }
                launch {
                    vm.installedModels.collect {
                        installed = it
                        renderInstalledSpinner()
                    }
                }
                launch { vm.settings.collect { renderSettings(it) } }
                launch {
                    vm.downloadedLangs.collect {
                        downloaded = it
                        renderPacks()
                    }
                }
                launch {
                    vm.langBusy.collect { lang ->
                        b.progressPack.visibility = if (lang != null) View.VISIBLE else View.GONE
                        b.btnDownloadPair.isEnabled = lang == null
                        b.btnDownloadPack.isEnabled = lang == null
                    }
                }
                launch { vm.messages.collect { toast(it) } }
                launch { AudioCaptureService.running.collect { renderRunning() } }
                launch { SubtitleOverlayService.running.collect { renderRunning() } }
            }
        }
    }

    private fun renderModelState(state: ModelState) {
        val busy = state is ModelState.Extracting || state is ModelState.Loading
        modelBusy = busy
        when (state) {
            is ModelState.Idle -> b.tvModelStatus.text = "Aucun modèle chargé"
            is ModelState.Extracting -> {
                b.tvModelStatus.text = if (state.percent >= 0)
                    "Extraction de ${state.message}… ${state.percent} %" else "Extraction de ${state.message}…"
                if (state.percent >= 0) {
                    b.progressModel.isIndeterminate = false
                    b.progressModel.setProgressCompat(state.percent, true)
                } else {
                    b.progressModel.isIndeterminate = true
                }
            }
            is ModelState.Loading -> {
                b.tvModelStatus.text = "Chargement de ${state.name} en mémoire…"
                b.progressModel.isIndeterminate = true
            }
            is ModelState.Ready -> b.tvModelStatus.text =
                "✔ ${state.info.name}\nLangue : ${state.info.languageName} • Taille : " +
                    Formatter.formatFileSize(this, state.info.sizeBytes)
            is ModelState.Error -> b.tvModelStatus.text = "✘ ${state.message}"
        }
        b.progressModel.visibility = if (busy) View.VISIBLE else View.GONE
        renderRunning()
        renderInstalledSpinner()
    }

    private fun renderInstalledSpinner() {
        val previous = installed.getOrNull(b.spInstalled.selectedItemPosition)?.name
        val ready = (vm.modelState.value as? ModelState.Ready)?.info?.name
        val labels = installed.map { "${it.name} (${Formatter.formatFileSize(this, it.sizeBytes)})" }
        b.spInstalled.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        val idx = installed.indexOfFirst { it.name == (ready ?: previous) }
        if (idx >= 0) b.spInstalled.setSelection(idx)
    }

    private fun renderSettings(s: AppSettings) {
        langTags.indexOf(s.sourceLang).takeIf { it >= 0 && it != b.spSource.selectedItemPosition }
            ?.let { b.spSource.setSelection(it) }
        langTags.indexOf(s.targetLang).takeIf { it >= 0 && it != b.spTarget.selectedItemPosition }
            ?.let { b.spTarget.setSelection(it) }

        b.tvTextSize.text = "Taille du texte : ${s.textSizeSp} sp"
        b.tvOpacity.text = "Opacité du fond : ${s.bgOpacity} %"
        if (b.seekTextSize.progress != s.textSizeSp - 12) b.seekTextSize.progress = s.textSizeSp - 12
        if (b.seekOpacity.progress != s.bgOpacity) b.seekOpacity.progress = s.bgOpacity
        if (b.swOriginal.isChecked != s.showOriginal) b.swOriginal.isChecked = s.showOriginal
        if (b.swNotif.isChecked != s.translateNotifications) b.swNotif.isChecked = s.translateNotifications

        ColorMode.entries.indexOfFirst { it.key == s.colorMode }
            .takeIf { it >= 0 && it != b.spColorMode.selectedItemPosition }?.let { b.spColorMode.setSelection(it) }
        val autoClear = s.autoClearSeconds > 0
        if (b.swAutoClear.isChecked != autoClear) b.swAutoClear.isChecked = autoClear
        if (b.swShortcut.isChecked != s.shortcutEnabled) b.swShortcut.isChecked = s.shortcutEnabled

        // La bulle de raccourci suit le réglage (et la permission de superposition)
        val shortcutOn = s.shortcutEnabled && Settings.canDrawOverlays(this)
        if (shortcutOn && !FloatingShortcutService.running.value) FloatingShortcutService.start(this)
        if (!s.shortcutEnabled && FloatingShortcutService.running.value) FloatingShortcutService.stop(this)
    }

    private fun renderPacks() {
        val tm = voskApp.translationManager
        val sel = b.spPack.selectedItemPosition.coerceAtLeast(0)
        val items = langTags.map { (if (it in downloaded) "✔ " else "") + tm.displayName(it) }
        b.spPack.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        if (sel < items.size) b.spPack.setSelection(sel)
        b.tvPacks.text = if (downloaded.isEmpty()) "Aucun pack installé"
        else "Packs installés : " + downloaded.map { tm.displayName(it) }.sorted().joinToString(", ")
    }

    private fun renderRunning() {
        val capturing = AudioCaptureService.running.value
        b.btnStartStop.text = if (capturing) "Arrêter le sous-titrage" else "Démarrer le sous-titrage"
        b.btnOverlay.text =
            if (SubtitleOverlayService.running.value) "Masquer la fenêtre flottante" else "Afficher la fenêtre flottante"
        val canChange = !capturing && !modelBusy
        b.btnLoad.isEnabled = canChange
        b.btnDeleteModel.isEnabled = canChange
        b.btnImport.isEnabled = canChange
    }

    // ------------------------------------------------------------ autorisations

    private fun hasAudioPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun hasNotificationAccess() =
        NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)

    private fun refreshPermissions() {
        renderSettings(vm.settings.value)   // démarre la bulle si la permission vient d'être accordée
        fun mark(ok: Boolean) = if (ok) "✔" else "✘"
        b.tvPerms.text = "Micro : ${mark(hasAudioPermission())}    " +
            "Superposition : ${mark(Settings.canDrawOverlays(this))}    " +
            "Accès notifications : ${mark(hasNotificationAccess())}"
    }

    private fun requestRuntimePermissions() {
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        requestRuntime.launch(perms.toTypedArray())
    }

    private fun requestOverlayPermission() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    // ------------------------------------------------------------ démarrage / arrêt

    private fun onStartStop() {
        if (AudioCaptureService.running.value) {
            stopService(Intent(this, AudioCaptureService::class.java))
            return
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            toast("La capture audio interne nécessite Android 10 ou plus"); return
        }
        if (vm.modelState.value !is ModelState.Ready) {
            toast("Chargez d'abord un modèle Vosk"); return
        }
        if (!hasAudioPermission()) { requestRuntimePermissions(); return }
        if (!Settings.canDrawOverlays(this)) { requestOverlayPermission(); return }

        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
