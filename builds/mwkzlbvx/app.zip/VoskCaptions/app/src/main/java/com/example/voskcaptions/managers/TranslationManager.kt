package com.example.voskcaptions.managers

import android.content.Context
import com.example.voskcaptions.data.SettingsRepository
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.languageid.LanguageIdentificationOptions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.TranslateRemoteModel
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

class LanguageModelMissingException(val lang: String) : Exception("Pack de langue manquant : $lang")

data class AutoTranslation(val sourceLang: String, val translated: String?)

class TranslationManager(
    @Suppress("unused") private val context: Context,
    private val settings: SettingsRepository
) {
    private val remoteModels = RemoteModelManager.getInstance()
    private val translators = ConcurrentHashMap<String, Translator>()
    private val readyKeys = ConcurrentHashMap.newKeySet<String>()
    private val identifier by lazy {
        LanguageIdentification.getClient(LanguageIdentificationOptions.Builder().setConfidenceThreshold(0.5f).build())
    }

    private val _downloaded = MutableStateFlow<Set<String>>(emptySet())
    val downloaded: StateFlow<Set<String>> = _downloaded.asStateFlow()

    // ---------------------------------------------------------------- packs de langues

    fun allLanguages(): List<String> =
        TranslateLanguage.getAllLanguages().sortedBy { displayName(it).lowercase() }

    fun displayName(tag: String): String =
        Locale.forLanguageTag(tag).getDisplayLanguage(Locale.getDefault())
            .ifBlank { tag }.replaceFirstChar { it.uppercase() }

    suspend fun refreshDownloaded() {
        _downloaded.value = remoteModels.getDownloadedModels(TranslateRemoteModel::class.java)
            .await().map { it.language }.toSet()
    }

    /** Télécharge un pack (nécessite le réseau, une seule fois). */
    suspend fun downloadLanguage(lang: String) {
        val model = TranslateRemoteModel.Builder(lang).build()
        remoteModels.download(model, DownloadConditions.Builder().build()).await()
        refreshDownloaded()
    }

    suspend fun deleteLanguage(lang: String) {
        closeAll()
        remoteModels.deleteDownloadedModel(TranslateRemoteModel.Builder(lang).build()).await()
        refreshDownloaded()
    }

    // ---------------------------------------------------------------- traduction

    /** Traduit hors ligne. Lève [LanguageModelMissingException] si un pack n'est pas installé. */
    suspend fun translate(text: String, src: String, tgt: String): String {
        if (text.isBlank() || src == tgt) return text
        val missing = listOf(src, tgt).firstOrNull { it !in _downloaded.value }
        if (missing != null) throw LanguageModelMissingException(missing)

        val key = "$src>$tgt"
        val translator = translators.getOrPut(key) {
            Translation.getClient(
                TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(tgt).build()
            )
        }
        if (readyKeys.add(key)) {
            try {
                translator.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
            } catch (t: Throwable) {
                readyKeys.remove(key); throw t
            }
        }
        return translator.translate(text).await()
    }

    /** Détecte la langue (modèle embarqué, hors ligne) puis traduit vers [target]. */
    suspend fun translateAuto(text: String, target: String): AutoTranslation {
        val detected = detectLanguage(text) ?: settings.state.value.sourceLang
        if (detected == target) return AutoTranslation(detected, null)
        return AutoTranslation(detected, translate(text, detected, target))
    }

    suspend fun detectLanguage(text: String): String? {
        val tag = identifier.identifyLanguage(text).await()
        if (tag == "und") return null
        return TranslateLanguage.fromLanguageTag(tag)
    }

    /** Libère les traducteurs en cache (changement de paire de langues, suppression d'un pack). */
    fun closeAll() {
        translators.values.forEach { runCatching { it.close() } }
        translators.clear()
        readyKeys.clear()
    }
}
