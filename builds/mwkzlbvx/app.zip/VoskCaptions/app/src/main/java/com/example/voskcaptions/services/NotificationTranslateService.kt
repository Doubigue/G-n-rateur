package com.example.voskcaptions.services

import android.app.Notification
import android.content.pm.PackageManager
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationCompat
import com.example.voskcaptions.VoskApp
import com.example.voskcaptions.data.SubtitleBus
import com.example.voskcaptions.data.SubtitleSource
import com.example.voskcaptions.data.SubtitleState
import com.example.voskcaptions.managers.LanguageModelMissingException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** Intercepte les notifications de messagerie, les traduit (ML Kit hors ligne) et les affiche dans l'overlay. */
class NotificationTranslateService : NotificationListenerService() {

    companion object {
        val SUPPORTED_PACKAGES = setOf(
            "com.whatsapp", "com.whatsapp.w4b",
            "org.telegram.messenger", "org.telegram.messenger.web", "org.thoughtcrime.securesms",
            "com.google.android.apps.messaging", "com.android.mms", "com.samsung.android.messaging",
            "com.facebook.orca", "com.instagram.android", "com.discord",
            "com.Slack", "com.microsoft.teams", "com.viber.voip", "jp.naver.line.android"
        )
    }

    private val app: VoskApp get() = applicationContext as VoskApp
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val recent = object : LinkedHashMap<String, Long>(32, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Long>?): Boolean = size > 50
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val settings = app.settings.state.value
        if (!settings.translateNotifications) return
        if (sbn.packageName !in SUPPORTED_PACKAGES) return

        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        val (sender, text) = extractMessage(n) ?: return

        val key = "${sbn.packageName}|$sender|$text"
        synchronized(recent) {
            val now = System.currentTimeMillis()
            if (now - (recent[key] ?: 0L) < 5_000) return
            recent[key] = now
        }

        if (Settings.canDrawOverlays(this) && !SubtitleOverlayService.running.value) {
            runCatching { SubtitleOverlayService.start(this) }   // peut être refusé en arrière-plan
        }

        val label = "${appLabel(sbn.packageName)} · $sender"
        scope.launch {
            val segId = SubtitleBus.nextId()
            SubtitleBus.publish(SubtitleState(SubtitleSource.MESSAGE, label, text, id = segId))
            val historyId = app.history.insert("message", label, text, "", settings.sourceLang, settings.targetLang)
            val translated = try {
                app.translationManager.translateAuto(text, settings.targetLang).translated.orEmpty()
            } catch (e: LanguageModelMissingException) {
                "⚠ Pack de langue manquant : ${app.translationManager.displayName(e.lang)}"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                ""
            }
            SubtitleBus.publish(SubtitleState(SubtitleSource.MESSAGE, label, text, translated, id = segId))
            if (translated.isNotBlank() && !translated.startsWith("⚠")) app.history.updateTranslation(historyId, translated)
        }
    }

    private fun extractMessage(n: Notification): Pair<String, String>? {
        val title = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val style = NotificationCompat.MessagingStyle.extractMessagingStyleFromNotification(n)
        val last = style?.messages?.lastOrNull()
        if (last != null && !last.text.isNullOrBlank()) {
            return (last.person?.name?.toString() ?: title) to last.text.toString()
        }
        val text = (n.extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: n.extras.getCharSequence(Notification.EXTRA_TEXT))?.toString()
        if (text.isNullOrBlank()) return null
        return title to text
    }

    private fun appLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: PackageManager.NameNotFoundException) {
        pkg
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
