package com.example.voskcaptions.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class HistoryItem(
    val id: Long,
    val timestamp: Long,
    val source: String,          // "speech" ou "message"
    val label: String,
    val original: String,
    val translated: String,
    val srcLang: String,
    val tgtLang: String
)

/** Historique persistant (SQLite) de toutes les transcriptions et messages traduits. */
class HistoryRepository(context: Context) : SQLiteOpenHelper(context, "history.db", null, 1) {

    private val _changes = MutableStateFlow(0)
    val changes: StateFlow<Int> = _changes.asStateFlow()

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE history(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts INTEGER NOT NULL,
                source TEXT NOT NULL,
                label TEXT NOT NULL DEFAULT '',
                original TEXT NOT NULL,
                translated TEXT NOT NULL DEFAULT '',
                src_lang TEXT NOT NULL DEFAULT '',
                tgt_lang TEXT NOT NULL DEFAULT ''
            )"""
        )
        db.execSQL("CREATE INDEX idx_history_ts ON history(ts)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun insert(source: String, label: String, original: String, translated: String, srcLang: String, tgtLang: String): Long {
        val cv = ContentValues().apply {
            put("ts", System.currentTimeMillis())
            put("source", source)
            put("label", label)
            put("original", original)
            put("translated", translated)
            put("src_lang", srcLang)
            put("tgt_lang", tgtLang)
        }
        val id = writableDatabase.insert("history", null, cv)
        _changes.value++
        return id
    }

    fun updateTranslation(id: Long, translated: String) {
        if (id < 0) return
        val cv = ContentValues().apply { put("translated", translated) }
        writableDatabase.update("history", cv, "id = ?", arrayOf(id.toString()))
        _changes.value++
    }

    fun query(filter: String? = null): List<HistoryItem> {
        val q = filter?.trim().orEmpty()
        val (sel, args) =
            if (q.isEmpty()) null to null
            else "original LIKE ? OR translated LIKE ? OR label LIKE ?" to Array(3) { "%$q%" }
        val out = ArrayList<HistoryItem>()
        readableDatabase.query("history", null, sel, args, null, null, "ts DESC, id DESC").use { c ->
            while (c.moveToNext()) {
                out += HistoryItem(
                    id = c.getLong(c.getColumnIndexOrThrow("id")),
                    timestamp = c.getLong(c.getColumnIndexOrThrow("ts")),
                    source = c.getString(c.getColumnIndexOrThrow("source")),
                    label = c.getString(c.getColumnIndexOrThrow("label")),
                    original = c.getString(c.getColumnIndexOrThrow("original")),
                    translated = c.getString(c.getColumnIndexOrThrow("translated")),
                    srcLang = c.getString(c.getColumnIndexOrThrow("src_lang")),
                    tgtLang = c.getString(c.getColumnIndexOrThrow("tgt_lang"))
                )
            }
        }
        return out
    }

    fun delete(id: Long) {
        writableDatabase.delete("history", "id = ?", arrayOf(id.toString()))
        _changes.value++
    }

    fun clear() {
        writableDatabase.delete("history", null, null)
        _changes.value++
    }
}
