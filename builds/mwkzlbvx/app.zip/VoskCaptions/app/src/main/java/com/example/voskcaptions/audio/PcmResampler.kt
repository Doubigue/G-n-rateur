package com.example.voskcaptions.audio

import kotlin.math.roundToInt

/**
 * Convertit en flux continu du PCM 16 bits entrelacé (N canaux, [inRate] Hz)
 * vers du PCM 16 bits MONO à [outRate] Hz.
 *
 * - Mixage mono : moyenne des canaux.
 * - Rééchantillonnage par moyenne pondérée sur la fenêtre (filtre « boîte » :
 *   anti-repliement suffisant pour la parole), valable pour tout ratio (48000→16000, 44100→16000…).
 */
class PcmResampler(inRate: Int, outRate: Int, private val channels: Int) {
    private val step = inRate.toDouble() / outRate
    private var acc = 0.0
    private var remaining = step

    /** @return nombre d'échantillons mono écrits dans [output]. */
    fun process(input: ShortArray, length: Int, output: ShortArray): Int {
        var o = 0
        var i = 0
        while (i + channels <= length) {
            var sum = 0
            for (c in 0 until channels) sum += input[i + c].toInt()
            i += channels
            val v = sum.toDouble() / channels
            var w = 1.0
            while (w > 1e-9) {
                val take = if (w < remaining) w else remaining
                acc += v * take
                w -= take
                remaining -= take
                if (remaining <= 1e-9) {
                    if (o < output.size) {
                        output[o++] = (acc / step).roundToInt().coerceIn(-32768, 32767).toShort()
                    }
                    acc = 0.0
                    remaining = step
                }
            }
        }
        return o
    }
}
