package com.example.voskcaptions.services

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.StyleSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.voskcaptions.HistoryActivity
import com.example.voskcaptions.R
import com.example.voskcaptions.VoskApp
import com.example.voskcaptions.data.AppSettings
import com.example.voskcaptions.data.OverlayGeometry
import com.example.voskcaptions.data.SubtitleBus
import com.example.voskcaptions.data.Segment
import com.example.voskcaptions.data.SubtitleState
import com.example.voskcaptions.data.Transcript
import com.example.voskcaptions.ui.AdaptiveColors
import com.example.voskcaptions.ui.ColorMode
import com.example.voskcaptions.ui.SceneColorBus
import com.example.voskcaptions.util.ClipboardUtil
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Fenêtre flottante déplaçable : texte original + traduction, boutons copier / historique / vider.
 * Le texte reste affiché tant que vous ne le videz pas (sauf si l'effacement auto est activé).
 */
class SubtitleOverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.example.voskcaptions.action.STOP_OVERLAY"
        private const val CHANNEL_ID = "subtitle_overlay"
        private const val NOTIFICATION_ID = 1002

        private val _running = MutableStateFlow(false)
        val running: StateFlow<Boolean> = _running.asStateFlow()

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, SubtitleOverlayService::class.java))
        }

        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, SubtitleOverlayService::class.java)) }
    }

    private val app: VoskApp get() = applicationContext as VoskApp
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private lateinit var wm: WindowManager
    private var rootView: View? = null
    private lateinit var params: WindowManager.LayoutParams
    private lateinit var bg: GradientDrawable
    private lateinit var tvLabel: TextView
    private lateinit var tvOriginal: TextView
    private lateinit var tvTranslated: TextView
    private lateinit var scrollOriginal: ScrollView
    private lateinit var scrollTranslated: ScrollView
    private lateinit var rowOriginal: LinearLayout
    private lateinit var rowTranslated: LinearLayout
    private lateinit var btnCopyOriginal: ImageButton
    private lateinit var btnCopyTranslated: ImageButton
    private lateinit var btnClear: ImageButton
    private lateinit var btnHistory: ImageButton

    private var settings = AppSettings()
    private var transcript = Transcript()
    private var shownOriginal: CharSequence = ""
    private var shownTranslated: CharSequence = ""
    private var sceneColor: Int? = null
    private var sceneLight = false
    private var clearJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForegroundCompat()
        if (intent?.action == ACTION_STOP || !Settings.canDrawOverlays(this)) {
            stopSelf(); return START_NOT_STICKY
        }
        if (rootView == null) setupOverlay()
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, n)
        }
    }

    @SuppressLint("InflateParams")
    private fun setupOverlay() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val view = LayoutInflater.from(this).inflate(R.layout.overlay_subtitles, null)
        tvLabel = view.findViewById(R.id.tvLabel)
        tvOriginal = view.findViewById(R.id.tvOriginal)
        tvTranslated = view.findViewById(R.id.tvTranslated)
        scrollOriginal = view.findViewById(R.id.scrollOriginal)
        scrollTranslated = view.findViewById(R.id.scrollTranslated)
        rowOriginal = view.findViewById(R.id.rowOriginal)
        rowTranslated = view.findViewById(R.id.rowTranslated)
        btnCopyOriginal = view.findViewById(R.id.btnCopyOriginal)
        btnCopyTranslated = view.findViewById(R.id.btnCopyTranslated)
        btnClear = view.findViewById(R.id.btnClear)
        btnHistory = view.findViewById(R.id.btnHistory)

        val dm = resources.displayMetrics
        bg = GradientDrawable().apply { cornerRadius = 16f * dm.density }
        view.background = bg

        settings = app.settings.state.value
        val width = (dm.widthPixels * 0.9f).toInt()
        params = WindowManager.LayoutParams(
            width,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = if (settings.overlayX >= 0) settings.overlayX else (dm.widthPixels - width) / 2
            y = if (settings.overlayY >= 0) settings.overlayY else (dm.heightPixels * 0.65f).toInt()
        }

        btnCopyOriginal.setOnClickListener { ClipboardUtil.copy(this, shownOriginal.toString()) }
        btnCopyTranslated.setOnClickListener { ClipboardUtil.copy(this, shownTranslated.toString()) }
        btnClear.setOnClickListener { SubtitleBus.clear() }
        btnHistory.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }

        installDragHandler(view)
        view.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> publishSampleBand() }
        applySettings()
        wm.addView(view, params)
        rootView = view
        _running.value = true

        scope.launch { app.settings.state.collect { settings = it; applySettings(); render(transcript) } }
        scope.launch { SubtitleBus.transcript.collect { transcript = it; render(it) } }
        scope.launch {
            SceneColorBus.avgColor.collect { color ->
                sceneColor = color
                if (color != null) sceneLight = AdaptiveColors.isLightScene(color, sceneLight)
                applySettings()
            }
        }

        // Message d'accueil en « partiel » : il est remplacé dès la première phrase reconnue
        if (SubtitleBus.transcript.value.isEmpty) {
            SubtitleBus.publish(
                SubtitleState(
                    original = "Sous-titres prêts — déplacez cette fenêtre avec le doigt",
                    partial = true, id = SubtitleBus.nextId()
                )
            )
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun installDragHandler(view: View) {
        view.setOnTouchListener(object : View.OnTouchListener {
            private var startX = 0
            private var startY = 0
            private var touchX = 0f
            private var touchY = 0f

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                val dm = resources.displayMetrics
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        startX = params.x; startY = params.y
                        touchX = e.rawX; touchY = e.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = (startX + (e.rawX - touchX).toInt())
                            .coerceIn(0, (dm.widthPixels - v.width).coerceAtLeast(0))
                        params.y = (startY + (e.rawY - touchY).toInt())
                            .coerceIn(0, (dm.heightPixels - v.height).coerceAtLeast(0))
                        wm.updateViewLayout(v, params)
                        publishSampleBand()
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        app.settings.update { it.copy(overlayX = params.x, overlayY = params.y) }
                        v.performClick()
                        return true
                    }
                }
                return false
            }
        })
    }

    /** Zone voisine (au-dessus, sinon en dessous) mesurée pour adapter les couleurs à la vidéo. */
    private fun publishSampleBand() {
        val v = rootView ?: return
        val h = v.height
        val w = v.width
        if (h == 0 || w == 0) return
        val top = if (params.y - h >= 0) params.y - h else params.y + h
        OverlayGeometry.sampleBand.value = Rect(params.x, top, params.x + w, top + h)
    }

    /** Tailles + couleurs (mode manuel ou automatique). */
    private fun applySettings() {
        if (rootView == null) return
        tvOriginal.setTextSize(TypedValue.COMPLEX_UNIT_SP, settings.textSizeSp * 0.8f)
        tvTranslated.setTextSize(TypedValue.COMPLEX_UNIT_SP, settings.textSizeSp.toFloat())

        val scheme = AdaptiveColors.resolve(
            ColorMode.fromKey(settings.colorMode), sceneColor, sceneLight, settings.bgOpacity
        )
        bg.setColor(scheme.background)
        tvOriginal.setTextColor(scheme.original)
        tvTranslated.setTextColor(scheme.translated)
        tvLabel.setTextColor(scheme.label)
        val tint = ColorStateList.valueOf(scheme.icon)
        listOf(btnCopyOriginal, btnCopyTranslated, btnClear, btnHistory).forEach { it.imageTintList = tint }
    }

    /** Affiche la transcription cumulée (phrases terminées + phrase en cours en italique). */
    private fun render(t: Transcript) {
        val view = rootView ?: return
        val parts: List<Segment> = t.segments + listOfNotNull(t.partial)

        fun build(pick: (Segment) -> String): CharSequence {
            val sb = SpannableStringBuilder()
            for (seg in parts) {
                val text = pick(seg)
                if (text.isBlank()) continue
                if (sb.isNotEmpty()) sb.append('\n')
                val start = sb.length
                sb.append(text)
                if (seg === t.partial) sb.setSpan(StyleSpan(Typeface.ITALIC), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            return sb
        }

        val original = build { it.original }
        val translated = build { it.translated }
        val hasOriginal = original.isNotEmpty()
        val hasTranslated = translated.isNotEmpty()
        val showOriginal = hasOriginal && (settings.showOriginal || !hasTranslated)

        shownOriginal = original
        shownTranslated = translated
        tvLabel.text = parts.lastOrNull()?.label.orEmpty()
        tvOriginal.text = original
        tvTranslated.text = translated
        rowOriginal.visibility = if (showOriginal) View.VISIBLE else View.GONE
        rowTranslated.visibility = if (hasTranslated) View.VISIBLE else View.GONE
        view.visibility = if (hasOriginal || hasTranslated) View.VISIBLE else View.GONE
        scrollToEnd(scrollOriginal)
        scrollToEnd(scrollTranslated)

        // Le texte reste jusqu'à « vider », sauf effacement automatique explicitement activé.
        clearJob?.cancel()
        val seconds = settings.autoClearSeconds
        if (seconds > 0 && (hasOriginal || hasTranslated)) {
            clearJob = scope.launch {
                delay(seconds * 1000L)
                SubtitleBus.clear()
            }
        }
    }

    private fun scrollToEnd(sv: ScrollView) {
        sv.post {
            val child = sv.getChildAt(0) ?: return@post
            sv.scrollTo(0, (child.height - sv.height).coerceAtLeast(0))
        }
    }

    private fun buildNotification(): Notification {
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Fenêtre de sous-titres", NotificationManager.IMPORTANCE_LOW)
        )
        val stopPi = PendingIntent.getService(
            this, 2,
            Intent(this, SubtitleOverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Fenêtre de sous-titres active")
            .setOngoing(true)
            .addAction(0, "Fermer", stopPi)
            .build()
    }

    override fun onDestroy() {
        scope.cancel()
        rootView?.let { runCatching { wm.removeView(it) } }
        rootView = null
        OverlayGeometry.sampleBand.value = null
        _running.value = false
        super.onDestroy()
    }
}
