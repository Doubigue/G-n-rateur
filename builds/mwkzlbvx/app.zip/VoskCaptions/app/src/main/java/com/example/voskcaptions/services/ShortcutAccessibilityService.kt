package com.example.voskcaptions.services

import android.accessibilityservice.AccessibilityButtonController
import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import com.example.voskcaptions.CaptureShortcuts

/**
 * Fournit le bouton d'accessibilité (barre de navigation / raccourci système) pour démarrer ou
 * arrêter le sous-titrage. Aucun contenu d'écran n'est lu (canRetrieveWindowContent = false).
 */
class ShortcutAccessibilityService : AccessibilityService() {

    private var callback: AccessibilityButtonController.AccessibilityButtonCallback? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        val cb = object : AccessibilityButtonController.AccessibilityButtonCallback() {
            override fun onClicked(controller: AccessibilityButtonController) {
                CaptureShortcuts.toggle(applicationContext)
            }
        }
        callback = cb
        accessibilityButtonController.registerAccessibilityButtonCallback(cb)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        callback?.let { accessibilityButtonController.unregisterAccessibilityButtonCallback(it) }
        super.onDestroy()
    }
}
