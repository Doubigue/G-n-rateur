package com.example.voskcaptions.ui

import android.content.Context
import android.util.AttributeSet
import android.widget.ScrollView

/** ScrollView plafonnée en hauteur : la transcription cumulée défile au lieu d'agrandir la fenêtre flottante. */
class MaxHeightScrollView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : ScrollView(context, attrs) {

    private val maxHeightPx = (130 * context.resources.displayMetrics.density).toInt()

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, MeasureSpec.makeMeasureSpec(maxHeightPx, MeasureSpec.AT_MOST))
    }
}
