package com.example.voskcaptions.data

import android.graphics.Rect
import kotlinx.coroutines.flow.MutableStateFlow

/** Zone d'écran (juste à côté de la fenêtre flottante) dont on mesure la couleur pour adapter le texte. */
object OverlayGeometry {
    val sampleBand = MutableStateFlow<Rect?>(null)
}
