# Vosk Captions

Sous-titres en direct (Vosk, hors ligne) + traduction ML Kit, par-dessus n'importe quelle vidéo.

## Fonctions
- **Bulle flottante** (réglage « Icône de raccourci ») collée au bord de l'écran : appui = démarrer/arrêter, appui long = historique, glisser = déplacer. Bouton d'accessibilité système en complément.
- **Fenêtre de transcription** : le texte **s'accumule et reste** jusqu'à ce que vous appuyiez sur ✕ (vider). Il survit à la fermeture/réouverture de la fenêtre.
- **Bouton copier** à côté du texte original et de la traduction (copie toute la transcription affichée).
- **Couleurs adaptatives** (mode « Auto ») : la couleur de l'écran autour de la fenêtre est mesurée, texte et fond sont choisis pour un contraste ≥ 4,5. 6 autres thèmes manuels.
- **Historique** persistant (SQLite) : recherche, copier, supprimer, exporter. La dernière phrase en cours est enregistrée à l'arrêt.

## Clé de signature dédiée
- Clé fournie : `keystore/vosk-captions-release.jks` (alias `vosk-captions`, RSA 4096, valable jusqu'en 2054), mots de passe dans `keystore.properties`.
- Empreinte SHA-256 : `0D:A4:23:8F:E2:6B:3E:28:B7:9C:FA:4F:62:32:51:90:1C:E7:0E:17:BE:6D:A3:00:6A:81:48:B4:94:57:27:C2`
- Les builds **debug et release** sont signés avec cette clé.
- **Sauvegardez le .jks et keystore.properties hors du dépôt** : sans eux, plus de mise à jour possible de l'appli installée. Ne la régénérez pas (`scripts/generate-keystore.sh` refuse d'écraser).
- Le `.jks` et `keystore.properties` sont **inclus dans le projet** (non ignorés par git) : GitHub Actions signe donc directement, sans secret à configurer. **Gardez le dépôt PRIVÉ** : quiconque a ce fichier peut signer à votre place.
- Option : variables `VOSK_KEYSTORE_BASE64`, `VOSK_KEYSTORE_PASSWORD`, `VOSK_KEY_ALIAS`, `VOSK_KEY_PASSWORD` si vous préférez des secrets (utilisées seulement si le .jks est absent).
