#!/usr/bin/env bash
# Génère VOTRE clé de signature dédiée (à exécuter sur votre machine) et keystore.properties.
set -euo pipefail
cd "$(dirname "$0")/.."
KS=keystore/vosk-captions-release.jks
ALIAS=vosk-captions
if [ -f "$KS" ]; then echo "Le keystore existe déjà : $KS (supprimez-le explicitement pour en recréer un)"; exit 1; fi
PASS=$(openssl rand -base64 24 | tr -d '=+/' | cut -c1-24)
keytool -genkeypair -v -keystore "$KS" -storetype PKCS12 -alias "$ALIAS" \
  -keyalg RSA -keysize 4096 -validity 10000 \
  -storepass "$PASS" -keypass "$PASS" \
  -dname "CN=Vosk Captions, O=Vosk Captions, C=FR"
cat > keystore.properties <<EOP
storeFile=$KS
storePassword=$PASS
keyAlias=$ALIAS
keyPassword=$PASS
EOP
echo "OK. SAUVEGARDEZ $KS et keystore.properties hors du dépôt : sans eux, plus aucune mise à jour possible."
keytool -list -v -keystore "$KS" -storepass "$PASS" | grep -E "SHA256|SHA1"
