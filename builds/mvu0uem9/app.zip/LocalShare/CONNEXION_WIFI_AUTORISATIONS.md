# Connexion Wi-Fi et autorisations LocalShare

## Parcours « Créer un accès »
- LocalShare demande les autorisations Android requises par la version du système : appareils Wi-Fi à proximité (Android 13+), localisation (Android 12 et antérieur), et notifications (Android 13+) pour le suivi des transferts.
- Si le Wi-Fi est désactivé, l'application ouvre le panneau système de connectivité et réessaie au retour.
- Le point d'accès local est créé via `WifiManager.startLocalOnlyHotspot`; le QR Wi-Fi s'affiche lorsque Android confirme que le point d'accès est actif.

## Parcours « Scanner »
- Si le Wi-Fi est désactivé, LocalShare ouvre le panneau Android. Au retour, le scanner QR s'ouvre automatiquement.
- Les liens HTTP/HTTPS scannés s'ouvrent dans le navigateur. Les QR Wi-Fi passent par les réglages Android, qui gardent la confirmation de connexion.

## Limites imposées par Android
Les autorisations d'une application ordinaire ne permettent pas de forcer le Wi-Fi à s'activer/se désactiver sans confirmation sur Android 10+, ni de garantir que le Wi-Fi se rallume automatiquement après la création d'un point d'accès. Android ou le fabricant décide si le Wi-Fi client et le point d'accès peuvent fonctionner simultanément. LocalShare ne tente pas de contourner ces restrictions. Sur certains téléphones, utilisez « Réglages du point d'accès Android » comme solution de repli.

## Arrière-plan
Accordez les notifications si Android le demande et autorisez LocalShare à fonctionner en arrière-plan dans les paramètres de batterie du téléphone. Le fabricant peut appliquer ses propres restrictions.
