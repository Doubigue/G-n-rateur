# Mise à jour LocalShare — interface simplifiée

- Accueil épuré avec deux actions principales : **Envoyer** et **Accéder**.
- Bouton de QR de connexion : ouvre le point d’accès local et affiche le QR Wi-Fi après les autorisations Android nécessaires.
- Scanner QR intégré : ouvre directement les adresses HTTP/HTTPS scannées et guide l’utilisateur pour les QR Wi-Fi.
- QR du serveur accessible dans Paramètres → QR du serveur web.
- Le serveur HTTP existant reste exécuté par un service de premier plan avec notification, et les partages depuis le menu Partager d’Android restent pris en charge.

## Limites Android importantes

Android ne permet pas à une application ordinaire d’allumer silencieusement tous les hotspots ni de rejoindre un Wi-Fi sans confirmation sur toutes les versions. Les autorisations système et confirmations restent possibles. L’accès distant est limité aux fichiers et contenus que LocalShare expose explicitement ; il ne donne pas le contrôle arbitraire des applications privées de l’autre téléphone.
