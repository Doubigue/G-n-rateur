package com.example.localshare

import android.content.Context
import android.os.Build
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

/** Verrouillage des dossiers dans LocalShare avec authentification système Android. */
object FolderLock {
    private const val PREFS = "localshare_folder_locks"
    private const val KEY = "paths"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private fun normalized(path: String) = java.io.File(path).canonicalPath
    fun isLocked(ctx: Context, path: String): Boolean = try { prefs(ctx).getStringSet(KEY, emptySet()).orEmpty().contains(normalized(path)) } catch (_: Exception) { false }
    fun toggle(ctx: Context, path: String, locked: Boolean) {
        val set = prefs(ctx).getStringSet(KEY, emptySet()).orEmpty().toMutableSet()
        val p = normalized(path)
        if (locked) set.add(p) else set.remove(p)
        prefs(ctx).edit().putStringSet(KEY, set).apply()
    }

    fun authenticate(activity: AppCompatActivity, title: String, onResult: (Boolean) -> Unit) {
        val authenticators = if (Build.VERSION.SDK_INT >= 30) {
            BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        } else BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        val manager = BiometricManager.from(activity)
        if (manager.canAuthenticate(authenticators) != BiometricManager.BIOMETRIC_SUCCESS) {
            android.widget.Toast.makeText(activity, "Configurez d’abord le verrouillage de l’écran (PIN, schéma ou mot de passe) dans les paramètres Android.", android.widget.Toast.LENGTH_LONG).show()
            onResult(false); return
        }
        val prompt = BiometricPrompt(activity, ContextCompat.getMainExecutor(activity), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { onResult(true) }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { onResult(false) }
            override fun onAuthenticationFailed() { /* Android permet de réessayer */ }
        })
        val builder = BiometricPrompt.PromptInfo.Builder().setTitle(title).setSubtitle("Confirmez avec le verrouillage de votre téléphone")
        if (Build.VERSION.SDK_INT >= 30) builder.setAllowedAuthenticators(authenticators)
        else builder.setDeviceCredentialAllowed(true)
        prompt.authenticate(builder.build())
    }
}
