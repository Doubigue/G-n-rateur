package com.example.localshare

import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import androidx.core.content.IntentCompat
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

enum class TStatus { IN_PROGRESS, DONE, FAILED }

class TransferItem(val payloadId: Int, val name: String, val outgoing: Boolean, @Volatile var total: Long) {
    val created = System.currentTimeMillis()
    @Volatile var transferred = 0L
    @Volatile var status = TStatus.IN_PROGRESS
    @Volatile var savedPath: String? = null

    val progress: Float get() = if (total <= 0) 0f else (transferred.toFloat() / total).coerceIn(0f, 1f)

    val speed: Double
        get() {
            val ms = System.currentTimeMillis() - created
            return if (ms < 700 || transferred <= 0) 0.0 else transferred * 1000.0 / ms
        }

    val etaSeconds: Long?
        get() {
            val s = speed
            return if (s <= 0 || total <= transferred) null else Math.ceil((total - transferred) / s).toLong()
        }
}

class TextItem(val text: String, val outgoing: Boolean) {
    val created = System.currentTimeMillis()
}

/** Élément reçu du menu « Partager » d'Android, envoyé dès qu'un appareil est connecté. */
class Shared(val file: File?, val name: String?, val text: String?)

/**
 * Envoi / réception de fichiers sur le lien Wi-Fi Direct.
 * Les fichiers reçus sont écrits directement dans <stockage>/DoubigueShare (fichier .part renommé à la fin).
 * Les envois sont séquentiels (un fichier à la fois) pour garder le débit maximal.
 */
class TransferManager(private val ctx: Context, private val p2p: P2pEngine) {

    /** Incrémenté à chaque changement : les écrans se redessinent (≈5 fois/s au maximum). */
    val tick = MutableStateFlow(0L)

    private val counter = AtomicLong()
    private var lastTouch = 0L
    private val nextId = AtomicInteger(1)
    private val main = Handler(Looper.getMainLooper())
    private val sendExec = Executors.newSingleThreadExecutor()
    private val io = Executors.newCachedThreadPool()

    private val items = CopyOnWriteArrayList<TransferItem>()
    private val texts = CopyOnWriteArrayList<TextItem>()
    private val queued = CopyOnWriteArrayList<Shared>()
    private val outMap = ConcurrentHashMap<Int, TransferItem>()
    private val cancelled = ConcurrentHashMap.newKeySet<Int>()
    private val batchOut = mutableListOf<TransferItem>()
    private val batchIn = mutableListOf<TransferItem>()
    private var notifPending = false

    private class Rx(val item: TransferItem) {
        var tmp: File? = null
        var dest: File? = null
        var out: BufferedOutputStream? = null
        var received = 0L
        @Volatile var failed = false
    }

    private val inMap = ConcurrentHashMap<Int, Rx>()

    init {
        p2p.jsonListeners.add { onMessage(it) }
        p2p.chunkHandler = { id, data -> onChunk(id, data) }
        p2p.endHandler = { id -> onEnd(id) }
        p2p.cancelHandler = { id -> onCancelFrame(id) }
        p2p.sessionEnded.add { failAll() }
    }

    private fun touch(force: Boolean) {
        val now = System.currentTimeMillis()
        if (force || now - lastTouch >= 200) {
            lastTouch = now
            tick.value = counter.incrementAndGet()
        }
    }

    /** Transferts et messages, du plus récent au plus ancien. */
    fun feed(): List<Any> {
        val all = ArrayList<Any>(items.size + texts.size)
        all.addAll(items)
        all.addAll(texts)
        return all.sortedByDescending { if (it is TransferItem) it.created else (it as TextItem).created }
    }

    // ============================================== menu « Partager » d'Android
    val queuedCount: Int get() = queued.size
    val queuedList: List<Shared> get() = queued.toList()

    /** Lit un intent SEND / SEND_MULTIPLE ; les fichiers sont copiés dans le cache (l'autorisation d'accès est temporaire). */
    fun queueFromIntent(intent: Intent) {
        val action = intent.action
        if (action != Intent.ACTION_SEND && action != Intent.ACTION_SEND_MULTIPLE) return
        val uris = ArrayList<Uri>()
        if (action == Intent.ACTION_SEND) {
            IntentCompat.getParcelableExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)?.let { uris += it }
        } else {
            IntentCompat.getParcelableArrayListExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)?.let { uris += it }
        }
        val text = intent.getStringExtra(Intent.EXTRA_TEXT)
        if (uris.isEmpty() && !text.isNullOrBlank()) {
            queued += Shared(null, null, text)
            touch(true)
            return
        }
        io.execute {
            for (u in uris) {
                try {
                    copyToCache(u)?.let { (f, n) -> queued += Shared(f, n, null) }
                } catch (_: Exception) {
                }
                touch(true)
            }
            if (p2p.isConnected) flushQueue()
        }
    }

    private fun copyToCache(uri: Uri): Pair<File, String>? {
        var name = "fichier"
        if (uri.scheme == "file") {
            name = File(uri.path ?: "fichier").name
        } else {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0)?.let { n -> name = n }
            }
        }
        val dir = File(ctx.cacheDir, "share").apply { mkdirs() }
        val out = File(dir, "${System.nanoTime()}_${Storage.safeName(name)}")
        ctx.contentResolver.openInputStream(uri)?.use { i ->
            FileOutputStream(out).use { o -> i.copyTo(o, 256 * 1024) }
        } ?: return null
        return out to name
    }

    fun clearQueue() {
        queued.forEach { it.file?.delete() }
        queued.clear()
        touch(true)
    }

    @Synchronized
    fun flushQueue() {
        if (!p2p.isConnected || queued.isEmpty()) return
        val q = queued.toList()
        queued.clear()
        touch(true)
        for (s in q) {
            if (s.text != null) sendText(s.text) else if (s.file != null) sendFile(s.file, s.name, deleteAfter = true)
        }
    }

    private fun failAll() {
        for (rx in inMap.values.toList()) abortRx(rx)
        for (it in outMap.values) if (it.status == TStatus.IN_PROGRESS) it.status = TStatus.FAILED
        touch(true)
        pushNotifications()
    }

    // ================================================================ texte
    fun sendText(raw: String) {
        var text = raw.trim()
        if (text.isEmpty()) return
        if (text.length > 6000) text = text.substring(0, 6000)
        p2p.send(JSONObject().put("t", "text").put("m", text))
        texts += TextItem(text, true)
        touch(true)
    }

    // ================================================================ envoi
    fun sendFile(file: File, displayName: String? = null, deleteAfter: Boolean = false) {
        if (!file.exists() || !p2p.isConnected) return
        val name = if (!displayName.isNullOrBlank()) displayName else file.name
        enqueue(name, file.length(), { FileInputStream(file) }, if (deleteAfter) ({ file.delete() }) else null)
    }

    /** Fichier choisi dans le sélecteur Android (URI de contenu). */
    fun sendUri(uri: Uri, name: String?, size: Long) {
        if (!p2p.isConnected) return
        enqueue(name ?: "fichier", size, {
            ctx.contentResolver.openInputStream(uri) ?: throw IOException("Fichier illisible")
        }, null)
    }

    private fun enqueue(name: String, size: Long, opener: () -> InputStream, after: (() -> Unit)?) {
        val id = nextId.getAndIncrement()
        val item = TransferItem(id, name, true, size)
        items += item
        outMap[id] = item
        synchronized(batchOut) { batchOut += item }
        touch(true)
        pushNotifications()
        sendExec.execute { pump(item, opener, after) }
    }

    private fun pump(item: TransferItem, opener: () -> InputStream, after: (() -> Unit)?) {
        val id = item.payloadId
        var ins: InputStream? = null
        try {
            if (cancelled.contains(id)) throw IOException("annulé")
            p2p.sendJsonSync(JSONObject().put("t", "file").put("id", id).put("name", item.name).put("size", maxOf(0L, item.total)))
            ins = opener()
            val buf = ByteArray(64 * 1024)
            var sent = 0L
            while (true) {
                if (cancelled.contains(id) || !p2p.isConnected) throw IOException("annulé")
                val n = ins.read(buf)
                if (n < 0) break
                p2p.sendChunkSync(id, buf, n)
                sent += n
                item.transferred = sent
                touch(false)
                scheduleNotifications()
            }
            p2p.sendEndSync(id)
            item.total = sent
            item.transferred = sent
            if (item.status == TStatus.IN_PROGRESS) item.status = TStatus.DONE
        } catch (e: Exception) {
            if (item.status == TStatus.IN_PROGRESS) item.status = TStatus.FAILED
            if (p2p.isConnected) p2p.sendCancel(id)
        } finally {
            try { ins?.close() } catch (_: IOException) { }
            cancelled.remove(id)
            outMap.remove(id)
            try { after?.invoke() } catch (_: Exception) { }
            touch(true)
            pushNotifications()
        }
    }

    fun cancel(item: TransferItem) {
        if (item.status != TStatus.IN_PROGRESS) return
        if (item.outgoing) {
            cancelled += item.payloadId
        } else {
            p2p.sendCancel(item.payloadId)
            inMap[item.payloadId]?.let { abortRx(it) }
        }
        item.status = TStatus.FAILED
        touch(true)
        pushNotifications()
    }

    // ============================================================ réception
    /** Thread du lien. */
    private fun onMessage(m: JSONObject) {
        when (m.optString("t")) {
            "text" -> {
                val t = m.optString("m")
                if (t.isNotBlank()) {
                    texts += TextItem(t, false)
                    Notifier.showDone(ctx, false, "Message reçu", if (t.length > 120) t.take(120) + "…" else t, null)
                    touch(true)
                }
            }
            "file" -> startRx(m)
        }
    }

    private fun startRx(m: JSONObject) {
        if (!m.has("id") || !m.has("name")) return
        val id = m.optInt("id")
        val name = Storage.safeName(m.optString("name"))
        val item = TransferItem(id, name, false, m.optLong("size", 0L))
        val rx = Rx(item)
        inMap[id] = rx // enregistré AVANT toute attente : les morceaux arrivent aussitôt
        items += item
        synchronized(batchIn) { batchIn += item }
        try {
            val dir = Storage.shareDir(ctx)
            val dest = Storage.uniqueFile(dir, name)
            val tmp = File(dir, dest.name + ".part")
            rx.dest = dest
            rx.tmp = tmp
            rx.out = BufferedOutputStream(FileOutputStream(tmp), 256 * 1024)
        } catch (e: Exception) {
            rx.failed = true
        }
        touch(true)
        pushNotifications()
    }

    private fun onChunk(id: Int, data: ByteArray) {
        val rx = inMap[id] ?: return
        if (rx.failed) return
        try {
            rx.out?.write(data) ?: run { rx.failed = true; return }
            rx.received += data.size
            rx.item.transferred = rx.received
            touch(false)
            scheduleNotifications()
        } catch (e: IOException) {
            rx.failed = true
        }
    }

    private fun onEnd(id: Int) {
        val rx = inMap.remove(id) ?: return
        val item = rx.item
        try { rx.out?.close() } catch (_: IOException) { }
        val hadFile = rx.out != null
        rx.out = null
        val complete = item.total <= 0L || rx.received == item.total
        val tmp = rx.tmp
        val dest = rx.dest
        if (rx.failed || !hadFile || !complete || tmp == null || dest == null) {
            tmp?.delete()
            item.status = TStatus.FAILED
        } else if (tmp.renameTo(dest)) {
            item.total = rx.received
            item.transferred = rx.received
            item.savedPath = dest.path
            item.status = TStatus.DONE
            MediaScannerConnection.scanFile(ctx, arrayOf(dest.path), null, null)
        } else {
            tmp.delete()
            item.status = TStatus.FAILED
        }
        touch(true)
        pushNotifications()
    }

    private fun onCancelFrame(id: Int) {
        inMap[id]?.let { abortRx(it); pushNotifications() }
        outMap[id]?.let {
            cancelled += id
            it.status = TStatus.FAILED
            touch(true)
        }
    }

    private fun abortRx(rx: Rx) {
        rx.failed = true
        rx.item.status = TStatus.FAILED
        try { rx.out?.close() } catch (_: IOException) { }
        rx.out = null
        rx.tmp?.delete()
        inMap.remove(rx.item.payloadId)
        touch(true)
    }

    // ========================================================= notifications
    private fun scheduleNotifications() {
        if (notifPending) return
        notifPending = true
        main.postDelayed({
            notifPending = false
            pushNotifications()
        }, 700)
    }

    private fun pushNotifications() {
        for (outgoing in listOf(true, false)) {
            val batch = if (outgoing) batchOut else batchIn
            val snap = synchronized(batch) { batch.toList() }
            if (snap.isEmpty()) continue

            val active = snap.filter { it.status == TStatus.IN_PROGRESS }
            if (active.isNotEmpty()) {
                val total = snap.sumOf { it.total }
                val done = snap.sumOf { it.transferred }
                val pct = if (total > 0) (done * 100 / total).toInt() else 0
                val what = if (snap.size == 1) snap[0].name else "${snap.size} fichiers"
                Notifier.showProgress(
                    ctx, outgoing,
                    if (outgoing) "Envoi en cours" else "Réception en cours",
                    if (total > 0) "$what · $pct %" else what, pct, total == 0L
                )
                continue
            }

            Notifier.cancel(ctx, if (outgoing) Notifier.ID_SEND else Notifier.ID_RECV)
            val ok = snap.filter { it.status == TStatus.DONE }
            val failed = snap.size - ok.size
            val title = if (failed == snap.size) {
                if (outgoing) "Échec de l’envoi" else "Échec de la réception"
            } else {
                if (outgoing) "Envoi terminé" else "Réception terminée"
            }
            val body = if (snap.size == 1) snap[0].name
            else "${ok.size} fichier(s)" + if (failed > 0) " · $failed en échec" else ""
            val path = if (!outgoing && snap.size == 1) snap[0].savedPath else null
            Notifier.showDone(ctx, outgoing, title, body, path)
            synchronized(batch) { batch.clear() }
        }
    }
}
