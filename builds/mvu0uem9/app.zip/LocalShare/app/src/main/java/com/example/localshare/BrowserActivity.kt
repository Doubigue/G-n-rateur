package com.example.localshare

import android.content.Intent

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.launch
import java.io.File
import java.util.Calendar

/**
 * Explorateur de fichiers, avec filtre par jour.
 *  - MODE_REMOTE : « Ses fichiers » — parcourir le stockage de l'autre téléphone et télécharger.
 *  - MODE_LOCAL  : « Fichiers reçus » — le dossier DoubigueShare de ce téléphone.
 */
class BrowserActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_MODE = "mode"
        const val MODE_LOCAL = "local"
        const val MODE_REMOTE = "remote"
    }

    private class Row(val name: String, val isDir: Boolean, val size: Long, val modified: Long, val path: String)

    private val p2p get() = app.p2p
    private val remoteFs get() = app.remoteFs

    private var remote = false
    private var day: Long? = null
    private val selected = LinkedHashSet<String>()
    private lateinit var localRoot: File
    private lateinit var localDir: File

    private lateinit var tvTitle: TextView
    private lateinit var tvPath: TextView
    private lateinit var tvState: TextView
    private lateinit var btnRetry: Button
    private lateinit var btnDownload: Button
    private lateinit var dayPick: Button
    private lateinit var adapter: RowAdapter<Row>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_browser)
        remote = intent.getStringExtra(EXTRA_MODE) == MODE_REMOTE

        tvTitle = findViewById(R.id.tvTitle)
        tvPath = findViewById(R.id.tvPath)
        tvState = findViewById(R.id.tvState)
        btnRetry = findViewById(R.id.btnRetry)
        btnDownload = findViewById(R.id.btnDownload)
        dayPick = findViewById(R.id.dayPick)

        localRoot = Storage.shareDir(this)
        localDir = localRoot
        tvTitle.text = if (remote) "Fichiers de ${p2p.state.value.connectedName}" else "Fichiers reçus (${Storage.FOLDER})"

        adapter = RowAdapter(
            bind = { h, r ->
                val mark = if (r.path in selected) "✔ " else ""
                h.title.text = mark + (if (!remote && FolderLock.isLocked(this, r.path)) "🔑 " else "") + (if (r.isDir) "📁 " else "") + r.name
                h.sub.text = if (r.isDir) "Dossier" else "${Fmt.bytes(r.size)} · ${Fmt.date(r.modified)}"
            },
            onClick = { onRowClick(it) },
            onLongClick = { if (!remote) showLocalMenu(it) }
        )
        findViewById<RecyclerView>(R.id.list).apply {
            layoutManager = LinearLayoutManager(this@BrowserActivity)
            adapter = this@BrowserActivity.adapter
        }

        findViewById<Button>(R.id.dayAll).setOnClickListener { setDay(null) }
        findViewById<Button>(R.id.dayToday).setOnClickListener { setDay(Fmt.startOfDay(0)) }
        findViewById<Button>(R.id.dayYesterday).setOnClickListener { setDay(Fmt.startOfDay(-1)) }
        dayPick.setOnClickListener { pickDay() }
        btnRetry.setOnClickListener { remoteFs.requestAccess() }
        btnDownload.setOnClickListener {
            remoteFs.download(selected.toList())
            Toast.makeText(this, "Téléchargement demandé : ${selected.size} fichier(s) → ${Storage.FOLDER}", Toast.LENGTH_LONG).show()
            selected.clear()
            render()
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (remote) {
                    if (remoteFs.access == RemoteAccess.GRANTED && !remoteFs.atRoot) remoteFs.up() else finish()
                } else if (localDir != localRoot) {
                    localDir = localDir.parentFile ?: localRoot
                    render()
                } else finish()
            }
        })

        if (remote) {
            when (remoteFs.access) {
                RemoteAccess.GRANTED -> remoteFs.list(remoteFs.currentPath)
                RemoteAccess.REQUESTING -> {}
                else -> remoteFs.requestAccess()
            }
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { remoteFs.tick.collect { render() } }
                launch { app.transfers.tick.collect { if (!remote) render() } }
                launch { p2p.state.collect { if (remote && !it.isConnected) finish() } }
            }
        }
    }

    // ---------------------------------------------------------------- filtre par jour
    private fun setDay(d: Long?) {
        day = d
        dayPick.text = if (d != null && d != Fmt.startOfDay(0) && d != Fmt.startOfDay(-1)) Fmt.day(d) else "Choisir un jour"
        render()
    }

    private fun pickDay() {
        val c = Calendar.getInstance().apply { if (day != null) timeInMillis = day!! }
        DatePickerDialog(this, { _, y, m, d ->
            val cal = Calendar.getInstance().apply {
                set(y, m, d, 0, 0, 0)
                set(Calendar.MILLISECOND, 0)
            }
            setDay(cal.timeInMillis)
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).apply {
            datePicker.maxDate = System.currentTimeMillis()
            setTitle("Afficher les fichiers de ce jour")
        }.show()
    }

    // ---------------------------------------------------------------- affichage
    private fun render() {
        val rows: List<Row>
        var state: String? = null
        var retry = false

        if (remote) {
            tvPath.text = Fmt.displayPath(remoteFs.currentPath)
            val who = p2p.state.value.connectedName
            when (remoteFs.access) {
                RemoteAccess.REQUESTING, RemoteAccess.NONE -> state = "En attente de l’autorisation de $who…"
                RemoteAccess.DENIED -> { state = "Accès refusé ou révoqué."; retry = true }
                RemoteAccess.GRANTED -> state = remoteFs.error
                    ?: if (remoteFs.loading && remoteFs.entries.isEmpty()) "Chargement…" else null
            }
            rows = if (remoteFs.access == RemoteAccess.GRANTED) {
                remoteFs.entries.map {
                    Row(it.name, it.isDir, it.size, it.modified, File(remoteFs.currentPath, it.name).path)
                }
            } else emptyList()
        } else {
            tvPath.text = Fmt.displayPath(localDir.path)
            rows = (localDir.listFiles() ?: emptyArray())
                .filter { !it.name.startsWith(".") && !it.name.endsWith(".part") }
                .sortedWith(compareBy({ !it.isDirectory }, { -it.lastModified() }))
                .map { Row(it.name, it.isDirectory, if (it.isDirectory) 0 else it.length(), it.lastModified(), it.path) }
        }

        val d = day
        val shown = if (d == null) rows else rows.filter { it.isDir || Fmt.sameDay(it.modified, d) }
        adapter.submit(shown)

        if (state == null && shown.isEmpty()) state = if (d != null) "Aucun fichier ce jour-là." else "Dossier vide."
        tvState.text = state
        tvState.visibility = if (state != null) View.VISIBLE else View.GONE
        btnRetry.visibility = if (retry) View.VISIBLE else View.GONE

        btnDownload.visibility = if (remote && selected.isNotEmpty()) View.VISIBLE else View.GONE
        btnDownload.text = "Télécharger (${selected.size})"
    }

    private fun onRowClick(r: Row) {
        if (r.isDir) {
            selected.clear()
            if (remote) remoteFs.list(r.path) else { openFolder(File(r.path)) }
        } else if (remote) {
            if (!selected.add(r.path)) selected.remove(r.path)
            render()
        } else {
            val f = File(r.path)
            if (isLockedOrInside(f)) FolderLock.authenticate(this, "Ouvrir le fichier sécurisé") { ok -> if (ok) Storage.open(this, f) }
            else Storage.open(this, f)
        }
    }

    private fun showLocalMenu(r: Row) {
        val f = File(r.path); val locked = FolderLock.isLocked(this, f.path)
        val labels = if (f.isDirectory) arrayOf("🔐 Sécuriser dans le coffre (chiffrer)", "Ouvrir", "Supprimer") else arrayOf("Ouvrir", "Supprimer")
        MaterialAlertDialogBuilder(this).setTitle(f.name).setItems(labels) { _, which ->
            if (f.isDirectory) when (which) {
                0 -> startActivity(Intent(this, VaultActivity::class.java).putExtra(VaultActivity.EXTRA_SECURE_FOLDER, f.canonicalPath))
                1 -> openFolder(f)
                2 -> deleteProtected(f)
            } else when (which) { 0 -> if (isLockedOrInside(f)) FolderLock.authenticate(this, "Ouvrir le fichier sécurisé") { ok -> if (ok) Storage.open(this, f) } else Storage.open(this, f); else -> deleteProtected(f) }
        }.show()
    }

    private fun isLockedOrInside(f: File): Boolean {
        var p: File? = if (f.isDirectory) f.absoluteFile else f.absoluteFile.parentFile
        while (p != null) { if (FolderLock.isLocked(this, p.path)) return true; p = p.parentFile }
        return false
    }
    private fun openFolder(f: File) {
        if (isLockedOrInside(f) || FolderLock.isLocked(this, f.path)) FolderLock.authenticate(this, "Ouvrir le dossier sécurisé") { ok -> if (ok) { localDir = f; render() } }
        else { localDir = f; render() }
    }
    private fun deleteProtected(f: File) {
        val action = { MaterialAlertDialogBuilder(this).setTitle("Supprimer ?").setMessage(f.name).setNegativeButton("Annuler", null).setPositiveButton("Supprimer") { _, _ -> f.deleteRecursively(); render() }.show(); Unit }
        if (isLockedOrInside(f) || FolderLock.isLocked(this, f.path)) FolderLock.authenticate(this, "Autoriser la suppression") { ok -> if (ok) action() } else action()
    }
    private fun confirmDelete(r: Row) = deleteProtected(File(r.path))
}
