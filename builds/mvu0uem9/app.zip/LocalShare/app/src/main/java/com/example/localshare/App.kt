package com.example.localshare

import android.app.Application
import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/** Les moteurs vivent autant que le processus : ils survivent à la fermeture des écrans. */
class App : Application() {
    lateinit var p2p: P2pEngine
    lateinit var transfers: TransferManager
    lateinit var remoteFs: RemoteFs
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()
        Notifier.init(this)
        p2p = P2pEngine(this)
        transfers = TransferManager(this, p2p)
        remoteFs = RemoteFs(this, p2p, transfers)
        p2p.init()
        // Éléments reçus du menu « Partager » : envoyés dès qu'un appareil est connecté.
        scope.launch {
            p2p.state.map { it.isConnected }.distinctUntilChanged().collect { if (it) transfers.flushQueue() }
        }
    }
}

val Context.app: App get() = applicationContext as App
