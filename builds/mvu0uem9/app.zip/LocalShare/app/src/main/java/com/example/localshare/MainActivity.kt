package com.example.localshare

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.launch

/** Accueil : appareils à proximité en Wi-Fi Direct, connexion, partage depuis le menu « Partager » d'Android. */
class MainActivity : AppCompatActivity() {

    private val p2p get() = app.p2p
    private val transfers get() = app.transfers

    private lateinit var tvName: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvShare: TextView
    private lateinit var tvEmpty: TextView
    private lateinit var btnFix: Button
    private lateinit var btnOpen: Button
    private lateinit var adapter: RowAdapter<Peer>
    private lateinit var tiles: TileAdapter
    private var visibleToOthers = true

    private var pendingDialog: AlertDialog? = null
    private var shownPendingCode: String? = null
    private var lastOpenedId: String? = null
    private var askedOnce = false
    private var fromFix = false
    private var scanAfterWifiSettings = false

    private val qrScanner = registerForActivityResult(ScanContract()) { result ->
        val value = result.contents?.trim().orEmpty()
        if (value.isNotEmpty()) handleScannedCode(value)
    }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (fromFix && !p2p.hasPermission()) openAppSettings()
            fromFix = false
            p2p.start()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        tvName = findViewById(R.id.tvName)
        tvStatus = findViewById(R.id.tvStatus)
        tvShare = findViewById(R.id.tvShare)
        tvEmpty = findViewById(R.id.tvEmpty)
        btnFix = findViewById(R.id.btnFix)
        btnOpen = findViewById(R.id.btnOpen)

        adapter = RowAdapter(
            bind = { h, p ->
                h.title.text = p.name
                h.sub.text = if (p.state == PeerState.CONNECTING) "Connexion…" else "Touchez pour se connecter"
            },
            onClick = { p -> p2p.connectTo(p.id) }
        )
        findViewById<RecyclerView>(R.id.list).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }

        tiles = TileAdapter()
        findViewById<RecyclerView>(R.id.tiles).setupTiles(tiles)
        findViewById<View>(R.id.actionShowQr).setOnClickListener {
            startActivity(Intent(this, HotspotActivity::class.java).putExtra("auto_start_hotspot", true))
        }
        findViewById<View>(R.id.actionScanQr).setOnClickListener { scanQrCode() }
        findViewById<View>(R.id.cardReceive).setOnClickListener { scanQrCode() }
        findViewById<View>(R.id.cardSend).setOnClickListener {
            startActivity(Intent(this, BrowserActivity::class.java)
                .putExtra(BrowserActivity.EXTRA_MODE, BrowserActivity.MODE_LOCAL))
        }
        findViewById<View>(R.id.btnMore).setOnClickListener { showSettingsMenu() }

        btnFix.setOnClickListener { onFix() }
        btnOpen.setOnClickListener { startActivity(Intent(this, SessionActivity::class.java)) }
        tvShare.setOnClickListener {
            transfers.clearQueue()
            Toast.makeText(this, "Envoi annulé", Toast.LENGTH_SHORT).show()
        }
        buildTiles()

        if (savedInstanceState == null) handleShareIntent(intent)

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { p2p.state.collect { render(it) } }
                launch { transfers.tick.collect { renderShare() } }
                launch { ServerState.status.collect { buildTiles() } }
                launch { HotspotController.state.collect { buildTiles() } }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleShareIntent(intent)
    }

    override fun onStart() {
        super.onStart()
        ensureAndStart()
        buildTiles()
    }

    override fun onResume() {
        super.onResume()
        if (scanAfterWifiSettings) {
            scanAfterWifiSettings = false
            window.decorView.postDelayed({ scanQrCode() }, 350)
        }
    }

    private fun scanQrCode() {
        val wifi = applicationContext.getSystemService(android.content.Context.WIFI_SERVICE) as android.net.wifi.WifiManager
        if (!wifi.isWifiEnabled) {
            scanAfterWifiSettings = true
            MaterialAlertDialogBuilder(this)
                .setTitle("Activez le Wi-Fi")
                .setMessage("Activez le Wi-Fi dans le panneau Android. Au retour, LocalShare ouvrira automatiquement le scanner. Android conserve la confirmation de connexion.")
                .setPositiveButton("Activer le Wi-Fi") { _, _ ->
                    try {
                        if (Build.VERSION.SDK_INT >= 29) startActivity(Intent("android.settings.panel.action.INTERNET_CONNECTIVITY"))
                        else startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
                    } catch (_: Exception) {
                        try { startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) } catch (_: Exception) { scanAfterWifiSettings = false }
                    }
                }
                .setNegativeButton("Annuler") { _, _ -> scanAfterWifiSettings = false }
                .show()
            return
        }
        val options = ScanOptions().apply {
            setPrompt("Scannez le QR Wi-Fi ou l’adresse du serveur LocalShare")
            setBeepEnabled(false)
            setOrientationLocked(false)
            setDesiredBarcodeFormats(ScanOptions.QR_CODE)
        }
        qrScanner.launch(options)
    }

    private fun handleScannedCode(value: String) {
        when {
            value.startsWith("http://", true) || value.startsWith("https://", true) -> {
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(value))) }
                catch (_: Exception) { Toast.makeText(this, "Impossible d’ouvrir ce lien", Toast.LENGTH_LONG).show() }
            }
            value.startsWith("WIFI:", true) -> MaterialAlertDialogBuilder(this)
                .setTitle("QR Wi-Fi détecté")
                .setMessage("Android doit confirmer la connexion au réseau. Ouvrez les réglages Wi-Fi et scannez le QR avec l’appareil photo si nécessaire.")
                .setPositiveButton("Réglages Wi-Fi") { _, _ -> try { startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) } catch (_: Exception) { } }
                .setNegativeButton("Annuler", null).show()
            else -> MaterialAlertDialogBuilder(this).setTitle("QR code non reconnu")
                .setMessage("Scannez un QR Wi-Fi ou une adresse HTTP/HTTPS LocalShare.")
                .setPositiveButton("OK", null).show()
        }
    }

    private fun showSettingsMenu() {
        val options = arrayOf("QR du serveur web", "Point d’accès / QR Wi-Fi", "Fichiers reçus", "Accès aux fichiers")
        MaterialAlertDialogBuilder(this).setTitle("Paramètres LocalShare")
            .setItems(options) { _, which -> when (which) {
                0 -> startActivity(Intent(this, WebServerActivity::class.java))
                1 -> startActivity(Intent(this, HotspotActivity::class.java))
                2 -> startActivity(Intent(this, BrowserActivity::class.java).putExtra(BrowserActivity.EXTRA_MODE, BrowserActivity.MODE_LOCAL))
                3 -> Storage.requestAccess(this)
            } }.show()
    }

    // ---------------------------------------------------------------- tableau de bord (cartes)
    private fun buildTiles() {
        if (!::tiles.isInitialized) return
        val web = ServerState.status.value
        val hs = HotspotController.state.value
        val files = Storage.hasAccess(this)
        tiles.submit(
            listOf(
                Tile(
                    R.drawable.ic_web, "Serveur web",
                    if (web.running) "Actif · port ${web.port}" else "Partage par navigateur + QR Code",
                    active = web.running
                ) { startActivity(Intent(this, WebServerActivity::class.java)) },
                Tile(
                    R.drawable.ic_hotspot, "Point d’accès",
                    when {
                        hs.active -> "Actif · ${hs.ssid}"
                        hs.starting -> "Démarrage…"
                        else -> "Hotspot sans Internet"
                    },
                    active = hs.active
                ) { startActivity(Intent(this, HotspotActivity::class.java)) },
                Tile(R.drawable.ic_download, "Fichiers reçus", "Dossier ${Storage.FOLDER}") {
                    startActivity(Intent(this, BrowserActivity::class.java).putExtra(BrowserActivity.EXTRA_MODE, BrowserActivity.MODE_LOCAL))
                },
                Tile(
                    R.drawable.ic_visibility, "Visibilité",
                    if (visibleToOthers) "Visible par les autres téléphones" else "Masqué",
                    active = visibleToOthers
                ) {
                    visibleToOthers = !visibleToOthers
                    p2p.setVisible(visibleToOthers)
                    buildTiles()
                },
                Tile(R.drawable.ic_edit, "Mon nom", p2p.state.value.deviceName) { askRename() },
                Tile(
                    R.drawable.ic_shield, "Accès aux fichiers",
                    if (files) "Autorisé" else "À autoriser", active = files
                ) { Storage.requestAccess(this) },
                Tile(R.drawable.ic_battery, "Batterie", "Rester connecté écran éteint") { requestBatteryExemption() },
                Tile(R.drawable.ic_power, "Quitter", "Arrêter LocalShare", danger = true) {
                    p2p.shutdown()
                    stopService(Intent(this, P2pService::class.java))
                    finishAffinity()
                }
            )
        )
    }

    // ---------------------------------------------------------------- partage Android
    private fun handleShareIntent(i: Intent?) {
        if (i == null) return
        if (i.action == Intent.ACTION_SEND || i.action == Intent.ACTION_SEND_MULTIPLE) {
            transfers.queueFromIntent(i)
            i.action = null
        }
    }

    private fun renderShare() {
        val n = transfers.queuedCount
        tvShare.visibility = if (n > 0) View.VISIBLE else View.GONE
        tvShare.text = "$n élément(s) à envoyer : touchez l’appareil destinataire (touchez ici pour annuler)."
    }

    // ---------------------------------------------------------------- permissions
    private fun neededPermissions(): Array<String> {
        val l = p2p.requiredPermissions().toMutableList()
        if (Build.VERSION.SDK_INT >= 33) l += Manifest.permission.POST_NOTIFICATIONS
        return l.toTypedArray()
    }

    private fun ensureAndStart() {
        if (!p2p.hasPermission() && !askedOnce) {
            askedOnce = true
            permLauncher.launch(neededPermissions())
        } else {
            p2p.start()
        }
    }

    private fun onFix() {
        when {
            !p2p.hasPermission() -> {
                fromFix = true
                permLauncher.launch(neededPermissions())
            }
            p2p.state.value.statusNeedsSettings -> openAppSettings()
            else -> p2p.restart()
        }
    }

    private fun openAppSettings() {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }

    private fun requestBatteryExemption() {
        try {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    private fun askRename() {
        val et = EditText(this).apply { setText(p2p.state.value.deviceName); setSelectAllOnFocus(true) }
        MaterialAlertDialogBuilder(this)
            .setTitle("Nom de votre appareil")
            .setView(et)
            .setPositiveButton("Enregistrer") { _, _ -> p2p.renameDevice(et.text.toString()) }
            .setNegativeButton("Annuler", null)
            .show()
    }

    // ---------------------------------------------------------------- affichage
    private fun render(s: P2pState) {
        tvName.text = "Mon nom : ${s.deviceName}"
        buildTiles()

        val lines = mutableListOf<String>()
        s.status?.let { lines += it }
        s.info?.let { lines += it }
        s.outgoingCode?.let { lines += "Code de vérification : $it (le même doit s’afficher sur l’autre téléphone)" }
        if (lines.isEmpty()) {
            lines += when {
                s.isConnected -> "Connecté à ${s.connectedName}"
                s.advertising && s.discovering -> "Visible comme « ${s.deviceName} » · recherche en cours…"
                s.advertising -> "Visible comme « ${s.deviceName} »"
                s.discovering -> "Recherche d’appareils…"
                else -> "Inactif"
            }
        }
        tvStatus.text = lines.joinToString("\n")

        btnFix.visibility = if (s.status != null) View.VISIBLE else View.GONE
        btnFix.text = if (s.statusNeedsSettings) "Autoriser" else "Réessayer"
        btnOpen.visibility = if (s.isConnected) View.VISIBLE else View.GONE

        val shown = s.peers.filter { it.state != PeerState.CONNECTED }
        adapter.submit(shown)
        tvEmpty.visibility = if (shown.isEmpty()) View.VISIBLE else View.GONE

        // Demande de connexion entrante.
        val pc = s.pending
        if (pc != null) {
            if (pendingDialog?.isShowing != true || shownPendingCode != pc.code) {
                pendingDialog?.dismiss()
                shownPendingCode = pc.code
                pendingDialog = MaterialAlertDialogBuilder(this)
                    .setTitle("Demande de connexion")
                    .setMessage(
                        "« ${pc.name} » veut se connecter à votre appareil (Wi-Fi Direct).\n\n" +
                                "Code : ${pc.code}\nVérifiez que le même code s’affiche sur l’autre appareil."
                    )
                    .setCancelable(false)
                    .setPositiveButton("Accepter") { _, _ -> p2p.acceptPending() }
                    .setNegativeButton("Refuser") { _, _ -> p2p.rejectPending() }
                    .show()
            }
        } else {
            pendingDialog?.dismiss()
            pendingDialog = null
            shownPendingCode = null
        }

        // Session ouverte automatiquement une fois par connexion.
        if (s.connectedId != null) {
            if (s.connectedId != lastOpenedId) {
                lastOpenedId = s.connectedId
                startActivity(Intent(this, SessionActivity::class.java))
            }
        } else {
            lastOpenedId = null
        }
    }

    override fun onDestroy() {
        pendingDialog?.dismiss()
        super.onDestroy()
    }
}
