package com.example.localshare

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.launch

/** Point d'accès (hotspot) : les autres appareils rejoignent ce Wi-Fi, puis ouvrent le serveur web. */
class HotspotActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var tvCreds: TextView
    private lateinit var tvHint: TextView
    private lateinit var ivQr: ImageView
    private lateinit var qrCard: View
    private lateinit var dot: View
    private lateinit var btnToggle: MaterialButton

    private var lastQr: String? = null

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
            // Les notifications sont utiles mais facultatives ; seule l’autorisation Wi-Fi requise bloque le hotspot.
            if (HotspotController.hasPermission(this)) startHotspot()
            else androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Autorisations nécessaires")
                .setMessage("Pour créer l’accès local, autorisez les appareils à proximité et, selon votre version d’Android, la localisation. Les notifications permettent de suivre les transferts en arrière-plan.")
                .setPositiveButton("Réessayer") { _, _ -> requestConnectionPermissions() }
                .setNegativeButton("Plus tard", null).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_hotspot)

        tvStatus = findViewById(R.id.tvStatus)
        tvCreds = findViewById(R.id.tvCreds)
        tvHint = findViewById(R.id.tvHint)
        ivQr = findViewById(R.id.ivQr)
        qrCard = findViewById(R.id.qrCard)
        dot = findViewById(R.id.dot)
        btnToggle = findViewById(R.id.btnToggle)

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<View>(R.id.btnWeb).setOnClickListener { startActivity(Intent(this, WebServerActivity::class.java)) }
        findViewById<View>(R.id.btnSystem).setOnClickListener { openSystemHotspot() }
        btnToggle.setOnClickListener { onToggle() }
        if (intent.getBooleanExtra("auto_start_hotspot", false)) {
            btnToggle.post { if (!HotspotController.state.value.active && !HotspotController.state.value.starting) onToggle() }
        }
        tvCreds.setOnClickListener {
            val pw = HotspotController.state.value.password
            if (pw.isNotEmpty()) {
                (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
                    .setPrimaryClip(ClipData.newPlainText("LocalShare", pw))
                Toast.makeText(this, "Mot de passe copié", Toast.LENGTH_SHORT).show()
            }
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                HotspotController.state.collect { render(it) }
            }
        }
    }

    private fun render(s: HotspotInfo) {
        dot.visibility = if (s.active) View.VISIBLE else View.GONE
        when {
            s.active -> {
                tvStatus.text = "Point d’accès actif"
                tvCreds.text = "Réseau : ${s.ssid}\nMot de passe : ${s.password}\n(touchez pour copier le mot de passe)"
                tvCreds.visibility = View.VISIBLE
                qrCard.visibility = View.VISIBLE
                tvHint.visibility = View.VISIBLE
                btnToggle.text = "Arrêter le point d’accès"
                val payload = Qr.wifi(s.ssid, s.password)
                if (payload != lastQr) {
                    lastQr = payload
                    lifecycleScope.launch { ivQr.setImageBitmap(Qr.make(payload)) }
                }
            }
            s.starting -> {
                tvStatus.text = "Démarrage du point d’accès…"
                hideDetails()
                btnToggle.text = "Annuler"
            }
            else -> {
                tvStatus.text = s.error ?: "Point d’accès arrêté"
                hideDetails()
                btnToggle.text = "Créer le point d’accès"
            }
        }
    }

    private fun hideDetails() {
        tvCreds.visibility = View.GONE
        qrCard.visibility = View.GONE
        tvHint.visibility = View.GONE
        lastQr = null
    }

    private fun onToggle() {
        val s = HotspotController.state.value
        if (s.active || s.starting) {
            HotspotController.stop()
            return
        }
        requestConnectionPermissions()
    }

    private fun requestConnectionPermissions() {
        val needed = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) {
            needed += android.Manifest.permission.NEARBY_WIFI_DEVICES
            needed += android.Manifest.permission.POST_NOTIFICATIONS
        } else {
            needed += android.Manifest.permission.ACCESS_FINE_LOCATION
        }
        val missing = needed.distinct().filter {
            androidx.core.content.ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) permLauncher.launch(missing.toTypedArray()) else startHotspot()
    }

    private fun startHotspot() {
        // Laisser Android gérer la radio Wi-Fi : une application tierce ne peut pas commuter
        // librement Wi-Fi/hotspot sur les versions récentes. On tente l'API système d'abord.
        if (!HotspotController.locationOk(this)) {
            Toast.makeText(this, "Activez la localisation de l’appareil, puis réessayez", Toast.LENGTH_LONG).show()
            try { startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) } catch (_: Exception) { }
            return
        }
        HotspotController.start(this)
    }

    /** Point d'accès d'Android (celui du réglage « Partage de connexion »). */
    private fun openSystemHotspot() {
        for (i in listOf(Intent("android.settings.TETHER_SETTINGS"), Intent(Settings.ACTION_WIRELESS_SETTINGS))) {
            try { startActivity(i); return } catch (_: Exception) { }
        }
    }
}
