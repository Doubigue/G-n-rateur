# Dossiers sécurisés LocalShare

L’action « Sécuriser dans le coffre (chiffrer) » compresse le dossier dans le cache privé de l’application, importe l’archive dans le coffre chiffré AES-GCM puis tente de supprimer le dossier source. Les autres explorateurs ne peuvent pas lire le conteneur chiffré stocké dans le répertoire privé de LocalShare.

Le dossier sécurisé est conservé comme archive ZIP chiffrée, pas comme dossier visible dans le stockage partagé. Pour récupérer les fichiers, déverrouiller le coffre puis exporter l’archive et l’extraire. Si Android refuse la suppression d’un élément source, LocalShare affiche un avertissement : il faut vérifier et supprimer manuellement les éléments restants.

Important : la protection ne couvre pas les copies préexistantes ailleurs, les sauvegardes ni les fichiers déjà partagés.
