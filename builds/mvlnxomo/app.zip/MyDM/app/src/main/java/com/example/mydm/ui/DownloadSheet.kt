package com.example.mydm.ui

import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.mydm.browser.EpisodeLink
import com.example.mydm.browser.PageScan
import com.example.mydm.browser.PageScanner
import com.example.mydm.core.*
import com.example.mydm.downloader.DownloadService
import kotlinx.coroutines.launch

/**
 * Fenêtre « Télécharger » :
 *  • lien YouTube / Facebook / TikTok → qualités + tailles (analyse pré-chargée, donc quasi instantanée) ;
 *  • autre page (cinezzz, papadustream…) → analyse SANS lecture de la vidéo + détection des épisodes de la série ;
 *  • médias détectés pendant la navigation.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DownloadSheet(
    found: SnapshotStateList<DetectedMedia>, pageUrl: String, onDismiss: () -> Unit,
    onSeries: ((List<EpisodeLink>, String) -> Unit)? = null
) {
    val ctx = LocalContext.current
    val app = appInstance()
    val scope = rememberCoroutineScope()

    var link by remember { mutableStateOf(if (pageUrl.startsWith("http")) pageUrl else "") }
    var loading by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf(MediaResolver.cached(link)) }
    var scan by remember { mutableStateOf<PageScan?>(null) }
    var infoUrl by remember { mutableStateOf(link) }
    var error by remember { mutableStateOf<String?>(null) }
    val sizes = remember { mutableStateMapOf<String, Long?>() }
    val ytState by app.ytState.collectAsState()

    fun analyze() {
        val u = link.trim()
        if (u.isEmpty()) return
        val url = if (u.startsWith("http")) u else Prefs.resolveInput(u)
        loading = true; error = null; info = null; scan = null
        scope.launch {
            if (MediaResolver.isSupportedPage(url)) {
                runCatching { MediaResolver.ytInfo(app, url) }
                    .onSuccess { info = it; infoUrl = url }
                    .onFailure { error = (it.message ?: "Analyse impossible").take(240) }
            } else {
                runCatching { PageScanner.scan(ctx, url, null, true) }
                    .onSuccess {
                        scan = it; infoUrl = url
                        if (it.media.isEmpty() && it.embeds.isEmpty() && it.episodes.isEmpty())
                            error = "Aucun média trouvé. Essayez de lancer la vidéo dans la page, ou augmentez la durée d'analyse (Paramètres)."
                    }
                    .onFailure { error = (it.message ?: "Analyse impossible").take(240) }
            }
            loading = false
        }
    }

    // Ouverture : analyse automatique (YouTube/Facebook/TikTok : déjà pré-chargée ; autre page : analyse sans lecture)
    LaunchedEffect(Unit) {
        if (link.isBlank() || info != null) return@LaunchedEffect
        if (MediaResolver.isSupportedPage(link)) { if (MediaResolver.isVideoPage(link)) analyze() }
        else if (found.isEmpty()) analyze()
    }

    fun downloadYt(opt: QualityOption) {
        val i = info ?: return
        scope.launch {
            val id = app.downloadEngine.enqueueYt(infoUrl, i.title, opt)
            DownloadService.start(ctx, id)
            Toast.makeText(ctx, "Téléchargement ajouté", Toast.LENGTH_SHORT).show()
            onDismiss()
        }
    }

    fun downloadDirect(m: DetectedMedia) {
        scope.launch {
            DownloadActions.queue(ctx, app, m)
            found.remove(m)
            Toast.makeText(ctx, "Téléchargement ajouté", Toast.LENGTH_SHORT).show()
        }
    }

    fun downloadEmbed(embed: String) {
        scope.launch {
            val name = cleanName(scan?.title.orEmpty()).ifBlank { "video" }
            val id = app.downloadEngine.enqueueYt(embed, name, QualityOption("", null, false, "bv*+ba/b"), infoUrl)
            DownloadService.start(ctx, id)
            Toast.makeText(ctx, "Ajouté (yt-dlp)", Toast.LENGTH_SHORT).show()
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = Bg
    ) {
        LazyColumn(
            Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item { Text("Télécharger", color = Txt, fontSize = 20.sp) }

            item {
                Column(Modifier.fillMaxWidth().glass().padding(12.dp)) {
                    Text("Lien ou page (YouTube, Facebook, TikTok, site de séries…)", color = Muted, fontSize = 12.sp)
                    OutlinedTextField(link, { link = it }, Modifier.fillMaxWidth(), singleLine = true,
                        placeholder = { Text("Collez un lien ici") })
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button({ analyze() }, enabled = link.isNotBlank() && !loading) { Text("Analyser") }
                        Spacer(Modifier.width(10.dp))
                        if (ytState == "loading") Text("Moteur en préparation…", color = Muted, fontSize = 11.sp)
                        else if (ytState.startsWith("error:")) Text("Moteur yt-dlp indisponible", color = Danger, fontSize = 11.sp)
                        else Text("Pas besoin de lire la vidéo", color = Muted, fontSize = 11.sp)
                    }
                }
            }
            if (loading) item {
                Column {
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                    Text(if (MediaResolver.isSupportedPage(link)) "Analyse du lien…" else "Analyse de la page en arrière-plan…", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
                }
            }
            error?.let { e -> item { Text(e, color = Danger, fontSize = 12.sp) } }

            // ── YouTube / Facebook / TikTok
            info?.let { i ->
                item { Text(i.title + (i.uploader?.let { " — $it" } ?: ""), color = Accent, maxLines = 2, overflow = TextOverflow.Ellipsis) }
                items(i.options) { o ->
                    Row(Modifier.fillMaxWidth().glass().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(o.label, color = Txt)
                            Text(o.sizeBytes?.let { (if (o.approx) "~" else "") + formatSize(it) } ?: "taille inconnue", color = Muted, fontSize = 12.sp)
                        }
                        Button({ downloadYt(o) }) { Text("Télécharger") }
                    }
                }
            }

            // ── Page analysée sans lecture
            scan?.let { sc ->
                if (sc.title.isNotBlank()) item { Text(sc.title, color = Accent, maxLines = 2, overflow = TextOverflow.Ellipsis) }
                if (sc.players.isNotEmpty()) item {
                    val order = sc.players.take(3).joinToString("  →  ") { "n°${it.idx + 1} ${it.name}${if (it.lang == "VO") " (VO)" else ""}" }
                    Text("Lecteurs vus : ${sc.players.size} • ordre d'essai : $order", color = Muted, fontSize = 11.sp)
                }
                if (sc.episodes.size >= 2 && onSeries != null) item {
                    Column(Modifier.fillMaxWidth().glass().padding(12.dp)) {
                        Text("📺 ${sc.episodes.size} épisodes détectés", color = Txt)
                        Text("Téléchargez toute la série d'un coup au lieu d'un épisode à la fois.", color = Muted, fontSize = 12.sp)
                        Button({ onSeries(sc.episodes, sc.title); onDismiss() }, Modifier.padding(top = 6.dp)) { Text("Choisir les épisodes") }
                    }
                }
                if (sc.media.isNotEmpty()) {
                    item { Text("Vidéos et fichiers trouvés (${sc.media.size})", color = Txt, modifier = Modifier.padding(top = 4.dp)) }
                    items(sc.media, key = { "s" + it.url }) { m -> MediaRow(m, sizes) { downloadDirect(m) } }
                }
                if (sc.media.none { it.type == MediaType.VIDEO || it.type == MediaType.HLS } && sc.embeds.isNotEmpty()) {
                    item {
                        Text("Lecteurs intégrés (yt-dlp peut en extraire certains)", color = Txt, modifier = Modifier.padding(top = 4.dp))
                    }
                    items(sc.embeds.take(6), key = { "e" + it }) { e ->
                        Row(Modifier.fillMaxWidth().glass().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text((Uri.parse(e).host ?: e) + if (MediaResolver.isKnownHoster(e)) "  ✓" else "", color = Txt, fontSize = 13.sp,
                                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                            Button({ downloadEmbed(e) }) { Text("Essayer") }
                        }
                    }
                }
            }

            // ── Médias détectés pendant la navigation
            item { Text("Détectés pendant la navigation (${found.size})", color = Txt, modifier = Modifier.padding(top = 8.dp)) }
            if (found.isEmpty()) item {
                Text("Rien pour l'instant. Utilisez « Analyser » ci-dessus : inutile de lancer la vidéo.", color = Muted, fontSize = 12.sp)
            }
            items(found.toList(), key = { "f" + it.url }) { m -> MediaRow(m, sizes) { downloadDirect(m) } }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun MediaRow(m: DetectedMedia, sizes: MutableMap<String, Long?>, onGet: () -> Unit) {
    LaunchedEffect(m.url) { if (m.sizeBytes == null && m.url !in sizes) sizes[m.url] = MediaResolver.probeSize(m) }
    val size = m.sizeBytes ?: sizes[m.url]
    Row(Modifier.fillMaxWidth().glass().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(m.displayName(), color = Txt, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
            Text(m.type.name + " • " + (size?.let { formatSize(it) } ?: if (m.url in sizes) "taille inconnue" else "calcul…") +
                " • " + (Uri.parse(m.url).host ?: ""), color = Muted, fontSize = 11.sp, maxLines = 1)
        }
        Button(onGet, contentPadding = PaddingValues(horizontal = 12.dp)) { Text("⬇") }
    }
}
