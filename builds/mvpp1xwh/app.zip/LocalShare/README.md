# Local Share — serveur de partage local (Android / Kotlin)

Le téléphone devient un serveur HTTP local. N'importe quel navigateur (PC, autre téléphone) sur le même
Wi-Fi ou sur le point d'accès du téléphone peut parcourir ses fichiers, les télécharger, lire les vidéos
en streaming, envoyer des fichiers vers le téléphone et récupérer les APK des applications installées.
Rien ne passe par Internet.

## Structure

```
app/build.gradle
app/src/main/AndroidManifest.xml
app/src/main/assets/index.html                      <- dashboard web
app/src/main/java/com/example/localshare/
    MainActivity.kt   ShareService.kt   LocalServer.kt   Support.kt
app/src/main/res/layout/activity_main.xml
app/src/main/res/values/{strings,themes,ic_launcher_background}.xml
app/src/main/res/drawable/ic_launcher_foreground.xml   <- icône adaptative
app/src/main/res/mipmap-*/                              <- icônes de repli (Android 7.x) + anydpi-v26
ic_launcher-playstore.png                               <- 512x512 pour la fiche Play Store
```

## Compiler

1. Android Studio (Ladybug ou plus récent) : **New Project > Empty Views Activity**
   - Language : Kotlin, Build config : Groovy DSL, Minimum SDK : 24
   - Package name : `com.example.localshare` (sinon adaptez `package` et `namespace`)
2. Remplacez par les fichiers de ce dossier (même chemins). Supprimez le `MainActivity.kt`,
   `activity_main.xml` et `themes.xml` générés (y compris `values-night/themes.xml` s'il existe).
   **Supprimez aussi tous les dossiers `res/mipmap-*` du template** (le projet fournit ses propres icônes,
   sinon erreur « Duplicate resources »).
3. Dans le `build.gradle` **racine**, vérifiez les plugins :
   ```groovy
   plugins {
       id 'com.android.application' version '8.7.3' apply false
       id 'org.jetbrains.kotlin.android' version '2.0.21' apply false
   }
   ```
4. **Sync Project with Gradle Files**, puis **Run** sur un vrai téléphone (Android 7+).

## Tester

1. Lancez l'app, appuyez sur **Autoriser l'accès aux fichiers**, activez « Local Share » dans l'écran système.
2. Appuyez sur **Activer le serveur** (acceptez les notifications). Une notification permanente apparaît.
3. Le QR Code et l'adresse `http://192.168.x.x:8080/?t=…` s'affichent.
4. Sur un PC/téléphone **sur le même Wi-Fi** (ou connecté au hotspot du téléphone), scannez le QR Code
   ou tapez l'adresse. La première visite pose un cookie : ensuite `http://192.168.x.x:8080` suffit.
5. Vérifiez : navigation dans les dossiers, lecture d'une vidéo (barre de progression déplaçable),
   glisser-déposer d'un gros fichier (le débit s'affiche), onglet Applications, bouton APK.

Test en ligne de commande (remplacez l'URL et le jeton) :
```
curl -c jar.txt "http://192.168.1.20:8080/?t=JETON" -o /dev/null
curl -b jar.txt -T photo.jpg "http://192.168.1.20:8080/api/upload?path=/Download&name=photo.jpg" -X POST
```

## Points d'attention

- **Jeton de session** : sans lui, toute personne sur le même Wi-Fi pourrait lire tout le stockage. Le jeton est
  régénéré à chaque démarrage et seul le QR Code/l'adresse affichés sur le téléphone le contiennent.
  Le trafic est en HTTP clair : à utiliser sur un réseau de confiance (ou le hotspot du téléphone).
- **Tailwind** : le dashboard n'utilise pas le CDN Tailwind, car un hotspot n'a pas Internet et la page serait
  sans style. Le CSS est intégré. Pour utiliser Tailwind quand même, copiez `tailwind.js` dans `assets/`
  et référencez `/static/tailwind.js`.
- **Applications découpées (split APK)** : la plupart des apps du Play Store sont des bundles. Dans ce cas
  le bouton télécharge un `.apks` (zip de tous les APK) à installer avec un outil type SAI ou `adb install-multiple`.
  Les apps à APK unique sont envoyées en `.apk` classique.
- **Play Store** : `MANAGE_EXTERNAL_STORAGE`, `QUERY_ALL_PACKAGES` et le service `specialUse` demandent une
  justification de politique pour une publication. Pour un usage personnel/sideload, aucun souci.
- **Batterie** : le service tient Wi-Fi et CPU éveillés. Sur certaines surcouches (Xiaomi, Samsung, Huawei…),
  désactivez l'optimisation de batterie pour l'app si le serveur est coupé en arrière-plan.
- Les dossiers ne se déposent pas dans l'interface web (fichiers uniquement). Seul le stockage partagé
  (`/storage/emulated/0`) est exposé, pas `/Android/data` sur Android 11+.
