package com.example.localshare

import kotlinx.coroutines.flow.MutableStateFlow
import java.net.Inet4Address
import java.net.NetworkInterface

/** État du serveur, partagé entre le Service et l'Activity. */
data class ServerStatus(
    val running: Boolean = false,
    val port: Int = 8080,
    val token: String = "",
    val error: String? = null
)

object ServerState {
    val status = MutableStateFlow(ServerStatus())
}

object NetUtils {
    /**
     * Renvoie l'IPv4 locale utilisable par un autre appareil : Wi-Fi client, point d'accès
     * (hotspot) ou Ethernet. Les interfaces de données mobiles sont ignorées.
     */
    fun localIp(): String? {
        return try {
            val found = mutableListOf<Pair<Int, String>>()
            for (nif in NetworkInterface.getNetworkInterfaces()?.toList().orEmpty()) {
                if (!nif.isUp || nif.isLoopback) continue
                val name = nif.name.lowercase()
                if (name.startsWith("rmnet") || name.startsWith("ccmni") ||
                    name.startsWith("tun") || name.startsWith("dummy") || name.startsWith("v4-")
                ) continue
                for (addr in nif.inetAddresses) {
                    if (addr is Inet4Address && !addr.isLoopbackAddress && addr.isSiteLocalAddress) {
                        val prio = when {
                            name.startsWith("wlan") || name.startsWith("swlan") || name.startsWith("ap") -> 0
                            name.startsWith("eth") -> 1
                            else -> 2
                        }
                        found += prio to addr.hostAddress!!
                    }
                }
            }
            found.minByOrNull { it.first }?.second
        } catch (e: Exception) {
            null
        }
    }
}
