package com.example.localshare

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Base64
import androidx.core.app.NotificationCompat
import java.io.IOException
import java.security.SecureRandom

/**
 * Service de premier plan : garde le serveur HTTP en vie (notification permanente),
 * et verrouille Wi-Fi + CPU pour conserver le débit écran éteint.
 */
class ShareService : Service() {

    companion object {
        const val ACTION_STOP = "com.example.localshare.STOP"
        private const val CHANNEL_ID = "share_server"
        private const val NOTIF_ID = 1
        private const val BASE_PORT = 8080
    }

    private var server: LocalServer? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            shutdown()
            return START_NOT_STICKY
        }

        createChannel()
        val notif = buildNotification("Démarrage du serveur…")
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notif)
        }

        if (server == null) startServer()
        return START_STICKY
    }

    private fun startServer() {
        val token = newToken()
        var started: LocalServer? = null
        var port = BASE_PORT
        var lastError: String? = null

        // Essaie 8080, puis 8081… si le port est déjà occupé.
        for (p in BASE_PORT..BASE_PORT + 9) {
            val s = LocalServer(applicationContext, p, token)
            try {
                s.start(60_000, false) // timeout de lecture large pour les gros uploads
                started = s
                port = p
                break
            } catch (e: IOException) {
                lastError = e.message
            }
        }

        if (started == null) {
            shutdown("Impossible de démarrer le serveur : $lastError")
            return
        }

        server = started
        acquireLocks()
        ServerState.status.value = ServerStatus(running = true, port = port, token = token)
        getSystemService(NotificationManager::class.java)
            .notify(NOTIF_ID, buildNotification("Serveur actif sur le port $port"))
    }

    private fun shutdown(error: String? = null) {
        server?.stop()
        server = null
        releaseLocks()
        ServerState.status.value = ServerStatus(running = false, error = error)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        server?.stop()
        server = null
        releaseLocks()
        if (ServerState.status.value.running) ServerState.status.value = ServerStatus()
        super.onDestroy()
    }

    // ------------------------------------------------------------ verrous

    @Suppress("DEPRECATION")
    private fun acquireLocks() {
        val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "LocalShare:wifi").apply {
            setReferenceCounted(false)
            acquire()
        }
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LocalShare:cpu").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun releaseLocks() {
        try { wifiLock?.takeIf { it.isHeld }?.release() } catch (_: Exception) { }
        try { wakeLock?.takeIf { it.isHeld }?.release() } catch (_: Exception) { }
        wifiLock = null
        wakeLock = null
    }

    // ------------------------------------------------------------ notification

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Serveur de partage", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, ShareService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("Local Share")
            .setContentText(text)
            .setContentIntent(open)
            .addAction(0, "Arrêter", stop)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun newToken(): String {
        val b = ByteArray(9)
        SecureRandom().nextBytes(b)
        return Base64.encodeToString(b, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    }
}
