// ============ Données d’exemple (catalogue + contenus + configuration) ============
// Couvertures générées en SVG (aucune image externe nécessaire). Photos : pravatar.cc / picsum.photos.
const REAL_COVERS = [
  "https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&w=700&q=88",
  "https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=700&q=88",
  "https://images.unsplash.com/photo-1495446815901-a7297e633e8d?auto=format&fit=crop&w=700&q=88",
  "https://images.unsplash.com/photo-1519682337058-a94d519337bc?auto=format&fit=crop&w=700&q=88"
];
const B = (id, title, author, genre, price, status, isbn, summary, extract, imageIndex = 0) =>
  ({ id, title, author, genre, price, status, isbn, summary, extract, cover: REAL_COVERS[imageIndex % REAL_COVERS.length], hidden: false });

export const SAMPLE = {
  books: [
    B("ex-eclat", "L'Éclat des Mots", "Anya Sharma", "Roman", 18, "Disponible", "978-2-490000-01-1",
      "Une traductrice retrouve les carnets de sa mère et, avec eux, une langue qu'elle croyait perdue.",
      "Le premier carnet sentait le thé et la poussière. Maya l'ouvrit au hasard : une écriture serrée, penchée vers la droite, comme si chaque phrase avait peur d'arriver trop tard. Elle ne reconnut pas la langue. Elle reconnut pourtant la voix.", 0),
    B("ex-cendre", "Sous la Cendre", "Moussa Diallo", "Essai", 22, "Disponible", "978-2-490000-02-8",
      "Une enquête sur la mémoire des villes après l'incendie, de Valparaíso à Dakar.",
      "Une ville qui brûle ne perd pas seulement ses murs. Elle perd ses raccourcis, ses odeurs, l'endroit exact où l'on attendait quelqu'un. J'ai marché trois semaines dans des rues dont les habitants connaissaient encore le tracé par cœur.", 1),
    B("ex-marees", "Marées", "Lina Verhaeghe", "Poésie", 14, "Disponible", "978-2-490000-03-5",
      "Soixante poèmes écrits entre deux ports, au rythme des départs.",
      "Le quai garde la forme de nos pas / l'eau la reprend avant midi / il faut apprendre à partir / comme on apprend à se taire : / sans claquer la porte du ciel.", 2),
    B("ex-renard", "Le Renard et la Lune", "Anya Sharma", "Jeunesse", 12, "À paraître", "978-2-490000-04-2",
      "Un conte pour les 6-9 ans : un renard décide de rapporter la lune à son village.",
      "Chaque soir, le renard regardait la lune accrochée au-dessus de la colline. « Elle est trop belle pour rester là-haut toute seule », dit-il. Et il se mit en route avec un sac, une corde et beaucoup d'espoir.", 3),
    B("ex-fleuve", "Les Heures du Fleuve", "Ibrahim Keïta", "Roman", 20, "Disponible", "978-2-490000-05-9",
      "Trois générations d'une famille de pêcheurs face à la construction d'un barrage.",
      "Mon grand-père disait que le fleuve ne coule pas : il se souvient. Chaque crue était une phrase de plus dans un livre que seuls les vieux savaient lire. Le jour où les ingénieurs sont arrivés, personne n'a pensé à leur traduire.", 0),
    B("ex-lire", "Lire autrement", "Moussa Diallo", "Essai", 16, "En rupture", "978-2-490000-06-6",
      "Petit manifeste pour une lecture lente à l'ère du défilement.",
      "Lire lentement n'est pas un luxe, c'est une résistance minuscule. On s'arrête sur un mot, on le retourne, on le garde un peu pour soi. Personne ne mesure ce temps-là, et c'est précisément ce qui le rend précieux.", 1),
    B("ex-sel", "Le Sel des Jours", "Lina Verhaeghe", "Poésie", 15, "À paraître", "978-2-490000-07-3",
      "Le deuxième recueil de Lina Verhaeghe, tourné vers l'ordinaire.",
      "Aujourd'hui j'ai épluché une orange / en pensant à ta main / le zeste partait en spirale / comme une phrase qu'on n'ose finir.", 2),
    B("ex-nuit", "La Nuit des Bibliothèques", "Ibrahim Keïta", "Jeunesse", 13, "Disponible", "978-2-490000-08-0",
      "Une nuit, les livres d'une bibliothèque de quartier se mettent à parler.",
      "À minuit pile, le dictionnaire toussa. Puis l'atlas se déplia, et le petit livre de recettes, tout au fond du rayon, demanda qui avait laissé la lumière allumée.", 3),
  ],
  authors: [
    { id: "ex-anya", name: "Anya Sharma", photo: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=500&q=85", bio: "Romancière et traductrice, Anya Sharma écrit sur l'héritage des langues et la transmission entre générations. Son premier roman a été traduit en neuf langues." },
    { id: "ex-moussa", name: "Moussa Diallo", photo: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=500&q=85", bio: "Journaliste devenu essayiste, Moussa Diallo explore la mémoire des villes et la manière dont on y habite après la catastrophe." },
    { id: "ex-lina", name: "Lina Verhaeghe", photo: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=500&q=85", bio: "Poète, Lina Verhaeghe publie depuis 2015 des recueils nés de ses voyages. Elle anime des ateliers d'écriture en bibliothèque." },
    { id: "ex-ibrahim", name: "Ibrahim Keïta", photo: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=500&q=85", bio: "Ibrahim Keïta écrit pour les adultes comme pour les enfants. Ses récits suivent des familles ordinaires face aux grands changements." },
  ],
  news: [
    { id: "ex-n1", title: "Rentrée littéraire : trois titres à découvrir", date: "2026-09-04", image: "https://images.unsplash.com/photo-1521587760476-6c12a4b040da?auto=format&fit=crop&w=1000&q=85", text: "Cette saison, nous publions un roman, un essai et un recueil de poèmes. Retrouvez les extraits en ligne et les dates de rencontres en librairie." },
    { id: "ex-n2", title: "Rencontre avec Anya Sharma à la médiathèque", date: "2026-10-18", image: "https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=1000&q=85", text: "L'autrice de « L'Éclat des Mots » présentera son travail de traduction et lira des pages inédites. Entrée libre, dédicace à l'issue de la rencontre." },
    { id: "ex-n3", title: "Appel à manuscrits : poésie et premiers romans", date: "2026-11-02", image: "https://images.unsplash.com/photo-1455390582262-044cdead277a?auto=format&fit=crop&w=1000&q=85", text: "Le comité de lecture ouvre sa session d'automne. Envoyez-nous votre texte via l'espace écrivains avant le 30 novembre." },
  ],
  testimonials: [
    { id: "ex-t1", name: "Claire", role: "Lectrice", photo: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=85", text: "Un catalogue qui laisse de la place aux voix singulières et aux histoires qui restent longtemps." },
    { id: "ex-t2", name: "Marc", role: "Auteur publié", photo: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=85", text: "J’ai apprécié la clarté des échanges et l’attention portée au texte à chaque étape." },
    { id: "ex-t3", name: "Sophie", role: "Libraire partenaire", photo: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=85", text: "Des livres choisis avec curiosité, exigence et une vraie envie de transmettre." }
  ],
  faqs: [
    { id: "ex-f1", question: "Comment soumettre un manuscrit ?", answer: "Utilisez le formulaire de soumission et transmettez un lien vers votre fichier PDF ou Word." },
    { id: "ex-f2", question: "Quels sont les délais de réponse ?", answer: "Le délai indicatif est de six semaines. Il peut varier selon le nombre de projets reçus." },
    { id: "ex-f3", question: "Proposez-vous des contrats à compte d’éditeur ?", answer: "Les modalités dépendent du projet et de la ligne éditoriale. Toute proposition est présentée clairement à l’auteur." },
    { id: "ex-f4", question: "Comment commander nos livres en quantité ?", answer: "Les librairies, écoles et médiathèques peuvent utiliser l’espace partenaires pour demander un catalogue ou un devis." }
  ],
  agencies: [
    { id: "ex-a1", name: "Agence centrale", city: "Paris", address: "12 rue des Livres", phone: "+33 1 00 00 00 00", image: "https://images.unsplash.com/photo-1497366754035-f200968a6e72?auto=format&fit=crop&w=700&q=85" },
    { id: "ex-a2", name: "Agence Afrique", city: "Abidjan", address: "Cocody, Côte d’Ivoire", phone: "+225 00 00 00 00", image: "https://images.unsplash.com/photo-1521737711867-e3b97375f902?auto=format&fit=crop&w=700&q=85" }
  ],
  settings: [
    { id: "site", logoUrl: "", logoStyle: "horizontal", faviconUrl: "", footerStyle: "classic", footerName: "", footerTagline: "Édition indépendante, littérature et transmission.", footerLinksTitle: "Liens rapides", footerInfoTitle: "Informations", footerCopyright: "© 2026 — Tous droits réservés." }
  ],
  manuscripts: [
    { id: "ex-m1", name: "Camille Roux", email: "camille.roux@example.com", title: "Les Jardins de Fer", genre: "Roman", link: "https://drive.google.com/", synopsis: "Une ancienne ouvrière de fonderie raconte la fermeture de l'usine et la reconversion du site en jardin partagé." },
    { id: "ex-m2", name: "Yanis Benali", email: "yanis.benali@example.com", title: "Trente-six vues du périphérique", genre: "Poésie", link: "https://drive.google.com/", synopsis: "Un recueil de poèmes courts écrits depuis la fenêtre d'un bus de nuit." },
    { id: "ex-m3", name: "Hélène Dupré", email: "helene.dupre@example.com", title: "Ce que dit le sable", genre: "Jeunesse", link: "", synopsis: "Album pour enfants : une petite fille apprend à lire les traces laissées sur la plage." },
  ],
};
