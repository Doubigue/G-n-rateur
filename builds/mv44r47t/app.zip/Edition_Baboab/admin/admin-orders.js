// ============ Admin : achats, clients, palmarès et rapport ============
import { onAuth, watchOrders, updateOrder, sendInvoiceMessage, watchSiteSettings, grantBook } from "../shared/firebase-config.js";
import { friendly } from "../shared/errors.js";
import { ORDER_ST, MODE_LABEL, fmtF, orderMs, fdate, FORMAT_LABEL, FORMAT_ICON, fmtOf, isDigitalOnly, itemLabel, modeLabel } from "../shared/orders.js";
import { mountScan, initScan } from "./admin-scan.js";
import { saveBlob, setInvoiceSource } from "../shared/download.js";
import { buildInvoicePdf, uploadPdf, invoiceName, dlUrl, loadJsPdf, DEFAULT_BRAND, applyInvoiceSettings, T } from "../shared/invoice-pdf.js";

const $ = s => document.querySelector(s);
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const toast = t => { document.querySelector(".adm-toast")?.remove(); const d = Object.assign(document.createElement("div"), { className: "adm-toast", textContent: t, role: "status" }); document.body.append(d); setTimeout(() => d.remove(), 4200); };
let orders = [], brand = DEFAULT_BRAND, stop = null, stopSet = null, built = false;
const F = { period: "all", agency: "all", status: "all", q: "" }, openSet = new Set();
const PERIODS = [["all", "Toute la période"], ["today", "Aujourd'hui"], ["7", "7 derniers jours"], ["30", "30 derniers jours"], ["month", "Ce mois-ci"], ["year", "Cette année"]];
const periodLabel = () => ({ all: "Sur l'ensemble de la période", today: "Aujourd'hui", 7: "Sur les 7 derniers jours", 30: "Sur les 30 derniers jours", month: "Ce mois-ci", year: "Cette année" }[F.period]);

function inPeriod(o) {
  if (F.period === "all") return true;
  const t = orderMs(o), now = new Date(), day = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  if (F.period === "today") return t >= day;
  if (F.period === "7" || F.period === "30") return t >= day - (+F.period - 1) * 864e5;
  if (F.period === "month") return t >= new Date(now.getFullYear(), now.getMonth(), 1).getTime();
  return t >= new Date(now.getFullYear(), 0, 1).getTime();
}
const filtered = () => orders.filter(o => inPeriod(o) && (F.agency === "all" || (o.agencyId || o.agencyName) === F.agency) && (F.status === "all" || o.status === F.status)
  && (!F.q || `${o.invoice} ${o.name} ${o.surname} ${o.email} ${o.phone} ${o.agencyName} ${(o.items || []).map(i => i.title).join(" ")}`.toLowerCase().includes(F.q.toLowerCase())))
  .sort((a, b) => orderMs(b) - orderMs(a));

function stats(list) {
  const live = list.filter(o => o.status !== "cancelled"), paid = live.filter(o => o.status === "paid" || o.status === "delivered"), pend = live.filter(o => o.status === "pending");
  const sum = a => a.reduce((s, o) => s + (+o.total || 0), 0);
  const books = {}, auth = {}, cl = {}, ag = {}; let qty = 0;
  for (const o of live) {
    const cid = o.uid || o.email, c = cl[cid] ||= { name: `${o.name || ""} ${o.surname || ""}`.trim() || o.email, email: o.email, phone: o.phone, orders: 0, qty: 0, total: 0 };
    c.orders++; c.total += +o.total || 0;
    const a = ag[o.agencyId || o.agencyName || "?"] ||= { name: o.agencyName || "Non précisée", orders: 0, total: 0 }; a.orders++; a.total += +o.total || 0;
    for (const i of o.items || []) {
      const b = books[i.id || i.title] ||= { title: i.title, author: i.author || "Auteur non précisé", qty: 0, total: 0 };
      b.qty += i.qty; b.total += i.unit * i.qty;
      const au = auth[i.author || "Auteur non précisé"] ||= { name: i.author || "Auteur non précisé", qty: 0, total: 0 }; au.qty += i.qty; au.total += i.unit * i.qty;
      c.qty += i.qty; qty += i.qty;
    }
  }
  const top = (m, k = "qty") => Object.values(m).sort((a, b) => b[k] - a[k] || b.total - a.total);
  return { live, paid, pend, cancelled: list.length - live.length, revenue: sum(paid), due: sum(pend), all: sum(live), qty, avg: live.length ? sum(live) / live.length : 0, books: top(books), authors: top(auth), clients: top(cl, "orders"), agencies: top(ag, "orders") };
}
function narrative(s) {
  if (!s.live.length) return `${periodLabel()}, aucun achat n'a été enregistré.`;
  const b = s.books[0], a = s.authors[0], c = s.clients[0], g = s.agencies[0], pl = (n, w) => `${n} ${w}${n > 1 ? "s" : ""}`;
  return `${periodLabel()}, ${pl(s.live.length, "commande")} ont été passées par ${pl(s.clients.length, "client")}, pour ${pl(s.qty, "livre")} et un montant total de ${fmtF(s.all)}. ` +
    `${pl(s.paid.length, "commande")} ${s.paid.length > 1 ? "sont payées" : "est payée"} (${fmtF(s.revenue)} encaissés) et ${pl(s.pend.length, "commande")} ${s.pend.length > 1 ? "attendent" : "attend"} leur règlement (${fmtF(s.due)} à encaisser). ` +
    `Le livre le plus acheté est « ${b.title} » (${pl(b.qty, "exemplaire")}). L'auteur le plus acheté est ${a.name} (${pl(a.qty, "livre")} vendus). ` +
    `Le meilleur client est ${c.name} : ${pl(c.orders, "achat")} pour ${fmtF(c.total)}. L'agence la plus choisie est ${g.name} (${pl(g.orders, "commande")}).` +
    (s.cancelled ? ` ${pl(s.cancelled, "commande")} ${s.cancelled > 1 ? "ont été annulées" : "a été annulée"}.` : "");
}

// ---------- Interface ----------
function build() {
  const root = $("#orders-root"); if (!root || built) return; built = true;
  root.innerHTML = `
  <div class="card" data-s="list">
    <div class="flex flex-wrap items-start justify-between gap-3"><div><h2 class="serif text-2xl">Liste des achats</h2><p class="text-sm text-stone-500 mt-1">Paiement à la remise : confirmez l'encaissement pour tamponner la facture « PAYÉE » et l'envoyer au client.</p></div>
    <div class="flex gap-2 flex-wrap"><button id="o-pdf" class="btn btn-dark text-sm" type="button">📄 Rapport PDF</button><button id="o-csv" class="btn btn-light text-sm" type="button">⬇ Export Excel (CSV)</button></div></div>
    <div class="grid sm:grid-cols-2 lg:grid-cols-4 gap-2 mt-4">
      <select id="o-period" class="input">${PERIODS.map(([k, n]) => `<option value="${k}">${n}</option>`).join("")}</select>
      <select id="o-agency" class="input"><option value="all">Toutes les agences</option></select>
      <select id="o-status" class="input"><option value="all">Tous les statuts</option>${Object.entries(ORDER_ST).map(([k, v]) => `<option value="${k}">${v[0]}</option>`).join("")}</select>
      <input id="o-q" class="input" type="search" placeholder="Client, facture, livre…">
    </div>
  </div>
  <div id="o-dyn" class="mt-4 grid gap-4"><div data-s="scan" id="o-scan"></div><div data-s="dash" id="o-dash" class="grid gap-4"></div><div data-s="clients" id="o-clients"></div><div data-s="search" id="o-search"></div><div data-s="list" id="o-list"></div></div>`;
  $("#o-period").onchange = e => { F.period = e.target.value; draw(); };
  $("#o-agency").onchange = e => { F.agency = e.target.value; draw(); };
  $("#o-status").onchange = e => { F.status = e.target.value; draw(); };
  $("#o-q").oninput = e => { F.q = e.target.value.trim(); draw(); };
  $("#o-csv").onclick = exportCsv; $("#o-pdf").onclick = exportPdf;
  $("#o-dyn").addEventListener("click", onAction); $("#o-dyn").addEventListener("input", e => { if (e.target.id === "o-sq") { SQ = e.target.value.trim(); drawSearch(true); } });
  mountScan($("#o-scan")); setTimeout(() => window.EDM_applySub?.(), 0);
  $("#o-dyn").addEventListener("toggle", e => { const d = e.target.closest?.("[data-oid]"); if (d) d.open ? openSet.add(d.dataset.oid) : openSet.delete(d.dataset.oid); }, true);
}
const bar = (v, max, col = "#d4af37") => `<div class="h-2 rounded bg-stone-100 mt-1"><div class="h-2 rounded" style="width:${max ? Math.max(3, v / max * 100) : 0}%;background:${col}"></div></div>`;
const kpi = (l, v, sub = "") => `<div class="card"><p class="text-xs uppercase tracking-wider text-stone-500">${l}</p><strong class="serif text-2xl block mt-1">${v}</strong>${sub ? `<p class="text-xs text-stone-500 mt-1">${sub}</p>` : ""}</div>`;
const star = (ico, l, main, sub) => `<div class="card" style="background:linear-gradient(150deg,#10281e,#1d4332);color:#f6efdc;border-color:#10281e"><p class="text-[11px] uppercase tracking-[.14em]" style="color:#e8cb6a">${ico} ${l}</p><strong class="serif text-xl block mt-2 leading-snug">${esc(main)}</strong><p class="text-xs mt-1 opacity-80">${esc(sub)}</p></div>`;
const rankList = (title, rows, unit) => `<div class="card"><h3 class="serif text-xl">${title}</h3>${rows.length ? `<ol class="mt-3 grid gap-3">${rows.slice(0, 5).map((r, i) => `<li><div class="flex justify-between gap-3 text-sm"><span class="truncate"><b class="text-[#8b6a32]">${i + 1}.</b> ${esc(r.name || r.title)}${r.author ? ` <span class="text-stone-400">· ${esc(r.author)}</span>` : ""}</span><b class="whitespace-nowrap">${r[unit]} ${unit === "qty" ? "ex." : "achat" + (r[unit] > 1 ? "s" : "")}</b></div>${bar(r[unit], rows[0][unit])}</li>`).join("")}</ol>` : `<p class="text-sm text-stone-500 mt-3">Aucune donnée.</p>`}</div>`;

function draw() {
  if (!built) return;
  // agences dans le filtre
  const ags = [...new Map(orders.map(o => [o.agencyId || o.agencyName, o.agencyName || "Non précisée"])).entries()].filter(([k]) => k);
  const sel = $("#o-agency"); if (sel && sel.options.length - 1 !== ags.length) { sel.innerHTML = `<option value="all">Toutes les agences</option>` + ags.map(([k, n]) => `<option value="${esc(k)}">${esc(n)}</option>`).join(""); sel.value = F.agency; }
  const list = filtered(), s = stats(list), pend = orders.filter(o => o.status === "pending").length;
  const bd = $("#ord-badge"); if (bd) { bd.textContent = pend; bd.classList.toggle("show", pend > 0); }
  $("#o-dash").innerHTML = `<div class="card" style="border-left:5px solid #d4af37"><p class="text-xs uppercase tracking-wider text-[#8b6a32] font-bold">Rapport en clair</p><p class="mt-2 leading-relaxed">${esc(narrative(s))}</p></div>
  <div class="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3">
    ${kpi("Achats", s.live.length, s.cancelled ? `${s.cancelled} annulée(s)` : "commandes valides")}
    ${kpi("Clients", s.clients.length, "acheteurs distincts")}
    ${kpi("Livres vendus", s.qty, "exemplaires")}
    ${kpi("Encaissé", fmtF(s.revenue), `${s.paid.length} payée(s)`)}
    ${kpi("À encaisser", fmtF(s.due), `${s.pend.length} en attente`)}
    ${kpi("Panier moyen", fmtF(s.avg), "par commande")}
  </div>
  <div class="grid sm:grid-cols-2 xl:grid-cols-4 gap-3">
    ${star("📖", "Livre le plus acheté", s.books[0]?.title || "—", s.books[0] ? `${s.books[0].qty} exemplaire(s) · ${s.books[0].author}` : "Aucune vente")}
    ${star("✍️", "Auteur le plus acheté", s.authors[0]?.name || "—", s.authors[0] ? `${s.authors[0].qty} livre(s) · ${fmtF(s.authors[0].total)}` : "Aucune vente")}
    ${star("👑", "Meilleur client", s.clients[0]?.name || "—", s.clients[0] ? `${s.clients[0].orders} achat(s) · ${fmtF(s.clients[0].total)}` : "Aucun achat")}
    ${star("📍", "Agence la plus choisie", s.agencies[0]?.name || "—", s.agencies[0] ? `${s.agencies[0].orders} commande(s) · ${fmtF(s.agencies[0].total)}` : "Aucune commande")}
  </div>
  <div class="grid lg:grid-cols-2 gap-3">${rankList("Top livres", s.books, "qty")}${rankList("Top auteurs", s.authors, "qty")}${rankList("Clients : nombre d'achats", s.clients, "orders")}${rankList("Agences", s.agencies, "orders")}</div>
`;
  $("#o-clients").innerHTML = `<div class="card"><h3 class="serif text-xl">Clients <span class="text-sm text-stone-400">(${s.clients.length})</span></h3><div class="overflow-x-auto mt-3"><table class="w-full text-sm min-w-[560px]"><thead class="text-left text-xs uppercase text-stone-500"><tr><th class="py-2">Client</th><th>Contact</th><th class="text-right">Achats</th><th class="text-right">Livres</th><th class="text-right">Montant</th></tr></thead><tbody>${s.clients.map(c => `<tr class="border-t"><td class="py-2 font-semibold">${esc(c.name)}</td><td class="text-stone-500">${esc(c.email || "")}<br>${esc(c.phone || "")}</td><td class="text-right">${c.orders}</td><td class="text-right">${c.qty}</td><td class="text-right font-semibold">${fmtF(c.total)}</td></tr>`).join("") || `<tr><td colspan="5" class="py-4 text-stone-500">Aucun client.</td></tr>`}</tbody></table></div></div>`;
  $("#o-list").innerHTML = `<div><h3 class="serif text-2xl mb-3">Liste des achats <span class="text-sm text-stone-400">(${list.length})</span></h3><div class="grid gap-3">${list.map(row).join("") || `<div class="card text-stone-500">Aucun achat ne correspond aux filtres.</div>`}</div></div>`;
  drawSearch(); drawDash(list, s); window.dispatchEvent(new Event("edm-orders"));
}
// ---------- Recherche (nom ou n° de facture) ----------
let SQ = "";
function drawSearch(keepInput) {
  const root = $("#o-search"); if (!root) return;
  if (!keepInput || !$("#o-sq")) root.innerHTML = `<div class="card"><h2 class="serif text-2xl">Recherche</h2><div class="flex gap-2 mt-3"><input id="o-sq" class="input" type="search" placeholder="Nom du client ou n° de facture" value="${esc(SQ)}" autocomplete="off"><button type="button" class="btn btn-gold" data-scan-open aria-label="Scanner">📷</button></div></div><div id="o-sres" class="grid gap-3 mt-3"></div>`;
  const q = SQ.toLowerCase(), res = q ? orders.filter(o => `${o.invoice} ${o.name} ${o.surname} ${o.email} ${o.phone}`.toLowerCase().includes(q)).sort((a, b) => orderMs(b) - orderMs(a)) : [];
  $("#o-sres").innerHTML = q ? (res.map(row).join("") || `<div class="card text-stone-500">Aucun résultat pour « ${esc(SQ)} ».</div>`) : `<p class="text-sm text-stone-500 px-1">Tapez un nom ou un numéro de facture, ou scannez le QR de la facture.</p>`;
}
// ---------- Tableau de bord (onglet Dashboard) ----------
function drawDash() {
  const r = $("#dash-root"); if (!r) return;
  const live = orders.filter(o => o.status !== "cancelled"), paid = live.filter(o => o.status === "paid" || o.status === "delivered"), pend = live.filter(o => o.status === "pending");
  const sum = a => a.reduce((t, o) => t + (+o.total || 0), 0), day0 = new Date().setHours(0, 0, 0, 0);
  const days = [...Array(7)].map((_, i) => { const t = day0 - (6 - i) * 864e5; return { t, v: sum(live.filter(o => orderMs(o) >= t && orderMs(o) < t + 864e5)) }; });
  const mx = Math.max(1, ...days.map(d => d.v)), wk = days.reduce((t, d) => t + d.v, 0), prev = sum(live.filter(o => orderMs(o) >= day0 - 13 * 864e5 && orderMs(o) < day0 - 6 * 864e5));
  const trend = prev ? Math.round((wk - prev) / prev * 100) : null, DN = ["D", "L", "M", "M", "J", "V", "S"];
  const bars = days.map((d, i) => { const h = Math.max(4, d.v / mx * 100), x = 14 + i * 44; return `<rect x="${x}" y="${120 - h}" width="28" height="${h}" rx="8" fill="${i === 6 ? "url(#g)" : "#2f5a45"}" opacity="${i === 6 ? 1 : .75}"/><text x="${x + 14}" y="138" text-anchor="middle" font-size="10" fill="#a8b8ae">${DN[new Date(d.t).getDay()]}</text>`; }).join("");
  const sc = (ico, l, v, sub, tone = "") => `<div class="dcard ${tone}"><span class="dico">${ico}</span><p>${l}</p><b>${v}</b><small>${sub}</small></div>`;
  const recent = [...orders].sort((a, b) => orderMs(b) - orderMs(a)).slice(0, 5);
  const st = stats(orders), tb = st.books.slice(0, 3);
  r.innerHTML = `
  <div class="dhero"><div><p class="dsmall">${new Date().toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long" })}</p><h2 class="serif">Tableau de bord</h2><p class="dsmall">Encaissé cette semaine</p><strong class="dbig">${fmtF(wk)}</strong>${trend === null ? "" : `<span class="dtrend ${trend < 0 ? "dn" : ""}">${trend < 0 ? "▼" : "▲"} ${Math.abs(trend)} % vs semaine préc.</span>`}</div>
   <svg viewBox="0 0 320 146" class="dchart" role="img" aria-label="Ventes des 7 derniers jours"><defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f0d77a"/><stop offset="1" stop-color="#b58a22"/></linearGradient></defs>${bars}</svg></div>
  <div class="hscroll">
   ${sc("💰", "Encaissé", fmtF(sum(paid)), `${paid.length} facture(s) payée(s)`, "gold")}${sc("⏳", "À encaisser", fmtF(sum(pend)), `${pend.length} en attente`)}${sc("🧾", "Achats", live.length, `${st.clients.length} client(s)`)}${sc("📖", "Livres vendus", st.qty, "exemplaires")}${sc("🛒", "Panier moyen", fmtF(st.avg), "par commande")}
  </div>
  <div class="grid lg:grid-cols-2 gap-4">
   <div class="card"><div class="flex justify-between items-center"><h3 class="serif text-xl">Derniers achats</h3><button class="pill" data-goto="orders:list">Tout voir</button></div>${recent.length ? recent.map(o => { const s2 = ORDER_ST[o.status] || [o.status, ""]; return `<button type="button" class="drow" data-open-inv="${esc(o.invoice)}"><span class="dot">${esc((o.name || "?")[0].toUpperCase())}</span><span class="min-w-0 flex-1 text-left"><b class="block truncate">${esc(`${o.name || ""} ${o.surname || ""}`.trim() || o.email)}</b><small class="text-stone-500">${esc(o.invoice)} · ${fdate(orderMs(o))}</small></span><span class="text-right"><b class="block text-sm">${fmtF(o.total)}</b><span class="chip ${s2[1]}">${esc(s2[0])}</span></span></button>`; }).join("") : `<p class="text-sm text-stone-500 mt-3">Aucun achat pour l'instant.</p>`}</div>
   <div class="card"><h3 class="serif text-xl">Livres les plus vendus</h3>${tb.length ? tb.map((b, i) => `<div class="mt-3"><div class="flex justify-between gap-2 text-sm"><span class="truncate"><b class="text-[#8b6a32]">${i + 1}.</b> ${esc(b.title)}</span><b>${b.qty} ex.</b></div>${bar(b.qty, tb[0].qty)}</div>`).join("") : `<p class="text-sm text-stone-500 mt-3">Aucune vente.</p>`}</div>
  </div>`;
}

function row(o) {
  const st = ORDER_ST[o.status] || [o.status, ""], dig = isDigitalOnly(o), del = !dig && o.mode === "delivery";
  return `<details class="card" data-oid="${esc(o.id)}" ${openSet.has(o.id) ? "open" : ""}>
  <summary class="cursor-pointer list-none flex flex-wrap items-center justify-between gap-2"><div class="min-w-0"><b class="serif text-lg">${esc(o.invoice)}</b> <span class="text-xs text-stone-500">· ${fdate(orderMs(o), true)}</span><p class="text-sm text-stone-600 truncate">${esc(`${o.name || ""} ${o.surname || ""}`.trim())} · ${esc(o.agencyName || "—")} · ${esc(modeLabel(o))}</p></div><div class="flex items-center gap-2"><b>${fmtF(o.total)}</b><span class="chip ${st[1]}">${esc(st[0])}</span></div></summary>
  <div class="mt-4 grid md:grid-cols-2 gap-4 text-sm">
    <div><p class="text-xs uppercase font-bold text-[#8b6a32]">Client</p><p>${esc(`${o.name || ""} ${o.surname || ""}`)}<br>${esc(o.email || "")}<br>${esc(o.phone || "")}${del ? `<br>📦 ${esc(o.address || "")} ${esc(o.city || "")}` : ""}</p>
    <p class="text-xs uppercase font-bold text-[#8b6a32] mt-3">${dig ? "Règlement à" : del ? "Livraison depuis" : "Retrait à"}</p><p>${esc(o.agencyName || "")}<br>${esc([o.agencyAddress, o.agencyCity].filter(Boolean).join(", "))}</p></div>
    <div><p class="text-xs uppercase font-bold text-[#8b6a32]">Livres</p><ul>${(o.items || []).map(i => `<li class="flex justify-between gap-2 py-0.5"><span>${esc(i.title)} <span class="pill">${FORMAT_ICON[fmtOf(i)]} ${FORMAT_LABEL[fmtOf(i)]}</span> <span class="text-stone-400">× ${i.qty}</span></span><b>${fmtF(i.unit * i.qty)}</b></li>`).join("")}</ul>
    <p class="text-xs uppercase font-bold text-[#8b6a32] mt-3">Traces</p><ul class="text-xs text-stone-600">${(o.history || []).map(h => `<li>• ${fdate(h.at, true)} — ${esc((ORDER_ST[h.s] || [h.s])[0])} <span class="text-stone-400">(${h.by === "admin" ? "admin" : "client"})</span></li>`).join("") || "<li>—</li>"}</ul></div>
  </div>
  <div class="flex flex-wrap gap-2 mt-4">
    ${o.status === "pending" ? `<button class="btn btn-gold text-sm" data-act="pay" data-id="${esc(o.id)}">💵 Confirmer le paiement</button><button class="btn btn-light btn-danger text-sm" data-act="cancel" data-id="${esc(o.id)}">Annuler</button>` : ""}
    ${o.status === "paid" && !dig ? `<button class="btn btn-dark text-sm" data-act="deliver" data-id="${esc(o.id)}">📦 Marquer ${del ? "livrée" : "remise en agence"}</button>` : ""}
    ${o.status !== "cancelled" ? `<a class="btn btn-light text-sm" href="#" data-inv="${esc(o.id)}">Facture PDF</a>` : ""}
    ${o.status === "paid" || o.status === "delivered" ? `<a class="btn btn-light text-sm" href="#" data-inv="${esc(o.id)}" data-paid="1">Facture PAYÉE</a>` : ""}
    ${o.status !== "cancelled" && (o.status === "pending" ? !o.invoiceUrl : (o.status !== "pending" && !o.invoicePaidUrl)) ? `<button class="btn btn-light text-sm" data-act="regen" data-id="${esc(o.id)}">🔁 Régénérer la facture</button>` : ""}
  </div></details>`;
}

setInvoiceSource(id => orders.find(x => x.id === id), () => brand);
// ---------- Actions ----------
async function makePdf(o, paid, paidAt) {
  const blob = await buildInvoicePdf({ ...o, paidAt }, { paid, brand });
  return uploadPdf(blob, invoiceName(o, paid) + (o.__v ? "-" + o.__v : ""));
}
async function onAction(e) {
  const b = e.target.closest("[data-act]"); if (!b) return; e.preventDefault();
  const o = orders.find(x => x.id === b.dataset.id); if (!o) return;
  return runAct(o, b.dataset.act, b);
}
async function runAct(o, act, b) {
  b ||= {}; const label = b.textContent; b.disabled = true; let ok = false;
  try {
    if (act === "pay") {
      if (!confirm(`Confirmer l'encaissement de ${fmtF(o.total)} pour ${o.invoice} ?\nLa facture PAYÉE (tampon + cachet) sera créée et envoyée au client.`)) return;
      b.textContent = "Création de la facture…"; const paidAt = Date.now(); let url = "";
      try { url = await makePdf({ ...o, __v: "" }, true, paidAt); } catch (err) { toast("Facture PAYÉE non envoyée : " + err.message + " — utilisez « Régénérer »."); }
      await updateOrder(o.id, { status: "paid", paidAt, invoicePaidUrl: url }, { s: "paid" });
      // E-books achetés : accès à la liseuse accordé automatiquement dans « Ma bibliothèque » du client
      const eb = (o.items || []).filter(i => fmtOf(i) === "ebook" && i.id);
      let unlocked = 0;
      if (o.uid) for (const i of eb) { try { await grantBook(o.uid, i.id, i.title); unlocked++; } catch (err) { toast("E-book « " + i.title + " » non débloqué : " + friendly(err) + " — utilisez « Donner accès » dans Comptes."); } }
      if (o.uid) await sendInvoiceMessage(o.uid, `✅ Paiement reçu pour votre commande ${o.invoice} : ${fmtF(o.total)}. Merci !\n${url ? "Votre facture PAYÉE (avec tampon et cachet) est disponible ci-dessous." : "Votre facture payée vous sera transmise prochainement."}${unlocked ? `\n📖 ${unlocked > 1 ? "Vos e-books sont débloqués" : "Votre e-book est débloqué"} : retrouvez-${unlocked > 1 ? "les" : "le"} dans « Mon espace › Ma bibliothèque ».` : ""}`, { kind: "invoice", orderId: o.id, invoiceNo: o.invoice, invoiceUrl: url });
      toast(unlocked ? `Paiement confirmé ✓ facture envoyée · ${unlocked} e-book(s) débloqué(s)` : "Paiement confirmé ✓ facture envoyée au client");
    } else if (act === "deliver") {
      await updateOrder(o.id, { status: "delivered", deliveredAt: Date.now() }, { s: "delivered" });
      if (o.uid) await sendInvoiceMessage(o.uid, `📦 Votre commande ${o.invoice} a été ${o.mode === "delivery" ? "livrée" : "remise en agence"}. Merci pour votre confiance !`, { kind: "order", orderId: o.id });
      toast("Commande marquée comme remise ✓");
    } else if (act === "cancel") {
      const why = prompt(`Annuler la commande ${o.invoice} ?\nMotif (affiché au client, facultatif) :`); if (why === null) return;
      await updateOrder(o.id, { status: "cancelled", cancelNote: why }, { s: "cancelled" });
      if (o.uid) await sendInvoiceMessage(o.uid, `⛔ Votre commande ${o.invoice} a été annulée.${why ? "\nMotif : " + why : ""}`, { kind: "order", orderId: o.id });
      toast("Commande annulée");
    } else if (act === "regen") {
      b.textContent = "Création…"; const paid = o.status !== "pending";
      const url = await makePdf({ ...o, __v: Date.now().toString(36) }, paid, o.paidAt || Date.now());
      await updateOrder(o.id, paid ? { invoicePaidUrl: url } : { invoiceUrl: url });
      if (o.uid) await sendInvoiceMessage(o.uid, `🧾 Votre facture ${o.invoice}${paid ? " (payée)" : ""} est disponible.`, { kind: "invoice", orderId: o.id, invoiceNo: o.invoice, invoiceUrl: url });
      toast("Facture générée et envoyée ✓");
    }
    ok = true;
  } catch (err) { alert("Action impossible : " + friendly(err)); }
  finally { b.disabled = false; b.textContent = label; }
  return ok;
}

// ---------- Exports ----------
function exportCsv() {
  const list = filtered(), q = v => `"${String(v ?? "").replace(/"/g, '""')}"`;
  const head = ["Facture", "Date", "Client", "Email", "Téléphone", "Agence", "Mode", "Livres (format)", "Quantité", "Total (F CFA)", "Statut"];
  const rows = list.map(o => [o.invoice, fdate(orderMs(o), true), `${o.name || ""} ${o.surname || ""}`.trim(), o.email, o.phone, o.agencyName, modeLabel(o), (o.items || []).map(i => `${itemLabel(i)} x${i.qty}`).join(" | "), (o.items || []).reduce((s, i) => s + i.qty, 0), Math.round(o.total), (ORDER_ST[o.status] || [o.status])[0]]);
  const csv = "\ufeff" + [head, ...rows].map(r => r.map(q).join(";")).join("\r\n");
  saveBlob(new Blob([csv], { type: "text/csv;charset=utf-8" }), `achats-${new Date().toISOString().slice(0, 10)}.csv`);
}
async function exportPdf() {
  const b = $("#o-pdf"); b.disabled = true;
  try {
    const J = await loadJsPdf(), list = filtered(), s = stats(list), doc = new J({ unit: "mm", format: "a4", compress: true }), W = 210, H = 297, M = 16;
    let y = 0, page = 1;
    const font = (st, sz, c = [23, 32, 27]) => { doc.setFont("helvetica", st); doc.setFontSize(sz); doc.setTextColor(...c); }, tx = (t, x, yy, o = {}) => doc.text(T(t), x, yy, o);
    const head = () => { doc.setFillColor(16, 40, 30); doc.rect(0, 0, W, 5, "F"); doc.setFillColor(176, 139, 46); doc.rect(0, 5, W, .9, "F"); };
    const foot = () => { font("normal", 7.5, [117, 111, 103]); tx(`${brand} - Rapport des achats - ${fdate(Date.now(), true)}`, M, H - 8); tx(`Page ${page}`, W - M, H - 8, { align: "right" }); };
    const need = n => { if (y + n > H - 16) { foot(); doc.addPage(); page++; head(); y = 18; } };
    head(); font("bold", 20, [16, 40, 30]); tx("Rapport des achats", M, 20); font("normal", 10, [117, 111, 103]); tx(`${brand}  |  ${periodLabel()}${F.agency !== "all" ? "  |  Agence filtrée" : ""}${F.status !== "all" ? "  |  " + ORDER_ST[F.status][0] : ""}`, M, 26.5);
    y = 36; font("bold", 8, [176, 139, 46]); tx("EN CLAIR", M, y); y += 5; font("normal", 10.5); doc.splitTextToSize(T(narrative(s)), W - 2 * M).forEach(l => { tx(l, M, y); y += 5.2; });
    y += 4; const k = [["Achats", s.live.length], ["Clients", s.clients.length], ["Livres vendus", s.qty], ["Encaissé", fmtF(s.revenue)], ["À encaisser", fmtF(s.due)], ["Panier moyen", fmtF(s.avg)]];
    k.forEach(([l, v], i) => { const x = M + (i % 3) * 60, yy = y + Math.floor(i / 3) * 17; doc.setFillColor(246, 240, 224); doc.roundedRect(x, yy, 56, 14, 2, 2, "F"); font("normal", 7.5, [117, 111, 103]); tx(l.toUpperCase(), x + 3, yy + 5); font("bold", 11, [16, 40, 30]); tx(String(v), x + 3, yy + 11); });
    y += 40;
    const table = (title, cols, rows) => { need(18); font("bold", 12, [16, 40, 30]); tx(title, M, y); y += 5; font("bold", 7.5, [117, 111, 103]); cols.forEach(c => tx(c.h.toUpperCase(), c.r ? c.x : c.x, y, { align: c.r ? "right" : "left" })); doc.setDrawColor(226, 220, 208); doc.line(M, y + 1.6, W - M, y + 1.6); y += 5.6;
      if (!rows.length) { font("normal", 9, [117, 111, 103]); tx("Aucune donnée.", M, y); y += 7; return; }
      rows.forEach(r => { need(7); font("normal", 9); cols.forEach((c, i) => { const v = T(r[i]); tx(c.w ? doc.splitTextToSize(v, c.w)[0] : v, c.x, y, { align: c.r ? "right" : "left" }); }); y += 5.6; }); y += 5; };
    table("Top livres", [{ h: "Livre", x: M, w: 90 }, { h: "Auteur", x: M + 94, w: 50 }, { h: "Qté", x: W - M - 28, r: 1 }, { h: "Montant", x: W - M, r: 1 }], s.books.slice(0, 10).map(b => [b.title, b.author, b.qty, fmtF(b.total)]));
    table("Top auteurs", [{ h: "Auteur", x: M, w: 110 }, { h: "Livres vendus", x: W - M - 28, r: 1 }, { h: "Montant", x: W - M, r: 1 }], s.authors.slice(0, 10).map(a => [a.name, a.qty, fmtF(a.total)]));
    table("Clients", [{ h: "Client", x: M, w: 60 }, { h: "Contact", x: M + 64, w: 62 }, { h: "Achats", x: W - M - 40, r: 1 }, { h: "Montant", x: W - M, r: 1 }], s.clients.slice(0, 15).map(c => [c.name, c.email || c.phone || "", c.orders, fmtF(c.total)]));
    table("Agences", [{ h: "Agence", x: M, w: 100 }, { h: "Commandes", x: W - M - 40, r: 1 }, { h: "Montant", x: W - M, r: 1 }], s.agencies.map(a => [a.name, a.orders, fmtF(a.total)]));
    table("Détail des achats", [{ h: "Facture", x: M, w: 34 }, { h: "Date", x: M + 36 }, { h: "Client", x: M + 58, w: 44 }, { h: "Agence", x: M + 104, w: 32 }, { h: "Statut", x: M + 138, w: 20 }, { h: "Total", x: W - M, r: 1 }], list.map(o => [o.invoice, fdate(orderMs(o)), `${o.name || ""} ${o.surname || ""}`.trim(), o.agencyName || "", (ORDER_ST[o.status] || [o.status])[0].split(" ")[0], fmtF(o.total)]));
    foot(); await saveBlob(doc.output("blob"), `rapport-achats-${new Date().toISOString().slice(0, 10)}.pdf`);
  } catch (err) { alert("Rapport impossible : " + err.message); }
  b.disabled = false;
}

onAuth(u => {
  stop && stop(); stopSet && stopSet(); stop = stopSet = null;
  if (!u) return; build();
  stop = watchOrders(l => { orders = l || []; draw(); }, err => { const r = $("#orders-root"); if (r) r.insertAdjacentHTML("afterbegin", `<div class="card text-stone-600 text-sm">Les achats ne peuvent pas être chargés pour le moment. ${esc(friendly(err, "Réessayez dans un instant."))}</div>`); });
  stopSet = watchSiteSettings(s => { applyInvoiceSettings(s || {}); window.__edmLogo = s?.logoUrl || ""; window.dispatchEvent(new Event("edm-logo")); brand = s?.footerName || DEFAULT_BRAND; });
});

initScan({ getOrders: () => orders, act: runAct, toast, fmtF, esc, ORDER_ST, MODE_LABEL, fdate, orderMs });
mountScan(document.querySelector("#home-scan"));
