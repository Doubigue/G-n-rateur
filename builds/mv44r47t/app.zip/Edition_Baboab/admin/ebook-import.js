// ============ Import automatique d'un e-book ============
// L'administrateur importe UN fichier (EPUB, PDF, Word .docx, TXT, Markdown, HTML) dans la fiche du livre.
// Le texte et les chapitres sont extraits ici, dans le navigateur, puis enregistrés ; le lecteur les affiche tels quels.
// Aucun copier-coller : parseEbookFile(file) → { chapters: [{ title, text }], words }
//
// Format du texte d'un chapitre : paragraphes séparés par une ligne vide ; une ligne commençant par « # » = intertitre.

const CDN = {
  jszip: "https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js",
  pdf: "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js",
  worker: "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js"
};
const MAX_MB = 40, MAX_CHARS_PER_DOC = 100000, CHUNK_WORDS = 4500;

// ---------- Chargement des bibliothèques (à la demande) ----------
const loaded = {};
const loadScript = url => loaded[url] ||= new Promise((res, rej) => {
  const s = document.createElement("script"); s.src = url; s.onload = res;
  s.onerror = () => { delete loaded[url]; rej(new Error("Le module de lecture n'a pas pu être chargé. Vérifiez votre connexion internet.")); };
  document.head.append(s);
});
const getZip = async () => { if (!globalThis.JSZip) await loadScript(CDN.jszip); return globalThis.JSZip; };
const getPdf = async () => {
  if (!globalThis.pdfjsLib) await loadScript(CDN.pdf);
  const lib = globalThis.pdfjsLib;
  if (lib.GlobalWorkerOptions && !lib.GlobalWorkerOptions.workerSrc) lib.GlobalWorkerOptions.workerSrc = CDN.worker;
  return lib;
};

// ---------- Outils texte ----------
const words = t => (String(t).match(/\S+/g) || []).length;
const squash = t => String(t).replace(/[\s\u00a0]+/g, " ").trim();
const NUMW = "(?:\\d+|[ivxlcdm]+|premier|première|premiere|deuxième|deuxieme|second|seconde|troisième|troisieme|un|une|deux|trois|quatre|cinq|six|sept|huit|neuf|dix|onze|douze|one|two|three|four|five|seven|eight|nine|ten|first|third)";
const CH_NUM = new RegExp("^(chapitre|chapter|partie|part|livre|book|acte|tome|section)\\s+" + NUMW + "(?![\\p{L}])", "iu");
const CH_WORD = /^(prologue|épilogue|epilogue|préface|preface|avant-propos|introduction|conclusion|remerciements|postface|interlude|dédicace|note de l'auteur|note de l’auteur)(?![\p{L}])/iu;
const NUM_RE = /^(?:\d{1,3}|[IVXLC]{1,7})[.)]?$/;
/** Une ligne courte et isolée qui ressemble à un titre de chapitre. */
const looksLikeHeading = (t, allowBareNumber) => {
  t = t.trim();
  if (!t || t.length >= 80) return false;
  if (allowBareNumber && NUM_RE.test(t)) return true;
  if (CH_NUM.test(t)) return !/[;,]$/.test(t);
  if (CH_WORD.test(t)) return t.length < 50 && !/[,;]/.test(t) && !/\.\s+\S/.test(t);
  return false;
};

/** Découpe un texte brut en blocs {t:"p"|"h", level, text}. */
function textToBlocks(raw, { allowBareNumber = true } = {}) {
  let text = raw.replace(/^\ufeff/, "").replace(/\r\n?/g, "\n");
  const blank = (text.match(/\n\s*\n/g) || []).length, lines = text.split("\n").filter(l => l.trim()).length;
  // Fichier sans lignes vides : chaque ligne est un paragraphe
  if (lines > 20 && blank < lines / 12) text = text.split("\n").map(l => l.trim()).filter(Boolean).join("\n\n");
  const blocks = [];
  for (const para of text.split(/\n\s*\n/)) {
    const t = para.trim(); if (!t) continue;
    const md = t.match(/^(#{1,6})\s+(.+)$/);
    if (md && !t.includes("\n")) { blocks.push({ t: "h", level: md[1].length, text: squash(md[2]) }); continue; }
    const one = squash(t);
    if (!t.includes("\n") && looksLikeHeading(one, allowBareNumber)) { blocks.push({ t: "h", level: 1, text: one }); continue; }
    blocks.push({ t: "p", text: t.split("\n").map(squash).filter(Boolean).join(" ") });
  }
  return blocks;
}

/** Blocs → chapitres. Découpe sur le niveau d'intertitre le plus haut ; à défaut, par tranches de lecture régulières. */
function blocksToChapters(blocks) {
  const hs = blocks.filter(b => b.t === "h");
  const lvl = hs.length ? Math.min(...hs.map(h => h.level)) : 0;
  const top = hs.filter(h => h.level === lvl).length;
  let chapters = [];
  if (top >= 2) {
    let cur = { title: "Début", parts: [] };
    for (const b of blocks) {
      if (b.t === "h" && b.level === lvl) { chapters.push(cur); cur = { title: b.text, parts: [] }; }
      else cur.parts.push(b.t === "h" ? "# " + b.text : b.text);
    }
    chapters.push(cur);
    chapters = chapters.map(c => ({ title: c.title, text: c.parts.join("\n\n") }))
      .filter((c, i) => !(i === 0 && c.title === "Début" && words(c.text) < 80));   // page de titre / dédicace vide : ignorée
  } else {
    chapters = chunk(blocks.map(b => b.t === "h" ? "# " + b.text : b.text));
  }
  return chapters;
}
function chunk(paras) {
  const out = []; let cur = [], w = 0;
  for (const p of paras) {
    cur.push(p); w += words(p);
    if (w >= CHUNK_WORDS) { out.push({ title: `Partie ${out.length + 1}`, text: cur.join("\n\n") }); cur = []; w = 0; }
  }
  if (cur.length) { if (out.length && w < CHUNK_WORDS / 4) out[out.length - 1].text += "\n\n" + cur.join("\n\n"); else out.push({ title: `Partie ${out.length + 1}`, text: cur.join("\n\n") }); }
  if (out.length === 1) out[0].title = "Texte intégral";
  return out;
}
/** Nettoie, coupe les chapitres trop volumineux (limite de taille d'un document) et ajoute les statistiques. */
function finalize(chapters) {
  const out = [];
  for (const c of chapters) {
    const text = c.text.trim(); if (!text) continue;
    const title = squash(c.title || "").slice(0, 120) || `Chapitre ${out.length + 1}`;
    if (text.length <= MAX_CHARS_PER_DOC) { out.push({ title, text }); continue; }
    let cur = [], len = 0, k = 1;
    for (const p of text.split(/\n\n/)) {
      if (len + p.length > MAX_CHARS_PER_DOC && cur.length) { out.push({ title: k === 1 ? title : `${title} (${k})`, text: cur.join("\n\n") }); cur = []; len = 0; k++; }
      // un paragraphe démesuré (texte sans ligne vide) est coupé aux phrases
      if (p.length > MAX_CHARS_PER_DOC) { for (let i = 0; i < p.length; i += MAX_CHARS_PER_DOC) { out.push({ title: `${title} (${k++})`, text: p.slice(i, i + MAX_CHARS_PER_DOC) }); } continue; }
      cur.push(p); len += p.length + 2;
    }
    if (cur.length) out.push({ title: k === 1 ? title : `${title} (${k})`, text: cur.join("\n\n") });
  }
  if (!out.length) throw new Error("Aucun texte lisible n'a été trouvé dans ce fichier.");
  return { chapters: out, words: out.reduce((s, c) => s + words(c.text), 0) };
}

// ---------- TXT / Markdown ----------
async function readText(file) {
  const buf = await file.arrayBuffer();
  try { return new TextDecoder("utf-8", { fatal: true }).decode(buf); } catch { return new TextDecoder("windows-1252").decode(buf); }
}
async function parseTxt(file) { return finalize(blocksToChapters(textToBlocks(await readText(file)))); }

// ---------- HTML / XHTML (aussi utilisé par l'EPUB) ----------
const SKIP = new Set(["SCRIPT", "STYLE", "HEAD", "SVG", "IMG", "NAV", "TITLE", "META", "LINK"]);
const LEAF = new Set(["P", "LI", "BLOCKQUOTE", "PRE", "DD", "DT", "FIGCAPTION", "TD", "TH", "SUMMARY"]);
const BLOCKISH = new Set(["P", "DIV", "LI", "UL", "OL", "BLOCKQUOTE", "SECTION", "ARTICLE", "TABLE", "TR", "TBODY", "PRE", "ASIDE", "HEADER", "FOOTER", "MAIN", "FIGURE", "DL", "H1", "H2", "H3", "H4", "H5", "H6"]);
function inline(node) {
  let t = "";
  for (const c of node.childNodes) {
    if (c.nodeType === 3) t += c.nodeValue.replace(/[\s\u00a0]+/g, " ");
    else if (c.nodeType === 1) { const tag = c.tagName.toUpperCase(); if (SKIP.has(tag)) continue; t += tag === "BR" ? "\u0001" : inline(c); }
  }
  return t;
}
const cleanInline = t => t.replace(/\u0001/g, "\n").split("\n").map(squash).filter(Boolean).join(" ");
function htmlBlocks(root, out = []) {
  for (const c of root.childNodes) {
    if (c.nodeType !== 1) continue;
    const tag = c.tagName.toUpperCase();
    if (SKIP.has(tag)) continue;
    if (/^H[1-6]$/.test(tag)) { const t = cleanInline(inline(c)); if (t) out.push({ t: "h", level: +tag[1], text: t }); }
    else if (LEAF.has(tag)) { const t = cleanInline(inline(c)); if (t) out.push({ t: "p", text: t }); }
    else if ([...c.childNodes].some(n => n.nodeType === 1 && BLOCKISH.has(n.tagName.toUpperCase()))) htmlBlocks(c, out);
    else { const t = cleanInline(inline(c)); if (t) out.push({ t: "p", text: t }); }
  }
  return out;
}
function parseMarkup(str, type) {
  let doc = new DOMParser().parseFromString(str, type);
  if (type !== "text/html" && (doc.getElementsByTagName("parsererror").length || !doc.documentElement)) doc = new DOMParser().parseFromString(str, "text/html");
  return doc;
}
const bodyOf = doc => doc.body || doc.getElementsByTagName("body")[0] || doc.documentElement;
async function parseHtml(file) {
  const doc = parseMarkup(await readText(file), "text/html");
  const blocks = htmlBlocks(bodyOf(doc));
  return finalize(blocksToChapters(blocks.length ? blocks : textToBlocks(bodyOf(doc).textContent || "")));
}

// ---------- EPUB ----------
const dirname = p => p.includes("/") ? p.slice(0, p.lastIndexOf("/")) : "";
const joinPath = (base, rel) => {
  const parts = (base ? base + "/" + rel : rel).split("/"), out = [];
  for (const s of parts) { if (s === "..") out.pop(); else if (s && s !== ".") out.push(s); }
  return out.join("/");
};
const safeDecode = s => { try { return decodeURIComponent(s); } catch { return s; } };
const byLocal = (root, name) => [...root.getElementsByTagName("*")].filter(e => (e.localName || e.tagName).toLowerCase().replace(/^.*:/, "") === name);

async function parseEpub(file, prog) {
  const JSZip = await getZip(), zip = await JSZip.loadAsync(await file.arrayBuffer());
  const read = async path => { const f = zip.file(path) || zip.file(safeDecode(path)); return f ? f.async("string") : null; };
  const container = await read("META-INF/container.xml");
  if (!container) throw new Error("Fichier EPUB invalide (container.xml introuvable).");
  const opfPath = byLocal(parseMarkup(container, "application/xml"), "rootfile")[0]?.getAttribute("full-path");
  const opfStr = opfPath && await read(opfPath);
  if (!opfStr) throw new Error("Fichier EPUB invalide (package introuvable).");
  const opf = parseMarkup(opfStr, "application/xml"), base = dirname(opfPath);
  const manifest = {};
  byLocal(opf, "item").forEach(i => { manifest[i.getAttribute("id")] = { href: joinPath(base, safeDecode(i.getAttribute("href") || "")), type: i.getAttribute("media-type") || "", props: i.getAttribute("properties") || "" }; });
  const spineEl = byLocal(opf, "spine")[0];
  const spine = byLocal(opf, "itemref").filter(r => r.getAttribute("linear") !== "no").map(r => manifest[r.getAttribute("idref")]).filter(Boolean);
  if (!spine.length) throw new Error("Cet EPUB ne contient aucun chapitre.");

  // Sommaire (titres des chapitres) : EPUB 3 « nav » ou EPUB 2 « NCX »
  const tocTitles = new Map();
  const addToc = (href, title, from) => { const p = joinPath(dirname(from), safeDecode(href.split("#")[0])); title = squash(title); if (title && !tocTitles.has(p)) tocTitles.set(p, title); };
  const nav = Object.values(manifest).find(m => /\bnav\b/.test(m.props));
  if (nav) {
    const s = await read(nav.href);
    if (s) {
      const d = parseMarkup(s, "application/xhtml+xml");
      const navEl = byLocal(d, "nav").find(n => /toc/.test(n.getAttribute("epub:type") || n.getAttribute("type") || "")) || byLocal(d, "nav")[0];
      if (navEl) byLocal(navEl, "a").forEach(a => a.getAttribute("href") && addToc(a.getAttribute("href"), a.textContent, nav.href));
    }
  }
  if (!tocTitles.size) {
    const ncx = manifest[spineEl?.getAttribute("toc")] || Object.values(manifest).find(m => /ncx/.test(m.type));
    const s = ncx && await read(ncx.href);
    if (s) byLocal(parseMarkup(s, "application/xml"), "navPoint").forEach(np => {
      const label = byLocal(np, "text")[0]?.textContent, src = byLocal(np, "content")[0]?.getAttribute("src");
      if (label && src) addToc(src, label, ncx.href);
    });
  }

  // Un chapitre commence quand le fichier figure au sommaire ou s'ouvre sur un titre ; sinon c'est la suite du précédent.
  const chapters = [];
  for (let i = 0; i < spine.length; i++) {
    prog && prog(10 + 80 * i / spine.length, `Lecture du chapitre ${i + 1} / ${spine.length}…`);
    const it = spine[i], s = await read(it.href); if (!s) continue;
    const blocks = htmlBlocks(bodyOf(parseMarkup(s, "application/xhtml+xml")));
    if (!blocks.some(b => words(b.text) > 0)) continue;
    const lead = blocks.find(b => b.t === "h"), leadsWithHeading = !!lead && blocks.indexOf(lead) <= 1;
    let title = tocTitles.get(it.href) || (leadsWithHeading ? lead.text : "");
    const body = blocks.filter((b, k) => !(title && k <= 1 && b.t === "h" && b.text.toLowerCase() === title.toLowerCase()))
      .map(b => b.t === "h" ? "# " + b.text : b.text).join("\n\n");
    if (!title && chapters.length) { chapters[chapters.length - 1].text += "\n\n" + body; continue; }
    chapters.push({ title: title || "Début", text: body });
  }
  // pages de garde / copyright sans contenu : on les écarte
  const kept = chapters.filter((c, i) => !(i < 2 && words(c.text) < 25 && chapters.length > 2));
  if (kept.length === 1) { const only = kept[0]; return finalize(blocksToChapters(textToBlocks(only.text))); }
  return finalize(kept);
}

// ---------- DOCX ----------
async function parseDocx(file) {
  const JSZip = await getZip(), zip = await JSZip.loadAsync(await file.arrayBuffer());
  const f = zip.file("word/document.xml"); if (!f) throw new Error("Fichier Word invalide.");
  const xml = parseMarkup(await f.async("string"), "application/xml");
  const blocks = [];
  for (const p of xml.getElementsByTagName("w:p")) {
    let t = "";
    for (const n of p.getElementsByTagName("*")) {
      const name = n.tagName;
      if (name === "w:t") t += n.textContent; else if (name === "w:tab") t += " "; else if (name === "w:br" || name === "w:cr") { if ((n.getAttribute("w:type") || "") !== "page") t += " "; } else if (name === "w:noBreakHyphen") t += "-";
    }
    t = squash(t); if (!t) continue;
    const style = p.getElementsByTagName("w:pStyle")[0]?.getAttribute("w:val") || "";
    const outline = p.getElementsByTagName("w:outlineLvl")[0]?.getAttribute("w:val");
    const m = style.match(/^(?:heading|titre|title)\s*([1-9])$/i);
    const level = m ? +m[1] : (outline !== undefined && outline !== null && outline !== "" ? +outline + 1 : 0);
    if (level && t.length < 160) blocks.push({ t: "h", level, text: t }); else blocks.push({ t: "p", text: t });
  }
  // Pas de styles de titre ? On reconnaît « Chapitre 1 », « Prologue »… dans le texte.
  if (!blocks.some(b => b.t === "h")) blocks.forEach(b => { if (b.t === "p" && looksLikeHeading(b.text, false)) { b.t = "h"; b.level = 1; } });
  return finalize(blocksToChapters(blocks));
}

// ---------- PDF ----------
function pageParagraphs(items) {
  const its = items.filter(i => typeof i.str === "string" && (i.str.trim() || i.hasEOL)).map(i => ({ s: i.str, x: i.transform[4], y: i.transform[5], w: i.width || 0, h: Math.abs(i.height || i.transform[3] || 10) }));
  if (!its.length) return [];
  // 1. lignes : même ordonnée (à une tolérance liée à la taille du texte)
  const lines = [];
  for (const it of its) {
    const l = lines.find(l => Math.abs(l.y - it.y) <= Math.max(2, it.h * 0.45));
    if (l) l.items.push(it); else lines.push({ y: it.y, h: it.h, items: [it] });
  }
  lines.sort((a, b) => b.y - a.y);
  for (const l of lines) {
    l.items.sort((a, b) => a.x - b.x);
    let t = "", prev = null;
    for (const it of l.items) {
      if (prev && it.x - (prev.x + prev.w) > it.h * 0.15 && !/\s$/.test(t) && !/^\s/.test(it.s)) t += " ";
      t += it.s; prev = it;
    }
    l.text = squash(t); l.x0 = l.items[0].x; l.x1 = Math.max(...l.items.map(i => i.x + i.w));
  }
  const ls = lines.filter(l => l.text);
  if (!ls.length) return [];
  // 2. paragraphes : grand interligne, ou fin de phrase sur une ligne nettement plus courte que les autres
  const gaps = ls.slice(1).map((l, i) => ls[i].y - l.y).filter(g => g > 0).sort((a, b) => a - b), med = gaps.length ? gaps[Math.floor(gaps.length / 2)] : 12;
  const maxW = Math.max(...ls.map(l => l.x1 - l.x0)), left = Math.min(...ls.map(l => l.x0));
  const paras = []; let cur = ls[0].text;
  for (let i = 1; i < ls.length; i++) {
    const prev = ls[i - 1], l = ls[i], gap = prev.y - l.y;
    const shortEnd = (prev.x1 - prev.x0) < maxW * 0.72 && /[.!?»”"…:;)]$/.test(prev.text);
    const indent = l.x0 - left > l.h * 0.9 && /[.!?»”"…]$/.test(prev.text);
    if (gap > med * 1.45 || shortEnd || indent) { paras.push(cur); cur = l.text; }
    else if (/[-‐]$/.test(cur) && /^[a-zàâçéèêëîïôûùüÿœ]/.test(l.text)) cur = cur.slice(0, -1) + l.text;   // mot coupé en fin de ligne
    else cur += " " + l.text;
  }
  paras.push(cur);
  return paras;
}
async function parsePdf(file, prog) {
  const pdfjs = await getPdf(), pdf = await pdfjs.getDocument({ data: new Uint8Array(await file.arrayBuffer()) }).promise;
  const pages = [];
  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i), tc = await page.getTextContent();
    pages.push(pageParagraphs(tc.items));
    prog && prog(5 + 85 * i / pdf.numPages, `Lecture de la page ${i} / ${pdf.numPages}…`);
  }
  // En-têtes / pieds de page répétés et numéros de page : supprimés
  const key = t => t.replace(/\d+/g, "#").toLowerCase();
  const freq = {};
  pages.forEach(ps => new Set([ps[0], ps[ps.length - 1]].filter(Boolean).map(key)).forEach(k => freq[k] = (freq[k] || 0) + 1));
  const rep = Math.max(3, pdf.numPages * 0.4);
  const isNoise = (t, edge) => edge && (/^[\s\-–—]*\d{1,4}[\s\-–—]*$/.test(t) || (freq[key(t)] >= rep && t.length < 90));
  const cleaned = pages.map(ps => ps.filter((t, i) => !isNoise(t, i === 0 || i === ps.length - 1)));
  if (cleaned.flat().join(" ").length < 200) throw new Error("Ce PDF ne contient pas de texte exploitable (probablement des pages scannées). Utilisez un PDF avec texte sélectionnable, un EPUB ou un fichier Word.");

  // Chapitres : signets du PDF s'ils existent, sinon intertitres « Chapitre … » reconnus dans le texte
  let starts = [];
  try {
    const outline = await pdf.getOutline();
    for (const o of outline || []) {
      let dest = o.dest; if (typeof dest === "string") dest = await pdf.getDestination(dest);
      if (Array.isArray(dest) && dest[0] !== undefined) starts.push({ title: o.title, page: typeof dest[0] === "object" ? await pdf.getPageIndex(dest[0]) : dest[0] });
    }
  } catch { starts = []; }
  starts = starts.filter((s, i, a) => Number.isInteger(s.page) && a.findIndex(x => x.page === s.page) === i).sort((a, b) => a.page - b.page);
  if (starts.length >= 2) {
    const chapters = [];
    if (starts[0].page > 0) chapters.push({ title: "Début", text: cleaned.slice(0, starts[0].page).flat().join("\n\n") });
    starts.forEach((s, i) => chapters.push({ title: s.title, text: cleaned.slice(s.page, i + 1 < starts.length ? starts[i + 1].page : pdf.numPages).flat().join("\n\n") }));
    const out = chapters.filter((c, i) => !(i === 0 && c.title === "Début" && words(c.text) < 80));
    // un signet ne contient que son titre en tête : on le retire du corps
    out.forEach(c => { const first = c.text.split("\n\n")[0]; if (first && squash(first).toLowerCase() === squash(c.title).toLowerCase()) c.text = c.text.split("\n\n").slice(1).join("\n\n"); });
    return finalize(out);
  }
  // Fusion d'un paragraphe coupé par un saut de page
  const paras = [];
  for (const ps of cleaned) for (let k = 0; k < ps.length; k++) {
    const prev = paras[paras.length - 1];
    if (k === 0 && prev && prev.t === "p" && !/[.!?»”"…:;)]$/.test(prev.text) && /^[a-zàâçéèêëîïôûùüÿœ]/.test(ps[k])) prev.text += " " + ps[k];
    else paras.push({ t: "p", text: ps[k] });
  }
  paras.forEach(b => { if (looksLikeHeading(b.text, false)) { b.t = "h"; b.level = 1; } });
  return finalize(blocksToChapters(paras));
}

// ---------- Point d'entrée ----------
export async function parseEbookFile(file, onProgress = () => {}) {
  if (!file) throw new Error("Aucun fichier.");
  if (file.size > MAX_MB * 1048576) throw new Error(`Fichier trop volumineux (max ${MAX_MB} Mo).`);
  const ext = (file.name.match(/\.([a-z0-9]+)$/i) || [])[1]?.toLowerCase() || "";
  const prog = (p, m) => onProgress(p, m);
  prog(3, "Ouverture du fichier…");
  let r;
  if (ext === "epub") r = await parseEpub(file, prog);
  else if (ext === "pdf") r = await parsePdf(file, prog);
  else if (ext === "docx") r = await parseDocx(file);
  else if (ext === "txt" || ext === "md" || ext === "markdown") r = await parseTxt(file);
  else if (ext === "html" || ext === "htm" || ext === "xhtml") r = await parseHtml(file);
  else if (ext === "doc") throw new Error("Le format .doc (ancien Word) n'est pas pris en charge : enregistrez le fichier au format .docx puis réimportez-le.");
  else throw new Error("Format non pris en charge. Importez un fichier EPUB, PDF, Word (.docx), TXT, Markdown ou HTML.");
  prog(100, "Terminé");
  return r;
}

// Exposés pour les tests automatiques
export const _t = { textToBlocks, blocksToChapters, finalize, parseTxt, parseEpub, parseDocx, parsePdf, pageParagraphs };
