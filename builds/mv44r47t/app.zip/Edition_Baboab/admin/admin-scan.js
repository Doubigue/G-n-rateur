// ============ Scanner de factures (QR / code-barres) ============
let C = null, stream = null, raf = 0, busy = false, recent = [];
const JSQR = "https://cdnjs.cloudflare.com/ajax/libs/jsQR/1.4.0/jsQR.min.js";
let jsqrP = null;
const loadJsQR = () => window.jsQR ? Promise.resolve(window.jsQR) : (jsqrP ||= new Promise((res, rej) => { const s = document.createElement("script"); s.src = JSQR; s.onload = () => res(window.jsQR); s.onerror = () => { jsqrP = null; rej(new Error("Lecteur QR indisponible (connexion ?)")); }; document.head.append(s); }));
const $ = s => document.querySelector(s);

export function initScan(ctx) { C = ctx; document.addEventListener("click", e => {
  if (e.target.closest("[data-scan-open]")) { e.preventDefault(); openScanner(); }
  const inv = e.target.closest("[data-open-inv]"); if (inv) { e.preventDefault(); showInvoice(inv.dataset.openInv); }
}); window.EDM_scan = { open: openScanner, find: showInvoice }; }

/** Carte premium « Scanner » (Accueil et Achats > Scanner) */
export function heroHtml() {
  const logo = window.__edmLogo;
  return `<div class="shero">
    <div class="sglow"></div>
    <div class="slogo">${logo ? `<img src="${logo}" alt="" crossorigin="anonymous">` : `<span>✦</span>`}</div>
    <p class="seyebrow">Validation des factures</p>
    <h2 class="serif">Scanner une facture</h2>
    <p class="ssub">Visez le QR ou le code-barres de la facture : elle s'ouvre aussitôt pour être confirmée et remise.</p>
    <button type="button" class="sbtn" data-scan-open aria-label="Ouvrir le scanner"><i class="r1"></i><i class="r2"></i><span><svg viewBox="0 0 24 24"><path d="M4 8V6a2 2 0 0 1 2-2h2M16 4h2a2 2 0 0 1 2 2v2M20 16v2a2 2 0 0 1-2 2h-2M8 20H6a2 2 0 0 1-2-2v-2"/><path d="M7 12h10"/></svg></span></button>
    <p class="stap">Toucher pour scanner</p>
    <form class="smanual" data-manual><input class="input" inputmode="text" autocomplete="off" placeholder="…ou saisir le n° de facture" aria-label="Numéro de facture"><button class="btn btn-gold">OK</button></form>
    ${recent.length ? `<div class="srecent"><p>Derniers scans</p><div class="hscroll">${recent.map(r => `<button type="button" class="dcard" data-open-inv="${C.esc(r.inv)}"><span class="dico">${r.ok ? "✅" : "🧾"}</span><b>${C.esc(r.inv)}</b><small>${C.esc(r.who)}</small></button>`).join("")}</div></div>` : ""}
  </div>`;
}
export function mountScan(el) { if (!el) return; const draw = () => { el.innerHTML = heroHtml(); }; draw(); window.addEventListener("edm-logo", draw); window.addEventListener("edm-scans", draw); window.EDM_mount = el2 => { if (el2) { el2.innerHTML = heroHtml(); } }; }
document.addEventListener("submit", e => { const f = e.target.closest("[data-manual]"); if (!f) return; e.preventDefault(); const v = f.querySelector("input").value.trim(); if (v) { showInvoice(v); f.reset(); } });

// ---------- Recherche d'une commande dans un texte scanné ----------
function findOrder(text) {
  const t = String(text || "").toUpperCase().replace(/\s+/g, ""); if (!t) return null;
  const list = C.getOrders();
  return list.find(o => o.invoice && t.includes(String(o.invoice).toUpperCase().replace(/\s+/g, ""))) || list.find(o => o.invoice && String(o.invoice).toUpperCase().includes(t) && t.length > 3) || null;
}

// ---------- Caméra ----------
async function openScanner() {
  closeScanner(); document.body.classList.add("noscroll");
  const ov = document.createElement("div"); ov.id = "scan-ov"; ov.innerHTML = `
   <video playsinline muted autoplay></video>
   <div class="sframe"><b></b><b></b><b></b><b></b><u></u></div>
   <div class="stop"><button type="button" data-sx aria-label="Fermer">✕</button><span>Placez le QR / code-barres dans le cadre</span></div>
   <div class="sbot"><button type="button" data-sphoto>🖼 Photo</button><button type="button" data-stype>⌨ Saisir</button></div>
   <p class="smsg" id="scan-msg"></p>`;
  document.body.append(ov);
  ov.addEventListener("click", e => { if (e.target.closest("[data-sx]")) closeScanner(); if (e.target.closest("[data-stype]")) { const v = prompt("N° de facture :"); if (v) handle(v); } if (e.target.closest("[data-sphoto]")) pickPhoto(); });
  const msg = t => { const m = $("#scan-msg"); if (m) m.textContent = t; };
  try {
    stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: "environment" }, width: { ideal: 1280 } }, audio: false });
    const v = ov.querySelector("video"); v.srcObject = stream; await v.play();
    const det = window.BarcodeDetector ? new BarcodeDetector({ formats: ["qr_code", "code_128", "code_39", "ean_13", "ean_8", "itf", "codabar", "upc_a", "data_matrix"] }) : null;
    if (!det) await loadJsQR().catch(() => msg("Lecteur QR indisponible : utilisez Photo ou Saisir."));
    const cv = document.createElement("canvas"), cx = cv.getContext("2d", { willReadFrequently: true });
    let last = 0;
    const tick = async t => {
      if (!$("#scan-ov")) return; raf = requestAnimationFrame(tick);
      if (busy || t - last < 140 || v.readyState < 2) return; last = t; let txt = "";
      try {
        if (det) { const r = await det.detect(v); txt = r[0]?.rawValue || ""; }
        else if (window.jsQR) { const k = Math.min(1, 640 / v.videoWidth); cv.width = v.videoWidth * k; cv.height = v.videoHeight * k; cx.drawImage(v, 0, 0, cv.width, cv.height); txt = window.jsQR(cx.getImageData(0, 0, cv.width, cv.height).data, cv.width, cv.height)?.data || ""; }
      } catch { }
      if (txt) handle(txt);
    };
    raf = requestAnimationFrame(tick);
  } catch (err) { msg(err?.name === "NotAllowedError" ? "Accès caméra refusé : autorisez-la, ou utilisez Photo / Saisir." : "Caméra indisponible : utilisez Photo ou Saisir."); }
}
function closeScanner() { cancelAnimationFrame(raf); stream?.getTracks().forEach(t => t.stop()); stream = null; $("#scan-ov")?.remove(); document.body.classList.remove("noscroll"); busy = false; }
function pickPhoto() {
  const i = Object.assign(document.createElement("input"), { type: "file", accept: "image/*" });
  i.onchange = async () => {
    const f = i.files?.[0]; if (!f) return; const bmp = await createImageBitmap(f), cv = document.createElement("canvas"); cv.width = bmp.width; cv.height = bmp.height; cv.getContext("2d").drawImage(bmp, 0, 0);
    let txt = ""; try { if (window.BarcodeDetector) txt = (await new BarcodeDetector().detect(cv))[0]?.rawValue || ""; } catch { }
    if (!txt) { await loadJsQR().catch(() => { }); txt = window.jsQR?.(cv.getContext("2d").getImageData(0, 0, cv.width, cv.height).data, cv.width, cv.height)?.data || ""; }
    txt ? handle(txt) : C.toast("Aucun code lisible sur cette image");
  }; i.click();
}
function handle(text) {
  if (busy) return; const o = findOrder(text);
  if (!o) { const m = $("#scan-msg"); if (m) { m.textContent = "Code non reconnu : « " + String(text).slice(0, 40) + " »"; busy = true; setTimeout(() => busy = false, 1600); } else C.toast("Facture introuvable"); return; }
  busy = true; navigator.vibrate?.(60); closeScanner(); showInvoice(o.invoice, true);
}

// ---------- Fiche facture : confirmer / remettre ----------
function showInvoice(inv, fromScan) {
  const o = findOrder(inv); document.getElementById("inv-sheet")?.remove();
  if (!o) { C.toast("Facture « " + inv + " » introuvable"); return; }
  const { fmtF, esc, ORDER_ST, MODE_LABEL, fdate, orderMs } = C, st = ORDER_ST[o.status] || [o.status, ""], dig = (o.items || []).length > 0 && (o.items || []).every(i => i.format === "ebook"), del = !dig && o.mode === "delivery";
  const who = `${o.name || ""} ${o.surname || ""}`.trim() || o.email || "Client";
  recent = [{ inv: o.invoice, who, ok: o.status === "delivered" }, ...recent.filter(r => r.inv !== o.invoice)].slice(0, 6); window.dispatchEvent(new Event("edm-scans"));
  const sh = document.createElement("div"); sh.id = "inv-sheet";
  const btn = (a, t, cls) => `<button class="btn ${cls}" data-sa="${a}">${t}</button>`;
  let actions = "";
  if (o.status === "pending") actions = btn("both", "✅ Confirmer le paiement et remettre", "btn-gold") + btn("pay", "💵 Confirmer le paiement seulement", "btn-dark") + btn("cancel", "Annuler la commande", "btn-light btn-danger");
  else if (o.status === "paid" && dig) actions = `<p class="ok-note">✅ Payée — e-book débloqué dans la bibliothèque du client.</p>`;
  else if (o.status === "paid") actions = btn("deliver", `📦 Marquer ${del ? "livrée" : "remise en agence"}`, "btn-gold");
  else if (o.status === "delivered") actions = `<p class="ok-note">✅ Cette facture a déjà été remise.</p>`;
  else actions = `<p class="ok-note ko">⛔ Commande annulée.</p>`;
  sh.innerHTML = `<div class="shbg" data-sc></div><div class="shpanel" role="dialog" aria-label="Facture ${esc(o.invoice)}"><i class="grab"></i>
   <div class="flex justify-between items-start gap-3"><div><p class="seyebrow">${fromScan ? "Facture scannée" : "Facture"}</p><h3 class="serif" style="font-size:26px">${esc(o.invoice)}</h3><p class="text-sm text-stone-500">${fdate(orderMs(o), true)}</p></div><span class="chip ${st[1]}">${esc(st[0])}</span></div>
   <div class="shinfo"><p><small>Client</small><b>${esc(who)}</b>${esc(o.phone || "")}</p><p><small>${dig ? "Règlement à" : del ? "Livraison depuis" : "Retrait à"}</small><b>${esc(o.agencyName || "—")}</b>${esc(dig ? "E-book (numérique)" : (MODE_LABEL[o.mode] || ""))}</p></div>
   <ul class="shitems">${(o.items || []).map(i => `<li><span>${esc(i.title)} <em>${i.format === "ebook" ? "· 📖 E-book" : "· 📕 Papier"} × ${i.qty}</em></span><b>${fmtF(i.unit * i.qty)}</b></li>`).join("")}</ul>
   <div class="shtotal"><span>Total</span><strong>${fmtF(o.total)}</strong></div>
   <div class="grid gap-2 mt-4" id="sh-actions">${actions}</div><button class="btn btn-light w-full mt-2" data-sc>Fermer</button>${fromScan ? `<button class="btn btn-light w-full mt-2" data-sagain>📷 Scanner la suivante</button>` : ""}</div>`;
  document.body.append(sh);
  sh.addEventListener("click", async e => {
    if (e.target.closest("[data-sc]")) return sh.remove();
    if (e.target.closest("[data-sagain]")) { sh.remove(); return openScanner(); }
    const b = e.target.closest("[data-sa]"); if (!b) return; const a = b.dataset.sa;
    b.disabled = true; let ok;
    if (a === "both") { ok = await C.act(o, "pay"); if (ok) ok = await C.act({ ...o, status: "paid" }, "deliver"); }
    else ok = await C.act(o, a);
    if (ok) { sh.remove(); setTimeout(() => showInvoice(o.invoice, fromScan), 700); } else b.disabled = false;
  });
}
