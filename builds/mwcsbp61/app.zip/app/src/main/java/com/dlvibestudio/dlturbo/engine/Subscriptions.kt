package com.dlvibestudio.dlturbo.engine

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject

/**
 * Chaînes suivies : toutes les 6 heures (tant que l'appli ou son service tourne) et à la demande, on
 * regarde les dernières vidéos de chaque chaîne ; les nouvelles sont mises en file de téléchargement.
 */
class Subscriptions(
    private val manager: DownloadManager,
    private val library: Library,
    private val scope: CoroutineScope,
) {
    fun startLoop() {
        scope.launch {
            delay(60_000)
            while (true) {
                runCatching { checkAll() }
                delay(6 * 3600_000L)
            }
        }
    }

    /** Ajoute une chaîne ; les vidéos déjà en ligne sont marquées comme vues (pas de téléchargement en masse). */
    suspend fun follow(input: String, quality: String): Result<String> = runCatching {
        val url = normalize(input) ?: error("Adresse de chaîne invalide")
        val json = manager.videos.dumpJson(videosUrl(url), "--flat-playlist" to null, "--playlist-end" to "15")
        val ids = ids(json)
        val name = json.optString("uploader").ifBlank { json.optString("title") }.ifBlank { url.substringAfterLast('/') }
        library.addChannel(Channel(url, name, ids, quality))
        name
    }

    /** Vérifie toutes les chaînes ; renvoie le nombre de nouvelles vidéos mises en file. */
    suspend fun checkAll(): Int {
        var added = 0
        for (c in library.channels.toList()) {
            try {
                val json = manager.videos.dumpJson(videosUrl(c.url), "--flat-playlist" to null, "--playlist-end" to "15")
                val fresh = entries(json).filter { it.first !in c.seen }
                fresh.reversed().forEach { (id, title) ->
                    manager.enqueueVideo("https://www.youtube.com/watch?v=$id", c.quality, false, title)
                    added++
                }
                library.updateChannel(c.copy(seen = c.seen + fresh.map { it.first }))
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                // Chaîne injoignable pour l'instant : on réessaiera au prochain passage.
            }
        }
        return added
    }

    private fun entries(json: JSONObject): List<Pair<String, String>> {
        val arr = json.optJSONArray("entries") ?: return emptyList()
        val out = ArrayList<Pair<String, String>>()
        for (i in 0 until arr.length()) {
            val e = arr.optJSONObject(i) ?: continue
            val id = e.optString("id")
            if (id.length == 11) out.add(id to e.optString("title"))
        }
        return out
    }

    private fun ids(json: JSONObject) = entries(json).map { it.first }

    private fun videosUrl(channel: String) =
        if (channel.contains("/videos") || channel.contains("/playlist")) channel else channel.trimEnd('/') + "/videos"

    private fun normalize(input: String): String? {
        val t = input.trim()
        return when {
            t.startsWith("@") -> "https://www.youtube.com/$t"
            t.startsWith("http", ignoreCase = true) && t.contains("youtube.com", ignoreCase = true) -> t.substringBefore('?')
            else -> null
        }
    }
}
