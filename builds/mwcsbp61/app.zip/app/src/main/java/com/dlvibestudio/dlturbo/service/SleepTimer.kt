package com.dlvibestudio.dlturbo.service

import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Minuteur d'arrêt : met la lecture en pause après un délai (musique avant de dormir). */
object SleepTimer {
    private val handler = Handler(Looper.getMainLooper())
    private var task: Runnable? = null
    private val _endAt = MutableStateFlow(0L)

    /** Heure d'arrêt prévue (ms), ou 0 si le minuteur est inactif. */
    val endAt: StateFlow<Long> = _endAt

    fun start(minutes: Int) {
        cancel()
        val delayMs = minutes * 60_000L
        val r = Runnable {
            PlaybackService.pausePlayer()
            task = null
            _endAt.value = 0L
        }
        task = r
        _endAt.value = System.currentTimeMillis() + delayMs
        handler.postDelayed(r, delayMs)
    }

    fun cancel() {
        task?.let { handler.removeCallbacks(it) }
        task = null
        _endAt.value = 0L
    }
}
