package com.dlvibestudio.dlturbo.ui

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject

data class Bookmark(val title: String, val url: String)

/** Favoris du navigateur, conservés sur le téléphone. */
class Bookmarks(context: Context) {
    private val prefs = context.getSharedPreferences("dlturbo_bookmarks", Context.MODE_PRIVATE)
    val items = mutableStateListOf<Bookmark>()

    init {
        try {
            val arr = JSONArray(prefs.getString("list", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                items.add(Bookmark(o.getString("t"), o.getString("u")))
            }
        } catch (_: Exception) {
        }
    }

    fun contains(url: String) = items.any { it.url == url }

    fun toggle(title: String, url: String) {
        val existing = items.indexOfFirst { it.url == url }
        if (existing >= 0) items.removeAt(existing)
        else if (url.startsWith("http")) items.add(0, Bookmark(title.ifBlank { url }.take(80), url))
        save()
    }

    fun remove(bookmark: Bookmark) {
        items.remove(bookmark)
        save()
    }

    private fun save() {
        val arr = JSONArray()
        items.forEach { arr.put(JSONObject().put("t", it.title).put("u", it.url)) }
        prefs.edit().putString("list", arr.toString()).apply()
    }
}
