package com.dlvibestudio.dlturbo.service

import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.dlvibestudio.dlturbo.App
import com.dlvibestudio.dlturbo.data.DlStatus
import com.dlvibestudio.dlturbo.data.DownloadItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Service de premier plan : c'est lui qui garde l'application vivante quand l'écran
 * est éteint ou que l'appli est en arrière-plan. Il maintient le processeur et le
 * Wi-Fi éveillés (wake locks) et met à jour les notifications chaque seconde.
 */
class DownloadService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var loopStarted = false

    /** Dernier statut connu de chaque élément, pour détecter « terminé », « en pause », « échec ». */
    private val lastStatus = HashMap<String, DlStatus>()
    /** Notifications de progression actuellement affichées (id d'élément -> id de notification). */
    private val shown = HashMap<String, Int>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "DLTurbo:download").apply {
            setReferenceCounted(false)
            runCatching { acquire() }
        }
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        @Suppress("DEPRECATION")
        wifiLock = wm?.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "DLTurbo:wifi")?.apply {
            setReferenceCounted(false)
            runCatching { acquire() }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val app = application as App
        val active = app.repo.items.value.filter { it.status.isActive }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
        try {
            ServiceCompat.startForeground(this, Notifications.SUMMARY_ID, Notifications.summary(this, active), type)
        } catch (e: Exception) {
            // Android a refusé le premier plan (appli en arrière-plan) : on s'arrête proprement.
            stopSelf()
            return START_NOT_STICKY
        }
        if (!loopStarted) {
            loopStarted = true
            app.repo.items.value.forEach { lastStatus[it.id] = it.status }
            scope.launch { loop(app) }
        }
        return START_NOT_STICKY
    }

    private suspend fun loop(app: App) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        var idle = 0
        while (scope.isActive) {
            val items = app.repo.items.value
            val active = items.filter { it.status.isActive }
            render(nm, app, items, active)
            if (active.isEmpty()) {
                idle++
                if (idle >= 3) break
            } else {
                idle = 0
            }
            delay(1000)
        }
        shown.values.forEach { nm.cancel(it) }
        shown.clear()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun render(nm: NotificationManager, app: App, items: List<DownloadItem>, active: List<DownloadItem>) {
        runCatching { nm.notify(Notifications.SUMMARY_ID, Notifications.summary(this, active)) }

        // Progression détaillée : limitée à quelques éléments pour respecter le quota d'Android.
        val detailed = active
            .sortedBy { if (it.status == DlStatus.RUNNING || it.status == DlStatus.CONNECTING) 0 else 1 }
            .take(MAX_DETAILED)
        val detailedIds = detailed.map { it.id }.toSet()

        // Transitions : terminé / en pause / échec / supprimé.
        val byId = items.associateBy { it.id }
        for ((id, previous) in lastStatus.toMap()) {
            val current = byId[id]
            if (current == null) {
                shown.remove(id)?.let { nm.cancel(it) }
                lastStatus.remove(id)
                continue
            }
            if (previous.isActive && !current.status.isActive) {
                shown.remove(id)
                val notifId = Notifications.idFor(current)
                runCatching {
                    when (current.status) {
                        DlStatus.COMPLETED ->
                            nm.notify(notifId, Notifications.done(this, current, app.settings.value.soundOnComplete))
                        DlStatus.PAUSED -> nm.notify(notifId, Notifications.paused(this, current))
                        DlStatus.ERROR -> nm.notify(notifId, Notifications.failed(this, current))
                        else -> nm.cancel(notifId)
                    }
                }
            }
        }
        items.forEach { lastStatus[it.id] = it.status }

        // Retire la progression des éléments qui ne sont plus détaillés (mais toujours actifs).
        val iterator = shown.entries.iterator()
        while (iterator.hasNext()) {
            val entry = iterator.next()
            if (entry.key !in detailedIds) {
                nm.cancel(entry.value)
                iterator.remove()
            }
        }
        for (item in detailed) {
            val notifId = Notifications.idFor(item)
            shown[item.id] = notifId
            runCatching { nm.notify(notifId, Notifications.progress(this, item)) }
        }
    }

    override fun onDestroy() {
        scope.cancel()
        runCatching { wakeLock?.takeIf { it.isHeld }?.release() }
        runCatching { wifiLock?.takeIf { it.isHeld }?.release() }
        super.onDestroy()
    }

    companion object {
        private const val MAX_DETAILED = 3

        fun start(context: Context) {
            try {
                ContextCompat.startForegroundService(context, Intent(context, DownloadService::class.java))
            } catch (_: Exception) {
            }
        }
    }
}
