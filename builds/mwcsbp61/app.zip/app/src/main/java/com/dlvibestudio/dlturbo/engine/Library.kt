package com.dlvibestudio.dlturbo.engine

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import org.json.JSONArray
import org.json.JSONObject

/** Chaîne suivie : les nouvelles vidéos sont téléchargées automatiquement. */
data class Channel(val url: String, val name: String, val seen: List<String>, val quality: String)

/**
 * Mémoire de l'application : vidéos déjà téléchargées (badge « Téléchargé »), recherches récentes
 * et chaînes suivies. Tout est gardé dans les préférences.
 */
class Library(context: Context) {
    private val prefs = context.getSharedPreferences("library", Context.MODE_PRIVATE)

    // ------------------------------------------------------------- Téléchargé
    private val _downloaded = mutableStateOf(loadSet("downloaded"))
    val downloaded get() = _downloaded.value

    fun isDownloaded(url: String): Boolean = key(url)?.let { it in _downloaded.value } == true

    fun markDownloaded(url: String) {
        val k = key(url) ?: return
        if (k in _downloaded.value) return
        _downloaded.value = _downloaded.value + k
        prefs.edit().putString("downloaded", JSONArray(_downloaded.value.toList()).toString()).apply()
    }

    // ------------------------------------------------------ Recherches récentes
    val recent = mutableStateListOf<String>().also { l -> loadList("recent").forEach { l.add(it) } }

    fun addSearch(q: String) {
        val t = q.trim()
        if (t.isEmpty()) return
        recent.removeAll { it.equals(t, ignoreCase = true) }
        recent.add(0, t)
        while (recent.size > 12) recent.removeAt(recent.lastIndex)
        prefs.edit().putString("recent", JSONArray(recent.toList()).toString()).apply()
    }

    fun clearSearches() {
        recent.clear()
        prefs.edit().remove("recent").apply()
    }

    // ----------------------------------------------------------------- Chaînes
    val channels = mutableStateListOf<Channel>().also { l -> loadChannels().forEach { l.add(it) } }

    fun addChannel(c: Channel) {
        channels.removeAll { it.url == c.url }
        channels.add(c)
        saveChannels()
    }

    fun updateChannel(c: Channel) {
        val i = channels.indexOfFirst { it.url == c.url }
        if (i >= 0) channels[i] = c
        saveChannels()
    }

    fun removeChannel(url: String) {
        channels.removeAll { it.url == url }
        saveChannels()
    }

    private fun saveChannels() {
        val arr = JSONArray()
        channels.forEach { c ->
            arr.put(
                JSONObject().put("url", c.url).put("name", c.name).put("quality", c.quality)
                    .put("seen", JSONArray(c.seen.takeLast(300)))
            )
        }
        prefs.edit().putString("channels", arr.toString()).apply()
    }

    private fun loadChannels(): List<Channel> = runCatching {
        val arr = JSONArray(prefs.getString("channels", "[]"))
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val seen = o.optJSONArray("seen")?.let { a -> (0 until a.length()).map { a.getString(it) } } ?: emptyList()
            Channel(o.getString("url"), o.optString("name", "Chaîne"), seen, o.optString("quality", "best"))
        }
    }.getOrDefault(emptyList())

    private fun loadSet(name: String): Set<String> = loadList(name).toSet()

    private fun loadList(name: String): List<String> = runCatching {
        val arr = JSONArray(prefs.getString(name, "[]"))
        (0 until arr.length()).map { arr.getString(it) }
    }.getOrDefault(emptyList())

    companion object {
        private val ID = Regex("""(?:youtu\.be/|[?&]v=|/shorts/|/embed/)([A-Za-z0-9_-]{11})""")

        /** Identifiant de vidéo YouTube, sinon l'adresse elle-même sans paramètres de suivi. */
        fun key(url: String): String? {
            if (url.isBlank()) return null
            ID.find(url)?.let { return "yt:" + it.groupValues[1] }
            return url.substringBefore('#').trim()
        }
    }
}
