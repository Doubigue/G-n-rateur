package com.dlvibestudio.dlturbo.engine

import com.dlvibestudio.dlturbo.data.DlStatus
import com.dlvibestudio.dlturbo.data.DownloadItem
import com.dlvibestudio.dlturbo.data.DownloadRepository
import com.dlvibestudio.dlturbo.data.Segment
import com.dlvibestudio.dlturbo.data.Settings
import com.dlvibestudio.dlturbo.data.SettingsData
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.Call
import okhttp3.ConnectionPool
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Request
import okhttp3.Response
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong
import kotlin.coroutines.coroutineContext
import kotlin.math.max
import kotlin.math.min

/** Le lien pointe vers une page web et non vers un fichier. */
class HtmlPageException : IOException("Page web")

/** Erreur définitive : inutile de réessayer. */
class FatalDownloadException(message: String) : IOException(message)

/** Limiteur de débit partagé par toutes les connexions. */
class RateLimiter(private val rate: () -> Long) {
    private var nextFree = 0L

    fun acquire(bytes: Int) {
        val r = rate()
        if (r <= 0) return
        val sleepNs = synchronized(this) {
            val now = System.nanoTime()
            val start = max(now, nextFree)
            nextFree = start + bytes * 1_000_000_000L / r
            start - now
        }
        if (sleepNs > 0) {
            try {
                Thread.sleep(min(sleepNs / 1_000_000L, 2000L))
            } catch (_: InterruptedException) {
            }
        }
    }
}

/**
 * Téléchargement HTTP/HTTPS accéléré : le fichier est découpé en segments, chacun
 * téléchargé par sa propre connexion (requêtes « Range »). L'avancement de chaque
 * segment est sauvegardé : après une pause, une coupure réseau ou un redémarrage,
 * chaque connexion reprend exactement à l'octet où elle s'était arrêtée.
 */
class HttpDownloader(
    private val repo: DownloadRepository,
    private val settings: Settings,
    private val limiter: RateLimiter,
) {
    val client: OkHttpClient = OkHttpClient.Builder()
        // HTTP/1.1 : une vraie connexion TCP par segment (HTTP/2 les regrouperait sur une seule).
        .protocols(listOf(Protocol.HTTP_1_1))
        .connectionPool(ConnectionPool(64, 2, TimeUnit.MINUTES))
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .retryOnConnectionFailure(true)
        .build()

    private class State(
        val start: LongArray,
        val end: LongArray,
        val done: Array<AtomicLong>,
        val resumable: Boolean,
        val etag: String?,
        val part: File,
        val cookie: String = "",
        val referer: String = "",
    ) {
        fun total(): Long = done.sumOf { it.get() }
        fun snapshot(): List<Segment> =
            start.indices.map { Segment(start[it], end[it], done[it].get()) }
    }

    /** Télécharge l'élément [id] jusqu'au bout et renvoie le fichier final. */
    suspend fun run(id: String): File {
        var item = repo.get(id) ?: throw FatalDownloadException("Téléchargement introuvable")
        val cfg = settings.value
        repo.update(id) { it.copy(info = "Connexion…") }

        val existingPart = File(item.dir, item.fileName + Links.PART_SUFFIX)
        val canContinue = item.resumable && item.segments.isNotEmpty() && existingPart.exists()
        if (!canContinue) {
            item = prepare(item, cfg)
            val prepared = item
            repo.update(id) {
                it.copy(
                    fileName = prepared.fileName, dir = prepared.dir,
                    totalBytes = prepared.totalBytes, resumable = prepared.resumable,
                    etag = prepared.etag, segments = prepared.segments,
                    downloadedBytes = 0, autoName = false, videoFallback = false,
                )
            }
            repo.saveNow()
        }

        val state = State(
            start = LongArray(item.segments.size) { item.segments[it].start },
            end = LongArray(item.segments.size) { item.segments[it].end },
            done = Array(item.segments.size) { AtomicLong(item.segments[it].done) },
            resumable = item.resumable,
            etag = item.etag,
            part = File(item.dir, item.fileName + Links.PART_SUFFIX),
            cookie = item.cookie,
            referer = item.referer,
        )
        val connections = state.start.size
        val label = if (connections > 1) "$connections connexions" else "1 connexion"
        repo.update(id) {
            if (it.status == DlStatus.CONNECTING) it.copy(status = DlStatus.RUNNING, info = label) else it
        }

        try {
            coroutineScope {
                val ticker = launch {
                    var last = state.total()
                    var lastTime = System.nanoTime()
                    var smooth = 0.0
                    while (isActive) {
                        delay(500)
                        val now = state.total()
                        val time = System.nanoTime()
                        val instant = (now - last) * 1e9 / max(1L, time - lastTime)
                        smooth = if (smooth == 0.0) instant else smooth * 0.7 + instant * 0.3
                        last = now
                        lastTime = time
                        repo.update(id) {
                            it.copy(
                                downloadedBytes = now,
                                speed = smooth.toLong(),
                                segments = state.snapshot(),
                            )
                        }
                    }
                }
                try {
                    (0 until connections).map { index ->
                        async(Dispatchers.IO) { segmentLoop(item.url, index, state, cfg) }
                    }.awaitAll()
                } finally {
                    ticker.cancel()
                }
            }
        } finally {
            // Toujours enregistrer la position exacte (pause, erreur, fin).
            repo.update(id) {
                it.copy(downloadedBytes = state.total(), segments = state.snapshot(), speed = 0)
            }
            repo.saveNow()
        }

        val done = state.total()
        if (item.totalBytes > 0 && done < item.totalBytes) {
            throw IOException("Téléchargement incomplet")
        }
        val dir = File(item.dir)
        var target = File(dir, item.fileName)
        if (target.exists()) target = Links.uniqueFile(dir, item.fileName)
        if (!state.part.renameTo(target)) {
            throw FatalDownloadException("Impossible d'enregistrer le fichier final")
        }
        val finalName = target.name
        repo.update(id) {
            it.copy(fileName = finalName, totalBytes = done, downloadedBytes = done, segments = emptyList())
        }
        return target
    }

    /** Interroge le serveur : taille, reprise possible, nom du fichier ; puis prépare le fichier. */
    private suspend fun prepare(item: DownloadItem, cfg: SettingsData): DownloadItem {
        val request = baseRequest(item.url, cfg, item.cookie, item.referer).header("Range", "bytes=0-0").build()
        var total = -1L
        var resumable = false
        var etag: String? = null
        var mime: String? = null
        var disposition: String? = null
        var finalUrl = item.url

        withCall(client.newCall(request)) { resp, _ ->
            if (!resp.isSuccessful) throw httpError(resp.code)
            mime = resp.header("Content-Type")
            disposition = resp.header("Content-Disposition")
            finalUrl = resp.request.url.toString()
            if (resp.code == 206) {
                total = resp.header("Content-Range")?.substringAfterLast('/')?.trim()?.toLongOrNull() ?: -1
                resumable = total > 0
            } else {
                total = resp.header("Content-Length")?.toLongOrNull() ?: -1
            }
            etag = resp.header("ETag")?.takeIf { !it.startsWith("W/") }
        }

        if (item.videoFallback && mime?.startsWith("text/html", ignoreCase = true) == true) {
            throw HtmlPageException()
        }

        var dirPath = item.dir
        var name = item.fileName
        if (item.autoName) {
            name = Links.fileName(finalUrl, disposition, mime)
            if (cfg.sortByCategory) dirPath = File(item.dir, Links.category(name)).path
            val reserved = repo.items.value.filter { it.id != item.id }
                .map { File(it.dir, it.fileName).path }.toSet()
            name = Links.uniqueFile(File(dirPath), name, reserved).name
        }
        val dir = File(dirPath)
        if (!dir.exists() && !dir.mkdirs() && !dir.exists()) {
            throw FatalDownloadException("Impossible de créer le dossier ${dir.path}")
        }
        if (total > 0 && dir.usableSpace in 1 until total) {
            throw FatalDownloadException("Espace de stockage insuffisant")
        }

        val count = if (resumable && total >= 2L * 1024 * 1024)
            min(cfg.connections.toLong(), max(1L, total / (1024 * 1024))).toInt()
        else 1
        val segments = ArrayList<Segment>(count)
        if (total > 0) {
            val chunk = total / count
            for (i in 0 until count) {
                val start = i * chunk
                val end = if (i == count - 1) total - 1 else start + chunk - 1
                segments.add(Segment(start, end, 0))
            }
        } else {
            segments.add(Segment(0, -1, 0))
        }

        val part = File(dir, name + Links.PART_SUFFIX)
        try {
            RandomAccessFile(part, "rw").use { it.setLength(if (total > 0) total else 0) }
        } catch (e: IOException) {
            throw FatalDownloadException("Écriture impossible dans ${dir.path}")
        }

        return item.copy(
            fileName = name, dir = dirPath, totalBytes = total, resumable = resumable,
            etag = etag, segments = segments, downloadedBytes = 0,
        )
    }

    /** Télécharge un segment, avec nouvelles tentatives et reprise à l'octet près. */
    private suspend fun segmentLoop(url: String, index: Int, state: State, cfg: SettingsData) {
        var attempt = 0
        while (true) {
            if (!state.resumable) state.done[index].set(0)
            val before = state.done[index].get()
            val pos = state.start[index] + before
            val end = state.end[index]
            if (end >= 0 && pos > end) return
            try {
                fetch(url, index, pos, end, state, cfg)
                if (end < 0) return
                if (state.start[index] + state.done[index].get() > end) return
                if (state.done[index].get() == before) throw IOException("Connexion interrompue")
                attempt = 0
            } catch (e: FatalDownloadException) {
                throw e
            } catch (e: IOException) {
                coroutineContext.ensureActive()
                if (state.done[index].get() > before) attempt = 0
                attempt++
                if (attempt > cfg.retries) throw e
                delay(min(1000L shl min(attempt, 4), 15_000L))
            }
        }
    }

    private suspend fun fetch(
        url: String, index: Int, pos: Long, end: Long, state: State, cfg: SettingsData,
    ) {
        val builder = baseRequest(url, cfg, state.cookie, state.referer)
        if (state.resumable) {
            builder.header("Range", "bytes=$pos-" + if (end >= 0) end.toString() else "")
            state.etag?.let { builder.header("If-Range", it) }
        }
        withCall(client.newCall(builder.build())) { resp, active ->
            if (state.resumable) {
                if (resp.code == 200) {
                    throw FatalDownloadException("Le fichier a changé sur le serveur : relancez le téléchargement")
                }
                if (resp.code != 206) throw httpError(resp.code)
            } else if (!resp.isSuccessful) {
                throw httpError(resp.code)
            }
            val body = resp.body ?: throw IOException("Réponse vide")
            RandomAccessFile(state.part, "rw").use { raf ->
                if (!state.resumable) raf.setLength(0)
                raf.seek(pos)
                val buffer = ByteArray(BUFFER_SIZE)
                val input = body.byteStream()
                var remaining = if (end >= 0) end - pos + 1 else Long.MAX_VALUE
                while (remaining > 0) {
                    val n = input.read(buffer, 0, min(buffer.size.toLong(), remaining).toInt())
                    if (n < 0) break
                    raf.write(buffer, 0, n)
                    state.done[index].addAndGet(n.toLong())
                    remaining -= n
                    limiter.acquire(n)
                    if (!active()) throw IOException("Annulé")
                }
            }
        }
    }

    private fun baseRequest(
        url: String, cfg: SettingsData, cookie: String = "", referer: String = "",
    ): Request.Builder {
        val b = Request.Builder().url(url)
            .header("User-Agent", cfg.userAgent.ifBlank { SettingsData.DEFAULT_UA })
            .header("Accept", "*/*")
            .header("Accept-Encoding", "identity")
        if (cookie.isNotBlank()) b.header("Cookie", cookie)
        if (referer.isNotBlank()) b.header("Referer", referer)
        return b
    }

    private fun httpError(code: Int): IOException {
        val retryable = code >= 500 || code == 408 || code == 429
        val message = when (code) {
            401, 403 -> "Accès refusé par le serveur (HTTP $code) : le lien a peut-être expiré"
            404, 410 -> "Fichier introuvable (HTTP $code)"
            416 -> "Reprise refusée par le serveur (HTTP 416)"
            else -> "Erreur du serveur (HTTP $code)"
        }
        return if (retryable) IOException(message) else FatalDownloadException(message)
    }

    /** Petit téléchargement en mémoire (fichiers .torrent distants). */
    suspend fun fetchBytes(url: String, maxBytes: Int = 20 * 1024 * 1024): ByteArray {
        val request = baseRequest(url, settings.value).build()
        var bytes = ByteArray(0)
        withCall(client.newCall(request)) { resp, _ ->
            if (!resp.isSuccessful) throw httpError(resp.code)
            val body = resp.body ?: throw IOException("Réponse vide")
            if (body.contentLength() > maxBytes) throw FatalDownloadException("Fichier trop volumineux")
            bytes = body.bytes()
        }
        return bytes
    }

    /**
     * Exécute un appel bloquant OkHttp de façon annulable : si la coroutine est annulée
     * (pause, suppression), l'appel est coupé immédiatement, même en pleine lecture.
     */
    private suspend fun withCall(call: Call, block: (Response, () -> Boolean) -> Unit) {
        coroutineScope {
            val watcher = launch(start = CoroutineStart.UNDISPATCHED) {
                try {
                    awaitCancellation()
                } finally {
                    call.cancel()
                }
            }
            try {
                call.execute().use { resp -> block(resp) { isActive } }
            } catch (e: IOException) {
                ensureActive()
                throw e
            } finally {
                watcher.cancel()
            }
        }
    }

    companion object {
        private const val BUFFER_SIZE = 128 * 1024
    }
}
