package com.dlvibestudio.dlturbo.ui

import android.content.Context
import android.net.Uri

/**
 * Filtrage des requêtes du navigateur : domaines publicitaires / traqueurs (liste dans
 * assets/blocklist.txt), quelques motifs d'URL, et scripts injectés (anti-pop-up, YouTube).
 */
class AdBlocker(context: Context) {

    private val domains: Set<String> = try {
        context.assets.open("blocklist.txt").bufferedReader().useLines { lines ->
            lines.map { it.trim().lowercase() }
                .filter { it.isNotEmpty() && !it.startsWith("#") }
                .toHashSet()
        }
    } catch (_: Exception) {
        emptySet()
    }

    /** Vrai si [url] doit être bloquée. [pageHost] = site affiché (pour ne jamais bloquer le site lui-même). */
    fun shouldBlock(url: Uri, pageHost: String?): Boolean {
        val host = url.host?.lowercase() ?: return false
        if (hostBlocked(host)) {
            // Visiter volontairement un domaine de la liste n'est pas bloqué par ce test.
            return pageHost == null || !sameSite(host, pageHost)
        }
        val full = host + (url.path ?: "")
        if (host.startsWith("adservice.google.")) return true
        if (isYoutube(host) && YT_PATTERNS.any { full.contains(it) }) return true
        if (isYoutube(pageHost ?: "") && host != pageHost) {
            if (PAGE_AD_PATTERNS.any { full.contains(it) }) return true
        }
        return false
    }

    private fun hostBlocked(host: String): Boolean {
        var h = host
        while (true) {
            if (h in domains) return true
            val dot = h.indexOf('.')
            if (dot < 0 || h.indexOf('.', dot + 1) < 0) return false
            h = h.substring(dot + 1)
        }
    }

    private fun sameSite(a: String, b: String): Boolean = site(a) == site(b)

    private fun site(host: String): String {
        val parts = host.split('.')
        return if (parts.size <= 2) host else parts.takeLast(2).joinToString(".")
    }

    private fun isYoutube(host: String) = host.endsWith("youtube.com") || host.endsWith("youtu.be")

    companion object {
        /** Requêtes publicitaires propres à YouTube (même domaine que le contenu). */
        private val YT_PATTERNS = listOf(
            "/pagead/", "/api/stats/ads", "/ptracking", "/get_midroll_", "/api/stats/atr",
            "/youtubei/v1/log_event", "/generate_204_ad",
        )
        private val PAGE_AD_PATTERNS = listOf("/pagead/", "/ads/ga-audiences", "/adsbygoogle.js")

        /** Masquage visuel des encarts publicitaires (CSS). Volontairement prudent pour ne rien casser. */
        const val COSMETIC_CSS = """
            .adsbygoogle, ins.adsbygoogle, [id^="google_ads_"], [id^="div-gpt-ad"], [data-ad-slot],
            [data-ad-client], .ad-banner, .ad-container, .ad-slot, .advertisement, .sponsored-ad,
            #ad-container, #ads, #ad-banner, iframe[src*="doubleclick.net"], iframe[src*="googlesyndication"],
            iframe[id^="google_ads_iframe"], .taboola, #taboola-below-article-thumbnails, .outbrain,
            [id^="taboola"], [class*="OUTBRAIN"], [id^="outbrain"], .mgid-container, [id^="mgid"],
            a[href*="doubleclick.net"], a[href*="adsterra"], a[href*="exoclick"] { display: none !important; }
        """

        /**
         * Anti pop-up, injecté au tout début de chaque page : window.open sans toucher récent est
         * ignoré, et les clics « fantômes » générés par script sur des liens target=_blank aussi.
         */
        val POPUP_SCRIPT: String = """
            (function(){
              if (window.__dltPop) return; window.__dltPop = true;
              var lastTouch = 0;
              function mark(){ lastTouch = Date.now(); }
              ['touchstart','mousedown','keydown'].forEach(function(t){ window.addEventListener(t, mark, true); });
              var realOpen = window.open;
              window.open = function(){
                if (Date.now() - lastTouch > 800) { return null; }
                return realOpen.apply(window, arguments);
              };
              document.addEventListener('click', function(e){
                var a = e.target && e.target.closest ? e.target.closest('a[target=_blank]') : null;
                if (a && !e.isTrusted) { e.preventDefault(); e.stopPropagation(); }
              }, true);
            })();
        """.trimIndent()

        /** Masque les encarts publicitaires de la page. */
        val COSMETIC_SCRIPT: String = """
            (function(){
              if (window.__dltCss) return; window.__dltCss = true;
              var css = ${jsString(COSMETIC_CSS)};
              function addCss(){
                if (document.getElementById('__dlt_css')) return;
                var s = document.createElement('style'); s.id='__dlt_css'; s.textContent = css;
                (document.head || document.documentElement).appendChild(s);
              }
              addCss();
              document.addEventListener('DOMContentLoaded', addCss);
            })();
        """.trimIndent()

        /**
         * YouTube (site mobile) : ajoute une petite icône de téléchargement sur la miniature de chaque
         * vidéo, comme dans Vidmate. Un clic appelle l'interface native « DLT ».
         */
        val YOUTUBE_BUTTONS_SCRIPT: String = """
            (function(){
              if (window.__dltBtn) return; window.__dltBtn = true;
              var ICON = '<svg viewBox="0 0 24 24" width="18" height="18"><path d="M5 20h14v-2H5v2zM19 9h-4V3H9v6H5l7 7 7-7z"/></svg>';
              var css = '.dlt-btn{position:absolute;right:6px;bottom:6px;width:34px;height:34px;border-radius:17px;' +
                'background:#F5B301;border:2px solid rgba(0,0,0,.35);display:flex;align-items:center;justify-content:center;' +
                'z-index:2147483000;padding:0;box-shadow:0 1px 4px rgba(0,0,0,.5)}.dlt-btn svg{fill:#1a1300}';
              function addCss(){
                if (document.getElementById('__dlt_btn_css')) return;
                var s = document.createElement('style'); s.id='__dlt_btn_css'; s.textContent = css;
                (document.head || document.documentElement).appendChild(s);
              }
              function videoUrl(a){
                var h = a.getAttribute('href') || '';
                if (h.indexOf('/watch?v=') >= 0 || h.indexOf('/shorts/') >= 0) {
                  try { return new URL(h, location.href).href; } catch(e){}
                }
                return null;
              }
              function decorate(){
                addCss();
                var links = document.querySelectorAll('a[href*="/watch?v="], a[href*="/shorts/"]');
                for (var i = 0; i < links.length; i++) {
                  var a = links[i];
                  if (a.__dlt) continue;
                  if (!a.querySelector('img, yt-image, [class*="thumbnail"], [class*="Thumbnail"], ytm-thumbnail-cover')) continue;
                  var r = a.getBoundingClientRect();
                  if (r.width < 90 || r.height < 50) continue;
                  if (!videoUrl(a)) continue;
                  a.__dlt = true;
                  if (getComputedStyle(a).position === 'static') a.style.position = 'relative';
                  var b = document.createElement('span');
                  b.className = 'dlt-btn';
                  b.setAttribute('role', 'button');
                  b.innerHTML = ICON;
                  b.addEventListener('click', function(ev){
                    ev.preventDefault(); ev.stopPropagation();
                    if (ev.stopImmediatePropagation) ev.stopImmediatePropagation();
                    var anchor = ev.currentTarget.parentNode;
                    var u = anchor ? videoUrl(anchor) : null;
                    if (u && window.DLT) window.DLT.download(u);
                  }, true);
                  a.appendChild(b);
                }
              }
              setInterval(decorate, 1000);
              document.addEventListener('DOMContentLoaded', decorate);
            })();
        """.trimIndent()

        /**
         * YouTube : retire les données publicitaires des réponses avant que le lecteur ne les lise,
         * saute les pubs restantes et masque les encarts. YouTube change souvent : à ajuster au besoin.
         */
        val YOUTUBE_SCRIPT: String = """
            (function(){
              if (window.__dltYT) return; window.__dltYT = true;
              var KEYS = ['adPlacements','adSlots','playerAds','adBreakHeartbeatParams'];
              function clean(o){
                if (o && typeof o === 'object') {
                  for (var i=0;i<KEYS.length;i++){ if (KEYS[i] in o) { try { delete o[KEYS[i]]; } catch(e){} } }
                  if (o.playerResponse) clean(o.playerResponse);
                  if (o.response) clean(o.response);
                }
                return o;
              }
              // 1) Réponse initiale de la page
              try {
                var _ipr;
                Object.defineProperty(window, 'ytInitialPlayerResponse', {
                  configurable: true,
                  get: function(){ return _ipr; },
                  set: function(v){ _ipr = clean(v); }
                });
              } catch(e){}
              // 2) JSON.parse
              var _parse = JSON.parse;
              JSON.parse = function(){
                var r = _parse.apply(this, arguments);
                try { if (r && typeof r === 'object') clean(r); } catch(e){}
                return r;
              };
              // 3) fetch (requêtes /youtubei/v1/player, /next …)
              var _fetch = window.fetch;
              if (_fetch) {
                window.fetch = function(){
                  var args = arguments;
                  return _fetch.apply(this, args).then(function(resp){
                    try {
                      var u = (typeof args[0] === 'string') ? args[0] : (args[0] && args[0].url) || '';
                      if (u.indexOf('/youtubei/v1/') >= 0) {
                        return resp.clone().text().then(function(t){
                          if (t.indexOf('adPlacements') < 0 && t.indexOf('playerAds') < 0 && t.indexOf('adSlots') < 0) return resp;
                          var j = _parse(t); clean(j);
                          return new Response(JSON.stringify(j), {status: resp.status, statusText: resp.statusText, headers: resp.headers});
                        }).catch(function(){ return resp; });
                      }
                    } catch(e){}
                    return resp;
                  });
                };
              }
              // 4) Filet de sécurité : saute les pubs qui passent quand même
              var AD_CSS = 'ytm-promoted-sparkles-web-renderer, ytm-companion-ad-renderer, ytm-promoted-video-renderer, ' +
                'ytm-ad-slot-renderer, ytm-statement-banner-renderer, ytm-brand-video-singleton-renderer, ' +
                '#player-ads, .ad-container, .ytp-ad-overlay-container, ytd-ad-slot-renderer, ' +
                'ytm-in-feed-ad-layout-renderer, ytm-display-ad-renderer, .ytp-ad-module { display:none !important; }';
              function addCss(){
                if (document.getElementById('__dlt_yt_css')) return;
                var s = document.createElement('style'); s.id='__dlt_yt_css'; s.textContent = AD_CSS;
                (document.head || document.documentElement).appendChild(s);
              }
              addCss(); document.addEventListener('DOMContentLoaded', addCss);
              setInterval(function(){
                try {
                  var skip = document.querySelector('.ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-skip-ad-button, .videoAdUiSkipButton');
                  if (skip) skip.click();
                  var player = document.querySelector('.html5-video-player, #player-container-id, #movie_player');
                  var inAd = player && (player.classList.contains('ad-showing') || player.classList.contains('ad-interrupting'));
                  var v = document.querySelector('video');
                  if (inAd && v && isFinite(v.duration) && v.duration > 0) {
                    v.muted = true; v.playbackRate = 16;
                    try { v.currentTime = v.duration; } catch(e){}
                  }
                } catch(e){}
              }, 400);
            })();
        """.trimIndent()

        /** Échappe un texte multi-lignes en chaîne JavaScript. */
        private fun jsString(s: String): String {
            val sb = StringBuilder("\"")
            for (ch in s.trim()) {
                when (ch) {
                    '\\' -> sb.append("\\\\")
                    '"' -> sb.append("\\\"")
                    '\n' -> sb.append(' ')
                    '\r' -> {}
                    else -> sb.append(ch)
                }
            }
            return sb.append('"').toString()
        }
    }
}
