package com.dlvibestudio.dlturbo.ui

import android.net.Uri

/** Un flux ou fichier média repéré dans le trafic d'une page. */
data class MediaHit(val url: String, val kind: String, val referer: String) {
    val isAudio: Boolean get() = kind in AUDIO_KINDS
    val isStream: Boolean get() = kind == "HLS" || kind == "DASH"
    val extension: String
        get() = when (kind) {
            "WEBM" -> "webm"
            "MKV" -> "mkv"
            "MOV" -> "mov"
            "FLV" -> "flv"
            "MP3" -> "mp3"
            "M4A" -> "m4a"
            "AAC" -> "aac"
            "OGG" -> "ogg"
            else -> "mp4"
        }

    companion object {
        val AUDIO_KINDS = setOf("MP3", "M4A", "AAC", "OGG")
    }
}

/** Un épisode (ou élément de liste de lecture) trouvé dans une page. */
data class EpisodeItem(val title: String, val url: String, val number: Int)

data class EpisodeList(val pageTitle: String, val pageUrl: String, val items: List<EpisodeItem>)

/** Une image trouvée dans une page. */
data class PageImage(val url: String, val width: Int)

/**
 * Repère les flux vidéo/audio (HLS, DASH, mp4…) qui passent dans une page, y compris dans ses lecteurs
 * intégrés (iframes), et fournit les scripts d'icône de téléchargement et de recherche d'épisodes.
 */
object MediaSniffer {

    private val KINDS = mapOf(
        "m3u8" to "HLS", "mpd" to "DASH", "mp4" to "MP4", "m4v" to "MP4", "webm" to "WEBM",
        "mkv" to "MKV", "mov" to "MOV", "flv" to "FLV", "mp3" to "MP3", "m4a" to "M4A",
        "aac" to "AAC", "ogg" to "OGG",
    )

    private val NOISE = listOf(
        "/ads/", "/ad/", "advert", "preroll", "pre-roll", "doubleclick", "googlesyndication", "/vast",
        "adserver", "analytics", "tracking", "pixel", "/banner", "sponsor",
    )

    /** Type de média d'après l'adresse, ou null si ce n'est pas un média. */
    fun classify(url: Uri): String? {
        val scheme = url.scheme?.lowercase()
        if (scheme != "http" && scheme != "https") return null
        val path = (url.path ?: "").lowercase()
        val dot = path.lastIndexOf('.')
        if (dot >= 0) KINDS[path.substring(dot + 1)]?.let { return it }
        if (path.contains(".m3u8")) return "HLS"
        return null
    }

    fun noisy(url: String): Boolean {
        val u = url.lowercase()
        return NOISE.any { u.contains(it) }
    }

    /** Choisit le meilleur flux parmi ceux repérés (liste maître HLS > DASH > fichier vidéo > audio). */
    fun pick(hits: List<MediaHit>): MediaHit? {
        if (hits.isEmpty()) return null
        fun score(h: MediaHit): Int {
            val p = h.url.lowercase()
            return when (h.kind) {
                "HLS" -> 30 + if (p.contains("master") || p.contains("index") || p.contains("playlist")) 5 else 0
                "DASH" -> 25
                "MP4", "WEBM", "MKV", "MOV" -> 20
                "FLV" -> 15
                else -> 5
            }
        }
        // À score égal, le plus récent : les publicités de début passent avant le contenu.
        return hits.withIndex().maxWithOrNull(compareBy({ score(it.value) }, { it.index }))?.value
    }

    /** Icône de téléchargement posée sur chaque lecteur vidéo de la page, même à l'arrêt. */
    val MEDIA_BUTTON_SCRIPT: String = """
        (function(){
          if (window.__dltMedia) return; window.__dltMedia = true;
          var ICON = '<svg viewBox="0 0 24 24" width="22" height="22"><path d="M5 20h14v-2H5v2zM19 9h-4V3H9v6H5l7 7 7-7z"/></svg>';
          var btns = new Map();
          var root = null;
          function ensureRoot(){
            if (root && root.isConnected) return root;
            root = document.createElement('div');
            root.id = '__dlt_media_root';
            root.style.cssText = 'position:fixed;left:0;top:0;width:0;height:0;z-index:2147483647;pointer-events:none';
            (document.body || document.documentElement).appendChild(root);
            return root;
          }
          function makeBtn(el, kind){
            var b = document.createElement('button');
            b.type = 'button';
            b.innerHTML = ICON;
            b.setAttribute('aria-label', 'Telecharger');
            b.style.cssText = 'position:fixed;width:40px;height:40px;border-radius:20px;background:#F5B301;' +
              'border:2px solid rgba(0,0,0,.4);display:flex;align-items:center;justify-content:center;padding:0;' +
              'margin:0;pointer-events:auto;box-shadow:0 1px 6px rgba(0,0,0,.6);opacity:.95';
            b.firstChild.style.fill = '#1a1300';
            var last = 0;
            function act(e){
              e.preventDefault(); e.stopPropagation();
              var now = Date.now(); if (now - last < 600) return; last = now;
              var src = '';
              try { src = (kind === 'video') ? (el.currentSrc || el.src || '') : (el.src || ''); } catch(x) {}
              try { DLM.tap(src, kind); } catch(x) {}
            }
            b.addEventListener('click', act, true);
            b.addEventListener('touchend', act, true);
            ensureRoot().appendChild(b);
            return b;
          }
          function bigIframe(f){
            var r = f.getBoundingClientRect();
            if (r.width < 220 || r.height < 120) return false;
            var s = (f.src || '').toLowerCase();
            if (s.indexOf('http') !== 0) return false;
            if (/doubleclick|googlesyndication|adsterra|adservice|\/ads?\/|banner|recaptcha|plugins\/|widgets/.test(s)) return false;
            return true;
          }
          function tick(){
            var els = [];
            var vs = document.getElementsByTagName('video');
            for (var i = 0; i < vs.length; i++) {
              var r = vs[i].getBoundingClientRect();
              if (r.width >= 160 && r.height >= 90) els.push([vs[i], 'video']);
            }
            var fs = document.getElementsByTagName('iframe');
            for (var j = 0; j < fs.length; j++) { if (bigIframe(fs[j])) els.push([fs[j], 'iframe']); }
            var alive = new Set();
            els.forEach(function(p){
              var el = p[0], r = el.getBoundingClientRect();
              var vis = r.bottom > 0 && r.right > 0 && r.top < innerHeight && r.left < innerWidth;
              var b = btns.get(el);
              if (!b) { b = makeBtn(el, p[1]); btns.set(el, b); }
              alive.add(el);
              b.style.display = vis ? 'flex' : 'none';
              if (vis) {
                b.style.left = Math.max(4, Math.min(innerWidth - 46, r.right - 50)) + 'px';
                b.style.top = Math.max(4, Math.min(innerHeight - 46, r.top + 8)) + 'px';
              }
            });
            btns.forEach(function(b, el){ if (!alive.has(el)) { b.remove(); btns.delete(el); } });
            try { DLM.seen(els.length); } catch(x) {}
          }
          setInterval(tick, 700);
          document.addEventListener('fullscreenchange', tick);
        })();
    """.trimIndent()

    /** Lance la lecture en sourdine et clique sur les boutons « lecture » : sert à repérer le flux d'un épisode. */
    val AUTOPLAY_SCRIPT: String = """
        (function(){
          if (window.__dltAuto) return; window.__dltAuto = true;
          var t0 = Date.now();
          var SEL = '.vjs-big-play-button,.jw-icon-display,.jw-display-icon-container,.plyr__control--overlaid,' +
            '.play-button,.btn-play,#play,.play,[aria-label="Play"],[aria-label="Lire"],[title="Play"],' +
            'button[class*="play"],div[class*="play-btn"],div[class*="PlayButton"],.fp-play,.ytp-large-play-button';
          function step(){
            if (Date.now() - t0 > 30000) { clearInterval(iv); return; }
            try {
              var vs = document.getElementsByTagName('video');
              for (var i = 0; i < vs.length; i++) {
                vs[i].muted = true;
                var p = vs[i].play(); if (p && p.catch) p.catch(function(){});
              }
            } catch(e) {}
            try {
              var els = document.querySelectorAll(SEL);
              for (var j = 0; j < els.length && j < 3; j++) els[j].click();
            } catch(e) {}
          }
          var iv = setInterval(step, 900);
        })();
    """.trimIndent()

    /** Cherche dans la page les liens d'épisodes (ou, à défaut, la plus grande liste de liens semblables). */
    val EPISODES_SCRIPT: String = """
        (function(){
          var re = /(episode|épisode|\bep[\s._-]*\d|saison|season|\bs\d{1,2}[\s._-]*e\d{1,3}|\be\d{1,3}\b|\d+x\d+)/i;
          var origin = location.origin;
          var seen = {}, all = [];
          var as = document.querySelectorAll('a[href]');
          for (var i = 0; i < as.length; i++) {
            var a = as[i], href = a.href;
            if (!href || href.indexOf(origin) !== 0 || href.indexOf('#') === href.length - 1) continue;
            var base = href.split('#')[0];
            if (base === location.href.split('#')[0] || seen[base]) continue;
            var text = (a.textContent || a.title || '').replace(/\s+/g, ' ').trim();
            seen[base] = 1;
            all.push({ t: text, u: base, e: re.test(text) || re.test(decodeURIComponent(base)) });
          }
          var cand = all.filter(function(x){ return x.e; });
          if (cand.length < 2) {
            var groups = {};
            all.forEach(function(x){
              var path = x.u.replace(origin, '').split('?')[0].replace(/\d+/g, '#');
              (groups[path] = groups[path] || []).push(x);
            });
            var best = [];
            for (var k in groups) { if (groups[k].length > best.length) best = groups[k]; }
            cand = best.length >= 3 ? best : cand;
          }
          var out = cand.slice(0, 600).map(function(x){
            var m = x.t.match(/(?:episode|épisode|ep|e)\s*[-._]?\s*(\d+)/i) || x.u.match(/(\d+)[^\d]*${'$'}/);
            var title = x.t || decodeURIComponent(x.u.split('/').filter(Boolean).pop() || x.u);
            return { t: title.substring(0, 90), u: x.u, n: m ? parseInt(m[1], 10) : 0 };
          });
          return JSON.stringify({ page: document.title || '', items: out });
        })();
    """.trimIndent()

    /** Images de la page (balises img, liens vers des images). */
    val IMAGES_SCRIPT: String = """
        (function(){
          var seen = {}, out = [];
          function add(u, w){
            if (!u || u.indexOf('http') !== 0 || u.indexOf('data:') === 0 || seen[u]) return;
            seen[u] = 1; out.push({ u: u, w: w || 0 });
          }
          var imgs = document.getElementsByTagName('img');
          for (var i = 0; i < imgs.length; i++) {
            var im = imgs[i];
            var w = im.naturalWidth || im.width || 0, h = im.naturalHeight || im.height || 0;
            if (w < 200 || h < 150) continue;
            var best = im.currentSrc || im.src;
            var ss = im.getAttribute('srcset');
            if (ss) {
              var top = 0;
              ss.split(',').forEach(function(p){
                var parts = p.trim().split(/\s+/);
                var d = parseInt(parts[1], 10) || 0;
                if (parts[0] && d >= top) { top = d; best = new URL(parts[0], location.href).href; }
              });
            }
            add(best, w);
          }
          var as = document.querySelectorAll('a[href]');
          for (var j = 0; j < as.length; j++) {
            if (/\.(jpe?g|png|webp|gif)(\?|${'$'})/i.test(as[j].href)) add(as[j].href, 0);
          }
          return JSON.stringify(out.slice(0, 300));
        })();
    """.trimIndent()
}
