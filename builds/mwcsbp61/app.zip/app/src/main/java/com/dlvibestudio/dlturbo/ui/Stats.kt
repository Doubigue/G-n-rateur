package com.dlvibestudio.dlturbo.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.dlvibestudio.dlturbo.data.DlStatus
import com.dlvibestudio.dlturbo.data.DownloadItem
import com.dlvibestudio.dlturbo.engine.Links
import com.dlvibestudio.dlturbo.util.Format
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Statistiques calculées sur les téléchargements terminés (volume par période, par site et par type). */
@Composable
fun StatsDialog(items: List<DownloadItem>, onDismiss: () -> Unit) {
    val done = items.filter { it.status == DlStatus.COMPLETED && it.finishedAt > 0 }
    fun bytes(it: DownloadItem) = maxOf(it.totalBytes, it.downloadedBytes).coerceAtLeast(0)

    val cal = Calendar.getInstance()
    val startToday = (cal.clone() as Calendar).apply {
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis
    val startMonth = (cal.clone() as Calendar).apply {
        set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis
    val today = done.filter { it.finishedAt >= startToday }
    val month = done.filter { it.finishedAt >= startMonth }

    // 7 derniers jours
    val day = 24 * 3600_000L
    val fmt = SimpleDateFormat("EEE d", Locale.getDefault())
    val week = (6 downTo 0).map { back ->
        val from = startToday - back * day
        val sum = done.filter { it.finishedAt >= from && it.finishedAt < from + day }.sumOf { bytes(it) }
        fmt.format(Date(from)) to sum
    }
    val weekMax = week.maxOf { it.second }.coerceAtLeast(1)

    val bySite = done.groupBy { Links.hostOf(it.url).ifBlank { "autre" } }
        .mapValues { e -> e.value.sumOf { bytes(it) } }.entries.sortedByDescending { it.value }.take(5)
    val byType = done.groupBy { Links.category(it.fileName) }
        .mapValues { e -> e.value.sumOf { bytes(it) } }.entries.sortedByDescending { it.value }.take(5)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Statistiques") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Line("Aujourd'hui", "${today.size} fichier(s) · ${Format.bytes(today.sumOf { bytes(it) })}")
                Line("Ce mois-ci", "${month.size} fichier(s) · ${Format.bytes(month.sumOf { bytes(it) })}")
                Line("Total", "${done.size} fichier(s) · ${Format.bytes(done.sumOf { bytes(it) })}")
                Title("7 derniers jours")
                week.forEach { (label, v) ->
                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Text(label, modifier = Modifier.padding(end = 8.dp).weight(0.25f), style = MaterialTheme.typography.bodySmall)
                        LinearProgressIndicator(
                            progress = { v.toFloat() / weekMax },
                            modifier = Modifier.weight(0.5f).height(6.dp),
                        )
                        Text(
                            Format.bytes(v),
                            modifier = Modifier.padding(start = 8.dp).weight(0.3f),
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
                Title("Par site")
                bySite.forEach { Line(it.key, Format.bytes(it.value)) }
                Title("Par type")
                byType.forEach { Line(it.key, Format.bytes(it.value)) }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fermer") } },
    )
}

@Composable
private fun Title(t: String) =
    Text(t, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 10.dp))

@Composable
private fun Line(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
    }
}
