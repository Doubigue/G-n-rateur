@file:OptIn(ExperimentalMaterial3Api::class)

package com.dlvibestudio.dlturbo.ui

import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PlaylistPlay
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.dlvibestudio.dlturbo.App
import com.dlvibestudio.dlturbo.engine.Links

// ---------------------------------------------------------------------------------------------
// Médias détectés dans la page (le bouton doré posé sur la vidéo ouvre cette feuille)
// ---------------------------------------------------------------------------------------------

@Composable
fun MediaSheet(hub: WebHub, tab: WebTab, onDismiss: () -> Unit) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val hits = tab.media.toList().asReversed() // les plus récents d'abord
    val videos = hits.filter { !it.isAudio }
    val audios = hits.filter { it.isAudio }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(
            Modifier.fillMaxWidth().navigationBarsPadding().verticalScroll(rememberScrollState())
                .padding(bottom = 16.dp),
        ) {
            Text(
                "Télécharger depuis cette page",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
            )
            if (hits.isEmpty()) {
                Text(
                    "Aucun flux détecté pour l'instant. Lancez la lecture de la vidéo : les flux " +
                        "(HLS, MP4…) apparaissent ici dès qu'ils sont repérés.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                )
            }
            (videos + audios).forEach { hit ->
                HitRow(
                    hit = hit,
                    onVideo = { hub.downloadMedia(tab, hit, audio = false); onDismiss() },
                    onMp3 = { hub.downloadMedia(tab, hit, audio = true); onDismiss() },
                )
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            }

            Spacer(Modifier.height(8.dp))
            if (tab.embed.isNotBlank()) {
                ActionRow("Extraire depuis le lecteur de la page", "Essaie l'extracteur sur le lecteur intégré") {
                    hub.formatRequest.value = tab.embed
                    onDismiss()
                }
            }
            ActionRow("Analyser cette page", "Choix des formats MP4 / MP3 / WAV (sites pris en charge)") {
                hub.formatRequest.value = tab.url
                onDismiss()
            }
            ActionRow("Liste d'épisodes / playlist de la page", "Saisons et épisodes : de 1 à la fin") {
                hub.scanEpisodes(tab)
                onDismiss()
            }
            ActionRow("Images de la page", "Choisir et télécharger les images") {
                hub.scanImages(tab)
                onDismiss()
            }
        }
    }
}

@Composable
private fun HitRow(hit: MediaHit, onVideo: () -> Unit, onMp3: () -> Unit) {
    val name = Uri.parse(hit.url).lastPathSegment ?: hit.url
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(
            hit.kind,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(MaterialTheme.colorScheme.primary)
                .padding(horizontal = 8.dp, vertical = 3.dp),
        )
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
            Text(
                Links.hostOf(hit.url),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        if (hit.isAudio) {
            TextButton(onClick = onVideo) { Text("Audio") }
        } else {
            TextButton(onClick = onVideo) { Text("Vidéo") }
            TextButton(onClick = onMp3) { Text("MP3") }
        }
    }
}

@Composable
private fun ActionRow(title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Liste d'épisodes (séries) : sélection d'une plage 1 → N puis recherche automatique des vidéos
// ---------------------------------------------------------------------------------------------

@Composable
fun EpisodesSheet(hub: WebHub, list: EpisodeList, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var reversed by remember(list) { mutableStateOf(false) }
    val checked = remember(list) { mutableStateListOf<Boolean>().apply { repeat(list.items.size) { add(true) } } }
    var from by remember(list) { mutableStateOf("1") }
    var to by remember(list) { mutableStateOf("") }
    var audio by remember(list) { mutableStateOf(false) }
    var prefix by remember(list) { mutableStateOf(cleanTitle(list.pageTitle)) }

    val shown = if (reversed) list.items.reversed() else list.items
    // Les cases suivent l'ordre d'affichage : on réinitialise quand l'ordre change.
    fun selectRange() {
        val a = (from.toIntOrNull() ?: 1).coerceAtLeast(1)
        val b = to.toIntOrNull() ?: Int.MAX_VALUE
        for (i in checked.indices) checked[i] = (i + 1) in a..b
    }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding()) {
            Row(Modifier.padding(horizontal = 20.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.PlaylistPlay, null, tint = MaterialTheme.colorScheme.primary)
                Text(
                    "  ${list.items.size} épisodes trouvés",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                )
            }
            OutlinedTextField(
                value = prefix,
                onValueChange = { prefix = it },
                label = { Text("Nom de la série (préfixe des fichiers)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            )
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                OutlinedTextField(
                    value = from, onValueChange = { from = it.filter(Char::isDigit) },
                    label = { Text("De") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                )
                OutlinedTextField(
                    value = to, onValueChange = { to = it.filter(Char::isDigit) },
                    label = { Text("à (vide = jusqu'à la fin)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1.6f),
                )
                OutlinedButton(onClick = { selectRange() }) { Text("OK") }
            }
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                FilterChip(selected = false, onClick = { for (i in checked.indices) checked[i] = true }, label = { Text("Tout") })
                FilterChip(selected = false, onClick = { for (i in checked.indices) checked[i] = false }, label = { Text("Aucun") })
                FilterChip(selected = reversed, onClick = { reversed = !reversed }, label = { Text("Ordre inversé") })
                Spacer(Modifier.weight(1f))
                FilterChip(selected = !audio, onClick = { audio = false }, label = { Text("Vidéo") })
                FilterChip(selected = audio, onClick = { audio = true }, label = { Text("MP3") })
            }
            HorizontalDivider(Modifier.padding(top = 8.dp))
            LazyColumn(Modifier.weight(1f, fill = false).heightIn(max = 380.dp)) {
                itemsIndexed(shown) { i, ep ->
                    Row(
                        Modifier.fillMaxWidth().clickable { checked[i] = !checked[i] }.padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Checkbox(checked = checked[i], onCheckedChange = { checked[i] = it })
                        Text("${i + 1}.", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.width(36.dp))
                        Text(ep.title, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            val count = checked.count { it }
            Button(
                onClick = {
                    val chosen = shown.filterIndexed { i, _ -> checked[i] }
                    hub.crawler.start(prefix.trim(), chosen, if (audio) "mp3" else "best")
                    Toast.makeText(
                        context, "Recherche des vidéos de ${chosen.size} épisode(s) lancée", Toast.LENGTH_LONG,
                    ).show()
                    onDismiss()
                },
                enabled = count > 0,
                modifier = Modifier.fillMaxWidth().padding(16.dp),
            ) {
                Icon(Icons.Filled.Download, null, modifier = Modifier.size(18.dp))
                Text("  Télécharger $count épisode(s)")
            }
        }
    }
}

private fun cleanTitle(t: String): String =
    t.replace(Regex("""\s*[|\-–—]\s*[^|\-–—]*(streaming|voir|regarder|gratuit)[^|\-–—]*$""", RegexOption.IGNORE_CASE), "")
        .replace(Regex("""(?i)\b(streaming|vf|vostfr|gratuit)\b"""), "")
        .replace(Regex("""\s+"""), " ")
        .trim()
        .take(60)

/** Bandeau d'avancement de la recherche des épisodes, visible depuis tous les onglets. */
@Composable
fun CrawlBanner(hub: WebHub) {
    val st = hub.crawler.state.value ?: return
    Surface(
        color = MaterialTheme.colorScheme.secondaryContainer,
        contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            if (st.running) {
                Text(
                    "Recherche des vidéos ${st.done + 1}/${st.total} · ${st.current}",
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold,
                )
                Text(
                    "${st.added} ajouté(s)" + if (st.failed.isNotEmpty()) " · ${st.failed.size} introuvable(s)" else "",
                    style = MaterialTheme.typography.bodySmall,
                )
                LinearProgressIndicator(
                    progress = { st.done.toFloat() / st.total.coerceAtLeast(1) },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                )
                Text(
                    "Gardez l'application ouverte pendant la recherche.",
                    style = MaterialTheme.typography.labelSmall,
                )
                TextButton(onClick = { hub.crawler.cancel() }) { Text("Annuler") }
            } else {
                Text(
                    "${st.added} épisode(s) ajouté(s) aux téléchargements" +
                        if (st.failed.isNotEmpty()) ", ${st.failed.size} sans vidéo trouvée" else "",
                    style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold,
                )
                if (st.failed.isNotEmpty()) {
                    Text(
                        "Introuvables : " + st.failed.take(6).joinToString(", ") +
                            if (st.failed.size > 6) "…" else "",
                        style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis,
                    )
                }
                TextButton(onClick = { hub.crawler.dismiss() }) { Text("Fermer") }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Images de la page
// ---------------------------------------------------------------------------------------------

@Composable
fun ImagesSheet(app: App, hub: WebHub, images: List<PageImage>, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val checked = remember(images) { mutableStateListOf<Boolean>().apply { repeat(images.size) { add(true) } } }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding()) {
            Text(
                "${images.size} images trouvées",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
            )
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = false, onClick = { for (i in checked.indices) checked[i] = true }, label = { Text("Tout") })
                FilterChip(selected = false, onClick = { for (i in checked.indices) checked[i] = false }, label = { Text("Aucune") })
            }
            LazyColumn(Modifier.weight(1f, fill = false).heightIn(max = 420.dp)) {
                itemsIndexed(images) { i, img ->
                    Row(
                        Modifier.fillMaxWidth().clickable { checked[i] = !checked[i] }.padding(horizontal = 12.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Checkbox(checked = checked[i], onCheckedChange = { checked[i] = it })
                        Box(Modifier.size(72.dp).clip(RoundedCornerShape(8.dp))) {
                            RemoteImage(img.url, app.manager.http.client, Modifier.size(72.dp))
                        }
                        Column(Modifier.weight(1f).padding(start = 12.dp)) {
                            Text(
                                Uri.parse(img.url).lastPathSegment ?: img.url,
                                maxLines = 1, overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.bodyMedium,
                            )
                            if (img.width > 0) {
                                Text(
                                    "${img.width} px",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                }
            }
            val count = checked.count { it }
            Button(
                onClick = {
                    val tab = hub.current
                    images.forEachIndexed { i, img ->
                        if (checked[i] && tab != null) hub.downloadFile(tab, img.url)
                    }
                    Toast.makeText(context, "$count image(s) ajoutée(s)", Toast.LENGTH_SHORT).show()
                    onDismiss()
                },
                enabled = count > 0,
                modifier = Modifier.fillMaxWidth().padding(16.dp),
            ) {
                Icon(Icons.Filled.Download, null, modifier = Modifier.size(18.dp))
                Text("  Télécharger $count image(s)")
            }
        }
    }
}
