package com.dlvibestudio.dlturbo.engine

import com.github.junrar.Archive
import net.lingala.zip4j.ZipFile
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.io.InputStream
import java.util.zip.GZIPInputStream

/** Lecture et décompression : ZIP (mot de passe / AES), RAR, 7z, tar, tar.gz/bz2/xz, gz, bz2, xz. */
object ArchiveManager {

    enum class Kind { ZIP, RAR, SEVEN_Z, TAR, TAR_GZ, TAR_BZ2, TAR_XZ, GZ, BZ2, XZ }

    data class Entry(val name: String, val size: Long, val isDir: Boolean)

    class PasswordRequired : IOException("Mot de passe requis ou incorrect")

    fun kindOf(file: File): Kind? {
        val n = file.name.lowercase()
        return when {
            n.endsWith(".zip") || n.endsWith(".jar") || n.endsWith(".cbz") -> Kind.ZIP
            n.endsWith(".rar") || n.endsWith(".cbr") -> Kind.RAR
            n.endsWith(".7z") -> Kind.SEVEN_Z
            n.endsWith(".tar.gz") || n.endsWith(".tgz") -> Kind.TAR_GZ
            n.endsWith(".tar.bz2") || n.endsWith(".tbz2") || n.endsWith(".tbz") -> Kind.TAR_BZ2
            n.endsWith(".tar.xz") || n.endsWith(".txz") -> Kind.TAR_XZ
            n.endsWith(".tar") -> Kind.TAR
            n.endsWith(".gz") -> Kind.GZ
            n.endsWith(".bz2") -> Kind.BZ2
            n.endsWith(".xz") -> Kind.XZ
            else -> null
        }
    }

    fun isArchive(file: File) = kindOf(file) != null

    /** Nom du dossier de destination par défaut : « photos.zip » -> « photos ». */
    fun defaultFolderName(file: File): String {
        var n = file.name
        for (ext in listOf(".tar.gz", ".tar.bz2", ".tar.xz", ".tgz", ".tbz2", ".tbz", ".txz")) {
            if (n.lowercase().endsWith(ext)) return n.dropLast(ext.length).ifBlank { "extrait" }
        }
        n = n.substringBeforeLast('.', n)
        return n.ifBlank { "extrait" }
    }

    // ------------------------------------------------------------- Liste

    fun list(file: File, password: String?): List<Entry> {
        val kind = kindOf(file) ?: throw IOException("Format d'archive non pris en charge")
        return when (kind) {
            Kind.ZIP -> listZip(file, password)
            Kind.RAR -> listRar(file, password)
            Kind.SEVEN_Z -> listSevenZ(file, password)
            Kind.TAR, Kind.TAR_GZ, Kind.TAR_BZ2, Kind.TAR_XZ -> listTar(file, kind)
            Kind.GZ, Kind.BZ2, Kind.XZ -> listOf(Entry(singleName(file), -1, false))
        }
    }

    private fun listZip(file: File, password: String?): List<Entry> {
        val zip = ZipFile(file)
        if (zip.isEncrypted && password.isNullOrEmpty()) throw PasswordRequired()
        if (!password.isNullOrEmpty()) zip.setPassword(password.toCharArray())
        return zip.fileHeaders.map { Entry(it.fileName, it.uncompressedSize, it.isDirectory) }
    }

    private fun listRar(file: File, password: String?): List<Entry> = openRar(file, password).use { rar ->
        rar.fileHeaders.map {
            Entry(rarName(it.fileName), it.fullUnpackSize, it.isDirectory)
        }
    }

    private fun listSevenZ(file: File, password: String?): List<Entry> = openSevenZ(file, password).use { sz ->
        sz.entries.map { Entry(it.name, it.size, it.isDirectory) }
    }

    private fun listTar(file: File, kind: Kind): List<Entry> {
        val out = ArrayList<Entry>()
        TarArchiveInputStream(openCompressed(file, kind)).use { tar ->
            var e = tar.nextEntry
            while (e != null) {
                out.add(Entry(e.name, e.size, e.isDirectory))
                e = tar.nextEntry
            }
        }
        return out
    }

    // ---------------------------------------------------------- Extraction

    /**
     * Extrait [file] dans [dest]. [onProgress] reçoit (élément courant, total, nom).
     * Renvoie le nombre de fichiers extraits. Lève [PasswordRequired] si le mot de passe manque.
     */
    fun extract(
        file: File,
        dest: File,
        password: String?,
        isCancelled: () -> Boolean,
        onProgress: (Int, Int, String) -> Unit,
    ): Int {
        val kind = kindOf(file) ?: throw IOException("Format d'archive non pris en charge")
        if (!dest.exists() && !dest.mkdirs() && !dest.exists()) {
            throw IOException("Impossible de créer le dossier ${dest.path}")
        }
        return when (kind) {
            Kind.ZIP -> extractZip(file, dest, password, isCancelled, onProgress)
            Kind.RAR -> extractRar(file, dest, password, isCancelled, onProgress)
            Kind.SEVEN_Z -> extractSevenZ(file, dest, password, isCancelled, onProgress)
            Kind.TAR, Kind.TAR_GZ, Kind.TAR_BZ2, Kind.TAR_XZ -> extractTar(file, kind, dest, isCancelled, onProgress)
            Kind.GZ, Kind.BZ2, Kind.XZ -> extractSingle(file, kind, dest, onProgress)
        }
    }

    private fun extractZip(
        file: File, dest: File, password: String?, cancelled: () -> Boolean, progress: (Int, Int, String) -> Unit,
    ): Int {
        val zip = ZipFile(file)
        if (zip.isEncrypted) {
            if (password.isNullOrEmpty()) throw PasswordRequired()
            zip.setPassword(password.toCharArray())
        }
        val headers = zip.fileHeaders.filter { !it.isDirectory }
        var done = 0
        for (h in zip.fileHeaders) {
            if (cancelled()) break
            val target = safeTarget(dest, h.fileName) ?: continue
            if (h.isDirectory) {
                target.mkdirs()
                continue
            }
            progress(done, headers.size, h.fileName)
            try {
                // zip4j recrée lui-même l'arborescence ; la destination est le dossier racine.
                zip.extractFile(h, dest.path)
            } catch (e: net.lingala.zip4j.exception.ZipException) {
                if (e.type == net.lingala.zip4j.exception.ZipException.Type.WRONG_PASSWORD) throw PasswordRequired()
                throw e
            }
            done++
        }
        progress(done, headers.size, "")
        return done
    }

    private fun extractRar(
        file: File, dest: File, password: String?, cancelled: () -> Boolean, progress: (Int, Int, String) -> Unit,
    ): Int = openRar(file, password).use { rar ->
        val headers = rar.fileHeaders.filter { !it.isDirectory }
        var done = 0
        for (h in rar.fileHeaders) {
            if (cancelled()) break
            val name = rarName(h.fileName)
            val target = safeTarget(dest, name) ?: continue
            if (h.isDirectory) {
                target.mkdirs()
                continue
            }
            progress(done, headers.size, name)
            target.parentFile?.mkdirs()
            try {
                target.outputStream().buffered().use { rar.extractFile(h, it) }
            } catch (e: Exception) {
                target.delete()
                if (e.message?.contains("password", ignoreCase = true) == true) throw PasswordRequired()
                throw IOException(e.message ?: "Erreur de décompression RAR")
            }
            done++
        }
        progress(done, headers.size, "")
        done
    }

    private fun extractSevenZ(
        file: File, dest: File, password: String?, cancelled: () -> Boolean, progress: (Int, Int, String) -> Unit,
    ): Int = openSevenZ(file, password).use { sz ->
        val total = sz.entries.count { !it.isDirectory }
        var done = 0
        var e = sz.nextEntry
        while (e != null) {
            if (cancelled()) break
            val target = safeTarget(dest, e.name)
            if (target != null) {
                if (e.isDirectory) {
                    target.mkdirs()
                } else {
                    progress(done, total, e.name)
                    target.parentFile?.mkdirs()
                    target.outputStream().buffered().use { out ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = sz.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                        }
                    }
                    done++
                }
            }
            e = sz.nextEntry
        }
        progress(done, total, "")
        done
    }

    private fun extractTar(
        file: File, kind: Kind, dest: File, cancelled: () -> Boolean, progress: (Int, Int, String) -> Unit,
    ): Int {
        var done = 0
        TarArchiveInputStream(openCompressed(file, kind)).use { tar ->
            var e = tar.nextEntry
            while (e != null) {
                if (cancelled()) break
                val target = safeTarget(dest, e.name)
                if (target != null) {
                    if (e.isDirectory) {
                        target.mkdirs()
                    } else if (e.isFile) {
                        progress(done, -1, e.name)
                        target.parentFile?.mkdirs()
                        target.outputStream().buffered().use { tar.copyTo(it) }
                        done++
                    }
                }
                e = tar.nextEntry
            }
        }
        progress(done, done, "")
        return done
    }

    private fun extractSingle(file: File, kind: Kind, dest: File, progress: (Int, Int, String) -> Unit): Int {
        val name = singleName(file)
        val target = safeTarget(dest, name) ?: throw IOException("Nom de fichier invalide")
        progress(0, 1, name)
        openCompressed(file, kind).use { input ->
            target.outputStream().buffered().use { input.copyTo(it) }
        }
        progress(1, 1, "")
        return 1
    }

    // ------------------------------------------------------------ Outils

    private fun openCompressed(file: File, kind: Kind): InputStream {
        val raw = BufferedInputStream(FileInputStream(file), 64 * 1024)
        return when (kind) {
            Kind.TAR_GZ, Kind.GZ -> GZIPInputStream(raw, 64 * 1024)
            Kind.TAR_BZ2, Kind.BZ2 -> BZip2CompressorInputStream(raw)
            Kind.TAR_XZ, Kind.XZ -> XZCompressorInputStream(raw)
            else -> raw
        }
    }

    private fun openRar(file: File, password: String?): Archive = try {
        if (password.isNullOrEmpty()) Archive(file) else Archive(file, password)
    } catch (e: Exception) {
        val msg = e.message ?: ""
        if (msg.contains("password", ignoreCase = true) || msg.contains("encrypted", ignoreCase = true)) {
            throw PasswordRequired()
        }
        throw IOException("Archive RAR illisible (les RAR5 ne sont pas pris en charge) : $msg")
    }

    private fun openSevenZ(file: File, password: String?): SevenZFile = try {
        val builder = SevenZFile.builder().setFile(file)
        if (!password.isNullOrEmpty()) builder.setPassword(password)
        builder.get()
    } catch (e: org.apache.commons.compress.PasswordRequiredException) {
        throw PasswordRequired()
    }

    private fun rarName(raw: String) = raw.replace('\\', '/')

    private fun singleName(file: File): String {
        val n = file.name
        val stripped = n.substringBeforeLast('.', n)
        return stripped.ifBlank { n + ".out" }
    }

    /** Protection « zip-slip » : refuse tout chemin qui sortirait du dossier de destination. */
    private fun safeTarget(dest: File, entryName: String): File? {
        val cleaned = entryName.replace('\\', '/').trimStart('/')
        if (cleaned.isBlank()) return null
        val target = File(dest, cleaned)
        val base = dest.canonicalPath
        val path = target.canonicalPath
        return if (path == base || path.startsWith(base + File.separator)) target else null
    }
}
