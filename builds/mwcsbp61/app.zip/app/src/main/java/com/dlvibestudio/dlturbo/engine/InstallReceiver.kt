package com.dlvibestudio.dlturbo.engine

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.os.Build
import android.widget.Toast

/** Reçoit le résultat d'une installation par PackageInstaller (bundles .xapk / .apks / .apkm). */
class InstallReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)
        when (status) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                // Le système demande la confirmation de l'utilisateur.
                val confirm: Intent? = if (Build.VERSION.SDK_INT >= 33)
                    intent.getParcelableExtra(Intent.EXTRA_INTENT, Intent::class.java)
                else
                    @Suppress("DEPRECATION") intent.getParcelableExtra(Intent.EXTRA_INTENT)
                confirm?.let {
                    runCatching { context.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                }
            }

            PackageInstaller.STATUS_SUCCESS ->
                Toast.makeText(context, "Application installée", Toast.LENGTH_LONG).show()

            PackageInstaller.STATUS_FAILURE_ABORTED ->
                Toast.makeText(context, "Installation annulée", Toast.LENGTH_SHORT).show()

            else -> {
                val message = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: "erreur inconnue"
                Toast.makeText(context, "Échec de l'installation : $message", Toast.LENGTH_LONG).show()
            }
        }
    }
}
