@file:OptIn(ExperimentalMaterial3Api::class)

package com.dlvibestudio.dlturbo.ui

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.dlvibestudio.dlturbo.App
import kotlinx.coroutines.launch

/** Chaînes suivies : les nouvelles vidéos sont téléchargées toutes seules (vérification toutes les 6 h). */
@Composable
fun SubscriptionsSheet(app: App, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val lib = app.library
    var input by remember { mutableStateOf("") }
    var quality by remember { mutableStateOf("720") }
    var busy by remember { mutableStateOf(false) }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(
            Modifier.navigationBarsPadding().padding(horizontal = 20.dp).padding(bottom = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text("Chaînes suivies", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(
                "Les nouvelles vidéos d'une chaîne sont téléchargées automatiquement (vérification toutes les 6 heures " +
                    "tant que l'appli tourne). Les vidéos déjà en ligne ne sont pas téléchargées.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                label = { Text("@nomdelachaîne ou lien de la chaîne") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("best" to "Meilleure", "1080" to "1080p", "720" to "720p", "480" to "480p", "mp3" to "MP3").forEach { (k, l) ->
                    FilterChip(selected = quality == k, onClick = { quality = k }, label = { Text(l) })
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(enabled = !busy && input.isNotBlank(), onClick = {
                    busy = true
                    scope.launch {
                        val r = app.subscriptions.follow(input, quality)
                        busy = false
                        r.onSuccess { name -> input = ""; Toast.makeText(context, "Chaîne suivie : $name", Toast.LENGTH_SHORT).show() }
                            .onFailure { Toast.makeText(context, it.message ?: "Chaîne introuvable", Toast.LENGTH_LONG).show() }
                    }
                }) { Text("Suivre") }
                OutlinedButton(enabled = !busy && lib.channels.isNotEmpty(), onClick = {
                    busy = true
                    scope.launch {
                        val n = runCatching { app.subscriptions.checkAll() }.getOrDefault(0)
                        busy = false
                        Toast.makeText(
                            context,
                            if (n > 0) "$n nouvelle(s) vidéo(s) ajoutée(s)" else "Rien de nouveau",
                            Toast.LENGTH_SHORT,
                        ).show()
                    }
                }) { Text("Vérifier maintenant") }
                if (busy) CircularProgressIndicator(Modifier.padding(start = 4.dp), strokeWidth = 3.dp)
            }
            HorizontalDivider()
            if (lib.channels.isEmpty()) {
                Text("Aucune chaîne suivie.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            lib.channels.toList().forEach { c ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(c.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            "Qualité : ${c.quality}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    IconButton(onClick = { lib.removeChannel(c.url) }) {
                        Icon(Icons.Filled.Close, contentDescription = "Ne plus suivre")
                    }
                }
            }
        }
    }
}
