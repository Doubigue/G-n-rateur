package com.dlvibestudio.dlturbo.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Gold = Color(0xFFF5B301)
val GoldDeep = Color(0xFFB8860B)
val Success = Color(0xFF3DDC84)

private val DarkColors = darkColorScheme(
    primary = Gold,
    onPrimary = Color(0xFF1A1300),
    primaryContainer = Color(0xFF3A2C00),
    onPrimaryContainer = Color(0xFFFFDF8A),
    secondary = Color(0xFFE0C36A),
    onSecondary = Color(0xFF1A1300),
    background = Color(0xFF0E0E12),
    onBackground = Color(0xFFECECF1),
    surface = Color(0xFF0E0E12),
    onSurface = Color(0xFFECECF1),
    surfaceVariant = Color(0xFF1B1B22),
    onSurfaceVariant = Color(0xFFA9A9B8),
    surfaceContainer = Color(0xFF17171D),
    surfaceContainerHigh = Color(0xFF1F1F27),
    surfaceContainerHighest = Color(0xFF26262F),
    surfaceContainerLow = Color(0xFF131318),
    outline = Color(0xFF3A3A46),
    outlineVariant = Color(0xFF2A2A33),
    error = Color(0xFFFF6B6B),
    onError = Color(0xFF2A0000),
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF8A6500),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFE08A),
    onPrimaryContainer = Color(0xFF2A1F00),
    secondary = Color(0xFF6B5A1E),
    background = Color(0xFFFBF9F4),
    onBackground = Color(0xFF1B1B1F),
    surface = Color(0xFFFBF9F4),
    onSurface = Color(0xFF1B1B1F),
    surfaceVariant = Color(0xFFEFEADF),
    onSurfaceVariant = Color(0xFF5A5648),
    surfaceContainer = Color(0xFFF3EFE6),
    surfaceContainerHigh = Color(0xFFEDE8DD),
    surfaceContainerHighest = Color(0xFFE6E1D5),
    surfaceContainerLow = Color(0xFFF7F4EC),
    outline = Color(0xFFB9B2A0),
    outlineVariant = Color(0xFFDAD4C4),
)

@Composable
fun DLTheme(mode: String, content: @Composable () -> Unit) {
    val dark = when (mode) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, content = content)
}
