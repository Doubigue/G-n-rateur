package com.dlvibestudio.dlturbo.ui

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.dlvibestudio.dlturbo.App
import com.dlvibestudio.dlturbo.util.PinLock

/** Réglages « Téléchargements programmés » et « Sécurité » (verrouillage par code). */
@Composable
fun ScheduleAndSecuritySection(app: App) {
    val context = LocalContext.current
    val s by app.settings.data.collectAsState()
    var dialog by remember { mutableStateOf<String?>(null) } // "set" | "off"

    // ------------------------------------------------------ Programmation
    Header("Téléchargements programmés")
    ToggleRow(
        "Télécharger seulement dans une plage horaire",
        "Par exemple la nuit, quand la connexion est libre. Hors plage, la file attend et démarre toute seule.",
        s.scheduleOn,
    ) { v -> app.settings.update { it.copy(scheduleOn = v) } }
    if (s.scheduleOn) {
        TimeRow("Début", s.scheduleStart) { v -> app.settings.update { it.copy(scheduleStart = v) } }
        TimeRow("Fin", s.scheduleEnd) { v -> app.settings.update { it.copy(scheduleEnd = v) } }
        Text(
            "Gardez l'appli ouverte ou en arrière-plan : une notification reste affichée pendant l'attente " +
                "et le téléphone ne s'endort pas complètement (consommation de batterie).",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(bottom = 4.dp),
        )
    }

    // ------------------------------------------------------------ Sécurité
    Header("Sécurité")
    ToggleRow(
        "Verrouiller l'application par code",
        "Demande le code au retour dans l'appli (après 30 s) et masque l'aperçu dans les applications récentes.",
        s.pinHash.isNotEmpty(),
    ) { v -> dialog = if (v) "set" else "off" }
    if (s.pinHash.isNotEmpty()) {
        TextButton(onClick = { dialog = "set" }) { Text("Changer le code") }
    }

    when (dialog) {
        "set" -> PinDialog(
            title = "Nouveau code",
            askConfirm = true,
            onDismiss = { dialog = null },
        ) { pin ->
            val salt = PinLock.newSalt()
            app.settings.update { it.copy(pinSalt = salt, pinHash = PinLock.hash(pin, salt)) }
            Toast.makeText(context, "Code enregistré", Toast.LENGTH_SHORT).show()
            dialog = null
            true
        }

        "off" -> PinDialog(
            title = "Entrez le code actuel",
            askConfirm = false,
            onDismiss = { dialog = null },
        ) { pin ->
            if (PinLock.verify(pin, s.pinHash, s.pinSalt)) {
                app.settings.update { it.copy(pinHash = "", pinSalt = "") }
                Toast.makeText(context, "Verrouillage désactivé", Toast.LENGTH_SHORT).show()
                dialog = null
                true
            } else {
                Toast.makeText(context, "Code incorrect", Toast.LENGTH_SHORT).show()
                false
            }
        }
    }
    if (s.pinHash.isNotEmpty()) {
        Text(
            "Code oublié : il faut effacer les données de l'application (Réglages Android).",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun Header(title: String) {
    Spacer(Modifier.height(20.dp))
    Text(title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(4.dp))
}

@Composable
private fun ToggleRow(title: String, hint: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun TimeRow(title: String, minutes: Int, onChange: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
        IconButton(onClick = { onChange((minutes - 30 + 1440) % 1440) }) {
            Icon(Icons.Filled.Remove, contentDescription = "Reculer de 30 minutes")
        }
        Text("%02d:%02d".format(minutes / 60, minutes % 60), fontWeight = FontWeight.Bold)
        IconButton(onClick = { onChange((minutes + 30) % 1440) }) {
            Icon(Icons.Filled.Add, contentDescription = "Avancer de 30 minutes")
        }
    }
}

/** Saisie d'un code de 4 à 8 chiffres. [onValid] renvoie true si le dialogue peut se fermer. */
@Composable
private fun PinDialog(title: String, askConfirm: Boolean, onDismiss: () -> Unit, onValid: (String) -> Boolean) {
    val context = LocalContext.current
    var pin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = pin,
                    onValueChange = { pin = it.filter(Char::isDigit).take(8) },
                    label = { Text("Code (4 à 8 chiffres)") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                )
                if (askConfirm) {
                    OutlinedTextField(
                        value = confirm,
                        onValueChange = { confirm = it.filter(Char::isDigit).take(8) },
                        label = { Text("Confirmer le code") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                when {
                    pin.length < 4 -> Toast.makeText(context, "Au moins 4 chiffres", Toast.LENGTH_SHORT).show()
                    askConfirm && pin != confirm -> Toast.makeText(context, "Les deux codes sont différents", Toast.LENGTH_SHORT).show()
                    else -> onValid(pin)
                }
            }) { Text("OK") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    )
}
