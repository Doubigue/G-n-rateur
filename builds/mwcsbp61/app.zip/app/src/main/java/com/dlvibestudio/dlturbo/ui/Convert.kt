package com.dlvibestudio.dlturbo.ui

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.dlvibestudio.dlturbo.App
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.io.File

/** « 1:05 », « 65 » ou « 0:01:05 » → secondes ; null si illisible. */
internal fun parseTime(text: String): Int? {
    val parts = text.trim().split(':')
    if (parts.isEmpty() || parts.size > 3) return null
    var total = 0
    for (p in parts) total = total * 60 + (p.trim().toIntOrNull() ?: return null)
    return total
}

/** Convertisseur : MP4 → MP3, compression 720p, découpe d'un extrait. */
@Composable
fun ConvertDialog(app: App, file: File, onDone: () -> Unit, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var mode by remember { mutableStateOf("mp3") }
    var from by remember { mutableStateOf("0:00") }
    var to by remember { mutableStateOf("0:30") }
    var busy by remember { mutableStateOf(false) }
    var job by remember { mutableStateOf<Job?>(null) }

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("Convertir") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(file.name, style = MaterialTheme.typography.bodySmall, maxLines = 2)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(mode == "mp3", { mode = "mp3" }, label = { Text("En MP3") }, enabled = !busy)
                    FilterChip(mode == "compress", { mode = "compress" }, label = { Text("Alléger") }, enabled = !busy)
                    FilterChip(mode == "cut", { mode = "cut" }, label = { Text("Extrait") }, enabled = !busy)
                }
                Text(
                    when (mode) {
                        "mp3" -> "Extrait le son de la vidéo en MP3."
                        "compress" -> "Vidéo recompressée en 720p : fichier bien plus petit."
                        else -> "Garde seulement la partie entre le début et la fin (mm:ss)."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                if (mode == "cut") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            from, { from = it }, label = { Text("Début") }, singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                            modifier = Modifier.weight(1f),
                        )
                        OutlinedTextField(
                            to, { to = it }, label = { Text("Fin") }, singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                            modifier = Modifier.weight(1f),
                        )
                    }
                }
                if (busy) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        CircularProgressIndicator(strokeWidth = 3.dp)
                        Text("Conversion en cours… (peut prendre du temps)")
                    }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = !busy, onClick = {
                val a = parseTime(from)
                val b = parseTime(to)
                if (mode == "cut" && (a == null || b == null || b <= a)) {
                    Toast.makeText(context, "Début et fin invalides", Toast.LENGTH_SHORT).show()
                    return@TextButton
                }
                busy = true
                job = scope.launch {
                    try {
                        val out = app.manager.videos.convert(file, mode, a ?: 0, b ?: 0)
                        android.media.MediaScannerConnection.scanFile(context, arrayOf(out.path), null, null)
                        Toast.makeText(context, "Créé : ${out.name}", Toast.LENGTH_LONG).show()
                        onDone()
                        onDismiss()
                    } catch (e: kotlinx.coroutines.CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        Toast.makeText(context, e.message ?: "Échec de la conversion", Toast.LENGTH_LONG).show()
                        busy = false
                    }
                }
            }) { Text("Convertir") }
        },
        dismissButton = {
            TextButton(onClick = { job?.cancel(); busy = false; onDismiss() }) { Text(if (busy) "Arrêter" else "Annuler") }
        },
    )
}
