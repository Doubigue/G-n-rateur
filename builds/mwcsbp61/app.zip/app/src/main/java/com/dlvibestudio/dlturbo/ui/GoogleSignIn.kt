package com.dlvibestudio.dlturbo.ui

import android.accounts.AccountManager
import android.app.Activity
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

/** Page de connexion Google (YouTube) avec l'adresse déjà remplie. */
fun googleLoginUrl(email: String): String =
    "https://accounts.google.com/ServiceLogin?service=youtube&hl=fr" +
        "&continue=" + Uri.encode("https://m.youtube.com/?app=m&persist_app=1") +
        "&Email=" + Uri.encode(email) + "&login_hint=" + Uri.encode(email)

/**
 * « Connexion Google » : affiche la liste des comptes Google présents sur l'appareil (sélecteur Android,
 * avec « Ajouter un compte »), puis appelle [onAccount] avec l'adresse choisie. Aucune autorisation
 * spéciale n'est nécessaire : c'est le système qui montre la liste.
 */
@Composable
fun rememberGoogleAccountPicker(onAccount: (String) -> Unit): () -> Unit {
    val context = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val email = result.data?.getStringExtra(AccountManager.KEY_ACCOUNT_NAME)
            if (!email.isNullOrBlank()) onAccount(email)
        }
    }
    return {
        try {
            @Suppress("DEPRECATION")
            val intent = AccountManager.newChooseAccountIntent(
                null, null, arrayOf("com.google"), null, null, null, null,
            )
            launcher.launch(intent)
        } catch (_: Exception) {
            Toast.makeText(context, "Impossible d'afficher la liste des comptes", Toast.LENGTH_SHORT).show()
        }
    }
}
