@file:OptIn(ExperimentalMaterial3Api::class)

package com.dlvibestudio.dlturbo.ui

import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.dlvibestudio.dlturbo.App
import com.dlvibestudio.dlturbo.engine.Links

val QUALITY_OPTIONS = listOf(
    "best" to "Meilleure",
    "1080" to "1080p",
    "720" to "720p",
    "480" to "480p",
    "360" to "360p",
    "audio" to "Audio MP3",
)

@Composable
fun AddDialog(app: App, initialText: String, onDismiss: () -> Unit) {
    val context = LocalContext.current
    var text by remember(initialText) { mutableStateOf(initialText) }
    var quality by remember { mutableStateOf(app.settings.value.videoQuality) }
    var error by remember { mutableStateOf<String?>(null) }

    val torrentPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val ok = addTorrentFromUri(context, app, uri)
            Toast.makeText(
                context,
                if (ok) "Torrent ajouté" else "Impossible de lire ce fichier .torrent",
                Toast.LENGTH_SHORT,
            ).show()
            if (ok) onDismiss()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nouveau téléchargement") },
        text = {
            Column {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it; error = null },
                    label = { Text("Lien, magnet ou plusieurs liens") },
                    placeholder = { Text("https://…  ou  magnet:?xt=…") },
                    minLines = 3,
                    maxLines = 6,
                    isError = error != null,
                    supportingText = { error?.let { Text(it) } },
                    modifier = Modifier.fillMaxWidth(),
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(context)
                        if (!clip.isNullOrBlank()) {
                            text = if (text.isBlank()) clip.toString() else text.trimEnd() + "\n" + clip
                            error = null
                        }
                    }) {
                        Icon(Icons.Filled.ContentPaste, contentDescription = null)
                        Text("  Coller")
                    }
                    OutlinedButton(onClick = {
                        torrentPicker.launch(arrayOf("application/x-bittorrent", "application/octet-stream", "*/*"))
                    }) {
                        Icon(Icons.Filled.FolderOpen, contentDescription = null)
                        Text("  .torrent")
                    }
                }
                Spacer(Modifier.height(14.dp))
                Text(
                    "Qualité (liens vidéo uniquement)",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    QUALITY_OPTIONS.forEach { (key, label) ->
                        FilterChip(
                            selected = quality == key,
                            onClick = { quality = key },
                            label = { Text(label) },
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                if (Links.extract(text).isEmpty()) {
                    error = "Aucun lien valide (http, https ou magnet)"
                } else {
                    val count = app.manager.enqueueText(text, quality)
                    Toast.makeText(
                        context,
                        if (count > 1) "$count téléchargements ajoutés" else "Téléchargement ajouté",
                        Toast.LENGTH_SHORT,
                    ).show()
                    onDismiss()
                }
            }) { Text("Télécharger") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    )
}
