package com.dlvibestudio.dlturbo.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.dlvibestudio.dlturbo.App
import com.dlvibestudio.dlturbo.engine.VideoInfo
import com.dlvibestudio.dlturbo.engine.YtEntry
import com.dlvibestudio.dlturbo.engine.YtSearch
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.net.URLEncoder

data class YtCategory(val label: String, val query: String, val playlists: Boolean = false)

/**
 * État de l'onglet YouTube : recherche native (résultats avec icône de téléchargement),
 * catégories, contenu d'une playlist. Conservé quand on change d'onglet.
 */
class YtModel(private val app: App) {

    val categories = listOf(
        YtCategory("Tendances", "tendances du moment"),
        YtCategory("Musique", "musique"),
        YtCategory("Afrique", "musique africaine"),
        YtCategory("Films", "film complet"),
        YtCategory("Jeux", "gaming"),
        YtCategory("Sport", "sport"),
        YtCategory("Actualités", "actualités"),
        YtCategory("Playlists", "playlist musique", playlists = true),
    )

    /** 0 = Découvrir (liste native), 1 = Site YouTube (WebView). */
    var mode by mutableIntStateOf(0)
    var query by mutableStateOf("")
    var category by mutableIntStateOf(0)
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var results by mutableStateOf<List<YtEntry>>(emptyList())
    var canLoadMore by mutableStateOf(false)

    /** Page à charger dans le mode « Site YouTube » dès qu'il s'affiche (null = rien de spécial). */
    var siteTarget by mutableStateOf<String?>(null)
    var siteLoaded = false

    /** Panier : vidéos ajoutées avec « + » pour être téléchargées ensemble. */
    val cart = androidx.compose.runtime.mutableStateListOf<YtEntry>()
    var cartOpen by mutableStateOf(false)
    var subsOpen by mutableStateOf(false)

    fun inCart(entry: YtEntry) = cart.any { it.url == entry.url }

    /** Nom de la liste de lecture d'où viennent les vidéos du panier (vide = origines mélangées). */
    var cartFolder by mutableStateOf("")

    private fun noteCartOrigin() {
        val ctx = playlistTitle.orEmpty()
        if (cart.isEmpty()) cartFolder = ctx else if (cartFolder != ctx) cartFolder = ""
    }

    fun toggleCart(entry: YtEntry) {
        if (entry.isPlaylist) return
        if (!inCart(entry)) noteCartOrigin()
        val i = cart.indexOfFirst { it.url == entry.url }
        if (i >= 0) cart.removeAt(i) else cart.add(entry)
    }

    fun addAllToCart() {
        noteCartOrigin()
        results.filter { !it.isPlaylist && !inCart(it) }.forEach { cart.add(it) }
    }

    /** Non nul quand on regarde le contenu d'une playlist. */
    var playlistTitle by mutableStateOf<String?>(null)
    var playlistUrl by mutableStateOf<String?>(null)

    private var count = PAGE
    private var lastQuery = ""
    private var lastPlaylists = false
    private var job: Job? = null
    private var parentResults: List<YtEntry>? = null
    private var started = false

    /** Ouvre une vidéo dans le site YouTube pour la regarder. */
    fun watch(videoUrl: String) {
        val mobile = videoUrl.replace("://www.youtube.com", "://m.youtube.com")
        siteTarget = mobile + (if (mobile.contains('?')) "&" else "?") + "app=m&persist_app=1"
        mode = 1
    }

    fun startIfNeeded() {
        if (started) return
        started = true
        selectCategory(0)
    }

    fun selectCategory(index: Int) {
        category = index
        query = ""
        val c = categories[index]
        search(c.query, c.playlists, more = false)
    }

    fun submit() {
        val q = query.trim()
        if (q.isEmpty()) return
        category = -1
        app.library.addSearch(q)
        search(q, playlists = false, more = false)
    }

    /** Relance la dernière recherche (bouton « Réessayer »). */
    fun retry() {
        if (lastQuery.isBlank()) selectCategory(category.coerceAtLeast(0))
        else search(lastQuery, lastPlaylists, more = false)
    }

    fun loadMore() {
        search(lastQuery, lastPlaylists, more = true)
    }

    private fun search(q: String, playlists: Boolean, more: Boolean) {
        job?.cancel()
        playlistTitle = null
        playlistUrl = null
        parentResults = null
        lastQuery = q
        lastPlaylists = playlists
        count = if (more) (count + PAGE).coerceAtMost(MAX) else PAGE
        job = app.scope.launch {
            loading = true
            error = null
            try {
                // 1) Recherche directe sur YouTube : rapide (une seule requête), sans attendre le moteur vidéo.
                var list: List<YtEntry> = emptyList()
                var firstError: Exception? = null
                if (!more) {
                    try {
                        list = YtSearch.search(app.manager.http.client, q, playlists)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        firstError = e
                    }
                    if (list.isNotEmpty()) {
                        results = list
                        loading = false
                    }
                }
                // 2) Moteur yt-dlp : si la recherche directe n'a rien donné, ou pour « voir plus ».
                if (list.isEmpty() || more) {
                    try {
                        val json = if (playlists) {
                            val enc = URLEncoder.encode(q, "UTF-8")
                            app.manager.videos.dumpJson(
                                "https://www.youtube.com/results?search_query=$enc&sp=EgIQAw%3D%3D",
                                "--flat-playlist" to null,
                                "--playlist-end" to count.toString(),
                            )
                        } else {
                            app.manager.videos.dumpJson("ytsearch$count:$q", "--flat-playlist" to null)
                        }
                        val viaEngine = VideoInfo.entries(json)
                        if (viaEngine.isNotEmpty()) {
                            list = viaEngine
                            results = list
                        }
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        if (results.isEmpty()) throw firstError?.let { Exception(e.message ?: it.message) } ?: e
                    }
                }
                canLoadMore = results.isNotEmpty() && count < MAX
                if (results.isEmpty()) error = "Aucun résultat"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = e.message ?: "Erreur de recherche"
            } finally {
                loading = false
            }
        }
    }

    fun openPlaylist(entry: YtEntry) {
        job?.cancel()
        parentResults = results
        playlistTitle = entry.title
        playlistUrl = entry.url
        results = emptyList()
        canLoadMore = false
        job = app.scope.launch {
            loading = true
            error = null
            try {
                // Lecture directe de la page de la playlist (rapide) ; yt-dlp en secours.
                try {
                    val (title, videos) = YtSearch.playlist(app.manager.http.client, entry.url)
                    if (videos.isNotEmpty()) {
                        results = videos
                        if (title.isNotBlank()) playlistTitle = title
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (_: Exception) {
                }
                if (results.isEmpty()) {
                    val json = app.manager.videos.dumpJson(entry.url, "--flat-playlist" to null)
                    results = VideoInfo.entries(json)
                    json.optString("title").takeIf { it.isNotBlank() }?.let { playlistTitle = it }
                }
                if (results.isEmpty()) error = "Playlist vide ou privée"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = e.message ?: "Impossible de lire la playlist"
            } finally {
                loading = false
            }
        }
    }

    /** Retour depuis une playlist. Renvoie false s'il n'y avait rien à fermer. */
    fun closePlaylist(): Boolean {
        if (playlistTitle == null) return false
        job?.cancel()
        results = parentResults ?: emptyList()
        parentResults = null
        playlistTitle = null
        playlistUrl = null
        loading = false
        error = null
        canLoadMore = false
        return true
    }

    companion object {
        private const val PAGE = 20
        private const val MAX = 100
    }
}
