package com.dlvibestudio.dlturbo.service

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.dlvibestudio.dlturbo.App

/** Boutons des notifications : Pause, Reprendre, Annuler, Tout suspendre. */
class ActionReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext as? App ?: return
        val id = intent.getStringExtra(EXTRA_ID)
        when (intent.action) {
            PAUSE -> id?.let { app.manager.pause(it) }
            RESUME -> id?.let {
                cancelNotification(context, app, it)
                app.manager.resume(it)
            }
            CANCEL -> id?.let {
                cancelNotification(context, app, it)
                app.manager.remove(it, deleteFile = true)
            }
            PAUSE_ALL -> app.manager.pauseAll()
        }
    }

    private fun cancelNotification(context: Context, app: App, id: String) {
        val item = app.repo.get(id) ?: return
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(Notifications.idFor(item))
    }

    companion object {
        const val EXTRA_ID = "id"
        const val PAUSE = "com.dlvibestudio.dlturbo.PAUSE"
        const val RESUME = "com.dlvibestudio.dlturbo.RESUME"
        const val CANCEL = "com.dlvibestudio.dlturbo.CANCEL"
        const val PAUSE_ALL = "com.dlvibestudio.dlturbo.PAUSE_ALL"
    }
}
