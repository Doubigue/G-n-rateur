package com.dlvibestudio.dlturbo.data

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONArray
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Liste des téléchargements, observable par l'interface, et sauvegardée sur disque
 * (fichier JSON) pour pouvoir reprendre exactement là où on s'était arrêté.
 */
class DownloadRepository(context: Context, scope: CoroutineScope) {

    private val file = File(context.filesDir, "downloads.json")
    private val dirty = AtomicBoolean(false)
    private val writeLock = Any()

    private val _items = MutableStateFlow(load())
    val items: StateFlow<List<DownloadItem>> = _items.asStateFlow()

    init {
        scope.launch(Dispatchers.IO) {
            while (true) {
                delay(2000)
                if (dirty.compareAndSet(true, false)) persist()
            }
        }
    }

    fun get(id: String): DownloadItem? = _items.value.firstOrNull { it.id == id }

    fun add(item: DownloadItem) {
        _items.update { listOf(item) + it }
        saveNow()
    }

    fun remove(id: String) {
        _items.update { list -> list.filterNot { it.id == id } }
        saveNow()
    }

    fun update(id: String, transform: (DownloadItem) -> DownloadItem) {
        _items.update { list -> list.map { if (it.id == id) transform(it) else it } }
        dirty.set(true)
    }

    fun updateAll(transform: (DownloadItem) -> DownloadItem) {
        _items.update { list -> list.map(transform) }
        dirty.set(true)
    }

    fun saveNow() {
        dirty.set(false)
        persist()
    }

    private fun persist() {
        synchronized(writeLock) {
            try {
                val arr = JSONArray()
                _items.value.forEach { arr.put(it.toJson()) }
                val tmp = File(file.parentFile, file.name + ".tmp")
                tmp.writeText(arr.toString())
                if (!tmp.renameTo(file)) {
                    file.delete()
                    tmp.renameTo(file)
                }
            } catch (_: Exception) {
            }
        }
    }

    private fun load(): List<DownloadItem> {
        if (!file.exists()) return emptyList()
        return try {
            val arr = JSONArray(file.readText())
            val out = ArrayList<DownloadItem>(arr.length())
            for (i in 0 until arr.length()) {
                val item = DownloadItem.fromJson(arr.getJSONObject(i))
                // Rien ne tourne encore au démarrage : ce qui était actif devient « en pause ».
                // DownloadManager relance ensuite ces éléments si la reprise automatique est activée.
                out.add(
                    if (item.status.isActive) item.copy(status = DlStatus.PAUSED, info = INTERRUPTED)
                    else item
                )
            }
            out
        } catch (_: Exception) {
            emptyList()
        }
    }

    companion object {
        const val INTERRUPTED = "Interrompu"
    }
}
