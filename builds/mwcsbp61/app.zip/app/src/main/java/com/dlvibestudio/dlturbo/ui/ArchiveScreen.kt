package com.dlvibestudio.dlturbo.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.dlvibestudio.dlturbo.App
import com.dlvibestudio.dlturbo.engine.ArchiveManager
import com.dlvibestudio.dlturbo.engine.Links
import com.dlvibestudio.dlturbo.util.Format
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Contenu d'une archive (ZIP, RAR, 7z, tar…) et extraction avec progression. */
@Composable
fun ArchiveScreen(app: App, file: File, onClose: () -> Unit) {
    val scope = rememberCoroutineScope()
    var entries by remember(file) { mutableStateOf<List<ArchiveManager.Entry>?>(null) }
    var error by remember(file) { mutableStateOf<String?>(null) }
    var needsPassword by remember(file) { mutableStateOf(false) }
    var password by remember(file) { mutableStateOf("") }
    var working by remember(file) { mutableStateOf(false) }
    var progress by remember(file) { mutableStateOf<Triple<Int, Int, String>?>(null) }
    var result by remember(file) { mutableStateOf<Pair<File, Int>?>(null) }
    var deleteAfter by remember(file) { mutableStateOf(false) }

    fun load() {
        scope.launch {
            error = null
            try {
                entries = withContext(Dispatchers.IO) { ArchiveManager.list(file, password.ifBlank { null }) }
                needsPassword = false
            } catch (_: ArchiveManager.PasswordRequired) {
                needsPassword = true
                entries = null
                if (password.isNotBlank()) error = "Mot de passe incorrect"
            } catch (e: Exception) {
                entries = null
                error = e.message ?: "Archive illisible"
            }
        }
    }
    LaunchedEffect(file) { load() }

    fun extract() {
        scope.launch {
            working = true
            error = null
            progress = Triple(0, -1, "")
            try {
                val parent = file.parentFile ?: file.absoluteFile.parentFile!!
                val dest = Links.uniqueFile(parent, ArchiveManager.defaultFolderName(file))
                val count = withContext(Dispatchers.IO) {
                    ArchiveManager.extract(
                        file, dest, password.ifBlank { null },
                        isCancelled = { !isActive },
                        onProgress = { done, total, name -> progress = Triple(done, total, name) },
                    )
                }
                if (deleteAfter) withContext(Dispatchers.IO) { file.delete() }
                result = dest to count
            } catch (_: ArchiveManager.PasswordRequired) {
                needsPassword = true
                error = if (password.isBlank()) "Cette archive est protégée par un mot de passe" else "Mot de passe incorrect"
            } catch (e: Exception) {
                error = e.message ?: "Échec de l'extraction"
            } finally {
                working = false
                progress = null
            }
        }
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize()) {
            ViewerBar(file.name, onClose)

            val done = result
            if (done != null) {
                Column(
                    Modifier.fillMaxSize().padding(24.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Icon(Icons.Filled.Folder, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(72.dp))
                    Spacer(Modifier.height(12.dp))
                    Text("Extraction terminée", style = MaterialTheme.typography.titleLarge)
                    Text(
                        "${done.second} fichier(s) dans « ${done.first.name} »",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(20.dp))
                    Button(onClick = {
                        app.viewer.value = null
                        app.openFolder.value = done.first
                    }) { Text("Ouvrir le dossier") }
                    OutlinedButton(onClick = onClose) { Text("Fermer") }
                }
                return@Column
            }

            if (needsPassword) {
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Mot de passe de l'archive") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                )
                OutlinedButton(
                    onClick = { load() },
                    modifier = Modifier.padding(horizontal = 16.dp),
                ) { Text("Déverrouiller") }
            }

            error?.let {
                Text(
                    it,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(16.dp),
                )
            }

            val list = entries
            when {
                list != null -> {
                    val files = list.count { !it.isDir }
                    val total = list.filter { !it.isDir && it.size >= 0 }.sumOf { it.size }
                    Text(
                        "$files fichier(s)" + if (total > 0) " · ${Format.bytes(total)} décompressés" else "",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    )
                    LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                        items(list.take(2000)) { e ->
                            Row(
                                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(
                                    if (e.isDir) Icons.Filled.Folder else Icons.Filled.Description,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(20.dp),
                                )
                                Text(
                                    e.name,
                                    modifier = Modifier.weight(1f).padding(horizontal = 12.dp),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    style = MaterialTheme.typography.bodyMedium,
                                )
                                if (!e.isDir && e.size >= 0) {
                                    Text(
                                        Format.bytes(e.size),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                            }
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                        }
                    }
                    Column(Modifier.fillMaxWidth().padding(16.dp)) {
                        val p = progress
                        if (working && p != null) {
                            if (p.second > 0) {
                                LinearProgressIndicator(
                                    progress = { (p.first.toFloat() / p.second).coerceIn(0f, 1f) },
                                    modifier = Modifier.fillMaxWidth(),
                                )
                            } else {
                                LinearProgressIndicator(Modifier.fillMaxWidth())
                            }
                            Text(
                                "${p.first}" + (if (p.second > 0) "/${p.second}" else "") + " · " + p.third,
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(top = 6.dp),
                            )
                        } else {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = deleteAfter, onCheckedChange = { deleteAfter = it })
                                Text("Supprimer l'archive après extraction", style = MaterialTheme.typography.bodyMedium)
                            }
                            Button(onClick = { extract() }, modifier = Modifier.fillMaxWidth()) {
                                Text("Tout extraire")
                            }
                        }
                    }
                }

                !needsPassword && error == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
        }
    }
}
