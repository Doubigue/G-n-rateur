package com.dlvibestudio.dlturbo.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.dlvibestudio.dlturbo.R
import com.dlvibestudio.dlturbo.data.DlStatus
import com.dlvibestudio.dlturbo.data.DownloadItem
import com.dlvibestudio.dlturbo.ui.MainActivity
import com.dlvibestudio.dlturbo.util.Format

object Notifications {

    const val CH_PROGRESS = "progress"
    const val CH_DONE = "done"
    const val CH_DONE_SILENT = "done_silent"
    const val SUMMARY_ID = 1
    private const val GOLD = 0xFFF5B301.toInt()

    fun createChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = context.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(
            NotificationChannel(CH_PROGRESS, "Téléchargements en cours", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Progression, pourcentage et vitesse"
                setShowBadge(false)
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_DONE, "Téléchargements terminés", NotificationManager.IMPORTANCE_DEFAULT)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_DONE_SILENT, "Téléchargements terminés (silencieux)", NotificationManager.IMPORTANCE_LOW)
        )
    }

    fun idFor(item: DownloadItem): Int = 1000 + (item.id.hashCode() and 0x0FFFFFFF)

    private fun flags() = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

    private fun openApp(context: Context): PendingIntent = PendingIntent.getActivity(
        context, 0,
        Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
        flags(),
    )

    private fun action(context: Context, action: String, id: String?): PendingIntent {
        val intent = Intent(context, ActionReceiver::class.java).setAction(action)
        if (id != null) intent.putExtra(ActionReceiver.EXTRA_ID, id)
        val code = (action + (id ?: "")).hashCode()
        return PendingIntent.getBroadcast(context, code, intent, flags())
    }

    /** Notification permanente du service : nombre de téléchargements, pourcentage global, vitesse. */
    fun summary(context: Context, active: List<DownloadItem>): Notification {
        val running = active.count { it.status == DlStatus.RUNNING || it.status == DlStatus.CONNECTING }
        val queued = active.count { it.status == DlStatus.QUEUED }
        val waiting = active.count { it.status == DlStatus.WAITING_NETWORK }
        val speed = active.sumOf { it.speed }
        val known = active.filter { it.totalBytes > 0 || it.percent >= 0f }
        val percent = if (known.isEmpty()) -1 else (known.map { it.progress }.average() * 100).toInt()

        val title = when {
            active.isEmpty() -> "Turbo Download"
            active.size == 1 -> "1 téléchargement en cours"
            else -> "${active.size} téléchargements en cours"
        }
        val parts = ArrayList<String>()
        if (percent >= 0) parts.add("$percent %")
        if (speed > 0) parts.add(Format.speed(speed))
        if (running > 0 && active.size > 1) parts.add("$running actifs")
        if (queued > 0) parts.add("$queued en file")
        if (waiting > 0) parts.add("$waiting en attente du réseau")

        val b = NotificationCompat.Builder(context, CH_PROGRESS)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(GOLD)
            .setContentTitle(title)
            .setContentText(parts.joinToString(" · ").ifBlank { "Préparation…" })
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setContentIntent(openApp(context))
        if (active.isNotEmpty()) {
            b.setProgress(100, percent.coerceAtLeast(0), percent < 0)
            b.addAction(0, "Tout suspendre", action(context, ActionReceiver.PAUSE_ALL, null))
        }
        return b.build()
    }

    /** Notification d'un téléchargement : nom, pourcentage, tailles, vitesse, temps restant. */
    fun progress(context: Context, item: DownloadItem): Notification {
        val parts = ArrayList<String>()
        val indeterminate = item.totalBytes <= 0 && item.percent < 0f
        if (!indeterminate) parts.add("${item.percentInt} %")
        if (item.totalBytes > 0) {
            parts.add("${Format.bytes(item.downloadedBytes)} / ${Format.bytes(item.totalBytes)}")
        } else if (item.downloadedBytes > 0) {
            parts.add(Format.bytes(item.downloadedBytes))
        }
        if (item.speed > 0) parts.add(Format.speed(item.speed))
        if (item.etaSeconds >= 0) parts.add("reste " + Format.duration(item.etaSeconds))
        val text = when (item.status) {
            DlStatus.QUEUED -> "En file d'attente"
            DlStatus.WAITING_NETWORK -> item.info.ifBlank { "En attente du réseau" }
            DlStatus.CONNECTING -> item.info.ifBlank { "Connexion…" }
            else -> parts.joinToString(" · ").ifBlank { item.info }
        }
        return NotificationCompat.Builder(context, CH_PROGRESS)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(GOLD)
            .setContentTitle(item.fileName)
            .setContentText(text)
            .setSubText(if (indeterminate) null else "${item.percentInt} %")
            .setProgress(100, item.percentInt, indeterminate || item.status == DlStatus.CONNECTING)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setContentIntent(openApp(context))
            .addAction(0, "Pause", action(context, ActionReceiver.PAUSE, item.id))
            .addAction(0, "Annuler", action(context, ActionReceiver.CANCEL, item.id))
            .build()
    }

    fun paused(context: Context, item: DownloadItem): Notification =
        NotificationCompat.Builder(context, CH_PROGRESS)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(GOLD)
            .setContentTitle(item.fileName)
            .setContentText("En pause · ${item.percentInt} %")
            .setProgress(100, item.percentInt, false)
            .setOnlyAlertOnce(true)
            .setContentIntent(openApp(context))
            .addAction(0, "Reprendre", action(context, ActionReceiver.RESUME, item.id))
            .addAction(0, "Annuler", action(context, ActionReceiver.CANCEL, item.id))
            .build()

    fun done(context: Context, item: DownloadItem, sound: Boolean): Notification =
        NotificationCompat.Builder(context, if (sound) CH_DONE else CH_DONE_SILENT)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(GOLD)
            .setContentTitle("Téléchargement terminé")
            .setContentText(
                item.fileName + if (item.totalBytes > 0) " · " + Format.bytes(item.totalBytes) else ""
            )
            .setAutoCancel(true)
            .setContentIntent(openApp(context))
            .build()

    fun failed(context: Context, item: DownloadItem): Notification =
        NotificationCompat.Builder(context, CH_DONE_SILENT)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(GOLD)
            .setContentTitle("Échec : ${item.fileName}")
            .setContentText(item.error ?: "Erreur inconnue")
            .setStyle(NotificationCompat.BigTextStyle().bigText(item.error ?: "Erreur inconnue"))
            .setAutoCancel(true)
            .setContentIntent(openApp(context))
            .addAction(0, "Réessayer", action(context, ActionReceiver.RESUME, item.id))
            .build()
}
