package com.dlvibestudio.dlturbo.engine

import org.json.JSONArray
import org.json.JSONObject

/** Une vidéo (ou une playlist) dans une liste de résultats. */
data class YtEntry(
    val id: String,
    val url: String,
    val title: String,
    val channel: String,
    val durationSec: Long,
    val views: Long,
    val thumbnail: String,
    val isPlaylist: Boolean,
    val count: Int = 0,
)

/** Une ligne du sélecteur de formats : « MP4 · 1080p · 45 Mo ». */
data class QualityOption(
    /** Valeur transmise au moteur : « 1080 », « best »… */
    val key: String,
    val label: String,
    val detail: String,
    val sizeBytes: Long,
)

data class VideoDetails(
    val url: String,
    val title: String,
    val uploader: String,
    val durationSec: Long,
    val thumbnail: String,
    val isPlaylist: Boolean,
    val entries: List<YtEntry>,
    val videoOptions: List<QualityOption>,
    val audioSizeEstimate: Long,
)

/** Transformation du JSON de yt-dlp en objets utilisables par l'interface. */
object VideoInfo {

    fun thumbnailFor(id: String) = "https://i.ytimg.com/vi/$id/mqdefault.jpg"

    /** Lien « liste de lecture pure » : playlist?list=… ou watch sans v=. */
    fun isPurePlaylist(url: String): Boolean {
        val u = url.lowercase()
        if (!u.contains("list=")) return false
        if (u.contains("youtu.be/")) return false
        return !Regex("""[?&]v=""").containsMatchIn(u)
    }

    fun hasPlaylistParam(url: String) = url.contains("list=", ignoreCase = true)

    fun entries(json: JSONObject): List<YtEntry> {
        val arr = json.optJSONArray("entries") ?: return emptyList()
        val out = ArrayList<YtEntry>(arr.length())
        for (i in 0 until arr.length()) {
            val e = arr.optJSONObject(i) ?: continue
            val id = e.optString("id")
            val url = e.optString("url").ifBlank { e.optString("webpage_url") }
            val ieKey = e.optString("ie_key")
            val isPlaylist = ieKey.contains("Tab", ignoreCase = true) ||
                ieKey.contains("Playlist", ignoreCase = true) ||
                e.optString("_type") == "playlist" ||
                url.contains("/playlist?list=")
            if (id.isBlank() && url.isBlank()) continue
            val fullUrl = when {
                url.startsWith("http") -> url
                isPlaylist -> "https://www.youtube.com/playlist?list=$id"
                else -> "https://www.youtube.com/watch?v=$id"
            }
            out.add(
                YtEntry(
                    id = id,
                    url = fullUrl,
                    title = e.optString("title").ifBlank { "Sans titre" },
                    channel = e.optString("channel").ifBlank { e.optString("uploader") },
                    durationSec = e.optLong("duration", 0),
                    views = e.optLong("view_count", 0),
                    thumbnail = bestThumbnail(e) ?: if (!isPlaylist && id.isNotBlank()) thumbnailFor(id) else "",
                    isPlaylist = isPlaylist,
                    count = e.optInt("playlist_count", 0),
                )
            )
        }
        return out
    }

    private fun bestThumbnail(e: JSONObject): String? {
        val direct = e.optString("thumbnail")
        if (direct.startsWith("http")) return direct
        val arr: JSONArray = e.optJSONArray("thumbnails") ?: return null
        var best: String? = null
        var bestWidth = 0
        for (i in 0 until arr.length()) {
            val t = arr.optJSONObject(i) ?: continue
            val url = t.optString("url")
            if (!url.startsWith("http")) continue
            val w = t.optInt("width", 0)
            // On préfère ~320 px : léger à charger, assez net pour une miniature.
            val score = if (w == 0) 1 else if (w in 200..480) 1000 - kotlin.math.abs(w - 320) else 500 - kotlin.math.abs(w - 320).coerceAtMost(499)
            if (best == null || score > bestWidth) {
                best = url
                bestWidth = score
            }
        }
        return best
    }

    fun details(url: String, json: JSONObject): VideoDetails {
        val isPlaylist = json.optString("_type") == "playlist" || json.has("entries")
        val title = json.optString("title").ifBlank { "Vidéo" }
        val uploader = json.optString("uploader").ifBlank { json.optString("channel") }
        val thumb = bestThumbnail(json) ?: json.optString("id").takeIf { it.isNotBlank() && !isPlaylist }
            ?.let { thumbnailFor(it) } ?: ""

        if (isPlaylist) {
            val list = entries(json)
            return VideoDetails(
                url = url, title = title, uploader = uploader, durationSec = 0,
                thumbnail = thumb.ifBlank { list.firstOrNull()?.thumbnail ?: "" },
                isPlaylist = true, entries = list,
                videoOptions = emptyList(), audioSizeEstimate = 0,
            )
        }

        val formats = json.optJSONArray("formats")
        val bestAudioSize = bestAudioSize(formats)
        val byHeight = HashMap<Int, Long>() // hauteur -> taille estimée (0 = inconnue)
        val fps = HashMap<Int, Int>()
        if (formats != null) {
            for (i in 0 until formats.length()) {
                val f = formats.optJSONObject(i) ?: continue
                val vcodec = f.optString("vcodec", "none")
                val acodec = f.optString("acodec", "none")
                val height = f.optInt("height", 0)
                if (vcodec == "none" || height <= 0) continue
                val ext = f.optString("ext")
                if (ext == "mhtml") continue
                var size = f.optLong("filesize", 0)
                if (size <= 0) size = f.optLong("filesize_approx", 0)
                if (size > 0 && acodec == "none") size += bestAudioSize
                val old = byHeight[height]
                if (old == null || size > old) byHeight[height] = size
                fps[height] = maxOf(fps[height] ?: 0, f.optInt("fps", 0))
            }
        }
        val options = ArrayList<QualityOption>()
        for (h in byHeight.keys.sortedDescending()) {
            val size = byHeight[h] ?: 0
            val f = fps[h] ?: 0
            val label = when {
                h >= 4320 -> "8K"
                h >= 2160 -> "4K"
                h >= 1440 -> "2K"
                else -> "${h}p"
            } + if (f > 30) " ${f}fps" else ""
            options.add(QualityOption(h.toString(), label, "MP4", size))
        }
        if (options.isEmpty()) {
            val size = json.optLong("filesize", 0).takeIf { it > 0 } ?: json.optLong("filesize_approx", 0)
            options.add(QualityOption("best", "Meilleure qualité", "MP4", size))
        }
        return VideoDetails(
            url = url, title = title, uploader = uploader,
            durationSec = json.optLong("duration", 0),
            thumbnail = thumb, isPlaylist = false, entries = emptyList(),
            videoOptions = options, audioSizeEstimate = bestAudioSize,
        )
    }

    private fun bestAudioSize(formats: JSONArray?): Long {
        if (formats == null) return 0
        var best = 0L
        var bestAbr = -1.0
        for (i in 0 until formats.length()) {
            val f = formats.optJSONObject(i) ?: continue
            if (f.optString("vcodec", "none") != "none") continue
            if (f.optString("acodec", "none") == "none") continue
            val abr = f.optDouble("abr", 0.0)
            var size = f.optLong("filesize", 0)
            if (size <= 0) size = f.optLong("filesize_approx", 0)
            if (abr > bestAbr || (abr == bestAbr && size > best)) {
                bestAbr = abr
                best = size
            }
        }
        return best
    }
}
