package com.dlvibestudio.dlturbo.engine

import android.net.Uri
import android.webkit.MimeTypeMap
import java.io.File
import java.net.URLDecoder

/** Reconnaissance des liens et utilitaires de noms de fichiers. */
object Links {

    private val VIDEO_HOSTS = listOf(
        "youtube.com", "youtu.be", "youtube-nocookie.com",
        "instagram.com", "instagr.am",
        "facebook.com", "fb.watch", "fb.com",
        "tiktok.com",
        "pinterest.", "pin.it",
        "twitter.com", "x.com", "t.co",
        "vimeo.com", "dailymotion.com", "dai.ly",
        "twitch.tv", "reddit.com", "redd.it",
        "soundcloud.com", "snapchat.com", "threads.net", "threads.com",
        "likee.video", "bilibili.com", "vk.com", "ok.ru", "rumble.com",
        "linkedin.com", "tumblr.com", "streamable.com", "kwai.com", "bsky.app",
    )

    private val URL_REGEX = Regex("""(magnet:\?[^\s]+|https?://[^\s]+)""", RegexOption.IGNORE_CASE)

    fun isMagnet(url: String) = url.startsWith("magnet:", ignoreCase = true)

    fun isTorrentUrl(url: String): Boolean {
        val path = runCatching { Uri.parse(url).path }.getOrNull() ?: return false
        return path.endsWith(".torrent", ignoreCase = true)
    }

    fun isVideoSite(url: String): Boolean {
        val host = runCatching { Uri.parse(url).host }.getOrNull()?.lowercase() ?: return false
        return VIDEO_HOSTS.any { host == it || host.endsWith(".$it") || (it.endsWith(".") && host.contains(it)) }
    }

    /** Extrait tous les liens d'un texte (texte partagé, presse-papiers, plusieurs lignes…). */
    fun extract(text: String): List<String> =
        URL_REGEX.findAll(text).map { it.value.trim().trimEnd(',', ';', ')', '"', '\'') }
            .distinct().toList()

    fun hostOf(url: String): String =
        runCatching { Uri.parse(url).host }.getOrNull()?.removePrefix("www.") ?: "lien"

    /** Nom de fichier à partir de l'en-tête Content-Disposition, sinon de l'URL. */
    fun fileName(url: String, contentDisposition: String?, mime: String?): String {
        var name: String? = null
        if (contentDisposition != null) {
            val star = Regex("""filename\*\s*=\s*(?:UTF-8|utf-8)''([^;]+)""").find(contentDisposition)
            val plain = Regex("""filename\s*=\s*"?([^";]+)"?""").find(contentDisposition)
            name = when {
                star != null -> runCatching { URLDecoder.decode(star.groupValues[1], "UTF-8") }.getOrNull()
                plain != null -> plain.groupValues[1].trim()
                else -> null
            }
        }
        if (name.isNullOrBlank()) {
            name = runCatching { Uri.parse(url).lastPathSegment }.getOrNull()
        }
        if (name.isNullOrBlank()) name = "fichier"
        name = sanitize(name)
        if (!name.contains('.') || name.substringAfterLast('.').length > 6) {
            val ext = mime?.substringBefore(';')?.trim()?.let {
                MimeTypeMap.getSingleton().getExtensionFromMimeType(it)
            }
            if (!ext.isNullOrBlank() && ext != "bin") name = "$name.$ext"
        }
        return name
    }

    fun sanitize(name: String): String {
        val cleaned = name.replace(Regex("""[\\/:*?"<>|\u0000-\u001f]"""), "_").trim().trim('.')
        return (if (cleaned.isBlank()) "fichier" else cleaned).take(180)
    }

    /** Évite d'écraser un fichier existant : « nom (1).ext », « nom (2).ext »… */
    fun uniqueFile(dir: File, name: String, reserved: Set<String> = emptySet()): File {
        var candidate = File(dir, name)
        if (!taken(candidate, reserved)) return candidate
        val base = name.substringBeforeLast('.', name)
        val ext = if (name.contains('.')) "." + name.substringAfterLast('.') else ""
        var i = 1
        while (true) {
            candidate = File(dir, "$base ($i)$ext")
            if (!taken(candidate, reserved)) return candidate
            i++
        }
    }

    private fun taken(f: File, reserved: Set<String>) =
        f.exists() || File(f.path + PART_SUFFIX).exists() || reserved.contains(f.path)

    const val PART_SUFFIX = ".dlpart"

    fun mimeOf(fileName: String): String {
        val ext = fileName.substringAfterLast('.', "").lowercase()
        if (ext == "apk") return "application/vnd.android.package-archive"
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
    }

    /** Sous-dossier de rangement selon le type de fichier. */
    fun category(fileName: String): String {
        return when (fileName.substringAfterLast('.', "").lowercase()) {
            "mp4", "mkv", "webm", "avi", "mov", "flv", "3gp", "m4v", "ts", "wmv" -> "Vidéos"
            "mp3", "m4a", "aac", "flac", "wav", "ogg", "opus", "wma" -> "Musique"
            "jpg", "jpeg", "png", "gif", "webp", "bmp", "svg", "heic", "avif" -> "Images"
            "apk", "xapk", "apks", "apkm" -> "APK"
            "zip", "rar", "7z", "tar", "gz", "bz2", "xz", "iso" -> "Archives"
            "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "epub", "csv" -> "Documents"
            "exe", "msi", "dmg", "deb", "rpm", "appimage", "pkg" -> "Logiciels"
            else -> "Autres"
        }
    }
}
