@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package com.dlvibestudio.dlturbo.ui

import android.graphics.Bitmap
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.dlvibestudio.dlturbo.App
import com.dlvibestudio.dlturbo.engine.ApkInstaller
import com.dlvibestudio.dlturbo.engine.ArchiveManager
import com.dlvibestudio.dlturbo.util.Format
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

private fun listFolder(dir: File): List<File> =
    (dir.listFiles() ?: emptyArray())
        .filter { !it.name.endsWith(".dlpart") && !it.name.startsWith(".") }
        .sortedWith(compareByDescending<File> { it.isDirectory }.thenBy { it.name.lowercase() })

/** Gestionnaire de fichiers : tous les téléchargements, avec miniatures et lecteurs intégrés. */
@Composable
fun FilesScreen(app: App, onOpenSettings: () -> Unit) {
    val context = LocalContext.current
    val root = remember { app.manager.baseDir }
    var dir by remember { mutableStateOf(root) }
    var version by remember { mutableIntStateOf(0) }
    var files by remember { mutableStateOf<List<File>>(emptyList()) }
    var renaming by remember { mutableStateOf<File?>(null) }
    var deleting by remember { mutableStateOf<File?>(null) }
    var converting by remember { mutableStateOf<File?>(null) }
    var vaultOpen by remember { mutableStateOf(false) }

    val request by app.openFolder.collectAsState()
    LaunchedEffect(request) {
        val f = request ?: return@LaunchedEffect
        dir = if (f.isDirectory) f else (f.parentFile ?: root)
        app.openFolder.value = null
    }

    LaunchedEffect(dir, version) {
        files = withContext(Dispatchers.IO) { listFolder(dir) }
    }

    val atRoot = dir.canonicalPath == root.canonicalPath || !dir.canonicalPath.startsWith(root.canonicalPath)
    BackHandler(enabled = !atRoot) { dir = dir.parentFile ?: root }

    if (vaultOpen) {
        VaultScreen(app, onClose = { vaultOpen = false; version++ })
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Fichiers", fontWeight = FontWeight.Bold)
                        Text(
                            if (atRoot) root.name else dir.relativeTo(root).path,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                },
                navigationIcon = {
                    if (!atRoot) IconButton(onClick = { dir = dir.parentFile ?: root }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Dossier parent")
                    }
                },
                actions = {
                    // « Lire tout le dossier » : playlist de tous les médias du dossier courant
                    val medias = files.filter { FileKinds.isMedia(it) }
                    if (medias.isNotEmpty()) {
                        IconButton(onClick = { app.viewer.value = ViewerRequest.Media(medias, 0) }) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = "Lire tout le dossier")
                        }
                    }
                    IconButton(onClick = { vaultOpen = true }) {
                        Icon(Icons.Filled.Lock, contentDescription = "Coffre privé")
                    }
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Filled.Settings, contentDescription = "Paramètres")
                    }
                },
            )
        },
    ) { padding ->
        if (files.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("Dossier vide", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(bottom = 16.dp),
            ) {
                items(files, key = { it.path }) { f ->
                    FileRow(
                        app = app,
                        file = f,
                        onClick = { if (f.isDirectory) dir = f else FileOpener.open(context, app, f) },
                        onRename = { renaming = f },
                        onDelete = { deleting = f },
                        onConvert = { converting = f },
                        onChanged = { version++ },
                    )
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                }
            }
        }
    }

    converting?.let { f ->
        ConvertDialog(app, f, onDone = { version++ }, onDismiss = { converting = null })
    }

    renaming?.let { f ->
        var name by remember(f) { mutableStateOf(f.name) }
        AlertDialog(
            onDismissRequest = { renaming = null },
            title = { Text("Renommer") },
            text = { OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = {
                    val clean = name.trim().replace('/', '_')
                    val target = File(f.parentFile, clean)
                    val ok = clean.isNotEmpty() && !target.exists() && f.renameTo(target)
                    if (!ok) Toast.makeText(context, "Impossible de renommer", Toast.LENGTH_SHORT).show()
                    renaming = null
                    version++
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { renaming = null }) { Text("Annuler") } },
        )
    }

    deleting?.let { f ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Supprimer ?") },
            text = { Text(f.name + if (f.isDirectory) "\n\nLe dossier et son contenu seront supprimés." else "") },
            confirmButton = {
                TextButton(onClick = {
                    val ok = if (f.isDirectory) f.deleteRecursively() else f.delete()
                    if (!ok) Toast.makeText(context, "Suppression impossible", Toast.LENGTH_SHORT).show()
                    deleting = null
                    version++
                }) { Text("Supprimer", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Annuler") } },
        )
    }
}

@Composable
private fun FileRow(
    app: App,
    file: File,
    onClick: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit,
    onConvert: () -> Unit,
    onChanged: () -> Unit,
) {
    val context = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth()
            .combinedClickable(onClick = onClick, onLongClick = { menu = true })
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        FileThumb(file)
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(
                file.name,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
            )
            Text(
                if (file.isDirectory) "${file.list()?.size ?: 0} élément(s)" else Format.bytes(file.length()),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Box {
            IconButton(onClick = { menu = true }) {
                Icon(Icons.Filled.MoreVert, contentDescription = "Actions")
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("Ouvrir") }, onClick = { menu = false; onClick() })
                if (file.isFile) {
                    if (ApkInstaller.canInstall(file)) {
                        DropdownMenuItem(
                            text = { Text("Installer") },
                            onClick = { menu = false; FileOpener.open(context, app, file) },
                        )
                    }
                    if (ArchiveManager.isArchive(file)) {
                        DropdownMenuItem(
                            text = { Text("Décompresser") },
                            onClick = { menu = false; app.viewer.value = ViewerRequest.Archive(file) },
                        )
                    }
                    DropdownMenuItem(
                        text = { Text("Ouvrir avec une autre application") },
                        onClick = { menu = false; FileOpener.openExternal(context, file) },
                    )
                    if (FileKinds.isMedia(file)) {
                        DropdownMenuItem(
                            text = { Text("Convertir / couper…") },
                            onClick = { menu = false; onConvert() },
                        )
                    }
                    DropdownMenuItem(
                        text = { Text("Mettre au coffre") },
                        onClick = {
                            menu = false
                            val ok = Vault.put(app, file)
                            Toast.makeText(
                                context,
                                if (ok) "Déplacé dans le coffre" else "Impossible de déplacer le fichier",
                                Toast.LENGTH_SHORT,
                            ).show()
                            onChanged()
                        },
                    )
                    DropdownMenuItem(
                        text = { Text("Partager") },
                        onClick = { menu = false; FileOpener.share(context, file) },
                    )
                }
                DropdownMenuItem(text = { Text("Renommer") }, onClick = { menu = false; onRename() })
                DropdownMenuItem(
                    text = { Text("Supprimer", color = MaterialTheme.colorScheme.error) },
                    onClick = { menu = false; onDelete() },
                )
            }
        }
    }
}

@Composable
private fun FileThumb(file: File) {
    val isImage = FileKinds.isImage(file)
    val isVideo = FileKinds.isVideo(file)
    val isApk = ApkInstaller.isApk(file)
    val context = LocalContext.current
    var bitmap by remember(file.path, file.lastModified()) { mutableStateOf<Bitmap?>(null) }
    if (isImage || isVideo || isApk) {
        LaunchedEffect(file.path, file.lastModified()) {
            bitmap = withContext(Dispatchers.IO) {
                when {
                    isApk -> Thumbs.apk(context, file)
                    isImage -> Thumbs.image(file, 160)
                    else -> Thumbs.video(file)
                }
            }
        }
    }
    val colors = MaterialTheme.colorScheme
    Box(
        Modifier.size(52.dp).clip(RoundedCornerShape(10.dp)).background(colors.primaryContainer),
        contentAlignment = Alignment.Center,
    ) {
        val bmp = bitmap
        if (bmp != null) {
            Image(
                bitmap = bmp.asImageBitmap(),
                contentDescription = null,
                contentScale = if (isApk) ContentScale.Fit else ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
            if (isVideo) {
                Icon(Icons.Filled.PlayArrow, null, tint = androidx.compose.ui.graphics.Color.White)
            }
        } else {
            val icon = when {
                file.isDirectory -> Icons.Filled.Folder
                isVideo -> Icons.Filled.Movie
                FileKinds.isAudio(file) -> Icons.Filled.MusicNote
                isImage -> Icons.Filled.Image
                ApkInstaller.canInstall(file) -> Icons.Filled.Android
                ArchiveManager.isArchive(file) -> Icons.Filled.FolderZip
                file.extension.lowercase() in FileKinds.WEB || file.extension.lowercase() in FileKinds.TEXT ->
                    Icons.Filled.Description
                else -> Icons.AutoMirrored.Filled.InsertDriveFile
            }
            Icon(icon, contentDescription = null, tint = colors.onPrimaryContainer)
        }
    }
    Spacer(Modifier.width(0.dp))
}
