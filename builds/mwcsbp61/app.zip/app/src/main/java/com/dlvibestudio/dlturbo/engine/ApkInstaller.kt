package com.dlvibestudio.dlturbo.engine

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import java.util.zip.ZipFile

/** Installation d'applications : APK simples et bundles (.xapk / .apks / .apkm). */
object ApkInstaller {

    const val ACTION_RESULT = "com.dlvibestudio.dlturbo.INSTALL_RESULT"

    fun isApk(file: File) = file.extension.equals("apk", ignoreCase = true)

    fun isBundle(file: File) = file.extension.lowercase() in setOf("xapk", "apks", "apkm")

    fun canInstall(file: File) = isApk(file) || isBundle(file)

    /** Lance l'installation. Renvoie false si l'autorisation « sources inconnues » manque. */
    suspend fun install(context: Context, file: File): Boolean {
        if (!ensurePermission(context)) return false
        if (isBundle(file)) {
            installBundle(context, file)
        } else {
            val uri = FileProvider.getUriForFile(context, context.packageName + ".files", file)
            val intent = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        }
        return true
    }

    /** Android demande une autorisation par application pour installer des APK. */
    private fun ensurePermission(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return true
        if (context.packageManager.canRequestPackageInstalls()) return true
        Toast.makeText(
            context,
            "Autorisez Turbo Download à installer des applications, puis réessayez",
            Toast.LENGTH_LONG,
        ).show()
        context.startActivity(
            Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + context.packageName))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        return false
    }

    private suspend fun installBundle(context: Context, file: File) = withContext(Dispatchers.IO) {
        ZipFile(file).use { zip ->
            val entries = zip.entries().toList().filter { !it.isDirectory && it.name.endsWith(".apk", true) }
            val chosen = entries.filter { wanted(it.name.substringAfterLast('/')) }
            if (chosen.isEmpty()) throw java.io.IOException("Aucun APK trouvé dans ce fichier")

            val installer = context.packageManager.packageInstaller
            val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
            val sessionId = installer.createSession(params)
            val session = installer.openSession(sessionId)
            try {
                for (e in chosen) {
                    val name = e.name.substringAfterLast('/')
                    zip.getInputStream(e).use { input ->
                        session.openWrite(name, 0, e.size.takeIf { it > 0 } ?: -1).use { out ->
                            input.copyTo(out, 128 * 1024)
                            session.fsync(out)
                        }
                    }
                }
                val intent = Intent(context, InstallReceiver::class.java).setAction(ACTION_RESULT)
                // Mutable : le système y ajoute le statut et l'éventuelle fenêtre de confirmation.
                val pending = PendingIntent.getBroadcast(
                    context, sessionId, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or
                        (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0),
                )
                session.commit(pending.intentSender)
            } catch (t: Throwable) {
                session.abandon()
                throw t
            } finally {
                session.close()
            }
        }
    }

    /**
     * Dans un bundle, on ne garde que ce qui correspond au téléphone :
     * APK de base + parties de code, processeur (ABI), densité d'écran et langues.
     */
    private fun wanted(fileName: String): Boolean {
        val n = fileName.lowercase().removeSuffix(".apk")
        val token = when {
            n.startsWith("split_config.") -> n.removePrefix("split_config.")
            n.startsWith("config.") -> n.removePrefix("config.")
            else -> return true // base.apk, split fonctionnels…
        }
        val abis = Build.SUPPORTED_ABIS.map { it.lowercase().replace('-', '_') }
        if (token in abis) return true
        if (token in ABI_TOKENS) return false
        if (token in DENSITY_TOKENS) return token == densityToken
        // Langue : « fr », « en », « pt_br »… on garde la langue du téléphone et l'anglais.
        val lang = Locale.getDefault().language.lowercase()
        return token == lang || token == "en" || token.startsWith(lang + "_")
    }

    private val ABI_TOKENS = setOf("arm64_v8a", "armeabi_v7a", "armeabi", "x86", "x86_64", "mips", "mips64")
    private val DENSITY_TOKENS = setOf("ldpi", "mdpi", "tvdpi", "hdpi", "xhdpi", "xxhdpi", "xxxhdpi", "nodpi")

    private val densityToken: String
        get() {
            val dpi = android.content.res.Resources.getSystem().displayMetrics.densityDpi
            return when {
                dpi <= 120 -> "ldpi"
                dpi <= 160 -> "mdpi"
                dpi <= 213 -> "tvdpi"
                dpi <= 240 -> "hdpi"
                dpi <= 320 -> "xhdpi"
                dpi <= 480 -> "xxhdpi"
                else -> "xxxhdpi"
            }
        }
}
