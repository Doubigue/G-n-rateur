package com.dlvibestudio.dlturbo.util

import java.security.MessageDigest
import java.security.SecureRandom

/** Code de verrouillage : on ne garde qu'une empreinte salée (SHA-256), jamais le code lui-même. */
object PinLock {
    fun newSalt(): String {
        val bytes = ByteArray(16)
        SecureRandom().nextBytes(bytes)
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun hash(pin: String, salt: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest((salt + ":" + pin).toByteArray())
        return digest.joinToString("") { "%02x".format(it) }
    }

    fun verify(pin: String, hash: String, salt: String): Boolean {
        if (hash.isEmpty()) return true
        return MessageDigest.isEqual(hash(pin, salt).toByteArray(), hash.toByteArray())
    }
}
