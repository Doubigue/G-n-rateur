import 'dart:io';

import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:video_player/video_player.dart';

/// Écran d'aperçu : lit la vidéo MP4 exportée avant de la partager.
class PreviewPage extends StatefulWidget {
  const PreviewPage({super.key, required this.path});
  final String path;

  @override
  State<PreviewPage> createState() => _PreviewPageState();
}

class _PreviewPageState extends State<PreviewPage> {
  late final VideoPlayerController _c;
  bool _ready = false;
  bool _loop = true;
  double _speed = 1;
  String? _error;

  @override
  void initState() {
    super.initState();
    _c = VideoPlayerController.file(File(widget.path));
    _c.addListener(() {
      if (mounted) setState(() {});
    });
    _c.initialize().then((_) async {
      if (!mounted) return;
      await _c.setLooping(_loop);
      await _c.play();
      setState(() => _ready = true);
    }).catchError((e) {
      if (mounted) setState(() => _error = '$e');
    });
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  String _fmt(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    final c = ((d.inMilliseconds.remainder(1000)) ~/ 100).toString();
    return '$m:$s.$c';
  }

  void _toggle() {
    if (_c.value.isPlaying) {
      _c.pause();
    } else {
      if (_c.value.position >= _c.value.duration) _c.seekTo(Duration.zero);
      _c.play();
    }
  }

  Future<void> _step(int ms) async {
    final target = _c.value.position + Duration(milliseconds: ms);
    final max = _c.value.duration;
    await _c.seekTo(target < Duration.zero
        ? Duration.zero
        : (target > max ? max : target));
  }

  @override
  Widget build(BuildContext context) {
    final v = _c.value;
    final total = v.duration.inMilliseconds;
    final pos = v.position.inMilliseconds.clamp(0, total > 0 ? total : 1);

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: const Text('Aperçu de la vidéo'),
        actions: [
          IconButton(
            tooltip: 'Partager',
            icon: const Icon(Icons.share),
            onPressed: () => Share.shareXFiles([XFile(widget.path)]),
          ),
        ],
      ),
      body: SafeArea(
        child: _error != null
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Text('Lecture impossible : $_error',
                      style: const TextStyle(color: Colors.white)),
                ),
              )
            : !_ready
                ? const Center(child: CircularProgressIndicator())
                : Column(children: [
                    Expanded(
                      child: GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTap: _toggle,
                        child: Center(
                          child: AspectRatio(
                            aspectRatio: v.aspectRatio,
                            child: Stack(
                              alignment: Alignment.center,
                              children: [
                                VideoPlayer(_c),
                                if (!v.isPlaying)
                                  const Icon(Icons.play_circle_fill,
                                      size: 72, color: Colors.white70),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    Slider(
                      value: pos.toDouble(),
                      min: 0,
                      max: total > 0 ? total.toDouble() : 1,
                      onChanged: (x) =>
                          _c.seekTo(Duration(milliseconds: x.round())),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(_fmt(v.position),
                              style: const TextStyle(color: Colors.white)),
                          Text(_fmt(v.duration),
                              style: const TextStyle(color: Colors.white)),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          IconButton(
                            tooltip: 'Boucle',
                            color: _loop ? Colors.lightBlueAccent : Colors.white54,
                            icon: const Icon(Icons.repeat),
                            onPressed: () {
                              setState(() => _loop = !_loop);
                              _c.setLooping(_loop);
                            },
                          ),
                          IconButton(
                            tooltip: 'Reculer 1 s',
                            color: Colors.white,
                            icon: const Icon(Icons.replay),
                            onPressed: () => _step(-1000),
                          ),
                          IconButton(
                            iconSize: 56,
                            color: Colors.white,
                            icon: Icon(v.isPlaying
                                ? Icons.pause_circle_filled
                                : Icons.play_circle_filled),
                            onPressed: _toggle,
                          ),
                          IconButton(
                            tooltip: 'Avancer 1 s',
                            color: Colors.white,
                            icon: const Icon(Icons.forward_5),
                            onPressed: () => _step(1000),
                          ),
                          PopupMenuButton<double>(
                            tooltip: 'Vitesse',
                            initialValue: _speed,
                            icon: const Icon(Icons.speed, color: Colors.white),
                            onSelected: (s) {
                              setState(() => _speed = s);
                              _c.setPlaybackSpeed(s);
                            },
                            itemBuilder: (_) => [
                              for (final s in [0.25, 0.5, 1.0, 1.5, 2.0])
                                PopupMenuItem(value: s, child: Text('×$s')),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ]),
      ),
    );
  }
}

/// Route d'aperçu : lecteur vidéo pour un MP4, image zoomable pour un GIF.
Route<void> previewRoute(String path) => MaterialPageRoute<void>(
      builder: (_) => path.toLowerCase().endsWith('.gif')
          ? GifPage(path: path)
          : PreviewPage(path: path),
    );

class GifPage extends StatelessWidget {
  const GifPage({super.key, required this.path});
  final String path;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: const Text('Aperçu du GIF'),
        actions: [
          IconButton(
            tooltip: 'Partager',
            icon: const Icon(Icons.share),
            onPressed: () => Share.shareXFiles([XFile(path)]),
          ),
        ],
      ),
      body: SafeArea(
        child: Center(
          child: InteractiveViewer(
            child: Image.file(File(path), fit: BoxFit.contain),
          ),
        ),
      ),
    );
  }
}
