import 'dart:async';
import 'dart:collection';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:archive/archive.dart';
import 'package:ffmpeg_kit_flutter_new/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_new/ffmpeg_session.dart';
import 'package:ffmpeg_kit_flutter_new/ffprobe_kit.dart';
import 'package:ffmpeg_kit_flutter_new/return_code.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:gal/gal.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shelf/shelf_io.dart' as shelf_io;
import 'package:shelf_static/shelf_static.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

import 'library_page.dart';
import 'preview_page.dart';

void main() {
  runZonedGuarded(
    () => runApp(
      MaterialApp(
        theme: ThemeData(colorSchemeSeed: Colors.indigo, useMaterial3: true),
        darkTheme: ThemeData(
            colorSchemeSeed: Colors.indigo,
            brightness: Brightness.dark,
            useMaterial3: true),
        themeMode: ThemeMode.system,
        home: const Home(),
      ),
    ),
    (e, st) => debugPrint('Erreur non gérée : $e\n$st'),
  );
}

/// Horloge virtuelle + enregistreur audio, injectés AVANT le chargement de la page.
///
/// Temps : requestAnimationFrame, setTimeout, setInterval, Date.now,
/// performance.now, animations CSS / Web Animations / SVG sont pilotés par
/// window.__seek(t) (t en ms).
///
/// Audio : les sons lancés par la page (new Audio().play(), <audio>, <video>,
/// Web Audio AudioBufferSourceNode.start) ne sont PAS joués : ils sont
/// enregistrés avec leur instant virtuel dans window.__audioEvents, puis
/// mixés dans la vidéo par FFmpeg.
const _shim = r'''
(function () {
  let virtual = 0, id = 0, uid = 0, tid = 0, rafs = [], rafCount = 0,
      toCount = 0, ivCount = 0, saw = false, autoDone = false;
  const d0 = Date.now();
  // Références réelles : servent à attendre un vrai rendu après chaque __seek.
  const realRaf = window.requestAnimationFrame.bind(window);
  const realSt = window.setTimeout.bind(window);
  window.__paint = n => new Promise(res => {
    let d = false; const f = () => { if (!d) { d = true; res(1); } };
    realSt(f, 150);
    const step = k => (k <= 0 ? f() : realRaf(() => step(k - 1)));
    step(n || 1);
  });
  const timers = new Map();
  const audioEvents = window.__audioEvents = [];

  ['animationstart', 'transitionstart'].forEach(e =>
    document.addEventListener(e, () => { saw = true; }, true));

  // ---- Horloge virtuelle
  window.requestAnimationFrame = cb => { rafCount++; rafs.push([++id, cb]); return id; };
  window.cancelAnimationFrame = i => { rafs = rafs.filter(r => r[0] !== i); };
  const mk = s => (typeof s === 'function' ? s : () => (0, eval)(String(s)));
  window.setTimeout = (cb, ms, ...a) => {
    toCount++;
    timers.set(++tid, { due: virtual + Math.max(+ms || 0, 0), cb: mk(cb), a, iv: 0 });
    return tid;
  };
  window.setInterval = (cb, ms, ...a) => {
    ivCount++;
    const iv = Math.max(+ms || 0, 1);
    timers.set(++tid, { due: virtual + iv, cb: mk(cb), a, iv });
    return tid;
  };
  window.clearTimeout = window.clearInterval = i => { timers.delete(i); };
  performance.now = () => virtual;
  Date.now = () => d0 + virtual;

  // ---- Enregistrement audio : éléments <audio>/<video>
  const mid = new WeakMap();
  const idOf = el => { if (!mid.has(el)) mid.set(el, ++uid); return mid.get(el); };
  HTMLMediaElement.prototype.play = function () {
    let s = this.currentSrc || this.src;
    if (!s) { const so = this.querySelector('source'); if (so) s = so.src; }
    if (s) {
      audioEvents.push({
        k: 'play', id: idOf(this), src: new URL(s, document.baseURI).href,
        t: virtual, off: this.currentTime || 0, loop: !!this.loop,
        rate: this.playbackRate || 1, vol: this.muted ? 0 : this.volume
      });
    }
    return Promise.resolve();
  };
  HTMLMediaElement.prototype.pause = function () {
    audioEvents.push({ k: 'stop', id: idOf(this), t: virtual });
  };

  // ---- Enregistrement audio : Web Audio API
  const abUrl = new WeakMap(), bufUrl = new WeakMap();
  const of = window.fetch;
  if (of) {
    window.fetch = function (input) {
      let url = null;
      try { url = new URL(typeof input === 'string' ? input : input.url, document.baseURI).href; } catch (e) {}
      return of.apply(this, arguments).then(res => {
        const ab = res.arrayBuffer.bind(res);
        res.arrayBuffer = () => ab().then(b => { if (url) abUrl.set(b, url); return b; });
        return res;
      });
    };
  }
  const oo = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (m, u) {
    this.addEventListener('load', () => {
      try {
        if (this.response instanceof ArrayBuffer)
          abUrl.set(this.response, new URL(u, document.baseURI).href);
      } catch (e) {}
    });
    return oo.apply(this, arguments);
  };
  const AC = window.BaseAudioContext || window.AudioContext || window.webkitAudioContext;
  if (AC) {
    const od = AC.prototype.decodeAudioData;
    AC.prototype.decodeAudioData = function (ab, ok, err) {
      const url = abUrl.get(ab);
      const tag = b => { if (url && b) bufUrl.set(b, url); return b; };
      const p = od.call(this, ab, ok ? b => ok(tag(b)) : undefined, err);
      return p && p.then ? p.then(tag) : p;
    };
  }
  const ASN = window.AudioBufferSourceNode;
  if (ASN) {
    const rel = (node, when) => {
      const now = node.context.currentTime;
      return when && when > now ? (when - now) * 1000 : 0;
    };
    ASN.prototype.start = function (when, offset, dur) {
      const url = bufUrl.get(this.buffer);
      if (url) {
        this.__id = ++uid;
        audioEvents.push({
          k: 'play', id: this.__id, src: url, t: virtual + rel(this, when),
          off: offset || 0, loop: !!this.loop, rate: this.playbackRate.value,
          vol: 1, dur: dur
        });
      }
    };
    ASN.prototype.stop = function (when) {
      if (this.__id)
        audioEvents.push({ k: 'stop', id: this.__id, t: virtual + rel(this, when) });
    };
  }

  window.__isAnimated = () =>
    saw || rafCount > 0 || ivCount > 0 || toCount > 1 ||
    document.getAnimations().length > 0 ||
    !!document.querySelector('animate,animateTransform,animateMotion,set');

  // ---- Mesure de la durée : simule le temps virtuel sans capture.
  // Retourne { end, loop, infinite } en ms.
  window.__measure = function (maxMs) {
    const step = 1000 / 30;
    let endFinite = 0, loopLen = 0, lastActive = 0, stillActive = false;
    for (let t = 0; t <= maxMs; t += step) {
      window.__seek(t);
      if (rafs.length > 0 || timers.size > 0) { lastActive = t; stillActive = true; }
      else stillActive = false;
      document.getAnimations().forEach(a => {
        try {
          const ct = a.effect.getComputedTiming();
          const dur = +ct.duration || 0, del = +ct.delay || 0, ed = +ct.endDelay || 0;
          if (ct.iterations === Infinity) {
            const alt = /alternate/.test(ct.direction) ? 2 : 1;
            loopLen = Math.max(loopLen, del + dur * alt);
          } else if (isFinite(ct.endTime)) {
            endFinite = Math.max(endFinite, ct.endTime + ed);
          }
        } catch (e) {}
      });
    }
    document.querySelectorAll('animate,animateTransform,animateMotion,set').forEach(n => {
      const p = v => { v = String(v || '').trim(); const m = v.match(/^([\d.]+)(ms|s)?$/);
        return m ? parseFloat(m[1]) * (m[2] === 'ms' ? 1 : 1000) : 0; };
      const b = p((n.getAttribute('begin') || '0').split(';')[0]);
      const d = p(n.getAttribute('dur'));
      const rc = n.getAttribute('repeatCount'), rd = p(n.getAttribute('repeatDur'));
      if (rc === 'indefinite' || n.getAttribute('repeatDur') === 'indefinite') loopLen = Math.max(loopLen, b + d);
      else endFinite = Math.max(endFinite, b + (rd || d * (parseFloat(rc) || 1)));
    });
    // tâche JS (rAF / timers) qui s'arrête d'elle-même
    if (!stillActive && lastActive > 0) endFinite = Math.max(endFinite, lastActive + step);
    return JSON.stringify({
      end: endFinite, loop: loopLen,
      infinite: stillActive, audio: audioEvents.slice()
    });
  };

  window.__seek = function (t) {
    let guard = 0;
    while (guard++ < 20000) {
      let best = null, bid = null;
      timers.forEach((v, k) => { if (v.due <= t && (!best || v.due < best.due)) { best = v; bid = k; } });
      if (!best) break;
      virtual = Math.max(virtual, best.due);
      if (best.iv) best.due += best.iv; else timers.delete(bid);
      try { best.cb(...best.a); } catch (e) {}
    }
    virtual = t;
    if (!autoDone) {
      autoDone = true;
      document.querySelectorAll('audio[autoplay],video[autoplay]').forEach(el => el.play());
    }
    document.getAnimations().forEach(a => { try { a.pause(); a.currentTime = t; } catch (e) {} });
    document.querySelectorAll('svg').forEach(s => {
      try { s.pauseAnimations(); s.setCurrentTime(t / 1000); } catch (e) {}
    });
    const cbs = rafs; rafs = [];
    cbs.forEach(([_, cb]) => { try { cb(virtual); } catch (e) {} });
  };
})();
''';

const _sample = '''
<html><body style="margin:0;background:#111;display:grid;place-items:center;height:100vh">
<div style="width:120px;height:120px;border-radius:24px;background:#6c8cff;
animation:m 2s ease-in-out infinite alternate">
</div>
<style>@keyframes m{from{transform:translateX(-120px) rotate(0)}
to{transform:translateX(120px) rotate(360deg);background:#ff6c9a}}</style>
</body></html>
''';

/// Un son joué par la page, avec son instant de départ (ms) dans la vidéo.
class _Snd {
  _Snd(this.file, this.t, this.off, this.vol, this.rate, this.loop, this.dur);
  final String file;
  final double t, off, vol, rate;
  final bool loop;
  double? dur; // secondes
}

String _n(double v) => v.toStringAsFixed(3);

/// Levée quand l'utilisateur appuie sur « Annuler ».
class _Cancelled implements Exception {}

enum _Fmt { portrait, landscape, square }

enum _Res { sd, hd, fhd }

enum _Q { fast, balanced, best }

enum _Out { mp4, gif }

/// Réglages de vitesse / qualité.
class _QP {
  const _QP(this.label, this.hint, this.png, this.jpg, this.rafs, this.preset,
      this.crf);
  final String label, hint, preset;
  final bool png; // true = captures PNG (lent, sans perte)
  final int jpg; // qualité JPEG
  final int rafs; // images réelles attendues après chaque seek
  final int crf; // x264 : plus petit = meilleure qualité
}

const _qps = <_Q, _QP>{
  _Q.fast: _QP('Rapide', 'Captures JPEG + encodage express (conseillé)', false,
      85, 1, 'ultrafast', 24),
  _Q.balanced:
      _QP('Équilibré', 'JPEG haute qualité, bon compromis', false, 93, 2,
          'veryfast', 21),
  _Q.best: _QP('Qualité', 'PNG sans perte, nettement plus lent', true, 100, 2,
      'medium', 17),
};

/// État affiché dans le bandeau de progression.
class _Prog {
  const _Prog(this.value, this.phase, this.detail, this.thumb);
  final double value; // 0..1
  final String phase, detail;
  final Uint8List? thumb; // dernière image capturée
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final _html = TextEditingController(text: _sample);
  final _w = TextEditingController(text: '720');
  final _h = TextEditingController(text: '1280');
  final _fps = TextEditingController(text: '30');
  final _dur = TextEditingController(text: '4');
  _Fmt _fmt = _Fmt.portrait;
  _Res _res = _Res.hd;
  _Q _q = _Q.fast;
  _Out _out = _Out.mp4;
  bool _autoDur = true; // durée calculée depuis le HTML
  bool _fade = false; // fondu d'entrée / sortie
  double _musicVol = 1;

  InAppWebViewController? _ctl;
  Completer<void>? _loaded;
  HttpServer? _server;
  bool _busy = false;
  bool _exporting = false;
  bool _cancel = false;
  bool _asyncOk = true; // callAsyncJavaScript disponible ?
  String _status = '';
  final _sw = Stopwatch();
  final _prog = ValueNotifier<_Prog>(const _Prog(0, '', '', null));
  final _clock = ValueNotifier<int>(0); // rafraîchit le temps écoulé
  Timer? _tick;

  // Projet zip (HTML + dossiers de sons, images…) servi en local
  String? _projectDir; // dossier extrait
  String? _entryUrl; // http://127.0.0.1:PORT/index.html
  String? _projectName;

  String? _audioPath; // musique ajoutée par l'utilisateur
  String? _audioName;
  String? _lastOut;

  double get _wv => double.tryParse(_w.text) ?? 720;
  double get _hv => double.tryParse(_h.text) ?? 1280;

  @override
  void dispose() {
    _tick?.cancel();
    _server?.close(force: true);
    _prog.dispose();
    _clock.dispose();
    super.dispose();
  }

  // ---------------------------------------------------------------- utilitaires

  void _set(double v, String phase, String detail,
      {Uint8List? thumb, bool clearThumb = false}) {
    _prog.value = _Prog(
        v.clamp(0.0, 1.0).toDouble(),
        phase,
        detail,
        clearThumb ? null : (thumb ?? _prog.value.thumb));
  }

  String _fmtSec(int s) {
    if (s < 60) return '${s}s';
    final m = s ~/ 60;
    return '${m}min ${(s % 60).toString().padLeft(2, '0')}s';
  }

  /// Exécute une action en affichant l'erreur à l'écran au lieu de l'avaler en silence.
  Future<void> _safe(Future<void> Function() f) async {
    try {
      await f();
    } catch (e) {
      if (mounted) {
        setState(() {
          _busy = false;
          _exporting = false;
          _status = 'Erreur : $e';
        });
      }
    }
  }

  /// Ouvre le sélecteur Android. FileType.any + contrôle de l'extension :
  /// le filtre par extension grise parfois les fichiers selon l'explorateur.
  Future<PlatformFile?> _choose(List<String> exts, String label) async {
    final r = await FilePicker.platform.pickFiles(
      type: FileType.any,
      allowMultiple: false,
      withData: false,
    );
    final f = r?.files.single;
    if (f == null || f.path == null) return null; // annulé
    final low = f.name.toLowerCase();
    if (!exts.any((e) => low.endsWith('.$e'))) {
      _snack('Choisis un fichier $label');
      return null;
    }
    return f;
  }

  void _openPreview([String? path]) {
    final p = path ?? _lastOut;
    if (p == null) return;
    Navigator.of(context).push(previewRoute(p));
  }

  void _openLibrary() {
    Navigator.of(context)
        .push(MaterialPageRoute(builder: (_) => const LibraryPage()));
  }

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  /// Applique format (portrait / paysage / carré) + résolution aux champs.
  void _applySize() {
    final s = switch (_res) { _Res.sd => 480, _Res.hd => 720, _Res.fhd => 1080 };
    final long = ((s * 16 / 9) / 2).round() * 2;
    final (w, h) = switch (_fmt) {
      _Fmt.portrait => (s, long),
      _Fmt.landscape => (long, s),
      _Fmt.square => (s, s),
    };
    _w.text = '$w';
    _h.text = '$h';
  }

  // --------------------------------------------------------------- chargement

  /// Charge la source courante (projet ou code collé) et attend qu'elle soit prête.
  Future<void> _load() async {
    _loaded = Completer<void>();
    if (_projectDir != null) {
      await _ctl!.loadUrl(urlRequest: URLRequest(url: WebUri(_entryUrl!)));
    } else {
      await _ctl!.loadData(data: _html.text);
    }
    await _loaded!.future.timeout(const Duration(seconds: 20));
    await Future.delayed(const Duration(milliseconds: 500)); // décodage audio, etc.
  }

  Future<bool> _isAnimated() async {
    final r = await _ctl!.evaluateJavascript(source: 'window.__isAnimated()');
    return r == true || r.toString() == 'true';
  }

  /// Positionne la page à l'instant [ms] puis attend un vrai rendu
  /// (au lieu d'une pause fixe de 40 ms par image).
  Future<void> _seekTo(double ms, int rafs) async {
    if (_asyncOk) {
      try {
        final r = await _ctl!.callAsyncJavaScript(
          functionBody:
              'window.__seek(${ms.toStringAsFixed(3)}); await window.__paint($rafs); return 1;',
        );
        if (r != null && r.error == null) return;
      } catch (_) {}
      _asyncOk = false; // repli sur l'ancienne méthode
    }
    await _ctl!.evaluateJavascript(
        source: 'window.__seek(${ms.toStringAsFixed(3)});');
    await Future.delayed(const Duration(milliseconds: 40));
  }

  /// Essaie une nouvelle source ; la garde seulement si elle est animée.
  Future<bool> _tryOpen(
      {String? dir, String? url, String? name, String? html}) async {
    final prevDir = _projectDir, prevUrl = _entryUrl, prevName = _projectName;
    final prevHtml = _html.text;
    _projectDir = dir;
    _entryUrl = url;
    _projectName = name;
    if (html != null) _html.text = html;
    try {
      await _load();
      if (await _isAnimated()) return true;
    } catch (_) {}
    _projectDir = prevDir;
    _entryUrl = prevUrl;
    _projectName = prevName;
    _html.text = prevHtml;
    try {
      await _load();
    } catch (_) {}
    return false;
  }

  Future<void> _pickHtml() => _safe(_pickHtmlImpl);

  Future<void> _pickHtmlImpl() async {
    final f = await _choose(['html', 'htm'], '.html');
    final path = f?.path;
    if (path == null) return;
    setState(() {
      _busy = true;
      _status = 'Vérification de l\'animation…';
    });
    final ok = await _tryOpen(html: File(path).readAsStringSync());
    setState(() {
      _busy = false;
      _status = ok ? 'HTML animé accepté ✓' : '';
    });
    if (!ok) _snack('Refusé : ce HTML ne contient aucune animation.');
  }

  /// Projet = .zip contenant le HTML et ses dossiers (sons, images, scripts…).
  Future<void> _pickProject() => _safe(_pickProjectImpl);

  Future<void> _pickProjectImpl() async {
    final file = await _choose(['zip'], '.zip');
    if (file?.path == null) return;
    setState(() {
      _busy = true;
      _status = 'Extraction du projet…';
    });
    HttpServer? srv;
    try {
      final tmp = await getTemporaryDirectory();
      final root = Directory('${tmp.path}/project');
      if (root.existsSync()) root.deleteSync(recursive: true);
      root.createSync(recursive: true);

      final htmls = <String>[];
      final arc = ZipDecoder().decodeBytes(File(file!.path!).readAsBytesSync());
      for (final f in arc) {
        if (!f.isFile || f.name.contains('..') || f.name.startsWith('__MACOSX')) {
          continue;
        }
        File('${root.path}/${f.name}')
          ..createSync(recursive: true)
          ..writeAsBytesSync(f.content as List<int>);
        final low = f.name.toLowerCase();
        if (low.endsWith('.html') || low.endsWith('.htm')) htmls.add(f.name);
      }
      if (htmls.isEmpty) throw Exception('aucun fichier .html dans le zip');

      // Entrée = index.html le moins profond, sinon le premier .html
      htmls.sort((a, b) {
        final da = '/'.allMatches(a).length, db = '/'.allMatches(b).length;
        if (da != db) return da.compareTo(db);
        final ia = a.toLowerCase().endsWith('index.html') ? 0 : 1;
        final ib = b.toLowerCase().endsWith('index.html') ? 0 : 1;
        return ia.compareTo(ib);
      });
      final entry = htmls.first;

      srv = await shelf_io.serve(
          createStaticHandler(root.path), InternetAddress.loopbackIPv4, 0);
      final url = 'http://127.0.0.1:${srv.port}/'
          '${entry.split('/').map(Uri.encodeComponent).join('/')}';

      setState(() => _status = 'Vérification de l\'animation…');
      final ok = await _tryOpen(
          dir: root.path, url: url, name: '${file.name} → $entry');
      if (ok) {
        await _server?.close(force: true);
        _server = srv;
        setState(() => _status = 'Projet animé accepté ✓');
      } else {
        await srv.close(force: true);
        setState(() => _status = '');
        _snack('Refusé : ce projet ne contient aucune animation.');
      }
    } catch (e) {
      await srv?.close(force: true);
      setState(() => _status = 'Erreur : $e');
    } finally {
      setState(() => _busy = false);
    }
  }

  Future<void> _closeProject() async {
    setState(() {
      _projectDir = null;
      _entryUrl = null;
      _projectName = null;
    });
    try {
      await _load();
    } catch (_) {}
  }

  Future<void> _pickAudio() => _safe(_pickAudioImpl);

  Future<void> _pickAudioImpl() async {
    final r = await FilePicker.platform
        .pickFiles(type: FileType.any, allowMultiple: false, withData: false);
    final f = r?.files.single;
    if (f == null || f.path == null) return;
    setState(() {
      _audioPath = f.path;
      _audioName = f.name;
    });
  }

  // -------------------------------------------------------------------- audio

  /// URL vue par la page -> chemin du fichier dans le projet extrait.
  String? _localFile(String src) {
    final dir = _projectDir;
    final u = Uri.tryParse(src);
    if (dir == null || u == null || u.host != '127.0.0.1') return null;
    final rel = Uri.decodeComponent(u.path);
    if (rel.contains('..')) return null;
    final f = File('$dir$rel');
    return f.existsSync() ? f.path : null;
  }

  List<_Snd> _parseSounds(String json, double totalSec) {
    final open = <int, _Snd>{};
    final out = <_Snd>[];
    for (final e in jsonDecode(json) as List) {
      final id = (e['id'] as num).toInt();
      final t = (e['t'] as num).toDouble();
      if (e['k'] == 'play') {
        final file = _localFile(e['src'] as String);
        final vol = (e['vol'] as num?)?.toDouble() ?? 1;
        if (file == null || vol <= 0 || t / 1000 >= totalSec) continue;
        final s = _Snd(
          file,
          t,
          (e['off'] as num?)?.toDouble() ?? 0,
          vol.clamp(0.0, 1.0).toDouble(),
          ((e['rate'] as num?)?.toDouble() ?? 1).clamp(0.5, 2.0).toDouble(),
          e['loop'] == true,
          (e['dur'] as num?)?.toDouble(),
        );
        open[id] = s;
        out.add(s);
      } else if (e['k'] == 'stop') {
        final s = open.remove(id);
        if (s != null && s.dur == null && t > s.t) s.dur = (t - s.t) / 1000;
      }
    }
    return out.take(64).toList();
  }

  /// Durée d'un fichier audio (secondes) via FFprobe, null si inconnue.
  Future<double?> _fileDuration(String path) async {
    try {
      final s = await FFprobeKit.getMediaInformation(path);
      final d = s.getMediaInformation()?.getDuration();
      return d == null ? null : double.tryParse(d);
    } catch (_) {
      return null;
    }
  }

  /// Simule la page (temps virtuel) pour savoir combien de secondes elle dure.
  /// Précondition : la page est chargée. Résultat borné entre 1 s et 120 s.
  Future<double> _measureDuration() async {
    const maxSec = 120.0;
    final raw = await _ctl!.evaluateJavascript(
        source: 'window.__measure(${(maxSec * 1000).round()})');
    final m = jsonDecode(raw.toString()) as Map<String, dynamic>;
    var endMs = (m['end'] as num).toDouble();
    final loopMs = (m['loop'] as num).toDouble();

    // Fin des sons joués par la page
    for (final e in (m['audio'] as List)) {
      if (e['k'] != 'play') continue;
      final file = _localFile(e['src'] as String);
      if (file == null || e['loop'] == true) continue;
      final fd = await _fileDuration(file);
      if (fd == null) continue;
      final rate = ((e['rate'] as num?)?.toDouble() ?? 1).clamp(0.5, 2.0);
      final off = (e['off'] as num?)?.toDouble() ?? 0;
      final len = e['dur'] != null ? (e['dur'] as num).toDouble() : fd - off;
      endMs = [endMs, (e['t'] as num).toDouble() + len / rate * 1000]
          .reduce((a, b) => a > b ? a : b);
    }

    double sec;
    if (endMs > 0) {
      sec = endMs / 1000; // il y a une fin réelle
    } else if (loopMs > 0) {
      sec = loopMs / 1000; // animation en boucle : un cycle complet
    } else {
      sec = 10; // boucle infinie non mesurable : valeur par défaut
    }
    return ((sec.clamp(1.0, maxSec) * 10).ceil()) / 10;
  }

  Future<void> _detectDuration() => _safe(() async {
        setState(() {
          _busy = true;
          _status = 'Calcul de la durée…';
        });
        await _load();
        final d = await _measureDuration();
        await _load(); // repart d'un état propre
        setState(() {
          _dur.text = d.toString();
          _busy = false;
          _status = 'Durée détectée : ${d}s';
        });
      });

  // ------------------------------------------------------------------- export

  void _cancelExport() {
    _cancel = true;
    _set(_prog.value.value, 'Annulation…', 'Arrêt en cours');
    FFmpegKit.cancel();
  }

  Future<void> _export() async {
    final fps = (int.tryParse(_fps.text) ?? 30).clamp(1, 60).toInt();
    var dur = double.tryParse(_dur.text) ?? 4;
    final q = _qps[_q]!;
    final gif = _out == _Out.gif;

    _cancel = false;
    _sw
      ..reset()
      ..start();
    _tick?.cancel();
    // rafraîchit le temps écoulé même quand aucune nouvelle image n'arrive
    _tick = Timer.periodic(const Duration(seconds: 1), (_) => _clock.value++);

    setState(() {
      _busy = true;
      _exporting = true;
      _lastOut = null;
      _status = '';
    });
    _set(0, 'Préparation', 'Chargement de la page…', clearThumb: true);
    try {
      await WakelockPlus.enable(); // écran allumé pendant la conversion
    } catch (_) {}

    final tmp = await getTemporaryDirectory();
    final dir = Directory('${tmp.path}/frames');
    try {
      if (dir.existsSync()) dir.deleteSync(recursive: true);
      dir.createSync(recursive: true);

      await _load();
      if (!await _isAnimated()) {
        throw Exception('ce HTML n\'est pas animé, export refusé');
      }
      if (_autoDur) {
        _set(0.01, 'Préparation', 'Calcul de la durée…');
        dur = await _measureDuration();
        _dur.text = dur.toString();
        await _load(); // état propre avant la capture
      }
      final total = (dur * fps).round().clamp(1, 100000).toInt();
      if (_cancel) throw _Cancelled();

      // 1) Capture image par image (les sons sont enregistrés par le shim)
      final ext = q.png ? 'png' : 'jpg';
      final shot = ScreenshotConfiguration(
        compressFormat: q.png ? CompressFormat.PNG : CompressFormat.JPEG,
        quality: q.jpg,
        snapshotWidth: _wv,
      );
      final pending = <Future<void>>[];
      final capSw = Stopwatch()..start();
      for (var i = 0; i < total; i++) {
        if (_cancel) throw _Cancelled();
        await _seekTo(i * 1000 / fps, q.rafs);
        final img = await _ctl!.takeScreenshot(screenshotConfiguration: shot);
        if (img == null) throw Exception('capture impossible (image $i)');
        // écriture en arrière-plan : on ne bloque pas la capture suivante
        pending.add(File('${dir.path}/frame_${i.toString().padLeft(5, '0')}.$ext')
            .writeAsBytes(img));
        if (pending.length >= 8) {
          await Future.wait(pending);
          pending.clear();
        }
        final done = i + 1;
        final perMs = capSw.elapsedMilliseconds / done;
        final eta = ((total - done) * perMs / 1000).round();
        _set(
          0.03 + done / total * 0.72,
          'Capture des images',
          '$done / $total · ${(1000 / (perMs > 0 ? perMs : 1)).toStringAsFixed(1)} img/s'
              ' · reste ~${_fmtSec(eta)}',
          thumb: done % 4 == 1 ? img : null,
        );
      }
      await Future.wait(pending);
      if (_cancel) throw _Cancelled();

      // 2) Récupère les sons joués par la page
      final raw = (await _ctl!.evaluateJavascript(
                  source: 'JSON.stringify(window.__audioEvents||[])'))
              ?.toString() ??
          '[]';
      final sounds = gif ? <_Snd>[] : _parseSounds(raw, dur);

      // 3) Construit la commande FFmpeg
      final docs = await getApplicationDocumentsDirectory();
      final exp = Directory('${docs.path}/exports')..createSync(recursive: true);
      final now = DateTime.now();
      String p2(int v) => v.toString().padLeft(2, '0');
      final stamp = '${now.year}${p2(now.month)}${p2(now.day)}_'
          '${p2(now.hour)}${p2(now.minute)}${p2(now.second)}';
      final out = '${exp.path}/html2mp4_$stamp.${gif ? 'gif' : 'mp4'}';

      final args = <String>[
        '-y', '-framerate', '$fps', '-i', '${dir.path}/frame_%05d.$ext',
      ];

      if (gif) {
        final gfps = fps > 20 ? 20 : fps;
        final gw = (_wv > 540 ? 540 : _wv).round();
        args.addAll([
          '-filter_complex',
          '[0:v]fps=$gfps,scale=$gw:-1:flags=lanczos,split[a][b];'
              '[a]palettegen=stats_mode=diff[p];'
              '[b][p]paletteuse=dither=bayer:bayer_scale=5[v]',
          '-map', '[v]', '-loop', '0', out,
        ]);
      } else {
        final fadeV = (_fade && dur > 1.5)
            ? ',fade=t=in:st=0:d=0.4,fade=t=out:st=${_n(dur - 0.4)}:d=0.4'
            : '';
        final chains = <String>[
          '[0:v]scale=trunc(iw/2)*2:trunc(ih/2)*2,format=yuv420p$fadeV[v]'
        ];
        final mix = <String>[];
        var idx = 1;
        const fmt = 'aformat=sample_rates=44100:channel_layouts=stereo';

        if (_audioPath != null) {
          args.addAll(['-stream_loop', '-1', '-i', _audioPath!]);
          final fade = dur > 2 ? ',afade=t=out:st=${_n(dur - 1)}:d=1' : '';
          final mv = (sounds.isEmpty ? 1.0 : 0.6) * _musicVol;
          chains.add('[$idx:a]$fmt,atrim=duration=${_n(dur)},'
              'asetpts=PTS-STARTPTS,volume=${_n(mv)}$fade[m]');
          mix.add('[m]');
          idx++;
        }

        for (var j = 0; j < sounds.length; j++) {
          final s = sounds[j];
          if (s.loop) args.addAll(['-stream_loop', '-1']);
          args.addAll(['-i', s.file]);
          final remain = dur - s.t / 1000;
          final sd = s.dur;
          final d = (sd != null && sd < remain) ? sd : remain;
          chains.add('[$idx:a]$fmt'
              '${s.off > 0 ? ',atrim=start=${_n(s.off)}' : ''}'
              ',asetpts=PTS-STARTPTS'
              '${s.rate != 1 ? ',atempo=${_n(s.rate)}' : ''}'
              ',atrim=duration=${_n(d)},volume=${_n(s.vol)}'
              ',adelay=${s.t.round()}:all=1[s$j]');
          mix.add('[s$j]');
          idx++;
        }

        if (mix.isNotEmpty) {
          chains.add('${mix.join()}amix=inputs=${mix.length}:duration=longest'
              ':normalize=0,alimiter=limit=0.95,atrim=duration=${_n(dur)}[aout]');
        }

        args.addAll(['-filter_complex', chains.join(';'), '-map', '[v]']);
        if (mix.isNotEmpty) {
          args.addAll(['-map', '[aout]', '-c:a', 'aac', '-b:a', '192k']);
        }
        args.addAll([
          '-c:v', 'libx264', '-preset', q.preset, '-crf', '${q.crf}',
          '-threads', '0', '-pix_fmt', 'yuv420p',
          '-t', _n(dur), '-movflags', '+faststart', out,
        ]);
      }

      // 4) Encodage avec progression réelle
      _set(0.75, 'Encodage ${gif ? 'GIF' : 'MP4'}',
          '0 %${sounds.isEmpty ? '' : ' · ${sounds.length} son(s) mixé(s)'}');
      final finished = Completer<FFmpegSession>();
      final encSw = Stopwatch()..start();
      await FFmpegKit.executeWithArgumentsAsync(
        args,
        (session) {
          if (!finished.isCompleted) finished.complete(session);
        },
        null,
        (st) {
          final ms = (st.getTime() as num).toDouble();
          final r = (ms / (dur * 1000)).clamp(0.0, 1.0).toDouble();
          final eta = r > 0.03
              ? (encSw.elapsedMilliseconds / r * (1 - r) / 1000).round()
              : null;
          _set(
            0.75 + r * 0.22,
            'Encodage ${gif ? 'GIF' : 'MP4'}',
            '${(r * 100).round()} %'
                '${eta == null ? '' : ' · reste ~${_fmtSec(eta)}'}',
          );
        },
      );
      final session = await finished.future;
      final rc = await session.getReturnCode();
      if (ReturnCode.isCancel(rc) || _cancel) throw _Cancelled();
      if (!ReturnCode.isSuccess(rc)) {
        final logs = await session.getAllLogsAsString() ?? '';
        final tail = logs.length > 300 ? logs.substring(logs.length - 300) : logs;
        throw Exception('FFmpeg a échoué\n$tail');
      }

      // 5) Enregistrement direct dans la galerie
      _set(0.98, 'Enregistrement', 'Ajout à la galerie…');
      String? galleryNote;
      try {
        if (!await Gal.hasAccess(toAlbum: true)) {
          await Gal.requestAccess(toAlbum: true);
        }
        if (gif) {
          await Gal.putImage(out, album: 'HTML2MP4');
        } else {
          await Gal.putVideo(out, album: 'HTML2MP4');
        }
      } catch (e) {
        galleryNote = 'Galerie indisponible ($e), utilise Partager.';
      }

      _set(1, 'Terminé', 'en ${_fmtSec(_sw.elapsed.inSeconds)}');
      HapticFeedback.mediumImpact();
      if (mounted) {
        setState(() {
          _lastOut = out;
          _status = galleryNote ??
              '${gif ? 'GIF' : 'Vidéo'} terminé en ${_fmtSec(_sw.elapsed.inSeconds)} ✓'
                  '${sounds.isEmpty ? '' : ' (${sounds.length} son(s) mixé(s))'}';
        });
        _openPreview(); // ouvre le lecteur d'aperçu
      }
    } on _Cancelled {
      if (mounted) setState(() => _status = 'Conversion annulée.');
    } catch (e) {
      if (mounted) setState(() => _status = 'Erreur : $e');
    } finally {
      _tick?.cancel();
      _sw.stop();
      try {
        if (dir.existsSync()) dir.deleteSync(recursive: true);
      } catch (_) {}
      try {
        await WakelockPlus.disable();
      } catch (_) {}
      if (mounted) {
        setState(() {
          _busy = false;
          _exporting = false;
        });
      }
    }
  }

  // ----------------------------------------------------------------------- UI

  Widget _num(String label, TextEditingController c) => Expanded(
        child: Padding(
          padding: const EdgeInsets.only(right: 8),
          child: TextField(
            controller: c,
            enabled: !_busy,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(labelText: label, isDense: true),
            onChanged: (_) => setState(() {}),
          ),
        ),
      );

  Widget _title(String t) => Padding(
        padding: const EdgeInsets.only(top: 16, bottom: 6),
        child: Text(t, style: Theme.of(context).textTheme.titleSmall),
      );

  /// Bandeau fixe en bas : bouton Convertir, ou progression détaillée.
  /// SafeArea = ne passe plus sous les boutons / la barre de gestes du téléphone.
  Widget _dock() {
    final cs = Theme.of(context).colorScheme;
    return Material(
      elevation: 10,
      color: cs.surfaceContainer,
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
          child: _exporting
              ? _progressCard()
              : _busy
                  ? Column(mainAxisSize: MainAxisSize.min, children: [
                      const LinearProgressIndicator(),
                      const SizedBox(height: 8),
                      Text(_status.isEmpty ? 'Patiente…' : _status),
                    ])
                  : _idleBar(),
        ),
      ),
    );
  }

  Widget _idleBar() {
    return Column(mainAxisSize: MainAxisSize.min, children: [
      if (_status.isNotEmpty)
        Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: Text(_status,
              maxLines: 3, overflow: TextOverflow.ellipsis),
        ),
      SizedBox(
        width: double.infinity,
        child: FilledButton.icon(
          onPressed: _export,
          icon: const Icon(Icons.movie),
          label: Text(_out == _Out.gif
              ? 'Convertir en GIF'
              : 'Convertir et enregistrer'),
        ),
      ),
      if (_lastOut != null)
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          TextButton.icon(
            onPressed: _openPreview,
            icon: const Icon(Icons.play_circle),
            label: const Text('Aperçu'),
          ),
          TextButton.icon(
            onPressed: () => Share.shareXFiles([XFile(_lastOut!)]),
            icon: const Icon(Icons.share),
            label: const Text('Partager'),
          ),
        ]),
    ]);
  }

  Widget _progressCard() {
    return ListenableBuilder(
      listenable: Listenable.merge([_prog, _clock]),
      builder: (context, _) {
        final p = _prog.value;
        final pct = (p.value * 100).floor();
        return Column(mainAxisSize: MainAxisSize.min, children: [
          Row(children: [
            if (p.thumb != null)
              Padding(
                padding: const EdgeInsets.only(right: 12),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: SizedBox(
                    width: 56,
                    height: 56,
                    child: Image.memory(p.thumb!,
                        fit: BoxFit.cover, gaplessPlayback: true),
                  ),
                ),
              ),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(p.phase,
                      style: Theme.of(context).textTheme.titleSmall),
                  Text(p.detail,
                      style: Theme.of(context).textTheme.bodySmall,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis),
                  Text('écoulé ${_fmtSec(_sw.elapsed.inSeconds)}',
                      style: Theme.of(context).textTheme.bodySmall),
                ],
              ),
            ),
            Text('$pct %',
                style: Theme.of(context)
                    .textTheme
                    .headlineMedium
                    ?.copyWith(fontWeight: FontWeight.w700)),
          ]),
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(value: p.value, minHeight: 10),
          ),
          const SizedBox(height: 4),
          Align(
            alignment: Alignment.centerRight,
            child: TextButton.icon(
              onPressed: _cancel ? null : _cancelExport,
              icon: const Icon(Icons.stop_circle_outlined),
              label: const Text('Annuler'),
            ),
          ),
        ]);
      },
    );
  }

  String _fmtLabel(_Fmt f) => switch (f) {
        _Fmt.portrait => 'Portrait 9:16',
        _Fmt.landscape => 'Paysage 16:9',
        _Fmt.square => 'Carré 1:1',
      };

  String _resLabel(_Res r) => switch (r) {
        _Res.sd => 'SD 480p',
        _Res.hd => 'HD 720p',
        _Res.fhd => 'Full HD 1080p',
      };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('HTML animé → MP4'),
        actions: [
          IconButton(
            tooltip: 'Mes vidéos',
            icon: const Icon(Icons.video_library),
            onPressed: _busy ? null : _openLibrary,
          ),
        ],
      ),
      bottomNavigationBar: _dock(),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            height: 240,
            color: Colors.black12,
            child: FittedBox(
              child: SizedBox(
                width: _wv,
                height: _hv,
                child: InAppWebView(
                  initialData: InAppWebViewInitialData(data: _html.text),
                  initialUserScripts: UnmodifiableListView([
                    UserScript(
                      source: _shim,
                      injectionTime: UserScriptInjectionTime.AT_DOCUMENT_START,
                    ),
                  ]),
                  onWebViewCreated: (c) => _ctl = c,
                  onLoadStop: (c, u) {
                    if (_loaded != null && !_loaded!.isCompleted) {
                      _loaded!.complete();
                    }
                  },
                ),
              ),
            ),
          ),
          _title('Format'),
          Wrap(spacing: 8, runSpacing: 4, children: [
            for (final f in _Fmt.values)
              ChoiceChip(
                label: Text(_fmtLabel(f)),
                selected: _fmt == f,
                onSelected: _busy
                    ? null
                    : (_) => setState(() {
                          _fmt = f;
                          _applySize();
                        }),
              ),
          ]),
          const SizedBox(height: 4),
          Wrap(spacing: 8, runSpacing: 4, children: [
            for (final r in _Res.values)
              ChoiceChip(
                label: Text(_resLabel(r)),
                selected: _res == r,
                onSelected: _busy
                    ? null
                    : (_) => setState(() {
                          _res = r;
                          _applySize();
                        }),
              ),
          ]),
          const SizedBox(height: 12),
          Row(children: [
            _num('Largeur', _w),
            _num('Hauteur', _h),
            _num('FPS', _fps),
          ]),
          _title('Sortie'),
          Wrap(spacing: 8, runSpacing: 4, children: [
            ChoiceChip(
              label: const Text('Vidéo MP4'),
              selected: _out == _Out.mp4,
              onSelected: _busy ? null : (_) => setState(() => _out = _Out.mp4),
            ),
            ChoiceChip(
              label: const Text('GIF animé'),
              selected: _out == _Out.gif,
              onSelected: _busy ? null : (_) => setState(() => _out = _Out.gif),
            ),
          ]),
          _title('Vitesse de conversion'),
          Wrap(spacing: 8, runSpacing: 4, children: [
            for (final e in _qps.entries)
              ChoiceChip(
                label: Text(e.value.label),
                selected: _q == e.key,
                onSelected: _busy ? null : (_) => setState(() => _q = e.key),
              ),
          ]),
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Text(_qps[_q]!.hint,
                style: Theme.of(context).textTheme.bodySmall),
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Durée automatique'),
            subtitle:
                const Text('Calculée d\'après les animations et les sons du HTML'),
            value: _autoDur,
            onChanged: _busy ? null : (v) => setState(() => _autoDur = v),
          ),
          Row(children: [
            Expanded(
              child: TextField(
                controller: _dur,
                enabled: !_busy && !_autoDur,
                keyboardType: TextInputType.number,
                decoration:
                    const InputDecoration(labelText: 'Durée (s)', isDense: true),
              ),
            ),
            const SizedBox(width: 8),
            OutlinedButton.icon(
              onPressed: _busy ? null : _detectDuration,
              icon: const Icon(Icons.timer),
              label: const Text('Détecter'),
            ),
          ]),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Fondu d\'entrée et de sortie'),
            subtitle: const Text('Vidéo MP4 uniquement (0,4 s)'),
            value: _fade && _out == _Out.mp4,
            onChanged: (_busy || _out == _Out.gif)
                ? null
                : (v) => setState(() => _fade = v),
          ),
          const SizedBox(height: 4),
          if (_projectName != null)
            Align(
              alignment: Alignment.centerLeft,
              child: InputChip(
                avatar: const Icon(Icons.folder_zip, size: 18),
                label: Text('Projet : $_projectName'),
                onDeleted: _busy ? null : _closeProject,
              ),
            )
          else
            TextField(
              controller: _html,
              enabled: !_busy,
              maxLines: 6,
              decoration: const InputDecoration(
                labelText: 'Code HTML (animé uniquement)',
                border: OutlineInputBorder(),
              ),
            ),
          const SizedBox(height: 8),
          Wrap(spacing: 8, runSpacing: 8, children: [
            OutlinedButton.icon(
              onPressed: _busy ? null : _pickHtml,
              icon: const Icon(Icons.html),
              label: const Text('Ouvrir un .html'),
            ),
            OutlinedButton.icon(
              onPressed: _busy ? null : _pickProject,
              icon: const Icon(Icons.folder_zip),
              label: const Text('Projet .zip (HTML + sons)'),
            ),
          ]),
          const Padding(
            padding: EdgeInsets.only(top: 4),
            child: Text(
              'Zippez le HTML avec son dossier de sons : les sons que la page '
              'joue sont détectés et mixés automatiquement.',
              style: TextStyle(fontSize: 12),
            ),
          ),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _busy ? null : _pickAudio,
                icon: const Icon(Icons.music_note),
                label: Text(
                  _audioName ?? 'Ajouter une musique de fond',
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ),
            if (_audioPath != null)
              IconButton(
                onPressed: _busy
                    ? null
                    : () => setState(() {
                          _audioPath = null;
                          _audioName = null;
                        }),
                icon: const Icon(Icons.close),
                tooltip: 'Retirer la musique',
              ),
          ]),
          if (_audioPath != null && _out == _Out.mp4)
            Row(children: [
              const Icon(Icons.volume_up, size: 20),
              Expanded(
                child: Slider(
                  value: _musicVol,
                  min: 0,
                  max: 1,
                  divisions: 20,
                  label: '${(_musicVol * 100).round()} %',
                  onChanged: _busy ? null : (v) => setState(() => _musicVol = v),
                ),
              ),
              SizedBox(
                width: 44,
                child: Text('${(_musicVol * 100).round()} %'),
              ),
            ]),
          const SizedBox(height: 16),
        ],
        ),
      ),
    );
  }
}
