import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import 'preview_page.dart';

/// « Mes vidéos » : tous les exports (MP4 / GIF) conservés dans l'appli.
class LibraryPage extends StatefulWidget {
  const LibraryPage({super.key});
  @override
  State<LibraryPage> createState() => _LibraryPageState();
}

class _LibraryPageState extends State<LibraryPage> {
  List<File>? _files;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  Future<void> _reload() async {
    final docs = await getApplicationDocumentsDirectory();
    final dir = Directory('${docs.path}/exports');
    final list = dir.existsSync()
        ? dir
            .listSync()
            .whereType<File>()
            .where((f) {
              final p = f.path.toLowerCase();
              return p.endsWith('.mp4') || p.endsWith('.gif');
            })
            .toList()
        : <File>[];
    list.sort((a, b) => b.lastModifiedSync().compareTo(a.lastModifiedSync()));
    if (mounted) setState(() => _files = list);
  }

  String _name(File f) => f.path.split('/').last;

  String _size(int b) {
    if (b < 1024 * 1024) return '${(b / 1024).round()} Ko';
    return '${(b / 1024 / 1024).toStringAsFixed(1)} Mo';
  }

  String _date(DateTime d) {
    String p(int v) => v.toString().padLeft(2, '0');
    return '${p(d.day)}/${p(d.month)}/${d.year} ${p(d.hour)}:${p(d.minute)}';
  }

  Future<void> _delete(File f) async {
    try {
      await f.delete();
    } catch (_) {}
    _reload();
  }

  Future<void> _deleteAll() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Tout supprimer ?'),
        content: const Text(
            'Les fichiers déjà enregistrés dans la galerie ne sont pas touchés.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(c, false),
              child: const Text('Annuler')),
          FilledButton(
              onPressed: () => Navigator.pop(c, true),
              child: const Text('Supprimer')),
        ],
      ),
    );
    if (ok != true) return;
    for (final f in _files ?? <File>[]) {
      try {
        await f.delete();
      } catch (_) {}
    }
    _reload();
  }

  @override
  Widget build(BuildContext context) {
    final files = _files;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Mes vidéos'),
        actions: [
          if (files != null && files.isNotEmpty)
            IconButton(
              tooltip: 'Tout supprimer',
              icon: const Icon(Icons.delete_sweep),
              onPressed: _deleteAll,
            ),
        ],
      ),
      body: SafeArea(
        child: files == null
            ? const Center(child: CircularProgressIndicator())
            : files.isEmpty
                ? const Center(
                    child: Padding(
                      padding: EdgeInsets.all(24),
                      child: Text(
                          'Aucun export pour l\'instant. Convertis une animation, elle apparaîtra ici.',
                          textAlign: TextAlign.center),
                    ),
                  )
                : ListView.separated(
                    itemCount: files.length,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (_, i) {
                      final f = files[i];
                      final gif = f.path.toLowerCase().endsWith('.gif');
                      return ListTile(
                        leading: Icon(gif ? Icons.gif_box : Icons.movie),
                        title: Text(_name(f), overflow: TextOverflow.ellipsis),
                        subtitle: Text(
                            '${_size(f.lengthSync())} · ${_date(f.lastModifiedSync())}'),
                        onTap: () => Navigator.of(context)
                            .push(previewRoute(f.path)),
                        trailing: PopupMenuButton<String>(
                          onSelected: (v) {
                            if (v == 'share') {
                              Share.shareXFiles([XFile(f.path)]);
                            } else {
                              _delete(f);
                            }
                          },
                          itemBuilder: (_) => const [
                            PopupMenuItem(value: 'share', child: Text('Partager')),
                            PopupMenuItem(
                                value: 'del', child: Text('Supprimer')),
                          ],
                        ),
                      );
                    },
                  ),
      ),
    );
  }
}
