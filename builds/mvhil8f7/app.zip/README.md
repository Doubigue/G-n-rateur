# HTML → MP4

1. `flutter create .` (génère android/ et ios/ si absents), puis `flutter pub get`
2. Android : minSdkVersion 24 ; dans AndroidManifest.xml, balise <application> : android:usesCleartextTraffic="true"
   (Android 9 ou moins : permission WRITE_EXTERNAL_STORAGE avec android:maxSdkVersion="28")
3. iOS (14+) : dans Info.plist ajouter
   - NSPhotoLibraryAddUsageDescription et NSPhotoLibraryUsageDescription
   - NSAppTransportSecurity > NSAllowsLocalNetworking = true
4. `flutter run`

Projet .zip : un index.html + ses dossiers (sons, images…). Exemple : spot_html2mp4.zip (720x1280, 30 FPS, 12 s).

Note : flutter_inappwebview 6.2.0-beta.3 est requis (la 6.1.5 échoue avec AGP 9 :
"getDefaultProguardFile('proguard-android.txt') is no longer supported").

## Correctifs (octobre 2026)
- Boutons d'upload : sélecteur FileType.any + contrôle d'extension, erreurs affichées à l'écran.
- Conversion : captures à la largeur demandée (snapshotWidth), erreur galerie non bloquante.
- Android release : compiler avec `flutter build apk --release --no-shrink` (R8 casse FFmpegKit :
  l'appli se ferme au premier appel FFmpeg). Règles dans android/app/proguard-rules.pro (voir ci-dessous).

android/app/proguard-rules.pro :
    -keep class com.antonkarpenko.** { *; }
    -keep class com.arthenica.** { *; }
    -dontwarn com.antonkarpenko.**
    -dontwarn com.arthenica.**

## Aperçu
Après l'export, l'écran « Aperçu de la vidéo » s'ouvre automatiquement (package video_player) :
lecture/pause, barre de progression, ±1 s, boucle, vitesse (×0,25 à ×2), partage.
Le bouton « Aperçu » reste disponible sous la barre de progression.

## Orientation et durée automatique (octobre 2026)
- Choix Portrait (720x1280) ou Paysage YouTube (1280x720) ; Largeur/Hauteur restent modifiables.
- Durée automatique (activée par défaut) : la page est simulée en temps virtuel (sans capture) et
  la durée est déduite des animations CSS/SVG finies, des timers, des boucles rAF qui s'arrêtent et de
  la longueur des sons joués. Animation uniquement en boucle : un cycle complet. Boucle infinie
  non mesurable : 10 s. Résultat borné de 1 à 120 s. Bouton « Détecter » pour la voir avant l'export ;
  désactive l'interrupteur pour saisir une durée à la main.
- Version web : voir web/html2mp4.html (ouvrir dans Chrome / Edge).

## Version 1.1 (octobre 2026) — progression, vitesse, écran, nouveautés

### Corrections
- **Progression toujours visible** : un bandeau fixe en bas affiche le pourcentage, la phase
  (préparation, capture, encodage, galerie), la vitesse en images/s, le temps restant estimé,
  le temps écoulé et une miniature de la dernière image capturée. Bouton Annuler.
  L'encodage FFmpeg remonte aussi sa progression réelle (avant, la barre restait figée).
- **Écran qui débordait sous les boutons du téléphone** : le contenu et le bandeau sont maintenant
  dans une SafeArea (barre de navigation / gestes Android pris en compte, mode plein écran inclus).
- **Conversion beaucoup plus rapide** :
  - captures en JPEG (au lieu de PNG) : 5 à 10 fois plus légères à encoder et à écrire ;
  - plus de pause fixe de 40 ms par image : on attend un vrai rendu de la WebView
    (window.__paint) ; repli automatique sur l'ancienne méthode si indisponible ;
  - écriture des images en arrière-plan pendant la capture suivante ;
  - x264 en preset ultrafast / veryfast (au lieu de medium) et tous les cœurs ;
  - la progression ne reconstruit plus tout l'écran à chaque image.
- La WebView reste vivante même si on fait défiler l'écran pendant l'export.

### Nouvelles fonctionnalités
- **Vitesse de conversion** : Rapide (défaut), Équilibré, Qualité (PNG sans perte).
- **Formats** : Portrait 9:16, Paysage 16:9, Carré 1:1, avec SD 480p / HD 720p / Full HD 1080p.
  Largeur / Hauteur restent modifiables à la main.
- **Sortie GIF animé** (palette optimisée, 540 px max, 20 img/s max) en plus du MP4.
- **Mes vidéos** (icône en haut à droite) : tous les exports sont conservés dans l'appli,
  avec aperçu, partage et suppression.
- **Écran maintenu allumé** pendant la conversion (wakelock_plus).
- **Volume de la musique de fond** réglable, fondu d'entrée / sortie optionnel de la vidéo.
- Vibration à la fin, thème sombre automatique.

Après mise à jour : `flutter pub get` (nouvelle dépendance wakelock_plus).

### Version web
web/html2mp4.html a reçu les mêmes améliorations (bandeau de progression fixe avec zone sûre,
annulation, vitesse Express / Rapide / Qualité, formats, carré, fondu, volume musique,
historique de la session, écran maintenu allumé, pourcentage dans le titre de l'onglet).
