package com.klotin.editor.workspace

import android.content.Context
import java.io.File
import java.io.InputStream

enum class Category(val dir: String, val exts: Set<String>) {
    TEXT_CODE("text_code", setOf("txt","html","htm","css","scss","less","js","mjs","ts","py","java","kt","c","cpp","h","cs","php","rb","go","rs","swift","sql","sh","bat","lua","r","scala","pl")),
    MARKUP_DATA("markup_data", setOf("md","xml","json","yaml","yml","toml","ini","cfg","conf","properties","csv","tsv","env","log","tex","svg")),
    ARCHIVES("archives", setOf("zip","rar","7z","tar","gz","bz2","xz","iso","apk","deb","rpm")),
    MEDIA_DOCS("media_docs", setOf("png","jpg","jpeg","gif","webp","bmp","ico","mp3","wav","ogg","m4a","flac","aac","opus","mp4","mkv","webm","avi","mov","3gp","pdf","docx","xlsx","pptx")),
    // Catch-all: anything unknown, no extension, binaries... nothing is ever rejected.
    BINARIES_OTHERS("binaries_others", emptySet());

    val isText get() = this == TEXT_CODE || this == MARKUP_DATA
}

class WorkspaceManager(context: Context) {
    val root = File(context.getExternalFilesDir(null) ?: context.filesDir, "KlotinWorkspace")
    private val history = File(root, ".history")

    init {
        Category.values().forEach { File(root, it.dir).mkdirs() }
        history.mkdirs()
    }

    fun categoryOf(name: String): Category {
        val ext = name.substringAfterLast('.', "").lowercase()
        return Category.values().firstOrNull { ext in it.exts } ?: Category.BINARIES_OTHERS
    }

    fun categoryOf(file: File) = categoryOf(file.name)

    /** Copies a stream into the right sub-folder; returns the destination file. */
    fun import(name: String, input: InputStream): File {
        val dest = uniqueFile(File(root, categoryOf(name).dir), File(name).name)
        input.use { i -> dest.outputStream().use { i.copyTo(it) } }
        return dest
    }

    fun create(name: String): File {
        val dest = uniqueFile(File(root, categoryOf(name).dir), File(name).name)
        dest.createNewFile()
        return dest
    }

    fun files(): List<File> =
        root.walkTopDown()
            .filter { it.isFile && !it.path.startsWith(history.path) }
            .sortedBy { it.path.lowercase() }
            .toList()

    fun delete(file: File) { file.delete() }

    /** Git-lite: previous version is snapshotted before each save. */
    fun save(file: File, text: String, charsetName: String) {
        if (file.exists() && file.length() > 0) {
            val dir = File(history, file.name).apply { mkdirs() }
            file.copyTo(File(dir, System.currentTimeMillis().toString()), overwrite = true)
        }
        file.writeText(text, charset(charsetName))
    }

    fun versions(file: File): List<File> =
        File(history, file.name).listFiles()?.sortedByDescending { it.name } ?: emptyList()

    private fun uniqueFile(dir: File, name: String): File {
        var f = File(dir, name)
        var n = 1
        val base = name.substringBeforeLast('.')
        val ext = name.substringAfterLast('.', "").let { if (it.isEmpty()) "" else ".$it" }
        while (f.exists()) f = File(dir, "${base}_${n++}$ext")
        return f
    }
}
