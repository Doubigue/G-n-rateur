package com.klotin.editor.ui

import android.annotation.SuppressLint
import android.graphics.BitmapFactory
import android.net.Uri
import android.net.http.SslError
import android.webkit.SslErrorHandler
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.klotin.editor.workspace.WorkspaceManager
import java.io.File

private val mono = FontFamily.Monospace

// ---------------- Editor ----------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(file: File, wm: WorkspaceManager, onBack: () -> Unit, onPreview: () -> Unit, onRun: () -> Unit) {
    val encodings = listOf("UTF-8", "UTF-16", "ISO-8859-1", "windows-1252", "US-ASCII", "Shift_JIS", "EUC-KR")
    var enc by remember(file) { mutableStateOf("UTF-8") }
    var tf by remember(file, enc) { mutableStateOf(TextFieldValue(file.readText(charset(enc)))) }
    val undo = remember(file) { ArrayDeque<String>() }
    val redo = remember(file) { ArrayDeque<String>() }
    var dirty by remember(file) { mutableStateOf(false) }
    var showFind by remember { mutableStateOf(false) }
    var find by remember { mutableStateOf("") }
    var repl by remember { mutableStateOf("") }
    var encMenu by remember { mutableStateOf(false) }
    val ext = file.extension.lowercase()
    val isHtml = ext in setOf("html", "htm")
    val isPy = ext == "py"

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(file.name + if (dirty) " •" else "", maxLines = 1) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Retour") } },
            actions = {
                IconButton(onClick = { undo.removeLastOrNull()?.let { redo.addLast(tf.text); tf = TextFieldValue(it) } }) { Text("↶") }
                IconButton(onClick = { redo.removeLastOrNull()?.let { undo.addLast(tf.text); tf = TextFieldValue(it) } }) { Text("↷") }
                IconButton(onClick = { showFind = !showFind }) { Icon(Icons.Default.Search, "Chercher") }
                Box {
                    TextButton(onClick = { encMenu = true }) { Text(enc, fontSize = 11.sp) }
                    DropdownMenu(encMenu, { encMenu = false }) {
                        encodings.forEach { e -> DropdownMenuItem({ Text(e) }, { enc = e; encMenu = false }) }
                    }
                }
                if (isHtml || isPy) IconButton(onClick = {
                    wm.save(file, tf.text, enc); dirty = false
                    if (isPy) onRun() else onPreview()
                }) { Icon(Icons.Default.PlayArrow, if (isPy) "Exécuter" else "Aperçu") }
                IconButton(onClick = { wm.save(file, tf.text, enc); dirty = false }) { Icon(Icons.Default.Check, "Enregistrer") }
            }
        )
        if (showFind) Row(Modifier.padding(8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(find, { find = it }, Modifier.weight(1f), singleLine = true, label = { Text("Chercher") })
            OutlinedTextField(repl, { repl = it }, Modifier.weight(1f), singleLine = true, label = { Text("Remplacer") })
            Button(onClick = {
                if (find.isNotEmpty()) {
                    undo.addLast(tf.text)
                    tf = TextFieldValue(tf.text.replace(find, repl)); dirty = true
                }
            }) { Text("Tout") }
        }
        val lines = tf.text.count { it == '\n' } + 1
        Row(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 6.dp)) {
            Text(
                (1..lines).joinToString("\n"),
                style = TextStyle(fontFamily = mono, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary.copy(alpha = .6f)),
                modifier = Modifier.padding(end = 8.dp)
            )
            BasicTextField(
                value = tf,
                onValueChange = {
                    if (it.text != tf.text) {
                        undo.addLast(tf.text); if (undo.size > 200) undo.removeFirst()
                        redo.clear(); dirty = true
                    }
                    tf = it
                },
                textStyle = TextStyle(fontFamily = mono, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface),
                cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                visualTransformation = remember(ext) { SyntaxTransformation(ext) },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

// ---------------- Hex viewer ----------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HexScreen(file: File, onBack: () -> Unit) {
    val dump = remember(file) {
        val max = 256 * 1024
        val bytes = file.inputStream().use { it.readNBytes(max) }
        buildString {
            bytes.toList().chunked(16).forEachIndexed { i, row ->
                append("%08X  ".format(i * 16))
                append(row.joinToString(" ") { "%02X".format(it) }.padEnd(47))
                append("  ")
                append(row.map { b -> val c = b.toInt() and 0xFF; if (c in 32..126) c.toChar() else '.' }.joinToString(""))
                append('\n')
            }
            if (file.length() > max) append("\n… tronqué à 256 Ko sur ${file.length()} octets")
        }
    }
    Column(Modifier.fillMaxSize()) {
        TopAppBar(title = { Text(file.name) }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Retour") } })
        Box(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).horizontalScroll(rememberScrollState()).padding(8.dp)) {
            Text(dump, style = TextStyle(fontFamily = mono, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface))
        }
    }
}

// ---------------- Image viewer ----------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImageScreen(file: File, onBack: () -> Unit) {
    val bmp = remember(file) { BitmapFactory.decodeFile(file.path)?.asImageBitmap() }
    Column(Modifier.fillMaxSize()) {
        TopAppBar(title = { Text(file.name) }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Retour") } })
        if (bmp != null) Image(bmp, file.name, Modifier.fillMaxSize()) else Text("Format non décodable", Modifier.padding(16.dp))
    }
}

// ---------------- Live preview (HTTP / HTTPS servis par le serveur local) ----------------
@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun PreviewScreen(httpUrl: String, httpsUrl: String, onBack: () -> Unit) {
    var secure by remember { mutableStateOf(false) }
    val url = if (secure) httpsUrl else httpUrl
    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(url, maxLines = 1, fontSize = 12.sp) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Retour") } },
            actions = { TextButton(onClick = { secure = !secure }) { Text(if (secure) "HTTPS" else "HTTP") } }
        )
        key(url) {
            AndroidView(factory = { ctx ->
                WebView(ctx).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    webViewClient = object : WebViewClient() {
                        // certificat auto-signé : accepté uniquement pour notre serveur local
                        override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
                            val host = Uri.parse(error.url).host
                            if (host == "127.0.0.1" || host == "localhost") handler.proceed() else handler.cancel()
                        }
                    }
                    loadUrl(url)
                }
            }, modifier = Modifier.fillMaxSize())
        }
    }
}
