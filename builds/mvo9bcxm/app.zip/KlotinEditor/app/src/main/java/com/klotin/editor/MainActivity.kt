package com.klotin.editor

import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.klotin.editor.server.CertManager
import com.klotin.editor.server.LocalServer
import com.klotin.editor.ui.*
import com.klotin.editor.util.PdfExport
import com.klotin.editor.util.Share
import com.klotin.editor.workspace.ArchiveManager
import com.klotin.editor.workspace.WorkspaceManager
import java.io.File
import java.net.Inet4Address
import java.net.NetworkInterface
import kotlin.concurrent.thread

private sealed interface Screen {
    object Files : Screen
    data class Edit(val f: File) : Screen
    data class Hex(val f: File) : Screen
    data class Img(val f: File) : Screen
    data class Media(val f: File) : Screen
    data class Pdf(val f: File) : Screen
    data class Py(val f: File?) : Screen
    data class Preview(val rel: String) : Screen
}

class MainActivity : ComponentActivity() {
    private lateinit var wm: WorkspaceManager
    private var http: LocalServer? = null
    private var https: LocalServer? = null
    private var lan = false
    private val serverInfo = mutableStateOf("Démarrage du serveur…")

    private val imgExt = setOf("png", "jpg", "jpeg", "gif", "webp", "bmp", "ico")
    private val mediaExt = setOf("mp3", "wav", "ogg", "m4a", "flac", "aac", "opus", "mp4", "mkv", "webm", "avi", "mov", "3gp")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        wm = WorkspaceManager(this)
        startServers(false)

        setContent {
            var theme by remember { mutableStateOf(KTheme.OLED) }
            var screen by remember { mutableStateOf<Screen>(Screen.Files) }
            var files by remember { mutableStateOf(wm.files()) }
            fun refresh() { files = wm.files() }
            fun toast(m: String) = runOnUiThread { Toast.makeText(this, m, Toast.LENGTH_LONG).show() }

            val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
                uris.forEach { uri ->
                    val name = contentResolver.query(uri, null, null, null, null)?.use { c ->
                        if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
                    } ?: "import.bin"
                    contentResolver.openInputStream(uri)?.let { wm.import(name, it) }
                }
                refresh()
            }

            fun extract(f: File) {
                toast("Extraction de ${f.name}…")
                thread {
                    val r = runCatching { ArchiveManager.extract(f, wm, cacheDir) }
                    toast(r.fold({ "${it.size} fichier(s) extrait(s) et rangés" }, { "Échec : ${it.message}" }))
                    runOnUiThread { refresh() }
                }
            }

            val actions = FileActions(
                open = { f -> if (ArchiveManager.canExtract(f)) extract(f) else screen = route(f) },
                openWith = { Share.open(this, it) },
                share = { Share.send(this, it, whatsapp = false) },
                whatsapp = { Share.send(this, it, whatsapp = true) },
                extract = ::extract,
                pdf = { f ->
                    val dest = wm.create(f.nameWithoutExtension + ".pdf")
                    runCatching { PdfExport.textToPdf(f.readText(), dest) }
                        .onSuccess { toast("PDF créé : /media_docs/${dest.name}") }
                        .onFailure { toast("Échec PDF : ${it.message}") }
                    refresh()
                },
                zip = { f -> ArchiveManager.compress(listOf(f), wm.create(f.nameWithoutExtension + ".zip")); refresh() },
                runPy = { screen = Screen.Py(it) },
                delete = { wm.delete(it); refresh() },
            )

            BackHandler(screen != Screen.Files) { screen = Screen.Files; refresh() }

            KlotinTheme(theme) {
                Surface(Modifier.fillMaxSize()) {
                    when (val s = screen) {
                        Screen.Files -> FilesScreen(
                            wm, files, theme, serverInfo.value, actions,
                            onTheme = { theme = it },
                            onImport = { picker.launch(arrayOf("*/*")) },
                            onCreate = { wm.create(it); refresh() },
                            onOpenPython = { screen = Screen.Py(null) },
                            onToggleLan = { startServers(!lan) },
                        )
                        is Screen.Edit -> EditorScreen(s.f, wm, { screen = Screen.Files; refresh() },
                            onPreview = { screen = Screen.Preview(s.f.relativeTo(wm.root).path) },
                            onRun = { screen = Screen.Py(s.f) })
                        is Screen.Hex -> HexScreen(s.f) { screen = Screen.Files }
                        is Screen.Img -> ImageScreen(s.f) { screen = Screen.Files }
                        is Screen.Media -> MediaScreen(s.f) { screen = Screen.Files }
                        is Screen.Pdf -> PdfScreen(s.f) { screen = Screen.Files }
                        is Screen.Py -> PythonScreen(s.f) { screen = Screen.Files }
                        is Screen.Preview -> PreviewScreen("http://127.0.0.1:8080/${s.rel}", "https://127.0.0.1:8443/${s.rel}") { screen = Screen.Files }
                    }
                }
            }
        }
    }

    private fun route(f: File): Screen {
        val ext = f.extension.lowercase()
        return when {
            wm.categoryOf(f).isText -> Screen.Edit(f)
            ext in imgExt -> Screen.Img(f)
            ext in mediaExt -> Screen.Media(f)
            ext == "pdf" -> Screen.Pdf(f)
            else -> Screen.Hex(f) // catch-all : tout fichier est inspectable
        }
    }

    /** HTTP :8080 + HTTPS :8443 (certificat auto-signé). shareOnLan = écoute sur toutes les interfaces. */
    private fun startServers(shareOnLan: Boolean) {
        lan = shareOnLan
        serverInfo.value = "Démarrage du serveur…"
        thread {
            http?.stop(); https?.stop()
            val host = if (shareOnLan) null else "127.0.0.1"
            val ips = if (shareOnLan) lanIps() else emptyList()
            http = LocalServer(wm.root, host, 8080).also { it.start() }
            val httpsOk = runCatching {
                val ssl = CertManager.sslFactory(this, ips)
                https = LocalServer(wm.root, host, 8443, ssl).also { it.start() }
            }.isSuccess
            val where = if (shareOnLan && ips.isNotEmpty()) ips.first() else "127.0.0.1"
            serverInfo.value = "http://$where:8080" +
                (if (httpsOk) " · https://$where:8443 (auto-signé)" else " · HTTPS indisponible") +
                (if (shareOnLan) " · partagé sur le réseau" else " · local")
        }
    }

    private fun lanIps(): List<String> =
        NetworkInterface.getNetworkInterfaces().toList()
            .flatMap { it.inetAddresses.toList() }
            .filter { !it.isLoopbackAddress && it is Inet4Address }
            .mapNotNull { it.hostAddress }

    override fun onDestroy() { http?.stop(); https?.stop(); super.onDestroy() }
}
