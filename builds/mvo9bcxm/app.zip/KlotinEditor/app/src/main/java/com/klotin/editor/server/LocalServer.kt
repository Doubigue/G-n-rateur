package com.klotin.editor.server

import fi.iki.elonen.NanoHTTPD
import java.io.File
import java.io.FileInputStream
import java.net.URLDecoder

/**
 * Serves the workspace over HTTP. Relative links across sub-folders are resolved:
 * if a requested path doesn't exist, the file is looked up by name anywhere in the workspace.
 * host = "127.0.0.1" (local only) or null (all interfaces => LAN sharing).
 */
class LocalServer(
    private val root: File,
    host: String?,
    port: Int = 8080,
    ssl: javax.net.ssl.SSLServerSocketFactory? = null, // non nul => HTTPS
) : NanoHTTPD(host, port) {

    init { if (ssl != null) makeSecure(ssl, null) }

    override fun serve(session: IHTTPSession): Response {
        val rel = URLDecoder.decode(session.uri, "UTF-8").trimStart('/')
        if (rel.isEmpty()) return listing()

        val rootPath = root.canonicalPath
        var f = File(root, rel).canonicalFile
        if (!f.path.startsWith(rootPath)) return text(Response.Status.FORBIDDEN, "Forbidden")
        if (f.isDirectory) f = File(f, "index.html")
        if (!f.isFile) {
            val name = File(rel).name
            f = root.walkTopDown().firstOrNull { it.isFile && it.name == name && !it.path.contains("/.history/") }
                ?: return text(Response.Status.NOT_FOUND, "Not found: $rel")
        }
        return newChunkedResponse(Response.Status.OK, getMimeTypeForFile(f.name), FileInputStream(f))
    }

    private fun listing(): Response {
        val items = root.walkTopDown().filter { it.isFile && !it.path.contains("/.history/") }
            .joinToString("") {
                val p = it.relativeTo(root).path
                "<li><a href=\"/$p\">$p</a></li>"
            }
        return newFixedLengthResponse(Response.Status.OK, "text/html", "<h1>Klotin Workspace</h1><ul>$items</ul>")
    }

    private fun text(s: Response.Status, m: String) = newFixedLengthResponse(s, "text/plain", m)
}
