package com.klotin.editor.ui

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.io.File

/** Lecteur audio + vidéo (ExoPlayer / Media3). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MediaScreen(file: File, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val player = remember(file) {
        ExoPlayer.Builder(ctx).build().apply {
            setMediaItem(MediaItem.fromUri(Uri.fromFile(file)))
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    Column(Modifier.fillMaxSize()) {
        TopAppBar(title = { Text(file.name, maxLines = 1) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Retour") } })
        AndroidView(factory = { c -> PlayerView(c).also { pv -> pv.player = player } }, modifier = Modifier.fillMaxSize())
    }
}

/** Visionneuse PDF (PdfRenderer), pages rendues à la demande. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfScreen(file: File, onBack: () -> Unit) {
    val renderer = remember(file) {
        runCatching { PdfRenderer(ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)) }.getOrNull()
    }
    DisposableEffect(renderer) { onDispose { renderer?.close() } }
    Column(Modifier.fillMaxSize()) {
        TopAppBar(title = { Text("${file.name}" + (renderer?.let { " · ${it.pageCount} p" } ?: ""), maxLines = 1) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Retour") } })
        if (renderer == null) {
            Text("PDF illisible ou protégé", Modifier.padding(16.dp))
        } else LazyColumn(Modifier.fillMaxSize()) {
            items(renderer.pageCount) { i ->
                val bmp = remember(i) {
                    synchronized(renderer) {
                        val page = renderer.openPage(i)
                        try {
                            val w = 1080
                            val h = (w.toFloat() / page.width * page.height).toInt()
                            Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also {
                                it.eraseColor(Color.WHITE)
                                page.render(it, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            }
                        } finally { page.close() }
                    }
                }
                Image(bmp.asImageBitmap(), "Page ${i + 1}", Modifier.fillMaxWidth().padding(4.dp))
            }
        }
    }
}
