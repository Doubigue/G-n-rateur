package com.klotin.editor.ui

import android.os.Handler
import android.os.Looper
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.klotin.editor.util.PyBridge
import java.io.File
import kotlin.concurrent.thread

/** Console Python embarquée (Chaquopy) : exécute un .py et offre un REPL persistant. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PythonScreen(file: File?, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val main = remember { Handler(Looper.getMainLooper()) }
    var out by remember { mutableStateOf("") }
    var running by remember { mutableStateOf(false) }
    var line by remember { mutableStateOf("") }

    fun call(fn: String, arg: String, header: String) {
        running = true
        out += header
        thread {
            val res = PyBridge.call(ctx, fn, arg)
            main.post { out += res; running = false }
        }
    }

    LaunchedEffect(file) { if (file != null) call("run_file", file.absolutePath, "▶ ${file.name}\n") }

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(file?.name ?: "Console Python", maxLines = 1) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Retour") } },
            actions = {
                if (file != null) IconButton(enabled = !running, onClick = { call("run_file", file.absolutePath, "\n▶ ${file.name}\n") }) {
                    Icon(Icons.Default.PlayArrow, "Relancer")
                }
                TextButton(onClick = { out = "" }) { Text("Effacer") }
            }
        )
        Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(8.dp)) {
            Text(out, style = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface))
            if (running) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))
        }
        Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(line, { line = it }, Modifier.weight(1f), singleLine = true, label = { Text(">>> instruction Python") })
            Button(enabled = !running && line.isNotBlank(), onClick = { val l = line; line = ""; call("repl", l, ">>> $l\n") }) { Text("Exec") }
        }
    }
}
