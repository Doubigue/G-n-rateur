package com.klotin.editor.workspace

import com.github.junrar.Junrar
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FilterInputStream
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object ArchiveManager {
    private val extractable = listOf(
        ".zip", ".7z", ".rar", ".tar", ".tar.gz", ".tgz", ".tar.bz2", ".tbz2",
        ".tar.xz", ".txz", ".gz", ".bz2", ".xz"
    )

    fun canExtract(f: File) = f.name.lowercase().let { n -> extractable.any { n.endsWith(it) } }

    /** Extrait n'importe quelle archive prise en charge ; chaque fichier est routé par extension. */
    fun extract(src: File, wm: WorkspaceManager, cache: File): List<File> {
        val n = src.name.lowercase()
        return when {
            n.endsWith(".zip") -> zip(src, wm)
            n.endsWith(".7z") -> sevenZ(src, wm)
            n.endsWith(".rar") -> rar(src, wm, cache)
            else -> tarOrCompressed(src, wm)
        }
    }

    private fun zip(src: File, wm: WorkspaceManager): List<File> {
        val out = mutableListOf<File>()
        ZipInputStream(BufferedInputStream(src.inputStream())).use { zis ->
            var e: ZipEntry? = zis.nextEntry
            while (e != null) {
                // nom de base uniquement : protège du zip-slip ("../../x")
                if (!e.isDirectory) out += wm.import(File(e.name).name, zis.nonClosing())
                e = zis.nextEntry
            }
        }
        return out
    }

    @Suppress("DEPRECATION")
    private fun sevenZ(src: File, wm: WorkspaceManager): List<File> {
        val out = mutableListOf<File>()
        SevenZFile(src).use { z ->
            var e = z.nextEntry
            while (e != null) {
                if (!e.isDirectory) out += wm.import(File(e.name).name, z.getInputStream(e).nonClosing())
                e = z.nextEntry
            }
        }
        return out
    }

    /** RAR4 uniquement (junrar) ; RAR5 n'est pas supporté. */
    private fun rar(src: File, wm: WorkspaceManager, cache: File): List<File> {
        val tmp = File(cache, "rar_${System.nanoTime()}").apply { mkdirs() }
        return try {
            Junrar.extract(src, tmp)
            tmp.walkTopDown().filter { it.isFile }.map { f -> f.inputStream().use { wm.import(f.name, it) } }.toList()
        } finally {
            tmp.deleteRecursively()
        }
    }

    private fun tarOrCompressed(src: File, wm: WorkspaceManager): List<File> {
        val n = src.name.lowercase()
        val isTar = n.endsWith(".tar") || n.contains(".tar.") || n.endsWith(".tgz") || n.endsWith(".tbz2") || n.endsWith(".txz")
        var input: InputStream = BufferedInputStream(src.inputStream())
        input = when {
            n.endsWith(".gz") || n.endsWith(".tgz") -> GzipCompressorInputStream(input)
            n.endsWith(".bz2") || n.endsWith(".tbz2") -> BZip2CompressorInputStream(input)
            n.endsWith(".xz") || n.endsWith(".txz") -> XZCompressorInputStream(input)
            else -> input
        }
        val out = mutableListOf<File>()
        input.use { stream ->
            if (!isTar) {
                // fichier unique compressé (ex: data.csv.gz -> data.csv)
                out += wm.import(src.name.substringBeforeLast('.'), stream.nonClosing())
            } else {
                TarArchiveInputStream(stream).use { tis ->
                    var e = tis.nextEntry
                    while (e != null) {
                        if (!e.isDirectory) out += wm.import(File(e.name).name, tis.nonClosing())
                        e = tis.nextEntry
                    }
                }
            }
        }
        return out
    }

    fun compress(files: List<File>, dest: File) {
        ZipOutputStream(dest.outputStream()).use { zos ->
            files.forEach { f ->
                zos.putNextEntry(ZipEntry(f.name))
                f.inputStream().use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }
    }

    private fun InputStream.nonClosing(): InputStream = object : FilterInputStream(this) {
        override fun close() {}
    }
}
