package com.klotin.editor.util

import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import java.io.File

object PdfExport {
    /** Génère un PDF A4 paginé à partir d'un texte (notes, reçus, code). */
    fun textToPdf(text: String, dest: File) {
        val w = 595; val h = 842; val margin = 40; val lineH = 15
        val paint = Paint().apply { textSize = 10.5f; typeface = Typeface.MONOSPACE }
        val maxChars = ((w - 2 * margin) / paint.measureText("M")).toInt()
        val lines = text.replace("\t", "    ").lines().flatMap { if (it.isEmpty()) listOf("") else it.chunked(maxChars) }
        val perPage = (h - 2 * margin) / lineH
        val pages = lines.chunked(perPage).ifEmpty { listOf(listOf("")) }
        val doc = PdfDocument()
        pages.forEachIndexed { i, pageLines ->
            val page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, i + 1).create())
            pageLines.forEachIndexed { j, l -> page.canvas.drawText(l, margin.toFloat(), (margin + (j + 1) * lineH).toFloat(), paint) }
            doc.finishPage(page)
        }
        dest.outputStream().use { doc.writeTo(it) }
        doc.close()
    }
}
