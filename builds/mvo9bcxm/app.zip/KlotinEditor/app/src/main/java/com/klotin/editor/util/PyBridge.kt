package com.klotin.editor.util

import android.content.Context
import java.lang.reflect.InvocationTargetException

/**
 * Accès à Chaquopy par réflexion : l'app compile même sans le plugin Python.
 * Pour activer Python, voir la section « Activer la console Python » du README.
 */
object PyBridge {
    val available: Boolean
        get() = runCatching { Class.forName("com.chaquo.python.Python") }.isSuccess

    fun call(ctx: Context, fn: String, arg: String): String {
        if (!available) {
            return "Python n'est pas activé dans cette compilation.\n" +
                "Voir README : « Activer la console Python ».\n"
        }
        try {
            val pyC = Class.forName("com.chaquo.python.Python")
            if (!(pyC.getMethod("isStarted").invoke(null) as Boolean)) {
                val platform = Class.forName("com.chaquo.python.android.AndroidPlatform")
                    .getConstructor(Context::class.java).newInstance(ctx)
                pyC.methods.first { it.name == "start" }.invoke(null, platform)
            }
            val py = pyC.getMethod("getInstance").invoke(null)
            val module = pyC.getMethod("getModule", String::class.java).invoke(py, "runner")
            val pyObj = Class.forName("com.chaquo.python.PyObject")
            val res = pyObj.getMethod("callAttr", String::class.java, Array<Any>::class.java)
                .invoke(module, fn, arrayOf<Any>(arg))
            return res.toString()
        } catch (e: InvocationTargetException) {
            return "Erreur Python : ${e.targetException.message}\n"
        } catch (e: Exception) {
            return "Erreur : ${e.message}\n"
        }
    }
}
