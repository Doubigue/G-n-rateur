package com.klotin.editor.server

import android.content.Context
import fi.iki.elonen.NanoHTTPD
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.asn1.x509.BasicConstraints
import org.bouncycastle.asn1.x509.Extension
import org.bouncycastle.asn1.x509.GeneralName
import org.bouncycastle.asn1.x509.GeneralNames
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import java.io.File
import java.math.BigInteger
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.util.Date
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.SSLServerSocketFactory

/** Certificat SSL auto-signé (localhost, 127.0.0.1 + IP du réseau local), régénéré si l'IP change. */
object CertManager {
    private const val PASS = "klotin"
    private const val ALIAS = "klotin"

    fun sslFactory(ctx: Context, ips: List<String>): SSLServerSocketFactory {
        val ksFile = File(ctx.filesDir, "klotin.p12")
        val meta = File(ctx.filesDir, "klotin.p12.ips")
        val key = ips.sorted().joinToString(",")
        val ks = KeyStore.getInstance("PKCS12")
        if (ksFile.exists() && meta.exists() && meta.readText() == key) {
            ksFile.inputStream().use { ks.load(it, PASS.toCharArray()) }
        } else {
            generate(ks, ips)
            ksFile.outputStream().use { ks.store(it, PASS.toCharArray()) }
            meta.writeText(key)
        }
        val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm())
        kmf.init(ks, PASS.toCharArray())
        return NanoHTTPD.makeSSLSocketFactory(ks, kmf)
    }

    private fun generate(ks: KeyStore, ips: List<String>) {
        val kp = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }.generateKeyPair()
        val name = X500Name("CN=Klotin Local")
        val now = Date()
        val end = Date(now.time + 825L * 24 * 3600 * 1000)
        val builder = JcaX509v3CertificateBuilder(name, BigInteger.valueOf(now.time), now, end, name, kp.public)
        val san = mutableListOf(
            GeneralName(GeneralName.dNSName, "localhost"),
            GeneralName(GeneralName.iPAddress, "127.0.0.1")
        )
        ips.forEach { san += GeneralName(GeneralName.iPAddress, it) }
        builder.addExtension(Extension.subjectAlternativeName, false, GeneralNames(san.toTypedArray()))
        builder.addExtension(Extension.basicConstraints, true, BasicConstraints(false))
        val signer = JcaContentSignerBuilder("SHA256withRSA").build(kp.private)
        val cert = JcaX509CertificateConverter().getCertificate(builder.build(signer))
        ks.load(null, null)
        ks.setKeyEntry(ALIAS, kp.private, PASS.toCharArray(), arrayOf(cert))
    }
}
