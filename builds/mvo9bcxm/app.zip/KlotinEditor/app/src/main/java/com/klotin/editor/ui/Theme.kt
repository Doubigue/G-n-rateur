package com.klotin.editor.ui

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

enum class KTheme(val label: String) { OLED("OLED"), CYBERPUNK("Cyberpunk"), LIGHT("Clair") }

@Composable
fun KlotinTheme(theme: KTheme, content: @Composable () -> Unit) {
    val scheme = when (theme) {
        KTheme.OLED -> darkColorScheme(background = Color.Black, surface = Color.Black,
            surfaceVariant = Color(0xFF111111), primary = Color(0xFF82B1FF), onBackground = Color.White, onSurface = Color.White)
        KTheme.CYBERPUNK -> darkColorScheme(background = Color(0xFF0B0221), surface = Color(0xFF0B0221),
            surfaceVariant = Color(0xFF1A0B3D), primary = Color(0xFFFF2BD6), secondary = Color(0xFF00F0FF),
            onBackground = Color(0xFFE0F7FF), onSurface = Color(0xFFE0F7FF))
        KTheme.LIGHT -> lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
