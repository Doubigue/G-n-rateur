package com.klotin.editor.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.klotin.editor.workspace.ArchiveManager
import com.klotin.editor.workspace.WorkspaceManager
import java.io.File

class FileActions(
    val open: (File) -> Unit,
    val openWith: (File) -> Unit,
    val share: (File) -> Unit,
    val whatsapp: (File) -> Unit,
    val extract: (File) -> Unit,
    val pdf: (File) -> Unit,
    val zip: (File) -> Unit,
    val runPy: (File) -> Unit,
    val delete: (File) -> Unit,
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FilesScreen(
    wm: WorkspaceManager,
    files: List<File>,
    theme: KTheme,
    serverInfo: String,
    actions: FileActions,
    onTheme: (KTheme) -> Unit,
    onImport: () -> Unit,
    onCreate: (String) -> Unit,
    onOpenPython: () -> Unit,
    onToggleLan: () -> Unit,
) {
    var newName by remember { mutableStateOf<String?>(null) }
    var themeMenu by remember { mutableStateOf(false) }
    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Co-edit") }, actions = {
                TextButton(onClick = onOpenPython) { Text("Python") }
                TextButton(onClick = onToggleLan) { Text("Serveur") }
                Box {
                    TextButton(onClick = { themeMenu = true }) { Text(theme.label) }
                    DropdownMenu(themeMenu, { themeMenu = false }) {
                        KTheme.values().forEach { t -> DropdownMenuItem({ Text(t.label) }, { onTheme(t); themeMenu = false }) }
                    }
                }
                IconButton(onClick = onImport) { Text("⇪") }
            })
        },
        floatingActionButton = { FloatingActionButton(onClick = { newName = "" }) { Icon(Icons.Default.Add, "Nouveau") } }
    ) { pad ->
        Column(Modifier.padding(pad)) {
            Text(serverInfo, Modifier.padding(horizontal = 16.dp, vertical = 4.dp), style = MaterialTheme.typography.labelSmall)
            val grouped = files.groupBy { wm.categoryOf(it) }
            LazyColumn {
                grouped.forEach { (cat, list) ->
                    item { Text("/${cat.dir}/", Modifier.padding(16.dp, 12.dp, 16.dp, 4.dp), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.titleSmall) }
                    items(list) { f ->
                        var menu by remember { mutableStateOf(false) }
                        Row(Modifier.fillMaxWidth().clickable { actions.open(f) }.padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(f.name)
                                Text("${f.length()} o", style = MaterialTheme.typography.labelSmall)
                            }
                            Box {
                                IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "Menu") }
                                DropdownMenu(menu, { menu = false }) {
                                    @Composable fun item(label: String, block: () -> Unit) = DropdownMenuItem({ Text(label) }, { menu = false; block() })
                                    if (f.extension.lowercase() == "py") item("Exécuter (Python)") { actions.runPy(f) }
                                    if (ArchiveManager.canExtract(f)) item("Extraire") { actions.extract(f) }
                                    item("Ouvrir avec…") { actions.openWith(f) }
                                    item("Partager") { actions.share(f) }
                                    item("Envoyer sur WhatsApp") { actions.whatsapp(f) }
                                    if (wm.categoryOf(f).isText) item("Exporter en PDF") { actions.pdf(f) }
                                    item("Compresser (zip)") { actions.zip(f) }
                                    item("Supprimer") { actions.delete(f) }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    newName?.let { n ->
        AlertDialog(onDismissRequest = { newName = null },
            title = { Text("Nouveau fichier") },
            text = { OutlinedTextField(n, { newName = it }, singleLine = true, label = { Text("ex: index.html") }) },
            confirmButton = { TextButton(onClick = { if (n.isNotBlank()) onCreate(n); newName = null }) { Text("Créer") } },
            dismissButton = { TextButton(onClick = { newName = null }) { Text("Annuler") } })
    }
}
