package com.klotin.editor.util

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

object Share {
    private fun uri(ctx: Context, f: File) = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)

    private fun mime(f: File) =
        MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "application/octet-stream"

    /** Partage système ; whatsapp = true cible directement WhatsApp (repli sur le sélecteur). */
    fun send(ctx: Context, f: File, whatsapp: Boolean) {
        val u = uri(ctx, f)
        val i = Intent(Intent.ACTION_SEND).apply {
            type = mime(f)
            putExtra(Intent.EXTRA_STREAM, u)
            clipData = ClipData.newRawUri("", u)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            if (whatsapp) setPackage("com.whatsapp")
        }
        try {
            ctx.startActivity(if (whatsapp) i else Intent.createChooser(i, "Partager ${f.name}"))
        } catch (e: ActivityNotFoundException) {
            i.setPackage(null)
            ctx.startActivity(Intent.createChooser(i, "Partager ${f.name}"))
        }
    }

    /** Ouvrir avec une autre application (docx, xlsx, pptx, ...). */
    fun open(ctx: Context, f: File) {
        val i = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri(ctx, f), mime(f))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try { ctx.startActivity(i) } catch (e: ActivityNotFoundException) {
            Toast.makeText(ctx, "Aucune application pour ouvrir ce fichier", Toast.LENGTH_SHORT).show()
        }
    }
}
