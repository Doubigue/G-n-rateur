import sys, io, os, runpy, traceback, contextlib

_ns = {"__name__": "__console__"}


def _capture(fn):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
        try:
            fn()
        except SystemExit:
            pass
        except BaseException:
            traceback.print_exc()
    return buf.getvalue()


def run_file(path):
    d = os.path.dirname(path)
    parent = os.path.dirname(d)
    # tous les sous-dossiers du workspace sont importables
    for sub in [d] + [os.path.join(parent, s) for s in os.listdir(parent) if not s.startswith(".")]:
        if os.path.isdir(sub) and sub not in sys.path:
            sys.path.insert(0, sub)
    os.chdir(d)
    return _capture(lambda: runpy.run_path(path, run_name="__main__"))


def repl(line):
    def go():
        try:
            r = eval(compile(line, "<console>", "eval"), _ns)
            if r is not None:
                print(repr(r))
        except SyntaxError:
            exec(compile(line, "<console>", "exec"), _ns)
    return _capture(go)
