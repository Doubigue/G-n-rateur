import 'package:flutter/material.dart';
import '../services/local_store.dart';

class AccountScreen extends StatefulWidget {
  final Map<String, dynamic> profile;
  final Future<void> Function(Map<String, dynamic>) onSave;
  const AccountScreen({super.key, required this.profile, required this.onSave});
  @override
  State<AccountScreen> createState() => _AccountScreenState();
}
class _AccountScreenState extends State<AccountScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _name;
  late final TextEditingController _email;
  late final TextEditingController _phone;
  List<Map<String, dynamic>> _orders = [];
  List<Map<String, dynamic>> _manuscripts = [];

  @override
  void initState() {
    super.initState();
    _name = TextEditingController(text: widget.profile['name'] as String? ?? '');
    _email = TextEditingController(text: widget.profile['email'] as String? ?? '');
    _phone = TextEditingController(text: widget.profile['phone'] as String? ?? '');
    _loadLists();
  }
  Future<void> _loadLists() async {
    final o = await LocalStore.loadOrders();
    final m = await LocalStore.loadManuscripts();
    if (mounted) setState(() { _orders = o; _manuscripts = m; });
  }
  @override
  void dispose() { _name.dispose(); _email.dispose(); _phone.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('Mon espace', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: Color(0xFF10281E))),
    const SizedBox(height: 5), const Text('Vos informations et votre activité sur cet appareil.'),
    const SizedBox(height: 18),
    Card(child: Padding(padding: const EdgeInsets.all(16), child: Form(key: _formKey, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Mes informations', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 14),
      TextFormField(controller: _name, decoration: const InputDecoration(labelText: 'Nom complet'), validator: (v) => v == null || v.trim().isEmpty ? 'Entrez votre nom.' : null),
      const SizedBox(height: 10),
      TextFormField(controller: _email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Adresse e-mail'), validator: (v) => v == null || !v.contains('@') ? 'Adresse e-mail invalide.' : null),
      const SizedBox(height: 10),
      TextFormField(controller: _phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Téléphone (facultatif)')),
      const SizedBox(height: 14),
      SizedBox(width: double.infinity, child: FilledButton(onPressed: () async {
        if (!_formKey.currentState!.validate()) return;
        await widget.onSave({'name': _name.text.trim(), 'email': _email.text.trim(), 'phone': _phone.text.trim()});
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Profil enregistré localement.')));
      }, child: const Text('Enregistrer mon profil'))),
    ])))),
    const SizedBox(height: 16),
    _section('Mes achats', _orders.isEmpty ? 'Aucune commande enregistrée.' : null),
    ..._orders.map((o) => Card(child: ListTile(leading: const Icon(Icons.receipt_long), title: Text(o['reference']?.toString() ?? 'Commande'), subtitle: Text('${o['status'] ?? ''} • ${o['createdAt'] ?? ''}'), trailing: Text('${o['total'] ?? 0} F')))),
    const SizedBox(height: 16),
    _section('Mes manuscrits', _manuscripts.isEmpty ? 'Aucun manuscrit enregistré.' : null),
    ..._manuscripts.map((m) => Card(child: ListTile(leading: const Icon(Icons.description_outlined), title: Text(m['title']?.toString() ?? 'Manuscrit'), subtitle: Text(m['reference']?.toString() ?? 'Brouillon local')))),
    const SizedBox(height: 16),
    const Text('Les données restent privées dans le stockage local de cette application. Elles ne sont pas synchronisées avec le site web.', style: TextStyle(color: Colors.black54, fontSize: 12)),
  ]);

  Widget _section(String title, String? empty) => Padding(padding: const EdgeInsets.only(bottom: 8), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: Color(0xFF10281E))),
    if (empty != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(empty, style: const TextStyle(color: Colors.black54))),
  ]));
}
