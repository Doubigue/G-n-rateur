# Téléphone ✦ — appli d'appels et de messages magique (Kotlin)

Created by **DL VIBE STUDIO** · Doubigue Loubikoa

Application Android native (Kotlin + Jetpack Compose) qui remplace l'appli Téléphone du système.

## Fonctions
**Téléphone complet**
- Clavier avec tonalités, recherche **T9** sur les noms, initiales et numéros
- Récents groupés par jour, filtres (Manqués, Entrants, Sortants, Bloqués), appui long : SMS, copier, bloquer, ajouter
- Contacts avec favoris ★, recherche, index alphabétique
- Écran d'appel : répondre/refuser, muet, haut-parleur, Bluetooth, attente, clavier DTMF, double appel, choix de SIM (double SIM)
- Écran qui s'éteint contre l'oreille (capteur de proximité), affichage par-dessus l'écran verrouillé

**Fonctions magiques ✨**
- 🔦 **Flash magique** : le flash clignote à l'appel entrant
- 🗣️ **Annonce vocale** : « Appel de Maman »
- 🙃 **Retourner = silence** : posez le téléphone face cachée pour couper la sonnerie
- 📳 **Vibration de décroché** quand votre correspondant répond
- 💬 **Refuser avec un SMS** (réponses personnalisables)
- ⏰ **« Dans 10 min »** : refuse et vous rappelle de rappeler
- 🛡️ **Bouclier** : liste noire, blocage des numéros masqués et des inconnus
- ⚡ **Numérotation rapide** : appui long sur 2 à 9 ; appui long sur 1 = messagerie, sur 0 = « + »
- 🔁 Bouton d'appel sur clavier vide = recompose le dernier numéro
- 📊 **Statistiques** des 30 derniers jours (graphe 7 jours, top contacts)
- 🎨 **Style simple** (sobre, suit le mode clair/sombre) et **9 styles DL VIBE** (Orange Studio, Mamba, Émeraude, Festin, Crépuscule, Portfolio, Losanges, Cramoisi, Black Friday) + style surprise

**Thèmes d'appel 🎬 (v1.1)**
- Lier à un numéro : une **vidéo** (plein écran pendant la sonnerie, à l'appel entrant comme sortant), une **sonnerie**, une **photo** et une **note** affichée pendant l'appel
- **Son de la vidéo** utilisable comme sonnerie
- **Thème par défaut** : une vidéo ou une sonnerie pour tous les appels
- **Photo des contacts** affichée partout ; en plein écran pendant l'appel si le numéro a une photo
- **VIP ⭐** : sonne même en mode silencieux ou Ne pas déranger
- **Aperçu de l'appel** pour voir le rendu avant un vrai appel
- **Sonnerie progressive** et vibration pendant la sonnerie
- **Blocage par préfixe** (ex. `+234*`)
- **Raccourcis** sur l'icône de l'appli : appui long = appeler vos 3 contacts les plus appelés
- Accès : onglet Réglages → « Thèmes d'appel », ou appui long sur un contact / un appel récent → « Personnaliser l'appel »

**Îlot d'appel caméra 🏝️ (v1.2)**
- Téléphone en main : l'appel s'affiche dans un îlot autour de la caméra frontale (au lieu du plein écran)
- Touche rouge (1 doigt) = refuser · touche verte (2 doigts) = répondre
- Maintenir 1 doigt sur l'îlot = refuser (anneau rouge) · poser 2 doigts = répondre (anneau vert)
- Toucher le centre = ouvrir / réduire l'îlot
- Caméra couverte pendant la sonnerie (capteur de proximité) : Rien / Silence (par défaut) / Répondre / Refuser
- Bouton « Essayer l'îlot » dans l'onglet Réglages
- Autorisation requise : « Afficher par-dessus les autres applis »

**Messages 💬 (v1.3)**
- Onglet Messages : conversations, photos, non lus, recherche dans le texte de tous les SMS
- Lire, envoyer, recevoir ; accusés « Envoyé ✓ / Reçu ✓✓ » (en appli SMS par défaut)
- 🔐 Codes de vérification détectés : « Copier le code » dans la notification et la conversation
- ↩️ Réponse directe depuis la notification · Marquer comme lu
- ⏰ Envoi programmé : appui long sur Envoyer (10 min, 1 h, ce soir, demain, heure au choix)
- 🤖 Répondeur automatique (1 fois / 30 min par numéro, jamais aux numéros courts)
- 🗣️ Lecture vocale des SMS reçus · « Lire à voix haute » sur un message
- ✍️ Signature automatique · 💬 réponses rapides · 🛡️ bouclier SMS (numéros bloqués)
- Refuser un appel avec SMS passe par DL Phone quand il est l'appli SMS par défaut

**v1.4**
- 📷 **MMS** : recevoir (téléchargement automatique), afficher les photos, les agrandir et les enregistrer dans la galerie ; envoyer une photo avec une légende (bouton 📷 dans la conversation, photo réduite à ~300 Ko)
- Nom de l'appli : **Téléphone**

**v1.5**
- Plus d'écran de démarrage, plus d'émojis ni de symboles dans les textes
- Plus de bannières « Activer… » : tout est dans Réglages > Général (appli d'appels, appli SMS, filtrage, affichage par-dessus les applis, autorisations)

## Compilation (GitHub Actions)
1. Envoyez ce dossier dans un dépôt GitHub (ou passez-le par APK Studio).
2. Le workflow `.github/workflows/build.yml` compile l'APK **signé** à chaque push.
3. Téléchargez l'APK dans l'onglet **Actions → DL-Phone-APK**.

En local avec Android Studio : `./gradlew assembleRelease` → `app/build/outputs/apk/release/app-release.apk`.

## Clé de signature
- Fichier : `app/dlphone-release.jks` (PKCS12, RSA 2048, valable 10 000 jours)
- Alias : `dlphone`
- Mot de passe (magasin et clé) : dans `keystore.properties`
- Titulaire : CN=Doubigue Loubikoa, O=DL VIBE STUDIO, C=CI
- SHA-256 : `4A:43:5D:77:DB:F6:A8:BC:ED:1F:F9:9D:54:39:FD:8A:67:A4:23:6F:D1:6F:1A:E4:BA:28:19:7C:EF:CD:06:E8`

⚠️ Gardez une copie de la clé et du mot de passe en lieu sûr : sans eux, impossible de publier une mise à jour. Utilisez un dépôt **privé** (ou mettez la clé dans les secrets GitHub).

## Premier lancement
Acceptez « Définir DL Phone comme appli Téléphone par défaut », puis les autorisations. Pour le filtrage avant la sonnerie (Android 10+), touchez « Activer le filtrage » dans l'onglet Réglages.
