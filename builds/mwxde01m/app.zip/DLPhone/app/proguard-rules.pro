# DL Phone — les services Telecom sont déclarés dans le manifeste et conservés automatiquement.
-keep class com.dlvibe.dlphone.DlInCallService { *; }
-keep class com.dlvibe.dlphone.DlScreeningService { *; }
