package com.dlvibe.dlphone

import android.content.Context
import android.media.MediaPlayer
import android.speech.tts.TextToSpeech
import java.util.Locale

/** Lecture des clips MP3 fournis, en respectant la voix sélectionnée. */
object VoiceAnnouncer {
    private var player: MediaPlayer? = null
    private val queue = ArrayDeque<Int>()
    private var context: Context? = null

    @Synchronized fun speakDigits(ctx: Context, value: String) {
        Prefs.init(ctx)
        val gender = Prefs.voiceGender
        val ids = value.filter { it.isDigit() || it == '*' || it == '#' || it == '+' }.mapNotNull { ch ->
            val key = when (ch) {
                in '0'..'9' -> listOf("zero","one","two","three","four","five","six","seven","eight","nine")[ch - '0']
                '*' -> "star"
                '#' -> "hash"
                '+' -> "plus"
                else -> return@mapNotNull null
            }
            val name = "voice_${gender}_${key}"
            ctx.resources.getIdentifier(name, "raw", ctx.packageName).takeIf { it != 0 }
        }
        if (ids.isEmpty()) return
        context = ctx.applicationContext
        queue.clear()
        queue.addAll(ids)
        playNext()
    }

    @Synchronized private fun playNext() {
        val ctx = context ?: return
        val id = queue.removeFirstOrNull() ?: run { player?.release(); player = null; return }
        try {
            player?.release()
            player = MediaPlayer.create(ctx, id)?.apply {
                setOnCompletionListener { synchronized(this@VoiceAnnouncer) { playNext() } }
                setOnErrorListener { mp, _, _ -> mp.release(); player = null; playNext(); true }
                start()
            }
        } catch (_: Exception) { player = null; playNext() }
    }

    @Synchronized fun stop() {
        queue.clear()
        player?.release()
        player = null
    }
}
