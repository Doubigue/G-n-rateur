package com.dlvibe.dlphone

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.CallLog
import android.provider.ContactsContract
import androidx.core.content.ContextCompat
import java.text.Normalizer

data class Contact(val id: Long, val name: String, val number: String, val starred: Boolean, val photo: String? = null)

data class CallEntry(
    val id: Long,
    val number: String,
    val name: String?,
    val type: Int,
    val date: Long,
    val duration: Long,
    val photo: String? = null
)

object ContactsRepo {
    fun granted(c: Context, p: String) =
        ContextCompat.checkSelfPermission(c, p) == PackageManager.PERMISSION_GRANTED

    fun contacts(c: Context): List<Contact> {
        if (!granted(c, Manifest.permission.READ_CONTACTS)) return emptyList()
        val out = ArrayList<Contact>()
        val proj = arrayOf(
            ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER,
            "starred",
            "photo_thumb_uri"
        )
        try {
            c.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI, proj, null, null,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE NOCASE ASC"
            )?.use { cur ->
                while (cur.moveToNext()) {
                    val number = cur.getString(2) ?: continue
                    out += Contact(cur.getLong(0), cur.getString(1) ?: number, number, cur.getInt(3) == 1, cur.getString(4))
                }
            }
        } catch (_: Exception) {
        }
        val seen = HashSet<String>()
        return out.filter { seen.add("${it.id}:${Prefs.norm(it.number)}") }
    }

    fun calls(c: Context, limit: Int = 500): List<CallEntry> {
        if (!granted(c, Manifest.permission.READ_CALL_LOG)) return emptyList()
        val out = ArrayList<CallEntry>()
        val proj = arrayOf(
            CallLog.Calls._ID, CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME,
            CallLog.Calls.TYPE, CallLog.Calls.DATE, CallLog.Calls.DURATION, CallLog.Calls.CACHED_PHOTO_URI
        )
        try {
            c.contentResolver.query(CallLog.Calls.CONTENT_URI, proj, null, null, CallLog.Calls.DATE + " DESC")
                ?.use { cur ->
                    while (cur.moveToNext() && out.size < limit) {
                        out += CallEntry(
                            cur.getLong(0),
                            cur.getString(1) ?: "",
                            cur.getString(2)?.takeIf { it.isNotBlank() },
                            cur.getInt(3),
                            cur.getLong(4),
                            cur.getLong(5),
                            cur.getString(6)?.takeIf { it.isNotBlank() }
                        )
                    }
                }
        } catch (_: Exception) {
        }
        return out
    }

    fun nameFor(c: Context, number: String?): String? {
        if (number.isNullOrBlank() || !granted(c, Manifest.permission.READ_CONTACTS)) return null
        return try {
            c.contentResolver.query(
                Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number)),
                arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null
            )?.use { if (it.moveToFirst()) it.getString(0) else null }
        } catch (_: Exception) {
            null
        }
    }
}

fun ContactsRepo.photoFor(c: Context, number: String?): String? {
    if (number.isNullOrBlank() || !granted(c, Manifest.permission.READ_CONTACTS)) return null
    return try {
        c.contentResolver.query(
            Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number)),
            arrayOf(ContactsContract.PhoneLookup.PHOTO_URI), null, null, null
        )?.use { if (it.moveToFirst()) it.getString(0) else null }
    } catch (_: Exception) {
        null
    }
}

/** Recherche intelligente T9 : 2=ABC, 3=DEF… sur les noms, les initiales et les numéros. */
object T9 {
    private const val KEYS = "22233344455566677778889999"

    fun clean(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "").lowercase()

    private fun encode(s: String): String = clean(s).map { ch ->
        when (ch) {
            in 'a'..'z' -> KEYS[ch - 'a']
            in '0'..'9' -> ch
            else -> ' '
        }
    }.joinToString("")

    fun matches(name: String, number: String, query: String): Boolean {
        if (query.isEmpty()) return false
        if (query.any { !it.isDigit() }) return number.replace(" ", "").contains(query)
        if (number.filter { it.isDigit() }.contains(query)) return true
        val words = encode(name).split(' ').filter { it.isNotEmpty() }
        if (words.any { it.startsWith(query) }) return true
        val initials = words.joinToString("") { it.take(1) }
        return query.length >= 2 && initials.startsWith(query)
    }
}
