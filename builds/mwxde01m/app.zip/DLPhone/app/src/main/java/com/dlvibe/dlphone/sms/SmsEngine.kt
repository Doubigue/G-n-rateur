package com.dlvibe.dlphone.sms

import android.app.Activity
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.provider.Telephony
import android.telephony.SmsManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.RemoteInput
import com.dlvibe.dlphone.ContactsRepo
import com.dlvibe.dlphone.MagicEffects
import com.dlvibe.dlphone.Prefs
import com.dlvibe.dlphone.R
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject

/** Signal pour rafraîchir l'écran Messages. */
object SmsBus {
    val tick = MutableStateFlow(0)
    fun changed() {
        tick.value = tick.value + 1
    }
}

object SmsSender {
    @Suppress("DEPRECATION")
    fun manager(c: Context): SmsManager =
        if (Build.VERSION.SDK_INT >= 31) c.getSystemService(SmsManager::class.java) else SmsManager.getDefault()

    /** Envoie un SMS (avec signature automatique si activée). */
    fun send(c: Context, address: String, text: String, sign: Boolean = true): Boolean {
        if (address.isBlank() || text.isBlank()) return false
        Prefs.init(c)
        val sig = Prefs.smsSignature.trim()
        val body = if (sign && sig.isNotEmpty() && !text.endsWith(sig)) "$text\n— $sig" else text
        return try {
            val uri = SmsRepo.insertOutgoing(c, address, body)
            val sm = manager(c)
            val parts = sm.divideMessage(body)
            val base = (System.currentTimeMillis() and 0xFFFFFF).toInt()
            val sent = ArrayList<PendingIntent>()
            val delivered = ArrayList<PendingIntent>()
            parts.indices.forEach { i ->
                sent += status(c, SmsActionReceiver.ACTION_SENT, uri, base * 4 + i, i == parts.size - 1)
                delivered += status(c, SmsActionReceiver.ACTION_DELIVERED, uri, base * 4 + 2 + i, i == parts.size - 1)
            }
            if (parts.size > 1) sm.sendMultipartTextMessage(address, null, parts, sent, delivered)
            else sm.sendTextMessage(address, null, body, sent[0], delivered[0])
            SmsBus.changed()
            true
        } catch (e: Exception) {
            Toast.makeText(c, "Envoi impossible : ${e.message}", Toast.LENGTH_LONG).show()
            false
        }
    }

    private fun status(c: Context, action: String, uri: Uri?, req: Int, last: Boolean): PendingIntent {
        val i = Intent(c, SmsActionReceiver::class.java).setAction(action)
            .putExtra("uri", uri?.toString()).putExtra("last", last)
        return PendingIntent.getBroadcast(c, req, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
}

/** Messages programmés. */
data class ScheduledSms(val id: Long, val address: String, val body: String, val at: Long)

object Scheduled {
    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("dl_sms_scheduled", Context.MODE_PRIVATE)

    fun all(c: Context): List<ScheduledSms> {
        val raw = sp(c).getString("list", "[]") ?: "[]"
        return runCatching {
            val a = JSONArray(raw)
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                ScheduledSms(o.getLong("id"), o.getString("address"), o.getString("body"), o.getLong("at"))
            }
        }.getOrDefault(emptyList()).sortedBy { it.at }
    }

    private fun saveAll(c: Context, list: List<ScheduledSms>) {
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().put("id", it.id).put("address", it.address).put("body", it.body).put("at", it.at))
        }
        sp(c).edit().putString("list", a.toString()).apply()
    }

    fun add(c: Context, address: String, body: String, at: Long) {
        val item = ScheduledSms(System.currentTimeMillis(), address, body, at)
        saveAll(c, all(c) + item)
        arm(c, item)
        SmsBus.changed()
    }

    fun cancel(c: Context, id: Long) {
        saveAll(c, all(c).filter { it.id != id })
        alarmManager(c)?.cancel(pending(c, id))
        SmsBus.changed()
    }

    fun fire(c: Context, id: Long) {
        val item = all(c).firstOrNull { it.id == id } ?: return
        saveAll(c, all(c).filter { it.id != id })
        if (SmsSender.send(c, item.address, item.body)) {
            SmsNotif.info(c, "Message programmé envoyé", "À ${ContactsRepo.nameFor(c, item.address) ?: item.address} : ${item.body}")
        }
        SmsBus.changed()
    }

    fun rearmAll(c: Context) = all(c).forEach { arm(c, it) }

    private fun alarmManager(c: Context) = c.getSystemService(AlarmManager::class.java)

    private fun pending(c: Context, id: Long): PendingIntent = PendingIntent.getBroadcast(
        c, (id and 0x7FFFFFF).toInt(),
        Intent(c, SmsActionReceiver::class.java).setAction(SmsActionReceiver.ACTION_SCHEDULED).putExtra("id", id),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun arm(c: Context, item: ScheduledSms) {
        val am = alarmManager(c) ?: return
        val pi = pending(c, item.id)
        val at = maxOf(item.at, System.currentTimeMillis() + 5_000)
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        } catch (_: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }
}

object SmsNotif {
    private const val CH = "dl_sms"
    private const val CH_INFO = "dl_sms_info"
    const val KEY_REPLY = "reply_text"

    fun channels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannels(
            listOf(
                NotificationChannel(CH, "Messages", NotificationManager.IMPORTANCE_HIGH),
                NotificationChannel(CH_INFO, "Infos messages", NotificationManager.IMPORTANCE_LOW)
            )
        )
    }

    fun idFor(address: String) = 5000 + (Prefs.norm(address).hashCode() and 0xFFFF)

    private fun post(c: Context, id: Int, n: android.app.Notification) {
        try {
            NotificationManagerCompat.from(c).notify(id, n)
        } catch (_: SecurityException) {
        }
    }

    private fun br(c: Context, action: String, address: String, req: Int, extra: (Intent) -> Unit = {}, mutable: Boolean = false): PendingIntent {
        val i = Intent(c, SmsActionReceiver::class.java).setAction(action).putExtra("address", address)
        extra(i)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                (if (mutable && Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else if (mutable) 0 else PendingIntent.FLAG_IMMUTABLE)
        return PendingIntent.getBroadcast(c, req, i, flags)
    }

    fun incoming(c: Context, address: String, body: String) {
        val name = ContactsRepo.nameFor(c, address) ?: address
        val id = idFor(address)
        val open = PendingIntent.getActivity(
            c, id, ConversationActivity.intent(c, address),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val remote = RemoteInput.Builder(KEY_REPLY).setLabel("Répondre…").build()
        val reply = NotificationCompat.Action.Builder(0, "Répondre", br(c, SmsActionReceiver.ACTION_REPLY, address, id + 1, mutable = true))
            .addRemoteInput(remote)
            .setAllowGeneratedReplies(true)
            .build()
        val b = NotificationCompat.Builder(c, CH)
            .setSmallIcon(R.drawable.ic_call)
            .setColor(0xFFFF7A00.toInt())
            .setContentTitle(name)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(open)
            .addAction(reply)
        val code = OtpDetector.find(body)
        if (code != null) {
            b.addAction(0, "Copier le code $code", br(c, SmsActionReceiver.ACTION_COPY, address, id + 2, { it.putExtra("code", code) }))
        }
        b.addAction(0, "Marquer comme lu", br(c, SmsActionReceiver.ACTION_READ, address, id + 3))
        post(c, id, b.build())
    }

    fun info(c: Context, title: String, text: String) {
        val n = NotificationCompat.Builder(c, CH_INFO)
            .setSmallIcon(R.drawable.ic_call)
            .setColor(0xFFFF7A00.toInt())
            .setContentTitle(title)
            .setContentText(text)
            .setAutoCancel(true)
            .build()
        post(c, 7000 + (title.hashCode() and 0xFF), n)
    }

    fun cancel(c: Context, address: String) = NotificationManagerCompat.from(c).cancel(idFor(address))
}

/** Réception d'un SMS (appli par défaut : SMS_DELIVER ; sinon : SMS_RECEIVED). */
open class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        Prefs.init(c)
        val isDefault = SmsRepo.isDefault(c)
        val deliver = intent.action == Telephony.Sms.Intents.SMS_DELIVER_ACTION
        if (!deliver && isDefault) return // déjà traité par SMS_DELIVER
        val msgs = runCatching { Telephony.Sms.Intents.getMessagesFromIntent(intent) }.getOrNull() ?: return
        val subId = intent.getIntExtra("subscription", -1)
        msgs.filterNotNull().groupBy { it.displayOriginatingAddress ?: "" }.forEach { (address, parts) ->
            val body = parts.joinToString("") { it.displayMessageBody ?: "" }
            val date = parts.firstOrNull()?.timestampMillis ?: System.currentTimeMillis()
            if (deliver) SmsRepo.insertIncoming(c, address, body, date, subId)
            handleMagic(c, address, body)
        }
        SmsBus.changed()
    }

    private fun handleMagic(c: Context, address: String, body: String) {
        val blocked = Prefs.isBlocked(address)
        if (blocked && Prefs.smsHideBlocked) return // bouclier : pas de notification
        val notify = SmsRepo.isDefault(c) || Prefs.smsNotif
        if (notify) SmsNotif.incoming(c, address, body)
        if (Prefs.smsAnnounce) {
            val who = ContactsRepo.nameFor(c, address) ?: "un numéro inconnu"
            MagicEffects.say(c, "Message de $who. $body")
        }
        AutoReply.maybeReply(c, address)
    }
}

class SmsReceivedReceiver : SmsReceiver()

/** Répondeur automatique : une seule réponse par numéro toutes les 30 minutes. */
object AutoReply {
    fun maybeReply(c: Context, address: String) {
        if (!Prefs.autoReply) return
        val digits = address.filter { it.isDigit() }
        if (digits.length < 8 || Prefs.isBlocked(address)) return // pas de réponse aux numéros courts (services)
        val sp = c.getSharedPreferences("dl_autoreply", Context.MODE_PRIVATE)
        val key = Prefs.norm(address)
        val last = sp.getLong(key, 0L)
        if (System.currentTimeMillis() - last < 30 * 60_000L) return
        sp.edit().putLong(key, System.currentTimeMillis()).apply()
        SmsSender.send(c, address, Prefs.autoReplyText, sign = false)
    }
}

/** Annonce d'un MMS par l'opérateur (appli SMS par défaut) : on le télécharge. */
class MmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        Prefs.init(c)
        val data = intent.getByteArrayExtra("data") ?: return
        val pending = goAsync()
        Thread {
            try {
                MmsTransport.onNotification(c, data)
            } finally {
                pending.finish()
            }
        }.start()
    }
}

/** « Répondre par message » depuis un appel entrant (Telecom). */
class RespondService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Prefs.init(this)
        val address = intent?.data?.schemeSpecificPart?.substringBefore('?')
        val text = intent?.getStringExtra(Intent.EXTRA_TEXT)
        if (!address.isNullOrBlank() && !text.isNullOrBlank()) SmsSender.send(this, address, text, sign = false)
        stopSelf(startId)
        return START_NOT_STICKY
    }
}

class SmsActionReceiver : BroadcastReceiver() {
    companion object {
        const val ACTION_SENT = "com.dlvibe.dlphone.SMS_SENT"
        const val ACTION_DELIVERED = "com.dlvibe.dlphone.SMS_DELIVERED"
        const val ACTION_REPLY = "com.dlvibe.dlphone.SMS_REPLY"
        const val ACTION_COPY = "com.dlvibe.dlphone.SMS_COPY"
        const val ACTION_READ = "com.dlvibe.dlphone.SMS_READ"
        const val ACTION_SCHEDULED = "com.dlvibe.dlphone.SMS_SCHEDULED"
    }

    override fun onReceive(c: Context, intent: Intent) {
        Prefs.init(c)
        val address = intent.getStringExtra("address") ?: ""
        when (intent.action) {
            ACTION_SENT -> {
                val uri = intent.getStringExtra("uri")?.let { Uri.parse(it) }
                val ok = resultCode == Activity.RESULT_OK
                if (uri != null && (intent.getBooleanExtra("last", true) || !ok)) {
                    SmsRepo.update(c, uri, ContentValues().apply {
                        put(Telephony.Sms.TYPE, if (ok) Telephony.Sms.MESSAGE_TYPE_SENT else Telephony.Sms.MESSAGE_TYPE_FAILED)
                    })
                }
                if (!ok) Toast.makeText(c, "Échec de l'envoi du SMS", Toast.LENGTH_SHORT).show()
                SmsBus.changed()
            }

            ACTION_DELIVERED -> {
                val uri = intent.getStringExtra("uri")?.let { Uri.parse(it) }
                if (uri != null) {
                    SmsRepo.update(c, uri, ContentValues().apply { put(Telephony.Sms.STATUS, Telephony.Sms.STATUS_COMPLETE) })
                }
                SmsBus.changed()
            }

            ACTION_REPLY -> {
                val text = RemoteInput.getResultsFromIntent(intent)?.getCharSequence(SmsNotif.KEY_REPLY)?.toString()
                if (!text.isNullOrBlank() && address.isNotBlank()) {
                    SmsSender.send(c, address, text)
                    SmsRepo.markRead(c, address)
                }
                SmsNotif.cancel(c, address)
            }

            ACTION_COPY -> {
                val code = intent.getStringExtra("code") ?: return
                c.getSystemService(ClipboardManager::class.java)?.setPrimaryClip(ClipData.newPlainText("Code", code))
                Toast.makeText(c, "Code $code copié", Toast.LENGTH_SHORT).show()
                SmsRepo.markRead(c, address)
                SmsNotif.cancel(c, address)
            }

            ACTION_READ -> {
                SmsRepo.markRead(c, address)
                SmsNotif.cancel(c, address)
                SmsBus.changed()
            }

            ACTION_SCHEDULED -> Scheduled.fire(c, intent.getLongExtra("id", 0L))
            MmsTransport.ACTION_SENT -> MmsTransport.onSent(c, intent, resultCode)
            MmsTransport.ACTION_DOWNLOADED -> {
                val code = resultCode
                val pending = goAsync()
                Thread {
                    try {
                        MmsTransport.onDownloaded(c, intent, code)
                    } finally {
                        pending.finish()
                    }
                }.start()
            }
        }
    }
}

/** Remet les messages programmés après un redémarrage. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            Prefs.init(c)
            Scheduled.rearmAll(c)
        }
    }
}
