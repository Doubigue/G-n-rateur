package com.dlvibe.dlphone

import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.TelecomManager
import android.telecom.VideoProfile
import android.widget.Toast
import kotlinx.coroutines.flow.MutableStateFlow

/** État partagé des appels en cours, observé par l'écran d'appel. */
object CallManager {
    val calls = MutableStateFlow<List<Call>>(emptyList())
    val tick = MutableStateFlow(0)
    val audio = MutableStateFlow<CallAudioState?>(null)

    @Volatile
    var service: DlInCallService? = null

    val incoming = HashSet<Call>()
    val answered = HashSet<Call>()

    @Suppress("DEPRECATION")
    fun stateOf(call: Call): Int =
        if (Build.VERSION.SDK_INT >= 31) call.details.state else call.state

    fun numberOf(call: Call): String = call.details?.handle?.schemeSpecificPart ?: ""

    fun ringing(): Call? = calls.value.firstOrNull { stateOf(it) == Call.STATE_RINGING }

    fun primary(): Call? {
        val l = calls.value
        return l.firstOrNull { stateOf(it) == Call.STATE_RINGING }
            ?: l.firstOrNull {
                val s = stateOf(it)
                s != Call.STATE_HOLDING && s != Call.STATE_DISCONNECTED
            }
            ?: l.firstOrNull()
    }

    fun add(c: Call) {
        calls.value = calls.value + c
        changed()
    }

    fun remove(c: Call) {
        calls.value = calls.value - c
        answered.remove(c)
        incoming.remove(c)
        changed()
    }

    fun changed() {
        tick.value = tick.value + 1
    }

    fun answer() {
        ringing()?.answer(VideoProfile.STATE_AUDIO_ONLY)
    }
}

object Phone {
    fun call(ctx: Context, number: String) {
        if (number.isBlank()) return
        val uri = if (number == "voicemail") Uri.fromParts("voicemail", "", null)
        else Uri.fromParts("tel", number, null)
        try {
            ctx.getSystemService(TelecomManager::class.java).placeCall(uri, Bundle())
        } catch (e: Exception) {
            Toast.makeText(ctx, "Impossible d'appeler : ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
