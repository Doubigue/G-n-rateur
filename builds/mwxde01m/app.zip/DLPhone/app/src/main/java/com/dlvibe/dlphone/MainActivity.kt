package com.dlvibe.dlphone

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Telephony
import android.telecom.TelecomManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import com.dlvibe.dlphone.ui.DlTheme
import com.dlvibe.dlphone.ui.MainScreen

class MainActivity : ComponentActivity() {
    companion object {
        const val EXTRA_CALL = "call_number"
        const val EXTRA_TAB = "tab"
    }

    private val refresh = mutableIntStateOf(0)
    private val prefill = mutableStateOf("")
    private val navKey = mutableIntStateOf(0)
    private val startTab = mutableIntStateOf(0)
    private val isDefault = mutableStateOf(false)
    private var pendingCall: String? = null

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh.intValue++ }

    private val roleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            checkDefault()
            askPermissions()
        }

    private val callPermLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            val n = pendingCall
            pendingCall = null
            if (ok && n != null) Phone.call(this, n)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        enableEdgeToEdge()
        checkDefault()
        if (!isDefault.value && !Prefs.askedDefault) {
            Prefs.askedDefault = true
            requestDefaultDialer()
        } else {
            askPermissions()
        }
        handleIntent(intent)
        setContent {
            DlTheme {
                MainScreen(
                    refreshKey = refresh.intValue,
                    prefill = prefill.value,
                    navKey = navKey.intValue,
                    startTab = startTab.intValue,
                    isDefault = isDefault.value,
                    onCall = ::call,
                    onRequestDefault = ::requestDefaultDialer,
                    onRequestScreening = ::requestScreening,
                    onRequestSmsDefault = ::requestSmsDefault,
                    onRefresh = { refresh.intValue++ }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        checkDefault()
        PhotoLoader.clearMisses()
        refresh.intValue++
    }

    private fun handleIntent(i: Intent?) {
        if (i == null) return
        val n = i.getStringExtra(EXTRA_CALL)
        if (!n.isNullOrBlank()) {
            i.removeExtra(EXTRA_CALL)
            call(n)
            return
        }
        val tab = i.getIntExtra(EXTRA_TAB, -1)
        if (tab >= 0) {
            startTab.intValue = tab
            navKey.intValue++
        }
        if ((i.action == Intent.ACTION_DIAL || i.action == Intent.ACTION_VIEW) && i.data?.scheme == "tel") {
            prefill.value = i.data?.schemeSpecificPart ?: ""
            startTab.intValue = 0
            navKey.intValue++
        }
    }

    private fun call(number: String) {
        if (ContactsRepo.granted(this, Manifest.permission.CALL_PHONE)) {
            Phone.call(this, number)
        } else {
            pendingCall = number
            callPermLauncher.launch(Manifest.permission.CALL_PHONE)
        }
    }

    private fun askPermissions() {
        val wanted = mutableListOf(
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_SMS,
            Manifest.permission.SEND_SMS,
            Manifest.permission.RECEIVE_SMS
        )
        if (Build.VERSION.SDK_INT >= 33) wanted += Manifest.permission.POST_NOTIFICATIONS
        val missing = wanted.filter { !ContactsRepo.granted(this, it) }
        if (missing.isNotEmpty()) permLauncher.launch(missing.toTypedArray())
    }

    private fun checkDefault() {
        isDefault.value = try {
            getSystemService(TelecomManager::class.java)?.defaultDialerPackage == packageName
        } catch (_: Exception) {
            false
        }
    }

    private fun requestDefaultDialer() {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val rm = getSystemService(RoleManager::class.java)
                if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_DIALER) && !rm.isRoleHeld(RoleManager.ROLE_DIALER)) {
                    roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER))
                    return
                }
            } else {
                roleLauncher.launch(
                    Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER)
                        .putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, packageName)
                )
                return
            }
        } catch (_: Exception) {
        }
        askPermissions()
    }

    private fun requestSmsDefault() {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val rm = getSystemService(RoleManager::class.java) ?: return
                if (rm.isRoleAvailable(RoleManager.ROLE_SMS) && !rm.isRoleHeld(RoleManager.ROLE_SMS)) {
                    roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_SMS))
                }
            } else {
                roleLauncher.launch(
                    Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
                        .putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, packageName)
                )
            }
        } catch (_: Exception) {
        }
    }

    private fun requestScreening() {
        if (Build.VERSION.SDK_INT >= 29) {
            val rm = getSystemService(RoleManager::class.java) ?: return
            if (rm.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING) && !rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)) {
                roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING))
            }
        }
    }
}
