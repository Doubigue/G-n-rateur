package com.dlvibe.dlphone

import android.media.AudioManager
import android.media.ToneGenerator
import android.telecom.Call
import com.dlvibe.dlphone.ui.toneFor
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Envoie les chiffres un par un, chacun avec une durée complète suivie d'un silence. */
object Dtmf {
    private val queue = Channel<Pair<Call, Char>>(Channel.UNLIMITED)
    private val tone by lazy {
        runCatching { ToneGenerator(AudioManager.STREAM_DTMF, 70) }.getOrNull()
    }

    init {
        MainScope().launch {
            for ((call, digit) in queue) {
                if (CallManager.stateOf(call) == Call.STATE_DISCONNECTED) continue
                runCatching { tone?.startTone(toneFor(digit), 200) } // retour sonore local
                runCatching { call.playDtmfTone(digit) }
                delay(250)
                runCatching { call.stopDtmfTone() }
                delay(120) // le serveur vocal doit distinguer deux chiffres
            }
        }
    }

    fun send(call: Call, digit: Char) {
        queue.trySend(call to digit)
    }
}
