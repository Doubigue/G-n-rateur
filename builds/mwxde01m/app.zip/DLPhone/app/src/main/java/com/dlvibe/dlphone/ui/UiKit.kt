@file:OptIn(ExperimentalFoundationApi::class)

package com.dlvibe.dlphone.ui

import android.app.Activity
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.view.Surface
import android.view.TextureView
import androidx.compose.foundation.Image
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.viewinterop.AndroidView
import com.dlvibe.dlphone.PhotoLoader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat

/** Palettes DL VIBE STUDIO (9 styles affiche). */
data class DlPalette(
    val name: String,
    val light: Boolean,
    val accent: Color,
    val onAccent: Color,
    val bg: Color,
    val bg2: Color,
    val cardTop: Color,
    val card: Color,
    val surface2: Color,
    val sheet: Color,
    val text: Color,
    val muted: Color,
    val pill: Color,
    val line: Color,
    val accent2: Color
)

val Palettes = listOf(
    DlPalette("Orange Studio", false, Color(0xFFFF7A00), Color(0xFFFFFFFF), Color(0xFF0A0A0A), Color(0xFF151515), Color(0xFF1E1E1E), Color(0xFF141414), Color(0xFF282828), Color(0xFF121212), Color(0xFFF5F5F5), Color(0xFFA8A8A8), Color(0xFFF2F2F2), Color(0x29FF7A00), Color(0xFFBDBDBD)),
    DlPalette("Mamba", false, Color(0xFFE9F23A), Color(0xFF2E3009), Color(0xFF0F3D27), Color(0xFF1B5E3A), Color(0xFF15452D), Color(0xFF0B2E1D), Color(0xFF1D5236), Color(0xFF0D3321), Color(0xFFF1F7F2), Color(0xFFA3C2AE), Color(0xFFE9F23A), Color(0x26E9F23A), Color(0xFFFFFFFF)),
    DlPalette("Émeraude", false, Color(0xFFF5A623), Color(0xFF312108), Color(0xFF0D5446), Color(0xFF093E33), Color(0xFF0F4D40), Color(0xFF0A3B31), Color(0xFF15604F), Color(0xFF0B4639), Color(0xFFF2FBF8), Color(0xFF9CC7BB), Color(0xFFF2F2F2), Color(0x21FFFFFF), Color(0xFFFFFFFF)),
    DlPalette("Festin", false, Color(0xFFFFC72C), Color(0xFF332809), Color(0xFF7A1A0E), Color(0xFFB8321A), Color(0xFF7E2012), Color(0xFF5E130A), Color(0xFF8F2A17), Color(0xFF66150B), Color(0xFFFFF4EC), Color(0xFFE8B8A8), Color(0xFFFFC72C), Color(0x26FFC72C), Color(0xFF2E9E4F)),
    DlPalette("Crépuscule", true, Color(0xFF1E7B3C), Color(0xFFFFFFFF), Color(0xFFFFA726), Color(0xFFFFD54F), Color(0xFFFFFAEE), Color(0xFFFFF3DC), Color(0xFFFFE3B0), Color(0xFFFFF5E2), Color(0xFF2B1A07), Color(0xFF6E4F24), Color(0xFFFFFFFF), Color(0x1F000000), Color(0xFFC62828)),
    DlPalette("Portfolio", true, Color(0xFFE8590C), Color(0xFFFFFFFF), Color(0xFFFFF8EF), Color(0xFFFFEEDD), Color(0xFFFFFFFF), Color(0xFFFFFFFF), Color(0xFFF6E6D3), Color(0xFFFFFFFF), Color(0xFF3A0E05), Color(0xFF7D5A4A), Color(0xFFF6E6D3), Color(0x1A3A0E05), Color(0xFFC2410C)),
    DlPalette("Losanges", false, Color(0xFFA9DCF5), Color(0xFF1B2B33), Color(0xFF223D52), Color(0xFF152A3A), Color(0xFF22405A), Color(0xFF182E3F), Color(0xFF2A4A63), Color(0xFF1A3245), Color(0xFFEAF5FC), Color(0xFF9DB6C8), Color(0xFFD6EEFA), Color(0x26A9DCF5), Color(0xFFFFFFFF)),
    DlPalette("Cramoisi", false, Color(0xFFFF3B5C), Color(0xFFFFFFFF), Color(0xFF3A0B16), Color(0xFF1C050B), Color(0xFF451020), Color(0xFF2A0710), Color(0xFF551629), Color(0xFF330A14), Color(0xFFFFEEF1), Color(0xFFD199A6), Color(0xFFF6D3DA), Color(0x26FF3B5C), Color(0xFF1ED760)),
    DlPalette("Black Friday", false, Color(0xFFA6E22E), Color(0xFF212D09), Color(0xFF0E0F0D), Color(0xFF1A1C18), Color(0xFF1E211B), Color(0xFF151713), Color(0xFF262A22), Color(0xFF121410), Color(0xFFF4F7EE), Color(0xFFA4AA98), Color(0xFFA6E22E), Color(0x29A6E22E), Color(0xFFFFFFFF)),
    SimpleLight
)

/** Index du style « Simple » (couleurs sobres, suit le mode clair/sombre du téléphone). */
const val SIMPLE_STYLE = 9
const val DECORATED_STYLES = 9

/** Style simple clair : fond blanc, aucun dégradé, accent bleu. */
val SimpleLight: DlPalette
    get() = DlPalette("Simple", true, Color(0xFF1A73E8), Color(0xFFFFFFFF), Color(0xFFFFFFFF), Color(0xFFFFFFFF), Color(0xFFF4F5F7), Color(0xFFF4F5F7), Color(0xFFECEEF1), Color(0xFFFFFFFF), Color(0xFF1C1C1E), Color(0xFF5F6368), Color(0xFFECEEF1), Color(0x1F000000), Color(0xFF1A73E8))

/** Style simple sombre : fond gris très foncé, aucun dégradé. */
val SimpleDark: DlPalette
    get() = DlPalette("Simple", false, Color(0xFF8AB4F8), Color(0xFF0B1B33), Color(0xFF121212), Color(0xFF121212), Color(0xFF1E1E1E), Color(0xFF1E1E1E), Color(0xFF2A2A2A), Color(0xFF181818), Color(0xFFECECEC), Color(0xFFA0A0A0), Color(0xFF2A2A2A), Color(0x22FFFFFF), Color(0xFF8AB4F8))

val AnswerGreen = Color(0xFF1FB45A)
val HangupRed = Color(0xFFE5484D)
private val AvatarColors = listOf(
    Color(0xFF81C995), Color(0xFFFF8BCB), Color(0xFFF28B82), Color(0xFFC58AF9),
    Color(0xFFFDD663), Color(0xFF78D9EC), Color(0xFFFCAD70)
)

object ThemeState {
    var index by mutableIntStateOf(0)
}

val LocalPalette = staticCompositionLocalOf { Palettes[0] }

@Composable
fun DlTheme(content: @Composable () -> Unit) {
    val idx = ThemeState.index.coerceIn(0, Palettes.size - 1)
    val p = if (idx == SIMPLE_STYLE) (if (isSystemInDarkTheme()) SimpleDark else SimpleLight) else Palettes[idx]
    val scheme = if (p.light) lightColorScheme(
        primary = p.accent, onPrimary = p.onAccent, secondary = p.accent2,
        background = p.bg, onBackground = p.text, surface = p.sheet, onSurface = p.text,
        surfaceVariant = p.surface2, onSurfaceVariant = p.muted, outline = p.line
    ) else darkColorScheme(
        primary = p.accent, onPrimary = p.onAccent, secondary = p.accent2,
        background = p.bg, onBackground = p.text, surface = p.sheet, onSurface = p.text,
        surfaceVariant = p.surface2, onSurfaceVariant = p.muted, outline = p.line
    )
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val w = (view.context as? Activity)?.window ?: return@SideEffect
            WindowCompat.getInsetsController(w, view).apply {
                isAppearanceLightStatusBars = p.light
                isAppearanceLightNavigationBars = p.light
            }
        }
    }
    CompositionLocalProvider(LocalPalette provides p) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

fun bgBrush(p: DlPalette) = Brush.verticalGradient(listOf(p.bg, p.bg2))

@Composable
fun DlCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val p = LocalPalette.current
    val shape = RoundedCornerShape(22.dp)
    Column(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.verticalGradient(listOf(p.cardTop, p.card)))
            .border(1.dp, p.line, shape)
            .padding(16.dp),
        content = content
    )
}

fun initials(name: String): String {
    val words = name.trim().split(Regex("\\s+")).filter { it.isNotEmpty() && it[0].isLetter() }
    if (words.isEmpty()) return "#"
    return words.take(2).joinToString("") { it.take(1).uppercase() }
}

@Composable
fun Avatar(name: String, size: Dp = 44.dp, photo: String? = null, number: String? = null, lookup: Boolean = false) {
    val p = LocalPalette.current
    val ctx = LocalContext.current
    val px = with(LocalDensity.current) { size.roundToPx() }
    val wants = photo != null || !number.isNullOrBlank()
    val version = PhotoLoader.version
    val img by produceState(
        if (wants) PhotoLoader.cached(PhotoLoader.key(number, photo, px, lookup)) else null,
        number, photo, px, lookup, version
    ) {
        value = if (wants) withContext(Dispatchers.IO) { PhotoLoader.load(ctx, number, photo, px, lookup) } else null
    }
    val bmp = img
    if (bmp != null) {
        Image(
            bmp, null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(size)
                .clip(CircleShape)
        )
    } else {
        AvatarInitials(name, size, p)
    }
}

@Composable
private fun AvatarInitials(name: String, size: Dp, p: DlPalette) {
    val base = AvatarColors[(name.hashCode() and 0x7fffffff) % AvatarColors.size]
    val c = if (p.light) lerp(base, Color.Black, 0.35f) else base
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(Brush.verticalGradient(listOf(c.copy(alpha = 0.34f), c.copy(alpha = 0.12f)))),
        contentAlignment = Alignment.Center
    ) {
        Text(initials(name), color = c, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.38f).sp)
    }
}

/** Vidéo en boucle, plein cadre (recadrée), sans son. */
@Composable
fun LoopingVideo(path: String, modifier: Modifier = Modifier, muted: Boolean = true) {
    key(path) {
        val player = remember { MediaPlayer() }
        DisposableEffect(Unit) {
            onDispose {
                runCatching { player.stop() }
                runCatching { player.release() }
            }
        }
        AndroidView(modifier = modifier, factory = { c ->
            TextureView(c).apply {
                val tv = this
                surfaceTextureListener = object : TextureView.SurfaceTextureListener {
                    override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                        try {
                            player.setDataSource(path)
                            player.setSurface(Surface(st))
                            player.isLooping = true
                            if (muted) player.setVolume(0f, 0f)
                            player.setOnVideoSizeChangedListener { _, vw, vh -> cropCenter(tv, vw, vh) }
                            player.setOnPreparedListener { it.start() }
                            player.prepareAsync()
                        } catch (_: Exception) {
                        }
                    }

                    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {
                        runCatching { cropCenter(tv, player.videoWidth, player.videoHeight) }
                    }

                    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean = true
                    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
                }
            }
        })
    }
}

private fun cropCenter(tv: TextureView, vw: Int, vh: Int) {
    if (vw <= 0 || vh <= 0 || tv.width == 0 || tv.height == 0) return
    val w = tv.width.toFloat()
    val h = tv.height.toFloat()
    val scale = maxOf(w / vw, h / vh)
    val m = Matrix()
    m.setScale(vw * scale / w, vh * scale / h, w / 2f, h / 2f)
    tv.setTransform(m)
}

@Composable
fun IconPill(icon: ImageVector, tint: Color, size: Dp = 40.dp) {
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(Brush.verticalGradient(listOf(tint.copy(alpha = 0.34f), tint.copy(alpha = 0.12f)))),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = tint, modifier = Modifier.size(size * 0.55f)) }
}

@Composable
fun ScreenHeader(title: String, subtitle: String? = null, action: @Composable () -> Unit = {}) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .padding(start = 20.dp, end = 12.dp, top = 12.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = p.text, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Box(
                Modifier
                    .padding(top = 4.dp)
                    .size(width = 28.dp, height = 3.dp)
                    .clip(CircleShape)
                    .background(p.accent)
            )
            if (subtitle != null) Text(subtitle, color = p.muted, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
        }
        action()
    }
}

@Composable
fun ListRow(
    title: String,
    leading: @Composable () -> Unit,
    subtitle: @Composable () -> Unit = {},
    trailing: @Composable () -> Unit = {},
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null
) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 16.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        leading()
        Column(
            Modifier
                .weight(1f)
                .padding(start = 14.dp)
        ) {
            Text(title, color = p.text, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            subtitle()
        }
        trailing()
    }
}

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    val p = LocalPalette.current
    Text(text, color = p.accent, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = modifier.padding(vertical = 6.dp))
}

@Composable
fun Signature() {
    val p = LocalPalette.current
    Column(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .size(width = 24.dp, height = 2.dp)
                .background(p.accent)
        )
        Spacer(Modifier.height(8.dp))
        Text("Created by DL VIBE STUDIO · Doubigue Loubikoa", color = p.text, fontSize = 12.sp)
    }
}

@Composable
fun dlTextFieldColors(): TextFieldColors {
    val p = LocalPalette.current
    return OutlinedTextFieldDefaults.colors(
        focusedBorderColor = p.accent, unfocusedBorderColor = p.line,
        focusedContainerColor = p.surface2, unfocusedContainerColor = p.surface2,
        focusedTextColor = p.text, unfocusedTextColor = p.text, cursorColor = p.accent,
        focusedPlaceholderColor = p.muted, unfocusedPlaceholderColor = p.muted,
        focusedLeadingIconColor = p.accent, unfocusedLeadingIconColor = p.muted
    )
}
