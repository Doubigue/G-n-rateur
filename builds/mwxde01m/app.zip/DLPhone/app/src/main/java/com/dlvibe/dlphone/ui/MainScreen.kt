@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.dlvibe.dlphone.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.Dialpad
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dlvibe.dlphone.CallEntry
import com.dlvibe.dlphone.Contact
import com.dlvibe.dlphone.ContactsRepo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun MainScreen(
    refreshKey: Int,
    prefill: String,
    navKey: Int,
    startTab: Int,
    isDefault: Boolean,
    onCall: (String) -> Unit,
    onRequestDefault: () -> Unit,
    onRequestScreening: () -> Unit,
    onRequestSmsDefault: () -> Unit,
    onRefresh: () -> Unit
) {
    val ctx = LocalContext.current
    val p = LocalPalette.current
    var tab by remember { mutableIntStateOf(0) }
    LaunchedEffect(navKey) { if (navKey > 0) tab = if (startTab == 1) 0 else startTab }

    var contacts by remember { mutableStateOf<List<Contact>>(emptyList()) }
    var calls by remember { mutableStateOf<List<CallEntry>>(emptyList()) }
    LaunchedEffect(refreshKey) {
        val r = withContext(Dispatchers.IO) { ContactsRepo.contacts(ctx) to ContactsRepo.calls(ctx) }
        contacts = r.first
        calls = r.second
        withContext(Dispatchers.IO) { com.dlvibe.dlphone.Shortcuts.update(ctx, r.second) }
    }

    val smsTick by com.dlvibe.dlphone.sms.SmsBus.tick.collectAsState()
    val smsObs = rememberSmsObserverTick()
    var unreadSms by remember { mutableIntStateOf(0) }
    LaunchedEffect(refreshKey, smsTick, smsObs) {
        unreadSms = withContext(Dispatchers.IO) { com.dlvibe.dlphone.sms.SmsRepo.unreadCount(ctx) }
    }
    val tabs = listOf(
        Triple("Clavier", Icons.Filled.Dialpad, 0),
        Triple("Contacts", Icons.Filled.Contacts, 2),
        Triple("Messages", Icons.Filled.Sms, 3),
        Triple("Réglages", Icons.Filled.Settings, 4)
    )

    Box(
        Modifier
            .fillMaxSize()
            .background(bgBrush(p))
    ) {
        Scaffold(
            containerColor = Color.Transparent,
            bottomBar = {
                NavigationBar(containerColor = p.sheet, tonalElevation = 0.dp) {
                    tabs.forEach { (label, icon, i) ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = {
                                if (i == 3 && unreadSms > 0) {
                                    BadgedBox(badge = { Badge(containerColor = HangupRed) { Text("$unreadSms") } }) { Icon(icon, label) }
                                } else Icon(icon, label)
                            },
                            label = { Text(label, fontSize = 11.sp, maxLines = 1) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = p.onAccent,
                                indicatorColor = p.accent,
                                selectedTextColor = p.accent,
                                unselectedIconColor = p.muted,
                                unselectedTextColor = p.muted
                            )
                        )
                    }
                }
            }
        ) { pad ->
            Column(
                Modifier
                    .padding(pad)
                    .fillMaxSize()
            ) {
                when (tab) {
                    0 -> DialerScreen(
                        contacts = contacts,
                        prefill = prefill,
                        navKey = navKey,
                        calls = calls,
                        lastNumber = calls.firstOrNull { it.type == android.provider.CallLog.Calls.OUTGOING_TYPE }?.number,
                        onCall = onCall
                    )

                    1, 2 -> ContactsScreen(contacts, onCall, onRefresh)
                    3 -> MessagesScreen(refreshKey)
                    else -> MagicScreen(calls, refreshKey, isDefault, onRequestDefault, onRequestSmsDefault, onRequestScreening)
                }
            }
        }
    }
}
