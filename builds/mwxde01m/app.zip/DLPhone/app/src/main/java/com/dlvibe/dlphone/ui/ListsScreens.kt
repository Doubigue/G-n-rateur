@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.dlvibe.dlphone.ui

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.provider.CallLog
import android.provider.ContactsContract
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallMade
import androidx.compose.material.icons.filled.CallMissed
import androidx.compose.material.icons.filled.CallReceived
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Voicemail
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dlvibe.dlphone.CallEntry
import com.dlvibe.dlphone.Contact
import com.dlvibe.dlphone.Prefs
import com.dlvibe.dlphone.T9
import com.dlvibe.dlphone.ThemeEditorActivity
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val FR = Locale.FRENCH

fun dayLabel(t: Long): String {
    val c = Calendar.getInstance().apply { timeInMillis = t }
    val now = Calendar.getInstance()
    fun same(a: Calendar, b: Calendar) =
        a.get(Calendar.YEAR) == b.get(Calendar.YEAR) && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)
    if (same(c, now)) return "Aujourd'hui"
    now.add(Calendar.DAY_OF_YEAR, -1)
    if (same(c, now)) return "Hier"
    return SimpleDateFormat("EEEE d MMMM", FR).format(Date(t)).replaceFirstChar { it.uppercase() }
}

fun hourLabel(t: Long): String = SimpleDateFormat("HH:mm", FR).format(Date(t))

fun durationLabel(s: Long): String = when {
    s <= 0 -> ""
    s < 60 -> "$s s"
    s < 3600 -> "${s / 60} min ${"%02d".format(s % 60)} s"
    else -> "${s / 3600} h ${"%02d".format((s % 3600) / 60)} min"
}

private fun typeColor(type: Int, light: Boolean): Color {
    val c = when (type) {
        CallLog.Calls.MISSED_TYPE, CallLog.Calls.REJECTED_TYPE -> Color(0xFFF28B82)
        CallLog.Calls.INCOMING_TYPE -> Color(0xFF81C995)
        CallLog.Calls.OUTGOING_TYPE -> Color(0xFF78D9EC)
        else -> Color(0xFFFDD663)
    }
    return if (light) lerp(c, Color.Black, 0.35f) else c
}

private fun typeIcon(type: Int) = when (type) {
    CallLog.Calls.MISSED_TYPE, CallLog.Calls.REJECTED_TYPE -> Icons.Filled.CallMissed
    CallLog.Calls.INCOMING_TYPE -> Icons.Filled.CallReceived
    CallLog.Calls.OUTGOING_TYPE -> Icons.Filled.CallMade
    CallLog.Calls.VOICEMAIL_TYPE -> Icons.Filled.Voicemail
    else -> Icons.Filled.Block
}

fun safeStart(ctx: Context, i: Intent) {
    try {
        ctx.startActivity(i)
    } catch (_: Exception) {
        Toast.makeText(ctx, "Aucune appli pour cette action", Toast.LENGTH_SHORT).show()
    }
}

@Composable
fun RecentsScreen(calls: List<CallEntry>, onCall: (String) -> Unit, onChanged: () -> Unit) {
    val p = LocalPalette.current
    var filter by remember { mutableIntStateOf(0) }
    val labels = listOf("Tous", "Manqués", "Entrants", "Sortants", "Bloqués")
    val groups = remember(calls, filter) {
        calls.filter {
            when (filter) {
                1 -> it.type == CallLog.Calls.MISSED_TYPE || it.type == CallLog.Calls.REJECTED_TYPE
                2 -> it.type == CallLog.Calls.INCOMING_TYPE
                3 -> it.type == CallLog.Calls.OUTGOING_TYPE
                4 -> it.type == CallLog.Calls.BLOCKED_TYPE
                else -> true
            }
        }.groupBy { dayLabel(it.date) }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Récents", "${calls.size} appels dans le journal")
        Row(
            Modifier
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            labels.forEachIndexed { i, l ->
                FilterChip(
                    selected = filter == i,
                    onClick = { filter = i },
                    label = { Text(l) },
                    colors = FilterChipDefaults.filterChipColors(
                        containerColor = p.surface2, labelColor = p.text,
                        selectedContainerColor = p.accent, selectedLabelColor = p.onAccent
                    )
                )
            }
        }
        if (groups.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Aucun appel ici pour l'instant", color = p.muted)
            }
        } else {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
                groups.forEach { (label, list) ->
                    item(key = "h_$label") {
                        SectionLabel(label, Modifier.padding(start = 20.dp, top = 10.dp))
                    }
                    items(list, key = { it.id }) { e -> RecentRow(e, onCall, onChanged) }
                }
            }
        }
    }
}

@Composable
private fun RecentRow(e: CallEntry, onCall: (String) -> Unit, onChanged: () -> Unit) {
    val ctx = LocalContext.current
    val p = LocalPalette.current
    val clipboard = LocalClipboardManager.current
    var menu by remember { mutableStateOf(false) }
    val title = e.name ?: e.number.ifBlank { "Numéro masqué" }
    val tc = typeColor(e.type, p.light)
    Box {
        ListRow(
            title = title,
            leading = { Avatar(title, 44.dp, photo = e.photo, number = e.number) },
            subtitle = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(typeIcon(e.type), null, tint = tc, modifier = Modifier.size(14.dp))
                    val d = durationLabel(e.duration)
                    Text(
                        " " + hourLabel(e.date) + (if (d.isNotEmpty()) " · $d" else "") +
                                (if (e.name != null) " · ${e.number}" else ""),
                        color = p.muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
            },
            trailing = {
                if (e.number.isNotBlank()) IconButton(onClick = { onCall(e.number) }) {
                    Icon(Icons.Filled.Call, "Appeler", tint = p.accent)
                }
            },
            onClick = { if (e.number.isNotBlank()) onCall(e.number) },
            onLongClick = { if (e.number.isNotBlank()) menu = true }
        )
        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
            val blocked = Prefs.isBlocked(e.number)
            DropdownMenuItem(text = { Text("Personnaliser l'appel") }, onClick = {
                menu = false
                ThemeEditorActivity.open(ctx, e.number, e.name)
            })
            DropdownMenuItem(text = { Text("Envoyer un SMS") }, onClick = {
                menu = false
                safeStart(ctx, Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${e.number}")))
            })
            DropdownMenuItem(text = { Text("Copier le numéro") }, onClick = {
                menu = false
                clipboard.setText(AnnotatedString(e.number))
            })
            DropdownMenuItem(text = { Text(if (blocked) "Débloquer" else "Bloquer ce numéro") }, onClick = {
                menu = false
                if (blocked) Prefs.unblock(e.number) else Prefs.block(e.number)
                Toast.makeText(ctx, if (blocked) "Numéro débloqué" else "Numéro bloqué", Toast.LENGTH_SHORT).show()
                onChanged()
            })
            if (e.name == null) DropdownMenuItem(text = { Text("Ajouter aux contacts") }, onClick = {
                menu = false
                safeStart(ctx, Intent(Intent.ACTION_INSERT, ContactsContract.Contacts.CONTENT_URI)
                    .putExtra(ContactsContract.Intents.Insert.PHONE, e.number))
            })
        }
    }
}

private fun writeContactsPdf(context: Context, uri: Uri, contacts: List<Contact>) {
    val pdf = PdfDocument()
    val pageWidth = 595
    val pageHeight = 842
    val ink = android.graphics.Color.rgb(24, 29, 39)
    val muted = android.graphics.Color.rgb(111, 119, 132)
    val orange = android.graphics.Color.rgb(245, 132, 31)
    val pale = android.graphics.Color.rgb(255, 246, 237)
    val border = android.graphics.Color.rgb(231, 234, 239)
    val white = android.graphics.Color.WHITE
    fun paint(color: Int, size: Float, bold: Boolean = false, align: Paint.Align = Paint.Align.LEFT) =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color; textSize = size; textAlign = align
            typeface = Typeface.create("sans-serif", if (bold) Typeface.BOLD else Typeface.NORMAL)
        }
    val brand = paint(white, 25f, true)
    val kicker = paint(android.graphics.Color.rgb(255, 218, 184), 9f, true)
    val title = paint(ink, 17f, true)
    val subtitle = paint(muted, 9f)
    val namePaint = paint(ink, 11.5f, true)
    val numberPaint = paint(android.graphics.Color.rgb(76, 85, 99), 10f)
    val small = paint(muted, 8f)
    val badgeText = paint(white, 8f, true, Paint.Align.CENTER)
    val rows = contacts.distinctBy { "${it.id}:${it.number}" }
        .filter { it.number.isNotBlank() }
        .sortedBy { it.name.lowercase(Locale.ROOT) }
    val pageRows = 10
    val totalPages = maxOf(1, (rows.size + pageRows - 1) / pageRows)
    val dateText = java.text.SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(java.util.Date())

    for (pageIndex in 0 until totalPages) {
        val pageNo = pageIndex + 1
        val page = pdf.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNo).create())
        val c = page.canvas
        c.drawColor(white)
        // Premium dark masthead and orange brand stripe
        c.drawRect(0f, 0f, pageWidth.toFloat(), 174f, paint(ink, 1f))
        c.drawRect(0f, 0f, pageWidth.toFloat(), 7f, paint(orange, 1f))
        c.drawCircle(55f, 57f, 20f, paint(orange, 1f))
        c.drawText("D", 55f, 64f, paint(white, 20f, true, Paint.Align.CENTER))
        c.drawText("DLPHONE", 88f, 52f, brand)
        c.drawText("RÉPERTOIRE PERSONNEL", 89f, 72f, kicker)
        c.drawText("Vos contacts,", 38f, 119f, paint(white, 23f, true))
        c.drawText("toujours à portée de main.", 38f, 145f, paint(android.graphics.Color.rgb(211, 216, 225), 12f))
        // Summary capsule
        c.drawRoundRect(420f, 106f, 557f, 151f, 12f, 12f, paint(android.graphics.Color.rgb(46, 53, 66), 1f))
        c.drawText("${rows.size}", 438f, 128f, paint(white, 17f, true))
        c.drawText("NUMÉROS", 438f, 141f, kicker)

        c.drawText("ANNUAIRE DES CONTACTS", 38f, 207f, title)
        c.drawText("Exporté le $dateText", 557f, 207f, paint(muted, 9f, false, Paint.Align.RIGHT))
        c.drawLine(38f, 222f, 557f, 222f, paint(border, 1f))
        c.drawText("CONTACT", 62f, 246f, paint(muted, 8f, true))
        c.drawText("NUMÉRO DE TÉLÉPHONE", 340f, 246f, paint(muted, 8f, true))
        c.drawText("N°", 548f, 246f, paint(muted, 8f, true, Paint.Align.RIGHT))

        val start = pageIndex * pageRows
        val end = minOf(rows.size, start + pageRows)
        var y = 260f
        for (i in start until end) {
            val contact = rows[i]
            val bottom = y + 48f
            if ((i - start) % 2 == 0) c.drawRoundRect(38f, y, 557f, bottom, 9f, 9f, paint(android.graphics.Color.rgb(248, 249, 251), 1f))
            val initials = contact.name.trim().split(Regex("\\s+")).take(2)
                .mapNotNull { it.firstOrNull()?.uppercaseChar() }.joinToString("")
            c.drawCircle(59f, y + 24f, 13f, paint(pale, 1f))
            c.drawText(initials.ifBlank { "?" }, 59f, y + 27f, paint(orange, 9f, true, Paint.Align.CENTER))
            c.drawText(contact.name.ifBlank { "Contact sans nom" }.take(34), 83f, y + 21f, namePaint)
            c.drawText(contact.number.take(28), 340f, y + 27f, numberPaint)
            c.drawRoundRect(515f, y + 12f, 548f, y + 36f, 7f, 7f, paint(pale, 1f))
            c.drawText("${i + 1}", 531.5f, y + 28f, paint(orange, 8f, true, Paint.Align.CENTER))
            y += 54f
        }
        if (rows.isEmpty()) {
            c.drawRoundRect(38f, 270f, 557f, 340f, 12f, 12f, paint(android.graphics.Color.rgb(248, 249, 251), 1f))
            c.drawText("Aucun numéro à exporter", 58f, 309f, namePaint)
            c.drawText("Ajoutez des contacts pour constituer votre répertoire.", 58f, 328f, subtitle)
        }
        // Footer on every page
        c.drawLine(38f, 786f, 557f, 786f, paint(border, 1f))
        c.drawText("DLPHONE  •  RÉPERTOIRE PRIVÉ", 38f, 808f, paint(muted, 8f, true))
        c.drawText("PAGE $pageNo / $totalPages", 557f, 808f, paint(orange, 8f, true, Paint.Align.RIGHT))
        pdf.finishPage(page)
    }
    context.contentResolver.openOutputStream(uri)?.use { pdf.writeTo(it) }
        ?: throw IllegalStateException("Impossible d'ouvrir le fichier de destination")
    pdf.close()
}

@Composable
fun ContactsScreen(contacts: List<Contact>, onCall: (String) -> Unit, onChanged: () -> Unit) {
    val ctx = LocalContext.current
    val p = LocalPalette.current
    val pdfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) runCatching { writeContactsPdf(ctx, uri, contacts) }
            .onSuccess { Toast.makeText(ctx, "PDF des numéros enregistré", Toast.LENGTH_SHORT).show() }
            .onFailure { Toast.makeText(ctx, "Impossible de créer le PDF", Toast.LENGTH_LONG).show() }
    }
    var q by remember { mutableStateOf("") }
    val shown = remember(q, contacts) {
        if (q.isBlank()) contacts else {
            val cq = T9.clean(q.trim())
            val dq = q.filter { it.isDigit() }
            contacts.filter { T9.clean(it.name).contains(cq) || (dq.isNotEmpty() && it.number.filter { d -> d.isDigit() }.contains(dq)) }
        }
    }
    val favs = remember(contacts) { contacts.filter { it.starred }.distinctBy { it.id } }
    val groups = remember(shown) {
        shown.groupBy { c -> c.name.firstOrNull()?.uppercaseChar()?.takeIf { it.isLetter() } ?: '#' }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Contacts", "${contacts.distinctBy { it.id }.size} contacts") {
            IconButton(onClick = { pdfLauncher.launch("DLPhone-numeros.pdf") }) {
                Icon(Icons.Filled.PictureAsPdf, "Exporter les numéros en PDF", tint = p.accent)
            }
            IconButton(onClick = { safeStart(ctx, Intent(Intent.ACTION_INSERT, ContactsContract.Contacts.CONTENT_URI)) }) {
                Icon(Icons.Filled.PersonAdd, "Nouveau contact", tint = p.accent)
            }
        }
        OutlinedTextField(
            value = q,
            onValueChange = { q = it },
            placeholder = { Text("Rechercher un nom ou un numéro") },
            leadingIcon = { Icon(Icons.Filled.Search, null) },
            singleLine = true,
            shape = RoundedCornerShape(28.dp),
            colors = dlTextFieldColors(),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp)
        )
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
            if (q.isBlank() && favs.isNotEmpty()) {
                item(key = "favs") {
                    Column {
                        SectionLabel("Favoris", Modifier.padding(start = 20.dp, top = 6.dp))
                        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            items(favs, key = { it.id }) { f ->
                                Column(
                                    Modifier
                                        .width(68.dp)
                                        .clickable { onCall(f.number) },
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Avatar(f.name, 58.dp, photo = f.photo, number = f.number)
                                    Text(f.name.substringBefore(' '), color = p.text, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                    }
                }
            }
            groups.forEach { (letter, list) ->
                item(key = "L_$letter") {
                    SectionLabel(letter.toString(), Modifier.padding(start = 20.dp, top = 8.dp))
                }
                items(list, key = { "${it.id}-${it.number}" }) { c -> ContactRow(c, onCall, onChanged) }
            }
        }
    }
}

@Composable
private fun ContactRow(c: Contact, onCall: (String) -> Unit, onChanged: () -> Unit) {
    val ctx = LocalContext.current
    val p = LocalPalette.current
    var menu by remember { mutableStateOf(false) }
    Box {
        ListRow(
            title = c.name,
            leading = { Avatar(c.name, 44.dp, photo = c.photo, number = c.number) },
            subtitle = { Text(c.number, color = p.muted, fontSize = 12.sp) },
            trailing = {
                IconButton(onClick = { onCall(c.number) }) { Icon(Icons.Filled.Call, "Appeler", tint = p.accent) }
            },
            onClick = { onCall(c.number) },
            onLongClick = { menu = true }
        )
        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
            DropdownMenuItem(text = { Text("Personnaliser l'appel") }, onClick = {
                menu = false
                ThemeEditorActivity.open(ctx, c.number, c.name)
            })
            DropdownMenuItem(text = { Text("Ouvrir la fiche") }, onClick = {
                menu = false
                safeStart(ctx, Intent(Intent.ACTION_VIEW, ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, c.id)))
            })
            DropdownMenuItem(text = { Text("Envoyer un SMS") }, onClick = {
                menu = false
                safeStart(ctx, Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${c.number}")))
            })
            val blocked = Prefs.isBlocked(c.number)
            DropdownMenuItem(text = { Text(if (blocked) "Débloquer" else "Bloquer") }, onClick = {
                menu = false
                if (blocked) Prefs.unblock(c.number) else Prefs.block(c.number)
                onChanged()
            })
        }
    }
}
