package com.dlvibestudio.dlturbo.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class SettingsData(
    // Général
    val maxParallel: Int = 3,
    val connections: Int = 8,
    /** Octets par seconde, 0 = illimité. */
    val speedLimit: Long = 0,
    val wifiOnly: Boolean = false,
    val autoResume: Boolean = true,
    val retries: Int = 8,
    val sortByCategory: Boolean = true,
    val userAgent: String = DEFAULT_UA,
    // Notifications
    val soundOnComplete: Boolean = true,
    // Vidéo
    val videoQuality: String = "best",
    val preferMp4: Boolean = true,
    val wholePlaylist: Boolean = false,
    val videoFragments: Int = 8,
    // Torrent
    val torrentUploadLimit: Long = 100 * 1024,
    val torrentMaxConnections: Int = 200,
    val torrentSeed: Boolean = false,
    // Apparence : "system", "dark", "light"
    val theme: String = "dark",
) {
    companion object {
        const val DEFAULT_UA =
            "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) " +
                "Chrome/126.0.0.0 Mobile Safari/537.36"
    }
}

class Settings(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    private val _data = MutableStateFlow(load())
    val data: StateFlow<SettingsData> = _data.asStateFlow()
    val value: SettingsData get() = _data.value

    fun update(transform: (SettingsData) -> SettingsData) {
        val next = transform(_data.value)
        _data.value = next
        save(next)
    }

    private fun load(): SettingsData {
        val d = SettingsData()
        return SettingsData(
            maxParallel = prefs.getInt("maxParallel", d.maxParallel).coerceIn(1, 10),
            connections = prefs.getInt("connections", d.connections).coerceIn(1, 32),
            speedLimit = prefs.getLong("speedLimit", d.speedLimit),
            wifiOnly = prefs.getBoolean("wifiOnly", d.wifiOnly),
            autoResume = prefs.getBoolean("autoResume", d.autoResume),
            retries = prefs.getInt("retries", d.retries).coerceIn(0, 30),
            sortByCategory = prefs.getBoolean("sortByCategory", d.sortByCategory),
            userAgent = prefs.getString("userAgent", d.userAgent) ?: d.userAgent,
            soundOnComplete = prefs.getBoolean("soundOnComplete", d.soundOnComplete),
            videoQuality = prefs.getString("videoQuality", d.videoQuality) ?: d.videoQuality,
            preferMp4 = prefs.getBoolean("preferMp4", d.preferMp4),
            wholePlaylist = prefs.getBoolean("wholePlaylist", d.wholePlaylist),
            videoFragments = prefs.getInt("videoFragments", d.videoFragments).coerceIn(1, 16),
            torrentUploadLimit = prefs.getLong("torrentUploadLimit", d.torrentUploadLimit),
            torrentMaxConnections = prefs.getInt("torrentMaxConnections", d.torrentMaxConnections),
            torrentSeed = prefs.getBoolean("torrentSeed", d.torrentSeed),
            theme = prefs.getString("theme", d.theme) ?: d.theme,
        )
    }

    private fun save(s: SettingsData) {
        prefs.edit()
            .putInt("maxParallel", s.maxParallel)
            .putInt("connections", s.connections)
            .putLong("speedLimit", s.speedLimit)
            .putBoolean("wifiOnly", s.wifiOnly)
            .putBoolean("autoResume", s.autoResume)
            .putInt("retries", s.retries)
            .putBoolean("sortByCategory", s.sortByCategory)
            .putString("userAgent", s.userAgent)
            .putBoolean("soundOnComplete", s.soundOnComplete)
            .putString("videoQuality", s.videoQuality)
            .putBoolean("preferMp4", s.preferMp4)
            .putBoolean("wholePlaylist", s.wholePlaylist)
            .putInt("videoFragments", s.videoFragments)
            .putLong("torrentUploadLimit", s.torrentUploadLimit)
            .putInt("torrentMaxConnections", s.torrentMaxConnections)
            .putBoolean("torrentSeed", s.torrentSeed)
            .putString("theme", s.theme)
            .apply()
    }
}
