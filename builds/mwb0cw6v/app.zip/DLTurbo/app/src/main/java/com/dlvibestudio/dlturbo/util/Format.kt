package com.dlvibestudio.dlturbo.util

import java.util.Locale

object Format {

    fun bytes(value: Long): String {
        if (value < 0) return "?"
        if (value < 1024) return "$value o"
        val units = arrayOf("Ko", "Mo", "Go", "To")
        var v = value / 1024.0
        var i = 0
        while (v >= 1024 && i < units.size - 1) {
            v /= 1024
            i++
        }
        return if (v >= 100) String.format(Locale.FRANCE, "%.0f %s", v, units[i])
        else String.format(Locale.FRANCE, "%.1f %s", v, units[i])
    }

    fun speed(bytesPerSecond: Long): String = bytes(bytesPerSecond) + "/s"

    fun duration(seconds: Long): String {
        if (seconds < 0) return ""
        val h = seconds / 3600
        val m = (seconds % 3600) / 60
        val s = seconds % 60
        return when {
            h > 0 -> "${h} h ${m} min"
            m > 0 -> "${m} min ${s} s"
            else -> "${s} s"
        }
    }
}
