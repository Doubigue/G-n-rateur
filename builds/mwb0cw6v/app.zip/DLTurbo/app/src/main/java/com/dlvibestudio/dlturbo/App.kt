package com.dlvibestudio.dlturbo

import android.app.Application
import com.dlvibestudio.dlturbo.data.DownloadRepository
import com.dlvibestudio.dlturbo.data.Settings
import com.dlvibestudio.dlturbo.engine.DownloadManager
import com.dlvibestudio.dlturbo.service.Notifications
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

class App : Application() {

    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    lateinit var settings: Settings
        private set
    lateinit var repo: DownloadRepository
        private set
    lateinit var manager: DownloadManager
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        Notifications.createChannels(this)
        settings = Settings(this)
        repo = DownloadRepository(this, scope)
        manager = DownloadManager(this, repo, settings, scope)
    }

    companion object {
        lateinit var instance: App
            private set
    }
}
