package com.dlvibestudio.dlturbo.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import com.dlvibestudio.dlturbo.App

class MainActivity : ComponentActivity() {

    /** Lien reçu par « Partager » ou par un clic sur un lien magnet : pré-remplit la fenêtre d'ajout. */
    private val pendingText = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as App
        if (savedInstanceState == null) handleIntent(intent)

        setContent {
            val settings by app.settings.data.collectAsState()
            DLTheme(settings.theme) {
                AppRoot(app, pendingText)
            }
        }
        // L'activité est au premier plan : c'est le bon moment pour relancer ce qui avait été coupé.
        app.manager.resumeInterrupted()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        intent ?: return
        val app = application as App
        when (intent.action) {
            Intent.ACTION_SEND -> {
                val text = intent.getStringExtra(Intent.EXTRA_TEXT)
                if (!text.isNullOrBlank()) pendingText.value = text
            }

            Intent.ACTION_VIEW -> {
                val data = intent.data ?: return
                when (data.scheme?.lowercase()) {
                    "magnet", "http", "https" -> pendingText.value = data.toString()
                    "content", "file" -> {
                        val ok = addTorrentFromUri(this, app, data)
                        Toast.makeText(
                            this,
                            if (ok) "Torrent ajouté" else "Impossible de lire ce fichier .torrent",
                            Toast.LENGTH_SHORT,
                        ).show()
                    }
                }
            }
        }
    }
}

/** Lit un fichier .torrent choisi par l'utilisateur et l'ajoute à la file. */
fun addTorrentFromUri(context: Context, app: App, uri: Uri): Boolean {
    return try {
        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return false
        if (bytes.isEmpty() || bytes.size > 30 * 1024 * 1024) return false
        var name = "Torrent"
        runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0)?.let { name = it }
            }
        }
        app.manager.enqueueTorrentFile(bytes, name)
        true
    } catch (_: Exception) {
        false
    }
}

@Composable
private fun AppRoot(app: App, pendingText: MutableState<String?>) {
    var screen by rememberSaveable { mutableStateOf("home") }

    // Autorisations demandées une fois au premier lancement.
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { }
    LaunchedEffect(Unit) {
        val wanted = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) wanted.add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.Q) wanted.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        val missing = wanted.filter {
            ContextCompat.checkSelfPermission(app, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) permissionLauncher.launch(missing.toTypedArray())
    }

    BackHandler(enabled = screen != "home") { screen = "home" }

    when (screen) {
        "settings" -> SettingsScreen(app = app, onBack = { screen = "home" })
        else -> DownloadsScreen(app = app, pendingText = pendingText, onOpenSettings = { screen = "settings" })
    }
}
