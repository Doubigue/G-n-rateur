package com.dlvibestudio.dlturbo.engine

import android.content.Context
import com.dlvibestudio.dlturbo.data.DlStatus
import com.dlvibestudio.dlturbo.data.DownloadRepository
import com.dlvibestudio.dlturbo.data.Settings
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.runInterruptible
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import kotlin.coroutines.coroutineContext

/**
 * Téléchargement de vidéos depuis les sites de partage (YouTube, Instagram, Facebook,
 * TikTok, Pinterest, X/Twitter et plus d'un millier d'autres) grâce à yt-dlp + ffmpeg.
 */
class VideoEngine(
    private val context: Context,
    private val repo: DownloadRepository,
    private val settings: Settings,
    scope: CoroutineScope,
) {
    /** null = prêt ; sinon, l'erreur d'initialisation. */
    private val ready = CompletableDeferred<Throwable?>()

    init {
        scope.launch(Dispatchers.IO) {
            val error = try {
                YoutubeDL.getInstance().init(context)
                FFmpeg.getInstance().init(context)
                null
            } catch (t: Throwable) {
                t
            }
            ready.complete(error)
        }
    }

    suspend fun run(id: String): File? {
        val item = repo.get(id) ?: throw FatalDownloadException("Téléchargement introuvable")
        val cfg = settings.value
        repo.update(id) { it.copy(info = "Analyse du lien…") }

        ready.await()?.let {
            throw FatalDownloadException("Module vidéo indisponible : ${it.message ?: it.javaClass.simpleName}")
        }

        val dir = File(item.dir)
        if (!dir.exists() && !dir.mkdirs() && !dir.exists()) {
            throw FatalDownloadException("Impossible de créer le dossier ${dir.path}")
        }

        val quality = item.quality.ifBlank { cfg.videoQuality }
        val request = YoutubeDLRequest(item.url)
        request.addOption("-o", File(dir, "%(title).120B [%(id)s].%(ext)s").path)
        request.addOption("--no-mtime")
        request.addOption("--continue")
        request.addOption("--newline")
        request.addOption("--retries", cfg.retries.coerceAtLeast(1))
        request.addOption("--fragment-retries", cfg.retries.coerceAtLeast(1))
        request.addOption("--concurrent-fragments", cfg.videoFragments)
        request.addOption("--user-agent", cfg.userAgent.ifBlank { com.dlvibestudio.dlturbo.data.SettingsData.DEFAULT_UA })
        if (!cfg.wholePlaylist) request.addOption("--no-playlist")
        if (cfg.speedLimit > 0) request.addOption("--limit-rate", "${cfg.speedLimit / 1024}K")

        when (quality) {
            "audio" -> {
                request.addOption("-x")
                request.addOption("--audio-format", "mp3")
                request.addOption("--audio-quality", "0")
            }
            "best" -> request.addOption("-f", "bv*+ba/b")
            else -> {
                val h = quality.toIntOrNull() ?: 720
                request.addOption("-f", "bv*[height<=$h]+ba/b[height<=$h]/bv*+ba/b")
            }
        }
        if (quality != "audio" && cfg.preferMp4) {
            request.addOption("-S", "ext:mp4:m4a")
            request.addOption("--merge-output-format", "mp4")
        }

        var outputPath: String? = null
        var lastUpdate = 0L

        try {
            runInterruptible(Dispatchers.IO) {
                YoutubeDL.getInstance().execute(request, id) { progress, _, line ->
                    parseDestination(line)?.let { path ->
                        outputPath = path
                        val name = File(path).name
                        repo.update(id) { it.copy(fileName = name, autoName = false) }
                    }
                    val now = System.currentTimeMillis()
                    if (now - lastUpdate >= 400) {
                        lastUpdate = now
                        val total = parseSize(TOTAL_REGEX, line)
                        val speed = parseSize(SPEED_REGEX, line)
                        val stage = when {
                            line.startsWith("[Merger]") -> "Fusion vidéo + audio…"
                            line.startsWith("[ExtractAudio]") -> "Conversion audio…"
                            line.startsWith("[download]") -> "Téléchargement"
                            else -> null
                        }
                        repo.update(id) {
                            it.copy(
                                status = if (it.status == DlStatus.CONNECTING || it.status == DlStatus.QUEUED)
                                    DlStatus.RUNNING else it.status,
                                percent = if (progress >= 0f) progress else it.percent,
                                totalBytes = if (total > 0) total else it.totalBytes,
                                downloadedBytes = if (total > 0 && progress >= 0f)
                                    (total * (progress / 100f)).toLong() else it.downloadedBytes,
                                speed = if (speed >= 0) speed else it.speed,
                                info = stage ?: it.info,
                            )
                        }
                    }
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: InterruptedException) {
            throw CancellationException("Annulé")
        } catch (e: Exception) {
            // Processus arrêté volontairement (pause / suppression) : ce n'est pas une erreur.
            if (e.javaClass.simpleName == "CanceledException") throw CancellationException("Annulé")
            coroutineContext.ensureActive()
            throw IOException(cleanError(e.message))
        } finally {
            // Arrête le processus yt-dlp s'il tourne encore (pause, suppression).
            // Les fichiers partiels (.part) restent sur le disque : la reprise continue dessus.
            runCatching { YoutubeDL.getInstance().destroyProcessById(id) }
            repo.update(id) { it.copy(speed = 0) }
        }

        val file = outputPath?.let { File(it) }?.takeIf { it.exists() }
        if (file != null) {
            val length = file.length()
            repo.update(id) {
                it.copy(fileName = file.name, totalBytes = length, downloadedBytes = length, percent = 100f)
            }
        }
        return file
    }

    /** Met à jour yt-dlp (les sites changent souvent : à faire quand un site ne marche plus). */
    suspend fun update(): String = withContext(Dispatchers.IO) {
        ready.await()?.let { return@withContext "Module vidéo indisponible : ${it.message}" }
        try {
            val status = YoutubeDL.getInstance().updateYoutubeDL(context)
            val version = YoutubeDL.getInstance().version(context) ?: ""
            if (status?.toString() == "ALREADY_UP_TO_DATE") "yt-dlp est déjà à jour ($version)"
            else "yt-dlp mis à jour ($version)"
        } catch (e: Throwable) {
            "Échec de la mise à jour : ${e.message ?: "erreur inconnue"}"
        }
    }

    private fun parseDestination(line: String): String? {
        for (regex in DEST_REGEXES) {
            regex.find(line)?.let { return it.groupValues[1].trim() }
        }
        return null
    }

    private fun parseSize(regex: Regex, line: String): Long {
        val m = regex.find(line) ?: return -1
        val value = m.groupValues[1].toDoubleOrNull() ?: return -1
        val factor = when (m.groupValues[2]) {
            "KiB" -> 1024.0
            "MiB" -> 1024.0 * 1024
            "GiB" -> 1024.0 * 1024 * 1024
            else -> 1.0
        }
        return (value * factor).toLong()
    }

    private fun cleanError(message: String?): String {
        if (message.isNullOrBlank()) return "Échec de l'extraction de la vidéo"
        val line = message.lines().lastOrNull { it.contains("ERROR") } ?: message.lines().last { it.isNotBlank() }
        return line.replace("ERROR:", "").trim().take(240)
    }

    companion object {
        private val DEST_REGEXES = listOf(
            Regex("""^\[Merger\] Merging formats into "(.+)"\s*$"""),
            Regex("""^\[ExtractAudio\] Destination: (.+)$"""),
            Regex("""^\[download\] Destination: (.+)$"""),
            Regex("""^\[download\] (.+) has already been downloaded$"""),
        )
        private val TOTAL_REGEX = Regex("""of\s+~?\s*([\d.]+)\s*(KiB|MiB|GiB|B)""")
        private val SPEED_REGEX = Regex("""at\s+([\d.]+)\s*(KiB|MiB|GiB|B)/s""")
    }
}
