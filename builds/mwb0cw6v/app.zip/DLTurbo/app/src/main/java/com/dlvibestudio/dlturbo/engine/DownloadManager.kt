package com.dlvibestudio.dlturbo.engine

import android.content.Context
import android.media.MediaScannerConnection
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Environment
import com.dlvibestudio.dlturbo.data.DlStatus
import com.dlvibestudio.dlturbo.data.DlType
import com.dlvibestudio.dlturbo.data.DownloadItem
import com.dlvibestudio.dlturbo.data.DownloadRepository
import com.dlvibestudio.dlturbo.data.Settings
import com.dlvibestudio.dlturbo.service.DownloadService
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Chef d'orchestre : file d'attente, nombre de téléchargements simultanés,
 * pause / reprise / suppression, attente du réseau, et choix du bon moteur
 * (HTTP multi-connexions, torrent ou extracteur vidéo).
 */
class DownloadManager(
    private val context: Context,
    val repo: DownloadRepository,
    val settings: Settings,
    private val scope: CoroutineScope,
) {
    private val limiter = RateLimiter { settings.value.speedLimit }
    val http = HttpDownloader(repo, settings, limiter)
    val torrents = TorrentEngine(context, repo, settings, http)
    val videos = VideoEngine(context, repo, settings, scope)

    private val jobs = ConcurrentHashMap<String, Job>()
    private val lock = Any()
    private var resumedOnce = false

    /** Dossier public : Téléchargements/DLTurbo (visible dans la galerie et les gestionnaires de fichiers). */
    val baseDir: File
        get() = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            "DLTurbo",
        )

    init {
        scope.launch {
            settings.data.collect {
                torrents.applyLimits()
                enforceNetworkPolicy()
                retryWaiting()
                schedule()
            }
        }
        registerNetworkCallback()
    }

    // ---------------------------------------------------------------- Ajout

    /** Ajoute tous les liens trouvés dans [text]. Renvoie le nombre de liens ajoutés. */
    fun enqueueText(text: String, quality: String = ""): Int {
        val urls = Links.extract(text)
        urls.forEach { enqueue(it, quality) }
        return urls.size
    }

    fun enqueue(url: String, quality: String = "") {
        val cfg = settings.value
        val sorted = cfg.sortByCategory
        val item = when {
            Links.isMagnet(url) || Links.isTorrentUrl(url) -> DownloadItem(
                id = newId(), type = DlType.TORRENT, url = url,
                fileName = magnetName(url),
                dir = (if (sorted) File(baseDir, "Torrents") else baseDir).path,
            )

            Links.isVideoSite(url) -> newVideoItem(url, quality)

            else -> DownloadItem(
                id = newId(), type = DlType.HTTP, url = url,
                fileName = Links.fileName(url, null, null),
                dir = baseDir.path,
                videoFallback = true,
            )
        }
        repo.add(item)
        schedule()
    }

    /** Ajoute un fichier .torrent choisi sur le téléphone. */
    fun enqueueTorrentFile(bytes: ByteArray, displayName: String) {
        val id = newId()
        torrents.torrentFile(id).writeBytes(bytes)
        val sorted = settings.value.sortByCategory
        repo.add(
            DownloadItem(
                id = id, type = DlType.TORRENT, url = "fichier .torrent",
                fileName = displayName.removeSuffix(".torrent").ifBlank { "Torrent" },
                dir = (if (sorted) File(baseDir, "Torrents") else baseDir).path,
            )
        )
        schedule()
    }

    private fun newVideoItem(url: String, quality: String, id: String = newId()): DownloadItem {
        val cfg = settings.value
        val q = quality.ifBlank { cfg.videoQuality }
        val dir = when {
            !cfg.sortByCategory -> baseDir
            q == "audio" -> File(baseDir, "Musique")
            else -> File(baseDir, "Vidéos")
        }
        return DownloadItem(
            id = id, type = DlType.VIDEO, url = url,
            fileName = (if (q == "audio") "Audio · " else "Vidéo · ") + Links.hostOf(url),
            dir = dir.path, quality = q,
        )
    }

    private fun magnetName(url: String): String {
        val dn = runCatching { Uri.parse(url.replaceFirst("magnet:?", "magnet://x/?")).getQueryParameter("dn") }
            .getOrNull()
        return if (!dn.isNullOrBlank()) Links.sanitize(dn)
        else if (Links.isMagnet(url)) "Torrent (magnet)"
        else Links.fileName(url, null, null).removeSuffix(".torrent")
    }

    private fun newId() = UUID.randomUUID().toString().replace("-", "").take(16)

    // ------------------------------------------------------ Pause / reprise

    fun pause(id: String) {
        repo.update(id) {
            if (it.status.isActive) it.copy(status = DlStatus.PAUSED, speed = 0, info = "") else it
        }
        jobs[id]?.cancel()
        repo.saveNow()
    }

    fun resume(id: String) {
        repo.update(id) {
            if (it.status == DlStatus.PAUSED || it.status == DlStatus.ERROR || it.status == DlStatus.WAITING_NETWORK)
                it.copy(status = DlStatus.QUEUED, error = null, info = "")
            else it
        }
        schedule()
    }

    fun pauseAll() {
        repo.items.value.filter { it.status.isActive }.forEach { pause(it.id) }
    }

    fun resumeAll() {
        repo.updateAll {
            if (it.status == DlStatus.PAUSED || it.status == DlStatus.ERROR)
                it.copy(status = DlStatus.QUEUED, error = null, info = "")
            else it
        }
        schedule()
    }

    /** Relance, une seule fois au lancement, ce qui a été coupé par la fermeture de l'application. */
    fun resumeInterrupted() {
        if (resumedOnce) return
        resumedOnce = true
        if (!settings.value.autoResume) return
        repo.updateAll {
            if (it.status == DlStatus.PAUSED && it.info == DownloadRepository.INTERRUPTED)
                it.copy(status = DlStatus.QUEUED, info = "")
            else it
        }
        schedule()
    }

    fun remove(id: String, deleteFile: Boolean) {
        val item = repo.get(id) ?: return
        val job = jobs[id]
        repo.remove(id)
        job?.cancel()
        runCatching {
            context.getSystemService(android.app.NotificationManager::class.java)
                ?.cancel(com.dlvibestudio.dlturbo.service.Notifications.idFor(item))
        }
        scope.launch(Dispatchers.IO) {
            job?.join()
            if (item.type == DlType.TORRENT) torrents.remove(id)
            runCatching {
                // Les fichiers partiels d'un téléchargement direct sont toujours nettoyés.
                if (item.type == DlType.HTTP && item.status != DlStatus.COMPLETED) {
                    File(item.dir, item.fileName + Links.PART_SUFFIX).delete()
                }
                // Le nom doit avoir été confirmé par le moteur avant toute suppression de fichier.
                if (deleteFile && !item.autoName && item.fileName.isNotBlank()) {
                    val target = File(item.dir, item.fileName)
                    if (target != File(item.dir) && target.exists()) target.deleteRecursively()
                }
            }
            schedule()
        }
    }

    fun clearCompleted() {
        repo.items.value.filter { it.status == DlStatus.COMPLETED }.forEach { repo.remove(it.id) }
    }

    // ----------------------------------------------------------------- File

    fun schedule() {
        synchronized(lock) {
            val max = settings.value.maxParallel
            while (jobs.size < max) {
                // La liste est triée du plus récent au plus ancien : on sert le plus ancien d'abord.
                val next = repo.items.value.lastOrNull {
                    it.status == DlStatus.QUEUED && !jobs.containsKey(it.id)
                } ?: break
                if (!networkOk()) {
                    repo.update(next.id) { it.copy(status = DlStatus.WAITING_NETWORK, info = waitingLabel()) }
                    DownloadService.start(context)
                    continue
                }
                start(next.id)
            }
        }
    }

    private fun start(id: String) {
        DownloadService.start(context)
        val job = scope.launch(Dispatchers.IO, start = CoroutineStart.LAZY) { runItem(id) }
        jobs[id] = job
        job.invokeOnCompletion {
            jobs.remove(id, job)
            schedule()
        }
        job.start()
    }

    private suspend fun runItem(id: String) {
        val item = repo.get(id) ?: return
        // Mis en pause entre la mise en file et le démarrage : on ne touche à rien.
        if (item.status != DlStatus.QUEUED) return
        repo.update(id) {
            if (it.status == DlStatus.QUEUED) it.copy(status = DlStatus.CONNECTING, error = null, info = "Connexion…")
            else it
        }
        try {
            val file: File? = when (item.type) {
                DlType.HTTP -> http.run(id)
                DlType.TORRENT -> {
                    torrents.run(id)
                    null
                }
                DlType.VIDEO -> videos.run(id)
            }
            repo.update(id) {
                it.copy(
                    status = DlStatus.COMPLETED, speed = 0, error = null, info = "",
                    finishedAt = System.currentTimeMillis(),
                    downloadedBytes = if (it.totalBytes > 0) it.totalBytes else it.downloadedBytes,
                )
            }
            val done = repo.get(id)
            val target = file ?: done?.let { File(it.dir, it.fileName) }
            if (target != null && target.isFile) {
                MediaScannerConnection.scanFile(context, arrayOf(target.path), null, null)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: HtmlPageException) {
            // Ce n'est pas un fichier mais une page web : on tente l'extracteur vidéo.
            val video = newVideoItem(item.url, "", id)
            repo.update(id) {
                it.copy(
                    type = DlType.VIDEO, status = DlStatus.QUEUED, fileName = video.fileName,
                    dir = video.dir, quality = video.quality, videoFallback = false,
                    segments = emptyList(), info = "",
                )
            }
        } catch (t: Throwable) {
            if (t !is FatalDownloadException && !networkOk()) {
                repo.update(id) {
                    it.copy(status = DlStatus.WAITING_NETWORK, speed = 0, info = waitingLabel())
                }
            } else {
                val message = t.message?.takeIf { it.isNotBlank() } ?: t.javaClass.simpleName
                repo.update(id) {
                    it.copy(status = DlStatus.ERROR, speed = 0, error = message, info = "")
                }
            }
        } finally {
            repo.saveNow()
        }
    }

    // --------------------------------------------------------------- Réseau

    private fun waitingLabel() =
        if (settings.value.wifiOnly) "En attente du Wi-Fi" else "En attente du réseau"

    fun networkOk(): Boolean {
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return true
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) return false
        return !settings.value.wifiOnly || caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
    }

    /** Remet en file ce qui attendait le réseau, dès qu'il est de retour. */
    private fun retryWaiting() {
        if (!networkOk()) return
        if (repo.items.value.none { it.status == DlStatus.WAITING_NETWORK }) return
        repo.updateAll {
            if (it.status == DlStatus.WAITING_NETWORK) it.copy(status = DlStatus.QUEUED, info = "") else it
        }
        schedule()
    }

    /** Mode « Wi-Fi uniquement » : suspend tout si on bascule sur les données mobiles. */
    private fun enforceNetworkPolicy() {
        if (!settings.value.wifiOnly || networkOk()) return
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return
        if (cm.activeNetwork == null) return // simple coupure : les moteurs réessaient d'eux-mêmes
        repo.items.value.filter { jobs.containsKey(it.id) }.forEach { item ->
            repo.update(item.id) {
                if (it.status.isActive) it.copy(status = DlStatus.WAITING_NETWORK, speed = 0, info = waitingLabel())
                else it
            }
            jobs[item.id]?.cancel()
        }
    }

    private fun registerNetworkCallback() {
        val cm = context.getSystemService(ConnectivityManager::class.java) ?: return
        runCatching {
            cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    scope.launch { retryWaiting() }
                }

                override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                    scope.launch {
                        enforceNetworkPolicy()
                        retryWaiting()
                    }
                }
            })
        }
    }
}
