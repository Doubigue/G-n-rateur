@file:OptIn(ExperimentalMaterial3Api::class)

package com.dlvibestudio.dlturbo.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DeviceHub
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.dlvibestudio.dlturbo.App
import com.dlvibestudio.dlturbo.R
import com.dlvibestudio.dlturbo.data.DlStatus
import com.dlvibestudio.dlturbo.data.DlType
import com.dlvibestudio.dlturbo.data.DownloadItem
import com.dlvibestudio.dlturbo.engine.Links
import com.dlvibestudio.dlturbo.util.Format
import java.io.File

@Composable
fun DownloadsScreen(app: App, pendingText: MutableState<String?>, onOpenSettings: () -> Unit) {
    val items by app.repo.items.collectAsState()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var showAdd by rememberSaveable { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }

    val active = items.filter { it.status != DlStatus.COMPLETED }
    val completed = items.filter { it.status == DlStatus.COMPLETED }
    val running = items.count { it.status.isActive }
    val totalSpeed = items.sumOf { it.speed }
    val visible = when (tab) {
        1 -> active
        2 -> completed
        else -> items
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painter = painterResource(R.drawable.logo),
                            contentDescription = null,
                            modifier = Modifier.size(34.dp).clip(RoundedCornerShape(9.dp)),
                        )
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("DL Turbo", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                            Text(
                                text = if (running > 0) "$running en cours · ${Format.speed(totalSpeed)}"
                                else "${items.size} téléchargement" + if (items.size > 1) "s" else "",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                },
                actions = {
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Filled.Settings, contentDescription = "Paramètres")
                    }
                    Box {
                        IconButton(onClick = { menuOpen = true }) {
                            Icon(Icons.Filled.MoreVert, contentDescription = "Plus d'actions")
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(
                                text = { Text("Tout suspendre") },
                                onClick = { menuOpen = false; app.manager.pauseAll() },
                            )
                            DropdownMenuItem(
                                text = { Text("Tout reprendre") },
                                onClick = { menuOpen = false; app.manager.resumeAll() },
                            )
                            DropdownMenuItem(
                                text = { Text("Vider la liste des terminés") },
                                onClick = { menuOpen = false; app.manager.clearCompleted() },
                            )
                        }
                    }
                },
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAdd = true },
                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                text = { Text("Ajouter") },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
            )
        },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Tous (${items.size})") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("En cours (${active.size})") })
                Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("Terminés (${completed.size})") })
            }
            if (visible.isEmpty()) {
                EmptyState()
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    items(visible, key = { it.id }) { item ->
                        DownloadCard(item, app)
                    }
                }
            }
        }
    }

    val shared = pendingText.value
    if (showAdd || shared != null) {
        AddDialog(
            app = app,
            initialText = shared ?: "",
            onDismiss = {
                showAdd = false
                pendingText.value = null
            },
        )
    }
}

@Composable
private fun EmptyState() {
    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(
            Icons.Filled.CloudDownload,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(72.dp),
        )
        Spacer(Modifier.height(16.dp))
        Text("Aucun téléchargement", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Text(
            "Appuyez sur « Ajouter » pour coller un lien, un magnet ou choisir un fichier .torrent.\n" +
                "Vous pouvez aussi utiliser « Partager » depuis YouTube, Instagram, TikTok, Facebook, " +
                "Pinterest ou votre navigateur.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
    }
}

private fun iconFor(item: DownloadItem): ImageVector = when {
    item.type == DlType.TORRENT -> Icons.Filled.DeviceHub
    item.type == DlType.VIDEO && item.quality == "audio" -> Icons.Filled.MusicNote
    item.type == DlType.VIDEO -> Icons.Filled.Movie
    else -> when (Links.category(item.fileName)) {
        "Vidéos" -> Icons.Filled.Movie
        "Musique" -> Icons.Filled.MusicNote
        "Images" -> Icons.Filled.Image
        "APK" -> Icons.Filled.Android
        else -> Icons.Filled.Description
    }
}

@Composable
private fun DownloadCard(item: DownloadItem, app: App) {
    val context = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    val colors = MaterialTheme.colorScheme

    Card(
        colors = CardDefaults.cardColors(containerColor = colors.surfaceContainer),
        shape = RoundedCornerShape(16.dp),
        onClick = { if (item.status == DlStatus.COMPLETED) openItem(context, item) },
    ) {
        Row(Modifier.padding(start = 12.dp, top = 12.dp, bottom = 12.dp, end = 4.dp)) {
            Box(
                modifier = Modifier.size(42.dp).clip(CircleShape).background(colors.primaryContainer),
                contentAlignment = Alignment.Center,
            ) {
                Icon(iconFor(item), contentDescription = null, tint = colors.onPrimaryContainer)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    item.fileName,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(6.dp))

                if (item.status != DlStatus.COMPLETED) {
                    val indeterminate = (item.status == DlStatus.CONNECTING) ||
                        (item.status == DlStatus.RUNNING && item.totalBytes <= 0 && item.percent < 0f)
                    val barColor = when (item.status) {
                        DlStatus.ERROR -> colors.error
                        DlStatus.PAUSED, DlStatus.QUEUED, DlStatus.WAITING_NETWORK -> colors.outline
                        else -> colors.primary
                    }
                    if (indeterminate) {
                        LinearProgressIndicator(
                            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                            color = barColor,
                            trackColor = colors.surfaceContainerHighest,
                        )
                    } else {
                        LinearProgressIndicator(
                            progress = { item.progress },
                            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                            color = barColor,
                            trackColor = colors.surfaceContainerHighest,
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                }

                Text(
                    statusLine(item),
                    style = MaterialTheme.typography.bodySmall,
                    color = if (item.status == DlStatus.ERROR) colors.error else colors.onSurfaceVariant,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                )
                val detail = detailLine(item)
                if (detail.isNotBlank()) {
                    Text(
                        detail,
                        style = MaterialTheme.typography.labelSmall,
                        color = colors.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                when {
                    item.status.isActive -> FilledTonalIconButton(onClick = { app.manager.pause(item.id) }) {
                        Icon(Icons.Filled.Pause, contentDescription = "Pause")
                    }
                    item.status == DlStatus.PAUSED -> FilledTonalIconButton(onClick = { app.manager.resume(item.id) }) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = "Reprendre")
                    }
                    item.status == DlStatus.ERROR -> FilledTonalIconButton(onClick = { app.manager.resume(item.id) }) {
                        Icon(Icons.Filled.Refresh, contentDescription = "Réessayer")
                    }
                }
                Box {
                    IconButton(onClick = { menu = true }) {
                        Icon(Icons.Filled.MoreVert, contentDescription = "Options")
                    }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        if (item.status == DlStatus.COMPLETED) {
                            DropdownMenuItem(
                                text = { Text("Ouvrir") },
                                onClick = { menu = false; openItem(context, item) },
                            )
                            DropdownMenuItem(
                                text = { Text("Partager") },
                                onClick = { menu = false; shareItem(context, item) },
                            )
                        }
                        DropdownMenuItem(
                            text = { Text("Copier le lien") },
                            onClick = {
                                menu = false
                                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                cm.setPrimaryClip(ClipData.newPlainText("lien", item.url))
                                Toast.makeText(context, "Lien copié", Toast.LENGTH_SHORT).show()
                            },
                        )
                        HorizontalDivider()
                        DropdownMenuItem(
                            text = { Text("Retirer de la liste") },
                            onClick = { menu = false; app.manager.remove(item.id, deleteFile = false) },
                        )
                        DropdownMenuItem(
                            text = { Text("Supprimer le fichier", color = colors.error) },
                            leadingIcon = { Icon(Icons.Filled.Delete, contentDescription = null, tint = colors.error) },
                            onClick = { menu = false; app.manager.remove(item.id, deleteFile = true) },
                        )
                    }
                }
            }
        }
    }
}

private fun statusLine(item: DownloadItem): String {
    val sizes = when {
        item.totalBytes > 0 -> "${Format.bytes(item.downloadedBytes)} / ${Format.bytes(item.totalBytes)}"
        item.downloadedBytes > 0 -> Format.bytes(item.downloadedBytes)
        else -> ""
    }
    val known = item.totalBytes > 0 || item.percent >= 0f
    val parts = ArrayList<String>()
    when (item.status) {
        DlStatus.QUEUED -> parts.add("En file d'attente")
        DlStatus.CONNECTING -> parts.add(item.info.ifBlank { "Connexion…" })
        DlStatus.WAITING_NETWORK -> {
            parts.add(item.info.ifBlank { "En attente du réseau" })
            if (known) parts.add("${item.percentInt} %")
        }
        DlStatus.RUNNING -> {
            if (known) parts.add("${item.percentInt} %")
            if (sizes.isNotBlank()) parts.add(sizes)
            if (item.speed > 0) parts.add(Format.speed(item.speed))
            if (item.etaSeconds >= 0) parts.add("reste ${Format.duration(item.etaSeconds)}")
            if (parts.isEmpty()) parts.add(item.info.ifBlank { "Téléchargement…" })
        }
        DlStatus.PAUSED -> {
            parts.add("En pause")
            if (known) parts.add("${item.percentInt} %")
            if (sizes.isNotBlank()) parts.add(sizes)
        }
        DlStatus.ERROR -> parts.add(item.error ?: "Erreur")
        DlStatus.COMPLETED -> {
            parts.add("Terminé")
            if (item.totalBytes > 0) parts.add(Format.bytes(item.totalBytes))
        }
    }
    return parts.joinToString(" · ")
}

private fun detailLine(item: DownloadItem): String = when (item.status) {
    DlStatus.RUNNING -> item.info
    DlStatus.COMPLETED -> File(item.dir).name
    else -> ""
}

private fun fileUri(context: Context, file: File) =
    FileProvider.getUriForFile(context, context.packageName + ".files", file)

private fun openItem(context: Context, item: DownloadItem) {
    val file = File(item.dir, item.fileName)
    if (!file.exists()) {
        Toast.makeText(context, "Fichier introuvable (déplacé ou supprimé)", Toast.LENGTH_SHORT).show()
        return
    }
    if (file.isDirectory) {
        Toast.makeText(context, "Dossier : ${file.path}", Toast.LENGTH_LONG).show()
        return
    }
    try {
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(fileUri(context, file), Links.mimeOf(file.name))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    } catch (_: Exception) {
        Toast.makeText(context, "Aucune application pour ouvrir ce fichier", Toast.LENGTH_SHORT).show()
    }
}

private fun shareItem(context: Context, item: DownloadItem) {
    val file = File(item.dir, item.fileName)
    if (!file.isFile) {
        Toast.makeText(context, "Fichier introuvable", Toast.LENGTH_SHORT).show()
        return
    }
    try {
        val intent = Intent(Intent.ACTION_SEND)
            .setType(Links.mimeOf(file.name))
            .putExtra(Intent.EXTRA_STREAM, fileUri(context, file))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        context.startActivity(Intent.createChooser(intent, "Partager").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {
        Toast.makeText(context, "Partage impossible", Toast.LENGTH_SHORT).show()
    }
}
