plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.dlvibestudio.dlturbo"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.dlvibestudio.dlturbo"
        minSdk = 24
        // 34 volontairement : à partir de 35, Android limite les services "dataSync" à 6 h par jour.
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"

        ndk {
            // Téléphones réels uniquement. Ajouter "x86_64" pour un émulateur
            // (et les dépendances libtorrent4j-android-x86_64 correspondantes).
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    // Aucune configuration de signature ici : elle est laissée au générateur / au dépôt.

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    packaging {
        // Indispensable pour yt-dlp / ffmpeg : les binaires doivent être extraits sur le téléphone.
        jniLibs {
            useLegacyPackaging = true
        }
        resources {
            excludes += setOf("/META-INF/{AL2.0,LGPL2.1}", "META-INF/DEPENDENCIES")
        }
    }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.core:core-ktx:1.15.0")

    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    // Moteur HTTP multi-connexions
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // Moteur BitTorrent (libtorrent)
    val libtorrent = "2.1.0-34"
    implementation("org.libtorrent4j:libtorrent4j:$libtorrent")
    implementation("org.libtorrent4j:libtorrent4j-android-arm64:$libtorrent")
    implementation("org.libtorrent4j:libtorrent4j-android-arm:$libtorrent")

    // Extraction vidéo (yt-dlp + ffmpeg) : YouTube, Instagram, Facebook, TikTok, Pinterest, etc.
    val ytdl = "0.18.1"
    implementation("io.github.junkfood02.youtubedl-android:library:$ytdl")
    implementation("io.github.junkfood02.youtubedl-android:ffmpeg:$ytdl")
}
