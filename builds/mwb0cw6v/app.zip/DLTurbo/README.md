# DL Turbo

Gestionnaire de téléchargements Android (Kotlin + Jetpack Compose) — DL VIBE STUDIO.

## Ce que fait l'application

| Fonction | Détail |
|---|---|
| Liens directs | APK, images, vidéos, logiciels, archives, documents… (HTTP/HTTPS) |
| Téléchargement accéléré | Fichier découpé en segments, jusqu'à 32 connexions par fichier |
| Pause / reprise | Reprise à l'octet près, y compris après fermeture de l'appli ou redémarrage du téléphone (au prochain lancement) |
| Torrents | Liens `magnet:`, fichiers `.torrent` (locaux ou distants), via libtorrent |
| Vidéos | YouTube, Instagram, Facebook, TikTok, Pinterest, X/Twitter et 1000+ sites, via yt-dlp + ffmpeg |
| Écran éteint | Service de premier plan + wake lock + verrou Wi-Fi |
| Notifications | Pourcentage, tailles, vitesse, temps restant, nombre de téléchargements, boutons Pause / Reprendre / Annuler |
| File d'attente | 1 à 10 téléchargements simultanés, attente automatique du réseau |
| Paramètres | Connexions, limite de vitesse, Wi-Fi uniquement, tentatives, qualité vidéo, MP3, playlists, limites torrent, thème… |
| Partage | « Partager » depuis une autre appli ou clic sur un lien magnet ouvre directement DL Turbo |

Les fichiers sont enregistrés dans `Téléchargements/DLTurbo/` (rangés par catégorie si l'option est activée).

## Compilation

- **APK Studio / GitHub Actions** : projet Gradle standard à la racine (`settings.gradle.kts`).
  Commande : `./gradlew assembleDebug` — JDK 17. Un workflow prêt à l'emploi est fourni dans
  `.github/workflows/build.yml`.
- **Android Studio** : ouvrir le dossier, laisser la synchronisation Gradle se terminer, puis Run.
- Aucune clé de signature n'est incluse : la signature est laissée au générateur / au dépôt.

Versions : Gradle 8.11.1, Android Gradle Plugin 8.7.3, Kotlin 2.1.20, compileSdk 35, targetSdk 34, minSdk 24.

L'APK est volumineux (≈ 100 Mo et plus) : il embarque Python/yt-dlp, ffmpeg et libtorrent pour
`arm64-v8a` et `armeabi-v7a`.

## Organisation du code

```
app/src/main/java/com/dlvibestudio/dlturbo/
├── App.kt                      Initialisation
├── data/
│   ├── DownloadItem.kt         Modèle d'un téléchargement (+ segments)
│   ├── DownloadRepository.kt   Liste observable, sauvegardée en JSON
│   └── Settings.kt             Paramètres
├── engine/
│   ├── DownloadManager.kt      File d'attente, pause/reprise, réseau
│   ├── HttpDownloader.kt       Moteur HTTP multi-connexions
│   ├── TorrentEngine.kt        Moteur BitTorrent (libtorrent4j)
│   ├── VideoEngine.kt          Extraction vidéo (yt-dlp + ffmpeg)
│   └── Links.kt                Reconnaissance des liens, noms de fichiers
├── service/
│   ├── DownloadService.kt      Service de premier plan (écran éteint)
│   ├── Notifications.kt        Notifications de progression
│   └── ActionReceiver.kt       Boutons des notifications
└── ui/                         Écrans Compose (liste, ajout, paramètres, thème)
```

## Remplacer le logo

- Icône de l'appli : `app/src/main/res/mipmap-*/ic_launcher*.png`
- Logo affiché dans l'appli : `app/src/main/res/drawable-nodpi/logo.png` (512 × 512)
- Source haute définition : `logo-dl-turbo.png`

## À savoir

- **Vitesse** : le multi-connexions accélère nettement les serveurs qui limitent chaque connexion,
  mais ne peut pas dépasser le débit de votre ligne ni celui du serveur.
- **Sites vidéo** : ils changent souvent. Si un site ne fonctionne plus :
  Paramètres → « Mettre à jour le moteur vidéo (yt-dlp) ».
- **Écran éteint** : sur certains téléphones (Xiaomi, Tecno, Infinix, Huawei, Samsung…), il faut en plus
  désactiver l'optimisation de batterie : Paramètres → « Désactiver l'optimisation de batterie ».
- **targetSdk 34** : volontaire. À partir de 35, Android limite ce type de service à 6 h par jour.
- **Droits** : ne téléchargez que des contenus que vous avez le droit de télécharger.
