# MTN Box Manager — Flutter / Dart

Application Android Flutter de suivi local pour un routeur MTN 4G en Côte d’Ivoire.

## Ce que contient le projet

- Interface sombre premium, adaptée au mobile.
- Tableau de bord du volume renseigné, du budget et des raccourcis.
- Historique local des consommations et graphique sur 7 mesures.
- Historique manuel des recharges (FCFA et Go).
- Réglage de l’adresse locale du routeur.
- Ouverture de l’interface d’administration du routeur dans l’application.
- Intégration des actions du script d’administration fourni : lecture de la liste des appareils, blocage/déblocage par adresse MAC et demande de redémarrage lorsque l’API du routeur les expose.
- Source JavaScript du panneau d’administration conservée dans `assets/router/router_admin.js` ; l’application réutilise la session de l’interface officielle, sans contourner la connexion.
- Conservation locale des paramètres avec `shared_preferences`.
- Alertes dans l’application selon les valeurs saisies.

## Limite importante : compatibilité du routeur

Le routeur est un MTN CPE modèle R023 (étiquette : IP 192.168.1.1). Aucune API documentée de ce modèle n’a été confirmée, donc les données restent saisies manuellement.

L’application **n’invente pas** de données réelles :
- la consommation et le volume du forfait sont des valeurs saisies manuellement ;
- les commandes Appareils et Redémarrer utilisent les fonctions `callJSON`/`postJSON` de la page du routeur après connexion ; elles ne fonctionneront que si le firmware chargé expose ces fonctions et les mêmes endpoints ;
- la modification du nom/mot de passe Wi-Fi se fait encore dans la page d’administration du routeur ;
- l’application ne confirme un blocage que si l’API retourne `result: success` ; un redémarrage peut couper la connexion avant qu’une réponse arrive ;
- les recharges sont enregistrées comme historique local, elles ne déclenchent aucun achat.

Pour MTN HomeBox, le portail officiel peut être accessible depuis le Wi-Fi du box à `moninternet.mtn.ci`. Les offres peuvent changer ; consulte les informations officielles avant d’acheter un forfait.

## Prérequis

- Flutter SDK stable installé
- Android Studio ou Android SDK
- Un téléphone Android ou un émulateur
- Le téléphone connecté au Wi-Fi du routeur pour ouvrir son administration

## Démarrage

Dans un terminal, à la racine du projet :

```bash
flutter doctor
flutter pub get
flutter run
```

Pour générer un APK :

```bash
flutter build apk --release
```

L’APK est normalement généré dans :

`build/app/outputs/flutter-apk/app-release.apk`

Pour un APK universel plus volumineux, cette commande est déjà la bonne par défaut. Tu peux aussi produire des APK séparés par architecture avec :

```bash
flutter build apk --split-per-abi
```

## Adresse d’administration

L’adresse par défaut est maintenant `http://192.168.1.1`, d’après l’étiquette du routeur **MTN CPE modèle R023**. Elle reste modifiable dans Réglages.

Le mot de passe administrateur n’est pas demandé ni stocké par l’application : saisis-le uniquement dans l’interface du routeur.

## Contrôles réellement disponibles

| Fonction | État dans ce projet |
|---|---|
| Tableau de bord | Fonctionnel avec valeurs locales |
| Historique et graphique | Fonctionnel avec mesures saisies |
| Historique des recharges | Fonctionnel en local |
| Alertes de seuil | Déclenchées lors de l’enregistrement des valeurs |
| Ouvrir l’interface du routeur | Fonctionnel si adresse et réseau accessibles |
| Consommation en direct | Non intégrée sans interface compatible confirmée |
| Liste d’appareils en direct | Intégrée si l’API `device_management_info` est disponible |
| Bloquer/débloquer un appareil | Intégré si l’API `device_management_set` est disponible |
| Modifier SSID/mot de passe Wi-Fi | Via l’interface du routeur si prise en charge |
| Redémarrage à distance | Intégré si l’API `device_restart` est disponible |

## Prochaine étape pour l’automatisation

Le script fourni révèle une API de type `xml_action.cgi` et des commandes `device_management_info`, `device_management_set` et `device_restart`. Leur présence dans ce script ne garantit pas que le firmware de ton MTN CPE R023 utilise les mêmes endpoints. Connecte-toi d’abord à l’interface depuis l’application, puis teste les commandes. Si elles ne répondent pas, il faudra identifier le firmware exact plutôt que prétendre que les actions ont réussi.

## Référence

- MTN Côte d’Ivoire — HomeBox : https://www.mtn.ci/deal/homebox/
- MTN Côte d’Ivoire — MTN HomeBox : https://www.mtn.ci/deal/mtn-homebox/
- Assistance Huawei — gestion des appareils : https://consumer.huawei.com/en/support/content/en-us15806342/
