import 'package:flutter_test/flutter_test.dart';
import 'package:mtn_box_manager/main.dart';

void main() {
  testWidgets('L’application affiche son tableau de bord', (tester) async {
    await tester.pumpWidget(const MtnBoxApp());
    await tester.pumpAndSettle();
    expect(find.text('MTN BOX'), findsOneWidget);
  });
}
