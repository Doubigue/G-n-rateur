function clearErrorInfo() {
    $("input[type='text'],input[type='username']").mousedown(function () {
        $(".error").text("").hide();
    });
    $("input[type='text'],input[type='password']").mousedown(function () {
        $(".error").text("").hide();
    });
    $("select").change(function () {
        $(".error").text("").hide();
    });
    $('input[type="radio"]').click(function () {
        $(".error").text("").hide();
    });
    $('input[type="checkbox"]').click(function () {
        $(".error").text("").hide();
    });
}
// -------------------------------------------------------------xml-help.js-----------------------------------------------------------------

(function ($) {
    $.fn.XML_Operations = function () {
        var text = '<?xml version="1.0" encoding="US-ASCII"?>';
        // Opera implicitly add the xml tag so no need to do it again.
        if (window.opera) text = "";
        this.getXMLDOC = function () {
            var xmlDoc;
            if (window.DOMParser) {
                parser = new DOMParser();
                xmlDoc = parser.parseFromString("<RGW></RGW>", "text/xml");
            } else {
                // Internet Explorer
                xmlDoc = new ActiveXObject("Microsoft.XMLDOM");
                xmlDoc.async = "false";
                xmlDoc.loadXML("<RGW></RGW>");
            }
            return xmlDoc;
        };
        this.getXMLDOCVersion = function (text) {
            var xmlDoc;
            if (window.DOMParser) {
                parser = new DOMParser();
                xmlDoc = parser.parseFromString(text, "text/xml");
            } else {
                // Internet Explorer
                xmlDoc = new ActiveXObject("Microsoft.XMLDOM");
                xmlDoc.async = "false";
                xmlDoc.loadXML(text);
            }
            return xmlDoc;
        };
        this.getInternetExplorerVersion = function () {
            var rv = -1; // Return value assumes failure.
            if (navigator.appName == "Microsoft Internet Explorer") {
                var ua = navigator.userAgent;
                var re = new RegExp("MSIE ([0-9]{1,}[.0-9]{0,})");
                if (re.exec(ua) != null) rv = parseFloat(RegExp.$1);
            }
            return rv;
        };
        this.getXMLDocToString = function (oXML) {
            var xmlString = "";

            if (window.ActiveXObject) {
                var ver = g_objXML.getInternetExplorerVersion();
                if (ver > -1) {
                    if (ver <= 8.0) xmlString = oXML.xml;
                    else xmlString = new XMLSerializer().serializeToString(oXML);
                }
            } else {
                xmlString = new XMLSerializer().serializeToString(oXML);
            }
            return text + " " + xmlString;
        };
        this.createNode = function (xmlDoc, parent, element, value) {
            var newel = xmlDoc.createElement(element);
            if (value != null) {
                var _value = xmlDoc.createTextNode(value);
                newel.appendChild(_value);
            }
            var _element = xmlDoc.getElementsByTagName(parent);
            _element[0].appendChild(newel);
            return xmlDoc;
        };

        this.createItemNode = function (xmlDoc, parent, element, value, index) {
            var newel = xmlDoc.createElement(element);
            if (value != null) {
                // var _value = xmlDoc.createTextNode(value);
                //  newel.appendChild(_value);
                newel.setAttribute("index", index);
            }
            var _element = xmlDoc.getElementsByTagName(parent);

            _element[0].appendChild(newel);
            return xmlDoc;
        };
        this.createDeleteNode = function (xmlDoc, parent, element, value, index) {
            var newel = xmlDoc.createElement(element);
            if (value != null) {
                var _value = xmlDoc.createTextNode(value);
                newel.appendChild(_value);
                newel.setAttribute("Delete", 1);
            }
            var _element = xmlDoc.getElementsByTagName(parent);

            _element[0].appendChild(newel);
            return xmlDoc;
        };

        this.childExist = function (xmlDoc, child) {
            var _element = xmlDoc.getElementsByTagName(child);
            if (_element[0] != null) return true;
            else return false;
        };
        this.createXML = function (controlMap) {
            var xmlDoc = this.getXMLDOC(text);
            for (var i = 0; i < controlMap.length; i++) {
                var j;
                if (controlMap[i] != null) {
                    var token = controlMap[i][0].split("/");
                    for (j = 0; j < token.length - 1; j++) if (!g_objXML.childExist(xmlDoc, token[j])) xmlDoc = g_objXML.createNode(xmlDoc, token[j - 1], token[j], null);

                    if (token[j].indexOf("#index") != -1) {
                        var cNode = token[j].substring(0, token[j].indexOf("#index"));
                        xmlDoc = g_objXML.createItemNode(xmlDoc, token[j - 1], cNode, controlMap[i][1], i);
                    } else if (token[j].indexOf("#delete") != -1) {
                        var deleteNode = token[j].substring(0, token[j].indexOf("#delete"));
                        xmlDoc = g_objXML.createDeleteNode(xmlDoc, token[j - 1], deleteNode, controlMap[i][1], i);
                    } else {
                        xmlDoc = g_objXML.createNode(xmlDoc, token[j - 1], token[j], controlMap[i][1]);
                    }
                }
            }
            return xmlDoc;
        };
        this.putMapElement = function (controlMap, index, path, value) {
            controlMap[index] = new Array(2);
            controlMap[index][0] = path;
            controlMap[index][1] = value;
            return controlMap;
        };
        this.copyArray = function (controlMapExisting, controlMapCurrent) {
            for (var i = 0; i < controlMapExisting.length; i++) {
                controlMapCurrent[i] = new Array(2);
                controlMapCurrent[i][0] = controlMapExisting[i][0];
                controlMapCurrent[i][1] = controlMapExisting[i][1];
            }
            return controlMapCurrent;
        };
        this.getChangedArray = function (controlMapExisting, _controlMap, flagDoChanges) {
            var tempArray = new Array(0);
            var index = 0;
            for (var i = 0; i < controlMapExisting.length; i++)
                if (controlMapExisting[i][1] != _controlMap[i][1]) {
                    tempArray[index] = new Array(2);
                    tempArray[index] = _controlMap[i];
                    if (flagDoChanges) controlMapExisting[i] = _controlMap[i];
                    index++;
                }
            return tempArray;
        };

        return this.each(function () {});
    };
})(jQuery);
var g_objXML = $().XML_Operations();
var g_objContent = null;
function getData(XML_Path) {
    return callProductXML(XML_Path);
}
function showAlert(message) {
    sm("alertMB", 350, 150);
    document.getElementById("lAlertMessage").innerHTML = message;
    document.getElementById("lAlert").innerHTML = jQuery.i18n.prop("lAlert");
    //document.getElementById("btnModalOk").innerHTML = jQuery.i18n.prop("btnModalOk");
    buttonLocaliztion("btnModalOk");
}
function putMapElement(controlMap, path, value, index) {
    controlMap[index] = new Array(2);
    controlMap[index][0] = path;
    controlMap[index][1] = value;
    return controlMap;
}
function buttonLocaliztion(buttonID) {
    document.getElementById(buttonID).value = jQuery.i18n.prop(buttonID);
}
function postXML(xmlName, xmlData, timeOutInterval, bHideWaitBox) {
    //document.getElementById("loadingdivimage").style.display = "block";
    if (undefined == bHideWaitBox) bHideWaitBox = false;
    if (timeOutInterval == undefined) timeOutInterval = 360000;
    if (xmlName != "locale" && !bHideWaitBox) {
        sm("PleaseWait", 150, 100);
        $("#lPleaseWait").text(jQuery.i18n.prop("h1PleaseWait"));
    }
    resetInterval();
    var url = "";
    var host = window.location.protocol + "//" + window.location.host + "/";
    url = host + "xml_action.cgi?method=set&module=duster&file=" + xmlName;
    if (devEnv == "1") alert(xmlData);
    $.ajax({
        type: "POST",
        beforeSend: function (xhr) {
            xhr.setRequestHeader("Authorization", getAuthHeader("POST"));
        },
        url: url,
        processData: false,
        data: xmlData,
        async: true,
        dataType: "xml",
        timeout: timeOutInterval,
        success: function (data, textStatus) {
            if (xmlName != "locale" && !bHideWaitBox) {
                hm();
            }

            if ($(data).find("login_status").text() == "UNAUTHORIZED") {
                clearAuthheader();
            }
        },
        complete: function (XMLHttpRequest, textStatus) {
            if (xmlName != "locale" && !bHideWaitBox) {
                hm();
            }
            //  if(null == g_InternetConnectionObj && null == g_PrimaryNetworkObj){
            //     g_objContent.onPostSuccess();
            //  }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            if (xmlName != "locale" && !bHideWaitBox) {
                hm();
            }
            // alert("In Error:" + textStatus);
            if (textStatus != "timeout") showAlert(jQuery.i18n.prop("lErrorPost"));
            else showAlert(jQuery.i18n.prop("lErrorTimeOut"));
        },
    });

    return true;
}
function webdav_postXML(xmlName, xmlData, timeOutInterval) {
    //document.getElementById("loadingdivimage").style.display = "block";
    if (timeOutInterval == undefined) timeOutInterval = 360000;
    //if(xmlName != "locale") {
    //    sm("PleaseWait",150,100);
    //     $("#lPleaseWait").text(jQuery.i18n.prop("h1PleaseWait"));
    // }
    resetInterval();
    var url = "";
    var host = window.location.protocol + "//" + window.location.host + "/";
    url = host + "xml_action.cgi?method=set&module=duster&file=" + xmlName;
    if (devEnv == "1") alert(xmlData);
    $.ajax({
        type: "POST",
        beforeSend: function (xhr) {
            xhr.setRequestHeader("Authorization", getAuthHeader("POST"));
        },
        url: url,
        processData: false,
        data: xmlData,
        async: true,
        dataType: "xml",
        timeout: timeOutInterval,
        success: function (data, textStatus) {
            showAlert(jQuery.i18n.prop("lsharesettingresultsuc"));
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            if (XMLHttpRequest.status == 200) {
                showAlert(jQuery.i18n.prop("lsharesettingresultsuc"));
            } else {
                showAlert(jQuery.i18n.prop("lsharesettingresultsuc"));
            }
        },
    });

    return true;
}
function callProductXML(xmlName) {
    if (xmlName != "device_date") resetInterval();
    var url = "";
    var content;
    var host = window.location.protocol + "//" + window.location.host + "/";
    url = host + "xml_action.cgi?method=get&module=duster&file=" + xmlName;
    // alert(url);
    if (devEnv == "0") {
        content = $.ajax({
            type: "GET",
            beforeSend: function (xhr) {
                xhr.setRequestHeader("Authorization", getAuthHeader("GET"));
            },
            url: url,
            dataType: "xml",
            async: false,
        }).responseXML;
    } else {
        xmlName = "xml/" + xmlName + ".xml";
        content = $.ajax({
            type: "GET",
            url: xmlName,
            dataType: "xml",
            contentType: "text/xml;charset=UTF-8",
            async: false,
        }).responseXML;
    }
    var login_text = $(content).find("login_status").text();
    if (login_text == "UNAUTHORIZED") {
        clearAuthheader();
        return null;
    }

    if ("KICKOFF" == $(content).find("login_status").text()) {
        showAlert(jQuery.i18n.prop("lKickOffUser"));
        clearAuthheader();
        return null;
    }

    return content;
}
function callProductHTML(htmlName) {
    //setTimeout ( "calculateAuthheader()", 6);
    resetInterval();
    var content;
    if (username == "admin") {
        content = $.ajax({
            type: "GET",
            url: htmlName,
            dataType: "html",
            timeout: 30000,
            async: false,
        }).responseText;
    } else {
        content = $.ajax({
            type: "GET",
            beforeSend: function (xhr) {
                xhr.setRequestHeader("Authorization", getAuthHeader("GET"));
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                if (null != g_objContent) {
                    g_objContent.onLoad(true);
                }
            },
            url: htmlName,
            dataType: "html",
            timeout: 30000,
            async: false,
        }).responseText;
    }

    if (content.indexOf("E7683FTEFTA8HT08HFH09") > 0) {
        clearAuthheader();
        return null;
    } else return content;
}

function callProductXML_webdavshare(xmlName) {
    if (xmlName != "device_date") resetInterval();
    var url = "";
    var content;
    var host = window.location.protocol + "//" + window.location.host + "/";
    url = host + "xml_action.cgi?method=get&module=duster&file=" + xmlName + Date.parse(new Date());
    // alert(url);
    if (devEnv == "0") {
        content = $.ajax({
            type: "GET",
            beforeSend: function (xhr) {
                xhr.setRequestHeader("Authorization", getAuthHeader("GET"));
            },
            url: url,
            dataType: "xml",
            async: false,
        }).responseXML;
    } else {
        xmlName = "xml/" + xmlName + ".xml";
        content = $.ajax({
            type: "GET",
            url: xmlName,
            dataType: "xml",
            contentType: "text/xml;charset=UTF-8",
            async: false,
        }).responseXML;
    }
    var login_text = $(content).find("login_status").text();
    return content;
}

function WebDav_PropfindSyncXML(xmlName, xmlData) {
    var host = window.location.protocol + "//" + window.location.host;
    var xmlNametemp = xmlName;
    var url = host + xmlNametemp;
    var content;
    //resetInterval();
    content = $.ajax({
        type: "PROPFIND",
        beforeSend: function (xhr) {
            xhr.setRequestHeader("Authorization", webdav_getAuthHeader("PROPFIND"));
            xhr.setRequestHeader("Depth", "1");
        },
        url: url,
        dataType: "xml",
        contentType: "text/xml;charset=UTF-8",
        //timeout: 60000,
        data: xmlData,
        async: false,
    }).responseText;

    //var login_text  = $(content).find("login_status").text();
    return content;
}
function WebDav_Options() {
    var host = window.location.protocol + "//" + window.location.host;
    var xmlNametemp = xmlName;
    var url = host + "/";
    var content;
    //resetInterval();
    content = $.ajax({
        type: "OPTIONS",
        beforeSend: function (xhr) {
            xhr.setRequestHeader("Authorization", webdav_getAuthHeader("OPTIONS"));
        },
        url: url,
        dataType: "xml",
        contentType: "text/xml;charset=UTF-8",
        //timeout: 60000,
        //data: xmlData,
        async: false,
    }).responseText;

    //var login_text  = $(content).find("login_status").text();
    return content;
}
function WebDav_Shared_PropfindSyncXML(xmlName, xmlData) {
    var host = window.location.protocol + "//" + window.location.host;
    var xmlNametemp = xmlName;
    var url = host + xmlNametemp;
    var content;
    //resetInterval();
    content = $.ajax({
        type: "PROPFIND",
        beforeSend: function (xhr) {
            xhr.setRequestHeader("Depth", "1");
        },
        url: url,
        dataType: "xml",
        contentType: "text/xml;charset=UTF-8",
        //timeout: 60000,
        data: xmlData,
        async: false,
    }).responseText;
    //var login_text  = $(content).find("login_status").text();
    return content;
}

function WebDav_GetSyncXML(xmlName, ContentType) {
    // sm("PleaseWait", 150, 100);
    // $("#lPleaseWait").text(jQuery.i18n.prop("h1PleaseWait"));
    showWait();

    var host = window.location.protocol + "//" + window.location.host;
    //var xmlNametemp=encodeURIComponent(xmlName);
    var xmlNametemp = xmlName;
    var url = host + xmlNametemp;
    var content;
    //resetInterval();
    content = $.ajax({
        type: "Get",
        beforeSend: function (xhr) {
            xhr.setRequestHeader("Authorization", webdav_getAuthHeader("GET"));
            xhr.setRequestHeader("Content-Type", ContentType);
        },
        url: url,
        //dataType: "xml",
        //contentType: ContentType,
        //timeout: 60000,
        //data: xmlData,
        async: true,
        success: function (data, textStatus) {
            closeWait();
        },
        complete: function (XMLHttpRequest, textStatus) {
            closeWait();
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            closeWait();
        },
    }).responseXML;
    //var login_text  = $(content).find("login_status").text();

    return content;
}

function WebDav_Shared_GetSyncXML(xmlName, ContentType) {
    // sm("PleaseWait", 150, 100);
    // $("#lPleaseWait").text(jQuery.i18n.prop("h1PleaseWait"));
    showWait();

    var host = window.location.protocol + "//" + window.location.host;
    //var xmlNametemp=encodeURIComponent(xmlName);
    var xmlNametemp = xmlName;
    var url = host + xmlNametemp;
    var content;
    //resetInterval();
    content = $.ajax({
        type: "Get",
        beforeSend: function (xhr) {
            xhr.setRequestHeader("Content-Type", ContentType);
        },
        url: url,
        //dataType: "xml",
        //contentType: ContentType,
        //timeout: 60000,
        //data: xmlData,
        async: true,
        success: function (data, textStatus) {
            closeWait();
        },
        complete: function (XMLHttpRequest, textStatus) {
            closeWait();
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            closeWait();
        },
    }).responseXML;
    //var login_text  = $(content).find("login_status").text();
    return content;
}

function WebDav_DeleteSyncXML(xmlName) {
    var host = window.location.protocol + "//" + window.location.host;
    //var xmlNametemp=encodeURIComponent(xmlName);
    var xmlNametemp = xmlName;
    var url = host + xmlNametemp;
    var content;
    //resetInterval();
    content = $.ajax({
        type: "DELETE",
        beforeSend: function (xhr) {
            xhr.setRequestHeader("Authorization", webdav_getAuthHeader("DELETE"));
        },
        url: url,
        //dataType: "xml",
        //contentType: ContentType,
        //timeout: 60000,
        //data: xmlData,
        async: false,
    }).responseXML;
    //var login_text  = $(content).find("login_status").text();
    return content;
}

function WebDav_Shared_DeleteSyncXML(xmlName) {
    var host = window.location.protocol + "//" + window.location.host;
    //var xmlNametemp=encodeURIComponent(xmlName);
    var xmlNametemp = xmlName;
    var url = host + xmlNametemp;
    var content;
    //resetInterval();
    content = $.ajax({
        type: "DELETE",
        beforeSend: function (xhr) {},
        url: url,
        //dataType: "xml",
        //contentType: ContentType,
        //timeout: 60000,
        //data: xmlData,
        async: false,
    }).responseXML;
    //var login_text  = $(content).find("login_status").text();
    return content;
}

function WebDav_MkdirSyncXML(xmlName) {
    var host = window.location.protocol + "//" + window.location.host;
    var xmlNametemp = xmlName;
    var url = host + xmlNametemp;
    var content;
    //resetInterval();
    content = $.ajax({
        type: "MKCOL",
        beforeSend: function (xhr) {
            xhr.setRequestHeader("Authorization", webdav_getAuthHeader("MKCOL"));
        },
        url: url,
        //dataType: "xml",
        //contentType: ContentType,
        //timeout: 60000,
        //data: xmlData,
        async: false,
    }).responseXML;
    //var login_text  = $(content).find("login_status").text();
    return content;
}

function WebDav_Shared_MkdirSyncXML(xmlName) {
    var host = window.location.protocol + "//" + window.location.host;
    var xmlNametemp = xmlName;
    var url = host + xmlNametemp;
    var content;
    //resetInterval();
    content = $.ajax({
        type: "MKCOL",
        beforeSend: function (xhr) {
            //xhr.setRequestHeader("Authorization",getAuthHeader("MKCOL"));
        },
        url: url,
        //dataType: "xml",
        //contentType: ContentType,
        //timeout: 60000,
        //data: xmlData,
        async: false,
    }).responseXML;
    //var login_text  = $(content).find("login_status").text();
    return content;
}

function WebDav_PutSyncXML(xmlName, FileType, FileDataFrom, FileDataTo, FileDataTotal, FileData) {
    var host = window.location.protocol + "//" + window.location.host;
    var xmlNametemp = xmlName;
    var url = host + xmlNametemp;
    var content;
    content = $.ajax({
        type: "PUT",
        processData: false,
        contentType: false,
        xhr: function () {
            var xhr = $.ajaxSettings.xhr();
            if (!xhr.sendAsBinary) {
                xhr.legacySend = xhr.send;
                xhr.sendAsBinary = function (string) {
                    var bytes = Array.prototype.map.call(string, function (c) {
                        return c.charCodeAt(0) & 0xff;
                    });
                    this.legacySend(new Uint8Array(bytes).buffer);
                };
            }
            xhr.send = xhr.sendAsBinary;
            return xhr;
        },
        beforeSend: function (xhr) {
            xhr.setRequestHeader("Authorization", webdav_getAuthHeader("PUT"));
            xhr.setRequestHeader("Content-Type", FileType);
            if (FileDataFrom != 0) {
                xhr.setRequestHeader("Content-Range", "bytes" + FileDataFrom + "-" + FileDataTo + "/" + FileDataTotal);
            }
        },

        url: url,
        //dataType: "xml",
        //timeout: 60000,
        data: FileData,
        async: true,
        success: function (data, textStatus) {
            //WebDav_Upload_Ondoing();
        },
        complete: function (XMLHttpRequest, textStatus) {
            WebDav_Upload_Ondoing();
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            WebDav_Upload_Ondoing();
        },
    }).responseXML;
    return content;
}

function WebDav_Shared_PutSyncXML(xmlName, FileType, FileDataFrom, FileDataTo, FileDataTotal, FileData) {
    var host = window.location.protocol + "//" + window.location.host;
    var xmlNametemp = xmlName;
    var url = host + xmlNametemp;
    var content;
    content = $.ajax({
        type: "PUT",
        processData: false,
        contentType: false,
        xhr: function () {
            var xhr = $.ajaxSettings.xhr();
            if (!xhr.sendAsBinary) {
                xhr.legacySend = xhr.send;
                xhr.sendAsBinary = function (string) {
                    var bytes = Array.prototype.map.call(string, function (c) {
                        return c.charCodeAt(0) & 0xff;
                    });
                    this.legacySend(new Uint8Array(bytes).buffer);
                };
            }
            xhr.send = xhr.sendAsBinary;
            return xhr;
        },
        beforeSend: function (xhr) {
            //xhr.setRequestHeader("Authorization",getAuthHeader("PUT"));
            xhr.setRequestHeader("Content-Type", FileType);
            if (FileDataFrom != 0) {
                xhr.setRequestHeader("Content-Range", "bytes" + FileDataFrom + "-" + FileDataTo + "/" + FileDataTotal);
            }
        },

        url: url,
        //dataType: "xml",
        //timeout: 60000,
        data: FileData,
        async: true,
        success: function (data, textStatus) {
            //WebDav_Upload_Ondoing();
        },
        complete: function (XMLHttpRequest, textStatus) {
            WebDav_Shared_Upload_Ondoing();
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            WebDav_Shared_Upload_Ondoing();
        },
    }).responseXML;
    return content;
}

function WebDav_PostSyncXML(xmlName, xmlData) {
    //var host = window.location.protocol + "//" + window.location.host + "/";
    // var url = host +  xmlName;
    var url = "";
    var host = window.location.protocol + "//" + window.location.host + "/";
    url = host + "xml_action.cgi?method=set&module=duster&file=" + xmlName;
    content = $.ajax({
        type: "POST",
        beforeSend: function (xhr) {
            xhr.setRequestHeader("Authorization", getAuthHeader("POST"));
        },
        url: url,
        processData: false,
        dataType: "xml",
        contentType: "text/xml;charset=UTF-8",
        //timeout: 60000,
        data: xmlData,
        async: false,
        success: function (data, textStatus) {
            showAlert(jQuery.i18n.prop("lsharesettingresultsuc"));
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            if (XMLHttpRequest.status == 200) {
                showAlert(jQuery.i18n.prop("lsharesettingresultsuc"));
            } else {
                showAlert(jQuery.i18n.prop("lsharesettingresultfal"));
            }
        },
    });
    return true;
}
// ------------------------index.js-------------------------
function setLocale(value) {
    var jsonData = "";
    if (value == "en") {
        jsonData = { language: "en" };
    } else {
        jsonData = { language: "cn" };
    }
    $("#lloginfailed").hide();
    postJSONlocale("locale_set", jsonData);
    setLocalization(value);
    LANGUAGE = value;
    displayControls();
}

function i18n_func() {
    $("[id^='lt_']").each(function () {
        id = $(this).attr("id");
        if (document.getElementById(id) && document.getElementById(id).tagName && document.getElementById(id).tagName.toLowerCase() == "input") {
            $(this).val(jQuery.i18n.prop(id));
        } else {
            $(this).html(jQuery.i18n.prop(id));
        }
    });
}

function startWith(str, start) {
    if (str.indexOf(start) == 0) {
        return true;
    }
    return false;
}

function displayControls() {
    document.title = jQuery.i18n.prop("lTitle");
    document.getElementById("btnSignIn").value = jQuery.i18n.prop("btnSignIn");
    $("#lt_quickSetup").html(jQuery.i18n.prop("lt_quickSetup"));
    $("#lt_modify_psw").html(jQuery.i18n.prop("lt_modify_psw"));
    $("#lt_logout").html(jQuery.i18n.prop("LogOutName"));
    document.getElementById("lt_lacopyright").innerHTML = jQuery.i18n.prop("lt_lacopyright");
    $("#texUer").prop("placeholder", jQuery.i18n.prop("laUsername"));
    $("#texPsw").prop("placeholder", jQuery.i18n.prop("laPassword"));
    $("#networkType").prop("title", jQuery.i18n.prop("networkTypeTitle"));
    $("#operator").prop("title", jQuery.i18n.prop("operatorTitle"));
    $("#signal_strength").prop("title", jQuery.i18n.prop("signal_strengthTitle"));
    $("#connection_status").prop("title", jQuery.i18n.prop("connection_statusTitle"));
    $("#sms_unread_count").prop("title", jQuery.i18n.prop("sms_unread_countTitle"));
    $("#battery").prop("title", jQuery.i18n.prop("batteryTitle"));
    $("#wifi_status").prop("title", jQuery.i18n.prop("wifi_statusTitle"));
}

function sharefile() {
    document.getElementById("indexContainer").style.width = "1000px";
    document.getElementById("indexContainer").innerHTML = callProductHTML("WebDav/WebDav_Share.html");
    document.getElementById("lTitleShareFile").innerHTML = jQuery.i18n.prop("lTitleShareFile");
    document.getElementById("ShareFileBack").innerHTML = jQuery.i18n.prop("ShareFileBack");
    ShareFileShowInit();
}
var g_loginUsername;
var pop = true;
function Login() {
    var username = encodeURIComponent(document.getElementById("texUer").value);
    var password = encodeURIComponent(document.getElementById("texPsw").value);
    var login_done;

    if (username == "" || password == "") login_done = 0;
    else login_done = doLogin(username, password);
    //login_done = 1;
    if (login_done == 1) {
        document.getElementById("container").innerHTML = CallHtmlFile("html/adminApp.html");
        setDlgStyle();
        var g_pwdstrength;
        g_pwdstrength = checkPWStrength(password);
        initAPP(g_pwdstrength);

        $("#loginShow").show();
        $("#language").hide();
        $("#logo2").hide();
        $("#statusBar").show();
        // $("#headLogo").show();
        $("#manageBar").css("marginTop", "0px");
        $("#indexContainer").removeClass("login-page-bg");
        setDlgStyle();
        checkUpgrade();
        $.objAdmin().onLoad(true);
        g_loginUsername = username;
        g_loginPasswd = password;
        if (isLoginTimer) {
            clearInterval(isLoginTimer);
        }
        isLoginTimer = setInterval(function () {
            callJSON(
                "login_info",
                function (json) {
                    var login_status = json.login_status;
                    if (login_status != "1") {
                        window.location.href = "index.html";
                    }
                },
                "1"
            );
        }, 10000);
        statusSbar();
        statusOnClick();
        setInterval(function () {
            statusSbar();
        }, 5000);
    } else {
        $("#loginShow").hide();
        $("#language").show();
        $("#logo2").show();
        $("#statusBar").hide();
        $("#m_statusBar").hide();
        $("#indexContainer").addClass("login-page-bg");
        $("#manageBar").css("marginTop", "-36px");
        document.getElementById("lloginfailed").style.display = "block";
        if (login_done == 0) document.getElementById("lloginfailed").innerHTML = jQuery.i18n.prop("lloginfailed");
        else if (login_done == -1) document.getElementById("lloginfailed").innerHTML = jQuery.i18n.prop("lnoconn");
    }
}

function initAPP(strength) {
    //initmb();
    // setDlgStyle();
    if (("" == GetCookie("showChangePaw") || "0" == GetCookie("showChangePaw")) && strength == MACRO_PASSWORD_LOW) {
        showPawChangeBox();
        $("#lt_changepwd_Text").text(jQuery.i18n.prop("lt_changepwd_Text"));
        $("#lt_changepwd_tip").text(jQuery.i18n.prop("lt_changepwd_tip"));
        $("#lt_changepwd_noRemind").text(jQuery.i18n.prop("lt_changepwd_noRemind"));
        $("#lt_btn_nowchange").val(jQuery.i18n.prop("lt_btn_nowchange"));
        $("#lt_btn_latterchange").val(jQuery.i18n.prop("lt_btn_latterchange"));
        document.getElementById("quickSetupSpan").innerHTML = jQuery.i18n.prop("quickSetupName");
        document.getElementById("MainHelp").innerHTML = jQuery.i18n.prop("helpName");
        document.getElementById("MainLogOut").innerHTML = jQuery.i18n.prop("LogOutName");

        $("#RemindBox").change(function () {
            var isSelect = 0;
            if ($(this).prop("checked")) {
                isSelect = 1;
            }
            SetCookie("showChangePaw", isSelect, 365);
        });
    } else {
        checkUpgrade();
        $.objAdmin().onLoad(true);
    }
}
function btnChangeLate() {
    CloseDlg();
    checkUpgrade();
    $.objAdmin().onLoad(true);
}
function btnChangePwd() {
    CloseDlg();
    displaySubMenu(7, true);
    /*$.objAdmin().onLoad(true);
	var attrName = '<a name="'+g_loginUsername+'">'+g_loginUsername+'</a>'
	setTimeout(function(){
		AccountClicked(attrName)
	},500)*/
}

var MACRO_PASSWORD_LOW = "low";
var MACRO_PASSWORD_MID = "mid";
var MACRO_PASSWORD_HIG = "hig";
function checkPWStrength(passValue) {
    function charMode(iN) {
        if (iN >= 48 && iN <= 57) {
            return 1;
        } else if ((iN >= 65 && iN <= 90) || (iN >= 97 && iN <= 122)) {
            return 2;
        } else {
            return 4;
        }
    }

    function bitTotal(num) {
        var modes = 0;
        var i = 0;
        for (i = 0; i < 3; i++) {
            if (num & 1) {
                modes++;
            }
            num >>>= 1;
        }
        return modes;
    }
    var ret = 0;
    var sPWLength = passValue.length;
    var sPWModes = 0;
    var i = 0;
    for (i = 0; i < sPWLength; i++) {
        sPWModes |= charMode(passValue.charCodeAt(i));
    }
    sPWModes = bitTotal(sPWModes);
    if (sPWLength < 6 || (sPWModes == 1 && sPWLength < 10)) {
        ret = MACRO_PASSWORD_LOW;
    } else if ((sPWModes == 2 && sPWLength >= 6) || (sPWModes == 1 && sPWLength >= 10)) {
        ret = MACRO_PASSWORD_MID;
    } else if (sPWModes == 3 && sPWLength >= 6) {
        ret = MACRO_PASSWORD_HIG;
    } else {
        ret = MACRO_PASSWORD_LOW;
    }
    if (2 == arguments.length) {
        if (!String(passValue).localeCompare(arguments[1]) || !String(passValue).localeCompare(arguments[1].split("").reverse().join(""))) {
            ret = MACRO_PASSWORD_LOW;
        }
    }
    return ret;
}
function checkUpgrade() {
    callJSON(
        "fotaupgread_info",
        function (data) {
            if (data.fotaupgread == "1") {
                showBOX2(
                    jQuery.i18n.prop("lt_sms_note"),
                    jQuery.i18n.prop("pUpdatesAvailable"),
                    jQuery.i18n.prop("lt_ManualNet_btnConfirm"),
                    jQuery.i18n.prop("lt_btnCancel"),
                    function () {
                        ClosemBOX2();
                        var json = {};
                        json.fotaupgread = "1";
                        postJSON("fotaupgread_set", json, function (data1) {});
                    },
                    function () {
                        ClosemBOX2();
                        var json = {};
                        json.fotaupgread = "0";
                        postJSON("fotaupgread_set", json, function (data1) {});
                    }
                );
                pop = false;
            }
        },
        "1"
    );
    if (pop == true) {
        setTimeout(function () {
            checkUpgrade();
        }, 60000);
    }
}
function checkEnter(e) {
    var characterCode;
    if (e && e.which) {
        e = e;
        characterCode = e.which;
    } else {
        e = event;
        characterCode = e.keyCode;
    }
    if (characterCode == 13) {
        Login();
    }
}
function hideError() {
    document.getElementById("lloginfailed").style.display = "none";
}
var versionString;
var isLoginTimer = null;
var g_nav = "";
var g_leftSub = "";
function initIndex() {
    setTimeout(function () {
        if ("IE6" == GetBrowserType()) {
            var fileref = document.createElement("script");
            fileref.setAttribute("type", "text/javascript");
            fileref.setAttribute("src", "js/jquery/jquery.bgiframe.min.js");
            document.getElementsByTagName("head")[0].appendChild(fileref);
        }
        //document.getElementById("tbarouter_username").focus();

        callJSON("locale_info", function (data) {
            LANGUAGE = data.language;
            if (data.language == "en") {
                setLocalization("en");
            } else {
                setLocalization("cn");
            }
            $("#language").val(LANGUAGE);
            displayControls();
        });

        isLogin();
        setDlgStyle();
    }, 100);
}
function selectChange(type) {
    $("#language").change(function () {
        var value = $(this).val();
        var jsonData = "";
        if (value == "en") {
            jsonData = { language: "en" };
        } else {
            jsonData = { language: "cn" };
        }
        $("#lloginfailed").hide();
        postJSONlocale("locale_set", jsonData);
        setLocalization(value);
        LANGUAGE = value;

        callJSON("login_info", function (json) {
            var login_status = json.login_status;
            if (login_status == "1") {
                //Have login
                g_nav = GetCookie("nav");
                g_leftSub = GetCookie("leftSub");
                if (g_nav == "" || g_nav == undefined) {
                    type = "";
                } else {
                    type = "1";
                }
            } else {
                type = "";
            }
            if (type == "1") {
                $("#lt_modify_psw").html(jQuery.i18n.prop("lt_modify_psw"));
                $("#lt_quickSetup").html(jQuery.i18n.prop("lt_quickSetup"));
                $("#lt_logout").html(jQuery.i18n.prop("LogOutName"));
                document.getElementById("lt_lacopyright").innerHTML = jQuery.i18n.prop("lt_lacopyright");
                $.objAdmin().onLoad(true);
            } else {
                displayControls();
            }
        });
    });
}
function statusOnClick() {
    callJSON("homepage_info", function (json) {
        var pinStatus = json.pin_status;
        var simStatus = json.sim_status;
        $("#sms_unread_count").unbind("click");
        $("#sms_unread_count").bind("click", function () {
            if (simStatus == "1") {
                displaySubMenu(4, true, "nosim");
            } else if (pinStatus == "48") {
                displaySubMenu(4, true, "simLock");
            } else {
                displaySubMenu(4, true);
            }
        });
        $("#m_sms_unread_count").unbind("click");
        $("#m_sms_unread_count").bind("click", function () {
            if (simStatus == "1") {
                displaySubMenu(4, true, "nosim");
            } else if (pinStatus == "48") {
                displaySubMenu(4, true, "simLock");
            } else {
                displaySubMenu(4, true);
            }
        });
        $("#lt_modify_psw").unbind("click");
        $("#lt_modify_psw").bind("click", function () {
            if (simStatus == "1") {
                displaySubMenu(7, true, "nosim");
            } else if (pinStatus == "48") {
                displaySubMenu(7, true, "simLock");
            } else {
                displaySubMenu(7, true);
            }
        });
        $("#lt_quickSetup").unbind("click");
        $("#lt_quickSetup").bind("click", function () {
            if (simStatus == "1") {
                displaySubMenu(8, true, "nosim");
            } else if (pinStatus == "48") {
                displaySubMenu(8, true, "simLock");
            } else {
                displaySubMenu(8, true);
            }
        });
    });
}
function statusSbar() {
    callJSON("status_info", function (json) {
        if (json.unread_long != "0") {
            $("#sms_unread_count").show();
            $("#m_sms_unread_count").show();
            $("#sms_unread").attr("src", "images/sms_unread.png");
            $("#m_sms_unread").attr("src", "images/sms_unread.png");
            $("#newSmsNum").html(json.unread_long);
            $("#m_newSmsNum").html(json.unread_long);
        } else {
            $("#sms_unread_count").hide();
            $("#m_sms_unread_count").hide();
        }
        $("#wifiConnNum").html(json.wifi_clients_num);
        $("#m_wifiConnNum").html(json.wifi_clients_num);

        //signalShow(0);
        if (json.battery_connect == "0") {
            //var battery =document.getElementById('battery');
            //battery.style.display = 'none';
            document.getElementById("battery_level").className = "titlebattery0";
            document.getElementById("m_battery_level").className = "titlebattery0";
        } else {
            if (json.battery_charging == "1") {
                document.getElementById("battery_level").className = "titlebattery";
                document.getElementById("m_battery_level").className = "titlebattery";

                if (json.battery_charge == "1") {
                    var level = json.battery_percent;
                    var soc = parseInt(level);
                    if (json.battery_charge == 3 || json.battery_charge == 2) {
                        soc = 100;
                    } else {
                        soc = Math.ceil(level / 10) * 10;
                    }
                    if (soc >= 0 && soc < 20) {
                        //document.getElementById("battery_level").className = "titlebattery1";
                        document.getElementById("battery_percent").innerHTML = soc + "%";
                        document.getElementById("m_battery_percent").innerHTML = soc + "%";
                    } else if (20 <= soc && soc < 40) {
                        //document.getElementById("battery_level").className = "titlebattery2";
                        document.getElementById("battery_percent").innerHTML = soc + "%";
                        document.getElementById("m_battery_percent").innerHTML = soc + "%";
                    } else if (40 <= soc && soc < 80) {
                        //document.getElementById("battery_level").className = "titlebattery3";
                        document.getElementById("battery_percent").innerHTML = soc + "%";
                        document.getElementById("m_battery_percent").innerHTML = soc + "%";
                    } else if (80 <= soc && soc < 100) {
                        //document.getElementById("battery_level").className = "titlebattery4";
                        document.getElementById("battery_percent").innerHTML = soc + "%";
                        document.getElementById("m_battery_percent").innerHTML = soc + "%";
                    } else if (soc == 100) {
                        document.getElementById("battery_level").className = "titlebattery5";
                        document.getElementById("m_battery_level").className = "titlebattery5";
                        document.getElementById("battery_percent").innerHTML = "100%";
                        document.getElementById("m_battery_percent").innerHTML = "100%";
                    }
                } else if (json.battery_charge == "2") {
                    document.getElementById("battery_level").className = "titlebattery5";
                    document.getElementById("m_battery_level").className = "titlebattery5";
                    document.getElementById("battery_percent").innerHTML = "100%";
                    document.getElementById("m_battery_percent").innerHTML = "100%";
                } else if (json.battery_charge == "3") {
                    document.getElementById("battery_level").className = "titlebattery5";
                    document.getElementById("m_battery_level").className = "titlebattery5";
                    document.getElementById("battery_percent").innerHTML = "100%";
                    document.getElementById("m_battery_percent").innerHTML = "100%";
                }
            } else {
                var level = json.battery_percent;
                var soc = parseInt(level);
                if (json.battery_charge == 2) {
                    soc = 100;
                } else {
                    soc = Math.ceil(level / 10) * 10;
                }
                if (soc >= 0 && soc < 20) {
                    document.getElementById("battery_level").className = "titlebattery1";
                    document.getElementById("m_battery_level").className = "titlebattery1";
                    document.getElementById("battery_percent").innerHTML = soc + "%";
                    document.getElementById("m_battery_percent").innerHTML = soc + "%";
                } else if (20 <= soc && soc < 40) {
                    document.getElementById("battery_level").className = "titlebattery2";
                    document.getElementById("m_battery_level").className = "titlebattery2";
                    document.getElementById("battery_percent").innerHTML = soc + "%";
                    document.getElementById("m_battery_percent").innerHTML = soc + "%";
                } else if (40 <= soc && soc < 80) {
                    document.getElementById("battery_level").className = "titlebattery3";
                    document.getElementById("m_battery_level").className = "titlebattery3";
                    document.getElementById("battery_percent").innerHTML = soc + "%";
                    document.getElementById("m_battery_percent").innerHTML = soc + "%";
                } else if (80 <= soc && soc < 100) {
                    document.getElementById("battery_level").className = "titlebattery4";
                    document.getElementById("m_battery_level").className = "titlebattery4";
                    document.getElementById("battery_percent").innerHTML = soc + "%";
                    document.getElementById("m_battery_percent").innerHTML = soc + "%";
                } else if (soc == 100) {
                    document.getElementById("battery_level").className = "titlebattery5";
                    document.getElementById("m_battery_level").className = "titlebattery5";
                    document.getElementById("battery_percent").innerHTML = "100%";
                    document.getElementById("m_battery_percent").innerHTML = soc + "%";
                }
            }
        }
        //added by nt yecong 180516 for temp test
        //alert(Battery_voltage);

        //var level=json.Battery_voltage;

        // var roaming=json.roaming;
        var sys_mode = json.sys_mode;
        var rssi = parseInt(json.rssi);
        var sendSpeed = parseInt(json.tx_speed);
        var receivedSpeed = parseInt(json.rx_speed);
        callJSON("homepage_info", function (jsonOne) {
            if (jsonOne.sim_status == "0" && jsonOne.connect_disconnect == "cellular") {
                $("#connection_status").removeClass("iconDisconnect").addClass("iconConnect");
                $("#m_connection_status").removeClass("iconDisconnect").addClass("iconConnect");
            } else {
                $("#connection_status").removeClass("iconConnect").addClass("iconDisconnect");
                $("#m_connection_status").removeClass("iconConnect").addClass("iconDisconnect");
            }
            if (jsonOne.wlan_enable == "1") {
                document.getElementById("wifi_status").className = "titlewifi";
                document.getElementById("m_wifi_status").className = "titlewifi";
                $("#wifiConnNum").show();
                $("#m_wifiConnNum").show();
            } else {
                document.getElementById("wifi_status").className = "titlewifi1";
                document.getElementById("m_wifi_status").className = "titlewifi1";
                $("#wifiConnNum").hide();
                $("#m_wifiConnNum").hide();
            }
            var iccid = jsonOne.iccid.slice(0, 6);
            if (iccid == "898600" || iccid == "898602" || iccid == "898604" || iccid == "898607" || iccid == "898608" || iccid == "898613") {
                $("#operator").html(jQuery.i18n.prop("lt_yd"));
                $("#m_operator").html(jQuery.i18n.prop("lt_yd"));
            } else if (iccid == "898601" || iccid == "898606" || iccid == "898609") {
                $("#operator").html(jQuery.i18n.prop("lt_lt"));
                $("#m_operator").html(jQuery.i18n.prop("lt_lt"));
            } else if (iccid == "898603" || iccid == "898605" || iccid == "898611") {
                $("#operator").html(jQuery.i18n.prop("lt_dx"));
                $("#m_operator").html(jQuery.i18n.prop("lt_dx"));
            } else if (iccid == "898615") {
                $("#operator").html(jQuery.i18n.prop("lt_gd"));
                $("#m_operator").html(jQuery.i18n.prop("lt_gd"));
            } else {
                $("#operator").html(jsonOne.network_name);
                $("#m_operator").html(jsonOne.network_name);
            }
            //$("#operator").html(jsonOne.network_name);
            var pinStatus = jsonOne.pin_status;
            var simStatus = jsonOne.sim_status;
            var conn = jsonOne.connect_disconnect;

            if (pinStatus == "0" && simStatus == "0") {
                if (sys_mode == "3") {
                    $("#networkType").html("2G");
                    $("#m_networkType").html("2G");
                } else if (sys_mode == "5" || sys_mode == "15") {
                    $("#networkType").html("3G");
                    $("#m_networkType").html("3G");
                } else if (sys_mode == "17") {
                    $("#networkType").html("4G");
                    $("#m_networkType").html("4G");
                } else {
                    signalShow(0);
                    $("#networkType").html(jQuery.i18n.prop("lt_dashbd_NoService"));
                    $("#m_networkType").html(jQuery.i18n.prop("lt_dashbd_NoService"));
                }
            } else {
                $("#networkType").hide();
                $("#m_networkType").hide();
            }

            if (simStatus != "0") {
                signalShow(0);
                $("#networkType").hide();
                $("#m_networkType").hide();
                $("#operator").html(jQuery.i18n.prop("lt_SimAbsent"));
                $("#m_operator").html(jQuery.i18n.prop("lt_SimAbsent"));
                document.getElementById("statusItemSimStatus").className = "SimAbsent";
                document.getElementById("m_statusItemSimStatus").className = "SimAbsent";
                $("#connection_status").removeClass().addClass("iconDisconnect");
                $("#m_connection_status").removeClass().addClass("iconDisconnect");
            } else if (simStatus == "0") {
                document.getElementById("statusItemSimStatus").className = "SimPresent";
                document.getElementById("m_statusItemSimStatus").className = "SimPresent";
                if (pinStatus == "0") {
                    signalShow(parseInt(json.signal_quality));
                    // if (conn != "cellular") {//有卡未开启数据连接
                    //     //that.signalShow(0);
                    //     signalShow(parseInt(json.signal_quality));
                    //     $("#connection_status").removeClass().addClass("iconConnect3");
                    //     // $("#txtWifiSSID").html(json.ssid);
                    // } else if(conn == "cellular"&&simStatus=="0") {//有卡开启数据连接
                    //     if(sendSpeed>0&&receivedSpeed>0){
                    //         $("#connection_status").removeClass().addClass("iconConnect");
                    //     }else if(sendSpeed>0&&receivedSpeed<=0){
                    //         $("#connection_status").removeClass().addClass("iconConnect2");
                    //     }else if(sendSpeed<=0&&receivedSpeed>0){
                    //         $("#connection_status").removeClass().addClass("iconConnect1");
                    //     }else{
                    //         $("#connection_status").removeClass().addClass("iconConnect3");
                    //     }
                    // }
                } else if (pinStatus == "1") {
                    signalShow(0);
                    $("#operator").html("PIN");
                    $("#m_operator").html("PIN");
                    // $("#connection_status").removeClass().addClass("iconConnect3");
                } else if (pinStatus == "2") {
                    signalShow(0);
                    $("#operator").html("PUK");
                    $("#m_operator").html("PUK");
                    // $("#connection_status").removeClass().addClass("iconConnect3");
                } else if (pinStatus == "3") {
                    signalShow(0);
                    $("#operator").html("SIM Locked");
                    $("#m_operator").html("SIM Locked");
                    // $("#connection_status").removeClass().addClass("iconConnect3");
                } else if (pinStatus == "4") {
                    signalShow(0);
                    $("#operator").html("SIM Error");
                    $("#m_operator").html("SIM Error");
                    // $("#connection_status").removeClass().addClass("iconConnect3");
                } else if (pinStatus == "48") {
                    signalShow(0);
                    $("#operator").html("PNPIN");
                    $("#m_operator").html("PNPIN");
                    // $("#connection_status").removeClass().addClass("iconConnect3");
                } else if (pinStatus == "49") {
                    signalShow(0);
                    $("#operator").html("PNPUK");
                    $("#m_operator").html("PNPUK");
                    // $("#connection_status").removeClass().addClass("iconConnect3");
                } else if (pinStatus == "50") {
                    signalShow(0);
                    $("#operator").html("PUPIN");
                    $("#m_operator").html("PUPIN");
                    // $("#connection_status").removeClass().addClass("iconConnect3");
                } else if (pinStatus == "51") {
                    signalShow(0);
                    $("#operator").html("SPPIN");
                    $("#m_operator").html("SPPIN");
                    // $("#connection_status").removeClass().addClass("iconConnect3");
                } else if (pinStatus == "52") {
                    signalShow(0);
                    $("#operator").html("SPPIN");
                    $("#m_operator").html("SPPIN");
                    // $("#connection_status").removeClass().addClass("iconConnect3");
                } else if (pinStatus == "53") {
                    signalShow(0);
                    $("#operator").html("SPPUK");
                    $("#m_operator").html("SPPUK");
                    // $("#connection_status").removeClass().addClass("iconConnect3");
                } else if (pinStatus == "54") {
                    signalShow(0);
                    $("#operator").html("PCPIN");
                    $("#m_operator").html("PCPIN");
                    // $("#connection_status").removeClass().addClass("iconConnect3");
                } else if (pinStatus == "55") {
                    signalShow(0);
                    $("#operator").html("PCPUK");
                    $("#m_operator").html("PCPUK");
                } else if (pinStatus == "56") {
                    signalShow(0);
                    $("#operator").html("SIMPIN");
                    $("#m_operator").html("SIMPIN");
                    // $("#connection_status").removeClass().addClass("iconConnect3");
                } else if (pinStatus == "57") {
                    signalShow(0);
                    $("#operator").html("SIMPUK");
                    $("#m_operator").html("SIMPUK");
                    // $("#connection_status").removeClass().addClass("iconConnect3");
                }
                if (conn != "cellular") {
                    signalShow(parseInt(json.signal_quality));
                    $("#connection_status").removeClass("iconConnect").addClass("iconDisconnect");
                    $("#m_connection_status").removeClass("iconConnect").addClass("iconDisconnect");
                } else if (conn == "cellular" && simStatus == "0") {
                    $("#connection_status").removeClass("iconDisconnect").addClass("iconConnect");
                    $("#m_connection_status").removeClass("iconDisconnect").addClass("iconConnect");
                }
            }
        });
    });
}
function signalShow(num) {
    switch (num) {
        case 0:
            document.getElementById("signal_strength").className = "signal_quality0";
            document.getElementById("m_signal_strength").className = "signal_quality0";
            break;
        case 1:
            document.getElementById("signal_strength").className = "signal_quality1";
            document.getElementById("m_signal_strength").className = "signal_quality1";
            break;
        case 2:
            document.getElementById("signal_strength").className = "signal_quality2";
            document.getElementById("m_signal_strength").className = "signal_quality2";
            break;
        case 3:
            document.getElementById("signal_strength").className = "signal_quality3";
            document.getElementById("m_signal_strength").className = "signal_quality3";
            break;
        case 4:
            document.getElementById("signal_strength").className = "signal_quality4";
            document.getElementById("m_signal_strength").className = "signal_quality4";
            break;
        case 5:
            document.getElementById("signal_strength").className = "signal_quality5";
            document.getElementById("m_signal_strength").className = "signal_quality5";
            break;
    }
}
function isLogin() {
    callJSON("login_info", function (json) {
        var login_status = json.login_status;
        if (login_status == "1") {
            //Have login
            g_nav = GetCookie("nav");
            g_leftSub = GetCookie("leftSub");
            if (g_nav == "" || g_nav == undefined) {
                g_nav = 0;
                g_leftSub = "";
                selectChange();
                $("#loginShow").hide();
                $("#language").show();
                $("#logo2").show();
                $("#statusBar").hide();
                $("#m_statusBar").hide();
                $("#manageBar").css("marginTop", "-36px");
                $("#indexContainer").addClass("login-page-bg");
                $("#bodyContainer").show();
                // $("#headLogo").hide();
            } else {
                if (g_loginUsername == undefined || g_loginUsername == "") {
                    g_loginUsername = json.username;
                }
                document.getElementById("container").innerHTML = CallHtmlFile("html/adminApp.html");
                selectChange("1");
                setDlgStyle();
                $("#bodyContainer").show();
                $("#loginShow").show();
                $("#logo2").hide();
                $("#statusBar").show();
                $("#manageBar").css("marginTop", "0px");
                $("#indexContainer").removeClass("login-page-bg");
                statusSbar();
                statusOnClick();
                setInterval(function () {
                    statusSbar();
                }, 5000);

                $.objAdmin().onLoad(true);
                // $("#headLogo").show();
            }
        } else {
            selectChange();
            g_nav = 0;
            g_leftSub = "";
            $("#loginShow").hide();
            $("#language").show();
            $("#logo2").show();
            $("#statusBar").hide();
            $("#m_statusBar").hide();
            $("#manageBar").css("marginTop", "-36px");
            $("#indexContainer").addClass("login-page-bg");
            $("#bodyContainer").show();
        }
    });
}

function SetCookie(c_name, value, expiredays) {
    var exdate = new Date();
    exdate.setDate(exdate.getDate() + expiredays);
    document.cookie = c_name + "=" + escape(value) + (expiredays == null ? "" : ";expires=" + exdate.toGMTString());
}
function GetCookie(c_name) {
    if (document.cookie.length > 0) {
        c_start = document.cookie.indexOf(c_name + "=");
        if (c_start != -1) {
            c_start = c_start + c_name.length + 1;
            c_end = document.cookie.indexOf(";", c_start);
            if (c_end == -1) c_end = document.cookie.length;
            return unescape(document.cookie.substring(c_start, c_end));
        }
    }
    return "";
}

// -------------------utils--------------------------
var devEnv = 0;
var AuthQop,
    username = "",
    passwd = "",
    GnCount = 1,
    Authrealm,
    Gnonce,
    nonce;
var _resetTimeOut = 600000;
var authHeaderIntervalID = 0;
var g_loginPasswd;
var devBusyState = false;
var g_bSimCardExist;
var statusInterval;
var afterRebootID;

function UniDecode(encodeString) {
    if (undefined == encodeString) {
        return "";
    }
    var deCodeStr = "";

    var strLen = encodeString.length / 4;
    for (var idx = 0; idx < strLen; ++idx) {
        deCodeStr += String.fromCharCode(parseInt(encodeString.substr(idx * 4, 4), 16));
    }
    return deCodeStr;
}
function UniEncode(string) {
    if (undefined == string) {
        return "";
    }
    var code = "";
    for (var i = 0; i < string.length; ++i) {
        var charCode = string.charCodeAt(i).toString(16);
        var paddingLen = 4 - charCode.length;
        for (var j = 0; j < paddingLen; ++j) {
            charCode = "0" + charCode;
        }

        code += charCode;
    }
    return code;
}
function setLocalization(locale) {
    if (locale != "en") locale = "cn";

    try {
        jQuery.i18n.properties({
            name: "Messages",
            path: "properties/",
            mode: "map",
            language: locale,
            callback: function () {},
        });
    } catch (err) {
        var fileref = document.createElement("script");
        fileref.setAttribute("type", "text/javascript");
        fileref.setAttribute("src", "js/jquery/jquery.i18n.properties-1.0.4.js");
        document.getElementsByTagName("head")[0].appendChild(fileref);
        setLocalization(locale);
    }
}
function GetCookie(c_name) {
    if (document.cookie.length > 0) {
        c_start = document.cookie.indexOf(c_name + "=");
        if (c_start != -1) {
            c_start = c_start + c_name.length + 1;
            c_end = document.cookie.indexOf(";", c_start);
            if (c_end == -1) c_end = document.cookie.length;
            return unescape(document.cookie.substring(c_start, c_end));
        }
    }
    return "";
}
function resetInterval() {
    if (authHeaderIntervalID > 0) clearInterval(authHeaderIntervalID);
    authHeaderIntervalID = setInterval("clearAuthheader()", _resetTimeOut);
}
function clearAuthheader() {
    //clearing coockies
    Authheader = "";
    AuthQop = "";
    username = "";
    passwd = "";
    GnCount = "";
    Authrealm = "";
    //window.location.reload();
    window.location = "index.html";
}
function FormatDataTrafficMinUnitKB(dataByte) {
    var formatData;
    if (dataByte > 1024 * 1024 * 1024) {
        var dataInGB = dataByte / (1024 * 1024 * 1024);
        formatData = dataInGB.toFixed(3) + "GB";
    } else if (dataByte > 1024 * 1024) {
        var dataInMB = dataByte / (1024 * 1024);
        formatData = dataInMB.toFixed(2) + "MB";
    } else {
        var dataInKB = dataByte / 1024;
        formatData = dataInKB.toFixed(2) + "KB";
    }

    return formatData;
}
function formatData(data) {
    var formatData;
    if (data >= 1024 * 1024 * 1024 * 1024) {
        var dataInTB = data / (1024 * 1024 * 1024 * 1024);
        formatData = dataInTB.toFixed(2) + "TB";
    } else if (data >= 1024 * 1024 * 1024) {
        var dataInGB = data / (1024 * 1024 * 1024);
        formatData = dataInGB.toFixed(2) + "GB";
    } else {
        var dataInMB = data / (1024 * 1024);
        formatData = dataInMB.toFixed(2) + "MB";
    }
    return formatData;
}

function formatTimedata(second_time, tip_day) {
    if (isNaN(second_time)) {
        return "00:00:00";
    }
    if (second_time.length < 2) {
        second_time = "0" + second_time;
    }
    var timeStr = "00:00:" + second_time;
    if (parseInt(second_time) > 60) {
        var second = parseInt(second_time) % 60;
        var min = parseInt(second_time / 60);
        second = second < 10 ? "0" + second : second;
        min = min < 10 ? "0" + min : min;
        timeStr = "00" + ":" + min + ":" + second;
        if (min > 60) {
            min = parseInt(second_time / 60) % 60;
            var hour = parseInt(parseInt(second_time / 60) / 60);
            min = min < 10 ? "0" + min : min;
            hour = hour < 10 ? "0" + hour : hour;
            timeStr = hour + ":" + min + ":" + second;
            if (hour > 24) {
                hour = parseInt(parseInt(second_time / 60) / 60) % 24;
                var day = parseInt(parseInt(parseInt(second_time / 60) / 60) / 24);
                hour = hour < 10 ? "0" + hour : hour;
                timeStr = day + " " + tip_day + " " + hour + ":" + min + ":" + second;
            }
        }
    }
    return timeStr;
}
function formatSeconds(second_time, tip_day, tip_hour, tip_minute, tip_second) {
    if (isNaN(second_time)) {
        return "0";
    }
    var timeStr = parseInt(second_time) + " " + tip_second;
    if (parseInt(second_time) > 60) {
        var second = parseInt(second_time) % 60;
        var min = parseInt(second_time / 60);
        timeStr = min + " " + tip_minute + " " + second + " " + tip_second;
        if (min > 60) {
            min = parseInt(second_time / 60) % 60;
            var hour = parseInt(parseInt(second_time / 60) / 60);
            timeStr = hour + " " + tip_hour + " " + min + " " + tip_minute + " " + second + " " + tip_second;
            if (hour > 24) {
                hour = parseInt(parseInt(second_time / 60) / 60) % 24;
                var day = parseInt(parseInt(parseInt(second_time / 60) / 60) / 24);
                timeStr = day + " " + tip_day + " " + hour + " " + tip_hour + " " + min + " " + tip_minute + " " + second + " " + tip_second;
            }
        }
    }
    return timeStr;
}

function IsGSM7Code(str) {
    var len = 0;
    for (var i = 0; i < str.length; i++) {
        var chr = str.charCodeAt(i);
        if (((chr >= 0x20 && chr <= 0x7f) || 0x20ac == chr || 0x20ac == chr || 0x0c == chr || 0x0a == chr || 0x0d == chr || 0xa1 == chr || 0xa3 == chr || 0xa5 == chr || 0xa7 == chr || 0xbf == chr || 0xc4 == chr || 0xc5 == chr || 0xc6 == chr || 0xc7 == chr || 0xc9 == chr || 0xd1 == chr || 0xd6 == chr || 0xd8 == chr || 0xdc == chr || 0xdf == chr || 0xe0 == chr || 0xe4 == chr || 0xe5 == chr || 0xe6 == chr || 0xe8 == chr || 0xe9 == chr || 0xec == chr || 0xf11 == chr || 0xf2 == chr || 0xf6 == chr || 0xf8 == chr || 0xf9 == chr || 0xfc == chr || 0x3c6 == chr || 0x3a9 == chr || 0x3a8 == chr || 0x3a3 == chr || 0x3a0 == chr || 0x39e == chr || 0x39b == chr || 0x398 == chr || 0x394 == chr || 0x393 == chr) && 0x60 != chr) {
            ++len;
        }
    }
    return len == str.length;
}
function setFocusID(id1, id) {
    if (document.getElementById(id1).value.toString().length == "3") document.getElementById(id).focus();
}
function setFocusMAC(id1, id) {
    if (document.getElementById(id1).value.toString().length == "2") document.getElementById(id).focus();
}
function setFocusIP(id1, id) {
    if (document.getElementById(id1).value.toString().length == "3") document.getElementById(id).focus();
}
function setAddBoxHeigth(objID) {
    // $("#"+objID).css("height",($("body").height())+"px");
    if (parseInt($("body").height()) > parseInt(document.documentElement.clientHeight)) {
        $("#" + objID).css("height", $("body").height() + "px");
    } else {
        $("#" + objID).css("height", document.documentElement.clientHeight + "px");
    }
}

function GetRandomNum(Min, Max) {
    var Range = Max - Min;
    var Rand = Math.random();
    return Min + Math.round(Rand * Range);
}
function login_done(urlData) {
    if (urlData.indexOf("200 OK") != -1) {
        return true;
    } else {
        return false;
    }
}
function getValue(authstr) {
    var arr = authstr.split("=");
    return arr[1].substring(1, arr[1].indexOf('"', 2));
}
function doLogin(username1, passwd1) {
    var url = window.location.protocol + "//" + window.location.host + "/login.cgi";
    var loginParam = getAuthType(url);
    //alert(loginParam);
    if (loginParam != null) {
        var loginParamArray = loginParam.split(" ");
        if (loginParamArray[0] == "Digest") {
            //nonce="718337c309eacc5dc1d2558936225417", qop="auth"
            Authrealm = getValue(loginParamArray[1]);
            nonce = getValue(loginParamArray[2]);
            AuthQop = getValue(loginParamArray[3]);

            //    alert("nonce :" + nonce);
            //    alert("AuthQop :" + AuthQop);
            //    alert("Authrealm :" + Authrealm);

            username = username1;
            passwd = passwd1;
            var rand, date, salt, strResponse;

            Gnonce = nonce;
            var tmp, DigestRes;
            var HA1, HA2;

            HA1 = hex_md5(username + ":" + Authrealm + ":" + passwd);
            HA2 = hex_md5("GET" + ":" + "/cgi/protected.cgi");

            rand = Math.floor(Math.random() * 100001);
            date = new Date().getTime();

            salt = rand + "" + date;
            tmp = hex_md5(salt);
            AuthCnonce = tmp.substring(0, 16);

            DigestRes = hex_md5(HA1 + ":" + nonce + ":" + "00000001" + ":" + AuthCnonce + ":" + AuthQop + ":" + HA2);

            url = window.location.protocol + "//" + window.location.host + "/login.cgi?Action=Digest&username=" + username + "&realm=" + Authrealm + "&nonce=" + nonce + "&response=" + DigestRes + "&qop=" + AuthQop + "&cnonce=" + AuthCnonce + "&temp=marvell";
            if (login_done(authentication(url))) {
                strResponse = 'Digest username="' + username + '", realm="' + Authrealm + '", nonce="' + nonce + '", uri="' + "/cgi/protected.cgi" + '", response="' + DigestRes + '", qop=' + AuthQop + ", nc=00000001" + ', cnonce="' + AuthCnonce + '"';

                return 1;
            } else {
                return 0;
            }

            return strResponse;
        }
    }
    return -1;
}
function getAuthType(url) {
    if (devEnv == "1") {
        return 'Digest realm="Highwmg", nonce="718337c309eacc5dc1d2558936225417", qop="auth" Content-Type: text/html Server: Lighttpd/1.4.19 Content-Length: 0 Date: Tue, 11 Oct 2005 10:44:32 GMT ';
    }
    var content = $.ajax({
        url: url,
        type: "GET",
        dataType: "text/html",
        async: false,
        cache: false,
        beforeSend: function (xhr) {
            xhr.setRequestHeader("Expires", "-1");
            xhr.setRequestHeader("Cache-Control", "no-store, no-cache, must-revalidate");
            xhr.setRequestHeader("Pragma", "no-cache");
        },
    }).getResponseHeader("WWW-Authenticate");
    return content;
}
function authentication(url) {
    if (devEnv == "1") {
        return "200 OK";
    }
    var content = $.ajax({
        url: url,
        dataType: "text/html",
        async: false,
        cache: false,
        beforeSend: function (xhr) {
            xhr.setRequestHeader("Authorization", getAuthHeader("GET"));
            xhr.setRequestHeader("Expires", "-1");
            xhr.setRequestHeader("Cache-Control", "no-store, no-cache, must-revalidate");
            xhr.setRequestHeader("Pragma", "no-cache");
        },
    }).responseText;
    return content;
}
function GetBrowserType() {
    var usrAgent = navigator.userAgent;
    if (navigator.userAgent.indexOf("MSIE") > 0) {
        var b_version = navigator.appVersion;
        var version = b_version.split(";");
        var trim_Version = version[1].replace(/[ ]/g, "");
        if (trim_Version == "MSIE6.0") {
            return "IE6";
        } else if (trim_Version == "MSIE7.0") {
            return "IE7";
        } else if (trim_Version == "MSIE8.0") {
            return "IE8";
        } else if (trim_Version == "MSIE9.0") {
            return "IE9";
        }
    }
    if ((isFirefox = navigator.userAgent.indexOf("Firefox") > 0)) {
        return "Firefox";
    }
    if ((isSafari = navigator.userAgent.indexOf("Safari") > 0)) {
        return "Safari"; //google
    }
    if ((isCamino = navigator.userAgent.indexOf("Camino") > 0)) {
        return "Camino";
    }
    if ((isMozilla = navigator.userAgent.indexOf("Gecko/") > 0)) {
        return "Gecko";
    }
}
function hex(d) {
    // alert("d" + d );
    var hD = "0123456789ABCDEF";
    var h = hD.substr(d & 15, 1);
    while (d > 15) {
        d >>= 4;
        h = hD.substr(d & 15, 1) + h;
    }
    return h;
    //alert("h" + h);
    //    return parseInt(str.toString(), 16);
}
function getAuthHeader(requestType, file) {
    // return getCookie("Authheader");
    var rand, date, salt, strAuthHeader;
    var tmp, DigestRes, AuthCnonce_f;
    var HA1, HA2;

    HA1 = hex_md5(username + ":" + Authrealm + ":" + passwd);
    HA2 = hex_md5(requestType + ":" + "/cgi/xml_action.cgi");

    rand = Math.floor(Math.random() * 100001);
    date = new Date().getTime();

    salt = rand + "" + date;
    tmp = hex_md5(salt);
    AuthCnonce_f = tmp.substring(0, 16);
    //AuthCnonce_f = tmp;

    var strhex = hex(GnCount);
    var temp = "0000000000" + strhex;
    var Authcount = temp.substring(temp.length - 8);
    DigestRes = hex_md5(HA1 + ":" + nonce + ":" + Authcount + ":" + AuthCnonce_f + ":" + AuthQop + ":" + HA2);

    GnCount++;
    strAuthHeader = "Digest " + 'username="' + username + '", realm="' + Authrealm + '", nonce="' + nonce + '", uri="' + "/cgi/xml_action.cgi" + '", response="' + DigestRes + '", qop=' + AuthQop + ", nc=" + Authcount + ', cnonce="' + AuthCnonce_f + '"';
    DigestHeader = strAuthHeader;
    return strAuthHeader;
}
function CallHtmlFile(htmlName) {
    // prevent loading html file from cache to avoid "304 not modified error."
    htmlName = htmlName + "?t=" + new Date().getTime().toString();

    resetInterval();
    var content;
    content = $.ajax({
        type: "GET",
        url: htmlName,
        dataType: "html",
        timeout: 30000,
        async: false,
    }).responseText;
    return content;
}
function getTimeToS(s) {
    var hh, mm, ss;

    hh = s >= 3600 ? (Math.floor(s / 3600) >= 10 ? Math.floor(s / 3600) : "0" + Math.floor(s / 3600)) : "00";
    mm = s >= 60 ? (Math.floor((s % 3600) / 60) >= 10 ? Math.floor((s % 3600) / 60) : "0" + Math.floor((s % 3600) / 60)) : "00";
    ss = s > 0 ? (s % 60 >= 10 ? s % 60 : "0" + (s % 60)) : "00";
    return hh + ":" + mm + ":" + ss;
}
function setFocus(controlID) {
    var str = document.getElementById(controlID).value;
    if (str.length == 2) {
        var c = controlID.toString().charAt(controlID.length - 1);
        c++;
        controlID = controlID.substring(0, controlID.length - 1);
        controlID = controlID + c;
        document.getElementById(controlID.toString()).focus();
    }
}
function GetSmsTime() {
    var date = new Date();
    var fullYear = new String(date.getFullYear());
    var year = fullYear.substr(2, fullYear.length - 1);
    var month = date.getMonth() + 1;
    var day = date.getDate();
    var hour = date.getHours();
    var mimute = date.getMinutes();
    var second = date.getSeconds();
    var timeZone = 0 - date.getTimezoneOffset() / 60;
    var timeZoneStr = "";
    if (timeZone > 0) {
        timeZoneStr = "%2B" + timeZone;
    } else {
        timeZoneStr = "-" + timeZone;
    }
    var smsTime = year + "," + month + "," + day + "," + hour + "," + mimute + "," + second + "," + timeZoneStr;
    return smsTime;
}
function getHeader(AuthMethod, file) {
    var rand, date, salt, setResponse;
    var tmp, DigestRes, AuthCnonce_f;
    var HA1, HA2;

    HA1 = hex_md5(username + ":" + Authrealm + ":" + passwd);
    HA2 = hex_md5(AuthMethod + ":" + "/cgi/xml_action.cgi");

    rand = Math.floor();
    date = new Date().getTime();

    salt = rand + "" + date;
    tmp = hex_md5(salt);
    AuthCnonce = tmp.substring(0, 16);
    AuthCnonce_f = tmp;

    var strhex = hex(GnCount);
    var temp = "0000000000" + strhex;
    var Authcount = temp.substring(temp.length - 8);

    DigestRes = hex_md5(HA1 + ":" + Gnonce + ":" + Authcount + ":" + AuthCnonce_f + ":" + AuthQop + ":" + HA2);

    ++GnCount;

    if ("GET" == AuthMethod) {
        if ("upgrade" == file) {
            //setResponse = "/login.cgi?Action=Upload&file=" + file + "&username=" +  username + "&realm=" + Authrealm + "&nonce=" + Gnonce + "&response=" +  DigestRes + "&cnonce=" + AuthCnonce_f + "&nc=" + Authcount + "&qop=" + AuthQop + "&temp=marvell";
            setResponse = "/xml_action.cgi?Action=Upload&file=upgrade&command=";
        } else if ("config_backup" == file) {
            setResponse = "/xml_action.cgi?Action=Upload&file=backfile&config_backup=";
        } else {
            setResponse = "/login.cgi?Action=Download&file=" + file + "&username=" + username + "&realm=" + Authrealm + "&nonce=" + Gnonce + "&response=" + DigestRes + "&cnonce=" + AuthCnonce_f + "&nc=" + Authcount + "&qop=" + AuthQop + "&temp=marvell";
        }
    }

    if ("POST" == AuthMethod) {
        setResponse = "/login.cgi?Action=Upload&file=" + file + "&username=" + username + "&realm=" + Authrealm + "&nonce=" + Gnonce + "&response=" + DigestRes + "&cnonce=" + AuthCnonce_f + "&nc=" + Authcount + "&qop=" + AuthQop + "&temp=marvell";
    }

    return setResponse;
}
function getAuthHeaderEx(requestType, file) {
    // return getCookie("Authheader");
    var rand, date, salt, strAuthHeader;
    var tmp, DigestRes, AuthCnonce_f;
    var HA1, HA2;

    HA1 = hex_md5(username + ":" + Authrealm + ":" + passwd);
    HA2 = hex_md5(requestType + ":" + "/cgi/xml_action.cgi");

    rand = Math.floor(Math.random() * 100001);
    date = new Date().getTime();

    salt = rand + "" + date;
    tmp = hex_md5(salt);
    AuthCnonce_f = tmp.substring(0, 16);
    //AuthCnonce_f = tmp;

    var strhex = hex(GnCount);
    var temp = "0000000000" + strhex;
    var Authcount = temp.substring(temp.length - 8);
    DigestRes = hex_md5(HA1 + ":" + nonce + ":" + Authcount + ":" + AuthCnonce_f + ":" + AuthQop + ":" + HA2);

    GnCount++;
    strAuthHeader = "username=" + username + "&realm=" + Authrealm + "&nonce=" + nonce + "&uri=/cgi/xml_action.cgi" + "&response=" + DigestRes + "&qop=" + AuthQop + "&nc=" + Authcount + "&cnonce=" + AuthCnonce_f;
    DigestHeader = strAuthHeader;
    return strAuthHeader;
}
// -------------------------------------------------------------validator-----------------------------------------------------------------

function IsNumber(obj) {
    if (typeof obj === "string") {
        var r = /^-?\d+$/;
        if (r.test(obj)) {
            if (obj.length >= 1 && obj.indexOf("0") == 0) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    if (typeof obj === "number") {
        if (obj.toString().indexOf(".") != -1) return false;
        else return true;
    }
    return false;
}
function IsNumber_1(obj) {
    if (typeof obj === "string") {
        var r = /^-?\d+$/;
        if (r.test(obj)) {
            return true;
        } else {
            return false;
        }
    }

    if (typeof obj === "number") {
        if (obj.toString().indexOf(".") != -1) return false;
        else return true;
    }
    return false;
}

function isIPv6Long(ip6Addr) {
    var matchStr = "((([0-9a-f]{1,4}:){7}([0-9a-f]{1,4}|:))|(([0-9a-f]{1,4}:){6}(:[0-9a-f]{1,4}|((25[0-5]|2[0-4]d|1dd|[1-9]?d)(.(25[0-5]|2[0-4]d|1dd|[1-9]?d)){3})|:))|(([0-9a-f]{1,4}:){5}(((:[0-9a-f]{1,4}){1,2})|:((25[0-5]|2[0-4]d|1dd|[1-9]?d)(.(25[0-5]|2[0-4]d|1dd|[1-9]?d)){3})|:))|(([0-9a-f]{1,4}:){4}(((:[0-9a-f]{1,4}){1,3})|((:[0-9a-f]{1,4})?:((25[0-5]|2[0-4]d|1dd|[1-9]?d)(.(25[0-5]|2[0-4]d|1dd|[1-9]?d)){3}))|:))|(([0-9a-f]{1,4}:){3}(((:[0-9a-f]{1,4}){1,4})|((:[0-9a-f]{1,4}){0,2}:((25[0-5]|2[0-4]d|1dd|[1-9]?d)(.(25[0-5]|2[0-4]d|1dd|[1-9]?d)){3}))|:))|(([0-9a-f]{1,4}:){2}(((:[0-9a-f]{1,4}){1,5})|((:[0-9a-f]{1,4}){0,3}:((25[0-5]|2[0-4]d|1dd|[1-9]?d)(.(25[0-5]|2[0-4]d|1dd|[1-9]?d)){3}))|:))|(([0-9a-f]{1,4}:){1}(((:[0-9a-f]{1,4}){1,6})|((:[0-9a-f]{1,4}){0,4}:((25[0-5]|2[0-4]d|1dd|[1-9]?d)(.(25[0-5]|2[0-4]d|1dd|[1-9]?d)){3}))|:))|(:(((:[0-9a-f]{1,4}){1,7})|((:[0-9a-f]{1,4}){0,5}:((25[0-5]|2[0-4]d|1dd|[1-9]?d)(.(25[0-5]|2[0-4]d|1dd|[1-9]?d)){3}))|:)))(%.+)?s*$";
    var ret = ip6Addr.match(matchStr);
    if (ret) {
        return true;
    } else {
        return false;
    }
}
function isIPFULL(inputString, flag) {
    var re = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
    if (!flag) {
        if (inputString == "...") return true;
        else isIPFULL(inputString, true);
    }
    //test the input string against the regular expression
    if (re.test(inputString)) {
        //now, validate the separate parts
        var parts = inputString.split(".");
        if (parseInt(parseFloat(parts[0])) == 0) {
            return false;
        }
        if (parseInt(parseFloat(parts[3])) == 0 /*|| inputString=="192.168.0.1"*/) {
            return false;
        }
        for (var i = 0; i < parts.length; i++) {
            if (parseInt(parseFloat(parts[i])) > 255) {
                return false;
            }
            /* bug20427*/
            if (parts[i].length >= 2 && parts[i].indexOf("0") == "0") {
                return false;
            }
        }
        return true;
    } else {
        return false;
    }
}
function IsInteger(str) {
    return /^\d+$/.test(str);
}
function isFloat(oNum) {
    if (!oNum) return false;
    var strP = /^\d+(\.\d+)?$/;
    if (!strP.test(oNum)) return false;
    try {
        if (parseFloat(oNum) != oNum) return false;
    } catch (ex) {
        return false;
    }
    return true;
}
function textBoxMinLength(control, value) {
    if (document.getElementById(control).value.length < value) return false;
    else return true;
}
function IsChineseChar(value) {
    if (/.*[\u0100-\uffff]+.*$/.test(value)) {
        return true;
    } else {
        return false;
    }
}
function textBoxMaxLength(control, value) {
    if (document.getElementById(control).value.length > value) return false;
    else return true;
}
function textBoxLength(control, value) {
    if (document.getElementById(control).value.length == value) return true;
    else return false;
}
function IsEmail(emailAddr) {
    var pattern = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (pattern.test(emailAddr)) {
        return true;
    } else {
        return false;
    }
}
function IsVPNName(vpnNmae) {
    var pattern = /^[a-zA-Z0-9]{4,20}$/;
    if (pattern.test(vpnNmae)) {
        return true;
    } else {
        return false;
    }
}
function IsPhoneNumber(phoneNumber) {
    var pattern = /(^[0-9]{3,4}\-[0-9]{3,8}$)|(^\+?[0-9]{3,15}$)|(^\([0-9]{3,4}\)[0-9]{3,8}$)/;
    if (pattern.test(phoneNumber)) {
        return true;
    } else {
        return false;
    }
}
function isChineseChar(value) {
    if (/.*[\u0100-\uffff]+.*$/.test(value)) {
        return true;
    } else {
        return false;
    }
}
function deviceNameValidation(str) {
    if (isChineseChar(str)) {
        return false;
    }

    if (str.toString().indexOf("#") != -1) return false;
    else if (str.toString().indexOf(":") != -1) return false;
    else if (str.toString().indexOf(" ") != -1) return false;
    else if (str.toString().indexOf("&") != -1) return false;
    else if (str.toString().indexOf(";") != -1) return false;
    else if (str.toString().indexOf("~") != -1) return false;
    else if (str.toString().indexOf("|") != -1) return false;
    else if (str.toString().indexOf("<") != -1) return false;
    else if (str.toString().indexOf(">") != -1) return false;
    else if (str.toString().indexOf("$") != -1) return false;
    else if (str.toString().indexOf("%") != -1) return false;
    else if (str.toString().indexOf("^") != -1) return false;
    else if (str.toString().indexOf("!") != -1) return false;
    else if (str.toString().indexOf("@") != -1) return false;
    else if (str.toString().indexOf(",") != -1) return false;
    else if (str.toString().indexOf("(") != -1) return false;
    else if (str.toString().indexOf(")") != -1) return false;
    else if (str.toString().indexOf("{") != -1) return false;
    else if (str.toString().indexOf("}") != -1) return false;
    else if (str.toString().indexOf("[") != -1) return false;
    else if (str.toString().indexOf("]") != -1) return false;
    else if (str.toString().indexOf("*") != -1) return false;
    else return true;
}
function IsIPv6(ipv6Addr) {
    return ipv6Addr.match(/:/g) != null && ipv6Addr.match(/:/g).length <= 15 && /::/.test(str) ? /^([\da-f]{1,4}(:|::)){1,6}[\da-f]{1,4}$/i.test(str) : /^([\da-f]{1,4}:){15}[\da-f]{1,4}$/i.test(str);
}
function IsIPv4(ipv4Addr) {
    var exp = /^([0-9]|[1-9][0-9]|1\d\d|2[0-4]\d|25[0-5])\.([0-9]|[1-9][0-9]|1\d\d|2[0-4]\d|25[0-5])\.([0-9]|[1-9][0-9]|1\d\d|2[0-4]\d|25[0-5])\.([0-9]|[1-9][0-9]|1\d\d|2[0-4]\d|25[0-5])$/;
    return null == ipv4Addr.match(exp) ? false : true;
}
function IsUrl(strUrl) {
    var regUrl = /(http\:\/\/)?([\w.]+)(\/[\w- \.\/\?%&=]*)?/gi;
    if (regUrl.test(strUrl)) {
        return true;
    } else {
        return false;
    }
}
function IsHexStr(str) {
    pattern = /^[0-9a-fA-F]+$/;
    if (pattern.test(str)) {
        return true;
    } else {
        return false;
    }
}
function IsASCIIStr(str) {
    pattern = /[0-9a-zA-Z]+/;
    if (pattern.test(str)) {
        return true;
    } else {
        return false;
    }
}
function IsEnglishLetter(str) {
    pattern = /[a-zA-Z]+/;
    if (pattern.test(str)) {
        return true;
    } else {
        return false;
    }
}
/* function IsMACAddr(mac) {
    var regex = /^([0-9a-f]{2}([:-]|$)){6}$|([0-9a-f]{4}([.]|$)){3}$/i;
    if (!regex.test(mac))
        return false;
    else
        return true;
} */
function IsMACAddr(mac) {
    var regex = /^([0-9a-fA-F]{2}([:-]|$)){6}$|([0-9a-fA-F]{4}([.]|$)){3}$/i;
    if (!regex.test(mac)) {
        return false;
    }
    mac = mac.toLowerCase();
    if ("ff:ff:ff:ff:ff:ff" == mac || "00:00:00:00:00:00" == mac) {
        return false;
    }
    var addrParts = mac.split(":");
    var c = parseInt(addrParts[0].charAt(1), 16);
    if (c % 2) {
        return false;
    }
    return true;
}
//time format: hh:mm:ss
function IsTime(time) {
    var regex = /^([0-1]?\d{1}|2[0-3]):[0-5]?\d{1}:([0-5]?\d{1})$/;
    if (!regex.test(time)) return false;
    else return true;
}
//time format: hh:mm
function IsTimeEx(time) {
    //var regex = /^(([0-1]\d)|(2[0-4])):[0-5]\d$/;
    var regex = /^([0-9]|[0-1]{1}\d|2[0-3]):([0-9]|[0-5]\d)$/;
    if (!regex.test(time)) return false;
    else return true;
}
//date format: yyyy-mm-dd
function IsData(date) {
    var month = "";
    var year = "";
    if (date) {
        var data = date.split("-");
        year = data[0];
        month = data[1] * 1;
    }
    return new Date(date.replace(/-/g, "/")).getDate() == date.substring(date.length - 2) && month <= 12 && month > 0 && year.indexOf("0") != 0;
}
//port format: xxxx:yyyy
function IsPort(port) {
    var portArr = port.split(":");
    for (var idx = 0; idx < 2; ++idx) {
        if ("" == portArr[idx] || !/^[1-9]+\d*$/.test(portArr[idx])) return false;

        if (portArr[idx] > 65535 || portArr[idx] < 0) return false;
    }
    if (Number(portArr[0]) > Number(portArr[1])) return false;

    return true;
}
function IsRuleName(ruleName) {
    if ("" == ruleName) return false;
    if (!IsASCIIStr(ruleName)) return false;

    return true;
}
function validate_pin(pin) {
    var ret = true;

    if (pin.length < 4 || pin.length > 8) ret = false;

    if (!IsNumber(pin)) ret = false;

    return ret;
}
function validate_puk(puk) {
    var ret = true;

    if (puk.length < 4 || puk.length > 10) ret = false;

    if (/\W/.test(puk)) ret = false;

    return ret;
}
function isAfterDate(beforeDate, afterDate) {
    var bDate = beforeDate.split("-");
    var aDate = afterDate.split("-");
    if (parseInt(bDate[0]) > parseInt(aDate[0])) {
        return false;
    } else if (parseInt(bDate[0]) < parseInt(aDate[0])) {
        return true;
    } else {
        if (parseInt(bDate[1]) > parseInt(aDate[1])) {
            return false;
        } else if (parseInt(bDate[1]) < parseInt(aDate[1])) {
            return true;
        } else {
            if (parseInt(bDate[2]) >= parseInt(aDate[2])) {
                return false;
            } else {
                return true;
            }
        }
    }
}
function isAfterTime(beforeTime, afterTime) {
    var bTime = beforeTime.split(":");
    var aTime = afterTime.split(":");
    if (parseInt(bTime[0]) > parseInt(aTime[0])) {
        return false;
    } else if (parseInt(bTime[0]) < parseInt(aTime[0])) {
        return true;
    } else {
        if (bTime.length == 2) {
            if (parseInt(bTime[1]) >= parseInt(aTime[1])) {
                return false;
            } else {
                return true;
            }
        } else {
            if (parseInt(bTime[1]) > parseInt(aTime[1])) {
                return false;
            } else if (parseInt(bTime[1]) < parseInt(aTime[1])) {
                return true;
            } else {
                if (parseInt(bTime[2]) >= parseInt(aTime[2])) {
                    return false;
                } else {
                    return true;
                }
            }
        }
    }
}
function validateMACAddress(mac) {
    var regex = /^([0-9a-f]{2}([:-]|$)){6}$|([0-9a-f]{4}([.]|$)){3}$/i;
    if (!regex.test(mac)) return false;
    else return true;
}
function validateIPAddress(ip) {
    if (!isIPFULL(ip, true)) return 0;
    else return 1;
}
// -------------------------------------------------------------ajax.js-----------------------------------------------------------------

function postJSONlocale(xmlName, jsonData) {
    resetInterval();
    var url = "";
    xmlName = "json_" + xmlName;
    var host = window.location.protocol + "//" + window.location.host + "/";
    url = host + "xml_action.cgi?method=post&module=duster&file=" + xmlName + Date.parse(new Date());
    $.ajax({
        type: "POST",
        beforeSend: function (xhr) {
            xhr.setRequestHeader("Authorization", getAuthHeader("POST"));
        },
        url: url,
        processData: false,
        data: JSON.stringify(jsonData),
        async: false,
        dataType: "json",
        timeout: 3000,
        success: function (data, textStatus) {},
        complete: function (XMLHttpRequest, textStatus) {},
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            if (textStatus != "timeout") alert(errorThrown);
            else alert(jQuery.i18n.prop("lErrorTimeOut"));
        },
    });
    return true;
}
function callJSON(jsonName, callbackFun, type) {
    if (type) {
    } else {
        resetInterval();
    }

    var url = "";
    jsonName = "json_" + jsonName;
    var host = window.location.protocol + "//" + window.location.host + "/";
    var ctx;
    url = host + "xml_action.cgi?method=get&module=duster&file=" + jsonName + Date.parse(new Date());

    $.ajax({
        type: "GET",
        beforeSend: function (xhr) {
            xhr.setRequestHeader("Authorization", getAuthHeader("GET"));
        },
        url: url,
        timeout: 30000,
        dataType: "json",
        async: true,
        success: function (data, textStatus) {},
        complete: function (XMLHttpRequest, textStatus) {
            var firstNewSmsContent = XMLHttpRequest.responseText;
            if (firstNewSmsContent) {
                var firstNewSmsString = firstNewSmsContent.substring(firstNewSmsContent.indexOf("{"), firstNewSmsContent.lastIndexOf("}") + 1);
                if (firstNewSmsString.indexOf("UNAUTHORIZED") > 0 || firstNewSmsString.indexOf("KICKOFF") > 0) {
                    clearAuthheader();
                } else {
                    ctx = JSON.parse(firstNewSmsString);
                    if (callbackFun) {
                        callbackFun(ctx);
                    }
                }
            }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {},
    });
}
function postJSON(jsonName, jsonData, callbackFun, timeOutInterval) {
    if (timeOutInterval === undefined || timeOutInterval === null) {
        timeOutInterval = 360000;
    }
    resetInterval();
    var url = "";
    jsonName = "json_" + jsonName;
    var host = window.location.protocol + "//" + window.location.host + "/";
    url = host + "xml_action.cgi?method=post&module=duster&file=" + jsonName + Date.parse(new Date());
    $.ajax({
        type: "POST",
        beforeSend: function (xhr) {
            xhr.setRequestHeader("Authorization", getAuthHeader("POST"));
        },
        url: url,
        dataType: "json",
        processData: false,
        async: true,
        data: JSON.stringify(jsonData),
        success: function (data, textStatus) {},
        complete: function (XMLHttpRequest, textStatus) {
            closeWait();
            var firstNewSmsContent = XMLHttpRequest.responseText;
            if (firstNewSmsContent) {
                var firstNewSmsString = firstNewSmsContent.substring(firstNewSmsContent.indexOf("{"), firstNewSmsContent.lastIndexOf("}") + 1);
                if (firstNewSmsString.indexOf("UNAUTHORIZED") > 0 || firstNewSmsString.indexOf("KICKOFF") > 0) {
                    clearAuthheader();
                } else {
                    ctx = JSON.parse(firstNewSmsString);
                    if (callbackFun) {
                        callbackFun(ctx);
                    }
                }
            }
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            closeWait();
            // if(textStatus!="timeout"){
            //     alert(jQuery.i18n.prop('lErrorPost'));
            // }else{
            //     alert(jQuery.i18n.prop('lErrorTimeOut'));
            // }
        },
    });
}
// -------------------------------------------------------------adminApp.js-----------------------------------------------------------------
var menu = {
    Menu: [
        { name: "mDashboard", implFunction: "objDashboard" },
        {
            name: "tInternet",
            subMenu: [
                { id: "mInternetConn", implFunction: "objInternetConn" },
                { id: "mManulNetwork", implFunction: "objManualNetwork" },
                { id: "mPinPuk", implFunction: "objPinPuk" },
                { id: "mAPN", implFunction: "objAPN" },
                { id: "mConnectionInfo", implFunction: "objConnectionInfo" },
            ],
        },
        {
            name: "tWireless",
            subMenu: [
                { id: "mWifiInfoSet", implFunction: "objWifiSet" },
                { id: "mWifisecuritySet", implFunction: "objWifisecuritySet" },
                { id: "mWPS", implFunction: "objWPS" },
                { id: "mWifiMACFilter", implFunction: "objWifiMACFilter" },
            ],
        },
        { name: "tUssd", subMenu: [{ id: "mUSSD", implFunction: "objUSSD" }] },
        {
            name: "tSms",
            subMenu: [
                { id: "mDeviceInbox", implFunction: "objSms" },
                // {"id":"mSmsOutbox","implFunction":"objSms"},
                // {"id":"mSmsDrafts","implFunction":"objSms"},
                { id: "mSim", implFunction: "objSms" },
                { id: "mSmsSet", implFunction: "objSmsSet" },
            ],
        },
        {
            name: "tPhoneBook",
            subMenu: [
                { id: "mAllContact", implFunction: "objPhoneBook" },
                { id: "mLoactionCommon", implFunction: "objPhoneBook" },
                { id: "mLoactionFamliy", implFunction: "objPhoneBook" },
                { id: "mLoactionFriends", implFunction: "objPhoneBook" },
                { id: "mLoactionColleague", implFunction: "objPhoneBook" },
            ],
        },
        {
            name: "tadvanceSetting",
            subMenu: [
                { id: "mDHCP_Settings", implFunction: "objDHCP_Settings" },
                { id: "mCustomFirewallRules", implFunction: "objCustomFirewallRules" },
                { id: "mPortFilter", implFunction: "objPortFilter" },
                { id: "mPortForwarding", implFunction: "objPortForwarding" },
                { id: "mSoftUpdate", implFunction: "objUpdate" },
                { id: "mDataTraffic", implFunction: "objDataTraffic" },
                { id: "mTrafficStatistical", implFunction: "objTrafficStatistical" },
                { id: "mRouterManage", implFunction: "objRouterManage" },
                { id: "mAccountManage", implFunction: "objAccountManage" },
                { id: "mTimeSetting", implFunction: "objTimeSetting" },
                { id: "mTR069Setting", implFunction: "objTR069Setting" },
            ],
        },
        { name: "mChangePwd", implFunction: "objChangePwd" },
        { name: "mQuickSetup", implFunction: "objQuickSetup" },
    ],
};
var dashboard_interval;
var maxWindowW = 430;
var LANGUAGE = "en";
(function ($) {
    $.objAdmin = function () {
        var that = this;
        this.onLoad = function (flag) {
            if (flag) {
                that.displayControls();
                that.showMenu();
                that.bindMenuClose();
            }
        };
        this.showMenu = function () {
            callJSON("homepage_info", function (json) {
                var pinStatus = json.pin_status;
                var simStatus = json.sim_status;

                if (simStatus == "1") {
                    var menuList = '<li ><a href="#"  name="mDashboard"  class="on" id="mDashboard" onclick="displaySubMenu(0)">' + jQuery.i18n.prop("mDashboard") + "</a></li>";
                    var index = 1;
                    for (var i = 1; i < menu.Menu.length; i++) {
                        var l = menu.Menu[i];
                        var MenuName = jQuery.i18n.prop(l.name);
                        var lname = l.name;
                        if (lname == "tDataTraffic" || lname == "tWireless" || lname == "tPhoneBook" || lname == "tSms" || lname == "tUssd" || lname == "tInternet" || lname == "tadvanceSetting") {
                            menuList += '<li><a href="#"  name="' + lname + '"   id="' + lname + '" onclick="displaySubMenu(' + index + ",true,'nosim')\">" + MenuName + "</a></li>";
                        } else {
                            menuList += '<li class=\'hide\'><a href="#"  name="' + lname + '"   id="' + lname + '" onclick="displaySubMenu(' + index + ",true,'nosim')\">" + MenuName + "</a></li>";
                        }

                        index++;
                    }
                } else if (pinStatus == "48") {
                    var menuList = '<li ><a href="#"  name="mDashboard"  class="on" id="mDashboard" onclick="displaySubMenu(0)">' + jQuery.i18n.prop("mDashboard") + "</a></li>";
                    var index = 1;
                    for (var i = 1; i < menu.Menu.length; i++) {
                        var l = menu.Menu[i];
                        var MenuName = jQuery.i18n.prop(l.name);
                        var lname = l.name;
                        if (lname == "tDataTraffic" || lname == "tWireless" || lname == "tPhoneBook" || lname == "tSms" || lname == "tUssd" || lname == "tInternet") {
                            menuList += '<li><a href="#"  name="' + lname + '"   id="' + lname + '" onclick="displaySubMenu(' + index + ",true,'simLock')\">" + MenuName + "</a></li>";
                        } else {
                            menuList += '<li class=\'hide\'><a href="#"  name="' + lname + '"   id="' + lname + '" onclick="displaySubMenu(' + index + ",true,'simLock')\">" + MenuName + "</a></li>";
                        }

                        index++;
                    }
                } else {
                    var menuList = '<li ><a href="#"  name="mDashboard"  class="on" id="mDashboard" onclick="displaySubMenu(0)">' + jQuery.i18n.prop("mDashboard") + "</a></li>";
                    var index = 1;
                    for (var i = 1; i < menu.Menu.length; i++) {
                        var l = menu.Menu[i];
                        var MenuName = jQuery.i18n.prop(l.name);
                        var lname = l.name;
                        if (lname == "tadvanceSetting" || lname == "tPhoneBook" || lname == "tSms" || lname == "tUssd" || lname == "tInternet" || lname == "tWireless") {
                            menuList += '<li><a href="#"  name="' + lname + '"   id="' + lname + '" onclick="displaySubMenu(' + index + ',true)">' + MenuName + "</a></li>";
                        } else {
                            menuList += '<li class=\'hide\'><a href="#"  name="' + lname + '"   id="' + lname + '" onclick="displaySubMenu(' + index + ',true)">' + MenuName + "</a></li>";
                        }

                        index++;
                    }
                }

                $("#menu").html(menuList);

                // displaySubMenu(0);
                //设置导航栏长度
                if ($(".menu li[class='hide']").length == 2) {
                    $("#menu a").width(138);
                } else if ($(".menu li[class='hide']").length == 4) {
                    $("#navigation").css("margin-left", "60px");
                    $("#menu a").width(245);
                } else {
                    $("#navigation").css("margin-left", "60px");
                    $("#menu a").width(138);
                }
                if (simStatus == "1") {
                    displaySubMenu(parseInt(g_nav));
                    //displaySubMenu(parseInt(g_nav),undefined,"nosim");
                } else if (pinStatus == "48") {
                    displaySubMenu(parseInt(g_nav));
                    //displaySubMenu(parseInt(g_nav),undefined,"simLock");
                } else {
                    displaySubMenu(parseInt(g_nav));
                }
            });
            $("#media_menu").unbind("click");
            $("#media_menu").bind("click", function () {
                $("#leftBar").hide();
                $("#statusBar").hide();
                $("#m_statusBar").show();
                if ($("#navigation").css("display") == "none") {
                    $("#navigation").show();
                } else {
                    $("#navigation").hide();
                }
            });
            $("#media_sub_menu").unbind("click");
            $("#media_sub_menu").bind("click", function () {
                $("#navigation").hide();
                $("#statusBar").hide();
                $("#m_statusBar").show();
                if ($("#leftBar").css("display") == "none") {
                    $("#leftBar").show();
                } else {
                    $("#leftBar").hide();
                }
            });
        };
        this.bindMenuClose = function () {
            $("#menu_bg").unbind("click");
            $("#menu_bg").bind("click", function () {
                $("#navigation").show();
            });
        };
        this.displayControls = function () {
            // document.getElementById("quickSetupSpan").innerHTML = jQuery.i18n.prop("quickSetupName");
            // document.getElementById("MainHelp").innerHTML = jQuery.i18n.prop("helpName");
            // document.getElementById("MainLogOut").innerHTML = jQuery.i18n.prop("LogOutName");
            document.getElementById("lPleaseWait").innerHTML = jQuery.i18n.prop("h1PleaseWait");
            // document.getElementById("lt_lacopyright").innerHTML = jQuery.i18n.prop("lt_lacopyright");
        };
        return this;
    };
})(jQuery);

var MenuId = "";
var SubMenuId = "";
function displaySubMenu(index, type, ifSim) {
    g_nav = index;
    SetCookie("nav", index);
    if (ifSim == "nosim") {
        var subbox = '<div class="leftBar" id="leftBar"><div class="leftBar_bg" id="leftBar_bg"></div><ul class="leftMenu" id="submenu"></ul></div><div id="Content" class="content"></div><br class="clear" /><br class="clear" />';
    } else if (ifSim == "simLock") {
        var subbox = '<div class="leftBar" id="leftBar"><div class="leftBar_bg" id="leftBar_bg"></div><ul class="leftMenu" id="submenu"></ul></div><div id="Content" class="content"></div><br class="clear" /><br class="clear" />';
    } else {
        var subbox = '<div class="leftBar" id="leftBar"><div class="leftBar_bg" id="leftBar_bg"></div><ul class="leftMenu" id="submenu"></ul></div><div id="Content" class="content"></div><br class="clear" /><br class="clear" />';
    }

    $("#mainColumn").html(subbox);
    switch (index) {
        case 0:
            MenuId = "mDashboard";
            break;
        case 1:
            MenuId = "tInternet";
            break;
        case 2:
            MenuId = "tWireless";
            break;
        case 3:
            MenuId = "tUssd";
            break;
        case 4:
            MenuId = "tSms";
            break;
        case 5:
            MenuId = "tPhoneBook";
            break;
        case 6:
            MenuId = "tadvanceSetting";
            break;
        case 7:
            MenuId = "mChangePwd";
            break;
        case 8:
            MenuId = "mQuickSetup";
            break;
    }
    $("#menu li a").removeClass("on");
    $("#" + MenuId).addClass("on");
    var subMenuList = "";
    var subId = "";
    for (var i = 0; i < menu.Menu.length; i++) {
        if (menu.Menu[i].name == MenuId && MenuId != "mDashboard" && MenuId != "mQuickSetup" && MenuId != "tDataTraffic" && MenuId != "tTrafficStatistical" && MenuId != "mChangePwd") {
            if (type) {
                subId = menu.Menu[i].subMenu[0].id;
            } else {
                if (g_leftSub != "" && g_leftSub != undefined) {
                    subId = g_leftSub;
                } else {
                    subId = menu.Menu[i].subMenu[0].id;
                }
            }
            // subId=menu.Menu[i].subMenu[0].id;
            for (var j = 0; j < menu.Menu[i].subMenu.length; j++) {
                var l = menu.Menu[i].subMenu[j];
                var subMenuName = jQuery.i18n.prop(l.id);
                subMenuList += '<li class="" id="' + l.id + '" onclick="displaySubContent(\'' + l.id + '\')"><a href="#">' + subMenuName + "</a></li>";
            }
            break;
        }
    }

    if (MenuId == "mDashboard") {
        if (ifSim == "nosim") {
            $("#mainColumn").html(CallHtmlFile("html/noSim.html"));
            $("#mainColumn").show();
            $("#tipMsg").html(jQuery.i18n.prop("lt_nosim_tipMsg"));
            $("#tipMsg").css("color", "#f00");
            // $.objDashboard().onLoad(true);
            $("#media_sub_menu").hide();
            $("#navigation").show();
        } else if (ifSim == "simLock") {
            $("#mainColumn").html(CallHtmlFile("html/noSim.html"));
            $("#mainColumn").show();
            $("#tipTitle").html(jQuery.i18n.prop("lt_simLock_title"));
            $("#tipTitle").css("color", "#f00");
            $("#tipMsg").html(jQuery.i18n.prop("lt_simLock_tipMsg"));
            // $.objDashboard().onLoad(true);
            $("#media_sub_menu").hide();
            $("#navigation").show();
        } else {
            $("#mainColumn").html(CallHtmlFile("html/dashboard.html"));
            $("#mainColumn").show();
            $.objDashboard().onLoad(true);
            $("#media_sub_menu").hide();
            $("#navigation").show();
        }
    } else if (MenuId == "mQuickSetup") {
        clearInterval(dashboard_interval);
        $("#mainColumn").html(CallHtmlFile("html/quickSetup.html"));
        $("#mainColumn").show();
        $.objQuickSetup().onLoad(true);
        $("#media_sub_menu").hide();
        $("#navigation").show();
    } else if (MenuId == "mChangePwd") {
        clearInterval(dashboard_interval);
        $("#mainColumn").html(CallHtmlFile("html/changePwd.html"));
        $("#mainColumn").show();
        $.objChangePwd().onLoad(true);
        $("#navigation").show();
    } else {
        clearInterval(dashboard_interval);
        $("#submenu").html(subMenuList);
        displaySubContent(subId);
        var bodyW = parseInt(document.body.offsetWidth);
        var windowW = parseInt($(".liginbox").width());
        if (bodyW < maxWindowW && windowW < maxWindowW) {
            $("#media_sub_menu").show();
        }
        $("#navigation").show();
    }

    if ($("#media_menu").css("display") != "none") {
        $("#navigation").hide();
    }
    if ($("#media_sub_menu").css("display") != "none") {
        $("#leftBar").hide();
    }
    if ($("#m_statusBar").css("display") != "none") {
        $("#statusBar").hide();
    }
    $("#leftBar_bg").css("width", parseInt(window.innerWidth) + "px");
    $("#leftBar_bg").unbind("click");
    $("#leftBar_bg").bind("click", function () {
        if ($("#leftBar").css("display") != "none") {
            $("#leftBar").hide();
        }
    });
}

function displaySubContent(obj) {
    g_leftSub = obj;
    SetCookie("leftSub", g_leftSub);
    SubMenuId = obj;
    $("#submenu li").removeClass("left_on");
    $("#" + obj).addClass("left_on");
    var menuid = obj;
    var implFun = "";
    for (var i = 1; i < menu.Menu.length; i++) {
        if (i == 7 || i == 8) {
            continue;
        }
        for (var j = 0; j < menu.Menu[i].subMenu.length; j++) {
            var l = menu.Menu[i].subMenu[j];
            if (l.id == obj && obj != "mDashboard") {
                menuid = menu.Menu[i].name;
                implFun = l.implFunction;
                break;
            }
        }
    }
    var path = "";
    switch (menuid) {
        case "mDashboard":
            path = "html/dashboard.html";
            break;
        case "tInternet":
            path = "html/internet";
            break;
        case "tHome_Network":
            path = "html/homeNetwork";
            break;
        case "tUssd":
            path = "html/ussd";
            break;
        case "tPhoneBook":
            path = "html/phoneBook/mPhoneBook.html";
            document.getElementById("Content").innerHTML = CallHtmlFile(path);
            eval("$." + implFun + "().onLoad(true)");
            $("#lt_content_titleh1").html(jQuery.i18n.prop(SubMenuId));
            //$("#navigation").show();

            return;
        case "tSms":
            if (SubMenuId == "mSmsSet") {
                path = "html/sms/mSmsSet.html";
                document.getElementById("Content").innerHTML = CallHtmlFile(path);
                $.objSmsSet().onLoad(true);
                $("#lt_content_titleh1").html(jQuery.i18n.prop(SubMenuId));
                //$("#navigation").show();
                return;
            }
            $("#lt_content_titleh1").html(jQuery.i18n.prop("tSms"));
            path = "html/sms/mSms.html";
            document.getElementById("Content").innerHTML = CallHtmlFile(path);
            $.objSms().onLoad(true);
            //$("#navigation").show();
            return;
        case "tWireless":
            path = "html/wifi";
            break;
        case "tadvanceSetting":
            path = "html/router";
            break;
    }
    path = path + "/" + obj + ".html";
    document.getElementById("Content").innerHTML = CallHtmlFile(path);
    // eval("$."+implFun+"().onLoad(true)");
    var obj = eval("$." + implFun + "({})");
    obj.onLoad(true);
    g_objContent = obj;
    $("#navigation").show();

    if ($("#media_menu").css("display") != "none") {
        $("#navigation").hide();
    }
    if ($("#media_sub_menu").css("display") != "none") {
        $("#leftBar").hide();
    }
    if ($("#m_statusBar").css("display") != "none") {
        $("#statusBar").hide();
    }
}
function dashboardOnClick(obj) {
    $("#menu li a").removeClass("on");
    var menuid = obj;
    var subMenuList = "";
    for (var i = 0; i < menu.Menu.length; i++) {
        for (var j = 0; j < menu.Menu.subMenu.length; j++) {}
    }
    $("#" + menuid).addClass("on");
}
function logOutOne() {
    showBOX2(
        jQuery.i18n.prop("lt_ManualNet_btnConfirm"),
        jQuery.i18n.prop("lt_confirm_loginOut"),
        jQuery.i18n.prop("lt_btnConfirmYes"),
        jQuery.i18n.prop("lt_btnConfirmNo"),
        function () {
            ClosemBOX2();
            logOut();
        },
        function () {
            ClosemBOX2();
        }
    );
}

function logOut() {
    var host = window.location.protocol + "//" + window.location.host + "/";
    var url = host + "xml_action.cgi?Action=logout";
    $.ajax({
        type: "GET",
        url: url,
        dataType: "html",
        async: false,
        complete: function () {
            clearAuthheader();
        },
    });
    return true;
}
function getHelp(helpPage) {
    var htmlFilename = "help_" + LANGUAGE + ".html";
    var host = window.location.protocol + "//" + window.location.host + "/";
    var url = host + htmlFilename + "#" + helpPage;

    var helpWindow = window.open(url, "newwindow");
    helpWindow.focus();
}
function getMainHelp() {
    getHelp("");
}
function showHelp() {
    $(".notes-title").click(function () {
        $(this).next().toggle();
        //$(".notes-content").toggle();
    });
    $("[id^='lt_help_']").each(function () {
        if (document.getElementById($(this).attr("id")).tagName.toLowerCase() == "input") {
            $(this).val(jQuery.i18n.prop($(this).attr("id")));
        } else {
            $(this).html(jQuery.i18n.prop($(this).attr("id")));
        }
    });
}
function showWait() {
    setDlgStyle();
    $("#mbox").show();
}
function closeWait() {
    $("#mbox").hide();
}
function showBOX2(DlgTitle, DlgMsg, btn1_txt, btn2_txt, btn1_fun, bnt2_fun) {
    setDlgStyle();
    $("#lt_mbox2_title").html(DlgTitle);
    $("#lt_mbox2_msg").html(DlgMsg);
    $("#mbox2_btn1").val(btn1_txt);
    $("#mbox2_btn2").val(btn2_txt);
    $("#mbox2").show();
    $("#mbox2_btn1").unbind("click");
    $("#mbox2_btn1").bind("click", function () {
        if (btn1_fun) {
            btn1_fun();
        }
    });
    $("#mbox2_btn2").unbind("click");
    $("#mbox2_btn2").bind("click", function () {
        if (bnt2_fun) {
            bnt2_fun();
        }
    });
}
function CloseDlg() {
    $("#confirmDlg").hide();
    $("#confirmDlg1").hide();
    $("#pawChangeBox").hide();
}
function ClosemBOX2() {
    $("#mbox2").hide();
}
function showMsgBox(DlgTitle, DlgMsg) {
    setDlgStyle();
    $("#lt_confirmDlg_title").html(DlgTitle);
    $("#lt_confirmDlg_msg").html(DlgMsg);
    if (DlgMsg.length <= 40) {
        $("#lt_confirmDlg_msg").html("<br/>" + DlgMsg + "<br/>");
    }
    $("#confirmDlg").show();
}
function showMsgBox1(DlgTitle) {
    setDlgStyle();
    $("#confirmDlg1 p").text(jQuery.i18n.prop("lt_ManualNet_lManualPromte"));
    $("#confirmDlg1 input:first").val(jQuery.i18n.prop("lt_btnCancel"));
    $("#confirmDlg1 input:last").val(jQuery.i18n.prop("lt_btnOK"));
    $("#lt_confirmDlg_title1").html(DlgTitle);
    $("#confirmDlg1").show();
}

/* function showPawChangeBox() {
    setDlgStyle();
	$("#lt_changepwd_Text").text(jQuery.i18n.prop("lt_ManualNet_lManualPromte"));
	$("#confirmDlg1 input:first").val(jQuery.i18n.prop("lt_btnOK"));
	$("#confirmDlg1 input:last").val(jQuery.i18n.prop("lt_btnCancel"));
    $("#lt_confirmDlg_title1").html(DlgTitle);   
    $("#confirmDlg1").show();
} */
function showPawChangeBox() {
    setDlgStyle();
    /* $("#lt_changepwd_Text").html(jQuery.i18n.prop("lt_changepwd_Text"));
    $("#lt_changepwd_tip").html(jQuery.i18n.prop("lt_changepwd_tip"));
    $("#lt_btn_nowchange").val(jQuery.i18n.prop("lt_btn_nowchange"));
    $("#lt_btn_latterchange").val(jQuery.i18n.prop("lt_btn_latterchange"));
		$("#lt_changepwd_noRemind").html(jQuery.i18n.prop("lt_changepwd_noRemind")) */
    $("#pawChangeBox").show();
}

function MainquickSetup() {
    oneShowQuick = 0;

    $("#mainColumn").hide();
    $("#quickSetup_box").show();
    $.objQuickSetup().onLoad(true);
    if (MenuId == "mDashboard") {
        clearInterval(dashboard_interval);
    }

    setDlgStyle();
}
function uaredirect(f) {
    try {
        if (document.getElementById("bdmark") != null) {
            return;
        }
        var b = false;
        if (arguments[1]) {
            var e = window.location.host;
            var a = window.location.href;
            if (isSubdomain(arguments[1], e) == 1) {
                f = f + "/#m/" + a;
                b = true;
            } else {
                if (isSubdomain(arguments[1], e) == 2) {
                    f = f + "/#m/" + a;
                    b = true;
                } else {
                    f = a;
                    b = false;
                }
            }
        } else {
            b = true;
        }
        if (b) {
            var c = window.location.hash;
            if (!c.match("fromapp")) {
                if (navigator.userAgent.match(/(iPhone|iPod|Android|ios)/i)) {
                    return "yes";
                } else {
                    return "no";
                }
            }
        }
    } catch (d) {}
}

function setDlgStyle() {
    var bodyW = parseInt(document.body.offsetWidth);
    var windowW = parseInt($("#divAdminApp").css("width"));
    var maxW = bodyW > windowW ? bodyW : windowW;
    var windowH = parseInt(window.innerHeight);
    var quickH = 0;
    if ($("#quickSetup_box").css("display") != "none") {
        quickH = parseInt($("#quickHeight").height()) + 170;
    }
    var leftBarH = parseInt($("#submenu").height()) + 170;
    var contentH = parseInt($("#Content").height()) + 170;
    var maxH = contentH;
    if (MenuId) {
        if ($("#quickSetup_box").css("display") != "none") {
            if (windowH > quickH && windowH > 600) {
                maxH = windowH;
            } else if (windowH < 600 && quickH < 600) {
                maxH = 600;
            } else if (quickH > windowH && quickH > 600) {
                maxH = quickH;
            }
            $("#quickBox").css("height", maxH - 170 + "px");
            if (bodyW < 430) {
                $("#quickBox").css("height", maxH - 150 + "px");
            }
        } else {
            if (windowH < 600 && leftBarH < 600 && contentH < 600) {
                maxH = 600;
            } else if (windowH > leftBarH && windowH > contentH && windowH > 600) {
                maxH = windowH;
            } else if (leftBarH > windowH && leftBarH > contentH && leftBarH > 600) {
                maxH = leftBarH;
            } else if (contentH > windowH && contentH > leftBarH && contentH > 600) {
                maxH = contentH;
            }
        }
        if (MenuId != "mDashboard") {
            $("#mainColumn").css("min-height", parseInt(maxH - 150) + "px");
            if (bodyW < 430) {
                $("#mainColumn").css("min-height", parseInt(maxH - 140) + "px");
            }
        } else {
            $("#mainColumn").css("min-height", "auto");
            if ($("#quickSetup_box").css("display") == "none") {
                maxH = 974;
                if (bodyW < 430 && uaredirect("index.html") == "yes") {
                    maxH = 1373;
                } else if (bodyW > 430 && uaredirect("index.html") == "yes") {
                    maxH = 993;
                }
            }
        }
    } else {
        maxH = 600;
    }

    // drawTriangle(maxH);
    $("#mbox").css("height", maxH + "px");
    $("#confirmDlg").css("height", maxH + "px");
    $("#mbox2").css("height", maxH + "px");
    $("#mbox1").css("height", maxH + "px");
    $(".popUpBox.popUpBox2")
        .parent()
        .css("height", maxH + "px");
    $("#menu_bg").css("height", maxH + "px");
    $("#leftBar_bg").css("height", maxH + "px");

    if (bodyW > windowW) {
        $(".loginArea").css("left", bodyW - 150 + "px");
    } else {
        $(".loginArea").css("left", "1050px");
    }
    if (bodyW < 769) {
        $("#media_menu").show();
        $("#m_statusBar").show();
        $("#statusBar").hide();
        $("#leftBar").hide();
        // $("#headLogo").hide();
        if (MenuId && MenuId != "mDashboard") {
            $("#media_sub_menu").show();
        } else {
            $("#media_sub_menu").hide();
        }
        $(".loginArea").css("left", "0px");
        $("#mbox").css("width", bodyW + "px");
        $("#confirmDlg").css("width", bodyW + "px");
        $("#mbox2").css("width", bodyW + "px");
        $("#mbox1").css("width", bodyW + "px");
        $(".popUpBox.popUpBox2")
            .parent()
            .css("width", bodyW + "px");
        $("#menu_bg").css("width", bodyW + "px");
        $("#leftBar_bg").css("width", bodyW + "px");
        $("#quickSetup_box").css("width", bodyW + "px");
        return;
    } else if (bodyW > 769 && bodyW <= 1200 && uaredirect("index.html") == "yes") {
        maxW = 1200;
    } else {
        $("#media_menu").hide();
        $("#media_sub_menu").hide();
        $("#m_statusBar").hide();
        $("#navigation").show();
        $("#statusBar").show();
    }
    if (MenuId && MenuId != "mDashboard") {
        $("#leftBar").show();
    } else {
        $("#leftBar").hide();
    }
    $("#mbox").css("width", maxW + "px");
    $("#confirmDlg").css("width", maxW + "px");
    $("#mbox2").css("width", maxW + "px");
    $("#mbox1").css("width", maxW + "px");
    $(".popUpBox.popUpBox2")
        .parent()
        .css("width", maxW + "px");
    $("#menu_bg").css("width", maxW + "px");
    $("#leftBar_bg").css("width", maxW + "px");
    $("#quickSetup_box").css("width", maxW + "px");
}
function afterRebootConf() {
    closeWait();
    clearInterval(afterRebootID);
    clearAuthheader();
}
// -------------------------------------------------------------objDashboard-----------------------------------------------------------------

quickNowPage = "divQsUserNamePage";
var oneShowQuick = 0;
var sSpeedArr = [];
var rSpeedArr = [];
var staticsTip = false;
var staticsTipOne = false;
(function ($) {
    $.objDashboard = function () {
        var that = this;
        var pinStatus = "0";
        var simStatus = "0";
        this.onLoad = function (flag) {
            if (flag) {
                setDlgStyle();
                that.displayControls();
                that.btnOpenClose();
            }
            that.displayInfo();
            that.showData();

            setDlgStyle();
            //wuqin add
            clearInterval(dashboard_interval);
            dashboard_interval = setInterval(function () {
                that.showData("1");
            }, 2000);
        };
        this.btnOpenClose = function () {
            $("#switch_network").unbind("click");
            $("#switch_network").bind("click", function () {
                var className = $("#connect_switch").attr("class");
                var jsonData = {};
                if (className.indexOf("h_connect_on") != -1) {
                    jsonData.connect_disconnect = "disabled";
                } else {
                    jsonData.connect_disconnect = "cellular";
                }
                showWait();
                setTimeout(function () {
                    postJSON("wan_set", jsonData, function (data) {
                        callJSON("homepage_info", function (json) {
                            if (json.connect_disconnect == "cellular") {
                                $("#connect_switch").addClass("h_connect_on").removeClass("h_connect_off");
                                $("#ConnectImag").addClass("ConnectImag").removeClass("disconnectImag");
                            } else {
                                $("#ConnectImag").addClass("disconnectImag").removeClass("ConnectImag");
                                $("#connect_switch").removeClass("h_connect_on").addClass("h_connect_off");
                            }
                        });
                    });
                }, 100);
            });
            $("#networt_setting").click(function () {
                displaySubMenu(1, true);
            });
            $("#wireless_setting").click(function () {
                displaySubMenu(2, true);
            });
            $(".traffic_control_container").click(function () {
                displaySubMenu(6, true);
                displaySubContent("mTrafficStatistical");
            });
            $(".connected_devices_container").click(function () {
                displaySubMenu(6, true);
                displaySubContent("mDataTraffic");
            });
            $("#showDetailInfo").click(function () {
                setAddBoxHeigth("divDeviceInfoDlg");
                $("#divDeviceInfoDlg").show();
            });
            $("#a_close_DeviceInfo").unbind("click");
            $("#a_close_DeviceInfo").bind("click", function () {
                $("#divDeviceInfoDlg").hide();
            });
            $("#lBtnOk").unbind("click");
            $("#lBtnOk").bind("click", function () {
                $("#divDeviceInfoDlg").hide();
            });
        };
        this.showNA = function (str) {
            if (str == "" || str == null || str == undefined || str == "n/a") {
                return "N/A";
            } else {
                return str;
            }
        };

        this.displayInfo = function () {
            callJSON("homepage_info", function (json) {
                if (!json) {
                    return;
                }
                pinStatus = json.pin_status;
                simStatus = json.sim_status;
                var conn = json.connect_disconnect;
                var wifiConn = json.wlan_enable;
                if (pinStatus == "0" && simStatus == "0" && conn == "cellular") {
                    document.getElementById("ConnectImag").className = "ConnectImag";
                    $("#switch_network").removeClass("hide");
                    $("#connect_switch").addClass("h_connect_on").removeClass("h_connect_off");
                } else if (pinStatus == "0" && simStatus == "0" && conn != "cellular") {
                    document.getElementById("ConnectImag").className = "disconnectImag";
                    $("#switch_network").removeClass("hide");
                    $("#connect_switch").addClass("h_connect_off").removeClass("h_connect_on");
                } else {
                    document.getElementById("ConnectImag").className = "disconnectImag";
                    document.getElementById("switch_network").className = "hide";
                    $("#connectTime").html("00:00:00");
                }
                var wifi_coverage = json.wifi_coverage;
                var coverageVlue;
                if (wifi_coverage == "0") {
                    coverageVlue = jQuery.i18n.prop("lt_wifiCoverage_LongEnabled");
                } else if (wifi_coverage == "1") {
                    coverageVlue = jQuery.i18n.prop("lt_wifiCoverage_MediumEnabled");
                } else if (wifi_coverage == "2") {
                    coverageVlue = jQuery.i18n.prop("lt_wifiCoverage_shortEnabled");
                }
                $("#txtRouterLanIP").html(that.showNA(json.lan_ip));
                $("#txtRouterMAC").html(that.showNA(json.mac));
                $("#txt_IMSI").html(that.showNA(json.imsi));
                $("#txt_maxNum").html(that.showNA(json.max_access_number));
                $("#txtWifiSSID").html(that.showNA(UniDecode(json.ssid)));
                $("#txtRouterIMEI").html(that.showNA(json.imei));
                //$("#txtWanIp").html(that.showNA(json.wan_ip));
                $("#txt_pop_iccid").html(that.showNA(json.iccid));
                $("#txtSimCardNum").html(that.showNA(json.msisdn));
                $("#txt_pop_imei").html(that.showNA(json.imei));
                $("#txt_pop_imsi").html(that.showNA(json.imsi));
                $("#txt_pop_ssid").html(that.showNA(UniDecode(json.ssid)));
                $("#txt_pop_maxNum").html(that.showNA(json.max_access_number));
                //$("#txt_pop_wifiCoverage").html(coverageVlue);
                //$("#txt_pop_lanDomain").html(that.showNA(json.lan_domain));
                $("#txt_pop_ipAddress").html(that.showNA(json.lan_ip));
                $("#txt_pop_macAddress").html(that.showNA(json.mac));
                $("#txt_pop_wanAddress").html(that.showNA(json.wan_ip));
                $("#txt_pop_softVersion").html(that.showNA(json.sw_version));
                $("#txt_pop_hardVersion").html(that.showNA(json.hw_version));
                callJSON("wlan_security_info", function (json) {
                    var wifiPasswd;
                    var _strSecurityType;
                    var security_mode = json.mode;
                    if (security_mode.length == 0 || security_mode == null || security_mode == "") {
                        _strSecurityType = "None";
                        wifiPasswd = "";
                    } else {
                        _strSecurityType = security_mode;
                    }
                    if (_strSecurityType != "None") {
                        if (_strSecurityType == "WEP") {
                            wifiPasswd = json[_strSecurityType].key1;
                        } else {
                            wifiPasswd = json[_strSecurityType].key;
                        }
                    }
                    // $("#qrcode1").html("");
                    // var qrcode = new QRCode(document.getElementById("qrcode1"), {
                    //     width : 100,
                    //     height : 100
                    // });
                    // var elText = "WIFI:T:"+_strSecurityType +";S:"+UniDecode(strSSID)+";P:"+wifiPasswd+";";
                    var elText;
                    if (_strSecurityType != "None") {
                        elText = "WIFI:T:WPA;S:" + UniDecode(json.ssid) + ";P:" + wifiPasswd + ";";
                    } else {
                        elText = "WIFI:S:" + UniDecode(json.ssid) + ";";
                    }
                    // qrcode.makeCode(elText);
                });
            });
        };

        this.showData = function (type) {
            callJSON(
                "status_info",
                function (json) {
                    if (!json) {
                        return;
                    }
                    var sendSpeed = parseInt(json.tx_speed);
                    var receivedSpeed = parseInt(json.rx_speed);
                    $("#wirelessDeviceNum").html(that.showNA(json.wifi_clients_num));
                    if (pinStatus == "0" && simStatus == "0") {
                        that.signalShow(parseInt(json.rssi));
                        var run_seconds = json.run_seconds;
                        $("#connectTime").html(formatSeconds(run_seconds, jQuery.i18n.prop("ldDays"), jQuery.i18n.prop("ldHours"), jQuery.i18n.prop("ldMinutes"), jQuery.i18n.prop("ldSeconds")));
                        $("#txtSendSpeed").html(FormatDataTrafficMinUnitKB(sendSpeed) + "/s");
                        $("#txtReceivedSpeed").html(FormatDataTrafficMinUnitKB(receivedSpeed) + "/s");
                    } else {
                        $("#txtSendSpeed").html("0b/s");
                        $("#txtReceivedSpeed").html("0b/s");
                        that.signalShow(0);
                    }
                },
                type
            );
            callJSON(
                "digitel_data_volume_limit_get",
                function (jsonOne) {
                    var staticsStatus = jsonOne.data_volume_limit_switch; //0 closed  1 opened
                    var staticsType = jsonOne.data_volume_limit_mode; // 数据统计   时间统计
                    var totalValue = jsonOne.digitel_limit_total_data; //总数据
                    var usedValue = jsonOne.digitel_cur_used_data; //已使用
                    var leftValue = totalValue - leftValue; //剩余
                    var thresholdValue = (totalValue * jsonOne.data_volume_alert_percent) / 100; //阈值
                    var totalTimeValue = jsonOne.digitel_limit_total_time; //总数据
                    var usedTimeValue = jsonOne.digitel_cur_used_time; //已使用
                    var leftTimeValue = totalTimeValue - usedTimeValue; //剩余
                    var thresholdTimeValue = (totalTimeValue * jsonOne.data_volume_alert_percent) / 100;

                    var limit_status = jsonOne.digitel_cur_limit_status;
                    if (!staticsTip) {
                        if (limit_status == "1" && staticsStatus == "1") {
                            var className = $("#connect_switch").attr("class");
                            var jsonData = {};
                            if (className.indexOf("h_connect_on") != -1) {
                                showBOX2(
                                    jQuery.i18n.prop("lt_ManualNet_btnConfirm"),
                                    jQuery.i18n.prop("lt_disconnect_network"),
                                    jQuery.i18n.prop("lt_btnOK"),
                                    jQuery.i18n.prop("lt_btnCancel"),
                                    function () {
                                        ClosemBOX2();
                                        var jsonData = {};
                                        jsonData.connect_disconnect = "disabled";
                                        showWait();
                                        setTimeout(function () {
                                            postJSON("wan_set", jsonData, function (data) {
                                                callJSON("homepage_info", function (json) {
                                                    if (json.connect_disconnect == "cellular") {
                                                        $("#connect_switch").addClass("h_connect_on").removeClass("h_connect_off");
                                                    } else {
                                                        $("#connect_switch").removeClass("h_connect_on").addClass("h_connect_off");
                                                    }
                                                });
                                            });
                                        }, 100);
                                    },
                                    function () {
                                        ClosemBOX2();
                                    }
                                );
                                staticsTip = true;
                            }
                        }
                    }
                    if (!staticsTipOne) {
                        if (limit_status == "2" && staticsStatus == "1") {
                            var className = $("#connect_switch").attr("class");
                            var jsonData = {};
                            if (className.indexOf("h_connect_on") != -1) {
                                showBOX2(
                                    jQuery.i18n.prop("lt_ManualNet_btnConfirm"),
                                    jQuery.i18n.prop("lt_disconnect_network1") + jsonOne.data_volume_alert_percent + jQuery.i18n.prop("lt_disconnect_network2"),
                                    jQuery.i18n.prop("lt_btnOK"),
                                    jQuery.i18n.prop("lt_btnCancel"),
                                    function () {
                                        ClosemBOX2();
                                        var jsonData = {};
                                        jsonData.connect_disconnect = "disabled";
                                        showWait();
                                        setTimeout(function () {
                                            postJSON("wan_set", jsonData, function (data) {
                                                callJSON("homepage_info", function (json) {
                                                    if (json.connect_disconnect == "cellular") {
                                                        $("#connect_switch").addClass("h_connect_on").removeClass("h_connect_off");
                                                    } else {
                                                        $("#connect_switch").removeClass("h_connect_on").addClass("h_connect_off");
                                                    }
                                                });
                                            });
                                        }, 100);
                                    },
                                    function () {
                                        ClosemBOX2();
                                    }
                                );
                                staticsTipOne = true;
                            }
                        }
                    }
                },
                type
            );
            callJSON(
                "statistics_info",
                function (json) {
                    var f_rx_data = parseInt(json.rx_byte_all);
                    var f_tx_data = parseInt(json.tx_byte_all);

                    $("#txtRxByteFromRestoreFactory").html(FormatDataTrafficMinUnitKB(f_rx_data));
                    $("#txtTxByteFromRestoreFactory").html(FormatDataTrafficMinUnitKB(f_tx_data));
                },
                type
            );
            callJSON(
                "engineering_info",
                function (json) {
                    if (json.sys_mode == "17" && Object.keys(json.lte).length > 1) {
                        $("#deviceInfo_eng_4g").show();
                        $("#txt_pop_pci").html(json.lte.phyCellId);
                        var ECGI = json.lte.ECGI;
                        $("#txt_pop_cellid").html(ECGI.substring(ECGI.length - 2));
                        var txt_rsrp = json.lte.rsrp;
                        var txt_rsrq = json.lte.rsrq;
                        var txt_rssi = json.lte.rssi;
                        txt_rsrp = parseInt(txt_rsrp) - 141;
                        txt_rsrq = -20 + txt_rsrq / 2;
                        txt_rssi = parseInt(txt_rssi) - 128;
                        $("#txt_pop_rsrp").html(txt_rsrp + " dBm");
                        $("#txt_pop_rsrq").html(txt_rsrq + " dB");
                        $("#txt_pop_sinr").html(json.lte.sinr + " dB");
                        $("#txt_pop_rssi").html(txt_rssi + " dBm");
                    } else {
                        $("#deviceInfo_eng_4g").hide();
                    }
                },
                type
            );
        };
        this.signalShow = function (num) {
            if (num == 0) {
                $("#txt_signal").html("— —");
                $("#txt_pop_signal").html("— —");
            } else {
                $("#txt_signal").html(num + " dBm");
                $("#txt_pop_signal").html(num + " dBm");
            }
        };

        this.displayControls = function () {
            $("#lt_Connectstatus_h3").html(jQuery.i18n.prop("lt_Connectstatus_h3"));
            $("#lt_network_h3").html(jQuery.i18n.prop("lt_network_h3"));
            $("#lt_wireless_h3").html(jQuery.i18n.prop("lt_wireless_h3"));
            $("#lt_TrafficStatistic_h3").html(jQuery.i18n.prop("lt_notSet"));
            $("#lt_wireless_name").html(jQuery.i18n.prop("lt_wireless_name"));
            $("#lt_used_statics").html(jQuery.i18n.prop("lt_used_statics"));
            $("#lt_dashbd_IMEI").html(jQuery.i18n.prop("lt_dashbd_IMEI"));
            $("#lt_dashbd_routerLanIp").html(jQuery.i18n.prop("lt_dashbd_routerLanIp"));
            $("#lt_pop_iccid").html(jQuery.i18n.prop("lt_pop_iccid"));
            $("#lt_dashbd_RouterMAC").html(jQuery.i18n.prop("lt_dashbd_RouterMAC"));
            $("#lt_deviceInfo_imsi").html(jQuery.i18n.prop("lt_deviceInfo_imsi"));
            $("#max_access_Num").html(jQuery.i18n.prop("max_access_Num"));
            $("#lt_signal_Strength").html(jQuery.i18n.prop("lt_signal_Strength"));
            $("#lt_dashbd_wifiSSID").html(jQuery.i18n.prop("lt_dashbd_wifiSSID"));
            $("#showDetailInfo").html(jQuery.i18n.prop("lt_dashDetailInfo"));
            $("#networt_setting").html(jQuery.i18n.prop("lt_network_h3"));
            $("#wireless_setting").html(jQuery.i18n.prop("lt_wifiSet_title"));
            $("#lt_simcardNum").html(jQuery.i18n.prop("lt_dashbd_phoneNum"));
            $("#lt_pop_imei").html(jQuery.i18n.prop("lt_dashbd_IMEI"));
            $("#lt_pop_imsi").html(jQuery.i18n.prop("lt_deviceInfo_imsi"));
            $("#lt_pop_signal").html(jQuery.i18n.prop("lt_signal_Strength"));
            $("#lt_pop_ssid").html(jQuery.i18n.prop("lt_dashbd_wifiSSID"));
            $("#lt_pop_maxNum").html(jQuery.i18n.prop("max_access_Num"));
            $("#lt_pop_wifiCoverage").html(jQuery.i18n.prop("lt_pop_wifiCoverage"));
            $("#lt_popLanDomain").html(jQuery.i18n.prop("lt_popLanDomain"));
            $("#lt_pop_macAddress").html(jQuery.i18n.prop("lt_dashbd_RouterMAC"));
            $("#lt_pop_wanAddress").html(jQuery.i18n.prop("lt_wan_ip"));
            $("#lt_pop_softVersion").html(jQuery.i18n.prop("lt_dashbd_SoftVersion"));
            $("#lt_pop_hardVersion").html(jQuery.i18n.prop("lt_dashbd_HardVersion"));
            $("#lt_pop_ipAddress").html(jQuery.i18n.prop("lt_dashbd_routerLanIp"));
            $("#deviceInfo_title").html(jQuery.i18n.prop("deviceInfo_title"));
            $("#statusInfoBoxTitle").html(jQuery.i18n.prop("deviceInfo_title"));

            $("#lt_rsrp_pop").html(jQuery.i18n.prop("deviceInfo_rsrp"));
            $("#lt_pop_rsrq").html(jQuery.i18n.prop("deviceInfo_rsrq"));
            $("#lt_pop_rssi").html(jQuery.i18n.prop("deviceInfo_rssi"));
            $("#lt_pop_sinr").html(jQuery.i18n.prop("lt_dashbd_LTE_sinr"));
            $("#lt_pop_cellid").html(jQuery.i18n.prop("lt_dashbd_LTE_cellid"));
            $("#lt_pop_pci").html(jQuery.i18n.prop("lt_dashbd_LTE_phy_cellid"));

            $("#ltFromRestore_commTraffic_RxByte").html(jQuery.i18n.prop("lt_commTraffic_RxByte"));
            $("#ltFromRestore_portTrigger_TxByte").html(jQuery.i18n.prop("lt_portTrigger_TxByte"));
        };
        return this;
    };
})(jQuery);
function GetAuthType(encryptInfo) {
    var authType;
    switch (encryptInfo) {
        case "wpa2":
            authType = jQuery.i18n.prop("lt_wifiSet_WPA2");
            break;
        case "none":
            authType = jQuery.i18n.prop("lt_wifiSet_None");
            break;
        case "wpa":
            authType = jQuery.i18n.prop("lt_wifiSet_WPAWPA2");
            break;
        case "wep":
        case "wep-open":
            authType = jQuery.i18n.prop("lt_wifiSet_WEP");
            break;
        default:
            authType = "Unknow Error";
            break;
    }
    return authType;
}
function dashboardOnClick(obj) {
    var menuid = "";
    for (var i = 0; i < menu.Menu.length; i++) {
        if (menu.Menu[i].subMenu) {
            for (var j = 0; j < menu.Menu[i].subMenu.length; j++) {
                var l = menu.Menu[i].subMenu[j];
                if (l.id == obj && obj != "mDashboard") {
                    menuid = menu.Menu[i].name;
                    break;
                }
            }
        }
    }
    var subbox = '<div class="leftBar" id="leftBar"><div class="leftBar_bg" id="leftBar_bg"></div><ul class="leftMenu" id="submenu"></ul></div><div id="Content" class="content"></div><br class="clear" /><br class="clear" />';

    $("#mainColumn").html(subbox);
    var menuList = '<li style="width:117.6px;" ><a href="#" class="on" id="mDashboard" onclick="displaySubMenu(0)">' + jQuery.i18n.prop("mDashboard") + "</a></li>";
    for (var k = 1; k < menu.Menu.length; k++) {
        var m = menu.Menu[k];
        var MenuName = jQuery.i18n.prop(m.name);
        var lname = m.name;
        menuList += '<li style="width:117.6px;" ><a href="#" id="' + lname + '" onclick="displaySubMenu(' + k + ')">' + MenuName + "</a></li>";
    }
    $("#menu").html(menuList);
    $("#menu li a").removeClass("on");
    $("#" + menuid).addClass("on");

    var subMenuList = "";
    for (var a = 0; a < menu.Menu.length; a++) {
        if (menu.Menu[a].name == menuid && menuid != "mDashboard") {
            for (var b = 0; b < menu.Menu[a].subMenu.length; b++) {
                var n = menu.Menu[a].subMenu[b];
                var subMenuName = jQuery.i18n.prop(n.id);
                subMenuList += '<li class="" id="' + n.id + '" onclick="displaySubContent(\'' + n.id + '\')"><a href="#">' + subMenuName + "</a></li>";
            }
            break;
        }
    }
    clearInterval(dashboard_interval);

    $("#submenu").html(subMenuList);
    displaySubContent(obj);

    $("#media_menu").unbind("click");
    $("#media_menu").bind("click", function () {
        $("#leftBar").hide();
        $("#statusBar").hide();
        $("#m_statusBar").show();
        if ($("#navigation").css("display") == "none") {
            $("#navigation").show();
        } else {
            $("#navigation").hide();
        }
    });
    $("#media_sub_menu").unbind("click");
    $("#media_sub_menu").bind("click", function () {
        $("#navigation").hide();
        $("#statusBar").hide();
        $("#m_statusBar").show();
        if ($("#leftBar").css("display") == "none") {
            $("#leftBar").show();
        } else {
            $("#leftBar").hide();
        }
    });
    $("#leftBar_bg").css("width", parseInt(window.innerWidth) + "px");
    $("#leftBar_bg").unbind("click");
    $("#leftBar_bg").bind("click", function () {
        if ($("#leftBar").css("display") != "none") {
            $("#leftBar").hide();
        }
    });
}
// -------------------------------------------------------------objQuickSetup-----------------------------------------------------------------
(function ($) {
    $.objQuickSetup = function () {
        var that = this;
        this.onLoad = function (flag) {
            if (flag) {
            }
            that.displayControls();
            that.showHTMLData();
        };
        this.showHTMLData = function () {
            $("#divQsUserNamePage").show();
            $("#userPageContent").html(CallHtmlFile("html/router/mAccountManage.html"));
            $.objAccountManage().onLoad(true);
            $(".form-note").hide();
            setDlgStyle();
        };
        this.showPage = function () {
            $("#lt_qs_h1UserSettings").removeClass("quick_on");
            $("#lt_qs_h1InternetConnection").removeClass("quick_on");
            $("#lt_qs_h1WirelessSeetings").removeClass("quick_on");
            $("#lt_qs_h1DevicePlaceGuid").removeClass("quick_on");
            $("#divQsUserNamePage").hide();
            $("#divQsInternetConnPage").hide();
            $("#divQsWifiSetPage").hide();
            $("#" + quickNowPage).show();
            switch (quickNowPage) {
                case "divQsUserNamePage":
                    $("#lt_qs_h1UserSettings").addClass("quick_on");
                    $("#userPageContent").html(CallHtmlFile("html/router/mAccountManage.html"));
                    $.objAccountManage().onLoad(true);
                    $(".form-note").hide();
                    break;
                case "divQsInternetConnPage":
                    $("#lt_qs_h1InternetConnection").addClass("quick_on");
                    $("#InternetPageContent").html(CallHtmlFile("html/internet/mInternetConn.html"));
                    $.objInternetConn().onLoad(true);
                    $(".form-note").hide();
                    break;
                case "divQsWifiSetPage":
                    $("#lt_qs_h1WirelessSeetings").addClass("quick_on");
                    $("#wifiPageContent").html(CallHtmlFile("html/wifi/mWifisecuritySet.html"));
                    $.objWifisecuritySet().onLoad(true);
                    $(".form-note").hide();
                    break;
            }
            setDlgStyle();
        };
        this.displayControls = function () {
            $("#lt_qs_h1UserSettings").text(jQuery.i18n.prop("lt_qs_h1UserSettings"));
            $("#lt_qs_h1InternetConnection").text(jQuery.i18n.prop("lt_qs_h1InternetConnection"));
            $("#lt_qs_h1WirelessSeetings").text(jQuery.i18n.prop("lt_qs_h1WirelessSeetings"));

            $("#lt_qs_btnExit").text(jQuery.i18n.prop("lt_qs_btnExit"));
            $("#lt_qs_btnExit1").text(jQuery.i18n.prop("lt_qs_btnExit"));
            $("#lt_qs_btnExit2").val(jQuery.i18n.prop("lt_qs_btnExit"));
            $("#lt_qs_btnNext").val(jQuery.i18n.prop("lt_qs_btnNext"));
            $("#lt_qs_btnNext1").val(jQuery.i18n.prop("lt_qs_btnNext"));
            $("#lt_qs_btnNext2").val(jQuery.i18n.prop("lt_qs_btnNext"));
            $("#lt_qs_btnBack").val(jQuery.i18n.prop("lt_qs_btnBack"));
            $("#lt_qs_btnBack1").val(jQuery.i18n.prop("lt_qs_btnBack"));
        };
        return this;
    };
})(jQuery);

function ExitQuickSetup() {
    displaySubMenu(0);
    setDlgStyle();
    $("#userPageContent").html("");
    $("#InternetPageContent").html("");
    $("#wifiPageContent").html("");
}

function showDiv(page) {
    quickNowPage = page;
    $.objQuickSetup().showPage();
    setDlgStyle();
}

// -------------------------------------------------------------objInternetConn-----------------------------------------------------------------
(function ($) {
    $.objInternetConn = function () {
        var that = this;
        var mtu_value;
        var g_network_mode;
        var g_prefer_lte_type;
        var connect_mode = "";
        var roaming_disable_auto_dial = "";
        this.onLoad = function (flag) {
            connect_mode = "";
            roaming_disable_auto_dial = "";
            if (flag) {
                that.displayControls();
                that.dialSet();
                that.btnEvent();
                that.networkSelection();
                showHelp();
            }
            that.showData();
            setDlgStyle();
        };
        this.showData = function () {
            callJSON("wan_info", function (json) {
                var network_mode = json.NW_mode;
                g_network_mode = network_mode;
                var preferred_mode = json.prefer_mode;
                var prefer_lte_type = json.prefer_lte_type;
                g_prefer_lte_type = prefer_lte_type;
                var network_mode_default = json.NW_mode_default;
                var optHtml = "";

                if (network_mode_default == "1") {
                    optHtml = "<option value='1'>" + jQuery.i18n.prop("lt_interCon_dropdownMultimode") + "</option>" + "<option value='2'>" + jQuery.i18n.prop("lt_interCon_dropdown4Gonly") + "</option>" + "<option value='3'>" + jQuery.i18n.prop("lt_interCon_dropdown43Gonly") + "</option>" + "<option value='4'>" + jQuery.i18n.prop("lt_interCon_dropdown32Gonly") + "</option>" + "<option value='5'>" + jQuery.i18n.prop("lt_interCon_dropdown3Gonly") + "</option>" + "<option value='6'>" + jQuery.i18n.prop("lt_interCon_dropdown2Gonly") + "</option>";
                } else if (network_mode_default == "2") {
                    optHtml = "<option value='2'>" + jQuery.i18n.prop("lt_interCon_dropdown4Gonly") + "</option>";
                } else if (network_mode_default == "3") {
                    optHtml = "<option value='2'>" + jQuery.i18n.prop("lt_interCon_dropdown4Gonly") + "</option>" + "<option value='3'>" + jQuery.i18n.prop("lt_interCon_dropdown43Gonly") + "</option>" + "<option value='5'>" + jQuery.i18n.prop("lt_interCon_dropdown3Gonly") + "</option>";
                } else if (network_mode_default == "8") {
                    optHtml = "<option value='2'>" + jQuery.i18n.prop("lt_interCon_dropdown4Gonly") + "</option>" + "<option value='6'>" + jQuery.i18n.prop("lt_interCon_dropdown2Gonly") + "</option>";
                } else if (network_mode_default == "4") {
                    optHtml = "<option value='5'>" + jQuery.i18n.prop("lt_interCon_dropdown3Gonly") + "</option>" + "<option value='4'>" + jQuery.i18n.prop("lt_interCon_dropdown32Gonly") + "</option>" + "<option value='6'>" + jQuery.i18n.prop("lt_interCon_dropdown2Gonly") + "</option>";
                } else if (network_mode_default == "5") {
                    optHtml = "<option value='5'>" + jQuery.i18n.prop("lt_interCon_dropdown3Gonly") + "</option>";
                } else if (network_mode_default == "6") {
                    optHtml = "<option value='6'>" + jQuery.i18n.prop("lt_interCon_dropdown2Gonly") + "</option>";
                } else if (network_mode_default == "7") {
                    optHtml = "<option value='7'>" + jQuery.i18n.prop("lt_interCon_dropdownDisableNw") + "</option>";
                }
                $("#network_selectModeType").html(optHtml);

                if ("2" == network_mode || "1" == network_mode || "3" == network_mode) {
                    // only 4G
                    document.getElementById("network_selectModeType").value = network_mode;
                    //document.getElementById("network_lteType").value = prefer_lte_type;
                    // $("#lteNetworkType").show();
                } else if ("5" == network_mode || "6" == network_mode || "4" == network_mode) {
                    // only 3G
                    document.getElementById("network_selectModeType").value = network_mode;
                    // $("#lteNetworkType").hide();
                } else {
                    document.getElementById("network_selectModeType").value = network_mode;
                    //document.getElementById("network_lteType").value = prefer_lte_type;
                }
                $("#mtu_input").val(json.mtu);
                mtu_value = json.mtu;

                connect_mode = json.connect_mode;
                if (connect_mode == "1") {
                    $("#radio_manual").prop("checked", true);
                } else {
                    $("#radio_auto").prop("checked", true);
                }

                roaming_disable_auto_dial = json.Roaming_disable_auto_dial;
                if (roaming_disable_auto_dial == "1") {
                    $("#check_roaming").prop("checked", false);
                } else {
                    $("#check_roaming").prop("checked", true);
                }

                var conn = json.proto;
                if (conn == "cellular") {
                    $("#sel_connect").val("cellular");
                } else {
                    $("#sel_connect").val("disabled");
                }
                closeWait();
                if (network_mode_default == "") {
                    showWait();
                    setTimeout(function () {
                        that.showData();
                    }, 10000);
                }
            });
        };
        this.dialSet = function () {
            $("#btn_dialSet").unbind("click");
            $("#btn_dialSet").bind("click", function () {
                var jsonData = {};
                var auto_manual, data_roaming;
                auto_manual = $("#radio_manual").is(":checked") ? "1" : "0";
                data_roaming = $("#check_roaming").is(":checked") ? "0" : "1";
                var conn = $("#sel_connect").val();
                jsonData.proto = conn;
                var flag = false;
                if (auto_manual == "1") {
                    jsonData.connect_mode = auto_manual;
                    flag = true;
                } else {
                    jsonData.connect_mode = "0";
                    flag = true;
                }
                if (data_roaming != roaming_disable_auto_dial) {
                    jsonData.Roaming_disable_auto_dial = data_roaming;
                    jsonData.Roaming_disable_auto_dial_action = "1";
                    flag = true;
                }
                if (!flag) {
                    return;
                }
                showWait();
                setTimeout(function () {
                    postJSON("wan_set", jsonData, function (data) {
                        showMsgBox(jQuery.i18n.prop("dialog_message_network_model_title"), jQuery.i18n.prop("dialog_message_network_model_success"));
                        that.onLoad(false);
                    });
                }, 100);
            });
        };
        this.btnEvent = function () {
            $("#mtu_input").unbind("input");
            $("#mtu_input").bind("input", function () {
                that.checkMtu();
            });

            $("#network_selectModeType").unbind("change");
            $("#network_selectModeType").bind("change", function () {
                var value = $("#network_selectModeType").val();
                if ("2" == value || "3" == value || "1" == value || "8" == value) {
                    //only 4G
                    // $("#lteNetworkType").show();
                } else if ("5" == value || "6" == value || "4" == value) {
                    // only 3G
                    //$("#lteNetworkType").hide();
                } else {
                    //$("#lteNetworkType").hide();
                }
            });

            // $("#sel_connect").unbind("change");
            // $("#sel_connect").bind("change",function(){
            //     showWait();
            //     setTimeout(function(){
            //         var conn=$("#sel_connect").val();
            //         var jsonData={};
            //         jsonData.proto=conn;
            //         postJSON("wan_set",jsonData,function(data){
            //             that.onLoad(false);
            //         });
            //     },100);
            // });
        };
        this.checkMtu = function () {
            $("#error_mtu").hide();
            var mtu = parseInt($("#mtu_input").val());
            if (mtu >= 1000 && mtu <= 1500) {
                return true;
            } else {
                $("#error_mtu").show();
                $("#error_mtu").html(jQuery.i18n.prop("lMtuInvalidTip"));
                return false;
            }
        };
        this.networkSelection = function () {
            $("#btn_network_mode_apply").unbind("click");
            $("#btn_network_mode_apply").bind("click", function () {
                if (that.checkMtu()) {
                    var mtu = $("#mtu_input").val();
                    var selectModeType = $("#network_selectModeType").val();
                    //var preferred=$("#network_lteType").val();

                    var jsonData = {};
                    var flag = false;
                    if (selectModeType != g_network_mode) {
                        flag = true;
                        jsonData.NW_mode = selectModeType;
                        jsonData.NW_mode_action = "1";
                        //jsonData.prefer_lte_type=preferred;
                        /* if(selectModeType=="5"){
						    jsonData.prefer_lte_type_action="0";
						}else{
						    jsonData.prefer_lte_type_action="1";
						} */
                        if (selectModeType == "1") {
                            jsonData.prefer_mode = "1";
                            jsonData.prefer_mode_action = "1";
                        } else if (selectModeType == "3") {
                            jsonData.prefer_mode = "3";
                            jsonData.prefer_mode_action = "1";
                        } else if (selectModeType == "4") {
                            jsonData.prefer_mode = "5";
                            jsonData.prefer_mode_action = "1";
                        } else if (selectModeType == "8") {
                            jsonData.prefer_mode = "9";
                            jsonData.prefer_mode_action = "1";
                        }
                    } else {
                        /* 	if("2" == g_network_mode || "1" == g_network_mode || "3" == g_network_mode){
							if(g_prefer_lte_type != preferred){
								flag = true;
								jsonData.NW_mode=selectModeType;
								jsonData.NW_mode_action="1";
								jsonData.prefer_lte_type=preferred;
								if(selectModeType=="5"){
								    jsonData.prefer_lte_type_action="0";
								}else{
								    jsonData.prefer_lte_type_action="1";
								}
								if(selectModeType=="1"){
								    jsonData.prefer_mode="1";
								    jsonData.prefer_mode_action = "1";
								}else if(selectModeType=="3"){
								    jsonData.prefer_mode="3";
								    jsonData.prefer_mode_action = "1";
								}else if(selectModeType=="4"){
								    jsonData.prefer_mode="5";
								    jsonData.prefer_mode_action = "1";
								}
							}
						} */
                    }

                    if (mtu_value != mtu) {
                        flag = true;
                        jsonData.mtu = mtu;
                        jsonData.mtu_action = "1";
                    }
                    if (!flag) {
                        return false;
                    }
                    showWait();
                    setTimeout(function () {
                        postJSON("wan_set", jsonData, function () {
                            showMsgBox(jQuery.i18n.prop("dialog_message_network_model_title"), jQuery.i18n.prop("dialog_message_network_model_success"));
                            that.onLoad(false);
                        });
                    }, 100);
                }
            });
        };
        this.displayControls = function () {
            $("#lt_internetConn_title").html(jQuery.i18n.prop("lt_dial_set_title"));
            $("#lt_NetworkSelection_title").html(jQuery.i18n.prop("lt_NetworkSelection_title"));
            $("#lt_wan_conn_mode").html(jQuery.i18n.prop("lt_wan_conn_mode"));
            $("#span_connMode_auto").html(jQuery.i18n.prop("AutoSelectNWMode"));
            $("#span_connMode_manual").html(jQuery.i18n.prop("ManualSelectNWMode"));
            $("#span_data_roaming").html(jQuery.i18n.prop("span_data_roaming"));
            $("#btn_dialSet").val(jQuery.i18n.prop("lt_btnSave"));
            $("#lt_networkMode").html(jQuery.i18n.prop("lt_interCon_NetworkMode"));
            $("#type_4g3g2g").html(jQuery.i18n.prop("lt_interCon_dropdownMultimode"));
            $("#type_4g_only").html(jQuery.i18n.prop("lt_interCon_dropdown4Gonly"));
            $("#type_4g3g").html(jQuery.i18n.prop("lt_interCon_dropdown43Gonly"));
            $("#type_3g_only").html(jQuery.i18n.prop("lt_interCon_dropdown3Gonly"));
            $("#type_3g2g").html(jQuery.i18n.prop("lt_interCon_dropdown32Gonly"));
            $("#type_2g_only").html(jQuery.i18n.prop("lt_interCon_dropdown2Gonly"));
            // $("#lt_Preferred").html(jQuery.i18n.prop("lt_interCon_preferredNetworkMode"));
            /* $("#dropdownTDPre").html(jQuery.i18n.prop("lt_interCon_dropdownTDPre"));
            $("#dropdownFDDPre").html(jQuery.i18n.prop("lt_interCon_dropdownFDDPre")); */
            $("#lt_mtu").html(jQuery.i18n.prop("lt_mtu"));
            $("#btn_network_mode_apply").val(jQuery.i18n.prop("lt_btnSave"));
            $("#lt_connect").html(jQuery.i18n.prop("lt_interCon_internetConnMode"));
            $("#op_connect").html(jQuery.i18n.prop("lt_interCon_cellularMode"));
            $("#op_disconnect").html(jQuery.i18n.prop("lt_SmsSet_stcSendReportDisabled"));
        };
        return this;
    };
})(jQuery);
// -------------------------------------------------------------objManualNetwork-----------------------------------------------------------------
var smiCardExist = false;
var bIsScanNetwork = false;
var searchNetworkStartTime = 0;
var SelectNetworkValue;
(function ($) {
    $.objManualNetwork = function () {
        var that = this;
        this.onLoad = function (flag) {
            if (flag) {
                that.displayControls();
                that.btnEvent();
                showHelp();
            }
            that.showData();
            setDlgStyle();
        };
        this.showData = function () {
            callJSON("wan_manual_network_info", function (json) {
                var manual_network_check = json.manual_network_start;
                var network_param_default = json.network_param;
                var SelectNetworkValue = network_param_default;
                var auto_network = json.auto_network;
                var selectNWMode = json.select_NW_Mode;

                if (json.sim_status == 0 || json.sim_status == "0") {
                    smiCardExist = true;
                }

                if (json.mannual_network_list.length > 0 && bIsScanNetwork) {
                    bIsScanNetwork = false;
                    that.loadManualNetwork(json);
                    showMsgBox(jQuery.i18n.prop("mManualNetwork"), jQuery.i18n.prop("completeScanNetwork"));
                    $("#btUpdate1").attr("disabled", false);
                    $("#btUpdate1").removeClass("disBtn");
                } else if (json.mannual_network_list.length > 0 && !bIsScanNetwork) {
                    that.loadManualNetwork(json);
                    $("#btUpdate1").attr("disabled", false);
                    $("#btUpdate1").removeClass("disBtn");
                    var param = json.network_param.split("%");
                    var val = param[0] + "%" + param[1] + "%" + param[2];
                    $("#Networkdropdown").val(val);
                }
            });
        };
        this.loadManualNetwork = function (json) {
            $("#Networkdropdown").html("");
            var network_param_value = json.network_param;

            var name_act_web = "Auto";
            name_act_plmn = "30";
            var opt_auto = document.createElement("option");
            opt_auto.id = "dropdownAuto";
            opt_auto.text = name_act_web;
            opt_auto.value = name_act_plmn;
            document.getElementById("Networkdropdown").options.add(opt_auto);

            if (json.mannual_network_list.length > 0) {
                for (var i = 0; i < json.mannual_network_list.length; i++) {
                    var l = json.mannual_network_list[i];
                    var network_plmn = l.plmm_name;
                    var network_act = l.act;
                    var network_name = l.name;
                    if (network_plmn == "51088" || network_plmn == "51068") {
                        name_act_web = "BOLT SUPER" + " " + that.networkAct2Mode(network_act);
                    } else {
                        name_act_web = network_name + " " + that.networkAct2Mode(network_act);
                    }
                    name_act_plmn = network_name + "%" + network_act + "%" + network_plmn;
                    var opt = document.createElement("option");
                    opt.text = name_act_web + " " + network_plmn;
                    opt.value = name_act_plmn;
                    document.getElementById("Networkdropdown").options.add(opt);
                }
            }

            if (network_param_value.length == 0 || network_param_value == "30") {
                $("#Networkdropdown").val("30");
            } else {
                $("#Networkdropdown").val(network_param_value);
            }
        };
        this.networkAct2Mode = function (networkAct) {
            var act_netmode = "";
            switch (networkAct) {
                case "0":
                    act_netmode = "2G";
                    break;
                case "1":
                    act_netmode = "2G C";
                    break;
                case "2":
                    act_netmode = "3G";
                    break;
                case "3":
                    act_netmode = "2G(EDGE)";
                    break;
                case "4":
                    act_netmode = "3G(HSDPA)";
                    break;
                case "5":
                    act_netmode = "3G(HSUPA)";
                    break;
                case "6":
                    act_netmode = "3G(HSDPA+HSUPA)";
                    break;
                case "7":
                    act_netmode = "4G(LTE)";
                    break;
                default:
                    break;
            }
            return act_netmode;
        };
        this.btnEvent = function () {
            $("#btUpdate1").unbind("click");
            $("#btUpdate1").bind("click", function () {
                callJSON("wan_manual_network_info", function (json) {
                    if (json.sim_status == "1") {
                        showMsgBox(jQuery.i18n.prop("lt_lWarning"), jQuery.i18n.prop("lSimCardAbsent"));
                        return;
                    }
                    if (json.pin_status == "1") {
                        showMsgBox(jQuery.i18n.prop("lt_lWarning"), jQuery.i18n.prop("lPinEnable"));
                        return;
                    }
                    if (json.pin_status == "2") {
                        showMsgBox(jQuery.i18n.prop("lt_lWarning"), jQuery.i18n.prop("lPukEnable"));
                        return;
                    }

                    /* var ManualNetworkHTML="<p>"+jQuery.i18n.prop("lt_ManualNet_lManualPromte")+"</p><br/><div style=\"text-align:center;\"><input type=\"button\" onclick=\"btnManualScanConfirm()\" value=\""+jQuery.i18n.prop("lt_btnOK")+"\" class=\"btn-apply\"/><input type=\"button\" onclick=\"CloseDlg()\" value=\""+jQuery.i18n.prop("lt_btnCancel")+"\" class=\"btn-apply\" style=\"margin-left:20px;\" /></div>";
                    showMsgBox(jQuery.i18n.prop("lt_ManualNet_SearchNetwork"),ManualNetworkHTML); */
                    showMsgBox1(jQuery.i18n.prop("lt_ManualNet_SearchNetwork"));
                });
            });

            $("#btUpdate").unbind("click");
            $("#btUpdate").bind("click", function () {
                var network_parm = $("#Networkdropdown").val();
                var jsonData = {};
                jsonData.bgscan_time = "4";
                jsonData.bgscan_time_action = "1";
                jsonData.network_param = network_parm;
                if (SelectNetworkValue != network_parm) {
                    jsonData.network_param_action = "1";
                } else {
                    jsonData.network_param_action = "0";
                }
                jsonData.network_select_done = "0";
                jsonData.manual_network_start = "0";
                showWait();
                setTimeout(function () {
                    postJSON("wan_set", jsonData, function (data) {});
                }, 100);
            });
        };
        this.displayControls = function () {
            $("#title").html(jQuery.i18n.prop("mManualNetwork"));
            $("#lt_ManualNet_SearchNetwork").html(jQuery.i18n.prop("lt_ManualNet_SearchNetwork"));
            $("#btUpdate1").val(jQuery.i18n.prop("lt_ManualNet_btnSearchNetwork"));
            $("#lMannualNetwork").html(jQuery.i18n.prop("lt_ManualNet_lMannualNetwork"));
            $("#dropdownAuto").html(jQuery.i18n.prop("lt_ManualNet_auto"));
            $("#lManualNetworkStart").html(jQuery.i18n.prop("lManualNetworkStart"));
            $("#dispmanualnetworktext").html(jQuery.i18n.prop("dispmanualnetworktext"));
            $("#lBgScanTime").html(jQuery.i18n.prop("lt_ManualNet_BgScanTime"));
            $("#dropdownImmediate").html(jQuery.i18n.prop("lt_ManualNet_bgScan_immediately"));
            $("#dropdown30sec").html(jQuery.i18n.prop("lt_ManualNet_bgScan_30sec"));
            $("#dropdown1M").html(jQuery.i18n.prop("lt_ManualNet_bgScan_1min"));
            $("#dropdown3M").html(jQuery.i18n.prop("lt_ManualNet_bgScan_3min"));
            $("#dropdown5M").html(jQuery.i18n.prop("lt_ManualNet_bgScan_5min"));
            $("#dropdown10M").html(jQuery.i18n.prop("lt_ManualNet_bgScan_10min"));
            $("#dropdown15M").html(jQuery.i18n.prop("lt_ManualNet_bgScan_15min"));
            $("#dropdown30M").html(jQuery.i18n.prop("lt_ManualNet_bgScan_30min"));
            $("#dropdown60M").html(jQuery.i18n.prop("lt_ManualNet_bgScan_60min"));
            $("#dropdownLteTimeDisable").html(jQuery.i18n.prop("lt_ManualNet_bgScan_Disable"));
            $("#CurrentScanModeLabel").html(jQuery.i18n.prop("CurrentScanModeLabel"));
            $("#btUpdate").val(jQuery.i18n.prop("lt_btnSave"));
        };
        return this;
    };
})(jQuery);
function btnManualScanConfirm() {
    if (!bIsScanNetwork) {
        $("#btUpdate1").attr("disabled", true);
        $("#btUpdate1").addClass("disBtn");
        manualSearchNetwork();
    }
}
function manualSearchNetwork() {
    ManualNetworkSelect = 1;
    bIsScanNetwork = true;
    searchNetworkStartTime = new Date().getTime();
    var jsonData = {};
    jsonData.search_network = "1";
    jsonData.network_select_done = "0";
    showWait();
    CloseDlg();
    setTimeout(function () {
        postJSON("wan_set", jsonData, function (json) {
            showWait();
            QueryScanResult();
        });
    }, 100);
}
function QueryScanResult() {
    callJSON("wan_manual_network_info", function (wan_manual_json) {
        var currentTime = new Date().getTime();

        if (currentTime - searchNetworkStartTime > 120000) {
            closeWait();
            showMsgBox(jQuery.i18n.prop("mManualNetwork"), jQuery.i18n.prop("lScanNetworkTimeOut"));
            bIsScanNetwork = false;
            $("#div_scanning_network").hide();
            $("#btn_manual_scan_network").removeAttr("disabled");
            $("#btUpdate1").attr("disabled", false);
            $("#btUpdate1").removeClass("disBtn");
            return;
        } else {
            if (null === wan_manual_json || wan_manual_json === undefined) {
                setTimeout(QueryScanResult, 5000);
            } else {
                if (wan_manual_json.mannual_network_list.length > 0) {
                    if (!bIsScanNetwork) {
                        return;
                    }
                    closeWait();
                    showMsgBox(jQuery.i18n.prop("mManualNetwork"), jQuery.i18n.prop("completeScanNetwork"));

                    $("#btUpdate1").attr("disabled", false);
                    $("#btUpdate1").removeClass("disBtn");
                    $.objManualNetwork().onLoad(false);
                } else {
                    setTimeout(QueryScanResult, 5000);
                }
            }
        }
    });
}
// -------------------------------------------------------------objPinPuk-----------------------------------------------------------------
(function ($) {
    $.objPinPuk = function () {
        var that = this;
        var gPinStatus = "";
        var gPinRetryCnt = "";
        var gPukRetryCnt = "";
        var gPinInUse = "";
        var pin_attempts_gl;
        this.onLoad = function (flag) {
            if (flag) {
                that.displayControls();
                that.btnShowBox();
                that.EnablePinCode();
                that.DisablePinCode();
                that.ChangePinCode();
                that.EnterPinCode();
                that.EnterPukCode();
                showHelp();
            }
            that.clearTextBox();
            that.showData();
            setDlgStyle();
        };
        this.showData = function () {
            showWait();
            setTimeout(function () {
                callJSON("pin_puk_info", function (json) {
                    closeWait();
                    if (json.sim_status != "0") {
                        $("#txtPinInfo").hide();
                        showMsgBox(jQuery.i18n.prop("mPinPuk"), jQuery.i18n.prop("lUnknownNoSIM"));
                        return;
                    }
                    var mep_currentststus = json.CURRENT_STATUS;
                    gPinStatus = mep_currentststus;
                    if (mep_currentststus != "PIN_LOCK" && mep_currentststus != "PUK_LOCK" && mep_currentststus != "READY") {
                        showMsgBox(jQuery.i18n.prop("mPinPuk"), jQuery.i18n.prop("lMEPUnlockrequired"));
                        return;
                    }
                    gPinRetryCnt = json.pin_attempts;
                    pin_attempts_gl = gPinRetryCnt;
                    gPukRetryCnt = json.puk_attempts;
                    gPinInUse = json.pin_enabled;

                    if (gPinRetryCnt == "-1" || gPukRetryCnt == "-1") {
                        $("#txtPinInfo").hide();
                        showMsgBox(jQuery.i18n.prop("mPinPuk"), jQuery.i18n.prop("lUnknownNoSIM"));
                        return;
                    } else if (gPinRetryCnt == "0" && gPukRetryCnt == "0") {
                        $("#txtPinInfo").hide();
                        showMsgBox(jQuery.i18n.prop("mPinPuk"), jQuery.i18n.prop("lPukExhausted"));
                        return;
                    }

                    var pinInfo = "";
                    if (gPinInUse == "0") {
                        if (gPinRetryCnt == "0") {
                            // that.onLoad(false);
                        }
                        pinInfo = pinInfo + jQuery.i18n.prop("lt_pin_notinuse") + "<br>";
                    } else {
                        pinInfo = pinInfo + jQuery.i18n.prop("lt_pin_inuse") + "<br>";
                        pinInfo = pinInfo + jQuery.i18n.prop("lt_pin_status") + " " + jQuery.i18n.prop("lt_pin_" + gPinStatus) + "<br>";
                    }
                    pinInfo = pinInfo + jQuery.i18n.prop("lpinattempts") + gPinRetryCnt + "<br>";
                    pinInfo = pinInfo + jQuery.i18n.prop("lpukattempts") + gPukRetryCnt;
                    $("#txtPinInfo").html(pinInfo);
                    $("#txtPinInfo").show();
                    that.disablePinPukButtons();
                });
            }, 100);
        };
        this.clearTextBox = function () {
            $("#txtEnablePin").val("");
            $("#txtDisablePin").val("");
            $("#txtPuk").val("");
            $("#txtchangePin1").val("");
            $("#txtchangePin2").val("");
            $("#txtEnterPin").val("");
            $("#txtEnterPuk").val("");
            $("#txtEnterPukPin1").val("");
            $("#txtEnterPukPin2").val("");
        };
        this.disablePinPukButtons = function () {
            $("#spanEnablePin").hide();
            $("#spanDisablePin").hide();
            $("#spanChangePinCode").hide();
            $("#spanEnterPukCode").hide();
            $("#spanEnterPinCode").hide();
            $("#divEnablePin").hide();
            $("#divDisablePin").hide();
            $("#divChangePin").hide();
            $("#divEnterPuk").hide();
            $("#divEnterPin").hide();

            // PIN is not in use
            if (gPinInUse == "0" && gPinStatus == "READY") {
                $("#spanEnablePin").show();
                return;
            }
            // Disable buttons according to PIN status
            if (gPinStatus == "READY") {
                $("#spanDisablePin").show();
                $("#spanChangePinCode").show();
            } else if (gPinStatus == "PIN_LOCK") {
                // PIN Required
                if (gPinRetryCnt == "0") {
                    $("#spanEnterPukCode").show();
                } else {
                    $("#spanEnterPinCode").show();
                }
            } else if (gPinStatus == "PUK_LOCK") {
                // PUK Required
                if (gPinRetryCnt == "0") {
                    $("#spanEnterPukCode").show();
                } else {
                    $("#spanEnterPinCode").show();
                }
            }
        };
        this.refreshPinInfo = function () {
            callJSON("pin_puk_info", function (json) {
                gPinRetryCnt = json.pin_attempts;
                gPukRetryCnt = json.puk_attempts;
                gPinInUse = json.pin_enabled;
                var pinInfo = "";
                if (gPinInUse == "0") {
                    if (gPinRetryCnt == "0") {
                        that.onLoad(false);
                    }
                    pinInfo = pinInfo + jQuery.i18n.prop("lt_pin_notinuse") + "<br>";
                } else {
                    pinInfo = pinInfo + jQuery.i18n.prop("lt_pin_inuse") + "<br>";
                    pinInfo = pinInfo + jQuery.i18n.prop("lt_pin_status") + gPinStatus + "<br>";
                    if (gPinRetryCnt == "0" && gPukRetryCnt != "0") {
                        that.disablePinPukButtons();
                        $("#spanEnterPukCode").click();
                    }
                }
                pinInfo = pinInfo + jQuery.i18n.prop("lpinattempts") + gPinRetryCnt + "<br>";
                pinInfo = pinInfo + jQuery.i18n.prop("lpukattempts") + gPukRetryCnt;
                $("#txtPinInfo").html(pinInfo);
            });
        };
        this.btnShowBox = function () {
            $("#spanEnablePin").unbind("click");
            $("#spanEnablePin").bind("click", function () {
                if ($("#divEnablePin").css("display") == "none") {
                    $("#divEnablePin").show();
                } else {
                    $("#divEnablePin").hide();
                }
                that.clearText("lt_enabledPin_error");
            });
            $("#spanDisablePin").unbind("click");
            $("#spanDisablePin").bind("click", function () {
                $("#divChangePin").hide();
                if ($("#divDisablePin").css("display") == "none") {
                    $("#divDisablePin").show();
                } else {
                    $("#divDisablePin").hide();
                }
                that.clearText("lt_disablePin_error");
            });
            $("#spanChangePinCode").unbind("click");
            $("#spanChangePinCode").bind("click", function () {
                $("#divDisablePin").hide();
                if ($("#divChangePin").css("display") == "none") {
                    $("#divChangePin").show();
                } else {
                    $("#divChangePin").hide();
                }
                that.clearText("lt_changePin_error");
            });
            $("#spanEnterPukCode").unbind("click");
            $("#spanEnterPukCode").bind("click", function () {
                if ($("#divEnterPuk").css("display") == "none") {
                    $("#divEnterPuk").show();
                } else {
                    $("#divEnterPuk").hide();
                }
                that.clearText("lt_enterPuk_error");
            });
            $("#spanEnterPinCode").unbind("click");
            $("#spanEnterPinCode").bind("click", function () {
                if ($("#divEnterPin").css("display") == "none") {
                    $("#divEnterPin").show();
                } else {
                    $("#divEnterPin").hide();
                }
                that.clearText("lt_enterPin_error");
            });
        };
        this.clearText = function (objError) {
            $("#Content input[type='password']").val("");
            $("#" + objError).hide();
        };
        this.checkPin = function (pinpukVal, objError) {
            $("#" + objError).hide();
            if (pinpukVal.length < 4 || pinpukVal.length > 8 || !IsNumber_1(pinpukVal)) {
                $("#" + objError).html(jQuery.i18n.prop("linvalidPin"));
                $("#" + objError).show();
                return false;
            }
            return true;
        };
        this.checkPuk = function (pinpukVal, objError) {
            $("#" + objError).hide();
            if (pinpukVal.length != 8 || !IsNumber_1(pinpukVal)) {
                $("#" + objError).html(jQuery.i18n.prop("linvalidPuk"));
                $("#" + objError).show();
                return false;
            }
            return true;
        };
        this.checkChange = function (pin, pin1, pin2, objError) {
            if (that.checkPin(pin, objError) && that.checkPin(pin1, objError) && that.checkPin(pin2, objError)) {
                if (pin == pin1) {
                    $("#" + objError).html(jQuery.i18n.prop("lNewPinSameWithOld"));
                    $("#" + objError).show();
                    return false;
                } else if (pin1 == pin2) {
                    return true;
                } else {
                    $("#" + objError).html(jQuery.i18n.prop("linvalidNewPin"));
                    $("#" + objError).show();
                    return false;
                }
            }
            return false;
        };
        this.checkChange_puk = function (puk, pin1, pin2, objError) {
            if (that.checkPuk(puk, objError) && that.checkPin(pin1, objError) && that.checkPin(pin2, objError)) {
                if (pin1 == pin2) {
                    return true;
                } else {
                    $("#" + objError).html(jQuery.i18n.prop("linvalidNewPin"));
                    $("#" + objError).show();
                    return false;
                }
            }
            return false;
        };
        this.EnablePinCode = function () {
            $("#btnEnablePin").unbind("click");
            $("#btnEnablePin").bind("click", function () {
                var enablePin = $("#txtEnablePin").val();
                if (that.checkPin(enablePin, "lt_enabledPin_error")) {
                    var jsonData = { command: 1, pin: enablePin };
                    showWait();
                    setTimeout(function () {
                        postJSON("pin_puk_set", jsonData, function (data) {
                            if (data.result == "success") {
                                $("#divEnablePin input[type='password']").val("");
                                that.CheckCmdStatus();
                            } else {
                                showMsgBox(jQuery.i18n.prop("lt_EnablePin"), jQuery.i18n.prop("lFailedWithUnkown"));
                            }
                        });
                    });
                }
            });
        };
        this.EnterPinCode = function () {
            $("#btnEnterPin").unbind("click");
            $("#btnEnterPin").bind("click", function () {
                var enterPin = $("#txtEnterPin").val();
                if (that.checkPin(enterPin, "lt_enterPin_error")) {
                    var jsonData = { command: 5, pin: enterPin };
                    showWait();
                    setTimeout(function () {
                        postJSON("pin_puk_set", jsonData, function (data) {
                            if (data.result == "success") {
                                $("#divEnterPin input[type='password']").val("");
                                that.CheckCmdStatus();
                            } else {
                                showMsgBox(jQuery.i18n.prop("lt_EnablePin"), jQuery.i18n.prop("lFailedWithUnkown"));
                            }
                        });
                    }, 100);
                }
            });
        };
        this.DisablePinCode = function () {
            $("#btnDisablePin").unbind("click");
            $("#btnDisablePin").bind("click", function () {
                var disPin = $("#txtDisablePin").val();
                if (that.checkPin(disPin, "lt_disablePin_error")) {
                    var jsonData = { command: 2, pin: disPin };
                    showWait();
                    setTimeout(function () {
                        postJSON("pin_puk_set", jsonData, function (data) {
                            if (data.result == "success") {
                                $("#divDisablePin input[type='password']").val("");
                                that.CheckCmdStatus();
                            } else {
                                showMsgBox(jQuery.i18n.prop("lt_EnablePin"), jQuery.i18n.prop("lFailedWithUnkown"));
                            }
                        });
                    });
                }
            });
        };
        this.ChangePinCode = function () {
            $("#btnChangePin").unbind("click");
            $("#btnChangePin").bind("click", function () {
                var pin = $("#txtPIN").val(); //Enter Current PIN
                var pin1 = $("#txtchangePin1").val(); //Enter New PIN
                var pin2 = $("#txtchangePin2").val(); //Confirm New PIN
                if (that.checkChange(pin, pin1, pin2, "lt_changePin_error")) {
                    var jsonData = { command: 3, pin: pin, new_pin: pin1 };
                    showWait();
                    setTimeout(function () {
                        postJSON("pin_puk_set", jsonData, function (data) {
                            if (data.result == "success") {
                                $("#divChangePin input[type='password']").val("");
                                that.CheckCmdStatus();
                            } else {
                                showMsgBox(jQuery.i18n.prop("lt_EnablePin"), jQuery.i18n.prop("lFailedWithUnkown"));
                            }
                        });
                    });
                }
            });
        };
        this.EnterPukCode = function () {
            $("#btnEnterPuk").unbind("click");
            $("#btnEnterPuk").bind("click", function () {
                var puk = $("#txtEnterPuk").val();
                var pin1 = $("#txtEnterPukPin1").val();
                var pin2 = $("#txtEnterPukPin2").val();
                if (that.checkChange_puk(puk, pin1, pin2, "lt_enterPuk_error")) {
                    var jsonData = { command: 4, puk: puk, new_pin: pin1 };
                    showWait();
                    setTimeout(function () {
                        postJSON("pin_puk_set", jsonData, function (data) {
                            if (data.result == "success") {
                                $("#divEnterPuk input[type='password']").val("");
                                that.CheckCmdStatus(data);
                            } else {
                                showMsgBox(jQuery.i18n.prop("lt_EnablePin"), jQuery.i18n.prop("lFailedWithUnkown"));
                            }
                        });
                    });
                }
            });
        };
        this.CheckCmdStatus = function () {
            showWait();
            setTimeout(function () {
                callJSON("pin_puk_info", function (json) {
                    var cmdStatus = json.cmd_status;

                    if ("10" == cmdStatus) {
                        // incorrect password
                        if (parseInt(pin_attempts_gl) > 0) {
                            showMsgBox(jQuery.i18n.prop("lWarning"), jQuery.i18n.prop("lt_enterPin_error"));
                        } else {
                            showMsgBox(jQuery.i18n.prop("lWarning"), jQuery.i18n.prop("PukPinPasswordError"));
                        }
                    } else if ("13" == cmdStatus) {
                        //SIM CARD do not support this PIN code
                        showMsgBox(jQuery.i18n.prop("lWarning"), jQuery.i18n.prop("lSimNotSupportPinCode"));
                    } else if ("7" == cmdStatus) {
                        //SIM PUK request
                        showMsgBox(jQuery.i18n.prop("lWarning"), jQuery.i18n.prop("lSimPUKRequest"));
                    } else if ("6" == cmdStatus) {
                        showMsgBox(jQuery.i18n.prop("lWarning"), jQuery.i18n.prop("PukPinPasswordError"));
                    }
                    that.onLoad(false);
                });
            }, 100);
        };
        this.displayControls = function () {
            $("#spanEnablePin").html(jQuery.i18n.prop("lt_EnablePin"));
            $("#spanDisablePin").html(jQuery.i18n.prop("lt_DisablePin"));
            $("#spanChangePinCode").html(jQuery.i18n.prop("lt_ChangePin"));
            $("#spanEnterPukCode").html(jQuery.i18n.prop("lt_EnterPuk"));
            $("#lt_dashbd_PINStatus").html(jQuery.i18n.prop("lt_dashbd_PINStatus"));
            $("#lt_EnablePin").html(jQuery.i18n.prop("lt_Mep_PinCode"));
            $("#btnEnablePin").val(jQuery.i18n.prop("lt_EnablePin"));
            $("#lt_DisablePin").html(jQuery.i18n.prop("lt_Mep_PinCode"));
            $("#btnDisablePin").val(jQuery.i18n.prop("lt_DisablePin"));
            $("#lt_pin").html(jQuery.i18n.prop("lt_EnterPin"));
            $("#lt_Pin1").html(jQuery.i18n.prop("lt_EnterNewPin1"));
            $("#lt_Pin2").html(jQuery.i18n.prop("lt_EnterNewPin2"));
            $("#btnChangePin").val(jQuery.i18n.prop("lt_ChangePin"));
            $("#lt_Enterpuk").html(jQuery.i18n.prop("lt_EnterPuk"));
            $("#lt_EnterPukPin1").html(jQuery.i18n.prop("lt_EnterNewPin1"));
            $("#lt_EnterPukPin2").html(jQuery.i18n.prop("lt_EnterNewPin2"));
            $("#btnEnterPuk").val(jQuery.i18n.prop("lt_Mep_btnPukUnlock"));
            $("#spanEnterPinCode").html(jQuery.i18n.prop("spanEnterPin"));
            $("#lt_EnterPin").html(jQuery.i18n.prop("lt_Mep_PinCode"));
            $("#btnEnterPin").val(jQuery.i18n.prop("spanEnterPin"));
        };
        return this;
    };
})(jQuery);

// -------------------------------------------------------------objConnectionInfo-----------------------------------------------------------------
(function ($) {
    $.objConnectionInfo = function () {
        var that = this;
        var pdpList = [];
        this.onLoad = function (flag) {
            if (flag) {
                that.displayControls();
                showHelp();
            }
            that.btnEvent();
            that.showData();
            setDlgStyle();
        };
        this.btnEvent = function () {
            $("#sel_PdpInfo").change(function () {
                var pdp_name = $(this).val();
                for (var i = 0; i < pdpList.length; i++) {
                    var l = pdpList[i];
                    if (pdp_name == l.rulename) {
                        changePDP(l);
                        break;
                    }
                }
            });
        };
        this.showData = function () {
            pdpList = [];
            callJSON("wan_pdp_context_info", function (json) {
                pdpList = json.pdp_context_list;
                var pdpHtml = "";
                for (var i = 0; i < pdpList.length; i++) {
                    pdpHtml += "<option value='" + pdpList[i].rulename + "'>" + pdpList[i].rulename + "</option>";
                }
                $("#sel_PdpInfo").empty();
                $("#sel_PdpInfo").html(pdpHtml);
                var l = pdpList[0];
                changePDP(l);
            });
            callJSON("engineering_info", function (json) {
                $("#deviceInfo_eng_title").html("");

                if (json.sys_mode == "17" && Object.keys(json.lte).length > 1) {
                    $("#deviceInfo_eng_4g").show();
                    $("#deviceInfo_eng_3g").hide();
                    $("#deviceInfo_eng_title").html(jQuery.i18n.prop("4g_Engineer_title"));
                    $("#txt_mcc").html(json.lte.mcc);
                    $("#txt_tac").html(json.lte.tac);
                    $("#txt_phy_cell_id").html(json.lte.phyCellId);
                    $("#txt_dl_earfcn").html(json.lte.dlEuArfcn);
                    $("#txt_ul_earfcn").html(json.lte.ulEuArfcn);
                    $("#txt_dl_bandWidth").html(json.lte.band);
                    var ECGI = json.lte.ECGI;
                    $("#txt_cell_id").html(ECGI.substring(ECGI.length - 2));
                    var txt_rsrp = json.lte.rsrp;
                    var txt_rsrq = json.lte.rsrq;
                    var txt_rssi = json.lte.rssi;
                    txt_rsrp = parseInt(txt_rsrp) - 141;
                    txt_rsrq = -20 + txt_rsrq / 2;
                    txt_rssi = parseInt(txt_rssi) - 128;
                    $("#txt_rsrp").html(txt_rsrp + " dBm");
                    $("#txt_rsrq").html(txt_rsrq + " dB");
                    $("#txt_sinr").html(json.lte.sinr + " dB");
                    $("#txt_rssi").html(txt_rssi + " dBm");
                    $("#txt_dns_ecgi").html(ECGI);
                    $("#txt_dns_tx_power").html(json.lte.txPower);
                    if (parseInt(json.lte.lenOfMnc) > json.lte.mnc.length) {
                        var len = parseInt(json.lte.lenOfMnc) - json.lte.mnc.length;
                        var str = "";
                        while (len > 0) {
                            str += "0";
                            len--;
                        }
                        $("#txt_mnc").html(str + json.lte.mnc);
                    } else {
                        $("#txt_mnc").html(json.lte.mnc);
                    }
                } else if (json.sys_mode == "5" && Object.keys(json.umts).length > 1) {
                    $("#deviceInfo_eng_3g").show();
                    $("#deviceInfo_eng_4g").hide();
                    $("#deviceInfo_eng_title").html(jQuery.i18n.prop("3g_Engineer_title"));
                    if (json.umts.sCellParamPresent == "0") {
                        $("#txt_3g_rac").html("");
                        $("#txt_3g_nom").html("");
                        $("#txt_3g_mcc").html("");
                        $("#txt_3g_mnc").html("");
                        $("#txt_3g_lac").html("");
                        $("#txt_3g_ci").html("");
                        $("#txt_3g_uraId").html("");
                        $("#txt_3g_arfcn").html("");
                        $("#txt_3g_hsdpa").html("");
                        $("#txt_3g_hsupa").html("");
                    } else {
                        $("#txt_3g_rac").html(json.umts.rac);
                        $("#txt_3g_nom").html(json.umts.nom);
                        $("#txt_3g_mcc").html(json.umts.mcc);
                        $("#txt_3g_mnc").html(json.umts.mnc);
                        $("#txt_3g_lac").html(json.umts.lac);
                        $("#txt_3g_ci").html(json.umts.ci);
                        $("#txt_3g_uraId").html(json.umts.uraId);
                        $("#txt_3g_arfcn").html(json.umts.arfcn);
                        $("#txt_3g_hsdpa").html(json.umts.HSDPASupport);
                        $("#txt_3g_hsupa").html(json.umts.HSUPASupport);
                    }
                    if (json.umts.sCellMeasPresent == "0") {
                        $("#txt_3g_rscp").html("");
                        $("#txt_3g_rssi").html("");
                        $("#txt_3g_tx_power").html("");
                    } else {
                        $("#txt_3g_rscp").html(json.umts.rscp + " dBm");
                        var txt_3g_rssi = json.umts.utraRssi;
                        txt_3g_rssi = parseInt(txt_3g_rssi) - 111;
                        $("#txt_3g_rssi").html(txt_3g_rssi + " dBm");
                        $("#txt_3g_tx_power").html(json.umts.txPower);
                    }
                }
            });
        };
        this.displayControls = function () {
            $("#lt_deviceInfo_title").html(jQuery.i18n.prop("mConnectionInfo"));

            $("#lt_dashbd_PdpInfo").html(jQuery.i18n.prop("lt_dashbd_PdpInfo"));
            $("#lt_dashbd_PdpType").html(jQuery.i18n.prop("lt_dashbd_PdpType"));
            $("#lt_dashbd_PdpConnStatus").html(jQuery.i18n.prop("lt_dashbd_PdpConnStatus"));
            $("#lt_dashbd_PdpIpv4Addr").html(jQuery.i18n.prop("lt_dashbd_PdpIpv4Addr"));
            $("#lt_dashbd_PdpIpv4Dns1").html(jQuery.i18n.prop("lt_dashbd_PdpIpv4Dns1"));
            $("#lt_dashbd_PdpIpv4Dns2").html(jQuery.i18n.prop("lt_dashbd_PdpIpv4Dns2"));
            $("#lt_dashbd_PdpIpv4GateWay").html(jQuery.i18n.prop("lt_dashbd_PdpIpv4GateWay"));
            $("#lt_dashbd_PdpIpv4NetMask").html(jQuery.i18n.prop("lt_dashbd_PdpIpv4NetMask"));
            $("#lt_dashbd_PdpIpv6Addr").html(jQuery.i18n.prop("lt_dashbd_PdpIpv6Addr"));
            $("#lt_dashbd_PdpIpv6GlobalAddr").html(jQuery.i18n.prop("lt_dashbd_PdpIpv6GlobalAddr"));
            $("#lt_dashbd_PdpIpv6Dns1").html(jQuery.i18n.prop("lt_dashbd_PdpIpv6Dns1"));
            $("#lt_dashbd_PdpIpv6Dns2").html(jQuery.i18n.prop("lt_dashbd_PdpIpv6Dns2"));
            $("#lt_dashbd_PdpIpv6GateWay").html(jQuery.i18n.prop("lt_dashbd_PdpIpv6GateWay"));
            $("#lt_dashbd_PdpIpv6NetMask").html(jQuery.i18n.prop("lt_dashbd_PdpIpv6NetMask"));
            $("#lt_dashbd_curConnTime").html(jQuery.i18n.prop("lt_dashbd_curConnTime"));
            $("#lt_dashbd_totalConnTime").html(jQuery.i18n.prop("lt_dashbd_totalConnTime"));

            $("#deviceInfo_rsrp").html(jQuery.i18n.prop("deviceInfo_rsrp"));
            $("#deviceInfo_rsrq").html(jQuery.i18n.prop("deviceInfo_rsrq"));
            $("#deviceInfo_rssi").html(jQuery.i18n.prop("deviceInfo_rssi"));
            $("#deviceInfo_sinr").html(jQuery.i18n.prop("lt_dashbd_LTE_sinr"));
            $("#deviceInfo_mcc").html(jQuery.i18n.prop("lt_dashbd_LTE_mcc"));
            $("#deviceInfo_mnc").html(jQuery.i18n.prop("lt_dashbd_LTE_mnc"));
            $("#deviceInfo_tac").html(jQuery.i18n.prop("lt_dashbd_LTE_tac"));
            $("#deviceInfo_phy_cell_id").html(jQuery.i18n.prop("lt_dashbd_LTE_phy_cellid"));
            $("#deviceInfo_cell_id").html(jQuery.i18n.prop("lt_dashbd_LTE_cellid"));
            $("#deviceInfo_dl_earfcn").html(jQuery.i18n.prop("lt_dashbd_LTE_dl_euarfcn"));
            $("#deviceInfo_ul_earfcn").html(jQuery.i18n.prop("lt_dashbd_LTE_ul_euarfcn"));
            $("#deviceInfo_dl_bandWidth").html(jQuery.i18n.prop("lt_dashbd_LTE_dl_bandwidth"));
            $("#deviceInfo_dns_ecgi").html(jQuery.i18n.prop("deviceInfo_dns_ecgi"));
            $("#deviceInfo_dns_tx_power").html(jQuery.i18n.prop("deviceInfo_dns_tx_power"));

            $("#3g_rac").html(jQuery.i18n.prop("3g_rac"));
            $("#3g_nom").html(jQuery.i18n.prop("3g_nom"));
            $("#3g_mcc").html(jQuery.i18n.prop("3g_mcc"));
            $("#3g_mnc").html(jQuery.i18n.prop("3g_mnc"));
            $("#3g_lac").html(jQuery.i18n.prop("3g_lac"));
            $("#3g_ci").html(jQuery.i18n.prop("3g_ci"));
            $("#3g_uraId").html(jQuery.i18n.prop("3g_uraId"));
            $("#3g_arfcn").html(jQuery.i18n.prop("3g_arfcn"));
            $("#3g_rscp").html(jQuery.i18n.prop("3g_rscp"));
            $("#3g_rssi").html(jQuery.i18n.prop("3g_rssi"));
            $("#3g_tx_power").html(jQuery.i18n.prop("3g_tx_power"));
            $("#3g_hsdpa").html(jQuery.i18n.prop("3g_hsdpa"));
            $("#3g_hsupa").html(jQuery.i18n.prop("3g_hsupa"));
        };
        function changePDP(l) {
            var defaultPDP = l["default"];
            var secondaryPdp = l.secondary;
            var typeValue = "NA";
            if (defaultPDP == "1") {
                if (secondaryPdp == "0") typeValue = jQuery.i18n.prop("SPDPType_Default") + " " + jQuery.i18n.prop("SecondaryPDP");
                else typeValue = jQuery.i18n.prop("SPDPType_Default") + " " + jQuery.i18n.prop("PrimaryPDP");
            } else if (defaultPDP == "0") {
                if (secondaryPdp == "0") typeValue = jQuery.i18n.prop("SPDPType_Custom") + " " + jQuery.i18n.prop("SecondaryPDP");
                else typeValue = jQuery.i18n.prop("SPDPType_Custom") + " " + jQuery.i18n.prop("PrimaryPDP");
            }

            var sucess = l.success;
            var PdpConnStatus = "NA";
            if (sucess == "1") {
                PdpConnStatus = jQuery.i18n.prop("pdpConnStatus_connected");
            } else if (sucess == "0") {
                PdpConnStatus = jQuery.i18n.prop("pdpConnStatus_disconnected");
            } else if (sucess == "2") {
                PdpConnStatus = jQuery.i18n.prop("pdpConnStatus_connecting");
            }
            $("#sel_PdpInfo").val(l.rulename);
            $("#txt_PdpType").html(typeValue);
            $("#txt_PdpConnStatus").html(PdpConnStatus);
            $("#txt_PdpIpv4Addr").html(l.ipv4);
            $("#txt_PdpIpv4Dns1").html(l.v4dns1);
            $("#txt_PdpIpv4Dns2").html(l.v4dns2);
            $("#txt_PdpIpv4GateWay").html(l.v4gateway);
            $("#txt_PdpIpv4NetMask").html(l.v4netmask);
            $("#txt_PdpIpv6Addr").html(l.ipv6);
            $("#txt_PdpIpv6GlobalAddr").html(l.g_ipv6);
            $("#txt_PdpIpv6Dns1").html(l.v6dns1);
            $("#txt_PdpIpv6Dns2").html(l.v6dns2);
            $("#txt_PdpIpv6GateWay").html(l.v6gateway);
            $("#txt_PdpIpv6NetMask").html(l.v6netmask);
            var cct = formatSeconds(l.curconntime, jQuery.i18n.prop("ldDays"), jQuery.i18n.prop("ldHours"), jQuery.i18n.prop("ldMinutes"), jQuery.i18n.prop("ldSeconds"));
            $("#txt_curConnTime").html(cct);
            var tct = formatSeconds(l.totalconntime, jQuery.i18n.prop("ldDays"), jQuery.i18n.prop("ldHours"), jQuery.i18n.prop("ldMinutes"), jQuery.i18n.prop("ldSeconds"));
            $("#txt_totalConnTime").html(tct);
        }

        return this;
    };
})(jQuery);
// -------------------------------------------------------------objDHCP_Settings-----------------------------------------------------------------
var _arrayStaticIP = [];
var dhcp_Changeip3 = "1";
(function ($) {
    $.objDHCP_Settings = function () {
        var that = this;
        var c_rdRadio;
        var dhcpv6Server;
        var c_ipControl_start;
        var c_ipControl_end;
        var c_controlMapExisting = [];
        var c_controlMapCurrent = [];
        this.onLoad = function (flag) {
            if (flag) {
                that.displayControls();
                that.btnEvent();
                showHelp();
            }
            that.showData();
        };
        this.showData = function () {
            showWait();
            setTimeout(function () {
                callJSON("dhcp_info", function (data) {
                    closeWait();
                    var ip = data.ip;
                    var dhcpv6Server = data.dhcpv6server;
                    var redirectionFunction = data.redirect_enable;
                    var dnsEnable = data.dns_enable;
                    var status = data.status;
                    var start = data.start;
                    var end = data.end;
                    var leaseTime = data.lease_time;
                    var val = ip.split(".");

                    c_ipControl_start = start;
                    c_ipControl_end = end;
                    $("#textbox3").val(val[2]);
                    dhcp_Changeip3 = val[2];
                    $("#ipControl_starttext2").val(val[2]);
                    $("#ipControl_endtext2").val(val[2]);
                    $("#ip").html(ip);
                    $("#ipControl_starttext0").val(val[0]);
                    $("#ipControl_endtext0").val(val[0]);
                    $("#ipControl_starttext1").val(val[1]);
                    $("#ipControl_endtext1").val(val[1]);
                    $("#ipControl_starttext2").val(val[2]);
                    $("#ipControl_endtext2").val(val[2]);
                    var startval = start.split(".");
                    var endval = end.split(".");
                    $("#ipControl_starttext3").val(startval[3]);
                    $("#ipControl_endtext3").val(endval[3]);
                    $("#tbdhcplt").val(leaseTime);

                    $("#DNSEnableSwitchSel").val(dnsEnable);
                    $("#txtDirectionURL").val(data.redirect_url);
                    $("#txtDnsName1").val("0" == data.dns1 ? "" : data.dns1);
                    $("#txtDnsName2").val("0" == data.dns2 ? "" : data.dns2);
                    if (1 == redirectionFunction) {
                        $("#divEnabledDirectionUrl").show();
                        $("#RedirectionURLEnabled").attr("checked", true);
                    } else {
                        $("#divEnabledDirectionUrl").hide();
                        $("#RedirectionURLDisabled").attr("checked", true);
                    }
                    if ("0" == dhcpv6Server) {
                        $("#statelessServerRadio").attr("checked", true);
                        $("#statefullServerRadio").attr("checked", false);
                    } else {
                        $("#statefullServerRadio").attr("checked", true);
                        $("#statelessServerRadio").attr("checked", false);
                    }
                    if (status == "1") {
                        $("#rdRadioEnabled").attr("checked", true);
                    } else {
                        $("#rdRadioDisabled").attr("checked", true);
                    }
                    rbDHCPClicked();
                    DNSEnableSwitchChanged();

                    _arrayStaticIP = [];
                    for (var i = 0; i < data.Fixed_IP_list.length; i++) {
                        var IndexList = data.Fixed_IP_list[i];
                        _arrayStaticIP.push([i, IndexList.mac, IndexList.ip]);
                    }
                    that.loadTableData();
                });
            }, 100);
        };
        this.loadTableData = function () {
            var loadHTML = "";
            for (var i = 0; i < _arrayStaticIP.length; i++) {
                loadHTML += "<tr><td>" + _arrayStaticIP[i][1] + '</td><td class="td_delete">' + _arrayStaticIP[i][2] + '<span class="dhcp_deleteData" onclick="deleteStaticIPAdd(\'' + _arrayStaticIP[i][0] + "')\"></span></td></tr>";
            }
            $("#StaticIPAddListBody").html(loadHTML);
            setDlgStyle();
        };
        this.btnEvent = function () {
            $("#a_close_divStaticIP").unbind("click");
            $("#a_close_divStaticIP").bind("click", function () {
                $("#divStaticIPDlg").hide();
            });

            $("#a_cancel_divStaticIP").unbind("click");
            $("#a_cancel_divStaticIP").bind("click", function () {
                $("#divStaticIPDlg").hide();
            });

            $("#btnAddStaticIP").unbind("click");
            $("#btnAddStaticIP").bind("click", function () {
                if (document.getElementById("tableStaticIP").rows.length >= 17) {
                    showMsgBox(jQuery.i18n.prop("btnAddStaticIP"), jQuery.i18n.prop("MaxStaticIpError"));
                    return;
                }
                setAddBoxHeigth("divStaticIPDlg");
                $("#divStaticIPDlg").show();
                $("#lMacIpError").hide();
                document.getElementById("txtMac1").focus();
                $("#divStaticIPDlg input[type='text']").val("");
            });
            $("#ipControl_starttext3,#ipControl_endtext3,#tbdhcplt").focus(function () {
                $("#lIPErrorMsg").hide();
            });

            $("#btUpdate").unbind("click");
            $("#btUpdate").bind("click", function () {
                if (that.isvalid()) {
                    $("#lIPErrorMsg").hide();

                    var dns1, dns2, dns_enable, end, start, lease_time, redirect_enable, status, ip;
                    var changeIP = false;
                    var jsonData = {};
                    dns_enable = $("#DNSEnableSwitchSel").val();
                    status = $("#rdRadioEnabled").is(":checked") ? 1 : 0;
                    if (status == 1) {
                        start = $("#ipControl_starttext0").val() + "." + $("#ipControl_starttext1").val() + "." + $("#ipControl_starttext2").val() + "." + $("#ipControl_starttext3").val();
                        end = $("#ipControl_endtext0").val() + "." + $("#ipControl_endtext1").val() + "." + $("#ipControl_endtext2").val() + "." + $("#ipControl_endtext3").val();
                        lease_time = $("#tbdhcplt").val();
                        jsonData.status = "1";
                        if (dns_enable == "1") {
                            dns1 = $("#txtDnsName1").val();
                            dns2 = $("#txtDnsName2").val();
                            jsonData.dns_enable = "1";
                            jsonData.dns1 = dns1;
                            jsonData.dns2 = dns2;
                        } else {
                            jsonData.dns_enable = "0";
                        }
                        jsonData.start = start;
                        jsonData.end = end;
                        jsonData.lease_time = lease_time;

                        var dhcpv6serverFlag = $("#statelessServerRadio").is(":checked") ? "0" : "1";
                        if (dhcpv6serverFlag != dhcpv6Server) {
                            jsonData.dhcpv6server = dhcpv6serverFlag;
                        }
                        var t3 = c_ipControl_start.split(".");
                        ip = $("#ip").text();
                        if ($("#textbox3").val() != t3[2]) {
                            jsonData.ip = ip;
                            changeIP = true;
                        }

                        if ($("#RedirectionURLEnabled").is(":checked")) {
                            jsonData.redirect_url = $("#txtDirectionURL").val();
                            jsonData.redirect_enable = "1";
                        } else {
                            jsonData.redirect_enable = "0";
                        }
                    } else {
                        jsonData.status = "0";
                    }
                    if (changeIP && _arrayStaticIP.length > 0) {
                        showBOX2(
                            jQuery.i18n.prop("mDHCP_Settings"),
                            jQuery.i18n.prop("mDHCP_noticeMsg"),
                            jQuery.i18n.prop("lt_btnOK"),
                            jQuery.i18n.prop("lt_btnCancel"),
                            function () {
                                ClosemBOX2();
                                showWait();
                                setTimeout(function () {
                                    postJSON("lan_set", jsonData, function (data) {
                                        if (data.result == "success") {
                                            that.onLoad(false);
                                        } else {
                                            showMsgBox(jQuery.i18n.prop("mDHCP_Settings"), jQuery.i18n.prop("dialog_message_dhcp_set_fail"));
                                        }
                                    });
                                    if (changeIP) {
                                        setTimeout(function () {
                                            window.location.host = ip;
                                        }, 1000);
                                    }
                                }, 100);
                                return;
                            },
                            function () {
                                ClosemBOX2();
                                return;
                            }
                        );
                    } else {
                        showWait();
                        setTimeout(function () {
                            postJSON("lan_set", jsonData, function (data) {
                                if (data.result == "success") {
                                    that.onLoad(false);
                                } else {
                                    showMsgBox(jQuery.i18n.prop("mDHCP_Settings"), jQuery.i18n.prop("dialog_message_dhcp_set_fail"));
                                }
                            });
                            if (changeIP) {
                                setTimeout(function () {
                                    window.location.host = ip;
                                }, 1000);
                            }
                        }, 100);
                    }
                }
            });
        };
        this.isvalid = function () {
            $("#lIPErrorMsg").hide();
            var dhcpRange = "192.168." + $("#textbox3").val() + ".1";
            var txt3 = $("#textbox3").val();
            if (!IsNumber_1(txt3) || parseInt(txt3) > 255 || parseInt(txt3) < 0) {
                $("#lIPErrorMsg").show();
                $("#lIPErrorMsg").html(jQuery.i18n.prop("lIPErrorMsg"));
                return false;
            }
            if (dhcpRange == c_ipControl_start) {
                $("#lIPErrorMsg").show();
                $("#lIPErrorMsg").html(jQuery.i18n.prop("lDhcpStartAddrError"));
                return false;
            }
            var startIP = $("#ipControl_starttext3").val();
            var endIP = $("#ipControl_endtext3").val();
            if (!IsNumber(startIP) || !IsNumber(endIP)) {
                $("#lIPErrorMsg").show();
                $("#lIPErrorMsg").html(jQuery.i18n.prop("lIPErrorMsg"));
                return false;
            }
            if (parseInt(startIP) > 255 || parseInt(startIP) < 2 || parseInt(endIP) > 255 || parseInt(endIP) < 2) {
                $("#lIPErrorMsg").show();
                $("#lIPErrorMsg").html(jQuery.i18n.prop("lIPErrorMsg"));
                return false;
            }
            if (parseInt(startIP) >= parseInt(endIP)) {
                $("#lIPErrorMsg").show();
                $("#lIPErrorMsg").html(jQuery.i18n.prop("lDhcpAddrRangeError"));
                return false;
            }
            if (!IsNumber($("#tbdhcplt").val()) || $("#tbdhcplt").val() < 86400) {
                $("#lIPErrorMsg").show();
                $("#lIPErrorMsg").html(jQuery.i18n.prop("lErrorNumber2"));
                return false;
            }

            if ("1" == $("#DNSEnableSwitchSel").val()) {
                if ("" == $("#txtDnsName1").val() && "" != $("#txtDnsName2").val()) {
                    $("#lIPErrorMsg").show();
                    $("#lIPErrorMsg").html(jQuery.i18n.prop("lt_pDNScannotbenone"));
                    return false;
                }
                if (("" != $("#txtDnsName1").val() && !IsIPv4($("#txtDnsName1").val())) || ("" != $("#txtDnsName2").val() && !IsIPv4($("#txtDnsName2").val()))) {
                    $("#lIPErrorMsg").show();
                    $("#lIPErrorMsg").html(jQuery.i18n.prop("lDnsIpError"));
                    return false;
                }
            }
            if ($("#RedirectionURLEnabled").is(":checked")) {
                var validateMsg = that.ValidateUrlEntry();
                if ("ok" != validateMsg) {
                    $("#lIPErrorMsg").show().text(validateMsg);
                    return;
                }
            }
            return true;
        };
        this.ValidateUrlEntry = function () {
            var name = $("#txtDirectionURL").val();
            if (name == "") {
                return jQuery.i18n.prop("lt_DirectURLEmpty");
            }
            // if(!/^[0-9a-zA-Z\.\-\:]+$/.test(name)){
            // 	return jQuery.i18n.prop("lt_DomainNameError");
            // }
            if (!that.checkRemoteAdress(name)) {
                return jQuery.i18n.prop("lt_DirectURLError");
            }

            return "ok";
        };
        this.checkRemoteAdress = function (UrlName) {
            /* if(UrlName.indexOf("http://")!= 0  ){
						return false;
					} */

            var r = /.*[\u0100-\uffff]+.*$/;
            if (r.test(UrlName)) {
                return false;
            }
            var s = /\s+/;
            if (s.test(UrlName)) {
                return false;
            }
            /* var pattern = new RegExp("[`~!@#$^&*()=|{}':;',\\[\\]\"<>/?~£¡@#£¤¡­¡­&*£¨£©¡ª¡ª|{}¡¾¡¿¡®£»£º¡±¡°'¡££¬¡¢£¿]");
					if(pattern.test(UrlName)){
						 return false;
					} */
            var pattern = new RegExp("[`~!@#$^&*()=|{}';',\\[\\]\"<>?~£¡@#£¤¡­¡­&*£¨£©¡ª¡ª|{}¡¾¡¿¡®£»£º¡±¡°'¡££¬¡¢£¿]");
            if (pattern.test(UrlName)) {
                return false;
            }

            return true;
        };
        this.displayControls = function () {
            $("#title").html(jQuery.i18n.prop("mDHCP_Settings"));
            $("#lDhcpRange").html(jQuery.i18n.prop("lDhcpRange"));
            $("#lDevLanIP").html(jQuery.i18n.prop("lDevLanIP"));
            $("#lDhcpServer").html(jQuery.i18n.prop("lDhcpServer"));
            $("#radio_En").html(jQuery.i18n.prop("lEnabled"));
            $("#raido_Dis").html(jQuery.i18n.prop("lt_SmsSet_stcSendReportDisabled"));
            $("#lDhcpStartAdd").html(jQuery.i18n.prop("lDhcpStartAdd"));
            $("#lDhcpEndAdd").html(jQuery.i18n.prop("lDhcpEndAdd"));
            $("#ldhcplt").html(jQuery.i18n.prop("ldhcplt"));
            $("#sTimeUint").html(jQuery.i18n.prop("lMinutes"));
            $("#DNSEnableSwitchLabel").html(jQuery.i18n.prop("DNSEnableSwitchLabel"));
            $("#ClosedivDNSEnableSwitch").html(jQuery.i18n.prop("lt_optDisabledSwitch"));
            $("#OpendivDNSEnableSwitch").html(jQuery.i18n.prop("lt_optEnableSwitch"));
            $("#lDnsName1").html(jQuery.i18n.prop("lDnsName1"));
            $("#lDnsName2").html(jQuery.i18n.prop("lDnsName2"));
            $("#lt_dhcp_stcRedirectionFunction").html(jQuery.i18n.prop("lt_dhcp_stcRedirectionFunction"));
            $("#lt_dhcp_stcRedirectionURLEnabled").html(jQuery.i18n.prop("lt_optEnableSwitch"));
            // $("#lt_dhcp_stcRedirectionURLDisabled").html(jQuery.i18n.prop("lt_optDisabledSwitch"));
            $("#lt_dhcp_stcRedirectionURLDisabled").html(jQuery.i18n.prop("lt_SmsSet_stcSendReportDisabled"));
            $("#lt_dhcp_stRedirectionURL").html(jQuery.i18n.prop("lt_dhcp_stRedirectionURL"));
            $("#lt_dhcp_stRedirectionTip").html(jQuery.i18n.prop("lt_dhcp_stRedirectionTip"));
            $("#btnAddStaticIP").val(jQuery.i18n.prop("btnAddStaticIP"));
            $("#ltMacAddress").html(jQuery.i18n.prop("ltMacAddress"));
            $("#ltIPAddress").html(jQuery.i18n.prop("ltIPAddress"));
            $("#DHCPV6title").html(jQuery.i18n.prop("DHCPV6title"));
            $("#lDhcpV6Server").html(jQuery.i18n.prop("lDhcpV6Server"));
            $("#lstatelessServer").html(jQuery.i18n.prop("lstatelessServer"));
            $("#lstatefullServer").html(jQuery.i18n.prop("lstatefullServer"));
            $("#h1AddStaticIP").html(jQuery.i18n.prop("h1AddStaticIP"));
            $("#lStaticIP_MAC").html(jQuery.i18n.prop("lStaticIP_MAC"));
            $("#lStaticIP_IP").html(jQuery.i18n.prop("lStaticIP_IP"));
            $("#a_cancel_divStaticIP").html(jQuery.i18n.prop("lt_btnCancel"));
            $("#btnAdd_dhcp").val(jQuery.i18n.prop("btnAdd_dhcp"));
            $("#btUpdate").val(jQuery.i18n.prop("lt_btnSave"));
            $("#lt_help_dhcpSettings1").val(jQuery.i18n.prop("lt_help_dhcpSettings1"));
            $("#lt_help_dhcpSettings2").val(jQuery.i18n.prop("lt_help_dhcpSettings2"));
            $("#lt_help_dhcpSettings3").val(jQuery.i18n.prop("lt_help_dhcpSettings3"));
            $("#lt_help_dhcpSettings4").val(jQuery.i18n.prop("lt_help_dhcpSettings4"));
        };
        return this;
    };
})(jQuery);
function deleteStaticIPAdd(index) {
    var jsonData = { Fixed_IP_list: [{ delete: 1, mac: _arrayStaticIP[parseInt(index)][1] }] };
    showWait();
    setTimeout(function () {
        postJSON("lan_set", jsonData, function (data) {
            if (data.result == "success") {
                $.objDHCP_Settings().onLoad(false);
            } else {
                showMsgBox(jQuery.i18n.prop("lt_dhcp_title"), jQuery.i18n.prop("dialog_message_dhcp_delete_static_ip_fail"));
            }
        });
    }, 100);
}
function btnAddStaticIPSetting() {
    var mac, ip;
    mac = $("#txtMac1").val() + ":" + $("#txtMac2").val() + ":" + $("#txtMac3").val() + ":" + $("#txtMac4").val() + ":" + $("#txtMac5").val() + ":" + $("#txtMac6").val();
    ip = $("#txtSrcIPAddress1").val() + "." + $("#txtSrcIPAddress2").val() + "." + $("#txtSrcIPAddress3").val() + "." + $("#txtSrcIPAddress4").val();

    var bMacAddrValid = IsMACAddr(mac);
    var bIpAddrValid = validateIPAddress(ip);
    $("#lMacIpError").hide();
    if (":::::" == mac) {
        $("#lMacIpError").show();
        $("#lMacIpError").html(jQuery.i18n.prop("MAC_ADDR_IS_EMPTY"));
        return;
    }
    if ("..." == ip) {
        $("#lMacIpError").show();
        $("#lMacIpError").html(jQuery.i18n.prop("IP_ADDR_IS_EMPTY"));
        return;
    }
    var lanIpAddr = $("#ip").text();
    if (lanIpAddr.split(".")[0] != ip.split(".")[0] || lanIpAddr.split(".")[1] != ip.split(".")[1] || lanIpAddr.split(".")[2] != ip.split(".")[2] || lanIpAddr.split(".")[3] == ip.split(".")[3]) {
        $("#lMacIpError").show();
        var startIp3 = $("#ipControl_starttext3").val();
        var endIp3 = $("#ipControl_endtext3").val() == "255" ? "254" : $("#ipControl_endtext3").val();
        var addrRange = " " + lanIpAddr.split(".")[0] + "." + lanIpAddr.split(".")[1] + "." + lanIpAddr.split(".")[2] + "." + startIp3 + "- " + lanIpAddr.split(".")[0] + "." + lanIpAddr.split(".")[1] + "." + lanIpAddr.split(".")[2] + "." + endIp3;
        $("#lMacIpError").html(jQuery.i18n.prop("lStaticIpAddrError") + addrRange);
        return;
    }

    var start = parseInt($("#ipControl_starttext3").val());
    var end = parseInt($("#ipControl_endtext3").val());
    var ip_4 = parseInt($("#txtSrcIPAddress4").val());
    if (ip_4 < start || ip_4 > end || ip_4 == 255) {
        $("#lMacIpError").show();
        $("#lMacIpError").html(jQuery.i18n.prop("lStaticIpAddrRangeError"));
        return;
    }

    var bMacIpExist = false;
    for (var idx = 0; idx < _arrayStaticIP.length; ++idx) {
        if (mac == _arrayStaticIP[idx][1] || ip == _arrayStaticIP[idx][2]) {
            bMacIpExist = true;
            break;
        }
    }
    if (bMacIpExist) {
        $("#lMacIpError").show();
        $("#lMacIpError").html(jQuery.i18n.prop("lMacIpExist"));
        return;
    }
    if (bMacAddrValid && bIpAddrValid) {
        $("#divStaticIPDlg").hide();
        showWait();
        setTimeout(function () {
            var jsonData = { Fixed_IP_list: [{ index: 1, mac: mac, ip: ip }] };
            postJSON("lan_set", jsonData, function (data) {
                if (data.result == "success") {
                    $.objDHCP_Settings().onLoad(false);
                } else {
                    showMsgBox(jQuery.i18n.prop("h1AddStaticIP"), jQuery.i18n.prop("ls_save_time_failure"));
                }
            });
        }, 100);
    } else {
        $("#lMacIpError").show();
        if (!bMacAddrValid) {
            $("#lMacIpError").html(jQuery.i18n.prop("MAC_IS_NOT_VALID"));
        } else if (!bIpAddrValid) {
            $("#lMacIpError").html(jQuery.i18n.prop("IP_IS_NOT_VALID"));
        }
    }
}
function drpdwn_DHCP_rangeChanged() {
    var ip3 = $("#textbox3").val();
    if (ip3 == "") {
        return false;
    }
    /* if(!IsNumber(ip3) || (parseInt(ip3)>255 || parseInt(ip3)<0)){
	    $("#textbox3").val(dhcp_Changeip3);
	} */
    if (!IsNumber_1(ip3) || parseInt(ip3) > 255 || parseInt(ip3) < 0) {
        $("#textbox3").val(dhcp_Changeip3);
        var value = "192.168.";
        $("#textbox3").val(parseInt(dhcp_Changeip3));
        $("#ipControl_starttext2").val(parseInt(dhcp_Changeip3));
        $("#ipControl_endtext2").val(parseInt(dhcp_Changeip3));
        $("#ip").html(value + parseInt(dhcp_Changeip3) + ".1");
        return false;
    }
    var value = "192.168.";
    $("#textbox3").val(parseInt(ip3));
    $("#ipControl_starttext2").val(parseInt(ip3));
    $("#ipControl_endtext2").val(parseInt(ip3));
    $("#ip").html(value + parseInt(ip3) + ".1");
}
function startText_rangeChanged() {
    var ip3 = $("#ipControl_starttext3").val();
    if (ip3 == "") {
        return false;
    }
    // $("#ipControl_starttext3").val(parseInt(ip3));
    $("#ipControl_starttext3").val(ip3);
}
function endText_rangeChanged() {
    var ip3 = $("#ipControl_endtext3").val();
    if (ip3 == "") {
        return false;
    }
    // $("#ipControl_endtext3").val(parseInt(ip3));
    $("#ipControl_endtext3").val(ip3);
}
function dhcplt_rangeChanged() {
    var dhcplt = $("#tbdhcplt").val();
    if (dhcplt == "") {
        return false;
    }
    // $("#tbdhcplt").val(parseInt(dhcplt));
    $("#tbdhcplt").val(dhcplt);
}
function SrcIPAddress4_rangeChanged() {
    var txtSrcIPAddress4 = $("#txtSrcIPAddress4").val();
    if (txtSrcIPAddress4 == "") {
        return false;
    }
    //$("#txtSrcIPAddress4").val(parseInt(txtSrcIPAddress4));
    $("#txtSrcIPAddress4").val(txtSrcIPAddress4);
}
function DNSEnableSwitchChanged() {
    if (0 == $("#DNSEnableSwitchSel").val()) {
        $("#txtDnsName1").attr("readonly", true);
        $("#txtDnsName2").attr("readonly", true);
        $("#txtDnsName1").attr("disabled", true);
        $("#txtDnsName2").attr("disabled", true);
        $("#txtDnsName1").css("backgroundColor", "#ddd");
        $("#txtDnsName2").css("backgroundColor", "#ddd");
    } else {
        $("#txtDnsName1").attr("readonly", false);
        $("#txtDnsName2").attr("readonly", false);
        $("#txtDnsName1").attr("disabled", false);
        $("#txtDnsName2").attr("disabled", false);
        $("#txtDnsName1").css("backgroundColor", "#fff");
        $("#txtDnsName2").css("backgroundColor", "#fff");
    }
}
function rbDHCPClicked() {
    if ($("#rdRadioEnabled").is(":checked")) {
        $("#divEnabledDisabledContent").show();
        $("#textbox3").attr("disabled", false);
        $("#divStaticIpAddrList").show();
        $("#divDHCPV6").show();
    }
    if ($("#rdRadioDisabled").is(":checked")) {
        $("#divEnabledDisabledContent").hide();
        $("#textbox3").attr("disabled", true);
        $("#divStaticIpAddrList").hide();
        $("#divDHCPV6").hide();
    }
    setDlgStyle();
}
function RedirectionURLEnabled() {
    if ($("#RedirectionURLEnabled").is(":checked")) {
        $("#divEnabledDirectionUrl").show();
    } else {
        $("#divEnabledDirectionUrl").hide();
        $("#lIPErrorMsg").hide();
    }
}

// -------------------------------------------------------------objDataTraffic-----------------------------------------------------------------
var clientArr = [];
var connItemArr = [];
(function ($) {
    $.objDataTraffic = function () {
        var that = this;
        this.onLoad = function (flag, ifSim) {
            if (flag) {
                that.displayControls();
                that.btnEvent(ifSim);
            }
            that.showData();
            setDlgStyle();
        };
        this.showData = function () {
            callJSON("device_management_info", function (json) {
                var name, connTime, macAdd, status, action, ipadd;
                var uArr = json.client_list;
                var htmlText;
                action = "";
                clientArr = [];
                connItemArr = [];
                clientArr = json.client_list;
                connItemArr = json.client_list;
                for (var i = 0; i < uArr.length; i++) {
                    var uJSON = uArr[i];
                    name = UniDecode(uJSON.n);
                    macAdd = uJSON.m;
                    connTime = getTimeToS(parseInt(uJSON.tf));
                    status = uJSON.ct;
                    ipadd = uJSON.ip;
                    if (status != "USB") {
                        if (uJSON.s == "1") {
                            if (ipadd == "NA") {
                                action = '<input class="btn-apply" name="' + name + "*&*" + macAdd + '" value="' + jQuery.i18n.prop("lUnBlock") + '" style=" display:none;width:80px;padding:0 10px;"/>';
                            } else {
                                action = '<input class="btn-apply" name="' + name + "*&*" + macAdd + '" value="' + jQuery.i18n.prop("lBlock") + '" style="width:80px;padding:0 10px;"  type="button" onclick="setBlockStatus(this)" />';
                            }
                        } else if (uJSON.s == "0") {
                            if (ipadd == "NA") {
                                action = '<input class="btn-apply" name="' + name + "*&*" + macAdd + '" value="' + jQuery.i18n.prop("lUnBlock") + '" style=" display:none;width:80px;padding:0 10px;"/>';
                            } else {
                                action = '<input class="btn-apply" name="' + name + "*&*" + macAdd + '" value="' + jQuery.i18n.prop("lBlock") + '" style="width:80px;padding:0 10px;"  type="button" onclick="setBlockStatus(this)" />';
                            }
                        } else if (uJSON.s == "2") {
                            action = '<input class="btn-apply" name="' + name + "*&*" + macAdd + '" value="' + jQuery.i18n.prop("lUnBlock") + '" style="width:80px;padding:0 10px;"   type="button" onclick="SetUnblockStatus(this)" />';
                        } else {
                            action = jQuery.i18n.prop("lUnkownStatus");
                        }
                    } else {
                        action = "";
                    }
                    // htmlText += '<tr><td><span  name="' + name + "*&*" + macAdd + '" >' + name + "</span></td><td>" + macAdd + "</td><td>" + ipadd + "</td><td>" + connTime + "</td><td>" + status + "</td><td>" + action + "</td></tr>";
                    if (uJSON.s == 1) {
                        htmlText += '<tr><td><span  name="' + name + "*&*" + macAdd + '" >' + name + "</span></td><td>" + '<img src="images/status-icon3.png">' + "</td><td>" + macAdd + "</td><td>" + ipadd + "</td><td>" + connTime + "</td><td>" + status + "</td><td>" + action + "</td></tr>";
                    } else {
                        htmlText += '<tr><td><span  name="' + name + "*&*" + macAdd + '" >' + name + "</span></td><td>" + '<img src="images/status-icon2.png">' + "</td><td>" + macAdd + "</td><td>" + ipadd + "</td><td>" + connTime + "</td><td>" + status + "</td><td>" + action + "</td></tr>";
                    }
                }
                $("#DeviceInfoBody").html(htmlText);
            });
        };
        this.btnEvent = function (ifSim) {
            $("#a_close_DeviceInfo").unbind("click");
            $("#a_close_DeviceInfo").bind("click", function () {
                $("#divDeviceInfoDlg").hide();
            });
            $("#lBtnOk").unbind("click");
            $("#lBtnOk").bind("click", function () {
                $("#divDeviceInfoDlg").hide();
            });
            $("#lBtnResetDevices").unbind("click");
            $("#lBtnResetDevices").bind("click", function () {
                var jsonData = { action: "4" };
                showWait();
                setTimeout(function () {
                    postJSON("device_management_set", jsonData, function (data) {
                        if (data.result == "success") {
                            // showMsgBox(jQuery.i18n.prop("lBtnResetDevices"),jQuery.i18n.prop("dialog_message_connectdevice_traffic_reset_clients_traffic_success"));
                            that.onLoad(false);
                        } else {
                            showMsgBox(jQuery.i18n.prop("lBtnResetDevices"), jQuery.i18n.prop("dialog_message_connectdevice_traffic_reset_clients_traffic_fail"));
                        }
                    });
                }, 100);
            });
            $("#backMenu").unbind("click");
            $("#backMenu").bind("click", function () {
                if (ifSim == "nosim") {
                    displaySubMenu(0);
                    //displaySubMenu(0,undefined,"nosim");
                } else if (ifSim == "simLock") {
                    displaySubMenu(0);
                    //displaySubMenu(0,undefined,"simLock");
                } else {
                    displaySubMenu(0);
                }
            });
        };
        this.displayControls = function () {
            $("#ltitle").html(jQuery.i18n.prop("lt_connected_wlan_clients"));
            $("#lIpAddr1").html(jQuery.i18n.prop("lIpAddr"));
            $("#lBtnOk").val(jQuery.i18n.prop("lt_btnOK"));
            $("#lBtnResetDevices").val(jQuery.i18n.prop("lBtnResetDevices"));
            $("#lClientName").html(jQuery.i18n.prop("lClientName"));
            $("#lMacAddr").html(jQuery.i18n.prop("lMacAddress"));
            $("#lt_Time").html(jQuery.i18n.prop("lt_Time"));
            $("#lt_Connection").html(jQuery.i18n.prop("lt_Connection"));
            $("#lAction").html(jQuery.i18n.prop("lAction"));
            $("#lDeviceInfoBoxTitle").html(jQuery.i18n.prop("lDeviceInfoBoxTitle"));
            $("#lDeviceName").html(jQuery.i18n.prop("lDeviceName"));
            $("#lNameType").html(jQuery.i18n.prop("lNameType"));
            $("#lDeviceStatus").html(jQuery.i18n.prop("lDeviceStatus"));
            $("#lConnType").html(jQuery.i18n.prop("lConnType"));
            $("#lIpAddr").html(jQuery.i18n.prop("lIpAddr"));
            $("#lMacAddress").html(jQuery.i18n.prop("lMacAddress"));
            $("#lLastConTime").html(jQuery.i18n.prop("lLastConTime"));
            $("#lTotalConTime").html(jQuery.i18n.prop("lTotalConTime"));
            $("#lMonthSendData").html(jQuery.i18n.prop("lMonthSendData"));
            $("#lMonthRecvData").html(jQuery.i18n.prop("lMonthRecvData"));
            $("#lMonthTotalData").html(jQuery.i18n.prop("lMonthTotalData"));
            $("#lLast3DaySendData").html(jQuery.i18n.prop("lLast3DaySendData"));
            $("#lLast3DayRecvData").html(jQuery.i18n.prop("lLast3DayRecvData"));
            $("#lLast3DayTotalData").html(jQuery.i18n.prop("lLast3DayTotalData"));
            $("#lTotalSendData").html(jQuery.i18n.prop("lTotalSendData"));
            $("#lTotalRecvData").html(jQuery.i18n.prop("lTotalRecvData"));
            $("#lTotalData").html(jQuery.i18n.prop("lTotalData"));
            $("#lt_content_titleh1").html(jQuery.i18n.prop("lt_dashbd_h3ConnDevice"));
            $("#lt_content_titleP").html(jQuery.i18n.prop("lt_content_titleP"));
            $("#lt_DeviceStatus").html(jQuery.i18n.prop("lt_DeviceStatus"));
        };
        return this;
    };
})(jQuery);
function SetUnblockStatus(input) {
    var indexName = $(input).attr("name");
    var indexArr = indexName.split("*&*");
    var name = indexArr[0];
    var macAdd = indexArr[1];
    var jsonData = { action: "3", mac: macAdd };
    showWait();
    setTimeout(function () {
        postJSON("device_management_set", jsonData, function (data) {
            if (data.result == "success") {
                $.objDataTraffic().onLoad(false);
            } else {
                showMsgBox(jQuery.i18n.prop("lUnBlock"), jQuery.i18n.prop("dialog_message_connectdevice_traffic_set_unblock_fail"));
            }
        });
    }, 100);
}
function SetStopStatus(input) {
    var indexName = $(input).attr("name");
    var indexArr = indexName.split("*&*");
    var name = indexArr[0];
    var macAdd = indexArr[1];
    var jsonData = { action: "1", mac: macAdd };
    showWait();
    setTimeout(function () {
        postJSON("device_management_set", jsonData, function (data) {
            if (data.result == "success") {
                $.objDataTraffic().onLoad(false);
            } else {
                showMsgBox(jQuery.i18n.prop("lStop"), jQuery.i18n.prop("dialog_message_connectdevice_traffic_set_block_fail"));
            }
        });
    }, 100);
}
function setBlockStatus(input) {
    var indexName = $(input).attr("name");
    var indexArr = indexName.split("*&*");
    var name = indexArr[0];
    var macAdd = indexArr[1];
    var jsonData = { action: "2", mac: macAdd };
    setTimeout(function () {
        postJSON("device_management_set", jsonData, function (data) {
            if (data.result == "success") {
                $.objDataTraffic().onLoad(false);
            } else {
                showMsgBox(jQuery.i18n.prop("lBlock"), jQuery.i18n.prop("dialog_message_connectdevice_traffic_set_block_fail"));
            }
        });
    }, 100);
}
function showConntedDeviceList(span) {
    var indexName = $(span).attr("name");
    var indexArr = indexName.split("*&*");
    var name = indexArr[0];
    var macAdd = indexArr[1];
    for (var i = 0; i < clientArr.length; i++) {
        var cJSON = clientArr[i];
        if (name == UniDecode(cJSON.n) && macAdd == cJSON.m) {
            $("#txtDeviceName").html(UniDecode(cJSON.n));
            if (cJSON.nt == "1") {
                $("#deviceNameAssignedSel").html(jQuery.i18n.prop("lNameTypeAssigned"));
            } else {
                $("#deviceNameAssignedSel").html(jQuery.i18n.prop("lNameTypeNotAssigned"));
            }
            if (cJSON.s == "0") {
                $("#deviceStatusSel").html(jQuery.i18n.prop("DisconnectedStatus"));
            } else if (cJSON.s == "1") {
                $("#deviceStatusSel").html(jQuery.i18n.prop("ConnectedStatus"));
            } else if (cJSON.s == "2") {
                $("#deviceStatusSel").html(jQuery.i18n.prop("BlockStatus"));
            }
            $("#ConnTypeSel").html(cJSON.ct);
            $("#txtIpAddr").html(cJSON.ip);
            $("#txtMacAddr").html(cJSON.m);
            $("#txtLastConTime").html(cJSON.ta);
            $("#txtTotalConTime").html(getTimeToS(parseInt(cJSON.tf)));
            $("#txtMonthSendData").html(FormatDataTrafficMinUnitKB(parseInt(cJSON.txm)));
            $("#txtMonthRecvData").html(FormatDataTrafficMinUnitKB(parseInt(cJSON.rxm)));
            $("#txtMonthTotalData").html(FormatDataTrafficMinUnitKB(parseInt(cJSON.rxm) + parseInt(cJSON.txm)));
            $("#txtLast3DaySendData").html(FormatDataTrafficMinUnitKB(parseInt(cJSON.tx3)));
            $("#txtLast3DayRecvData").html(FormatDataTrafficMinUnitKB(parseInt(cJSON.rx3)));
            $("#txtLast3DayTotalData").html(FormatDataTrafficMinUnitKB(parseInt(cJSON.rx3) + parseInt(cJSON.tx3)));
            $("#txtTotalSendData").html(FormatDataTrafficMinUnitKB(parseInt(cJSON.tx)));
            $("#txtTotalRecvData").html(FormatDataTrafficMinUnitKB(parseInt(cJSON.rx)));
            $("#txtTotalData").html(FormatDataTrafficMinUnitKB(parseInt(cJSON.tx) + parseInt(cJSON.rx)));
        }
    }
    setAddBoxHeigth("divDeviceInfoDlg");
    $("#divDeviceInfoDlg").show();
}

// -------------------------------------------------------------objTrafficStatistical-----------------------------------------------------------------
var TstaticsTipOne = false;
var TstaticsTip = false;
(function ($) {
    $.objTrafficStatistical = function () {
        var that = this;
        this.onLoad = function (flag) {
            if (flag) {
                that.displayControls();
                that.clearData();
                showHelp();
            }
            that.showData();
            setDlgStyle();
        };
        this.showData = function () {
            callJSON("statistics_info", function (json) {
                var f_rx_data = parseInt(json.rx_byte_all);
                var f_tx_data = parseInt(json.tx_byte_all);
                var p_rx_data = parseInt(json.rx_byte);
                var p_tx_data = parseInt(json.tx_byte);

                $("#txtRxByteFromPower").html(FormatDataTrafficMinUnitKB(p_rx_data));
                $("#txtTxByteFromPower").html(FormatDataTrafficMinUnitKB(p_tx_data));
                $("#txtRxTxByteFromPower").html(FormatDataTrafficMinUnitKB(p_rx_data + p_tx_data));
                $("#txtRxByteFromRestoreFactory").html(FormatDataTrafficMinUnitKB(f_rx_data));
                $("#txtTxByteFromRestoreFactory").html(FormatDataTrafficMinUnitKB(f_tx_data));
                $("#txtRxTxByteFromRestoreFactory").html(FormatDataTrafficMinUnitKB(f_rx_data + f_tx_data));
            });
        };
        this.clearData = function () {
            $("#lt_commTraffic_btnClearData").unbind("click");
            $("#lt_commTraffic_btnClearData").bind("click", function () {
                var jsonData = { reset: "1" };
                showWait();
                setTimeout(function () {
                    postJSON("statistics_set", jsonData, function (data) {
                        if (data.result == "success") {
                            showMsgBox(jQuery.i18n.prop("lt_commTraffic_btnClearData"), jQuery.i18n.prop("dialog_message_traffic_statistic_clear_monitor_data_success"));
                            that.onLoad(false);
                        } else {
                            showMsgBox(jQuery.i18n.prop("lt_commTraffic_btnClearData"), jQuery.i18n.prop("dialog_message_traffic_statistic_clear_monitor_data_fail"));
                        }
                    });
                }, 100);
            });
        };
        this.displayControls = function () {
            $("#lt_commTraffic_StaticFromPowerOn").html(jQuery.i18n.prop("lt_commTraffic_StaticFromPowerOn"));
            $("#lt_commTraffic_TitleFromPowerOn").html(jQuery.i18n.prop("lt_commTraffic_TitleFromPowerOn"));
            $("#lt_commTraffic_RxByte").html(jQuery.i18n.prop("lt_commTraffic_RxByte"));
            $("#lt_notice_dataManage").html(jQuery.i18n.prop("lt_notice_dataManage"));
            $("#lt_portTrigger_TxByte").html(jQuery.i18n.prop("lt_portTrigger_TxByte"));
            $("#lt_portTrigger_RxTxByte").html(jQuery.i18n.prop("lt_portTrigger_RxTxByte"));
            $("#ltFromRestore_commTraffic_RxByte").html(jQuery.i18n.prop("lt_commTraffic_RxByte"));
            $("#ltFromRestore_portTrigger_TxByte").html(jQuery.i18n.prop("lt_portTrigger_TxByte"));
            $("#ltFromRestore_portTrigger_RxTxByte").html(jQuery.i18n.prop("lt_portTrigger_RxTxByte"));
            $("#lt_commTraffic_btnClearData").val(jQuery.i18n.prop("lt_commTraffic_btnClearData"));
            $("#lt_commTraffic_TitleFromRestoreFactory").html(jQuery.i18n.prop("lt_commTraffic_TitleFromRestoreFactory"));
            $("#lt_commTraffic_StaticFromRestoreFactory").html(jQuery.i18n.prop("lt_commTraffic_StaticFromRestoreFactory"));
        };
        return this;
    };
})(jQuery);

// -------------------------------------------------------------objPhoneBook-----------------------------------------------------------------
(function ($) {
    $.objPhoneBook = function () {
        var that = this;
        var PHONE_NUM_PER_PAGE = 10;
        var countNum = 1;
        var maxNum = 100;
        var delCount = 0;
        var pageCount = 10;
        var pageTotal = 1;
        var pageIndex = 1;
        var isAllChecked = false;
        var usedDevNum;
        var maxDevNum;
        this.onLoad = function (flag) {
            if (flag) {
                that.displayControls();
                that.addPhoneBook();
                that.deleteSimPhoneBook();
                that.sendMessage();
                // that.copyMove();
                that.btnEvent();
                $("#phoneInfoDlg input[type='text']").focus(function () {
                    $("#phoneInfoDlg .error").hide();
                });
            }
            that.showData();
            setDlgStyle();
        };
        this.showData = function () {
            var deviceNum, SimNum;
            callJSON("pb_capacity_info", function (json) {
                usedDevNum = json.pb_dev_used_record_num;
                maxDevNum = json.pb_dev_max_record_num;
                deviceNum = jQuery.i18n.prop("mLocationContact") + "(" + json.pb_dev_used_record_num + "/" + json.pb_dev_max_record_num + ")";
                SimNum = "  " + jQuery.i18n.prop("mSimPhoneBook") + "(" + json.pb_sim_used_record_num + "/" + json.pb_sim_max_record_num + ")";
                if (json.pb_sim_max_record_num == "0") {
                    SimNum = "  " + jQuery.i18n.prop("lUnknownNoSIM");
                }
                $("#lt_phonebook_DeviceSimNum").html(deviceNum + SimNum);
            });
            this.UpdatePhoneBookList(1, true);
        };
        this.btnEvent = function () {
            $("#selSaveLoc").unbind("change");
            $("#selSaveLoc").bind("change", function () {
                if ($("#selSaveLoc").val() == "0") {
                    $("#divDeviceSupport").hide();
                } else {
                    $("#divDeviceSupport").show();
                }
                setDlgStyle();
            });

            $("#lt_Phonebook_btnNew").unbind("click");
            $("#lt_Phonebook_btnNew").bind("click", function () {
                var pbGroup;
                switch (SubMenuId) {
                    case "mAllContact":
                        pbGroup = "all";
                        break;
                    case "mLoactionCommon":
                        pbGroup = "common";
                        break;
                    case "mLoactionFamliy":
                        pbGroup = "family";
                        break;
                    case "mLoactionFriends":
                        pbGroup = "friend";
                        break;
                    case "mLoactionColleague":
                        pbGroup = "colleague";
                        break;
                }
                if ("mLoactionCommon" == SubMenuId || "mAllContact" == SubMenuId) {
                    $("#selSaveLoc").val("0");
                    // $("#selSaveLoc").attr("disabled", true);
                    // $("#selSaveLoc").css("backgroundColor","#ddd");
                    $("#divDeviceSupport").hide();
                    $("#selGroup").val("common");
                } else {
                    $("#selSaveLoc").val("1");
                    // $("#selSaveLoc").attr("disabled", false);
                    // $("#selSaveLoc").css("backgroundColor","#fff");
                    $("#divDeviceSupport").show();
                    $("#selGroup").val(pbGroup);
                }
                $("#lt_SimPhoneBook_btnUpdate").hide();
                $("#lt_SimPhoneBook_btnAdd").show();
                $("input[type='text']").val("");
                $("#lSimPhoneBookError").hide();
                $("#phoneInfoDlg").show();
                $("#selSaveLoc").attr("disabled", false);
                $("#selSaveLoc").css("backgroundColor", "#fff");
                setDlgStyle();
                setAddBoxHeigth("phoneInfoDlg");
            });

            $("#lt_SimPhoneBook_btnUpdate").unbind("click");
            $("#lt_SimPhoneBook_btnUpdate").bind("click", function () {
                if (that.checkInput()) {
                    var stcName = UniEncode($("#txt_Phonebook_stcName").val());
                    var stcNum = $("#txt_Phonebook_stcNum").val();
                    var selLoc = $("#selSaveLoc").val();
                    var selGroup = $("#selGroup").val();
                    var email = UniEncode($("#txtEmail").val());
                    var homePhone = $("#txtHomePhone").val();
                    var officePhone = $("#txtOfficePhone").val();

                    var jsonData = {};
                    jsonData.pb_action = "pbm_contact_edit";
                    jsonData.pb_edit_id = $("#lt_SimPhoneBook_btnUpdate").attr("name");
                    jsonData.location = selLoc;
                    jsonData.name = stcName;
                    jsonData.mobile = stcNum;
                    if (selLoc == "1") {
                        jsonData.homenum = homePhone;
                        jsonData.officephone = officePhone;
                        jsonData.email = email;
                        jsonData.group = selGroup;
                    }
                    showWait();
                    setTimeout(function () {
                        postJSON("pb_set", jsonData, function (data) {
                            if (0 == data.pb_result || "0" == data.pb_result) {
                                showMsgBox(jQuery.i18n.prop("dialog_message_phonebook_title"), jQuery.i18n.prop("dialog_message_phonebook_save_contact_success"));
                                $("#phoneInfoDlg").hide();
                                that.onLoad(false);
                            } else {
                                showMsgBox(jQuery.i18n.prop("dialog_message_phonebook_title"), jQuery.i18n.prop("dialog_message_phonebook_save_contact_fail"));
                            }
                        });
                    }, 100);
                }
            });

            $("#addPhoneBookBoxclose").unbind("click");
            $("#addPhoneBookBoxclose").bind("click", function () {
                $("#phoneInfoDlg").hide();
            });

            $("#lt_SimPhoneBook_btnCancel").unbind("click");
            $("#lt_SimPhoneBook_btnCancel").bind("click", function () {
                $("#phoneInfoDlg").hide();
            });

            $("#lt_copyMove_btnCancel").unbind("click");
            $("#lt_copyMove_btnCancel").bind("click", function () {
                $("#copyMoveDlg").hide();
            });
            $("#copyMoveBoxclose").unbind("click");
            $("#copyMoveBoxclose").bind("click", function () {
                $("#copyMoveDlg").hide();
            });

            $("#lt_sendMessage_btnCancel").unbind("click");
            $("#lt_sendMessage_btnCancel").bind("click", function () {
                $("#sendMessageDlg").hide();
            });
            $("#sendMessageBoxclose").unbind("click");
            $("#sendMessageBoxclose").bind("click", function () {
                $("#sendMessageDlg").hide();
            });

            var bind_name = "input";
            if (navigator.userAgent.indexOf("MSIE") != -1) {
                bind_name = "propertychange";
            }
            $("#txtSmsContentInPhoneBook").unbind(bind_name);
            $("#txtSmsContentInPhoneBook").bind(bind_name, function () {
                $("#lt_phonebook_stcSmsErrorInfo").hide();
                var messageBody = $("#txtSmsContentInPhoneBook").val();
                var patrn = /[\u4E00-\u9FA5]|[\uFE30-\uFFA0]/gi;

                var msgLen = messageBody.length;
                var charCount, itemCount;
                if (!IsGSM7Code(messageBody)) {
                    if (msgLen > 335) {
                        $("#lt_phonebook_stcSmsErrorInfo").text(jQuery.i18n.prop("lt_sms_stcSmsLenghtError"));
                        $("#lt_phonebook_stcSmsErrorInfo").show();
                        $("#txtSmsContentInPhoneBook").val(messageBody.substr(0, 335));
                        msgLen = 335;
                    }
                    charCount = "(" + msgLen + "/335)";
                    if (msgLen <= 70) {
                        itemCount = 1;
                    } else {
                        itemCount = Math.floor(msgLen / 67 + (msgLen % 67 > 0 ? 1 : 0));
                    }
                } else {
                    //english
                    if (msgLen > 765) {
                        $("#lt_phonebook_stcSmsErrorInfo").text(jQuery.i18n.prop("lt_sms_stcSmsLenghtError"));
                        $("#lt_phonebook_stcSmsErrorInfo").show();
                        $("#txtSmsContentInPhoneBook").val(messageBody.substr(0, 765));
                        msgLen = 765;
                    }
                    var specString = "^{}\\[]~|";
                    for (var idx = 0; idx < messageBody.length; ++idx) {
                        if (-1 != specString.indexOf(messageBody[idx])) {
                            ++msgLen;
                        }
                    }
                    if (msgLen <= 160) {
                        itemCount = 1;
                    } else {
                        if (-1 != specString.indexOf(messageBody[152])) {
                            ++msgLen;
                        }
                        itemCount = Math.floor(msgLen / 153 + (msgLen % 153 > 0 ? 1 : 0));
                    }
                    charCount = "(" + msgLen + "/765)";
                }
                $("#inputcountInPhoneBook").text(charCount);
                $("#inputItemCountInPhoneBook").text("(" + itemCount + "/5)");
            });
        };
        this.UpdatePhoneBookList = function (pageNumber, bInitFlag) {
            var pbGroup;
            switch (SubMenuId) {
                case "mAllContact":
                    pbGroup = "all";
                    break;
                case "mLoactionCommon":
                    pbGroup = "common";
                    break;
                case "mLoactionFamliy":
                    pbGroup = "family";
                    break;
                case "mLoactionFriends":
                    pbGroup = "friend";
                    break;
                case "mLoactionColleague":
                    pbGroup = "colleague";
                    break;
                default:
            }

            var jsonData = {};
            if ("mAllContact" == SubMenuId) {
                jsonData.pb_action = "pb_get_all";
            } else {
                jsonData.pb_action = "pb_get_by_gr";
                jsonData.pb_gr = pbGroup;
            }
            jsonData.location = "2";
            jsonData.page_num = "" + pageNumber;
            jsonData.data_per_page = "" + PHONE_NUM_PER_PAGE;
            postJSON("pb_set", jsonData, function (json) {
                var showHTML = "";
                var strGroup, locImage;
                for (var i = 0; i < json.pb_entries.length; i++) {
                    var l = json.pb_entries[i];
                    var pbmId = l.pbm_id;
                    var pbmLocation = l.pbm_location;
                    var pbmName = UniDecode(l.pbm_name);
                    var pbmNumber = l.pbm_number;
                    var pbmHomeNum = l.pbm_anr;
                    var pbmOfficeNum = l.pbm_anr1;
                    var pbmEmail = l.pbm_email;
                    var pbmNickName = l.pbm_sne;
                    var pbmGroup = l.pbm_group;
                    if ("NONE" == pbmHomeNum) {
                        pbmHomeNum = "";
                    }
                    if ("NONE" == pbmOfficeNum) {
                        pbmOfficeNum = "";
                    }
                    if ("NONE" == pbmEmail) pbmEmail = "";
                    else pbmEmail = UniDecode(l.pbm_email);
                    if ("NONE" == pbmNickName) pbmNickName = "";
                    else pbmNickName = UniDecode(l.pbm_sne);

                    if (1 == pbmLocation) {
                        locImage = "images/device.png";
                    } else {
                        locImage = "images/sim.png";
                    }
                    if ("friend" == pbmGroup) strGroup = jQuery.i18n.prop("mLoactionFriends");
                    else if ("family" == pbmGroup) strGroup = jQuery.i18n.prop("mLoactionFamliy");
                    else if ("common" == pbmGroup) strGroup = jQuery.i18n.prop("mLoactionCommon");
                    else if ("colleague" == pbmGroup) strGroup = jQuery.i18n.prop("mLoactionColleague");
                    var attrName = pbmId + "*&*" + pbmLocation + "*&*" + pbmName + "*&*" + pbmNumber + "*&*" + pbmHomeNum + "*&*" + pbmOfficeNum + "*&*" + pbmEmail + "*&*" + pbmGroup;

                    showHTML += '<tr><td name="' + attrName + '" onclick="showPhoneBookIndex(this)" sytle="cursor:pointer;">' + pbmName + '</td><td style="cursor:pointer;" onclick="phoneBookSendSms(this)" name="' + attrName + '">' + pbmNumber + "</td><td>" + strGroup + '</td><td><img src="' + locImage + '" /></td><td><input class="SimPhoneBook_del" name="' + pbmId + '" type="checkbox"/></td></tr>';
                }
                if (showHTML == "") {
                    showHTML = '<tr><td colspan="5">' + jQuery.i18n.prop("lPBRetNoConactErr") + "</td></tr>";
                    $("#tablePhoneBookBody").html(showHTML);
                    $("#deleteAllPhone").prop("disabled", true);
                } else {
                    $("#tablePhoneBookBody").html(showHTML);
                    $("#deleteAllPhone").prop("disabled", false);
                    that.showDeleteBtn();
                }
                if (bInitFlag) {
                    pageTotal = Math.ceil(parseInt(json.gr_num) / 10);
                    that.showPhoneBookPageNum();
                }
            });
        };
        this.showPhoneBookPageNum = function () {
            if (pageTotal <= 1) {
                $("#divPhoneBookPageNum").hide();
                return;
            }
            $("#divPhoneBookPageNum").show();
            var htmlTxt = "";
            for (var i = 1; i <= pageTotal; i++) {
                htmlTxt += '<a style="color: #555; font-weight: 700;text-decoration:none; margin:5px 3px;cursor:pointer;" name="' + i + '" href="##">' + i + "</a>";
            }
            $("#divPhoneBookPageNum").html(htmlTxt);
            $("#divPhoneBookPageNum a:first").css("color", "#05bda1");

            $("#divPhoneBookPageNum a").unbind("click");
            $("#divPhoneBookPageNum a").bind("click", function () {
                showWait();
                $("#divPhoneBookPageNum a").removeClass("pageSelIdx");
                $("#divPhoneBookPageNum a").css("color", "#555");
                $(this).css("color", "#05bda1");
                $(this).addClass("pageSelIdx");
                var PBPageIdx = $(this).attr("name");
                pageIndex = parseInt(PBPageIdx);
                $("#deleteAllPhone").prop("checked", false);
                $("#lt_Phonebook_btnDelete").hide();
                that.UpdatePhoneBookList(pageIndex, false);
            });
        };
        this.showDeleteBtn = function () {
            $("#lt_Phonebook_btnDelete").hide();
            $("#deleteAllPhone").prop("checked", false);

            $("#deleteAllPhone").unbind("click");
            $("#deleteAllPhone").bind("click", function () {
                if ($("#deleteAllPhone").is(":checked")) {
                    if ($("#tablePhoneBookBody").html() != "") {
                        $("#tablePhoneBookBody .SimPhoneBook_del").prop("checked", true);
                        $("#lt_Phonebook_btnDelete").show();
                    }
                } else {
                    $("#tablePhoneBookBody .SimPhoneBook_del").prop("checked", false);
                    $("#lt_Phonebook_btnDelete").hide();
                }
            });
            $("#tablePhoneBookBody .SimPhoneBook_del").each(function () {
                $(this).unbind("click");
                $(this).bind("click", function () {
                    isAllChecked = true;
                    $("#lt_Phonebook_btnDelete").hide();
                    $("#tablePhoneBookBody .SimPhoneBook_del").each(function (index) {
                        if ($(this).is(":checked")) {
                            $("#lt_Phonebook_btnDelete").show();
                        } else {
                            isAllChecked = false;
                        }
                    });
                    if (isAllChecked) {
                        $("#deleteAllPhone").prop("checked", true);
                    } else {
                        $("#deleteAllPhone").prop("checked", false);
                    }
                });
            });
        };
        // this.copyMove = function(){
        //     $("#lt_copyMove_btnSave").unbind("click");
        //     $("#lt_copyMove_btnSave").bind("click",function(){
        //         var pbAction;
        //         if($("#radio_move").is(":checked")){
        //             if($("#span_move").html()==jQuery.i18n.prop("lt_Phonebook_moveToDevice")){
        //                 pbAction = "PB_MV_SIM_TO_LOCAL";
        //             }else{
        //                 pbAction = "PB_MV_LOCAL_TO_SIM";
        //             }
        //         }else{
        //             if($("#span_copy").html()==jQuery.i18n.prop("lt_Phonebook_copyToDevice")){
        //                 pbAction = "PB_CP_SIM_TO_LOCAL";
        //             }else{
        //                 pbAction = "PB_CP_LOCAL_TO_SIM";
        //             }
        //         }
        //         var pbId=$("#lt_copyMove_btnSave").attr("name")+",";
        //         var jsonData={};
        //         jsonData.pb_action=pbAction;
        //         jsonData.mv_cp_id=pbId;
        //         showWait();
        //         setTimeout(function () {
        //         postJSON("phonebook_set",jsonData,function(data){
        //             if ("0" == data.pb_result) {
        //                 $("#copyMoveDlg").hide();
        //                 that.onLoad(false);
        //             } else {
        //                 showMsgBox(jQuery.i18n.prop("dialog_message_phonebook_title"),jQuery.i18n.prop("lCopyFailed"));
        //             }
        //         });
        //         }, 100);
        //     });
        // };
        this.addPhoneBook = function () {
            $("#lt_SimPhoneBook_btnAdd").unbind("click");
            $("#lt_SimPhoneBook_btnAdd").bind("click", function () {
                if (that.checkInput()) {
                    var stcName = UniEncode($("#txt_Phonebook_stcName").val());
                    var stcNum = $("#txt_Phonebook_stcNum").val();
                    var selLoc = $("#selSaveLoc").val();
                    var selGroup = $("#selGroup").val();
                    var email = UniEncode($("#txtEmail").val());
                    var homePhone = $("#txtHomePhone").val();
                    var officePhone = $("#txtOfficePhone").val();
                    if (selLoc == "1" && parseInt(usedDevNum) >= parseInt(maxDevNum)) {
                        $("#lSimPhoneBookError").text(jQuery.i18n.prop("lPBRetlocationFlashFullErr"));
                        $("#lSimPhoneBookError").show();
                        return false;
                    }
                    var jsonData = {};
                    jsonData.pb_action = "pbm_contact_add";
                    jsonData.location = selLoc;
                    jsonData.name = stcName;
                    jsonData.mobile = stcNum;
                    if (selLoc == "1") {
                        jsonData.homenum = homePhone;
                        jsonData.officephone = officePhone;
                        jsonData.email = email;
                        jsonData.group = selGroup;
                    }
                    showWait();
                    setTimeout(function () {
                        postJSON("pb_set", jsonData, function (data) {
                            if (0 == data.pb_result || "0" == data.pb_result) {
                                showMsgBox(jQuery.i18n.prop("dialog_message_phonebook_title"), jQuery.i18n.prop("dialog_message_phonebook_save_contact_success"));
                                $("#phoneInfoDlg").hide();
                                that.onLoad(false);
                            } else {
                                showMsgBox(jQuery.i18n.prop("dialog_message_phonebook_title"), jQuery.i18n.prop("dialog_message_phonebook_save_contact_fail"));
                            }
                        });
                    }, 100);
                }
            });
        };
        this.sendMessage = function () {
            $("#lt_sendMessage_btnSend").unbind("click");
            $("#lt_sendMessage_btnSend").bind("click", function () {
                var phoneNumber = $("#txt_sendMessage_mobile").val();
                var text = $("#txtSmsContentInPhoneBook").val();
                var jsonData = {};
                var encodeType = "UNICODE";
                if (IsGSM7Code(text)) {
                    encodeType = "GSM7_default";
                }

                jsonData.send_from_draft_id = "";
                jsonData.message_flag = "SEND_SMS";
                jsonData.sms_cmd = "4";
                jsonData.contacts = phoneNumber;
                jsonData.content = UniEncode(text);
                jsonData.encode_type = encodeType;
                jsonData.sms_time = GetSmsTime();
                showWait();
                setTimeout(function () {
                    postJSON("message_set", jsonData, function (data) {
                        if (data.sms_cmd_status_result != 3) {
                            showMsgBox(jQuery.i18n.prop("dialog_message_phonebook_title"), jQuery.i18n.prop("lSaveMessageFailed"));
                        } else {
                            $("#sendMessageDlg").hide();
                            that.onLoad(false);
                        }
                    });
                }, 100);
            });
        };
        this.checkInput = function () {
            $("#lSimPhoneBookError").hide();
            var stcName = $("#txt_Phonebook_stcName").val();
            var stcNum = $("#txt_Phonebook_stcNum").val();
            var selLoc = $("#selSaveLoc").val();
            var email = $("#txtEmail").val();
            var homePhone = $("#txtHomePhone").val();
            var officePhone = $("#txtOfficePhone").val();

            if (stcName.length == 0) {
                $("#lSimPhoneBookError").text(jQuery.i18n.prop("lNameEmpty"));
                $("#lSimPhoneBookError").show();
                return false;
            }
            if (!deviceNameValidation_Contain_Chinese(stcName)) {
                $("#lSimPhoneBookError").text(jQuery.i18n.prop("InvalidName"));
                $("#lSimPhoneBookError").show();
                return false;
            }
            if ("" == stcNum) {
                $("#lSimPhoneBookError").text(jQuery.i18n.prop("lMobilePhoneEmpty"));
                $("#lSimPhoneBookError").show();
                return false;
            }
            if (!IsPhoneNumber(stcNum)) {
                $("#lSimPhoneBookError").text(jQuery.i18n.prop("lMobilePhoneError"));
                $("#lSimPhoneBookError").show();
                return false;
            }
            if (selLoc == "1") {
                if ("" != email && !IsEmail(email)) {
                    $("#lSimPhoneBookError").text(jQuery.i18n.prop("lEmailAddrError"));
                    $("#lSimPhoneBookError").show();
                    return false;
                }

                if ("" != homePhone && !IsPhoneNumber(homePhone)) {
                    $("#lSimPhoneBookError").text(jQuery.i18n.prop("lMobilePhoneError"));
                    $("#lSimPhoneBookError").show();
                    return false;
                }

                if ("" != officePhone && !IsPhoneNumber(officePhone)) {
                    $("#lSimPhoneBookError").text(jQuery.i18n.prop("lMobilePhoneError"));
                    $("#lSimPhoneBookError").show();
                    return false;
                }
            }
            return true;
        };
        this.deleteSimPhoneBook = function () {
            $("#lt_Phonebook_btnDelete").unbind("click");
            $("#lt_Phonebook_btnDelete").bind("click", function () {
                var delId = "";
                $("#tablePhoneBookBody .SimPhoneBook_del").each(function () {
                    if ($(this).is(":checked")) {
                        delId = delId + $(this).attr("name") + ",";
                    }
                });
                showWait();
                setTimeout(function () {
                    var jsonData = {};
                    jsonData.pb_action = "pbm_contact_delete";
                    jsonData.location = "2";
                    jsonData.delete_option = "delete_num";
                    jsonData.delete_pb_id = delId;
                    jsonData.pb_gr = SubMenuId;
                    postJSON("pb_set", jsonData, function (data) {
                        if (0 == data.pb_result || "0" == data.pb_result) {
                            showMsgBox(jQuery.i18n.prop("dialog_message_phonebook_title"), jQuery.i18n.prop("dialog_message_phonebook_delete_contact_success"));
                            that.onLoad(false);
                        } else {
                            showMsgBox(jQuery.i18n.prop("dialog_message_phonebook_title"), jQuery.i18n.prop("dialog_message_phonebook_delete_contact_fail"));
                        }
                    });
                }, 100);
            });
        };
        this.displayControls = function () {
            $("#h1_add_phonebook").html(jQuery.i18n.prop("lt_Phonebook_btnNew"));
            $("#lt_Phonebook_btnNew").val(jQuery.i18n.prop("lt_Phonebook_btnNew"));
            $("#lt_Phonebook_btnDelete").val(jQuery.i18n.prop("lt_Phonebook_btnDelete"));
            $("#lt_Phonebook_stcName").html(jQuery.i18n.prop("lt_Phonebook_stcName"));
            $("#lt_Phonebook_stcMobileNum").html(jQuery.i18n.prop("lt_Phonebook_stcMobileNum"));
            $("#lt_Phonebook_stcGroup").html(jQuery.i18n.prop("lt_Phonebook_stcGroup"));
            $("#lt_Phonebook_stcSaveLoc").html(jQuery.i18n.prop("lt_Phonebook_stcSaveLoc"));
            $("#lt_Phonebook_stcSimCard").html(jQuery.i18n.prop("lt_Phonebook_stcSimCard"));
            $("#lt_Phonebook_stcDevice").html(jQuery.i18n.prop("lt_Phonebook_stcDevice"));
            $("#lt_Phonebook_stcSaveLoc1").html(jQuery.i18n.prop("lt_Phonebook_stcSaveLoc"));
            $("#lt_Phonebook_stcName1").html(jQuery.i18n.prop("lt_Phonebook_stcName"));
            $("#lt_Phonebook_stcMobileNum1").html(jQuery.i18n.prop("lt_Phonebook_stcMobileNum"));
            $("#lt_SimPhoneBook_btnAdd").val(jQuery.i18n.prop("lt_Phonebook_btnNewSave"));
            $("#lt_SimPhoneBook_btnCancel").val(jQuery.i18n.prop("lt_Phonebook_stcCancelView"));
            $("#lt_Phonebook_stcFormTitle").html(jQuery.i18n.prop("lt_Phonebook_stcFormTitle"));
            $("#lt_Phonebook_stcGroup1").html(jQuery.i18n.prop("lt_Phonebook_stcGroup"));
            $("#lt_Phonebook_stcCommonPhoneBook").html(jQuery.i18n.prop("lt_Phonebook_stcCommonPhoneBook"));
            $("#lt_Phonebook_stcFamilyPhoneBook").html(jQuery.i18n.prop("lt_Phonebook_stcFamilyPhoneBook"));
            $("#lt_Phonebook_stcFriendPhoneBook").html(jQuery.i18n.prop("lt_Phonebook_stcFriendPhoneBook"));
            $("#lt_Phonebook_stcColleaguePhoneBook").html(jQuery.i18n.prop("lt_Phonebook_stcColleaguePhoneBook"));
            $("#lt_Phonebook_stcEmail").html(jQuery.i18n.prop("lt_Phonebook_stcEmail"));
            $("#lt_Phonebook_stcHomeNum").html(jQuery.i18n.prop("lt_Phonebook_stcHomeNum"));
            $("#lt_Phonebook_stcOfficeNum").html(jQuery.i18n.prop("lt_Phonebook_stcOfficeNum"));
            $("#lt_SimPhoneBook_btnUpdate").val(jQuery.i18n.prop("lt_btnSave"));
            $("#lt_copyMove_btnSave").val(jQuery.i18n.prop("lt_btnSave"));
            $("#lt_copyMove_btnCancel").val(jQuery.i18n.prop("lt_btnCancel"));
            $("#lt_Phonebook_copyMove").html(jQuery.i18n.prop("lt_Phonebook_stcBoxTitle"));
            $("#lt_sendMessage_btnSend").val(jQuery.i18n.prop("lt_Phonebook_btnSendMsg"));
            $("#lt_sendMessage_btnCancel").val(jQuery.i18n.prop("lt_btnCancel"));
            $("#lt_sendMessage_title").html(jQuery.i18n.prop("lt_Phonebook_stcFormTitle"));
            $("#lt_sendMessage_mobile").html(jQuery.i18n.prop("lt_Phonebook_stcContact"));
            $("#lt_sendMessage_content").html(jQuery.i18n.prop("lt_Phonebook_stcContents"));
        };
        return this;
    };
})(jQuery);
function showPhoneBookIndex(obj) {
    $("#lSimPhoneBookError").text("");
    $("#lSimPhoneBookError").hide();
    $("#lt_SimPhoneBook_btnUpdate").show();
    $("#lt_SimPhoneBook_btnAdd").hide();
    var pbStr = $(obj).attr("name");
    var pbArr = pbStr.split("*&*");
    $("#txt_Phonebook_stcName").val(pbArr[2]);
    $("#txt_Phonebook_stcNum").val(pbArr[3]);
    $("#selSaveLoc").val(pbArr[1]);
    $("#lt_SimPhoneBook_btnUpdate").attr("name", pbArr[0]);
    if (pbArr[1] == "0") {
        $("#divDeviceSupport").hide();
        // $("#selSaveLoc").attr("disabled",true);
        // $("#selSaveLoc").css("backgroundColor","#ddd");
    } else {
        $("#divDeviceSupport").show();
        // $("#selSaveLoc").attr("disabled",false);
        // $("#selSaveLoc").css("backgroundColor","#fff");
        $("#selGroup").val(pbArr[7]);
        if ("NONE" == pbArr[6]) pbArr[6] = "";
        $("#txtEmail").val(pbArr[6]);
        $("#txtHomePhone").val(pbArr[4]);
        $("#txtOfficePhone").val(pbArr[5]);
    }
    $("#phoneInfoDlg").show();
    setDlgStyle();
    setAddBoxHeigth("phoneInfoDlg");
    $("#selSaveLoc").attr("disabled", true);
    $("#selSaveLoc").css("backgroundColor", "#ddd");
}
// function CopyMovePhone(obj){
//     var pbStr=$(obj).attr("name");
//     var pbArr=pbStr.split("*&*");
//     if(pbArr[1]=="0"){
//         $("#span_move").html(jQuery.i18n.prop("lt_Phonebook_moveToDevice"));
//         $("#span_copy").html(jQuery.i18n.prop("lt_Phonebook_copyToDevice"));
//     }else{
//         $("#span_move").html(jQuery.i18n.prop("lt_Phonebook_moveToSim"));
//         $("#span_copy").html(jQuery.i18n.prop("lt_Phonebook_copyToSim"));
//     }
//     $("#lt_copyMove_btnSave").attr("name",pbArr[0]);
//     $("#copyMoveDlg").show();
//     setDlgStyle();
//     setAddBoxHeigth("copyMoveDlg");
// }
function phoneBookSendSms(obj) {
    var pbStr = $(obj).attr("name");
    var pbArr = pbStr.split("*&*");
    $("#inputcountInPhoneBook").text("(0/765)");
    $("#inputItemCountInPhoneBook").text("(0/5)");
    $("#lt_sendMessage_btnSend").attr("name", pbArr[3]);
    $("#txt_sendMessage_mobile").val(pbArr[3]);
    $("#txtSmsContentInPhoneBook").val("");
    $("#sendMessageDlg").show();
    setDlgStyle();
    setAddBoxHeigth("sendMessageDlg");
}
function deviceNameValidation_Contain_Chinese(str) {
    //  if (isChineseChar(str)) {
    //  return false;   }

    if (str.toString().indexOf("#") != -1) return false;
    else if (str.toString().indexOf(":") != -1) return false;
    else if (str.toString().indexOf(" ") != -1) return false;
    else if (str.toString().indexOf("&") != -1) return false;
    else if (str.toString().indexOf(";") != -1) return false;
    else if (str.toString().indexOf("~") != -1) return false;
    else if (str.toString().indexOf("|") != -1) return false;
    else if (str.toString().indexOf("<") != -1) return false;
    else if (str.toString().indexOf(">") != -1) return false;
    else if (str.toString().indexOf("$") != -1) return false;
    else if (str.toString().indexOf("%") != -1) return false;
    else if (str.toString().indexOf("^") != -1) return false;
    else if (str.toString().indexOf("!") != -1) return false;
    else if (str.toString().indexOf("@") != -1) return false;
    else if (str.toString().indexOf(",") != -1) return false;
    else if (str.toString().indexOf("*") != -1) return false;
    else if (str.toString().indexOf("\\") != -1) return false;
    else if (str.toString().indexOf("/") != -1) return false;
    else return true;
}
// -------------------------------------------------------------objSms-----------------------------------------------------------------
var g_status_report = "";
var phoneNumberList = null;
var message_list_json = null;
(function ($) {
    $.objSms = function () {
        var that = this;
        var memStore = "";
        var tags = "";
        var SMS_NUMBER_PAGE = "10";
        this.onLoad = function (flag) {
            if (flag) {
                that.displayControls();
                that.btnEvent();
                that.sendSms();
                that.deleteSms();
                that.saveSms();
                // that.copySms();
                // that.moveSms();
            }
            that.showData();
            setDlgStyle();
        };
        this.showData = function () {
            $("#lt_sms_btnDelete").hide();

            callJSON("homepage_info", function (json) {
                if (json.sim_status == "0" || json.sim_status == 0) {
                    g_bSimCardExist = true;
                } else {
                    g_bSimCardExist = false;
                }
                if (SubMenuId == "mSim") {
                    if (g_bSimCardExist) {
                        that.UpdateSmsList(1, true);
                    } else {
                        showMsgBox(jQuery.i18n.prop("lOperateMessageReportTitle"), jQuery.i18n.prop("lsmsSimCardAbsent"));
                        $(".helpDiv").css("height", "32px");
                        return;
                    }
                } else {
                    that.UpdateSmsList(1, true);
                }
            });
            callJSON("sms_setting_info", function (json) {
                g_status_report = json.status_report;
            });
        };
        this.UpdateSmsList = function (pageNumber, bInitFlag) {
            var messageFlag;
            switch (SubMenuId) {
                case "mDeviceInbox":
                    messageFlag = "GET_RCV_SMS_LOCAL";
                    memStore = "1";
                    tags = "12";
                    break;
                case "mSmsOutbox":
                    messageFlag = "GET_SENT_SMS_LOCAL";
                    memStore = "1";
                    tags = "2";
                    $("#lt_sms_stcRecvTime").text(jQuery.i18n.prop("lt_sms_stc_Time"));
                    $("#lt_sms_stcFrom").text(jQuery.i18n.prop("lsmsReceiver"));
                    break;
                case "mSim":
                    messageFlag = "GET_SIM_SMS";
                    memStore = "0";
                    break;
                case "mSmsDrafts":
                    messageFlag = "GET_DRAFT_SMS";
                    memStore = "2";
                    tags = "2";
                    $("#lt_sms_stcRecvTime").text(jQuery.i18n.prop("lt_sms_stc_Time"));
                    $("#lt_sms_stcFrom").text(jQuery.i18n.prop("lsmsReceiver"));
                    break;
                default:
            }
            var jsonData = {};
            jsonData.message_flag = messageFlag;
            jsonData.page_number = pageNumber;
            jsonData.data_per_page = SMS_NUMBER_PAGE;
            postJSON("message_set", jsonData, function (json) {
                var smsPageNum = parseInt(json.total_page_number);
                if (bInitFlag) {
                    callJSON("sms_capacity_info", function (json1) {
                        var smsNvTotal = parseInt(json1.sms_nv_total);
                        var smsSimTotal = parseInt(json1.sms_sim_total);
                        var smsSimNum = parseInt(json1.sms_sim_num);
                        var smsNvRecvTotal = parseInt(json1.sms_nv_rev_total);
                        var smsNvSendTotal = parseInt(json1.sms_nv_send_total);
                        var smsNvDraftTotal = parseInt(json1.sms_nv_draftbox_total);
                        var smsNvRecvNum = parseInt(json1.sms_nv_rev_num);
                        var smsNvSendNum = parseInt(json1.sms_nv_send_num);
                        var smsNvDraftNum = parseInt(json1.sms_nv_draftbox_num);

                        if (SubMenuId == "mDeviceInbox" && smsNvRecvNum >= smsNvRecvTotal) {
                            showMsgBox(jQuery.i18n.prop("lsmsWarning"), jQuery.i18n.prop("lDeviceInboxCapacityFull"));
                        }

                        if (SubMenuId == "mSmsOutbox" && smsNvSendNum >= smsNvSendTotal) {
                            showMsgBox(jQuery.i18n.prop("lsmsWarning"), jQuery.i18n.prop("lDeviceOutboxCapacityFull"));
                        }

                        if (SubMenuId == "mSmsDrafts" && smsNvDraftNum >= smsNvDraftTotal) {
                            showMsgBox(jQuery.i18n.prop("lsmsWarning"), jQuery.i18n.prop("lDeviceDraftboxCapacityFull"));
                        }

                        if (SubMenuId == "mSim" && smsSimNum >= smsSimTotal && smsSimTotal != 0) {
                            showMsgBox(jQuery.i18n.prop("lsmsWarning"), jQuery.i18n.prop("lSimCardCapacityFull"));
                        }

                        that.InitSmsPageNum(smsPageNum);
                        switch (SubMenuId) {
                            case "mDeviceInbox":
                                $("#lt_sms_stcTitle").html(jQuery.i18n.prop(SubMenuId) + "(" + smsNvRecvNum + "/" + smsNvRecvTotal + ")");
                                break;
                            case "mSmsOutbox":
                                $("#lt_sms_stcTitle").html(jQuery.i18n.prop(SubMenuId) + "(" + smsNvSendNum + "/" + smsNvSendTotal + ")");
                                break;
                            case "mSim":
                                $("#lt_sms_stcTitle").html(jQuery.i18n.prop(SubMenuId) + "(" + smsSimNum + "/" + smsSimTotal + ")");
                                break;
                            case "mSmsDrafts":
                                $("#lt_sms_stcTitle").html(jQuery.i18n.prop(SubMenuId) + "(" + smsNvDraftNum + "/" + smsNvDraftTotal + ")");
                                break;
                            default:
                        }
                    });
                }
                $("#smsListInfo").html("");
                if (json.message_list.length > 0) {
                    for (var i = 0; i < json.message_list.length; i++) {
                        var l = json.message_list[i];
                        var status = l.status;
                        var subjectUnicode = l.subject;
                        var content = UniDecode(subjectUnicode);
                        var from = UniDecode(l.from);
                        var recvTime = l.received;
                        var date = [];
                        date = recvTime.split(",");
                        var len = date.length;
                        for (var j = 0; j < len - 1; j++) {
                            //the last one is timezone , no need to handle
                            if (date[j] < 10 && date[j].length < 2)
                                // add 0 if number is smaller than 10
                                date[j] = "0" + date[j];
                        }
                        var messageType = l.message_type;
                        var formatTime = date[0] + "/" + date[1] + "/" + date[2] + " " + date[3] + ":" + date[4] + ":" + date[5]; //month/day/year hh:mm:ss
                        that.AddSmsToList(from, content, subjectUnicode, formatTime, status, l.index, messageType);
                    }
                    that.checkboxAll();
                    $("#deleteAllSms").attr("disabled", false);
                    $("#deleteAllSms").attr("checked", false);
                } else {
                    var noSMSHtml = '<tr><td colspan="5">' + jQuery.i18n.prop("lt_no_sms") + "</td></tr>";
                    $("#smsListInfo").html(noSMSHtml);
                    $("#deleteAllSms").attr("disabled", true);
                    $("#deleteAllSms").attr("checked", false);
                }
            });
        };
        this.AddSmsToList = function (From, Subject, SubjectUniCode, recvTime, Status, id, messageType) {
            var showSubject = Subject;
            if (Subject.length > 40) {
                showSubject = Subject.substr(0, 35) + "...";
            }
            showSubject = showSubject.replace(/</gi, "&lt");
            showSubject = showSubject.replace(/>/gi, "&gt");
            showSubject = showSubject.replace(/[ ]/g, "&nbsp");

            var contact = "";
            if (From.indexOf(";") == 0) {
                contact = From.substr(1, From.length - 1);
            } else {
                contact = From.substr(From.indexOf(";") + 1, From.length);
            }
            contact = contact.split(",").join(";");
            var statusLtTipId = "";
            var imgSrc = "";
            switch (Status) {
                case "0":
                    statusLtTipId = "lt_sms_unreadSms";
                    imgSrc = "unreadSms.png";
                    break;
                case "1":
                    statusLtTipId = "lt_sms_readedSms";
                    imgSrc = "readedSms.png";
                    break;
                case "2":
                    statusLtTipId = "lt_sms_sendFailed";
                    imgSrc = "SmssendFailed.png";
                    break;
                case "3":
                    statusLtTipId = "lt_sms_sendSuccess";
                    imgSrc = "SendSmsSuccess.png";
                    break;
                case "4":
                    statusLtTipId = "lt_sms_drafts";
                    imgSrc = "drafts.png";
                    break;
                default:
                    break;
            }
            var htmlText;
            if (0 == messageType) {
                htmlText = '<tr id="' + id + '" name="' + SubjectUniCode + '"><td>' + contact + '</td><td style="cursor: pointer;" onclick="showLocalSms(this)" value="' + SubjectUniCode + '" name="' + id + "*#*" + contact + "*#*" + '"><span>' + showSubject + "</span></td>" + "<td>" + recvTime + '</td><td> <img align="middle" src="images/' + imgSrc + '" title="' + jQuery.i18n.prop(statusLtTipId) + '"/></td>' + '<td><input id="' + id + '"  align="right" type="checkbox" class="del_checkbox"/></td></tr>';
            } else {
                htmlText = '<tr id="' + id + '" name="' + SubjectUniCode + '"><td name="' + From + '">' + contact + '</td><td style="background:#ddd;cursor: pointer;" value="' + SubjectUniCode + '" onclick="showLocalSms(this)" name="' + id + "*#*" + contact + "*#*" + '">' + showSubject + "</td>" + "<td><span>" + recvTime + '</span></td><td> <img align="middle" src="images/' + imgSrc + '" title="' + jQuery.i18n.prop(statusLtTipId) + '"/></td>' + '<td><input id="' + id + '"  align="right" type="checkbox" class="del_checkbox"/></td></tr>';
            }
            $("#smsListInfo").append(htmlText);
        };
        this.InitSmsPageNum = function (totalPageNum) {
            $("#divSmsPageNum").empty();
            totalPageNum = totalPageNum == 0 ? 1 : totalPageNum;
            for (var idx = 1; idx <= totalPageNum; ++idx) {
                var htmlTxt;
                if (idx == 1) {
                    htmlTxt = '<a class="pageSelIdx" style="color: #05bda1; font-weight: 700; text-decoration: underline;margin-left:3px;cursor:pointer;" href="##">' + idx + "</a>";
                } else {
                    htmlTxt = '<a style="color: #333; font-weight: 700; text-decoration: underline;margin-left:3px;cursor:pointer;" href="##">' + idx + "</a>";
                }
                $("#divSmsPageNum").append(htmlTxt);
            }
            $("#divSmsPageNum").unbind("click");
            $("#divSmsPageNum").bind("click", function (event) {
                if ($(event.target).is("a")) {
                    $(event.target).css("color", "#05bda1");
                    $(event.target).addClass("pageSelIdx");
                    $(event.target).siblings().css("color", "#333");
                    $(event.target).siblings().removeClass("pageSelIdx");
                    var smsPageIdx = $(event.target).text();
                    $("#deleteAllSms").attr("checked", false);
                    that.UpdateSmsList(smsPageIdx, false);
                }
            });
        };
        this.deleteSms = function () {
            $("#lt_sms_btnDelete").unbind("click");
            $("#lt_sms_btnDelete").bind("click", function () {
                var deleteId = "";
                $(".del_checkbox").each(function (index) {
                    if ($(this).is(":checked")) {
                        deleteId += $(this).parent().parent().attr("id") + ",";
                    }
                });
                var jsonData = {};
                jsonData.message_flag = "DELETE_SMS";
                jsonData.sms_cmd = "6";
                jsonData.tags = tags;
                jsonData.mem_store = memStore;
                jsonData.delete_message_id = deleteId;
                showWait();
                setTimeout(function () {
                    postJSON("message_set", jsonData, function (data) {
                        if (data.sms_cmd_status_result != 3) {
                            showMsgBox(jQuery.i18n.prop("lOperateMessageReportTitle"), jQuery.i18n.prop("lDeleteMessageFailed"));
                        } else {
                            that.onLoad(false);
                        }
                    });
                }, 100);
            });
        };
        this.checkSendSms = function (phoneNumberList, smsText) {
            $("#lt_sms_stcSmsErrorInfo").hide();
            if ("" == phoneNumberList || phoneNumberList.trim() == "") {
                document.getElementById("lt_sms_stcSmsErrorInfo").style.display = "inline";
                $("#lt_sms_stcSmsErrorInfo").text(jQuery.i18n.prop("lContactIsEmpty"));
                return false;
            }
            var regex = /^\;{1,40}$/;
            if (regex.test(phoneNumberList)) {
                document.getElementById("lt_sms_stcSmsErrorInfo").style.display = "inline";
                $("#lt_sms_stcSmsErrorInfo").text(jQuery.i18n.prop("lContactIsEmpty"));
                return false;
            }
            if (phoneNumberList.charAt(phoneNumberList.length - 1) != ";") {
                phoneNumberList += ";";
            }
            var phoneNumberArr = phoneNumberList.split(";");
            var isEmpty = true;
            for (var i = 0; i < phoneNumberArr.length; i++) {
                var phoneNumber = phoneNumberArr[i];
                if (phoneNumberArr[i] != "" && !IsPhoneNumber(phoneNumber)) {
                    document.getElementById("lt_sms_stcSmsErrorInfo").style.display = "inline";
                    $("#lt_sms_stcSmsErrorInfo").text(jQuery.i18n.prop("lPhoneNumberFormatError"));
                    return false;
                }
                if (isEmpty && phoneNumber == "") {
                    isEmpty = true;
                } else {
                    isEmpty = false;
                }
            }
            if (isEmpty) {
                document.getElementById("lt_sms_stcSmsErrorInfo").style.display = "inline";
                $("#lt_sms_stcSmsErrorInfo").text(jQuery.i18n.prop("lContactIsEmpty"));
                return false;
            }
            if (smsText == "") {
                document.getElementById("lt_sms_stcSmsErrorInfo").style.display = "inline";
                $("#lt_sms_stcSmsErrorInfo").text(jQuery.i18n.prop("lSmsIsEmpty"));
                return false;
            }

            if (IsGSM7Code(smsText)) {
                if (smsText.length > 765) {
                    $("#lt_sms_stcSmsErrorInfo").text(jQuery.i18n.prop("lt_sms_stcSmsLenghtError"));
                    document.getElementById("lt_sms_stcSmsErrorInfo").style.display = "inline";
                    return false;
                }
            } else {
                if (smsText.length > 335) {
                    $("#lt_sms_stcSmsErrorInfo").text(jQuery.i18n.prop("lt_sms_stcSmsLenghtError"));
                    document.getElementById("lt_sms_stcSmsErrorInfo").style.display = "inline";
                    return false;
                }
            }
            return true;
        };
        this.sendSms = function () {
            $("#lt_sms_btnSend").unbind("click");
            $("#lt_sms_btnSend").bind("click", function () {
                if (!g_bSimCardExist) {
                    showMsgBox(jQuery.i18n.prop("lOperateMessageReportTitle"), jQuery.i18n.prop("lsmsSimCardAbsent"));
                    return;
                }
                var phoneNumberList = $("#txtNumberList").val();
                var text = $("#txtSmsContent").val();
                if (that.checkSendSms(phoneNumberList, text)) {
                    var encodeType = "UNICODE";
                    if (IsGSM7Code(text)) {
                        encodeType = "GSM7_default";
                    }

                    var smsId = "";
                    if (SubMenuId == "mSmsDrafts") {
                        smsId = $("#txtSmsContent").attr("name") + ",";
                    }
                    var phoneNumberArr = phoneNumberList.split(";");
                    var jsonData = {};
                    jsonData.send_from_draft_id = smsId;
                    jsonData.message_flag = "SEND_SMS";
                    jsonData.sms_cmd = "4";
                    jsonData.contacts = phoneNumberArr.join(",") + ",";
                    jsonData.content = UniEncode(text);
                    jsonData.encode_type = encodeType;
                    jsonData.sms_time = GetSmsTime();
                    showWait();
                    setTimeout(function () {
                        postJSON("message_set", jsonData, function (data) {
                            if (data.sms_cmd_status_result != 3) {
                                showMsgBox(jQuery.i18n.prop("lOperateMessageReportTitle"), jQuery.i18n.prop("lSendMessageFailed"));
                            } else {
                                $("#divSmsList").show();
                                $("#divSmsChatRoom").hide();

                                that.onLoad(false);
                            }
                            if (g_status_report == "1") {
                                QueryReportTryCount = 0;
                                QuerySmsReport();
                            }
                        });
                    }, 100);
                }
            });
        };
        this.saveSms = function () {
            $("#lt_sms_btnSaveDraft").unbind("click");
            $("#lt_sms_btnSaveDraft").bind("click", function () {
                var phoneNumberList = $("#txtNumberList").val();
                var text = $("#txtSmsContent").val();
                if (that.checkSendSms(phoneNumberList, text)) {
                    phoneNumberList = phoneNumberList.split(";").join(",");
                    var encodeType = "UNICODE";
                    if (IsGSM7Code(text)) {
                        encodeType = "GSM7_default";
                    }
                    if (("UNICODE" == encodeType && text.length > 70) || ("GSM7_default" == encodeType && text.length > 160)) {
                        document.getElementById("lt_sms_stcSmsErrorInfo").style.display = "inline";
                        $("#lt_sms_stcSmsErrorInfo").text(jQuery.i18n.prop("lSaveSmsError"));
                        return;
                    }
                    var smsId = "";
                    if (SubMenuId == "mSmsDrafts") {
                        smsId = $("#txtSmsContent").attr("name") + ",";
                    }
                    var jsonData = {};
                    jsonData.message_flag = "SAVE_SMS";
                    jsonData.sms_cmd = "5";
                    jsonData.tags = "11";
                    jsonData.mem_store = "1";
                    jsonData.contacts = phoneNumberList;
                    jsonData.content = UniEncode(text);
                    jsonData.encode_type = encodeType;
                    jsonData.sms_time = GetSmsTime();
                    if (SubMenuId == "mSmsDrafts") {
                        jsonData.edit_draft_id = smsId;
                    }
                    showWait();
                    setTimeout(function () {
                        postJSON("message_set", jsonData, function (data) {
                            if (data.sms_cmd_status_result != 3) {
                                showMsgBox(jQuery.i18n.prop("lOperateMessageReportTitle"), jQuery.i18n.prop("lSendMessageFailed"));
                            } else {
                                $("#divSmsList").show();
                                $("#divSmsChatRoom").hide();
                                that.onLoad(false);
                            }
                        });
                    }, 100);
                }
            });
        };
        this.copySms = function () {
            $("#lt_sms_btnCopy").unbind("click");
            $("#lt_sms_btnCopy").bind("click", function () {
                if (SubMenuId == "mDeviceInbox" || SubMenuId == "mSmsDrafts" || SubMenuId == "mSmsOutbox") {
                    if (!g_bSimCardExist) {
                        showMsgBox(jQuery.i18n.prop("lOperateMessageReportTitle"), jQuery.i18n.prop("lsmsSimCardAbsent"));
                        return;
                    }
                }
                var copyId = "";
                $(".del_checkbox").each(function (index) {
                    if ($(this).is(":checked")) {
                        copyId += $(this).parent().parent().attr("id") + ",";
                    }
                });
                var jsonData = {};
                if (SubMenuId == "mDeviceInbox" || SubMenuId == "mSmsOutbox" || SubMenuId == "mSmsDrafts") {
                    jsonData.message_flag = "COPY_SMS_TO_SIM";
                } else {
                    jsonData.message_flag = "COPY_SMS_TO_LOCAL";
                }
                jsonData.sms_cmd = "8";
                jsonData.tags = tags;
                jsonData.mem_store = memStore;
                jsonData.mv_cp_id = copyId;
                showWait();
                setTimeout(function () {
                    postJSON("message_set", jsonData, function (data) {
                        if (data.sms_cmd_status_result == "9" && smsCmd == "8") {
                            showMsgBox(jQuery.i18n.prop("lOperateMessageReportTitle"), jQuery.i18n.prop("lCopyMessagePartialFailed"));
                        } else if (data.sms_cmd_status_result != "3") {
                            showMsgBox(jQuery.i18n.prop("lOperateMessageReportTitle"), jQuery.i18n.prop("lCopyMessageFailed"));
                        } else {
                            that.onLoad(false);
                        }
                    });
                }, 100);
            });
        };
        this.moveSms = function () {
            $("#lt_sms_btnMove").unbind("click");
            $("#lt_sms_btnMove").bind("click", function () {
                if (SubMenuId == "mDeviceInbox" || SubMenuId == "mSmsDrafts" || SubMenuId == "mSmsOutbox") {
                    if (!g_bSimCardExist) {
                        showMsgBox(jQuery.i18n.prop("lOperateMessageReportTitle"), jQuery.i18n.prop("lsmsSimCardAbsent"));
                        return;
                    }
                }
                var moveId = "";
                $(".del_checkbox").each(function (index) {
                    if ($(this).is(":checked")) {
                        moveId += $(this).parent().parent().attr("id") + ",";
                    }
                });
                var jsonData = {};
                if (SubMenuId == "mDeviceInbox" || SubMenuId == "mSmsOutbox" || SubMenuId == "mSmsDrafts") {
                    jsonData.message_flag = "MOVE_SMS_TO_SIM";
                } else {
                    jsonData.message_flag = "MOVE_SMS_TO_LOCAL";
                }
                jsonData.sms_cmd = "9";
                jsonData.tags = tags;
                jsonData.mem_store = memStore;
                jsonData.mv_cp_id = moveId;
                showWait();
                setTimeout(function () {
                    postJSON("message_set", jsonData, function (data) {
                        if (data.sms_cmd_status_result == "9" && smsCmd == "9") {
                            showMsgBox(jQuery.i18n.prop("lOperateMessageReportTitle"), jQuery.i18n.prop("lCopyMessagePartialFailed"));
                        } else if (data.sms_cmd_status_result != "3") {
                            showMsgBox(jQuery.i18n.prop("lOperateMessageReportTitle"), jQuery.i18n.prop("lCopyMessageFailed"));
                        } else {
                            that.onLoad(false);
                        }
                    });
                }, 100);
            });
        };
        this.btnEvent = function () {
            $("#lt_sms_btnNew").unbind("click");
            $("#lt_sms_btnNew").bind("click", function () {
                $("#txtNumberList").val("");
                $("#txtSmsContent").val("");
                $("#divSmsList").hide();
                $("#divRecvSmsContent").hide();
                $("#divSmsChatRoom").show();
                $("#txtNumberList").prop("disabled", false);
            });

            $("#lt_sms_btnCancel").bind("click", function () {
                $("#txtSmsCharaNum").text("(0/765)");
                $("#txtSmsItemNum").text("(0/5)");
                $("#divSmsChatRoom").hide();
                $("#divSmsList").show();
                $("#txtNumberList").prop("disabled", false);
                that.onLoad(false);
            });

            var bind_name = "input";
            if (navigator.userAgent.indexOf("MSIE") != -1) {
                bind_name = "propertychange";
            }
            $("#txtSmsContent").unbind(bind_name);
            $("#txtSmsContent").bind(bind_name, function () {
                valuateContLen();
            });

            $("#deleteAllSms").unbind("click");
            $("#deleteAllSms").bind("click", function () {
                if ($("#deleteAllSms").is(":checked")) {
                    $("#smsListInfo input").prop("checked", true);
                    // if(SubMenuId=="mDeviceInbox" || SubMenuId=="mSmsOutbox" || SubMenuId=="mSmsDrafts"){
                    //     $("#lt_sms_btnCopy").val(jQuery.i18n.prop("lt_sms_stcmeucopytosim"));
                    //     $("#lt_sms_btnMove").val(jQuery.i18n.prop("lt_sms_stcmeumovetosim"));
                    // }else{
                    //     $("#lt_sms_btnCopy").val(jQuery.i18n.prop("lt_sms_stcmeucopytolocal"));
                    //     $("#lt_sms_btnMove").val(jQuery.i18n.prop("lt_sms_stcmeumovetolocal"));
                    // }

                    $("#lt_sms_btnDelete").show();
                    // $("#lt_sms_btnCopy").show();
                    // $("#lt_sms_btnMove").show();
                    // if(SubMenuId=="mSmsDrafts" || SubMenuId=="mSmsOutbox"){
                    //     $("#lt_sms_btnCopy").hide();
                    //     $("#lt_sms_btnMove").hide();
                    // }
                } else {
                    $("#smsListInfo .del_checkbox").prop("checked", false);
                    $("#lt_sms_btnDelete").hide();
                    // $("#lt_sms_btnCopy").hide();
                    // $("#lt_sms_btnMove").hide();
                }
            });
        };
        this.checkboxAll = function () {
            $(".del_checkbox").unbind("click");
            $(".del_checkbox").bind("click", function () {
                var allChecked = true;
                var isChecked = false;
                $(".del_checkbox").each(function (index) {
                    if (!$(this).is(":checked")) {
                        allChecked = false;
                    } else {
                        isChecked = true;
                    }
                });

                if (allChecked) {
                    $("#deleteAllSms").prop("checked", true);
                } else {
                    $("#deleteAllSms").prop("checked", false);
                }
                if (isChecked) {
                    // if(SubMenuId=="mDeviceInbox" || SubMenuId=="mSmsOutbox" || SubMenuId=="mSmsDrafts"){
                    //     $("#lt_sms_btnCopy").val(jQuery.i18n.prop("lt_sms_stcmeucopytosim"));
                    //     $("#lt_sms_btnMove").val(jQuery.i18n.prop("lt_sms_stcmeumovetosim"));
                    // }else{
                    //     $("#lt_sms_btnCopy").val(jQuery.i18n.prop("lt_sms_stcmeucopytolocal"));
                    //     $("#lt_sms_btnMove").val(jQuery.i18n.prop("lt_sms_stcmeumovetolocal"));
                    // }
                    $("#lt_sms_btnDelete").show();
                    // $("#lt_sms_btnCopy").show();
                    // $("#lt_sms_btnMove").show();

                    // if(SubMenuId=="mSmsDrafts" || SubMenuId=="mSmsOutbox"){
                    //     $("#lt_sms_btnCopy").hide();
                    //     $("#lt_sms_btnMove").hide();
                    // }
                } else {
                    $("#lt_sms_btnDelete").hide();
                    // $("#lt_sms_btnCopy").hide();
                    // $("#lt_sms_btnMove").hide();
                }
            });
        };
        this.readSMS = function (index) {
            var jsonData = {};
            jsonData.message_flag = "SET_MSG_READ";
            jsonData.sms_cmd = "7";
            jsonData.tags = tags;
            jsonData.mem_store = memStore;
            jsonData.read_message_id = index;
            postJSON("message_set", jsonData);
        };
        this.displayControls = function () {
            document.getElementById("lt_sms_stcFrom").innerHTML = jQuery.i18n.prop("lt_sms_stcFrom");
            document.getElementById("lt_sms_stcSubject").innerHTML = jQuery.i18n.prop("lt_sms_stcSubject");
            document.getElementById("lt_sms_stcRecvTime").innerHTML = jQuery.i18n.prop("lt_sms_stc_Time");
            document.getElementById("lt_sms_stcStatus").innerHTML = jQuery.i18n.prop("lt_sms_stcStatus");
            $("#lt_sms_btnSend").val(jQuery.i18n.prop("lt_sms_btnSend"));
            $("#lt_sms_btnDelete").val(jQuery.i18n.prop("lt_sms_btnDelete"));
            $("#lt_sms_btnNew").val(jQuery.i18n.prop("lt_sms_btnNew"));
            $("#lt_sms_btnSaveDraft").val(jQuery.i18n.prop("lt_sms_btnSaveDraft"));
            $("#lt_sms_btnCancel").val(jQuery.i18n.prop("lt_sms_btnCancel"));
            $("#lt_Phonebook_btnSave").val(jQuery.i18n.prop("lt_Phonebook_btnSave"));
            // $("#lt_sms_btnCopy").val(jQuery.i18n.prop("lt_sms_btnCopy"));
            // $("#lt_sms_btnMove").val(jQuery.i18n.prop("lt_sms_btnMove"));
        };
        return this;
    };
})(jQuery);
function showLocalSms(smsId) {
    var strSms = $(smsId).attr("name");
    var arr = strSms.split("*#*");
    var val = UniDecode($(smsId).attr("value"));
    $("#txtSmsContent").val("");
    $("#divSmsList").hide();
    $("#divSmsChatRoom").show();
    $("#lt_sms_btnSaveDraft").show();
    $("#lt_sms_btnSend").show();
    $("#txtNumberList").val(arr[1]);
    if (SubMenuId == "mSmsDrafts") {
        $("#divRecvSmsContent").hide();
        $("#txtNumberList").prop("disabled", false);
        $("#txtSmsContent").val(val);
        $("#txtSmsContent").attr("name", arr[0]);
    } else {
        $("#txtNumberList").prop("disabled", true);
        $("#txtRecvSmsContent").html(val);
        $("#divRecvSmsContent").show();
    }
    valuateContLen();
    $.objSms().readSMS(arr[0]);
}
function GetSmsTime() {
    var date = new Date();
    var fullYear = new String(date.getFullYear());
    var year = fullYear.substr(2, fullYear.length - 1);
    var month = date.getMonth() + 1;
    var day = date.getDate();
    var hour = date.getHours();
    var mimute = date.getMinutes();
    var second = date.getSeconds();
    var timeZone = 0 - date.getTimezoneOffset() / 60;
    var timeZoneStr = "";
    if (timeZone > 0) {
        timeZoneStr = "%2B" + timeZone;
    } else {
        timeZoneStr = "-" + timeZone;
    }
    var smsTime = year + "," + month + "," + day + "," + hour + "," + mimute + "," + second + "," + timeZoneStr;
    return smsTime;
}
function valuateContLen() {
    $("#lt_sms_stcSmsErrorInfo").hide();
    var messageBody = document.getElementById("txtSmsContent").value;
    // var patrn = /[\u4E00-\u9FA5]|[\uFE30-\uFFA0]/gi;

    var msgLen = messageBody.length;
    var charCount, itemCount;
    if (!IsGSM7Code(messageBody)) {
        if (msgLen > 335) {
            $("#txtSmsContent").val(messageBody.substr(0, 335));
            msgLen = 335;
        }
        charCount = "(" + msgLen + "/335)";
        if (msgLen <= 70) {
            itemCount = 1;
        } else {
            itemCount = Math.floor(msgLen / 67 + (msgLen % 67 > 0 ? 1 : 0));
        }
    } else {
        //english
        if (msgLen > 765) {
            $("#txtSmsContent").val(messageBody.substr(0, 765));
            msgLen = 765;
        }

        if (msgLen <= 160) {
            itemCount = 1;
        } else {
            itemCount = Math.floor(msgLen / 153 + (msgLen % 153 > 0 ? 1 : 0));
        }

        charCount = "(" + msgLen + "/765)";
    }

    $("#txtSmsCharaNum").text(charCount);
    $("#txtSmsItemNum").text("(" + itemCount + "/5)");
}
var QueryReportTryCount = 0;
function QuerySmsReport() {
    var recvSuccessNumber = "";
    var recvFailNumber = "";
    setTimeout(function () {
        callJSON("sms_status_report_list_info", function (retData) {
            if (retData && retData.sms_report_status_list.length == 0 && ++QueryReportTryCount < 5) {
                setTimeout(QuerySmsReport, 4000);
            } else if (retData && retData.sms_report_status_list.length > 0) {
                for (var i = 0; i < retData.sms_report_status_list.length; i++) {
                    var l = retData.sms_report_status_list[i];
                    var phoneNumber = l.submit_num;
                    if ("1" == l.status) {
                        recvSuccessNumber = recvSuccessNumber + phoneNumber + ";" + " ";
                    } else {
                        recvFailNumber = recvFailNumber + phoneNumber + ";" + " ";
                    }
                }

                var msg = "";
                if (recvSuccessNumber && "" != recvSuccessNumber) {
                    msg = msg + recvSuccessNumber.substr(0, recvSuccessNumber.length - 1) + " " + jQuery.i18n.prop("lMessageReportSuccessReceive");
                }
                if (recvFailNumber && "" != recvFailNumber) {
                    msg = msg + recvFailNumber.substr(0, recvFailNumber.length - 1) + " " + jQuery.i18n.prop("lMessageReportFailedReceive");
                }
                showMsgBox(jQuery.i18n.prop("sms_send"), msg);
            }
        });
    }, 7000);
}
// -------------------------------------------------------------objSmsSet-----------------------------------------------------------------
(function ($) {
    $.objSmsSet = function () {
        var that = this;
        var savedSMSInfo = {};
        // var DefaultcenterNumber = "";
        this.onLoad = function (flag) {
            if (flag) {
                that.displayControls();
                that.btnEvent();
                showHelp();
            }
            that.showData();
            setDlgStyle();
        };
        this.showData = function () {
            callJSON("sms_setting_info", function (json) {
                savedSMSInfo = {};
                savedSMSInfo.sms_center = json.sms_center;
                savedSMSInfo.save_location = json.save_location;
                savedSMSInfo.sms_over_cs = json.sms_over_cs;
                savedSMSInfo.status_report = json.status_report;
                savedSMSInfo.save_time = json.save_time;
                $("#txtCenterNumber").val(json.sms_center);
                $("#smsSaveLocSel").val(json.save_location);
                $("#smsSMScsModeSel").val(json.sms_over_cs);
                //DefaultcenterNumber = json.sms_center;
                if (json.status_report == "0") {
                    $("#SendReportDisabled").attr("checked", true);
                } else {
                    $("#SendReportEnabled").attr("checked", true);
                }
                var CPdisplay = json.sms_center_display;
                if (CPdisplay == "1") {
                    $("#centerPhone").hide();
                    $("#lt_help_sms2").hide();
                } else {
                    $("#centerPhone").show();
                    $("#lt_help_sms2").show();
                }
                var saveTime = json.save_time;
                switch (saveTime) {
                    case "143":
                        $("#validitySel").get(0).selectedIndex = 0;
                        break;
                    case "167":
                        $("#validitySel").get(0).selectedIndex = 1;
                        break;
                    case "173":
                        $("#validitySel").get(0).selectedIndex = 2;
                        break;
                    case "255":
                        $("#validitySel").get(0).selectedIndex = 3;
                        break;
                    default:
                        $("#validitySel").get(0).selectedIndex = 0;
                }
            });
        };
        this.btnEvent = function () {
            /*      $("#txtCenterNumber").unbind("change");
            $("#txtCenterNumber").bind("change",function(){
                var CurrentCenterNumber = $("#txtCenterNumber").val();
                if(CurrentCenterNumber!=DefaultcenterNumber){
					showBOX2(jQuery.i18n.prop("mSmsSet"),jQuery.i18n.prop("lSMSCenterModificationWarning"),jQuery.i18n.prop("lt_btnOK"),jQuery.i18n.prop("lt_btnCancel"),function() {
						ClosemBOX2();
						var sendval= $("#SendReportEnabled").is(":checked") ? "1" : "0";
						var validityval=$("#validitySel").val();
						var smssaveval=$("#smsSaveLocSel").val();
						var smsModeval=$("#smsSMScsModeSel").val();
						var jsonData={};
						jsonData.message_flag="SET_SMS_CENTER";
						jsonData.status_report=sendval;
						jsonData.sms_center=CurrentCenterNumber;               
						jsonData.save_time=validityval;
						jsonData.save_location=smssaveval;
						jsonData.sms_over_cs=smsModeval;
						showWait();
						setTimeout(function(){
						    postJSON("message_set",jsonData,function(data){
						        that.onLoad(false);
						    });
						},100); 
					},function() {
					    ClosemBOX2();
					});
                }
            });
 */

            $("#lt_SmsSet_btnSave").unbind("click");
            $("#lt_SmsSet_btnSave").bind("click", function () {
                var sendval = $("#SendReportEnabled").is(":checked") ? "1" : "0";
                var centernum = $("#txtCenterNumber").val();
                var validityval = $("#validitySel").val();
                var smssaveval = $("#smsSaveLocSel").val();
                var smsModeval = $("#smsSMScsModeSel").val();
                if (centernum == savedSMSInfo.sms_center && savedSMSInfo.save_location == smssaveval && savedSMSInfo.sms_over_cs == smsModeval && savedSMSInfo.status_report == sendval && savedSMSInfo.save_time == validityval) {
                    return false;
                }
                if (centernum == savedSMSInfo.sms_center) {
                    that.saveSmsSettings(sendval, centernum, validityval, smssaveval, smsModeval);
                } else if (that.validatePhoneNum(centernum)) {
                    showBOX2(
                        jQuery.i18n.prop("mSmsSet"),
                        jQuery.i18n.prop("lSMSCenterModificationWarning"),
                        jQuery.i18n.prop("lt_btnOK"),
                        jQuery.i18n.prop("lt_btnCancel"),
                        function () {
                            ClosemBOX2();
                            that.saveSmsSettings(sendval, centernum, validityval, smssaveval, smsModeval);
                        },
                        function () {
                            ClosemBOX2();
                        }
                    );
                }
            });
            $("#txtCenterNumber").focus(function () {
                $("#lt_sms_setting_error").hide();
            });
        };
        this.saveSmsSettings = function (sendval, centernum, validityval, smssaveval, smsModeval) {
            var jsonData = {};
            jsonData.message_flag = "SET_SMS_CENTER";
            jsonData.status_report = sendval;
            jsonData.sms_center = centernum;
            /* if(centernum!=DefaultcenterNumber){
					          jsonData.sms_center=centernum;
					}  */
            jsonData.save_time = validityval;
            jsonData.save_location = smssaveval;
            jsonData.sms_over_cs = smsModeval;
            showWait();
            setTimeout(function () {
                postJSON("message_set", jsonData, function (data) {
                    that.onLoad(false);
                });
            }, 100);
        };
        this.validatePhoneNum = function (mobilePhone) {
            if (mobilePhone == "" || mobilePhone.length > 15 || mobilePhone.length < 3) {
                $("#lt_sms_setting_error")
                    .show()
                    .text(jQuery.i18n.prop("dialog_message_sms_settings_title") + ":" + jQuery.i18n.prop("lphoneNumbertoolong"));
                return false;
            }
            if (!IsPhoneNumber(mobilePhone)) {
                $("#lt_sms_setting_error")
                    .show()
                    .text(jQuery.i18n.prop("dialog_message_sms_settings_title") + ":" + jQuery.i18n.prop("lMobilePhoneError"));
                return false;
            }
            return true;
        };
        this.displayControls = function () {
            $("#lt_SmsSet_stcTitle").html(jQuery.i18n.prop("mSmsSet"));
            $("#lt_SmsSet_stcDeliveryReport").html(jQuery.i18n.prop("lt_SmsSet_stcDeliveryReport"));
            $("#lt_SmsSet_stcSendReportEnabled").html(jQuery.i18n.prop("lt_SmsSet_stcSendReportEnabled"));
            $("#lt_SmsSet_stcSendReportDisabled").html(jQuery.i18n.prop("lt_SmsSet_stcSendReportDisabled"));
            $("#lt_SmsSet_stcSaveLoc").html(jQuery.i18n.prop("lt_SmsSet_stcSaveLoc"));
            $("#lt_SmsSet_stcSaveLocSimCard").html(jQuery.i18n.prop("lt_SmsSet_stcSaveLocSimCard"));
            $("#lt_SmsSet_stcSaveLocDevice").html(jQuery.i18n.prop("lt_SmsSet_stcSaveLocDevice"));
            $("#lt_SmsSet_stcSMSOverCSMode").html(jQuery.i18n.prop("lt_SmsSet_stcSMSOverCSMode"));
            $("#lt_SmsSet_stcPackageDomain").html(jQuery.i18n.prop("lt_SmsSet_stcPackageDomain"));
            $("#lt_SmsSet_stcCircuitSwitched").html(jQuery.i18n.prop("lt_SmsSet_stcCircuitSwitched"));
            $("#lt_SmsSet_stcValidity").html(jQuery.i18n.prop("lt_SmsSet_stcValidity"));
            $("#lt_SmsSet_stcTwelveHours").html(jQuery.i18n.prop("lt_SmsSet_stcTwelveHours"));
            $("#lt_SmsSet_stcOneDay").html(jQuery.i18n.prop("lt_SmsSet_stcOneDay"));
            $("#lt_SmsSet_stcOneWeek").html(jQuery.i18n.prop("lt_SmsSet_stcOneWeek"));
            $("#lt_SmsSet_stcLargest").html(jQuery.i18n.prop("lt_SmsSet_stcLargest"));
            $("#lt_SmsSet_stcCenterNumber").html(jQuery.i18n.prop("lt_SmsSet_stcCenterNumber"));
            $("#lt_SmsSet_btnSave").val(jQuery.i18n.prop("lt_SmsSet_btnSave"));
        };
        return this;
    };
})(jQuery);
// -------------------------------------------------------------objWifiSet-----------------------------------------------------------------
(function ($) {
    $.objWifiSet = function () {
        var that = this;
        var wifiPasswd;
        var g_net_mode;
        var g_rfband;
        this.onLoad = function (flag) {
            if (flag) {
                that.displayControls();
                that.wifiAdvanced();
                that.WifiOutoOff();
                that.btnEvent();
                showHelp();
            }
            that.showData();
            setDlgStyle();
        };
        this.showData = function () {
            callJSON("wlan_info", function (json) {
                var last_channel = parseInt(json.last_channel);
                var optionHTML = "";
                for (var i = 0; i <= last_channel; i++) {
                    if (i == 0) {
                        optionHTML += "<option id='dropdown_wireless_auto' value='0'>" + jQuery.i18n.prop("lt_wifiSet_optChannelAuto") + "</option>";
                    } else {
                        optionHTML += "<option id='dropdown_CH" + i + "' value='" + i + "'>" + jQuery.i18n.prop("lt_wifiSet_optCH" + i) + "</option>";
                    }
                }
                $("#wl_advanced_primary_channel_select").html(optionHTML);
                if (json.proto == "wifi") {
                    $("#wl_advanced_primary_channel_select").attr("disabled", true);
                    $("#wl_advanced_primary_channel_select").css("backgroundColor", "#ddd");
                } else {
                    $("#wl_advanced_primary_channel_select").attr("disabled", false);
                    $("#wl_advanced_primary_channel_select").css("backgroundColor", "#fff");
                }
                var wifiOption = "";
                var initial_max_clients = parseInt(json.initial_max_clients);
                for (var i = 1; i <= initial_max_clients; i++) {
                    wifiOption += "<option id ='dropdown_client_0" + i + "' value='" + i + "'>" + i + "</option>";
                }
                $("#wl_advanced_maximum_simultaneous_clients_select").html(wifiOption);
                $("#wl_advanced_80211_mode_select").val(json.net_mode);
                $("#wl_advanced_primary_channel_select").val(json.channel);
                $("#wl_advanced_maximum_simultaneous_clients_select").val(json.max_clients);
                $("#wl_advanced_ap_isolate_select").val(json.ap_isolate);
                var bandwidth = json.bandwidth;
                var bandwidth_acs = json.bandwidth_acs;
                if (bandwidth_acs == "1") {
                    $("#Bandwidthdrpdwn").val("0");
                } else {
                    $("#Bandwidthdrpdwn").val(bandwidth);
                }
                var wifiSleepTime = json.wifi_sleep_time;
                g_rfband = json.rf_band;
                if (wifiSleepTime == "0") {
                    $("#wl_advanced_autooff_function_checkbox").attr("checked", true);
                    $("#div_autoOff").hide();
                } else {
                    $("#wl_advanced_autooff_function_checkbox").attr("checked", false);
                    $("#wl_advanced_sleep_function_text").val(wifiSleepTime);
                    $("#div_autoOff").show();
                }
                if (json.wlan_enable == "1") {
                    $("#lt_radio_enable").prop("checked", true);
                    $("#div_advanced").show();
                } else {
                    $("#lt_radio_disable").prop("checked", true);
                    $("#div_advanced").hide();
                }
            });
        };
        this.wifiAdvanced = function () {
            $("#btn_advanced_settings_apply").unbind("click");
            $("#btn_advanced_settings_apply").bind("click", function () {
                var netMode = $("#wl_advanced_80211_mode_select").val();
                var maxClients = $("#wl_advanced_maximum_simultaneous_clients_select").val();
                var channelValue = $("#wl_advanced_primary_channel_select").val();
                var apIsolate = $("#wl_advanced_ap_isolate_select").val();
                var wlanEnable;
                var Bandwidthdrpdwn = $("#Bandwidthdrpdwn").val();
                if ($("#lt_radio_enable").is(":checked")) {
                    wlanEnable = "1";
                } else {
                    wlanEnable = "0";
                }
                var BandWidthAcs = "";
                var jsonData = {};
                if (Bandwidthdrpdwn == "0") {
                    BandWidthAcs = "1";
                    jsonData.wlan_enable = wlanEnable;
                    jsonData.rf_band = g_rfband;
                    jsonData.net_mode = netMode;
                    jsonData.channel = channelValue;
                    jsonData.max_clients = maxClients;
                    jsonData.ap_isolate = apIsolate;
                    jsonData.bandwidth_acs = BandWidthAcs;
                    // jsonData.sec_channel = SelAboveOrBelow;
                } else {
                    BandWidthAcs = "0";
                    jsonData.wlan_enable = wlanEnable;
                    jsonData.rf_band = g_rfband;
                    jsonData.net_mode = netMode;
                    jsonData.channel = channelValue;
                    jsonData.max_clients = maxClients;
                    jsonData.ap_isolate = apIsolate;
                    jsonData.bandwidth = Bandwidthdrpdwn;
                    jsonData.bandwidth_acs = BandWidthAcs;
                    // jsonData.sec_channel = SelAboveOrBelow;
                }
                showWait();
                setTimeout(function () {
                    postJSON("wlan_set", jsonData, function (data) {
                        if (data.result == "success") {
                            showMsgBox(jQuery.i18n.prop("h_wireless_advanced_settings_title"), jQuery.i18n.prop("dialog_message_wifi_settings_modify_wifi_param_success"));
                            that.onLoad(false);
                        } else {
                            showMsgBox(jQuery.i18n.prop("h_wireless_advanced_settings_title"), jQuery.i18n.prop("dialog_message_wifi_settings_modify_wifi_param_fail"));
                        }
                    });
                }, 100);
            });
        };
        this.WifiOutoOff = function () {
            $("#btn_autoOff_settings_apply").unbind("click");
            $("#btn_autoOff_settings_apply").bind("click", function () {
                $("#autoOff_error").hide();
                var sleepTime;
                if ($("#wl_advanced_autooff_function_checkbox").is(":checked")) {
                    sleepTime = "0";
                } else {
                    sleepTime = $("#wl_advanced_sleep_function_text").val();
                    if (!IsNumber(sleepTime)) {
                        $("#autoOff_error").html(jQuery.i18n.prop("lSleepTimeErrorLogs"));
                        $("#autoOff_error").show();
                        return;
                    }
                    if ((sleepTime > 60 || sleepTime < 10) && sleepTime != "0") {
                        $("#autoOff_error").html(jQuery.i18n.prop("lSleepTimeErrorLogs"));
                        $("#autoOff_error").show();
                        return;
                    }
                }

                var jsonData = {};
                jsonData.wifi_sleep_time = sleepTime;
                jsonData.wifi_sleep_action = "1";
                showWait();
                setTimeout(function () {
                    postJSON("wlan_set", jsonData, function (data) {
                        if (data.result == "success") {
                            showMsgBox(jQuery.i18n.prop("lWifiAutoOffFun"), jQuery.i18n.prop("dialog_message_wifi_settings_modify_wifi_param_success"));
                            that.onLoad(false);
                        } else {
                            showMsgBox(jQuery.i18n.prop("lWifiAutoOffFun"), jQuery.i18n.prop("dialog_message_wifi_settings_modify_wifi_param_fail"));
                        }
                    });
                }, 100);
            });
        };
        this.btnEvent = function () {
            $("#wl_advanced_autooff_function_checkbox").unbind("change");
            $("#wl_advanced_autooff_function_checkbox").bind("change", function () {
                if ($("#wl_advanced_autooff_function_checkbox").is(":checked")) {
                    $("#div_autoOff").hide();
                } else {
                    $("#div_autoOff").show();
                }
            });

            $("#lt_radio_enable").unbind("click");
            $("#lt_radio_enable").bind("click", function () {
                if ($("#lt_radio_enable").is(":checked")) {
                    $("#div_advanced").show();
                } else {
                    $("#div_advanced").hide();
                }
            });

            $("#lt_radio_disable").unbind("click");
            $("#lt_radio_disable").bind("click", function () {
                if ($("#lt_radio_enable").is(":checked")) {
                    $("#div_advanced").show();
                } else {
                    $("#div_advanced").hide();
                }
            });
        };
        this.displayControls = function () {
            $("#lt_wifiSet_title").html(jQuery.i18n.prop("mWifiInfoSet"));
            $("#lt_wifi_status").html(jQuery.i18n.prop("lMessageStatsStatus"));
            $("#span_status_enable").html(jQuery.i18n.prop("lt_optEnable"));
            $("#span_status_disable").html(jQuery.i18n.prop("lt_optDisable"));
            $("#td_wl_advanced_80211_mode").html(jQuery.i18n.prop("lt_wifiSet_wifiNetMode"));
            $("#td_wl_advanced_primary_channel").html(jQuery.i18n.prop("lt_wifiSet_wifiChannel"));
            $("#td_wl_advanced_maximum_simultaneous_clients").html(jQuery.i18n.prop("lMaxClients"));
            $("#td_wl_advanced_ap_isolate").html(jQuery.i18n.prop("lt_wifiSet_ApIsolateSwitch"));
            $("#drop_Close").html(jQuery.i18n.prop("DisabledApIsolateSwitch"));
            $("#drop_Open").html(jQuery.i18n.prop("EnableApIsolateSwitch"));
            $("#btn_advanced_settings_apply").val(jQuery.i18n.prop("lt_btnSave"));
            $("#lWifiAutoOffFun").html(jQuery.i18n.prop("lWifiAutoOffFun"));
            $("#span_advance_autoOff").html(jQuery.i18n.prop("lDisableWifiAutoOff"));
            $("#td_wl_advanced_wifi_sleep_function").html(jQuery.i18n.prop("lt_wifiSet_AutoOffWifiTimeout"));
            $("#span_sleep_text").html(jQuery.i18n.prop("sSleepTimeUint"));
            $("#btn_autoOff_settings_apply").val(jQuery.i18n.prop("lt_btnSave"));
            $("#dropdown_80211n").html(jQuery.i18n.prop("lt_wifiSet_opt80211n"));
            $("#dropdown_80211bg").html(jQuery.i18n.prop("lt_wifiSet_opt80211gb"));
            $("#dropdown_80211b_only").html(jQuery.i18n.prop("lt_wifiSet_opt80211b_only"));
            $("#dropdown_80211g_only").html(jQuery.i18n.prop("lt_wifiSet_opt80211g_only"));
            $("#lBandwidth").html(jQuery.i18n.prop("lBandwidth"));
            $("#lt_BandwidthAuto").html(jQuery.i18n.prop("lt_BandwidthAuto"));
            $("#lt_Bandwidth20").html(jQuery.i18n.prop("lt_Bandwidth20"));
            $("#lt_Bandwidth40").html(jQuery.i18n.prop("lt_Bandwidth40"));
        };
        return this;
    };
})(jQuery);

function isSSID(value) {
    var ssidmsg = /^[\u0000-\u007F]{1,32}$/;
    if (!ssidmsg.test(value)) {
        return false;
    }
    var MACRO_NOT_SUPPORT_CHAR_COMMA = 44; //,
    var MACRO_NOT_SUPPORT_CHAR_QUOTATION_MARK = 34; //"
    var MACRO_NOT_SUPPORT_CHAR_SEMICOLON = 59; //;
    var MACRO_NOT_SUPPORT_BACKSLASH_MARK = 92; //\
    var MACRO_NOT_SUPPORT_CHAR_39 = 39; //'
    var MACRO_NOT_SUPPORT_CHAR_60 = 60; //<
    var MACRO_NOT_SUPPORT_CHAR_62 = 62; //>
    var MACRO_NOT_SUPPORT_CHAR_63 = 63; //?
    var MACRO_NOT_SUPPORT_CHAR_94 = 94; //^
    var i;
    var char_i;
    var num_char_i;
    if (value.length > 32) {
        return false;
    }
    for (i = 0; i < value.length; i++) {
        char_i = value.charAt(i);
        num_char_i = char_i.charCodeAt();
        if (MACRO_NOT_SUPPORT_CHAR_COMMA == num_char_i || MACRO_NOT_SUPPORT_CHAR_QUOTATION_MARK == num_char_i || MACRO_NOT_SUPPORT_CHAR_SEMICOLON == num_char_i || MACRO_NOT_SUPPORT_BACKSLASH_MARK == num_char_i || MACRO_NOT_SUPPORT_CHAR_39 == num_char_i || MACRO_NOT_SUPPORT_CHAR_60 == num_char_i || MACRO_NOT_SUPPORT_CHAR_62 == num_char_i || MACRO_NOT_SUPPORT_CHAR_63 == num_char_i || MACRO_NOT_SUPPORT_CHAR_94 == num_char_i) {
            return false;
        }
    }
    return true;
}

//--------------------------------------------------------------objWifisecuritySet------------------------------------------------------------------------
(function ($) {
    $.objWifisecuritySet = function () {
        var that = this;
        var wlireDate = {};
        this.onLoad = function (flag) {
            if (flag) {
                that.displayControls();
                that.wifiQuickSetup();
                that.btnEvent();
                showHelp();
            }
            that.showData();
            setDlgStyle();
        };
        this.btnEvent = function () {
            $("#showPawBox").click(function () {
                if ($(this).prop("checked")) {
                    $("#wl_wifi_password").attr("type", "text");
                } else {
                    $("#wl_wifi_password").attr("type", "password");
                }
            });

            $("#wl_selectSecurityModeType").unbind("change");
            $("#wl_selectSecurityModeType").bind("change", function () {
                if ($("#wl_selectSecurityModeType").val() == "None") {
                    $("#td_wl_wifi_password").hide();
                    $("#wifi_password").hide();
                } else {
                    $("#td_wl_wifi_password").show();
                    $("#wifi_password").show();
                }

                var _strSecurityType;
                var security_mode = $("#wl_selectSecurityModeType").val();
                if (security_mode.length == 0 || security_mode == null || security_mode == "") {
                    _strSecurityType = "None";
                } else {
                    _strSecurityType = security_mode;
                }
                callJSON("wlan_security_info", function (json) {
                    var pass = "";
                    if (_strSecurityType != "None") {
                        if (json[_strSecurityType]) {
                            if (_strSecurityType == "WEP") {
                                pass = json[_strSecurityType].key1;
                            } else {
                                pass = json[_strSecurityType].key;
                            }
                            $("#wl_wifi_password").val(pass);
                        }
                    }
                });
            });
        };
        this.showData = function () {
            wlireDate = {};
            $("#wl_wifi_password").val("");
            callJSON("wlan_security_info", function (json) {
                wlireDate = json;
                g_net_mode = json.net_mode;
                var ssid_status = json.ssid_bcast;
                if (ssid_status == "1") {
                    $("#wl_advanced_status_radio_enable").prop("checked", true);
                } else {
                    $("#wl_advanced_status_radio_disable").prop("checked", true);
                }
                var strSSID = json.ssid;
                $("#wl_nnSSID").val(UniDecode(strSSID));
                var _strSecurityType;
                var security_mode = json.mode;
                if (security_mode.length == 0 || security_mode == null || security_mode == "") {
                    _strSecurityType = "None";
                    wifiPasswd = "";
                } else {
                    _strSecurityType = security_mode;
                }
                $("#wl_selectSecurityModeType").val(_strSecurityType);

                if (_strSecurityType != "None") {
                    if (_strSecurityType == "WEP") {
                        wifiPasswd = json[_strSecurityType].key1;
                    } else {
                        wifiPasswd = json[_strSecurityType].key;
                    }
                    $("#wl_wifi_password").val(wifiPasswd);
                    $("#td_wl_wifi_password").show();
                    $("#wifi_password").show();
                } else {
                    $("#td_wl_wifi_password").hide();
                    $("#wifi_password").hide();
                }
                //  if(json.lcd_show_wifi_pwd =="1"){
                //   $("#raido_display").prop("checked",true)
                //  }else{
                //     $("#raido_hide").prop("checked",true)
                //  }

                $("#qrcode").html("");
                var qrcode = new QRCode(document.getElementById("qrcode"), {
                    width: 100,
                    height: 100,
                });
                // var elText = "WIFI:T:"+_strSecurityType +";S:"+UniDecode(strSSID)+";P:"+wifiPasswd+";";
                var elText;
                if (_strSecurityType != "None") {
                    elText = "WIFI:T:WPA;S:" + UniDecode(strSSID) + ";P:" + wifiPasswd + ";";
                } else {
                    elText = "WIFI:S:" + UniDecode(strSSID) + ";";
                }
                qrcode.makeCode(elText);
            });
        };
        this.wifiQuickSetup = function () {
            $("#btn_wl_basic_settings_apply").unbind("click");
            $("#btn_wl_basic_settings_apply").bind("click", function () {
                if (that.checkQuickSetup()) {
                    var ssidName = $("#wl_nnSSID").val().trim();
                    var wifiPass = $("#wl_wifi_password").val();
                    var mode = $("#wl_selectSecurityModeType").val();
                    var ssid_status = $("#wl_advanced_status_radio_enable").is(":checked") ? "1" : "0";
                    // var lcd_psw_display =($("#raido_display").is(":checked")) ?"1" :"0";
                    var jsonData = {};
                    jsonData.ssid = UniEncode(ssidName);
                    jsonData.ssid_bcast = ssid_status;
                    jsonData.mode = mode;
                    // jsonData.lcd_show_wifi_pwd = lcd_psw_display;
                    if (mode != "None") {
                        var key = mode + ".";
                        if (mode == "WEP") {
                            key = key + "key1";
                        } else if (mode == "WAPI-PSK") {
                            key = key + "key";
                            jsonData[mode + ".key_type"] = wlireDate["WAPI-PSK"]["key_type"];
                        } else {
                            key = key + "key";
                        }
                        jsonData[key] = wifiPass;
                        jsonData[mode + ".mode"] = wlireDate[mode]["mode"];
                    }
                    showWait();
                    setTimeout(function () {
                        postJSON("wlan_security_set", jsonData, function (data) {
                            if (data.result == "success") {
                                showMsgBox(jQuery.i18n.prop("dialog_message_wifi_settings_title"), jQuery.i18n.prop("dialog_message_wifi_settings_modify_wifi_param_success"));
                                that.onLoad(false);
                            } else {
                                showMsgBox(jQuery.i18n.prop("dialog_message_wifi_settings_title"), jQuery.i18n.prop("dialog_message_wifi_settings_modify_wifi_param_fail"));
                            }
                        });
                    }, 100);
                }
            });
        };
        this.checkQuickSetup = function () {
            var ssid = $("#wl_nnSSID").val().trim();
            $("#QuickSetup_error").hide();
            if (ssid == "" || !ssid || ssid.length == 0) {
                $("#QuickSetup_error").html(jQuery.i18n.prop("lt_wifiSet_SsidIsEmpty"));
                $("#QuickSetup_error").show();
                return false;
            }
            if (!isSSID(ssid)) {
                $("#QuickSetup_error").html(jQuery.i18n.prop("input_ssid_error"));
                $("#QuickSetup_error").show();
                return false;
            }
            // if (ssid.includes(';')) {
            // 	$("#QuickSetup_error").html(jQuery.i18n.prop("input_ssidname_error"));
            // 	$("#QuickSetup_error").show();
            // 	return false;
            // }
            var tempPassword = $("#wl_wifi_password").val();
            var mode = $("#wl_selectSecurityModeType").val();
            if (mode != "None") {
                if (!tempPassword || tempPassword == "") {
                    $("#QuickSetup_error").html(jQuery.i18n.prop("lvpn_password_IsEmpty"));
                    $("#QuickSetup_error").show();
                    return false;
                }
                if (tempPassword.length < 8) {
                    $("#QuickSetup_error").html(jQuery.i18n.prop("lminLengthError8"));
                    $("#QuickSetup_error").show();
                    return false;
                }
                if (tempPassword.length > 32) {
                    $("#QuickSetup_error").html(jQuery.i18n.prop("lmaxLengthError32"));
                    $("#QuickSetup_error").show();
                    return false;
                }
                var re = /^[a-zA-Z0-9!@#%*&]{8,32}$/;
                if (!re.test(tempPassword)) {
                    $("#QuickSetup_error").html(jQuery.i18n.prop("lt_wifiset_WPA2PSKPasswdError2"));
                    $("#QuickSetup_error").show();
                    return false;
                }
                /*  if(IsChineseChar(tempPassword)){
		            $("#QuickSetup_error").html(jQuery.i18n.prop("lt_wifiset_WPA2PSKPasswdError2"));
		            $("#QuickSetup_error").show();
		            return false;
		        }
                var r = /[";\\]/;
				if(r.test(tempPassword)){
					$("#QuickSetup_error").html("alert error");
		            $("#QuickSetup_error").show();
					return ;
				} */
            }
            return true;
        };
        this.displayControls = function () {
            $("#lt_wifiSecuritySet_title").html(jQuery.i18n.prop("mWifisecuritySet"));
            $("#label_wl_advanced_status_radio_enable").html(jQuery.i18n.prop("lt_SSIDDisabledSwitch"));
            $("#sp_wl_advanced_status_radio_enable").html(jQuery.i18n.prop("lt_optEnableSwitch"));
            $("#sp_wl_advanced_status_radio_disable").html(jQuery.i18n.prop("lt_SmsSet_stcSendReportDisabled"));
            $("#td_wl_ssid_name").html(jQuery.i18n.prop("lt_wifiSet_SSID"));
            $("#td_wl_security_mode").html(jQuery.i18n.prop("lt_wifiSet_AuthType"));
            $("#wl_sec_mixed").html(jQuery.i18n.prop("lt_wifiSet_WPAWPA2"));
            $("#wl_sec_psk").html(jQuery.i18n.prop("lt_wifiSet_WPA2"));
            $("#wl_sec_open").html(jQuery.i18n.prop("lt_wifiSet_None"));
            $("#wl_wifi_showPassword").html(jQuery.i18n.prop("lt_wifiSet_showPaw"));
            $("#td_wl_wifi_password").html(jQuery.i18n.prop("lt_wifiSet_passwd"));
            $("#btn_wl_basic_settings_apply").val(jQuery.i18n.prop("lt_btnSave"));
            // $("#lt_screen_password").html(jQuery.i18n.prop("lt_screen_password"));
            // $("#lt_screen_password_display").html(jQuery.i18n.prop("lt_screen_password_display"));
            // $("#lt_screen_password_hide").html(jQuery.i18n.prop("lt_SmsSet_stcSendReportDisabled"));
        };

        return this;
    };
})(jQuery);
// -------------------------------------------------------------objWPS-----------------------------------------------------------------
var isWpsMatch = false;
var wpsItervalID;
var queryWPSStartTime = 0;
(function ($) {
    $.objWPS = function () {
        var that = this;
        this.onLoad = function (flag) {
            if (flag) {
                that.displayControls();
                that.btnEvent();
                showHelp();
            }
            if (wpsItervalID) {
                clearInterval(wpsItervalID);
            }
            callJSON("wlan_security_info", function (json) {
                if (json.ssid_bcast == "0") {
                    showMsgBox(jQuery.i18n.prop("lt_lWarning"), jQuery.i18n.prop("ssidBroadcast"));
                    $("#btn_wl_wps_register").attr("disabled", true);
                    $("#btn_wl_wps_register").addClass("disBtn");
                    $("#btn_wl_wps_pair").attr("disabled", true);
                    $("#btn_wl_wps_pair").addClass("disBtn");
                    $("#wl_wps_pin_text").attr("disabled", true);
                    $("#wl_wps_pin_text").css("backgroundColor", "#ddd");
                    return;
                }
            });
            that.showData();
            setDlgStyle();
        };
        this.showData = function () {
            if (isWpsMatch) {
                wpsItervalID = setInterval(function () {
                    that.QueryWpsStatus();
                }, 3000);
                queryWPSStartTime = new Date().getTime();
            } else {
                if (wpsItervalID) {
                    clearInterval(wpsItervalID);
                }
                $("#tr_wl_wps_matching").hide();
                $("#span_wl_wps_Status").text("");
                $("#span_wl_wps_errorPIN").text("");

                $("#btn_wl_wps_register").attr("disabled", false);
                $("#btn_wl_wps_register").removeClass("disBtn");
                $("#btn_wl_wps_pair").attr("disabled", false);
                $("#btn_wl_wps_pair").removeClass("disBtn");
                $("#wl_wps_pin_text").attr("disabled", false);
                $("#wl_wps_pin_text").css("backgroundColor", "#fff");
            }
        };
        this.QueryWpsStatus = function () {
            callJSON("wlan_wps_info", function (json) {
                var WPSStatus = json.wps_status;

                $("#btn_wl_wps_register").attr("disabled", false);
                $("#btn_wl_wps_register").removeClass("disBtn");
                $("#btn_wl_wps_pair").attr("disabled", false);
                $("#btn_wl_wps_pair").removeClass("disBtn");
                $("#wl_wps_pin_text").attr("disabled", false);
                $("#wl_wps_pin_text").css("backgroundColor", "#fff");
                $("#tr_wl_wps_matching").hide();
                isWpsMatch = false;
                if (WPSStatus == 0) {
                    $("#span_wl_wps_Status").text("");
                    showMsgBox(jQuery.i18n.prop("mWPS"), jQuery.i18n.prop("WPSwlanclosed"));
                } else if (WPSStatus == 1) {
                    $("#btn_wl_wps_register").attr("disabled", true);
                    $("#btn_wl_wps_register").addClass("disBtn");
                    $("#btn_wl_wps_pair").attr("disabled", true);
                    $("#btn_wl_wps_pair").addClass("disBtn");
                    $("#wl_wps_pin_text").attr("disabled", true);
                    $("#wl_wps_pin_text").css("backgroundColor", "#ddd");
                    $("#tr_wl_wps_matching").show();

                    isWpsMatch = true;
                } else if (WPSStatus == 2) {
                    $("#span_wl_wps_Status").text(jQuery.i18n.prop("lWpsMatchSuccess"));
                } else if (WPSStatus == 3) {
                    $("#span_wl_wps_Status").text(jQuery.i18n.prop("lWpsMatchFailed"));
                } else if (WPSStatus == 4) {
                    $("#span_wl_wps_Status").text(jQuery.i18n.prop("lWpsMatchInterrupt"));
                } else if (WPSStatus == 5) {
                    $("#span_wl_wps_Status").text(jQuery.i18n.prop("lWpsPinCheckFail"));
                } else {
                    $("#span_wl_wps_Status").text("Unkown Error.");
                }

                if (WPSStatus != 1) {
                    clearInterval(wpsItervalID);
                    return;
                }

                var currentTime = new Date().getTime();
                if (currentTime - queryWPSStartTime > 180000) {
                    that.closeWPSClient();
                }
            });
        };
        this.closeWPSClient = function () {
            clearInterval(wpsItervalID);
            isWpsMatch = false;

            $("#tr_wl_wps_matching").hide();
            $("#span_wl_wps_errorPIN").text("");
            $("#span_wl_wps_Status").text("");

            $("#btn_wl_wps_register").attr("disabled", false);
            $("#btn_wl_wps_register").removeClass("disBtn");
            $("#btn_wl_wps_pair").attr("disabled", false);
            $("#btn_wl_wps_pair").removeClass("disBtn");
            $("#wl_wps_pin_text").attr("disabled", false);
            $("#wl_wps_pin_text").css("backgroundColor", "#fff");
        };
        this.btnEvent = function () {
            $("#wl_wps_pin_text").unbind("input");
            $("#wl_wps_pin_text").bind("input", function () {
                $("#span_wl_wps_errorPIN").text("");
                $("#span_wl_wps_Status").text("");
                var client_pin = $("#wl_wps_pin_text").val();
                if ("-" == client_pin.substr(4, 1)) {
                    client_pin = client_pin.replace("-", "");
                }
                if (!(client_pin.length == 8 || client_pin.length == 4) || !Number(client_pin)) {
                    $("#span_wl_wps_errorPIN").text(jQuery.i18n.prop("lWPSPinError"));
                    isWpsMatch = false;

                    $("#btn_wl_wps_register").attr("disabled", true);
                    $("#btn_wl_wps_register").addClass("disBtn");
                } else {
                    $("#btn_wl_wps_register").attr("disabled", false);
                    $("#btn_wl_wps_register").removeClass("disBtn");
                }
            });

            $("#btn_wl_wps_register").unbind("click");
            $("#btn_wl_wps_register").bind("click", function () {
                $("#tr_wl_wps_matching").hide();
                $("#span_wl_wps_Status").text("");
                $("#span_wl_wps_errorPIN").text("");

                var client_pin = $("#wl_wps_pin_text").val();
                if ("-" == client_pin.substr(4, 1)) {
                    client_pin = client_pin.replace("-", "");
                }

                if ((client_pin.length == 8 || client_pin.length == 4) && Number(client_pin)) {
                    var jsonData = {};
                    jsonData.connect_method = "2";
                    jsonData.wps_pin = client_pin;
                    showWait();
                    setTimeout(function () {
                        postJSON("wlan_security_set", jsonData, function () {
                            showWait();
                            setTimeout(function () {
                                isWpsMatch = false;
                                that.onLoad(false);
                                clearInterval(wpsItervalID);
                            }, 100);
                        });
                        setTimeout(function () {
                            that.QueryWpsStatusEx();
                        }, 3000);
                    }, 100);
                } else {
                    $("#span_wl_wps_errorPIN").text(jQuery.i18n.prop("lWPSPinError"));
                    isWpsMatch = false;
                }
                clearInterval(wpsItervalID);
            });

            $("#btn_wl_wps_pair").unbind("click");
            $("#btn_wl_wps_pair").bind("click", function () {
                $("#span_wl_wps_Status").text("");
                var jsonData = {};
                jsonData.connect_method = "1";
                showWait();
                setTimeout(function () {
                    postJSON("wlan_security_set", jsonData, function () {
                        showWait();
                        setTimeout(function () {
                            closeWait();
                        }, 3000);
                        isWpsMatch = true;
                        that.onLoad(false);
                    });
                }, 100);
            });

            $("#btn_wl_wps_cancel_matching").unbind("click");
            $("#btn_wl_wps_cancel_matching").bind("click", function () {
                var jsonData = {};
                jsonData.connect_method = "3";
                showWait();
                setTimeout(function () {
                    postJSON("wlan_security_set", jsonData, function () {
                        isWpsMatch = false;
                        if (wpsItervalID) {
                            clearInterval(wpsItervalID);
                        }
                        that.onLoad(false);
                    });
                    $("#tr_wl_wps_matching").hide();
                }, 100);
            });
        };
        this.QueryWpsStatusEx = function () {
            callJSON("wlan_wps_info", function (json) {
                var WPSStatus = parseInt(json.wps_status);
                if (WPSStatus == 1) {
                    setTimeout(function () {
                        that.QueryWpsStatusEx();
                    }, 4000);
                } else if (WPSStatus == 2) {
                    closeWait();
                    showMsgBox(jQuery.i18n.prop("mWPS"), jQuery.i18n.prop("lWpsMatchSuccess"));
                } else if (WPSStatus == 3) {
                    closeWait();
                    showMsgBox(jQuery.i18n.prop("mWPS"), jQuery.i18n.prop("lWpsMatchFailed"));
                } else if (WPSStatus == 4) {
                    closeWait();
                    showMsgBox(jQuery.i18n.prop("mWPS"), jQuery.i18n.prop("lWpsMatchInterrupt"));
                } else if (WPSStatus == 5) {
                    closeWait();
                    showMsgBox(jQuery.i18n.prop("mWPS"), jQuery.i18n.prop("lWpsPinCheckFail"));
                } else if (WPSStatus == 0) {
                    closeWait();
                    showMsgBox(jQuery.i18n.prop("mWPS"), jQuery.i18n.prop("WPSwlanclosed"));
                }
            });
        };
        this.displayControls = function () {
            $("#h_wireless_wps_settings_title").html(jQuery.i18n.prop("h1AddWPSClient"));
            $("#td_wl_wps_choose_method").html(jQuery.i18n.prop("lWPStext"));
            $("#td_wl_wps_pair_method").html(jQuery.i18n.prop("spanWPSPushButton"));
            $("#btn_wl_wps_pair").val(jQuery.i18n.prop("btnPush"));
            $("#td_wl_wps_pin_method").html(jQuery.i18n.prop("spanEnterPin"));
            $("#btn_wl_wps_register").val(jQuery.i18n.prop("btnRegister"));
            $("#td_wl_wps_matching").html(jQuery.i18n.prop("lWpsMatchPro"));
            $("#btn_wl_wps_cancel_matching").val(jQuery.i18n.prop("lt_btnCancel"));
        };
        return this;
    };
})(jQuery);
// -------------------------------------------------------------objWifiMACFilter-----------------------------------------------------------------
(function ($) {
    $.objWifiMACFilter = function () {
        var that = this;
        var allchecked = false;
        var g_MACFilter_allowlist = "";
        var g_MACFilter_denylist = "";
        this.onLoad = function (flag) {
            if (flag) {
                that.displayControls();
                that.btnEvent();
                showHelp();
            }
            that.showData();
            setDlgStyle();
        };
        this.showData = function () {
            g_MACFilter_allow = "";
            g_MACFilter_deny = "";
            callJSON("wlan_mac_filters_info", function (json) {
                if (json.enable == "0") {
                    $("#radio_MacFilter_disabled").attr("checked", true);
                    $("#div_AwDn").hide();
                    $("#div_MacFilterList").hide();
                } else {
                    $("#div_AwDn").show();
                    $("#div_MacFilterList").show();
                    $("#radio_MacFilter_enabled").attr("checked", true);
                    if (json.mode == "1") {
                        $("#radio_MacFilter_allow").attr("checked", true);
                        $("#lMacFilterListLabel").html(jQuery.i18n.prop("lt_macFilter_AllowMacAddrList"));
                    } else {
                        $("#radio_MacFilter_deny").attr("checked", true);
                        $("#lMacFilterListLabel").html(jQuery.i18n.prop("lt_macFilter_DenyMacAddrList"));
                    }
                }
                var macHTML = "";
                if (json.mode == "1") {
                    g_MACFilter_allowlist = json.allow_list;
                    for (var i = 0; i < json.allow_list.length; i++) {
                        macHTML += "<tr><td>" + json.allow_list[i].mac + '</td><td><input class="mac_del" name="' + i + "*&*" + json.allow_list[i].mac + "\" type='checkbox'></td></tr>";
                    }
                } else {
                    g_MACFilter_denylist = json.deny_list;
                    for (var j = 0; j < json.deny_list.length; j++) {
                        macHTML += "<tr><td>" + json.deny_list[j].mac + '</td><td><input class="mac_del" name="' + j + "*&*" + json.deny_list[j].mac + "\" type='checkbox'></td></tr>";
                    }
                }
                if (macHTML == "") {
                    macHTML = '<tr><td colspan="2">' + jQuery.i18n.prop("tableNoData") + "</td></tr>";
                    $("#DeleteAllIpEntry").attr("disabled", true);
                    $("#DeleteAllIpEntry").attr("checked", false);
                } else {
                    $("#DeleteAllIpEntry").attr("disabled", false);
                    $("#DeleteAllIpEntry").attr("checked", false);
                }
                $("#lt_macFilter_btnDeleteMacFilter").hide();
                $("#tbodyMacAddrList").html(macHTML);
                that.bindChecked();
            });
        };
        this.showAloowDenyList = function () {
            callJSON("wlan_mac_filters_info", function (json) {
                if ($("#radio_MacFilter_allow").is(":checked")) {
                    $("#radio_MacFilter_allow").attr("checked", true);
                    $("#lMacFilterListLabel").html(jQuery.i18n.prop("lt_macFilter_AllowMacAddrList"));
                } else {
                    $("#radio_MacFilter_deny").attr("checked", true);
                    $("#lMacFilterListLabel").html(jQuery.i18n.prop("lt_macFilter_DenyMacAddrList"));
                }
                var macHTML = "";
                if ($("#radio_MacFilter_allow").is(":checked")) {
                    for (var i = 0; i < json.allow_list.length; i++) {
                        macHTML += "<tr><td>" + json.allow_list[i].mac + '</td><td><input class="mac_del" name="' + json.allow_list[i].index + "*&*" + json.allow_list[i].mac + "\" type='checkbox'></td></tr>";
                    }
                } else {
                    for (var j = 0; j < json.deny_list.length; j++) {
                        macHTML += "<tr><td>" + json.deny_list[j].mac + '</td><td><input class="mac_del" name="' + json.deny_list[j].index + "*&*" + json.deny_list[j].mac + "\" type='checkbox'></td></tr>";
                    }
                }
                if (macHTML == "") {
                    macHTML = '<tr><td colspan="2">' + jQuery.i18n.prop("tableNoData") + "</td></tr>";
                    $("#DeleteAllIpEntry").attr("disabled", true);
                    $("#DeleteAllIpEntry").attr("checked", false);
                } else {
                    $("#DeleteAllIpEntry").attr("disabled", false);
                    $("#DeleteAllIpEntry").attr("checked", false);
                }
                $("#lt_macFilter_btnDeleteMacFilter").hide();
                $("#tbodyMacAddrList").html(macHTML);
                that.bindChecked();
            });
        };
        this.btnEvent = function () {
            $("#addMacBoxclose").unbind("click");
            $("#addMacBoxclose").bind("click", function () {
                $("#divMACFilterDlg").hide();
            });

            $("#lt_btnCancel").unbind("click");
            $("#lt_btnCancel").bind("click", function () {
                $("#divMACFilterDlg").hide();
            });

            $("#btn_addMac").unbind("click");
            $("#btn_addMac").bind("click", function () {
                $("#divMACFilterDlg input[type='text']").val("");
                $("#divMACFilterDlg").show();
                setDlgStyle();
                $("#lt_macFilter_MacError").hide();
                setAddBoxHeigth("divMACFilterDlg");
            });

            $("#radio_MacFilter_enabled").unbind("click");
            $("#radio_MacFilter_enabled").bind("click", function () {
                if ($("#radio_MacFilter_enabled").is(":checked")) {
                    $("#div_AwDn").show();
                    $("#div_MacFilterList").show();
                    that.showAloowDenyList();
                } else {
                    $("#div_AwDn").hide();
                    $("#div_MacFilterList").hide();
                }
            });

            $("#radio_MacFilter_disabled").unbind("click");
            $("#radio_MacFilter_disabled").bind("click", function () {
                if ($("#radio_MacFilter_enabled").is(":checked")) {
                    $("#div_AwDn").show();
                    $("#div_MacFilterList").show();
                    that.showAloowDenyList();
                } else {
                    $("#div_AwDn").hide();
                    $("#div_MacFilterList").hide();
                }
            });

            $("#radio_MacFilter_allow").unbind("click");
            $("#radio_MacFilter_allow").bind("click", function () {
                if ($("#radio_MacFilter_allow").is(":checked")) {
                    $("#lMacFilterListLabel").html(jQuery.i18n.prop("lt_macFilter_AllowMacAddrList"));
                    that.showAloowDenyList();
                } else {
                    $("#lMacFilterListLabel").html(jQuery.i18n.prop("lt_macFilter_DenyMacAddrList"));
                    that.showAloowDenyList();
                }
            });

            $("#radio_MacFilter_deny").unbind("click");
            $("#radio_MacFilter_deny").bind("click", function () {
                if ($("#radio_MacFilter_allow").is(":checked")) {
                    $("#lMacFilterListLabel").html(jQuery.i18n.prop("lt_macFilter_AllowMacAddrList"));
                    that.showAloowDenyList();
                } else {
                    $("#lMacFilterListLabel").html(jQuery.i18n.prop("lt_macFilter_DenyMacAddrList"));
                    that.showAloowDenyList();
                }
            });

            $("#lt_macFilter_btnDeleteMacFilter").unbind("click");
            $("#lt_macFilter_btnDeleteMacFilter").bind("click", function () {
                that.delMac();
            });

            $("#lt_btnSave").unbind("click");
            $("#lt_btnSave").bind("click", function () {
                if ($("#radio_MacFilter_allow").is(":checked")) {
                    if (g_MACFilter_allowlist.length >= 16) {
                        showMsgBox(jQuery.i18n.prop("mWifiMACFilter"), jQuery.i18n.prop("lt_macFilter_AllowMacAddrList_limit"));
                        return;
                    }
                } else {
                    if (g_MACFilter_denylist.length >= 16) {
                        showMsgBox(jQuery.i18n.prop("mWifiMACFilter"), jQuery.i18n.prop("lt_macFilter_DenyMacAddrList_limit"));
                        return;
                    }
                }
                that.addMac();
            });

            $("#btn_macFilter_apply").unbind("click");
            $("#btn_macFilter_apply").bind("click", function () {
                var jsonData = {};
                if ($("#radio_MacFilter_enabled").is(":checked")) {
                    jsonData.enable = "1";
                } else {
                    jsonData.enable = "0";
                }
                if ($("#radio_MacFilter_allow").is(":checked")) {
                    jsonData.mode = "1";
                } else {
                    jsonData.mode = "2";
                }
                showWait();
                setTimeout(function () {
                    postJSON("wlan_mac_filters_set", jsonData, function (data) {
                        if (data.result != "success") {
                            showMsgBox(jQuery.i18n.prop("mWifiMACFilter"), jQuery.i18n.prop("ls_save_time_failure"));
                        } else {
                            that.onLoad(false);
                        }
                    });
                }, 100);
            });
        };
        this.addMac = function () {
            if (that.checkMac()) {
                showWait();
                setTimeout(function () {
                    var mac_val = $("#txtMac1").val() + ":" + $("#txtMac2").val() + ":" + $("#txtMac3").val() + ":" + $("#txtMac4").val() + ":" + $("#txtMac5").val() + ":" + $("#txtMac6").val();
                    var jsonData = {};
                    if ($("#radio_MacFilter_enabled").is(":checked")) {
                        jsonData.enable = "1";
                    } else {
                        jsonData.enable = "0";
                    }
                    if ($("#radio_MacFilter_allow").is(":checked")) {
                        jsonData.mode = "1";
                        jsonData.allow_list = [{}];
                        jsonData.allow_list[0].mac = mac_val;
                    } else {
                        jsonData.mode = "2";
                        jsonData.deny_list = [{}];
                        jsonData.deny_list[0].mac = mac_val;
                    }
                    postJSON("wlan_mac_filters_set", jsonData, function (data) {
                        if (data.result != "success") {
                            showMsgBox(jQuery.i18n.prop("mWifiMACFilter"), jQuery.i18n.prop("dialog_message_mac_filter_add_fail"));
                        } else {
                            $("#divMACFilterDlg").hide();
                            that.onLoad(false);
                        }
                    });
                }, 100);
            }
        };
        this.delMac = function () {
            var delList = "";
            $("#tbodyMacAddrList .mac_del").each(function (index) {
                if ($(this).is(":checked")) {
                    var del = $(this).attr("name").split("*&*");
                    delList += parseInt(del[0]) + ",";
                }
            });
            var jsonData = {};
            if ($("#radio_MacFilter_enabled").is(":checked")) {
                jsonData.enable = "1";
            } else {
                jsonData.enable = "0";
            }
            if ($("#radio_MacFilter_allow").is(":checked")) {
                jsonData.mode = "1";
                jsonData.allow_delete_index = delList;
            } else {
                jsonData.mode = "2";
                jsonData.deny_delete_index = delList;
            }
            showWait();
            setTimeout(function () {
                postJSON("wlan_mac_filters_set", jsonData, function (data) {
                    if (data.result != "success") {
                        showMsgBox(jQuery.i18n.prop("mWifiMACFilter"), jQuery.i18n.prop("dialog_message_mac_filter_delete_fail"));
                    } else {
                        that.onLoad(false);
                    }
                });
            }, 100);
        };
        this.checkMac = function () {
            if ($("#txtMac1").val() == "" || $("#txtMac2").val() == "" || $("#txtMac3").val() == "" || $("#txtMac4").val() == "" || $("#txtMac5").val() == "" || $("#txtMac6").val() == "") {
                $("#lt_macFilter_MacError").html(jQuery.i18n.prop("MAC_ADDR_IS_EMPTY"));
                $("#lt_macFilter_MacError").show();
                return false;
            }
            var mac = $("#txtMac1").val() + ":" + $("#txtMac2").val() + ":" + $("#txtMac3").val() + ":" + $("#txtMac4").val() + ":" + $("#txtMac5").val() + ":" + $("#txtMac6").val();
            // var regex = /^([0-9a-f]{2}([:-]|$)){6}$|([0-9a-f]{4}([.]|$)){3}$/i;
            if (!IsMACAddr(mac)) {
                $("#lt_macFilter_MacError").html(jQuery.i18n.prop("lt_MacAddrFormatError"));
                $("#lt_macFilter_MacError").show();
                return false;
            }
            if ($("#radio_MacFilter_allow").is(":checked")) {
                for (var i = 0; i < g_MACFilter_allowlist.length; i++) {
                    if (g_MACFilter_allowlist[i].mac == mac) {
                        $("#lt_macFilter_MacError").html(jQuery.i18n.prop("MAC_ADDR_EXIST"));
                        $("#lt_macFilter_MacError").show();
                        return false;
                    }
                }
            } else {
                for (var j = 0; j < g_MACFilter_denylist.length; j++) {
                    if (g_MACFilter_denylist[j].mac == mac) {
                        $("#lt_macFilter_MacError").html(jQuery.i18n.prop("MAC_ADDR_EXIST"));
                        $("#lt_macFilter_MacError").show();
                        return false;
                    }
                }
            }

            return true;
        };
        this.bindChecked = function () {
            $("#DeleteAllIpEntry").unbind("click");
            $("#DeleteAllIpEntry").bind("click", function () {
                if ($("#DeleteAllIpEntry").is(":checked")) {
                    if ($("#tbodyMacAddrList").html() != "") {
                        $("#tbodyMacAddrList .mac_del").prop("checked", true);
                        $("#lt_macFilter_btnDeleteMacFilter").show();
                    }
                } else {
                    $("#tbodyMacAddrList .mac_del").prop("checked", false);
                    $("#lt_macFilter_btnDeleteMacFilter").hide();
                }
            });
            $("#tbodyMacAddrList .mac_del").each(function () {
                $(this).unbind("click");
                $(this).bind("click", function () {
                    allchecked = true;
                    $("#lt_macFilter_btnDeleteMacFilter").hide();
                    $("#tbodyMacAddrList .mac_del").each(function (index) {
                        if ($(this).is(":checked")) {
                            $("#lt_macFilter_btnDeleteMacFilter").show();
                        } else {
                            allchecked = false;
                        }
                    });
                    if (allchecked) {
                        $("#DeleteAllIpEntry").prop("checked", true);
                    } else {
                        $("#DeleteAllIpEntry").prop("checked", false);
                    }
                });
            });
        };
        this.displayControls = function () {
            $("#lt_macFilter_title").html(jQuery.i18n.prop("mWifiMACFilter"));
            $("#lMF").html(jQuery.i18n.prop("lt_macFilter_title"));
            $("#span_MacFilter_enabled").html(jQuery.i18n.prop("lt_optEnableSwitch"));
            $("#span_MacFilter_disabled").html(jQuery.i18n.prop("lt_SmsSet_stcSendReportDisabled"));
            $("#lMS").html(jQuery.i18n.prop("lt_macFilter_MacFilterSwitch"));
            $("#span_MacFilter_allow").html(jQuery.i18n.prop("lt_macFilter_AllowdMode"));
            $("#span_MacFilter_deny").html(jQuery.i18n.prop("lt_macFilter_DenyMode"));
            $("#btn_macFilter_apply").val(jQuery.i18n.prop("lt_btnSave"));
            $("#lt_macFilter_clientMacAddrList").html(jQuery.i18n.prop("lt_macFilter_clientMacAddrList"));
            $("#lt_macFilter_AddMACFilterTitle").html(jQuery.i18n.prop("lt_macFilter_AddMACFilterTitle"));
            $("#lt_btnSave").val(jQuery.i18n.prop("lt_btnSave"));
            $("#lt_btnCancel").val(jQuery.i18n.prop("lt_btnCancel"));
            $("#btn_addMac").val(jQuery.i18n.prop("lt_macFilter_btnAddMacFilter"));
            $("#lt_macFilter_btnDeleteMacFilter").val(jQuery.i18n.prop("lt_macFilter_btnDeleteMacFilter"));
        };
        return this;
    };
})(jQuery);

// -------------------------------------------------------------objCustomFirewallRules-----------------------------------------------------------------
var _arrayTableDataCustomFW = [];
var g_FirewallRulesNumber = 0;
(function ($) {
    $.objCustomFirewallRules = function () {
        var that = this;
        var mtu_value;
        this.onLoad = function (flag) {
            if (flag) {
                that.displayControls();
                that.btnEvent();
                showHelp();
            }
            that.showData();
            setDlgStyle();
        };
        this.showData = function () {
            g_FirewallRulesNumber = 0;
            callJSON("custom_fw_info", function (json) {
                g_FirewallRulesNumber = json.custom_rules_list.length;
                _arrayTableDataCustomFW = [];
                filer_mode = json.custom_rules_mode;
                for (var i = 0; i < json.custom_rules_list.length; i++) {
                    var l = json.custom_rules_list[i];
                    ruleName = l.rule_name;
                    ruleName = decodeURIComponent(ruleName);
                    enabled = l.enabled;
                    srcIPAddress = l.src_ip;
                    srcPort = l.src_port;
                    dstIPAddress = l.dst_ip;
                    dstPort = l.dst_port;
                    protocol = l.proto;
                    _arrayTableDataCustomFW.push([l.index, ruleName, enabled, srcIPAddress, srcPort, dstIPAddress, dstPort, protocol]);
                }
                that.loadTableData(_arrayTableDataCustomFW);
            });
        };
        this.loadTableData = function (arrayTableData) {
            var bodyHTML = "";

            if (arrayTableData.length === 0) {
                bodyHTML = '<tr><td colspan="8">' + jQuery.i18n.prop("tableNoData") + "</td></tr>";
            } else {
                for (var i = 0; i < arrayTableData.length; i++) {
                    var l = arrayTableData[i];
                    var index = l[0];
                    var ruleName = l[1];
                    var enabled = l[2];
                    if (enabled == "1") {
                        enabled = jQuery.i18n.prop("lt_optEnableSwitch");
                    } else {
                        enabled = jQuery.i18n.prop("lt_optDisabledSwitch");
                    }
                    var srcIP = l[3] == "NA" || l[3] == "" ? "N/A" : l[3];
                    var srcport = l[4] == "NA" || l[4] == "" ? "N/A" : l[4];
                    var dstIP = l[5] == "NA" || l[5] == "" ? "N/A" : l[5];
                    var dstport = l[6] == "NA" || l[6] == "" ? "N/A" : l[6];
                    var protocol = l[7];
                    bodyHTML += '<tr><td name="' + ruleName + '"  onclick="customFWRuleClicked(this)" style="color:#05bda1;cursor:pointer;">' + ruleName + "</td><td>" + enabled + "</td><td>" + srcIP + "</td><td>" + srcport + "</td><td>" + dstIP + "</td><td>" + dstport + "</td><td>" + protocol + '</td><td><sapn name="' + ruleName + '" onclick="deleteFirewallRule(this)" class="delete_spanBtn">&times;</span></td></tr>';
                }
            }
            $("#firewallFulesBody").html(bodyHTML);
        };
        this.btnEvent = function () {
            $("#addFirewallRuleclose").unbind("click");
            $("#addFirewallRuleclose").bind("click", function () {
                $("#divFirewallRuleDlg").hide();
            });

            $("#lt_btnCancel").unbind("click");
            $("#lt_btnCancel").bind("click", function () {
                $("#divFirewallRuleDlg").hide();
            });

            $("#btn_add_firewallRule").unbind("click");
            $("#btn_add_firewallRule").bind("click", function () {
                if (g_FirewallRulesNumber >= 8) {
                    showMsgBox(jQuery.i18n.prop("mCustomFirewallRules"), jQuery.i18n.prop("OutFirewallRulesRange"));
                    return;
                }
                $("input[type='text']").val("");
                $("#divFirewallRuleDlg").show();
                setAddBoxHeigth("divFirewallRuleDlg");
                $("#txtRulename").attr("disabled", false);
                $("#txtRulename").removeClass("dhcp_disabled");
                $("#firewallRule_error").hide();
                $("#lt_btnAdd").show();
                $("#lt_btnSave").hide();
            });

            $("#txtRulename").unbind("input");
            $("#txtRulename").bind("input", function () {
                that.checkRuleName();
            });

            $("#lt_btnSave").unbind("click");
            $("#lt_btnSave").bind("click", function () {
                if (that.checkIPPort()) {
                    var jsonData = {};
                    jsonData.custom_rules_list = [];
                    var listDetail = {};
                    var ruleName = encodeURIComponent($("#txtRulename").val());
                    var enabled = $("#radio_enabled").is(":checked") ? "1" : "0";
                    var src_ip = $("#sourceIP1").val() + "." + $("#sourceIP2").val() + "." + $("#sourceIP3").val() + "." + $("#sourceIP4").val();
                    var src_netmask = $("#sourceIP5").val();
                    var src_port = $("#sourcePort1").val() + ":" + $("#sourcePort2").val();
                    var dst_ip = $("#destinationIP1").val() + "." + $("#destinationIP2").val() + "." + $("#destinationIP3").val() + "." + $("#destinationIP4").val();
                    var dst_netmask = $("#destinationIP5").val();
                    var dst_port = $("#destinationPort1").val() + ":" + $("#destinationPort2").val();
                    var protocol = $("#fwdSelect").val();
                    listDetail.index = $("#txtRulename").attr("name");
                    listDetail.rule_name = $("#txtRulename").val();
                    listDetail.enabled = enabled;

                    if (src_ip != "...") {
                        if (src_netmask.length > 0) src_ip = src_ip + "/" + src_netmask;
                        listDetail.src_ip = src_ip;
                    } else {
                        listDetail.src_ip = "NA";
                    }
                    listDetail.src_port = src_port != ":" ? src_port : "NA";

                    if (dst_ip != "...") {
                        if (dst_netmask.length > 0) {
                            dst_ip = dst_ip + "/" + dst_netmask;
                        }
                        listDetail.dst_ip = dst_ip;
                    } else {
                        listDetail.dst_ip = "NA";
                    }
                    listDetail.dst_port = dst_port != ":" ? dst_port : "NA";
                    listDetail.proto = protocol;
                    jsonData.custom_rules_list.push(listDetail);
                    showWait();
                    setTimeout(function () {
                        postJSON("custom_fw_set", jsonData, function (data) {
                            if (data.result != "success") {
                                showMsgBox(jQuery.i18n.prop("mCustomFirewallRules"), jQuery.i18n.prop("ls_save_time_failure"));
                            } else {
                                that.onLoad(false);
                                $("#divFirewallRuleDlg").hide();
                            }
                        });
                    }, 100);
                }
            });
            $("#txtRulename,#sourceIP1,#sourceIP2,#sourceIP3,#sourceIP4,#sourceIP5,#sourcePort1,#sourcePort2,#destinationIP1,#destinationIP2,#destinationIP3,#destinationIP4,#destinationIP5,#destinationPort1,#destinationPort2").focus(function () {
                $("#firewallRule_error").hide();
            });
            $("#lt_btnAdd").unbind("click");
            $("#lt_btnAdd").bind("click", function () {
                if (that.checkRuleName() && that.checkIPPort()) {
                    var jsonData = {};
                    jsonData.custom_rules_list = [];
                    var listDetail = {};
                    var ruleName = encodeURIComponent($("#txtRulename").val());
                    var enabled = $("#radio_enabled").is(":checked") ? "1" : "0";
                    var src_ip = $("#sourceIP1").val() + "." + $("#sourceIP2").val() + "." + $("#sourceIP3").val() + "." + $("#sourceIP4").val();
                    var src_netmask = $("#sourceIP5").val();
                    var src_port = $("#sourcePort1").val() + ":" + $("#sourcePort2").val();
                    var dst_ip = $("#destinationIP1").val() + "." + $("#destinationIP2").val() + "." + $("#destinationIP3").val() + "." + $("#destinationIP4").val();
                    var dst_netmask = $("#destinationIP5").val();
                    var dst_port = $("#destinationPort1").val() + ":" + $("#destinationPort2").val();
                    var protocol = $("#fwdSelect").val();
                    listDetail.index = _arrayTableDataCustomFW.length;
                    listDetail.rule_name = $("#txtRulename").val();
                    listDetail.enabled = enabled;

                    if (src_ip != "...") {
                        if (src_netmask.length > 0) src_ip = src_ip + "/" + src_netmask;
                        listDetail.src_ip = src_ip;
                    } else {
                        listDetail.src_ip = "NA";
                    }
                    listDetail.src_port = src_port != ":" ? src_port : "NA";

                    if (dst_ip != "...") {
                        if (dst_netmask.length > 0) {
                            dst_ip = dst_ip + "/" + dst_netmask;
                        }
                        listDetail.dst_ip = dst_ip;
                    } else {
                        listDetail.dst_ip = "NA";
                    }
                    listDetail.dst_port = dst_port != ":" ? dst_port : "NA";
                    listDetail.proto = protocol;
                    jsonData.custom_rules_list.push(listDetail);
                    showWait();
                    setTimeout(function () {
                        postJSON("custom_fw_set", jsonData, function (data) {
                            if (data.result != "success") {
                                showMsgBox(jQuery.i18n.prop("mCustomFirewallRules"), jQuery.i18n.prop("ls_save_time_failure"));
                            } else {
                                that.onLoad(false);
                                $("#divFirewallRuleDlg").hide();
                            }
                        });
                    }, 100);
                }
            });
        };
        this.isCustomRuleNameExist = function (name) {
            for (var i = 0; i < _arrayTableDataCustomFW.length; i++) {
                if (name == _arrayTableDataCustomFW[i][1]) {
                    return true;
                }
            }
            return false;
        };
        this.checkRuleName = function () {
            $("#firewallRule_error").hide();
            var ruleName = $("#txtRulename").val();
            if (ruleName == "") {
                $("#firewallRule_error").show();
                $("#firewallRule_error").html(jQuery.i18n.prop("lEmptyName"));
                return false;
            }
            if (ruleName.length > 15 || ruleName.length < 3) {
                $("#firewallRule_error").show();
                $("#firewallRule_error").html(jQuery.i18n.prop("ruleName3_5"));
                return false;
            }
            if (that.isCustomRuleNameExist(ruleName)) {
                $("#firewallRule_error").show();
                $("#firewallRule_error").html(jQuery.i18n.prop("RuleName_ADDR_EXIST"));
                return false;
            }
            if (IsChineseChar(ruleName)) {
                $("#firewallRule_error").show();
                $("#firewallRule_error").html(jQuery.i18n.prop("lRuleNameIsChinese"));
                return false;
            }
            if (!deviceNameValidation(ruleName)) {
                $("#firewallRule_error").show();
                $("#firewallRule_error").html(jQuery.i18n.prop("lCustomFWSpecialCharsNotAllowed"));
                return false;
            }
            return true;
        };
        this.checkIPPort = function () {
            $("#firewallRule_error").hide();
            var src_ip = $("#sourceIP1").val() + "." + $("#sourceIP2").val() + "." + $("#sourceIP3").val() + "." + $("#sourceIP4").val();

            var src_netmask = $("#sourceIP5").val();

            var src_port = $("#sourcePort1").val() + ":" + $("#sourcePort2").val();

            var dst_ip = $("#destinationIP1").val() + "." + $("#destinationIP2").val() + "." + $("#destinationIP3").val() + "." + $("#destinationIP4").val();

            var dst_netmask = $("#destinationIP5").val();

            var dst_port = $("#destinationPort1").val() + ":" + $("#destinationPort2").val();
            var flag = isValidRule(src_ip, src_netmask, src_port, dst_ip, dst_netmask, dst_port);
            if (flag == 0) {
                return true;
            } else if (flag == 1) {
                $("#firewallRule_error").show();
                $("#firewallRule_error").html(jQuery.i18n.prop("lIncorrectSrcIP"));
                return false;
            } else if (flag == 2) {
                $("#firewallRule_error").show();
                $("#firewallRule_error").html(jQuery.i18n.prop("lIncorrectDstIP"));
                return false;
            } else if (flag == 3) {
                $("#firewallRule_error").show();
                $("#firewallRule_error").html(jQuery.i18n.prop("lPortNumInvalide"));
                return false;
            } else if (flag == 4) {
                $("#firewallRule_error").show();
                $("#firewallRule_error").html(jQuery.i18n.prop("lStartPortLarger"));
                return false;
            } else if (flag == 5) {
                $("#firewallRule_error").show();
                $("#firewallRule_error").html(jQuery.i18n.prop("lAtleastOne"));
                return false;
            }
        };
        this.displayControls = function () {
            $("#lt_firewall_title").html(jQuery.i18n.prop("mCustomFirewallRules"));
            $("#lt_firewall_text").html(jQuery.i18n.prop("lCustomFWRulesText"));
            $("#btn_add_firewallRule").val(jQuery.i18n.prop("btnAddRule"));
            $("#th_ruleName").html(jQuery.i18n.prop("ltRuleName"));
            $("#th_enabled").html(jQuery.i18n.prop("ltEnabled"));
            $("#th_sourceIP").html(jQuery.i18n.prop("ltSrcIP"));
            $("#th_sourcePort").html(jQuery.i18n.prop("ltSrcPort"));
            $("#th_destinationIP").html(jQuery.i18n.prop("ltDstIP"));
            $("#th_destinationPort").html(jQuery.i18n.prop("ltDstPort"));
            $("#th_protocol").html(jQuery.i18n.prop("ltProtocol"));
            $("#lt_firewallRule_AddTitle").html(jQuery.i18n.prop("h1CustomFWRule"));
            $("#lt_ruleName").html(jQuery.i18n.prop("lRuleName_fw"));
            $("#lt_status").html(jQuery.i18n.prop("lStatus_fw"));
            $("#lt_sourceIP").html(jQuery.i18n.prop("lSrcIP"));
            $("#lt_sourcePort").html(jQuery.i18n.prop("lSrcPort"));
            $("#lt_destinationIP").html(jQuery.i18n.prop("lDstIP"));
            $("#lt_destinationPort").html(jQuery.i18n.prop("lDstPort"));
            $("#lt_protocol").html(jQuery.i18n.prop("lProtocol"));
            $("#span_enabled").html(jQuery.i18n.prop("lt_optEnableSwitch"));
            $("#span_disabled").html(jQuery.i18n.prop("lt_optDisabledSwitch"));
            $("#lt_btnAdd").val(jQuery.i18n.prop("btnAddAccessLogsRule"));
            $("#lt_btnSave").val(jQuery.i18n.prop("lt_btnSave"));
            $("#lt_btnCancel").val(jQuery.i18n.prop("lt_btnCancel"));
        };
        return this;
    };
})(jQuery);
function customFWRuleClicked(obj) {
    $("#firewallRule_error").hide();
    var name = $(obj).attr("name");
    for (var i = 0; i < _arrayTableDataCustomFW.length; i++) {
        var l = _arrayTableDataCustomFW[i];
        if (name == l[1]) {
            $("#divFirewallRuleDlg").show();
            setAddBoxHeigth("divFirewallRuleDlg");
            $("#lt_btnAdd").hide();
            $("#lt_btnSave").show();
            $("#txtRulename").val(l[1]);
            $("#txtRulename").attr("name", name);
            $("#txtRulename").attr("disabled", true);
            $("#txtRulename").addClass("dhcp_disabled");
            if (l[2] == "1") {
                $("#radio_enabled").prop("checked", true);
            } else {
                $("#radio_disabled").prop("checked", true);
            }
            var srcPort = l[4].split(":");
            $("#sourcePort1").val(srcPort[0]);
            $("#sourcePort2").val(srcPort[1]);
            if (l[3] == "" || l[3] == "NA" || l[3] == "N/A") {
                $("#sourceIP1").val("");
                $("#sourceIP2").val("");
                $("#sourceIP3").val("");
                $("#sourceIP4").val("");
                $("#sourceIP5").val("");
            } else {
                var srcIP = l[3].split(".");
                var srcip3 = srcIP[3];
                srcip3 = srcip3.split("/");
                $("#sourceIP1").val(srcIP[0]);
                $("#sourceIP2").val(srcIP[1]);
                $("#sourceIP3").val(srcIP[2]);
                $("#sourceIP4").val(srcip3[0]);
                $("#sourceIP5").val(srcip3[1]);
            }

            var desPort = l[6].split(":");
            $("#destinationPort1").val(desPort[0]);
            $("#destinationPort2").val(desPort[1]);
            if (l[5] == "" || l[5] == "NA" || l[5] == "N/A") {
                $("#destinationIP1").val("");
                $("#destinationIP2").val("");
                $("#destinationIP3").val("");
                $("#destinationIP4").val("");
                $("#destinationIP5").val("");
            } else {
                var desIP = l[5].split(".");
                var desip3 = desIP[3];
                desip3 = desip3.split("/");
                $("#destinationIP1").val(desIP[0]);
                $("#destinationIP2").val(desIP[1]);
                $("#destinationIP3").val(desIP[2]);
                $("#destinationIP4").val(desip3[0]);
                $("#destinationIP5").val(desip3[1]);
            }
            $("#fwdSelect").val(l[7]);
        }
    }
}
function deleteFirewallRule(obj) {
    var rule_name = $(obj).attr("name");
    var jsonData = { custom_rules_list: [{ rule_name: rule_name, delete: "1" }] };

    showWait();
    setTimeout(function () {
        postJSON("custom_fw_set", jsonData, function (data) {
            if (data.result != "success") {
                showMsgBox(jQuery.i18n.prop("mCustomFirewallRules"), jQuery.i18n.prop("dialog_message_qos_delete_ip_fail"));
            } else {
                $.objCustomFirewallRules().onLoad(false);
                $("#divFirewallRuleDlg").hide();
            }
        });
    }, 100);
}
function isValidRule(ip1, nm1, ports1, ip2, nm2, ports2) {
    var flag = 0;

    if (ip1 == "..." && ports1 == ":" && ip2 == "..." && ports2 == ":") flag = 5;

    if (ip1 != "...") {
        if (!isIPFULL(ip1, true)) flag = 1;
        if (!is_valid_netmask_num(nm1)) flag = 1;
    } else {
        if (nm1.length > 0) flag = 1;
    }
    if (ip2 != "...") {
        if (!isIPFULL(ip2, true)) flag = 2;
        if (!is_valid_netmask_num(nm2)) flag = 2;
    } else {
        if (nm2.length > 0) flag = 2;
    }

    if (ports1 != ":") {
        var port11 = ports1.split(":")[0];
        var port12 = ports1.split(":")[1];
        if (!(IsNumber(port11) && IsNumber(port12))) flag = 3;
        if (Number(port11) > 65535 || Number(port11) < 1) flag = 3;
        if (Number(port12) > 65535 || Number(port12) < 1) flag = 3;
        if (Number(port11) > Number(port12)) flag = 4;
    }

    if (ports2 != ":") {
        var port21 = ports2.split(":")[0];
        var port22 = ports2.split(":")[1];
        if (!(IsNumber(port21) && IsNumber(port22))) flag = 3;
        if (Number(port21) > 65535 || Number(port21) < 1) flag = 3;
        if (Number(port22) > 65535 || Number(port22) < 1) flag = 3;
        if (Number(port21) > Number(port22)) flag = 4;
    }

    return flag;
}
function is_valid_netmask_num(nm) {
    ret = true;
    if (nm.length > 0) {
        if (!IsNumber(nm)) ret = false;
        if (Number(nm) < 1 || Number(nm) > 32) ret = false;
    }
    return ret;
}
// -------------------------------------------------------------objPortFilter-----------------------------------------------------------------
var arrayPortFilterRules = [];
var g_PortFilterNumber = 0;
(function ($) {
    $.objPortFilter = function () {
        var that = this;
        var mtu_value;
        this.onLoad = function (flag) {
            if (flag) {
                that.displayControls();
                that.btnEvent();
                showHelp();
            }
            that.showData();
            setDlgStyle();
        };
        this.showData = function () {
            callJSON("port_filter_info", function (json) {
                var filter_mode = json.port_filter_mode;
                if (filter_mode == "1") {
                    $("#radio_enabled").attr("checked", true);
                } else {
                    $("#radio_disabled").attr("checked", true);
                }
                arrayPortFilterRules = [];
                g_PortFilterNumber = json.port_filter_list.length;
                for (var i = 0; i < json.port_filter_list.length; i++) {
                    var l = json.port_filter_list[i];
                    var ruleName = decodeURIComponent(l.rule_name);
                    var protocol = l.protocol;
                    var triggerPort = l.trigger_port;
                    var responsePort = l.response_port;

                    arrayPortFilterRules.push([l.index, ruleName, protocol, triggerPort, responsePort]);
                }
                that.loadTableData();
            });
        };
        this.loadTableData = function () {
            var bodyHTML = "";
            if (arrayPortFilterRules.length == 0) {
                bodyHTML = '<tr><td colspan="5">' + jQuery.i18n.prop("tableNoData") + "</td></tr>";
            } else {
                for (var i = 0; i < arrayPortFilterRules.length; i++) {
                    var l = arrayPortFilterRules[i];
                    bodyHTML += '<tr><td name="' + l[1] + '"  onclick="PortFilterRuleClicked(this)" style="color:#05bda1;cursor:pointer;">' + l[1] + "</td><td>" + l[2] + "</td><td>" + l[3] + "</td><td>" + l[4] + '</td><td><sapn name="' + l[1] + '" onclick="deletePortFilterRule(this)" class="delete_spanBtn">&times;</span></td></tr>';
                }
            }
            $("#portFilterBody").html(bodyHTML);
        };
        this.btnEvent = function () {
            $("#addPortFilterclose").unbind("click");
            $("#addPortFilterclose").bind("click", function () {
                $("#divPortFilterDlg").hide();
            });

            $("#lt_btnCancel").unbind("click");
            $("#lt_btnCancel").bind("click", function () {
                $("#divPortFilterDlg").hide();
            });

            /*  $("#triggerPort2").unbind("input");
            $("#triggerPort2").bind("input",function(){
                that.checkPort();
            });

            $("#txtRulename").unbind("input");
            $("#txtRulename").bind("input",function(){
                that.checkRuleName();
            });

            $("#responsePort2").unbind("input");
            $("#responsePort2").bind("input",function(){
                that.checkPort();
            }); */
            $("#txtRulename,#triggerPort1,#triggerPort2,#responsePort1,#responsePort2").focus(function () {
                $("#portFilter_error").hide();
            });
            $("#PortFilterProtocolSel").change(function () {
                $("#portFilter_error").hide();
            });
            $("#btn_addPortFilter").unbind("click");
            $("#btn_addPortFilter").bind("click", function () {
                if (g_PortFilterNumber >= 8) {
                    showMsgBox(jQuery.i18n.prop("mPortFilter"), jQuery.i18n.prop("OutPortFilterRange"));
                    return;
                }
                $("input[type='text']").val("");
                $("#divPortFilterDlg").show();
                setAddBoxHeigth("divPortFilterDlg");
                $("#txtRulename").attr("disabled", false);
                $("#txtRulename").removeClass("dhcp_disabled");
                $("#portFilter_error").hide();
                $("#lt_btnAdd").show();
                $("#lt_btnSave").hide();
            });

            $("#btn_portFilterMode").unbind("click");
            $("#btn_portFilterMode").bind("click", function () {
                showWait();
                setTimeout(function () {
                    var portFilterMode = $("#radio_enabled").is(":checked") ? "1" : "0";
                    var jsonData = {};
                    jsonData.port_filter_mode = portFilterMode;
                    postJSON("port_filter_set", jsonData, function (data) {
                        closeWait();
                        if (data.result == "success") {
                            showMsgBox(jQuery.i18n.prop("lt_portFilter_stcMode"), jQuery.i18n.prop("ls_save_time_success"));
                        } else {
                            showMsgBox(jQuery.i18n.prop("lt_portFilter_stcMode"), jQuery.i18n.prop("ls_save_time_failure"));
                        }
                        that.onLoad(false);
                    });
                }, 100);
            });

            $("#lt_btnAdd").unbind("click");
            $("#lt_btnAdd").bind("click", function () {
                if (that.checkRuleName() && that.checkPort()) {
                    var ruleName = $("#txtRulename").val();
                    var trigger1 = $("#triggerPort1").val();
                    var trigger2 = $("#triggerPort2").val();
                    var response1 = $("#responsePort1").val();
                    var response2 = $("#responsePort2").val();
                    var protocol = $("#PortFilterProtocolSel").val();
                    var triggerPort = trigger1 + ":" + trigger2;
                    var responsePort = response1 + ":" + response2;

                    if (response1 == "") {
                        responsePort = "NA";
                    }
                    if (trigger1 == "") {
                        triggerPort = "NA";
                    }
                    var jsonData = {};
                    jsonData.port_filter_list = [{}];
                    jsonData.port_filter_list[0].index = arrayPortFilterRules.length + "";
                    jsonData.port_filter_list[0].rule_name = ruleName;
                    jsonData.port_filter_list[0].protocol = protocol;
                    jsonData.port_filter_list[0].trigger_port = triggerPort;
                    jsonData.port_filter_list[0].response_port = responsePort;
                    showWait();
                    setTimeout(function () {
                        postJSON("port_filter_set", jsonData, function (data) {
                            if (data.result != "success") {
                                showMsgBox(jQuery.i18n.prop("mPortFilter"), jQuery.i18n.prop("ls_save_time_failure"));
                            } else {
                                $("#divPortFilterDlg").hide();
                                that.onLoad(false);
                            }
                        });
                    }, 100);
                }
            });

            $("#lt_btnSave").unbind("click");
            $("#lt_btnSave").bind("click", function () {
                if (that.checkRuleName() && chat.checkPort()) {
                    var ruleName = $("#txtRulename").val();
                    var trigger1 = $("#triggerPort1").val();
                    var trigger2 = $("#triggerPort2").val();
                    var response1 = $("#responsePort1").val();
                    var response2 = $("#responsePort2").val();
                    var protocol = $("#PortFilterProtocolSel").val();
                    var triggerPort = trigger1 + ":" + trigger2;
                    var responsePort = response1 + ":" + response2;

                    if (response1 == "") {
                        responsePort = "NA";
                    }
                    if (trigger1 == "") {
                        triggerPort = "NA";
                    }
                    var jsonData = {};
                    jsonData.port_filter_list = [{}];
                    jsonData.port_filter_list[0].index = $("#txtRulename").attr("name");
                    jsonData.port_filter_list[0].rule_name = ruleName;
                    jsonData.port_filter_list[0].protocol = protocol;
                    jsonData.port_filter_list[0].trigger_port = triggerPort;
                    jsonData.port_filter_list[0].response_port = responsePort;
                    showWait();
                    setTimeout(function () {
                        postJSON("port_filter_set", jsonData, function (data) {
                            if (data.result != "success") {
                                showMsgBox(jQuery.i18n.prop("mPortFilter"), jQuery.i18n.prop("ls_save_time_failure"));
                            } else {
                                $("#divPortFilterDlg").hide();
                                that.onLoad(false);
                            }
                        });
                    }, 100);
                }
            });
        };
        this.checkRuleName = function () {
            $("#portFilter_error").hide();
            var ruleName = $("#txtRulename").val();
            if (ruleName == "") {
                $("#portFilter_error").show();
                $("#portFilter_error").html(jQuery.i18n.prop("lEmptyName"));
                return false;
            }
            if (!deviceNameValidation(ruleName)) {
                $("#portFilter_error").show();
                $("#portFilter_error").html(jQuery.i18n.prop("lCustomFWSpecialCharsNotAllowed"));
                return false;
            }
            return true;
        };
        this.checkPort = function () {
            $("#portFilter_error").hide();
            var trigger1 = $("#triggerPort1").val();
            var trigger2 = $("#triggerPort2").val();
            var response1 = $("#responsePort1").val();
            var response2 = $("#responsePort2").val();

            if (!CheckPortNum(trigger1) || !CheckPortNum(trigger2) || !CheckPortNum(response1) || !CheckPortNum(response2)) {
                $("#portFilter_error").show();
                $("#portFilter_error").html(jQuery.i18n.prop("lPortNumInvalide"));
                return false;
            }
            if ((trigger1 != "" && trigger2 == "") || (trigger1 == "" && trigger2 != "")) {
                $("#portFilter_error").show();
                $("#portFilter_error").html(jQuery.i18n.prop("lTriggerPortIncomplete"));
                return false;
            }
            if ((response1 != "" && response2 == "") || (response1 == "" && response2 != "")) {
                $("#portFilter_error").show();
                $("#portFilter_error").html(jQuery.i18n.prop("lResponsePortIncomplete"));
                return false;
            }
            if (trigger1 != "") {
                if (parseInt(trigger1) > parseInt(trigger2)) {
                    $("#portFilter_error").show();
                    $("#portFilter_error").html(jQuery.i18n.prop("lStartPortLarger"));
                    return false;
                }
            }
            if (response1 != "") {
                if (parseInt(response1) > parseInt(response2)) {
                    $("#portFilter_error").show();
                    $("#portFilter_error").html(jQuery.i18n.prop("lStartPortLarger"));
                    return false;
                }
            }
            if ((trigger1 == "" && trigger2 == "") || (response2 == "" && response1 == "")) {
                $("#portFilter_error").show();
                $("#portFilter_error").html(jQuery.i18n.prop("lStartPortIsEmpty"));
                return false;
            }

            return true;
        };
        this.displayControls = function () {
            $("#lt_portFilter_title").html(jQuery.i18n.prop("mPortFilter"));
            $("#p_portFilter_text").html(jQuery.i18n.prop("p_portFilter_text"));
            $("#lt_portFilterMode").html(jQuery.i18n.prop("lt_portFilter_stcMode"));
            $("#span_enabled").html(jQuery.i18n.prop("lt_optEnableSwitch"));
            $("#span_disabled").html(jQuery.i18n.prop("lt_SmsSet_stcSendReportDisabled"));
            $("#btn_portFilterMode").val(jQuery.i18n.prop("lt_btnSave"));
            $("#btn_addPortFilter").val(jQuery.i18n.prop("lt_portFilter_btnAddPortFilterRules"));
            $("#th_ruleName").html(jQuery.i18n.prop("ltRuleName"));
            $("#th_protocol").html(jQuery.i18n.prop("ltProtocol"));
            $("#th_triggerPort").html(jQuery.i18n.prop("lt_portFilter_stcTriggerPort"));
            $("#th_responsePort").html(jQuery.i18n.prop("lt_portFilter_stcResponsePort"));
            $("#lt_portFilter_AddTitle").html(jQuery.i18n.prop("lt_portFilter_stcPortFilterDlgTitle"));
            $("#lt_ruleName").html(jQuery.i18n.prop("ltRuleName"));
            $("#lt_triggerPort").html(jQuery.i18n.prop("lt_portFilter_stcTriggerPort"));
            $("#lt_responsePort").html(jQuery.i18n.prop("lt_portFilter_stcResponsePort"));
            $("#lt_protocol").html(jQuery.i18n.prop("ltProtocol"));
            $("#lt_btnAdd").val(jQuery.i18n.prop("lt_portFilter_btnAddPortFilterRules"));
            $("#lt_btnSave").val(jQuery.i18n.prop("lt_btnSave"));
            $("#lt_btnCancel").val(jQuery.i18n.prop("lt_btnCancel"));
        };
        return this;
    };
})(jQuery);
function PortFilterRuleClicked(obj) {
    $("#portFilter_error").text("");
    var name = $(obj).attr("name");
    for (var i = 0; i < arrayPortFilterRules.length; i++) {
        var l = arrayPortFilterRules[i];
        if (l[1] == name) {
            $("#divPortFilterDlg").show();
            setAddBoxHeigth("divPortFilterDlg");
            $("#txtRulename").attr("disabled", true);
            $("#txtRulename").addClass("dhcp_disabled");
            $("#lt_btnAdd").show();
            $("#lt_btnSave").hide();
            $("#txtRulename").attr("name", name);
            var trigger = l[3].split(":");
            var response = l[4].split(":");
            $("#txtRulename").val(l[1]);
            $("#triggerPort1").val(trigger[0]);
            $("#triggerPort2").val(trigger[1]);
            $("#responsePort1").val(response[0]);
            $("#responsePort2").val(response[1]);
            $("#PortFilterProtocolSel").val(l[2]);
        }
    }
}
function deletePortFilterRule(obj) {
    var rule_name = $(obj).attr("name");
    var jsonData = { port_filter_list: [{ delete: "1" }] };
    jsonData.port_filter_list[0].rule_name = rule_name;
    showWait();
    setTimeout(function () {
        postJSON("port_filter_set", jsonData, function (data) {
            if (data.result != "success") {
                showMsgBox(jQuery.i18n.prop("mPortFilter"), jQuery.i18n.prop("dialog_message_qos_delete_ip_fail"));
            } else {
                $.objPortFilter().onLoad(false);
            }
        });
    }, 100);
}
function CheckPortNum(strPortNum) {
    if (strPortNum == "") {
        return true;
    }
    if (!IsNumber(strPortNum)) {
        return false;
    }
    var portNum = parseInt(strPortNum);
    if (portNum < 1 || portNum > 65535) {
        return false;
    }
    return true;
}
// -------------------------------------------------------------objPortForwarding-----------------------------------------------------------------
var arrayPortForwardRules = [];
var g_PortForwardingNumber = 0;
var portForwardDHCP = "";
(function ($) {
    $.objPortForwarding = function () {
        var that = this;
        var mtu_value;
        this.onLoad = function (flag) {
            if (flag) {
                that.displayControls();
                that.btnEvent();
                showHelp();
            }
            that.showData();
            setDlgStyle();
        };
        this.showData = function () {
            g_PortForwardingNumber = 0;
            callJSON("port_forwarding_info", function (json) {
                var start = json.dhcp_start;
                portForwardDHCP = json.dhcp_start;
                start = start.split(".");
                $("#ip1").val(start[0]);
                $("#ip2").val(start[1]);
                $("#ip3").val(start[2]);

                if (json.pf_enable == "1") {
                    $("#radio_enabled").attr("checked", true);
                } else {
                    $("#radio_disabled").attr("checked", true);
                }
                arrayPortForwardRules = [];
                g_PortForwardingNumber = json.port_forwarding_list.length;
                for (var i = 0; i < json.port_forwarding_list.length; i++) {
                    var l = json.port_forwarding_list[i];
                    arrayPortForwardRules.push([l.index, decodeURIComponent(l.rulename), l.pw_ip, l.pw_port, l.protocol]);
                }
                that.loadTableData();
            });
        };
        this.loadTableData = function () {
            var bodyHTML = "";
            if (arrayPortForwardRules.length == 0) {
                bodyHTML = '<tr><td colspan="5">' + jQuery.i18n.prop("tableNoData") + "</td></tr>";
            } else {
                for (var i = 0; i < arrayPortForwardRules.length; i++) {
                    var l = arrayPortForwardRules[i];
                    bodyHTML += '<tr><td name="' + l[1] + '"  onclick="PortForwardRuleClicked(this)" style="color:#05bda1;cursor:pointer;">' + l[1] + "</td><td>" + l[2] + "</td><td>" + l[3] + "</td><td>" + l[4] + '</td><td><sapn name="' + l[1] + '" onclick="deletePortForwardRule(this)" class="delete_spanBtn">&times;</span></td></tr>';
                }
            }
            $("#portForwardBody").html(bodyHTML);
        };
        this.checkRuleName = function () {
            $("#portForward_error").hide();
            var ruleName = $("#txtRulename").val();
            if (ruleName == "") {
                $("#portForward_error").show();
                $("#portForward_error").html(jQuery.i18n.prop("lEmptyName"));
                return false;
            }
            if (!deviceNameValidation(ruleName)) {
                $("#portForward_error").show();
                $("#portForward_error").html(jQuery.i18n.prop("lCustomFWSpecialCharsNotAllowed"));
                return false;
            }
            return true;
        };
        this.checkPort = function () {
            $("#portForward_error").hide();
            var port1 = $("#port1").val();
            var port2 = $("#port2").val();
            var ip = $("#ip4").val();

            if (ip == "") {
                $("#portForward_error").show();
                $("#portForward_error").html(jQuery.i18n.prop("IP_ADDR_IS_EMPTY"));
                return false;
            }
            if (!IsNumber(ip)) {
                $("#portForward_error").show();
                $("#portForward_error").html(jQuery.i18n.prop("lIncorrectPWIP"));
                return false;
            }
            if (parseInt(ip) > 255 || parseInt(ip) < 1) {
                $("#portForward_error").show();
                $("#portForward_error").html(jQuery.i18n.prop("lIncorrectPWIP"));
                return false;
            }

            if (!CheckPortNum(port1) || !CheckPortNum(port2)) {
                $("#portForward_error").show();
                $("#portForward_error").html(jQuery.i18n.prop("lPortNumInvalide"));
                return false;
            }
            if ((port1 != "" && port2 == "") || (port1 == "" && port2 != "")) {
                $("#portForward_error").show();
                $("#portForward_error").html(jQuery.i18n.prop("lResponsePortIncomplete"));
                return false;
            }
            if (port1 == "" && port2 == "") {
                $("#portForward_error").show();
                $("#portForward_error").html(jQuery.i18n.prop("lStartPortIsEmpty"));
                return false;
            }
            if (parseInt(port1) > parseInt(port2)) {
                $("#portForward_error").show();
                $("#portForward_error").html(jQuery.i18n.prop("lStartPortLarger"));
                return false;
            }

            return true;
        };
        this.btnEvent = function () {
            $("#addPorForwardclose").unbind("click");
            $("#addPorForwardclose").bind("click", function () {
                $("#divPorForwardDlg").hide();
            });

            $("#lt_btnCancel").unbind("click");
            $("#lt_btnCancel").bind("click", function () {
                $("#divPorForwardDlg").hide();
            });

            $("#btn_addporForward").unbind("click");
            $("#btn_addporForward").bind("click", function () {
                if (g_PortForwardingNumber >= 8) {
                    showMsgBox(jQuery.i18n.prop("mPortForwarding"), jQuery.i18n.prop("OutPortForwardingRange"));
                    return;
                }
                $("#divPorForwardDlg").show();
                setAddBoxHeigth("divPorForwardDlg");
                $("#txtRulename").val("");
                $("#port1").val("");
                $("#port2").val("");
                $("#ip4").val("");
                $("#txtRulename").attr("disabled", false);
                $("#txtRulename").removeClass("dhcp_disabled");
                $("#portForward_error").hide();
                $("#lt_btnAdd").show();
                $("#lt_btnSave").hide();
            });

            $("#btn_porForwardMode").unbind("click");
            $("#btn_porForwardMode").bind("click", function () {
                var porForwardMode = $("#radio_enabled").is(":checked") ? "1" : "0";
                var jsonData = {};
                jsonData.pf_enable = porForwardMode;
                showWait();
                setTimeout(function () {
                    postJSON("port_forwarding_set", jsonData, function (data) {
                        that.onLoad(false);
                    });
                }, 100);
            });

            /* $("#port2").unbind("input");
            $("#port2").bind("input",function(){
                that.checkPort();
            }); */

            /*  $("#txtRulename").unbind("input");
            $("#txtRulename").bind("input",function(){
                that.checkRuleName();
            }); */
            $("#txtRulename,#ip4,#port1,#port2").focus(function () {
                $("#portForward_error").text("");
            });
            $("#porForwardProtocolSel").change(function () {
                $("#portForward_error").text("");
            });

            $("#lt_btnAdd").unbind("click");
            $("#lt_btnAdd").bind("click", function () {
                if (that.checkRuleName() && that.checkPort()) {
                    var rulename = $("#txtRulename").val();
                    var ipStart = portForwardDHCP.split(".");
                    var ip = ipStart[0] + "." + ipStart[1] + "." + ipStart[2] + "." + $("#ip4").val();
                    var port = $("#port1").val() + ":" + $("#port2").val();
                    var protocol = $("#porForwardProtocolSel").val();
                    var jsonData = {};
                    jsonData.port_forwarding_list = [{}];
                    jsonData.port_forwarding_list[0].index = arrayPortForwardRules.length + "";
                    jsonData.port_forwarding_list[0].rulename = rulename;
                    jsonData.port_forwarding_list[0].pw_ip = ip;
                    jsonData.port_forwarding_list[0].pw_port = port;
                    jsonData.port_forwarding_list[0].protocol = protocol;
                    showWait();
                    setTimeout(function () {
                        postJSON("port_forwarding_set", jsonData, function (data) {
                            if (data.result != "success") {
                                showMsgBox(jQuery.i18n.prop("mPortForwarding"), jQuery.i18n.prop("ls_save_time_failure"));
                            } else {
                                $("#divPorForwardDlg").hide();
                                that.onLoad(false);
                            }
                        });
                    }, 100);
                }
            });

            $("#lt_btnSave").unbind("click");
            $("#lt_btnSave").bind("click", function () {
                if (that.checkRuleName() && that.checkPort()) {
                    var rulename = $("#txtRulename").val();
                    var ipStart = portForwardDHCP.split(".");
                    var ip = ipStart[0] + "." + ipStart[1] + "." + ipStart[2] + "." + $("#ip4").val();
                    var port = $("#port1").val() + ":" + $("#port2").val();
                    var protocol = $("#porForwardProtocolSel").val();
                    var jsonData = {};
                    jsonData.port_forwarding_list = [{}];
                    jsonData.port_forwarding_list[0].index = $("#txtRulename").attr("name");
                    jsonData.port_forwarding_list[0].rulename = rulename;
                    jsonData.port_forwarding_list[0].pw_ip = ip;
                    jsonData.port_forwarding_list[0].pw_port = port;
                    jsonData.port_forwarding_list[0].protocol = protocol;
                    showWait();
                    setTimeout(function () {
                        postJSON("port_forwarding_set", jsonData, function (data) {
                            if (data.result != "success") {
                                showMsgBox(jQuery.i18n.prop("mPortForwarding"), jQuery.i18n.prop("ls_save_time_failure"));
                            } else {
                                $("#divPorForwardDlg").hide();
                                that.onLoad(false);
                            }
                        });
                    }, 100);
                }
            });
        };
        this.displayControls = function () {
            $("#lt_porForward_title").html(jQuery.i18n.prop("mPortForwarding"));
            $("#lt_porForwardMode").html(jQuery.i18n.prop("lCustomPWRulesText"));
            $("#span_enabled").html(jQuery.i18n.prop("lt_optEnableSwitch"));
            $("#span_disabled").html(jQuery.i18n.prop("lt_SmsSet_stcSendReportDisabled"));
            $("#btn_porForwardMode").val(jQuery.i18n.prop("lt_btnSave"));
            $("#btn_addporForward").val(jQuery.i18n.prop("btnAddAccessLogsRule"));
            $("#th_ruleName").html(jQuery.i18n.prop("ltRuleName"));
            $("#th_IP").html(jQuery.i18n.prop("lt_log_IPAddr"));
            $("#th_port").html(jQuery.i18n.prop("ltPWPort"));
            $("#th_protocol").html(jQuery.i18n.prop("ltProtocol"));
            $("#lt_porForward_AddTitle").html(jQuery.i18n.prop("mPortForwarding"));
            $("#lt_ruleName").html(jQuery.i18n.prop("ltRuleName"));
            $("#lt_IP").html(jQuery.i18n.prop("lt_log_IPAddr"));
            $("#lt_port").html(jQuery.i18n.prop("ltPWPort"));
            $("#lt_protocol").html(jQuery.i18n.prop("ltProtocol"));
            $("#lt_btnAdd").val(jQuery.i18n.prop("btnAddAccessLogsRule"));
            $("#lt_btnSave").val(jQuery.i18n.prop("lt_btnSave"));
            $("#lt_btnCancel").val(jQuery.i18n.prop("lt_btnCancel"));
        };
        return this;
    };
})(jQuery);
function ip4_rangeChanged() {
    var ip4 = $("#ip4").val();
    if (ip4 == "") {
        return false;
    }
    //$("#ip4").val(parseInt(ip4));
    $("#ip4").val(ip4);
}
function PortForwardRuleClicked(obj) {
    $("#portForward_error").text("");
    var name = $(obj).attr("name");
    for (var i = 0; i < arrayPortForwardRules.length; i++) {
        var l = arrayPortForwardRules[i];
        if (l[1] == name) {
            $("#divPorForwardDlg").show();
            setAddBoxHeigth("divPorForwardDlg");
            $("#txtRulename").attr("disabled", true);
            $("#txtRulename").addClass("dhcp_disabled");
            $("#lt_btnAdd").hide();
            $("#lt_btnSave").show();
            $("#txtRulename").attr("name", name);
            var ip = l[2];
            var port = l[3];
            ip = ip.split(".");
            port = port.split(":");
            $("#txtRulename").val(l[1]);
            $("#ip4").val(ip[3]);
            $("#port1").val(port[0]);
            $("#port2").val(port[1]);
            $("#porForwardProtocolSel").val(l[4]);
        }
    }
}
function deletePortForwardRule(obj) {
    var name = $(obj).attr("name");
    var jsonData = { port_forwarding_list: [{ delete: "1" }] };
    jsonData.port_forwarding_list[0].rulename = name;
    showWait();
    setTimeout(function () {
        postJSON("port_forwarding_set", jsonData, function (data) {
            if (data.result != "success") {
                showMsgBox(jQuery.i18n.prop("mPortForwarding"), jQuery.i18n.prop("dialog_message_qos_delete_ip_fail"));
            } else {
                $.objPortForwarding().onLoad(false);
            }
        });
    }, 100);
}
// -------------------------------------------------------------objRouterManage-----------------------------------------------------------------
(function ($) {
    $.objRouterManage = function () {
        var that = this;
        this.onLoad = function (flag) {
            if (flag) {
                that.displayControls();
                that.BtnClick();
                showHelp();
            }
            setDlgStyle();
        };
        this.BtnClick = function () {
            $("#lt_rm_btnReboot").unbind("click");
            $("#lt_rm_btnReboot").bind("click", function () {
                showBOX2(
                    jQuery.i18n.prop("lt_rm_title"),
                    jQuery.i18n.prop("lt_rm_QueryRebootedRouter"),
                    jQuery.i18n.prop("lt_btnOK"),
                    jQuery.i18n.prop("lt_btnCancel"),
                    function () {
                        callJSON("device_restart", function () {
                            showWait();
                        });
                        ClosemBOX2();
                        showWait();
                        afterRebootID = setInterval("afterRebootConf()", 30000);
                    },
                    function () {
                        ClosemBOX2();
                    }
                );
            });
            $("#lt_rm_btnResetFactory").unbind("click");
            $("#lt_rm_btnResetFactory").bind("click", function () {
                showBOX2(
                    jQuery.i18n.prop("lt_rm_title"),
                    jQuery.i18n.prop("lt_rm_QueryResetRouter"),
                    jQuery.i18n.prop("lt_btnOK"),
                    jQuery.i18n.prop("lt_btnCancel"),
                    function () {
                        callJSON("device_restore_factory", function () {
                            showWait();
                        });
                        ClosemBOX2();
                        showWait();
                        afterRebootID = setInterval("afterRebootConf()", 30000);
                    },
                    function () {
                        ClosemBOX2();
                    }
                );
            });
        };
        this.displayControls = function () {
            $("#lt_rm_title").html(jQuery.i18n.prop("lt_rm_title"));
            $("#lt_rm_reboot").html(jQuery.i18n.prop("lt_rm_reboot"));
            $("#lt_rm_resetFactory").html(jQuery.i18n.prop("lt_rm_resetFactory"));
            $("#lt_rm_btnReboot").val(jQuery.i18n.prop("lt_rm_btnReboot"));
            $("#lt_rm_btnResetFactory").val(jQuery.i18n.prop("lt_rm_btnResetFactory"));
        };
        return this;
    };
})(jQuery);
// -------------------------------------------------------------objAccountManage-----------------------------------------------------------------
ACCESS_ACCOUNT = "admin";
var router_user_list = [];
var curUsername = "";
var curPassword = "";
(function ($) {
    $.objAccountManage = function () {
        var that = this;
        this.onLoad = function (flag) {
            if (flag) {
                that.displayControls();
                that.btnSave();
            }
            that.showData();
            setDlgStyle();
        };
        this.showData = function () {
            callJSON("account_management_info", function (json) {
                var multi_account = json.multi_account;
                curUsername = json.router_username;
                curPassword = json.router_password;
                router_user_list = json.router_user_list;
                loadAccountTable(router_user_list);
            });
        };
        this.btnSave = function () {
            $("#lt_btUpdate").unbind("click");
            $("#lt_btUpdate").bind("click", function () {
                if (that.checkPwd()) {
                    showWait();
                    var item_name = encodeURIComponent(username);
                    var item_password = encodeURIComponent($("#txtNewPwd1").val());

                    var jsonData = {};
                    jsonData.account_action = "1";
                    jsonData.router_user_list = [{}];
                    jsonData.router_user_list[0].username = item_name;
                    jsonData.router_user_list[0].password = item_password;
                    //jsonData.router_user_list[0].authority="1";
                    setTimeout(function () {
                        postJSON("account_management_set", jsonData, function (data) {
                            // setTimeout(function () {
                            //     window.location.href="index.html";
                            // },100);
                            logOut();
                        });
                    }, 100);
                }
            });
        };
        this.checkPwd = function () {
            $("#lAlertPasswordError").hide();
            var pwd1 = $("#txtNewPwd1").val();
            var pwd2 = $("#txtNewPwd2").val();
            var currentPwd = $("#txtCurrentPwd1").val();
            if (currentPwd != g_loginPasswd) {
                $("#lAlertPasswordError").html(jQuery.i18n.prop("lloginfailed"));
                $("#lAlertPasswordError").show();
                return false;
            } else if (pwd1 == "" || pwd2 == "") {
                $("#lAlertPasswordError").html(jQuery.i18n.prop("lPasswdIsEmpty"));
                $("#lAlertPasswordError").show();
                return false;
            } else if (pwd1 != pwd2) {
                $("#lAlertPasswordError").html(jQuery.i18n.prop("lPassErrorMes"));
                $("#lAlertPasswordError").show();
                return false;
            } else if (pwd1.indexOf(" ") >= 0) {
                $("#lAlertPasswordError").html(jQuery.i18n.prop("lPasswordError1"));
                $("#lAlertPasswordError").show();
                return false;
            } else if (pwd1.length < 4) {
                $("#lAlertPasswordError").html(jQuery.i18n.prop("lPasswordMinLengthError"));
                $("#lAlertPasswordError").show();
                return false;
            } else if (pwd1.length > 20) {
                $("#lAlertPasswordError").html(jQuery.i18n.prop("lPasswordMaxLengthError"));
                $("#lAlertPasswordError").show();
                return false;
            } else if (!deviceNameValidation(pwd1)) {
                $("#lAlertPasswordError").html(jQuery.i18n.prop("ErrAccountPwdChat"));
                $("#lAlertPasswordError").show();
                return false;
            }
            return true;
        };
        this.displayControls = function () {
            $("#lt_change_password_title").html(jQuery.i18n.prop("lt_change_password_title"));
            $("#lt_btUpdate").val(jQuery.i18n.prop("lt_btUpdate"));
            $("#btnAddNewAccount").val(jQuery.i18n.prop("btnAddNewAccount"));
            $("#lAccountTabletitle").html(jQuery.i18n.prop("lAccountTabletitle"));
            $("#ltAccountName").html(jQuery.i18n.prop("ltAccountName"));
            $("#ltAccountGroup").html(jQuery.i18n.prop("ltAccountGroup"));
            $("#ltAccountDelColumn").html(jQuery.i18n.prop("ltAccountDelColumn"));
            $("#h1AccountEdit").html(jQuery.i18n.prop("h1AccountEdit"));
            $("#lAccountName").html(jQuery.i18n.prop("lAccountName"));
            $("#lAccountPassword").html(jQuery.i18n.prop("lAccountPassword"));
            $("#lReAccountPassword").html(jQuery.i18n.prop("lReAccountPassword"));
            $("#lAccountAuthority").html(jQuery.i18n.prop("lAccountAuthority"));
            $("#opt_restricted").html(jQuery.i18n.prop("opt_restricted"));
            $("#opt_standard").html(jQuery.i18n.prop("opt_standard"));
            $("#btnCancel").html(jQuery.i18n.prop("btnCancel"));
            $("#btnOk").val(jQuery.i18n.prop("btnOk"));
        };
        function loadAccountTable(arrayTableData) {
            var tableUserAccount = document.getElementById("tableUserAccount");
            var tBodytable = tableUserAccount.getElementsByTagName("tbody")[0];
            clearTabaleRows("tableUserAccount");
            if (arrayTableData.length == 0) {
                var row1 = tBodytable.insertRow(0);
                var rowCol1 = row1.insertCell(0);
                rowCol1.colSpan = 3;
                rowCol1.innerHTML = jQuery.i18n.prop("tableNoData");
            } else {
                for (var i = 0; i < arrayTableData.length; i++) {
                    var arrayTableDataRow = arrayTableData[i];
                    var row = tBodytable.insertRow(-1);
                    var AccountNameCol = row.insertCell(0);
                    var AuthorityCol = row.insertCell(1);
                    var removeCol = row.insertCell(2);
                    var _name = decodeURIComponent(arrayTableDataRow.username);
                    AccountNameCol.innerHTML = "<a name='" + _name + "' href='#' id ='table_username_link" + i + "' onclick='AccountClicked(this)'>" + _name + "</a>";

                    var authority = arrayTableDataRow.authority;
                    if (authority == "1") {
                        AuthorityCol.innerHTML = jQuery.i18n.prop("lStandard");
                    } else {
                        AuthorityCol.innerHTML = jQuery.i18n.prop("lRestricted");
                    }
                    removeCol.innerHTML = "<a name='" + _name + "' href='#' id='table_remove_link" + i + "' onclick='deleteAccountItem(this)'>" + jQuery.i18n.prop("lRemove") + "</a>";

                    if (g_loginUsername != ACCESS_ACCOUNT) {
                        //当前用户不是admin
                        if (g_loginUsername != _name) {
                            //比如当前是user
                            $("#table_username_link" + i + "").attr("onclick", null);
                            $("#table_username_link" + i + "").css("color", "gray");
                        }
                        $("#table_remove_link" + i + "").attr("onclick", null);
                        $("#table_remove_link" + i + "").css("color", "gray");
                    } else if (g_loginUsername == _name) {
                        //admin
                        $("#table_remove_link" + i + "").attr("onclick", null);
                        $("#table_remove_link" + i + "").css("color", "gray");
                    }
                }
            }
        }

        function clearTabaleRows(tableId) {
            var i = document.getElementById(tableId).rows.length;
            while (i != 1) {
                document.getElementById(tableId).deleteRow(i - 1);
                i--;
            }
        }
        return this;
    };
})(jQuery);
function btnCancelClickedAccountEdit() {
    $("#MBAccount_Popup").hide();
}
function btnOKClickedEditAccount() {
    var AccountName, AccountPassword, AccountRePassword, AccountAuthority;
    AccountName = document.getElementById("txtAccountName").value;
    AccountPassword = document.getElementById("txtAccountPassword").value;
    AccountRePassword = document.getElementById("txtReAccountPassword").value;
    AccountAuthority = document.getElementById("AccountGroupSelect").value;
    if (isChineseChar(AccountName)) {
        document.getElementById("lTablePassErrorMes").style.display = "block";
        document.getElementById("lTablePassErrorMes").innerHTML = jQuery.i18n.prop("APN_AHTU_USER_NAME_INVALIDEATE");
        return;
    }
    if (!bEditAccount) {
        //add new account
        for (var idx = 0; idx < router_user_list.length; ++idx) {
            if (AccountName == router_user_list[idx]["username"]) {
                document.getElementById("lTablePassErrorMes").style.display = "block";
                document.getElementById("lTablePassErrorMes").innerHTML = jQuery.i18n.prop("lAccountExist");
                return;
            }
        }
    }
    if (document.getElementById("txtAccountPassword").value != document.getElementById("txtReAccountPassword").value) {
        document.getElementById("lTablePassErrorMes").style.display = "block";
        document.getElementById("lTablePassErrorMes").innerHTML = jQuery.i18n.prop("lPassErrorMes");
        document.getElementById("txtReAccountPassword").value = "";
    } else {
        document.getElementById("lTablePassErrorMes").style.display = "none";
        if (isValidAccountPage()) {
            document.getElementById("lTablePassErrorMes").style.display = "none";
            postAccountItem(false, AccountName, AccountPassword, AccountAuthority);
        }
    }
}
function isValidAccountPage() {
    if (!(textBoxMinLength("txtAccountName", 4) && textBoxMinLength("txtAccountPassword", 4))) {
        document.getElementById("lTablePassErrorMes").style.display = "block";
        document.getElementById("lTablePassErrorMes").innerHTML = jQuery.i18n.prop("lminLengthError4");
        return false;
    }
    if (!(textBoxMaxLength("txtAccountName", 20) && textBoxMaxLength("txtAccountPassword", 20))) {
        document.getElementById("lTablePassErrorMes").style.display = "block";
        document.getElementById("lTablePassErrorMes").innerHTML = jQuery.i18n.prop("lmaxLengthError20");
        return false;
    }
    if (!deviceNameValidation(document.getElementById("txtAccountName").value)) {
        document.getElementById("lTablePassErrorMes").style.display = "block";
        document.getElementById("lTablePassErrorMes").innerHTML = jQuery.i18n.prop("ErrInvalidUserPass");
        return false;
    }
    if (!deviceNameValidation(document.getElementById("txtAccountPassword").value)) {
        document.getElementById("lTablePassErrorMes").style.display = "block";
        document.getElementById("lTablePassErrorMes").innerHTML = jQuery.i18n.prop("ErrInvalidUserPass");
        return false;
    }
    return true;
}

function deleteAccountItem(that) {
    var name = $(that).attr("name");
    postAccountItem(true, name);
}
function postAccountItem(isDeleted, name, password, authority) {
    var jsonData = {};
    var _name = encodeURIComponent(name);
    var _password = encodeURIComponent(password);
    jsonData.router_user_list = [{}];
    jsonData.router_user_list[0].username = _name;
    // delete
    if (isDeleted) {
        jsonData.account_action = "2";
        jsonData.router_user_list[0]["delete"] = "1";
    } else {
        //edit or add
        jsonData.account_action = "2";
        jsonData.router_user_list[0].password = _password;
        jsonData.router_user_list[0].authority = authority;
    }
    showWait();
    setTimeout(function () {
        postJSON("account_management_set", jsonData, function (data) {
            if (data.result == "success") {
                if (!isDeleted && _name == g_loginUsername) {
                    // setTimeout(function () {
                    //     window.location.href="index.html";
                    // },100);
                    logOut();
                } else {
                    $("#MBAccount_Popup").hide();
                    $.objAccountManage().onLoad(true);
                }
            }
        });
    }, 100);
}
function AddNewAccount() {
    if (document.getElementById("tableUserAccount").rows.length <= 4) {
        $("#MBAccount_Popup").show();
        $("#lTablePassErrorMes").hide();
        setAddBoxHeigth("MBAccount_Popup");
        document.getElementById("txtAccountName").readOnly = false;

        document.getElementById("txtAccountName").value = "";
        document.getElementById("txtAccountPassword").value = "";
        document.getElementById("txtReAccountPassword").value = "";

        $("#AccountGroupSelect").val(0);
        $("#AccountGroupSelect").attr("disabled", true);
        $("#txtAccountName").attr("readonly", false);
        $("#txtAccountName").attr("disabled", false);
        bEditAccount = false; //add account
    } else {
        showMsgBox(jQuery.i18n.prop("mAccountManage"), jQuery.i18n.prop("lAccountNumber"));
    }
}

function AccountClicked(that) {
    $("#MBAccount_Popup").show();
    $("#lTablePassErrorMes").hide();
    setAddBoxHeigth("MBAccount_Popup");
    var name = $(that).attr("name");
    for (var i = 0; i < router_user_list.length; i++) {
        l = router_user_list[i];
        if (name == l.username) {
            document.getElementById("txtAccountName").value = name;
            document.getElementById("txtAccountName").readonly = true;
            document.getElementById("txtAccountPassword").value = l.password;
            document.getElementById("txtReAccountPassword").value = decodeURIComponent(l.password);
            var authority;
            if (l.authority == "" || l.authority == undefined) {
                authority = "0";
            } else {
                authority = l.authority;
            }
            document.getElementById("AccountGroupSelect").value = authority;
            $("#AccountGroupSelect").attr("disabled", true);
            $("#txtAccountName").attr("disabled", true);
            $("#txtAccountName").attr("readonly", true);
            bEditAccount = true; //edit
        }
    }
}

function tablepasswordChanged() {
    document.getElementById("txtReAccountPassword").value = "";
    document.getElementById("lReAccountPassword").style.display = "block";
    document.getElementById("txtReAccountPassword").style.display = "block";
}

// -------------------------------------------------------------objAPN-----------------------------------------------------------------
var g_profile_name = [];
var g_profile_list = [];
var g_enableProfile;
var currentProfile;

var current_profile; //当前显示在页面上的
(function ($) {
    $.objAPN = function () {
        var that = this;
        var mtu_value;

        var defaultData = { auto_apn: "" };
        this.onLoad = function (flag) {
            g_profile_name = [];
            g_profile_list = [];
            if (flag) {
                that.displayControls();
                that.btnEvent();
                showHelp();
                clearErrorInfo();
            }
            that.showData();
            setDlgStyle();
        };
        this.showData = function () {
            callJSON("wan_apn_profile_info", function (json) {
                var profile_list = json.profile_list;
                g_profile_list = profile_list;
                var optionH = "";
                var rulename = jQuery.i18n.prop("txtWifiChannel_auto");
                if (profile_list.length > 0) {
                    for (var i = 0; i < profile_list.length; i++) {
                        var profile = profile_list[i];
                        g_profile_name.push(profile.profile_name);
                        if (profile.enable == "1") {
                            g_enableProfile = profile;
                            g_currentProfile = profile;

                            if (profile.profile_name == "PDN1") {
                                optionH += '<option value="' + profile.profile_name + '">' + rulename + "(" + jQuery.i18n.prop("lCurrent") + ")</option>";
                            } else {
                                optionH += '<option value="' + profile.profile_name + '">' + profile.profile_name + "(" + jQuery.i18n.prop("lCurrent") + ")</option>";
                            }
                        } else {
                            if (profile.profile_name == "PDN1") {
                                optionH += '<option value="' + profile.profile_name + '">' + rulename + "</option>";
                            } else {
                                optionH += '<option value="' + profile.profile_name + '">' + profile.profile_name + "</option>";
                            }
                        }
                    }
                    if (profile.profile_name == "PDN1") {
                        $("#CurrentApnDetail").hide();
                        $("#card_apn").show();
                    } else {
                        $("#CurrentApnDetail").show();
                        $("#card_apn").hide();
                    }

                    $("#profiles_select").html(optionH);
                    $("#profiles_select").val(g_currentProfile.profile_name);
                }
                that.showCurrentAPN(g_currentProfile);
                $("#card_apn_apn").val(json.apn);
            });
        };
        this.btnEvent = function () {
            $("#lt_btnCancel").unbind("click");
            $("#lt_btnCancel").bind("click", function () {
                $("#divAPNDlg").hide();
            });

            $("#addAPNclose").unbind("click");
            $("#addAPNclose").bind("click", function () {
                $("#divAPNDlg").hide();
            });

            $("#btn_addAPN").unbind("click");
            $("#btn_addAPN").bind("click", function () {
                if (g_profile_list.length >= 10) {
                    showMsgBox(jQuery.i18n.prop("mAPN"), jQuery.i18n.prop("lt_APN_max_length"));
                } else {
                    $("#apnContent input[type='text']").val("");
                    $("#apnContent input[type='password']").val("");
                    $("#apnContent input").attr("disabled", false);
                    $("#apnContent select").attr("disabled", false);
                    $("#apnContent input").css("backgroundColor", "#fff");
                    $("#apnContent select").css("backgroundColor", "#fff");
                    $("#divAPNDlg").show();
                    $("#lPdpSetError").hide();
                    setAddBoxHeigth("divAPNDlg");
                }
            });

            $("#profiles_select").unbind("change");
            $("#profiles_select").bind("change", function () {
                var name = $(this).val();
                var l;
                for (var i = 0; i < g_profile_list.length; i++) {
                    if (name == g_profile_list[i].profile_name) {
                        l = g_profile_list[i];
                        break;
                    }
                }
                g_currentProfile = l;
                that.showCurrentAPN(l);
                if (name == "PDN1") {
                    $("#CurrentApnDetail").hide();
                } else {
                    $("#CurrentApnDetail").show();
                }
            });

            $("#profile_name").unbind("input");
            $("#profile_name").bind("input", function () {
                that.checkProfileName();
            });

            $("#apn").unbind("input");
            $("#apn").bind("input", function () {
                that.checkAPN();
            });

            $("#username").unbind("input");
            $("#username").bind("input", function () {
                that.checkUsername();
            });

            $("#password").unbind("input");
            $("#password").bind("input", function () {
                that.checkPassword();
            });

            $("#btn_set_as_default").unbind("click");
            $("#btn_set_as_default").bind("click", function () {
                var profile_name = $("#profiles_select").val();
                var apn = $("#apn_apn").val();
                var iptype = $("#pdp_iptype_apn").val();
                var authtype2g3 = $("#authenticationtype_apn").val();
                var usr2g3 = $("#username_apn").val();
                var paswd2g3 = $("#password_apn").val();

                if (!validateRuleName(apn)) {
                    $("#lPdpSetError_apn").show();
                    $("#lPdpSetError_apn").html(jQuery.i18n.prop("EMPTY_APN_NAME"));
                    return;
                }
                if (usr2g3 == "" && IsChineseChar(usr2g3)) {
                    $("#lPdpSetError_apn").show();
                    $("#lPdpSetError_apn").html(jQuery.i18n.prop("lloginUsernameInvalide"));
                    return;
                }

                if ("" != usr2g3 && false == that.checkInputChar(usr2g3)) {
                    $("#lPdpSetError_apn").show();
                    $("#lPdpSetError_apn").html(jQuery.i18n.prop("lUsernameInvalidTip"));
                    return;
                }
                if (paswd2g3 != "" && IsChineseChar(paswd2g3)) {
                    $("#lPdpSetError_apn").show();
                    $("#lPdpSetError_apn").html(jQuery.i18n.prop("lInvalidPassword"));
                    return;
                }
                if (false == that.checkInputChar(paswd2g3)) {
                    $("#lPdpSetError_apn").show();
                    $("#lPdpSetError_apn").html(jQuery.i18n.prop("lpwdInvalidTip"));
                    return;
                }

                if (profile_name == g_currentProfile.profile_name && apn == g_currentProfile.apn && iptype == g_currentProfile.iptype && authtype2g3 == g_currentProfile.authtype2g3 && usr2g3 == g_currentProfile.usr2g3 && paswd2g3 == g_currentProfile.paswd2g3 && g_currentProfile.enable == "1") {
                    return;
                }
                var autoAPN = "";
                if (profile_name == "PDN1") {
                    autoAPN = "1";
                } else {
                    autoAPN = "0";
                }
                var jsonData = {};
                var profile = {};
                jsonData.profile_list = [];
                jsonData.auto_apn = autoAPN;
                jsonData.auto_apn_action = "1";
                profile.enable = "1";
                profile.profile_name = profile_name;
                profile["default"] = g_currentProfile["default"];
                profile.apn = apn;
                profile.lte_apn = apn;
                profile.iptype = iptype;
                profile.qci = "0";
                profile.authtype2g3 = authtype2g3;
                profile.usr2g3 = usr2g3;
                profile.paswd2g3 = paswd2g3;
                profile.authtype4g = authtype2g3;
                profile.usr4g = usr2g3;
                profile.paswd4g = paswd2g3;
                jsonData.profile_list.push(profile);
                if (g_currentProfile.enable != "1") {
                    var enable_profile = g_enableProfile;
                    enable_profile.enable = "0";
                    jsonData.profile_list.push(enable_profile);
                }
                showWait();
                setTimeout(function () {
                    postJSON("wan_set", jsonData, function (data) {
                        if (data.result == "success") {
                            showMsgBox(jQuery.i18n.prop("mAPN"), jQuery.i18n.prop("set_apn_success"));
                        }
                        that.onLoad(false);
                    });
                }, 100);
            });

            $("#btn_delAPN").unbind("click");
            $("#btn_delAPN").bind("click", function () {
                // var profileName=$("#profiles_select").val();
                var isCheck = false;
                var jsonData = {};
                jsonData.profile_list = [];
                var profile = { delete: "1" };

                if (g_currentProfile["default"] != "1" || g_currentProfile["enable"] != "1") {
                    profile.profile_name = g_currentProfile.profile_name;
                }
                jsonData.profile_list.push(profile);
                showWait();
                setTimeout(function () {
                    postJSON("wan_set", jsonData, function (data) {
                        that.onLoad(false);
                    });
                }, 100);
            });

            $("#btn_add_profile").unbind("click");
            $("#btn_add_profile").bind("click", function () {
                if (that.checkProfileName("add") && that.checkProfileNameRe("add") && that.checkAPN("add") && that.checkUsername("add") && that.checkPassword("add")) {
                    var authType = $("#authenticationtype").val();
                    var profileName = $("#profile_name").val();
                    var apn = $("#apn").val();
                    var iptype = $("#pdp_iptype").val();
                    var username = $("#username").val();
                    var password = $("#password").val();
                    if (authType == "NONE") {
                        username = username;
                        password = password;
                    }
                    var jsonData = {};
                    jsonData.profile_list = [];
                    var profile = {};
                    profile.profile_name = profileName;
                    profile.enable = "0";
                    profile["default"] = "0";
                    profile.apn = apn;
                    profile.lte_apn = apn;
                    profile.iptype = iptype;
                    profile.qci = "0";
                    profile.authtype2g3 = authType;
                    profile.usr2g3 = username;
                    profile.paswd2g3 = password;
                    profile.authtype4g = authType;
                    profile.usr4g = username;
                    profile.paswd4g = password;
                    jsonData.profile_list.push(profile);
                    showWait();
                    setTimeout(function () {
                        postJSON("wan_set", jsonData, function (data) {
                            if (data.result != "success") {
                                showMsgBox(jQuery.i18n.prop("mAPN"), jQuery.i18n.prop("ls_save_time_failure"));
                            } else {
                                $("#divAPNDlg").hide();
                                that.onLoad(false);
                            }
                        });
                    }, 100);
                }
            });
        };
        this.showCurrentAPN = function (l) {
            $("#pdp_iptype_apn").val(l.iptype);
            $("#apn_apn").val(l.apn);
            $("#authenticationtype_apn").val(l.authtype2g3);
            $("#username_apn").val(l.usr2g3);
            $("#password_apn").val(l.paswd2g3);
            if (l["default"] == "1") {
                $("#pdp_iptype_apn").prop("disabled", true);
                $("#apn_apn").prop("disabled", true);
                $("#authenticationtype_apn").prop("disabled", true);
                $("#username_apn").prop("disabled", true);
                $("#password_apn").prop("disabled", true);
                $("#CurrentApnDetail").hide();
                $("#card_apn").show();
            } else {
                $("#pdp_iptype_apn").prop("disabled", false);
                $("#apn_apn").prop("disabled", false);
                $("#authenticationtype_apn").prop("disabled", false);
                $("#username_apn").prop("disabled", false);
                $("#password_apn").prop("disabled", false);
                $("#CurrentApnDetail").show();
                $("#card_apn").hide();
            }
            if (l["enable"] == "1" || l["default"] == "1") {
                $("#btn_delAPN").prop("disabled", true);
            } else {
                $("#btn_delAPN").prop("disabled", false);
            }
        };
        this.checkProfileName = function () {
            $("#lPdpSetError").hide();
            var profieName = $("#profile_name").val();
            if ("" == profieName) {
                $("#lPdpSetError").show().text(jQuery.i18n.prop("EMPTY_PROFILE_NAME"));
                return false;
            }
            if (!/^[a-zA-Z][a-zA-Z0-9_]*$/.test(profieName) || !IsEnglishLetter(profieName)) {
                $("#lPdpSetError").show().text(jQuery.i18n.prop("lPdpProfileNameFormatError"));
                return false;
            }
            // 判断apn配置文件名称是否重复
            if (g_profile_name.includes(profieName)) {
                $("#lPdpSetError").show().text(jQuery.i18n.prop("It_APNNAME_ERROR"));
                return false;
            } else {
                return true;
            }
            return true;
        };
        this.checkProfileNameRe = function (type) {
            $("#lPdpSetError").hide();
            var profileName = $("#profile_name").val();
            if (type == "add") {
                for (var i = 0; i < g_profile_name; i++) {
                    if (profileName == g_profile_name[i]) {
                        $("#lPdpSetError").show();
                        $("#lPdpSetError").html(jQuery.i18n.prop("EXIST_PROFILE_NAME"));
                        return false;
                    }
                }
            } else if (type == "edit") {
                if (profileName != current_profile.profile_name) {
                    for (var i = 0; i < g_profile_name; i++) {
                        if (profileName == g_profile_name[i]) {
                            $("#lPdpSetError").show();
                            $("#lPdpSetError").html(jQuery.i18n.prop("EXIST_PROFILE_NAME"));
                            return false;
                        }
                    }
                }
            }
            return true;
        };
        this.checkAPN = function () {
            $("#lPdpSetError").hide();
            var apn = $("#apn").val();
            if (false == that.checkInputChar(apn) || -1 < apn.indexOf(" ") || apn == "") {
                $("#lPdpSetError").show().text(jQuery.i18n.prop("lApnNameInvalidTip"));
                return false;
            }
            return true;
        };
        this.checkUsername = function () {
            $("#lPdpSetError").hide();
            var username = $("#username").val();
            if ("" != username && false == that.checkInputChar(username)) {
                $("#lPdpSetError").show().text(jQuery.i18n.prop("lUsernameInvalidTip"));
                return false;
            }
            return true;
        };
        this.checkPassword = function () {
            $("#lPdpSetError").hide();
            var password = $("#password").val();
            if ("" != password && false == that.checkInputChar(password)) {
                $("#lPdpSetError").show().text(jQuery.i18n.prop("lpwdInvalidTip"));
                return false;
            }
            return true;
        };
        this.checkInputChar = function (str) {
            /*apn not support char*/
            var MACRO_SUPPORT_CHAR_MIN = 32;
            var MACRO_SUPPORT_CHAR_MAX = 126;
            var MACRO_NOT_SUPPORT_CHAR_COMMA = 44; //,
            var MACRO_NOT_SUPPORT_CHAR_QUOTATION_MARK = 34; //"
            var MACRO_NOT_SUPPORT_CHAR_COLON = 58; //:
            var MACRO_NOT_SUPPORT_CHAR_SEMICOLON = 59; //;
            var MACRO_NOT_SUPPORT_BACKSLASH_MARK = 92; //\
            var MACRO_NOT_SUPPORT_CHAR_38 = 38; //&
            var MACRO_NOT_SUPPORT_CHAR_37 = 37; //%
            var MACRO_NOT_SUPPORT_CHAR_43 = 43; //+
            var MACRO_NOT_SUPPORT_CHAR_39 = 39; //'
            var MACRO_NOT_SUPPORT_CHAR_60 = 60; //<
            var MACRO_NOT_SUPPORT_CHAR_62 = 62; //>
            var MACRO_NOT_SUPPORT_CHAR_63 = 63; //?
            var MACRO_NOT_SUPPORT_CHAR_94 = 94; //^

            var i;
            var char_i;
            var num_char_i;
            if (str == "") {
                return true;
            }
            for (i = 0; i < str.length; i++) {
                char_i = str.charAt(i);
                num_char_i = char_i.charCodeAt();
                if (num_char_i > MACRO_SUPPORT_CHAR_MAX || num_char_i <= MACRO_SUPPORT_CHAR_MIN) {
                    return false;
                } else if (MACRO_NOT_SUPPORT_CHAR_COMMA == num_char_i || MACRO_NOT_SUPPORT_CHAR_QUOTATION_MARK == num_char_i || MACRO_NOT_SUPPORT_CHAR_COLON == num_char_i || MACRO_NOT_SUPPORT_CHAR_SEMICOLON == num_char_i || MACRO_NOT_SUPPORT_BACKSLASH_MARK == num_char_i || MACRO_NOT_SUPPORT_CHAR_38 == num_char_i || MACRO_NOT_SUPPORT_CHAR_37 == num_char_i || MACRO_NOT_SUPPORT_CHAR_43 == num_char_i || MACRO_NOT_SUPPORT_CHAR_39 == num_char_i || MACRO_NOT_SUPPORT_CHAR_60 == num_char_i || MACRO_NOT_SUPPORT_CHAR_62 == num_char_i || MACRO_NOT_SUPPORT_CHAR_63 == num_char_i || MACRO_NOT_SUPPORT_CHAR_94 == num_char_i) {
                    return false;
                } else {
                    continue;
                }
            }
            return true;
        };
        this.displayControls = function () {
            $("#lt_apn_title").html(jQuery.i18n.prop("mAPN"));
            $("#lt_APN_AddTitle").html(jQuery.i18n.prop("mAPN"));
            $("#auto_apn").html(jQuery.i18n.prop("lt_interCon_autoApn"));
            $("#span_enabled").html(jQuery.i18n.prop("lt_optEnableSwitch"));
            $("#sapn_disabled").html(jQuery.i18n.prop("lt_optDisabledSwitch"));
            $("#btn_APNSave").val(jQuery.i18n.prop("lt_btnSave"));
            $("#btn_set_as_default").val(jQuery.i18n.prop("btn_set_as_default"));
            $("#lt_apnProfileNmae").html(jQuery.i18n.prop("lt_interCon_PdpProfileName"));
            $("#lt_apnSetting").html(jQuery.i18n.prop("lt_interCon_pdpList"));
            $("#lt_internetPDP").html(jQuery.i18n.prop("lt_interCon_pdpList"));
            $("#btn_addAPN").val(jQuery.i18n.prop("lt_interCon_addPdpProfile"));
            $("#btn_delAPN").val(jQuery.i18n.prop("lt_interCon_delPdpProfile"));
            $("#nconpt").html(jQuery.i18n.prop("lt_interCon_PdpType"));
            $("#nconpt_apn").html(jQuery.i18n.prop("lt_interCon_PdpType"));
            $("#dropdown_IPV4_apn").html(jQuery.i18n.prop("lt_interCon_OptIPV4"));
            $("#dropdown_IPV6_apn").html(jQuery.i18n.prop("lt_interCon_OptIPV6"));
            $("#dropdown_IPV4V6_apn").html(jQuery.i18n.prop("lt_interCon_OptIPV4V6"));
            $("#dropdown_IPV4").html(jQuery.i18n.prop("lt_interCon_OptIPV4"));
            $("#dropdown_IPV6").html(jQuery.i18n.prop("lt_interCon_OptIPV6"));
            $("#dropdown_IPV4V6").html(jQuery.i18n.prop("lt_interCon_OptIPV4V6"));
            $("#nconpn").html(jQuery.i18n.prop("ltProfilename"));
            $("#nconapn").html(jQuery.i18n.prop("ltAPNname"));
            $("#nconapn_apn").html(jQuery.i18n.prop("ltAPNname"));
            $("#nconauth").html(jQuery.i18n.prop("lt_interCon_2G3GAuthType"));
            $("#nconauth_apn").html(jQuery.i18n.prop("lt_interCon_2G3GAuthType"));
            $("#ncon_none").html(jQuery.i18n.prop("lt_vpn_protocol_none"));
            $("#ncon_pap").html(jQuery.i18n.prop("lt_apnAuth_pap"));
            $("#ncon_chap").html(jQuery.i18n.prop("lt_apnAuth_chap"));
            $("#nconuname").html(jQuery.i18n.prop("lCUsername"));
            $("#nconuname_apn").html(jQuery.i18n.prop("lCUsername"));
            $("#nconpass").html(jQuery.i18n.prop("lCPassword"));
            $("#nconpass_apn").html(jQuery.i18n.prop("lCPassword"));
            $("#btn_add_profile").val(jQuery.i18n.prop("lt_btnSave"));
            $("#lt_btnCancel").val(jQuery.i18n.prop("lt_btnCancel"));
            $("#card_apn_title").html(jQuery.i18n.prop("card_apn_title"));
            // $("#card_apn_title").html(jQuery.i18n.prop("card_apn_title"));
        };
        return this;
    };
})(jQuery);

function validateRuleName(Rulename) {
    if (!Rulename || Rulename == "") {
        return false;
    }

    if (IsChineseChar(Rulename)) {
        return false;
    }

    if (Rulename.toString().indexOf("%") != -1) return false;
    else if (Rulename.toString().indexOf("^") != -1) return false;
    else if (Rulename.toString().indexOf(";") != -1) return false;

    return true;
}

// -------------------------------------------------------------objTimeSetting-----------------------------------------------------------------
var g_bNtpEnabled;
(function ($) {
    $.objTimeSetting = function () {
        var that = this;
        this.onLoad = function (flag) {
            if (flag) {
                that.displayControls();
                that.btnEvent();
            }
            that.showData();
            setDlgStyle();
        };
        this.showData = function () {
            callJSON("time_setting_info", function (json) {
                $("#txt_year").val(json.year);
                $("#txt_month").val(json.month);
                $("#txt_day").val(json.day);
                $("#txt_hh").val(json.hour);
                $("#txt_mm").val(json.minute);
                $("#txt_ss").val(json.second);
                if (json.ntp_status == "enable") {
                    g_bNtpEnabled = true;
                    $("#radio_enabled").attr("checked", true);
                } else {
                    g_bNtpEnabled = false;
                    $("#radio_disabled").attr("checked", true);
                }
            });
        };
        this.btnEvent = function () {
            $("#btn_save").unbind("click");
            $("#btn_save").bind("click", function () {
                var year = $("#txt_year").val();
                var month = $("#txt_month").val();
                var day = $("#txt_day").val();
                var hour = $("#txt_hh").val().length == 1 ? "0" + $("#txt_hh").val() : $("#txt_hh").val();
                // if(hour.length==1){
                // 	hour="0"+hour;
                // }
                var minute = $("#txt_mm").val().length == 1 ? "0" + $("#txt_mm").val() : $("#txt_mm").val();
                var second = $("#txt_ss").val().length == 1 ? "0" + $("#txt_ss").val() : $("#txt_ss").val();
                if (that.time_validate(year, month, day, hour, minute, second)) {
                    var jsonData = {};
                    jsonData.year = year;
                    jsonData.month = month;
                    jsonData.day = day;
                    jsonData.hour = hour;
                    jsonData.minute = minute;
                    jsonData.second = second;
                    if ($("#radio_enabled").is(":checked")) {
                        jsonData.ntp_status = "enable";
                        if (g_bNtpEnabled) {
                            jsonData.ntp_action = "noaction";
                        } else {
                            jsonData.ntp_action = "enable";
                        }
                    } else {
                        jsonData.ntp_status = "disable";
                        if (!g_bNtpEnabled) {
                            jsonData.ntp_action = "noaction";
                        } else {
                            jsonData.ntp_action = "disable";
                        }
                    }
                    showWait();
                    setTimeout(function () {
                        postJSON("time_set", jsonData, function (data) {
                            if (data.result != "success") {
                                showMsgBox(jQuery.i18n.prop("mTimeSetting"), jQuery.i18n.prop("mTimeSetting"));
                            } else {
                                that.onLoad(false);
                            }
                        });
                    }, 100);
                }
            });
        };
        this.time_validate = function (year, month, day, hour, minute, second) {
            $("#time_error").hide();
            var time = hour + ":" + minute + ":" + second;
            if (year == "") {
                $("#time_error").show();
                $("#time_error").html(jQuery.i18n.prop("lEmptyYear"));
                return false;
            }
            if (month == "") {
                $("#time_error").show();
                $("#time_error").html(jQuery.i18n.prop("lEmptyMonth"));
                return false;
            }
            if (day == "") {
                $("#time_error").show();
                $("#time_error").html(jQuery.i18n.prop("lEmptyDay"));
                return false;
            }
            if (hour == "") {
                $("#time_error").show();
                $("#time_error").html(jQuery.i18n.prop("lEmptyHour"));
                return false;
            }
            if (minute == "") {
                $("#time_error").show();
                $("#time_error").html(jQuery.i18n.prop("lEmptyMinute"));
                return false;
            }
            if (second == "") {
                $("#time_error").show();
                $("#time_error").html(jQuery.i18n.prop("lEmptySecond"));
                return false;
            }

            if (!IsNumber(year) || year < 1970 || year > 2100) {
                $("#time_error").show();
                $("#time_error").html(jQuery.i18n.prop("lYearNumErr"));
                return false;
            }
            if (year.length > 4) {
                $("#time_error").show();
                $("#time_error").html(jQuery.i18n.prop("lYearLenErr"));
                return false;
            }
            if (!IsNumber_1(month)) {
                $("#time_error").show();
                $("#time_error").html(jQuery.i18n.prop("lMonthNumErr"));
                return false;
            }
            if (month.length > 2) {
                $("#time_error").show();
                $("#time_error").html(jQuery.i18n.prop("lMonthLenErr"));
                return false;
            }
            if (month > 12 || month <= 0) {
                $("#time_error").show();
                $("#time_error").html(jQuery.i18n.prop("lMonthLenErr"));
                return false;
            }
            if (!IsNumber_1(day)) {
                $("#time_error").show();
                $("#time_error").html(jQuery.i18n.prop("lDayNumErr"));
                return false;
            }
            if (day.length > 2 || day == 0) {
                $("#time_error").show();
                $("#time_error").html(jQuery.i18n.prop("lDayRangeErr"));
                return false;
            }
            if (month == 2) {
                if (is_leapyear(year)) {
                    if (day > 29) {
                        $("#time_error").show();
                        $("#time_error").html(jQuery.i18n.prop("lDayRangeLeap"));
                        return false;
                    }
                } else {
                    if (day > 28) {
                        $("#time_error").show();
                        $("#time_error").html(jQuery.i18n.prop("lDayRangeNonLeap"));
                        return false;
                    }
                }
            } else if (month <= 7) {
                if (month % 2 == 1) {
                    if (day > 31) {
                        $("#time_error").show();
                        $("#time_error").html(jQuery.i18n.prop("lDayRangeErr"));
                        return false;
                    }
                } else {
                    if (day > 30) {
                        $("#time_error").show();
                        $("#time_error").html(jQuery.i18n.prop("lDayRangeErr1"));
                        return false;
                    }
                }
            } else if (month > 7) {
                if (month % 2 == 0) {
                    if (day > 31) {
                        $("#time_error").show();
                        $("#time_error").html(jQuery.i18n.prop("lDayRangeErr"));
                        return false;
                    }
                } else {
                    if (day > 30) {
                        $("#time_error").show();
                        $("#time_error").html(jQuery.i18n.prop("lDayRangeErr1"));
                        return false;
                    }
                }
            }

            if (day > 31 || day < 1) {
                $("#time_error").show();
                $("#time_error").html(jQuery.i18n.prop("lDayRangeErr"));
                return false;
            }
            if (!IsTime(time)) {
                $("#time_error").show();
                $("#time_error").html(jQuery.i18n.prop("lt_TimeFormatError"));
                return false;
            }
            /*     if(!IsNumber(hour)){
                $("#time_error").show();
                $("#time_error").html(jQuery.i18n.prop('lHourNumErr'));
                return false;
            }
            if(hour>23 || hour<0){
                $("#time_error").show();
                $("#time_error").html(jQuery.i18n.prop('lHourRangeErr'));
                return false;
            }
            if(!IsNumber(minute)){
                $("#time_error").show();
                $("#time_error").html(jQuery.i18n.prop('lMinuteNumErr'));
                return false;
            }
            if(minute>59 || minute<0){
                $("#time_error").show();
                $("#time_error").html(jQuery.i18n.prop('lMinuteRangeErr'));
                return false;
            }
            if(!IsNumber(second)){
                $("#time_error").show();
                $("#time_error").html(jQuery.i18n.prop('lSecondNumErr'));
                return false;
            }
            if(second>59 || second<0){
                $("#time_error").show();
                $("#time_error").html(jQuery.i18n.prop('lSecondRangeErr'));
                return false;
            } */
            return true;
        };
        this.displayControls = function () {
            $("#lt_timeSetting_title").html(jQuery.i18n.prop("mTimeSetting"));
            $("#lt_yymmdd").html(jQuery.i18n.prop("lt_yymmdd"));
            $("#lt_hhmmss").html(jQuery.i18n.prop("lt_hhmmss"));
            $("#lt_ntpStatus").html(jQuery.i18n.prop("lt_ntpStatus"));
            $("#span_enabled").html(jQuery.i18n.prop("lt_optEnableSwitch"));
            $("#span_disabled").html(jQuery.i18n.prop("lt_optDisabledSwitch"));
            $("#btn_save").val(jQuery.i18n.prop("lt_btnSave"));
        };
        return this;
    };
})(jQuery);

// -------------------------------------------------------------objUSSD-----------------------------------------------------------------
var timeoutCount = 0;
var first_ussd = true;
(function ($) {
    $.objUSSD = function () {
        var that = this;
        this.onLoad = function (flag) {
            if (flag) {
                that.displayControls();
                that.btnEvent();
                showHelp();
            }
            that.showData();
            setDlgStyle();
        };
        this.showData = function () {
            $("#txt_show_ussd").val("");
            first_ussd = true;
        };
        this.btnEvent = function () {
            $("#lt_ussd_btnSend").unbind("click");
            $("#lt_ussd_btnSend").bind("click", function () {
                $("#ussd_error").hide();
                timeoutCount = 0;
                var txtUSSD = $.trim($("#txt_send_ussd").val());
                if (txtUSSD == "") {
                    $("#ussd_error").show();
                    $("#ussd_error").html(jQuery.i18n.prop("EmptyldialParam"));
                    return;
                }
                if (first_ussd && txtUSSD.substring(0, 1) != "*") {
                    txtUSSD = "*" + txtUSSD;
                }
                if (first_ussd && !validDialParam(txtUSSD)) {
                    $("#ussd_error").show();
                    $("#ussd_error").html(jQuery.i18n.prop("ldialParamError"));
                    return;
                }
                if (first_ussd) {
                    $("#lt_ussd_btnCancel").attr("disabled", false);
                    $("#lt_ussd_btnCancel").removeClass("disBtn");
                    $("#lt_ussd_btnCancel").attr("name", txtUSSD);
                }
                var jsonData = {};
                jsonData.action = "1";
                jsonData.ussd_param = txtUSSD;
                postJSON("ussd_set", jsonData, function (data) {
                    setTimeout(QueryUssdNetworkStatus, 1000);
                    showWait();
                    first_ussd = false;
                    setTimeout(function () {
                        closeWait();
                        $("#lt_USSD_Title").html(jQuery.i18n.prop("lt_ussd_messages_title"));
                    }, 1000);
                });
            });
            $("#lt_ussd_btnCancel").unbind("click");
            $("#lt_ussd_btnCancel").bind("click", function () {
                var jsonData = {};
                jsonData.action = "2";
                jsonData.ussd_param = $("#lt_ussd_btnCancel").attr("name");
                showWait();
                setTimeout(function () {
                    postJSON("ussd_set", jsonData, function (data) {
                        first_ussd = true;
                        $("#txt_send_ussd").val("");
                        $("#txt_show_ussd").val("");
                        $("#lt_ussd_btnSend").attr("disabled", false);
                        $("#lt_ussd_btnSend").removeClass("disBtn");
                        $("#txt_send_ussd").attr("disabled", false);
                        $("#txt_send_ussd").removeClass("dhcp_disabled");
                        $("#lt_ussd_btnCancel").attr("disabled", true);
                        $("#lt_ussd_btnCancel").addClass("disBtn");
                    });
                }, 100);
            });
        };
        this.displayControls = function () {
            $("#lt_USSD_title").html(jQuery.i18n.prop("mUSSD"));
            $("#lt_ussd_messages_title").html(jQuery.i18n.prop("lt_ussd_messages_title"));
            $("#lt_ussd_btnSend").val(jQuery.i18n.prop("btnSend"));
            $("#lt_ussd_btnCancel").val(jQuery.i18n.prop("lt_ussd_btnCancel"));
            $("#ussd_received").html(jQuery.i18n.prop("lTrafficStatsWANReceived"));
            $("#lt_notice_USSD").html(jQuery.i18n.prop("lt_notice_USSD"));
        };
        return this;
    };
})(jQuery);
function is_leapyear(year) {
    if (year % 400 == 0 || (year % 100 != 0 && year % 4 == 0)) return true;
    else return false;
}
function validDialParam(param) {
    param = param.trim();
    param = param.replace(/[\[\]]/g, "");
    if (param.length <= 0 || param.length > 100) {
        return false;
    }
    var regex = /[*]{1}\S{2,98}[#]{1}/;
    if (!regex.test(param)) return false;
    else return true;
}
function QueryUssdNetworkStatus() {
    callJSON("ussd_info", function (json) {
        closeWait();
        $("#ussd_error").hide();
        var ussdType = json.ussd_type;
        if (timeoutCount > 15) {
            $("#lt_ussd_btnSend").attr("disabled", true);
            $("#lt_ussd_btnSend").addClass("disBtn");
            $("#txt_send_ussd").attr("disabled", true);
            $("#txt_send_ussd").addClass("dhcp_disabled");
            return;
        }

        if ("" == ussdType) {
            ++timeoutCount;
            $("#lt_ussd_btnSend").attr("disabled", true);
            $("#lt_ussd_btnSend").addClass("disBtn");
            $("#txt_send_ussd").attr("disabled", true);
            $("#txt_send_ussd").addClass("dis");
            $("#ussd_error").show();
            $("#ussd_error").html(jQuery.i18n.prop("h1PleaseWait"));
            if (json.ussd_str.length > 0) {
                $("#txt_show_ussd").val(UniDecode(json.ussd_str));
            }
            setTimeout(QueryUssdNetworkStatus, 2000);
        } else if ("0" == ussdType || "1" == ussdType) {
            if (json.ussd_str.length > 0) {
                $("#txt_show_ussd").val(UniDecode(json.ussd_str));
            }
            $("#txt_send_ussd").val("");
            $("#lt_ussd_btnSend").attr("disabled", false);
            $("#lt_ussd_btnSend").removeClass("disBtn");
            $("#txt_send_ussd").attr("disabled", false);
            $("#txt_send_ussd").removeClass("dhcp_disabled");
        } else if ("2" == ussdType && json.ussd_str.length > 0) {
            if (json.ussd_str.length > 0) {
                $("#txt_show_ussd").val(UniDecode(json.ussd_str));
            }
            $("#txt_send_ussd").val("");
            $("#lt_ussd_btnSend").attr("disabled", false);
            $("#lt_ussd_btnSend").removeClass("disBtn");
            $("#txt_send_ussd").attr("disabled", false);
            $("#txt_send_ussd").removeClass("dhcp_disabled");
        } else {
            var msg;
            first_ussd = true;
            $("#txt_send_ussd").val("");
            $("#txt_show_ussd").val("");
            $("#lt_ussd_btnSend").attr("disabled", false);
            $("#lt_ussd_btnSend").removeClass("disBtn");
            $("#txt_send_ussd").attr("disabled", false);
            $("#txt_send_ussd").removeClass("dhcp_disabled");
            $("#lt_ussd_btnCancel").attr("disabled", true);
            $("#lt_ussd_btnCancel").addClass("disBtn");
            if ("2" == ussdType) {
                msg = jQuery.i18n.prop("lt_ussd_error_type2");
            } else if ("3" == ussdType) {
                msg = jQuery.i18n.prop("lt_ussd_error_type3");
            } else if ("4" == ussdType) {
                msg = jQuery.i18n.prop("lt_ussd_error_type4");
            } else if ("5" == ussdType) {
                msg = jQuery.i18n.prop("lt_ussd_error_type5");
            } else {
                msg = jQuery.i18n.prop("lt_ussd_unknow_error");
            }
            $("#ussd_error").show();
            $("#ussd_error").html(msg);
        }
    });
}
// -------------------------------------------------------------objUpdate-----------------------------------------------------------------
var progressInterval;
(function ($) {
    $.objUpdate = function () {
        var that = this;
        var moveIndex = 0;
        this.bytesPerChunk = 100000;
        var _pixels = 0;
        this.onLoad = function (flag) {
            if (flag) {
                that.displayControls();
                that.btnEvent();
                showHelp();
            }
            that.showData();
            setDlgStyle();
        };
        this.showData = function () {
            callJSON("firmware_info", function (json) {
                $("#lt_value_software_version").html(json.version_num);
                $("#lt_value_hardware_version").html(json.hardware_version);
                $("#lt_value_date_version").html(json.version_date);
            });
            if (GetBrowserType() == "IE9" || GetBrowserType() == "IE8") {
                $(".file").css({
                    position: "absolute",
                    top: "0px",
                    left: "2px",
                    filter: "alpha(opacity:0)",
                    opacity: "0",
                    "font-size": "35px",
                });
                //  $("#updateCfgFile").css({"position":"absolute","top":"4px","left":"-5px","filter":"alpha(opacity:0)","opacity": "0", "font-size":"35px"});
            }
        };
        this.btnEvent = function () {
            /* $("#yo_btn_browse").unbind("click");
            $("#yo_btn_browse").bind("click",function(){
                $("#softVersionUpdateFile").trigger('click');
            }); */

            $("#yo_update_cencelBtn").unbind("click");
            $("#yo_update_cencelBtn").bind("click", function () {
                $("#yo_btn_browse").show();
                $("#softVersionUpdateFile").val("");
                $("#yo_update_fileName").hide();
                $("#yo_update_updateBtn").hide();
                $("#yo_update_cencelBtn").hide();
            });

            $("#softVersionUpdateFile").unbind("change");
            $("#softVersionUpdateFile").bind("change", function () {
                $("#yo_update_updateBtn").hide();
                $("#yo_update_cencelBtn").hide();
                if (document.getElementById("softVersionUpdateFile").value != "") {
                    var filePath = $("#softVersionUpdateFile").val();
                    var fileName = filePath.substring(filePath.lastIndexOf("\\") + 1);
                    $("#yo_update_fileName").text(fileName);
                    $("#yo_btn_browse").hide();
                    $("#yo_update_fileName").show();
                    $("#yo_update_updateBtn").show();
                    $("#yo_update_cencelBtn").show();
                    //	$("#softVersionUpdateFile").prop("disabled",true);
                    /*  if(document.getElementById("softVersionUpdateFile").value.toString().lastIndexOf(".bin")==-1) {
                        $("#yo_update_updateBtn").attr("disabled",true);
                        $("#yo_update_updateBtn").addClass("disBtn");
                    }else {
                        $("#yo_update_updateBtn").attr("disabled",false);
                        $("#yo_update_updateBtn").removeClass("disBtn");
                    } */
                }
            });

            $("#yo_update_updateBtn").unbind("click");

            $("#yo_update_updateBtn").bind("click", function () {
                if (document.getElementById("softVersionUpdateFile").value != "") {
                    if (document.getElementById("softVersionUpdateFile").value.toString().lastIndexOf(".bin") == -1) {
                        showMsgBox(jQuery.i18n.prop("mUpdate"), jQuery.i18n.prop("lt_sw_binExtError"));
                    } else {
                        showBOX2(
                            jQuery.i18n.prop("mUpdate"),
                            jQuery.i18n.prop("lSoftwareWarningText"),
                            jQuery.i18n.prop("lt_btnOK"),
                            jQuery.i18n.prop("lt_btnCancel"),
                            function () {
                                ClosemBOX2();
                                $("#yo_update_progress").show();
                                $("#yo_update_updateBtn").hide();
                                $("#yo_update_cencelBtn").hide();
                                $("#yo_btn_browse").hide();
                                try {
                                    var url;
                                    var host = window.location.protocol + "//" + window.location.host;
                                    url = host + getHeader("GET", "upgrade");
                                    $("body").addClass("noClicks");
                                    $("#progress_bar").show();

                                    var fd = new FormData();
                                    fd.append("file", document.getElementById("softVersionUpdateFile").files[0]);
                                    var xhr = new XMLHttpRequest();
                                    xhr.upload.addEventListener("progress", uploadProgress, false);
                                    //xhr.addEventListener("load", uploadComplete, false);
                                    // xhr.addEventListener("error", uploadFailed, false);
                                    xhr.addEventListener("abort", uploadCanceled, false);
                                    xhr.open("POST", url); //修改成自己的接口
                                    xhr.send(fd);
                                } catch (e) {
                                    $("body").removeClass("noClicks");
                                    showMsgBox(jQuery.i18n.prop("mUpdate"), jQuery.i18n.prop("lt_sw_UpgradeFailedWarningLine1"));
                                }
                            },
                            function () {
                                ClosemBOX2();
                            }
                        );
                    }
                } else {
                    showMsgBox(jQuery.i18n.prop("mUpdate"), jQuery.i18n.prop("lt_sw_binExtError"));
                }
            });
        };
        function uploadProgress(evt) {
            if (evt.lengthComputable) {
                var percent = Math.round((evt.loaded * 100) / evt.total);
                document.getElementById("yo_update_progress_text").innerHTML = percent.toFixed(2) + "%";
                document.getElementById("yo_update_progress").style.width = percent.toFixed(2) + "%";
                uploadComplete();
            } else {
                document.getElementById("yo_update_progress_text").innerHTML = "unable to compute";
            }
        }
        function uploadFailed(evt) {
            alert("There was an error attempting to upload the file.");
        }
        function uploadCanceled(evt) {
            alert("The upload has been canceled by the user or the browser dropped the connection.");
        }
        this.progressRun = function (prbValue) {
            var intValue = parseInt(prbValue, 10); // Convert to int
            var prbMax = 100;
            if (intValue > prbMax) return;
            $("#yo_update_progress").css("width", intValue + "%");
            $("#yo_update_progress_text").html(intValue + "%");
        };
        this.moveProgress = function () {
            setInterval(function () {
                if (moveIndex == 18) {
                    moveIndex = 0;
                }
                $("#yo_update_progress_bg").css("background-position-x", moveIndex + "px");
                moveIndex++;
            }, 100);
        };
        this.displayControls = function () {
            $("#lt_commTraffic").html(jQuery.i18n.prop("mUpdate"));
            $("#lt_update_subTitle").html(jQuery.i18n.prop("lt_update_subTitle"));
            $("#lt_key_software_version").html(jQuery.i18n.prop("lt_sw_CurrentSoftVersion"));
            $("#lt_key_date_version").html(jQuery.i18n.prop("lt_sw_CurrentSoftwareDate"));
            $("#lt_key_hardware_version").html(jQuery.i18n.prop("lt_sw_hardwareVersion"));
            $("#lSoftwareWarningText").html(jQuery.i18n.prop("lSoftwareWarningText"));
            $("#yo_btn_browse").val(jQuery.i18n.prop("yo_btn_browse"));
            $("#yo_update_updateBtn").val(jQuery.i18n.prop("lt_sw_btnUpgrade"));
            $("#yo_update_cencelBtn").html(jQuery.i18n.prop("lt_btnCancel"));
            $("#lt_help_softupdate1").html(jQuery.i18n.prop("lt_help_softupdate1"));
            $("#lt_help_softupdate2").html(jQuery.i18n.prop("lt_help_softupdate2"));
            $("#lt_help_softupdate3").html(jQuery.i18n.prop("lt_help_softupdate3"));
        };
        return this;
    };
})(jQuery);
function uploadComplete() {
    /* 服务器端返回响应时候触发event事件*/
    //document.getElementById('result').innerHTML = evt.target.responseText;
    if (document.getElementById("yo_update_progress_text").innerHTML == "100%" || document.getElementById("yo_update_progress").style.width == "100%") {
        var successHTML = '<div id="yo_success_text"></div><div style="margin-top:15px; text-align:center;"><input class="btn-apply" style="width:60px;" id="yo_btn_success_ok" /></div>';
        showMsgBox(jQuery.i18n.prop("mUpdate"), successHTML);
        $("#yo_success_text").html(jQuery.i18n.prop("lt_sw_UpgradeSuccessWarningLine1") + "<br>" + jQuery.i18n.prop("lt_sw_UpgradeSuccessWarningLine2"));
        $("#yo_btn_success_ok").val(jQuery.i18n.prop("lt_btnOK"));
        $("#yo_btn_success_ok").unbind("click");
        $("#yo_btn_success_ok").bind("click", function () {
            CloseDlg();
        });
        setTimeout(function () {
            CloseDlg();
        }, 5000);
        showWait();
        setTimeout(function () {
            clearAuthheader();
        }, 25000);
    }
}
// -------------------------------------------------------------objChangePwd-----------------------------------------------------------------
(function ($) {
    $.objChangePwd = function () {
        var that = this;
        this.onLoad = function (flag, ifSim) {
            if (flag) {
                that.displayControls();
                that.showData();
                that.btnSave(ifSim);
                that.showPwd();
                showHelp();
            }
            setDlgStyle();
        };
        this.showData = function () {
            callJSON("account_management_info", function (json) {
                var multi_account = json.multi_account;
                curUsername = json.router_username;
                curPassword = json.router_password;
                $("#ChangeUser").show();
            });
        };
        this.btnSave = function (ifSim) {
            $("#lt_btUpdate").unbind("click");
            $("#lt_btUpdate").bind("click", function () {
                if (that.checkPwd()) {
                    showWait();
                    var item_name = encodeURIComponent(username);
                    var item_password = encodeURIComponent($("#txtNewPwd1").val());

                    var jsonData = {};
                    jsonData.account_action = "1";
                    jsonData.router_user_list = [{}];
                    jsonData.router_user_list[0].username = item_name;
                    jsonData.router_user_list[0].password = item_password;
                    jsonData.router_user_list[0].authority = "1";
                    setTimeout(function () {
                        postJSON("account_management_set", jsonData, function (data) {
                            setTimeout(function () {
                                window.location.href = "index.html";
                            }, 100);
                            logOut();
                        });
                    }, 100);
                }
            });
        };
        this.checkPwd = function () {
            $("#lAlertPasswordError").hide();
            var pwd1 = $("#txtNewPwd1").val();
            var pwd2 = $("#txtNewPwd2").val();
            //var currentPwd = $("#txtCurrentPwd1").val();
            /*if (currentPwd != g_loginPasswd) {
        $("#lAlertPasswordError").html(jQuery.i18n.prop("lloginfailed"));
        $("#lAlertPasswordError").show();
        return false;
      } else*/ if (pwd1 == "" || pwd2 == "") {
                $("#lAlertPasswordError").html(jQuery.i18n.prop("lPasswdIsEmpty"));
                $("#lAlertPasswordError").show();
                return false;
            } else if (pwd1 != pwd2) {
                $("#lAlertPasswordError").html(jQuery.i18n.prop("lPassErrorMes"));
                $("#lAlertPasswordError").show();
                return false;
            } else if (pwd1.indexOf(" ") >= 0) {
                $("#lAlertPasswordError").html(jQuery.i18n.prop("lPasswordError1"));
                $("#lAlertPasswordError").show();
                return false;
            } else if (pwd1.length < 4) {
                $("#lAlertPasswordError").html(jQuery.i18n.prop("lPasswordMinLengthError"));
                $("#lAlertPasswordError").show();
                return false;
            } else if (pwd1.length > 20) {
                $("#lAlertPasswordError").html(jQuery.i18n.prop("lPasswordMaxLengthError"));
                $("#lAlertPasswordError").show();
                return false;
            } else if (!deviceNameValidation(pwd1)) {
                $("#lAlertPasswordError").html(jQuery.i18n.prop("ErrAccountPwdChat"));
                $("#lAlertPasswordError").show();
                return false;
            }
            return true;
        };
        this.showPwd = function () {
            var flag = 0;
            $("#eye2").unbind("click");
            $("#eye2").bind("click", function () {
                if (flag == 0) {
                    $("#txtNewPwd1").attr("type", "text");
                    $("#eye2").attr("src", "../../images/open.png");
                    flag = 1;
                } else {
                    $("#txtNewPwd1").attr("type", "password");
                    $("#eye2").attr("src", "../../images/close.png");
                    flag = 0;
                }
            });
            $("#eye3").unbind("click");
            $("#eye3").bind("click", function () {
                if (flag == 0) {
                    $("#txtNewPwd2").attr("type", "text");
                    $("#eye3").attr("src", "../../images/open.png");
                    flag = 1;
                } else {
                    $("#txtNewPwd2").attr("type", "password");
                    $("#eye3").attr("src", "../../images/close.png");
                    flag = 0;
                }
            });
        };
        this.displayControls = function () {
            $("#lt_change_password_title").html(jQuery.i18n.prop("lt_change_password_title"));
            /*document.getElementById("lt_CurrentPassword").innerHTML =
        jQuery.i18n.prop("lt_CurrentPassword");*/
            document.getElementById("lt_EnterNewPassword1").innerHTML = jQuery.i18n.prop("lt_EnterNewPassword1");
            document.getElementById("lt_EnterNewPassword2").innerHTML = jQuery.i18n.prop("lt_EnterNewPassword2");
            $("#lt_btUpdate").val(jQuery.i18n.prop("lt_btUpdate"));
        };

        return this;
    };
})(jQuery);

//-----------------------------------------------------objTR069Setting---------------------------------------
(function ($) {
    $.objTR069Setting = function () {
        var that = this;
        this.onLoad = function (flag) {
            if (flag) {
                that.displayControls();
            }
            that.showData();
            setDlgStyle();
        };
        this.showData = function () {
            callJSON("acs_config_info", function (jsonOnes) {
                $("#tAcsUrl").val(jsonOnes.acs_url);
                $("#tAcsUsername").val(jsonOnes.acs_username);
                $("#tAcsPassword").val(jsonOnes.acs_password);
                $("#lt_Connection_num").val(jsonOnes.conn_req_port);
                $("#lt_TR069_ConnName_txt").val(jsonOnes.conn_name);
                $("#lt_TR069_ConnPwd_txt").val(jsonOnes.conn_psw);
                if (jsonOnes.inform_enable == "1") {
                    $("#divEnableInform").show();
                    $("#radEnableInform").attr("checked", true);
                    $("#radDisableInform").attr("checked", false);
                    $("#tInformInterval").val(jsonOnes.inform_interval);
                } else {
                    $("#radEnableInform").prop("checked", false);
                    $("#radDisableInform").attr("checked", true);
                    $("#divEnableInform").hide();
                }
                $("#lt_Connection_nummsg").hide();
            });
        };
        $("#btSaveTr069Param").unbind("click");
        $("#btSaveTr069Param").bind("click", function () {
            $("#lt_Connection_nummsg").hide();
            var acs_url = $("#tAcsUrl").val();
            var acs_tAcsUsername = $("#tAcsUsername").val();
            var acs_tAcsPassword = $("#tAcsPassword").val();
            var acs_Dis = $("#radEnableInform").is(":checked") ? "1" : "0";
            var acs_tInformInterval = $("#tInformInterval").val();
            var acs_conn_req_port = $("#lt_Connection_num").val();
            var acs_ConnUsername = $("#lt_TR069_ConnName_txt").val();
            var acs_ConnPassword = $("#lt_TR069_ConnPwd_txt").val();
            if (acs_conn_req_port < 0 || acs_conn_req_port > 65535) {
                $("#lt_Connection_nummsg").show();
                $("#lt_Connection_nummsg").html(jQuery.i18n.prop("lt_Connection_nummsg"));
                return false;
            }
            var jsonData = {};
            jsonData.acs_url = acs_url;
            jsonData.acs_username = acs_tAcsUsername;
            jsonData.acs_password = acs_tAcsPassword;
            jsonData.inform_enable = acs_Dis;
            jsonData.inform_interval = acs_tInformInterval;
            jsonData.conn_req_port = acs_conn_req_port;
            jsonData.conn_name = acs_ConnUsername;
            jsonData.conn_pwd = acs_ConnPassword;
            showWait();
            setTimeout(function () {
                postJSON("acs_config_info_set", jsonData, function (data) {
                    if (data.result == "success") {
                        showMsgBox(jQuery.i18n.prop("acs_setting_title"), jQuery.i18n.prop("acs_setting_title_success"));
                        that.onLoad(false);
                    } else {
                        showMsgBox(jQuery.i18n.prop("acs_setting_title"), jQuery.i18n.prop("acs_setting_title_error"));
                    }
                });
            }, 100);
        });
        this.displayControls = function () {
            $("#Tr069_title").html(jQuery.i18n.prop("mtr069Setting"));
            $("#lAcsUrl").html(jQuery.i18n.prop("lAcsUrl"));
            $("#lAcsUsername").html(jQuery.i18n.prop("lAcsUsername"));
            $("#lAcsPassword").html(jQuery.i18n.prop("lAcsPassword"));
            $("#lInformEnable").html(jQuery.i18n.prop("lInformEnable"));
            $("#lt_dhcp_stcEnableInform").html(jQuery.i18n.prop("lt_dhcp_stcEnableInform"));
            $("#lt_dhcp_stcDisableInform").html(jQuery.i18n.prop("lt_dhcp_stcDisableInform"));
            $("#lInformInterval").html(jQuery.i18n.prop("lInformInterval"));
            $("#btSaveTr069Param").html(jQuery.i18n.prop("btSaveTr069Param"));
            $("#lt_tr069_Connection").html(jQuery.i18n.prop("lt_tr069_Connection"));
            $("#lt_TR069_ConnName").html(jQuery.i18n.prop("lt_TR069_ConnName"));
            $("#lt_TR069_ConnPwd").html(jQuery.i18n.prop("lt_TR069_ConnPwd"));
        };
        function clearTabaleRows(tableId) {
            var i = document.getElementById(tableId).rows.length;
            while (i != 1) {
                document.getElementById(tableId).deleteRow(i - 1);
                i--;
            }
        }
        return this;
    };
})(jQuery);
function EnableInformChange() {
    $("#divEnableInform").show();
    $("#radEnableInform").attr("checked", true);
    $("#radDisableInform").attr("checked", false);
}

function DisableInformChange() {
    $("#divEnableInform").hide();
    $("#radEnableInform").attr("checked", false);
    $("#radDisableInform").attr("checked", true);
}
