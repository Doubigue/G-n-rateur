package com.example.mtn_box_manager

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
