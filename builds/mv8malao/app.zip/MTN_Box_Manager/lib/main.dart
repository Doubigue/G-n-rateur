import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:intl/intl.dart';

void main() => runApp(const MtnBoxApp());

const bg = Color(0xFF0A0D12);
const panel = Color(0xFF141A23);
const panel2 = Color(0xFF1B2430);
const accent = Color(0xFFFFC928);
const muted = Color(0xFF9BA8B8);
const green = Color(0xFF49D6A1);

class MtnBoxApp extends StatelessWidget {
  const MtnBoxApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'MTN Box Manager',
    theme: ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: bg,
      colorScheme: const ColorScheme.dark(primary: accent, surface: panel),
      fontFamily: 'Roboto',
      useMaterial3: true,
      cardTheme: const CardThemeData(color: panel, elevation: 0),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: panel2,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
      ),
    ),
    home: const HomePage(),
  );
}

class UsageEntry {
  final String date;
  final double gb;
  UsageEntry(this.date, this.gb);
  Map<String, dynamic> toJson() => {'date': date, 'gb': gb};
  factory UsageEntry.fromJson(Map<String, dynamic> j) => UsageEntry(j['date'] as String, (j['gb'] as num).toDouble());
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  bool moninternetVisited = false;
  String routerUrl = 'http://192.168.1.1';
  String routerModel = 'MTN CPE • R023';
  double packageGb = 51;
  double usedGb = 12.4;
  int monthlyBudget = 10000;
  bool alertEnabled = true;
  final List<Map<String, dynamic>> recharges = [];
  final List<UsageEntry> usage = [];
  final TextEditingController urlController = TextEditingController(text: 'http://192.168.1.1');
  final TextEditingController packageController = TextEditingController(text: '51');
  final TextEditingController usedController = TextEditingController(text: '12.4');
  final TextEditingController budgetController = TextEditingController(text: '10000');

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    setState(() {
      routerUrl = p.getString('routerUrl') ?? routerUrl;
      urlController.text = routerUrl;
      packageGb = p.getDouble('packageGb') ?? packageGb;
      usedGb = p.getDouble('usedGb') ?? usedGb;
      monthlyBudget = p.getInt('monthlyBudget') ?? monthlyBudget;
      alertEnabled = p.getBool('alertEnabled') ?? true;
      packageController.text = packageGb.toString();
      usedController.text = usedGb.toString();
      budgetController.text = monthlyBudget.toString();
      final raw = p.getString('recharges');
      if (raw != null) recharges.addAll((jsonDecode(raw) as List).cast<Map<String, dynamic>>());
      final rawUsage = p.getString('usage');
      if (rawUsage != null) usage.addAll((jsonDecode(rawUsage) as List).map((e) => UsageEntry.fromJson(Map<String, dynamic>.from(e))));
      if (usage.isEmpty) {
        final now = DateTime.now();
        for (int i = 6; i >= 0; i--) {
          final d = now.subtract(Duration(days: i));
          usage.add(UsageEntry(DateFormat('dd/MM').format(d), i == 0 ? usedGb : (0.8 + ((i * 7) % 19) / 10)));
        }
      }
    });
  }

  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('routerUrl', routerUrl);
    await p.setDouble('packageGb', packageGb);
    await p.setDouble('usedGb', usedGb);
    await p.setInt('monthlyBudget', monthlyBudget);
    await p.setBool('alertEnabled', alertEnabled);
    await p.setString('recharges', jsonEncode(recharges));
    await p.setString('usage', jsonEncode(usage.map((e) => e.toJson()).toList()));
  }

  void _toast(String text) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text), behavior: SnackBarBehavior.floating));

  @override
  Widget build(BuildContext context) {
    final pages = [
      _dashboard(), _usagePage(), _devicesPage(), _settingsPage(),
      moninternetVisited ? const MonInternetPage() : const SizedBox.shrink(),
    ];
    return Scaffold(
      body: SafeArea(child: Column(children: [
        if (tab != 4) _topBar(),
        Expanded(child: IndexedStack(index: tab, children: pages)),
      ])),
      bottomNavigationBar: NavigationBar(
        backgroundColor: panel, indicatorColor: accent.withOpacity(.15),
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() { tab = v; if (v == 4) moninternetVisited = true; }),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.grid_view_rounded), label: 'Accueil'),
          NavigationDestination(icon: Icon(Icons.query_stats_rounded), label: 'Données'),
          NavigationDestination(icon: Icon(Icons.devices_rounded), label: 'Appareils'),
          NavigationDestination(icon: Icon(Icons.tune_rounded), label: 'Réglages'),
          NavigationDestination(icon: Icon(Icons.public_rounded), label: 'Mon Internet'),
        ],
      ),
    );
  }

  Widget _topBar() => Padding(
    padding: const EdgeInsets.fromLTRB(20, 14, 20, 14),
    child: Row(children: [
      Container(width: 42, height: 42, decoration: BoxDecoration(color: accent, borderRadius: BorderRadius.circular(14)),
        child: const Icon(Icons.wifi_rounded, color: bg, size: 25)),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('MTN BOX', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
        Text(routerModel.toUpperCase(), style: const TextStyle(fontSize: 10, color: muted, letterSpacing: 1.7)),
      ])),
      IconButton(onPressed: () => _openRouter(), icon: const Icon(Icons.open_in_browser_rounded), tooltip: 'Ouvrir l’administration du routeur'),
    ]),
  );

  Widget _dashboard() => ListView(padding: const EdgeInsets.fromLTRB(18, 4, 18, 24), children: [
    Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(26),
        gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF293746), Color(0xFF121923)]),
        border: Border.all(color: Colors.white.withOpacity(.07)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Expanded(child: Text('TON INTERNET,\nSOUS CONTRÔLE.', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, height: 1.18))),
          Container(width: 56, height: 56, decoration: BoxDecoration(color: accent.withOpacity(.15), shape: BoxShape.circle),
            child: const Icon(Icons.router_rounded, color: accent, size: 31)),
        ]),
        const SizedBox(height: 22),
        Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Text(usedGb.toStringAsFixed(1), style: const TextStyle(fontSize: 39, fontWeight: FontWeight.w900)),
          const Padding(padding: EdgeInsets.only(bottom: 7, left: 6), child: Text('Go utilisés', style: TextStyle(color: muted))),
          const Spacer(),
          Text('${(packageGb - usedGb).clamp(0, packageGb).toStringAsFixed(1)} Go restants', style: const TextStyle(color: accent, fontWeight: FontWeight.w700)),
        ]),
        const SizedBox(height: 12),
        ClipRRect(borderRadius: BorderRadius.circular(20), child: LinearProgressIndicator(
          value: packageGb <= 0 ? 0 : (usedGb / packageGb).clamp(0, 1), minHeight: 9,
          backgroundColor: Colors.white.withOpacity(.1), color: accent)),
        const SizedBox(height: 10),
        Text('${packageGb <= 0 ? 0 : (usedGb / packageGb * 100).clamp(0, 100).round()} % du volume renseigné', style: const TextStyle(color: muted, fontSize: 12)),
      ]),
    ),
    const SizedBox(height: 16),
    Row(children: [
      Expanded(child: _metric(Icons.signal_cellular_alt_rounded, 'Réseau', 'À vérifier', 'Dans le routeur', green)),
      const SizedBox(width: 12),
      Expanded(child: _metric(Icons.devices_rounded, 'Appareils', 'À vérifier', 'Données du routeur', accent)),
    ]),
    const SizedBox(height: 12),
    Row(children: [
      Expanded(child: _metric(Icons.account_balance_wallet_rounded, 'Budget recharge', NumberFormat('#,##0', 'fr_FR').format(monthlyBudget) + ' F', 'FCFA / mois', accent)),
      const SizedBox(width: 12),
      Expanded(child: _metric(Icons.notifications_active_outlined, 'Alertes', alertEnabled ? 'Activées' : 'Désactivées', 'Sur tes saisies', green)),
    ]),
    const SizedBox(height: 22),
    _sectionTitle('Accès rapide', 'Gérer'),
    const SizedBox(height: 10),
    _actionTile(Icons.admin_panel_settings_outlined, 'Administration du box', 'Ouvrir la page locale du routeur', () => _openRouter()),
    _actionTile(Icons.add_card_rounded, 'Enregistrer une recharge', 'Montant, volume et date', _addRecharge),
    _actionTile(Icons.settings_ethernet_rounded, 'Paramètres de connexion', 'Adresse locale et volume du forfait', () => setState(() => tab = 3)),
    const SizedBox(height: 14),
    _notice('Les valeurs de consommation et de forfait sont saisies manuellement. Elles ne deviennent automatiques que si ton modèle expose une interface compatible.'),
  ]);

  Widget _metric(IconData icon, String title, String value, String caption, Color color) => Container(
    padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(20), border: Border.all(color: Colors.white.withOpacity(.04))),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, color: color, size: 21), const SizedBox(height: 12),
      Text(title, style: const TextStyle(color: muted, fontSize: 12)),
      const SizedBox(height: 5), Text(value, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
      const SizedBox(height: 4), Text(caption, style: const TextStyle(color: muted, fontSize: 10)),
    ]),
  );

  Widget _sectionTitle(String title, String right) => Row(children: [
    Expanded(child: Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800))),
    Text(right, style: const TextStyle(color: accent, fontSize: 12, fontWeight: FontWeight.w700)),
  ]);

  Widget _actionTile(IconData icon, String title, String subtitle, VoidCallback action) => Container(
    margin: const EdgeInsets.only(bottom: 9), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(17)),
    child: ListTile(onTap: action, leading: Container(width: 42, height: 42, decoration: BoxDecoration(color: accent.withOpacity(.12), borderRadius: BorderRadius.circular(13)), child: Icon(icon, color: accent)),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
      subtitle: Text(subtitle, style: const TextStyle(color: muted, fontSize: 11)),
      trailing: const Icon(Icons.chevron_right_rounded, color: muted)),
  );

  Widget _notice(String text) => Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: accent.withOpacity(.08), borderRadius: BorderRadius.circular(15), border: Border.all(color: accent.withOpacity(.22))),
    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Icon(Icons.info_outline_rounded, color: accent, size: 19), const SizedBox(width: 10),
      Expanded(child: Text(text, style: const TextStyle(color: Color(0xFFE5D7AC), fontSize: 11, height: 1.45))),
    ]));

  Widget _usagePage() => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('Consommation', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
    const SizedBox(height: 5), const Text('Historique local et suivi du forfait', style: TextStyle(color: muted)),
    const SizedBox(height: 20),
    Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(22)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Évolution sur 7 jours', style: TextStyle(fontWeight: FontWeight.w800)),
      const SizedBox(height: 24),
      SizedBox(height: 190, child: BarChart(BarChartData(
        borderData: FlBorderData(show: false),
        gridData: FlGridData(show: true, drawVerticalLine: false, getDrawingHorizontalLine: (_) => FlLine(color: Colors.white.withOpacity(.06))),
        titlesData: FlTitlesData(
          topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          leftTitles: AxisTitles(sideTitles: SideTitles(showTitles: true, reservedSize: 32, getTitlesWidget: (v, _) => Text(v.toInt().toString(), style: const TextStyle(color: muted, fontSize: 10)))),
          bottomTitles: AxisTitles(sideTitles: SideTitles(showTitles: true, getTitlesWidget: (v, _) {
            final i = v.toInt(); if (i < 0 || i >= usage.length) return const SizedBox.shrink();
            return Padding(padding: const EdgeInsets.only(top: 8), child: Text(usage[i].date, style: const TextStyle(color: muted, fontSize: 9)));
          })),
        ),
        barGroups: List.generate(usage.length, (i) => BarChartGroupData(x: i, barRods: [BarChartRodData(toY: usage[i].gb, color: accent, width: 14, borderRadius: BorderRadius.circular(5))])),
      ))),
      const SizedBox(height: 12),
      const Text('Les barres reflètent les valeurs enregistrées dans l’application, pas une lecture garantie en direct du routeur.', style: TextStyle(color: muted, fontSize: 11, height: 1.4)),
    ])),
    const SizedBox(height: 18),
    _sectionTitle('Forfait et volume', 'Modifier'),
    const SizedBox(height: 10),
    _actionTile(Icons.edit_note_rounded, 'Mettre à jour les données', 'Volume du forfait et consommation estimée', _editUsage),
    _actionTile(Icons.add_circle_outline_rounded, 'Ajouter une journée', 'Enregistrer une mesure dans l’historique', _addUsage),
    const SizedBox(height: 18),
    _sectionTitle('Historique des recharges', '${recharges.length} entrée(s)'),
    const SizedBox(height: 10),
    if (recharges.isEmpty) _empty('Aucune recharge enregistrée pour le moment.')
    else ...recharges.reversed.map((r) => Container(
      margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(15)),
      child: Row(children: [
        const Icon(Icons.receipt_long_rounded, color: accent), const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('${r['amount']} FCFA • ${r['volume']} Go', style: const TextStyle(fontWeight: FontWeight.w700)),
          Text('${r['date']}', style: const TextStyle(color: muted, fontSize: 11)),
        ])),
      ]),
    )),
  ]);

  Widget _devicesPage() => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('Appareils connectés', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
    const SizedBox(height: 7),
    const Text('La liste réelle doit être lue depuis l’interface de ton routeur.', style: TextStyle(color: muted, height: 1.4)),
    const SizedBox(height: 20),
    Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(22)), child: Column(children: [
      Container(width: 68, height: 68, decoration: BoxDecoration(color: accent.withOpacity(.12), shape: BoxShape.circle), child: const Icon(Icons.router_rounded, color: accent, size: 34)),
      const SizedBox(height: 14),
      const Text('Connexion à l’administration', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
      const SizedBox(height: 8),
      Text('Adresse configurée : $routerUrl', style: const TextStyle(color: muted, fontSize: 12), textAlign: TextAlign.center),
      const SizedBox(height: 18),
      SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _openRouter, icon: const Icon(Icons.open_in_browser_rounded), label: const Text('Afficher les appareils du routeur'))),
    ])),
    const SizedBox(height: 14),
    _notice('Le blocage d’un appareil n’est pas exécuté par cette application pour l’instant : les menus et mécanismes diffèrent selon les routeurs MTN. Utilise la fonction de blocage dans l’interface officielle du routeur si elle est disponible.'),
    const SizedBox(height: 14),
    _notice('Sécurité : ce modèle (R023) est livré avec l’identifiant et le mot de passe d’administration par défaut inscrits sur l’étiquette. Change-les dans l’interface du routeur, ainsi que la clé Wi-Fi d’origine.'),
    const SizedBox(height: 14),
    _actionTile(Icons.security_rounded, 'Sécurité Wi-Fi', 'Ouvrir les réglages de sécurité du routeur', _openRouter),
    _actionTile(Icons.restart_alt_rounded, 'Redémarrer le box', 'Ouvrir l’interface pour chercher la commande officielle', _openRouter),
  ]);

  Widget _settingsPage() => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('Réglages', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
    const SizedBox(height: 5), const Text('Configure l’accès local et tes repères de consommation.', style: TextStyle(color: muted)),
    const SizedBox(height: 20),
    _sectionTitle('Accès au routeur', 'Local'),
    const SizedBox(height: 10),
    TextField(controller: urlController, keyboardType: TextInputType.url, decoration: const InputDecoration(labelText: 'Adresse du routeur', hintText: 'http://192.168.1.1', prefixIcon: Icon(Icons.language_rounded))),
    const SizedBox(height: 10),
    SizedBox(width: double.infinity, child: FilledButton(onPressed: () {
      var value = urlController.text.trim();
      if (!value.startsWith('http://') && !value.startsWith('https://')) value = 'http://$value';
      final uri = Uri.tryParse(value);
      if (uri == null || uri.host.isEmpty) { _toast('Adresse invalide.'); return; }
      setState(() => routerUrl = value);
      _save(); _toast('Adresse enregistrée.'); 
    }, child: const Text('Enregistrer l’adresse'))),
    const SizedBox(height: 24),
    _sectionTitle('Suivi du forfait', 'Manuel'),
    const SizedBox(height: 10),
    TextField(controller: packageController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Volume du forfait (Go)', suffixText: 'Go')),
    const SizedBox(height: 10),
    TextField(controller: usedController, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Volume consommé estimé (Go)', suffixText: 'Go')),
    const SizedBox(height: 10),
    TextField(controller: budgetController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Budget mensuel de recharge', suffixText: 'FCFA')),
    const SizedBox(height: 10),
    SwitchListTile(value: alertEnabled, activeColor: accent, contentPadding: EdgeInsets.zero, title: const Text('Activer les rappels dans l’application'), subtitle: const Text('Basés sur les valeurs saisies', style: TextStyle(color: muted, fontSize: 12)), onChanged: (v) { setState(() => alertEnabled = v); _save(); }),
    SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: () {
      final p = double.tryParse(packageController.text.replaceAll(',', '.'));
      final u = double.tryParse(usedController.text.replaceAll(',', '.'));
      final b = int.tryParse(budgetController.text);
      if (p == null || u == null || b == null || p <= 0 || u < 0 || b < 0) { _toast('Vérifie les valeurs saisies.'); return; }
      setState(() { packageGb = p; usedGb = u; monthlyBudget = b; if (usage.isNotEmpty) usage[usage.length - 1] = UsageEntry(DateFormat('dd/MM').format(DateTime.now()), usedGb); });
      _save();
      if (alertEnabled && usedGb / packageGb >= .8) _toast('Alerte : tu as atteint au moins 80 % du volume renseigné.');
      else _toast('Suivi mis à jour.');
    }, icon: const Icon(Icons.save_rounded), label: const Text('Enregistrer le suivi'))),
    const SizedBox(height: 20),
    _notice('Ne saisis pas ici le mot de passe administrateur du routeur. L’application ouvre sa page locale ; l’authentification se fait directement dans cette page.'),
    const SizedBox(height: 18),
    _actionTile(Icons.open_in_browser_rounded, 'Ouvrir l’administration du routeur', 'Tu dois être connecté au Wi-Fi du box', _openRouter),
  ]);

  Widget _empty(String text) => Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16)), child: Text(text, style: const TextStyle(color: muted)));

  Future<void> _openRouter() async {
    final controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(NavigationDelegate(
        onWebResourceError: (e) { if (mounted) _toast('Page inaccessible. Vérifie le Wi-Fi et l’adresse du routeur.'); },
      ))
      ..loadRequest(Uri.parse(routerUrl));
    if (!mounted) return;
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => RouterWebPage(controller: controller, url: routerUrl)));
  }

  Future<void> _addRecharge() async {
    final amount = TextEditingController();
    final volume = TextEditingController();
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      backgroundColor: panel,
      title: const Text('Enregistrer une recharge'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: amount, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Montant (FCFA)')),
        const SizedBox(height: 10),
        TextField(controller: volume, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Volume reçu (Go)')),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Enregistrer'))],
    ));
    if (ok != true) return;
    final a = int.tryParse(amount.text);
    final v = double.tryParse(volume.text.replaceAll(',', '.'));
    if (a == null || v == null || a <= 0 || v <= 0) { _toast('Montant ou volume invalide.'); return; }
    setState(() => recharges.add({'amount': a, 'volume': v, 'date': DateFormat('dd/MM/yyyy').format(DateTime.now())}));
    await _save(); _toast('Recharge ajoutée à l’historique local.');
  }

  Future<void> _editUsage() async {
    final p = TextEditingController(text: packageGb.toString());
    final u = TextEditingController(text: usedGb.toString());
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      backgroundColor: panel, title: const Text('Mettre à jour le volume'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: p, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Forfait total (Go)')),
        const SizedBox(height: 10),
        TextField(controller: u, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Consommation (Go)')),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Enregistrer'))],
    ));
    if (ok != true) return;
    final pp = double.tryParse(p.text.replaceAll(',', '.'));
    final uu = double.tryParse(u.text.replaceAll(',', '.'));
    if (pp == null || uu == null || pp <= 0 || uu < 0) { _toast('Valeurs invalides.'); return; }
    setState(() { packageGb = pp; usedGb = uu; if (usage.isNotEmpty) usage[usage.length - 1] = UsageEntry(DateFormat('dd/MM').format(DateTime.now()), uu); });
    await _save();
  }

  Future<void> _addUsage() async {
    final c = TextEditingController(text: usedGb.toString());
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      backgroundColor: panel, title: const Text('Ajouter une mesure'),
      content: TextField(controller: c, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Consommation totale estimée (Go)')),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Ajouter'))],
    ));
    if (ok != true) return;
    final v = double.tryParse(c.text.replaceAll(',', '.'));
    if (v == null || v < 0) { _toast('Valeur invalide.'); return; }
    setState(() { usedGb = v; usage.add(UsageEntry(DateFormat('dd/MM').format(DateTime.now()), v)); if (usage.length > 7) usage.removeAt(0); });
    await _save();
  }
}

class RouterWebPage extends StatefulWidget {
  final WebViewController controller;
  final String url;
  const RouterWebPage({super.key, required this.controller, required this.url});
  @override State<RouterWebPage> createState() => _RouterWebPageState();
}

class _RouterWebPageState extends State<RouterWebPage> {
  bool _busy = false;

  Future<String?> _waitForBridgeResult() async {
    for (var i = 0; i < 30; i++) {
      await Future.delayed(const Duration(milliseconds: 200));
      try {
        final result = await widget.controller.runJavaScriptReturningResult('window.__mtnBoxBridgeResult || ""');
        var value = result.toString();
        if (value.isNotEmpty && value != 'null' && value != '""') {
          await widget.controller.runJavaScript('window.__mtnBoxBridgeResult = "";');
          if (value.startsWith('"') && value.endsWith('"')) {
            try { value = jsonDecode(value) as String; } catch (_) {}
          }
          return value;
        }
      } catch (_) {}
    }
    return null;
  }

  Future<void> _fetchDevices() async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      await widget.controller.runJavaScript('''
        window.__mtnBoxBridgeResult = "";
        if (typeof callJSON !== 'function') {
          window.__mtnBoxBridgeResult = JSON.stringify({error:'Cette interface ne fournit pas les fonctions API attendues. Connecte-toi à la page d’administration officielle.'});
        } else {
          callJSON('device_management_info', function(data) {
            window.__mtnBoxBridgeResult = JSON.stringify(data || {});
          });
        }
      ''');
      final raw = await _waitForBridgeResult();
      if (!mounted) return;
      if (raw == null) { _toast('Aucune réponse. Connecte-toi à l’administration du routeur puis réessaie.'); return; }
      final decoded = jsonDecode(raw);
      if (decoded is! Map || decoded['error'] != null) {
        _toast(decoded is Map ? '${decoded['error'] ?? 'Réponse du routeur invalide.'}' : 'Réponse du routeur invalide.');
        return;
      }
      final list = (decoded['client_list'] as List?) ?? const [];
      if (!mounted) return;
      setState(() => _busy = false);
      await showModalBottomSheet<void>(
        context: context, isScrollControlled: true, backgroundColor: panel,
        builder: (ctx) => SafeArea(child: SizedBox(height: MediaQuery.of(ctx).size.height * .72,
          child: Column(children: [
            Padding(padding: const EdgeInsets.all(18), child: Row(children: [
              const Expanded(child: Text('Appareils connectés', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
              Text('${list.whereType<Map>().where((d) => '${d['s']}' == '1').length} actifs', style: const TextStyle(color: green)),
            ])),
            const Divider(height: 1),
            Expanded(child: list.isEmpty ? const Center(child: Text('Aucun appareil retourné par le routeur.')) : ListView.builder(
              itemCount: list.length,
              itemBuilder: (ctx, index) {
                final device = Map<String, dynamic>.from(list[index] as Map);
                final mac = '${device['m'] ?? ''}';
                final name = '${device['n'] ?? 'Appareil sans nom'}';
                final ip = '${device['ip'] ?? 'IP inconnue'}';
                final status = '${device['s'] ?? '0'}';
                final blocked = status == '2';
                final active = status == '1';
                return ListTile(
                  leading: Icon(active ? Icons.devices_rounded : (blocked ? Icons.block_rounded : Icons.devices_other_rounded), color: blocked ? Colors.redAccent : (active ? green : muted)),
                  title: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis),
                  subtitle: Text('$ip\n$mac\n${blocked ? 'Bloqué' : (active ? 'Connecté' : 'Déconnecté')}', style: const TextStyle(color: muted, fontSize: 11)),
                  isThreeLine: true,
                  trailing: mac.isEmpty || '${device['ct'] ?? ''}' == 'USB' ? null : IconButton(
                    tooltip: blocked ? 'Débloquer' : 'Bloquer',
                    icon: Icon(blocked ? Icons.lock_open_rounded : Icons.block_rounded, color: blocked ? green : Colors.orangeAccent),
                    onPressed: () async {
                      final confirm = await showDialog<bool>(context: ctx, builder: (dctx) => AlertDialog(
                        backgroundColor: panel2,
                        title: Text(blocked ? 'Débloquer cet appareil ?' : 'Bloquer cet appareil ?'),
                        content: Text('$name\n$mac\nCette action modifie réellement les règles du routeur.'),
                        actions: [TextButton(onPressed: () => Navigator.pop(dctx, false), child: const Text('Annuler')), FilledButton(onPressed: () => Navigator.pop(dctx, true), child: const Text('Confirmer'))],
                      ));
                      if (confirm != true) return;
                      Navigator.pop(ctx);
                      await _setDeviceBlocked(mac, blocked ? '3' : '2');
                    },
                  ),
                );
              },
            )),
          ]))),
      );
    } catch (_) {
      if (mounted) _toast('Impossible de lire les appareils. Vérifie que tu es connecté à la page d’administration.');
    } finally { if (mounted) setState(() => _busy = false); }
  }

  Future<void> _setDeviceBlocked(String mac, String action) async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      await widget.controller.runJavaScript('''
        window.__mtnBoxBridgeResult = "";
        if (typeof postJSON !== 'function') {
          window.__mtnBoxBridgeResult = JSON.stringify({error:'Fonction de gestion non disponible.'});
        } else {
          postJSON('device_management_set', {action:'$action', mac:${jsonEncode(mac)}}, function(data) {
            window.__mtnBoxBridgeResult = JSON.stringify(data || {});
          });
        }
      ''');
      final raw = await _waitForBridgeResult();
      if (!mounted) return;
      if (raw == null) { _toast('Le routeur n’a pas confirmé la commande.'); return; }
      final result = jsonDecode(raw);
      if (result is Map && result['result'] == 'success') {
        _toast(action == '2' ? 'Appareil bloqué par le routeur.' : 'Appareil débloqué par le routeur.');
      } else {
        _toast('Commande refusée ou non prise en charge par le routeur.');
      }
    } catch (_) { if (mounted) _toast('Échec de la commande. Connecte-toi à l’administration du routeur.'); }
    finally { if (mounted) setState(() => _busy = false); }
  }

  Future<void> _rebootRouter() async {
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      backgroundColor: panel,
      title: const Text('Redémarrer le routeur ?'),
      content: const Text('La connexion Wi-Fi sera interrompue pendant le redémarrage. Cette commande n’est disponible que si l’interface chargée expose son API de gestion.'),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Redémarrer'))],
    ));
    if (ok != true || !mounted || _busy) return;
    setState(() => _busy = true);
    try {
      await widget.controller.runJavaScript('''
        window.__mtnBoxBridgeResult = "";
        if (typeof callJSON !== 'function') {
          window.__mtnBoxBridgeResult = JSON.stringify({error:'Cette interface ne fournit pas l’API de redémarrage.'});
        } else {
          callJSON('device_restart', function(data) {
            window.__mtnBoxBridgeResult = JSON.stringify(data || {requested:true});
          });
        }
      ''');
      final raw = await _waitForBridgeResult();
      if (!mounted) return;
      if (raw == null) _toast('Aucune confirmation du routeur. Vérifie l’interface et la connexion.');
      else {
        final r = jsonDecode(raw);
        if (r is Map && r['error'] != null) _toast('${r['error']}');
        else _toast('Commande de redémarrage envoyée. La reconnexion peut prendre un moment.');
      }
    } catch (_) { if (mounted) _toast('Le redémarrage n’est pas pris en charge sur cette interface.'); }
    finally { if (mounted) setState(() => _busy = false); }
  }

  void _toast(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Administration du box'), backgroundColor: panel,
      actions: [
        IconButton(tooltip: 'Appareils connectés', onPressed: _busy ? null : _fetchDevices, icon: const Icon(Icons.devices_rounded)),
        IconButton(tooltip: 'Redémarrer le routeur', onPressed: _busy ? null : _rebootRouter, icon: const Icon(Icons.restart_alt_rounded)),
        IconButton(tooltip: 'Actualiser', onPressed: () => widget.controller.reload(), icon: const Icon(Icons.refresh_rounded)),
      ]),
    body: Column(children: [
      Container(width: double.infinity, color: accent.withOpacity(.08), padding: const EdgeInsets.all(10),
        child: Text(_busy ? 'Communication avec le routeur…' : 'Page locale : ${widget.url} • Connecte-toi d’abord à l’administration. Les commandes utilisent la session officielle du routeur.', style: const TextStyle(color: Color(0xFFE5D7AC), fontSize: 11))),
      Expanded(child: WebViewWidget(controller: widget.controller)),
    ]),
  );
}

class MonInternetPage extends StatefulWidget {
  const MonInternetPage({super.key});
  @override State<MonInternetPage> createState() => _MonInternetPageState();
}

class _MonInternetPageState extends State<MonInternetPage> with AutomaticKeepAliveClientMixin {
  static const String url = 'http://moninternet.mtn.ci/';
  late final WebViewController controller;
  int progress = 0;
  bool error = false;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(bg)
      ..setNavigationDelegate(NavigationDelegate(
        onPageStarted: (_) { if (mounted) setState(() { error = false; progress = 0; }); },
        onProgress: (v) { if (mounted) setState(() => progress = v); },
        onPageFinished: (_) { if (mounted) setState(() => progress = 100); },
        onWebResourceError: (e) { if (mounted && (e.isForMainFrame ?? true)) setState(() => error = true); },
      ))
      ..loadRequest(Uri.parse(url));
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Column(children: [
      Container(
        color: panel,
        padding: const EdgeInsets.symmetric(horizontal: 4),
        child: Row(children: [
          IconButton(icon: const Icon(Icons.arrow_back_rounded), onPressed: () async { if (await controller.canGoBack()) controller.goBack(); }),
          IconButton(icon: const Icon(Icons.arrow_forward_rounded), onPressed: () async { if (await controller.canGoForward()) controller.goForward(); }),
          const Expanded(child: Text('Mon Internet MTN', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w700))),
          IconButton(icon: const Icon(Icons.home_rounded), onPressed: () => controller.loadRequest(Uri.parse(url))),
          IconButton(icon: const Icon(Icons.refresh_rounded), onPressed: () => controller.reload()),
        ]),
      ),
      if (progress < 100 && !error) LinearProgressIndicator(value: progress / 100, minHeight: 2, color: accent, backgroundColor: panel2),
      Expanded(
        child: error
            ? Center(child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.wifi_off_rounded, size: 48, color: muted),
                  const SizedBox(height: 12),
                  const Text('Page inaccessible. Vérifie ta connexion Internet.', textAlign: TextAlign.center, style: TextStyle(color: muted)),
                  const SizedBox(height: 16),
                  FilledButton(onPressed: () { setState(() => error = false); controller.loadRequest(Uri.parse(url)); }, child: const Text('Réessayer')),
                ]),
              ))
            : WebViewWidget(controller: controller),
      ),
    ]);
  }
}
