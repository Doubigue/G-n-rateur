package com.example.assistant

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import android.provider.Settings

class CommandExecutor(
    private val context: Context,
    private val notes: NoteManager,
    private val status: SystemStatusReporter,
    private val torch: TorchController
) {
    private val alarms = AlarmMemory(context)

    fun execute(cmd: Command): String = when (cmd) {
        is Command.Torch -> when {
            !torch.hasTorch -> "Ce téléphone n'a pas de lampe torche."
            torch.set(cmd.on) -> if (cmd.on) "Torche allumée." else "Torche éteinte."
            else -> "Impossible de contrôler la torche."
        }
        is Command.Setting -> setting(cmd)
        Command.Battery -> status.batteryReport()
        Command.Storage -> status.storageReport()
        Command.Help -> help()
        Command.ListAlarms -> listAlarms()
        Command.OpenAlarmApp -> if (openAlarmApp()) "J'ouvre les alarmes." else "Impossible d'ouvrir l'application d'alarme."
        is Command.DisableAlarm -> disableAlarm(cmd.hour, cmd.minute)
        is Command.Note -> if (cmd.text.isBlank()) "Que dois-je noter ?" else if (notes.addNote(cmd.text)) "Note enregistrée." else "Impossible d'enregistrer la note."
        is Command.Alarm -> setAlarm(cmd.hour, cmd.minute)
        is Command.OpenApp -> openApp(cmd.name)
        Command.PowerMenu -> if (PowerAccessibilityService.showPowerDialog()) "Menu d'alimentation affiché." else {
            launch(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); "Veuillez activer le service d'accessibilité de l'assistant."
        }
        is Command.Unknown -> "Je n'ai pas compris. Tu peux dire : quelles sont tes commandes ?"
    }

    private fun setting(cmd: Command.Setting): String {
        val action = when (cmd.type) {
            Command.Setting.Type.BLUETOOTH -> Settings.ACTION_BLUETOOTH_SETTINGS
            Command.Setting.Type.WIFI -> Settings.ACTION_WIFI_SETTINGS
            Command.Setting.Type.INTERNET -> Settings.ACTION_WIRELESS_SETTINGS
            Command.Setting.Type.MICROPHONE -> Settings.ACTION_PRIVACY_SETTINGS
        }
        val name = when (cmd.type) {
            Command.Setting.Type.BLUETOOTH -> "Bluetooth"
            Command.Setting.Type.WIFI -> "Wi-Fi"
            Command.Setting.Type.INTERNET -> "Internet"
            Command.Setting.Type.MICROPHONE -> "microphone"
        }
        // Android moderne interdit généralement aux applications ordinaires de basculer ces radios directement.
        return if (launch(Intent(action))) {
            if (cmd.on) "J'ouvre les réglages pour activer $name." else "J'ouvre les réglages pour désactiver $name."
        } else "Je ne peux pas ouvrir les réglages de $name."
    }

    private fun help() = "Tu peux dire : allume ou éteins la torche, le Bluetooth ou le Wi-Fi, ouvre une application, alarme sept heures trente, lis mes alarmes, éteins l'alarme, ouvre les alarmes, ou éteins le téléphone. Tu peux aussi me demander de te parler."

    private fun listAlarms(): String {
        val list = alarms.entries()
        if (list.isEmpty()) return "Je n'ai aucune alarme créée par moi en mémoire. J'ouvre les alarmes pour vérifier les alarmes du téléphone."
        val text = list.joinToString(", ") { formatTime(it.hour, it.minute) }
        return "Mes alarmes enregistrées sont : $text."
    }

    private fun disableAlarm(hour: Int?, minute: Int?): String {
        val list = alarms.entries()
        if (list.isEmpty()) return if (openAlarmApp()) "Je n'ai aucune alarme enregistrée par moi. L'application des alarmes est ouverte pour que tu choisisses celle à désactiver." else "Je n'ai aucune alarme enregistrée par moi."
        if (hour == null || minute == null) {
            return "J'ai trouvé : ${list.joinToString(", ") { formatTime(it.hour, it.minute) }}. Laquelle veux-tu désactiver ?"
        }
        val match = alarms.nearest(hour, minute)
        if (match == null || kotlin.math.abs(match.hour * 60 + match.minute - (hour * 60 + minute)) > 1) return "Je ne trouve pas cette alarme."
        alarms.remove(match.hour, match.minute)
        return if (openAlarmApp()) "J'ai trouvé l'alarme de ${formatTime(match.hour, match.minute)}. J'ouvre les alarmes : la désactivation finale doit être faite dans l'application d'horloge."
        else "J'ai retiré cette alarme de ma liste, mais je ne peux pas la désactiver directement avec les API Android standard."
    }

    private fun setAlarm(hour: Int?, minute: Int?): String {
        if (hour == null || minute == null) return "Je n'ai pas compris l'heure de l'alarme. Dis par exemple : alarme sept heures trente."
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minute)
            putExtra(AlarmClock.EXTRA_MESSAGE, "Assistant")
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        }
        return if (launch(intent)) {
            alarms.add(hour, minute)
            "Alarme programmée à ${formatTime(hour, minute)}."
        } else "Aucune application d'alarme trouvée."
    }

    private fun openAlarmApp(): Boolean = launch(Intent(AlarmClock.ACTION_SHOW_ALARMS))

    private fun formatTime(hour: Int, minute: Int) = if (minute == 0) "$hour heures" else "$hour heures $minute"

    private fun openApp(name: String): String {
        val pm = context.packageManager
        val target = VoiceCommandParser.normalizeName(name)
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        val best = pm.queryIntentActivities(launcher, 0).mapNotNull { ri ->
            val label = VoiceCommandParser.normalizeName(ri.loadLabel(pm).toString())
            val score = when { label == target -> 3; label.startsWith(target) -> 2; label.contains(target) -> 1; else -> 0 }
            if (score > 0) Triple(score, label.length, ri.activityInfo.packageName) else null
        }.sortedWith(compareByDescending<Triple<Int, Int, String>> { it.first }.thenBy { it.second }).firstOrNull()
        val intent = best?.let { pm.getLaunchIntentForPackage(it.third) } ?: return "Je ne trouve pas l'application $name."
        return if (launch(intent)) "J'ouvre $name." else "Impossible d'ouvrir $name."
    }

    private fun launch(intent: Intent): Boolean = try {
        context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
    } catch (_: ActivityNotFoundException) { false } catch (_: SecurityException) { false }
}
