package com.example.assistant

import android.content.Context
import java.util.Locale

/** Mémorise les alarmes créées par l'assistant afin de pouvoir les relire et les retrouver. */
class AlarmMemory(context: Context) {
    private val prefs = context.getSharedPreferences("assistant_alarms", Context.MODE_PRIVATE)

    data class Entry(val hour: Int, val minute: Int)

    fun add(hour: Int, minute: Int) {
        val all = entries().toMutableList()
        if (all.none { it.hour == hour && it.minute == minute }) all += Entry(hour, minute)
        save(all)
    }

    fun entries(): List<Entry> = prefs.getStringSet("times", emptySet()).orEmpty().mapNotNull {
        val p = it.split(":")
        if (p.size != 2) null else p[0].toIntOrNull()?.let { h -> p[1].toIntOrNull()?.let { m -> Entry(h, m) } }
    }.sortedWith(compareBy<Entry> { it.hour }.thenBy { it.minute })

    fun remove(hour: Int, minute: Int) {
        save(entries().filterNot { it.hour == hour && it.minute == minute })
    }

    fun nearest(hour: Int, minute: Int): Entry? = entries().minByOrNull {
        kotlin.math.abs((it.hour * 60 + it.minute) - (hour * 60 + minute))
    }

    private fun save(list: List<Entry>) {
        prefs.edit().putStringSet("times", list.map { String.format(Locale.US, "%02d:%02d", it.hour, it.minute) }.toSet()).apply()
    }
}
