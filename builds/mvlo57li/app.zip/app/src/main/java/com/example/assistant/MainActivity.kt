package com.example.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

/** Écran de configuration : permissions, import du modèle Vosk, accessibilité et assistant. */
class MainActivity : AppCompatActivity() {

    private lateinit var statusView: TextView

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh() }

    private val modelPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri == null) return@registerForActivityResult
            importModel(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = dp(20)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        statusView = TextView(this).apply { textSize = 16f; setPadding(0, 0, 0, dp(12)) }
        root.addView(TextView(this).apply { text = "Assistant vocal hors-ligne"; textSize = 22f })
        root.addView(statusView)

        root.addView(button("1. Autoriser micro et notifications") { requestRuntimePermissions() })
        root.addView(button("2. Autoriser l'affichage par-dessus les autres apps") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        root.addView(button("3. Activer le service d'accessibilité") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("📦 Importer le modèle Vosk (.zip)") {
            modelPicker.launch(arrayOf("application/zip", "application/octet-stream", "*/*"))
        })
        root.addView(button("▶ Démarrer l'assistant") { startAssistant() })
        root.addView(commandList())
        root.addView(button("■ Arrêter l'assistant") {
            stopService(Intent(this, FloatingWidgetService::class.java))
            statusView.postDelayed({ refresh() }, 400)
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun importModel(uri: Uri) {
        Toast.makeText(this, "Import du modèle en cours…", Toast.LENGTH_LONG).show()
        Thread {
            val result = VoskEngine.importZip(this, uri)
            runOnUiThread {
                result.fold(
                    onSuccess = {
                        val wasRunning = FloatingWidgetService.isRunning
                        if (wasRunning) stopService(Intent(this, FloatingWidgetService::class.java))
                        Toast.makeText(
                            this,
                            if (wasRunning) "Modèle importé. Relancez l'assistant pour l'utiliser."
                            else "Modèle Vosk importé avec succès.",
                            Toast.LENGTH_LONG
                        ).show()
                        refresh()
                    },
                    onFailure = {
                        Toast.makeText(this, "Échec de l'import : ${it.message ?: "fichier invalide"}", Toast.LENGTH_LONG).show()
                        refresh()
                    }
                )
            }
        }.start()
    }

    private fun startAssistant() {
        when {
            !hasMic() -> requestRuntimePermissions()
            !Settings.canDrawOverlays(this) ->
                Toast.makeText(this, "Autorisez d'abord l'affichage par-dessus les autres apps (étape 2).", Toast.LENGTH_LONG).show()
            !VoskEngine.isModelInstalled(this) ->
                Toast.makeText(this, "Importez d'abord le modèle Vosk avec le bouton 📦.", Toast.LENGTH_LONG).show()
            else -> {
                ContextCompat.startForegroundService(this, Intent(this, FloatingWidgetService::class.java))
                statusView.postDelayed({ refresh() }, 400)
            }
        }
    }

    private fun requestRuntimePermissions() {
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        permissionLauncher.launch(perms.toTypedArray())
    }

    private fun hasMic() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun refresh() {
        fun mark(ok: Boolean) = if (ok) "✔" else "✘"
        statusView.text = buildString {
            appendLine("${mark(hasMic())} Micro")
            appendLine("${mark(Settings.canDrawOverlays(this@MainActivity))} Affichage par-dessus les apps")
            appendLine("${mark(PowerAccessibilityService.instance != null)} Service d'accessibilité")
            appendLine("${mark(VoskEngine.isModelInstalled(this@MainActivity))} Modèle Vosk importé")
            append("${mark(FloatingWidgetService.isRunning)} Assistant en cours d'exécution")
        }
    }

    private fun commandList() = TextView(this).apply {
        textSize = 15f
        setPadding(0, dp(18), 0, dp(18))
        text = """COMMANDES VOCALES

TORCHE / LAMPE
• Allume la torche / lampe / flash
• Éteins la torche / lampe / flash

BLUETOOTH / WI-FI / INTERNET
• Allume le Bluetooth
• Éteins le Bluetooth
• Allume le Wi-Fi
• Éteins le Wi-Fi
• Active / désactive Internet
• Active / désactive le microphone

APPLICATIONS
• Ouvre WhatsApp
• Ouvre [nom de n'importe quelle application]

ALARMES
• Alarme sept heures trente
• Alarme 7 heures 30
• Lis mes alarmes
• Ouvre mes alarmes
• Éteins l'alarme
• Éteins l'alarme de sept heures trente

TÉLÉPHONE
• Éteins le téléphone
• Redémarre le téléphone

CONVERSATION
• Bonjour / Salut
• Ça va ?
• Qui es-tu ?
• Quelles sont tes commandes ?
• Merci
"""
    }

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        setOnClickListener { onClick() }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
