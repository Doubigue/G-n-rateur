# System Monitor — Android (Kotlin, MVVM, Material 3)

## Ouvrir et compiler
1. Android Studio (Ladybug 2024.2 ou plus récent) → *Open* → dossier `SysMonitor`.
2. Laisser la synchronisation Gradle se terminer (JDK 17).
   Si `gradlew` est absent : *Tools ▸ Gradle ▸ Create Wrapper*, ou `gradle wrapper --gradle-version 8.9`.
3. Lancer sur un appareil / émulateur Android 8.0+ (API 26+).

## Permissions système à accorder UNE FOIS par ADB (facultatif)
Sans elles, l'analyseur de wakelocks et la liste des services actifs d'autres applications
restent indisponibles (Android interdit `dumpsys` aux applications tierces) :

    adb shell pm grant com.example.sysmonitor android.permission.DUMP
    adb shell pm grant com.example.sysmonitor android.permission.PACKAGE_USAGE_STATS

## Architecture
    data/      Lecteurs système (RAM, stockage, CPU, thermique, batterie, réseau), dumpsys,
               audit des applications, root, SQLite (journal + presse-papiers chiffré), préférences
    service/   MonitorService (alertes), WebServerService (NanoHTTPD), QuickTileService, AlertNotifier
    widget/    StatsWidget (écran d'accueil)
    ui/        MainActivity, AlertActivity (écran verrouillé), thème Material 3, composants
    ui/screens Système · Batterie · Réseau · Sécurité · Journal · Paramètres
    ui/viewmodel  MonitorViewModel, SecurityViewModel, LogsViewModel

## Serveur web local
Activer dans l'onglet *Réseau*, puis ouvrir l'URL affichée (avec le jeton `?t=…`) depuis un PC
sur le même Wi-Fi. HTTP non chiffré : réseau de confiance uniquement.
