package com.example.sysmonitor.data

import android.content.Context
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.NetworkCapabilities
import android.os.SystemClock
import android.net.TrafficStats
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.URL

object NetworkReader {

    fun read(ctx: Context): NetworkInfo {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val net = cm.activeNetwork ?: return NetworkInfo("Hors ligne", null, false, false)
        val caps = cm.getNetworkCapabilities(net)
        val type = when {
            caps == null -> "Inconnu"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Données mobiles"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "VPN"
            else -> "Autre"
        }
        // NET_CAPABILITY_VALIDATED : Android a lui-même validé l'accès Internet (hors portail captif)
        val validated = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true
        return NetworkInfo(type, ipv4(cm.getLinkProperties(net)), validated, true)
    }

    /** IPv4 du réseau local (Wi-Fi / Ethernet), utile pour l'URL du serveur web. */
    @Suppress("DEPRECATION")
    fun lanIp(ctx: Context): String? {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        for (n in cm.allNetworks) {
            val caps = cm.getNetworkCapabilities(n) ?: continue
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
            ) {
                ipv4(cm.getLinkProperties(n))?.let { return it }
            }
        }
        // Repli (ex. appareil en point d'accès Wi-Fi)
        return runCatching {
            NetworkInterface.getNetworkInterfaces().toList()
                .filter { it.isUp && !it.isLoopback && listOf("wlan", "ap", "eth").any { p -> it.name.startsWith(p) } }
                .flatMap { it.inetAddresses.toList() }
                .firstOrNull { it is Inet4Address }
                ?.hostAddress
        }.getOrNull()
    }

    private fun ipv4(lp: LinkProperties?): String? =
        lp?.linkAddresses?.map { it.address }
            ?.firstOrNull { it is Inet4Address && !it.isLoopbackAddress }
            ?.hostAddress
}

/**
 * Test d'accès Internet RÉEL : requête HTTPS sur l'endpoint "generate_204" (utilisé par Android lui-même).
 * Un code 204 = Internet OK ; tout autre code (200/302…) = portail captif ou filtrage.
 */
object InternetProbe {
    private const val URL_204 = "https://connectivitycheck.gstatic.com/generate_204"

    suspend fun check(ctx: Context): ProbeResult = withContext(Dispatchers.IO) {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val net = cm.activeNetwork ?: return@withContext ProbeResult(false, null, "Aucun réseau actif")
        val start = SystemClock.elapsedRealtime()
        try {
            // Network.openConnection force l'utilisation du réseau actif (utile avec Wi-Fi sans Internet)
            val conn = net.openConnection(URL(URL_204)) as HttpURLConnection
            conn.connectTimeout = 4000
            conn.readTimeout = 4000
            conn.instanceFollowRedirects = false
            conn.useCaches = false
            val code = conn.responseCode
            conn.disconnect()
            val ms = SystemClock.elapsedRealtime() - start
            if (code == 204) ProbeResult(true, ms, "Accès Internet fonctionnel")
            else ProbeResult(false, ms, "Réponse inattendue ($code) : portail captif ?")
        } catch (e: IOException) {
            ProbeResult(false, null, "Échec : ${e.javaClass.simpleName}")
        }
    }
}

/** Calcul de débit à partir de TrafficStats (octets cumulés depuis le démarrage). */
class BandwidthMeter {
    private var lastRx = TrafficStats.getTotalRxBytes()
    private var lastTx = TrafficStats.getTotalTxBytes()
    private var lastTime = SystemClock.elapsedRealtime()

    fun sample(): Bandwidth {
        val now = SystemClock.elapsedRealtime()
        val rx = TrafficStats.getTotalRxBytes()
        val tx = TrafficStats.getTotalTxBytes()
        val dt = (now - lastTime).coerceAtLeast(1L)
        val result = if (rx < 0 || tx < 0 || lastRx < 0 || lastTx < 0) {
            Bandwidth(0, 0) // TrafficStats.UNSUPPORTED
        } else {
            Bandwidth(
                downBps = ((rx - lastRx) * 1000 / dt).coerceAtLeast(0),
                upBps = ((tx - lastTx) * 1000 / dt).coerceAtLeast(0)
            )
        }
        lastRx = rx; lastTx = tx; lastTime = now
        return result
    }
}
