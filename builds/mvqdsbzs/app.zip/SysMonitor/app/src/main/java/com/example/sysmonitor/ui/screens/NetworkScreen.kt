package com.example.sysmonitor.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.sysmonitor.data.formatSpeed
import com.example.sysmonitor.ui.InfoCard
import com.example.sysmonitor.ui.KeyValue
import com.example.sysmonitor.ui.LoadingBox
import com.example.sysmonitor.ui.ScreenColumn
import com.example.sysmonitor.ui.viewmodel.MonitorViewModel

/** Réseau actif, test Internet réel, bande passante en direct et serveur web local. */
@Composable
fun NetworkScreen(vm: MonitorViewModel) {
    val snap by vm.snapshot.collectAsStateWithLifecycle()
    val probe by vm.probe.collectAsStateWithLifecycle()
    val probing by vm.probing.collectAsStateWithLifecycle()
    val webRunning by vm.webRunning.collectAsStateWithLifecycle()
    val s = snap
    if (s == null) {
        LoadingBox()
        return
    }
    val n = s.network
    // Force le recalcul de l'URL après régénération du jeton
    var tokenVersion by remember { mutableIntStateOf(0) }
    val url = remember(n.ip, webRunning, tokenVersion) { vm.webUrl() }

    ScreenColumn {
        InfoCard("Connexion active") {
            KeyValue("Type", n.type)
            KeyValue("Adresse IP locale", n.ip ?: "—")
            KeyValue("Validé par Android", if (n.validated) "Oui" else "Non")
        }

        InfoCard("Test d'accès Internet réel") {
            val p = probe
            if (p == null) {
                Text(if (probing) "Test en cours…" else "Aucun test effectué")
            } else {
                Text(
                    p.detail,
                    style = MaterialTheme.typography.titleSmall,
                    color = if (p.ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                )
                p.latencyMs?.let { KeyValue("Latence", "$it ms") }
            }
            Button(onClick = { vm.runProbe() }, enabled = !probing) {
                Text(if (probing) "Test en cours…" else "Tester maintenant")
            }
        }

        InfoCard("Bande passante en direct") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                SpeedBlock("↓ Téléchargement", formatSpeed(s.bandwidth.downBps))
                SpeedBlock("↑ Envoi", formatSpeed(s.bandwidth.upBps))
            }
        }

        InfoCard("Serveur web local") {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(if (webRunning) "Serveur actif" else "Serveur arrêté")
                Switch(checked = webRunning, onCheckedChange = { vm.setWebServer(it) })
            }
            Text(
                "Consultez ce tableau de bord depuis un navigateur PC connecté au même réseau Wi-Fi.",
                style = MaterialTheme.typography.bodySmall
            )
            if (webRunning) {
                SelectionContainer {
                    Text(url, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodyMedium)
                }
                OutlinedButton(onClick = {
                    vm.regenerateToken()
                    tokenVersion++
                }) { Text("Régénérer le jeton d'accès") }
            }
            Text(
                "Protocole HTTP non chiffré, protégé par jeton : à n'utiliser que sur un réseau de confiance " +
                    "(jamais sur un Wi-Fi public). Le presse-papiers n'est jamais exposé.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun SpeedBlock(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.headlineSmall)
    }
}
