package com.example.sysmonitor.data

import android.content.ClipboardManager
import android.content.Context

/**
 * Capture le contenu du presse-papiers.
 *
 * Restriction Android 10+ : une application ne peut lire le presse-papiers que lorsqu'elle a le focus
 * (ou si elle est le clavier par défaut). La capture se fait donc :
 *  - à chaque retour au premier plan (MainActivity.onWindowFocusChanged) ;
 *  - via le listener du service de surveillance (effectif sur Android ≤ 9 uniquement).
 *
 * Respect de la vie privée : les contenus marqués "sensibles" par l'application source
 * (mots de passe, Android 13+) ne sont jamais enregistrés.
 */
object ClipboardTracker {
    private const val EXTRA_IS_SENSITIVE = "android.content.extra.IS_SENSITIVE"

    fun capture(ctx: Context) {
        val cm = ctx.getSystemService(ClipboardManager::class.java) ?: return
        val clip = runCatching { cm.primaryClip }.getOrNull() ?: return
        if (clip.itemCount == 0) return
        val sensitive = clip.description.extras?.getBoolean(EXTRA_IS_SENSITIVE, false) == true
        if (sensitive) return
        val text = clip.getItemAt(0).coerceToText(ctx)?.toString()?.trim().orEmpty()
        if (text.isNotEmpty()) ClipStore.add(ctx, text)
    }
}
