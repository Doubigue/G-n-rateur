package com.example.sysmonitor.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.sysmonitor.data.ClipEntry
import com.example.sysmonitor.data.LogEntry
import com.example.sysmonitor.ui.viewmodel.LogsViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Journal des événements (export .txt) et historique du presse-papiers. */
@Composable
fun LogsScreen(vm: LogsViewModel) {
    val logs by vm.logs.collectAsStateWithLifecycle()
    val clips by vm.clips.collectAsStateWithLifecycle()
    var mode by rememberSaveable { mutableIntStateOf(0) }
    val fmt = remember { SimpleDateFormat("dd/MM HH:mm:ss", Locale.getDefault()) }

    // Sélecteur de fichier système (SAF) : aucune permission de stockage nécessaire
    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) vm.export(uri)
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = mode == 0, onClick = { mode = 0 }, label = { Text("Journal") })
                FilterChip(selected = mode == 1, onClick = { mode = 1 }, label = { Text("Presse-papiers") })
            }
        }

        if (mode == 0) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { exporter.launch("sysmonitor-journal.txt") }) { Text("Exporter (.txt)") }
                    OutlinedButton(onClick = { vm.clearLogs() }) { Text("Effacer") }
                }
            }
            if (logs.isEmpty()) item { Text("Aucun événement enregistré.") }
            items(logs, key = { it.id }) { LogRow(it, fmt) }
        } else {
            item {
                Text(
                    "Historique local chiffré (AES-256, clé dans l'Android Keystore). Sur Android 10+, " +
                        "la capture n'a lieu que lorsque l'application est au premier plan (restriction système). " +
                        "Les contenus marqués « sensibles » ne sont pas enregistrés. Touchez un élément pour le recopier.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            item { OutlinedButton(onClick = { vm.clearClips() }) { Text("Tout effacer") } }
            if (clips.isEmpty()) item { Text("Historique vide.") }
            items(clips, key = { it.id }) { ClipRow(it, fmt, onDelete = { vm.deleteClip(it.id) }) }
        }
    }
}

@Composable
private fun LogRow(e: LogEntry, fmt: SimpleDateFormat) {
    val color = when (e.level) {
        "ALERT" -> MaterialTheme.colorScheme.error
        "WARN" -> MaterialTheme.colorScheme.tertiary
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    Column {
        Text(
            "${fmt.format(Date(e.ts))} · ${e.level} · ${e.tag}",
            style = MaterialTheme.typography.labelSmall,
            color = color
        )
        Text(e.message, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun ClipRow(e: ClipEntry, fmt: SimpleDateFormat, onDelete: () -> Unit) {
    val ctx = LocalContext.current
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable {
                ctx.getSystemService(ClipboardManager::class.java)
                    .setPrimaryClip(ClipData.newPlainText("sysmonitor", e.text))
                Toast.makeText(ctx, "Recopié dans le presse-papiers", Toast.LENGTH_SHORT).show()
            },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
    ) {
        Row(
            Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    e.text, maxLines = 3, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodyMedium, fontFamily = FontFamily.Monospace
                )
                Text(
                    fmt.format(Date(e.ts)), style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            TextButton(onClick = onDelete) { Text("Suppr.") }
        }
    }
}
