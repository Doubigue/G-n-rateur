package com.example.sysmonitor.data

import android.content.Context

/**
 * Produit un [DeviceSnapshot]. Une instance = un consommateur (ViewModel, service, serveur web…),
 * car CPU et débit réseau sont calculés par différence avec l'échantillon précédent.
 */
class MetricsSampler(context: Context) {
    private val ctx = context.applicationContext
    private val cpu = CpuSampler()
    private val bandwidth = BandwidthMeter()

    fun sample(): DeviceSnapshot = DeviceSnapshot(
        timestamp = System.currentTimeMillis(),
        ram = SystemReaders.readRam(ctx),
        storage = SystemReaders.readStorage(ctx),
        cpu = cpu.sample(),
        thermal = ThermalReader.read(ctx),
        battery = BatteryReader.read(ctx),
        network = NetworkReader.read(ctx),
        bandwidth = bandwidth.sample()
    )
}
