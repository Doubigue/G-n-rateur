package com.example.sysmonitor.service

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import com.example.sysmonitor.data.MetricsSampler
import com.example.sysmonitor.ui.MainActivity
import kotlin.math.roundToInt

/** Tuile des Réglages rapides : affiche RAM / température batterie, ouvre l'application au toucher. */
class QuickTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        refresh()
    }

    override fun onClick() {
        super.onClick()
        val intent = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(
                PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE)
            )
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(intent)
        }
    }

    private fun refresh() {
        val tile = qsTile ?: return
        val s = MetricsSampler(applicationContext).sample()
        tile.label = "System Monitor"
        if (Build.VERSION.SDK_INT >= 29) {
            tile.subtitle = "RAM ${s.ram.usedPercent.roundToInt()} % · ${"%.0f".format(s.battery.tempC)} °C"
        }
        tile.state = Tile.STATE_ACTIVE
        tile.updateTile()
    }
}
