package com.example.sysmonitor.ui.screens

import android.app.NotificationManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.example.sysmonitor.data.AppSettings
import com.example.sysmonitor.service.AlertNotifier
import com.example.sysmonitor.service.MonitorService
import com.example.sysmonitor.ui.InfoCard
import com.example.sysmonitor.ui.KeyValue
import com.example.sysmonitor.ui.ScreenColumn
import kotlin.math.roundToInt

/** Service de surveillance, alertes sur écran verrouillé et seuils critiques. */
@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    val st = remember { AppSettings(ctx) }
    var monitor by remember { mutableStateOf(st.monitorEnabled) }
    var lock by remember { mutableStateOf(st.lockScreenAlerts) }
    var temp by remember { mutableFloatStateOf(st.batteryTempC.toFloat()) }
    var storage by remember { mutableFloatStateOf(st.storagePercent.toFloat()) }
    var ram by remember { mutableFloatStateOf(st.ramPercent.toFloat()) }
    var low by remember { mutableFloatStateOf(st.lowBatteryPercent.toFloat()) }

    ScreenColumn {
        InfoCard("Surveillance en arrière-plan") {
            SwitchRow("Service de surveillance et alertes", monitor) {
                monitor = it
                st.monitorEnabled = it
                if (it) MonitorService.start(ctx) else MonitorService.stop(ctx)
            }
            SwitchRow("Alertes par-dessus l'écran de verrouillage", lock) {
                lock = it
                st.lockScreenAlerts = it
            }
            val nm = ctx.getSystemService(NotificationManager::class.java)
            if (Build.VERSION.SDK_INT >= 34 && !nm.canUseFullScreenIntent()) {
                Text(
                    "Android 14+ : l'autorisation « notifications plein écran » doit être accordée manuellement.",
                    style = MaterialTheme.typography.bodySmall
                )
                OutlinedButton(onClick = {
                    ctx.startActivity(
                        Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:${ctx.packageName}"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }) { Text("Ouvrir le réglage") }
            }
            OutlinedButton(onClick = {
                AlertNotifier.alert(ctx, 199, "Alerte de test", "Verrouillez l'écran puis relancez ce test pour vérifier l'affichage.")
            }) { Text("Envoyer une alerte de test") }
        }

        InfoCard("Seuils d'alerte") {
            SliderRow("Température batterie", "${temp.roundToInt()} °C", temp, 35f..55f) {
                temp = it; st.batteryTempC = it.roundToInt()
            }
            SliderRow("Stockage interne utilisé", "${storage.roundToInt()} %", storage, 70f..99f) {
                storage = it; st.storagePercent = it.roundToInt()
            }
            SliderRow("RAM utilisée", "${ram.roundToInt()} %", ram, 70f..99f) {
                ram = it; st.ramPercent = it.roundToInt()
            }
            SliderRow("Batterie faible", "${low.roundToInt()} %", low, 5f..40f) {
                low = it; st.lowBatteryPercent = it.roundToInt()
            }
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun SliderRow(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit
) {
    Column {
        KeyValue(label, valueText)
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}
