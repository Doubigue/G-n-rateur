package com.example.sysmonitor.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.example.sysmonitor.R
import com.example.sysmonitor.data.DeviceSnapshot
import com.example.sysmonitor.data.IoExecutor
import com.example.sysmonitor.data.MetricsSampler
import com.example.sysmonitor.ui.MainActivity
import kotlin.math.roundToInt

/** Widget d'accueil : batterie, RAM et stockage. Rafraîchi toutes les 10 s par MonitorService. */
class StatsWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val pending = goAsync()
        IoExecutor.single.execute {
            try {
                refresh(context, MetricsSampler(context).sample())
            } finally {
                pending.finish()
            }
        }
    }

    companion object {
        fun refresh(ctx: Context, s: DeviceSnapshot) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, StatsWidget::class.java))
            if (ids.isEmpty()) return
            val open = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
            )
            val views = RemoteViews(ctx.packageName, R.layout.widget_stats).apply {
                setTextViewText(
                    R.id.widget_battery,
                    "Batterie ${s.battery.percent} % · ${"%.0f".format(s.battery.tempC)} °C"
                )
                setTextViewText(R.id.widget_ram, "RAM ${s.ram.usedPercent.roundToInt()} %")
                val st = s.storage.firstOrNull()
                setTextViewText(R.id.widget_storage, "Stockage ${st?.usedPercent?.roundToInt() ?: 0} %")
                setOnClickPendingIntent(R.id.widget_root, open)
            }
            mgr.updateAppWidget(ids, views)
        }
    }
}
