package com.example.sysmonitor.data

import java.util.Locale

fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes o"
    val units = arrayOf("Ko", "Mo", "Go", "To")
    var value = bytes.toDouble()
    var i = -1
    while (value >= 1024 && i < units.lastIndex) {
        value /= 1024
        i++
    }
    return String.format(Locale.getDefault(), "%.1f %s", value, units[i])
}

fun formatSpeed(bytesPerSec: Long): String =
    if (bytesPerSec >= 1_048_576) String.format(Locale.getDefault(), "%.2f Mo/s", bytesPerSec / 1_048_576.0)
    else String.format(Locale.getDefault(), "%.1f Ko/s", bytesPerSec / 1024.0)

fun formatFreq(khz: Long): String =
    if (khz >= 1_000_000) String.format(Locale.getDefault(), "%.2f GHz", khz / 1_000_000.0)
    else "${khz / 1000} MHz"
