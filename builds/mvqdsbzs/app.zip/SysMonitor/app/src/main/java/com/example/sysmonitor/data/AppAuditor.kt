package com.example.sysmonitor.data

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build

enum class RiskCategory(val label: String) {
    CAMERA("Caméra"),
    MICROPHONE("Micro"),
    LOCATION("Localisation"),
    SMS("SMS"),
    STORAGE("Stockage")
}

data class AppEntry(
    val label: String,
    val packageName: String,
    val isSystem: Boolean,
    val versionName: String,
    /** Catégories sensibles pour lesquelles une permission est RÉELLEMENT accordée. */
    val risks: List<RiskCategory>
)

/** Audit des applications installées et de leurs permissions à haut risque. */
object AppAuditor {

    private val riskMap: Map<String, RiskCategory> = mapOf(
        "android.permission.CAMERA" to RiskCategory.CAMERA,
        "android.permission.RECORD_AUDIO" to RiskCategory.MICROPHONE,
        "android.permission.ACCESS_FINE_LOCATION" to RiskCategory.LOCATION,
        "android.permission.ACCESS_COARSE_LOCATION" to RiskCategory.LOCATION,
        "android.permission.ACCESS_BACKGROUND_LOCATION" to RiskCategory.LOCATION,
        "android.permission.READ_SMS" to RiskCategory.SMS,
        "android.permission.SEND_SMS" to RiskCategory.SMS,
        "android.permission.RECEIVE_SMS" to RiskCategory.SMS,
        "android.permission.READ_EXTERNAL_STORAGE" to RiskCategory.STORAGE,
        "android.permission.WRITE_EXTERNAL_STORAGE" to RiskCategory.STORAGE,
        "android.permission.MANAGE_EXTERNAL_STORAGE" to RiskCategory.STORAGE,
        "android.permission.READ_MEDIA_IMAGES" to RiskCategory.STORAGE,
        "android.permission.READ_MEDIA_VIDEO" to RiskCategory.STORAGE,
        "android.permission.READ_MEDIA_AUDIO" to RiskCategory.STORAGE
    )

    fun scan(ctx: Context): List<AppEntry> {
        val pm = ctx.packageManager
        val packages: List<PackageInfo> = if (Build.VERSION.SDK_INT >= 33) {
            pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(PackageManager.GET_PERMISSIONS.toLong()))
        } else {
            @Suppress("DEPRECATION")
            pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)
        }
        return packages.map { p ->
            val ai: ApplicationInfo? = p.applicationInfo
            val isSystem = ai != null && (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            val label = if (ai != null) pm.getApplicationLabel(ai).toString() else p.packageName
            val perms: Array<String> = p.requestedPermissions ?: emptyArray()
            val flags: IntArray = p.requestedPermissionsFlags ?: IntArray(0)
            val risks = perms.indices
                .filter { i -> (flags.getOrElse(i) { 0 } and PackageInfo.REQUESTED_PERMISSION_GRANTED) != 0 }
                .mapNotNull { i -> riskMap[perms[i]] }
                .distinct()
            AppEntry(label, p.packageName, isSystem, p.versionName ?: "—", risks)
        }.sortedBy { it.label.lowercase() }
    }
}
