package com.example.sysmonitor.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.sysmonitor.data.AppSettings
import com.example.sysmonitor.data.DeviceSnapshot
import com.example.sysmonitor.data.DumpResult
import com.example.sysmonitor.data.DumpsysReader
import com.example.sysmonitor.data.InternetProbe
import com.example.sysmonitor.data.MetricsSampler
import com.example.sysmonitor.data.NetworkReader
import com.example.sysmonitor.data.ProbeResult
import com.example.sysmonitor.data.WakelockEntry
import com.example.sysmonitor.service.WebServerService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** ViewModel des onglets Système, Batterie et Réseau (tous alimentés par le même instantané). */
class MonitorViewModel(app: Application) : AndroidViewModel(app) {

    private val settings = AppSettings(app)
    private val sampler = MetricsSampler(app)

    /** Instantané rafraîchi chaque seconde, uniquement tant qu'un écran l'observe. */
    val snapshot: StateFlow<DeviceSnapshot?> = flow<DeviceSnapshot?> {
        while (true) {
            emit(sampler.sample())
            delay(1000)
        }
    }.flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    // ── Test d'accès Internet ──
    private val _probe = MutableStateFlow<ProbeResult?>(null)
    val probe: StateFlow<ProbeResult?> = _probe.asStateFlow()
    private val _probing = MutableStateFlow(false)
    val probing: StateFlow<Boolean> = _probing.asStateFlow()

    fun runProbe() {
        if (_probing.value) return
        viewModelScope.launch {
            _probing.value = true
            _probe.value = InternetProbe.check(getApplication())
            _probing.value = false
        }
    }

    // ── Analyseur de wakelocks ──
    private val _wakelocks = MutableStateFlow<DumpResult<List<WakelockEntry>>?>(null)
    val wakelocks: StateFlow<DumpResult<List<WakelockEntry>>?> = _wakelocks.asStateFlow()
    private val _analyzing = MutableStateFlow(false)
    val analyzing: StateFlow<Boolean> = _analyzing.asStateFlow()

    fun analyzeWakelocks() {
        if (_analyzing.value) return
        viewModelScope.launch(Dispatchers.IO) {
            _analyzing.value = true
            _wakelocks.value = DumpsysReader.wakelocks(getApplication())
            _analyzing.value = false
        }
    }

    // ── Serveur web local ──
    val webRunning: StateFlow<Boolean> = WebServerService.running

    fun setWebServer(enabled: Boolean) {
        if (enabled) WebServerService.start(getApplication()) else WebServerService.stop(getApplication())
    }

    fun webUrl(): String {
        val ip = NetworkReader.lanIp(getApplication()) ?: "IP_DE_L_APPAREIL"
        return "http://$ip:${settings.webPort}/?t=${settings.webToken}"
    }

    fun regenerateToken() {
        settings.regenerateToken()
        // Le serveur en cours garde l'ancien jeton : on le redémarre pour appliquer le nouveau.
        if (WebServerService.running.value) {
            WebServerService.stop(getApplication())
            WebServerService.start(getApplication())
        }
    }

    init {
        runProbe()
    }
}
