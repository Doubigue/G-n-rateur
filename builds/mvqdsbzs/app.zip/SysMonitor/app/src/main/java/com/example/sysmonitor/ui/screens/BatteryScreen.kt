package com.example.sysmonitor.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.sysmonitor.data.DumpResult
import com.example.sysmonitor.data.DumpsysReader
import com.example.sysmonitor.ui.AdbHint
import com.example.sysmonitor.ui.InfoCard
import com.example.sysmonitor.ui.KeyValue
import com.example.sysmonitor.ui.LoadingBox
import com.example.sysmonitor.ui.ScreenColumn
import com.example.sysmonitor.ui.UsageBar
import com.example.sysmonitor.ui.viewmodel.MonitorViewModel

/** Batterie (BatteryManager) + veille profonde (Doze) + analyseur de wakelocks. */
@Composable
fun BatteryScreen(vm: MonitorViewModel) {
    val snap by vm.snapshot.collectAsStateWithLifecycle()
    val s = snap
    if (s == null) {
        LoadingBox()
        return
    }
    val b = s.battery

    ScreenColumn {
        InfoCard("Batterie") {
            Text("${b.percent} %", style = MaterialTheme.typography.displaySmall)
            UsageBar(b.percent / 100f, warn = b.percent <= 15 && !b.charging)
            KeyValue("Statut", b.status)
            KeyValue("Source d'alimentation", b.source)
            KeyValue("Température", "%.1f °C".format(b.tempC))
            KeyValue("Tension", "${b.voltageMv} mV (%.2f V)".format(b.voltageMv / 1000f))
            KeyValue("Santé", b.health)
            KeyValue("Technologie", b.technology)
            b.currentMa?.let { KeyValue("Courant instantané (approx.)", "$it mA") }
        }

        InfoCard("Veille profonde") {
            KeyValue("Mode Doze (veille profonde)", if (b.deviceIdle) "Actif" else "Inactif")
            KeyValue("Économiseur de batterie", if (b.powerSave) "Activé" else "Désactivé")
        }

        InfoCard("Analyseur de wakelocks") {
            val result by vm.wakelocks.collectAsStateWithLifecycle()
            val analyzing by vm.analyzing.collectAsStateWithLifecycle()

            Text(
                "Identifie les applications qui maintiennent l'appareil éveillé et l'empêchent d'entrer en veille profonde.",
                style = MaterialTheme.typography.bodySmall
            )
            Button(onClick = { vm.analyzeWakelocks() }, enabled = !analyzing) {
                Text(if (analyzing) "Analyse…" else "Analyser maintenant")
            }
            when (val r = result) {
                null -> Unit
                is DumpResult.Ok -> {
                    if (r.value.isEmpty()) {
                        Text("Aucun wakelock actif : l'appareil peut entrer en veille profonde.")
                    } else {
                        HorizontalDivider()
                        r.value.forEach { w ->
                            Column {
                                Text(w.label, style = MaterialTheme.typography.titleSmall)
                                Text(
                                    "${w.type} · « ${w.tag} »",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(w.packageName, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
                DumpResult.NoPermission -> AdbHint(DumpsysReader.ADB_COMMANDS)
                is DumpResult.Error -> Text(r.message, color = MaterialTheme.colorScheme.error)
            }
        }
    }
}
