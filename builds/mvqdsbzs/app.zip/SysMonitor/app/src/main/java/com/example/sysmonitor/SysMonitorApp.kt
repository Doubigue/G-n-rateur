package com.example.sysmonitor

import android.app.Application
import com.example.sysmonitor.data.EventLogger
import com.example.sysmonitor.service.AlertNotifier

class SysMonitorApp : Application() {
    override fun onCreate() {
        super.onCreate()
        AlertNotifier.createChannels(this)
        EventLogger.info(this, "Application", "Processus démarré")
    }
}
