package com.example.sysmonitor.data

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import java.io.File
import kotlin.math.abs

/** Lecteurs "sans état" : RAM, stockage. */
object SystemReaders {

    fun readRam(ctx: Context): RamInfo {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return RamInfo(mi.totalMem, mi.availMem, mi.lowMemory)
    }

    fun readStorage(ctx: Context): List<StorageVolume> {
        val list = mutableListOf<StorageVolume>()
        fun add(label: String, dir: File?, removable: Boolean) {
            if (dir == null) return
            runCatching {
                val st = StatFs(dir.absolutePath)
                list += StorageVolume(label, st.totalBytes, st.availableBytes, removable)
            }
        }
        add("Stockage interne", Environment.getDataDirectory(), false)
        // getExternalFilesDirs : l'index 0 est le stockage partagé primaire (même partition que /data),
        // les index >= 1 correspondent aux cartes SD / volumes amovibles.
        ctx.getExternalFilesDirs(null).drop(1).forEachIndexed { i, d ->
            add("Carte SD / externe ${i + 1}", d, true)
        }
        return list
    }

    /** Lecture robuste d'un fichier sysfs/procfs (taille déclarée peu fiable). */
    internal fun readText(path: String): String? =
        runCatching { File(path).bufferedReader().use { it.readText() }.trim() }.getOrNull()

    internal fun readLong(path: String): Long? = readText(path)?.toLongOrNull()
}

/**
 * Échantillonneur CPU (avec état : conserve le /proc/stat précédent).
 *
 * Limites Android :
 *  - /proc/stat est bloqué pour les apps depuis Android 8 → repli sur une charge estimée via les fréquences.
 *  - Les cœurs hors ligne n'exposent pas cpufreq → affichés "hors ligne".
 */
class CpuSampler {
    private var prevTotal = 0L
    private var prevIdle = 0L

    fun sample(): CpuInfo {
        val cores = readCores()
        val real = readProcStatLoad()
        if (real != null) return CpuInfo(real, false, cores)
        val active = cores.filter { it.online && it.maxKhz > 0 }
        val estimate = if (active.isEmpty()) 0f else active.map { it.ratio }.average().toFloat() * 100f
        return CpuInfo(estimate, true, cores)
    }

    private fun readProcStatLoad(): Float? {
        val line = runCatching { File("/proc/stat").bufferedReader().use { it.readLine() } }.getOrNull()
            ?: return null
        val p = line.trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
        if (p.size < 5) return null
        val idle = p[3] + p[4]            // idle + iowait
        val total = p.take(8).sum()
        val dTotal = total - prevTotal
        val dIdle = idle - prevIdle
        val first = prevTotal == 0L
        prevTotal = total
        prevIdle = idle
        if (first || dTotal <= 0) return null
        return ((dTotal - dIdle) * 100f / dTotal).coerceIn(0f, 100f)
    }

    private fun readCores(): List<CoreInfo> {
        val indices = File("/sys/devices/system/cpu").listFiles()
            ?.mapNotNull { Regex("cpu(\\d+)").matchEntire(it.name)?.groupValues?.get(1)?.toIntOrNull() }
            ?.sorted()
            ?.takeIf { it.isNotEmpty() }
            ?: (0 until Runtime.getRuntime().availableProcessors()).toList()
        return indices.map { i ->
            val base = "/sys/devices/system/cpu/cpu$i/cpufreq/"
            val cur = SystemReaders.readLong(base + "scaling_cur_freq")
            val max = SystemReaders.readLong(base + "cpuinfo_max_freq")
                ?: SystemReaders.readLong(base + "scaling_max_freq")
            CoreInfo(i, cur != null, cur ?: 0L, max ?: 0L)
        }
    }
}

/** Sondes thermiques : zones sysfs (si lisibles) + état thermique officiel Android. */
object ThermalReader {
    fun read(ctx: Context): ThermalInfo {
        val zones = File("/sys/class/thermal").listFiles()
            ?.filter { it.name.startsWith("thermal_zone") }
            ?.sortedBy { it.name.removePrefix("thermal_zone").toIntOrNull() ?: 0 }
            ?.mapNotNull { dir ->
                val raw = SystemReaders.readText(File(dir, "temp").path)?.toFloatOrNull()
                    ?: return@mapNotNull null
                // Selon le SoC : milli-degrés ou degrés
                val c = if (abs(raw) >= 1000f) raw / 1000f else raw
                if (c <= -20f || c > 150f || c == 0f) null
                else ThermalZone(SystemReaders.readText(File(dir, "type").path) ?: dir.name, c)
            }
            ?.take(12)
            .orEmpty()

        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        val status = if (Build.VERSION.SDK_INT >= 29) {
            when (pm.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE -> "Normal"
                PowerManager.THERMAL_STATUS_LIGHT -> "Léger"
                PowerManager.THERMAL_STATUS_MODERATE -> "Modéré"
                PowerManager.THERMAL_STATUS_SEVERE -> "Sévère (bridage)"
                PowerManager.THERMAL_STATUS_CRITICAL -> "Critique"
                PowerManager.THERMAL_STATUS_EMERGENCY -> "Urgence"
                PowerManager.THERMAL_STATUS_SHUTDOWN -> "Arrêt imminent"
                else -> "Inconnu"
            }
        } else null
        val headroom = if (Build.VERSION.SDK_INT >= 30) {
            pm.getThermalHeadroom(0).takeIf { !it.isNaN() }
        } else null
        return ThermalInfo(zones, status, headroom)
    }
}
