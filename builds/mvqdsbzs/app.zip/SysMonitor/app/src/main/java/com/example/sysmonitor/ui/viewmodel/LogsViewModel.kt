package com.example.sysmonitor.ui.viewmodel

import android.app.Application
import android.net.Uri
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.sysmonitor.data.ClipEntry
import com.example.sysmonitor.data.ClipStore
import com.example.sysmonitor.data.EventLogger
import com.example.sysmonitor.data.LogEntry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.merge
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Journal d'événements (SQLite) et historique du presse-papiers (chiffré). */
class LogsViewModel(private val app: Application) : AndroidViewModel(app) {

    private val _logs = MutableStateFlow<List<LogEntry>>(emptyList())
    val logs: StateFlow<List<LogEntry>> = _logs.asStateFlow()

    private val _clips = MutableStateFlow<List<ClipEntry>>(emptyList())
    val clips: StateFlow<List<ClipEntry>> = _clips.asStateFlow()

    init {
        // Recharge au démarrage puis à chaque écriture en base
        viewModelScope.launch {
            merge(flowOf(Unit), EventLogger.updates, ClipStore.updates).collect { reload() }
        }
    }

    private suspend fun reload() = withContext(Dispatchers.IO) {
        _logs.value = EventLogger.recent(app)
        _clips.value = ClipStore.recent(app)
    }

    fun clearLogs() {
        viewModelScope.launch(Dispatchers.IO) { EventLogger.clear(app) }
    }

    fun clearClips() {
        viewModelScope.launch(Dispatchers.IO) { ClipStore.clear(app) }
    }

    fun deleteClip(id: Long) {
        viewModelScope.launch(Dispatchers.IO) { ClipStore.delete(app, id) }
    }

    /** Exporte le journal vers l'URI choisi par l'utilisateur (Storage Access Framework). */
    fun export(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val ok = runCatching {
                app.contentResolver.openOutputStream(uri)?.use { EventLogger.exportText(app, it) } != null
            }.getOrDefault(false)
            withContext(Dispatchers.Main) {
                Toast.makeText(app, if (ok) "Journal exporté" else "Échec de l'export", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
