package com.example.sysmonitor.data

import android.content.Context
import android.content.pm.PackageManager

data class WakelockEntry(val tag: String, val type: String, val packageName: String, val label: String)
data class ServiceEntry(val packageName: String, val label: String, val service: String)

sealed interface DumpResult<out T> {
    data class Ok<T>(val value: T) : DumpResult<T>
    data object NoPermission : DumpResult<Nothing>
    data class Error(val message: String) : DumpResult<Nothing>
}

/**
 * Lecture de `dumpsys` : analyse des wakelocks actifs (veille profonde) et des services actifs.
 *
 * IMPORTANT : sans privilège système, Android refuse `dumpsys` aux applications tierces.
 * Les permissions DUMP et PACKAGE_USAGE_STATS doivent être accordées UNE FOIS via ADB (voir [ADB_COMMANDS]).
 */
object DumpsysReader {

    val ADB_COMMANDS = listOf(
        "adb shell pm grant com.example.sysmonitor android.permission.DUMP",
        "adb shell pm grant com.example.sysmonitor android.permission.PACKAGE_USAGE_STATS"
    )

    private fun run(vararg args: String): String? = try {
        val p = ProcessBuilder("dumpsys", *args).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().use { it.readText() }
        p.waitFor()
        out
    } catch (e: Exception) {
        null
    }

    private fun denied(out: String) =
        out.contains("Permission Denial", ignoreCase = true) || out.contains("SecurityException")

    /** Wakelocks actuellement détenus : `dumpsys power`. */
    fun wakelocks(ctx: Context): DumpResult<List<WakelockEntry>> {
        val out = run("power") ?: return DumpResult.Error("dumpsys indisponible sur cet appareil")
        if (denied(out)) return DumpResult.NoPermission
        // Ex. : PARTIAL_WAKE_LOCK  'tag' ACQ=-5s12ms (uid=10157 pid=5287 ws=WorkSource{10157})
        val re = Regex("""(\w*WAKE_LOCK)\s+'(.*?)'.*?uid=(\d+)""")
        val pm = ctx.packageManager
        val list = out.lineSequence()
            .mapNotNull { re.find(it) }
            .map { m ->
                val (type, tag, uid) = m.destructured
                val pkg = pm.getPackagesForUid(uid.toInt())?.firstOrNull() ?: "uid:$uid"
                WakelockEntry(tag, type, pkg, appLabel(pm, pkg))
            }
            .distinct()
            .toList()
        return DumpResult.Ok(list)
    }

    /** Services actifs de toutes les applications : `dumpsys activity services`. */
    fun activeServices(ctx: Context): DumpResult<List<ServiceEntry>> {
        val out = run("activity", "services") ?: return DumpResult.Error("dumpsys indisponible sur cet appareil")
        if (denied(out)) return DumpResult.NoPermission
        // Ex. : * ServiceRecord{c1a2b3 u0 com.google.android.gms/.chimera.GmsApiService}
        val re = Regex("""ServiceRecord\{[0-9a-f]+ u\d+ ([\w.]+)/([\w.$]+)\}""")
        val pm = ctx.packageManager
        val labels = HashMap<String, String>()
        val list = re.findAll(out)
            .map { it.groupValues[1] to it.groupValues[2] }
            .distinct()
            .map { (pkg, svc) -> ServiceEntry(pkg, labels.getOrPut(pkg) { appLabel(pm, pkg) }, svc) }
            .sortedBy { it.label.lowercase() }
            .toList()
        return DumpResult.Ok(list)
    }

    @Suppress("DEPRECATION")
    private fun appLabel(pm: PackageManager, pkg: String): String =
        runCatching { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() }.getOrDefault(pkg)
}
