package com.example.sysmonitor.data

/** Mémoire vive (source : ActivityManager.MemoryInfo). */
data class RamInfo(val totalBytes: Long, val availBytes: Long, val lowMemory: Boolean) {
    val usedBytes: Long get() = totalBytes - availBytes
    val usedPercent: Float get() = if (totalBytes > 0) usedBytes * 100f / totalBytes else 0f
}

/** Un volume de stockage (source : StatFs). */
data class StorageVolume(
    val label: String,
    val totalBytes: Long,
    val freeBytes: Long,
    val removable: Boolean
) {
    val usedBytes: Long get() = totalBytes - freeBytes
    val usedPercent: Float get() = if (totalBytes > 0) usedBytes * 100f / totalBytes else 0f
}

/** Fréquences d'un cœur CPU en kHz (sysfs : cpufreq). */
data class CoreInfo(val index: Int, val online: Boolean, val curKhz: Long, val maxKhz: Long) {
    val ratio: Float get() = if (maxKhz > 0) (curKhz.toFloat() / maxKhz).coerceIn(0f, 1f) else 0f
}

/** [loadEstimated] = true quand /proc/stat est inaccessible (Android 8+) : charge déduite des fréquences. */
data class CpuInfo(val loadPercent: Float, val loadEstimated: Boolean, val cores: List<CoreInfo>)

data class ThermalZone(val name: String, val tempC: Float)

data class ThermalInfo(
    val zones: List<ThermalZone>,
    val statusLabel: String?,   // PowerManager.currentThermalStatus (API 29+)
    val headroom: Float?        // PowerManager.getThermalHeadroom (API 30+), 1.0 = seuil de bridage
)

data class BatteryInfo(
    val percent: Int,
    val status: String,
    val charging: Boolean,
    val source: String,
    val tempC: Float,
    val voltageMv: Int,
    val health: String,
    val technology: String,
    val currentMa: Int?,
    val powerSave: Boolean,
    val deviceIdle: Boolean
)

data class NetworkInfo(val type: String, val ip: String?, val validated: Boolean, val connected: Boolean)

data class Bandwidth(val downBps: Long, val upBps: Long)

data class ProbeResult(val ok: Boolean, val latencyMs: Long?, val detail: String)

/** Instantané complet de l'appareil : unique source de vérité pour l'UI, les alertes et le serveur web. */
data class DeviceSnapshot(
    val timestamp: Long,
    val ram: RamInfo,
    val storage: List<StorageVolume>,
    val cpu: CpuInfo,
    val thermal: ThermalInfo,
    val battery: BatteryInfo,
    val network: NetworkInfo,
    val bandwidth: Bandwidth
)
