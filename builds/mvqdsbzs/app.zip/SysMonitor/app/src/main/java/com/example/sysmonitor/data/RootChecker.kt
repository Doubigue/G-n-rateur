package com.example.sysmonitor.data

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import java.io.File

data class RootReport(val rooted: Boolean, val findings: List<String>)

/**
 * Détection de root par heuristiques classiques. Non exhaustive : Magisk (DenyList / Zygisk) et
 * d'autres outils peuvent masquer ces indices à une application.
 */
object RootChecker {
    private val suPaths = listOf(
        "/system/bin/su", "/system/xbin/su", "/sbin/su", "/system/su", "/su/bin/su",
        "/data/local/xbin/su", "/data/local/bin/su", "/system/sd/xbin/su", "/vendor/bin/su"
    )
    private val rootPackages = listOf(
        "com.topjohnwu.magisk", "eu.chainfire.supersu", "com.noshufou.android.su",
        "com.koushikdutta.superuser", "com.thirdparty.superuser", "com.yellowes.su", "me.weishu.kernelsu"
    )

    fun check(ctx: Context): RootReport {
        val findings = mutableListOf<String>()
        if (Build.TAGS?.contains("test-keys") == true) findings += "Firmware signé avec des clés de test (test-keys)"
        suPaths.filter { File(it).exists() }.forEach { findings += "Binaire su présent : $it" }
        rootPackages.filter { isInstalled(ctx, it) }.forEach { findings += "Application de gestion root : $it" }
        if (suInPath()) findings += "La commande « su » est résolue dans le PATH"
        if (File("/system").canWrite()) findings += "/system accessible en écriture"
        return RootReport(findings.isNotEmpty(), findings)
    }

    @Suppress("DEPRECATION")
    private fun isInstalled(ctx: Context, pkg: String): Boolean =
        try {
            ctx.packageManager.getPackageInfo(pkg, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }

    private fun suInPath(): Boolean = try {
        val p = Runtime.getRuntime().exec(arrayOf("which", "su"))
        val out = p.inputStream.bufferedReader().use { it.readText() }
        p.waitFor()
        out.isNotBlank()
    } catch (e: Exception) {
        false
    }
}
