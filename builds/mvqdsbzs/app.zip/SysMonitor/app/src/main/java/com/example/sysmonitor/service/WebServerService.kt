package com.example.sysmonitor.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.example.sysmonitor.data.AppSettings
import com.example.sysmonitor.data.EventLogger
import com.example.sysmonitor.data.MetricsSampler
import com.example.sysmonitor.data.NetworkReader
import com.example.sysmonitor.data.toJson
import fi.iki.elonen.NanoHTTPD
import fi.iki.elonen.NanoHTTPD.IHTTPSession
import fi.iki.elonen.NanoHTTPD.Method
import fi.iki.elonen.NanoHTTPD.Response
import fi.iki.elonen.NanoHTTPD.Response.Status
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.IOException
import java.security.MessageDigest

/** Héberge le serveur web local (NanoHTTPD) tant que le service est actif. */
class WebServerService : Service() {

    private var server: DashboardServer? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val settings = AppSettings(this)
        val ip = NetworkReader.lanIp(this)
        ServiceCompat.startForeground(
            this, NOTIF_ID,
            AlertNotifier.serverNotification(this, "http://${ip ?: "?"}:${settings.webPort}"),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        )
        if (server == null) {
            val s = DashboardServer(applicationContext, settings.webPort, settings.webToken)
            try {
                s.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false)
                server = s
                _running.value = true
                EventLogger.info(this, "Serveur web", "Démarré sur le port ${settings.webPort}")
            } catch (e: IOException) {
                EventLogger.warn(this, "Serveur web", "Échec du démarrage : ${e.message}")
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        server?.stop()
        server = null
        _running.value = false
        EventLogger.info(this, "Serveur web", "Arrêté")
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val NOTIF_ID = 2
        private val _running = MutableStateFlow(false)
        val running: StateFlow<Boolean> = _running

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, WebServerService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, WebServerService::class.java))
        }
    }
}

/**
 * Serveur HTTP local.
 *  - GET /               → page du tableau de bord (assets/dashboard.html)
 *  - GET /api/status     → instantané JSON complet
 *  - GET /api/logs       → 100 derniers événements
 * Toutes les routes exigent le jeton (?t=…). Le presse-papiers n'est JAMAIS exposé.
 */
class DashboardServer(
    private val ctx: Context,
    port: Int,
    private val token: String
) : NanoHTTPD(port) {

    private val sampler = MetricsSampler(ctx)
    private val html: String by lazy {
        ctx.assets.open("dashboard.html").bufferedReader().use { it.readText() }
    }

    override fun serve(session: IHTTPSession): Response {
        if (session.method != Method.GET) return text(Status.METHOD_NOT_ALLOWED, "405")
        val provided = session.parameters["t"]?.firstOrNull().orEmpty()
        // Comparaison en temps constant
        if (!MessageDigest.isEqual(provided.toByteArray(), token.toByteArray())) {
            return text(Status.UNAUTHORIZED, "Jeton invalide. Utilisez l'URL affichée dans l'application.")
        }
        return when (session.uri) {
            "/" -> NanoHTTPD.newFixedLengthResponse(Status.OK, "text/html; charset=utf-8", html)
            "/api/status" -> json(synchronized(sampler) { sampler.sample().toJson().toString() })
            "/api/logs" -> json(EventLogger.recent(ctx, 100).toJson().toString())
            else -> text(Status.NOT_FOUND, "404")
        }
    }

    private fun text(status: Status, body: String): Response =
        NanoHTTPD.newFixedLengthResponse(status, "text/plain; charset=utf-8", body)

    private fun json(body: String): Response =
        NanoHTTPD.newFixedLengthResponse(Status.OK, "application/json; charset=utf-8", body)
            .apply { addHeader("Cache-Control", "no-store") }
}
