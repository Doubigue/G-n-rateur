package com.example.sysmonitor.data

import android.content.Context
import java.security.SecureRandom

/** Préférences utilisateur (SharedPreferences). Lues à chaque évaluation : les changements sont immédiats. */
class AppSettings(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var monitorEnabled: Boolean
        get() = sp.getBoolean("monitor", false)
        set(v) = sp.edit().putBoolean("monitor", v).apply()

    var lockScreenAlerts: Boolean
        get() = sp.getBoolean("lock_alerts", true)
        set(v) = sp.edit().putBoolean("lock_alerts", v).apply()

    var batteryTempC: Int
        get() = sp.getInt("thr_temp", 42)
        set(v) = sp.edit().putInt("thr_temp", v).apply()

    var storagePercent: Int
        get() = sp.getInt("thr_storage", 90)
        set(v) = sp.edit().putInt("thr_storage", v).apply()

    var ramPercent: Int
        get() = sp.getInt("thr_ram", 90)
        set(v) = sp.edit().putInt("thr_ram", v).apply()

    var lowBatteryPercent: Int
        get() = sp.getInt("thr_batt", 15)
        set(v) = sp.edit().putInt("thr_batt", v).apply()

    val webPort: Int get() = 8080

    /** Jeton d'accès au serveur web local (généré aléatoirement au premier usage). */
    val webToken: String
        get() = sp.getString("web_token", null) ?: regenerateToken()

    fun regenerateToken(): String {
        val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val rnd = SecureRandom()
        val token = (1..8).map { alphabet[rnd.nextInt(alphabet.length)] }.joinToString("")
        sp.edit().putString("web_token", token).apply()
        return token
    }
}
