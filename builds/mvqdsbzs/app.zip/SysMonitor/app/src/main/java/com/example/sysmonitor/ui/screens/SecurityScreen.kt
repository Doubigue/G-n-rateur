package com.example.sysmonitor.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.FilterChip
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.sysmonitor.data.AppEntry
import com.example.sysmonitor.data.DumpResult
import com.example.sysmonitor.data.DumpsysReader
import com.example.sysmonitor.data.RootReport
import com.example.sysmonitor.ui.AdbHint
import com.example.sysmonitor.ui.InfoCard
import com.example.sysmonitor.ui.viewmodel.SecurityViewModel

/** Trois vues : Audit (root + permissions à risque), Applications (utilisateur / système), Services actifs. */
@Composable
fun SecurityScreen(vm: SecurityViewModel) {
    val apps by vm.apps.collectAsStateWithLifecycle()
    val root by vm.root.collectAsStateWithLifecycle()
    val services by vm.services.collectAsStateWithLifecycle()
    var mode by rememberSaveable { mutableIntStateOf(0) }
    var appFilter by rememberSaveable { mutableIntStateOf(0) } // 0 utilisateur, 1 système, 2 toutes

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Audit", "Applications", "Services").forEachIndexed { i, label ->
                    FilterChip(selected = mode == i, onClick = { mode = i }, label = { Text(label) })
                }
            }
        }

        when (mode) {
            0 -> {
                item { RootCard(root) }
                val risky = apps.orEmpty()
                    .filter { !it.isSystem && it.risks.isNotEmpty() }
                    .sortedWith(compareByDescending<AppEntry> { it.risks.size }.thenBy { it.label.lowercase() })
                item {
                    InfoCard("Permissions à haut risque") {
                        Text(
                            if (apps == null) "Analyse en cours…"
                            else "${risky.size} application(s) utilisateur disposent de permissions sensibles " +
                                "accordées (caméra, micro, localisation, SMS, stockage). Touchez une application pour gérer ses permissions.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
                items(risky, key = { it.packageName }) { AppRow(it) }
            }

            1 -> {
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Utilisateur", "Système", "Toutes").forEachIndexed { i, label ->
                            FilterChip(selected = appFilter == i, onClick = { appFilter = i }, label = { Text(label) })
                        }
                    }
                }
                val list = apps.orEmpty().filter {
                    when (appFilter) {
                        0 -> !it.isSystem
                        1 -> it.isSystem
                        else -> true
                    }
                }
                if (apps == null) item { Text("Chargement…") }
                else item { Text("${list.size} application(s)", style = MaterialTheme.typography.labelMedium) }
                items(list, key = { it.packageName }) { AppRow(it) }
            }

            else -> {
                when (val r = services) {
                    null -> item { Text("Chargement…") }
                    DumpResult.NoPermission -> item {
                        InfoCard("Services actifs") { AdbHint(DumpsysReader.ADB_COMMANDS) }
                    }
                    is DumpResult.Error -> item { Text(r.message, color = MaterialTheme.colorScheme.error) }
                    is DumpResult.Ok -> {
                        item { Text("${r.value.size} service(s) actif(s)", style = MaterialTheme.typography.labelMedium) }
                        items(r.value, key = { it.packageName + "/" + it.service }) { sv ->
                            ListItem(
                                headlineContent = { Text(sv.label, maxLines = 1) },
                                supportingContent = { Text("${sv.packageName}\n${sv.service}") }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RootCard(report: RootReport?) {
    InfoCard("Vérification du root") {
        if (report == null) {
            Text("Analyse en cours…")
        } else {
            Text(
                if (report.rooted) "Appareil probablement rooté" else "Aucun indice de root détecté",
                style = MaterialTheme.typography.titleMedium,
                color = if (report.rooted) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
            )
            report.findings.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
            Text(
                "Détection heuristique : certains outils (Magisk DenyList…) peuvent masquer le root.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun AppRow(app: AppEntry) {
    val ctx = LocalContext.current
    ListItem(
        modifier = Modifier.clickable {
            runCatching {
                ctx.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        },
        headlineContent = { Text(app.label, maxLines = 1) },
        supportingContent = {
            Text(
                buildString {
                    append(app.packageName)
                    if (app.risks.isNotEmpty()) append("\n" + app.risks.joinToString(" · ") { it.label })
                }
            )
        },
        trailingContent = {
            Text(if (app.isSystem) "Système" else "Utilisateur", style = MaterialTheme.typography.labelSmall)
        }
    )
}
