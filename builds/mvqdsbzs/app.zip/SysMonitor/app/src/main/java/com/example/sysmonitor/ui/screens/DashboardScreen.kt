package com.example.sysmonitor.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.sysmonitor.data.formatBytes
import com.example.sysmonitor.data.formatFreq
import com.example.sysmonitor.ui.InfoCard
import com.example.sysmonitor.ui.KeyValue
import com.example.sysmonitor.ui.LoadingBox
import com.example.sysmonitor.ui.ScreenColumn
import com.example.sysmonitor.ui.UsageBar
import com.example.sysmonitor.ui.viewmodel.MonitorViewModel
import kotlin.math.roundToInt

/** Tableau de bord : RAM, stockage, CPU (global + par cœur) et sondes thermiques. */
@Composable
fun DashboardScreen(vm: MonitorViewModel) {
    val snap by vm.snapshot.collectAsStateWithLifecycle()
    val s = snap
    if (s == null) {
        LoadingBox()
        return
    }

    ScreenColumn {
        InfoCard("Mémoire vive (RAM)") {
            UsageBar(s.ram.usedPercent / 100f, warn = s.ram.usedPercent >= 90f)
            KeyValue("Utilisée", "${formatBytes(s.ram.usedBytes)} (${s.ram.usedPercent.roundToInt()} %)")
            KeyValue("Disponible", formatBytes(s.ram.availBytes))
            KeyValue("Totale", formatBytes(s.ram.totalBytes))
            if (s.ram.lowMemory) Text("Le système signale une mémoire faible.", color = MaterialTheme.colorScheme.error)
        }

        InfoCard("Stockage") {
            s.storage.forEach { v ->
                Column {
                    KeyValue(v.label, "${formatBytes(v.usedBytes)} / ${formatBytes(v.totalBytes)} (${v.usedPercent.roundToInt()} %)")
                    UsageBar(v.usedPercent / 100f, warn = v.usedPercent >= 90f)
                }
            }
            if (s.storage.none { it.removable }) {
                Text(
                    "Aucune carte SD / stockage externe amovible détecté.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        InfoCard("Processeur") {
            KeyValue(
                if (s.cpu.loadEstimated) "Charge (estimée via les fréquences)" else "Charge globale",
                "${s.cpu.loadPercent.roundToInt()} %"
            )
            UsageBar(s.cpu.loadPercent / 100f, warn = s.cpu.loadPercent >= 90f)
            if (s.cpu.loadEstimated) {
                Text(
                    "Android 8+ bloque /proc/stat pour les applications : la charge exacte n'est pas lisible.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            HorizontalDivider()
            s.cpu.cores.forEach { c ->
                Column {
                    KeyValue(
                        "Cœur ${c.index}",
                        if (c.online) "${formatFreq(c.curKhz)} / ${formatFreq(c.maxKhz)}" else "hors ligne"
                    )
                    if (c.online && c.maxKhz > 0) UsageBar(c.ratio)
                }
            }
        }

        InfoCard("Températures") {
            KeyValue("Batterie", "%.1f °C".format(s.battery.tempC))
            s.thermal.statusLabel?.let { KeyValue("État thermique Android", it) }
            s.thermal.headroom?.let { KeyValue("Indice thermique (1,0 = bridage)", "%.2f".format(it)) }
            if (s.thermal.zones.isEmpty()) {
                Text(
                    "Sondes détaillées (CPU, GPU…) non accessibles : restriction SELinux sur cet appareil.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                HorizontalDivider()
                s.thermal.zones.forEach { z -> KeyValue(z.name, "%.1f °C".format(z.tempC)) }
            }
        }
    }
}
