package com.example.sysmonitor.data

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.PowerManager
import kotlin.math.abs

/** Lecture de l'état batterie via l'intent collant ACTION_BATTERY_CHANGED + BatteryManager. */
object BatteryReader {

    fun read(ctx: Context): BatteryInfo {
        val i: Intent? = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val percent = if (level >= 0 && scale > 0) level * 100 / scale else 0
        val statusCode = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val plugged = i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
        val healthCode = i?.getIntExtra(BatteryManager.EXTRA_HEALTH, 0) ?: 0
        val tempTenths = i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
        val voltage = i?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0
        val tech = i?.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY).orEmpty().ifBlank { "—" }

        val status = when (statusCode) {
            BatteryManager.BATTERY_STATUS_CHARGING -> "En charge"
            BatteryManager.BATTERY_STATUS_DISCHARGING -> "En décharge"
            BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Ne charge pas"
            BatteryManager.BATTERY_STATUS_FULL -> "Pleine"
            else -> "Inconnu"
        }
        val source = when (plugged) {
            BatteryManager.BATTERY_PLUGGED_AC -> "Secteur (AC)"
            BatteryManager.BATTERY_PLUGGED_USB -> "USB"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Sans fil"
            8 -> "Dock"
            else -> "Batterie (aucune source)"
        }
        val health = when (healthCode) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Bonne"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Surchauffe"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Défaillante"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Surtension"
            BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "Défaillance"
            BatteryManager.BATTERY_HEALTH_COLD -> "Trop froide"
            else -> "Inconnue"
        }

        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val rawCurrent = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        // L'unité varie selon les constructeurs (µA le plus souvent, mA parfois) : heuristique.
        val currentMa = if (rawCurrent == Int.MIN_VALUE || rawCurrent == 0) null
        else if (abs(rawCurrent) >= 10_000) rawCurrent / 1000 else rawCurrent

        val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
        return BatteryInfo(
            percent = percent,
            status = status,
            charging = statusCode == BatteryManager.BATTERY_STATUS_CHARGING || statusCode == BatteryManager.BATTERY_STATUS_FULL,
            source = source,
            tempC = tempTenths / 10f,
            voltageMv = voltage,
            health = health,
            technology = tech,
            currentMa = currentMa,
            powerSave = pm.isPowerSaveMode,
            deviceIdle = pm.isDeviceIdleMode
        )
    }
}
