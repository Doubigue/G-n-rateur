package com.example.sysmonitor.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import com.example.sysmonitor.R
import com.example.sysmonitor.data.AppSettings
import com.example.sysmonitor.data.DeviceSnapshot
import com.example.sysmonitor.data.EventLogger
import com.example.sysmonitor.ui.AlertActivity
import com.example.sysmonitor.ui.MainActivity
import kotlin.math.roundToInt

/** Création des canaux et émission des notifications (service permanent + alertes critiques). */
object AlertNotifier {
    const val CH_MONITOR = "monitor"
    const val CH_ALERTS = "alerts"

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_MONITOR, "Surveillance en cours", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_ALERTS, "Alertes critiques", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Surchauffe, stockage saturé, mémoire saturée, batterie faible"
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
        )
    }

    private fun openApp(ctx: Context): PendingIntent = PendingIntent.getActivity(
        ctx, 0, Intent(ctx, MainActivity::class.java),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    fun monitorNotification(ctx: Context, text: String): Notification =
        NotificationCompat.Builder(ctx, CH_MONITOR)
            .setSmallIcon(R.drawable.ic_monitor)
            .setContentTitle("System Monitor actif")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openApp(ctx))
            .build()

    fun serverNotification(ctx: Context, text: String): Notification =
        NotificationCompat.Builder(ctx, CH_MONITOR)
            .setSmallIcon(R.drawable.ic_monitor)
            .setContentTitle("Serveur web local actif")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(openApp(ctx))
            .build()

    /**
     * Alerte critique. Si l'option est activée, un "full-screen intent" ouvre [AlertActivity]
     * par-dessus l'écran de verrouillage (écran éteint ou verrouillé uniquement).
     */
    fun alert(ctx: Context, id: Int, title: String, text: String) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val alertIntent = Intent(ctx, AlertActivity::class.java)
            .putExtra(AlertActivity.EXTRA_TITLE, title)
            .putExtra(AlertActivity.EXTRA_TEXT, text)
            .putExtra(AlertActivity.EXTRA_ID, id)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val fullScreen = PendingIntent.getActivity(
            ctx, id, alertIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val builder = NotificationCompat.Builder(ctx, CH_ALERTS)
            .setSmallIcon(R.drawable.ic_monitor)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ERROR)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setContentIntent(openApp(ctx))
            .setAutoCancel(true)
        if (AppSettings(ctx).lockScreenAlerts) builder.setFullScreenIntent(fullScreen, true)
        nm.notify(id, builder.build())
        EventLogger.log(ctx, "ALERT", "Alerte", "$title — $text")
    }
}

/** Règles d'alerte à seuils configurables, avec délai anti-répétition de 15 minutes par règle. */
class AlertEngine(private val ctx: Context) {
    private val settings = AppSettings(ctx)
    private val lastFired = HashMap<Int, Long>()

    private fun fire(id: Int, active: Boolean, title: String, text: String) {
        if (!active) return
        val now = SystemClock.elapsedRealtime()
        val last = lastFired[id]
        if (last != null && now - last < COOLDOWN_MS) return
        lastFired[id] = now
        AlertNotifier.alert(ctx, id, title, text)
    }

    fun evaluate(s: DeviceSnapshot) {
        fire(
            ID_TEMP, s.battery.tempC >= settings.batteryTempC,
            "Surchauffe de la batterie",
            "%.1f °C — seuil réglé à %d °C".format(s.battery.tempC, settings.batteryTempC)
        )
        val internal = s.storage.firstOrNull()
        if (internal != null) {
            fire(
                ID_STORAGE, internal.usedPercent >= settings.storagePercent,
                "Stockage presque plein",
                "Stockage interne utilisé à ${internal.usedPercent.roundToInt()} % (seuil ${settings.storagePercent} %)"
            )
        }
        fire(
            ID_RAM, s.ram.usedPercent >= settings.ramPercent,
            "Mémoire vive saturée",
            "RAM utilisée à ${s.ram.usedPercent.roundToInt()} % (seuil ${settings.ramPercent} %)"
        )
        fire(
            ID_BATT, !s.battery.charging && s.battery.percent <= settings.lowBatteryPercent,
            "Batterie faible",
            "Niveau à ${s.battery.percent} % (seuil ${settings.lowBatteryPercent} %)"
        )
    }

    private companion object {
        const val COOLDOWN_MS = 15 * 60_000L
        const val ID_TEMP = 101
        const val ID_STORAGE = 102
        const val ID_RAM = 103
        const val ID_BATT = 104
    }
}
