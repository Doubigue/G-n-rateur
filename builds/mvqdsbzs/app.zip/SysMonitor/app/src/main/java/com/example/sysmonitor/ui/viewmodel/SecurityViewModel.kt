package com.example.sysmonitor.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.sysmonitor.data.AppAuditor
import com.example.sysmonitor.data.AppEntry
import com.example.sysmonitor.data.DumpResult
import com.example.sysmonitor.data.DumpsysReader
import com.example.sysmonitor.data.RootChecker
import com.example.sysmonitor.data.RootReport
import com.example.sysmonitor.data.ServiceEntry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/** Applications installées, audit des permissions, root et services actifs. */
class SecurityViewModel(app: Application) : AndroidViewModel(app) {

    private val _apps = MutableStateFlow<List<AppEntry>?>(null)
    val apps: StateFlow<List<AppEntry>?> = _apps.asStateFlow()

    private val _root = MutableStateFlow<RootReport?>(null)
    val root: StateFlow<RootReport?> = _root.asStateFlow()

    private val _services = MutableStateFlow<DumpResult<List<ServiceEntry>>?>(null)
    val services: StateFlow<DumpResult<List<ServiceEntry>>?> = _services.asStateFlow()

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch(Dispatchers.IO) {
            _root.value = RootChecker.check(getApplication())
            _apps.value = AppAuditor.scan(getApplication())
            _services.value = DumpsysReader.activeServices(getApplication())
        }
    }
}
