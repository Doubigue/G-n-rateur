package com.example.sysmonitor.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import kotlinx.coroutines.flow.MutableSharedFlow
import java.io.OutputStream
import java.security.KeyStore
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Exécuteur mono-thread partagé : sérialise les écritures SQLite et les tâches courtes en arrière-plan. */
object IoExecutor {
    val single = Executors.newSingleThreadExecutor()
}

/** Base SQLite locale : journal d'événements + historique du presse-papiers (chiffré). */
class AppDatabase private constructor(ctx: Context) : SQLiteOpenHelper(ctx, "sysmonitor.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE logs (id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, " +
                "level TEXT NOT NULL, tag TEXT NOT NULL, message TEXT NOT NULL)"
        )
        db.execSQL("CREATE TABLE clips (id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, content BLOB NOT NULL)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    companion object {
        @Volatile
        private var instance: AppDatabase? = null

        fun get(ctx: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: AppDatabase(ctx.applicationContext).also { instance = it }
        }
    }
}

// ───────────────────────────── Journal d'événements ─────────────────────────────

data class LogEntry(val id: Long, val ts: Long, val level: String, val tag: String, val message: String)

object EventLogger {
    private const val MAX_ROWS = 2000

    /** Émet à chaque écriture : permet à l'UI de se rafraîchir sans polling. */
    val updates = MutableSharedFlow<Unit>(extraBufferCapacity = 1)

    fun log(ctx: Context, level: String, tag: String, message: String) {
        val app = ctx.applicationContext
        IoExecutor.single.execute {
            runCatching {
                val db = AppDatabase.get(app).writableDatabase
                db.insert("logs", null, ContentValues().apply {
                    put("ts", System.currentTimeMillis())
                    put("level", level)
                    put("tag", tag)
                    put("message", message)
                })
                db.execSQL("DELETE FROM logs WHERE id <= (SELECT MAX(id) FROM logs) - $MAX_ROWS")
                updates.tryEmit(Unit)
            }
        }
    }

    fun info(ctx: Context, tag: String, message: String) = log(ctx, "INFO", tag, message)
    fun warn(ctx: Context, tag: String, message: String) = log(ctx, "WARN", tag, message)

    /** Lecture bloquante : à appeler hors du thread principal. */
    fun recent(ctx: Context, limit: Int = 300): List<LogEntry> {
        val out = ArrayList<LogEntry>()
        AppDatabase.get(ctx).readableDatabase.rawQuery(
            "SELECT id, ts, level, tag, message FROM logs ORDER BY id DESC LIMIT ?",
            arrayOf(limit.toString())
        ).use { c ->
            while (c.moveToNext()) {
                out += LogEntry(c.getLong(0), c.getLong(1), c.getString(2), c.getString(3), c.getString(4))
            }
        }
        return out
    }

    fun clear(ctx: Context) {
        AppDatabase.get(ctx).writableDatabase.execSQL("DELETE FROM logs")
        updates.tryEmit(Unit)
    }

    /** Exporte tout le journal au format texte brut (ordre chronologique). */
    fun exportText(ctx: Context, out: OutputStream) {
        val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        out.bufferedWriter().use { w ->
            w.write("# System Monitor — journal des événements\n")
            AppDatabase.get(ctx).readableDatabase
                .rawQuery("SELECT ts, level, tag, message FROM logs ORDER BY id ASC", null)
                .use { c ->
                    while (c.moveToNext()) {
                        w.write("${fmt.format(Date(c.getLong(0)))} [${c.getString(1)}] ${c.getString(2)}: ${c.getString(3)}\n")
                    }
                }
        }
    }
}

// ───────────────────────────── Presse-papiers sécurisé ─────────────────────────────

data class ClipEntry(val id: Long, val ts: Long, val text: String)

/** Chiffrement AES-256-GCM, clé stockée dans l'Android Keystore (non exportable). */
object CryptoBox {
    private const val ALIAS = "sysmonitor_clip_key"
    private const val GCM_TAG_BITS = 128
    private const val IV_SIZE = 12

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    /** Retourne IV (12 octets) + texte chiffré. */
    fun encrypt(text: String): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        return cipher.iv + cipher.doFinal(text.toByteArray(Charsets.UTF_8))
    }

    fun decrypt(data: ByteArray): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(GCM_TAG_BITS, data, 0, IV_SIZE))
        return cipher.doFinal(data, IV_SIZE, data.size - IV_SIZE).toString(Charsets.UTF_8)
    }
}

object ClipStore {
    private const val MAX_ITEMS = 50
    val updates = MutableSharedFlow<Unit>(extraBufferCapacity = 1)

    fun add(ctx: Context, text: String) {
        val app = ctx.applicationContext
        IoExecutor.single.execute {
            runCatching {
                if (recent(app, 1).firstOrNull()?.text == text) return@runCatching // évite les doublons
                val db = AppDatabase.get(app).writableDatabase
                db.insert("clips", null, ContentValues().apply {
                    put("ts", System.currentTimeMillis())
                    put("content", CryptoBox.encrypt(text))
                })
                db.execSQL("DELETE FROM clips WHERE id <= (SELECT MAX(id) FROM clips) - $MAX_ITEMS")
                updates.tryEmit(Unit)
            }
        }
    }

    fun recent(ctx: Context, limit: Int = MAX_ITEMS): List<ClipEntry> {
        val out = ArrayList<ClipEntry>()
        AppDatabase.get(ctx).readableDatabase.rawQuery(
            "SELECT id, ts, content FROM clips ORDER BY id DESC LIMIT ?",
            arrayOf(limit.toString())
        ).use { c ->
            while (c.moveToNext()) {
                val text = runCatching { CryptoBox.decrypt(c.getBlob(2)) }.getOrNull() ?: continue
                out += ClipEntry(c.getLong(0), c.getLong(1), text)
            }
        }
        return out
    }

    fun delete(ctx: Context, id: Long) {
        AppDatabase.get(ctx).writableDatabase.execSQL("DELETE FROM clips WHERE id = ?", arrayOf<Any>(id))
        updates.tryEmit(Unit)
    }

    fun clear(ctx: Context) {
        AppDatabase.get(ctx).writableDatabase.execSQL("DELETE FROM clips")
        updates.tryEmit(Unit)
    }
}
