package com.example.sysmonitor.ui

import android.app.NotificationManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.sysmonitor.ui.theme.SysMonitorTheme

/**
 * Écran d'alerte minimal affiché par-dessus l'écran de verrouillage (showWhenLocked + turnScreenOn).
 * Il ne montre que le message d'alerte : l'application complète demande le déverrouillage.
 */
class AlertActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Équivalent runtime de android:showWhenLocked / android:turnScreenOn du Manifest
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val title = intent.getStringExtra(EXTRA_TITLE) ?: "Alerte système"
        val text = intent.getStringExtra(EXTRA_TEXT) ?: ""
        val id = intent.getIntExtra(EXTRA_ID, -1)

        setContent {
            SysMonitorTheme {
                Surface(Modifier.fillMaxSize()) {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(32.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Default.Warning, contentDescription = null,
                            tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(64.dp)
                        )
                        Text(title, style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center)
                        Text(text, style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center)
                        Button(onClick = { dismiss(id) }) { Text("Fermer") }
                        TextButton(onClick = {
                            dismiss(id)
                            startActivity(Intent(this@AlertActivity, MainActivity::class.java))
                        }) { Text("Ouvrir l'application") }
                    }
                }
            }
        }
    }

    private fun dismiss(id: Int) {
        if (id >= 0) getSystemService(NotificationManager::class.java).cancel(id)
        finish()
    }

    companion object {
        const val EXTRA_TITLE = "title"
        const val EXTRA_TEXT = "text"
        const val EXTRA_ID = "id"
    }
}
