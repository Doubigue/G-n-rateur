package com.example.sysmonitor.data

import org.json.JSONArray
import org.json.JSONObject

private fun Float.safe(): Double = if (isNaN() || isInfinite()) 0.0 else toDouble()

/** Sérialisation JSON de l'instantané (consommée par le tableau de bord web). */
fun DeviceSnapshot.toJson(): JSONObject = JSONObject().apply {
    put("timestamp", timestamp)
    put("ram", JSONObject()
        .put("total", ram.totalBytes).put("available", ram.availBytes)
        .put("used", ram.usedBytes).put("percent", ram.usedPercent.safe()).put("low", ram.lowMemory))
    put("storage", JSONArray(storage.map {
        JSONObject().put("label", it.label).put("total", it.totalBytes).put("free", it.freeBytes)
            .put("used", it.usedBytes).put("percent", it.usedPercent.safe()).put("removable", it.removable)
    }))
    put("cpu", JSONObject()
        .put("load", cpu.loadPercent.safe()).put("estimated", cpu.loadEstimated)
        .put("cores", JSONArray(cpu.cores.map {
            JSONObject().put("index", it.index).put("online", it.online).put("cur", it.curKhz).put("max", it.maxKhz)
        })))
    put("thermal", JSONObject()
        .put("status", thermal.statusLabel ?: JSONObject.NULL)
        .put("headroom", thermal.headroom?.safe() ?: JSONObject.NULL)
        .put("zones", JSONArray(thermal.zones.map {
            JSONObject().put("name", it.name).put("temp", it.tempC.safe())
        })))
    put("battery", JSONObject()
        .put("percent", battery.percent).put("status", battery.status).put("charging", battery.charging)
        .put("source", battery.source).put("temp", battery.tempC.safe()).put("voltage", battery.voltageMv)
        .put("health", battery.health).put("technology", battery.technology)
        .put("current", battery.currentMa ?: JSONObject.NULL)
        .put("powerSave", battery.powerSave).put("deviceIdle", battery.deviceIdle))
    put("network", JSONObject()
        .put("type", network.type).put("ip", network.ip ?: JSONObject.NULL)
        .put("validated", network.validated).put("connected", network.connected))
    put("bandwidth", JSONObject().put("down", bandwidth.downBps).put("up", bandwidth.upBps))
}

fun List<LogEntry>.toJson(): JSONArray = JSONArray(map {
    JSONObject().put("ts", it.ts).put("level", it.level).put("tag", it.tag).put("message", it.message)
})
