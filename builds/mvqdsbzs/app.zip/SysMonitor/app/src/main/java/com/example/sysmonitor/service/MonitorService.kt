package com.example.sysmonitor.service

import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.os.IBinder
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.example.sysmonitor.data.ClipboardTracker
import com.example.sysmonitor.data.EventLogger
import com.example.sysmonitor.data.MetricsSampler
import com.example.sysmonitor.widget.StatsWidget
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * Service au premier plan : échantillonne l'appareil toutes les 10 s, évalue les alertes,
 * met à jour le widget et journalise les événements clés (charge, réseau, presse-papiers).
 */
class MonitorService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var loop: Job? = null
    private lateinit var engine: AlertEngine
    private lateinit var clipboard: ClipboardManager
    private lateinit var connectivity: ConnectivityManager

    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener {
        ClipboardTracker.capture(applicationContext)
    }

    private val powerReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val msg = when (intent.action) {
                Intent.ACTION_POWER_CONNECTED -> "Chargeur branché"
                Intent.ACTION_POWER_DISCONNECTED -> "Chargeur débranché"
                Intent.ACTION_BATTERY_LOW -> "Niveau de batterie faible (signal système)"
                Intent.ACTION_BATTERY_OKAY -> "Niveau de batterie rétabli (signal système)"
                else -> return
            }
            EventLogger.info(context, "Batterie", msg)
        }
    }

    private val netCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            EventLogger.info(applicationContext, "Réseau", "Réseau par défaut disponible")
        }

        override fun onLost(network: Network) {
            EventLogger.warn(applicationContext, "Réseau", "Réseau par défaut perdu")
        }
    }

    override fun onCreate() {
        super.onCreate()
        engine = AlertEngine(applicationContext)
        clipboard = getSystemService(ClipboardManager::class.java)
        connectivity = getSystemService(ConnectivityManager::class.java)

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
            addAction(Intent.ACTION_BATTERY_LOW)
            addAction(Intent.ACTION_BATTERY_OKAY)
        }
        ContextCompat.registerReceiver(this, powerReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        clipboard.addPrimaryClipChangedListener(clipListener)
        connectivity.registerDefaultNetworkCallback(netCallback)
        EventLogger.info(this, "Service", "Surveillance démarrée")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Doit être appelé dans les 5 s suivant startForegroundService()
        ServiceCompat.startForeground(
            this, NOTIF_ID,
            AlertNotifier.monitorNotification(this, "Initialisation…"),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        )
        if (loop == null) {
            loop = scope.launch {
                val sampler = MetricsSampler(applicationContext)
                val nm = getSystemService(NotificationManager::class.java)
                while (isActive) {
                    val snap = sampler.sample()
                    engine.evaluate(snap)
                    val temp = "%.0f".format(snap.battery.tempC)
                    val text = "Batterie ${snap.battery.percent} % · $temp °C · RAM ${snap.ram.usedPercent.roundToInt()} %"
                    nm.notify(NOTIF_ID, AlertNotifier.monitorNotification(applicationContext, text))
                    StatsWidget.refresh(applicationContext, snap)
                    delay(INTERVAL_MS)
                }
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        runCatching { unregisterReceiver(powerReceiver) }
        runCatching { clipboard.removePrimaryClipChangedListener(clipListener) }
        runCatching { connectivity.unregisterNetworkCallback(netCallback) }
        EventLogger.info(this, "Service", "Surveillance arrêtée")
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val NOTIF_ID = 1
        private const val INTERVAL_MS = 10_000L

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, MonitorService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, MonitorService::class.java))
        }
    }
}
