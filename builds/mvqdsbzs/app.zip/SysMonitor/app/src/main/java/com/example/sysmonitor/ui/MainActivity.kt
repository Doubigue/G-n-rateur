package com.example.sysmonitor.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.sysmonitor.data.ClipboardTracker
import com.example.sysmonitor.ui.screens.BatteryScreen
import com.example.sysmonitor.ui.screens.DashboardScreen
import com.example.sysmonitor.ui.screens.LogsScreen
import com.example.sysmonitor.ui.screens.NetworkScreen
import com.example.sysmonitor.ui.screens.SecurityScreen
import com.example.sysmonitor.ui.screens.SettingsScreen
import com.example.sysmonitor.ui.theme.SysMonitorTheme
import com.example.sysmonitor.ui.viewmodel.LogsViewModel
import com.example.sysmonitor.ui.viewmodel.MonitorViewModel
import com.example.sysmonitor.ui.viewmodel.SecurityViewModel

/** Activité unique (Compose) : barre de navigation inférieure + écran de paramètres. */
class MainActivity : ComponentActivity() {

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* refus toléré */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent { SysMonitorTheme { MainScaffold() } }
    }

    /** Android 10+ : le presse-papiers n'est lisible que lorsque la fenêtre a le focus. */
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) ClipboardTracker.capture(this)
    }
}

private enum class AppTab(val label: String, val icon: ImageVector) {
    SYSTEM("Système", Icons.Default.Dashboard),
    BATTERY("Batterie", Icons.Default.BatteryFull),
    NETWORK("Réseau", Icons.Default.Wifi),
    SECURITY("Sécurité", Icons.Default.Security),
    LOGS("Journal", Icons.Default.History)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MainScaffold() {
    var tab by rememberSaveable { mutableStateOf(AppTab.SYSTEM) }
    var showSettings by rememberSaveable { mutableStateOf(false) }

    // ViewModels (MVVM) : survivent aux rotations, partagés entre les onglets
    val monitorVm: MonitorViewModel = viewModel()
    val securityVm: SecurityViewModel = viewModel()
    val logsVm: LogsViewModel = viewModel()

    BackHandler(enabled = showSettings) { showSettings = false }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (showSettings) "Paramètres" else tab.label) },
                navigationIcon = {
                    if (showSettings) {
                        IconButton(onClick = { showSettings = false }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
                        }
                    }
                },
                actions = {
                    if (!showSettings) {
                        IconButton(onClick = { showSettings = true }) {
                            Icon(Icons.Default.Settings, contentDescription = "Paramètres")
                        }
                    }
                }
            )
        },
        bottomBar = {
            if (!showSettings) {
                NavigationBar {
                    AppTab.entries.forEach { t ->
                        NavigationBarItem(
                            selected = tab == t,
                            onClick = { tab = t },
                            icon = { Icon(t.icon, contentDescription = null) },
                            label = { Text(t.label) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding)) {
            if (showSettings) {
                SettingsScreen()
            } else {
                when (tab) {
                    AppTab.SYSTEM -> DashboardScreen(monitorVm)
                    AppTab.BATTERY -> BatteryScreen(monitorVm)
                    AppTab.NETWORK -> NetworkScreen(monitorVm)
                    AppTab.SECURITY -> SecurityScreen(securityVm)
                    AppTab.LOGS -> LogsScreen(logsVm)
                }
            }
        }
    }
}
