package com.linkshare.core

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import java.io.File

/** Valeurs partagées avec MediaStudio (RouterContract.kt). Toute modification doit être faite des deux côtés. */
object StudioContract {
    /**
     * Identifiants possibles de l'appli installée : l'applicationId peut être réécrit à la compilation
     * (ex. com.doubigue.converter) alors que les classes restent dans com.mediastudio.app.
     */
    val PACKAGES = listOf("com.doubigue.converter", "com.mediastudio.app")
    const val ROUTER_CLASS = "com.mediastudio.app.MediaStudioRouterActivity"

    const val ACTION_TO_MP3 = "com.mediastudio.app.action.TO_MP3"
    const val ACTION_TO_MP4 = "com.mediastudio.app.action.TO_MP4"
    /** Nombre maximal de fichiers acceptés par le routeur de Media Studio. */
    const val MAX_FILES = 50
    const val ACTION_COMPRESS = "com.mediastudio.app.action.COMPRESS_VIDEO"
    const val ACTION_EFFECT = "com.mediastudio.app.action.APPLY_EFFECT"
    const val ACTION_MIX = "com.mediastudio.app.action.MIX_MUSIC"
    const val ACTION_CONCAT = "com.mediastudio.app.action.CONCAT"
    const val ACTION_TRANSFORM = "com.mediastudio.app.action.TRANSFORM"
    const val ACTION_SPEED = "com.mediastudio.app.action.SPEED"
    const val ACTION_VOLUME = "com.mediastudio.app.action.VOLUME"
    const val ACTION_MUTE = "com.mediastudio.app.action.MUTE"
    const val ACTION_AUDIO_EFFECT = "com.mediastudio.app.action.AUDIO_EFFECT"
    const val ACTION_FRAME = "com.mediastudio.app.action.FRAME"
    const val ACTION_FRAME_COUNT = "com.mediastudio.app.action.FRAME_COUNT"
    const val ACTION_EXTRACT_FRAMES = "com.mediastudio.app.action.EXTRACT_FRAMES"
    const val ACTION_REBUILD_VIDEO = "com.mediastudio.app.action.REBUILD_VIDEO"
    const val ACTION_IMAGE = "com.mediastudio.app.action.IMAGE"
    const val ACTION_IMAGES_TO_PDF = "com.mediastudio.app.action.IMAGES_TO_PDF"
    const val ACTION_WORD_TO_PDF = "com.mediastudio.app.action.WORD_TO_PDF"
    const val ACTION_PDF_TO_WORD = "com.mediastudio.app.action.PDF_TO_WORD"
    const val ACTION_TEXT_TO_PDF = "com.mediastudio.app.action.TEXT_TO_PDF"
    // Sous-titres (Whisper hors ligne, dans Media Studio)
    const val ACTION_TRANSCRIBE = "com.mediastudio.app.action.TRANSCRIBE"
    const val ACTION_SUBTITLE_STUDIO = "com.mediastudio.app.action.SUBTITLE_STUDIO"
    const val ACTION_BURN_SUBTITLES = "com.mediastudio.app.action.BURN_SUBTITLES"
    const val ACTION_IMPORT_WHISPER_MODEL = "com.mediastudio.app.action.IMPORT_WHISPER_MODEL"

    const val EXTRA_BITRATE_KBPS = "bitrate_kbps"
    const val EXTRA_MAX_HEIGHT = "max_height"
    const val EXTRA_VIDEO_BITRATE = "video_bitrate"
    const val EXTRA_FILTER = "filter"
    const val EXTRA_TEXT = "overlay_text"
    const val EXTRA_TEXT_POS = "text_pos"
    const val EXTRA_LOGO_SCALE = "logo_scale"
    const val EXTRA_LOGO_POSITION = "logo_position"
    const val EXTRA_KEEP_AUDIO = "keep_original_audio"
    const val EXTRA_VIDEO_VOLUME = "video_volume"
    const val EXTRA_MUSIC_VOLUME = "music_volume"
    const val EXTRA_FADE = "fade"
    const val EXTRA_ROTATE_DEG = "rotate_deg"
    const val EXTRA_FLIP_H = "flip_h"
    const val EXTRA_SPEED = "speed"
    const val EXTRA_VOLUME = "volume"
    const val EXTRA_AUDIO_PRESET = "audio_preset"
    const val EXTRA_TIME_MS = "time_ms"
    const val EXTRA_IMG_FORMAT = "img_format"
    const val EXTRA_IMG_QUALITY = "img_quality"
    const val EXTRA_IMG_MAX_SIDE = "img_max_side"
    const val EXTRA_LANGUAGE = "language"
    const val EXTRA_SUB_FORMAT = "sub_format"
    const val EXTRA_ALSO_TXT = "also_txt"
    const val EXTRA_TRANSLATE = "translate"
    const val EXTRA_MAX_CHARS = "max_chars"
    const val EXTRA_ACCURATE = "accurate"
    const val EXTRA_SUB_STYLE = "sub_style"
    const val EXTRA_SUB_SIZE = "sub_size"
    const val EXTRA_SUB_POSITION = "sub_position"

    const val EXTRA_MP4_MODE = "mp4_mode"
    const val EXTRA_MP4_ALLOW_MUTE = "mp4_allow_mute"

    const val EXTRA_OUTPUT_NAME = "output_name"
    const val EXTRA_OUTPUT_SUMMARY = "output_summary"
    const val EXTRA_ERROR = "error"
}

/** Filtres proposés (les identifiants sont les noms de l'enum Filter de MediaStudio). */
enum class StudioFilter(val id: String, val label: String, val swatch: Long) {
    NOIR("NOIR", "Noir & blanc", 0xFF9E9E9E), WARM("WARM", "Chaud", 0xFFFF9800), COOL("COOL", "Froid", 0xFF42A5F5),
    VIVID("VIVID", "Vif", 0xFFE91E63), CONTRAST("CONTRAST", "Contraste", 0xFF212121),
    BRIGHT("BRIGHT", "Lumineux", 0xFFFFEB3B), INVERT("INVERT", "Inversé", 0xFF7E57C2),
}

enum class StudioAudioPreset(val id: String, val label: String, val description: String) {
    RADIO("RADIO", "Radio ancienne", "Bande FM étroite, grain vintage et saturation douce"),
    PHONE("PHONE", "Téléphone", "Voix centrée sur les fréquences de parole"),
    BASS("BASS", "Basses renforcées", "Donne plus de profondeur aux graves"),
    TREBLE("TREBLE", "Aigus clairs", "Accentue les détails et la présence"),
    ECHO("ECHO", "Écho léger", "Ajoute une répétition discrète du son"),
}

enum class StudioTextPos(val id: String, val label: String) {
    TOP("TOP", "Haut"), MIDDLE("MIDDLE", "Milieu"), BOTTOM("BOTTOM", "Bas"),
}

enum class StudioLogoPosition(val id: String, val label: String) {
    TOP_LEFT("TOP_LEFT", "Haut gauche"), TOP_RIGHT("TOP_RIGHT", "Haut droite"),
}

/** Styles d'incrustation (identifiants = enum SubPreset de MediaStudio). */
enum class StudioSubStyle(val id: String, val label: String, val swatch: Long) {
    CLASSIC("CLASSIC", "Classique", 0xFFFFFFFF), BOX("BOX", "Boîte noire", 0xFF212121),
    YELLOW("YELLOW", "Jaune ciné", 0xFFFFE14D), GOLD("GOLD", "Doré DL VIBE", 0xFFF2C75C),
    NEON("NEON", "Néon", 0xFF6FF6FF), PINK("PINK", "Rose pop", 0xFFE0337A),
}

/** Langues proposées pour la transcription (codes Whisper). */
enum class StudioLanguage(val code: String, val label: String) {
    FR("fr", "Français"), EN("en", "Anglais"), ES("es", "Espagnol"), PT("pt", "Portugais"),
    AR("ar", "Arabe"), DE("de", "Allemand"), SW("sw", "Swahili"),
}

/** Une commande = une action du routeur + ses paramètres. Construite uniquement par les fabriques ci-dessous. */
class StudioCommand private constructor(val action: String, private val extras: Bundle) {

    fun applyTo(intent: Intent): Intent = intent.putExtras(extras)

    companion object {
        fun toMp3(bitrateKbps: Int = 192) = StudioCommand(StudioContract.ACTION_TO_MP3, Bundle().apply {
            putInt(StudioContract.EXTRA_BITRATE_KBPS, bitrateKbps)
        })

        /**
         * Convertit une ou plusieurs vidéos (MKV, AVI, WebM, MOV, TS…) en MP4, une par une.
         * [compatible] : image mise en H.264 ; sinon H.264 / H.265 copiés sans réencodage.
         */
        fun toMp4(compatible: Boolean = false) = StudioCommand(StudioContract.ACTION_TO_MP4, Bundle().apply {
            putString(StudioContract.EXTRA_MP4_MODE, if (compatible) "H264" else "AUTO")
        })

        fun compress(maxHeight: Int, videoBitrate: Int) = StudioCommand(StudioContract.ACTION_COMPRESS, Bundle().apply {
            putInt(StudioContract.EXTRA_MAX_HEIGHT, maxHeight)
            putInt(StudioContract.EXTRA_VIDEO_BITRATE, videoBitrate)
        })

        fun effect(filter: StudioFilter?, text: String = "", pos: StudioTextPos = StudioTextPos.BOTTOM) =
            StudioCommand(StudioContract.ACTION_EFFECT, Bundle().apply {
                filter?.let { putString(StudioContract.EXTRA_FILTER, it.id) }
                if (text.isNotBlank()) {
                    putString(StudioContract.EXTRA_TEXT, text.trim())
                    putString(StudioContract.EXTRA_TEXT_POS, pos.id)
                }
            })

        /** Incruste un logo : fichiers attendus dans l'ordre vidéo puis image. */
        fun logo(scale: Float = 0.18f, position: StudioLogoPosition = StudioLogoPosition.TOP_RIGHT) =
            StudioCommand(StudioContract.ACTION_EFFECT, Bundle().apply {
                putFloat(StudioContract.EXTRA_LOGO_SCALE, scale.coerceIn(0.08f, 0.45f))
                putString(StudioContract.EXTRA_LOGO_POSITION, position.id)
            })

        /** Fichiers attendus : une vidéo et une musique (dans n'importe quel ordre). */
        fun mix(keepOriginalAudio: Boolean = true, videoVolume: Float = 1f, musicVolume: Float = 0.8f) =
            StudioCommand(StudioContract.ACTION_MIX, Bundle().apply {
                putBoolean(StudioContract.EXTRA_KEEP_AUDIO, keepOriginalAudio)
                putFloat(StudioContract.EXTRA_VIDEO_VOLUME, videoVolume)
                putFloat(StudioContract.EXTRA_MUSIC_VOLUME, musicVolume)
            })

        /** Rotation (sens horaire : 90 / 180 / 270) et/ou miroir horizontal. Le son est conservé. */
        fun transform(rotateClockwiseDeg: Int, flipHorizontal: Boolean = false) =
            StudioCommand(StudioContract.ACTION_TRANSFORM, Bundle().apply {
                putInt(StudioContract.EXTRA_ROTATE_DEG, rotateClockwiseDeg)
                putBoolean(StudioContract.EXTRA_FLIP_H, flipHorizontal)
            })

        /** Vitesse de lecture (0,25 à 4) : image et son suivent. */
        fun speed(factor: Float) = StudioCommand(StudioContract.ACTION_SPEED, Bundle().apply {
            putFloat(StudioContract.EXTRA_SPEED, factor)
        })

        /** Volume d'un audio ou d'une vidéo (1 = inchangé). */
        fun volume(factor: Float) = StudioCommand(StudioContract.ACTION_VOLUME, Bundle().apply {
            putFloat(StudioContract.EXTRA_VOLUME, factor)
        })

        fun mute() = StudioCommand(StudioContract.ACTION_MUTE, Bundle())

        fun audioEffect(preset: StudioAudioPreset) = StudioCommand(
            StudioContract.ACTION_AUDIO_EFFECT, Bundle().apply {
                putString(StudioContract.EXTRA_AUDIO_PRESET, preset.id)
            }
        )

        /** Capture d'une image (JPEG) ; [atMs] est la position de lecture en millisecondes. */
        fun frame(atMs: Long = -1L) = StudioCommand(StudioContract.ACTION_FRAME, Bundle().apply {
            putLong(StudioContract.EXTRA_TIME_MS, atMs)
        })

        /** Compte les images (frames) du flux vidéo et génère un rapport texte. */
        fun countVideoFrames() = StudioCommand(StudioContract.ACTION_FRAME_COUNT, Bundle())

        /** Extrait toutes les images en JPEG dans un dossier du même nom que la vidéo, livré en ZIP. */
        fun extractVideoFrames() = StudioCommand(StudioContract.ACTION_EXTRACT_FRAMES, Bundle())

        /** Reconstruit un MP4 depuis l'archive ZIP créée par Media Studio (images + metadata.txt + audio facultatif). */
        fun rebuildVideoFromFrames() = StudioCommand(StudioContract.ACTION_REBUILD_VIDEO, Bundle())

        /** format : AUTO, JPG, PNG ou WEBP. */
        fun image(format: String = "AUTO", quality: Int = 85, maxSide: Int = 6000) =
            StudioCommand(StudioContract.ACTION_IMAGE, Bundle().apply {
                putString(StudioContract.EXTRA_IMG_FORMAT, format)
                putInt(StudioContract.EXTRA_IMG_QUALITY, quality)
                putInt(StudioContract.EXTRA_IMG_MAX_SIDE, maxSide)
            })

        /** Fichiers attendus : une ou plusieurs images → un seul PDF. */
        fun imagesToPdf() = StudioCommand(StudioContract.ACTION_IMAGES_TO_PDF, Bundle())

        fun wordToPdf() = StudioCommand(StudioContract.ACTION_WORD_TO_PDF, Bundle())
        fun pdfToWord() = StudioCommand(StudioContract.ACTION_PDF_TO_WORD, Bundle())
        fun textToPdf() = StudioCommand(StudioContract.ACTION_TEXT_TO_PDF, Bundle())

        /**
         * Transcription hors ligne (Whisper) d'un audio ou d'une vidéo.
         * @param format "SRT", "TXT" ou "VTT" ; [alsoTxt] enregistre aussi la transcription horodatée .txt.
         */
        fun transcribe(
            language: String = "auto", format: String = "SRT", alsoTxt: Boolean = true,
            translate: Boolean = false, maxChars: Int = 42,
        ) = StudioCommand(StudioContract.ACTION_TRANSCRIBE, Bundle().apply {
            putString(StudioContract.EXTRA_LANGUAGE, language)
            putString(StudioContract.EXTRA_SUB_FORMAT, format)
            putBoolean(StudioContract.EXTRA_ALSO_TXT, alsoTxt)
            putBoolean(StudioContract.EXTRA_TRANSLATE, translate)
            putInt(StudioContract.EXTRA_MAX_CHARS, maxChars)
        })

        /** Ouvre le studio sous-titres plein écran (vidéo, + .srt facultatif) ; renvoie la vidéo sous-titrée ou le SRT. */
        fun subtitleStudio() = StudioCommand(StudioContract.ACTION_SUBTITLE_STUDIO, Bundle())

        /** Fichiers attendus : une vidéo et un .srt (ou .vtt). */
        fun burnSubtitles(style: StudioSubStyle = StudioSubStyle.CLASSIC, size: String = "M", position: String = "BOTTOM") =
            StudioCommand(StudioContract.ACTION_BURN_SUBTITLES, Bundle().apply {
                putString(StudioContract.EXTRA_SUB_STYLE, style.id)
                putString(StudioContract.EXTRA_SUB_SIZE, size)
                putString(StudioContract.EXTRA_SUB_POSITION, position)
            })

        /** Installe un modèle Whisper ggml-*.bin (reçu d'un autre téléphone) dans Media Studio. */
        fun importWhisperModel() = StudioCommand(StudioContract.ACTION_IMPORT_WHISPER_MODEL, Bundle())

        /** Fichiers attendus : au moins deux vidéos, assemblées dans l'ordre fourni. */
        fun concat(fade: Boolean = false) = StudioCommand(StudioContract.ACTION_CONCAT, Bundle().apply {
            putBoolean(StudioContract.EXTRA_FADE, fade)
        })
    }
}

/** Résultat du lancement (le résultat du traitement arrive plus tard, via l'Activity Result API). */
sealed interface StudioLaunch {
    data object Launched : StudioLaunch
    data object NotInstalled : StudioLaunch
    data class Failed(val reason: String) : StudioLaunch
}

/** Routeur centralisé côté LinkShare : toutes les actions MediaStudio passent par [dispatch]. */
object MediaStudioRouter {

    /** Premier identifiant de [StudioContract.PACKAGES] réellement installé, ou null. */
    fun installedPackage(ctx: Context): String? = StudioContract.PACKAGES.firstOrNull { pkg ->
        try { ctx.packageManager.getPackageInfo(pkg, 0); true } catch (_: PackageManager.NameNotFoundException) { false }
    }

    fun isInstalled(ctx: Context): Boolean = installedPackage(ctx) != null

    /**
     * Intent EXPLICITE (composant ciblé, jamais de résolution implicite) + lecture accordée uniquement aux fichiers choisis.
     * Pas de FLAG_ACTIVITY_NEW_TASK : MediaStudio se superpose à LinkShare dans la même tâche, et sa fermeture
     * redonne directement la main à LinkShare.
     */
    fun buildIntent(ctx: Context, pkg: String, cmd: StudioCommand, files: List<File>): Intent {
        val authority = "${ctx.packageName}.files"
        val uris = files.map { FileProvider.getUriForFile(ctx, authority, it) }
        val clip = ClipData.newRawUri("MediaStudio", uris[0]).also { c -> uris.drop(1).forEach { c.addItem(ClipData.Item(it)) } }
        return Intent(cmd.action)
            .setComponent(ComponentName(pkg, StudioContract.ROUTER_CLASS))
            .setDataAndType(uris[0], mimeOf(files[0]))
            .also { it.clipData = clip }              // tous les fichiers (data = le premier)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) // lecture seule : MediaStudio n'écrit jamais dans la source
            .let(cmd::applyTo)
    }

    /**
     * @param launch lance l'Intent avec startActivityForResult (voir rememberLauncherForActivityResult) :
     * indispensable pour que MediaStudio puisse identifier l'appelant et renvoyer le fichier produit.
     */
    fun dispatch(ctx: Context, launch: (Intent) -> Unit, cmd: StudioCommand, files: List<File>): StudioLaunch {
        if (!Bridges.on(Bridge.STUDIO)) return StudioLaunch.Failed(Bridges.DISABLED_MSG)
        if (files.isEmpty()) return StudioLaunch.Failed("Aucun fichier sélectionné")
        if (files.any { !it.isFile || !it.canRead() }) return StudioLaunch.Failed("Fichier introuvable ou illisible")
        if (files.size > StudioContract.MAX_FILES)
            return StudioLaunch.Failed("Sélectionnez au maximum ${StudioContract.MAX_FILES} fichiers à la fois")
        val pkg = installedPackage(ctx) ?: return StudioLaunch.NotInstalled
        return try {
            launch(buildIntent(ctx, pkg, cmd, files))
            StudioLaunch.Launched
        } catch (_: ActivityNotFoundException) {
            StudioLaunch.Failed("Media Studio est installé mais trop ancien : mettez-le à jour")
        } catch (e: SecurityException) {
            StudioLaunch.Failed("Accès refusé par Media Studio")
        } catch (e: IllegalArgumentException) { // FileProvider : fichier hors des chemins déclarés
            StudioLaunch.Failed("Ce fichier ne peut pas être partagé")
        }
    }

    fun mimeOf(f: File): String =
        MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
}

/** « Modifier avec… » : images, vidéos et audios, avec l'éditeur de l'utilisateur (indépendant de MediaStudio). */
object ExternalEditor {

    /** @return null si tout va bien, sinon le message à afficher. */
    fun edit(ctx: Context, file: File): String? {
        if (!Bridges.on(Bridge.EDITOR)) return Bridges.DISABLED_MSG
        if (!file.isFile || !file.canRead()) return "Fichier introuvable ou illisible"
        return try {
            val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", file)
            val mime = MediaStudioRouter.mimeOf(file)
            // L'éditeur doit pouvoir enregistrer sur place : lecture ET écriture, limitées à ce seul fichier
            val grants = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            val edit = Intent(Intent.ACTION_EDIT).setDataAndType(uri, mime).addFlags(grants)
                .also { it.clipData = ClipData.newRawUri("", uri) }
            val hasEditor = ctx.packageManager.queryIntentActivities(edit, PackageManager.MATCH_DEFAULT_ONLY)
                .any { it.activityInfo.packageName != ctx.packageName }
            val target = if (hasEditor) edit
            else Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                .also { it.clipData = ClipData.newRawUri("", uri) } // aucun éditeur : on propose au moins d'ouvrir
            val chooser = Intent.createChooser(target, "Modifier avec")
                .putExtra(Intent.EXTRA_EXCLUDE_COMPONENTS, arrayOf(ComponentName(ctx.packageName, "${ctx.packageName}.MainActivity")))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(chooser)
            if (hasEditor) null else "Aucun éditeur installé pour ce type de fichier : ouverture en lecture"
        } catch (_: ActivityNotFoundException) {
            "Aucune application pour modifier ce fichier"
        } catch (e: IllegalArgumentException) {
            "Ce fichier ne peut pas être partagé"
        }
    }
}
