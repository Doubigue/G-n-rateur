package com.linkshare.ui

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import com.linkshare.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * « Ouvrir avec » de LinkShare : LinkShare proposée en premier (quand elle sait afficher le fichier),
 * puis les autres applications, avec les boutons « Une seule fois » et « Toujours ».
 * « Toujours » est retenu par type de fichier (extension) : un appui sur le fichier dans l'explorateur
 * l'ouvre alors directement avec l'appli choisie.
 */
object OpenWith {
    /** Valeur enregistrée quand LinkShare est l'appli par défaut. */
    const val SELF = "self"

    class Request(val file: File, val mime: String, val onSelf: (() -> Unit)?)

    var request by mutableStateOf<Request?>(null)

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("linkshare_open_with", Context.MODE_PRIVATE)

    fun keyOf(f: File): String = f.extension.lowercase().ifEmpty { "noext" }

    fun mimeOf(f: File): String =
        MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"

    /** Appli par défaut retenue pour ce type : [SELF], « paquet/classe », ou null. */
    fun defaultFor(ctx: Context, f: File): String? = prefs(ctx).getString(keyOf(f), null)

    fun setDefault(ctx: Context, f: File, value: String?) {
        prefs(ctx).edit().apply { if (value == null) remove(keyOf(f)) else putString(keyOf(f), value) }.apply()
    }

    fun clearAll(ctx: Context) = prefs(ctx).edit().clear().apply()

    fun viewIntent(ctx: Context, f: File, mime: String): Intent {
        val uri: Uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
        return Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    /** Lance l'appli enregistrée « paquet/classe » ; faux si elle a été désinstallée (le choix est alors oublié). */
    fun launchSaved(ctx: Context, f: File, saved: String): Boolean {
        val cn = ComponentName.unflattenFromString(saved) ?: return false
        return try {
            ctx.startActivity(viewIntent(ctx, f, mimeOf(f)).setComponent(cn))
            true
        } catch (e: Exception) {
            setDefault(ctx, f, null)
            false
        }
    }
}

private class AppChoice(val id: String, val label: String, val icon: ImageBitmap?, val component: ComponentName?)

/** À placer une seule fois, au-dessus de tous les écrans (explorateur, lecteurs, fichiers reçus). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OpenWithHost() {
    val req = OpenWith.request ?: return
    val ctx = LocalContext.current
    val f = req.file
    val saved = remember(req) { OpenWith.defaultFor(ctx, f) }

    val apps by produceState<List<AppChoice>?>(null, req) {
        value = withContext(Dispatchers.IO) {
            val pm = ctx.packageManager
            val probe = OpenWith.viewIntent(ctx, f, req.mime)
            pm.queryIntentActivities(probe, PackageManager.MATCH_DEFAULT_ONLY)
                .filter { it.activityInfo.packageName != ctx.packageName }
                .map { ri ->
                    val cn = ComponentName(ri.activityInfo.packageName, ri.activityInfo.name)
                    AppChoice(
                        cn.flattenToString(),
                        ri.loadLabel(pm).toString(),
                        runCatching { ri.loadIcon(pm).toBitmap(96, 96).asImageBitmap() }.getOrNull(),
                        cn,
                    )
                }
                .distinctBy { it.id }
                .sortedBy { it.label.lowercase() }
        }
    }

    // LinkShare d'abord, présélectionnée ; sinon l'appli déjà retenue, sinon la première
    var picked by remember(req) {
        mutableStateOf(if (req.onSelf != null) OpenWith.SELF else saved)
    }
    LaunchedEffect(apps) {
        if (picked == null) picked = apps?.firstOrNull { it.id == saved }?.id ?: apps?.firstOrNull()?.id
    }

    fun close() { OpenWith.request = null }

    fun launch(always: Boolean) {
        val id = picked ?: return
        if (always) OpenWith.setDefault(ctx, f, id)
        close()
        if (id == OpenWith.SELF) { req.onSelf?.invoke(); return }
        val cn = ComponentName.unflattenFromString(id) ?: return
        try {
            ctx.startActivity(OpenWith.viewIntent(ctx, f, req.mime).setComponent(cn))
        } catch (e: Exception) {
            android.widget.Toast.makeText(ctx, "Impossible d'ouvrir avec cette appli", android.widget.Toast.LENGTH_LONG).show()
        }
    }

    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(onDismissRequest = { close() }, sheetState = state, containerColor = LS.Sheet, contentColor = LS.Text) {
        Column(
            Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp).padding(bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text("Ouvrir avec", color = LS.Text, fontSize = 20.sp, fontWeight = FontWeight.Medium)
            Text(f.name, color = LS.Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)

            val list = buildList {
                if (req.onSelf != null) add(AppChoice(OpenWith.SELF, "LinkShare", null, null))
                addAll(apps.orEmpty())
            }
            when {
                apps == null && req.onSelf == null ->
                    Box(Modifier.fillMaxWidth().height(120.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = LS.Blue) }
                list.isEmpty() ->
                    Text("Aucune application pour ouvrir ce fichier", color = LS.Muted, fontSize = 14.sp)
                else -> LazyVerticalGrid(
                    GridCells.Fixed(4),
                    Modifier.fillMaxWidth().heightIn(max = 340.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    items(list, key = { it.id }) { app ->
                        AppTile(
                            app, selected = picked == app.id, isDefault = saved == app.id,
                            onClick = {
                                // Deuxième appui sur l'appli déjà choisie : ouverture une seule fois (comme Android)
                                if (picked == app.id) launch(always = false) else picked = app.id
                            },
                        )
                    }
                }
            }

            if (saved != null) {
                val name = if (saved == OpenWith.SELF) "LinkShare" else apps?.firstOrNull { it.id == saved }?.label
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Par défaut pour .${OpenWith.keyOf(f)} : ${name ?: "…"}",
                        Modifier.weight(1f), color = LS.Muted, fontSize = 12.sp,
                    )
                    TextButton({ OpenWith.setDefault(ctx, f, null); close() }) { Text("Réinitialiser", color = LS.Blue) }
                }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    { launch(always = false) }, Modifier.weight(1f), enabled = picked != null,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = LS.Blue),
                ) { Text("Une seule fois") }
                Button(
                    { launch(always = true) }, Modifier.weight(1f), enabled = picked != null,
                    colors = ButtonDefaults.buttonColors(containerColor = LS.Blue, contentColor = LS.OnBlue),
                ) { Text("Toujours") }
            }
        }
    }
}

@Composable
private fun AppTile(app: AppChoice, selected: Boolean, isDefault: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Column(
        Modifier.fillMaxWidth().clip(shape)
            .background(if (selected) LS.BlueLight else androidx.compose.ui.graphics.Color.Transparent)
            .then(if (selected) Modifier.border(1.5.dp, LS.Blue, shape) else Modifier)
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        val iconMod = Modifier.size(44.dp).clip(RoundedCornerShape(12.dp))
        when {
            app.id == OpenWith.SELF -> Image(painterResource(R.drawable.ic_logo), "LinkShare", iconMod)
            app.icon != null -> Image(app.icon, app.label, iconMod)
            else -> Box(iconMod.background(LS.Card2))
        }
        Spacer(Modifier.height(6.dp))
        Text(
            app.label, color = LS.Text, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center, lineHeight = 13.sp,
        )
        if (app.id == OpenWith.SELF || isDefault) Text(
            if (isDefault) "Par défaut" else "Recommandé",
            color = LS.Blue, fontSize = 9.sp, fontWeight = FontWeight.Medium,
        )
    }
}
