import java.net.HttpURLConnection
import java.net.URI

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
// ── Whisper : modèle embarqué dans l'APK ─────────────────────────────────────────────────────────
// Le modèle est récupéré UNE fois au moment de la compilation (CI ou PC), puis tout fonctionne hors ligne
// sur le téléphone. Choix : -Pwhisper.model=base-q5_1 (défaut) | small-q5_1 | tiny | base | none.
// Pour compiler sans Internet : déposez ggml-<modèle>.bin dans le dossier whisper-models/ à la racine.
val whisperModel: String = providers.gradleProperty("whisper.model").orNull?.trim() ?: "base-q5_1"
val whisperAssetsDir = layout.buildDirectory.dir("generated/whisperAssets")
val fetchWhisperModel by tasks.registering {
    val modelName = whisperModel
    val outDir = whisperAssetsDir
    val localDir = rootProject.layout.projectDirectory.dir("whisper-models")
    inputs.property("whisperModel", modelName)
    outputs.dir(outDir)
    doLast {
        val dir = outDir.get().asFile.resolve("whisper")
        dir.mkdirs()
        if (modelName.isEmpty() || modelName == "none") {
            dir.listFiles()?.forEach { it.delete() }
            logger.lifecycle("Whisper : aucun modèle embarqué (import depuis le téléphone).")
            return@doLast
        }
        val fileName = "ggml-$modelName.bin"
        dir.listFiles()?.filter { it.name != fileName }?.forEach { it.delete() }
        val target = dir.resolve(fileName)
        if (target.length() > 10_000_000) return@doLast
        val local = localDir.file(fileName).asFile
        if (local.isFile) { local.copyTo(target, overwrite = true); return@doLast }
        val url = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/$fileName"
        logger.lifecycle("Whisper : téléchargement de $fileName …")
        val tmp = dir.resolve("$fileName.part")
        try {
            var conn = URI(url).toURL().openConnection() as HttpURLConnection
            var hops = 0
            while (conn.responseCode in 300..399 && hops++ < 5) {
                val next = URI(url).resolve(conn.getHeaderField("Location")).toURL()
                conn.disconnect()
                conn = next.openConnection() as HttpURLConnection
            }
            if (conn.responseCode != 200) error("HTTP ${conn.responseCode}")
            conn.inputStream.use { input -> tmp.outputStream().use { input.copyTo(it, 1 shl 20) } }
            if (tmp.length() < 10_000_000) error("fichier incomplet")
            tmp.renameTo(target)
            logger.lifecycle("Whisper : $fileName embarqué (${target.length() / 1_000_000} Mo).")
        } catch (e: Exception) {
            tmp.delete()
            logger.warn("Whisper : modèle non téléchargé ($e). L'APK sera compilé sans modèle : importez-le depuis le téléphone.")
        }
    }
}

android {
    namespace = "com.mediastudio.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.mediastudio.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "1.1"
        // Whisper (whisper.cpp) : bibliothèque native pour les téléphones ARM 64 et 32 bits
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
        externalNativeBuild {
            cmake {
                arguments += listOf("-DANDROID_STL=c++_static", "-DCMAKE_BUILD_TYPE=Release")
            }
        }
    }
    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }
    sourceSets {
        getByName("main") { assets.srcDir(whisperAssetsDir) }
    }
    // Le modèle reste non compressé dans l'APK : lecture directe, sans copie sur le téléphone
    androidResources { noCompress += listOf("bin") }

    signingConfigs {
        create("release") {
            storeFile = rootProject.file("keystore/mediastudio-release.jks")
            storePassword = providers.environmentVariable("MEDIA_STUDIO_STORE_PASSWORD").orNull ?: ""
            keyAlias = "mediastudio-release"
            keyPassword = providers.environmentVariable("MEDIA_STUDIO_KEY_PASSWORD").orNull
                ?: providers.environmentVariable("MEDIA_STUDIO_STORE_PASSWORD").orNull
                ?: ""
        }
    }
    buildTypes {
        getByName("release") {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = false
        }
    }
    buildFeatures { compose = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    packaging { resources { excludes += setOf("META-INF/DEPENDENCIES", "META-INF/LICENSE*", "META-INF/NOTICE*", "META-INF/*.kotlin_module") } }
}
// TAndroidLame (2015) embarque l'ancienne support-library : doublons avec AndroidX -> exclue.
configurations.configureEach { exclude(group = "com.android.support") }

dependencies {
    val media3 = "1.5.1"
    implementation("androidx.media3:media3-transformer:$media3")
    implementation("androidx.media3:media3-effect:$media3")
    implementation("androidx.media3:media3-common:$media3")
    implementation("androidx.media3:media3-exoplayer:$media3")
    implementation("androidx.media3:media3-ui:$media3")
    implementation("com.github.naman14:TAndroidLame:1.1") // LAME (MP3 encoder)
    implementation("com.tom-roush:pdfbox-android:2.0.27.0") // PDF -> Word (extraction du texte)
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
}

tasks.named("preBuild") { dependsOn(fetchWhisperModel) }
