package com.linguavibe.app.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linguavibe.app.data.CourseRepository
import com.linguavibe.app.data.LanguageInfo
import com.linguavibe.app.data.Languages
import com.linguavibe.app.data.Lesson
import com.linguavibe.app.data.Levels
import com.linguavibe.app.data.ProgressStore
import com.linguavibe.app.speech.Speaker
import com.linguavibe.app.speech.VoskManager
import kotlinx.coroutines.launch

sealed class Screen {
    object Home : Screen()
    data class OpenCourse(val lang: String, val modelId: String = "model1") : Screen()
    data class OpenAlphabet(val lang: String) : Screen()
    data class OpenLesson(val lang: String, val lessonId: String, val modelId: String = "model1") : Screen()
    object SpanishModels : Screen()
    object Lexique : Screen()
    object Models : Screen()
    object Teachers : Screen()
    object Settings : Screen()
    object Firebase : Screen()
}

@Composable
fun AppRoot(speaker: Speaker, progress: ProgressStore) {
    val stack = remember { mutableStateListOf<Screen>(Screen.Home) }
    val push: (Screen) -> Unit = { stack.add(it) }
    val pop: () -> Unit = { if (stack.size > 1) stack.removeAt(stack.lastIndex) }
    val openModels: () -> Unit = { if (stack.last() != Screen.Models) stack.add(Screen.Models) }

    BackHandler(enabled = stack.size > 1) { pop() }

    CompositionLocalProvider(LocalSpeaker provides speaker, LocalOpenModels provides openModels) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            AnimatedContent(
                targetState = stack.last(),
                transitionSpec = {
                    (fadeIn(tween(280)) + slideInHorizontally(tween(280)) { it / 8 }) togetherWith fadeOut(tween(180))
                },
                label = "navigation"
            ) { screen ->
                when (screen) {
                    is Screen.Home -> HomeScreen(
                        progress, { code ->
                            if (code == "es") push(Screen.SpanishModels) else push(Screen.OpenCourse(code, "model1"))
                        }, openModels, { push(Screen.Firebase) },
                        { push(Screen.Settings) }, { push(Screen.Teachers) }
                    )
                    is Screen.SpanishModels -> SpanishModelsScreen(
                        onModel1 = { push(Screen.OpenCourse("es", "model1")) },
                        onModel2 = { push(Screen.OpenCourse("es", "model2")) },
                        onModel3 = { push(Screen.OpenCourse("es", "model3")) },
                        onLexique = { push(Screen.Lexique) },
                        onBack = pop
                    )
                    is Screen.Lexique -> LexiqueScreen(pop)
                    is Screen.OpenCourse -> CourseScreen(
                        Languages.byCode(screen.lang), progress, pop,
                        modelId = screen.modelId,
                        onOpenAlphabet = { push(Screen.OpenAlphabet(screen.lang)) }
                    ) { push(Screen.OpenLesson(screen.lang, it, screen.modelId)) }
                    is Screen.OpenAlphabet -> AlphabetScreen(Languages.byCode(screen.lang), pop)
                    is Screen.OpenLesson -> LessonScreen(Languages.byCode(screen.lang), screen.lessonId, progress, pop, screen.modelId)
                    is Screen.Models -> ModelsScreen(pop)
                    is Screen.Teachers -> TeachersScreen(pop)
                    is Screen.Settings -> SettingsScreen(pop)
                    is Screen.Firebase -> FirebaseScreen(pop)
                }
            }
        }
    }
}

// ------------------------------------------------------------ Éléments communs

@Composable
fun TopBar(
    title: String, subtitle: String?, color: Color, onBack: () -> Unit, theme: PosterTheme? = null,
    action: (@Composable () -> Unit)? = null
) {
    val t = theme ?: PosterTheme(color, Night, Gold)
    Row(
        Modifier
            .fillMaxWidth()
            .background(Brush.linearGradient(listOf(t.start, t.end)))
            .waxPattern(alpha = 0.07f)
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BackArrow(Color.White, onBack)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                title, color = Color.White, style = PosterTitle, fontSize = 21.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            if (subtitle != null) Text(subtitle, color = t.accent, style = AccentText, fontSize = 14.sp, maxLines = 1)
        }
        if (action != null) {
            Spacer(Modifier.width(8.dp))
            action()
        }
    }
}

@Composable
fun CardBox(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Column(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Color.White)
            .border(1.dp, Sand, shape)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        content = content
    )
}

/** Titre de section style affiche : trait doré, grand titre, indication en italique. */
@Composable
fun SectionTitle(title: String, hint: String? = null, icon: LineDrawing? = null) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (icon != null) {
            Box(
                Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(Night),
                contentAlignment = Alignment.Center
            ) { LineIcon(icon, Color.White, 26.dp, accent = Gold) }
            Spacer(Modifier.width(12.dp))
        } else {
            Box(Modifier.width(5.dp).height(34.dp).clip(RoundedCornerShape(50)).background(Gold))
            Spacer(Modifier.width(10.dp))
        }
        Column {
            Text(title, style = PosterTitle, fontSize = 21.sp, color = Ink)
            if (hint != null) Text(hint, style = AccentText, fontSize = 13.sp, color = InkSoft, lineHeight = 17.sp)
        }
    }
}

@Composable
fun Chip(text: String, color: Color) {
    Text(
        text, color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.13f))
            .padding(horizontal = 12.dp, vertical = 5.dp)
    )
}

// --------------------------------------------------------------------- Accueil

@Composable
fun HomeScreen(
    progress: ProgressStore,
    onOpenCourse: (String) -> Unit,
    onOpenModels: () -> Unit,
    onOpenFirebase: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenTeachers: () -> Unit
) {
    val context = LocalContext.current
    val version = VoskManager.installsVersion
    var grid by rememberGridMode("languages")
    LazyVerticalGrid(
        columns = GridCells.Fixed(if (grid) 2 else 1),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(GridGap),
        verticalArrangement = Arrangement.spacedBy(GridGap)
    ) {
        item(key = "hero", span = { GridItemSpan(maxLineSpan) }) { HomeHero(progress) }
        item(key = "title", span = { GridItemSpan(maxLineSpan) }) {
            Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Choisissez une langue", style = PosterTitle, fontSize = 22.sp, color = Ink)
                    Text("Six langues, du niveau A1 au C2", style = AccentText, fontSize = 14.sp, color = InkSoft)
                }
                ViewToggle(grid, { grid = it })
            }
        }
        itemsIndexed(Languages.courses, key = { _, l -> l.code }) { index, lang ->
            val installed = remember(version, lang.code) { VoskManager.isInstalled(context, lang.code) }
            val course = remember(lang.code, CourseRepository.version) { CourseRepository.load(context, lang.code) }
            val done = course.lessons.count { progress.isCompleted(it.id) }
            StaggerIn(index) {
                LanguageCard(lang, installed, course.lessons.size, done, grid, index) {
                    if (lang.available) onOpenCourse(lang.code)
                }
            }
        }
        item(key = "teachers", span = { GridItemSpan(maxLineSpan) }) {
            ActionTile(
                "Mes professeurs", "Des enseignants animés pour pratiquer chaque langue", Art.icVoice,
                PosterTheme(Navy, Color(0xFF304AA0), GoldSoft), Modifier.fillMaxWidth()
            ) { onOpenTeachers() }
        }
        item(key = "tools-title", span = { GridItemSpan(maxLineSpan) }) {
            Text("Outils", style = PosterTitle, fontSize = 20.sp, color = Ink, modifier = Modifier.padding(top = 10.dp))
        }
        item(key = "tools", span = { GridItemSpan(maxLineSpan) }) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionTile(
                    "Micro", "Modèles Vosk hors ligne", Art.icMic,
                    PosterTheme(Navy, Night, Gold), Modifier.weight(1f), onOpenModels
                )
                ActionTile(
                    "Voix", "Paramètres et voix réalistes", Art.icVoice,
                    PosterTheme(Ruby, Color(0xFF8E1B1B), GoldSoft), Modifier.weight(1f), onOpenSettings
                )
                ActionTile(
                    "Cloud", "Données Firebase", Art.icCloud,
                    PosterTheme(Forest, Color(0xFF06331F), Color(0xFFE8F25C)), Modifier.weight(1f), onOpenFirebase
                )
            }
        }
        item(key = "footer", span = { GridItemSpan(maxLineSpan) }) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                if (com.linguavibe.app.data.FirebaseSync.busy) {
                    Text("Mise à jour des cours…", fontSize = 13.sp, color = InkSoft)
                }
                Text(
                    "La correction de la prononciation fonctionne hors ligne grâce à un modèle vocal par langue.",
                    fontSize = 12.sp, color = InkSoft
                )
            }
        }
    }
}

@Composable
private fun HomeHero(progress: ProgressStore) {
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(30.dp))
            .background(Brush.linearGradient(listOf(Navy, Night)))
            .waxPattern(color = Gold, alpha = 0.10f)
            .padding(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("LinguaVibe", style = PosterTitle, fontSize = 34.sp, color = Color.White)
                Text("Parlez une nouvelle langue, leçon après leçon", style = AccentText, fontSize = 15.sp, color = GoldSoft)
                Spacer(Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill("Série ${progress.streak} j")
                    Pill("${progress.xp} XP", bg = Color.White.copy(alpha = 0.14f), fg = Color.White)
                }
            }
            LineArt(Art.hero, Modifier.size(118.dp), color = Color.White, accent = Gold, strokeWidth = 2.dp)
        }
    }
}

@Composable
private fun LanguageCard(
    lang: LanguageInfo, modelInstalled: Boolean, total: Int, done: Int, grid: Boolean, index: Int, onClick: () -> Unit
) {
    val theme = posterTheme(lang.code)
    PosterCard(
        theme, Art.landmark(lang.code), grid, enabled = lang.available, seed = index,
        badge = { if (done > 0 && done == total) Pill("Terminé") },
        onClick = onClick
    ) {
        Text(lang.name, style = PosterTitle, fontSize = if (grid) 21.sp else 23.sp, color = Color.White, maxLines = 1)
        Text(lang.nativeName, style = AccentText, fontSize = 15.sp, color = theme.accent, maxLines = 1)
        if (lang.available) {
            PosterBar(if (total == 0) 0f else done.toFloat() / total, theme.accent, Modifier.padding(top = 4.dp))
            Text("$done / $total leçons", fontSize = 12.sp, color = Color.White.copy(alpha = 0.85f))
        } else {
            Text("Bientôt disponible", fontSize = 12.sp, color = Color.White.copy(alpha = 0.85f))
        }
        Pill(
            if (modelInstalled) "Micro prêt" else "Micro à installer",
            bg = if (modelInstalled) theme.accent else Color.White.copy(alpha = 0.16f),
            fg = if (modelInstalled) theme.onAccent else Color.White
        )
    }
}

// ---------------------------------------------------------- Choix des modèles espagnols

@Composable
private fun ModelTile(
    chip: String, title: String, description: String, stats: String, button: String,
    color: Color, modifier: Modifier, onClick: () -> Unit
) {
    CardBox(modifier.clickable(onClick = onClick)) {
        Chip(chip, color)
        Text(title, style = PosterTitle, fontSize = 21.sp, lineHeight = 24.sp, color = Ink)
        Text(description, color = InkSoft, fontSize = 12.5.sp, lineHeight = 17.sp)
        Spacer(Modifier.weight(1f))
        Text(stats, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Ink)
        PillButton(button, Art.icPlay, color, Modifier.fillMaxWidth(), onClick = onClick)
    }
}

@Composable
fun SpanishModelsScreen(onModel1: () -> Unit, onModel2: () -> Unit, onModel3: () -> Unit, onLexique: () -> Unit, onBack: () -> Unit) {
    val brown = Color(0xFF9A5B2A)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopBar("Espagnol", "Choisissez votre parcours", posterTheme("es").start, onBack, posterTheme("es"))
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(GridGap)) {
            Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(GridGap)) {
                ModelTile(
                    "EXISTANT", "MODEL 1",
                    "Les cours d'espagnol déjà présents, avec leur progression et leurs activités.",
                    "36 leçons · A1 à C2", "Ouvrir", Forest, Modifier.weight(1f).fillMaxHeight(), onModel1
                )
                ModelTile(
                    "NOUVEAU", "MODEL 2",
                    "Le guide PDF en 16 chapitres : explications, vocabulaire, dialogues, quiz et devoirs.",
                    "16 leçons · A1 à C1", "Ouvrir", IndigoDark, Modifier.weight(1f).fillMaxHeight(), onModel2
                )
            }
            Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(GridGap)) {
                ModelTile(
                    "NOUVEAU", "MODEL 3",
                    "Le manuel approfondi : salutations, famille, conseils, nombres, grammaire et exercices.",
                    "4 unités · manuel PDF", "Ouvrir", brown, Modifier.weight(1f).fillMaxHeight(), onModel3
                )
                ModelTile(
                    "LEXIQUE", "10 000 mots",
                    "Cartes avec écoute, mots appris, quiz chronométré, tableau de bord et rappels.",
                    "espagnol → français", "Ouvrir", Forest, Modifier.weight(1f).fillMaxHeight(), onLexique
                )
            }
            CardBox {
                Text("Progressions indépendantes", style = PosterTitle, color = Ink)
                Text("Les scores et les devoirs de chaque modèle sont indépendants. Les parcours 1, 2 et 3 conservent leur propre progression.", color = InkSoft)
            }
        }
    }
}

// ----------------------------------------------------------------------- Cours

@Composable
fun CourseScreen(
    lang: LanguageInfo, progress: ProgressStore, onBack: () -> Unit,
    modelId: String = "model1",
    onOpenAlphabet: () -> Unit, onOpenLesson: (String) -> Unit
) {
    val context = LocalContext.current
    val course = remember(lang.code, modelId, CourseRepository.version) { CourseRepository.load(context, lang.code, modelId) }
    val progressScope = if (lang.code == "es") "es_$modelId" else "default"
    val done = course.lessons.count { progress.isCompleted(it.id, progressScope) }
    val theme = posterTheme(lang.code)
    var grid by rememberGridMode("lessons")
    val gridState = rememberLazyGridState()
    val scope = rememberCoroutineScope()
    val levels = Levels.order.filter { level -> course.lessons.any { it.level == level } }
    // Position de chaque en-tête de chapitre dans la grille (pour y sauter).
    val headerIndex = remember(course, levels) {
        val map = HashMap<String, Int>()
        var i = 3
        levels.forEach { l ->
            map[l] = i
            val count = course.lessons.count { it.level == l }
            i += if (modelId == "model2" || modelId == "model3") 2 + count else 1 + count
        }
        map
    }
    val exportPdf = rememberPdfExporter()
    val modelLabel = if (lang.code == "es") when (modelId) { "model2" -> "MODEL 2"; "model3" -> "MODEL 3"; else -> "MODEL 1" } else ""
    Column(Modifier.fillMaxSize()) {
        TopBar(
            if (lang.code == "es") "Espagnol · $modelLabel" else lang.name,
            "${lang.nativeName} · $done / ${course.lessons.size} leçons validées", theme.start, onBack, theme,
            action = if (course.lessons.isEmpty()) null else ({
                PdfTopButton {
                    exportPdf("LinguaVibe_${lang.name}${if (modelLabel.isBlank()) "" else "_" + modelLabel.replace(" ", "")}_cours.pdf") { out ->
                        com.linguavibe.app.export.PdfExporter.exportCourse(context, lang, modelLabel, course.lessons, out)
                    }
                }
            })
        )
        LazyVerticalGrid(
            columns = GridCells.Fixed(if (grid) 2 else 1),
            state = gridState,
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(GridGap),
            verticalArrangement = Arrangement.spacedBy(GridGap)
        ) {
            item(key = "intro", span = { GridItemSpan(maxLineSpan) }) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(if (modelId == "model1") "Votre parcours" else "Programme du cours", style = PosterTitle, fontSize = 22.sp, color = Ink)
                            Text(if (modelId == "model1") "Tous les niveaux sont accessibles sans prérequis" else "Choisissez une leçon pour étudier son cours, ses exemples et ses activités.", style = AccentText, fontSize = 14.sp, color = InkSoft)
                        }
                        ViewToggle(grid, { grid = it })
                    }
                    Text("Chapitres", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = InkSoft)
                }
            }
            if (modelId == "model1") item(key = "alphabet", span = { GridItemSpan(maxLineSpan) }) {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
                        .background(Brush.linearGradient(listOf(Color(0xFF5145A8), Color(0xFFDB6D91))))
                        .clickable { onOpenAlphabet() }.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("🔤 APPRENDRE L'ALPHABET", color = Color(0xFFFFE6A8), fontSize = 11.sp, fontWeight = FontWeight.ExtraBold)
                        Text("Lettres, sons et mots illustrés", color = Color.White, style = PosterTitle, fontSize = 18.sp)
                        Text("Écoute chaque lettre et joue au mini-défi", color = Color.White.copy(alpha = .86f), fontSize = 12.sp)
                    }
                    Text("🦊", fontSize = 42.sp)
                }
            }
            item(key = "chapters", span = { GridItemSpan(maxLineSpan) }) {
                ChapterStrip(levels, course.lessons, progress, grid, progressScope) { level ->
                    headerIndex[level]?.let { scope.launch { gridState.animateScrollToItem(it) } }
                }
            }
            levels.forEach { level ->
                val lessons = course.lessons.filter { it.level == level }
                item(key = "level-$level", span = { GridItemSpan(maxLineSpan) }) {
                    LevelHeader(level, lessons.count { progress.isCompleted(it.id, progressScope) }, lessons.size)
                }
                if (lessons.isEmpty()) {
                    item(key = "empty-$level", span = { GridItemSpan(maxLineSpan) }) {
                        CardBox {
                            Text("$level · Niveau débloqué", fontWeight = FontWeight.Bold, color = Ink)
                            Text("Ce niveau est accessible. Les chapitres correspondants ne figurent pas dans ce manuel.", color = InkSoft, fontSize = 13.sp)
                        }
                    }
                } else {
                    itemsIndexed(lessons, key = { _, l -> l.id }) { i, lesson ->
                        LessonCard(lesson, progress.bestScore(lesson.id, progressScope), progress.isCompleted(lesson.id, progressScope), grid, i) {
                            onOpenLesson(lesson.id)
                        }
                    }
                }
            }
            if (modelId == "model1") item(key = "future-lessons-heading", span = { GridItemSpan(maxLineSpan) }) {
                Column(Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 4.dp)) {
                    Text("À VENIR", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp, color = InkSoft)
                    Text("Les prochaines leçons", style = PosterTitle, fontSize = 22.sp, color = Ink)
                    Text("Ces thèmes seront bientôt disponibles.", fontSize = 13.sp, color = InkSoft)
                }
            }
            if (modelId == "model1") itemsIndexed(futureLessons, key = { _, item -> "future-${item.number}" }) { index, item ->
                FutureLessonCard(item, grid, index)
            }
        }
    }
}

private data class FutureLesson(val number: Int, val emoji: String, val title: String)

private val futureLessons = listOf(
    FutureLesson(40, "🐄", "La ferme et les animaux d'élevage"),
    FutureLesson(41, "👕", "Les vêtements, les chaussures et les accessoires"),
    FutureLesson(42, "🚆", "Les transports et les moyens de déplacement"),
    FutureLesson(43, "🍳", "La cuisine et les ustensiles"),
    FutureLesson(44, "🍎", "Les fruits, les légumes et les aliments"),
    FutureLesson(45, "👨‍⚕️", "Les métiers et les professions"),
    FutureLesson(46, "🎓", "L'école et les études"),
    FutureLesson(47, "🧍", "Le corps humain et les cinq sens"),
    FutureLesson(48, "😊", "Les émotions et les traits de caractère"),
    FutureLesson(49, "⚽", "Les loisirs, les sports et les jeux"),
    FutureLesson(50, "🌍", "La nature, les paysages et l'environnement"),
    FutureLesson(51, "🌦️", "Les saisons et les phénomènes naturels"),
    FutureLesson(52, "🛠️", "Les outils, les appareils et les objets du quotidien"),
    FutureLesson(54, "🏨", "À l'hôtel et à l'hébergement"),
    FutureLesson(55, "💳", "La banque, l'argent et les paiements"),
    FutureLesson(56, "🚨", "Les urgences et les situations difficiles"),
    FutureLesson(57, "📱", "Internet, les réseaux sociaux et la communication"),
    FutureLesson(58, "📺", "Les médias, la radio et la télévision"),
    FutureLesson(59, "🎉", "La culture, les traditions et les fêtes"),
    FutureLesson(60, "🏆", "Révision générale et examen pratique")
)

@Composable
private fun FutureLessonCard(item: FutureLesson, grid: Boolean, index: Int) {
    val shape = RoundedCornerShape(22.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .height(if (grid) 156.dp else 104.dp)
            .clip(shape)
            .background(Color(0xFFE6E8ED))
            .border(1.dp, Color(0xFFD2D6DE), shape)
            .alpha(0.66f)
            .padding(if (grid) 12.dp else 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(item.emoji, fontSize = if (grid) 30.sp else 36.sp)
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                "LEÇON ${item.number.toString().padStart(2, '0')}",
                fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.2.sp,
                color = Color(0xFF737B89)
            )
            Text(
                item.title, fontSize = if (grid) 13.sp else 15.sp, fontWeight = FontWeight.Bold,
                color = Color(0xFF596170), maxLines = 3, overflow = TextOverflow.Ellipsis,
                lineHeight = if (grid) 16.sp else 19.sp
            )
            Text("À venir  ·  Bientôt disponible", fontSize = 10.sp, color = Color(0xFF7A8290))
        }
        Text("🔒", fontSize = 16.sp)
    }
}

/** Les chapitres (niveaux) en grille de tuiles, ou en liste compacte. */
@Composable
private fun ChapterStrip(
    levels: List<String>, lessons: List<Lesson>, progress: ProgressStore, grid: Boolean,
    progressScope: String, onPick: (String) -> Unit
) {
    val rows = if (grid) levels.chunked(3) else levels.map { listOf(it) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        rows.forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { level ->
                    val inLevel = lessons.filter { it.level == level }
                    val ok = inLevel.count { progress.isCompleted(it.id, progressScope) }
                    val t = levelPoster(level)
                    val content: @Composable () -> Unit = {
                        Text(level, style = PosterTitle, fontSize = 22.sp, color = Color.White)
                        Text(Levels.label(level), fontSize = 12.sp, color = Color.White.copy(alpha = 0.85f), maxLines = 1)
                        PosterBar(if (inLevel.isEmpty()) 0f else ok.toFloat() / inLevel.size, t.accent)
                    }
                    if (grid) {
                        Column(
                            Modifier.weight(1f).clip(RoundedCornerShape(18.dp))
                                .background(Brush.linearGradient(listOf(t.start, t.end)))
                                .clickable { onPick(level) }.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) { content() }
                    } else {
                        Row(
                            Modifier.weight(1f).clip(RoundedCornerShape(18.dp))
                                .background(Brush.linearGradient(listOf(t.start, t.end)))
                                .clickable { onPick(level) }.padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(level, style = PosterTitle, fontSize = 20.sp, color = Color.White)
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("${Levels.label(level)} · $ok / ${inLevel.size}", fontSize = 13.sp, color = Color.White)
                                PosterBar(if (inLevel.isEmpty()) 0f else ok.toFloat() / inLevel.size, t.accent)
                            }
                        }
                    }
                }
                if (grid) repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
private fun LevelHeader(level: String, done: Int, total: Int) {
    Row(
        Modifier.fillMaxWidth().padding(top = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            level, style = PosterTitle, color = Gold, fontSize = 18.sp,
            modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(levelColor(level))
                .padding(horizontal = 12.dp, vertical = 5.dp)
        )
        Column(Modifier.weight(1f)) {
            Text("Chapitre ${Levels.order.indexOf(level) + 1} · ${Levels.label(level)}", style = PosterTitle, fontSize = 18.sp, color = Ink)
            Text("$done / $total leçons validées", style = AccentText, fontSize = 13.sp, color = InkSoft)
        }
    }
}

@Composable
private fun LessonCard(lesson: Lesson, best: Int?, completed: Boolean, grid: Boolean, index: Int, onClick: () -> Unit) {
    val theme = levelPoster(lesson.level)
    val drawing = remember(lesson) { Art.forLesson(lesson) }
    PosterCard(
        theme, drawing, grid, seed = index,
        badge = {
            when {
                completed -> Pill("${best ?: 0} %")
                best != null -> Pill("${best} %", bg = Color.White.copy(alpha = 0.2f), fg = Color.White)
                else -> {}
            }
        },
        onClick = onClick
    ) {
        Text(
            "LEÇON ${lesson.number.toString().padStart(2, '0')}",
            fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp, color = theme.accent
        )
        Text(
            lesson.title, style = PosterTitle, fontSize = if (grid) 16.sp else 18.sp, color = Color.White,
            maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = if (grid) 19.sp else 22.sp
        )
        Text(
            lesson.titleTr, fontSize = 12.sp, color = Color.White.copy(alpha = 0.8f),
            maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 15.sp
        )
    }
}

// --------------------------------------------------------------- Modèles vocaux

@Composable
fun ModelsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val version = VoskManager.installsVersion
    val status = remember { mutableStateMapOf<String, String>() }
    val busy = remember { mutableStateMapOf<String, Float>() }
    var pendingLang by rememberSaveable { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val lang = pendingLang
        if (uri != null && lang != null) {
            scope.launch {
                busy[lang] = -1f
                status[lang] = "Décompression du modèle…"
                try {
                    val input = context.contentResolver.openInputStream(uri)
                        ?: throw IllegalStateException("Fichier illisible")
                    input.use { stream ->
                        VoskManager.installZip(context, lang, stream) { bytes ->
                            status[lang] = "Décompression… ${bytes / (1024 * 1024)} Mo"
                        }
                    }
                    status[lang] = "OK: Modèle installé"
                } catch (e: Exception) {
                    status[lang] = "ERR: ${e.message ?: "Échec de l'import"}"
                } finally {
                    busy.remove(lang)
                }
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        TopBar("Modèles vocaux", "Reconnaissance hors ligne Vosk", Navy, onBack)
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ScreenHero(
                "Le micro qui vous corrige", "Un modèle Vosk par langue, hors ligne",
                Art.icMic, PosterTheme(Navy, Night, Gold)
            )
            CardBox {
                Text("Comment ça marche ?", style = PosterTitle, fontSize = 17.sp, color = Ink)
                Text(
                    "Chaque langue a besoin d'un modèle Vosk pour écouter et corriger votre prononciation.\n" +
                        "• Précision maximale : le meilleur modèle, mais très lourd (plus de 1 Go) et gourmand en mémoire.\n" +
                        "• Léger : conçu pour les téléphones, fonctionne partout.\n" +
                        "• Importer un ZIP : choisissez un fichier .zip déjà téléchargé depuis " +
                        "alphacephei.com/vosk/models (tout modèle Vosk est accepté).\n" +
                        "Un seul modèle par langue : le nouveau remplace l'ancien.",
                    fontSize = 14.sp, color = InkSoft
                )
            }
            Languages.all.forEach { lang ->
                val code = lang.code
                val installedName = remember(version, code) { VoskManager.installedName(context, code) }
                val sizeMb = remember(version, code) { VoskManager.installedSizeMb(context, code) }
                val progressValue = busy[code]
                CardBox {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        LangBadge(lang.code, 40.dp)
                        Spacer(Modifier.width(12.dp))
                        Text(
                            if (lang.native) "${lang.name} (langue maternelle)" else lang.name,
                            style = PosterTitle, fontSize = 18.sp, color = Ink,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    if (lang.native) {
                        Text(
                            "Permet de répondre à voix haute en français dans les quiz d'écoute.",
                            fontSize = 13.sp, color = InkSoft
                        )
                    }
                    if (installedName != null) {
                        Chip("Installé : $installedName ($sizeMb Mo)", Good)
                    } else {
                        Chip("Aucun modèle installé", Warn)
                    }
                    if (progressValue != null) {
                        if (progressValue >= 0f) AnimatedBar(progressValue, Navy)
                        else LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    }
                    status[code]?.let { AutoStatus(it) }

                    lang.models.forEach { model ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(Paper)
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(
                                    "${model.label} · ${model.size}",
                                    fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Navy
                                )
                                Text(model.name, fontSize = 12.sp, color = Ink)
                                Text(model.note, fontSize = 12.sp, color = InkSoft, lineHeight = 16.sp)
                            }
                            Spacer(Modifier.width(8.dp))
                            Button(
                                enabled = progressValue == null,
                                onClick = {
                                    scope.launch {
                                        busy[code] = 0f
                                        status[code] = "Téléchargement de ${model.name}…"
                                        try {
                                            VoskManager.download(context, code, model.url) { fraction ->
                                                busy[code] = fraction
                                                status[code] = if (fraction >= 0f) {
                                                    "Téléchargement… ${(fraction * 100).toInt()} %"
                                                } else {
                                                    "Décompression du modèle…"
                                                }
                                            }
                                            status[code] = "OK: ${model.name} installé"
                                        } catch (e: Exception) {
                                            status[code] = "ERR: ${e.message ?: "Échec du téléchargement"}"
                                        } finally {
                                            busy.remove(code)
                                        }
                                    }
                                }
                            ) { LineIcon(Art.icDownload, Color.White, 18.dp, accent = Gold) }
                        }
                    }

                    OutlinedButton(
                        enabled = progressValue == null,
                        onClick = {
                            pendingLang = code
                            picker.launch(
                                arrayOf(
                                    "application/zip",
                                    "application/x-zip-compressed",
                                    "application/octet-stream"
                                )
                            )
                        }
                    ) { LineIcon(Art.icFolder, Navy, 18.dp); Spacer(Modifier.width(6.dp)); Text("Importer un ZIP") }
                    if (installedName != null && progressValue == null) {
                        TextButton(onClick = {
                            VoskManager.delete(context, code)
                            status[code] = "Modèle supprimé"
                        }) { LineIcon(Art.icTrash, Bad, 18.dp); Spacer(Modifier.width(6.dp)); Text("Supprimer le modèle installé", color = Bad) }
                    }
                }
            }
        }
    }
}
