package com.linguavibe.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.linguavibe.app.data.CourseRepository
import com.linguavibe.app.data.DialogueLine
import com.linguavibe.app.data.GrammarPoint
import com.linguavibe.app.data.Homework
import com.linguavibe.app.data.LanguageInfo
import com.linguavibe.app.data.Languages
import com.linguavibe.app.data.Lesson
import com.linguavibe.app.data.Levels
import com.linguavibe.app.data.ProgressStore
import com.linguavibe.app.data.QuizItem
import com.linguavibe.app.speech.Pronunciation
import com.linguavibe.app.speech.PronunciationResult
import com.linguavibe.app.speech.VoskManager
import com.linguavibe.app.speech.WordStatus
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch


@Composable
fun LessonScreen(lang: LanguageInfo, lessonId: String, progress: ProgressStore, onBack: () -> Unit, modelId: String = "model1") {
    val context = LocalContext.current
    val speaker = LocalSpeaker.current
    val course = remember(lang.code, modelId, CourseRepository.version) { CourseRepository.load(context, lang.code, modelId) }
    val progressScope = if (lang.code == "es") "es_$modelId" else "default"
    val lesson = course.lesson(lessonId)
    if (lesson == null) {
        Column(Modifier.fillMaxSize()) {
            TopBar("Leçon introuvable", null, IndigoDark, onBack)
        }
        return
    }
    val color = levelColor(lesson.level)
    var tab by rememberSaveable(lessonId) { mutableStateOf(0) }
    // La voix de l'appli est chargée dès l'ouverture, et les phrases de la leçon sont préparées en tâche de fond.
    LaunchedEffect(lessonId) {
        speaker.prefetch(
            lesson.phrases.map { it.text } +
                lesson.vocab.map { it.word } +
                lesson.dialogue.map { it.text } +
                (lesson.reading?.sentences?.map { it.text } ?: emptyList()),
            lang.locale
        )
    }
    val exportPdf = rememberPdfExporter()
    val modelLabel = if (lang.code == "es") when (modelId) { "model2" -> "MODEL 2"; "model3" -> "MODEL 3"; else -> "MODEL 1" } else ""

    // On coupe la voix et le micro en changeant d'onglet ou en quittant la leçon.
    LaunchedEffect(tab) {
        speaker.stop()
        VoskManager.cancel()
    }
    DisposableEffect(lessonId) {
        onDispose {
            speaker.stop()
            VoskManager.cancel()
        }
    }

    Column(Modifier.fillMaxSize()) {
        TopBar(
            lesson.title, "${lesson.level} · Leçon ${lesson.number} · ${lesson.titleTr}", color, onBack, levelPoster(lesson.level),
            action = {
                PdfTopButton {
                    exportPdf("LinguaVibe_${lang.name}_${lesson.level}_Lecon${lesson.number}.pdf") { out ->
                        com.linguavibe.app.export.PdfExporter.exportLesson(context, lang, modelLabel, lesson, out)
                    }
                }
            }
        )
        LessonTabBar(tab, color) { tab = it }
        AnimatedContent(
            targetState = tab,
            modifier = Modifier.weight(1f),
            transitionSpec = { fadeIn(tween(250)) togetherWith fadeOut(tween(150)) },
            label = "lessonTab"
        ) { current ->
            when (current) {
                0 -> LearnStep(lesson, lang, color) { tab = 1 }
                1 -> ReadingStep(lesson, lang, color) { tab = 2 }
                2 -> DialogueStep(lesson, lang, color) { tab = 3 }
                3 -> PronunciationStep(lesson, lang, color) { tab = 4 }
                4 -> QuizStep(lesson, lang, color, progress, progressScope) { tab = 5 }
                else -> HomeworkStep(lesson, lang, color, progress, progressScope)
            }
        }
    }
}

/** Étape sans contenu (leçon ajoutée depuis l'administration et encore incomplète). */
@Composable
private fun EmptyStep(message: String, next: String, color: Color, onNext: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        CardBox { StatusLine(message) }
        NextButton(next, color, onNext)
    }
}

@Composable
private fun NextButton(text: String, color: Color, onClick: () -> Unit) {
    PillButton(text, Art.icPlay, color, Modifier.fillMaxWidth(), big = true, onClick = onClick)
}

// ------------------------------------------------------------------ 1. Leçon

@Composable
private fun LearnStep(lesson: Lesson, lang: LanguageInfo, color: Color, onNext: () -> Unit) {
    val context = LocalContext.current
    val speaker = LocalSpeaker.current
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        LessonHero(lesson)
        lesson.illustrationAsset?.let { assetPath ->
            val illustration = remember(assetPath) {
                runCatching {
                    context.assets.open(assetPath).use { BitmapFactory.decodeStream(it)?.asImageBitmap() }
                }.getOrNull()
            }
            illustration?.let { bitmap ->
                Image(
                    bitmap = bitmap,
                    contentDescription = "Illustration du manuel pour ${lesson.title}",
                    modifier = Modifier.fillMaxWidth().heightIn(max = 240.dp)
                        .clip(RoundedCornerShape(18.dp)),
                    contentScale = ContentScale.Fit
                )
            }
        }
        PlaybackSpeedControl(speaker.settings.playbackSpeed, speaker.settings::updatePlaybackSpeed, color)
        speaker.lastError?.let { message ->
            CardBox {
                StatusLine(message, -1)
            }
        }
        // Le texte « Contenu officiel intégré… » est une note technique : inutile pour l'élève.
        if (lesson.intro.isNotBlank() && !lesson.intro.startsWith("Contenu officiel")) {
            ExplanationIntroCard(lesson.intro, lang, color)
        }

        if (lesson.sourceContent.isNotBlank()) {
            ManualCourse(lesson.sourceContent, color, lang)
        }

        // Écoute de toute la leçon : vocabulaire, exemples de grammaire, puis dialogue.
        val playlist = remember(lesson.id) {
            lesson.vocab.flatMap { vocab ->
                if (vocab.word.any { it == '+' || it == '…' }) listOf(vocab.example).filter { it.isNotBlank() }
                else listOf(vocab.word, vocab.example).filter { it.isNotBlank() }
            } + lesson.grammar.flatMap { point -> point.examples.map { it.text } } +
                lesson.dialogue.map { it.text } + lesson.phrases.map { it.text }
        }
        if (playlist.isNotEmpty()) {
            PillButton(
                if (speaker.sequencePlaying) "Arrêter l'écoute" else "Écouter toute la leçon",
                if (speaker.sequencePlaying) Art.icStop else Art.icVoice,
                if (speaker.sequencePlaying) Bad else Night,
                Modifier.fillMaxWidth(), big = true
            ) {
                if (speaker.sequencePlaying) speaker.stop() else speaker.speakAll(playlist, lang.locale)
            }
            if (speaker.sequencePlaying) {
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { Waveform(color) }
            }
        }

        SectionTitle("Vocabulaire", "Touchez une carte pour la retourner", Art.icBook)
        lesson.vocab.withIndex().chunked(2).forEach { pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                pair.forEach { (i, vocab) ->
                    // Pour une structure (« llevar + gerundio »), on fait entendre l'exemple.
                    val spoken = if (vocab.word.any { it == '+' || it == '…' }) vocab.example else vocab.word
                    VocabCard(vocab, i, color, { speaker.speak(spoken, lang.locale) }, Modifier.weight(1f))
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }

        if (lesson.grammar.isNotEmpty()) {
            GrammarChapters(lesson.grammar, lang, color)
        }

        NextButton("Passer à la lecture", color, onNext)
    }
}

@Composable
private fun ExplanationIntroCard(intro: String, lang: LanguageInfo, color: Color) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp))
            .background(Brush.linearGradient(listOf(color.copy(alpha = 0.16f), Color.White, Gold.copy(alpha = 0.10f))))
            .border(1.dp, color.copy(alpha = 0.22f), RoundedCornerShape(26.dp)).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(11.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            Box(Modifier.size(38.dp).clip(RoundedCornerShape(13.dp)).background(color), contentAlignment = Alignment.Center) {
                Text("✦", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            }
            Column(Modifier.weight(1f)) {
                Text("LE COURS EN CLAIR", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = color, letterSpacing = 1.1.sp)
                Text("Comprendre avant de mémoriser", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Ink)
            }
        }
        Text(intro, fontSize = 15.sp, color = Ink, lineHeight = 24.sp)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            Text("🌍", fontSize = 16.sp)
            Text("Ensuite, observez les mots et les exemples dans ${lang.nativeName}.", fontSize = 12.sp, color = InkSoft, lineHeight = 17.sp)
        }
        PronLegend(lang)
    }
}

@Composable
private fun PlaybackSpeedControl(speed: Float, onChange: (Float) -> Unit, color: Color) {
    CardBox {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Vitesse de lecture", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Ink)
                Text("S'applique aux mots, phrases et textes lus à voix haute", fontSize = 12.sp, color = InkSoft)
            }
            Text(String.format(java.util.Locale.FRANCE, "%.1fx", speed), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = color)
        }
        Slider(
            value = speed,
            onValueChange = onChange,
            valueRange = 0.5f..1.5f,
            steps = 9,
            colors = SliderDefaults.colors(thumbColor = color, activeTrackColor = color)
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("0,5× Lent", fontSize = 11.sp, color = InkSoft)
            Text("1× Normal", fontSize = 11.sp, color = InkSoft)
            Text("1,5× Rapide", fontSize = 11.sp, color = InkSoft)
        }
    }
}

/** Mode d'emploi de la prononciation figurée, par langue. */
val pronLegend = mapOf(
    "es" to "Comment lire la prononciation : syllabe accentuée en MAJUSCULES · th = « th » anglais (z, ce, ci) · " +
        "kh = son raclé de la jota · rr = r roulé · r = r battu, un seul coup de langue · " +
        "nn, mm = n et m jamais nasaux · ou = u espagnol.",
    "pt" to "Comment lire la prononciation : syllabe accentuée en MAJUSCULES · ã, ẽ, ĩ, õ, ũ = voyelles nasales " +
        "(ãou = « pão ») · rr = r du fond de la gorge, soufflé · r = r battu · tch, dj = t et d devant le son i · " +
        "è = e ouvert · ô = o fermé · ou = u.",
    "en" to "Comment lire la prononciation (anglais américain) : syllabe accentuée en MAJUSCULES, toutes les lettres " +
        "se prononcent · e = son faible · eu = u de « but » · eur = « bird » · ii = i long · â = a de « father » · " +
        "ôou = o de « go » · th = langue entre les dents (think) · dh = th doux (this) · w = ou bref · " +
        "ng = n du nez sans g · h = expiré · nn, mm = jamais nasaux.",
    "ru" to "Comment lire la prononciation : syllabe accentuée en MAJUSCULES (les voyelles non accentuées " +
        "s'affaiblissent : о se lit a, е et я se lisent i) · y = ы, i dur, langue en arrière · ' = consonne mouillée (ь) · " +
        "kh = son raclé (х) · ch = ш · j = ж · tch = ч · chtch = щ · r = r roulé · nn, mm = jamais nasaux.",
    "zh" to "La prononciation est donnée en pinyin, avec les tons : ā haut et plat · á montant · ǎ descendant puis " +
        "montant · à descendant · a sans signe = ton neutre. x ≈ ch doux · q ≈ tch soufflé · zh ≈ dj · ch ≈ tch · " +
        "c ≈ ts soufflé · z ≈ dz · r ≈ j anglais · u = ou (ü = u français).",
    "ar" to "La prononciation est transcrite en lettres latines : ā, ī, ū = voyelles longues · ʿ = son de gorge (ع) · " +
        "ʾ = coup de glotte (ء) · ḥ = h soufflé · kh = jota (خ) · gh = r grasseyé (غ) · q = k du fond de la gorge · " +
        "ṣ, ḍ, ṭ, ẓ = consonnes « lourdes » · th = th anglais dur · dh = th doux · sh = ch."
)

@Composable
fun PronLegend(lang: LanguageInfo) {
    val legend = pronLegend[lang.code] ?: return
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Paper).padding(10.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        LineIcon(Art.icBulb, Navy, 18.dp, accent = Ruby)
        Text(legend, fontSize = 12.sp, color = InkSoft, lineHeight = 16.sp)
    }
}

/** Prononciation figurée (« comment prononcer »), syllabe accentuée en MAJUSCULES. */
@Composable
fun PronLine(pron: String, color: Color, fontSize: Int = 13, onDark: Boolean = false) {
    if (pron.isBlank()) return
    Text(
        pron,
        style = AccentText,
        fontSize = fontSize.sp,
        lineHeight = (fontSize + 4).sp,
        color = if (onDark) Color.White.copy(alpha = 0.92f) else color,
        fontWeight = FontWeight.Medium
    )
}

/** Les points de grammaire présentés comme des chapitres, en grille ou en liste. */
@Composable
private fun GrammarChapters(points: List<GrammarPoint>, lang: LanguageInfo, color: Color) {
    var grid by rememberGridMode("grammar")
    var open by remember(points) { mutableIntStateOf(-1) }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.weight(1f)) {
            SectionTitle("Grammaire", "Un chapitre par règle ; touchez un exemple pour l'écouter", Art.blocks)
        }
        ViewToggle(grid, { grid = it; open = -1 })
    }
    if (grid) {
        points.withIndex().chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { (i, point) ->
                    GrammarTile(i, point, color, open == i, Modifier.weight(1f)) { open = if (open == i) -1 else i }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
            val inRow = row.firstOrNull { it.index == open }
            AnimatedVisibility(visible = inRow != null) {
                inRow?.let { GrammarCard(it.index, it.value, lang, color) }
            }
        }
    } else {
        points.forEachIndexed { index, point ->
            StaggerIn(index) { GrammarCard(index, point, lang, color) }
        }
    }
}

@Composable
private fun GrammarTile(index: Int, point: GrammarPoint, color: Color, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Column(
        modifier
            .height(156.dp)
            .clip(shape)
            .background(
                if (selected) Brush.linearGradient(listOf(Night, Navy))
                else Brush.linearGradient(listOf(color, lerpNight(color)))
            )
            .waxPattern(alpha = 0.08f, seed = index)
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(
            "CHAPITRE ${index + 1}", fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp, color = Gold
        )
        Text(
            point.title, style = PosterTitle, fontSize = 16.sp, lineHeight = 19.sp, color = Color.White,
            maxLines = 3, overflow = TextOverflow.Ellipsis
        )
        Spacer(Modifier.weight(1f))
        Pill(
            if (selected) "Fermer" else "${point.examples.size} exemple" + if (point.examples.size > 1) "s" else "",
            bg = Color.White.copy(alpha = 0.16f), fg = Color.White
        )
    }
}

@Composable
private fun GrammarCard(index: Int, point: GrammarPoint, lang: LanguageInfo, color: Color) {
    val speaker = LocalSpeaker.current
    CardBox {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                (index + 1).toString().padStart(2, '0'), style = PosterTitle, fontSize = 30.sp,
                color = color.copy(alpha = 0.25f)
            )
            Spacer(Modifier.width(10.dp))
            Column {
                Text("CHAPITRE ${index + 1}", fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp, color = color)
                Text(point.title, style = PosterTitle, fontSize = 17.sp, color = Ink, lineHeight = 20.sp)
            }
        }
        Text("EXPLICATION DANS LA LANGUE ÉTUDIÉE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = color)
        Text(point.explanation, fontSize = 14.sp, color = Ink, lineHeight = 20.sp)
        Text("COMPARAISON EN FRANÇAIS", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = color)
        Text(
            "Lisez la règle dans la langue cible, puis comparez chaque exemple à sa traduction française. Repérez ce qui change dans l'ordre des mots, les pronoms et les formes verbales.",
            fontSize = 13.sp, color = InkSoft, lineHeight = 18.sp
        )
        point.examples.forEach { example ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Paper)
                    .clickable { speaker.speak(example.text, lang.locale) }
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.width(3.dp).height(36.dp).clip(RoundedCornerShape(50)).background(Gold))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(example.text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, color = Ink)
                    PronLine(example.pron, color)
                    Text(example.translation, fontSize = 13.sp, color = InkSoft, fontStyle = FontStyle.Italic)
                }
                LineIcon(Art.icVoice, color, 18.dp)
            }
        }
    }
}

// -------------------------------------------------------- Micro et correction

/** Bouton micro complet : permission, chargement du modèle, écoute, texte en direct. */
@Composable
fun MicControl(id: String, lang: LanguageInfo, color: Color, onHeard: (String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val openModels = LocalOpenModels.current
    val speaker = LocalSpeaker.current
    val currentOnHeard by rememberUpdatedState(onHeard)
    var error by remember(id) { mutableStateOf<String?>(null) }
    var missingModel by remember(id) { mutableStateOf(false) }
    val listening = VoskManager.activeId == id
    val loading = VoskManager.loadingId == id

    val begin: () -> Unit = {
        error = null
        if (!VoskManager.isInstalled(context, lang.code)) {
            missingModel = true
        } else {
            missingModel = false
            speaker.stop()
            scope.launch {
                VoskManager.loadingId = id
                try {
                    val model = VoskManager.ensureModel(context, lang.code)
                    VoskManager.start(
                        id, model,
                        onFinal = { heard -> currentOnHeard(heard) },
                        onError = { message -> error = message }
                    )
                } catch (e: Exception) {
                    error = e.message ?: "Impossible de charger le modèle vocal"
                } finally {
                    if (VoskManager.loadingId == id) VoskManager.loadingId = null
                }
            }
        }
    }

    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) begin() else error = "Autorisez le microphone pour vous faire corriger."
    }

    DisposableEffect(id) {
        onDispose { if (VoskManager.activeId == id) VoskManager.cancel() }
    }

    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        PulsingMic(listening, loading, color) {
            val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
            when {
                listening -> VoskManager.stop()
                granted -> begin()
                else -> permission.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
        when {
            loading -> Text("Chargement du modèle vocal…", fontSize = 13.sp, color = InkSoft)
            listening -> {
                Waveform(color)
                Text(
                    VoskManager.partial.ifBlank { "Parlez… puis touchez le micro pour terminer" },
                    fontSize = 14.sp, color = Ink, textAlign = TextAlign.Center
                )
            }
            else -> Text("Touchez le micro et parlez", fontSize = 13.sp, color = InkSoft)
        }
        if (missingModel) {
            Text(
                "Aucun modèle vocal n'est encore installé pour : ${lang.name.lowercase()}.",
                fontSize = 13.sp, color = Bad, textAlign = TextAlign.Center
            )
            PillButton("Installer le modèle", Art.icDownload, Navy, filled = false, onClick = openModels)
        }
        error?.let { Text(it, fontSize = 13.sp, color = Bad, textAlign = TextAlign.Center) }
    }
}

@Composable
private fun PronunciationFeedback(result: PronunciationResult) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(scoreColor(result.score).copy(alpha = 0.08f))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ScoreRing(result.score, 68.dp)
        Spacer(Modifier.width(12.dp))
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                buildAnnotatedString {
                    result.words.forEach { word ->
                        val style = when (word.status) {
                            WordStatus.OK -> SpanStyle(color = Good, fontWeight = FontWeight.Bold)
                            WordStatus.CLOSE -> SpanStyle(color = Warn, fontWeight = FontWeight.Bold)
                            WordStatus.MISSED -> SpanStyle(
                                color = Bad, fontWeight = FontWeight.Bold,
                                textDecoration = TextDecoration.Underline
                            )
                        }
                        withStyle(style) { append(word.word) }
                        append("  ")
                    }
                },
                fontSize = 16.sp
            )
            if (result.heardText.isNotBlank()) {
                Text("Entendu : « ${result.heardText} »", fontSize = 13.sp, color = InkSoft)
            }
            Text(result.feedback, fontSize = 13.sp, color = Ink)
            Text("vert = correct · orange = presque · rouge = à retravailler", fontSize = 11.sp, color = InkSoft)
        }
    }
}

/** Micro + correction mot à mot de la phrase attendue. */
@Composable
fun PronounceBlock(id: String, expected: String, lang: LanguageInfo, color: Color) {
    var result by remember(id) { mutableStateOf<PronunciationResult?>(null) }
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        MicControl(id, lang, color) { heard ->
            result = Pronunciation.evaluate(expected, heard, lang.code)
        }
        AnimatedVisibility(visible = result != null) {
            result?.let { PronunciationFeedback(it) }
        }
    }
}

// ---------------------------------------------------------------- 2. Lecture

@Composable
private fun ReadingStep(lesson: Lesson, lang: LanguageInfo, color: Color, onNext: () -> Unit) {
    val speaker = LocalSpeaker.current
    val reading = lesson.reading
    var showPron by rememberSaveable(lesson.id) { mutableStateOf(true) }
    var showTr by rememberSaveable(lesson.id) { mutableStateOf(false) }
    var micIndex by remember(lesson.id) { mutableIntStateOf(-1) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (reading == null || reading.sentences.isEmpty()) {
            CardBox {
                StatusLine("Le texte de lecture de cette leçon arrive bientôt.")
            }
            NextButton("Passer au dialogue", color, onNext)
            return@Column
        }
        val texts = reading.sentences.map { it.text }

        CardBox {
            Row(verticalAlignment = Alignment.CenterVertically) {
                LineIcon(Art.icNews, color, 26.dp, accent = Ruby)
                Spacer(Modifier.width(10.dp))
                Text(reading.title, style = PosterTitle, fontSize = 21.sp, color = Ink, lineHeight = 24.sp)
            }
            if (reading.titleTr.isNotBlank()) {
                Text(reading.titleTr, style = AccentText, fontSize = 15.sp, color = color)
            }
            Text(
                "Lisez le texte, écoutez-le phrase par phrase, puis lisez-le à voix haute.",
                fontSize = 13.sp, color = InkSoft
            )
            PronLegend(lang)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = showPron, onClick = { showPron = !showPron },
                    label = { Text("Prononciation") }
                )
                FilterChip(
                    selected = showTr, onClick = { showTr = !showTr },
                    label = { Text("Traduction") }
                )
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PillButton(
                if (speaker.sequencePlaying) "Arrêter" else "Écouter le texte",
                if (speaker.sequencePlaying) Art.icStop else Art.icVoice,
                if (speaker.sequencePlaying) Bad else Night, Modifier.weight(1f)
            ) { if (speaker.sequencePlaying) speaker.stop() else speaker.speakAll(texts, lang.locale) }
            PillButton("Lent", Art.icSlow, color, filled = false) { speaker.speakAll(texts, lang.locale, slow = true) }
        }
        if (speaker.sequencePlaying) {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { Waveform(color) }
        }

        reading.sentences.forEachIndexed { index, sentence ->
            val active = speaker.sequencePlaying && speaker.sequenceIndex == index
            StaggerIn(index) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (active) color.copy(alpha = 0.12f) else Color.White)
                        .border(if (active) 2.dp else 1.dp, if (active) color else Sand, RoundedCornerShape(16.dp))
                        .clickable { speaker.speak(sentence.text, lang.locale) }
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(sentence.text, fontWeight = FontWeight.SemiBold, fontSize = 17.sp, color = Ink, lineHeight = 24.sp)
                    if (showPron) PronLine(sentence.pron, color, fontSize = 14)
                    if (showTr) {
                        Text(sentence.translation, fontSize = 14.sp, color = InkSoft, fontStyle = FontStyle.Italic)
                    }
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        PillButton("Écouter", Art.icVoice, color, filled = false) { speaker.speak(sentence.text, lang.locale) }
                        PillButton("Lent", Art.icSlow, color, filled = false) { speaker.speak(sentence.text, lang.locale, slow = true) }
                        PillButton("D'ici", Art.icPlay, color, filled = false) { speaker.speakAll(texts, lang.locale, from = index) }
                        PillButton(
                            if (micIndex == index) "Fermer" else "Lire",
                            if (micIndex == index) Art.icCross else Art.icMic,
                            if (micIndex == index) Bad else Night, filled = micIndex != index
                        ) { micIndex = if (micIndex == index) -1 else index }
                    }
                    AnimatedVisibility(visible = micIndex == index) {
                        PronounceBlock("reading-${lesson.id}-$index", sentence.text, lang, color)
                    }
                }
            }
        }
        NextButton("Passer au dialogue", color, onNext)
    }
}

// --------------------------------------------------------------- 3. Dialogue

@Composable
private fun DialogueStep(lesson: Lesson, lang: LanguageInfo, color: Color, onNext: () -> Unit) {
    val speaker = LocalSpeaker.current
    val lines = lesson.dialogue
    if (lines.isEmpty()) {
        EmptyStep("Cette leçon n'a pas encore de dialogue.", "Passer à la prononciation", color, onNext)
        return
    }
    var shown by remember(lesson.id) { mutableIntStateOf(1) }
    val scroll = rememberScrollState()
    val current = lines[(shown - 1).coerceIn(0, lines.lastIndex)]
    val isLast = shown >= lines.size

    LaunchedEffect(shown) {
        delay(200)
        scroll.animateScrollTo(scroll.maxValue)
        if (!current.isUser) speaker.speak(current.text, lang.locale)
    }

    Column(Modifier.fillMaxSize()) {
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(scroll)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            SectionTitle(
                "Jeu de rôle",
                "L'application joue le premier personnage, vous le second (bulles colorées). Touchez une bulle pour la réécouter.",
                Art.icChat
            )
            lines.take(shown).forEachIndexed { index, line ->
                key(index) {
                    StaggerIn(0) { Bubble(line, color) { speaker.speak(line.text, lang.locale) } }
                }
            }
        }
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp))
                .background(Color.White)
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (current.isUser) {
                Text("À vous ! Dites la phrase colorée :", style = PosterTitle, fontSize = 16.sp, color = color)
                PronounceBlock("dialogue-${lesson.id}-$shown", current.text, lang, color)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PillButton("Réécouter", Art.icSlow, color, Modifier.weight(1f), filled = false) {
                    speaker.speak(current.text, lang.locale, slow = true)
                }
                PillButton(
                    if (isLast) "Terminer" else "Continuer",
                    if (isLast) Art.icCheck else Art.icPlay, color, Modifier.weight(1f)
                ) { if (isLast) onNext() else shown++ }
            }
        }
    }
}

@Composable
private fun Bubble(line: DialogueLine, color: Color, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (line.isUser) Arrangement.End else Arrangement.Start
    ) {
        if (!line.isUser) {
            Avatar(false, color)
            Spacer(Modifier.width(8.dp))
        }
        Column(
            Modifier
                .fillMaxWidth(if (line.isUser) 0.82f else 0.95f)
                .clip(
                    RoundedCornerShape(
                        topStart = 20.dp, topEnd = 20.dp,
                        bottomStart = if (line.isUser) 20.dp else 4.dp,
                        bottomEnd = if (line.isUser) 4.dp else 20.dp
                    )
                )
                .background(
                    if (line.isUser) Brush.linearGradient(listOf(color, lerpNight(color)))
                    else Brush.linearGradient(listOf(Color.White, Color.White))
                )
                .clickable(onClick = onClick)
                .padding(12.dp)
        ) {
            val textColor = if (line.isUser) Color.White else Ink
            Text(line.text, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, color = textColor)
            PronLine(line.pron, color, onDark = line.isUser)
            Text(line.translation, fontSize = 13.sp, color = textColor.copy(alpha = 0.75f), fontStyle = FontStyle.Italic)
        }
        if (line.isUser) {
            Spacer(Modifier.width(8.dp))
            Avatar(true, color)
        }
    }
}

// ---------------------------------------------------------- 4. Prononciation

@Composable
private fun PronunciationStep(lesson: Lesson, lang: LanguageInfo, color: Color, onNext: () -> Unit) {
    val speaker = LocalSpeaker.current
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        SectionTitle(
            "Prononciation",
            "Écoutez le modèle, répétez dans le micro : chaque mot est corrigé.",
            Art.icMic
        )
        lesson.phrases.forEachIndexed { index, phrase ->
            StaggerIn(index) {
                CardBox {
                    Text(phrase.text, style = PosterTitle, fontSize = 20.sp, color = Ink, lineHeight = 24.sp)
                    PronLine(phrase.pron, color, fontSize = 15)
                    Text(phrase.translation, fontSize = 14.sp, color = InkSoft, fontStyle = FontStyle.Italic)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PillButton("Écouter", Art.icVoice, color, filled = false) { speaker.speak(phrase.text, lang.locale) }
                        PillButton("Lentement", Art.icSlow, color, filled = false) {
                            speaker.speak(phrase.text, lang.locale, slow = true)
                        }
                    }
                    PronounceBlock("phrase-${lesson.id}-$index", phrase.text, lang, color)
                }
            }
        }
        NextButton("Passer au quiz", color, onNext)
    }
}

// ------------------------------------------------------------------- 5. Quiz

@Composable
private fun QuizStep(lesson: Lesson, lang: LanguageInfo, color: Color, progress: ProgressStore, progressScope: String, onNext: () -> Unit) {
    val items = lesson.quiz
    if (items.isEmpty()) {
        EmptyStep("Cette leçon n'a pas encore de quiz.", "Faire le devoir", color, onNext)
        return
    }
    var index by remember(lesson.id) { mutableIntStateOf(0) }
    var correct by remember(lesson.id) { mutableIntStateOf(0) }
    var finished by remember(lesson.id) { mutableStateOf(false) }
    var gained by remember(lesson.id) { mutableIntStateOf(0) }

    if (finished) {
        val score = correct * 100 / items.size
        val passed = score >= ProgressStore.PASS_SCORE
        Box(Modifier.fillMaxSize()) {
            Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                LineArt(
                    if (passed) Art.trophy else Art.effort, Modifier.size(120.dp),
                    color = Ink, accent = if (passed) Gold else Ruby, strokeWidth = 2.4.dp
                )
                ScoreRing(score, 124.dp)
                Text(
                    if (passed) "Leçon validée !" else "Encore un effort",
                    style = PosterTitle, fontSize = 28.sp, color = Ink
                )
                Text(
                    "$correct bonnes réponses sur ${items.size}" +
                        if (passed) "" else " — il faut ${ProgressStore.PASS_SCORE} % pour valider.",
                    fontSize = 15.sp, color = InkSoft, textAlign = TextAlign.Center
                )
                Pill("+$gained XP")
                PillButton("Refaire le quiz", Art.icRefresh, color, filled = false) {
                    index = 0
                    correct = 0
                    finished = false
                }
                NextButton("Faire le devoir", color, onNext)
            }
            if (passed) Confetti()
        }
        return
    }

    Column(
        Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        AnimatedBar(index.toFloat() / items.size, color)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Question ${index + 1}", style = PosterTitle, fontSize = 18.sp, color = Ink)
            Text(" / ${items.size}", style = AccentText, fontSize = 15.sp, color = InkSoft)
        }
        AnimatedContent(
            targetState = index,
            modifier = Modifier.weight(1f),
            transitionSpec = {
                (fadeIn(tween(260)) + slideInHorizontally(tween(260)) { it / 5 }) togetherWith fadeOut(tween(140))
            },
            label = "question"
        ) { i ->
            QuestionView(
                item = items[i.coerceIn(0, items.lastIndex)],
                lang = lang,
                color = color,
                onAnswered = { ok -> if (ok) correct++ },
                onContinue = {
                    if (i >= items.lastIndex) {
                        gained = progress.recordQuiz(lesson.id, correct * 100 / items.size, progressScope)
                        finished = true
                    } else {
                        index = i + 1
                    }
                }
            )
        }
    }
}

@Composable
private fun QuestionView(
    item: QuizItem,
    lang: LanguageInfo,
    color: Color,
    onAnswered: (Boolean) -> Unit,
    onContinue: () -> Unit
) {
    val speaker = LocalSpeaker.current
    var answered by remember(item) { mutableStateOf(false) }
    var wasCorrect by remember(item) { mutableStateOf(false) }
    var note by remember(item) { mutableStateOf("") }
    val submit: (Boolean, String) -> Unit = { ok, message ->
        if (!answered) {
            answered = true
            wasCorrect = ok
            note = message
            onAnswered(ok)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        when (item) {
            is QuizItem.Mcq -> {
                Text(item.question, style = PosterTitle, fontSize = 21.sp, color = Ink, lineHeight = 26.sp)
                Options(item.correct, item.wrong, answered) { ok -> submit(ok, item.correct) }
            }

            is QuizItem.Listen -> {
                LaunchedEffect(item) {
                    delay(350)
                    speaker.speak(item.phrase, lang.locale)
                }
                Text("Écoutez et choisissez le sens", style = PosterTitle, fontSize = 21.sp, color = Ink)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PillButton("Écouter", Art.icVoice, color) { speaker.speak(item.phrase, lang.locale) }
                    PillButton("Lentement", Art.icSlow, color, filled = false) {
                        speaker.speak(item.phrase, lang.locale, slow = true)
                    }
                }
                Options(
                    item.correct, item.wrong, answered,
                    voiceId = "quiz-voice-${item.phrase.hashCode()}"
                ) { ok -> submit(ok, "${item.phrase} = ${item.correct}") }
            }

            is QuizItem.Typed -> {
                var input by remember(item) { mutableStateOf("") }
                Text(
                    "Traduisez en ${lang.name.lowercase()}" +
                        when (lang.code) {
                            "zh" -> " (caractères ou pinyin)"
                            "ar" -> " (écriture arabe ou lettres latines)"
                            else -> ""
                        },
                    fontSize = 14.sp, color = InkSoft
                )
                Text(item.prompt, style = PosterTitle, fontSize = 21.sp, color = Ink, lineHeight = 26.sp)
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    enabled = !answered,
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Votre réponse") }
                )
                if (!answered) {
                    PillButton("Valider", Art.icCheck, color, enabled = input.isNotBlank()) {
                            val typed = Pronunciation.matchKey(input, lang.code)
                            val ok = item.answers.any { Pronunciation.matchKey(it, lang.code) == typed }
                            val exact = item.answers.any {
                                Pronunciation.clean(it).replace(" ", "") == Pronunciation.clean(input).replace(" ", "")
                            }
                            // En chinois et en arabe, on donne l'écriture d'origine et sa transcription.
                            val best = item.answers.first() +
                                if (lang.code in setOf("zh", "ar") && item.answers.size > 1) "  ·  ${item.answers[1]}" else ""
                            val note = when (lang.code) {
                                "zh" -> "attention aux tons"
                                "ar" -> "attention aux voyelles longues"
                                else -> "attention aux accents"
                            }
                            submit(ok, if (ok && !exact) "$best  ($note)" else best)
                    }
                }
            }
        }

        AnimatedVisibility(visible = answered) {
            val feedbackColor = if (wasCorrect) Good else Bad
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(feedbackColor.copy(alpha = 0.12f))
                    .padding(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    LineIcon(if (wasCorrect) Art.icCheck else Art.icCross, feedbackColor, 20.dp)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        if (wasCorrect) "Bravo !" else "Pas tout à fait",
                        style = PosterTitle, color = feedbackColor, fontSize = 17.sp
                    )
                }
                Text("Réponse : $note", color = Ink, fontSize = 15.sp)
            }
        }
        if (answered) NextButton("Continuer", color, onContinue)
    }
}

@Composable
private fun Options(
    correct: String,
    wrong: List<String>,
    answered: Boolean,
    voiceId: String? = null,
    onPick: (Boolean) -> Unit
) {
    val context = LocalContext.current
    val options = remember(correct, wrong) { (wrong + correct).distinct().shuffled() }
    var picked by remember(correct, wrong) { mutableStateOf<String?>(null) }
    var voiceNote by remember(correct, wrong) { mutableStateOf<String?>(null) }
    options.forEach { option ->
        val highlight = when {
            !answered -> null
            option == correct -> Good
            option == picked -> Bad
            else -> null
        }
        val background by animateColorAsState(highlight?.copy(alpha = 0.16f) ?: Color.White, label = "optionBg")
        val shape = RoundedCornerShape(16.dp)
        Text(
            option,
            fontSize = 16.sp,
            color = Ink,
            fontWeight = if (highlight != null) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(background)
                .border(1.5.dp, highlight ?: Sand, shape)
                .clickable(enabled = !answered) {
                    picked = option
                    onPick(option == correct)
                }
                .padding(16.dp)
        )
    }

    // Réponse à voix haute dans la langue maternelle, si son modèle vocal est installé.
    val native = Languages.native
    val version = VoskManager.installsVersion
    val nativeReady = remember(version) { VoskManager.isInstalled(context, native.code) }
    if (voiceId != null && nativeReady && !answered) {
        Text("…ou dites la réponse en ${native.name.lowercase()} :", fontSize = 13.sp, color = InkSoft)
        MicControl(voiceId, native, Navy) { heard ->
            val best = options.maxByOrNull { Pronunciation.evaluate(it, heard, native.code).score }
            val score = if (best == null) 0 else Pronunciation.evaluate(best, heard, native.code).score
            if (best != null && score >= 60) {
                picked = best
                onPick(best == correct)
            } else {
                voiceNote = "Je n'ai reconnu aucune des réponses (entendu : « $heard »). Réessayez ou touchez une réponse."
            }
        }
        voiceNote?.let { Text(it, fontSize = 13.sp, color = Bad) }
    }
}

// ----------------------------------------------------------------- 5. Devoir

@Composable
private fun HomeworkStep(lesson: Lesson, lang: LanguageInfo, color: Color, progress: ProgressStore, progressScope: String) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        SectionTitle(
            "Devoir",
            "Répondez en ${lang.name.lowercase()} avec vos propres mots (à l'écrit ou à la voix), puis comparez au modèle.",
            Art.icPen
        )
        if (lesson.homework.isEmpty()) {
            CardBox { StatusLine("Cette leçon n'a pas encore de devoir.") }
        }
        lesson.homework.forEachIndexed { index, homework ->
            HomeworkCard("${lesson.id}-$index", index + 1, homework, lang, color, progress, progressScope)
        }
    }
}

@Composable
private fun HomeworkCard(
    key: String,
    number: Int,
    homework: Homework,
    lang: LanguageInfo,
    color: Color,
    progress: ProgressStore,
    progressScope: String
) {
    val speaker = LocalSpeaker.current
    var text by remember(key, progressScope) { mutableStateOf(progress.homeworkAnswer(key, progressScope)) }
    var corrected by remember(key) { mutableStateOf(false) }
    CardBox {
        Text("QUESTION $number", fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp, color = color)
        Text(homework.prompt, style = PosterTitle, fontSize = 17.sp, color = Ink, lineHeight = 22.sp)
        OutlinedTextField(
            value = text,
            onValueChange = {
                text = it
                corrected = false
            },
            modifier = Modifier.fillMaxWidth(),
            minLines = 3,
            label = { Text("Votre réponse") }
        )
        Text("…ou dictez votre réponse :", fontSize = 13.sp, color = InkSoft)
        MicControl("homework-$key", lang, color) { heard ->
            if (heard.isNotBlank()) {
                text = (text.trim() + " " + heard).trim()
                corrected = false
            }
        }
        PillButton("Corriger mon devoir", Art.icCheck, color, enabled = text.isNotBlank()) {
            progress.saveHomework(key, text, progressScope)
            corrected = true
        }

        AnimatedVisibility(visible = corrected) {
            val answer = Pronunciation.matchKey(text, lang.code)
            // Un mot-clé peut avoir des variantes séparées par « / » (caractères / pinyin).
            val found = homework.keywords.filter { keyword ->
                keyword.split('/').any { variant ->
                    val key = Pronunciation.matchKey(variant, lang.code)
                    key.isNotBlank() && answer.contains(key)
                }
            }.map { it.replace("/", " / ") }
            val missing = homework.keywords.map { it.replace("/", " / ") }.filter { it !in found }
            val wordCount = if (lang.code == "zh") answer.length / 2 else text.split(Regex("\\s+")).count { it.isNotBlank() }
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (homework.keywords.isNotEmpty()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        ScoreRing(found.size * 100 / homework.keywords.size, 60.dp)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            if (found.isNotEmpty()) {
                                StatusLine("Bien utilisé : ${found.joinToString(", ")}", 1)
                            }
                            if (missing.isNotEmpty()) {
                                StatusLine("À intégrer : ${missing.joinToString(", ")}")
                            }
                        }
                    }
                }
                if (wordCount < 6) {
                    StatusLine("Développez davantage : visez au moins deux phrases complètes.")
                }
                Text("Réponse modèle (touchez pour écouter)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = color)
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Paper)
                        .clickable { speaker.speak(homework.model, lang.locale) }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(homework.model, fontSize = 15.sp, color = Ink, lineHeight = 21.sp, modifier = Modifier.weight(1f))
                    Spacer(Modifier.width(8.dp))
                    LineIcon(Art.icVoice, color, 20.dp)
                }
                Text(
                    "La correction automatique vérifie les éléments clés attendus ; comparez votre texte au modèle " +
                        "pour l'orthographe et la grammaire.",
                    fontSize = 12.sp, color = InkSoft
                )
            }
        }
    }
}
