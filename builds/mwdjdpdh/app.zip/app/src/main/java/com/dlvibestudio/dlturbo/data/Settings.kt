package com.dlvibestudio.dlturbo.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class SettingsData(
    // Général
    val maxParallel: Int = 3,
    val connections: Int = 8,
    /** Octets par seconde, 0 = illimité. */
    val speedLimit: Long = 0,
    val wifiOnly: Boolean = false,
    val autoResume: Boolean = true,
    val retries: Int = 8,
    val sortByCategory: Boolean = true,
    val userAgent: String = DEFAULT_UA,
    // Notifications
    val soundOnComplete: Boolean = true,
    // Vidéo
    val videoQuality: String = "best",
    val preferMp4: Boolean = true,
    val wholePlaylist: Boolean = false,
    val videoFragments: Int = 8,
    // Torrent
    val torrentUploadLimit: Long = 100 * 1024,
    val torrentMaxConnections: Int = 200,
    val torrentSeed: Boolean = false,
    /** Saisons entières : télécharger les épisodes dans l'ordre (1, puis 2…). */
    val torrentEpisodeOrder: Boolean = true,
    // Apparence : "system", "dark", "light"
    val theme: String = "dark",
    // Navigateur
    val blockAds: Boolean = true,
    val blockPopups: Boolean = true,
    val blockRedirects: Boolean = true,
    /** "google", "duckduckgo" ou "bing". */
    val searchEngine: String = "google",
    /** Téléchargements programmés : seulement dans la plage horaire (minutes depuis minuit). */
    val scheduleOn: Boolean = false,
    val scheduleStart: Int = 60,
    val scheduleEnd: Int = 420,
    /** Verrouillage par code : empreinte du code (vide = pas de verrouillage). */
    val pinHash: String = "",
    val pinSalt: String = "",
    /** Vidéo : sous-titres téléchargés et intégrés ; langues séparées par des virgules. */
    val subtitles: Boolean = false,
    val subtitleLangs: String = "fr,en",
    /** Audio : miniature, titre et artiste intégrés au fichier. */
    val embedMeta: Boolean = true,
    /** Batterie faible et pas sur secteur : un seul téléchargement à la fois. */
    val batterySaver: Boolean = false,
    /** Propose de télécharger un lien copié au retour dans l'appli. */
    val clipboardWatch: Boolean = true,
    /** Vidéos et musiques rangées dans un sous-dossier par site (YouTube, TikTok…). */
    val folderBySite: Boolean = false,
    /** Écran de démarrage animé (logo + « Created by DL VIBE STUDIO »). */
    val splash: Boolean = true,
) {
    companion object {
        const val DEFAULT_UA =
            "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) " +
                "Chrome/126.0.0.0 Mobile Safari/537.36"
    }
}

class Settings(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    private val _data = MutableStateFlow(load())
    val data: StateFlow<SettingsData> = _data.asStateFlow()
    val value: SettingsData get() = _data.value

    fun update(transform: (SettingsData) -> SettingsData) {
        val next = transform(_data.value)
        _data.value = next
        save(next)
    }

    private fun load(): SettingsData {
        val d = SettingsData()
        return SettingsData(
            maxParallel = prefs.getInt("maxParallel", d.maxParallel).coerceIn(1, 10),
            connections = prefs.getInt("connections", d.connections).coerceIn(1, 32),
            speedLimit = prefs.getLong("speedLimit", d.speedLimit),
            wifiOnly = prefs.getBoolean("wifiOnly", d.wifiOnly),
            autoResume = prefs.getBoolean("autoResume", d.autoResume),
            retries = prefs.getInt("retries", d.retries).coerceIn(0, 30),
            sortByCategory = prefs.getBoolean("sortByCategory", d.sortByCategory),
            userAgent = prefs.getString("userAgent", d.userAgent) ?: d.userAgent,
            soundOnComplete = prefs.getBoolean("soundOnComplete", d.soundOnComplete),
            videoQuality = prefs.getString("videoQuality", d.videoQuality) ?: d.videoQuality,
            preferMp4 = prefs.getBoolean("preferMp4", d.preferMp4),
            wholePlaylist = prefs.getBoolean("wholePlaylist", d.wholePlaylist),
            videoFragments = prefs.getInt("videoFragments", d.videoFragments).coerceIn(1, 16),
            torrentUploadLimit = prefs.getLong("torrentUploadLimit", d.torrentUploadLimit),
            torrentMaxConnections = prefs.getInt("torrentMaxConnections", d.torrentMaxConnections),
            torrentSeed = prefs.getBoolean("torrentSeed", d.torrentSeed),
            torrentEpisodeOrder = prefs.getBoolean("torrentEpisodeOrder", d.torrentEpisodeOrder),
            theme = prefs.getString("theme", d.theme) ?: d.theme,
            blockAds = prefs.getBoolean("blockAds", d.blockAds),
            blockPopups = prefs.getBoolean("blockPopups", d.blockPopups),
            blockRedirects = prefs.getBoolean("blockRedirects", d.blockRedirects),
            searchEngine = prefs.getString("searchEngine", d.searchEngine) ?: d.searchEngine,
            scheduleOn = prefs.getBoolean("scheduleOn", d.scheduleOn),
            scheduleStart = prefs.getInt("scheduleStart", d.scheduleStart).coerceIn(0, 1439),
            scheduleEnd = prefs.getInt("scheduleEnd", d.scheduleEnd).coerceIn(0, 1439),
            pinHash = prefs.getString("pinHash", d.pinHash) ?: d.pinHash,
            pinSalt = prefs.getString("pinSalt", d.pinSalt) ?: d.pinSalt,
            subtitles = prefs.getBoolean("subtitles", d.subtitles),
            subtitleLangs = prefs.getString("subtitleLangs", d.subtitleLangs) ?: d.subtitleLangs,
            embedMeta = prefs.getBoolean("embedMeta", d.embedMeta),
            batterySaver = prefs.getBoolean("batterySaver", d.batterySaver),
            clipboardWatch = prefs.getBoolean("clipboardWatch", d.clipboardWatch),
            folderBySite = prefs.getBoolean("folderBySite", d.folderBySite),
            splash = prefs.getBoolean("splash", d.splash),
        )
    }

    private fun save(s: SettingsData) {
        prefs.edit()
            .putInt("maxParallel", s.maxParallel)
            .putInt("connections", s.connections)
            .putLong("speedLimit", s.speedLimit)
            .putBoolean("wifiOnly", s.wifiOnly)
            .putBoolean("autoResume", s.autoResume)
            .putInt("retries", s.retries)
            .putBoolean("sortByCategory", s.sortByCategory)
            .putString("userAgent", s.userAgent)
            .putBoolean("soundOnComplete", s.soundOnComplete)
            .putString("videoQuality", s.videoQuality)
            .putBoolean("preferMp4", s.preferMp4)
            .putBoolean("wholePlaylist", s.wholePlaylist)
            .putInt("videoFragments", s.videoFragments)
            .putLong("torrentUploadLimit", s.torrentUploadLimit)
            .putInt("torrentMaxConnections", s.torrentMaxConnections)
            .putBoolean("torrentSeed", s.torrentSeed)
            .putBoolean("torrentEpisodeOrder", s.torrentEpisodeOrder)
            .putString("theme", s.theme)
            .putBoolean("blockAds", s.blockAds)
            .putBoolean("blockPopups", s.blockPopups)
            .putBoolean("blockRedirects", s.blockRedirects)
            .putString("searchEngine", s.searchEngine)
            .putBoolean("scheduleOn", s.scheduleOn)
            .putInt("scheduleStart", s.scheduleStart)
            .putInt("scheduleEnd", s.scheduleEnd)
            .putString("pinHash", s.pinHash)
            .putString("pinSalt", s.pinSalt)
            .putBoolean("subtitles", s.subtitles)
            .putString("subtitleLangs", s.subtitleLangs)
            .putBoolean("embedMeta", s.embedMeta)
            .putBoolean("batterySaver", s.batterySaver)
            .putBoolean("clipboardWatch", s.clipboardWatch)
            .putBoolean("folderBySite", s.folderBySite)
            .putBoolean("splash", s.splash)
            .apply()
    }
}
