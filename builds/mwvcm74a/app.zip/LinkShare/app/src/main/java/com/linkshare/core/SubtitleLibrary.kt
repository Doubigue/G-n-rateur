package com.linkshare.core

import android.content.Context
import android.net.Uri
import java.io.File
import java.security.MessageDigest

/** Sous-titres latéraux de LinkShare : aucun changement du fichier vidéo. */
object SubtitleLibrary {
    data class Cue(val startMs: Long, val endMs: Long, val text: String)

    private fun key(video: String): String = MessageDigest.getInstance("SHA-256")
        .digest(video.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }

    fun attach(context: Context, video: String, subtitleUri: Uri): Int {
        val raw = context.contentResolver.openInputStream(subtitleUri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
            ?: error("Fichier de sous-titres illisible")
        val parsed = parse(raw)
        require(parsed.isNotEmpty()) { "Aucun horodatage de sous-titre reconnu" }
        val id = key(video)
        val file = File(context.filesDir, "subtitle-sidecars/$id.txt")
        file.parentFile?.mkdirs()
        file.writeText(raw, Charsets.UTF_8)
        context.getSharedPreferences("subtitle-sidecars", Context.MODE_PRIVATE).edit()
            .putString(id, file.name).apply()
        return parsed.size
    }

    fun load(context: Context, video: String): List<Cue> {
        val id = key(video)
        val name = context.getSharedPreferences("subtitle-sidecars", Context.MODE_PRIVATE).getString(id, null) ?: return emptyList()
        val file = File(File(context.filesDir, "subtitle-sidecars"), name)
        if (!file.isFile) return emptyList()
        return runCatching { parse(file.readText(Charsets.UTF_8)) }.getOrDefault(emptyList())
    }

    private fun parse(source: String): List<Cue> {
        val text = source.removePrefix("\uFEFF").replace("\r\n", "\n").replace('\r', '\n')
        val cues = mutableListOf<Cue>()
        val srt = Regex("""(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})\s*-->\s*(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})""")
        val txt = Regex("""\[(\d{1,2}):(\d{2}):(\d{2})[.,](\d{1,3})\s*[→-]+\s*(\d{1,2}):(\d{2}):(\d{2})[.,](\d{1,3})\]\s*(.+)""")
        fun ms(h: String, m: String, s: String, f: String) = h.toLong()*3_600_000 + m.toLong()*60_000 + s.toLong()*1000 + f.padEnd(3,'0').take(3).toLong()
        val lines = text.lines()
        var i = 0
        while (i < lines.size) {
            val line = lines[i].trim()
            val match = srt.find(line)
            val oneLine = txt.find(line)
            if (match != null) {
                val g = match.groupValues
                val start = ms(g[1],g[2],g[3],g[4]); val end = ms(g[5],g[6],g[7],g[8])
                i++
                val body = StringBuilder()
                while (i < lines.size && lines[i].isNotBlank() && !srt.containsMatchIn(lines[i])) {
                    if (body.isNotEmpty()) body.append(' ')
                    body.append(lines[i].trim()); i++
                }
                val clean = body.toString().replace(Regex("<[^>]+>"), "").trim()
                if (end > start && clean.isNotEmpty()) cues += Cue(start,end,clean)
                continue
            }
            if (oneLine != null) {
                val g = oneLine.groupValues
                val start = ms(g[1],g[2],g[3],g[4]); val end = ms(g[5],g[6],g[7],g[8])
                if (end > start) cues += Cue(start,end,g[9].trim())
            }
            i++
        }
        return cues.sortedBy { it.startMs }
    }
}
