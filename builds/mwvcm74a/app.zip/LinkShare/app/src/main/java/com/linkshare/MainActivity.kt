package com.linkshare

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.os.Bundle
import android.os.Environment
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.material3.*
import androidx.compose.runtime.SideEffect
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.core.view.WindowCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import android.app.NotificationManager
import com.linkshare.client.TransferManager
import com.linkshare.client.TransferNotifier
import com.linkshare.ui.AppEvents
import com.linkshare.ui.ExternalOpen
import com.linkshare.ui.LS
import com.linkshare.scores.EXTRA_SCORES
import com.linkshare.scores.ScoresPrefs
import com.linkshare.scores.ScoresService
import com.linkshare.ui.PipHost
import com.linkshare.ui.PlayerHost
import com.linkshare.ui.ScoresOpen
import com.linkshare.ui.VaultLock
import com.linkshare.ui.LinkShareApp
import com.linkshare.ui.MainViewModel
import com.linkshare.ui.UiStyle
import com.linkshare.ui.Fonts
import com.linkshare.ui.appTypography
import androidx.compose.runtime.remember

private const val ACTION_BROWSE = "android.provider.action.BROWSE"
private val FOLDER_TYPES = setOf("vnd.android.document/directory", "vnd.android.document/root", "resource/folder")

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onStart() {
        super.onStart()
        TransferManager.appVisible = true
        AppEvents.resumeTick += 1
        getSystemService(NotificationManager::class.java).cancel(TransferNotifier.ID)
        // Scores en notification activés : on relance le suivi (l'appli est au premier plan, c'est autorisé)
        if (ScoresPrefs.notif(this)) ScoresService.start(this)
    }

    /** Coffre : verrouillé et lecture coupée, quelle que soit la façon de quitter l'écran. */
    private fun secureVault() {
        PlayerHost.stopIfSecure()
        VaultLock.unlocked = false
    }

    /** Bouton « récents » (ou Accueil) : appelé avant même que l'appli ne quitte l'écran. */
    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        secureVault()
        // Une vidéo est en cours : elle se réduit en fenêtre flottante au lieu de disparaître
        PipHost.enter(this)
    }

    // ── Fenêtre flottante : bouton lecture / pause et fermeture ──
    private var pipReceiverOn = false
    private val pipReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val p = PlayerHost.controller ?: return
            p.playWhenReady = !p.playWhenReady
            PipHost.refresh(this@MainActivity)
        }
    }

    private fun setPipReceiver(on: Boolean) {
        if (on == pipReceiverOn) return
        if (on) ContextCompat.registerReceiver(this, pipReceiver, IntentFilter(PipHost.ACTION_TOGGLE), ContextCompat.RECEIVER_NOT_EXPORTED)
        else runCatching { unregisterReceiver(pipReceiver) }
        pipReceiverOn = on
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        PipHost.inPip = isInPictureInPictureMode
        setPipReceiver(isInPictureInPictureMode)
        // Fenêtre fermée avec la croix : l'activité est arrêtée, on coupe la lecture et on fermera le lecteur
        if (!isInPictureInPictureMode && lifecycle.currentState == Lifecycle.State.CREATED && PlayerHost.videoActive) {
            PlayerHost.stop()
            PipHost.dismissed = true
        }
    }

    override fun onDestroy() {
        setPipReceiver(false)
        super.onDestroy()
    }

    override fun onPause() {
        super.onPause()
        if (!isChangingConfigurations) secureVault()
    }

    override fun onStop() {
        super.onStop()
        TransferManager.appVisible = false
        secureVault() // le coffre se reverrouille dès que l'app quitte l'écran
    }

    /**
     * Ouverture depuis une autre appli : vidéo, audio, image, texte (y compris en streaming http/https) ou dossier
     * (« Ouvrir avec », « Afficher dans le dossier », Réglages › Stockage › Parcourir, Téléchargements).
     */
    private fun handleIntent(i: Intent?) {
        if (i == null) return
        if (i.getBooleanExtra(EXTRA_SCORES, false)) { ScoresOpen.request = true; return }
        when (i.action) {
            Intent.ACTION_VIEW, ACTION_BROWSE -> {
                val data = i.data ?: return
                val type = i.type ?: contentResolver.getType(data)
                if (i.action == ACTION_BROWSE || (type != null && type in FOLDER_TYPES)) {
                    ExternalOpen.folder = ExternalOpen.resolveFolder(data)
                } else {
                    ExternalOpen.inApp = false
                    ExternalOpen.mime = type
                    ExternalOpen.uri = data
                }
            }
            DownloadManager.ACTION_VIEW_DOWNLOADS ->
                ExternalOpen.folder = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        UiStyle.load(this) // thème, accent, animations… choisis dans Paramètres
        com.linkshare.core.Bridges.load(this) // ponts activés / désactivés
        com.linkshare.ui.AppUpdate.load(this) // source des mises à jour intégrées
        // Relancée depuis les applis récentes, l'activité reçoit encore l'intent d'origine : on ne rouvre pas le fichier
        val fromHistory = (intent.flags and Intent.FLAG_ACTIVITY_LAUNCHED_FROM_HISTORY) != 0
        if (savedInstanceState == null && !fromHistory) handleIntent(intent)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        setContent {
            val light = UiStyle.pal.light
            // Icônes de la barre d'état / de navigation : sombres sur un thème clair
            SideEffect {
                WindowCompat.getInsetsController(window, window.decorView).apply {
                    isAppearanceLightStatusBars = light
                    isAppearanceLightNavigationBars = light
                }
            }
            val scheme = if (light) lightColorScheme(
                primary = LS.Blue, onPrimary = LS.OnBlue,
                background = LS.Bg, surface = LS.Bg, onSurface = LS.Text, onBackground = LS.Text,
                surfaceContainer = LS.Card2, surfaceContainerHigh = LS.Card2, surfaceContainerHighest = LS.Card2,
                surfaceContainerLow = LS.Card, surfaceVariant = LS.Card2, onSurfaceVariant = LS.Muted,
            ) else darkColorScheme(
                primary = LS.Blue, onPrimary = LS.OnBlue,
                background = LS.Bg, surface = LS.Bg, onSurface = LS.Text, onBackground = LS.Text,
                surfaceContainer = LS.Card2, surfaceContainerHigh = LS.Card2, surfaceContainerHighest = LS.Card2,
                surfaceContainerLow = LS.Card, surfaceVariant = LS.Card2, onSurfaceVariant = LS.Muted,
            )
            // Police du style (tirée au hasard avec les couleurs si « Style aléatoire ») appliquée à tous les textes
            val font = UiStyle.font
            val typography = remember(font) { appTypography(Fonts.of(font)) }
            MaterialTheme(colorScheme = scheme, typography = typography) {
                Surface(color = LS.Bg) { LinkShareApp(vm) }
            }
        }
    }
}
