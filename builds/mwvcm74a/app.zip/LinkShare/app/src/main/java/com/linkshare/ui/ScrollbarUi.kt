package com.linkshare.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * Ascenseur (barre de défilement rapide) : une poignée à droite de la liste, visible pendant le défilement.
 * On la saisit et on la glisse pour parcourir tout de suite une longue liste.
 * À poser dans un Box qui contient la liste : `ListScrollThumb(state, Modifier.align(Alignment.CenterEnd))`.
 */
@Composable
internal fun ListScrollThumb(state: LazyListState, modifier: Modifier = Modifier) {
    val scope = rememberCoroutineScope()
    ScrollThumb(
        total = state.layoutInfo.totalItemsCount, visible = state.layoutInfo.visibleItemsInfo.size,
        first = state.firstVisibleItemIndex, scrolling = state.isScrollInProgress,
        scrollTo = { i -> scope.launch { state.scrollToItem(i) } }, modifier = modifier,
    )
}

@Composable
internal fun GridScrollThumb(state: LazyGridState, modifier: Modifier = Modifier) {
    val scope = rememberCoroutineScope()
    ScrollThumb(
        total = state.layoutInfo.totalItemsCount, visible = state.layoutInfo.visibleItemsInfo.size,
        first = state.firstVisibleItemIndex, scrolling = state.isScrollInProgress,
        scrollTo = { i -> scope.launch { state.scrollToItem(i) } }, modifier = modifier,
    )
}

@Composable
private fun ScrollThumb(
    total: Int, visible: Int, first: Int, scrolling: Boolean, scrollTo: (Int) -> Unit, modifier: Modifier,
) {
    var dragging by remember { mutableStateOf(false) }
    var dragFraction by remember { mutableFloatStateOf(0f) }
    var recent by remember { mutableStateOf(false) }
    LaunchedEffect(scrolling, dragging) {
        if (scrolling || dragging) recent = true else { delay(1200); recent = false }
    }
    val longEnough = visible > 0 && total > visible * 2 // liste courte : inutile
    val show = longEnough && (recent || dragging)
    val alpha by animateFloatAsState(if (show) 1f else 0f, label = "scrollThumb")
    val maxFirst = (total - visible).coerceAtLeast(1)
    val fraction = if (dragging) dragFraction else (first.toFloat() / maxFirst).coerceIn(0f, 1f)
    val maxFirstNow by rememberUpdatedState(maxFirst)
    val fractionNow by rememberUpdatedState(fraction)
    val scrollNow by rememberUpdatedState(scrollTo)

    if (!longEnough || (alpha == 0f && !show)) return
    BoxWithConstraints(modifier.fillMaxHeight().width(30.dp).alpha(alpha)) {
        val d = LocalDensity.current
        val thumb = 56.dp
        val range = (with(d) { maxHeight.toPx() } - with(d) { thumb.toPx() }).coerceAtLeast(1f)
        val rangeNow by rememberUpdatedState(range)
        Box(
            Modifier.align(Alignment.TopEnd)
                .offset { IntOffset(0, (fraction * range).roundToInt()) }
                .width(30.dp).height(thumb)
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { dragging = true; dragFraction = fractionNow },
                        onDragEnd = { dragging = false },
                        onDragCancel = { dragging = false },
                    ) { change, drag ->
                        change.consume()
                        dragFraction = (dragFraction + drag.y / rangeNow).coerceIn(0f, 1f)
                        scrollNow((dragFraction * maxFirstNow).roundToInt())
                    }
                },
            contentAlignment = Alignment.CenterEnd,
        ) {
            Box(
                Modifier.padding(end = 3.dp).width(if (dragging) 10.dp else 6.dp).height(thumb)
                    .clip(RoundedCornerShape(50)).background(LS.Blue.copy(alpha = if (dragging) 0.95f else 0.7f)),
            )
        }
    }
}
