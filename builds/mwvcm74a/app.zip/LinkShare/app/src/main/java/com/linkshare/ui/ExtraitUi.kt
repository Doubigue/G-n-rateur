package com.linkshare.ui

import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linkshare.core.ExtraitBridge
import com.linkshare.core.ExtraitContract
import com.linkshare.core.ExtraitLaunch
import com.linkshare.core.ExtraitRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Petite barre qui apparaît dès qu'on sélectionne une ou plusieurs images : deux boutons, « Extraire le texte »
 * (OCR) et « PDF », qui passent par le pont vers l'appli Extrait. Affichée au-dessus de la carte de sélection.
 */
@Composable
internal fun ExtraitQuickBar(ex: ExplorerViewModel) {
    val paths = ex.selected.toList()
    if (paths.isEmpty()) return
    val ok = remember(paths) { ExtraitBridge.relevant(paths.map { File(it) }) && paths.none { ex.inVault(File(it)) } }
    if (!ok) return
    val ctx = LocalContext.current
    val installed = remember { ExtraitBridge.isInstalled(ctx) }
    val shape = RoundedCornerShape(22.dp)

    fun go(mode: String) {
        if (!installed) {
            ex.message = "Installez l'appli Extrait pour extraire le texte ou créer un PDF"
            return
        }
        ex.extraitRequest = ExtraitRequest(paths.map { File(it) }, mode)
    }

    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp).clip(shape).background(LS.Sheet).border(1.dp, LS.Line, shape)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                if (paths.size == 1) "1 image" else "${paths.size} images",
                color = LS.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
            )
            Text(
                if (installed) "Avec Extrait" else "Extrait n'est pas installé",
                color = LS.Muted, fontSize = 11.sp,
            )
        }
        QuickButton("Extraire le texte", LS.Blue, LS.OnBlue) { go(ExtraitContract.MODE_OCR) }
        Spacer(Modifier.width(8.dp))
        QuickButton("PDF", LS.BlueLight, LS.Blue) { go(ExtraitContract.MODE_PDF) }
    }
}

@Composable
private fun QuickButton(label: String, bg: Color, fg: Color, onClick: () -> Unit) {
    Text(
        label, color = fg, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
        modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(bg).clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp),
    )
}

/**
 * À composer UNE fois (à côté de MediaActionsHost). Lance Extrait pour la demande en cours et, quand Extrait
 * renvoie un PDF, le range dans le dossier des images d'origine. Le launcher reste toujours composé : le résultat
 * arrive après la fermeture de la fenêtre d'Extrait, alors que la sélection a déjà été effacée.
 */
@Composable
internal fun ExtraitHost(ex: ExplorerViewModel) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var pending by remember { mutableStateOf<ExtraitRequest?>(null) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val req = pending
        pending = null
        val uri = r.data?.data
        // Extrait ne renvoie un résultat que lorsqu'un PDF a été créé (peu importe le bouton choisi dans sa fenêtre)
        if (req == null || r.resultCode != Activity.RESULT_OK || uri == null) {
            return@rememberLauncherForActivityResult
        }
        val dir = req.files.firstOrNull()?.parentFile ?: req.saveDir ?: return@rememberLauncherForActivityResult
        scope.launch {
            try {
                val saved = withContext(Dispatchers.IO) {
                    ExtraitBridge.saveResult(ctx, uri, dir, ExtraitBridge.resultBaseName(req.files), "pdf")
                }
                val uriOut = androidx.core.content.FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", saved)
                ex.mediaStudioResult = MediaStudioOutput(uriOut, saved.name, "application/pdf", saved.parentFile?.absolutePath ?: "Documents")
                ex.reload()
            } catch (e: Exception) {
                ex.message = "Impossible d'enregistrer le PDF dans ce dossier"
            }
        }
    }

    val req = ex.extraitRequest
    LaunchedEffect(req) {
        if (req == null) return@LaunchedEffect
        ex.extraitRequest = null
        when (val r = ExtraitBridge.dispatch(ctx, { launcher.launch(it) }, req)) {
            ExtraitLaunch.Launched -> { pending = req; ex.selected.clear() }
            ExtraitLaunch.NotInstalled -> ex.message = "Extrait n'est pas installé"
            is ExtraitLaunch.Failed -> ex.message = r.reason
        }
    }
}
