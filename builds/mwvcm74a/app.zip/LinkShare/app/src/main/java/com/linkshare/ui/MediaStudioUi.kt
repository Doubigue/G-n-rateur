package com.linkshare.ui

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.provider.MediaStore
import android.text.format.Formatter
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linkshare.core.Bridge
import com.linkshare.core.Bridges
import com.linkshare.core.ExternalEditor
import com.linkshare.core.MediaStudioRouter
import com.linkshare.core.StudioCommand
import com.linkshare.core.StudioContract
import com.linkshare.core.StudioFilter
import com.linkshare.core.StudioLanguage
import com.linkshare.core.StudioLaunch
import com.linkshare.core.StudioSubStyle
import com.linkshare.core.StudioTextPos
import com.linkshare.core.StudioLogoPosition
import java.io.File

// ═══════════════════════════ Types de fichiers ═══════════════════════════

internal enum class MediaKind(val emoji: String, val label: String) {
    AUDIO("🎵", "Audio"), VIDEO("🎬", "Vidéo"), IMAGE("🖼️", "Image"),
    WORD("📝", "Word"), PDF("📕", "PDF"), TEXT("📄", "Texte"), SUBTITLE("💬", "Sous-titres"), OTHER("📁", "Fichier"),
}

internal fun File.mediaKind(): MediaKind = when (extension.lowercase()) {
    "docx" -> MediaKind.WORD
    "pdf" -> MediaKind.PDF
    "txt", "md", "log" -> MediaKind.TEXT
    "srt", "vtt" -> MediaKind.SUBTITLE
    else -> when (category()) {
        Category.VIDEOS -> MediaKind.VIDEO
        Category.MUSIC -> MediaKind.AUDIO
        Category.PHOTOS -> MediaKind.IMAGE
        else -> MediaKind.OTHER
    }
}

/** Couleur d'accent d'un type de fichier (suit le thème de LinkShare). */
private fun MediaKind.accent(): Color = when (this) {
    MediaKind.AUDIO -> LS.Purple
    MediaKind.VIDEO -> LS.Red
    MediaKind.IMAGE -> LS.Pink
    MediaKind.WORD -> LS.Blue
    MediaKind.PDF -> LS.Orange
    MediaKind.TEXT -> LS.Amber
    MediaKind.SUBTITLE -> LS.Amber
    MediaKind.OTHER -> LS.Teal
}

/** Vrai si la feuille « Studio » doit être proposée pour cette sélection. Un fichier seul : toujours. */
internal fun studioRelevant(files: List<File>): Boolean {
    if (!Bridges.shown(Bridge.STUDIO) && !Bridges.shown(Bridge.EDITOR)) return false
    if (files.isEmpty() || files.any { it.isDirectory }) return false
    if (files.size == 1) return true
    val kinds = files.map { it.mediaKind() }
    return kinds.all { it == MediaKind.VIDEO } || kinds.all { it == MediaKind.IMAGE } ||
        (files.size == 2 && kinds.count { it == MediaKind.VIDEO } == 1 && kinds.count { it == MediaKind.AUDIO } == 1) ||
        (files.size == 2 && kinds.count { it == MediaKind.VIDEO } == 1 && kinds.count { it == MediaKind.SUBTITLE } == 1)
}

// ═══════════════════════════ Modèle d'actions (pur, sans Compose) ═══════════════════════════

internal class StudioRow(
    val emoji: String, val tint: Color, val title: String, val subtitle: String,
    /** true : nécessite MediaStudio (grisé s'il n'est pas installé). */
    val needsStudio: Boolean = true,
    val onClick: () -> Unit,
)

internal class StudioChip(val label: String, val swatch: Color? = null, val onClick: () -> Unit)

internal class StudioSection(
    val emoji: String, val title: String, val rows: List<StudioRow> = emptyList(),
    val chipsTitle: String = "", val chips: List<StudioChip> = emptyList(),
)

private fun times(f: Float) = "×" + f.toString().trimEnd('0').trimEnd('.').replace('.', ',')

/**
 * Liste dynamique des actions selon le type des fichiers et leur nombre.
 * [run] envoie une commande à MediaStudio ; [edit] ouvre « Modifier avec… » ; [askText] demande le texte à incruster.
 */
internal fun buildStudioSections(
    files: List<File>, run: (StudioCommand) -> Unit, edit: (File) -> Unit, askText: () -> Unit,
    askLogo: () -> Unit = {}, frameAtMs: Long = -1L,
): List<StudioSection> = buildAllStudioSections(files, run, edit, askText, askLogo, frameAtMs).filter {
    // La section « Modifier » appartient au pont « Modifier avec… », toutes les autres au pont Media Studio
    if (it.title == "Modifier") Bridges.shown(Bridge.EDITOR) else Bridges.shown(Bridge.STUDIO)
}

private fun buildAllStudioSections(
    files: List<File>, run: (StudioCommand) -> Unit, edit: (File) -> Unit, askText: () -> Unit,
    askLogo: () -> Unit, frameAtMs: Long = -1L,
): List<StudioSection> = buildList {
    if (files.size == 1) {
        val f = files[0]
        val kind = f.mediaKind()
        val c = kind.accent()
        when (kind) {
            MediaKind.AUDIO -> {
                add(StudioSection("🎵", "Convertir", buildList {
                    if (f.extension.equals("mp3", true)) {
                        add(StudioRow("🪶", c, "Alléger le MP3", "Réencodage à 128 kbps") { run(StudioCommand.toMp3(128)) })
                    } else {
                        add(StudioRow("🎵", c, "Convertir en MP3", "192 kbps · standard") { run(StudioCommand.toMp3(192)) })
                        add(StudioRow("💎", c, "MP3 haute qualité", "320 kbps") { run(StudioCommand.toMp3(320)) })
                        add(StudioRow("🪶", c, "MP3 léger", "128 kbps · fichier réduit") { run(StudioCommand.toMp3(128)) })
                    }
                }))
                add(subtitleSection(run, video = false))
                add(StudioSection("🔊", "Volume", listOf(
                    StudioRow("🔉", c, "Plus fort ${times(1.5f)}", "Export M4A") { run(StudioCommand.volume(1.5f)) },
                    StudioRow("📢", c, "Très fort ${times(2f)}", "Export M4A") { run(StudioCommand.volume(2f)) },
                    StudioRow("🔈", c, "Plus doux ${times(0.5f)}", "Export M4A") { run(StudioCommand.volume(0.5f)) },
                )))
            }

            MediaKind.VIDEO -> {
                add(mp4Section(run, listOf(f)))
                add(subtitleSection(run, video = true))
                add(StudioSection("🎧", "Son", listOf(
                    StudioRow("🎵", LS.Purple, "Extraire l'audio", "MP3 192 kbps") { run(StudioCommand.toMp3(192)) },
                    StudioRow("🔇", c, "Retirer le son", "Vidéo muette") { run(StudioCommand.mute()) },
                    StudioRow("📢", c, "Volume ${times(1.5f)}", "Le son est conservé") { run(StudioCommand.volume(1.5f)) },
                    StudioRow("🔈", c, "Volume ${times(0.5f)}", "Le son est conservé") { run(StudioCommand.volume(0.5f)) },
                )))
                add(StudioSection("🗜️", "Compression", listOf(
                    StudioRow("🪶", LS.Amber, "Compresser 480p", "Très léger · ~1 Mbit/s") { run(StudioCommand.compress(480, 1_000_000)) },
                    StudioRow("⚖️", LS.Amber, "Compresser 720p", "Équilibré · ~2 Mbit/s") { run(StudioCommand.compress(720, 2_000_000)) },
                    StudioRow("💎", LS.Amber, "Compresser 1080p", "Haute qualité · ~4 Mbit/s") { run(StudioCommand.compress(1080, 4_000_000)) },
                )))
                add(StudioSection(
                    "🔄", "Transformer",
                    rows = listOf(
                        StudioRow("↻", LS.Teal, "Pivoter à droite", "90° dans le sens horaire") { run(StudioCommand.transform(90)) },
                        StudioRow("↺", LS.Teal, "Pivoter à gauche", "90° anti-horaire") { run(StudioCommand.transform(270)) },
                        StudioRow("🔁", LS.Teal, "Retourner", "Rotation de 180°") { run(StudioCommand.transform(180)) },
                        StudioRow("🪞", LS.Teal, "Miroir", "Inversion gauche / droite") { run(StudioCommand.transform(0, true)) },
                    ),
                    chipsTitle = "Vitesse (image et son)",
                    chips = listOf(0.5f, 0.75f, 1.5f, 2f, 4f).map { v -> StudioChip(times(v)) { run(StudioCommand.speed(v)) } },
                ))
                add(StudioSection(
                    "✨", "Effets",
                    rows = listOf(
                        StudioRow("🔤", LS.Pink, "Ajouter un texte", "Incruster un titre") { askText() },
                        StudioRow("🖼️", LS.Pink, "Ajouter un logo / image", "Choisir l'image, la taille et le coin") { askLogo() },
                        StudioRow("📸", LS.Pink, "Capturer une image", "JPG, à la position actuelle") { run(StudioCommand.frame(frameAtMs)) },
                        StudioRow("🔢", LS.Pink, "Compter les images", "Nombre total de frames de la vidéo") { run(StudioCommand.countVideoFrames()) },
                        StudioRow("🖼️", LS.Pink, "Extraire toutes les images", "Images JPEG + metadata.txt + piste audio compatible · ZIP") { run(StudioCommand.extractVideoFrames()) },
                    ),
                    chipsTitle = "Filtres",
                    chips = StudioFilter.entries.map { fl -> StudioChip(fl.label, Color(fl.swatch)) { run(StudioCommand.effect(fl)) } },
                ))
            }

            MediaKind.IMAGE -> {
                add(StudioSection("🗜️", "Optimiser", listOf(
                    StudioRow("⚖️", c, "Compresser", "Qualité 80 % · 2048 px max") { run(StudioCommand.image("AUTO", 80, 2048)) },
                    StudioRow("🪶", c, "Compresser fort", "Qualité 60 % · 1280 px max") { run(StudioCommand.image("JPG", 60, 1280)) },
                )))
                add(StudioSection(
                    "🔁", "Convertir",
                    rows = listOf(StudioRow("📄", c, "Créer un PDF", "Une page A4 par image") { run(StudioCommand.imagesToPdf()) }),
                    chipsTitle = "Convertir en",
                    chips = listOf("PNG", "JPG", "WEBP").map { fmt ->
                        StudioChip(if (fmt == "WEBP") "WebP" else fmt) { run(StudioCommand.image(fmt, 90, 6000)) }
                    },
                ))
            }

            MediaKind.WORD -> add(StudioSection("📄", "Document", listOf(
                StudioRow("📄", c, "Convertir en PDF", "Texte, styles, listes et images") { run(StudioCommand.wordToPdf()) },
            )))

            MediaKind.PDF -> add(StudioSection("📝", "Document", listOf(
                StudioRow("📝", c, "Convertir en Word", "Texte modifiable (.docx)") { run(StudioCommand.pdfToWord()) },
            )))

            MediaKind.TEXT -> add(StudioSection("📄", "Document", listOf(
                StudioRow("📄", c, "Convertir en PDF", "Mise en page A4") { run(StudioCommand.textToPdf()) },
            )))

            // Un .srt seul : rien à traiter ; l'incrustation se fait en sélectionnant aussi la vidéo
            MediaKind.SUBTITLE -> Unit

            MediaKind.OTHER -> if (f.extension.equals("zip", true)) add(StudioSection("🎞️", "Reconstruction vidéo", listOf(
                StudioRow("🎬", LS.Red, "Reconstruire une vidéo", "Lire metadata.txt, images et audio du paquet") { run(StudioCommand.rebuildVideoFromFrames()) },
            ))) else if (f.extension.equals("bin", true)) add(StudioSection("🧠", "Whisper", listOf(
                StudioRow("🧠", LS.Amber, "Installer comme modèle Whisper", "Transcription hors ligne dans Media Studio") { run(StudioCommand.importWhisperModel()) },
            )))
        }
        if (kind != MediaKind.OTHER && kind != MediaKind.SUBTITLE) add(StudioSection("✏️", "Modifier", listOf(
            StudioRow("🛠️", LS.Blue, "Modifier avec…", "Choisir une application d'édition", needsStudio = false) { edit(f) },
        )))
    } else {
        val videos = files.count { it.mediaKind() == MediaKind.VIDEO }
        val audios = files.count { it.mediaKind() == MediaKind.AUDIO }
        val images = files.count { it.mediaKind() == MediaKind.IMAGE }
        when {
            videos == files.size && videos >= 2 -> {
                add(mp4Section(run, files))
                add(StudioSection("🎞️", "Montage", listOf(
                    StudioRow("🎞️", LS.Red, "Assembler $videos vidéos", "Dans l'ordre de sélection") { run(StudioCommand.concat(false)) },
                    StudioRow("🌘", LS.Red, "Assembler avec fondu", "Fondu au noir entre les clips") { run(StudioCommand.concat(true)) },
                )))
            }

            files.size == 2 && videos == 1 && files.count { it.mediaKind() == MediaKind.SUBTITLE } == 1 -> add(StudioSection(
                "💬", "Sous-titres",
                rows = listOf(
                    StudioRow("✨", LS.Amber, "Studio sous-titres", "Aperçu sur la vidéo, retouches, style, puis incrustation") { run(StudioCommand.subtitleStudio()) },
                    StudioRow("💬", LS.Amber, "Incruster directement", "Style classique, en bas de l'image") { run(StudioCommand.burnSubtitles()) },
                ),
                chipsTitle = "Incruster avec le style",
                chips = StudioSubStyle.entries.map { st -> StudioChip(st.label, Color(st.swatch)) { run(StudioCommand.burnSubtitles(st)) } },
            ))

            files.size == 2 && videos == 1 && audios == 1 -> add(StudioSection("🎶", "Montage", listOf(
                StudioRow("🎶", LS.Purple, "Ajouter la musique", "Son d'origine conservé · musique à 80 %") { run(StudioCommand.mix(true)) },
                StudioRow("🔁", LS.Purple, "Remplacer le son", "Le son d'origine est supprimé") { run(StudioCommand.mix(false, musicVolume = 1f)) },
            )))

            images == files.size -> add(StudioSection("📚", "Documents", listOf(
                StudioRow("📚", LS.Pink, "Créer un seul PDF", "$images images, une par page") { run(StudioCommand.imagesToPdf()) },
            )))

            else -> Unit
        }
    }
}

/** Conversion en MP4 d'une ou plusieurs vidéos : chaque vidéo donne son propre fichier. */
private fun mp4Section(run: (StudioCommand) -> Unit, videos: List<File>): StudioSection {
    val many = videos.size > 1
    val allMp4 = videos.all { it.extension.equals("mp4", true) }
    return StudioSection("🎬", if (many) "Convertir en MP4 · ${videos.size} vidéos" else "Convertir en MP4", buildList {
        // « Rapide » n'apporte rien à un lot déjà entièrement en MP4
        if (!allMp4) add(StudioRow(
            "🎬", LS.Blue, if (many) "Convertir ${videos.size} vidéos en MP4" else "Convertir en MP4",
            "Rapide · sans perte quand c'est possible",
        ) { run(StudioCommand.toMp4()) })
        add(StudioRow(
            "📱", LS.Blue, if (allMp4) "Rendre compatible partout" else "MP4 compatible partout",
            "Image H.264 · son AAC",
        ) { run(StudioCommand.toMp4(compatible = true)) })
    })
}

/** Sous-titres et transcription hors ligne (Whisper dans Media Studio). */
private fun subtitleSection(run: (StudioCommand) -> Unit, video: Boolean): StudioSection = StudioSection(
    "💬", "Sous-titres · Whisper hors ligne",
    rows = buildList {
        add(StudioRow("✨", LS.Amber, "Studio sous-titres",
            if (video) "Transcrire, voir le résultat sur la vidéo, styliser, incruster" else "Transcrire, relire et corriger") {
            run(StudioCommand.subtitleStudio())
        })
        add(StudioRow("🎙️", LS.Amber, "Transcrire → SRT + TXT", "Horodatage complet · langue détectée") { run(StudioCommand.transcribe()) })
        add(StudioRow("📄", LS.Amber, "Transcrire → TXT", "Texte horodaté + texte intégral") { run(StudioCommand.transcribe(format = "TXT", alsoTxt = false)) })
        add(StudioRow("🌍", LS.Amber, "Sous-titres anglais", "Traduction automatique (SRT + TXT)") { run(StudioCommand.transcribe(translate = true)) })
    },
    chipsTitle = "Transcrire en précisant la langue (SRT + TXT)",
    chips = StudioLanguage.entries.map { l -> StudioChip(l.label) { run(StudioCommand.transcribe(language = l.code)) } },
)

// ═══════════════════════════ Feuille + gestion du résultat ═══════════════════════════

/**
 * À composer UNE fois (à côté de FileInfoSheet). Le launcher reste toujours composé : le résultat de MediaStudio
 * arrive même après la fermeture de la feuille.
 */
internal data class MediaStudioOutput(
    val uri: Uri, val name: String, val mime: String, val location: String, val summary: String? = null,
    /** Traitement par lot : tous les fichiers produits ([uri] est le premier). */
    val outputs: List<Uri> = listOf(uri),
)

/** Métadonnées du fichier renvoyé par MediaStudio (URI MediaStore). */
internal fun mediaStudioOutput(ctx: android.content.Context, uri: Uri, fallbackName: String?, summary: String? = null): MediaStudioOutput {
    var name = fallbackName?.takeIf { it.isNotBlank() } ?: "Fichier créé"
    var location = "Enregistrement MediaStore"
    runCatching {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, MediaStore.MediaColumns.RELATIVE_PATH), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (ni >= 0) name = c.getString(ni)?.takeIf { it.isNotBlank() } ?: name
                val pi = c.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH)
                if (pi >= 0) location = c.getString(pi)?.trimEnd('/')?.takeIf { it.isNotBlank() } ?: location
            }
        }
    }
    val mime = ctx.contentResolver.getType(uri) ?: "application/octet-stream"
    return MediaStudioOutput(uri, name, mime, location, summary)
}

@Composable
internal fun MediaStudioResultCard(ex: ExplorerViewModel) {
    val ctx = LocalContext.current
    val result = ex.mediaStudioResult ?: return
    AlertDialog(
        onDismissRequest = { ex.mediaStudioResult = null },
        containerColor = LS.Card2,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("✓", color = Color(0xFF35B779), fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(10.dp))
                Text("Traitement réussi", color = LS.Text, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text(result.name, color = LS.Text, fontWeight = FontWeight.SemiBold)
                result.summary?.let { Text(it, color = LS.Text, fontWeight = FontWeight.Bold) }
                val format = if (result.outputs.size > 1) result.mime.substringAfter('/').uppercase()
                else result.name.substringAfterLast('.', "Fichier").uppercase()
                Text("Format : $format", color = LS.Muted, fontSize = 12.sp)
                Text("Emplacement : ${result.location}", color = LS.Muted, fontSize = 12.sp)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val view = Intent(Intent.ACTION_VIEW).setDataAndType(result.uri, result.mime)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                runCatching { ctx.startActivity(view) }.onFailure { ex.message = "Aucune application ne peut ouvrir ce fichier" }
            }) { Text(if (result.outputs.size > 1) "Ouvrir la 1re" else "Ouvrir") }
        },
        dismissButton = {
            Row {
                TextButton(onClick = {
                    val send = if (result.outputs.size > 1) Intent(Intent.ACTION_SEND_MULTIPLE)
                        .putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(result.outputs))
                    else Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, result.uri)
                    send.setType(result.mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    // ClipData : la permission de lecture suit chaque fichier vers l'appli choisie
                    send.clipData = android.content.ClipData.newRawUri("", result.outputs.first()).also { c ->
                        result.outputs.drop(1).forEach { c.addItem(android.content.ClipData.Item(it)) }
                    }
                    runCatching { ctx.startActivity(Intent.createChooser(send, "Partager le résultat")) }
                }) { Text("Partager") }
                TextButton(onClick = { ex.mediaStudioResult = null }) { Text("Fermer") }
            }
        },
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun MediaActionsHost(ex: ExplorerViewModel) {
    val ctx = LocalContext.current
    var logoDialog by remember { mutableStateOf(false) }
    var logoScale by remember { mutableFloatStateOf(0.18f) }
    var logoPosition by remember { mutableStateOf(StudioLogoPosition.TOP_RIGHT) }
    var pendingLogoVideo by remember { mutableStateOf<File?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        when (r.resultCode) {
            Activity.RESULT_OK -> {
                val uri = r.data?.data
                val name = r.data?.getStringExtra(StudioContract.EXTRA_OUTPUT_NAME)
                val summary = r.data?.getStringExtra(StudioContract.EXTRA_OUTPUT_SUMMARY)
                val clip = r.data?.clipData
                val all = clip?.let { c -> (0 until c.itemCount).mapNotNull { c.getItemAt(it).uri } }.orEmpty()
                if (uri != null) ex.mediaStudioResult = mediaStudioOutput(ctx, uri, name, summary).let { out ->
                    // Lot : le nom reçu est le titre du lot, pas celui du premier fichier
                    if (all.size > 1) out.copy(name = name ?: "${all.size} fichiers créés", outputs = all) else out
                }
                else ex.message = summary ?: "Traitement terminé"
                ex.reload() // actualise les fichiers après le retour de MediaStudio
            }
            else -> r.data?.getStringExtra(StudioContract.EXTRA_ERROR)?.let { ex.message = "Media Studio : $it" }
        }
    }

    val logoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val video = pendingLogoVideo
        if (uri != null && video != null) {
            val copied = runCatching {
                val ext = (ctx.contentResolver.getType(uri)?.substringAfter('/') ?: "png").substringBefore(';').let { if (it == "jpeg") "jpg" else it }
                val target = File(ctx.cacheDir, "studio_logo_${System.currentTimeMillis()}.$ext")
                ctx.contentResolver.openInputStream(uri)?.use { input -> target.outputStream().use { output -> input.copyTo(output) } }
                target
            }.getOrNull()
            if (copied != null && copied.length() > 0L) {
                ex.studioFiles = emptyList()
                val cmd = StudioCommand.logo(logoScale, logoPosition)
                when (val result = MediaStudioRouter.dispatch(ctx, { launcher.launch(it) }, cmd, listOf(video, copied))) {
                    StudioLaunch.Launched -> ex.selected.clear()
                    StudioLaunch.NotInstalled -> ex.message = "Media Studio n'est pas installé"
                    is StudioLaunch.Failed -> ex.message = result.reason
                }
            } else ex.message = "Impossible de lire cette image"
        }
        pendingLogoVideo = null
    }

    // Depuis la pastille du lecteur vidéo, ouvrir directement les réglages du logo (sans afficher la feuille Studio).
    val directLogoVideo = ex.studioLogoRequest
    LaunchedEffect(directLogoVideo) {
        if (directLogoVideo != null) {
            pendingLogoVideo = directLogoVideo
            logoDialog = true
            ex.studioLogoRequest = null
        }
    }

    // Commandes venant du cadre « Studio » de l'écran Action : le launcher reste ici, toujours composé
    val request = ex.studioRequest
    LaunchedEffect(request) {
        if (request == null) return@LaunchedEffect
        ex.studioRequest = null
        when (val r = MediaStudioRouter.dispatch(ctx, { launcher.launch(it) }, request.cmd, request.files)) {
            StudioLaunch.Launched -> ex.selected.clear()
            StudioLaunch.NotInstalled -> ex.message = "Media Studio n'est pas installé"
            is StudioLaunch.Failed -> ex.message = r.reason
        }
    }

    MediaStudioResultCard(ex)
    val files = ex.studioFiles
    val installed = remember { MediaStudioRouter.isInstalled(ctx) }
    var textDialog by remember { mutableStateOf(false) }
    fun close() { ex.studioFiles = emptyList() }

    fun runCmd(cmd: StudioCommand) {
        val target = files
        close()
        when (val r = MediaStudioRouter.dispatch(ctx, { launcher.launch(it) }, cmd, target)) {
            StudioLaunch.Launched -> ex.selected.clear()
            StudioLaunch.NotInstalled -> ex.message = "Media Studio n'est pas installé"
            is StudioLaunch.Failed -> ex.message = r.reason
        }
    }

    fun editFile(f: File) {
        close()
        ExternalEditor.edit(ctx, f)?.let { ex.message = it }
    }

    val sections = remember(files) { buildStudioSections(files, ::runCmd, ::editFile, askText = { textDialog = true }, askLogo = { pendingLogoVideo = files.singleOrNull(); logoDialog = true }) }

    if (files.isNotEmpty()) ModalBottomSheet(
        onDismissRequest = ::close,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = LS.Sheet, contentColor = LS.Text,
    ) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).navigationBarsPadding()
                .padding(horizontal = 16.dp).padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            StudioHero(files, installed)
            if (sections.isEmpty()) {
                val ext = files.singleOrNull()?.extension?.lowercase()
                Text(
                    when {
                        files.size > 1 -> "Pour plusieurs fichiers : sélectionnez au moins deux vidéos (conversion MP4 ou assemblage), une vidéo et une musique (mixage), une vidéo et son .srt (sous-titres) ou plusieurs images (PDF)."
                        files.singleOrNull()?.mediaKind() == MediaKind.SUBTITLE -> "Pour incruster ces sous-titres, sélectionnez-les avec la vidéo correspondante."
                        ext == "doc" || ext == "odt" || ext == "rtf" -> "Seul le format .docx est pris en charge : enregistrez ce document en .docx pour le convertir."
                        else -> "Media Studio traite l'audio, la vidéo, les images et les documents Word, PDF et texte : ce type de fichier n'est pas pris en charge."
                    },
                    Modifier.padding(8.dp), color = LS.Muted, fontSize = 13.sp,
                )
            }
            sections.forEach { s -> SectionBlock(s, installed) }
        }
    }

    if (textDialog) TextOverlayDialog(
        onDismiss = { textDialog = false },
        onConfirm = { text, pos -> textDialog = false; runCmd(StudioCommand.effect(null, text, pos)) },
    )
    if (logoDialog) LogoOverlayDialog(
        scale = logoScale, onScale = { logoScale = it }, position = logoPosition,
        onPosition = { logoPosition = it }, onDismiss = { logoDialog = false },
        onChoose = { logoDialog = false; logoPicker.launch(arrayOf("image/*")) },
    )
}

/** Une commande Studio en attente d'envoi (émise par le cadre « Studio » de l'écran Action). */
internal class StudioRequest(val cmd: StudioCommand, val files: List<File>)

/**
 * Menu Studio affiché directement dans l'écran « Action », dans son propre cadre « Studio »
 * (réglage Paramètres › Fichiers › « Studio dans le menu Action »). N'affiche rien si Studio ne traite pas ces fichiers.
 */
@Composable
internal fun StudioPanel(ex: ExplorerViewModel, files: List<File>, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val installed = remember { MediaStudioRouter.isInstalled(ctx) }
    var textDialog by remember { mutableStateOf(false) }
    var logoDialog by remember { mutableStateOf(false) }
    var logoScale by remember { mutableFloatStateOf(0.18f) }
    var logoPosition by remember { mutableStateOf(StudioLogoPosition.TOP_RIGHT) }
    val logoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val copied = runCatching {
                val ext = (ctx.contentResolver.getType(uri)?.substringAfter('/') ?: "png").substringBefore(';').let { if (it == "jpeg") "jpg" else it }
                val target = File(ctx.cacheDir, "studio_logo_${System.currentTimeMillis()}.$ext")
                ctx.contentResolver.openInputStream(uri)?.use { input -> target.outputStream().use { output -> input.copyTo(output) } }
                target
            }.getOrNull()
            if (copied != null && copied.length() > 0L) {
                onClose()
                ex.studioRequest = StudioRequest(StudioCommand.logo(logoScale, logoPosition), files + copied)
            }
            else ex.message = "Impossible de lire cette image"
        }
    }

    fun runCmd(cmd: StudioCommand) {
        onClose()
        ex.studioRequest = StudioRequest(cmd, files)
    }
    fun editFile(f: File) {
        onClose()
        ExternalEditor.edit(ctx, f)?.let { ex.message = it }
    }

    val sections = remember(files) { buildStudioSections(files, ::runCmd, ::editFile, askText = { textDialog = true }, askLogo = { logoDialog = true }) }
    if (sections.isEmpty()) return

    Column(
        Modifier.fillMaxWidth().lsCard(RoundedCornerShape(UiStyle.r(20.dp))).padding(horizontal = 12.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(Modifier.padding(start = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Ic.Animation, null, Modifier.size(18.dp), tint = LS.Purple)
            Spacer(Modifier.width(8.dp))
            Text("Studio", Modifier.weight(1f), color = LS.Purple, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text(
                if (installed) "● Media Studio prêt" else "○ Media Studio non installé",
                color = LS.Muted, fontSize = 11.sp,
            )
        }
        sections.forEach { s -> SectionBlock(s, installed) }
    }

    if (textDialog) TextOverlayDialog(
        onDismiss = { textDialog = false },
        onConfirm = { text, pos -> textDialog = false; runCmd(StudioCommand.effect(null, text, pos)) },
    )
    if (logoDialog) LogoOverlayDialog(
        scale = logoScale, onScale = { logoScale = it }, position = logoPosition,
        onPosition = { logoPosition = it }, onDismiss = { logoDialog = false },
        onChoose = { logoDialog = false; logoPicker.launch(arrayOf("image/*")) },
    )
}

// ═══════════════════════════ Composants stylés ═══════════════════════════

@Composable
private fun StudioHero(files: List<File>, installed: Boolean) {
    val ctx = LocalContext.current
    val single = files.singleOrNull()
    val kind = single?.mediaKind() ?: MediaKind.VIDEO
    val c = kind.accent()
    val emoji = if (single != null) kind.emoji else "🎞️"
    val title = single?.name ?: "${files.size} fichiers sélectionnés"
    val size = Formatter.formatShortFileSize(ctx, files.sumOf { it.length() })
    val ext = single?.extension?.uppercase()?.takeIf { it.isNotEmpty() }

    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
            .background(Brush.linearGradient(listOf(c, lerp(c, Color.Black, 0.45f))))
    ) {
        Box(Modifier.align(Alignment.TopEnd).offset(x = 36.dp, y = (-36).dp).size(130.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.10f)))
        Box(Modifier.align(Alignment.BottomEnd).offset(x = (-60).dp, y = 40.dp).size(80.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.07f)))
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(58.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.22f)), contentAlignment = Alignment.Center) {
                    Text(emoji, fontSize = 30.sp)
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(
                        if (single != null) kind.label else "Sélection multiple",
                        color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp,
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                HeroPill(size)
                ext?.let { HeroPill(it) }
                HeroPill(if (installed) "● Media Studio prêt" else "○ Non installé")
            }
        }
    }
}

@Composable
private fun HeroPill(text: String) {
    Text(
        text, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Medium,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.20f)).padding(horizontal = 10.dp, vertical = 4.dp),
    )
}

@Composable
private fun SectionBlock(s: StudioSection, installed: Boolean) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.padding(start = 4.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(s.emoji, fontSize = 15.sp)
            Spacer(Modifier.width(8.dp))
            Text(s.title, color = LS.Text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
        s.rows.chunked(2).forEach { pair ->
            Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                pair.forEach { row ->
                    StudioCard(row, enabled = installed || !row.needsStudio, modifier = Modifier.weight(1f).fillMaxHeight())
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        if (s.chips.isNotEmpty()) {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(LS.Card)
                    .border(1.dp, LS.Line, RoundedCornerShape(20.dp)).padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                if (s.chipsTitle.isNotEmpty()) Text(s.chipsTitle, color = LS.Muted, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    s.chips.forEach { ChipItem(it, installed) }
                }
            }
        }
    }
}

@Composable
private fun StudioCard(row: StudioRow, enabled: Boolean, modifier: Modifier) {
    val shape = RoundedCornerShape(22.dp)
    Column(
        modifier.clip(shape)
            .background(Brush.linearGradient(listOf(row.tint.copy(alpha = 0.22f), row.tint.copy(alpha = 0.06f))))
            .border(1.dp, row.tint.copy(alpha = 0.35f), shape)
            .alpha(if (enabled) 1f else 0.4f)
            .clickable(enabled = enabled, onClick = row.onClick)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Box(
            Modifier.size(44.dp).clip(RoundedCornerShape(14.dp))
                .background(Brush.linearGradient(listOf(row.tint, lerp(row.tint, Color.Black, 0.35f)))),
            contentAlignment = Alignment.Center,
        ) { Text(row.emoji, fontSize = 22.sp) }
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(row.title, color = LS.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(row.subtitle, color = LS.Muted, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun ChipItem(chip: StudioChip, installed: Boolean) {
    val shape = RoundedCornerShape(50)
    Row(
        Modifier.clip(shape).background(LS.Card2).border(1.dp, LS.Line, shape)
            .alpha(if (installed) 1f else 0.4f)
            .clickable(enabled = installed, onClick = chip.onClick)
            .padding(horizontal = 14.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        chip.swatch?.let {
            Box(Modifier.size(12.dp).clip(CircleShape).background(it).border(1.dp, Color.White.copy(alpha = 0.5f), CircleShape))
            Spacer(Modifier.width(8.dp))
        }
        Text(chip.label, color = LS.Text, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LogoOverlayDialog(
    scale: Float, onScale: (Float) -> Unit, position: StudioLogoPosition,
    onPosition: (StudioLogoPosition) -> Unit, onDismiss: () -> Unit, onChoose: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss, shape = RoundedCornerShape(28.dp),
        title = { Text("🖼️  Ajouter un logo / image") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Position du logo", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StudioLogoPosition.entries.forEach { p -> FilterChip(position == p, { onPosition(p) }, label = { Text(p.label) }) }
                }
                Text("Taille : ${(scale * 100).toInt()} %", style = MaterialTheme.typography.labelLarge)
                Slider(value = scale, onValueChange = onScale, valueRange = 0.08f..0.45f)
                Text("Le logo sera incrusté sur toute la durée de la vidéo.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = { TextButton(onClick = onChoose) { Text("Choisir l'image") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TextOverlayDialog(onDismiss: () -> Unit, onConfirm: (String, StudioTextPos) -> Unit) {
    var text by remember { mutableStateOf("") }
    var pos by remember { mutableStateOf(StudioTextPos.BOTTOM) }
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(28.dp),
        title = { Text("🔤  Ajouter un texte") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(text, { text = it.take(120) }, label = { Text("Texte") }, singleLine = true, shape = RoundedCornerShape(16.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StudioTextPos.entries.forEach { p -> FilterChip(pos == p, { pos = p }, label = { Text(p.label) }) }
                }
            }
        },
        confirmButton = { TextButton(enabled = text.isNotBlank(), onClick = { onConfirm(text.trim(), pos) }) { Text("Appliquer") } },
        dismissButton = { TextButton(onDismiss) { Text("Annuler") } },
    )
}
