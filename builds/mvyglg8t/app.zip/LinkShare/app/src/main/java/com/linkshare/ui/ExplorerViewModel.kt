package com.linkshare.ui

import android.app.Application
import android.content.ActivityNotFoundException
import android.content.ContentResolver
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import androidx.compose.runtime.*
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.*
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

data class LItem(val file: File, val isDir: Boolean, val size: Long, val modified: Long, val count: Int)

/** Copie ou déplacement en attente : les éléments sont choisis, il reste à désigner le dossier de destination. */
data class PendingTransfer(val files: List<File>, val move: Boolean)

enum class SortKey(val label: String) { NAME("Nom"), DATE("Date"), SIZE("Taille"), TYPE("Type") }

enum class LCat(val label: String) {
    IMAGES("Images"), VIDEOS("Vidéos"), AUDIO("Audio"), DOCS("Documents"), ARCHIVES("Archives"),
}

/** Le coffre n'est ouvert qu'après le déverrouillage du téléphone, et se referme dès que l'app quitte l'écran. */
object VaultLock { var unlocked by mutableStateOf(false) }

/** Compteur incrémenté à chaque retour dans l'app (rafraîchit permissions et listes). */
object AppEvents { var resumeTick by mutableIntStateOf(0) }

internal val VIEW_IMG = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp")
internal val VIEW_TXT = setOf("txt", "md", "csv", "log", "json", "xml", "ini", "conf", "yml", "yaml", "srt")
private val ARCHIVE_EXT = setOf("zip", "rar", "7z", "tar", "gz")
private val DOC_EXT = listOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "odt", "csv", "rtf")

internal fun File.isArchive() = extension.lowercase() in ARCHIVE_EXT

class ExplorerViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx get() = getApplication<Application>()

    val root: File = Environment.getExternalStorageDirectory()
    val vaultDir: File get() = File(ctx.filesDir, "vault").apply { mkdirs() }

    var dir by mutableStateOf(root)
    var category by mutableStateOf<LCat?>(null)
    var query by mutableStateOf("")
    var items by mutableStateOf<List<LItem>>(emptyList())
    var recents by mutableStateOf<List<File>>(emptyList())
    var vaultItems by mutableStateOf<List<LItem>>(emptyList())
    var sort by mutableStateOf(SortKey.NAME)
    var ascending by mutableStateOf(true)
    var grid by mutableStateOf(true)
    var loading by mutableStateOf(false)
    var busy by mutableStateOf<String?>(null)
    var message by mutableStateOf<String?>(null)
    var viewing by mutableStateOf<File?>(null)
    var zipPrompt by mutableStateOf<File?>(null)
    /** Fichiers « frères » du fichier ouvert (même type) : on passe de l'un à l'autre en balayant. */
    var viewList by mutableStateOf<List<File>>(emptyList())
    /** Non nul = le sélecteur de dossier de destination est affiché. */
    var transfer by mutableStateOf<PendingTransfer?>(null)
    val selected = mutableStateListOf<String>()

    /** Point d'entrée de l'explorateur : le « retour » s'arrête ici et ramène à l'accueil. */
    var base by mutableStateOf(root)
    /** Vrai quand la liste affichée est celle des favoris. */
    var favMode by mutableStateOf(false)
    /** Taille occupée par catégorie (dl, img, vid, aud, doc), affichée sur l'accueil. */
    var sizes by mutableStateOf<Map<String, Long>>(emptyMap())
    val favorites = mutableStateListOf<String>()

    private val prefs get() = ctx.getSharedPreferences("linkshare", Context.MODE_PRIVATE)

    init { favorites.addAll(prefs.getStringSet("favs", emptySet()).orEmpty()) }

    private var loadJob: Job? = null
    private var searchJob: Job? = null

    val canGoUp get() = query.isNotEmpty() || category != null || dir.path != base.path

    // ───────────────────────────── Navigation ─────────────────────────────

    fun refresh() { reload(); loadRecents() }

    fun openDir(d: File) { category = null; query = ""; if (favMode) base = d; favMode = false; dir = d; reload() }

    fun openCategory(c: LCat) { favMode = false; category = c; query = ""; reload() }

    /** Entrées depuis l'accueil : le dossier choisi devient le point d'entrée. */
    fun enter(d: File) { favMode = false; base = d; openDir(d) }
    fun enterCategory(c: LCat) = openCategory(c)
    fun enterFavorites() { category = null; query = ""; selected.clear(); favMode = true; reload() }

    /** Remonte d'un cran ; false = on est au point d'entrée (retour à l'accueil). */
    fun back(): Boolean = when {
        selected.isNotEmpty() -> { selected.clear(); true }
        query.isNotEmpty() -> { query = ""; reload(); true }
        favMode || category != null -> false
        dir.path != base.path -> { dir = dir.parentFile ?: base; reload(); true }
        else -> false
    }

    fun leave() { favMode = false; category = null; query = ""; selected.clear() }

    fun up() {
        when {
            query.isNotEmpty() -> { query = ""; reload() }
            category != null -> { category = null; reload() }
            dir.path != base.path -> { dir = dir.parentFile ?: base; reload() }
        }
    }

    fun updateQuery(q: String) {
        query = q
        searchJob?.cancel()
        searchJob = viewModelScope.launch { if (q.isNotBlank()) delay(300); reload() }
    }

    fun reload() {
        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            loading = true
            val d = dir; val q = query.trim(); val cat = category; val fav = favMode; val favs = favorites.toList()
            val res = try {
                withContext(Dispatchers.IO) {
                    when {
                        fav -> favs.map { File(it) }.filter { it.exists() }.map { it.toItem() }.filter { q.isEmpty() || it.file.name.contains(q, true) }
                        cat != null -> byCategory(cat).filter { q.isEmpty() || it.name.contains(q, true) }.map { it.toItem() }
                        q.isNotEmpty() -> search(d, q)
                        else -> d.listFiles().orEmpty().filter { !it.name.startsWith(".") }.map { it.toItem() }
                    }
                }
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { message = e.message ?: e.toString(); emptyList() }
            items = sortItems(res)
            selected.clear()
            loading = false
        }
    }

    fun loadRecents() {
        viewModelScope.launch {
            recents = withContext(Dispatchers.IO) {
                try {
                    queryFiles("${MediaStore.Files.FileColumns.SIZE} > 0 AND ${MediaStore.Files.FileColumns.MIME_TYPE} IS NOT NULL", 150).take(15)
                } catch (e: Exception) { emptyList() }
            }
        }
    }

    // ───────────────────────────── Favoris & tailles ─────────────────────────────

    private fun saveFavs() { prefs.edit().putStringSet("favs", favorites.toSet()).apply() }

    fun favoriteSelected() {
        val paths = selected.toList()
        if (paths.isEmpty()) return
        val all = paths.all { it in favorites }
        if (all) favorites.removeAll(paths.toSet()) else paths.forEach { if (it !in favorites) favorites.add(it) }
        saveFavs()
        message = if (all) "Retiré des favoris" else "Ajouté aux favoris"
        selected.clear()
        if (favMode) reload()
    }

    fun toggleFavorite(f: File) {
        val had = favorites.remove(f.path)
        if (!had) favorites.add(f.path)
        saveFavs()
        message = if (had) "Retiré des favoris" else "Ajouté aux favoris"
    }

    private fun docSelection(): String {
        val name = MediaStore.Files.FileColumns.DISPLAY_NAME
        return DOC_EXT.joinToString(" OR ", "(", ")") { "LOWER($name) LIKE '%.$it'" }
    }

    fun loadSizes() {
        viewModelScope.launch {
            sizes = withContext(Dispatchers.IO) {
                fun sum(uri: Uri, sel: String? = null): Long {
                    var t = 0L
                    try {
                        ctx.contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.SIZE), sel, null, null)?.use { c ->
                            while (c.moveToNext()) t += c.getLong(0)
                        }
                    } catch (_: Exception) {}
                    return t
                }
                val dl = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                mapOf(
                    "dl" to dl.walkTopDown().filter { it.isFile }.sumOf { it.length() },
                    "img" to sum(MediaStore.Images.Media.EXTERNAL_CONTENT_URI),
                    "vid" to sum(MediaStore.Video.Media.EXTERNAL_CONTENT_URI),
                    "aud" to sum(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI),
                    "doc" to sum(MediaStore.Files.getContentUri("external"), docSelection()),
                )
            }
        }
    }

    // ───────────────────────────── Tri ─────────────────────────────

    fun changeSort(k: SortKey) { sort = k; items = sortItems(items) }
    fun toggleOrder() { ascending = !ascending; items = sortItems(items) }

    private fun sortItems(l: List<LItem>): List<LItem> {
        val cmp: Comparator<LItem> = when (sort) {
            SortKey.NAME -> compareBy<LItem> { it.file.name.lowercase() }
            SortKey.DATE -> compareBy<LItem> { it.modified }
            SortKey.SIZE -> compareBy<LItem> { if (it.isDir) it.count.toLong() else it.size }
            SortKey.TYPE -> compareBy<LItem>({ it.file.extension.lowercase() }, { it.file.name.lowercase() })
        }
        val c = if (ascending) cmp else cmp.reversed()
        return l.sortedWith(compareByDescending<LItem> { it.isDir }.then(c))
    }

    // ───────────────────────────── Lecture disque ─────────────────────────────

    private fun File.toItem() = LItem(this, isDirectory, if (isDirectory) 0L else length(), lastModified(), if (isDirectory) (list()?.size ?: 0) else 0)

    /** Recherche récursive (largeur d'abord) dans le dossier courant, limitée à 300 résultats. */
    private suspend fun search(base: File, q: String): List<LItem> {
        val out = ArrayList<LItem>()
        val queue = ArrayList<File>().apply { add(base) }
        var i = 0
        while (i < queue.size && out.size < 300) {
            currentCoroutineContext().ensureActive()
            val kids = queue[i++].listFiles() ?: continue
            for (k in kids) {
                if (k.name.startsWith(".")) continue
                if (k.name.contains(q, ignoreCase = true) && out.size < 300) out += k.toItem()
                if (k.isDirectory) queue.add(k)
            }
        }
        return out
    }

    private fun queryFiles(selection: String, limit: Int): List<File> {
        val b = Bundle().apply {
            putString(ContentResolver.QUERY_ARG_SQL_SELECTION, selection)
            putStringArray(ContentResolver.QUERY_ARG_SORT_COLUMNS, arrayOf(MediaStore.Files.FileColumns.DATE_MODIFIED))
            putInt(ContentResolver.QUERY_ARG_SORT_DIRECTION, ContentResolver.QUERY_SORT_DIRECTION_DESCENDING)
            putInt(ContentResolver.QUERY_ARG_LIMIT, limit)
        }
        val out = ArrayList<File>()
        ctx.contentResolver.query(
            MediaStore.Files.getContentUri("external"), arrayOf(MediaStore.Files.FileColumns.DATA), b, null,
        )?.use { c ->
            while (c.moveToNext()) {
                val p = c.getString(0) ?: continue
                if (p.contains("/.") || p.contains("/Android/")) continue
                val f = File(p)
                if (f.isFile) out += f
            }
        }
        return out
    }

    private fun byCategory(c: LCat): List<File> {
        val col = MediaStore.Files.FileColumns.MIME_TYPE
        val name = MediaStore.Files.FileColumns.DISPLAY_NAME
        fun exts(l: Collection<String>) = l.joinToString(" OR ", "(", ")") { "LOWER($name) LIKE '%.$it'" }
        val sel = when (c) {
            LCat.IMAGES -> "$col LIKE 'image/%'"
            LCat.VIDEOS -> "$col LIKE 'video/%'"
            LCat.AUDIO -> "$col LIKE 'audio/%'"
            LCat.DOCS -> exts(DOC_EXT)
            LCat.ARCHIVES -> exts(ARCHIVE_EXT)
        }
        return queryFiles(sel, 500)
    }

    // ───────────────────────────── Ouverture ─────────────────────────────

    /** 0 = image, 1 = vidéo, 2 = audio, 3 = texte : on ne balaie qu'entre fichiers du même type. */
    private fun viewKind(f: File): Int {
        val e = f.extension.lowercase()
        return when {
            e in VIEW_IMG -> 0
            categoryOfExt(e) == Category.VIDEOS -> 1
            categoryOfExt(e) == Category.MUSIC -> 2
            else -> 3
        }
    }

    /** Liste dans laquelle on balaie : celle d'où vient le fichier (liste affichée, coffre ou récents), même type seulement. */
    private fun siblingsOf(f: File, from: List<File>?): List<File> {
        val kind = viewKind(f)
        if (kind == 3) return listOf(f)
        val src = from ?: listOf(items.map { it.file }, vaultItems.map { it.file }).firstOrNull { l -> l.any { it.path == f.path } }
        val list = src?.filter { !it.isDirectory && viewKind(it) == kind }.orEmpty()
        return if (list.any { it.path == f.path }) list else listOf(f)
    }

    fun open(f: File, siblings: List<File>? = null) {
        val e = f.extension.lowercase()
        val cat = categoryOfExt(e)
        when {
            f.isDirectory ->
                if (f.path.startsWith(vaultDir.path)) message = "Restaure ce dossier pour l'ouvrir" else openDir(f)
            e in VIEW_IMG || e in VIEW_TXT || cat == Category.VIDEOS || cat == Category.MUSIC -> {
                viewList = siblingsOf(f, siblings)
                viewing = f
            }
            e == "zip" -> zipPrompt = f
            else -> external(f)
        }
    }

    fun external(f: File) {
        try {
            val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
            ctx.startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: ActivityNotFoundException) {
            message = "Aucune application pour ouvrir ce fichier"
        } catch (e: Exception) {
            message = e.message ?: e.toString()
        }
    }

    // ───────────────────────────── Sélection ─────────────────────────────

    fun toggle(path: String) { if (!selected.remove(path)) selected.add(path) }
    fun selectAll(list: List<LItem>) { selected.clear(); selected.addAll(list.map { it.file.path }) }
    private fun picked(list: List<LItem>) = list.filter { it.file.path in selected }.map { it.file }

    // ───────────────────────────── Travaux (IO) ─────────────────────────────

    private fun work(label: String, block: () -> String) {
        viewModelScope.launch {
            busy = label
            try { message = withContext(Dispatchers.IO) { block() }.ifEmpty { null } }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { message = e.message ?: e.toString() }
            busy = null
            reload(); loadRecents()
            if (VaultLock.unlocked) loadVault()
        }
    }

    private fun stamp() = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    private fun unique(f: File): File {
        if (!f.exists()) return f
        val ext = f.extension.let { if (it.isEmpty()) "" else ".$it" }
        return generateSequence(1) { it + 1 }
            .map { File(f.parentFile, "${f.nameWithoutExtension} ($it)$ext") }
            .first { !it.exists() }
    }

    /** Partage via le menu Android. Les dossiers sont envoyés sous forme d'archive ZIP. */
    fun shareSelected() { val f = picked(items); selected.clear(); shareFiles(f) }

    fun shareFiles(files: List<File>) {
        if (files.isEmpty()) return
        work("Préparation du partage…") {
            val cache = File(ctx.cacheDir, "share").apply { deleteRecursively(); mkdirs() }
            val srcs = files.map { f ->
                if (f.isDirectory) unique(File(cache, f.name + ".zip")).also { z -> writeZip(listOf(f), z) { n -> busy = "Compression · $n" } } else f
            }
            val uris = srcs.map { FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", it) }
            val intent = if (uris.size == 1) {
                val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(srcs[0].extension.lowercase()) ?: "*/*"
                Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, uris[0])
            } else {
                Intent(Intent.ACTION_SEND_MULTIPLE).setType("*/*").putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
            }
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            intent.clipData = ClipData.newRawUri("", uris[0]).also { c -> uris.drop(1).forEach { c.addItem(ClipData.Item(it)) } }
            ctx.startActivity(Intent.createChooser(intent, "Partager").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            if (files.any { it.isDirectory }) "Les dossiers sont envoyés en archive ZIP" else ""
        }
    }

    fun compressSelected() {
        val files = picked(items)
        if (files.isEmpty()) return
        val parent = files.first().parentFile ?: return
        val dest = unique(File(parent, if (files.size == 1) files[0].name + ".zip" else "Archive_${stamp()}.zip"))
        selected.clear()
        work("Compression…") {
            writeZip(files, dest) { busy = "Compression · $it" }
            "Archive créée : ${dest.name}"
        }
    }

    fun extract(archive: File) {
        val target = unique(File(archive.parentFile, archive.nameWithoutExtension))
        work("Décompression…") {
            readZip(archive, target) { busy = "Décompression · $it" }
            "Décompressé dans « ${target.name} »"
        }
    }

    fun deleteSelected() {
        val files = picked(items)
        selected.clear()
        work("Suppression…") {
            var n = 0
            files.forEach { if (it.deleteRecursively()) n++ }
            "$n élément(s) supprimé(s)"
        }
    }

    private fun writeZip(sources: List<File>, dest: File, onFile: (String) -> Unit) {
        val destPath = dest.canonicalPath
        ZipOutputStream(BufferedOutputStream(FileOutputStream(dest))).use { z ->
            fun add(f: File, name: String) {
                if (f.canonicalPath == destPath) return
                if (f.isDirectory) {
                    z.putNextEntry(ZipEntry("$name/")); z.closeEntry()
                    f.listFiles()?.forEach { add(it, "$name/${it.name}") }
                } else {
                    onFile(f.name)
                    z.putNextEntry(ZipEntry(name).apply { time = f.lastModified() })
                    FileInputStream(f).use { it.copyTo(z, 64 * 1024) }
                    z.closeEntry()
                }
            }
            sources.forEach { add(it, it.name) }
        }
    }

    /** Décompression protégée contre les chemins « ../ » (zip-slip). */
    private fun readZip(archive: File, target: File, onFile: (String) -> Unit) {
        target.mkdirs()
        val base = target.canonicalPath + File.separator
        ZipInputStream(BufferedInputStream(FileInputStream(archive))).use { zin ->
            var next: ZipEntry? = zin.nextEntry
            while (next != null) {
                val entry: ZipEntry = next
                val out = File(target, entry.name).canonicalFile
                if (out.path.startsWith(base)) {
                    if (entry.isDirectory) out.mkdirs()
                    else {
                        out.parentFile?.mkdirs()
                        onFile(out.name)
                        FileOutputStream(out).use { zin.copyTo(it, 64 * 1024) }
                    }
                }
                zin.closeEntry()
                next = zin.nextEntry
            }
        }
    }

    // ───────────────────────────── Copier / déplacer ─────────────────────────────

    /** Ouvre le sélecteur de dossier pour copier (move = false) ou déplacer (move = true) la sélection. */
    fun startTransfer(move: Boolean) {
        val files = picked(items)
        if (files.isNotEmpty()) transfer = PendingTransfer(files, move)
    }

    fun cancelTransfer() { transfer = null }

    /** Message d'erreur si la destination est impossible (dossier dans lui-même, rien à déplacer), sinon null. */
    fun transferProblem(t: PendingTransfer, dest: File): String? {
        val d = runCatching { dest.canonicalPath }.getOrDefault(dest.path)
        for (f in t.files) {
            val p = runCatching { f.canonicalPath }.getOrDefault(f.path)
            if (f.isDirectory && (d == p || d.startsWith(p + File.separator))) return "Impossible de mettre « ${f.name} » dans lui-même"
        }
        if (t.move && t.files.all { (it.parentFile?.path ?: "") == dest.path }) return "Ces éléments sont déjà dans ce dossier"
        return null
    }

    fun createFolder(parent: File, name: String): Boolean {
        val n = name.trim()
        if (n.isEmpty() || n.contains('/')) { message = "Nom de dossier invalide"; return false }
        val d = File(parent, n)
        if (d.exists()) { message = "« $n » existe déjà"; return false }
        val ok = d.mkdirs()
        if (!ok) message = "Impossible de créer le dossier"
        return ok
    }

    /** Copie ou déplace les éléments en attente dans [dest]. Les homonymes sont renommés « nom (1) ». */
    fun pasteTo(dest: File) {
        val t = transfer ?: return
        if (transferProblem(t, dest) != null) return
        transfer = null
        selected.clear()
        val verb = if (t.move) "Déplacement" else "Copie"
        work("$verb…") {
            var ok = 0
            var fail = 0
            val created = ArrayList<String>()
            for (f in t.files) {
                busy = "$verb · ${f.name}"
                if (t.move && f.parentFile?.path == dest.path) { ok++; continue }
                val target = unique(File(dest, f.name))
                try {
                    val done = if (t.move) {
                        // renameTo est instantané sur le même volume ; sinon on copie puis on supprime l'original
                        f.renameTo(target) || (f.copyRecursively(target) && f.deleteRecursively())
                    } else {
                        f.copyRecursively(target)
                    }
                    if (done) { ok++; target.walkTopDown().filter { it.isFile }.forEach { created += it.path } }
                    else { fail++; if (!t.move) target.deleteRecursively() }
                } catch (e: Exception) {
                    fail++
                    if (!t.move) target.deleteRecursively()
                }
            }
            scanPaths(created)
            val what = if (t.move) "déplacé(s)" else "copié(s)"
            "$ok élément(s) $what" + if (fail > 0) " · $fail échec(s)" else ""
        }
    }

    /** Signale les nouveaux fichiers à Android pour qu'ils apparaissent aussitôt dans Images, Vidéos, Audio, Documents. */
    private fun scanPaths(paths: List<String>) {
        if (paths.isEmpty()) return
        val latch = CountDownLatch(paths.size)
        MediaScannerConnection.scanFile(ctx, paths.toTypedArray(), null) { _, _ -> latch.countDown() }
        latch.await(10, TimeUnit.SECONDS)
    }

    // ───────────────────────────── Coffre-fort ─────────────────────────────

    fun loadVault() {
        viewModelScope.launch {
            vaultItems = withContext(Dispatchers.IO) {
                vaultDir.listFiles().orEmpty().map { it.toItem() }
                    .sortedWith(compareByDescending<LItem> { it.isDir }.thenBy { it.file.name.lowercase() })
            }
        }
    }

    fun lockVault() { VaultLock.unlocked = false; selected.clear(); vaultItems = emptyList() }

    fun moveToVault() {
        val files = picked(items)
        selected.clear()
        work("Déplacement vers le coffre…") {
            var n = 0
            files.forEach { f ->
                val t = unique(File(vaultDir, f.name))
                try {
                    if (f.copyRecursively(t)) { f.deleteRecursively(); n++ } else t.deleteRecursively()
                } catch (e: Exception) { t.deleteRecursively() }
            }
            "$n élément(s) déplacé(s) dans le coffre"
        }
    }

    fun restoreFromVault() {
        val files = picked(vaultItems)
        selected.clear()
        val out = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Restauré du coffre")
        work("Restauration…") {
            out.mkdirs()
            var n = 0
            files.forEach { f ->
                val t = unique(File(out, f.name))
                try {
                    if (f.copyRecursively(t)) { f.deleteRecursively(); n++ } else t.deleteRecursively()
                } catch (e: Exception) { t.deleteRecursively() }
            }
            "$n élément(s) restauré(s) dans Download/Restauré du coffre"
        }
    }

    fun deleteFromVault() {
        val files = picked(vaultItems)
        selected.clear()
        work("Suppression…") {
            var n = 0
            files.forEach { if (it.deleteRecursively()) n++ }
            "$n élément(s) supprimé(s) du coffre"
        }
    }

    // ───────────────────────────── Scan de documents ─────────────────────────────

    fun saveScan(uri: Uri) {
        val scans = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "LinkShare Scans")
        category = null; query = ""; favMode = false; base = scans; dir = scans
        work("Enregistrement du scan…") {
            scans.mkdirs()
            val out = unique(File(scans, "Scan_${stamp()}.pdf"))
            val input = ctx.contentResolver.openInputStream(uri) ?: error("Scan illisible")
            input.use { i -> FileOutputStream(out).use { i.copyTo(it) } }
            "Scan enregistré : Documents/LinkShare Scans/${out.name}"
        }
    }
}
