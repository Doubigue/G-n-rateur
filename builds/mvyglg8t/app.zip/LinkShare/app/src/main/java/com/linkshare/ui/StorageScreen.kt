package com.linkshare.ui

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.content.ContextWrapper
import android.net.Uri
import android.os.Environment
import android.text.format.Formatter
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.decode.VideoFrameDecoder
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DateFormat
import java.util.Date

internal tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

private fun LItem.iconVec(): ImageVector = when {
    isDir -> Ic.Folder
    file.isArchive() -> Ic.Archive
    file.category() == Category.MORE -> Ic.Doc
    else -> file.category().icon()
}

private fun LItem.isPhoto() = !isDir && file.extension.lowercase() in VIEW_IMG

// ═══════════════════════════ Composants ═══════════════════════════

@Composable
internal fun Thumb(item: LItem, size: Dp = 52.dp) {
    Box(Modifier.size(size).clip(RoundedCornerShape(10.dp)).background(LS.Card), contentAlignment = Alignment.Center) {
        if (item.isPhoto()) AsyncImage(item.file, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(item.iconVec(), null, Modifier.size(if (item.isDir) size * 0.8f else size / 2), tint = if (item.isDir) LS.Blue else LS.Muted)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun FileRow(item: LItem, ex: ExplorerViewModel) {
    val ctx = LocalContext.current
    val f = item.file
    val sel = f.path in ex.selected
    val showParent = ex.query.isNotBlank() || ex.category != null
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(if (sel) LS.BlueLight else Color.Transparent)
            .combinedClickable(
                onClick = { if (ex.selected.isNotEmpty()) ex.toggle(f.path) else ex.open(f) },
                onLongClick = { ex.toggle(f.path) },
            ).padding(4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Thumb(item)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(f.name, color = LS.Text, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val sub = if (item.isDir) "${item.count} élément(s)"
            else Formatter.formatShortFileSize(ctx, item.size) + " · " + DateFormat.getDateInstance(DateFormat.SHORT).format(Date(item.modified))
            Text(
                if (showParent) sub + " · " + (f.parentFile?.name ?: "") else sub,
                color = LS.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
        if (sel) Icon(Ic.Check, null, Modifier.padding(end = 8.dp).size(20.dp), tint = LS.Blue)
        else if (f.path in ex.favorites) Icon(Ic.Star, null, Modifier.padding(end = 8.dp).size(16.dp), tint = LS.Blue)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun FolderCell(item: LItem, ex: ExplorerViewModel, modifier: Modifier) {
    val f = item.file
    val sel = f.path in ex.selected
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier.clip(shape).background(if (sel) LS.BlueLight else LS.Card)
            .then(if (sel) Modifier.border(1.5.dp, LS.Blue, shape) else Modifier)
            .combinedClickable(
                onClick = { if (ex.selected.isNotEmpty()) ex.toggle(f.path) else ex.open(f) },
                onLongClick = { ex.toggle(f.path) },
            ).padding(14.dp),
    ) {
        Icon(Ic.Folder, null, Modifier.size(68.dp), tint = LS.Blue)
        Spacer(Modifier.height(8.dp))
        Text(f.name, color = LS.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Text("${item.count} élément(s)", color = LS.Muted, fontSize = 12.sp)
    }
}

/** Chargeur de miniatures qui sait aussi extraire une image d'une vidéo. */
@Composable
internal fun rememberThumbLoader(): ImageLoader {
    val ctx = LocalContext.current
    return remember { ImageLoader.Builder(ctx).components { add(VideoFrameDecoder.Factory()) }.crossfade(true).build() }
}

/** Fichier en vue grille : miniature pour les images et les vidéos, grande icône + nom pour le reste (audio, documents…). */
@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun FileCell(item: LItem, ex: ExplorerViewModel, loader: ImageLoader, modifier: Modifier = Modifier) {
    val f = item.file
    val sel = f.path in ex.selected
    val ext = f.extension.lowercase()
    val cat = f.category()
    val video = cat == Category.VIDEOS
    val visual = ext in VIEW_IMG || ext == "heic" || video
    val shape = RoundedCornerShape(14.dp)
    Box(
        modifier.aspectRatio(1f).clip(shape).background(if (sel) LS.BlueLight else LS.Card)
            .then(if (sel) Modifier.border(2.dp, LS.Blue, shape) else Modifier)
            .combinedClickable(
                onClick = { if (ex.selected.isNotEmpty()) ex.toggle(f.path) else ex.open(f) },
                onLongClick = { ex.toggle(f.path) },
            ),
        contentAlignment = Alignment.Center,
    ) {
        if (visual) {
            AsyncImage(
                model = f, contentDescription = f.name, imageLoader = loader,
                modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop,
            )
            if (video) Box(
                Modifier.size(36.dp).clip(CircleShape).background(Color(0x99000000)),
                contentAlignment = Alignment.Center,
            ) { Icon(Ic.Play, null, Modifier.size(22.dp), tint = Color.White) }
        } else {
            Column(
                Modifier.fillMaxSize().padding(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
            ) {
                Icon(item.iconVec(), null, Modifier.size(34.dp), tint = LS.Blue)
                Spacer(Modifier.height(6.dp))
                Text(
                    f.name, color = LS.Text, fontSize = 11.sp, maxLines = 2,
                    overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                )
            }
        }
        if (sel) Box(
            Modifier.align(Alignment.TopEnd).padding(6.dp).size(22.dp).clip(CircleShape).background(LS.Blue),
            contentAlignment = Alignment.Center,
        ) { Icon(Ic.Check, null, Modifier.size(16.dp), tint = LS.OnBlue) }
        else if (f.path in ex.favorites) Icon(
            Ic.Star, null, Modifier.align(Alignment.TopEnd).padding(6.dp).size(16.dp), tint = LS.Blue,
        )
    }
}

internal class BarAction(val label: String, val icon: ImageVector, val onClick: () -> Unit)

/**
 * Barre d'actions de la sélection. Les actions défilent horizontalement quand elles sont trop nombreuses ;
 * [onCancel], s'il est fourni, ajoute un bouton « Annuler » toujours visible à gauche.
 */
@Composable
internal fun SelectionBar(count: Int, actions: List<BarAction>, modifier: Modifier, onCancel: (() -> Unit)? = null) {
    Row(
        modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp).clip(RoundedCornerShape(22.dp))
            .background(LS.Blue).padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (onCancel != null) Column(
            Modifier.clip(RoundedCornerShape(10.dp)).clickable(onClick = onCancel).padding(horizontal = 8.dp, vertical = 2.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Icon(Ic.Close, "Annuler", Modifier.size(20.dp), tint = LS.OnBlue)
            Text("Annuler", color = LS.OnBlue, fontSize = 9.sp)
        }
        Text("$count", Modifier.padding(horizontal = 8.dp), color = LS.OnBlue, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        Row(
            Modifier.weight(1f).horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically,
        ) {
            actions.forEach { a ->
                Column(
                    Modifier.clip(RoundedCornerShape(10.dp)).clickable(onClick = a.onClick).padding(horizontal = 8.dp, vertical = 2.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Icon(a.icon, a.label, Modifier.size(20.dp), tint = LS.OnBlue)
                    Text(a.label, color = LS.OnBlue, fontSize = 9.sp)
                }
            }
        }
    }
}

// ═══════════════════════════ Dossier sécurisé ═══════════════════════════

@Composable
internal fun VaultView(ex: ExplorerViewModel) {
    var confirm by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { ex.loadVault() }
    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = if (ex.selected.isNotEmpty()) 84.dp else 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item(key = "vtitle") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton({ ex.lockVault() }) { Icon(Ic.Back, "Verrouiller", tint = LS.Blue) }
                    Text("Dossier sécurisé", Modifier.weight(1f), color = LS.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Icon(Ic.Lock, null, Modifier.size(22.dp), tint = LS.Blue)
                }
            }
            item(key = "vinfo") {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(LS.BlueLight).padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Ic.Info, null, Modifier.size(18.dp), tint = LS.Blue)
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "Ajoute des fichiers depuis l'explorateur : appui long, puis « Coffre ». " +
                            "Ils sont rangés dans l'espace privé de l'appli, invisibles aux autres apps et gestionnaires de fichiers. " +
                            "Désinstaller LinkShare les supprime : restaure-les avant.",
                        color = LS.Text, fontSize = 11.sp,
                    )
                }
            }
            ex.busy?.let { b -> item(key = "vbusy") { Column { Text(b, color = LS.Text, fontSize = 11.sp); LinearProgressIndicator(Modifier.fillMaxWidth(), color = LS.Blue) } } }
            if (ex.vaultItems.isEmpty()) item(key = "vempty") {
                Text("Le coffre est vide", Modifier.fillMaxWidth().padding(24.dp), color = LS.Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
            }
            items(ex.vaultItems, key = { it.file.path }) { FileRow(it, ex) }
        }
        if (ex.selected.isNotEmpty()) {
            SelectionBar(
                ex.selected.size,
                listOf(
                    BarAction("Restaurer", Ic.Up) { ex.restoreFromVault() },
                    BarAction("Suppr.", Ic.Delete) { confirm = true },
                ),
                Modifier.align(Alignment.BottomCenter),
                onCancel = { ex.selected.clear() },
            )
        }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("Supprimer du coffre ?") },
        text = { Text("${ex.selected.size} élément(s) seront supprimés définitivement.") },
        confirmButton = { TextButton({ confirm = false; ex.deleteFromVault() }) { Text("Supprimer") } },
        dismissButton = { TextButton({ confirm = false }) { Text("Annuler") } },
    )
}

// ═══════════════════════════ Lecteur local ═══════════════════════════

@Composable
fun LocalViewerScreen(ex: ExplorerViewModel) {
    val f = ex.viewing ?: return
    val e = f.extension.lowercase()
    // Fichiers du même type dans la liste d'où vient le fichier : on y passe en balayant
    val list = ex.viewList.ifEmpty { listOf(f) }
    val start = remember { list.indexOfFirst { it.path == f.path }.coerceAtLeast(0) }
    fun close() { PlayerHost.stop(); ex.viewing = null; ex.viewList = emptyList() }
    BackHandler { close() }
    // Fichier du dossier sécurisé : son nom ne doit pas s'afficher sur l'écran verrouillé
    fun lockTitle(x: File) = if (x.path.startsWith(ex.vaultDir.path)) "Fichier sécurisé" else x.name
    Column(Modifier.fillMaxSize().background(LS.Bg).systemBarsPadding()) {
        Row(Modifier.padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ close() }) { Icon(Ic.Back, "Retour", tint = LS.Blue) }
            Text(f.name, Modifier.weight(1f), color = LS.Blue, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (list.size > 1) Text(
                "${list.indexOfFirst { it.path == f.path } + 1}/${list.size}",
                Modifier.padding(end = 12.dp), color = LS.Muted, fontSize = 12.sp,
            )
        }
        when {
            e in VIEW_IMG -> ImagePager(list, start) { ex.viewing = list[it] }
            e in VIEW_TXT -> TextViewer(f)
            else -> {
                val urls = remember(list) { list.map { Uri.fromFile(it).toString() } }
                val titles = remember(list) { list.map { lockTitle(it) } }
                Player(urls, titles, start) { ex.viewing = list[it] }
            }
        }
    }
}

@Composable
private fun TextViewer(f: File) {
    val text by produceState("Chargement…", f) {
        value = withContext(Dispatchers.IO) {
            try {
                f.bufferedReader().use { r ->
                    val buf = CharArray(300_000)
                    val n = r.read(buf)
                    (if (n > 0) String(buf, 0, n) else "") + if (f.length() > 600_000) "\n\n… (aperçu limité)" else ""
                }
            } catch (e: Exception) { "Lecture impossible : ${e.message}" }
        }
    }
    SelectionContainer {
        Text(
            text, Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            color = LS.Text, fontSize = 12.sp, fontFamily = FontFamily.Monospace,
        )
    }
}
