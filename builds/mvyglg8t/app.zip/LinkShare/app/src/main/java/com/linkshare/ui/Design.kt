package com.linkshare.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linkshare.core.FileEntry
import com.linkshare.core.ext
import java.io.File

/** Palette sombre inspirée de Files by Google. */
object LS {
    val Blue = Color(0xFF8AB4F8)       // accent (icônes, dossiers, boutons)
    val OnBlue = Color(0xFF062E6F)     // texte posé sur l'accent
    val BlueLight = Color(0xFF34435A)  // éléments sélectionnés
    val Bg = Color(0xFF262626)         // fond d'écran
    val Card = Color(0xFF151515)       // cartes de catégories
    val Card2 = Color(0xFF343434)      // surfaces secondaires (menus, barres)
    val Pill = Color(0xFFD9D9D9)       // pilule Partager / Scanner
    val Text = Color(0xFFF2F2F2)
    val Muted = Color(0xFFA9A9A9)
}

private fun vec(name: String, d: String): ImageVector =
    ImageVector.Builder(name, 24.dp, 24.dp, 24f, 24f)
        .addPath(PathParser().parsePathString(d).toNodes(), fill = SolidColor(Color.Black))
        .build()

/** Icônes (tracés Material, 24x24) : aucune dépendance supplémentaire. */
object Ic {
    val Home by lazy { vec("home", "M10,20v-6h4v6h5v-8h3L12,3 2,12h3v8z") }
    val Cloud by lazy { vec("cloud", "M19.35,10.04C18.67,6.59 15.64,4 12,4 9.11,4 6.6,5.64 5.35,8.04 2.34,8.36 0,10.91 0,14c0,3.31 2.69,6 6,6h13c2.76,0 5,-2.24 5,-5 0,-2.64 -2.05,-4.78 -4.65,-4.96z") }
    val Share by lazy { vec("share", "M18,16.08c-0.76,0 -1.44,0.3 -1.96,0.77L8.91,12.7c0.05,-0.23 0.09,-0.46 0.09,-0.7s-0.04,-0.47 -0.09,-0.7l7.05,-4.11c0.54,0.5 1.25,0.81 2.04,0.81 1.66,0 3,-1.34 3,-3s-1.34,-3 -3,-3 -3,1.34 -3,3c0,0.24 0.04,0.47 0.09,0.7L8.04,9.81C7.5,9.31 6.79,9 6,9c-1.66,0 -3,1.34 -3,3s1.34,3 3,3c0.79,0 1.5,-0.31 2.04,-0.81l7.12,4.16c-0.05,0.21 -0.08,0.43 -0.08,0.65 0,1.61 1.31,2.92 2.92,2.92 1.61,0 2.92,-1.31 2.92,-2.92s-1.31,-2.92 -2.92,-2.92z") }
    val Person by lazy { vec("person", "M12,12c2.21,0 4,-1.79 4,-4s-1.79,-4 -4,-4 -4,1.79 -4,4 1.79,4 4,4zM12,14c-2.67,0 -8,1.34 -8,4v2h16v-2c0,-2.66 -5.33,-4 -8,-4z") }
    val Search by lazy { vec("search", "M15.5,14h-0.79l-0.28,-0.27C15.41,12.59 16,11.11 16,9.5 16,5.91 13.09,3 9.5,3S3,5.91 3,9.5 5.91,16 9.5,16c1.61,0 3.09,-0.59 4.23,-1.57l0.27,0.28v0.79l5,4.99L20.49,19l-4.99,-5zM9.5,14C7.01,14 5,11.99 5,9.5S7.01,5 9.5,5 14,7.01 14,9.5 11.99,14 9.5,14z") }
    val Send by lazy { vec("send", "M2.01,21L23,12 2.01,3 2,10l15,2 -15,2z") }
    val Download by lazy { vec("download", "M19,9h-4V3H9v6H5l7,7 7,-7zM5,18v2h14v-2H5z") }
    val Link by lazy { vec("link", "M3.9,12c0,-1.71 1.39,-3.1 3.1,-3.1h4V7H7c-2.76,0 -5,2.24 -5,5s2.24,5 5,5h4v-1.9H7c-1.71,0 -3.1,-1.39 -3.1,-3.1zM8,13h8v-2H8v2zM17,7h-4v1.9h4c1.71,0 3.1,1.39 3.1,3.1s-1.39,3.1 -3.1,3.1h-4V17h4c2.76,0 5,-2.24 5,-5s-2.24,-5 -5,-5z") }
    val Doc by lazy { vec("doc", "M14,2H6c-1.1,0 -1.99,0.9 -1.99,2L4,20c0,1.1 0.89,2 1.99,2H18c1.1,0 2,-0.9 2,-2V8l-6,-6zM16,18H8v-2h8v2zM16,14H8v-2h8v2zM13,9V3.5L18.5,9H13z") }
    val Image by lazy { vec("image", "M21,19V5c0,-1.1 -0.9,-2 -2,-2H5c-1.1,0 -2,0.9 -2,2v14c0,1.1 0.9,2 2,2h14c1.1,0 2,-0.9 2,-2zM8.5,13.5l2.5,3.01L14.5,12l4.5,6H5l3.5,-4.5z") }
    val Video by lazy { vec("video", "M17,10.5V7c0,-0.55 -0.45,-1 -1,-1H4c-0.55,0 -1,0.45 -1,1v10c0,0.55 0.45,1 1,1h12c0.55,0 1,-0.45 1,-1v-3.5l4,4v-11l-4,4z") }
    val Music by lazy { vec("music", "M12,3v10.55c-0.59,-0.34 -1.27,-0.55 -2,-0.55 -2.21,0 -4,1.79 -4,4s1.79,4 4,4 4,-1.79 4,-4V7h4V3h-6z") }
    val More by lazy { vec("more", "M6,10c-1.1,0 -2,0.9 -2,2s0.9,2 2,2 2,-0.9 2,-2 -0.9,-2 -2,-2zM18,10c-1.1,0 -2,0.9 -2,2s0.9,2 2,2 2,-0.9 2,-2 -0.9,-2 -2,-2zM12,10c-1.1,0 -2,0.9 -2,2s0.9,2 2,2 2,-0.9 2,-2 -0.9,-2 -2,-2z") }
    val Folder by lazy { vec("folder", "M10,4H4c-1.1,0 -1.99,0.9 -1.99,2L2,18c0,1.1 0.9,2 2,2h16c1.1,0 2,-0.9 2,-2V8c0,-1.1 -0.9,-2 -2,-2h-8l-2,-2z") }
    val Back by lazy { vec("back", "M15.41,7.41L14,6l-6,6 6,6 1.41,-1.41L10.83,12z") }
    val Chevron by lazy { vec("chevron", "M10,6L8.59,7.41 13.17,12l-4.58,4.59L10,18l6,-6z") }
    val Expand by lazy { vec("expand", "M16.59,8.59L12,13.17 7.41,8.59 6,10l6,6 6,-6z") }
    val Scan by lazy { vec("scan", "M9.5,6.5v3h-3v-3H9.5M11,5H5v6h6V5zM9.5,14.5v3h-3v-3H9.5M11,13H5v6h6V13zM17.5,6.5v3h-3v-3H17.5M19,5h-6v6h6V5zM13,13h1.5v1.5H13V13zM14.5,14.5H16V16h-1.5V14.5zM16,13h1.5v1.5H16V13zM13,16h1.5v1.5H13V16zM14.5,17.5H16V19h-1.5V17.5zM16,16h1.5v1.5H16V16zM17.5,14.5H19V16h-1.5V14.5zM17.5,17.5H19V19h-1.5V17.5zM22,7h-2V4h-3V2h5V7zM22,22h-5v-2h3v-3h2V22zM2,22v-5h2v3h3v2H2zM2,2h5v2H4v3H2V2z") }
    val Apps by lazy { vec("apps", "M4,8h4V4H4v4zM10,20h4v-4h-4v4zM4,20h4v-4H4v4zM4,14h4v-4H4v4zM10,14h4v-4h-4v4zM16,4v4h4V4h-4zM10,8h4V4h-4v4zM16,14h4v-4h-4v4zM16,20h4v-4h-4v4z") }
    val Up by lazy { vec("up", "M4,12l1.41,1.41L11,7.83V20h2V7.83l5.58,5.59L20,12l-8,-8 -8,8z") }
    val Down by lazy { vec("down", "M20,12l-1.41,-1.41L13,16.17V4h-2v12.17l-5.58,-5.59L4,12l8,8 8,-8z") }
    val Info by lazy { vec("info", "M11,7h2v2h-2zM11,11h2v6h-2zM12,2C6.48,2 2,6.48 2,12s4.48,10 10,10 10,-4.48 10,-10S17.52,2 12,2zM12,20c-4.41,0 -8,-3.59 -8,-8s3.59,-8 8,-8 8,3.59 8,8 -3.59,8 -8,8z") }
    val Copy by lazy { vec("copy", "M16,1H4c-1.1,0 -2,0.9 -2,2v14h2V3h12V1zM19,5H8c-1.1,0 -2,0.9 -2,2v14c0,1.1 0.9,2 2,2h11c1.1,0 2,-0.9 2,-2V7c0,-1.1 -0.9,-2 -2,-2zM19,21H8V7h11v14z") }
    val Lock by lazy { vec("lock", "M18,8h-1V6c0,-2.76 -2.24,-5 -5,-5S7,3.24 7,6v2H6c-1.1,0 -2,0.9 -2,2v10c0,1.1 0.9,2 2,2h12c1.1,0 2,-0.9 2,-2V10c0,-1.1 -0.9,-2 -2,-2zM12,17c-1.1,0 -2,-0.9 -2,-2s0.9,-2 2,-2 2,0.9 2,2 -0.9,2 -2,2zM15.1,8H8.9V6c0,-1.71 1.39,-3.1 3.1,-3.1 1.71,0 3.1,1.39 3.1,3.1v2z") }
    val Archive by lazy { vec("archive", "M20.54,5.23l-1.39,-1.68C18.88,3.21 18.47,3 18,3H6c-0.47,0 -0.88,0.21 -1.16,0.55L3.46,5.23C3.17,5.57 3,6.02 3,6.5V19c0,1.1 0.9,2 2,2h14c1.1,0 2,-0.9 2,-2V6.5c0,-0.48 -0.17,-0.93 -0.46,-1.27zM12,17.5L6.5,12H10v-2h4v2h3.5L12,17.5zM5.12,5l0.81,-1h12l0.94,1H5.12z") }
    val ScanDoc by lazy { vec("scandoc", "M4,4h3V2H2v5h2V4zM20,4v3h2V2h-5v2h3zM4,20v-3H2v5h5v-2H4zM20,20h-3v2h5v-5h-2v3zM8,8h8v1.6H8zM8,11.2h8v1.6H8zM8,14.4h5v1.6H8z") }
    val Sort by lazy { vec("sort", "M3,18h6v-2H3v2zM3,6v2h18V6H3zM3,13h12v-2H3v2z") }
    val GridView by lazy { vec("grid", "M3,3v8h8V3H3zM9,9H5V5h4v4zM3,13v8h8v-8H3zM9,19H5v-4h4v4zM13,3v8h8V3h-8zM19,9h-4V5h4v4zM13,13v8h8v-8h-8zM19,19h-4v-4h4v4z") }
    val ViewList by lazy { vec("list", "M3,13h2v-2H3v2zM3,17h2v-2H3v2zM3,9h2V7H3v2zM7,13h14v-2H7v2zM7,17h14v-2H7v2zM7,7v2h14V7H7z") }
    val Delete by lazy { vec("delete", "M6,19c0,1.1 0.9,2 2,2h8c1.1,0 2,-0.9 2,-2V7H6v12zM19,4h-3.5l-1,-1h-5l-1,1H5v2h14V4z") }
    val Check by lazy { vec("check", "M9,16.17L4.83,12l-1.42,1.41L9,19 21,7l-1.41,-1.41z") }
    val Close by lazy { vec("close", "M19,6.41L17.59,5 12,10.59 6.41,5 5,6.41 10.59,12 5,17.59 6.41,19 12,13.41 17.59,19 19,17.59 13.41,12z") }
    val ShareNearby by lazy { vec("sharenearby", "M12,2C6.48,2 2,6.48 2,12s4.48,10 10,10 10,-4.48 10,-10S17.52,2 12,2zM12,20c-4.41,0 -8,-3.59 -8,-8s3.59,-8 8,-8 8,3.59 8,8 -3.59,8 -8,8zM6.5,9L10,5.5L10,8L17,8L17,10L10,10L10,12.5zM17.5,15L14,18.5L14,16L7,16L7,14L14,14L14,11.5z") }
    val Star by lazy { vec("star", "M12,17.27L18.18,21l-1.64,-7.03L22,9.24l-7.19,-0.61L12,2 9.19,8.63 2,9.24l5.46,4.73L5.82,21z") }
    val Play by lazy { vec("play", "M8,5v14l11,-7z") }
    val MoreVert by lazy { vec("morevert", "M12,8c1.1,0 2,-0.9 2,-2s-0.9,-2 -2,-2 -2,0.9 -2,2 0.9,2 2,2zM12,10c-1.1,0 -2,0.9 -2,2s0.9,2 2,2 2,-0.9 2,-2 -0.9,-2 -2,-2zM12,16c-1.1,0 -2,0.9 -2,2s0.9,2 2,2 2,-0.9 2,-2 -0.9,-2 -2,-2z") }
    val Phone by lazy { vec("phone", "M17,1.01L7,1c-1.1,0 -2,0.9 -2,2v18c0,1.1 0.9,2 2,2h10c1.1,0 2,-0.9 2,-2V3c0,-1.1 -0.9,-1.99 -2,-1.99zM17,19H7V5h10v14z") }
    val SdCard by lazy { vec("sdcard", "M18,2h-8L4.02,8 4,20c0,1.1 0.9,2 2,2h12c1.1,0 2,-0.9 2,-2V4c0,-1.1 -0.9,-2 -2,-2zM12,8h-2V4h2v4zM15,8h-2V4h2v4z") }
    val Storage by lazy { vec("storage", "M2,20h20v-4H2v4zM4,17h2v2H4v-2zM2,4v4h20V4H2zM6,7H4V5h2v2zM2,14h20v-4H2v4zM4,11h2v2H4v-2z") }
    val Stop by lazy { vec("stop", "M6,6h12v12H6z") }
    val Forward by lazy { vec("forward", "M12,4l-1.41,1.41L16.17,11H4v2h12.17l-5.58,5.59L12,20l8,-8z") }
    val Volume by lazy { vec("volume", "M3,9v6h4l5,5V4L7,9H3zM16.5,12c0,-1.77 -1.02,-3.29 -2.5,-4.03v8.05c1.48,-0.73 2.5,-2.25 2.5,-4.02zM14,3.23v2.06c2.89,0.86 5,3.54 5,6.71s-2.11,5.85 -5,6.71v2.06c4.01,-0.91 7,-4.49 7,-8.77s-2.99,-7.86 -7,-8.77z") }
}

enum class Category(val label: String, val group: String) {
    DOCS("Docs", "Documents"),
    PHOTOS("Photos", "Photos"),
    VIDEOS("Vidéos", "Vidéos"),
    MUSIC("Musique", "Musique"),
    MORE("Plus", "Autres fichiers"),
}

private val DOCS = setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "odt", "ods", "odp", "csv", "rtf", "md")
private val PHOTOS = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "svg")
private val VIDEOS = setOf("mp4", "mkv", "webm", "3gp", "mov", "avi")
private val MUSIC = setOf("mp3", "m4a", "aac", "ogg", "opus", "wav", "flac")

fun categoryOfExt(e: String): Category = when (e) {
    in DOCS -> Category.DOCS
    in PHOTOS -> Category.PHOTOS
    in VIDEOS -> Category.VIDEOS
    in MUSIC -> Category.MUSIC
    else -> Category.MORE
}

fun FileEntry.category(): Category = categoryOfExt(ext())
fun File.category(): Category = categoryOfExt(extension.lowercase())

fun Category.icon(): ImageVector = when (this) {
    Category.DOCS -> Ic.Doc
    Category.PHOTOS -> Ic.Image
    Category.VIDEOS -> Ic.Video
    Category.MUSIC -> Ic.Music
    Category.MORE -> Ic.More
}

fun FileEntry.icon(): ImageVector = when {
    isDir -> Ic.Folder
    category() == Category.MORE -> Ic.Doc
    else -> category().icon()
}

@Composable
fun CategoryTile(cat: Category, selected: Boolean, onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier.size(52.dp).clip(RoundedCornerShape(14.dp)).background(if (selected) LS.Blue else LS.Card),
            contentAlignment = Alignment.Center,
        ) { Icon(cat.icon(), null, Modifier.size(24.dp), tint = if (selected) Color.White else LS.Blue) }
        Spacer(Modifier.height(4.dp))
        Text(cat.label, fontSize = 10.sp, color = if (selected) LS.Blue else LS.Muted)
    }
}

@Composable
fun SectionTitle(title: String, action: String? = null, onAction: () -> Unit = {}) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f), color = LS.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        if (action != null) Text(
            action, Modifier.clickable(onClick = onAction),
            color = LS.Blue, fontSize = 11.sp, fontWeight = FontWeight.SemiBold,
        )
    }
}

@Composable
fun ActionTile(label: String, icon: ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(16.dp)).background(LS.Card).clickable(onClick = onClick).padding(vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, null, Modifier.size(24.dp), tint = LS.Blue)
        Spacer(Modifier.height(6.dp))
        Text(label, fontSize = 11.sp, color = LS.Text)
    }
}

@Composable
fun Avatar(diameter: androidx.compose.ui.unit.Dp) {
    Box(
        Modifier.size(diameter).clip(CircleShape).background(LS.BlueLight),
        contentAlignment = Alignment.Center,
    ) { Icon(Ic.Person, null, Modifier.size(diameter * 0.6f), tint = LS.Blue) }
}
