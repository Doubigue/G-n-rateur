package com.dlvibe.extrait

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat

/** Réglage « détection des captures d'écran » + état des autorisations nécessaires. */
object Prefs {
    private const val FILE = "extrait"
    private const val KEY_SHOT = "screenshot_watch"

    fun watching(ctx: Context): Boolean =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean(KEY_SHOT, false)

    fun setWatching(ctx: Context, on: Boolean) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putBoolean(KEY_SHOT, on).apply()
    }

    /** Permission de lire les images (pour voir apparaître la capture d'écran). */
    val mediaPermission: String
        get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
        else Manifest.permission.READ_EXTERNAL_STORAGE

    fun hasMedia(ctx: Context) =
        ContextCompat.checkSelfPermission(ctx, mediaPermission) == PackageManager.PERMISSION_GRANTED

    fun hasNotifications(ctx: Context) =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun hasOverlay(ctx: Context) = Settings.canDrawOverlays(ctx)

    fun overlaySettingsIntent(ctx: Context): Intent =
        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:${ctx.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    /** Démarre ou arrête le service selon le réglage et les autorisations. */
    fun apply(ctx: Context) {
        if (watching(ctx) && hasMedia(ctx)) ScreenshotService.start(ctx) else ScreenshotService.stop(ctx)
    }
}
