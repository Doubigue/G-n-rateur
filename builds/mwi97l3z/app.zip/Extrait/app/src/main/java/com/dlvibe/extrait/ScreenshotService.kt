package com.dlvibe.extrait

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentResolver
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.database.ContentObserver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.max

/** Ce que montre la carte (ou la notification) pendant le traitement d'une capture. */
private sealed interface Ui {
    data object Choose : Ui
    data class Working(val label: String) : Ui
    data class TextDone(val text: String, val copied: Boolean) : Ui
    data class PdfDone(val file: File, val uri: Uri, val where: String?, val pages: Int) : Ui
    data class Fail(val message: String) : Ui
}

/**
 * Surveille la galerie : dès qu'une capture d'écran apparaît, affiche une petite carte par-dessus tout
 * (même app fermée) avec « Extraire le texte » et « Numériser en PDF ». Les deux actions sont exécutées
 * ici, dans le service : l'app ne s'ouvre jamais. Sans l'autorisation « Affichage par-dessus les autres
 * applis », la même proposition arrive sous forme de notification avec les deux boutons.
 */
class ScreenshotService : Service() {

    private val main = Handler(Looper.getMainLooper())
    private val io: ExecutorService = Executors.newSingleThreadExecutor()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var job: Job? = null
    private var observer: ContentObserver? = null
    private var lastShownId = -1L
    private var overlay: LinearLayout? = null
    private var overlayParams: WindowManager.LayoutParams? = null
    private var shotUri: Uri? = null
    private var shotThumb: Bitmap? = null

    @Volatile private var attempts = 0

    private val check = Runnable { io.execute { checkLatest() } }
    private val hide = Runnable { hideOverlay() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannels()
        try {
            val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            else ServiceInfo.FOREGROUND_SERVICE_TYPE_MANIFEST
            ServiceCompat.startForeground(this, ONGOING_ID, ongoingNotification(), type)
        } catch (e: Throwable) {
            stopSelf()
            return
        }
        val obs = object : ContentObserver(main) {
            override fun onChange(selfChange: Boolean, uri: Uri?) {
                attempts = 0
                main.removeCallbacks(check)
                main.postDelayed(check, 250)
            }
        }
        contentResolver.registerContentObserver(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true, obs)
        observer = obs
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Boutons de la notification (mode sans fenêtre flottante) : on travaille ici, sans ouvrir l'app.
        val uri = intent?.data
        if (uri != null) {
            when (intent?.action) {
                ACTION_OCR -> runOcr(uri)
                ACTION_PDF -> runPdf(uri)
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        observer?.let { contentResolver.unregisterContentObserver(it) }
        observer = null
        main.removeCallbacksAndMessages(null)
        hideOverlay()
        scope.cancel()
        io.shutdownNow()
        super.onDestroy()
    }

    // ------------------------------------------------------------ détection

    private fun checkLatest() {
        val found = findScreenshot()
        if (found < 0) {
            // La capture peut arriver quelques instants après la notification de la galerie : on réessaie.
            if (attempts++ < 4) main.postDelayed(check, 600L * attempts)
            return
        }
        if (found == lastShownId) return
        lastShownId = found
        val uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, found)
        val thumb = smallThumb(uri)
        main.post { onScreenshot(uri, thumb) }
    }

    private fun findScreenshot(): Long {
        if (!Prefs.hasMedia(this)) return -1L
        val cols = arrayListOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME, MediaStore.Images.Media.DATE_ADDED)
        cols.add(if (Build.VERSION.SDK_INT >= 29) MediaStore.Images.Media.RELATIVE_PATH else MediaStore.Images.Media.DATA)
        val args = Bundle().apply {
            putStringArray(ContentResolver.QUERY_ARG_SORT_COLUMNS, arrayOf(MediaStore.Images.Media.DATE_ADDED, MediaStore.Images.Media._ID))
            putInt(ContentResolver.QUERY_ARG_SORT_DIRECTION, ContentResolver.QUERY_SORT_DIRECTION_DESCENDING)
            putInt(ContentResolver.QUERY_ARG_LIMIT, 6)
        }
        try {
            contentResolver.query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cols.toTypedArray(), args, null)?.use { c ->
                val now = System.currentTimeMillis() / 1000
                while (c.moveToNext()) {
                    val added = c.getLong(2)
                    if (now - added > 30) break
                    if (looksLikeScreenshot(c.getString(1).orEmpty(), c.getString(3).orEmpty())) return c.getLong(0)
                }
            }
        } catch (e: Throwable) {
            // lecture refusée ou galerie indisponible
        }
        return -1L
    }

    private fun looksLikeScreenshot(name: String, path: String): Boolean {
        val s = "$path/$name".lowercase()
        return listOf("screenshot", "screen_shot", "screen-shot", "screencap", "capture d", "capture_d", "capture-d", "capture écran", "capture_ecran")
            .any { it in s }
    }

    private fun smallThumb(uri: Uri): Bitmap? = try {
        val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, b) }
        var sample = 1
        while (max(b.outWidth, b.outHeight) / (sample * 2) >= 320) sample *= 2
        val o = BitmapFactory.Options().apply { inSampleSize = sample }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
    } catch (e: Throwable) {
        null
    }

    private fun onScreenshot(uri: Uri, thumb: Bitmap?) {
        job?.cancel()
        shotUri = uri
        shotThumb = thumb
        if (Prefs.hasOverlay(this)) {
            try { showOverlay(); return } catch (e: Throwable) { /* repli : notification */ }
        }
        render(Ui.Choose)
    }

    // ------------------------------------------------------------ actions (sans ouvrir l'app)

    private fun runOcr(uri: Uri) {
        job?.cancel()
        job = scope.launch {
            render(Ui.Working("Lecture du texte…"))
            try {
                val text = withContext(Dispatchers.Default) { Ocr.read(this@ScreenshotService, uri).text }.trim()
                val copied = text.isNotEmpty() && Actions.copy(this@ScreenshotService, text)
                render(Ui.TextDone(text, copied))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                render(Ui.Fail("Lecture impossible"))
            }
        }
    }

    private fun runPdf(uri: Uri) {
        job?.cancel()
        job = scope.launch {
            render(Ui.Working("Création du PDF…"))
            try {
                val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val name = "Capture_$stamp.pdf"
                val (file, pages) = withContext(Dispatchers.IO) { Export.imagesToPdf(this@ScreenshotService, listOf(uri), name) }
                val saved = withContext(Dispatchers.IO) { savePublic(file, name) }
                val open = saved ?: FileProvider.getUriForFile(this@ScreenshotService, "$packageName.files", file)
                render(Ui.PdfDone(file, open, if (saved != null) "Téléchargements/Extrait/$name" else null, pages))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                render(Ui.Fail("Création du PDF impossible"))
            }
        }
    }

    /** Enregistre le PDF dans Téléchargements/Extrait (Android 10+). Renvoie null si impossible. */
    private fun savePublic(file: File, name: String): Uri? {
        if (Build.VERSION.SDK_INT < 29) return null
        return try {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Extrait")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return null
            contentResolver.openOutputStream(uri)!!.use { o -> file.inputStream().use { it.copyTo(o) } }
            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
            uri
        } catch (e: Throwable) {
            null
        }
    }

    private fun openPdf(uri: Uri) {
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/pdf")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        try { startActivity(i) } catch (e: Throwable) { /* aucun lecteur de PDF */ }
    }

    // ------------------------------------------------------------ affichage

    private fun render(ui: Ui) {
        if (overlay != null) renderOverlay(ui) else renderNotification(ui)
    }

    private fun showOverlay() {
        hideOverlay()
        val wm = getSystemService(WindowManager::class.java)
        val d = resources.displayMetrics.density
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((14 * d).toInt(), (14 * d).toInt(), (10 * d).toInt(), (14 * d).toInt())
            background = GradientDrawable().apply { setColor(0xFF0E1530.toInt()); cornerRadius = 24 * d }
            elevation = 12 * d
            alpha = 0f
            translationY = 30 * d
        }
        val width = minOf(resources.displayMetrics.widthPixels - (24 * d).toInt(), (420 * d).toInt())
        val params = WindowManager.LayoutParams(
            width, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = (96 * d).toInt()
        }
        wm.addView(card, params)
        overlay = card
        overlayParams = params
        renderOverlay(Ui.Choose)
        card.animate().alpha(1f).translationY(0f).setDuration(220).start()
    }

    private fun hideOverlay() {
        main.removeCallbacks(hide)
        job?.cancel()
        val v = overlay ?: return
        overlay = null
        try { getSystemService(WindowManager::class.java).removeView(v) } catch (e: Throwable) { /* déjà retirée */ }
    }

    private fun scheduleHide(ms: Long) {
        main.removeCallbacks(hide)
        main.postDelayed(hide, ms)
    }

    private fun renderOverlay(ui: Ui) {
        val card = overlay ?: return
        val uri = shotUri
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        card.removeAllViews()

        fun pill(label: String, icon: Int?, bg: Int, fg: Int, onClick: () -> Unit) = TextView(this).apply {
            text = label
            setTextColor(fg)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            maxLines = 1
            setPadding(dp(10), dp(13), dp(10), dp(13))
            setAutoSizeTextTypeUniformWithConfiguration(10, 14, 1, TypedValue.COMPLEX_UNIT_SP)
            if (icon != null) {
                val dr = ContextCompat.getDrawable(this@ScreenshotService, icon)!!.mutate()
                dr.setTint(fg)
                setCompoundDrawablesRelativeWithIntrinsicBounds(dr, null, null, null)
                compoundDrawablePadding = dp(8)
            }
            background = GradientDrawable().apply { setColor(bg); cornerRadius = dp(16).toFloat() }
            setOnTouchListener { v, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> v.alpha = 0.7f
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.alpha = 1f
                }
                false
            }
            setOnClickListener { onClick() }
        }
        fun rowOf(vararg pills: TextView) = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            pills.forEachIndexed { k, p ->
                addView(p, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    if (k > 0) marginStart = dp(8)
                })
            }
        }

        val yellow = 0xFFFFC857.toInt()
        val navy = 0xFF0E1530.toInt()
        val glass = 0x26FFFFFF
        val white = 0xFFFFFFFF.toInt()

        val (title, sub) = when (ui) {
            is Ui.Choose -> "Capture d’écran" to "Que voulez-vous en faire ?"
            is Ui.Working -> ui.label to "Un instant…"
            is Ui.TextDone -> when {
                ui.text.isBlank() -> "Aucun texte détecté" to "Essayez avec une autre capture"
                ui.copied -> "Texte copié ✓" to "${ui.text.length} caractères dans le presse-papiers"
                else -> "Texte trop volumineux pour être copié" to "Utilisez Partager"
            }
            is Ui.PdfDone -> "PDF créé ✓" to (ui.where ?: "Prêt à partager")
            is Ui.Fail -> ui.message to ""
        }

        // En-tête : vignette + titre + croix
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val img = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(0xFF1C2A5E.toInt())
            shotThumb?.let { setImageBitmap(it) }
            clipToOutline = true
            outlineProvider = object : android.view.ViewOutlineProvider() {
                override fun getOutline(v: View, o: android.graphics.Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(10).toFloat()) }
            }
        }
        header.addView(img, LinearLayout.LayoutParams(dp(44), dp(58)))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(TextView(this).apply {
            text = title; setTextColor(white); setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f); typeface = Typeface.DEFAULT_BOLD
            maxLines = 2; ellipsize = TextUtils.TruncateAt.END
        })
        if (sub.isNotEmpty()) col.addView(TextView(this).apply {
            text = sub; setTextColor(0xFFB9C3E3.toInt()); setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            maxLines = 1; ellipsize = TextUtils.TruncateAt.MIDDLE
        })
        header.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(12) })
        header.addView(TextView(this).apply {
            text = "✕"; setTextColor(0xFFB9C3E3.toInt()); setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f); gravity = Gravity.CENTER
            setOnClickListener { hideOverlay() }
        }, LinearLayout.LayoutParams(dp(40), dp(40)))
        card.addView(header)

        fun lp() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(12); marginEnd = dp(4) }

        when (ui) {
            is Ui.Choose -> {
                card.addView(rowOf(
                    pill("Extraire le texte", R.drawable.ic_text, yellow, navy) { if (uri != null) runOcr(uri) },
                    pill("Numériser en PDF", R.drawable.ic_pdf, glass, white) { if (uri != null) runPdf(uri) }
                ), lp())
                scheduleHide(12_000)
            }
            is Ui.Working -> {
                card.addView(ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                    isIndeterminate = true
                    indeterminateTintList = ColorStateList.valueOf(yellow)
                }, lp())
                card.addView(rowOf(pill("Annuler", null, glass, white) { hideOverlay() }), lp())
                main.removeCallbacks(hide)
            }
            is Ui.TextDone -> {
                if (ui.text.isNotBlank()) {
                    card.addView(TextView(this).apply {
                        text = ui.text
                        setTextColor(0xFFE6ECFF.toInt()); setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
                        typeface = Typeface.MONOSPACE
                        maxLines = 4; ellipsize = TextUtils.TruncateAt.END
                        setPadding(dp(12), dp(10), dp(12), dp(10))
                        background = GradientDrawable().apply { setColor(0x1AFFFFFF); cornerRadius = dp(14).toFloat() }
                    }, lp())
                    card.addView(rowOf(
                        pill("Partager", null, yellow, navy) { Actions.share(this, ui.text); hideOverlay() },
                        pill("Fermer", null, glass, white) { hideOverlay() }
                    ), lp())
                } else {
                    card.addView(rowOf(pill("Fermer", null, glass, white) { hideOverlay() }), lp())
                }
                scheduleHide(25_000)
            }
            is Ui.PdfDone -> {
                card.addView(rowOf(
                    pill("Ouvrir", R.drawable.ic_pdf, yellow, navy) { openPdf(ui.uri); hideOverlay() },
                    pill("Partager", null, glass, white) { Export.share(this, ui.file, "application/pdf"); hideOverlay() }
                ), lp())
                scheduleHide(25_000)
            }
            is Ui.Fail -> {
                card.addView(rowOf(pill("Fermer", null, glass, white) { hideOverlay() }), lp())
                scheduleHide(8_000)
            }
        }
        try { getSystemService(WindowManager::class.java).updateViewLayout(card, overlayParams) } catch (e: Throwable) { /* fenêtre retirée */ }
    }

    // ------------------------------------------------------------ notifications (repli sans fenêtre flottante)

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_WATCH, "Surveillance des captures", NotificationManager.IMPORTANCE_MIN)
                .apply { description = "Notification discrète qui garde la détection active."; setShowBadge(false) }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_SHOT, "Capture d’écran détectée", NotificationManager.IMPORTANCE_HIGH)
                .apply { description = "Propose d’extraire le texte ou de créer un PDF."; setShowBadge(false) }
        )
    }

    private fun ongoingNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CH_WATCH)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Extrait surveille les captures d’écran")
            .setContentText("Appuyez pour ouvrir l’app")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
    }

    private fun serviceAction(code: Int, action: String, uri: Uri) = PendingIntent.getService(
        this, code, Intent(this, ScreenshotService::class.java).setAction(action).setData(uri),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun renderNotification(ui: Ui) {
        val b = Notification.Builder(this, CH_SHOT)
            .setSmallIcon(R.drawable.ic_notif)
            .setOnlyAlertOnce(true)
            .setAutoCancel(true)
            .setTimeoutAfter(60_000)
        shotThumb?.let { b.setLargeIcon(it) }
        val uri = shotUri
        when (ui) {
            is Ui.Choose -> {
                if (uri == null) return
                b.setContentTitle("Capture d’écran").setContentText("Que voulez-vous en faire ?")
                    .addAction(Notification.Action.Builder(null, "Extraire le texte", serviceAction(2, ACTION_OCR, uri)).build())
                    .addAction(Notification.Action.Builder(null, "Numériser en PDF", serviceAction(3, ACTION_PDF, uri)).build())
                    .setTimeoutAfter(30_000)
            }
            is Ui.Working -> b.setContentTitle(ui.label).setProgress(0, 0, true).setAutoCancel(false).setOngoing(true)
            is Ui.TextDone -> {
                b.setContentTitle(
                    when {
                        ui.text.isBlank() -> "Aucun texte détecté"
                        ui.copied -> "Texte copié ✓"
                        else -> "Texte trop volumineux pour être copié"
                    }
                ).setContentText(ui.text.take(120)).setStyle(Notification.BigTextStyle().bigText(ui.text.take(600)))
                if (ui.text.isNotBlank() && ui.text.length <= 50_000) {
                    val send = Intent.createChooser(
                        Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, ui.text), "Partager le texte"
                    )
                    val pi = PendingIntent.getActivity(this, 4, send, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                    b.addAction(Notification.Action.Builder(null, "Partager", pi).build())
                }
            }
            is Ui.PdfDone -> {
                val view = Intent(Intent.ACTION_VIEW).setDataAndType(ui.uri, "application/pdf")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                val share = Intent.createChooser(
                    Intent(Intent.ACTION_SEND).setType("application/pdf")
                        .putExtra(Intent.EXTRA_STREAM, FileProvider.getUriForFile(this, "$packageName.files", ui.file))
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION),
                    "Partager le PDF"
                )
                b.setContentTitle("PDF créé ✓").setContentText(ui.where ?: "Prêt à partager")
                    .setContentIntent(PendingIntent.getActivity(this, 5, view, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
                    .addAction(Notification.Action.Builder(null, "Partager", PendingIntent.getActivity(this, 6, share, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)).build())
            }
            is Ui.Fail -> b.setContentTitle(ui.message)
        }
        try {
            getSystemService(NotificationManager::class.java).notify(SHOT_ID, b.build())
        } catch (e: Throwable) { /* notifications refusées */ }
    }

    companion object {
        const val ACTION_OCR = "com.dlvibe.extrait.SHOT_OCR"
        const val ACTION_PDF = "com.dlvibe.extrait.SHOT_PDF"
        private const val CH_WATCH = "watch"
        private const val CH_SHOT = "shot"
        private const val ONGOING_ID = 1
        private const val SHOT_ID = 2

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, ScreenshotService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, ScreenshotService::class.java))
        }
    }
}
