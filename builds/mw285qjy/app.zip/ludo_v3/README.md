# Ludo Local — V3 (source de développement)

Projet Android dérivé du ZIP V2 fourni : Kotlin, Jetpack Compose et package `com.example.ludokotlin`. Cette archive ne remplace pas le projet par une maquette indépendante.

## Fonctionnalités présentes dans cette archive

- Sélection du mode **2D ou 3D par l'hôte** avant le lancement de la salle.
- QR contenant l'identifiant de salle, l'adresse, le port, le protocole, la capacité et le mode choisi.
- Le profil invité est demandé après le scan ; nom et avatar sont envoyés lors de la connexion.
- Serveur TCP local, validation du protocole, de l'identifiant, du mode, du nom et de la capacité à l'entrée.
- Événements réseau de connexion/déconnexion, transport de messages JSON bornés, fonction de diffusion hôte et fonction d'envoi client.
- Moteur de règles isolé : sortie sur 6, déplacement exact à l'arrivée, capture et cases protégées, victoire après les quatre pions.
- Plateau 2D dessiné en Compose.
- Scène 3D géométrique OpenGL ES 2.0 avec volumes, perspective, rotation et zoom par pincement.
- Paramètres d'effets sonores/vibrations, thèmes, profil photo/avatar et historique local en mémoire.
- Tests unitaires du moteur de jeu et workflow GitHub Actions pour compiler/tester le projet.

## Ouvrir et compiler

1. Extraire le ZIP.
2. Ouvrir le dossier `LudoKotlin_V3` dans Android Studio.
3. Installer JDK 17 et Android SDK Platform 35.
4. Synchroniser Gradle avec Android Gradle Plugin 8.7.3 (Gradle 8.9 recommandé).
5. Lancer `:app:testDebugUnitTest`, puis `:app:assembleDebug`.
6. L'APK, si la compilation réussit, sera créé dans `app/build/outputs/apk/debug/app-debug.apk`.

Le projet cible Android 8.0 (API 26) et ultérieur. Le scanner QR utilise la caméra ; le système de scan gère la demande de permission caméra.

## Utilisation réseau

- L'hôte et les invités doivent être sur le même Wi-Fi ou le même point d'accès mobile.
- L'hôte choisit le mode, démarre le serveur et partage le QR.
- L'invité scanne, renseigne son nom et choisit une photo ou un avatar, puis demande à rejoindre.
- Le serveur refuse les demandes dont le protocole, le mode ou l'identifiant de salle ne correspondent pas.

## État réel et limites à ne pas confondre avec une version de production

Cette archive est une **base V3 avancée, mais elle n'est pas encore une version finale certifiée jouable en réseau**. Les points suivants restent incomplets et ne sont donc pas annoncés comme terminés :

- L'interface de salle ne présente pas encore une liste complète et interactive des quatre profils, le bouton de lancement réservé à l'hôte et une fermeture de salle propagée à tous.
- Le moteur de jeu n'est pas encore raccordé à un protocole de commandes réseau autoritaire de bout en bout. Le transport TCP et les points d'entrée d'envoi/diffusion existent, mais les dés, déplacements, chat et réactions ne sont pas synchronisés en partie réelle.
- La reconnexion avec restauration d'état, attribution persistante des sièges et transmission des photos de profil ne sont pas terminées.
- Le mode 3D est un rendu géométrique OpenGL ES réel, mais les pions/dés ne sont pas encore pilotés par l'état du moteur ; il ne s'agit pas encore d'une partie 3D complète avec animations et effets finaux.
- Le plateau 2D est une représentation graphique de prototype, pas encore une cartographie fidèle et complète de toutes les 52 cases et des couloirs d'arrivée.
- L'IA configurable, la musique de fond, les statistiques persistantes et le chat multijoueur complet restent à finaliser.
- Les tests présents sont des tests unitaires du moteur. Aucun test multi-téléphone (2 à 4 appareils), test caméra/QR sur appareil physique ou test de reconnexion n'a été exécuté ici.

## Vérification de compilation dans cet environnement

Le code Kotlin du moteur `LudoEngine.kt` a été compilé isolément avec le compilateur Kotlin disponible. En revanche, cet environnement ne contient ni Gradle ni Android SDK : la compilation complète Android et la production d'un APK n'ont donc pas pu être exécutées ici. Le workflow `.github/workflows/android.yml` exécute les tests et la tâche `assembleDebug` sur GitHub Actions lorsque le projet est poussé dans un dépôt.

## Architecture

- `LudoEngine.kt` : règles et état du jeu, sans dépendance à Compose.
- `LanRoom.kt` : transport TCP local, validation de l'entrée et messages JSON.
- `MainActivity.kt` : écrans Compose, profils, QR, paramètres et plateau 2D.
- `Ludo3DView.kt` : scène OpenGL ES 2.0.
- `LudoEngineTest.kt` : tests unitaires du moteur.

## Dépendances et choix 3D

La scène 3D utilise OpenGL ES 2.0 natif afin de rester compatible avec le socle Android du projet. SceneView/Filament n'a pas été ajouté sans validation de compatibilité complète de la chaîne Gradle/SDK.
