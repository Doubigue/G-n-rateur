#!/usr/bin/env bash
set -euo pipefail
gradle :app:testDebugUnitTest :app:assembleDebug
