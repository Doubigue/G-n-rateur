package com.example.ludokotlin

import org.junit.Assert.*
import org.junit.Test

class LudoEngineTest {
    @Test fun playerCannotLeaveBaseWithoutSix() {
        val engine = LudoEngine(listOf(Player("A", Seat.RED), Player("B", Seat.GREEN)))
        engine.restore(engine.state.copy(dice = 5))
        assertFalse(engine.move(0))
        assertEquals(-1, engine.state.positions[0][0])
    }

    @Test fun playerLeavesBaseOnSixAndGetsAnotherTurn() {
        val engine = LudoEngine(listOf(Player("A", Seat.RED), Player("B", Seat.GREEN)))
        engine.restore(engine.state.copy(dice = 6))
        assertTrue(engine.move(0))
        assertEquals(0, engine.state.positions[0][0])
        assertEquals(0, engine.state.turn)
    }

    @Test fun exactFinishIsRequired() {
        val engine = LudoEngine(listOf(Player("A", Seat.RED), Player("B", Seat.GREEN)))
        val positions = listOf(listOf(55, 57, 57, 57), listOf(-1, -1, -1, -1))
        engine.restore(engine.state.copy(positions = positions, dice = 3))
        assertFalse(engine.move(0))
        assertEquals(55, engine.state.positions[0][0])
    }

    @Test fun allFourFinishedDeclaresWinner() {
        val engine = LudoEngine(listOf(Player("A", Seat.RED), Player("B", Seat.GREEN)))
        val positions = listOf(listOf(56, 57, 57, 57), listOf(-1, -1, -1, -1))
        engine.restore(engine.state.copy(positions = positions, dice = 1))
        assertTrue(engine.move(0))
        assertTrue(engine.state.finished)
        assertEquals("A", engine.state.winner)
    }

    @Test fun landingOnOpponentOnUnprotectedSquareCapturesIt() {
        val engine = LudoEngine(listOf(Player("A", Seat.RED), Player("B", Seat.GREEN)))
        val positions = listOf(listOf(0, -1, -1, -1), listOf(40, -1, -1, -1))
        engine.restore(engine.state.copy(positions = positions, dice = 1))
        assertTrue(engine.move(0))
        assertEquals(-1, engine.state.positions[1][0])
        assertEquals(0, engine.state.turn)
    }

    @Test fun protectedSquarePreventsCapture() {
        val engine = LudoEngine(listOf(Player("A", Seat.RED), Player("B", Seat.GREEN)))
        val positions = listOf(listOf(-1, -1, -1, -1), listOf(39, -1, -1, -1))
        engine.restore(engine.state.copy(positions = positions, dice = 6))
        assertTrue(engine.move(0))
        assertEquals(39, engine.state.positions[1][0])
    }

    @Test fun invalidRemoteStateIsIgnored() {
        val engine = LudoEngine(listOf(Player("A", Seat.RED), Player("B", Seat.GREEN)))
        val original = engine.state
        engine.restore(original.copy(positions = listOf(listOf(99, -1, -1, -1), listOf(-1, -1, -1, -1))))
        assertEquals(original, engine.state)
    }
}
