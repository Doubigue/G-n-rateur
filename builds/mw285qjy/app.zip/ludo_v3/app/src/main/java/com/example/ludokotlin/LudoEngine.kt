package com.example.ludokotlin

import kotlin.random.Random

enum class Seat(val label: String, val color: Long, val start: Int) {
    RED("Rouge", 0xFFE53935, 0),
    GREEN("Vert", 0xFF43A047, 13),
    YELLOW("Jaune", 0xFFFFC107, 26),
    BLUE("Bleu", 0xFF1E88E5, 39)
}

data class Player(val name: String, val seat: Seat, val isBot: Boolean = false)
data class GameState(
    val players: List<Player>,
    val positions: List<List<Int>> = players.map { listOf(-1, -1, -1, -1) },
    val turn: Int = 0,
    val dice: Int? = null,
    val message: String = "À ${players.firstOrNull()?.name ?: "Rouge"} de jouer",
    val finished: Boolean = false,
    val winner: String? = null
)

/**
 * Moteur Ludo indépendant de l'interface.
 * -1 = base, 0..51 = piste commune (progression personnelle), 52..57 = couloir final.
 * La progression est personnelle au joueur; Seat.start transforme une case en case globale.
 */
class LudoEngine(initialPlayers: List<Player>) {
    var state = GameState(initialPlayers)
        private set

    private val safeGlobalSquares = setOf(0, 8, 13, 21, 26, 34, 39, 47)

    fun legalMoves(die: Int = state.dice ?: 0): List<Int> {
        if (state.finished || state.players.isEmpty() || die !in 1..6) return emptyList()
        return state.positions[state.turn].indices.filter { token ->
            val current = state.positions[state.turn][token]
            when {
                current == -1 -> die == 6
                current >= 57 -> false
                current + die > 57 -> false
                else -> true
            }
        }
    }

    fun roll(): Int {
        if (state.finished || state.dice != null || state.players.isEmpty()) return state.dice ?: 0
        val value = Random.nextInt(1, 7)
        state = state.copy(dice = value, message = "${state.players[state.turn].name} a obtenu $value")
        if (legalMoves(value).isEmpty()) {
            state = state.copy(message = "Aucun déplacement possible")
        }
        return value
    }

    fun move(token: Int): Boolean {
        val die = state.dice ?: return false
        if (token !in 0..3 || token !in legalMoves(die)) return false
        val playerIndex = state.turn
        val player = state.players[playerIndex]
        val positions = state.positions.map { it.toMutableList() }.toMutableList()
        val current = positions[playerIndex][token]
        val next = if (current == -1) 0 else current + die
        positions[playerIndex][token] = next

        var captured = false
        if (next in 0..51) {
            val landingGlobal = (player.seat.start + next) % 52
            if (landingGlobal !in safeGlobalSquares) {
                positions.indices.filter { it != playerIndex }.forEach { other ->
                    positions[other].indices.forEach { otherToken ->
                        val otherProgress = positions[other][otherToken]
                        if (otherProgress in 0..51) {
                            val otherGlobal = (state.players[other].seat.start + otherProgress) % 52
                            if (otherGlobal == landingGlobal) {
                                positions[other][otherToken] = -1
                                captured = true
                            }
                        }
                    }
                }
            }
        }

        val won = positions[playerIndex].all { it == 57 }
        val bonus = die == 6 || captured
        val nextTurn = if (won || bonus) playerIndex else (playerIndex + 1) % state.players.size
        state = state.copy(
            positions = positions.map { it.toList() },
            turn = nextTurn,
            dice = null,
            finished = won,
            winner = if (won) player.name else null,
            message = when {
                won -> "${player.name} remporte la partie !"
                captured -> "Capture ! ${player.name} rejoue"
                die == 6 -> "${player.name} rejoue"
                else -> "À ${state.players[nextTurn].name} de jouer"
            }
        )
        return true
    }

    fun skip() {
        if (state.dice != null && legalMoves().isEmpty() && !state.finished) {
            val n = (state.turn + 1) % state.players.size
            state = state.copy(turn = n, dice = null, message = "À ${state.players[n].name} de jouer")
        }
    }

    /** Applique un état validé par l'hôte lors de la synchronisation réseau. */
    fun restore(remote: GameState) {
        if (remote.players.size in 2..4 &&
            remote.positions.size == remote.players.size &&
            remote.positions.all { it.size == 4 && it.all { p -> p in -1..57 } } &&
            remote.turn in remote.players.indices
        ) state = remote
    }
}
