package com.example.ludokotlin

import org.json.JSONObject
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.concurrent.thread

/** Transport TCP ligne-par-ligne pour un réseau Wi-Fi/point d'accès local. */
class LanRoom {
    companion object {
        const val PORT = 47621
        const val PROTOCOL = 3
    }

    private var server: ServerSocket? = null
    private val clients = CopyOnWriteArrayList<Socket>()
    private val clientWriters = ConcurrentHashMap<Socket, Any>()
    private val playerNames = CopyOnWriteArrayList<String>()
    @Volatile private var clientSocket: Socket? = null
    @Volatile private var roomId: String = ""
    @Volatile private var selectedMode: String = "2D"
    @Volatile private var capacity: Int = 4
    @Volatile var onMessage: ((String) -> Unit)? = null

    fun startHost(
        mode: String,
        maxPlayers: Int,
        onReady: (String, String) -> Unit,
        onError: (String) -> Unit
    ) {
        require(mode == "2D" || mode == "3D")
        require(maxPlayers in 2..4)
        thread(name = "ludo-host") {
            try {
                close()
                selectedMode = mode
                capacity = maxPlayers
                roomId = UUID.randomUUID().toString()
                val socketServer = ServerSocket(PORT)
                server = socketServer
                val ip = try {
                    NetworkInterface.getNetworkInterfaces().toList()
                        .flatMap { it.inetAddresses.toList() }
                        .firstOrNull { !it.isLoopbackAddress && it.hostAddress?.contains(':') == false }
                        ?.hostAddress ?: "192.168.43.1"
                } catch (_: Exception) { "192.168.43.1" }
                onReady(ip, roomId)
                while (!socketServer.isClosed) {
                    val socket = socketServer.accept()
                    thread(name = "ludo-client-handler") { handleClient(socket) }
                }
            } catch (e: Exception) {
                if (server?.isClosed != true) onError(e.message ?: "Erreur réseau")
            }
        }
    }

    private fun sendLine(socket: Socket, payload: JSONObject) {
        synchronized(clientWriters.getOrPut(socket) { Any() }) {
            val bytes = (payload.toString() + "\n").toByteArray(Charsets.UTF_8)
            socket.getOutputStream().write(bytes)
            socket.getOutputStream().flush()
        }
    }

    private fun handleClient(socket: Socket) {
        var acceptedName: String? = null
        try {
            socket.soTimeout = 12_000
            val reader = socket.getInputStream().bufferedReader()
            val helloLine = reader.readLine() ?: throw IllegalArgumentException("Connexion vide")
            val hello = JSONObject(helloLine)
            val name = hello.optString("name").trim().take(20)
            val requestedMode = hello.optString("gameMode")
            val requestedRoom = hello.optString("roomId")
            val protocol = hello.optInt("protocol", -1)
            val rejection = when {
                protocol != PROTOCOL -> "Version du jeu incompatible"
                requestedRoom != roomId -> "Cette salle n'existe plus"
                requestedMode != selectedMode -> "Le mode ne correspond pas à celui de l'hôte"
                name.isBlank() -> "Nom de joueur obligatoire"
                playerNames.size >= capacity - 1 -> "Salle complète"
                playerNames.any { it.equals(name, ignoreCase = true) } -> "Ce nom est déjà utilisé"
                else -> null
            }
            if (rejection != null) {
                sendLine(socket, JSONObject().put("type", "reject").put("reason", rejection))
                return
            }

            acceptedName = name
            playerNames += name
            clients += socket
            socket.soTimeout = 0
            sendLine(socket, JSONObject().put("type", "welcome")
                .put("roomId", roomId).put("gameMode", selectedMode)
                .put("capacity", capacity).put("hostAuthoritative", true))
            onMessage?.invoke(JSONObject().put("type", "player_joined")
                .put("name", name).put("avatar", hello.optString("avatar", "😀")).toString())

            reader.forEachLine { line ->
                try {
                    if (line.length > 16_384) return@forEachLine
                    val msg = JSONObject(line)
                    // Les clients ne peuvent pas modifier les métadonnées de la salle.
                    if (msg.optString("roomId", roomId) != roomId ||
                        msg.optString("gameMode", selectedMode) != selectedMode) return@forEachLine
                    msg.put("sender", name)
                    when (msg.optString("type")) {
                        "chat", "reaction", "ready", "ping" -> onMessage?.invoke(msg.toString())
                        // Les commandes de jeu ne sont jamais relayées comme état validé.
                        "game_command" -> onMessage?.invoke(msg.toString())
                    }
                } catch (_: Exception) { }
            }
        } catch (e: Exception) {
            onMessage?.invoke(JSONObject().put("type", "network_error")
                .put("message", e.message ?: "Déconnexion").toString())
        } finally {
            clients.remove(socket)
            clientWriters.remove(socket)
            acceptedName?.let { playerNames.remove(it) }
            if (acceptedName != null) onMessage?.invoke(JSONObject().put("type", "player_left")
                .put("name", acceptedName).toString())
            try { socket.close() } catch (_: Exception) { }
        }
    }

    fun connect(
        ip: String, port: Int, roomId: String, gameMode: String,
        playerName: String, avatar: String,
        onConnected: (String) -> Unit, onError: (String) -> Unit
    ) {
        require(gameMode == "2D" || gameMode == "3D")
        this.roomId = roomId
        this.selectedMode = gameMode
        thread(name = "ludo-client") {
            try {
                val socket = Socket(ip, port)
                socket.soTimeout = 12_000
                val writerLock = Any()
                clientWriters[socket] = writerLock
                sendLine(socket, JSONObject().put("type", "join").put("protocol", PROTOCOL)
                    .put("roomId", roomId).put("gameMode", gameMode)
                    .put("name", playerName.trim().take(20)).put("avatar", avatar))
                val reader = socket.getInputStream().bufferedReader()
                val response = reader.readLine()
                    ?: throw IllegalStateException("L'hôte a fermé la connexion")
                val reply = JSONObject(response)
                if (reply.optString("type") != "welcome") {
                    socket.close()
                    throw IllegalStateException(reply.optString("reason", "Connexion refusée"))
                }
                if (reply.optString("gameMode") != gameMode || reply.optString("roomId") != roomId) {
                    socket.close()
                    throw IllegalStateException("Configuration de salle invalide")
                }
                socket.soTimeout = 0
                clientSocket = socket
                onConnected(reply.optString("gameMode"))
                thread(name = "ludo-client-reader") {
                    try {
                        reader.forEachLine { line ->
                            if (line.length <= 16_384) onMessage?.invoke(line)
                        }
                    } catch (_: Exception) { }
                    finally {
                        if (clientSocket === socket) clientSocket = null
                        clientWriters.remove(socket)
                        try { socket.close() } catch (_: Exception) { }
                        onMessage?.invoke(JSONObject().put("type", "disconnected").toString())
                    }
                }
            } catch (e: Exception) {
                onError(e.message ?: "Connexion impossible")
            }
        }
    }

    /** Envoie une commande/chat/réaction de l'invité vers l'hôte. */
    fun sendToHost(json: JSONObject): Boolean {
        val socket = clientSocket ?: return false
        return try {
            val payload = JSONObject(json.toString())
            payload.put("roomId", roomId).put("gameMode", selectedMode)
            sendLine(socket, payload)
            true
        } catch (_: Exception) { false }
    }

    /** Diffuse un événement validé par l'hôte à tous les invités. */
    fun broadcast(json: JSONObject) {
        val payload = JSONObject(json.toString())
            .put("roomId", roomId).put("gameMode", selectedMode)
        clients.toList().forEach { socket ->
            try { sendLine(socket, payload) }
            catch (_: Exception) { clients.remove(socket); try { socket.close() } catch (_: Exception) { } }
        }
    }

    fun close() {
        try { server?.close() } catch (_: Exception) { }
        server = null
        try { clientSocket?.close() } catch (_: Exception) { }
        clientSocket = null
        clients.forEach { try { it.close() } catch (_: Exception) { } }
        clients.clear()
        clientWriters.clear()
        playerNames.clear()
    }
}
