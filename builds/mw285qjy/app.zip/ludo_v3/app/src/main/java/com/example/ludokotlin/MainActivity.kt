package com.example.ludokotlin

import android.os.Bundle
import android.media.ToneGenerator
import android.media.AudioManager
import android.os.Vibrator
import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.Canvas
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import android.graphics.Bitmap
import android.graphics.Color as AndroidColor
import android.graphics.ImageDecoder
import android.provider.MediaStore
import android.os.Build
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import org.json.JSONObject
import java.net.InetAddress

data class UserProfile(val name: String, val photo: Uri? = null, val avatar: String = "😀")
data class RoomInvite(val ip: String, val port: Int, val host: String, val roomId: String, val gameMode: String, val maxPlayers: Int)

class MainActivity : ComponentActivity() {
    private var scannedInvite by mutableStateOf<RoomInvite?>(null)
    private val scanner = registerForActivityResult(ScanContract()) { result ->
        if (result.contents != null) {
            try {
                val data = JSONObject(result.contents)
                if (data.optString("app") != "LUDO_LOCAL") throw IllegalArgumentException()
                val mode = data.optString("gameMode", "2D")
                if (mode != "2D" && mode != "3D") throw IllegalArgumentException()
                scannedInvite = RoomInvite(data.getString("ip"), data.optInt("port", LanRoom.PORT),
                    data.optString("host", "Hôte"), data.getString("roomId"), mode, data.optInt("maxPlayers", 4))
            } catch (_: Exception) {
                Toast.makeText(this, "QR Ludo invalide", Toast.LENGTH_SHORT).show()
            }
        }
    }
    private val room = LanRoom()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LudoApp(
                scannedInvite = scannedInvite,
                onInviteConsumed = { scannedInvite = null },
                onScan = { scanner.launch(ScanOptions().setPrompt("Scanne le QR de l'hôte").setBeepEnabled(true).setOrientationLocked(false)) },
                onHost = { mode, maxPlayers, ready -> room.startHost(mode, maxPlayers,
                    { ip, roomId -> runOnUiThread { ready(ip, roomId) } },
                    { err -> runOnUiThread { Toast.makeText(this, err, Toast.LENGTH_LONG).show() } }) },
                onConnect = { invite, profile ->
                    room.connect(invite.ip, invite.port, invite.roomId, invite.gameMode, profile.name, profile.avatar,
                        { mode -> runOnUiThread { Toast.makeText(this, "Connecté en mode $mode à ${invite.host}", Toast.LENGTH_LONG).show() } },
                        { err -> runOnUiThread { Toast.makeText(this, err, Toast.LENGTH_LONG).show() } })
                },
                onStopHost = { room.close() }
            )
        }
    }
    override fun onDestroy() { room.close(); super.onDestroy() }
}

@Composable
fun LudoApp(
    scannedInvite: RoomInvite?,
    onInviteConsumed: () -> Unit,
    onScan: () -> Unit,
    onHost: (String, Int, (String, String) -> Unit) -> Unit,
    onConnect: (RoomInvite, UserProfile) -> Unit,
    onStopHost: () -> Unit
) {
    var screen by remember { mutableStateOf("home") }
    var profile by remember { mutableStateOf(UserProfile("Joueur")) }
    var editName by remember { mutableStateOf(profile.name) }
    var editAvatar by remember { mutableStateOf(profile.avatar) }
    var editPhoto by remember { mutableStateOf<Uri?>(null) }
    var pendingProfile by remember { mutableStateOf(false) }
    var pendingInvite by remember { mutableStateOf<RoomInvite?>(null) }
    var hostIp by remember { mutableStateOf("") }
    var qrText by remember { mutableStateOf("") }
    var maxPlayers by remember { mutableIntStateOf(4) }
    var selectedGameMode by remember { mutableStateOf("2D") }
    var roomId by remember { mutableStateOf("") }
    var joinedMode by remember { mutableStateOf("2D") }
    var sound by remember { mutableStateOf(true) }
    var music by remember { mutableStateOf(true) }
    var vibration by remember { mutableStateOf(true) }
    var theme by remember { mutableStateOf("Classique") }
    var difficulty by remember { mutableStateOf("Normale") }
    var chatText by remember { mutableStateOf("") }
    var chat by remember { mutableStateOf(listOf("🎉 Bienvenue dans Ludo Local !")) }
    var reactions by remember { mutableStateOf(listOf("👏", "😂", "🔥", "😎", "😮", "❤️")) }
    var history by remember { mutableStateOf(listOf("Aucune partie terminée pour le moment")) }
    var engine by remember { mutableStateOf(LudoEngine(listOf(Player(profile.name, Seat.RED), Player("Ordinateur", Seat.GREEN, true)))) }
    var game by remember { mutableStateOf(engine.state) }
    val context = LocalContext.current
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        editPhoto = uri
    }
    LaunchedEffect(scannedInvite) {
        if (scannedInvite != null) {
            pendingInvite = scannedInvite
            editName = ""
            editAvatar = profile.avatar
            editPhoto = null
            pendingProfile = true
        }
    }
    MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF5B35A5), secondary = Color(0xFFFFB300))) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFFF4F1FA)) {
            when (screen) {
                "home" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp), verticalArrangement = Arrangement.spacedBy(13.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Spacer(Modifier.height(18.dp))
                    Text("🎲 LUDO LOCAL", fontSize = 34.sp, color = Color(0xFF4D2A91))
                    Text("Joue avec tes amis, même sans Internet", color = Color.DarkGray)
                    ProfileBadge(profile)
                    OutlinedButton(onClick = { editName = profile.name; editAvatar = profile.avatar; editPhoto = profile.photo; screen = "profile" }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Person, null); Text("  Mon profil") }
                    Button(onClick = {
                        engine = LudoEngine(listOf(Player(profile.name, Seat.RED), Player("Ordinateur", Seat.GREEN, true)))
                        game = engine.state; screen = "game"
                    }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.SmartToy, null); Text("  Jouer contre l'ordinateur") }
                    Button(onClick = { screen = "host" }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Wifi, null); Text("  Créer une partie locale") }
                    OutlinedButton(onClick = onScan, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.QrCodeScanner, null); Text("  Scanner un QR pour rejoindre") }
                    OutlinedButton(onClick = { screen = "settings" }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Settings, null); Text("  Paramètres et thèmes") }
                    OutlinedButton(onClick = { screen = "history" }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.EmojiEvents, null); Text("  Historique et statistiques") }
                    Text("Jusqu'à 4 joueurs • Réseau local • Sans Internet", color = Color.Gray, fontSize = 12.sp)
                }
                "profile" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("Ton profil joueur", fontSize = 28.sp, color = Color(0xFF4D2A91))
                    ProfileBadge(UserProfile(editName, editPhoto, editAvatar), 92)
                    OutlinedTextField(editName, { editName = it.take(20) }, label = { Text("Nom de joueur") }, singleLine = true)
                    Text("Choisis un avatar", style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("😀","😎","🐼","🦁","🐯","🐸").forEach { a ->
                            Text(a, fontSize = 28.sp, modifier = Modifier.clip(CircleShape).background(if (editAvatar == a && editPhoto == null) Color(0xFFDCD0F5) else Color.White).clickable { editAvatar = a; editPhoto = null }.padding(8.dp))
                        }
                    }
                    OutlinedButton(onClick = { photoPicker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.AddAPhoto, null); Text("  Choisir une photo depuis la galerie") }
                    if (editPhoto != null) Text("Photo sélectionnée ✓", color = Color(0xFF388E3C))
                    Button(onClick = { profile = UserProfile(editName.ifBlank { "Joueur" }, editPhoto, editAvatar); screen = "home"; pendingProfile = false }, modifier = Modifier.fillMaxWidth()) { Text("Enregistrer le profil") }
                    Text("Tu peux utiliser une photo personnelle ou choisir un avatar illustré.", color = Color.Gray, fontSize = 12.sp)
                    TextButton(onClick = { screen = "home" }) { Text("Retour") }
                }
                "host" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("Créer une salle", fontSize = 28.sp)
                    ProfileBadge(profile)
                    Text("Hôte : ${profile.name}")
                    Text("Nombre maximum de joueurs")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { (2..4).forEach { n -> FilterChip(selected = maxPlayers == n, onClick = { maxPlayers = n }, label = { Text("$n joueurs") }) } }
                    Text("Mode de jeu (choix réservé à l'hôte)", style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        FilterChip(selected = selectedGameMode == "2D", onClick = { selectedGameMode = "2D" }, label = { Text("🎲 Plateau 2D") })
                        FilterChip(selected = selectedGameMode == "3D", onClick = { selectedGameMode = "3D" }, label = { Text("🧊 Plateau 3D") })
                    }
                    Text("1. Active ton point d'accès mobile ou connecte-toi au même Wi-Fi.")
                    Text("2. Démarre le serveur puis partage le QR.")
                    Button(onClick = {
                        onHost(selectedGameMode, maxPlayers) { ip, id ->
                            hostIp = ip
                            roomId = id
                            qrText = JSONObject().put("app","LUDO_LOCAL").put("protocol",LanRoom.PROTOCOL)
                                .put("ip",ip).put("port",LanRoom.PORT).put("host",profile.name)
                                .put("maxPlayers",maxPlayers).put("roomId",id).put("gameMode",selectedGameMode).toString()
                        }
                    }) { Icon(Icons.Default.QrCode, null); Text("  Démarrer la salle") }
                    if (qrText.isNotBlank()) {
                        QrCode(qrText)
                        Text("Les invités scannent ce QR puis créent leur profil.")
                        Text("Adresse : $hostIp:${LanRoom.PORT}")
                        Text("Salle ouverte • ${maxPlayers} places maximum • Mode $selectedGameMode")
                        Text("Les appareils doivent être sur le même réseau local.")
                    }
                    OutlinedButton(onClick = { onStopHost(); qrText = ""; screen = "home" }) { Icon(Icons.Default.Stop, null); Text("  Terminer la salle") }
                }
                "game" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) { Text("LUDO • ${joinedMode}", fontSize = 28.sp, color = Color(0xFF4D2A91), modifier = Modifier.weight(1f)); Text("🎵 ${if (sound) "ON" else "OFF"}") }
                    Text(game.message, style = MaterialTheme.typography.titleMedium)
                    if (joinedMode == "3D") {
                        AndroidView(factory = { Ludo3DView(it) }, modifier = Modifier.fillMaxWidth().height(360.dp))
                        Text("Plateau 3D • fais glisser pour tourner la caméra", color = Color.Gray, fontSize = 12.sp)
                    } else {
                        Board(game, theme)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = { engine.roll(); game = engine.state; if (sound) playTone(context, vibration) }) { Text("🎲 Lancer ${game.dice?.let { "($it)" } ?: ""}") }
                        OutlinedButton(onClick = { engine.skip(); game = engine.state }) { Text("Passer") }
                    }
                    Text("Choisis un pion après le lancer")
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { (0..3).forEach { i -> Button(onClick = { engine.move(i); game = engine.state; if (game.finished) history = listOf("${profile.name} — victoire en mode solo") + history }, enabled = game.dice != null) { Text("Pion ${i+1}") } }
                    }
                    Text("Réactions rapides")
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) { reactions.forEach { e -> Text(e, fontSize = 25.sp, modifier = Modifier.clickable { chat = chat + "${profile.name} : $e" }) } }
                    Text("Discussion", style = MaterialTheme.typography.titleMedium)
                    chat.takeLast(4).forEach { Text(it, fontSize = 12.sp, modifier = Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(8.dp)).padding(7.dp)) }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(chatText, { chatText = it }, modifier = Modifier.weight(1f), placeholder = { Text("Message rapide") }, singleLine = true)
                        IconButton(onClick = { if (chatText.isNotBlank()) { chat = chat + "${profile.name} : $chatText"; chatText = "" } }) { Icon(Icons.Default.Send, null) }
                    }
                    OutlinedButton(onClick = { screen = "home" }) { Text("Quitter la partie") }
                }
                "settings" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp), verticalArrangement = Arrangement.spacedBy(15.dp)) {
                    Text("Paramètres", fontSize = 28.sp)
                    SettingSwitch("Effets sonores", sound) { sound = it }
                    SettingSwitch("Musique d'ambiance", music) { music = it }
                    SettingSwitch("Vibrations", vibration) { vibration = it }
                    Text("Thème du plateau")
                    listOf("Classique","Nuit néon","Jungle","Océan").forEach { FilterChip(selected = theme == it, onClick = { theme = it }, label = { Text(it) }) }
                    Text("Difficulté de l'ordinateur")
                    listOf("Facile","Normale","Difficile").forEach { FilterChip(selected = difficulty == it, onClick = { difficulty = it }, label = { Text(it) }) }
                    Text("Options supplémentaires : chronomètre, règles personnalisées et mode tournoi seront activables dans la version complète.", color = Color.Gray)
                    Button(onClick = { screen = "home" }) { Text("Enregistrer et revenir") }
                }
                "history" -> Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Historique", fontSize = 28.sp)
                    Text("Victoires récentes")
                    LazyColumn { items(history) { Text("🏆  $it", modifier = Modifier.fillMaxWidth().padding(8.dp).background(Color.White, RoundedCornerShape(8.dp)).padding(10.dp)) } }
                    Button(onClick = { screen = "home" }) { Text("Retour") }
                }
            }
        }
    }
    if (pendingProfile && pendingInvite != null) {
        AlertDialog(
            onDismissRequest = { pendingProfile = false; pendingInvite = null; onInviteConsumed() },
            title = { Text("Rejoindre ${pendingInvite!!.host}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Mode imposé par l'hôte : ${pendingInvite!!.gameMode}. Tu ne peux pas le modifier.")
                    Text("Avant de rejoindre, crée ton profil.")
                    OutlinedTextField(editName, { editName = it.take(20) }, label = { Text("Ton nom") }, singleLine = true, isError = editName.isBlank())
                    Text("Choisis ton avatar")
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { listOf("😀","😎","🐼","🦁","🐯","🐸").forEach { a -> Text(a, fontSize = 25.sp, modifier = Modifier.clickable { editAvatar = a; editPhoto = null }.padding(3.dp)) } }
                    OutlinedButton(onClick = { photoPicker.launch("image/*") }) { Icon(Icons.Default.AddAPhoto, null); Text("Ajouter une photo") }
                    if (editPhoto != null) Text("Photo choisie ✓")
                }
            },
            confirmButton = { TextButton(enabled = editName.isNotBlank(), onClick = {
                if (editName.isBlank()) return@TextButton
                val p = UserProfile(editName.trim(), editPhoto, editAvatar)
                profile = p
                joinedMode = pendingInvite!!.gameMode
                onConnect(pendingInvite!!, p)
                pendingProfile = false; pendingInvite = null; onInviteConsumed(); screen = "game"
            }) { Text("Rejoindre") } },
            dismissButton = { TextButton(onClick = { pendingProfile = false; pendingInvite = null; onInviteConsumed() }) { Text("Annuler") } }
        )
    }
}

@Composable fun SettingSwitch(label: String, checked: Boolean, onChange: (Boolean)->Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) { Text(label, modifier = Modifier.weight(1f)); Switch(checked, onChange) }
}
@Composable fun ProfileBadge(profile: UserProfile, size: Int = 64) {
    Box(Modifier.size(size.dp).clip(CircleShape).background(Color(0xFFE3D9F5)), contentAlignment = Alignment.Center) {
        if (profile.photo != null) {
            val context = LocalContext.current
            val bitmap = remember(profile.photo) { try {
                if (Build.VERSION.SDK_INT >= 28) ImageDecoder.decodeBitmap(ImageDecoder.createSource(context.contentResolver, profile.photo))
                else MediaStore.Images.Media.getBitmap(context.contentResolver, profile.photo)
            } catch (_: Exception) { null } }
            if (bitmap != null) androidx.compose.foundation.Image(bitmap.asImageBitmap(), null, Modifier.fillMaxSize())
            else Text(profile.avatar, fontSize = (size/2).sp)
        } else Text(profile.avatar, fontSize = (size/2).sp)
    }
    Text(profile.name, style = MaterialTheme.typography.titleMedium)
}
@Composable fun Board(state: GameState, theme: String) {
    val dark = theme == "Nuit néon"
    val background = when(theme) {
        "Nuit néon" -> Color(0xFF202039)
        "Jungle" -> Color(0xFFE3F1D8)
        "Océan" -> Color(0xFFD9F1F8)
        else -> Color(0xFFFFFDF8)
    }
    val seats = listOf(
        Color(0xFFE53935), Color(0xFF1E88E5),
        Color(0xFF43A047), Color(0xFFFFC107)
    )
    Column(Modifier.fillMaxWidth().background(background, RoundedCornerShape(14.dp)).padding(8.dp)) {
        Canvas(Modifier.fillMaxWidth().aspectRatio(1f)) {
            val cell = size.width / 15f
            drawRect(background)
            // Quatre bases en quartiers.
            val bases = listOf(
                0 to 0, 9 to 0, 0 to 9, 9 to 9
            )
            bases.forEachIndexed { index, (x, y) ->
                drawRect(seats[index], androidx.compose.ui.geometry.Offset(x*cell, y*cell),
                    androidx.compose.ui.geometry.Size(6*cell, 6*cell))
                drawRect(Color.White, androidx.compose.ui.geometry.Offset((x+1)*cell, (y+1)*cell),
                    androidx.compose.ui.geometry.Size(4*cell, 4*cell))
                val centers = listOf(
                    2.2f to 2.2f, 3.8f to 2.2f, 2.2f to 3.8f, 3.8f to 3.8f
                )
                centers.forEachIndexed { pawn, (cx, cy) ->
                    drawCircle(seats[index], cell*.43f,
                        androidx.compose.ui.geometry.Offset((x+cx)*cell, (y+cy)*cell))
                    drawCircle(Color.White, cell*.28f,
                        androidx.compose.ui.geometry.Offset((x+cx)*cell, (y+cy)*cell))
                }
            }
            // Piste en croix (cases).
            for (row in 0..14) for (col in 0..14) {
                if ((row in 6..8) || (col in 6..8)) {
                    val fill = when {
                        row == 7 && col in 1..5 -> seats[0]
                        col == 7 && row in 1..5 -> seats[1]
                        row == 7 && col in 9..13 -> seats[2]
                        col == 7 && row in 9..13 -> seats[3]
                        else -> Color(0xFFF3F0E8)
                    }
                    drawRect(fill, androidx.compose.ui.geometry.Offset(col*cell, row*cell),
                        androidx.compose.ui.geometry.Size(cell, cell))
                    drawRect(Color(0xFF8A8178), androidx.compose.ui.geometry.Offset(col*cell, row*cell),
                        androidx.compose.ui.geometry.Size(cell, cell), style = Stroke(1f))
                }
            }
            // Centre en étoile stylisée et pions actuellement en piste.
            drawRect(Color(0xFF5B35A5), androidx.compose.ui.geometry.Offset(6*cell, 6*cell),
                androidx.compose.ui.geometry.Size(3*cell, 3*cell))
            state.players.forEachIndexed { playerIndex, player ->
                state.positions[playerIndex].forEachIndexed { tokenIndex, position ->
                    if (position >= 0) {
                        val trackIndex = (position.coerceAtMost(51) + player.seat.start) % 52
                        val point = when (trackIndex % 12) {
                            0 -> 1f to 6.5f
                            1 -> 2f to 6.5f
                            2 -> 3f to 6.5f
                            3 -> 4f to 6.5f
                            4 -> 5f to 6.5f
                            5 -> 6.5f to 5f
                            6 -> 6.5f to 4f
                            7 -> 6.5f to 3f
                            8 -> 6.5f to 2f
                            9 -> 6.5f to 1f
                            10 -> 7.5f to 1f
                            else -> 8.5f to 1f
                        }
                        val x = (point.first + (playerIndex%2)*.16f) * cell
                        val y = (point.second + (tokenIndex%2)*.16f) * cell
                        drawCircle(Color(player.seat.color), cell*.28f, androidx.compose.ui.geometry.Offset(x,y))
                    }
                }
            }
        }
        Text("Plateau Ludo • quatre bases • piste et couloirs d'arrivée",
            color = if(dark) Color.LightGray else Color.DarkGray, fontSize = 11.sp)
    }
}
@Composable fun QrCode(value: String) {
    val bitmap = remember(value) {
        val matrix = QRCodeWriter().encode(value, BarcodeFormat.QR_CODE, 420, 420)
        Bitmap.createBitmap(420,420,Bitmap.Config.RGB_565).also { bmp ->
            for(x in 0 until 420) for(y in 0 until 420) bmp.setPixel(x,y,if(matrix[x,y]) AndroidColor.BLACK else AndroidColor.WHITE)
        }
    }
    androidx.compose.foundation.Image(bitmap.asImageBitmap(), "QR code de la salle", Modifier.size(230.dp))
}
fun playTone(context: Context, vibrate: Boolean) {
    try { ToneGenerator(AudioManager.STREAM_MUSIC, 70).startTone(ToneGenerator.TONE_PROP_BEEP, 120) } catch (_: Exception) {}
    if (vibrate) try { (context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).vibrate(45) } catch (_: Exception) {}
}
