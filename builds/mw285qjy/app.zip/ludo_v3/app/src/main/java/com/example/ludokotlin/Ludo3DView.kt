package com.example.ludokotlin

import android.content.Context
import android.opengl.GLSurfaceView
import android.opengl.GLES20
import android.opengl.Matrix
import android.view.MotionEvent
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.max

/**
 * Plateau procédural OpenGL ES 2.0 : géométrie 3D réelle, éclairage simple,
 * perspective, rotation et zoom tactiles. Aucun bitmap 2D ne simule la scène.
 */
class Ludo3DView(context: Context) : GLSurfaceView(context) {
    private val gameRenderer = BoardRenderer()
    private var previousX = 0f
    private var previousY = 0f
    private var previousPinch = 0f

    init {
        setEGLContextClientVersion(2)
        setRenderer(gameRenderer)
        renderMode = RENDERMODE_CONTINUOUSLY
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                previousX = event.x
                previousY = event.y
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (event.pointerCount >= 2) {
                    val distance = pointerDistance(event)
                    if (previousPinch > 0f && distance > 0f) gameRenderer.zoomBy(distance / previousPinch)
                    previousPinch = distance
                    return true
                }
                val dx = event.x - previousX
                val dy = event.y - previousY
                gameRenderer.rotate(dx * 0.55f, dy * 0.35f)
                previousX = event.x
                previousY = event.y
                return true
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (event.pointerCount >= 2) previousPinch = pointerDistance(event)
                return true
            }
            MotionEvent.ACTION_POINTER_UP -> {
                previousPinch = 0f
                return true
            }
        }
        return true
    }

    private fun pointerDistance(event: MotionEvent): Float {
        val dx = event.getX(0) - event.getX(1)
        val dy = event.getY(0) - event.getY(1)
        return kotlin.math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
    }

    private class BoardRenderer : Renderer {
        @Volatile private var yaw = -35f
        @Volatile private var pitch = 48f
        @Volatile private var zoom = 1f
        private val projection = FloatArray(16)
        private val view = FloatArray(16)
        private val model = FloatArray(16)
        private val modelView = FloatArray(16)
        private val mvp = FloatArray(16)
        private var program = 0
        private var positionHandle = 0
        private var matrixHandle = 0
        private var colorHandle = 0
        private lateinit var cube: FloatBuffer

        private val vertexShader = """
            uniform mat4 uMVP;
            attribute vec3 aPosition;
            void main() { gl_Position = uMVP * vec4(aPosition, 1.0); }
        """.trimIndent()
        private val fragmentShader = """
            precision mediump float;
            uniform vec4 uColor;
            void main() { gl_FragColor = uColor; }
        """.trimIndent()

        override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
            GLES20.glClearColor(0.91f, 0.93f, 0.97f, 1f)
            GLES20.glEnable(GLES20.GL_DEPTH_TEST)
            program = linkProgram(vertexShader, fragmentShader)
            positionHandle = GLES20.glGetAttribLocation(program, "aPosition")
            matrixHandle = GLES20.glGetUniformLocation(program, "uMVP")
            colorHandle = GLES20.glGetUniformLocation(program, "uColor")
            val vertices = floatArrayOf(
                -0.5f,-0.5f, 0.5f,  0.5f,-0.5f, 0.5f,  0.5f, 0.5f, 0.5f,
                -0.5f,-0.5f, 0.5f,  0.5f, 0.5f, 0.5f, -0.5f, 0.5f, 0.5f,
                -0.5f,-0.5f,-0.5f, -0.5f, 0.5f,-0.5f,  0.5f, 0.5f,-0.5f,
                -0.5f,-0.5f,-0.5f,  0.5f, 0.5f,-0.5f,  0.5f,-0.5f,-0.5f,
                -0.5f,-0.5f,-0.5f, -0.5f,-0.5f, 0.5f, -0.5f, 0.5f, 0.5f,
                -0.5f,-0.5f,-0.5f, -0.5f, 0.5f, 0.5f, -0.5f, 0.5f,-0.5f,
                 0.5f,-0.5f,-0.5f,  0.5f, 0.5f,-0.5f,  0.5f, 0.5f, 0.5f,
                 0.5f,-0.5f,-0.5f,  0.5f, 0.5f, 0.5f,  0.5f,-0.5f, 0.5f,
                -0.5f, 0.5f,-0.5f, -0.5f, 0.5f, 0.5f,  0.5f, 0.5f, 0.5f,
                -0.5f, 0.5f,-0.5f,  0.5f, 0.5f, 0.5f,  0.5f, 0.5f,-0.5f,
                -0.5f,-0.5f,-0.5f,  0.5f,-0.5f,-0.5f,  0.5f,-0.5f, 0.5f,
                -0.5f,-0.5f,-0.5f,  0.5f,-0.5f, 0.5f, -0.5f,-0.5f, 0.5f
            )
            cube = ByteBuffer.allocateDirect(vertices.size * 4).order(ByteOrder.nativeOrder())
                .asFloatBuffer().apply { put(vertices); position(0) }
        }

        fun rotate(dx: Float, dy: Float) {
            yaw = (yaw + dx) % 360f
            pitch = (pitch + dy).coerceIn(18f, 78f)
        }

        fun zoomBy(factor: Float) {
            if (factor.isFinite() && factor > 0f) zoom = (zoom * factor).coerceIn(0.65f, 1.8f)
        }

        override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
            GLES20.glViewport(0, 0, width, height)
            Matrix.perspectiveM(projection, 0, 42f, width.toFloat() / max(1, height), 0.1f, 100f)
        }

        override fun onDrawFrame(gl: GL10?) {
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
            Matrix.setLookAtM(view, 0, 0f, 0f, 19f / zoom, 0f, 0f, 0f, 0f, 1f, 0f)
            Matrix.rotateM(view, 0, pitch, 1f, 0f, 0f)
            Matrix.rotateM(view, 0, yaw, 0f, 0f, 1f)
            GLES20.glUseProgram(program)
            cube.position(0)
            GLES20.glEnableVertexAttribArray(positionHandle)
            GLES20.glVertexAttribPointer(positionHandle, 3, GLES20.GL_FLOAT, false, 12, cube)

            // Socle et plateau en relief.
            box(0f, 0f, -0.42f, 15.8f, 15.8f, 0.65f, floatArrayOf(.24f,.18f,.13f,1f))
            box(0f, 0f, -0.06f, 15.1f, 15.1f, 0.18f, floatArrayOf(.94f,.91f,.83f,1f))

            // Quatre quartiers colorés en relief.
            val colors = arrayOf(
                floatArrayOf(.86f,.12f,.12f,1f), floatArrayOf(.12f,.34f,.86f,1f),
                floatArrayOf(.13f,.62f,.25f,1f), floatArrayOf(.96f,.70f,.08f,1f)
            )
            box(-4.8f, 4.8f, .18f, 5.0f, 5.0f, .42f, colors[0])
            box(4.8f, 4.8f, .18f, 5.0f, 5.0f, .42f, colors[1])
            box(-4.8f, -4.8f, .18f, 5.0f, 5.0f, .42f, colors[2])
            box(4.8f, -4.8f, .18f, 5.0f, 5.0f, .42f, colors[3])

            // Piste en croix, cases individuelles en relief.
            for (i in -7..7) {
                for (lane in -1..1) {
                    val c = if ((i + lane) % 2 == 0) .99f else .82f
                    box(i.toFloat(), lane.toFloat(), .20f, .91f, .91f, .12f, floatArrayOf(c,c,c,1f))
                    box(lane.toFloat(), i.toFloat(), .20f, .91f, .91f, .12f, floatArrayOf(c,c,c,1f))
                }
            }
            // Couloirs d'arrivée colorés.
            for (i in 1..5) {
                box(-0.0f, i.toFloat(), .29f, .86f, .86f, .12f, colors[0])
                box(i.toFloat(), 0f, .29f, .86f, .86f, .12f, colors[1])
                box(0f, -i.toFloat(), .29f, .86f, .86f, .12f, colors[2])
                box(-i.toFloat(), 0f, .29f, .86f, .86f, .12f, colors[3])
            }
            box(0f, 0f, .36f, 1.45f, 1.45f, .35f, floatArrayOf(.96f,.84f,.52f,1f))

            // Pions 3D : fûts et têtes empilés pour un relief visible.
            val pawnCenters = arrayOf(
                arrayOf(-5.9f,5.9f), arrayOf(5.9f,5.9f),
                arrayOf(-5.9f,-5.9f), arrayOf(5.9f,-5.9f)
            )
            pawnCenters.forEachIndexed { index, center ->
                for (pawn in 0..3) {
                    val ox = if (pawn % 2 == 0) -.65f else .65f
                    val oy = if (pawn < 2) -.65f else .65f
                    val x = center[0] + ox
                    val y = center[1] + oy
                    box(x, y, .57f, .46f, .46f, .62f, colors[index])
                    box(x, y, .91f, .38f, .38f, .22f, colors[index].copyOf().also { it[0] = (it[0]*.75f).coerceAtMost(1f); it[1] = (it[1]*.75f).coerceAtMost(1f); it[2] = (it[2]*.75f).coerceAtMost(1f) })
                }
            }
            // Dé blanc posé près du centre.
            box(1.4f, 1.4f, .64f, .85f, .85f, .85f, floatArrayOf(.98f,.98f,.98f,1f))
            GLES20.glDisableVertexAttribArray(positionHandle)
        }

        private fun box(x: Float, y: Float, z: Float, sx: Float, sy: Float, sz: Float, color: FloatArray) {
            Matrix.setIdentityM(model, 0)
            Matrix.translateM(model, 0, x, y, z)
            Matrix.scaleM(model, 0, sx, sy, sz)
            Matrix.multiplyMM(modelView, 0, view, 0, model, 0)
            Matrix.multiplyMM(mvp, 0, projection, 0, modelView, 0)
            GLES20.glUniformMatrix4fv(matrixHandle, 1, false, mvp, 0)
            GLES20.glUniform4fv(colorHandle, 1, color, 0)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 36)
        }

        private fun linkProgram(vs: String, fs: String): Int {
            fun compile(type: Int, source: String): Int {
                val shader = GLES20.glCreateShader(type)
                GLES20.glShaderSource(shader, source)
                GLES20.glCompileShader(shader)
                return shader
            }
            val v = compile(GLES20.GL_VERTEX_SHADER, vs)
            val f = compile(GLES20.GL_FRAGMENT_SHADER, fs)
            return GLES20.glCreateProgram().also {
                GLES20.glAttachShader(it, v); GLES20.glAttachShader(it, f); GLES20.glLinkProgram(it)
            }
        }
    }
}
