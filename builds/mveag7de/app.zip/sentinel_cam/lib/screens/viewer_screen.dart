import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:gal/gal.dart';
import '../services/alert_service.dart';
import '../services/background_service.dart';
import '../services/viewer_client.dart';

class ViewerScreen extends StatefulWidget {
  const ViewerScreen({super.key});
  @override
  State<ViewerScreen> createState() => _ViewerScreenState();
}

class _ViewerScreenState extends State<ViewerScreen> {
  final client = ViewerClient();
  final ctrl = TextEditingController(text: ViewerClient.lastCode);
  String? error;

  @override
  void initState() {
    super.initState();
    client.onAlert = _onAlert;
    client.init().then((_) => mounted ? setState(() {}) : null);
  }

  @override
  void dispose() {
    client.dispose();
    BackgroundService.stop();
    ctrl.dispose();
    super.dispose();
  }

  void _snack(String m, {SnackBarAction? action}) {
    if (mounted) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(m), action: action));
    }
  }

  void _onAlert(String label) {
    AlertService.notifyPerson(label); // notification + son 5 s max
    _snack('⚠️ $label détectée');
  }

  Future<void> _connect() async {
    setState(() => error = null);
    try {
      await client.connect(ctrl.text);
      // Garde la session et les alertes actives si l'app passe en arrière-plan.
      await BackgroundService.start(
        types: [ForegroundServiceTypes.dataSync],
        title: 'Visionnage actif',
        text: 'Alertes de détection activées',
      );
    } catch (e) {
      setState(() => error = '$e');
    }
  }

  Future<void> _hangup() async {
    if (client.recording.value) await _toggleRec(); // sauvegarde avant de quitter
    await client.disconnect();
    await BackgroundService.stop();
  }

  /// REC : démarre / arrête, puis enregistre la vidéo dans la galerie du téléphone.
  Future<void> _toggleRec() async {
    if (!client.recording.value) {
      try {
        await client.startRecording();
      } catch (e) {
        _snack('$e');
      }
      return;
    }
    final file = await client.stopRecording();
    if (file == null) {
      _snack('Enregistrement vide');
      return;
    }
    try {
      await Gal.putVideo(file.path, album: 'Sentinel Cam');
      await file.delete();
      _snack('Enregistré dans la galerie (album Sentinel Cam)',
          action: SnackBarAction(label: 'Ouvrir', onPressed: () => Gal.open()));
    } catch (e) {
      _snack('Enregistrement impossible : $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mode Visionneur')),
      body: ValueListenableBuilder(
        valueListenable: client.status,
        builder: (_, s, __) => (s == ViewerStatus.idle) ? _form() : _player(s),
      ),
    );
  }

  Widget _form() => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          TextField(
            controller: ctrl,
            keyboardType: TextInputType.number,
            textAlign: TextAlign.center,
            maxLength: 6,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            style: const TextStyle(fontSize: 40, letterSpacing: 8),
            decoration: InputDecoration(
                hintText: '000000', errorText: error, border: const OutlineInputBorder()),
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: FilledButton(onPressed: _connect, child: const Text('Se connecter')),
          ),
        ]),
      );

  Widget _player(ViewerStatus s) => Stack(fit: StackFit.expand, children: [
        const ColoredBox(color: Colors.black),
        RTCVideoView(client.renderer,
            objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitContain),
        if (s == ViewerStatus.connecting) const Center(child: CircularProgressIndicator()),
        if (s == ViewerStatus.error)
          const Center(child: Text('Connexion perdue ou caméra arrêtée')),
        if (s == ViewerStatus.paused)
          const Center(child: Icon(Icons.pause_circle, size: 80, color: Colors.white54)),
        Positioned(
          top: 12, left: 12,
          child: ValueListenableBuilder<bool>(
            valueListenable: client.recording,
            builder: (_, r, __) => r
                ? const Chip(
                    avatar: Icon(Icons.fiber_manual_record, color: Colors.red, size: 16),
                    label: Text('REC'))
                : const SizedBox.shrink(),
          ),
        ),
        Positioned(
          left: 0, right: 0, bottom: 24,
          child: Wrap(
            alignment: WrapAlignment.center,
            spacing: 14,
            runSpacing: 12,
            children: [
              ValueListenableBuilder<bool>(
                valueListenable: client.muted,
                builder: (_, m, __) => FloatingActionButton(
                  heroTag: 'mute',
                  onPressed: () => client.setMuted(!m),
                  child: Icon(m ? Icons.volume_off : Icons.volume_up),
                ),
              ),
              ValueListenableBuilder<bool>(
                valueListenable: client.torchOn,
                builder: (_, t, __) => FloatingActionButton(
                  heroTag: 'torch',
                  backgroundColor: t ? Colors.amber : null,
                  onPressed: () => client.setTorch(!t),
                  child: Icon(t ? Icons.flashlight_on : Icons.flashlight_off),
                ),
              ),
              ValueListenableBuilder<bool>(
                valueListenable: client.recording,
                builder: (_, r, __) => FloatingActionButton(
                  heroTag: 'rec',
                  backgroundColor: r ? Colors.red : null,
                  onPressed: _toggleRec,
                  child: Icon(r ? Icons.stop : Icons.fiber_manual_record),
                ),
              ),
              FloatingActionButton(
                heroTag: 'pause',
                onPressed: (s == ViewerStatus.live || s == ViewerStatus.paused)
                    ? () => client.setPaused(s == ViewerStatus.live)
                    : null,
                child: Icon(s == ViewerStatus.paused ? Icons.play_arrow : Icons.pause),
              ),
              FloatingActionButton(
                heroTag: 'stop',
                backgroundColor: Colors.red.shade700,
                onPressed: _hangup,
                child: const Icon(Icons.call_end),
              ),
            ],
          ),
        ),
      ]);
}
