import 'dart:async';
import 'dart:io';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:google_mlkit_image_labeling/google_mlkit_image_labeling.dart';
import 'package:path_provider/path_provider.dart';

/// Capture une image du flux toutes les 2 s et l'analyse sur le téléphone
/// (ML Kit, modèle embarqué : rien n'est envoyé à un serveur).
class PersonDetector {
  final MediaStreamTrack track;
  final void Function(String label, double confidence) onPerson;
  final Duration interval;
  final Duration cooldown;

  PersonDetector({
    required this.track,
    required this.onPerson,
    this.interval = const Duration(seconds: 2),
    this.cooldown = const Duration(seconds: 30),
  });

  static const _humanLabels = {'person', 'crowd', 'selfie', 'face', 'head', 'human body'};

  final _labeler = ImageLabeler(options: ImageLabelerOptions(confidenceThreshold: 0.65));
  Timer? _timer;
  bool _busy = false;
  DateTime _last = DateTime.fromMillisecondsSinceEpoch(0);

  void start() => _timer = Timer.periodic(interval, (_) => _tick());

  Future<void> _tick() async {
    if (_busy || !track.enabled) return; // pas d'analyse quand le flux est en pause
    _busy = true;
    try {
      final buf = await track.captureFrame();
      final dir = await getTemporaryDirectory();
      final file = File('${dir.path}/frame.png');
      await file.writeAsBytes(buf.asUint8List(), flush: true);
      final labels = await _labeler.processImage(InputImage.fromFilePath(file.path));
      for (final l in labels) {
        if (_humanLabels.contains(l.label.toLowerCase())) {
          final now = DateTime.now();
          if (now.difference(_last) >= cooldown) {
            _last = now;
            onPerson('Personne', l.confidence);
          }
          break;
        }
      }
    } catch (_) {
      // image indisponible : on réessaie au prochain tour
    } finally {
      _busy = false;
    }
  }

  Future<void> stop() async {
    _timer?.cancel();
    await _labeler.close();
  }
}
