import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:path_provider/path_provider.dart';
import 'rtc_config.dart';

enum ViewerStatus { idle, connecting, live, paused, error }

class ViewerClient {
  /// Dernier code saisi (sert de clé pour retrouver les enregistrements).
  static String lastCode = '';

  final _db = FirebaseFirestore.instance;
  final status = ValueNotifier<ViewerStatus>(ViewerStatus.idle);
  final torchOn = ValueNotifier<bool>(false);
  final muted = ValueNotifier<bool>(false);
  final recording = ValueNotifier<bool>(false);
  final renderer = RTCVideoRenderer();

  /// Appelé quand la caméra signale une personne.
  void Function(String label)? onAlert;

  String code = '';
  MediaStream? remoteStream;
  RTCPeerConnection? _pc;
  DocumentReference<Map<String, dynamic>>? _doc;
  StreamSubscription? _sessionSub, _candSub;
  String _id = '';
  bool _gotOffer = false, _remoteSet = false;
  int? _lastAlertN;
  final List<RTCIceCandidate> _pending = [];
  MediaRecorder? _rec;
  String? _recPath;

  Future<void> init() => renderer.initialize();

  Future<void> connect(String rawCode) async {
    await disconnect();
    code = rawCode.replaceAll(RegExp(r'\D'), '');
    final doc = _db.collection('sessions').doc(code.isEmpty ? '_' : code);
    if (code.length != 6 || !(await doc.get()).exists) throw 'Code introuvable';
    lastCode = code;

    _doc = doc;
    _id = '${DateTime.now().microsecondsSinceEpoch}${Random().nextInt(9999)}';
    status.value = ViewerStatus.connecting;

    final pc = _pc = await createPeerConnection(rtcConfig);
    pc.onTrack = (e) {
      if (e.streams.isNotEmpty) {
        remoteStream = e.streams.first;
        if (e.track.kind == 'video') renderer.srcObject = remoteStream;
        if (e.track.kind == 'audio') e.track.enabled = !muted.value;
      }
    };
    pc.onIceCandidate = (c) {
      if (c.candidate != null) {
        doc.collection('viewCandidates').add({...c.toMap(), 'viewer': _id});
      }
    };
    pc.onConnectionState = (s) {
      if (s == RTCPeerConnectionState.RTCPeerConnectionStateConnected) {
        status.value = ViewerStatus.live;
      } else if (s == RTCPeerConnectionState.RTCPeerConnectionStateFailed) {
        status.value = ViewerStatus.error;
      }
    };

    _candSub = doc
        .collection('hostCandidates')
        .where('viewer', isEqualTo: _id)
        .snapshots()
        .listen((qs) async {
      for (final ch in qs.docChanges.where((c) => c.type == DocumentChangeType.added)) {
        final m = ch.doc.data()!;
        final cand = RTCIceCandidate(m['candidate'], m['sdpMid'], m['sdpMLineIndex']);
        _remoteSet ? await _pc?.addCandidate(cand) : _pending.add(cand);
      }
    });

    _sessionSub = doc.snapshots().listen((s) async {
      final d = s.data();
      if (d == null) {
        status.value = ViewerStatus.error; // caméra arrêtée
        return;
      }
      torchOn.value = d['torch'] == true;

      // Alertes : la première lecture sert de référence, seules les suivantes déclenchent.
      final n = (d['alertN'] as num?)?.toInt() ?? 0;
      if (_lastAlertN == null) {
        _lastAlertN = n;
      } else if (n > _lastAlertN!) {
        _lastAlertN = n;
        onAlert?.call((d['alertLabel'] as String?) ?? 'Personne');
      }

      final offer = d['offer'];
      if (offer is Map && offer['viewer'] == _id && !_gotOffer) {
        _gotOffer = true;
        await pc.setRemoteDescription(RTCSessionDescription(offer['sdp'], offer['type']));
        _remoteSet = true;
        for (final c in _pending) {
          await pc.addCandidate(c);
        }
        _pending.clear();
        final answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);
        await doc.update({
          'answer': {'sdp': answer.sdp, 'type': answer.type, 'viewer': _id}
        });
      }
    });

    await doc.update({'join': _id, 'paused': false});
  }

  Future<void> setPaused(bool p) async {
    await _doc?.update({'paused': p});
    status.value = p ? ViewerStatus.paused : ViewerStatus.live;
  }

  Future<void> setTorch(bool on) => _doc?.update({'torch': on}) ?? Future.value();

  void setMuted(bool m) {
    muted.value = m;
    for (final t in remoteStream?.getAudioTracks() ?? <MediaStreamTrack>[]) {
      t.enabled = !m;
    }
  }

  /// Enregistre le flux reçu (vidéo + son) dans un fichier mp4 temporaire.
  Future<void> startRecording() async {
    final s = remoteStream;
    if (s == null || s.getVideoTracks().isEmpty) throw 'Aucun flux à enregistrer';
    final dir = await getTemporaryDirectory();
    _recPath = '${dir.path}/rec_${DateTime.now().millisecondsSinceEpoch}.mp4';
    _rec = MediaRecorder();
    await _rec!.start(
      _recPath!,
      videoTrack: s.getVideoTracks().first,
      audioChannel: RecorderAudioChannel.OUTPUT,
    );
    recording.value = true;
  }

  Future<File?> stopRecording() async {
    try {
      await _rec?.stop();
    } finally {
      _rec = null;
      recording.value = false;
    }
    final f = _recPath == null ? null : File(_recPath!);
    return (f != null && await f.exists() && await f.length() > 0) ? f : null;
  }

  Future<void> disconnect() async {
    if (recording.value) await stopRecording();
    await _sessionSub?.cancel();
    await _candSub?.cancel();
    try {
      await _doc?.update({'join': FieldValue.delete(), 'torch': false});
    } catch (_) {}
    await _pc?.close();
    _pc = null;
    _doc = null;
    remoteStream = null;
    _gotOffer = _remoteSet = false;
    _lastAlertN = null;
    _pending.clear();
    renderer.srcObject = null;
    torchOn.value = false;
    status.value = ViewerStatus.idle;
  }

  Future<void> dispose() async {
    await disconnect();
    await renderer.dispose();
  }
}
