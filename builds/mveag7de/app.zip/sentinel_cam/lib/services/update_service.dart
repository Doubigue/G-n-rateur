import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:open_filex/open_filex.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

class UpdateInfo {
  final String versionName;
  final int versionCode;
  final String apkUrl;
  UpdateInfo(this.versionName, this.versionCode, this.apkUrl);
}

/// Mises à jour via les Releases GitHub publiées par APK Studio.
/// Le dépôt doit être PUBLIC (appel API sans jeton).
class UpdateService {
  static const repo = 'Doubigue/G-n-rateur';
  static const packageName = 'com.doubigue.macamera';

  static final navigatorKey = GlobalKey<NavigatorState>();
  static final _notif = FlutterLocalNotificationsPlugin();
  static final progress = ValueNotifier<double?>(null);

  static bool enabled = true; // désactivé pendant le Mode Caméra
  static bool _busy = false;
  static int? _dismissed, _notified;
  static File? _apk;

  static Future<void> init() async {
    await _notif.initialize(
      const InitializationSettings(
          android: AndroidInitializationSettings('@mipmap/ic_launcher')),
      onDidReceiveNotificationResponse: (r) {
        if (r.payload == 'install') {
          install();
        } else {
          checkAndPrompt(force: true);
        }
      },
    );
    await _notif
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.requestNotificationsPermission();
  }

  /// Cherche une version plus récente que celle installée.
  static Future<UpdateInfo?> check() async {
    try {
      final current =
          int.tryParse((await PackageInfo.fromPlatform()).buildNumber) ?? 0;
      final client = HttpClient()..connectionTimeout = const Duration(seconds: 10);
      try {
        final req = await client.getUrl(
            Uri.parse('https://api.github.com/repos/$repo/releases?per_page=30'));
        req.headers.set('Accept', 'application/vnd.github+json');
        final res = await req.close();
        if (res.statusCode != 200) return null;
        final list = jsonDecode(await res.transform(utf8.decoder).join()) as List;

        UpdateInfo? best;
        for (final r in list) {
          final body = (r['body'] ?? '') as String;
          if (!body.contains('Paquet : $packageName')) continue;
          final m = RegExp(r'Version : (\S+) \((\d+)\)').firstMatch(body);
          if (m == null) continue;
          final code = int.parse(m.group(2)!);
          String? url;
          for (final a in (r['assets'] as List)) {
            if ((a['name'] as String).endsWith('.apk')) {
              url = a['browser_download_url'] as String;
              break;
            }
          }
          if (url == null) continue;
          if (best == null || code > best.versionCode) {
            best = UpdateInfo(m.group(1)!, code, url);
          }
        }
        return (best != null && best.versionCode > current) ? best : null;
      } finally {
        client.close();
      }
    } catch (_) {
      return null;
    }
  }

  static Future<void> checkAndPrompt({bool force = false}) async {
    if (!enabled || _busy) return;
    final u = await check();
    if (u == null) return;
    if (_notified != u.versionCode) {
      _notified = u.versionCode;
      await _show(9001, 'Mise à jour disponible',
          'Version ${u.versionName} : appuyez pour mettre à jour', 'update');
    }
    if (!force && _dismissed == u.versionCode) return;
    final ctx = navigatorKey.currentContext;
    if (ctx == null || !ctx.mounted) return;
    final ok = await showDialog<bool>(
      context: ctx,
      builder: (c) => AlertDialog(
        title: const Text('Mise à jour disponible'),
        content: Text('La version ${u.versionName} est disponible. '
            'Voulez-vous la télécharger et l\'installer ?'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(c, false), child: const Text('Plus tard')),
          FilledButton(
              onPressed: () => Navigator.pop(c, true), child: const Text('Mettre à jour')),
        ],
      ),
    );
    if (ok == true) {
      await downloadAndInstall(u);
    } else {
      _dismissed = u.versionCode;
    }
  }

  static Future<void> downloadAndInstall(UpdateInfo u) async {
    if (_busy) return;
    _busy = true;
    progress.value = 0;
    final ctx = navigatorKey.currentContext;
    if (ctx != null && ctx.mounted) {
      showDialog(
        context: ctx,
        barrierDismissible: false,
        builder: (_) => PopScope(
          canPop: false,
          child: AlertDialog(
            title: const Text('Téléchargement...'),
            content: ValueListenableBuilder<double?>(
              valueListenable: progress,
              builder: (_, v, __) => Column(mainAxisSize: MainAxisSize.min, children: [
                LinearProgressIndicator(value: v),
                const SizedBox(height: 8),
                Text(v == null ? '' : '${(v * 100).round()} %'),
              ]),
            ),
          ),
        ),
      );
    }
    try {
      _apk = await _download(u);
      navigatorKey.currentState?.pop(); // ferme la fenêtre de progression
      await _show(9002, 'Mise à jour prête',
          'Version ${u.versionName} : appuyez pour installer', 'install');
      await install();
    } catch (e) {
      navigatorKey.currentState?.pop();
      await _show(9002, 'Échec de la mise à jour', '$e', 'update');
    } finally {
      _busy = false;
      progress.value = null;
    }
  }

  static Future<File> _download(UpdateInfo u) async {
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/sentinelcam-${u.versionCode}.apk');
    if (await file.exists()) await file.delete();
    final client = HttpClient();
    try {
      final res = await (await client.getUrl(Uri.parse(u.apkUrl))).close();
      if (res.statusCode != 200) throw 'Téléchargement impossible (${res.statusCode})';
      final total = res.contentLength;
      var got = 0, lastPct = -10;
      final sink = file.openWrite();
      await for (final chunk in res) {
        sink.add(chunk);
        got += chunk.length;
        if (total > 0) {
          progress.value = got / total;
          final pct = (got * 100 / total).floor();
          if (pct >= lastPct + 5) {
            lastPct = pct;
            _progressNotif(pct);
          }
        }
      }
      await sink.close();
      return file;
    } finally {
      client.close();
    }
  }

  static Future<void> install() async {
    final f = _apk;
    if (f == null || !await f.exists()) return;
    var st = await Permission.requestInstallPackages.status;
    if (!st.isGranted) st = await Permission.requestInstallPackages.request();
    if (!st.isGranted) {
      final c = navigatorKey.currentContext;
      if (c != null && c.mounted) {
        ScaffoldMessenger.maybeOf(c)?.showSnackBar(const SnackBar(
            content: Text('Autorisez « Installer des applications inconnues » '
                'pour Sentinel Cam, puis appuyez sur la notification.')));
      }
      return;
    }
    await OpenFilex.open(f.path, type: 'application/vnd.android.package-archive');
  }

  static Future<void> _show(int id, String title, String body, String payload) =>
      _notif.show(
        id, title, body,
        const NotificationDetails(
          android: AndroidNotificationDetails(
            'sentinel_update', 'Mises à jour',
            channelDescription: 'Nouvelles versions de Sentinel Cam',
            importance: Importance.high, priority: Priority.high,
          ),
        ),
        payload: payload,
      );

  static Future<void> _progressNotif(int pct) => _notif.show(
        9002, 'Téléchargement de la mise à jour', '$pct %',
        NotificationDetails(
          android: AndroidNotificationDetails(
            'sentinel_update_progress', 'Progression des mises à jour',
            importance: Importance.low, priority: Priority.low,
            showProgress: true, maxProgress: 100, progress: pct,
            onlyAlertOnce: true, ongoing: true,
          ),
        ),
      );
}
