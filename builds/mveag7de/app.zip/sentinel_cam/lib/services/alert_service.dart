import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class AlertService {
  /// Notification + son d'alarme + vibration, retirée automatiquement après 5 s
  /// (ce qui coupe aussi le son et la vibration).
  static Future<void> notifyPerson(String label) {
    final now = DateTime.now();
    final hh = now.hour.toString().padLeft(2, '0');
    final mm = now.minute.toString().padLeft(2, '0');
    return FlutterLocalNotificationsPlugin().show(
      9100,
      '⚠️ $label détectée',
      'La caméra a repéré une présence à $hh:$mm',
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'sentinel_alert_v1',
          'Alertes de détection',
          channelDescription: 'Alerte quand une personne est détectée',
          importance: Importance.max,
          priority: Priority.high,
          playSound: true,
          enableVibration: true,
          audioAttributesUsage: AudioAttributesUsage.alarm,
          category: AndroidNotificationCategory.alarm,
          timeoutAfter: 5000,
        ),
      ),
    );
  }
}
