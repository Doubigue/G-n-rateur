import 'dart:async';
import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'person_detector.dart';
import 'rtc_config.dart';

enum HostStatus { starting, waiting, connecting, live, error }

/// Émetteur : capture caméra + micro, génère le code, détecte les personnes,
/// répond aux visionneurs. Signalisation Firestore : sessions/{code}.
class CameraHost {
  final _db = FirebaseFirestore.instance;
  final status = ValueNotifier<HostStatus>(HostStatus.starting);
  final torch = ValueNotifier<bool>(false);
  final detections = ValueNotifier<int>(0);
  final preview = RTCVideoRenderer();

  String? code;
  MediaStream? _stream;
  RTCPeerConnection? _pc;
  DocumentReference<Map<String, dynamic>>? _doc;
  StreamSubscription? _sessionSub, _candSub;
  PersonDetector? _detector;
  String? _viewer;
  bool _answered = false;
  final List<RTCIceCandidate> _pending = [];

  Future<String> start({bool withAudio = true}) async {
    await preview.initialize();
    _stream = await navigator.mediaDevices.getUserMedia({
      'audio': withAudio,
      'video': {
        'facingMode': 'environment',
        'mandatory': {'minWidth': '640', 'minHeight': '480', 'minFrameRate': '10'},
        'optional': [],
      },
    });
    preview.srcObject = _stream;
    code = await _reserveCode();
    status.value = HostStatus.waiting;
    _sessionSub = _doc!.snapshots().listen(_onSession);
    _detector = PersonDetector(
      track: _stream!.getVideoTracks().first,
      onPerson: _onPerson,
    )..start();
    return code!;
  }

  Future<String> _reserveCode() async {
    final rnd = Random.secure();
    for (var i = 0; i < 20; i++) {
      final c = (100000 + rnd.nextInt(900000)).toString();
      final ref = _db.collection('sessions').doc(c);
      final ok = await _db.runTransaction((tx) async {
        if ((await tx.get(ref)).exists) return false;
        tx.set(ref, {
          'createdAt': FieldValue.serverTimestamp(),
          'paused': false,
          'torch': false,
          'alertN': 0,
        });
        return true;
      });
      if (ok) {
        _doc = ref;
        return c;
      }
    }
    throw 'Impossible de générer un code';
  }

  void _onPerson(String label, double conf) {
    detections.value++;
    _doc?.update({
      'alertN': FieldValue.increment(1),
      'alertAt': FieldValue.serverTimestamp(),
      'alertLabel': label,
    });
  }

  /// Lampe (flash) : bouton local ou commande du visionneur.
  Future<void> setTorch(bool on) async {
    await _applyTorch(on);
    await _doc?.update({'torch': on});
  }

  Future<void> _applyTorch(bool on) async {
    try {
      final t = _stream?.getVideoTracks().first;
      if (t != null && await t.hasTorch()) {
        await t.setTorch(on);
        torch.value = on;
      }
    } catch (e) {
      debugPrint('Lampe indisponible: $e');
    }
  }

  Future<void> _onSession(DocumentSnapshot<Map<String, dynamic>> snap) async {
    final d = snap.data();
    if (d == null) return;

    // Pause : images noires et micro coupé, débit quasi nul.
    final paused = d['paused'] == true;
    for (final t in _stream?.getTracks() ?? <MediaStreamTrack>[]) {
      t.enabled = !paused;
    }

    final wantTorch = d['torch'] == true;
    if (wantTorch != torch.value) await _applyTorch(wantTorch);

    final join = d['join'] as String?;
    if (join != null && join != _viewer) {
      await _startPeer(join);
    } else if (join == null && _viewer != null) {
      await _closePeer();
      status.value = HostStatus.waiting;
    }

    final ans = d['answer'];
    if (ans is Map && ans['viewer'] == _viewer && !_answered && _pc != null) {
      _answered = true;
      await _pc!.setRemoteDescription(RTCSessionDescription(ans['sdp'], ans['type']));
      for (final c in _pending) {
        await _pc!.addCandidate(c);
      }
      _pending.clear();
      _limitBitrate();
    }
  }

  Future<void> _startPeer(String viewerId) async {
    await _closePeer();
    _viewer = viewerId;
    status.value = HostStatus.connecting;

    final pc = _pc = await createPeerConnection(rtcConfig);
    for (final t in _stream!.getTracks()) {
      await pc.addTrack(t, _stream!);
    }
    pc.onIceCandidate = (c) {
      if (c.candidate != null) {
        _doc?.collection('hostCandidates').add({...c.toMap(), 'viewer': viewerId});
      }
    };
    pc.onConnectionState = (s) {
      if (s == RTCPeerConnectionState.RTCPeerConnectionStateConnected) {
        status.value = HostStatus.live;
      } else if (s == RTCPeerConnectionState.RTCPeerConnectionStateFailed ||
          s == RTCPeerConnectionState.RTCPeerConnectionStateDisconnected) {
        status.value = HostStatus.waiting;
      }
    };

    _candSub = _doc!
        .collection('viewCandidates')
        .where('viewer', isEqualTo: viewerId)
        .snapshots()
        .listen((qs) async {
      for (final ch in qs.docChanges.where((c) => c.type == DocumentChangeType.added)) {
        final m = ch.doc.data()!;
        final cand = RTCIceCandidate(m['candidate'], m['sdpMid'], m['sdpMLineIndex']);
        if (_answered) {
          await _pc?.addCandidate(cand);
        } else {
          _pending.add(cand);
        }
      }
    });

    final offer = await pc.createOffer({'offerToReceiveVideo': 0, 'offerToReceiveAudio': 0});
    await pc.setLocalDescription(offer);
    await _doc!.update({
      'offer': {'sdp': offer.sdp, 'type': offer.type, 'viewer': viewerId},
      'answer': FieldValue.delete(),
    });
  }

  /// Plafonne débit et FPS vidéo côté encodeur.
  Future<void> _limitBitrate() async {
    try {
      final senders = await _pc!.getSenders();
      final s = senders.firstWhere((s) => s.track?.kind == 'video');
      final p = s.parameters;
      for (final e in p.encodings ?? <RTCRtpEncoding>[]) {
        e.maxBitrate = maxBitrate;
        e.maxFramerate = maxFps;
      }
      await s.setParameters(p);
    } catch (e) {
      debugPrint('setParameters ignoré: $e');
    }
  }

  Future<void> _closePeer() async {
    await _candSub?.cancel();
    _candSub = null;
    await _pc?.close();
    _pc = null;
    _viewer = null;
    _answered = false;
    _pending.clear();
  }

  Future<void> stop() async {
    await _detector?.stop();
    await _sessionSub?.cancel();
    await _closePeer();
    try {
      if (torch.value) await _stream?.getVideoTracks().first.setTorch(false);
    } catch (_) {}
    _stream?.getTracks().forEach((t) => t.stop());
    await _stream?.dispose();
    preview.srcObject = null;
    await preview.dispose();
    try {
      await _doc?.delete(); // sous-collections : à purger via TTL / Cloud Function
    } catch (_) {}
  }
}
