import 'package:flutter_foreground_task/flutter_foreground_task.dart';

@pragma('vm:entry-point')
void startCallback() => FlutterForegroundTask.setTaskHandler(_KeepAliveHandler());

/// Le travail WebRTC reste dans l'isolate principal ; ce service maintient le
/// processus vivant (notification + WakeLock CPU + WifiLock + type "camera").
class _KeepAliveHandler extends TaskHandler {
  @override
  Future<void> onStart(DateTime timestamp, TaskStarter starter) async {}
  @override
  void onRepeatEvent(DateTime timestamp) {}
  @override
  Future<void> onDestroy(DateTime timestamp, bool isTimeout) async {}
}

class BackgroundService {
  static void init() {
    FlutterForegroundTask.init(
      androidNotificationOptions: AndroidNotificationOptions(
        channelId: 'sentinel_cam',
        channelName: 'Caméra de surveillance',
        channelDescription: 'Capture vidéo en cours',
        channelImportance: NotificationChannelImportance.LOW,
        priority: NotificationPriority.LOW,
      ),
      iosNotificationOptions: const IOSNotificationOptions(),
      foregroundTaskOptions: ForegroundTaskOptions(
        eventAction: ForegroundTaskEventAction.nothing(),
        autoRunOnBoot: false,
        allowWakeLock: true, // WAKE_LOCK partiel : CPU actif écran éteint
        allowWifiLock: true, // Wi-Fi actif écran éteint
      ),
    );
  }

  static Future<void> requestPermissions() async {
    if (await FlutterForegroundTask.checkNotificationPermission() !=
        NotificationPermission.granted) {
      await FlutterForegroundTask.requestNotificationPermission();
    }
    if (!await FlutterForegroundTask.isIgnoringBatteryOptimizations) {
      await FlutterForegroundTask.requestIgnoreBatteryOptimization();
    }
  }

  /// Caméra : camera (+ microphone). Visionneur : dataSync (alertes en arrière-plan).
  /// À appeler APRÈS l'obtention des permissions caméra / micro (Android 14+).
  static Future<void> start({
    List<ForegroundServiceTypes> types = const [
      ForegroundServiceTypes.camera,
      ForegroundServiceTypes.microphone,
    ],
    String title = 'Caméra de surveillance active...',
    String text = 'Diffusion vidéo et audio en cours',
  }) async {
    if (await FlutterForegroundTask.isRunningService) return;
    await FlutterForegroundTask.startService(
      serviceId: 4242,
      serviceTypes: types,
      notificationTitle: title,
      notificationText: text,
      callback: startCallback,
    );
  }

  static Future<void> stop() => FlutterForegroundTask.stopService();
}
