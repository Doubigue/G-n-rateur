package com.dlvibe.extrait

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color as AColor
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.Rect
import android.net.Uri
import android.provider.OpenableColumns
import androidx.exifinterface.media.ExifInterface
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.tasks.await
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Retouches choisies par la personne : rotation (degrés) puis rognage (fractions 0..1 de l'image tournée). */
data class Edit(val rotation: Int = 0, val l: Float = 0f, val t: Float = 0f, val r: Float = 1f, val b: Float = 1f) {
    val hasCrop: Boolean get() = l > 0.001f || t > 0.001f || r < 0.999f || b < 0.999f
}

/** Style d'un morceau de texte, en positions dans la chaîne résultat. */
class Run(val start: Int, val end: Int, val color: Int, val bold: Boolean, val scale: Float)

/** Texte mis en page + couleur de fond de l'image + styles relevés dans l'image. */
class Laid(val text: String, val bg: Int, val runs: List<Run>, val thumb: Bitmap? = null)

object Ocr {
    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    /** Lit une image et renvoie son texte, positionné comme dans l'image. */
    suspend fun read(context: Context, uri: Uri, edit: Edit = Edit()): Laid {
        val bmp = decode(context, uri, edit, 2200, 3200) ?: error("Image illisible")
        try {
            val result = recognizer.process(InputImage.fromBitmap(bmp, 0)).await()
            val laid = LayoutBuilder.build(result, bmp)
            return Laid(laid.text, laid.bg, laid.runs, thumb(bmp))
        } finally {
            bmp.recycle()
        }
    }

    /** Petite vignette pour les cartes. */
    private fun thumb(bmp: Bitmap): Bitmap? = try {
        val k = 160f / max(bmp.width, bmp.height)
        if (k >= 1f) bmp.copy(Bitmap.Config.ARGB_8888, false)
        else Bitmap.createScaledBitmap(bmp, max(1, (bmp.width * k).roundToInt()), max(1, (bmp.height * k).roundToInt()), true)
    } catch (e: Throwable) {
        null
    }

    fun displayName(context: Context, uri: Uri): String? = try {
        context.contentResolver
            .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
    } catch (e: Exception) {
        null
    }

    /** Aperçu (léger) pour l'écran de recadrage, avec rotation EXIF + rotation choisie. */
    fun preview(context: Context, uri: Uri, rotation: Int): Bitmap? =
        decode(context, uri, Edit(rotation = rotation), 1200, 1600)

    /** Décode en limitant la taille (centaines d'images : on évite de saturer la mémoire). */
    private fun decode(context: Context, uri: Uri, edit: Edit, sampleTarget: Int, cap: Int): Bitmap? {
        val cr = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        val longSide = max(bounds.outWidth, bounds.outHeight)
        if (longSide <= 0) return null

        var sample = 1
        while (longSide / (sample * 2) >= sampleTarget) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null

        val exifDeg = try {
            cr.openInputStream(uri)?.use { s ->
                when (ExifInterface(s).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } ?: 0f
        } catch (e: Exception) {
            0f
        }

        val degrees = (exifDeg + edit.rotation) % 360f
        val big = max(bmp.width, bmp.height)
        if (big > cap) {
            val k = cap.toFloat() / big
            val scaled = Bitmap.createScaledBitmap(bmp, (bmp.width * k).roundToInt(), (bmp.height * k).roundToInt(), true)
            if (scaled !== bmp) bmp.recycle()
            bmp = scaled
        }
        if (degrees != 0f) {
            val m = Matrix().apply { postRotate(degrees) }
            val rotated = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            if (rotated !== bmp) bmp.recycle()
            bmp = rotated
        }
        if (edit.hasCrop) {
            val x = (edit.l * bmp.width).roundToInt().coerceIn(0, bmp.width - 2)
            val y = (edit.t * bmp.height).roundToInt().coerceIn(0, bmp.height - 2)
            val w = ((edit.r - edit.l) * bmp.width).roundToInt().coerceIn(2, bmp.width - x)
            val h = ((edit.b - edit.t) * bmp.height).roundToInt().coerceIn(2, bmp.height - y)
            val cropped = Bitmap.createBitmap(bmp, x, y, w, h)
            if (cropped !== bmp) bmp.recycle()
            bmp = cropped
        }
        return bmp
    }
}

/**
 * Reconstruit la disposition : les lignes détectées sont regroupées par rangée,
 * puis placées sur une grille à espacement fixe selon leur position horizontale.
 * Les écarts verticaux deviennent des lignes vides.
 */
object LayoutBuilder {
    private class Ink(val bg: Int, val fg: Int, val ratio: Float)
    private val WHITE = 0xFFFFFFFF.toInt()

    private class L(val text: String, val r: Rect, val ink: Ink?) {
        val cy: Float get() = r.exactCenterY()
    }

    fun build(t: Text, bmp: Bitmap): Laid {
        val lines = t.textBlocks.flatMap { it.lines }
            .mapNotNull { l ->
                val b = l.boundingBox ?: return@mapNotNull null
                val tx = l.text.trim()
                if (tx.isEmpty()) null else L(tx, b, sample(bmp, b))
            }
        if (lines.isEmpty()) return Laid("", WHITE, emptyList())
        val ratios = lines.mapNotNull { it.ink?.ratio }.sorted()
        val medRatio = if (ratios.isEmpty()) 0f else ratios[ratios.size / 2]
        val pageBg = pageBackground(lines.mapNotNull { it.ink?.bg })
        val runs = mutableListOf<Run>()

        val minLeft = lines.minOf { it.r.left }
        val maxRight = lines.maxOf { it.r.right }
        val widths = lines.map { it.r.width().toFloat() / it.text.length }.sorted()
        var cw = widths[widths.size / 2].coerceAtLeast(1f)
        val medH = lines.map { it.r.height() }.sorted()[lines.size / 2].coerceAtLeast(1)
        if ((maxRight - minLeft) / cw > 140f) cw = (maxRight - minLeft) / 140f

        val rows = mutableListOf<MutableList<L>>()
        for (l in lines.sortedBy { it.cy }) {
            val row = rows.lastOrNull()
            if (row != null && sameRow(row, l)) row.add(l) else rows.add(mutableListOf(l))
        }

        val sb = StringBuilder()
        var prevBottom: Int? = null
        for (row in rows) {
            val items = row.sortedBy { it.r.left }
            val top = items.minOf { it.r.top }
            val bottom = items.maxOf { it.r.bottom }
            if (prevBottom != null) {
                val gap = top - prevBottom
                val blanks = if (gap > 0.6f * medH) (gap / medH.toFloat()).roundToInt().coerceIn(1, 4) else 0
                repeat(blanks + 1) { sb.append('\n') }
            }
            val lineStart = sb.length
            val line = StringBuilder()
            for (item in items) {
                val target = ((item.r.left - minLeft) / cw).roundToInt()
                val pad = if (line.isEmpty()) target else max(1, target - line.length)
                repeat(pad) { line.append(' ') }
                val start = lineStart + line.length
                line.append(item.text)
                val ink = item.ink
                val scale = if (items.size == 1) {
                    val k = item.r.height().toFloat() / medH
                    if (k >= 1.7f) 1.5f else if (k >= 1.3f) 1.25f else 1f
                } else 1f
                runs.add(
                    Run(
                        start, start + item.text.length,
                        ink?.fg ?: readable(pageBg),
                        ink != null && medRatio > 0f && ink.ratio > medRatio * 1.35f,
                        scale
                    )
                )
            }
            sb.append(line)
            prevBottom = bottom
        }
        return Laid(sb.toString(), pageBg, runs)
    }

    private fun sameRow(row: List<L>, l: L): Boolean {
        val rcy = row.map { it.cy }.average()
        val rh = row.map { it.r.height() }.average()
        return abs(l.cy - rcy) < 0.5 * min(rh, l.r.height().toDouble())
    }

    private fun readable(bg: Int): Int {
        val lum = 0.299 * AColor.red(bg) + 0.587 * AColor.green(bg) + 0.114 * AColor.blue(bg)
        return if (lum < 128) WHITE else 0xFF111111.toInt()
    }

    private fun dist(a: Int, b: Int) =
        abs(AColor.red(a) - AColor.red(b)) + abs(AColor.green(a) - AColor.green(b)) + abs(AColor.blue(a) - AColor.blue(b))

    private fun rgb(r: Long, g: Long, b: Long, n: Int) =
        AColor.rgb((r / n).toInt(), (g / n).toInt(), (b / n).toInt())

    private fun bucket(p: Int) =
        ((AColor.red(p) shr 4) shl 8) or ((AColor.green(p) shr 4) shl 4) or (AColor.blue(p) shr 4)

    private fun pageBackground(bgs: List<Int>): Int {
        if (bgs.isEmpty()) return WHITE
        fun med(f: (Int) -> Int) = bgs.map(f).sorted()[bgs.size / 2]
        return AColor.rgb(med(AColor::red), med(AColor::green), med(AColor::blue))
    }

    /** Relève la couleur de fond, la couleur du texte et la « densité d'encre » (gras) d'une ligne. */
    private fun sample(bmp: Bitmap, r: Rect): Ink? {
        val l = r.left.coerceIn(0, bmp.width - 1)
        val t = r.top.coerceIn(0, bmp.height - 1)
        val rt = r.right.coerceIn(l + 1, bmp.width)
        val bt = r.bottom.coerceIn(t + 1, bmp.height)
        val sx = max(1, (rt - l) / 40)
        val sy = max(1, (bt - t) / 12)
        val px = ArrayList<Int>()
        var y = t
        while (y < bt) {
            var x = l
            while (x < rt) { px.add(bmp.getPixel(x, y)); x += sx }
            y += sy
        }
        if (px.size < 6) return null
        val counts = HashMap<Int, Int>()
        for (p in px) counts[bucket(p)] = (counts[bucket(p)] ?: 0) + 1
        val key = counts.maxByOrNull { it.value }!!.key
        var sr = 0L; var sg = 0L; var sb = 0L; var n = 0
        for (p in px) if (bucket(p) == key) { sr += AColor.red(p); sg += AColor.green(p); sb += AColor.blue(p); n++ }
        val bg = rgb(sr, sg, sb, n)
        val d = px.map { dist(it, bg) }
        val maxD = d.max()
        if (maxD < 120) return Ink(bg, readable(bg), 0f)
        var fr = 0L; var fg = 0L; var fb = 0L; var fn = 0
        for (i in px.indices) if (d[i] >= maxD * 0.75f) {
            fr += AColor.red(px[i]); fg += AColor.green(px[i]); fb += AColor.blue(px[i]); fn++
        }
        return Ink(bg, rgb(fr, fg, fb, fn), d.count { it > 120 } / px.size.toFloat())
    }
}
