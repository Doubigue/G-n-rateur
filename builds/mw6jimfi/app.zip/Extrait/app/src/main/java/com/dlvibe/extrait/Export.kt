package com.dlvibe.extrait

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.max
import kotlin.math.min

/** Exporte le résultat (avec fond, couleurs, gras) en PDF, Word ou Excel. */
object Export {
    private class Ln(val text: String, val start: Int, val runs: List<Run>)

    fun mime(fmt: String) = when (fmt) {
        "pdf" -> "application/pdf"
        "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        else -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    }

    fun build(ctx: Context, fmt: String, items: List<ScanItem>): File {
        val out = File(dir(ctx), "Extrait.$fmt")
        when (fmt) {
            "pdf" -> pdf(items, out)
            "docx" -> docx(items, out)
            else -> xlsx(items, out)
        }
        return out
    }

    fun share(ctx: Context, file: File, mime: String) {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(send, "Enregistrer / partager"))
    }

    /** Copie un fichier fourni par le scanner (ex. PDF numérisé) pour le partager tel quel. */
    fun copyUri(ctx: Context, uri: Uri, name: String): File {
        val f = File(dir(ctx), name)
        ctx.contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        return f
    }

    private fun dir(ctx: Context) = File(ctx.cacheDir, "exports").apply { mkdirs() }

    private fun lines(item: ScanItem): List<Ln> {
        if (item.text.isBlank()) return listOf(Ln("(aucun texte détecté)", 0, emptyList()))
        val runs = item.runs.sortedBy { it.start }
        val out = ArrayList<Ln>()
        var pos = 0
        var ri = 0
        for (raw in item.text.split('\n')) {
            val end = pos + raw.length
            val mine = ArrayList<Run>()
            while (ri < runs.size && runs[ri].start < end) { if (runs[ri].start >= pos) mine.add(runs[ri]); ri++ }
            out.add(Ln(raw, pos, mine))
            pos = end + 1
        }
        return out
    }

    private fun hex(c: Int) = String.format("%06X", c and 0xFFFFFF)

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    private fun zip(out: File, parts: Map<String, String>) {
        ZipOutputStream(FileOutputStream(out)).use { z ->
            for ((name, body) in parts) {
                z.putNextEntry(ZipEntry(name)); z.write(body.toByteArray(Charsets.UTF_8)); z.closeEntry()
            }
        }
    }

    // ---------------------------------------------------------------- PDF
    private fun pdf(items: List<ScanItem>, out: File) {
        val doc = PdfDocument()
        val w = 595; val h = 842; val m = 34f
        var pageNo = 1
        for (item in items) {
            val ls = lines(item)
            val maxCols = max(1, ls.maxOf { it.text.length })
            val base = min(10f, (w - 2 * m) / (maxCols * 0.6f)).coerceAtLeast(4f)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.MONOSPACE; textSize = base }
            val cw = paint.measureText("M")
            var page: PdfDocument.Page? = null
            var cv: Canvas? = null
            var y = m
            for (ln in ls) {
                val scale = ln.runs.maxOfOrNull { it.scale } ?: 1f
                val lh = base * 1.35f * scale
                if (page == null || y + lh > h - m) {
                    page?.let { doc.finishPage(it) }
                    val np = doc.startPage(PdfDocument.PageInfo.Builder(w, h, pageNo++).create())
                    np.canvas.drawColor(item.bg)
                    page = np; cv = np.canvas; y = m
                }
                val baseline = y + base * scale
                y += lh
                if (ln.runs.isEmpty()) {
                    paint.textSize = base; paint.isFakeBoldText = false; paint.color = 0xFF555555.toInt()
                    if (ln.text.isNotBlank()) cv!!.drawText(ln.text, m, baseline, paint)
                    continue
                }
                for (r in ln.runs) {
                    paint.textSize = base * r.scale
                    paint.isFakeBoldText = r.bold
                    paint.color = r.color
                    cv!!.drawText(item.text.substring(r.start, r.end), m + (r.start - ln.start) * cw, baseline, paint)
                }
            }
            page?.let { doc.finishPage(it) }
        }
        FileOutputStream(out).use { doc.writeTo(it) }
        doc.close()
    }

    // ---------------------------------------------------------------- Word
    private fun docx(items: List<ScanItem>, out: File) {
        val body = StringBuilder()
        items.forEachIndexed { idx, item ->
            val ls = lines(item)
            val maxCols = max(1, ls.maxOf { it.text.length })
            val sz = min(20, (540f / (maxCols * 0.6f) * 2).toInt()).coerceAtLeast(8)
            val fill = hex(item.bg)
            ls.forEachIndexed { i, ln ->
                body.append("<w:p><w:pPr>")
                if (idx > 0 && i == 0) body.append("<w:pageBreakBefore/>")
                body.append("<w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"$fill\"/>")
                body.append("<w:spacing w:before=\"0\" w:after=\"0\" w:line=\"240\" w:lineRule=\"auto\"/>")
                body.append("<w:rPr><w:sz w:val=\"$sz\"/></w:rPr></w:pPr>")
                fun run(t: String, color: String?, bold: Boolean, size: Int) {
                    body.append("<w:r><w:rPr><w:rFonts w:ascii=\"Courier New\" w:hAnsi=\"Courier New\" w:cs=\"Courier New\"/>")
                    if (bold) body.append("<w:b/>")
                    if (color != null) body.append("<w:color w:val=\"$color\"/>")
                    body.append("<w:sz w:val=\"$size\"/></w:rPr><w:t xml:space=\"preserve\">${esc(t)}</w:t></w:r>")
                }
                if (ln.runs.isEmpty()) {
                    if (ln.text.isNotBlank()) run(ln.text, "555555", false, sz)
                } else {
                    var col = 0
                    for (r in ln.runs) {
                        val gap = (r.start - ln.start) - col
                        if (gap > 0) run(" ".repeat(gap), null, false, sz)
                        run(item.text.substring(r.start, r.end), hex(r.color), r.bold, (sz * r.scale).toInt())
                        col = r.end - ln.start
                    }
                }
                body.append("</w:p>")
            }
        }
        val ns = "xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\""
        zip(out, linkedMapOf(
            "[Content_Types].xml" to "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/></Types>",
            "_rels/.rels" to "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/></Relationships>",
            "word/document.xml" to "<?xml version=\"1.0\" encoding=\"UTF-8\"?><w:document $ns><w:body>$body<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/><w:pgMar w:top=\"720\" w:right=\"720\" w:bottom=\"720\" w:left=\"720\" w:header=\"0\" w:footer=\"0\" w:gutter=\"0\"/></w:sectPr></w:body></w:document>"
        ))
    }

    // ---------------------------------------------------------------- Excel
    private fun colName(i: Int): String {
        var n = i; val s = StringBuilder()
        do { s.insert(0, 'A' + n % 26); n = n / 26 - 1 } while (n >= 0)
        return s.toString()
    }

    private fun xlsx(items: List<ScanItem>, out: File) {
        val fonts = arrayListOf("<font><sz val=\"11\"/><name val=\"Calibri\"/></font>")
        val fills = arrayListOf("<fill><patternFill patternType=\"none\"/></fill>", "<fill><patternFill patternType=\"gray125\"/></fill>")
        val xfs = arrayListOf("<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>")
        val xfKey = HashMap<String, Int>()
        val fillKey = HashMap<Int, Int>()
        fun style(r: Run, bg: Int): Int = xfKey.getOrPut("${r.color}|${r.bold}|$bg|${r.scale}") {
            fonts.add("<font>${if (r.bold) "<b/>" else ""}<sz val=\"${11 * r.scale}\"/><color rgb=\"FF${hex(r.color)}\"/><name val=\"Calibri\"/></font>")
            val fi = fillKey.getOrPut(bg) {
                fills.add("<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF${hex(bg)}\"/><bgColor indexed=\"64\"/></patternFill></fill>")
                fills.size - 1
            }
            xfs.add("<xf numFmtId=\"0\" fontId=\"${fonts.size - 1}\" fillId=\"$fi\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\"/>")
            xfs.size - 1
        }

        val sheets = items.map { item ->
            val sb = StringBuilder()
            lines(item).forEachIndexed { i, ln ->
                if (ln.runs.isEmpty() && ln.text.isBlank()) return@forEachIndexed
                sb.append("<row r=\"${i + 1}\">")
                if (ln.runs.isEmpty()) sb.append("<c r=\"A${i + 1}\" t=\"inlineStr\"><is><t>${esc(ln.text)}</t></is></c>")
                ln.runs.forEachIndexed { c, r ->
                    sb.append("<c r=\"${colName(c)}${i + 1}\" s=\"${style(r, item.bg)}\" t=\"inlineStr\"><is><t xml:space=\"preserve\">${esc(item.text.substring(r.start, r.end))}</t></is></c>")
                }
                sb.append("</row>")
            }
            sb.toString()
        }

        val main = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
        val rel = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
        val parts = linkedMapOf<String, String>()
        val overrides = StringBuilder()
        val wbSheets = StringBuilder()
        val wbRels = StringBuilder()
        sheets.forEachIndexed { i, rows ->
            val n = i + 1
            parts["xl/worksheets/sheet$n.xml"] = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet xmlns=\"$main\"><cols><col min=\"1\" max=\"40\" width=\"24\" customWidth=\"1\"/></cols><sheetData>$rows</sheetData></worksheet>"
            overrides.append("<Override PartName=\"/xl/worksheets/sheet$n.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>")
            wbSheets.append("<sheet name=\"Image ${items[i].index + 1}\" sheetId=\"$n\" r:id=\"rId$n\"/>")
            wbRels.append("<Relationship Id=\"rId$n\" Type=\"$rel/worksheet\" Target=\"worksheets/sheet$n.xml\"/>")
        }
        val sid = sheets.size + 1
        wbRels.append("<Relationship Id=\"rId$sid\" Type=\"$rel/styles\" Target=\"styles.xml\"/>")
        val styles = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><styleSheet xmlns=\"$main\"><fonts count=\"${fonts.size}\">${fonts.joinToString("")}</fonts><fills count=\"${fills.size}\">${fills.joinToString("")}</fills><borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs><cellXfs count=\"${xfs.size}\">${xfs.joinToString("")}</cellXfs></styleSheet>"

        val all = linkedMapOf(
            "[Content_Types].xml" to "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>$overrides</Types>",
            "_rels/.rels" to "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"$rel/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>",
            "xl/workbook.xml" to "<?xml version=\"1.0\" encoding=\"UTF-8\"?><workbook xmlns=\"$main\" xmlns:r=\"$rel\"><sheets>$wbSheets</sheets></workbook>",
            "xl/_rels/workbook.xml.rels" to "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">$wbRels</Relationships>",
            "xl/styles.xml" to styles
        )
        all.putAll(parts)
        zip(out, all)
    }
}
