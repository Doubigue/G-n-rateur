package com.dlvibe.extrait.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.TextDecrease
import androidx.compose.material.icons.rounded.TextIncrease
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dlvibe.extrait.ScanItem
import com.dlvibe.extrait.ScanViewModel
import kotlinx.coroutines.delay

@Composable
fun ViewerScreen(
    vm: ScanViewModel,
    index: Int,
    onBack: () -> Unit,
    onCopy: (String) -> Unit,
    onExport: (String) -> Unit
) {
    val items = vm.items
    val sections: List<ScanItem> = if (index >= 0) listOfNotNull(items.getOrNull(index)) else items.toList()
    val multi = index < 0 && items.size > 1
    val title = if (multi) "Toutes les images" else sections.firstOrNull()?.name ?: "Texte extrait"
    val words = sections.sumOf { it.words }
    val subtitle = if (multi) "${items.size} images · $words mots" else "$words mots"

    var size by rememberSaveable { mutableIntStateOf(13) }
    var copied by remember { mutableStateOf(false) }
    LaunchedEffect(copied) {
        if (copied) {
            delay(1600)
            copied = false
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 8.dp, end = 14.dp, top = 4.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Retour", tint = Ink)
            }
            Column(Modifier.weight(1f)) {
                Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(subtitle, fontSize = 13.sp, color = Muted)
            }
            var menu by remember { mutableStateOf(false) }
            Box {
                IconButton(onClick = { menu = true }) {
                    Icon(Icons.Rounded.Download, contentDescription = "Enregistrer", tint = Ink)
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    listOf("pdf" to "PDF", "docx" to "Word (.docx)", "xlsx" to "Excel (.xlsx)", "txt" to "Texte (.txt)").forEach { (k, l) ->
                        DropdownMenuItem(text = { Text(l) }, onClick = { menu = false; onExport(k) })
                    }
                }
            }
            FilledIconButton(
                onClick = {
                    onCopy(vm.textFor(index))
                    copied = true
                },
                modifier = Modifier.size(46.dp),
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = Ink, contentColor = Beam)
            ) {
                Icon(
                    if (copied) Icons.Rounded.Check else Icons.Rounded.ContentCopy,
                    contentDescription = "Copier le texte"
                )
            }
        }

        // La « page » : fond, couleurs, gras et titres relevés dans l'image ; le texte reste sélectionnable.
        Surface(
            modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp),
            shape = RoundedCornerShape(22.dp),
            color = Color.White,
            shadowElevation = 3.dp
        ) {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                itemsIndexed(sections, key = { _, s -> s.index }) { _, s ->
                    val bg = Color(s.bg)
                    val base = if (bg.luminance() < 0.5f) Color.White else Ink
                    Column(Modifier.fillMaxWidth().background(bg).padding(18.dp)) {
                        if (multi) SectionHeader(s, base)
                        if (s.text.isBlank()) {
                            Text(
                                if (s.failed) "Lecture impossible pour cette image." else "Aucun texte détecté.",
                                color = base.copy(alpha = 0.7f),
                                fontStyle = FontStyle.Italic,
                                fontSize = 14.sp
                            )
                        } else {
                            val styled = remember(s, size) { styledText(s, size) }
                            SelectionContainer {
                                Text(
                                    styled,
                                    softWrap = false,
                                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                                    style = TextStyle(fontFamily = FontFamily.Monospace, fontSize = size.sp, color = base)
                                )
                            }
                        }
                    }
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(vertical = 10.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(shape = RoundedCornerShape(24.dp), color = Color.White, shadowElevation = 2.dp) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { if (size > 9) size-- }) {
                        Icon(Icons.Rounded.TextDecrease, contentDescription = "Réduire le texte", tint = Ink)
                    }
                    Text("$size", fontWeight = FontWeight.Bold, color = Ink, fontSize = 15.sp)
                    IconButton(onClick = { if (size < 24) size++ }) {
                        Icon(Icons.Rounded.TextIncrease, contentDescription = "Agrandir le texte", tint = Ink)
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionHeader(s: ScanItem, textColor: Color) {
    Row(Modifier.padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.clip(RoundedCornerShape(8.dp)).background(Beam).padding(horizontal = 8.dp, vertical = 3.dp),
            contentAlignment = Alignment.Center
        ) { Text("${s.index + 1}", color = Ink, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
        Spacer(Modifier.width(10.dp))
        Text(s.name, fontWeight = FontWeight.SemiBold, color = textColor, fontSize = 14.sp, maxLines = 1)
    }
}

private fun styledText(s: ScanItem, base: Int): AnnotatedString = buildAnnotatedString {
    append(s.text)
    for (r in s.runs) {
        if (r.start >= r.end || r.end > s.text.length) continue
        addStyle(
            SpanStyle(
                color = Color(r.color),
                fontWeight = if (r.bold) FontWeight.Bold else null,
                fontSize = if (r.scale != 1f) (base * r.scale).sp else TextUnit.Unspecified
            ),
            r.start, r.end
        )
    }
}
