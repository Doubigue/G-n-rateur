@file:OptIn(ExperimentalMaterial3Api::class)

package com.dlvibe.extrait.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.remember
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.draw.drawBehind
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddPhotoAlternate
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.DocumentScanner
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dlvibe.extrait.ScanItem
import com.dlvibe.extrait.ScanViewModel

@Composable
fun HomeScreen(
    vm: ScanViewModel,
    listState: LazyListState,
    onPick: () -> Unit,
    onScan: () -> Unit,
    onDigitize: () -> Unit,
    onOpen: (Int) -> Unit,
    onCopy: (String) -> Unit,
    onExport: (String) -> Unit
) {
    val items = vm.items
    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 40.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(Modifier.padding(top = 8.dp, bottom = 4.dp)) {
                Text("Extrait", fontSize = 34.sp, fontWeight = FontWeight.Black, color = Ink, letterSpacing = (-1).sp)
                Text("Le texte de vos images, mis en page comme l’original.", color = Muted, fontSize = 15.sp)
            }
        }
        item { HeroCard(running = vm.running, onPick = onPick, onScan = onScan, onDigitize = onDigitize) }
        if (vm.running) {
            item { ProgressCard(done = items.size, total = vm.total, onCancel = vm::cancel) }
        } else if (items.isNotEmpty()) {
            item {
                SummaryCard(
                    count = items.size,
                    words = items.sumOf { it.words },
                    onOpen = { onOpen(-1) },
                    onCopy = { onCopy(vm.textFor(-1)) },
                    onExport = onExport
                )
            }
        }
        itemsIndexed(items, key = { _, item -> item.index }) { i, item ->
            ResultRow(item = item, onOpen = { onOpen(i) }, onCopy = { onCopy(vm.textFor(i)) })
        }
    }
}

@Composable
private fun WhiteCard(
    onClick: (() -> Unit)? = null,
    radius: Dp = 24.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(radius)
    val colors = CardDefaults.cardColors(containerColor = Color.White)
    val elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    if (onClick != null) {
        Card(onClick = onClick, shape = shape, colors = colors, elevation = elevation, modifier = Modifier.fillMaxWidth(), content = content)
    } else {
        Card(shape = shape, colors = colors, elevation = elevation, modifier = Modifier.fillMaxWidth(), content = content)
    }
}

@Composable
private fun HeroCard(running: Boolean, onPick: () -> Unit, onScan: () -> Unit, onDigitize: () -> Unit) {
    Card(
        shape = RoundedCornerShape(30.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(
            Modifier
                .background(Brush.linearGradient(listOf(Ink, InkSoft)))
                .drawBehind {
                    val rad = size.width * 0.6f
                    drawCircle(
                        Brush.radialGradient(listOf(Beam.copy(alpha = 0.28f), Color.Transparent), Offset(size.width, 0f), rad),
                        rad, Offset(size.width, 0f)
                    )
                }
        ) {
            Column(Modifier.padding(22.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            "Lisez le texte de vos images",
                            color = Color.White,
                            fontSize = 25.sp,
                            lineHeight = 29.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = (-0.5).sp
                        )
                        Spacer(Modifier.height(10.dp))
                        Text(
                            "Une photo ou des centaines. La mise en page est conservée et tout reste sur votre téléphone.",
                            color = Color(0xFFB9C3E3),
                            fontSize = 14.sp,
                            lineHeight = 20.sp
                        )
                    }
                    Spacer(Modifier.width(16.dp))
                    ScanPage(running, Modifier.size(84.dp, 108.dp))
                }
                Spacer(Modifier.height(20.dp))
                Button(
                    onClick = onPick,
                    enabled = !running,
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Beam,
                        contentColor = Ink,
                        disabledContainerColor = Color(0x33FFFFFF),
                        disabledContentColor = Color(0x99FFFFFF)
                    )
                ) {
                    Icon(Icons.Rounded.AddPhotoAlternate, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Choisir des images", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    listOf(
                        Triple("Scanner (texte)", Icons.Rounded.DocumentScanner, onScan),
                        Triple("Numériser (PDF)", Icons.Rounded.PictureAsPdf, onDigitize)
                    ).forEach { (label, icon, click) ->
                        OutlinedButton(
                            onClick = click,
                            enabled = !running,
                            modifier = Modifier.weight(1f).height(48.dp),
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, Color(0x66FFFFFF)),
                            contentPadding = PaddingValues(horizontal = 8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White, disabledContentColor = Color(0x99FFFFFF))
                        ) {
                            Icon(icon, contentDescription = null, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}

/** Petite page avec un faisceau qui balaie pendant la lecture. */
@Composable
private fun ScanPage(running: Boolean, modifier: Modifier) {
    val transition = rememberInfiniteTransition(label = "scan")
    val anim by transition.animateFloat(
        initialValue = 0.06f,
        targetValue = 0.94f,
        animationSpec = infiniteRepeatable(tween(1600, easing = LinearEasing), RepeatMode.Reverse),
        label = "beam"
    )
    val p = if (running) anim else 0.42f
    Canvas(modifier.clip(RoundedCornerShape(14.dp))) {
        val w = size.width
        val h = size.height
        drawRect(Color.White.copy(alpha = 0.96f))
        val bars = listOf(0.7f, 0.9f, 0.55f, 0.85f, 0.4f, 0.8f, 0.65f)
        var y = h * 0.14f
        bars.forEach { f ->
            drawRoundRect(
                color = Line,
                topLeft = Offset(w * 0.12f, y),
                size = Size(w * 0.76f * f, 5.dp.toPx()),
                cornerRadius = CornerRadius(3.dp.toPx())
            )
            y += h * 0.115f
        }
        val by = h * p
        val glow = 26.dp.toPx()
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color.Transparent, Beam.copy(alpha = 0.55f)),
                startY = by - glow,
                endY = by
            ),
            topLeft = Offset(0f, by - glow),
            size = Size(w, glow)
        )
        drawLine(Beam, Offset(0f, by), Offset(w, by), strokeWidth = 2.5.dp.toPx())
    }
}

@Composable
private fun ProgressCard(done: Int, total: Int, onCancel: () -> Unit) {
    val progress by animateFloatAsState(if (total == 0) 0f else done / total.toFloat(), label = "progress")
    WhiteCard(radius = 28.dp) {
        Column(Modifier.padding(22.dp)) {
            Row(verticalAlignment = Alignment.Bottom) {
                Text("${(progress * 100).toInt()}", fontSize = 44.sp, fontWeight = FontWeight.Black, color = Cobalt, letterSpacing = (-1.5).sp)
                Text("%", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Cobalt, modifier = Modifier.padding(start = 2.dp, bottom = 8.dp))
                Spacer(Modifier.weight(1f))
                TextButton(onClick = onCancel) { Text("Arrêter") }
            }
            Text("$done sur $total images lues", color = Muted, fontSize = 14.sp)
            Spacer(Modifier.height(14.dp))
            Box(Modifier.fillMaxWidth().height(10.dp).clip(CircleShape).background(Line)) {
                Box(
                    Modifier.fillMaxWidth(progress.coerceIn(0f, 1f)).height(10.dp).clip(CircleShape)
                        .background(Brush.horizontalGradient(listOf(Cobalt, Color(0xFF6C7CFF))))
                )
            }
        }
    }
}

@Composable
private fun SummaryCard(
    count: Int,
    words: Int,
    onOpen: () -> Unit,
    onCopy: () -> Unit,
    onExport: (String) -> Unit
) {
    Card(
        onClick = onOpen,
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(
            Modifier
                .background(Brush.linearGradient(listOf(Cobalt, Color(0xFF1631B8))))
                .drawBehind {
                    val rad = size.width * 0.55f
                    drawCircle(
                        Brush.radialGradient(listOf(Beam.copy(alpha = 0.30f), Color.Transparent), Offset(size.width, 0f), rad),
                        rad, Offset(size.width, 0f)
                    )
                }
        ) {
            Column(Modifier.padding(22.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(48.dp).clip(CircleShape).background(Beam), contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.Check, contentDescription = null, tint = Ink)
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Extraction terminée", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Black)
                        Text("Prêt à copier ou à enregistrer", color = Color(0xFFC9D3FF), fontSize = 13.sp)
                    }
                }
                Spacer(Modifier.height(18.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    listOf(count.toString() to (if (count > 1) "images" else "image"), words.toString() to (if (words > 1) "mots" else "mot"))
                        .forEach { (v, l) ->
                            Column(
                                Modifier.weight(1f).clip(RoundedCornerShape(18.dp)).background(Color(0x26FFFFFF)).padding(14.dp)
                            ) {
                                Text(v, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black, letterSpacing = (-0.5).sp)
                                Text(l, color = Color(0xFFC9D3FF), fontSize = 12.sp)
                            }
                        }
                }
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Button(
                        onClick = onOpen,
                        modifier = Modifier.weight(1f).height(52.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Beam, contentColor = Ink)
                    ) {
                        Icon(Icons.Rounded.Description, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Ouvrir le texte", fontWeight = FontWeight.Bold)
                    }
                    FilledIconButton(
                        onClick = onCopy,
                        modifier = Modifier.size(52.dp),
                        colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color(0x33FFFFFF), contentColor = Color.White)
                    ) { Icon(Icons.Rounded.ContentCopy, contentDescription = "Copier tout le texte") }
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("pdf" to "PDF", "docx" to "Word", "xlsx" to "Excel").forEach { (k, l) ->
                        Box(
                            Modifier.weight(1f).height(40.dp).clip(RoundedCornerShape(12.dp))
                                .background(Color(0x26FFFFFF)).clickable { onExport(k) },
                            contentAlignment = Alignment.Center
                        ) { Text(l, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
                    }
                }
            }
        }
    }
}

@Composable
private fun ResultRow(item: ScanItem, onOpen: () -> Unit, onCopy: () -> Unit) {
    val preview = item.text.lineSequence().firstOrNull { it.isNotBlank() }?.trim()
    val canCopy = item.text.isNotBlank()
    val bg = Color(item.bg)
    val fg = item.runs.firstOrNull()?.let { Color(it.color) } ?: Ink
    WhiteCard(onClick = onOpen, radius = 22.dp) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(58.dp, 74.dp).clip(RoundedCornerShape(14.dp)).background(bg).border(1.dp, Line, RoundedCornerShape(14.dp))) {
                item.thumb?.let { t ->
                    val img = remember(t) { t.asImageBitmap() }
                    Image(img, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                }
                Box(
                    Modifier.align(Alignment.BottomStart).padding(5.dp).clip(RoundedCornerShape(8.dp))
                        .background(Ink).padding(horizontal = 6.dp, vertical = 2.dp)
                ) { Text("${item.index + 1}", color = Beam, fontWeight = FontWeight.Bold, fontSize = 11.sp) }
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(item.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold, color = Ink, fontSize = 15.sp)
                Spacer(Modifier.height(6.dp))
                when {
                    item.failed -> Text("Lecture impossible", color = Color(0xFFB3261E), fontSize = 13.sp)
                    preview == null -> Text("Aucun texte détecté", color = Muted, fontSize = 13.sp)
                    else -> Box(
                        Modifier.clip(RoundedCornerShape(8.dp)).background(bg).border(1.dp, Line, RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(preview, color = fg, fontFamily = FontFamily.Monospace, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text("${item.words} mot${if (item.words > 1) "s" else ""}", color = Muted, fontSize = 12.sp)
            }
            FilledIconButton(
                onClick = onCopy,
                enabled = canCopy,
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = Page, contentColor = Cobalt,
                    disabledContainerColor = Page, disabledContentColor = Line
                )
            ) { Icon(Icons.Rounded.ContentCopy, contentDescription = "Copier le texte de cette image") }
        }
    }
}
