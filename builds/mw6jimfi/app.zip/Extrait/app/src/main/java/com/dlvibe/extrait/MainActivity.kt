package com.dlvibe.extrait

import android.app.Activity
import android.graphics.Color as AColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.lifecycle.viewmodel.compose.viewModel
import com.dlvibe.extrait.ui.CropScreen
import com.dlvibe.extrait.ui.ExtraitTheme
import com.dlvibe.extrait.ui.HomeScreen
import com.dlvibe.extrait.ui.Page
import com.dlvibe.extrait.ui.ViewerScreen
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(AColor.TRANSPARENT, AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.light(AColor.TRANSPARENT, AColor.TRANSPARENT)
        )
        setContent { ExtraitTheme { App() } }
    }
}

@Composable
private fun App(vm: ScanViewModel = viewModel()) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val snack = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    // L'écran reste allumé pendant la lecture de nombreuses images.
    DisposableEffect(vm.running) {
        view.keepScreenOn = vm.running
        onDispose { view.keepScreenOn = false }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) vm.pending = uris
    }

    // Scanner de documents (caméra) : soit on lit le texte, soit on numérise en PDF.
    var digitize by remember { mutableStateOf(false) }
    val scanner = remember {
        GmsDocumentScanning.getClient(
            GmsDocumentScannerOptions.Builder()
                .setGalleryImportAllowed(true)
                .setPageLimit(100)
                .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_JPEG, GmsDocumentScannerOptions.RESULT_FORMAT_PDF)
                .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
                .build()
        )
    }
    val scanLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        if (res.resultCode != Activity.RESULT_OK) return@rememberLauncherForActivityResult
        val r = GmsDocumentScanningResult.fromActivityResultIntent(res.data) ?: return@rememberLauncherForActivityResult
        if (digitize) {
            val pdf = r.pdf?.uri ?: return@rememberLauncherForActivityResult
            scope.launch {
                try {
                    val f = withContext(Dispatchers.IO) { Export.copyUri(ctx, pdf, "Numerisation.pdf") }
                    Export.share(ctx, f, "application/pdf")
                } catch (e: Throwable) { snack.showSnackbar("Enregistrement impossible") }
            }
        } else {
            vm.start(r.pages?.map { it.imageUri }.orEmpty())
        }
    }
    val launchScan: (Boolean) -> Unit = { d ->
        digitize = d
        scanner.getStartScanIntent(ctx as Activity)
            .addOnSuccessListener { scanLauncher.launch(IntentSenderRequest.Builder(it).build()) }
            .addOnFailureListener { scope.launch { snack.showSnackbar("Scanner indisponible sur cet appareil") } }
    }

    val export: (String, Int) -> Unit = { fmt, index ->
        scope.launch {
            try {
                if (fmt == "txt") {
                    Actions.share(ctx, vm.textFor(index))
                } else {
                    val sections = if (index >= 0) listOfNotNull(vm.items.getOrNull(index)) else vm.items.toList()
                    val f = withContext(Dispatchers.Default) { Export.build(ctx, fmt, sections) }
                    Export.share(ctx, f, Export.mime(fmt))
                }
            } catch (e: Throwable) {
                snack.showSnackbar("Export impossible")
            }
        }
    }

    val copy: (String) -> Unit = { text ->
        val ok = Actions.copy(ctx, text)
        scope.launch {
            snack.currentSnackbarData?.dismiss()
            snack.showSnackbar(if (ok) "Texte copié" else "Texte trop volumineux : utilisez Partager")
        }
    }

    BackHandler(enabled = vm.pending.isNotEmpty()) { vm.pending = emptyList() }
    BackHandler(enabled = vm.viewing != null && vm.pending.isEmpty()) { vm.viewing = null }

    Scaffold(containerColor = Page, snackbarHost = { SnackbarHost(snack) }) { pad ->
        if (vm.pending.isNotEmpty()) {
            CropScreen(
                vm = vm,
                modifier = Modifier.padding(pad),
                onCancel = { vm.pending = emptyList() },
                onConfirm = { vm.start(vm.pending, it) }
            )
            return@Scaffold
        }
        AnimatedContent(
            targetState = vm.viewing,
            modifier = Modifier.padding(pad),
            transitionSpec = {
                if (targetState != null && initialState == null) {
                    (slideInHorizontally { it / 4 } + fadeIn()) togetherWith fadeOut()
                } else {
                    fadeIn() togetherWith (slideOutHorizontally { it / 4 } + fadeOut())
                }
            },
            label = "screen"
        ) { v ->
            if (v == null) {
                HomeScreen(
                    vm = vm,
                    listState = listState,
                    onPick = { picker.launch("image/*") },
                    onScan = { launchScan(false) },
                    onDigitize = { launchScan(true) },
                    onOpen = { vm.viewing = it },
                    onCopy = copy,
                    onExport = { export(it, -1) }
                )
            } else {
                ViewerScreen(
                    vm = vm,
                    index = v,
                    onBack = { vm.viewing = null },
                    onCopy = copy,
                    onExport = { export(it, v) }
                )
            }
        }
    }
}
