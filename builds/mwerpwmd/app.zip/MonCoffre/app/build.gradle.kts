plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.moncoffre.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.moncoffre.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 3
        versionName = "1.0"
    }

    // Même clé pour toutes les compilations : une nouvelle version s'installe
    // par-dessus l'ancienne sans désinstaller (donc sans perdre le coffre).
    signingConfigs {
        create("shared") {
            storeFile = rootProject.file("keystore/moncoffre.jks")
            storePassword = "moncoffre"
            keyAlias = "moncoffre"
            keyPassword = "moncoffre"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("shared")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("shared")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.7.0")
    implementation("androidx.biometric:biometric:1.1.0")
}
