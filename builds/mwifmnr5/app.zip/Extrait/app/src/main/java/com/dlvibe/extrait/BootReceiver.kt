package com.dlvibe.extrait

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Relance la surveillance des captures d'écran après un redémarrage ou une mise à jour. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        try {
            Prefs.apply(context)
        } catch (e: Throwable) {
            // Démarrage en arrière-plan refusé : la surveillance reprendra à l'ouverture de l'app.
        }
    }
}
