package com.dlvibe.extrait

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Réglage « détection des captures d'écran » + état des autorisations nécessaires. */
object Prefs {
    private const val FILE = "extrait"
    private const val KEY_SHOT = "screenshot_watch"

    fun watching(ctx: Context): Boolean =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getBoolean(KEY_SHOT, false)

    fun setWatching(ctx: Context, on: Boolean) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putBoolean(KEY_SHOT, on).apply()
    }

    /** Permission de lire les images (pour voir apparaître la capture d'écran). */
    val mediaPermission: String
        get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
        else Manifest.permission.READ_EXTERNAL_STORAGE

    fun hasMedia(ctx: Context) =
        ContextCompat.checkSelfPermission(ctx, mediaPermission) == PackageManager.PERMISSION_GRANTED

    fun hasNotifications(ctx: Context) =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun hasOverlay(ctx: Context) = Settings.canDrawOverlays(ctx)

    fun overlaySettingsIntent(ctx: Context): Intent =
        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:${ctx.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun ignoresBattery(ctx: Context): Boolean =
        ctx.getSystemService(PowerManager::class.java)?.isIgnoringBatteryOptimizations(ctx.packageName) == true

    fun batteryIntent(ctx: Context): Intent =
        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, android.net.Uri.parse("package:${ctx.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    /** Démarre ou arrête le service selon le réglage et les autorisations. */
    fun apply(ctx: Context) {
        if (watching(ctx) && hasMedia(ctx)) ScreenshotService.start(ctx) else ScreenshotService.stop(ctx)
    }
}

/** Journal de diagnostic de la détection des captures : écrit par le service, affiché sur l'accueil. */
object ShotLog {
    private const val FILE = "extrait_log"

    fun now(): String = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())

    fun put(ctx: Context, key: String, value: String) {
        try {
            ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString(key, value).apply()
        } catch (e: Throwable) {
            // journal indisponible : sans conséquence
        }
    }

    private fun get(ctx: Context, key: String, empty: String): String =
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(key, null) ?: empty

    /** Ajoute une ligne à l'historique (les 8 dernières sont conservées). */
    @Synchronized
    fun add(ctx: Context, msg: String) {
        try {
            val p = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            val old = p.getString("hist", "").orEmpty().lines().filter { it.isNotBlank() }
            val next = (old + "${now()} $msg").takeLast(8)
            p.edit().putString("hist", next.joinToString("\n")).apply()
        } catch (e: Throwable) {
            // journal indisponible : sans conséquence
        }
    }

    private fun yn(ok: Boolean) = if (ok) "oui" else "NON"

    fun report(ctx: Context): String {
        val hist = get(ctx, "hist", "").lines().filter { it.isNotBlank() }
        val head = listOf(
            "Service : " + get(ctx, "service", "jamais démarré"),
            "Galerie : dernier signal " + get(ctx, "event", "jamais reçu"),
            "Photos : " + yn(Prefs.hasMedia(ctx)) + " · Flottante : " + yn(Prefs.hasOverlay(ctx)) +
                " · Notifs : " + yn(Prefs.hasNotifications(ctx)),
            "Batterie sans restriction : " + yn(Prefs.ignoresBattery(ctx)),
            "Journal :"
        )
        return (head + (if (hist.isEmpty()) listOf("  (vide)") else hist.map { "  $it" })).joinToString("\n")
    }
}
