package com.dlvibe.debit;

import android.Manifest;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.provider.Settings;

/** Garde l'affichage actif : réactivation de l'accessibilité, sinon icône de notification. */
final class Keeper {
    private Keeper() {}

    static boolean overlayEnabled(Context c) {
        String list = Settings.Secure.getString(c.getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (list == null) return false;
        ComponentName mine = new ComponentName(c, OverlayService.class);
        for (String s : list.split(":")) {
            if (mine.equals(ComponentName.unflattenFromString(s))) return true;
        }
        return false;
    }

    static boolean canWriteSecure(Context c) {
        return c.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS)
                == PackageManager.PERMISSION_GRANTED;
    }

    /** Réactive le service d'accessibilité (nécessite la permission accordée par ADB). */
    static boolean reenable(Context c) {
        if (overlayEnabled(c)) return true;
        if (!canWriteSecure(c)) return false;
        try {
            String me = new ComponentName(c, OverlayService.class).flattenToString();
            String list = Settings.Secure.getString(c.getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            String value = (list == null || list.isEmpty()) ? me : list + ":" + me;
            Settings.Secure.putString(c.getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, value);
            Settings.Secure.putInt(c.getContentResolver(), Settings.Secure.ACCESSIBILITY_ENABLED, 1);
            return true;
        } catch (SecurityException e) {
            return false;
        }
    }

    static boolean canNotify(Context c) {
        return Build.VERSION.SDK_INT < 33 || c.checkSelfPermission(
                Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }

    static void startNotif(Context c) {
        if (!canNotify(c)) return;
        try {
            c.startForegroundService(new Intent(c, NotifService.class));
        } catch (RuntimeException ignored) {
            // Démarrage refusé par le système (arrière-plan) : nouvel essai au prochain événement.
        }
    }

    /** Appelé au démarrage, au déverrouillage et à l'ouverture de l'appli. */
    static void ensure(Context c) {
        android.content.SharedPreferences p = Prefs.get(c);
        boolean overlay = p.getBoolean(Prefs.KEEP_ON, true) && reenable(c);
        // L'icône de notification sert aussi de secours si l'affichage a été coupé.
        if (p.getBoolean(Prefs.NOTIF, false)
                || (p.getBoolean(Prefs.KEEP_ON, true) && !overlay && wasOverlayUsed(c))) {
            startNotif(c);
        }
    }

    private static boolean wasOverlayUsed(Context c) {
        return Prefs.get(c).getBoolean("overlay_seen", false);
    }
}
