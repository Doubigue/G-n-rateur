package com.dlvibe.debit;

import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

/** Tuile des réglages rapides : afficher / masquer le débit d'un geste. */
public class QuickTile extends TileService {
    @Override public void onStartListening() {
        refresh();
    }

    @Override public void onClick() {
        boolean on = Prefs.get(this).getBoolean(Prefs.VISIBLE, true);
        Prefs.get(this).edit().putBoolean(Prefs.VISIBLE, !on).apply();
        refresh();
    }

    private void refresh() {
        Tile t = getQsTile();
        if (t == null) return;
        boolean on = Prefs.get(this).getBoolean(Prefs.VISIBLE, true);
        t.setState(on ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
        if (android.os.Build.VERSION.SDK_INT >= 29) t.setSubtitle(on ? "Affiché" : "Masqué");
        t.updateTile();
    }
}
