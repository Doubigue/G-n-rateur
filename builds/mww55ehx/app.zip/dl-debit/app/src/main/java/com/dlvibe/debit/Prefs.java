package com.dlvibe.debit;

import android.content.Context;
import android.content.SharedPreferences;

final class Prefs {
    static final String X = "x";                 // distance depuis le bord droit (dp)
    static final String Y = "y";                 // décalage vertical (dp), 20 = zéro
    static final String SIZE = "size";           // taille du texte (dp)
    static final String MODE = "mode";           // 0 réception, 1 les deux, 2 total
    static final String COLOR = "color";
    static final String BITS = "bits";
    static final String BACKGROUND = "background";
    static final String HIDE_LANDSCAPE = "hide_landscape";
    static final String HIDE_IDLE = "hide_idle";
    static final String INTERVAL = "interval";   // 0 = 0,5 s, 1 = 1 s, 2 = 2 s
    static final String VISIBLE = "visible";     // tuile rapide
    static final String NOTIF = "notif";
    static final String KEEP_ON = "keep_on";     // réactiver après redémarrage

    static final int Y_ZERO = 20;
    static final long[] INTERVALS = {500, 1000, 2000};

    static long interval(SharedPreferences p) {
        int i = p.getInt(INTERVAL, 1);
        return INTERVALS[Math.max(0, Math.min(INTERVALS.length - 1, i))];
    }

    /** Stockage lisible même avant le premier déverrouillage après un redémarrage. */
    static SharedPreferences get(Context c) {
        Context safe = c.createDeviceProtectedStorageContext();
        if (!safe.getSharedPreferences("reglages", Context.MODE_PRIVATE).getBoolean("migre", false)) {
            safe.moveSharedPreferencesFrom(c, "reglages");
            safe.getSharedPreferences("reglages", Context.MODE_PRIVATE)
                    .edit().putBoolean("migre", true).apply();
        }
        return safe.getSharedPreferences("reglages", Context.MODE_PRIVATE);
    }
}
