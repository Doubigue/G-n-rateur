package com.dlvibe.debit;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Relance l'affichage après extinction / rallumage du téléphone ou mise à jour. */
public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        Keeper.ensure(c);
    }
}
