package com.dlvibe.debit;

import android.app.admin.DeviceAdminReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;

/** Administrateur de l'appareil : l'appli ne peut plus être désinstallée sans le désactiver. */
public class AdminReceiver extends DeviceAdminReceiver {
    static ComponentName name(Context c) {
        return new ComponentName(c, AdminReceiver.class);
    }

    @Override public void onEnabled(Context c, Intent i) {
        Keeper.ensure(c);
    }

    @Override public CharSequence onDisableRequested(Context c, Intent i) {
        return "Le débit ne sera plus protégé et DL Débit pourra être désinstallée.";
    }
}
