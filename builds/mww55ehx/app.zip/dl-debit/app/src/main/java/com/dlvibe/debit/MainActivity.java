package com.dlvibe.debit;

import android.Manifest;
import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int GREEN = 0xFF4CE67A, GOLD = 0xFFE6B84C;

    private SharedPreferences prefs;
    private DevicePolicyManager dpm;
    private LinearLayout root;
    private TextView overlayStatus, adminStatus, bootStatus;
    private Button adminButton, batteryButton;
    private Switch notifSwitch;

    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        prefs = Prefs.get(this);
        dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(32));

        title("DL Débit", 28);
        label("DL VIBE STUDIO · v" + version());

        // 1. Affichage
        title("1. Affichage à côté de LTE", 18);
        overlayStatus = label("");
        button("Activer dans Accessibilité", v ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        label("Ouvrez « DL Débit » (parfois sous « Applications installées ») et activez-le. "
                + "Réglage grisé (Android 13+) : bouton ci-dessous, menu ⋮, "
                + "« Autoriser les paramètres restreints ».");
        button("Ouvrir la fiche de l'appli", v -> openAppDetails());

        // 2. Administrateur
        title("2. Mode administrateur", 18);
        adminStatus = label("");
        label("Protège l'appli : impossible de la désinstaller ou de la forcer à s'arrêter "
                + "tant que ce mode est actif.");
        adminButton = button("", v -> toggleAdmin());

        // 3. Redémarrage
        title("3. Reprise après redémarrage", 18);
        bootStatus = label("");
        toggle("Reprendre automatiquement au rallumage", Prefs.KEEP_ON, true);
        batteryButton = button("Ne pas limiter la batterie de DL Débit", v -> askBattery());
        label("Xiaomi, Tecno, Infinix, itel, Oppo… : sur la fiche de l'appli, autorisez aussi "
                + "le « Démarrage automatique ».");
        button("Garantie totale (ADB) : copier la commande", v -> copyAdb());
        label("Certains téléphones coupent l'accessibilité au redémarrage. Lancez une fois "
                + "cette commande depuis un ordinateur (ADB) : l'appli pourra alors se "
                + "réactiver seule. Sinon, elle bascule sur l'icône de notification.");

        // Réglages
        title("Position et style", 18);
        int screenDp = Math.round(getResources().getDisplayMetrics().widthPixels
                / getResources().getDisplayMetrics().density);
        slider("Horizontal (vers la gauche)", Prefs.X, 0, screenDp - 40, 105);
        slider("Vertical (milieu = normal)", Prefs.Y, 0, 60, Prefs.Y_ZERO);
        slider("Taille du texte", Prefs.SIZE, 8, 18, 11);
        spinner("Valeur affichée", Prefs.MODE, 0,
                new String[]{"Réception ↓", "Réception ↓ et envoi ↑", "Total ↕"});
        spinner("Couleur", Prefs.COLOR, 0, new String[]{"Blanc", "Noir", "Or", "Vert"});
        spinner("Actualisation", Prefs.INTERVAL, 1,
                new String[]{"Toutes les 0,5 s", "Chaque seconde", "Toutes les 2 s"});
        toggle("Afficher le débit", Prefs.VISIBLE, true);
        toggle("Masquer quand rien ne se charge", Prefs.HIDE_IDLE, false);
        toggle("Fond contrasté", Prefs.BACKGROUND, false);
        toggle("Masquer en paysage (vidéos, jeux)", Prefs.HIDE_LANDSCAPE, true);
        toggle("Unité en bits (Mb/s) au lieu d'octets (Mo/s)", Prefs.BITS, false);
        label("Astuce : ajoutez la tuile « Débit » dans les réglages rapides pour "
                + "masquer / afficher d'un geste.");

        title("Icône de notification", 18);
        label("Affiche aussi le débit en icône, à gauche de la barre d'état.");
        notifSwitch = toggle("Icône de notification", Prefs.NOTIF, false);
        notifSwitch.setOnCheckedChangeListener((b, on) -> setNotif(on));

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);
        setContentView(scroll);

        // Le secours par notification a besoin de cette permission.
        if (Build.VERSION.SDK_INT >= 33 && !Keeper.canNotify(this)) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
        Keeper.ensure(this);
    }

    @Override protected void onResume() {
        super.onResume();
        boolean overlay = Keeper.overlayEnabled(this);
        status(overlayStatus, overlay, "Affichage activé", "Affichage désactivé");
        boolean admin = dpm.isAdminActive(AdminReceiver.name(this));
        status(adminStatus, admin, "Administrateur actif", "Administrateur inactif");
        adminButton.setText(admin ? "Désactiver le mode administrateur"
                                  : "Activer le mode administrateur");
        boolean battery = ((PowerManager) getSystemService(POWER_SERVICE))
                .isIgnoringBatteryOptimizations(getPackageName());
        boolean adb = Keeper.canWriteSecure(this);
        status(bootStatus, battery, adb ? "Reprise garantie (ADB accordé)"
                        : "Reprise activée", "Batterie limitée : la reprise peut échouer");
        batteryButton.setVisibility(battery ? View.GONE : View.VISIBLE);
    }

    private void status(TextView t, boolean ok, String yes, String no) {
        t.setText(ok ? "● " + yes : "○ " + no);
        t.setTextColor(ok ? GREEN : GOLD);
    }

    private void toggleAdmin() {
        if (dpm.isAdminActive(AdminReceiver.name(this))) {
            dpm.removeActiveAdmin(AdminReceiver.name(this));
            Toast.makeText(this, "Mode administrateur désactivé", Toast.LENGTH_SHORT).show();
            adminButton.postDelayed(this::onResume, 500);
            return;
        }
        Intent i = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
        i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, AdminReceiver.name(this));
        i.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, getString(R.string.admin_description));
        startActivity(i);
    }

    private void askBattery() {
        try {
            startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:" + getPackageName())));
        } catch (RuntimeException e) {
            startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
        }
    }

    private void openAppDetails() {
        startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + getPackageName())));
    }

    private void copyAdb() {
        String cmd = "adb shell pm grant " + getPackageName()
                + " android.permission.WRITE_SECURE_SETTINGS";
        ((ClipboardManager) getSystemService(CLIPBOARD_SERVICE))
                .setPrimaryClip(ClipData.newPlainText("adb", cmd));
        Toast.makeText(this, "Commande copiée", Toast.LENGTH_SHORT).show();
    }

    private void setNotif(boolean on) {
        prefs.edit().putBoolean(Prefs.NOTIF, on).apply();
        if (!on) {
            stopService(new Intent(this, NotifService.class));
            return;
        }
        if (!Keeper.canNotify(this)) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 2);
            return;
        }
        Keeper.startNotif(this);
    }

    @Override public void onRequestPermissionsResult(int code, String[] p, int[] results) {
        super.onRequestPermissionsResult(code, p, results);
        boolean granted = results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED;
        if (code == 2) {
            if (granted) Keeper.startNotif(this);
            else notifSwitch.setChecked(false);
        }
    }

    private String version() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (PackageManager.NameNotFoundException e) {
            return "?";
        }
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void add(View v) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(10);
        root.addView(v, p);
    }

    private TextView label(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(14);
        add(t);
        return t;
    }

    private void title(String text, int size) {
        TextView t = label(text);
        t.setTextSize(size);
        t.setTextColor(getColor(R.color.or));
        t.setPadding(0, dp(12), 0, 0);
    }

    private Button button(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        add(b);
        return b;
    }

    private void slider(String text, String key, int min, int max, int def) {
        label(text);
        SeekBar s = new SeekBar(this);
        s.setMin(min);
        s.setMax(max);
        s.setProgress(prefs.getInt(key, def));
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int value, boolean fromUser) {
                if (fromUser) prefs.edit().putInt(key, value).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar bar) {}
            @Override public void onStopTrackingTouch(SeekBar bar) {}
        });
        add(s);
    }

    private void spinner(String text, String key, int def, String[] choices) {
        label(text);
        Spinner s = new Spinner(this);
        ArrayAdapter<String> a = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, choices);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(a);
        s.setSelection(prefs.getInt(key, def));
        s.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                prefs.edit().putInt(key, pos).apply();
            }
            @Override public void onNothingSelected(AdapterView<?> p) {}
        });
        add(s);
    }

    private Switch toggle(String text, String key, boolean def) {
        Switch s = new Switch(this);
        s.setText(text);
        s.setChecked(prefs.getBoolean(key, def));
        s.setOnCheckedChangeListener((b, on) -> prefs.edit().putBoolean(key, on).apply());
        add(s);
        return s;
    }
}
