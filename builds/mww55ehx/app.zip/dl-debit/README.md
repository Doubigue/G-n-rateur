# DL Débit 1.1 — DL VIBE STUDIO

Affiche la vitesse de connexion en haut de l'écran, à côté de LTE (Android 8 et plus).

## Compiler
Mettre le contenu de ce dossier (`.github` compris) à la racine d'un dépôt GitHub **privé**,
puis onglet **Actions** > **Compiler APK**. L'APK signé est dans les *Artifacts* (`DL-Debit-apk`).

## Clé de signature
`app/dl-debit.jks` + `keystore.properties` (mots de passe). Sauvegardez-les : toutes les mises à
jour doivent être signées avec la même clé. Dépôt public : ne pas y mettre ces deux fichiers,
mais créer les secrets `DL_KEYSTORE_BASE64` (`base64 -w0 app/dl-debit.jks`),
`DL_STORE_PASSWORD`, `DL_KEY_ALIAS`, `DL_KEY_PASSWORD`.

## Installer et activer
1. Désinstaller l'ancienne version (signature différente), installer l'APK.
2. Ouvrir DL Débit et suivre les étapes 1 à 3 de l'écran.

## Reprise après redémarrage
- Accessibilité : Android relance le service seul au démarrage.
- Batterie non limitée + « Démarrage automatique » (Xiaomi, Tecno, Infinix…) recommandés.
- Si le téléphone coupe l'accessibilité au démarrage : l'appli bascule sur l'icône de
  notification. Pour une reprise garantie, une seule fois depuis un ordinateur :
  `adb shell pm grant com.dlvibe.debit android.permission.WRITE_SECURE_SETTINGS`

## Mode administrateur
Empêche la désinstallation tant qu'il est actif. Pour désinstaller : DL Débit >
« Désactiver le mode administrateur », puis désinstaller normalement.
