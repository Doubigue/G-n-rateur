package com.example.mediaconverter

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel

/**
 * Pipeline : FFmpeg décode en PCM float 44,1 kHz stéréo (fichier temporaire)
 *  -> traitement par chunks de 5,9 s : STFT -> MDX-Net (ONNX) -> iSTFT
 *  -> FFmpeg encode en WAV 16 bits vers le fichier choisi.
 * Le traitement est "streamé" : la mémoire ne dépend pas de la durée de la vidéo.
 */
class VoiceSeparator(private val context: Context, private val store: ModelStore) {

    suspend fun separate(inputSaf: String, outputSaf: String, mode: VoiceOutput, onProgress: (Float) -> Unit): Result<Unit> {
        val rawIn = File(context.cacheDir, "mdx_in.f32")
        val rawOut = File(context.cacheDir, "mdx_out.f32")
        return try {
            // 1) décodage
            val dec = FFmpegKit.executeWithArguments(arrayOf(
                "-y", "-i", inputSaf, "-vn", "-ac", "2", "-ar", "44100", "-f", "f32le", rawIn.path))
            check(ReturnCode.isSuccess(dec.returnCode)) { "Impossible de décoder l'audio (la vidéo a-t-elle une piste son ?)." }
            val total = rawIn.length() / 8
            check(total > 0) { "Aucun son détecté." }

            // 2) inférence chunk par chunk
            runModel(rawIn, rawOut, total, mode, onProgress)

            // 3) encodage WAV
            val encArgs = if (mode == VoiceOutput.VIDEO_NO_VOICE) arrayOf(
                // vidéo d'origine copiée telle quelle + nouvelle piste audio sans la voix
                "-y", "-i", inputSaf, "-f", "f32le", "-ar", "44100", "-ac", "2", "-i", rawOut.path,
                "-map", "0:v:0", "-map", "1:a:0", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k",
                "-shortest", "-f", "mp4", outputSaf,
            ) else arrayOf(
                "-y", "-f", "f32le", "-ar", "44100", "-ac", "2", "-i", rawOut.path,
                "-c:a", "pcm_s16le", "-f", "wav", outputSaf,
            )
            val enc = FFmpegKit.executeWithArguments(encArgs)
            check(ReturnCode.isSuccess(enc.returnCode)) { "Échec de l'écriture du fichier de sortie." }
            onProgress(1f)
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            val msg = if (e is OutOfMemoryError) "Mémoire insuffisante pour le modèle IA. Utilisez « filtre rapide »." else e.message
            Result.failure(Exception(msg, e))
        } finally {
            rawIn.delete(); rawOut.delete()
        }
    }

    private suspend fun runModel(rawIn: File, rawOut: File, total: Long, mode: VoiceOutput, onProgress: (Float) -> Unit) {
        val env = OrtEnvironment.getEnvironment()
        val opts = OrtSession.SessionOptions().apply {
            setIntraOpNumThreads(Runtime.getRuntime().availableProcessors().coerceIn(2, 4))
            setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
        }
        val stft = MdxStft()
        val chunks = ((total + Mdx.GEN - 1) / Mdx.GEN).toInt()

        val left = FloatArray(Mdx.CHUNK); val right = FloatArray(Mdx.CHUNK)
        val outL = FloatArray(Mdx.CHUNK); val outR = FloatArray(Mdx.CHUNK)
        val spec = FloatArray(Mdx.TENSOR_SIZE)
        val result = FloatArray(Mdx.TENSOR_SIZE)
        val direct = ByteBuffer.allocateDirect(Mdx.TENSOR_SIZE * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        val readBuf = ByteBuffer.allocate(Mdx.CHUNK * 8).order(ByteOrder.LITTLE_ENDIAN)
        val writeBuf = ByteBuffer.allocate(Mdx.GEN * 8).order(ByteOrder.LITTLE_ENDIAN)
        val shape = longArrayOf(1, 4, Mdx.DIM_F.toLong(), Mdx.DIM_T.toLong())

        env.createSession(store.file.path, opts).use { session ->
            val inName = session.inputNames.first()
            FileInputStream(rawIn).channel.use { inCh ->
                FileOutputStream(rawOut).channel.use { outCh ->
                    for (i in 0 until chunks) {
                        currentCoroutineContext().ensureActive()
                        val start = i.toLong() * Mdx.GEN - Mdx.TRIM
                        readChunk(inCh, start, total, left, right, readBuf)

                        stft.forward(left, spec, 0)
                        stft.forward(right, spec, 1)
                        // UVR met à zéro les 3 premiers bins avant le modèle
                        for (p in 0 until 4) for (f in 0 until 3) {
                            val o = (p * Mdx.DIM_F + f) * Mdx.DIM_T
                            java.util.Arrays.fill(spec, o, o + Mdx.DIM_T, 0f)
                        }

                        direct.clear(); direct.put(spec); direct.rewind()
                        OnnxTensor.createTensor(env, direct, shape).use { input ->
                            session.run(mapOf(inName to input)).use { res ->
                                val fb = (res.get(0) as OnnxTensor).floatBuffer
                                fb.rewind(); fb.get(result)
                            }
                        }

                        stft.inverse(result, 0, outL)
                        stft.inverse(result, 1, outR)

                        val keep = minOf(Mdx.GEN.toLong(), total - i.toLong() * Mdx.GEN).toInt()
                        writeBuf.clear()
                        val fo = writeBuf.asFloatBuffer()
                        for (j in 0 until keep) {
                            val vl = outL[Mdx.TRIM + j] * Mdx.COMPENSATE
                            val vr = outR[Mdx.TRIM + j] * Mdx.COMPENSATE
                            if (mode == VoiceOutput.VOICE) { fo.put(vl); fo.put(vr) }
                            else { // tout sauf la voix = mix d'origine - voix estimée
                                fo.put(left[Mdx.TRIM + j] - vl)
                                fo.put(right[Mdx.TRIM + j] - vr)
                            }
                        }
                        writeBuf.position(0); writeBuf.limit(keep * 8)
                        while (writeBuf.hasRemaining()) outCh.write(writeBuf)

                        onProgress((i + 1) / chunks.toFloat() * 0.98f)
                    }
                }
            }
        }
        opts.close()
    }

    /** Lit [start, start+CHUNK) en complétant par des zéros hors du fichier. */
    private fun readChunk(ch: FileChannel, start: Long, total: Long, l: FloatArray, r: FloatArray, buf: ByteBuffer) {
        l.fill(0f); r.fill(0f)
        val from = maxOf(start, 0L)
        val to = minOf(start + Mdx.CHUNK, total)
        if (to <= from) return
        val count = (to - from).toInt()
        buf.clear(); buf.limit(count * 8)
        ch.position(from * 8)
        while (buf.hasRemaining()) if (ch.read(buf) < 0) break
        buf.flip()
        val fb = buf.asFloatBuffer()
        val off = (from - start).toInt()
        for (j in 0 until count) { l[off + j] = fb.get(); r[off + j] = fb.get() }
    }
}
