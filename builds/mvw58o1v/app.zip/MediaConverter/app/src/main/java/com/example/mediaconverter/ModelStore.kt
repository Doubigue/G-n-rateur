package com.example.mediaconverter

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/**
 * Gère le fichier modèle MDX-Net "Kim_Vocal_2.onnx" (~66 Mo, stocké dans filesDir).
 * Il n'est pas embarqué dans l'APK : téléchargé à la demande, ou importé à la main.
 */
class ModelStore(private val context: Context) {

    val file: File get() = File(context.filesDir, "models/Kim_Vocal_2.onnx")

    fun isReady() = file.exists() && file.length() > MIN_SIZE

    suspend fun download(onProgress: (Float) -> Unit): Result<Unit> = withContext(Dispatchers.IO) {
        val tmp = File(file.parentFile, "Kim_Vocal_2.onnx.part")
        try {
            file.parentFile!!.mkdirs()
            val conn = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply {
                connectTimeout = 15_000
                readTimeout = 30_000
                instanceFollowRedirects = true
            }
            check(conn.responseCode == 200) { "Téléchargement impossible (HTTP ${conn.responseCode}). Importez le fichier à la main." }
            val total = conn.contentLengthLong.takeIf { it > 0 } ?: EXPECTED_SIZE
            val sha = MessageDigest.getInstance("SHA-256")
            var done = 0L
            conn.inputStream.use { input ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        sha.update(buf, 0, n)
                        done += n
                        onProgress((done / total.toFloat()).coerceIn(0f, 1f))
                    }
                }
            }
            val hex = sha.digest().joinToString("") { "%02x".format(it) }
            check(hex == MODEL_SHA256) { "Fichier corrompu ou différent de celui attendu (SHA-256 invalide)." }
            file.delete()
            check(tmp.renameTo(file)) { "Impossible d'enregistrer le modèle." }
            Result.success(Unit)
        } catch (e: Exception) {
            tmp.delete()
            Result.failure(e)
        }
    }

    /** Import manuel d'un fichier .onnx compatible (Kim_Vocal_2 : entrée 1x4x3072x256). */
    suspend fun importFrom(uri: Uri): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            file.parentFile!!.mkdirs()
            context.contentResolver.openInputStream(uri)!!.use { i -> file.outputStream().use { o -> i.copyTo(o) } }
            if (!isReady()) { file.delete(); error("Fichier trop petit pour être le modèle attendu.") }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    companion object {
        // Miroir public de Kim_Vocal_2.onnx (révision figée). Constantes à vérifier / adapter si le miroir change.
        const val MODEL_URL =
            "https://huggingface.co/seanghay/uvr_models/resolve/6f4fc0cfb0717c9033ffed12471a53008f145b20/Kim_Vocal_2.onnx"
        const val MODEL_SHA256 = "ce74ef3b6a6024ce44211a07be9cf8bc6d87728cc852a68ab34eb8e58cde9c8b"
        private const val EXPECTED_SIZE = 67_000_000L
        private const val MIN_SIZE = 50_000_000L
    }
}
