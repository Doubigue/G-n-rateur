package com.example.mediaconverter

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContract
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp

/** Sélecteur d'emplacement de sortie : (type MIME, nom suggéré) -> Uri */
class CreateAnyDocument : ActivityResultContract<Pair<String, String>, Uri?>() {
    override fun createIntent(context: Context, input: Pair<String, String>) =
        Intent(Intent.ACTION_CREATE_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType(input.first)
            .putExtra(Intent.EXTRA_TITLE, input.second)

    override fun parseResult(resultCode: Int, intent: Intent?): Uri? =
        if (resultCode == Activity.RESULT_OK) intent?.data else null
}

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { Screen(vm) } } }
    }
}

@Composable
private fun Screen(vm: MainViewModel) {
    val s by vm.state.collectAsState()

    val pickVideo = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(vm::pickInput) }
    val pickAudio = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(vm::pickAudio) }
    val pickModel = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(vm::importModel) }
    val saveAs = rememberLauncherForActivityResult(CreateAnyDocument()) { it?.let(vm::start) }

    val canStart = s.input != null && !s.running && (s.op != Operation.ADD_AUDIO || s.audio != null) &&
        (s.op != Operation.EXTRACT_VOICE || s.modelReady)

    Column(
        Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Convertisseur vidéo / audio", style = MaterialTheme.typography.headlineSmall)

        OutlinedButton(onClick = { pickVideo.launch(arrayOf("video/*")) }, enabled = !s.running) {
            Text(if (s.input == null) "Choisir une vidéo" else "Vidéo : ${s.inputName}")
        }

        Text("Opération", style = MaterialTheme.typography.titleMedium)
        Operation.entries.forEach { op ->
            RadioRow(op.label, s.op == op, !s.running) { vm.update { copy(op = op) } }
        }

        when (s.op) {
            Operation.TO_VIDEO -> Section("Format de sortie") {
                VideoFormat.entries.forEach { f ->
                    RadioRow(f.label, s.videoFormat == f, !s.running) { vm.update { copy(videoFormat = f) } }
                }
            }
            Operation.COMPRESS -> Section("Niveau de compression") {
                CompressLevel.entries.forEach { l ->
                    RadioRow(l.label, s.level == l, !s.running) { vm.update { copy(level = l) } }
                }
            }
            Operation.ADD_AUDIO -> Section("Son à ajouter") {
                OutlinedButton(onClick = { pickAudio.launch(arrayOf("audio/*")) }, enabled = !s.running) {
                    Text(if (s.audio == null) "Choisir un fichier audio" else "Audio : ${s.audioName}")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(s.mixOriginal, { v -> vm.update { copy(mixOriginal = v) } }, enabled = !s.running)
                    Spacer(Modifier.width(8.dp))
                    Text("Mixer avec le son d'origine (sinon remplacer)")
                }
            }
            Operation.EXTRACT_VOICE -> Section("Modèle IA (MDX-Net Kim_Vocal_2)") {
                Text(
                    "Sépare réellement la voix de la musique, 100 % sur l'appareil. " +
                        "Lent (plusieurs fois la durée de la vidéo selon le téléphone) et gourmand en RAM (~1 Go). " +
                        "Modèle ≈ 66 Mo, non fourni avec l'app ; les auteurs n'indiquent pas de licence : " +
                        "vérifiez qu'elle convient à votre usage.",
                    style = MaterialTheme.typography.bodySmall,
                )
                Text("Résultat souhaité", style = MaterialTheme.typography.titleSmall)
                VoiceOutput.entries.forEach { o ->
                    RadioRow(o.label, s.voiceOutput == o, !s.running) { vm.update { copy(voiceOutput = o) } }
                }
                Text(
                    "« Sans la voix » = mix d'origine moins la voix estimée : musique, bruitages et ambiance sont conservés, " +
                        "avec parfois de légers résidus de voix. La vidéo est copiée sans réencodage.",
                    style = MaterialTheme.typography.bodySmall,
                )
                if (s.modelReady) Text("✔ Modèle installé") else {
                    Button(onClick = vm::downloadModel, enabled = !s.running) { Text("Télécharger le modèle") }
                    OutlinedButton(onClick = { pickModel.launch(arrayOf("*/*")) }, enabled = !s.running) {
                        Text("Importer un fichier .onnx")
                    }
                }
            }
            Operation.EXTRACT_VOICE_FAST -> Text(
                "Filtre voix + débruitage : rapide mais la musique reste en partie audible. Sortie : WAV.",
                style = MaterialTheme.typography.bodySmall,
            )
            else -> Unit
        }

        Button(
            onClick = { saveAs.launch(vm.outputMime() to vm.suggestedName()) },
            enabled = canStart,
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Convertir") }

        if (s.running) {
            s.phase?.let { Text(it) }
            LinearProgressIndicator(progress = { s.progress }, modifier = Modifier.fillMaxWidth())
            Text("${(s.progress * 100).toInt()} %")
            TextButton(onClick = vm::cancel) { Text("Annuler") }
        }
        s.message?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium)
        content()
    }
}

@Composable
private fun RadioRow(label: String, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().selectable(selected, enabled, Role.RadioButton, onClick),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected, onClick = null, enabled = enabled)
        Spacer(Modifier.width(8.dp))
        Text(label)
    }
}
