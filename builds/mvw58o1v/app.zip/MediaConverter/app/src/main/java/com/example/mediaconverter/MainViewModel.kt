package com.example.mediaconverter

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.arthenica.ffmpegkit.FFmpegKitConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class UiState(
    val input: Uri? = null,
    val inputName: String = "",
    val audio: Uri? = null,
    val audioName: String = "",
    val op: Operation = Operation.TO_MP3,
    val videoFormat: VideoFormat = VideoFormat.MKV,
    val level: CompressLevel = CompressLevel.MEDIUM,
    val mixOriginal: Boolean = false,
    val voiceOutput: VoiceOutput = VoiceOutput.VOICE,
    val modelReady: Boolean = false,
    val running: Boolean = false,
    val phase: String? = null,
    val progress: Float = 0f,
    val message: String? = null,
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val converter = MediaConverter()
    private val store = ModelStore(app)
    private val separator = VoiceSeparator(app, store)
    private val _state = MutableStateFlow(UiState(modelReady = store.isReady()))
    val state: StateFlow<UiState> = _state.asStateFlow()
    private var job: Job? = null

    fun update(block: UiState.() -> UiState) = _state.update { it.block() }

    fun pickInput(uri: Uri) = update { copy(input = uri, inputName = displayName(uri), message = null) }
    fun pickAudio(uri: Uri) = update { copy(audio = uri, audioName = displayName(uri)) }

    fun suggestedName(): String {
        val s = _state.value
        val base = s.inputName.substringBeforeLast('.').ifBlank { "sortie" }
        val spec = outputSpec(s.op, s.videoFormat, s.voiceOutput)
        return "$base${spec.suffix}.${spec.ext}"
    }

    fun outputMime(): String = _state.value.let { outputSpec(it.op, it.videoFormat, it.voiceOutput).mime }

    fun cancel() { job?.cancel() }

    fun downloadModel() = launchTask("Téléchargement du modèle IA…") {
        store.download(::setProgress).fold(
            onSuccess = { "Modèle installé ✔" },
            onFailure = { e -> "Erreur : ${e.message}" },
        )
    }

    fun importModel(uri: Uri) = launchTask("Import du modèle…") {
        store.importFrom(uri).fold(
            onSuccess = { "Modèle importé ✔" },
            onFailure = { e -> "Erreur : ${e.message}" },
        )
    }

    fun start(output: Uri) {
        val s = _state.value
        val inUri = s.input ?: return
        val ctx = getApplication<Application>()
        val phase = if (s.op == Operation.EXTRACT_VOICE) "Séparation de la voix (IA)…" else "Conversion…"
        launchTask(phase) {
            val inArg = FFmpegKitConfig.getSafParameterForRead(ctx, inUri)
            val outArg = FFmpegKitConfig.getSafParameterForWrite(ctx, output)
            val result = if (s.op == Operation.EXTRACT_VOICE) {
                separator.separate(inArg, outArg, s.voiceOutput, ::setProgress)
            } else {
                converter.convert(
                    op = s.op, input = inArg, output = outArg,
                    audio = s.audio?.let { FFmpegKitConfig.getSafParameterForRead(ctx, it) },
                    videoFormat = s.videoFormat, level = s.level, mixOriginal = s.mixOriginal,
                    onProgress = ::setProgress,
                )
            }
            result.fold(
                onSuccess = { "Terminé ✔ — fichier enregistré." },
                onFailure = { e -> "Erreur : ${e.message}" },
            )
        }
    }

    private fun setProgress(p: Float) = _state.update { it.copy(progress = p) }

    private fun launchTask(phase: String, block: suspend () -> String) {
        job = viewModelScope.launch(Dispatchers.IO) {
            _state.update { it.copy(running = true, progress = 0f, phase = phase, message = null) }
            try {
                val msg = block()
                _state.update { it.copy(message = msg) }
            } catch (e: CancellationException) {
                _state.update { it.copy(message = "Annulé.") }
                throw e
            } finally {
                _state.update { it.copy(running = false, phase = null, modelReady = store.isReady()) }
            }
        }
    }

    private fun displayName(uri: Uri): String =
        getApplication<Application>().contentResolver
            .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null } ?: "fichier"
}
