package com.example.mediaconverter

import org.jtransforms.fft.FloatFFT_1D
import kotlin.math.PI
import kotlin.math.cos

/** Paramètres de Kim_Vocal_2 (UVR MDX-Net) : n_fft 7680, hop 1024, dim_f 3072, dim_t 256. */
object Mdx {
    const val N_FFT = 7680
    const val HOP = 1024
    const val DIM_F = 3072
    const val DIM_T = 256
    const val CHUNK = HOP * (DIM_T - 1)      // 261 120 échantillons (~5,9 s)
    const val TRIM = N_FFT / 2               // 3 840
    const val GEN = CHUNK - 2 * TRIM         // 253 440 échantillons réellement produits par chunk
    const val COMPENSATE = 1.009f
    const val TENSOR_SIZE = 4 * DIM_F * DIM_T // [1, 4, 3072, 256] = [reL, imL, reR, imR]
}

/** Équivalent de torch.stft / torch.istft (fenêtre de Hann périodique, center=True, reflect). */
class MdxStft {
    private val fft = FloatFFT_1D(Mdx.N_FFT.toLong())
    private val window = FloatArray(Mdx.N_FFT) { (0.5 - 0.5 * cos(2.0 * PI * it / Mdx.N_FFT)).toFloat() }
    private val frame = FloatArray(Mdx.N_FFT)
    private val padded = FloatArray(Mdx.CHUNK + Mdx.N_FFT)

    // Somme des fenêtres² (normalisation de l'overlap-add), calculée une fois
    private val envelope = FloatArray(Mdx.CHUNK + Mdx.N_FFT).also { env ->
        for (t in 0 until Mdx.DIM_T) for (k in 0 until Mdx.N_FFT) env[t * Mdx.HOP + k] += window[k] * window[k]
        for (i in env.indices) if (env[i] < 1e-11f) env[i] = 1f
    }

    private fun reflect(x: FloatArray, i: Int): Float {
        var j = i
        if (j < 0) j = -j
        if (j >= x.size) j = 2 * (x.size - 1) - j
        return x[j]
    }

    /** x : CHUNK échantillons -> écrit re/im dans dst aux plans (2*ch, 2*ch+1). */
    fun forward(x: FloatArray, dst: FloatArray, ch: Int) {
        val planeRe = (2 * ch) * Mdx.DIM_F * Mdx.DIM_T
        val planeIm = (2 * ch + 1) * Mdx.DIM_F * Mdx.DIM_T
        for (t in 0 until Mdx.DIM_T) {
            val start = t * Mdx.HOP - Mdx.TRIM
            for (k in 0 until Mdx.N_FFT) frame[k] = reflect(x, start + k) * window[k]
            fft.realForward(frame) // format packé : [Re0, Re(N/2), Re1, Im1, Re2, Im2, ...]
            for (f in 0 until Mdx.DIM_F) {
                val idx = f * Mdx.DIM_T + t
                if (f == 0) { dst[planeRe + idx] = frame[0]; dst[planeIm + idx] = 0f }
                else { dst[planeRe + idx] = frame[2 * f]; dst[planeIm + idx] = frame[2 * f + 1] }
            }
        }
    }

    /** src : sortie du modèle (même disposition) -> out : CHUNK échantillons. */
    fun inverse(src: FloatArray, ch: Int, out: FloatArray) {
        val planeRe = (2 * ch) * Mdx.DIM_F * Mdx.DIM_T
        val planeIm = (2 * ch + 1) * Mdx.DIM_F * Mdx.DIM_T
        padded.fill(0f)
        for (t in 0 until Mdx.DIM_T) {
            frame.fill(0f) // bins 3072..3840 = 0 (bande coupée par le modèle)
            for (f in 0 until Mdx.DIM_F) {
                val idx = f * Mdx.DIM_T + t
                if (f == 0) frame[0] = src[planeRe + idx]
                else { frame[2 * f] = src[planeRe + idx]; frame[2 * f + 1] = src[planeIm + idx] }
            }
            fft.realInverse(frame, true)
            val base = t * Mdx.HOP
            for (k in 0 until Mdx.N_FFT) padded[base + k] += frame[k] * window[k]
        }
        for (i in 0 until Mdx.CHUNK) out[i] = padded[Mdx.TRIM + i] / envelope[Mdx.TRIM + i]
    }
}
