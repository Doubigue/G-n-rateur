plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.example.mediaconverter"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.mediaconverter"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
        // Le fork FFmpegKit maintenu ne publie que arm64-v8a
        ndk { abiFilters += listOf("arm64-v8a") }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    packaging { jniLibs.useLegacyPackaging = true }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.10.01")
    implementation(composeBom)
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    // FFmpegKit (original archivé en 2025) -> fork maintenu, même package com.arthenica.ffmpegkit
    // Tier gratuit : VP8/VP9/AV1, Opus/Vorbis. Pour MP3 (libmp3lame) et H.264 (libx264),
    // utilisez un tier payant : placez l'.aar dans app/libs/ et remplacez la ligne ci-dessous par
    // implementation(files("libs/ffmpeg-kit-xxx.aar")) + implementation("com.arthenica:smart-exception-java:0.2.1")
    implementation("dev.ffmpegkit-maintained:ffmpeg:7.1.6")

    // Séparation voix/musique par IA : ONNX Runtime (inférence) + JTransforms (FFT n=7680, non puissance de 2)
    implementation("com.microsoft.onnxruntime:onnxruntime-android:1.20.0")
    implementation("com.github.wendykierp:JTransforms:3.1")
}
