# Convertisseur MP4 (Kotlin + Jetpack Compose + FFmpegKit)

Ouvrir le dossier dans Android Studio (Ladybug ou plus récent) -> Sync -> Run.
Android Studio génère le Gradle wrapper automatiquement.

Fonctions : MP4->MP3, MP4->WAV, MP4->MKV/MOV/WebM/AVI, compression, ajout/mixage de son, extraction de voix.
Aucune permission de stockage (Storage Access Framework).

## Extraction de voix par IA
Modèle : MDX-Net Kim_Vocal_2 (ONNX, ~66 Mo), exécuté avec ONNX Runtime. STFT/iSTFT en Kotlin (JTransforms).
Le modèle n'est pas dans l'APK : bouton "Télécharger" dans l'app (URL + SHA-256 dans ModelStore.kt) ou import manuel d'un .onnx.
Sorties de l'extraction IA : voix seule (WAV), tout sauf la voix (WAV), ou vidéo d'origine avec une piste audio sans la voix (MP4).
