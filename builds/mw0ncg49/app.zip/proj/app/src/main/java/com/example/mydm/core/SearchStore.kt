package com.example.mydm.core

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/**
 * Mémoire de la recherche de l'onglet « Vidéos » :
 *  - historique des recherches (les plus récentes d'abord, sans doublon) ;
 *  - dernier résultat (vidéos + listes de lecture), réaffiché même sans connexion
 *    tant que l'utilisateur n'a pas appuyé sur « Vider le résultat ».
 */
object SearchStore {
    private const val MAX_HISTORY = 40
    @Volatile private var sp: SharedPreferences? = null

    data class Saved(val query: String, val lastQuery: String?, val wanted: Int,
                     val videos: List<VideoEntry>, val lists: List<VideoEntry>)

    private fun prefs(ctx: Context): SharedPreferences =
        sp ?: ctx.applicationContext.getSharedPreferences("yt_search", Context.MODE_PRIVATE).also { sp = it }

    // ───── Historique
    fun history(ctx: Context): List<String> = runCatching {
        val a = JSONArray(prefs(ctx).getString("history", "[]"))
        List(a.length()) { a.getString(it) }
    }.getOrDefault(emptyList())

    fun addHistory(ctx: Context, q: String): List<String> {
        val t = q.trim()
        if (t.isEmpty()) return history(ctx)
        val l = (listOf(t) + history(ctx).filter { !it.equals(t, ignoreCase = true) }).take(MAX_HISTORY)
        saveHistory(ctx, l); return l
    }

    fun removeHistory(ctx: Context, q: String): List<String> {
        val l = history(ctx).filter { it != q }
        saveHistory(ctx, l); return l
    }

    fun clearHistory(ctx: Context) = saveHistory(ctx, emptyList())

    private fun saveHistory(ctx: Context, l: List<String>) {
        prefs(ctx).edit().putString("history", JSONArray(l).toString()).apply()
    }

    // ───── Dernier résultat
    fun saveResult(ctx: Context, query: String, lastQuery: String?, wanted: Int,
                   videos: List<VideoEntry>, lists: List<VideoEntry>) {
        val o = JSONObject()
            .put("query", query)
            .put("lastQuery", lastQuery ?: JSONObject.NULL)
            .put("wanted", wanted)
            .put("videos", JSONArray(videos.map { it.toJson() }))
            .put("lists", JSONArray(lists.map { it.toJson() }))
        prefs(ctx).edit().putString("result", o.toString()).apply()
    }

    fun loadResult(ctx: Context): Saved? = runCatching {
        val s = prefs(ctx).getString("result", null) ?: return null
        val o = JSONObject(s)
        fun arr(k: String) = o.optJSONArray(k)?.let { a -> List(a.length()) { a.getJSONObject(it).toEntry() } } ?: emptyList()
        Saved(
            query = o.optString("query", ""),
            lastQuery = if (o.isNull("lastQuery")) null else o.optString("lastQuery"),
            wanted = o.optInt("wanted", 50),
            videos = arr("videos"), lists = arr("lists")
        ).takeIf { it.videos.isNotEmpty() || it.lists.isNotEmpty() }
    }.getOrNull()

    fun clearResult(ctx: Context) { prefs(ctx).edit().remove("result").apply() }

    private fun VideoEntry.toJson() = JSONObject()
        .put("id", id).put("title", title).put("url", url).put("dur", durationSec)
        .put("ch", channel ?: JSONObject.NULL).put("th", thumb ?: JSONObject.NULL)
        .put("list", isList).put("n", count ?: JSONObject.NULL)

    private fun JSONObject.toEntry() = VideoEntry(
        id = optString("id"), title = optString("title"), url = optString("url"),
        durationSec = optLong("dur", 0L),
        channel = if (isNull("ch")) null else optString("ch"),
        thumb = if (isNull("th")) null else optString("th"),
        isList = optBoolean("list", false),
        count = if (isNull("n")) null else optInt("n")
    )
}
