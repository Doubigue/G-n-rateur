package com.example.mydm.ui

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.mydm.core.*
import kotlinx.coroutines.launch

/**
 * Capture « comme 1DM » : quand on lance la lecture dans la page, tout ce que le lecteur charge
 * (flux HLS et leurs qualités, fichiers vidéo, sous-titres) est listé dans « Fichier(s) détectés ! »,
 * puis un clic ouvre « Télécharger le(s) fichier(s) ! » (lien, nom = titre de la page, dossier, stockage).
 */

/** Une ligne de la liste : un média, et — pour un flux HLS à plusieurs qualités — la qualité visée. */
data class CaptureRow(val key: String, val media: DetectedMedia, val variant: HlsVariant?)

/** Taille (estimée pour le HLS : débit × durée), nombre de pièces et durée d'une ligne. */
data class RowInfo(val size: Long?, val approx: Boolean, val pieces: Int?, val durationSec: Long?)

private val CaptureOrange = Color(0xFFE8833A)

private suspend fun loadInfo(r: CaptureRow): RowInfo {
    val m = r.media
    if (m.type == MediaType.HLS) {
        val d = MediaResolver.hlsDetail(m, r.variant?.url ?: m.url)
        val dur = d.durationSec ?: MediaResolver.cachedMeta(m.url)?.durationSec ?: MediaResolver.probeMeta(m).durationSec
        val bw = r.variant?.bandwidth
        return RowInfo(if (bw != null && dur != null) bw * dur / 8 else null, true, d.pieces, dur)
    }
    val size = m.sizeBytes ?: MediaResolver.probeSize(m)
    val dur = if (m.type == MediaType.VIDEO || m.type == MediaType.AUDIO)
        MediaResolver.cachedMeta(m.url)?.durationSec ?: MediaResolver.probeMeta(m).durationSec else null
    return RowInfo(size, false, null, dur)
}

/** 4648 → « 1h17m28s » */
private fun hms(sec: Long): String {
    val h = sec / 3600; val m = (sec % 3600) / 60; val s = sec % 60
    return when { h > 0 -> "${h}h${m}m${s}s"; m > 0 -> "${m}m${s}s"; else -> "${s}s" }
}

private fun sizeText(i: RowInfo?): String =
    i?.size?.let { (if (i.approx) "~" else "") + formatSize(it) } ?: if (i == null) "…" else "—"

// ───────────────────────────── Fichier(s) détectés !
@Composable
fun DetectedFilesDialog(items: SnapshotStateList<DetectedMedia>, pageTitle: String, onClose: () -> Unit) {
    val metas = remember { mutableStateMapOf<String, MediaMeta>() }
    val selected = remember { mutableStateListOf<String>() }
    var sort by remember { mutableIntStateOf(0) }
    var start by remember { mutableStateOf<List<CaptureRow>?>(null) }

    // Qualités des flux HLS (liste maître) : une ligne par qualité
    val urlsKey = items.map { it.url }
    LaunchedEffect(urlsKey) {
        items.toList().filter { it.type == MediaType.HLS && it.url !in metas }.forEach { m ->
            launch { metas[m.url] = MediaResolver.cachedMeta(m.url) ?: MediaResolver.probeMeta(m) }
        }
    }

    val base = items.toList().flatMap { m ->
        val vs = metas[m.url]?.variants.orEmpty()
        if (m.type == MediaType.HLS && vs.isNotEmpty()) vs.map { CaptureRow(m.url + "#" + it.url, m, it) }
        else listOf(CaptureRow(m.url, m, null))
    }
    // Clés uniques : la même URL peut être détectée plusieurs fois (plusieurs iframes / requêtes) → sinon crash LazyColumn
    val uniqueBase = base.distinctBy { it.key }
    val rows = when (sort) {
        1 -> uniqueBase.sortedWith(compareBy<CaptureRow> { it.media.type.ordinal }.thenByDescending { it.variant?.height ?: 0 })
        2 -> uniqueBase.sortedBy { it.media.displayName().lowercase() }
        else -> uniqueBase
    }
    val allChecked = rows.isNotEmpty() && rows.all { it.key in selected }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxWidth(0.95f).heightIn(max = 680.dp), shape = RoundedCornerShape(14.dp), color = Bg) {
            Column(Modifier.padding(16.dp)) {
                Text("Fichier(s) détectés !", color = Txt, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(allChecked, { on ->
                        selected.clear(); if (on) selected.addAll(rows.map { it.key })
                    })
                    Text("Sélectionnez les fichiers à télécharger", color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
                }
                Text("Touchez un fichier pour choisir son nom et le dossier. Prévisualisez le lien avant de télécharger " +
                    "(pas d'image ni de son = mauvais lien).", color = CaptureOrange, fontSize = 11.sp, modifier = Modifier.padding(vertical = 6.dp))
                HorizontalDivider()
                if (rows.isEmpty()) Text("Aucun fichier détecté. Lancez la vidéo dans la page.", color = Muted, fontSize = 13.sp,
                    modifier = Modifier.padding(vertical = 24.dp))
                LazyColumn(Modifier.weight(1f, fill = false)) {
                    items(rows, key = { it.key }) { r ->
                        CaptureRowView(r, r.key in selected,
                            onCheck = { on -> if (on) { if (r.key !in selected) selected.add(r.key) } else selected.remove(r.key) },
                            onOpen = { start = listOf(r) },
                            onRemove = { items.remove(r.media); selected.remove(r.key) })
                    }
                }
                HorizontalDivider()
                Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextButton({ items.clear(); selected.clear(); onClose() }, contentPadding = PaddingValues(horizontal = 8.dp)) {
                        Text("TOUT EFFACER", fontSize = 12.sp)
                    }
                    TextButton({ sort = (sort + 1) % 3 }, contentPadding = PaddingValues(horizontal = 8.dp)) {
                        Text(when (sort) { 1 -> "TRI : TYPE"; 2 -> "TRI : NOM"; else -> "TRIER" }, fontSize = 12.sp)
                    }
                    Spacer(Modifier.weight(1f))
                    if (selected.isNotEmpty()) Button({ start = rows.filter { it.key in selected } }, contentPadding = PaddingValues(horizontal = 12.dp)) {
                        Text("Télécharger (${selected.size})", fontSize = 12.sp)
                    }
                    TextButton(onClose, contentPadding = PaddingValues(horizontal = 8.dp)) { Text("FERMER", fontSize = 12.sp) }
                }
            }
        }
    }

    start?.let { rs ->
        StartDownloadDialog(rs, pageTitle, onDismiss = { start = null }, onStarted = { start = null; selected.clear() })
    }
}

@Composable
private fun CaptureRowView(row: CaptureRow, checked: Boolean, onCheck: (Boolean) -> Unit, onOpen: () -> Unit, onRemove: () -> Unit) {
    val clip = LocalClipboardManager.current
    val ctx = LocalContext.current
    var info by remember(row.key) { mutableStateOf<RowInfo?>(null) }
    var menu by remember { mutableStateOf(false) }
    LaunchedEffect(row.key) { info = runCatching { loadInfo(row) }.getOrNull() ?: RowInfo(null, false, null, null) }
    val m = row.media
    val link = row.variant?.url ?: m.url

    Row(Modifier.fillMaxWidth().clickable(onClick = onOpen).padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked, onCheck)
        Column(Modifier.width(72.dp)) {
            Text(if (m.type == MediaType.SUBTITLE) "💬" else "🎞️", fontSize = 22.sp)
            Text(sizeText(info), color = Muted, fontSize = 11.sp, maxLines = 1)
            info?.pieces?.let { Text("$it pièces", color = Muted, fontSize = 11.sp, maxLines = 1) }
        }
        Column(Modifier.weight(1f)) {
            Text(link, color = Muted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(m.displayName(), color = Txt, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            row.variant?.resolution?.let { Text("Résolution : $it", color = Muted, fontSize = 11.sp) }
            info?.durationSec?.let { Text("Durée : ${hms(it)}", color = Muted, fontSize = 11.sp) }
        }
        Box {
            IconButton({ menu = true }) { Text("⋮", color = Muted, fontSize = 18.sp) }
            DropdownMenu(menu, { menu = false }) {
                DropdownMenuItem({ Text("Copier le lien") }, {
                    menu = false; clip.setText(AnnotatedString(link)); Toast.makeText(ctx, "Lien copié", Toast.LENGTH_SHORT).show()
                })
                DropdownMenuItem({ Text("Retirer de la liste") }, { menu = false; onRemove() })
            }
        }
    }
}

// ───────────────────────────── Télécharger le(s) fichier(s) !
@Composable
fun StartDownloadDialog(rows: List<CaptureRow>, pageTitle: String, onDismiss: () -> Unit, onStarted: () -> Unit) {
    val ctx = LocalContext.current
    val app = appInstance()
    val scope = rememberCoroutineScope()
    val clip = LocalClipboardManager.current
    val first = rows.first()
    val single = rows.size == 1
    val title = TitleCleaner.fileTitle(first.media.pageTitle?.takeIf { it.isNotBlank() } ?: pageTitle, first.media.pageUrl).let(::cleanName)
    var useTitle by remember { mutableStateOf(true) }
    var name by remember { mutableStateOf(title.ifBlank { first.media.displayName().substringBeforeLast('.') }) }
    var info by remember { mutableStateOf<RowInfo?>(null) }
    LaunchedEffect(first.key) { if (single) info = runCatching { loadInfo(first) }.getOrNull() }
    val (free, total) = remember { Storage.space() }
    val ext = fileNameFor(first.media).substringAfterLast('.', "mp4")
    val folder = "/storage/emulated/0/" + Storage.rel(categoryFor(fileNameFor(first.media)))
    val link = first.variant?.url ?: first.media.url

    fun go() {
        scope.launch {
            rows.forEach { r ->
                val n = if (!useTitle) null else (if (single) cleanName(name) else title).ifBlank { null }
                DownloadActions.queue(ctx, app, r.media, null, n, r.variant)
            }
            Toast.makeText(ctx, if (single) "Téléchargement ajouté" else "${rows.size} téléchargements ajoutés", Toast.LENGTH_SHORT).show()
            onStarted()
        }
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxWidth(0.95f), shape = RoundedCornerShape(14.dp), color = Bg) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Télécharger le(s) fichier(s) !", color = Txt, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                if (single) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(link, color = Muted, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        TextButton({ clip.setText(AnnotatedString(link)); Toast.makeText(ctx, "Lien copié", Toast.LENGTH_SHORT).show() },
                            contentPadding = PaddingValues(horizontal = 8.dp)) { Text("COPIER", fontSize = 12.sp) }
                    }
                    Text("Enregistrer sous", color = Muted, fontSize = 12.sp)
                    Row(verticalAlignment = Alignment.Bottom) {
                        OutlinedTextField(name, { name = it }, Modifier.weight(1f), enabled = useTitle, maxLines = 3)
                        Text(ext, color = CaptureOrange, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 10.dp, bottom = 16.dp))
                    }
                    Text(buildString {
                        append(sizeText(info))
                        val extra = listOfNotNull(info?.pieces?.let { "$it pièces" }, info?.durationSec?.let { "durée ${hms(it)}" })
                        if (extra.isNotEmpty()) append(" (").append(extra.joinToString(", ")).append(")")
                    }, color = Muted, fontSize = 12.sp)
                } else {
                    Text("${rows.size} fichiers sélectionnés", color = Txt)
                }
                Text("Stockage : ${formatSize(free)} libre / ${formatSize(total)}", color = Muted, fontSize = 12.sp)
                Text(folder, color = Txt, fontSize = 12.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(useTitle, { useTitle = it })
                    Text("Utiliser le titre de la page web comme nom de fichier", color = Txt, fontSize = 13.sp)
                }
                Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.End) {
                    TextButton(onDismiss) { Text("ANNULER") }
                    TextButton({ go() }) { Text("COMMENCER") }
                }
            }
        }
    }
}
