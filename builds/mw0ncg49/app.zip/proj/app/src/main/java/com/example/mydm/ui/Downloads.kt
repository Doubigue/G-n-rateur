package com.example.mydm.ui

import android.content.Intent
import android.net.Uri
import android.util.Size
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.mydm.browser.BrowserManager
import com.example.mydm.core.*
import com.example.mydm.downloader.DownloadService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date

/** Page « Téléchargements » : À télécharger • En cours / terminés • Dossiers (avec lecteur intégré). */
@Composable
fun DownloadsScreen(manager: BrowserManager) {
    val app = appInstance()
    val tasks by app.db.downloadDao().observeTasks().collectAsStateWithLifecycle(emptyList())
    val active = tasks.count { it.status != Status.COMPLETED }          // en cours, en attente, en pause, programmés, échoués
    val finished = tasks.count { it.status == Status.COMPLETED }
    val toGet = manager.allFound().size
    var page by rememberSaveable { mutableIntStateOf(0) }
    val titles = listOf("À télécharger" to toGet, "En cours" to active, "Terminés" to finished, "Dossiers" to 0)

    Column(Modifier.fillMaxSize()) {
        ScrollableTabRow(page, containerColor = Bg, contentColor = Accent, edgePadding = 0.dp) {
            titles.forEachIndexed { i, (t, n) ->
                Tab(page == i, { page = i }, text = {
                    BadgedBox(badge = { if (n > 0) Badge { Text("$n") } }) { Text(t, fontSize = 13.sp, maxLines = 1) }
                })
            }
        }
        when (page) {
            0 -> ToDownloadPage(manager) { page = 1 }
            1 -> TasksPage(tasks, completed = false)
            2 -> TasksPage(tasks, completed = true)
            else -> LibraryPage()
        }
    }
}

// ───────────── 1) Liste des médias à télécharger
@Composable
private fun ToDownloadPage(manager: BrowserManager, goTasks: () -> Unit) {
    val ctx = LocalContext.current; val app = appInstance(); val scope = rememberCoroutineScope()
    var filter by remember { mutableStateOf("Tous") }
    var sheet by remember { mutableStateOf(false) }
    var startAt by remember { mutableStateOf<Long?>(null) }          // null = tout de suite
    var showSchedule by remember { mutableStateOf(false) }
    val sizes = remember { mutableStateMapOf<String, Long?>() }
    val all = manager.allFound()
    val shown = all.distinctBy { it.url }.filter {
        when (filter) {
            "Vidéos" -> it.type == MediaType.VIDEO || it.type == MediaType.HLS
            "Audio" -> it.type == MediaType.AUDIO
            "Fichiers" -> it.type != MediaType.VIDEO && it.type != MediaType.HLS && it.type != MediaType.AUDIO
            else -> true
        }
    }
    fun get(m: DetectedMedia) = scope.launch {
        DownloadActions.queue(ctx, app, m, startAt = startAt); manager.removeFound(m)
        startAt?.let { Toast.makeText(ctx, "Programmé : ${formatWhen(it)}", Toast.LENGTH_SHORT).show() }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            listOf("Tous", "Vidéos", "Audio", "Fichiers").forEach { f -> FilterChip(filter == f, { filter = f }, label = { Text(f, fontSize = 12.sp) }) }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ sheet = true }) { Text("🔎 Analyser un lien / une page") }
            if (shown.isNotEmpty()) OutlinedButton({ manager.clearDetected() }) { Text("Vider") }
        }
        if (shown.isEmpty()) {
            Centered("Aucun média détecté.\nCollez un lien avec « Analyser » (inutile de lire la vidéo), ou ouvrez une page dans le navigateur.")
        } else {
            ScheduleBar(startAt, { showSchedule = true }, { startAt = null }, Modifier.padding(horizontal = 12.dp, vertical = 6.dp))
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)) {
                Button({ scope.launch { shown.forEach { DownloadActions.queue(ctx, app, it, startAt = startAt); manager.removeFound(it) }; goTasks() } }) { Text("Tout télécharger (${shown.size})") }
            }
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(shown, key = { it.url }) { m ->
                    LaunchedEffect(m.url) { if (m.sizeBytes == null && m.url !in sizes) sizes[m.url] = MediaResolver.sizeOf(m) }
                    val size = m.sizeBytes ?: sizes[m.url]
                    Row(Modifier.fillMaxWidth().glass().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(when (m.type) { MediaType.VIDEO, MediaType.HLS -> "🎞️"; MediaType.AUDIO -> "🎵"; MediaType.APK -> "🤖"; MediaType.PDF -> "📄"; else -> "📦" }, fontSize = 24.sp)
                        Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                            Text(m.displayName(), color = Txt, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                            Text("${m.type.name} • " + m.sizeText(size, m.url in sizes) +
                                " • " + (Uri.parse(m.url).host ?: ""), color = Muted, fontSize = 11.sp, maxLines = 1)
                        }
                        Button({ get(m) }, contentPadding = PaddingValues(horizontal = 12.dp)) { Text("⬇") }
                    }
                }
            }
        }
    }
    if (sheet) DownloadSheet(manager.current.playing, "", { sheet = false })
    if (showSchedule) ScheduleDialog(onDismiss = { showSchedule = false }) { startAt = it; showSchedule = false }
}

// ───────────── 2) Téléchargements en cours / terminés
private fun statusLabel(s: Status) = when (s) {
    Status.QUEUED -> "En attente"; Status.RUNNING -> "Téléchargement"; Status.PAUSED -> "En pause"
    Status.MERGING -> "Assemblage"; Status.COMPLETED -> "Terminé"; Status.FAILED -> "Échec"
    Status.SCHEDULED -> "Programmé"
}

@Composable
private fun TasksPage(allTasks: List<DownloadTask>, completed: Boolean) {
    // Onglet « En cours » : tout ce qui n'est pas terminé • onglet « Terminés » : les téléchargements finis
    val tasks = allTasks.filter { (it.status == Status.COMPLETED) == completed }
    val ctx = LocalContext.current; val app = appInstance(); val scope = rememberCoroutineScope()
    val progress by app.downloadEngine.progress.collectAsStateWithLifecycle()
    if (tasks.isEmpty()) {
        Centered(if (completed) "Aucun téléchargement terminé" else "Aucun téléchargement en cours"); return
    }

    // Sélection de plusieurs fichiers (pour les programmer ou les démarrer d'un coup)
    var selecting by remember { mutableStateOf(false) }
    val picked = remember { mutableStateListOf<String>() }
    var scheduleFor by remember { mutableStateOf<List<String>?>(null) }
    scheduleFor?.let { ids ->
        ScheduleDialog(
            title = if (ids.size > 1) "Programmer ${ids.size} téléchargements" else "Programmer le téléchargement",
            onDismiss = { scheduleFor = null }
        ) { at ->
            scope.launch { ids.forEach { app.downloadEngine.schedule(it, at) } }
            Toast.makeText(ctx, "Programmé : ${formatWhen(at)}", Toast.LENGTH_SHORT).show()
            scheduleFor = null; selecting = false; picked.clear()
        }
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row {
                if (!completed) {
                    TextButton({ app.downloadEngine.pauseAll() }) { Text("Tout mettre en pause") }
                    if (tasks.any { it.status == Status.FAILED || it.status == Status.PAUSED })
                        TextButton({ tasks.filter { it.status == Status.FAILED || it.status == Status.PAUSED }.forEach { DownloadService.start(ctx, it.id) } }) { Text("Tout reprendre") }
                } else TextButton({ scope.launch { app.db.downloadDao().clearCompleted() } }) { Text("Effacer les terminés") }
            }
        }
        if (!completed) item {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
                TextButton({ selecting = !selecting; picked.clear() }) { Text(if (selecting) "✖ Fermer la sélection" else "☑ Sélectionner") }
                if (selecting) {
                    TextButton({ picked.clear(); picked.addAll(tasks.filter { it.status != Status.COMPLETED }.map { it.id }) }) { Text("Tout") }
                    TextButton({ scheduleFor = picked.toList() }, enabled = picked.isNotEmpty()) { Text("⏰ Programmer (${picked.size})") }
                    TextButton({
                        val ids = tasks.filter { it.id in picked && (it.status == Status.PAUSED || it.status == Status.FAILED || it.status == Status.SCHEDULED) }.map { it.id }
                        if (ids.isNotEmpty()) DownloadService.startMany(ctx, ids)
                        selecting = false; picked.clear()
                    }, enabled = picked.isNotEmpty()) { Text("▶ Démarrer") }
                }
            }
        }
        items(tasks, key = { it.id }) { t ->
            val p = progress[t.id]
            val total = p?.total ?: t.totalBytes
            val frac = if (t.status == Status.COMPLETED) 1f else if (p != null && total > 0) (p.downloaded.toFloat() / total).coerceIn(0f, 1f) else 0f
            val sizeTxt = when {
                p != null && p.real && p.total > 0 -> "${formatSize(p.downloaded)} / ${formatSize(p.total)}"
                t.totalBytes > 0 -> (if (t.headersJson.contains("ytdlpFormat") && t.status != Status.COMPLETED) "~" else "") + formatSize(t.totalBytes)
                else -> null
            }
            val kind = kindOf(t.fileName, t.mimeType)
            val canSchedule = t.status != Status.COMPLETED && t.status != Status.MERGING
            Column(Modifier.fillMaxWidth().glass()
                .then(if (selecting) Modifier.clickable { if (t.id in picked) picked.remove(t.id) else picked.add(t.id) } else Modifier)
                .padding(14.dp)) {
                if (selecting) Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(t.id in picked, { c -> if (c) picked.add(t.id) else picked.remove(t.id) })
                    Text(if (canSchedule) "Sélectionner" else "Déjà terminé", color = Muted, fontSize = 11.sp)
                }
                Text(categoryFor(t.fileName, t.mimeType).icon + " " + t.fileName, color = Txt, maxLines = 1, overflow = TextOverflow.Ellipsis)
                t.subFolder?.let { Text("📁 $it", color = Muted, fontSize = 11.sp) }
                LinearProgressIndicator({ frac }, Modifier.fillMaxWidth().padding(vertical = 8.dp))
                Text((if (t.status == Status.SCHEDULED) "⏰ Programmé ${formatWhen(t.scheduledAt)}" else "${statusLabel(t.status)} • ${(frac * 100).toInt()}%") + (sizeTxt?.let { " • $it" } ?: "") +
                    (if (t.status == Status.COMPLETED) timingSuffix(t.durationSec, null)
                     else timingSuffix(t.durationSec, p?.takeIf { it.real }?.let { etaSeconds(it.downloaded, it.total, it.speedBps) })) +
                    (p?.takeIf { it.speedBps > 0 }?.let { " • ${it.speedBps / 1024} Ko/s" } ?: "") +
                    (t.error?.let { " • $it" } ?: ""), color = if (t.status == Status.FAILED) Danger else Muted, fontSize = 12.sp)
                Row(Modifier.horizontalScroll(rememberScrollState())) {
                    when (t.status) {
                        Status.RUNNING, Status.QUEUED -> TextButton({ app.downloadEngine.pause(t.id) }) { Text("Pause") }     // appel direct : la pause est immédiate
                        Status.PAUSED, Status.FAILED -> TextButton({ DownloadService.start(ctx, t.id) }) { Text("Reprendre") }
                        Status.SCHEDULED -> {
                            TextButton({ DownloadService.start(ctx, t.id) }) { Text("Démarrer maintenant") }
                            TextButton({ scope.launch { app.downloadEngine.unschedule(t.id) } }) { Text("Annuler l'heure") }
                        }
                        Status.COMPLETED -> {
                            val u = t.resultUri
                            if (u != null) {
                                val item = ViewItem(Uri.parse(u), t.fileName, t.mimeType)
                                if (kind == ViewKind.APK) TextButton({ Installer.install(ctx, item.uri) }) { Text("Installer") }
                                else TextButton({ Viewer.open(listOf(item)) }) { Text(if (kind == ViewKind.VIDEO || kind == ViewKind.AUDIO) "Lire" else "Ouvrir") }
                                TextButton({ openWithOtherApp(ctx, item) }) { Text("Ouvrir avec…") }
                            }
                        }
                        else -> {}
                    }
                    if (canSchedule) TextButton({ scheduleFor = listOf(t.id) }) { Text(if (t.status == Status.SCHEDULED) "⏰ Modifier" else "⏰ Programmer") }
                    TextButton({ app.downloadEngine.cancel(t.id) }) { Text("Supprimer") }
                }
            }
        }
    }
}

// ───────────── 3) Dossiers de l'application
private fun kindIcon(f: LibFile) = when (kindOf(f.name, f.mime)) {
    ViewKind.VIDEO -> "🎞️"; ViewKind.AUDIO -> "🎵"; ViewKind.IMAGE -> "🖼️"; ViewKind.PDF -> "📕"
    ViewKind.TEXT -> "📝"; ViewKind.APK -> "🤖"; ViewKind.OTHER -> "📦"
}

@Composable
private fun LibraryPage() {
    val ctx = LocalContext.current
    var open by rememberSaveable { mutableStateOf<String?>(null) }
    var version by remember { mutableIntStateOf(0) }
    var query by rememberSaveable { mutableStateOf("") }
    var sort by rememberSaveable { mutableStateOf("date") }
    var toDelete by remember { mutableStateOf<LibFile?>(null) }
    BackHandler(open != null) { open = null }

    // Lire n'importe quel fichier du téléphone (vidéo, audio, image, document, APK…)
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) Viewer.open(uris.map { Viewer.fromExternal(ctx, it, null) })
    }

    toDelete?.let { f ->
        AlertDialog(onDismissRequest = { toDelete = null },
            title = { Text("Supprimer ce fichier ?") }, text = { Text(f.name) },
            confirmButton = { TextButton({ Storage.delete(ctx, f); version++; toDelete = null }) { Text("Supprimer", color = Danger) } },
            dismissButton = { TextButton({ toDelete = null }) { Text("Annuler") } })
    }

    val cat = open?.let { n -> Category.entries.firstOrNull { it.name == n } }
    if (cat == null) {
        val counts by produceState<Map<Category, Int>>(emptyMap(), version) {
            value = withContext(Dispatchers.IO) { Category.entries.associateWith { Storage.count(ctx, it) } }
        }
        val (free, total) = remember(version) { Storage.space() }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Column(Modifier.fillMaxWidth().glass().padding(14.dp)) {
                    Text("Stockage", color = Muted, fontSize = 12.sp)
                    if (total > 0) {
                        LinearProgressIndicator({ 1f - free.toFloat() / total }, Modifier.fillMaxWidth().padding(vertical = 8.dp))
                        Text("${formatSize(free)} libres sur ${formatSize(total)}", color = Txt, fontSize = 13.sp)
                    }
                    Text("Download/${Prefs.rootFolder}/", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
                }
            }
            item {
                Button({ pick.launch(arrayOf("*/*")) }, Modifier.fillMaxWidth()) { Text("📂 Ouvrir un fichier du téléphone…") }
            }
            items(Category.entries) { c ->
                Row(Modifier.fillMaxWidth().glass().clickable { open = c.name }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(c.icon, fontSize = 28.sp)
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text(c.label, color = Txt, fontWeight = FontWeight.Bold)
                        Text(when (c) {
                            Category.VIDEO_MADE -> "Statuts : photos et vidéos"
                            Category.VIDEO -> "Vidéos téléchargées"
                            else -> ""
                        }, color = Muted, fontSize = 11.sp)
                    }
                    Text("${counts[c] ?: 0}", color = Accent, fontSize = 18.sp)
                }
            }
        }
    } else {
        val files by produceState<List<LibFile>?>(null, cat, version) { value = withContext(Dispatchers.IO) { Storage.list(ctx, cat) } }
        Column(Modifier.fillMaxSize()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton({ open = null }) { Text("◀ ${cat.icon} ${cat.label}", fontSize = 16.sp) }
            }
            OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth().padding(horizontal = 12.dp), singleLine = true,
                placeholder = { Text("Rechercher dans ce dossier") })
            Row(Modifier.padding(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("date" to "Récents", "name" to "Nom", "size" to "Taille").forEach { (k, l) ->
                    FilterChip(sort == k, { sort = k }, label = { Text(l, fontSize = 12.sp) })
                }
            }
            val raw = files
            when {
                raw == null -> Centered("Chargement…")
                raw.isEmpty() -> Centered("Dossier vide")
                else -> {
                    val list = remember(raw, query, sort) {
                        raw.filter { query.isBlank() || it.name.contains(query, true) || it.folder.contains(query, true) }
                            .let { l -> when (sort) { "name" -> l.sortedBy { it.name.lowercase() }; "size" -> l.sortedByDescending { it.size }; else -> l } }
                    }
                    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(list, key = { it.uri.toString() }) { f ->
                            val kind = kindOf(f.name, f.mime)
                            val thumb by produceState<ImageBitmap?>(null, f.uri) {
                                if (kind == ViewKind.VIDEO || kind == ViewKind.IMAGE) value = withContext(Dispatchers.IO) {
                                    runCatching { ctx.contentResolver.loadThumbnail(f.uri, Size(192, 192), null).asImageBitmap() }.getOrNull()
                                }
                            }
                            Column(Modifier.fillMaxWidth().glass().clickable { Viewer.openFrom(list, f) }.padding(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.size(56.dp).clip(RoundedCornerShape(12.dp)).background(Surface2), contentAlignment = Alignment.Center) {
                                        val t = thumb
                                        if (t != null) Image(t, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) else Text(kindIcon(f), fontSize = 24.sp)
                                    }
                                    Column(Modifier.weight(1f).padding(start = 12.dp)) {
                                        Text(f.name, color = Txt, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                                        Text(buildString {
                                            append(formatSize(f.size)); append(" • ")
                                            append(DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(f.modified)))
                                            if (f.folder.isNotEmpty()) append(" • 📁 ${f.folder}")
                                        }, color = Muted, fontSize = 11.sp)
                                    }
                                }
                                Row {
                                    if (kind == ViewKind.APK) TextButton({ Installer.install(ctx, f.uri) }) { Text("Installer") }
                                    else TextButton({ Viewer.openFrom(list, f) }) { Text(if (kind == ViewKind.VIDEO || kind == ViewKind.AUDIO) "Lire" else "Ouvrir") }
                                    TextButton({ shareItem(ctx, f.toViewItem()) }) { Text("Partager") }
                                    TextButton({ if (Prefs.confirmDelete) toDelete = f else { Storage.delete(ctx, f); version++ } }) { Text("Supprimer") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
