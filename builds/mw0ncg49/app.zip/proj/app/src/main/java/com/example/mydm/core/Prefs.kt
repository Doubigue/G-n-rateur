package com.example.mydm.core

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray

enum class SearchEngine(val label: String, val template: String) {
    GOOGLE("Google", "https://www.google.com/search?q="),
    DUCKDUCKGO("DuckDuckGo", "https://duckduckgo.com/?q="),
    BING("Bing", "https://www.bing.com/search?q="),
    ECOSIA("Ecosia", "https://www.ecosia.org/search?q=")
}

/** Moteurs de recherche par photo : la page s'ouvre et la photo choisie est envoyée au bouton « importer ». */
enum class ImageEngine(val label: String, val url: String) {
    LENS("Google Lens", "https://lens.google.com/"),
    BING("Bing Visual", "https://www.bing.com/visualsearch"),
    TINEYE("TinEye", "https://tineye.com/"),
    YANDEX("Yandex", "https://yandex.com/images/")
}

/**
 * Style de l'application : change le FOND, les cartes, la couleur du texte ET l'accent.
 * [accent] est la couleur d'accent proposée par le style (remplaçable dans Paramètres > Couleur d'accent).
 */
enum class ThemeMode(
    val label: String, val dark: Boolean,
    val bg: Long, val surface1: Long, val surface2: Long, val text: Long, val muted: Long, val accent: Long
) {
    SYSTEM("Auto", true, 0xFF0D0F1C, 0xFF171A2E, 0xFF212545, 0xFFF2F4FF, 0xFF9AA3C7, 0xFF8B7CFF),   // suit le téléphone : Sombre ou Clair
    DARK("Sombre", true, 0xFF0D0F1C, 0xFF171A2E, 0xFF212545, 0xFFF2F4FF, 0xFF9AA3C7, 0xFF8B7CFF),
    AMOLED("Noir pur", true, 0xFF000000, 0xFF0E0E14, 0xFF181822, 0xFFF2F4FF, 0xFF9AA3C7, 0xFF8B7CFF),
    LIGHT("Clair", false, 0xFFF4F5FB, 0xFFFFFFFF, 0xFFE9EBF7, 0xFF14172B, 0xFF5B627F, 0xFF6B5CE7),
    OCEAN("Océan", true, 0xFF06161F, 0xFF0B2533, 0xFF11384D, 0xFFE6F6FF, 0xFF8DB4C8, 0xFF22D3EE),
    FORET("Forêt", true, 0xFF0A140F, 0xFF112019, 0xFF1A3326, 0xFFE8F5EC, 0xFF91B3A0, 0xFF3DDC97),
    CREPUSCULE("Crépuscule", true, 0xFF1A0F1E, 0xFF261630, 0xFF3A2145, 0xFFFFEFF5, 0xFFC7A3B8, 0xFFFF8A5B),
    MINUIT("Minuit", true, 0xFF0A0E2A, 0xFF121845, 0xFF1C2466, 0xFFEAEDFF, 0xFF98A0D8, 0xFF6C8CFF),
    CAFE("Café", true, 0xFF17100C, 0xFF241913, 0xFF36271D, 0xFFF6EBDD, 0xFFB8A28C, 0xFFD9A066),
    GRAPHITE("Graphite", true, 0xFF16181B, 0xFF202327, 0xFF2D3136, 0xFFECEFF2, 0xFF9AA1A9, 0xFFF2B84B),
    ROSE("Rose bonbon", false, 0xFFFFF1F5, 0xFFFFFFFF, 0xFFFFDCE7, 0xFF3A1624, 0xFF8A5A6B, 0xFFE0457B),
    MENTHE("Menthe", false, 0xFFEFFAF5, 0xFFFFFFFF, 0xFFD5F2E5, 0xFF0F2A20, 0xFF4F7A68, 0xFF12A66F),
    PAPIER("Papier", false, 0xFFF6EEDC, 0xFFFFF9EA, 0xFFEADDC0, 0xFF3B2F1E, 0xFF7A6A50, 0xFFB7791F),
    CIEL("Ciel", false, 0xFFEAF4FF, 0xFFFFFFFF, 0xFFD2E6FB, 0xFF0F2238, 0xFF55708F, 0xFF2F7BE8)
}

enum class AccentColor(val label: String, val argb: Long) {
    AUTO("Selon le style", 0),
    VIOLET("Violet", 0xFF8B7CFF), CYAN("Cyan", 0xFF22D3EE), ROSE("Rose", 0xFFFF6B9D),
    VERT("Vert", 0xFF3DDC97), ORANGE("Orange", 0xFFFFA24C), BLEU("Bleu", 0xFF4C8DFF),
    ROUGE("Rouge", 0xFFFF5A5F), JAUNE("Jaune", 0xFFFFD43B)
}

/** Réglages de l'application (SharedPreferences + état Compose, donc l'UI se met à jour seule). */
object Prefs {
    const val DEFAULT_HOME = "https://www.google.com"
    lateinit var sp: SharedPreferences; private set

    // ── Navigateur
    var homeUrl by mutableStateOf(DEFAULT_HOME); private set
    var searchEngine by mutableStateOf(SearchEngine.GOOGLE); private set
    var imageEngine by mutableStateOf(ImageEngine.LENS); private set
    var desktopMode by mutableStateOf(false); private set
    var blockPopups by mutableStateOf(true); private set
    var restoreTabs by mutableStateOf(true); private set
    var jsEnabled by mutableStateOf(true); private set
    var loadImages by mutableStateOf(true); private set
    var textZoom by mutableIntStateOf(100); private set
    var blockAds by mutableStateOf(true); private set
    var externalNewTab by mutableStateOf(true); private set
    // ── Téléchargements
    var maxSegments by mutableIntStateOf(16); private set
    var maxParallel by mutableIntStateOf(3); private set
    var wifiOnly by mutableStateOf(false); private set
    var autoRetry by mutableStateOf(true); private set          // relance seule un téléchargement en échec (503, coupure, délai…)
    var autoDownloadShared by mutableStateOf(false); private set  // lien partagé vers MyDM : false = écran d'analyse + choix du format ; true = téléchargement direct
    // ── Mise à jour de MyDM (OTA)
    var autoUpdateCheck by mutableStateOf(true); private set     // vérifie au démarrage (au plus toutes les 6 h)
    var updateUrl by mutableStateOf(""); private set             // JSON de mise à jour ou API GitHub Releases
    var skippedUpdate by mutableStateOf(""); private set         // version « ignorée »
    var speedLimitKbps by mutableIntStateOf(0); private set     // 0 = illimité (par téléchargement)
    var rootFolder by mutableStateOf("MyDM"); private set
    var notifLines by mutableIntStateOf(5); private set
    var notifyDone by mutableStateOf(true); private set
    // ── Détection
    var autoDetect by mutableStateOf(false); private set        // ajouter automatiquement à « À télécharger » les médias vus en naviguant
    var seriesFrenchOnly by mutableStateOf(true); private set   // séries : cocher par défaut seulement les épisodes en français
    var detectVideo by mutableStateOf(true); private set
    var detectAudio by mutableStateOf(true); private set
    var detectFiles by mutableStateOf(true); private set
    // ── Apparence
    var themeMode by mutableStateOf(ThemeMode.DARK); private set
    var accent by mutableStateOf(AccentColor.AUTO); private set
    // ── Analyse de pages / séries
    var prefetchLinks by mutableStateOf(true); private set     // pré-analyse YouTube/Facebook/TikTok dès l'ouverture de la page
    var clipboardWatch by mutableStateOf(true); private set    // propose les liens copiés
    var scanSeconds by mutableIntStateOf(8); private set       // durée max d'analyse d'une page (sans la lire)
    var scanEmbeds by mutableIntStateOf(3); private set        // lecteurs intégrés (iframes) analysés par page
    var seriesParallel by mutableIntStateOf(2); private set    // épisodes analysés en même temps
    var seriesFolders by mutableStateOf(true); private set     // un dossier par série
    // ── Lecteur
    var autoPlayNext by mutableStateOf(true); private set
    var resumePlayback by mutableStateOf(true); private set
    var keepScreenOn by mutableStateOf(true); private set
    var confirmDelete by mutableStateOf(true); private set
    // ── Moteur yt-dlp
    var autoUpdateYt by mutableStateOf(true); private set
    // ── Développeur
    var captureConsole by mutableStateOf(true); private set
    var siteMaxMb by mutableIntStateOf(100); private set

    fun init(ctx: Context) {
        sp = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
        homeUrl = sp.getString("home", DEFAULT_HOME) ?: DEFAULT_HOME
        searchEngine = runCatching { SearchEngine.valueOf(sp.getString("engine", "GOOGLE")!!) }.getOrDefault(SearchEngine.GOOGLE)
        imageEngine = runCatching { ImageEngine.valueOf(sp.getString("imgEngine", "LENS")!!) }.getOrDefault(ImageEngine.LENS)
        desktopMode = sp.getBoolean("desktop", false)
        blockPopups = sp.getBoolean("popupsV3", true)
        restoreTabs = sp.getBoolean("restoreTabs", true)
        jsEnabled = sp.getBoolean("js", true)
        loadImages = sp.getBoolean("images", true)
        textZoom = sp.getInt("textZoom", 100)
        blockAds = sp.getBoolean("adsV3", true)
        autoDetect = sp.getBoolean("autoDetect", false)
        seriesFrenchOnly = sp.getBoolean("seriesFr", true)
        externalNewTab = sp.getBoolean("externalNewTab", true)
        maxSegments = sp.getInt("segmentsV2", 16)          // v2.9.4 : 16 connexions par défaut (ancien réglage remis à 16)
        maxParallel = sp.getInt("parallel", 3)
        wifiOnly = sp.getBoolean("wifiOnly", false)
        autoRetry = sp.getBoolean("autoRetry", true)
        autoDownloadShared = sp.getBoolean("autoSharedV2", false)
        autoUpdateCheck = sp.getBoolean("otaAuto", true)
        updateUrl = sp.getString("otaUrl", "") ?: ""
        skippedUpdate = sp.getString("otaSkip", "") ?: ""
        speedLimitKbps = sp.getInt("speedLimit", 0)
        rootFolder = sp.getString("root", "MyDM") ?: "MyDM"
        notifLines = sp.getInt("notifLines", 5)
        notifyDone = sp.getBoolean("notifyDone", true)
        detectVideo = sp.getBoolean("detVideo", true)
        detectAudio = sp.getBoolean("detAudio", true)
        detectFiles = sp.getBoolean("detFiles", true)
        themeMode = runCatching { ThemeMode.valueOf(sp.getString("theme", "DARK")!!) }.getOrDefault(ThemeMode.DARK)
        accent = runCatching { AccentColor.valueOf(sp.getString("accent", "AUTO")!!) }.getOrDefault(AccentColor.AUTO)
        prefetchLinks = sp.getBoolean("prefetch", true)
        clipboardWatch = sp.getBoolean("clipboard", true)
        scanSeconds = sp.getInt("scanSec", 10)
        scanEmbeds = sp.getInt("scanEmbeds", 5)
        seriesParallel = sp.getInt("seriesPar", 2)
        seriesFolders = sp.getBoolean("seriesFolders", true)
        autoPlayNext = sp.getBoolean("autoNext", true)
        resumePlayback = sp.getBoolean("resume", true)
        keepScreenOn = sp.getBoolean("keepOn", true)
        confirmDelete = sp.getBoolean("confirmDel", true)
        autoUpdateYt = sp.getBoolean("autoYt", true)
        captureConsole = sp.getBoolean("console", true)
        siteMaxMb = sp.getInt("siteMaxMb", 100)
    }

    private fun b(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()
    private fun i(k: String, v: Int) = sp.edit().putInt(k, v).apply()

    fun updateHomeUrl(v: String) {
        val t = v.trim().ifEmpty { DEFAULT_HOME }
        homeUrl = if (t.startsWith("http://") || t.startsWith("https://")) t else "https://$t"
        sp.edit().putString("home", homeUrl).apply()
    }
    fun updateSearchEngine(v: SearchEngine) { searchEngine = v; sp.edit().putString("engine", v.name).apply() }
    fun updateImageEngine(v: ImageEngine) { imageEngine = v; sp.edit().putString("imgEngine", v.name).apply() }
    fun updateDesktopMode(v: Boolean) { desktopMode = v; b("desktop", v) }
    fun updateBlockPopups(v: Boolean) { blockPopups = v; b("popupsV3", v) }
    fun updateRestoreTabs(v: Boolean) { restoreTabs = v; b("restoreTabs", v) }
    fun updateJs(v: Boolean) { jsEnabled = v; b("js", v) }
    fun updateLoadImages(v: Boolean) { loadImages = v; b("images", v) }
    fun updateTextZoom(v: Int) { textZoom = v; i("textZoom", v) }
    fun updateBlockAds(v: Boolean) { blockAds = v; b("adsV3", v) }
    fun updateAutoDetect(v: Boolean) { autoDetect = v; b("autoDetect", v) }
    fun updateSeriesFrenchOnly(v: Boolean) { seriesFrenchOnly = v; b("seriesFr", v) }
    fun updateExternalNewTab(v: Boolean) { externalNewTab = v; b("externalNewTab", v) }
    fun updateMaxSegments(v: Int) { maxSegments = v; i("segmentsV2", v) }
    fun updateMaxParallel(v: Int) { maxParallel = v; i("parallel", v) }
    fun updateWifiOnly(v: Boolean) { wifiOnly = v; b("wifiOnly", v) }
    fun updateAutoDownloadShared(v: Boolean) { autoDownloadShared = v; b("autoSharedV2", v) }
    fun updateAutoUpdateCheck(v: Boolean) { autoUpdateCheck = v; b("otaAuto", v) }
    fun updateUpdateUrl(v: String) { updateUrl = v.trim(); sp.edit().putString("otaUrl", updateUrl).apply() }
    fun skipUpdate(v: String) { skippedUpdate = v; sp.edit().putString("otaSkip", v).apply() }
    fun lastUpdateCheck(): Long = sp.getLong("otaChecked", 0L)
    fun markUpdateChecked() { sp.edit().putLong("otaChecked", System.currentTimeMillis()).apply() }
    fun updateSpeedLimit(v: Int) { speedLimitKbps = v; i("speedLimit", v) }
    fun updateRootFolder(v: String) {
        rootFolder = v.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifEmpty { "MyDM" }
        sp.edit().putString("root", rootFolder).apply()
    }
    fun updateNotifLines(v: Int) { notifLines = v; i("notifLines", v) }
    fun updateNotifyDone(v: Boolean) { notifyDone = v; b("notifyDone", v) }
    fun updateAutoRetry(v: Boolean) { autoRetry = v; b("autoRetry", v) }
    fun updateDetectVideo(v: Boolean) { detectVideo = v; b("detVideo", v) }
    fun updateDetectAudio(v: Boolean) { detectAudio = v; b("detAudio", v) }
    fun updateDetectFiles(v: Boolean) { detectFiles = v; b("detFiles", v) }
    fun updateThemeMode(v: ThemeMode) { themeMode = v; sp.edit().putString("theme", v.name).apply() }
    fun updateAccent(v: AccentColor) { accent = v; sp.edit().putString("accent", v.name).apply() }
    fun updatePrefetch(v: Boolean) { prefetchLinks = v; b("prefetch", v) }
    fun updateClipboardWatch(v: Boolean) { clipboardWatch = v; b("clipboard", v) }
    fun updateScanSeconds(v: Int) { scanSeconds = v; i("scanSec", v) }
    fun updateScanEmbeds(v: Int) { scanEmbeds = v; i("scanEmbeds", v) }
    fun updateSeriesParallel(v: Int) { seriesParallel = v; i("seriesPar", v) }
    fun updateSeriesFolders(v: Boolean) { seriesFolders = v; b("seriesFolders", v) }
    fun updateAutoPlayNext(v: Boolean) { autoPlayNext = v; b("autoNext", v) }
    fun updateResumePlayback(v: Boolean) { resumePlayback = v; b("resume", v) }
    fun updateKeepScreenOn(v: Boolean) { keepScreenOn = v; b("keepOn", v) }
    fun updateConfirmDelete(v: Boolean) { confirmDelete = v; b("confirmDel", v) }
    fun updateAutoUpdateYt(v: Boolean) { autoUpdateYt = v; b("autoYt", v) }
    fun updateCaptureConsole(v: Boolean) { captureConsole = v; b("console", v) }
    fun updateSiteMaxMb(v: Int) { siteMaxMb = v; i("siteMaxMb", v) }

    /** Transforme ce que tape l'utilisateur en URL : adresse, domaine ou recherche. */
    fun resolveInput(input: String): String {
        val t = input.trim()
        return when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            "." in t && " " !in t -> "https://$t"
            else -> searchEngine.template + android.net.Uri.encode(t)
        }
    }

    // ── Positions de lecture (reprise)
    fun savePosition(key: String, ms: Long) { sp.edit().putLong("pos_" + key.hashCode(), ms).apply() }
    fun position(key: String): Long = sp.getLong("pos_" + key.hashCode(), 0L)
    fun lastYtUpdate(): Long = sp.getLong("ytUpdated", 0L)
    fun markYtUpdated() { sp.edit().putLong("ytUpdated", System.currentTimeMillis()).apply() }

    // ── Onglets ouverts (restaurés au démarrage si l'option est active)
    fun saveTabs(urls: List<String>, current: Int) {
        sp.edit().putString("tabs", JSONArray(urls).toString()).putInt("tabIndex", current).apply()
    }
    fun savedTabs(): List<String> = runCatching {
        val a = JSONArray(sp.getString("tabs", "[]"))
        List(a.length()) { a.getString(it) }.filter { it.startsWith("http") }
    }.getOrDefault(emptyList())
    fun savedTabIndex(): Int = sp.getInt("tabIndex", 0)
}
