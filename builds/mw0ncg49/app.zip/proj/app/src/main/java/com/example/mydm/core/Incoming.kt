package com.example.mydm.core

import android.content.Intent
import android.net.Uri
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Liens / fichiers / images reçus d'autres applications (VIEW, SEND). */
object Incoming {
    var url by mutableStateOf<String?>(null)
    /** Lien reçu à télécharger directement (sans analyse) ; s'il n'est pas téléchargeable, il s'ouvre dans le navigateur. */
    var autoLink by mutableStateOf<String?>(null)
    /** true = on interroge le serveur pour savoir si le lien est un fichier (partage) ; false = test sur l'extension seulement. */
    var autoProbe = false
    var image by mutableStateOf<Uri?>(null)
    /** Fichier externe à lire dans la visionneuse intégrée (vidéo, audio, image, PDF, texte, APK…). */
    var file by mutableStateOf<ViewItem?>(null)
    lateinit var appContext: android.content.Context

    fun handle(i: Intent?) {
        i ?: return
        when (i.action) {
            Intent.ACTION_VIEW -> {
                val d = i.data ?: return
                when (d.scheme) {
                    "content", "file" -> file = Viewer.fromExternal(appContext, d, i.type ?: "")
                    else -> {
                        val u = d.toString()
                        if (AutoDownload.looksLikeFile(u)) { autoProbe = false; autoLink = u } else url = u
                    }
                }
            }
            Intent.ACTION_SEND -> {
                val t0 = i.type ?: ""
                // Facebook / Instagram / TikTok / Pinterest… envoient souvent EXTRA_TEXT en CharSequence (pas String) :
                // getStringExtra() renvoyait null et le partage était ignoré en silence.
                val shared = (i.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString() ?: i.getStringExtra(Intent.EXTRA_SUBJECT))?.trim()
                val sharedLink = shared?.let { Regex("https?://\\S+").find(it)?.value?.trimEnd('.', ',', ')', ']', '>', '"', '\'', '!', ';') }
                if (sharedLink != null && (!i.hasExtra(Intent.EXTRA_STREAM) || t0.startsWith("text/"))) {
                    autoProbe = true; autoLink = sharedLink
                    return
                }
                if (!t0.startsWith("image/") && !t0.startsWith("text/") && i.hasExtra(Intent.EXTRA_STREAM)) {
                    @Suppress("DEPRECATION") val u = i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
                    if (u != null) file = Viewer.fromExternal(appContext, u, t0)
                } else if (t0.startsWith("image/")) {
                    @Suppress("DEPRECATION") image = i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
                } else {
                    val t = shared ?: return
                    // Lien partagé (Facebook, TikTok, Instagram, YouTube, X…) : on retire la ponctuation collée au lien
                    val link = Regex("https?://\\S+").find(t)?.value?.trimEnd('.', ',', ')', ']', '>', '"', '\'', '!', ';')
                    if (link != null) { autoProbe = true; autoLink = link }       // téléchargement direct si c'est une vidéo / un fichier
                    else url = Prefs.resolveInput(t)
                }
            }
        }
    }
}

/** Sélecteur de fichiers des pages web (<input type=file>) ; sert aussi à la recherche par photo. */
object FileChooserBridge {
    /** Photo choisie pour la recherche : renvoyée automatiquement au prochain bouton « importer » du site. */
    var pendingImage: Uri? = null
    var launcher: ((Intent) -> Unit)? = null
    private var callback: ValueCallback<Array<Uri>>? = null

    fun show(cb: ValueCallback<Array<Uri>>, intent: Intent): Boolean {
        pendingImage?.let { cb.onReceiveValue(arrayOf(it)); pendingImage = null; return true }
        callback?.onReceiveValue(null); callback = cb
        return runCatching { launcher!!.invoke(intent); true }.getOrElse { callback = null; cb.onReceiveValue(null); false }
    }

    fun result(code: Int, data: Intent?) {
        callback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(code, data)); callback = null
    }
}
