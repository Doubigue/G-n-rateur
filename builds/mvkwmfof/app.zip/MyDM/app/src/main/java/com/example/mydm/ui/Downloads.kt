package com.example.mydm.ui

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.mydm.browser.BrowserManager
import com.example.mydm.core.*
import com.example.mydm.downloader.DownloadService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date

/** Page « Téléchargements » : À télécharger (liste des médias détectés) • En cours / terminés • Dossiers. */
@Composable
fun DownloadsScreen(manager: BrowserManager) {
    val app = appInstance()
    val tasks by app.db.downloadDao().observeTasks().collectAsStateWithLifecycle(emptyList())
    val active = tasks.count { it.status == Status.RUNNING || it.status == Status.QUEUED || it.status == Status.MERGING }
    val toGet = manager.allFound().size
    var page by rememberSaveable { mutableIntStateOf(0) }
    val titles = listOf("À télécharger" to toGet, "Téléchargements" to active, "Dossiers" to 0)

    Column(Modifier.fillMaxSize()) {
        TabRow(page, containerColor = Bg) {
            titles.forEachIndexed { i, (t, n) ->
                Tab(page == i, { page = i }, text = {
                    BadgedBox(badge = { if (n > 0) Badge { Text("$n") } }) { Text(t, fontSize = 13.sp, maxLines = 1) }
                })
            }
        }
        when (page) {
            0 -> ToDownloadPage(manager) { page = 1 }
            1 -> TasksPage(tasks)
            else -> LibraryPage()
        }
    }
}

// ───────────── 1) Liste des médias à télécharger
@Composable
private fun ToDownloadPage(manager: BrowserManager, goTasks: () -> Unit) {
    val ctx = LocalContext.current; val app = appInstance(); val scope = rememberCoroutineScope()
    var filter by remember { mutableStateOf("Tous") }
    val sizes = remember { mutableStateMapOf<String, Long?>() }
    val all = manager.allFound()
    val shown = all.filter {
        when (filter) {
            "Vidéos" -> it.type == MediaType.VIDEO || it.type == MediaType.HLS
            "Audio" -> it.type == MediaType.AUDIO
            "Fichiers" -> it.type != MediaType.VIDEO && it.type != MediaType.HLS && it.type != MediaType.AUDIO
            else -> true
        }
    }
    fun get(m: DetectedMedia) = scope.launch { DownloadActions.queue(ctx, app, m); manager.removeFound(m) }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            listOf("Tous", "Vidéos", "Audio", "Fichiers").forEach { f -> FilterChip(filter == f, { filter = f }, label = { Text(f, fontSize = 12.sp) }) }
        }
        if (shown.isEmpty()) {
            Centered("Aucun média détecté.\nOuvrez une page dans le navigateur et lancez une vidéo : elle apparaîtra ici.")
            return@Column
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
            Button({ scope.launch { shown.forEach { DownloadActions.queue(ctx, app, it); manager.removeFound(it) }; goTasks() } }) { Text("Tout télécharger (${shown.size})") }
            Spacer(Modifier.width(8.dp))
            OutlinedButton({ manager.clearDetected() }) { Text("Vider") }
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(shown, key = { it.url }) { m ->
                LaunchedEffect(m.url) { if (m.sizeBytes == null && m.url !in sizes) sizes[m.url] = MediaResolver.probeSize(m) }
                val size = m.sizeBytes ?: sizes[m.url]
                Row(Modifier.fillMaxWidth().glass().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(when (m.type) { MediaType.VIDEO, MediaType.HLS -> "🎞️"; MediaType.AUDIO -> "🎵"; MediaType.APK -> "🤖"; MediaType.PDF -> "📄"; else -> "📦" }, fontSize = 24.sp)
                    Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                        Text(m.displayName(), color = Color.White, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                        Text("${m.type.name} • " + (size?.let { formatSize(it) } ?: if (m.url in sizes) "taille inconnue" else "calcul…") +
                            " • " + (Uri.parse(m.url).host ?: ""), color = Muted, fontSize = 11.sp, maxLines = 1)
                    }
                    Button({ get(m) }, contentPadding = PaddingValues(horizontal = 12.dp)) { Text("⬇") }
                }
            }
        }
    }
}

// ───────────── 2) Téléchargements en cours / terminés
@Composable
private fun TasksPage(tasks: List<DownloadTask>) {
    val ctx = LocalContext.current; val app = appInstance(); val scope = rememberCoroutineScope()
    val progress by app.downloadEngine.progress.collectAsStateWithLifecycle()
    if (tasks.isEmpty()) { Centered("Aucun téléchargement"); return }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row {
                TextButton({ ctx.startService(Intent(ctx, DownloadService::class.java).setAction(DownloadService.ACTION_PAUSE_ALL)) }) { Text("Tout mettre en pause") }
                TextButton({ scope.launch { app.db.downloadDao().clearCompleted() } }) { Text("Effacer les terminés") }
            }
        }
        items(tasks, key = { it.id }) { t ->
            val p = progress[t.id]
            val total = p?.total ?: t.totalBytes
            val frac = if (t.status == Status.COMPLETED) 1f else if (p != null && total > 0) (p.downloaded.toFloat() / total).coerceIn(0f, 1f) else 0f
            val sizeTxt = when {
                p != null && p.real && p.total > 0 -> "${formatSize(p.downloaded)} / ${formatSize(p.total)}"
                t.totalBytes > 0 -> formatSize(t.totalBytes)
                else -> null
            }
            Column(Modifier.fillMaxWidth().glass().padding(14.dp)) {
                Text(categoryFor(t.fileName, t.mimeType).icon + " " + t.fileName, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                LinearProgressIndicator({ frac }, Modifier.fillMaxWidth().padding(vertical = 8.dp))
                Text("${t.status} • ${(frac * 100).toInt()}%" + (sizeTxt?.let { " • $it" } ?: "") +
                    (p?.takeIf { it.speedBps > 0 }?.let { " • ${it.speedBps / 1024} Ko/s" } ?: "") +
                    (t.error?.let { " • $it" } ?: ""), color = if (t.status == Status.FAILED) Color(0xFFFF8A80) else Muted, fontSize = 12.sp)
                Row {
                    when (t.status) {
                        Status.RUNNING, Status.QUEUED -> TextButton({
                            ctx.startService(Intent(ctx, DownloadService::class.java)
                                .setAction(DownloadService.ACTION_PAUSE).putExtra(DownloadService.EXTRA_ID, t.id))
                        }) { Text("Pause") }
                        Status.PAUSED, Status.FAILED -> TextButton({ DownloadService.start(ctx, t.id) }) { Text("Reprendre") }
                        Status.COMPLETED -> TextButton({ openUri(ctx, t.resultUri) }) { Text("Ouvrir") }
                        else -> {}
                    }
                    TextButton({ app.downloadEngine.cancel(t.id) }) { Text("Supprimer") }
                }
            }
        }
    }
}

private fun openUri(ctx: android.content.Context, u: String?, mime: String? = null) {
    u ?: return
    val uri = Uri.parse(u)
    runCatching {
        ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime ?: ctx.contentResolver.getType(uri))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
    }.onFailure { Toast.makeText(ctx, "Aucune application pour ouvrir ce fichier", Toast.LENGTH_SHORT).show() }
}

// ───────────── 3) Dossiers de l'application
@Composable
private fun LibraryPage() {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    var open by rememberSaveable { mutableStateOf<String?>(null) }
    var version by remember { mutableIntStateOf(0) }
    BackHandler(open != null) { open = null }

    val cat = open?.let { n -> Category.entries.firstOrNull { it.name == n } }
    if (cat == null) {
        val counts by produceState<Map<Category, Int>>(emptyMap(), version) {
            value = withContext(Dispatchers.IO) { Category.entries.associateWith { Storage.count(ctx, it) } }
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Text("Download/${Prefs.rootFolder}/", color = Muted, fontSize = 12.sp) }
            items(Category.entries) { c ->
                Row(Modifier.fillMaxWidth().glass().clickable { open = c.name }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(c.icon, fontSize = 28.sp)
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text(c.label, color = Color.White, fontWeight = FontWeight.Bold)
                        Text(when (c) {
                            Category.VIDEO_MADE -> "Statuts : photos et vidéos"
                            Category.TORRENT -> "Vidéos, applications, logiciels, documents, jeux…"
                            Category.VIDEO -> "Vidéos téléchargées"
                            else -> ""
                        }, color = Muted, fontSize = 11.sp)
                    }
                    Text("${counts[c] ?: 0}", color = Accent, fontSize = 18.sp)
                }
            }
        }
    } else {
        val files by produceState<List<LibFile>?>(null, cat, version) { value = withContext(Dispatchers.IO) { Storage.list(ctx, cat) } }
        Column(Modifier.fillMaxSize()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton({ open = null }) { Text("◀ ${cat.icon} ${cat.label}", fontSize = 16.sp) }
            }
            val list = files
            when {
                list == null -> Centered("Chargement…")
                list.isEmpty() -> Centered("Dossier vide")
                else -> LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(list, key = { it.uri.toString() }) { f ->
                        Column(Modifier.fillMaxWidth().glass().clickable { openUri(ctx, f.uri.toString(), f.mime) }.padding(12.dp)) {
                            Text(f.name, color = Color.White, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                            Text(buildString {
                                append(formatSize(f.size)); append(" • ")
                                append(DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(f.modified)))
                                if (f.folder.isNotEmpty()) append(" • ${f.folder}")
                            }, color = Muted, fontSize = 11.sp)
                            Row {
                                TextButton({
                                    ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType(f.mime ?: "*/*")
                                        .putExtra(Intent.EXTRA_STREAM, f.uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), null))
                                }) { Text("Partager") }
                                TextButton({ Storage.delete(ctx, f); version++ }) { Text("Supprimer") }
                            }
                        }
                    }
                }
            }
        }
    }
}
