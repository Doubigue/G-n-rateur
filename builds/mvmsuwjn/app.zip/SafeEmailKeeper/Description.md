# SafeEmail Keeper
Gardez tous vos comptes email, clés de secours et méthodes de sécurité au même endroit, chiffrés sur votre téléphone.

## Fonctions
- 📧 **Comptes email** : ajoutez et modifiez vos adresses avec mot de passe et numéro de récupération.
- 🔑 **Clés de secours** : chaque clé est une puce que l'on peut ajouter, retirer ou mettre à jour.
- ✂️ **Barrer une clé** : un simple tap barre la clé déjà utilisée, avec une rayure animée.
- 🛡️ **Méthodes de sécurité** : notez 2FA, YubiKey, questions secrètes et email de secours.
- 👁️ **Mot de passe** : affichez, masquez ou copiez le mot de passe en un geste.
- 📜 **Journal** : suivez chaque action dans une frise animée.
- 📄 **Export PDF global** : un seul PDF élégant avec tous les comptes.
- 🗜️ **Export ZIP** : une archive avec un PDF stylé par email.

## Comment l'utiliser
1. Touchez le bouton + pour ajouter un compte.
2. Saisissez l'email, le mot de passe et le numéro de récupération.
3. Ajoutez vos clés de secours une à une.
4. Touchez une clé utilisée pour la barrer.
5. Ajoutez vos méthodes de sécurité.
6. Touchez Enregistrer pour valider.
7. Ouvrez l'onglet Journal pour revoir l'historique.
8. Ouvrez Export pour créer le PDF global ou le ZIP.

## Astuces
> Appui long sur une clé : elle est supprimée.
> Masquez les mots de passe avant de partager un PDF.

## Captures
- 01-accueil.png : liste des comptes
- 02-compte.png : saisie d'un compte
- 03-cles.png : clés de secours, une barrée
- 04-journal.png : journal d'activités
- 05-export.png : export PDF et ZIP
