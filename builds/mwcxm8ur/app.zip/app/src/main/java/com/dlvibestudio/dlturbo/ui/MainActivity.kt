package com.dlvibestudio.dlturbo.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import com.dlvibestudio.dlturbo.App

class MainActivity : ComponentActivity() {

    /** Lien reçu par « Partager » ou par un clic sur un lien magnet : pré-remplit la fenêtre d'ajout. */
    private val pendingText = mutableStateOf<String?>(null)
    private lateinit var hub: WebHub
    private val inPip = mutableStateOf(false)
    private val locked = mutableStateOf(false)
    private val clipLink = mutableStateOf<String?>(null)
    private var lastClip = ""
    private var stoppedAt = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as App
        hub = WebHub(this, app)
        app.hub = hub
        locked.value = app.settings.value.pinHash.isNotEmpty()
        if (savedInstanceState == null) handleIntent(intent)

        setContent {
            val settings by app.settings.data.collectAsState()
            // Avec un code : pas de capture d'écran ni d'aperçu dans les applications récentes.
            LaunchedEffect(settings.pinHash.isNotEmpty()) {
                if (settings.pinHash.isNotEmpty()) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
                else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
            }
            DLTheme(settings.theme) {
                if (locked.value && settings.pinHash.isNotEmpty()) {
                    LockScreen(app, onUnlock = { locked.value = false })
                } else {
                    AppRoot(app, hub, pendingText, inPip.value)
                    clipLink.value?.let { link ->
                        androidx.compose.material3.AlertDialog(
                            onDismissRequest = { clipLink.value = null },
                            title = { Text("Lien copié détecté") },
                            text = { Text(link, maxLines = 4, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis) },
                            confirmButton = {
                                androidx.compose.material3.TextButton(onClick = {
                                    pendingText.value = link
                                    clipLink.value = null
                                }) { Text("Télécharger") }
                            },
                            dismissButton = {
                                androidx.compose.material3.TextButton(onClick = { clipLink.value = null }) { Text("Ignorer") }
                            },
                        )
                    }
                }
            }
        }
        // L'activité est au premier plan : c'est le bon moment pour relancer ce qui avait été coupé.
        app.manager.resumeInterrupted()
    }

    /** Au retour dans l'appli : un lien copié (vidéo, magnet, fichier) est proposé au téléchargement. */
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus || locked.value || pendingText.value != null || clipLink.value != null) return
        val app = application as App
        if (!app.settings.value.clipboardWatch) return
        val text = runCatching {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()
        }.getOrNull()?.trim().orEmpty()
        if (text.isEmpty() || text == lastClip || text.length > 2000) return
        lastClip = text
        val link = com.dlvibestudio.dlturbo.engine.Links.extract(text).firstOrNull() ?: return
        // Pas de doublon avec ce qui est déjà dans la liste.
        if (app.repo.items.value.any { it.url == link }) return
        clipLink.value = link
    }

    override fun onStop() {
        super.onStop()
        stoppedAt = System.currentTimeMillis()
    }

    override fun onStart() {
        super.onStart()
        val app = application as App
        // Retour dans l'appli après plus de 30 s : le code est redemandé.
        if (app.settings.value.pinHash.isNotEmpty() && stoppedAt > 0 &&
            System.currentTimeMillis() - stoppedAt > 30_000
        ) locked.value = true
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        val app = application as App
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && app.videoOnScreen &&
            packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)
        ) {
            runCatching {
                enterPictureInPictureMode(
                    android.app.PictureInPictureParams.Builder().setAspectRatio(android.util.Rational(16, 9)).build()
                )
            }
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: android.content.res.Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip.value = isInPictureInPictureMode
    }

    override fun onPause() {
        super.onPause()
        hub.pause()
    }

    override fun onResume() {
        super.onResume()
        hub.resume()
    }

    override fun onDestroy() {
        if (isFinishing) {
            hub.destroyAll()
            (application as App).hub = null
        }
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        intent ?: return
        val app = application as App
        when (intent.action) {
            Intent.ACTION_SEND -> {
                val stream = streamOf(intent)
                val text = intent.getStringExtra(Intent.EXTRA_TEXT)
                if (stream != null && intent.type?.startsWith("text/") != true) {
                    // Vidéo / fichier partagé depuis Telegram, WhatsApp, la galerie… : copié dans DLTurbo.
                    importShared(this, app, listOf(stream))
                } else if (!text.isNullOrBlank()) {
                    pendingText.value = text
                } else if (stream != null) {
                    importShared(this, app, listOf(stream))
                }
            }

            Intent.ACTION_SEND_MULTIPLE -> {
                val list = streamsOf(intent)
                if (list.isNotEmpty()) importShared(this, app, list)
            }

            Intent.ACTION_VIEW -> {
                val data = intent.data ?: return
                when (data.scheme?.lowercase()) {
                    "magnet", "http", "https" -> pendingText.value = data.toString()
                    "content", "file" -> {
                        val ok = addTorrentFromUri(this, app, data)
                        Toast.makeText(
                            this,
                            if (ok) "Torrent ajouté" else "Impossible de lire ce fichier .torrent",
                            Toast.LENGTH_SHORT,
                        ).show()
                    }
                }
            }
        }
    }
}

@Suppress("DEPRECATION")
private fun streamOf(intent: Intent): Uri? =
    if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
    else intent.getParcelableExtra(Intent.EXTRA_STREAM) as? Uri

@Suppress("DEPRECATION")
private fun streamsOf(intent: Intent): List<Uri> =
    (if (Build.VERSION.SDK_INT >= 33) intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
    else intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM))?.filterNotNull() ?: emptyList()

/** Fichiers partagés par une autre application : un .torrent devient un torrent, le reste est copié. */
private fun importShared(activity: ComponentActivity, app: App, uris: List<Uri>) {
    var torrents = 0
    var files = 0
    for (uri in uris) {
        var name: String? = null
        var size = -1L
        runCatching {
            activity.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)
                ?.use { c ->
                    if (c.moveToFirst()) {
                        name = c.getString(0)
                        if (!c.isNull(1)) size = c.getLong(1)
                    }
                }
        }
        val mime = activity.contentResolver.getType(uri)
        if (name?.endsWith(".torrent", ignoreCase = true) == true || mime == "application/x-bittorrent") {
            if (addTorrentFromUri(activity, app, uri)) torrents++
        } else {
            app.manager.importShared(uri, name, mime, size)
            files++
        }
    }
    val msg = buildList {
        if (files > 0) add("$files fichier(s) ajouté(s) aux téléchargements")
        if (torrents > 0) add("$torrents torrent(s) ajouté(s)")
    }.joinToString(" · ").ifBlank { "Aucun fichier reçu" }
    Toast.makeText(activity, msg, Toast.LENGTH_SHORT).show()
}

/** Lit un fichier .torrent choisi par l'utilisateur et l'ajoute à la file. */
fun addTorrentFromUri(context: Context, app: App, uri: Uri): Boolean {
    return try {
        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return false
        if (bytes.isEmpty() || bytes.size > 30 * 1024 * 1024) return false
        var name = "Torrent"
        runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0)?.let { name = it }
            }
        }
        app.manager.enqueueTorrentFile(bytes, name)
        true
    } catch (_: Exception) {
        false
    }
}

@Composable
private fun AppRoot(app: App, hub: WebHub, pendingText: MutableState<String?>, inPip: Boolean) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var settingsOpen by rememberSaveable { mutableStateOf(false) }

    // Autorisations demandées une fois au premier lancement.
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { }
    LaunchedEffect(Unit) {
        val wanted = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) wanted.add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.Q) wanted.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        val missing = wanted.filter {
            ContextCompat.checkSelfPermission(app, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) permissionLauncher.launch(missing.toTypedArray())
    }

    // Un lien partagé ouvre l'onglet Téléchargements (où s'affiche la fenêtre d'ajout).
    val shared = pendingText.value
    LaunchedEffect(shared) { if (shared != null) { tab = 0; settingsOpen = false } }

    // Demandes venant du navigateur (ex. nouvel onglet) ou du gestionnaire (ouvrir un dossier).
    val requestedTab by hub.requestTab
    LaunchedEffect(requestedTab) {
        requestedTab?.let { tab = it; hub.requestTab.value = null }
    }
    val folder by app.openFolder.collectAsState()
    LaunchedEffect(folder) { if (folder != null) { tab = 3; settingsOpen = false } }

    val viewer by app.viewer.collectAsState()
    val fullscreen by hub.fullscreen
    // Pastille : téléchargements en cours / en file d'attente.
    val downloads by app.manager.repo.items.collectAsState()
    val activeCount = downloads.count { it.status.isActive }
    val formatUrl by hub.formatRequest

    BackHandler(enabled = true) {
        when {
            fullscreen -> hub.exitFullscreen()
            viewer != null -> app.viewer.value = null
            settingsOpen -> settingsOpen = false
            tab == 1 && hub.yt.mode == 0 && hub.yt.closePlaylist() -> Unit
            tab == 1 && hub.yt.mode == 1 && hub.youtube.canGoBack -> hub.youtube.webView.goBack()
            tab == 1 && hub.yt.mode == 1 -> hub.yt.mode = 0
            tab == 2 && hub.current?.canGoBack == true -> hub.current?.webView?.goBack()
            tab != 0 -> tab = 0
            else -> Unit
        }
    }

    Box(Modifier.fillMaxSize()) {
        if (settingsOpen) {
            SettingsScreen(app = app, onBack = { settingsOpen = false })
        } else {
            Scaffold(
                contentWindowInsets = WindowInsets(0, 0, 0, 0),
                bottomBar = {
                    if (!fullscreen) NavigationBar {
                        NavItem("Téléchargements", Icons.Filled.CloudDownload, tab == 0, badge = activeCount) { tab = 0 }
                        NavItem("YouTube", Icons.Filled.PlayCircle, tab == 1) { tab = 1 }
                        NavItem("Navigateur", Icons.Filled.Language, tab == 2) { tab = 2 }
                        NavItem("Fichiers", Icons.Filled.Folder, tab == 3) { tab = 3 }
                        NavItem("Torrents", Icons.Filled.SwapVert, tab == 4) { tab = 4 }
                    }
                },
            ) { padding ->
                Column(Modifier.fillMaxSize().padding(padding)) {
                    CrawlBanner(hub)
                    Box(Modifier.weight(1f).fillMaxWidth()) {
                        when (tab) {
                            0 -> DownloadsScreen(app, pendingText, onOpenSettings = { settingsOpen = true })
                            1 -> YouTubeScreen(app, hub)
                            2 -> BrowserScreen(app, hub, onOpenYoutube = { tab = 1 })
                            4 -> TorrentsScreen(app)
                            else -> FilesScreen(app, onOpenSettings = { settingsOpen = true })
                        }
                    }
                }
            }
        }

        // Lecteurs et visionneuses par-dessus tout le reste.
        viewer?.let { v ->
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                val close = { app.viewer.value = null }
                when (v) {
                    is ViewerRequest.Media -> MediaScreen(v.files, v.index, inPip, close)
                    is ViewerRequest.Images -> ImageViewerScreen(v.files, v.index, close)
                    is ViewerRequest.WebFile -> WebFileScreen(v.file, close)
                    is ViewerRequest.TextFile -> TextFileScreen(v.file, close)
                    is ViewerRequest.Archive -> ArchiveScreen(app, v.file, close)
                }
            }
        }
    }

    formatUrl?.let { url ->
        FormatSheet(app, url, onDismiss = { hub.formatRequest.value = null })
    }
    HitDialog(app, hub)

    hub.mediaSheet.value?.let { tab -> MediaSheet(hub, tab, onDismiss = { hub.mediaSheet.value = null }) }
    hub.episodes.value?.let { list -> EpisodesSheet(hub, list, onDismiss = { hub.episodes.value = null }) }
    hub.images.value?.let { list -> ImagesSheet(app, hub, list, onDismiss = { hub.images.value = null }) }
    if (hub.waitOpen.value) WaitListSheet(hub, onDismiss = { hub.waitOpen.value = false })
}

@Composable
private fun RowScope.NavItem(
    label: String, icon: ImageVector, selected: Boolean, badge: Int = 0, onClick: () -> Unit,
) {
    NavigationBarItem(
        selected = selected,
        onClick = onClick,
        icon = {
            if (badge > 0) {
                BadgedBox(badge = { Badge { Text(if (badge > 99) "99+" else badge.toString()) } }) {
                    Icon(icon, contentDescription = "$label ($badge en cours)")
                }
            } else {
                Icon(icon, contentDescription = label)
            }
        },
        label = { Text(label, maxLines = 1, style = MaterialTheme.typography.labelSmall) },
    )
}
