package com.safeemail.keeper
import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

data class Key(val text: String, val used: Boolean = false)
data class Account(val id: String = UUID.randomUUID().toString(), val email: String, val password: String,
    val phone: String = "", val keys: List<Key> = emptyList(), val methods: List<String> = emptyList())
data class Log(val time: String, val text: String)

class Store(ctx: Context) {
    private val sp = EncryptedSharedPreferences.create(ctx, "vault",
        MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)

    fun accounts(): List<Account> = JSONArray(sp.getString("acc", "[]")).let { a ->
        (0 until a.length()).map { val o = a.getJSONObject(it)
            Account(o.getString("id"), o.getString("email"), o.getString("pwd"), o.getString("phone"),
                o.getJSONArray("keys").let { k -> (0 until k.length()).map { i -> Key(k.getJSONObject(i).getString("t"), k.getJSONObject(i).getBoolean("u")) } },
                o.getJSONArray("m").let { m -> (0 until m.length()).map { i -> m.getString(i) } }) } }

    fun save(list: List<Account>) = sp.edit().putString("acc", JSONArray(list.map { a -> JSONObject()
        .put("id", a.id).put("email", a.email).put("pwd", a.password).put("phone", a.phone)
        .put("keys", JSONArray(a.keys.map { JSONObject().put("t", it.text).put("u", it.used) }))
        .put("m", JSONArray(a.methods)) }).toString()).apply()

    fun logs(): List<Log> = JSONArray(sp.getString("log", "[]")).let { a ->
        (0 until a.length()).map { Log(a.getJSONObject(it).getString("t"), a.getJSONObject(it).getString("x")) } }

    fun log(text: String) {
        val t = SimpleDateFormat("dd/MM HH:mm", Locale.FRANCE).format(Date())
        val l = (listOf(Log(t, text)) + logs()).take(200)
        sp.edit().putString("log", JSONArray(l.map { JSONObject().put("t", it.time).put("x", it.text) }).toString()).apply()
    }
}
