package com.safeemail.keeper
import android.app.*
import android.content.Context
import android.content.Intent
import android.net.Uri

object Notifier {
    private const val CH = "downloads"
    fun done(ctx: Context, uri: Uri, mime: String, name: String, path: String) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Téléchargements", NotificationManager.IMPORTANCE_DEFAULT))
        val open = if (mime == "application/pdf")
            Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        else Intent(DownloadManager.ACTION_VIEW_DOWNLOADS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pi = PendingIntent.getActivity(ctx, name.hashCode(), open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(ctx, CH).setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("Téléchargement terminé").setContentText(name)
            .setStyle(Notification.BigTextStyle().bigText(path)).setContentIntent(pi).setAutoCancel(true).build()
        try { nm.notify(name.hashCode(), n) } catch (_: SecurityException) {}
    }
}
