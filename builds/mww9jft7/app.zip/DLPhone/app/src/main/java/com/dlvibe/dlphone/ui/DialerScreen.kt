@file:OptIn(ExperimentalFoundationApi::class)

package com.dlvibe.dlphone.ui

import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import android.provider.ContactsContract
import android.widget.Toast
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dlvibe.dlphone.Contact
import com.dlvibe.dlphone.Prefs
import com.dlvibe.dlphone.T9

val KEYS = listOf(
    '1' to "∞", '2' to "ABC", '3' to "DEF",
    '4' to "GHI", '5' to "JKL", '6' to "MNO",
    '7' to "PQRS", '8' to "TUV", '9' to "WXYZ",
    '*' to "", '0' to "+", '#' to ""
)

fun toneFor(ch: Char): Int = when (ch) {
    in '0'..'9' -> ToneGenerator.TONE_DTMF_0 + (ch - '0')
    '*' -> ToneGenerator.TONE_DTMF_S
    '#' -> ToneGenerator.TONE_DTMF_P
    else -> ToneGenerator.TONE_DTMF_0
}

@Composable
fun Keypad(onPress: (Char) -> Unit, onLong: (Char) -> Unit = {}) {
    val p = LocalPalette.current
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        KEYS.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                row.forEach { (d, letters) ->
                    Column(
                        Modifier
                            .size(width = 86.dp, height = 60.dp)
                            .clip(RoundedCornerShape(30.dp))
                            .background(p.surface2.copy(alpha = 0.6f))
                            .combinedClickable(onClick = { onPress(d) }, onLongClick = { onLong(d) }),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(d.toString(), fontSize = 27.sp, color = p.text)
                        if (letters.isNotEmpty()) Text(letters, fontSize = 10.sp, color = p.muted, letterSpacing = 1.5.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun DialerScreen(
    contacts: List<Contact>,
    prefill: String,
    navKey: Int,
    lastNumber: String?,
    onCall: (String) -> Unit
) {
    val ctx = LocalContext.current
    val p = LocalPalette.current
    val haptic = LocalHapticFeedback.current
    var number by remember { mutableStateOf("") }
    LaunchedEffect(navKey) { if (prefill.isNotEmpty()) number = prefill }

    val tone = remember { runCatching { ToneGenerator(AudioManager.STREAM_DTMF, 70) }.getOrNull() }
    DisposableEffect(Unit) { onDispose { tone?.release() } }

    val matches = remember(number, contacts) {
        if (number.isEmpty()) emptyList() else contacts.filter { T9.matches(it.name, it.number, number) }.take(40)
    }

    fun press(ch: Char) {
        number += ch
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        runCatching { tone?.startTone(toneFor(ch), 120) }
    }

    fun longPress(d: Char) {
        when (d) {
            '0' -> {
                number += "+"
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            }

            '1' -> onCall("voicemail")
            in '2'..'9' -> {
                val slot = d - '0'
                val saved = Prefs.speedDial(slot)
                when {
                    saved != null -> onCall(saved)
                    number.isNotBlank() -> {
                        Prefs.setSpeedDial(slot, number)
                        Toast.makeText(ctx, "✨ Touche $slot → $number", Toast.LENGTH_SHORT).show()
                    }

                    else -> Toast.makeText(ctx, "Tapez un numéro puis restez appuyé sur $slot pour l'enregistrer", Toast.LENGTH_LONG).show()
                }
            }

            else -> press(d)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 18.dp)
    ) {
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            if (matches.isEmpty()) {
                Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Téléphone ✦", color = p.accent, fontSize = 30.sp, fontWeight = FontWeight.Black)
                    Text(
                        if (number.isEmpty()) "Tapez un numéro ou un nom (T9)" else "Aucun contact correspondant",
                        color = p.muted, fontSize = 13.sp
                    )
                }
            } else {
                LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(vertical = 6.dp)) {
                    items(matches, key = { "${it.id}-${it.number}" }) { c ->
                        ListRow(
                            title = c.name,
                            leading = { Avatar(c.name, 40.dp, photo = c.photo, number = c.number) },
                            subtitle = { Text(c.number, color = p.muted, fontSize = 13.sp) },
                            onClick = { onCall(c.number) },
                            onLongClick = { number = c.number }
                        )
                    }
                }
            }
        }

        Text(
            number,
            fontSize = when {
                number.length > 16 -> 22.sp
                number.length > 11 -> 29.sp
                else -> 36.sp
            },
            color = p.text,
            fontWeight = FontWeight.Light,
            maxLines = 1,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp)
                .height(48.dp)
        )

        Keypad(onPress = ::press, onLong = ::longPress)

        Row(
            Modifier
                .fillMaxWidth()
                .padding(vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .clickable(enabled = number.isNotEmpty()) {
                        runCatching {
                            ctx.startActivity(
                                Intent(Intent.ACTION_INSERT, ContactsContract.Contacts.CONTENT_URI)
                                    .putExtra(ContactsContract.Intents.Insert.PHONE, number)
                            )
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.PersonAdd, "Ajouter", tint = if (number.isNotEmpty()) p.muted else Color.Transparent)
            }
            Box(
                Modifier
                    .size(70.dp)
                    .clip(CircleShape)
                    .background(Brush.verticalGradient(listOf(p.accent, p.accent.copy(alpha = 0.8f))))
                    .clickable {
                        if (number.isNotEmpty()) onCall(number)
                        else if (!lastNumber.isNullOrBlank()) number = lastNumber // ✨ Rappel du dernier numéro
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.Call, "Appeler", tint = p.onAccent, modifier = Modifier.size(30.dp))
            }
            Box(
                Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .combinedClickable(
                        onClick = { number = number.dropLast(1) },
                        onLongClick = { number = "" }
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.Backspace, "Effacer", tint = if (number.isNotEmpty()) p.muted else Color.Transparent)
            }
        }
    }
}
