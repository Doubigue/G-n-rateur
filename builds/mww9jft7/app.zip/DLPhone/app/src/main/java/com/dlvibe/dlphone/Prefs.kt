package com.dlvibe.dlphone

import android.content.Context
import android.content.SharedPreferences

/** Réglages de DL Phone (fonctions magiques, liste noire, numérotation rapide…). */
object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(context: Context) {
        if (!::sp.isInitialized) {
            sp = context.applicationContext.getSharedPreferences("dl_phone", Context.MODE_PRIVATE)
        }
    }

    private fun getB(key: String, def: Boolean): Boolean = sp.getBoolean(key, def)
    private fun putB(key: String, v: Boolean) {
        sp.edit().putBoolean(key, v).apply()
    }

    var flash: Boolean
        get() = getB("flash", true)
        set(v) = putB("flash", v)

    var announce: Boolean
        get() = getB("announce", true)
        set(v) = putB("announce", v)

    var flipToSilence: Boolean
        get() = getB("flip", true)
        set(v) = putB("flip", v)

    var vibrateOnConnect: Boolean
        get() = getB("vibrate_connect", true)
        set(v) = putB("vibrate_connect", v)

    var missedNotif: Boolean
        get() = getB("missed_notif", true)
        set(v) = putB("missed_notif", v)

    var blockHidden: Boolean
        get() = getB("block_hidden", false)
        set(v) = putB("block_hidden", v)

    var blockUnknown: Boolean
        get() = getB("block_unknown", false)
        set(v) = putB("block_unknown", v)

    var crescendo: Boolean
        get() = getB("crescendo", true)
        set(v) = putB("crescendo", v)

    var vibrateRing: Boolean
        get() = getB("vibrate_ring", true)
        set(v) = putB("vibrate_ring", v)

    var videoDuringCall: Boolean
        get() = getB("video_during_call", false)
        set(v) = putB("video_during_call", v)

    var island: Boolean
        get() = getB("island", true)
        set(v) = putB("island", v)

    /** Caméra couverte pendant la sonnerie : 0 rien, 1 silence, 2 répondre, 3 refuser. */
    var coverAction: Int
        get() = sp.getInt("cover_action", 1)
        set(v) {
            sp.edit().putInt("cover_action", v).apply()
        }

    // --- Messages ---
    var smsNotif: Boolean
        get() = getB("sms_notif", true)
        set(v) = putB("sms_notif", v)

    var smsAnnounce: Boolean
        get() = getB("sms_announce", false)
        set(v) = putB("sms_announce", v)

    var smsHideBlocked: Boolean
        get() = getB("sms_hide_blocked", true)
        set(v) = putB("sms_hide_blocked", v)

    var autoReply: Boolean
        get() = getB("auto_reply", false)
        set(v) = putB("auto_reply", v)

    var autoReplyText: String
        get() = sp.getString("auto_reply_text", null) ?: "Je ne suis pas disponible pour le moment, je vous réponds dès que possible."
        set(v) {
            sp.edit().putString("auto_reply_text", v).apply()
        }

    var smsSignature: String
        get() = sp.getString("sms_signature", "") ?: ""
        set(v) {
            sp.edit().putString("sms_signature", v).apply()
        }

    var splash: Boolean
        get() = getB("splash", true)
        set(v) = putB("splash", v)

    var randomStyle: Boolean
        get() = getB("random_style", false)
        set(v) = putB("random_style", v)

    var askedDefault: Boolean
        get() = getB("asked_default", false)
        set(v) = putB("asked_default", v)

    var style: Int
        get() = sp.getInt("style", 0)
        set(v) {
            sp.edit().putInt("style", v).apply()
        }

    var blockedCount: Int
        get() = sp.getInt("blocked_count", 0)
        set(v) {
            sp.edit().putInt("blocked_count", v).apply()
        }

    /** Clé de comparaison d'un numéro : les 9 derniers chiffres (ignore +225, 0, espaces…). */
    fun norm(n: String?): String = (n ?: "").filter { it.isDigit() }.takeLast(9)

    fun blacklist(): List<String> = sp.getStringSet("blacklist", emptySet())?.sorted() ?: emptyList()

    /** Accepte aussi les préfixes : « +234* » bloque tous les numéros qui commencent par +234. */
    fun isBlocked(n: String?): Boolean {
        val digits = (n ?: "").filter { it.isDigit() }
        val k = norm(n)
        if (k.length < 3) return false
        return blacklist().any { entry ->
            if (entry.trim().endsWith("*")) {
                val pre = entry.filter { it.isDigit() }
                pre.isNotEmpty() && (digits.startsWith(pre) || digits.startsWith("00$pre"))
            } else norm(entry) == k
        }
    }

    fun block(n: String) {
        val s = blacklist().toMutableSet()
        s.add(n.trim())
        sp.edit().putStringSet("blacklist", s).apply()
    }

    fun unblock(n: String) {
        val k = norm(n)
        val s = blacklist().filter { it != n && (it.trim().endsWith("*") || norm(it) != k) }.toSet()
        sp.edit().putStringSet("blacklist", s).apply()
    }

    val DEFAULT_REPLIES = listOf(
        "Je ne peux pas répondre, je te rappelle.",
        "Je suis en réunion, envoie-moi un message.",
        "Je conduis, je te rappelle plus tard.",
        "J'arrive dans 5 minutes."
    )

    fun quickReplies(): List<String> {
        val raw = sp.getString("replies", null) ?: return DEFAULT_REPLIES
        return raw.split("\n").filter { it.isNotBlank() }
    }

    fun setQuickReplies(list: List<String>) {
        sp.edit().putString("replies", list.joinToString("\n")).apply()
    }

    fun speedDial(d: Int): String? = sp.getString("sd_$d", null)

    fun setSpeedDial(d: Int, n: String?) {
        val e = sp.edit()
        if (n == null) e.remove("sd_$d") else e.putString("sd_$d", n)
        e.apply()
    }
}
