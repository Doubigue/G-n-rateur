package com.dlvibe.dlphone

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.telecom.Call
import android.util.LruCache
import android.webkit.MimeTypeMap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.InputStream

/** Thème d'appel lié à un numéro : vidéo, sonnerie, photo, note, VIP. */
data class CallTheme(
    val key: String,
    val number: String,
    val label: String? = null,
    val video: String? = null,
    val sound: String? = null,
    val photo: String? = null,
    val useVideoSound: Boolean = false,
    val vip: Boolean = false,
    val note: String? = null
) {
    fun toJson(): String = JSONObject().apply {
        put("key", key)
        put("number", number)
        putOpt("label", label)
        putOpt("video", video)
        putOpt("sound", sound)
        putOpt("photo", photo)
        put("useVideoSound", useVideoSound)
        put("vip", vip)
        putOpt("note", note)
    }.toString()

    /** Source audio de la sonnerie (fichier) ou null = sonnerie du téléphone. */
    fun ringSource(): String? = if (useVideoSound && video != null) video else sound

    companion object {
        private fun JSONObject.str(k: String): String? = if (has(k) && !isNull(k)) getString(k) else null

        fun fromJson(s: String): CallTheme? = try {
            val o = JSONObject(s)
            CallTheme(
                key = o.getString("key"),
                number = o.optString("number", ""),
                label = o.str("label"),
                video = o.str("video"),
                sound = o.str("sound"),
                photo = o.str("photo"),
                useVideoSound = o.optBoolean("useVideoSound", false),
                vip = o.optBoolean("vip", false),
                note = o.str("note")
            )
        } catch (_: Exception) {
            null
        }
    }
}

object CallThemes {
    const val DEFAULT_KEY = "_default"

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences("dl_themes", Context.MODE_PRIVATE)

    fun keyFor(number: String?): String = Prefs.norm(number)

    fun all(c: Context): List<CallTheme> =
        sp(c).all.values.mapNotNull { v -> (v as? String)?.let { CallTheme.fromJson(it) } }
            .sortedBy { (it.label ?: it.number).lowercase() }

    fun byKey(c: Context, key: String): CallTheme? = sp(c).getString(key, null)?.let { CallTheme.fromJson(it) }

    fun get(c: Context, number: String?): CallTheme? {
        val k = keyFor(number)
        if (k.length < 3) return null
        return byKey(c, k)
    }

    fun default(c: Context): CallTheme? = byKey(c, DEFAULT_KEY)

    /** Thème du numéro, complété par le thème par défaut (vidéo / sonnerie pour tous). */
    fun forCall(c: Context, number: String?): CallTheme? {
        val t = get(c, number)
        val d = default(c)
        if (t == null && d == null) return null
        val ownVideo = t != null && (t.video != null || t.useVideoSound)
        return CallTheme(
            key = t?.key ?: DEFAULT_KEY,
            number = number ?: "",
            label = t?.label,
            video = t?.video ?: d?.video,
            sound = t?.sound ?: (if (t?.useVideoSound == true) null else d?.sound),
            photo = t?.photo,
            useVideoSound = if (ownVideo) t!!.useVideoSound else (d?.useVideoSound ?: false),
            vip = t?.vip ?: false,
            note = t?.note
        )
    }

    fun save(c: Context, t: CallTheme) {
        sp(c).edit().putString(t.key, t.toJson()).apply()
        PhotoLoader.clear()
    }

    fun removeKey(c: Context, key: String) {
        sp(c).edit().remove(key).apply()
    }

    fun delete(c: Context, key: String) {
        val t = byKey(c, key)
        removeKey(c, key)
        t?.let { listOf(it.video, it.sound, it.photo).forEach { p -> deleteIfUnused(c, p) } }
        PhotoLoader.clear()
    }

    /** Copie le fichier choisi dans l'appli : il reste disponible même si l'original est déplacé. */
    fun importFile(c: Context, uri: Uri, kind: String): String? {
        val dir = File(c.filesDir, "call_themes").apply { mkdirs() }
        val mime = c.contentResolver.getType(uri)
        val ext = mime?.let { MimeTypeMap.getSingleton().getExtensionFromMimeType(it) } ?: when (kind) {
            "video" -> "mp4"
            "audio" -> "mp3"
            else -> "jpg"
        }
        val f = File(dir, "${kind}_${System.currentTimeMillis()}.$ext")
        val ok = c.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) }; true } ?: false
        return if (ok) f.absolutePath else null
    }

    fun deleteIfUnused(c: Context, path: String?) {
        if (path == null) return
        if (all(c).none { it.video == path || it.sound == path || it.photo == path }) runCatching { File(path).delete() }
    }
}

/** Charge les photos (thème, contact) avec un petit cache mémoire. */
object PhotoLoader {
    private val cache = LruCache<String, ImageBitmap>(120)
    private val misses = HashSet<String>()
    var version by mutableIntStateOf(0)

    fun key(number: String?, photo: String?, px: Int, lookup: Boolean) = "$number|$photo|$px|$lookup"

    fun cached(k: String): ImageBitmap? = cache.get(k)

    fun clearMisses() {
        synchronized(misses) { misses.clear() }
    }

    fun clear() {
        cache.evictAll()
        synchronized(misses) { misses.clear() }
        version++
    }

    fun load(ctx: Context, number: String?, photo: String?, px: Int, lookup: Boolean): ImageBitmap? {
        val k = key(number, photo, px, lookup)
        cache.get(k)?.let { return it }
        if (synchronized(misses) { k in misses }) return null
        val src = CallThemes.get(ctx, number)?.photo
            ?: photo
            ?: if (lookup) ContactsRepo.photoFor(ctx, number) else null
        val bmp = src?.let { decode(ctx, it, px) }
        if (bmp != null) cache.put(k, bmp) else synchronized(misses) { misses.add(k) }
        return bmp
    }

    private fun open(ctx: Context, src: String): InputStream? =
        if (src.contains("://")) ctx.contentResolver.openInputStream(Uri.parse(src))
        else FileInputStream(File(src))

    fun decode(ctx: Context, src: String, px: Int): ImageBitmap? = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        open(ctx, src)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= px && bounds.outHeight / (sample * 2) >= px) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        open(ctx, src)?.use { BitmapFactory.decodeStream(it, null, opts) }?.asImageBitmap()
    } catch (_: Throwable) {
        null
    }
}

/** Sonnerie gérée par DL Phone : son par numéro, son de la vidéo, VIP, montée progressive. */
object Ringer {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var player: MediaPlayer? = null
    private var fallback: Ringtone? = null
    private var vibrator: Vibrator? = null
    private var rampJob: Job? = null

    fun start(ctx: Context, number: String, preview: Boolean = false) {
        stop()
        val app = ctx.applicationContext
        val theme = CallThemes.forCall(app, number)
        val vip = theme?.vip == true
        if (!preview) {
            val busy = CallManager.calls.value.any {
                val s = CallManager.stateOf(it)
                s == Call.STATE_ACTIVE || s == Call.STATE_HOLDING || s == Call.STATE_DIALING
            }
            if (busy) { // double appel : simple vibration
                vibrate(app, repeat = false)
                return
            }
            val nm = app.getSystemService(NotificationManager::class.java)
            val dnd = nm != null && nm.currentInterruptionFilter > NotificationManager.INTERRUPTION_FILTER_ALL
            if (dnd && !vip) return
        }
        val mode = app.getSystemService(AudioManager::class.java)?.ringerMode ?: AudioManager.RINGER_MODE_NORMAL
        if (Prefs.vibrateRing && (mode != AudioManager.RINGER_MODE_SILENT || vip)) vibrate(app, repeat = true)
        if (mode == AudioManager.RINGER_MODE_NORMAL || vip || preview) playSound(app, theme?.ringSource(), vip)
    }

    private fun playSound(app: Context, src: String?, vip: Boolean) {
        val uri: Uri = src?.let { Uri.fromFile(File(it)) }
            ?: RingtoneManager.getActualDefaultRingtoneUri(app, RingtoneManager.TYPE_RINGTONE)
            ?: Settings.System.DEFAULT_RINGTONE_URI
        val usage = if (vip) AudioAttributes.USAGE_ALARM else AudioAttributes.USAGE_NOTIFICATION_RINGTONE
        try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder().setUsage(usage).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            )
            mp.setDataSource(app, uri)
            mp.isLooping = true
            mp.setOnPreparedListener {
                if (player === it) {
                    if (Prefs.crescendo) ramp(it) else it.setVolume(1f, 1f)
                    it.start()
                }
            }
            mp.setOnErrorListener { _, _, _ ->
                playFallback(app)
                true
            }
            player = mp
            mp.prepareAsync()
        } catch (_: Exception) {
            playFallback(app)
        }
    }

    /** 📈 Sonnerie progressive : commence doucement puis monte. */
    private fun ramp(mp: MediaPlayer) {
        rampJob?.cancel()
        rampJob = scope.launch {
            var v = 0.12f
            while (v < 1f) {
                runCatching { mp.setVolume(v, v) }
                delay(1000)
                v += 0.08f
            }
            runCatching { mp.setVolume(1f, 1f) }
        }
    }

    private fun playFallback(app: Context) {
        try {
            player?.release()
            player = null
            val r = RingtoneManager.getRingtone(app, Settings.System.DEFAULT_RINGTONE_URI) ?: return
            if (Build.VERSION.SDK_INT >= 28) r.isLooping = true
            r.play()
            fallback = r
        } catch (_: Exception) {
        }
    }

    @Suppress("DEPRECATION")
    private fun vibrate(app: Context, repeat: Boolean) {
        val v: Vibrator? = if (Build.VERSION.SDK_INT >= 31) {
            app.getSystemService(VibratorManager::class.java)?.defaultVibrator
        } else {
            app.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
        vibrator = v
        val effect = if (repeat) VibrationEffect.createWaveform(longArrayOf(0, 900, 700), 0)
        else VibrationEffect.createWaveform(longArrayOf(0, 200, 150, 200), -1)
        runCatching {
            v?.vibrate(
                effect,
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE).build()
            )
        }
    }

    fun stop() {
        rampJob?.cancel()
        rampJob = null
        player?.let { runCatching { it.stop() }; runCatching { it.release() } }
        player = null
        fallback?.let { runCatching { it.stop() } }
        fallback = null
        vibrator?.let { runCatching { it.cancel() } }
        vibrator = null
    }
}

/** Raccourcis sur l'écran d'accueil : appui long sur l'icône = appeler vos contacts préférés. */
object Shortcuts {
    fun update(ctx: Context, calls: List<CallEntry>) {
        try {
            val top = calls.filter { it.number.isNotBlank() }
                .groupBy { Prefs.norm(it.number) }
                .map { (_, l) -> l.first() to l.size }
                .sortedByDescending { it.second }
                .take(3)
            val list = top.mapIndexed { i, (e, _) ->
                val label = e.name ?: e.number
                ShortcutInfoCompat.Builder(ctx, "call_$i")
                    .setShortLabel(label.take(20))
                    .setLongLabel("Appeler $label")
                    .setIcon(IconCompat.createWithResource(ctx, R.mipmap.ic_launcher))
                    .setIntent(
                        Intent(ctx, MainActivity::class.java)
                            .setAction(Intent.ACTION_VIEW)
                            .putExtra(MainActivity.EXTRA_CALL, e.number)
                    )
                    .build()
            }
            ShortcutManagerCompat.setDynamicShortcuts(ctx, list)
        } catch (_: Exception) {
        }
    }
}
