package com.dlvibe.dlphone.sms

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.Telephony
import com.dlvibe.dlphone.ContactsRepo
import com.dlvibe.dlphone.Prefs

data class SmsMsg(
    val id: Long,
    val threadId: Long,
    val address: String,
    val body: String,
    val date: Long,
    val type: Int,
    val read: Boolean,
    val status: Int,
    val isMms: Boolean = false,
    val parts: List<MmsPart> = emptyList()
) {
    val outgoing: Boolean get() = type != Telephony.Sms.MESSAGE_TYPE_INBOX
}

data class Conversation(
    val threadId: Long,
    val address: String,
    val name: String?,
    val snippet: String,
    val date: Long,
    val unread: Int,
    val lastOutgoing: Boolean
)

object SmsRepo {
    private val PROJ = arrayOf(
        Telephony.Sms._ID, Telephony.Sms.THREAD_ID, Telephony.Sms.ADDRESS, Telephony.Sms.BODY,
        Telephony.Sms.DATE, Telephony.Sms.TYPE, Telephony.Sms.READ, Telephony.Sms.STATUS
    )

    fun canRead(c: Context) = ContactsRepo.granted(c, Manifest.permission.READ_SMS)

    fun isDefault(c: Context): Boolean =
        runCatching { Telephony.Sms.getDefaultSmsPackage(c) == c.packageName }.getOrDefault(false)

    private fun read(c: Context, selection: String?, args: Array<String>?, order: String, limit: Int): List<SmsMsg> {
        if (!canRead(c)) return emptyList()
        val out = ArrayList<SmsMsg>()
        try {
            c.contentResolver.query(Telephony.Sms.CONTENT_URI, PROJ, selection, args, order)?.use { cur ->
                while (cur.moveToNext() && out.size < limit) {
                    out += SmsMsg(
                        id = cur.getLong(0),
                        threadId = cur.getLong(1),
                        address = cur.getString(2) ?: "",
                        body = cur.getString(3) ?: "",
                        date = cur.getLong(4),
                        type = cur.getInt(5),
                        read = cur.getInt(6) == 1,
                        status = if (cur.isNull(7)) -1 else cur.getInt(7)
                    )
                }
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun conversations(c: Context): List<Conversation> {
        val all = read(c, null, null, Telephony.Sms.DATE + " DESC", 6000)
        val byThread = LinkedHashMap<Long, MutableList<SmsMsg>>()
        all.forEach { m -> byThread.getOrPut(m.threadId) { mutableListOf() }.add(m) }
        val names = HashMap<String, String?>()
        val mms = MmsRepo.latestPerThread(c)
        val result = LinkedHashMap<Long, Conversation>()
        byThread.forEach { (tid, list) ->
            val last = list.first()
            val key = Prefs.norm(last.address)
            val name = names.getOrPut(key) { ContactsRepo.nameFor(c, last.address) }
            result[tid] = Conversation(
                threadId = tid,
                address = last.address,
                name = name,
                snippet = last.body,
                date = last.date,
                unread = list.count { !it.read && !it.outgoing },
                lastOutgoing = last.outgoing
            )
        }
        // 📷 Fusion avec les MMS
        mms.forEach { (tid, pair) ->
            val (m, unread) = pair
            val snippet = listOfNotNull(
                if (m.parts.any { it.uri != null }) "📷 Photo" else null,
                m.body.takeIf { it.isNotBlank() }
            ).joinToString(" · ").ifBlank { "📩 MMS" }
            val existing = result[tid]
            if (existing == null) {
                if (m.address.isBlank()) return@forEach
                val name = names.getOrPut(Prefs.norm(m.address)) { ContactsRepo.nameFor(c, m.address) }
                result[tid] = Conversation(tid, m.address, name, snippet, m.date, unread, m.outgoing)
            } else {
                result[tid] = if (m.date > existing.date) existing.copy(
                    snippet = snippet, date = m.date, lastOutgoing = m.outgoing, unread = existing.unread + unread
                ) else existing.copy(unread = existing.unread + unread)
            }
        }
        return result.values.sortedByDescending { it.date }
    }

    fun threadIdFor(c: Context, address: String): Long? =
        runCatching { Telephony.Threads.getOrCreateThreadId(c, address) }.getOrNull()

    fun messages(c: Context, address: String): List<SmsMsg> {
        val tid = threadIdFor(c, address)
        val mms = if (tid != null) MmsRepo.forThread(c, tid, address) else emptyList()
        return (smsMessages(c, address, tid) + mms).sortedBy { it.date }
    }

    private fun smsMessages(c: Context, address: String, tid: Long?): List<SmsMsg> {
        var list = if (tid != null) read(c, Telephony.Sms.THREAD_ID + "=?", arrayOf(tid.toString()), Telephony.Sms.DATE + " ASC", 5000)
        else emptyList()
        if (list.isEmpty()) {
            val k = Prefs.norm(address)
            list = read(c, null, null, Telephony.Sms.DATE + " DESC", 8000)
                .filter { Prefs.norm(it.address) == k }
                .sortedBy { it.date }
        }
        return list
    }

    fun unreadCount(c: Context): Int {
        if (!canRead(c)) return 0
        return runCatching {
            c.contentResolver.query(
                Telephony.Sms.CONTENT_URI, arrayOf(Telephony.Sms._ID),
                Telephony.Sms.READ + "=0 AND " + Telephony.Sms.TYPE + "=" + Telephony.Sms.MESSAGE_TYPE_INBOX, null, null
            )?.use { it.count } ?: 0
        }.getOrDefault(0) + MmsRepo.unreadCount(c)
    }

    /** 🔎 Recherche dans le texte de tous les messages. */
    fun search(c: Context, q: String): List<SmsMsg> =
        if (q.isBlank()) emptyList()
        else read(c, Telephony.Sms.BODY + " LIKE ?", arrayOf("%$q%"), Telephony.Sms.DATE + " DESC", 200)

    // --- Écriture (seulement quand DL Phone est l'appli SMS par défaut) ---

    fun insertIncoming(c: Context, address: String, body: String, date: Long, subId: Int): Uri? {
        if (!isDefault(c)) return null
        return try {
            val v = ContentValues().apply {
                put(Telephony.Sms.ADDRESS, address)
                put(Telephony.Sms.BODY, body)
                put(Telephony.Sms.DATE, System.currentTimeMillis())
                put(Telephony.Sms.DATE_SENT, date)
                put(Telephony.Sms.READ, 0)
                put(Telephony.Sms.SEEN, 0)
                put(Telephony.Sms.TYPE, Telephony.Sms.MESSAGE_TYPE_INBOX)
                if (subId >= 0) put(Telephony.Sms.SUBSCRIPTION_ID, subId)
            }
            c.contentResolver.insert(Telephony.Sms.Inbox.CONTENT_URI, v)
        } catch (_: Exception) {
            null
        }
    }

    fun insertOutgoing(c: Context, address: String, body: String): Uri? {
        if (!isDefault(c)) return null
        return try {
            val v = ContentValues().apply {
                put(Telephony.Sms.ADDRESS, address)
                put(Telephony.Sms.BODY, body)
                put(Telephony.Sms.DATE, System.currentTimeMillis())
                put(Telephony.Sms.READ, 1)
                put(Telephony.Sms.SEEN, 1)
                put(Telephony.Sms.TYPE, Telephony.Sms.MESSAGE_TYPE_OUTBOX)
                put(Telephony.Sms.STATUS, Telephony.Sms.STATUS_PENDING)
            }
            c.contentResolver.insert(Telephony.Sms.CONTENT_URI, v)
        } catch (_: Exception) {
            null
        }
    }

    fun update(c: Context, uri: Uri, values: ContentValues) {
        if (!isDefault(c)) return
        runCatching { c.contentResolver.update(uri, values, null, null) }
    }

    fun markRead(c: Context, address: String) {
        if (!isDefault(c)) return
        val tid = threadIdFor(c, address) ?: return
        MmsRepo.markRead(c, tid)
        runCatching {
            c.contentResolver.update(
                Telephony.Sms.CONTENT_URI,
                ContentValues().apply { put(Telephony.Sms.READ, 1); put(Telephony.Sms.SEEN, 1) },
                Telephony.Sms.THREAD_ID + "=? AND " + Telephony.Sms.READ + "=0",
                arrayOf(tid.toString())
            )
        }
    }

    fun delete(c: Context, id: Long): Boolean {
        if (!isDefault(c)) return false
        return runCatching {
            c.contentResolver.delete(Uri.withAppendedPath(Telephony.Sms.CONTENT_URI, id.toString()), null, null) > 0
        }.getOrDefault(false)
    }

    fun deleteThread(c: Context, address: String): Boolean {
        if (!isDefault(c)) return false
        val tid = threadIdFor(c, address) ?: return false
        runCatching { c.contentResolver.delete(Uri.parse("content://mms"), "thread_id=?", arrayOf(tid.toString())) }
        return runCatching {
            c.contentResolver.delete(Telephony.Sms.CONTENT_URI, Telephony.Sms.THREAD_ID + "=?", arrayOf(tid.toString())) >= 0
        }.getOrDefault(false)
    }
}

/** 🔐 Détecte un code de vérification (OTP) dans un SMS. */
object OtpDetector {
    private val KEYWORDS = Regex(
        "(code|otp|v[ée]rification|verification|mot de passe|password|pin|confirm|connexion|login|s[ée]curit[ée]|validation)",
        RegexOption.IGNORE_CASE
    )
    private val CODE = Regex("(?<![\\d+])(\\d{4,8})(?!\\d)")

    fun find(body: String): String? {
        if (!KEYWORDS.containsMatchIn(body)) return null
        return CODE.find(body)?.groupValues?.get(1)
    }
}
