package com.dlvibe.dlphone.sms

import android.app.Activity
import android.app.PendingIntent
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.provider.Telephony
import android.widget.Toast
import androidx.core.content.FileProvider
import com.dlvibe.dlphone.Prefs
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.charset.Charset

/** Une pièce d'un MMS (texte ou image). */
data class MmsPart(val id: Long, val type: String, val text: String?, val uri: String?)

// =====================================================================
//  PDU MMS (WAP/WSP) : lecture et écriture minimales
// =====================================================================
object Pdu {
    const val SEND_REQ = 0x80
    const val NOTIFICATION_IND = 0x82
    const val RETRIEVE_CONF = 0x84

    data class Headers(
        var type: Int = 0,
        var tid: String? = null,
        var location: String? = null,
        var from: String? = null,
        var subject: String? = null,
        var date: Long = 0L,
        var contentType: String? = null
    )

    data class RawPart(val type: String, val charset: Int, val name: String?, val cid: String?, val data: ByteArray) {
        val isText: Boolean get() = type.startsWith("text/") || type == "application/smil"
        fun text(): String = String(data, charsetOf(charset)).trimEnd('\u0000')
    }

    private data class CType(val type: String, val charset: Int = 106, val name: String? = null)

    fun charsetOf(mib: Int): Charset = runCatching {
        when (mib) {
            3 -> Charsets.US_ASCII
            4 -> Charsets.ISO_8859_1
            1000, 1015 -> Charsets.UTF_16
            1013 -> Charsets.UTF_16BE
            1014 -> Charsets.UTF_16LE
            else -> Charsets.UTF_8
        }
    }.getOrDefault(Charsets.UTF_8)

    private fun wellKnown(i: Int): String = when (i) {
        0x00 -> "*/*"; 0x01 -> "text/*"; 0x02 -> "text/html"; 0x03 -> "text/plain"
        0x07 -> "text/x-vCard"; 0x08 -> "text/vnd.wap.wml"
        0x0C -> "multipart/mixed"; 0x0F -> "multipart/alternative"
        0x1C -> "image/*"; 0x1D -> "image/gif"; 0x1E -> "image/jpeg"; 0x1F -> "image/tiff"
        0x20 -> "image/png"; 0x21 -> "image/vnd.wap.wbmp"
        0x23 -> "application/vnd.wap.multipart.mixed"
        0x26 -> "application/vnd.wap.multipart.alternative"
        0x33 -> "application/vnd.wap.multipart.related"
        0x3E -> "application/vnd.wap.mms-message"
        else -> "application/octet-stream"
    }

    class Reader(private val b: ByteArray) {
        var pos = 0
        fun eof() = pos >= b.size
        fun u8(): Int = b[pos++].toInt() and 0xFF
        fun peek(): Int = b[pos].toInt() and 0xFF

        fun uintvar(): Int {
            var r = 0
            while (true) {
                val x = u8()
                r = (r shl 7) or (x and 0x7F)
                if (x and 0x80 == 0) return r
            }
        }

        fun text(cs: Charset = Charsets.UTF_8): String {
            val start = pos
            while (pos < b.size && b[pos].toInt() != 0) pos++
            var s = String(b, start, pos - start, cs)
            if (pos < b.size) pos++
            if (s.startsWith("\u007F") || s.startsWith("\"")) s = s.substring(1)
            return s
        }

        /** Value-length : renvoie -1 si la valeur n'est pas de cette forme. */
        fun valueLength(): Int {
            val x = u8()
            return when {
                x < 31 -> x
                x == 31 -> uintvar()
                else -> {
                    pos--; -1
                }
            }
        }

        fun longInt(): Long {
            val n = u8()
            var r = 0L
            repeat(n) { r = (r shl 8) or u8().toLong() }
            return r
        }

        fun intValue(): Int {
            val x = peek()
            return when {
                x >= 128 -> u8() and 0x7F
                x <= 30 -> longInt().toInt()
                else -> {
                    text(); 0
                }
            }
        }

        /** Saute une valeur d'en-tête, quel que soit son encodage. */
        fun skipValue() {
            if (eof()) return
            val x = peek()
            when {
                x >= 128 -> pos++
                x <= 30 -> pos += 1 + x
                x == 31 -> {
                    pos++
                    val l = uintvar()
                    pos += l
                }

                else -> text()
            }
        }

        fun encodedString(): String {
            val x = peek()
            if (x > 31) return text()
            val len = valueLength()
            val end = (pos + len).coerceAtMost(b.size)
            val cs = runCatching { intValue() }.getOrDefault(106)
            val s = if (end > pos) String(b, pos, end - pos, charsetOf(cs)).trimEnd('\u0000') else ""
            pos = end
            return if (s.startsWith("\u007F")) s.substring(1) else s
        }

        fun bytes(n: Int): ByteArray {
            val end = (pos + n).coerceAtMost(b.size)
            val out = b.copyOfRange(pos, end)
            pos = end
            return out
        }
    }

    private fun contentType(r: Reader): CType {
        val x = r.peek()
        if (x >= 128) {
            r.u8(); return CType(wellKnown(x and 0x7F))
        }
        if (x > 31) return CType(r.text())
        val len = r.valueLength()
        val end = r.pos + len
        val y = r.peek()
        val type = when {
            y >= 128 -> {
                r.u8(); wellKnown(y and 0x7F)
            }

            y > 31 -> r.text()
            else -> {
                r.skipValue(); "application/octet-stream"
            }
        }
        var charset = 106
        var name: String? = null
        try {
            while (r.pos < end) {
                val p = r.u8()
                when (p) {
                    0x81 -> charset = r.intValue()
                    0x85, 0x97 -> name = r.text()
                    0x86, 0x98 -> if (name == null) name = r.text() else r.text()
                    else -> if (p < 0x80) {
                        r.pos--; r.text(); r.skipValue()
                    } else r.skipValue()
                }
            }
        } catch (_: Exception) {
        }
        r.pos = end
        return CType(type, if (charset == 0) 106 else charset, name)
    }

    private fun multipart(r: Reader): List<RawPart> {
        val out = ArrayList<RawPart>()
        val n = r.uintvar()
        repeat(n) {
            val hl = r.uintvar()
            val dl = r.uintvar()
            val hStart = r.pos
            val ct = contentType(r)
            var loc: String? = null
            var cid: String? = null
            try {
                while (r.pos < hStart + hl) {
                    val f = r.u8()
                    when (f) {
                        0x8E -> loc = r.text()
                        0xC0 -> cid = r.text()
                        else -> if (f < 0x80) {
                            r.pos--; r.text(); r.text()
                        } else r.skipValue()
                    }
                }
            } catch (_: Exception) {
            }
            r.pos = hStart + hl
            out += RawPart(ct.type, ct.charset, ct.name ?: loc, cid, r.bytes(dl))
        }
        return out
    }

    fun cleanAddress(a: String?): String? =
        a?.substringBefore("/TYPE")?.trim()?.takeIf { it.isNotEmpty() && it != "insert-address-token" }

    fun parse(bytes: ByteArray): Pair<Headers, List<RawPart>> {
        val r = Reader(bytes)
        val h = Headers()
        var parts: List<RawPart> = emptyList()
        var body = false
        try {
            while (!r.eof() && !body) {
                val field = r.u8()
                if (field < 0x80) {
                    r.pos--; r.text(); r.text()
                    continue
                }
                when (field) {
                    0x8C -> h.type = r.u8()
                    0x98 -> h.tid = r.text()
                    0x83 -> h.location = r.text()
                    0x89 -> {
                        val len = r.valueLength()
                        if (len >= 0) {
                            val end = r.pos + len
                            val tok = r.u8()
                            if (tok == 0x80) h.from = r.encodedString()
                            r.pos = end
                        } else r.skipValue()
                    }

                    0x96 -> h.subject = r.encodedString()
                    0x85 -> h.date = r.longInt()
                    0x84 -> {
                        h.contentType = contentType(r).type
                        if (h.contentType!!.contains("multipart")) parts = multipart(r)
                        body = true
                    }

                    else -> r.skipValue()
                }
            }
        } catch (_: Exception) {
        }
        h.from = cleanAddress(h.from)
        return h to parts
    }

    // ---- Écriture ----
    class Writer {
        private val o = ByteArrayOutputStream()
        fun u8(x: Int) = o.write(x)
        fun uintvar(v: Int) {
            val groups = ArrayList<Int>()
            var x = v
            groups.add(x and 0x7F)
            x = x ushr 7
            while (x > 0) {
                groups.add((x and 0x7F) or 0x80)
                x = x ushr 7
            }
            groups.reversed().forEach { o.write(it) }
        }

        fun text(s: String) {
            val bytes = s.toByteArray(Charsets.UTF_8)
            if (bytes.isNotEmpty() && (bytes[0].toInt() and 0xFF) >= 128) o.write(0x7F)
            o.write(bytes)
            o.write(0)
        }

        fun valueLength(n: Int) {
            if (n < 31) o.write(n) else {
                o.write(31); uintvar(n)
            }
        }

        fun bytes(b: ByteArray) = o.write(b)
        fun toByteArray(): ByteArray = o.toByteArray()
    }

    private fun partHeader(typeBlock: ByteArray, cid: String, location: String): ByteArray {
        val w = Writer()
        w.bytes(typeBlock)
        w.u8(0xC0); w.u8(0x22); w.text("<$cid>")
        w.u8(0x8E); w.text(location)
        return w.toByteArray()
    }

    /** Construit un m-send-req (texte + image facultative). */
    fun sendReq(to: List<String>, text: String?, image: ByteArray?, imageType: String = "image/jpeg"): ByteArray {
        val w = Writer()
        w.u8(0x8C); w.u8(SEND_REQ)
        w.u8(0x98); w.text("T" + System.currentTimeMillis().toString(16))
        w.u8(0x8D); w.u8(0x92)
        w.u8(0x89); w.u8(0x01); w.u8(0x81)
        to.forEach { w.u8(0x97); w.text(it.filter { c -> c.isDigit() || c == '+' } + "/TYPE=PLMN") }
        w.u8(0x8A); w.u8(0x80)
        w.u8(0x86); w.u8(0x81)
        w.u8(0x90); w.u8(0x81)

        val ct = Writer()
        ct.u8(0xB3)
        ct.u8(0x8A); ct.text("<smil>")
        ct.u8(0x89); ct.text("application/smil")
        val ctb = ct.toByteArray()
        w.u8(0x84); w.valueLength(ctb.size); w.bytes(ctb)

        val parts = ArrayList<Pair<ByteArray, ByteArray>>()
        val hasText = !text.isNullOrBlank()
        val smil = buildString {
            append("<smil><head><layout><root-layout/>")
            append("<region id=\"Image\" top=\"0\" left=\"0\" height=\"80%\" width=\"100%\" fit=\"meet\"/>")
            append("<region id=\"Text\" top=\"80%\" left=\"0\" height=\"20%\" width=\"100%\" fit=\"scroll\"/>")
            append("</layout></head><body><par dur=\"5000ms\">")
            if (image != null) append("<img src=\"image.jpg\" region=\"Image\"/>")
            if (hasText) append("<text src=\"text.txt\" region=\"Text\"/>")
            append("</par></body></smil>")
        }
        val smilType = Writer().apply { text("application/smil") }.toByteArray()
        parts += partHeader(smilType, "smil", "smil.xml") to smil.toByteArray(Charsets.UTF_8)
        if (image != null) {
            val inner = Writer().apply { text(imageType); u8(0x85); text("image.jpg") }.toByteArray()
            val tb = Writer().apply { valueLength(inner.size); bytes(inner) }.toByteArray()
            parts += partHeader(tb, "image", "image.jpg") to image
        }
        if (hasText) {
            val tb = byteArrayOf(3, 0x83.toByte(), 0x81.toByte(), 0xEA.toByte())
            parts += partHeader(tb, "text", "text.txt") to text!!.toByteArray(Charsets.UTF_8)
        }
        w.uintvar(parts.size)
        parts.forEach { (hdr, data) ->
            w.uintvar(hdr.size); w.uintvar(data.size); w.bytes(hdr); w.bytes(data)
        }
        return w.toByteArray()
    }

    /** Accusé « MMS bien reçu » envoyé à l'opérateur. */
    fun notifyResp(tid: String): ByteArray {
        val w = Writer()
        w.u8(0x8C); w.u8(0x83)
        w.u8(0x98); w.text(tid)
        w.u8(0x8D); w.u8(0x92)
        w.u8(0x95); w.u8(0x81)
        return w.toByteArray()
    }
}

// =====================================================================
//  Lecture / écriture dans la base MMS du téléphone
// =====================================================================
object MmsRepo {
    private val MMS: Uri = Uri.parse("content://mms")
    private val PART: Uri = Uri.parse("content://mms/part")

    fun parts(c: Context, mmsId: Long): List<MmsPart> {
        val out = ArrayList<MmsPart>()
        runCatching {
            c.contentResolver.query(PART, arrayOf("_id", "ct", "text"), "mid=?", arrayOf(mmsId.toString()), "seq ASC")?.use { cur ->
                while (cur.moveToNext()) {
                    val id = cur.getLong(0)
                    val type = cur.getString(1) ?: continue
                    when {
                        type == "application/smil" -> {}
                        type.startsWith("text/") -> out += MmsPart(id, type, cur.getString(2) ?: readText(c, id), null)
                        type.startsWith("image/") || type.startsWith("video/") || type.startsWith("audio/") ->
                            out += MmsPart(id, type, null, "content://mms/part/$id")
                    }
                }
            }
        }
        return out
    }

    private fun readText(c: Context, partId: Long): String? = runCatching {
        c.contentResolver.openInputStream(Uri.parse("content://mms/part/$partId"))?.use { String(it.readBytes()) }
    }.getOrNull()

    fun address(c: Context, mmsId: Long, inbox: Boolean): String {
        val type = if (inbox) 137 else 151
        return runCatching {
            c.contentResolver.query(Uri.parse("content://mms/$mmsId/addr"), arrayOf("address", "type"), null, null, null)?.use { cur ->
                var found = ""
                while (cur.moveToNext()) {
                    val a = cur.getString(0) ?: continue
                    if (a == "insert-address-token") continue
                    if (cur.getInt(1) == type) {
                        found = a; break
                    }
                    if (found.isEmpty()) found = a
                }
                found
            } ?: ""
        }.getOrDefault("")
    }

    private fun boxToType(box: Int): Int = when (box) {
        Telephony.Mms.MESSAGE_BOX_INBOX -> Telephony.Sms.MESSAGE_TYPE_INBOX
        Telephony.Mms.MESSAGE_BOX_OUTBOX -> Telephony.Sms.MESSAGE_TYPE_OUTBOX
        Telephony.Mms.MESSAGE_BOX_FAILED -> Telephony.Sms.MESSAGE_TYPE_FAILED
        else -> Telephony.Sms.MESSAGE_TYPE_SENT
    }

    private fun toMsg(c: Context, id: Long, tid: Long, dateSec: Long, box: Int, read: Boolean, mType: Int, address: String?): SmsMsg {
        val parts = if (mType == 130) emptyList() else parts(c, id)
        val text = if (mType == 130) "📩 MMS pas encore téléchargé"
        else parts.mapNotNull { it.text }.joinToString("\n")
        return SmsMsg(
            id = id, threadId = tid,
            address = address ?: address(c, id, box == Telephony.Mms.MESSAGE_BOX_INBOX),
            body = text, date = dateSec * 1000, type = boxToType(box), read = read, status = -1,
            isMms = true, parts = parts
        )
    }

    fun forThread(c: Context, threadId: Long, address: String): List<SmsMsg> {
        if (!SmsRepo.canRead(c)) return emptyList()
        val out = ArrayList<SmsMsg>()
        runCatching {
            c.contentResolver.query(MMS, arrayOf("_id", "thread_id", "date", "msg_box", "read", "m_type"),
                "thread_id=?", arrayOf(threadId.toString()), "date ASC")?.use { cur ->
                while (cur.moveToNext() && out.size < 500) {
                    out += toMsg(c, cur.getLong(0), cur.getLong(1), cur.getLong(2), cur.getInt(3), cur.getInt(4) == 1, cur.getInt(5), address)
                }
            }
        }
        return out
    }

    /** Dernier MMS de chaque conversation + nombre de non lus. */
    fun latestPerThread(c: Context): Map<Long, Pair<SmsMsg, Int>> {
        if (!SmsRepo.canRead(c)) return emptyMap()
        val rows = ArrayList<LongArray>() // id, tid, date, box, read, mtype
        runCatching {
            c.contentResolver.query(MMS, arrayOf("_id", "thread_id", "date", "msg_box", "read", "m_type"), null, null, "date DESC")?.use { cur ->
                while (cur.moveToNext() && rows.size < 2000) {
                    rows += longArrayOf(cur.getLong(0), cur.getLong(1), cur.getLong(2), cur.getLong(3), cur.getLong(4), cur.getLong(5))
                }
            }
        }
        val out = LinkedHashMap<Long, Pair<SmsMsg, Int>>()
        rows.groupBy { it[1] }.forEach { (tid, list) ->
            val l = list.first()
            val unread = list.count { it[4] == 0L && it[3].toInt() == Telephony.Mms.MESSAGE_BOX_INBOX }
            val msg = toMsg(c, l[0], tid, l[2], l[3].toInt(), l[4] == 1L, l[5].toInt(), null)
            out[tid] = msg to unread
        }
        return out
    }

    fun unreadCount(c: Context): Int = runCatching {
        c.contentResolver.query(MMS, arrayOf("_id"), "read=0 AND msg_box=1", null, null)?.use { it.count } ?: 0
    }.getOrDefault(0)

    fun markRead(c: Context, threadId: Long) {
        if (!SmsRepo.isDefault(c)) return
        runCatching {
            c.contentResolver.update(MMS, ContentValues().apply { put("read", 1); put("seen", 1) },
                "thread_id=? AND read=0", arrayOf(threadId.toString()))
        }
    }

    fun delete(c: Context, id: Long): Boolean {
        if (!SmsRepo.isDefault(c)) return false
        return runCatching { c.contentResolver.delete(ContentUris.withAppendedId(MMS, id), null, null) > 0 }.getOrDefault(false)
    }

    private fun insertAddr(c: Context, id: Long, address: String, type: Int) {
        runCatching {
            c.contentResolver.insert(Uri.parse("content://mms/$id/addr"), ContentValues().apply {
                put("address", address); put("type", type); put("charset", 106)
            })
        }
    }

    private fun insertPart(c: Context, id: Long, seq: Int, type: String, name: String?, cid: String?, text: String?, data: ByteArray?) {
        runCatching {
            val v = ContentValues().apply {
                put("mid", id); put("seq", seq); put("ct", type)
                if (name != null) {
                    put("name", name); put("cl", name); put("fn", name)
                }
                if (cid != null) put("cid", if (cid.startsWith("<")) cid else "<$cid>")
                if (text != null) {
                    put("chset", 106); put("text", text)
                }
            }
            val pu = c.contentResolver.insert(Uri.parse("content://mms/$id/part"), v) ?: return@runCatching
            if (text == null && data != null) c.contentResolver.openOutputStream(pu)?.use { it.write(data) }
        }
    }

    fun insertIncoming(c: Context, h: Pdu.Headers, parts: List<Pdu.RawPart>): Long? {
        if (!SmsRepo.isDefault(c)) return null
        val from = h.from ?: return null
        val tid = SmsRepo.threadIdFor(c, from) ?: return null
        return runCatching {
            val v = ContentValues().apply {
                put("thread_id", tid)
                put("date", System.currentTimeMillis() / 1000)
                put("date_sent", h.date)
                put("msg_box", Telephony.Mms.MESSAGE_BOX_INBOX)
                put("read", 0); put("seen", 0)
                put("m_type", 132); put("v", 18)
                put("ct_t", h.contentType ?: "application/vnd.wap.multipart.related")
                h.tid?.let { put("tr_id", it) }
                h.location?.let { put("ct_l", it) }
                h.subject?.let { put("sub", it); put("sub_cs", 106) }
            }
            val uri = c.contentResolver.insert(Telephony.Mms.Inbox.CONTENT_URI, v) ?: return@runCatching null
            val id = ContentUris.parseId(uri)
            insertAddr(c, id, from, 137)
            parts.forEachIndexed { i, p ->
                insertPart(c, id, i, p.type, p.name, p.cid, if (p.isText) p.text() else null, if (p.isText) null else p.data)
            }
            id
        }.getOrNull()
    }

    fun insertOutgoing(c: Context, address: String, text: String?, image: ByteArray?): Uri? {
        if (!SmsRepo.isDefault(c)) return null
        val tid = SmsRepo.threadIdFor(c, address) ?: return null
        return runCatching {
            val v = ContentValues().apply {
                put("thread_id", tid)
                put("date", System.currentTimeMillis() / 1000)
                put("msg_box", Telephony.Mms.MESSAGE_BOX_OUTBOX)
                put("read", 1); put("seen", 1)
                put("m_type", 128); put("v", 18)
                put("ct_t", "application/vnd.wap.multipart.related")
            }
            val uri = c.contentResolver.insert(MMS, v) ?: return@runCatching null
            val id = ContentUris.parseId(uri)
            insertAddr(c, id, address, 151)
            insertAddr(c, id, "insert-address-token", 137)
            var seq = 0
            if (image != null) insertPart(c, id, seq++, "image/jpeg", "image.jpg", "image", null, image)
            if (!text.isNullOrBlank()) insertPart(c, id, seq, "text/plain", "text.txt", "text", text, null)
            uri
        }.getOrNull()
    }

    fun setBox(c: Context, uri: Uri, box: Int) {
        if (!SmsRepo.isDefault(c)) return
        runCatching { c.contentResolver.update(uri, ContentValues().apply { put("msg_box", box) }, null, null) }
    }
}

// =====================================================================
//  Envoi / téléchargement via le service MMS d'Android
// =====================================================================
object MmsTransport {
    const val ACTION_DOWNLOADED = "com.dlvibe.dlphone.MMS_DOWNLOADED"
    const val ACTION_SENT = "com.dlvibe.dlphone.MMS_SENT"
    private val MMS_PACKAGES = listOf("com.android.phone", "com.android.mms.service")

    private fun dir(c: Context) = File(c.cacheDir, "mms").apply { mkdirs() }
    private fun uriFor(c: Context, f: File): Uri = FileProvider.getUriForFile(c, c.packageName + ".mmsfiles", f)

    private fun grant(c: Context, uri: Uri, write: Boolean) {
        val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or (if (write) Intent.FLAG_GRANT_WRITE_URI_PERMISSION else 0)
        MMS_PACKAGES.forEach { runCatching { c.grantUriPermission(it, uri, flags) } }
    }

    private fun mutableFlags() = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)

    /** Appelé quand l'opérateur annonce un MMS : on le télécharge. */
    fun onNotification(c: Context, pdu: ByteArray) {
        val (h, _) = Pdu.parse(pdu)
        if (h.type != Pdu.NOTIFICATION_IND) return
        val location = h.location ?: return
        if (h.from != null && Prefs.isBlocked(h.from)) return
        val f = File(dir(c), "dl_${System.currentTimeMillis()}.pdu")
        val uri = uriFor(c, f)
        grant(c, uri, true)
        val pi = PendingIntent.getBroadcast(
            c, (System.currentTimeMillis() and 0xFFFFFF).toInt(),
            Intent(c, SmsActionReceiver::class.java).setAction(ACTION_DOWNLOADED)
                .putExtra("file", f.absolutePath).putExtra("tid", h.tid).putExtra("from", h.from),
            mutableFlags()
        )
        runCatching { SmsSender.manager(c).downloadMultimediaMessage(c, location, uri, null, pi) }
            .onFailure { SmsNotif.info(c, "MMS", "Téléchargement du MMS impossible : activez les données mobiles.") }
    }

    fun onDownloaded(c: Context, intent: Intent, resultCode: Int) {
        val f = File(intent.getStringExtra("file") ?: return)
        try {
            if (resultCode != Activity.RESULT_OK || !f.exists() || f.length() == 0L) {
                SmsNotif.info(c, "MMS non reçu", "Le téléchargement a échoué. Vérifiez que les données mobiles sont activées.")
                return
            }
            val (h, parts) = Pdu.parse(f.readBytes())
            if (h.from == null) h.from = intent.getStringExtra("from")
            val from = h.from ?: ""
            MmsRepo.insertIncoming(c, h, parts)
            val text = parts.filter { it.type.startsWith("text/plain") }.joinToString(" ") { it.text() }
            val hasImage = parts.any { it.type.startsWith("image/") }
            val snippet = listOfNotNull(if (hasImage) "📷 Photo" else null, text.takeIf { it.isNotBlank() }).joinToString(" · ")
                .ifBlank { "📩 MMS" }
            if (!(Prefs.isBlocked(from) && Prefs.smsHideBlocked)) SmsNotif.incoming(c, from, snippet)
            (h.tid ?: intent.getStringExtra("tid"))?.let { sendRaw(c, Pdu.notifyResp(it), null) }
            SmsBus.changed()
        } catch (_: Exception) {
        } finally {
            f.delete()
        }
    }

    private fun sendRaw(c: Context, pdu: ByteArray, sent: PendingIntent?) {
        val f = File(dir(c), "send_${System.nanoTime()}.pdu")
        f.writeBytes(pdu)
        val uri = uriFor(c, f)
        grant(c, uri, false)
        SmsSender.manager(c).sendMultimediaMessage(c, uri, null, null, sent)
    }

    /** 📷 Envoie un MMS : texte + photo. */
    fun send(c: Context, address: String, text: String?, imageUri: Uri?): Boolean {
        if (address.isBlank()) return false
        return try {
            val image = imageUri?.let { compress(c, it) }
            if (imageUri != null && image == null) {
                Toast.makeText(c, "Image illisible", Toast.LENGTH_SHORT).show()
                return false
            }
            val pdu = Pdu.sendReq(listOf(address), text, image)
            val msgUri = MmsRepo.insertOutgoing(c, address, text, image)
            val pi = PendingIntent.getBroadcast(
                c, (System.currentTimeMillis() and 0xFFFFFF).toInt(),
                Intent(c, SmsActionReceiver::class.java).setAction(ACTION_SENT).putExtra("uri", msgUri?.toString()),
                mutableFlags()
            )
            sendRaw(c, pdu, pi)
            SmsBus.changed()
            true
        } catch (e: Exception) {
            Toast.makeText(c, "Envoi du MMS impossible : ${e.message}", Toast.LENGTH_LONG).show()
            false
        }
    }

    fun onSent(c: Context, intent: Intent, resultCode: Int) {
        val uri = intent.getStringExtra("uri")?.let { Uri.parse(it) }
        val ok = resultCode == Activity.RESULT_OK
        if (uri != null) MmsRepo.setBox(c, uri, if (ok) Telephony.Mms.MESSAGE_BOX_SENT else Telephony.Mms.MESSAGE_BOX_FAILED)
        if (!ok) Toast.makeText(c, "Échec de l'envoi du MMS (données mobiles ?)", Toast.LENGTH_LONG).show()
        dir(c).listFiles()?.filter { it.name.startsWith("send_") && System.currentTimeMillis() - it.lastModified() > 60_000 }
            ?.forEach { it.delete() }
        SmsBus.changed()
    }

    /** Réduit la photo (≈ 300 Ko max, limite courante des opérateurs). */
    private fun compress(c: Context, uri: Uri): ByteArray? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0) return null
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= 1280) sample *= 2
        var bmp = c.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: return null
        val rotation = runCatching {
            c.contentResolver.openInputStream(uri)?.use {
                when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } ?: 0f
        }.getOrDefault(0f)
        if (rotation != 0f) {
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(rotation) }, true)
        }
        var quality = 85
        while (true) {
            val out = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, quality, out)
            if (out.size() <= 300_000 || (quality <= 35 && maxOf(bmp.width, bmp.height) <= 480)) return out.toByteArray()
            if (quality > 35) quality -= 10
            else {
                bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * 0.75f).toInt(), (bmp.height * 0.75f).toInt(), true)
                quality = 75
            }
        }
    }
}
