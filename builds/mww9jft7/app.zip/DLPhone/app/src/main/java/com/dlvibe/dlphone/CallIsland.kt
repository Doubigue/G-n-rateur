package com.dlvibe.dlphone

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.text.TextPaint
import android.text.TextUtils
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.core.graphics.PathParser
import kotlin.math.hypot

/**
 * 🏝️ Îlot d'appel autour de la caméra frontale.
 * - Touche rouge = refuser, touche verte = répondre
 * - 1 doigt maintenu = refuser (anneau rouge), 2 doigts = répondre (anneau vert)
 * - Toucher le centre = ouvrir / réduire l'îlot
 */
object CallIsland {
    private var view: IslandView? = null
    private var wm: WindowManager? = null

    fun canShow(ctx: Context): Boolean = Settings.canDrawOverlays(ctx)

    fun overlaySettings(ctx: Context) {
        runCatching {
            ctx.startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    /** Écran allumé et déverrouillé : l'îlot remplace l'écran d'appel plein écran. */
    fun deviceInUse(ctx: Context): Boolean {
        val km = ctx.getSystemService(KeyguardManager::class.java)
        val pm = ctx.getSystemService(PowerManager::class.java)
        return pm?.isInteractive == true && km?.isKeyguardLocked != true
    }

    @Suppress("DEPRECATION")
    fun show(ctx: Context, number: String, name: String?, preview: Boolean = false): Boolean {
        if (!canShow(ctx)) return false
        hide()
        val app = ctx.applicationContext
        val w = app.getSystemService(WindowManager::class.java) ?: return false
        val dm = app.resources.displayMetrics
        val sb = statusBarHeight(app)
        var camX = dm.widthPixels / 2f
        var camY = sb / 2f
        if (Build.VERSION.SDK_INT >= 29) {
            val rect = runCatching { w.defaultDisplay?.cutout?.boundingRects }.getOrNull()
                ?.filter { it.top < sb * 2 }
                ?.minByOrNull { it.top }
            if (rect != null) {
                camX = rect.exactCenterX()
                camY = rect.exactCenterY()
            }
        }
        val v = IslandView(app, name ?: number.ifBlank { "Numéro masqué" }, preview, camX, camY, sb)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.x = v.windowOffset()
        lp.y = 0
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return try {
            w.addView(v, lp)
            view = v
            wm = w
            true
        } catch (_: Exception) {
            false
        }
    }

    fun hide() {
        val v = view ?: return
        view = null
        v.release()
        runCatching { wm?.removeView(v) }
    }

    internal fun relayout(v: IslandView) {
        val lp = v.layoutParams as? WindowManager.LayoutParams ?: return
        lp.x = v.windowOffset()
        runCatching { wm?.updateViewLayout(v, lp) }
    }

    @SuppressLint("DiscouragedApi", "InternalInsetResource")
    private fun statusBarHeight(ctx: Context): Int {
        val id = ctx.resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) ctx.resources.getDimensionPixelSize(id) else (24 * ctx.resources.displayMetrics.density).toInt()
    }

    /** Ce qui se passe quand l'îlot est validé. */
    internal fun act(ctx: Context, answer: Boolean, preview: Boolean) {
        if (preview) {
            Toast.makeText(ctx, if (answer) "Répondu ✓ (essai)" else "Refusé ✕ (essai)", Toast.LENGTH_SHORT).show()
        } else if (answer) {
            CallManager.answer()
            runCatching {
                ctx.startActivity(Intent(ctx, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        } else {
            CallManager.ringing()?.reject(false, null)
        }
        hide()
    }
}

@SuppressLint("ViewConstructor")
class IslandView(
    ctx: Context,
    private val title: String,
    private val preview: Boolean,
    private val camX: Float,
    private val camY: Float,
    private val sb: Int
) : View(ctx) {
    companion object {
        private val RED = Color.parseColor("#E5484D")
        private val GREEN = Color.parseColor("#1FB45A")
        private val ORANGE = Color.parseColor("#FF7A00")
        private const val ONE =
            "M10 13V4.5a1.5 1.5 0 0 1 3 0V12M13 11.5a1.5 1.5 0 0 1 3 0V13M16 12.5a1.5 1.5 0 0 1 3 0V16a6 6 0 0 1-6 6h-1a6 6 0 0 1-5.2-3l-2.3-4a1.5 1.5 0 0 1 2.6-1.5L10 15"
        private const val TWO =
            "M9 12V4.5a1.5 1.5 0 0 1 3 0V11M12 11l2.3-6.6a1.5 1.5 0 0 1 2.8 1L15 12M15 12a1.5 1.5 0 0 1 3 0v4a6 6 0 0 1-6 6h-1a6 6 0 0 1-5.2-3l-2.3-4a1.5 1.5 0 0 1 2.6-1.5L9 15"
    }

    private val d = resources.displayMetrics.density
    private val screenW = resources.displayMetrics.widthPixels
    private var expanded = false
    private var progress = 0f
    private var holdColor = RED
    private var maxFingers = 0
    private var downTime = 0L
    private var done = false
    private var pulse = 0f
    private var holdAnim: ValueAnimator? = null
    private var pulseAnim: ValueAnimator? = null
    private val uiHandler = Handler(Looper.getMainLooper())

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.5f * d }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 4f * d; strokeCap = Paint.Cap.ROUND
    }
    private val icon = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = Color.WHITE; strokeWidth = 2f
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val nameP = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }
    private val subP = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = ORANGE }
    private val hintP = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#A8A8A8") }
    private val oneFinger: Path? = runCatching { PathParser.createPathFromPathData(ONE) }.getOrNull()
    private val twoFingers: Path? = runCatching { PathParser.createPathFromPathData(TWO) }.getOrNull()

    init {
        isHapticFeedbackEnabled = true
        if (preview) uiHandler.postDelayed({ CallIsland.hide() }, 20_000)
    }

    // ---- Géométrie ----
    private fun widthPx(): Int = if (expanded) screenW - (24 * d).toInt() else (236 * d).toInt()
    private fun heightPx(): Int = sb + ((if (expanded) 112 else 44) * d).toInt()
    fun windowOffset(): Int {
        if (expanded) return 0
        val half = (screenW - widthPx()) / 2
        return (camX - screenW / 2f).toInt().coerceIn(-half, half)
    }

    private fun leftOnScreen(): Float = (screenW - widthPx()) / 2f + windowOffset()
    private fun btnR(): Float = (if (expanded) 26f else 15f) * d
    private fun btnCy(): Float = if (expanded) sb + 46 * d else heightPx() - 22 * d
    private fun redCx(): Float = 8 * d + btnR()
    private fun greenCx(): Float = widthPx() - 8 * d - btnR()

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(widthPx(), heightPx())
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        pulseAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1200
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener {
                pulse = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    fun release() {
        uiHandler.removeCallbacksAndMessages(null)
        holdAnim?.cancel()
        pulseAnim?.cancel()
    }

    override fun onDetachedFromWindow() {
        release()
        super.onDetachedFromWindow()
    }

    // ---- Dessin ----
    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = 24 * d
        c.drawRoundRect(RectF(0f, 0f, w, h), r, r, bg)
        border.color = if (progress > 0f) holdColor else (ORANGE and 0x00FFFFFF) or (0x70 shl 24)
        val inset = border.strokeWidth / 2
        c.drawRoundRect(RectF(inset, inset, w - inset, h - inset), r, r, border)

        // Caméra : halo qui pulse, puis anneau de progression
        val cx = camX - leftOnScreen()
        val cy = camY
        ring.strokeWidth = 2f * d
        ring.color = (ORANGE and 0x00FFFFFF) or (((1f - pulse) * 160).toInt() shl 24)
        c.drawCircle(cx, cy, (11f + 9f * pulse) * d, ring)
        if (progress > 0f) {
            ring.strokeWidth = 4f * d
            ring.color = holdColor
            val rr = 17f * d
            c.drawArc(RectF(cx - rr, cy - rr, cx + rr, cy + rr), -90f, 360f * progress, false, ring)
        }

        // Boutons rouge (1 doigt) et vert (2 doigts)
        val by = btnCy()
        fill.color = RED
        c.drawCircle(redCx(), by, btnR(), fill)
        drawIcon(c, oneFinger, redCx(), by, btnR() * 1.15f)
        fill.color = GREEN
        c.drawCircle(greenCx(), by, btnR(), fill)
        drawIcon(c, twoFingers, greenCx(), by, btnR() * 1.15f)

        if (!expanded) {
            nameP.textSize = 12f * d
            val avail = greenCx() - redCx() - 2 * btnR() - 16 * d
            val t = TextUtils.ellipsize(title, nameP, avail, TextUtils.TruncateAt.END).toString()
            c.drawText(t, (redCx() + greenCx()) / 2f - nameP.measureText(t) / 2f, by + 4.5f * d, nameP)
        } else {
            nameP.textSize = 17f * d
            subP.textSize = 12f * d
            hintP.textSize = 11f * d
            val tx = redCx() + btnR() + 16 * d
            val avail = greenCx() - btnR() - 12 * d - tx
            val t = TextUtils.ellipsize(title, nameP, avail, TextUtils.TruncateAt.END).toString()
            c.drawText(t, tx, by - 2 * d, nameP)
            c.drawText(if (preview) "Essai de l'îlot ✦" else "Appel entrant…", tx, by + 16 * d, subP)
            val hint = "Maintenir 1 doigt = refuser · 2 doigts = répondre"
            val ht = TextUtils.ellipsize(hint, hintP, w - 24 * d, TextUtils.TruncateAt.END).toString()
            c.drawText(ht, w / 2f - hintP.measureText(ht) / 2f, h - 12 * d, hintP)
        }
    }

    private fun drawIcon(c: Canvas, p: Path?, cx: Float, cy: Float, size: Float) {
        if (p == null) return
        c.save()
        c.translate(cx - size / 2f, cy - size / 2f)
        c.scale(size / 24f, size / 24f)
        c.drawPath(p, icon)
        c.restore()
    }

    // ---- Gestes ----
    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (done) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                maxFingers = 1
                downTime = SystemClock.uptimeMillis()
                startHold(if (hit(e.x, e.y, greenCx())) GREEN else RED)
            }

            MotionEvent.ACTION_POINTER_DOWN -> {
                if (e.pointerCount > maxFingers) {
                    maxFingers = e.pointerCount
                    if (maxFingers >= 2) startHold(GREEN)
                }
            }

            MotionEvent.ACTION_UP -> {
                val quick = SystemClock.uptimeMillis() - downTime < 300
                cancelHold()
                if (quick && maxFingers == 1) {
                    when {
                        hit(e.x, e.y, redCx()) -> finish(false)
                        hit(e.x, e.y, greenCx()) -> finish(true)
                        else -> toggle()
                    }
                }
            }

            MotionEvent.ACTION_CANCEL -> cancelHold()
        }
        return true
    }

    private fun hit(x: Float, y: Float, cx: Float): Boolean = hypot(x - cx, y - btnCy()) <= btnR() + 10 * d

    private fun startHold(color: Int) {
        holdAnim?.cancel()
        holdColor = color
        progress = 0f
        val anim = ValueAnimator.ofFloat(0f, 1f)
        anim.duration = 800
        anim.startDelay = 150
        var cancelled = false
        anim.addUpdateListener {
            progress = it.animatedValue as Float
            invalidate()
        }
        anim.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationCancel(animation: Animator) {
                cancelled = true
            }

            override fun onAnimationEnd(animation: Animator) {
                if (!cancelled && !done) finish(holdColor == GREEN)
            }
        })
        holdAnim = anim
        anim.start()
    }

    private fun cancelHold() {
        holdAnim?.cancel()
        holdAnim = null
        progress = 0f
        invalidate()
    }

    private fun toggle() {
        expanded = !expanded
        requestLayout()
        CallIsland.relayout(this)
        invalidate()
    }

    private fun finish(answer: Boolean) {
        if (done) return
        done = true
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        CallIsland.act(context, answer, preview)
    }
}

/** 👆 Caméra couverte pendant la sonnerie (capteur de proximité à côté de la caméra). */
object CoverGesture {
    const val NONE = 0
    const val SILENCE = 1
    const val ANSWER = 2
    const val REJECT = 3

    private var sm: SensorManager? = null
    private var listener: SensorEventListener? = null
    private val handler = Handler(Looper.getMainLooper())

    fun start(ctx: Context) {
        stop()
        val action = Prefs.coverAction
        if (action == NONE) return
        val app = ctx.applicationContext
        val manager = app.getSystemService(SensorManager::class.java) ?: return
        val sensor = manager.getDefaultSensor(Sensor.TYPE_PROXIMITY) ?: return
        val l = object : SensorEventListener {
            var seenFar = false
            override fun onSensorChanged(e: SensorEvent) {
                val near = e.values[0] < minOf(5f, sensor.maximumRange)
                if (!near) {
                    seenFar = true
                    handler.removeCallbacksAndMessages(null)
                } else if (seenFar) {
                    handler.removeCallbacksAndMessages(null)
                    handler.postDelayed({ perform(app, action) }, 600)
                }
            }

            override fun onAccuracyChanged(s: Sensor?, accuracy: Int) {}
        }
        manager.registerListener(l, sensor, SensorManager.SENSOR_DELAY_NORMAL)
        sm = manager
        listener = l
    }

    private fun perform(ctx: Context, action: Int) {
        if (CallManager.ringing() == null) return
        when (action) {
            SILENCE -> MagicEffects.silence(ctx)
            ANSWER -> CallIsland.act(ctx, answer = true, preview = false)
            REJECT -> CallIsland.act(ctx, answer = false, preview = false)
        }
        stop()
    }

    fun stop() {
        handler.removeCallbacksAndMessages(null)
        listener?.let { sm?.unregisterListener(it) }
        listener = null
    }
}
