package com.dlvibe.dlphone

import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dlvibe.dlphone.ui.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Éditeur de thème d'appel : vidéo, sonnerie, photo, note et VIP pour un numéro. */
class ThemeEditorActivity : ComponentActivity() {
    companion object {
        private const val EXTRA_NUMBER = "number"
        private const val EXTRA_NAME = "name"
        private const val EXTRA_DEFAULT = "is_default"

        fun open(ctx: Context, number: String?, name: String?, isDefault: Boolean = false) {
            ctx.startActivity(
                Intent(ctx, ThemeEditorActivity::class.java)
                    .putExtra(EXTRA_NUMBER, number)
                    .putExtra(EXTRA_NAME, name)
                    .putExtra(EXTRA_DEFAULT, isDefault)
            )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        enableEdgeToEdge()
        val number = intent.getStringExtra(EXTRA_NUMBER) ?: ""
        val name = intent.getStringExtra(EXTRA_NAME)
        val isDefault = intent.getBooleanExtra(EXTRA_DEFAULT, false)
        setContent { DlTheme { ThemeEditor(number, name, isDefault, onClose = { finish() }) } }
    }
}

@Composable
private fun ThemeEditor(initialNumber: String, initialName: String?, isDefault: Boolean, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val p = LocalPalette.current
    val scope = rememberCoroutineScope()
    val existing = remember { if (isDefault) CallThemes.default(ctx) else CallThemes.get(ctx, initialNumber) }

    var number by remember { mutableStateOf(existing?.number?.takeIf { it.isNotBlank() } ?: initialNumber) }
    var label by remember { mutableStateOf(existing?.label ?: initialName ?: "") }
    var video by remember { mutableStateOf(existing?.video) }
    var sound by remember { mutableStateOf(existing?.sound) }
    var photo by remember { mutableStateOf(existing?.photo) }
    var useVideoSound by remember { mutableStateOf(existing?.useVideoSound ?: false) }
    var vip by remember { mutableStateOf(existing?.vip ?: false) }
    var note by remember { mutableStateOf(existing?.note ?: "") }
    var busy by remember { mutableStateOf<String?>(null) }
    val replaced = remember { mutableListOf<String>() }

    // --- Écoute de la sonnerie ---
    val preview = remember { arrayOfNulls<MediaPlayer>(1) }
    var playing by remember { mutableStateOf(false) }
    fun stopPreview() {
        preview[0]?.let { runCatching { it.stop() }; runCatching { it.release() } }
        preview[0] = null
        playing = false
    }

    fun playPreview() {
        stopPreview()
        val src = if (useVideoSound && video != null) video else sound
        val mp = MediaPlayer()
        try {
            if (src != null) mp.setDataSource(src) else mp.setDataSource(ctx, Settings.System.DEFAULT_RINGTONE_URI)
            mp.setOnCompletionListener { stopPreview() }
            mp.prepare()
            mp.start()
            preview[0] = mp
            playing = true
        } catch (_: Exception) {
            runCatching { mp.release() }
            Toast.makeText(ctx, "Impossible de lire ce son", Toast.LENGTH_SHORT).show()
        }
    }
    DisposableEffect(Unit) { onDispose { stopPreview() } }

    // --- Import des fichiers ---
    fun importMedia(uri: Uri?, kind: String, label: String, set: (String) -> Unit) {
        if (uri == null) return
        busy = "Import $label…"
        scope.launch {
            val path = withContext(Dispatchers.IO) { runCatching { CallThemes.importFile(ctx, uri, kind) }.getOrNull() }
            busy = null
            if (path != null) set(path) else Toast.makeText(ctx, "Import impossible", Toast.LENGTH_SHORT).show()
        }
    }

    val pickVideo = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        importMedia(uri, "video", "de la vidéo") { path -> video?.let { replaced.add(it) }; video = path }
    }
    val pickSound = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        importMedia(uri, "audio", "du son") { path -> sound?.let { replaced.add(it) }; sound = path }
    }
    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        importMedia(uri, "image", "de la photo") { path -> photo?.let { replaced.add(it) }; photo = path }
    }
    val pickContact = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val uri = r.data?.data ?: return@rememberLauncherForActivityResult
        runCatching {
            ctx.contentResolver.query(
                uri,
                arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME),
                null, null, null
            )?.use {
                if (it.moveToFirst()) {
                    number = it.getString(0) ?: ""
                    label = it.getString(1) ?: ""
                }
            }
        }
    }

    fun save(): Boolean {
        val key = if (isDefault) CallThemes.DEFAULT_KEY else CallThemes.keyFor(number)
        if (!isDefault && key.length < 3) {
            Toast.makeText(ctx, "Entrez un numéro valide", Toast.LENGTH_SHORT).show()
            return false
        }
        val t = CallTheme(
            key = key,
            number = if (isDefault) "" else number.trim(),
            label = label.trim().ifBlank { null },
            video = video, sound = sound, photo = photo,
            useVideoSound = useVideoSound, vip = vip,
            note = note.trim().ifBlank { null }
        )
        if (existing != null && existing.key != key) CallThemes.removeKey(ctx, existing.key)
        CallThemes.save(ctx, t)
        replaced.forEach { CallThemes.deleteIfUnused(ctx, it) }
        replaced.clear()
        return true
    }

    val photoImg by produceState<ImageBitmap?>(null, photo) {
        value = photo?.let { withContext(Dispatchers.IO) { PhotoLoader.decode(ctx, it, 900) } }
    }
    val title = if (isDefault) "Tous les appels" else label.ifBlank { number.ifBlank { "Nouveau numéro" } }

    Box(
        Modifier
            .fillMaxSize()
            .background(bgBrush(p))
            .systemBarsPadding()
            .imePadding()
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) { Icon(Icons.Filled.ArrowBack, "Retour", tint = p.text) }
                Column {
                    Text(if (isDefault) "Thème par défaut" else "Personnaliser l'appel", color = p.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Vidéo, sonnerie, photo et note ✦", color = p.muted, fontSize = 12.sp)
                }
            }

            if (!isDefault) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = number,
                        onValueChange = { number = it },
                        label = { Text("Numéro") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        shape = RoundedCornerShape(16.dp),
                        colors = dlTextFieldColors(),
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = {
                        runCatching {
                            pickContact.launch(Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI))
                        }
                    }) { Icon(Icons.Filled.Contacts, "Choisir un contact", tint = p.accent) }
                }
                OutlinedTextField(
                    value = label,
                    onValueChange = { label = it },
                    label = { Text("Nom affiché (facultatif)") },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    colors = dlTextFieldColors(),
                    modifier = Modifier.fillMaxWidth()
                )
            } else {
                Text(
                    "La vidéo et la sonnerie choisies ici s'appliquent à tous les numéros qui n'ont pas leur propre thème.",
                    color = p.muted, fontSize = 13.sp
                )
            }

            // Aperçu visuel
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(320.dp)
                    .clip(RoundedCornerShape(26.dp))
                    .background(Brush.verticalGradient(listOf(p.cardTop, p.card)))
            ) {
                val v = video
                val img = photoImg
                when {
                    v != null -> LoopingVideo(v, Modifier.fillMaxSize())
                    img != null -> Image(img, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                    else -> Box(Modifier.align(Alignment.Center)) {
                        Avatar(title, 110.dp, number = if (isDefault) null else number, lookup = true)
                    }
                }
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.75f))))
                )
                Column(
                    Modifier
                        .align(Alignment.BottomStart)
                        .padding(18.dp)
                ) {
                    Text(title, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("Appel entrant…", color = p.accent, fontSize = 14.sp)
                    if (note.isNotBlank()) Text("📝 $note", color = Color.White, fontSize = 13.sp, maxLines = 2)
                }
            }

            DlCard {
                MediaRow(Icons.Filled.Movie, "Vidéo d'appel", video?.let { "Vidéo choisie ✓" } ?: "Aucune — plein écran à l'appel",
                    onPick = { pickVideo.launch(arrayOf("video/*")) },
                    onRemove = if (video != null) ({ video?.let { replaced.add(it) }; video = null; useVideoSound = false }) else null)
                MediaRow(Icons.Filled.MusicNote, "Sonnerie", sound?.let { File(it).name } ?: if (useVideoSound && video != null) "Son de la vidéo" else "Sonnerie du téléphone",
                    onPick = { pickSound.launch(arrayOf("audio/*")) },
                    onRemove = if (sound != null) ({ sound?.let { replaced.add(it) }; sound = null }) else null,
                    extra = {
                        IconButton(onClick = { if (playing) stopPreview() else playPreview() }) {
                            Icon(if (playing) Icons.Filled.Stop else Icons.Filled.PlayArrow, "Écouter", tint = p.accent)
                        }
                    })
                MediaRow(Icons.Filled.Image, "Photo", photo?.let { "Photo choisie ✓" } ?: "Photo du contact si elle existe",
                    onPick = { pickPhoto.launch(arrayOf("image/*")) },
                    onRemove = if (photo != null) ({ photo?.let { replaced.add(it) }; photo = null }) else null)
            }

            DlCard {
                ToggleRow(Icons.Filled.VolumeUp, "Son de la vidéo comme sonnerie", "La bande-son de la vidéo sonne à l'appel", useVideoSound, enabled = video != null) {
                    useVideoSound = it
                }
                if (!isDefault) {
                    ToggleRow(Icons.Filled.Star, "VIP", "Sonne même en mode silencieux ou Ne pas déranger", vip) { vip = it }
                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it },
                        label = { Text("📝 Note affichée pendant l'appel") },
                        placeholder = { Text("Ex : lui rappeler le rendez-vous de vendredi") },
                        shape = RoundedCornerShape(16.dp),
                        colors = dlTextFieldColors(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp)
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(
                    onClick = {
                        if (save()) {
                            stopPreview()
                            ctx.startActivity(
                                Intent(ctx, InCallActivity::class.java)
                                    .putExtra(InCallActivity.EXTRA_PREVIEW, if (isDefault) "" else number)
                                    .putExtra(InCallActivity.EXTRA_PREVIEW_NAME, title)
                            )
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) { Text("Aperçu ✨", color = p.accent) }
                Button(
                    onClick = {
                        if (save()) {
                            Toast.makeText(ctx, "Thème enregistré ✦", Toast.LENGTH_SHORT).show()
                            onClose()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = p.accent, contentColor = p.onAccent),
                    modifier = Modifier.weight(1f)
                ) { Text("Enregistrer") }
            }
            if (existing != null) {
                TextButton(onClick = {
                    CallThemes.delete(ctx, existing.key)
                    replaced.forEach { CallThemes.deleteIfUnused(ctx, it) }
                    Toast.makeText(ctx, "Thème supprimé", Toast.LENGTH_SHORT).show()
                    onClose()
                }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                    Text("Supprimer ce thème", color = HangupRed)
                }
            }
            Signature()
        }

        val b = busy
        if (b != null) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.55f)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = p.accent)
                    Text(b, color = Color.White, modifier = Modifier.padding(top = 12.dp))
                }
            }
        }
    }
}

@Composable
private fun MediaRow(
    icon: ImageVector,
    title: String,
    value: String,
    onPick: () -> Unit,
    onRemove: (() -> Unit)?,
    extra: @Composable () -> Unit = {}
) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconPill(icon, p.accent, 40.dp)
        Column(
            Modifier
                .weight(1f)
                .padding(horizontal = 12.dp)
        ) {
            Text(title, color = p.text, fontWeight = FontWeight.Medium)
            Text(value, color = p.muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        extra()
        if (onRemove != null) IconButton(onClick = onRemove) { Icon(Icons.Filled.Delete, "Retirer", tint = p.muted) }
        TextButton(onClick = onPick) { Text("Choisir", color = p.accent) }
    }
}

@Composable
private fun ToggleRow(
    icon: ImageVector,
    title: String,
    sub: String,
    checked: Boolean,
    enabled: Boolean = true,
    onChange: (Boolean) -> Unit
) {
    val p = LocalPalette.current
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconPill(icon, if (enabled) p.accent else p.muted, 38.dp)
        Column(
            Modifier
                .weight(1f)
                .padding(horizontal = 12.dp)
        ) {
            Text(title, color = if (enabled) p.text else p.muted, fontWeight = FontWeight.Medium)
            Text(sub, color = p.muted, fontSize = 12.sp)
        }
        Switch(
            checked = checked,
            enabled = enabled,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedThumbColor = p.onAccent, checkedTrackColor = p.accent)
        )
    }
}
