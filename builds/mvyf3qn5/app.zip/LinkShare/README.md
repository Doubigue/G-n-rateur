# LinkShare

Partage rapide Android (Kotlin / Compose / Ktor) avec accès distant aux fichiers et applications.

## Lancer
1. Ouvrir le dossier dans Android Studio (Ladybug ou plus récent, JDK 17) et laisser Gradle synchroniser.
2. Installer sur deux téléphones (Android 11+).
3. Téléphone A : « Partager mon téléphone » (autoriser l'accès à tous les fichiers) → un QR s'affiche.
4. Téléphone B : « Scanner un QR » → parcourir fichiers et apps, lire vidéos / audio / images en streaming,
   télécharger fichiers ou dossiers, envoyer fichiers ou dossiers (ils arrivent dans Download/LinkShare).

## Interface (explorateur façon Files by Google)
Thème sombre. Accueil : carrousel de fichiers récents (miniatures image/vidéo), Catégories (Téléchargements, Images, Vidéos,
Audio, Documents, Applications) avec la taille occupée, Collections (Favoris, Dossier sécurisé), Stockage total (interne,
carte SD si présente, autre téléphone via LinkShare).

La **pilule** est la barre grise arrondie flottante en bas de l'accueil, avec deux boutons : **Partager** à gauche (LinkShare : envoyer / recevoir) et **Scanner** à droite (scan de documents en PDF, ML Kit, enregistré dans Documents/LinkShare Scans).
- Partager ouvre une feuille : Envoyer (QR + radar), Recevoir (scan d'un QR), Se connecter avec un lien. Ces écrans sont
  propres à l'explorateur : pas d'accueil, de barre de navigation ni de profil LinkShare. Une fois connecté, la liste distante
  (fichiers, apps, envoi/téléchargement) s'affiche.
- Explorateur : dossiers en grille de grandes icônes (bascule liste), recherche récursive, tri, lecture intégrée,
  ZIP, favoris, dossier sécurisé (verrouillage du téléphone), suppression.

## Lecture, ouverture depuis d'autres applis, partage
- **Lecture en arrière-plan** (service Media3, `PlaybackService`) : notification de lecture dans la barre d'état
  (icône LinkShare, titre, lecture/pause/avance), commandes sur l'écran verrouillé, la lecture continue écran éteint ou
  appli quittée avec Accueil (vidéo comme audio). Le Wi-Fi reste actif écran éteint, donc un flux venant de l'autre
  téléphone ne se coupe pas. Toucher la notification rouvre l'appli. La flèche retour du lecteur arrête la lecture.
  Le nom d'un fichier du dossier sécurisé n'est pas affiché sur l'écran verrouillé.
- **Appli par défaut / « Ouvrir avec »** : LinkShare se déclare pour vidéo, audio, image, texte (fichiers locaux, `content://`
  ou `file://`), vidéo/audio en streaming (liens http/https), dossiers, Téléchargements et « Parcourir » (Réglages › Stockage).
  Pour en faire l'appli par défaut : ouvrir un fichier depuis une autre appli, choisir LinkShare puis « Toujours »
  (ou Réglages › Applis › LinkShare › Ouvrir par défaut).
- **Partager** (menu Android) fichiers et dossiers : appui long pour sélectionner, puis « Partager ». Les dossiers partent
  en ZIP (un ZIP par dossier). Aussi disponible dans le menu ⋮ des récents (fichiers).
- **Logo** : `res/drawable/ic_launcher_*` (icône adaptative + monochrome), `ic_logo` (appli, lecteur audio), `ic_stat_logo`
  (barre d'état) ; sources dans `branding/` (SVG + PNG 512).

## Réseau
Même Wi-Fi, ou B connecté au point d'accès de A (le plus rapide, sans routeur).

## À faire ensuite
- TLS (certificat auto-signé épinglé dans le QR) : actuellement HTTP + jeton aléatoire de 192 bits.
- Wi-Fi Direct (WifiP2pManager) pour une connexion sans routeur ni hotspot manuel.
- Choix des dossiers partagés + écran de consentement / révocation.
- Visionneuse texte/PDF, reprise des transferts, installation directe des APK.
