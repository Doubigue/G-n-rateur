package com.linkshare.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.provider.Settings
import android.text.format.Formatter
import android.view.WindowManager
import android.widget.Toast
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.common.MediaMetadata
import android.content.ComponentName
import com.linkshare.server.PlaybackService
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import com.linkshare.core.*
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp
import com.linkshare.R
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import com.linkshare.server.ShareService

@Composable
fun LinkShareApp(vm: MainViewModel) {
    val ex: ExplorerViewModel = viewModel()
    // Coffre ouvert : pas de captures d'écran ni d'aperçu dans les apps récentes
    val act = LocalContext.current.findActivity()
    DisposableEffect(VaultLock.unlocked) {
        if (VaultLock.unlocked) act?.window?.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        onDispose { act?.window?.clearFlags(WindowManager.LayoutParams.FLAG_SECURE) }
    }
    var splash by rememberSaveable { mutableStateOf(ExternalOpen.uri == null && ExternalOpen.folder == null) }
    Crossfade(targetState = splash, label = "splash") { showSplash ->
        if (showSplash) SplashScreen { splash = false }
        else when {
            ExternalOpen.uri != null -> ExternalViewerScreen()
            ex.viewing != null -> LocalViewerScreen(ex)
            vm.viewer != null -> ViewerScreen(vm)
            vm.client != null -> RemoteScreen(vm)
            else -> FilesApp(vm)
        }
    }
}

@Composable
fun SplashScreen(onDone: () -> Unit) {
    val scale = remember { Animatable(0.5f) }
    val logoAlpha = remember { Animatable(0f) }
    val credit = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        launch { scale.animateTo(1f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow)) }
        launch { logoAlpha.animateTo(1f, tween(700)) }
        delay(500)
        credit.animateTo(1f, tween(700))
        delay(1300)
        onDone()
    }
    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF1E6FEB), Color(0xFF123F96))))
            .systemBarsPadding()
    ) {
        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier.size(190.dp).scale(scale.value).alpha(logoAlpha.value)
                    .clip(CircleShape).background(Color.White.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center,
            ) {
                Image(painterResource(R.drawable.ic_launcher_foreground), null, Modifier.size(170.dp))
            }
            Spacer(Modifier.height(20.dp))
            Text("LinkShare", Modifier.alpha(logoAlpha.value), color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.ExtraBold)
            Text("Partage ultra-rapide", Modifier.alpha(logoAlpha.value), color = Color.White.copy(alpha = 0.8f), fontSize = 15.sp)
        }
        Column(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 36.dp).alpha(credit.value),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("Created by", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
            Text("DL VIBE STUDIO", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 3.sp)
            Text("Doubigue Loubikoa", color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp)
        }
    }
}

internal fun ensureAllFiles(ctx: Context): Boolean {
    if (Environment.isExternalStorageManager()) return true
    ctx.startActivity(
        Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${ctx.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    )
    Toast.makeText(ctx, "Autorise l'accès à tous les fichiers, puis réessaie", Toast.LENGTH_LONG).show()
    return false
}

/** Demande une seule fois d'ignorer l'optimisation de batterie (évite que le système tue le partage). */
internal fun askBatteryExemptionOnce(ctx: Context) {
    val prefs = ctx.getSharedPreferences("linkshare", Context.MODE_PRIVATE)
    val pm = ctx.getSystemService(PowerManager::class.java)
    if (pm.isIgnoringBatteryOptimizations(ctx.packageName) || prefs.getBoolean("battery_asked", false)) return
    prefs.edit().putBoolean("battery_asked", true).apply()
    ctx.startActivity(
        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    )
}

internal fun needsNotifPermission(ctx: Context) =
    Build.VERSION.SDK_INT >= 33 &&
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED

internal fun qr(text: String): Bitmap {
    val n = 640
    val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, n, n)
    return Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888).also { b ->
        for (x in 0 until n) for (y in 0 until n)
            b.setPixel(x, y, if (m.get(x, y)) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
    }
}

internal fun scan(ctx: Context, onResult: (Connection) -> Unit) {
    val opts = GmsBarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()
    GmsBarcodeScanning.getClient(ctx, opts).startScan()
        .addOnSuccessListener { b ->
            val c = Connection.parse(b.rawValue ?: "")
            if (c != null) onResult(c) else Toast.makeText(ctx, "QR non reconnu", Toast.LENGTH_SHORT).show()
        }
}


@Composable
fun ViewerScreen(vm: MainViewModel) {
    val e = vm.viewer ?: return
    val url = vm.client?.fileUrl(e.path) ?: return
    fun close() { PlayerHost.stop(); vm.viewer = null }
    BackHandler { close() }
    Column(Modifier.fillMaxSize().background(LS.Bg).systemBarsPadding()) {
        Row(Modifier.padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ close() }) { Icon(Ic.Back, "Retour", tint = LS.Blue) }
            Text(e.name, maxLines = 1, color = LS.Blue, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
        }
        if (e.isImage()) AsyncImage(url, e.name, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
        else Player(url, e.name)
    }
}

/** Contrôleur de la lecture en cours (renseigné par [Player]) : sert à arrêter la lecture quand on ferme le lecteur. */
internal object PlayerHost {
    var controller: MediaController? = null

    /** Arrête la lecture et retire la notification (fermeture du lecteur par l'utilisateur). */
    fun stop() {
        val c = controller ?: return
        c.stop()
        c.clearMediaItems()
    }
}

/**
 * Lecteur branché sur [PlaybackService] : la lecture continue en arrière-plan (écran éteint, appli quittée avec
 * Accueil), avec les commandes dans la barre de notification et sur l'écran verrouillé, vidéo comme audio.
 * Fermer le lecteur (flèche retour) arrête la lecture : voir [PlayerHost.stop].
 */
@Composable
internal fun Player(url: String, title: String = "") {
    val ctx = LocalContext.current
    var controller by remember { mutableStateOf<MediaController?>(null) }
    val audioOnly = remember(title) { categoryOfExt(title.substringAfterLast('.', "").lowercase()) == Category.MUSIC }
    // Android 13+ : sans cette autorisation, la notification de lecture n'apparaît pas
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) { if (needsNotifPermission(ctx)) notif.launch(Manifest.permission.POST_NOTIFICATIONS) }
    DisposableEffect(url) {
        var disposed = false
        val token = SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        val future = MediaController.Builder(ctx, token).buildAsync()
        future.addListener({
            if (disposed) return@addListener
            val c = runCatching { future.get() }.getOrNull() ?: return@addListener
            // Même média déjà en cours (activité recréée, retour depuis l'écran d'accueil) : on se rattache
            // sans relancer la lecture, au lieu de repartir de zéro.
            val already = c.currentMediaItem?.localConfiguration?.uri?.toString() == url
            if (!already) {
                val item = MediaItem.Builder()
                    .setUri(url)
                    .setRequestMetadata(MediaItem.RequestMetadata.Builder().setMediaUri(Uri.parse(url)).build())
                    .setMediaMetadata(MediaMetadata.Builder().setTitle(title).build())
                    .build()
                c.setMediaItem(item); c.prepare(); c.playWhenReady = true
            }
            PlayerHost.controller = c
            controller = c
        }, ContextCompat.getMainExecutor(ctx))
        onDispose {
            disposed = true
            if (PlayerHost.controller === controller) PlayerHost.controller = null
            controller = null
            MediaController.releaseFuture(future)
        }
    }
    AndroidView(
        factory = {
            PlayerView(it).apply {
                defaultArtwork = ContextCompat.getDrawable(it, R.drawable.ic_logo) // pochette des fichiers audio
                if (audioOnly) { controllerShowTimeoutMs = 0; controllerHideOnTouch = false } // commandes toujours visibles
            }
        },
        update = { it.player = controller },
        modifier = Modifier.fillMaxSize(),
    )
}
