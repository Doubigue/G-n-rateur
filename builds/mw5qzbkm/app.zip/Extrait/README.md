# Extrait

Appli Android (Kotlin + Jetpack Compose) qui extrait le texte d'une ou de plusieurs centaines d'images, en gardant la disposition du texte.

- OCR local avec ML Kit (alphabet latin, hors ligne)
- Choix multiple d'images, lecture une par une avec progression
- Recadrage et rotation avant lecture (réglage appliqué à toutes les images choisies)
- Écran de lecture fidèle à l'image : couleur de fond, couleur du texte, gras et titres plus grands relevés dans l'image, texte sélectionnable
- Icône copier, partage en .txt, taille de texte réglable

## Compiler
Poussez le dossier sur la branche `main` d'un dépôt GitHub : le workflow `.github/workflows/build.yml` produit l'APK (onglet Actions > artefact `Extrait-debug-apk`).
