package com.dlvibe.extrait.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Crop
import androidx.compose.material.icons.rounded.RotateRight
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dlvibe.extrait.Edit
import com.dlvibe.extrait.Ocr
import com.dlvibe.extrait.ScanViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.abs

private data class CropBox(val l: Float = 0f, val t: Float = 0f, val r: Float = 1f, val b: Float = 1f)

/** Recadrage + rotation. Le réglage s'applique à toutes les images choisies. */
@Composable
fun CropScreen(
    vm: ScanViewModel,
    modifier: Modifier = Modifier,
    onCancel: () -> Unit,
    onConfirm: (Edit) -> Unit
) {
    val ctx = LocalContext.current
    val uri = vm.pending.first()
    val count = vm.pending.size
    var rotation by rememberSaveable { mutableIntStateOf(0) }
    var crop by remember { mutableStateOf(CropBox()) }

    val bmp by produceState<Bitmap?>(null, uri, rotation) {
        value = withContext(Dispatchers.IO) { Ocr.preview(ctx, uri, rotation) }
    }

    Column(modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 8.dp, end = 8.dp, top = 4.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onCancel) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Annuler", tint = Ink)
            }
            Column(Modifier.weight(1f)) {
                Text("Recadrer", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink)
                Text(
                    if (count > 1) "Appliqué aux $count images" else "Glissez les coins ou les bords",
                    fontSize = 13.sp,
                    color = Muted
                )
            }
            IconButton(onClick = { rotation = (rotation + 90) % 360; crop = CropBox() }) {
                Icon(Icons.Rounded.RotateRight, contentDescription = "Pivoter", tint = Ink)
            }
        }

        Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp), contentAlignment = Alignment.Center) {
            val b = bmp
            if (b == null) {
                CircularProgressIndicator(color = Cobalt)
            } else {
                val img = remember(b) { b.asImageBitmap() }
                BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    val k = minOf(maxWidth.value / b.width, maxHeight.value / b.height)
                    Box(Modifier.size((b.width * k).dp, (b.height * k).dp)) {
                        Image(bitmap = img, contentDescription = null, modifier = Modifier.fillMaxSize())
                        CropOverlay(crop) { crop = it }
                    }
                }
            }
        }

        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(
                onClick = { crop = CropBox() },
                modifier = Modifier.height(50.dp),
                shape = RoundedCornerShape(14.dp)
            ) { Text("Tout garder", color = Ink) }
            Spacer(Modifier.width(12.dp))
            Button(
                onClick = { onConfirm(Edit(rotation, crop.l, crop.t, crop.r, crop.b)) },
                modifier = Modifier.weight(1f).height(50.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Cobalt, contentColor = Color.White)
            ) {
                Icon(Icons.Rounded.Crop, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Lire le texte", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun CropOverlay(crop: CropBox, onChange: (CropBox) -> Unit) {
    val current by rememberUpdatedState(crop)
    Canvas(
        Modifier.fillMaxSize().pointerInput(Unit) {
            var mode = 0 // bits : 1 = gauche, 2 = haut, 4 = droite, 8 = bas ; 15 = déplacer
            val touch = 36.dp.toPx()
            detectDragGestures(
                onDragStart = { p ->
                    val c = current
                    val l = c.l * size.width; val t = c.t * size.height
                    val r = c.r * size.width; val b = c.b * size.height
                    val inX = p.x in (l - touch)..(r + touch)
                    val inY = p.y in (t - touch)..(b + touch)
                    var m = 0
                    if (abs(p.x - l) < touch && inY) m = m or 1
                    if (abs(p.y - t) < touch && inX) m = m or 2
                    if (abs(p.x - r) < touch && inY) m = m or 4
                    if (abs(p.y - b) < touch && inX) m = m or 8
                    if (m == 0 && p.x in l..r && p.y in t..b) m = 15
                    mode = m
                },
                onDrag = { change, d ->
                    change.consume()
                    val c = current
                    val dx = d.x / size.width
                    val dy = d.y / size.height
                    val min = 0.08f
                    onChange(
                        if (mode == 15) {
                            val w = c.r - c.l
                            val h = c.b - c.t
                            val nl = (c.l + dx).coerceIn(0f, 1f - w)
                            val nt = (c.t + dy).coerceIn(0f, 1f - h)
                            CropBox(nl, nt, nl + w, nt + h)
                        } else {
                            c.copy(
                                l = if ((mode and 1) != 0) (c.l + dx).coerceIn(0f, c.r - min) else c.l,
                                t = if ((mode and 2) != 0) (c.t + dy).coerceIn(0f, c.b - min) else c.t,
                                r = if ((mode and 4) != 0) (c.r + dx).coerceIn(c.l + min, 1f) else c.r,
                                b = if ((mode and 8) != 0) (c.b + dy).coerceIn(c.t + min, 1f) else c.b
                            )
                        }
                    )
                }
            )
        }
    ) {
        val w = size.width; val h = size.height
        val l = crop.l * w; val t = crop.t * h; val r = crop.r * w; val b = crop.b * h
        val dim = Color(0x99000000)
        drawRect(dim, Offset(0f, 0f), Size(w, t))
        drawRect(dim, Offset(0f, b), Size(w, h - b))
        drawRect(dim, Offset(0f, t), Size(l, b - t))
        drawRect(dim, Offset(r, t), Size(w - r, b - t))
        val grid = Color(0x66FFFFFF)
        for (i in 1..2) {
            val gx = l + (r - l) * i / 3f
            val gy = t + (b - t) * i / 3f
            drawLine(grid, Offset(gx, t), Offset(gx, b), 1.dp.toPx())
            drawLine(grid, Offset(l, gy), Offset(r, gy), 1.dp.toPx())
        }
        drawRect(Beam, Offset(l, t), Size(r - l, b - t), style = Stroke(2.dp.toPx()))
        for (o in listOf(Offset(l, t), Offset(r, t), Offset(l, b), Offset(r, b))) drawCircle(Beam, 9.dp.toPx(), o)
    }
}
