package com.dlvibe.extrait

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File

object Actions {
    /** Copie dans le presse-papiers. Renvoie false si le texte est trop volumineux. */
    fun copy(ctx: Context, text: String): Boolean = try {
        val cm = ctx.getSystemService(ClipboardManager::class.java)
        cm.setPrimaryClip(ClipData.newPlainText("Extrait", text))
        true
    } catch (e: Exception) {
        false
    }

    /** Partage le texte sous forme de fichier .txt (adapté aux très gros résultats). */
    fun share(ctx: Context, text: String) {
        val dir = File(ctx.cacheDir, "exports").apply { mkdirs() }
        val file = File(dir, "extrait.txt").apply { writeText(text) }
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(send, "Partager le texte"))
    }
}
