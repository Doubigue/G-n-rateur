package com.dlvibe.extrait.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Ink = Color(0xFF0E1530)
val InkSoft = Color(0xFF1C2A5E)
val Beam = Color(0xFFFFC857)
val Cobalt = Color(0xFF2447F5)
val Page = Color(0xFFEEF2F8)
val Muted = Color(0xFF5B6784)
val Line = Color(0xFFC9D1E3)

@Composable
fun ExtraitTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Cobalt,
            onPrimary = Color.White,
            secondary = Beam,
            background = Page,
            surface = Color.White,
            onSurface = Ink,
            onBackground = Ink
        ),
        content = content
    )
}
