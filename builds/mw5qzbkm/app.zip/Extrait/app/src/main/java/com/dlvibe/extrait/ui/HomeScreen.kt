@file:OptIn(ExperimentalMaterial3Api::class)

package com.dlvibe.extrait.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddPhotoAlternate
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dlvibe.extrait.ScanItem
import com.dlvibe.extrait.ScanViewModel

@Composable
fun HomeScreen(
    vm: ScanViewModel,
    listState: LazyListState,
    onPick: () -> Unit,
    onOpen: (Int) -> Unit,
    onCopy: (String) -> Unit
) {
    val items = vm.items
    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 40.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(Modifier.padding(top = 8.dp, bottom = 4.dp)) {
                Text("Extrait", fontSize = 34.sp, fontWeight = FontWeight.Black, color = Ink, letterSpacing = (-1).sp)
                Text("Le texte de vos images, mis en page comme l’original.", color = Muted, fontSize = 15.sp)
            }
        }
        item { HeroCard(running = vm.running, onPick = onPick) }
        if (vm.running) {
            item { ProgressCard(done = items.size, total = vm.total, onCancel = vm::cancel) }
        } else if (items.isNotEmpty()) {
            item {
                SummaryCard(
                    count = items.size,
                    words = items.sumOf { it.words },
                    onOpen = { onOpen(-1) },
                    onCopy = { onCopy(vm.textFor(-1)) }
                )
            }
        }
        itemsIndexed(items, key = { _, item -> item.index }) { i, item ->
            ResultRow(item = item, onOpen = { onOpen(i) }, onCopy = { onCopy(vm.textFor(i)) })
        }
    }
}

@Composable
private fun WhiteCard(
    onClick: (() -> Unit)? = null,
    radius: Dp = 24.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(radius)
    val colors = CardDefaults.cardColors(containerColor = Color.White)
    val elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    if (onClick != null) {
        Card(onClick = onClick, shape = shape, colors = colors, elevation = elevation, modifier = Modifier.fillMaxWidth(), content = content)
    } else {
        Card(shape = shape, colors = colors, elevation = elevation, modifier = Modifier.fillMaxWidth(), content = content)
    }
}

@Composable
private fun HeroCard(running: Boolean, onPick: () -> Unit) {
    Card(
        shape = RoundedCornerShape(30.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(Modifier.background(Brush.linearGradient(listOf(Ink, InkSoft)))) {
            Column(Modifier.padding(22.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            "Lisez le texte de vos images",
                            color = Color.White,
                            fontSize = 25.sp,
                            lineHeight = 29.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = (-0.5).sp
                        )
                        Spacer(Modifier.height(10.dp))
                        Text(
                            "Une photo ou des centaines. La mise en page est conservée et tout reste sur votre téléphone.",
                            color = Color(0xFFB9C3E3),
                            fontSize = 14.sp,
                            lineHeight = 20.sp
                        )
                    }
                    Spacer(Modifier.width(16.dp))
                    ScanPage(running, Modifier.size(84.dp, 108.dp))
                }
                Spacer(Modifier.height(20.dp))
                Button(
                    onClick = onPick,
                    enabled = !running,
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Beam,
                        contentColor = Ink,
                        disabledContainerColor = Color(0x33FFFFFF),
                        disabledContentColor = Color(0x99FFFFFF)
                    )
                ) {
                    Icon(Icons.Rounded.AddPhotoAlternate, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Choisir des images", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }
        }
    }
}

/** Petite page avec un faisceau qui balaie pendant la lecture. */
@Composable
private fun ScanPage(running: Boolean, modifier: Modifier) {
    val transition = rememberInfiniteTransition(label = "scan")
    val anim by transition.animateFloat(
        initialValue = 0.06f,
        targetValue = 0.94f,
        animationSpec = infiniteRepeatable(tween(1600, easing = LinearEasing), RepeatMode.Reverse),
        label = "beam"
    )
    val p = if (running) anim else 0.42f
    Canvas(modifier.clip(RoundedCornerShape(14.dp))) {
        val w = size.width
        val h = size.height
        drawRect(Color.White.copy(alpha = 0.96f))
        val bars = listOf(0.7f, 0.9f, 0.55f, 0.85f, 0.4f, 0.8f, 0.65f)
        var y = h * 0.14f
        bars.forEach { f ->
            drawRoundRect(
                color = Line,
                topLeft = Offset(w * 0.12f, y),
                size = Size(w * 0.76f * f, 5.dp.toPx()),
                cornerRadius = CornerRadius(3.dp.toPx())
            )
            y += h * 0.115f
        }
        val by = h * p
        val glow = 26.dp.toPx()
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color.Transparent, Beam.copy(alpha = 0.55f)),
                startY = by - glow,
                endY = by
            ),
            topLeft = Offset(0f, by - glow),
            size = Size(w, glow)
        )
        drawLine(Beam, Offset(0f, by), Offset(w, by), strokeWidth = 2.5.dp.toPx())
    }
}

@Composable
private fun ProgressCard(done: Int, total: Int, onCancel: () -> Unit) {
    val progress by animateFloatAsState(if (total == 0) 0f else done / total.toFloat(), label = "progress")
    WhiteCard {
        Column(Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Lecture en cours", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Ink)
                    Text("$done sur $total images", color = Muted, fontSize = 14.sp)
                }
                TextButton(onClick = onCancel) { Text("Arrêter") }
            }
            Spacer(Modifier.height(12.dp))
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                color = Cobalt,
                trackColor = Line
            )
        }
    }
}

@Composable
private fun SummaryCard(count: Int, words: Int, onOpen: () -> Unit, onCopy: () -> Unit) {
    WhiteCard(onClick = onOpen) {
        Column(Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(44.dp).clip(CircleShape).background(Color(0x1A2447F5)),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Rounded.Check, contentDescription = null, tint = Cobalt) }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("Extraction terminée", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Ink)
                    Text(
                        "$count image${if (count > 1) "s" else ""} · $words mot${if (words > 1) "s" else ""}",
                        color = Muted,
                        fontSize = 14.sp
                    )
                }
                FilledIconButton(
                    onClick = onCopy,
                    modifier = Modifier.size(46.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(containerColor = Ink, contentColor = Beam)
                ) { Icon(Icons.Rounded.ContentCopy, contentDescription = "Copier tout le texte") }
            }
            Spacer(Modifier.height(16.dp))
            Button(
                onClick = onOpen,
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Cobalt, contentColor = Color.White)
            ) {
                Icon(Icons.Rounded.Description, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Ouvrir le texte", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun ResultRow(item: ScanItem, onOpen: () -> Unit, onCopy: () -> Unit) {
    val preview = item.text.lineSequence().firstOrNull { it.isNotBlank() }?.trim()
    val canCopy = item.text.isNotBlank()
    WhiteCard(onClick = onOpen, radius = 18.dp) {
        Row(
            Modifier.padding(start = 14.dp, top = 12.dp, bottom = 12.dp, end = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(Page),
                contentAlignment = Alignment.Center
            ) { Text("${item.index + 1}", fontWeight = FontWeight.Bold, color = Cobalt, fontSize = 14.sp) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(item.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, color = Ink, fontSize = 15.sp)
                Text(
                    when {
                        item.failed -> "Lecture impossible"
                        preview == null -> "Aucun texte détecté"
                        else -> preview
                    },
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = if (item.failed) Color(0xFFB3261E) else Muted,
                    fontSize = 13.sp
                )
            }
            IconButton(onClick = onCopy, enabled = canCopy) {
                Icon(
                    Icons.Rounded.ContentCopy,
                    contentDescription = "Copier le texte de cette image",
                    tint = if (canCopy) Cobalt else Line
                )
            }
        }
    }
}
