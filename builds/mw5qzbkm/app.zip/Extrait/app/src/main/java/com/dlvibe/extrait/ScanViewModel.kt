package com.dlvibe.extrait

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class ScanItem(
    val index: Int,
    val name: String,
    val text: String,
    val failed: Boolean = false,
    val runs: List<Run> = emptyList(),
    val bg: Int = 0xFFFFFFFF.toInt()
) {
    val words: Int = if (text.isBlank()) 0 else text.trim().split(Regex("\\s+")).size
}

class ScanViewModel(app: Application) : AndroidViewModel(app) {
    val items = mutableStateListOf<ScanItem>()

    var total by mutableIntStateOf(0)
        private set
    var running by mutableStateOf(false)
        private set

    /** null = accueil, -1 = tout le texte, sinon position de l'image. */
    var viewing by mutableStateOf<Int?>(null)

    /** Images choisies, en attente de recadrage. */
    var pending by mutableStateOf<List<Uri>>(emptyList())

    private var job: Job? = null

    fun start(uris: List<Uri>, edit: Edit = Edit()) {
        if (uris.isEmpty()) return
        pending = emptyList()
        job?.cancel()
        items.clear()
        total = uris.size
        running = true
        viewing = null
        job = viewModelScope.launch {
            val ctx = getApplication<Application>()
            uris.forEachIndexed { i, uri ->
                val item = withContext(Dispatchers.Default) {
                    val name = Ocr.displayName(ctx, uri) ?: "Image ${i + 1}"
                    try {
                        val laid = Ocr.read(ctx, uri, edit)
                        ScanItem(i, name, laid.text, runs = laid.runs, bg = laid.bg)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Throwable) {
                        ScanItem(i, name, "", failed = true)
                    }
                }
                items.add(item)
            }
            running = false
        }
    }

    fun cancel() {
        job?.cancel()
        running = false
    }

    fun textFor(index: Int): String {
        if (index >= 0) return items.getOrNull(index)?.text.orEmpty()
        if (items.size == 1) return items[0].text
        return items.joinToString("\n\n") {
            "━━ ${it.index + 1}. ${it.name} ━━\n\n" + it.text.ifBlank { "(aucun texte détecté)" }
        }
    }
}
