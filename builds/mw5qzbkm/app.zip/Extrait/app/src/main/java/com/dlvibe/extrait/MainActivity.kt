package com.dlvibe.extrait

import android.graphics.Color as AColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.lifecycle.viewmodel.compose.viewModel
import com.dlvibe.extrait.ui.CropScreen
import com.dlvibe.extrait.ui.ExtraitTheme
import com.dlvibe.extrait.ui.HomeScreen
import com.dlvibe.extrait.ui.Page
import com.dlvibe.extrait.ui.ViewerScreen
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(AColor.TRANSPARENT, AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.light(AColor.TRANSPARENT, AColor.TRANSPARENT)
        )
        setContent { ExtraitTheme { App() } }
    }
}

@Composable
private fun App(vm: ScanViewModel = viewModel()) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val snack = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    // L'écran reste allumé pendant la lecture de nombreuses images.
    DisposableEffect(vm.running) {
        view.keepScreenOn = vm.running
        onDispose { view.keepScreenOn = false }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) vm.pending = uris
    }

    val copy: (String) -> Unit = { text ->
        val ok = Actions.copy(ctx, text)
        scope.launch {
            snack.currentSnackbarData?.dismiss()
            snack.showSnackbar(if (ok) "Texte copié" else "Texte trop volumineux : utilisez Partager")
        }
    }

    BackHandler(enabled = vm.pending.isNotEmpty()) { vm.pending = emptyList() }
    BackHandler(enabled = vm.viewing != null && vm.pending.isEmpty()) { vm.viewing = null }

    Scaffold(containerColor = Page, snackbarHost = { SnackbarHost(snack) }) { pad ->
        if (vm.pending.isNotEmpty()) {
            CropScreen(
                vm = vm,
                modifier = Modifier.padding(pad),
                onCancel = { vm.pending = emptyList() },
                onConfirm = { vm.start(vm.pending, it) }
            )
            return@Scaffold
        }
        AnimatedContent(
            targetState = vm.viewing,
            modifier = Modifier.padding(pad),
            transitionSpec = {
                if (targetState != null && initialState == null) {
                    (slideInHorizontally { it / 4 } + fadeIn()) togetherWith fadeOut()
                } else {
                    fadeIn() togetherWith (slideOutHorizontally { it / 4 } + fadeOut())
                }
            },
            label = "screen"
        ) { v ->
            if (v == null) {
                HomeScreen(
                    vm = vm,
                    listState = listState,
                    onPick = { picker.launch("image/*") },
                    onOpen = { vm.viewing = it },
                    onCopy = copy
                )
            } else {
                ViewerScreen(
                    vm = vm,
                    index = v,
                    onBack = { vm.viewing = null },
                    onCopy = copy,
                    onShare = { Actions.share(ctx, it) }
                )
            }
        }
    }
}
