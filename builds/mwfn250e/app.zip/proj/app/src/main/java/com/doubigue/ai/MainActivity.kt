package com.doubigue.ai

import android.content.Intent
import android.os.Bundle
import androidx.compose.runtime.mutableIntStateOf
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.graphics.Color
import com.doubigue.ai.ui.DoubigueApp

class MainActivity : ComponentActivity() {
    companion object {
        const val EXTRA_AUTO_LISTEN = "auto_listen"
        /** Incrémenté quand le tiroir demande d'écouter dès l'ouverture de l'assistant. */
        val listenRequest = mutableIntStateOf(0)
        /** Vrai quand l'activité vient d'être détruite par une rotation : on ne rejoue pas la bienvenue. */
        @Volatile private var skipNextWelcome = false
    }

    override fun onStop() {
        if (isChangingConfigurations) skipNextWelcome = true
        super.onStop()
    }

    private fun handleIntent(i: Intent?) {
        if (i?.getBooleanExtra(EXTRA_AUTO_LISTEN, false) == true) { listenRequest.intValue += 1; i.removeExtra(EXTRA_AUTO_LISTEN) }
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); handleIntent(intent) }

    override fun onStart() {
        super.onStart()
        if (skipNextWelcome) { skipNextWelcome = false; return }
        com.doubigue.ai.events.EventSounds.playWelcomeOnce(applicationContext)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleIntent(intent)
        runCatching { com.doubigue.ai.data.BackupManager.applyPendingRestore(applicationContext) }
        window.statusBarColor = android.graphics.Color.rgb(8, 11, 18)
        window.navigationBarColor = android.graphics.Color.rgb(8, 11, 18)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Color(0xFF78DCE8), background = Color(0xFF080B12), surface = Color(0xFF111827)
            )) { DoubigueApp() }
        }
    }
}
