package com.doubigue.ai.events

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.room.Room
import com.doubigue.ai.MainActivity
import com.doubigue.ai.R
import com.doubigue.ai.data.AssistantDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.io.File

/**
 * Annonce sonore quand tu ouvres une application depuis les menus du téléphone (même sans commande dans l'assistant) :
 * son personnel de l'app s'il existe, sinon le son « Application ouverte (par défaut) ».
 * Utilise l'accès « Données d'utilisation » (déjà demandé pour savoir si une app est ouverte). Rien n'est enregistré.
 */
class AppWatchService : Service() {
    private lateinit var thread: HandlerThread
    private lateinit var handler: Handler
    private var lastPkg: String? = null
    private val lastAnnounced = HashMap<String, Long>()
    private var homePkgs: Set<String> = emptySet()
    private var db: AssistantDatabase? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val tick = object : Runnable { override fun run() { try { poll() } catch (_: Throwable) {}; handler.postDelayed(this, 700) } }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { EventSounds.setWatchEnabled(this, false); stopSelf(); return START_NOT_STICKY }
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Annonce des applications", NotificationManager.IMPORTANCE_MIN))
        try {
            val n = notification()
            if (Build.VERSION.SDK_INT >= 34) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            else startForeground(NOTIF_ID, n)
        } catch (_: Exception) { stopSelf(); return }
        homePkgs = packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)
            .map { it.activityInfo.packageName }.toSet()
        thread = HandlerThread("doubigue-appwatch").also { it.start() }
        handler = Handler(thread.looper)
        handler.post(tick)
    }

    private fun notification(): Notification {
        val open = PendingIntent.getActivity(this, 21, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 22, Intent(this, AppWatchService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_doubigue)
            .setContentTitle("DOUBIGUE AI : annonce des applications active")
            .setContentIntent(open).setOngoing(true).setPriority(NotificationCompat.PRIORITY_MIN)
            .addAction(0, "Arrêter", stop).build()
    }

    private fun poll() {
        val usm = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val events = usm.queryEvents(now - 2500, now)
        val e = UsageEvents.Event()
        val resumed = if (Build.VERSION.SDK_INT >= 29) UsageEvents.Event.ACTIVITY_RESUMED else UsageEvents.Event.MOVE_TO_FOREGROUND
        var newest: String? = null
        while (events.hasNextEvent()) { events.getNextEvent(e); if (e.eventType == resumed) newest = e.packageName }
        val pkg = newest ?: return
        if (pkg == lastPkg) return
        lastPkg = pkg
        onForeground(pkg)
    }

    private fun onForeground(pkg: String) {
        if (pkg == packageName || pkg in homePkgs || pkg == "com.android.systemui") return
        if (packageManager.getLaunchIntentForPackage(pkg) == null) return      // fenêtres système, sélecteurs…
        if (AppOpenGate.recentlyHandled(pkg)) return                              // déjà annoncée par la voix / le tiroir
        val now = SystemClock.elapsedRealtime()
        if (now - (lastAnnounced[pkg] ?: -10_000L) < 4000L) return
        lastAnnounced[pkg] = now
        scope.launch {
            val cfg = try { database().appVoiceConfigDao().get(pkg) } catch (_: Throwable) { null }
            val custom = cfg?.openAudioUri
            if (!custom.isNullOrBlank() && File(custom).exists()) EventSounds.playPath(custom)
            else EventSounds.play(applicationContext, SoundEvent.APP_OPEN_DEFAULT)
        }
    }

    private fun database(): AssistantDatabase = db ?: Room.databaseBuilder(applicationContext, AssistantDatabase::class.java, "doubigue.db")
        .addMigrations(com.doubigue.ai.data.MIGRATION_1_2, com.doubigue.ai.data.MIGRATION_2_3, com.doubigue.ai.data.MIGRATION_3_4, com.doubigue.ai.data.MIGRATION_4_5)
        .build().also { db = it }

    override fun onDestroy() {
        if (::handler.isInitialized) handler.removeCallbacksAndMessages(null)
        if (::thread.isInitialized) thread.quitSafely()
        scope.cancel()
        try { db?.close() } catch (_: Exception) {}
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.doubigue.ai.events.WATCH_STOP"
        private const val CHANNEL = "doubigue_appwatch"
        private const val NOTIF_ID = 44
        fun start(c: Context) { EventSounds.setWatchEnabled(c, true); ContextCompat.startForegroundService(c, Intent(c, AppWatchService::class.java)) }
        fun stop(c: Context) { EventSounds.setWatchEnabled(c, false); c.stopService(Intent(c, AppWatchService::class.java)) }
    }
}
