package com.doubigue.ai.system

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.doubigue.ai.events.EventSounds
import com.doubigue.ai.events.SoundEvent

/**
 * Petit écran avec interrupteur pour la lampe, le Bluetooth (et le Wi-Fi sur Android ≤ 9).
 * Wi-Fi / Internet sur Android 10+ : on ouvre le panneau système (petit écran avec les interrupteurs),
 * car Android interdit aux applis d'activer/couper le Wi-Fi ou les données mobiles elles-mêmes.
 */
class QuickTogglesActivity : ComponentActivity() {
    companion object {
        const val EXTRA_KIND = "kind"

        fun show(c: Context, kind: String) {
            val flags = Intent.FLAG_ACTIVITY_NEW_TASK
            when {
                kind == "internet" && Build.VERSION.SDK_INT >= 29 ->
                    start(c, Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY).addFlags(flags))
                kind == "wifi" && Build.VERSION.SDK_INT >= 30 ->
                    start(c, Intent(Settings.Panel.ACTION_WIFI).addFlags(flags))
                kind == "wifi" && Build.VERSION.SDK_INT >= 29 ->
                    start(c, Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY).addFlags(flags))
                kind == "internet" -> start(c, Intent(Settings.ACTION_WIRELESS_SETTINGS).addFlags(flags))
                else -> start(c, Intent(c, QuickTogglesActivity::class.java).putExtra(EXTRA_KIND, kind).addFlags(flags))
            }
        }

        private fun start(c: Context, i: Intent) { try { c.startActivity(i) } catch (_: Exception) {} }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val kind = intent.getStringExtra(EXTRA_KIND) ?: "flash"
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF78DCE8), surface = Color(0xFF111A2A))) {
                Box(
                    Modifier.fillMaxSize().background(Color(0x99000000)).clickable { finish() },
                    contentAlignment = Alignment.Center
                ) {
                    Card(
                        Modifier.padding(32.dp).fillMaxWidth().clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { },
                        shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF111A2A))
                    ) {
                        Column(Modifier.padding(22.dp)) {
                            when (kind) {
                                "bluetooth" -> BluetoothToggle()
                                "wifi" -> WifiToggle()
                                else -> FlashToggle()
                            }
                            TextButton(onClick = { finish() }, modifier = Modifier.align(Alignment.End)) { Text("Fermer") }
                        }
                    }
                }
            }
        }
    }

    @Composable private fun ToggleRow(title: String, checked: Boolean, hint: String, onChange: (Boolean) -> Unit) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            Switch(checked = checked, onCheckedChange = onChange)
        }
        Text(if (checked) "Activé" else "Désactivé", color = Color(0xFF83DDE8), fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
        if (hint.isNotBlank()) Text(hint, color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
    }

    @Composable private fun FlashToggle() {
        val cm = remember { getSystemService(CAMERA_SERVICE) as CameraManager }
        val camId = remember {
            try { cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true } } catch (_: Exception) { null }
        }
        var on by remember { mutableStateOf(false) }
        DisposableEffect(Unit) {
            val cb = object : CameraManager.TorchCallback() {
                override fun onTorchModeChanged(cameraId: String, enabled: Boolean) { if (cameraId == camId) on = enabled }
            }
            cm.registerTorchCallback(cb, Handler(Looper.getMainLooper()))
            onDispose { cm.unregisterTorchCallback(cb) }
        }
        ToggleRow("Lampe torche", on, if (camId == null) "Aucune lampe détectée sur ce téléphone." else "") { v ->
            if (camId != null) {
                try { cm.setTorchMode(camId, v); EventSounds.play(this@QuickTogglesActivity, if (v) SoundEvent.FLASH_ON else SoundEvent.FLASH_OFF) } catch (_: Exception) {}
            }
        }
    }

    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    @Composable private fun BluetoothToggle() {
        val adapter = remember { (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter }
        var on by remember { mutableStateOf(adapter?.isEnabled == true) }
        DisposableEffect(Unit) {
            val r = object : BroadcastReceiver() {
                override fun onReceive(c: Context, i: Intent) { on = adapter?.isEnabled == true }
            }
            ContextCompat.registerReceiver(this@QuickTogglesActivity, r, IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED)
            onDispose { try { unregisterReceiver(r) } catch (_: Exception) {} }
        }
        val askEnable = {
            try { startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)) } catch (_: Exception) {}
        }
        val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> if (granted) askEnable() }
        val hint = if (adapter == null) "Pas de Bluetooth sur ce téléphone."
        else if (Build.VERSION.SDK_INT >= 33) "Android 13+ : pour couper le Bluetooth, les réglages s'ouvrent (les applis n'ont pas le droit de le couper)." else ""
        ToggleRow("Bluetooth", on, hint) { v ->
            if (adapter == null) return@ToggleRow
            if (v) {
                if (Build.VERSION.SDK_INT >= 31 && ContextCompat.checkSelfPermission(this@QuickTogglesActivity, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED)
                    perm.launch(Manifest.permission.BLUETOOTH_CONNECT)
                else askEnable()
            } else {
                if (Build.VERSION.SDK_INT >= 33) { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); finish() }
                else try { adapter.disable() } catch (_: Exception) { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
            }
        }
    }

    @Suppress("DEPRECATION")
    @Composable private fun WifiToggle() {
        // Atteint seulement sur Android ≤ 9 (sur 10+ le panneau système est ouvert à la place).
        val wm = remember { applicationContext.getSystemService(WIFI_SERVICE) as WifiManager }
        var on by remember { mutableStateOf(wm.isWifiEnabled) }
        ToggleRow("Wi-Fi", on, "") { v -> try { wm.isWifiEnabled = v; on = v } catch (_: Exception) {} }
    }
}
