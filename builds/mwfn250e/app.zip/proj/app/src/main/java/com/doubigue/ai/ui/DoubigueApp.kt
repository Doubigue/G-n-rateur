package com.doubigue.ai.ui

import android.Manifest
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.first
import com.doubigue.ai.data.MIGRATION_1_2
import com.doubigue.ai.data.AppVoiceConfigDao
import com.doubigue.ai.data.AppVoiceConfig
import com.doubigue.ai.data.AssistantDatabase
import com.doubigue.ai.audio.LocalAudioLibrary
import androidx.room.Room
import android.media.MediaPlayer
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlin.math.cos
import kotlin.math.sin
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.core.content.ContextCompat
import androidx.core.content.PermissionChecker
import com.doubigue.ai.apps.AppController
import com.doubigue.ai.apps.InstalledApp
import com.doubigue.ai.overlay.FloatingBubbleService
import com.doubigue.ai.system.PhoneTools
import com.doubigue.ai.voice.VoiceEngine

private val Bg = Color(0xFF080B12)
private val Panel = Color(0xFF111A2A)
private val Cyan = Color(0xFF83DDE8)

@Composable
fun DoubigueApp() {
    val context = LocalContext.current
    var page by remember { mutableStateOf("Accueil") }
    var status by remember { mutableStateOf("Prêt") }
    var transcript by remember { mutableStateOf("") }
    var command by remember { mutableStateOf("") }
    var listening by remember { mutableStateOf(false) }
    var apps by remember { mutableStateOf(emptyList<InstalledApp>()) }
    var selected by remember { mutableStateOf<InstalledApp?>(null) }
    var audioUri by remember { mutableStateOf<Uri?>(null) }
    var response by remember { mutableStateOf("Bonjour. Je suis DOUBIGUE AI.") }
    val controller = remember { AppController(context) }
    val database = remember { Room.databaseBuilder(context, AssistantDatabase::class.java, "doubigue.db").addMigrations(MIGRATION_1_2, com.doubigue.ai.data.MIGRATION_2_3, com.doubigue.ai.data.MIGRATION_3_4, com.doubigue.ai.data.MIGRATION_4_5).build() }
    val scope = rememberCoroutineScope()
    val tools = remember { PhoneTools(context) }
    val voice = remember { VoiceEngine(context, { heard -> transcript = heard; command = heard; listening = false }, { status = it }) }
    val cameraPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> if (!granted) response = "Autorisation caméra requise pour la lampe torche." }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> if (granted) { voice.listen(); listening = true } else status = "Autorisation microphone refusée" }
    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        audioUri = uri
        if (uri != null) try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
    }
    val startMic: () -> Unit = { if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PermissionChecker.PERMISSION_GRANTED) { voice.listen(); listening = true } else micPermission.launch(Manifest.permission.RECORD_AUDIO) }
    val listenRequest = com.doubigue.ai.MainActivity.listenRequest.intValue
    LaunchedEffect(listenRequest) { if (listenRequest > 0) { page = "Accueil"; startMic(); com.doubigue.ai.MainActivity.listenRequest.intValue = 0 } }
    DisposableEffect(Unit) { onDispose { voice.release() } }
    LaunchedEffect(page) { if (page == "Mes applications" || page == "Raccourcis") apps = controller.installedApps() }

    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel, primary = Cyan)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 18.dp)) {
                Row(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    IconButton(onClick = { page = if (page == "Accueil") "Paramètres" else "Accueil" }) { Icon(if (page == "Accueil") Icons.Default.Settings else Icons.Default.ArrowBack, null, tint = Color.White) }
                    Text("DOUBIGUE AI", color = Color.White, fontWeight = FontWeight.SemiBold, letterSpacing = 2.sp)
                    IconButton(onClick = { page = "Profil" }) { Icon(Icons.Default.AccountCircle, null, tint = Cyan) }
                }
                when (page) {
                    "Accueil" -> HomeContent(status, response, transcript, command, { command = it }, { runCommand(context, command, controller, tools, voice, database.appVoiceConfigDao(), database.learnedCommandDao(), scope) { response = it } }, startMic, listening)
                    "Paramètres" -> SettingsContent(onSelect = { page = it }, onBack = { page = "Accueil" })
                    "Mes applications" -> AppsContent(apps, selected, { selected = it }, database.appVoiceConfigDao(), { page = "Paramètres" }, { controller.openUsageAccessSettings() }, controller.hasUsageAccess())
                    "Apprentissage" -> LearningContent(database.learnedCommandDao())
                    "Raccourcis" -> ShortcutsContent(apps) { page = "Paramètres" }
                    "Effets et styles" -> EffectsContent { page = "Paramètres" }
                    "Actions" -> ActionsContent(context, onEnableBubble = { enableBubble(context) }, onFlashPermission = { cameraPermission.launch(Manifest.permission.CAMERA) }) { page = "Paramètres" }
                    "Sons d'événements" -> EventSoundsContent { page = "Paramètres" }
                    "Voix hors ligne" -> VoiceModelContent(voice) { page = "Paramètres" }
                    "Sauvegarde" -> BackupContent { page = "Paramètres" }
                    "Profil" -> ProfileContent { page = "Accueil" }
                    else -> SettingsContent(onSelect = { page = it }, onBack = { page = "Accueil" })
                }
            }
        }
    }
}

@Composable private fun HomeContent(status: String, response: String, transcript: String, command: String, onCommand: (String) -> Unit, onSend: () -> Unit, onMic: () -> Unit, listening: Boolean) {
    var localCommand by remember { mutableStateOf(command) }
    LaunchedEffect(command) { localCommand = command }
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(12.dp))
        Text(status, color = Cyan.copy(alpha = .8f), fontSize = 13.sp)
        Spacer(Modifier.weight(.7f))
        HologramSphere(listening, Modifier.size(260.dp).clickable { onMic() })
        Spacer(Modifier.height(28.dp))
        Text("Bonjour,", color = Color.White.copy(alpha = .75f), fontSize = 19.sp)
        Text("DOUBIGUE AI", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        Spacer(Modifier.height(10.dp))
        Text(response, color = Color(0xFFB7C4D8), fontSize = 14.sp)
        if (transcript.isNotBlank()) Text("« $transcript »", color = Cyan, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp))
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(30.dp)).background(Panel).padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
            TextField(value = localCommand, onValueChange = { localCommand = it; onCommand(it) }, modifier = Modifier.weight(1f), placeholder = { Text("Écrivez ou donnez une commande…", color = Color.Gray, fontSize = 13.sp) }, singleLine = true, colors = TextFieldDefaults.colors(focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent, focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent))
            IconButton(onClick = onMic) { Icon(Icons.Default.Mic, null, tint = Cyan) }
            IconButton(onClick = onSend) { Icon(Icons.Default.Send, null, tint = Color.White) }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable private fun HologramSphere(listening: Boolean, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "orb")
    val pulse by transition.animateFloat(initialValue = .94f, targetValue = 1.04f, animationSpec = infiniteRepeatable(tween(2400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")
    val rotation by transition.animateFloat(0f, 360f, infiniteRepeatable(tween(18000, easing = LinearEasing)), label = "rotation")
    Canvas(modifier) {
        val center = Offset(size.width / 2, size.height / 2)
        val radius = size.minDimension * .39f * pulse
        drawCircle(brush = Brush.radialGradient(listOf(Color(0x5578DCE8), Color(0x2271A6D8), Color.Transparent), center, radius * 1.45f), radius = radius * 1.45f, center = center)
        drawCircle(brush = Brush.radialGradient(listOf(Color(0x553B7895), Color(0x22213D59), Color(0x08080B12)), center - Offset(radius * .2f, radius * .25f), radius * 1.2f), radius = radius, center = center)
        drawCircle(Color(0x997DDDE8), radius, center, style = Stroke(width = 1.5.dp.toPx()))
        rotate(rotation, center) { drawOval(Color(0x667DDDE8), topLeft = Offset(center.x-radius*.9f, center.y-radius*.24f), size = androidx.compose.ui.geometry.Size(radius*1.8f, radius*.48f), style = Stroke(1.dp.toPx()), alpha = .7f) }
        rotate(-rotation * .7f, center) { drawOval(Color(0x557DDDE8), topLeft = Offset(center.x-radius*.25f, center.y-radius), size = androidx.compose.ui.geometry.Size(radius*.5f, radius*2), style = Stroke(1.dp.toPx()), alpha = .6f) }
        val micColor = if (listening) Color.White else Color(0xFFD6F4F7)
        drawRoundRect(micColor, Offset(center.x-radius*.10f, center.y-radius*.27f), androidx.compose.ui.geometry.Size(radius*.20f, radius*.39f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(radius*.1f))
        drawArc(micColor, 0f, 180f, false, Offset(center.x-radius*.20f, center.y-radius*.12f), androidx.compose.ui.geometry.Size(radius*.40f, radius*.40f), style = Stroke(2.dp.toPx()))
        drawLine(micColor, Offset(center.x, center.y+radius*.27f), Offset(center.x, center.y+radius*.39f), 2.dp.toPx())
        drawLine(micColor, Offset(center.x-radius*.12f, center.y+radius*.39f), Offset(center.x+radius*.12f, center.y+radius*.39f), 2.dp.toPx())
    }
}

@Composable private fun SettingsContent(onSelect: (String) -> Unit, onBack: () -> Unit) {
    val items = listOf(Triple("Mes applications", "Commandes vocales et sons personnalisés", Icons.Default.Apps), Triple("Apprentissage", "Créer des commandes personnalisées hors ligne", Icons.Default.Lightbulb), Triple("Raccourcis", "Tiroir circulaire et applications favorites", Icons.Default.Dashboard), Triple("Effets et styles", "Hologramme, couleurs et animations", Icons.Default.Palette), Triple("Actions", "Bienvenue, outils et annonces", Icons.Default.Bolt), Triple("Sons d'événements", "Bienvenue, verrouillage, empreinte, PIN, échecs…", Icons.Default.Lock), Triple("Voix hors ligne", "Importer le modèle Vosk français", Icons.Default.Mic), Triple("Sauvegarde", "Sauvegarder / restaurer (dossier Doubigue Ai Database)", Icons.Default.Save))
    Column(Modifier.fillMaxWidth()) {
        Text("Organisation des paramètres", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 12.dp))
        items.forEach { (title, subtitle, icon) -> Card(Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable { onSelect(title) }, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) { Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = Cyan, modifier = Modifier.size(30.dp)); Spacer(Modifier.width(16.dp)); Column { Text(title, color = Color.White, fontWeight = FontWeight.SemiBold); Text(subtitle, color = Color.LightGray, fontSize = 12.sp) }; Spacer(Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null, tint = Color.Gray) } } }
        Spacer(Modifier.height(10.dp)); OutlinedButton(onClick = onBack) { Text("Retour à l'assistant") }
    }
}


@Composable private fun LearningContent(dao: com.doubigue.ai.data.LearnedCommandDao) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val learned by dao.observeAll().collectAsState(initial = emptyList())
    val profiles = listOf("Général", "Travail", "Maison", "Nuit")
    var activeProfile by remember { mutableStateOf(context.getSharedPreferences("doubigue_local", Context.MODE_PRIVATE).getString("active_profile", "Général") ?: "Général") }
    var trigger by remember { mutableStateOf("") }
    var action by remember { mutableStateOf("") }
    var feedback by remember { mutableStateOf("Exemple : « Routine matin » → « ouvre WhatsApp puis joue ma musique ».") }
    val visibleCommands = learned.filter { it.profileName == activeProfile || it.profileName == "Général" }
    Column(Modifier.fillMaxSize()) {
        Text("Apprentissage local", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Crée des commandes et des routines multi-actions. Tout reste sur ce téléphone.", color = Color.LightGray, fontSize = 13.sp, modifier = Modifier.padding(vertical = 10.dp))
        Text("Profil actif", color = Color.White, fontWeight = FontWeight.SemiBold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            profiles.forEach { profile ->
                FilterChip(selected = activeProfile == profile, onClick = {
                    activeProfile = profile
                    context.getSharedPreferences("doubigue_local", Context.MODE_PRIVATE).edit().putString("active_profile", profile).apply()
                }, label = { Text(profile, fontSize = 11.sp) })
            }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = trigger, onValueChange = { trigger = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Phrase déclencheuse, ex. Routine matin") })
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = action, onValueChange = { action = it }, modifier = Modifier.fillMaxWidth(), minLines = 2, label = { Text("Action(s), ex. ouvre WhatsApp puis joue ma musique") })
        Spacer(Modifier.height(8.dp))
        Button(onClick = {
            val t = trigger.trim(); val a = action.trim()
            if (t.isBlank() || a.isBlank()) feedback = "Renseigne les deux champs."
            else if (com.doubigue.ai.voice.CommandRouter.normalize(t) == com.doubigue.ai.voice.CommandRouter.normalize(a)) feedback = "La phrase et l'action doivent être différentes."
            else scope.launch {
                val normalized = com.doubigue.ai.voice.CommandRouter.normalize(t)
                learned.filter { com.doubigue.ai.voice.CommandRouter.normalize(it.triggerPhrase) == normalized }.forEach { dao.delete(it.id) }
                dao.save(com.doubigue.ai.data.LearnedCommand(triggerPhrase = t, commandText = a, profileName = activeProfile))
                trigger = ""; action = ""; feedback = "Commande enregistrée dans le profil $activeProfile."
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("Enregistrer la commande / routine") }
        Text(feedback, color = Cyan, fontSize = 12.sp, modifier = Modifier.padding(vertical = 10.dp))
        Text("Commandes disponibles (${visibleCommands.size})", color = Color.White, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(vertical = 8.dp))
        LazyColumn {
            items(visibleCommands, key = { it.id }) { item ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("« ${item.triggerPhrase} »", color = Cyan, fontWeight = FontWeight.SemiBold)
                            Text("${item.profileName} · ${item.commandText}", color = Color.LightGray, fontSize = 12.sp)
                        }
                        IconButton(onClick = { scope.launch { dao.delete(item.id) } }) { Icon(Icons.Default.Delete, "Supprimer", tint = Color.LightGray) }
                    }
                }
            }
        }
    }
}

@Composable private fun AppsContent(
    apps: List<InstalledApp>,
    selected: InstalledApp?,
    onSelect: (InstalledApp?) -> Unit,
    dao: AppVoiceConfigDao,
    onBack: () -> Unit,
    onUsage: () -> Unit,
    usage: Boolean
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val audioLibrary = remember { LocalAudioLibrary(context) }
    var config by remember(selected?.packageName) { mutableStateOf<AppVoiceConfig?>(null) }
    var spokenName by remember(selected?.packageName) { mutableStateOf(selected?.label.orEmpty()) }
    var aliases by remember(selected?.packageName) { mutableStateOf("") }
    var smartToggle by remember(selected?.packageName) { mutableStateOf(true) }
    var openAudio by remember(selected?.packageName) { mutableStateOf<String?>(null) }
    var closeAudio by remember(selected?.packageName) { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf("") }
    var audioTarget by remember { mutableStateOf("open") }
    var mediaPlayer by remember { mutableStateOf<MediaPlayer?>(null) }

    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null && selected != null) {
            try {
                val file = audioLibrary.import(uri, selected.packageName.replace(".", "_") + "_" + audioTarget)
                if (audioTarget == "open") openAudio = file.absolutePath else closeAudio = file.absolutePath
                message = "Fichier audio importé localement."
            } catch (e: Exception) {
                message = "Import impossible : ${e.message ?: "erreur inconnue"}"
            }
        }
    }

    LaunchedEffect(selected?.packageName) {
        if (selected != null) {
            config = dao.get(selected.packageName)
            config?.let {
                spokenName = it.spokenName
                aliases = it.aliases
                smartToggle = it.smartToggle
                openAudio = it.openAudioUri
                closeAudio = it.closeAudioUri
            } ?: run {
                spokenName = selected.label
                aliases = ""
                smartToggle = true
                openAudio = null
                closeAudio = null
            }
            message = ""
        }
    }
    DisposableEffect(Unit) {
        onDispose { mediaPlayer?.release(); mediaPlayer = null }
    }

    fun preview(path: String?) {
        if (path.isNullOrBlank()) { message = "Aucun son associé à cet événement."; return }
        try {
            mediaPlayer?.release()
            mediaPlayer = MediaPlayer().apply {
                setDataSource(path)
                setOnCompletionListener { it.release(); mediaPlayer = null }
                prepare()
                start()
            }
            message = "Lecture de l'annonce…"
        } catch (e: Exception) {
            message = "Lecture impossible : fichier audio invalide ou inaccessible."
        }
    }

    Column(Modifier.fillMaxSize()) {
        Text("Mes applications", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        if (!usage) Card(Modifier.fillMaxWidth().padding(vertical = 8.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF3A2D1D))) {
            Column(Modifier.padding(12.dp)) {
                Text("Autorisation d'accès à l'utilisation", color = Color.White)
                Text("Requise pour différencier l'application au premier plan des applications en arrière-plan.", color = Color.LightGray, fontSize = 12.sp)
                TextButton(onClick = onUsage) { Text("Ouvrir les paramètres") }
            }
        }
        if (selected == null) {
            LazyColumn {
                items(apps) { app ->
                    Row(Modifier.fillMaxWidth().clickable { onSelect(app) }.padding(vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                        val bitmap = remember(app.packageName) { app.icon.toBitmap(72,72).asImageBitmap() }
                        Image(bitmap, contentDescription = app.label, modifier = Modifier.size(38.dp).clip(RoundedCornerShape(9.dp)))
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(app.label, color = Color.White)
                            Text(app.packageName, color = Color.Gray, fontSize = 10.sp)
                        }
                        Spacer(Modifier.weight(1f))
                        Icon(Icons.Default.ChevronRight, null, tint = Cyan)
                    }
                }
            }
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                item {
                    TextButton(onClick = { onSelect(null) }) { Text("← Toutes les applications") }
                    Text(selected.label, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(selected.packageName, color = Color.Gray, fontSize = 11.sp)
                    Text("Commande vocale principale", color = Color.LightGray, modifier = Modifier.padding(top = 14.dp))
                    OutlinedTextField(value = spokenName, onValueChange = { spokenName = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Nom prononcé") })
                    OutlinedTextField(value = aliases, onValueChange = { aliases = it }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp), minLines = 2, label = { Text("Variantes vocales (séparées par des virgules)") })
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Commande intelligente", color = Color.White)
                            Text("Autoriser l'ouverture / retour à l'accueil selon l'état détectable.", color = Color.Gray, fontSize = 11.sp)
                        }
                        Switch(checked = smartToggle, onCheckedChange = { smartToggle = it })
                    }
                    Divider(color = Color(0xFF29364A), modifier = Modifier.padding(vertical = 12.dp))
                    Text("Annonce à l'ouverture", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text(openAudio?.substringAfterLast('/') ?: "Aucun fichier importé", color = Color.Gray, fontSize = 11.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton(onClick = { audioTarget = "open"; audioPicker.launch(arrayOf("audio/mpeg", "audio/wav", "audio/*")) }) { Text("Importer") }
                        TextButton(onClick = { preview(openAudio) }) { Text("Écouter") }
                    }
                    Text("Annonce au retour à l'accueil", color = Color.White, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp))
                    Text(closeAudio?.substringAfterLast('/') ?: "Aucun fichier importé", color = Color.Gray, fontSize = 11.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton(onClick = { audioTarget = "close"; audioPicker.launch(arrayOf("audio/mpeg", "audio/wav", "audio/*")) }) { Text("Importer") }
                        TextButton(onClick = { preview(closeAudio) }) { Text("Écouter") }
                    }
                    Row(Modifier.fillMaxWidth().padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = {
                            if (spokenName.isBlank()) { message = "Le nom vocal est obligatoire." }
                            else scope.launch {
                                dao.save(AppVoiceConfig(
                                    packageName = selected.packageName,
                                    spokenName = spokenName.trim(),
                                    aliases = aliases.split(",").map { it.trim() }.filter { it.isNotBlank() }.distinct().joinToString("|"),
                                    openAudioUri = openAudio,
                                    closeAudioUri = closeAudio,
                                    smartToggle = smartToggle
                                ))
                                message = "Configuration enregistrée."
                            }
                        }, modifier = Modifier.weight(1f)) { Text("Enregistrer") }
                        OutlinedButton(onClick = {
                            scope.launch {
                                dao.delete(selected.packageName)
                                audioLibrary.delete(openAudio)
                                audioLibrary.delete(closeAudio)
                                spokenName = selected.label; aliases = ""; smartToggle = true
                                openAudio = null; closeAudio = null
                                message = "Configuration supprimée."
                            }
                        }) { Text("Supprimer") }
                    }
                    if (message.isNotBlank()) Text(message, color = Cyan, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp, bottom = 24.dp))
                }
            }
        }
    }
}

@Composable private fun ShortcutsContent(apps: List<InstalledApp>, onBack: () -> Unit) {
    val context = LocalContext.current
    var enabled by remember { mutableStateOf(com.doubigue.ai.overlay.EdgePrefs.isEnabled(context)) }
    var side by remember { mutableStateOf(com.doubigue.ai.overlay.EdgePrefs.side(context)) }
    var favs by remember { mutableStateOf(com.doubigue.ai.overlay.EdgePrefs.favorites(context)) }
    var hint by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        Text("Raccourcis", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Tiroir en roue : tire depuis le bord de l'écran, fais tourner l'anneau, touche une app pour l'ouvrir (retouche-la pour la fermer) ou le micro pour parler directement. Tire encore depuis le bord : l'assistant s'ouvre. Par défaut : toutes les apps ; coche pour choisir.", color = Color.Gray, fontSize = 12.sp)
        SettingSwitch("Activer le tiroir en arc", enabled) { on ->
            if (on) {
                if (Settings.canDrawOverlays(context)) { com.doubigue.ai.overlay.EdgeDrawerService.start(context); enabled = true; hint = "" }
                else {
                    hint = "Autorise l'affichage par-dessus les autres apps, puis réactive l'option."
                    context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            } else { com.doubigue.ai.overlay.EdgeDrawerService.stop(context); enabled = false }
        }
        if (hint.isNotBlank()) Text(hint, color = Cyan, fontSize = 12.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Côté", color = Color.White, modifier = Modifier.padding(end = 12.dp))
            FilterChip(selected = side == "left", onClick = { side = "left"; com.doubigue.ai.overlay.EdgePrefs.setSide(context, "left"); com.doubigue.ai.overlay.EdgeDrawerService.reload(context) }, label = { Text("Gauche") })
            Spacer(Modifier.width(8.dp))
            FilterChip(selected = side == "right", onClick = { side = "right"; com.doubigue.ai.overlay.EdgePrefs.setSide(context, "right"); com.doubigue.ai.overlay.EdgeDrawerService.reload(context) }, label = { Text("Droite") })
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(if (favs.isEmpty()) "Apps du tiroir : toutes (${apps.size})" else "Apps du tiroir : ${favs.size} choisies", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.weight(1f))
            if (favs.isNotEmpty()) TextButton(onClick = { favs = emptyList(); com.doubigue.ai.overlay.EdgePrefs.setFavorites(context, emptyList()) }) { Text("Toutes") }
        }
        LazyColumn(Modifier.weight(1f)) {
            items(apps, key = { it.packageName }) { app ->
                val checked = app.packageName in favs
                Row(Modifier.fillMaxWidth().clickable {
                    val next = if (checked) favs - app.packageName else favs + app.packageName
                    favs = next; com.doubigue.ai.overlay.EdgePrefs.setFavorites(context, next)
                }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    val bmp = remember(app.packageName) { app.icon.toBitmap(72, 72).asImageBitmap() }
                    Image(bmp, null, Modifier.size(32.dp)); Spacer(Modifier.width(12.dp))
                    Text(app.label, color = Color.White, modifier = Modifier.weight(1f)); Checkbox(checked, null)
                }
            }
        }
        OutlinedButton(onClick = onBack) { Text("Retour") }
    }
}

@Composable private fun EffectsContent(onBack: () -> Unit) {
    var hologram by remember { mutableStateOf(true) }; var neon by remember { mutableStateOf(false) }; var particles by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) { Text("Effets et styles", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold); HologramSphere(false, Modifier.align(Alignment.CenterHorizontally).size(190.dp)); SettingSwitch("Sphère holographique", hologram) { hologram = it }; SettingSwitch("Effets néon", neon) { neon = it }; SettingSwitch("Particules", particles) { particles = it }; Text("Le thème initial reste sobre et transparent. Les réglages visuels seront persistés avec DataStore dans l'itération suivante.", color = Color.Gray, fontSize = 12.sp) }
}

@Composable private fun ActionsContent(context: Context, onEnableBubble: () -> Unit, onFlashPermission: () -> Unit, onBack: () -> Unit) {
    val tools = remember { PhoneTools(context) }; var flash by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) { Text("Actions et outils", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold); SettingSwitch("Lampe torche", flash) { enabled -> if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PermissionChecker.PERMISSION_GRANTED) { flash = enabled; if (!tools.setFlashlight(enabled)) flash = false } else if (enabled) onFlashPermission() }; ActionRow("Wi-Fi", "Ouvrir les réglages Wi-Fi") { tools.openWifiSettings() }; ActionRow("Bluetooth", "Ouvrir les réglages Bluetooth") { tools.openBluetoothSettings() }; ActionRow("Luminosité", "Ouvrir les réglages d'affichage") { tools.openDisplaySettings() }; ActionRow("État Internet", tools.connectionType()) {}; ActionRow("Créer une alarme", "Choisir l'heure dans l'application Horloge") { tools.setAlarm(7, 0) }; ActionRow("Bulle flottante", "Autoriser et afficher la bulle DOUBIGUE AI") { onEnableBubble() }; Text("Les fonctions sensibles (capture/enregistrement d'écran, luminosité système, écran verrouillé) nécessitent les autorisations et dialogues Android dédiés.", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(top = 12.dp)) }
}

@Composable private fun ProfileContent(onBack: () -> Unit) { Column { Text("Profil", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold); Text("DOUBIGUE AI · Assistant personnel", color = Color.LightGray); Spacer(Modifier.height(20.dp)); Text("Version 1.8.0 · Profils et routines locales", color = Color.Gray, fontSize = 12.sp); OutlinedButton(onClick = onBack) { Text("Retour") } } }

@Composable private fun SettingSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) { Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) { Text(label, color = Color.White, modifier = Modifier.weight(1f)); Switch(checked, onChange) } }
@Composable private fun ActionRow(title: String, subtitle: String, action: () -> Unit) { Card(Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { action() }, colors = CardDefaults.cardColors(containerColor = Panel)) { Column(Modifier.padding(14.dp)) { Text(title, color = Color.White, fontWeight = FontWeight.SemiBold); Text(subtitle, color = Color.Gray, fontSize = 12.sp) } } }

private object CommandExecutionGuard {
    @Volatile private var lastCommand = ""
    @Volatile private var lastAt = 0L
    @Synchronized fun accept(raw: String): Boolean {
        val normalized = raw.lowercase().replace("[^a-z0-9]".toRegex(), "")
        val now = android.os.SystemClock.elapsedRealtime()
        if (normalized.isBlank()) return false
        if (normalized == lastCommand && now - lastAt < 1800L) return false
        lastCommand = normalized
        lastAt = now
        return true
    }
}

private var commandAudioPlayer: MediaPlayer? = null

private fun playCommandAudio(path: String?) {
    if (path.isNullOrBlank()) return
    try {
        commandAudioPlayer?.release()
        commandAudioPlayer = MediaPlayer().apply {
            setDataSource(path)
            setOnCompletionListener { player ->
                player.release()
                if (commandAudioPlayer === player) commandAudioPlayer = null
            }
            setOnErrorListener { player, _, _ ->
                player.release()
                if (commandAudioPlayer === player) commandAudioPlayer = null
                true
            }
            prepare()
            start()
        }
    } catch (_: Exception) {
        commandAudioPlayer?.release()
        commandAudioPlayer = null
    }
}

internal fun runCommand(
    context: Context,
    raw: String,
    apps: AppController,
    tools: PhoneTools,
    voice: VoiceEngine,
    dao: AppVoiceConfigDao,
    learnedDao: com.doubigue.ai.data.LearnedCommandDao,
    scope: kotlinx.coroutines.CoroutineScope,
    respond: (String) -> Unit
) {
    val command = raw.trim()
    if (!CommandExecutionGuard.accept(command)) {
        respond("Commande déjà exécutée.")
        return
    }
    val normalized = com.doubigue.ai.voice.CommandRouter.normalize(command)
    val learnMatch = Regex("(?i)^apprends(?:\\s+que)?\\s+quand\\s+je\\s+dis\\s+(.+?)[, ]+(?:fais|exécute|execute)\\s+(.+)$").find(command)
    if (learnMatch != null) {
        val trigger = learnMatch.groupValues[1].trim().trim(',', '.')
        val action = learnMatch.groupValues[2].trim().trimEnd('.', '!')
        if (trigger.isNotBlank() && action.isNotBlank()) scope.launch {
            val db = Room.databaseBuilder(context, AssistantDatabase::class.java, "doubigue.db").addMigrations(MIGRATION_1_2, com.doubigue.ai.data.MIGRATION_2_3, com.doubigue.ai.data.MIGRATION_3_4, com.doubigue.ai.data.MIGRATION_4_5).build()
            val learnedDaoLocal = db.learnedCommandDao()
            val key = com.doubigue.ai.voice.CommandRouter.normalize(trigger)
            learnedDaoLocal.all().filter { com.doubigue.ai.voice.CommandRouter.normalize(it.triggerPhrase) == key }.forEach { learnedDaoLocal.delete(it.id) }
            val profile = context.getSharedPreferences("doubigue_local", Context.MODE_PRIVATE).getString("active_profile", "Général") ?: "Général"
            learnedDaoLocal.save(com.doubigue.ai.data.LearnedCommand(triggerPhrase = trigger, commandText = action, profileName = profile))
            db.close()
            val message = "C'est appris. Quand tu diras $trigger, j'exécuterai : $action."
            respond(message); voice.speak(message)
        }
        return
    }
    // Execute a deterministic sequence one action at a time; maximum five steps.
    val plan = com.doubigue.ai.voice.CommandPlanParser.parse(command)
    if (plan.error == null && plan.actions.size > 1) {
        scope.launch {
            plan.actions.forEachIndexed { index, action ->
                val phrase = when (action) {
                    is com.doubigue.ai.voice.PlannedAction.OpenTarget -> "ouvre ${action.name}"
                    is com.doubigue.ai.voice.PlannedAction.PlayAudio -> "joue ${action.query}"
                    is com.doubigue.ai.voice.PlannedAction.Flashlight -> if (action.enabled) "allume la lampe" else "éteins la lampe"
                }
                runCommand(context, phrase, apps, tools, voice, dao, learnedDao, scope, respond)
                if (index < plan.actions.lastIndex) kotlinx.coroutines.delay(700)
            }
        }
        return
    }
    when {
        normalized.contains("allume") && (normalized.contains("lampe") || normalized.contains("torche")) -> {
            val ok = tools.setFlashlight(true)
            if (ok) com.doubigue.ai.events.EventSounds.play(context, com.doubigue.ai.events.SoundEvent.FLASH_ON)
            val message = if (ok) "Lampe allumée." else "Lampe torche indisponible."
            respond(message); voice.speak(message)
        }
        (normalized.contains("eteins") || normalized.contains("eteindre")) && (normalized.contains("lampe") || normalized.contains("torche")) -> {
            val ok = tools.setFlashlight(false)
            if (ok) com.doubigue.ai.events.EventSounds.play(context, com.doubigue.ai.events.SoundEvent.FLASH_OFF)
            val message = if (ok) "Lampe éteinte." else "Impossible d'éteindre la lampe."
            respond(message); voice.speak(message)
        }
        normalized.contains("lampe") || normalized.contains("torche") -> {
            com.doubigue.ai.system.QuickTogglesActivity.show(context, "flash")
            com.doubigue.ai.events.EventSounds.play(context, com.doubigue.ai.events.SoundEvent.FLASH_ON)
            respond("Lampe torche : interrupteur ouvert.")
        }
        normalized.contains("wifi") -> {
            com.doubigue.ai.system.QuickTogglesActivity.show(context, "wifi")
            com.doubigue.ai.events.EventSounds.play(context, com.doubigue.ai.events.SoundEvent.WIFI)
            respond("Wi-Fi : interrupteur ouvert.")
        }
        normalized.contains("bluetooth") -> {
            com.doubigue.ai.system.QuickTogglesActivity.show(context, "bluetooth")
            com.doubigue.ai.events.EventSounds.play(context, com.doubigue.ai.events.SoundEvent.BLUETOOTH)
            respond("Bluetooth : interrupteur ouvert.")
        }
        normalized.contains("internet") || normalized.contains("connexion") -> {
            com.doubigue.ai.system.QuickTogglesActivity.show(context, "internet")
            com.doubigue.ai.events.EventSounds.play(context, com.doubigue.ai.events.SoundEvent.INTERNET)
            respond("Internet : interrupteurs ouverts.")
        }
        normalized.startsWith("joue") || normalized.startsWith("mets") -> {
            val query = command.replace(Regex("(?i)^(joue|mets)\\s+"), "").trim()
            val files = LocalAudioLibrary(context).list()
            val key = com.doubigue.ai.voice.CommandRouter.normalize(query)
            val selectedAudio = if (key.isBlank() || key in listOf("musique", "mamusique", "son", "audio")) files.firstOrNull() else files.firstOrNull { com.doubigue.ai.voice.CommandRouter.normalize(it.nameWithoutExtension).contains(key) }
            if (selectedAudio == null) {
                val message = "Je ne trouve pas ce fichier audio. Importe d'abord un MP3 ou WAV dans Mes applications."
                respond(message); voice.speak(message)
            } else {
                playCommandAudio(selectedAudio.absolutePath)
                val message = "Lecture de ${selectedAudio.nameWithoutExtension}."
                respond(message); voice.speak(message)
            }
        }
        else -> scope.launch {
            val activeProfile = context.getSharedPreferences("doubigue_local", Context.MODE_PRIVATE).getString("active_profile", "Général") ?: "Général"
            val availableLearned = learnedDao.all().filter { it.profileName == activeProfile || it.profileName == "Général" }
            val learned = com.doubigue.ai.voice.LearnedCommandMatcher.find(command, availableLearned)
            if (learned != null) {
                respond("Commande personnalisée reconnue : ${learned.triggerPhrase}.")
                runCommand(context, learned.commandText, apps, tools, voice, dao, learnedDao, scope, respond)
                return@launch
            }
            val installed = apps.installedApps()
            val configs = installed.mapNotNull { app -> dao.get(app.packageName)?.let { app to it } }
            val lookupCommand = command.replace(Regex("(?i)^(ouvre|ouvrir|lance|démarre|demarre)\\s+"), "").trim()
            val key = com.doubigue.ai.voice.CommandRouter.normalize(lookupCommand)
            val match = configs.firstOrNull { (app, config) ->
                val names = listOf(app.label, config.spokenName) + config.aliases.split(',', ';', '|', '\n').map { it.trim() }
                names.any { com.doubigue.ai.voice.CommandRouter.normalize(it) == key }
            } ?: installed.firstOrNull { com.doubigue.ai.voice.CommandRouter.normalize(it.label) == key }?.let { it to null }

            if (match == null) {
                val looksLikeConversation = command.trim().contains(' ') && !normalized.startsWith("ouvre") && !normalized.startsWith("lance") && !normalized.startsWith("joue") && !normalized.startsWith("mets")
                if (looksLikeConversation) {
                    val history = try { daoConversationHistory(context) } catch (_: Exception) { emptyList() }
                    val answer = com.doubigue.ai.voice.ConversationEngine.reply(command, history)
                    try {
                        val historyDb = Room.databaseBuilder(context, AssistantDatabase::class.java, "doubigue.db").addMigrations(MIGRATION_1_2, com.doubigue.ai.data.MIGRATION_2_3, com.doubigue.ai.data.MIGRATION_3_4, com.doubigue.ai.data.MIGRATION_4_5).build()
                        historyDb.conversationDao().add(com.doubigue.ai.data.ConversationMessage(role = "user", content = command))
                        historyDb.conversationDao().add(com.doubigue.ai.data.ConversationMessage(role = "assistant", content = answer))
                        historyDb.close()
                    } catch (_: Exception) { }
                    respond(answer); voice.speak(answer)
                } else {
                    val message = "Application inconnue : $command. Vous pouvez l'installer ou ajouter un alias dans Mes applications."
                    respond(message); voice.speak(message)
                }
                return@launch
            }
            val (app, config) = match
            launchOrToggleApp(context, apps, voice, app, config, respond)
        }
    }
}

/** Ouvre l'app (son d'ouverture) ou la ferme si elle est déjà au premier plan (son de fermeture). Utilisé par la voix ET le tiroir. */
internal fun launchOrToggleApp(
    context: Context,
    apps: AppController,
    voice: VoiceEngine,
    app: InstalledApp,
    config: AppVoiceConfig?,
    respond: (String) -> Unit
) {
    com.doubigue.ai.events.AppOpenGate.mark(app.packageName)
    val before = apps.stateOf(app.packageName)
    val shouldClose = config?.smartToggle != false && before == com.doubigue.ai.apps.AppState.FOREGROUND
    val ok = if (shouldClose) {
        apps.goHome()
    } else {
        val launch = context.packageManager.getLaunchIntentForPackage(app.packageName)
        if (launch == null) false else {
            try {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                context.startActivity(launch)
                true
            } catch (_: Exception) { false }
        }
    }
    if (ok) {
        val message = if (shouldClose) "${app.label} quitté. Retour à l'accueil." else "${app.label} ouvert."
        respond(message); voice.speak(message)
        // Son personnel de l'app ; sinon le son par défaut (Paramètres > Sons d'événements).
        val custom = if (shouldClose) config?.closeAudioUri else config?.openAudioUri
        if (!custom.isNullOrBlank() && java.io.File(custom).exists()) playCommandAudio(custom)
        else com.doubigue.ai.events.EventSounds.play(context,
            if (shouldClose) com.doubigue.ai.events.SoundEvent.APP_CLOSE_DEFAULT else com.doubigue.ai.events.SoundEvent.APP_OPEN_DEFAULT)
    } else {
        val message = "Impossible d'ouvrir ${app.label}."
        respond(message); voice.speak(message)
    }
}


private suspend fun daoConversationHistory(context: Context): List<String> {
    val db = Room.databaseBuilder(context, AssistantDatabase::class.java, "doubigue.db")
        .addMigrations(MIGRATION_1_2, com.doubigue.ai.data.MIGRATION_2_3, com.doubigue.ai.data.MIGRATION_3_4, com.doubigue.ai.data.MIGRATION_4_5).build()
    return try {
        db.conversationDao().latest(40).first()
            .filter { it.role == "user" }.map { it.content }
    } finally { db.close() }
}

private fun enableBubble(context: Context) {
    if (!Settings.canDrawOverlays(context)) {
        context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } else {
        ContextCompat.startForegroundService(context, Intent(context, com.doubigue.ai.overlay.FloatingBubbleService::class.java))
    }
}
