package com.doubigue.ai.events

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

/**
 * SECOURS pour les échecs sur l'écran de verrouillage (empreinte, PIN, schéma, mot de passe) quand l'administrateur
 * d'appareil ne les signale pas (selon marque / version d'Android). Lit uniquement les messages d'échec de
 * com.android.systemui (« schéma incorrect », « empreinte non reconnue »…). Rien d'autre n'est lu ni enregistré.
 */
class LockAccessibilityService : AccessibilityService() {
    private val negative = listOf("non reconnu", "not recognized", "incorrect", "mauvais", "wrong", "erron", "reessayez", "réessayez", "try again", "invalide", "invalid", "refus")
    private val fingerprint = Regex("empreinte|fingerprint|doigt|finger|visage|\\bface\\b")
    private val pattern = Regex("sch[ée]ma|pattern|dessin")
    private val pin = Regex("\\bpin\\b")
    private val password = Regex("mot de passe|password")
    private val countdown = Regex("\\d+\\s*(secondes?|seconds?|sec\\b|s\\b)")

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val e = event ?: return
        if (e.packageName?.toString()?.contains("systemui") != true) return
        val text = buildString {
            e.text?.forEach { append(it).append(' ') }
            append(e.contentDescription ?: "")
        }.lowercase()
        if (text.isBlank() || negative.none { text.contains(it) }) return
        if (countdown.containsMatchIn(text)) return            // « Réessayez dans 29 secondes » : pas un nouvel échec
        val ev = when {
            fingerprint.containsMatchIn(text) -> SoundEvent.FINGERPRINT_FAIL
            pattern.containsMatchIn(text) -> SoundEvent.PATTERN_FAIL
            pin.containsMatchIn(text) -> SoundEvent.PIN_FAIL
            password.containsMatchIn(text) -> SoundEvent.PASSWORD_FAIL
            else -> EventSounds.failEvent(this)                 // message générique : on prend ton type de verrouillage
        }
        if (LockState.claimFail()) EventSounds.play(this, ev)
    }

    override fun onInterrupt() {}
}
