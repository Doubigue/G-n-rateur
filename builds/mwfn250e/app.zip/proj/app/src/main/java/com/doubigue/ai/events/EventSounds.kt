package com.doubigue.ai.events

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import java.io.File

/** Événements auxquels on peut associer un son (MP3/WAV importé, ex. ElevenLabs). */
enum class SoundEvent(val key: String, val label: String, val hint: String) {
    WELCOME("welcome", "Bienvenue (ouverture de l'appli)", "Joué quand tu ouvres DOUBIGUE AI"),
    SCREEN_LOCKED("screen_locked", "Écran verrouillé", "Joué quand l'écran s'éteint / se verrouille"),
    SCREEN_ON("screen_on", "Écran allumé (verrouillé)", "Joué quand l'écran s'allume, avant le déverrouillage"),
    UNLOCK_FINGERPRINT("unlock_fingerprint", "Empreinte acceptée", "Déverrouillage sans PIN/mot de passe/schéma (empreinte ou visage)"),
    FINGERPRINT_FAIL("fingerprint_fail", "Empreinte refusée", "Expérimental : nécessite le service d'accessibilité"),
    UNLOCK_PIN("unlock_pin", "Code PIN accepté", "Déverrouillage par code PIN"),
    PIN_FAIL("pin_fail", "Code PIN incorrect", "Échec de saisie du PIN"),
    UNLOCK_PASSWORD("unlock_password", "Mot de passe accepté", "Déverrouillage par mot de passe"),
    PASSWORD_FAIL("password_fail", "Mot de passe incorrect", "Échec de saisie du mot de passe"),
    UNLOCK_PATTERN("unlock_pattern", "Schéma accepté", "Déverrouillage par schéma"),
    PATTERN_FAIL("pattern_fail", "Schéma incorrect", "Échec de saisie du schéma"),
    AFTER_UNLOCK("after_unlock", "Après déverrouillage", "Joué après n'importe quel déverrouillage réussi (en plus du son spécifique)"),
    LISTEN_PROMPT("listen_prompt", "Micro du tiroir : « Je vous écoute »", "Joué quand tu touches le micro du tiroir, avant que tu parles"),
    APP_OPEN_DEFAULT("app_open_default", "Application ouverte (son par défaut)", "Joué quand une app s'ouvre (tiroir, voix ou menu du téléphone) et qu'elle n'a pas de son personnel"),
    APP_CLOSE_DEFAULT("app_close_default", "Application fermée (son par défaut)", "Joué quand une app est fermée par la voix ou le tiroir et qu'elle n'a pas de son personnel"),
    FLASH_ON("flash_on", "Lampe allumée", "Joué quand la lampe torche s'allume"),
    FLASH_OFF("flash_off", "Lampe éteinte", "Joué quand la lampe torche s'éteint"),
    WIFI("wifi", "Wi-Fi", "Joué à la commande Wi-Fi (petit écran avec interrupteur)"),
    BLUETOOTH("bluetooth", "Bluetooth", "Joué à la commande Bluetooth (petit écran avec interrupteur)"),
    INTERNET("internet", "Internet / données mobiles", "Joué à la commande Internet (petit écran avec interrupteurs)");
}

/** Type de verrouillage que tu utilises : Android ne dit pas aux applis lequel c'est. */
enum class LockType(val key: String, val label: String) {
    PIN("pin", "Code PIN"), PASSWORD("password", "Mot de passe"), PATTERN("pattern", "Schéma")
}

object EventSounds {
    private const val PREFS = "doubigue_events"
    private const val K_ENABLED = "service_enabled"
    private const val K_LOCK_TYPE = "lock_type"
    private const val K_WELCOME_AT = "welcome_last_at"

    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun getPath(c: Context, e: SoundEvent): String? = prefs(c).getString("sound_" + e.key, null)?.takeIf { File(it).exists() }
    fun setPath(c: Context, e: SoundEvent, path: String?) {
        prefs(c).edit().apply { if (path == null) remove("sound_" + e.key) else putString("sound_" + e.key, path) }.apply()
    }

    fun isWatchEnabled(c: Context) = prefs(c).getBoolean("watch_enabled", false)
    fun setWatchEnabled(c: Context, v: Boolean) = prefs(c).edit().putBoolean("watch_enabled", v).apply()

    fun isServiceEnabled(c: Context) = prefs(c).getBoolean(K_ENABLED, false)
    fun setServiceEnabled(c: Context, v: Boolean) = prefs(c).edit().putBoolean(K_ENABLED, v).apply()

    fun lockType(c: Context): LockType = LockType.values().firstOrNull { it.key == prefs(c).getString(K_LOCK_TYPE, "pin") } ?: LockType.PIN
    fun setLockType(c: Context, t: LockType) = prefs(c).edit().putString(K_LOCK_TYPE, t.key).apply()

    fun unlockEvent(c: Context) = when (lockType(c)) {
        LockType.PIN -> SoundEvent.UNLOCK_PIN; LockType.PASSWORD -> SoundEvent.UNLOCK_PASSWORD; LockType.PATTERN -> SoundEvent.UNLOCK_PATTERN
    }
    fun failEvent(c: Context) = when (lockType(c)) {
        LockType.PIN -> SoundEvent.PIN_FAIL; LockType.PASSWORD -> SoundEvent.PASSWORD_FAIL; LockType.PATTERN -> SoundEvent.PATTERN_FAIL
    }

    /** Bienvenue : à chaque entrée dans l'appli (même si elle n'était pas fermée) ; seul un doublon à moins de 2 s est ignoré. */
    fun playWelcomeOnce(c: Context) {
        val now = android.os.SystemClock.elapsedRealtime()
        val last = prefs(c).getLong(K_WELCOME_AT, -1L)
        // elapsedRealtime repart de 0 au redémarrage du téléphone : on joue alors toujours.
        if (last in 0..now && now - last < 2_000L) return
        prefs(c).edit().putLong(K_WELCOME_AT, now).apply()
        play(c, SoundEvent.WELCOME)
    }

    private var player: MediaPlayer? = null
    private val queue = ArrayDeque<String>()

    /** Joue le son de l'événement (si configuré). Les sons s'enchaînent sans se couper. */
    @Synchronized fun play(c: Context, vararg events: SoundEvent) {
        events.mapNotNull { getPath(c, it) }.forEach { queue.addLast(it) }
        if (player == null) next()
    }

    /** Met un fichier (ex. son personnel d'une application) dans la file de lecture. */
    @Synchronized fun playPath(path: String?) {
        if (path.isNullOrBlank() || !File(path).exists()) return
        queue.addLast(path)
        if (player == null) next()
    }

    /** Joue le son de l'événement puis appelle [onDone] (aussi s'il n'y a pas de son ou en cas d'erreur). */
    fun playThen(c: Context, e: SoundEvent, onDone: () -> Unit) {
        val path = getPath(c, e)
        if (path == null) { onDone(); return }
        try {
            MediaPlayer().apply {
                setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                setDataSource(path)
                setOnCompletionListener { try { it.release() } catch (_: Exception) {}; onDone() }
                setOnErrorListener { mp, _, _ -> try { mp.release() } catch (_: Exception) {}; onDone(); true }
                prepare(); start()
            }
        } catch (_: Exception) { onDone() }
    }

    /** Lecture directe d'un fichier (bouton « Écouter »). */
    @Synchronized fun preview(path: String?) {
        if (path.isNullOrBlank()) return
        queue.clear(); release(); queue.addLast(path); next()
    }

    @Synchronized private fun next() {
        val path = queue.removeFirstOrNull() ?: return
        try {
            player = MediaPlayer().apply {
                setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                setDataSource(path)
                setOnCompletionListener { synchronized(EventSounds) { release(); next() } }
                setOnErrorListener { _, _, _ -> synchronized(EventSounds) { release(); next() }; true }
                prepare(); start()
            }
        } catch (_: Exception) { release(); next() }
    }

    @Synchronized private fun release() { try { player?.release() } catch (_: Exception) {}; player = null }
}

/** Mémorise les apps ouvertes par l'assistant / le tiroir pour que le guetteur d'ouvertures ne rejoue pas un second son. */
object AppOpenGate {
    private val marks = java.util.concurrent.ConcurrentHashMap<String, Long>()
    fun mark(pkg: String) { marks[pkg] = android.os.SystemClock.elapsedRealtime() }
    fun recentlyHandled(pkg: String): Boolean = marks[pkg]?.let { android.os.SystemClock.elapsedRealtime() - it < 7000L } ?: false
}
