package com.doubigue.ai.events

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import com.doubigue.ai.MainActivity

/**
 * Service au premier plan qui écoute les changements d'état de l'écran.
 * (Ces diffusions ne peuvent être reçues que par un récepteur enregistré dans le code, d'où le service.)
 */
class EventSoundService : Service() {
    private var receiver: BroadcastReceiver? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            EventSounds.setServiceEnabled(this, false)
            stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Annonces sonores", NotificationManager.IMPORTANCE_MIN))
        startForeground(NOTIF_ID, notification())
        register()
    }

    private fun notification(): Notification {
        val open = PendingIntent.getActivity(this, 11, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 12, Intent(this, EventSoundService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle("DOUBIGUE AI : annonces sonores actives")
            .setContentIntent(open).setOngoing(true).setPriority(NotificationCompat.PRIORITY_MIN)
            .addAction(android.R.drawable.ic_media_pause, "Arrêter", stop).build()
    }

    private fun register() {
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                when (i.action) {
                    Intent.ACTION_SCREEN_OFF -> EventSounds.play(c, SoundEvent.SCREEN_LOCKED)
                    Intent.ACTION_SCREEN_ON -> {
                        val km = c.getSystemService(KEYGUARD_SERVICE) as android.app.KeyguardManager
                        if (km.isKeyguardLocked) EventSounds.play(c, SoundEvent.SCREEN_ON)
                    }
                    Intent.ACTION_USER_PRESENT -> onUnlocked(c)
                }
            }
        }
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF); addAction(Intent.ACTION_SCREEN_ON); addAction(Intent.ACTION_USER_PRESENT)
        }
        // Diffusions système : pas besoin d'exporter (Android 14+).
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(r, f, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(r, f)
        receiver = r
    }

    /**
     * Après un déverrouillage : si un PIN/mot de passe/schéma vient d'être validé (signal de l'administrateur
     * d'appareil, juste avant), c'est lui ; sinon on en déduit une empreinte (ou un visage).
     */
    private fun onUnlocked(c: Context) {
        val sinceCredential = SystemClock.elapsedRealtime() - LockState.lastCredentialOk
        val byCredential = LockState.lastCredentialOk > 0 && sinceCredential in 0..4000
        val specific = if (byCredential) EventSounds.unlockEvent(c) else SoundEvent.UNLOCK_FINGERPRINT
        EventSounds.play(c, specific, SoundEvent.AFTER_UNLOCK)
    }

    override fun onDestroy() {
        receiver?.let { try { unregisterReceiver(it) } catch (_: Exception) {} }
        receiver = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.doubigue.ai.events.STOP"
        private const val CHANNEL = "doubigue_events"
        private const val NOTIF_ID = 42
        fun start(c: Context) {
            EventSounds.setServiceEnabled(c, true)
            androidx.core.content.ContextCompat.startForegroundService(c, Intent(c, EventSoundService::class.java))
        }
        fun stop(c: Context) { c.startService(Intent(c, EventSoundService::class.java).setAction(ACTION_STOP)) }
    }
}

/** Relance le service après un redémarrage du téléphone (si activé). */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        if (EventSounds.isServiceEnabled(context)) {
            try { EventSoundService.start(context) } catch (_: Exception) {}
        }
        if (EventSounds.isWatchEnabled(context)) {
            try { AppWatchService.start(context) } catch (_: Exception) {}
        }
        if (com.doubigue.ai.overlay.EdgePrefs.isEnabled(context) && android.provider.Settings.canDrawOverlays(context)) {
            try { com.doubigue.ai.overlay.EdgeDrawerService.start(context) } catch (_: Exception) {}
        }
    }
}
