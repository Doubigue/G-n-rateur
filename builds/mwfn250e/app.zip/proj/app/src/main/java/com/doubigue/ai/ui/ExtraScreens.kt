package com.doubigue.ai.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.doubigue.ai.data.BackupManager
import com.doubigue.ai.voice.VoiceEngine
import com.doubigue.ai.voice.VoskModelManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun VoiceModelContent(voice: VoiceEngine, onBack: () -> Unit) {
    val context: Context = LocalContext.current
    val scope = rememberCoroutineScope()
    var installed by remember { mutableStateOf(VoskModelManager.isInstalled(context)) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            busy = true
            message = "Import en cours… (quelques dizaines de secondes)"
            val result = withContext(Dispatchers.IO) { runCatching { VoskModelManager.importZip(context, uri) } }
            result.onSuccess { voice.reloadModel(); installed = true; message = "Modèle importé. Tu peux utiliser le micro." }
                .onFailure { installed = VoskModelManager.isInstalled(context); message = "Échec : ${it.message ?: "erreur inconnue"}" }
            busy = false
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Text("Voix hors ligne (Vosk)", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(
            "Importe le fichier vosk-model-small-fr-0.22.zip téléchargé. La reconnaissance vocale fonctionne ensuite sans internet. L'appli ne parle pas : seuls tes propres sons sont joués.",
            color = Color.LightGray, fontSize = 13.sp, modifier = Modifier.padding(vertical = 10.dp)
        )
        Text(if (installed) "Modèle installé ✔" else "Aucun modèle installé", color = if (installed) Color(0xFF83DDE8) else Color(0xFFFFB74D), fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(12.dp))
        Button(enabled = !busy, onClick = { picker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")) }) {
            Text(if (installed) "Remplacer le modèle (zip)" else "Importer le modèle (zip)")
        }
        if (installed) {
            OutlinedButton(enabled = !busy, onClick = { voice.reloadModel(); VoskModelManager.delete(context); installed = false; message = "Modèle supprimé." }, modifier = Modifier.padding(top = 8.dp)) { Text("Supprimer le modèle") }
        }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 14.dp))
        if (message.isNotBlank()) Text(message, color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(top = 12.dp))
        Spacer(Modifier.height(16.dp))
        OutlinedButton(onClick = onBack) { Text("Retour") }
    }
}

@Composable
fun BackupContent(onBack: () -> Unit) {
    val context: Context = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var includeModel by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var pickedUri by remember { mutableStateOf<Uri?>(null) }
    var readyToRestart by remember { mutableStateOf(BackupManager.hasPendingRestore(context)) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) pickedUri = uri }

    pickedUri?.let { uri ->
        AlertDialog(
            onDismissRequest = { pickedUri = null },
            title = { Text("Restaurer cette sauvegarde ?") },
            text = { Text("Les données actuelles (applications configurées, commandes apprises, réglages, sons) seront remplacées par celles de la sauvegarde.") },
            confirmButton = {
                TextButton(onClick = {
                    pickedUri = null
                    scope.launch {
                        busy = true
                        message = "Lecture de la sauvegarde…"
                        val result = withContext(Dispatchers.IO) { runCatching { BackupManager.stageRestore(context, uri) } }
                        result.onSuccess { n -> readyToRestart = true; message = "Sauvegarde prête ($n fichiers). Redémarre l'appli pour terminer la restauration." }
                            .onFailure { readyToRestart = false; message = "Échec : ${it.message ?: "erreur inconnue"}" }
                        busy = false
                    }
                }) { Text("Restaurer") }
            },
            dismissButton = { TextButton(onClick = { pickedUri = null }) { Text("Annuler") } }
        )
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Text("Sauvegarde et restauration", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(
            "Enregistre toutes les données de l'appli (applications configurées, commandes apprises, réglages, sons importés) dans un zip, dans le dossier « ${BackupManager.FOLDER} » (Documents).",
            color = Color.LightGray, fontSize = 13.sp, modifier = Modifier.padding(vertical = 10.dp)
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = includeModel, onCheckedChange = { includeModel = it }, enabled = !busy)
            Text("  Inclure le modèle vocal Vosk (~40 Mo)", color = Color.White, fontSize = 13.sp)
        }
        Spacer(Modifier.height(10.dp))
        Button(enabled = !busy, onClick = {
            scope.launch {
                busy = true
                message = "Sauvegarde en cours…"
                val result = withContext(Dispatchers.IO) { runCatching { BackupManager.createBackup(context, includeModel) } }
                message = result.fold({ "Sauvegarde créée : $it" }, { "Échec : ${it.message ?: "erreur inconnue"}" })
                busy = false
            }
        }) { Text("Sauvegarder maintenant") }

        Spacer(Modifier.height(22.dp))
        Text("Restaurer", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        Text(
            "Choisis un zip DoubigueAI_Sauvegarde_….zip dans le dossier « ${BackupManager.FOLDER} ». Fonctionne aussi après une réinstallation de l'appli.",
            color = Color.LightGray, fontSize = 13.sp, modifier = Modifier.padding(vertical = 8.dp)
        )
        OutlinedButton(enabled = !busy, onClick = { picker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")) }) {
            Text("Restaurer depuis un zip")
        }
        if (readyToRestart) {
            Button(enabled = !busy, onClick = { BackupManager.restartApp(context) }, modifier = Modifier.padding(top = 10.dp)) { Text("Redémarrer maintenant") }
        }
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 14.dp))
        if (message.isNotBlank()) Text(message, color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(top = 12.dp))
        Spacer(Modifier.height(16.dp))
        OutlinedButton(onClick = onBack) { Text("Retour") }
    }
}

@Composable
fun EventSoundsContent(onBack: () -> Unit) {
    val context: Context = LocalContext.current
    val library = remember { com.doubigue.ai.audio.LocalAudioLibrary(context) }
    var refresh by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf("") }
    var serviceOn by remember { mutableStateOf(com.doubigue.ai.events.EventSounds.isServiceEnabled(context)) }
    var lockType by remember { mutableStateOf(com.doubigue.ai.events.EventSounds.lockType(context)) }
    var target by remember { mutableStateOf<com.doubigue.ai.events.SoundEvent?>(null) }
    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val ev = target
        if (uri != null && ev != null) {
            try {
                library.delete(com.doubigue.ai.events.EventSounds.getPath(context, ev))
                val file = library.import(uri, "event_" + ev.key)
                com.doubigue.ai.events.EventSounds.setPath(context, ev, file.absolutePath)
                refresh++; message = "Son importé pour « ${ev.label} »."
            } catch (e: Exception) { message = "Import impossible : ${e.message ?: "erreur"}" }
        }
    }
    val adminActive = remember(refresh) {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as android.app.admin.DevicePolicyManager
        dpm.isAdminActive(android.content.ComponentName(context, com.doubigue.ai.events.LockAdminReceiver::class.java))
    }
    val a11yActive = remember(refresh) {
        val enabled = android.provider.Settings.Secure.getString(context.contentResolver, android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
        enabled.contains(context.packageName + "/" + com.doubigue.ai.events.LockAccessibilityService::class.java.name)
    }
    // Revient de l'écran Android d'autorisation : on relit l'état.
    val lifecycle = androidx.compose.ui.platform.LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        val obs = androidx.lifecycle.LifecycleEventObserver { _, e -> if (e == androidx.lifecycle.Lifecycle.Event.ON_RESUME) refresh++ }
        lifecycle.addObserver(obs); onDispose { lifecycle.removeObserver(obs) }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Text("Sons d'événements", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Associe un MP3/WAV (ex. ElevenLabs) à chaque situation. L'appli ne synthétise aucune voix : elle joue tes fichiers.", color = Color.LightGray, fontSize = 13.sp, modifier = Modifier.padding(vertical = 10.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = serviceOn, onCheckedChange = { on ->
                serviceOn = on
                if (on) {
                    if (android.os.Build.VERSION.SDK_INT >= 33) notifPermission.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                    com.doubigue.ai.events.EventSoundService.start(context)
                } else com.doubigue.ai.events.EventSoundService.stop(context)
            })
            Column(Modifier.padding(start = 10.dp)) {
                Text("Annonces écran verrouillé / déverrouillé", color = Color.White, fontSize = 14.sp)
                Text("Garde une petite notification discrète active.", color = Color.Gray, fontSize = 11.sp)
            }
        }

        var watchOn by remember { mutableStateOf(com.doubigue.ai.events.EventSounds.isWatchEnabled(context)) }
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 10.dp)) {
            Switch(checked = watchOn, onCheckedChange = { on ->
                if (on) {
                    if (!com.doubigue.ai.apps.AppController(context).hasUsageAccess()) {
                        message = "Autorise « Données d'utilisation » pour DOUBIGUE AI, puis réactive l'option."
                        context.startActivity(Intent(android.provider.Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } else {
                        if (android.os.Build.VERSION.SDK_INT >= 33) notifPermission.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                        com.doubigue.ai.events.AppWatchService.start(context); watchOn = true
                    }
                } else { com.doubigue.ai.events.AppWatchService.stop(context); watchOn = false }
            })
            Column(Modifier.padding(start = 10.dp)) {
                Text("Annoncer les apps ouvertes depuis le téléphone", color = Color.White, fontSize = 14.sp)
                Text("Son personnel de l'app, sinon « Application ouverte (par défaut) ».", color = Color.Gray, fontSize = 11.sp)
            }
        }

        Text("Ton type de verrouillage", color = Color.White, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 16.dp))
        Text("Android ne dit pas aux applis si c'est un PIN, un mot de passe ou un schéma : choisis le tien.", color = Color.Gray, fontSize = 11.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 4.dp)) {
            com.doubigue.ai.events.LockType.values().forEach { t ->
                FilterChip(selected = lockType == t, onClick = { lockType = t; com.doubigue.ai.events.EventSounds.setLockType(context, t) }, label = { Text(t.label, fontSize = 12.sp) })
            }
        }

        Card(Modifier.fillMaxWidth().padding(top = 14.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF111A2A))) {
            Column(Modifier.padding(12.dp)) {
                Text(if (adminActive) "Échecs PIN / mot de passe / schéma : activés ✔" else "Échecs PIN / mot de passe / schéma : à autoriser", color = if (adminActive) Color(0xFF83DDE8) else Color(0xFFFFB74D), fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Text("Active DOUBIGUE AI comme administrateur de l'appareil. Seule la surveillance des tentatives de connexion est demandée : aucun droit d'effacer ou de bloquer le téléphone.", color = Color.Gray, fontSize = 11.sp)
                if (!adminActive) TextButton(onClick = {
                    context.startActivity(Intent(android.app.admin.DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                        .putExtra(android.app.admin.DevicePolicyManager.EXTRA_DEVICE_ADMIN, android.content.ComponentName(context, com.doubigue.ai.events.LockAdminReceiver::class.java))
                        .putExtra(android.app.admin.DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Pour annoncer les codes incorrects et corrects sur l'écran de verrouillage."))
                }) { Text("Autoriser") }
                else TextButton(onClick = {
                    (context.getSystemService(Context.DEVICE_POLICY_SERVICE) as android.app.admin.DevicePolicyManager)
                        .removeActiveAdmin(android.content.ComponentName(context, com.doubigue.ai.events.LockAdminReceiver::class.java)); refresh++
                }) { Text("Désactiver") }
            }
        }
        Card(Modifier.fillMaxWidth().padding(top = 8.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF111A2A))) {
            Column(Modifier.padding(12.dp)) {
                Text(if (a11yActive) "Échecs empreinte / PIN / schéma (secours) : activé ✔" else "Échecs empreinte / PIN / schéma (secours) : à autoriser", color = if (a11yActive) Color(0xFF83DDE8) else Color(0xFFFFB74D), fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Text("Si l'administrateur ci-dessus ne signale pas les échecs sur ton téléphone, ce service d'accessibilité prend le relais : il lit seulement les messages d'échec de l'écran de verrouillage (« schéma incorrect », « empreinte non reconnue »…). Active-le aussi pour les empreintes. Peut varier selon la marque.", color = Color.Gray, fontSize = 11.sp)
                TextButton(onClick = { context.startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) { Text("Ouvrir les réglages d'accessibilité") }
            }
        }

        Divider(color = Color(0xFF29364A), modifier = Modifier.padding(vertical = 14.dp))
        key(refresh) {
            com.doubigue.ai.events.SoundEvent.values().forEach { ev ->
                val path = com.doubigue.ai.events.EventSounds.getPath(context, ev)
                Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Text(ev.label, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text(ev.hint, color = Color.Gray, fontSize = 11.sp)
                    Text(path?.substringAfterLast('/') ?: "Aucun son", color = if (path == null) Color.DarkGray else Color(0xFF83DDE8), fontSize = 11.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton(onClick = { target = ev; picker.launch(arrayOf("audio/mpeg", "audio/wav", "audio/*")) }) { Text("Importer", fontSize = 12.sp) }
                        TextButton(enabled = path != null, onClick = { com.doubigue.ai.events.EventSounds.preview(path) }) { Text("Écouter", fontSize = 12.sp) }
                        TextButton(enabled = path != null, onClick = { library.delete(path); com.doubigue.ai.events.EventSounds.setPath(context, ev, null); refresh++ }) { Text("Retirer", fontSize = 12.sp) }
                    }
                }
            }
        }
        if (message.isNotBlank()) Text(message, color = Color(0xFF83DDE8), fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = onBack) { Text("Retour") }
        Spacer(Modifier.height(24.dp))
    }
}
