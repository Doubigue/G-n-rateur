package com.doubigue.ai.overlay

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import android.util.TypedValue
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import androidx.core.graphics.drawable.toBitmap
import com.doubigue.ai.apps.InstalledApp
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Tiroir en roue (d'après le schéma) : le centre du cercle est tout près du bord de l'écran,
 * le micro est au centre, les applications forment un anneau autour, tronqué par le bord.
 * - toucher une icône : ouvre l'app (ou la ferme si elle est déjà ouverte) ;
 * - faire tourner l'anneau (glisser le long du cercle) : défile TOUTES les applications ;
 * - toucher le micro : écoute directe ; tirer encore depuis le bord / « Assistant IA » : ouvre l'assistant.
 */
@SuppressLint("ViewConstructor")
class EdgeArcView(
    context: Context,
    private val apps: List<InstalledApp>,
    private val leftSide: Boolean,
    private val onLaunch: (InstalledApp) -> Unit,
    private val onMic: () -> Unit,
    private val onAssistant: () -> Unit,
    private val onClose: () -> Unit,
    private val onInteraction: () -> Unit
) : View(context) {
    private val density = resources.displayMetrics.density
    private fun dp(v: Float) = v * density
    private fun sp(v: Float) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, resources.displayMetrics)
    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop

    var status: String = "Touchez le micro pour parler"
        set(value) { field = value; invalidate() }
    var listening: Boolean = false
        set(value) { field = value; invalidate() }

    private var progress = 0f
    private var scroll = 0f
    private var pulse = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val text = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val icons = HashMap<String, Bitmap?>()
    private val assistantRect = RectF()
    private var pulseAnim: ValueAnimator? = null
    private var flingAnim: ValueAnimator? = null

    private var downX = 0f
    private var downY = 0f
    private var prevTheta = 0f
    private var lastMoveTime = 0L
    private var velocity = 0f
    private var moved = false
    private var fromEdge = false
    private var assistantFired = false

    private val cyan = 0xFF40E0FF.toInt()
    private val blue = 0xFF4F6BFF.toInt()
    private val violet = 0xFFB45CFF.toInt()
    private val pink = 0xFFFF5CAA.toInt()
    private val orange = 0xFFFFB04A.toInt()
    private val green = 0xFF5CFF9A.toInt()

    // ---- géométrie ----
    private val ringR: Float get() = min(width * 0.40f, dp(150f))
    private val inset: Float get() = ringR * 0.55f
    private val cx: Float get() = if (leftSide) inset else width - inset
    private val cy: Float get() = height * 0.46f
    private val micR: Float get() = ringR * 0.40f
    private val inward: Float get() = if (leftSide) 0f else 180f
    private val sgn: Float get() = if (leftSide) -1f else 1f
    private val tileHalf: Float get() = dp(23f)
    private val step: Float get() = Math.toDegrees(((tileHalf * 2 + dp(8f)) / ringR).toDouble()).toFloat()
    /** Demi-ouverture visible de l'anneau : on s'arrête quand une icône sortirait de l'écran. */
    private val halfSpan: Float get() {
        val c = ((tileHalf + dp(4f) - inset) / ringR).coerceIn(-1f, 1f)
        return min(125f, Math.toDegrees(acos(c.toDouble())).toFloat())
    }
    private val halfUse: Float get() = halfSpan - 8f
    private val listLen: Float get() = max(0, apps.size - 1) * step
    private val maxScroll: Float get() = max(0f, listLen - 2 * halfUse)
    private fun tOf(i: Int): Float = if (listLen <= 2 * halfUse) listLen / 2f - i * step else halfUse - i * step + scroll
    private fun px(t: Float) = cx + ringR * cos(Math.toRadians((inward + sgn * t).toDouble())).toFloat()
    private fun py(t: Float) = cy + ringR * sin(Math.toRadians((inward + sgn * t).toDouble())).toFloat()

    private fun iconOf(app: InstalledApp): Bitmap? = icons.getOrPut(app.packageName) {
        val size = dp(76f).toInt()
        try { app.icon.toBitmap(size, size) } catch (_: Throwable) { null }
    }

    fun animateIn() {
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 260; interpolator = DecelerateInterpolator()
            addUpdateListener { progress = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    fun animateOut(end: () -> Unit) {
        ValueAnimator.ofFloat(progress, 0f).apply {
            duration = 180
            addUpdateListener { progress = it.animatedValue as Float; invalidate() }
            addListener(object : AnimatorListenerAdapter() { override fun onAnimationEnd(a: Animator) { end() } })
            start()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        pulseAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1600; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
            addUpdateListener { pulse = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        pulseAnim?.cancel(); pulseAnim = null
        flingAnim?.cancel(); flingAnim = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val p = progress
        c.drawColor(Color.argb((165 * p).toInt(), 3, 7, 20))
        val layer = c.saveLayerAlpha(0f, 0f, width.toFloat(), height.toFloat(), (255 * p).toInt())
        c.translate((1f - p) * dp(110f) * (if (leftSide) -1f else 1f), 0f)
        drawBand(c); drawArrows(c); drawMic(c); drawTiles(c); drawChips(c); drawEdgeCue(c)
        c.restoreToCount(layer)
    }

    private fun drawBand(c: Canvas) {
        val start = inward - halfSpan - 6f
        val sweep = (halfSpan + 6f) * 2f
        paint.reset(); paint.isAntiAlias = true
        paint.style = Paint.Style.STROKE; paint.strokeCap = Paint.Cap.ROUND
        paint.strokeWidth = dp(64f); paint.color = Color.argb(48, 140, 190, 255)
        c.drawArc(RectF(cx - ringR, cy - ringR, cx + ringR, cy + ringR), start, sweep, false, paint)
        paint.strokeWidth = dp(2.2f)
        paint.shader = SweepGradient(cx, cy, intArrayOf(cyan, blue, violet, pink, cyan), null)
        val off = dp(32f)
        c.drawArc(RectF(cx - ringR - off, cy - ringR - off, cx + ringR + off, cy + ringR + off), start, sweep, false, paint)
        c.drawArc(RectF(cx - ringR + off, cy - ringR + off, cx + ringR - off, cy + ringR - off), start, sweep, false, paint)
        paint.shader = null
    }

    /** Flèches de rotation (comme sur le schéma) sur le côté extérieur de l'anneau. */
    private fun drawArrows(c: Canvas) {
        val ra = ringR + dp(46f)
        val a0 = inward - 42f; val a1 = inward + 42f
        paint.reset(); paint.isAntiAlias = true; paint.style = Paint.Style.STROKE
        paint.strokeWidth = dp(3.2f); paint.strokeCap = Paint.Cap.ROUND
        paint.shader = LinearGradient(cx - ra, cy - ra, cx - ra, cy + ra, intArrayOf(0xFF9BE8FF.toInt(), 0xFF4F8BFF.toInt(), 0xFF9BE8FF.toInt()), null, Shader.TileMode.CLAMP)
        c.drawArc(RectF(cx - ra, cy - ra, cx + ra, cy + ra), a0, a1 - a0, false, paint)
        fun head(angle: Float, dir: Float) {
            val r = Math.toRadians(angle.toDouble())
            val x = cx + ra * cos(r).toFloat(); val y = cy + ra * sin(r).toFloat()
            val dx = -sin(r).toFloat() * dir; val dy = cos(r).toFloat() * dir     // tangente, orientée vers l'extérieur du tracé
            val nx = -dy; val ny = dx; val l = dp(11f)
            val path = Path().apply {
                moveTo(x + dx * l * .4f, y + dy * l * .4f)
                lineTo(x - dx * l * .6f + nx * l * .8f, y - dy * l * .6f + ny * l * .8f)
                lineTo(x - dx * l * .6f - nx * l * .8f, y - dy * l * .6f - ny * l * .8f)
                close()
            }
            paint.style = Paint.Style.FILL; c.drawPath(path, paint); paint.style = Paint.Style.STROKE
        }
        head(a1, 1f); head(a0, -1f)
        paint.shader = null
    }

    private fun starPath(x: Float, y: Float, s: Float): Path = Path().apply {
        moveTo(x, y - s)
        quadTo(x + s * .12f, y - s * .12f, x + s, y)
        quadTo(x + s * .12f, y + s * .12f, x, y + s)
        quadTo(x - s * .12f, y + s * .12f, x - s, y)
        quadTo(x - s * .12f, y - s * .12f, x, y - s)
        close()
    }

    private fun drawMic(c: Canvas) {
        val sx = cx; val sy = cy; val r = micR
        paint.reset(); paint.isAntiAlias = true
        paint.shader = RadialGradient(sx, sy, r * 1.7f, intArrayOf(0x663A7BFF, 0x00000000), floatArrayOf(.45f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(sx, sy, r * 1.7f, paint)
        if (listening) for (k in 0..1) {
            val ph = (pulse + k * .5f) % 1f
            paint.reset(); paint.isAntiAlias = true; paint.style = Paint.Style.STROKE
            paint.strokeWidth = dp(2f); paint.color = Color.argb((150 * (1f - ph)).toInt(), 120, 220, 255)
            c.drawCircle(sx, sy, r * (1.05f + .45f * ph), paint)
        }
        paint.reset(); paint.isAntiAlias = true
        paint.shader = RadialGradient(sx - r * .3f, sy - r * .35f, r * 1.25f,
            intArrayOf(0xFF8FC2FF.toInt(), 0xFF2448D8.toInt(), 0xFF0B1366.toInt()), floatArrayOf(0f, .5f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(sx, sy, r, paint)
        val period = if (listening) 2500L else 9000L
        val angle = (SystemClock.uptimeMillis() % period) / period.toFloat() * 360f
        val sweep = SweepGradient(sx, sy, intArrayOf(cyan, blue, violet, pink, orange, green, cyan), null)
        sweep.setLocalMatrix(Matrix().apply { setRotate(angle, sx, sy) })
        paint.reset(); paint.isAntiAlias = true; paint.style = Paint.Style.STROKE
        paint.strokeWidth = dp(3f); paint.shader = sweep
        c.save(); c.rotate(-25f, sx, sy)
        c.drawOval(RectF(sx - r * 1.22f, sy - r * .55f, sx + r * 1.22f, sy + r * .55f), paint)
        c.restore()
        val s = r * .30f
        paint.reset(); paint.isAntiAlias = true
        paint.shader = LinearGradient(sx - s, sy - r * .2f - s, sx + s, sy - r * .2f + s, intArrayOf(0xFF4FD8FF.toInt(), violet, orange), null, Shader.TileMode.CLAMP)
        c.drawPath(starPath(sx, sy - r * .2f, s), paint)
        val my = sy + r * .42f; val w = r * .2f; val h = r * .36f
        paint.reset(); paint.isAntiAlias = true; paint.color = if (listening) 0xFF9BF0FF.toInt() else Color.WHITE
        c.drawRoundRect(RectF(sx - w / 2, my - h * .7f, sx + w / 2, my + h * .3f), w / 2, w / 2, paint)
        paint.style = Paint.Style.STROKE; paint.strokeWidth = dp(2.2f); paint.strokeCap = Paint.Cap.ROUND
        c.drawArc(RectF(sx - w * .95f, my - h * .45f, sx + w * .95f, my + h * .45f), 20f, 140f, false, paint)
        c.drawLine(sx, my + h * .45f, sx, my + h * .62f, paint)
        c.drawLine(sx - w * .6f, my + h * .62f, sx + w * .6f, my + h * .62f, paint)
    }

    private fun drawTiles(c: Canvas) {
        for (i in apps.indices) {
            val t = tOf(i)
            if (abs(t) > halfSpan) continue
            val fade = ((abs(t) - (halfUse - 10f)) / 18f).coerceIn(0f, 1f)
            val scale = 1f - .28f * fade
            val alpha = (255 * (1f - .8f * fade)).toInt()
            val x = px(t); val y = py(t); val half = tileHalf * scale
            val rect = RectF(x - half, y - half, x + half, y + half)
            paint.reset(); paint.isAntiAlias = true; paint.color = Color.argb((alpha * .28f).toInt(), 200, 225, 255)
            c.drawRoundRect(rect, dp(13f) * scale, dp(13f) * scale, paint)
            paint.style = Paint.Style.STROKE; paint.strokeWidth = dp(1.2f); paint.color = Color.argb((alpha * .55f).toInt(), 160, 210, 255)
            c.drawRoundRect(rect, dp(13f) * scale, dp(13f) * scale, paint)
            iconOf(apps[i])?.let { bmp ->
                val ih = dp(34f) * scale
                bmpPaint.alpha = alpha
                c.drawBitmap(bmp, null, RectF(x - ih / 2, y - ih / 2, x + ih / 2, y + ih / 2), bmpPaint)
            }
        }
    }

    private fun chip(c: Canvas, r: RectF, corner: Float) {
        paint.reset(); paint.isAntiAlias = true
        paint.style = Paint.Style.FILL; paint.color = Color.argb(225, 14, 22, 56)
        c.drawRoundRect(r, corner, corner, paint)
        paint.style = Paint.Style.STROKE; paint.strokeWidth = dp(1.5f); paint.color = Color.argb(170, 130, 170, 255)
        c.drawRoundRect(r, corner, corner, paint)
    }

    private fun drawChips(c: Canvas) {
        val w = min(dp(236f), width * .7f); val h = dp(54f); val l = dp(14f); val t = dp(56f)
        assistantRect.set(l, t, l + w, t + h)
        chip(c, assistantRect, h / 2f)
        val ax = assistantRect.left + dp(28f); val ay = assistantRect.centerY()
        paint.reset(); paint.isAntiAlias = true
        paint.shader = LinearGradient(ax - dp(13f), ay - dp(13f), ax + dp(13f), ay + dp(13f), intArrayOf(0xFF4FD8FF.toInt(), 0xFF5B7CFF.toInt()), null, Shader.TileMode.CLAMP)
        c.drawPath(starPath(ax, ay, dp(13f)), paint)
        text.reset(); text.isAntiAlias = true; text.color = Color.WHITE; text.textSize = sp(15f); text.typeface = Typeface.DEFAULT_BOLD
        c.drawText("Assistant IA", assistantRect.left + dp(54f), assistantRect.top + h * .44f, text)
        text.typeface = Typeface.DEFAULT; text.textSize = sp(12.5f); text.color = 0xFFB9C7E8.toInt()
        c.drawText("Touchez pour ouvrir", assistantRect.left + dp(54f), assistantRect.top + h * .76f, text)

        val bw = min(dp(250f), width * .64f)
        text.reset(); text.isAntiAlias = true; text.color = Color.WHITE; text.textSize = sp(14f)
        text.typeface = if (listening) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        val layout = StaticLayout.Builder.obtain(status, 0, status.length, text, (bw - dp(28f)).toInt())
            .setMaxLines(3).setEllipsize(TextUtils.TruncateAt.END).build()
        val bh = layout.height + dp(22f)
        val bl = (cx - bw / 2f).coerceIn(dp(10f), max(dp(10f), width - dp(10f) - bw))
        val bt = cy + ringR + tileHalf + dp(18f)
        chip(c, RectF(bl, bt, bl + bw, bt + bh), dp(20f))
        c.save(); c.translate(bl + dp(14f), bt + dp(11f)); layout.draw(c); c.restore()

        if (maxScroll > 0f && height > dp(560f)) {
            val hint = "Faites tourner l'anneau pour voir plus d'apps"
            text.reset(); text.isAntiAlias = true; text.textSize = sp(13f); text.color = 0xFFD5DEF5.toInt()
            val hw = min(text.measureText(hint) + dp(32f), width - dp(20f)); val hl = (width - hw) / 2f; val ht = height - dp(120f)
            chip(c, RectF(hl, ht, hl + hw, ht + dp(40f)), dp(20f))
            c.drawText(TextUtils.ellipsize(hint, text, hw - dp(32f), TextUtils.TruncateAt.END).toString(), hl + dp(16f), ht + dp(25f), text)
        }
    }

    private fun drawEdgeCue(c: Canvas) {
        val a = (110 + 100 * sin(pulse * 2 * Math.PI)).toInt().coerceIn(0, 255)
        paint.reset(); paint.isAntiAlias = true; paint.style = Paint.Style.STROKE
        paint.strokeWidth = dp(2.5f); paint.strokeCap = Paint.Cap.ROUND; paint.color = Color.argb(a, 130, 220, 255)
        val s = if (leftSide) 1f else -1f
        val x0 = if (leftSide) dp(5f) else width - dp(5f)
        val p = Path().apply { moveTo(x0, cy - dp(14f)); lineTo(x0 + s * dp(9f), cy); lineTo(x0, cy + dp(14f)) }
        c.drawPath(p, paint)
    }

    private fun thetaOf(x: Float, y: Float) = Math.toDegrees(atan2((y - cy).toDouble(), (x - cx).toDouble())).toFloat()
    private fun wrap(a: Float): Float { var v = a; while (v > 180f) v -= 360f; while (v < -180f) v += 360f; return v }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                flingAnim?.cancel()
                downX = e.x; downY = e.y; moved = false; assistantFired = false; velocity = 0f
                prevTheta = thetaOf(e.x, e.y); lastMoveTime = e.eventTime
                fromEdge = if (leftSide) e.x < dp(44f) else e.x > width - dp(44f)
                onInteraction()
            }
            MotionEvent.ACTION_MOVE -> {
                onInteraction()
                val dx = e.x - downX; val dy = e.y - downY
                val inw = if (leftSide) dx else -dx
                if (fromEdge && !assistantFired && inw > dp(48f) && abs(dx) > abs(dy)) {
                    assistantFired = true; moved = true; onAssistant(); return true
                }
                if (!moved && (abs(dx) > touchSlop || abs(dy) > touchSlop)) { moved = true; prevTheta = thetaOf(e.x, e.y) }
                if (moved && !assistantFired && hypot(e.x - cx, e.y - cy) > dp(34f)) {
                    val th = thetaOf(e.x, e.y)
                    val d = wrap(th - prevTheta)
                    prevTheta = th
                    val ns = (scroll + sgn * d).coerceIn(0f, maxScroll)
                    val dt = max(1L, e.eventTime - lastMoveTime)
                    velocity = velocity * .6f + ((ns - scroll) / dt) * .4f
                    lastMoveTime = e.eventTime
                    scroll = ns
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP -> {
                if (!moved) handleTap(e.x, e.y)
                else if (!assistantFired && maxScroll > 0f && abs(velocity) > .05f && e.eventTime - lastMoveTime < 90) fling()
            }
        }
        return true
    }

    private fun fling() {
        val s0 = scroll
        val target = (s0 + velocity * 360f).coerceIn(0f, maxScroll)
        if (abs(target - s0) < 6f) return
        flingAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 700; interpolator = DecelerateInterpolator(1.6f)
            addUpdateListener { scroll = s0 + (target - s0) * (it.animatedValue as Float); invalidate() }
            start()
        }
    }

    private fun handleTap(x: Float, y: Float) {
        if (assistantRect.contains(x, y)) { onAssistant(); return }
        if (hypot(x - cx, y - cy) <= micR * 1.15f) { onMic(); return }
        for (i in apps.indices) {
            val t = tOf(i)
            if (abs(t) > halfSpan) continue
            if (hypot(x - px(t), y - py(t)) <= tileHalf + dp(4f)) { onLaunch(apps[i]); return }
        }
        if (hypot(x - cx, y - cy) > ringR + dp(80f)) onClose()
    }
}
