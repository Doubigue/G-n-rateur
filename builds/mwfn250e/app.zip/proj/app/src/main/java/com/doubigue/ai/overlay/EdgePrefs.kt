package com.doubigue.ai.overlay

import android.content.Context
import com.doubigue.ai.apps.InstalledApp

/** Réglages du tiroir en arc (lisibles de façon synchrone par le service et le récepteur de démarrage). */
object EdgePrefs {
    private fun sp(c: Context) = c.getSharedPreferences("doubigue_edge", Context.MODE_PRIVATE)
    fun isEnabled(c: Context) = sp(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) { sp(c).edit().putBoolean("enabled", v).apply() }
    fun side(c: Context): String = sp(c).getString("side", "right") ?: "right"
    fun setSide(c: Context, v: String) { sp(c).edit().putString("side", v).apply() }
    fun favorites(c: Context): List<String> =
        (sp(c).getString("favorites", "") ?: "").split(',').filter { it.isNotBlank() }
    fun setFavorites(c: Context, list: List<String>) { sp(c).edit().putString("favorites", list.joinToString(",")).apply() }

    /** Favoris choisis ; sinon TOUTES les applications lançables (triées par nom). */
    fun resolveShortcuts(c: Context): List<InstalledApp> {
        val pm = c.packageManager
        val chosen = favorites(c).mapNotNull { pkg ->
            try {
                if (pkg == c.packageName || pm.getLaunchIntentForPackage(pkg) == null) null else {
                    val ai = pm.getApplicationInfo(pkg, 0)
                    InstalledApp(pm.getApplicationLabel(ai).toString(), pkg, pm.getApplicationIcon(ai))
                }
            } catch (_: Exception) { null }
        }
        return if (chosen.isNotEmpty()) chosen else com.doubigue.ai.apps.AppController(c).installedApps()
    }
}
