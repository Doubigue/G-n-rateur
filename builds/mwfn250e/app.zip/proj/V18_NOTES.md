# V18
- Tiroir en roue d'après ton schéma : centre près du bord (droite par défaut, réglable), micro au centre, anneau d'apps qui tourne (flèches de rotation), toutes les apps par défaut (ou ton choix).
- Toucher une icône = même logique que la voix : ouvre avec le son de l'app (ou son par défaut) ; retoucher une app ouverte la ferme avec son son de fermeture.
- Micro du tiroir : joue d'abord « Je vous écoute » (son importé dans Paramètres > Sons d'événements), puis écoute.
- Apps ouvertes depuis le menu du téléphone : annonce sonore (option dans Sons d'événements, nécessite « Données d'utilisation »).
- Lampe / Wi-Fi / Bluetooth / Internet : petit écran avec interrupteur (lampe, Bluetooth) ou panneau système (Wi-Fi, Internet), + un son par commande dans Sons d'événements.
- Échecs PIN / schéma / mot de passe / empreinte : service d'accessibilité de secours qui reconnaît le type d'échec.
- Compilation et tests sur téléphone : NON FAITS ici.
- V18.1 : le son de bienvenue joue à chaque entrée dans l'appli (même non fermée), sauf rotation d'écran.
