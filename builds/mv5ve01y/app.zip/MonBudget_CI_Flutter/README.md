# MonBudget CI — Flutter / Dart

Application Flutter mobile de gestion financière, stockage local SQLite, sans compte cloud.

## Inclus
- Tableau de bord mensuel revenus/dépenses/solde net
- Dépenses, revenus et transferts avec contrôle de solde
- Comptes, dépensiers, catégories et budgets
- Rapports mensuels par catégorie
- Export/partage et restauration JSON
- Espace administrateur avec PIN local modifiable
- Interface sombre, FCFA, données hors ligne

## Ouvrir et générer un APK
Prérequis : Flutter SDK et Android SDK installés.
```bash
flutter doctor
flutter pub get
flutter run
flutter build apk --release
```
L'APK est généralement généré dans `build/app/outputs/flutter-apk/app-release.apk`.

Si les dossiers Android/plateforme ne sont pas présents, exécutez `flutter create .` depuis ce dossier, puis `flutter pub get`.

PIN initial : `1234`. Changez-le dans Administration. Le PIN protège l'interface mais ne chiffre pas la base de données. La sauvegarde ouvre la feuille de partage Android pour enregistrer le JSON. Gardez le fichier privé.

## Notes de version (corrections pour la compilation CI)
- PDF : les tableaux utilisent maintenant `TableRow` (l'ancien code ne compilait pas) ; les espaces fines des montants et les emojis ne sont plus envoyés à la police PDF.
- Barre de progression des rapports : conversion explicite en `double`.
- Le bouton « Plus » ouvre un menu : Dépensiers, Catégories, Rapports, Sauvegarde, Administration (ces écrans n'étaient pas accessibles).
- Saisie : date `AAAA-MM-JJ` vérifiée, virgule décimale acceptée.
