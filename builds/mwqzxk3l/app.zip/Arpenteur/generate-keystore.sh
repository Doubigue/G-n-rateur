#!/usr/bin/env bash
# Génère la clé de signature dédiée d'Arpenteur + keystore.properties
set -e
cd "$(dirname "$0")"
KS=arpenteur-release.jks; ALIAS=arpenteur
[ -f "$KS" ] && { echo "$KS existe déjà : rien n'a été écrasé."; exit 1; }
read -rp "Nom ou organisation (CN) : " CN
read -rsp "Mot de passe de la clé (6 caractères min.) : " PW; echo
keytool -genkeypair -v -keystore "$KS" -alias "$ALIAS" -keyalg RSA -keysize 4096 \
  -validity 10000 -storepass "$PW" -keypass "$PW" -dname "CN=$CN"
cat > keystore.properties <<EOP
storeFile=$KS
storePassword=$PW
keyAlias=$ALIAS
keyPassword=$PW
EOP
echo
echo "OK : $KS et keystore.properties créés."
echo "SAUVEGARDEZ $KS + le mot de passe (cloud chiffré + clé USB). Perdue = impossible de mettre à jour l'app."
echo "Build signé : ./gradlew assembleRelease  (APK) ou ./gradlew bundleRelease (AAB Play Store)"
