# Arpenteur — mesure de parcelle 100 % hors ligne
1. Ouvrir ce dossier dans Android Studio (Koala+), laisser Gradle synchroniser (il génère le wrapper).
2. Brancher un téléphone Android 10+, Run ▶.
Aucun réseau, aucune clé API : GPS brut (LocationManager + GnssStatus).
Exports : Téléchargements/Arpenteur (.geojson / .csv).

## Carte & rapport (osmdroid)
Après « Fermer » : bouton **Carte & rapport pro** → fond Satellite (Esri) ou Plan (OSM), téléchargement des tuiles
pour le hors-ligne (≤ 1500 tuiles, zoom 14–19), export **PDF A4** ou **PNG** dans Téléchargements/Arpenteur.
Respecter les conditions d'usage des tuiles (OSM / Esri) : petites zones uniquement.

## Clé dédiée pour les tuiles (MapTiler)
1. Créez une clé sur https://cloud.maptiler.com/account/keys/
2. Ajoutez `MAPTILER_KEY=...` dans `local.properties` (voir `local.properties.example`), puis resynchronisez Gradle.
3. Sans clé, l'app retombe sur Esri / OSM publics (usage léger uniquement).
La clé est injectée dans BuildConfig au build : jamais dans le code source ni dans Git.

## Signature (clé dédiée)
1. `./generate-keystore.sh` → crée `arpenteur-release.jks` + `keystore.properties` (ignorés par git).
2. `./gradlew assembleRelease` → `app/build/outputs/apk/release/app-release.apk` signé.
   `./gradlew bundleRelease` → AAB pour le Play Store (activer Play App Signing).
3. Sans `keystore.properties`, le build release n'est pas signé (aucune clé n'est jamais incluse dans le projet).
