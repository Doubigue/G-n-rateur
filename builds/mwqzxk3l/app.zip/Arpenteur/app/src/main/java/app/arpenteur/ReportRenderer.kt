package app.arpenteur

import android.graphics.*
import android.graphics.pdf.PdfDocument
import java.io.ByteArrayOutputStream
import java.util.Locale
import kotlin.math.*

data class ReportData(
    val name: String, val date: String, val points: List<GeoPoint>,
    val areaM2: Double, val perimeterM: Double, val credit: String
)

/** Rapport A4 : en-tête, carte (ou plan), chiffres clés, tableau des bornes. Vectoriel en PDF. */
object ReportRenderer {
    const val W = 1240f
    const val H = 1754f
    private val DARK = Color.parseColor("#0B1410")
    private val GREEN = Color.parseColor("#3DDC84")
    private val INK = Color.parseColor("#13201A")
    private val MUTED = Color.parseColor("#6B7C73")
    private val BG = Color.parseColor("#F2F5F3")

    private fun p(color: Int, size: Float = 28f, bold: Boolean = false, align: Paint.Align = Paint.Align.LEFT) =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color; textSize = size; textAlign = align
            typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }

    private fun nice(m: Double) = listOf(1, 2, 5, 10, 20, 50, 100, 200, 500, 1000, 2000, 5000).map { it.toDouble() }

    fun draw(c: Canvas, d: ReportData, map: Bitmap?, mapPxPerM: Double?) {
        val fr = Locale.FRANCE
        c.drawColor(BG)
        // En-tête
        c.drawRect(0f, 0f, W, 250f, p(DARK)); c.drawRect(0f, 250f, W, 262f, p(GREEN))
        c.drawText("PLAN DE PARCELLE", 60f, 85f, p(GREEN, 26f, true).apply { letterSpacing = .2f })
        c.drawText(d.name.take(28), 60f, 165f, p(Color.WHITE, 68f, true))
        c.drawText("${d.date}  •  WGS84", 60f, 215f, p(Color.parseColor("#B5C4BB"), 28f))
        c.drawText("ARPENTEUR", W - 60, 85f, p(Color.WHITE, 26f, true, Paint.Align.RIGHT).apply { letterSpacing = .2f })

        // Cadre carte (4:3)
        val fw = W - 120f; val fh = fw * 3 / 4
        val frame = RectF(60f, 300f, 60f + fw, 300f + fh)
        c.save()
        c.clipPath(Path().apply { addRoundRect(frame, 28f, 28f, Path.Direction.CW) })
        c.drawRect(frame, p(Color.parseColor("#12201A")))
        val ppm: Double
        if (map != null) {
            c.drawBitmap(map, null, frame, Paint(Paint.FILTER_BITMAP_FLAG))
            ppm = (mapPxPerM ?: 1.0) * fw / map.width
        } else ppm = drawPlan(c, d, frame)
        c.restore()
        c.drawRoundRect(frame, 28f, 28f, Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 5f; color = Color.WHITE })

        // Rose des vents
        val nx = frame.right - 70f; val ny = frame.top + 85f
        c.drawCircle(nx, ny, 46f, p(Color.argb(210, 255, 255, 255)))
        c.drawPath(Path().apply { moveTo(nx, ny - 30f); lineTo(nx - 15f, ny + 14f); lineTo(nx, ny + 6f); lineTo(nx + 15f, ny + 14f); close() }, p(DARK))
        c.drawText("N", nx, ny - 34f, p(Color.WHITE, 26f, true, Paint.Align.CENTER).apply { setShadowLayer(4f, 0f, 0f, Color.BLACK) })

        // Barre d'échelle
        val step = nice(0.0).firstOrNull { it * ppm >= 150 } ?: 5000.0
        val bw = (step * ppm).toFloat(); val bx = frame.left + 36f; val by = frame.bottom - 44f
        c.drawRoundRect(RectF(bx - 16f, by - 50f, bx + bw + 16f, by + 22f), 14f, 14f, p(Color.argb(210, 255, 255, 255)))
        val lp = p(DARK).apply { strokeWidth = 5f }
        c.drawLine(bx, by, bx + bw, by, lp); c.drawLine(bx, by - 10f, bx, by + 10f, lp); c.drawLine(bx + bw, by - 10f, bx + bw, by + 10f, lp)
        c.drawText(if (step >= 1000) "${(step / 1000).toInt()} km" else "${step.toInt()} m", bx + bw / 2, by - 16f, p(DARK, 24f, true, Paint.Align.CENTER))
        c.drawText(d.credit, frame.right - 24f, frame.bottom - 20f,
            p(Color.WHITE, 19f, false, Paint.Align.RIGHT).apply { setShadowLayer(5f, 0f, 0f, Color.BLACK) })

        // Cartes de chiffres clés
        val cy = frame.bottom + 40f; val cw = (fw - 60f) / 4; val ch = 170f
        val stats = listOf(
            Triple("SURFACE", String.format(fr, "%.4f ha", d.areaM2 / 10000), true),
            Triple("SURFACE", String.format(fr, "%,.0f m²", d.areaM2), false),
            Triple("PÉRIMÈTRE", if (d.perimeterM >= 1000) String.format(fr, "%.3f km", d.perimeterM / 1000) else String.format(fr, "%.1f m", d.perimeterM), false),
            Triple("ACRES", String.format(fr, "%.2f ac", d.areaM2 / 4046.8564224), false)
        )
        stats.forEachIndexed { i, (label, value, hero) ->
            val r = RectF(60f + i * (cw + 20f), cy, 60f + i * (cw + 20f) + cw, cy + ch)
            c.drawRoundRect(r, 22f, 22f, p(if (hero) DARK else Color.WHITE))
            c.drawText(label, r.left + 24f, r.top + 52f, p(if (hero) GREEN else MUTED, 22f, true).apply { letterSpacing = .15f })
            c.drawText(value, r.left + 24f, r.top + 118f, p(if (hero) Color.WHITE else INK, if (value.length > 11) 34f else 40f, true))
        }

        // Tableau des bornes
        val ty = cy + ch + 36f
        val tr = RectF(60f, ty, 60f + fw, 1700f)
        c.drawRoundRect(tr, 22f, 22f, p(Color.WHITE))
        val cols = floatArrayOf(90f, 190f, 470f, 760f, 960f)
        val head = listOf("N°", "LATITUDE", "LONGITUDE", "CÔTÉ (m)", "PRÉCISION")
        head.forEachIndexed { i, h -> c.drawText(h, cols[i], ty + 50f, p(MUTED, 20f, true).apply { letterSpacing = .1f }) }
        val seg = GeoCalculator.segments(d.points, true)
        val maxRows = ((tr.bottom - ty - 90f) / 34f).toInt().coerceAtLeast(1)
        val shown = if (d.points.size > maxRows) maxRows - 1 else d.points.size
        d.points.take(shown).forEachIndexed { i, q ->
            val y = ty + 92f + i * 34f
            if (i % 2 == 0) c.drawRect(72f, y - 26f, tr.right - 12f, y + 8f, p(Color.parseColor("#F6F9F7")))
            val cells = listOf("${i + 1}", String.format(Locale.US, "%.6f°", q.lat), String.format(Locale.US, "%.6f°", q.lon),
                String.format(fr, "%.1f", seg.getOrElse(i) { 0.0 }), if (q.acc > 0) String.format(fr, "± %.1f m", q.acc) else "—")
            cells.forEachIndexed { k, t -> c.drawText(t, cols[k], y, p(INK, 24f, k == 0)) }
        }
        if (d.points.size > shown)
            c.drawText("… et ${d.points.size - shown} autre(s) borne(s) — voir l'export CSV / GeoJSON", cols[0], ty + 92f + shown * 34f, p(MUTED, 22f))
        c.drawText("Généré par Arpenteur  •  mesure GPS, précision dépendante du signal", W / 2, 1735f, p(MUTED, 20f, false, Paint.Align.CENTER))
    }

    /** Plan quadrillé quand aucun fond de carte n'est disponible. Retourne px/m. */
    private fun drawPlan(c: Canvas, d: ReportData, f: RectF): Double {
        val loc = GeoCalculator.toLocal(d.points, d.points[0])
        val minX = loc.minOf { it.first }; val maxX = loc.maxOf { it.first }
        val minY = loc.minOf { it.second }; val maxY = loc.maxOf { it.second }
        val sc = min((f.width() - 200) / max(maxX - minX, 20.0), (f.height() - 200) / max(maxY - minY, 20.0))
        val cx = (minX + maxX) / 2; val cy = (minY + maxY) / 2
        fun sx(x: Double) = (f.centerX() + (x - cx) * sc).toFloat()
        fun sy(y: Double) = (f.centerY() - (y - cy) * sc).toFloat()
        val step = nice(0.0).firstOrNull { it * sc >= 70 } ?: 1000.0
        val gp = p(Color.argb(28, 255, 255, 255)).apply { strokeWidth = 2f }
        var gx = floor((cx - f.width() / 2 / sc) / step) * step
        while (gx < cx + f.width() / 2 / sc) { c.drawLine(sx(gx), f.top, sx(gx), f.bottom, gp); gx += step }
        var gy = floor((cy - f.height() / 2 / sc) / step) * step
        while (gy < cy + f.height() / 2 / sc) { c.drawLine(f.left, sy(gy), f.right, sy(gy), gp); gy += step }
        val path = Path().apply { moveTo(sx(loc[0].first), sy(loc[0].second)); loc.drop(1).forEach { lineTo(sx(it.first), sy(it.second)) }; close() }
        c.drawPath(path, p(Color.argb(80, 61, 220, 132)))
        c.drawPath(path, p(GREEN).apply { style = Paint.Style.STROKE; strokeWidth = 7f; strokeJoin = Paint.Join.ROUND })
        val seg = GeoCalculator.segments(d.points, true)
        loc.indices.forEach { i ->
            val a = loc[i]; val b = loc[(i + 1) % loc.size]
            c.drawText(String.format(Locale.FRANCE, "%.1f m", seg[i]), sx((a.first + b.first) / 2), sy((a.second + b.second) / 2) - 16f,
                p(Color.parseColor("#FFC857"), 26f, true, Paint.Align.CENTER))
        }
        loc.forEachIndexed { i, q ->
            c.drawCircle(sx(q.first), sy(q.second), 22f, p(DARK)); c.drawCircle(sx(q.first), sy(q.second), 18f, p(if (i == 0) Color.parseColor("#FFC857") else GREEN))
            c.drawText("${i + 1}", sx(q.first), sy(q.second) + 9f, p(Color.BLACK, 24f, true, Paint.Align.CENTER))
        }
        return sc
    }

    fun toPng(d: ReportData, map: Bitmap?, ppm: Double?): ByteArray {
        val bmp = Bitmap.createBitmap(W.toInt(), H.toInt(), Bitmap.Config.ARGB_8888)
        draw(Canvas(bmp), d, map, ppm)
        return ByteArrayOutputStream().also { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }.toByteArray()
    }

    fun toPdf(d: ReportData, map: Bitmap?, ppm: Double?): ByteArray {
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
        page.canvas.scale(595f / W, 842f / H)
        draw(page.canvas, d, map, ppm)
        doc.finishPage(page)
        return ByteArrayOutputStream().also { doc.writeTo(it); doc.close() }.toByteArray()
    }
}
