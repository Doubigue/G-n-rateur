package app.arpenteur

import android.graphics.Paint
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import kotlin.math.*

private val Green = Color(0xFF3DDC84)
private val Blue = Color(0xFF4FC3F7)
private val Amber = Color(0xFFFFC857)

/** Plan cartésien en direct, à l'échelle, sans aucun fond de carte. */
@Composable
fun PlotCanvas(points: List<GeoPoint>, fix: Fix?, closed: Boolean, modifier: Modifier = Modifier,
               polygon: Boolean = true, closeRadius: Float = 0f, letters: Boolean = false) {
    val pulse by rememberInfiniteTransition(label = "pulse")
        .animateFloat(0f, 1f, infiniteRepeatable(tween(1500, easing = LinearEasing)), label = "p")
    val paint = remember { Paint().apply { isAntiAlias = true; textAlign = Paint.Align.CENTER } }

    Canvas(modifier) {
        val w = size.width; val h = size.height
        val sp = 11.dp.toPx()
        fun text(t: String, x: Float, y: Float, c: Color, size: Float = sp, bold: Boolean = false, align: Paint.Align = Paint.Align.CENTER) {
            paint.color = c.toArgb(); paint.textSize = size; paint.textAlign = align
            paint.isFakeBoldText = bold
            drawIntoCanvas { it.nativeCanvas.drawText(t, x, y, paint) }
        }

        val cur = fix?.toPoint()
        val origin = points.firstOrNull() ?: cur
        if (origin == null) {
            text("En attente du signal GPS…", w / 2, h / 2, Color.White.copy(.6f), 14.dp.toPx())
            return@Canvas
        }
        val loc = GeoCalculator.toLocal(points, origin)
        val curL = cur?.let { GeoCalculator.toLocal(listOf(it), origin)[0] }
        val all = loc + listOfNotNull(curL)
        val minX = all.minOf { it.first }; val maxX = all.maxOf { it.first }
        val minY = all.minOf { it.second }; val maxY = all.maxOf { it.second }
        val pad = 44.dp.toPx()
        val spanX = max(maxX - minX, 20.0); val spanY = max(maxY - minY, 20.0)
        val scale = min((w - 2 * pad) / spanX, (h - 2 * pad) / spanY)
        val cx = (minX + maxX) / 2; val cy = (minY + maxY) / 2
        fun sx(x: Double) = (w / 2 + (x - cx) * scale).toFloat()
        fun sy(y: Double) = (h / 2 - (y - cy) * scale).toFloat()

        // Grille à l'échelle
        val steps = listOf(1.0, 2.0, 5.0, 10.0, 20.0, 50.0, 100.0, 200.0, 500.0, 1000.0)
        val step = steps.firstOrNull { it * scale >= 36.dp.toPx() } ?: 1000.0
        var gx = floor((cx - w / 2 / scale) / step) * step
        while (gx < cx + w / 2 / scale) {
            drawLine(Color.White.copy(.07f), Offset(sx(gx), 0f), Offset(sx(gx), h)); gx += step
        }
        var gy = floor((cy - h / 2 / scale) / step) * step
        while (gy < cy + h / 2 / scale) {
            drawLine(Color.White.copy(.07f), Offset(0f, sy(gy)), Offset(w, sy(gy))); gy += step
        }

        // Polygone
        if (loc.size >= 2) {
            val path = Path().apply {
                moveTo(sx(loc[0].first), sy(loc[0].second))
                loc.drop(1).forEach { lineTo(sx(it.first), sy(it.second)) }
                if (closed) close()
            }
            if (polygon && loc.size >= 3) {
                val fill = Path().apply { addPath(path); close() }
                drawPath(fill, Green.copy(if (closed) .28f else .12f))
            }
            drawPath(path, Green, style = Stroke(3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        val dash = PathEffect.dashPathEffect(floatArrayOf(14f, 10f))
        if (polygon && !closed && loc.size >= 3) { // fermeture provisoire
            drawLine(Green.copy(.5f), Offset(sx(loc.last().first), sy(loc.last().second)),
                Offset(sx(loc[0].first), sy(loc[0].second)), 2.dp.toPx(), pathEffect = dash)
        }
        if (!closed && curL != null && loc.isNotEmpty()) {
            drawLine(Blue.copy(.7f), Offset(sx(loc.last().first), sy(loc.last().second)),
                Offset(sx(curL.first), sy(curL.second)), 2.dp.toPx(), pathEffect = dash)
            val dm = hypot(curL.first - loc.last().first, curL.second - loc.last().second)
            text(if (dm >= 1000) "%.2f km".format(dm / 1000) else "%.1f m".format(dm),
                sx((curL.first + loc.last().first) / 2), sy((curL.second + loc.last().second) / 2) - 8.dp.toPx(), Blue, sp * .9f, true)
        }

        // Zone de fermeture autour du point de départ
        if (polygon && closeRadius > 0f && !closed && loc.size >= 3) {
            val c0 = Offset(sx(loc[0].first), sy(loc[0].second)); val r0 = max(closeRadius * scale.toFloat(), 14.dp.toPx())
            drawCircle(Amber.copy(.15f), r0, c0)
            drawCircle(Amber.copy(.8f), r0, c0, style = Stroke(2.dp.toPx(), pathEffect = dash))
        }

        // Distances des segments
        GeoCalculator.segments(points, closed).forEachIndexed { i, d ->
            val a = loc[i]; val b = loc[(i + 1) % loc.size]
            val label = if (d >= 1000) "%.2f km".format(d / 1000) else "%.1f m".format(d)
            text(label, sx((a.first + b.first) / 2), sy((a.second + b.second) / 2) - 8.dp.toPx(), Amber, sp * .9f, true)
        }

        // Bornes numérotées
        loc.forEachIndexed { i, p ->
            drawCircle(Color(0xFF0B1410), 11.dp.toPx(), Offset(sx(p.first), sy(p.second)))
            drawCircle(if (i == 0) Amber else Green, 9.dp.toPx(), Offset(sx(p.first), sy(p.second)))
            text(if (letters) ('A' + i % 26).toString() else "${i + 1}", sx(p.first), sy(p.second) + 4.dp.toPx(), Color.Black, sp * .9f, true)
        }

        // Position actuelle + cercle de précision pulsant
        if (curL != null && fix != null) {
            val c = Offset(sx(curL.first), sy(curL.second))
            val r = max(fix.acc * scale.toFloat(), 8.dp.toPx())
            drawCircle(Blue.copy(.12f), r, c)
            drawCircle(Blue.copy(.5f * (1 - pulse)), r * (.4f + .6f * pulse) + 6.dp.toPx(), c, style = Stroke(2.dp.toPx()))
            drawCircle(Color.White, 8.dp.toPx(), c); drawCircle(Blue, 6.dp.toPx(), c)
        }

        // Rose des vents
        val nx = w - 26.dp.toPx(); val ny = 40.dp.toPx()
        drawPath(Path().apply { moveTo(nx, ny - 14.dp.toPx()); lineTo(nx - 7.dp.toPx(), ny + 6.dp.toPx()); lineTo(nx, ny + 2.dp.toPx()); lineTo(nx + 7.dp.toPx(), ny + 6.dp.toPx()); close() }, Color.White.copy(.85f))
        text("N", nx, ny - 18.dp.toPx(), Color.White.copy(.85f), sp, true)

        // Barre d'échelle
        val barW = (step * scale).toFloat(); val bx = 16.dp.toPx(); val by = h - 18.dp.toPx()
        drawLine(Color.White, Offset(bx, by), Offset(bx + barW, by), 3.dp.toPx())
        drawLine(Color.White, Offset(bx, by - 5.dp.toPx()), Offset(bx, by + 5.dp.toPx()), 2.dp.toPx())
        drawLine(Color.White, Offset(bx + barW, by - 5.dp.toPx()), Offset(bx + barW, by + 5.dp.toPx()), 2.dp.toPx())
        text(if (step >= 1000) "${(step / 1000).toInt()} km" else "${step.toInt()} m", bx + barW / 2, by - 10.dp.toPx(), Color.White, sp, align = Paint.Align.CENTER)
    }
}
