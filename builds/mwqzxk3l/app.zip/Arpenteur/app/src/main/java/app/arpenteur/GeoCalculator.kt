package app.arpenteur

import kotlin.math.*

data class GeoPoint(val lat: Double, val lon: Double, val acc: Float = 0f)

object GeoCalculator {
    private const val R = 6371008.8 // rayon terrestre moyen (m)

    /** Distance Haversine en mètres. */
    fun distance(a: GeoPoint, b: GeoPoint): Double {
        val dLat = Math.toRadians(b.lat - a.lat)
        val dLon = Math.toRadians(b.lon - a.lon)
        val h = sin(dLat / 2).pow(2) +
            cos(Math.toRadians(a.lat)) * cos(Math.toRadians(b.lat)) * sin(dLon / 2).pow(2)
        return 2 * R * asin(min(1.0, sqrt(h)))
    }

    /** Longueurs de chaque segment (+ segment de fermeture si [closed]). */
    fun segments(p: List<GeoPoint>, closed: Boolean): List<Double> {
        if (p.size < 2) return emptyList()
        val n = if (closed && p.size >= 3) p.size else p.size - 1
        return (0 until n).map { distance(p[it], p[(it + 1) % p.size]) }
    }

    fun perimeter(p: List<GeoPoint>, closed: Boolean = true) = segments(p, closed).sum()

    /** Projection plane locale (équirectangulaire autour de [o]) : x = Est, y = Nord, en mètres. */
    fun toLocal(p: List<GeoPoint>, o: GeoPoint): List<Pair<Double, Double>> {
        val k = cos(Math.toRadians(o.lat))
        return p.map {
            Math.toRadians(it.lon - o.lon) * R * k to Math.toRadians(it.lat - o.lat) * R
        }
    }

    /** Superficie en m² (formule du lacet / Gauss sur projection locale). */
    fun areaM2(p: List<GeoPoint>): Double {
        if (p.size < 3) return 0.0
        val o = GeoPoint(p.map { it.lat }.average(), p.map { it.lon }.average())
        val l = toLocal(p, o)
        var s = 0.0
        for (i in l.indices) {
            val (x1, y1) = l[i]; val (x2, y2) = l[(i + 1) % l.size]
            s += x1 * y2 - x2 * y1
        }
        return abs(s) / 2
    }

    fun selfIntersects(p: List<GeoPoint>): Boolean {
        if (p.size < 4) return false
        val l = toLocal(p, p[0])
        val n = l.size
        fun ccw(a: Pair<Double, Double>, b: Pair<Double, Double>, c: Pair<Double, Double>) =
            (c.second - a.second) * (b.first - a.first) > (b.second - a.second) * (c.first - a.first)
        fun cross(a: Int, b: Int, c: Int, d: Int) =
            ccw(l[a], l[c], l[d]) != ccw(l[b], l[c], l[d]) && ccw(l[a], l[b], l[c]) != ccw(l[a], l[b], l[d])
        for (i in 0 until n) for (j in i + 2 until n) {
            if (i == 0 && j == n - 1) continue
            if (cross(i, (i + 1) % n, j, (j + 1) % n)) return true
        }
        return false
    }

    fun ha(m2: Double) = m2 / 10_000.0
    fun acres(m2: Double) = m2 / 4046.8564224
}
