package app.arpenteur

import android.annotation.SuppressLint
import android.content.Context
import android.location.GnssStatus
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class Fix(val lat: Double, val lon: Double, val acc: Float, val time: Long = System.nanoTime()) {
    fun toPoint() = GeoPoint(lat, lon, acc)
}

/** GPS pur (aucun réseau, aucune clé API) via LocationManager + GnssStatus. */
class GpsTracker(context: Context) {
    private val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    private val _fix = MutableStateFlow<Fix?>(null)
    val fix: StateFlow<Fix?> = _fix
    private val _sats = MutableStateFlow(0 to 0) // utilisés / visibles
    val sats: StateFlow<Pair<Int, Int>> = _sats
    private val _enabled = MutableStateFlow(true)
    val enabled: StateFlow<Boolean> = _enabled
    private var running = false

    private val listener = object : LocationListener {
        override fun onLocationChanged(l: Location) {
            _fix.value = Fix(l.latitude, l.longitude, if (l.hasAccuracy()) l.accuracy else 99f)
        }
        override fun onProviderEnabled(p: String) { _enabled.value = true }
        override fun onProviderDisabled(p: String) { _enabled.value = false }
        @Deprecated("Deprecated") override fun onStatusChanged(p: String?, s: Int, e: Bundle?) {}
    }
    private val gnss = object : GnssStatus.Callback() {
        override fun onSatelliteStatusChanged(s: GnssStatus) {
            var used = 0
            for (i in 0 until s.satelliteCount) if (s.usedInFix(i)) used++
            _sats.value = used to s.satelliteCount
        }
    }

    @SuppressLint("MissingPermission")
    fun start() {
        if (running) return
        running = true
        _enabled.value = lm.isProviderEnabled(LocationManager.GPS_PROVIDER)
        lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, listener, Looper.getMainLooper())
        lm.registerGnssStatusCallback(gnss, Handler(Looper.getMainLooper()))
    }

    fun stop() {
        if (!running) return
        running = false
        lm.removeUpdates(listener)
        lm.unregisterGnssStatusCallback(gnss)
    }
}
