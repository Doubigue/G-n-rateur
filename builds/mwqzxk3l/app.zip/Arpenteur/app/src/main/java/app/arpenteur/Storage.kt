package app.arpenteur

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

data class SavedParcel(
    val id: Long, val name: String, val date: String,
    val points: List<GeoPoint>, val areaM2: Double, val perimeterM: Double
)

class ParcelStore(private val ctx: Context) {
    private val file get() = File(ctx.filesDir, "parcels.json")

    fun load(): List<SavedParcel> = try {
        val arr = JSONArray(if (file.exists()) file.readText() else "[]")
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val pts = o.getJSONArray("pts")
            SavedParcel(
                o.getLong("id"), o.getString("name"), o.getString("date"),
                (0 until pts.length()).map { pts.getJSONArray(it).let { p -> GeoPoint(p.getDouble(0), p.getDouble(1), p.optDouble(2, 0.0).toFloat()) } },
                o.getDouble("area"), o.getDouble("perim")
            )
        }
    } catch (e: Exception) { emptyList() }

    fun saveAll(list: List<SavedParcel>) {
        val arr = JSONArray()
        list.forEach { s ->
            arr.put(JSONObject().put("id", s.id).put("name", s.name).put("date", s.date)
                .put("area", s.areaM2).put("perim", s.perimeterM)
                .put("pts", JSONArray(s.points.map { JSONArray(listOf(it.lat, it.lon, it.acc.toDouble())) })))
        }
        file.writeText(arr.toString())
    }
}

object Exporter {
    fun now(): String = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE).format(Date())

    fun geoJson(name: String, p: List<GeoPoint>, area: Double, perim: Double): String {
        val ring = JSONArray((p + p.first()).map { JSONArray(listOf(it.lon, it.lat)) })
        val feature = JSONObject().put("type", "Feature")
            .put("properties", JSONObject().put("nom", name).put("surface_m2", area)
                .put("surface_ha", area / 10000).put("perimetre_m", perim))
            .put("geometry", JSONObject().put("type", "Polygon").put("coordinates", JSONArray().put(ring)))
        return JSONObject().put("type", "FeatureCollection").put("features", JSONArray().put(feature)).toString(2)
    }

    fun csv(name: String, p: List<GeoPoint>, area: Double, perim: Double): String = buildString {
        appendLine("parcelle,$name"); appendLine("surface_m2,%.2f".format(Locale.US, area))
        appendLine("surface_ha,%.4f".format(Locale.US, area / 10000)); appendLine("perimetre_m,%.2f".format(Locale.US, perim))
        appendLine("point,latitude,longitude,precision_m")
        p.forEachIndexed { i, q -> appendLine("${i + 1},%.7f,%.7f,%.1f".format(Locale.US, q.lat, q.lon, q.acc)) }
    }

    fun write(ctx: Context, fileName: String, mime: String, content: String): Uri? =
        writeBytes(ctx, fileName, mime, content.toByteArray())

    /** Écrit dans Téléchargements/Arpenteur (sans permission, Android 10+). */
    fun writeBytes(ctx: Context, fileName: String, mime: String, bytes: ByteArray): Uri? {
        val cv = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, fileName)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Arpenteur")
        }
        val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: return null
        ctx.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
        return uri
    }
}
