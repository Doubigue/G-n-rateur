package app.arpenteur

import org.osmdroid.tileprovider.tilesource.ITileSource
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.MapTileIndex

/** Sources de tuiles : clé MapTiler dédiée si fournie (local.properties), sinon Esri / OSM publics. */
object Tiles {
    private val key: String = BuildConfig.MAPTILER_KEY
    val hasKey: Boolean get() = key.isNotBlank()

    private fun z(t: Long) = MapTileIndex.getZoom(t)
    private fun x(t: Long) = MapTileIndex.getX(t)
    private fun y(t: Long) = MapTileIndex.getY(t)

    val sat: ITileSource = if (hasKey)
        object : OnlineTileSourceBase(
            "MapTilerSat", 0, 20, 256, ".jpg",
            arrayOf("https://api.maptiler.com/tiles/satellite-v2/"), "© MapTiler © OpenStreetMap contributors"
        ) {
            override fun getTileURLString(t: Long) = baseUrl + "${z(t)}/${x(t)}/${y(t)}.jpg?key=$key"
        }
    else EsriSat

    val plan: ITileSource = if (hasKey)
        object : OnlineTileSourceBase(
            "MapTilerStreets", 0, 20, 256, ".png",
            arrayOf("https://api.maptiler.com/maps/streets-v2/256/"), "© MapTiler © OpenStreetMap contributors"
        ) {
            override fun getTileURLString(t: Long) = baseUrl + "${z(t)}/${x(t)}/${y(t)}.png?key=$key"
        }
    else TileSourceFactory.MAPNIK
}
