package com.doubigue.ai.overlay

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.BlurMaskFilter
import android.graphics.Matrix
import android.graphics.SweepGradient
import android.os.SystemClock
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.room.Room
import com.doubigue.ai.MainActivity
import com.doubigue.ai.R
import com.doubigue.ai.apps.AppController
import com.doubigue.ai.events.EventSounds
import com.doubigue.ai.events.SoundEvent
import com.doubigue.ai.apps.InstalledApp
import com.doubigue.ai.data.AssistantDatabase
import com.doubigue.ai.ui.launchOrToggleApp
import com.doubigue.ai.voice.VoiceEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * Tiroir en arc au bord de l'écran (fenêtre superposée, même autorisation que la bulle).
 * Une fine poignée reste sur le bord ; la tirer vers l'intérieur ouvre l'arc.
 */
class EdgeDrawerService : Service() {
    private lateinit var wm: WindowManager
    private var handle: EdgeHandleView? = null
    private var panel: EdgeArcView? = null
    private var voice: VoiceEngine? = null
    private var db: AssistantDatabase? = null
    private var micTypeActive = false
    @Volatile private var cachedApps: List<InstalledApp>? = null
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val autoClose = Runnable { closePanel() }
    private val releaseVoice = Runnable { voice?.release(); voice = null }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        try { startFg(false) } catch (_: Exception) { stopSelf(); return }
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        addHandle()
        refreshApps()
    }

    private fun refreshApps() { Thread { try { cachedApps = EdgePrefs.resolveShortcuts(applicationContext) } catch (_: Throwable) {} }.start() }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { EdgePrefs.setEnabled(this, false); stopSelf(); return START_NOT_STICKY }
            ACTION_RELOAD -> { closePanelNow(); removeHandle(); addHandle(); refreshApps() }
        }
        return START_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (!::wm.isInitialized) return
        closePanelNow(); removeHandle(); addHandle()
    }

    // ---------- notification / premier plan ----------
    private fun createChannel() {
        val m = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        m.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Tiroir en arc", NotificationManager.IMPORTANCE_LOW))
    }

    private fun notification(): Notification {
        val stop = PendingIntent.getService(this, 3, Intent(this, EdgeDrawerService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val open = PendingIntent.getActivity(this, 4, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_doubigue)
            .setContentTitle("Tiroir DOUBIGUE actif")
            .setContentText("Tire depuis le bord de l'écran pour l'ouvrir")
            .setContentIntent(open).setOngoing(true)
            .addAction(0, "Désactiver", stop).build()
    }

    /** Le type « microphone » n'est activé que pendant l'écoute (indicateur micro Android visible). */
    private fun startFg(mic: Boolean) {
        val n = notification()
        when {
            Build.VERSION.SDK_INT >= 34 -> {
                var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                if (mic) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                startForeground(NOTIF_ID, n, type)
            }
            Build.VERSION.SDK_INT >= 29 ->
                startForeground(NOTIF_ID, n, if (mic) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0)
            else -> startForeground(NOTIF_ID, n)
        }
    }

    private fun setMicType(on: Boolean): Boolean {
        if (micTypeActive == on) return true
        return try { startFg(on); micTypeActive = on; true } catch (_: Throwable) { false }
    }

    // ---------- poignée ----------
    private fun addHandle() {
        val left = EdgePrefs.side(this) == "left"
        val v = EdgeHandleView(this, left) { openPanel() }
        val lp = WindowManager.LayoutParams(
            (44 * resources.displayMetrics.density).toInt(), (200 * resources.displayMetrics.density).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = (if (left) Gravity.START else Gravity.END) or Gravity.CENTER_VERTICAL }
        try { wm.addView(v, lp); handle = v } catch (_: Exception) { stopSelf() }
    }

    private fun removeHandle() {
        handle?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        handle = null
    }

    // ---------- panneau en arc ----------
    private fun openPanel() {
        if (panel != null) return
        val apps = cachedApps ?: EdgePrefs.resolveShortcuts(this)
        val left = EdgePrefs.side(this) == "left"
        val view = EdgeArcView(this, apps, left,
            onLaunch = { launchApp(it) }, onMic = { startMic() }, onAssistant = { openAssistant(false) },
            onClose = { closePanel() }, onInteraction = { if (panel?.listening != true) scheduleAutoClose(9000) })
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        try { wm.addView(view, lp) } catch (_: Exception) { return }
        panel = view
        main.removeCallbacks(releaseVoice)
        view.animateIn()
        view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        handle?.visibility = View.GONE
        scheduleAutoClose(9000)
    }

    private fun scheduleAutoClose(ms: Long) { main.removeCallbacks(autoClose); main.postDelayed(autoClose, ms) }

    private fun closePanel() {
        main.removeCallbacks(autoClose)
        val p = panel ?: return
        panel = null
        voice?.stopListening()
        setMicType(false)
        p.animateOut { try { wm.removeView(p) } catch (_: Exception) {} }
        handle?.visibility = View.VISIBLE
        main.postDelayed(releaseVoice, 45_000)
        refreshApps()
    }

    private fun closePanelNow() {
        main.removeCallbacks(autoClose)
        val p = panel ?: return
        panel = null
        voice?.stopListening(); setMicType(false)
        try { wm.removeView(p) } catch (_: Exception) {}
        handle?.visibility = View.VISIBLE
    }

    /** Toucher une icône = même logique que la voix : ouvre (son d'ouverture) ou ferme si déjà ouverte (son de fermeture). */
    private fun launchApp(app: InstalledApp) {
        scope.launch {
            val cfg = try { database().appVoiceConfigDao().get(app.packageName) } catch (_: Throwable) { null }
            launchOrToggleApp(applicationContext, AppController(applicationContext), ensureVoice(), app, cfg) { }
            closePanel()
        }
    }

    private fun openAssistant(autoListen: Boolean) {
        val i = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            .putExtra(MainActivity.EXTRA_AUTO_LISTEN, autoListen)
        try { startActivity(i) } catch (_: Exception) {}
        closePanel()
    }

    // ---------- micro direct ----------
    private fun database(): AssistantDatabase = db ?: Room.databaseBuilder(applicationContext, AssistantDatabase::class.java, "doubigue.db")
        .addMigrations(com.doubigue.ai.data.MIGRATION_1_2, com.doubigue.ai.data.MIGRATION_2_3, com.doubigue.ai.data.MIGRATION_3_4, com.doubigue.ai.data.MIGRATION_4_5)
        .build().also { db = it }

    private fun ensureVoice(): VoiceEngine = voice ?: VoiceEngine(applicationContext, { onHeard(it) }, { onVoiceState(it) }).also { voice = it }

    private fun startMic() {
        main.removeCallbacks(autoClose); main.removeCallbacks(releaseVoice)
        val p = panel ?: return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            p.status = "Autorisation micro requise : ouverture de l'assistant…"
            main.postDelayed({ openAssistant(true) }, 700)
            return
        }
        // « Je vous écoute » (son importé dans Paramètres) AVANT d'écouter, pour que le micro ne capte pas le son.
        p.status = ""
        EventSounds.playThen(this, SoundEvent.LISTEN_PROMPT) { main.post { beginListening() } }
    }

    private fun beginListening() {
        val p = panel ?: return
        if (!setMicType(true)) { openAssistant(true); return }   // Android refuse le micro ici : repli sur l'assistant
        p.listening = true
        ensureVoice().listen()
    }

    private fun onVoiceState(s: String) {
        val p = panel
        if (s.startsWith("Prêt")) { p?.listening = false; setMicType(false); return }
        val active = s.startsWith("Écoute") || s.startsWith("Je t'écoute") || s.startsWith("Chargement")
        p?.listening = active
        p?.status = if (active) "" else s
        if (!active) { setMicType(false); scheduleAutoClose(5000) }
    }

    private fun onHeard(text: String) {
        panel?.status = "« $text »"
        val v = voice ?: return
        val d = database()
        com.doubigue.ai.ui.runCommand(applicationContext, text, AppController(applicationContext), com.doubigue.ai.system.PhoneTools(applicationContext), v,
            d.appVoiceConfigDao(), d.learnedCommandDao(), scope) { msg -> main.post { panel?.status = msg } }
        scheduleAutoClose(3500)
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        closePanelNow()
        removeHandle()
        voice?.release(); voice = null
        try { db?.close() } catch (_: Exception) {}
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.doubigue.ai.overlay.EDGE_STOP"
        const val ACTION_RELOAD = "com.doubigue.ai.overlay.EDGE_RELOAD"
        private const val CHANNEL_ID = "doubigue_edge"
        private const val NOTIF_ID = 43

        fun start(c: Context) {
            EdgePrefs.setEnabled(c, true)
            ContextCompat.startForegroundService(c, Intent(c, EdgeDrawerService::class.java))
        }
        fun stop(c: Context) {
            EdgePrefs.setEnabled(c, false)
            c.stopService(Intent(c, EdgeDrawerService::class.java))
        }
        fun reload(c: Context) {
            if (EdgePrefs.isEnabled(c)) c.startService(Intent(c, EdgeDrawerService::class.java).setAction(ACTION_RELOAD))
        }
    }
}

/**
 * Poignée du tiroir : un petit « dôme de verre » qui dépasse du bord, avec un liseré coloré qui tourne doucement
 * (même palette que la sphère du micro) et une étincelle au centre.
 */
class EdgeHandleView(context: Context, private val leftSide: Boolean, private val onSwipe: () -> Unit) : View(context) {
    private val d = resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val halo = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val spark = Paint(Paint.ANTI_ALIAS_FLAG)
    private val colors = intArrayOf(0xFF40E0FF.toInt(), 0xFF4F6BFF.toInt(), 0xFFB45CFF.toInt(), 0xFFFF5CAA.toInt(), 0xFFFFB04A.toInt(), 0xFF40E0FF.toInt())
    private val tick = object : Runnable { override fun run() { invalidate(); postDelayed(this, 80) } }
    private var downX = 0f
    private var downY = 0f
    private var fired = false

    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }   // nécessaire pour le halo (flou)

    override fun onAttachedToWindow() { super.onAttachedToWindow(); removeCallbacks(tick); post(tick) }
    override fun onDetachedFromWindow() { removeCallbacks(tick); super.onDetachedFromWindow() }
    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        removeCallbacks(tick)
        if (visibility == VISIBLE && isAttachedToWindow) post(tick)     // pas d'animation quand le tiroir est ouvert
    }

    override fun onDraw(c: Canvas) {
        val ex = if (leftSide) 0f else width.toFloat()
        val cy = height / 2f
        val rw = 17 * d; val rh = 36 * d
        val oval = RectF(ex - rw, cy - rh, ex + rw, cy + rh)      // seule la moitié côté écran est visible
        fill.shader = RadialGradient(ex, cy, rh, intArrayOf(0xE62A3F9E.toInt(), 0xE60B1334.toInt()), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)
        c.drawOval(oval, fill)
        val angle = (SystemClock.uptimeMillis() % 8000L) / 8000f * 360f
        val sweep = SweepGradient(ex, cy, colors, null)
        sweep.setLocalMatrix(Matrix().apply { setRotate(angle, ex, cy) })
        halo.shader = sweep; halo.strokeWidth = 5 * d; halo.alpha = 110; halo.maskFilter = BlurMaskFilter(5 * d, BlurMaskFilter.Blur.NORMAL)
        c.drawOval(oval, halo)
        rim.shader = sweep; rim.strokeWidth = 2.2f * d
        c.drawOval(oval, rim)
        val sx = if (leftSide) 7 * d else width - 7 * d; val s = 5 * d
        spark.color = Color.argb(235, 220, 245, 255)
        c.drawPath(Path().apply {
            moveTo(sx, cy - s); quadTo(sx + s * .15f, cy - s * .15f, sx + s, cy)
            quadTo(sx + s * .15f, cy + s * .15f, sx, cy + s); quadTo(sx - s * .15f, cy + s * .15f, sx - s, cy)
            quadTo(sx - s * .15f, cy - s * .15f, sx, cy - s); close()
        }, spark)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        super.onLayout(changed, l, t, r, b)
        if (Build.VERSION.SDK_INT >= 29) systemGestureExclusionRects = listOf(Rect(0, 0, r - l, b - t))
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; fired = false }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - downX; val dy = e.rawY - downY
                val inward = if (leftSide) dx else -dx
                if (!fired && inward > 36 * d && inward > abs(dy)) { fired = true; onSwipe() }
            }
        }
        return true
    }
}
