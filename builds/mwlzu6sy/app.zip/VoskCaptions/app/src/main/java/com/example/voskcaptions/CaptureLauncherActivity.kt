package com.example.voskcaptions

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.voskcaptions.managers.ModelState
import com.example.voskcaptions.services.AudioCaptureService
import com.example.voskcaptions.services.SubtitleOverlayService

/**
 * Activité transparente : Android impose une confirmation « Partager l'écran » à chaque
 * nouvelle projection (Android 14+ : usage unique). On la demande une seule fois, puis le service garde la projection.
 */
class CaptureLauncherActivity : AppCompatActivity() {

    private val launcher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == RESULT_OK && data != null) {
            SubtitleOverlayService.start(this)
            val begin = intent.getBooleanExtra(EXTRA_BEGIN, true)
            ContextCompat.startForegroundService(this, AudioCaptureService.armIntent(this, r.resultCode, data, begin))
        } else {
            toast("Capture refusée")
        }
        finish()
    }

    companion object {
        /** false = seulement activer la capture permanente, sans démarrer le sous-titrage. */
        const val EXTRA_BEGIN = "begin"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        when {
            AudioCaptureService.armed.value -> {            // déjà autorisée : aucune boîte de dialogue
                if (intent.getBooleanExtra(EXTRA_BEGIN, true)) {
                    SubtitleOverlayService.start(this)
                    startService(AudioCaptureService.beginIntent(this))
                }
                finish()
            }
            voskApp.modelManager.state.value is ModelState.Loading -> {
                toast("Modèle en cours de chargement, réessayez dans un instant"); finish()
            }
            voskApp.modelManager.state.value !is ModelState.Ready -> openMain("Chargez d'abord un modèle Vosk")
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED ->
                openMain("Autorisez d'abord le micro dans l'application")
            !Settings.canDrawOverlays(this) -> openMain("Autorisez d'abord l'affichage par-dessus")
            else -> {
                launcher.launch(CaptureShortcuts.captureIntent(this))
            }
        }
    }

    private fun openMain(msg: String) {
        toast(msg)
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
