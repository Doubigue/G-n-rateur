package com.example.voskcaptions.services

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.voskcaptions.MainActivity
import com.example.voskcaptions.VoskApp
import com.example.voskcaptions.audio.PcmResampler
import com.example.voskcaptions.audio.ScreenColorSampler
import com.example.voskcaptions.data.OverlayGeometry
import com.example.voskcaptions.data.SubtitleSource
import com.example.voskcaptions.ui.ColorMode
import com.example.voskcaptions.ui.SceneColorBus
import kotlinx.coroutines.delay
import com.example.voskcaptions.data.SubtitleBus
import com.example.voskcaptions.data.SubtitleState
import com.example.voskcaptions.managers.LanguageModelMissingException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import org.vosk.Recognizer
import kotlin.coroutines.coroutineContext
import kotlin.math.max

/**
 * Capture l'audio interne (MediaProjection + AudioPlaybackCapture), le convertit en
 * 16 kHz / mono / PCM16 et le passe à Vosk. Publie sous-titres + traduction sur [SubtitleBus].
 */
class AudioCaptureService : Service() {

    companion object {
        const val ACTION_STOP = "com.example.voskcaptions.action.STOP_CAPTURE"          // désactive tout (libère la projection)
        const val ACTION_ARM = "com.example.voskcaptions.action.ARM_CAPTURE"            // obtient la projection, sans démarrer
        const val ACTION_BEGIN = "com.example.voskcaptions.action.BEGIN_TRANSCRIPTION"  // démarre le sous-titrage (projection déjà prête)
        const val ACTION_PAUSE = "com.example.voskcaptions.action.PAUSE_TRANSCRIPTION"  // arrête le sous-titrage, garde la projection
        private const val EXTRA_RESULT_CODE = "result_code"
        private const val EXTRA_RESULT_DATA = "result_data"
        private const val EXTRA_BEGIN = "begin"
        private const val CHANNEL_ID = "audio_capture"
        private const val NOTIFICATION_ID = 1001
        private const val TARGET_RATE = 16_000

        /** Sous-titrage en cours. */
        private val _running = MutableStateFlow(false)
        val running: StateFlow<Boolean> = _running.asStateFlow()

        /** Autorisation de capture accordée et conservée : le sous-titrage démarre sans nouvelle boîte de dialogue. */
        private val _armed = MutableStateFlow(false)
        val armed: StateFlow<Boolean> = _armed.asStateFlow()

        /** [begin] = démarrer aussi le sous-titrage tout de suite (première utilisation). */
        fun armIntent(ctx: Context, resultCode: Int, data: Intent, begin: Boolean): Intent =
            Intent(ctx, AudioCaptureService::class.java)
                .setAction(ACTION_ARM)
                .putExtra(EXTRA_RESULT_CODE, resultCode)
                .putExtra(EXTRA_RESULT_DATA, data)
                .putExtra(EXTRA_BEGIN, begin)

        fun beginIntent(ctx: Context): Intent =
            Intent(ctx, AudioCaptureService::class.java).setAction(ACTION_BEGIN)

        fun pauseIntent(ctx: Context): Intent =
            Intent(ctx, AudioCaptureService::class.java).setAction(ACTION_PAUSE)

        fun stopIntent(ctx: Context): Intent =
            Intent(ctx, AudioCaptureService::class.java).setAction(ACTION_STOP)
    }

    private val app: VoskApp get() = applicationContext as VoskApp
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mainHandler = Handler(Looper.getMainLooper())

    private var captureJob: Job? = null
    private var partialJob: Job? = null
    private var colorJob: Job? = null
    private var projection: MediaProjection? = null
    private var sampler: ScreenColorSampler? = null      // un seul VirtualDisplay par projection (Android 14+)

    private var lastPartial = ""

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopSelf()
            ACTION_ARM -> {
                // Android 14 : startForeground(type=mediaProjection) AVANT getMediaProjection()
                startForeground(
                    NOTIFICATION_ID, buildNotification(),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                )
                if (projection == null) {
                    val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                    val data = readResultData(intent)
                    if (data == null || resultCode != Activity.RESULT_OK || !arm(resultCode, data)) {
                        stopSelf(); return START_NOT_STICKY
                    }
                }
                if (intent.getBooleanExtra(EXTRA_BEGIN, false)) beginTranscription()
            }
            ACTION_BEGIN -> {
                if (projection == null) { toast("Capture non activée : activez-la d'abord"); stopSelf() }
                else beginTranscription()
            }
            ACTION_PAUSE -> pauseTranscription()
            else -> if (projection == null) stopSelf()
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun readResultData(intent: Intent): Intent? =
        if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        else intent.getParcelableExtra(EXTRA_RESULT_DATA)

    /** Obtient la projection UNE fois et la garde jusqu'à la désactivation (ou révocation par Android). */
    private fun arm(resultCode: Int, data: Intent): Boolean {
        val proj = try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mpm.getMediaProjection(resultCode, data).also { p ->
                p.registerCallback(object : MediaProjection.Callback() {
                    override fun onStop() {
                        // Android a révoqué la projection (verrouillage, autre partage d'écran…)
                        if (projection != null) {
                            toast("Capture révoquée par Android : réactivez-la dans l'appli")
                            projection = null
                            stopSelf()
                        }
                    }
                }, mainHandler)
            }
        } catch (e: Exception) {
            toast("Projection média refusée : ${e.message}"); return false
        }
        projection = proj
        _armed.value = true
        colorJob = scope.launch { runColorSampling(proj) }
        updateNotification()
        return true
    }

    private fun beginTranscription() {
        val proj = projection ?: return
        if (captureJob?.isActive == true) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toast("Permission micro (RECORD_AUDIO) manquante"); return
        }
        val recognizer: Recognizer? = try { app.modelManager.createRecognizer() } catch (e: Exception) { null }
        if (recognizer == null) {
            toast("Aucun modèle Vosk chargé"); return
        }
        scope.launch {
            val st = app.settings.state.value
            app.translationManager.prepare(st.sourceLang, st.targetLang)   // charge les modèles de traduction à l'avance
        }
        captureJob = scope.launch { runPipeline(proj, recognizer) }.also {
            it.invokeOnCompletion { mainHandler.post { updateNotification() } }
        }
        updateNotification()
    }

    /** Arrête seulement le sous-titrage : la projection reste active, pas de nouvelle demande au prochain démarrage. */
    private fun pauseTranscription() {
        captureJob?.cancel()
        partialJob?.cancel()
        updateNotification()
    }

    // ------------------------------------------------------------------ pipeline audio → Vosk

    @SuppressLint("MissingPermission")
    private fun buildRecord(proj: MediaProjection): Pair<AudioRecord, Int>? {
        val config = AudioPlaybackCaptureConfiguration.Builder(proj)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()
        for (rate in intArrayOf(48_000, 44_100, 16_000)) {
            val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
            if (min <= 0) continue
            try {
                val format = AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(rate)
                    .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                    .build()
                val record = AudioRecord.Builder()
                    .setAudioFormat(format)
                    .setBufferSizeInBytes(max(min * 4, rate * 4 / 2))   // ~0,5 s
                    .setAudioPlaybackCaptureConfig(config)
                    .build()
                if (record.state == AudioRecord.STATE_INITIALIZED) return record to rate
                record.release()
            } catch (_: Exception) { /* essaie la fréquence suivante */ }
        }
        return null
    }

    private suspend fun runPipeline(proj: MediaProjection, recognizer: Recognizer) {
        var record: AudioRecord? = null
        try {
            val built = buildRecord(proj)
            if (built == null) {
                toast("Capture audio interne impossible sur cet appareil"); return
            }
            val (rec, inRate) = built
            record = rec
            val resampler = PcmResampler(inRate, TARGET_RATE, channels = 2)
            val chunk = ShortArray(inRate / 10 * 2)                              // 100 ms stéréo
            val out = ShortArray(chunk.size / 2 * TARGET_RATE / inRate + 16)     // 100 ms mono 16 kHz

            rec.startRecording()
            _running.value = true

            while (coroutineContext.isActive) {
                val n = rec.read(chunk, 0, chunk.size)           // bloquant (~100 ms)
                if (n < 0) { toast("Erreur de lecture audio ($n)"); break }
                if (n == 0) continue
                val outN = resampler.process(chunk, n, out)
                if (outN == 0) continue
                if (recognizer.acceptWaveForm(out, outN)) {
                    onFinal(JSONObject(recognizer.result).optString("text"))
                } else {
                    onPartial(JSONObject(recognizer.partialResult).optString("partial"))
                }
            }
        } finally {
            withContext(NonCancellable) {
                record?.let { runCatching { it.stop() }; runCatching { it.release() } }
                runCatching { flushPending(recognizer) }
                runCatching { recognizer.close() }        // libération mémoire native
                _running.value = false
                // Le dernier texte reste affiché dans la fenêtre flottante (à vider manuellement).
            }
        }
    }

    // ------------------------------------------------------------------ résultats + traduction

    /** Le bus gère l'ordre (partiels dépassés, traductions tardives) : on lui donne juste l'id du segment. */
    private fun publish(seq: Long, state: SubtitleState) = SubtitleBus.publish(state.copy(id = seq))

    private fun onPartial(text: String) {
        if (text.isBlank() || text == lastPartial) return
        lastPartial = text
        val seq = SubtitleBus.nextId()
        publish(seq, SubtitleState(original = text, partial = true))
        partialJob?.cancel()
        partialJob = scope.launch {
            delay(700)                           // on ne traduit un partiel que s'il reste stable un instant
            val tr = safeTranslate(text)
            if (tr.isNotBlank()) publish(seq, SubtitleState(original = text, translated = tr, partial = true))
        }
    }

    private fun onFinal(text: String) {
        lastPartial = ""
        partialJob?.cancel()
        if (text.isBlank()) return
        val seq = SubtitleBus.nextId()
        publish(seq, SubtitleState(original = text, partial = false))
        scope.launch {
            val s = app.settings.state.value
            val id = app.history.insert("speech", "", text, "", s.sourceLang, s.targetLang)
            val tr = safeTranslate(text)
            if (tr.isNotBlank()) publish(seq, SubtitleState(original = text, translated = tr, partial = false))
            if (tr.isNotBlank() && !tr.startsWith("⚠")) app.history.updateTranslation(id, tr)
        }
    }

    /** À l'arrêt : la phrase encore en cours n'est pas perdue, elle est ajoutée à la transcription et à l'historique. */
    private suspend fun flushPending(recognizer: Recognizer) {
        val last = runCatching { JSONObject(recognizer.finalResult).optString("text") }.getOrDefault("")
        if (last.isBlank()) return
        val seq = SubtitleBus.nextId()
        val s = app.settings.state.value
        publish(seq, SubtitleState(original = last, partial = false))
        val id = runCatching { app.history.insert("speech", "", last, "", s.sourceLang, s.targetLang) }.getOrDefault(-1L)
        val tr = withTimeoutOrNull(10_000) { safeTranslate(last) }.orEmpty()
        if (tr.isNotBlank()) {
            publish(seq, SubtitleState(original = last, translated = tr, partial = false))
            if (!tr.startsWith("⚠")) runCatching { app.history.updateTranslation(id, tr) }
        }
    }

    private suspend fun safeTranslate(text: String): String {
        val s = app.settings.state.value
        if (s.sourceLang == s.targetLang) return ""
        return try {
            app.translationManager.translate(text, s.sourceLang, s.targetLang)
        } catch (e: LanguageModelMissingException) {
            "⚠ Pack de langue manquant : ${app.translationManager.displayName(e.lang)}"
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            ""
        }
    }

    // ------------------------------------------------------------------ couleurs adaptatives

    /** En mode « Auto », mesure la couleur de l'écran près de la fenêtre flottante (VirtualDisplay 1/8).
     *  Le VirtualDisplay n'est créé qu'une fois par projection (Android 14+) et gardé jusqu'à la fin. */
    private suspend fun runColorSampling(proj: MediaProjection) {
        try {
            while (coroutineContext.isActive) {
                delay(600)
                if (app.settings.state.value.colorMode != ColorMode.AUTO.key) continue
                val band = OverlayGeometry.sampleBand.value ?: continue
                val s = sampler ?: ScreenColorSampler(applicationContext, proj, mainHandler)
                    .also { it.start(); sampler = it }
                s.sample(band)?.let { SceneColorBus.avgColor.value = it }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // Échec de la capture d'écran : on garde les couleurs par défaut
        }
    }

    // ------------------------------------------------------------------ divers

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Sous-titrage en direct", NotificationManager.IMPORTANCE_LOW)
        )
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val offPi = PendingIntent.getService(this, 0, stopIntent(this), flags)
        val openPi = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), flags)
        val live = captureJob?.isActive == true
        val b = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle(if (live) "Sous-titrage en direct actif" else "Capture prête")
            .setContentText(if (live) "Capture de l'audio interne en cours" else "Le sous-titrage démarre sans nouvelle autorisation")
            .setOngoing(true)
            .setContentIntent(openPi)
        if (live) b.addAction(0, "Pause", PendingIntent.getService(this, 2, pauseIntent(this), flags))
        else b.addAction(0, "Démarrer", PendingIntent.getService(this, 3, beginIntent(this), flags))
        b.addAction(0, "Désactiver", offPi)
        return b.build()
    }

    private fun updateNotification() {
        if (projection == null) return
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification())
    }

    private fun toast(msg: String) = mainHandler.post {
        Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        val p = projection
        projection = null                       // évite que onStop() relance stopSelf()
        scope.cancel()                          // le bloc finally du pipeline ferme AudioRecord et Recognizer
        runCatching { sampler?.release() }; sampler = null
        runCatching { p?.stop() }
        _armed.value = false
        if (captureJob == null) _running.value = false
        super.onDestroy()
    }
}
