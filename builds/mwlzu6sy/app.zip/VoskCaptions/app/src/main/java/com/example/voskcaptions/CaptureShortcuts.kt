package com.example.voskcaptions

import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.os.Build
import com.example.voskcaptions.services.AudioCaptureService

/** Action unique « démarrer / arrêter » utilisée par la bulle flottante et le bouton d'accessibilité. */
object CaptureShortcuts {
    /**
     * Demande de capture : sur Android 14+, seule l'option « Tout l'écran » est proposée
     * (pas de choix d'appli). Android impose toujours la confirmation, elle ne peut pas être supprimée.
     */
    fun captureIntent(context: Context): Intent {
        val mpm = context.getSystemService(MediaProjectionManager::class.java)
        return if (Build.VERSION.SDK_INT >= 34) mpm.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
        else mpm.createScreenCaptureIntent()
    }

    /**
     * Bulle / bouton d'accessibilité :
     *  - sous-titrage en cours → pause (la capture reste autorisée) ;
     *  - capture déjà autorisée → démarre immédiatement, SANS boîte de dialogue ;
     *  - sinon → demande l'autorisation (une seule fois), puis démarre.
     */
    fun toggle(context: Context) {
        val app = context.applicationContext
        when {
            AudioCaptureService.running.value -> app.startService(AudioCaptureService.pauseIntent(app))
            AudioCaptureService.armed.value -> app.startService(AudioCaptureService.beginIntent(app))
            else -> app.startActivity(
                Intent(app, CaptureLauncherActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
            )
        }
    }

    /** Désactive la capture permanente (libère l'autorisation). */
    fun disarm(context: Context) {
        val app = context.applicationContext
        app.stopService(Intent(app, AudioCaptureService::class.java))
    }
}
