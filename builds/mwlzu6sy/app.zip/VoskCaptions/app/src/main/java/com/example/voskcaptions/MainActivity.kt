package com.example.voskcaptions

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.format.Formatter
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.example.voskcaptions.data.AppSettings
import com.example.voskcaptions.databinding.ActivityMainBinding
import com.example.voskcaptions.managers.ModelInfo
import com.example.voskcaptions.managers.ModelState
import com.example.voskcaptions.services.AudioCaptureService
import com.example.voskcaptions.services.FloatingShortcutService
import com.example.voskcaptions.services.SubtitleOverlayService
import com.example.voskcaptions.ui.ColorMode
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private val vm: MainViewModel by viewModels()

    private var installed: List<ModelInfo> = emptyList()
    private var langTags: List<String> = emptyList()
    private var pairTags: List<String> = emptyList()
    private var downloaded: Set<String> = emptySet()
    private var modelBusy = false

    // ------------------------------------------------------------ Activity Result API

    private val pickZips = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris: List<Uri> ->
        vm.importModels(uris)
    }

    private val pickFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        uri?.let { vm.importFolder(it) }
    }

    private val requestRuntime = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        refreshPermissions()
    }

    /** true = la demande vient du bouton « Activer la capture » : on n'enchaîne pas avec le démarrage. */
    private var armOnly = false

    private val projectionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == RESULT_OK && data != null) {
            SubtitleOverlayService.start(this)
            ContextCompat.startForegroundService(this, AudioCaptureService.armIntent(this, r.resultCode, data, begin = !armOnly))
            if (armOnly) toast("Capture activée : démarrez le sous-titrage quand vous voulez, sans nouvelle demande")
        } else {
            toast("Capture de l'audio refusée")
        }
    }

    // ------------------------------------------------------------ cycle de vie

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        langTags = voskApp.translationManager.allLanguages()
        pairTags = voskApp.translationManager.allPairs()
        val names = langTags.map { voskApp.translationManager.displayName(it) }
        b.spSource.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        b.spTarget.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        renderPacks()
        b.spColorMode.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, ColorMode.entries.map { it.label }
        )

        setupListeners()
        observe()
    }

    override fun onResume() {
        super.onResume()
        refreshPermissions()
        vm.refreshStorage()
    }

    // ------------------------------------------------------------ listeners

    private fun setupListeners() {
        b.btnImport.setOnClickListener {
            pickZips.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))
        }
        b.btnImportFolder.setOnClickListener { pickFolder.launch(null) }
        b.btnLoad.setOnClickListener {
            installed.getOrNull(b.spInstalled.selectedItemPosition)?.let { vm.loadModel(it.name) }
        }
        b.btnDeleteModel.setOnClickListener {
            val m = installed.getOrNull(b.spInstalled.selectedItemPosition) ?: return@setOnClickListener
            MaterialAlertDialogBuilder(this)
                .setTitle("Supprimer le modèle ?")
                .setMessage(m.name)
                .setPositiveButton("Supprimer") { _, _ -> vm.deleteModel(m.name) }
                .setNegativeButton("Annuler", null)
                .show()
        }

        b.spSource.onItemSelectedListener = onSelected { pos ->
            val tag = langTags[pos]
            if (tag != vm.settings.value.sourceLang) vm.setSourceLang(tag)
        }
        b.spTarget.onItemSelectedListener = onSelected { pos ->
            val tag = langTags[pos]
            if (tag != vm.settings.value.targetLang) vm.setTargetLang(tag)
        }
        b.btnDownloadPair.setOnClickListener { vm.downloadForCurrent() }
        b.btnDownloadPack.setOnClickListener {
            pairTags.getOrNull(b.spPack.selectedItemPosition)?.let { vm.downloadPairs(listOf(it)) }
        }
        b.btnDeletePack.setOnClickListener {
            val pair = pairTags.getOrNull(b.spPack.selectedItemPosition) ?: return@setOnClickListener
            if (pair !in downloaded) { toast("Cette paire n'est pas installée"); return@setOnClickListener }
            MaterialAlertDialogBuilder(this)
                .setTitle("Supprimer ${voskApp.translationManager.displayName(pair)} ?")
                .setNegativeButton("Annuler", null)
                .setPositiveButton("Supprimer") { _, _ -> vm.deletePair(pair) }
                .show()
        }

        b.seekTextSize.setOnSeekBarChangeListener(onSeek { p -> vm.setTextSize(p + 12) })
        b.seekOpacity.setOnSeekBarChangeListener(onSeek { p -> vm.setOpacity(p) })
        b.swOriginal.setOnCheckedChangeListener { _, v -> vm.setShowOriginal(v) }
        b.swNotif.setOnCheckedChangeListener { _, v -> vm.setTranslateNotifications(v) }

        b.btnOverlay.setOnClickListener {
            when {
                SubtitleOverlayService.running.value -> SubtitleOverlayService.stop(this)
                !Settings.canDrawOverlays(this) -> requestOverlayPermission()
                else -> SubtitleOverlayService.start(this)
            }
        }

        b.btnPermAudio.setOnClickListener { requestRuntimePermissions() }
        b.btnPermOverlay.setOnClickListener { requestOverlayPermission() }
        b.btnPermNotif.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        b.spColorMode.onItemSelectedListener = onSelected { pos ->
            val key = ColorMode.entries[pos].key
            if (key != vm.settings.value.colorMode) vm.setColorMode(key)
        }
        b.swAutoClear.setOnCheckedChangeListener { _, v -> vm.setAutoClear(v) }
        b.swShortcut.setOnCheckedChangeListener { _, v ->
            if (v && !Settings.canDrawOverlays(this)) requestOverlayPermission()
            vm.setShortcutEnabled(v)
        }
        b.btnHistory.setOnClickListener { startActivity(Intent(this, HistoryActivity::class.java)) }
        b.btnPermStorage.setOnClickListener { requestStoragePermission() }
        b.btnPermAccess.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }

        b.btnStartStop.setOnClickListener { onStartStop() }
        b.btnArm.setOnClickListener { onArmToggle() }
    }

    private fun onSelected(block: (Int) -> Unit) = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(p: AdapterView<*>?, v: View?, position: Int, id: Long) = block(position)
        override fun onNothingSelected(p: AdapterView<*>?) {}
    }

    private fun onSeek(block: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) { if (fromUser) block(progress) }
        override fun onStartTrackingTouch(s: SeekBar?) {}
        override fun onStopTrackingTouch(s: SeekBar?) {}
    }

    // ------------------------------------------------------------ observation des états

    private fun observe() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { vm.modelState.collect { renderModelState(it) } }
                launch {
                    vm.installedModels.collect {
                        installed = it
                        renderInstalledSpinner()
                    }
                }
                launch { vm.settings.collect { renderSettings(it) } }
                launch {
                    vm.downloadedLangs.collect {
                        downloaded = it
                        renderPacks()
                    }
                }
                launch {
                    vm.langBusy.collect { lang ->
                        b.progressPack.visibility = if (lang != null) View.VISIBLE else View.GONE
                        b.btnDownloadPair.isEnabled = lang == null
                        b.btnDownloadPack.isEnabled = lang == null
                        b.btnDeletePack.isEnabled = lang == null
                        if (lang == null) renderPacks()
                    }
                }
                launch {
                    vm.packProgress.collect { p ->
                        if (p == null) return@collect
                        b.progressPack.setProgressCompat(p.percent.coerceAtLeast(0), false)
                        b.tvPacks.text = p.message
                    }
                }
                launch { vm.messages.collect { toast(it) } }
                launch { AudioCaptureService.running.collect { renderRunning() } }
                launch { AudioCaptureService.armed.collect { renderRunning() } }
                launch { SubtitleOverlayService.running.collect { renderRunning() } }
            }
        }
    }

    private fun renderModelState(state: ModelState) {
        val busy = state is ModelState.Extracting || state is ModelState.Loading
        modelBusy = busy
        when (state) {
            is ModelState.Idle -> b.tvModelStatus.text = "Aucun modèle chargé"
            is ModelState.Extracting -> {
                b.tvModelStatus.text = if (state.percent >= 0)
                    "Extraction de ${state.message}… ${state.percent} %" else "Extraction de ${state.message}…"
                if (state.percent >= 0) {
                    b.progressModel.isIndeterminate = false
                    b.progressModel.setProgressCompat(state.percent, true)
                } else {
                    b.progressModel.isIndeterminate = true
                }
            }
            is ModelState.Loading -> {
                b.tvModelStatus.text = "Chargement de ${state.name} en mémoire…"
                b.progressModel.isIndeterminate = true
            }
            is ModelState.Ready -> b.tvModelStatus.text =
                "✔ ${state.info.name}\nLangue : ${state.info.languageName} • Taille : " +
                    Formatter.formatFileSize(this, state.info.sizeBytes)
            is ModelState.Error -> b.tvModelStatus.text = "✘ ${state.message}"
        }
        b.progressModel.visibility = if (busy) View.VISIBLE else View.GONE
        renderRunning()
        renderInstalledSpinner()
    }

    private fun renderInstalledSpinner() {
        val previous = installed.getOrNull(b.spInstalled.selectedItemPosition)?.name
        val ready = (vm.modelState.value as? ModelState.Ready)?.info?.name
        val labels = installed.map { "${it.name} (${Formatter.formatFileSize(this, it.sizeBytes)})" }
        b.spInstalled.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        val idx = installed.indexOfFirst { it.name == (ready ?: previous) }
        if (idx >= 0) b.spInstalled.setSelection(idx)
    }

    private fun renderSettings(s: AppSettings) {
        langTags.indexOf(s.sourceLang).takeIf { it >= 0 && it != b.spSource.selectedItemPosition }
            ?.let { b.spSource.setSelection(it) }
        langTags.indexOf(s.targetLang).takeIf { it >= 0 && it != b.spTarget.selectedItemPosition }
            ?.let { b.spTarget.setSelection(it) }

        b.tvTextSize.text = "Taille du texte : ${s.textSizeSp} sp"
        b.tvOpacity.text = "Opacité du fond : ${s.bgOpacity} %"
        if (b.seekTextSize.progress != s.textSizeSp - 12) b.seekTextSize.progress = s.textSizeSp - 12
        if (b.seekOpacity.progress != s.bgOpacity) b.seekOpacity.progress = s.bgOpacity
        if (b.swOriginal.isChecked != s.showOriginal) b.swOriginal.isChecked = s.showOriginal
        if (b.swNotif.isChecked != s.translateNotifications) b.swNotif.isChecked = s.translateNotifications

        ColorMode.entries.indexOfFirst { it.key == s.colorMode }
            .takeIf { it >= 0 && it != b.spColorMode.selectedItemPosition }?.let { b.spColorMode.setSelection(it) }
        val autoClear = s.autoClearSeconds > 0
        if (b.swAutoClear.isChecked != autoClear) b.swAutoClear.isChecked = autoClear
        if (b.swShortcut.isChecked != s.shortcutEnabled) b.swShortcut.isChecked = s.shortcutEnabled

        // La bulle de raccourci suit le réglage (et la permission de superposition)
        val shortcutOn = s.shortcutEnabled && Settings.canDrawOverlays(this)
        if (shortcutOn && !FloatingShortcutService.running.value) FloatingShortcutService.start(this)
        if (!s.shortcutEnabled && FloatingShortcutService.running.value) FloatingShortcutService.stop(this)
    }

    private fun renderPacks() {
        val tm = voskApp.translationManager
        val sel = b.spPack.selectedItemPosition.coerceAtLeast(0)
        val items = pairTags.map { (if (it in downloaded) "✔ " else "") + tm.displayName(it) }
        b.spPack.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        if (sel < items.size) b.spPack.setSelection(sel)
        val where = if (vm.hasSharedAccess()) "dans /VoskCaptions/traduction (gardés après désinstallation)"
        else "dans l'appli (perdus à la désinstallation : accordez l'accès aux fichiers)"
        b.tvPacks.text = if (downloaded.isEmpty()) "Aucune paire installée"
        else "Installées $where :\n" + downloaded.map { tm.displayName(it) }.sorted().joinToString("\n")
    }

    private fun renderRunning() {
        val capturing = AudioCaptureService.running.value
        val armed = AudioCaptureService.armed.value
        b.btnStartStop.text = if (capturing) "Arrêter le sous-titrage" else "Démarrer le sous-titrage"
        b.btnArm.text = if (armed) "✔ Capture activée (toucher pour désactiver)" else "Activer la capture (une seule fois)"
        b.tvArmHint.text = if (armed)
            "L'autorisation Android est conservée : le sous-titrage démarre et s'arrête sans nouvelle boîte de dialogue, y compris depuis la bulle."
        else
            "Android demande « Partager l'écran » : acceptez une fois ici, ensuite plus rien ne s'affichera tant que la capture reste activée."
        b.btnOverlay.text =
            if (SubtitleOverlayService.running.value) "Masquer la fenêtre flottante" else "Afficher la fenêtre flottante"
        val canChange = !capturing && !modelBusy
        b.btnLoad.isEnabled = canChange
        b.btnDeleteModel.isEnabled = canChange
        b.btnImport.isEnabled = canChange
        b.btnImportFolder.isEnabled = canChange
    }

    // ------------------------------------------------------------ autorisations

    private fun hasAudioPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun hasNotificationAccess() =
        NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)

    private fun refreshPermissions() {
        renderSettings(vm.settings.value)   // démarre la bulle si la permission vient d'être accordée
        fun mark(ok: Boolean) = if (ok) "✔" else "✘"
        b.tvPerms.text = "Micro : ${mark(hasAudioPermission())}    " +
            "Superposition : ${mark(Settings.canDrawOverlays(this))}    " +
            "Accès notifications : ${mark(hasNotificationAccess())}    " +
            "Modèles permanents : ${mark(hasStorageAccess())}"
        b.btnPermStorage.visibility = if (hasStorageAccess()) View.GONE else View.VISIBLE
    }

    private fun requestRuntimePermissions() {
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        requestRuntime.launch(perms.toTypedArray())
    }

    private fun hasStorageAccess() = vm.hasSharedAccess()

    /** Accès aux fichiers : permet de garder les modèles dans /VoskCaptions après une désinstallation. */
    private fun requestStoragePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else {
            requestRuntime.launch(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE))
        }
    }

    private fun requestOverlayPermission() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    // ------------------------------------------------------------ démarrage / arrêt

    private fun onArmToggle() {
        if (AudioCaptureService.armed.value) {
            CaptureShortcuts.disarm(this)      // libère la projection (arrête aussi le sous-titrage)
            return
        }
        if (!canCapture()) return
        armOnly = true
        projectionLauncher.launch(CaptureShortcuts.captureIntent(this))
    }

    private fun canCapture(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            toast("La capture audio interne nécessite Android 10 ou plus"); return false
        }
        if (!hasAudioPermission()) { requestRuntimePermissions(); return false }
        if (!Settings.canDrawOverlays(this)) { requestOverlayPermission(); return false }
        return true
    }

    private fun onStartStop() {
        if (AudioCaptureService.running.value) {
            // Pause : la capture reste autorisée. Pour tout libérer, utiliser le bouton « Capture activée ».
            if (AudioCaptureService.armed.value) startService(AudioCaptureService.pauseIntent(this))
            else stopService(Intent(this, AudioCaptureService::class.java))
            return
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            toast("La capture audio interne nécessite Android 10 ou plus"); return
        }
        if (vm.modelState.value !is ModelState.Ready) {
            toast("Chargez d'abord un modèle Vosk"); return
        }
        if (!canCapture()) return

        if (AudioCaptureService.armed.value) {          // déjà autorisée : aucune boîte de dialogue
            SubtitleOverlayService.start(this)
            startService(AudioCaptureService.beginIntent(this))
            return
        }
        armOnly = false
        projectionLauncher.launch(CaptureShortcuts.captureIntent(this))
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
