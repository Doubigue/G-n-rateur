package com.example.voskcaptions.screen

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.voskcaptions.data.AppStorage
import com.example.voskcaptions.databinding.ActivityScreenTranslateBinding
import com.example.voskcaptions.databinding.ItemScreenTextBinding
import com.example.voskcaptions.voskApp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Panneau affiché par-dessus l'appli lue : traductions section par section, copie et export. */
class ScreenTranslateActivity : AppCompatActivity() {

    private lateinit var b: ActivityScreenTranslateBinding
    private val adapter = Adapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityScreenTranslateBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.list.layoutManager = LinearLayoutManager(this)
        b.list.adapter = adapter
        b.root.setOnClickListener { finish() }          // toucher la zone sombre = fermer
        b.panel.setOnClickListener { }                   // ne ferme pas en touchant le panneau
        b.btnClose.setOnClickListener { finish() }
        b.btnCopyAll.setOnClickListener { copy(allTranslations(), "Toutes les traductions copiées") }
        b.btnShare.setOnClickListener { share() }
        b.btnSave.setOnClickListener { save() }
        setupTargetPicker()

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { ScreenTranslation.items.collect { adapter.submit(it); renderStatus() } }
                launch { ScreenTranslation.busy.collect { renderStatus() } }
            }
        }
    }

    /** Choix de la langue cible dans le panneau : change le réglage global et retraduit les textes affichés. */
    private fun setupTargetPicker() {
        val tm = voskApp.translationManager
        val tags = tm.allLanguages()
        b.spTarget.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, tags.map { tm.displayName(it) })
        tags.indexOf(voskApp.settings.state.value.targetLang).takeIf { it >= 0 }?.let { b.spTarget.setSelection(it, false) }
        b.spTarget.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, position: Int, id: Long) {
                val tag = tags.getOrNull(position) ?: return
                if (tag == voskApp.settings.state.value.targetLang) return
                voskApp.settings.update { it.copy(targetLang = tag) }
                tm.closeAll()
                renderStatus()
                ScreenTranslation.retranslate(applicationContext)
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    private fun renderStatus() {
        val items = ScreenTranslation.items.value
        val done = items.count { it.status != ItemStatus.PENDING }
        val target = voskApp.translationManager.displayName(voskApp.settings.state.value.targetLang)
        val app = ScreenTranslation.appLabel.ifBlank { "écran" }
        b.tvTitle.text = "Traduction de « $app » → $target"
        b.progress.visibility = if (ScreenTranslation.busy.value) View.VISIBLE else View.GONE
        b.progress.max = items.size.coerceAtLeast(1)
        b.progress.setProgressCompat(done, true)
        b.tvStatus.text = if (ScreenTranslation.busy.value) "$done / ${items.size} sections traduites…"
        else "${items.size} section(s) · appui long sur un texte pour en copier une partie"
    }

    // ------------------------------------------------------------ copie / export

    private fun shown(i: ScreenItem) = i.translated ?: i.original

    private fun allTranslations() = ScreenTranslation.items.value.joinToString("\n\n") { shown(it) }

    private fun fullExport(): String {
        val date = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE).format(Date(ScreenTranslation.capturedAt))
        val tm = voskApp.translationManager
        return buildString {
            append("Traduction de l'écran — ${ScreenTranslation.appLabel} — $date\n\n")
            ScreenTranslation.items.value.forEachIndexed { k, it ->
                append("[${k + 1}]")
                it.lang?.let { l -> append(" (${tm.displayName(l)})") }
                append('\n')
                append("Original : ${it.original}\n")
                when {
                    it.translated != null -> append("Traduction : ${it.translated}\n")
                    it.note != null -> append("(${it.note})\n")
                }
                append('\n')
            }
        }.trim()
    }

    private fun copy(text: String, msg: String) {
        val cm = getSystemService(ClipboardManager::class.java)
        cm.setPrimaryClip(ClipData.newPlainText("Traduction", text))
        if (Build.VERSION.SDK_INT < 33) toast(msg)
    }

    private fun share() {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Traduction — ${ScreenTranslation.appLabel}")
            putExtra(Intent.EXTRA_TEXT, fullExport())
        }
        startActivity(Intent.createChooser(send, "Exporter la traduction"))
    }

    private fun save() {
        val text = fullExport()
        lifecycleScope.launch {
            val file = withContext(Dispatchers.IO) {
                runCatching {
                    val dir = if (AppStorage.hasSharedAccess(this@ScreenTranslateActivity)) File(AppStorage.sharedRoot, "exports")
                    else getExternalFilesDir("exports") ?: File(filesDir, "exports")
                    dir.mkdirs()
                    val name = "traduction_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".txt"
                    File(dir, name).apply { writeText(text) }
                }
            }
            file.onSuccess { toast("Enregistré : ${it.absolutePath}") }
                .onFailure { toast("Enregistrement impossible : ${it.message}") }
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    // ------------------------------------------------------------ liste

    private inner class Holder(val v: ItemScreenTextBinding) : RecyclerView.ViewHolder(v.root)

    private inner class Adapter : RecyclerView.Adapter<Holder>() {
        private var data: List<ScreenItem> = emptyList()

        fun submit(list: List<ScreenItem>) {
            val sameSize = list.size == data.size
            val old = data
            data = list
            if (sameSize) list.indices.forEach { if (old[it] != list[it]) notifyItemChanged(it) }
            else notifyDataSetChanged()
        }

        override fun getItemCount() = data.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            Holder(ItemScreenTextBinding.inflate(LayoutInflater.from(parent.context), parent, false))

        override fun onBindViewHolder(h: Holder, position: Int) {
            val item = data[position]
            val tm = voskApp.translationManager
            h.v.tvOriginal.text = item.original
            h.v.tvTranslated.text = when (item.status) {
                ItemStatus.PENDING -> "Traduction…"
                ItemStatus.DONE -> item.translated
                ItemStatus.SAME_LANGUAGE -> "(déjà dans la langue cible)"
                ItemStatus.MISSING, ItemStatus.ERROR -> "⚠ ${item.note}"
            }
            h.v.tvLang.text = "${position + 1}" + (item.lang?.let { l -> " · ${tm.displayName(l)}" } ?: "")
            h.v.btnCopy.setOnClickListener { _ -> copy(shown(item), "Copié") }
            h.v.btnCopyBoth.setOnClickListener { _ ->
                copy(item.original + (item.translated?.let { t -> "\n\n$t" } ?: ""), "Original + traduction copiés")
            }
        }
    }
}
