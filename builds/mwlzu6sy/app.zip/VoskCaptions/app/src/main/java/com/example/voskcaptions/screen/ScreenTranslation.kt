package com.example.voskcaptions.screen

import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.widget.Toast
import com.example.voskcaptions.VoskApp
import com.example.voskcaptions.managers.LanguageModelMissingException
import com.example.voskcaptions.services.ShortcutAccessibilityService
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class ItemStatus { PENDING, DONE, SAME_LANGUAGE, MISSING, ERROR }

data class ScreenItem(
    val original: String,
    val translated: String? = null,
    val lang: String? = null,
    val status: ItemStatus = ItemStatus.PENDING,
    val note: String? = null
)

/** Bouton flottant → lecture du texte de l'écran → traduction section par section. */
object ScreenTranslation {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null

    private val _items = MutableStateFlow<List<ScreenItem>>(emptyList())
    val items: StateFlow<List<ScreenItem>> = _items.asStateFlow()

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    var appLabel: String = ""
        private set
    var capturedAt: Long = 0L
        private set

    /** À appeler depuis le thread principal (bulle flottante, bouton d'accessibilité). */
    fun trigger(context: Context) {
        val ctx = context.applicationContext
        val svc = ShortcutAccessibilityService.instance
        if (svc == null) {
            toast(ctx, "Activez le service d'accessibilité « Vosk Captions » pour traduire l'écran")
            runCatching {
                ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            return
        }
        val (label, sections) = try {
            ScreenTextExtractor.extract(svc)
        } catch (t: Throwable) {
            toast(ctx, "Lecture de l'écran impossible : ${t.message}"); return
        }
        if (sections.isEmpty()) {
            toast(ctx, "Aucun texte lisible à l'écran (les images et certaines applis ne sont pas lisibles)")
            return
        }
        job?.cancel()
        appLabel = label
        capturedAt = System.currentTimeMillis()
        _items.value = sections.map { ScreenItem(it.text) }
        ctx.startActivity(
            Intent(ctx, ScreenTranslateActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        )
        job = scope.launch { translateAll(ctx as VoskApp) }
    }

    fun cancel() { job?.cancel() }

    /** Retraduit les mêmes textes (après un changement de langue cible dans le panneau). */
    fun retranslate(context: Context) {
        if (_items.value.isEmpty()) return
        val app = context.applicationContext as VoskApp
        val old = job
        job = scope.launch {
            old?.cancelAndJoin()                       // évite qu'une ancienne traduction écrase la nouvelle
            _items.update { list -> list.map { ScreenItem(it.original) } }
            translateAll(app)
        }
    }

    private suspend fun translateAll(app: VoskApp) {
        _busy.value = true
        val target = app.settings.state.value.targetLang
        try {
            for (i in _items.value.indices) {
                val text = _items.value.getOrNull(i)?.original ?: break
                val result = try {
                    val r = app.translationManager.translateAuto(text, target)
                    if (r.translated == null) ScreenItem(text, null, r.sourceLang, ItemStatus.SAME_LANGUAGE)
                    else ScreenItem(text, r.translated, r.sourceLang, ItemStatus.DONE)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: LanguageModelMissingException) {
                    ScreenItem(text, null, null, ItemStatus.MISSING,
                        "Pack manquant : ${app.translationManager.displayName(e.lang)}")
                } catch (e: Exception) {
                    ScreenItem(text, null, null, ItemStatus.ERROR, e.message ?: "Erreur de traduction")
                }
                _items.update { list -> list.toMutableList().also { if (i < it.size) it[i] = result } }
                if (result.status == ItemStatus.DONE) {
                    runCatching {
                        app.history.insert("screen", appLabel, text, result.translated.orEmpty(), result.lang.orEmpty(), target)
                    }
                }
            }
        } finally {
            _busy.value = false
        }
    }

    private fun toast(ctx: Context, msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
}
