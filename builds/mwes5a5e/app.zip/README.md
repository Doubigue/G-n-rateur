# Turbo Download

Gestionnaire de téléchargements Android (Kotlin + Jetpack Compose) — DL VIBE STUDIO.

## Version 11 – captcha, tailles, épisodes sans lecture

- **Captcha / Cloudflare** (Cinezzz, PapaDuStream…) : les domaines et adresses de vérification (Cloudflare Turnstile, `/cdn-cgi/`, hCaptcha, reCAPTCHA…) ne sont plus jamais bloqués par le filtre de pubs ; les scripts anti-pub ne masquent ni ne suppriment plus un calque ou un cadre qui contient une vérification ; les cookies tiers sont autorisés sur les sites de streaming / torrent (nécessaires au cadre Turnstile) ; le navigateur invisible des épisodes applique la même protection.
- **Taille des téléchargements** : pour les flux découpés (HLS / DASH), la taille n'est plus celle, exagérée, déduite du débit de pointe annoncé par le site (ex. 4 Go pour 200 Mo). Elle reste « inconnue » au tout début, puis est calculée avec les octets réellement reçus, lissée et affichée avec « ~ ». Dans la feuille de qualités, le débit moyen ou la mesure de quelques morceaux remplace le débit de pointe.
- **Télécharger un épisode sans lire la vidéo** : la page et ses lecteurs (iframes, boutons de serveurs, scripts « packés ») sont lus directement pour trouver le flux ; sinon le navigateur invisible, plus grand, fait de vrais appuis sur le lecteur à la place de l'utilisateur.

## Version 11b

- **Recherches récentes du navigateur** : mémorisées (30 maximum), proposées sous la barre d'adresse pendant la saisie (filtrées) et sur la page d'accueil, avec suppression une à une ou « Effacer ».
- **Vérification Cloudflare qui recommence** : les sites de streaming utilisent d'emblée l'identité d'origine du moteur (le cookie obtenu reste valable, plus de rechargement qui l'invalide) ; les étapes de la vérification (`__cf_chl`, `/cdn-cgi/`) ne sont plus retouchées par les règles anti-redirection ; la détection n'est plus déclenchée par erreur sur les pages normales.

## Version 10 – onglet Torrents (inspiré de l'appli BitTorrent analysée)

- Nouvel onglet **Torrents** : listes Tous / En cours / Terminés, pause, reprise, suppression (avec ou sans les fichiers), interrupteur « partager après le téléchargement », ajout d'un magnet, d'une adresse ou d'un fichier .torrent.
- **Détail** : liste des fichiers avec cases à cocher (seuls les fichiers cochés sont téléchargés), avancement par fichier, ouverture d'un fichier, « lire pendant le téléchargement » (mode séquentiel), onglet Détails (hash, pièces, sources/pairs, trackers, envoi, ratio).

## Version 9

- **Listes de lecture** : une vidéo téléchargée depuis une liste (ou la liste entière) est rangée dans un dossier au nom de la liste ; si le dossier existe déjà, les fichiers y sont ajoutés.
- **Torrents / magnets** : session démarrée à l'avance, 12 trackers publics ajoutés au magnet, 4 tentatives de 30 s au lieu d'une attente de 180 s, compteur visible.

## Version 8

- **Connexion Google** (icône compte dans l'onglet YouTube, et menu du navigateur) : liste des comptes Google de l'appareil, puis page de connexion avec l'adresse déjà remplie.
- **Logo des applications** : l'icône réelle d'un APK s'affiche dans Téléchargements (une fois téléchargé) et dans Fichiers.

## Version 7

- **Historique** : badge « ✓ Téléchargé » sur les vidéos déjà téléchargées, recherches récentes sous la barre de recherche YouTube.
- **Lien copié** : au retour dans l'appli, le lien du presse-papiers est proposé au téléchargement (réglable).
- **Sous-titres** (FR/EN) intégrés aux vidéos, **pochette + infos** intégrées aux MP3/M4A.
- **Économie de batterie** (un seul téléchargement sous 20 %), **un dossier par site** (option).
- **Téléchargements** : recherche, tri (récents / nom / taille), statistiques (jour, mois, 7 jours, par site, par type).
- **Fichiers** : convertisseur (MP4 → MP3, alléger en 720p, couper un extrait) et **coffre privé** protégé par le code PIN.
- **Chaînes suivies** (icône cloche de l'onglet YouTube) : les nouvelles vidéos sont téléchargées automatiquement (vérification toutes les 6 h).
- Déjà présents : partage vers l'appli, limite de vitesse, Wi-Fi seulement, lecture aléatoire / boucle.

## Version 6

- **Onglet « Liste de lecture »** (YouTube, comme dans MyDM) : recherche de listes de lecture, ou collage du lien d'une liste / d'une chaîne. Une liste ouverte (ici, ou depuis « Découvrir ») affiche l'écran **« Sélectionné »** : toutes les vidéos cochées d'office, « Tout sélectionner », compteur n/N, bouton **FAIT** → un format unique (MP4 toutes qualités, MP3, M4A, WAV) → les vidéos cochées sont mises en file dans un dossier au nom de la liste. Le contenu est lu directement depuis la page YouTube (rapide) ; yt-dlp complète au-delà de ~100 vidéos et pour les chaînes.
- **Bouton « + »** sur chaque vidéo : constitue une liste de téléchargement (barre en bas), puis un format unique pour tout télécharger d'un coup.
- **Plus d'analyse préalable sur YouTube** : les formats vidéo (Meilleure, 4K → 240p) et audio (MP3, M4A, WAV) s'affichent tout de suite ; un appui lance le téléchargement.

## Version 5 — ce qui change

- **Nom de l'application : Turbo Download** (le dossier des fichiers reste `Téléchargements/DLTurbo`, pour ne rien perdre).
- **Blocage des pubs comme dans MyDM** : mêmes règles (régies publicitaires, adresses de pub), même script
  (calques transparents « cliquez n'importe où », `window.open` vers un autre site, liens fantômes), et même
  traitement des pop-ups : ouverts dans une fenêtre jetable qui ne charge rien ; seul un lien du même site
  cliqué par vous s'ouvre, dans l'onglet courant.
- **YouTube** : plus d'invite « ouvrir / télécharger l'application YouTube » (version web forcée, invites masquées
  et refermées, liens `intent://` rouverts en version web). Le navigateur se présente comme Chrome
  (vrai User-Agent du téléphone, sans le marqueur WebView).
- **Découvrir** : recherche directe sur YouTube (une requête, quasi instantanée), yt-dlp en secours et pour
  « voir plus ». yt-dlp n'impose plus de User-Agent mobile (cause probable de la liste vide) et se met à jour
  tout seul une fois par jour. En cas d'échec : message d'erreur + bouton « Réessayer ».

## Ce que fait l'application

| Fonction | Détail |
|---|---|
| Liens directs | APK, images, vidéos, logiciels, archives, documents… (HTTP/HTTPS) |
| Téléchargement accéléré | Fichier découpé en segments, jusqu'à 32 connexions par fichier |
| Pause / reprise | Reprise à l'octet près, y compris après fermeture de l'appli ou redémarrage du téléphone (au prochain lancement) |
| Torrents | Liens `magnet:`, fichiers `.torrent` (locaux ou distants), via libtorrent |
| Vidéos | YouTube, Instagram, Facebook, TikTok, Pinterest, X/Twitter et 1000+ sites, via yt-dlp + ffmpeg |
| Écran éteint | Service de premier plan + wake lock + verrou Wi-Fi |
| Notifications | Pourcentage, tailles, vitesse, temps restant, nombre de téléchargements, boutons Pause / Reprendre / Annuler |
| File d'attente | 1 à 10 téléchargements simultanés, attente automatique du réseau |
| Paramètres | Connexions, limite de vitesse, Wi-Fi uniquement, tentatives, qualité vidéo, MP3, playlists, limites torrent, thème… |
| Onglet YouTube | Recherche, catégories, onglet « Liste de lecture » (sélection vidéo par vidéo) ; icône de téléchargement sur chaque vidéo → choix MP4 (toutes qualités), MP3, M4A ou WAV, ou playlist entière. Mode « Site YouTube » : le vrai site, sans pub |
| Navigateur | Onglets, blocage des publicités / traqueurs / pop-ups / redirections sur tous les sites, mode ordinateur, page enregistrée hors-ligne (`Pages/`), téléchargement depuis les pages |
| Détection de flux | Sur n'importe quel site : une icône dorée apparaît sur chaque lecteur vidéo (même à l'arrêt) ; les flux HLS/DASH/MP4/MP3 repérés pendant la lecture sont listés, à télécharger en vidéo ou en MP3 |
| Séries et streaming | « Liste d'épisodes / playlist » : de 1 à la fin, par plage ; chaque page d'épisode est ouverte en arrière-plan, la lecture lancée en sourdine, le flux repéré et mis en file avec un nom `Série - Épisode` |
| Images de la page | Choix et téléchargement groupé des images d'une page (Pinterest, galeries…) |
| Favoris | Ajout depuis le menu du navigateur, affichés sur la page d'accueil |
| Minuteur d'arrêt | Dans le lecteur : la musique/vidéo s'arrête après 15, 30, 45, 60 ou 90 min |
| Fenêtre flottante | Une vidéo continue en petite fenêtre (PiP) quand on quitte l'appli, ou via le bouton du lecteur |
| Verrouillage par code | Code de 4 à 8 chiffres (empreinte salée), redemandé après 30 s hors de l'appli, captures d'écran et aperçu des récents bloqués |
| Téléchargements programmés | Plage horaire (ex. 01:00 → 07:00) : hors plage la file attend et démarre toute seule ; ce qui est en cours est remis en attente à la fin de la plage |
| Lecteurs intégrés | Vidéo et audio (lecture en arrière-plan, playlist du dossier, vitesse 0,5× à 2×), images (zoom, balayage), fichiers web (.html, .mhtml, .svg) et texte |
| Fichiers | Gestionnaire du dossier DLTurbo avec miniatures, renommer, supprimer, partager, « lire tout le dossier » |
| Installer des applications | APK, et paquets .xapk / .apks / .apkm (installation par sessions) |
| Décompresser | ZIP (mot de passe), 7z, RAR (version 4), TAR, GZ, BZ2, XZ |
| Partage | « Partager » depuis une autre appli ou clic sur un lien magnet ouvre directement Turbo Download |

Les fichiers sont enregistrés dans `Téléchargements/DLTurbo/` (rangés par catégorie si l'option est activée).

## Compilation

- **APK Studio / GitHub Actions** : projet Gradle standard à la racine (`settings.gradle.kts`).
  Commande : `./gradlew assembleDebug` — JDK 17. Un workflow prêt à l'emploi est fourni dans
  `.github/workflows/build.yml`.
- **Android Studio** : ouvrir le dossier, laisser la synchronisation Gradle se terminer, puis Run.
- La clé dédiée `keystore/dlturbo.jks` signe les APK Debug et Release. Elle est différente
de celle de Mon Coffre. Gardez le keystore et le dépôt privés, et ne remplacez jamais cette
clé après diffusion de l'application : les mises à jour doivent être signées avec la même clé.

Versions : Gradle 8.11.1, Android Gradle Plugin 8.7.3, Kotlin 2.1.20, compileSdk 35, targetSdk 34, minSdk 26 (Android 8.0).

L'APK est volumineux (≈ 100 Mo et plus) : il embarque Python/yt-dlp, ffmpeg et libtorrent pour
`arm64-v8a` et `armeabi-v7a`.

## Clé de signature Turbo Download

- Fichier : `keystore/dlturbo.jks`
- Alias : `dlturbo`
- Utilisée automatiquement pour les variantes Debug et Release.
- Cette clé appartient uniquement à Turbo Download ; elle ne réutilise pas celle de Mon Coffre.
- **Important :** sauvegardez le fichier `.jks` dans un endroit sûr et gardez le dépôt privé.
  Si cette clé est perdue ou remplacée, Android ne permettra plus de mettre à jour l'application
  déjà installée avec une APK signée par cette nouvelle clé.

## Organisation du code

```
app/src/main/java/com/dlvibestudio/dlturbo/
├── App.kt                      Initialisation
├── data/
│   ├── DownloadItem.kt         Modèle d'un téléchargement (+ segments)
│   ├── DownloadRepository.kt   Liste observable, sauvegardée en JSON
│   └── Settings.kt             Paramètres
├── engine/
│   ├── DownloadManager.kt      File d'attente, pause/reprise, réseau
│   ├── HttpDownloader.kt       Moteur HTTP multi-connexions
│   ├── TorrentEngine.kt        Moteur BitTorrent (libtorrent4j)
│   ├── VideoEngine.kt          Extraction vidéo (yt-dlp + ffmpeg)
│   ├── VideoInfo.kt            Formats disponibles (pour le choix MP3/WAV/vidéo)
│   ├── ArchiveManager.kt       Décompression (protégée contre le zip-slip)
│   ├── ApkInstaller.kt         Installation APK et paquets scindés
│   └── Links.kt                Reconnaissance des liens, noms de fichiers
├── service/
│   ├── DownloadService.kt      Service de premier plan (écran éteint)
│   ├── Notifications.kt        Notifications de progression
│   ├── ActionReceiver.kt       Boutons des notifications
│   └── PlaybackService.kt      Lecture audio/vidéo en arrière-plan (media3)
└── ui/                         Écrans Compose : téléchargements, YouTube, navigateur (WebHub,
                                AdBlocker), fichiers, lecteurs, paramètres, thème
```

## Remplacer le logo

- Icône de l'appli : `app/src/main/res/mipmap-*/ic_launcher*.png`
- Logo affiché dans l'appli : `app/src/main/res/drawable-nodpi/logo.png` (512 × 512)
- Source haute définition : `logo-dl-turbo.png`

## À savoir

- **Vitesse** : le multi-connexions accélère nettement les serveurs qui limitent chaque connexion,
  mais ne peut pas dépasser le débit de votre ligne ni celui du serveur.
- **Sites vidéo** : ils changent souvent. Si un site ne fonctionne plus :
  Paramètres → « Mettre à jour le moteur vidéo (yt-dlp) ».
- **Écran éteint** : sur certains téléphones (Xiaomi, Tecno, Infinix, Huawei, Samsung…), il faut en plus
  désactiver l'optimisation de batterie : Paramètres → « Désactiver l'optimisation de batterie ».
- **targetSdk 34** : volontaire. À partir de 35, Android limite ce type de service à 6 h par jour.
- **Blocage des pubs** : liste de domaines (`app/src/main/assets/blocklist.txt`, modifiable) + filtres de
  pages + scripts anti-pop-up. Sur YouTube, le blocage est « au mieux » : YouTube modifie souvent son site
  et une mise à jour de l'appli peut être nécessaire.
- **Séries / streaming** : la recherche des épisodes dépend de chaque site. Les lecteurs protégés (DRM,
  captcha, lecteurs obfusqués, lien qui expire) peuvent échouer : les épisodes introuvables sont listés
  à la fin. Gardez l'application ouverte pendant la recherche (≈ 5 à 30 s par épisode). Le flux choisi
  est le plus probable ; une publicité vidéo peut parfois être prise à sa place.
- **Connexion Google** : Google peut refuser la connexion dans un navigateur intégré. Les vidéos publiques
  se téléchargent sans compte.
- **Limites** : RAR5 non géré (RAR4 oui) ; les données OBB des .xapk sont ignorées ; le choix de fichier à
  envoyer (upload) depuis une page web n'est pas implémenté.
- **Programmation** : l'appli doit rester vivante (une notification reste affichée pendant l'attente) ; si Android
  ferme l'appli pendant la nuit, la file reprendra à la prochaine ouverture. Désactivez la plage pour démarrer tout de suite.
- **Code oublié** : aucune récupération possible, il faut effacer les données de l'application.
- **Projet non compilé** : le code a été écrit sans environnement Android ; une première compilation peut
  révéler de petites erreurs à corriger.
- **Droits** : ne téléchargez que des contenus que vous avez le droit de télécharger.
