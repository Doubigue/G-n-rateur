package com.dlvibestudio.dlturbo.ui

import android.content.Context

/**
 * Vérification Cloudflare (« Un instant… », case « Je suis humain ») :
 *  - nos scripts (anti-pub, anti-pop-up, bouton de téléchargement) ne s'exécutent jamais sur la page de
 *    vérification ni dans le cadre Turnstile : Cloudflare refuse un navigateur dont les fonctions sont modifiées ;
 *  - un site qui présente une vérification passe en « mode compatible » : identité exacte du moteur du
 *    téléphone (User-Agent d'origine, cohérent avec les en-têtes envoyés) et cookies tiers autorisés.
 *    Le cookie obtenu (cf_clearance) étant lié à cette identité, le navigateur invisible (épisodes,
 *    recherche de flux) l'utilise aussi pour ce site.
 */
class Cloudflare(context: Context) {
    private val prefs = context.getSharedPreferences("dlturbo_cloudflare", Context.MODE_PRIVATE)
    private val sites: MutableSet<String> = prefs.getStringSet("sites", emptySet())!!.toHashSet()

    fun isCompat(site: String) = site in sites

    /** Renvoie true si le site vient d'être ajouté. */
    fun add(site: String): Boolean {
        if (site.isBlank() || !sites.add(site)) return false
        prefs.edit().putStringSet("sites", HashSet(sites)).apply()
        return true
    }

    companion object {
        /** Entoure un script injecté : il ne s'exécute pas sur une page de vérification ni dans un cadre captcha. */
        fun guard(script: String): String = """
(function(){
  try {
    var h = location.hostname;
    if (/(^|\.)(cloudflare\.com|hcaptcha\.com|recaptcha\.net|arkoselabs\.com|funcaptcha\.com|geetest\.com)${'$'}/i.test(h)) return;
    if (h === 'www.google.com' && location.pathname.indexOf('/recaptcha') === 0) return;
    if (location.pathname.indexOf('/cdn-cgi/') === 0 || location.search.indexOf('__cf_chl') >= 0) return;
    var n = performance.getEntriesByType && performance.getEntriesByType('navigation')[0];
    if (n && (n.responseStatus === 403 || n.responseStatus === 503 || n.responseStatus === 429)) return;
  } catch(e) {}
""" + script + "\n})();"

        /** Renvoie "1" si la page affichée est une vérification Cloudflare. */
        const val DETECT = """
(function(){
  try {
    var t = (document.title || '').toLowerCase();
    if (/just a moment|un instant|attention required|checking your browser|vérification|verify you are human|un momento/.test(t)) return '1';
    if (window._cf_chl_opt) return '1';
    if (document.querySelector('#challenge-form, #cf-challenge-running, #challenge-stage, [name="cf-turnstile-response"], script[src*="/cdn-cgi/challenge-platform/"]')) return '1';
  } catch(e) {}
  return '0';
})();
"""
    }
}

/**
 * Services de vérification (Cloudflare Turnstile / « Un instant… », hCaptcha, reCAPTCHA…) : jamais bloqués par le
 * filtre de pubs, jamais masqués par les scripts anti-pub, cookies tiers autorisés.
 */
object CaptchaRules {
    private val HOSTS = listOf(
        "challenges.cloudflare.com", "cloudflare.com", "cloudflareinsights.com", "cf-ns.com",
        "hcaptcha.com", "recaptcha.net", "arkoselabs.com", "funcaptcha.com", "geetest.com",
    )

    fun isCaptchaHost(host: String?): Boolean {
        val h = host?.lowercase() ?: return false
        return HOSTS.any { h == it || h.endsWith(".$it") }
    }

    /** Adresse d'une vérification : hôte dédié, dossier /cdn-cgi/ (Cloudflare) ou /recaptcha/ de Google. */
    fun isCaptchaUrl(uri: android.net.Uri): Boolean {
        if (isCaptchaHost(uri.host)) return true
        val path = (uri.path ?: "").lowercase()
        if (path.startsWith("/cdn-cgi/") || path.contains("/recaptcha/") || path.contains("/turnstile/")) return true
        val h = uri.host?.lowercase() ?: return false
        return (h == "www.google.com" || h == "www.gstatic.com" || h == "gstatic.com") && path.contains("recaptcha")
    }

    /** Sélecteur CSS des éléments d'une vérification (cadre ou conteneur). */
    const val SELECTOR = "iframe[src*=\"challenges.cloudflare.com\"], iframe[src*=\"hcaptcha\"], iframe[src*=\"recaptcha\"], " +
        "iframe[src*=\"turnstile\"], iframe[src*=\"captcha\"], .cf-turnstile, .g-recaptcha, .h-captcha, #cf-chl-widget, " +
        "[name=\"cf-turnstile-response\"], [id^=\"cf-chl\"], #challenge-stage, #challenge-form"

    /** Renvoie "1" si la page contient un cadre ou un widget de vérification. */
    const val DETECT_WIDGET = """
(function(){
  try { return document.querySelector('iframe[src*="challenges.cloudflare.com"], iframe[src*="hcaptcha"], iframe[src*="recaptcha"], .cf-turnstile, .g-recaptcha, .h-captcha') ? '1' : '0'; } catch(e) { return '0'; }
})();
"""
}
