extends Node3D
## Rendu 3D de Vibe Strike : stade, terrain, buts, ballon, joueurs, caméra.
## La logique du jeu reste en coordonnées "terrain" (720 x 1280) dans main.gd ;
## ce script les convertit en mètres (1 unité terrain = 4 cm) et les affiche.

const S := 0.04                    # mètres par unité terrain
const BALL_R3 := 0.16
const CROSSBAR := 2.44
const NET_DEPTH := 2.0
const P3D := preload("res://scripts/player3d.gd")

var game: Node                     # main.gd
var cam: Camera3D
var sun: DirectionalLight3D
var ball_mi: MeshInstance3D
var keeper: Node3D
var mates: Array = []
var defs: Array = []
var net_back: Node3D
var cam_pos := Vector3(0, 22, 40)
var cam_look := Vector3(0, 0, -10)
var _prev_def: Array = []
var _prev_keeper_x := 360.0
var _ball_prev := Vector3.ZERO
var _kit_shown := -1


func w(p: Vector2, h: float = 0.0) -> Vector3:
	return Vector3((p.x - 360.0) * S, h, (p.y - 640.0) * S)


func f(v: Vector3) -> Vector2:
	return Vector2(v.x / S + 360.0, v.z / S + 640.0)


## position terrain (+ hauteur en mètres) -> position écran (coordonnées du canvas)
func to_screen(p: Vector2, h: float = 0.0) -> Vector2:
	return cam.unproject_position(w(p, h))


## position écran -> point du terrain touché (rayon contre le sol)
func screen_to_field(sp: Vector2) -> Vector2:
	var o := cam.project_ray_origin(sp)
	var d := cam.project_ray_normal(sp)
	if d.y > -0.002:
		return Vector2(-99999, -99999)
	var k := -o.y / d.y
	return f(o + d * k)


func _ready() -> void:
	_build_env()
	_build_field()
	_build_goal()
	_build_stadium()
	_build_ball()
	keeper = _new_player()
	keeper.call("set_colors", Color(0.15, 0.75, 0.95), Color(0.08, 0.08, 0.1))
	cam = Camera3D.new()
	cam.fov = 58.0
	cam.far = 400.0
	add_child(cam)
	cam.current = true


# ------------------------------------------------------------------ CONSTRUCTION
func _build_env() -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sm := ProceduralSkyMaterial.new()
	sm.sky_top_color = Color(0.22, 0.45, 0.85)
	sm.sky_horizon_color = Color(0.75, 0.82, 0.92)
	sm.ground_bottom_color = Color(0.1, 0.12, 0.1)
	sm.ground_horizon_color = Color(0.6, 0.65, 0.6)
	sky.sky_material = sm
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.6
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-52, -30, 0)
	sun.light_energy = 1.0
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 70.0
	add_child(sun)


func _mat(col: Color, tex: Texture2D = null, unshaded: bool = false) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = col
	if tex:
		m.albedo_texture = tex
		m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC
	if unshaded:
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.roughness = 0.9
	return m


func _mesh(mesh: Mesh, mat: Material, pos: Vector3, shadow: bool = true) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.position = pos
	if not shadow:
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)
	return mi


func _build_field() -> void:
	# herbe autour du terrain
	var ground := PlaneMesh.new()
	ground.size = Vector2(160, 160)
	_mesh(ground, _mat(Color(0.1, 0.28, 0.1)), Vector3(0, -0.02, 0), false)
	# terrain : texture dessinée à partir des mêmes coordonnées que la logique
	var img := Image.create(720, 1280, true, Image.FORMAT_RGB8)
	for i in 13:
		var c := Color(0.16, 0.4, 0.15) if i % 2 == 0 else Color(0.135, 0.35, 0.13)
		img.fill_rect(Rect2i(0, i * 100, 720, 100), c)
	var lc := Color(0.85, 0.88, 0.85)
	_rect_lines(img, Rect2i(30, 150, 660, 1110), 5, lc)
	_rect_lines(img, Rect2i(130, 150, 460, 280), 5, lc)
	_rect_lines(img, Rect2i(230, 150, 260, 110), 5, lc)
	img.fill_rect(Rect2i(30, 1258, 660, 5), lc)
	_arc(img, Vector2(360, 380), 110, deg_to_rad(30), deg_to_rad(150), lc)
	_arc(img, Vector2(360, 1260), 130, PI, TAU, lc)
	_disc(img, Vector2(360, 360), 6, lc)
	img.generate_mipmaps()
	var pm := PlaneMesh.new()
	pm.size = Vector2(720 * S, 1280 * S)
	_mesh(pm, _mat(Color.WHITE, ImageTexture.create_from_image(img)), Vector3.ZERO, false)


func _rect_lines(img: Image, r: Rect2i, th: int, c: Color) -> void:
	img.fill_rect(Rect2i(r.position.x, r.position.y, r.size.x, th), c)
	img.fill_rect(Rect2i(r.position.x, r.end.y - th, r.size.x, th), c)
	img.fill_rect(Rect2i(r.position.x, r.position.y, th, r.size.y), c)
	img.fill_rect(Rect2i(r.end.x - th, r.position.y, th, r.size.y), c)


func _arc(img: Image, c: Vector2, r: float, a0: float, a1: float, col: Color) -> void:
	var n := int(r * (a1 - a0) * 1.5)
	for i in n + 1:
		var a := lerpf(a0, a1, float(i) / n)
		var p := c + Vector2(cos(a), sin(a)) * r
		img.fill_rect(Rect2i(int(p.x) - 2, int(p.y) - 2, 5, 5), col)


func _disc(img: Image, c: Vector2, r: int, col: Color) -> void:
	for y in range(-r, r + 1):
		for x in range(-r, r + 1):
			if x * x + y * y <= r * r:
				img.set_pixel(int(c.x) + x, int(c.y) + y, col)


func _build_goal() -> void:
	var gl: float = game.GOAL_L
	var gr: float = game.GOAL_R
	var gy: float = game.GOAL_Y
	var post := _mat(Color(0.97, 0.97, 0.97))
	post.roughness = 0.3
	var cyl := CylinderMesh.new()
	cyl.top_radius = 0.06
	cyl.bottom_radius = 0.06
	cyl.height = CROSSBAR
	_mesh(cyl, post, w(Vector2(gl, gy), CROSSBAR / 2.0))
	_mesh(cyl, post, w(Vector2(gr, gy), CROSSBAR / 2.0))
	var bar := CylinderMesh.new()
	bar.top_radius = 0.06
	bar.bottom_radius = 0.06
	bar.height = (gr - gl) * S + 0.12
	var b := _mesh(bar, post, w(Vector2((gl + gr) / 2.0, gy), CROSSBAR))
	b.rotation_degrees = Vector3(0, 0, 90)
	# filet
	var ni := Image.create(64, 64, true, Image.FORMAT_RGBA8)
	ni.fill(Color(1, 1, 1, 0.0))
	for i in 64:
		for k in 3:
			ni.set_pixel(i, k, Color(1, 1, 1, 0.85))
			ni.set_pixel(k, i, Color(1, 1, 1, 0.85))
	ni.generate_mipmaps()
	var nm := _mat(Color.WHITE, ImageTexture.create_from_image(ni))
	nm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
	nm.alpha_scissor_threshold = 0.3
	nm.cull_mode = BaseMaterial3D.CULL_DISABLED
	nm.uv1_scale = Vector3(30, 9, 1)
	var width := (gr - gl) * S
	net_back = Node3D.new()
	add_child(net_back)
	net_back.position = w(Vector2((gl + gr) / 2.0, gy))
	var back := MeshInstance3D.new()
	var q := QuadMesh.new()
	q.size = Vector2(width, CROSSBAR)
	back.mesh = q
	back.material_override = nm
	back.position = Vector3(0, CROSSBAR / 2.0, -NET_DEPTH)
	back.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	net_back.add_child(back)
	var top := MeshInstance3D.new()
	var qt := QuadMesh.new()
	qt.size = Vector2(width, NET_DEPTH)
	top.mesh = qt
	top.material_override = nm
	top.position = Vector3(0, CROSSBAR, -NET_DEPTH / 2.0)
	top.rotation_degrees = Vector3(-90, 0, 0)
	top.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	net_back.add_child(top)
	for sgn in [-1.0, 1.0]:
		var side := MeshInstance3D.new()
		var qs := QuadMesh.new()
		qs.size = Vector2(NET_DEPTH, CROSSBAR)
		side.mesh = qs
		side.material_override = nm
		side.position = Vector3(sgn * width / 2.0, CROSSBAR / 2.0, -NET_DEPTH / 2.0)
		side.rotation_degrees = Vector3(0, 90, 0)
		side.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		net_back.add_child(side)


func _build_stadium() -> void:
	# foule : texture de points colorés
	var ci := Image.create(256, 128, true, Image.FORMAT_RGB8)
	ci.fill(Color(0.12, 0.12, 0.14))
	var rng := RandomNumberGenerator.new()
	rng.seed = 7
	var cols := [Color(0.7, 0.56, 0.2), Color(0.75, 0.42, 0.1), Color(0.7, 0.7, 0.7), Color(0.1, 0.42, 0.22),
		Color(0.55, 0.16, 0.16), Color(0.16, 0.26, 0.55), Color(0.42, 0.32, 0.25), Color(0.22, 0.18, 0.16),
		Color(0.3, 0.28, 0.3), Color(0.35, 0.25, 0.2)]
	for y in range(2, 128, 6):
		for x in range(2, 256, 5):
			var c: Color = cols[rng.randi() % cols.size()]
			ci.fill_rect(Rect2i(x + rng.randi_range(-1, 1), y, 3, 4), c)
	ci.generate_mipmaps()
	var crowd := _mat(Color.WHITE, ImageTexture.create_from_image(ci))
	crowd.uv1_scale = Vector3(8, 3, 1)
	var concrete := _mat(Color(0.32, 0.33, 0.36))
	# tribune derrière le but et sur les côtés : plan incliné + muret
	var zgoal := (150.0 - 640.0) * S
	_stand(Vector3(0, 0, zgoal - 7.0), 0.0, 70.0, crowd, concrete)
	_stand(Vector3(-22.0, 0, 0), 90.0, 80.0, crowd, concrete)
	_stand(Vector3(22.0, 0, 0), -90.0, 80.0, crowd, concrete)
	# panneaux publicitaires DL VIBE STUDIO
	var board_mat := _mat(Color(0.06, 0.06, 0.08))
	_board(Vector3(0, 0.45, zgoal - 4.0), 0.0, 36.0, board_mat)
	_board(Vector3(-15.6, 0.45, 2.0), 90.0, 46.0, board_mat)
	_board(Vector3(15.6, 0.45, 2.0), -90.0, 46.0, board_mat)


func _stand(pos: Vector3, rot_y: float, width: float, crowd: Material, concrete: Material) -> void:
	var root := Node3D.new()
	root.position = pos
	root.rotation_degrees.y = rot_y
	add_child(root)
	var q := QuadMesh.new()
	q.size = Vector2(width, 16.0)
	var mi := MeshInstance3D.new()
	mi.mesh = q
	mi.material_override = crowd
	mi.position = Vector3(0, 6.5, -5.5)
	mi.rotation_degrees.x = -35.0
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(mi)
	var wall := BoxMesh.new()
	wall.size = Vector3(width, 1.6, 0.4)
	var wi := MeshInstance3D.new()
	wi.mesh = wall
	wi.material_override = concrete
	wi.position = Vector3(0, 0.8, 1.0)
	root.add_child(wi)


func _board(pos: Vector3, rot_y: float, width: float, mat: Material) -> void:
	var root := Node3D.new()
	root.position = pos
	root.rotation_degrees.y = rot_y
	add_child(root)
	var bm := BoxMesh.new()
	bm.size = Vector3(width, 0.9, 0.15)
	var mi := MeshInstance3D.new()
	mi.mesh = bm
	mi.material_override = mat
	root.add_child(mi)
	var n := int(width / 12.0)
	for i in n:
		var l := Label3D.new()
		l.text = "DL VIBE STUDIO" if i % 2 == 0 else "VIBE STRIKE"
		l.font_size = 64
		l.pixel_size = 0.009
		l.modulate = Color(0.95, 0.76, 0.25)
		l.outline_size = 0
		l.position = Vector3(-width / 2.0 + (i + 0.5) * width / n, 0, 0.09)
		l.shaded = false
		root.add_child(l)


func _build_ball() -> void:
	var img := Image.create(256, 128, true, Image.FORMAT_RGB8)
	img.fill(Color(0.97, 0.97, 0.97))
	var spots := [Vector2(0.0, 0.5), Vector2(0.2, 0.2), Vector2(0.2, 0.8), Vector2(0.4, 0.5), Vector2(0.6, 0.2),
		Vector2(0.6, 0.8), Vector2(0.8, 0.5), Vector2(1.0, 0.5), Vector2(0.5, 0.0), Vector2(0.5, 1.0)]
	for s in spots:
		var sv: Vector2 = s
		var cx := int(sv.x * 256.0)
		var cy := int(sv.y * 128.0)
		for y in range(-12, 13):
			for x in range(-18, 19):
				if (x * x) / 324.0 + (y * y) / 144.0 <= 1.0:
					var px := posmod(cx + x, 256)
					var py := clampi(cy + y, 0, 127)
					img.set_pixel(px, py, Color(0.08, 0.08, 0.1))
	img.generate_mipmaps()
	var sm := SphereMesh.new()
	sm.radius = BALL_R3
	sm.height = BALL_R3 * 2.0
	var m := _mat(Color.WHITE, ImageTexture.create_from_image(img))
	m.roughness = 0.6
	m.metallic_specular = 0.25
	ball_mi = _mesh(sm, m, Vector3(0, BALL_R3, 0))


func _new_player() -> Node3D:
	var p: Node3D = P3D.new()
	add_child(p)
	return p


func _pool(arr: Array, n: int) -> void:
	while arr.size() < n:
		arr.append(_new_player())
	for i in arr.size():
		(arr[i] as Node3D).visible = i < n


# ------------------------------------------------------------------ SYNCHRO
func kick_holder() -> void:
	var h: int = game.holder
	if h < mates.size():
		(mates[h] as Node3D).call("kick")


func _process(delta: float) -> void:
	if game == null:
		return
	var in_game: bool = game.screen == game.Screen.GAME
	var team: Array = game.team if in_game else [Vector2(360, 560)]
	var defenders: Array = game.defenders if in_game else []
	var holder: int = game.holder if in_game else 0
	var phase: int = game.phase

	# couleurs du maillot choisi
	var kit_i: int = game.kit
	_pool(mates, team.size())
	if kit_i != _kit_shown:
		_kit_shown = kit_i
		for m in mates:
			_apply_kit(m as Node3D)
	for i in mates.size():
		var p := mates[i] as Node3D
		if not p.has_meta("kit") or int(p.get_meta("kit")) != _kit_shown:
			_apply_kit(p)
		if i >= team.size():
			continue
		p.position = w(team[i])
		p.rotation.y = PI
		p.call("play", "idle")
		var aim: bool = in_game and (phase == game.Phase.AIM or phase == game.Phase.DRAW)
		if aim and i == holder:
			p.call("set_ring", true, Color(0.95, 0.76, 0.25, 0.9))
		elif aim:
			var a := 0.5 + 0.4 * sin(game.t * 6.0)
			p.call("set_ring", true, Color(1, 1, 1, a))
		else:
			p.call("set_ring", false)
		p.call("tick", delta)

	# défenseurs
	_pool(defs, defenders.size())
	while _prev_def.size() < defenders.size():
		_prev_def.append(Vector2.ZERO)
	for i in defenders.size():
		var p := defs[i] as Node3D
		if not p.has_meta("opp"):
			p.set_meta("opp", true)
			p.call("set_colors", Color(0.78, 0.12, 0.15), Color(0.95, 0.95, 0.95))
		var dp: Vector2 = (defenders[i] as Dictionary)["pos"]
		var v := (dp - (_prev_def[i] as Vector2)) / maxf(delta, 0.001)
		_prev_def[i] = dp
		p.position = w(dp)
		if v.length() > 25.0 and v.length() < 2000.0:
			p.call("play", "walk", clampf(v.length() / 90.0, 0.6, 1.8))
			p.rotation.y = lerp_angle(p.rotation.y, atan2(v.x, v.y), minf(1.0, delta * 8.0))
		else:
			p.call("play", "idle")
			p.rotation.y = lerp_angle(p.rotation.y, 0.0, minf(1.0, delta * 4.0))
		p.call("tick", delta)

	# gardien
	var kx: float = game.keeper_x if in_game else 360.0
	keeper.position = w(Vector2(kx, game.GOAL_Y + 22.0))
	keeper.rotation.y = 0.0
	var kv := (kx - _prev_keeper_x) / maxf(delta, 0.001)
	_prev_keeper_x = kx
	keeper.call("play", "walk" if absf(kv) > 30.0 else "idle", 1.2)
	var dive_target := 0.0
	if in_game and phase == game.Phase.FLIGHT and not game.flight_is_pass:
		var bpos: Vector2 = game.ball
		if bpos.y < game.GOAL_Y + 230.0:
			var dx := bpos.x - kx
			if absf(dx) > 22.0:
				dive_target = clampf(dx / 70.0, -1.0, 1.0)
	elif in_game and phase == game.Phase.RESULT and String(game.msg) == "Arrêt du gardien !":
		dive_target = float(keeper.get("dive"))
	keeper.set("dive", lerpf(float(keeper.get("dive")), dive_target, minf(1.0, delta * 9.0)))
	keeper.call("tick", delta)

	# ballon
	var bp: Vector2 = game.ball if in_game else Vector2(360, 540)
	var h: float = float(game.flight_h) * 0.025 if in_game else 0.0
	var pos := w(bp, h + BALL_R3)
	var mv := pos - _ball_prev
	mv.y = 0.0
	if mv.length() > 0.0005 and mv.length() < 5.0:
		var axis := Vector3.UP.cross(mv.normalized())
		ball_mi.rotate(axis, mv.length() / BALL_R3)
	_ball_prev = pos
	ball_mi.position = pos

	# filet qui ondule sur un but
	var wob: float = game.net_wobble
	net_back.scale = Vector3(1.0, 1.0, 1.0 + 0.25 * wob * absf(sin(game.t * 20.0)))

	_update_camera(delta, in_game, team, holder, phase)


func _apply_kit(p: Node3D) -> void:
	var k: Dictionary = game.kits[_kit_shown]
	p.call("set_colors", k["main"], k["acc"])
	p.set_meta("kit", _kit_shown)


func _update_camera(delta: float, in_game: bool, team: Array, holder: int, phase: int) -> void:
	var goal_c := Vector2(360, game.GOAL_Y)
	var want_pos: Vector3
	var want_look: Vector3
	if not in_game:
		var a := float(game.t) * 0.12
		want_look = w(Vector2(360, 420))
		want_pos = want_look + Vector3(sin(a) * 17.0, 7.5, cos(a) * 17.0)
		cam_pos = cam_pos.lerp(want_pos, minf(1.0, delta * 1.5))
		cam_look = cam_look.lerp(want_look, minf(1.0, delta * 1.5))
	else:
		# pas de mouvement pendant le tracé : le doigt garde ses repères
		if phase == game.Phase.DRAW:
			return
		var focus: Vector2 = team[holder] if holder < team.size() else Vector2(360, 900)
		if phase == game.Phase.FLIGHT or phase == game.Phase.RESULT:
			focus = focus.lerp(game.ball, 0.35)
		# vue "derrière le tireur" : il reste en bas de l'écran, le but est visible au fond
		want_pos = w(Vector2(lerpf(360.0, focus.x, 0.8), focus.y)) + Vector3(0, 4.8, 7.0)
		want_look = w(focus.lerp(goal_c, 0.25), 0.0)
		var k := minf(1.0, delta * 3.0)
		cam_pos = cam_pos.lerp(want_pos, k)
		cam_look = cam_look.lerp(want_look, k)
	var shake: float = game.shake
	var jit := Vector3(randf_range(-1, 1), randf_range(-1, 1), 0) * shake * 0.25
	cam.position = cam_pos + jit
	cam.look_at(cam_look + jit, Vector3.UP)


## place la caméra tout de suite (début de niveau)
func snap_camera() -> void:
	cam_pos = cam.position
