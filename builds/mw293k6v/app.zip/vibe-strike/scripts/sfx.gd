extends Node
## Sons de Vibe Strike, synthétisés au démarrage (aucun fichier audio à importer).

const RATE := 22050

var enabled := true
var sounds := {}
var players: Array[AudioStreamPlayer] = []
var crowd: AudioStreamPlayer


func _ready() -> void:
	for i in 8:
		var p := AudioStreamPlayer.new()
		add_child(p)
		players.append(p)
	crowd = AudioStreamPlayer.new()
	crowd.volume_db = -16.0
	add_child(crowd)
	sounds["kick"] = _wav(_kick(0.22, 1.0), false)
	sounds["pass"] = _wav(_kick(0.14, 0.55), false)
	sounds["whistle"] = _wav(_whistle(0.45), false)
	sounds["post"] = _wav(_post(0.8), false)
	sounds["cheer"] = _wav(_cheer(2.6), false)
	sounds["groan"] = _wav(_groan(1.0), false)
	sounds["click"] = _wav(_blip(0.06, 900.0, 900.0), false)
	sounds["star"] = _wav(_blip(0.22, 700.0, 1400.0), false)
	crowd.stream = _wav(_crowd_loop(3.0), true)


func play(name: String, pitch: float = 1.0, vol_db: float = 0.0) -> void:
	if not enabled or not sounds.has(name):
		return
	for p in players:
		if not p.playing:
			p.stream = sounds[name]
			p.pitch_scale = pitch
			p.volume_db = vol_db
			p.play()
			return


func crowd_on(on: bool) -> void:
	if on and enabled:
		if not crowd.playing:
			crowd.play()
	else:
		crowd.stop()


func set_enabled(on: bool) -> void:
	enabled = on
	if not on:
		crowd.stop()
		for p in players:
			p.stop()


# ------------------------------------------------------------------ SYNTHÈSE
func _wav(samples: PackedFloat32Array, loop: bool) -> AudioStreamWAV:
	var data := PackedByteArray()
	data.resize(samples.size() * 2)
	for i in samples.size():
		data.encode_s16(i * 2, int(clampf(samples[i], -1.0, 1.0) * 32000.0))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = RATE
	w.stereo = false
	w.data = data
	if loop:
		w.loop_mode = AudioStreamWAV.LOOP_FORWARD
		w.loop_begin = 0
		w.loop_end = samples.size()
	return w


func _kick(dur: float, amp: float) -> PackedFloat32Array:
	var n := int(dur * RATE)
	var out := PackedFloat32Array()
	out.resize(n)
	var ph := 0.0
	for i in n:
		var tt := float(i) / RATE
		var f := 55.0 + 110.0 * exp(-tt * 30.0)
		ph += TAU * f / RATE
		var v := sin(ph) * exp(-tt * 16.0) * 0.9
		v += randf_range(-1.0, 1.0) * exp(-tt * 140.0) * 0.5
		out[i] = v * amp
	return out


func _whistle(dur: float) -> PackedFloat32Array:
	var n := int(dur * RATE)
	var out := PackedFloat32Array()
	out.resize(n)
	var ph := 0.0
	for i in n:
		var tt := float(i) / RATE
		var f := 2900.0 + sin(tt * TAU * 28.0) * 140.0
		ph += TAU * f / RATE
		var env := minf(1.0, tt / 0.02) * minf(1.0, (dur - tt) / 0.06)
		out[i] = (sin(ph) * 0.3 + randf_range(-1.0, 1.0) * 0.04) * env
	return out


func _post(dur: float) -> PackedFloat32Array:
	var n := int(dur * RATE)
	var out := PackedFloat32Array()
	out.resize(n)
	var freqs := [523.0, 1347.0, 2211.0, 3119.0]
	var decays := [5.0, 7.0, 10.0, 14.0]
	for i in n:
		var tt := float(i) / RATE
		var v := 0.0
		for k in freqs.size():
			v += sin(TAU * float(freqs[k]) * tt) * exp(-tt * float(decays[k])) * 0.22
		out[i] = v
	return out


func _cheer(dur: float) -> PackedFloat32Array:
	var n := int(dur * RATE)
	var out := PackedFloat32Array()
	out.resize(n)
	var lp := 0.0
	var lp2 := 0.0
	for i in n:
		var tt := float(i) / RATE
		lp += (randf_range(-1.0, 1.0) - lp) * 0.22
		lp2 += (lp - lp2) * 0.35
		var env := minf(1.0, tt / 0.25) * exp(-maxf(0.0, tt - 0.6) * 1.4)
		var wobble := 1.0 + 0.25 * sin(tt * 9.0) * sin(tt * 3.1)
		out[i] = lp2 * env * wobble * 1.6
	return out


func _groan(dur: float) -> PackedFloat32Array:
	var n := int(dur * RATE)
	var out := PackedFloat32Array()
	out.resize(n)
	var lp := 0.0
	var ph := 0.0
	for i in n:
		var tt := float(i) / RATE
		lp += (randf_range(-1.0, 1.0) - lp) * 0.06
		ph += TAU * (190.0 - tt * 60.0) / RATE
		var env := sin(PI * tt / dur)
		out[i] = (lp * 2.2 + sin(ph) * 0.08) * env
	return out


func _crowd_loop(dur: float) -> PackedFloat32Array:
	var n := int(dur * RATE)
	var out := PackedFloat32Array()
	out.resize(n)
	var lp := 0.0
	for i in n:
		lp += (randf_range(-1.0, 1.0) - lp) * 0.09
		out[i] = lp * 1.4
	# fondu aux bords pour une boucle sans claquement
	var fade := int(0.05 * RATE)
	for i in fade:
		var k := float(i) / fade
		out[i] *= k
		out[n - 1 - i] *= k
	return out


func _blip(dur: float, f0: float, f1: float) -> PackedFloat32Array:
	var n := int(dur * RATE)
	var out := PackedFloat32Array()
	out.resize(n)
	var ph := 0.0
	for i in n:
		var tt := float(i) / RATE
		ph += TAU * lerpf(f0, f1, tt / dur) / RATE
		out[i] = sin(ph) * exp(-tt * 12.0) * 0.35
	return out
