extends Node
## Réseau local du mode Duel (2 téléphones sur le même Wi-Fi / point d'accès).
## - L'hôte crée un serveur ENet et s'annonce en UDP broadcast.
## - L'invité trouve les parties automatiquement, ou saisit l'adresse à la main.
## - Les deux téléphones jouent les mêmes situations (même graine aléatoire)
##   et s'échangent seulement les scores : pas de lag possible sur le jeu.

signal peer_joined
signal start(seed_value: int)
signal opp_score(goals: int)
signal opp_finished(goals: int)
signal opp_kit(k: int)
signal net_error(reason: String)

const PORT := 7777
const DISC_PORT := 7778
const MAGIC := "VIBESTRIKE_DUEL_1"

var is_host := false
var active := false
var my_kit := 0
var hosts := {}            # ip -> dernier contact (ms)
var _udp: PacketPeerUDP
var _listening := false
var _bcast_t := 0.0


func _ready() -> void:
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected)
	multiplayer.connection_failed.connect(_on_failed)
	multiplayer.server_disconnected.connect(_on_server_gone)


# ------------------------------------------------------------------ CONNEXION
func host() -> int:
	close()
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_server(PORT, 1)
	if err != OK:
		return err
	multiplayer.multiplayer_peer = peer
	is_host = true
	active = true
	_udp = PacketPeerUDP.new()
	_udp.set_broadcast_enabled(true)
	_udp.set_dest_address("255.255.255.255", DISC_PORT)
	return OK


func join(ip: String) -> int:
	_close_peer()
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_client(ip, PORT)
	if err != OK:
		return err
	multiplayer.multiplayer_peer = peer
	is_host = false
	active = true
	return OK


func start_discovery() -> void:
	stop_discovery()
	hosts.clear()
	_udp = PacketPeerUDP.new()
	if _udp.bind(DISC_PORT) == OK:
		_listening = true


func stop_discovery() -> void:
	_listening = false
	if _udp and not is_host:
		_udp.close()


func close() -> void:
	_close_peer()
	_listening = false
	if _udp:
		_udp.close()
	_udp = null
	hosts.clear()


func _close_peer() -> void:
	active = false
	is_host = false
	if multiplayer.multiplayer_peer and not (multiplayer.multiplayer_peer is OfflineMultiplayerPeer):
		multiplayer.multiplayer_peer.close()
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()


func connected() -> bool:
	return active and multiplayer.get_peers().size() > 0


func found_hosts() -> Array:
	var now := Time.get_ticks_msec()
	var out: Array = []
	for ip in hosts.keys():
		if now - int(hosts[ip]) < 3500:
			out.append(ip)
	return out


func local_ips() -> Array:
	var out: Array = []
	for a in IP.get_local_addresses():
		var s := String(a)
		if s.contains(":") or s.begins_with("127.") or s.begins_with("169.254."):
			continue
		# adresses Wi-Fi / point d'accès en premier
		if s.begins_with("192.168.") or s.begins_with("10.") or s.begins_with("172."):
			out.push_front(s)
		else:
			out.append(s)
	return out


func _process(delta: float) -> void:
	# l'hôte s'annonce tant que personne n'a rejoint
	if is_host and active and _udp and multiplayer.get_peers().is_empty():
		_bcast_t -= delta
		if _bcast_t <= 0.0:
			_bcast_t = 1.0
			_udp.put_packet(MAGIC.to_utf8_buffer())
	if _listening and _udp:
		while _udp.get_available_packet_count() > 0:
			var msg := _udp.get_packet().get_string_from_utf8()
			var ip := _udp.get_packet_ip()
			if msg == MAGIC and ip != "":
				hosts[ip] = Time.get_ticks_msec()


# ------------------------------------------------------------------ PARTIE
## Appelée par l'hôte : lance (ou relance) une manche sur les deux téléphones
func begin_match() -> void:
	if is_host and connected():
		rpc("net_start", randi())


func request_rematch() -> void:
	if is_host:
		begin_match()
	elif connected():
		rpc_id(1, "net_rematch")


func send_score(goals: int) -> void:
	if connected():
		rpc("net_score", goals)


func send_finished(goals: int) -> void:
	if connected():
		rpc("net_finished", goals)


@rpc("authority", "call_local", "reliable")
func net_start(seed_value: int) -> void:
	start.emit(seed_value)


@rpc("any_peer", "call_remote", "reliable")
func net_rematch() -> void:
	if is_host:
		begin_match()


@rpc("any_peer", "call_remote", "reliable")
func net_score(goals: int) -> void:
	opp_score.emit(goals)


@rpc("any_peer", "call_remote", "reliable")
func net_finished(goals: int) -> void:
	opp_finished.emit(goals)


@rpc("any_peer", "call_remote", "reliable")
func net_kit(k: int) -> void:
	opp_kit.emit(k)


# ------------------------------------------------------------------ SIGNAUX
func _on_peer_connected(_id: int) -> void:
	rpc("net_kit", my_kit)
	if is_host:
		peer_joined.emit()


func _on_connected() -> void:
	stop_discovery()


func _on_peer_disconnected(_id: int) -> void:
	if active:
		net_error.emit("L'adversaire s'est déconnecté")


func _on_failed() -> void:
	if active:
		active = false
		net_error.emit("Connexion impossible")


func _on_server_gone() -> void:
	if active:
		active = false
		net_error.emit("L'hôte a quitté la partie")
