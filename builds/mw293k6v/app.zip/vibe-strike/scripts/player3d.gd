extends Node3D
## Joueur 3D : modèle humain riggé + animations capturées (repos / marche / course).
## Frappe et plongeon du gardien ajoutés en procédural sur le squelette.
## Si tu remplaces assets/models/player.glb par un modèle Mixamo qui contient
## des animations nommées "kick" ou "dive", elles sont utilisées automatiquement.

const MODEL := preload("res://assets/models/player.glb")

var model: Node3D
var ap: AnimationPlayer
var sk: Skeleton3D
var cur := ""
var kick_t := -1.0
var dive := 0.0          # -1 (gauche) .. 1 (droite), pour le gardien
var ring: MeshInstance3D
var _b_rup := -1
var _b_rleg := -1
var _b_lup := -1
var _b_spine := -1
var _b_larm := -1
var _b_rarm := -1
var _has_kick := false


func _ready() -> void:
	model = MODEL.instantiate()
	add_child(model)
	ap = model.find_child("AnimationPlayer", true, false) as AnimationPlayer
	for n in model.find_children("*", "Skeleton3D", true, false):
		sk = n as Skeleton3D
	if ap:
		ap.callback_mode_process = AnimationMixer.ANIMATION_CALLBACK_MODE_PROCESS_MANUAL
		for a in ["idle", "walk", "run"]:
			if ap.has_animation(a):
				ap.get_animation(a).loop_mode = Animation.LOOP_LINEAR
		_has_kick = ap.has_animation("kick")
	if sk:
		_b_rup = sk.find_bone("mixamorig_RightUpLeg")
		_b_rleg = sk.find_bone("mixamorig_RightLeg")
		_b_lup = sk.find_bone("mixamorig_LeftUpLeg")
		_b_spine = sk.find_bone("mixamorig_Spine")
		_b_larm = sk.find_bone("mixamorig_LeftArm")
		_b_rarm = sk.find_bone("mixamorig_RightArm")
	play("idle")
	if ap and ap.has_animation("idle"):
		ap.seek(randf() * 2.0, true)
	# anneau au sol (joueur sélectionnable / porteur du ballon)
	ring = MeshInstance3D.new()
	var tm := TorusMesh.new()
	tm.inner_radius = 0.55
	tm.outer_radius = 0.68
	tm.rings = 32
	ring.mesh = tm
	ring.scale = Vector3(1, 0.08, 1)
	ring.position.y = 0.03
	var rm := StandardMaterial3D.new()
	rm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	rm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	rm.albedo_color = Color(1, 1, 1, 0.85)
	ring.material_override = rm
	ring.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	ring.visible = false
	add_child(ring)


func set_colors(main: Color, accent: Color) -> void:
	for n in model.find_children("*", "MeshInstance3D", true, false):
		var mi := n as MeshInstance3D
		var m := StandardMaterial3D.new()
		m.roughness = 0.55
		m.metallic = 0.05
		m.albedo_color = accent if String(mi.name).contains("Joint") else main
		mi.material_override = m


func set_ring(on: bool, col: Color = Color.WHITE) -> void:
	ring.visible = on
	(ring.material_override as StandardMaterial3D).albedo_color = col


func play(anim: String, speed: float = 1.0) -> void:
	if not ap or not ap.has_animation(anim):
		return
	ap.speed_scale = speed
	if cur != anim:
		cur = anim
		ap.play(anim, 0.25)


func kick() -> void:
	kick_t = 0.0
	if _has_kick:
		cur = "kick"
		ap.play("kick", 0.1)


func tick(delta: float) -> void:
	if ap:
		ap.advance(delta)
	if not sk:
		return
	# --- frappe procédurale : armé de la jambe droite puis fouetté vers l'avant
	if kick_t >= 0.0:
		kick_t += delta
		var u := kick_t / 0.5
		if u >= 1.0:
			kick_t = -1.0
			if _has_kick:
				cur = ""
		elif not _has_kick:
			var ang := 0.0
			if u < 0.4:
				ang = -55.0 * sin(u / 0.4 * PI * 0.5)          # armé
			else:
				ang = lerpf(-55.0, 80.0, minf(1.0, (u - 0.4) / 0.25))  # frappe
				if u > 0.7:
					ang = lerpf(80.0, 0.0, (u - 0.7) / 0.3)    # retour
			_rot(_b_rup, Vector3.RIGHT, -ang)
			_rot(_b_rleg, Vector3.RIGHT, clampf(-ang, 0.0, 60.0) if u < 0.55 else 0.0)
			_rot(_b_spine, Vector3.RIGHT, 8.0 * sin(u * PI))
			_rot(_b_larm, Vector3.FORWARD, 35.0 * sin(u * PI))
	# --- plongeon du gardien : bras tendus
	if absf(dive) > 0.05:
		_rot(_b_larm, Vector3.FORWARD, 70.0 * absf(dive))
		_rot(_b_rarm, Vector3.FORWARD, -70.0 * absf(dive))
	model.rotation.z = -dive * 1.25
	model.position = Vector3(dive * 0.7, absf(dive) * 0.55, 0)


func _rot(bone: int, axis: Vector3, deg: float) -> void:
	if bone < 0:
		return
	var q := sk.get_bone_pose_rotation(bone)
	sk.set_bone_pose_rotation(bone, q * Quaternion(axis, deg_to_rad(deg)))
