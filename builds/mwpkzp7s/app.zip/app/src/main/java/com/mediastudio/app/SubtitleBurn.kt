package com.mediastudio.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.common.OverlaySettings
import androidx.media3.common.StaticOverlaySettings
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import com.google.common.collect.ImmutableList
import com.mediastudio.app.whisper.Cue
import com.mediastudio.app.whisper.Subtitles
import java.io.File
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

// ═══════════════════════════ Style des sous-titres ═══════════════════════════

internal enum class SubPreset(
    val label: String, val text: Int, val outline: Int, val box: Int?, val glow: Boolean = false,
) {
    CLASSIC("Classique", 0xFFFFFFFF.toInt(), 0xFF000000.toInt(), null),
    BOX("Boîte noire", 0xFFFFFFFF.toInt(), 0x00000000, 0xB8000000.toInt()),
    YELLOW("Jaune ciné", 0xFFFFE14D.toInt(), 0xFF111111.toInt(), null),
    GOLD("Doré DL VIBE", 0xFFF2C75C.toInt(), 0xFF2A1C05.toInt(), 0xD9100B04.toInt()),
    NEON("Néon", 0xFF6FF6FF.toInt(), 0xFF003A42.toInt(), null, glow = true),
    PINK("Rose pop", 0xFFFFFFFF.toInt(), 0x00000000, 0xE6E0337A.toInt()),
}

internal enum class SubSize(val label: String, val factor: Float) {
    S("Petit", 0.040f), M("Moyen", 0.050f), L("Grand", 0.062f), XL("Très grand", 0.076f),
}

/** anchorY : point du cadre vidéo (-1 bas … 1 haut) ; overlayY : point du bloc de texte posé dessus. */
internal enum class SubPosition(val label: String, val anchorY: Float, val overlayY: Float) {
    BOTTOM("Bas", -0.86f, -1f), MIDDLE("Milieu", 0f, 0f), TOP("Haut", 0.86f, 1f),
}

internal enum class SubFont(val label: String, val fam: FontKit.Fam) {
    SANS("Arial", FontKit.Fam.SANS), MODERN("Calibri", FontKit.Fam.CARLITO),
    SERIF("Times", FontKit.Fam.SERIF), MONO("Mono", FontKit.Fam.MONO),
}

internal data class SubtitleStyle(
    val preset: SubPreset = SubPreset.CLASSIC,
    val size: SubSize = SubSize.M,
    val position: SubPosition = SubPosition.BOTTOM,
    val font: SubFont = SubFont.SANS,
    val bold: Boolean = true,
    val uppercase: Boolean = false,
)

// ═══════════════════════════ Rendu (identique à l'aperçu et à l'export) ═══════════════════════════

internal object SubtitleRenderer {

    /** Dessine [text] pour une image de [frameW]×[frameH] pixels ; le bloc est centré, prêt à poser. */
    fun render(text: String, style: SubtitleStyle, frameW: Int, frameH: Int): Bitmap {
        val p = style.preset
        val t = if (style.uppercase) text.uppercase() else text
        val textPx = max(12f, min(frameW, frameH) * style.size.factor)
        val face = FontKit.typeface(style.font.fam, style.bold, false)

        val fill = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = textPx
            typeface = face
            color = p.text
            when {
                p.glow -> setShadowLayer(textPx * 0.45f, 0f, 0f, p.text)
                p.box == null -> setShadowLayer(textPx * 0.10f, 0f, textPx * 0.05f, 0xAA000000.toInt())
            }
        }
        val hasOutline = (p.outline ushr 24) != 0
        val stroke = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = textPx
            typeface = face
            color = p.outline
            this.style = Paint.Style.STROKE
            strokeWidth = textPx * if (p.box == null) 0.16f else 0.08f
            strokeJoin = Paint.Join.ROUND
        }

        val maxW = max(40, (frameW * 0.86f).toInt())
        fun layout(paint: TextPaint) = StaticLayout.Builder.obtain(t, 0, t.length, paint, maxW)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setLineSpacing(0f, 1.04f)
            .setIncludePad(true)
            .build()
        val lf = layout(fill)
        var lineW = 0f
        for (i in 0 until lf.lineCount) lineW = max(lineW, lf.getLineWidth(i))

        val padH = if (p.box != null) textPx * 0.55f else textPx * 0.35f
        val padV = if (p.box != null) textPx * 0.25f else textPx * 0.20f
        val w = ceil(lineW + 2 * padH).toInt().coerceAtLeast(2)
        val h = ceil(lf.height + 2 * padV).toInt().coerceAtLeast(2)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        p.box?.let { boxColor ->
            val r = textPx * 0.32f
            c.drawRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), r, r, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = boxColor })
        }
        c.translate(w / 2f - maxW / 2f, padV)
        if (hasOutline) layout(stroke).draw(c)
        lf.draw(c)
        return bmp
    }
}

/** Calque Media3 : affiche, image par image, le sous-titre correspondant à l'instant de la vidéo. */
@UnstableApi
internal class SubtitleOverlay(
    private val cues: List<Cue>, private val style: SubtitleStyle, private val frameW: Int, private val frameH: Int,
) : BitmapOverlay() {
    private val empty = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
    private var lastIndex = Int.MIN_VALUE
    private var last: Bitmap = empty
    private val settings = StaticOverlaySettings.Builder()
        .setBackgroundFrameAnchor(0f, style.position.anchorY)
        .setOverlayFrameAnchor(0f, style.position.overlayY)
        .build()

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val i = Subtitles.indexAt(cues, presentationTimeUs / 1000)
        if (i != lastIndex) {
            lastIndex = i
            last = if (i < 0) empty else SubtitleRenderer.render(cues[i].text, style, frameW, frameH)
        }
        return last
    }

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings = settings
}

@UnstableApi
internal object SubtitleBurner {

    /** Taille d'affichage (rotation appliquée) : c'est le cadre que voient les effets Media3. */
    fun displaySize(ctx: Context, video: Uri): Pair<Int, Int> {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, video)
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot % 180 != 0) h to w else w to h
        } catch (_: Exception) {
            0 to 0
        } finally {
            r.release()
        }
    }

    /** Incruste les sous-titres dans l'image (H.264 + AAC) ; le son d'origine est conservé. */
    suspend fun burn(
        ctx: Context, video: Uri, cues: List<Cue>, style: SubtitleStyle, output: File, onProgress: (Float) -> Unit,
    ) {
        require(cues.isNotEmpty()) { "Aucun sous-titre à incruster." }
        FontKit.init(ctx)
        val (w, h) = displaySize(ctx, video)
        require(w > 0 && h > 0) { "Cette vidéo n'a pas de piste image : impossible d'y incruster des sous-titres." }
        val overlay = SubtitleOverlay(cues.sortedBy { it.startMs }, style, w, h)
        val effects = listOf<Effect>(OverlayEffect(ImmutableList.of<TextureOverlay>(overlay)))
        val item = EditedMediaItem.Builder(MediaItem.fromUri(video))
            .setRemoveAudio(false)
            .setEffects(Effects(emptyList(), effects))
            .build()
        VideoOps.runSingle(ctx, item, output, onProgress)
    }
}
