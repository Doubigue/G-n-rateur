package com.linguavibe.app.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.OutputStream

/**
 * Renvoie une fonction « exporter(nomDuFichier, écriture) » : le téléphone demande où enregistrer le PDF
 * (aucune permission nécessaire), puis le PDF est généré en arrière-plan et écrit à cet endroit.
 */
@Composable
fun rememberPdfExporter(): (String, (OutputStream) -> Unit) -> Unit {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pending by remember { mutableStateOf<((OutputStream) -> Unit)?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val job = pending
        pending = null
        if (uri != null && job != null) {
            Toast.makeText(context, "Création du PDF… (un cours complet peut prendre quelques secondes)", Toast.LENGTH_LONG).show()
            scope.launch {
                val ok = withContext(Dispatchers.IO) {
                    try {
                        val stream = context.contentResolver.openOutputStream(uri)
                        if (stream == null) false else {
                            stream.use { job(it) }
                            true
                        }
                    } catch (e: Throwable) {
                        false
                    }
                }
                Toast.makeText(
                    context,
                    if (ok) "PDF enregistré" else "Impossible de créer le PDF",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }
    return { name, job ->
        pending = job
        launcher.launch(name)
    }
}

/** Bouton « PDF » à placer dans la barre du haut. */
@Composable
fun PdfTopButton(onClick: () -> Unit) {
    Row(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(Color.White.copy(alpha = 0.18f))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        LineIcon(Art.icDownload, Color.White, 18.dp, accent = Gold)
        Text("PDF", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}
