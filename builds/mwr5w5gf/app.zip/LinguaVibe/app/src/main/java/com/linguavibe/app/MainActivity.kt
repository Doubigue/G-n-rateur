package com.linguavibe.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.lifecycleScope
import com.linguavibe.app.data.FirebaseSync
import kotlinx.coroutines.launch
import com.linguavibe.app.data.ProgressStore
import com.linguavibe.app.speech.Speaker
import com.linguavibe.app.speech.VoskManager
import com.linguavibe.app.ui.AppRoot
import com.linguavibe.app.ui.LinguaTheme
import com.linguavibe.app.ui.SplashScreen
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue

class MainActivity : ComponentActivity() {
    private lateinit var speaker: Speaker

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        speaker = Speaker(this)
        // Téléchargements de voix interrompus : ils réapparaissent « en pause », prêts à reprendre.
        com.linguavibe.app.speech.NeuralVoices.restore(this)
        val progress = ProgressStore(this)
        // Rappels du lexique : canal de notification et reprogrammation à l'heure choisie.
        com.linguavibe.app.lexique.LexiqueReminder.createChannel(this)
        com.linguavibe.app.lexique.LexiqueReminder.schedule(this)
        // Mise à jour discrète des cours depuis Firebase (s'il est configuré et qu'il y a du réseau).
        if (savedInstanceState == null && FirebaseSync.autoSync(this) && FirebaseSync.loadConfig(this).isComplete) {
            lifecycleScope.launch {
                try {
                    FirebaseSync.sync(applicationContext)
                } catch (_: Exception) {
                    // Hors ligne : on garde les cours déjà enregistrés.
                }
            }
        }
        setContent {
            LinguaTheme {
                var splash by rememberSaveable { mutableStateOf(true) }
                Crossfade(targetState = splash, animationSpec = tween(300), label = "splash") { show ->
                    if (show) SplashScreen { splash = false } else AppRoot(speaker, progress)
                }
            }
        }
    }

    override fun onStop() {
        super.onStop()
        // On libère le micro quand l'application passe en arrière-plan.
        VoskManager.cancel()
        speaker.stop()
    }

    override fun onDestroy() {
        speaker.shutdown()
        super.onDestroy()
    }
}
