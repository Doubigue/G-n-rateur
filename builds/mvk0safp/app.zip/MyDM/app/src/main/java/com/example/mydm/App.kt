package com.example.mydm

import android.app.Application
import androidx.room.Room
import com.example.mydm.core.AppDb
import com.example.mydm.downloader.DownloadEngine
import com.example.mydm.torrent.TorrentEngine
import com.example.mydm.whatsapp.StatusRepository

class App : Application() {
    lateinit var db: AppDb
    lateinit var downloadEngine: DownloadEngine
    lateinit var torrentEngine: TorrentEngine
    lateinit var statusRepo: StatusRepository

    override fun onCreate() {
        super.onCreate()
        db = Room.databaseBuilder(this, AppDb::class.java, "mydm.db").build()
        downloadEngine = DownloadEngine(this, db.downloadDao())
        torrentEngine = TorrentEngine(this)
        statusRepo = StatusRepository(this)
    }
}
