package com.example.mydm.ui

import android.content.Intent
import android.net.Uri
import android.util.Size
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.mydm.App
import com.example.mydm.browser.SnifferWebView
import com.example.mydm.core.*
import com.example.mydm.downloader.DownloadService
import com.example.mydm.torrent.TorrentFile
import com.example.mydm.torrent.TorrentService
import com.example.mydm.whatsapp.StatusItem
import com.example.mydm.whatsapp.WaApp
import com.frostwire.jlibtorrent.TorrentInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable private fun app() = LocalContext.current.applicationContext as App

// ───────────── Navigateur ─────────────
@Composable
fun BrowserScreen() {
    val ctx = LocalContext.current
    val app = app()
    val scope = rememberCoroutineScope()
    val web = remember { SnifferWebView(ctx).apply { loadUrl("https://www.google.com") } }
    var address by remember { mutableStateOf("") }
    val found = remember { mutableStateListOf<DetectedMedia>() }

    LaunchedEffect(web) {
        web.onUrlChanged = { address = it }
        web.detectedMedia.collect { found.add(0, it) }
    }
    DisposableEffect(Unit) { onDispose { web.destroy() } }

    fun go() {
        val t = address.trim()
        web.loadUrl(if (t.startsWith("http")) t else if ("." in t && " " !in t) "https://$t"
            else "https://www.google.com/search?q=${Uri.encode(t)}")
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton({ if (web.canGoBack()) web.goBack() }) { Text("◀") }
            OutlinedTextField(address, { address = it }, Modifier.weight(1f), singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { go() }))
            TextButton({ web.reload() }) { Text("⟳") }
        }
        Box(Modifier.weight(1f)) {
            AndroidView({ web }, Modifier.fillMaxSize())
            if (found.isNotEmpty()) {
                Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(10.dp).glass()) {
                    Row(Modifier.padding(start = 12.dp, top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${found.size} média(s) détecté(s)", color = Accent, modifier = Modifier.weight(1f))
                        TextButton({ found.clear() }) { Text("Vider") }
                    }
                    LazyColumn(Modifier.heightIn(max = 200.dp)) {
                        items(found.toList()) { m ->
                            Row(Modifier.fillMaxWidth().clickable {
                                if (m.type == MediaType.HLS) {
                                    Toast.makeText(ctx, "HLS (.m3u8) non supporté dans cette version", Toast.LENGTH_SHORT).show()
                                } else scope.launch {
                                    val id = app.downloadEngine.enqueue(m)
                                    DownloadService.start(ctx, id)
                                    found.remove(m)
                                    Toast.makeText(ctx, "Téléchargement ajouté", Toast.LENGTH_SHORT).show()
                                }
                            }.padding(12.dp)) {
                                Text(m.type.name, color = Accent, modifier = Modifier.width(76.dp), fontSize = 12.sp)
                                Text(m.url, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ───────────── Téléchargements ─────────────
@Composable
fun DownloadsScreen() {
    val ctx = LocalContext.current; val app = app()
    val tasks by app.db.downloadDao().observeTasks().collectAsStateWithLifecycle(emptyList())
    val progress by app.downloadEngine.progress.collectAsStateWithLifecycle()

    if (tasks.isEmpty()) { Centered("Aucun téléchargement") ; return }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(tasks, key = { it.id }) { t ->
            val p = progress[t.id]
            val total = p?.total ?: t.totalBytes
            val frac = if (t.status == Status.COMPLETED) 1f else if (p != null && total > 0) p.downloaded.toFloat() / total else 0f
            Column(Modifier.fillMaxWidth().glass().padding(14.dp)) {
                Text(t.fileName, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                LinearProgressIndicator({ frac }, Modifier.fillMaxWidth().padding(vertical = 8.dp))
                Text("${t.status} • ${(frac * 100).toInt()}%" + (p?.let { " • ${it.speedBps / 1024} Ko/s" } ?: "") +
                    (t.error?.let { " • $it" } ?: ""), color = Muted, fontSize = 12.sp)
                Row {
                    when (t.status) {
                        Status.RUNNING, Status.QUEUED -> TextButton({
                            ctx.startService(Intent(ctx, DownloadService::class.java)
                                .setAction(DownloadService.ACTION_PAUSE).putExtra(DownloadService.EXTRA_ID, t.id))
                        }) { Text("Pause") }
                        Status.PAUSED, Status.FAILED -> TextButton({ DownloadService.start(ctx, t.id) }) { Text("Reprendre") }
                        Status.COMPLETED -> TextButton({
                            t.resultUri?.let { u ->
                                val uri = Uri.parse(u)
                                runCatching {
                                    ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, ctx.contentResolver.getType(uri))
                                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
                                }
                            }
                        }) { Text("Ouvrir") }
                        else -> {}
                    }
                    TextButton({ app.downloadEngine.cancel(t.id) }) { Text("Supprimer") }
                }
            }
        }
    }
}

// ───────────── Statuts WhatsApp ─────────────
@Composable
fun StatusScreen() {
    val ctx = LocalContext.current; val repo = app().statusRepo
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf(WaApp.WHATSAPP) }
    var statuses by remember { mutableStateOf<List<StatusItem>>(emptyList()) }
    var granted by remember { mutableStateOf(repo.hasGrant(tab)) }
    var reload by remember { mutableIntStateOf(0) }

    LaunchedEffect(tab, reload) {
        granted = repo.hasGrant(tab)
        statuses = if (granted) repo.list(tab) else emptyList()
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) { repo.persistGrant(tab, uri); reload++ }
    }

    Column(Modifier.fillMaxSize()) {
        TabRow(WaApp.entries.indexOf(tab), containerColor = Bg) {
            WaApp.entries.forEach { a -> Tab(tab == a, { tab = a }, text = { Text(a.label) }) }
        }
        if (!granted) {
            Centered("Autorisez l'accès au dossier Android/media/${tab.pkg}\n(appuyez sur « Utiliser ce dossier »)") {
                Button({ picker.launch(repo.initialUri(tab)) }) { Text("Autoriser l'accès") }
            }
        } else if (statuses.isEmpty()) {
            Centered("Aucun statut trouvé.\nVisionnez d'abord des statuts dans WhatsApp.") {
                Button({ reload++ }) { Text("Actualiser") }
            }
        } else LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(statuses, key = { it.uri.toString() }) { s ->
                val thumb by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, s.uri) {
                    value = withContext(Dispatchers.IO) {
                        runCatching { ctx.contentResolver.loadThumbnail(s.uri, Size(256, 256), null).asImageBitmap() }.getOrNull()
                    }
                }
                Row(Modifier.fillMaxWidth().glass().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(72.dp).background(Color(0x22FFFFFF))) {
                        thumb?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
                    }
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text(if (s.isVideo) "Vidéo" else "Photo", color = Accent)
                        Text("${s.size / 1024} Ko", color = Muted, fontSize = 12.sp)
                    }
                    Button({
                        scope.launch {
                            runCatching { repo.save(s) }
                                .onSuccess { Toast.makeText(ctx, "Enregistré dans Download/Statuses", Toast.LENGTH_SHORT).show() }
                                .onFailure { Toast.makeText(ctx, "Échec : ${it.message}", Toast.LENGTH_LONG).show() }
                        }
                    }) { Text("Enregistrer") }
                }
            }
        }
    }
}

// ───────────── Torrent ─────────────
@Composable
fun TorrentScreen() {
    val ctx = LocalContext.current; val engine = app().torrentEngine
    val scope = rememberCoroutineScope()
    val states by engine.states.collectAsStateWithLifecycle()
    var source by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<TorrentInfo?>(null) }
    var files by remember { mutableStateOf<List<TorrentFile>>(emptyList()) }
    var selected by remember { mutableStateOf<Set<Int>>(emptySet()) }

    fun inspect(src: String) = scope.launch {
        busy = true
        runCatching { engine.inspect(src) }
            .onSuccess { ti -> pending = ti; files = engine.listFiles(ti); selected = files.map { it.index }.toSet() }
            .onFailure { Toast.makeText(ctx, "Erreur : ${it.message}", Toast.LENGTH_LONG).show() }
        busy = false
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { inspect(it.toString()) }
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Column(Modifier.fillMaxWidth().glass().padding(14.dp)) {
                OutlinedTextField(source, { source = it }, Modifier.fillMaxWidth(), label = { Text("Lien magnet:?xt=urn:btih:…") })
                Row {
                    Button({ inspect(source.trim()) }, enabled = source.startsWith("magnet:") && !busy) { Text("Analyser") }
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton({ picker.launch(arrayOf("*/*")) }, enabled = !busy) { Text("Fichier .torrent") }
                }
                if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))
            }
        }
        pending?.let { ti ->
            item {
                Column(Modifier.fillMaxWidth().glass().padding(14.dp)) {
                    Text(ti.name(), color = Color.White)
                    files.forEach { f ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(f.index in selected, { c -> selected = if (c) selected + f.index else selected - f.index })
                            Text("${f.path}  (${f.size / 1_048_576} Mo)", color = Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
                        }
                    }
                    Button({
                        engine.download(ti, selected); TorrentService.start(ctx); pending = null
                    }, enabled = selected.isNotEmpty()) { Text("Télécharger") }
                }
            }
        }
        items(states.values.toList(), key = { it.infoHash }) { s ->
            Column(Modifier.fillMaxWidth().glass().padding(14.dp)) {
                Text(s.name, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                LinearProgressIndicator({ s.progress }, Modifier.fillMaxWidth().padding(vertical = 8.dp))
                Text("${(s.progress * 100).toInt()}% • ${s.state} • ↓ ${s.downloadRate / 1024} Ko/s • ↑ ${s.uploadRate / 1024} Ko/s • ${s.peers} pairs",
                    color = Muted, fontSize = 12.sp)
                Row {
                    TextButton({ engine.pause(s.infoHash) }) { Text("Pause") }
                    TextButton({ engine.resume(s.infoHash) }) { Text("Reprendre") }
                    TextButton({ engine.remove(s.infoHash) }) { Text("Retirer") }
                }
            }
        }
    }
}

@Composable
private fun Centered(text: String, extra: @Composable () -> Unit = {}) =
    Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Text(text, color = Muted); Spacer(Modifier.height(12.dp)); extra()
    }
