package com.example.mydm.whatsapp

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class WaApp(val label: String, val pkg: String, val rootFolders: List<String>) {
    WHATSAPP("WhatsApp", "com.whatsapp", listOf("WhatsApp")),
    BUSINESS("WhatsApp Business", "com.whatsapp.w4b", listOf("WhatsApp Business", "WhatsApp"))
}

data class StatusItem(val uri: Uri, val name: String, val mime: String, val size: Long, val modified: Long) {
    val isVideo get() = mime.startsWith("video/")
}

class StatusRepository(private val context: Context) {
    private val prefs = context.getSharedPreferences("wa", Context.MODE_PRIVATE)

    fun initialUri(app: WaApp): Uri = DocumentsContract.buildDocumentUri(
        "com.android.externalstorage.documents", "primary:Android/media/${app.pkg}")

    fun persistGrant(app: WaApp, treeUri: Uri) {
        context.contentResolver.takePersistableUriPermission(treeUri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        prefs.edit().putString(app.pkg, treeUri.toString()).apply()
    }

    fun hasGrant(app: WaApp) = prefs.getString(app.pkg, null) != null

    suspend fun list(app: WaApp): List<StatusItem> = withContext(Dispatchers.IO) {
        val tree = prefs.getString(app.pkg, null)?.let(Uri::parse) ?: return@withContext emptyList()
        val root = DocumentFile.fromTreeUri(context, tree) ?: return@withContext emptyList()
        val statuses = if (root.name == ".Statuses") root else
            app.rootFolders.firstNotNullOfOrNull { f -> root.findFile(f)?.findFile("Media")?.findFile(".Statuses") }
        statuses?.listFiles().orEmpty()
            .filter { it.isFile && it.type?.let { t -> t.startsWith("image/") || t.startsWith("video/") } == true }
            .map { StatusItem(it.uri, it.name ?: "status", it.type!!, it.length(), it.lastModified()) }
            .sortedByDescending { it.modified }
    }

    suspend fun save(item: StatusItem): Uri = withContext(Dispatchers.IO) {
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, item.name)
            put(MediaStore.Downloads.MIME_TYPE, item.mime)
            put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/Statuses")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val resolver = context.contentResolver
        val dest = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)!!
        resolver.openInputStream(item.uri)!!.use { i -> resolver.openOutputStream(dest)!!.use { o -> i.copyTo(o) } }
        resolver.update(dest, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
        dest
    }
}
