package com.example.mydm.browser

import android.content.Context
import android.graphics.Bitmap
import android.webkit.*
import com.example.mydm.core.DetectedMedia
import com.example.mydm.core.MediaDetector
import com.example.mydm.core.MediaType
import kotlinx.coroutines.flow.MutableSharedFlow
import java.util.concurrent.ConcurrentHashMap

object SnifferScript {
    const val JS = """
(function(){
  if (window.__sniffer) return; window.__sniffer = true;
  const seen = new Set();
  const exts = /\.(mp4|webm|mkv|m3u8|mp3|m4a|apk|pdf|zip|rar)(\?|#|${'$'})/i;
  function send(u, kind){
    try { u = new URL(u, location.href).href; } catch(e){ return; }
    if (u.startsWith('blob:') || u.startsWith('data:') || seen.has(u)) return;
    seen.add(u); SnifferBridge.report(u, kind, document.title || '');
  }
  function scan(){
    document.querySelectorAll('video,audio').forEach(function(m){
      if (m.currentSrc) send(m.currentSrc,'media'); if (m.src) send(m.src,'media');
      m.querySelectorAll('source').forEach(function(s){ if (s.src) send(s.src,'media'); });
    });
    document.querySelectorAll('a[href]').forEach(function(a){ if (exts.test(a.href)) send(a.href,'link'); });
  }
  scan();
  new MutationObserver(scan).observe(document.documentElement,
    {childList:true, subtree:true, attributes:true, attributeFilter:['src','href']});
  document.addEventListener('play', function(e){ if (e.target && e.target.currentSrc) send(e.target.currentSrc,'media'); }, true);
  const xo = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function(m,u){ if (exts.test(u)) send(u,'xhr'); return xo.apply(this, arguments); };
  const f = window.fetch;
  window.fetch = function(i){ var u=(typeof i==='string')?i:(i&&i.url); if (u&&exts.test(u)) send(u,'fetch'); return f.apply(this, arguments); };
})();
"""
}

class JsBridge(private val onFound: (String, String, String) -> Unit) {
    @JavascriptInterface fun report(url: String, kind: String, title: String) = onFound(url, kind, title)
}

class SnifferWebViewClient(
    private val events: MutableSharedFlow<DetectedMedia>,
    private val userAgent: () -> String
) : WebViewClient() {
    private val seen = ConcurrentHashMap.newKeySet<String>()
    @Volatile var currentPage: String? = null
    @Volatile var currentTitle: String? = null
    var onUrlChanged: (String) -> Unit = {}

    override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
        currentPage = url; seen.clear(); onUrlChanged(url)
    }
    override fun onPageFinished(view: WebView, url: String) {
        currentTitle = view.title
        view.evaluateJavascript(SnifferScript.JS, null)
    }
    // Thread d'arrière-plan : ne pas toucher à la View
    override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
        val url = request.url.toString()
        MediaDetector.detect(url)?.let { emit(url, it) }
        return null
    }
    fun emit(url: String, type: MediaType) {
        if (!seen.add(url)) return
        events.tryEmit(DetectedMedia(url, type, currentPage, currentTitle, userAgent(),
            CookieManager.getInstance().getCookie(url), currentPage))
    }
}

class SnifferWebView(context: Context) : WebView(context) {
    val detectedMedia = MutableSharedFlow<DetectedMedia>(extraBufferCapacity = 64)
    private val client = SnifferWebViewClient(detectedMedia) { settings.userAgentString }
    var onUrlChanged: (String) -> Unit
        get() = client.onUrlChanged
        set(v) { client.onUrlChanged = v }

    init {
        settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
        webViewClient = client
        addJavascriptInterface(JsBridge { url, kind, _ ->
            val type = MediaDetector.detect(url) ?: if (kind == "media") MediaType.VIDEO else return@JsBridge
            client.emit(url, type)
        }, "SnifferBridge")
        setDownloadListener { url, _, _, mime, _ ->
            val type = MediaDetector.detect(url)
                ?: if (mime?.startsWith("video") == true) MediaType.VIDEO else MediaType.ARCHIVE
            client.emit(url, type)
        }
    }
}
