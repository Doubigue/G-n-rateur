package com.example.mydm.downloader

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.mydm.App
import kotlinx.coroutines.*

class DownloadService : Service() {
    private val engine get() = (application as App).downloadEngine
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    @Volatile private var started = false

    override fun onBind(i: Intent?) = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Téléchargements", NotificationManager.IMPORTANCE_LOW))
        startForeground(NOTIF_ID, notif("Préparation…", 0, true), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        scope.launch {
            while (isActive) {
                delay(1000)
                val map = engine.progress.value
                val done = map.values.sumOf { it.downloaded }; val total = map.values.sumOf { it.total }
                val speed = map.values.sumOf { it.speedBps }
                val pct = if (total > 0) (done * 100 / total).toInt() else 0
                nm.notify(NOTIF_ID, notif("${engine.activeCount} tâche(s) • ${speed / 1024} Ko/s", pct, total <= 0))
                if (started && engine.activeCount == 0) stopSelf()
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val id = intent?.getStringExtra(EXTRA_ID)
        when (intent?.action) {
            ACTION_START -> id?.let { engine.start(it); started = true }
            ACTION_PAUSE -> id?.let(engine::pause)
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() { scope.cancel() }

    private fun notif(text: String, pct: Int, indeterminate: Boolean) =
        NotificationCompat.Builder(this, CH).setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("MyDM").setContentText(text)
            .setProgress(100, pct, indeterminate).setOngoing(true).build()

    companion object {
        const val CH = "downloads"; const val NOTIF_ID = 42
        const val ACTION_START = "start"; const val ACTION_PAUSE = "pause"; const val EXTRA_ID = "id"
        fun start(ctx: Context, taskId: String) = ContextCompat.startForegroundService(
            ctx, Intent(ctx, DownloadService::class.java).setAction(ACTION_START).putExtra(EXTRA_ID, taskId))
    }
}
