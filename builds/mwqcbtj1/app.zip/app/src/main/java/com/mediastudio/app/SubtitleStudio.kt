package com.mediastudio.app

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.mediastudio.app.whisper.Cue
import com.mediastudio.app.whisper.Subtitles
import com.mediastudio.app.whisper.WhisperEngine
import com.mediastudio.app.whisper.WhisperModels
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

/** Palette du studio : nuit violette + or DL VIBE. */
private object SP {
    val Bg = Color(0xFF0D0A12)
    val Card = Color(0xFF17131F)
    val Card2 = Color(0xFF211B2B)
    val Line = Color(0xFF2E2639)
    val Gold = Color(0xFFF2C75C)
    val GoldDeep = Color(0xFFB7862C)
    val Violet = Color(0xFF8B5CF6)
    val Teal = Color(0xFF2DD4BF)
    val Green = Color(0xFF35C98A)
    val Red = Color(0xFFFF5A6E)
    val Text = Color(0xFFF6F2FB)
    val Muted = Color(0xFFA89EB7)
    val goldBrush = Brush.linearGradient(listOf(Color(0xFFFFE08A), Gold, GoldDeep))
}

private val darkScheme = darkColorScheme(
    primary = SP.Gold, onPrimary = Color(0xFF1C1405), secondary = SP.Violet, background = SP.Bg,
    surface = SP.Card, onSurface = SP.Text, surfaceVariant = SP.Card2, onSurfaceVariant = SP.Muted,
    outline = SP.Line, error = SP.Red,
)

/**
 * Studio sous-titres : vidéo → transcription Whisper hors ligne (horodatée) → SRT + TXT →
 * aperçu stylé sur la vidéo → incrustation.
 *
 * @param routerMode ouvert depuis LinkShare : un bouton renvoie le résultat ([onDeliver]).
 * @param initialSource fichier reçu (LinkShare) à ouvrir directement.
 */
@UnstableApi
@Composable
internal fun SubtitleStudioScreen(
    modifier: Modifier = Modifier,
    routerMode: Boolean = false,
    initialSource: Uri? = null,
    initialSubtitles: Uri? = null,
    destinationTreeUri: Uri? = null,
    onClose: (() -> Unit)? = null,
    onDeliver: ((uri: Uri, name: String, summary: String?) -> Unit)? = null,
) = MaterialTheme(colorScheme = darkScheme) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val st by ExportManager.state.collectAsState()
    val src by SubtitleSession.source.collectAsState()
    val phase by SubtitleSession.phase.collectAsState()
    val cues by SubtitleSession.cues.collectAsState()
    val options by SubtitleSession.options.collectAsState()
    val style by SubtitleSession.style.collectAsState()
    val srtUri by SubtitleSession.srtUri.collectAsState()
    val txtUri by SubtitleSession.txtUri.collectAsState()
    val burnedUri by SubtitleSession.burnedUri.collectAsState()
    val language by SubtitleSession.language.collectAsState()
    val message by SubtitleSession.message.collectAsState()
    val snackbar = remember { SnackbarHostState() }

    var models by remember { mutableStateOf(WhisperModels.list(ctx)) }
    var model by remember { mutableStateOf(WhisperModels.selected(ctx)) }
    var showModels by remember { mutableStateOf(false) }
    var importProgress by remember { mutableStateOf<Float?>(null) }
    fun refreshModels() { models = WhisperModels.list(ctx); model = WhisperModels.selected(ctx) }

    LaunchedEffect(st) { SubtitleSession.reconcile(st) }
    LaunchedEffect(message) {
        message?.let { snackbar.showSnackbar(it); SubtitleSession.message.value = null }
    }
    // Fichier reçu de LinkShare : ouvert une seule fois (pas à chaque recréation de l'écran)
    LaunchedEffect(initialSource) {
        if (initialSource != null && SubtitleSession.source.value?.uri != initialSource && !st.busy) {
            SubtitleSession.open(ctx, initialSource)
            initialSubtitles?.let { SubtitleSession.loadSubtitleFile(ctx, it) }
        }
    }

    val pickMedia = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { SubtitleSession.open(ctx, it) }
    }
    val pickSrt = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { SubtitleSession.loadSubtitleFile(ctx, it) }
    }
    val pickModel = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            importProgress = 0f
            try {
                val m = WhisperModels.import(ctx, uri) { importProgress = it }
                refreshModels()
                SubtitleSession.message.value = "Modèle installé : ${m.label}"
            } catch (e: Exception) {
                SubtitleSession.message.value = e.message ?: "Import impossible"
            } finally { importProgress = null }
        }
    }

    // ── Lecteur partagé (aperçu de la vidéo + sous-titres) ──
    val player = remember { ExoPlayer.Builder(ctx).build() }
    DisposableEffect(Unit) { onDispose { player.release() } }
    LaunchedEffect(src?.uri) {
        val s = src
        if (s == null) player.clearMediaItems()
        else { player.setMediaItem(MediaItem.fromUri(s.uri)); player.prepare() }
    }
    LaunchedEffect(phase) {
        when (phase) {
            SubtitleSession.Phase.TRANSCRIBING -> player.pause()
            SubtitleSession.Phase.BURNING -> player.stop() // libère les décodeurs pour l'export
            else -> if (src != null && player.playbackState == Player.STATE_IDLE) player.prepare()
        }
    }
    var posMs by remember { mutableLongStateOf(0L) }
    LaunchedEffect(player) { while (true) { posMs = player.currentPosition; delay(80) } }

    val busy = st.busy
    val listState = rememberLazyListState()

    Box(modifier.fillMaxSize().background(SP.Bg)) {
        Column(Modifier.fillMaxSize()) {
            StudioTopBar(
                canReset = src != null && !busy,
                onReset = { SubtitleSession.reset() },
                onClose = onClose,
            )
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 40.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                val s = src
                if (s == null) {
                    item {
                        HeroPick(
                            engineError = WhisperEngine.available(),
                            onVideo = { pickMedia.launch(arrayOf("video/*")) },
                            onAudio = { pickMedia.launch(arrayOf("audio/*")) },
                        )
                    }
                    item { ModelCard(model, models.size, importProgress, onManage = { showModels = true }, onImport = { pickModel.launch(arrayOf("*/*")) }) }
                    return@LazyColumn
                }

                item(key = "stage") {
                    VideoStage(
                        player = player, src = s, cues = cues, style = style, posMs = posMs,
                        showSubs = phase == SubtitleSession.Phase.REVIEW || phase == SubtitleSession.Phase.BURNED,
                        dimmed = phase == SubtitleSession.Phase.BURNING,
                    )
                }

                when (phase) {
                    SubtitleSession.Phase.EMPTY, SubtitleSession.Phase.READY -> {
                        item { ModelCard(model, models.size, importProgress, onManage = { showModels = true }, onImport = { pickModel.launch(arrayOf("*/*")) }) }
                        item { OptionsCard(options) { SubtitleSession.options.value = it } }
                        item {
                            GoldButton(
                                "🎙️  Transcrire hors ligne",
                                enabled = model != null && !busy && WhisperEngine.available() == null,
                            ) { model?.let { SubtitleSession.startTranscription(ctx, it, destinationTreeUri) } }
                        }
                        item {
                            OutlinedButton(
                                onClick = { pickSrt.launch(arrayOf("application/x-subrip", "text/vtt", "text/plain", "application/octet-stream", "*/*")) },
                                enabled = !busy && s.hasVideo,
                                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(50),
                                border = BorderStroke(1.dp, SP.Line),
                            ) { Text("J'ai déjà un fichier .srt : l'incruster", color = SP.Muted) }
                        }
                    }

                    SubtitleSession.Phase.TRANSCRIBING -> {
                        item { ProgressCard("Transcription", st, SP.Violet) { cancelExport(ctx) } }
                        item { SectionTitle("✍️", "Texte reconnu en direct", "${cues.size}") }
                        itemsIndexed(cues.takeLast(60).reversed()) { _, c -> LiveCueRow(c) }
                    }

                    SubtitleSession.Phase.REVIEW, SubtitleSession.Phase.BURNING, SubtitleSession.Phase.BURNED -> {
                        if (phase == SubtitleSession.Phase.BURNING) item { ProgressCard("Incrustation", st, SP.Gold) { cancelExport(ctx) } }
                        if (phase == SubtitleSession.Phase.BURNED) burnedUri?.let { u ->
                            item {
                                DoneCard(
                                    uri = u, name = "${s.base}_soustitre.mp4", routerMode = routerMode,
                                    onDeliver = { onDeliver?.invoke(u, "${s.base}_soustitre.mp4", "${cues.size} sous-titres incrustés") },
                                )
                            }
                        }
                        item {
                            FilesCard(
                                count = cues.size, language = language, srt = srtUri, txt = txtUri, routerMode = routerMode,
                                fullText = { Subtitles.fullText(cues) },
                                onSaveEdited = { SubtitleSession.saveEdited(ctx, destinationTreeUri) },
                                onDeliver = { u, n -> onDeliver?.invoke(u, n, "${cues.size} sous-titres · ${Subtitles.languageLabel(language)}") },
                                srtName = "${s.base}.srt", txtName = "${s.base}.txt", busy = busy,
                            )
                        }
                        if (s.hasVideo) {
                            item { StyleCard(style, enabled = !busy) { SubtitleSession.style.value = it } }
                            item {
                                GoldButton(
                                    if (phase == SubtitleSession.Phase.BURNED) "✨  Générer à nouveau avec ce style" else "✨  Générer les sous-titres dans la vidéo",
                                    enabled = !busy && cues.isNotEmpty(), big = true,
                                ) { SubtitleSession.startBurn(ctx, destinationTreeUri) }
                            }
                        } else item {
                            Text(
                                "Fichier audio : les sous-titres ne peuvent pas être incrustés, mais le SRT et le TXT sont prêts.",
                                color = SP.Muted, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 6.dp),
                            )
                        }
                        item { TimingCard(enabled = !busy) { SubtitleSession.shiftAll(it) } }
                        item { SectionTitle("📝", "Sous-titres (touchez l'heure pour y aller)", "${cues.size}") }
                        itemsIndexed(cues, key = { i, c -> "cue$i-${c.startMs}" }) { i, c ->
                            CueEditor(
                                index = i, cue = c, active = posMs in c.startMs until c.endMs, enabled = !busy,
                                onSeek = { player.seekTo(c.startMs); player.play() },
                                onText = { SubtitleSession.editCue(i, it) },
                                onDelete = { SubtitleSession.deleteCue(i) },
                            )
                        }
                    }
                }
            }
        }
        SnackbarHost(snackbar, Modifier.align(Alignment.BottomCenter).padding(16.dp))
    }

    if (showModels) ModelsDialog(
        models = models, selected = model, importing = importProgress,
        onSelect = { WhisperModels.select(ctx, it); refreshModels() },
        onDelete = { WhisperModels.delete(ctx, it); refreshModels() },
        onImport = { pickModel.launch(arrayOf("*/*")) },
        onDismiss = { showModels = false },
    )
}

private fun cancelExport(ctx: Context) {
    if (ExportManager.state.value.busy)
        ctx.startService(Intent(ctx, ExportService::class.java).setAction(ExportService.ACTION_CANCEL))
}

private fun openUri(ctx: Context, uri: Uri, mime: String) {
    val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    runCatching { ctx.startActivity(i) }.onFailure {
        // Pas de lecteur de sous-titres : on ouvre en texte
        runCatching { ctx.startActivity(Intent(i).setDataAndType(uri, "text/plain")) }
            .onFailure { SubtitleSession.message.value = "Aucune application pour ouvrir ce fichier" }
    }
}

private fun shareUri(ctx: Context, uri: Uri, mime: String, name: String) {
    val send = Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, uri)
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    send.clipData = ClipData.newUri(ctx.contentResolver, name, uri)
    runCatching { ctx.startActivity(Intent.createChooser(send, "Partager").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}

private fun tenth(ms: Long): String {
    val t = ms.coerceAtLeast(0)
    return String.format(Locale.US, "%s.%d", Subtitles.short(t), (t % 1000) / 100)
}

// ═══════════════════════════ En-tête ═══════════════════════════

@Composable
private fun StudioTopBar(canReset: Boolean, onReset: () -> Unit, onClose: (() -> Unit)?) {
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().padding(start = 18.dp, end = 8.dp, top = 10.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(SP.goldBrush), contentAlignment = Alignment.Center) {
            Text("CC", color = Color(0xFF1C1405), fontWeight = FontWeight.Black, fontSize = 16.sp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("Studio Sous-titres", color = SP.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("Whisper · 100 % hors ligne", color = SP.Gold, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        }
        if (canReset) TextButton(onClick = onReset) { Text("Nouveau", color = SP.Muted) }
        if (onClose != null) TextButton(onClick = onClose) { Text("✕", color = SP.Text, fontSize = 20.sp) }
    }
}

// ═══════════════════════════ Accueil ═══════════════════════════

@Composable
private fun HeroPick(engineError: String?, onVideo: () -> Unit, onAudio: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF3B2470), Color(0xFF1B1230), Color(0xFF2B1D07))))
            .border(1.dp, SP.Gold.copy(alpha = 0.35f), RoundedCornerShape(28.dp)),
    ) {
        Box(Modifier.align(Alignment.TopEnd).offset(x = 40.dp, y = (-40).dp).size(150.dp).clip(CircleShape).background(SP.Gold.copy(alpha = 0.10f)))
        Box(Modifier.align(Alignment.BottomStart).offset(x = (-30).dp, y = 36.dp).size(110.dp).clip(CircleShape).background(SP.Violet.copy(alpha = 0.18f)))
        Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("🎬", fontSize = 40.sp)
            Text("Sous-titrez vos vidéos,\nsans Internet", color = SP.Text, fontSize = 24.sp, fontWeight = FontWeight.Bold, lineHeight = 30.sp)
            listOf(
                "🎙️" to "Transcription automatique horodatée (Whisper)",
                "📄" to "Fichiers SRT et TXT de tout le résultat",
                "✨" to "Aperçu sur la vidéo puis incrustation stylée",
            ).forEach { (e, t) ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(e, fontSize = 16.sp); Spacer(Modifier.width(10.dp))
                    Text(t, color = SP.Text.copy(alpha = 0.85f), fontSize = 14.sp)
                }
            }
            engineError?.let { Text(it, color = SP.Red, fontSize = 13.sp) }
            GoldButton("Choisir une vidéo", enabled = true, onClick = onVideo)
            OutlinedButton(
                onClick = onAudio, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(50),
                border = BorderStroke(1.dp, SP.Gold.copy(alpha = 0.5f)),
            ) { Text("Choisir un audio (transcription seule)", color = SP.Gold) }
        }
    }
}

// ═══════════════════════════ Vidéo + aperçu des sous-titres ═══════════════════════════

@UnstableApi
@Composable
private fun VideoStage(
    player: ExoPlayer, src: SubtitleSession.Source, cues: List<Cue>, style: SubtitleStyle,
    posMs: Long, showSubs: Boolean, dimmed: Boolean,
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (src.hasVideo) {
            val ratio = (src.width.toFloat() / src.height.coerceAtLeast(1)).coerceIn(0.4f, 2.4f)
            BoxWithConstraints(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                val maxH = 440.dp
                var w = maxWidth
                var h = w / ratio
                if (h > maxH) { h = maxH; w = h * ratio }
                val density = LocalDensity.current
                val wPx = with(density) { w.roundToPx() }
                val hPx = with(density) { h.roundToPx() }
                Box(
                    Modifier.size(w, h).clip(RoundedCornerShape(22.dp)).background(Color.Black)
                        .border(1.dp, SP.Gold.copy(alpha = 0.25f), RoundedCornerShape(22.dp))
                        .alpha(if (dimmed) 0.45f else 1f),
                ) {
                    AndroidView(
                        modifier = Modifier.fillMaxSize(),
                        factory = { c -> PlayerView(c).apply { this.player = player; setShowSubtitleButton(false) } },
                    )
                    if (showSubs) {
                        val idx = Subtitles.indexAt(cues, posMs)
                        val cue = cues.getOrNull(idx)
                        if (cue != null) {
                            val bmp = remember(cue.text, style, wPx, hPx) { SubtitleRenderer.render(cue.text, style, wPx, hPx) }
                            val align = when (style.position) {
                                SubPosition.BOTTOM -> Alignment.BottomCenter
                                SubPosition.MIDDLE -> Alignment.Center
                                SubPosition.TOP -> Alignment.TopCenter
                            }
                            val margin = if (style.position == SubPosition.MIDDLE) 0.dp else h * 0.07f
                            Image(
                                bmp.asImageBitmap(), null,
                                Modifier.align(align).padding(vertical = margin),
                            )
                        }
                    }
                }
            }
        } else {
            Box(Modifier.fillMaxWidth().height(120.dp).clip(RoundedCornerShape(22.dp)).background(SP.Card)) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { c -> PlayerView(c).apply { this.player = player; controllerShowTimeoutMs = 0 } },
                )
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(src.name, Modifier.weight(1f), color = SP.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (src.durationMs > 0) Pill(Subtitles.short(src.durationMs))
            if (src.hasVideo) Pill("${src.width}×${src.height}") else Pill("Audio")
        }
    }
}

@Composable
private fun Pill(text: String, color: Color = SP.Card2) {
    Text(
        text, color = SP.Muted, fontSize = 11.sp, fontWeight = FontWeight.Medium,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(color).padding(horizontal = 10.dp, vertical = 4.dp),
    )
}

// ═══════════════════════════ Modèle et options ═══════════════════════════

@Composable
private fun StudioCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(SP.Card)
            .border(1.dp, SP.Line, RoundedCornerShape(22.dp)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        content = content,
    )
}

@Composable
private fun SectionTitle(emoji: String, title: String, badge: String? = null) {
    Row(Modifier.padding(start = 4.dp, top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(emoji, fontSize = 16.sp)
        Spacer(Modifier.width(8.dp))
        Text(title, Modifier.weight(1f), color = SP.Text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        badge?.let { Pill(it) }
    }
}

@Composable
private fun ModelCard(model: WhisperModels.Model?, count: Int, importing: Float?, onManage: () -> Unit, onImport: () -> Unit) {
    StudioCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(SP.Violet.copy(alpha = 0.25f)), contentAlignment = Alignment.Center) {
                Text("🧠", fontSize = 22.sp)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Modèle Whisper", color = SP.Muted, fontSize = 12.sp)
                Text(
                    model?.let { "${it.label}  ${it.sizeLabel}".trim() } ?: "Aucun modèle installé",
                    color = if (model == null) SP.Red else SP.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                )
                model?.let { Text(if (it.bundled) "Intégré à l'application" else "Importé sur ce téléphone", color = SP.Muted, fontSize = 11.sp) }
            }
            if (count > 0) TextButton(onClick = onManage) { Text("Changer", color = SP.Gold) }
        }
        if (importing != null) {
            LinearProgressIndicator(progress = { importing }, modifier = Modifier.fillMaxWidth(), color = SP.Gold)
            Text("Installation du modèle…", color = SP.Muted, fontSize = 12.sp)
        } else if (model == null) {
            Text(WhisperModels.HELP, color = SP.Muted, fontSize = 12.sp, lineHeight = 17.sp)
            OutlinedButton(onClick = onImport, shape = RoundedCornerShape(50), border = BorderStroke(1.dp, SP.Gold.copy(alpha = 0.5f))) {
                Text("Importer un modèle (.bin)", color = SP.Gold)
            }
        }
    }
}

@Composable
private fun OptionsCard(o: com.mediastudio.app.whisper.TranscribeOptions, onChange: (com.mediastudio.app.whisper.TranscribeOptions) -> Unit) {
    StudioCard {
        Text("Langue parlée", color = SP.Muted, fontSize = 12.sp)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Subtitles.LANGUAGES.forEach { (code, label) ->
                FilterChip(o.language == code, { onChange(o.copy(language = code)) }, label = { Text(label) })
            }
        }
        Text("Qualité", color = SP.Muted, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(!o.accurate, { onChange(o.copy(accurate = false)) }, label = { Text("⚡ Rapide") })
            FilterChip(o.accurate, { onChange(o.copy(accurate = true)) }, label = { Text("🎯 Précise (plus lent)") })
        }
        Text("Longueur des sous-titres", color = SP.Muted, fontSize = 12.sp)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(32 to "Court", 42 to "Normal", 60 to "Long", 0 to "Phrases entières").forEach { (n, l) ->
                FilterChip(o.maxChars == n, { onChange(o.copy(maxChars = n)) }, label = { Text(if (n > 0) "$l · $n car." else l) })
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Traduire en anglais", color = SP.Text, fontSize = 14.sp)
                Text("Sous-titres anglais, quelle que soit la langue parlée", color = SP.Muted, fontSize = 11.sp)
            }
            Switch(o.translate, { onChange(o.copy(translate = it)) })
        }
        OutlinedTextField(
            value = o.prompt, onValueChange = { onChange(o.copy(prompt = it.take(200))) },
            label = { Text("Noms propres / mots-clés (facultatif)") },
            placeholder = { Text("ex. DL VIBE STUDIO, Abidjan, Yopougon") },
            singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp),
        )
    }
}

@Composable
private fun ModelsDialog(
    models: List<WhisperModels.Model>, selected: WhisperModels.Model?, importing: Float?,
    onSelect: (WhisperModels.Model) -> Unit, onDelete: (WhisperModels.Model) -> Unit,
    onImport: () -> Unit, onDismiss: () -> Unit,
) {
    var confirmDelete by remember { mutableStateOf<WhisperModels.Model?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SP.Card,
        title = { Text("🧠  Modèles Whisper", color = SP.Text) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                models.forEach { m ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable { onSelect(m) }
                            .background(if (m.id == selected?.id) SP.Gold.copy(alpha = 0.12f) else Color.Transparent)
                            .padding(horizontal = 6.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioButton(m.id == selected?.id, { onSelect(m) })
                        Column(Modifier.weight(1f)) {
                            Text(m.label, color = SP.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            Text("${m.sizeLabel} · ${if (m.bundled) "intégré" else "importé"}", color = SP.Muted, fontSize = 11.sp)
                        }
                        if (!m.bundled) TextButton(onClick = { confirmDelete = m }) { Text("Suppr.", color = SP.Red, fontSize = 12.sp) }
                    }
                }
                Text(
                    "Plus le modèle est gros, plus la transcription est juste… et lente. Small ou Base conviennent bien au français.",
                    color = SP.Muted, fontSize = 11.sp,
                )
                if (importing != null) LinearProgressIndicator(progress = { importing }, modifier = Modifier.fillMaxWidth(), color = SP.Gold)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("OK", color = SP.Gold) } },
        dismissButton = { TextButton(onClick = onImport, enabled = importing == null) { Text("Importer…", color = SP.Muted) } },
    )
    confirmDelete?.let { m ->
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            containerColor = SP.Card2,
            title = { Text("Supprimer ${m.label} ?", color = SP.Text) },
            text = { Text("Le fichier ${m.fileName} (${m.sizeLabel}) sera effacé de ce téléphone.", color = SP.Muted) },
            confirmButton = { TextButton(onClick = { onDelete(m); confirmDelete = null }) { Text("Supprimer", color = SP.Red) } },
            dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text("Annuler") } },
        )
    }
}

// ═══════════════════════════ Progression ═══════════════════════════

@Composable
private fun ProgressCard(title: String, st: ExportManager.State, accent: Color, onCancel: () -> Unit) {
    val p = if (st.busy) st.progress.coerceIn(0f, 1f) else 0f
    val animated by animateFloatAsState(p, tween(400), label = "p")
    StudioCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(84.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(
                    progress = { 1f }, modifier = Modifier.fillMaxSize(), strokeWidth = 8.dp,
                    color = accent.copy(alpha = 0.15f), trackColor = Color.Transparent,
                )
                if (p < 0.005f) CircularProgressIndicator(Modifier.fillMaxSize(), color = accent, strokeWidth = 8.dp, strokeCap = StrokeCap.Round)
                else CircularProgressIndicator(
                    progress = { animated }, modifier = Modifier.fillMaxSize(), strokeWidth = 8.dp,
                    color = accent, trackColor = Color.Transparent, strokeCap = StrokeCap.Round,
                )
                Text("${(animated * 100).toInt()} %", color = SP.Text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, color = SP.Text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text(st.status.ifBlank { "En cours…" }, color = SP.Muted, fontSize = 13.sp)
                Text("Continue écran éteint ou appli en arrière-plan.", color = SP.Muted.copy(alpha = 0.7f), fontSize = 11.sp)
            }
        }
        OutlinedButton(onClick = onCancel, shape = RoundedCornerShape(50), border = BorderStroke(1.dp, SP.Line), modifier = Modifier.fillMaxWidth()) {
            Text("Annuler", color = SP.Muted)
        }
    }
}

@Composable
private fun LiveCueRow(c: Cue) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(SP.Card).padding(horizontal = 12.dp, vertical = 9.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Text(tenth(c.startMs), color = SP.Violet, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.width(58.dp))
        Text(c.text, color = SP.Text, fontSize = 14.sp)
    }
}

// ═══════════════════════════ Résultats ═══════════════════════════

@Composable
private fun FilesCard(
    count: Int, language: String, srt: Uri?, txt: Uri?, routerMode: Boolean, busy: Boolean,
    srtName: String, txtName: String,
    fullText: () -> String, onSaveEdited: () -> Unit, onDeliver: (Uri, String) -> Unit,
) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    StudioCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).clip(CircleShape).background(SP.Green.copy(alpha = 0.2f)), contentAlignment = Alignment.Center) {
                Text("✓", color = SP.Green, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Transcription prête", color = SP.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text(
                    "$count sous-titres" + if (language.isNotBlank()) " · ${Subtitles.languageLabel(language)}" else "",
                    color = SP.Muted, fontSize = 12.sp,
                )
            }
        }
        FileRow("SRT", "Sous-titres horodatés", srt, SP.Gold, onOpen = { srt?.let { openUri(ctx, it, SubFormat.SRT.mime) } },
            onShare = { srt?.let { shareUri(ctx, it, SubFormat.SRT.mime, srtName) } })
        FileRow("TXT", "Texte horodaté + texte intégral", txt, SP.Teal, onOpen = { txt?.let { openUri(ctx, it, "text/plain") } },
            onShare = { txt?.let { shareUri(ctx, it, "text/plain", txtName) } })
        Text("Enregistrés dans Download/MediaStudio", color = SP.Muted, fontSize = 11.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = { clipboard.setText(AnnotatedString(fullText())); SubtitleSession.message.value = "Texte copié" },
                shape = RoundedCornerShape(50), border = BorderStroke(1.dp, SP.Line), modifier = Modifier.weight(1f),
            ) { Text("Copier le texte", color = SP.Text, fontSize = 13.sp) }
            OutlinedButton(
                onClick = onSaveEdited, enabled = !busy,
                shape = RoundedCornerShape(50), border = BorderStroke(1.dp, SP.Line), modifier = Modifier.weight(1f),
            ) { Text("Enregistrer mes modifs", color = SP.Text, fontSize = 13.sp) }
        }
        if (routerMode && srt != null) {
            TextButton(onClick = { onDeliver(srt, srtName) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                Text("Terminer : renvoyer le SRT à LinkShare", color = SP.Gold)
            }
        }
    }
}

@Composable
private fun FileRow(tag: String, subtitle: String, uri: Uri?, accent: Color, onOpen: () -> Unit, onShare: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(SP.Card2).padding(10.dp)
            .alpha(if (uri == null) 0.45f else 1f),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(accent.copy(alpha = 0.22f)), contentAlignment = Alignment.Center) {
            Text(tag, color = accent, fontWeight = FontWeight.Black, fontSize = 12.sp)
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(".${tag.lowercase()}", color = SP.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text(if (uri == null) "Pas encore enregistré" else subtitle, color = SP.Muted, fontSize = 11.sp)
        }
        TextButton(onClick = onOpen, enabled = uri != null) { Text("Ouvrir", color = accent, fontSize = 13.sp) }
        TextButton(onClick = onShare, enabled = uri != null) { Text("Partager", color = SP.Muted, fontSize = 13.sp) }
    }
}

@Composable
private fun StyleCard(style: SubtitleStyle, enabled: Boolean, onChange: (SubtitleStyle) -> Unit) {
    StudioCard {
        Text("🎨  Style des sous-titres", color = SP.Text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        Text("L'aperçu sur la vidéo correspond exactement au rendu final.", color = SP.Muted, fontSize = 11.sp)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SubPreset.entries.forEach { p -> PresetSwatch(p, p == style.preset, enabled) { onChange(style.copy(preset = p)) } }
        }
        LabeledChips("Taille", SubSize.entries, style.size, { it.label }, enabled) { onChange(style.copy(size = it)) }
        LabeledChips("Position", SubPosition.entries, style.position, { it.label }, enabled) { onChange(style.copy(position = it)) }
        LabeledChips("Police", SubFont.entries, style.font, { it.label }, enabled) { onChange(style.copy(font = it)) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(style.bold, { onChange(style.copy(bold = !style.bold)) }, enabled = enabled, label = { Text("Gras") })
            FilterChip(style.uppercase, { onChange(style.copy(uppercase = !style.uppercase)) }, enabled = enabled, label = { Text("MAJUSCULES") })
        }
    }
}

@Composable
private fun <T> LabeledChips(label: String, values: List<T>, selected: T, name: (T) -> String, enabled: Boolean, onPick: (T) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label, color = SP.Muted, fontSize = 12.sp)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            values.forEach { v -> FilterChip(v == selected, { onPick(v) }, enabled = enabled, label = { Text(name(v)) }) }
        }
    }
}

@Composable
private fun PresetSwatch(p: SubPreset, selected: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        Modifier.width(104.dp).clip(shape)
            .background(Brush.linearGradient(listOf(Color(0xFF39404F), Color(0xFF14161C))))
            .border(if (selected) 2.dp else 1.dp, if (selected) SP.Gold else SP.Line, shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(vertical = 14.dp, horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(
            "Aa", color = Color(p.text), fontSize = 20.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.clip(RoundedCornerShape(8.dp))
                .background(p.box?.let { Color(it) } ?: Color.Transparent).padding(horizontal = 8.dp, vertical = 2.dp),
        )
        Text(p.label, color = SP.Text, fontSize = 11.sp, textAlign = TextAlign.Center, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun TimingCard(enabled: Boolean, onShift: (Long) -> Unit) {
    StudioCard {
        Text("⏱️  Synchronisation", color = SP.Text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        Text("Décaler tous les sous-titres si le texte arrive trop tôt ou trop tard.", color = SP.Muted, fontSize = 11.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
            listOf(-1000L to "−1 s", -250L to "−0,25 s", 250L to "+0,25 s", 1000L to "+1 s").forEach { (d, l) ->
                AssistChip(onClick = { onShift(d) }, enabled = enabled, label = { Text(l) })
            }
        }
    }
}

@Composable
private fun CueEditor(
    index: Int, cue: Cue, active: Boolean, enabled: Boolean,
    onSeek: () -> Unit, onText: (String) -> Unit, onDelete: () -> Unit,
) {
    val shape = RoundedCornerShape(18.dp)
    Column(
        Modifier.fillMaxWidth().clip(shape)
            .background(if (active) SP.Gold.copy(alpha = 0.10f) else SP.Card)
            .border(1.dp, if (active) SP.Gold.copy(alpha = 0.6f) else SP.Line, shape)
            .padding(start = 12.dp, end = 4.dp, top = 8.dp, bottom = 10.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("${index + 1}", color = SP.Muted, fontSize = 11.sp, modifier = Modifier.width(28.dp))
            Text(
                "▶ ${tenth(cue.startMs)} → ${tenth(cue.endMs)}",
                color = if (active) SP.Gold else SP.Violet, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clip(RoundedCornerShape(50)).clickable(onClick = onSeek)
                    .background(SP.Card2).padding(horizontal = 10.dp, vertical = 4.dp),
            )
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onDelete, enabled = enabled) { Text("Retirer", color = SP.Muted, fontSize = 12.sp) }
        }
        var text by remember(cue.text) { mutableStateOf(cue.text) }
        OutlinedTextField(
            value = text,
            onValueChange = { text = it; onText(it) },
            enabled = enabled,
            modifier = Modifier.fillMaxWidth().padding(end = 8.dp),
            textStyle = MaterialTheme.typography.bodyMedium.copy(color = SP.Text),
            shape = RoundedCornerShape(12.dp),
        )
    }
}

@Composable
private fun DoneCard(uri: Uri, name: String, routerMode: Boolean, onDeliver: () -> Unit) {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF1E5B43), Color(0xFF12241D))))
            .border(1.dp, SP.Green.copy(alpha = 0.5f), RoundedCornerShape(24.dp)).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("✓", color = Color(0xFF7BE3B0), fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(12.dp))
            Column {
                Text("Vidéo sous-titrée prête", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text("$name · Movies/MediaStudio", color = Color(0xFFB8D4C7), fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { openUri(ctx, uri, "video/mp4") }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(50)) { Text("Regarder") }
            OutlinedButton(
                onClick = { shareUri(ctx, uri, "video/mp4", name) }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(50),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.4f)),
            ) { Text("Partager", color = Color.White) }
        }
        if (routerMode) GoldButton("Terminer et revenir à LinkShare", enabled = true, onClick = onDeliver)
    }
}

@Composable
private fun GoldButton(text: String, enabled: Boolean, big: Boolean = false, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier.fillMaxWidth().height(if (big) 62.dp else 52.dp).clip(shape)
            .background(if (enabled) SP.goldBrush else Brush.linearGradient(listOf(SP.Card2, SP.Card2)))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text, color = if (enabled) Color(0xFF1C1405) else SP.Muted,
            fontSize = if (big) 17.sp else 15.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 16.dp),
        )
    }
}
