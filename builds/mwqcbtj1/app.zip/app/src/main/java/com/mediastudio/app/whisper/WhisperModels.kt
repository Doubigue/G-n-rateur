package com.mediastudio.app.whisper

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

/**
 * Modèles Whisper (format ggml de whisper.cpp, fichiers ggml-*.bin), tous lus en local :
 *  - embarqués dans l'APK (assets/whisper/…, ajoutés à la compilation) ;
 *  - importés par l'utilisateur depuis le stockage ou reçus via LinkShare (copiés dans files/whisper).
 */
object WhisperModels {

    data class Model(
        val id: String,
        val fileName: String,
        val sizeBytes: Long,
        /** Chemin dans les assets (modèle embarqué) ou null. */
        val asset: String? = null,
        /** Fichier local (modèle importé) ou null. */
        val file: File? = null,
    ) {
        val bundled get() = asset != null
        val label: String get() = describe(fileName)
        val sizeLabel: String get() = when {
            sizeBytes <= 0 -> ""
            sizeBytes >= 1_000_000_000 -> String.format(Locale.FRANCE, "%.1f Go", sizeBytes / 1e9)
            else -> "${sizeBytes / 1_000_000} Mo"
        }
    }

    private const val ASSET_DIR = "whisper"
    private const val PREFS = "whisper"
    private const val KEY_SELECTED = "selected_model"

    fun dir(ctx: Context) = File(ctx.filesDir, "whisper_models").apply { mkdirs() }

    fun list(ctx: Context): List<Model> {
        val bundled = runCatching { ctx.assets.list(ASSET_DIR)?.toList().orEmpty() }.getOrDefault(emptyList())
            .filter { it.endsWith(".bin") }
            .map { name ->
                val size = runCatching { ctx.assets.openFd("$ASSET_DIR/$name").use { it.length } }.getOrDefault(-1L)
                Model("asset:$name", name, size, asset = "$ASSET_DIR/$name")
            }
        val imported = dir(ctx).listFiles { f -> f.isFile && f.name.endsWith(".bin") }.orEmpty()
            .sortedBy { it.name }
            .map { Model("file:${it.name}", it.name, it.length(), file = it) }
        return bundled + imported
    }

    fun selected(ctx: Context): Model? {
        val all = list(ctx)
        val id = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_SELECTED, null)
        return all.firstOrNull { it.id == id } ?: all.maxByOrNull { rank(it.fileName) }
    }

    fun select(ctx: Context, model: Model) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_SELECTED, model.id).apply()
    }

    fun delete(ctx: Context, model: Model): Boolean {
        val f = model.file ?: return false
        WhisperEngine.release(model.id)
        return f.delete()
    }

    /**
     * Copie un modèle choisi par l'utilisateur (ou envoyé par LinkShare) après vérification de l'en-tête ggml.
     * @return le modèle installé.
     */
    suspend fun import(ctx: Context, source: Uri, onProgress: (Float) -> Unit = {}): Model = withContext(Dispatchers.IO) {
        val rawName = displayName(ctx, source) ?: "ggml-modele.bin"
        var name = rawName.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001F]"), "_").trim()
        if (!name.endsWith(".bin", true)) name = name.substringBeforeLast('.') + ".bin"
        val total = runCatching {
            ctx.contentResolver.openAssetFileDescriptor(source, "r")?.use { it.length }
        }.getOrNull() ?: -1L
        val target = File(dir(ctx), name)
        val tmp = File(dir(ctx), "$name.part")
        ctx.contentResolver.openInputStream(source)?.use { input ->
            val head = ByteArray(4)
            if (input.read(head) != 4 || !isGgml(head)) {
                error("Ce fichier n'est pas un modèle Whisper ggml (attendu : ggml-base.bin, ggml-small.bin…).")
            }
            tmp.outputStream().buffered(1 shl 20).use { out ->
                out.write(head)
                val buf = ByteArray(1 shl 20)
                var copied = 4L
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    copied += n
                    if (total > 0) onProgress((copied.toFloat() / total).coerceIn(0f, 1f))
                }
            }
        } ?: error("Lecture du modèle impossible.")
        if (tmp.length() < 10_000_000) { tmp.delete(); error("Fichier de modèle incomplet ou trop petit.") }
        target.delete()
        if (!tmp.renameTo(target)) { tmp.delete(); error("Installation du modèle impossible.") }
        val model = Model("file:${target.name}", target.name, target.length(), file = target)
        select(ctx, model)
        model
    }

    /** whisper.cpp écrit le magic 0x67676d6c en little-endian : « lmgg ». */
    private fun isGgml(h: ByteArray) =
        h[0] == 'l'.code.toByte() && h[1] == 'm'.code.toByte() && h[2] == 'g'.code.toByte() && h[3] == 'g'.code.toByte()

    private fun displayName(ctx: Context, uri: Uri): String? = runCatching {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { if (it.moveToFirst()) it.getString(0) else null }
    }.getOrNull()

    /** « ggml-base-q5_1.bin » → « Base · quantifié q5_1 ». */
    fun describe(fileName: String): String {
        val core = fileName.removePrefix("ggml-").removeSuffix(".bin")
        val parts = core.split('-')
        val size = parts.firstOrNull().orEmpty()
        val base = when {
            size.startsWith("tiny") -> "Tiny"
            size.startsWith("base") -> "Base"
            size.startsWith("small") -> "Small"
            size.startsWith("medium") -> "Medium"
            size.startsWith("large") -> "Large"
            else -> core
        }
        val english = if (size.endsWith(".en")) " (anglais seul)" else ""
        val extra = parts.drop(1).joinToString(" ").let { if (it.isBlank()) "" else " · $it" }
        return "$base$english$extra"
    }

    /** Préférence par défaut : le modèle multilingue le plus précis disponible. */
    private fun rank(fileName: String): Int {
        val n = fileName.lowercase()
        val size = when {
            "large" in n -> 50; "medium" in n -> 40; "small" in n -> 30; "base" in n -> 20; "tiny" in n -> 10; else -> 5
        }
        return size - if (".en" in n) 15 else 0
    }

    /** Texte d'aide quand aucun modèle n'est présent. */
    const val HELP = "Aucun modèle Whisper sur ce téléphone. Importez un fichier ggml (ex. ggml-base.bin, " +
        "ggml-small-q5_1.bin) depuis le stockage, ou envoyez-le depuis un autre téléphone avec LinkShare " +
        "(« Installer comme modèle Whisper »). Aucune connexion Internet n'est nécessaire ensuite."
}
