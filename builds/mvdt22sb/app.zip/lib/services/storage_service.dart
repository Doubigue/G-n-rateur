import 'dart:io';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

/// Gestion du stockage : dossier DoubigueShare + accès « tous les fichiers ».
class StorageService {
  static const rootPath = '/storage/emulated/0';
  static const folderName = 'DoubigueShare';

  static Future<int> _sdk() async => (await DeviceInfoPlugin().androidInfo).version.sdkInt;

  /// Android 11+ : MANAGE_EXTERNAL_STORAGE (« Accès à tous les fichiers »).
  /// Android 10- : READ/WRITE_EXTERNAL_STORAGE.
  static Future<bool> hasAccess() async {
    if (!Platform.isAndroid) return true;
    return await _sdk() >= 30
        ? Permission.manageExternalStorage.isGranted
        : Permission.storage.isGranted;
  }

  static Future<bool> ensureAccess() async {
    if (!Platform.isAndroid) return true;
    if (await hasAccess()) return true;
    final st = await _sdk() >= 30
        ? await Permission.manageExternalStorage.request()
        : await Permission.storage.request();
    return st.isGranted;
  }

  /// <stockage interne>/DoubigueShare (créé s'il n'existe pas).
  /// Repli : dossier privé de l'appli si l'accès complet est refusé.
  static Future<Directory> shareDir() async {
    if (Platform.isAndroid && await hasAccess()) {
      try {
        final d = Directory('$rootPath/$folderName');
        if (!await d.exists()) await d.create(recursive: true);
        return d;
      } catch (e) {
        debugPrint('shareDir error: $e');
      }
    }
    final base = (Platform.isAndroid ? await getExternalStorageDirectory() : null) ??
        await getApplicationDocumentsDirectory();
    final d = Directory('${base.path}/$folderName');
    if (!await d.exists()) await d.create(recursive: true);
    return d;
  }
}
