import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:nearby_connections/nearby_connections.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/peer.dart';
import 'background_service.dart';
import 'crash_guard.dart';
import 'notification_service.dart';
import 'protocol.dart';

/// Rôle de cet appareil dans la session.
enum NearbyRole { none, host, client }

/// Demande de connexion entrante à valider manuellement.
class PendingConnection {
  PendingConnection(this.id, this.name, this.code);
  final String id;
  final String name;
  final String code; // authenticationToken : doit être identique des deux côtés
}

/// Gère découverte, connexion et échange de payloads.
///
/// Dès le lancement, l'appareil est À LA FOIS visible (advertising) et en
/// recherche (discovery) : deux téléphones qui ouvrent l'appli se voient
/// automatiquement. Toucher un appareil envoie une demande ; l'autre reçoit
/// une notification Accepter / Refuser.
///
/// Sécurité : toute demande entrante passe par une confirmation avec code.
class NearbyService extends ChangeNotifier {
  static const _serviceId = 'com.example.localshare';
  static const _strategy = Strategy.P2P_POINT_TO_POINT;

  final Nearby _nearby = Nearby();
  final Map<String, Peer> _peers = {};
  NearbyRole role = NearbyRole.none;
  bool isAdvertising = false;
  bool isDiscovering = false;

  /// Recherche automatique (le radar balaie dès l'ouverture).
  bool wantDiscover = true;

  /// Visible par défaut. Passe à false uniquement si l'utilisateur le demande.
  bool wantVisible = true;
  String? connectedId;
  String deviceName = 'Appareil';

  /// Problème à corriger par l'utilisateur (permission, Bluetooth, GPS…).
  String? status;

  /// Si true : afficher « Ouvrir les réglages » à côté du message.
  bool statusNeedsSettings = false;

  /// Information neutre (recherche QR, connexion en cours…).
  String? info;

  /// Demande entrante en attente de validation (côté hôte).
  PendingConnection? pending;

  /// Code de vérification côté demandeur.
  String? outgoingCode;

  String? _rid;
  Timer? _connectTimer;
  Timer? _restartTimer;
  bool _starting = false;
  bool _initDone = false;

  final _payloadCtrl = StreamController<(String, Payload)>.broadcast();
  final _progressCtrl = StreamController<(String, PayloadTransferUpdate)>.broadcast();
  Stream<(String, Payload)> get onPayload => _payloadCtrl.stream;
  Stream<(String, PayloadTransferUpdate)> get onProgress => _progressCtrl.stream;

  List<Peer> get peers => _peers.values.toList();
  bool get isConnected => connectedId != null;
  String get connectedName => _peers[connectedId]?.name ?? 'Appareil';

  static bool get supported => Platform.isAndroid;

  // ---------------------------------------------------------------- init
  Future<void> init() async {
    if (_initDone || !supported) return;
    final a = await DeviceInfoPlugin().androidInfo;
    String? custom;
    try {
      custom = (await SharedPreferences.getInstance()).getString('device_name');
    } catch (_) {}
    deviceName = (custom != null && custom.trim().isNotEmpty)
        ? custom
        : '${a.brand} ${a.model}'.replaceAll('#', '');
    _sdk = a.version.sdkInt;
    _initDone = true;
    notifyListeners();
  }

  int _sdk = 0;

  /// Change le nom affiché sur les autres appareils.
  Future<void> renameDevice(String raw) async {
    var name = raw.replaceAll('#', '').trim();
    if (name.length > 30) name = name.substring(0, 30);
    if (name.isEmpty) return;
    deviceName = name;
    try {
      (await SharedPreferences.getInstance()).setString('device_name', name);
    } catch (_) {}
    notifyListeners();
    if (!isConnected) await restart();
  }

  void _setStatus(String? msg, {bool settings = false}) {
    status = msg;
    statusNeedsSettings = settings;
    notifyListeners();
  }

  /// Traduit une erreur Nearby en consigne compréhensible.
  String _explain(Object e) {
    final s = e.toString().toUpperCase();
    if (s.contains('BLUETOOTH') || s.contains('RADIO')) {
      return 'Bluetooth ou Wi-Fi désactivé : activez-les, puis touchez « Réessayer ».';
    }
    if (s.contains('PERMISSION')) {
      return 'Une permission manque : ouvrez les réglages de l\u2019appli.';
    }
    if (s.contains('LOCATION')) {
      return 'Activez la localisation (GPS) : Android l\u2019exige pour détecter les appareils proches.';
    }
    return 'Erreur de détection : $e';
  }

  // ------------------------------------------------------- permissions
  /// Vérifie tout ce dont Nearby a besoin pour DÉTECTER les appareils :
  ///  1. permissions d'exécution (selon la version d'Android),
  ///  2. service de localisation (GPS) activé — requis par le scan Bluetooth.
  /// Le Bluetooth lui-même est signalé par _explain() s'il est éteint.
  Future<bool> ensureReady() async {
    if (!supported) return false;
    await init();

    final critical = <Permission>[
      Permission.location,
      if (_sdk >= 31) ...[
        Permission.bluetoothScan,
        Permission.bluetoothAdvertise,
        Permission.bluetoothConnect,
      ],
    ];
    final all = <Permission>[
      ...critical,
      if (_sdk >= 33) Permission.nearbyWifiDevices,
    ];

    final res = await all.request();
    final missing = critical.where((p) => !(res[p]?.isGranted ?? false)).toList();
    if (missing.isNotEmpty) {
      final blocked = missing.any((p) => res[p]?.isPermanentlyDenied ?? false);
      _setStatus(
        blocked
            ? 'Permissions bloquées. Ouvrez les réglages de l\u2019appli → Autorisations, '
                'puis activez « Appareils à proximité » et « Localisation ».'
            : 'LocalShare a besoin des permissions « Appareils à proximité » et « Localisation » '
                'pour détecter les appareils.',
        settings: blocked,
      );
      return false;
    }

    // Localisation (GPS) activée ? (checkLocationEnabled/enableLocationServices
    // n'existent plus dans nearby_connections 4.x -> permission_handler.)
    if (!await Permission.location.serviceStatus.isEnabled) {
      _setStatus(
        'La localisation (GPS) est désactivée. Android l\u2019exige pour détecter '
        'les appareils proches (aucune position n\u2019est utilisée). '
        'Activez-la dans les réglages rapides, puis touchez « Réessayer ».',
      );
      return false;
    }
    return true;
  }

  static String _randomHex(int n) {
    final r = Random.secure();
    return List.generate(n, (_) => r.nextInt(16).toRadixString(16)).join();
  }

  // ------------------------------------------------- démarrage automatique
  /// Visible + en recherche, en une seule action. Appelée au lancement, au
  /// retour dans l'appli, après une déconnexion et par le bouton « Réessayer ».
  Future<void> start() async {
    if (!supported || _starting || isConnected) return;
    _starting = true;
    try {
      if (!await ensureReady()) return;
      status = CrashGuard.notice;
      statusNeedsSettings = false;
      if (wantVisible && !isAdvertising) await _advertise();
      if (wantDiscover && !isDiscovering) await _discover();
      if (isAdvertising || isDiscovering) {
        await BackgroundService.start(
          isAdvertising ? 'Visible comme « $deviceName »' : 'Recherche d\u2019appareils…',
        );
      }
    } finally {
      _starting = false;
      notifyListeners();
    }
  }

  /// Relance complète (bouton « Actualiser » / « Réessayer »).
  Future<void> restart() async {
    if (isConnected) return;
    try {
      await _nearby.stopAdvertising();
      await _nearby.stopDiscovery();
    } catch (_) {}
    isAdvertising = false;
    isDiscovering = false;
    wantDiscover = true;
    _peers.removeWhere((_, p) => p.state != PeerState.connected);
    notifyListeners();
    await start();
  }

  void _scheduleRestart() {
    _restartTimer?.cancel();
    _restartTimer = Timer(const Duration(milliseconds: 800), start);
  }

  // ------------------------------------------------------- advertising (visible)
  Future<void> _advertise() async {
    _rid = _randomHex(4);
    try {
      await _nearby.stopAdvertising();
      isAdvertising = await CrashGuard.run(
            'advertise',
            () => _nearby.startAdvertising(
              Protocol.joinName(deviceName, _rid!),
              _strategy,
              serviceId: _serviceId,
              onConnectionInitiated: _onConnectionInitiated,
              onConnectionResult: _onConnectionResult,
              onDisconnected: _onDisconnected,
            ),
          ) ??
          false;
    } catch (e) {
      debugPrint('startAdvertising error: $e');
      isAdvertising = false;
      _setStatus(_explain(e));
    }
    if (!isAdvertising) _rid = null;
    notifyListeners();
  }

  /// Active / désactive la visibilité (l'utilisateur seul peut la couper).
  Future<void> setVisible(bool v) async {
    wantVisible = v;
    if (v) {
      if (await ensureReady()) await _advertise();
    } else {
      try {
        await _nearby.stopAdvertising();
      } catch (_) {}
      isAdvertising = false;
      _rid = null;
    }
    notifyListeners();
  }

  Future<void> stopAdvertising() => setVisible(false);

  // --------------------------------------------------------- discovery (recherche)
  Future<void> _discover() async {
    try {
      await _nearby.stopDiscovery();
      isDiscovering = await CrashGuard.run('discover', () => _nearby.startDiscovery(
        Protocol.joinName(deviceName, ''),
        _strategy,
        serviceId: _serviceId,
        onEndpointFound: (id, rawName, _) {
          final (display, rid) = Protocol.splitName(rawName);
          final existing = _peers[id];
          if (existing == null) {
            _peers[id] = Peer(id, display, rid: rid);
          }
          notifyListeners();
        },
        onEndpointLost: (id) {
          if (id != null && _peers[id]?.state != PeerState.connected) _peers.remove(id);
          notifyListeners();
        },
      )) ?? false;
    } catch (e) {
      debugPrint('startDiscovery error: $e');
      isDiscovering = false;
      _setStatus(_explain(e));
    }
    notifyListeners();
  }

  // ------------------------------------------------------------- connexion
  Future<void> connectTo(Peer peer) async {
    if (peer.state == PeerState.connecting || isConnected) return;
    peer.state = PeerState.connecting;
    status = null;
    info = 'Demande envoyée à ${peer.name}…';
    notifyListeners();

    _connectTimer?.cancel();
    _connectTimer = Timer(const Duration(seconds: 45), () {
      if (!isConnected && peer.state == PeerState.connecting) {
        peer.state = PeerState.discovered;
        outgoingCode = null;
        info = null;
        _nearby.disconnectFromEndpoint(peer.id);
        _setStatus('${peer.name} n\u2019a pas répondu.');
      }
    });

    try {
      await _nearby.requestConnection(
        Protocol.joinName(deviceName, ''),
        peer.id,
        onConnectionInitiated: _onConnectionInitiated,
        onConnectionResult: _onConnectionResult,
        onDisconnected: _onDisconnected,
      );
      role = NearbyRole.client;
    } catch (e) {
      _connectTimer?.cancel();
      peer.state = PeerState.discovered;
      info = null;
      debugPrint('requestConnection error: $e');
      _setStatus(_explain(e));
    }
  }

  void _onConnectionInitiated(String id, ConnectionInfo infoNearby) {
    final (name, _) = Protocol.splitName(infoNearby.endpointName);
    final peer = _peers.putIfAbsent(id, () => Peer(id, name));
    peer.state = PeerState.connecting;

    final incoming = infoNearby.isIncomingConnection;
    if (incoming) role = NearbyRole.host;

    // Toute demande entrante passe par une confirmation avec code.
    final trusted = !incoming;
    if (trusted) {
      _accept(id);
    } else {
      pending = PendingConnection(id, name, infoNearby.authenticationToken);
      // Notification avec boutons, même si l'appli est en arrière-plan.
      NotificationService.showConnectionRequest(name, infoNearby.authenticationToken);
    }
    if (!incoming) outgoingCode = infoNearby.authenticationToken;
    notifyListeners();
  }

  void _accept(String id) {
    _nearby.acceptConnection(
      id,
      onPayLoadRecieved: (endpointId, payload) => _payloadCtrl.add((endpointId, payload)),
      onPayloadTransferUpdate: (endpointId, update) => _progressCtrl.add((endpointId, update)),
    );
  }

  void acceptPending() {
    final pc = pending;
    if (pc == null) return;
    pending = null;
    NotificationService.cancel(NotificationService.idRequest);
    _accept(pc.id);
    notifyListeners();
  }

  void rejectPending() {
    final pc = pending;
    if (pc == null) return;
    pending = null;
    NotificationService.cancel(NotificationService.idRequest);
    _nearby.rejectConnection(pc.id);
    _peers.remove(pc.id);
    notifyListeners();
  }

  void _onConnectionResult(String id, Status result) {
    _connectTimer?.cancel();
    NotificationService.cancel(NotificationService.idRequest);
    pending = null;
    outgoingCode = null;
    info = null;

    if (result == Status.CONNECTED) {
      connectedId = id;
      _peers[id]?.state = PeerState.connected;
      status = null;
      statusNeedsSettings = false;
      _nearby.stopAdvertising();
      _nearby.stopDiscovery();
      isAdvertising = isDiscovering = false;
      _rid = null;
      BackgroundService.start('Connecté à $connectedName');
      BackgroundService.requestBatteryExemption();
    } else {
      _peers[id]?.state = PeerState.discovered;
      status = 'Connexion refusée ou échouée.';
      statusNeedsSettings = false;
      role = NearbyRole.none;
    }
    notifyListeners();
  }

  void _onDisconnected(String id) {
    if (connectedId == id) {
      connectedId = null;
      role = NearbyRole.none;
      _peers.remove(id);
      BackgroundService.start('Reconnexion…');
      _scheduleRestart();
    } else {
      _peers.remove(id);
    }
    notifyListeners();
  }

  Future<void> disconnect() async {
    final id = connectedId;
    if (id != null) await _nearby.disconnectFromEndpoint(id);
    await _nearby.stopAllEndpoints();
    connectedId = null;
    role = NearbyRole.none;
    isAdvertising = isDiscovering = false;
    _rid = null;
    _peers.clear();
    notifyListeners();
    _scheduleRestart();
  }

  /// Arrêt complet (menu « Quitter »).
  Future<void> shutdown() async {
    _connectTimer?.cancel();
    _restartTimer?.cancel();
    try {
      await _nearby.stopAdvertising();
      await _nearby.stopDiscovery();
      await _nearby.stopAllEndpoints();
    } catch (_) {}
    connectedId = null;
    isAdvertising = isDiscovering = false;
    _peers.clear();
    notifyListeners();
  }

  // --------------------------------------------------------------- envoi
  Future<void> sendBytes(Uint8List data) async {
    if (connectedId != null) await _nearby.sendBytesPayload(connectedId!, data);
  }

  Future<void> cancelPayload(int id) async {
    try {
      await _nearby.cancelPayload(id);
    } catch (e) {
      debugPrint('cancelPayload: $e');
    }
  }

  Future<int?> sendFile(String path) async {
    if (connectedId == null) return null;
    return _nearby.sendFilePayload(connectedId!, path);
  }

  Future<bool> moveReceivedFile(String sourceUri, String destPath) =>
      _nearby.copyFileAndDeleteOriginal(sourceUri, destPath);

  @override
  void dispose() {
    _connectTimer?.cancel();
    _restartTimer?.cancel();
    _payloadCtrl.close();
    _progressCtrl.close();
    super.dispose();
  }
}
