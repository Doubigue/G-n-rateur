import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';

/// Protection anti-plantage : avant chaque étape « native » risquée on écrit
/// son nom dans un fichier. Si l'appli est tuée pendant l'étape, le nom reste
/// là ; au lancement suivant l'étape fautive est désactivée (au lieu de
/// replanter en boucle) et un message l'indique.
class CrashGuard {
  CrashGuard._();

  static File? _mark;
  static File? _off;
  static final Set<String> disabled = {};
  static String? notice;

  /// Journal système du plantage précédent (lu une seule fois, à afficher).
  static String? report;
  static const _version = '4';
  static int _token = 0;

  static const _labels = {
    'notifications': 'les notifications',
    'advertise': 'la visibilité (advertising)',
    'discover': 'la recherche d\u2019appareils',
    'foreground_service': 'le service d\u2019arrière-plan',
  };

  static Future<void> init() async {
    try {
      final d = await getApplicationDocumentsDirectory();
      _mark = File('${d.path}/boot_step.txt');
      _off = File('${d.path}/disabled_steps.txt');
      // Nouvelle version de l'appli : on réessaie tout depuis zéro.
      final ver = File('${d.path}/guard_version.txt');
      if (!await ver.exists() || (await ver.readAsString()).trim() != _version) {
        for (final f in [_off!, _mark!]) {
          if (await f.exists()) await f.delete();
        }
        await ver.writeAsString(_version, flush: true);
      }
      if (await _off!.exists()) {
        disabled.addAll((await _off!.readAsLines()).where((l) => l.trim().isNotEmpty));
      }
      if (await _mark!.exists()) {
        final s = (await _mark!.readAsString()).trim();
        if (s.isNotEmpty && s != 'ok') {
          disabled.add(s);
          report = await _collectLog(s);
          await _off!.writeAsString(disabled.join('\n'), flush: true);
          await _mark!.writeAsString('ok', flush: true);
        }
      }
      if (disabled.isNotEmpty) {
        notice = 'Protection anti-plantage : ${disabled.map((e) => _labels[e] ?? e).join(', ')} '
            '${disabled.length > 1 ? 'ont été désactivés' : 'a été désactivé'} car '
            '${disabled.length > 1 ? 'ils ont' : 'il a'} fait fermer l\u2019appli. '
            'Étape fautive : ${disabled.join(', ')}.';
      }
    } catch (e) {
      debugPrint('CrashGuard.init: $e');
    }
  }

  /// Lit les journaux Android de NOTRE appli (autorisé : même UID), y compris
  /// ceux du processus qui vient de planter, et en garde l'essentiel.
  static Future<String> _collectLog(String step) async {
    final b = StringBuffer('Étape : $step\n');
    try {
      final crash = await Process.run('logcat', ['-d', '-b', 'crash', '-v', 'threadtime', '-t', '120']);
      b.writeln('--- crash ---');
      b.writeln(crash.stdout.toString().trim());
      final main = await Process.run('logcat', ['-d', '-b', 'main', '-v', 'threadtime', '-t', '1500']);
      final re = RegExp(r'AndroidRuntime|FATAL|Exception|Caused by|ForegroundService|Nearby|nearby|Permission|SecurityException');
      final lines = main.stdout.toString().split('\n').where(re.hasMatch).toList();
      b.writeln('--- main (filtré) ---');
      b.writeln(lines.skip(lines.length > 80 ? lines.length - 80 : 0).join('\n'));
    } catch (e) {
      b.writeln('Lecture du journal impossible : $e');
    }
    var out = b.toString();
    if (out.length > 9000) out = out.substring(out.length - 9000);
    try {
      final d = await getApplicationDocumentsDirectory();
      await File('${d.path}/crash_report.txt').writeAsString(out, flush: true);
    } catch (_) {}
    return out;
  }

  static Future<void> _write(String s) async {
    try {
      await _mark?.writeAsString(s, flush: true);
    } catch (_) {}
  }

  /// Exécute [fn] sous surveillance. Retourne null si l'étape est désactivée.
  static Future<T?> run<T>(String step, Future<T> Function() fn) async {
    if (disabled.contains(step)) return null;
    final my = ++_token;
    await _write(step);
    try {
      return await fn();
    } finally {
      // Un crash natif arrive parfois quelques ms après le retour : on attend.
      Future.delayed(const Duration(seconds: 4), () {
        if (_token == my) _write('ok');
      });
    }
  }
}
