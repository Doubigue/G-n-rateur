import 'dart:async';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:nearby_connections/nearby_connections.dart';
import 'package:path/path.dart' as p;
import 'nearby_service.dart';
import 'notification_service.dart';
import 'protocol.dart';
import 'storage_service.dart';

enum TransferStatus { inProgress, done, failed }

/// Un transfert. Chaque transfert notifie SES propres écouteurs (sa ligne dans
/// la liste), de façon limitée (≈5 fois/s) : la progression ne reconstruit plus
/// tout l'écran à chaque paquet reçu, c'était la cause principale des saccades.
class TransferItem extends ChangeNotifier {
  TransferItem({
    required this.payloadId,
    required this.name,
    required this.outgoing,
    this.total = 0,
  });
  final int payloadId;
  String name;
  final bool outgoing;
  int total;
  int transferred = 0;
  TransferStatus status = TransferStatus.inProgress;
  String? savedPath; // destination finale dans DoubigueShare (réception)
  final DateTime created = DateTime.now();

  /// Vitesse moyenne en octets/s (0 tant qu'on ne peut pas l'estimer).
  double get speed {
    final ms = DateTime.now().difference(created).inMilliseconds;
    if (ms < 700 || transferred <= 0) return 0;
    return transferred * 1000 / ms;
  }

  /// Temps restant estimé.
  Duration? get eta {
    final s = speed;
    if (s <= 0 || total <= transferred) return null;
    return Duration(seconds: ((total - transferred) / s).ceil());
  }

  int _lastNotify = 0;

  double get progress => total == 0 ? 0 : (transferred / total).clamp(0.0, 1.0);

  void setProgress(int done, int tot, {bool force = false}) {
    if (tot > 0) total = tot;
    transferred = done;
    final now = DateTime.now().millisecondsSinceEpoch;
    if (force || now - _lastNotify >= 200) {
      _lastNotify = now;
      notifyListeners();
    }
  }

  void touch() => notifyListeners();
}

/// Un message texte échangé (envoyé ou reçu).
class TextItem {
  TextItem(this.text, {required this.outgoing});
  final String text;
  final bool outgoing;
  final DateTime created = DateTime.now();
}

/// Envoi / réception de fichiers via les payloads Nearby.
/// Les fichiers reçus sont rangés dans <stockage>/DoubigueShare.
class FileTransferService extends ChangeNotifier {
  FileTransferService(this._nearby) {
    _subs.add(_nearby.onPayload.listen(_onPayload));
    _subs.add(_nearby.onProgress.listen(_onProgress));
  }

  final NearbyService _nearby;
  final List<StreamSubscription> _subs = [];
  final Map<int, TransferItem> _items = {};
  final Map<int, String> _names = {};
  final Map<int, String> _sources = {};
  final List<TextItem> _texts = [];

  // Lots en cours (un pour l'envoi, un pour la réception) : une seule
  // notification de progression par sens, quel que soit le nombre de fichiers.
  final Map<bool, List<TransferItem>> _batch = {true: [], false: []};
  Timer? _notifTimer;

  List<TransferItem> get items => _items.values.toList().reversed.toList();

  /// Transferts + messages texte, du plus récent au plus ancien.
  List<Object> get feed {
    final all = <Object>[..._items.values, ..._texts];
    DateTime t(Object o) => o is TransferItem ? o.created : (o as TextItem).created;
    all.sort((a, b) => t(b).compareTo(t(a)));
    return all;
  }

  // ------------------------------------------------------------------ texte
  Future<void> sendText(String raw) async {
    var text = raw.trim();
    if (text.isEmpty) return;
    if (text.length > 6000) text = text.substring(0, 6000);
    await _nearby.sendBytes(Protocol.encode({'t': 'text', 'm': text}));
    _texts.add(TextItem(text, outgoing: true));
    notifyListeners();
  }

  /// Annule un transfert en cours.
  Future<void> cancel(TransferItem item) async {
    if (item.status != TransferStatus.inProgress) return;
    await _nearby.cancelPayload(item.payloadId);
    item.status = TransferStatus.failed;
    item.touch();
    notifyListeners();
    _pushNotifications();
  }

  // ------------------------------------------------------------------ envoi
  Future<void> pickAndSend() async {
    final res = await FilePicker.platform.pickFiles(allowMultiple: true);
    if (res == null) return;
    for (final f in res.files) {
      final path = f.path;
      if (path != null) await sendPath(path);
    }
  }

  /// Envoie un fichier local (utilisé aussi quand l'autre appareil en télécharge un).
  Future<void> sendPath(String path) async {
    final file = File(path);
    if (!await file.exists()) return;
    final size = await file.length();
    final name = p.basename(path);

    final id = await _nearby.sendFile(path);
    if (id == null) return;

    final item = TransferItem(payloadId: id, name: name, outgoing: true, total: size);
    _items[id] = item;
    _batch[true]!.add(item);
    notifyListeners();
    _pushNotifications();

    await _nearby.sendBytes(
      Protocol.encode({'t': 'file', 'id': id, 'name': name, 'size': size}),
    );
  }

  // -------------------------------------------------------------- réception
  void _onPayload((String, Payload) event) {
    try {
      _handlePayload(event.$2);
    } catch (e, st) {
      // Un message ou fichier inattendu ne doit jamais faire tomber l'appli.
      debugPrint('onPayload error: $e\n$st');
    }
  }

  void _handlePayload(Payload payload) {
    if (payload.type == PayloadType.BYTES) {
      final msg = Protocol.decode(payload);
      if (msg == null) return;

      if (msg['t'] == 'text') {
        final m = msg['m'];
        if (m is String && m.trim().isNotEmpty) {
          _texts.add(TextItem(m, outgoing: false));
          HapticFeedback.mediumImpact();
          NotificationService.showDone(
            outgoing: false,
            title: 'Message reçu',
            body: m.length > 120 ? '${m.substring(0, 120)}…' : m,
            payload: 'transfer',
          );
          notifyListeners();
        }
        return;
      }

      if (msg['t'] != 'file') return;
      final idRaw = msg['id'];
      final nameRaw = msg['name'];
      if (idRaw is! num || nameRaw is! String) return;
      final id = idRaw.toInt();
      _names[id] = nameRaw;
      final item = _items[id];
      if (item != null) {
        item.name = _safeName(nameRaw);
        final sz = msg['size'];
        if (sz is num && item.total == 0) item.total = sz.toInt();
        item.touch();
      }
    } else if (payload.type == PayloadType.FILE) {
      final u = payload.uri;
      // ignore: deprecated_member_use
      _sources[payload.id] = (u != null && u.isNotEmpty) ? u : (payload.filePath ?? '');
      final item = TransferItem(
        payloadId: payload.id,
        name: _names[payload.id] != null ? _safeName(_names[payload.id]!) : 'Réception…',
        outgoing: false,
      );
      _items[payload.id] = item;
      _batch[false]!.add(item);
      notifyListeners();
      _pushNotifications();
    }
  }

  Future<void> _onProgress((String, PayloadTransferUpdate) event) async {
    final u = event.$2;
    final item = _items[u.id];
    if (item == null) return;

    switch (u.status) {
      case PayloadStatus.IN_PROGRESS:
        item.setProgress(u.bytesTransferred, u.totalBytes);
        _scheduleNotifications();
        return;
      case PayloadStatus.SUCCESS:
        final total = u.totalBytes > 0 ? u.totalBytes : item.total;
        item.setProgress(total, total, force: true);
        if (item.outgoing) {
          item.status = TransferStatus.done;
        } else {
          await _saveReceived(item);
          if (item.status == TransferStatus.done) HapticFeedback.mediumImpact();
        }
        break;
      case PayloadStatus.FAILURE:
      case PayloadStatus.CANCELED:
        item.status = TransferStatus.failed;
        break;
      default:
        return;
    }
    item.touch();
    notifyListeners();
    _pushNotifications();
  }

  // ---------------------------------------------------------- notifications
  /// Android limite le rythme des mises à jour de notification : on les groupe.
  void _scheduleNotifications() {
    if (_notifTimer != null) return;
    _notifTimer = Timer(const Duration(milliseconds: 700), () {
      _notifTimer = null;
      _pushNotifications();
    });
  }

  void _pushNotifications() {
    for (final outgoing in const [true, false]) {
      final batch = _batch[outgoing]!;
      if (batch.isEmpty) continue;
      final progressId =
          outgoing ? NotificationService.idSendProgress : NotificationService.idReceiveProgress;
      final active = batch.where((i) => i.status == TransferStatus.inProgress).toList();

      if (active.isNotEmpty) {
        final total = batch.fold<int>(0, (a, i) => a + i.total);
        final done = batch.fold<int>(0, (a, i) => a + i.transferred);
        final pct = total > 0 ? (done * 100 ~/ total) : 0;
        final title = outgoing ? 'Envoi en cours' : 'Réception en cours';
        final what = batch.length == 1 ? batch.first.name : '${batch.length} fichiers';
        NotificationService.showProgress(
          outgoing: outgoing,
          title: title,
          body: total > 0 ? '$what · $pct %' : what,
          percent: pct,
          indeterminate: total == 0,
        );
        continue;
      }

      // Lot terminé : on remplace la progression par un résumé.
      NotificationService.cancel(progressId);
      final ok = batch.where((i) => i.status == TransferStatus.done).toList();
      final failed = batch.length - ok.length;
      final single = batch.length == 1;
      final title = failed == batch.length
          ? (outgoing ? 'Échec de l\u2019envoi' : 'Échec de la réception')
          : (outgoing ? 'Envoi terminé' : 'Réception terminée');
      final body = single
          ? batch.first.name
          : '${ok.length} fichier(s)${failed > 0 ? ' · $failed en échec' : ''}';
      final path = (!outgoing && single) ? batch.first.savedPath : null;
      NotificationService.showDone(
        outgoing: outgoing,
        title: title,
        body: body,
        payload: path != null ? 'open:$path' : 'transfer',
      );
      batch.clear();
      if (outgoing) {
        // Copies temporaires créées par le sélecteur de fichiers : inutiles.
        FilePicker.platform.clearTemporaryFiles().catchError((_) => null);
      }
    }
  }

  // ------------------------------------------------------------------ fichiers
  /// Le nom vient de l'autre appareil : on ne garde que le nom de fichier
  /// (protège contre « ../../ » et caractères interdits).
  String _safeName(String raw) {
    var n = p.basename(raw.replaceAll('\\', '/')).replaceAll(RegExp(r'[<>:"|?*\x00-\x1F]'), '_').trim();
    if (n.isEmpty || n == '.' || n == '..') n = 'fichier';
    return n;
  }

  Future<void> _saveReceived(TransferItem item) async {
    try {
      final dir = await StorageService.shareDir();

      // Les métadonnées (nom) peuvent arriver juste après un très petit fichier.
      for (var i = 0; i < 30 && !_names.containsKey(item.payloadId); i++) {
        await Future.delayed(const Duration(milliseconds: 100));
      }
      final name = _safeName(_names[item.payloadId] ?? 'fichier_${item.payloadId}');
      item.name = name;
      final dest = _uniquePath(dir.path, name);

      final src = _sources[item.payloadId] ?? '';
      bool ok;
      if (src.startsWith('/')) {
        // Android 9 et moins : chemin classique, copie directe.
        try {
          await File(src).copy(dest);
          try {
            await File(src).delete();
          } catch (_) {}
          ok = true;
        } catch (e) {
          debugPrint('copy legacy error: $e');
          ok = false;
        }
      } else {
        ok = await _nearby.moveReceivedFile(src, dest);
      }
      item.savedPath = ok ? dest : null;
      item.status = ok ? TransferStatus.done : TransferStatus.failed;
    } catch (e) {
      debugPrint('saveReceived error: $e');
      item.status = TransferStatus.failed;
    }
  }

  String _uniquePath(String dir, String name) {
    var path = '$dir/$name';
    var i = 1;
    final dot = name.lastIndexOf('.');
    final stem = dot > 0 ? name.substring(0, dot) : name;
    final ext = dot > 0 ? name.substring(dot) : '';
    while (File(path).existsSync()) {
      path = '$dir/$stem ($i)$ext';
      i++;
    }
    return path;
  }

  @override
  void dispose() {
    _notifTimer?.cancel();
    for (final s in _subs) {
      s.cancel();
    }
    super.dispose();
  }
}
