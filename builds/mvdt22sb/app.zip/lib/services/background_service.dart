import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'crash_guard.dart';

/// Service au premier plan : garde l'appli (visibilité, connexion, transferts)
/// active quand on quitte l'écran. Une notification discrète reste affichée.
class BackgroundService {
  BackgroundService._();

  static bool _inited = false;
  static bool _batteryAsked = false;

  static void _init() {
    if (_inited) return;
    _inited = true;
    FlutterForegroundTask.init(
      androidNotificationOptions: AndroidNotificationOptions(
        channelId: 'localshare_keepalive',
        channelName: 'LocalShare actif',
        channelDescription: 'Garde LocalShare joignable en arrière-plan',
        channelImportance: NotificationChannelImportance.LOW,
        priority: NotificationPriority.LOW,
      ),
      iosNotificationOptions: const IOSNotificationOptions(),
      foregroundTaskOptions: ForegroundTaskOptions(
        eventAction: ForegroundTaskEventAction.nothing(),
        allowWakeLock: true,
        allowWifiLock: true,
      ),
    );
  }

  /// Démarre le service, ou met à jour le texte de sa notification.
  static Future<void> start(String text) async {
    if (!Platform.isAndroid) return;
    try {
      await CrashGuard.run('foreground_service', () async {
        _init();
        if (await FlutterForegroundTask.isRunningService) {
          await FlutterForegroundTask.updateService(
            notificationTitle: 'LocalShare',
            notificationText: text,
          );
          return;
        }
        await FlutterForegroundTask.startService(
          serviceId: 7001,
          notificationTitle: 'LocalShare',
          notificationText: text,
          serviceTypes: [ForegroundServiceTypes.connectedDevice],
        );
      });
    } catch (e) {
      debugPrint('BackgroundService.start error: $e');
    }
  }

  static Future<void> stop() async {
    if (!Platform.isAndroid) return;
    try {
      if (await FlutterForegroundTask.isRunningService) {
        await FlutterForegroundTask.stopService();
      }
    } catch (_) {}
  }

  /// Une seule fois par lancement : sur certains téléphones (Xiaomi, Huawei,
  /// Samsung…) l'économie de batterie tue l'appli en arrière-plan.
  static Future<void> requestBatteryExemption() async {
    if (!Platform.isAndroid || _batteryAsked) return;
    _batteryAsked = true;
    try {
      if (!await FlutterForegroundTask.isIgnoringBatteryOptimizations) {
        await FlutterForegroundTask.requestIgnoreBatteryOptimization();
      }
    } catch (_) {}
  }

  /// Met l'appli en arrière-plan SANS la fermer (le bouton « retour » ferme
  /// l'activité Android, ce qui couperait Nearby).
  static void minimize() {
    if (Platform.isAndroid) FlutterForegroundTask.minimizeApp();
  }
}
