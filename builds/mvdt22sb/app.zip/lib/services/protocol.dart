import 'dart:convert';
import 'dart:typed_data';
import 'package:nearby_connections/nearby_connections.dart';

/// Messages JSON échangés en BYTES payload (max 32 Ko par message).
///   {"t":"file","id":<payloadId>,"name":"x.mp4","size":123}        métadonnées fichier
///   {"t":"fs_req"}                    demande d'accès aux fichiers
///   {"t":"fs_grant","ok":true|false}  réponse (autorisé / refusé)
///   {"t":"fs_revoke"}                 accès révoqué par le propriétaire
///   {"t":"ls","r":<req>,"p":"/chemin"}                             lister un dossier
///   {"t":"ls_r","r":<req>,"p":"/chemin","pg":0,"more":true,"e":[{"n","d","s","m"}],"err":"…"}
///   {"t":"get","p":"/chemin/fichier"}                              télécharger un fichier
class Protocol {
  static Uint8List encode(Map<String, dynamic> m) =>
      Uint8List.fromList(utf8.encode(jsonEncode(m)));

  /// Retourne null si le payload n'est pas un message JSON valide.
  static Map<String, dynamic>? decode(Payload p) {
    if (p.type != PayloadType.BYTES || p.bytes == null) return null;
    try {
      final d = jsonDecode(utf8.decode(p.bytes!));
      return d is Map<String, dynamic> ? d : null;
    } catch (_) {
      return null;
    }
  }

  /// Nom d'endpoint Nearby = "<nom>#<jeton>" (jeton = rid public ou secret QR).
  static String joinName(String name, String token) => '$name#$token';

  static (String, String) splitName(String raw) {
    final i = raw.lastIndexOf('#');
    if (i < 0) return (raw, '');
    return (raw.substring(0, i), raw.substring(i + 1));
  }
}
