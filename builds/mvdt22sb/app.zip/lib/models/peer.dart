enum PeerState { discovered, connecting, connected }

class Peer {
  final String id;
  final String name;

  /// Identifiant public court annoncé par l'hôte.
  final String rid;
  PeerState state;

  Peer(this.id, this.name, {this.rid = '', this.state = PeerState.discovered});
}
