import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path/path.dart' as p;
import 'package:pdfx/pdfx.dart';
import 'package:video_player/video_player.dart';
import '../utils/file_utils.dart';

/// Ouvre un fichier dans le lecteur intégré.
Future<void> openInApp(BuildContext context, String path) =>
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => FileViewerScreen(path: path)));

/// Lecteur intégré : images, vidéos, audio, PDF, texte.
/// Autres formats : proposition d'ouvrir avec une autre appli.
class FileViewerScreen extends StatelessWidget {
  const FileViewerScreen({super.key, required this.path});
  final String path;

  @override
  Widget build(BuildContext context) {
    final kind = kindOf(path);
    final dark = kind == FileKind.image || kind == FileKind.video;
    return Scaffold(
      backgroundColor: dark ? Colors.black : null,
      appBar: AppBar(
        backgroundColor: dark ? Colors.black : null,
        foregroundColor: dark ? Colors.white : null,
        title: Text(p.basename(path), overflow: TextOverflow.ellipsis),
        actions: [
          IconButton(
            tooltip: 'Ouvrir avec…',
            icon: const Icon(Icons.open_in_new),
            onPressed: () => OpenFilex.open(path),
          ),
        ],
      ),
      body: switch (kind) {
        FileKind.image => _ImageViewer(path: path),
        FileKind.video => _MediaViewer(path: path, audio: false),
        FileKind.audio => _MediaViewer(path: path, audio: true),
        FileKind.pdf => _PdfViewer(path: path),
        FileKind.text => _TextViewer(path: path),
        FileKind.other => _Unsupported(path: path),
      },
    );
  }
}

class _Unsupported extends StatelessWidget {
  const _Unsupported({required this.path});
  final String path;
  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.insert_drive_file_outlined, size: 72, color: Theme.of(context).colorScheme.outline),
            const SizedBox(height: 12),
            const Text('Ce format ne peut pas être lu directement dans l\u2019appli.',
                textAlign: TextAlign.center),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: () => OpenFilex.open(path),
              icon: const Icon(Icons.open_in_new),
              label: const Text('Ouvrir avec une autre appli'),
            ),
          ]),
        ),
      );
}

// ------------------------------------------------------------------ image
class _ImageViewer extends StatelessWidget {
  const _ImageViewer({required this.path});
  final String path;
  @override
  Widget build(BuildContext context) => InteractiveViewer(
        maxScale: 6,
        child: Center(
          child: Image.file(
            File(path),
            errorBuilder: (_, __, ___) => const Text('Image illisible',
                style: TextStyle(color: Colors.white)),
          ),
        ),
      );
}

// ------------------------------------------------------------ vidéo / audio
class _MediaViewer extends StatefulWidget {
  const _MediaViewer({required this.path, required this.audio});
  final String path;
  final bool audio;
  @override
  State<_MediaViewer> createState() => _MediaViewerState();
}

class _MediaViewerState extends State<_MediaViewer> {
  late final VideoPlayerController _c = VideoPlayerController.file(File(widget.path));
  bool _ready = false;
  bool _failed = false;

  @override
  void initState() {
    super.initState();
    _c.addListener(_tick);
    _c.initialize().then((_) {
      if (!mounted) return;
      setState(() => _ready = true);
      _c.play();
    }).catchError((_) {
      if (mounted) setState(() => _failed = true);
    });
  }

  void _tick() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _c.removeListener(_tick);
    _c.dispose();
    super.dispose();
  }

  String _t(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return d.inHours > 0 ? '${d.inHours}:$m:$s' : '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    final light = widget.audio ? null : Colors.white;
    if (_failed) return _Unsupported(path: widget.path);
    if (!_ready) return const Center(child: CircularProgressIndicator());

    final v = _c.value;
    final pos = v.position.inMilliseconds.toDouble();
    final dur = v.duration.inMilliseconds.toDouble();
    return Column(children: [
      Expanded(
        child: Center(
          child: widget.audio
              ? Icon(Icons.music_note_rounded, size: 120, color: Theme.of(context).colorScheme.primary)
              : GestureDetector(
                  onTap: () => v.isPlaying ? _c.pause() : _c.play(),
                  child: AspectRatio(aspectRatio: v.aspectRatio, child: VideoPlayer(_c)),
                ),
        ),
      ),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        child: Row(children: [
          Text(_t(v.position), style: TextStyle(color: light)),
          Expanded(
            child: Slider(
              value: pos.clamp(0.0, dur <= 0 ? 1.0 : dur).toDouble(),
              max: dur <= 0 ? 1 : dur,
              onChanged: (x) => _c.seekTo(Duration(milliseconds: x.toInt())),
            ),
          ),
          Text(_t(v.duration), style: TextStyle(color: light)),
        ]),
      ),
      Padding(
        padding: const EdgeInsets.only(bottom: 24),
        child: IconButton.filled(
          iconSize: 36,
          onPressed: () => v.isPlaying ? _c.pause() : _c.play(),
          icon: Icon(v.isPlaying ? Icons.pause : Icons.play_arrow),
        ),
      ),
    ]);
  }
}

// -------------------------------------------------------------------- PDF
class _PdfViewer extends StatefulWidget {
  const _PdfViewer({required this.path});
  final String path;
  @override
  State<_PdfViewer> createState() => _PdfViewerState();
}

class _PdfViewerState extends State<_PdfViewer> {
  late final PdfControllerPinch _pdf =
      PdfControllerPinch(document: PdfDocument.openFile(widget.path));

  @override
  void dispose() {
    _pdf.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Stack(children: [
      PdfViewPinch(
        controller: _pdf,
        onDocumentError: (_) {},
      ),
      Positioned(
        right: 16,
        bottom: 16,
        child: PdfPageNumber(
          controller: _pdf,
          builder: (context, state, page, pages) => Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: cs.inverseSurface.withOpacity(0.85),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Text('$page / ${pages ?? 0}', style: TextStyle(color: cs.onInverseSurface)),
          ),
        ),
      ),
    ]);
  }
}

// ------------------------------------------------------------------ texte
class _TextViewer extends StatelessWidget {
  const _TextViewer({required this.path});
  final String path;

  static const _max = 512 * 1024;

  Future<(String, bool)> _read() async {
    final f = File(path);
    final len = await f.length();
    final bytes = await f.openRead(0, _max).expand((x) => x).toList();
    return (utf8.decode(bytes, allowMalformed: true), len > _max);
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<(String, bool)>(
        future: _read(),
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final (text, truncated) = snap.data!;
          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              SelectableText(text, style: const TextStyle(fontFamily: 'monospace', fontSize: 13)),
              if (truncated)
                const Padding(
                  padding: EdgeInsets.only(top: 16),
                  child: Text('… fichier tronqué (aperçu des 512 premiers Ko)',
                      style: TextStyle(fontStyle: FontStyle.italic)),
                ),
            ]),
          );
        },
      );
}
