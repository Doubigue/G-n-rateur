import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/background_service.dart';
import '../services/file_transfer_service.dart';
import '../services/nearby_service.dart';
import '../services/remote_fs_service.dart';
import '../services/storage_service.dart';
import '../utils/file_utils.dart';
import 'file_viewer_screen.dart';
import 'received_screen.dart';
import 'remote_browser_screen.dart';

class TransferScreen extends StatefulWidget {
  const TransferScreen({
    super.key,
    required this.nearby,
    required this.files,
    required this.remote,
  });
  final NearbyService nearby;
  final FileTransferService files;
  final RemoteFsService remote;

  @override
  State<TransferScreen> createState() => _TransferScreenState();
}

class _TransferScreenState extends State<TransferScreen> {
  bool _askOpen = false;
  bool _leaving = false;
  BuildContext? _askCtx;
  late final String _peerName = widget.nearby.connectedName;

  @override
  void initState() {
    super.initState();
    widget.nearby.addListener(_watchConnection);
    widget.remote.addListener(_onRemote);
  }

  /// Retour automatique à l'accueil si l'autre appareil se déconnecte.
  void _watchConnection() {
    if (!widget.nearby.isConnected) _leave();
  }

  void _leave() {
    if (_leaving || !mounted) return;
    _leaving = true;
    Navigator.of(context).pop();
  }

  /// L'autre appareil demande à parcourir mes fichiers : consentement explicite
  /// (dialogue ici, ou boutons de la notification).
  void _onRemote() {
    if (!mounted) return;
    final r = widget.remote;

    if (!r.pendingRequest && _askOpen && _askCtx != null) {
      // Réponse donnée depuis la notification : on ferme le dialogue.
      if (_askCtx!.mounted) Navigator.of(_askCtx!).pop();
      return;
    }
    if (!r.pendingRequest || _askOpen) return;

    _askOpen = true;
    showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) {
        _askCtx = ctx;
        return AlertDialog(
          icon: const Icon(Icons.folder_shared_outlined, size: 36),
          title: const Text('Accès à vos fichiers'),
          content: Text(
            '« $_peerName » demande à parcourir et télécharger les fichiers de votre téléphone '
            '(stockage interne).\n\nVous pourrez révoquer l\u2019accès à tout moment.',
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Refuser')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Autoriser')),
          ],
        );
      },
    ).then((ok) async {
      _askOpen = false;
      _askCtx = null;
      if (ok == true) {
        await r.allow();
      } else if (ok == false) {
        await r.respond(false);
      }
    });
  }

  /// Envoie un texte (message, lien, code…) à l'autre appareil.
  Future<void> _sendText() async {
    final ctrl = TextEditingController();
    final text = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Envoyer à $_peerName'),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          minLines: 2,
          maxLines: 6,
          decoration: const InputDecoration(
            hintText: 'Texte, lien, code…',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () async {
              final d = await Clipboard.getData(Clipboard.kTextPlain);
              if (d?.text != null) ctrl.text = d!.text!;
            },
            child: const Text('Coller'),
          ),
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(ctx, ctrl.text), child: const Text('Envoyer')),
        ],
      ),
    );
    if (text != null && text.trim().isNotEmpty) await widget.files.sendText(text);
  }

  @override
  void dispose() {
    widget.nearby.removeListener(_watchConnection);
    widget.remote.removeListener(_onRemote);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final n = widget.nearby, files = widget.files, remote = widget.remote;

    return PopScope(
      // « Retour » met l'appli en arrière-plan : la connexion et les transferts continuent.
      // Pour couper : bouton « Se déconnecter ».
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) BackgroundService.minimize();
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text('Connecté à $_peerName'),
          actions: [
            IconButton(
              tooltip: 'Se déconnecter',
              icon: const Icon(Icons.link_off),
              onPressed: () async {
                await n.disconnect();
                _leave();
              },
            ),
          ],
        ),
        body: Column(
          children: [
            // Seules ces zones se reconstruisent sur un changement de connexion / d'accès.
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
              child: ListenableBuilder(
                listenable: remote,
                builder: (context, _) => Column(children: [
                  if (remote.accessGranted)
                    _Banner(
                      color: cs.tertiaryContainer,
                      onColor: cs.onTertiaryContainer,
                      icon: Icons.folder_shared,
                      text: '« $_peerName » a accès à vos fichiers.',
                      action: TextButton(onPressed: remote.revoke, child: const Text('Révoquer')),
                    ),
                  Row(children: [
                    Expanded(
                      child: _BigAction(
                        icon: Icons.upload_file,
                        title: 'Envoyer',
                        subtitle: 'Des fichiers',
                        onTap: files.pickAndSend,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _BigAction(
                        icon: Icons.chat_bubble_outline,
                        title: 'Texte',
                        subtitle: 'Message, lien…',
                        onTap: _sendText,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _BigAction(
                        icon: Icons.folder_shared_outlined,
                        title: 'Ses fichiers',
                        subtitle: 'Parcourir',
                        onTap: () => Navigator.of(context).push(MaterialPageRoute(
                          builder: (_) => RemoteBrowserScreen(remote: remote, peerName: _peerName),
                        )),
                      ),
                    ),
                  ]),
                ]),
              ),
            ),

            // ----- Transferts
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 24, 16, 8),
              child: Row(children: [
                const Expanded(
                  child: Text('Transferts', style: TextStyle(fontWeight: FontWeight.w600)),
                ),
                TextButton.icon(
                  onPressed: () => Navigator.of(context)
                      .push(MaterialPageRoute(builder: (_) => const ReceivedScreen())),
                  icon: const Icon(Icons.folder_special_outlined, size: 18),
                  label: const Text(StorageService.folderName),
                ),
              ]),
            ),
            // Liste paresseuse : seule la liste (pas l'écran) réagit aux nouveaux transferts ;
            // la progression, elle, ne touche que la ligne concernée.
            Expanded(
              child: ListenableBuilder(
                listenable: files,
                builder: (context, _) {
                  final items = files.feed;
                  if (items.isEmpty) {
                    return Center(child: Text('Aucun transfert', style: TextStyle(color: cs.outline)));
                  }
                  return ListView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                    itemCount: items.length,
                    itemBuilder: (_, i) {
                      final it = items[i];
                      if (it is TextItem) {
                        return _TextTile(key: ValueKey('t${it.created.microsecondsSinceEpoch}'), item: it);
                      }
                      final t = it as TransferItem;
                      return _TransferTile(
                        key: ValueKey(t.payloadId),
                        item: t,
                        onCancel: () => files.cancel(t),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Banner extends StatelessWidget {
  const _Banner({
    required this.color,
    required this.onColor,
    required this.icon,
    required this.text,
    this.action,
  });
  final Color color, onColor;
  final IconData icon;
  final String text;
  final Widget? action;

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.fromLTRB(14, 10, 8, 10),
        decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(14)),
        child: Row(children: [
          Icon(icon, color: onColor, size: 18),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: TextStyle(color: onColor, fontSize: 13))),
          if (action != null) action!,
        ]),
      );
}

class _BigAction extends StatelessWidget {
  const _BigAction({required this.icon, required this.title, required this.subtitle, required this.onTap});
  final IconData icon;
  final String title, subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Material(
      color: cs.surfaceContainerHigh,
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(icon, size: 26, color: cs.primary),
            const SizedBox(height: 10),
            Text(title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
            Text(subtitle,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: cs.outline, fontSize: 12)),
          ]),
        ),
      ),
    );
  }
}

/// Une ligne de transfert : écoute uniquement SON transfert (progression fluide,
/// sans reconstruire le reste de l'écran).
class _TransferTile extends StatelessWidget {
  const _TransferTile({super.key, required this.item, required this.onCancel});
  final TransferItem item;
  final VoidCallback onCancel;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return RepaintBoundary(
      child: ListenableBuilder(
        listenable: item,
        builder: (context, _) {
          final t = item;
          final inProgress = t.status == TransferStatus.inProgress;
          final canOpen = !t.outgoing && t.savedPath != null && t.status == TransferStatus.done;
          return Card(
            elevation: 0,
            color: cs.surfaceContainerHigh,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            child: InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: canOpen ? () => openInApp(context, t.savedPath!) : null,
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Icon(t.outgoing ? Icons.arrow_upward : Icons.arrow_downward,
                        size: 18, color: cs.primary),
                    const SizedBox(width: 8),
                    Expanded(child: Text(t.name, overflow: TextOverflow.ellipsis)),
                    if (inProgress)
                      IconButton(
                        tooltip: 'Annuler',
                        visualDensity: VisualDensity.compact,
                        icon: const Icon(Icons.close, size: 20),
                        onPressed: onCancel,
                      ),
                    if (canOpen) Icon(Icons.visibility_outlined, size: 20, color: cs.primary),
                    if (t.status == TransferStatus.done && !canOpen)
                      const Icon(Icons.check_circle, color: Colors.green, size: 20),
                    if (t.status == TransferStatus.failed)
                      Icon(Icons.error, color: cs.error, size: 20),
                  ]),
                  const SizedBox(height: 10),
                  LinearProgressIndicator(
                    value: inProgress ? t.progress : 1,
                    borderRadius: BorderRadius.circular(4),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    '${formatBytes(t.transferred)} / ${formatBytes(t.total)}'
                    '${inProgress ? "  •  ${(t.progress * 100).toStringAsFixed(0)} %" : ""}'
                    '${inProgress && t.speed > 0 ? "  •  ${formatBytes(t.speed.round())}/s" : ""}'
                    '${inProgress && t.eta != null ? "  •  ${_fmtEta(t.eta!)} restant" : ""}'
                    '${canOpen ? "  •  Touchez pour ouvrir" : ""}',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ]),
              ),
            ),
          );
        },
      ),
    );
  }
}

String _fmtEta(Duration d) {
  final s = d.inSeconds;
  return s < 60 ? '$s s' : '${s ~/ 60} min ${(s % 60).toString().padLeft(2, '0')} s';
}

/// Un message texte (envoyé ou reçu) : touchez l'icône pour le copier.
class _TextTile extends StatelessWidget {
  const _TextTile({super.key, required this.item});
  final TextItem item;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Card(
      elevation: 0,
      color: item.outgoing ? cs.primaryContainer : cs.surfaceContainerHigh,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(14, 8, 4, 8),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Padding(
            padding: const EdgeInsets.only(top: 10),
            child: Icon(item.outgoing ? Icons.arrow_upward : Icons.arrow_downward,
                size: 18, color: cs.primary),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: SelectableText(item.text),
            ),
          ),
          IconButton(
            tooltip: 'Copier',
            icon: const Icon(Icons.copy, size: 18),
            onPressed: () {
              Clipboard.setData(ClipboardData(text: item.text));
              ScaffoldMessenger.of(context)
                ..hideCurrentSnackBar()
                ..showSnackBar(const SnackBar(content: Text('Copié')));
            },
          ),
        ]),
      ),
    );
  }
}
