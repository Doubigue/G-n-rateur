import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';
import '../models/peer.dart';
import '../services/background_service.dart';
import '../services/crash_guard.dart';
import '../services/file_transfer_service.dart';
import '../services/nearby_service.dart';
import '../services/notification_service.dart';
import '../services/remote_fs_service.dart';
import '../services/storage_service.dart';
import '../widgets/radar_view.dart';
import 'received_screen.dart';
import 'transfer_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({
    super.key,
    required this.nearby,
    required this.files,
    required this.remote,
  });
  final NearbyService nearby;
  final FileTransferService files;
  final RemoteFsService remote;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with WidgetsBindingObserver {
  NearbyService get n => widget.nearby;
  bool _transferOpen = false;
  bool _pendingDialogOpen = false;
  BuildContext? _pendingCtx;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    n.addListener(_onChange);
    WidgetsBinding.instance.addPostFrameCallback((_) => _boot());
  }

  /// Au lancement : notifications → permissions + visible & recherche → accès fichiers.
  Future<void> _boot() async {
    await _showCrashReport();
    await NotificationService.requestPermission();
    await n.start();
    if (mounted) await _ensureStorage();
  }

  /// Si le lancement précédent a planté : affiche le journal à copier-coller.
  Future<void> _showCrashReport() async {
    final r = CrashGuard.report;
    if (r == null || !mounted) return;
    CrashGuard.report = null;
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Rapport de plantage'),
        content: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: SelectableText(r, style: const TextStyle(fontSize: 10, fontFamily: 'monospace')),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Clipboard.setData(ClipboardData(text: r)),
            child: const Text('Copier'),
          ),
          FilledButton(onPressed: () => Navigator.pop(ctx), child: const Text('Fermer')),
        ],
      ),
    );
  }

  /// Retour dans l'appli (par ex. après avoir activé une permission dans les
  /// réglages) : on relance la détection si elle n'est pas active.
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && !n.isConnected) {
      if ((n.wantDiscover && !n.isDiscovering) || (n.wantVisible && !n.isAdvertising)) n.start();
    }
  }

  Future<void> _ensureStorage() async {
    if (!Platform.isAndroid) {
      await StorageService.shareDir();
      return;
    }
    if (await StorageService.hasAccess()) {
      await StorageService.shareDir();
      return;
    }
    if (!mounted) return;
    final ok = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        icon: const Icon(Icons.folder_special_outlined, size: 36),
        title: const Text('Accès aux fichiers'),
        content: const Text(
          'Pour créer le dossier « ${StorageService.folderName} » où seront rangés les fichiers reçus, '
          'et pouvoir parcourir vos fichiers à distance (si vous l\u2019autorisez), '
          'l\u2019appli a besoin de l\u2019accès à tous les fichiers.\n\n'
          'Sur l\u2019écran suivant, activez l\u2019option pour LocalShare.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Plus tard')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Continuer')),
        ],
      ),
    );
    if (ok == true) {
      await StorageService.ensureAccess();
      await StorageService.shareDir();
    }
  }

  void _onChange() {
    if (!mounted) return;

    // Demande de connexion entrante : dialogue + notification (boutons Accepter / Refuser).
    final pc = n.pending;
    if (pc != null && !_pendingDialogOpen) {
      _pendingDialogOpen = true;
      showDialog<bool>(
        context: context,
        barrierDismissible: false,
        builder: (ctx) {
          _pendingCtx = ctx;
          return AlertDialog(
            icon: const Icon(Icons.link, size: 36),
            title: const Text('Demande de connexion'),
            content: Column(mainAxisSize: MainAxisSize.min, children: [
              Text('« ${pc.name} » veut se connecter à votre appareil.'),
              const SizedBox(height: 16),
              Text(pc.code,
                  style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold, letterSpacing: 6)),
              const SizedBox(height: 8),
              const Text('Vérifiez que le même code s\u2019affiche sur l\u2019autre appareil.',
                  textAlign: TextAlign.center),
            ]),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Refuser')),
              FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Accepter')),
            ],
          );
        },
      ).then((ok) {
        _pendingDialogOpen = false;
        _pendingCtx = null;
        // ok == null : fermé parce que la demande a été traitée via la notification.
        if (ok == true) {
          n.acceptPending();
        } else if (ok == false) {
          n.rejectPending();
        }
      });
    } else if (pc == null && _pendingDialogOpen && _pendingCtx != null) {
      // Traitée depuis la notification (ou expirée) : on ferme le dialogue.
      final ctx = _pendingCtx!;
      if (ctx.mounted) Navigator.of(ctx).pop();
    }

    // Connecté : ferme feuilles/dialogues et ouvre l'écran de transfert.
    if (n.isConnected && !_transferOpen) {
      _transferOpen = true;
      Navigator.of(context).popUntil((r) => r.isFirst);
      Navigator.of(context)
          .push(MaterialPageRoute(
            builder: (_) => TransferScreen(nearby: n, files: widget.files, remote: widget.remote),
          ))
          .then((_) {
        _transferOpen = false;
        if (n.isConnected) n.disconnect();
      });
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    n.removeListener(_onChange);
    super.dispose();
  }

  Future<void> _toggleVisible() => n.setVisible(!n.isAdvertising);

  Future<void> _rename() async {
    final ctrl = TextEditingController(text: n.deviceName);
    final name = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Nom de votre appareil'),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          maxLength: 30,
          decoration: const InputDecoration(
            hintText: 'Ex. : Téléphone de Marc',
            helperText: 'Ce nom s\u2019affiche sur les autres appareils.',
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(ctx, ctrl.text), child: const Text('Enregistrer')),
        ],
      ),
    );
    if (name != null) await n.renameDevice(name);
  }

  Future<void> _quit() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Quitter LocalShare ?'),
        content: const Text(
          'Vous ne serez plus visible et les transferts en cours seront interrompus.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Quitter')),
        ],
      ),
    );
    if (ok != true) return;
    await n.shutdown();
    await BackgroundService.stop();
    await NotificationService.cancelAll();
    SystemNavigator.pop();
  }

  String _statusLine() {
    if (n.outgoingCode != null) {
      return 'En attente de l\u2019accord de l\u2019autre appareil · code ${n.outgoingCode}';
    }
    if (n.info != null) return n.info!;
    if (n.isAdvertising && n.isDiscovering) {
      return 'Visible comme « ${n.deviceName} » · recherche en cours…';
    }
    if (n.isDiscovering) return 'Recherche en cours · vous n\u2019êtes pas visible';
    if (n.isAdvertising) {
      return 'Visible comme « ${n.deviceName} »';
    }
    return 'Détection en pause';
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return PopScope(
      // « Retour » met l'appli en arrière-plan au lieu de la fermer (sinon Nearby s'arrête).
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) BackgroundService.minimize();
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text('LocalShare'),
          centerTitle: true,
          actions: [
            IconButton(
              tooltip: 'Actualiser la détection',
              icon: const Icon(Icons.refresh),
              onPressed: n.restart,
            ),
            IconButton(
              tooltip: 'Fichiers reçus (${StorageService.folderName})',
              icon: const Icon(Icons.folder_special_outlined),
              onPressed: () => Navigator.of(context)
                  .push(MaterialPageRoute(builder: (_) => const ReceivedScreen())),
            ),
            PopupMenuButton<String>(
              onSelected: (v) {
                if (v == 'quit') _quit();
              },
              itemBuilder: (_) => const [
                PopupMenuItem(value: 'quit', child: Text('Quitter LocalShare')),
              ],
            ),
          ],
        ),
        body: ListenableBuilder(
          listenable: n,
          builder: (context, _) {
            final active = n.isAdvertising || n.isDiscovering;
            final discoverable = n.peers.where((p) => p.state != PeerState.connected).toList();
            return Column(
              children: [
                if (!NearbyService.supported)
                  _InfoCard(
                    color: cs.errorContainer,
                    onColor: cs.onErrorContainer,
                    icon: Icons.info_outline,
                    text: 'Nearby Connections est Android uniquement. Sur iOS, voir le README.',
                  ),
                // ----- Problème de détection à corriger (permission, GPS, Bluetooth…)
                if (n.status != null)
                  _InfoCard(
                    color: cs.errorContainer,
                    onColor: cs.onErrorContainer,
                    icon: Icons.warning_amber_rounded,
                    text: n.status!,
                    actionLabel: n.statusNeedsSettings ? 'Réglages' : 'Réessayer',
                    onAction: () => n.statusNeedsSettings ? openAppSettings() : n.restart(),
                  ),
                // ----- Radar
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                    child: RadarView(
                      peers: n.peers,
                      active: active,
                      onPeerTap: n.connectTo,
                    ),
                  ),
                ),
                // ----- État
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Text(
                    _statusLine(),
                    textAlign: TextAlign.center,
                    style: TextStyle(color: cs.outline),
                  ),
                ),
                // ----- Appareils détectés : touchez-en un pour lui envoyer une demande
                SizedBox(
                  height: 56,
                  child: discoverable.isEmpty
                      ? Center(
                          child: Text(
                            n.isDiscovering
                                ? 'Aucun appareil pour l\u2019instant. Ouvrez LocalShare sur l\u2019autre téléphone.'
                                : '',
                            textAlign: TextAlign.center,
                            style: TextStyle(color: cs.outline, fontSize: 12),
                          ),
                        )
                      : ListView.separated(
                          padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                          scrollDirection: Axis.horizontal,
                          itemCount: discoverable.length,
                          separatorBuilder: (_, __) => const SizedBox(width: 8),
                          itemBuilder: (_, i) {
                            final p = discoverable[i];
                            final busy = p.state == PeerState.connecting;
                            return ActionChip(
                              avatar: busy
                                  ? const SizedBox(
                                      width: 16,
                                      height: 16,
                                      child: CircularProgressIndicator(strokeWidth: 2),
                                    )
                                  : const Icon(Icons.smartphone, size: 18),
                              label: Text(busy ? '${p.name} · en attente…' : p.name),
                              onPressed: busy ? null : () => n.connectTo(p),
                            );
                          },
                        ),
                ),
                // ----- Actions
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Row(children: [
                    Expanded(
                      child: _ActionTile(
                        icon: n.isAdvertising ? Icons.visibility : Icons.visibility_off_outlined,
                        label: n.isAdvertising ? 'Visible' : 'Invisible',
                        selected: n.isAdvertising,
                        onTap: _toggleVisible,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _ActionTile(
                        icon: Icons.radar,
                        label: 'Actualiser',
                        onTap: n.restart,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _ActionTile(
                        icon: Icons.edit_outlined,
                        label: 'Mon nom',
                        onTap: _rename,
                      ),
                    ),
                  ]),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  const _InfoCard({
    required this.color,
    required this.onColor,
    required this.icon,
    required this.text,
    this.actionLabel,
    this.onAction,
  });
  final Color color, onColor;
  final IconData icon;
  final String text;
  final String? actionLabel;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) => Container(
        width: double.infinity,
        margin: const EdgeInsets.fromLTRB(16, 8, 16, 0),
        padding: const EdgeInsets.fromLTRB(14, 10, 8, 10),
        decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(14)),
        child: Row(children: [
          Icon(icon, color: onColor, size: 20),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: TextStyle(color: onColor, fontSize: 13))),
          if (actionLabel != null)
            TextButton(onPressed: onAction, child: Text(actionLabel!)),
        ]),
      );
}

class _ActionTile extends StatelessWidget {
  const _ActionTile({
    required this.icon,
    required this.label,
    required this.onTap,
    this.selected = false,
  });
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool selected;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Material(
      color: selected ? cs.primaryContainer : cs.surfaceContainerHigh,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 14),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(icon, color: selected ? cs.onPrimaryContainer : cs.primary),
            const SizedBox(height: 6),
            Text(label,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  color: selected ? cs.onPrimaryContainer : null,
                )),
          ]),
        ),
      ),
    );
  }
}
