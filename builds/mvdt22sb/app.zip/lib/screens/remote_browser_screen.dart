import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import '../services/remote_fs_service.dart';
import '../utils/file_utils.dart';

/// Parcourt les fichiers de l'autre téléphone, comme un téléphone branché à un PC.
class RemoteBrowserScreen extends StatefulWidget {
  const RemoteBrowserScreen({super.key, required this.remote, required this.peerName});
  final RemoteFsService remote;
  final String peerName;

  @override
  State<RemoteBrowserScreen> createState() => _RemoteBrowserScreenState();
}

class _RemoteBrowserScreenState extends State<RemoteBrowserScreen> {
  RemoteFsService get r => widget.remote;
  final Set<String> _selected = {};

  @override
  void initState() {
    super.initState();
    if (r.access == RemoteAccess.granted) {
      r.list(r.currentPath);
    } else {
      r.requestAccess();
    }
  }

  String _full(RemoteEntry e) => p.join(r.currentPath, e.name);

  void _download(Iterable<String> paths) {
    final list = paths.toList();
    if (list.isEmpty) return;
    r.download(list);
    setState(_selected.clear);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(list.length == 1
          ? 'Téléchargement lancé dans DoubigueShare…'
          : 'Téléchargement de ${list.length} fichiers dans DoubigueShare…'),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return ListenableBuilder(
      listenable: r,
      builder: (context, _) {
        final granted = r.access == RemoteAccess.granted;
        final selecting = _selected.isNotEmpty;
        return PopScope(
          canPop: !(granted && !r.atRoot) && !selecting,
          onPopInvokedWithResult: (didPop, _) {
            if (didPop) return;
            if (selecting) {
              setState(_selected.clear);
            } else {
              r.up();
            }
          },
          child: Scaffold(
            appBar: AppBar(
              leading: selecting
                  ? IconButton(icon: const Icon(Icons.close), onPressed: () => setState(_selected.clear))
                  : null,
              title: Text(selecting
                  ? '${_selected.length} sélectionné(s)'
                  : 'Fichiers de ${widget.peerName}'),
              actions: [
                if (selecting)
                  IconButton(
                    tooltip: 'Télécharger',
                    icon: const Icon(Icons.download),
                    onPressed: () => _download(_selected),
                  )
                else if (granted)
                  IconButton(
                    tooltip: 'Actualiser',
                    icon: const Icon(Icons.refresh),
                    onPressed: r.refresh,
                  ),
              ],
            ),
            body: switch (r.access) {
              RemoteAccess.none || RemoteAccess.requesting => Center(
                  child: Padding(
                    padding: const EdgeInsets.all(32),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      const CircularProgressIndicator(),
                      const SizedBox(height: 20),
                      Text(
                        'En attente de l\u2019autorisation de ${widget.peerName}…',
                        textAlign: TextAlign.center,
                      ),
                    ]),
                  ),
                ),
              RemoteAccess.denied => Center(
                  child: Padding(
                    padding: const EdgeInsets.all(32),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      Icon(Icons.lock_outline, size: 64, color: cs.outline),
                      const SizedBox(height: 12),
                      const Text('Accès refusé ou révoqué.', textAlign: TextAlign.center),
                      const SizedBox(height: 16),
                      FilledButton(onPressed: r.requestAccess, child: const Text('Redemander l\u2019accès')),
                    ]),
                  ),
                ),
              RemoteAccess.granted => Column(children: [
                  Container(
                    width: double.infinity,
                    color: cs.surfaceContainerHigh,
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    child: Row(children: [
                      Icon(Icons.folder_open, size: 18, color: cs.primary),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(displayPath(r.currentPath),
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontWeight: FontWeight.w600)),
                      ),
                    ]),
                  ),
                  if (r.loading) const LinearProgressIndicator(),
                  Expanded(
                    child: r.error != null
                        ? Center(child: Text(r.error!, style: TextStyle(color: cs.error)))
                        : (r.entries.isEmpty && !r.loading)
                            ? Center(child: Text('Dossier vide', style: TextStyle(color: cs.outline)))
                            : ListView.builder(
                                itemCount: r.entries.length,
                                itemBuilder: (_, i) {
                                  final e = r.entries[i];
                                  final path = _full(e);
                                  final sel = _selected.contains(path);
                                  return ListTile(
                                    selected: sel,
                                    leading: Icon(
                                      e.isDir ? Icons.folder : iconForKind(kindOf(e.name)),
                                      color: e.isDir ? Colors.amber.shade700 : cs.primary,
                                    ),
                                    title: Text(e.name, overflow: TextOverflow.ellipsis),
                                    subtitle: Text(e.isDir
                                        ? formatDate(e.modified)
                                        : '${formatBytes(e.size)} · ${formatDate(e.modified)}'),
                                    trailing: selecting && !e.isDir
                                        ? Checkbox(
                                            value: sel,
                                            onChanged: (_) => setState(() =>
                                                sel ? _selected.remove(path) : _selected.add(path)),
                                          )
                                        : e.isDir
                                            ? const Icon(Icons.chevron_right)
                                            : IconButton(
                                                tooltip: 'Télécharger',
                                                icon: const Icon(Icons.download),
                                                onPressed: () => _download([path]),
                                              ),
                                    onTap: () {
                                      if (selecting && !e.isDir) {
                                        setState(() => sel ? _selected.remove(path) : _selected.add(path));
                                      } else if (e.isDir) {
                                        r.list(path);
                                      } else {
                                        _download([path]);
                                      }
                                    },
                                    onLongPress: e.isDir ? null : () => setState(() => _selected.add(path)),
                                  );
                                },
                              ),
                  ),
                ]),
            },
          ),
        );
      },
    );
  }
}
