import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;

enum FileKind { image, video, audio, pdf, text, other }

const _image = {'jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'heic', 'heif'};
const _video = {'mp4', 'mkv', 'mov', 'avi', 'webm', '3gp', 'm4v'};
const _audio = {'mp3', 'm4a', 'aac', 'wav', 'ogg', 'oga', 'flac', 'opus'};
const _text = {
  'txt', 'md', 'json', 'xml', 'csv', 'log', 'yaml', 'yml', 'html', 'htm', 'css',
  'js', 'dart', 'java', 'kt', 'py', 'c', 'cpp', 'h', 'sh', 'ini', 'conf', 'srt', 'vcf',
};

FileKind kindOf(String path) {
  final e = p.extension(path).toLowerCase().replaceFirst('.', '');
  if (_image.contains(e)) return FileKind.image;
  if (_video.contains(e)) return FileKind.video;
  if (_audio.contains(e)) return FileKind.audio;
  if (e == 'pdf') return FileKind.pdf;
  if (_text.contains(e)) return FileKind.text;
  return FileKind.other;
}

IconData iconForKind(FileKind k) => switch (k) {
      FileKind.image => Icons.image_outlined,
      FileKind.video => Icons.movie_outlined,
      FileKind.audio => Icons.audiotrack_outlined,
      FileKind.pdf => Icons.picture_as_pdf_outlined,
      FileKind.text => Icons.description_outlined,
      FileKind.other => Icons.insert_drive_file_outlined,
    };

String formatBytes(int b) {
  if (b < 1024) return '$b o';
  if (b < 1024 * 1024) return '${(b / 1024).toStringAsFixed(1)} Ko';
  if (b < 1024 * 1024 * 1024) return '${(b / 1024 / 1024).toStringAsFixed(1)} Mo';
  return '${(b / 1024 / 1024 / 1024).toStringAsFixed(2)} Go';
}

String _two(int n) => n.toString().padLeft(2, '0');

String formatDate(DateTime d) =>
    '${_two(d.day)}/${_two(d.month)}/${d.year} ${_two(d.hour)}:${_two(d.minute)}';

String displayPath(String path) => path.replaceFirst('/storage/emulated/0', 'Stockage interne');
