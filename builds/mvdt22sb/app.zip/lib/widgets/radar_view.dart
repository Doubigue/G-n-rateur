import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../models/peer.dart';

/// Radar de proximité.
///
/// Optimisé pour rester fluide :
///  - la grille (cercles, graduations, anneau) est dessinée UNE fois dans une
///    couche séparée (RepaintBoundary) ;
///  - seule la couche dynamique (faisceau, échos) est redessinée à chaque image,
///    sans reconstruire de widgets ;
///  - plus de flou (MaskFilter) coûteux : les halos sont des dégradés ;
///  - les étiquettes de texte sont mises en cache.
///
/// NB : l'API Nearby ne fournit ni distance ni direction. La position d'un écho
/// est dérivée de son identifiant : stable, mais symbolique.
class RadarView extends StatefulWidget {
  const RadarView({
    super.key,
    required this.peers,
    required this.active,
    required this.onPeerTap,
  });

  final List<Peer> peers;
  final bool active;
  final ValueChanged<Peer> onPeerTap;

  @override
  State<RadarView> createState() => _RadarViewState();
}

class _RadarViewState extends State<RadarView> with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 3600));
  final Map<String, TextPainter> _labels = {};

  @override
  void initState() {
    super.initState();
    _syncLabels();
    if (widget.active) _ctrl.repeat();
  }

  @override
  void didUpdateWidget(covariant RadarView old) {
    super.didUpdateWidget(old);
    _syncLabels();
    if (widget.active && !_ctrl.isAnimating) _ctrl.repeat();
    if (!widget.active && _ctrl.isAnimating) _ctrl.stop();
  }

  void _syncLabels() {
    final names = widget.peers.map((p) => p.name).toSet();
    _labels.removeWhere((k, _) => !names.contains(k));
    for (final n in names) {
      _labels.putIfAbsent(
        n,
        () => TextPainter(
          text: TextSpan(
            text: n,
            style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600),
          ),
          maxLines: 1,
          ellipsis: '…',
          textDirection: TextDirection.ltr,
        )..layout(maxWidth: 110),
      );
    }
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Peer? _hit(Offset pos, double side) {
    final c = Offset(side / 2, side / 2);
    final r = side / 2 - 4;
    Peer? best;
    var bestD = 40.0;
    for (final p in widget.peers) {
      final d = (blipOffset(p, c, r) - pos).distance;
      if (d < bestD) {
        bestD = d;
        best = p;
      }
    }
    return best;
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, box) {
      final side = math.min(box.maxWidth, box.maxHeight);
      return Center(
        child: SizedBox(
          width: side,
          height: side,
          child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTapUp: (d) {
              final p = _hit(d.localPosition, side);
              if (p != null && p.state == PeerState.discovered) widget.onPeerTap(p);
            },
            child: Stack(fit: StackFit.expand, children: [
              const RepaintBoundary(child: CustomPaint(painter: _GridPainter())),
              RepaintBoundary(
                child: CustomPaint(
                  painter: _SweepPainter(
                    ctrl: _ctrl,
                    peers: widget.peers,
                    active: widget.active,
                    labels: _labels,
                  ),
                ),
              ),
            ]),
          ),
        ),
      );
    });
  }
}

int _fnv(String s) {
  var h = 0x811c9dc5;
  for (final u in s.codeUnits) {
    h ^= u;
    h = (h * 0x01000193) & 0xFFFFFFFF;
  }
  return h;
}

/// Position déterministe d'un écho (angle + rayon dérivés de l'id).
Offset blipOffset(Peer p, Offset c, double r) {
  final h = _fnv(p.id);
  final angle = (h % 3600) / 3600 * 2 * math.pi;
  final frac = 0.36 + ((h >> 12) % 100) / 100 * 0.5;
  return c + Offset(math.cos(angle), math.sin(angle)) * (r * frac);
}

double _blipAngle(Peer p) => (_fnv(p.id) % 3600) / 3600 * 2 * math.pi;

const _cyan = Color(0xFF00E5FF);
const _green = Color(0xFF39FF9A);
const _amber = Color(0xFFFFC107);

/// Couche statique : dessinée une seule fois.
class _GridPainter extends CustomPainter {
  const _GridPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2 - 4;
    final rect = Rect.fromCircle(center: c, radius: r);

    canvas.drawCircle(
      c,
      r,
      Paint()
        ..shader = const RadialGradient(
          colors: [Color(0xFF06343F), Color(0xFF020B10)],
        ).createShader(rect),
    );

    final line = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;

    for (var i = 1; i <= 3; i++) {
      canvas.drawCircle(c, r * i / 4, line..color = _cyan.withOpacity(0.18));
    }
    line.color = _cyan.withOpacity(0.14);
    canvas.drawLine(Offset(c.dx - r, c.dy), Offset(c.dx + r, c.dy), line);
    canvas.drawLine(Offset(c.dx, c.dy - r), Offset(c.dx, c.dy + r), line);

    for (var deg = 0; deg < 360; deg += 6) {
      final a = deg * math.pi / 180;
      final len = deg % 30 == 0 ? 11.0 : 5.0;
      final d = Offset(math.cos(a), math.sin(a));
      canvas.drawLine(
        c + d * (r - len),
        c + d * r,
        line..color = _cyan.withOpacity(deg % 30 == 0 ? 0.7 : 0.35),
      );
    }
    canvas.drawCircle(
      c,
      r,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = _cyan.withOpacity(0.65),
    );
  }

  @override
  bool shouldRepaint(covariant _GridPainter old) => false;
}

/// Couche dynamique : faisceau, ondes, échos. Se redessine via `repaint: ctrl`
/// (aucune reconstruction de widget à chaque image).
class _SweepPainter extends CustomPainter {
  _SweepPainter({
    required this.ctrl,
    required this.peers,
    required this.active,
    required this.labels,
  }) : super(repaint: ctrl);

  final AnimationController ctrl;
  final List<Peer> peers;
  final bool active;
  final Map<String, TextPainter> labels;

  @override
  void paint(Canvas canvas, Size size) {
    final t = ctrl.value;
    final c = size.center(Offset.zero);
    final r = size.width / 2 - 4;
    final rect = Rect.fromCircle(center: c, radius: r);
    final sweep = t * 2 * math.pi;

    if (active) {
      for (var k = 0; k < 3; k++) {
        final ph = (t + k / 3) % 1.0;
        canvas.drawCircle(
          c,
          r * ph,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = 1.6
            ..color = _green.withOpacity((1 - ph) * 0.35),
        );
      }
      canvas.drawCircle(
        c,
        r,
        Paint()
          ..shader = SweepGradient(
            colors: [_cyan.withOpacity(0), _cyan.withOpacity(0), _cyan.withOpacity(0.5)],
            stops: const [0.0, 0.7, 1.0],
            transform: GradientRotation(sweep),
          ).createShader(rect),
      );
      canvas.drawLine(
        c,
        c + Offset(math.cos(sweep), math.sin(sweep)) * r,
        Paint()
          ..color = _cyan.withOpacity(0.95)
          ..strokeWidth = 2
          ..strokeCap = StrokeCap.round,
      );
    }

    for (final p in peers) {
      final pos = blipOffset(p, c, r);
      var b = 0.55;
      if (active) {
        var delta = (sweep - _blipAngle(p)) % (2 * math.pi);
        if (delta < 0) delta += 2 * math.pi;
        b = 0.35 + 0.65 * math.exp(-delta * 0.9);
      }
      final color = switch (p.state) {
        PeerState.discovered => _green,
        PeerState.connecting => _amber,
        PeerState.connected => _cyan,
      };
      final pulse = p.state == PeerState.connecting ? 2.5 * math.sin(t * 2 * math.pi * 4).abs() : 0.0;
      final glowR = 16 + pulse;

      // Halo en dégradé radial (beaucoup moins coûteux qu'un flou).
      canvas.drawCircle(
        pos,
        glowR,
        Paint()
          ..shader = RadialGradient(
            colors: [color.withOpacity(0.55 * b), color.withOpacity(0)],
          ).createShader(Rect.fromCircle(center: pos, radius: glowR)),
      );
      canvas.drawCircle(pos, 6, Paint()..color = color.withOpacity(0.4 + 0.6 * b));
      canvas.drawCircle(
        pos,
        10 + pulse,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.2
          ..color = color.withOpacity(0.6 * b),
      );

      final tp = labels[p.name];
      if (tp != null) {
        final x = (pos.dx - tp.width / 2).clamp(4.0, size.width - tp.width - 4);
        tp.paint(canvas, Offset(x, pos.dy + 14));
      }
    }

    canvas.drawCircle(
      c,
      14,
      Paint()
        ..shader = RadialGradient(colors: [_green.withOpacity(0.35), _green.withOpacity(0)])
            .createShader(Rect.fromCircle(center: c, radius: 14)),
    );
    canvas.drawCircle(c, 9, Paint()..style = PaintingStyle.stroke..strokeWidth = 1.5..color = _green);
    canvas.drawCircle(c, 4.5, Paint()..color = Colors.white);
  }

  @override
  bool shouldRepaint(covariant _SweepPainter old) =>
      old.peers != peers || old.active != active;
}
