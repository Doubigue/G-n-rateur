# LocalShare

Partage local style Quick Share / AirDrop :
- **envoi de fichiers**, reçus dans le dossier **`DoubigueShare`** et lisibles directement dans l'appli ;
- **accès aux fichiers de l'autre téléphone** (comme un téléphone branché à un PC) ;
- détection **automatique** des appareils proches (radar) ;
- **envoi de texte** (message, lien, code) et copie en un geste ;
- vitesse, temps restant et **annulation** des transferts ; vibration à la réception.

> v1.3 : le scan par QR code a été retiré ; plugin `nearby_connections` corrigé (plantage à la réception).

## Mise en route
1. `flutter create --org com.example --project-name localshare .` (génère android/ et ios/)
2. Copiez `lib/`, `packages/` et `pubspec.yaml` de cette archive (le dossier `packages/` contient
   le plugin Nearby corrigé), puis `flutter pub get`
3. Remplacez `android/app/src/main/AndroidManifest.xml` par `platform_config/AndroidManifest.xml`
4. Dans `android/app/build.gradle(.kts)` :
   - `minSdk = 23`, `compileSdk = 34` (ou plus), `applicationId = "com.example.localshare"`
   - **nouveau** (requis par `flutter_local_notifications`) :
     ```kotlin
     android {
         compileOptions {
             isCoreLibraryDesugaringEnabled = true
             sourceCompatibility = JavaVersion.VERSION_11
             targetCompatibility = JavaVersion.VERSION_11
         }
     }
     dependencies {
         coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")
     }
     ```
     (Groovy : `coreLibraryDesugaringEnabled true` et `coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.4'`)
5. iOS : fusionnez `platform_config/Info.plist.snippet.xml` dans `ios/Runner/Info.plist`
6. Testez sur **deux appareils physiques** (pas d'émulateur).

## Utilisation
- **Au lancement**, l'appli est **visible par défaut** et **cherche** les appareils proches. Il suffit que
  l'autre téléphone ait ouvert LocalShare (Bluetooth + localisation activés).
- Touchez un appareil (écho du radar ou pastille) : l'autre reçoit une **notification** avec
  **Accepter / Refuser** et un code à 4 chiffres identique des deux côtés.
- **Mon nom** : change le nom affiché aux autres. **Actualiser** : relance le radar.
- Une fois connectés : **Envoyer** (fichiers), **Texte** ou **Ses fichiers** (l'autre doit **autoriser**, révocable).
- **Notifications** : progression d'envoi / de réception (barre de progression dans la barre d'état),
  fin de transfert, demandes de connexion et d'accès aux fichiers.
- **Arrière-plan** : « Retour » ou « Accueil » mettent l'appli en arrière-plan sans rien couper
  (service au premier plan). Pour arrêter : menu ⋮ → **Quitter LocalShare**, ou « Se déconnecter ».
- Fichiers reçus : `<stockage interne>/DoubigueShare`.

## Si un appareil n'est pas détecté
La détection réclame, **sur les deux téléphones** :
1. Permissions **Appareils à proximité** (Android 12+) et **Localisation** accordées à LocalShare ;
2. **Localisation (GPS) activée** dans les réglages rapides — la permission seule ne suffit pas ;
3. **Bluetooth activé** (et idéalement le Wi-Fi) ;
4. **LocalShare ouvert** sur l'autre téléphone (il doit être « Visible »).
L'appli affiche désormais le problème exact en haut de l'écran, avec un bouton « Réglages » ou « Réessayer ».
Si les permissions ont été refusées deux fois, Android ne redemande plus : passez par Réglages → Applis →
LocalShare → Autorisations.

## Sécurité
- Toute demande de connexion entrante passe par une validation avec code identique des deux côtés.
- Accès aux fichiers : consentement explicite, limité au stockage interne, chemins normalisés
  (pas de sortie via `..`), fichiers cachés masqués, remis à zéro à la déconnexion.
- Les noms de fichiers reçus sont assainis avant écriture.

## Performances (changements v1.2)
- La progression ne reconstruit plus tout l'écran : chaque transfert met à jour sa propre ligne, ≈5 fois/s.
- Liste de transferts paresseuse (`ListView.builder`), radar en deux couches sans flou.
- Notifications de progression groupées (une par sens, mise à jour toutes les ~0,7 s).
- Lecture des dossiers distants non bloquante.

## Limites connues
- **Gros fichiers reçus** : en fin de réception, le plugin Nearby copie le fichier vers `DoubigueShare`
  (`copyFileAndDeleteOriginal`). Cette copie est faite par le plugin et peut figer brièvement l'écran sur
  de très gros fichiers (plusieurs Go). Seul un correctif natif du plugin (copie dans un thread) le supprimerait.
- **Dossier DoubigueShare à la racine** : Android 11+ exige « Accès à tous les fichiers »
  (`MANAGE_EXTERNAL_STORAGE`). Si refusé, repli sur le dossier privé de l'appli.
- **Boutons des notifications** : « Accepter / Refuser / Autoriser » ramènent l'appli au premier plan
  (Android ne permet pas de les traiter sans ouvrir l'appli sans code natif supplémentaire).
- **Fermeture depuis les « récents »** : coupe la visibilité et les transferts. Sur certains constructeurs
  (Xiaomi, Huawei, Samsung…), désactivez aussi l'économie de batterie pour l'appli (proposé à la 1re connexion).
- **Radar** : Nearby ne donne ni distance ni direction ; la position d'un écho est symbolique.
- Dossiers : téléchargement fichier par fichier.
- **iOS** : `nearby_connections` est Android-only. Implémentez la même interface que `NearbyService`
  avec MultipeerConnectivity ou Bonjour + sockets TCP ; le protocole JSON (`protocol.dart`) reste identique.
