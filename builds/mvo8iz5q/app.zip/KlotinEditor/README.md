# Co-edit v0.2

Ouvrir le dossier dans Android Studio (Koala+), laisser Gradle synchroniser (le wrapper est généré à l'ouverture), puis Run.
Prérequis : JDK 17. Chaquopy (Python) télécharge ses runtimes à la première synchronisation.

## Fonctionnalités
- Workspace `KlotinWorkspace/` (stockage de l'app) : 5 sous-dossiers routés par extension, `binaries_others` = catch-all
- Éditeur : numéros de ligne, coloration, undo/redo, chercher/remplacer, encodages, historique Git-lite (`.history/`)
- Visionneuses : hexadécimal (tout fichier), images, **audio/vidéo (Media3)**, **PDF (PdfRenderer)**
- Aperçu HTML (WebView) servi par NanoHTTPD, liens relatifs inter-dossiers résolus par nom de fichier
- **HTTP :8080 + HTTPS :8443** : certificat auto-signé (BouncyCastle), SAN localhost/127.0.0.1/IP LAN, régénéré si l'IP change ; bouton « Serveur » = partage réseau
- **Console Python (Chaquopy 3.11)** : exécuter un .py (▶ dans l'éditeur ou menu du fichier) + REPL persistant
- **Archives** : zip, 7z, tar, tar.gz/tgz, tar.bz2, tar.xz, gz/bz2/xz, rar (RAR4) ; toucher une archive l'extrait et range les fichiers ; compression zip
- **Partage** : feuille de partage, envoi direct WhatsApp, « Ouvrir avec… » (docx/xlsx/pptx), export PDF des fichiers texte
- Thèmes OLED / Cyberpunk / Clair

## Limites connues
- Certificat auto-signé : le navigateur d'un autre appareil affichera un avertissement ; la WebView intégrée l'accepte pour localhost/127.0.0.1 uniquement
- Python : pas de `input()`, pas de pip (ajouter des paquets via `chaquopy { defaultConfig { pip { install("...") } } }`)
- RAR5 non supporté (junrar) ; l'extraction met les fichiers à plat par catégorie (pas d'arborescence)
- Si Gradle refuse la version de Chaquopy avec votre AGP, ajustez `com.chaquo.python` (racine) ou la version AGP

## Idées suivantes
Rendu Markdown, éditeur Sora pour gros fichiers, tests instrumentés
