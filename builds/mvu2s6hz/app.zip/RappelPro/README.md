# RappelPro

Application Android de rappels avec sonnerie (Kotlin + un fichier Java).

## Fonctionnalités
- Tableau de bord en grille de cartes : programmer un rappel, prochain rappel, rappels actifs, rappels du jour, rappel rapide (minuteur / test), fiabilité des sonneries.
- Rappel : nom, sonnerie (système ou fichier audio perso), heure, date, infos, répétition (une fois / tous les jours / chaque semaine), vibration.
- Liste des rappels avec heure, interrupteur ON/OFF, modification au toucher, suppression.
- Sonnerie via `AlarmManager.setAlarmClock` : fonctionne écran éteint, en veille profonde (Doze) et application fermée.
- Notification + écran plein écran qui expliquent pourquoi le rappel sonne ; boutons Arrêter / Répéter 10 min.
- Reprogrammation automatique après redémarrage, changement d'heure ou mise à jour.
- Notification « Rappel manqué » si l'heure est tombée pendant que le téléphone était éteint.
- Thème clair / sombre, logo adaptatif (cloche).

## Compiler
- Android Studio : ouvrir le dossier, laisser Gradle synchroniser, Run.
- GitHub Actions : pousser le dépôt, l'APK debug est dans les artefacts du workflow « Build APK ».

## Téléphone totalement éteint
Android n'autorise aucune application à rallumer un téléphone éteint. Utilisez l'allumage programmé
des réglages du téléphone (selon la marque) : au démarrage, RappelPro reprogramme tout seul les rappels.
