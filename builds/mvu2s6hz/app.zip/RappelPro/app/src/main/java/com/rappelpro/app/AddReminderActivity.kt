package com.rappelpro.app

import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.datepicker.CalendarConstraints
import com.google.android.material.datepicker.DateValidatorPointForward
import com.google.android.material.datepicker.MaterialDatePicker
import com.google.android.material.timepicker.MaterialTimePicker
import com.google.android.material.timepicker.TimeFormat
import com.rappelpro.app.databinding.ActivityAddReminderBinding
import java.util.Calendar

class AddReminderActivity : AppCompatActivity() {

    private lateinit var b: ActivityAddReminderBinding
    private var editId = -1
    private var hour = 0
    private var minute = 0
    private var dateMillis = 0L          // minuit local du jour choisi
    private var ringtoneUri: String? = null
    private var ringtoneTitle = "Sonnerie par défaut"

    private val ringtonePicker =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            if (res.resultCode == RESULT_OK) {
                @Suppress("DEPRECATION")
                val uri: Uri? = res.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
                if (uri != null) setRingtone(uri, null)
            }
        }

    private val filePicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) {
                }
                setRingtone(uri, fileName(uri))
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityAddReminderBinding.inflate(layoutInflater)
        setContentView(b.root)

        editId = intent.getIntExtra(AlarmScheduler.EXTRA_ID, -1)
        val existing = if (editId > 0) ReminderStore.get(this, editId) else null

        if (existing != null) {
            b.tvFormTitle.text = "Modifier le rappel"
            b.etName.setText(existing.name)
            b.etInfo.setText(existing.info)
            hour = existing.hour
            minute = existing.minute
            dateMillis = existing.dateMillis
            ringtoneUri = existing.ringtoneUri
            ringtoneTitle = existing.ringtoneTitle
            b.switchVibrate.isChecked = existing.vibrate
            b.chipGroup.check(
                when (existing.repeat) {
                    Reminder.REPEAT_DAILY -> R.id.chipDaily
                    Reminder.REPEAT_WEEKLY -> R.id.chipWeekly
                    else -> R.id.chipOnce
                }
            )
            b.btnDeleteReminder.visibility = android.view.View.VISIBLE
        } else {
            val cal = Calendar.getInstance().apply { add(Calendar.MINUTE, 5) }
            hour = cal.get(Calendar.HOUR_OF_DAY)
            minute = cal.get(Calendar.MINUTE)
            dateMillis = Utils.startOfDay(cal.timeInMillis)
            b.chipGroup.check(R.id.chipOnce)
        }
        refreshUi()

        b.btnTime.setOnClickListener { pickTime() }
        b.btnDate.setOnClickListener { pickDate() }
        b.btnRingtone.setOnClickListener {
            val i = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
                putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Choisir la sonnerie")
                putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                ringtoneUri?.let { putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(it)) }
            }
            ringtonePicker.launch(i)
        }
        b.btnFile.setOnClickListener { filePicker.launch(arrayOf("audio/*")) }
        b.btnSave.setOnClickListener { save() }
        b.btnDeleteReminder.setOnClickListener {
            AlarmScheduler.cancel(this, editId)
            ReminderStore.delete(this, editId)
            finish()
        }
    }

    private fun refreshUi() {
        b.btnTime.text = "🕒 ${Utils.time(hour, minute)}"
        b.btnDate.text = "📅 ${Utils.date(dateMillis)}"
        b.tvRingtone.text = "🎵 Sonnerie : $ringtoneTitle"
    }

    private fun setRingtone(uri: Uri, title: String?) {
        ringtoneUri = uri.toString()
        ringtoneTitle = title
            ?: try { RingtoneManager.getRingtone(this, uri)?.getTitle(this) } catch (_: Exception) { null }
            ?: "Sonnerie choisie"
        refreshUi()
    }

    private fun fileName(uri: Uri): String {
        try {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && c.moveToFirst()) return c.getString(idx)
            }
        } catch (_: Exception) {
        }
        return "Fichier audio"
    }

    private fun pickTime() {
        val picker = MaterialTimePicker.Builder()
            .setTimeFormat(TimeFormat.CLOCK_24H)
            .setHour(hour)
            .setMinute(minute)
            .setTitleText("Heure du rappel")
            .build()
        picker.addOnPositiveButtonClickListener {
            hour = picker.hour
            minute = picker.minute
            refreshUi()
        }
        picker.show(supportFragmentManager, "time")
    }

    private fun pickDate() {
        val constraints = CalendarConstraints.Builder()
            .setValidator(DateValidatorPointForward.from(MaterialDatePicker.todayInUtcMilliseconds()))
            .build()
        val picker = MaterialDatePicker.Builder.datePicker()
            .setTitleText("Date du rappel")
            .setSelection(Utils.localToUtc(dateMillis))
            .setCalendarConstraints(constraints)
            .build()
        picker.addOnPositiveButtonClickListener { sel ->
            dateMillis = Utils.utcToLocal(sel)
            refreshUi()
        }
        picker.show(supportFragmentManager, "date")
    }

    private fun save() {
        val name = b.etName.text.toString().trim()
        if (name.isEmpty()) {
            b.tilName.error = "Donnez un nom au rappel"
            return
        }
        b.tilName.error = null

        val repeat = when (b.chipGroup.checkedChipId) {
            R.id.chipDaily -> Reminder.REPEAT_DAILY
            R.id.chipWeekly -> Reminder.REPEAT_WEEKLY
            else -> Reminder.REPEAT_ONCE
        }
        val id = if (editId > 0) editId else ReminderStore.nextId(this)
        val r = Reminder(
            id = id,
            name = name,
            info = b.etInfo.text.toString().trim(),
            ringtoneUri = ringtoneUri,
            ringtoneTitle = ringtoneTitle,
            hour = hour,
            minute = minute,
            dateMillis = dateMillis,
            repeat = repeat,
            enabled = true,
            vibrate = b.switchVibrate.isChecked
        )
        val next = r.nextTrigger()
        if (next == null) {
            Toast.makeText(this, "Cette date et cette heure sont déjà passées.", Toast.LENGTH_LONG).show()
            return
        }
        ReminderStore.upsert(this, r)
        AlarmScheduler.schedule(this, r)
        Toast.makeText(this, "Rappel programmé dans ${Utils.delay(next - System.currentTimeMillis())}", Toast.LENGTH_LONG).show()
        finish()
    }
}
