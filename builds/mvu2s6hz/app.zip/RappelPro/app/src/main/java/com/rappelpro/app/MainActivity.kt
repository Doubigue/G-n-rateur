package com.rappelpro.app

import android.Manifest
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.rappelpro.app.databinding.ActivityMainBinding
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private lateinit var adapter: ReminderAdapter

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        NotificationHelper.ensureChannels(this)
        AlarmScheduler.rescheduleAll(this)

        adapter = ReminderAdapter(::onToggle, ::openEdit, ::confirmDelete)
        b.rvReminders.layoutManager = LinearLayoutManager(this)
        b.rvReminders.adapter = adapter

        b.cardAdd.setOnClickListener { openAdd() }
        b.fabAdd.setOnClickListener { openAdd() }
        b.cardQuick.setOnClickListener { showQuickDialog() }
        b.cardReliab.setOnClickListener { showReliabilityDialog() }

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun openAdd() = startActivity(Intent(this, AddReminderActivity::class.java))

    private fun openEdit(r: Reminder) = startActivity(
        Intent(this, AddReminderActivity::class.java).putExtra(AlarmScheduler.EXTRA_ID, r.id)
    )

    private fun refresh() {
        val now = System.currentTimeMillis()
        val all = ReminderStore.getAll(this)

        val sorted = all.sortedWith(
            compareBy<Reminder>({ !it.enabled }, { it.nextTrigger(now) ?: Long.MAX_VALUE })
        )
        adapter.submit(sorted)
        b.tvEmpty.visibility = if (all.isEmpty()) View.VISIBLE else View.GONE

        val active = all.filter { it.enabled && it.nextTrigger(now) != null }
        b.tvActiveValue.text = active.size.toString()
        val endOfDay = Utils.startOfDay(now) + 24L * 3600 * 1000
        b.tvTodayValue.text = active.count { (it.nextTrigger(now) ?: Long.MAX_VALUE) < endOfDay }.toString()

        val next = active.minByOrNull { it.nextTrigger(now)!! }
        if (next != null) {
            b.tvNextValue.text = Utils.time(next.hour, next.minute)
            b.tvNextSub.text = "${next.name} · dans ${Utils.delay(next.nextTrigger(now)!! - now)}"
        } else {
            b.tvNextValue.text = "--:--"
            b.tvNextSub.text = "Aucun rappel actif"
        }

        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val hello = when {
            h < 12 -> "Bonjour"
            h < 18 -> "Bon après-midi"
            else -> "Bonsoir"
        }
        b.tvGreeting.text = "$hello · " +
            SimpleDateFormat("EEEE d MMMM", Locale.getDefault()).format(Date(now))

        b.tvReliabValue.text = if (isReliable()) "✔ Tout est prêt pour sonner à l'heure"
        else "⚠ À vérifier : touchez pour régler les autorisations"
    }

    private fun isReliable(): Boolean {
        val notifOk = NotificationManagerCompat.from(this).areNotificationsEnabled()
        val fullOk = if (Build.VERSION.SDK_INT >= 34) {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).canUseFullScreenIntent()
        } else true
        return notifOk && fullOk
    }

    private fun onToggle(r: Reminder, checked: Boolean) {
        if (checked) {
            r.enabled = true
            if (r.nextTrigger() == null) {
                Toast.makeText(this, "L'heure est passée : modifiez la date ou l'heure.", Toast.LENGTH_LONG).show()
                r.enabled = false
            } else {
                ReminderStore.upsert(this, r)
                AlarmScheduler.schedule(this, r)
                Toast.makeText(this, "Rappel activé (dans ${Utils.delay(r.nextTrigger()!! - System.currentTimeMillis())})", Toast.LENGTH_SHORT).show()
            }
        } else {
            r.enabled = false
            ReminderStore.upsert(this, r)
            AlarmScheduler.cancel(this, r.id)
        }
        refresh()
    }

    private fun confirmDelete(r: Reminder) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Supprimer ce rappel ?")
            .setMessage("« ${r.name} » sera supprimé définitivement.")
            .setPositiveButton("Supprimer") { _, _ ->
                AlarmScheduler.cancel(this, r.id)
                ReminderStore.delete(this, r.id)
                refresh()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun showQuickDialog() {
        val labels = arrayOf("Dans 1 minute (test)", "Dans 10 minutes", "Dans 30 minutes", "Dans 1 heure")
        val minutes = intArrayOf(1, 10, 30, 60)
        MaterialAlertDialogBuilder(this)
            .setTitle("⚡ Rappel rapide")
            .setItems(labels) { _, which ->
                val cal = Calendar.getInstance().apply { add(Calendar.MINUTE, minutes[which]) }
                val test = which == 0
                val r = Reminder(
                    id = ReminderStore.nextId(this),
                    name = if (test) "Test de rappel" else "Rappel rapide",
                    info = if (test) "Test de sonnerie lancé depuis le tableau de bord."
                    else "Rappel rapide créé depuis le tableau de bord.",
                    hour = cal.get(Calendar.HOUR_OF_DAY),
                    minute = cal.get(Calendar.MINUTE),
                    dateMillis = Utils.startOfDay(cal.timeInMillis)
                )
                if (r.nextTrigger() == null) {
                    // La minute choisie vient de passer : on décale d'une minute.
                    cal.add(Calendar.MINUTE, 1)
                    r.hour = cal.get(Calendar.HOUR_OF_DAY)
                    r.minute = cal.get(Calendar.MINUTE)
                    r.dateMillis = Utils.startOfDay(cal.timeInMillis)
                }
                ReminderStore.upsert(this, r)
                AlarmScheduler.schedule(this, r)
                Toast.makeText(this, "Rappel à ${Utils.time(r.hour, r.minute)}", Toast.LENGTH_SHORT).show()
                refresh()
            }
            .setNegativeButton("Fermer", null)
            .show()
    }

    private fun showReliabilityDialog() {
        val items = arrayOf(
            "🔔 Autoriser les notifications",
            "📱 Afficher sur l'écran verrouillé",
            "🔋 Désactiver l'optimisation batterie",
            "⏻ Et si le téléphone est éteint ?"
        )
        MaterialAlertDialogBuilder(this)
            .setTitle("🛡️ Fiabilité des sonneries")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> {
                        if (Build.VERSION.SDK_INT >= 33 &&
                            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                            != PackageManager.PERMISSION_GRANTED
                        ) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                        else safeStart(
                            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                                .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                        )
                    }
                    1 -> {
                        if (Build.VERSION.SDK_INT >= 34) safeStart(
                            Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT)
                                .setData(Uri.parse("package:$packageName"))
                        ) else Toast.makeText(this, "Déjà autorisé sur votre version d'Android.", Toast.LENGTH_SHORT).show()
                    }
                    2 -> safeStart(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                    3 -> showPowerOffInfo()
                }
            }
            .setNegativeButton("Fermer", null)
            .show()
    }

    private fun showPowerOffInfo() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Téléphone éteint")
            .setMessage(
                "Une application ne peut pas allumer un téléphone complètement éteint : " +
                    "c'est une limite d'Android.\n\n" +
                    "✔ Écran éteint, téléphone verrouillé ou en veille : le rappel sonne et allume l'écran.\n" +
                    "✔ Après un redémarrage : tous vos rappels sont reprogrammés automatiquement.\n" +
                    "✔ Si l'heure est tombée pendant que le téléphone était éteint : vous recevez une notification « Rappel manqué ».\n\n" +
                    "Pour que le téléphone s'allume tout seul avant l'heure du rappel, utilisez la fonction " +
                    "« Allumage / extinction programmé(e) » des réglages du téléphone (Samsung, Xiaomi, Oppo, Huawei… selon la marque)."
            )
            .setPositiveButton("Compris", null)
            .show()
    }

    private fun safeStart(i: Intent) {
        try {
            startActivity(i)
        } catch (_: Exception) {
            Toast.makeText(this, "Réglage indisponible sur cet appareil.", Toast.LENGTH_SHORT).show()
        }
    }
}
