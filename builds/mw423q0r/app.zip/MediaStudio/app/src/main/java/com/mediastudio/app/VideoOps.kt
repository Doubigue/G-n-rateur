package com.mediastudio.app

import android.content.Context
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.ChannelMixingAudioProcessor
import androidx.media3.common.audio.ChannelMixingMatrix
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.transformer.*
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.io.File

/** Compression, collage (concat) et mixage musique+vidéo via Media3 Transformer (MediaCodec matériel). */
@UnstableApi
object VideoOps {

    private fun fx(audio: List<AudioProcessor> = emptyList(), video: List<Effect> = emptyList()) =
        Effects(audio, video)

    private fun volumeProcessors(volume: Float): List<AudioProcessor> {
        val mixer = ChannelMixingAudioProcessor()
        for (ch in 1..2) mixer.putChannelMixingMatrix(ChannelMixingMatrix.create(ch, 2).scaleBy(volume))
        return listOf(mixer)
    }

    private fun item(c: Clip, maxHeight: Int?, fadeIn: Boolean = false, fadeOut: Boolean = false) =
        EditedMediaItem.Builder(c.toMediaItem())
            .setEffects(fx(video = videoEffects(c, fadeIn, fadeOut, maxHeight))).build()

    /** Découpe + filtre + texte + hauteur max + débit vidéo (H.264 + AAC). */
    suspend fun compress(
        ctx: Context, clip: Clip, output: File,
        maxHeight: Int = 720, videoBitrate: Int = 2_000_000,
        onProgress: (Float) -> Unit = {}
    ) {
        val encoderFactory = DefaultEncoderFactory.Builder(ctx)
            .setRequestedVideoEncoderSettings(
                VideoEncoderSettings.Builder().setBitrate(videoBitrate).build())
            .build()
        val seq = EditedMediaItemSequence.Builder(item(clip, maxHeight)).build()
        run(ctx, Composition.Builder(listOf(seq)).build(), output, encoderFactory, onProgress)
    }

    /** Colle les clips ; [fade] ajoute un fondu au noir entre chaque clip. */
    suspend fun concat(
        ctx: Context, clips: List<Clip>, output: File,
        fade: Boolean = false, maxHeight: Int = 1080, onProgress: (Float) -> Unit = {}
    ) {
        val items = clips.mapIndexed { i, c ->
            item(c, maxHeight, fadeIn = fade && i > 0, fadeOut = fade && i < clips.lastIndex)
        }
        val seq = EditedMediaItemSequence.Builder(items).build()
        run(ctx, Composition.Builder(listOf(seq)).build(), output, null, onProgress)
    }

    /** Musique (découpée, bouclée) sur la vidéo (découpée, filtrée, texte), volumes réglables. */
    suspend fun mixMusic(
        ctx: Context, clip: Clip, music: Clip, output: File,
        keepOriginalAudio: Boolean = true, videoVolume: Float = 1f, musicVolume: Float = 1f,
        onProgress: (Float) -> Unit = {}
    ) {
        val v = EditedMediaItem.Builder(clip.toMediaItem())
            .setRemoveAudio(!keepOriginalAudio)
            .setEffects(fx(
                audio = if (keepOriginalAudio && videoVolume != 1f) volumeProcessors(videoVolume) else emptyList(),
                video = videoEffects(clip)))
            .build()
        val m = EditedMediaItem.Builder(music.toMediaItem())
            .setRemoveVideo(true).setEffects(fx(audio = volumeProcessors(musicVolume))).build()
        val videoSeq = EditedMediaItemSequence.Builder(v).build()
        val musicSeq = EditedMediaItemSequence.Builder(m).setIsLooping(true).build()
        run(ctx, Composition.Builder(listOf(videoSeq, musicSeq)).build(), output, null, onProgress)
    }

    private suspend fun run(
        ctx: Context, composition: Composition, output: File,
        encoderFactory: Codec.EncoderFactory?, onProgress: (Float) -> Unit
    ) = withContext(Dispatchers.Main) {
        val done = CompletableDeferred<Unit>()
        val b = Transformer.Builder(ctx)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(c: Composition, r: ExportResult) { done.complete(Unit) }
                override fun onError(c: Composition, r: ExportResult, e: ExportException) {
                    done.completeExceptionally(e)
                }
            })
        encoderFactory?.let { b.setEncoderFactory(it) }
        val t = b.build()
        output.delete()
        t.start(composition, output.absolutePath)
        val holder = ProgressHolder()
        try {
            while (!done.isCompleted && isActive) {
                if (t.getProgress(holder) != Transformer.PROGRESS_STATE_NOT_STARTED)
                    onProgress(holder.progress / 100f)
                delay(300)
            }
            done.await()
        } finally { if (!done.isCompleted) t.cancel() }
    }
}
