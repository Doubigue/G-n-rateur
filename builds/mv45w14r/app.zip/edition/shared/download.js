// ============ Téléchargement automatique avec barre de progression animée ============
// Un clic sur un lien « Télécharger » lance aussitôt le transfert, affiche une barre animée,
// puis enregistre le fichier tout seul dans le dossier de téléchargements du navigateur.
import { buildInvoicePdf, DEFAULT_BRAND } from "./invoice-pdf.js";

const CSS = `
.dl-stack{position:fixed;left:50%;bottom:22px;transform:translateX(-50%);z-index:2147483000;display:grid;gap:10px;width:min(380px,calc(100vw - 24px));pointer-events:none}
@media(max-width:768px){.dl-stack{bottom:calc(88px + env(safe-area-inset-bottom,0px))}}
.dl-card{pointer-events:auto;display:grid;grid-template-columns:44px 1fr;gap:12px;align-items:center;padding:13px 15px;border-radius:18px;color:#faf8f5;background:linear-gradient(160deg,#0a1b13,#1b3d2d);box-shadow:0 24px 50px -14px rgba(0,0,0,.65),0 0 0 1px rgba(212,175,55,.4);font-family:Inter,system-ui,sans-serif;animation:dl-in .35s cubic-bezier(.2,.9,.3,1.2)}
.dl-card.out{animation:dl-out .3s forwards}
@keyframes dl-in{from{opacity:0;transform:translateY(24px) scale(.94)}}
@keyframes dl-out{to{opacity:0;transform:translateY(16px) scale(.96)}}
.dl-ico{width:44px;height:44px;border-radius:13px;display:grid;place-items:center;background:rgba(212,175,55,.16);color:#d4af37;position:relative;overflow:hidden}
.dl-ico svg{width:22px;height:22px;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
.dl-card:not(.done):not(.err) .dl-ico svg{animation:dl-bounce 1s ease-in-out infinite}
@keyframes dl-bounce{50%{transform:translateY(3px)}}
.dl-top{display:flex;justify-content:space-between;gap:10px;font-size:13px;font-weight:600}
.dl-name{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.dl-pct{flex:none;color:#d4af37;font-variant-numeric:tabular-nums}
.dl-bar{height:9px;margin-top:8px;border-radius:99px;background:rgba(255,255,255,.14);overflow:hidden}
.dl-fill{height:100%;width:0;border-radius:99px;background:repeating-linear-gradient(135deg,rgba(255,255,255,.28) 0 8px,transparent 8px 16px),linear-gradient(90deg,#8b6a32,#d4af37,#f3d66e);background-size:32px 32px,100% 100%;animation:dl-stripes .7s linear infinite;box-shadow:0 0 12px rgba(212,175,55,.7);transition:background .3s}
@keyframes dl-stripes{to{background-position:32px 0,0 0}}
.dl-sub{margin-top:6px;font-size:11.5px;opacity:.72}
.dl-card.done .dl-fill{animation:none;background:linear-gradient(90deg,#15803d,#22c55e);box-shadow:0 0 12px rgba(34,197,94,.7)}
.dl-card.done .dl-ico{background:rgba(34,197,94,.2);color:#4ade80}.dl-card.done .dl-pct{color:#4ade80}
.dl-card.err .dl-fill{animation:none;background:#dc2626;box-shadow:none}.dl-card.err .dl-ico{background:rgba(220,38,38,.2);color:#f87171}.dl-card.err .dl-pct{color:#f87171}
`;
const NS = 'xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"';
const ICON = { dl: `<svg ${NS}><path d="M12 3v12m0 0-4.5-4.5M12 15l4.5-4.5M4 20h16"/></svg>`, ok: `<svg ${NS}><path d="m5 12.5 4.5 4.5L19 7.5"/></svg>`, err: `<svg ${NS}><path d="M12 8v5m0 3.5v.01M10.3 4l-8 14a2 2 0 0 0 1.7 3h16a2 2 0 0 0 1.7-3l-8-14a2 2 0 0 0-3.4 0Z"/></svg>` };
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const size = n => n >= 1048576 ? (n / 1048576).toFixed(1).replace(".", ",") + " Mo" : Math.max(1, Math.round(n / 1024)) + " Ko";
let stack = null;
function ui(name) {
  if (!document.getElementById("dl-css")) document.head.append(Object.assign(document.createElement("style"), { id: "dl-css", textContent: CSS }));
  if (!stack) { stack = document.createElement("div"); stack.className = "dl-stack"; stack.setAttribute("aria-live", "polite"); document.body.append(stack); }
  const c = document.createElement("div"); c.className = "dl-card";
  c.innerHTML = `<div class="dl-ico">${ICON.dl}</div><div><div class="dl-top"><span class="dl-name">${esc(name)}</span><span class="dl-pct">0 %</span></div><div class="dl-bar"><div class="dl-fill"></div></div><div class="dl-sub">Téléchargement en cours…</div></div>`;
  stack.append(c);
  const q = s => c.querySelector(s);
  return {
    set(p, sub) { q(".dl-fill").style.width = p + "%"; q(".dl-pct").textContent = Math.floor(p) + " %"; if (sub) q(".dl-sub").textContent = sub; },
    done(message = "Téléchargement lancé.") { c.classList.add("done"); q(".dl-ico").innerHTML = ICON.ok; q(".dl-sub").textContent = message; q(".dl-pct").textContent = "100 %"; q(".dl-fill").style.width = "100%"; this.close(6500); },
    fail(msg) { c.classList.add("err"); q(".dl-ico").innerHTML = ICON.err; q(".dl-sub").textContent = msg; q(".dl-pct").textContent = "Échec"; this.close(6000); },
    close(ms = 0) { setTimeout(() => { c.classList.add("out"); setTimeout(() => c.remove(), 320); }, ms); },
  };
}
/** Déclenche l'enregistrement du fichier (dossier Téléchargements du navigateur). */
function trigger(href, name) {
  const a = Object.assign(document.createElement("a"), { href, download: name, rel: "noopener" });
  a.style.display = "none"; document.body.append(a); a.click(); a.remove();
}

/**
 * Les WebView Android (notamment certains APK générés depuis un site) ignorent parfois
 * les téléchargements d'URL blob via <a download>. Sur mobile, proposer d'abord la
 * feuille de partage native avec le PDF en pièce jointe : l'utilisateur peut choisir
 * « Enregistrer dans Fichiers/Téléchargements ». En navigateur classique, garder le
 * téléchargement direct.
 */
async function deliverBlob(blob, name) {
  const file = new File([blob], name, { type: blob.type || "application/pdf" });
  const isAndroidApp = /Android/i.test(navigator.userAgent) &&
    (window.Capacitor || window.ReactNativeWebView || window.Android || window.webkit?.messageHandlers);
  if (isAndroidApp && navigator.share && (!navigator.canShare || navigator.canShare({ files: [file] }))) {
    try {
      await navigator.share({ files: [file], title: name, text: "Facture — " + name });
      return "shared";
    } catch (e) {
      // L'API de partage peut refuser si l'APK a perdu l'activation utilisateur
      // pendant la génération du PDF. Seul un vrai abandon explicite n'est pas repris.
      if (e?.name === "AbortError") throw e;
    }
  }
  const obj = URL.createObjectURL(blob);
  trigger(obj, name);
  setTimeout(() => URL.revokeObjectURL(obj), 120000);
  return "download";
}
/** Fait avancer la barre affichée vers la valeur réelle, de façon fluide ; résout quand elle atteint 100 %. */
function animator(box) {
  let target = 0, shown = 0, finished = false, resolve; const end = new Promise(r => resolve = r);
  (function tick() {
    shown += Math.max((target - shown) * .12, finished ? .9 : .05); if (shown > target) shown = target;
    box.set(shown);
    if (finished && shown >= 100) return resolve();
    requestAnimationFrame(tick);
  })();
  return { to: v => { target = Math.max(target, Math.min(v, 99)); }, finish: () => { finished = true; target = 100; return end; } };
}
const nameFrom = (url, given) => {
  let n = given || (decodeURIComponent((url.match(/fl_attachment:([^/]+)/) || [])[1] || "") || decodeURIComponent((url.split("?")[0].split("/").pop() || "")) || "document");
  if (!/\.\w{2,5}$/.test(n)) n += ".pdf";
  return n;
};

/** Télécharge une URL (https ou blob:) avec barre de progression, puis l'enregistre automatiquement. */
export async function downloadFile(url, filename) {
  const name = nameFrom(url, filename), box = ui(name), an = animator(box);
  // « fl_attachment » est une transformation : Cloudinary la refuse (401) si « Strict transformations » est actif.
  // Inutile ici : le nom du fichier est donné par le site, on télécharge donc l'URL d'origine sans transformation.
  url = url.replace(/\/fl_attachment[^/]*\//, "/");
  try {
    const res = await fetch(url); if (!res.ok) throw Object.assign(new Error("HTTP " + res.status), { http: res.status });
    const total = +res.headers.get("content-length") || 0, type = res.headers.get("content-type") || "application/octet-stream";
    const chunks = []; let got = 0;
    if (res.body?.getReader) {
      const rd = res.body.getReader();
      for (;;) {
        const { done, value } = await rd.read(); if (done) break;
        chunks.push(value); got += value.length;
        an.to(total ? got / total * 100 : 92 * (1 - Math.exp(-got / 250000)));
        box.set(Math.min(99, total ? got / total * 100 : 0), `${size(got)}${total ? " / " + size(total) : ""}`);
      }
    } else { chunks.push(new Uint8Array(await res.arrayBuffer())); got = chunks[0].length; }
    await an.finish();
    const blob = new Blob(chunks, { type: type.split(";")[0] });
    const method = await deliverBlob(blob, name);
    box.done(method === "shared" ? "Choisissez « Enregistrer » dans le menu Android pour conserver le fichier." : "Téléchargement lancé. Vérifiez le dossier Téléchargements.");
  } catch (err) {
    if (err.http === 401 || err.http === 403) return box.fail("Accès refusé par Cloudinary : vérifiez Cloudinary > Settings > Security (« PDF and ZIP files delivery »).");
    if (err.http === 404) return box.fail("Fichier introuvable (facture supprimée ?).");
    // Secours (serveur sans CORS, etc.) : lien direct, le navigateur télécharge de lui-même
    try { an.to(99); await an.finish(); trigger(url, name); box.done("Téléchargement lancé. Si rien ne se passe, ouvrez le lien dans le navigateur."); } catch { box.fail("Téléchargement impossible. Réessayez."); }
  }
}

/** Enregistre un fichier généré DANS LE NAVIGATEUR (CSV, PDF…) : accepte un Blob ou une promesse de Blob. Rien n'est envoyé sur internet. */
export async function saveBlob(src, filename) {
  const box = ui(filename), an = animator(box), t0 = performance.now(); let blob = null, err = null;
  const ready = Promise.resolve(src).then(b => { blob = b; }, e => { err = e; });
  const iv = setInterval(() => { const p = Math.min(blob || err ? 96 : 85, (performance.now() - t0) / 9); an.to(p); box.set(Math.min(99, p), blob ? size(blob.size * p / 100) : "Création du document…"); }, 60);
  await Promise.all([ready, new Promise(r => setTimeout(r, 800))]); clearInterval(iv);
  if (err || !blob) return box.fail("Création impossible : " + (err?.message || "erreur"));
  await an.finish();
  try {
    const method = await deliverBlob(blob, filename);
    box.done(method === "shared" ? "Choisissez « Enregistrer » dans le menu Android pour conserver le PDF." : "Téléchargement lancé. Vérifiez le dossier Téléchargements.");
  } catch (e) {
    if (e?.name === "AbortError") box.fail("Enregistrement annulé. Rouvrez le menu de téléchargement pour réessayer.");
    else box.fail("Impossible d'enregistrer le fichier. Réessayez depuis le menu de partage Android.");
  }
}

/** Les pages déclarent comment retrouver une commande (par id) et le nom de la maison d'édition. */
let findOrder = null, getBrand = () => DEFAULT_BRAND;
export const setInvoiceSource = (find, brand) => { findOrder = find; if (brand) getBrand = brand; };
/** Fabrique la facture PDF sur l'appareil et l'enregistre (aucun passage par Cloudinary). */
export function saveInvoice(order, paid) {
  return saveBlob(buildInvoicePdf({ ...order, paidAt: order.paidAt || Date.now() }, { paid, brand: getBrand() }), `${order.invoice}${paid ? "-PAYEE" : ""}.pdf`);
}

// Tout lien de facture / [data-dl] devient un téléchargement automatique animé
document.addEventListener("click", e => {
  const inv = e.target.closest("a[data-inv]");
  if (inv) {
    e.preventDefault(); e.stopImmediatePropagation();
    const o = findOrder?.(inv.dataset.inv);
    if (o) saveInvoice(o, inv.dataset.paid === "1"); else ui("Facture").fail("Commande introuvable. Rechargez la page.");
    return;
  }
  const a = e.target.closest("a[data-dl], a.inv-dl"); if (!a) return;
  const href = a.getAttribute("href"); if (!href || href === "#") return;
  e.preventDefault(); e.stopImmediatePropagation();
  downloadFile(a.href, a.getAttribute("download") || a.dataset.name || "");
}, true);
