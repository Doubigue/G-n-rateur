# Mes professeurs

La rubrique « Mes professeurs » est accessible depuis l'accueil. Elle propose six accompagnateurs, un par langue étudiée : anglais, espagnol, portugais, russe, chinois et arabe.

Chaque fiche comprend une présentation en français et une présentation dans la langue cible, chacune pouvant être lue à voix haute. Un bouton permet également d'entendre une salutation dans la langue choisie. Les avatars ont une animation légère de mouvement et un indicateur animé pendant la lecture vocale.

Le réglage de vitesse (0,5× à 1,5×) utilise le réglage vocal partagé de l'application et s'applique donc aussi aux autres lectures.

Les voix réellement disponibles dépendent des moteurs installés/configurés sur l'appareil et des langues prises en charge par ces moteurs.
