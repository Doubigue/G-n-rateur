# Mise à jour — explications bilingues et vitesse de lecture

- Le parcours de leçon distingue visuellement l'introduction en français et les règles présentées dans la langue étudiée.
- Les chapitres de grammaire distinguent l'explication dans la langue cible et le rappel de comparaison en français ; les exemples restent accompagnés de leur traduction.
- Un curseur permet de régler la lecture de 0,5× à 1,5× (pas de 0,1×). Le réglage est mémorisé sur l'appareil et s'applique aux mots, phrases, dialogues, lectures et lectures en séquence.
- Les commandes « Lent » existantes restent disponibles et ralentissent davantage la lecture par rapport à la vitesse choisie.

Limite : cette mise à jour améliore l'affichage bilingue à partir des champs déjà présents dans les cours. Elle ne réécrit pas encore chaque règle avec un long commentaire français individualisé. Compilation Android non exécutée dans cet environnement.
