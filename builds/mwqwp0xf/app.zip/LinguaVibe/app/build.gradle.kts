import java.util.Properties
import java.net.HttpURLConnection
import java.net.URL

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("org.jetbrains.kotlin.kapt")
}

// Clé de signature dédiée à l'application : signing/keystore.properties + fichier .jks.
// Les variables d'environnement SIGNING_STORE_PASSWORD / SIGNING_KEY_PASSWORD (secrets GitHub) priment si elles existent.
val signingProps = Properties().apply {
    val f = rootProject.file("signing/keystore.properties")
    if (f.exists()) f.inputStream().use { this.load(it) }
}

// Moteur des voix hors ligne Kokoro et Piper (sherpa-onnx). La bibliothèque est téléchargée
// automatiquement à la première compilation ; les voix, elles, s'installent depuis l'application.
val sherpaVersion = "1.13.7"
val sherpaAar = file("libs/sherpa-onnx-$sherpaVersion.aar")
if (!sherpaAar.exists()) {
    sherpaAar.parentFile.mkdirs()
    var url = "https://github.com/k2-fsa/sherpa-onnx/releases/download/v$sherpaVersion/sherpa-onnx-$sherpaVersion.aar"
    logger.lifecycle("Téléchargement de sherpa-onnx $sherpaVersion…")
    for (attempt in 1..5) {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.instanceFollowRedirects = false
        val code = connection.responseCode
        if (code in 300..399) {
            url = connection.getHeaderField("Location")
            connection.disconnect()
            continue
        }
        check(code == 200) { "Téléchargement de sherpa-onnx impossible (code $code) : $url" }
        val tmp = file("${sherpaAar.path}.tmp")
        connection.inputStream.use { input -> tmp.outputStream().use { input.copyTo(it) } }
        tmp.renameTo(sherpaAar)
        break
    }
    check(sherpaAar.exists()) { "Téléchargement de sherpa-onnx impossible : trop de redirections" }
}

android {
    namespace = "com.linguavibe.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.linguavibe.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 4
        versionName = "1.3"
        ndk {
            // Téléphones (ARM) et émulateurs (x86_64)
            abiFilters += listOf("arm64-v8a", "armeabi-v7a", "x86_64")
        }
    }

    signingConfigs {
        create("dedicated") {
            storeFile = rootProject.file(signingProps.getProperty("storeFile", "signing/missing.jks"))
            storePassword = System.getenv("SIGNING_STORE_PASSWORD") ?: signingProps.getProperty("storePassword")
            keyAlias = signingProps.getProperty("keyAlias")
            keyPassword = System.getenv("SIGNING_KEY_PASSWORD") ?: signingProps.getProperty("keyPassword")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("dedicated")
        }
        debug {
            // Même clé en debug : empreinte SHA-1 stable (restrictions de clé API Firebase) et mises à jour sans désinstaller.
            signingConfig = signingConfigs.getByName("dedicated")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
        freeCompilerArgs = freeCompilerArgs + listOf(
            "-opt-in=androidx.compose.material3.ExperimentalMaterial3Api",
            "-opt-in=androidx.compose.animation.ExperimentalAnimationApi",
            "-opt-in=androidx.compose.foundation.ExperimentalFoundationApi",
            // La bibliothèque sherpa-onnx peut être compilée avec un Kotlin plus récent.
            "-Xskip-metadata-version-check"
        )
    }
    buildFeatures {
        compose = true
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
        jniLibs {
            pickFirsts += "**/libc++_shared.so"
            useLegacyPackaging = true
        }
    }
}

dependencies {
    // Affichage de vrais modèles 3D glTF/GLB sur Android (Filament).
    implementation("io.github.sceneview:sceneview:2.3.0")
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.3")

    // Progression locale persistée avec Room (fusion du module Room fourni).
    implementation("androidx.room:room-runtime:2.7.2")
    implementation("androidx.room:room-ktx:2.7.2")
    kapt("androidx.room:room-compiler:2.7.2")

    // Reconnaissance vocale hors ligne (Vosk)
    implementation("net.java.dev.jna:jna:5.13.0@aar")
    implementation("com.alphacephei:vosk-android:0.3.47@aar")

    // Voix hors ligne Kokoro et Piper (sherpa-onnx) + décompression des voix (.tar.bz2)
    implementation(files("libs/sherpa-onnx-$sherpaVersion.aar"))
    implementation("org.apache.commons:commons-compress:1.26.2")
}

kapt { correctErrorTypes = true }
