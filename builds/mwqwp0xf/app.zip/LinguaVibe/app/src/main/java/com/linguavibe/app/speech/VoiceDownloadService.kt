package com.linguavibe.app.speech

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.linguavibe.app.MainActivity
import com.linguavibe.app.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Service de premier plan qui garde les téléchargements de voix actifs quand on quitte
 * l'application (ou que l'écran s'éteint). Il affiche la progression dans une notification
 * avec les boutons Pause / Reprendre / Annuler, et s'arrête tout seul à la fin.
 */
class VoiceDownloadService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var ticker: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel(this)
        val first = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, first, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIF_ID, first)
        }
        // Le téléphone ne doit pas couper le processeur ni le Wi-Fi pendant le téléchargement.
        wakeLock = (getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LinguaVibe:voices").apply { acquire(6 * 60 * 60 * 1000L) }
        @Suppress("DEPRECATION")
        wifiLock = (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager)
            .createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "LinguaVibe:voices").apply { acquire() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val id = intent?.getStringExtra(EXTRA_ID)
        val voice = NeuralVoices.all.firstOrNull { it.id == id }
        when (intent?.action) {
            ACTION_PAUSE -> voice?.let { NeuralVoices.pause(it) }
            ACTION_RESUME -> voice?.let { NeuralVoices.install(this, it) }
            ACTION_CANCEL -> voice?.let { NeuralVoices.cancel(this, it) }
        }
        if (ticker?.isActive != true) {
            ticker = scope.launch {
                var idle = 0
                while (isActive) {
                    refresh()
                    // Plus rien ne tourne : on s'arrête en laissant une notification « en pause » si besoin.
                    if (!NeuralVoices.anyRunning) idle++ else idle = 0
                    if (idle >= 3) {
                        finish()
                        break
                    }
                    delay(1_000)
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun refresh() {
        NotificationManagerCompat.from(this).let { nm ->
            if (canNotify(this)) nm.notify(NOTIF_ID, buildNotification())
        }
    }

    private fun finish() {
        val pending = NeuralVoices.installing.entries.firstOrNull { it.value.paused }
        stopForeground(STOP_FOREGROUND_REMOVE)
        if (pending != null && canNotify(this)) {
            // Notification simple (non permanente) pour reprendre plus tard.
            NotificationManagerCompat.from(this).notify(NOTIF_PAUSED_ID, buildNotification(finalState = true))
        } else {
            NotificationManagerCompat.from(this).cancel(NOTIF_PAUSED_ID)
        }
        stopSelf()
    }

    override fun onDestroy() {
        scope.cancel()
        wakeLock?.takeIf { it.isHeld }?.release()
        wifiLock?.takeIf { it.isHeld }?.release()
        super.onDestroy()
    }

    private fun buildNotification(finalState: Boolean = false): Notification {
        val entries = NeuralVoices.installing.entries.toList()
        val main = entries.firstOrNull { it.value.active } ?: entries.firstOrNull()
        val voice = main?.let { e -> NeuralVoices.all.firstOrNull { it.id == e.key } }
        val state = main?.value

        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val title = when {
            voice == null -> "Voix hors ligne"
            state?.paused == true -> "En pause : ${voice.label}"
            state?.waitingNetwork == true -> "En attente du réseau : ${voice.label}"
            else -> "Téléchargement : ${voice.label}"
        }
        val others = entries.size - 1
        val text = (state?.error ?: state?.step ?: "Préparation…") + if (others > 0) " · +$others autre(s)" else ""

        val b = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_download)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setOngoing(!finalState)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setColor(0xFFF5B800.toInt())

        if (state != null && voice != null) {
            if (!finalState && state.active) {
                if (state.progress >= 0f) b.setProgress(1000, (state.progress * 1000).toInt(), false)
                else b.setProgress(0, 0, true)
                b.addAction(0, "Pause", action(ACTION_PAUSE, voice.id))
            } else {
                b.addAction(0, "Reprendre", action(ACTION_RESUME, voice.id))
            }
            b.addAction(0, "Annuler", action(ACTION_CANCEL, voice.id))
        }
        return b.build()
    }

    private fun action(name: String, id: String): PendingIntent {
        val intent = Intent(this, VoiceDownloadService::class.java).setAction(name).putExtra(EXTRA_ID, id)
        val code = (name + id).hashCode()
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            PendingIntent.getForegroundService(this, code, intent, flags)
        } else {
            PendingIntent.getService(this, code, intent, flags)
        }
    }

    companion object {
        private const val CHANNEL = "voice_downloads"
        private const val NOTIF_ID = 4201
        private const val NOTIF_PAUSED_ID = 4202
        const val ACTION_PAUSE = "com.linguavibe.app.voices.PAUSE"
        const val ACTION_RESUME = "com.linguavibe.app.voices.RESUME"
        const val ACTION_CANCEL = "com.linguavibe.app.voices.CANCEL"
        const val EXTRA_ID = "voice_id"

        fun start(context: Context) {
            NotificationManagerCompat.from(context).cancel(NOTIF_PAUSED_ID)
            val intent = Intent(context, VoiceDownloadService::class.java)
            try {
                ContextCompat.startForegroundService(context, intent)
            } catch (_: Exception) {
                // Démarrage refusé (appli en arrière-plan) : le téléchargement continue tant que l'appli vit.
            }
        }

        fun canNotify(context: Context): Boolean =
            Build.VERSION.SDK_INT < 33 ||
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED

        private fun createChannel(context: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(CHANNEL, "Téléchargement des voix", NotificationManager.IMPORTANCE_LOW)
                channel.description = "Progression des voix hors ligne Kokoro et Piper"
                (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
            }
        }
    }
}
