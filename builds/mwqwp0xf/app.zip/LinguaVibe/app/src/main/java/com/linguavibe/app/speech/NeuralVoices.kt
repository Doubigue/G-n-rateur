package com.linguavibe.app.speech

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.setValue
import com.k2fsa.sherpa.onnx.OfflineTts
import com.k2fsa.sherpa.onnx.OfflineTtsConfig
import com.k2fsa.sherpa.onnx.OfflineTtsKokoroModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsVitsModelConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import kotlin.coroutines.coroutineContext

enum class NeuralEngine(val label: String) { KOKORO("Kokoro"), PIPER("Piper") }

/**
 * Une voix hors ligne téléchargeable (archives publiées par le projet sherpa-onnx).
 * [langs] : codes des langues qu'elle sait lire.
 */
data class NeuralVoice(
    val id: String,
    val engine: NeuralEngine,
    val langs: List<String>,
    val label: String,
    val size: String,
    val note: String
) {
    val url: String get() = "https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/$id.tar.bz2"
}

/**
 * État d'un téléchargement (fraction 0..1, ou -1 si inconnue).
 * [paused] : mis en pause (par l'utilisateur ou faute de réseau) ; le fichier partiel est conservé.
 * [waitingNetwork] : connexion perdue, la reprise se fera toute seule au retour du réseau.
 */
data class InstallState(
    val progress: Float,
    val step: String,
    val error: String? = null,
    val paused: Boolean = false,
    val waitingNetwork: Boolean = false
) {
    val active: Boolean get() = error == null && !paused
}

/**
 * Voix neuronales hors ligne : Kokoro (multilingue, très naturelle) et Piper (une voix par langue).
 *
 * Les voix ne sont pas livrées avec l'application : on les télécharge une seule fois depuis
 * l'écran Paramètres. Elles sont rangées dans files/tts/<identifiant>/ et fonctionnent ensuite
 * sans connexion.
 */
object NeuralVoices {
    // ------------------------------------------------------------ Catalogue

    private const val MEDIUM = "Voix de qualité moyenne, bon compromis entre naturel et rapidité."
    private const val LOW = "Version allégée : plus rapide et plus petite, un peu moins naturelle."

    val kokoro = NeuralVoice(
        "kokoro-multi-lang-v1_0", NeuralEngine.KOKORO, listOf("es", "en", "pt", "zh", "fr"),
        "Kokoro multilingue", "plus de 300 Mo",
        "Une seule installation pour l'espagnol, l'anglais, le portugais du Brésil, le chinois et le français. " +
            "Voix très naturelles. Prévoir un téléphone récent (4 Go de RAM ou plus). " +
            "Kokoro ne parle ni russe ni arabe : installez Piper pour ces deux langues."
    )

    val piper = listOf(
        NeuralVoice("vits-piper-es_ES-davefx-medium", NeuralEngine.PIPER, listOf("es"), "Espagnol · Davefx", "≈ 65 Mo", MEDIUM),
        NeuralVoice("vits-piper-en_US-amy-medium", NeuralEngine.PIPER, listOf("en"), "Anglais · Amy", "≈ 65 Mo", MEDIUM),
        NeuralVoice("vits-piper-en_US-amy-low", NeuralEngine.PIPER, listOf("en"), "Anglais · Amy (légère)", "≈ 25 Mo", LOW),
        NeuralVoice("vits-piper-pt_BR-faber-medium", NeuralEngine.PIPER, listOf("pt"), "Portugais · Faber", "≈ 65 Mo", MEDIUM),
        NeuralVoice("vits-piper-ru_RU-irina-medium", NeuralEngine.PIPER, listOf("ru"), "Russe · Irina", "≈ 65 Mo", MEDIUM),
        NeuralVoice("vits-piper-ru_RU-ruslan-medium", NeuralEngine.PIPER, listOf("ru"), "Russe · Ruslan", "≈ 65 Mo", MEDIUM),
        NeuralVoice("vits-piper-zh_CN-xiao_ya-medium", NeuralEngine.PIPER, listOf("zh"), "Chinois · Xiao Ya", "≈ 65 Mo", MEDIUM),
        NeuralVoice("vits-piper-zh_CN-huayan-medium", NeuralEngine.PIPER, listOf("zh"), "Chinois · Huayan", "≈ 65 Mo", MEDIUM),
        NeuralVoice("vits-piper-ar_JO-kareem-medium", NeuralEngine.PIPER, listOf("ar"), "Arabe · Kareem", "≈ 65 Mo", MEDIUM),
        NeuralVoice("vits-piper-ar_JO-kareem-low", NeuralEngine.PIPER, listOf("ar"), "Arabe · Kareem (légère)", "≈ 25 Mo", LOW),
        NeuralVoice("vits-piper-fr_FR-siwis-medium", NeuralEngine.PIPER, listOf("fr"), "Français · Siwis", "≈ 65 Mo", MEDIUM)
    )

    val all: List<NeuralVoice> get() = listOf(kokoro) + piper

    /** Voix Kokoro choisie pour chaque langue : (voix féminine, voix masculine). */
    private val kokoroSpeakers = mapOf(
        "en" to (3 to 16),   // af_heart, am_michael
        "es" to (28 to 29),  // ef_dora, em_alex
        "pt" to (42 to 43),  // pf_dora, pm_alex
        "zh" to (47 to 50),  // zf_xiaoxiao, zm_yunxi
        "fr" to (30 to 30)   // ff_siwis
    )

    /** Langue donnée au phonétiseur de Kokoro (vide : dictionnaires anglais et chinois du modèle). */
    private val kokoroLang = mapOf("es" to "es", "pt" to "pt-br", "fr" to "fr", "en" to "", "zh" to "")

    // ------------------------------------------------------------ Installation

    /** Incrémenté à chaque installation / suppression pour rafraîchir l'interface. */
    var version by mutableIntStateOf(0)
        private set

    /** Téléchargements en cours, en pause ou en erreur, par identifiant de voix. */
    val installing = mutableStateMapOf<String, InstallState>()

    private val jobs = java.util.concurrent.ConcurrentHashMap<String, Job>()
    private val pausing: MutableSet<String> = java.util.concurrent.ConcurrentHashMap.newKeySet()
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private fun baseDir(context: Context) = File(context.filesDir, "tts")
    private fun voiceDir(context: Context, voice: NeuralVoice) = File(baseDir(context), voice.id)

    /** Fichiers partiels : gardés dans files/ (le système ne les efface pas) pour reprendre plus tard. */
    private fun partialDir(context: Context) = File(context.filesDir, "tts-partial").apply { mkdirs() }
    private fun partFile(context: Context, voice: NeuralVoice) = File(partialDir(context), "${voice.id}.tar.bz2.part")
    private fun totalFile(context: Context, voice: NeuralVoice) = File(partialDir(context), "${voice.id}.total")

    private fun savedTotal(context: Context, voice: NeuralVoice): Long =
        totalFile(context, voice).takeIf { it.isFile }?.readText()?.trim()?.toLongOrNull() ?: -1L

    /** Dossier qui contient tokens.txt (l'archive ajoute un dossier de premier niveau). */
    private fun findRoot(dir: File, depth: Int = 0): File? {
        if (!dir.isDirectory) return null
        if (File(dir, "tokens.txt").isFile) return dir
        if (depth >= 2) return null
        dir.listFiles()?.forEach { child -> if (child.isDirectory) findRoot(child, depth + 1)?.let { return it } }
        return null
    }

    fun isInstalled(context: Context, voice: NeuralVoice): Boolean = findRoot(voiceDir(context, voice)) != null

    fun sizeMb(context: Context, voice: NeuralVoice): Long {
        val dir = voiceDir(context, voice)
        if (!dir.exists()) return 0
        return dir.walkTopDown().filter { it.isFile }.sumOf { it.length() } / (1024 * 1024)
    }

    fun installed(context: Context): List<NeuralVoice> = all.filter { isInstalled(context, it) }

    /** Vrai s'il reste au moins un téléchargement qui tourne (le service de premier plan reste alors actif). */
    val anyRunning: Boolean get() = jobs.values.any { it.isActive }

    private fun mb(bytes: Long) = bytes / (1024 * 1024)

    private fun progressText(done: Long, total: Long) =
        if (total > 0) "${mb(done)} / ${mb(total)} Mo" else "${mb(done)} Mo"

    /**
     * Au lancement de l'appli : les téléchargements interrompus (appli fermée, téléphone redémarré)
     * réapparaissent « en pause », prêts à reprendre là où ils s'étaient arrêtés.
     */
    fun restore(context: Context) {
        val app = context.applicationContext
        all.forEach { voice ->
            val part = partFile(app, voice)
            if (part.isFile && jobs[voice.id]?.isActive != true && installing[voice.id] == null && !isInstalled(app, voice)) {
                val total = savedTotal(app, voice)
                installing[voice.id] = InstallState(
                    if (total > 0) part.length().toFloat() / total else -1f,
                    "En pause · ${progressText(part.length(), total)}", paused = true
                )
            }
        }
    }

    /**
     * Lance (ou reprend) le téléchargement. Il continue hors de l'appli grâce au service
     * de premier plan [VoiceDownloadService], qui affiche la progression en notification.
     */
    fun install(context: Context, voice: NeuralVoice) {
        if (jobs[voice.id]?.isActive == true) return
        val app = context.applicationContext
        pausing.remove(voice.id)
        val part = partFile(app, voice)
        val total = savedTotal(app, voice)
        installing[voice.id] = InstallState(
            if (part.isFile && total > 0) part.length().toFloat() / total else 0f,
            if (part.isFile && part.length() > 0) "Reprise à ${progressText(part.length(), total)}…" else "Connexion…"
        )
        jobs[voice.id] = ioScope.launch {
            val self = this.coroutineContext[Job]
            try {
                downloadWithRetry(app, voice)
                withContext(Dispatchers.Main) {
                    installing.remove(voice.id)
                    version++
                }
            } catch (e: Exception) {
                val cancelled = e is kotlinx.coroutines.CancellationException
                withContext(Dispatchers.Main + kotlinx.coroutines.NonCancellable) {
                    when {
                        cancelled && voice.id in pausing -> {
                            val done = partFile(app, voice).length()
                            val t = savedTotal(app, voice)
                            installing[voice.id] = InstallState(
                                if (t > 0) done.toFloat() / t else -1f,
                                "En pause · ${progressText(done, t)}", paused = true
                            )
                        }
                        cancelled -> installing.remove(voice.id)
                        else -> {
                            val done = partFile(app, voice).length()
                            val t = savedTotal(app, voice)
                            installing[voice.id] = InstallState(
                                if (t > 0) done.toFloat() / t else 0f,
                                if (done > 0) "Arrêté à ${progressText(done, t)}" else "",
                                e.message ?: "Installation impossible", paused = done > 0
                            )
                        }
                    }
                    pausing.remove(voice.id)
                }
            } finally {
                // On ne retire que ce travail-ci (une reprise rapide a pu en lancer un nouveau).
                self?.let { jobs.remove(voice.id, it) }
            }
        }
        VoiceDownloadService.start(app)
    }

    /** Met en pause : le fichier partiel est conservé, « Reprendre » repart au même octet. */
    fun pause(voice: NeuralVoice) {
        val job = jobs[voice.id] ?: return
        pausing.add(voice.id)
        job.cancel()
    }

    /** Annule et efface ce qui avait déjà été téléchargé. */
    fun cancel(context: Context, voice: NeuralVoice) {
        pausing.remove(voice.id)
        jobs.remove(voice.id)?.cancel()
        installing.remove(voice.id)
        val app = context.applicationContext
        ioScope.launch {
            kotlinx.coroutines.delay(300)
            partFile(app, voice).delete()
            totalFile(app, voice).delete()
        }
    }

    fun clearError(voice: NeuralVoice) {
        val state = installing[voice.id] ?: return
        if (state.error == null) return
        if (state.paused) installing[voice.id] = state.copy(error = null) else installing.remove(voice.id)
    }

    suspend fun delete(context: Context, voice: NeuralVoice) {
        lock.withLock {
            if (loadedKey?.startsWith(voice.id) == true) releaseEngine()
        }
        withContext(Dispatchers.IO) { voiceDir(context, voice).deleteRecursively() }
        version++
    }

    private suspend fun report(id: String, progress: Float, step: String, waiting: Boolean = false) =
        withContext(Dispatchers.Main) { installing[id] = InstallState(progress, step, waitingNetwork = waiting) }

    private fun isOnline(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork ?: return false) ?: return false
        return caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    /**
     * Télécharge en reprenant après chaque coupure : si le réseau tombe, on attend son retour
     * puis on repart de l'octet où l'on s'était arrêté (requête HTTP « Range »).
     */
    private suspend fun downloadWithRetry(context: Context, voice: NeuralVoice) {
        var failures = 0
        while (true) {
            coroutineContext.ensureActive()
            try {
                downloadPart(context, voice)
                break
            } catch (e: java.io.IOException) {
                coroutineContext.ensureActive()
                val done = partFile(context, voice).length()
                val total = savedTotal(context, voice)
                val progress = if (total > 0) done.toFloat() / total else -1f
                if (!isOnline(context)) {
                    // Pas de réseau : on attend son retour, sans limite de temps.
                    report(voice.id, progress, "Connexion perdue à ${progressText(done, total)} · reprise automatique dès le retour du réseau", true)
                    while (!isOnline(context)) kotlinx.coroutines.delay(3_000)
                    failures = 0
                } else {
                    failures++
                    if (failures > 8) throw IllegalStateException("Le serveur ne répond pas. Touchez « Reprendre » pour réessayer.")
                    report(voice.id, progress, "Réseau instable · nouvel essai dans ${failures * 5} s…", true)
                    kotlinx.coroutines.delay(failures * 5_000L)
                }
            }
        }
        val archive = partFile(context, voice)
        val total = archive.length()
        try {
            extract(voice, archive, total, File(baseDir(context), voice.id))
        } catch (e: Exception) {
            // Archive abîmée : on l'efface pour qu'un nouvel essai reparte proprement.
            if (e !is kotlinx.coroutines.CancellationException) {
                archive.delete()
                totalFile(context, voice).delete()
            }
            throw e
        }
        archive.delete()
        totalFile(context, voice).delete()
    }

    /** Ouvre la connexion en suivant les redirections (GitHub → serveur de fichiers) en gardant l'en-tête Range. */
    private fun open(url: String, from: Long): HttpURLConnection {
        var current = url
        repeat(6) {
            val c = URL(current).openConnection() as HttpURLConnection
            c.connectTimeout = 20_000
            c.readTimeout = 30_000
            c.instanceFollowRedirects = false
            c.setRequestProperty("Accept-Encoding", "identity")
            if (from > 0) c.setRequestProperty("Range", "bytes=$from-")
            val code = c.responseCode
            if (code in 300..399) {
                val location = c.getHeaderField("Location") ?: throw IllegalStateException("Redirection invalide")
                c.disconnect()
                current = URL(URL(current), location).toString()
            } else {
                return c
            }
        }
        throw IllegalStateException("Trop de redirections")
    }

    private suspend fun downloadPart(context: Context, voice: NeuralVoice) {
        val part = partFile(context, voice)
        var from = if (part.isFile) part.length() else 0L
        val known = savedTotal(context, voice)
        if (known > 0 && from >= known) return // déjà complet : il ne reste qu'à décompresser

        val connection = open(voice.url, from)
        try {
            val code = connection.responseCode
            val total: Long
            when {
                code == 416 && from > 0 -> return // le serveur n'a plus rien à envoyer : fichier complet
                code == 206 -> {
                    // « Content-Range: bytes 1000-4999/5000 »
                    total = connection.getHeaderField("Content-Range")?.substringAfterLast('/')?.toLongOrNull()
                        ?: (from + connection.contentLengthLong)
                }
                code in 200..299 -> {
                    // Le serveur ne sait pas reprendre : on recommence au début.
                    from = 0
                    total = connection.contentLengthLong
                }
                else -> throw IllegalStateException("Téléchargement impossible (code $code)")
            }
            if (total > 0) {
                if (known > 0 && known != total) {
                    // Le fichier a changé sur le serveur depuis la pause : on repart de zéro.
                    part.delete()
                    totalFile(context, voice).writeText(total.toString())
                    throw java.io.IOException("Fichier modifié sur le serveur")
                }
                totalFile(context, voice).writeText(total.toString())
                val need = (total - from) + total * 3 / 2
                if (context.filesDir.usableSpace < need) {
                    throw IllegalStateException("Espace insuffisant : libérez environ ${mb(need)} Mo.")
                }
            }
            var done = from
            var last = 0L
            val buffer = ByteArray(64 * 1024)
            connection.inputStream.use { ins ->
                FileOutputStream(part, from > 0).use { out ->
                    while (true) {
                        coroutineContext.ensureActive()
                        val n = ins.read(buffer)
                        if (n < 0) break
                        out.write(buffer, 0, n)
                        done += n
                        if (done - last > 256 * 1024) {
                            last = done
                            report(voice.id, if (total > 0) done.toFloat() / total else -1f, "Téléchargement : ${progressText(done, total)}")
                        }
                    }
                }
            }
            if (total > 0 && done < total) throw java.io.IOException("Téléchargement interrompu")
            if (total <= 0) totalFile(context, voice).writeText(done.toString())
        } finally {
            connection.disconnect()
        }
    }

    /** Décompresse une archive .tar.bz2 (lecteur tar minimal : fichiers, dossiers, noms longs). */
    private suspend fun extract(voice: NeuralVoice, archive: File, total: Long, target: File) {
        val tmp = File(target.parentFile, "${voice.id}.tmp")
        tmp.deleteRecursively()
        tmp.mkdirs()
        val base = tmp.canonicalPath + File.separator
        try {
            val counting = CountingStream(FileInputStream(archive))
            BZip2CompressorInputStream(BufferedInputStream(counting, 256 * 1024)).use { tar ->
                val header = ByteArray(512)
                val buffer = ByteArray(64 * 1024)
                var longName: String? = null
                var last = 0L
                while (true) {
                    coroutineContext.ensureActive()
                    if (!readFully(tar, header)) break
                    if (header.all { it == 0.toByte() }) break
                    val size = octal(header, 124, 12)
                    val type = header[156].toInt().toChar()
                    var name = longName ?: run {
                        val prefix = text(header, 345, 155)
                        val plain = text(header, 0, 100)
                        if (prefix.isNotEmpty()) "$prefix/$plain" else plain
                    }
                    longName = null
                    when (type) {
                        'L' -> { // nom long GNU : le contenu est le nom de l'entrée suivante
                            longName = String(readBytes(tar, size), Charsets.UTF_8).trimEnd('\u0000', '\n')
                            skipPadding(tar, size)
                            continue
                        }
                        'x' -> { // en-tête pax : on récupère « path= » si présent
                            val pax = String(readBytes(tar, size), Charsets.UTF_8)
                            Regex("""\d+ path=([^\n]*)\n""").find(pax)?.let { longName = it.groupValues[1] }
                            skipPadding(tar, size)
                            continue
                        }
                        'g' -> {
                            skip(tar, size); skipPadding(tar, size); continue
                        }
                    }
                    name = name.removePrefix("./")
                    val out = File(tmp, name)
                    if (!(out.canonicalPath + File.separator).startsWith(base)) {
                        throw SecurityException("Archive invalide")
                    }
                    when (type) {
                        '5' -> out.mkdirs()
                        '0', '\u0000', '7' -> {
                            out.parentFile?.mkdirs()
                            FileOutputStream(out).use { fos ->
                                var left = size
                                while (left > 0) {
                                    val n = tar.read(buffer, 0, minOf(buffer.size.toLong(), left).toInt())
                                    if (n < 0) throw IllegalStateException("Archive incomplète")
                                    fos.write(buffer, 0, n)
                                    left -= n
                                }
                            }
                            skipPadding(tar, size)
                        }
                        else -> { // liens et autres types : ignorés
                            skip(tar, size); skipPadding(tar, size)
                        }
                    }
                    if (counting.count - last > 1024 * 1024) {
                        last = counting.count
                        report(
                            voice.id, if (total > 0) counting.count.toFloat() / total else -1f,
                            "Décompression…"
                        )
                    }
                }
            }
            if (findRoot(tmp) == null) throw IllegalStateException("Cette archive ne contient pas de voix valide.")
            target.deleteRecursively()
            if (!tmp.renameTo(target)) {
                tmp.copyRecursively(target, overwrite = true)
                tmp.deleteRecursively()
            }
        } catch (e: Exception) {
            tmp.deleteRecursively()
            throw e
        }
    }

    private class CountingStream(private val input: InputStream) : InputStream() {
        var count = 0L
        override fun read(): Int = input.read().also { if (it >= 0) count++ }
        override fun read(b: ByteArray, off: Int, len: Int): Int = input.read(b, off, len).also { if (it > 0) count += it }
        override fun close() = input.close()
    }

    private fun readFully(input: InputStream, buf: ByteArray): Boolean {
        var off = 0
        while (off < buf.size) {
            val n = input.read(buf, off, buf.size - off)
            if (n < 0) return false
            off += n
        }
        return true
    }

    private fun readBytes(input: InputStream, size: Long): ByteArray {
        val buf = ByteArray(size.toInt())
        if (size > 0 && !readFully(input, buf)) throw IllegalStateException("Archive incomplète")
        return buf
    }

    private fun skip(input: InputStream, size: Long) {
        var left = size
        val buf = ByteArray(16 * 1024)
        while (left > 0) {
            val n = input.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
            if (n < 0) return
            left -= n
        }
    }

    private fun skipPadding(input: InputStream, size: Long) {
        val rest = (512 - size % 512) % 512
        if (rest > 0) skip(input, rest)
    }

    private fun text(h: ByteArray, off: Int, len: Int): String {
        var end = off
        while (end < off + len && h[end] != 0.toByte()) end++
        return String(h, off, end - off, Charsets.UTF_8).trim()
    }

    private fun octal(h: ByteArray, off: Int, len: Int): Long {
        // Grands fichiers : encodage binaire (bit de poids fort à 1).
        if (h[off].toInt() and 0x80 != 0) {
            var v = 0L
            for (i in off + 1 until off + len) v = (v shl 8) or (h[i].toLong() and 0xff)
            return v
        }
        val s = text(h, off, len).trim()
        return if (s.isEmpty()) 0 else s.toLong(8)
    }

    // ------------------------------------------------------------ Synthèse

    private val lock = Mutex()
    private var engine: OfflineTts? = null
    private var loadedKey: String? = null

    /** Vrai pendant le chargement d'une voix en mémoire (quelques secondes pour Kokoro). */
    var loading by androidx.compose.runtime.mutableStateOf(false)
        private set

    /** Première voix installée capable de lire [lang], selon le moteur demandé. */
    fun voiceFor(context: Context, lang: String, engine: NeuralEngine): NeuralVoice? = when (engine) {
        NeuralEngine.KOKORO -> kokoro.takeIf { lang in it.langs && isInstalled(context, it) }
        NeuralEngine.PIPER -> piper.firstOrNull { lang in it.langs && isInstalled(context, it) }
    }

    private fun releaseEngine() {
        try {
            engine?.release()
        } catch (_: Exception) {
        }
        engine = null
        loadedKey = null
    }

    private fun buildConfig(voice: NeuralVoice, root: File, lang: String): OfflineTtsConfig {
        val threads = Runtime.getRuntime().availableProcessors().coerceIn(1, 4)
        fun path(name: String) = File(root, name).takeIf { it.exists() }?.absolutePath ?: ""
        return if (voice.engine == NeuralEngine.KOKORO) {
            val lexicons = when (lang) {
                "en" -> listOf("lexicon-us-en.txt")
                "zh" -> listOf("lexicon-us-en.txt", "lexicon-zh.txt")
                else -> emptyList()
            }.map { path(it) }.filter { it.isNotEmpty() }.joinToString(",")
            OfflineTtsConfig(
                model = OfflineTtsModelConfig(
                    kokoro = OfflineTtsKokoroModelConfig(
                        model = path("model.onnx"),
                        voices = path("voices.bin"),
                        tokens = path("tokens.txt"),
                        dataDir = path("espeak-ng-data"),
                        lexicon = lexicons,
                        lang = kokoroLang[lang] ?: ""
                    ),
                    numThreads = threads
                )
            )
        } else {
            val model = root.listFiles()?.firstOrNull { it.isFile && it.name.endsWith(".onnx") }?.absolutePath
                ?: throw IllegalStateException("Modèle Piper introuvable")
            val fsts = root.listFiles()?.filter { it.name.endsWith(".fst") }?.sortedBy { it.name }
                ?.joinToString(",") { it.absolutePath } ?: ""
            OfflineTtsConfig(
                model = OfflineTtsModelConfig(
                    vits = OfflineTtsVitsModelConfig(
                        model = model,
                        lexicon = path("lexicon.txt"),
                        tokens = path("tokens.txt"),
                        dataDir = path("espeak-ng-data")
                    ),
                    numThreads = threads
                ),
                ruleFsts = fsts
            )
        }
    }

    /**
     * Fabrique (ou retrouve en cache) le fichier WAV de [text] lu par [voice].
     * [playbackRate] : vitesse de lecture appliquée directement par le modèle.
     */
    suspend fun speechFile(
        context: Context,
        voice: NeuralVoice,
        lang: String,
        text: String,
        playbackRate: Float,
        male: Boolean
    ): File = withContext(Dispatchers.Default) {
        val sid = if (voice.engine == NeuralEngine.KOKORO) {
            kokoroSpeakers[lang]?.let { if (male) it.second else it.first } ?: 0
        } else 0
        val speed = playbackRate.coerceIn(0.5f, 1.5f)
        val dir = File(context.cacheDir, "neural").apply { mkdirs() }
        val file = File(dir, hash("${voice.id}|$lang|$sid|$speed|$text") + ".wav")
        if (file.isFile && file.length() > 44) return@withContext file

        lock.withLock {
            val key = "${voice.id}|$lang"
            if (loadedKey != key || engine == null) {
                releaseEngine()
                val root = findRoot(voiceDir(context, voice)) ?: throw IllegalStateException("Voix non installée")
                withContext(Dispatchers.Main) { loading = true }
                try {
                    engine = OfflineTts(config = buildConfig(voice, root, lang))
                    loadedKey = key
                } finally {
                    withContext(Dispatchers.Main) { loading = false }
                }
            }
            val audio = engine!!.generate(text = text, sid = sid, speed = speed)
            if (audio.samples.isEmpty()) throw IllegalStateException("La voix n'a rien produit")
            val tmp = File(dir, file.name + ".tmp")
            if (!audio.save(tmp.absolutePath)) throw IllegalStateException("Enregistrement audio impossible")
            tmp.renameTo(file)
        }
        file
    }

    fun cacheSizeMb(context: Context): Long =
        File(context.cacheDir, "neural").walkTopDown().filter { it.isFile }.sumOf { it.length() } / (1024 * 1024)

    fun clearCache(context: Context) {
        File(context.cacheDir, "neural").deleteRecursively()
    }

    private fun hash(text: String): String =
        MessageDigest.getInstance("SHA-1").digest(text.toByteArray()).joinToString("") { "%02x".format(it) }
}
