package com.linguavibe.app.speech

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.vosk.LibVosk
import org.vosk.LogLevel
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/**
 * Gère les modèles Vosk (import d'un ZIP, téléchargement, suppression)
 * et la reconnaissance vocale hors ligne.
 *
 * Chaque langue possède son dossier : files/vosk/<code>/<nom-du-modèle>/
 */
object VoskManager {
    private const val SAMPLE_RATE = 16000f

    private var model: Model? = null
    private var modelLang: String? = null
    private var service: SpeechService? = null
    private var recognizer: Recognizer? = null

    /** Identifiant du micro en cours d'écoute (un seul à la fois). */
    var activeId by mutableStateOf<String?>(null)
        private set

    /** Identifiant du micro qui attend le chargement du modèle. */
    var loadingId by mutableStateOf<String?>(null)

    /** Texte reconnu en direct. */
    var partial by mutableStateOf("")
        private set

    /** Incrémenté à chaque installation / suppression pour rafraîchir l'interface. */
    var installsVersion by mutableIntStateOf(0)
        private set

    // ---------------------------------------------------------------- Modèles

    private fun langDir(context: Context, lang: String): File =
        File(File(context.filesDir, "vosk"), lang)

    /** Cherche le dossier racine du modèle (celui qui contient am/, conf/, graph/...). */
    private fun findModelRoot(dir: File, depth: Int = 0): File? {
        if (!dir.isDirectory) return null
        val looksLikeModel = File(dir, "am").isDirectory ||
            File(dir, "final.mdl").isFile ||
            (File(dir, "conf").isDirectory && File(dir, "graph").isDirectory)
        if (looksLikeModel) return dir
        if (depth >= 3) return null
        dir.listFiles()?.forEach { child ->
            if (child.isDirectory) findModelRoot(child, depth + 1)?.let { return it }
        }
        return null
    }

    fun isInstalled(context: Context, lang: String): Boolean =
        findModelRoot(langDir(context, lang)) != null

    /** Nom du modèle installé (nom du dossier), ou null. */
    fun installedName(context: Context, lang: String): String? {
        val root = findModelRoot(langDir(context, lang)) ?: return null
        return if (root.name == lang) "modèle personnalisé" else root.name
    }

    fun installedSizeMb(context: Context, lang: String): Long {
        val dir = langDir(context, lang)
        if (!dir.exists()) return 0
        return dir.walkTopDown().filter { it.isFile }.sumOf { it.length() } / (1024 * 1024)
    }

    fun delete(context: Context, lang: String) {
        if (modelLang == lang) releaseModel()
        langDir(context, lang).deleteRecursively()
        installsVersion++
    }

    /**
     * Installe un modèle à partir d'un fichier ZIP (celui téléchargé sur alphacephei.com/vosk/models).
     * [onProgress] reçoit le nombre d'octets lus.
     */
    suspend fun installZip(
        context: Context,
        lang: String,
        input: InputStream,
        onProgress: (Long) -> Unit
    ) = withContext(Dispatchers.IO) {
        val target = langDir(context, lang)
        val tmp = File(target.parentFile, "$lang.tmp")
        tmp.deleteRecursively()
        tmp.mkdirs()
        try {
            val base = tmp.canonicalPath + File.separator
            var read = 0L
            var lastReport = 0L
            val buffer = ByteArray(64 * 1024)
            ZipInputStream(BufferedInputStream(input)).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    val out = File(tmp, entry.name)
                    // Protection contre les chemins malveillants dans l'archive.
                    if (!(out.canonicalPath + File.separator).startsWith(base)) {
                        throw SecurityException("Archive invalide")
                    }
                    if (entry.isDirectory) {
                        out.mkdirs()
                    } else {
                        out.parentFile?.mkdirs()
                        FileOutputStream(out).use { fos ->
                            while (true) {
                                val n = zip.read(buffer)
                                if (n < 0) break
                                fos.write(buffer, 0, n)
                                read += n
                                if (read - lastReport > 512 * 1024) {
                                    lastReport = read
                                    onProgress(read)
                                }
                            }
                        }
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
            if (findModelRoot(tmp) == null) {
                throw IllegalArgumentException(
                    "Ce fichier ZIP ne contient pas de modèle Vosk valide (dossiers am/, conf/, graph/ introuvables)."
                )
            }
            if (modelLang == lang) releaseModel()
            target.deleteRecursively()
            if (!tmp.renameTo(target)) {
                tmp.copyRecursively(target, overwrite = true)
                tmp.deleteRecursively()
            }
        } catch (e: Exception) {
            tmp.deleteRecursively()
            throw e
        } finally {
            withContext(Dispatchers.Main) { installsVersion++ }
        }
    }

    /** Télécharge le modèle recommandé puis l'installe. [onProgress] : fraction 0..1, ou -1 si inconnue. */
    suspend fun download(
        context: Context,
        lang: String,
        url: String,
        onProgress: (Float) -> Unit
    ) = withContext(Dispatchers.IO) {
        val zipFile = File(context.cacheDir, "$lang-model.zip")
        try {
            val connection = URL(url).openConnection() as HttpURLConnection
            connection.connectTimeout = 20_000
            connection.readTimeout = 30_000
            connection.instanceFollowRedirects = true
            try {
                if (connection.responseCode !in 200..299) {
                    throw IllegalStateException("Téléchargement impossible (code ${connection.responseCode})")
                }
                val total = connection.contentLengthLong
                // Il faut la place du ZIP plus celle du modèle décompressé.
                if (total > 0 && context.filesDir.usableSpace < total * 23 / 10) {
                    throw IllegalStateException(
                        "Espace insuffisant : libérez environ ${total * 23 / 10 / (1024 * 1024)} Mo."
                    )
                }
                var done = 0L
                var lastReport = 0L
                val buffer = ByteArray(64 * 1024)
                connection.inputStream.use { ins ->
                    FileOutputStream(zipFile).use { out ->
                        while (true) {
                            val n = ins.read(buffer)
                            if (n < 0) break
                            out.write(buffer, 0, n)
                            done += n
                            if (done - lastReport > 256 * 1024) {
                                lastReport = done
                                onProgress(if (total > 0) done.toFloat() / total else -1f)
                            }
                        }
                    }
                }
            } finally {
                connection.disconnect()
            }
            onProgress(-1f) // décompression
            FileInputStream(zipFile).use { installZip(context, lang, it) {} }
        } finally {
            zipFile.delete()
        }
    }

    // ----------------------------------------------------------- Reconnaissance

    @Synchronized
    private fun releaseModel() {
        cancel()
        try {
            model?.close()
        } catch (_: Exception) {
        }
        model = null
        modelLang = null
    }

    /** Charge (une seule fois) le modèle de la langue. Peut prendre quelques secondes. */
    suspend fun ensureModel(context: Context, lang: String): Model = withContext(Dispatchers.IO) {
        synchronized(this@VoskManager) {
            val current = model
            if (current != null && modelLang == lang) {
                current
            } else {
                val root = findModelRoot(langDir(context, lang))
                    ?: throw IllegalStateException("Modèle vocal non installé pour cette langue.")
                try {
                    model?.close()
                } catch (_: Exception) {
                }
                model = null
                modelLang = null
                LibVosk.setLogLevel(LogLevel.WARNINGS)
                val loaded = Model(root.absolutePath)
                model = loaded
                modelLang = lang
                loaded
            }
        }
    }

    private fun textOf(json: String?, key: String): String = try {
        JSONObject(json ?: "{}").optString(key, "")
    } catch (_: Exception) {
        ""
    }

    /** Démarre l'écoute. À appeler depuis le fil principal, permission micro accordée. */
    fun start(id: String, model: Model, onFinal: (String) -> Unit, onError: (String) -> Unit) {
        cancel()
        try {
            val rec = Recognizer(model, SAMPLE_RATE)
            recognizer = rec
            val svc = SpeechService(rec, SAMPLE_RATE)
            service = svc
            activeId = id
            partial = ""
            val heard = StringBuilder()
            svc.startListening(object : RecognitionListener {
                override fun onPartialResult(hypothesis: String?) {
                    if (service !== svc) return
                    partial = (heard.toString() + " " + textOf(hypothesis, "partial")).trim()
                }

                override fun onResult(hypothesis: String?) {
                    if (service !== svc) return
                    val text = textOf(hypothesis, "text")
                    if (text.isNotBlank()) heard.append(' ').append(text)
                    partial = heard.toString().trim()
                }

                override fun onFinalResult(hypothesis: String?) {
                    if (service !== svc) return
                    val text = textOf(hypothesis, "text")
                    if (text.isNotBlank()) heard.append(' ').append(text)
                    cancel()
                    onFinal(heard.toString().trim())
                }

                override fun onError(exception: Exception?) {
                    if (service !== svc) return
                    cancel()
                    onError(exception?.message ?: "Erreur du microphone")
                }

                override fun onTimeout() {
                    if (service !== svc) return
                    cancel()
                    onFinal(heard.toString().trim())
                }
            })
        } catch (e: Exception) {
            cancel()
            onError(e.message ?: "Impossible de démarrer le microphone")
        }
    }

    /** Arrête l'écoute : le résultat final arrive ensuite dans onFinal. */
    fun stop() {
        try {
            service?.stop()
        } catch (_: Exception) {
        }
    }

    /** Annule tout sans résultat. */
    fun cancel() {
        val svc = service
        val rec = recognizer
        service = null
        recognizer = null
        activeId = null
        partial = ""
        try {
            svc?.cancel()
            svc?.shutdown()
        } catch (_: Exception) {
        }
        try {
            rec?.close()
        } catch (_: Exception) {
        }
    }
}
