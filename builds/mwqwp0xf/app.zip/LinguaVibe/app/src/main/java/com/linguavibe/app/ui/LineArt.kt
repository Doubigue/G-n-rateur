package com.linguavibe.app.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Un trait d'un dessin lineart, écrit comme une donnée de chemin SVG (commande M absolue au début).
 * [weight] multiplie l'épaisseur ; [accent] utilise la couleur d'accent ; [fill] remplit au lieu de tracer.
 */
class LineStroke(val d: String, val weight: Float = 1f, val accent: Boolean = false, val fill: Boolean = false)

/** Dessin lineart vectoriel, défini dans un cadre [width] × [height]. */
class LineDrawing(val width: Float, val height: Float, val strokes: List<LineStroke>)

private class Prepared(val path: Path, val length: Float, val stroke: LineStroke)

/** Découpe chaque trait en contours simples (un par commande M) pour pouvoir les mesurer et les animer. */
private fun prepare(drawing: LineDrawing): List<Prepared> {
    val out = ArrayList<Prepared>()
    for (s in drawing.strokes) {
        val parts = s.d.trim().split(Regex("(?=M)")).filter { it.isNotBlank() }
        for (part in parts) {
            val path = PathParser().parsePathString(part).toPath()
            val measure = PathMeasure()
            measure.setPath(path, false)
            out += Prepared(path, measure.length, s)
        }
    }
    return out
}

/**
 * Affiche un dessin lineart animé : les traits se dessinent l'un après l'autre (tracé à la main),
 * puis le dessin flotte doucement. [brush] remplace [color] pour un tracé en dégradé (or du logo, par exemple).
 */
@Composable
fun LineArt(
    drawing: LineDrawing,
    modifier: Modifier = Modifier,
    color: Color = Ink,
    accent: Color = Gold,
    brush: Brush? = null,
    strokeWidth: Dp = 2.2.dp,
    animate: Boolean = true,
    drawMillis: Int = 1400,
    delayMillis: Int = 0,
    float: Boolean = true
) {
    val prepared = remember(drawing) { prepare(drawing) }
    val progress = remember(drawing) { Animatable(if (animate) 0f else 1f) }
    LaunchedEffect(drawing, animate) {
        if (animate) {
            progress.snapTo(0f)
            kotlinx.coroutines.delay(delayMillis.toLong())
            progress.animateTo(1f, tween(drawMillis, easing = FastOutSlowInEasing))
        } else {
            progress.snapTo(1f)
        }
    }
    val transition = rememberInfiniteTransition(label = "lineart")
    val dy by transition.animateFloat(
        initialValue = -1f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "dy"
    )
    val sway by transition.animateFloat(
        initialValue = -1f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(3100, easing = LinearEasing), RepeatMode.Reverse),
        label = "sway"
    )
    Canvas(
        modifier.graphicsLayer {
            if (float) {
                translationY = dy * 3.dp.toPx()
                rotationZ = sway * 1.2f
            }
        }
    ) {
        val s = minOf(size.width / drawing.width, size.height / drawing.height)
        val ox = (size.width - drawing.width * s) / 2f
        val oy = (size.height - drawing.height * s) / 2f
        val base = strokeWidth.toPx() / s
        val t = progress.value
        val n = prepared.size.coerceAtLeast(1)
        val segment = Path()
        val measure = PathMeasure()
        translate(ox, oy) {
            scale(s, s, pivot = Offset.Zero) {
                prepared.forEachIndexed { i, p ->
                    // Chaque contour démarre un peu après le précédent.
                    val start = 0.55f * i / n
                    val local = ((t - start) / 0.45f).coerceIn(0f, 1f)
                    if (local <= 0f) return@forEachIndexed
                    val tint = if (p.stroke.accent) accent else color
                    if (p.stroke.fill) {
                        if (brush != null && !p.stroke.accent) drawPath(p.path, brush, alpha = local, style = Fill)
                        else drawPath(p.path, tint, alpha = local, style = Fill)
                        return@forEachIndexed
                    }
                    val style = Stroke(width = base * p.stroke.weight, cap = StrokeCap.Round, join = StrokeJoin.Round)
                    val path = if (local >= 1f) p.path else {
                        segment.reset()
                        measure.setPath(p.path, false)
                        measure.getSegment(0f, p.length * local, segment, true)
                        segment
                    }
                    if (brush != null && !p.stroke.accent) drawPath(path, brush, style = style)
                    else drawPath(path, tint, style = style)
                }
            }
        }
    }
}
