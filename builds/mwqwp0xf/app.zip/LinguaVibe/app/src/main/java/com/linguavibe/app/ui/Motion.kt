package com.linguavibe.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linguavibe.app.data.Vocab
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/** Emoji qui flotte doucement : sert d'illustration animée. */
@Composable
fun FloatingEmoji(emoji: String, fontSize: Int = 56, modifier: Modifier = Modifier, offsetMs: Int = 0) {
    val transition = rememberInfiniteTransition(label = "float")
    val dy by transition.animateFloat(
        initialValue = -6f, targetValue = 6f,
        animationSpec = infiniteRepeatable(
            tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse, StartOffset(offsetMs)
        ),
        label = "dy"
    )
    val rotation by transition.animateFloat(
        initialValue = -5f, targetValue = 5f,
        animationSpec = infiniteRepeatable(tween(2300, easing = LinearEasing), RepeatMode.Reverse),
        label = "rotation"
    )
    Text(
        emoji,
        fontSize = fontSize.sp,
        modifier = modifier.graphicsLayer {
            translationY = dy.dp.toPx()
            rotationZ = rotation
        }
    )
}

/** Bandeau illustré et animé : dégradé, bulles en mouvement, emojis flottants. */
@Composable
fun SceneBanner(
    emoji: String,
    extras: List<String>,
    color: Color,
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    tag: String? = null
) {
    val transition = rememberInfiniteTransition(label = "scene")
    val phase by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing)),
        label = "phase"
    )
    Box(
        modifier
            .fillMaxWidth()
            .height(168.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(Brush.linearGradient(listOf(color, color.copy(alpha = 0.62f))))
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val w = this.size.width
            val h = this.size.height
            for (i in 0 until 7) {
                val angle = (phase + i / 7f) * 2f * PI.toFloat()
                val cx = w * (0.08f + 0.15f * i) + cos(angle) * 22f
                val cy = h * (0.5f + 0.34f * sin(angle + i))
                drawCircle(
                    color = Color.White.copy(alpha = 0.08f + 0.015f * i),
                    radius = 16f + 10f * i,
                    center = Offset(cx, cy)
                )
            }
        }
        Row(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                if (tag != null) {
                    Text(
                        tag,
                        color = color,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(Color.White)
                            .padding(horizontal = 10.dp, vertical = 3.dp)
                    )
                    Spacer(Modifier.height(8.dp))
                }
                Text(title, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp, lineHeight = 26.sp)
                Spacer(Modifier.height(4.dp))
                Text(subtitle, color = Color.White.copy(alpha = 0.9f), fontSize = 14.sp)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                FloatingEmoji(emoji, 58)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    extras.take(3).forEachIndexed { i, e -> FloatingEmoji(e, 22, offsetMs = 300 * (i + 1)) }
                }
            }
        }
    }
}

private class ConfettiPiece(val x: Float, val speed: Float, val seed: Float, val color: Color, val side: Float)

/** Pluie de confettis jouée une fois (fin de quiz réussie). */
@Composable
fun Confetti(modifier: Modifier = Modifier) {
    val progress = remember { Animatable(0f) }
    LaunchedEffect(Unit) { progress.animateTo(1f, tween(2800, easing = LinearOutSlowInEasing)) }
    val palette = listOf(Indigo, Coral, Good, Warn, Color(0xFFE94FA1), Color(0xFF29B6F6))
    val pieces = remember {
        List(80) {
            ConfettiPiece(
                Random.nextFloat(), 0.7f + Random.nextFloat() * 0.7f, Random.nextFloat(),
                palette[Random.nextInt(palette.size)], 10f + Random.nextFloat() * 14f
            )
        }
    }
    Canvas(modifier.fillMaxSize()) {
        val p = progress.value
        val w = this.size.width
        val h = this.size.height
        pieces.forEach { piece ->
            val x = piece.x * w + sin(p * 9f + piece.seed * 20f) * 36f
            val y = -40f + p * h * piece.speed * 1.2f
            rotate(degrees = p * 720f * (piece.seed - 0.5f), pivot = Offset(x, y)) {
                drawRect(
                    color = piece.color.copy(alpha = (1f - p * p).coerceIn(0f, 1f)),
                    topLeft = Offset(x, y),
                    size = Size(piece.side, piece.side * 0.6f)
                )
            }
        }
    }
}

/** Anneau de score animé. */
@Composable
fun ScoreRing(score: Int, diameter: Dp = 72.dp) {
    val animated by animateFloatAsState(score / 100f, tween(900, easing = FastOutSlowInEasing), label = "score")
    val color = scoreColor(score)
    Box(Modifier.size(diameter), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 8.dp.toPx()
            val arcSize = Size(this.size.width - stroke, this.size.height - stroke)
            val origin = Offset(stroke / 2f, stroke / 2f)
            drawArc(
                color = color.copy(alpha = 0.18f), startAngle = 0f, sweepAngle = 360f, useCenter = false,
                topLeft = origin, size = arcSize, style = Stroke(stroke)
            )
            drawArc(
                color = color, startAngle = -90f, sweepAngle = 360f * animated, useCenter = false,
                topLeft = origin, size = arcSize, style = Stroke(stroke, cap = StrokeCap.Round)
            )
        }
        Text("$score%", fontWeight = FontWeight.Bold, color = color, fontSize = 16.sp)
    }
}

/** Bouton micro avec ondes pulsées pendant l'écoute. */
@Composable
fun PulsingMic(listening: Boolean, loading: Boolean, color: Color, onClick: () -> Unit) {
    val transition = rememberInfiniteTransition(label = "mic")
    val pulse by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1300, easing = LinearEasing)),
        label = "pulse"
    )
    val scale by animateFloatAsState(if (listening) 1.08f else 1f, spring(dampingRatio = 0.45f), label = "micScale")
    Box(Modifier.size(88.dp), contentAlignment = Alignment.Center) {
        if (listening) {
            Canvas(Modifier.fillMaxSize()) {
                val maxRadius = this.size.minDimension / 2f
                for (k in 0..1) {
                    val p = (pulse + k * 0.5f) % 1f
                    drawCircle(Bad.copy(alpha = (1f - p) * 0.35f), radius = maxRadius * (0.62f + 0.38f * p))
                }
            }
        }
        Box(
            Modifier
                .size(58.dp)
                .graphicsLayer { scaleX = scale; scaleY = scale }
                .clip(CircleShape)
                .background(if (listening) Bad else color)
                .clickable(enabled = !loading, onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            if (loading) {
                CircularProgressIndicator(modifier = Modifier.size(24.dp), color = Color.White, strokeWidth = 2.dp)
            } else {
                Text(if (listening) "⏹" else "🎤", fontSize = 24.sp)
            }
        }
    }
}

/** Barres audio animées affichées pendant l'écoute. */
@Composable
fun Waveform(color: Color, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "wave")
    val phase by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1100, easing = LinearEasing)),
        label = "wavePhase"
    )
    Canvas(modifier.width(150.dp).height(30.dp)) {
        val bars = 18
        val slot = this.size.width / bars
        val h = this.size.height
        for (i in 0 until bars) {
            val amp = abs(sin(phase * 2f * PI.toFloat() + i * 0.55f))
            val barHeight = h * (0.18f + 0.82f * amp)
            drawRoundRect(
                color = color.copy(alpha = 0.45f + 0.55f * amp),
                topLeft = Offset(i * slot + slot * 0.25f, (h - barHeight) / 2f),
                size = Size(slot * 0.5f, barHeight),
                cornerRadius = CornerRadius(slot * 0.25f, slot * 0.25f)
            )
        }
    }
}

/** Apparition en cascade des éléments d'une liste. */
@Composable
fun StaggerIn(index: Int, content: @Composable () -> Unit) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(70L * index.coerceAtMost(8))
        visible = true
    }
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(380)) + slideInVertically(tween(380)) { it / 3 }
    ) {
        content()
    }
}

/** Barre de progression animée. */
@Composable
fun AnimatedBar(fraction: Float, color: Color, modifier: Modifier = Modifier) {
    val animated by animateFloatAsState(fraction.coerceIn(0f, 1f), tween(700, easing = FastOutSlowInEasing), label = "bar")
    Box(
        modifier
            .fillMaxWidth()
            .height(10.dp)
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.18f))
    ) {
        Box(
            Modifier
                .fillMaxWidth(animated)
                .height(10.dp)
                .clip(RoundedCornerShape(50))
                .background(color)
        )
    }
}

/** Carte de vocabulaire qui se retourne (illustration + mot / traduction + exemple). */
@Composable
fun FlipCard(vocab: Vocab, color: Color, onSpeak: () -> Unit, modifier: Modifier = Modifier) {
    var flipped by remember { mutableStateOf(false) }
    val rotation by animateFloatAsState(
        if (flipped) 180f else 0f,
        spring(dampingRatio = 0.7f, stiffness = Spring.StiffnessLow),
        label = "flip"
    )
    val front = rotation <= 90f
    Box(
        modifier
            .height(206.dp)
            .graphicsLayer {
                rotationY = rotation
                cameraDistance = 14f * density
            }
            .clip(RoundedCornerShape(22.dp))
            .background(if (front) Color.White else color)
            .clickable { flipped = !flipped }
            .padding(10.dp),
        contentAlignment = Alignment.Center
    ) {
        if (front) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(vocab.emoji, fontSize = 40.sp)
                Spacer(Modifier.height(4.dp))
                Text(
                    vocab.word, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Ink,
                    textAlign = TextAlign.Center
                )
                if (vocab.pron.isNotBlank()) {
                    Text(
                        "🗣 ${vocab.pron}", fontSize = 12.sp, color = color, fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center, lineHeight = 15.sp
                    )
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    "🔊",
                    fontSize = 18.sp,
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(color.copy(alpha = 0.14f))
                        .clickable(onClick = onSpeak)
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                )
            }
        } else {
            Column(
                Modifier.graphicsLayer { rotationY = 180f },
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    vocab.translation, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(6.dp))
                Text(vocab.example, fontSize = 13.sp, color = Color.White, textAlign = TextAlign.Center, lineHeight = 16.sp)
                if (vocab.examplePron.isNotBlank()) {
                    Text(
                        "🗣 ${vocab.examplePron}", fontSize = 11.sp, color = Color.White.copy(alpha = 0.92f),
                        textAlign = TextAlign.Center, lineHeight = 14.sp
                    )
                }
                Text(
                    vocab.exampleTr, fontSize = 12.sp, color = Color.White.copy(alpha = 0.8f),
                    textAlign = TextAlign.Center, lineHeight = 15.sp
                )
            }
        }
    }
}
