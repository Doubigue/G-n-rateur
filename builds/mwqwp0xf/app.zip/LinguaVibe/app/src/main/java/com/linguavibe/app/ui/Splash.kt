package com.linguavibe.app.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Logo DL VIBE STUDIO redessiné en lineart (sans la TV), cadre 800 × 610. */
val DlVibeLogo = LineDrawing(
    800f, 610f, listOf(
        // Orbite
        LineStroke("M118 318 C 40 230 170 120 400 104 C 600 92 730 150 690 222", weight = 1.4f),
        LineStroke("M690 222 C 680 238 668 252 654 264", weight = 1f),
        LineStroke("M630 280 C 616 288 602 296 588 302", weight = 1f),
        LineStroke("M566 308 C 552 312 536 316 520 318", weight = 1f),
        // D
        LineStroke("M150 120 H 270 C 372 120 430 186 430 262 C 430 338 372 404 270 404 H 150 Z", weight = 1.8f),
        LineStroke("M206 172 H 266 C 334 172 372 212 372 262 C 372 312 334 352 266 352 H 206 Z", weight = 1f),
        // Bouton lecture
        LineStroke("M250 222 L 318 262 L 250 302 Z", weight = 1.6f, accent = true),
        // L
        LineStroke("M456 120 H 520 V 344 H 646 V 404 H 456 Z", weight = 1.8f),
        LineStroke("M478 140 V 384 H 626", weight = 0.8f),
        // Étincelles
        LineStroke("M700 96 l 6 16 l 16 6 l -16 6 l -6 16 l -6 -16 l -16 -6 l 16 -6 Z", weight = 1f),
        LineStroke("M96 150 l 4 10 l 10 4 l -10 4 l -4 10 l -4 -10 l -10 -4 l 10 -4 Z", weight = 1f),
        LineStroke("M667 150 a 5 5 0 1 0 10 0 a 5 5 0 1 0 -10 0", weight = 1f),
        // Ruban rouge
        LineStroke("M120 528 C 260 500 540 500 680 528 L 662 586 C 520 556 280 556 138 586 Z", accent = true, fill = true),
        LineStroke("M120 528 C 260 500 540 500 680 528 L 662 586 C 520 556 280 556 138 586 Z", weight = 0.8f),
        LineStroke("M120 528 L 80 542 L 104 564 L 80 590 L 138 586", weight = 1f),
        LineStroke("M680 528 L 720 542 L 696 564 L 720 590 L 662 586", weight = 1f),
    )
)

val GoldBrush = Brush.linearGradient(
    listOf(GoldSoft, Gold, Color(0xFFC98A00)),
    start = Offset(0f, 90f), end = Offset(0f, 600f)
)

/** Fond « nuit » avec losanges géométriques discrets (inspiré des affiches de référence). */
@Composable
fun NightBackdrop(modifier: Modifier = Modifier) {
    Canvas(modifier.background(Brush.radialGradient(listOf(Navy, Night), radius = 1600f))) {
        val step = 120.dp.toPx()
        val line = Color.White.copy(alpha = 0.035f)
        var x = -size.height
        while (x < size.width + size.height) {
            drawLine(line, Offset(x, 0f), Offset(x + size.height, size.height), 1.5f)
            drawLine(line, Offset(x + size.height, 0f), Offset(x, size.height), 1.5f)
            x += step
        }
        // Halo doré derrière le logo
        drawCircle(
            Brush.radialGradient(
                listOf(Gold.copy(alpha = 0.16f), Color.Transparent),
                center = center, radius = size.minDimension * 0.6f
            ),
            radius = size.minDimension * 0.6f
        )
    }
}

/** Splash animé de 2 secondes : le logo se dessine trait par trait, puis le texte apparaît. */
@OptIn(ExperimentalTextApi::class)
@Composable
fun SplashScreen(onDone: () -> Unit) {
    val textAlpha = remember { Animatable(0f) }
    val exit = remember { Animatable(1f) }
    LaunchedEffect(Unit) {
        launch {
            delay(850)
            textAlpha.animateTo(1f, tween(550, easing = FastOutSlowInEasing))
        }
        delay(1750)
        exit.animateTo(0f, tween(250))
        onDone()
    }
    val measurer = rememberTextMeasurer()
    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer { alpha = exit.value },
        contentAlignment = Alignment.Center
    ) {
        NightBackdrop(Modifier.fillMaxSize())
        Box(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 28.dp)
                .aspectRatio(800f / 610f)
        ) {
            LineArt(
                DlVibeLogo,
                Modifier.fillMaxSize(),
                accent = Ruby,
                brush = GoldBrush,
                strokeWidth = 2.6.dp,
                drawMillis = 1300,
                float = false
            )
            // Textes du logo, dans le même repère 800 × 610.
            Canvas(Modifier.fillMaxSize().graphicsLayer { alpha = textAlpha.value }) {
                val s = size.width / 800f
                val title = measurer.measure(
                    "DL VIBE STUDIO",
                    TextStyle(
                        fontFamily = Display, fontWeight = FontWeight.Black,
                        fontSize = (74f * s).toSp(), letterSpacing = (2f * s).toSp(),
                        drawStyle = Stroke(width = 3.2f * s)
                    )
                )
                drawText(
                    title, brush = GoldBrush,
                    topLeft = Offset(400f * s - title.size.width / 2f, 488f * s - title.firstBaseline)
                )
                val sign = measurer.measure(
                    "Doubigue Loubikoa",
                    TextStyle(
                        fontFamily = Accent, fontStyle = FontStyle.Italic,
                        fontWeight = FontWeight.SemiBold, fontSize = (34f * s).toSp(),
                        color = Color.White
                    )
                )
                drawText(sign, topLeft = Offset(400f * s - sign.size.width / 2f, 556f * s - sign.firstBaseline))
            }
        }
        Text(
            "LinguaVibe",
            Modifier.align(Alignment.BottomCenter).padding(bottom = 48.dp).graphicsLayer { alpha = textAlpha.value },
            style = TextStyle(
                fontFamily = Poppins, fontWeight = FontWeight.Medium,
                fontSize = 15.sp, letterSpacing = 4.sp, color = GoldSoft.copy(alpha = 0.8f),
                textAlign = TextAlign.Center
            )
        )
    }
}
