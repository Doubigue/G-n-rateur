package com.linguavibe.app.ui

import com.google.android.filament.Engine
import com.google.android.filament.gltfio.FilamentAsset
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.pow
import kotlin.math.sin

/**
 * Pilote directement le nœud glTF « mouth » d'un professeur 3D.
 *
 * Le mesh de la bouche est centré sur l'origine du nœud (la position est portée par la translation du nœud),
 * donc une mise à l'échelle l'ouvre sur place sans le déplacer.
 *
 * - [update] reçoit le niveau sonore réel (0..1) quand il est disponible ;
 * - sinon (analyse audio indisponible), un rythme syllabique simulé prend le relais pendant la parole.
 *
 * C'est une ouverture pilotée par l'amplitude, pas une synchronisation phonème par phonème.
 */
class MouthRig private constructor(
    private val engine: Engine,
    private val entity: Int,
    private val matrix: FloatArray
) {
    private var open = 0f
    private var clock = 0f

    fun update(level: Float, levelIsLive: Boolean, speaking: Boolean, dtSeconds: Float) {
        val dt = dtSeconds.coerceIn(0f, 0.1f)
        clock += dt
        val target = when {
            levelIsLive -> {
                // Seuil bas pour ignorer le bruit de fond, puis courbe douce pour mieux voir les petites voyelles.
                val gated = ((level - 0.04f) / 0.96f).coerceIn(0f, 1f)
                gated.pow(0.7f)
            }
            speaking -> {
                // Repli (voix sans analyse) : enveloppe syllabique approximative, indépendante de l'audio.
                val s = 0.40f + 0.35f * sin(2f * PI.toFloat() * 4.4f * clock) +
                    0.15f * sin(2f * PI.toFloat() * 7.1f * clock + 1.3f)
                s.coerceIn(0f, 1f)
            }
            else -> 0f
        }
        // Ouverture rapide, fermeture un peu plus lente : plus naturel qu'un suivi linéaire.
        val k = 1f - exp(-dt * if (target > open) 38f else 16f)
        open += (target - open) * k

        val tm = engine.transformManager
        val instance = tm.getInstance(entity)
        if (instance == 0) return
        matrix[0] = 1f - 0.18f * open  // un peu plus étroite quand elle s'ouvre
        matrix[5] = 1f + 1.1f * open   // ouverture verticale
        matrix[10] = 1f + 0.5f * open
        tm.setTransform(instance, matrix)
    }

    companion object {
        /** Retrouve le nœud « mouth » du modèle chargé ; null si le modèle n'en a pas. */
        fun find(engine: Engine, asset: FilamentAsset?): MouthRig? {
            val entity = asset?.getFirstEntityByName("mouth") ?: return null
            if (entity == 0) return null
            val tm = engine.transformManager
            val instance = tm.getInstance(entity)
            if (instance == 0) return null
            val matrix = FloatArray(16)
            tm.getTransform(instance, matrix) // conserve la translation de la bouche
            return MouthRig(engine, entity, matrix)
        }
    }
}
