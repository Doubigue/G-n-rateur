package com.linguavibe.app.speech

import android.content.Context
import android.media.MediaPlayer
import android.media.audiofx.Visualizer
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.io.File
import java.util.Locale

/**
 * Fait entendre la prononciation modèle.
 * Ordre par défaut : ElevenLabs (si configuré), puis les voix hors ligne Kokoro et Piper
 * (si elles sont installées), puis la synthèse vocale d'Android.
 */
class Speaker(context: Context) : TextToSpeech.OnInitListener {
    private val appContext = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val tts = TextToSpeech(appContext, this)
    private var ready = false
    private var pending: (() -> Unit)? = null
    private var player: MediaPlayer? = null
    private var visualizer: Visualizer? = null

    /** Niveau sonore réel de la lecture MediaPlayer, normalisé entre 0 et 1. */
    var speechLevel by mutableStateOf(0f)
        private set
    /** Vrai quand [speechLevel] vient réellement de l'audio (faux : voix indisponible ou analyse refusée). */
    var levelLive by mutableStateOf(false)
        private set
    /** Vrai si la voix en cours se joue sans analyse audio : l'animation de bouche passe alors en repli. */
    var levelUnavailable by mutableStateOf(false)
        private set
    private var job: Job? = null
    private var sequenceId = 0

    // Voix Android : on synthétise d'abord dans un fichier pour la rejouer via MediaPlayer,
    // ce qui donne accès à l'analyse du niveau sonore (comme pour les autres voix).
    private var fileUtterance: String? = null
    private var fileTarget: File? = null
    private var fileText = ""
    private var fileRate = 1f
    private var fileCallback: (() -> Unit)? = null

    val settings = VoiceSettings(appContext)

    /** Faux si la voix Android de la langue demandée n'est pas installée. */
    var voiceAvailable by mutableStateOf(true)
        private set

    /** Dernière erreur de la voix ElevenLabs (affichée à l'apprenant). */
    var lastError by mutableStateOf<String?>(null)
        private set

    /** Vrai pendant la lecture d'une suite de phrases (« écouter la leçon »). */
    var sequencePlaying by mutableStateOf(false)
        private set

    /** Position de la phrase lue dans la suite en cours (-1 hors lecture). */
    var sequenceIndex by mutableStateOf(-1)
        private set

    /** Nom de la voix utilisée pour la dernière phrase (affiché dans les paramètres). */
    var lastEngine by mutableStateOf("")
        private set

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
        if (!ready) voiceAvailable = false
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                if (utteranceId != null && utteranceId == fileUtterance) {
                    main.post { playSynthesized(utteranceId) }
                } else finish()
            }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                if (utteranceId != null && utteranceId == fileUtterance) {
                    // La synthèse en fichier a échoué : lecture directe, sans niveau sonore.
                    main.post { fallbackDirect(utteranceId) }
                } else finish()
            }
        })
    }

    private fun finish() {
        main.post {
            val callback = pending
            pending = null
            callback?.invoke()
        }
    }

    /** Arrête le son en cours sans toucher à la suite de phrases. */
    private fun halt() {
        levelUnavailable = false
        fileUtterance = null
        fileCallback = null
        releaseVisualizer()
        speechLevel = 0f
        job?.cancel()
        job = null
        pending = null
        player?.let {
            try {
                it.stop()
            } catch (_: Exception) {
            }
            it.release()
        }
        player = null
        if (ready) tts.stop()
    }

    fun speak(text: String, locale: Locale, slow: Boolean = false, onDone: (() -> Unit)? = null) {
        sequenceId++
        sequencePlaying = false
        sequenceIndex = -1
        val rate = (settings.playbackSpeed * if (slow) 0.65f else 1.0f).coerceIn(0.35f, 1.5f)
        start(text, locale, rate, onDone)
    }

    /** Lit plusieurs phrases à la suite (en partant de [from]). */
    fun speakAll(texts: List<String>, locale: Locale, slow: Boolean = false, from: Int = 0) {
        val id = ++sequenceId
        sequencePlaying = true
        fun next(index: Int) {
            if (id != sequenceId) return
            if (index >= texts.size) {
                sequencePlaying = false
                sequenceIndex = -1
                return
            }
            sequenceIndex = index
            val rate = (settings.playbackSpeed * if (slow) 0.65f else 1.0f).coerceIn(0.35f, 1.5f)
            start(texts[index], locale, rate) { next(index + 1) }
        }
        next(from)
    }

    fun stop() {
        sequenceId++
        sequencePlaying = false
        sequenceIndex = -1
        halt()
    }

    private enum class Source { ELEVEN, KOKORO, PIPER, ANDROID }

    /** Ordre d'essai des voix selon le réglage choisi dans les paramètres. */
    private fun order(): List<Source> = when (settings.engine) {
        VoiceSettings.ENGINE_KOKORO -> listOf(Source.KOKORO, Source.PIPER, Source.ANDROID)
        VoiceSettings.ENGINE_PIPER -> listOf(Source.PIPER, Source.KOKORO, Source.ANDROID)
        VoiceSettings.ENGINE_ELEVEN -> listOf(Source.ELEVEN, Source.KOKORO, Source.PIPER, Source.ANDROID)
        VoiceSettings.ENGINE_ANDROID -> listOf(Source.ANDROID)
        else -> listOf(Source.ELEVEN, Source.KOKORO, Source.PIPER, Source.ANDROID)
    }

    private fun start(text: String, locale: Locale, rate: Float, onDone: (() -> Unit)?) {
        halt()
        val lang = locale.language
        val sources = order().filter { source ->
            when (source) {
                Source.ELEVEN -> settings.ready
                Source.KOKORO -> NeuralVoices.voiceFor(appContext, lang, NeuralEngine.KOKORO) != null
                Source.PIPER -> NeuralVoices.voiceFor(appContext, lang, NeuralEngine.PIPER) != null
                Source.ANDROID -> true
            }
        }
        if (sources.first() == Source.ANDROID) {
            lastEngine = "Voix du téléphone"
            speakTts(text, locale, rate, onDone)
            return
        }
        job = scope.launch {
            for (source in sources) {
                if (source == Source.ANDROID) break
                try {
                    val file = when (source) {
                        Source.ELEVEN -> ElevenLabs.speechFile(
                            appContext, settings.apiKey, settings.voiceId, settings.model, text, lang
                        )
                        else -> {
                            val engine = if (source == Source.KOKORO) NeuralEngine.KOKORO else NeuralEngine.PIPER
                            val voice = NeuralVoices.voiceFor(appContext, lang, engine)!!
                            NeuralVoices.speechFile(appContext, voice, lang, text, rate, settings.kokoroMale)
                        }
                    }
                    lastError = null
                    lastEngine = when (source) {
                        Source.ELEVEN -> "ElevenLabs"
                        Source.KOKORO -> "Kokoro"
                        else -> "Piper"
                    }
                    // La vitesse est intégrée au fichier généré par les voix hors ligne.
                    // Ne pas la réappliquer au lecteur, sinon le réglage serait doublé.
                    play(file, if (source == Source.ELEVEN) rate else 1.0f, onDone)
                    return@launch
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    // Pas de réseau, quota dépassé, voix trop lourde… : on essaie la voix suivante.
                    lastError = when (source) {
                        Source.ELEVEN -> e.message ?: "Voix ElevenLabs indisponible."
                        else -> "Voix hors ligne indisponible : ${e.message ?: e.javaClass.simpleName}."
                    }
                }
            }
            lastEngine = "Voix du téléphone"
            speakTts(text, locale, rate, onDone)
        }
    }

    /** Analyse uniquement le flux audio de ce MediaPlayer (jamais le micro). */
    private fun attachVisualizer(mp: MediaPlayer) {
        releaseVisualizer()
        try {
            val capture = Visualizer(mp.audioSessionId)
            val range = Visualizer.getCaptureSizeRange()
            capture.captureSize = range[1].coerceAtMost(1024)
            capture.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(
                    visualizer: Visualizer?, waveform: ByteArray?, samplingRate: Int
                ) {
                    if (waveform.isNullOrEmpty()) return
                    var sum = 0.0
                    for (sample in waveform) {
                        val centered = (sample.toInt() and 0xff) - 128
                        sum += centered * centered
                    }
                    val rms = kotlin.math.sqrt(sum / waveform.size).toFloat()
                    val level = ((rms - 3f) / 68f).coerceIn(0f, 1f)
                    main.post {
                        // Lissage léger pour éviter les mouvements saccadés du visage.
                        speechLevel = speechLevel * 0.35f + level * 0.65f
                    }
                }

                override fun onFftDataCapture(
                    visualizer: Visualizer?, fft: ByteArray?, samplingRate: Int
                ) = Unit
            }, (Visualizer.getMaxCaptureRate() / 2).coerceAtLeast(1), true, false)
            capture.enabled = true
            visualizer = capture
            levelLive = true
        } catch (_: Throwable) {
            // Certains appareils refusent l'effet de visualisation : la lecture audio continue.
            levelUnavailable = true
            speechLevel = 0f
            releaseVisualizer()
        }
    }

    private fun releaseVisualizer() {
        levelLive = false
        visualizer?.let { effect ->
            try { effect.enabled = false } catch (_: Throwable) { }
            try { effect.release() } catch (_: Throwable) { }
        }
        visualizer = null
    }

    private fun play(file: File, rate: Float, onDone: (() -> Unit)?) {
        val mp = MediaPlayer()
        player = mp
        pending = onDone
        mp.setOnCompletionListener {
            if (player === it) {
                releaseVisualizer()
                speechLevel = 0f
                it.release()
                player = null
                finish()
            }
        }
        mp.setOnErrorListener { failed, _, _ ->
            if (player === failed) {
                releaseVisualizer()
                speechLevel = 0f
                failed.release()
                player = null
                finish()
            }
            true
        }
        mp.setDataSource(file.absolutePath)
        mp.prepare()
        mp.playbackParams = mp.playbackParams.setSpeed(rate)
        attachVisualizer(mp)
        mp.start()
    }

    private fun speakTts(text: String, locale: Locale, rate: Float, onDone: (() -> Unit)?) {
        speechLevel = 0f
        if (!ready) {
            onDone?.invoke()
            return
        }
        val result = tts.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            voiceAvailable = false
            onDone?.invoke()
            return
        }
        voiceAvailable = true
        val ttsRate = (0.95f * rate).coerceIn(0.35f, 1.5f)
        tts.setSpeechRate(ttsRate)

        // Essai 1 : synthèse dans un fichier, relue par MediaPlayer + Visualizer (niveau sonore réel).
        appContext.cacheDir.listFiles { f -> f.name.startsWith("tts_") }?.forEach { it.delete() }
        val id = "f" + System.nanoTime()
        val target = File(appContext.cacheDir, "tts_$id.wav")
        fileUtterance = id
        fileTarget = target
        fileText = text
        fileRate = ttsRate
        fileCallback = onDone
        val queued = try {
            tts.synthesizeToFile(text, null, target, id) == TextToSpeech.SUCCESS
        } catch (_: Throwable) {
            false
        }
        if (!queued) fallbackDirect(id)
    }

    /** La voix Android a fini d'écrire le fichier : on le joue avec l'analyse du niveau sonore. */
    private fun playSynthesized(id: String) {
        if (id != fileUtterance) return // lecture arrêtée ou remplacée entre-temps
        val file = fileTarget
        val callback = fileCallback
        if (file == null || !file.exists() || file.length() < 512L) {
            fallbackDirect(id)
            return
        }
        fileUtterance = null
        fileCallback = null
        try {
            // La vitesse est déjà intégrée au fichier par setSpeechRate.
            play(file, 1.0f, callback)
        } catch (_: Throwable) {
            player?.let { try { it.release() } catch (_: Throwable) { } }
            player = null
            releaseVisualizer()
            fileUtterance = id
            fallbackDirect(id)
        }
    }

    /** Dernier recours : lecture directe par le moteur Android (pas de niveau sonore). */
    private fun fallbackDirect(id: String) {
        if (id != fileUtterance) return
        fileUtterance = null
        val callback = fileCallback
        fileCallback = null
        speechLevel = 0f
        levelUnavailable = true
        pending = callback
        tts.setSpeechRate(fileRate)
        tts.speak(fileText, TextToSpeech.QUEUE_FLUSH, null, "u" + System.nanoTime())
    }

    fun shutdown() {
        stop()
        scope.cancel()
        tts.shutdown()
    }
}
