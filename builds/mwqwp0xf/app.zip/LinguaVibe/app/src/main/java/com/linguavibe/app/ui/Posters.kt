package com.linguavibe.app.ui

import android.content.Context
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ------------------------------------------------------------- Préférences d'affichage

/** Mémorise le mode grille / liste de chaque écran. */
object UiPrefs {
    private fun prefs(c: Context) = c.getSharedPreferences("ui", Context.MODE_PRIVATE)
    fun isGrid(c: Context, key: String): Boolean = prefs(c).getBoolean("grid_$key", true)
    fun setGrid(c: Context, key: String, value: Boolean) = prefs(c).edit().putBoolean("grid_$key", value).apply()
}

@Composable
fun rememberGridMode(key: String): MutableState<Boolean> {
    val context = LocalContext.current
    val state = remember(key) { mutableStateOf(UiPrefs.isGrid(context, key)) }
    LaunchedEffect(state.value) { UiPrefs.setGrid(context, key, state.value) }
    return state
}

// ---------------------------------------------------------------- Motifs africains

/** Motif wax / bogolan discret dessiné en fond de carte (cercles concentriques, points, zigzags). */
fun Modifier.waxPattern(color: Color = Color.White, alpha: Float = 0.10f, seed: Int = 0): Modifier = drawBehind {
    val c = color.copy(alpha = alpha)
    val u = 18.dp.toPx()
    val stroke = Stroke(1.2.dp.toPx())
    // Cercles concentriques en haut à droite
    val cx = size.width - u * (1.2f + (seed % 3) * 0.4f)
    val cy = u * (0.8f + (seed % 2) * 0.6f)
    for (r in 1..4) drawCircle(c, radius = u * 0.7f * r, center = Offset(cx, cy), style = stroke)
    // Rangée de zigzags en bas
    val zig = Path()
    var x = 0f
    val y = size.height - u * 0.7f
    zig.moveTo(0f, y)
    while (x < size.width) {
        zig.lineTo(x + u / 2, y - u / 3); zig.lineTo(x + u, y); x += u
    }
    drawPath(zig, c, style = stroke)
    // Points bogolan
    var px = u * 0.6f
    while (px < size.width) {
        drawCircle(c, radius = 1.6.dp.toPx(), center = Offset(px, size.height - u * 0.25f)); px += u * 0.5f
    }
}

// ------------------------------------------------------------------- Petits éléments

/** Pastille arrondie style affiche (fond jaune, texte sombre par défaut). */
@Composable
fun Pill(text: String, bg: Color = Gold, fg: Color = Night, modifier: Modifier = Modifier) {
    Text(
        text, color = fg, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1,
        modifier = modifier.clip(RoundedCornerShape(50)).background(bg).padding(horizontal = 12.dp, vertical = 5.dp)
    )
}

/** Fine barre de progression dorée sur fond translucide. */
@Composable
fun PosterBar(fraction: Float, color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.22f))
    ) {
        Box(Modifier.fillMaxWidth(fraction.coerceIn(0f, 1f)).fillMaxHeight().clip(RoundedCornerShape(50)).background(color))
    }
}

/** Bouton grille / liste dessiné en lineart. */
@Composable
fun ViewToggle(grid: Boolean, onChange: (Boolean) -> Unit, tint: Color = Navy) {
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(tint.copy(alpha = 0.08f)).padding(3.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        listOf(true, false).forEach { g ->
            val selected = grid == g
            val bg by animateColorAsState(if (selected) tint else Color.Transparent, label = "toggle")
            Box(
                Modifier.size(36.dp).clip(CircleShape).background(bg).clickable { onChange(g) },
                contentAlignment = Alignment.Center
            ) {
                val ink = if (selected) Gold else tint
                Canvas(Modifier.size(16.dp)) {
                    val w = 1.8.dp.toPx()
                    if (g) {
                        val h = size.width / 2 - 2.dp.toPx()
                        for (i in 0..1) for (j in 0..1) drawRoundRect(
                            ink, topLeft = Offset(i * (h + 4.dp.toPx()), j * (h + 4.dp.toPx())),
                            size = androidx.compose.ui.geometry.Size(h, h),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(2.dp.toPx()), style = Stroke(w)
                        )
                    } else {
                        for (k in 0..2) {
                            val y = size.height * (0.15f + k * 0.35f)
                            drawCircle(ink, 1.6.dp.toPx(), Offset(1.6.dp.toPx(), y))
                            drawLine(ink, Offset(5.dp.toPx(), y), Offset(size.width, y), w, StrokeCap.Round)
                        }
                    }
                }
            }
        }
    }
}

/** Flèche retour dessinée. */
@Composable
fun BackArrow(color: Color, onClick: () -> Unit) {
    Box(
        Modifier.size(42.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.12f)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(18.dp)) {
            val w = 2.2.dp.toPx()
            drawLine(color, Offset(size.width * 0.9f, size.height / 2), Offset(size.width * 0.1f, size.height / 2), w, StrokeCap.Round)
            drawLine(color, Offset(size.width * 0.1f, size.height / 2), Offset(size.width * 0.45f, size.height * 0.15f), w, StrokeCap.Round)
            drawLine(color, Offset(size.width * 0.1f, size.height / 2), Offset(size.width * 0.45f, size.height * 0.85f), w, StrokeCap.Round)
        }
    }
}

/** Grand titre style affiche. */
val PosterTitle = TextStyle(fontFamily = Display, fontWeight = FontWeight.Black, letterSpacing = (-0.5).sp)
val AccentText = TextStyle(fontFamily = Accent, fontStyle = FontStyle.Italic, fontWeight = FontWeight.SemiBold)

// -------------------------------------------------------------- Cartes « affiche »

/**
 * Carte affiche générique : dégradé, motif wax, dessin lineart animé.
 * En grille : dessin en haut, texte dessous. En liste : dessin à gauche.
 */
@Composable
fun PosterCard(
    theme: PosterTheme,
    drawing: LineDrawing,
    grid: Boolean,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    seed: Int = 0,
    badge: (@Composable () -> Unit)? = null,
    onClick: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(26.dp)
    Box(
        modifier
            .fillMaxWidth()
            .alpha(if (enabled) 1f else 0.55f)
            .shadow(8.dp, shape, ambientColor = theme.end, spotColor = theme.end)
            .clip(shape)
            .background(Brush.linearGradient(listOf(theme.start, theme.end)))
            .waxPattern(seed = seed)
            .clickable(enabled = enabled, onClick = onClick)
    ) {
        if (grid) {
            Column(Modifier.padding(14.dp)) {
                LineArt(
                    drawing, Modifier.fillMaxWidth().aspectRatio(1.25f),
                    color = Color.White, accent = theme.accent, strokeWidth = 2.dp, delayMillis = seed * 70
                )
                Spacer(Modifier.height(6.dp))
                Column(verticalArrangement = Arrangement.spacedBy(4.dp), content = content)
            }
        } else {
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(88.dp).clip(RoundedCornerShape(20.dp)).background(Color.White.copy(alpha = 0.10f)),
                    contentAlignment = Alignment.Center
                ) {
                    LineArt(
                        drawing, Modifier.size(78.dp),
                        color = Color.White, accent = theme.accent, strokeWidth = 1.8.dp, delayMillis = seed * 70
                    )
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp), content = content)
            }
        }
        if (badge != null) Box(Modifier.align(Alignment.TopEnd).padding(10.dp)) { badge() }
    }
}

/** Thème affiche d'un niveau (leçons), à partir de la couleur du niveau. */
fun levelPoster(level: String): PosterTheme {
    val c = levelColor(level)
    return PosterTheme(start = c, end = lerpDark(c), accent = Gold)
}

private fun lerpDark(c: Color, k: Float = 0.45f) = Color(
    red = c.red * (1 - k) + Night.red * k,
    green = c.green * (1 - k) + Night.green * k,
    blue = c.blue * (1 - k) + Night.blue * k
)

/** Petite tuile d'action (icône lineart + libellé) en style affiche. */
@Composable
fun ActionTile(label: String, hint: String, drawing: LineDrawing, theme: PosterTheme, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Column(
        modifier
            .clip(shape)
            .background(Brush.linearGradient(listOf(theme.start, theme.end)))
            .waxPattern(alpha = 0.07f)
            .clickable(onClick = onClick)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        LineArt(drawing, Modifier.size(44.dp), color = Color.White, accent = theme.accent, strokeWidth = 2.dp, float = false)
        Text(label, style = PosterTitle, fontSize = 15.sp, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(hint, fontSize = 11.sp, color = Color.White.copy(alpha = 0.75f), maxLines = 2, lineHeight = 14.sp)
    }
}

/** Hauteur standard des espacements de grille. */
val GridGap: Dp = 12.dp
