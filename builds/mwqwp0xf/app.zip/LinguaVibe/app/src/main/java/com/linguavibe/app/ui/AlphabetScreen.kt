package com.linguavibe.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linguavibe.app.data.LanguageInfo

private data class LetterCard(val symbol: String, val sound: String, val example: String, val meaning: String, val emoji: String)

private val alphabetData = mapOf(
    "en" to listOf(
        "A|éi|Apple|pomme|🍎","B|biː|Ball|ballon|⚽","C|siː|Cat|chat|🐱","D|diː|Dog|chien|🐶",
        "E|iː|Elephant|éléphant|🐘","F|ef|Fish|poisson|🐟","G|djiː|Giraffe|girafe|🦒","H|eitch|House|maison|🏠",
        "I|aï|Ice|glace|🍦","J|djeï|Juice|jus|🧃","K|kéï|Kite|cerf-volant|🪁","L|el|Lion|lion|🦁",
        "M|em|Moon|lune|🌙","N|en|Nose|nez|👃","O|ôu|Orange|orange|🍊","P|piː|Pizza|pizza|🍕",
        "Q|kiou|Queen|reine|👑","R|ar|Rainbow|arc-en-ciel|🌈","S|es|Sun|soleil|☀️","T|tiː|Tree|arbre|🌳",
        "U|you|Umbrella|parapluie|☂️","V|viː|Violin|violon|🎻","W|dabeul-you|Whale|baleine|🐳",
        "X|eks|Xylophone|xylophone|🎼","Y|waï|Yo-yo|yo-yo|🪀","Z|zed|Zebra|zèbre|🦓"
    ),
    "es" to listOf(
        "A|a|Árbol|arbre|🌳","B|bé|Barco|bateau|⛵","C|sé|Casa|maison|🏠","D|dé|Dado|dé|🎲",
        "E|é|Elefante|éléphant|🐘","F|éfé|Flor|fleur|🌸","G|khé|Gato|chat|🐱","H|atché|Helado|glace|🍦",
        "I|i|Isla|île|🏝️","J|khota|Jirafa|girafe|🦒","K|ka|Koala|koala|🐨","L|élé|Luna|lune|🌙",
        "M|émé|Manzana|pomme|🍎","N|éné|Nube|nuage|☁️","Ñ|égné|Ñandú|nandou|🦤","O|o|Oso|ours|🐻",
        "P|pé|Perro|chien|🐶","Q|kou|Queso|fromage|🧀","R|éré|Rana|grenouille|🐸","S|ésé|Sol|soleil|☀️",
        "T|té|Tigre|tigre|🐯","U|ou|Uva|raisin|🍇","V|ouvé|Vaca|vache|🐮","W|doblé ouvé|Wafle|gaufre|🧇",
        "X|ékis|Xilófono|xylophone|🎼","Y|i griéga|Yoyó|yo-yo|🪀","Z|séta|Zorro|renard|🦊"
    ),
    "pt" to listOf(
        "A|a|Abelha|abeille|🐝","B|bé|Bola|ballon|⚽","C|cé|Casa|maison|🏠","D|dé|Dado|dé|🎲",
        "E|é|Elefante|éléphant|🐘","F|éfi|Flor|fleur|🌸","G|jé|Gato|chat|🐱","H|agá|Hotel|hôtel|🏨",
        "I|i|Igreja|église|⛪","J|jota|Janela|fenêtre|🪟","K|ká|Kiwi|kiwi|🥝","L|éli|Lua|lune|🌙",
        "M|émi|Macaco|singe|🐒","N|éni|Navio|bateau|🚢","O|ó|Ovo|œuf|🥚","P|pé|Pato|canard|🦆",
        "Q|ké|Queijo|fromage|🧀","R|érri|Rato|souris|🐭","S|éssi|Sol|soleil|☀️","T|té|Tartaruga|tortue|🐢",
        "U|ou|Uva|raisin|🍇","V|vé|Vaca|vache|🐮","W|dáblio|Web|web|🌐","X|chis|Xícara|tasse|☕",
        "Y|ípsilon|Yoga|yoga|🧘","Z|zé|Zebra|zèbre|🦓"
    ),
    "ru" to listOf(
        "А|a|Аист|cigogne|🕊️","Б|bé|Банан|banane|🍌","В|vé|Волк|loup|🐺","Г|gué|Гриб|champignon|🍄",
        "Д|dé|Дом|maison|🏠","Е|ié|Ель|sapin|🌲","Ё|io|Ёж|hérisson|🦔","Ж|jé|Жук|scarabée|🪲",
        "З|zé|Заяц|lièvre|🐇","И|i|Игра|jeu|🎮","Й|i kratkoïé|Йогурт|yaourt|🥣","К|ka|Кот|chat|🐱",
        "Л|él|Лиса|renard|🦊","М|èm|Мяч|ballon|⚽","Н|èn|Нос|nez|👃","О|o|Облако|nuage|☁️",
        "П|pé|Панда|panda|🐼","Р|èr|Рыба|poisson|🐟","С|ès|Солнце|soleil|☀️","Т|té|Торт|gâteau|🎂",
        "У|ou|Утка|canard|🦆","Ф|èf|Флаг|drapeau|🚩","Х|kha|Хлеб|pain|🍞","Ц|tsé|Цирк|cirque|🎪",
        "Ч|tché|Чай|thé|🍵","Ш|cha|Шар|ballon|🎈","Щ|chtcha|Щука|brochet|🐟","Ъ|signe dur|Объект|objet|📦",
        "Ы|y|Сыр|fromage|🧀","Ь|signe mou|День|jour|🌞","Э|è|Эхо|écho|📣","Ю|you|Юла|toupie|🌀","Я|ya|Яблоко|pomme|🍎"
    ),
    "ar" to listOf(
        "ا|ā / a|أَسَد (asad)|lion|🦁","ب|b|بَاب (bāb)|porte|🚪","ت|t|تُفَّاح (tuffāḥ)|pomme|🍎",
        "ث|th|ثَعْلَب (thaʿlab)|renard|🦊","ج|j|جَمَل (jamal)|chameau|🐪","ح|ḥ|حِصَان (ḥiṣān)|cheval|🐎",
        "خ|kh|خُبْز (khubz)|pain|🍞","د|d|دُبّ (dubb)|ours|🐻","ذ|dh|ذَهَب (dhahab)|or|✨",
        "ر|r|رُمَّان (rummān)|grenade|🍎","ز|z|زَهْرَة (zahra)|fleur|🌸","س|s|سَمَك (samak)|poisson|🐟",
        "ش|sh|شَمْس (shams)|soleil|☀️","ص|ṣ|صَقْر (ṣaqr)|faucon|🦅","ض|ḍ|ضِفْدَع (ḍifdaʿ)|grenouille|🐸",
        "ط|ṭ|طَائِر (ṭāʾir)|oiseau|🐦","ظ|ẓ|ظَرْف (ẓarf)|enveloppe|✉️","ع|ʿ|عَيْن (ʿayn)|œil|👁️",
        "غ|gh|غَيْم (ghaym)|nuage|☁️","ف|f|فِيل (fīl)|éléphant|🐘","ق|q|قَمَر (qamar)|lune|🌙",
        "ك|k|كِتَاب (kitāb)|livre|📚","ل|l|لَيْمُون (laymūn)|citron|🍋","م|m|مَوْز (mawz)|banane|🍌",
        "ن|n|نَجْم (najm)|étoile|⭐","ه|h|هِلال (hilāl)|croissant|🌙","و|w / ū|وَرْدَة (warda)|rose|🌹","ي|y / ī|يَد (yad)|main|✋"
    ),
    "zh" to listOf(
        "b|b|八 bā|huit|8️⃣","p|p|朋 péng|ami|🤝","m|m|猫 māo|chat|🐱","f|f|风 fēng|vent|🌬️",
        "d|d|大 dà|grand|🏔️","t|t|天 tiān|ciel|🌤️","n|n|你 nǐ|tu / vous|👋","l|l|六 liù|six|6️⃣",
        "g|g|狗 gǒu|chien|🐶","k|k|看 kàn|regarder|👀","h|h|好 hǎo|bien|👍","j|dj|家 jiā|maison|🏠",
        "q|tch soufflé|七 qī|sept|7️⃣","x|ch doux|星 xīng|étoile|⭐","zh|dj|中 zhōng|milieu|🎯",
        "ch|tch|吃 chī|manger|🥢","sh|ch|书 shū|livre|📚","r|j|人 rén|personne|🧑",
        "z|dz|字 zì|caractère|🔤","c|ts soufflé|草 cǎo|herbe|🌱","s|s|三 sān|trois|3️⃣",
        "y|y|月 yuè|lune|🌙","w|w|我 wǒ|moi|🙋",
        "a|a|妈 mā|maman|👩","o|o|我 wǒ|moi|🙋","e|e|饿 è|avoir faim|🍜",
        "i|i|米 mǐ|riz|🍚","u|ou|书 shū|livre|📚","ü|u français|鱼 yú|poisson|🐟",
        "ai|aï|爱 ài|amour|❤️","ei|éi|杯 bēi|tasse|☕","ao|aou|猫 māo|chat|🐱",
        "ou|oou|狗 gǒu|chien|🐶","an|ane|山 shān|montagne|⛰️","en|eune|门 mén|porte|🚪",
        "ang|ang|房 fáng|maison|🏠","eng|eung|风 fēng|vent|🌬️","ong|oung|中 zhōng|milieu|🎯"
    )
)

private fun entries(code: String): List<LetterCard> = (alphabetData[code] ?: emptyList()).map { raw ->
    val p = raw.split("|")
    LetterCard(p[0], p[1], p[2], p[3], p[4])
}

@Composable
fun AlphabetScreen(lang: LanguageInfo, onBack: () -> Unit) {
    val speaker = LocalSpeaker.current
    val cards = remember(lang.code) { entries(lang.code) }
    var quizIndex by remember(lang.code) { mutableIntStateOf(0) }
    var quizFeedback by remember { mutableStateOf<String?>(null) }
    val palette = listOf(Color(0xFF6657C8), Color(0xFFDF6685), Color(0xFF159D91), Color(0xFFE39B36))
    Column(Modifier.fillMaxSize().background(Color(0xFFFFF9F1))) {
        TopBar("L'alphabet", "${lang.flag} ${lang.name} · ${cards.size} cartes", Color(0xFF5145A8), onBack)
        Column(Modifier.weight(1f).padding(horizontal = 16.dp)) {
            Spacer(Modifier.height(14.dp))
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF5145A8), Color(0xFFDB6D91))))
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Les lettres deviennent tes amies !", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 19.sp)
                    Text("Écoute, observe et répète à ton rythme.", color = Color.White.copy(alpha = .9f), fontSize = 13.sp)
                }
                Text("🦊", fontSize = 48.sp)
            }
            Spacer(Modifier.height(12.dp))
            if (lang.code == "zh") {
                Text("Le chinois ne possède pas d'alphabet : découvre ici les initiales du pinyin, avec des caractères et leurs tons.", color = Color(0xFF625B6B), fontSize = 12.sp)
            } else if (lang.code == "ar") {
                Text("L'arabe s'écrit de droite à gauche. Les lettres changent parfois de forme selon leur position dans le mot.", color = Color(0xFF625B6B), fontSize = 12.sp)
            } else {
                Text("Touchez une carte pour découvrir la lettre, son son et un mot illustré.", color = Color(0xFF625B6B), fontSize = 12.sp)
            }
            Spacer(Modifier.height(10.dp))
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(bottom = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(cards) { card ->
                    val index = cards.indexOf(card)
                    val color = palette[index % palette.size]
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                            .background(Color.White).clickable {
                                speaker.speak(card.symbol, lang.locale)
                            }.padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(card.symbol, fontSize = if (lang.code == "ar" || lang.code == "zh" || lang.code == "ru") 34.sp else 38.sp,
                            fontWeight = FontWeight.Black, color = color)
                        Text(card.sound, color = Color(0xFF625B6B), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Text(card.emoji, fontSize = 27.sp)
                        Text(card.example, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF302B3A), textAlign = TextAlign.Center)
                        Text(card.meaning, fontSize = 11.sp, color = Color(0xFF817989))
                        Text("▶ Écouter", color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        if (cards.isNotEmpty()) {
            val current = cards[quizIndex % cards.size]
            Column(Modifier.fillMaxWidth().background(Color.White).padding(14.dp)) {
                Text("🎯 Mini-défi", fontWeight = FontWeight.ExtraBold, color = Color(0xFF302B3A), fontSize = 16.sp)
                Text("Écoute le mot, puis choisis sa première lettre.", fontSize = 13.sp, color = Color(0xFF625B6B))
                Text("🔊 Écouter : ${current.example}", color = Color(0xFF5145A8), fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { speaker.speak(current.example, lang.locale) }.padding(top = 5.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                    listOf(current, cards[(quizIndex + 3) % cards.size], cards[(quizIndex + 7) % cards.size]).distinctBy { it.symbol }.forEach { option ->
                        Button(
                            onClick = {
                                quizFeedback = if (option.symbol == current.symbol) "Bravo ! ⭐" else "Essaie encore 😊"
                                if (option.symbol == current.symbol) quizIndex = (quizIndex + 1) % cards.size
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF5145A8)),
                            contentPadding = PaddingValues(6.dp)
                        ) { Text(option.symbol, fontSize = 20.sp) }
                    }
                }
                quizFeedback?.let { Text(it, color = Color(0xFF5145A8), fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp)) }
            }
        }
    }
}
