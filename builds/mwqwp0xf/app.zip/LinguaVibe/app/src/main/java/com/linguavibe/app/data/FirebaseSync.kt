package com.linguavibe.app.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.text.DateFormat
import java.util.Date

/**
 * Cours téléchargés depuis Firebase et conservés sur le téléphone (utilisables hors ligne).
 *
 * Organisation attendue dans la base (Realtime Database) :
 *   <rootPath>/meta     { version, updatedAt }
 *   <rootPath>/courses  { es: { lang, lessons: [...] }, en: {...}, ... }
 */
object FirebaseSync {
    private const val PREFS = "firebase"

    /** Dernier état affiché à l'apprenant. */
    var status by mutableStateOf("")
        private set
    var busy by mutableStateOf(false)
        private set

    fun loadConfig(context: Context): FirebaseConfig {
        val text = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("config", null)
            ?: return FirebaseConfig()
        return try {
            FirebaseConfig.fromJson(JSONObject(text))
        } catch (_: Exception) {
            FirebaseConfig()
        }
    }

    fun saveConfig(context: Context, config: FirebaseConfig) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("config", config.toJson().toString()).apply()
    }

    fun autoSync(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("autoSync", true)

    fun setAutoSync(context: Context, value: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("autoSync", value).apply()
    }

    fun lastSync(context: Context): String {
        val t = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong("lastSync", 0)
        return if (t == 0L) "jamais" else DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(t))
    }

    fun dir(context: Context) = File(context.filesDir, "courses")

    fun hasDownloaded(context: Context): Boolean = dir(context).listFiles()?.any { it.name.endsWith(".json") } == true

    /** Supprime les cours téléchargés : l'application revient aux cours intégrés. */
    fun clear(context: Context) {
        dir(context).deleteRecursively()
        CourseRepository.reload()
        status = "Cours intégrés rétablis."
    }

    /**
     * Télécharge tous les cours depuis Firebase et les enregistre sur le téléphone.
     * Renvoie le nombre de leçons reçues.
     */
    suspend fun sync(context: Context, config: FirebaseConfig = loadConfig(context)): Int {
        if (!config.isComplete) throw IllegalStateException("Configuration Firebase incomplète.")
        busy = true
        status = "Téléchargement des cours…"
        try {
            val client = FirebaseRest(context, config)
            val text = client.get("courses")
            val count = withContext(Dispatchers.IO) {
                if (text.trim() == "null") {
                    throw IllegalStateException(
                        "Aucun cours dans la base (« ${config.rootPath}/courses » est vide). " +
                            "Envoyez d'abord les données avec l'appli d'administration."
                    )
                }
                val courses = JSONObject(text)
                val folder = dir(context)
                val tmp = File(context.filesDir, "courses.tmp")
                tmp.deleteRecursively()
                tmp.mkdirs()
                var lessons = 0
                for (lang in courses.keys()) {
                    val course = courses.optJSONObject(lang) ?: continue
                    course.put("lang", lang)
                    // Vérifie que le cours se lit correctement avant de l'enregistrer.
                    lessons += CourseRepository.parse(lang, course).lessons.size
                    File(tmp, "$lang.json").writeText(course.toString(), Charsets.UTF_8)
                }
                if (lessons == 0) throw IllegalStateException("Les cours reçus ne contiennent aucune leçon.")
                folder.deleteRecursively()
                if (!tmp.renameTo(folder)) {
                    tmp.copyRecursively(folder, overwrite = true)
                    tmp.deleteRecursively()
                }
                lessons
            }
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putLong("lastSync", System.currentTimeMillis()).apply()
            CourseRepository.reload()
            status = "✅ $count leçons téléchargées. Elles restent disponibles hors ligne."
            return count
        } catch (e: Exception) {
            status = "❌ ${e.message ?: "Téléchargement impossible"}"
            throw e
        } finally {
            busy = false
        }
    }
}
