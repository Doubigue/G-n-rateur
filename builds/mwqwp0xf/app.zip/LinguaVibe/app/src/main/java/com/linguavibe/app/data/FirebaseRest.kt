package com.linguavibe.app.data

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest

/**
 * Paramètres de connexion à une base Firebase (Realtime Database).
 * Ils viennent du fichier de configuration de l'app (google-services.json) ou sont saisis à la main.
 */
data class FirebaseConfig(
    val projectId: String = "",
    val apiKey: String = "",
    val appId: String = "",
    val databaseUrl: String = "",
    val storageBucket: String = "",
    /** Dossier racine des données dans la base. */
    val rootPath: String = "linguavibe",
    /** Connexion anonyme (règles « auth != null »). Décoché : lecture publique, sans connexion. */
    val anonymousAuth: Boolean = true
) {
    val isComplete: Boolean get() = databaseUrl.isNotBlank() && (!anonymousAuth || apiKey.isNotBlank())

    fun toJson(): JSONObject = JSONObject()
        .put("projectId", projectId).put("apiKey", apiKey).put("appId", appId)
        .put("databaseUrl", databaseUrl).put("storageBucket", storageBucket)
        .put("rootPath", rootPath).put("anonymousAuth", anonymousAuth)

    companion object {
        fun fromJson(o: JSONObject) = FirebaseConfig(
            o.optString("projectId"), o.optString("apiKey"), o.optString("appId"),
            o.optString("databaseUrl"), o.optString("storageBucket"),
            o.optString("rootPath", "linguavibe").ifBlank { "linguavibe" }, o.optBoolean("anonymousAuth", true)
        )

        /**
         * Lit un fichier de configuration Firebase :
         * - google-services.json (application Android) ;
         * - ou la configuration « Web » ({ apiKey, projectId, databaseURL, appId, ... }), en JSON
         *   ou copiée telle quelle depuis la console (const firebaseConfig = { ... }).
         * [packageName] choisit le bon client quand le fichier contient plusieurs applications.
         */
        fun parse(text: String, packageName: String): FirebaseConfig {
            val start = text.indexOf('{')
            val end = text.lastIndexOf('}')
            require(start >= 0 && end > start) { "Ce fichier ne contient pas de configuration Firebase." }
            var body = text.substring(start, end + 1)
            val root = try {
                JSONObject(body)
            } catch (e: Exception) {
                // Configuration Web copiée depuis la console : clés sans guillemets.
                body = body.replace(Regex("""([{,]\s*)([A-Za-z_][A-Za-z0-9_]*)\s*:"""), "$1\"$2\":")
                JSONObject(body)
            }
            if (root.has("project_info")) {
                val info = root.getJSONObject("project_info")
                val projectId = info.optString("project_id")
                val clients = root.optJSONArray("client")
                var client: JSONObject? = null
                if (clients != null) {
                    for (i in 0 until clients.length()) {
                        val c = clients.getJSONObject(i)
                        val pkg = c.optJSONObject("client_info")?.optJSONObject("android_client_info")
                            ?.optString("package_name")
                        if (pkg == packageName) client = c
                    }
                    if (client == null && clients.length() > 0) client = clients.getJSONObject(0)
                }
                val apiKey = client?.optJSONArray("api_key")?.optJSONObject(0)?.optString("current_key") ?: ""
                val appId = client?.optJSONObject("client_info")?.optString("mobilesdk_app_id") ?: ""
                val url = info.optString("firebase_url").ifBlank {
                    if (projectId.isNotBlank()) "https://$projectId-default-rtdb.firebaseio.com" else ""
                }
                return FirebaseConfig(projectId, apiKey, appId, url, info.optString("storage_bucket"))
            }
            val projectId = root.optString("projectId")
            val url = root.optString("databaseURL").ifBlank {
                if (projectId.isNotBlank()) "https://$projectId-default-rtdb.firebaseio.com" else ""
            }
            require(root.has("apiKey") || url.isNotBlank()) { "Configuration Firebase non reconnue." }
            return FirebaseConfig(projectId, root.optString("apiKey"), root.optString("appId"), url, root.optString("storageBucket"))
        }
    }
}

/** Client minimal de Firebase par l'API REST : connexion (anonyme ou e-mail) et lecture / écriture JSON. */
class FirebaseRest(private val context: Context, private val config: FirebaseConfig) {
    private val sp = context.applicationContext.getSharedPreferences("firebase_auth", Context.MODE_PRIVATE)

    private val base: String get() = config.databaseUrl.trim().trimEnd('/')

    /** En-têtes exigés quand la clé API est restreinte aux applications Android. */
    private fun HttpURLConnection.androidHeaders() {
        setRequestProperty("X-Android-Package", context.packageName)
        signingSha1()?.let { setRequestProperty("X-Android-Cert", it) }
    }

    @Suppress("DEPRECATION")
    private fun signingSha1(): String? = try {
        val pm = context.packageManager
        val sig = if (Build.VERSION.SDK_INT >= 28) {
            pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
                .signingInfo?.apkContentsSigners?.firstOrNull()
        } else {
            pm.getPackageInfo(context.packageName, PackageManager.GET_SIGNATURES).signatures?.firstOrNull()
        }
        sig?.let { s ->
            MessageDigest.getInstance("SHA-1").digest(s.toByteArray()).joinToString("") { "%02X".format(it) }
        }
    } catch (_: Exception) {
        null
    }

    private fun request(method: String, url: String, body: String? = null, form: Boolean = false): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 20_000
        c.readTimeout = 60_000
        c.androidHeaders()
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty(
                "Content-Type",
                if (form) "application/x-www-form-urlencoded" else "application/json; charset=utf-8"
            )
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }
        try {
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) throw IllegalStateException(explain(code, text))
            return text
        } finally {
            c.disconnect()
        }
    }

    private fun explain(code: Int, text: String): String {
        val message = try {
            val o = JSONObject(text)
            o.optJSONObject("error")?.optString("message") ?: o.optString("error", text)
        } catch (_: Exception) {
            text.take(200)
        }
        return when {
            message.contains("ADMIN_ONLY_OPERATION") || message.contains("OPERATION_NOT_ALLOWED") ->
                "La connexion anonyme n'est pas activée (console Firebase › Authentication › Méthodes de connexion)."
            message.contains("INVALID_LOGIN_CREDENTIALS") || message.contains("INVALID_PASSWORD") ||
                message.contains("EMAIL_NOT_FOUND") -> "E-mail ou mot de passe incorrect."
            message.contains("API key not valid") || message.contains("API_KEY_INVALID") -> "Clé API invalide."
            code == 401 || message.contains("Permission denied") ->
                "Accès refusé par les règles de la base (code $code). Vérifiez les règles et la connexion."
            code == 404 -> "Base introuvable (code 404) : vérifiez l'URL de la base de données."
            else -> "Erreur Firebase $code : $message"
        }
    }

    // ------------------------------------------------------------- Connexion

    private val tokenKey get() = "token_${config.projectId}"
    private val refreshKey get() = "refresh_${config.projectId}"
    private val expiryKey get() = "expiry_${config.projectId}"
    private val emailKey get() = "email_${config.projectId}"

    /** Adresse du compte connecté par e-mail (appli d'administration), ou null. */
    val signedInEmail: String? get() = sp.getString(emailKey, null)

    private fun saveTokens(idToken: String, refresh: String, expiresIn: Long, email: String?) {
        val editor = sp.edit()
            .putString(tokenKey, idToken)
            .putString(refreshKey, refresh)
            .putLong(expiryKey, System.currentTimeMillis() + (expiresIn - 60) * 1000)
        if (email != null) editor.putString(emailKey, email)
        editor.apply()
    }

    fun signOut() {
        sp.edit().remove(tokenKey).remove(refreshKey).remove(expiryKey).remove(emailKey).apply()
    }

    suspend fun signInWithEmail(email: String, password: String) = withContext(Dispatchers.IO) {
        val body = JSONObject().put("email", email).put("password", password).put("returnSecureToken", true)
        val res = JSONObject(
            request("POST", "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${config.apiKey}", body.toString())
        )
        saveTokens(res.getString("idToken"), res.getString("refreshToken"), res.optString("expiresIn", "3600").toLong(), email)
    }

    private fun signInAnonymously() {
        val res = JSONObject(
            request(
                "POST", "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=${config.apiKey}",
                JSONObject().put("returnSecureToken", true).toString()
            )
        )
        saveTokens(res.getString("idToken"), res.getString("refreshToken"), res.optString("expiresIn", "3600").toLong(), null)
    }

    /** Jeton valide (renouvelé si besoin), ou null quand la base est lue sans connexion. */
    private fun token(requireAccount: Boolean): String? {
        val current = sp.getString(tokenKey, null)
        if (current != null && System.currentTimeMillis() < sp.getLong(expiryKey, 0)) return current
        val refresh = sp.getString(refreshKey, null)
        if (refresh != null) {
            try {
                val res = JSONObject(
                    request(
                        "POST", "https://securetoken.googleapis.com/v1/token?key=${config.apiKey}",
                        "grant_type=refresh_token&refresh_token=" + URLEncoder.encode(refresh, "UTF-8"), form = true
                    )
                )
                saveTokens(
                    res.getString("id_token"), res.getString("refresh_token"),
                    res.optString("expires_in", "3600").toLong(), signedInEmail
                )
                return res.getString("id_token")
            } catch (_: Exception) {
                // jeton expiré ou révoqué : on se reconnecte
            }
        }
        if (requireAccount) throw IllegalStateException("Connectez-vous d'abord avec le compte administrateur.")
        if (!config.anonymousAuth) return null
        signInAnonymously()
        return sp.getString(tokenKey, null)
    }

    private fun url(path: String, requireAccount: Boolean): String {
        val clean = (config.rootPath.trim('/') + "/" + path.trim('/')).trim('/')
        val auth = token(requireAccount)?.let { "?auth=$it" } ?: ""
        return "$base/$clean.json$auth"
    }

    // ------------------------------------------------------------- Données

    /** Lit le JSON stocké sous rootPath/path ("null" si rien). */
    suspend fun get(path: String, requireAccount: Boolean = false): String = withContext(Dispatchers.IO) {
        request("GET", url(path, requireAccount))
    }

    /** Remplace le contenu de rootPath/path. */
    suspend fun put(path: String, json: String, requireAccount: Boolean = false): String = withContext(Dispatchers.IO) {
        request("PUT", url(path, requireAccount), json)
    }

    /** Vérifie que la base répond (lecture de quelques clés seulement). */
    suspend fun test(requireAccount: Boolean = false): String = withContext(Dispatchers.IO) {
        val shallow = url("meta", requireAccount)
        request("GET", shallow)
    }
}
