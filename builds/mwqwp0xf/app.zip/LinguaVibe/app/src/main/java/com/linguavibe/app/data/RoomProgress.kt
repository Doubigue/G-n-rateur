package com.linguavibe.app.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "lesson_progress", primaryKeys = ["modelId", "recordId"])
data class LessonProgressRecord(
    val modelId: String,
    val recordId: String,
    val score: Int = 0,
    val homework: String = "",
    val completed: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)

@Dao
interface RoomProgressDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun save(record: LessonProgressRecord)

    @Query("SELECT * FROM lesson_progress WHERE modelId = :modelId ORDER BY updatedAt DESC")
    fun observeModel(modelId: String): Flow<List<LessonProgressRecord>>

    @Query("SELECT * FROM lesson_progress ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<LessonProgressRecord>>
}

@Database(entities = [LessonProgressRecord::class], version = 1, exportSchema = false)
abstract class RoomProgressDatabase : RoomDatabase() {
    abstract fun progressDao(): RoomProgressDao

    companion object {
        @Volatile private var instance: RoomProgressDatabase? = null
        fun get(context: Context): RoomProgressDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext, RoomProgressDatabase::class.java, "linguavibe_progress.db"
            ).build().also { instance = it }
        }
    }
}
