package com.linguavibe.app.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/** Progression de l'apprenant, enregistrée localement (SharedPreferences). */
class ProgressStore(context: Context) {
    private val appContext = context.applicationContext
    private val sp = appContext.getSharedPreferences("progress", Context.MODE_PRIVATE)
    private val roomDao = RoomProgressDatabase.get(appContext).progressDao()
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    var xp by mutableIntStateOf(sp.getInt("xp", 0))
        private set
    var streak by mutableIntStateOf(sp.getInt("streak", 0))
        private set

    /** identifiant de leçon -> meilleur score au quiz (0..100) */
    val scores = mutableStateMapOf<String, Int>()

    init {
        sp.all.forEach { (key, value) ->
            if (key.startsWith("score_") && value is Int) scores[key.removePrefix("score_")] = value
        }
        // La série est perdue si plus d'un jour s'est écoulé.
        val last = sp.getLong("lastDay", -1L)
        if (last >= 0 && today() - last > 1) {
            streak = 0
            sp.edit().putInt("streak", 0).apply()
        }
    }

    private fun today(): Long = System.currentTimeMillis() / 86_400_000L

    private fun scopedKey(lessonId: String, scope: String): String =
        if (scope == "default" || scope == "es_model1") lessonId else "$scope:$lessonId"

    fun isCompleted(lessonId: String, scope: String = "default"): Boolean =
        (scores[scopedKey(lessonId, scope)] ?: scores[lessonId] ?: -1) >= PASS_SCORE

    fun bestScore(lessonId: String, scope: String = "default"): Int? =
        scores[scopedKey(lessonId, scope)] ?: scores[lessonId]

    /** Enregistre le résultat d'un quiz et renvoie les XP gagnés. */
    fun recordQuiz(lessonId: String, score: Int, scope: String = "default"): Int {
        val key = scopedKey(lessonId, scope)
        val previous = scores[key] ?: scores[lessonId]
        val gained = when {
            score < PASS_SCORE -> 5
            previous == null || previous < PASS_SCORE -> 50 + score / 2
            else -> 10
        }
        if (previous == null || score > previous) scores[key] = score
        xp += gained
        touchStreak()
        val best = scores[key] ?: score
        sp.edit()
            .putInt("score_$key", best)
            .putInt("xp", xp)
            .apply()
        ioScope.launch {
            roomDao.save(LessonProgressRecord(
                modelId = scope, recordId = "quiz:$lessonId", score = best,
                completed = best >= PASS_SCORE
            ))
        }
        return gained
    }

    fun addXp(amount: Int) {
        xp += amount
        touchStreak()
        sp.edit().putInt("xp", xp).apply()
    }

    private fun touchStreak() {
        val day = today()
        val last = sp.getLong("lastDay", -1L)
        if (last == day) return
        streak = if (last == day - 1) streak + 1 else 1
        sp.edit().putLong("lastDay", day).putInt("streak", streak).apply()
    }

    fun homeworkAnswer(key: String, scope: String = "default"): String {
        val storedKey = if (scope == "default" || scope == "es_model1") key else "$scope:$key"
        return sp.getString("hw_$storedKey", "") ?: ""
    }

    fun saveHomework(key: String, text: String, scope: String = "default") {
        val storedKey = if (scope == "default" || scope == "es_model1") key else "$scope:$key"
        sp.edit().putString("hw_$storedKey", text).apply()
        ioScope.launch {
            roomDao.save(LessonProgressRecord(
                modelId = scope, recordId = "homework:$key", homework = text
            ))
        }
    }

    companion object {
        const val PASS_SCORE = 70
    }
}
