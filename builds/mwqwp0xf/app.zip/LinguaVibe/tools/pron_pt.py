#!/usr/bin/env python3
"""Prononciation figurée du portugais du Brésil pour un lecteur francophone.

Usage : python3 tools/pron_pt.py          (complète content/pt/prononciation.txt)
        python3 tools/pron_pt.py --force  (régénère tout le fichier)

Conventions : syllabe accentuée en MAJUSCULES ; voyelle avec tilde (ã, ẽ, ĩ, õ, ũ) = voyelle nasale ;
« rr » = r du fond de la gorge, soufflé ; « r » = r battu ; « tch », « dj » = t et d devant le son i ;
« è » = e ouvert ; « ô » = o fermé ; « ou » = u.
"""
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from pron_common import collect_texts, write_table  # noqa: E402

VOW = set("aeiouáéíóúâêôãõàü")
ACCENTED = set("áéíóúâêô")
CLUSTERS = {"pr", "br", "tr", "dr", "cr", "gr", "fr", "vr", "pl", "bl", "cl", "gl", "fl", "tl"}
DIGRAPHS = ("ch", "lh", "nh", "rr", "ss")
UNSTRESSED = set("""o a os as um uma uns umas de do da dos das em no na nos nas num numa por pelo pela pelos pelas
para pra com sem e ou que se me te lhe lhes nos vos mas como quando onde porque meu minha teu tua seu sua""".split())
X_KS = {"táxi", "fixo", "fixa", "sexo", "tóxico", "tóxica", "anexo", "reflexo", "complexo", "complexa", "látex", "xerox", "boxe"}
X_SS = {"próximo", "próxima", "próximos", "próximas", "máximo", "máxima", "auxílio", "trouxe", "sintaxe", "aproximar"}


def units(w):
    out, i = [], 0
    while i < len(w):
        two = w[i:i + 2]
        if two in DIGRAPHS:
            out.append(two)
            i += 2
        elif two in ("qu", "gu") and i + 2 < len(w) and w[i + 2] in "eéêií":
            out.append(two)
            i += 2
        else:
            out.append(w[i])
            i += 1
    return out


def nuclei(us):
    """Groupes vocaliques : diphtongues descendantes (ai, ei, oi, ui, au, eu, ou, iu, ão, ãe, õe)."""
    groups, k = [], 0
    while k < len(us):
        if us[k] in VOW:
            start = k
            while k + 1 < len(us) and us[k + 1] in VOW:
                a, b = us[k], us[k + 1]
                prev = us[k - 1] if k > 0 else ""
                falling = b in "iu" and a not in "iu" or (a in "iu" and b in "iu" and a != b) \
                    or (a in "ãõ" and b in "eo")
                glide_after_qg = a in "uü" and prev in ("q", "g")
                if not (falling or glide_after_qg):
                    break
                k += 1
            groups.append((start, k))
        k += 1
    return groups


def split(us, groups):
    bounds = []
    for (_s1, e1), (s2, _e2) in zip(groups, groups[1:]):
        cons = us[e1 + 1:s2]
        n = len(cons)
        if n == 0:
            cut = s2
        elif n == 1:
            cut = s2 - 1
        elif n == 2:
            cut = s2 - 2 if cons[0] + cons[1] in CLUSTERS else s2 - 1
        else:
            cut = s2 - 2 if cons[-2] + cons[-1] in CLUSTERS else s2 - 1
        bounds.append(cut)
    out, prev = [], 0
    for b in bounds:
        out.append(list(range(prev, b)))
        prev = b
    out.append(list(range(prev, len(us))))
    return out


def stress_of(word, us, sylls):
    for idx, syl in enumerate(sylls):
        if any(us[k] in ACCENTED for k in syl):
            return idx
    for idx, syl in enumerate(sylls):
        if any(us[k] in "ãõ" for k in syl):
            return idx
    if len(sylls) == 1:
        return 0
    for end in ("a", "e", "o", "as", "es", "os", "em", "ens", "am"):
        if word.endswith(end):
            return len(sylls) - 2
    return len(sylls) - 1


def render_word(word):
    low = word.lower()
    us = units(low)
    groups = nuclei(us)
    if not groups:
        return word
    sylls = split(us, groups)
    stress = stress_of(low, us, sylls)
    # Glissement : syllabe atone « i / u » + voyelle après l'accent → une seule syllabe (his-TÓ-rya).
    merged = []
    for idx, syl in enumerate(sylls):
        prev_v = [us[k] for k in merged[-1] if us[k] in VOW] if merged else []
        if idx - 1 > stress and prev_v in (["i"], ["u"]) and us[syl[0]] in VOW:
            merged[-1] = merged[-1] + syl
            continue
        merged.append(syl)
    sylls = merged
    is_last_syl = {k: (i == len(sylls) - 1) for i, syl in enumerate(sylls) for k in syl}
    stressed = set(sylls[stress]) if stress < len(sylls) else set()
    n = len(us)

    def nxt(k):
        return us[k + 1] if k + 1 < n else ""

    def prv(k):
        return us[k - 1] if k > 0 else ""

    def i_sound(k):
        """Vrai si l'unité k se prononce « i » (i, í, e final atone, es final atone)."""
        if k >= n:
            return False
        u = us[k]
        if u in "ií":
            return True
        if u == "e" and k not in stressed and is_last_syl.get(k) and (k == n - 1 or us[k + 1:] == ["s"]):
            return True
        return False

    def nasal_follow(k):
        """Voyelle suivie de m/n en fin de syllabe (devant consonne ou en fin de mot)."""
        if k + 1 < n and us[k + 1] in ("m", "n"):
            after = us[k + 2] if k + 2 < n else ""
            return after == "" or (after not in VOW and after != "h")
        return False

    pieces = []
    for si, syl in enumerate(sylls):
        out = ""
        for k in syl:
            u, a, b = us[k], prv(k), nxt(k)
            final_word = k == n - 1 or (k == n - 2 and us[-1] == "s")
            atone = k not in stressed
            if u in VOW:
                if u in "iu" and a in VOW and a not in "iu" and not (a in "uü" and prv(k - 1) in ("q", "g")):
                    if u == "u" and a == "o" and out.endswith("o"):
                        out = out[:-1] + "ô"
                    else:
                        out += "ï" if u == "i" else "ou"
                    continue
                if u in "iu" and b in VOW and k + 1 in syl and not nasal_follow(k):
                    out += "y" if u == "i" else "ou"
                    continue
                if u in ("e", "o") and a and a in "ãõ":
                    out += "ou" if u == "o" else "ï"
                    continue
                if u in ("u", "ü") and a in ("q", "g") and b in VOW:
                    out += "ou"
                    continue
                if nasal_follow(k):
                    base = {"a": "ã", "â": "ã", "á": "ã", "e": "ẽ", "ê": "ẽ", "é": "ẽ", "i": "ĩ", "í": "ĩ",
                            "o": "õ", "ô": "õ", "ó": "õ", "u": "ũ", "ú": "ũ"}.get(u, u)
                    tail = us[k + 1]
                    if k + 2 >= n or us[k + 2:] == ["s"]:
                        if u in "eéê":
                            base = "ẽï"
                        elif u == "a" and tail == "m":
                            base = "ãou"
                    out += base
                    continue
                if u == "e" and atone and final_word:
                    out += "i"
                elif u == "o" and atone and final_word:
                    out += "ou"
                elif u == "e":
                    out += "é"
                else:
                    out += {"a": "a", "á": "a", "â": "a", "à": "a", "ã": "ã", "é": "è", "ê": "é", "i": "i",
                            "í": "i", "o": "o", "ó": "o", "ô": "ô", "õ": "õ", "u": "ou", "ú": "ou", "ü": "ou"}[u]
                continue
            # consonnes
            if u in ("m", "n") and k > 0 and a in VOW and nasal_follow(k - 1):
                continue
            if u == "qu":
                out += "k"
            elif u == "gu":
                out += "gu"
            elif u == "q":
                out += "k"
            elif u == "ch":
                out += "ch"
            elif u == "lh":
                out += "ly"
            elif u == "nh":
                out += "gn"
            elif u == "rr":
                out += "rr"
            elif u == "ss":
                out += "ss"
            elif u == "r":
                out += "rr" if (k == 0 or a in ("n", "l", "s")) else "r"
            elif u == "c":
                out += ("ss" if a in VOW else "s") if b and b in "eéêií" else "k"
            elif u == "ç":
                out += "ss"
            elif u == "g":
                out += "j" if b and b in "eéêií" else "g"
            elif u == "h":
                continue
            elif u == "t":
                out += "tch" if i_sound(k + 1) else "t"
            elif u == "d":
                out += "dj" if i_sound(k + 1) else "d"
            elif u == "s":
                if k == 0:
                    out += "s"
                elif a in VOW and b in VOW:
                    out += "z"
                elif k == n - 1:
                    out += "ss"
                else:
                    out += "s"
            elif u == "z":
                out += "ss" if k == n - 1 else "z"
            elif u == "x":
                if low in X_KS:
                    out += "ks"
                elif low in X_SS:
                    out += "ss"
                elif low.startswith("ex") and k == 1 and b in VOW:
                    out += "z"
                else:
                    out += "ch"
            elif u == "l":
                if (k == n - 1 or (b and b not in VOW)) and a in VOW:
                    out += "" if a in ("u", "ú") else "ou"
                else:
                    out += "l"
            elif u == "w":
                out += "ou"
            elif u == "y":
                out += "i"
            else:
                out += u
        pieces.append(out)
    if len(pieces) > 1 and low not in UNSTRESSED:
        pieces[stress] = pieces[stress].upper()
    return "-".join(p for p in pieces if p)


SPECIAL = {"ao": "aou", "aos": "aouss", "à": "a", "às": "ass", "de": "dji", "que": "ki", "se": "si", "me": "mi", "te": "tchi", "e": "i", "o": "ou", "os": "ouss",
           "do": "dou", "dos": "douss", "no": "nou", "nos": "nouss", "lhe": "lyi", "pelo": "pé-lou",
           "como": "kô-mou", "muito": "MŨÏ-tou", "muita": "MŨÏ-ta", "muitos": "MŨÏ-touss", "muitas": "MŨÏ-tass", "porque": "pour-KÉ", "por que": "pour ké", "você": "vô-SSÉ", "vocês": "vô-SSÉSS"}
WORD = re.compile(r"[A-Za-zÀ-ÿ]+")


def pron(text):
    def one(m):
        w = m.group(0)
        if w.lower() in SPECIAL:
            return SPECIAL[w.lower()]
        return render_word(w)
    return WORD.sub(one, text).strip()


if __name__ == "__main__":
    write_table("pt", collect_texts("pt"), pron, force="--force" in sys.argv)
