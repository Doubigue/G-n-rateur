#!/usr/bin/env python3
"""Rassemble toutes les données de l'application dans un seul fichier JSON pour Firebase.

Usage : python3 tools/export_firebase_json.py
Produit firebase/linguavibe_data.json :
  { "meta": { version, updatedAt, languages }, "courses": { "es": { lang, lessons }, ... } }

Ce fichier s'importe tel quel dans Firebase (Realtime Database › ⋮ › Importer JSON, sous le nœud « linguavibe »)
ou s'envoie avec l'appli LinguaVibe Admin. Lancez d'abord tools/build_course.py pour chaque langue.
"""
import json
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
LANGS = ["es", "en", "pt", "ru", "zh", "ar"]


def main():
    courses = {}
    for lang in LANGS:
        path = ROOT / "app" / "src" / "main" / "assets" / "courses" / f"{lang}.json"
        data = json.loads(path.read_text(encoding="utf-8"))
        courses[lang] = {"lang": lang, "lessons": data["lessons"]}
    meta = {
        "version": int(time.time()),
        "updatedAt": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "languages": LANGS,
        "lessonCount": sum(len(c["lessons"]) for c in courses.values()),
    }
    out = ROOT / "firebase" / "linguavibe_data.json"
    out.parent.mkdir(exist_ok=True)
    out.write_text(json.dumps({"meta": meta, "courses": courses}, ensure_ascii=False, indent=1), encoding="utf-8")
    # Copie dans l'appli d'administration, qui l'utilise comme point de départ.
    admin = ROOT.parent / "LinguaVibeAdmin" / "app" / "src" / "main" / "assets"
    if admin.parent.exists():
        admin.mkdir(parents=True, exist_ok=True)
        (admin / "linguavibe_data.json").write_text(out.read_text(encoding="utf-8"), encoding="utf-8")
    print(f"{out.relative_to(ROOT)} : {meta['lessonCount']} leçons, {out.stat().st_size // 1024} Ko")


if __name__ == "__main__":
    main()
