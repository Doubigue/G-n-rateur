#!/usr/bin/env python3
"""Convertit content/<langue>/*.txt en app/src/main/assets/courses/<langue>.json.

Usage : python3 tools/build_course.py es

Format d'une leçon (un champ par « | ») :
  # NIVEAU|Titre|Titre traduit|emoji
  > Introduction
  V mot|traduction|emoji|exemple|traduction de l'exemple
  G titre|explication|exemple = traduction;;exemple = traduction
  D A|réplique|traduction          (A = application, B = apprenant)
  Q question|bonne réponse|mauvaise|mauvaise|mauvaise
  L phrase à écouter|bon sens|mauvais|mauvais
  T phrase à traduire|réponse|variante acceptée|...
  H consigne|réponse modèle|mot-clé,mot-clé   (variantes séparées par « / » : 我叫/wo jiao)
  P phrase à prononcer|traduction

Deux fichiers facultatifs complètent le cours d'une langue :

content/<langue>/prononciation.txt — prononciation figurée « à la française », une ligne par texte :
  texte exact = prononciation        (ex. : ¿Cómo te llamas? = KO-mo té YA-mass ?)
  La syllabe accentuée est en MAJUSCULES. Elle s'applique partout où ce texte apparaît
  (mots, exemples, grammaire, dialogues, phrases, textes de lecture).

content/<langue>/lecture.txt — un texte de lecture par leçon :
  @ numéro de la leçon|titre|titre traduit
  R phrase|prononciation (facultative si elle est dans prononciation.txt)|traduction
"""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def fail(path, n, msg):
    sys.exit(f"{path.name}:{n}: {msg}")


EXTRA_FILES = ("prononciation.txt", "lecture.txt")


def key(text):
    return " ".join(text.split())


def load_pron(lang):
    path = ROOT / "content" / lang / "prononciation.txt"
    table = {}
    if not path.exists():
        return table
    for n, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        line = raw.strip()
        if not line or line.startswith("//"):
            continue
        text, sep, pron = line.rpartition(" = ")
        if not sep or not text.strip() or not pron.strip():
            fail(path, n, "prononciation : « texte = prononciation » attendu")
        table[key(text)] = pron.strip()
    return table


def load_readings(lang):
    path = ROOT / "content" / lang / "lecture.txt"
    readings = {}
    if not path.exists():
        return readings
    cur = None
    for n, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        line = raw.strip()
        if not line:
            continue
        tag, _, rest = line.partition(" ")
        f = [x.strip() for x in rest.split("|")]
        if tag == "@":
            if len(f) != 3 or not f[0].isdigit():
                fail(path, n, "@ numéro|titre|titre traduit")
            if int(f[0]) in readings:
                fail(path, n, f"texte en double pour la leçon {f[0]}")
            cur = dict(title=f[1], titleTr=f[2], sentences=[])
            readings[int(f[0])] = cur
        elif tag == "R":
            if cur is None or len(f) != 3 or not f[0] or not f[2]:
                fail(path, n, "R phrase|prononciation|traduction")
            cur["sentences"].append(dict(text=f[0], pron=f[1], translation=f[2]))
        else:
            fail(path, n, f"balise inconnue : {tag}")
    return readings


def build(lang):
    lessons = []
    cur = None
    paths = [p for p in sorted((ROOT / "content" / lang).glob("*.txt")) if p.name not in EXTRA_FILES]
    for path in paths:
        for n, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
            line = raw.strip()
            if not line:
                continue
            tag, _, rest = line.partition(" ")
            f = [x.strip() for x in rest.split("|")]
            if tag == "#":
                if len(f) != 4:
                    fail(path, n, "titre : 4 champs attendus")
                cur = dict(id=f"{lang}-{len(lessons) + 1:02d}", level=f[0], number=len(lessons) + 1,
                           title=f[1], titleTr=f[2], emoji=f[3], intro="", vocab=[], grammar=[],
                           dialogue=[], quiz=[], homework=[], phrases=[])
                lessons.append(cur)
            elif cur is None:
                fail(path, n, "contenu avant le premier titre")
            elif tag == ">":
                cur["intro"] = rest.strip()
            elif tag == "V":
                if len(f) != 5:
                    fail(path, n, "V : 5 champs attendus")
                cur["vocab"].append(dict(word=f[0], translation=f[1], emoji=f[2], example=f[3], exampleTr=f[4]))
            elif tag == "G":
                if len(f) != 3:
                    fail(path, n, "G : 3 champs attendus")
                examples = []
                for ex in f[2].split(";;"):
                    text, sep, tr = ex.rpartition(" = ")
                    if not sep:
                        fail(path, n, f"exemple sans ' = ' : {ex}")
                    examples.append(dict(text=text.strip(), translation=tr.strip()))
                cur["grammar"].append(dict(title=f[0], explanation=f[1], examples=examples))
            elif tag == "D":
                if len(f) != 3 or f[0] not in ("A", "B"):
                    fail(path, n, "D : A|texte|traduction")
                cur["dialogue"].append(dict(speaker=f[0], text=f[1], translation=f[2]))
            elif tag == "Q":
                if len(f) < 4 or f[1] in f[2:] or len(set(f[1:])) != len(f[1:]):
                    fail(path, n, "Q : réponses invalides ou en double")
                cur["quiz"].append(dict(type="mcq", question=f[0], correct=f[1], wrong=f[2:]))
            elif tag == "L":
                if len(f) < 3 or f[1] in f[2:]:
                    fail(path, n, "L : réponses invalides")
                cur["quiz"].append(dict(type="listen", phrase=f[0], correct=f[1], wrong=f[2:]))
            elif tag == "T":
                if len(f) < 2:
                    fail(path, n, "T : réponse manquante")
                cur["quiz"].append(dict(type="typed", prompt=f[0], answers=f[1:]))
            elif tag == "H":
                if len(f) != 3:
                    fail(path, n, "H : 3 champs attendus")
                cur["homework"].append(dict(prompt=f[0], model=f[1],
                                            keywords=[k.strip() for k in f[2].split(",") if k.strip()]))
            elif tag == "P":
                if len(f) != 2:
                    fail(path, n, "P : 2 champs attendus")
                cur["phrases"].append(dict(text=f[0], translation=f[1]))
            else:
                fail(path, n, f"balise inconnue : {tag}")

    # Les leçons sont rangées par niveau (ordre des fichiers conservé à l'intérieur d'un niveau).
    order = ["A1", "A2", "B1", "B2", "C1", "C2"]
    lessons.sort(key=lambda item: order.index(item["level"]))
    for position, lesson in enumerate(lessons, 1):
        lesson["id"] = f"{lang}-{position:02d}"
        lesson["number"] = position

    for lesson in lessons:
        for field, minimum in (("vocab", 6), ("grammar", 1), ("dialogue", 4), ("quiz", 5), ("homework", 1), ("phrases", 3)):
            if len(lesson[field]) < minimum:
                sys.exit(f"{lesson['id']} ({lesson['title']}) : pas assez de « {field} »")
        if not lesson["intro"]:
            sys.exit(f"{lesson['id']} : introduction manquante")

    # Textes de lecture (par numéro de leçon) et prononciation figurée.
    readings = load_readings(lang)
    for number in readings:
        if not 1 <= number <= len(lessons):
            sys.exit(f"lecture.txt : la leçon {number} n'existe pas")
    pron = load_pron(lang)
    used, missing = set(), []

    def find(text):
        k = key(text)
        if k in pron:
            used.add(k)
            return pron[k]
        if pron:
            missing.append(text)
        return ""

    for lesson in lessons:
        for v in lesson["vocab"]:
            v["pron"] = find(v["word"])
            v["examplePron"] = find(v["example"])
        for g in lesson["grammar"]:
            for ex in g["examples"]:
                ex["pron"] = find(ex["text"])
        for d in lesson["dialogue"]:
            d["pron"] = find(d["text"])
        for p in lesson["phrases"]:
            p["pron"] = find(p["text"])
        reading = readings.get(lesson["number"])
        if reading:
            for sentence in reading["sentences"]:
                if not sentence["pron"]:
                    sentence["pron"] = find(sentence["text"])
            lesson["reading"] = reading

    out = ROOT / "app" / "src" / "main" / "assets" / "courses" / f"{lang}.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(dict(lang=lang, lessons=lessons), ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"{out.relative_to(ROOT)} : {len(lessons)} leçons, {len(readings)} textes de lecture")
    if pron:
        unused = [k for k in pron if k not in used]
        print(f"  prononciation : {len(used)} textes couverts, {len(set(missing))} sans prononciation, "
              f"{len(unused)} lignes inutilisées")
        if "-v" in sys.argv:
            for text in sorted(set(missing)):
                print("    manque :", text)
            for text in unused:
                print("    inutilisée :", text)
    for lesson in lessons:
        print(f"  {lesson['id']} {lesson['level']} {lesson['title']} — "
              f"{len(lesson['vocab'])} mots, {len(lesson['quiz'])} questions")


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("-")]
    build(args[0] if args else "es")
