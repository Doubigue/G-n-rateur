#!/usr/bin/env python3
"""Prononciation figurée de l'espagnol (Espagne) pour un lecteur francophone.

Usage : python3 tools/pron_es.py          (complète content/es/prononciation.txt)
        python3 tools/pron_es.py --force  (régénère tout le fichier)

Les lignes déjà présentes dans prononciation.txt sont conservées (corrections à la main).
Conventions : syllabes séparées par « - », syllabe accentuée en MAJUSCULES ;
« th » = th anglais (c devant e/i, z) ; « kh » = jota (j, g devant e/i) ;
« rr » = r roulé ; « nn », « mm » en fin de syllabe = n / m non nasal.
"""
import re
import sys
import unicodedata
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from pron_common import collect_texts, write_table  # noqa: E402

VOWELS = "aeiouáéíóúü"
STRONG = "aeoáéóíú"   # voyelles qui forment un noyau (une voyelle accentuée aussi)
CLUSTERS = {"pr", "br", "tr", "dr", "cr", "gr", "fr", "pl", "bl", "cl", "gl", "fl", "kr", "tl"}
UNSTRESSED = set("""el la lo los las un una unos unas de del a al en con por para sin sobre entre hasta desde
y e o u ni que se me te le nos os les mi mis tu tus su sus pero como cuando donde mientras porque aunque si
cual cuales quien quienes cuyo cuya nuestro nuestra nuestros nuestras vuestro vuestra""".split())
KH_X = {"méxico", "mexicano", "mexicana", "mexicanos", "mexicanas", "texas", "oaxaca", "xavier"}


def units(word):
    """Découpe le mot en unités graphiques (ch, ll, rr, qu, gu+e/i comptent pour une consonne)."""
    out, i = [], 0
    w = word
    while i < len(w):
        two = w[i:i + 2]
        if two in ("ch", "ll", "rr"):
            out.append(two)
            i += 2
        elif two == "qu" and i + 2 < len(w) and w[i + 2] in "eéií":
            out.append("qu")
            i += 2
        elif two == "gu" and i + 2 < len(w) and w[i + 2] in "eéií":
            out.append("gu")
            i += 2
        else:
            out.append(w[i])
            i += 1
    return out


def is_vowel(u, units_, k):
    if u in VOWELS:
        return True
    # « y » final ou entre consonnes est une voyelle (hay, muy, rey, y)
    if u == "y":
        nxt = units_[k + 1] if k + 1 < len(units_) else None
        return nxt is None or nxt not in VOWELS
    return False


def syllables(word):
    us = units(word)
    kinds = ["V" if is_vowel(u, us, k) else "C" for k, u in enumerate(us)]
    # Noyaux : voyelles adjacentes en diphtongue sauf deux fortes (hiatus) ou faible accentuée.
    nuclei = []  # liste de (début, fin) en indices d'unités
    k = 0
    while k < len(us):
        if kinds[k] == "V":
            start = k
            while k + 1 < len(us) and kinds[k + 1] == "V":
                a, b = us[k], us[k + 1]
                strong_a = a in "aeoáéó" or a in "íú"
                strong_b = b in "aeoáéó" or b in "íú"
                if strong_a and strong_b:
                    break
                k += 1
            nuclei.append((start, k))
        k += 1
    if not nuclei:
        return ["".join(us)]
    bounds = []
    for (s1, e1), (s2, _e2) in zip(nuclei, nuclei[1:]):
        cons = us[e1 + 1:s2]
        n = len(cons)
        if n == 0:
            cut = s2
        elif n == 1:
            cut = s2 - 1
        elif n == 2:
            cut = s2 - 2 if (cons[0] + cons[1]) in CLUSTERS else s2 - 1
        else:
            cut = s2 - 2 if (cons[-2] + cons[-1]) in CLUSTERS else s2 - 1
        bounds.append(cut)
    sylls, prev = [], 0
    for b in bounds:
        sylls.append(us[prev:b])
        prev = b
    sylls.append(us[prev:])
    return sylls


def stressed_index(word, sylls):
    for idx, syl in enumerate(sylls):
        if any(ch in "áéíóú" for u in syl for ch in u):
            return idx
    if len(sylls) == 1:
        return 0
    last = word[-1]
    return len(sylls) - 2 if last in "aeiouns" else len(sylls) - 1


def render_word(word):
    low = word.lower()
    sylls = syllables(low)
    if not isinstance(sylls[0], list):
        return word
    stress = stressed_index(low, sylls)
    flat = [u for s in sylls for u in s]
    pieces, pos = [], 0
    for si, syl in enumerate(sylls):
        out = ""
        for j, u in enumerate(syl):
            k = pos + j
            nxt = flat[k + 1] if k + 1 < len(flat) else ""
            prv = flat[k - 1] if k > 0 else ""
            coda = j == len(syl) - 1 and not is_vowel(u, flat, k)
            # voyelles (avec glissement i/u devant une autre voyelle)
            if u in "aá":
                out += "a"
            elif u in "eé":
                out += "é"
            elif u in "oó":
                out += "o"
            elif u in "ií" or (u == "y" and is_vowel(u, flat, k)):
                if u == "i" and nxt and nxt in "aeoáéóu" and is_vowel(nxt, flat, k + 1):
                    out += "y"
                elif prv and prv in "aeoáéó" and u != "í" and is_vowel(prv, flat, k - 1):
                    out += "ï"
                else:
                    out += "i"
            elif u in "uúü":
                if prv == "q":
                    continue
                out += "ou"
            # consonnes
            elif u == "qu":
                out += "k"
            elif u == "gu":
                out += "gu"
            elif u == "ch":
                out += "tch"
            elif u == "ll":
                out += "y"
            elif u == "rr":
                out += "rr"
            elif u == "r":
                out += "rr" if (k == 0 or prv in ("n", "l", "s")) else "r"
            elif u == "c":
                out += "th" if nxt[:1] in ("e", "é", "i", "í") else "k"
            elif u == "z":
                out += "th"
            elif u == "g":
                if nxt[:1] in ("e", "é", "i", "í"):
                    out += "kh"
                else:
                    out += "g"
            elif u == "j":
                out += "kh"
            elif u == "h":
                continue
            elif u == "ñ":
                out += "gn"
            elif u == "v":
                out += "b"
            elif u == "w":
                out += "ou"
            elif u == "x":
                out += "kh" if low in KH_X else "ks"
            elif u == "y":
                out += "y"
            elif u == "s":
                out += "s" if (k == 0 or (nxt and not is_vowel(nxt, flat, k + 1))) else "ss"
            elif u in ("n", "m") and (not nxt or (not is_vowel(nxt, flat, k + 1) and nxt not in ("n", "m"))):
                out += u * 2  # « nn » / « mm » : n et m ne sont jamais nasaux en espagnol
            else:
                out += u
        if out.endswith("i") and si == len(sylls) - 1 and flat[-1] == "y" and len(out) > 1 and out[-2] in "aéo":
            out = out[:-1] + "ï"
        pieces.append(out)
        pos += len(syl)
    if len(sylls) > 1 and low not in UNSTRESSED:
        pieces[stress] = pieces[stress].upper()
    return "-".join(p for p in pieces if p)


WORD = re.compile(r"[A-Za-zÁÉÍÓÚÜÑáéíóúüñ]+")


def pron(text):
    text = text.replace("¿", "").replace("¡", "")
    return WORD.sub(lambda m: render_word(m.group(0)), text).strip()


if __name__ == "__main__":
    texts = collect_texts("es")
    write_table("es", texts, pron, force="--force" in sys.argv)
