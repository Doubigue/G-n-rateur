#!/usr/bin/env python3
"""Prononciation figurée de l'anglais (américain) pour un lecteur francophone.

L'orthographe anglaise est trop irrégulière pour des règles : chaque mot est cherché dans
tools/dict_en.txt (conventions en tête de ce fichier). Ajoutez-y les mots nouveaux.

Usage : python3 tools/pron_en.py          (complète content/en/prononciation.txt)
        python3 tools/pron_en.py --force  (régénère tout le fichier)
"""
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from pron_common import collect_texts, write_table  # noqa: E402

DICT = {}
for line in (Path(__file__).resolve().parent / "dict_en.txt").read_text(encoding="utf-8").splitlines():
    if line.startswith("//") or " = " not in line:
        continue
    word, _, p = line.partition(" = ")
    DICT[word.strip().lower()] = p.strip()

WORD = re.compile(r"[A-Za-zÀ-ÿ]+(?:['’][A-Za-z]+)*")
missing = set()


def one(m):
    w = m.group(0).replace("’", "'")
    p = DICT.get(w.lower())
    if p is None:
        missing.add(w.lower())
        return w
    return p


def pron(text):
    return WORD.sub(one, text.replace("“", '"').replace("”", '"')).strip()


if __name__ == "__main__":
    write_table("en", collect_texts("en"), pron, force="--force" in sys.argv)
    if missing:
        sys.exit("Mots absents de tools/dict_en.txt : " + " ".join(sorted(missing)))
