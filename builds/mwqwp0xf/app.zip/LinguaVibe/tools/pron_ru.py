#!/usr/bin/env python3
"""Prononciation figurée du russe pour un lecteur francophone.

L'accent tonique vient de tools/stress_ru.txt (voyelle accentuée en majuscule) ou de la lettre ё.
Le script applique ensuite les règles de lecture : voyelles réduites hors accent (о → a, е / я → i),
consonnes assourdies en fin de mot, consonnes mouillées.

Usage : python3 tools/pron_ru.py          (complète content/ru/prononciation.txt)
        python3 tools/pron_ru.py --force  (régénère tout le fichier)
"""
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from pron_common import collect_texts, write_table  # noqa: E402

VOWELS = "аеёиоуыэюя"
SONORANT = "лмнрй"
VOICED = {"б": "п", "в": "ф", "г": "к", "д": "т", "ж": "ш", "з": "с"}
VOICELESS = {v: k for k, v in VOICED.items()}
HARD = "жшц"

STRESS = {}
for line in (Path(__file__).resolve().parent / "stress_ru.txt").read_text(encoding="utf-8").splitlines():
    if line.startswith("//"):
        continue
    for w in line.split():
        idx = next(i for i, c in enumerate(w) if c.isupper())
        STRESS[w.lower()] = idx

# Mots dont la lecture s'écarte des règles
SPECIAL = {
    "что": "chto", "чтобы": "CHTO-by", "что-то": "CHTO-ta", "что-нибудь": "CHTO-ni-bout'", "конечно": "ka-NIÉCH-na",
    "скучно": "SKOUCH-na", "здравствуйте": "ZDRAS-tvouï-tié", "здравствуй": "ZDRAS-tvouï", "солнце": "SONN-tsé",
    "сегодня": "si-VOD-nia", "сегодняшний": "si-VOD-nich-niï", "пожалуйста": "pa-JA-lous-ta", "его": "yi-VO",
    "ничего": "ni-tchi-VO", "чего": "tchi-VO", "кого": "ka-VO", "сейчас": "si-TCHASS", "чувствую": "TCHOUS-tvou-you",
    "чувствуете": "TCHOUS-tvou-ié-tié", "чувствовала": "TCHOUS-tva-va-la", "лёгкий": "LIOKH-kiï", "легко": "likh-KO",
    "мягкий": "MIAKH-kiï", "счастье": "CHTCHAS-tié", "счастья": "CHTCHAS-tia", "счастью": "CHTCHAS-tiou",
    "счастливые": "chtchis-LI-vy-yé", "счастливым": "chtchis-LI-vymm", "несчастье": "ni-CHTCHAS-tié",
    "счёт": "chtchot", "здание": "ZDA-ni-yé", "булочная": "BOU-lach-na-ya",
}
# Petits mots sans accent propre, prononcés avec le mot suivant
PROCLITIC = {"до": "da", "по": "pa", "со": "sa", "во": "va", "ко": "ka", "о": "a", "об": "ap", "обо": "a-ba",
             "от": "at", "но": "na", "не": "ni", "ни": "ni", "же": "jy", "без": "biz", "из": "iz", "под": "pat",
             "над": "nat", "из-за": "iz-za"}
NOT_V = {"много", "немного", "строго", "дорого", "убого", "полого"}
WORD = re.compile(r"[А-Яа-яЁё]+(?:-[А-Яа-яЁё]+)*")


def stress_index(w):
    if "ё" in w:
        return w.index("ё")
    if w in STRESS:
        return STRESS[w]
    vs = [i for i, c in enumerate(w) if c in VOWELS]
    if len(vs) == 1:
        return vs[0]
    return None


def assimilate(letters):
    """Assourdissement final et assimilation de sonorité dans les groupes de consonnes."""
    out = list(letters)
    if not any(c in VOWELS for c in out):
        return out  # prépositions d'une lettre (в, к, с) : on les laisse telles quelles
    nxt = "end"
    for i in range(len(out) - 1, -1, -1):
        c = out[i]
        if c in "ьъ":
            continue
        if c in VOWELS or c in SONORANT:
            nxt = None
            continue
        if nxt in ("end", "voiceless") and c in VOICED:
            out[i] = VOICED[c]
        elif nxt == "voiced" and c in VOICELESS:
            out[i] = VOICELESS[c]
        c2 = out[i]
        if c2 == "в":
            nxt = None
        elif c2 in VOICED:
            nxt = "voiced"
        else:
            nxt = "voiceless"
    return out


def syllables(w):
    vs = [i for i, c in enumerate(w) if c in VOWELS]
    if len(vs) <= 1:
        return [list(range(len(w)))]
    cuts = []
    for a, b in zip(vs, vs[1:]):
        cons = [k for k in range(a + 1, b)]
        real = [k for k in cons if w[k] not in "ьъ"]
        if not cons:
            cuts.append(b)
        elif w[cons[0]] == "й" or (len(real) >= 2 and w[real[0]] in SONORANT and w[real[0]] != "й"):
            # й et la première sonante restent avec la voyelle d'avant
            first = cons[0]
            k = first + 1
            while k < b and w[k] in "ьъ":
                k += 1
            cuts.append(k)
        else:
            cuts.append(cons[0])
    out, prev = [], 0
    for c in cuts:
        out.append(list(range(prev, c)))
        prev = c
    out.append(list(range(prev, len(w))))
    return out


CONS = {"б": "b", "в": "v", "г": "g", "д": "d", "ж": "j", "з": "z", "к": "k", "л": "l", "м": "m", "н": "n", "п": "p",
        "р": "r", "с": "s", "т": "t", "ф": "f", "х": "kh", "ц": "ts", "ч": "tch", "ш": "ch", "щ": "chtch"}


def render_word(word):
    w = word.lower()
    if w in SPECIAL:
        return SPECIAL[w]
    if w in PROCLITIC:
        return PROCLITIC[w]
    if "-" in w:
        return "-".join(render_word(p) for p in w.split("-"))
    st = stress_index(w)
    letters = list(w)
    if (w.endswith("ого") or w.endswith("его")) and len(w) > 3 and w not in NOT_V:
        letters[-2] = "в"
    letters = assimilate(letters)
    n = len(letters)
    sylls = syllables(w)
    pieces = []
    for syl in sylls:
        out = ""
        for k in syl:
            c = letters[k]
            prev = letters[k - 1] if k > 0 else ""
            after_vowel = (k == 0) or prev in VOWELS or prev in ("ь", "ъ")
            prev = prev or "#"
            stressed = k == st
            final = k == n - 1
            if c in VOWELS:
                if c == "а":
                    out += "i" if (not stressed and prev in ("ч", "щ")) else "a"
                elif c == "о":
                    out += "o" if stressed else "a"
                elif c == "у":
                    out += "ou"
                elif c == "ы":
                    out += "y"
                elif c == "э":
                    out += "é"
                elif c == "и":
                    out += "y" if prev in HARD else ("yi" if prev == "ь" else "i")
                elif c == "е":
                    if after_vowel:
                        out += "yé" if (stressed or final) else "yi"
                    elif prev in HARD:
                        out += "é" if stressed else "y"
                    elif prev in ("ч", "щ"):
                        out += "é" if stressed else "i"
                    else:
                        out += "ié" if stressed else "i"
                elif c == "ё":
                    out += "yo" if after_vowel else ("o" if prev in HARD + "чщ" else "io")
                elif c == "ю":
                    out += "you" if after_vowel else ("ou" if prev in HARD + "чщ" else "iou")
                elif c == "я":
                    if after_vowel:
                        out += "ya" if (stressed or final) else "yi"
                    elif prev in ("ч", "щ"):
                        out += "a" if stressed or final else "i"
                    else:
                        out += "ia" if (stressed or final) else "i"
            elif c == "й":
                out += "y" if (k + 1 < n and letters[k + 1] in VOWELS) else "ï"
            elif c == "ь":
                if k + 1 < n and letters[k + 1] in VOWELS:
                    continue
                if prev not in HARD + "чщ":
                    out += "'"
            elif c == "ъ":
                continue
            else:
                out += CONS.get(c, c)
        pieces.append(out)

    # Retouches pour un lecteur francophone
    fixed = []
    for i, p in enumerate(pieces):
        p = re.sub(r"g(?=[iéy])", "gu", p)
        p = re.sub(r"(?<=[aeiouéyï])s(?=[aeiouéy])", "ss", p)
        # n et m en fin de syllabe ou devant consonne : jamais nasaux
        p = re.sub(r"([nm])(?=$|'|[^aeiouéyïoa'])", lambda m: m.group(1) * 2, p)
        fixed.append(p)
    # s entre deux voyelles à la jonction de syllabes
    for i in range(1, len(fixed)):
        if fixed[i].startswith("s") and not fixed[i].startswith("ss") and fixed[i - 1][-1:] in "aeiouéyï" \
                and len(fixed[i]) > 1 and fixed[i][1] in "aeiouéy":
            fixed[i] = "s" + fixed[i]
    if len(fixed) > 1 and st is not None:
        for i, syl in enumerate(sylls):
            if st in syl:
                fixed[i] = fixed[i].upper()
    return "-".join(fixed)


missing = set()


def pron(text):
    def one(m):
        w = m.group(0)
        low = w.lower()
        for part in low.split("-"):
            if part not in SPECIAL and part not in PROCLITIC and any(c in VOWELS for c in part) \
                    and stress_index(part) is None:
                missing.add(part)
        return render_word(w)
    return WORD.sub(one, text).strip()


if __name__ == "__main__":
    write_table("ru", collect_texts("ru"), pron, force="--force" in sys.argv)
    if missing:
        sys.exit("Accent inconnu (ajoutez-les à tools/stress_ru.txt) : " + " ".join(sorted(missing)))
