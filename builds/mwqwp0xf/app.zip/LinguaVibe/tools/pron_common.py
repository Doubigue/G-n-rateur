"""Outils communs aux générateurs de prononciation figurée (tools/pron_<langue>.py)."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
EXTRA = ("prononciation.txt", "lecture.txt")


def key(text):
    return " ".join(text.split())


def collect_texts(lang):
    """Tous les textes à prononcer d'un cours : mots, exemples, grammaire, dialogues, phrases, lectures."""
    folder = ROOT / "content" / lang
    texts = []
    for path in sorted(folder.glob("*.txt")):
        if path.name == "prononciation.txt":
            continue
        for raw in path.read_text(encoding="utf-8").splitlines():
            tag, _, rest = raw.strip().partition(" ")
            f = [x.strip() for x in rest.split("|")]
            if tag == "V":
                texts += [f[0], f[3]]
            elif tag == "G":
                texts += [ex.rpartition(" = ")[0].strip() for ex in f[2].split(";;")]
            elif tag in ("D",):
                texts.append(f[1])
            elif tag in ("P", "R"):
                texts.append(f[0])
    seen, out = set(), []
    for t in texts:
        k = key(t)
        if k and k not in seen:
            seen.add(k)
            out.append(k)
    return out


def write_table(lang, texts, convert, force=False):
    path = ROOT / "content" / lang / "prononciation.txt"
    existing = {}
    if path.exists() and not force:
        for line in path.read_text(encoding="utf-8").splitlines():
            text, sep, pron = line.rpartition(" = ")
            if sep and not line.startswith("//"):
                existing[key(text)] = pron.strip()
    lines = ["// Prononciation figurée — syllabe accentuée en MAJUSCULES. Corrigez librement une ligne :",
             "// elle est conservée quand le fichier est complété par tools/pron_" + lang + ".py."]
    added = 0
    for t in texts:
        if t in existing:
            p = existing[t]
        else:
            p = convert(t)
            added += 1
        lines.append(f"{t} = {p}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"{path.relative_to(ROOT)} : {len(texts)} textes ({added} nouveaux)")
