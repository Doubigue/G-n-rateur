# Professeurs 3D animés

Les six professeurs disposent maintenant de deux variantes GLB locales :

- `models/<nom>_idle.glb` : mouvement d'attente (léger balancement, mouvement de tête et clignement des yeux).
- `models/<nom>_speaking.glb` : gestes de bras, mouvements de tête et ouverture/fermeture de la bouche pendant la lecture vocale.

La vue `TeachersScreen` sélectionne la variante parlante pendant la lecture et revient à l'animation d'attente à la fin ou à l'arrêt de la voix. Les modèles sont intégrés dans les assets Android ; aucune connexion réseau n'est nécessaire pour les afficher.

## Limite de synchronisation

L'ouverture de la bouche est une animation cyclique de parole. Elle n'est pas encore synchronisée phonème par phonème avec l'audio et ne reproduit pas précisément chaque syllabe. Les personnages utilisent des animations de transformation de nœuds glTF ; les modèles ne disposent pas encore d'un squelette articulé complet pour des gestes corporels complexes.

## Contrôle effectué

Les 12 fichiers GLB (6 modes d'attente et 6 modes de parole) ont été relus avec un parseur de scènes 3D : géométries présentes et clips d'animation détectés. La compilation Android complète n'a pas été exécutée dans cet environnement.

## Lip-sync piloté par le niveau sonore

- `Speaker.speechLevel` (0 à 1, enveloppe d'amplitude mesurée avec Android `Visualizer`) commande désormais directement le nœud glTF `mouth` : `MouthRig` (ui/MouthRig.kt) modifie sa transformation Filament à chaque image (ouverture verticale, léger rétrécissement horizontal, ouverture rapide / fermeture plus lente).
- Les GLB ont été corrigés : le mesh de la bouche est recentré sur l'origine du nœud (sa position passe dans la translation du nœud), sinon une mise à l'échelle la déplaçait vers le haut du visage. Le canal `scale` de `mouth` a été retiré des clips `*_speaking.glb`, pour que le code seul pilote la bouche.
- Voix Android : le texte est synthétisé dans un fichier (`synthesizeToFile`) puis relu par `MediaPlayer`, ce qui donne accès au même niveau sonore que les voix ElevenLabs/Kokoro/Piper. En cas d'échec, lecture directe par le moteur Android avec un rythme de bouche simulé (indiqué sous le personnage).
- `Visualizer` exige l'autorisation audio (RECORD_AUDIO) même sans micro : elle est demandée au premier clic sur une lecture dans « Mes professeurs ». Refusée, la bouche utilise le rythme simulé.

## Encore à faire

- Synchronisation phonème par phonème / visèmes (formes de bouche distinctes pour A, O, M, etc.) : nécessite des données d'alignement (par ex. timestamps ElevenLabs ou phonèmes Piper/Kokoro) et plusieurs formes de bouche.
- Les nœuds du visage sont à plat sous `world` : la bouche ne suit pas la rotation de la tête du clip d'animation.
- Compilation Android et test sur appareil non effectués dans cet environnement : les API Filament/SceneView utilisées (`onFrame`, `modelInstance.asset`, `transformManager`) sont à vérifier à la première compilation.
