# Intégration MODEL 2 et Room — version 1.3

## Parcours espagnol
- La carte Espagnol ouvre maintenant un écran de choix entre MODEL 1 et MODEL 2.
- MODEL 1 conserve le catalogue `assets/courses/es.json` et les cours espagnols synchronisés depuis Firebase.
- MODEL 2 charge exclusivement `assets/courses/es_model2.json` : 16 leçons construites à partir des 16 chapitres du guide PDF.
- Les identifiants des leçons MODEL 2 sont préfixés `m2-es-` et les clés de progression utilisent `es_model2`.
- MODEL 1 garde les clés de progression historiques afin de préserver les scores déjà enregistrés.

## Niveaux
Aucun contrôle de prérequis n'est ajouté : A1, A2, B1, B2, C1 et C2 sont accessibles. Les 16 chapitres du PDF sont répartis dans A1 à C1 pour la navigation ; cette répartition est une proposition de structuration et n'est pas présentée comme une classification officielle fournie par le PDF. C2 est visible et ouvert, mais le guide PDF ne contient pas de chapitre C2 : l'écran le signale au lieu d'inventer des leçons.

## Room
- Room 2.7.2 et KAPT sont ajoutés au module Android.
- Les résultats de quiz et les devoirs sont enregistrés dans `linguavibe_progress.db`.
- SharedPreferences est conservé pour la compatibilité et l'affichage instantané des scores existants ; les nouvelles actions sont également copiées dans Room.

## Contrôle
Le JSON MODEL 2 a été vérifié : 16 leçons, 48 questions de quiz et 16 devoirs. Le projet n'a pas pu être compilé ici : l'environnement ne dispose pas du SDK Android ni d'une distribution Gradle installée. Ouvrir le dossier dans Android Studio, synchroniser Gradle et lancer une compilation avant installation sur téléphone.
