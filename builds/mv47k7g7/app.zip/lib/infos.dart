import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import 'donnees.dart';
import 'main.dart';

Future<void> lien(String u) async {
  final x = Uri.tryParse(u.trim());
  if (x != null && ['http', 'https', 'tel', 'mailto'].contains(x.scheme)) {
    await launchUrl(x, mode: LaunchMode.externalApplication);
  }
}

String? premiereImage(dynamic x) {
  final l = x is List ? x.map((e) => '$e').toList() : '${x ?? ''}'.split(RegExp(r'\n+'));
  for (final s in l) {
    final t = s.trim();
    if (t.startsWith('http') || t.startsWith('data:image')) return t;
  }
  return null;
}

Widget vide(String t) => Center(child: Padding(padding: const EdgeInsets.all(32), child: Text(t, textAlign: TextAlign.center)));

class PageInfos extends StatelessWidget {
  const PageInfos({super.key});

  @override
  Widget build(BuildContext context) {
    return const DefaultTabController(
      length: 5,
      child: Column(children: [
        TabBar(
          isScrollable: true,
          tabAlignment: TabAlignment.start,
          labelColor: vert,
          indicatorColor: or,
          tabs: [Tab(text: 'Actualités'), Tab(text: 'Annonces'), Tab(text: 'FAQ'), Tab(text: 'Avis'), Tab(text: 'Agences')],
        ),
        Expanded(child: TabBarView(children: [PageActus(), ListeAnnonces(), ListeFaq(), ListeAvis(), ListeAgences()])),
      ]),
    );
  }
}

class ListeAnnonces extends StatelessWidget {
  const ListeAnnonces({super.key});
  static const types = {
    'manuscrit': '📣 Appel à manuscrits', 'partenariat': '🤝 Appel à partenariats', 'parution': '✨ Nouvelle parution',
    'paraitre': '⏳ À paraître', 'ticker': '⚡ Info', 'event': '📅 Événement', 'quote': '❤️ Coup de cœur', 'banner': '🎪 Promotion',
  };

  @override
  Widget build(BuildContext context) {
    final l = etat.annonces.where((a) => (a['showOnSite'] ?? (a['isActive'] != false)) != false).toList()
      ..sort((a, b) => '${b['_creation']}'.compareTo('${a['_creation']}'));
    if (l.isEmpty) return vide('Aucune annonce pour le moment.');
    return ListView(padding: const EdgeInsets.all(16), children: [
      for (final a in l)
        Card(
          color: Colors.white,
          elevation: 0,
          clipBehavior: Clip.antiAlias,
          margin: const EdgeInsets.only(bottom: 14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            if (premiereImage(a['images']) != null)
              SizedBox(height: 160, width: double.infinity, child: Couv(premiereImage(a['images'])!)),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(types[texte(a, 'type')] ?? 'Annonce', style: const TextStyle(fontSize: 12, color: vert2)),
                const SizedBox(height: 4),
                Text(texte(a, 'title'), style: const TextStyle(fontFamily: 'serif', fontSize: 20, fontWeight: FontWeight.w600)),
                if (texte(a, 'subtitle').isNotEmpty) Text(texte(a, 'subtitle'), style: const TextStyle(color: Colors.black54)),
                if (texte(a, 'targetDate').isNotEmpty)
                  Padding(padding: const EdgeInsets.only(top: 4), child: Text(dateFr(a['targetDate']), style: const TextStyle(fontWeight: FontWeight.w600))),
                if (texte(a, 'description').isNotEmpty)
                  Padding(padding: const EdgeInsets.only(top: 8), child: Text(texte(a, 'description'), style: const TextStyle(height: 1.5))),
                if (texte(a, 'btnUrl').isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: FilledButton(
                      onPressed: () => lien(texte(a, 'btnUrl')),
                      child: Text(texte(a, 'btnText').isEmpty ? 'En savoir plus' : texte(a, 'btnText')),
                    ),
                  ),
              ]),
            ),
          ]),
        ),
    ]);
  }
}

class ListeFaq extends StatelessWidget {
  const ListeFaq({super.key});

  @override
  Widget build(BuildContext context) {
    if (etat.faqs.isEmpty) return vide('Aucune question pour le moment.');
    return ListView(padding: const EdgeInsets.all(16), children: [
      for (final f in etat.faqs)
        Card(
          color: Colors.white,
          elevation: 0,
          child: ExpansionTile(
            shape: const Border(),
            title: Text(texte(f, 'question'), style: const TextStyle(fontWeight: FontWeight.w600)),
            childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            expandedCrossAxisAlignment: CrossAxisAlignment.start,
            children: [Text(texte(f, 'answer'), style: const TextStyle(height: 1.5))],
          ),
        ),
    ]);
  }
}

class ListeAvis extends StatelessWidget {
  const ListeAvis({super.key});

  @override
  Widget build(BuildContext context) {
    if (etat.avis.isEmpty) return vide('Aucun témoignage pour le moment.');
    return ListView(padding: const EdgeInsets.all(16), children: [
      for (final t in etat.avis)
        Card(
          color: Colors.white,
          elevation: 0,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              SizedBox(
                width: 46,
                height: 46,
                child: ClipOval(
                  child: texte(t, 'photo').isEmpty
                      ? Container(color: vert, alignment: Alignment.center,
                          child: Text(texte(t, 'name').isEmpty ? '?' : texte(t, 'name')[0], style: const TextStyle(color: or, fontSize: 20)))
                      : Couv(texte(t, 'photo')),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('« ${texte(t, 'text')} »', style: const TextStyle(fontStyle: FontStyle.italic, height: 1.5)),
                  const SizedBox(height: 6),
                  Text('— ${texte(t, 'name')}${texte(t, 'role').isEmpty ? '' : ', ${texte(t, 'role')}'}',
                      style: const TextStyle(fontSize: 13, color: Colors.black54)),
                ]),
              ),
            ]),
          ),
        ),
    ]);
  }
}

class ListeAgences extends StatelessWidget {
  const ListeAgences({super.key});

  @override
  Widget build(BuildContext context) {
    if (etat.agences.isEmpty) return vide('Aucune agence pour le moment.');
    return ListView(padding: const EdgeInsets.all(16), children: [
      for (final a in etat.agences)
        Card(
          color: Colors.white,
          elevation: 0,
          clipBehavior: Clip.antiAlias,
          margin: const EdgeInsets.only(bottom: 14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            if (texte(a, 'image').isNotEmpty) SizedBox(height: 130, width: double.infinity, child: Couv(texte(a, 'image'))),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(texte(a, 'name'), style: const TextStyle(fontFamily: 'serif', fontSize: 20, fontWeight: FontWeight.w600)),
                Text([texte(a, 'address'), texte(a, 'city')].where((x) => x.isNotEmpty).join(', '),
                    style: const TextStyle(color: Colors.black54)),
                if (texte(a, 'phone').isNotEmpty)
                  TextButton.icon(
                    onPressed: () => lien('tel:${texte(a, 'phone').replaceAll(' ', '')}'),
                    icon: const Icon(Icons.call),
                    label: Text(texte(a, 'phone')),
                  ),
              ]),
            ),
          ]),
        ),
    ]);
  }
}
