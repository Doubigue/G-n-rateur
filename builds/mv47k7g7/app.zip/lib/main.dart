import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import 'compte.dart';
import 'donnees.dart';
import 'infos.dart';

const vert = Color(0xFF10281E);
const vert2 = Color(0xFF1B3D2D);
const creme = Color(0xFFFAF8F5);
const or = Color(0xFFD4AF37);
const encre = Color(0xFF17201B);

final etat = Etat();
final onglet = ValueNotifier<int>(0);

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  etat.init();
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Éditions Baobab',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: vert, primary: vert, secondary: or),
        scaffoldBackgroundColor: creme,
        appBarTheme: const AppBarTheme(
          backgroundColor: vert,
          foregroundColor: creme,
          titleTextStyle: TextStyle(fontFamily: 'serif', fontSize: 22, color: creme),
        ),
        navigationBarTheme: const NavigationBarThemeData(
          backgroundColor: Colors.white,
          indicatorColor: Color(0x33D4AF37),
        ),
      ),
      home: const Accueil(),
    );
  }
}

/// Image réseau ou en base64 (data:), avec une couverture de remplacement.
class Couv extends StatelessWidget {
  const Couv(this.src, {super.key});
  final String src;
  static final _cache = <String, Uint8List>{};

  @override
  Widget build(BuildContext context) {
    final vide = Container(
      color: const Color(0xFFE8E2D6),
      child: const Icon(Icons.menu_book, size: 36, color: Color(0xFF9A927F)),
    );
    if (src.isEmpty) return vide;
    if (src.startsWith('data:')) {
      try {
        final o = _cache.putIfAbsent(src, () => base64Decode(src.substring(src.indexOf(',') + 1)));
        return Image.memory(o, fit: BoxFit.cover, errorBuilder: (_, __, ___) => vide);
      } catch (_) {
        return vide;
      }
    }
    return Image.network(src, fit: BoxFit.cover, errorBuilder: (_, __, ___) => vide);
  }
}

class Accueil extends StatefulWidget {
  const Accueil({super.key});
  @override
  State<Accueil> createState() => _AccueilState();
}

class _AccueilState extends State<Accueil> {
  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: Listenable.merge([etat, onglet]),
      builder: (context, _) {
        const pages = [PageLivres(), PageAuteurs(), PageInfos(), PagePanier(), PageCompte()];
        return Scaffold(
          appBar: AppBar(title: const Text('Éditions Baobab')),
          body: etat.chargement && etat.livres.isEmpty
              ? const Center(child: CircularProgressIndicator())
              : etat.erreur != null && etat.livres.isEmpty
                  ? Center(
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        Text(etat.erreur!, textAlign: TextAlign.center),
                        const SizedBox(height: 12),
                        FilledButton(onPressed: etat.charger, child: const Text('Réessayer')),
                      ]),
                    )
                  : pages[onglet.value],
          bottomNavigationBar: NavigationBar(
            selectedIndex: onglet.value,
            onDestinationSelected: (v) => onglet.value = v,
            destinations: [
              const NavigationDestination(icon: Icon(Icons.menu_book_outlined), label: 'Livres'),
              const NavigationDestination(icon: Icon(Icons.person_outline), label: 'Auteurs'),
              const NavigationDestination(icon: Icon(Icons.newspaper), label: 'Infos'),
              NavigationDestination(
                icon: Badge(
                  label: Text('${etat.nombre}'),
                  isLabelVisible: etat.nombre > 0,
                  child: const Icon(Icons.shopping_bag_outlined),
                ),
                label: 'Panier',
              ),
              const NavigationDestination(icon: Icon(Icons.account_circle_outlined), label: 'Compte'),
            ],
          ),
        );
      },
    );
  }
}

class PageLivres extends StatefulWidget {
  const PageLivres({super.key});
  @override
  State<PageLivres> createState() => _PageLivresState();
}

class _PageLivresState extends State<PageLivres> {
  String _genre = 'Tous';
  String _q = '';

  @override
  Widget build(BuildContext context) {
    final genres = ['Tous', ...etat.livres.map((l) => l.genre).where((g) => g.isNotEmpty).toSet()];
    final q = _q.toLowerCase();
    final liste = etat.livres
        .where((l) => _genre == 'Tous' || l.genre == _genre)
        .where((l) => q.isEmpty || l.titre.toLowerCase().contains(q) || l.auteur.toLowerCase().contains(q))
        .toList();

    return Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
        child: TextField(
          onChanged: (v) => setState(() => _q = v),
          decoration: InputDecoration(
            hintText: 'Titre ou auteur',
            prefixIcon: const Icon(Icons.search),
            filled: true,
            fillColor: Colors.white,
            contentPadding: EdgeInsets.zero,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(30), borderSide: BorderSide.none),
          ),
        ),
      ),
      SizedBox(
        height: 48,
        child: ListView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 12),
          children: [
            for (final g in genres)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
                child: ChoiceChip(
                  label: Text(g),
                  selected: g == _genre,
                  onSelected: (_) => setState(() => _genre = g),
                ),
              ),
          ],
        ),
      ),
      Expanded(
        child: RefreshIndicator(
          onRefresh: etat.charger,
          child: liste.isEmpty
              ? ListView(children: const [
                  Padding(padding: EdgeInsets.all(40), child: Center(child: Text('Aucun livre ne correspond.'))),
                ])
              : GridView.builder(
                  padding: const EdgeInsets.all(16),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2, childAspectRatio: 0.54, crossAxisSpacing: 14, mainAxisSpacing: 14),
                  itemCount: liste.length,
                  itemBuilder: (context, i) => _CarteLivre(liste[i]),
                ),
        ),
      ),
    ]);
  }
}

class _CarteLivre extends StatelessWidget {
  const _CarteLivre(this.l);
  final Livre l;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DetailLivre(l))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Expanded(
          child: SizedBox(
            width: double.infinity,
            child: ClipRRect(borderRadius: BorderRadius.circular(10), child: Couv(l.couverture)),
          ),
        ),
        const SizedBox(height: 8),
        Text(l.titre,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontFamily: 'serif', fontSize: 16, fontWeight: FontWeight.w600, color: encre)),
        Text(l.auteur, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, color: Colors.black54)),
        const SizedBox(height: 2),
        Text(fcfa(l.papier), style: const TextStyle(fontWeight: FontWeight.w600, color: vert2)),
      ]),
    );
  }
}

class DetailLivre extends StatefulWidget {
  const DetailLivre(this.l, {super.key});
  final Livre l;
  @override
  State<DetailLivre> createState() => _DetailLivreState();
}

class _DetailLivreState extends State<DetailLivre> {
  bool _eb = false;

  @override
  Widget build(BuildContext context) {
    final l = widget.l;
    final precommande = l.statut == 'À paraître';
    return Scaffold(
      appBar: AppBar(title: const Text('Publication')),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        Center(
          child: SizedBox(
            width: 190,
            height: 285,
            child: ClipRRect(borderRadius: BorderRadius.circular(12), child: Couv(l.couverture)),
          ),
        ),
        const SizedBox(height: 20),
        Text(l.titre, style: const TextStyle(fontFamily: 'serif', fontSize: 26, fontWeight: FontWeight.w600, color: encre)),
        const SizedBox(height: 4),
        Text(l.auteur, style: const TextStyle(fontSize: 16, color: Colors.black54)),
        const SizedBox(height: 10),
        Wrap(spacing: 8, children: [
          if (l.genre.isNotEmpty) Chip(label: Text(l.genre)),
          if (l.statut.isNotEmpty) Chip(label: Text(l.statut)),
        ]),
        if (l.resume.isNotEmpty) ...[
          const SizedBox(height: 12),
          Text(l.resume, style: const TextStyle(fontSize: 15, height: 1.5)),
        ],
        if (l.ebook) ...[
          const SizedBox(height: 20),
          SegmentedButton<bool>(
            segments: const [
              ButtonSegment(value: false, label: Text('Livre papier'), icon: Icon(Icons.menu_book)),
              ButtonSegment(value: true, label: Text('E-book'), icon: Icon(Icons.tablet_android)),
            ],
            selected: {_eb},
            onSelectionChanged: (s) => setState(() => _eb = s.first),
          ),
        ],
      ]),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: FilledButton(
            style: FilledButton.styleFrom(padding: const EdgeInsets.all(16)),
            onPressed: () {
              etat.ajouter(l, _eb);
              ScaffoldMessenger.of(context)
                ..hideCurrentSnackBar()
                ..showSnackBar(const SnackBar(content: Text('Ajouté au panier')));
            },
            child: Text('${precommande ? 'Précommander' : 'Ajouter au panier'} — ${fcfa(l.prix(_eb))}'),
          ),
        ),
      ),
    );
  }
}

class PageAuteurs extends StatelessWidget {
  const PageAuteurs({super.key});

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: etat.charger,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        for (final a in etat.auteurs)
          Card(
            color: Colors.white,
            elevation: 0,
            child: ExpansionTile(
              shape: const Border(),
              leading: SizedBox(
                width: 46,
                height: 46,
                child: ClipOval(
                  child: texte(a, 'photo').isEmpty
                      ? Container(color: vert, alignment: Alignment.center,
                          child: Text(texte(a, 'name')[0], style: const TextStyle(color: or, fontSize: 20, fontFamily: 'serif')))
                      : Couv(texte(a, 'photo')),
                ),
              ),
              title: Text(texte(a, 'name'), style: const TextStyle(fontFamily: 'serif', fontSize: 18)),
              childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              expandedCrossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(texte(a, 'bio'), style: const TextStyle(height: 1.5)),
                Builder(builder: (context) {
                  final siens = etat.livres.where((l) => l.auteur == texte(a, 'name')).toList();
                  if (siens.isEmpty) return const SizedBox.shrink();
                  return Padding(
                    padding: const EdgeInsets.only(top: 12),
                    child: Wrap(spacing: 8, children: [
                      for (final l in siens)
                        ActionChip(
                          label: Text(l.titre),
                          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DetailLivre(l))),
                        ),
                    ]),
                  );
                }),
              ],
            ),
          ),
      ]),
    );
  }
}

class PageActus extends StatelessWidget {
  const PageActus({super.key});

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: etat.charger,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        for (final n in etat.actus)
          Card(
            color: Colors.white,
            elevation: 0,
            clipBehavior: Clip.antiAlias,
            margin: const EdgeInsets.only(bottom: 14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              if (texte(n, 'image').isNotEmpty) SizedBox(height: 160, width: double.infinity, child: Couv(texte(n, 'image'))),
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(dateFr(n['date']), style: const TextStyle(fontSize: 12, color: Colors.black54)),
                  const SizedBox(height: 4),
                  Text(texte(n, 'title'), style: const TextStyle(fontFamily: 'serif', fontSize: 20, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 6),
                  Text(texte(n, 'text'), style: const TextStyle(height: 1.5)),
                ]),
              ),
            ]),
          ),
      ]),
    );
  }
}

class PagePanier extends StatelessWidget {
  const PagePanier({super.key});

  @override
  Widget build(BuildContext context) {
    if (etat.panier.isEmpty) {
      return const Center(child: Text('Ton panier est vide.'));
    }
    return Column(children: [
      Expanded(
        child: ListView(padding: const EdgeInsets.all(16), children: [
          for (final l in etat.panier)
            Card(
              color: Colors.white,
              elevation: 0,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Row(children: [
                  SizedBox(width: 56, height: 80, child: ClipRRect(borderRadius: BorderRadius.circular(6), child: Couv(l.couv))),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(l.titre, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600)),
                      Text(l.ebook ? 'E-book' : 'Livre papier', style: const TextStyle(fontSize: 12, color: Colors.black54)),
                      const SizedBox(height: 4),
                      Text(fcfa(l.unite * l.qte), style: const TextStyle(color: vert2, fontWeight: FontWeight.w600)),
                    ]),
                  ),
                  if (!l.ebook)
                    Row(children: [
                      IconButton(icon: const Icon(Icons.remove_circle_outline), onPressed: () => etat.changer(l, -1)),
                      Text('${l.qte}', style: const TextStyle(fontWeight: FontWeight.bold)),
                      IconButton(icon: const Icon(Icons.add_circle_outline), onPressed: () => etat.changer(l, 1)),
                    ])
                  else
                    IconButton(icon: const Icon(Icons.close), onPressed: () => etat.retirer(l)),
                ]),
              ),
            ),
        ]),
      ),
      SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              const Text('Total', style: TextStyle(fontSize: 18)),
              Text(fcfa(etat.total), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: vert)),
            ]),
            const SizedBox(height: 10),
            FilledButton(
              style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52)),
              onPressed: () => ouvrir(context, const PageCommande()),
              child: const Text('Commander'),
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(48)),
              icon: const Icon(Icons.chat),
              label: const Text('Commander sur WhatsApp'),
              onPressed: () => launchUrl(
                Uri.parse('https://wa.me/$whatsapp?text=${Uri.encodeComponent(etat.messageCommande)}'),
                mode: LaunchMode.externalApplication,
              ),
            ),
          ]),
        ),
      ),
    ]);
  }
}
