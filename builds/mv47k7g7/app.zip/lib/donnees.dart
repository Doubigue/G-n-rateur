import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

/// Même base Firestore que le site (contenu public en lecture libre).
const projet = 'maison-b6a19';

/// Numéro WhatsApp des commandes, format international sans « + ».
/// Le site utilise 33600000000 (valeur d'exemple) : remplace-le par le vrai numéro.
const whatsapp = '33600000000';

const tauxXof = 655.957;

String _s(dynamic x) => x == null ? '' : '$x';
double _d(dynamic x) =>
    x is num ? x.toDouble() : (double.tryParse(_s(x).replaceAll(',', '.')) ?? 0);

dynamic _val(Map<String, dynamic> v) {
  if (v.containsKey('stringValue')) return v['stringValue'];
  if (v.containsKey('integerValue')) return int.tryParse('${v['integerValue']}') ?? 0;
  if (v.containsKey('doubleValue')) return double.tryParse('${v['doubleValue']}') ?? 0.0;
  if (v.containsKey('booleanValue')) return v['booleanValue'];
  if (v.containsKey('timestampValue')) return v['timestampValue'];
  if (v.containsKey('arrayValue')) {
    final l = (v['arrayValue']['values'] as List?) ?? [];
    return [for (final e in l) _val(e as Map<String, dynamic>)];
  }
  if (v.containsKey('mapValue')) {
    return _champs((v['mapValue']['fields'] as Map<String, dynamic>?) ?? {});
  }
  return null;
}

Map<String, dynamic> _champs(Map<String, dynamic> f) =>
    f.map((k, v) => MapEntry(k, _val(v as Map<String, dynamic>)));

Future<File> _cache(String nom) async =>
    File('${(await getApplicationDocumentsDirectory()).path}/cache_$nom.json');

/// Lit une collection Firestore (API REST). En cas d'échec, utilise la dernière copie enregistrée.
Future<List<Map<String, dynamic>>> collection(String nom) async {
  try {
    final out = <Map<String, dynamic>>[];
    String? page;
    do {
      final url = Uri.parse(
              'https://firestore.googleapis.com/v1/projects/$projet/databases/(default)/documents/$nom')
          .replace(queryParameters: {'pageSize': '300', if (page != null) 'pageToken': page});
      final r = await http.get(url).timeout(const Duration(seconds: 15));
      if (r.statusCode != 200) throw Exception('HTTP ${r.statusCode}');
      final j = jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
      for (final d in (j['documents'] as List?) ?? []) {
        final m = _champs((d['fields'] as Map<String, dynamic>?) ?? {});
        m['id'] = (d['name'] as String).split('/').last;
        m['_creation'] = d['createTime'];
        out.add(m);
      }
      page = j['nextPageToken'] as String?;
    } while (page != null);
    try {
      await (await _cache(nom)).writeAsString(jsonEncode(out));
    } catch (_) {}
    return out;
  } catch (e) {
    try {
      final f = await _cache(nom);
      if (await f.exists()) {
        return (jsonDecode(await f.readAsString()) as List).cast<Map<String, dynamic>>();
      }
    } catch (_) {}
    rethrow;
  }
}

String fcfa(int n) {
  final s = n.toString();
  final b = StringBuffer();
  for (var i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 == 0) b.write('\u202f');
    b.write(s[i]);
  }
  return '$b F CFA';
}

String dateFr(dynamic x) {
  final d = DateTime.tryParse(_s(x));
  if (d == null) return _s(x);
  return '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';
}

String texte(Map<String, dynamic> m, String cle) => _s(m[cle]);

class Livre {
  Livre(this.m);
  final Map<String, dynamic> m;

  String get id => _s(m['id']);
  String get titre => _s(m['title']);
  String get auteur => _s(m['author']);
  String get genre => _s(m['genre']);
  String get resume => _s(m['summary']);
  String get couverture => _s(m['cover']);
  String get statut => _s(m['status']);
  String get creation => _s(m['_creation']);
  bool get cache => m['hidden'] == true;
  bool get ebook => m['hasEbook'] == true;

  int get papier {
    final x = _d(m['priceXof']);
    return x > 0 ? x.round() : (_d(m['price']) * tauxXof).round();
  }

  int get numerique {
    final p = m['ebookPrice'];
    if (p == null || _s(p).isEmpty) return papier;
    return (_d(p) * tauxXof).round();
  }

  int prix(bool eb) => eb ? numerique : papier;
}

class Ligne {
  Ligne(this.id, this.titre, this.auteur, this.couv, this.ebook, this.unite, this.qte);
  final String id, titre, auteur, couv;
  final bool ebook;
  final int unite;
  int qte;

  Map<String, dynamic> toJson() => {
        'id': id, 'titre': titre, 'auteur': auteur, 'couv': couv,
        'ebook': ebook, 'unite': unite, 'qte': qte,
      };

  factory Ligne.fromJson(Map<String, dynamic> j) =>
      Ligne(j['id'], j['titre'], j['auteur'], j['couv'], j['ebook'], j['unite'], j['qte']);
}

class Etat extends ChangeNotifier {
  List<Livre> livres = [];
  List<Map<String, dynamic>> auteurs = [], actus = [];
  List<Ligne> panier = [];
  Session? session;
  List<Map<String, dynamic>> commandes = [], achats = [], annonces = [], faqs = [], avis = [], agences = [];
  bool chargement = true;
  String? erreur;

  int get total => panier.fold(0, (s, l) => s + l.unite * l.qte);
  int get nombre => panier.fold(0, (s, l) => s + l.qte);

  Future<void> init() async {
    await _lirePanier();
    await _lireSession();
    await charger();
    await chargerCompte();
  }

  Future<void> charger() async {
    chargement = true;
    erreur = null;
    notifyListeners();
    try {
      final r = await Future.wait([
        collection('books'), collection('authors'), collection('news'),
        _facultative('siteAnnouncements'), _facultative('faqs'), _facultative('testimonials'), _facultative('agencies'),
      ]);
      livres = r[0].map(Livre.new).where((l) => !l.cache && l.titre.isNotEmpty).toList()
        ..sort((a, b) => b.creation.compareTo(a.creation));
      auteurs = r[1].where((a) => _s(a['name']).isNotEmpty).toList();
      actus = r[2]..sort((a, b) => _s(b['date']).compareTo(_s(a['date'])));
      annonces = r[3];
      faqs = r[4];
      avis = r[5];
      agences = r[6];
    } catch (_) {
      erreur = 'Connexion impossible. Vérifie internet puis réessaie.';
    }
    chargement = false;
    notifyListeners();
  }

  void ajouter(Livre l, bool eb) {
    final i = panier.indexWhere((x) => x.id == l.id && x.ebook == eb);
    if (i >= 0) {
      if (!eb) panier[i].qte++;
    } else {
      panier.add(Ligne(l.id, l.titre, l.auteur, l.couverture, eb, l.prix(eb), 1));
    }
    _ecrire();
  }

  void changer(Ligne l, int delta) {
    l.qte += delta;
    if (l.qte <= 0) panier.remove(l);
    _ecrire();
  }

  void retirer(Ligne l) {
    panier.remove(l);
    _ecrire();
  }

  Future<List<Map<String, dynamic>>> _facultative(String n) =>
      collection(n).catchError((_) => <Map<String, dynamic>>[]);

  // ---------- Compte ----------
  Future<File> _fSession() async =>
      File('${(await getApplicationDocumentsDirectory()).path}/session.json');

  Future<void> _lireSession() async {
    try {
      final f = await _fSession();
      if (await f.exists()) session = Session.fromJson(jsonDecode(await f.readAsString()) as Map<String, dynamic>);
    } catch (_) {}
  }

  Future<void> _ecrireSession() async {
    try {
      final f = await _fSession();
      if (session == null) {
        if (await f.exists()) await f.delete();
      } else {
        await f.writeAsString(jsonEncode(session!.toJson()));
      }
    } catch (_) {}
  }

  Future<String> jeton() async {
    final s = session!;
    if (DateTime.now().isAfter(s.expire.subtract(const Duration(minutes: 2)))) {
      await rafraichir(s);
      await _ecrireSession();
    }
    return s.jeton;
  }

  Future<void> connexion(String email, String mdp) async {
    session = await authentifier('signInWithPassword', email, mdp);
    await _ecrireSession();
    notifyListeners();
    chargerCompte();
  }

  Future<void> inscription(String nom, String email, String mdp) async {
    final s = await authentifier('signUp', email, mdp);
    s.nom = nom;
    session = s;
    await _ecrireSession();
    try {
      await fusionner('users/${s.uid}', {
        'name': nom, 'email': email.toLowerCase(), 'role': 'reader', 'roles': ['reader'],
        'organization': '', 'createdAt': DateTime.now(),
      }, s.jeton);
    } catch (_) {}
    notifyListeners();
    chargerCompte();
  }

  Future<void> deconnexion() async {
    session = null;
    commandes = [];
    achats = [];
    await _ecrireSession();
    notifyListeners();
  }

  Future<void> chargerCompte() async {
    if (session == null) return;
    try {
      final t = await jeton(), u = session!.uid;
      commandes = await chercher('orders', 'uid', u, t);
      commandes.sort((a, b) => _d(b['date']).compareTo(_d(a['date'])));
      achats = await chercher('purchases', 'uid', u, t);
      final p = await lireDoc('users/$u', t);
      if (p != null && _s(p['name']).isNotEmpty) session!.nom = _s(p['name']);
    } catch (_) {}
    notifyListeners();
  }

  Future<Map<String, dynamic>> commander(Map<String, String> c, Map<String, dynamic> ag, bool livraison) async {
    final t = await jeton(), u = session!.uid, mail = session!.email.toLowerCase();
    final items = [
      for (final l in panier)
        {'id': l.id, 'format': l.ebook ? 'ebook' : 'paper', 'title': l.titre, 'author': l.auteur,
         'qty': l.ebook ? 1 : l.qte, 'unit': l.unite}
    ];
    final eb = panier.any((l) => l.ebook), pap = panier.any((l) => !l.ebook);
    final tot = panier.fold<int>(0, (s, l) => s + l.unite * (l.ebook ? 1 : l.qte));
    final digital = eb && !pap, liv = !digital && livraison;
    final r = Random();
    final code = List.generate(6, (_) => 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'[r.nextInt(32)]).join();
    final now = DateTime.now();
    final o = <String, dynamic>{
      'invoice': 'FAC-${now.year}-$code', 'date': now.millisecondsSinceEpoch,
      'name': c['nom'] ?? '', 'surname': c['prenom'] ?? '', 'phone': c['tel'] ?? '', 'email': mail,
      'mode': liv ? 'delivery' : 'pickup',
      'address': liv ? c['adresse'] ?? '' : '', 'city': liv ? c['ville'] ?? '' : '', 'country': liv ? c['pays'] ?? '' : '',
      'agencyId': _s(ag['id']), 'agencyName': _s(ag['name']), 'agencyAddress': _s(ag['address']),
      'agencyCity': _s(ag['city']), 'agencyPhone': _s(ag['phone']),
      'items': items, 'total': tot, 'totalLabel': fcfa(tot), 'currency': 'XOF',
      'hasEbook': eb, 'hasPaper': pap, 'digitalOnly': digital,
      'uid': u, 'status': 'pending', 'paymentMethod': 'cash', 'invoiceUrl': '', 'invoicePaidUrl': '',
      'history': [{'s': 'pending', 'at': now.millisecondsSinceEpoch, 'by': 'client'}],
      'createdAt': now,
    };
    await creerDoc('orders', o, t);
    final ou = digital
        ? "Règlement en espèces à l'agence : ${o['agencyName']}.\nMontant à régler : ${o['totalLabel']}.\n"
        : "${liv ? 'Livraison depuis' : 'Retrait à'} l'agence : ${o['agencyName']}.\nMontant à régler à la remise : ${o['totalLabel']}.\n";
    final texte = '🧾 Commande ${o['invoice']} enregistrée.\n$ou'
        '${eb ? 'Vos e-books seront débloqués dans « Ma bibliothèque » dès la confirmation du paiement.\n' : ''}'
        "Votre facture PDF vous sera transmise ici par l'éditeur.";
    try {
      await fusionner('threads/$u', {
        'name': '${c['nom'] ?? ''} ${c['prenom'] ?? ''}'.trim(), 'email': mail,
        'lastText': texte.substring(0, min(80, texte.length)), 'lastFrom': 'system', 'updatedAt': now,
      }, t);
      await creerDoc('threads/$u/messages', {
        'from': 'system', 'text': texte, 'kind': 'invoice', 'invoiceNo': o['invoice'], 'invoiceUrl': '', 'createdAt': now,
      }, t);
    } catch (_) {}
    panier = [];
    await _ecrire();
    await chargerCompte();
    return o;
  }

  Future<void> annulerCommande(Map<String, dynamic> o) async {
    final t = await jeton();
    final h = [
      ...((o['history'] as List?) ?? []),
      {'s': 'cancelled', 'at': DateTime.now().millisecondsSinceEpoch, 'by': 'client'},
    ];
    await fusionner('orders/${o['id']}', {'status': 'cancelled', 'history': h}, t);
    await chargerCompte();
  }

  Future<List<Map<String, dynamic>>> messages() async =>
      lireListe('threads/${session!.uid}/messages', await jeton(), ordre: 'createdAt');

  Future<void> envoyer(String texte) async {
    final t = await jeton(), u = session!.uid, now = DateTime.now();
    await fusionner('threads/$u', {
      'name': session!.nom ?? session!.email, 'email': session!.email.toLowerCase(),
      'lastText': texte.substring(0, min(80, texte.length)), 'lastFrom': 'author', 'updatedAt': now,
    }, t);
    await creerDoc('threads/$u/messages', {'from': 'author', 'text': texte, 'createdAt': now}, t);
  }

  Future<Map<String, dynamic>?> metaEbook(String id) async => lireDoc('ebooks/$id', await jeton());

  Future<Map<String, dynamic>?> chapitre(String id, int n) async =>
      lireDoc('ebooks/$id/chapters/${n.toString().padLeft(4, '0')}', await jeton());

  Future<Map<String, dynamic>?> progression(String id) async =>
      lireDoc('readingProgress/${session!.uid}_$id', await jeton());

  Future<void> sauverProgression(String id, Map<String, dynamic> d) async => fusionner(
      'readingProgress/${session!.uid}_$id',
      {'uid': session!.uid, 'bookId': id, ...d, 'updatedAt': DateTime.now()},
      await jeton());

  String get messageCommande {
    final lignes = panier
        .map((l) => '- ${l.qte} × ${l.titre} (${l.ebook ? 'E-book' : 'Livre papier'}) : ${fcfa(l.unite * l.qte)}')
        .join('\n');
    return 'Bonjour, je souhaite commander :\n$lignes\nTotal : ${fcfa(total)}';
  }

  Future<File> _fichier() async =>
      File('${(await getApplicationDocumentsDirectory()).path}/panier.json');

  Future<void> _ecrire() async {
    notifyListeners();
    try {
      await (await _fichier()).writeAsString(jsonEncode(panier.map((l) => l.toJson()).toList()));
    } catch (_) {}
  }

  Future<void> _lirePanier() async {
    try {
      final f = await _fichier();
      if (await f.exists()) {
        panier = (jsonDecode(await f.readAsString()) as List)
            .map((j) => Ligne.fromJson(j as Map<String, dynamic>))
            .toList();
      }
    } catch (_) {}
  }
}

// ====================== Écriture, session, comptes (API REST) ======================
const cleApi = 'AIzaSyBJPG2thg1E10BeqFL163KcpgSSyjJacqA';
const siteUrl = 'https://editions.loubikoa.online/';
const _base = 'https://firestore.googleapis.com/v1/projects/$projet/databases/(default)/documents';

dynamic enc(dynamic v) {
  if (v == null) return {'nullValue': null};
  if (v is bool) return {'booleanValue': v};
  if (v is int) return {'integerValue': '$v'};
  if (v is double) return {'doubleValue': v};
  if (v is DateTime) return {'timestampValue': v.toUtc().toIso8601String()};
  if (v is List) return {'arrayValue': {'values': v.map(enc).toList()}};
  if (v is Map) return {'mapValue': {'fields': v.map((k, x) => MapEntry('$k', enc(x)))}};
  return {'stringValue': '$v'};
}

Map<String, dynamic> encChamps(Map<String, dynamic> m) => m.map((k, v) => MapEntry(k, enc(v)));

Map<String, dynamic> _doc(dynamic d) {
  final m = _champs((d['fields'] as Map<String, dynamic>?) ?? {});
  m['id'] = (d['name'] as String).split('/').last;
  m['_creation'] = d['createTime'];
  return m;
}

Future<dynamic> _rest(String methode, String url, {String? token, Object? corps}) async {
  final req = http.Request(methode, Uri.parse(url))
    ..headers['Content-Type'] = 'application/json'
    ..headers.addAll({if (token != null) 'Authorization': 'Bearer $token'});
  if (corps != null) req.body = jsonEncode(corps);
  final r = await http.Response.fromStream(await req.send().timeout(const Duration(seconds: 20)));
  final j = r.body.isEmpty ? null : jsonDecode(utf8.decode(r.bodyBytes));
  if (r.statusCode >= 300) {
    throw Exception(j is Map && j['error'] is Map ? '${j['error']['message']}' : 'HTTP ${r.statusCode}');
  }
  return j;
}

Future<Map<String, dynamic>?> lireDoc(String chemin, String token) async {
  try {
    return _doc(await _rest('GET', '$_base/$chemin', token: token));
  } catch (_) {
    return null;
  }
}

Future<List<Map<String, dynamic>>> lireListe(String chemin, String token, {String? ordre}) async {
  final j = await _rest('GET', '$_base/$chemin?pageSize=300${ordre != null ? '&orderBy=$ordre' : ''}', token: token);
  return [for (final d in (j['documents'] as List?) ?? []) _doc(d)];
}

Future<List<Map<String, dynamic>>> chercher(String col, String champ, String val, String token) async {
  final j = await _rest('POST', '$_base:runQuery', token: token, corps: {
    'structuredQuery': {
      'from': [{'collectionId': col}],
      'where': {
        'fieldFilter': {'field': {'fieldPath': champ}, 'op': 'EQUAL', 'value': {'stringValue': val}}
      }
    }
  });
  return [for (final r in (j as List)) if (r['document'] != null) _doc(r['document'])];
}

Future<void> creerDoc(String col, Map<String, dynamic> data, String token) =>
    _rest('POST', '$_base/$col', token: token, corps: {'fields': encChamps(data)});

Future<void> fusionner(String chemin, Map<String, dynamic> data, String token) {
  final masque = data.keys.map((k) => 'updateMask.fieldPaths=${Uri.encodeComponent(k)}').join('&');
  return _rest('PATCH', '$_base/$chemin?$masque', token: token, corps: {'fields': encChamps(data)});
}

class Session {
  Session(this.uid, this.email, this.jeton, this.refresh, this.expire, [this.nom]);
  final String uid, email;
  String jeton, refresh;
  DateTime expire;
  String? nom;

  Map<String, dynamic> toJson() => {
        'uid': uid, 'email': email, 'jeton': jeton, 'refresh': refresh,
        'expire': expire.toIso8601String(), 'nom': nom,
      };

  factory Session.fromJson(Map<String, dynamic> j) =>
      Session(j['uid'], j['email'], j['jeton'], j['refresh'], DateTime.parse(j['expire']), j['nom']);
}

String _erreurAuth(String c) {
  if (c.contains('INVALID_LOGIN_CREDENTIALS') || c.contains('INVALID_PASSWORD') || c.contains('EMAIL_NOT_FOUND')) {
    return 'E-mail ou mot de passe incorrect.';
  }
  if (c.contains('EMAIL_EXISTS')) return 'Un compte existe déjà avec cet e-mail.';
  if (c.contains('WEAK_PASSWORD')) return 'Mot de passe trop court (6 caractères minimum).';
  if (c.contains('INVALID_EMAIL')) return 'Adresse e-mail invalide.';
  if (c.contains('TOO_MANY_ATTEMPTS')) return 'Trop de tentatives, réessaie plus tard.';
  return 'Connexion impossible ($c).';
}

Future<Session> authentifier(String action, String email, String mdp) async {
  final http.Response r;
  try {
    r = await http
        .post(Uri.parse('https://identitytoolkit.googleapis.com/v1/accounts:$action?key=$cleApi'),
            headers: {'Content-Type': 'application/json', 'Referer': siteUrl},
            body: jsonEncode({'email': email, 'password': mdp, 'returnSecureToken': true}))
        .timeout(const Duration(seconds: 20));
  } catch (_) {
    throw Exception('Pas de connexion internet.');
  }
  final j = jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
  if (r.statusCode != 200) throw Exception(_erreurAuth('${(j['error'] as Map?)?['message'] ?? r.statusCode}'));
  return Session(j['localId'], j['email'], j['idToken'], j['refreshToken'],
      DateTime.now().add(Duration(seconds: int.tryParse('${j['expiresIn']}') ?? 3600)));
}

Future<void> rafraichir(Session s) async {
  final r = await http.post(Uri.parse('https://securetoken.googleapis.com/v1/token?key=$cleApi'),
      headers: {'Referer': siteUrl}, body: {'grant_type': 'refresh_token', 'refresh_token': s.refresh});
  final j = jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;
  if (r.statusCode != 200) throw Exception('Session expirée, reconnecte-toi.');
  s.jeton = j['id_token'];
  s.refresh = j['refresh_token'];
  s.expire = DateTime.now().add(Duration(seconds: int.tryParse('${j['expires_in']}') ?? 3600));
}

int entier(dynamic x) => x is num ? x.round() : int.tryParse('$x') ?? 0;
