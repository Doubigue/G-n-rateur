import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'donnees.dart';
import 'main.dart';

const statuts = {
  'pending': 'En attente de paiement', 'paid': 'Payée', 'delivered': 'Remise / livrée', 'cancelled': 'Annulée',
};
const modes = {'pickup': 'Retrait en agence', 'delivery': 'Livraison', 'digital': 'E-book (numérique)'};

InputDecoration champ(String l, {IconData? icone}) => InputDecoration(
      labelText: l,
      prefixIcon: icone == null ? null : Icon(icone),
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
    );

void ouvrir(BuildContext c, Widget p) => Navigator.push(c, MaterialPageRoute(builder: (_) => p));

String dateMs(dynamic ms) =>
    dateFr(DateTime.fromMillisecondsSinceEpoch(ms is num ? ms.toInt() : 0).toIso8601String());

// ====================== Compte ======================
class PageCompte extends StatefulWidget {
  const PageCompte({super.key});
  @override
  State<PageCompte> createState() => _PageCompteState();
}

class _PageCompteState extends State<PageCompte> {
  final _nom = TextEditingController(), _mail = TextEditingController(), _mdp = TextEditingController();
  bool _inscrire = false, _occupe = false;
  String? _err;

  Future<void> _valider() async {
    setState(() {
      _occupe = true;
      _err = null;
    });
    try {
      if (_inscrire) {
        await etat.inscription(_nom.text.trim(), _mail.text.trim(), _mdp.text);
      } else {
        await etat.connexion(_mail.text.trim(), _mdp.text);
      }
    } catch (e) {
      _err = '$e'.replaceFirst('Exception: ', '');
    }
    if (mounted) setState(() => _occupe = false);
  }

  @override
  Widget build(BuildContext context) {
    final s = etat.session;
    if (s != null) {
      return ListView(padding: const EdgeInsets.all(16), children: [
        ListTile(
          leading: CircleAvatar(backgroundColor: vert, child: Text((s.nom ?? s.email)[0].toUpperCase(), style: const TextStyle(color: or))),
          title: Text(s.nom ?? s.email, style: const TextStyle(fontFamily: 'serif', fontSize: 20)),
          subtitle: Text(s.email),
        ),
        const Divider(),
        ListTile(leading: const Icon(Icons.receipt_long), title: const Text('Mes achats'), trailing: const Icon(Icons.chevron_right), onTap: () => ouvrir(context, const PageAchats())),
        ListTile(leading: const Icon(Icons.local_library), title: const Text('Ma bibliothèque'), trailing: const Icon(Icons.chevron_right), onTap: () => ouvrir(context, const PageBibliotheque())),
        ListTile(leading: const Icon(Icons.forum_outlined), title: const Text('Messagerie'), trailing: const Icon(Icons.chevron_right), onTap: () => ouvrir(context, const PageMessages())),
        const Divider(),
        ListTile(leading: const Icon(Icons.logout), title: const Text('Se déconnecter'), onTap: etat.deconnexion),
      ]);
    }
    return ListView(padding: const EdgeInsets.all(20), children: [
      Text(_inscrire ? 'Créer un compte' : 'Connexion', style: const TextStyle(fontFamily: 'serif', fontSize: 26, color: encre)),
      const SizedBox(height: 4),
      const Text('Un compte est nécessaire pour commander, lire tes e-books et écrire à l\'éditeur.', style: TextStyle(color: Colors.black54)),
      const SizedBox(height: 18),
      if (_inscrire) ...[
        TextField(controller: _nom, decoration: champ('Nom complet', icone: Icons.person_outline)),
        const SizedBox(height: 12),
      ],
      TextField(controller: _mail, keyboardType: TextInputType.emailAddress, autocorrect: false, decoration: champ('E-mail', icone: Icons.mail_outline)),
      const SizedBox(height: 12),
      TextField(controller: _mdp, obscureText: true, decoration: champ('Mot de passe', icone: Icons.lock_outline)),
      if (_err != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(_err!, style: const TextStyle(color: Colors.red))),
      const SizedBox(height: 18),
      FilledButton(
        style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52)),
        onPressed: _occupe ? null : _valider,
        child: _occupe
            ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
            : Text(_inscrire ? 'Créer mon compte' : 'Se connecter'),
      ),
      TextButton(
        onPressed: () => setState(() {
          _inscrire = !_inscrire;
          _err = null;
        }),
        child: Text(_inscrire ? 'J\'ai déjà un compte' : 'Pas de compte ? Créer un compte'),
      ),
    ]);
  }
}

// ====================== Commande ======================
class PageCommande extends StatefulWidget {
  const PageCommande({super.key});
  @override
  State<PageCommande> createState() => _PageCommandeState();
}

class _PageCommandeState extends State<PageCommande> {
  final _cle = GlobalKey<FormState>();
  final _c = {for (final k in ['prenom', 'nom', 'tel', 'adresse', 'ville', 'pays']) k: TextEditingController()};
  bool _livraison = false, _occupe = false;
  String? _ag, _err;

  Future<void> _envoyer() async {
    if (!_cle.currentState!.validate()) return;
    final ag = etat.agences.where((a) => texte(a, 'id') == _ag).toList();
    if (ag.isEmpty) {
      setState(() => _err = "Choisis l'agence de retrait ou de livraison.");
      return;
    }
    setState(() {
      _occupe = true;
      _err = null;
    });
    try {
      final o = await etat.commander({for (final e in _c.entries) e.key: e.value.text.trim()}, ag.first, _livraison);
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => Confirmation(o)));
    } catch (e) {
      setState(() {
        _occupe = false;
        _err = 'Commande impossible : ${'$e'.replaceFirst('Exception: ', '')}';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final digital = etat.panier.every((l) => l.ebook);
    return Scaffold(
      appBar: AppBar(title: const Text('Finaliser la commande')),
      body: etat.session == null
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(32),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Text('Connecte-toi pour finaliser ton achat.', textAlign: TextAlign.center),
                  const SizedBox(height: 14),
                  FilledButton(
                    onPressed: () {
                      onglet.value = 4;
                      Navigator.pop(context);
                    },
                    child: const Text('Aller à la connexion'),
                  ),
                ]),
              ),
            )
          : Form(
              key: _cle,
              child: ListView(padding: const EdgeInsets.all(16), children: [
                Row(children: [
                  Expanded(child: _champ('prenom', 'Prénom')),
                  const SizedBox(width: 10),
                  Expanded(child: _champ('nom', 'Nom')),
                ]),
                const SizedBox(height: 12),
                _champ('tel', 'Téléphone', type: TextInputType.phone),
                if (!digital) ...[
                  const SizedBox(height: 14),
                  SegmentedButton<bool>(
                    segments: const [
                      ButtonSegment(value: false, label: Text('Retrait'), icon: Icon(Icons.store)),
                      ButtonSegment(value: true, label: Text('Livraison'), icon: Icon(Icons.local_shipping)),
                    ],
                    selected: {_livraison},
                    onSelectionChanged: (s) => setState(() => _livraison = s.first),
                  ),
                  if (_livraison) ...[
                    const SizedBox(height: 12),
                    _champ('adresse', 'Adresse de livraison'),
                    const SizedBox(height: 12),
                    Row(children: [
                      Expanded(child: _champ('ville', 'Ville')),
                      const SizedBox(width: 10),
                      Expanded(child: _champ('pays', 'Pays')),
                    ]),
                  ],
                ],
                const SizedBox(height: 18),
                Text(digital ? 'Agence de règlement' : (_livraison ? 'Agence de livraison' : 'Agence de retrait'),
                    style: const TextStyle(fontFamily: 'serif', fontSize: 18)),
                for (final a in etat.agences)
                  Card(
                    color: _ag == texte(a, 'id') ? const Color(0x33D4AF37) : Colors.white,
                    elevation: 0,
                    child: ListTile(
                      onTap: () => setState(() => _ag = texte(a, 'id')),
                      leading: Icon(_ag == texte(a, 'id') ? Icons.radio_button_checked : Icons.radio_button_off, color: vert),
                      title: Text(texte(a, 'name')),
                      subtitle: Text([texte(a, 'address'), texte(a, 'city')].where((x) => x.isNotEmpty).join(', ')),
                    ),
                  ),
                if (etat.agences.isEmpty) const Padding(padding: EdgeInsets.all(8), child: Text("Aucune agence n'est disponible pour le moment.")),
                const SizedBox(height: 12),
                Text('Paiement à la remise, en espèces. Total : ${fcfa(etat.total)}', style: const TextStyle(fontWeight: FontWeight.w600)),
                if (_err != null) Padding(padding: const EdgeInsets.only(top: 10), child: Text(_err!, style: const TextStyle(color: Colors.red))),
                const SizedBox(height: 14),
                FilledButton(
                  style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(52)),
                  onPressed: _occupe ? null : _envoyer,
                  child: _occupe
                      ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                      : const Text('Confirmer la commande'),
                ),
              ]),
            ),
    );
  }

  Widget _champ(String k, String l, {TextInputType? type}) => TextFormField(
        controller: _c[k],
        keyboardType: type,
        decoration: champ(l),
        validator: (v) => (v == null || v.trim().isEmpty) ? 'Requis' : null,
      );
}

class Confirmation extends StatelessWidget {
  const Confirmation(this.o, {super.key});
  final Map<String, dynamic> o;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Commande enregistrée')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          const Icon(Icons.check_circle, size: 72, color: vert2),
          const SizedBox(height: 14),
          Text('${o['invoice']}', style: const TextStyle(fontFamily: 'serif', fontSize: 24)),
          const SizedBox(height: 10),
          Text(
            'Règle ${o['totalLabel']} à l\'agence ${o['agencyName']}.'
            '${o['hasEbook'] == true ? '\nTes e-books seront débloqués dans « Ma bibliothèque » dès la confirmation du paiement.' : ''}'
            '\nTa facture t\'est transmise dans la messagerie.',
            textAlign: TextAlign.center,
            style: const TextStyle(height: 1.5),
          ),
          const SizedBox(height: 24),
          FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Terminer')),
        ]),
      ),
    );
  }
}

// ====================== Mes achats ======================
class PageAchats extends StatefulWidget {
  const PageAchats({super.key});
  @override
  State<PageAchats> createState() => _PageAchatsState();
}

class _PageAchatsState extends State<PageAchats> {
  @override
  void initState() {
    super.initState();
    etat.chargerCompte();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mes achats')),
      body: ListenableBuilder(
        listenable: etat,
        builder: (context, _) => etat.commandes.isEmpty
            ? const Center(child: Text('Aucun achat pour le moment.'))
            : ListView(padding: const EdgeInsets.all(16), children: [
                for (final o in etat.commandes)
                  Card(
                    color: Colors.white,
                    elevation: 0,
                    child: ListTile(
                      title: Text('${o['invoice']}', style: const TextStyle(fontWeight: FontWeight.w600)),
                      subtitle: Text('${dateMs(o['date'])} · ${statuts[o['status']] ?? o['status']}'),
                      trailing: Text(fcfa(entier(o['total'])), style: const TextStyle(color: vert2, fontWeight: FontWeight.w600)),
                      onTap: () => ouvrir(context, DetailCommande(o)),
                    ),
                  ),
              ]),
      ),
    );
  }
}

class DetailCommande extends StatelessWidget {
  const DetailCommande(this.o, {super.key});
  final Map<String, dynamic> o;

  @override
  Widget build(BuildContext context) {
    final items = ((o['items'] as List?) ?? []).cast<Map>();
    return Scaffold(
      appBar: AppBar(title: Text('${o['invoice']}')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Wrap(spacing: 8, children: [
          Chip(label: Text(statuts[o['status']] ?? '${o['status']}')),
          Chip(label: Text(modes[o['mode']] ?? '${o['mode']}')),
        ]),
        const SizedBox(height: 8),
        Text('Passée le ${dateMs(o['date'])}'),
        Text("Agence : ${o['agencyName']}${texte(o, 'agencyCity').isEmpty ? '' : ', ${o['agencyCity']}'}"),
        if (o['mode'] == 'delivery') Text('Livraison : ${o['address']}, ${o['city']}'),
        const Divider(height: 28),
        for (final it in items)
          ListTile(
            contentPadding: EdgeInsets.zero,
            title: Text('${it['qty']} × ${it['title']}'),
            subtitle: Text(it['format'] == 'ebook' ? 'E-book' : 'Livre papier'),
            trailing: Text(fcfa(entier(it['unit']) * entier(it['qty']))),
          ),
        const Divider(height: 28),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          const Text('Total', style: TextStyle(fontSize: 18)),
          Text(fcfa(entier(o['total'])), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: vert)),
        ]),
        if (o['status'] == 'pending') ...[
          const SizedBox(height: 20),
          OutlinedButton(
            onPressed: () async {
              await etat.annulerCommande(o);
              if (context.mounted) Navigator.pop(context);
            },
            child: const Text('Annuler cette commande'),
          ),
        ],
      ]),
    );
  }
}

// ====================== Bibliothèque ======================
class PageBibliotheque extends StatelessWidget {
  const PageBibliotheque({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Ma bibliothèque')),
      body: ListenableBuilder(
        listenable: etat,
        builder: (context, _) => etat.achats.isEmpty
            ? const Center(
                child: Padding(
                  padding: EdgeInsets.all(32),
                  child: Text('Aucun e-book débloqué. Il l\'est dès que l\'agence confirme ton paiement.', textAlign: TextAlign.center),
                ),
              )
            : ListView(padding: const EdgeInsets.all(16), children: [
                for (final p in etat.achats)
                  Card(
                    color: Colors.white,
                    elevation: 0,
                    child: ListTile(
                      leading: const Icon(Icons.auto_stories, color: vert),
                      title: Text(texte(p, 'bookTitle').isEmpty ? texte(p, 'bookId') : texte(p, 'bookTitle'), style: const TextStyle(fontFamily: 'serif', fontSize: 18)),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () => ouvrir(context, Liseuse(texte(p, 'bookId'), texte(p, 'bookTitle'))),
                    ),
                  ),
              ]),
      ),
    );
  }
}

// ====================== Messagerie ======================
class PageMessages extends StatefulWidget {
  const PageMessages({super.key});
  @override
  State<PageMessages> createState() => _PageMessagesState();
}

class _PageMessagesState extends State<PageMessages> {
  List<Map<String, dynamic>> _l = [];
  bool _charge = true;
  final _c = TextEditingController();
  Timer? _t;

  @override
  void initState() {
    super.initState();
    _maj();
    _t = Timer.periodic(const Duration(seconds: 10), (_) => _maj());
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  Future<void> _maj() async {
    try {
      final l = await etat.messages();
      if (mounted) setState(() {
        _l = l;
        _charge = false;
      });
    } catch (_) {
      if (mounted) setState(() => _charge = false);
    }
  }

  Future<void> _envoyer() async {
    final t = _c.text.trim();
    if (t.isEmpty) return;
    _c.clear();
    try {
      await etat.envoyer(t);
    } catch (_) {}
    _maj();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Messagerie')),
      body: Column(children: [
        Expanded(
          child: _charge
              ? const Center(child: CircularProgressIndicator())
              : _l.isEmpty
                  ? const Center(child: Text('Aucun message. Écris à l\'éditeur ci-dessous.'))
                  : ListView(padding: const EdgeInsets.all(12), children: [
                      for (final m in _l)
                        Align(
                          alignment: m['from'] == 'author' ? Alignment.centerRight : Alignment.centerLeft,
                          child: Container(
                            constraints: const BoxConstraints(maxWidth: 290),
                            margin: const EdgeInsets.symmetric(vertical: 4),
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: m['from'] == 'author' ? vert : (m['from'] == 'system' ? const Color(0x33D4AF37) : Colors.white),
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: Text(texte(m, 'text'), style: TextStyle(height: 1.4, color: m['from'] == 'author' ? creme : encre)),
                          ),
                        ),
                    ]),
        ),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 4, 12, 8),
            child: Row(children: [
              Expanded(child: TextField(controller: _c, minLines: 1, maxLines: 4, decoration: champ('Ton message'))),
              IconButton(onPressed: _envoyer, icon: const Icon(Icons.send, color: vert)),
            ]),
          ),
        ),
      ]),
    );
  }
}

// ====================== Liseuse (écran protégé contre les captures) ======================
class Liseuse extends StatefulWidget {
  const Liseuse(this.id, this.titre, {super.key});
  final String id, titre;
  @override
  State<Liseuse> createState() => _LiseuseState();
}

class _LiseuseState extends State<Liseuse> with WidgetsBindingObserver {
  static const _canal = MethodChannel('baobab/secure');
  final _cle = GlobalKey<ScaffoldState>();
  Map<String, dynamic>? _meta;
  int _ch = 0, _page = 0;
  double _taille = 18;
  String _texte = '';
  List<String> _pages = [''];
  PageController _pc = PageController();
  bool _charge = true, _masque = false;
  String? _err;
  Timer? _t;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _secure(true);
    _ouvrir();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _secure(false);
    _t?.cancel();
    _pc.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) => setState(() => _masque = s != AppLifecycleState.resumed);

  Future<void> _secure(bool on) async {
    try {
      await _canal.invokeMethod(on ? 'on' : 'off');
    } catch (_) {}
  }

  Future<void> _ouvrir() async {
    final m = await etat.metaEbook(widget.id);
    if (m == null) {
      if (mounted) setState(() {
        _err = "Ce livre n'est pas (ou pas encore) disponible en lecture.";
        _charge = false;
      });
      return;
    }
    _meta = m;
    final p = await etat.progression(widget.id);
    final n = (m['count'] as num?)?.toInt() ?? 1;
    final ch = ((p?['chapter'] as num?)?.toInt() ?? 0).clamp(0, n - 1).toInt();
    await _aller(ch, page: (p?['page'] as num?)?.toInt() ?? 0);
  }

  Future<void> _aller(int ch, {int page = 0}) async {
    setState(() => _charge = true);
    final c = await etat.chapitre(widget.id, ch);
    if (!mounted) return;
    _ch = ch;
    _texte = c == null ? '' : '${c['text'] ?? ''}';
    _decouper(page);
    setState(() => _charge = false);
    _sauver();
  }

  void _decouper(int page, {double? frac}) {
    final cible = (226800 / (_taille * _taille)).round();
    final out = <String>[];
    var buf = '';
    for (var p in _texte.split(RegExp(r'\n+'))) {
      p = p.trim();
      if (p.isEmpty) continue;
      while (p.length > cible) {
        var i = p.lastIndexOf(' ', cible);
        if (i < cible ~/ 2) i = cible;
        if (buf.isNotEmpty) {
          out.add(buf);
          buf = '';
        }
        out.add(p.substring(0, i));
        p = p.substring(i).trim();
      }
      if (buf.isNotEmpty && buf.length + p.length > cible) {
        out.add(buf);
        buf = '';
      }
      buf = buf.isEmpty ? p : '$buf\n\n$p';
    }
    if (buf.isNotEmpty) out.add(buf);
    if (out.isEmpty) out.add('(chapitre vide)');
    _pages = out;
    _page = (frac != null ? (frac * out.length).floor() : page).clamp(0, out.length - 1).toInt();
    final ancien = _pc;
    WidgetsBinding.instance.addPostFrameCallback((_) => ancien.dispose());
    _pc = PageController(initialPage: _page);
  }

  void _changerTaille(double d) {
    final frac = _page / _pages.length;
    setState(() {
      _taille = (_taille + d).clamp(14.0, 30.0).toDouble();
      _decouper(0, frac: frac);
    });
  }

  void _sauver() {
    _t?.cancel();
    _t = Timer(const Duration(milliseconds: 1200), () {
      final m = _meta;
      if (m == null) return;
      final n = (m['count'] as num?)?.toInt() ?? 1;
      final toc = (m['toc'] as List?) ?? [];
      etat.sauverProgression(widget.id, {
        'chapter': _ch, 'page': _page, 'pages': _pages.length, 'frac': _page / _pages.length,
        'chapterTitle': _ch < toc.length ? '${toc[_ch]}' : '', 'totalChapters': n,
        'percent': (((_ch + (_page + 1) / _pages.length) / n) * 100).round(),
        'at': DateTime.now().millisecondsSinceEpoch,
      }).catchError((_) {});
    });
  }

  @override
  Widget build(BuildContext context) {
    final toc = ((_meta?['toc'] as List?) ?? []).map((e) => '$e').toList();
    final n = (_meta?['count'] as num?)?.toInt() ?? 1;
    return Scaffold(
      key: _cle,
      backgroundColor: const Color(0xFFFFFBF2),
      appBar: AppBar(
        title: Text(widget.titre, overflow: TextOverflow.ellipsis),
        actions: [
          IconButton(icon: const Icon(Icons.text_decrease), onPressed: _meta == null ? null : () => _changerTaille(-2)),
          IconButton(icon: const Icon(Icons.text_increase), onPressed: _meta == null ? null : () => _changerTaille(2)),
          IconButton(icon: const Icon(Icons.list), onPressed: _meta == null ? null : () => _cle.currentState?.openEndDrawer()),
        ],
      ),
      endDrawer: Drawer(
        child: SafeArea(
          child: ListView(children: [
            const ListTile(title: Text('Sommaire', style: TextStyle(fontFamily: 'serif', fontSize: 20))),
            for (var i = 0; i < toc.length; i++)
              ListTile(
                selected: i == _ch,
                title: Text(toc[i]),
                onTap: () {
                  Navigator.pop(context);
                  _aller(i);
                },
              ),
          ]),
        ),
      ),
      body: _masque
          ? Container(color: vert)
          : _err != null
              ? Center(child: Padding(padding: const EdgeInsets.all(32), child: Text(_err!, textAlign: TextAlign.center)))
              : _charge
                  ? const Center(child: CircularProgressIndicator())
                  : Stack(children: [
                      Column(children: [
                        Padding(
                          padding: const EdgeInsets.fromLTRB(24, 12, 24, 0),
                          child: Text(_ch < toc.length ? toc[_ch] : '', style: const TextStyle(color: Colors.black45, fontSize: 13)),
                        ),
                        Expanded(
                          child: PageView.builder(
                            key: ValueKey(_pc),
                            controller: _pc,
                            itemCount: _pages.length,
                            onPageChanged: (p) {
                              setState(() => _page = p);
                              _sauver();
                            },
                            itemBuilder: (_, i) => SingleChildScrollView(
                              padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
                              child: Text(_pages[i], style: TextStyle(fontFamily: 'serif', fontSize: _taille, height: 1.7, color: encre)),
                            ),
                          ),
                        ),
                        SafeArea(
                          top: false,
                          child: Row(children: [
                            IconButton(icon: const Icon(Icons.chevron_left), onPressed: _ch > 0 ? () => _aller(_ch - 1) : null),
                            Expanded(
                              child: Text('Chapitre ${_ch + 1}/$n · page ${_page + 1}/${_pages.length}',
                                  textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, color: Colors.black54)),
                            ),
                            IconButton(icon: const Icon(Icons.chevron_right), onPressed: _ch < n - 1 ? () => _aller(_ch + 1) : null),
                          ]),
                        ),
                      ]),
                      Positioned.fill(
                        child: IgnorePointer(
                          child: Opacity(
                            opacity: 0.06,
                            child: Transform.rotate(
                              angle: -0.5,
                              child: Column(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                                for (var i = 0; i < 9; i++)
                                  Text('${etat.session?.email ?? ''}   ' * 3,
                                      maxLines: 1, softWrap: false, overflow: TextOverflow.clip,
                                      style: const TextStyle(fontSize: 16, color: Colors.black)),
                              ]),
                            ),
                          ),
                        ),
                      ),
                    ]),
    );
  }
}
