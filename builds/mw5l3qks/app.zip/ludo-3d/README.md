# Ludo 3D (Three.js + Vite)

Jeu de Ludo 3D pour 1 à 4 joueurs, avec IA. Plateau pivotable à la souris ou au doigt.

## Règles
- Il faut un 6 pour sortir un pion de la base.
- Un 6, une capture ou un pion arrivé donnent un nouveau lancer.
- Capture : tomber sur un pion adverse le renvoie à sa base, sauf sur les cases de départ et les étoiles.
- Il faut le nombre exact pour entrer au centre. Le premier à ramener ses 4 pions gagne.

## Lancer en local
    npm install
    npm run dev

## Compiler avec GitHub Actions
1. Poussez ce dossier sur la branche `main` d’un dépôt GitHub.
2. Dans Settings > Pages, choisissez Source : GitHub Actions.
3. Le workflow `.github/workflows/build.yml` compile le jeu, le publie sur GitHub Pages et garde le dossier `dist` en artefact téléchargeable.
