import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import './style.css';

/* ---------- Données du plateau (grille 15x15) ---------- */
const NAMES = ['Rouge', 'Vert', 'Jaune', 'Bleu'];
const HEX = [0xe53935, 0x43a047, 0xfbc02d, 0x1e88e5];
const CSSC = ['#e53935', '#43a047', '#fbc02d', '#1e88e5'];
const STARTS = [0, 13, 26, 39];               // case de départ de chaque couleur sur le circuit
const SAFE = new Set([0, 8, 13, 21, 26, 34, 39, 47]);
const DIRS = [[-1, 0], [0, -1], [1, 0], [0, 1]];
const BASES = [[0, 0], [9, 0], [9, 9], [0, 9]];
const FACES = '⚀⚁⚂⚃⚄⚅';
const G = 0.14;                               // hauteur du sol des pions

const line = (x0, y0, x1, y1) => {
  const dx = Math.sign(x1 - x0), dy = Math.sign(y1 - y0);
  const n = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0));
  return Array.from({ length: n + 1 }, (_, i) => [x0 + dx * i, y0 + dy * i]);
};
const TRACK = [
  ...line(1, 6, 5, 6), ...line(6, 5, 6, 0), [7, 0], [8, 0], ...line(8, 1, 8, 5),
  ...line(9, 6, 14, 6), [14, 7], [14, 8], ...line(13, 8, 9, 8), ...line(8, 9, 8, 14),
  [7, 14], [6, 14], ...line(6, 13, 6, 9), ...line(5, 8, 0, 8), [0, 7], [0, 6]
];
const HOME = [line(1, 7, 5, 7), line(7, 1, 7, 5), line(13, 7, 9, 7), line(7, 13, 7, 9)];

const W = (x, y, h = G) => new THREE.Vector3(x - 7, h, y - 7);

// rel : -1 = base, 0..50 = circuit, 51..55 = couloir final, 56 = arrivée
function cellPos(c, rel, i) {
  if (rel < 0) { const [bx, by] = BASES[c]; return W(bx + (i % 2 ? 3.5 : 1.5), by + (i < 2 ? 1.5 : 3.5)); }
  if (rel <= 50) { const [x, y] = TRACK[(STARTS[c] + rel) % 52]; return W(x, y); }
  if (rel <= 55) { const [x, y] = HOME[c][rel - 51]; return W(x, y); }
  const d = DIRS[c];
  return W(7 + d[0] * 0.9 - d[1] * (i - 1.5) * 0.3, 7 + d[1] * 0.9 + d[0] * (i - 1.5) * 0.3);
}

/* ---------- Scène ---------- */
const canvas = document.getElementById('c');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.shadowMap.enabled = true;
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x14213d);
const camera = new THREE.PerspectiveCamera(45, 1, 0.1, 150);
camera.position.set(0, 17, 12);
const controls = new OrbitControls(camera, canvas);
controls.enablePan = false;
controls.enableDamping = true;
controls.maxPolarAngle = 1.3;
controls.minDistance = 8;
controls.maxDistance = 70;

scene.add(new THREE.HemisphereLight(0xffffff, 0x445577, 1.1));
const sun = new THREE.DirectionalLight(0xffffff, 1.6);
sun.position.set(6, 14, 8);
sun.castShadow = true;
sun.shadow.mapSize.set(1024, 1024);
Object.assign(sun.shadow.camera, { left: -11, right: 11, top: 11, bottom: -11 });
scene.add(sun);

function resize() {
  const w = innerWidth, h = innerHeight, aspect = w / h;
  renderer.setSize(w, h, false);
  camera.aspect = aspect;
  camera.updateProjectionMatrix();
  camera.position.setLength(Math.max(21, 22 / aspect));
}
addEventListener('resize', resize);
resize();

/* ---------- Plateau ---------- */
const mat = (c) => new THREE.MeshStandardMaterial({ color: c, roughness: 0.6 });
const board = new THREE.Group();
scene.add(board);
function box(w, h, d, x, y, z, color) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat(color));
  m.position.set(x, y, z);
  m.receiveShadow = true;
  board.add(m);
  return m;
}
box(16, 0.4, 16, 0, -0.2, 0, 0x2b2d42);
box(15, 0.1, 15, 0, 0.05, 0, 0xf4efe4);

BASES.forEach(([bx, by], c) => {
  const p = W(bx + 2.5, by + 2.5, 0);
  box(6, 0.04, 6, p.x, 0.12, p.z, HEX[c]);
  box(4, 0.05, 4, p.x, 0.125, p.z, 0xffffff);
  for (let i = 0; i < 4; i++) {
    const s = cellPos(c, -1, i);
    const m = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.5, 0.06, 28), mat(HEX[c]));
    m.position.set(s.x, 0.15, s.z);
    m.receiveShadow = true;
    board.add(m);
  }
});

const starShape = new THREE.Shape();
for (let k = 0; k < 10; k++) {
  const r = k % 2 ? 0.12 : 0.3, a = k * Math.PI / 5;
  k ? starShape.lineTo(Math.cos(a) * r, Math.sin(a) * r) : starShape.moveTo(Math.cos(a) * r, Math.sin(a) * r);
}
const starGeo = new THREE.ShapeGeometry(starShape);

TRACK.forEach(([x, y], i) => {
  const s = STARTS.indexOf(i);
  box(0.92, 0.04, 0.92, x - 7, 0.12, y - 7, s >= 0 ? HEX[s] : 0xffffff);
  if (SAFE.has(i) && s < 0) {
    const st = new THREE.Mesh(starGeo, new THREE.MeshBasicMaterial({ color: 0x8d99ae }));
    st.rotation.x = -Math.PI / 2;
    st.position.set(x - 7, 0.15, y - 7);
    board.add(st);
  }
});
HOME.forEach((h, c) => h.forEach(([x, y]) => box(0.92, 0.04, 0.92, x - 7, 0.12, y - 7, HEX[c])));

HEX.forEach((col, c) => {
  const d = DIRS[c], p = [-d[1], d[0]];
  const a = [d[0] * 1.5 + p[0] * 1.5, d[1] * 1.5 + p[1] * 1.5];
  const b = [d[0] * 1.5 - p[0] * 1.5, d[1] * 1.5 - p[1] * 1.5];
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(new Float32Array([0, 0.15, 0, a[0], 0.15, a[1], b[0], 0.15, b[1]]), 3));
  g.computeVertexNormals();
  board.add(new THREE.Mesh(g, new THREE.MeshStandardMaterial({ color: col, side: THREE.DoubleSide })));
});

/* ---------- Pions ---------- */
const pawnGeo = new THREE.LatheGeometry(
  [[0.001, 0], [0.3, 0], [0.3, 0.07], [0.17, 0.17], [0.11, 0.42], [0.2, 0.46], [0.2, 0.52], [0.11, 0.56], [0.19, 0.68], [0.19, 0.8], [0.1, 0.9], [0.001, 0.92]]
    .map(([x, y]) => new THREE.Vector2(x, y)), 24);
const pieces = [];
const all = [];
for (let c = 0; c < 4; c++) {
  pieces[c] = [];
  for (let i = 0; i < 4; i++) {
    const m = new THREE.Mesh(pawnGeo, new THREE.MeshStandardMaterial({
      color: HEX[c], roughness: 0.35, metalness: 0.1, emissive: HEX[c], emissiveIntensity: 0, side: THREE.DoubleSide
    }));
    m.castShadow = true;
    const p = { c, i, rel: -1, mesh: m };
    m.userData.p = p;
    scene.add(m);
    pieces[c].push(p);
    all.push(p);
  }
}

function keyOf(p) {
  if (p.rel < 0) return `b${p.c}${p.i}`;
  if (p.rel === 56) return `g${p.c}${p.i}`;
  if (p.rel <= 50) return `t${(STARTS[p.c] + p.rel) % 52}`;
  return `h${p.c}${p.rel}`;
}
function layout() {
  const groups = new Map();
  for (const p of all) {
    const k = keyOf(p);
    if (!groups.has(k)) groups.set(k, []);
    groups.get(k).push(p);
  }
  groups.forEach((arr) => arr.forEach((p, j) => {
    const pos = cellPos(p.c, p.rel, p.i);
    if (arr.length > 1) {
      const a = (j / arr.length) * Math.PI * 2;
      pos.x += Math.cos(a) * 0.2;
      pos.z += Math.sin(a) * 0.2;
    }
    p.mesh.position.copy(pos);
    p.mesh.scale.setScalar(arr.length > 1 ? 0.65 : 0.85);
  }));
}
layout();

function tween(mesh, to, ms, hop = 0) {
  return new Promise((res) => {
    const from = mesh.position.clone(), t0 = performance.now();
    (function step() {
      const k = Math.min(1, (performance.now() - t0) / ms);
      mesh.position.lerpVectors(from, to, k);
      mesh.position.y = G + Math.sin(k * Math.PI) * hop;
      if (k < 1) requestAnimationFrame(step); else { mesh.position.copy(to); res(); }
    })();
  });
}

/* ---------- Règles ---------- */
const $ = (id) => document.getElementById(id);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const setMsg = (t) => { $('msg').textContent = t; };

let turn = 0, dice = 0, state = 'menu', selectable = [];
let humans = [true, false, false, false];

const movable = (c, d) => pieces[c].filter((p) => (p.rel < 0 ? d === 6 : p.rel + d <= 56));
const enemyAt = (c, a) => all.filter((q) => q.c !== c && q.rel >= 0 && q.rel <= 50 && (STARTS[q.c] + q.rel) % 52 === a);

function aiPick(c, d, list) {
  let best = null, score = -1e9;
  for (const p of list) {
    const nr = p.rel < 0 ? 0 : p.rel + d;
    let s = nr;
    if (nr === 56) s += 100;
    if (p.rel < 0) s += 40;
    if (nr <= 50) {
      const a = (STARTS[c] + nr) % 52;
      if (!SAFE.has(a) && enemyAt(c, a).length) s += 80;
      if (SAFE.has(a)) s += 10;
    } else s += 15;
    if (s > score) { score = s; best = p; }
  }
  return best;
}

function startTurn() {
  state = 'roll';
  selectable = [];
  const t = $('turn');
  t.textContent = `${NAMES[turn]} · ${humans[turn] ? 'Humain' : 'IA'}`;
  t.style.setProperty('--c', CSSC[turn]);
  $('dice').disabled = !humans[turn];
  if (humans[turn]) setMsg('Touchez le dé pour le lancer');
  else { setMsg('L’IA joue…'); setTimeout(roll, 900); }
}

async function roll() {
  if (state !== 'roll') return;
  state = 'rolling';
  const b = $('dice');
  b.disabled = true;
  b.classList.add('shake');
  const n = Math.floor(Math.random() * 6) + 1;
  for (let k = 0; k < 8; k++) { b.textContent = FACES[Math.floor(Math.random() * 6)]; await sleep(70); }
  b.textContent = FACES[n - 1];
  b.classList.remove('shake');
  dice = n;
  const list = movable(turn, n);
  if (!list.length) {
    setMsg(`${NAMES[turn]} fait ${n} : aucun coup possible`);
    await sleep(1000);
    return next(false);
  }
  let p;
  if (!humans[turn]) { await sleep(500); p = aiPick(turn, n, list); }
  else if (list.length === 1) { await sleep(300); p = list[0]; }
  else {
    state = 'pick';
    selectable = list;
    setMsg(`Vous avez fait ${n} : touchez un pion`);
    return;
  }
  await move(p, n);
}

async function move(p, d) {
  state = 'anim';
  selectable = [];
  const steps = [];
  if (p.rel < 0) steps.push(0);
  else for (let r = p.rel + 1; r <= p.rel + d; r++) steps.push(r);
  p.mesh.scale.setScalar(0.85);
  for (const r of steps) {
    p.rel = r;
    await tween(p.mesh, cellPos(p.c, r, p.i), 170, 0.35);
  }
  let capture = false;
  if (p.rel <= 50) {
    const a = (STARTS[p.c] + p.rel) % 52;
    if (!SAFE.has(a)) for (const q of enemyAt(p.c, a)) { q.rel = -1; capture = true; }
  }
  layout();
  if (pieces[p.c].every((q) => q.rel === 56)) return win(p.c);
  if (capture) setMsg('Capture ! Vous rejouez');
  else if (p.rel === 56) setMsg('Pion arrivé ! Vous rejouez');
  else if (d === 6) setMsg('Un 6 : vous rejouez');
  await sleep(500);
  next(d === 6 || capture || p.rel === 56);
}

function next(bonus) {
  if (!bonus) turn = (turn + 1) % 4;
  startTurn();
}

function win(c) {
  state = 'over';
  $('dice').disabled = true;
  $('wintxt').textContent = `${NAMES[c]} a gagné !`;
  $('win').classList.remove('hidden');
}

/* ---------- Interface ---------- */
$('dice').addEventListener('click', () => { if (humans[turn] && state === 'roll') roll(); });

document.querySelectorAll('#menu [data-mode]').forEach((b) => b.addEventListener('click', () => {
  const m = b.dataset.mode;
  humans = m === '1' ? [true, false, false, false] : m === '2' ? [true, false, true, false] : [true, true, true, true];
  turn = 0;
  $('menu').classList.add('hidden');
  startTurn();
}));

$('again').addEventListener('click', () => {
  all.forEach((p) => { p.rel = -1; });
  layout();
  $('win').classList.add('hidden');
  $('menu').classList.remove('hidden');
  $('turn').textContent = '';
  $('msg').textContent = '';
  state = 'menu';
});

let down = null;
canvas.addEventListener('pointerdown', (e) => { down = [e.clientX, e.clientY]; });
canvas.addEventListener('pointerup', (e) => {
  if (!down || state !== 'pick') return;
  if (Math.hypot(e.clientX - down[0], e.clientY - down[1]) > 8) return;
  const r = canvas.getBoundingClientRect();
  let best = null, bd = 60;
  for (const p of selectable) {
    const v = p.mesh.position.clone();
    v.y += 0.4;
    v.project(camera);
    const sx = ((v.x + 1) / 2) * r.width + r.left, sy = ((1 - v.y) / 2) * r.height + r.top;
    const dist = Math.hypot(sx - e.clientX, sy - e.clientY);
    if (dist < bd) { bd = dist; best = p; }
  }
  if (best) move(best, dice);
});

/* ---------- Boucle de rendu ---------- */
renderer.setAnimationLoop(() => {
  const t = performance.now() / 1000;
  for (const p of all) {
    const on = selectable.includes(p);
    p.mesh.material.emissiveIntensity = on ? 0.4 + 0.4 * Math.sin(t * 6) : 0;
    if (state !== 'anim') p.mesh.position.y = G + (on ? Math.abs(Math.sin(t * 5)) * 0.15 : 0);
  }
  controls.update();
  renderer.render(scene, camera);
});
