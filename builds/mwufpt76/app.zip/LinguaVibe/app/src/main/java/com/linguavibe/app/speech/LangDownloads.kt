package com.linguavibe.app.speech

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import androidx.compose.runtime.mutableStateMapOf
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.ForegroundInfo
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.linguavibe.app.MainActivity
import com.linguavibe.app.data.Languages
import kotlinx.coroutines.CancellationException
import java.util.concurrent.TimeUnit

/**
 * Tous les téléchargements de langue (modèles Vosk, voix Supertonic et chinoise, audios des leçons)
 * passent par WorkManager : ils continuent quand l'appli est en arrière-plan ou fermée, attendent le
 * retour du réseau, reprennent après un redémarrage du téléphone, et une notification montre l'avancement.
 */
object LangDownloads {
    const val KIND_VOSK = "vosk"
    const val KIND_SUPERTONIC = "supertonic"
    const val KIND_ZH = "zh"
    const val KIND_PACK = "pack"

    const val TAG = "lang-download"
    const val CHANNEL = "lang_downloads"

    /** État affiché : [fraction] entre 0 et 1, ou -1 si inconnue (préparation, décompression). */
    data class State(
        val fraction: Float = -1f,
        val label: String = "",
        val running: Boolean = true,
        val error: String? = null,
        val finished: Boolean = false
    )

    /** États par clé « type:langue » (mis à jour par le worker, dans le même processus que l'interface). */
    val states = mutableStateMapOf<String, State>()

    fun key(kind: String, lang: String = "") = "$kind:$lang"

    private fun workName(kind: String, lang: String) = "dl-$kind-$lang"

    fun title(kind: String, lang: String): String {
        val name = runCatching { Languages.byCode(lang).name }.getOrDefault(lang)
        return when (kind) {
            KIND_VOSK -> "Modèle vocal · $name"
            KIND_SUPERTONIC -> "Voix Supertonic 3"
            KIND_ZH -> "Voix chinoise"
            else -> "Audios des leçons · $name"
        }
    }

    fun enqueue(context: Context, kind: String, lang: String = "", url: String = "", replace: Boolean = false) {
        val app = context.applicationContext
        states[key(kind, lang)] = State(label = "En file d'attente…")
        val request = OneTimeWorkRequestBuilder<LangDownloadWorker>()
            .setInputData(workDataOf("kind" to kind, "lang" to lang, "url" to url))
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .setBackoffCriteria(BackoffPolicy.LINEAR, 30, TimeUnit.SECONDS)
            .addTag(TAG)
            .addTag(key(kind, lang))
            .build()
        WorkManager.getInstance(app).enqueueUniqueWork(
            workName(kind, lang),
            if (replace) ExistingWorkPolicy.REPLACE else ExistingWorkPolicy.KEEP,
            request
        )
    }

    fun cancel(context: Context, kind: String, lang: String = "") {
        WorkManager.getInstance(context.applicationContext).cancelUniqueWork(workName(kind, lang))
        states[key(kind, lang)] = State(running = false, label = "Téléchargement arrêté.")
    }

    fun cancelAll(context: Context, kind: String) {
        states.keys.filter { it.startsWith("$kind:") }.forEach { k ->
            cancel(context, kind, k.substringAfter(':'))
        }
    }

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(
                NotificationChannel(CHANNEL, "Téléchargement des langues", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Avancement des modèles vocaux et des voix téléchargés en arrière-plan."
                }
            )
        }
    }

    internal fun notification(context: Context, title: String, text: String, fraction: Float, ongoing: Boolean) =
        NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(title)
            .setContentText(text)
            .setOnlyAlertOnce(true)
            .setOngoing(ongoing)
            .setSilent(true)
            .setContentIntent(
                PendingIntent.getActivity(
                    context, 0, Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            )
            .apply {
                if (!ongoing) {
                    setSmallIcon(android.R.drawable.stat_sys_download_done)
                    setAutoCancel(true)
                } else if (fraction >= 0f) {
                    setProgress(1000, (fraction * 1000).toInt().coerceIn(0, 1000), false)
                } else {
                    setProgress(0, 0, true)
                }
            }
            .build()
}

class LangDownloadWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    private val kind = inputData.getString("kind") ?: LangDownloads.KIND_PACK
    private val lang = inputData.getString("lang") ?: ""
    private val url = inputData.getString("url") ?: ""
    private val key = LangDownloads.key(kind, lang)
    private val notifId = 4200 + (key.hashCode() and 0x3ff)
    private val title = LangDownloads.title(kind, lang)
    private var lastNotify = 0L

    private fun foreground(text: String, fraction: Float): ForegroundInfo {
        val n = LangDownloads.notification(applicationContext, title, text, fraction, true)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ForegroundInfo(notifId, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            ForegroundInfo(notifId, n)
        }
    }

    override suspend fun getForegroundInfo(): ForegroundInfo = foreground("Préparation…", -1f)

    private fun report(fraction: Float, label: String) {
        LangDownloads.states[key] = LangDownloads.State(fraction, label, true)
        val now = System.currentTimeMillis()
        if (now - lastNotify < 1000) return
        lastNotify = now
        try {
            NotificationManagerCompat.from(applicationContext)
                .notify(notifId, LangDownloads.notification(applicationContext, title, label, fraction, true))
        } catch (_: SecurityException) {
            // Notifications refusées : le téléchargement continue quand même.
        }
    }

    private fun bytes(done: Long, total: Long): String {
        val mb = done / (1024 * 1024)
        return if (total > 0) "$mb / ${total / (1024 * 1024)} Mo" else "$mb Mo"
    }

    override suspend fun doWork(): Result {
        LangDownloads.createChannel(applicationContext)
        try {
            // Service au premier plan : Android laisse le téléchargement tourner, appli fermée.
            setForeground(foreground("Préparation…", -1f))
        } catch (_: Throwable) {
            // Refusé (Android 12+ quand l'appli est déjà en arrière-plan) : WorkManager continue normalement.
        }
        return try {
            report(-1f, "Préparation…")
            when (kind) {
                LangDownloads.KIND_VOSK -> {
                    VoskManager.download(applicationContext, lang, url) { f ->
                        report(f, if (f >= 0f) "Téléchargement… ${(f * 100).toInt()} %" else "Décompression du modèle…")
                    }
                }
                LangDownloads.KIND_SUPERTONIC -> SupertonicVoiceManager.install(applicationContext) { d, t ->
                    report(if (t > 0) d.toFloat() / t else -1f, "Téléchargement… ${bytes(d, t)}")
                }
                LangDownloads.KIND_ZH -> ChineseVoiceManager.install(applicationContext) { d, t ->
                    report(if (t > 0) d.toFloat() / t else -1f, "Téléchargement… ${bytes(d, t)}")
                }
                else -> VoicePacks.run(applicationContext, lang) { d, t ->
                    report(if (t > 0) d.toFloat() / t else -1f, "$d / $t phrases")
                }
            }
            LangDownloads.states[key] = LangDownloads.State(1f, "Terminé : installé sur le téléphone.", false, finished = true)
            done("Terminé : prêt hors ligne.")
            Result.success()
        } catch (e: CancellationException) {
            throw e
        } catch (e: VoiceNetworkException) {
            LangDownloads.states[key] = LangDownloads.State(-1f, "En attente du réseau : reprise automatique.", true)
            if (runAttemptCount < 50) Result.retry() else fail("Réseau indisponible trop longtemps : relancez le téléchargement.")
        } catch (e: Throwable) {
            fail(e.message ?: "Échec du téléchargement.")
        }
    }

    private fun fail(message: String): Result {
        LangDownloads.states[key] = LangDownloads.State(running = false, error = message, label = message)
        done(message)
        return Result.failure()
    }

    private fun done(text: String) {
        try {
            NotificationManagerCompat.from(applicationContext)
                .notify(notifId + 1, LangDownloads.notification(applicationContext, title, text, 1f, false))
        } catch (_: SecurityException) {
        }
    }
}
