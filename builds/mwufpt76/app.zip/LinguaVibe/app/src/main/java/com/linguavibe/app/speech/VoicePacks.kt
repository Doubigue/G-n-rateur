package com.linguavibe.app.speech

import android.content.Context
import androidx.compose.runtime.mutableStateMapOf
import com.linguavibe.app.data.CourseRepository
import com.linguavibe.app.data.QuizItem
import com.linguavibe.app.ui.CourseNarration
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import java.io.File

data class PackProgress(val done: Int, val total: Int, val running: Boolean, val message: String? = null)

/**
 * Téléchargement des voix d'une langue, une seule fois : tout l'audio des cours est enregistré
 * dans le dossier de langue durable, puis lu sans Internet. Les phrases déjà enregistrées sont
 * sautées : un téléchargement interrompu (réseau coupé, appli fermée, téléphone redémarré) reprend
 * où il s'était arrêté. Le travail tourne en arrière-plan grâce à [LangDownloads].
 */
object VoicePacks {
    val progress = mutableStateMapOf<String, PackProgress>()

    private fun marker(context: Context, lang: String) = File(LangStorage.dir(context, "voice-packs"), "$lang.done")

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences("voice_packs", Context.MODE_PRIVATE)

    /** Le marqueur est dans le dossier durable : il survit à une désinstallation, comme les audios. */
    fun isDone(context: Context, lang: String): Boolean =
        marker(context, lang).exists() || prefs(context).getBoolean("done_$lang", false)

    /** Toutes les phrases que les leçons font lire dans [lang]. */
    fun texts(context: Context, lang: String): List<String> {
        if (lang == "fr") {
            // Le français sert à écouter le cours expliqué : on précharge toute la narration des cours.
            val intro = listOf(
                "Bonjour et bienvenue dans LinguaVibe.",
                "Écoutez la phrase, puis répétez-la à voix haute."
            )
            return (intro + CourseNarration.frenchTexts(context)).map { it.trim() }.filter { it.isNotEmpty() }.distinct()
        }
        val courses = buildList {
            add(CourseRepository.load(context, lang, "model1"))
            if (lang == "es") {
                add(CourseRepository.load(context, lang, "model2"))
                add(CourseRepository.load(context, lang, "model3"))
                add(CourseRepository.load(context, lang, "model4"))
            }
        }
        val out = ArrayList<String>()
        for (lesson in courses.flatMap { it.lessons }) {
            lesson.vocab.forEach { v ->
                out.add(if (v.word.any { it == '+' || it == '…' }) v.example else v.word)
                out.add(v.example)
            }
            lesson.grammar.forEach { g -> g.examples.forEach { out.add(it.text) } }
            lesson.dialogue.forEach { out.add(it.text) }
            lesson.quiz.filterIsInstance<QuizItem.Listen>().forEach { out.add(it.phrase) }
            lesson.phrases.forEach { out.add(it.text) }
            lesson.reading?.sentences?.forEach { out.add(it.text) }
            lesson.homework.forEach { out.add(it.model) }
        }
        return out.map { it.trim() }.filter { it.isNotEmpty() }.distinct()
    }

    /** Lance (ou relance) le téléchargement en arrière-plan. */
    fun start(context: Context, lang: String) {
        progress[lang] = progress[lang]?.copy(running = true, message = null) ?: PackProgress(0, 0, true)
        LangDownloads.enqueue(context, LangDownloads.KIND_PACK, lang)
    }

    /**
     * Le vrai travail, exécuté par le worker. Lève [VoiceNetworkException] si le réseau tombe :
     * le worker réessaie plus tard et reprend à la première phrase manquante.
     */
    suspend fun run(context: Context, lang: String, onProgress: (Int, Int) -> Unit) {
        val app = context.applicationContext
        progress[lang] = PackProgress(0, 0, true)
        val all = texts(app, lang)
        val total = all.size
        var done = 0
        progress[lang] = PackProgress(0, total, true)
        for (text in all) {
            val cached = GoogleVoice.isCached(app, text, lang)
            try {
                GoogleVoice.speechFile(app, text, lang)
            } catch (e: CancellationException) {
                throw e
            } catch (e: VoiceNetworkException) {
                progress[lang] = PackProgress(done, total, false, "En attente du réseau : le téléchargement reprendra tout seul.")
                throw e
            } catch (_: Throwable) {
                // Une phrase refusée par le service : on passe à la suivante.
            }
            done++
            if (done % 3 == 0 || done == total) {
                progress[lang] = PackProgress(done, total, true)
                onProgress(done, total)
            }
            if (!cached) delay(120)
        }
        marker(app, lang).writeText("$total\n")
        progress[lang] = PackProgress(total, total, false)
    }

    fun cancel(context: Context, lang: String) {
        LangDownloads.cancel(context, LangDownloads.KIND_PACK, lang)
        progress[lang]?.let { progress[lang] = it.copy(running = false, message = "Téléchargement arrêté.") }
    }

    /** À appeler quand l'audio enregistré est vidé. */
    fun resetAll(context: Context) {
        LangDownloads.cancelAll(context, LangDownloads.KIND_PACK)
        progress.clear()
        prefs(context).edit().clear().apply()
        File(LangStorage.root(context), "voice-packs").listFiles()?.forEach { it.delete() }
    }
}
