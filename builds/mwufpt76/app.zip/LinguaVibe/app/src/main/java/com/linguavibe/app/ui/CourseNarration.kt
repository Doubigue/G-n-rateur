package com.linguavibe.app.ui

import android.content.Context
import com.linguavibe.app.data.CourseRepository
import com.linguavibe.app.data.Languages
import com.linguavibe.app.data.Lesson

/**
 * Le cours lu à voix haute en français : un narrateur français présente la leçon, explique la
 * grammaire et traduit, et les mots et phrases de la langue étudiée sont lus par la voix de cette langue.
 * En mode « français seulement », tout est lu par la voix française.
 */
object CourseNarration {

    /** Un morceau à lire. [foreign] : lu avec la voix de la langue étudiée (sinon voix française). */
    data class Seg(val section: String, val text: String, val foreign: Boolean)

    const val S_INTRO = "Présentation"
    const val S_MANUAL = "Le manuel"
    const val S_CONJ = "Conjugaison"
    const val S_VOCAB = "Vocabulaire"
    const val S_GRAMMAR = "Grammaire"
    const val S_DIALOGUE = "Dialogues"
    const val S_READING = "Lecture"
    const val S_PHRASES = "Phrases utiles"

    private val emoji = Regex("[\\p{So}\\p{Cn}\\uFE0F\\u200D]")

    /** Nettoie un texte pour la synthèse vocale (symboles, flèches, mise en forme). */
    fun clean(t: String): String = t
        .replace(emoji, "")
        .replace("→", ", donne, ")
        .replace("≠", " différent de ")
        .replace("—", ", ")
        .replace("━", "")
        .replace(Regex("[«»“”\"*_#|]"), " ")
        .replace(Regex("\\s*/\\s*"), ", ")
        .replace(Regex("\\(\\s*\\)"), "")
        .replace(Regex("\\s+"), " ")
        .trim()

    /**
     * Construit la narration d'une leçon. [frenchOnly] : tout en français (les mots étrangers sont
     * cités dans la phrase française). [examples] : lire aussi les exemples du vocabulaire.
     */
    fun build(lesson: Lesson, frenchOnly: Boolean, examples: Boolean = true): List<Seg> {
        val out = ArrayList<Seg>()
        fun fr(section: String, text: String) {
            val c = clean(text)
            if (c.length > 1) out.add(Seg(section, c, false))
        }
        fun pair(section: String, foreign: String, french: String, glue: String = " : ") {
            val f = clean(foreign)
            val t = clean(french)
            if (f.isEmpty() && t.isEmpty()) return
            if (frenchOnly) {
                fr(section, if (t.isEmpty()) f else "$f$glue$t")
            } else {
                if (f.isNotEmpty()) out.add(Seg(section, f, true))
                if (t.isNotEmpty()) fr(section, t)
            }
        }

        // Présentation
        fr(S_INTRO, "Leçon ${lesson.number}. ${lesson.titleTr.ifBlank { lesson.title }}.")
        if (lesson.title.isNotBlank() && lesson.title != lesson.titleTr && !frenchOnly) {
            out.add(Seg(S_INTRO, clean(lesson.title), true))
        }
        if (lesson.intro.isNotBlank() && !lesson.intro.startsWith("Contenu officiel")) fr(S_INTRO, lesson.intro)

        // Tableaux de conjugaison (MODEL 4) : les temps principaux, forme par forme.
        val spokenPersons = listOf("yo", "tú", "él", "nosotros", "vosotros", "ellos")
        val main = setOf("presente", "preterito_perfecto", "imperfecto", "indefinido", "futuro", "condicional", "subj_presente", "imperativo")
        lesson.conjugations.forEach { c ->
            fr(S_CONJ, "La conjugaison de ${c.verb}, ${c.translation}.")
            if (c.note.isNotBlank()) fr(S_CONJ, c.note)
            c.tenses.filter { it.id in main }.forEach { t ->
                val forms = t.forms.mapIndexedNotNull { i, f -> if (f == "—") null else if (t.isImperative) f else "${spokenPersons[i]} $f" }
                if (frenchOnly) fr(S_CONJ, "${t.name} : ${forms.joinToString(", ")}.")
                else {
                    fr(S_CONJ, "${t.name}.")
                    out.add(Seg(S_CONJ, forms.joinToString(", ") + ".", true))
                }
            }
        }

        // Texte du manuel (MODEL 2 et 3)
        if (lesson.sourceContent.isNotBlank()) {
            fr(S_MANUAL, "Le cours du manuel.")
            for (b in ManualParser.parse(lesson.sourceContent)) {
                when (b) {
                    is MBlock.Chapter -> fr(S_MANUAL, "${b.label}. ${b.title}.")
                    is MBlock.SubHeading -> fr(S_MANUAL, "${b.title}.")
                    is MBlock.Minor -> fr(S_MANUAL, "${b.title}.")
                    is MBlock.Para -> fr(S_MANUAL, b.text)
                    is MBlock.Bullets -> b.items.forEach { fr(S_MANUAL, it) }
                    is MBlock.Callout -> fr(S_MANUAL, "${b.label} : ${b.text}")
                    is MBlock.Table -> b.rows.forEach { row ->
                        if (row.size >= 2) pair(S_MANUAL, row[0], row.drop(1).filter { it.isNotBlank() }.joinToString(". "))
                        else row.firstOrNull()?.let { fr(S_MANUAL, it) }
                    }
                    is MBlock.Pairs -> b.items.forEach { (a, c) -> pair(S_MANUAL, a, c) }
                    is MBlock.Days -> b.items.forEach { (a, c) -> pair(S_MANUAL, a, c) }
                    is MBlock.Dialogue -> {
                        fr(S_MANUAL, "Dialogue.")
                        b.turns.forEach { (who, text) ->
                            if (frenchOnly) fr(S_MANUAL, "$who : $text") else out.add(Seg(S_MANUAL, clean(text), true))
                        }
                        b.translation?.let { fr(S_MANUAL, "Traduction : $it") }
                    }
                    is MBlock.Reading -> {
                        fr(S_MANUAL, "Lecture : ${b.title}.")
                        pair(S_MANUAL, b.spanish, b.french ?: "", ". En français : ")
                    }
                    is MBlock.Questions -> {
                        b.intro?.let { fr(S_MANUAL, it) }
                        b.items.forEach { fr(S_MANUAL, it) }
                    }
                    is MBlock.Exercise -> fr(S_MANUAL, "${b.label}. ${b.title ?: ""}. ${b.text}")
                    is MBlock.SelfCheck -> {
                        fr(S_MANUAL, "Je vérifie mes acquis.")
                        b.items.forEach { fr(S_MANUAL, it) }
                    }
                }
            }
        }

        // Vocabulaire
        if (lesson.vocab.isNotEmpty()) {
            fr(S_VOCAB, "Le vocabulaire de la leçon : ${lesson.vocab.size} mots et expressions.")
            lesson.vocab.forEach { v ->
                pair(S_VOCAB, v.word, v.translation, " veut dire : ")
                if (examples && v.example.isNotBlank()) pair(S_VOCAB, v.example, v.exampleTr, ". C'est-à-dire : ")
            }
        }

        // Grammaire
        if (lesson.grammar.isNotEmpty()) {
            fr(S_GRAMMAR, "La grammaire.")
            lesson.grammar.forEach { g ->
                fr(S_GRAMMAR, "${g.title}.")
                fr(S_GRAMMAR, g.explanation)
                if (g.examples.isNotEmpty()) fr(S_GRAMMAR, "Exemples.")
                g.examples.forEach { e -> pair(S_GRAMMAR, e.text, e.translation, ". C'est-à-dire : ") }
            }
        }

        // Dialogues
        if (lesson.scenes.isNotEmpty()) {
            fr(S_DIALOGUE, "Les dialogues.")
            lesson.scenes.forEach { sc ->
                fr(S_DIALOGUE, "${sc.titleTr.ifBlank { sc.title }}. ${sc.context}")
                sc.lines.forEach { l ->
                    if (frenchOnly) fr(S_DIALOGUE, "${l.label} : ${l.text}. ${l.translation}")
                    else pair(S_DIALOGUE, l.text, l.translation)
                }
            }
        } else if (lesson.dialogue.isNotEmpty()) {
            fr(S_DIALOGUE, "Le dialogue.")
            lesson.dialogue.forEach { l -> pair(S_DIALOGUE, l.text, l.translation) }
        }

        // Lecture
        lesson.reading?.let { r ->
            if (r.sentences.isNotEmpty()) {
                fr(S_READING, "Lecture : ${r.titleTr.ifBlank { r.title }}.")
                r.sentences.forEach { s -> pair(S_READING, s.text, s.translation) }
            }
        }

        // Phrases utiles
        if (lesson.phrases.isNotEmpty()) {
            fr(S_PHRASES, "Les phrases utiles à retenir.")
            lesson.phrases.forEach { p -> pair(S_PHRASES, p.text, p.translation) }
        }
        fr(S_PHRASES, "Fin de la leçon. Passez maintenant aux exercices et au quiz.")
        return out
    }

    /** Toutes les phrases françaises des narrations, pour le pack de voix française hors ligne. */
    fun frenchTexts(context: Context): List<String> {
        val out = LinkedHashSet<String>()
        for (lang in Languages.courses) {
            val models = if (lang.code == "es") listOf("model1", "model2", "model3", "model4") else listOf("model1")
            for (m in models) {
                val course = runCatching { CourseRepository.load(context, lang.code, m) }.getOrNull() ?: continue
                for (lesson in course.lessons) {
                    build(lesson, frenchOnly = false).filter { !it.foreign }.forEach { out.add(it.text) }
                }
            }
        }
        return out.toList()
    }
}
