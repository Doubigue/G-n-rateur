package com.linguavibe.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linguavibe.app.data.ConjTable
import com.linguavibe.app.data.LanguageInfo

private val PERSONS = listOf("yo", "tú", "él / ella / usted", "nosotros", "vosotros", "ellos / ellas / ustedes")
private val PERSONS_IMP = listOf("", "tú", "usted", "nosotros", "vosotros", "ustedes")
private val SPOKEN = listOf("yo", "tú", "él", "nosotros", "vosotros", "ellos")
private val IrregularColor = Color(0xFFC0392B)

/**
 * Tableau de conjugaison interactif (MODEL 4) : choix du temps par mode, règle du temps, six formes
 * (les irrégulières en couleur), écoute de chaque forme ou du temps entier, et mode révision qui cache
 * les formes jusqu'à ce qu'on les touche.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ConjugationCard(table: ConjTable, lang: LanguageInfo, color: Color) {
    val speaker = LocalSpeaker.current
    var sel by rememberSaveable(table.verb) { mutableStateOf(0) }
    var hide by rememberSaveable(table.verb) { mutableStateOf(false) }
    val tense = table.tenses.getOrNull(sel) ?: return
    val revealed = remember(table.verb, sel, hide) { mutableStateListOf<Int>() }

    fun spoken(i: Int): String {
        val f = tense.forms[i]
        return if (tense.isImperative) f else "${SPOKEN[i]} $f"
    }

    // ------------------------------------------------------------ en-tête du verbe
    CardBox {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(table.verb, style = PosterTitle, fontSize = 32.sp, color = color)
                Text(table.translation, fontSize = 15.sp, color = Ink, fontWeight = FontWeight.SemiBold)
                Text(
                    "Verbe en ${table.group} · gérondif ${table.gerund} · participe ${table.participle}",
                    fontSize = 12.sp, color = InkSoft
                )
            }
            PillButton("Écouter", Art.icVoice, color, filled = false) { speaker.speak(table.verb, lang.locale) }
        }
        if (table.note.isNotBlank()) {
            Text(
                table.note, fontSize = 13.sp, color = Ink, lineHeight = 18.sp,
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                    .background(color.copy(alpha = 0.09f)).padding(12.dp)
            )
        }
    }

    // ------------------------------------------------------------ choix du temps
    CardBox {
        Text("Choisissez un temps", style = PosterTitle, fontSize = 16.sp, color = Ink)
        table.tenses.map { it.mood }.distinct().forEach { mood ->
            Text(mood.uppercase(), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp, color = color)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                table.tenses.forEachIndexed { i, t ->
                    if (t.mood == mood) {
                        FilterChip(selected = i == sel, onClick = { sel = i }, label = { Text(t.name, fontSize = 12.sp) })
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------ le temps choisi
    CardBox {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(tense.name, style = PosterTitle, fontSize = 21.sp, color = Ink)
                Text(tense.nameEs, fontSize = 13.sp, fontStyle = FontStyle.Italic, color = InkSoft)
            }
            val irr = tense.forms.indices.count { tense.isIrregular(it) }
            Text(
                if (irr == 0) "régulier" else "$irr forme${if (irr > 1) "s" else ""} irrégulière${if (irr > 1) "s" else ""}",
                fontSize = 11.sp, fontWeight = FontWeight.Bold,
                color = if (irr == 0) Good else IrregularColor,
                modifier = Modifier.clip(RoundedCornerShape(50))
                    .background((if (irr == 0) Good else IrregularColor).copy(alpha = 0.12f))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }
        Text(
            tense.rule, fontSize = 13.sp, color = Ink, lineHeight = 18.sp,
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                .background(Paper).padding(12.dp)
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Mode révision : cacher les formes", fontSize = 13.sp, color = InkSoft, modifier = Modifier.weight(1f))
            Switch(checked = hide, onCheckedChange = { hide = it }, colors = SwitchDefaults.colors(checkedTrackColor = color))
        }
        tense.forms.forEachIndexed { i, f ->
            if (f != "—") {
                val hidden = hide && i !in revealed
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                        .background(if (i % 2 == 0) color.copy(alpha = 0.05f) else Color.Transparent)
                        .clickable {
                            if (hidden) revealed.add(i) else speaker.speak(spoken(i), lang.locale)
                        }
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        (if (tense.isImperative) PERSONS_IMP else PERSONS)[i],
                        fontSize = 13.sp, color = InkSoft, modifier = Modifier.weight(0.42f)
                    )
                    Text(
                        if (hidden) "• • •  (touchez)" else f,
                        fontSize = 18.sp, fontWeight = FontWeight.Bold,
                        color = when {
                            hidden -> InkSoft
                            tense.isIrregular(i) -> IrregularColor
                            else -> Ink
                        },
                        modifier = Modifier.weight(0.5f)
                    )
                    LineIcon(Art.icVoice, color, 18.dp)
                }
            }
        }
        Text("En rouge : les formes irrégulières. Touchez une ligne pour l'écouter.", fontSize = 11.sp, color = InkSoft)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val all = tense.forms.indices.filter { tense.forms[it] != "—" }.map { spoken(it) }
            PillButton("Écouter le temps", Art.icPlay, color) { speaker.speakAll(all, lang.locale) }
            PillButton("Lentement", Art.icSlow, color, filled = false) { speaker.speakAll(all, lang.locale, slow = true) }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton(onClick = { sel = (sel - 1).coerceAtLeast(0) }, enabled = sel > 0) { Text("◀ Temps précédent") }
            Spacer(Modifier.width(4.dp))
            TextButton(onClick = { sel = (sel + 1).coerceAtMost(table.tenses.lastIndex) }, enabled = sel < table.tenses.lastIndex) {
                Text("Temps suivant ▶")
            }
        }
    }
}
