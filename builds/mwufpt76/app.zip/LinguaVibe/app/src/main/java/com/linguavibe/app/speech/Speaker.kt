package com.linguavibe.app.speech

import android.content.Context
import android.media.MediaPlayer
import android.media.audiofx.Visualizer
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.util.Locale

/**
 * Fait entendre la prononciation modèle.
 * Voix de l'appli : ElevenLabs (si configuré), sinon la voix en ligne gratuite de Google.
 * La synthèse vocale du téléphone n'est pas utilisée.
 */
class Speaker(context: Context) : TextToSpeech.OnInitListener {
    private val appContext = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val tts = TextToSpeech(appContext, this)
    private var ready = false
    private var pending: (() -> Unit)? = null
    private var player: MediaPlayer? = null
    private var visualizer: Visualizer? = null

    /** Niveau sonore réel de la lecture MediaPlayer, normalisé entre 0 et 1. */
    var speechLevel by mutableStateOf(0f)
        private set
    /** Vrai quand [speechLevel] vient réellement de l'audio (faux : voix indisponible ou analyse refusée). */
    var levelLive by mutableStateOf(false)
        private set
    /** Vrai si la voix en cours se joue sans analyse audio : l'animation de bouche passe alors en repli. */
    var levelUnavailable by mutableStateOf(false)
        private set
    private var job: Job? = null
    private var sequenceId = 0

    // Voix Android : on synthétise d'abord dans un fichier pour la rejouer via MediaPlayer,
    // ce qui donne accès à l'analyse du niveau sonore (comme pour les autres voix).
    private var fileUtterance: String? = null
    private var fileTarget: File? = null
    private var fileText = ""
    private var fileRate = 1f
    private var fileCallback: (() -> Unit)? = null

    val settings = VoiceSettings(appContext)

    /** Faux si la voix Android de la langue demandée n'est pas installée. */
    var voiceAvailable by mutableStateOf(true)
        private set

    /** Dernière erreur de la voix ElevenLabs (affichée à l'apprenant). */
    var lastError by mutableStateOf<String?>(null)
        private set

    /** Vrai pendant la lecture d'une suite de phrases (« écouter la leçon »). */
    var sequencePlaying by mutableStateOf(false)
        private set

    /** Position de la phrase lue dans la suite en cours (-1 hors lecture). */
    var sequenceIndex by mutableStateOf(-1)
        private set

    /** Nom de la suite en cours (ex. « narration ») ; vide pour « écouter la leçon ». */
    var sequenceTag by mutableStateOf("")
        private set

    /** Nom de la voix utilisée pour la dernière phrase (affiché dans les paramètres). */
    var lastEngine by mutableStateOf("")
        private set

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
        if (!ready) voiceAvailable = false
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                if (utteranceId != null && utteranceId == fileUtterance) {
                    main.post { playSynthesized(utteranceId) }
                } else finish()
            }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                if (utteranceId != null && utteranceId == fileUtterance) {
                    // La synthèse en fichier a échoué : lecture directe, sans niveau sonore.
                    main.post { fallbackDirect(utteranceId) }
                } else finish()
            }
        })
    }

    private fun finish() {
        main.post {
            val callback = pending
            pending = null
            callback?.invoke()
        }
    }

    /** Arrête le son en cours sans toucher à la suite de phrases. */
    private fun halt() {
        levelUnavailable = false
        fileUtterance = null
        fileCallback = null
        releaseVisualizer()
        speechLevel = 0f
        job?.cancel()
        job = null
        pending = null
        player?.let {
            try {
                it.stop()
            } catch (_: Exception) {
            }
            it.release()
        }
        player = null
        if (ready) tts.stop()
    }

    fun speak(text: String, locale: Locale, slow: Boolean = false, onDone: (() -> Unit)? = null) {
        sequenceId++
        sequencePlaying = false
        sequenceIndex = -1
        val rate = (settings.playbackSpeed * if (slow) 0.65f else 1.0f).coerceIn(0.35f, 1.5f)
        start(text, locale, rate, onDone)
    }

    /** Lit plusieurs phrases à la suite (en partant de [from]). */
    fun speakAll(texts: List<String>, locale: Locale, slow: Boolean = false, from: Int = 0) {
        speakSegments(texts.map { it to locale }, "", slow, from)
    }

    /**
     * Lit une suite de phrases, chacune avec sa propre langue (narration du cours en français avec
     * les exemples dans la langue étudiée). [tag] identifie la suite pour l'interface.
     */
    fun speakSegments(segments: List<Pair<String, Locale>>, tag: String, slow: Boolean = false, from: Int = 0) {
        val id = ++sequenceId
        sequenceTag = tag
        sequencePlaying = true
        fun next(index: Int) {
            if (id != sequenceId) return
            if (index >= segments.size) {
                sequencePlaying = false
                sequenceIndex = -1
                return
            }
            sequenceIndex = index
            val rate = (settings.playbackSpeed * if (slow) 0.65f else 1.0f).coerceIn(0.35f, 1.5f)
            val (text, loc) = segments[index]
            start(text, loc, rate) { next(index + 1) }
        }
        next(from)
    }

    fun stop() {
        sequenceId++
        sequencePlaying = false
        sequenceIndex = -1
        halt()
    }

    private var prefetchJob: Job? = null

    /**
     * Prépare en tâche de fond le son des premières phrases d'une leçon : ensuite, un appui
     * sur « Écouter » est immédiat. Sans effet avec ElevenLabs (payant à la phrase).
     */
    fun prefetch(texts: List<String>, locale: Locale) {
        val lang = locale.language
        if (settings.ready || settings.engine == VoiceSettings.ENGINE_SUPERTONIC ||
            (lang == "zh" && ChineseVoiceManager.isInstalled(appContext)) ||
            (lang != "zh" && settings.engine == VoiceSettings.ENGINE_AUTO && SupertonicVoiceManager.isInstalled(appContext))) return
        prefetchJob?.cancel()
        prefetchJob = scope.launch {
            for (text in texts.map { it.trim() }.filter { it.isNotEmpty() }.distinct().take(30)) {
                try {
                    GoogleVoice.speechFile(appContext, text, lang)
                } catch (e: CancellationException) {
                    throw e
                } catch (_: Throwable) {
                    return@launch
                }
                delay(150)
            }
        }
    }

    /**
     * Voix de l'appli : ElevenLabs si une clé est configurée (ou choisie en priorité),
     * sinon la voix en ligne gratuite de Google. Supertonic 3 est entièrement local après installation.
     */
    private fun start(text: String, locale: Locale, rate: Float, onDone: (() -> Unit)?) {
        halt()
        val lang = locale.language
        val useChineseVits = lang == "zh" && ChineseVoiceManager.isInstalled(appContext)
        val useSupertonic = lang != "zh" && (settings.engine == VoiceSettings.ENGINE_SUPERTONIC ||
            (settings.engine == VoiceSettings.ENGINE_AUTO && SupertonicVoiceManager.isInstalled(appContext)))
        val useEleven = settings.ready && settings.engine != VoiceSettings.ENGINE_SUPERTONIC
        job = scope.launch {
            try {
                if (lang == "zh" && (useChineseVits || settings.engine == VoiceSettings.ENGINE_SUPERTONIC || settings.engine == VoiceSettings.ENGINE_AUTO && ChineseVoiceManager.isInstalled(appContext))) {
                    if (!ChineseVoiceManager.isInstalled(appContext)) throw IllegalStateException("Installez le pack de voix chinoise dans Paramètres > Voix.")
                    val sid = settings.chineseSpeaker()
                    val file = ChineseVitsTts.speechFile(appContext, text, sid, rate)
                    lastError = null; voiceAvailable = true; lastEngine = "VITS chinois · voix ${sid + 1}"
                    play(file, 1.0f, onDone)
                    return@launch
                }
                if (useSupertonic) {
                    if (!SupertonicVoiceManager.isInstalled(appContext)) {
                        throw IllegalStateException("Téléchargez d'abord le modèle Supertonic 3 dans Paramètres > Voix.")
                    }
                    val speakerId = settings.speakerFor(lang)
                    val file = SupertonicTts.speechFile(appContext, text, lang, speakerId, rate)
                    lastError = null
                    voiceAvailable = true
                    lastEngine = "Supertonic 3 · voix ${speakerId + 1}"
                    play(file, 1.0f, onDone)
                    return@launch
                }
                val file = if (useEleven) {
                    try {
                        ElevenLabs.speechFile(appContext, settings.apiKey, settings.voiceId, settings.model, text, lang)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Throwable) {
                        lastError = e.message ?: "Voix ElevenLabs indisponible."
                        null
                    }
                } else null
                val source = if (file != null) "ElevenLabs" else "Google (audio téléchargé)"
                val result = file ?: GoogleVoice.speechFile(appContext, text, lang)
                lastError = null
                voiceAvailable = true
                lastEngine = source
                play(result, rate, onDone)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                lastError = e.message ?: "Voix de l'appli indisponible."
                sequencePlaying = false
                sequenceIndex = -1
            }
        }
    }

    /** Analyse uniquement le flux audio de ce MediaPlayer (jamais le micro). */
    private fun attachVisualizer(mp: MediaPlayer) {
        releaseVisualizer()
        try {
            val capture = Visualizer(mp.audioSessionId)
            val range = Visualizer.getCaptureSizeRange()
            capture.captureSize = range[1].coerceAtMost(1024)
            capture.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(
                    visualizer: Visualizer?, waveform: ByteArray?, samplingRate: Int
                ) {
                    if (waveform == null || waveform.isEmpty()) return
                    var sum = 0.0
                    for (sample in waveform) {
                        val centered = (sample.toInt() and 0xff) - 128
                        sum += centered * centered
                    }
                    val rms = kotlin.math.sqrt(sum / waveform.size).toFloat()
                    val level = ((rms - 3f) / 68f).coerceIn(0f, 1f)
                    main.post {
                        // Lissage léger pour éviter les mouvements saccadés du visage.
                        speechLevel = speechLevel * 0.35f + level * 0.65f
                    }
                }

                override fun onFftDataCapture(
                    visualizer: Visualizer?, fft: ByteArray?, samplingRate: Int
                ) = Unit
            }, (Visualizer.getMaxCaptureRate() / 2).coerceAtLeast(1), true, false)
            capture.enabled = true
            visualizer = capture
            levelLive = true
        } catch (_: Throwable) {
            // Certains appareils refusent l'effet de visualisation : la lecture audio continue.
            levelUnavailable = true
            speechLevel = 0f
            releaseVisualizer()
        }
    }

    private fun releaseVisualizer() {
        levelLive = false
        visualizer?.let { effect ->
            try { effect.enabled = false } catch (_: Throwable) { }
            try { effect.release() } catch (_: Throwable) { }
        }
        visualizer = null
    }

    private fun play(file: File, rate: Float, onDone: (() -> Unit)?) {
        val mp = MediaPlayer()
        player = mp
        pending = onDone
        mp.setOnCompletionListener {
            if (player === it) {
                releaseVisualizer()
                speechLevel = 0f
                it.release()
                player = null
                finish()
            }
        }
        mp.setOnErrorListener { failed, _, _ ->
            if (player === failed) {
                releaseVisualizer()
                speechLevel = 0f
                failed.release()
                player = null
                finish()
            }
            true
        }
        mp.setDataSource(file.absolutePath)
        mp.prepare()
        mp.playbackParams = mp.playbackParams.setSpeed(rate)
        attachVisualizer(mp)
        mp.start()
    }

    /** Vrai si la voix de synthèse du téléphone (moteur Android) a ses données pour cette langue. */
    fun phoneVoiceInstalled(locale: Locale): Boolean = try {
        ready && tts.isLanguageAvailable(locale) >= TextToSpeech.LANG_AVAILABLE
    } catch (e: Throwable) {
        false
    }

    private fun speakTts(text: String, locale: Locale, rate: Float, onDone: (() -> Unit)?) {
        speechLevel = 0f
        if (!ready) {
            onDone?.invoke()
            return
        }
        val result = tts.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            voiceAvailable = false
            onDone?.invoke()
            return
        }
        voiceAvailable = true
        val ttsRate = (0.95f * rate).coerceIn(0.35f, 1.5f)
        tts.setSpeechRate(ttsRate)

        // Essai 1 : synthèse dans un fichier, relue par MediaPlayer + Visualizer (niveau sonore réel).
        appContext.cacheDir.listFiles { f -> f.name.startsWith("tts_") }?.forEach { it.delete() }
        val id = "f" + System.nanoTime()
        val target = File(appContext.cacheDir, "tts_$id.wav")
        fileUtterance = id
        fileTarget = target
        fileText = text
        fileRate = ttsRate
        fileCallback = onDone
        val queued = try {
            tts.synthesizeToFile(text, null, target, id) == TextToSpeech.SUCCESS
        } catch (_: Throwable) {
            false
        }
        if (!queued) fallbackDirect(id)
    }

    /** La voix Android a fini d'écrire le fichier : on le joue avec l'analyse du niveau sonore. */
    private fun playSynthesized(id: String) {
        if (id != fileUtterance) return // lecture arrêtée ou remplacée entre-temps
        val file = fileTarget
        val callback = fileCallback
        if (file == null || !file.exists() || file.length() < 512L) {
            fallbackDirect(id)
            return
        }
        fileUtterance = null
        fileCallback = null
        try {
            // La vitesse est déjà intégrée au fichier par setSpeechRate.
            play(file, 1.0f, callback)
        } catch (_: Throwable) {
            player?.let { try { it.release() } catch (_: Throwable) { } }
            player = null
            releaseVisualizer()
            fileUtterance = id
            fallbackDirect(id)
        }
    }

    /** Dernier recours : lecture directe par le moteur Android (pas de niveau sonore). */
    private fun fallbackDirect(id: String) {
        if (id != fileUtterance) return
        fileUtterance = null
        val callback = fileCallback
        fileCallback = null
        speechLevel = 0f
        levelUnavailable = true
        pending = callback
        tts.setSpeechRate(fileRate)
        tts.speak(fileText, TextToSpeech.QUEUE_FLUSH, null, "u" + System.nanoTime())
    }

    fun shutdown() {
        stop()
        scope.cancel()
        SupertonicTts.release()
        ChineseVitsTts.release()
        tts.shutdown()
    }
}
