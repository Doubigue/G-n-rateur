#!/usr/bin/env python3
"""Cours augmentés des MODEL 2 et 3 (espagnol).

- MODEL 3 : quatre nouvelles unités (5 à 8) : au marché, à l'école, la maison et le village, les repas et la fête ;
  plus du vocabulaire et un point de grammaire en plus dans les unités 1 à 4.
- MODEL 2 : quatre nouvelles leçons 17 à 20 (tools/content_m2_new.py : voyage, santé, travail, environnement), et dans
  chacune des 16 leçons d'origine, cinq mots, un point de grammaire et trois phrases utiles en plus.

Appliqué par tools/quiz_practice.py avant la génération des quiz (aucun doublon si on relance).
"""
import copy
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from content_m3 import V, G, S, H  # noqa: E402
from pron_es import pron  # noqa: E402
from content_m2_new import M2_NEW, manual_text  # noqa: E402
from content_m2_more import M2_MORE  # noqa: E402


def Qx(question, correct, wrong, explain=""):
    return {"type": "mcq", "question": question, "correct": correct, "wrong": wrong, "explain": explain}


def R(title, titleTr, sentences):
    return {"title": title, "titleTr": titleTr,
            "sentences": [{"text": t, "translation": f, "pron": ""} for t, f in sentences]}


def P(ref, title, instruction, items):
    return {"ref": ref, "title": title, "instruction": instruction, "items": items}


def fill(sentence, answers, wrong, tr, explain=""):
    return {"type": "fill", "sentence": sentence, "answers": answers, "wrong": wrong, "translation": tr, "explain": explain}


def order(sentence, tr):
    return {"type": "order", "words": sentence.split(), "translation": tr, "explain": ""}


def speak(text, tr):
    return {"type": "speak", "text": text, "translation": tr, "explain": ""}


def match(pairs, title=""):
    return {"type": "match", "pairs": [list(p) for p in pairs], "title": title, "explain": ""}


def write(prompt, model, keywords, n):
    return {"type": "write", "prompt": prompt, "model": model, "keywords": keywords, "minWords": n, "explain": ""}


# =============================================================================== MODEL 3 : nouvelles unités

M3_NEW = [
    # ----------------------------------------------------------------------- Unité 5
    {
        "id": "m3-es-05", "level": "A1", "number": 5, "emoji": "🧺",
        "title": "En el mercado",
        "titleTr": "Au marché : acheter, demander le prix, payer",
        "intro": "Fatou fait les courses au marché d'Adjamé avec mamá Awa, la vendeuse, puis Koffi commande à manger "
                 "dans un maquis. Vous apprenez à demander ce que vous voulez, le prix d'un article, à dire la quantité, "
                 "à payer et à recevoir la monnaie. Réutilisez les nombres de l'unité 4.",
        "vocab": [
            V("el mercado", "le marché", "Voy al mercado con mi madre.", "Je vais au marché avec ma mère.", "🧺"),
            V("la vendedora / el vendedor", "la vendeuse / le vendeur", "La vendedora vende tomates.", "La vendeuse vend des tomates.", "👩🏾‍🌾"),
            V("Quiero…", "Je veux… / Je voudrais…", "Quiero un kilo de arroz.", "Je voudrais un kilo de riz.", "🙋"),
            V("¿Cuánto cuestan?", "Combien coûtent-ils / elles ?", "¿Cuánto cuestan las naranjas?", "Combien coûtent les oranges ?", "💰"),
            V("el kilo", "le kilo", "Medio kilo de tomates, por favor.", "Un demi-kilo de tomates, s'il vous plaît.", "⚖️"),
            V("la naranja", "l'orange", "Las naranjas están muy dulces.", "Les oranges sont très sucrées.", "🍊"),
            V("el plátano", "la banane (plantain)", "Compro plátanos para el alloco.", "J'achète des bananes pour l'alloco.", "🍌"),
            V("el tomate", "la tomate", "Los tomates son rojos.", "Les tomates sont rouges.", "🍅"),
            V("el arroz", "le riz", "El arroz cuesta mil francos el kilo.", "Le riz coûte mille francs le kilo.", "🍚"),
            V("el aceite", "l'huile", "Una botella de aceite, por favor.", "Une bouteille d'huile, s'il vous plaît.", "🫙"),
            V("el pescado", "le poisson", "El pescado está fresco.", "Le poisson est frais.", "🐟"),
            V("el pan", "le pain", "Quiero dos panes.", "Je veux deux pains.", "🥖"),
            V("la botella", "la bouteille", "Una botella de agua.", "Une bouteille d'eau.", "🍾"),
            V("Aquí tiene.", "Voici. / Tenez.", "Aquí tiene dos mil francos.", "Voici deux mille francs.", "🤲"),
            V("¿Algo más?", "Autre chose ?", "¿Algo más? — No, gracias.", "Autre chose ? — Non, merci.", "➕"),
            V("fresco / fresca", "frais / fraîche", "La fruta está fresca.", "Les fruits sont frais.", "🌿"),
            V("pagar", "payer", "Pago con un billete de cinco mil.", "Je paie avec un billet de cinq mille.", "💵"),
            V("el billete", "le billet", "No tengo billetes pequeños.", "Je n'ai pas de petits billets.", "💶"),
        ],
        "grammar": [
            G("Dire ce que l'on veut : QUERER (e → ie)",
              "Querer (vouloir) change son e en ie quand l'accent tombe sur le radical : quiero, quieres, quiere, quieren ; "
              "mais queremos, queréis gardent le e. Au marché, on dit quiero… ou, plus poli, quería… (je voudrais). "
              "Querer + nom (quiero pan) ou querer + infinitif (quiero comprar pan).",
              [("Quiero un kilo de tomates.", "Je veux un kilo de tomates."),
               ("¿Qué quieres, hija?", "Que veux-tu, ma fille ?"),
               ("Queremos comprar pescado.", "Nous voulons acheter du poisson."),
               ("Mis hermanos quieren plátanos.", "Mes frères veulent des bananes.")]),
            G("Demander le prix : CUESTA / CUESTAN",
              "Costar (coûter) change son o en ue : cuesta, cuestan. On accorde avec la chose achetée : "
              "¿Cuánto cuesta el pan? (un seul) ; ¿Cuánto cuestan las naranjas? (plusieurs). "
              "Pour le total, on dit : ¿Cuánto es? — Son mil francos.",
              [("¿Cuánto cuesta el kilo de arroz? — Cuesta mil francos.", "Combien coûte le kilo de riz ? — Il coûte mille francs."),
               ("¿Cuánto cuestan los tomates? — Cuestan quinientos francos.", "Combien coûtent les tomates ? — Elles coûtent cinq cents francs."),
               ("¿Cuánto es todo? — Son tres mil francos.", "Combien ça fait en tout ? — Ça fait trois mille francs.")]),
            G("Dire la quantité : UN KILO DE, UNA BOTELLA DE, MEDIO",
              "Après une quantité, on met de + le nom, sans article : un kilo de arroz, una botella de aceite, un paquete de azúcar. "
              "Medio (demi) se place devant le nom sans un : medio kilo. Mucho / mucha (beaucoup de) et poco / poca (peu de) "
              "s'accordent : muchas naranjas, poco aceite.",
              [("Un kilo de arroz y una botella de aceite.", "Un kilo de riz et une bouteille d'huile."),
               ("Medio kilo de pescado, por favor.", "Un demi-kilo de poisson, s'il vous plaît."),
               ("Hay muchas naranjas y poco pan.", "Il y a beaucoup d'oranges et peu de pain.")]),
        ],
        "scenes": [
            S("En el mercado de Adjamé", "Au marché d'Adjamé", "mercado",
              "Samedi matin. Fatou fait les courses pour sa mère. Mamá Awa vend des fruits et des légumes.",
              {"A": "Mamá Awa", "B": "Fatou"},
              [("A", "¡Buenos días, hija! ¿Qué quieres?", "Bonjour, ma fille ! Que veux-tu ?"),
               ("B", "Buenos días, señora. ¿Cuánto cuesta el kilo de tomates?", "Bonjour, madame. Combien coûte le kilo de tomates ?"),
               ("A", "Cuesta quinientos francos.", "Il coûte cinq cents francs."),
               ("B", "¿Y cuánto cuestan las naranjas?", "Et combien coûtent les oranges ?"),
               ("A", "Cien francos cada una. Están muy dulces.", "Cent francs pièce. Elles sont très sucrées."),
               ("B", "Quiero diez naranjas y un kilo de tomates, por favor.", "Je voudrais dix oranges et un kilo de tomates, s'il vous plaît."),
               ("A", "Muy bien. ¿Algo más?", "Très bien. Autre chose ?"),
               ("B", "No, gracias. ¿Cuánto es todo?", "Non, merci. Combien ça fait en tout ?"),
               ("A", "Son mil quinientos francos.", "Ça fait mille cinq cents francs."),
               ("B", "Aquí tiene dos mil francos.", "Voici deux mille francs."),
               ("A", "Y aquí tienes la vuelta: quinientos francos.", "Et voici ta monnaie : cinq cents francs."),
               ("B", "¡Gracias, señora! ¡Hasta el sábado!", "Merci, madame ! À samedi !")]),
            S("En el maquis", "Au maquis", "maquis",
              "Après le marché, Koffi et Silué ont faim. Ils s'arrêtent dans un petit maquis du quartier.",
              {"A": "Adjoua", "B": "Koffi"},
              [("A", "¡Buenas tardes, chicos! ¿Qué queréis comer?", "Bonjour, les garçons ! Que voulez-vous manger ?"),
               ("B", "Queremos dos platos de arroz con pescado.", "Nous voulons deux assiettes de riz au poisson."),
               ("A", "¿Y para beber?", "Et pour boire ?"),
               ("B", "Un zumo de naranja y una botella de agua, por favor.", "Un jus d'orange et une bouteille d'eau, s'il vous plaît."),
               ("A", "Muy bien. ¿Queréis también alloco?", "Très bien. Vous voulez aussi de l'alloco ?"),
               ("B", "Sí, una porción pequeña. ¿Cuánto es todo?", "Oui, une petite portion. Combien ça fait en tout ?"),
               ("A", "Son tres mil francos.", "Ça fait trois mille francs."),
               ("B", "Aquí tiene. ¡Está muy rico!", "Voici. C'est très bon !")]),
        ],
        "phrases_add": [
            ("¿Cuánto cuesta el kilo de arroz?", "Combien coûte le kilo de riz ?"),
            ("Quiero medio kilo de tomates, por favor.", "Je voudrais un demi-kilo de tomates, s'il vous plaît."),
            ("Es un poco caro.", "C'est un peu cher."),
            ("¿Cuánto es todo?", "Combien ça fait en tout ?"),
            ("Aquí tiene. Gracias.", "Voici. Merci."),
            ("¿Tiene usted la vuelta?", "Avez-vous la monnaie ?"),
        ],
        "reading": R("La lista de la compra", "La liste de courses", [
            ("Hoy es sábado y Fatou va al mercado.", "Aujourd'hui, c'est samedi et Fatou va au marché."),
            ("Su madre le da una lista y cinco mil francos.", "Sa mère lui donne une liste et cinq mille francs."),
            ("Fatou compra un kilo de arroz por mil francos.", "Fatou achète un kilo de riz pour mille francs."),
            ("Compra también una botella de aceite por mil quinientos francos.", "Elle achète aussi une bouteille d'huile pour mille cinq cents francs."),
            ("Al final, tiene dos mil quinientos francos de vuelta.", "À la fin, il lui reste deux mille cinq cents francs de monnaie."),
            ("Con cien francos, compra una naranja para ella.", "Avec cent francs, elle s'achète une orange."),
        ]),
        "homework": [
            H("Écris ta liste de courses en espagnol : cinq produits avec la quantité (un kilo de…, una botella de…).",
              "Un kilo de arroz, una botella de aceite, medio kilo de tomates, diez naranjas y dos panes.",
              ["kilo", "botella", "de"]),
            H("Écris un petit dialogue entre un client et une vendeuse (6 répliques) avec ¿Cuánto cuesta? et ¿Cuánto es?",
              "— Buenos días. ¿Cuánto cuesta el pescado? — Dos mil francos el kilo. — Quiero un kilo. — ¿Algo más? — No, gracias. ¿Cuánto es? — Son dos mil francos.",
              ["cuánto cuesta", "quiero", "cuánto es", "francos"]),
            H("Fatou paie 3 250 F avec un billet de 5 000 F. Écris en lettres la monnaie qu'on lui rend.",
              "Le devuelven mil setecientos cincuenta francos.", ["mil", "setecientos", "cincuenta"]),
        ],
        "quiz_add": [
            Qx("« Combien coûtent les oranges ? »", "¿Cuánto cuestan las naranjas?", ["¿Cuánto cuesta las naranjas?", "¿Cuántos cuestan las naranjas?", "¿Cuánto costan las naranjas?"],
               "Plusieurs oranges : cuestan (o → ue, pluriel)."),
            Qx("« Un kilo de riz » :", "un kilo de arroz", ["un kilo del arroz", "un kilo arroz", "uno kilo de arroz"], "Après une quantité : de + nom, sans article."),
            Qx("« Nous voulons du poisson » :", "Queremos pescado.", ["Quieremos pescado.", "Queremos el pescado de.", "Quiero pescado."], "Nosotros garde le e : queremos."),
            Qx("Le prix total, la vendeuse dit :", "Son mil francos.", ["Es mil francos.", "Cuesta mil francos todo de.", "Están mil francos."], "Pour un total : son + somme."),
            Qx("« Voici la monnaie » :", "Aquí tiene la vuelta.", ["Aquí tiene el billete.", "Aquí tiene la botella.", "Aquí tiene el kilo."], "La vuelta = la monnaie rendue."),
        ],
        "practice": [
            P("", "Faire ses courses au marché", "Complétez, associez puis jouez la scène au micro.", [
                fill("¿Cuánto ___ el kilo de arroz?", ["cuesta"], ["cuestan", "costa", "cuestas"], "Combien coûte le kilo de riz ?"),
                fill("¿Cuánto ___ los tomates?", ["cuestan"], ["cuesta", "costan", "cuestamos"], "Combien coûtent les tomates ?"),
                fill("Yo ___ diez naranjas.", ["quiero"], ["quero", "queremos", "quieres"], "Je veux dix oranges."),
                fill("Una botella ___ aceite.", ["de"], ["del", "en", "a"], "Une bouteille d'huile."),
                match([("el pescado", "le poisson"), ("el arroz", "le riz"), ("el aceite", "l'huile"), ("el pan", "le pain"), ("la vuelta", "la monnaie")]),
                order("Quiero medio kilo de tomates, por favor.", "Je voudrais un demi-kilo de tomates, s'il vous plaît."),
                {"type": "typed", "prompt": "Tomates : 500 F + pan : 250 F + aceite : 1 500 F. ¿Cuánto es?", "answers": ["dos mil doscientos cincuenta", "dos mil doscientos cincuenta francos", "son dos mil doscientos cincuenta francos"],
                 "explain": "500 + 250 + 1 500 = 2 250.", "instruction": "Écrivez le total en lettres"},
                speak("Buenos días, señora. ¿Cuánto cuesta el kilo de tomates?", "Bonjour, madame. Combien coûte le kilo de tomates ?"),
                write("Écris ton dialogue au marché : salue, demande deux prix, achète, paie.",
                      "Buenos días. ¿Cuánto cuesta el pan? — Doscientos francos. — ¿Y el pescado? — Dos mil el kilo. — Quiero un pan y un kilo de pescado. ¿Cuánto es? — Son dos mil doscientos francos. — Aquí tiene.",
                      ["cuánto cuesta", "quiero", "cuánto es", "aquí tiene"], 25),
            ]),
        ],
    },
    # ----------------------------------------------------------------------- Unité 6
    {
        "id": "m3-es-06", "level": "A1", "number": 6, "emoji": "🎒",
        "title": "En el colegio",
        "titleTr": "Au collège : les fournitures, les matières et l'emploi du temps",
        "intro": "Aya a perdu sa règle, Silué lui prête la sienne ; puis Koffi et Fatou regardent leur emploi du temps de la semaine. "
                 "Vous apprenez à nommer les objets de la classe, à dire ce qu'il y a (hay) et ce que vous avez (tener), "
                 "les jours de la semaine et les matières.",
        "vocab": [
            V("la mochila", "le sac d'école", "¿Qué hay en tu mochila?", "Qu'y a-t-il dans ton sac ?", "🎒"),
            V("el bolígrafo", "le stylo", "Tengo un bolígrafo azul.", "J'ai un stylo bleu.", "🖊️"),
            V("la regla", "la règle", "¿Me prestas tu regla?", "Tu me prêtes ta règle ?", "📏"),
            V("la goma", "la gomme", "La goma está en la mesa.", "La gomme est sur la table.", "🧽"),
            V("la pizarra", "le tableau", "El profesor escribe en la pizarra.", "Le professeur écrit au tableau.", "🧑🏾‍🏫"),
            V("el profesor / la profesora", "le professeur / la professeure", "La profesora de español es simpática.", "La professeure d'espagnol est sympathique.", "👩🏾‍🏫"),
            V("la asignatura", "la matière", "Mi asignatura preferida es el español.", "Ma matière préférée est l'espagnol.", "📚"),
            V("las matemáticas", "les mathématiques", "Los lunes tenemos matemáticas.", "Le lundi, nous avons maths.", "➗"),
            V("la historia", "l'histoire", "Me gusta la historia de África.", "J'aime l'histoire de l'Afrique.", "🏛️"),
            V("el recreo", "la récréation", "En el recreo jugamos al fútbol.", "À la récréation, nous jouons au foot.", "⚽"),
            V("el horario", "l'emploi du temps", "Mira el horario de la semana.", "Regarde l'emploi du temps de la semaine.", "🗓️"),
            V("el lunes, el martes, el miércoles", "lundi, mardi, mercredi", "El martes tenemos inglés.", "Mardi, nous avons anglais.", "📅"),
            V("el jueves, el viernes", "jeudi, vendredi", "El viernes hay deporte.", "Vendredi, il y a sport.", "📅"),
            V("el sábado, el domingo", "samedi, dimanche", "El domingo no hay clase.", "Le dimanche, il n'y a pas cours.", "🌞"),
            V("hay", "il y a", "Hay treinta alumnos en la clase.", "Il y a trente élèves dans la classe.", "👉"),
            V("prestar", "prêter", "Te presto mi regla.", "Je te prête ma règle.", "🤝"),
            V("estudiar", "étudier", "Estudio español en el colegio.", "J'étudie l'espagnol au collège.", "📖"),
            V("los deberes", "les devoirs", "Hago los deberes por la tarde.", "Je fais mes devoirs l'après-midi.", "📝"),
        ],
        "grammar": [
            G("Dire ce qu'il y a : HAY",
              "Hay (il y a) est invariable : hay un libro, hay dos libros. Il s'emploie avec un, una, unos, des nombres ou sans article "
              "(hay pan), jamais avec el / la. Question : ¿Qué hay…? (qu'y a-t-il ?) ; ¿Cuántos alumnos hay? (combien y a-t-il d'élèves ?). "
              "Négation : no hay.",
              [("En mi mochila hay un libro y dos cuadernos.", "Dans mon sac, il y a un livre et deux cahiers."),
               ("¿Cuántos alumnos hay en tu clase? — Hay cuarenta.", "Combien d'élèves y a-t-il dans ta classe ? — Il y en a quarante."),
               ("Hoy no hay clase de deporte.", "Aujourd'hui, il n'y a pas cours de sport.")]),
            G("Dire ce que l'on a : TENER (e → ie, irrégulier)",
              "Tener : tengo, tienes, tiene, tenemos, tenéis, tienen. Il sert pour les objets (tengo una regla), l'âge (tengo doce años) "
              "et l'emploi du temps (los lunes tenemos matemáticas). Tener que + infinitif = devoir : tengo que estudiar.",
              [("Tengo una regla y dos bolígrafos.", "J'ai une règle et deux stylos."),
               ("¿Tienes una goma? — No, no tengo.", "Tu as une gomme ? — Non, je n'en ai pas."),
               ("Los martes tenemos inglés.", "Le mardi, nous avons anglais."),
               ("Tengo que hacer los deberes.", "Je dois faire mes devoirs.")]),
            G("Les jours de la semaine : EL LUNES, LOS LUNES",
              "Les jours sont masculins et sans majuscule : el lunes, el martes, el miércoles, el jueves, el viernes, el sábado, el domingo. "
              "El lunes = lundi (ce lundi-là) ; los lunes = le lundi (tous les lundis). On ne met pas de préposition : "
              "« le mardi, j'ai sport » → el martes tengo deporte.",
              [("El lunes voy al colegio a las siete.", "Lundi, je vais au collège à sept heures."),
               ("Los viernes tenemos deporte.", "Le vendredi, nous avons sport."),
               ("El sábado y el domingo no hay clase.", "Samedi et dimanche, il n'y a pas cours.")]),
        ],
        "scenes": [
            S("¿Me prestas tu regla?", "Tu me prêtes ta règle ?", "aula",
              "Cours de mathématiques. Aya cherche sa règle dans son sac. Silué est assis à côté d'elle.",
              {"A": "Aya", "B": "Silué"},
              [("A", "¡Ay! No tengo mi regla. ¿Me prestas tu regla, Silué?", "Oh ! Je n'ai pas ma règle. Tu me prêtes ta règle, Silué ?"),
               ("B", "Sí, claro. Aquí tienes.", "Oui, bien sûr. Tiens."),
               ("A", "Gracias. ¿Tienes también una goma?", "Merci. Tu as aussi une gomme ?"),
               ("B", "No, no tengo goma. Pero Koffi tiene dos.", "Non, je n'ai pas de gomme. Mais Koffi en a deux."),
               ("A", "¿Qué hay en tu mochila? ¡Es enorme!", "Qu'est-ce qu'il y a dans ton sac ? Il est énorme !"),
               ("B", "Hay tres libros, cinco cuadernos y mi almuerzo.", "Il y a trois livres, cinq cahiers et mon déjeuner."),
               ("A", "¡Silencio! La profesora escribe en la pizarra.", "Silence ! La professeure écrit au tableau."),
               ("B", "Sí, sí. Vamos a trabajar.", "Oui, oui. Travaillons.")]),
            S("El horario de la semana", "L'emploi du temps de la semaine", "horario",
              "À la récréation, Koffi et Fatou regardent l'emploi du temps affiché près de la cour.",
              {"A": "Koffi", "B": "Fatou"},
              [("A", "Fatou, ¿qué tenemos el lunes?", "Fatou, qu'est-ce qu'on a lundi ?"),
               ("B", "El lunes tenemos matemáticas, francés y español.", "Lundi, on a maths, français et espagnol."),
               ("A", "¡Qué bien! El español es mi asignatura preferida.", "Super ! L'espagnol est ma matière préférée."),
               ("B", "Y el miércoles por la tarde no hay clase.", "Et mercredi après-midi, il n'y a pas cours."),
               ("A", "¿Y cuándo tenemos deporte?", "Et quand avons-nous sport ?"),
               ("B", "Los viernes, de diez a doce.", "Le vendredi, de dix heures à midi."),
               ("A", "Tengo que estudiar historia para el jueves.", "Je dois réviser l'histoire pour jeudi."),
               ("B", "Yo también. ¿Estudiamos juntos?", "Moi aussi. On révise ensemble ?")]),
        ],
        "phrases_add": [
            ("¿Me prestas tu bolígrafo?", "Tu me prêtes ton stylo ?"),
            ("¿Qué hay en tu mochila?", "Qu'y a-t-il dans ton sac ?"),
            ("Los lunes tenemos matemáticas.", "Le lundi, nous avons maths."),
            ("Mi asignatura preferida es el español.", "Ma matière préférée est l'espagnol."),
            ("Tengo que hacer los deberes.", "Je dois faire mes devoirs."),
            ("¿Puedo salir, profesora?", "Je peux sortir, madame ?"),
        ],
        "reading": R("Mi semana en el colegio", "Ma semaine au collège", [
            ("Me llamo Koffi y estudio en un colegio de Abiyán.", "Je m'appelle Koffi et j'étudie dans un collège d'Abidjan."),
            ("En mi clase hay cuarenta y cinco alumnos.", "Dans ma classe, il y a quarante-cinq élèves."),
            ("Los lunes tengo matemáticas, francés y español.", "Le lundi, j'ai maths, français et espagnol."),
            ("El miércoles por la tarde no hay clase: juego al fútbol.", "Le mercredi après-midi, il n'y a pas cours : je joue au foot."),
            ("Los viernes tenemos deporte con el profesor Yao.", "Le vendredi, nous avons sport avec le professeur Yao."),
            ("Mi asignatura preferida es el español.", "Ma matière préférée est l'espagnol."),
        ]),
        "homework": [
            H("Écris ce qu'il y a dans ton sac d'école (5 objets, avec hay).",
              "En mi mochila hay dos libros, cuatro cuadernos, un bolígrafo, una regla y una goma.", ["hay", "mochila"]),
            H("Écris ton emploi du temps de deux jours en espagnol (el lunes tengo…).",
              "El lunes tengo matemáticas y francés. El martes tengo inglés, historia y español.", ["lunes", "martes", "tengo"]),
            H("Demande poliment à un camarade de te prêter deux objets, puis remercie-le.",
              "¿Me prestas tu regla? ¿Y tu goma? ¡Muchas gracias!", ["me prestas", "gracias"]),
        ],
        "quiz_add": [
            Qx("« Il y a deux livres » :", "Hay dos libros.", ["Están dos libros.", "Hay los dos libros.", "Tiene dos libros."], "Hay est invariable et ne prend pas el / la."),
            Qx("« J'ai une règle » :", "Tengo una regla.", ["Tiengo una regla.", "Teno una regla.", "Hay una regla."], "Tener : tengo, tienes, tiene…"),
            Qx("« Le vendredi, nous avons sport » :", "Los viernes tenemos deporte.", ["En viernes tenemos deporte.", "El viernes tienemos deporte.", "Los viernes hay deportes tenemos."],
               "Tous les vendredis : los viernes, sans préposition."),
            Qx("« Je dois étudier » :", "Tengo que estudiar.", ["Tengo estudiar.", "Tengo de estudiar.", "Hay que yo estudiar."], "Tener que + infinitif = devoir."),
            Qx("Quel jour vient après el miércoles ?", "el jueves", ["el martes", "el viernes", "el lunes"]),
        ],
        "practice": [
            P("", "Mon sac et mon emploi du temps", "Complétez avec hay ou tener, puis présentez votre semaine au micro.", [
                fill("En mi mochila ___ tres cuadernos.", ["hay"], ["tiene", "está", "son"], "Dans mon sac, il y a trois cahiers."),
                fill("Yo ___ una regla nueva.", ["tengo"], ["tiene", "hay", "tienes"], "J'ai une règle neuve."),
                fill("¿___ tú una goma?", ["Tienes"], ["Tengo", "Hay", "Tiene"], "Tu as une gomme ?"),
                fill("Los viernes ___ deporte.", ["tenemos"], ["tienemos", "tengo", "hay que"], "Le vendredi, nous avons sport."),
                match([("el lunes", "lundi"), ("el martes", "mardi"), ("el miércoles", "mercredi"), ("el jueves", "jeudi"), ("el viernes", "vendredi")], "Les jours"),
                match([("la mochila", "le sac"), ("la regla", "la règle"), ("la goma", "la gomme"), ("la pizarra", "le tableau"), ("el bolígrafo", "le stylo")], "La classe"),
                order("¿Me prestas tu regla, por favor?", "Tu me prêtes ta règle, s'il te plaît ?"),
                speak("Los lunes tengo matemáticas, francés y español.", "Le lundi, j'ai maths, français et espagnol."),
                write("Présente ta semaine au collège en 5 phrases : tes matières, ta matière préférée, le jour sans cours.",
                      "Los lunes tengo matemáticas y español. Los martes tengo inglés. El miércoles por la tarde no hay clase. Los viernes tengo deporte. Mi asignatura preferida es la historia.",
                      ["tengo", "hay", "lunes", "asignatura"], 25),
            ]),
        ],
    },
    # ----------------------------------------------------------------------- Unité 7
    {
        "id": "m3-es-07", "level": "A2", "number": 7, "emoji": "🏡",
        "title": "Mi casa y mi pueblo",
        "titleTr": "Ma maison et mon village : décrire et situer",
        "intro": "Api fait visiter la maison familiale à Koffi, puis un visiteur demande son chemin sur la place du village. "
                 "Vous apprenez les pièces de la maison, les lieux du village, le verbe estar pour situer, "
                 "les prépositions de lieu (cerca de, al lado de…) et la différence entre hay et está.",
        "vocab": [
            V("la habitación", "la chambre", "Mi habitación es pequeña pero bonita.", "Ma chambre est petite mais jolie.", "🛏️"),
            V("el baño", "la salle de bains / les toilettes", "El baño está al fondo.", "La salle de bains est au fond.", "🚿"),
            V("el comedor", "la salle à manger", "Comemos en el comedor.", "Nous mangeons dans la salle à manger.", "🍽️"),
            V("la puerta", "la porte", "La puerta es azul.", "La porte est bleue.", "🚪"),
            V("la ventana", "la fenêtre", "Abre la ventana, por favor.", "Ouvre la fenêtre, s'il te plaît.", "🪟"),
            V("el pueblo", "le village", "Mi abuela vive en un pueblo cerca de Man.", "Ma grand-mère vit dans un village près de Man.", "🏘️"),
            V("la ciudad", "la ville", "Abiyán es una ciudad muy grande.", "Abidjan est une très grande ville.", "🏙️"),
            V("la plaza", "la place", "Los niños juegan en la plaza.", "Les enfants jouent sur la place.", "⛲"),
            V("el pozo", "le puits", "El pozo está detrás de la casa.", "Le puits est derrière la maison.", "🪣"),
            V("el árbol", "l'arbre", "Hay un gran árbol en el patio.", "Il y a un grand arbre dans la cour.", "🌳"),
            V("el dispensario", "le dispensaire", "El dispensario está al lado de la escuela.", "Le dispensaire est à côté de l'école.", "🏥"),
            V("la escuela", "l'école", "La escuela está cerca de la plaza.", "L'école est près de la place.", "🏫"),
            V("la mezquita / la iglesia", "la mosquée / l'église", "La mezquita está enfrente de la iglesia.", "La mosquée est en face de l'église.", "🕌"),
            V("cerca de / lejos de", "près de / loin de", "Mi casa está cerca del mercado.", "Ma maison est près du marché.", "📍"),
            V("al lado de", "à côté de", "La cocina está al lado del comedor.", "La cuisine est à côté de la salle à manger.", "↔️"),
            V("delante de / detrás de", "devant / derrière", "El coche está delante de la casa.", "La voiture est devant la maison.", "↕️"),
            V("enfrente de", "en face de", "La tienda está enfrente de la escuela.", "La boutique est en face de l'école.", "🔁"),
            V("entre… y…", "entre… et…", "El pozo está entre la casa y el árbol.", "Le puits est entre la maison et l'arbre.", "⏸️"),
        ],
        "grammar": [
            G("Situer : ESTAR",
              "Estar sert à dire où se trouve quelqu'un ou quelque chose : estoy, estás, está, estamos, estáis, están. "
              "« Où est… ? » se dit ¿Dónde está…? Ser décrit (la casa es grande), estar situe (la casa está cerca del río).",
              [("¿Dónde está el baño? — Está al fondo, a la derecha.", "Où sont les toilettes ? — Au fond, à droite."),
               ("Mis padres están en el patio.", "Mes parents sont dans la cour."),
               ("La casa es grande y está cerca del río.", "La maison est grande et elle est près de la rivière.")]),
            G("Les prépositions de lieu et DEL",
              "Cerca de, lejos de, al lado de, delante de, detrás de, enfrente de, encima de, debajo de, dentro de, entre… y…. "
              "De + el se contracte en del : al lado del mercado (mais al lado de la escuela). "
              "À + el se contracte en al : voy al pueblo.",
              [("El pozo está detrás de la casa.", "Le puits est derrière la maison."),
               ("La escuela está al lado del dispensario.", "L'école est à côté du dispensaire."),
               ("El gato está debajo de la mesa.", "Le chat est sous la table.")]),
            G("HAY ou ESTÁ ?",
              "Hay présente une chose nouvelle, avec un, una, des nombres ou sans article : en el pueblo hay un pozo. "
              "Está / están situent une chose déjà connue, avec el, la, mi, tu… : el pozo está en la plaza. "
              "On ne dit jamais « hay el pozo ».",
              [("En mi pueblo hay una escuela y un dispensario.", "Dans mon village, il y a une école et un dispensaire."),
               ("La escuela está enfrente de la plaza.", "L'école est en face de la place."),
               ("¿Hay un pozo cerca? — Sí, el pozo está detrás del árbol.", "Y a-t-il un puits près d'ici ? — Oui, le puits est derrière l'arbre.")]),
        ],
        "scenes": [
            S("Bienvenido a mi casa", "Bienvenue chez moi", "casa",
              "Koffi rend visite à Api pour la première fois. Api lui montre la maison de la famille d'Abolé.",
              {"A": "Api", "B": "Koffi"},
              [("A", "¡Pasa, Koffi! Bienvenido a mi casa.", "Entre, Koffi ! Bienvenue chez moi."),
               ("B", "Gracias, Api. ¡Tu casa es muy bonita!", "Merci, Api. Ta maison est très jolie !"),
               ("A", "Mira, aquí está el salón y allí está la cocina.", "Regarde, ici c'est le salon et là-bas c'est la cuisine."),
               ("B", "¿Y dónde está tu habitación?", "Et où est ta chambre ?"),
               ("A", "Está al lado de la habitación de Yéli.", "Elle est à côté de la chambre de Yéli."),
               ("B", "¿Hay un patio?", "Il y a une cour ?"),
               ("A", "Sí, el patio está detrás de la casa. Hay un mango muy grande.", "Oui, la cour est derrière la maison. Il y a un très grand manguier."),
               ("B", "¡Qué bien! ¿Jugamos debajo del árbol?", "Super ! On joue sous l'arbre ?")]),
            S("En la plaza del pueblo", "Sur la place du village", "place",
              "Un visiteur arrive au village et demande son chemin à Adou, qui revient du puits.",
              {"A": "Visitante", "B": "Adou"},
              [("A", "Perdón, ¿dónde está el dispensario?", "Pardon, où est le dispensaire ?"),
               ("B", "Está cerca. Al lado de la escuela.", "C'est tout près. À côté de l'école."),
               ("A", "¿Y la escuela? ¿Está lejos?", "Et l'école ? C'est loin ?"),
               ("B", "No, está enfrente de la mezquita, a cinco minutos.", "Non, elle est en face de la mosquée, à cinq minutes."),
               ("A", "¿Hay una tienda en el pueblo?", "Y a-t-il une boutique au village ?"),
               ("B", "Sí, hay una tienda entre el pozo y el gran árbol.", "Oui, il y a une boutique entre le puits et le grand arbre."),
               ("A", "Muchas gracias, joven.", "Merci beaucoup, jeune homme."),
               ("B", "De nada, señor. ¡Bienvenido al pueblo!", "De rien, monsieur. Bienvenue au village !")]),
        ],
        "phrases_add": [
            ("¿Dónde está el baño, por favor?", "Où sont les toilettes, s'il vous plaît ?"),
            ("Mi casa está cerca del mercado.", "Ma maison est près du marché."),
            ("En mi pueblo hay un pozo y una escuela.", "Dans mon village, il y a un puits et une école."),
            ("Está al lado de la mezquita.", "C'est à côté de la mosquée."),
            ("¿Está lejos de aquí?", "C'est loin d'ici ?"),
            ("Bienvenido a mi casa.", "Bienvenue chez moi."),
        ],
        "reading": R("El pueblo de mis abuelos", "Le village de mes grands-parents", [
            ("Mis abuelos viven en un pueblo cerca de Korhogo.", "Mes grands-parents vivent dans un village près de Korhogo."),
            ("Su casa es pequeña y está al lado de un río.", "Leur maison est petite et elle est à côté d'une rivière."),
            ("Delante de la casa hay un gran árbol.", "Devant la maison, il y a un grand arbre."),
            ("El pozo está detrás de la cocina.", "Le puits est derrière la cuisine."),
            ("En el centro del pueblo hay una plaza, una escuela y un mercado.", "Au centre du village, il y a une place, une école et un marché."),
            ("Por la tarde, los vecinos hablan debajo del árbol.", "L'après-midi, les voisins discutent sous l'arbre."),
        ]),
        "homework": [
            H("Décris ta maison en 5 phrases : les pièces et où elles se trouvent (está al lado de…).",
              "Mi casa tiene un salón, una cocina y tres habitaciones. La cocina está al lado del salón. Mi habitación está enfrente del baño. Hay un patio detrás de la casa.",
              ["está", "al lado de", "hay", "habitación"]),
            H("Dessine le plan de ton quartier ou de ton village et écris 4 phrases pour situer les lieux.",
              "La escuela está cerca de la plaza. El mercado está al lado de la mezquita. El dispensario está enfrente de la escuela. Mi casa está lejos del mercado.",
              ["cerca de", "al lado de", "enfrente de", "está"]),
            H("Écris un mini-dialogue : quelqu'un demande où est un lieu, tu réponds.",
              "— Perdón, ¿dónde está el mercado? — Está cerca, al lado de la plaza. — Gracias. — De nada.", ["dónde está", "está"]),
        ],
        "quiz_add": [
            Qx("« Où est l'école ? »", "¿Dónde está la escuela?", ["¿Dónde es la escuela?", "¿Dónde hay la escuela?", "¿Dónde están la escuela?"], "Pour situer : estar."),
            Qx("« À côté du marché » :", "al lado del mercado", ["al lado de el mercado", "a lado del mercado", "al lado mercado"], "de + el = del."),
            Qx("« Dans mon village, il y a un puits » :", "En mi pueblo hay un pozo.", ["En mi pueblo está un pozo.", "En mi pueblo hay el pozo.", "En mi pueblo es un pozo."],
               "Chose présentée pour la première fois : hay + un."),
            Qx("« Le puits est derrière la maison » :", "El pozo está detrás de la casa.", ["El pozo hay detrás de la casa.", "El pozo es detrás de la casa.", "El pozo está detrás la casa."],
               "Chose connue (el pozo) : está ; detrás de."),
            Qx("Le contraire de cerca de :", "lejos de", ["al lado de", "delante de", "entre"]),
        ],
        "practice": [
            P("", "Situer dans la maison et au village", "Choisissez entre hay et está, complétez les prépositions puis décrivez votre maison.", [
                fill("En la casa ___ tres habitaciones.", ["hay"], ["está", "están", "es"], "Dans la maison, il y a trois chambres."),
                fill("La cocina ___ al lado del comedor.", ["está"], ["hay", "es", "están"], "La cuisine est à côté de la salle à manger."),
                fill("Mis padres ___ en el patio.", ["están"], ["hay", "son", "está"], "Mes parents sont dans la cour."),
                fill("La escuela está cerca ___ mercado.", ["del"], ["de el", "al", "de la"], "L'école est près du marché."),
                fill("El gato está ___ de la mesa.", ["debajo"], ["dentro", "entre", "lejos"], "Le chat est sous la table."),
                match([("cerca de", "près de"), ("lejos de", "loin de"), ("al lado de", "à côté de"), ("delante de", "devant"), ("detrás de", "derrière")], "Où ?"),
                order("La mezquita está enfrente de la iglesia.", "La mosquée est en face de l'église."),
                speak("Perdón, ¿dónde está el dispensario?", "Pardon, où est le dispensaire ?"),
                write("Décris ta maison ou ton village en 5 phrases avec hay et está.",
                      "Mi pueblo es pequeño. Hay una escuela y un mercado. La escuela está cerca de la plaza. El pozo está detrás de mi casa. Mi casa está al lado de un gran árbol.",
                      ["hay", "está", "cerca de", "al lado de"], 25),
            ]),
        ],
    },
    # ----------------------------------------------------------------------- Unité 8
    {
        "id": "m3-es-08", "level": "A2", "number": 8, "emoji": "🎉",
        "title": "La comida y la fiesta",
        "titleTr": "Les repas, les goûts et la fête",
        "intro": "Fatou et Aya parlent de ce qu'elles aiment manger, puis toute la famille d'Abolé fête l'anniversaire de Yéli. "
                 "Vous apprenez les repas de la journée, les plats et les boissons, le verbe gustar pour dire ce que vous aimez, "
                 "et les mots de la fête.",
        "vocab": [
            V("el desayuno", "le petit déjeuner", "En el desayuno tomo pan y té.", "Au petit déjeuner, je prends du pain et du thé.", "🥣"),
            V("el almuerzo", "le déjeuner", "El almuerzo es a la una.", "Le déjeuner est à une heure.", "🍛"),
            V("la cena", "le dîner", "La cena es a las ocho de la noche.", "Le dîner est à huit heures du soir.", "🍲"),
            V("el pollo", "le poulet", "Me gusta el pollo con attiéké.", "J'aime le poulet avec de l'attiéké.", "🍗"),
            V("la carne", "la viande", "Mi padre no come carne los viernes.", "Mon père ne mange pas de viande le vendredi.", "🥩"),
            V("la salsa", "la sauce", "La salsa de cacahuete está muy rica.", "La sauce arachide est très bonne.", "🥜"),
            V("la fruta", "les fruits", "La fruta es buena para la salud.", "Les fruits sont bons pour la santé.", "🍉"),
            V("el agua", "l'eau", "El agua está fría.", "L'eau est fraîche.", "💧"),
            V("el zumo", "le jus", "Quiero un zumo de mango.", "Je veux un jus de mangue.", "🧃"),
            V("me gusta / me gustan", "j'aime (une chose / des choses)", "Me gusta el arroz. Me gustan las naranjas.", "J'aime le riz. J'aime les oranges.", "😋"),
            V("no me gusta", "je n'aime pas", "No me gusta el pescado frito.", "Je n'aime pas le poisson frit.", "🙅"),
            V("me encanta", "j'adore", "¡Me encanta el alloco!", "J'adore l'alloco !", "😍"),
            V("rico / rica", "bon / bonne (au goût)", "¡Qué rico está el pollo!", "Qu'il est bon, ce poulet !", "👌"),
            V("la fiesta", "la fête", "Hay una fiesta en casa de Api.", "Il y a une fête chez Api.", "🎉"),
            V("el cumpleaños", "l'anniversaire", "Hoy es el cumpleaños de Yéli.", "Aujourd'hui, c'est l'anniversaire de Yéli.", "🎂"),
            V("el regalo", "le cadeau", "Tengo un regalo para ti.", "J'ai un cadeau pour toi.", "🎁"),
            V("bailar", "danser", "Nos gusta bailar en las fiestas.", "Nous aimons danser aux fêtes.", "💃🏾"),
            V("cantar", "chanter", "Todos cantan «Cumpleaños feliz».", "Tout le monde chante « Joyeux anniversaire ».", "🎤"),
            V("¡Feliz cumpleaños!", "Joyeux anniversaire !", "¡Feliz cumpleaños, Yéli!", "Joyeux anniversaire, Yéli !", "🥳"),
        ],
        "grammar": [
            G("Dire ce que l'on aime : GUSTAR",
              "Gustar se construit à l'envers du français : la chose aimée est le sujet. "
              "Me gusta + nom singulier ou infinitif (me gusta el pollo, me gusta bailar) ; me gustan + nom pluriel (me gustan las frutas). "
              "Les pronoms changent selon la personne : me, te, le, nos, os, les. Encantar se construit pareil : me encanta.",
              [("Me gusta el attiéké con pescado.", "J'aime l'attiéké avec du poisson."),
               ("¿Te gustan los plátanos? — Sí, me encantan.", "Tu aimes les bananes ? — Oui, j'adore."),
               ("A mi padre le gusta cantar.", "Mon père aime chanter."),
               ("Nos gusta bailar en las fiestas.", "Nous aimons danser aux fêtes.")]),
            G("Être d'accord ou non : A MÍ TAMBIÉN, A MÍ TAMPOCO",
              "Pour répondre à une phrase avec gustar : à une phrase affirmative, a mí también (moi aussi) ou a mí no (pas moi) ; "
              "à une phrase négative, a mí tampoco (moi non plus) ou a mí sí (moi si).",
              [("Me gusta el zumo de mango. — A mí también.", "J'aime le jus de mangue. — Moi aussi."),
               ("No me gusta la carne. — A mí tampoco.", "Je n'aime pas la viande. — Moi non plus."),
               ("Me gusta el pescado. — A mí no.", "J'aime le poisson. — Pas moi.")]),
            G("Manger et boire : COMER, BEBER (verbes en -ER)",
              "Les verbes réguliers en -er prennent : -o, -es, -e, -emos, -éis, -en. Como, comes, come, comemos, coméis, comen ; "
              "bebo, bebes, bebe… Tomar (prendre) s'emploie aussi pour les repas et les boissons : tomo un zumo.",
              [("Comemos arroz todos los días.", "Nous mangeons du riz tous les jours."),
               ("¿Qué bebes en el desayuno? — Bebo té.", "Que bois-tu au petit déjeuner ? — Je bois du thé."),
               ("Mis hermanos comen mucha fruta.", "Mes frères mangent beaucoup de fruits.")]),
        ],
        "scenes": [
            S("¿Qué te gusta comer?", "Qu'aimes-tu manger ?", "comida",
              "Pendant le déjeuner chez Fatou, les deux amies parlent de leurs plats préférés.",
              {"A": "Fatou", "B": "Aya"},
              [("A", "Aya, ¿qué te gusta comer?", "Aya, qu'est-ce que tu aimes manger ?"),
               ("B", "Me encanta el attiéké con pescado. ¿Y a ti?", "J'adore l'attiéké au poisson. Et toi ?"),
               ("A", "A mí también. Y me gusta mucho el alloco.", "Moi aussi. Et j'aime beaucoup l'alloco."),
               ("B", "¿Te gusta la carne?", "Tu aimes la viande ?"),
               ("A", "No, no me gusta mucho la carne.", "Non, je n'aime pas trop la viande."),
               ("B", "A mí tampoco. Prefiero el pollo.", "Moi non plus. Je préfère le poulet."),
               ("A", "¿Qué bebes en el almuerzo?", "Que bois-tu au déjeuner ?"),
               ("B", "Bebo agua o un zumo de mango. ¡Mmm, qué rico!", "Je bois de l'eau ou un jus de mangue. Mmm, c'est bon !")]),
            S("¡Feliz cumpleaños, Yéli!", "Joyeux anniversaire, Yéli !", "fete",
              "Samedi soir, la famille d'Abolé et les amis fêtent les onze ans de Yéli dans la cour.",
              {"A": "Abolé", "B": "Yéli"},
              [("A", "¡Feliz cumpleaños, hija! Hoy tienes once años.", "Joyeux anniversaire, ma fille ! Aujourd'hui, tu as onze ans."),
               ("B", "¡Gracias, papá! ¡Qué fiesta tan bonita!", "Merci, papa ! Quelle belle fête !"),
               ("A", "Mira, aquí tienes un regalo de tu madre y de mí.", "Regarde, voici un cadeau de ta mère et de moi."),
               ("B", "¡Un paño nuevo! ¡Me encanta! Muchas gracias.", "Un pagne neuf ! J'adore ! Merci beaucoup."),
               ("A", "Ahora todos cantamos y después comemos el pastel.", "Maintenant, on chante tous et après on mange le gâteau."),
               ("B", "¿Y bailamos también?", "Et on danse aussi ?"),
               ("A", "¡Claro! A tu abuelo le gusta mucho bailar.", "Bien sûr ! Ton grand-père aime beaucoup danser."),
               ("B", "¡Es el mejor cumpleaños de mi vida!", "C'est le meilleur anniversaire de ma vie !")]),
        ],
        "phrases_add": [
            ("¿Qué te gusta comer?", "Qu'aimes-tu manger ?"),
            ("Me encanta el attiéké con pescado.", "J'adore l'attiéké au poisson."),
            ("No me gusta mucho la carne.", "Je n'aime pas trop la viande."),
            ("A mí también. / A mí tampoco.", "Moi aussi. / Moi non plus."),
            ("¡Qué rico está!", "Comme c'est bon !"),
            ("¡Feliz cumpleaños!", "Joyeux anniversaire !"),
        ],
        "reading": R("Un domingo en familia", "Un dimanche en famille", [
            ("El domingo, toda la familia come junta.", "Le dimanche, toute la famille mange ensemble."),
            ("En el desayuno, tomamos pan, té y fruta.", "Au petit déjeuner, nous prenons du pain, du thé et des fruits."),
            ("Para el almuerzo, mi madre prepara arroz con salsa de cacahuete.", "Pour le déjeuner, ma mère prépare du riz à la sauce arachide."),
            ("A mi padre le gusta mucho el pollo.", "Mon père aime beaucoup le poulet."),
            ("A mis hermanos les gustan los plátanos fritos.", "Mes frères aiment les bananes frites."),
            ("Por la noche, cenamos poco y escuchamos los cuentos del abuelo.", "Le soir, nous dînons peu et nous écoutons les contes du grand-père."),
        ]),
        "homework": [
            H("Écris 5 phrases sur tes goûts avec me gusta, me gustan, no me gusta et me encanta.",
              "Me gusta el arroz. Me gustan las naranjas. No me gusta la carne. Me encanta el alloco. Me gusta bailar.",
              ["me gusta", "me gustan", "no me gusta", "me encanta"]),
            H("Raconte tes trois repas d'une journée (desayuno, almuerzo, cena).",
              "En el desayuno tomo pan y té. En el almuerzo como arroz con pescado. En la cena como attiéké y bebo agua.",
              ["desayuno", "almuerzo", "cena", "como"]),
            H("Écris une carte d'anniversaire pour un ami (4 phrases).",
              "¡Feliz cumpleaños, Koffi! Hoy tienes trece años. Aquí tienes un regalo. ¡Vamos a bailar en la fiesta!",
              ["feliz cumpleaños", "tienes", "regalo"]),
        ],
        "quiz_add": [
            Qx("« J'aime les oranges » :", "Me gustan las naranjas.", ["Me gusta las naranjas.", "Yo gusto las naranjas.", "Me gustan naranjas las."],
               "Nom pluriel : me gustan."),
            Qx("« J'aime danser » :", "Me gusta bailar.", ["Me gustan bailar.", "Yo gusto bailar.", "Me gusto bailar."], "Infinitif : me gusta (singulier)."),
            Qx("« Je n'aime pas la viande. — Moi non plus. »", "No me gusta la carne. — A mí tampoco.", ["No me gusta la carne. — A mí también.", "No me gusta la carne. — Yo no también.", "No me gusta la carne. — A mí sí tampoco."],
               "Après une phrase négative : a mí tampoco."),
            Qx("« Mon père aime chanter » :", "A mi padre le gusta cantar.", ["Mi padre gusta cantar.", "A mi padre me gusta cantar.", "A mi padre les gusta cantar."],
               "Pour il / elle : le gusta."),
            Qx("Quel repas prend-on le soir ?", "la cena", ["el desayuno", "el almuerzo", "el recreo"]),
        ],
        "practice": [
            P("", "Mes goûts et la fête", "Gustar au singulier ou au pluriel, d'accord ou pas d'accord, puis la fête au micro.", [
                fill("Me ___ el pollo.", ["gusta"], ["gustan", "gusto", "gustas"], "J'aime le poulet."),
                fill("Me ___ los plátanos fritos.", ["gustan"], ["gusta", "gusto", "gustamos"], "J'aime les bananes frites."),
                fill("¿___ gusta bailar, Aya?", ["Te"], ["Me", "Tu", "Le"], "Tu aimes danser, Aya ?"),
                fill("A mis hermanos ___ gusta el fútbol.", ["les"], ["le", "nos", "me"], "Mes frères aiment le foot."),
                fill("No me gusta la carne. — A mí ___.", ["tampoco"], ["también", "sí", "no"], "Je n'aime pas la viande. — Moi non plus."),
                match([("el desayuno", "le petit déjeuner"), ("el almuerzo", "le déjeuner"), ("la cena", "le dîner"), ("el zumo", "le jus"), ("el regalo", "le cadeau")]),
                order("¡Feliz cumpleaños! Aquí tienes un regalo.", "Joyeux anniversaire ! Voici un cadeau."),
                speak("Me encanta el attiéké con pescado. ¿Y a ti?", "J'adore l'attiéké au poisson. Et toi ?"),
                write("Présente tes goûts : deux plats que tu aimes, un que tu n'aimes pas, ta boisson préférée et ce que tu fais aux fêtes.",
                      "Me gusta mucho el arroz con salsa. Me encantan los plátanos. No me gusta el pescado frito. Mi bebida preferida es el zumo de mango. En las fiestas me gusta bailar.",
                      ["me gusta", "no me gusta", "me encanta"], 25),
            ]),
        ],
    },
]

# =============================================================================== Ajouts aux leçons existantes

def A(vocab=(), grammar=(), phrases=()):
    return {"vocab": list(vocab), "grammar": list(grammar), "phrases_add": list(phrases)}


ADD = {
    # ---------------------------------------------------------------------------------- MODEL 3
    "m3-es-01": A(
        [V("¿De dónde eres?", "D'où es-tu ?", "¿De dónde eres, Silué? — Soy de Korhogo.", "D'où es-tu, Silué ? — Je suis de Korhogo.", "🗺️"),
         V("el señor / la señora", "monsieur / madame", "Buenos días, señora Koné.", "Bonjour, madame Koné.", "🧑🏾‍💼"),
         V("el amigo / la amiga", "l'ami / l'amie", "Aya es mi amiga.", "Aya est mon amie.", "🫂"),
         V("Por favor", "S'il te plaît / S'il vous plaît", "Una regla, por favor.", "Une règle, s'il te plaît.", "🙏"),
         V("Gracias / De nada", "Merci / De rien", "¡Gracias, Koffi! — De nada.", "Merci, Koffi ! — De rien.", "😊"),
         V("Perdón", "Pardon", "Perdón, ¿eres Silué?", "Pardon, tu es Silué ?", "🙇")],
        [G("Le verbe SER au présent et les pronoms sujets",
           "Ser (être, pour l'identité et l'origine) : yo soy, tú eres, él / ella / usted es, nosotros somos, vosotros sois, "
           "ellos / ellas / ustedes son. En espagnol, on omet souvent le pronom, car la terminaison suffit : soy de Man = je suis de Man. "
           "Usted (vous de politesse) se conjugue comme él : usted es.",
           [("Soy Koffi y soy de Abiyán.", "Je suis Koffi et je suis d'Abidjan."),
            ("¿Eres de Bouaké? — No, soy de Man.", "Tu es de Bouaké ? — Non, je suis de Man."),
            ("Somos compañeros de clase.", "Nous sommes camarades de classe."),
            ("¿Es usted el profesor de español?", "Êtes-vous le professeur d'espagnol ?")])],
        [("¿De dónde eres?", "D'où es-tu ?"), ("Mucho gusto, señora.", "Enchanté, madame."), ("Gracias. — De nada.", "Merci. — De rien.")]),
    "m3-es-02": A(
        [V("los hermanos", "les frères et sœurs", "Tengo tres hermanos: dos chicos y una chica.", "J'ai trois frères et sœurs : deux garçons et une fille.", "👫"),
         V("el bebé", "le bébé", "El bebé tiene seis meses.", "Le bébé a six mois.", "👶🏾"),
         V("negro / negra", "noir / noire", "Tengo el pelo negro.", "J'ai les cheveux noirs.", "⚫"),
         V("simpático / simpática", "sympathique, gentil", "Mi tía es muy simpática.", "Ma tante est très sympathique.", "😄"),
         V("el pelo corto / largo", "les cheveux courts / longs", "Yéli tiene el pelo largo.", "Yéli a les cheveux longs.", "💇🏾‍♀️"),
         V("llevar", "porter (un vêtement)", "Fatou lleva un paño verde.", "Fatou porte un pagne vert.", "👗")],
        [G("Les possessifs : MI, TU, SU",
           "Devant le nom : mi (mon, ma), tu (ton, ta), su (son, sa, leur, votre de politesse) ; au pluriel : mis, tus, sus. "
           "Ils ne varient pas au féminin : mi padre, mi madre. Nuestro / nuestra (notre) s'accorde : nuestra familia, nuestros hijos.",
           [("Mi padre se llama Abolé y mi madre se llama Fatou.", "Mon père s'appelle Abolé et ma mère s'appelle Fatou."),
            ("¿Cómo se llaman tus hermanos?", "Comment s'appellent tes frères et sœurs ?"),
            ("Api vive con sus padres y sus hermanos.", "Api vit avec ses parents et ses frères et sœurs."),
            ("Nuestra familia es grande.", "Notre famille est grande.")])],
        [("Tengo dos hermanos y una hermana.", "J'ai deux frères et une sœur."), ("Mi abuela es muy simpática.", "Ma grand-mère est très sympathique."),
         ("¿Cuántos hermanos tienes?", "Combien de frères et sœurs as-tu ?")]),
    "m3-es-03": A(
        [V("trabajar", "travailler", "Los padres trabajan en el campo.", "Les parents travaillent au champ.", "👨🏾‍🌾"),
         V("el machete", "la machette", "El padre lleva su machete.", "Le père porte sa machette.", "🔪"),
         V("el árbol", "l'arbre", "Kadjo está debajo de un árbol.", "Kadjo est sous un arbre.", "🌳"),
         V("llorar", "pleurer", "El niño llora en la selva.", "L'enfant pleure dans la forêt.", "😢"),
         V("tener miedo", "avoir peur", "Kadjo tiene mucho miedo.", "Kadjo a très peur.", "😨"),
         V("volver a casa", "rentrer à la maison", "Al final, Kadjo vuelve a casa.", "À la fin, Kadjo rentre à la maison.", "🏠")],
        [G("Le verbe IR au présent : aller",
           "Ir est très irrégulier : voy, vas, va, vamos, vais, van. On dit ir a + lieu : voy al campo (a + el = al), "
           "vamos a la escuela. Vamos peut aussi vouloir dire « allons-y ». Pour refuser : no voy (je n'y vais pas).",
           [("Kadjo, vamos al campo.", "Kadjo, allons au champ."),
            ("No, papá; no voy.", "Non, papa ; je n'y vais pas."),
            ("Los niños van a la escuela.", "Les enfants vont à l'école."),
            ("¿Adónde vas? — Voy al mercado.", "Où vas-tu ? — Je vais au marché.")])],
        [("Hay que escuchar a los padres.", "Il faut écouter ses parents."), ("Kadjo tiene miedo.", "Kadjo a peur."),
         ("Vamos al campo con papá.", "Allons au champ avec papa.")]),
    "m3-es-04": A(
        [V("más", "plus", "Dos más dos son cuatro.", "Deux plus deux font quatre.", "➕"),
         V("menos", "moins", "Diez menos tres son siete.", "Dix moins trois font sept.", "➖"),
         V("por", "fois (multiplié par)", "Tres por cinco son quince.", "Trois fois cinq font quinze.", "✖️"),
         V("entre", "divisé par", "Veinte entre cuatro son cinco.", "Vingt divisé par quatre font cinq.", "➗"),
         V("la docena", "la douzaine", "Una docena de huevos.", "Une douzaine d'œufs.", "🥚"),
         V("contar", "compter", "Cuenta de diez en diez.", "Compte de dix en dix.", "🔢")],
        [G("Calculer : MÁS, MENOS, POR, ENTRE… SON",
           "Pour une opération, on emploie son (font) : dos más tres son cinco. Les signes se lisent más (+), menos (−), "
           "por (×), entre ou dividido por (÷), es igual a (=). Pour un seul résultat « un », on dit es uno : tres menos dos es uno.",
           [("Cuatro más seis son diez.", "Quatre plus six font dix."),
            ("Cien menos veinte son ochenta.", "Cent moins vingt font quatre-vingts."),
            ("Siete por ocho son cincuenta y seis.", "Sept fois huit font cinquante-six."),
            ("Mil entre diez son cien.", "Mille divisé par dix font cent.")])],
        [("¿Cuánto son dos más dos?", "Combien font deux plus deux ?"), ("Mi número de teléfono es el cero siete, veinte, treinta y uno.", "Mon numéro est le 07 20 31."),
         ("Cuesta dos mil quinientos francos.", "Ça coûte deux mille cinq cents francs.")]),

    # ---------------------------------------------------------------------------------- MODEL 2
    "m2-es-01": A(
        [V("la consonante", "la consonne", "La «ñ» es una consonante española.", "Le « ñ » est une consonne espagnole.", "🔠"),
         V("la sílaba", "la syllabe", "«Ca-sa» tiene dos sílabas.", "« Ca-sa » a deux syllabes.", "✂️"),
         V("la palabra", "le mot", "¿Qué significa esta palabra?", "Que veut dire ce mot ?", "💬"),
         V("en voz alta", "à voix haute", "Lee el texto en voz alta.", "Lis le texte à voix haute.", "📢"),
         V("despacio", "lentement", "Habla más despacio, por favor.", "Parle plus lentement, s'il te plaît.", "🐢")],
        [G("Les sons difficiles : J, G, LL, Ñ, RR",
           "La j (et la g devant e, i) se prononce comme un h raclé au fond de la gorge : José, gente. La ll et la y se prononcent « y » : "
           "llave, yo. La ñ = « gn » : niño. La rr (et le r en début de mot) est roulée plusieurs fois : perro, rosa ; "
           "le r simple entre voyelles est battu une fois : pero (mais) ≠ perro (chien).",
           [("El jardín de Jorge es grande.", "Le jardin de Jorge est grand."),
            ("La llave está en la calle.", "La clé est dans la rue."),
            ("El perro corre por la carretera.", "Le chien court sur la route."),
            ("Mañana voy a España.", "Demain, je vais en Espagne.")])],
        [("¿Puede repetir, por favor?", "Pouvez-vous répéter, s'il vous plaît ?"), ("¿Cómo se pronuncia esta palabra?", "Comment se prononce ce mot ?"),
         ("Hable más despacio, por favor.", "Parlez plus lentement, s'il vous plaît.")]),
    "m2-es-02": A(
        [V("el doble", "le double", "Diez es el doble de cinco.", "Dix est le double de cinq.", "✌️"),
         V("la docena", "la douzaine", "Compro una docena de huevos.", "J'achète une douzaine d'œufs.", "🥚"),
         V("cuarto / cuarta", "quatrième", "Vivo en el cuarto piso.", "J'habite au quatrième étage.", "4️⃣"),
         V("quinto / quinta", "cinquième", "Mi hermana está en quinto curso.", "Ma sœur est en cinquième année.", "5️⃣"),
         V("el resultado", "le résultat", "El resultado es noventa y nueve.", "Le résultat est quatre-vingt-dix-neuf.", "🧮")],
        [G("Les opérations : MÁS, MENOS, POR, ENTRE",
           "On lit les opérations avec son (font) : dos más dos son cuatro. Signes : más (+), menos (−), por (×), entre (÷), "
           "es igual a (=). Les pourcentages se disent por ciento : el diez por ciento.",
           [("Dos más dos son cuatro.", "Deux plus deux font quatre."),
            ("Cincuenta menos ocho son cuarenta y dos.", "Cinquante moins huit font quarante-deux."),
            ("Seis por siete son cuarenta y dos.", "Six fois sept font quarante-deux."),
            ("El veinte por ciento de los alumnos ganó un premio.", "Vingt pour cent des élèves ont gagné un prix.")])],
        [("Quedé en segundo lugar.", "Je suis arrivé deuxième."), ("¿Cuánto son seis por siete?", "Combien font six fois sept ?"),
         ("Es la tercera vez que gano.", "C'est la troisième fois que je gagne.")]),
    "m2-es-03": A(
        [V("el problema", "le problème", "El problema es difícil.", "Le problème est difficile.", "❓"),
         V("la foto", "la photo", "Las fotos de la fiesta son bonitas.", "Les photos de la fête sont jolies.", "📷"),
         V("la radio", "la radio", "Escucho la radio por la mañana.", "J'écoute la radio le matin.", "📻"),
         V("el agua", "l'eau", "El agua del pozo está fría.", "L'eau du puits est fraîche.", "💧"),
         V("el sofá", "le canapé", "Los sofás del salón son nuevos.", "Les canapés du salon sont neufs.", "🛋️")],
        [G("EL AGUA, EL ÁGUILA : un nom féminin avec EL",
           "Devant un nom féminin singulier qui commence par a ou ha accentués, on met el (et un) pour éviter deux a qui se suivent : "
           "el agua, el águila, el hambre. Le nom reste féminin : el agua fría, et au pluriel on revient à las : las aguas.",
           [("El agua está fría.", "L'eau est fraîche."),
            ("Las aguas del río son limpias.", "Les eaux de la rivière sont propres."),
            ("El águila vuela muy alto.", "L'aigle vole très haut."),
            ("Tengo mucha hambre.", "J'ai très faim.")])],
        [("Los problemas de matemáticas son fáciles.", "Les problèmes de maths sont faciles."), ("Las fotos están en la mesa.", "Les photos sont sur la table."),
         ("El agua está fría.", "L'eau est fraîche.")]),
    "m2-es-04": A(
        [V("moderno / moderna", "moderne", "Es un edificio moderno.", "C'est un bâtiment moderne.", "🏢"),
         V("antiguo / antigua", "ancien / ancienne", "La mezquita de Kong es muy antigua.", "La mosquée de Kong est très ancienne.", "🕌"),
         V("limpio / limpia", "propre", "La cocina está limpia.", "La cuisine est propre.", "✨"),
         V("bonito / bonita", "joli / jolie", "Tienes una casa muy bonita.", "Tu as une très jolie maison.", "🌺"),
         V("grande / gran", "grand / grande", "Abiyán es una gran ciudad.", "Abidjan est une grande ville.", "🏙️")],
        [G("GRANDE → GRAN, BUENO → BUEN, MALO → MAL",
           "Devant un nom singulier, grande devient gran (masculin et féminin) et prend souvent le sens de « grand, important » : "
           "una gran ciudad. Bueno et malo perdent leur o devant un nom masculin singulier : un buen libro, un mal día ; "
           "mais una buena idea. Après le nom, ils gardent leur forme complète : un libro bueno.",
           [("Es una casa grande.", "C'est une grande maison (de grande taille)."),
            ("Houphouët-Boigny fue un gran presidente.", "Houphouët-Boigny fut un grand président."),
            ("Hoy es un buen día.", "Aujourd'hui est un bon jour."),
            ("Es una buena idea.", "C'est une bonne idée.")])],
        [("Tu casa es muy bonita.", "Ta maison est très jolie."), ("Es una gran ciudad.", "C'est une grande ville."),
         ("¡Qué buena idea!", "Quelle bonne idée !")]),
    "m2-es-05": A(
        [V("el apellido", "le nom de famille", "Mi apellido es Kouassi.", "Mon nom de famille est Kouassi.", "🪪"),
         V("la edad", "l'âge", "¿Qué edad tienes?", "Quel âge as-tu ?", "🎂"),
         V("casado / casada", "marié / mariée", "Mi hermano está casado.", "Mon frère est marié.", "💍"),
         V("soltero / soltera", "célibataire", "Soy soltera.", "Je suis célibataire.", "🙋🏾‍♀️"),
         V("el correo electrónico", "l'adresse e-mail", "¿Cuál es tu correo electrónico?", "Quelle est ton adresse e-mail ?", "📧")],
        [G("Se présenter avec SER, ESTAR et TENER",
           "Ser pour l'identité, la nationalité et le métier : soy marfileño, soy enfermera. Estar pour la situation civile : "
           "estoy casado / soltero (on entend aussi soy soltero). Tener pour l'âge : tengo veinticinco años. "
           "Llamarse pour le prénom, et mi apellido es… pour le nom de famille.",
           [("Me llamo Aya y mi apellido es Kouassi.", "Je m'appelle Aya et mon nom de famille est Kouassi."),
            ("Soy enfermera y estoy casada.", "Je suis infirmière et je suis mariée."),
            ("Tengo veinticinco años y vivo en Yamusukro.", "J'ai vingt-cinq ans et je vis à Yamoussoukro.")])],
        [("¿Cuál es tu apellido?", "Quel est ton nom de famille ?"), ("Tengo veinticinco años.", "J'ai vingt-cinq ans."),
         ("Encantado de conocerte.", "Ravi de te connaître.")]),
    "m2-es-06": A(
        [V("la nariz", "le nez", "Tiene la nariz pequeña.", "Il a le nez petit.", "👃🏾"),
         V("la boca", "la bouche", "Abre la boca, por favor.", "Ouvre la bouche, s'il te plaît.", "👄"),
         V("las orejas", "les oreilles", "El elefante tiene orejas grandes.", "L'éléphant a de grandes oreilles.", "👂🏾"),
         V("el brazo", "le bras", "Me duele el brazo.", "J'ai mal au bras.", "💪🏾"),
         V("la pierna", "la jambe", "El atleta tiene piernas largas.", "L'athlète a de longues jambes.", "🦵🏾")],
        [G("Comparer : MÁS… QUE, MENOS… QUE, TAN… COMO",
           "Supériorité : más + adjectif + que ; infériorité : menos + adjectif + que ; égalité : tan + adjectif + como. "
           "Irréguliers : mejor (meilleur), peor (pire), mayor (plus âgé), menor (plus jeune).",
           [("Mi hermano es más alto que yo.", "Mon frère est plus grand que moi."),
            ("Aya es tan simpática como su madre.", "Aya est aussi sympathique que sa mère."),
            ("Mi abuelo es menos deportivo que mi padre.", "Mon grand-père est moins sportif que mon père."),
            ("Mi hermana mayor tiene veinte años.", "Ma sœur aînée a vingt ans.")])],
        [("Me parezco a mi madre.", "Je ressemble à ma mère."), ("Es más alto que su padre.", "Il est plus grand que son père."),
         ("Tiene los ojos negros y el pelo corto.", "Il a les yeux noirs et les cheveux courts.")]),
    "m2-es-07": A(
        [V("lavarse los dientes", "se brosser les dents", "Me lavo los dientes después de comer.", "Je me brosse les dents après avoir mangé.", "🪥"),
         V("ir a pie", "aller à pied", "Voy al colegio a pie.", "Je vais au collège à pied.", "🚶🏾"),
         V("hacer los deberes", "faire ses devoirs", "Hago los deberes antes de cenar.", "Je fais mes devoirs avant de dîner.", "📝"),
         V("barrer", "balayer", "Los sábados barro el patio.", "Le samedi, je balaie la cour.", "🧹"),
         V("ver la tele", "regarder la télé", "Por la noche vemos la tele.", "Le soir, nous regardons la télé.", "📺")],
        [G("Dire l'heure d'une action : A LA UNA, A LAS…",
           "Pour l'heure d'une action, on emploie a + la / las + heure : a la una (à une heure), a las seis (à six heures). "
           "On précise de la mañana, de la tarde, de la noche. Y media (et demie), y cuarto (et quart), menos cuarto (moins le quart).",
           [("Me levanto a las seis de la mañana.", "Je me lève à six heures du matin."),
            ("Almuerzo a la una y media.", "Je déjeune à une heure et demie."),
            ("Me acuesto a las diez de la noche.", "Je me couche à dix heures du soir.")])],
        [("¿A qué hora te levantas?", "À quelle heure te lèves-tu ?"), ("Voy al colegio a pie.", "Je vais au collège à pied."),
         ("Después de cenar, hago los deberes.", "Après le dîner, je fais mes devoirs.")]),
    "m2-es-08": A(
        [V("¿Cuándo…?", "Quand… ?", "¿Cuándo empieza el curso?", "Quand commence l'année scolaire ?", "⏰"),
         V("¿Dónde…?", "Où… ?", "¿Dónde vives?", "Où habites-tu ?", "📍"),
         V("¿Quién…? / ¿Quiénes…?", "Qui… ?", "¿Quién es tu profesor?", "Qui est ton professeur ?", "🧑🏾"),
         V("¿Cuánto…? / ¿Cuántos…?", "Combien… ?", "¿Cuántos alumnos hay?", "Combien d'élèves y a-t-il ?", "🔢"),
         V("¿Qué…?", "Que… ? / Quoi… ? / Quel… ?", "¿Qué estudias?", "Qu'étudies-tu ?", "❔")],
        [G("¿QUÉ ou ¿CUÁL ?",
           "Qué demande une définition ou se place devant un nom : ¿Qué es esto? ¿Qué libro lees? "
           "Cuál (cuáles au pluriel) demande de choisir parmi plusieurs possibilités et s'emploie devant le verbe ser : "
           "¿Cuál es tu dirección? (et non « qué es tu dirección »).",
           [("¿Qué quieres beber?", "Que veux-tu boire ?"),
            ("¿Cuál es tu número de teléfono?", "Quel est ton numéro de téléphone ?"),
            ("¿Cuál prefieres, el rojo o el azul?", "Lequel préfères-tu, le rouge ou le bleu ?"),
            ("¿Qué carrera vas a elegir?", "Quelles études vas-tu choisir ?")])],
        [("¿Cuál es tu dirección?", "Quelle est ton adresse ?"), ("¿Dónde está la universidad?", "Où est l'université ?"),
         ("¿Cuántos años tienes?", "Quel âge as-tu ?")]),
    "m2-es-09": A(
        [V("el mes", "le mois", "Diciembre es el último mes del año.", "Décembre est le dernier mois de l'année.", "🗓️"),
         V("ayer", "hier", "Ayer fue domingo.", "Hier, c'était dimanche.", "⬅️"),
         V("mañana", "demain", "Mañana tengo una cita.", "Demain, j'ai un rendez-vous.", "➡️"),
         V("pasado mañana", "après-demain", "Pasado mañana es mi cumpleaños.", "Après-demain, c'est mon anniversaire.", "⏭️"),
         V("enero, febrero, marzo…", "janvier, février, mars…", "En agosto celebramos la independencia.", "En août, nous fêtons l'indépendance.", "📆")],
        [G("Les mois et la date : EL + jour + DE + mois",
           "Les mois s'écrivent sans majuscule : enero, febrero, marzo, abril, mayo, junio, julio, agosto, septiembre, octubre, "
           "noviembre, diciembre. La date : el + nombre + de + mois (+ de + année) : el 7 de agosto de 1960. "
           "« Quelle est la date ? » : ¿Qué fecha es hoy? ou ¿A qué estamos? — Estamos a 3 de marzo.",
           [("Hoy es el siete de agosto.", "Aujourd'hui, c'est le 7 août."),
            ("Mi cumpleaños es el quince de mayo.", "Mon anniversaire est le 15 mai."),
            ("Costa de Marfil es independiente desde el siete de agosto de mil novecientos sesenta.", "La Côte d'Ivoire est indépendante depuis le 7 août 1960.")])],
        [("¿Qué fecha es hoy?", "Quelle est la date aujourd'hui ?"), ("No tengo nada que hacer.", "Je n'ai rien à faire."),
         ("Quedamos el sábado a las cuatro.", "On se retrouve samedi à quatre heures.")]),
    "m2-es-10": A(
        [V("la infancia", "l'enfance", "Mi infancia fue muy feliz.", "Mon enfance a été très heureuse.", "🧒🏾"),
         V("jugar", "jouer", "De niño jugaba al fútbol.", "Enfant, je jouais au foot.", "⚽"),
         V("crecer", "grandir", "Crecí en un pueblo.", "J'ai grandi dans un village.", "🌱"),
         V("el futuro", "l'avenir, le futur", "En el futuro seré médico.", "À l'avenir, je serai médecin.", "🔮"),
         V("la semana pasada", "la semaine dernière", "La semana pasada visité a mi abuela.", "La semaine dernière, j'ai rendu visite à ma grand-mère.", "↩️")],
        [G("Le futur proche : IR A + infinitif",
           "Pour un projet proche ou une intention, on emploie ir (voy, vas, va, vamos, vais, van) + a + infinitif. "
           "C'est la forme la plus courante à l'oral : voy a estudiar (je vais étudier). Le futur simple (estudiaré) "
           "sert plutôt pour l'avenir lointain ou les prévisions.",
           [("Voy a estudiar medicina.", "Je vais étudier la médecine."),
            ("Mañana vamos a visitar a la abuela.", "Demain, nous allons rendre visite à grand-mère."),
            ("¿Qué vas a hacer este fin de semana?", "Que vas-tu faire ce week-end ?")])],
        [("Cuando era niño, vivía en el pueblo.", "Quand j'étais enfant, je vivais au village."), ("El año que viene voy a viajar.", "L'année prochaine, je vais voyager."),
         ("Ya no vivo con mis padres.", "Je ne vis plus avec mes parents.")]),
    "m2-es-11": A(
        [V("el vuelo", "le vol", "El vuelo sale a las nueve.", "Le vol part à neuf heures.", "✈️"),
         V("el equipaje", "les bagages", "Mi equipaje pesa veinte kilos.", "Mes bagages pèsent vingt kilos.", "🧳"),
         V("el andén", "le quai", "El tren está en el andén dos.", "Le train est sur le quai deux.", "🚉"),
         V("la taquilla", "le guichet", "Compré el billete en la taquilla.", "J'ai acheté le billet au guichet.", "🎫"),
         V("llegar tarde", "arriver en retard", "Llegué tarde por el tráfico.", "Je suis arrivé en retard à cause de la circulation.", "⌛")],
        [G("Le gérondif : ESTAR + -ANDO / -IENDO",
           "Pour une action en cours, on emploie estar + gérondif : -ar → -ando (esperando), -er / -ir → -iendo (comiendo, saliendo). "
           "Irréguliers : leer → leyendo, dormir → durmiendo, decir → diciendo. Au passé : estaba + gérondif.",
           [("Estoy esperando el autobús.", "Je suis en train d'attendre le bus."),
            ("Estábamos comiendo cuando llegó.", "Nous étions en train de manger quand il est arrivé."),
            ("El tren está saliendo del andén.", "Le train est en train de quitter le quai.")])],
        [("He perdido mi billete.", "J'ai perdu mon billet."), ("El autobús llegó con retraso.", "Le bus est arrivé en retard."),
         ("¿A qué hora sale el próximo tren?", "À quelle heure part le prochain train ?")]),
    "m2-es-12": A(
        [V("la cuenta", "l'addition", "¿Nos trae la cuenta, por favor?", "Vous nous apportez l'addition, s'il vous plaît ?", "🧾"),
         V("la propina", "le pourboire", "Dejamos una propina.", "Nous laissons un pourboire.", "🪙"),
         V("el menú", "le menu", "El menú del día cuesta tres mil francos.", "Le menu du jour coûte trois mille francs.", "📋"),
         V("pedir", "commander, demander", "Pido el pollo con arroz.", "Je commande le poulet avec du riz.", "🗣️"),
         V("poder", "pouvoir", "¿Puedo pagar con tarjeta?", "Je peux payer par carte ?", "✅")],
        [G("Les verbes à diphtongue : E → IE, O → UE, E → I",
           "Certains verbes changent la voyelle du radical quand elle est accentuée (toutes les personnes sauf nosotros et vosotros) : "
           "querer → quiero, preferir → prefiero, poder → puedo, volver → vuelvo, pedir → pido, servir → sirvo.",
           [("Prefiero el pescado.", "Je préfère le poisson."),
            ("¿Puedes traer la cuenta?", "Tu peux apporter l'addition ?"),
            ("Vuelvo mañana.", "Je reviens demain."),
            ("Siempre pido el plato del día.", "Je commande toujours le plat du jour.")])],
        [("La cuenta, por favor.", "L'addition, s'il vous plaît."), ("¿Me lo puede explicar otra vez?", "Pouvez-vous me l'expliquer encore une fois ?"),
         ("Acabo de llegar.", "Je viens d'arriver.")]),
    "m2-es-13": A(
        [V("la salud", "la santé", "El deporte es bueno para la salud.", "Le sport est bon pour la santé.", "❤️"),
         V("cuidarse", "prendre soin de soi", "Tienes que cuidarte.", "Tu dois prendre soin de toi.", "🫶"),
         V("la farmacia", "la pharmacie", "La farmacia está abierta.", "La pharmacie est ouverte.", "💊"),
         V("el médico / la médica", "le médecin", "Voy al médico mañana.", "Je vais chez le médecin demain.", "🩺"),
         V("hay que", "il faut", "Hay que dormir bien.", "Il faut bien dormir.", "☝️")],
        [G("Donner un conseil : TIENES QUE, HAY QUE, DEBERÍAS + infinitif",
           "Tener que + infinitif exprime une obligation personnelle (tienes que descansar). Hay que + infinitif est impersonnel "
           "(il faut). Deberías + infinitif (conditionnel de deber) est un conseil plus doux. "
           "Pour des conseils avec un sujet différent : te aconsejo que + subjonctif.",
           [("Tienes que beber mucha agua.", "Tu dois boire beaucoup d'eau."),
            ("Hay que lavarse las manos antes de comer.", "Il faut se laver les mains avant de manger."),
            ("Deberías descansar un poco.", "Tu devrais te reposer un peu."),
            ("Te aconsejo que vayas al médico.", "Je te conseille d'aller chez le médecin.")])],
        [("Deberías descansar.", "Tu devrais te reposer."), ("Hay que estudiar cada día.", "Il faut étudier chaque jour."),
         ("Ojalá apruebes el examen.", "Pourvu que tu réussisses l'examen.")]),
    "m2-es-14": A(
        [V("en mi opinión", "à mon avis", "En mi opinión, internet es útil.", "À mon avis, internet est utile.", "💭"),
         V("por un lado… por otro lado", "d'un côté… de l'autre", "Por un lado es caro; por otro lado, es útil.", "D'un côté c'est cher ; de l'autre, c'est utile.", "⚖️"),
         V("es decir", "c'est-à-dire", "Es un móvil, es decir, un teléfono.", "C'est un portable, c'est-à-dire un téléphone.", "🔁"),
         V("en resumen", "en résumé", "En resumen, el proyecto es un éxito.", "En résumé, le projet est un succès.", "📌"),
         V("sobre todo", "surtout", "Me gusta leer, sobre todo novelas.", "J'aime lire, surtout des romans.", "⭐")],
        [G("Le superlatif : EL MÁS… DE, -ÍSIMO",
           "Superlatif relatif : el / la / los / las + más (ou menos) + adjectif + de : el alumno más trabajador de la clase. "
           "Superlatif absolu : adjectif + -ísimo (très, extrêmement) : facilísimo, carísima, buenísimos. "
           "Attention à l'orthographe : rico → riquísimo, largo → larguísimo.",
           [("Es el alumno más trabajador de la clase.", "C'est l'élève le plus travailleur de la classe."),
            ("Abiyán es la ciudad más grande del país.", "Abidjan est la plus grande ville du pays."),
            ("Este ejercicio es facilísimo.", "Cet exercice est très facile."),
            ("La comida está riquísima.", "Le repas est délicieux.")])],
        [("En mi opinión, tienes razón.", "À mon avis, tu as raison."), ("Es el mejor proyecto de todos.", "C'est le meilleur projet de tous."),
         ("Estoy de acuerdo contigo.", "Je suis d'accord avec toi.")]),
    "m2-es-15": A(
        [V("la cosecha", "la récolte", "La cosecha de cacao empieza en octubre.", "La récolte du cacao commence en octobre.", "🌾"),
         V("el agricultor / la agricultora", "l'agriculteur / l'agricultrice", "Los agricultores trabajan juntos.", "Les agriculteurs travaillent ensemble.", "👩🏾‍🌾"),
         V("la semilla", "la semence, la graine", "Compramos semillas de calidad.", "Nous achetons des semences de qualité.", "🌱"),
         V("exportar", "exporter", "Costa de Marfil exporta mucho cacao.", "La Côte d'Ivoire exporte beaucoup de cacao.", "🚢"),
         V("el anacardo", "la noix de cajou", "El anacardo crece en el norte.", "La noix de cajou pousse dans le nord.", "🥜")],
        [G("Les prépositions A, EN, DE, DESDE… HASTA",
           "A indique la direction (voy a Bouaké) et l'heure (a las ocho). En indique le lieu où l'on est (vivo en San Pedro) "
           "et le moyen de transport (en autobús, mais a pie). De indique l'origine et la matière (de Daloa, de madera). "
           "Desde… hasta = de… jusqu'à (temps ou espace).",
           [("Voy a Bouaké en autobús.", "Je vais à Bouaké en bus."),
            ("Vivo en San Pedro, cerca del puerto.", "J'habite à San Pedro, près du port."),
            ("El cacao viene de Daloa.", "Le cacao vient de Daloa."),
            ("Trabajo desde las ocho hasta las cinco.", "Je travaille de huit heures à cinq heures.")])],
        [("Gracias al apoyo de la cooperativa, ganamos más.", "Grâce au soutien de la coopérative, nous gagnons plus."),
         ("Voy a la plantación en moto.", "Je vais à la plantation à moto."), ("Depende del precio del cacao.", "Ça dépend du prix du cacao.")]),
    "m2-es-16": A(
        [V("el refrán", "le proverbe", "Un refrán dice: «Poco a poco se va lejos».", "Un proverbe dit : « Petit à petit, on va loin ».", "📜"),
         V("la adivinanza", "la devinette", "El abuelo nos cuenta adivinanzas.", "Grand-père nous raconte des devinettes.", "🧩"),
         V("el narrador / la narradora", "le narrateur / la narratrice", "El narrador habla despacio.", "Le narrateur parle lentement.", "🗣️"),
         V("la tortuga", "la tortue", "La tortuga es lenta pero sabia.", "La tortue est lente mais sage.", "🐢"),
         V("Colorín colorado", "formule de fin de conte", "Y colorín colorado, este cuento se ha acabado.", "Et voilà, ce conte est terminé.", "🌈")],
        [G("Les formules du conte",
           "Pour commencer : Érase una vez… / Había una vez… (Il était une fois). Pour faire avancer l'histoire : Un día… (Un jour), "
           "De repente… (Soudain), Entonces… (Alors), Al final… (À la fin). Pour finir : Y colorín colorado, este cuento se ha acabado. "
           "La morale : La moraleja es que…",
           [("Érase una vez una liebre muy astuta.", "Il était une fois un lièvre très rusé."),
            ("Un día, la hiena tenía mucha hambre.", "Un jour, l'hyène avait très faim."),
            ("De repente, apareció la tortuga.", "Soudain, la tortue apparut."),
            ("Y colorín colorado, este cuento se ha acabado.", "Et voilà, ce conte est terminé.")])],
        [("Poco a poco se va lejos.", "Petit à petit, on va loin."), ("¿Me cuentas un cuento, abuelo?", "Tu me racontes un conte, grand-père ?"),
         ("La moraleja es que hay que ser paciente.", "La morale est qu'il faut être patient.")]),
}


# =============================================================================== Application


def _p(t):
    return pron(t) if t else ""


def _city(t):
    return re.sub(r"\bAbidjan\b", "Abiyán", t)


def _vocab(lesson, items):
    seen = {v["word"].lower() for v in lesson["vocab"]}
    for v in items:
        if v["word"].lower() in seen:
            continue
        v = copy.deepcopy(v)
        v["example"] = _city(v["example"])
        v["pron"] = _p(v["word"])
        v["examplePron"] = _p(v["example"])
        lesson["vocab"].append(v)
        seen.add(v["word"].lower())


def _grammar(lesson, items):
    seen = {g["title"] for g in lesson["grammar"]}
    for g in items:
        if g["title"] in seen:
            continue
        g = copy.deepcopy(g)
        for e in g["examples"]:
            e["text"] = _city(e["text"])
            e["pron"] = _p(e["text"])
        lesson["grammar"].append(g)


def _phrases(lesson, items):
    have = {p["text"] for p in lesson["phrases"]}
    for t, f in items:
        t = _city(t)
        if t not in have:
            lesson["phrases"].append({"text": t, "translation": f, "pron": _p(t)})
            have.add(t)


def _new_lesson(data, model):
    lesson = {
        "id": data["id"], "level": data["level"], "number": data["number"], "title": data["title"],
        "titleTr": data["titleTr"], "emoji": data["emoji"], "intro": data["intro"],
        "pages": [], "sourceContent": "", "sourcePages": [], "art": None,
        "vocab": [], "grammar": [], "dialogue": [], "quiz": [], "homework": [], "phrases": [],
    }
    _vocab(lesson, data["vocab"])
    _grammar(lesson, data["grammar"])
    scenes = copy.deepcopy(data["scenes"])
    flat = []
    for sc in scenes:
        cast = sc["cast"]
        for ln in sc["lines"]:
            ln["text"] = _city(ln["text"])
            ln["name"] = cast.get(ln["speaker"], "")
            ln["pron"] = _p(ln["text"])
            flat.append(dict(ln))
    lesson["scenes"] = scenes
    lesson["dialogue"] = flat
    _phrases(lesson, data["phrases_add"])
    r = copy.deepcopy(data["reading"])
    for s in r["sentences"]:
        s["text"] = _city(s["text"])
        s["pron"] = _p(s["text"])
    lesson["reading"] = r
    lesson["homework"] = copy.deepcopy(data["homework"])
    lesson["quiz"] = copy.deepcopy(data["quiz_add"])
    lesson["practice"] = copy.deepcopy(data.get("practice", []))
    return lesson


def _new_m2_lesson(d):
    """Nouvelle leçon du MODEL 2 : même structure que les 16 chapitres, avec son texte de manuel."""
    data = dict(d)
    data["reading"] = R(d["reading_title"], d["reading_title"], d["reading"])
    data.setdefault("practice", [])
    lesson = _new_lesson(data, "es_model2")
    lesson["art"] = d.get("art")
    lesson["sourceContent"] = manual_text(d)
    n = d["number"]
    lesson["sourcePages"] = [3 * n, 3 * n + 1, 3 * n + 2]
    lesson.pop("practice", None)  # atelier construit automatiquement par quiz_practice.py (m2_practice)
    lesson["quiz"] += [Qx(q, c, w, e) for q, c, w, e in d["manual_quiz"]]
    return lesson


COVERS = {
    "m2-es-17": "manual_images/model2_lesson_17.webp", "m2-es-18": "manual_images/model2_lesson_18.webp",
    "m2-es-19": "manual_images/model2_lesson_19.webp", "m2-es-20": "manual_images/model2_lesson_20.webp",
    **{f"m2-es-{n}": f"manual_images/model2_lesson_{n}.webp" for n in range(21, 29)},
    "m3-es-02": "manual_images/model3_unit_02.webp", "m3-es-03": "manual_images/model3_unit_03.webp",
    "m3-es-04": "manual_images/model3_unit_04.webp", "m3-es-05": "manual_images/model3_unit_05.webp",
    "m3-es-06": "manual_images/model3_unit_06.webp", "m3-es-07": "manual_images/model3_unit_07.webp",
    "m3-es-08": "manual_images/model3_unit_08.webp",
}


def apply(name, doc):
    """Ajoute le contenu supplémentaire au document JSON du cours [name] (es_model2 ou es_model3)."""
    for lesson in doc["lessons"]:
        extra = ADD.get(lesson["id"])
        if extra:
            _vocab(lesson, extra["vocab"])
            _grammar(lesson, extra["grammar"])
            _phrases(lesson, extra["phrases_add"])
    if name == "es_model2":
        ids = {l["id"] for l in doc["lessons"]}
        for d in M2_NEW + M2_MORE:
            if d["id"] not in ids:
                doc["lessons"].append(_new_m2_lesson(d))
        doc["lessons"].sort(key=lambda l: l["number"])
    if name == "es_model3":
        ids = {l["id"] for l in doc["lessons"]}
        for data in M3_NEW:
            if data["id"] not in ids:
                doc["lessons"].append(_new_lesson(data, name))
        doc["lessons"].sort(key=lambda l: l["number"])
        note = " Unités complémentaires 5 à 8 : au marché, au collège, la maison et le village, les repas et la fête."
        if note not in doc.get("courseDescription", ""):
            doc["courseDescription"] = doc.get("courseDescription", "") + note
    # Couvertures dessinées (tools/flat_scenes_plus.py) pour les leçons sans illustration du manuel.
    for lesson in doc["lessons"]:
        if not lesson.get("illustrationAsset") and lesson["id"] in COVERS:
            lesson["illustrationAsset"] = COVERS[lesson["id"]]
    return doc
