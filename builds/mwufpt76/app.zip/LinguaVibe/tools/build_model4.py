#!/usr/bin/env python3
"""MODEL 4 : la conjugaison espagnole, verbe par verbe, en commençant par les plus utilisés.

Usage : python3 tools/build_model4.py
Écrit app/src/main/assets/courses/es_model4.json :
- une leçon par verbe (model4_verbs.py), avec les tableaux de tous les temps (conjugator.py),
  la règle de chaque temps, les formes irrégulières repérées, des exemples, un quiz et des ateliers.
"""
import json
import random
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from conjugator import conjugate, regular  # noqa: E402
from model4_verbs import VERBS  # noqa: E402
from pron_es import pron  # noqa: E402

OUT = HERE.parent / "app" / "src" / "main" / "assets" / "courses" / "es_model4.json"
PERSONS = ["yo", "tú", "él / ella / usted", "nosotros", "vosotros", "ellos / ellas / ustedes"]
PERSONS_IMP = ["—", "tú", "usted", "nosotros", "vosotros", "ustedes"]
LEVELS = ["A1", "A2", "B1", "B2", "C1", "C2"]

# id, nom français, nom espagnol, mode, règle
TENSES = [
    ("presente", "Présent", "Presente", "Indicatif",
     "Formation : radical + -o, -as, -a, -amos, -áis, -an (-ar) ; -o, -es, -e, -emos, -éis, -en (-er) ; -o, -es, -e, -imos, -ís, -en (-ir). "
     "Emploi : ce qui se passe maintenant, les habitudes, les vérités générales, et un futur proche avec un repère de temps (mañana salgo)."),
    ("preterito_perfecto", "Passé composé", "Pretérito perfecto", "Indicatif",
     "Formation : haber au présent (he, has, ha, hemos, habéis, han) + participe passé invariable (-ado, -ido). "
     "Emploi : une action passée dans une période qui n'est pas terminée (hoy, esta semana, este año) ou une expérience (nunca he visto…)."),
    ("imperfecto", "Imparfait", "Pretérito imperfecto", "Indicatif",
     "Formation : -aba, -abas, -aba, -ábamos, -abais, -aban (-ar) ; -ía, -ías, -ía, -íamos, -íais, -ían (-er, -ir). Seuls ser (era), ir (iba) et ver (veía) sont irréguliers. "
     "Emploi : le décor d'un récit, les descriptions et les habitudes du passé (cuando era niño, jugaba…)."),
    ("indefinido", "Passé simple", "Pretérito indefinido", "Indicatif",
     "Formation : -é, -aste, -ó, -amos, -asteis, -aron (-ar) ; -í, -iste, -ió, -imos, -isteis, -ieron (-er, -ir). Beaucoup de verbes courants ont un radical irrégulier (tuve, hice, dije) et des terminaisons sans accent. "
     "Emploi : une action terminée à un moment précis du passé (ayer, el año pasado, en 2020). Très utilisé à l'oral."),
    ("pluscuamperfecto", "Plus-que-parfait", "Pluscuamperfecto", "Indicatif",
     "Formation : haber à l'imparfait (había, habías…) + participe passé. "
     "Emploi : une action antérieure à une autre action passée (cuando llegué, el tren ya había salido)."),
    ("futuro", "Futur simple", "Futuro simple", "Indicatif",
     "Formation : infinitif + -é, -ás, -á, -emos, -éis, -án (mêmes terminaisons pour les trois groupes). Quelques verbes ont un radical court : tendr-, har-, dir-, podr-, pondr-, saldr-, vendr-, sabr-, querr-, habr-. "
     "Emploi : l'avenir, une prévision, une promesse, et parfois une supposition (serán las ocho = il doit être huit heures)."),
    ("futuro_perfecto", "Futur antérieur", "Futuro perfecto", "Indicatif",
     "Formation : haber au futur (habré, habrás…) + participe passé. "
     "Emploi : une action qui sera terminée avant un moment futur (a las seis ya habré terminado), ou une supposition sur le passé."),
    ("condicional", "Conditionnel présent", "Condicional simple", "Conditionnel",
     "Formation : infinitif (ou radical court du futur) + -ía, -ías, -ía, -íamos, -íais, -ían. "
     "Emploi : la politesse (¿podría…?), le conseil (deberías…), l'hypothèse (si tuviera dinero, viajaría) et le futur dans le passé (dijo que vendría)."),
    ("condicional_perfecto", "Conditionnel passé", "Condicional compuesto", "Conditionnel",
     "Formation : haber au conditionnel (habría, habrías…) + participe passé. "
     "Emploi : ce qui aurait pu se passer (si hubiera sabido, habría venido) et le regret."),
    ("subj_presente", "Subjonctif présent", "Presente de subjuntivo", "Subjonctif",
     "Formation : on part du « yo » du présent sans le -o, et on inverse la voyelle : -ar → -e, -es, -e, -emos, -éis, -en ; -er / -ir → -a, -as, -a, -amos, -áis, -an (tengo → tenga, hablo → hable). "
     "Emploi : après un souhait, un doute, un sentiment ou un conseil (quiero que vengas, espero que…), après cuando pour le futur, et pour l'impératif négatif."),
    ("subj_perfecto", "Subjonctif passé", "Pretérito perfecto de subjuntivo", "Subjonctif",
     "Formation : haber au subjonctif présent (haya, hayas…) + participe passé. "
     "Emploi : comme le subjonctif présent, pour une action déjà accomplie (espero que hayas comido bien)."),
    ("subj_imperfecto", "Subjonctif imparfait", "Imperfecto de subjuntivo", "Subjonctif",
     "Formation : 3e personne du pluriel du passé simple sans -ron + -ra, -ras, -ra, -ramos, -rais, -ran (tuvieron → tuviera ; accent sur nosotros : tuviéramos). "
     "Emploi : le subjonctif dans un récit au passé (quería que vinieras), l'hypothèse avec si (si tuviera…) et la politesse (quisiera)."),
    ("subj_pluscuam", "Subjonctif plus-que-parfait", "Pluscuamperfecto de subjuntivo", "Subjonctif",
     "Formation : haber au subjonctif imparfait (hubiera, hubieras…) + participe passé. "
     "Emploi : l'hypothèse passée non réalisée (si hubiera estudiado, habría aprobado) et le regret (ojalá hubiera venido)."),
    ("imperativo", "Impératif affirmatif", "Imperativo afirmativo", "Impératif",
     "Formation : tú = 3e personne du présent (habla, come), sauf huit irréguliers (di, haz, ve, pon, sal, sé, ten, ven) ; vosotros = infinitif avec -d (hablad) ; "
     "usted, nosotros, ustedes = subjonctif présent. Les pronoms se collent à la fin : dímelo, siéntate. "
     "Emploi : donner un ordre, un conseil, une instruction."),
    ("imperativo_neg", "Impératif négatif", "Imperativo negativo", "Impératif",
     "Formation : no + subjonctif présent pour toutes les personnes (no hables, no habléis). Les pronoms se placent avant le verbe : no me lo digas. "
     "Emploi : interdire, déconseiller."),
]
TNAME = {t[0]: t[1] for t in TENSES}
MAIN = ["presente", "preterito_perfecto", "imperfecto", "indefinido", "futuro", "condicional", "subj_presente", "imperativo"]


def short(tr):
    return tr.split(" (")[0].split(",")[0]


def irregular_marks(inf, c):
    reg = regular(inf)["tenses"]
    out = {}
    for tid in c["tenses"]:
        forms = c["tenses"][tid]
        rf = reg.get(tid, forms)
        out[tid] = "".join("1" if f != "—" and f != r else "0" for f, r in zip(forms, rf))
    return out


def table(v, c):
    marks = irregular_marks(v["inf"], c)
    return {
        "verb": v["inf"], "translation": v["tr"], "group": "-" + v["inf"][-2:].replace("ír", "ir"),
        "note": v["note"], "gerund": c["gerund"], "participle": c["participle"],
        "tenses": [{"id": tid, "name": name, "nameEs": es, "mood": mood, "rule": rule,
                    "forms": c["tenses"][tid], "irregular": marks[tid]} for tid, name, es, mood, rule in TENSES],
    }


def all_forms(c):
    out = set()
    for forms in c["tenses"].values():
        for f in forms:
            if f != "—":
                out.add(f.replace("no ", ""))
    return out


def plabel(tid, p):
    return (PERSONS_IMP if tid.startswith("imperativo") else PERSONS)[p]


def quiz(v, c, rnd, others):
    inf = v["inf"]
    t = c["tenses"]
    q = []
    persons = list(range(6))
    # 1. choisir la bonne forme (même personne, autres temps)
    for tid in MAIN:
        ps = [p for p in persons if t[tid][p] != "—"]
        if not ps:
            continue
        p = rnd.choice(ps)
        correct = t[tid][p]
        wrong = []
        for o in MAIN + ["pluscuamperfecto", "futuro_perfecto", "subj_imperfecto"]:
            f = t[o][p]
            if o != tid and f not in ("—", correct) and f not in wrong:
                wrong.append(f)
        rnd.shuffle(wrong)
        q.append({"type": "mcq", "question": f"{inf.upper()} · {plabel(tid, p)} · {TNAME[tid].lower()}", "correct": correct, "wrong": wrong[:3],
                  "explain": f"{TNAME[tid]} de {inf} : " + ", ".join(f for f in t[tid] if f != "—") + "."})
    # 2. forme à écrire
    for tid in ["presente", "indefinido", "imperfecto", "futuro", "condicional", "subj_presente", "preterito_perfecto", "subj_imperfecto"]:
        for p in rnd.sample(persons, 2):
            q.append({"type": "typed", "prompt": f"{inf} → {plabel(tid, p)}, {TNAME[tid].lower()}", "answers": [t[tid][p]],
                      "instruction": "Écrivez la forme conjuguée", "explain": ""})
    # 3. reconnaître le temps
    for tid in rnd.sample(["indefinido", "imperfecto", "futuro", "condicional", "subj_presente", "subj_imperfecto", "pluscuamperfecto"], 4):
        p = rnd.choice([0, 2, 3, 5])
        f = t[tid][p]
        if f == "—":
            continue
        wrong = [TNAME[o] for o in ("presente", "indefinido", "imperfecto", "futuro", "condicional", "subj_presente", "subj_imperfecto", "pluscuamperfecto")
                 if o != tid and t[o][p] != f]
        rnd.shuffle(wrong)
        q.append({"type": "mcq", "question": f"« {f} » ({inf}, {plabel(tid, p)}) est au…", "correct": TNAME[tid], "wrong": wrong[:3],
                  "explain": TENSES[[x[0] for x in TENSES].index(tid)][4].split(" Emploi")[0]})
    # 4. paires
    for tid in ("presente", "indefinido"):
        q.append({"type": "match", "pairs": [[PERSONS[p].split(" /")[0], t[tid][p]] for p in (0, 1, 2, 3, 5)],
                  "title": f"{TNAME[tid]} de {inf} : associez la personne et la forme", "explain": ""})
    # 5. participe et gérondif
    q.append({"type": "mcq", "question": f"Participe passé de {inf} :", "correct": c["participle"],
              "wrong": [x for x in {inf[:-2] + ("ado" if inf.endswith("ar") else "ido"), inf[:-2] + "to", c["gerund"], inf[:-2] + "ido"} if x != c["participle"]][:3],
              "explain": f"On l'emploie avec haber : he {c['participle']}, había {c['participle']}."})
    q.append({"type": "mcq", "question": f"Gérondif de {inf} :", "correct": c["gerund"],
              "wrong": [x for x in {inf[:-2] + "ando", inf[:-2] + "iendo", c["participle"], inf[:-2] + "yendo"} if x != c["gerund"]][:3],
              "explain": f"Estar + gérondif : estoy {c['gerund']} (action en cours)."})
    # 6. exemples : trou, écoute, ordre, oral
    forms = all_forms(c)
    for es, fr, tid in v["examples"]:
        words = es.replace("¿", "").replace("¡", "").replace("?", "").replace("!", "").replace(".", "").replace(",", "").split()
        hit = next((w for w in words if w.lower() in forms or w.lower().rstrip("melotenos") in forms), None)
        if hit and hit.lower() in forms:
            wrong = [f for f in rnd.sample(sorted(forms), min(12, len(forms))) if f.lower() != hit.lower() and " " not in f][:3]
            if hit[0].isupper():
                wrong = [w[0].upper() + w[1:] for w in wrong]
            q.append({"type": "fill", "sentence": es.replace(hit, "___", 1), "answers": [hit], "wrong": wrong, "translation": fr,
                      "explain": f"{TNAME.get(tid, '')} de {inf}."})
        q.append({"type": "listen", "phrase": es, "correct": fr, "wrong": rnd.sample(others, 3), "explain": ""})
        if 3 <= len(es.split()) <= 9:
            q.append({"type": "order", "words": es.split(), "translation": fr, "explain": ""})
    for es, fr, _ in v["examples"][:2]:
        q.append({"type": "speak", "text": es, "translation": fr, "explain": "Réussi à partir de 60 % de mots reconnus."})
    q.append({"type": "write", "prompt": f"Écrivez 4 phrases avec {inf} : au présent, au passé simple, au futur et au subjonctif.",
              "model": " ".join(e[0] for e in v["examples"]), "keywords": [t["presente"][0], t["indefinido"][0], t["futuro"][0]], "minWords": 16,
              "explain": "Vérifiez les terminaisons de chaque temps."})
    return q


def practice(v, c, rnd):
    inf = v["inf"]
    t = c["tenses"]

    def typed(tid, p):
        return {"type": "typed", "prompt": f"{plabel(tid, p)} · {TNAME[tid].lower()}", "answers": [t[tid][p]],
                "instruction": f"Conjuguez {inf}", "explain": ""}

    sets = [
        {"ref": "", "title": f"Le présent de {inf}", "instruction": "Écrivez les six formes, puis vérifiez dans le tableau.",
         "items": [typed("presente", p) for p in range(6)]},
        {"ref": "", "title": "Les temps du passé", "instruction": "Passé simple, imparfait et passé composé : une forme par ligne.",
         "items": [typed(tid, p) for tid in ("indefinido", "imperfecto", "preterito_perfecto") for p in rnd.sample(range(6), 2)]},
        {"ref": "", "title": "Futur et conditionnel", "instruction": "Attention aux radicaux courts (tendr-, har-, dir-…).",
         "items": [typed(tid, p) for tid in ("futuro", "condicional") for p in rnd.sample(range(6), 3)]},
        {"ref": "", "title": "Subjonctif et impératif", "instruction": "Partez du « yo » du présent pour former le subjonctif.",
         "items": [typed("subj_presente", p) for p in rnd.sample(range(6), 3)] +
                  ([typed("imperativo", p) for p in (1, 2, 4)] if t["imperativo"][1] != "—" else [typed("subj_imperfecto", p) for p in (0, 2, 5)])},
    ]
    forms = all_forms(c)
    ctx = []
    for es, fr, tid in v["examples"]:
        words = es.replace("¿", "").replace("¡", "").replace("?", "").replace("!", "").replace(".", "").replace(",", "").split()
        hit = next((w for w in words if w.lower() in forms), None)
        if hit:
            ctx.append({"type": "fill", "sentence": es.replace(hit, "___", 1), "answers": [hit], "wrong": [], "translation": fr,
                        "explain": f"{TNAME.get(tid, '')} de {inf}."})
    ctx += [{"type": "speak", "text": es, "translation": fr, "explain": ""} for es, fr, _ in v["examples"][:2]]
    if ctx:
        sets.append({"ref": "", "title": f"{inf.capitalize()} en contexte", "instruction": "Tapez la forme qui manque, puis dites les phrases au micro.", "items": ctx})
    return sets


def build():
    rnd = random.Random(4)
    others_pool = [e[1] for v in VERBS for e in v["examples"]]
    lessons = []
    for i, v in enumerate(VERBS, 1):
        c = conjugate(v["inf"], **v["traits"])
        tb = table(v, c)
        others = [x for x in others_pool if x not in {e[1] for e in v["examples"]}]
        irregular_count = sum(m.count("1") for m in (t["irregular"] for t in tb["tenses"]))
        kind = "régulier" if irregular_count == 0 else ("régulier, orthographe modifiée" if not v["traits"] else "irrégulier")
        lesson = {
            "id": f"m4-es-{i:02d}", "level": LEVELS[(i - 1) // 10], "number": i,
            "title": f"{v['inf'].capitalize()} · {short(v['tr'])}",
            "titleTr": f"Verbe n° {i} · {v['tr']} · {kind}",
            "emoji": v["emoji"],
            "intro": f"{v['inf'].capitalize()} est le verbe n° {i} des plus utilisés en espagnol. {v['usage']}",
            "vocab": [],
            "grammar": [
                {"title": f"Ce qu'il faut retenir sur {v['inf']}", "explanation": v["note"],
                 "examples": [{"text": e[0], "translation": e[1], "pron": pron(e[0])} for e in v["examples"][:2]]},
                {"title": f"Employer {v['inf']}", "explanation": v["usage"],
                 "examples": [{"text": e[0], "translation": e[1], "pron": pron(e[0])} for e in v["examples"][2:]]},
            ],
            "conjugations": [tb],
            "dialogue": [],
            "quiz": quiz(v, c, rnd, others),
            "homework": [
                {"prompt": f"Écrivez 4 phrases sur votre vie avec {v['inf']} : présent, passé simple, futur et subjonctif.",
                 "model": " ".join(e[0] for e in v["examples"]), "keywords": [c["tenses"]["presente"][0], c["tenses"]["futuro"][0]]},
                {"prompt": f"Recopiez de mémoire le présent et le passé simple de {v['inf']}, puis comparez avec le tableau.",
                 "model": ", ".join(c["tenses"]["presente"]) + " / " + ", ".join(c["tenses"]["indefinido"]), "keywords": c["tenses"]["presente"][:3]},
            ],
            "phrases": [{"text": e[0], "translation": e[1], "pron": pron(e[0])} for e in v["examples"]],
            "reading": {"title": f"{v['inf'].capitalize()} en contexte", "titleTr": f"{v['inf'].capitalize()} en contexte",
                        "sentences": [{"text": e[0], "translation": e[1], "pron": pron(e[0])} for e in v["examples"]]},
            "practice": practice(v, c, rnd),
        }
        for qq in lesson["quiz"]:
            if qq["type"] in ("mcq", "listen"):
                assert qq["correct"] not in qq["wrong"], qq
                assert len(qq["wrong"]) >= 1, qq
        lessons.append(lesson)
    doc = {"lang": "es", "model": "model4",
           "source": "Conjugaison espagnole : les verbes les plus utilisés, à tous les temps, avec règles, exercices et quiz.",
           "lessons": lessons}
    OUT.write_text(json.dumps(doc, ensure_ascii=False, indent=1), encoding="utf-8")
    print(OUT.name, len(lessons), "leçons,", sum(len(l["quiz"]) for l in lessons), "questions,",
          sum(len(p["items"]) for l in lessons for p in l["practice"]), "exercices")


if __name__ == "__main__":
    build()
