#!/usr/bin/env python3
"""Quiz élargis et ateliers interactifs « À pratiquer » des MODEL 2 et 3 (espagnol).

Usage : python3 tools/quiz_practice.py
- Applique d'abord tools/content_plus.py (cours augmentés : unités 5 à 8 du MODEL 3, ajouts dans toutes les leçons).
- Génère de nouvelles questions à partir du vocabulaire, des exemples et des dialogues de chaque leçon :
  choix multiples dans les deux sens, écoute, traduction écrite, phrases à remettre dans l'ordre,
  phrases à trou, paires, oral au micro. Elles sont marquées "gen": true et refaites à chaque lancement.
- Ajoute des questions rédigées (avec explication) et les ateliers « practice » :
  MODEL 3 : ateliers rédigés, dont ceux rattachés aux exercices du manuel (Exercice 1-4, Activité 1-4) ;
  MODEL 2 : un atelier par leçon construit à partir des dialogues, de la grammaire et du devoir.
"""
import json
import random
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import content_plus  # noqa: E402
from fictional_places import fictionalize  # noqa: E402

ASSETS = HERE.parent / "app" / "src" / "main" / "assets" / "courses"

# ----------------------------------------------------------------------------- nombres

U = ["cero", "uno", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve", "diez", "once", "doce", "trece",
     "catorce", "quince", "dieciséis", "diecisiete", "dieciocho", "diecinueve", "veinte", "veintiuno", "veintidós",
     "veintitrés", "veinticuatro", "veinticinco", "veintiséis", "veintisiete", "veintiocho", "veintinueve"]
T = {30: "treinta", 40: "cuarenta", 50: "cincuenta", 60: "sesenta", 70: "setenta", 80: "ochenta", 90: "noventa"}
C = {100: "ciento", 200: "doscientos", 300: "trescientos", 400: "cuatrocientos", 500: "quinientos", 600: "seiscientos",
     700: "setecientos", 800: "ochocientos", 900: "novecientos"}


def es_num(n):
    if n < 30:
        return U[n]
    if n < 100:
        t, u = divmod(n, 10)
        return T[t * 10] + ("" if u == 0 else " y " + U[u])
    if n == 100:
        return "cien"
    if n < 1000:
        c, r = divmod(n, 100)
        return C[c * 100] + ("" if r == 0 else " " + es_num(r))
    if n < 1_000_000:
        m, r = divmod(n, 1000)
        head = "mil" if m == 1 else es_num(m).replace("veintiuno", "veintiún") + " mil"
        if head.endswith("uno mil"):
            head = head[:-7] + "un mil"
        return head + ("" if r == 0 else " " + es_num(r))
    return str(n)


def num_answers(n):
    a = es_num(n)
    out = [a]
    if a.startswith("veinti"):
        out.append(a.replace("veinti", "veinte y ", 1))
    return out


def digits(n):
    s = str(n)
    out = [s]
    if n >= 1000:
        out += [f"{n:,}".replace(",", " "), f"{n:,}".replace(",", ".")]
    return out


# ----------------------------------------------------------------------------- outils

def mcq(q, correct, wrong, explain="", gen=False):
    d = {"type": "mcq", "question": q, "correct": correct, "wrong": wrong[:3], "explain": explain}
    if gen:
        d["gen"] = True
    return d


def typed(prompt, answers, explain="", instruction="", gen=False):
    d = {"type": "typed", "prompt": prompt, "answers": answers, "explain": explain}
    if instruction:
        d["instruction"] = instruction
    if gen:
        d["gen"] = True
    return d


def listen(phrase, correct, wrong, explain="", gen=False):
    d = {"type": "listen", "phrase": phrase, "correct": correct, "wrong": wrong[:3], "explain": explain}
    if gen:
        d["gen"] = True
    return d


def order(sentence, translation, explain="", gen=False):
    d = {"type": "order", "words": sentence.split(), "translation": translation, "explain": explain}
    if gen:
        d["gen"] = True
    return d


def fill(sentence, answers, wrong, translation="", explain="", gen=False):
    if isinstance(answers, str):
        answers = [answers]
    d = {"type": "fill", "sentence": sentence, "answers": answers, "wrong": wrong, "translation": translation, "explain": explain}
    if gen:
        d["gen"] = True
    return d


def match(pairs, title="", explain="", gen=False):
    d = {"type": "match", "pairs": [list(p) for p in pairs], "title": title, "explain": explain}
    if gen:
        d["gen"] = True
    return d


def speak(text, translation, explain="", gen=False):
    d = {"type": "speak", "text": text, "translation": translation, "explain": explain}
    if gen:
        d["gen"] = True
    return d


def write(prompt, model, keywords, min_words=0, explain=""):
    return {"type": "write", "prompt": prompt, "model": model, "keywords": keywords, "minWords": min_words, "explain": explain}


def practice(title, instruction, items, ref=""):
    return {"ref": ref, "title": title, "instruction": instruction, "items": items}


def plain(word):
    return re.sub(r"[¡!¿?.,…]", "", word).strip()


def clean_word(w):
    return w.replace("…", "").strip()


# ----------------------------------------------------------------------------- génération automatique

def generate(lesson, model_vocab, rnd):
    vocab = [v for v in lesson["vocab"] if v.get("word") and v.get("translation")]
    others = [v for v in model_vocab if v not in vocab]
    out = []
    seen_q = {q.get("question") or q.get("prompt") or q.get("phrase") for q in lesson["quiz"]}

    def distract(field, exclude, n=3, pool=None):
        pool = pool or (vocab + others)
        cands = [v[field] for v in pool if v[field] != exclude and v[field].strip()]
        rnd.shuffle(cands)
        res = []
        for c in cands:
            if c not in res and c.lower() != exclude.lower():
                res.append(c)
            if len(res) == n:
                break
        return res

    # 1. sens des mots (espagnol -> français)
    for v in rnd.sample(vocab, min(12, len(vocab))):
        q = f"Que veut dire « {v['word']} » ?"
        if q in seen_q:
            continue
        ex = f"Exemple : {v['example']} — {v['exampleTr']}" if v.get("example") else ""
        out.append(mcq(q, v["translation"], distract("translation", v["translation"], pool=vocab if len(vocab) > 6 else None), ex, gen=True))
    # 2. français -> espagnol
    for v in rnd.sample(vocab, min(8, len(vocab))):
        out.append(mcq(f"Comment dit-on « {v['translation']} » ?", v["word"], distract("word", v["word"]),
                       v.get("example", "") and f"{v['example']} — {v['exampleTr']}", gen=True))
    # 3. écoute des exemples
    exs = [v for v in vocab if v.get("example") and v.get("exampleTr")]
    for v in rnd.sample(exs, min(6, len(exs))):
        wrong = [o["exampleTr"] for o in rnd.sample(exs + [x for x in others if x.get("exampleTr")], min(12, len(exs) + len(others))) if o["exampleTr"] != v["exampleTr"]][:3]
        if len(wrong) >= 2:
            out.append(listen(v["example"], v["exampleTr"], wrong, f"Mot clé : {v['word']} = {v['translation']}", gen=True))
    # 4. traduction écrite de phrases courtes
    phrases = [p for p in lesson.get("phrases", []) if 2 <= len(p["text"].split()) <= 7]
    for p in rnd.sample(phrases, min(5, len(phrases))):
        answers = [p["text"], plain(p["text"])]
        out.append(typed(p["translation"], list(dict.fromkeys(answers)), "Pensez aux signes ¡ ¿ et aux accents.", gen=True))
    # 5. remettre dans l'ordre (répliques de dialogue)
    lines = [l for l in lesson.get("dialogue", []) if 4 <= len(l["text"].split()) <= 9]
    for l in rnd.sample(lines, min(8, len(lines))):
        out.append(order(l["text"], l["translation"], f"Réplique de {l.get('name') or 'dialogue'}.", gen=True))
    # 6. phrases à trou : un mot du vocabulaire retiré d'une réplique ou d'un exemple
    singles = [clean_word(v["word"]) for v in vocab if re.fullmatch(r"[A-Za-zÁÉÍÓÚÜÑáéíóúüñ]+", clean_word(v["word"]))]
    bases = [(l["text"], l["translation"]) for l in lesson.get("dialogue", [])] + [(v["example"], v["exampleTr"]) for v in exs]
    rnd.shuffle(bases)
    n = 0
    for text, tr in bases:
        for w in singles:
            m = re.search(rf"(?<![\wáéíóúñ]){re.escape(w)}(?![\wáéíóúñ])", text, re.I)
            if m and len(singles) >= 3:
                wrong = [x for x in singles if x.lower() != w.lower()]
                rnd.shuffle(wrong)
                out.append(fill(text[:m.start()] + "___" + text[m.end():], [m.group(0)], wrong[:3], tr, gen=True))
                n += 1
                break
        if n >= 6:
            break
    # 7. paires
    short = [v for v in vocab if len(v["word"]) <= 28 and len(v["translation"]) <= 32]
    rnd.shuffle(short)
    for i in range(0, min(len(short), 10), 5):
        grp = short[i:i + 5]
        if len(grp) >= 4:
            out.append(match([(v["word"], v["translation"]) for v in grp], "Associez le mot et sa traduction", gen=True))
    # 8. oral
    sp = [p for p in lesson.get("phrases", []) if len(p["text"].split()) <= 10]
    for p in rnd.sample(sp, min(4, len(sp))):
        out.append(speak(p["text"], p["translation"], "Réussi à partir de 60 % de mots reconnus.", gen=True))
    return out


# ----------------------------------------------------------------------------- MODEL 3 : rédigé

M3_QUIZ = {
    "m3-es-01": [
        mcq("Il est 8 h. Vous saluez votre professeur :", "¡Buenos días, señor profesor!", ["¡Buenas noches, señor profesor!", "¡Buenas tardes, señor profesor!", "¡Adiós, señor profesor!"],
            "Buenos días s'emploie le matin, jusqu'à midi environ."),
        mcq("Pour présenter une fille, on dit :", "Ésta es Aya.", ["Éste es Aya.", "Éstos son Aya.", "Me llamo Aya."], "Ésta pour une fille ou une femme, éste pour un garçon."),
        mcq("« Voici Koffi et Silué » :", "Éstos son Koffi y Silué.", ["Éstas son Koffi y Silué.", "Éste es Koffi y Silué.", "Ésta son Koffi y Silué."],
            "Au pluriel, dès qu'il y a un garçon, on emploie le masculin éstos."),
        mcq("Quelle phrase est correcte ?", "Me llamo Fatou.", ["Yo llamo Fatou.", "Mi llamo Fatou.", "Me llama Fatou."], "Le verbe est pronominal : me llamo, te llamas, se llama."),
        mcq("Vous vouvoyez une dame âgée :", "¿Cómo está usted?", ["¿Cómo estás?", "¿Qué tal, tú?", "¿Cómo te llamas?"], "Avec usted, le verbe est à la 3e personne : está."),
        mcq("« Bienvenue au collège, Silué ! »", "¡Bienvenido al colegio, Silué!", ["¡Bienvenida al colegio, Silué!", "¡Encantado al colegio!", "¡Hola al colegio!"],
            "Bienvenido s'accorde : bienvenido pour un garçon, bienvenida pour une fille. a + el = al."),
        fill("Silué es ___ Korhogo.", "de", ["en", "a", "por"], "Silué est de Korhogo.", "Ser de + lieu : dire d'où l'on vient."),
        fill("¿Cómo te ___?", "llamas", ["llamo", "llama", "llaman"], "Comment t'appelles-tu ?", "Avec tú : te llamas."),
        order("¡Hola! Me llamo Fatou. ¿Cómo te llamas?", "Salut ! Je m'appelle Fatou. Comment t'appelles-tu ?", "Première bulle de la page 10 du manuel."),
        order("Éste es Silué. Es de Korhogo.", "Voici Silué. Il est de Korhogo."),
        listen("¡Hasta mañana!", "À demain !", ["À tout à l'heure !", "Bonne nuit !", "Au revoir !"]),
        listen("Encantada.", "Enchantée.", ["Bienvenue.", "Merci.", "De rien."], "Une fille dit encantada, un garçon encantado."),
        speak("¡Hola! Me llamo Fatou. ¿Cómo te llamas?", "Salut ! Je m'appelle Fatou. Comment t'appelles-tu ?"),
        speak("Éste es Silué. Es de Korhogo.", "Voici Silué. Il est de Korhogo."),
        match([("¡Buenos días!", "Bonjour (matin)"), ("¡Buenas tardes!", "Bonjour (après-midi)"), ("¡Buenas noches!", "Bonsoir / Bonne nuit"),
               ("¡Hasta luego!", "À plus tard"), ("¡Adiós!", "Au revoir")], "Les salutations du jour"),
    ],
    "m3-es-02": [
        mcq("Abolé est le … d'Api.", "padre", ["hermano", "abuelo", "hijo"], "Abolé (45 ans) et Fatou (44 ans) sont les parents d'Api, Adou et Yéli."),
        mcq("Api, Adou et Yéli sont les … d'Abolé.", "hijos", ["padres", "abuelos", "primos"], "Hijos désigne les enfants (garçons et filles ensemble)."),
        mcq("Yéli es la … de la familia (10 ans).", "menor", ["mayor", "madre", "alta"], "La menor = la plus jeune ; la mayor = l'aînée."),
        mcq("Combien d'enfants ont Abolé et Fatou ?", "tres", ["dos", "cuatro", "cinco"], "Api, Adou y Yéli : tres hijos."),
        mcq("« Fatou a quarante-quatre ans » :", "Fatou tiene cuarenta y cuatro años.", ["Fatou es cuarenta y cuatro años.", "Fatou está cuarenta y cuatro años.", "Fatou tiene cuarenta cuatro años."],
            "On dit tener + años, et y entre les dizaines et les unités à partir de 31."),
        fill("La mesa es ___.", "redonda", ["redondo", "redondas", "cuadrado"], "La table est ronde.", "Mesa est féminin : l'adjectif prend -a."),
        fill("Una camiseta ___.", "amarilla", ["amarillo", "amarillas", "azules"], "Un tee-shirt jaune.", "Camiseta est féminin singulier."),
        fill("Dos paños ___.", "azules", ["azul", "azuls", "azulos"], "Deux pagnes bleus.", "Azul finit par une consonne : pluriel en -es."),
        fill("El chico es ___.", "bajo", ["baja", "bajos", "mediana"], "Le garçon est petit.", "Chico est masculin : bajo."),
        fill("Esta es ___ madre.", "mi", ["mis", "me", "yo"], "Voici ma mère.", "Possessif : mi + singulier, mis + pluriel."),
        fill("Estos son ___ hermanos.", "mis", ["mi", "mío", "me"], "Voici mes frères et sœurs.", "Hermanos est au pluriel : mis."),
        order("Este es mi padre. Tiene cuarenta y cinco años.", "Voici mon père. Il a quarante-cinq ans."),
        order("La chica es de estatura mediana.", "La fille est de taille moyenne."),
        listen("Api tiene catorce años.", "Api a quatorze ans.", ["Api a quarante ans.", "Api a douze ans.", "Api a quatre ans."]),
        listen("una falda roja", "une jupe rouge", ["un pagne bleu", "un tee-shirt jaune", "une robe verte"]),
        match([("rojo", "rouge"), ("azul", "bleu"), ("amarillo", "jaune"), ("verde", "vert"), ("blanco", "blanc")], "Les couleurs"),
        match([("redonda", "ronde"), ("cuadrado", "carré"), ("rectangular", "rectangulaire"), ("alta", "grande"), ("bajo", "petit")], "Formes et taille"),
        speak("Esta es mi familia.", "Voici ma famille."),
    ],
    "m3-es-03": [
        mcq("Pourquoi le génie emporte-t-il Kadjo ?", "Porque no va al campo con sus padres.", ["Porque tiene hambre.", "Porque está sucio.", "Porque es pequeño."],
            "« Te llevo al fondo de la selva porque no vas al campo con tus padres. »"),
        mcq("Où les villageois retrouvent-ils Kadjo ?", "Debajo de un árbol, en la selva.", ["En el colegio.", "En el campo.", "En casa."]),
        mcq("Comment est Kadjo quand on le retrouve ?", "Sucio y con hambre.", ["Limpio y contento.", "Alto y fuerte.", "Rojo y amarillo."], "« ¡Pobre niño! Mira cómo está sucio. Tiene hambre. »"),
        mcq("Quelle est la morale du conte ?", "Hay que escuchar los consejos de los padres.", ["Hay que ir a la selva.", "Hay que jugar todo el día.", "Hay que tener hambre."]),
        mcq("Vrai ou faux : Kadjo écoutait toujours ses parents.", "Faux", ["Vrai"], "« No escuchaba los consejos de sus padres » : il ne les écoutait pas."),
        mcq("Vrai ou faux : le père va au champ avec une machette.", "Vrai", ["Faux"]),
        fill("Kadjo, ___ a tus padres.", "escucha", ["escuchad", "escuchar", "escuchas"], "Kadjo, écoute tes parents.", "Impératif tú : 3e personne du présent → escucha."),
        fill("¡Niños, ___ los consejos de vuestros padres!", "escuchad", ["escucha", "escuchan", "escuchar"], "Les enfants, écoutez les conseils de vos parents !",
             "Impératif vosotros : infinitif sans -r + -d."),
        fill("No, papá; no ___.", "voy", ["vas", "va", "ir"], "Non, papa ; je n'y vais pas.", "Ir au présent : voy, vas, va…"),
        fill("El niño tiene ___.", "hambre", ["sucio", "campo", "selva"], "L'enfant a faim.", "Tener hambre = avoir faim."),
        fill("___ una vez un niño llamado Kadjo.", "Érase", ["Hasta", "Había", "Era"], "Il était une fois un enfant nommé Kadjo.", "Formule d'ouverture des contes (Había una vez est aussi possible)."),
        order("Te llevo al fondo de la selva.", "Je t'emmène au fond de la forêt."),
        order("¡Kadjo! ¿Dónde estás?", "Kadjo ! Où es-tu ?"),
        order("Niños, escuchad los consejos de vuestros padres.", "Les enfants, écoutez les conseils de vos parents."),
        listen("¡Pobre niño!", "Pauvre enfant !", ["Petit enfant !", "Enfant sale !", "Viens, enfant !"]),
        speak("Niños, escuchad los consejos de vuestros padres.", "Les enfants, écoutez les conseils de vos parents."),
        match([("el campo", "le champ"), ("la selva", "la forêt"), ("el consejo", "le conseil"), ("sucio", "sale"), ("tener hambre", "avoir faim")], "Les mots du conte"),
    ],
    "m3-es-04": [
        mcq("Comment dit-on 15 ?", "quince", ["cinco", "cincuenta", "quinientos"]),
        mcq("Comment dit-on 70 ?", "setenta", ["sesenta", "siete", "setecientos"], "Attention : 60 = sesenta, 70 = setenta."),
        mcq("Comment dit-on 100 tout seul ?", "cien", ["ciento", "cientos", "un cien"], "Cien seul ou devant un nom ; ciento devant une autre unité (ciento uno)."),
        mcq("Comment dit-on 500 ?", "quinientos", ["cincocientos", "quinientas mil", "cincuenta"], "500, 700 et 900 sont irréguliers : quinientos, setecientos, novecientos."),
        mcq("« 200 personnes » :", "doscientas personas", ["doscientos personas", "dos cientas personas", "doscientas persona"], "Les centaines s'accordent avec le nom féminin."),
        mcq("Comment dit-on 1 000 ?", "mil", ["un mil", "cien mil", "mile"], "On ne dit pas « un mil »."),
        mcq("« 31 élèves » :", "treinta y un alumnos", ["treinta y uno alumnos", "treinta un alumnos", "treintiún alumnos"], "Uno devient un devant un nom masculin."),
        typed("2 300", ["dos mil trescientos"], "mil reste invariable : dos mil.", "Écrivez le nombre en lettres"),
        typed("cuarenta y siete", ["47"], "", "Écrivez en chiffres"),
        listen("Cuesta quinientos francos.", "Ça coûte 500 francs.", ["Ça coûte 50 francs.", "Ça coûte 5 000 francs.", "Ça coûte 150 francs."]),
        listen("Tengo dieciocho años.", "J'ai 18 ans.", ["J'ai 80 ans.", "J'ai 8 ans.", "J'ai 28 ans."]),
        listen("Hay treinta y dos alumnos.", "Il y a 32 élèves.", ["Il y a 22 élèves.", "Il y a 302 élèves.", "Il y a 12 élèves."]),
        fill("Quiero ___ naranjas.", "diez", ["dos", "doce", "dieciséis"], "Je veux dix oranges."),
        order("¿Cuántas naranjas quiere?", "Combien d'oranges voulez-vous ?"),
        order("Cuestan mil francos.", "Elles coûtent mille francs."),
        match([("veinte", "20"), ("treinta", "30"), ("cuarenta", "40"), ("cincuenta", "50"), ("noventa", "90")], "Les dizaines"),
        match([("doscientos", "200"), ("trescientos", "300"), ("quinientos", "500"), ("setecientos", "700"), ("novecientos", "900")], "Les centaines"),
        speak("¿Cuánto cuesta? Cuesta mil francos.", "Combien ça coûte ? Ça coûte mille francs."),
    ],
}

# ----------------------------------------------------------------------------- MODEL 3 : ateliers


def number_writing(nums, ref, title):
    return practice(title, "Écrivez chaque nombre en toutes lettres en espagnol, puis écoutez la correction.",
                    [typed(f"{n:,}".replace(",", " "), num_answers(n), "", "Écrivez en lettres") for n in nums], ref)


M3_PRACTICE = {
    "m3-es-01": [
        practice("Saluer au bon moment", "Choisissez la bonne salutation selon l'heure et la personne, puis dites-la.", [
            mcq("7 h du matin, vous croisez le directeur :", "¡Buenos días, señor director!", ["¡Buenas noches, señor director!", "¡Hola, tío!", "¡Hasta luego!"]),
            mcq("15 h, vous rentrez chez votre grand-mère :", "¡Buenas tardes, abuela!", ["¡Buenos días, abuela!", "¡Buenas noches, abuela!", "¡Adiós, abuela!"]),
            mcq("21 h, vous quittez vos amis après la veillée :", "¡Buenas noches! ¡Hasta mañana!", ["¡Buenos días!", "¡Buenas tardes! ¡Hola!", "¡Bienvenido!"]),
            mcq("Votre ami Koffi arrive dans la cour :", "¡Hola, Koffi! ¿Qué tal?", ["¡Buenas noches, señor Koffi!", "¿Cómo está usted, Koffi?", "¡Adiós, Koffi!"],
                "Entre amis, on emploie hola et qué tal, sans vouvoiement."),
            match([("¡Hola!", "Salut !"), ("¿Qué tal?", "Ça va ?"), ("Muy bien, gracias.", "Très bien, merci."), ("¡Hasta luego!", "À plus tard !"), ("¡Adiós!", "Au revoir !")]),
            speak("¡Buenas tardes, abuela! ¿Cómo está usted?", "Bonjour, grand-mère ! Comment allez-vous ?"),
        ]),
        practice("Compléter le dialogue du manuel (page 10)", "« Mes camarades et moi, nous complétons le dialogue. » Tapez le mot qui manque.", [
            fill("¡Hola! Me ___ Fatou.", ["llamo"], [], "Salut ! Je m'appelle Fatou."),
            fill("Yo ___ de Bouaké.", ["soy"], [], "Moi, je suis de Bouaké."),
            fill("¿Cómo te ___?", ["llamas"], [], "Comment t'appelles-tu ?"),
            fill("___ es Silué. Es de Korhogo.", ["Éste", "Este"], [], "Voici Silué. Il est de Korhogo."),
            fill("___ es Aya, mi compañera.", ["Ésta", "Esta"], [], "Voici Aya, ma camarade."),
            fill("___ son Koffi y Silué.", ["Éstos", "Estos"], [], "Voici Koffi et Silué."),
            fill("___ son Fatou y Aya.", ["Éstas", "Estas"], [], "Voici Fatou et Aya."),
            fill("Encantado, Silué. ¡___ al colegio!", ["Bienvenido"], [], "Enchanté, Silué. Bienvenue au collège !"),
        ]),
        practice("Je me présente et je présente un camarade", "Écrivez puis dites votre présentation.", [
            order("Me llamo Koffi y soy de Abiyán.", "Je m'appelle Koffi et je suis d'Abidjan."),
            order("Ésta es mi compañera Aya. Es de Man.", "Voici ma camarade Aya. Elle est de Man."),
            write("Présentez-vous (nom, ville) puis présentez un ou une camarade en 4 phrases.",
                  "¡Hola! Me llamo Awa. Soy de Yamoussoukro. Ésta es mi compañera Aya. Es de Man.",
                  ["me llamo", "soy de", "es de"], 12),
            speak("¡Hola! Me llamo Awa. Soy de Yamoussoukro.", "Salut ! Je m'appelle Awa. Je suis de Yamoussoukro."),
        ]),
    ],
    "m3-es-02": [
        practice("L'arbre de la famille d'Abolé", "Regardez l'arbre de la page 20 : Abolé 45 ans, Fatou 44 ans, Api 14 ans, Adou 12 ans, Yéli 10 ans.", [
            fill("Abolé es el ___ de Api.", ["padre"], ["hermano", "hijo", "abuelo"], "Abolé est le père d'Api."),
            fill("Fatou es la ___ de Adou.", ["madre"], ["hermana", "hija", "abuela"], "Fatou est la mère d'Adou."),
            fill("Adou es el ___ de Yéli.", ["hermano"], ["padre", "hijo", "tío"], "Adou est le frère de Yéli."),
            fill("Api y Yéli son ___.", ["hermanas"], ["hermanos", "padres", "madres"], "Api et Yéli sont sœurs.", "Deux filles : hermanas."),
            fill("Abolé y Fatou son los ___ de Adou.", ["padres"], ["hermanos", "hijos", "abuelos"], "Abolé et Fatou sont les parents d'Adou."),
            fill("Yéli es la ___ de Abolé.", ["hija"], ["madre", "hermana", "abuela"], "Yéli est la fille d'Abolé."),
            typed("¿Cuántos años tiene Abolé?", ["cuarenta y cinco", "tiene cuarenta y cinco años", "45"], "", "Répondez en lettres"),
            typed("¿Cuántos años tiene Fatou?", ["cuarenta y cuatro", "tiene cuarenta y cuatro años", "44"], "", "Répondez en lettres"),
            typed("¿Cuántos años tiene Api?", ["catorce", "tiene catorce años", "14"], "", "Répondez en lettres"),
            typed("¿Cuántos años tiene Yéli?", ["diez", "tiene diez años", "10"], "", "Répondez en lettres"),
        ]),
        practice("Formes, couleurs et taille", "Esquisse grammaticale : accordez l'adjectif avec le nom.", [
            fill("La mesa es ___.", ["redonda"], ["redondo", "redondas"], "La table est ronde."),
            fill("La sala de comer es ___.", ["rectangular"], ["rectangulara", "rectangulares"], "La salle à manger est rectangulaire."),
            fill("El salón es ___.", ["cuadrado"], ["cuadrada", "cuadrados"], "Le salon est carré.", "Le manuel écrit « cuadrada », mais salón est masculin : cuadrado."),
            fill("Un paño ___.", ["azul"], ["azula", "azules"], "Un pagne bleu."),
            fill("Una falda ___.", ["roja"], ["rojo", "rojas"], "Une jupe rouge."),
            fill("La chica es ___.", ["alta"], ["alto", "altas"], "La fille est grande."),
            match([("la mesa redonda", "la table ronde"), ("un paño azul", "un pagne bleu"), ("una camiseta amarilla", "un tee-shirt jaune"),
                   ("una falda roja", "une jupe rouge"), ("el chico bajo", "le garçon petit")]),
            speak("La chica es alta y el chico es bajo.", "La fille est grande et le garçon est petit."),
        ]),
        practice("J'intègre : mon carnet", "Tu passes une journée chez ton ami(e). Note dans ton carnet les informations sur sa famille.", [
            write("Écris 5 phrases sur la famille de ton ami(e) : noms, âges, taille, vêtements.",
                  "La familia de mi amiga Aya es grande. Su padre se llama Yao y tiene cincuenta años. Es alto. Su madre lleva un paño verde. Aya tiene dos hermanos.",
                  ["su padre", "su madre", "tiene", "años", "es", "lleva"], 25),
            speak("Su padre se llama Yao y tiene cincuenta años.", "Son père s'appelle Yao et il a cinquante ans."),
        ]),
    ],
    "m3-es-03": [
        practice("Raconter le conte de Kadjo", "Remettez chaque phrase dans l'ordre, puis racontez le conte à voix haute.", [
            order("Érase una vez un niño llamado Kadjo.", "Il était une fois un enfant nommé Kadjo."),
            order("No escuchaba los consejos de sus padres.", "Il n'écoutait pas les conseils de ses parents."),
            order("Kadjo, vamos al campo. No papá, no voy.", "Kadjo, allons au champ. Non papa, je n'y vais pas."),
            order("Un genio lo llevó al fondo de la selva.", "Un génie l'emporta au fond de la forêt."),
            order("¡Pobre niño! Mira cómo está sucio.", "Pauvre enfant ! Regarde comme il est sale."),
            mcq("Remettez les images dans l'ordre : que se passe-t-il juste après le refus de Kadjo ?",
                "Le génie l'emporte dans la forêt.", ["Les villageois le retrouvent.", "Le grand-père donne la morale.", "Kadjo va au champ."]),
            speak("Érase una vez un niño llamado Kadjo. No escuchaba los consejos de sus padres.", "Il était une fois un enfant nommé Kadjo. Il n'écoutait pas les conseils de ses parents."),
        ]),
        practice("Je découvre : donner des conseils", "Relevez et utilisez l'expression liée à « donner des conseils ».", [
            mcq("Quelle bulle donne un conseil ?", "¡Niños, escuchad los consejos de vuestros padres!",
                ["Kadjo, vamos al campo.", "¡Kadjo! ¿Dónde estás?", "Érase una vez, un niño llamado Kadjo."]),
            fill("Hijo, ___ a tu madre.", ["escucha"], [], "Mon fils, écoute ta mère.", "escuchar → escucha (tú)."),
            fill("___ bien, Kadjo. (comer)", ["Come"], [], "Mange bien, Kadjo."),
            fill("___ tus lecciones. (estudiar)", ["Estudia"], [], "Étudie tes leçons."),
            fill("___ al campo con nosotros. (venir)", ["Ven"], [], "Viens au champ avec nous.", "Venir est irrégulier : ven."),
            fill("Niños, ___ a la escuela. (ir)", ["id", "vayan"], [], "Les enfants, allez à l'école.", "Ir → id (vosotros) ; vayan (ustedes)."),
            write("Écris 3 conseils à un petit frère avec l'impératif, plus une phrase avec « no ».",
                  "Escucha a papá y a mamá. Come bien. Estudia tus lecciones. No juegues en la selva.",
                  ["escucha", "come", "estudia", "no"], 10),
        ]),
    ],
    "m3-es-04": [
        practice("Compter dans les deux sens", "Dites chaque série au micro sans regarder, puis réécoutez la correction.", [
            speak("cero, uno, dos, tres, cuatro, cinco, seis, siete, ocho, nueve, diez", "0 à 10"),
            speak("once, doce, trece, catorce, quince, dieciséis, diecisiete, dieciocho, diecinueve, veinte", "11 à 20"),
            speak("veinte, diecinueve, dieciocho, diecisiete, dieciséis, quince, catorce, trece, doce, once, diez", "20 à 10 (à l'envers)"),
            speak("diez, veinte, treinta, cuarenta, cincuenta, sesenta, setenta, ochenta, noventa, cien", "Les dizaines jusqu'à 100"),
            speak("cien, doscientos, trescientos, cuatrocientos, quinientos, seiscientos, setecientos, ochocientos, novecientos, mil", "Les centaines jusqu'à 1 000"),
            order("diez veinte treinta cuarenta cincuenta", "10, 20, 30, 40, 50"),
        ], "Exercice oral 1"),
        number_writing([4, 9, 12, 16, 19, 21, 28, 35, 47, 52, 69, 73, 88, 94, 100, 101, 115, 240, 506, 999, 1000, 2300, 10000],
                       "Exercice écrit 2", "Écrire les nombres en toutes lettres"),
        practice("Retrouver les chiffres", "Écrivez chaque nombre en chiffres.", [
            typed(w, digits(n), "", "Écrivez en chiffres") for w, n in (("diecisiete", 17), ("veintidós", 22), ("treinta y seis", 36), ("cincuenta y uno", 51),
                                                                         ("ochenta y cuatro", 84), ("ciento veinte", 120), ("trescientos nueve", 309),
                                                                         ("setecientos cincuenta", 750), ("dos mil", 2000))
        ], "Exercice 3"),
        practice("Les nombres dans la vie quotidienne", "Complétez en lettres.", [
            fill("Tengo ___ años.", ["dieciocho"], [], "J'ai 18 ans."),
            fill("Mi familia tiene ___ personas.", ["siete"], [], "Ma famille compte 7 personnes."),
            fill("Hay ___ alumnos en la clase.", ["treinta y dos"], [], "Il y a 32 élèves dans la classe."),
            fill("El libro cuesta ___ francos.", ["quinientos"], [], "Le livre coûte 500 francs."),
            fill("Vivo en la casa número ___.", ["veinticuatro", "veinte y cuatro"], [], "J'habite au numéro 24."),
            speak("Tengo dieciocho años y vivo en la casa número veinticuatro.", "J'ai 18 ans et j'habite au numéro 24."),
        ], "Exercice 4"),
        practice("Présente ta famille", "Écris 5 à 8 phrases. Tu peux remplacer les noms par ceux de ta famille.", [
            order("Mi familia es grande. Tengo dos hermanos.", "Ma famille est grande. J'ai deux frères."),
            fill("Mi ___ se llama Abolé y mi madre se llama Fatou.", ["padre"], ["madre", "hermano"], "Mon père s'appelle Abolé et ma mère s'appelle Fatou."),
            write("Présente ta famille en 5 à 8 phrases.",
                  "Me llamo Api. Tengo catorce años. Mi padre se llama Abolé y mi madre se llama Fatou. Tengo un hermano y una hermana. Mi familia es muy simpática.",
                  ["me llamo", "mi padre", "mi madre", "tengo", "hermanos", "mi familia"], 30),
            speak("Me llamo Api. Tengo catorce años. Mi familia es muy simpática.", "Je m'appelle Api. J'ai 14 ans. Ma famille est très sympathique."),
        ], "Activité 1"),
        practice("Jouer une scène de salutations", "Jouez la rencontre devant l'école : saluer, demander comment ça va, répondre, prendre congé.", [
            speak("¡Hola, Aya! ¿Cómo estás?", "Salut, Aya ! Comment vas-tu ?"),
            speak("Estoy bien, gracias. ¿Y tú?", "Je vais bien, merci. Et toi ?"),
            speak("Muy bien. ¡Hasta mañana!", "Très bien. À demain !"),
            mcq("Remplacez « hasta mañana » par une autre formule d'adieu :", "Hasta pronto", ["Buenos días", "Encantado", "Bienvenido"], "Hasta pronto = à bientôt ; hasta luego = à plus tard."),
            order("Estoy bien, gracias. ¿Y tú?", "Je vais bien, merci. Et toi ?"),
        ], "Activité 2"),
        practice("Donner un conseil", "Un enfant ne veut pas écouter ses parents : donne-lui des conseils à l'impératif.", [
            fill("___ a tus padres.", ["Escucha"], ["Escuchas", "Escuchar"], "Écoute tes parents."),
            fill("___ a casa temprano.", ["Ven"], ["Vienes", "Venir"], "Viens tôt à la maison."),
            fill("___ tus lecciones.", ["Estudia"], ["Estudias", "Estudiar"], "Étudie tes leçons."),
            fill("___ en la selva solo.", ["No juegues", "No vayas"], [], "Ne joue pas seul dans la forêt."),
            write("Écris trois conseils avec escucha, ven, estudia ou come, et une phrase négative avec no.",
                  "Escucha a tus padres. Ven al campo. Estudia mucho. No vayas a la selva solo.", ["escucha", "ven", "estudia", "no"], 10),
        ], "Activité 3"),
        practice("Mini-marché des nombres", "Le client demande trois articles, le vendeur annonce les prix. Calculez et répondez en lettres.", [
            listen("Cuesta trescientos cincuenta francos.", "350 F", ["305 F", "530 F", "3 500 F"]),
            listen("Son mil doscientos francos.", "1 200 F", ["1 002 F", "2 100 F", "120 F"]),
            typed("Tomates : 400 F + naranjas : 600 F. ¿Cuánto es en total?", ["mil", "mil francos", "son mil francos"], "400 + 600 = 1 000 : mil.", "Écrivez le total en lettres"),
            typed("Arroz : 1 500 F + aceite : 1 000 F. ¿Cuánto es?", ["dos mil quinientos", "dos mil quinientos francos"], "", "Écrivez le total en lettres"),
            typed("Pagas con 5 000 F un total de 3 250 F. ¿Cuánto es la vuelta?", ["mil setecientos cincuenta", "mil setecientos cincuenta francos"], "5 000 − 3 250 = 1 750.", "Écrivez la monnaie en lettres"),
            order("Buenos días. ¿Cuánto cuesta el kilo de tomates?", "Bonjour. Combien coûte le kilo de tomates ?"),
            write("Écris le dialogue du mini-marché (client et vendeur) avec au moins cinq nombres, dont un au-dessus de 100 et un au-dessus de 1 000.",
                  "— Buenos días. ¿Cuánto cuesta el pan? — Doscientos francos. — ¿Y el arroz? — Mil quinientos francos. — Quiero dos panes y un kilo de arroz. — Son mil novecientos francos.",
                  ["cuánto cuesta", "francos", "quiero", "mil"], 25),
        ], "Activité 4"),
        practice("Le dialogue au marché", "Remettez les répliques du petit dialogue dans l'ordre, puis jouez-le.", [
            order("Buenos días. ¿Cuántas naranjas quiere?", "Bonjour. Combien d'oranges voulez-vous ?"),
            order("Quiero diez naranjas.", "Je veux dix oranges."),
            order("Cuestan mil francos.", "Elles coûtent mille francs."),
            order("Aquí tiene. Gracias.", "Voici. Merci."),
            speak("¡Muchas gracias! ¡Hasta luego!", "Merci beaucoup ! À plus tard !"),
        ]),
        practice("Écouter les nombres", "Écoutez le nombre et choisissez le bon chiffre.", [
            listen(es_num(n), f"{n:,}".replace(",", " "), [f"{m:,}".replace(",", " ") for m in w])
            for n, w in ((13, (30, 3, 33)), (60, (70, 16, 600)), (77, (67, 707, 17)), (150, (115, 105, 1500)),
                         (340, (430, 304, 3400)), (900, (90, 9000, 190)), (1001, (101, 1100, 11)), (5600, (5060, 6500, 560)))
        ]),
    ],
}

# ----------------------------------------------------------------------------- MODEL 2 : ateliers construits


def m2_practice(lesson, rnd):
    items = []
    lines = [l for sc in lesson.get("scenes", []) for l in sc["lines"]]
    users = [l for l in lines if l["speaker"] == "B" and 3 <= len(l["text"].split()) <= 10]
    for l in rnd.sample(users, min(3, len(users))):
        items.append(order(l["text"], l["translation"], f"Réplique de {l.get('name', '')}."))
    exs = [e for g in lesson.get("grammar", []) for e in g.get("examples", []) if 3 <= len(e["text"].split()) <= 9]
    singles = sorted({w for v in lesson["vocab"] for w in [v["word"]] if re.fullmatch(r"[a-záéíóúñ]+", v["word"])})
    for e in exs[:6]:
        words = [w for w in re.findall(r"[A-Za-zÁÉÍÓÚÑáéíóúñ]+", e["text"]) if len(w) > 3]
        if not words:
            continue
        w = max(words, key=len)
        others = [x for x in singles if x != w.lower()] or ["es", "son", "hay"]
        items.append(fill(re.sub(rf"\b{re.escape(w)}\b", "___", e["text"], count=1), [w], [], e["translation"], "Tapez le mot manquant."))
        if len(items) >= 7:
            break
    for l in rnd.sample(users, min(2, len(users))):
        items.append(speak(l["text"], l["translation"]))
    hw = lesson.get("homework", [])
    if hw:
        h = hw[-1]
        items.append(write(h["prompt"], h.get("model", ""), h.get("keywords", [])[:6], 15))
    title = "Atelier : " + lesson["title"]
    return [practice(title, "Remettez dans l'ordre, complétez, dites au micro puis rédigez : tout se corrige ici.", items)]


# ----------------------------------------------------------------------------- exécution


def run(name, hand_quiz, hand_practice, auto_practice=None):
    path = ASSETS / f"{name}.json"
    doc = json.loads(path.read_text(encoding="utf-8"))
    content_plus.apply(name, doc)  # cours augmentés (nouvelles unités, mots, grammaire, phrases)
    model_vocab = [v for l in doc["lessons"] for v in l["vocab"]]
    for lesson in doc["lessons"]:
        rnd = random.Random(lesson["id"])
        base = [q for q in lesson["quiz"] if not q.get("gen") and not q.get("hand")]
        hand = [dict(q, hand=True) for q in hand_quiz.get(lesson["id"], [])]
        lesson["quiz"] = base
        lesson["quiz"] = base + hand + generate(lesson, model_vocab, rnd)
        if lesson["id"] in hand_practice:
            lesson["practice"] = hand_practice[lesson["id"]]
        elif auto_practice:
            lesson["practice"] = auto_practice(lesson, rnd)
        # contrôles
        for q in lesson["quiz"] + [i for p in lesson.get("practice", []) for i in p["items"]]:
            if q["type"] in ("mcq", "listen"):
                assert q["correct"] not in q["wrong"], (lesson["id"], q)
            if q["type"] == "fill":
                assert "___" in q["sentence"], q
    fictionalize(doc)  # villes et quartiers fictifs (tools/fictional_places.py)
    path.write_text(json.dumps(doc, ensure_ascii=False, indent=1), encoding="utf-8")
    for l in doc["lessons"]:
        kinds = {}
        for q in l["quiz"]:
            kinds[q["type"]] = kinds.get(q["type"], 0) + 1
        print(name, l["id"], "quiz", len(l["quiz"]), kinds, "| ateliers", len(l.get("practice", [])),
              sum(len(p["items"]) for p in l.get("practice", [])))


if __name__ == "__main__":
    run("es_model3", M3_QUIZ, M3_PRACTICE)
    run("es_model2", {}, {}, m2_practice)
