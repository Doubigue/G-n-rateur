#!/usr/bin/env python3
"""Nouvelles illustrations en aplats (même style que flat_scenes.py) et couvertures des leçons.

1. Scènes de dialogue supplémentaires → app/src/main/assets/scenes/<id>.webp
   hotel, farmacia, entrevista, reciclaje, casa, comida, numeros, horario
2. Couvertures des leçons sans illustration → app/src/main/assets/manual_images/
   MODEL 2 leçons 17 à 20, MODEL 3 unités 2 à 8 : une scène + un bandeau « LEÇON n · titre ».

Usage : python3 tools/flat_scenes_plus.py [dossier_aperçus]
"""
import io
import subprocess
import sys
from pathlib import Path

from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parent))
import flat_scenes as fs  # noqa: E402
from flat_scenes import S, SKINS, W, H, GY  # noqa: E402


def sign(s, x, y, w, text, bg="#FFFFFF", fg="#1D3557", border="#1D3557", size=22):
    s.add(f'<rect x="{x}" y="{y}" width="{w}" height="40" rx="8" fill="{bg}" stroke="{border}" stroke-width="4"/>'
          f'<text x="{x + w / 2}" y="{y + 28}" font-family="DejaVu Sans" font-weight="bold" font-size="{size}" text-anchor="middle" fill="{fg}">{text}</text>')


def counter(s, x, w, top=GY - 120, color="#8A5530", front="url(#waxB)"):
    s.add(f'<rect x="{x}" y="{top}" width="{w}" height="18" fill="{fs.shade(color, .15)}"/>'
          f'<rect x="{x + 8}" y="{top + 18}" width="{w - 16}" height="{GY - top - 10}" fill="{color}"/>'
          f'<rect x="{x + 8}" y="{top + 40}" width="{w - 16}" height="34" fill="{front}" opacity=".9"/>')


def suitcase(s, x, col="#C1121F"):
    s.add(f'<rect x="{x}" y="{GY - 66}" width="64" height="70" rx="8" fill="{col}"/><rect x="{x + 18}" y="{GY - 84}" width="28" height="20" rx="6" fill="none" stroke="#2B2B2B" stroke-width="6"/>'
          f'<path d="M{x + 14} {GY - 60} v60 M{x + 50} {GY - 60} v60" stroke="{fs.shade(col, -.3)}" stroke-width="5"/>'
          f'<circle cx="{x + 12}" cy="{GY + 6}" r="6" fill="#222"/><circle cx="{x + 52}" cy="{GY + 6}" r="6" fill="#222"/>')


def shelves(s, x, y, w, rows=3, seed=1):
    import random
    rnd = random.Random(seed)
    cols = ["#E63946", "#2A9D8F", "#F4A261", "#457B9D", "#FFFFFF", "#80B918", "#F2C14E"]
    for r in range(rows):
        yy = y + r * 70
        s.add(f'<rect x="{x}" y="{yy + 56}" width="{w}" height="10" fill="#8A5530"/>')
        xx = x + 8
        while xx < x + w - 30:
            bw = rnd.choice((22, 28, 34))
            bh = rnd.choice((34, 42, 50))
            s.add(f'<rect x="{xx}" y="{yy + 56 - bh}" width="{bw}" height="{bh}" rx="3" fill="{rnd.choice(cols)}"/>'
                  f'<rect x="{xx + 4}" y="{yy + 56 - bh + 8}" width="{bw - 8}" height="6" fill="#FFFFFF" opacity=".6"/>')
            xx += bw + 6


# --------------------------------------------------------------------------- scènes

def sc_hotel():
    s = S(); s.wall_in("#F3E9DC")
    s.add('<rect y="0" width="960" height="36" fill="url(#kente)" opacity=".85"/>')
    sign(s, 330, 70, 300, "HOTEL DEL PUERTO", bg="#1D3557", fg="#FFD166", border="#FFD166", size=24)
    s.add('<rect x="660" y="120" width="230" height="150" fill="#8ECAE6"/><path d="M660 120 h230 v150 h-230 Z" fill="none" stroke="#FFFFFF" stroke-width="10"/>'
          '<path d="M660 230 q60 -30 115 0 t115 0 v40 h-230 Z" fill="#2A9D8F"/><circle cx="830" cy="165" r="20" fill="#FFD23F"/>')
    s.add('<rect x="80" y="110" width="170" height="130" rx="6" fill="#6B4220"/>')
    for r in range(3):
        for c in range(4):
            s.add(f'<circle cx="{110 + c * 38}" cy="{140 + r * 36}" r="6" fill="#D4AF37"/><path d="M{110 + c * 38} {146 + r * 36} v14" stroke="#D4AF37" stroke-width="4"/>')
    s.floor_in(480)
    s.person(330, "woman", 250, 1, skin=SKINS[3], cloth="#FFFFFF", arms=("hold", "point"), mouth="open")
    counter(s, 190, 300)
    s.add('<rect x="380" y="352" width="60" height="10" fill="#F2C14E"/><circle cx="250" cy="350" r="12" fill="#D4AF37"/><rect x="246" y="356" width="8" height="8" fill="#D4AF37"/>')
    s.person(640, "woman", 255, -1, skin=SKINS[1], cloth="url(#waxC)", arms=("hold", "down"), mouth="open")
    suitcase(s, 720)
    s.add('<path d="M870 500 q-10 -60 0 -120 q30 -10 40 30 q-10 50 -40 90 Z" fill="#3E7C3A"/><rect x="860" y="470" width="50" height="36" rx="6" fill="#B5651D"/>')
    s.frame(); return s


def sc_farmacia():
    s = S(); s.wall_in("#E9F5EE")
    s.add('<rect x="390" y="50" width="70" height="70" rx="10" fill="#2A9D8F"/><path d="M425 62 v46 M402 85 h46" stroke="#FFFFFF" stroke-width="14"/>')
    sign(s, 480, 64, 200, "FARMACIA", bg="#FFFFFF", fg="#2A9D8F", border="#2A9D8F")
    shelves(s, 60, 140, 300, seed=3); shelves(s, 600, 140, 300, seed=7)
    s.floor_in(480)
    s.person(300, "nurse", 250, 1, skin=SKINS[2], cloth="#FFFFFF", arms=("hold", "point"), mouth="open")
    counter(s, 160, 330, front="#2A9D8F")
    s.add('<rect x="420" y="336" width="44" height="30" rx="4" fill="#FFFFFF"/><rect x="424" y="344" width="36" height="6" fill="#E63946"/>'
          '<rect x="360" y="342" width="40" height="24" rx="3" fill="#F2C14E"/>')
    s.person(640, "man", 255, -1, skin=SKINS[0], cloth="url(#waxC)", pants="#3D405B", arms=("hold", "chin"))
    s.add('<rect x="560" y="300" width="56" height="70" rx="4" fill="#FFFFFF" stroke="#457B9D" stroke-width="3"/><path d="M570 318 h36 M570 332 h30 M570 346 h36" stroke="#457B9D" stroke-width="3"/>')
    s.frame(); return s


def sc_entrevista():
    s = S(); s.wall_in("#EEF1F6")
    sign(s, 80, 60, 240, "RECURSOS HUMANOS", size=18)
    s.add('<rect x="610" y="60" width="280" height="190" fill="#8ECAE6"/><path d="M610 60 h280 v190 h-280 Z" fill="none" stroke="#FFFFFF" stroke-width="12"/>'
          '<path d="M640 250 v-90 h46 v90 M700 250 v-140 h50 v140 M764 250 v-70 h40 v70 M816 250 v-120 h48 v120" fill="#5C7A99"/>'
          '<path d="M400 70 h120 v150 h-120 Z" fill="#FFFFFF" stroke="#3D405B" stroke-width="5"/><path d="M415 200 l25 -40 l25 20 l25 -50 l15 20" stroke="#2A9D8F" stroke-width="6" fill="none"/>')
    s.floor_in(480)
    s.add('<rect x="300" y="380" width="360" height="22" fill="#5C3A1E"/><rect x="316" y="402" width="16" height="104" fill="#3E2614"/><rect x="628" y="402" width="16" height="104" fill="#3E2614"/>'
          '<rect x="380" y="352" width="80" height="28" fill="#FFFFFF" stroke="#999" stroke-width="2"/><path d="M390 362 h60 M390 370 h48" stroke="#999" stroke-width="3"/>'
          '<rect x="520" y="350" width="70" height="30" rx="3" fill="#2B2B2B"/>')
    s.chair(220, 1); s.chair(740, -1)
    s.person(240, "woman", 232, 1, skin=SKINS[1], cloth="#1D3557", arms=("hold", "point"), seated=True, mouth="open")
    s.person(720, "man", 240, -1, skin=SKINS[2], cloth="#FFFFFF", pants="#2F3E46", arms=("hold", "chin"), seated=True)
    s.frame(); return s


def sc_reciclaje():
    s = S("skyDay"); s.sky_bg(); s.sun(860, 80, 38); s.cloud(250, 80)
    s.ground("#C9B79C", grass=False)
    s.house(560, 330, 150, wall="#F4E1C1", roof="#C0392B", windows=2)
    s.add('<path d="M40 150 h420" stroke="#5C4033" stroke-width="4"/><rect x="60" y="150" width="380" height="60" fill="#2A9D8F"/>'
          '<text x="250" y="192" font-family="DejaVu Sans" font-weight="bold" font-size="28" text-anchor="middle" fill="#FFFFFF">¡BARRIO LIMPIO!</text>')
    for i, (x, col, lab) in enumerate(((60, "#457B9D", "PLÁSTICO"), (150, "#2A9D8F", "PAPEL"), (240, "#6A994E", "ORGÁNICO"))):
        s.add(f'<path d="M{x} {GY - 90} h76 l-6 96 h-64 Z" fill="{col}"/><rect x="{x - 4}" y="{GY - 100}" width="84" height="14" rx="4" fill="{fs.shade(col, -.25)}"/>'
              f'<text x="{x + 38}" y="{GY - 44}" font-family="DejaVu Sans" font-weight="bold" font-size="11" text-anchor="middle" fill="#FFFFFF">{lab}</text>'
              f'<path d="M{x + 26} {GY - 30} l12 -14 l12 14 Z" fill="none" stroke="#FFFFFF" stroke-width="3"/>')
    for x, y, r in ((420, 520, 10), (470, 540, 0), (900, 530, 30), (520, 560, -20)):
        s.add(f'<g transform="rotate({r} {x} {y})"><rect x="{x}" y="{y}" width="34" height="14" rx="5" fill="#BDE0FE"/><rect x="{x + 32}" y="{y + 3}" width="8" height="8" fill="#1D3557"/></g>')
    s.person(420, "boy", 225, 1, skin=SKINS[0], cloth="#F77F00", pants="#264653", arms=("down", "point"), mouth="open")
    s.person(560, "girl", 220, -1, skin=SKINS[1], cloth="url(#waxD)", arms=("basket", "wave"), mouth="open")
    s.person(800, "woman", 250, -1, skin=SKINS[3], cloth="url(#waxA)", arms=("hold", "down"))
    s.add('<rect x="740" y="380" width="30" height="80" fill="#6B4220"/><path d="M735 380 h40 l-8 -14 h-24 Z" fill="#E9C46A"/>')
    s.frame(); return s


def sc_casa():
    s = S("skyDay"); s.sky_bg(); s.sun(880, 70, 32)
    s.ground("#D9A05B")
    # maison en coupe : salon, cuisine, chambre
    s.add('<path d="M70 200 L480 60 L890 200 Z" fill="#B5473A"/><rect x="100" y="200" width="760" height="304" fill="#F4E1C1"/>'
          '<rect x="100" y="200" width="760" height="10" fill="#C9A27A"/><path d="M360 210 v294 M620 210 v294" stroke="#C9A27A" stroke-width="10"/>')
    for x, lab in ((230, "SALÓN"), (490, "COCINA"), (740, "HABITACIÓN")):
        s.add(f'<text x="{x}" y="244" font-family="DejaVu Sans" font-weight="bold" font-size="18" text-anchor="middle" fill="#7A4A26">{lab}</text>')
    s.add('<rect x="130" y="400" width="200" height="50" rx="12" fill="#457B9D"/><rect x="130" y="380" width="200" height="30" rx="10" fill="#5FA8D3"/><rect x="140" y="450" width="12" height="50" fill="#3D405B"/><rect x="308" y="450" width="12" height="50" fill="#3D405B"/>'
          '<rect x="390" y="420" width="200" height="84" fill="#8A5530"/><rect x="400" y="400" width="80" height="20" fill="#3D405B"/><ellipse cx="440" cy="396" rx="26" ry="10" fill="#555"/>'
          '<rect x="500" y="280" width="80" height="60" fill="#8ECAE6" stroke="#FFFFFF" stroke-width="6"/>'
          '<rect x="650" y="420" width="190" height="60" fill="url(#waxD)"/><rect x="650" y="404" width="40" height="22" rx="6" fill="#FFFFFF"/><rect x="650" y="480" width="190" height="20" fill="#6B4220"/>'
          '<rect x="700" y="280" width="70" height="60" fill="#8ECAE6" stroke="#FFFFFF" stroke-width="6"/>')
    s.person(230, "girl", 200, 1, skin=SKINS[1], cloth="url(#waxC)", arms=("down", "point"), mouth="open")
    s.person(60, "boy", 200, 1, skin=SKINS[0], cloth="#FFD166", pants="#1D3557", arms=("down", "wave"))
    s.tree(920, .55)
    s.frame(); return s


def sc_comida():
    s = S(); s.wall_in("#F6E7C8")
    s.add('<rect x="80" y="70" width="260" height="170" fill="#8ECAE6"/><path d="M80 70 h260 v170 h-260 Z" fill="none" stroke="#FFFFFF" stroke-width="10"/><path d="M210 70 v170" stroke="#FFFFFF" stroke-width="8"/>'
          '<path d="M60 50 q30 110 0 210 h36 q-24 -100 0 -210 Z M360 50 q-30 110 0 210 h-36 q24 -100 0 -210 Z" fill="url(#waxA)"/>')
    s.add('<rect x="600" y="90" width="260" height="150" rx="8" fill="#FFFFFF" stroke="#8B5A2B" stroke-width="6"/>'
          '<text x="730" y="130" font-family="DejaVu Sans" font-weight="bold" font-size="22" text-anchor="middle" fill="#8B5A2B">MENÚ DEL DÍA</text>'
          '<text x="730" y="166" font-family="DejaVu Sans" font-size="18" text-anchor="middle" fill="#3D405B">attiéké con pescado</text>'
          '<text x="730" y="194" font-family="DejaVu Sans" font-size="18" text-anchor="middle" fill="#3D405B">alloco · pollo</text>'
          '<text x="730" y="222" font-family="DejaVu Sans" font-size="18" text-anchor="middle" fill="#3D405B">zumo de mango</text>')
    s.floor_in(480)
    s.chair(250, 1); s.chair(710, -1)
    s.person(270, "girl", 200, 1, skin=SKINS[1], cloth="url(#waxB)", arms=("hold", "point"), seated=True, mouth="open")
    s.person(690, "girl", 196, -1, skin=SKINS[5], cloth="#E63946", arms=("hold", "down"), seated=True)
    s.round_table(480, 380, 360, cloth="url(#waxC)")
    s.add('<ellipse cx="380" cy="372" rx="30" ry="10" fill="#FFFFFF"/><path d="M356 370 q24 -24 48 0 Z" fill="#F4A259"/>'
          '<ellipse cx="580" cy="372" rx="30" ry="10" fill="#FFFFFF"/><path d="M558 370 l10 -14 l10 14 l10 -14 l10 14 Z" fill="#E9C46A"/>')
    s.frame(); return s


def sc_numeros():
    s = S(); s.wall_in("#F6E7C8")
    s.add('<rect y="0" width="960" height="40" fill="url(#kente)" opacity=".9"/>')
    s.blackboard(260, 80, 440, 190, "1 · 10 · 100")
    s.add('<rect x="60" y="80" width="140" height="200" rx="8" fill="#FFFFFF" stroke="#8B5A2B" stroke-width="6"/>')
    for k in range(5):
        s.add(f'<circle cx="{90 + (k % 2) * 40}" cy="{110 + k * 34}" r="12" fill="{["#E63946", "#F77F00", "#FFD23F", "#2A9D8F", "#1D4E89"][k]}"/>'
              f'<text x="{150}" y="{117 + k * 34}" font-family="DejaVu Sans" font-weight="bold" font-size="20" text-anchor="middle" fill="#3D405B">{k + 1}</text>')
    s.floor_in(470)
    s.person(210, "teacher", 270, 1, skin=SKINS[2], cloth="url(#waxB)", pants="#2F3E46", arms=("point", "hold"), mouth="open", accessory="book")
    for i, (xx, kind, cl, sk) in enumerate(((520, "boy", "#FFFFFF", SKINS[0]), (720, "girl", "url(#waxD)", SKINS[1]))):
        s.person(xx, kind, 170, -1, skin=sk, cloth=cl, pants="#2B4C7E", arms=("hold", "wave" if i == 0 else "down"), seated=True)
        s.desk(xx - 110, 120)
    s.bubble(560, 300, "¡Cien!", tail=-1)
    s.frame(); return s


def sc_horario():
    s = S(); s.wall_in("#EEF4E6")
    s.add('<rect x="250" y="60" width="460" height="260" rx="10" fill="#FFFFFF" stroke="#1D4E89" stroke-width="6"/>'
          '<text x="480" y="98" font-family="DejaVu Sans" font-weight="bold" font-size="24" text-anchor="middle" fill="#1D4E89">HORARIO</text>')
    days = ["LUN", "MAR", "MIÉ", "JUE", "VIE"]
    cols = ["#E63946", "#F4A261", "#2A9D8F", "#457B9D", "#80B918", "#F2C14E"]
    for i, d in enumerate(days):
        x = 280 + i * 84
        s.add(f'<text x="{x + 36}" y="134" font-family="DejaVu Sans" font-weight="bold" font-size="16" text-anchor="middle" fill="#3D405B">{d}</text>')
        for r in range(4):
            s.add(f'<rect x="{x}" y="{146 + r * 40}" width="72" height="32" rx="4" fill="{cols[(i + r * 2) % 6]}" opacity=".85"/>')
    s.floor_in(480)
    s.person(260, "boy", 225, 1, skin=SKINS[0], cloth="#FFFFFF", pants="#2B4C7E", arms=("down", "point"), mouth="open")
    s.person(700, "girl", 220, -1, skin=SKINS[1], cloth="url(#waxC)", arms=("hold", "down"))
    s.add('<rect x="600" y="380" width="44" height="60" rx="6" fill="#E76F51"/><path d="M606 380 q16 -24 32 0" stroke="#7A2E1E" stroke-width="5" fill="none"/>')
    s.frame(); return s


def sc_cocina():
    s = S("skyWarm"); s.sky_bg(); s.sun(820, 90, 40)
    s.ground("#CF8A4C")
    s.add('<rect x="40" y="200" width="14" height="300" fill="#6B4220"/><rect x="520" y="200" width="14" height="300" fill="#6B4220"/>'
          '<path d="M10 220 L290 130 L570 220 Q290 240 10 220 Z" fill="url(#thatch)"/>')
    s.fire(300)
    s.add('<path d="M240 440 q60 30 120 0 l-10 60 q-50 20 -100 0 Z" fill="#2B2B2B"/><ellipse cx="300" cy="440" rx="62" ry="12" fill="#444"/>'
          '<path d="M280 420 q-8 -14 0 -28 q8 -14 0 -28 M310 418 q-8 -14 0 -28 q8 -14 0 -28" stroke="#FFFFFF" stroke-width="4" fill="none" opacity=".7"/>')
    s.add('<rect x="610" y="420" width="200" height="16" fill="#8A5530"/><rect x="620" y="436" width="12" height="70" fill="#6B4220"/><rect x="786" y="436" width="12" height="70" fill="#6B4220"/>'
          '<circle cx="650" cy="408" r="14" fill="#E63946"/><circle cx="680" cy="410" r="12" fill="#E63946"/><ellipse cx="730" cy="410" rx="18" ry="12" fill="#C9A0DC"/>'
          '<path d="M760 412 l30 -6 l-30 -6 Z" fill="#80B918"/>')
    s.person(150, "woman", 255, 1, skin=SKINS[3], cloth="url(#waxA)", arms=("point", "down"), mouth="open")
    s.person(470, "girl", 215, -1, skin=SKINS[1], cloth="url(#waxC)", arms=("hold", "chin"))
    s.palm(900, 280)
    s.frame(); return s


def sc_futbol():
    s = S("skyDay"); s.sky_bg(); s.cloud(200, 80); s.sun(860, 80, 36)
    s.add('<rect y="300" width="960" height="300" fill="#4F9D3A"/>')
    for k in range(6):
        s.add(f'<rect x="{k * 160}" y="300" width="80" height="300" fill="#5DAA45"/>')
    s.add('<path d="M0 470 H960" stroke="#FFFFFF" stroke-width="5" opacity=".8"/><ellipse cx="480" cy="470" rx="140" ry="34" fill="none" stroke="#FFFFFF" stroke-width="5" opacity=".8"/>'
          '<path d="M720 240 h200 v130" fill="none" stroke="#FFFFFF" stroke-width="8"/><path d="M720 240 v130" stroke="#FFFFFF" stroke-width="8"/>'
          '<path d="M728 248 h184 v118 h-184 Z" fill="none" stroke="#FFFFFF" stroke-width="1.5" opacity=".7"/>')
    for x in range(740, 920, 14):
        s.add(f'<path d="M{x} 248 v118" stroke="#FFFFFF" stroke-width="1" opacity=".5"/>')
    s.person(250, "man", 265, 1, skin=SKINS[2], cloth="#1D3557", pants="#1D3557", arms=("point", "hold"), mouth="open", accessory="moustache")
    s.person(470, "boy", 230, -1, skin=SKINS[0], cloth="#F77F00", pants="#FFFFFF", arms=("down", "wave"), mouth="open")
    s.add('<circle cx="560" cy="490" r="18" fill="#FFFFFF"/><path d="M552 482 l8 6 l8 -6 l-2 10 h-12 Z" fill="#2B2B2B"/>')
    s.frame(); return s


def sc_boda():
    s = S("skyWarm"); s.sky_bg(); s.sun(480, 120, 50); s.hills("#B5C96A", 400)
    s.ground("#D08C4A")
    s.add('<path d="M120 200 h720 l-40 -60 h-640 Z" fill="#FFFFFF"/><path d="M120 200 q90 30 180 0 q90 30 180 0 q90 30 180 0 q90 30 180 0" fill="#F4A261"/>'
          '<rect x="140" y="200" width="10" height="300" fill="#8A5530"/><rect x="810" y="200" width="10" height="300" fill="#8A5530"/>')
    s.person(390, "man", 265, 1, skin=SKINS[2], cloth="url(#kente)", pants="#2F3E46", arms=("hold", "wave"), mouth="smile")
    s.person(560, "woman", 255, -1, skin=SKINS[3], cloth="url(#kente)", arms=("wave", "hold"), mouth="smile")
    s.person(190, "elder", 250, 1, skin=SKINS[4], cloth="url(#bogolan)", arms=("cane", "point"), mouth="open")
    s.person(760, "woman", 240, -1, skin=SKINS[1], cloth="url(#waxD)", arms=("basket", "wave"))
    for x, y, c in ((300, 120, "#E63946"), (480, 100, "#FFD23F"), (660, 120, "#2A9D8F")):
        s.add(f'<circle cx="{x}" cy="{y}" r="10" fill="{c}"/><path d="M{x} {y + 10} v26" stroke="{c}" stroke-width="2"/>')
    s.frame(); return s


def sc_radio():
    s = S(); s.wall_in("#2B2D42")
    s.add('<rect x="0" y="0" width="960" height="600" fill="url(#bogolan)" opacity=".12"/>')
    sign(s, 340, 60, 280, "EN EL AIRE", bg="#E63946", fg="#FFFFFF", border="#FFFFFF", size=24)
    s.add('<rect x="80" y="120" width="190" height="130" rx="8" fill="#8ECAE6" opacity=".7"/><text x="175" y="196" font-family="DejaVu Sans" font-weight="bold" font-size="18" text-anchor="middle" fill="#1D3557">RADIO</text>'
          '<text x="175" y="220" font-family="DejaVu Sans" font-weight="bold" font-size="18" text-anchor="middle" fill="#1D3557">ARC-EN-CIEL</text>')
    s.floor_in(480)
    s.add('<rect x="250" y="370" width="460" height="24" fill="#3D405B"/><rect x="270" y="394" width="16" height="110" fill="#22223B"/><rect x="674" y="394" width="16" height="110" fill="#22223B"/>'
          '<rect x="400" y="340" width="160" height="30" rx="4" fill="#4A4E69"/>')
    for k in range(8):
        s.add(f'<rect x="{410 + k * 18}" y="346" width="8" height="18" fill="{["#80B918", "#FFD23F", "#E63946"][k % 3]}"/>')
    for x in (330, 630):
        s.add(f'<path d="M{x} 370 v-60" stroke="#999" stroke-width="5"/><rect x="{x - 12}" y="282" width="24" height="40" rx="12" fill="#2B2B2B"/>')
    s.chair(200, 1); s.chair(760, -1)
    s.person(220, "man", 235, 1, skin=SKINS[0], cloth="url(#waxC)", pants="#3D405B", arms=("hold", "point"), seated=True, mouth="open")
    s.person(740, "woman", 235, -1, skin=SKINS[3], cloth="url(#kente)", arms=("hold", "down"), seated=True, mouth="open")
    s.frame(); return s


def sc_banco():
    s = S(); s.wall_in("#EAF4F4")
    sign(s, 320, 56, 320, "BANCO DEL SOL", bg="#1D4E89", fg="#FFFFFF", border="#FFD166", size=20)
    s.add('<rect x="60" y="120" width="150" height="190" rx="8" fill="#3D405B"/><rect x="78" y="140" width="114" height="70" fill="#8ECAE6"/>'
          '<rect x="90" y="230" width="90" height="12" fill="#222"/><rect x="100" y="260" width="70" height="30" fill="#80B918"/>'
          '<text x="135" y="181" font-family="DejaVu Sans" font-weight="bold" font-size="18" text-anchor="middle" fill="#1D3557">CAJERO</text>')
    s.add('<rect x="700" y="120" width="200" height="140" fill="#FFFFFF" stroke="#1D4E89" stroke-width="6"/><path d="M720 240 l40 -50 l30 20 l40 -60 l40 30" stroke="#2A9D8F" stroke-width="7" fill="none"/>')
    s.floor_in(480)
    s.add('<rect x="300" y="380" width="360" height="22" fill="#5C3A1E"/><rect x="316" y="402" width="16" height="104" fill="#3E2614"/><rect x="628" y="402" width="16" height="104" fill="#3E2614"/>'
          '<rect x="430" y="352" width="70" height="28" fill="#FFFFFF" stroke="#999" stroke-width="2"/><circle cx="560" cy="368" r="14" fill="#D4AF37"/><circle cx="580" cy="370" r="12" fill="#D4AF37"/>')
    s.chair(240, 1); s.chair(720, -1)
    s.person(260, "woman", 235, 1, skin=SKINS[3], cloth="url(#waxA)", arms=("hold", "point"), seated=True, mouth="open")
    s.person(700, "man", 240, -1, skin=SKINS[2], cloth="#FFFFFF", pants="#2F3E46", arms=("hold", "chin"), seated=True)
    s.frame(); return s


def sc_biblioteca():
    s = S(); s.wall_in("#F3E9DC")
    sign(s, 360, 50, 240, "ORIENTACIÓN", bg="#FFFFFF", fg="#7A4A26", border="#7A4A26")
    import random
    rnd = random.Random(5)
    cols = ["#E63946", "#2A9D8F", "#F4A261", "#457B9D", "#80B918", "#8E2C48", "#F2C14E"]
    for sx in (40, 700):
        for r in range(4):
            y = 110 + r * 80
            s.add(f'<rect x="{sx}" y="{y + 66}" width="220" height="10" fill="#8A5530"/>')
            xx = sx + 6
            while xx < sx + 200:
                bw = rnd.choice((12, 16, 20)); bh = rnd.choice((50, 58, 64))
                s.add(f'<rect x="{xx}" y="{y + 66 - bh}" width="{bw}" height="{bh}" fill="{rnd.choice(cols)}"/>')
                xx += bw + 3
    s.floor_in(480)
    s.add('<rect x="300" y="380" width="360" height="22" fill="#A0673A"/><rect x="316" y="402" width="16" height="104" fill="#7A4A26"/><rect x="628" y="402" width="16" height="104" fill="#7A4A26"/>'
          '<path d="M420 378 l60 -14 l60 14 Z" fill="#FFFFFF" stroke="#999" stroke-width="2"/><path d="M480 364 v14" stroke="#999" stroke-width="2"/>'
          '<rect x="560" y="356" width="40" height="22" fill="#457B9D"/>')
    s.chair(250, 1); s.chair(710, -1)
    s.person(270, "woman", 240, 1, skin=SKINS[2], cloth="url(#waxB)", arms=("hold", "point"), seated=True, mouth="open")
    s.person(690, "girl", 215, -1, skin=SKINS[1], cloth="url(#waxC)", arms=("hold", "chin"), seated=True)
    s.frame(); return s


def sc_taller():
    s = S(); s.wall_in("#E8D5B5")
    s.add('<path d="M20 60 H940" stroke="#6B4220" stroke-width="6"/>')
    for i, x in enumerate((60, 200, 340, 620, 760)):
        col = ["#5B3A1E", "#7A4A26", "#3E2614", "#8B5A2B", "#4E2C1C"][i]
        s.add(f'<path d="M{x} 70 q50 -6 100 0 q6 70 -14 120 q-36 30 -72 0 q-20 -50 -14 -120 Z" fill="{col}"/>'
              f'<ellipse cx="{x + 32}" cy="110" rx="10" ry="6" fill="#F1E3C6"/><ellipse cx="{x + 68}" cy="110" rx="10" ry="6" fill="#F1E3C6"/>'
              f'<path d="M{x + 40} 150 h20" stroke="#F1E3C6" stroke-width="5"/><path d="M{x + 50} 76 v24" stroke="#E63946" stroke-width="4"/>')
    s.floor_in(480)
    s.add('<rect x="380" y="400" width="240" height="18" fill="#8A5530"/><rect x="396" y="418" width="14" height="86" fill="#6B4220"/><rect x="590" y="418" width="14" height="86" fill="#6B4220"/>'
          '<path d="M470 400 q30 -4 60 0 q4 -50 -10 -84 q-20 -18 -40 0 q-14 34 -10 84 Z" fill="#7A4A26"/><ellipse cx="490" cy="350" rx="7" ry="4" fill="#F1E3C6"/><ellipse cx="512" cy="350" rx="7" ry="4" fill="#F1E3C6"/>'
          '<path d="M560 392 l30 -24 l8 8 l-30 24 Z" fill="#999"/><path d="M420 380 q20 6 40 0" stroke="#C9A27A" stroke-width="4" fill="none"/>')
    s.stool(240)
    s.person(260, "elder", 240, 1, skin=SKINS[4], cloth="url(#bogolan)", arms=("hold", "point"), seated=True, mouth="open")
    s.person(760, "woman", 255, -1, skin=SKINS[1], cloth="#1D3557", arms=("hold", "down"), mouth="open")
    s.add('<rect x="680" y="320" width="40" height="54" rx="3" fill="#FFFFFF" stroke="#457B9D" stroke-width="3"/>')
    s.frame(); return s


def sc_concierto():
    s = S("skyNight"); s.sky_bg(); s.stars(40); s.moon(860, 80)
    s.ground("#3D2B1F", grass=False)
    s.add('<rect x="160" y="300" width="640" height="40" fill="#5C4033"/><rect x="160" y="340" width="640" height="160" fill="#3E2614"/>'
          '<rect x="150" y="90" width="20" height="250" fill="#555"/><rect x="790" y="90" width="20" height="250" fill="#555"/><rect x="150" y="80" width="660" height="20" fill="#555"/>')
    for x, c in ((260, "#FFD23F"), (480, "#E63946"), (700, "#2A9D8F")):
        s.add(f'<path d="M{x} 100 L{x - 90} 300 H{x + 90} Z" fill="{c}" opacity=".22"/><circle cx="{x}" cy="104" r="12" fill="{c}"/>')
    s.add('<path d="M190 300 l-14 -70 h60 l-14 70 Z" fill="#8B5A2B"/><ellipse cx="206" cy="230" rx="30" ry="8" fill="#F1E3C6"/>')
    s.add('<g transform="translate(0 -196)">')
    s.person(320, "man", 175, 1, skin=SKINS[0], cloth="url(#waxC)", pants="#3D405B", arms=("hold", "wave"), mouth="open")
    s.person(480, "man", 185, -1, skin=SKINS[2], cloth="url(#kente)", pants="#2F3E46", arms=("phone", "wave"), mouth="open")
    s.person(640, "woman", 175, -1, skin=SKINS[3], cloth="url(#waxD)", arms=("wave", "wave"), mouth="open")
    s.add('</g>')
    for i, x in enumerate(range(60, 960, 70)):
        sk = SKINS[i % len(SKINS)]
        s.add(f'<circle cx="{x}" cy="540" r="26" fill="#1B1B1B"/><path d="M{x - 34} 600 q34 -60 68 0 Z" fill="#1B1B1B"/>')
        if i % 3 == 0:
            s.add(f'<path d="M{x + 18} 530 l18 -60" stroke="#1B1B1B" stroke-width="10" stroke-linecap="round"/>')
    s.frame(); return s


NEW = {
    "hotel": sc_hotel, "farmacia": sc_farmacia, "entrevista": sc_entrevista, "reciclaje": sc_reciclaje,
    "casa": sc_casa, "comida": sc_comida, "numeros": sc_numeros, "horario": sc_horario,
    "cocina": sc_cocina, "futbol": sc_futbol, "boda": sc_boda, "radio": sc_radio, "banco": sc_banco,
    "biblioteca": sc_biblioteca, "taller": sc_taller, "concierto": sc_concierto,
}
fs.SCENES.update(NEW)

# --------------------------------------------------------------------------- couvertures

COVERS = [
    # (fichier, scène, ligne du haut, titre)
    ("model2_lesson_17", "gare", "B1 · LEÇON 17", "Voyager : transports et hébergement"),
    ("model2_lesson_18", "farmacia", "B1 · LEÇON 18", "La santé : chez le médecin et à la pharmacie"),
    ("model2_lesson_19", "entrevista", "B2 · LEÇON 19", "Le travail : métiers, CV et entretien"),
    ("model2_lesson_20", "reciclaje", "C1 · LEÇON 20", "L'environnement et la ville durable"),
    ("model2_lesson_21", "cocina", "A2 · LEÇON 21", "La cuisine : recettes et ingrédients"),
    ("model2_lesson_22", "futbol", "B1 · LEÇON 22", "Les loisirs et le sport"),
    ("model2_lesson_23", "telefono", "B1 · LEÇON 23", "Téléphone, messages et réseaux sociaux"),
    ("model2_lesson_24", "boda", "B2 · LEÇON 24", "Fêtes et traditions"),
    ("model2_lesson_25", "radio", "B2 · LEÇON 25", "Les médias et l'information"),
    ("model2_lesson_26", "banco", "C1 · LEÇON 26", "L'argent, la banque et le commerce"),
    ("model2_lesson_27", "biblioteca", "C1 · LEÇON 27", "Études et avenir"),
    ("model2_lesson_28", "concierto", "C2 · LEÇON 28", "Arts et culture"),
    ("model3_unit_02", "familia", "UNIDAD 2", "Mi familia · Ma famille"),
    ("model3_unit_03", "selva", "UNIDAD 3", "Escucha a tus padres"),
    ("model3_unit_04", "numeros", "UNIDAD 4", "Los números · Les nombres"),
    ("model3_unit_05", "mercado", "UNIDAD 5", "En el mercado · Au marché"),
    ("model3_unit_06", "horario", "UNIDAD 6", "En el colegio · Au collège"),
    ("model3_unit_07", "casa", "UNIDAD 7", "Mi casa y mi pueblo"),
    ("model3_unit_08", "fete", "UNIDAD 8", "La comida y la fiesta"),
]


def esc(t):
    return t.replace("&", "&amp;").replace("<", "&lt;")


def cover_svg(scene, kicker, title):
    base = fs.SCENES[scene]().svg()
    band = (f'<rect x="0" y="{H - 120}" width="{W}" height="120" fill="#1B1B1B" opacity=".78"/>'
            f'<rect x="0" y="{H - 124}" width="{W}" height="6" fill="url(#kente)"/>'
            f'<text x="40" y="{H - 78}" font-family="DejaVu Sans" font-weight="bold" font-size="22" letter-spacing="3" fill="#FFD166">{esc(kicker)}</text>'
            f'<text x="40" y="{H - 34}" font-family="DejaVu Sans" font-weight="bold" font-size="{38 if len(title) < 40 else 32}" fill="#FFFFFF">{esc(title)}</text>')
    return base.replace("</svg>", band + "</svg>")


def png_of(svg):
    return subprocess.run(["rsvg-convert", "-w", "1200", "-h", "750", "-f", "png"], input=svg.encode(), capture_output=True, check=True).stdout


if __name__ == "__main__":
    root = Path(__file__).resolve().parent.parent / "app" / "src" / "main" / "assets"
    prev = Path(sys.argv[1]) if len(sys.argv) > 1 else None
    if prev:
        prev.mkdir(parents=True, exist_ok=True)
    for name in NEW:
        p = fs.render(name, root / "scenes", prev)
        print("scène", name, p.stat().st_size // 1024, "Ko")
    for fname, scene, kicker, title in COVERS:
        im = Image.open(io.BytesIO(png_of(cover_svg(scene, kicker, title)))).convert("RGB")
        out = root / "manual_images" / f"{fname}.webp"
        im.save(out, "WEBP", quality=82, method=6)
        if prev:
            im.save(prev / f"{fname}.png")
        print("couverture", fname, out.stat().st_size // 1024, "Ko")
