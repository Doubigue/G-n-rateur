"""Conjugueur espagnol pour le MODEL 4 : tous les temps, verbes réguliers et irréguliers.

conjugate(inf, **traits) renvoie un dict {temps: [6 formes]} + gérondif et participe.
Personnes : yo, tú, él/ella/usted, nosotros, vosotros, ellos/ellas/ustedes.
L'impératif a « — » pour yo ; l'impératif négatif est rangé à part.
"""

ACC = {"a": "á", "e": "é", "i": "í", "o": "ó", "u": "ú"}
VOWELS = "aeiouáéíóú"

END = {
    "presente": {"ar": ["o", "as", "a", "amos", "áis", "an"], "er": ["o", "es", "e", "emos", "éis", "en"], "ir": ["o", "es", "e", "imos", "ís", "en"]},
    "imperfecto": {"ar": ["aba", "abas", "aba", "ábamos", "abais", "aban"], "er": ["ía", "ías", "ía", "íamos", "íais", "ían"], "ir": ["ía", "ías", "ía", "íamos", "íais", "ían"]},
    "indefinido": {"ar": ["é", "aste", "ó", "amos", "asteis", "aron"], "er": ["í", "iste", "ió", "imos", "isteis", "ieron"], "ir": ["í", "iste", "ió", "imos", "isteis", "ieron"]},
    "subj_presente": {"ar": ["e", "es", "e", "emos", "éis", "en"], "er": ["a", "as", "a", "amos", "áis", "an"], "ir": ["a", "as", "a", "amos", "áis", "an"]},
}
FUT = ["é", "ás", "á", "emos", "éis", "án"]
COND = ["ía", "ías", "ía", "íamos", "íais", "ían"]
STRONG = ["e", "iste", "o", "imos", "isteis", "ieron"]  # passés simples irréguliers (tuve, hice…)
HABER = {
    "preterito_perfecto": ["he", "has", "ha", "hemos", "habéis", "han"],
    "pluscuamperfecto": ["había", "habías", "había", "habíamos", "habíais", "habían"],
    "futuro_perfecto": ["habré", "habrás", "habrá", "habremos", "habréis", "habrán"],
    "condicional_perfecto": ["habría", "habrías", "habría", "habríamos", "habríais", "habrían"],
    "subj_perfecto": ["haya", "hayas", "haya", "hayamos", "hayáis", "hayan"],
    "subj_pluscuam": ["hubiera", "hubieras", "hubiera", "hubiéramos", "hubierais", "hubieran"],
}
BOOT = (0, 1, 2, 5)  # personnes accentuées sur le radical


def _last_vowel(stem):
    """Index de la voyelle du radical qui porte l'accent (on ignore le u muet de gu/qu)."""
    for i in range(len(stem) - 1, -1, -1):
        if stem[i] in "aeiou":
            if stem[i] == "u" and i > 0 and stem[i - 1] in "gq" and i + 1 < len(stem) + 1:
                continue
            return i
    return -1


def _change(stem, kind):
    i = _last_vowel(stem)
    v = stem[i]
    rep = {"ie": {"e": "ie", "i": "ie"}, "ue": {"o": "ue", "u": "ue"}, "i": {"e": "i"}, "e>i": {"e": "i"}, "o>u": {"o": "u"}}[kind]
    if v not in rep:
        return stem
    return stem[:i] + rep[v] + stem[i + 1:]


def _ortho(stem, next_letter):
    """Changements orthographiques devant e (car, gar, zar) ou devant a / o (guir, cer / cir, ger / gir)."""
    if next_letter in "eé":
        if stem.endswith("c"):
            return stem[:-1] + "qu"
        if stem.endswith("g"):
            return stem + "u"
        if stem.endswith("z"):
            return stem[:-1] + "c"
    if next_letter in "aoáó":
        if stem.endswith("gu"):
            return stem[:-1]
    return stem


def regular(inf):
    """Conjugaison purement régulière (pour repérer les formes irrégulières)."""
    return conjugate(inf, _plain=True)


def conjugate(inf, stem_change=None, zc=False, yo=None, pres=None, pret=None, pret_stem=None, fut_stem=None,
              participle=None, gerund=None, imp_tu=None, imp_vos=None, subj=None, subj_stem=None, impf=None,
              vowel_stem=False, no_imp=False, imp_nos=None, _plain=False):
    g = inf[-2:]
    stem = inf[:-2]
    ir = g == "ir" or inf.endswith("ír")
    if inf.endswith("ír"):
        g, stem = "ir", inf[:-2]
    t = {}

    def ortho(s, end):
        return s if _plain else _ortho(s, end[0])

    # ------------------------------------------------------------- présent
    if pres:
        t["presente"] = list(pres)
    else:
        forms = []
        for p, e in enumerate(END["presente"][g]):
            s = stem
            if stem_change and p in BOOT and not _plain:
                s = _change(stem, "ie" if stem_change == "ie" else "ue" if stem_change == "ue" else "i")
            if p == 0 and not _plain:
                if zc:
                    s = s[:-1] + "zc"
                elif s.endswith("gu") and g == "ir":
                    s = s[:-1]
                elif s.endswith("g") and g in ("er", "ir") and not s.endswith("gu"):
                    s = s[:-1] + "j"
            forms.append(s + e)
        if yo and not _plain:
            forms[0] = yo
        t["presente"] = forms

    # ------------------------------------------------------------- imparfait
    if impf and not _plain:
        t["imperfecto"] = list(impf)
    else:
        t["imperfecto"] = [stem + e for e in END["imperfecto"][g]]

    # ------------------------------------------------------------- passé simple
    if pret and not _plain:
        t["indefinido"] = list(pret)
    elif pret_stem and not _plain:
        ends = list(STRONG)
        if pret_stem.endswith("j"):
            ends[5] = "eron"
        t["indefinido"] = [pret_stem + e for e in ends]
    else:
        forms = []
        for p, e in enumerate(END["indefinido"][g]):
            s = stem
            if p == 0 and g == "ar":
                s = ortho(s, e)
            if not _plain and g == "ir" and stem_change in ("ie", "ue", "i") and p in (2, 5):
                s = _change(stem, "e>i" if stem_change in ("ie", "i") else "o>u")
            if not _plain and vowel_stem and g != "ar":
                e = {0: "í", 1: "íste", 2: "yó", 3: "ímos", 4: "ísteis", 5: "yeron"}[p]
            forms.append(s + e)
        t["indefinido"] = forms

    # ------------------------------------------------------------- futur / conditionnel
    fs = (fut_stem if fut_stem and not _plain else inf.replace("ír", "ir"))
    t["futuro"] = [fs + e for e in FUT]
    t["condicional"] = [fs + e for e in COND]

    # ------------------------------------------------------------- subjonctif présent
    if subj and not _plain:
        t["subj_presente"] = list(subj)
    else:
        if _plain:
            base = stem
        else:
            base = subj_stem or (t["presente"][0][:-1] if t["presente"][0].endswith("o") else stem)
        forms = []
        for p, e in enumerate(END["subj_presente"][g]):
            s = base
            if not _plain and p in (3, 4) and stem_change and not subj_stem and not yo and not zc:
                # nosotros / vosotros : pas de diphtongue (mais e → i, o → u pour les verbes en -ir)
                s = stem
                if g == "ir":
                    s = _change(stem, "e>i" if stem_change in ("ie", "i") else "o>u")
            if not _plain:
                s = _ortho(s, e[0])
            forms.append(s + e)
        t["subj_presente"] = forms

    # ------------------------------------------------------------- subjonctif imparfait
    third = t["indefinido"][5]
    sb = third[:-3]
    t["subj_imperfecto"] = [sb + e for e in ("ra", "ras", "ra")] + [sb[:-1] + ACC[sb[-1]] + "ramos"] + [sb + e for e in ("rais", "ran")]

    # ------------------------------------------------------------- formes nominales
    if participle and not _plain:
        part = participle
    else:
        part = stem + ("ado" if g == "ar" else "ido")
        if not _plain and stem and stem[-1] in "aeo" and g != "ar":
            part = stem + "ído"
    if gerund and not _plain:
        ger = gerund
    else:
        s = stem
        if not _plain and g == "ir" and stem_change in ("ie", "ue", "i"):
            s = _change(stem, "e>i" if stem_change in ("ie", "i") else "o>u")
        ger = s + ("ando" if g == "ar" else "iendo")
        if not _plain and vowel_stem and g != "ar":
            ger = stem + "yendo"

    # ------------------------------------------------------------- temps composés
    for k, aux in HABER.items():
        t[k] = [a + " " + part for a in aux]

    # ------------------------------------------------------------- impératif
    sp = t["subj_presente"]
    tu = imp_tu if (imp_tu and not _plain) else t["presente"][2] if not pres else (imp_tu or t["presente"][2])
    if _plain:
        tu = stem + ("a" if g == "ar" else "e")
    vos = imp_vos if (imp_vos and not _plain) else inf.replace("ír", "ir")[:-1] + "d"
    if inf.endswith("ír") and not imp_vos:
        vos = inf[:-1] + "d"
    t["imperativo"] = ["—", tu, sp[2], sp[3], vos, sp[5]]
    t["imperativo_neg"] = ["—", "no " + sp[1], "no " + sp[2], "no " + sp[3], "no " + sp[4], "no " + sp[5]]
    if imp_nos and not _plain:
        t["imperativo"][3] = imp_nos
    if no_imp and not _plain:
        t["imperativo"] = ["—"] * 6
        t["imperativo_neg"] = ["—"] * 6
    return {"tenses": t, "participle": part, "gerund": ger}
