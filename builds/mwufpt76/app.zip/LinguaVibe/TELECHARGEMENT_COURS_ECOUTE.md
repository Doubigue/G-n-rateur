# Téléchargement des langues, cours augmentés, écoute en français

## 1. Téléchargement en arrière-plan (speech/LangDownloads.kt)
- Les modèles Vosk, la voix Supertonic 3, la voix chinoise et les packs d'audios passent par WorkManager
  (worker au premier plan, type « dataSync », notification de progression).
- Le téléchargement continue si l'on quitte l'appli ou si on la ferme. Il attend le retour du réseau et repart
  après un redémarrage du téléphone.
- Reprise : speech/ResumableDownload.kt garde le fichier « .part » et redemande la suite au serveur (en-tête Range).
  Une coupure ne fait donc jamais repartir de zéro. Pour les packs d'audios, les phrases déjà enregistrées sont sautées.

## 2. Données conservées après désinstallation (speech/LangStorage.kt)
- Quand l'utilisateur accepte l'accès au stockage, tout va dans le dossier public `/LinguaVibe` du téléphone,
  dans les sous-dossiers vosk, tts-models, google-voice, tts, voice-packs et downloads.
  L'accès est « Gérer tous les fichiers » sur Android 11 et plus, ou WRITE_EXTERNAL_STORAGE sur Android 10 et moins.
- Android n'efface pas ce dossier à la désinstallation. Après une réinstallation, il suffit de redonner l'accès
  (carte « Conserver mes langues ») pour retrouver toutes les langues sans rien retélécharger.
- Les données déjà présentes dans le dossier privé y sont déplacées automatiquement, avec la carte ou au démarrage.
- Sans l'accès au stockage, l'appli garde le dossier privé, comme avant.
- Un fichier `.nomedia` empêche les audios d'apparaître dans la musique du téléphone.
- La carte « Conserver mes langues » apparaît dans Modèles vocaux et dans Paramètres › Voix.
- Remarque : la permission MANAGE_EXTERNAL_STORAGE est limitée sur Google Play. Pour une publication sur le Play Store,
  il faudrait justifier cet usage auprès de Google, ou passer par un dossier choisi avec le sélecteur de fichiers (SAF).

## 3. Cours augmentés (tools/content_plus.py, appliqué par tools/quiz_practice.py)
- MODEL 3 : 4 nouvelles unités.
  - 5 En el mercado : querer, cuesta / cuestan, les quantités.
  - 6 En el colegio : hay, tener, les jours.
  - 7 Mi casa y mi pueblo : estar, les prépositions de lieu, hay ou está.
  - 8 La comida y la fiesta : gustar, también / tampoco, comer / beber.
  Chaque unité a 18 ou 19 mots, 3 points de grammaire, 2 dialogues illustrés, une lecture, 6 phrases,
  3 devoirs, un atelier et une cinquantaine de questions de quiz.
- MODEL 3, unités 1 à 4 : 6 mots et 1 point de grammaire de plus par unité.
  Les points ajoutés : SER et les pronoms, les possessifs, IR, le calcul.
- MODEL 2 : 4 nouvelles leçons, dans tools/content_m2_new.py. Il passe donc à 20 leçons.
  - 17 Voyager : transports et hébergement (B1)
  - 18 La santé : chez le médecin et à la pharmacie (B1)
  - 19 Le travail : métiers, CV et entretien d'embauche (B2)
  - 20 L'environnement et la ville durable (C1)
  Chaque leçon a une page de manuel au format du guide : règle, règles à mémoriser, exemples, vocabulaire,
  lecture guidée, quiz, corrigé, travail personnel et auto-évaluation. Elle a aussi 14 mots, 3 points de grammaire,
  2 dialogues illustrés, une lecture, 7 phrases utiles, 3 devoirs, un atelier et une cinquantaine de questions.
- MODEL 2 : 8 leçons de plus, dans tools/content_m2_more.py. Il passe donc à 28 leçons, de A1 à C2.
  Chacune a sa page de manuel, 2 dialogues illustrés, une couverture, un atelier et une cinquantaine de questions.
  - 21 La cuisine : recettes et ingrédients (A2) : l'impératif et le se des recettes.
  - 22 Les loisirs et le sport (B1) : jugar / tocar, soler, interesar, proposer une sortie.
  - 23 Téléphone, messages et réseaux sociaux (B1) : acabar de, volver a.
  - 24 Fêtes et traditions (B2) : les passés simples irréguliers.
  - 25 Les médias et l'information (B2) : le discours rapporté.
  - 26 L'argent, la banque et le commerce (C1) : les pronoms relatifs, négocier.
  - 27 Études et avenir (C1) : le subjonctif après cuando, para que.
  - 28 Arts et culture (C2) : l'hypothèse passée et les regrets.
  Nouvelles scènes : cocina, futbol, boda, radio, banco, biblioteca, taller, concierto.
- MODEL 2, leçons 1 à 16 : 5 mots, 1 point de grammaire et 3 phrases utiles de plus dans chacune.
- Pour régénérer : `python3 tools/enrich_m2_m3.py <JSON d'origine>` puis `python3 tools/quiz_practice.py`.

## 4. Écouter le cours en français (ui/CourseNarration.kt, ui/CourseListen.kt)
- Une carte en haut de l'onglet « Apprendre » de chaque leçon (MODEL 1, 2 et 3).
- Un narrateur français lit la leçon dans cet ordre : présentation, texte du manuel, vocabulaire, grammaire
  (explications et exemples), dialogues, lecture et phrases utiles.
- Deux modes :
  - « Français + espagnol » : les mots et phrases espagnols sont lus par la voix espagnole, puis traduits.
  - « Tout en français » : tout est lu par la voix française.
- On peut commencer à n'importe quelle partie et passer au passage précédent, le répéter ou passer au suivant.
  Le texte lu s'affiche.
- Le pack « Français » de Paramètres › Voix précharge toute la narration pour l'écouter hors ligne.

## 5. Illustrations (tools/flat_scenes_plus.py)
- 8 nouvelles scènes de dialogue en aplats, dans le style des autres scènes :
  hotel, farmacia, entrevista, reciclaje, casa, comida, numeros, horario.
- Couvertures dessinées pour les leçons qui n'avaient pas d'illustration :
  - MODEL 2 : leçons 17 à 20 (manual_images/model2_lesson_17…20.webp) ;
  - MODEL 3 : unités 2 à 8 (manual_images/model3_unit_02…08.webp).
- Les dialogues des nouvelles leçons utilisent ces scènes. La leçon 17 se passe maintenant à la réception de l'hôtel,
  et la leçon 18 a un 3e dialogue, à la pharmacie.
- Aperçu de toutes les nouvelles images : ILLUSTRATIONS_APERCU.png.
- Pour régénérer : `python3 tools/flat_scenes_plus.py [dossier_aperçus]`, puis `enrich_m2_m3.py` et `quiz_practice.py`.

## 6. Villes fictives (tools/fictional_places.py)
Dans les MODEL 2 et 3, les villes, communes et quartiers réels sont remplacés par des noms inventés.
C'est fait au moment de générer les cours (quiz_practice.py), sur tous les textes : manuel, dialogues,
vocabulaire, lectures, quiz, ateliers et devoirs. La prononciation figurée est recalculée.

| Réel | Fictif |
|---|---|
| Abidjan / Abiyán | Lagunabé |
| Yamoussoukro | Kanzikro |
| San Pedro | Port-Lumé |
| Bouaké | Sanbara |
| Korhogo | Siméla |
| Man | Tonkimé |
| Daloa | Gbaléa |
| Grand-Bassam | Bassilé-Plage |
| Bingerville | Mangoville |
| Katiola | Kanéla |
| Bouaflé | Koflé |
| Kong | Kandiara |
| Cocody | Lomana |
| Marcory | Tiéméla |
| Treichville | Kotiba |
| Yopougon | Wassakro |
| Adjamé | Kossiba |
| Plateau | Bel-Horizon |
| Madrid | Valdeluna |
| Radio Lagunes | Radio Arc-en-ciel |

Les noms de pays (Côte d'Ivoire, España…) sont gardés. Le bus de la scène « gare » affiche « PORT-LUMÉ ».
Les photos du manuel (manual_images/*.jpeg, model3_cover.png) n'ont pas été modifiées.
