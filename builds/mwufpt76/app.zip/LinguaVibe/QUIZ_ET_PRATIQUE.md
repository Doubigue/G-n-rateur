# Quiz élargis et ateliers « À pratiquer »

## Moteur de quiz (ui/QuizPlay.kt)
- 8 types de questions : Choix, Écrire, Écoute, Ordre (tuiles de mots), Trou, Paires, Oral (micro Vosk), Rédaction (mots clés + modèle).
- Chaque question peut porter une explication 💡 affichée après la réponse.
- Menu : Série rapide (10), Série de 20, Tout le quiz, Mes erreurs, filtre par type.
- Série : barre de progression, série 🔥, XP, bilan « À revoir », refaire ses erreurs.

## Contenu (tools/quiz_practice.py)
- MODEL 3 : 71 à 107 questions par leçon (avant : environ 19), dont des questions rédigées avec explication.
- MODEL 2 : 52 à 58 questions par leçon (avant : 7).
- MODEL 3, « À pratiquer » : 18 ateliers interactifs, soit 130 exercices corrigés directement dans le jeu.
  Les 8 exercices du manuel (Exercice oral 1, Exercice écrit 2, Exercice 3, Exercice 4, Activité 1 à 4) ont chacun leur atelier, placé juste sous la consigne.
- MODEL 2 : un atelier par leçon (ordre, trou, oral, rédaction).

Pour régénérer : `python3 tools/enrich_m2_m3.py <dossier des JSON d'origine>` puis `python3 tools/quiz_practice.py`.

## Format JSON
```json
{"type":"order","words":["Me","llamo","Fatou."],"translation":"…","explain":"…"}
{"type":"fill","sentence":"Tengo ___ años.","answers":["dieciocho"],"wrong":[],"translation":"J'ai 18 ans."}
{"type":"match","pairs":[["rojo","rouge"],["azul","bleu"]],"title":"Les couleurs"}
{"type":"speak","text":"Esta es mi familia.","translation":"Voici ma famille."}
{"type":"write","prompt":"…","model":"…","keywords":["me llamo","tengo"],"minWords":30}
"practice":[{"ref":"Exercice 4","title":"…","instruction":"…","items":[…]}]
```
Une phrase à trou sans `wrong` se joue au clavier. Un atelier avec un `ref` égal au titre d'un exercice du manuel s'affiche sous cet exercice ; un atelier sans `ref` va dans la section « À pratiquer ».
