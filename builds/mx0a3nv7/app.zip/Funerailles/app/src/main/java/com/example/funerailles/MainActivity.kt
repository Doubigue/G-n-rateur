package com.example.funerailles

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import java.text.NumberFormat
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var db: DatabaseHelper
    private fun money(v: Double) = NumberFormat.getIntegerInstance(Locale.FRANCE).format(v) + " FCFA"
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); db=DatabaseHelper(this); render() }
    override fun onResume() { super.onResume(); if(::db.isInitialized) render() }
    private fun render() {
        val root=Ui.page(this,"Funérailles")
        val welcome=Ui.text("Bienvenue dans votre espace de collecte",16,false); root.addView(welcome)
        val total=Ui.card(this,"TOTAL DES COTISATIONS",money(db.total)); root.addView(total)
        root.addView(Ui.card(this,"COTISANTS", "${db.count} enregistrement(s)"))
        root.addView(Ui.text("Services",21,true).apply { setPadding(0,24,0,4) })
        root.addView(Ui.button(this,"＋  Enregistrer une cotisation").apply { setOnClickListener { startActivity(Intent(this@MainActivity,CotisationActivity::class.java)) } })
        root.addView(Ui.button(this,"▦  Cotisants et historique").apply { setOnClickListener { startActivity(Intent(this@MainActivity,ContributorsActivity::class.java)) } })
        root.addView(Ui.button(this,"＋  Gérer groupes et quartiers").apply { setOnClickListener { startActivity(Intent(this@MainActivity,ManageActivity::class.java)) } })
        root.addView(Ui.button(this,"⇩  Rapports PDF").apply { setOnClickListener { startActivity(Intent(this@MainActivity,ReportsActivity::class.java)) } })
        root.addView(Ui.button(this,"⟳  Tester la synchronisation").apply { setOnClickListener { SyncManager.testConnection { ok,msg -> runOnUiThread { android.widget.Toast.makeText(this,msg,android.widget.Toast.LENGTH_LONG).show() } } } })
        val note=Ui.text("Vos données sont enregistrées sur ce téléphone. Configurez Firebase pour activer la synchronisation multi-téléphones.",12,false);note.setTextColor(Ui.MUTED);note.setPadding(4,22,4,0);root.addView(note)
        setContentView(root)
    }
}
