package com.example.funerailles;

import android.app.*;import android.graphics.Color;import android.graphics.Typeface;import android.graphics.drawable.GradientDrawable;import android.view.*;import android.widget.*;

public class Ui {
 public static final int BG=Color.rgb(8,8,8), CARD=Color.rgb(36,36,36), ORANGE=Color.rgb(255,133,0), WHITE=Color.WHITE, MUTED=Color.LTGRAY;
 public static GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);return d;}
 public static TextView text(String s,int size,boolean bold){TextView t=new TextView(context);t.setText(s);t.setTextSize(size);t.setTextColor(WHITE);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
 public static LinearLayout page(Activity a,String title){context=a;LinearLayout root=new LinearLayout(a);root.setOrientation(1);root.setPadding(22,24,22,20);root.setBackgroundColor(BG);TextView h=text(title,25,true);h.setPadding(0,4,0,22);root.addView(h);return root;}
 public static TextView button(Activity a,String label){TextView b=text(label,15,true);b.setGravity(Gravity.CENTER);b.setPadding(16,15,16,15);b.setBackground(shape(ORANGE,24));b.setTextColor(Color.BLACK);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=12;b.setLayoutParams(p);return b;}
 public static TextView field(Activity a,String hint){EditText e=new EditText(a);e.setSingleLine(true);e.setHint(hint);e.setHintTextColor(MUTED);e.setTextColor(WHITE);e.setPadding(16,12,16,12);e.setBackground(shape(CARD,18));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=9;e.setLayoutParams(p);return e;}
 public static TextView card(Activity a,String title,String subtitle){TextView t=text(title+"\n"+subtitle,16,true);t.setPadding(18,18,18,18);t.setBackground(shape(CARD,20));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=10;t.setLayoutParams(p);return t;}
 public static AppCompatDummy unused;
 static android.content.Context context;
 public static class AppCompatDummy {}
}
