package com.example.funerailles;
import android.app.*;import android.os.Bundle;import android.view.*;import android.widget.*;import java.util.*;
public class ContributorsActivity extends Activity {
 DatabaseHelper db;LinearLayout root,rows;Spinner category,place;
 @Override public void onCreate(Bundle b){super.onCreate(b);db=new DatabaseHelper(this);root=Ui.page(this,"Cotisants");category=new Spinner(this);category.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Tous","Groupe","Quartier"}));place=new Spinner(this);refreshPlaces();root.addView(category);root.addView(place);TextView go=Ui.button(this,"Appliquer les filtres");root.addView(go);rows=new LinearLayout(this);rows.setOrientation(1);root.addView(rows);go.setOnClickListener(v->load());load();setContentView(root);}
 void refreshPlaces(){List<String> a=new ArrayList<>();a.add("Tous");a.addAll(db.getItems("groupes"));a.addAll(db.getItems("quartiers"));place.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,a));}
 void load(){rows.removeAllViews();String c=category.getSelectedItem()==null?"Tous":category.getSelectedItem().toString();String l=place.getSelectedItem()==null?"Tous":place.getSelectedItem().toString();for(String[] r:db.getCotisations(c,l))rows.addView(Ui.card(this,r[0],r[1]+" FCFA • "+r[2]+" • "+r[3]+"\n"+r[4]));if(rows.getChildCount()==0)rows.addView(Ui.text("Aucune cotisation pour ce filtre.",14,false));}
}
