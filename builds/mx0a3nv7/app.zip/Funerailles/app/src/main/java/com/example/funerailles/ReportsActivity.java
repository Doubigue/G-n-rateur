package com.example.funerailles;

import android.app.*;
import android.os.Bundle;
import android.os.Environment;
import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.text.*;
import java.util.*;

public class ReportsActivity extends Activity {
    DatabaseHelper db;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        db = new DatabaseHelper(this);
        LinearLayout root = Ui.page(this, "Rapports PDF");
        root.addView(Ui.text("Générez un rapport officiel avec le nom et la signature manuscrite du responsable.", 15, false));
        TextView button = Ui.button(this, "Générer le rapport signé PDF");
        button.setOnClickListener(v -> showSignatureDialog());
        root.addView(button);
        setContentView(root);
    }

    void showSignatureDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setPadding(20, 12, 20, 8);
        box.setOrientation(LinearLayout.VERTICAL);
        EditText name = new EditText(this); name.setSingleLine(true); name.setHint("Nom et prénom du responsable");
        EditText role = new EditText(this); role.setSingleLine(true); role.setHint("Fonction (ex. Trésorier)");
        TextView instruction = Ui.text("Signez dans le cadre blanc ci-dessous :", 14, false);
        SignaturePadView pad = new SignaturePadView(this);
        LinearLayout.LayoutParams padParams = new LinearLayout.LayoutParams(-1, dp(150));
        padParams.topMargin = dp(8); padParams.bottomMargin = dp(8);
        TextView clear = Ui.button(this, "Effacer la signature");
        clear.setOnClickListener(v -> pad.clear());
        box.addView(name); box.addView(role); box.addView(instruction); box.addView(pad, padParams); box.addView(clear);
        ScrollView scroll = new ScrollView(this); scroll.addView(box);
        new AlertDialog.Builder(this).setTitle("Signature du responsable").setView(scroll)
            .setNegativeButton("Annuler", null)
            .setPositiveButton("Créer le PDF", (d, w) -> {
                String signer = name.getText().toString().trim();
                String function = role.getText().toString().trim();
                if (signer.isEmpty() || !pad.hasSignature()) {
                    Toast.makeText(this, "Indiquez le nom et ajoutez une signature.", Toast.LENGTH_LONG).show();
                    return;
                }
                export(signer, function, pad.getSignatureBitmap());
            }).show();
    }

    int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    void export(String signer, String function, Bitmap signature) {
        PdfDocument pdf = new PdfDocument();
        PdfDocument.PageInfo info = new PdfDocument.PageInfo.Builder(595, 842, 1).create();
        PdfDocument.Page page = pdf.startPage(info);
        Canvas c = page.getCanvas(); Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        c.drawColor(Color.WHITE);
        p.setColor(Color.rgb(255, 133, 0)); c.drawRect(0, 0, 595, 105, p);
        p.setColor(Color.BLACK); p.setTextSize(27); p.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        c.drawText("RAPPORT DES COTISATIONS", 35, 58, p);
        p.setTextSize(12); p.setTypeface(Typeface.DEFAULT);
        c.drawText("Collecte funéraire • FCFA • " + new SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE).format(new Date()), 35, 85, p);
        p.setColor(Color.BLACK); p.setTextSize(13); p.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        c.drawText("Nom et prénom", 35, 145, p); c.drawText("Montant", 330, 145, p); c.drawText("Catégorie / lieu", 420, 145, p);
        p.setTypeface(Typeface.DEFAULT); p.setTextSize(10);
        int y = 175; int count = 0;
        for (String[] r : db.getCotisations("Tous", "Tous")) {
            if (y > 625) break;
            c.drawText(r[0], 35, y, p); c.drawText(r[1] + " F", 330, y, p);
            c.drawText(r[2] + " / " + r[3], 420, y, p);
            y += 21; count++;
        }
        p.setColor(Color.rgb(255, 133, 0)); c.drawRect(35, 650, 560, 652, p);
        p.setColor(Color.BLACK); p.setTypeface(Typeface.create("sans-serif", Typeface.BOLD)); p.setTextSize(16);
        c.drawText("TOTAL : " + NumberFormat.getIntegerInstance(Locale.FRANCE).format(db.getTotal()) + " FCFA", 35, 680, p);
        p.setTypeface(Typeface.DEFAULT); p.setTextSize(10);
        c.drawText("Responsable : " + signer, 35, 720, p);
        if (!function.isEmpty()) c.drawText("Fonction : " + function, 35, 738, p);
        c.drawText("Signature :", 35, 760, p);
        if (signature != null) {
            Paint imagePaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
            Rect src = new Rect(0, 0, signature.getWidth(), signature.getHeight());
            Rect dst = new Rect(35, 765, 250, 825);
            c.drawBitmap(signature, src, dst, imagePaint);
        }
        p.setColor(Color.GRAY); p.setTextSize(8); p.setTypeface(Typeface.DEFAULT);
        c.drawText("Document généré par Funérailles • " + count + " ligne(s) affichée(s)", 330, 825, p);
        pdf.finishPage(page);
        try {
            File dir = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
            if (dir != null && !dir.exists()) dir.mkdirs();
            File f = new File(dir, "Rapport_Funerailles_Signe_" + System.currentTimeMillis() + ".pdf");
            FileOutputStream out = new FileOutputStream(f); pdf.writeTo(out); out.close();
            Toast.makeText(this, "PDF signé créé : " + f.getAbsolutePath(), Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Erreur PDF : " + e.getMessage(), Toast.LENGTH_LONG).show();
        } finally { pdf.close(); if (signature != null) signature.recycle(); }
    }
}
