package com.example.mydm.ui

import android.content.Intent
import android.net.Uri
import java.util.Date
import java.text.DateFormat
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.RoundedCornerShape
import android.view.ViewGroup
import androidx.compose.runtime.snapshots.SnapshotStateList
import android.util.Size
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.mydm.App
import com.example.mydm.browser.SnifferWebView
import com.example.mydm.core.*
import com.example.mydm.downloader.DownloadService
import com.example.mydm.torrent.TorrentFile
import com.example.mydm.torrent.TorrentService
import com.example.mydm.whatsapp.ScanResult
import com.example.mydm.whatsapp.StatusItem
import com.example.mydm.whatsapp.WaApp
import com.frostwire.jlibtorrent.TorrentInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable internal fun appInstance() = LocalContext.current.applicationContext as App

// ───────────── Statuts WhatsApp ─────────────
@Composable
fun StatusScreen() {
    val ctx = LocalContext.current; val repo = appInstance().statusRepo
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf(WaApp.WHATSAPP) }
    var scan by remember { mutableStateOf<ScanResult?>(null) }
    var granted by remember { mutableStateOf(repo.hasGrant(tab)) }
    var loading by remember { mutableStateOf(false) }
    var reload by remember { mutableIntStateOf(0) }

    LaunchedEffect(tab, reload) {
        granted = repo.hasGrant(tab)
        scan = null
        if (granted) {
            loading = true
            scan = runCatching { repo.scan(tab) }.getOrElse { ScanResult(emptyList(), "Erreur : ${it.message}") }
            loading = false
        }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) { repo.persistGrant(tab, uri); reload++ }
    }

    Column(Modifier.fillMaxSize()) {
        TabRow(WaApp.entries.indexOf(tab), containerColor = Bg) {
            WaApp.entries.forEach { a -> Tab(tab == a, { tab = a }, text = { Text(a.label) }) }
        }
        val s = scan ?: ScanResult(emptyList(), "")
        when {
            !granted -> Centered("Autorisez l'accès au dossier Android/media/${tab.pkg}\n(appuyez sur « Utiliser ce dossier »)") {
                Button({ picker.launch(repo.initialUri(tab)) }) { Text("Autoriser l'accès") }
            }
            loading || scan == null -> Centered("Recherche des statuts…")
            s.items.isEmpty() -> Centered(s.message) {
                Row {
                    Button({ reload++ }) { Text("Actualiser") }
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton({ picker.launch(repo.initialUri(tab)) }) { Text("Changer de dossier") }
                }
            }
            else -> LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    Row {
                        TextButton({ reload++ }) { Text("Actualiser (${s.items.size})") }
                        TextButton({ picker.launch(repo.initialUri(tab)) }) { Text("Changer de dossier") }
                    }
                }
                if (s.info.isNotBlank()) item { Text(s.info, color = Muted, fontSize = 11.sp) }
                items(s.items, key = { it.uri.toString() }) { st ->
                    val thumb by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, st.uri) {
                        value = withContext(Dispatchers.IO) {
                            runCatching { ctx.contentResolver.loadThumbnail(st.uri, Size(256, 256), null).asImageBitmap() }.getOrNull()
                        }
                    }
                    Row(Modifier.fillMaxWidth().glass().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(72.dp).background(Color(0x22FFFFFF))) {
                            thumb?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
                        }
                        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                            Text(if (st.isVideo) "Vidéo" else "Photo", color = Accent)
                            Text("${st.size / 1024} Ko • ${fmtDate(st.modified)}", color = Muted, fontSize = 12.sp)
                        }
                        Button({
                            scope.launch {
                                runCatching { repo.save(st) }
                                    .onSuccess { Toast.makeText(ctx, "Enregistré dans ${Prefs.rootFolder}/Vidéo made/Statuts", Toast.LENGTH_SHORT).show() }
                                    .onFailure { Toast.makeText(ctx, "Échec : ${it.message}", Toast.LENGTH_LONG).show() }
                            }
                        }) { Text("Enregistrer") }
                    }
                }
            }
        }
    }
}

// ───────────── Torrent ─────────────
private fun torrentStateLabel(s: com.example.mydm.torrent.TorrentState): String = when (s.state) {
    "ERREUR" -> "Erreur"
    "PAUSED" -> "En pause"
    "NET_PAUSED" -> "⏸ Pas de connexion — reprise automatique"
    "DOWNLOADING_METADATA" -> if (s.message.isNotBlank()) s.message else "Recherche des pairs…"
    "DOWNLOADING" -> "Téléchargement"
    "FINISHED" -> if (s.progress >= 1f) "Terminé" else "Fichiers choisis terminés"
    "SEEDING" -> "Terminé"
    "CHECKING_FILES", "CHECKING_RESUME_DATA" -> "Vérification des fichiers…"
    "ALLOCATING" -> "Préparation…"
    else -> s.state
}

@Composable
fun TorrentScreen() {
    val ctx = LocalContext.current; val app = appInstance(); val engine = app.torrentEngine
    val states by engine.states.collectAsStateWithLifecycle()
    val clipboard = androidx.compose.ui.platform.LocalClipboardManager.current
    var source by remember { mutableStateOf("") }
    var filesFor by remember { mutableStateOf<String?>(null) }
    var removeFor by remember { mutableStateOf<String?>(null) }

    // Recharge les torrents mémorisés (session démarrée hors du thread principal)
    LaunchedEffect(Unit) { withContext(Dispatchers.IO) { runCatching { engine.start() } } }

    fun add(src: String) = AutoDownload.launchTorrent(app, src) { Toast.makeText(ctx, it, Toast.LENGTH_LONG).show() }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let { add(it.toString()) } }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Column(Modifier.fillMaxWidth().glass().padding(14.dp)) {
                OutlinedTextField(source, { source = it }, Modifier.fillMaxWidth(), label = { Text("Lien magnet, lien .torrent ou hash") })
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button({
                        AutoDownload.torrentSource(source)?.let { add(it); source = "" }
                    }, enabled = AutoDownload.torrentSource(source) != null) { Text("Télécharger") }
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton({
                        val t = clipboard.getText()?.text.orEmpty()
                        val src = AutoDownload.torrentSource(t)
                        if (src != null) add(src) else Toast.makeText(ctx, "Aucun lien torrent dans le presse-papiers", Toast.LENGTH_SHORT).show()
                    }) { Text("Coller") }
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton({ picker.launch(arrayOf("*/*")) }) { Text(".torrent") }
                }
                Text("Le téléchargement démarre tout de suite. Touchez « Fichiers » pour décocher ce que vous ne voulez pas.", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
            }
        }
        if (states.isEmpty()) item { Text("Aucun torrent. Partagez un lien magnet ou un fichier .torrent vers MyDM, ou collez-le ci-dessus.", color = Muted, fontSize = 13.sp) }
        items(states.values.toList(), key = { it.infoHash }) { s ->
            val paused = s.paused || s.state == "ERREUR"
            Column(Modifier.fillMaxWidth().glass().padding(14.dp)) {
                Text(s.name, color = Txt, maxLines = 2, overflow = TextOverflow.Ellipsis)
                if (s.state == "DOWNLOADING_METADATA") LinearProgressIndicator(Modifier.fillMaxWidth().padding(vertical = 8.dp))
                else LinearProgressIndicator({ s.progress }, Modifier.fillMaxWidth().padding(vertical = 8.dp))
                val size = if (s.totalSize > 0) " • " + formatSize((s.totalSize * s.progress).toLong()) + " / " + formatSize(s.totalSize) else ""
                Text("${(s.progress * 100).toInt()}% • ${torrentStateLabel(s)}$size", color = Muted, fontSize = 12.sp)
                if (s.state == "DOWNLOADING" || s.state == "CHECKING_FILES")
                    Text("↓ ${s.downloadRate / 1024} Ko/s • ↑ ${s.uploadRate / 1024} Ko/s • ${s.peers} pairs (${s.seeds} sources)", color = Muted, fontSize = 12.sp)
                s.error?.let { Text(it, color = Danger, fontSize = 12.sp) }
                Row {
                    if (s.state != "FINISHED" || s.progress < 1f) {
                        if (paused) TextButton({ engine.resume(s.infoHash) }) { Text("Reprendre") }
                        else TextButton({ engine.pause(s.infoHash) }) { Text("Pause") }
                    }
                    if (s.files.size > 1) TextButton({ filesFor = s.infoHash }) { Text("Fichiers (${s.files.count { it.selected }}/${s.files.size})") }
                    TextButton({ removeFor = s.infoHash }) { Text("Retirer") }
                }
            }
        }
    }

    // Choix des fichiers (après le démarrage)
    filesFor?.let { id ->
        val st = states[id]
        if (st == null) filesFor = null else {
            var sel by remember(id) { mutableStateOf(st.files.filter { it.selected }.map { it.index }.toSet()) }
            AlertDialog(
                onDismissRequest = { filesFor = null },
                title = { Text("Fichiers à télécharger") },
                text = {
                    Column(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState())) {
                        st.files.forEach { f ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(f.index in sel, { c -> sel = if (c) sel + f.index else sel - f.index })
                                Text("${f.path.substringAfterLast('/')}  (${formatSize(f.size)})", fontSize = 12.sp, modifier = Modifier.weight(1f))
                            }
                        }
                    }
                },
                confirmButton = { TextButton({ if (sel.isNotEmpty()) engine.setSelection(id, sel); filesFor = null }) { Text("OK") } },
                dismissButton = { TextButton({ filesFor = null }) { Text("Annuler") } }
            )
        }
    }
    removeFor?.let { id ->
        AlertDialog(
            onDismissRequest = { removeFor = null },
            title = { Text("Retirer ce torrent ?") },
            text = { Text("Les données incomplètes seront supprimées. Un torrent terminé garde ses fichiers dans Téléchargements.") },
            confirmButton = { TextButton({ engine.remove(id); removeFor = null }) { Text("Retirer") } },
            dismissButton = { TextButton({ removeFor = null }) { Text("Annuler") } }
        )
    }
}

@Composable
internal fun Centered(text: String, extra: @Composable () -> Unit = {}) =
    Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Text(text, color = Muted); Spacer(Modifier.height(12.dp)); extra()
    }

private fun fmtDate(ms: Long): String =
    if (ms <= 0) "date inconnue" else DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(ms))
