package com.example.mydm.core

import android.content.Context
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.PowerManager

/**
 * Garde le processeur (et le Wi-Fi) réveillés tant qu'un téléchargement ou un torrent tourne, écran éteint.
 * Les services au premier plan (DownloadService, TorrentService) l'activent à leur création et le relâchent à leur arrêt.
 */
object KeepAlive {
    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null
    private val owners = HashSet<String>()

    /** Type de service au premier plan : « specialUse » n'a ni limite des 6 h (Android 15) ni blocage au démarrage du téléphone. */
    fun fgsType(): Int =
        if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        else ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC

    @Synchronized fun acquire(ctx: Context, owner: String) {
        owners.add(owner)
        val app = ctx.applicationContext
        if (wake == null) wake = runCatching {
            app.getSystemService(PowerManager::class.java)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MyDM:keepalive").apply { setReferenceCounted(false); acquire() }
        }.getOrNull()
        if (wifi == null) wifi = runCatching {
            @Suppress("DEPRECATION")
            app.getSystemService(WifiManager::class.java)
                .createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "MyDM:wifi").apply { setReferenceCounted(false); acquire() }
        }.getOrNull()
    }

    @Synchronized fun release(owner: String) {
        owners.remove(owner)
        if (owners.isNotEmpty()) return
        runCatching { wake?.takeIf { it.isHeld }?.release() }; wake = null
        runCatching { wifi?.takeIf { it.isHeld }?.release() }; wifi = null
    }
}
