package com.example.mydm.core

import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.webkit.URLUtil
import com.example.mydm.App
import com.example.mydm.downloader.DownloadService
import com.example.mydm.torrent.TorrentService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

/**
 * Lien partagé / collé / cliqué : on le télécharge tout de suite, sans écran d'analyse.
 *  • magnet, .torrent (fichier ou lien), hash        → moteur torrent
 *  • vidéo YouTube / Facebook / TikTok…              → meilleure qualité (yt-dlp)
 *  • fichier direct (apk, zip, mp4, pdf, iso…)       → téléchargement multi-segments
 *  • simple page web                                 → rien (l'appelant l'ouvre dans le navigateur)
 */
object AutoDownload {
    class Outcome(val started: Boolean, val message: String = "", val torrent: Boolean = false)

    const val UA = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val http = OkHttpClient.Builder().connectTimeout(8, TimeUnit.SECONDS).readTimeout(8, TimeUnit.SECONDS).followRedirects(true).build()
    private val main = Handler(Looper.getMainLooper())

    private val fileExt = setOf(
        "apk", "xapk", "apks", "zip", "rar", "7z", "tar", "gz", "tgz", "bz2", "xz", "iso", "img", "exe", "msi", "dmg", "deb", "rpm", "jar",
        "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "epub", "mobi", "csv",
        "mp4", "mkv", "webm", "avi", "mov", "m4v", "flv", "wmv", "ts", "3gp",
        "mp3", "m4a", "flac", "wav", "ogg", "opus", "aac"
    )

    private val magnetRe = Regex("magnet:\\?\\S+", RegexOption.IGNORE_CASE)
    private val urlRe = Regex("https?://\\S+", RegexOption.IGNORE_CASE)
    private val hashRe = Regex("^[0-9a-fA-F]{40}$")

    private fun pathOf(url: String) = (Uri.parse(url).path ?: "").lowercase()

    /**
     * Détecte une source torrent dans un texte sans se limiter à l'extension de l'URL.
     * Les liens générés par certains sites ressemblent à /download?id=123 et ne finissent
     * jamais par .torrent ; la confirmation Content-Type/Disposition se fait ensuite par probe.
     */
    fun torrentSource(text: String): String? {
        val t = text.trim()
        magnetRe.find(t)?.value?.let { return it }
        if (hashRe.matches(t)) return "magnet:?xt=urn:btih:$t"
        urlRe.find(t)?.value?.let { if (pathOf(it).endsWith(".torrent")) return it }
        return null
    }

    private fun looksLikeTorrentMime(mime: String?): Boolean {
        val m = mime?.substringBefore(';')?.trim()?.lowercase() ?: return false
        return m == "application/x-bittorrent" || m == "application/x-torrent" ||
            m == "application/bittorrent" || m == "application/octet-stream"
    }

    /** Vérifie rapidement si un lien qui ne porte pas .torrent sert en réalité un torrent. */
    private fun probeTorrent(url: String): Boolean = runCatching {
        http.newCall(Request.Builder().url(url).header("User-Agent", UA).header("Range", "bytes=0-65535").build()).execute().use { r ->
            if (!r.isSuccessful) return@use false
            val ct = r.header("Content-Type")
            val cd = r.header("Content-Disposition").orEmpty()
            if (ct?.substringBefore(';')?.trim()?.equals("application/x-bittorrent", true) == true ||
                cd.contains(".torrent", true)) return@use true
            if (r.body == null) return@use false
            val head = r.body!!.byteStream().use { input ->
                val b = ByteArray(65536); val n = input.read(b); if (n <= 0) ByteArray(0) else b.copyOf(n)
            }
            val text = head.toString(Charsets.ISO_8859_1)
            head.isNotEmpty() && head[0] == 'd'.code.toByte() &&
                (text.contains("4:info") || text.contains("8:announce"))
        }
    }.getOrDefault(false)

    fun looksLikeFile(url: String): Boolean = pathOf(url).substringAfterLast('.', "") in fileExt

    /** Lance le traitement en arrière-plan ; [onDone] est appelé sur le thread principal. */
    fun launch(app: App, link: String, probe: Boolean, onDone: (Outcome) -> Unit) {
        scope.launch {
            val o = runCatching { handle(app, link, probe) }.getOrElse { Outcome(false, "Échec : " + (it.message ?: "erreur").take(100)) }
            withContext(Dispatchers.Main) { onDone(o) }
        }
    }

    /** Ajoute un torrent (magnet, .torrent) ; [onDone] reçoit le message à afficher. */
    fun launchTorrent(app: App, source: String, onDone: (String) -> Unit) {
        scope.launch {
            val msg = runCatching { addTorrent(app, source) }.getOrElse { "Torrent refusé : " + (it.message ?: it.javaClass.simpleName).take(120) }
            main.post { onDone(msg) }
        }
    }

    private suspend fun handle(app: App, raw: String, probe: Boolean): Outcome = withContext(Dispatchers.IO) {
        val link = raw.trim()
        torrentSource(link)?.let { return@withContext Outcome(true, addTorrent(app, it), torrent = true) }
        if (!link.startsWith("http", true)) return@withContext Outcome(false)

        // Capture des URLs de téléchargement qui masquent leur .torrent derrière une route
        // /download?id=… ou un Content-Disposition: attachment; filename=xxx.torrent.
        if (probe && probeTorrent(link)) {
            return@withContext Outcome(true, addTorrent(app, link), torrent = true)
        }

        if (MediaResolver.isSupportedPage(link)) {
            if (!MediaResolver.isVideoPage(link)) return@withContext Outcome(false)
            // Analyse silencieuse (déjà en cache si la page était ouverte) : on prend la meilleure qualité
            val info = runCatching { MediaResolver.ytInfo(app, link) }.getOrNull()
            val opt = info?.options?.firstOrNull { !it.mp3 } ?: QualityOption("", null, false, "bv*+ba/b")
            val title = info?.title ?: ("Vidéo " + (Uri.parse(link).host ?: ""))
            val id = app.downloadEngine.enqueueYt(link, title, opt, durationSec = info?.durationSec ?: 0, sizeBytes = opt.sizeBytes)
            launchService(app, id)
            return@withContext Outcome(true, "Téléchargement démarré : " + title.take(40))
        }

        if (looksLikeFile(link)) return@withContext startFile(app, link, null)
        if (probe) probeFile(link)?.let { return@withContext startFile(app, link, it) }
        Outcome(false)
    }

    private class FileProbe(val name: String, val mime: String?)

    /** Le serveur répond-il par un fichier (et pas une page HTML) ? */
    private fun probeFile(url: String): FileProbe? = runCatching {
        http.newCall(Request.Builder().url(url).header("User-Agent", UA).header("Range", "bytes=0-0").build()).execute().use { r ->
            if (!r.isSuccessful) null else {
                val ct = r.header("Content-Type")?.substringBefore(';')?.trim()?.lowercase()
                val cd = r.header("Content-Disposition")
                val isFile = cd?.contains("attachment", true) == true ||
                    (ct != null && !ct.startsWith("text/") && ct != "application/xhtml+xml" && ct != "application/json" && ct != "application/javascript")
                if (isFile) FileProbe(URLUtil.guessFileName(r.request.url.toString(), cd, ct), ct) else null
            }
        }
    }.getOrNull()

    private suspend fun startFile(app: App, url: String, p: FileProbe?): Outcome {
        val name = p?.name ?: (Uri.parse(url).lastPathSegment?.takeIf { it.isNotBlank() } ?: "fichier")
        val id = app.downloadEngine.enqueueFile(url, name, p?.mime, UA)
        launchService(app, id)
        return Outcome(true, "Téléchargement démarré : " + name.take(40))
    }

    private suspend fun addTorrent(app: App, source: String): String {
        val msg = app.torrentEngine.addAuto(source)
        try { TorrentService.start(app) } catch (e: Exception) { app.torrentEngine.start() }
        return msg
    }

    /** Service au premier plan ; si Android refuse (appli en arrière-plan), le moteur tourne quand même. */
    private fun launchService(app: App, id: String) {
        try { DownloadService.start(app, id) } catch (e: Exception) { app.downloadEngine.start(id) }
    }
}
