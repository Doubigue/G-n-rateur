package com.example.mydm.torrent

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.CookieManager
import android.webkit.MimeTypeMap
import androidx.core.app.NotificationCompat
import com.example.mydm.MainActivity
import com.example.mydm.core.*
import com.frostwire.jlibtorrent.*
import com.frostwire.jlibtorrent.alerts.Alert
import com.frostwire.jlibtorrent.alerts.AlertType
import com.frostwire.jlibtorrent.swig.torrent_flags_t
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

data class TorrentFile(val index: Int, val path: String, val size: Long, val progress: Long = 0, val selected: Boolean = true)

data class TorrentState(
    val infoHash: String, val name: String, val progress: Float,
    val downloadRate: Int, val uploadRate: Int, val peers: Int, val seeds: Int,
    val state: String, val files: List<TorrentFile>,
    val message: String = "",          // ex. « Recherche des pairs… », « Copie vers Téléchargements… »
    val error: String? = null,
    val paused: Boolean = false,       // pause demandée par vous
    val totalSize: Long = 0
)

/**
 * Moteur torrent (jlibtorrent).
 *  • Un magnet / .torrent (fichier, lien http) est ajouté et téléchargé tout de suite, sans étape d'analyse.
 *  • Les trackers publics sont ajoutés aux magnets pour trouver des pairs plus vite (plusieurs essais, avec reprise).
 *  • Les torrents sont mémorisés : après un redémarrage de l'appli ou du téléphone ils repartent seuls.
 *  • Coupure de connexion : pause automatique, reprise au retour du réseau.
 */
class TorrentEngine(private val context: Context) {
    private val session by lazy { SessionManager() }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val saveDir = File(context.getExternalFilesDir(null), "torrents").apply { mkdirs() }
    private val metaDir = File(context.filesDir, "torrent_meta").apply { mkdirs() }
    private val indexFile = File(context.filesDir, "torrents.json")
    private val http = OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build()

    private class Entry(val id: String, val magnet: String?, var name: String) {
        @Volatile var info: TorrentInfo? = null
        @Volatile var selected: Set<Int>? = null      // null = tous les fichiers
        @Volatile var paused = false                  // pause demandée par l'utilisateur
        @Volatile var netPaused = false               // pause automatique (pas de réseau)
        @Volatile var done = false                    // terminé et copié dans Téléchargements
        @Volatile var status = ""                     // message affiché
        @Volatile var error: String? = null
        @Volatile var job: Job? = null                // récupération des métadonnées / ajout à la session
        val exporting = AtomicBoolean(false)
    }

    private val entries = ConcurrentHashMap<String, Entry>()
    private val _states = MutableStateFlow<Map<String, TorrentState>>(emptyMap())
    val states: StateFlow<Map<String, TorrentState>> = _states
    private var started = false
    private var polling: Job? = null

    // ───────────── Démarrage / restauration
    @Synchronized fun start() {
        if (started && session.isRunning) return
        session.addListener(object : AlertListener {
            override fun types() = intArrayOf(AlertType.TORRENT_FINISHED.swig(), AlertType.TORRENT_ERROR.swig())
            override fun alert(alert: Alert<*>) { /* la fin est détectée par la boucle d'état */ }
        })
        session.start()
        started = true
        restore()
        polling = scope.launch { pollLoop() }
        scope.launch { netLoop() }
    }

    /** Y a-t-il des torrents à reprendre au lancement ? (sans démarrer la session) */
    fun hasPendingWork(): Boolean {
        if (!indexFile.exists()) return false
        return runCatching {
            val arr = JSONArray(indexFile.readText())
            (0 until arr.length()).any { val o = arr.getJSONObject(it); !o.optBoolean("done") && !o.optBoolean("paused") }
        }.getOrDefault(false)
    }

    /** Y a-t-il quelque chose qui tourne (pour garder le service au premier plan) ? */
    fun hasActive(): Boolean = entries.values.any { !it.done && !it.paused && it.error == null }

    private fun restore() {
        if (entries.isNotEmpty() || !indexFile.exists()) return
        runCatching {
            val arr = JSONArray(indexFile.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val id = o.getString("id")
                val e = Entry(id, o.optString("magnet").takeIf { it.isNotBlank() }, o.optString("name", id.take(12)))
                e.paused = o.optBoolean("paused"); e.done = o.optBoolean("done")
                o.optJSONArray("sel")?.let { a -> e.selected = (0 until a.length()).map { a.getInt(it) }.toSet() }
                File(metaDir, "$id.torrent").takeIf { it.exists() }?.let { f -> e.info = runCatching { TorrentInfo.bdecode(f.readBytes()) }.getOrNull() }
                entries[id] = e
                if (!e.done && !e.paused) begin(e)
            }
        }
    }

    @Synchronized private fun save() {
        runCatching {
            val arr = JSONArray()
            entries.values.forEach { e ->
                val o = JSONObject().put("id", e.id).put("magnet", e.magnet ?: "").put("name", e.name)
                    .put("paused", e.paused).put("done", e.done)
                e.selected?.let { o.put("sel", JSONArray(it.toList())) }
                arr.put(o)
            }
            val tmp = File(indexFile.path + ".tmp"); tmp.writeText(arr.toString()); tmp.renameTo(indexFile)
        }
    }

    // ───────────── Ajout automatique (magnet, .torrent en fichier ou en lien)
    /** Ajoute et démarre aussitôt. Renvoie le message à afficher. */
    suspend fun addAuto(source: String): String = withContext(Dispatchers.IO) {
        start()
        val src = source.trim()
        if (src.startsWith("magnet:", true)) {
            val id = btihOf(src) ?: UUID.randomUUID().toString().replace("-", "")
            if (entries.containsKey(id)) { resume(id); return@withContext "Ce torrent est déjà dans la liste" }
            val e = Entry(id, src, magnetName(src) ?: ("Torrent " + id.take(8)))
            entries[id] = e; save(); begin(e)
            "Torrent ajouté — recherche des pairs…"
        } else {
            val data = readTorrentBytes(src)
            val ti = TorrentInfo.bdecode(data)
            val id = hash(ti)
            if (entries.containsKey(id)) { resume(id); return@withContext "Ce torrent est déjà dans la liste" }
            File(metaDir, "$id.torrent").writeBytes(data)
            val e = Entry(id, null, ti.name()); e.info = ti
            entries[id] = e; save(); begin(e)
            "Torrent ajouté : " + ti.name().take(40)
        }
    }

    private fun readTorrentBytes(src: String): ByteArray {
        if (src.startsWith("http", true)) {
            val rb = Request.Builder().url(src).header("User-Agent", AutoDownload.UA)
            CookieManager.getInstance().getCookie(src)?.let { rb.header("Cookie", it) }
            http.newCall(rb.build()).execute().use { r ->
                if (!r.isSuccessful) error("Lien .torrent inaccessible (HTTP ${r.code})")
                val b = r.body!!.bytes()
                if (b.isEmpty() || b[0] != 'd'.code.toByte()) error("Ce lien n'est pas un fichier .torrent valide")
                return b
            }
        }
        return context.contentResolver.openInputStream(Uri.parse(src))?.use { it.readBytes() } ?: error("Fichier .torrent illisible")
    }

    /** Récupère les métadonnées (magnet) puis ajoute le torrent à la session. */
    private fun begin(e: Entry) {
        e.job?.cancel()
        e.error = null
        e.job = scope.launch {
            try {
                if (e.info == null) {
                    val data = fetchMeta(e)
                    if (data == null) {
                        if (!e.paused && entries.containsKey(e.id))
                            e.error = "Aucun pair trouvé. Vérifiez la connexion, puis touchez « Reprendre »."
                        e.status = ""
                        return@launch
                    }
                    File(metaDir, "${e.id}.torrent").writeBytes(data)
                    val ti = TorrentInfo.bdecode(data)
                    e.info = ti; e.name = ti.name()
                    save()
                }
                while (!NetworkMonitor.usable()) { e.status = NetworkMonitor.waitReason() ?: ""; delay(1000) }
                e.status = ""
                addToSession(e)
            } catch (c: CancellationException) {
                throw c
            } catch (t: Throwable) {
                e.error = (t.message ?: t.javaClass.simpleName).take(200)
            }
        }
    }

    private suspend fun fetchMeta(e: Entry): ByteArray? {
        val uri = withTrackers(e.magnet ?: return null)
        for (attempt in 1..8) {
            while (!NetworkMonitor.usable()) { e.status = NetworkMonitor.waitReason() ?: ""; delay(1000) }
            e.status = "Recherche des pairs… (essai $attempt/8)"
            val data = withContext(Dispatchers.IO) { runCatching { session.fetchMagnet(uri, 60, saveDir) }.getOrNull() }
            if (data != null) { e.status = ""; return data }
            if (e.paused || !entries.containsKey(e.id)) return null
        }
        return null
    }

    private fun addToSession(e: Entry) {
        val ti = e.info ?: return
        if (session.find(ti.infoHashV1()) != null) { handle(e)?.resume(); return }
        val sel = e.selected
        val prios = Array(ti.numFiles()) { if (sel == null || it in sel) Priority.NORMAL else Priority.IGNORE }
        session.download(ti, saveDir, null, prios, null, torrent_flags_t())
    }

    // ───────────── Commandes
    fun hash(ti: TorrentInfo) = ti.infoHashV1().toHex()

    fun listFiles(ti: TorrentInfo): List<TorrentFile> {
        val fs = ti.files()
        return (0 until fs.numFiles()).map { TorrentFile(it, fs.filePath(it), fs.fileSize(it)) }
    }

    fun setSelection(id: String, selected: Set<Int>) {
        val e = entries[id] ?: return
        e.selected = selected
        val ti = e.info
        if (ti != null) handle(e)?.prioritizeFiles(Array(ti.numFiles()) { if (it in selected) Priority.NORMAL else Priority.IGNORE })
        save()
    }

    fun pause(id: String) {
        val e = entries[id] ?: return
        e.paused = true
        handle(e)?.pause()
        save()
    }

    fun resume(id: String) {
        val e = entries[id] ?: return
        e.paused = false; e.error = null; e.exporting.set(false)
        if (e.done) return
        if (e.info == null || handle(e) == null) begin(e) else handle(e)?.resume()
        save()
    }

    /** Retire de la liste ; les données incomplètes sont supprimées (un torrent terminé garde ses fichiers dans Téléchargements). */
    fun remove(id: String) {
        val e = entries.remove(id) ?: return
        e.job?.cancel()
        val ti = e.info
        if (ti != null) {
            runCatching { session.find(ti.infoHashV1())?.let { session.remove(it) } }
            if (!e.done) runCatching {
                File(saveDir, ti.name()).takeIf { it.isDirectory }?.deleteRecursively()
                listFiles(ti).forEach { File(saveDir, it.path).delete() }
            }
        }
        File(metaDir, "$id.torrent").delete()
        save()
    }

    private fun handle(e: Entry): TorrentHandle? = e.info?.let { runCatching { session.find(it.infoHashV1()) }.getOrNull() }

    // ───────────── Fin d'un torrent : copie dans Download/<racine>/Torrent/<Vidéos|Applications|…>
    private fun exportToLibrary(e: Entry, ti: TorrentInfo) {
        if (!e.exporting.compareAndSet(false, true)) return
        scope.launch {
            try {
                e.status = "Copie vers Téléchargements…"
                val sel = e.selected
                listFiles(ti).filter { sel == null || it.index in sel }.forEach { f ->
                    val src = File(saveDir, f.path)
                    if (!src.exists()) return@forEach
                    val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extOf(src.name))
                    val uri = Storage.create(context, src.name, mime, Storage.rel(Category.TORRENT, torrentSubFolder(src.name)))
                    context.contentResolver.openOutputStream(uri)!!.use { o -> src.inputStream().use { it.copyTo(o, 256 * 1024) } }
                    Storage.finish(context, uri)
                    src.delete()          // évite de garder deux copies
                }
                handle(e)?.pause()
                e.done = true; e.status = ""; save()
                notifyDone(e.name)
            } catch (t: Throwable) {
                e.error = "Copie impossible : " + (t.message ?: t.javaClass.simpleName).take(120)
                e.status = ""
            }
        }
    }

    private fun notifyDone(name: String) {
        runCatching {
            val nm = context.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("done", "Téléchargements terminés", NotificationManager.IMPORTANCE_DEFAULT))
            val pi = PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            nm.notify(name.hashCode(), NotificationCompat.Builder(context, "done").setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle("Torrent terminé").setContentText(name).setContentIntent(pi).setAutoCancel(true).build())
        }
    }

    // ───────────── Coupure / retour du réseau : pause et reprise automatiques
    private suspend fun netLoop() {
        var wasUsable = NetworkMonitor.usable()
        NetworkMonitor.changes.collect {
            val usable = NetworkMonitor.usable()
            if (!usable && wasUsable) {
                entries.values.forEach { e -> if (!e.paused && !e.done && handle(e) != null) { e.netPaused = true; handle(e)?.pause() } }
            } else if (usable && !wasUsable) {
                delay(1500)
                entries.values.forEach { e -> if (e.netPaused) { e.netPaused = false; if (!e.paused) handle(e)?.resume() } }
            }
            wasUsable = usable
        }
    }

    // ───────────── État affiché
    private fun stateOf(id: String, e: Entry): TorrentState {
        val ti = e.info
        val h = handle(e)
        val files = ti?.let { listFiles(it) } ?: emptyList()
        if (ti == null || h == null || !h.isValid) {
            val st = when {
                e.error != null -> "ERREUR"
                e.done -> "FINISHED"
                e.paused -> "PAUSED"
                else -> "DOWNLOADING_METADATA"
            }
            val sel = e.selected
            return TorrentState(id, e.name, if (e.done) 1f else 0f, 0, 0, 0, 0, st,
                files.map { it.copy(selected = sel == null || it.index in sel, progress = if (e.done) it.size else 0L) },
                e.status, e.error, e.paused, files.sumOf { it.size })
        }
        val s = h.status()
        // jlibtorrent 2.0.x
        val perFile = h.fileProgress(TorrentHandle.PIECE_GRANULARITY)
        val sel = e.selected
        val fl = files.map { it.copy(progress = perFile.getOrElse(it.index) { 0L }, selected = sel == null || it.index in sel) }
        val name = s.state().name
        if ((name == "FINISHED" || name == "SEEDING") && !e.done && e.error == null) exportToLibrary(e, ti)
        val shown = when {
            e.error != null -> "ERREUR"
            e.paused -> "PAUSED"
            e.netPaused -> "NET_PAUSED"
            else -> name
        }
        return TorrentState(id, e.name, s.progress(), s.downloadPayloadRate(), s.uploadPayloadRate(), s.numPeers(), s.numSeeds(),
            shown, fl, e.status, e.error, e.paused, fl.filter { it.selected }.sumOf { it.size })
    }

    private suspend fun pollLoop() {
        while (currentCoroutineContext().isActive) {
            _states.value = entries.mapValues { (id, e) -> runCatching { stateOf(id, e) }.getOrElse {
                TorrentState(id, e.name, 0f, 0, 0, 0, 0, "ERREUR", emptyList(), error = it.message)
            } }
            delay(1000)
        }
    }

    // ───────────── Magnets : identifiant, nom, trackers publics
    private fun btihOf(magnet: String): String? {
        val h = Regex("xt=urn:btih:([A-Za-z0-9]+)", RegexOption.IGNORE_CASE).find(magnet)?.groupValues?.get(1) ?: return null
        return when {
            h.length == 40 && h.all { it.isDigit() || it.lowercaseChar() in 'a'..'f' } -> h.lowercase()
            h.length == 32 -> base32ToHex(h)
            else -> null
        }
    }

    private fun base32ToHex(s: String): String? {
        val alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"
        var bits = 0; var value = 0
        val out = StringBuilder()
        for (ch in s.uppercase()) {
            val v = alpha.indexOf(ch); if (v < 0) return null
            value = (value shl 5) or v; bits += 5
            if (bits >= 8) { bits -= 8; out.append("%02x".format((value shr bits) and 0xFF)) }
            value = value and ((1 shl bits) - 1)
        }
        return out.toString().takeIf { it.length == 40 }
    }

    private fun magnetName(magnet: String): String? =
        Regex("[?&]dn=([^&]+)").find(magnet)?.groupValues?.get(1)?.let { runCatching { URLDecoder.decode(it, "UTF-8") }.getOrNull() }

    private val publicTrackers = listOf(
        "udp://tracker.opentrackr.org:1337/announce", "udp://open.stealth.si:80/announce",
        "udp://tracker.torrent.eu.org:451/announce", "udp://exodus.desync.com:6969/announce",
        "udp://open.demonii.com:1337/announce", "udp://tracker.openbittorrent.com:6969/announce",
        "udp://tracker.dler.org:6969/announce", "udp://opentracker.i2p.rocks:6969/announce",
        "udp://explodie.org:6969/announce", "udp://tracker.tiny-vps.com:6969/announce",
        "udp://p4p.arenabg.com:1337/announce", "https://tracker.tamersunion.org:443/announce"
    )

    /** Beaucoup de magnets n'ont aucun tracker (ou des trackers morts) : on ajoute une liste de trackers publics. */
    private fun withTrackers(magnet: String): String {
        val have = magnet.lowercase()
        val sb = StringBuilder(magnet)
        publicTrackers.forEach { t ->
            val host = t.substringAfter("://").substringBefore('/')
            if (host.lowercase() !in have && URLEncoder.encode(host, "UTF-8").lowercase() !in have) sb.append("&tr=").append(URLEncoder.encode(t, "UTF-8"))
        }
        return sb.toString()
    }
}
