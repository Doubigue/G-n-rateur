package com.example.mydm.torrent

import android.app.*
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.mydm.App
import com.example.mydm.MainActivity
import com.example.mydm.core.KeepAlive
import kotlinx.coroutines.*

/** Garde les torrents en marche en arrière-plan (écran éteint, appli fermée) et les relance si Android arrête le processus. */
class TorrentService : Service() {
    private val engine get() = (application as App).torrentEngine
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onBind(i: Intent?) = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Torrents", NotificationManager.IMPORTANCE_LOW))
        startForeground(NOTIF_ID, notif("Torrent en cours…"), KeepAlive.fgsType())
        KeepAlive.acquire(this, "torrent")
        scope.launch {
            withContext(Dispatchers.IO) { runCatching { engine.start() } }      // recharge aussi les torrents mémorisés
            delay(3000)
            while (isActive) {
                if (!engine.hasActive()) { stopSelf(); break }
                val s = engine.states.value.values.filter { it.state != "FINISHED" || it.progress < 1f }
                val style = NotificationCompat.InboxStyle()
                s.take(5).forEach {
                    val info = when {
                        it.error != null -> "erreur"
                        it.paused -> "en pause"
                        it.state == "NET_PAUSED" -> "⏸ pas de connexion"
                        it.message.isNotBlank() -> it.message
                        else -> "${(it.progress * 100).toInt()}% • ${it.peers} pairs"
                    }
                    style.addLine("${it.name.take(32)} — $info")
                }
                if (s.size > 5) style.setSummaryText("+${s.size - 5} autres")
                nm.notify(NOTIF_ID, NotificationCompat.Builder(this@TorrentService, CH).setSmallIcon(android.R.drawable.stat_sys_download)
                    .setContentTitle("${s.size} torrent(s) • ↓ ${s.sumOf { it.downloadRate } / 1024} Ko/s ↑ ${s.sumOf { it.uploadRate } / 1024} Ko/s")
                    .setContentText(s.firstOrNull()?.name ?: "")
                    .setContentIntent(PendingIntent.getActivity(this@TorrentService, 0, Intent(this@TorrentService, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
                    .setStyle(style).setNumber(s.size).setOngoing(true).setOnlyAlertOnce(true).build())
                delay(1000)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY
    override fun onDestroy() { scope.cancel(); KeepAlive.release("torrent") }

    private fun notif(text: String) = NotificationCompat.Builder(this, CH)
        .setSmallIcon(android.R.drawable.stat_sys_download).setContentTitle("MyDM Torrent")
        .setContentText(text).setOngoing(true).build()

    companion object {
        const val CH = "torrents"; const val NOTIF_ID = 43
        fun start(ctx: Context) = ContextCompat.startForegroundService(ctx, Intent(ctx, TorrentService::class.java))
    }
}
