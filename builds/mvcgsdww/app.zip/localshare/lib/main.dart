import 'package:flutter/material.dart';
import 'screens/file_viewer_screen.dart';
import 'screens/home_screen.dart';
import 'services/file_transfer_service.dart';
import 'services/nearby_service.dart';
import 'services/notification_service.dart';
import 'services/remote_fs_service.dart';

final GlobalKey<NavigatorState> navKey = GlobalKey<NavigatorState>();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await NotificationService.init();
  runApp(const LocalShareApp());
}

class LocalShareApp extends StatefulWidget {
  const LocalShareApp({super.key});
  @override
  State<LocalShareApp> createState() => _LocalShareAppState();
}

class _LocalShareAppState extends State<LocalShareApp> {
  // Services créés une seule fois, dès le lancement : ils écoutent les payloads
  // avant même l'ouverture de l'écran de transfert (aucun message perdu).
  late final NearbyService nearby = NearbyService();
  late final FileTransferService files = FileTransferService(nearby);
  late final RemoteFsService remote = RemoteFsService(nearby, files);

  @override
  void initState() {
    super.initState();
    NotificationService.onAction = _onNotificationAction;
  }

  /// Boutons des notifications et appui sur « Réception terminée ».
  void _onNotificationAction(String? action, String? payload) {
    switch (action) {
      case 'conn_accept':
        nearby.acceptPending();
        return;
      case 'conn_reject':
        nearby.rejectPending();
        return;
      case 'fs_allow':
        if (remote.pendingRequest) remote.allow();
        return;
      case 'fs_deny':
        if (remote.pendingRequest) remote.respond(false);
        return;
    }
    if (payload != null && payload.startsWith('open:')) {
      navKey.currentState?.push(
        MaterialPageRoute(builder: (_) => FileViewerScreen(path: payload.substring(5))),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      navigatorKey: navKey,
      title: 'LocalShare',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorSchemeSeed: Colors.indigo, useMaterial3: true),
      darkTheme: ThemeData(
        colorSchemeSeed: Colors.indigo,
        brightness: Brightness.dark,
        useMaterial3: true,
      ),
      home: HomeScreen(nearby: nearby, files: files, remote: remote),
    );
  }
}
