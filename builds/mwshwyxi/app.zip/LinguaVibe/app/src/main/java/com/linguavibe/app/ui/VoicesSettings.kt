package com.linguavibe.app.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.speech.tts.TextToSpeech
import androidx.compose.runtime.DisposableEffect
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linguavibe.app.data.Languages
import com.linguavibe.app.speech.VoicePacks
import com.linguavibe.app.speech.VoiceSettings
import com.linguavibe.app.speech.SupertonicVoiceManager
import com.linguavibe.app.speech.SupertonicTts
import com.linguavibe.app.speech.ChineseVoiceManager
import com.linguavibe.app.speech.ChineseVitsTts
import kotlinx.coroutines.launch

/** Phrases d'essai pour chaque langue. */
private val samples = listOf(
    "es" to "Hola, bienvenido a tu clase de español.",
    "en" to "Hello, welcome to your English lesson.",
    "pt" to "Olá, bem-vindo à sua aula de português.",
    "ru" to "Здравствуйте, добро пожаловать на урок.",
    "zh" to "你好，欢迎来上中文课。",
    "ar" to "مرحبا، أهلا بك في درس اللغة العربية.",
    "fr" to "Bonjour, bienvenue dans votre leçon de français."
)

/** Choix de la voix de l'appli et essai des voix. */
@Composable
fun VoiceEngineSection() {
    val speaker = LocalSpeaker.current
    val settings = speaker.settings

    CardBox {
        Text("Voix utilisée pour lire les leçons", style = PosterTitle, fontSize = 17.sp, color = Ink)
        listOf(
            VoiceSettings.ENGINE_AUTO to "Automatique : Supertonic 3 hors ligne si installé, sinon audio Google préchargé",
            VoiceSettings.ENGINE_SUPERTONIC to "Supertonic 3 : synthèse locale hors ligne après téléchargement du modèle",
            VoiceSettings.ENGINE_ELEVEN to "ElevenLabs en priorité (clé API, connexion et quota requis)"
        ).forEach { (id, label) ->
            val selected = settings.engine == id ||
                (id == VoiceSettings.ENGINE_AUTO && settings.engine != VoiceSettings.ENGINE_ELEVEN)
            ChoiceRow(label, selected, Ruby) { settings.updateEngine(id) }
        }
        Text(
            "Supertonic 3 synthétise localement les nouveaux textes après installation. Les audios préchargés " +
                "restent une option séparée pour une lecture immédiate.",
            fontSize = 12.sp, color = InkSoft
        )
    }

    CardBox {
        Text("Essayer les voix", style = PosterTitle, fontSize = 17.sp, color = Ink)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            samples.filter { it.first != "zh" }.forEach { (code, sentence) ->
                val lang = Languages.byCode(code)
                Box(
                    Modifier.weight(1f).clickable { speaker.speak(sentence, lang.locale) },
                    contentAlignment = Alignment.Center
                ) { LangBadge(code, 42.dp) }
            }
        }
        if (speaker.lastEngine.isNotBlank()) {
            Text("Dernière phrase lue par : ${speaker.lastEngine}", fontSize = 13.sp, color = InkSoft)
        }
        speaker.lastError?.let { StatusLine(it, -1) }
    }
}

/** Téléchargement des voix, une fois par langue, pour tout lire sans Internet. */
@Composable
fun VoicePacksSection() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val modelProgress = SupertonicVoiceManager.progress.value
    var modelBusy by remember { mutableStateOf(false) }
    var modelError by remember { mutableStateOf<String?>(null) }
    var installed by remember { mutableStateOf(SupertonicVoiceManager.isInstalled(context)) }
    CardBox {
        Text("Voix neuronales intégrées à LinguaVibe", style = PosterTitle, fontSize = 17.sp, color = Ink)
        Text(
            "Supertonic 3 est un moteur TTS local (ni Piper ni Kokoro). Le pack multilingue est téléchargé " +
                "dans le stockage privé de LinguaVibe (environ 132 Mo à télécharger, 145 Mo installés). Une fois installé, il lit de nouveaux " +
                "textes hors ligne en français, espagnol, anglais, portugais, russe et arabe. Le chinois dispose d'un pack séparé. Les " +
                "langues partagent le même modèle ; chaque langue peut utiliser l'une des 10 voix intégrées.",
            fontSize = 13.sp, color = InkSoft
        )
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (installed) {
                Text("Modèle installé · prêt hors ligne", color = Good, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                OutlinedButton(onClick = {
                    SupertonicVoiceManager.remove(context)
                    SupertonicTts.release()
                    modelError = null
                    installed = false
                }) { Text("Supprimer") }
            } else {
                Button(enabled = !modelBusy, onClick = {
                    modelBusy = true; modelError = null
                    scope.launch {
                        try { SupertonicVoiceManager.install(context); installed = true }
                        catch (t: Throwable) { modelError = t.message ?: "Téléchargement impossible." }
                        finally { modelBusy = false }
                    }
                }) { Text(if (modelBusy) "Installation…" else "Télécharger le modèle vocal") }
            }
        }
        if (modelBusy && modelProgress.total > 0) {
            LinearProgressIndicator(progress = { (modelProgress.downloaded.toFloat() / modelProgress.total).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth(), color = Ruby)
            Text("${modelProgress.downloaded / (1024 * 1024)} / ${modelProgress.total / (1024 * 1024)} Mo", fontSize = 12.sp, color = InkSoft)
        }
        (modelError ?: modelProgress.error)?.let { Text(it, fontSize = 12.sp, color = Bad) }
        if (installed) {
            Text("Choisissez Supertonic 3 ci-dessus pour que la synthèse des nouveaux textes soit hors ligne.", fontSize = 12.sp, color = InkSoft)
            samples.filter { it.first != "zh" }.forEach { (code, sentence) ->
                val lang = Languages.byCode(code)
                val sid = speaker.settings.speakerFor(code)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                    LangBadge(code, 30.dp)
                    Text(lang.name, modifier = Modifier.weight(1f), fontSize = 13.sp, color = Ink)
                    OutlinedButton(onClick = { speaker.settings.updateSpeakerFor(code, (sid + 1) % 10) }) { Text("Voix ${sid + 1}/10") }
                    TextButton(onClick = { speaker.settings.updateEngine(VoiceSettings.ENGINE_SUPERTONIC); speaker.speak(sentence, lang.locale) }) { Text("Écouter") }
                }
            }
        }
    }
    val zhProgress = ChineseVoiceManager.progress.value
    var zhBusy by remember { mutableStateOf(false) }
    var zhError by remember { mutableStateOf<String?>(null) }
    var zhInstalled by remember { mutableStateOf(ChineseVoiceManager.isInstalled(context)) }
    CardBox {
        Text("Voix chinoise hors ligne", style = PosterTitle, fontSize = 17.sp, color = Ink)
        Text("Supertonic 3 ne liste pas le chinois. LinguaVibe utilise donc un modèle chinois dédié VITS Icefall AISHELL-3, téléchargé séparément (environ 30 Mo pour le fichier ONNX). Il fonctionne localement après installation et propose 174 identifiants de voix.", fontSize = 13.sp, color = InkSoft)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (zhInstalled) {
                Text("Modèle chinois installé", color = Good, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                OutlinedButton(onClick = { ChineseVoiceManager.remove(context); ChineseVitsTts.release(); zhInstalled = false }) { Text("Supprimer") }
            } else {
                Button(enabled = !zhBusy, onClick = {
                    zhBusy = true; zhError = null
                    scope.launch {
                        try { ChineseVoiceManager.install(context); zhInstalled = true }
                        catch (t: Throwable) { zhError = t.message ?: "Téléchargement chinois impossible." }
                        finally { zhBusy = false }
                    }
                }) { Text(if (zhBusy) "Installation…" else "Télécharger la voix chinoise") }
            }
        }
        if (zhBusy && zhProgress.total > 0) {
            LinearProgressIndicator(progress = { (zhProgress.downloaded.toFloat() / zhProgress.total).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth(), color = Ruby)
            Text("${zhProgress.downloaded / (1024 * 1024)} / ${zhProgress.total / (1024 * 1024)} Mo", fontSize = 12.sp, color = InkSoft)
        }
        (zhError ?: zhProgress.error)?.let { Text(it, fontSize = 12.sp, color = Bad) }
        if (zhInstalled) {
            val sid = speaker.settings.chineseSpeaker()
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                LangBadge("zh", 30.dp)
                Text("Mandarin", modifier = Modifier.weight(1f), fontSize = 13.sp, color = Ink)
                OutlinedButton(onClick = { speaker.settings.updateChineseSpeaker((sid + 1) % 174) }) { Text("Voix ${sid + 1}/174") }
                TextButton(onClick = { speaker.speak("你好，欢迎来上中文课。", Languages.byCode("zh").locale) }) { Text("Écouter") }
            }
        }
    }
    CardBox {
        Text("Précharger les audios des phrases (facultatif)", style = PosterTitle, fontSize = 17.sp, color = Ink)
        Text(
            "Cette option enregistre les phrases existantes pour une lecture instantanée. Ce n'est pas un modèle TTS. " +
                "Pour synthétiser de nouveaux textes hors ligne, installez le modèle Supertonic 3 ci-dessus.",
            fontSize = 14.sp, color = InkSoft
        )
        Languages.all.forEach { lang ->
            val state = VoicePacks.progress[lang.code]
            val done = state == null && VoicePacks.isDone(context, lang.code) ||
                (state != null && !state.running && state.total > 0 && state.done >= state.total)
            Column(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    LangBadge(lang.code, 34.dp)
                    Column(Modifier.weight(1f)) {
                        Text(lang.name, fontWeight = FontWeight.SemiBold, color = Ink)
                        Text(
                            when {
                                state?.running == true && state.total > 0 -> "${state.done} / ${state.total} phrases"
                                state?.running == true -> "Préparation…"
                                done -> "Audios préchargés"
                                else -> "Non téléchargée"
                            },
                            fontSize = 12.sp, color = if (done) Good else InkSoft
                        )
                    }
                    when {
                        state?.running == true ->
                            PillButton("Arrêter", Art.icStop, Bad, filled = false) { VoicePacks.cancel(lang.code) }
                        done -> Unit
                        else ->
                            PillButton(
                                if (state != null && state.done > 0) "Reprendre" else "Télécharger",
                                Art.icDownload, Ruby
                            ) { VoicePacks.start(context, lang.code) }
                    }
                }
                if (state?.running == true && state.total > 0) {
                    LinearProgressIndicator(
                        progress = { state.done.toFloat() / state.total },
                        modifier = Modifier.fillMaxWidth(), color = Ruby
                    )
                }
                state?.message?.let { Text(it, fontSize = 12.sp, color = Bad) }
            }
        }
    }
}
