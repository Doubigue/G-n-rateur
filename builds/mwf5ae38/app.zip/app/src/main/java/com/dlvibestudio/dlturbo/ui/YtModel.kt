package com.dlvibestudio.dlturbo.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.dlvibestudio.dlturbo.App
import com.dlvibestudio.dlturbo.engine.VideoInfo
import com.dlvibestudio.dlturbo.engine.YtEntry
import com.dlvibestudio.dlturbo.engine.YtSearch
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.net.URLEncoder

data class YtCategory(val label: String, val query: String, val playlists: Boolean = false)

/**
 * État de l'onglet YouTube : recherche native (résultats avec icône de téléchargement),
 * catégories, onglet « Liste de lecture » et écran « Sélectionné ». Conservé quand on change d'onglet.
 */
class YtModel(private val app: App) {

    val categories = listOf(
        YtCategory("Tendances", "tendances du moment"),
        YtCategory("Musique", "musique"),
        YtCategory("Afrique", "musique africaine"),
        YtCategory("Films", "film complet"),
        YtCategory("Jeux", "gaming"),
        YtCategory("Sport", "sport"),
        YtCategory("Actualités", "actualités"),
        YtCategory("Playlists", "playlist musique", playlists = true),
    )

    /** 0 = Découvrir (liste native), 1 = Site YouTube (WebView), 2 = Liste de lecture. */
    var mode by mutableIntStateOf(0)
    var query by mutableStateOf("")
    var category by mutableIntStateOf(0)
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var results by mutableStateOf<List<YtEntry>>(emptyList())
    var canLoadMore by mutableStateOf(false)

    /** Page à charger dans le mode « Site YouTube » dès qu'il s'affiche (null = rien de spécial). */
    var siteTarget by mutableStateOf<String?>(null)
    var siteLoaded = false

    /** Panier : vidéos ajoutées avec « + » pour être téléchargées ensemble. */
    val cart = androidx.compose.runtime.mutableStateListOf<YtEntry>()
    var cartOpen by mutableStateOf(false)
    var subsOpen by mutableStateOf(false)

    fun inCart(entry: YtEntry) = cart.any { it.url == entry.url }

    fun toggleCart(entry: YtEntry) {
        if (entry.isPlaylist) return
        val i = cart.indexOfFirst { it.url == entry.url }
        if (i >= 0) cart.removeAt(i) else cart.add(entry)
    }

    private var count = PAGE
    private var lastQuery = ""
    private var lastPlaylists = false
    private var job: Job? = null
    private var started = false

    /** Ouvre une vidéo dans le site YouTube pour la regarder. */
    fun watch(videoUrl: String) {
        val mobile = videoUrl.replace("://www.youtube.com", "://m.youtube.com")
        siteTarget = mobile + (if (mobile.contains('?')) "&" else "?") + "app=m&persist_app=1"
        mode = 1
    }

    fun startIfNeeded() {
        if (started) return
        started = true
        selectCategory(0)
    }

    fun selectCategory(index: Int) {
        category = index
        query = ""
        val c = categories[index]
        search(c.query, c.playlists, more = false)
    }

    fun submit() {
        val q = query.trim()
        if (q.isEmpty()) return
        category = -1
        app.library.addSearch(q)
        search(q, playlists = false, more = false)
    }

    /** Relance la dernière recherche (bouton « Réessayer »). */
    fun retry() {
        if (lastQuery.isBlank()) selectCategory(category.coerceAtLeast(0))
        else search(lastQuery, lastPlaylists, more = false)
    }

    fun loadMore() {
        search(lastQuery, lastPlaylists, more = true)
    }

    private fun search(q: String, playlists: Boolean, more: Boolean) {
        job?.cancel()
        lastQuery = q
        lastPlaylists = playlists
        count = if (more) (count + PAGE).coerceAtMost(MAX) else PAGE
        job = app.scope.launch {
            loading = true
            error = null
            try {
                // 1) Recherche directe sur YouTube : rapide (une seule requête), sans attendre le moteur vidéo.
                var list: List<YtEntry> = emptyList()
                var firstError: Exception? = null
                if (!more) {
                    try {
                        list = YtSearch.search(app.manager.http.client, q, playlists)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        firstError = e
                    }
                    if (list.isNotEmpty()) {
                        results = list
                        loading = false
                    }
                }
                // 2) Moteur yt-dlp : si la recherche directe n'a rien donné, ou pour « voir plus ».
                if (list.isEmpty() || more) {
                    try {
                        val json = if (playlists) {
                            val enc = URLEncoder.encode(q, "UTF-8")
                            app.manager.videos.dumpJson(
                                "https://www.youtube.com/results?search_query=$enc&sp=EgIQAw%3D%3D",
                                "--flat-playlist" to null,
                                "--playlist-end" to count.toString(),
                            )
                        } else {
                            app.manager.videos.dumpJson("ytsearch$count:$q", "--flat-playlist" to null)
                        }
                        val viaEngine = VideoInfo.entries(json)
                        if (viaEngine.isNotEmpty()) {
                            list = viaEngine
                            results = list
                        }
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        if (results.isEmpty()) throw firstError?.let { Exception(e.message ?: it.message) } ?: e
                    }
                }
                canLoadMore = results.isNotEmpty() && count < MAX
                if (results.isEmpty()) error = "Aucun résultat"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = e.message ?: "Erreur de recherche"
            } finally {
                loading = false
            }
        }
    }

    // ───────────── Onglet « Liste de lecture » ─────────────

    var listsQuery by mutableStateOf("")
    var lists by mutableStateOf<List<YtEntry>>(emptyList())
    var listsLoading by mutableStateOf(false)
    var listsError by mutableStateOf<String?>(null)
    private var listsJob: Job? = null
    private var listsLast = ""
    private var listsStarted = false

    /** Première ouverture de l'onglet : quelques listes de lecture tout de suite, sans qu'il faille chercher. */
    fun startListsIfNeeded() {
        if (listsStarted) return
        listsStarted = true
        searchLists(DEFAULT_LISTS_QUERY)
    }

    fun submitLists() {
        val q = listsQuery.trim()
        if (q.isEmpty()) return
        searchLists(q)
    }

    fun retryLists() = searchLists(listsLast.ifBlank { DEFAULT_LISTS_QUERY })

    private fun searchLists(q: String) {
        listsJob?.cancel()
        listsLast = q
        listsError = null
        listsLoading = true
        listsJob = app.scope.launch {
            try {
                var found: List<YtEntry> = emptyList()
                var failure: Exception? = null
                // 1) Recherche directe (une requête) ; 2) yt-dlp en secours.
                try {
                    found = YtSearch.search(app.manager.http.client, q, playlists = true).filter { it.isPlaylist }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    failure = e
                }
                if (found.isEmpty()) {
                    try {
                        val enc = URLEncoder.encode(q, "UTF-8")
                        val json = app.manager.videos.dumpJson(
                            "https://www.youtube.com/results?search_query=$enc&sp=EgIQAw%3D%3D",
                            "--flat-playlist" to null,
                            "--playlist-end" to LISTS_MAX.toString(),
                        )
                        found = VideoInfo.entries(json).filter { it.isPlaylist }
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        failure = failure ?: e
                    }
                }
                // Hors connexion ou erreur : les listes déjà affichées restent à l'écran.
                if (found.isNotEmpty()) lists = found.distinctBy { it.url }
                else listsError = failure?.message ?: "Aucune liste de lecture trouvée"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                listsError = e.message ?: "Erreur de recherche"
            } finally {
                listsLoading = false
            }
        }
    }

    // ───────────── Écran « Sélectionné » ─────────────
    // Toutes les vidéos d'une liste de lecture / chaîne / lien collé, cochées d'office ; FAIT → format → file de téléchargement
    // dans un dossier au nom de la liste.

    /** Non nul : l'écran « Sélectionné » est ouvert (il porte le nom de la liste, aussi nom du dossier). */
    var selTitle by mutableStateOf<String?>(null)
    var selItems by mutableStateOf<List<YtEntry>>(emptyList())
    var selLoading by mutableStateOf(false)
    var selError by mutableStateOf<String?>(null)
    var selFormatOpen by mutableStateOf(false)
    val selChecked = mutableStateMapOf<String, Boolean>()
    private var selJob: Job? = null
    private var selUrl = ""
    private var selExpected = 0
    private var selNamed = false

    val selCount: Int get() = selItems.count { selChecked[it.url] == true }

    fun openPlaylist(entry: YtEntry) = openSelection(entry.url, entry.title, entry.count)

    /** [title] vide (lien collé) : le nom est lu dans la liste elle-même. [expected] : nombre de vidéos annoncé, 0 si inconnu. */
    fun openSelection(url: String, title: String, expected: Int) {
        selJob?.cancel()
        selUrl = url
        selExpected = expected
        selNamed = title.isNotBlank()
        selTitle = title.ifBlank { "Liste" }
        selItems = emptyList()
        selChecked.clear()
        selError = null
        selFormatOpen = false
        selLoading = true
        selJob = app.scope.launch {
            try {
                var items: List<YtEntry> = emptyList()
                // 1) Lecture directe de la page de la liste (rapide, une centaine de vidéos au plus).
                if (VideoInfo.hasPlaylistParam(url)) {
                    try {
                        val (pageTitle, videos) = YtSearch.playlist(app.manager.http.client, url)
                        if (videos.isNotEmpty()) {
                            items = videos
                            if (pageTitle.isNotBlank()) {
                                selTitle = pageTitle
                                selNamed = true
                            }
                            setSelection(items)
                        }
                    } catch (e: CancellationException) {
                        throw e
                    } catch (_: Exception) {
                    }
                }
                // 2) yt-dlp : rien lu sur la page (chaîne…), ou liste plus longue que ce que la page donne.
                if (items.isEmpty() || items.size >= FAST_MAX || expected > items.size) {
                    try {
                        val json = app.manager.videos.dumpJson(listUrl(url), "--flat-playlist" to null)
                        val all = VideoInfo.entries(json).filter { !it.isPlaylist }
                        if (!selNamed) json.optString("title").takeIf { it.isNotBlank() }?.let { selTitle = it }
                        if (all.size > items.size) {
                            items = all
                            setSelection(all)
                        }
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        if (items.isEmpty()) throw e
                    }
                }
                if (items.isEmpty()) selError = "Liste vide ou privée"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                selError = e.message ?: "Impossible de lire la liste"
            } finally {
                selLoading = false
            }
        }
    }

    fun retrySelection() {
        if (selUrl.isBlank()) return
        openSelection(selUrl, if (selNamed) selTitle.orEmpty() else "", selExpected)
    }

    /** Les vidéos déjà là gardent leur case ; les nouvelles arrivent cochées. */
    private fun setSelection(list: List<YtEntry>) {
        val clean = list.distinctBy { it.url }
        val known = selItems.map { it.url }.toHashSet()
        selItems = clean
        clean.forEach { if (it.url !in known) selChecked[it.url] = true }
    }

    fun toggleSel(entry: YtEntry) {
        selChecked[entry.url] = selChecked[entry.url] != true
    }

    fun toggleSelectAll() {
        val all = selItems.isNotEmpty() && selCount == selItems.size
        selItems.forEach { selChecked[it.url] = !all }
    }

    /** Met en file les vidéos cochées dans le format choisi, rangées dans un dossier au nom de la liste. Renvoie leur nombre. */
    fun downloadSelection(quality: String): Int {
        val picked = selItems.filter { selChecked[it.url] == true }
        val folder = selTitle.orEmpty()
        picked.forEach { app.manager.enqueueVideo(it.url, quality, false, it.title, folder) }
        return picked.size
    }

    /** Retour depuis l'écran « Sélectionné ». Renvoie false s'il n'y avait rien à fermer. */
    fun closeSelection(): Boolean {
        if (selTitle == null) return false
        selJob?.cancel()
        selJob = null
        selTitle = null
        selItems = emptyList()
        selChecked.clear()
        selLoading = false
        selError = null
        selFormatOpen = false
        return true
    }

    /**
     * Adresse lue par yt-dlp : toujours la liste elle-même (un lien « vidéo + list= » ne donnerait que la vidéo),
     * et pour une chaîne l'onglet « Vidéos » (sans lui, yt-dlp renvoie les onglets, pas les vidéos).
     */
    private fun listUrl(url: String): String {
        Regex("""[?&]list=([A-Za-z0-9_-]+)""").find(url)?.groupValues?.get(1)?.let {
            return "https://www.youtube.com/playlist?list=$it"
        }
        val clean = url.substringBefore('#')
        val channel = Regex("""youtube\.com/(@[^/?]+|channel/[^/?]+|c/[^/?]+|user/[^/?]+)/?(\?.*)?$""")
        return if (channel.containsMatchIn(clean)) clean.substringBefore('?').trimEnd('/') + "/videos" else clean
    }

    companion object {
        private const val PAGE = 20
        private const val MAX = 100
        private const val FAST_MAX = 100
        private const val LISTS_MAX = 30
        private const val DEFAULT_LISTS_QUERY = "playlist musique"
    }
}
