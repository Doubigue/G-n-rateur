package com.dlvibestudio.dlturbo.ui

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.lifecycleScope
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import com.dlvibestudio.dlturbo.App
import com.dlvibestudio.dlturbo.data.SettingsData
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.coroutines.coroutineContext
import java.io.ByteArrayInputStream
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Télécharge une liste d'épisodes (1 → N) sur les sites de streaming : chaque page d'épisode est ouverte
 * à tour de rôle dans un navigateur invisible, la lecture est lancée en sourdine, le flux vidéo qui passe
 * (HLS, DASH, mp4) est repéré puis mis dans la file de téléchargement.
 */
class EpisodeCrawler(
    private val activity: ComponentActivity,
    private val app: App,
    private val blocker: AdBlocker,
) {
    data class State(
        val total: Int,
        val done: Int,
        val added: Int,
        val failed: List<String>,
        val current: String,
        val running: Boolean,
    )

    val state = mutableStateOf<State?>(null)

    /** Identité du navigateur selon le site (fournie par WebHub : mode compatible Cloudflare). */
    var uaFor: ((String) -> String)? = null

    private var webView: WebView? = null
    private var container: FrameLayout? = null
    private var job: Job? = null
    private val found = CopyOnWriteArrayList<MediaHit>()

    @Volatile
    private var currentPage = ""

    /** Recherche ponctuelle du flux d'une seule page en cours (feuille « Télécharger depuis cette page »). */
    @Volatile
    private var sniffing = false

    val busy: Boolean get() = sniffing || state.value?.running == true

    /**
     * Ouvre [url] dans le navigateur invisible, lance la lecture et renvoie les flux vus passer
     * (lecteurs intégrés compris). Sert quand l'extracteur ne connaît pas le site.
     */
    suspend fun sniff(url: String): List<MediaHit> {
        if (busy || !url.startsWith("http")) return emptyList()
        sniffing = true
        return try {
            ensureWebView()
            findAll(url)
        } finally {
            sniffing = false
            if (state.value?.running != true) teardown()
        }
    }

    fun start(prefix: String, items: List<EpisodeItem>, quality: String) {
        if (items.isEmpty()) return
        cancel()
        state.value = State(items.size, 0, 0, emptyList(), items.first().title, true)
        job = activity.lifecycleScope.launch {
            try {
                ensureWebView()
                var added = 0
                val failed = ArrayList<String>()
                items.forEachIndexed { index, episode ->
                    state.value = State(items.size, index, added, failed.toList(), episode.title, true)
                    val hit = findStream(episode.url)
                    if (hit != null) {
                        val cookie = CookieManager.getInstance().getCookie(hit.url) ?: ""
                        val title = listOf(prefix, episode.title).filter { it.isNotBlank() }.joinToString(" - ")
                        // Comme MyDM : la taille est mesurée AVANT de mettre l'épisode dans la file, pour qu'elle reste
                        // la même pendant tout le téléchargement (sinon elle serait recalculée à chaque mise à jour).
                        val expected = runCatching {
                            val a = StreamProbe.analyze(app.manager.http.client, listOf(hit), SettingsData.DEFAULT_UA)
                            val h = quality.toIntOrNull()
                            val v = if (h != null) a.videos.firstOrNull { it.height in 1..h } ?: a.videos.firstOrNull() else a.videos.firstOrNull()
                            v?.sizeBytes ?: 0L
                        }.getOrDefault(0L)
                        app.manager.enqueueStream(hit.url, hit.referer, cookie, title, quality, if (quality == "mp3" || quality == "audio" || quality == "m4a" || quality == "wav") 0 else expected)
                        added++
                    } else {
                        failed.add(episode.title)
                    }
                    delay(400)
                }
                state.value = State(items.size, items.size, added, failed, "", false)
            } finally {
                // Seule la tâche en cours nettoie ; une tâche annulée a déjà été nettoyée par cancel().
                if (job === coroutineContext[Job]) teardown()
            }
        }
    }

    fun cancel() {
        job?.cancel()
        job = null
        teardown()
        state.value = null
    }

    fun dismiss() {
        if (state.value?.running != true) state.value = null
    }

    private suspend fun findStream(url: String): MediaHit? = MediaSniffer.pick(findAll(url))

    private suspend fun findAll(url: String): List<MediaHit> {
        val w = webView ?: return emptyList()
        found.clear()
        currentPage = url
        val ua = uaFor?.invoke(url)
        ua?.let { if (w.settings.userAgentString != it) w.settings.userAgentString = it }

        // 1) Lecture directe de la page et de ses lecteurs (aucune lecture vidéo nécessaire).
        val quick = runCatching {
            PageExtractor.extract(app.manager.http.client, url, ua ?: w.settings.userAgentString)
        }.getOrDefault(emptyList())
        if (MediaSniffer.pick(quick) != null) {
            w.loadUrl("about:blank")
            return quick
        }

        // 2) Navigateur invisible : la lecture est lancée à la place de l'utilisateur (vrais appuis sur le lecteur).
        w.loadUrl(url)
        val start = System.currentTimeMillis()
        var firstAt = 0L
        var lastTap = 0L
        while (System.currentTimeMillis() - start < TIMEOUT_MS) {
            delay(300)
            val now = System.currentTimeMillis()
            if (found.isEmpty() && now - start > 2_500 && now - lastTap > 1_600) {
                lastTap = now
                tapPlayer(w)
            }
            if (found.isNotEmpty()) {
                if (firstAt == 0L) firstAt = now
                // On laisse un instant pour voir passer la liste principale (HLS maître) après un éventuel premier flux.
                if (now - firstAt > SETTLE_MS) break
            }
        }
        w.stopLoading()
        val hits = found.toList()
        w.loadUrl("about:blank")
        return hits
    }

    /**
     * Appui réel (« de confiance » pour la page) au centre du lecteur : beaucoup de lecteurs ignorent un clic
     * simulé par script. Le premier appui sert parfois à fermer un calque publicitaire, le suivant lance la lecture.
     */
    private fun tapPlayer(w: WebView) {
        w.evaluateJavascript(PLAYER_JS) { raw ->
            val r = raw?.trim('"').orEmpty()
            val p = r.split(',')
            if (p.size < 3) return@evaluateJavascript
            val cx = p[0].toFloatOrNull() ?: return@evaluateJavascript
            val cy = p[1].toFloatOrNull() ?: return@evaluateJavascript
            val vw = p[2].toFloatOrNull()?.takeIf { it > 0f } ?: return@evaluateJavascript
            val scale = w.width / vw
            val x = cx * scale
            val y = cy * scale
            val t = SystemClock.uptimeMillis()
            val down = MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, x, y, 0)
            val up = MotionEvent.obtain(t, t + 70, MotionEvent.ACTION_UP, x, y, 0)
            runCatching {
                w.dispatchTouchEvent(down)
                w.dispatchTouchEvent(up)
            }
            down.recycle()
            up.recycle()
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun ensureWebView() {
        if (webView != null) return
        val wv = WebView(activity)
        with(wv.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            setSupportMultipleWindows(false)
            javaScriptCanOpenWindowsAutomatically = false
            allowFileAccess = false
            allowContentAccess = false
            userAgentString = runCatching {
                android.webkit.WebSettings.getDefaultUserAgent(activity)
                    .replace("; wv)", ")").replace(Regex("""\sVersion/\d+\.\d+"""), "")
            }.getOrDefault(SettingsData.DEFAULT_UA)
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
        wv.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val uri = request.url
                val pageHost = runCatching { Uri.parse(currentPage).host }.getOrNull()
                if (app.settings.value.blockAds && (
                        blocker.shouldBlock(uri, pageHost) || AdRules.isAdHost(uri.host) || AdRules.isGamblingHost(uri.host) ||
                            (!request.isForMainFrame && AdRules.looksLikeAdResource(uri))
                        )
                ) {
                    return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                }
                val kind = MediaSniffer.classify(uri)
                val u = uri.toString()
                if (kind != null && !MediaSniffer.noisy(u)) {
                    val referer = request.requestHeaders?.get("Referer")?.takeIf { it.isNotBlank() } ?: currentPage
                    found.add(MediaHit(u, kind, referer))
                }
                return null
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (!request.isForMainFrame) return false
                if (request.isRedirect) return false
                val to = request.url.host
                val from = runCatching { Uri.parse(currentPage).host }.getOrNull()
                // La page d'épisode reste sur son site ; tout saut vers ailleurs (publicité) est ignoré.
                return !(to != null && from != null && site(to) == site(from))
            }

            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                    view.evaluateJavascript(Cloudflare.guard(StrictSites.JS), null)
                    view.evaluateJavascript(Cloudflare.guard(AdGuard.JS), null)
                    view.evaluateJavascript(Cloudflare.guard(MediaSniffer.AUTOPLAY_SCRIPT), null)
                }
            }
        }
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            runCatching { WebViewCompat.addDocumentStartJavaScript(wv, Cloudflare.guard(StrictSites.JS), setOf("*")) }
            runCatching { WebViewCompat.addDocumentStartJavaScript(wv, Cloudflare.guard(AdGuard.JS), setOf("*")) }
            runCatching { WebViewCompat.addDocumentStartJavaScript(wv, Cloudflare.guard(MediaSniffer.AUTOPLAY_SCRIPT), setOf("*")) }
        }

        // Presque invisible mais « affiché » : certains lecteurs ne démarrent pas hors de l'écran.
        // Le conteneur laisse passer les appuis vers l'application située dessous.
        val density = activity.resources.displayMetrics.density
        val frame = PassThroughFrame(activity)
        frame.alpha = 0.02f
        val vwPx = minOf(activity.resources.displayMetrics.widthPixels, (412 * density).toInt())
        val vhPx = (640 * density).toInt()
        frame.addView(wv, FrameLayout.LayoutParams(vwPx, vhPx))
        val decor = activity.window.decorView as FrameLayout
        decor.addView(frame, FrameLayout.LayoutParams(vwPx, vhPx, Gravity.BOTTOM or Gravity.START))
        webView = wv
        container = frame
    }

    private fun teardown() {
        runCatching {
            container?.let { (it.parent as? ViewGroup)?.removeView(it) }
            webView?.stopLoading()
            webView?.destroy()
        }
        webView = null
        container = null
    }

    private fun site(host: String): String {
        val parts = host.lowercase().split('.')
        return if (parts.size <= 2) host.lowercase() else parts.takeLast(2).joinToString(".")
    }

    private class PassThroughFrame(context: Context) : FrameLayout(context) {
        override fun dispatchTouchEvent(ev: MotionEvent?): Boolean = false
    }

    companion object {
        /** Centre du plus grand lecteur de la page (« x,y,largeur de page »), après l'avoir fait défiler dans l'écran. */
        private const val PLAYER_JS = """
(function(){
  var best = null, ba = 0;
  var els = document.querySelectorAll('video,iframe');
  for (var i = 0; i < els.length; i++) {
    var r = els[i].getBoundingClientRect();
    if (r.width < 200 || r.height < 110) continue;
    var s = (els[i].src || '').toLowerCase();
    if (/captcha|turnstile|doubleclick|googlesyndication|\/ads?\//.test(s)) continue;
    var a = r.width * r.height;
    if (a > ba) { ba = a; best = r; }
  }
  if (!best) return '';
  if (best.bottom < 0 || best.top > innerHeight - 40) {
    window.scrollTo(0, Math.max(0, best.top + (window.scrollY || 0) - innerHeight / 4));
    return '';
  }
  return Math.round(best.left + best.width / 2) + ',' + Math.round(best.top + best.height / 2) + ',' + innerWidth;
})();
"""
        private const val TIMEOUT_MS = 28_000L
        private const val SETTLE_MS = 1_800L
    }
}
