package com.dlvibestudio.dlturbo.service

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.dlvibestudio.dlturbo.App
import com.dlvibestudio.dlturbo.R
import com.dlvibestudio.dlturbo.data.DownloadItem
import com.dlvibestudio.dlturbo.ui.MainActivity
import com.dlvibestudio.dlturbo.util.Format

/** Widget d'écran d'accueil : nombre de téléchargements, vitesse, avancement du premier, bouton « Coller ». */
class DownloadsWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val items = runCatching { (context.applicationContext as App).manager.repo.items.value }.getOrDefault(emptyList())
        render(context, manager, ids, items)
    }

    companion object {
        private var lastKey = ""

        /** Appelé par le gestionnaire quand la liste change (au plus toutes les 2 s). */
        fun refresh(context: Context, items: List<DownloadItem>) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = runCatching {
                manager.getAppWidgetIds(ComponentName(context, DownloadsWidget::class.java))
            }.getOrNull() ?: return
            if (ids.isEmpty()) return
            render(context, manager, ids, items)
        }

        private fun render(context: Context, manager: AppWidgetManager, ids: IntArray, items: List<DownloadItem>) {
            val active = items.filter { it.status.isActive }
            val speed = active.sumOf { it.speed }
            val first = active.firstOrNull()
            val status = when {
                active.isEmpty() -> "Aucun téléchargement en cours"
                else -> "${active.size} en cours · ${Format.speed(speed)}"
            }
            val pct = first?.let {
                when {
                    it.totalBytes > 0 -> (it.downloadedBytes * 100 / it.totalBytes).toInt()
                    it.percent >= 0f -> it.percent.toInt()
                    else -> 0
                }
            }?.coerceIn(0, 100) ?: 0
            val key = "$status|${first?.fileName}|$pct|${active.size}|${items.size}"
            if (key == lastKey) return
            lastKey = key

            val views = RemoteViews(context.packageName, R.layout.widget_downloads)
            views.setTextViewText(R.id.widget_status, status)
            views.setTextViewText(
                R.id.widget_title,
                first?.let { "${it.fileName} · $pct %" } ?: "${items.count { it.status.name == "COMPLETED" }} terminé(s) · touchez pour ouvrir",
            )
            views.setProgressBar(R.id.widget_progress, 100, pct, first != null && first.totalBytes <= 0 && first.percent < 0f)
            views.setTextViewText(R.id.widget_more, if (active.size > 1) "+ ${active.size - 1} autre(s)" else "")

            val open = PendingIntent.getActivity(
                context, 10, Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
            val paste = PendingIntent.getActivity(
                context, 11,
                Intent(context, MainActivity::class.java).setAction(MainActivity.ACTION_PASTE)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
            views.setOnClickPendingIntent(R.id.widget_root, open)
            views.setOnClickPendingIntent(R.id.widget_paste, paste)
            runCatching { manager.updateAppWidget(ids, views) }
        }
    }
}
