package com.dlvibestudio.dlturbo.ui

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.dlvibestudio.dlturbo.App
import com.dlvibestudio.dlturbo.data.DlStatus
import com.dlvibestudio.dlturbo.data.DownloadItem
import com.dlvibestudio.dlturbo.engine.TorrentEngine
import com.dlvibestudio.dlturbo.util.Format
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File

/** Tri « naturel » : Épisode 2 avant Épisode 10. */
private fun naturalKey(s: String): String =
    Regex("""\d+""").replace(s.lowercase()) { it.value.padStart(6, '0') }

/**
 * Épisodes (fichiers) d'un torrent, affichés directement dans l'onglet Téléchargements :
 * avancement de chacun, pause / reprise épisode par épisode, lecture (même partielle).
 */
@Composable
internal fun TorrentEpisodes(app: App, item: DownloadItem) {
    val context = LocalContext.current
    val files by produceState(emptyList<TorrentEngine.TorrentFile>(), item.id, item.fileName) {
        while (value.isEmpty()) {
            value = withContext(Dispatchers.IO) { app.manager.torrents.files(item.id) }
            if (value.isEmpty()) delay(2000)
        }
    }
    val active = item.status.isActive
    val live by produceState<TorrentEngine.Live?>(null, item.id, active) {
        while (active) {
            value = withContext(Dispatchers.IO) { app.manager.torrents.live(item.id) }
            delay(1000)
        }
    }
    val skip = remember(item.ignored) { item.ignored.split(',').mapNotNull { it.trim().toIntOrNull() }.toSet() }

    if (files.isEmpty()) {
        Text(
            "La liste des épisodes apparaît dès que les métadonnées du torrent sont reçues…",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
        )
        return
    }
    val shown = remember(files) { files.sortedBy { naturalKey(it.path) } }

    fun setWanted(f: TorrentEngine.TorrentFile, wanted: Boolean) {
        val after = if (wanted) skip - f.index else skip + f.index
        if (!wanted && after.size >= files.size) {
            // Tous les épisodes en pause : c'est le torrent entier qui se met en pause.
            app.manager.pause(item.id)
            return
        }
        app.manager.torrents.setFileWanted(item.id, f.index, wanted)
        if (wanted && !item.status.isActive) app.manager.restartTorrent(item.id)
    }

    Column(Modifier.fillMaxWidth().padding(bottom = 6.dp)) {
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "${files.size} fichier(s)" + if (skip.isNotEmpty()) " · ${skip.size} en pause" else "",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f),
            )
            TextButton(onClick = {
                skip.forEach { app.manager.torrents.setFileWanted(item.id, it, true) }
                if (!item.status.isActive) app.manager.restartTorrent(item.id)
            }) { Text("Tout reprendre") }
            if (item.status.isActive) {
                TextButton(onClick = { app.manager.pause(item.id) }) { Text("Tout en pause") }
            }
        }
        shown.forEach { f ->
            val wanted = f.index !in skip
            val got = live?.fileProgress?.getOrNull(f.index)
                ?: if (item.status == DlStatus.COMPLETED && wanted) f.size else -1L
            val frac = if (f.size > 0 && got >= 0) (got.toFloat() / f.size).coerceIn(0f, 1f) else 0f
            val disk = File(item.dir, f.path)
            val isCurrent = active && app.manager.torrents.currentEpisodeOf(item.id) == f.index
            val state = when {
                !wanted -> "En pause · " + Format.bytes(f.size)
                isCurrent && got in 0 until f.size -> "▶ En cours · ${Format.bytes(got)} / ${Format.bytes(f.size)} · ${(frac * 100).toInt()} %"
                got >= f.size && f.size > 0 -> "Terminé · " + Format.bytes(f.size)
                got >= 0 -> "${Format.bytes(got)} / ${Format.bytes(f.size)} · ${(frac * 100).toInt()} %"
                item.status == DlStatus.PAUSED -> "Torrent en pause · " + Format.bytes(f.size)
                else -> Format.bytes(f.size)
            }
            Row(
                Modifier.fillMaxWidth()
                    .clickable { openEpisode(context, app, disk) }
                    .padding(start = 4.dp, end = 4.dp, top = 2.dp, bottom = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = { setWanted(f, !wanted) }) {
                    Icon(
                        if (wanted) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = if (wanted) "Mettre cet épisode en pause" else "Reprendre cet épisode",
                        tint = if (wanted) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.primary,
                    )
                }
                Column(Modifier.weight(1f)) {
                    Text(
                        f.path.substringAfterLast('/'),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (wanted) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text(state, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (wanted && got >= 0 && frac < 1f) {
                        LinearProgressIndicator(
                            progress = { frac },
                            modifier = Modifier.fillMaxWidth().padding(top = 3.dp).height(3.dp),
                        )
                    }
                }
                if (FileKinds.isMedia(disk)) {
                    IconButton(onClick = { openEpisode(context, app, disk) }) {
                        Icon(
                            Icons.Filled.PlayCircle,
                            contentDescription = "Lire",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(26.dp),
                        )
                    }
                }
            }
        }
    }
}

/** Ouvre un épisode, même incomplet (lecture de la partie déjà reçue). */
private fun openEpisode(context: android.content.Context, app: App, disk: File) {
    when {
        !disk.isFile || disk.length() == 0L -> Toast.makeText(
            context, "Cet épisode n'a pas encore commencé à arriver", Toast.LENGTH_SHORT,
        ).show()
        FileKinds.isMedia(disk) -> app.viewer.value = ViewerRequest.Media(listOf(disk), 0)
        else -> FileOpener.open(context, app, disk)
    }
}
