package com.dlvibestudio.dlturbo.ui

import android.webkit.CookieManager
import com.dlvibestudio.dlturbo.engine.Links
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

/** Une qualité téléchargeable repérée dans une page : « 720p · MP4 · ~540 Mo ». */
data class StreamVariant(
    /** Adresse à télécharger (liste HLS de cette qualité, ou fichier). */
    val url: String,
    /** Hauteur de l'image en pixels (0 = inconnue). */
    val height: Int,
    /** Débit en bits/s (0 = inconnu). */
    val bandwidth: Long,
    /** Taille estimée en octets (0 = inconnue). */
    val sizeBytes: Long,
    /** HLS, DASH, MP4, WEBM… */
    val container: String,
    val referer: String,
) {
    val isStream: Boolean get() = container == "HLS" || container == "DASH"
    val host: String get() = Links.hostOf(url)
    val label: String
        get() = when {
            height >= 2160 -> "2160p (4K)"
            height >= 1440 -> "1440p (2K)"
            height >= 1080 -> "${height}p (Full HD)"
            height >= 720 -> "${height}p (HD)"
            height > 0 -> "${height}p"
            else -> "Qualité d'origine"
        }
}

data class StreamAnalysis(
    val durationSec: Long,
    /** Qualités vidéo, de la meilleure à la plus faible. */
    val videos: List<StreamVariant>,
    /** Source utilisée pour extraire l'audio (fichier audio, ou la qualité vidéo la plus légère). */
    val audioSource: StreamVariant?,
) {
    /** Tailles audio estimées (MP3 ≈ 192 kb/s, M4A ≈ 128 kb/s, WAV 16 bits stéréo 44,1 kHz). */
    fun audioSize(format: String): Long {
        if (durationSec <= 0) return 0
        return when (format) {
            "mp3" -> durationSec * 24_000
            "m4a" -> durationSec * 16_000
            "wav" -> durationSec * 176_400
            else -> 0
        }
    }
}

/**
 * Lit les flux repérés dans une page (listes HLS maître / de lecture, fichiers MP4…) pour proposer
 * chaque qualité avec sa taille, sans rien télécharger d'autre que les listes et quelques en-têtes.
 */
object StreamProbe {

    suspend fun analyze(client: OkHttpClient, hits: List<MediaHit>, ua: String): StreamAnalysis =
        withContext(Dispatchers.IO) {
            val c = client.newBuilder()
                .callTimeout(20, TimeUnit.SECONDS)
                .followRedirects(true)
                .build()
            val videos = ArrayList<StreamVariant>()
            val seen = HashSet<String>()
            var duration = 0L
            var audioFile: StreamVariant? = null

            // Listes HLS : on lit d'abord les maîtres, pour ignorer ensuite leurs sous-listes déjà comptées.
            val hls = hits.filter { it.kind == "HLS" }.mapNotNull { h ->
                val text = fetchText(c, h.url, h.referer, ua) ?: return@mapNotNull null
                Triple(h, text, text.contains("#EXT-X-STREAM-INF"))
            }.sortedByDescending { it.third }

            for ((hit, text, master) in hls) {
                if (key(hit.url) in seen) continue
                seen.add(key(hit.url))
                if (master) {
                    val variants = parseMaster(hit.url, text)
                    if (variants.isEmpty()) continue
                    // Durée : lue sur la sous-liste la plus légère.
                    val lightest = variants.minByOrNull { if (it.bandwidth > 0) it.bandwidth else Long.MAX_VALUE }!!
                    val media = fetchText(c, lightest.url, hit.referer, ua)
                    val dur = media?.let { mediaDuration(it) } ?: 0.0
                    if (dur > 0) duration = maxOf(duration, dur.toLong())
                    for (v in variants) {
                        if (!seen.add(key(v.url))) continue
                        // Le débit « BANDWIDTH » d'une liste HLS est un débit de POINTE : il surestime souvent la taille
                        // de 2 à 20 fois. Ordre de confiance : débit moyen annoncé > mesure sur quelques morceaux > pointe × 0,6.
                        var size = if (v.averaged && v.bandwidth > 0 && dur > 0) (v.bandwidth * dur / 8).toLong() else 0L
                        if (size <= 0) {
                            val t = if (v.url == lightest.url) media else fetchText(c, v.url, hit.referer, ua)
                            if (t != null) size = mediaSize(c, v.url, t, hit.referer, ua)
                        }
                        if (size <= 0 && v.bandwidth > 0 && dur > 0) size = (v.bandwidth * dur / 8 * 0.6).toLong()
                        videos.add(StreamVariant(v.url, v.height, v.bandwidth, size, "HLS", hit.referer))
                    }
                } else {
                    val dur = mediaDuration(text)
                    if (dur > 0) duration = maxOf(duration, dur.toLong())
                    val size = mediaSize(c, hit.url, text, hit.referer, ua)
                    val bw = if (size > 0 && dur > 0) (size * 8 / dur).toLong() else 0L
                    videos.add(StreamVariant(hit.url, heightIn(hit.url), bw, size, "HLS", hit.referer))
                }
            }

            for (hit in hits) {
                if (hit.kind == "HLS" || !seen.add(key(hit.url))) continue
                when {
                    hit.kind == "DASH" -> videos.add(StreamVariant(hit.url, heightIn(hit.url), 0, 0, "DASH", hit.referer))
                    hit.isAudio -> if (audioFile == null) {
                        audioFile = StreamVariant(hit.url, 0, 0, length(c, hit.url, hit.referer, ua), hit.kind, hit.referer)
                    }
                    else -> videos.add(
                        StreamVariant(hit.url, heightIn(hit.url), 0, length(c, hit.url, hit.referer, ua), hit.kind, hit.referer)
                    )
                }
            }

            val sorted = videos.sortedWith(compareByDescending<StreamVariant> { it.height }.thenByDescending { it.sizeBytes })
            val audio = audioFile
                ?: sorted.filter { it.isStream }.minByOrNull { if (it.sizeBytes > 0) it.sizeBytes else Long.MAX_VALUE }
                ?: sorted.lastOrNull()
            StreamAnalysis(duration, sorted, audio)
        }

    // ------------------------------------------------------------------ HLS

    private data class Variant(val url: String, val height: Int, val bandwidth: Long, val averaged: Boolean)

    private fun parseMaster(base: String, text: String): List<Variant> {
        val lines = text.lines().map { it.trim() }
        val out = ArrayList<Variant>()
        for (i in lines.indices) {
            val line = lines[i]
            if (!line.startsWith("#EXT-X-STREAM-INF")) continue
            val attrs = line.substringAfter(':', "")
            val avg = attr(attrs, "AVERAGE-BANDWIDTH")?.toLongOrNull()
            val bw = avg ?: attr(attrs, "BANDWIDTH")?.toLongOrNull() ?: 0L
            val height = attr(attrs, "RESOLUTION")?.substringAfter('x', "")?.toIntOrNull() ?: 0
            val uri = lines.subList(i + 1, lines.size).firstOrNull { it.isNotEmpty() && !it.startsWith("#") } ?: continue
            val abs = resolve(base, uri) ?: continue
            out.add(Variant(abs, height.takeIf { it > 0 } ?: heightIn(abs), bw, avg != null))
        }
        // Même qualité proposée deux fois (serveurs de secours) : on garde la première.
        return out.distinctBy { "${it.height}/${it.bandwidth}" }
    }

    private fun attr(attrs: String, name: String): String? =
        Regex("""(?:^|,)$name=("?)([^",]*)\1""").find(attrs)?.groupValues?.get(2)

    private fun mediaDuration(text: String): Double =
        Regex("""#EXTINF:\s*([\d.]+)""").findAll(text).sumOf { it.groupValues[1].toDoubleOrNull() ?: 0.0 }

    /** Taille d'une liste de lecture HLS : exacte si elle donne les plages d'octets, sinon d'après quelques segments. */
    private fun mediaSize(c: OkHttpClient, url: String, text: String, referer: String, ua: String): Long {
        val ranges = Regex("""#EXT-X-BYTERANGE:\s*(\d+)""").findAll(text).sumOf { it.groupValues[1].toLong() }
        if (ranges > 0) return ranges
        // Segments avec leur durée (#EXTINF). Le dernier est presque toujours plus court : il fausserait la moyenne.
        val segs = ArrayList<Pair<String, Double>>()
        var pending = 0.0
        for (raw in text.lines()) {
            val line = raw.trim()
            if (line.startsWith("#EXTINF:")) pending = line.removePrefix("#EXTINF:").substringBefore(',').trim().toDoubleOrNull() ?: 0.0
            else if (line.isNotEmpty() && !line.startsWith("#")) { segs.add(line to pending); pending = 0.0 }
        }
        if (segs.isEmpty()) return 0
        val totalDur = segs.sumOf { it.second }
        // Comme MyDM : on évite le tout début et la toute fin (générique, dernier morceau court) et on mesure
        // jusqu'à 10 morceaux répartis entre 10 % et 90 % de la vidéo.
        val margin = segs.size / 10
        val pool = if (segs.size > 10) segs.subList(margin, segs.size - margin) else segs
        val count = minOf(10, pool.size)
        val picks = (0 until count).map { k -> if (count == 1) 0 else k * (pool.size - 1) / (count - 1) }.distinct()
        var bytes = 0L
        var secs = 0.0
        var counted = 0
        for (i in picks) {
            val n = resolve(url, pool[i].first)?.let { length(c, it, referer, ua) }?.takeIf { it > 0 } ?: continue
            bytes += n
            secs += pool[i].second
            counted++
        }
        if (counted == 0) return 0
        // Octets par seconde mesurés × durée totale ; à défaut de durées, moyenne par morceau × nombre de morceaux.
        return if (secs > 0 && totalDur > 0) (bytes / secs * totalDur).toLong() else bytes / counted * segs.size
    }

    // ------------------------------------------------------------------ HTTP

    private fun request(url: String, referer: String, ua: String): Request.Builder {
        val b = Request.Builder().url(url).header("User-Agent", ua).header("Accept", "*/*")
        if (referer.startsWith("http")) {
            b.header("Referer", referer)
            referer.toHttpUrlOrNull()?.let { b.header("Origin", "${it.scheme}://${it.host}" + if (it.port != 80 && it.port != 443) ":${it.port}" else "") }
        }
        runCatching { CookieManager.getInstance().getCookie(url) }.getOrNull()
            ?.takeIf { it.isNotBlank() }?.let { b.header("Cookie", it) }
        return b
    }

    private fun fetchText(c: OkHttpClient, url: String, referer: String, ua: String): String? = runCatching {
        c.newCall(request(url, referer, ua).build()).execute().use { r ->
            if (!r.isSuccessful) return@use null
            val body = r.body ?: return@use null
            if (body.contentLength() > 8_000_000) return@use null
            body.string().takeIf { it.trimStart().startsWith("#EXTM3U") }
        }
    }.getOrNull()

    /** Taille d'un fichier : en-tête Content-Length (HEAD), sinon demande du premier octet (Content-Range). */
    private fun length(c: OkHttpClient, url: String, referer: String, ua: String): Long {
        runCatching {
            c.newCall(request(url, referer, ua).head().build()).execute().use { r ->
                val n = r.header("Content-Length")?.toLongOrNull() ?: 0
                if (r.isSuccessful && n > 0) return n
            }
        }
        runCatching {
            c.newCall(request(url, referer, ua).header("Range", "bytes=0-0").build()).execute().use { r ->
                val total = r.header("Content-Range")?.substringAfter('/', "")?.toLongOrNull() ?: 0
                if (total > 0) return total
                val n = r.header("Content-Length")?.toLongOrNull() ?: 0
                if (r.code == 200 && n > 1) return n
            }
        }
        return 0
    }

    private fun resolve(base: String, ref: String): String? =
        base.toHttpUrlOrNull()?.resolve(ref.trim())?.toString()

    private fun key(url: String) = url.substringBefore('?').substringBefore('#')

    private fun heightIn(url: String): Int =
        Regex("""(?i)(?:^|[^\d])(2160|1440|1080|720|576|480|360|240)p?(?:[^\d]|$)""").find(url)?.groupValues?.get(1)?.toIntOrNull() ?: 0
}
