package com.dlvibestudio.dlturbo.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.dlvibestudio.dlturbo.App
import com.dlvibestudio.dlturbo.data.DlStatus
import com.dlvibestudio.dlturbo.data.DlType
import com.dlvibestudio.dlturbo.data.DownloadItem
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel

/**
 * Transfert de téléchargements d'un téléphone à l'autre par QR code : l'un affiche, l'autre scanne
 * (menu ⋮ → « Scanner un QR code »). Chaque QR est autonome : on peut les scanner dans n'importe quel ordre.
 * Format : « TDL1 page/total » puis une ligne par téléchargement « type<TAB>qualité<TAB>adresse ».
 */
object QrTransfer {
    private const val HEADER = "TDL1"
    private const val MAX_CHARS = 1500 // au-delà, le QR devient trop dense pour une caméra moyenne

    fun isOurs(text: String?) = text?.startsWith(HEADER) == true

    fun payloads(items: List<DownloadItem>): List<String> {
        val lines = items.mapNotNull { item ->
            val url = item.url.trim()
            if (!(url.startsWith("http") || url.startsWith("magnet:"))) return@mapNotNull null
            val type = if (item.type == DlType.VIDEO) "V" else "U"
            "$type\t${item.quality.replace('\t', ' ')}\t$url"
        }.distinct()
        if (lines.isEmpty()) return emptyList()
        val pages = ArrayList<MutableList<String>>()
        var cur = ArrayList<String>()
        var size = 0
        for (l in lines) {
            if (l.length > MAX_CHARS) continue // lien démesuré : ignoré
            if (size + l.length + 1 > MAX_CHARS && cur.isNotEmpty()) {
                pages.add(cur); cur = ArrayList(); size = 0
            }
            cur.add(l); size += l.length + 1
        }
        if (cur.isNotEmpty()) pages.add(cur)
        return pages.mapIndexed { i, p -> "$HEADER ${i + 1}/${pages.size}\n" + p.joinToString("\n") }
    }

    /** Ajoute les téléchargements d'un QR scanné ; renvoie le nombre ajouté. */
    fun import(app: App, text: String): Int {
        var n = 0
        val known = app.manager.repo.items.value.map { it.url }.toHashSet()
        text.lines().drop(1).forEach { line ->
            val parts = line.split('\t')
            if (parts.size < 3) return@forEach
            val url = parts[2].trim()
            if (url.isBlank() || url in known) return@forEach
            if (parts[0] == "V") app.manager.enqueueVideo(url, parts[1].ifBlank { "best" })
            else app.manager.enqueue(url, parts[1])
            known.add(url)
            n++
        }
        return n
    }

    fun bitmap(text: String, size: Int = 720): Bitmap {
        val hints = mapOf(
            EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.L,
            EncodeHintType.CHARACTER_SET to "UTF-8",
            EncodeHintType.MARGIN to 1,
        )
        val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size, hints)
        val w = m.width
        val h = m.height
        val px = IntArray(w * h)
        for (y in 0 until h) for (x in 0 until w) px[y * w + x] = if (m.get(x, y)) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }
}

/** Affiche les QR codes à scanner avec l'autre téléphone. */
@Composable
fun QrShareDialog(app: App, onDismiss: () -> Unit) {
    val all = app.manager.repo.items.value
    var onlyPending by remember { mutableStateOf(all.any { it.status != DlStatus.COMPLETED }) }
    val chosen = if (onlyPending) all.filter { it.status != DlStatus.COMPLETED } else all
    val pages = remember(onlyPending) { QrTransfer.payloads(chosen) }
    var page by remember(onlyPending) { mutableIntStateOf(0) }
    val bmp = remember(pages, page) { pages.getOrNull(page)?.let { runCatching { QrTransfer.bitmap(it) }.getOrNull() } }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Transférer vers un autre téléphone") },
        text = {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = onlyPending, onClick = { onlyPending = true }, label = { Text("Non terminés") })
                    FilterChip(selected = !onlyPending, onClick = { onlyPending = false }, label = { Text("Tous") })
                }
                if (bmp == null) {
                    Text(
                        "Aucun téléchargement transférable (seuls les liens web et magnet passent par QR code).",
                        modifier = Modifier.padding(top = 16.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    Box(
                        Modifier.padding(top = 12.dp).fillMaxWidth().aspectRatio(1f)
                            .clip(RoundedCornerShape(12.dp)).background(Color.White).padding(8.dp),
                    ) {
                        Image(
                            bmp.asImageBitmap(), contentDescription = "QR code",
                            filterQuality = FilterQuality.None, modifier = Modifier.fillMaxWidth().aspectRatio(1f),
                        )
                    }
                    Text(
                        "Sur l'autre téléphone : Turbo Download → menu ⋮ → « Scanner un QR code »." +
                            if (pages.size > 1) "\nQR ${page + 1} sur ${pages.size} : scannez-les tous." else "",
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 8.dp),
                    )
                }
            }
        },
        confirmButton = {
            if (pages.size > 1 && page < pages.size - 1) {
                TextButton(onClick = { page++ }) { Text("QR suivant") }
            } else {
                TextButton(onClick = onDismiss) { Text("Terminé") }
            }
        },
        dismissButton = {
            if (page > 0) TextButton(onClick = { page-- }) { Text("Précédent") }
        },
    )
}
