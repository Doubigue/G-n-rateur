@file:OptIn(ExperimentalMaterial3Api::class)

package com.dlvibestudio.dlturbo.ui

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.dlvibestudio.dlturbo.App

/**
 * Liste de téléchargement : les vidéos cochées avec « + » ; un format choisi ici s'applique à toutes
 * et lance les téléchargements d'un coup.
 */
@Composable
internal fun CartSheet(app: App, yt: YtModel) {
    val context = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    val sheet = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    fun start(key: String) {
        val items = yt.cart.toList()
        if (items.isEmpty()) return
        items.forEach { app.manager.enqueueVideo(it.url, key, false, it.title) }
        Toast.makeText(context, "${items.size} téléchargement(s) ajouté(s)", Toast.LENGTH_SHORT).show()
        yt.cart.clear()
        yt.cartOpen = false
    }

    ModalBottomSheet(onDismissRequest = { yt.cartOpen = false }, sheetState = sheet) {
        Column(Modifier.navigationBarsPadding().padding(bottom = 12.dp)) {
            Text(
                "Liste de téléchargement (${yt.cart.size})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
            )
            if (yt.cart.isEmpty()) {
                Text(
                    "La liste est vide.",
                    modifier = Modifier.padding(20.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            } else {
                Column(Modifier.heightIn(max = 200.dp).verticalScroll(rememberScrollState())) {
                    yt.cart.toList().forEach { e ->
                        Row(
                            Modifier.fillMaxWidth().padding(start = 20.dp, end = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                        ) {
                            Text(
                                e.title,
                                modifier = Modifier.weight(1f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            IconButton(onClick = { yt.toggleCart(e) }) {
                                Icon(Icons.Filled.Close, contentDescription = "Retirer")
                            }
                        }
                    }
                }
                HorizontalDivider()
                Text(
                    "Choisissez un format : il sera appliqué à toutes les vidéos.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp),
                )
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    FormatList(tab, { tab = it }, null, FIXED_VIDEO_CHOICES.filter { it.key != "240" }) { start(it) }
                }
                TextButton(onClick = { yt.cart.clear() }, modifier = Modifier.padding(horizontal = 12.dp)) {
                    Text("Vider la liste")
                }
            }
        }
    }
}
