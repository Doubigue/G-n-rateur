@file:OptIn(ExperimentalMaterial3Api::class)

package com.dlvibestudio.dlturbo.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PlaylistPlay
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dlvibestudio.dlturbo.App
import com.dlvibestudio.dlturbo.engine.YtEntry
import com.dlvibestudio.dlturbo.util.Format

/** Lien YouTube qui désigne une liste de lecture ou une chaîne (et non une vidéo seule). */
private fun isYoutubeListUrl(url: String): Boolean {
    if (!isYoutubeUrl(url)) return false
    return url.contains("list=") || Regex("""/(playlist|@[^/?]+|channel/|c/|user/)""").containsMatchIn(url)
}

/**
 * Onglet « Liste de lecture » (comme dans MyDM) : recherche de listes de lecture YouTube, ou collage du lien
 * d'une liste / d'une chaîne. Un appui ouvre l'écran « Sélectionné ».
 */
@Composable
internal fun ListsContent(app: App, hub: WebHub) {
    val yt = hub.yt
    LaunchedEffect(Unit) { yt.startListsIfNeeded() }

    fun go() {
        val q = yt.listsQuery.trim()
        if (q.isEmpty()) return
        if (q.startsWith("http")) {
            // Liste ou chaîne YouTube : écran « Sélectionné ». Toute autre adresse : sélecteur de formats habituel.
            if (isYoutubeListUrl(q)) yt.openSelection(q, "", 0) else hub.formatRequest.value = q
        } else {
            yt.submitLists()
        }
    }

    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = yt.listsQuery,
            onValueChange = { yt.listsQuery = it },
            placeholder = { Text("Rechercher une liste ou coller un lien") },
            singleLine = true,
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            trailingIcon = {
                if (yt.listsQuery.isNotEmpty()) {
                    IconButton(onClick = { yt.listsQuery = "" }) {
                        Icon(Icons.Filled.Close, contentDescription = "Effacer")
                    }
                }
            },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { go() }),
            shape = RoundedCornerShape(28.dp),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
        )
        if (yt.listsLoading) LinearProgressIndicator(Modifier.fillMaxWidth())

        val err = yt.listsError
        if (err != null) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                Text(err, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                if (yt.lists.isEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = { yt.retryLists() }) { Text("Réessayer") }
                }
            }
        }

        LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(bottom = 16.dp)) {
            items(yt.lists, key = { it.url }) { entry ->
                ListRow(app, entry) { yt.openPlaylist(entry) }
            }
        }
    }
}

/** Ligne compacte : miniature + nombre de vidéos + titre + ⬇. */
@Composable
private fun ListRow(app: App, entry: YtEntry, onOpen: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onOpen).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.width(120.dp).height(68.dp).clip(RoundedCornerShape(10.dp))) {
            RemoteImage(entry.thumbnail, app.manager.http.client, Modifier.fillMaxSize())
            Row(
                Modifier.align(Alignment.BottomEnd).padding(4.dp)
                    .background(Color(0xCC000000), RoundedCornerShape(4.dp))
                    .padding(horizontal = 5.dp, vertical = 1.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.PlaylistPlay, null, tint = Color.White, modifier = Modifier.size(14.dp))
                if (entry.count > 0) Text("${entry.count}", color = Color.White, fontSize = 11.sp)
            }
        }
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(
                entry.title,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
            )
            val sub = buildList {
                if (entry.channel.isNotBlank()) add(entry.channel)
                if (entry.count > 0) add("${entry.count} vidéos")
            }.joinToString(" · ")
            if (sub.isNotBlank()) {
                Text(
                    sub,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        IconButton(onClick = onOpen) {
            Icon(Icons.Filled.Download, contentDescription = "Choisir et télécharger", tint = MaterialTheme.colorScheme.primary)
        }
    }
}

/**
 * Écran « Sélectionné » (comme dans MyDM) : toutes les vidéos de la liste, cochées d'office ; « Tout sélectionner »,
 * compteur n/N, bouton FAIT → choix du format → file de téléchargement dans un dossier au nom de la liste.
 */
@Composable
internal fun SelectionScreen(app: App, yt: YtModel) {
    val count = yt.selCount
    val total = yt.selItems.size
    val all = total > 0 && count == total

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = { yt.closeSelection() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
            }
            Column(Modifier.weight(1f).padding(end = 12.dp)) {
                Text("Sélectionné", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                    yt.selTitle.orEmpty(),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        HorizontalDivider()
        if (yt.selLoading) LinearProgressIndicator(Modifier.fillMaxWidth())

        val err = yt.selError
        if (err != null) {
            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                Text(err, color = MaterialTheme.colorScheme.error)
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { yt.retrySelection() }) { Text("Réessayer") }
            }
        }

        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(yt.selItems, key = { it.url }) { entry ->
                SelectionRow(app, entry, on = yt.selChecked[entry.url] == true) { yt.toggleSel(entry) }
            }
        }

        HorizontalDivider()
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Row(
                Modifier.clickable(enabled = total > 0) { yt.toggleSelectAll() }.padding(vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                CheckCircle(all)
                Text(
                    "Tout sélectionner",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(start = 8.dp),
                )
            }
            Spacer(Modifier.weight(1f))
            Text(
                "$count/$total",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(end = 12.dp),
            )
            Button(onClick = { yt.selFormatOpen = true }, enabled = count > 0) { Text("FAIT") }
        }
    }
    if (yt.selFormatOpen) SelectionFormatSheet(yt)
}

@Composable
private fun SelectionRow(app: App, entry: YtEntry, on: Boolean, onToggle: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onToggle),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CheckCircle(on)
        Spacer(Modifier.width(10.dp))
        Box(Modifier.width(112.dp).height(64.dp).clip(RoundedCornerShape(8.dp))) {
            RemoteImage(entry.thumbnail, app.manager.http.client, Modifier.fillMaxSize())
            if (entry.durationSec > 0) {
                Text(
                    Format.clock(entry.durationSec),
                    color = Color.White,
                    fontSize = 10.sp,
                    modifier = Modifier.align(Alignment.BottomEnd).padding(3.dp)
                        .background(Color(0xCC000000), RoundedCornerShape(4.dp))
                        .padding(horizontal = 4.dp),
                )
            }
        }
        Text(
            entry.title,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.weight(1f).padding(start = 12.dp),
        )
    }
}

/** Pastille ronde : pleine avec une coche quand la vidéo est sélectionnée. */
@Composable
private fun CheckCircle(on: Boolean) {
    Box(
        Modifier.size(24.dp).clip(CircleShape).background(
            if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
        ),
        contentAlignment = Alignment.Center,
    ) {
        if (on) {
            Icon(
                Icons.Filled.Check,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.size(16.dp),
            )
        }
    }
}

/** Format commun aux vidéos cochées (même choix que la liste de téléchargement) : un appui lance tout. */
@Composable
private fun SelectionFormatSheet(yt: YtModel) {
    val context = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    val sheet = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(onDismissRequest = { yt.selFormatOpen = false }, sheetState = sheet) {
        Column(Modifier.navigationBarsPadding().padding(bottom = 12.dp).verticalScroll(rememberScrollState())) {
            Text(
                "${yt.selCount} vidéo(s)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
            )
            Text(
                "Dossier « ${yt.selTitle.orEmpty()} ». Choisissez un format : il sera appliqué à toutes les vidéos.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp),
            )
            FormatList(tab, { tab = it }, null, FIXED_VIDEO_CHOICES.filter { it.key != "240" }) { key ->
                val n = yt.downloadSelection(key)
                Toast.makeText(context, "$n téléchargement(s) ajouté(s)", Toast.LENGTH_SHORT).show()
                yt.closeSelection()
            }
        }
    }
}
