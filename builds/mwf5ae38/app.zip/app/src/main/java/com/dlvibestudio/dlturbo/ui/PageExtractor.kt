package com.dlvibestudio.dlturbo.ui

import android.net.Uri
import android.webkit.CookieManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

/**
 * Cherche le flux vidéo d'une page d'épisode SANS lancer la lecture : la page puis ses lecteurs intégrés
 * (iframes, boutons de serveurs) sont lus comme du texte, et on y repère les adresses .m3u8 / .mpd / .mp4
 * (y compris dans les scripts « packés » que beaucoup d'hébergeurs utilisent).
 *
 * Rapide (quelques requêtes) ; si rien n'est trouvé, l'appelant retombe sur le navigateur invisible.
 */
object PageExtractor {

    private const val MAX_EMBEDS = 8
    private const val MAX_BODY = 3_000_000L

    private val STREAM = Regex(
        """https?://[^\s"'<>\\)\]]+?\.(?:m3u8|mpd|mp4|webm)(?:\?[^\s"'<>\\)\]]*)?""",
        RegexOption.IGNORE_CASE,
    )

    /** Fichiers de fond de page, bandes-annonces et pubs : pas l'épisode. */
    private val SKIP = Regex("""(?i)(trailer|teaser|preview|intro|logo|sprite|thumb|poster|/ads?/|advert|preroll|banner)""")

    private val IFRAME = Regex(
        """<iframe[^>]+?(?:data-src|data-lazy-src|src)\s*=\s*["']([^"']+)["']""",
        RegexOption.IGNORE_CASE,
    )

    /** Attributs de boutons « serveur / lecteur » (data-url, data-src, data-embed, data-video, data-link…). */
    private val DATA_URL = Regex(
        """data-(?:url|embed|video|link|player|iframe|href|lien)\s*=\s*["']([^"']+)["']""",
        RegexOption.IGNORE_CASE,
    )

    /** Hébergeurs de lecteurs vidéo courants : leurs liens sont suivis même s'ils ne sont pas dans une iframe. */
    private val PLAYER_HOST = Regex(
        """(?i)(uqload|voe\.|dood|d0000d|ds2play|filemoon|streamtape|vidoza|netu|hqq\.|upstream|vidmoly|mixdrop|streamwish|lulustream|vidguard|luluvdo|sibnet|embed|player|stream)"""
    )

    private val PACKED = Regex(
        """\}\('((?:[^'\\]|\\.)*)',\s*(\d+),\s*(\d+),\s*'((?:[^'\\]|\\.)*)'\.split\('\|'\)""",
        RegexOption.DOT_MATCHES_ALL,
    )

    suspend fun extract(client: OkHttpClient, pageUrl: String, ua: String, referer: String = pageUrl): List<MediaHit> =
        withContext(Dispatchers.IO) {
            val c = client.newBuilder()
                .callTimeout(10, TimeUnit.SECONDS)
                .followRedirects(true)
                .build()
            val out = ArrayList<MediaHit>()
            val seen = HashSet<String>()
            val html = fetch(c, pageUrl, referer, ua) ?: return@withContext emptyList()
            collect(html, pageUrl, pageUrl, out, seen)

            // Lecteurs intégrés : iframes et boutons de serveurs de la page (un niveau, plus un second pour les imbriqués).
            val embeds = LinkedHashSet<String>()
            candidates(html, pageUrl).forEach { embeds.add(it) }
            val visited = HashSet<String>()
            var level = 0
            var queue: List<String> = embeds.toList()
            while (queue.isNotEmpty() && level < 2 && visited.size < MAX_EMBEDS) {
                val next = ArrayList<String>()
                for (u in queue) {
                    if (visited.size >= MAX_EMBEDS) break
                    if (!visited.add(u)) continue
                    val body = fetch(c, u, pageUrl, ua) ?: continue
                    collect(body, u, u, out, seen)
                    if (level == 0) candidates(body, u).forEach { if (it !in visited) next.add(it) }
                }
                queue = next
                level++
            }
            out
        }

    // ------------------------------------------------------------------

    /** Adresses de lecteurs à suivre dans [html]. */
    private fun candidates(html: String, base: String): List<String> {
        val list = ArrayList<String>()
        fun add(raw: String) {
            val u = absolute(base, raw.replace("&amp;", "&").replace("\\/", "/")) ?: return
            val uri = Uri.parse(u)
            val host = uri.host ?: return
            if (AdRules.isAdHost(host) || AdRules.isGamblingHost(host) || CaptchaRules.isCaptchaHost(host)) return
            if (AdRules.looksLikeAdResource(uri)) return
            if (list.none { it == u }) list.add(u)
        }
        IFRAME.findAll(html).forEach { add(it.groupValues[1]) }
        DATA_URL.findAll(html).forEach { m ->
            val v = m.groupValues[1]
            if (v.startsWith("http") || v.startsWith("//")) {
                val h = runCatching { Uri.parse(if (v.startsWith("//")) "https:$v" else v).host }.getOrNull()
                if (h != null && PLAYER_HOST.containsMatchIn(h)) add(v)
            }
        }
        return list
    }

    /** Repère les flux dans un texte (HTML, JavaScript, JavaScript « packé »). */
    private fun collect(text: String, base: String, referer: String, out: MutableList<MediaHit>, seen: MutableSet<String>) {
        val bodies = ArrayList<String>()
        bodies.add(text)
        runCatching { unpack(text) }.getOrNull()?.let { bodies.addAll(it) }
        for (b in bodies) {
            val clean = b.replace("\\/", "/").replace("\\u0026", "&").replace("&amp;", "&")
            for (m in STREAM.findAll(clean)) {
                val url = m.value
                if (!seen.add(url.substringBefore('?'))) continue
                if (MediaSniffer.noisy(url) || SKIP.containsMatchIn(url.substringAfter("://").substringBefore('?'))) continue
                val kind = MediaSniffer.classify(Uri.parse(url)) ?: continue
                out.add(MediaHit(url, kind, referer))
            }
        }
    }

    /** Décompresse les scripts « eval(function(p,a,c,k,e,d)… » (Dean Edwards packer). */
    private fun unpack(text: String): List<String> {
        if (!text.contains("eval(function(p,a,c,k,e")) return emptyList()
        val results = ArrayList<String>()
        for (m in PACKED.findAll(text)) {
            val payload = m.groupValues[1].replace("\\'", "'").replace("\\\\", "\\")
            val radix = m.groupValues[2].toIntOrNull() ?: continue
            val count = m.groupValues[3].toIntOrNull() ?: continue
            val words = m.groupValues[4].split('|')
            if (radix < 2 || count <= 0 || count > 200_000) continue
            val dict = HashMap<String, String>(count * 2)
            for (i in 0 until count) {
                val w = words.getOrNull(i) ?: ""
                dict[encode(i, radix)] = if (w.isEmpty()) encode(i, radix) else w
            }
            results.add(Regex("""\b\w+\b""").replace(payload) { dict[it.value] ?: it.value })
        }
        return results
    }

    private fun encode(n: Int, radix: Int): String {
        val head = if (n < radix) "" else encode(n / radix, radix)
        val r = n % radix
        return head + if (r > 35) (r + 29).toChar().toString() else Integer.toString(r, 36)
    }

    // ------------------------------------------------------------------ HTTP

    private fun fetch(c: OkHttpClient, url: String, referer: String, ua: String): String? = runCatching {
        val b = Request.Builder().url(url)
            .header("User-Agent", ua)
            .header("Accept", "text/html,application/xhtml+xml,*/*;q=0.8")
            .header("Accept-Language", "fr-FR,fr;q=0.9,en;q=0.7")
        if (referer.startsWith("http")) {
            b.header("Referer", referer)
        }
        runCatching { CookieManager.getInstance().getCookie(url) }.getOrNull()
            ?.takeIf { it.isNotBlank() }?.let { b.header("Cookie", it) }
        c.newCall(b.build()).execute().use { r ->
            if (!r.isSuccessful) return@use null
            val body = r.body ?: return@use null
            if (body.contentLength() > MAX_BODY) return@use null
            val type = r.header("Content-Type").orEmpty().lowercase()
            if (type.startsWith("video/") || type.startsWith("audio/") || type.contains("octet-stream")) return@use null
            body.string().take(MAX_BODY.toInt())
        }
    }.getOrNull()

    private fun absolute(base: String, ref: String): String? {
        val r = ref.trim()
        if (r.isEmpty() || r.startsWith("javascript:") || r.startsWith("about:") || r.startsWith("data:")) return null
        if (r.startsWith("//")) return "https:$r"
        return base.toHttpUrlOrNull()?.resolve(r)?.toString()?.takeIf { it.startsWith("http") }
    }
}
