package com.dlvibestudio.dlturbo.service

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import androidx.core.app.NotificationCompat
import com.dlvibestudio.dlturbo.R
import com.dlvibestudio.dlturbo.ui.MainActivity

/**
 * Fin de TOUS les téléchargements : alarme sonore (réveil le matin après une nuit de téléchargements)
 * ou proposition de couper le Wi-Fi. Android ne permet plus aux applis de couper le Wi-Fi elles-mêmes :
 * la notification ouvre directement le panneau Wi-Fi, il reste un appui à faire.
 */
object AllDone {
    private const val NOTIF_ID = 7
    private var ringtone: Ringtone? = null
    private val main = Handler(Looper.getMainLooper())

    fun trigger(context: Context, mode: String, count: Int) {
        if (mode == "none") return
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val open = PendingIntent.getActivity(
            context, 20, Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val b = NotificationCompat.Builder(context, Notifications.CH_DONE)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(0xFFF5B301.toInt())
            .setContentTitle("Tous les téléchargements sont terminés")
            .setContentText("$count fichier(s) prêt(s)")
            .setAutoCancel(true)
            .setContentIntent(open)
        if (mode == "wifi") {
            val wifi = Intent(if (Build.VERSION.SDK_INT >= 29) Settings.Panel.ACTION_WIFI else Settings.ACTION_WIFI_SETTINGS)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val pi = PendingIntent.getActivity(context, 21, wifi, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            b.setContentText("$count fichier(s) prêt(s) · appuyez pour couper le Wi-Fi")
                .setContentIntent(pi)
                .addAction(0, "Couper le Wi-Fi", pi)
        }
        if (mode == "alarm") {
            b.setContentText("$count fichier(s) prêt(s) · ouvrez l'appli pour arrêter l'alarme")
            startAlarm(context)
        }
        runCatching { nm.notify(NOTIF_ID, b.build()) }
    }

    private fun startAlarm(context: Context) {
        stopAlarm()
        val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION) ?: return
        val r = RingtoneManager.getRingtone(context, uri) ?: return
        r.audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        if (Build.VERSION.SDK_INT >= 28) r.isLooping = true
        runCatching { r.play() }
        ringtone = r
        // Arrêt automatique au bout d'une minute.
        main.postDelayed({ stopAlarm() }, 60_000)
    }

    /** Arrête l'alarme (à l'ouverture de l'appli). */
    fun stopAlarm() {
        runCatching { ringtone?.stop() }
        ringtone = null
    }
}
