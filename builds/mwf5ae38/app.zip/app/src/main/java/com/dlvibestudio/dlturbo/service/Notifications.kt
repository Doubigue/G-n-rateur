package com.dlvibestudio.dlturbo.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.os.Build
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import com.dlvibestudio.dlturbo.R
import com.dlvibestudio.dlturbo.data.DlStatus
import com.dlvibestudio.dlturbo.data.DownloadItem
import com.dlvibestudio.dlturbo.ui.MainActivity
import com.dlvibestudio.dlturbo.util.Format

object Notifications {

    const val CH_PROGRESS = "progress"
    const val CH_DONE = "done"
    const val CH_DONE_SILENT = "done_silent"
    const val SUMMARY_ID = 1
    private const val GOLD = 0xFFF5B301.toInt()

    fun createChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = context.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(
            NotificationChannel(CH_PROGRESS, "Téléchargements en cours", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Progression, pourcentage et vitesse"
                setShowBadge(false)
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_DONE, "Téléchargements terminés", NotificationManager.IMPORTANCE_DEFAULT)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_DONE_SILENT, "Téléchargements terminés (silencieux)", NotificationManager.IMPORTANCE_LOW)
        )
    }

    fun idFor(item: DownloadItem): Int = 1000 + (item.id.hashCode() and 0x0FFFFFFF)

    private fun flags() = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE

    private fun openApp(context: Context): PendingIntent = PendingIntent.getActivity(
        context, 0,
        Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
        flags(),
    )

    private fun action(context: Context, action: String, id: String?): PendingIntent {
        val intent = Intent(context, ActionReceiver::class.java).setAction(action)
        if (id != null) intent.putExtra(ActionReceiver.EXTRA_ID, id)
        val code = (action + (id ?: "")).hashCode()
        return PendingIntent.getBroadcast(context, code, intent, flags())
    }

    /** Chiffres de la session en cours (téléchargements vus depuis le démarrage du service). */
    data class Session(val total: Int, val done: Int, val failed: Int, val paused: Int, val overall: Float)

    private const val TRACK = 0x40808080
    private const val GREEN = 0xFF34C759.toInt()
    private const val RED = 0xFFEF5350.toInt()
    private const val BLUE = 0xFF64B5F6.toInt()
    private const val CARDS = 5

    /** Cercle de progression : piste grise + arc de couleur (le texte du centre est une vue, il suit le thème clair / sombre). */
    private fun ring(sizePx: Int, fraction: Float, color: Int): Bitmap {
        val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val stroke = sizePx * 0.11f
        val r = RectF(stroke / 2, stroke / 2, sizePx - stroke / 2, sizePx - stroke / 2)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = stroke
            strokeCap = Paint.Cap.ROUND
        }
        p.color = TRACK
        c.drawArc(r, 0f, 360f, false, p)
        val sweep = 360f * fraction.coerceIn(0f, 1f)
        if (sweep > 0f) {
            p.color = color
            c.drawArc(r, -90f, sweep, false, p)
        }
        return bmp
    }

    /** Cercle plein avec une coche (terminé) ou un point d'exclamation (échec) : grande icône des notifications. */
    private fun badge(sizePx: Int, color: Int, failed: Boolean): Bitmap {
        val bmp = ring(sizePx, 1f, color)
        val c = Canvas(bmp)
        val s = sizePx.toFloat()
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = s * 0.11f
            strokeCap = Paint.Cap.ROUND
            this.color = color
        }
        if (!failed) {
            c.drawLine(s * 0.30f, s * 0.52f, s * 0.44f, s * 0.66f, p)
            c.drawLine(s * 0.44f, s * 0.66f, s * 0.71f, s * 0.36f, p)
        } else {
            c.drawLine(s * 0.5f, s * 0.28f, s * 0.5f, s * 0.56f, p)
            c.drawPoint(s * 0.5f, s * 0.72f, p)
        }
        return bmp
    }

    private fun card(context: Context, item: DownloadItem, d: Float): RemoteViews {
        val rv = RemoteViews(context.packageName, R.layout.notif_card)
        val unknown = item.totalBytes <= 0 && item.percent < 0f
        val color = when (item.status) {
            DlStatus.RUNNING -> GOLD
            DlStatus.COMPLETED -> GREEN
            else -> BLUE
        }
        rv.setImageViewBitmap(R.id.ring_card, ring((44 * d).toInt(), if (unknown) 0.25f else item.progress, color))
        rv.setTextViewText(R.id.txt_card, if (unknown) "…" else "${item.percentInt}%")
        rv.setTextViewText(R.id.name, item.fileName)
        rv.setTextViewText(
            R.id.sub,
            when (item.status) {
                DlStatus.QUEUED -> "En file"
                DlStatus.WAITING_NETWORK -> "Réseau…"
                DlStatus.CONNECTING -> "Connexion…"
                else -> if (item.speed > 0) Format.speed(item.speed) else Format.bytes(item.downloadedBytes)
            },
        )
        return rv
    }

    /**
     * Notification permanente du service, en cartes : un cercle pour l'ensemble des téléchargements, un cercle pour les
     * fichiers terminés, puis une carte par téléchargement (jusqu'à 5, avec cercle et pourcentage). Une seule icône
     * dans la barre d'état, quel que soit le nombre de téléchargements.
     */
    fun dashboard(context: Context, active: List<DownloadItem>, s: Session): Notification {
        val d = context.resources.displayMetrics.density
        val pkg = context.packageName
        val speed = active.sumOf { it.speed }
        val known = active.filter { it.totalBytes > 0 }
        val totalBytes = known.sumOf { it.totalBytes }
        val doneBytes = known.sumOf { it.downloadedBytes.coerceAtMost(it.totalBytes) }
        val eta = if (speed > 0 && known.isNotEmpty()) (totalBytes - doneBytes).coerceAtLeast(0) / speed else -1L
        val unknown = active.isNotEmpty() && s.overall <= 0f && active.all { it.totalBytes <= 0 && it.percent < 0f }
        val pct = (s.overall * 100).toInt()
        val doneFraction = if (s.total > 0) s.done.toFloat() / s.total else 0f

        val title = when {
            active.isEmpty() -> if (s.total > 0) "Téléchargements terminés" else "Turbo Download"
            active.size == 1 -> "1 téléchargement en cours"
            else -> "${active.size} téléchargements en cours"
        }
        val line1 = buildList {
            if (speed > 0) add(Format.speed(speed))
            if (eta >= 0) add("reste " + Format.duration(eta))
        }.joinToString(" · ").ifBlank { if (active.isEmpty()) "" else "Préparation…" }
        val line2 = if (totalBytes > 0) "${Format.bytes(doneBytes)} / ${Format.bytes(totalBytes)}" else ""
        val globalText = if (unknown) "…" else "$pct%"
        val doneText = "${s.done}/${s.total}"
        val globalFraction = if (unknown) 0.25f else s.overall

        fun header(rv: RemoteViews, ringDp: Int) {
            rv.setImageViewBitmap(R.id.ring_global, ring((ringDp * d).toInt(), globalFraction, GOLD))
            rv.setTextViewText(R.id.txt_global, globalText)
            rv.setTextViewText(R.id.title, title)
            rv.setTextViewText(R.id.line, line1)
            rv.setImageViewBitmap(R.id.ring_done, ring((ringDp * d).toInt(), doneFraction, GREEN))
            rv.setTextViewText(R.id.txt_done, doneText)
        }

        val small = RemoteViews(pkg, R.layout.notif_collapsed)
        header(small, 40)

        val big = RemoteViews(pkg, R.layout.notif_expanded)
        header(big, 52)
        big.setTextViewText(R.id.line2, line2)
        val shown = active
            .sortedBy { if (it.status == DlStatus.RUNNING || it.status == DlStatus.CONNECTING) 0 else 1 }
            .take(CARDS)
        shown.forEach { big.addView(R.id.cards_row, card(context, it, d)) }
        repeat(CARDS - shown.size) { big.addView(R.id.cards_row, RemoteViews(pkg, R.layout.notif_card_empty)) }
        val footer = buildList {
            val hidden = active.size - shown.size
            if (hidden > 0) add("+$hidden autre(s) en cours")
            val queued = active.count { it.status == DlStatus.QUEUED }
            if (queued > 0) add("$queued en file")
            val waiting = active.count { it.status == DlStatus.WAITING_NETWORK }
            if (waiting > 0) add("$waiting en attente du réseau")
            if (s.paused > 0) add("${s.paused} en pause")
            if (s.failed > 0) add("${s.failed} en échec")
        }.joinToString(" · ")
        big.setTextViewText(R.id.footer, footer)
        big.setViewVisibility(R.id.footer, if (footer.isBlank()) android.view.View.GONE else android.view.View.VISIBLE)
        big.setViewVisibility(R.id.cards_row, if (shown.isEmpty()) android.view.View.GONE else android.view.View.VISIBLE)

        val b = NotificationCompat.Builder(context, CH_PROGRESS)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(GOLD)
            .setStyle(NotificationCompat.DecoratedCustomViewStyle())
            .setCustomContentView(small)
            .setCustomBigContentView(big)
            .setContentTitle(title)
            .setContentText(line1)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setContentIntent(openApp(context))
        if (active.isNotEmpty()) {
            b.addAction(0, "Tout suspendre", action(context, ActionReceiver.PAUSE_ALL, null))
        }
        return b.build()
    }

    fun paused(context: Context, item: DownloadItem): Notification =
        NotificationCompat.Builder(context, CH_PROGRESS)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(GOLD)
            .setContentTitle(item.fileName)
            .setContentText("En pause · ${item.percentInt} %")
            .setProgress(100, item.percentInt, false)
            .setOnlyAlertOnce(true)
            .setContentIntent(openApp(context))
            .addAction(0, "Reprendre", action(context, ActionReceiver.RESUME, item.id))
            .addAction(0, "Annuler", action(context, ActionReceiver.CANCEL, item.id))
            .build()

    fun done(context: Context, item: DownloadItem, sound: Boolean): Notification =
        NotificationCompat.Builder(context, if (sound) CH_DONE else CH_DONE_SILENT)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(GOLD)
            .setLargeIcon(badge((64 * context.resources.displayMetrics.density).toInt(), GREEN, false))
            .setContentTitle(item.fileName)
            .setContentText(
                "Terminé" + if (item.totalBytes > 0) " · " + Format.bytes(item.totalBytes) else ""
            )
            .setAutoCancel(true)
            .setContentIntent(openApp(context))
            .build()

    fun failed(context: Context, item: DownloadItem): Notification =
        NotificationCompat.Builder(context, CH_DONE_SILENT)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(GOLD)
            .setLargeIcon(badge((64 * context.resources.displayMetrics.density).toInt(), RED, true))
            .setContentTitle("Échec : ${item.fileName}")
            .setContentText(item.error ?: "Erreur inconnue")
            .setStyle(NotificationCompat.BigTextStyle().bigText(item.error ?: "Erreur inconnue"))
            .setAutoCancel(true)
            .setContentIntent(openApp(context))
            .addAction(0, "Réessayer", action(context, ActionReceiver.RESUME, item.id))
            .build()
}
