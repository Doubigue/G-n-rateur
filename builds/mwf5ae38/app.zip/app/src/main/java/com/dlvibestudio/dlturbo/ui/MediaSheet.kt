@file:OptIn(ExperimentalMaterial3Api::class)

package com.dlvibestudio.dlturbo.ui

import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PlaylistPlay
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.dlvibestudio.dlturbo.App
import com.dlvibestudio.dlturbo.engine.Links
import com.dlvibestudio.dlturbo.util.Format
import kotlinx.coroutines.CancellationException

// ---------------------------------------------------------------------------------------------
// Médias détectés dans la page (le bouton doré posé sur la vidéo ouvre cette feuille)
// ---------------------------------------------------------------------------------------------

@Composable
fun MediaSheet(hub: WebHub, tab: WebTab, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val hits = tab.media.toList()
    val key = hits.joinToString("|") { it.url }
    var analysis by remember(tab.id) { mutableStateOf<StreamAnalysis?>(null) }
    var analyzing by remember(tab.id) { mutableStateOf(false) }
    var sniffing by remember(tab.id) { mutableStateOf(false) }
    var formatTab by remember { mutableIntStateOf(0) }

    // Chaque nouveau flux repéré : on relit les qualités disponibles et leurs tailles.
    LaunchedEffect(key) {
        if (hits.isEmpty()) return@LaunchedEffect
        analyzing = true
        try {
            analysis = hub.analyzeStreams(hits)
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
        } finally {
            analyzing = false
        }
    }
    // Aucun flux encore vu (vidéo pas lancée, lecteur dans une iframe…) : recherche automatique en arrière-plan.
    LaunchedEffect(tab.id) {
        if (tab.media.isEmpty() && !hub.crawler.busy && tab.url.startsWith("http")) {
            sniffing = true
            try {
                hub.crawler.sniff(tab.url).forEach { tab.addMedia(it) }
            } finally {
                sniffing = false
            }
        }
    }

    val a = analysis
    val title = cleanPageTitle(tab.title)

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(
            Modifier.fillMaxWidth().navigationBarsPadding().verticalScroll(rememberScrollState())
                .padding(bottom = 16.dp),
        ) {
            Text(
                "Télécharger depuis cette page",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 8.dp),
            )
            val sub = listOfNotNull(
                title.takeIf { it.isNotBlank() },
                a?.durationSec?.takeIf { it > 0 }?.let { Format.clock(it) },
            ).joinToString(" · ")
            if (sub.isNotBlank()) {
                Text(
                    sub, maxLines = 2, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 20.dp),
                )
            }
            Spacer(Modifier.height(8.dp))

            when {
                sniffing && hits.isEmpty() -> Busy("Recherche de la vidéo dans la page…")
                hits.isEmpty() -> Text(
                    "Aucun flux trouvé. Si la page demande une vérification (captcha / Cloudflare), validez-la dans " +
                        "le navigateur puis rouvrez ce menu. Sinon, lancez la lecture de la vidéo, " +
                        "ou essayez « Analyser cette page ».",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                )
                a == null && analyzing -> Busy("Calcul des formats et des tailles…")
                a == null -> Text(
                    "Impossible de lire les formats de ce flux.",
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                )
                else -> {
                    TabRow(selectedTabIndex = formatTab) {
                        Tab(selected = formatTab == 0, onClick = { formatTab = 0 }, text = { Text("Vidéo (${a.videos.size})") })
                        Tab(selected = formatTab == 1, onClick = { formatTab = 1 }, text = { Text("Audio (MP3…)") })
                    }
                    if (formatTab == 0) {
                        if (a.videos.isEmpty()) {
                            Text(
                                "Seul un flux audio a été trouvé : voir l'onglet Audio.",
                                modifier = Modifier.padding(20.dp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        a.videos.forEach { v ->
                            val ext = if (v.isStream || v.container == "MP4") "MP4" else v.container
                            OptionRow(
                                title = "${v.label} · $ext",
                                detail = listOf(
                                    if (v.sizeBytes > 0) "~" + Format.bytes(v.sizeBytes) else "taille inconnue",
                                    v.host,
                                ).joinToString(" · "),
                            ) { hub.downloadVariant(tab, v, "best"); onDismiss() }
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                        }
                    } else {
                        val src = a.audioSource
                        listOf(
                            Triple("mp3", "MP3", "Compatible partout"),
                            Triple("m4a", "M4A", "AAC · plus léger"),
                            Triple("wav", "WAV", "Sans compression · très volumineux"),
                        ).forEach { (k, label, d) ->
                            val size = a.audioSize(k)
                            OptionRow(
                                title = label,
                                detail = d + if (size > 0) " · ~" + Format.bytes(size) else "",
                            ) {
                                if (src != null) { hub.downloadVariant(tab, src, k); onDismiss() }
                            }
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                        }
                    }
                    if (analyzing) Busy("Mise à jour des formats…")
                }
            }

            Spacer(Modifier.height(8.dp))
            val inList = hub.waitList.contains(tab.url)
            ActionRow(
                if (inList) "Déjà dans la liste d'attente" else "Ajouter à la liste d'attente",
                "Téléchargement groupé : ajoutez plusieurs épisodes / films puis lancez tout (${hub.waitList.items.size} en attente)",
            ) {
                if (!inList) hub.addToWaitList(tab)
                else Toast.makeText(context, "Cette page est déjà dans la liste", Toast.LENGTH_SHORT).show()
            }
            if (hub.waitList.items.isNotEmpty()) {
                ActionRow("Ouvrir la liste d'attente", "Choisir le format et tout télécharger") {
                    hub.waitOpen.value = true
                    onDismiss()
                }
            }
            if (tab.embed.isNotBlank()) {
                ActionRow("Extraire depuis le lecteur de la page", "Essaie l'extracteur sur le lecteur intégré") {
                    hub.formatRequest.value = tab.embed
                    onDismiss()
                }
            }
            ActionRow("Analyser cette page", "Formats MP4 / MP3 / WAV avec l'extracteur (sites pris en charge)") {
                hub.formatRequest.value = tab.url
                onDismiss()
            }
            ActionRow("Liste d'épisodes / playlist de la page", "Saisons et épisodes : de 1 à la fin") {
                hub.scanEpisodes(tab)
                onDismiss()
            }
            ActionRow("Images de la page", "Choisir et télécharger les images") {
                hub.scanImages(tab)
                onDismiss()
            }
        }
    }
}

@Composable
private fun Busy(text: String) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
        Text("  $text", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun ActionRow(title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Liste d'épisodes (séries) : sélection d'une plage 1 → N puis recherche automatique des vidéos
// ---------------------------------------------------------------------------------------------

@Composable
fun EpisodesSheet(hub: WebHub, list: EpisodeList, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var reversed by remember(list) { mutableStateOf(false) }
    val checked = remember(list) { mutableStateListOf<Boolean>().apply { repeat(list.items.size) { add(true) } } }
    var from by remember(list) { mutableStateOf("1") }
    var to by remember(list) { mutableStateOf("") }
    var audio by remember(list) { mutableStateOf(false) }
    var prefix by remember(list) { mutableStateOf(cleanPageTitle(list.pageTitle)) }

    val shown = if (reversed) list.items.reversed() else list.items
    // Les cases suivent l'ordre d'affichage : on réinitialise quand l'ordre change.
    fun selectRange() {
        val a = (from.toIntOrNull() ?: 1).coerceAtLeast(1)
        val b = to.toIntOrNull() ?: Int.MAX_VALUE
        for (i in checked.indices) checked[i] = (i + 1) in a..b
    }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding()) {
            Row(Modifier.padding(horizontal = 20.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.PlaylistPlay, null, tint = MaterialTheme.colorScheme.primary)
                Text(
                    "  ${list.items.size} épisodes trouvés",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                )
            }
            OutlinedTextField(
                value = prefix,
                onValueChange = { prefix = it },
                label = { Text("Nom de la série (préfixe des fichiers)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            )
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                OutlinedTextField(
                    value = from, onValueChange = { from = it.filter(Char::isDigit) },
                    label = { Text("De") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f),
                )
                OutlinedTextField(
                    value = to, onValueChange = { to = it.filter(Char::isDigit) },
                    label = { Text("à (vide = jusqu'à la fin)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1.6f),
                )
                OutlinedButton(onClick = { selectRange() }) { Text("OK") }
            }
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                FilterChip(selected = false, onClick = { for (i in checked.indices) checked[i] = true }, label = { Text("Tout") })
                FilterChip(selected = false, onClick = { for (i in checked.indices) checked[i] = false }, label = { Text("Aucun") })
                FilterChip(selected = reversed, onClick = { reversed = !reversed }, label = { Text("Ordre inversé") })
                Spacer(Modifier.weight(1f))
                FilterChip(selected = !audio, onClick = { audio = false }, label = { Text("Vidéo") })
                FilterChip(selected = audio, onClick = { audio = true }, label = { Text("MP3") })
            }
            HorizontalDivider(Modifier.padding(top = 8.dp))
            LazyColumn(Modifier.weight(1f, fill = false).heightIn(max = 380.dp)) {
                itemsIndexed(shown) { i, ep ->
                    Row(
                        Modifier.fillMaxWidth().clickable { checked[i] = !checked[i] }.padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Checkbox(checked = checked[i], onCheckedChange = { checked[i] = it })
                        Text("${i + 1}.", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.width(36.dp))
                        Text(ep.title, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            val count = checked.count { it }
            OutlinedButton(
                onClick = {
                    val chosen = shown.filterIndexed { i, _ -> checked[i] }
                        .map { it.copy(title = listOf(prefix.trim(), it.title).filter { t -> t.isNotBlank() }.joinToString(" - ")) }
                    val n = hub.waitList.addAll(chosen)
                    Toast.makeText(
                        context, "$n épisode(s) ajouté(s) à la liste d'attente (${hub.waitList.items.size} au total)",
                        Toast.LENGTH_LONG,
                    ).show()
                    onDismiss()
                },
                enabled = count > 0,
                modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 12.dp),
            ) {
                Text("Ajouter $count épisode(s) à la liste d'attente")
            }
            Button(
                onClick = {
                    val chosen = shown.filterIndexed { i, _ -> checked[i] }
                    hub.crawler.start(prefix.trim(), chosen, if (audio) "mp3" else "best")
                    Toast.makeText(
                        context, "Recherche des vidéos de ${chosen.size} épisode(s) lancée", Toast.LENGTH_LONG,
                    ).show()
                    onDismiss()
                },
                enabled = count > 0,
                modifier = Modifier.fillMaxWidth().padding(16.dp),
            ) {
                Icon(Icons.Filled.Download, null, modifier = Modifier.size(18.dp))
                Text("  Télécharger $count épisode(s)")
            }
        }
    }
}

/** Bandeau d'avancement de la recherche des épisodes, visible depuis tous les onglets. */
@Composable
fun CrawlBanner(hub: WebHub) {
    val st = hub.crawler.state.value ?: return
    Surface(
        color = MaterialTheme.colorScheme.secondaryContainer,
        contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            if (st.running) {
                Text(
                    "Recherche des vidéos ${st.done + 1}/${st.total} · ${st.current}",
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold,
                )
                Text(
                    "${st.added} ajouté(s)" + if (st.failed.isNotEmpty()) " · ${st.failed.size} introuvable(s)" else "",
                    style = MaterialTheme.typography.bodySmall,
                )
                LinearProgressIndicator(
                    progress = { st.done.toFloat() / st.total.coerceAtLeast(1) },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                )
                Text(
                    "Gardez l'application ouverte pendant la recherche.",
                    style = MaterialTheme.typography.labelSmall,
                )
                TextButton(onClick = { hub.crawler.cancel() }) { Text("Annuler") }
            } else {
                Text(
                    "${st.added} épisode(s) ajouté(s) aux téléchargements" +
                        if (st.failed.isNotEmpty()) ", ${st.failed.size} sans vidéo trouvée" else "",
                    style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold,
                )
                if (st.failed.isNotEmpty()) {
                    Text(
                        "Introuvables : " + st.failed.take(6).joinToString(", ") +
                            if (st.failed.size > 6) "…" else "",
                        style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis,
                    )
                }
                TextButton(onClick = { hub.crawler.dismiss() }) { Text("Fermer") }
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Images de la page
// ---------------------------------------------------------------------------------------------

@Composable
fun ImagesSheet(app: App, hub: WebHub, images: List<PageImage>, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val checked = remember(images) { mutableStateListOf<Boolean>().apply { repeat(images.size) { add(true) } } }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding()) {
            Text(
                "${images.size} images trouvées",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
            )
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = false, onClick = { for (i in checked.indices) checked[i] = true }, label = { Text("Tout") })
                FilterChip(selected = false, onClick = { for (i in checked.indices) checked[i] = false }, label = { Text("Aucune") })
            }
            LazyColumn(Modifier.weight(1f, fill = false).heightIn(max = 420.dp)) {
                itemsIndexed(images) { i, img ->
                    Row(
                        Modifier.fillMaxWidth().clickable { checked[i] = !checked[i] }.padding(horizontal = 12.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Checkbox(checked = checked[i], onCheckedChange = { checked[i] = it })
                        Box(Modifier.size(72.dp).clip(RoundedCornerShape(8.dp))) {
                            RemoteImage(img.url, app.manager.http.client, Modifier.size(72.dp))
                        }
                        Column(Modifier.weight(1f).padding(start = 12.dp)) {
                            Text(
                                Uri.parse(img.url).lastPathSegment ?: img.url,
                                maxLines = 1, overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.bodyMedium,
                            )
                            if (img.width > 0) {
                                Text(
                                    "${img.width} px",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                }
            }
            val count = checked.count { it }
            Button(
                onClick = {
                    val tab = hub.current
                    images.forEachIndexed { i, img ->
                        if (checked[i] && tab != null) hub.downloadFile(tab, img.url)
                    }
                    Toast.makeText(context, "$count image(s) ajoutée(s)", Toast.LENGTH_SHORT).show()
                    onDismiss()
                },
                enabled = count > 0,
                modifier = Modifier.fillMaxWidth().padding(16.dp),
            ) {
                Icon(Icons.Filled.Download, null, modifier = Modifier.size(18.dp))
                Text("  Télécharger $count image(s)")
            }
        }
    }
}
