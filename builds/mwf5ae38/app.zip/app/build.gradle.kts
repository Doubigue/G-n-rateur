plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.dlvibestudio.dlturbo"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.dlvibestudio.dlturbo"
        // 26 : requis par les bibliothèques d'archives (7z/tar) qui utilisent java.nio.file.
        minSdk = 26
        // 34 volontairement : à partir de 35, Android limite les services "dataSync" à 6 h par jour.
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"

        ndk {
            // Téléphones réels uniquement. Ajouter "x86_64" pour un émulateur
            // (et les dépendances libtorrent4j-android-x86_64 correspondantes).
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    // Clé dédiée à Turbo Download : ne pas la remplacer après publication.
    // Conserver le keystore et ce projet dans un dépôt privé.
    signingConfigs {
        create("turbo") {
            storeFile = rootProject.file("keystore/dlturbo.jks")
            storePassword = "LzK9q7yAi9QmlQcw9sZUU8H9lVko"
            keyAlias = "dlturbo"
            keyPassword = "MPctSJIeyRMsA9KERe8e1G47i8EN"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("turbo")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("turbo")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    packaging {
        // Indispensable pour yt-dlp / ffmpeg : les binaires doivent être extraits sur le téléphone.
        jniLibs {
            useLegacyPackaging = true
        }
        resources {
            excludes += setOf("/META-INF/{AL2.0,LGPL2.1}", "META-INF/DEPENDENCIES")
        }
    }
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.core:core-ktx:1.15.0")

    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    // Moteur HTTP multi-connexions
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // Moteur BitTorrent (libtorrent)
    val libtorrent = "2.1.0-34"
    implementation("org.libtorrent4j:libtorrent4j:$libtorrent")
    implementation("org.libtorrent4j:libtorrent4j-android-arm64:$libtorrent")
    implementation("org.libtorrent4j:libtorrent4j-android-arm:$libtorrent")

    // Lecteur vidéo / audio (lecture en arrière-plan via un service MediaSession)
    val media3 = "1.5.1"
    implementation("androidx.media3:media3-exoplayer:$media3")
    implementation("androidx.media3:media3-ui:$media3")
    implementation("androidx.media3:media3-session:$media3")

    // Navigateur : scripts injectés dès le début de la page
    implementation("androidx.webkit:webkit:1.12.1")

    // Visionneuse d'images (rotation EXIF)
    implementation("androidx.exifinterface:exifinterface:1.3.7")

    // QR codes : transfert des téléchargements vers un autre téléphone (création + lecture par la caméra)
    implementation("com.google.zxing:core:3.5.3")
    implementation("com.journeyapps:zxing-android-embedded:4.3.0") { isTransitive = false }

    // Décompression : ZIP (mot de passe, AES), 7z / tar / gz / bz2 / xz, RAR
    implementation("net.lingala.zip4j:zip4j:2.11.5")
    implementation("org.apache.commons:commons-compress:1.27.1")
    implementation("org.tukaani:xz:1.10")
    implementation("com.github.junrar:junrar:7.5.5")

    // Extraction vidéo (yt-dlp + ffmpeg) : YouTube, Instagram, Facebook, TikTok, Pinterest, etc.
    val ytdl = "0.18.1"
    implementation("io.github.junkfood02.youtubedl-android:library:$ytdl")
    implementation("io.github.junkfood02.youtubedl-android:ffmpeg:$ytdl")
    // aria2c : plusieurs connexions sur les fichiers vidéo simples (YouTube, Facebook, TikTok…) comme dans MyDM
    implementation("io.github.junkfood02.youtubedl-android:aria2c:$ytdl")
}
