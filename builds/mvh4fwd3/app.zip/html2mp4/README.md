# HTML → MP4

1. `flutter create .` (dans ce dossier, pour générer android/ et ios/), puis `flutter pub get`
2. Android : minSdkVersion 24 ; dans AndroidManifest.xml, balise <application> : android:usesCleartextTraffic="true"
   (Android 9 ou moins : permission WRITE_EXTERNAL_STORAGE avec android:maxSdkVersion="28")
3. iOS (14+) : dans Info.plist ajouter
   - NSPhotoLibraryAddUsageDescription et NSPhotoLibraryUsageDescription
   - NSAppTransportSecurity > NSAllowsLocalNetworking = true
4. `flutter run`

Projet .zip : un index.html + ses dossiers (sons, images…). Exemple : spot_html2mp4.zip (720x1280, 30 FPS, 12 s).
