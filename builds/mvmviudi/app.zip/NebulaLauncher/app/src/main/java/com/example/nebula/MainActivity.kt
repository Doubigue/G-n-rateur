package com.example.nebula

import android.Manifest
import android.app.AlertDialog
import android.app.WallpaperManager
import android.app.usage.UsageStatsManager
import android.content.*
import android.content.pm.PackageManager
import android.graphics.*
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.provider.Settings
import android.text.TextUtils
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.WindowCompat
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs

class MainActivity : ComponentActivity() {
    private lateinit var prefs: Prefs
    private lateinit var t: NebulaTheme
    private lateinit var repo: AppRepo
    private lateinit var tilt: Tilt
    private lateinit var root: FrameLayout
    private lateinit var home: LinearLayout
    private lateinit var particles: ParticleView
    private lateinit var bgImage: ImageView
    private lateinit var bgVideo: VideoView
    private lateinit var clock: TextView
    private lateinit var weather: TextView
    private lateinit var focusLabel: TextView
    private lateinit var homeMedia: MediaCard
    private lateinit var ccMedia: MediaCard
    private lateinit var dock: LinearLayout
    private lateinit var drawer: LinearLayout
    private lateinit var grid: RecyclerView
    private lateinit var chips: LinearLayout
    private lateinit var drawerSearch: EditText
    private lateinit var sortBtn: TextView
    private lateinit var searchPanel: LinearLayout
    private lateinit var searchEdit: EditText
    private lateinit var results: LinearLayout
    private lateinit var cc: LinearLayout
    private lateinit var ccInfo: TextView
    private lateinit var ccStorage: ProgressBar
    private val adapter = AppAdapter()
    private var apps = listOf<AppItem>()
    private var cat = Cat.ALL
    private var query = ""
    private var drawerOpen = false; private var searchOpen = false; private var ccOpen = false
    private val h = Handler(Looper.getMainLooper())
    private var pickKind = 0
    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            prefs.bgUri = uri.toString(); prefs.bgMode = if (pickKind == 0) 4 else 5; applyBackground()
        }
    }
    private val loop = object : Runnable { override fun run() { tick(); h.postDelayed(this, 500) } }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun haptic(v: View = root) = v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    private fun ml(w: Int = -1, hh: Int = -2) = LinearLayout.LayoutParams(w, hh)

    private fun chip(text: String, on: Boolean = false, click: () -> Unit) = TextView(this).apply {
        this.text = text; setTextColor(t.text); textSize = 13f; setPadding(dp(14), dp(8), dp(14), dp(8))
        background = glassBg(t, dp(18).toFloat(), if (on) 130 else 45)
        setOnClickListener { haptic(it); click() }
        layoutParams = LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(8) }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        prefs = Prefs(this); t = Themes.all[prefs.theme.coerceIn(0, Themes.all.size - 1)]
        repo = AppRepo(this, prefs); tilt = Tilt(this)
        WindowCompat.setDecorFitsSystemWindows(window, false)

        root = FrameLayout(this)
        particles = ParticleView(this)
        bgImage = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; visibility = View.GONE; setColorFilter(Color.argb(90, 0, 0, 0)) }
        bgVideo = VideoView(this).apply { visibility = View.GONE }
        root.addView(particles, FrameLayout.LayoutParams(-1, -1)); root.addView(bgImage, FrameLayout.LayoutParams(-1, -1))
        root.addView(bgVideo, FrameLayout.LayoutParams(-1, -1))

        buildHome(); buildDrawer(); buildSearchPanel(); buildControlCenter()
        setContentView(root)
        applyBackground(); applyFocusVisual()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { // ne ferme jamais le launcher
                when { ccOpen -> closeCC(); searchOpen -> closeSearch(); drawerOpen -> closeDrawer() }
            }
        })

        val need = mutableListOf(Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) need += Manifest.permission.POST_NOTIFICATIONS
        val missing = need.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 1)
        if (prefs.lockEnabled && Settings.canDrawOverlays(this)) startForegroundService(Intent(this, LockService::class.java))
        reloadApps()
    }

    // ───────────────────────── Accueil ─────────────────────────
    private fun buildHome() {
        home = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(72), dp(20), dp(36)) }
        clock = TextView(this).apply {
            textSize = 72f; setTextColor(t.accent2); typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
            setShadowLayer(26f, 0f, 0f, t.accent2)
        }
        tilt.add(clock)
        weather = TextView(this).apply { setTextColor(t.text); textSize = 18f; text = prefs.weather }
        focusLabel = TextView(this).apply { setTextColor(t.accent); textSize = 14f; visibility = View.GONE }
        homeMedia = MediaCard(this, t); homeMedia.tiltOnTouch()
        homeMedia.onOtherFling = { vx, vy -> handleFling(vx, vy) }
        dock = LinearLayout(this).apply { background = glassBg(t, dp(32).toFloat(), 55); gravity = Gravity.CENTER; setPadding(dp(12), dp(12), dp(12), dp(8)) }
        home.addView(clock); home.addView(weather); home.addView(focusLabel)
        home.addView(homeMedia, ml().apply { topMargin = dp(28) })
        home.addView(View(this), ml(-1, 0).apply { weight = 1f })
        home.addView(dock, ml())
        root.addView(home, FrameLayout.LayoutParams(-1, -1))

        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onFling(a: MotionEvent?, b: MotionEvent, vx: Float, vy: Float) = handleFling(vx, vy)
            override fun onDoubleTap(e: MotionEvent): Boolean { lockPhone(); return true }
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean { nextSeason(); return true }
            override fun onLongPress(e: MotionEvent) { haptic(); mainMenu() }
        })
        home.setOnTouchListener { _, ev -> particles.touch(ev); gd.onTouchEvent(ev) }
    }

    /** Tap sur le bureau (fond de saison) : Printemps → Été → Automne → Hiver → Auto (selon l'heure) → … */
    private fun nextSeason() {
        val m = prefs.bgMode; if (m !in 8..12) return
        val n = if (m == 12) 8 else m + 1
        prefs.bgMode = n; applyBackground(); haptic()
        Toast.makeText(this, arrayOf("🌸 Printemps", "☀️ Été", "🍂 Automne", "❄️ Hiver", "🕒 Auto : suit l'heure")[n - 8], Toast.LENGTH_SHORT).show()
    }

    private fun handleFling(vx: Float, vy: Float): Boolean {
        if (abs(vy) > abs(vx)) {
            if (vy < -1200) openDrawer() else if (vy > 1200) openSearch() else return false
        } else if (vx < -1200) openCC() else return false
        return true
    }

    private fun refreshDock() {
        dock.removeAllViews()
        val pinned = prefs.dock.split(",").filter { it.isNotEmpty() }.mapNotNull { p -> apps.firstOrNull { it.pkg == p } }
        (if (pinned.isEmpty()) apps.take(4) else pinned).forEach { a ->
            val v = ReflectionIcon(this, a.icon)
            v.setOnClickListener { launch(a) }; v.setOnLongClickListener { appMenu(a); true }
            tilt.add(v); dock.addView(v, ml(0, dp(80)).apply { weight = 1f })
        }
    }

    // ───────────────────────── Tiroir intelligent ─────────────────────────
    private fun buildDrawer() {
        drawer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE; isClickable = true
            setBackgroundColor(Color.argb(215, Color.red(t.bgTop), Color.green(t.bgTop), Color.blue(t.bgTop)))
            setPadding(dp(12), dp(56), dp(12), dp(12))
        }
        drawerSearch = EditText(this).apply {
            hint = "Rechercher…"; setHintTextColor(Color.GRAY); setTextColor(t.text); background = glassBg(t, dp(20).toFloat(), 50)
            setPadding(dp(16), dp(12), dp(16), dp(12)); setSingleLine()
            doAfterTextChanged { query = it.toString(); refreshDrawer() }
        }
        sortBtn = chip("A–Z") { prefs.sort = (prefs.sort + 1) % 3; refreshDrawer() }
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        row.addView(drawerSearch, ml(0, -2).apply { weight = 1f; marginEnd = dp(8) }); row.addView(sortBtn)
        chips = LinearLayout(this)
        val chipScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(chips) }
        grid = RecyclerView(this).apply { layoutManager = GridLayoutManager(this@MainActivity, 4); this.adapter = this@MainActivity.adapter }
        drawer.addView(row); drawer.addView(chipScroll, ml().apply { topMargin = dp(10); bottomMargin = dp(6) })
        drawer.addView(grid, ml(-1, 0).apply { weight = 1f })
        root.addView(drawer, FrameLayout.LayoutParams(-1, -1))
        tilt.onChange = { rx, ry ->
            if (drawerOpen) for (i in 0 until grid.childCount) { val c = grid.getChildAt(i); c.rotationX = rx * .6f; c.rotationY = ry * .6f }
        }
    }

    private fun refreshDrawer() {
        val hidden = if (prefs.focus) setOf(Cat.SOCIAL, Cat.GAMES) else emptySet()
        var list = apps.filter { it.cat !in hidden && (cat == Cat.ALL || it.cat == cat) && it.label.contains(query, true) }
        list = if (query.isNotEmpty())
            list.sortedWith(compareByDescending<AppItem> { it.label.startsWith(query, true) }.thenByDescending { prefs.launches(it.pkg) })
        else repo.sort(list, prefs.sort)
        adapter.submit(list)
        sortBtn.text = arrayOf("A–Z", "Fréquence", "Couleur")[prefs.sort]
        chips.removeAllViews()
        Cat.values().forEach { c ->
            val n = apps.count { it.cat == c || c == Cat.ALL }
            if (n > 0) chips.addView(chip("${c.label} $n", c == cat) { cat = c; refreshDrawer() })
        }
    }

    private inner class AppAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        var data = listOf<AppItem>()
        fun submit(l: List<AppItem>) { data = l; notifyDataSetChanged() }
        override fun getItemCount() = data.size
        override fun onCreateViewHolder(p: ViewGroup, vt: Int): RecyclerView.ViewHolder {
            val v = LinearLayout(p.context).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(10)); cameraDistance = 12000f
                addView(ImageView(context), LinearLayout.LayoutParams(dp(52), dp(52)))
                addView(TextView(context).apply { setTextColor(t.text); textSize = 11f; maxLines = 1; gravity = Gravity.CENTER; ellipsize = TextUtils.TruncateAt.END })
                layoutParams = RecyclerView.LayoutParams(-1, -2)
            }
            return object : RecyclerView.ViewHolder(v) {}
        }
        override fun onBindViewHolder(vh: RecyclerView.ViewHolder, i: Int) {
            val a = data[i]; val v = vh.itemView as LinearLayout
            (v.getChildAt(0) as ImageView).setImageDrawable(a.icon.copy()); (v.getChildAt(1) as TextView).text = a.label
            v.rotationX = tilt.rx * .6f; v.rotationY = tilt.ry * .6f
            v.setOnClickListener { haptic(it); launch(a) }
            v.setOnLongClickListener { appMenu(a); true }
        }
    }

    private fun launch(a: AppItem) { prefs.addLaunch(a.pkg); try { startActivity(a.intent) } catch (_: Exception) {} }

    private fun appMenu(a: AppItem) {
        AlertDialog.Builder(this).setTitle(a.label).setItems(arrayOf("📌 Épingler au dock", "ℹ️ Infos", "🗑️ Désinstaller")) { _, i ->
            when (i) {
                0 -> {
                    val l = prefs.dock.split(",").filter { it.isNotEmpty() }.toMutableList(); l.remove(a.pkg); l.add(0, a.pkg)
                    prefs.dock = l.take(5).joinToString(","); refreshDock()
                }
                1 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}")))
                2 -> startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}")))
            }
        }.show()
    }

    // ───────────────────────── Panneau de recherche (swipe bas) ─────────────────────────
    private fun buildSearchPanel() {
        searchPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE; isClickable = true
            background = glassBg(t, dp(28).toFloat(), 190); setPadding(dp(16), dp(56), dp(16), dp(16))
        }
        searchEdit = EditText(this).apply {
            hint = "Recherche prédictive…"; setHintTextColor(Color.GRAY); setTextColor(t.text); setSingleLine()
            background = glassBg(t, dp(20).toFloat(), 50); setPadding(dp(16), dp(12), dp(16), dp(12))
            doAfterTextChanged { updateResults(it.toString()) }
        }
        val shortcuts = LinearLayout(this)
        shortcuts.addView(chip("📞") { startActivity(Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) })
        shortcuts.addView(chip("📷") { try { startActivity(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)) } catch (_: Exception) {} })
        shortcuts.addView(chip("⚙️") { startActivity(Intent(Settings.ACTION_SETTINGS)) })
        shortcuts.addView(chip("🎯 Focus") { setFocus(!prefs.focus); closeSearch() })
        results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        searchPanel.addView(searchEdit); searchPanel.addView(shortcuts, ml().apply { topMargin = dp(10) })
        searchPanel.addView(results, ml().apply { topMargin = dp(10) })
        root.addView(searchPanel, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onFling(a: MotionEvent?, b: MotionEvent, vx: Float, vy: Float): Boolean { if (vy < -1000) { closeSearch(); return true }; return false }
        })
        searchPanel.setOnTouchListener { _, e -> gd.onTouchEvent(e); false }
    }

    private fun updateResults(q: String) {
        results.removeAllViews()
        val hidden = if (prefs.focus) setOf(Cat.SOCIAL, Cat.GAMES) else emptySet()
        val l = apps.filter { it.cat !in hidden && it.label.contains(q, true) }
            .sortedWith(compareByDescending<AppItem> { it.label.startsWith(q, true) }.thenByDescending { prefs.launches(it.pkg) }).take(5)
        l.forEach { a ->
            val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(6)) }
            r.addView(ImageView(this).apply { setImageDrawable(a.icon.copy()) }, LinearLayout.LayoutParams(dp(40), dp(40)))
            r.addView(TextView(this).apply { text = a.label; setTextColor(t.text); textSize = 15f; setPadding(dp(12), 0, 0, 0) })
            r.setOnClickListener { haptic(it); closeSearch(); launch(a) }
            results.addView(r)
        }
    }

    // ───────────────────────── Centre de contrôle (swipe gauche) ─────────────────────────
    private fun buildControlCenter() {
        cc = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE; isClickable = true
            background = glassBg(t, dp(28).toFloat(), 190); setPadding(dp(16), dp(64), dp(16), dp(16))
        }
        ccMedia = MediaCard(this, t)
        ccInfo = TextView(this).apply { setTextColor(t.text); textSize = 14f }
        ccStorage = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progressTintList = android.content.res.ColorStateList.valueOf(t.accent)
        }
        val r1 = LinearLayout(this); val r2 = LinearLayout(this)
        r1.addView(chip("📶 Wi-Fi") { startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) })
        r1.addView(chip("🔷 Bluetooth") { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) })
        r2.addView(chip("🎯 Focus") { setFocus(!prefs.focus); closeCC() })
        r2.addView(chip("🔒 Lock") { lockPhone() })
        cc.addView(TextView(this).apply { text = "Centre de contrôle"; setTextColor(t.accent2); textSize = 18f })
        cc.addView(ccMedia, ml().apply { topMargin = dp(12) })
        cc.addView(ccInfo, ml().apply { topMargin = dp(16) })
        cc.addView(ccStorage, ml(-1, dp(10)).apply { topMargin = dp(6) })
        cc.addView(r1, ml().apply { topMargin = dp(16) }); cc.addView(r2, ml().apply { topMargin = dp(8) })
        root.addView(cc, FrameLayout.LayoutParams(dp(300), -1, Gravity.END))
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onFling(a: MotionEvent?, b: MotionEvent, vx: Float, vy: Float): Boolean { if (vx > 1000) { closeCC(); return true }; return false }
        })
        cc.setOnTouchListener { _, e -> gd.onTouchEvent(e); false }
    }

    private fun refreshCC() {
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        val st = StatFs(Environment.getDataDirectory().path)
        val total = st.totalBytes; val used = total - st.availableBytes
        ccStorage.progress = (used * 100 / total).toInt()
        ccInfo.text = "🔋 Batterie ${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)}%\n💾 Stockage ${used shr 30} / ${total shr 30} Go"
        ccMedia.refresh()
    }

    // ───────────────────────── Ouverture / fermeture des panneaux ─────────────────────────
    private fun openDrawer() {
        if (drawerOpen) return; drawerOpen = true; haptic(); refreshDrawer()
        drawer.visibility = View.VISIBLE; drawer.translationY = root.height.toFloat()
        drawer.animate().translationY(0f).setDuration(300).setInterpolator(android.view.animation.DecelerateInterpolator(1.6f)).start()
        if (Build.VERSION.SDK_INT >= 31) home.setRenderEffect(RenderEffect.createBlurEffect(40f, 40f, Shader.TileMode.CLAMP))
    }
    private fun closeDrawer() {
        drawerOpen = false; drawerSearch.setText(""); cat = Cat.ALL
        drawer.animate().translationY(root.height.toFloat()).setDuration(220).withEndAction { drawer.visibility = View.GONE }.start()
        if (Build.VERSION.SDK_INT >= 31) home.setRenderEffect(null)
    }
    private fun openSearch() {
        if (searchOpen) return; searchOpen = true; haptic(); updateResults("")
        searchPanel.visibility = View.VISIBLE; searchPanel.translationY = -root.height.toFloat()
        searchPanel.animate().translationY(0f).setDuration(260).start()
        searchEdit.requestFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(searchEdit, 0)
    }
    private fun closeSearch() {
        searchOpen = false; searchEdit.setText("")
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(searchEdit.windowToken, 0)
        searchPanel.animate().translationY(-root.height.toFloat()).setDuration(220).withEndAction { searchPanel.visibility = View.GONE }.start()
    }
    private fun openCC() {
        if (ccOpen) return; ccOpen = true; haptic(); refreshCC()
        cc.visibility = View.VISIBLE; cc.translationX = dp(300).toFloat(); cc.animate().translationX(0f).setDuration(260).start()
    }
    private fun closeCC() {
        ccOpen = false
        cc.animate().translationX(dp(300).toFloat()).setDuration(220).withEndAction { cc.visibility = View.GONE }.start()
    }

    // ───────────────────────── Fond d'écran ─────────────────────────
    private fun applyBackground() {
        val m = prefs.bgMode
        particles.engine.theme = t; if (m < 4 || m >= 6) particles.engine.style = m; particles.engine.rebuild()
        particles.visibility = if (m < 4 || m >= 6) View.VISIBLE else View.GONE
        bgImage.visibility = View.GONE; bgVideo.visibility = View.GONE; bgVideo.stopPlayback()
        val uri = prefs.bgUri?.let { Uri.parse(it) } ?: return
        try {
            if (m == 4) { bgImage.setImageURI(uri); bgImage.visibility = View.VISIBLE }
            if (m == 5) {
                bgVideo.visibility = View.VISIBLE; bgVideo.setVideoURI(uri)
                bgVideo.setOnPreparedListener { it.isLooping = true; it.setVolume(0f, 0f) }; bgVideo.start()
            }
        } catch (_: Exception) { particles.visibility = View.VISIBLE }
    }

    // ───────────────────────── Mode Focus / Détox ─────────────────────────
    private fun setFocus(on: Boolean) {
        prefs.focus = on; if (on) prefs.focusSince = System.currentTimeMillis()
        haptic(); applyFocusVisual(); refreshDrawer()
    }
    private fun applyFocusVisual() {
        val p = Paint().apply { colorFilter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(0f) }) }
        root.setLayerType(if (prefs.focus) View.LAYER_TYPE_HARDWARE else View.LAYER_TYPE_NONE, if (prefs.focus) p else null)
        focusLabel.visibility = if (prefs.focus) View.VISIBLE else View.GONE
    }
    private fun screenTimeMs(): Long = try {
        val usm = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
        val cal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0) }
        usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, cal.timeInMillis, System.currentTimeMillis()).sumOf { it.totalTimeInForeground }
    } catch (_: Throwable) { 0L }

    private fun tick() {
        clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        homeMedia.refresh(); if (ccOpen) ccMedia.refresh()
        if (prefs.focus) {
            val s = (System.currentTimeMillis() - prefs.focusSince) / 1000; val st = screenTimeMs() / 60000
            focusLabel.text = "🎯 Focus %02d:%02d  •  Écran aujourd'hui : %s".format(s / 60, s % 60, if (st > 0) "${st / 60} h ${st % 60} min" else "(autoriser dans le menu)")
        }
    }

    // ───────────────────────── Menu & actions système ─────────────────────────
    private fun lockPhone() {
        val s = LockAccessibilityService.instance
        if (s != null) s.lock() else Toast.makeText(this, "Active Nebula dans Accessibilité (menu > Double-tap)", Toast.LENGTH_LONG).show()
    }

    private fun mainMenu() {
        val items = arrayOf("🎨 Thème", "🖼️ Fond d'écran", "🧩 Pack d'icônes", "↕️ Tri du tiroir",
            "🔒 Écran de verrouillage Nebula : ${if (prefs.lockEnabled) "ON" else "OFF"}", "🌌 Fond animé système (live wallpaper)",
            "👆 Double-tap pour verrouiller (accessibilité)", "⏱️ Autoriser temps d'écran", "🎯 Mode Focus : ${if (prefs.focus) "ON" else "OFF"}")
        AlertDialog.Builder(this).setItems(items) { _, i ->
            when (i) {
                0 -> pick(Themes.all.map { it.name }) { prefs.theme = it; recreate() }
                1 -> pick(listOf("Particules", "Vagues fluides", "Motifs géométriques", "Nébuleuse", "Image de la galerie…", "Vidéo…",
                    "🦋 Papillon", "🐦 Oiseaux", "🌸 Printemps", "☀️ Été", "🍂 Automne", "❄️ Hiver", "🕒 Saisons selon l'heure (6 h chacune)",
                    "🌱 Fleur qui naît et fleurit", "🏖️ Plage & ville (heure réelle)")) { k ->
                    if (k < 4 || k >= 6) { prefs.bgMode = k; applyBackground() }
                    else { pickKind = k - 4; picker.launch(arrayOf(if (k == 4) "image/*" else "video/*")) }
                }
                2 -> {
                    val packs = IconPacks.available(packageManager)
                    pick(listOf("Par défaut") + packs.map { it.second }) { k -> prefs.iconPack = if (k == 0) "" else packs[k - 1].first; reloadApps() }
                }
                3 -> pick(listOf("A–Z", "Fréquence d'utilisation", "Couleur dominante")) { prefs.sort = it; refreshDrawer() }
                4 -> toggleLock()
                5 -> try {
                    startActivity(Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
                        .putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, ComponentName(this, NebulaWallpaperService::class.java)))
                } catch (_: Exception) { startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER)) }
                6 -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                7 -> startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                8 -> setFocus(!prefs.focus)
            }
        }.show()
    }
    private fun pick(items: List<String>, cb: (Int) -> Unit) =
        AlertDialog.Builder(this).setItems(items.toTypedArray()) { _, i -> cb(i) }.show()

    private fun toggleLock() {
        if (!prefs.lockEnabled) {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Autorise « Affichage par-dessus d'autres applis »", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))); return
            }
            prefs.lockEnabled = true; startForegroundService(Intent(this, LockService::class.java))
            if (!MediaHelper.hasAccess(this)) startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        } else { prefs.lockEnabled = false; stopService(Intent(this, LockService::class.java)) }
    }

    private fun reloadApps() {
        Thread {
            val l = repo.load()
            h.post { apps = l; refreshDock(); refreshDrawer() }
        }.start()
    }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); if (ccOpen) closeCC(); if (searchOpen) closeSearch(); if (drawerOpen) closeDrawer() }
    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r); Weather.fetch(this) { s -> h.post { weather.text = s } }
    }
    override fun onResume() {
        super.onResume(); tilt.start(); h.post(loop)
        Weather.fetch(this) { s -> h.post { weather.text = s } }
        if (prefs.bgMode == 5) try { bgVideo.start() } catch (_: Exception) {}
    }
    override fun onPause() { super.onPause(); tilt.stop(); h.removeCallbacks(loop) }
}
