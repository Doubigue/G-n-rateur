import 'package:flutter/material.dart';

void main() => runApp(const TestApp());

class TestApp extends StatelessWidget {
  const TestApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Test APK Studio',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF8B9BFF),
        brightness: Brightness.dark,
      ),
      home: const Accueil(),
    );
  }
}

class Accueil extends StatefulWidget {
  const Accueil({super.key});

  @override
  State<Accueil> createState() => _AccueilState();
}

class _AccueilState extends State<Accueil> {
  int _compteur = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.check_circle, size: 72, color: Color(0xFF5EEAD4)),
              const SizedBox(height: 16),
              const Text(
                'Ton APK Flutter fonctionne !',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 32),
              AnimatedSwitcher(
                duration: const Duration(milliseconds: 250),
                child: Text(
                  '$_compteur',
                  key: ValueKey(_compteur),
                  style: const TextStyle(fontSize: 80, fontWeight: FontWeight.bold),
                ),
              ),
              const SizedBox(height: 24),
              FilledButton.icon(
                onPressed: () => setState(() => _compteur++),
                icon: const Icon(Icons.add),
                label: const Text('Ajouter 1'),
              ),
              TextButton(
                onPressed: () => setState(() => _compteur = 0),
                child: const Text('Remettre à zéro'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
