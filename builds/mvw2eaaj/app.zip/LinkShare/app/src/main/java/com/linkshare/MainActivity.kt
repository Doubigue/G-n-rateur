package com.linkshare

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import android.app.NotificationManager
import com.linkshare.client.TransferManager
import com.linkshare.client.TransferNotifier
import com.linkshare.ui.LinkShareApp
import com.linkshare.ui.MainViewModel

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onStart() {
        super.onStart()
        TransferManager.appVisible = true
        getSystemService(NotificationManager::class.java).cancel(TransferNotifier.ID)
    }

    override fun onStop() {
        super.onStop()
        TransferManager.appVisible = false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface { LinkShareApp(vm) }
            }
        }
    }
}
