package com.linkshare.core

import android.net.Uri
import android.util.Base64
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.serialization.Serializable
import java.io.File
import java.net.Inet4Address
import java.net.NetworkInterface
import java.security.SecureRandom

const val PORT = 8765
const val BUF = 512 * 1024

@Serializable data class DeviceInfo(val name: String, val version: Int = 1)
@Serializable data class FileEntry(val name: String, val path: String, val isDir: Boolean, val size: Long, val modified: Long)
@Serializable data class Listing(val path: String, val entries: List<FileEntry>)
@Serializable data class AppEntry(
    val name: String, val pkg: String, val version: String,
    val size: Long, val isSystem: Boolean, val split: Boolean,
)

private val IMG = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp")
private val AV = setOf("mp4", "mkv", "webm", "3gp", "mov", "avi", "mp3", "m4a", "aac", "ogg", "opus", "wav", "flac")
fun FileEntry.ext() = name.substringAfterLast('.', "").lowercase()
fun FileEntry.isImage() = ext() in IMG
fun FileEntry.isAv() = ext() in AV

/** Données du QR code : linkshare://host:port?token=...&name=... */
data class Connection(val host: String, val port: Int, val token: String, val name: String) {
    companion object {
        fun parse(s: String): Connection? {
            val u = Uri.parse(s)
            if (u.scheme != "linkshare") return null
            val host = u.host ?: return null
            val port = u.port.takeIf { it > 0 } ?: return null
            val token = u.getQueryParameter("token") ?: return null
            return Connection(host, port, token, u.getQueryParameter("name") ?: host)
        }
    }
}

data class ShareInfo(val host: String, val port: Int, val token: String, val name: String) {
    fun toUri() = "linkshare://$host:$port?token=$token&name=${Uri.encode(name)}"
}

object ShareState {
    val info = MutableStateFlow<ShareInfo?>(null)
    /** Nombre de requêtes HTTP en cours côté serveur. */
    val active = MutableStateFlow(0)
    fun newToken(): String {
        val b = ByteArray(24).also { SecureRandom().nextBytes(it) }
        return Base64.encodeToString(b, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    }
}

/** Racine partagée + protection contre ../ et les liens symboliques. */
class SharedRoot(val root: File) {
    private val canon = root.canonicalFile
    fun resolve(rel: String): File? {
        val f = File(canon, rel).canonicalFile
        return if (f == canon || f.path.startsWith(canon.path + File.separator)) f else null
    }
    fun relative(f: File): String = f.relativeTo(canon).path.replace(File.separatorChar, '/')
    val dir get() = canon
}

object NetUtil {
    /** IP locale (Wi-Fi, hotspot ou groupe Wi-Fi Direct). */
    fun localIp(): String {
        val cands = NetworkInterface.getNetworkInterfaces()?.toList().orEmpty()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { ni ->
                ni.inetAddresses.toList().filterIsInstance<Inet4Address>()
                    .filter { it.isSiteLocalAddress }.map { ni.name to it.hostAddress!! }
            }
        val preferred = cands.firstOrNull { (n, _) ->
            n.startsWith("wlan") || n.startsWith("ap") || n.startsWith("swlan") || n.startsWith("p2p")
        }
        return (preferred ?: cands.firstOrNull())?.second ?: "0.0.0.0"
    }
}
