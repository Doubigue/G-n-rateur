package com.linkshare.client

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.linkshare.MainActivity
import com.linkshare.R

/** Notification de fin de transfert (affichée seulement si l'app n'est pas à l'écran). */
object TransferNotifier {
    const val ID = 4
    private const val CH = "transfer_done"

    fun post(ctx: Context, results: List<TransferManager.Result>) {
        if (results.isEmpty()) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Transferts terminés", NotificationManager.IMPORTANCE_DEFAULT))

        val ok = results.count { it.ok }
        val ko = results.size - ok
        val title = when {
            ko == 0 && results.size == 1 -> "Transfert terminé ✓"
            ko == 0 -> "$ok transferts terminés ✓"
            ok == 0 -> "Transfert échoué ✗"
            else -> "$ok réussi(s), $ko échec(s)"
        }
        val text = if (results.size == 1) results[0].text else "Touche pour ouvrir LinkShare"
        val inbox = NotificationCompat.InboxStyle().setBigContentTitle(title)
        results.take(6).forEach { inbox.addLine((if (it.ok) "✓ " else "✗ ") + it.text) }
        if (results.size > 6) inbox.setSummaryText("+${results.size - 6} autre(s)")

        val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        nm.notify(
            ID,
            NotificationCompat.Builder(ctx, CH)
                .setSmallIcon(R.drawable.ic_stat_share)
                .setColor(0xFF1E6FEB.toInt())
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(inbox)
                .setContentIntent(open)
                .setAutoCancel(true)
                .setCategory(NotificationCompat.CATEGORY_STATUS)
                .build()
        )
    }
}
