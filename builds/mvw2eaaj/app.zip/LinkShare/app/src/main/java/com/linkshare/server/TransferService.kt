package com.linkshare.server

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.linkshare.MainActivity
import com.linkshare.R
import com.linkshare.client.TransferManager
import kotlinx.coroutines.*

/** Service au premier plan actif tant qu'au moins un transfert (envoi ou téléchargement) est en cours. */
class TransferService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val nm by lazy { getSystemService(NotificationManager::class.java) }
    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null
    private var started = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        nm.createNotificationChannel(
            NotificationChannel(CH, "Transferts", NotificationManager.IMPORTANCE_LOW).apply { setShowBadge(false) }
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL) TransferManager.cancelAll()
        // Toujours appeler startForeground en premier (obligatoire après startForegroundService)
        ServiceCompat.startForeground(this, ID, build(TransferManager.label.value), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        if (!started) {
            started = true
            wake = getSystemService(PowerManager::class.java)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "linkshare:transfer")
                .apply { setReferenceCounted(false); acquire(2 * 60 * 60_000L) }
            wifi = (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager)
                .createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "linkshare:transfer").apply { acquire() }
            // Le service s'arrête tout seul quand plus aucun transfert n'est actif
            scope.launch { TransferManager.active.collect { if (it <= 0) stopSelf() } }
            scope.launch { TransferManager.label.collect { nm.notify(ID, build(it)); delay(500) } }
        }
        return START_NOT_STICKY
    }

    // Android 14 (1 argument) et 15 (2 arguments) : limite de durée des services dataSync
    override fun onTimeout(startId: Int) = handleTimeout()
    override fun onTimeout(startId: Int, fgsType: Int) = handleTimeout()

    private fun handleTimeout() {
        TransferManager.cancelAll()
        stopSelf()
    }

    override fun onDestroy() {
        scope.cancel()
        wake?.takeIf { it.isHeld }?.release()
        wifi?.takeIf { it.isHeld }?.release()
        super.onDestroy()
    }

    private fun build(label: String): Notification {
        val cancel = PendingIntent.getService(this, 1, Intent(this, TransferService::class.java).setAction(ACTION_CANCEL), PendingIntent.FLAG_IMMUTABLE)
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat_share)
            .setColor(0xFF1E6FEB.toInt())
            .setContentTitle("Transfert en cours")
            .setContentText(label.ifEmpty { "Préparation…" })
            .setProgress(0, 0, true)
            .setContentIntent(open)
            .addAction(0, "Annuler", cancel)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    companion object {
        const val CH = "transfer"
        const val ID = 2
        const val ACTION_CANCEL = "com.linkshare.CANCEL_TRANSFER"
    }
}
