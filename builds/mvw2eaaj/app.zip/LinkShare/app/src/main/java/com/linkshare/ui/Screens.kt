package com.linkshare.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.provider.Settings
import android.text.format.Formatter
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import com.linkshare.core.*
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp
import com.linkshare.R
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import com.linkshare.server.ShareService

@Composable
fun LinkShareApp(vm: MainViewModel) {
    var splash by rememberSaveable { mutableStateOf(true) }
    Crossfade(targetState = splash, label = "splash") { showSplash ->
        if (showSplash) SplashScreen { splash = false }
        else when {
            vm.viewer != null -> ViewerScreen(vm)
            vm.client != null -> RemoteScreen(vm)
            else -> HomeScreen(vm)
        }
    }
}

@Composable
fun SplashScreen(onDone: () -> Unit) {
    val scale = remember { Animatable(0.5f) }
    val logoAlpha = remember { Animatable(0f) }
    val credit = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        launch { scale.animateTo(1f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow)) }
        launch { logoAlpha.animateTo(1f, tween(700)) }
        delay(500)
        credit.animateTo(1f, tween(700))
        delay(1300)
        onDone()
    }
    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF1E6FEB), Color(0xFF123F96))))
            .systemBarsPadding()
    ) {
        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier.size(190.dp).scale(scale.value).alpha(logoAlpha.value)
                    .clip(CircleShape).background(Color.White.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center,
            ) {
                Image(painterResource(R.drawable.ic_launcher_foreground), null, Modifier.size(170.dp))
            }
            Spacer(Modifier.height(20.dp))
            Text("LinkShare", Modifier.alpha(logoAlpha.value), color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.ExtraBold)
            Text("Partage ultra-rapide", Modifier.alpha(logoAlpha.value), color = Color.White.copy(alpha = 0.8f), fontSize = 15.sp)
        }
        Column(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 36.dp).alpha(credit.value),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text("Created by", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
            Text("DL VIBE STUDIO", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 3.sp)
            Text("Doubigue Loubikoa", color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp)
        }
    }
}

private fun ensureAllFiles(ctx: Context): Boolean {
    if (Environment.isExternalStorageManager()) return true
    ctx.startActivity(
        Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${ctx.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    )
    Toast.makeText(ctx, "Autorise l'accès à tous les fichiers, puis réessaie", Toast.LENGTH_LONG).show()
    return false
}

/** Demande une seule fois d'ignorer l'optimisation de batterie (évite que le système tue le partage). */
private fun askBatteryExemptionOnce(ctx: Context) {
    val prefs = ctx.getSharedPreferences("linkshare", Context.MODE_PRIVATE)
    val pm = ctx.getSystemService(PowerManager::class.java)
    if (pm.isIgnoringBatteryOptimizations(ctx.packageName) || prefs.getBoolean("battery_asked", false)) return
    prefs.edit().putBoolean("battery_asked", true).apply()
    ctx.startActivity(
        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    )
}

private fun needsNotifPermission(ctx: Context) =
    Build.VERSION.SDK_INT >= 33 &&
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED

private fun qr(text: String): Bitmap {
    val n = 640
    val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, n, n)
    return Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888).also { b ->
        for (x in 0 until n) for (y in 0 until n)
            b.setPixel(x, y, if (m.get(x, y)) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
    }
}

private fun scan(ctx: Context, onResult: (Connection) -> Unit) {
    val opts = GmsBarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()
    GmsBarcodeScanning.getClient(ctx, opts).startScan()
        .addOnSuccessListener { b ->
            val c = Connection.parse(b.rawValue ?: "")
            if (c != null) onResult(c) else Toast.makeText(ctx, "QR non reconnu", Toast.LENGTH_SHORT).show()
        }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ActionCard(title: String, subtitle: String, icon: Int, colors: List<Color>, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(32.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(
            Modifier.background(Brush.linearGradient(colors)).padding(28.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(
                Modifier.size(120.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center,
            ) { Image(painterResource(icon), null, Modifier.size(72.dp)) }
            Spacer(Modifier.height(16.dp))
            Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Text(subtitle, color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun HomeScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val info by ShareState.info.collectAsState()
    fun startSharing() {
        ContextCompat.startForegroundService(ctx, Intent(ctx, ShareService::class.java))
        askBatteryExemptionOnce(ctx)
    }
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { startSharing() }
    fun scanNow() = scan(ctx) { vm.connect(it); askBatteryExemptionOnce(ctx) }
    val notifScan = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { scanNow() }

    LaunchedEffect(vm.message) { vm.message?.let { Toast.makeText(ctx, it, Toast.LENGTH_LONG).show(); vm.message = null } }

    BoxWithConstraints(Modifier.fillMaxSize().systemBarsPadding()) {
        Column(
            Modifier.verticalScroll(rememberScrollState()).heightIn(min = maxHeight).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp, Alignment.CenterVertically),
        ) {
            Text("LinkShare", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)

            val i = info
            if (i == null) {
                ActionCard(
                    title = "Partager mon téléphone",
                    subtitle = "Affiche un QR code pour que l'autre téléphone se connecte",
                    icon = R.drawable.ic_card_share,
                    colors = listOf(Color(0xFF1E6FEB), Color(0xFF6A5AE0)),
                ) {
                    if (ensureAllFiles(ctx)) {
                        if (Build.VERSION.SDK_INT >= 33 &&
                            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                        ) notif.launch(Manifest.permission.POST_NOTIFICATIONS) else startSharing()
                    }
                }
            } else {
                val bmp = remember(i) { qr(i.toUri()) }
                Card(shape = RoundedCornerShape(32.dp), elevation = CardDefaults.cardElevation(10.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(24.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Image(bmp.asImageBitmap(), "QR code", Modifier.size(240.dp).clip(RoundedCornerShape(16.dp)))
                        Spacer(Modifier.height(12.dp))
                        Text("${i.host}:${i.port}", fontWeight = FontWeight.Bold)
                        Text(
                            "Quiconque scanne ce code accède à tes fichiers. Arrête le partage quand tu as fini.",
                            style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center,
                        )
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(onClick = { ctx.stopService(Intent(ctx, ShareService::class.java)) }) { Text("Arrêter le partage") }
                    }
                }
            }

            ActionCard(
                title = "Se connecter à un téléphone",
                subtitle = "Scanne son QR code pour parcourir ses fichiers et apps",
                icon = R.drawable.ic_card_scan,
                colors = listOf(Color(0xFF0F9B8E), Color(0xFF2EB872)),
            ) {
                if (ensureAllFiles(ctx)) {
                    if (needsNotifPermission(ctx)) notifScan.launch(Manifest.permission.POST_NOTIFICATIONS) else scanNow()
                }
            }

            vm.status?.let {
                Text(it, style = MaterialTheme.typography.bodySmall)
                LinearProgressIndicator(Modifier.fillMaxWidth())
            }
            Text(
                "Même Wi-Fi, ou l'un sur le point d'accès de l'autre",
                style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center,
            )
            Text("DL VIBE STUDIO", fontSize = 11.sp, letterSpacing = 2.sp, color = MaterialTheme.colorScheme.outline)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RemoteScreen(vm: MainViewModel) {
    var tab by remember { mutableIntStateOf(0) }
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(vm.message) { vm.message?.let { snack.showSnackbar(it); vm.message = null } }
    BackHandler { if (tab == 0 && vm.path.isNotEmpty()) vm.up() else vm.disconnect() }

    val pickFiles = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { vm.uploadFiles(it) }
    val pickTree = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { it?.let(vm::uploadFolder) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(vm.deviceName) },
                navigationIcon = { TextButton(onClick = { vm.disconnect() }) { Text("✕") } },
            )
        },
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({ pickFiles.launch(arrayOf("*/*")) }, Modifier.weight(1f)) { Text("Envoyer fichiers") }
                Button({ pickTree.launch(null) }, Modifier.weight(1f)) { Text("Envoyer dossier") }
            }
        },
    ) { pad ->
        Column(Modifier.padding(pad)) {
            TabRow(selectedTabIndex = tab) {
                Tab(tab == 0, { tab = 0 }, text = { Text("Fichiers") })
                Tab(tab == 1, { tab = 1 }, text = { Text("Applications") })
            }
            vm.status?.let {
                Column(Modifier.padding(8.dp)) {
                    Text(it, style = MaterialTheme.typography.bodySmall)
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                }
            }
            if (tab == 0) FilesTab(vm) else AppsTab(vm)
        }
    }
}

@Composable
private fun FilesTab(vm: MainViewModel) {
    val ctx = LocalContext.current
    Text("/" + vm.path, Modifier.padding(horizontal = 16.dp, vertical = 8.dp), style = MaterialTheme.typography.labelLarge)
    LazyColumn {
        if (vm.path.isNotEmpty()) item {
            ListItem(
                headlineContent = { Text("..") },
                leadingContent = { Text("📁") },
                modifier = Modifier.clickable { vm.up() },
            )
        }
        items(vm.entries, key = { it.path }) { e ->
            var menu by remember { mutableStateOf(false) }
            ListItem(
                headlineContent = { Text(e.name, maxLines = 1) },
                supportingContent = { if (!e.isDir) Text(Formatter.formatShortFileSize(ctx, e.size)) },
                leadingContent = { Text(if (e.isDir) "📁" else "📄") },
                trailingContent = {
                    Box {
                        TextButton({ menu = true }) { Text("⋮") }
                        DropdownMenu(menu, { menu = false }) {
                            DropdownMenuItem(
                                text = { Text(if (e.isDir) "Télécharger le dossier" else "Télécharger") },
                                onClick = { menu = false; vm.download(e) },
                            )
                        }
                    }
                },
                modifier = Modifier.clickable { vm.tap(e) },
            )
        }
    }
}

@Composable
private fun AppsTab(vm: MainViewModel) {
    val ctx = LocalContext.current
    var system by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { vm.loadApps() }
    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Switch(system, { system = it })
        Spacer(Modifier.width(12.dp))
        Text("Afficher les apps système")
    }
    LazyColumn {
        items(vm.apps.filter { system || !it.isSystem }, key = { it.pkg }) { a ->
            ListItem(
                leadingContent = { AsyncImage(vm.client?.iconUrl(a.pkg), null, Modifier.size(40.dp)) },
                headlineContent = { Text(a.name, maxLines = 1) },
                supportingContent = {
                    Text("${a.version} · ${Formatter.formatShortFileSize(ctx, a.size)}" + if (a.split) " · .apks" else "")
                },
                modifier = Modifier.clickable { vm.downloadApp(a) },
            )
        }
    }
}

@Composable
fun ViewerScreen(vm: MainViewModel) {
    val e = vm.viewer ?: return
    val url = vm.client?.fileUrl(e.path) ?: return
    BackHandler { vm.viewer = null }
    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton({ vm.viewer = null }) { Text("←") }
            Text(e.name, maxLines = 1)
        }
        if (e.isImage()) AsyncImage(url, e.name, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
        else Player(url)
    }
}

@Composable
private fun Player(url: String) {
    val ctx = LocalContext.current
    val player = remember {
        ExoPlayer.Builder(ctx).build().apply {
            setMediaItem(MediaItem.fromUri(url)); prepare(); playWhenReady = true
        }
    }
    DisposableEffect(Unit) { onDispose { player.release() } }
    AndroidView(factory = { PlayerView(it).also { v -> v.player = player } }, modifier = Modifier.fillMaxSize())
}
