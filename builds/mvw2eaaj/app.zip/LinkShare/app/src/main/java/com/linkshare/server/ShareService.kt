package com.linkshare.server

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.TrafficStats
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.Process
import android.text.format.Formatter
import android.view.View
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.linkshare.MainActivity
import com.linkshare.R
import com.linkshare.core.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collectLatest

class ShareService : Service() {
    private var server: ShareServer? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val nm by lazy { getSystemService(NotificationManager::class.java) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        nm.createNotificationChannel(
            NotificationChannel(CH, "Partage", NotificationManager.IMPORTANCE_LOW).apply { setShowBadge(false) }
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        ServiceCompat.startForeground(this, ID, build(0, 0, 0, 0), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        if (server == null) {
            val token = ShareState.newToken()
            server = ShareServer(applicationContext, token).also { it.start() }
            ShareState.info.value = ShareInfo(NetUtil.localIp(), PORT, token, Build.MODEL)
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "linkshare").apply { acquire() }
            scope.launch { tick() }
            // Verrou CPU uniquement pendant qu'une requête est en cours (économise la batterie)
            val wake = getSystemService(PowerManager::class.java)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "linkshare:share")
                .apply { setReferenceCounted(false) }
            wakeLock = wake
            scope.launch {
                ShareState.active.collectLatest { n ->
                    if (n > 0) {
                        while (true) { wake.acquire(5 * 60_000L); delay(4 * 60_000L) }
                    } else {
                        delay(5_000)
                        if (wake.isHeld) wake.release()
                    }
                }
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        server?.stop(); server = null
        wifiLock?.takeIf { it.isHeld }?.release()
        wakeLock?.takeIf { it.isHeld }?.release()
        ShareState.info.value = null
        ShareState.active.value = 0
        super.onDestroy()
    }

    // Android 14/15 coupe les services dataSync après 6 h : on s'arrête proprement et on prévient l'utilisateur
    override fun onTimeout(startId: Int) = handleTimeout()
    override fun onTimeout(startId: Int, fgsType: Int) = handleTimeout()

    private fun handleTimeout() {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        nm.notify(
            ID_INFO,
            NotificationCompat.Builder(this, CH)
                .setSmallIcon(R.drawable.ic_stat_share)
                .setContentTitle("Partage arrêté")
                .setContentText("Android limite les partages à 6 h. Rouvre l'app pour relancer.")
                .setContentIntent(open)
                .setAutoCancel(true)
                .build()
        )
        stopSelf()
    }

    /** Met à jour la notification chaque seconde avec la vitesse réelle (compteurs réseau de l'app). */
    private suspend fun tick() {
        val uid = Process.myUid()
        fun tx() = TrafficStats.getUidTxBytes(uid).coerceAtLeast(0)
        fun rx() = TrafficStats.getUidRxBytes(uid).coerceAtLeast(0)
        val t0 = tx(); val r0 = rx()
        var lt = t0; var lr = r0
        val pm = getSystemService(PowerManager::class.java)
        while (currentCoroutineContext().isActive) {
            delay(1000)
            val t = tx(); val r = rx()
            if (pm.isInteractive) nm.notify(ID, build(t - lt, r - lr, t - t0, r - r0)) // écran éteint : on économise la batterie
            lt = t; lr = r
        }
    }

    private fun speed(b: Long) = Formatter.formatShortFileSize(this, b) + "/s"
    private fun size(b: Long) = Formatter.formatShortFileSize(this, b)

    private fun build(dTx: Long, dRx: Long, totTx: Long, totRx: Long): Notification {
        val busy = dTx + dRx > BUSY_BYTES_PER_SEC
        val host = ShareState.info.value?.let { "${it.host}:${it.port}" } ?: ""
        val title = if (busy) "Transfert en cours" else "Partage actif"
        val line = if (busy) "↑ ${speed(dTx)}    ↓ ${speed(dRx)}" else "En attente · $host"
        val total = "Session : ↑ ${size(totTx)} · ↓ ${size(totRx)}"

        fun views(big: Boolean) = RemoteViews(packageName, if (big) R.layout.notification_share_big else R.layout.notification_share).apply {
            setTextViewText(R.id.title, title)
            setTextViewText(R.id.line, line)
            if (big) setTextViewText(R.id.total, total)
            setViewVisibility(R.id.active, if (busy) View.VISIBLE else View.GONE)
            setViewVisibility(R.id.idle, if (busy) View.GONE else View.VISIBLE)
            setViewVisibility(R.id.bar, if (busy) View.VISIBLE else View.GONE)
        }

        val stop = PendingIntent.getService(this, 0, Intent(this, ShareService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)

        return NotificationCompat.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat_share)
            .setColor(0xFF1E6FEB.toInt())
            .setContentTitle(title)
            .setContentText(line)
            .setStyle(NotificationCompat.DecoratedCustomViewStyle())
            .setCustomContentView(views(false))
            .setCustomBigContentView(views(true))
            .setContentIntent(open)
            .addAction(0, "Afficher le QR", open)
            .addAction(0, "Arrêter", stop)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    companion object {
        const val CH = "share"
        const val ID = 1
        const val ID_INFO = 3
        const val ACTION_STOP = "com.linkshare.STOP"
        private const val BUSY_BYTES_PER_SEC = 20_000L
    }
}
