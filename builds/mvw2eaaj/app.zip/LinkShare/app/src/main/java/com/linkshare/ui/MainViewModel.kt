package com.linkshare.ui

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import android.text.format.Formatter
import androidx.compose.runtime.*
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.linkshare.client.RemoteClient
import com.linkshare.client.TransferManager
import com.linkshare.core.*
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.util.concurrent.atomic.AtomicInteger

class MainViewModel(app: Application) : AndroidViewModel(app) {
    var client by mutableStateOf<RemoteClient?>(null); private set
    var deviceName by mutableStateOf("")
    var path by mutableStateOf("")
    var entries by mutableStateOf<List<FileEntry>>(emptyList())
    var apps by mutableStateOf<List<AppEntry>>(emptyList())
    var viewer by mutableStateOf<FileEntry?>(null)
    var status by mutableStateOf<String?>(null)
    var message by mutableStateOf<String?>(null)

    private val ctx get() = getApplication<Application>()
    private fun size(n: Long) = Formatter.formatShortFileSize(ctx, n)

    private fun launchSafe(block: suspend () -> Unit) = viewModelScope.launch {
        try { block() }
        catch (e: CancellationException) { throw e }
        catch (e: Exception) { message = e.message ?: e.toString(); status = null }
    }

    /** Les transferts tournent hors de l'écran, protégés par un service au premier plan. */
    private fun transfer(block: suspend () -> Unit) =
        TransferManager.launch(ctx, { message = it.message ?: it.toString(); status = null }, block)

    private fun progress(text: String) { status = text; TransferManager.label.value = text }

    fun connect(c: Connection) = launchSafe {
        status = "Connexion à ${c.name}…"
        val rc = RemoteClient(c)
        val info = try { rc.info() } catch (e: Exception) { rc.close(); throw e }
        client = rc; deviceName = info.name
        browse("")
        status = null
    }

    fun disconnect() {
        client?.close(); client = null; viewer = null
        entries = emptyList(); apps = emptyList(); path = ""
    }

    private suspend fun browse(p: String) {
        val l = client!!.list(p)
        entries = l.entries; path = l.path
    }

    fun open(p: String) = launchSafe { browse(p) }
    fun up() { if (path.isNotEmpty()) open(path.substringBeforeLast('/', "")) }

    fun tap(e: FileEntry) {
        if (e.isDir) open(e.path) else if (e.isImage() || e.isAv()) viewer = e else download(e)
    }

    fun loadApps() = launchSafe { if (apps.isEmpty()) apps = client?.apps().orEmpty() }

    fun download(e: FileEntry) = transfer {
        val c = client ?: return@transfer
        progress("Téléchargement de ${e.name}…")
        val f = if (e.isDir) c.downloadFolder(e.path, e.name) { progress("${e.name} · ${size(it)}") }
        else c.downloadFile(e.path, e.name) { progress("${e.name} · ${size(it)}") }
        status = null; message = "Enregistré : ${f.path}"
        TransferManager.report(true, "${e.name} enregistré dans Download/LinkShare")
    }

    fun downloadApp(a: AppEntry) = transfer {
        val c = client ?: return@transfer
        progress("Téléchargement de ${a.name}…")
        val f = c.downloadApk(a.pkg, a.split) { progress("${a.name} · ${size(it)}") }
        status = null; message = "Enregistré : ${f.path}"
        TransferManager.report(true, "${a.name} (APK) enregistré dans Download/LinkShare")
    }

    fun uploadFiles(uris: List<Uri>) = transfer { sendAll(uris.map { it to displayName(it) }) }

    fun uploadFolder(tree: Uri) = transfer {
        val root = DocumentFile.fromTreeUri(ctx, tree) ?: return@transfer
        val items = mutableListOf<Pair<Uri, String>>()
        fun walk(d: DocumentFile, prefix: String) {
            d.listFiles().forEach {
                if (it.isDirectory) walk(it, "$prefix${it.name}/") else items += it.uri to "$prefix${it.name}"
            }
        }
        withContext(Dispatchers.IO) { walk(root, "${root.name}/") }
        sendAll(items)
    }

    /** Envoi parallèle (4 flux) : bien plus rapide pour beaucoup de petits fichiers. */
    private suspend fun sendAll(items: List<Pair<Uri, String>>) {
        val c = client ?: return
        if (items.isEmpty()) return
        val sem = Semaphore(4); val done = AtomicInteger(0)
        progress("Envoi 0/${items.size}")
        coroutineScope {
            items.map { (u, n) ->
                async(Dispatchers.IO) {
                    sem.withPermit { c.upload(ctx, u, n); progress("Envoi ${done.incrementAndGet()}/${items.size}") }
                }
            }.awaitAll()
        }
        status = null
        message = "${items.size} fichier(s) envoyé(s) dans Download/LinkShare"
        TransferManager.report(true, "${items.size} fichier(s) envoyé(s) vers $deviceName")
    }

    private fun displayName(u: Uri): String =
        ctx.contentResolver.query(u, null, null, null, null)?.use {
            if (it.moveToFirst()) it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
        } ?: "fichier"
}
