# LocalShare 4.0 — améliorations

- Dossier visible `LocalShare` dans le stockage, créé automatiquement.
- Sous-dossiers automatiques : `Vidéo`, `Documents`, `Musique`, `Application`, `Autres`.
- Les fichiers reçus sont classés automatiquement selon leur extension.
- Le partage Android `Partager → Local Share` reste pris en charge pour `SEND` et `SEND_MULTIPLE` : le fichier arrive dans la file d'envoi à l'ouverture de l'application.
- Progression et notifications de transfert conservées, avec ouverture du fichier reçu depuis la notification lorsqu'un fichier unique est terminé.
- Nouvelle apparence `Système / Clair / Sombre`.
- Interface claire plus lumineuse, tout en conservant le thème sombre.
- Les fonctions existantes (Wi‑Fi Direct, hotspot, serveur web/QR, explorateur de fichiers, etc.) sont conservées.

## Local Share File Manager 4.1

- Nouveau tableau de bord type gestionnaire de fichiers.
- Recherche de fichiers depuis l'accueil et recherche récursive dans LocalShare.
- Vue grille par défaut dans l'explorateur, avec bascule grille/liste.
- Catégories Vidéo, Documents, Musique, Application et Autres avec compteurs.
- Carte stockage et indicateur d'utilisation.
- Accès direct Envoyer / Reçus depuis l'accueil.
- Intégration conservée avec le menu Partager Android : les fichiers partagés sont préparés dans la file d'envoi.
- Réception automatique classée dans les sous-dossiers LocalShare.

## Local Share 4.4 — Scanner

- Nouvelle carte **Scanner**, placée en premier dans l'écran Local Share.
- Détection automatique des bords, recadrage, plusieurs pages, import depuis la galerie, export en PDF (scanner Google ML Kit, aucune permission caméra).
- Le PDF `Scan_AAAAMMJJ_HHMMSS.pdf` est enregistré dans `LocalShare/Documents`, puis on peut l'**envoyer** (file d'envoi Local Share) ou l'**ouvrir**.
- Sans Google Play Services : repli sur l'appareil photo du système, photo convertie en PDF (une page par photo).
- Correction de compilation : les styles du tiroir (`EX.Drawer*`) sont renommés `ExDrawer*` (sans point, donc sans parent implicite `EX`).
