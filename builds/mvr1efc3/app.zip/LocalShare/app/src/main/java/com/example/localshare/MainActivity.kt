package com.example.localshare

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.launch

/** Accueil : appareils à proximité en Wi-Fi Direct, connexion, partage depuis le menu « Partager » d'Android. */
class MainActivity : AppCompatActivity() {

    private val p2p get() = app.p2p
    private val transfers get() = app.transfers

    private lateinit var tvName: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvShare: TextView
    private lateinit var tvEmpty: TextView
    private lateinit var btnFix: Button
    private lateinit var btnOpen: Button
    private lateinit var adapter: RowAdapter<Peer>
    private lateinit var tiles: TileAdapter
    private lateinit var categories: CategoryAdapter
    private lateinit var etSearch: EditText
    private lateinit var tvStorage: TextView
    private lateinit var storageProgress: ProgressBar
    private lateinit var tvReceivedCount: TextView
    private var visibleToOthers = true

    private var pendingDialog: AlertDialog? = null
    private var shownPendingCode: String? = null
    private var lastOpenedId: String? = null
    private var askedOnce = false
    private var fromFix = false

    /** Scanner de documents (doit être créé ici : les lanceurs s'enregistrent avant le démarrage de l'écran). */
    private val docScanner = DocScanner(this)

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (fromFix && !p2p.hasPermission()) openAppSettings()
            fromFix = false
            p2p.start()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        val savedMode = getSharedPreferences("settings", MODE_PRIVATE).getInt("night_mode", AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        AppCompatDelegate.setDefaultNightMode(savedMode)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        tvName = findViewById(R.id.tvName)
        tvStatus = findViewById(R.id.tvStatus)
        tvShare = findViewById(R.id.tvShare)
        etSearch = findViewById(R.id.etSearch)
        tvStorage = findViewById(R.id.tvStorage)
        storageProgress = findViewById(R.id.storageProgress)
        tvReceivedCount = findViewById(R.id.tvReceivedCount)
        tvEmpty = findViewById(R.id.tvEmpty)
        btnFix = findViewById(R.id.btnFix)
        btnOpen = findViewById(R.id.btnOpen)

        adapter = RowAdapter(
            bind = { h, p ->
                h.title.text = p.name
                h.sub.text = if (p.state == PeerState.CONNECTING) "Connexion…" else "Touchez pour se connecter"
            },
            onClick = { p -> p2p.connectTo(p.id) }
        )
        findViewById<RecyclerView>(R.id.list).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }

        tiles = TileAdapter()
        findViewById<RecyclerView>(R.id.tiles).setupTiles(tiles)
        categories = CategoryAdapter { name ->
            startActivity(Intent(this, BrowserActivity::class.java)
                .putExtra(BrowserActivity.EXTRA_MODE, BrowserActivity.MODE_LOCAL)
                .putExtra(BrowserActivity.EXTRA_CATEGORY, name))
        }
        findViewById<RecyclerView>(R.id.categoryGrid).apply {
            layoutManager = androidx.recyclerview.widget.GridLayoutManager(this@MainActivity, 2)
            adapter = categories
            itemAnimator = null
        }
        findViewById<View>(R.id.cardReceive).setOnClickListener {
            startActivity(Intent(this, BrowserActivity::class.java).putExtra(BrowserActivity.EXTRA_MODE, BrowserActivity.MODE_LOCAL))
        }
        findViewById<View>(R.id.cardSend).setOnClickListener { startActivity(Intent(this, BrowserActivity::class.java).putExtra(BrowserActivity.EXTRA_MODE, BrowserActivity.MODE_LOCAL).putExtra(BrowserActivity.EXTRA_PICK_FOR_SHARE, true)) }
        etSearch.setOnEditorActionListener { _, _, _ -> openSearch(); true }
        findViewById<View>(R.id.btnMore).setOnClickListener { chooseAppearance() }
        renderFileDashboard()

        btnFix.setOnClickListener { onFix() }
        btnOpen.setOnClickListener { startActivity(Intent(this, SessionActivity::class.java)) }
        tvShare.setOnClickListener {
            transfers.clearQueue()
            Toast.makeText(this, "Envoi annulé", Toast.LENGTH_SHORT).show()
        }
        buildTiles()

        if (savedInstanceState == null) handleShareIntent(intent)

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { p2p.state.collect { render(it) } }
                launch { transfers.tick.collect { renderShare() } }
                launch { ServerState.status.collect { buildTiles() } }
                launch { HotspotController.state.collect { buildTiles() } }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleShareIntent(intent)
    }

    override fun onStart() {
        super.onStart()
        ensureAndStart()
        buildTiles()
        renderFileDashboard()
    }

    private fun openSearch() {
        val q = etSearch.text.toString().trim()
        startActivity(Intent(this, BrowserActivity::class.java).putExtra(BrowserActivity.EXTRA_MODE, BrowserActivity.MODE_LOCAL).putExtra(BrowserActivity.EXTRA_QUERY, q))
    }

    private fun renderFileDashboard() {
        val root = Storage.shareDir(this)
        Storage.ensureFolders(this)
        val all = root.walkTopDown().filter { it.isFile && !it.name.endsWith(".part") }.toList()
        val cats = listOf(
            CategoryAdapter.Item(Storage.VIDEO, "🎬", all.count { Storage.categoryFor(it.name) == Storage.VIDEO }),
            CategoryAdapter.Item(Storage.DOCUMENTS, "📄", all.count { Storage.categoryFor(it.name) == Storage.DOCUMENTS }),
            CategoryAdapter.Item(Storage.MUSIC, "🎵", all.count { Storage.categoryFor(it.name) == Storage.MUSIC }),
            CategoryAdapter.Item(Storage.APPLICATION, "📦", all.count { Storage.categoryFor(it.name) == Storage.APPLICATION }),
            CategoryAdapter.Item(Storage.OTHER, "🗂️", all.count { Storage.categoryFor(it.name) == Storage.OTHER })
        )
        categories.submit(cats)
        tvReceivedCount.text = "${all.size} fichier(s) reçus"
        val total = android.os.StatFs(root.absolutePath).totalBytes
        val free = android.os.StatFs(root.absolutePath).availableBytes
        val used = (total - free).coerceAtLeast(0)
        val pct = if (total > 0) ((used * 100.0) / total).toInt().coerceIn(0,100) else 0
        storageProgress.progress = pct
        tvStorage.text = "${Fmt.bytes(used)} utilisés"
    }

    // ---------------------------------------------------------------- tableau de bord (cartes)
    private fun buildTiles() {
        if (!::tiles.isInitialized) return
        val web = ServerState.status.value
        val hs = HotspotController.state.value
        val files = Storage.hasAccess(this)
        tiles.submit(
            listOf(
                Tile(R.drawable.ic_scan, "Scanner", "Document → PDF · recadrage auto") { docScanner.start() },
                Tile(
                    R.drawable.ic_web, "Serveur web",
                    if (web.running) "Actif · port ${web.port}" else "Partage par navigateur + QR Code",
                    active = web.running
                ) { startActivity(Intent(this, WebServerActivity::class.java)) },
                Tile(
                    R.drawable.ic_hotspot, "Point d’accès",
                    when {
                        hs.active -> "Actif · ${hs.ssid}"
                        hs.starting -> "Démarrage…"
                        else -> "Hotspot sans Internet"
                    },
                    active = hs.active
                ) { startActivity(Intent(this, HotspotActivity::class.java)) },
                Tile(R.drawable.ic_download, "Fichiers reçus", "Dossier ${Storage.FOLDER}") {
                    startActivity(Intent(this, BrowserActivity::class.java).putExtra(BrowserActivity.EXTRA_MODE, BrowserActivity.MODE_LOCAL))
                },
                Tile(R.drawable.ic_shield, "Coffre-fort", if (VaultStore.isConfigured(this)) "Fichiers chiffrés · PIN / biométrie" else "Créer votre espace sécurisé") {
                    startActivity(Intent(this, VaultActivity::class.java))
                },
                Tile(
                    R.drawable.ic_visibility, "Visibilité",
                    if (visibleToOthers) "Visible par les autres téléphones" else "Masqué",
                    active = visibleToOthers
                ) {
                    visibleToOthers = !visibleToOthers
                    p2p.setVisible(visibleToOthers)
                    buildTiles()
                },
                Tile(R.drawable.ic_edit, "Mon nom", p2p.state.value.deviceName) { askRename() },
                Tile(
                    R.drawable.ic_shield, "Accès aux fichiers",
                    if (files) "Autorisé" else "À autoriser", active = files
                ) { Storage.requestAccess(this) },
                Tile(R.drawable.ic_battery, "Batterie", "Rester connecté écran éteint") { requestBatteryExemption() },
                Tile(
                    R.drawable.ic_edit, "Apparence", appearanceLabel()
                ) { chooseAppearance() },
                Tile(R.drawable.ic_power, "Quitter", "Arrêter LocalShare", danger = true) {
                    p2p.shutdown()
                    stopService(Intent(this, P2pService::class.java))
                    finishAffinity()
                }
            )
        )
    }

    // ---------------------------------------------------------------- partage Android
    private fun handleShareIntent(i: Intent?) {
        if (i == null) return
        if (i.action == Intent.ACTION_SEND || i.action == Intent.ACTION_SEND_MULTIPLE) {
            transfers.queueFromIntent(i)
            i.action = null
        }
    }

    private fun renderShare() {
        val n = transfers.queuedCount
        tvShare.visibility = if (n > 0) View.VISIBLE else View.GONE
        tvShare.text = "$n élément(s) à envoyer : touchez l’appareil destinataire (touchez ici pour annuler)."
    }

    // ---------------------------------------------------------------- permissions
    private fun neededPermissions(): Array<String> {
        val l = p2p.requiredPermissions().toMutableList()
        if (Build.VERSION.SDK_INT >= 33) l += Manifest.permission.POST_NOTIFICATIONS
        return l.toTypedArray()
    }

    private fun ensureAndStart() {
        if (!p2p.hasPermission() && !askedOnce) {
            askedOnce = true
            permLauncher.launch(neededPermissions())
        } else {
            p2p.start()
        }
    }

    private fun onFix() {
        when {
            !p2p.hasPermission() -> {
                fromFix = true
                permLauncher.launch(neededPermissions())
            }
            p2p.state.value.statusNeedsSettings -> openAppSettings()
            else -> p2p.restart()
        }
    }

    private fun openAppSettings() {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }

    private fun requestBatteryExemption() {
        try {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }



    private fun appearanceLabel(): String = when (
        getSharedPreferences("settings", MODE_PRIVATE).getInt("night_mode", -1)
    ) {
        AppCompatDelegate.MODE_NIGHT_NO -> "Clair"
        AppCompatDelegate.MODE_NIGHT_YES -> "Sombre"
        else -> "Système"
    }

    private fun chooseAppearance() {
        val modes = arrayOf("Système", "Clair", "Sombre")
        val current = when (
            getSharedPreferences("settings", MODE_PRIVATE).getInt("night_mode", -1)
        ) {
            AppCompatDelegate.MODE_NIGHT_NO -> 1
            AppCompatDelegate.MODE_NIGHT_YES -> 2
            else -> 0
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Apparence de LocalShare")
            .setSingleChoiceItems(modes, current) { dialog, which ->
                val mode = when (which) {
                    1 -> AppCompatDelegate.MODE_NIGHT_NO
                    2 -> AppCompatDelegate.MODE_NIGHT_YES
                    else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
                }
                getSharedPreferences("settings", MODE_PRIVATE)
                    .edit().putInt("night_mode", mode).apply()
                AppCompatDelegate.setDefaultNightMode(mode)
                dialog.dismiss()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun askRename() {
        val et = EditText(this).apply { setText(p2p.state.value.deviceName); setSelectAllOnFocus(true) }
        MaterialAlertDialogBuilder(this)
            .setTitle("Nom de votre appareil")
            .setView(et)
            .setPositiveButton("Enregistrer") { _, _ -> p2p.renameDevice(et.text.toString()) }
            .setNegativeButton("Annuler", null)
            .show()
    }

    // ---------------------------------------------------------------- affichage
    private fun render(s: P2pState) {
        tvName.text = "Mon nom : ${s.deviceName}"
        buildTiles()

        val lines = mutableListOf<String>()
        s.status?.let { lines += it }
        s.info?.let { lines += it }
        s.outgoingCode?.let { lines += "Code de vérification : $it (le même doit s’afficher sur l’autre téléphone)" }
        if (lines.isEmpty()) {
            lines += when {
                s.isConnected -> "Connecté à ${s.connectedName}"
                s.advertising && s.discovering -> "Visible comme « ${s.deviceName} » · recherche en cours…"
                s.advertising -> "Visible comme « ${s.deviceName} »"
                s.discovering -> "Recherche d’appareils…"
                else -> "Inactif"
            }
        }
        tvStatus.text = lines.joinToString("\n")

        btnFix.visibility = if (s.status != null) View.VISIBLE else View.GONE
        btnFix.text = if (s.statusNeedsSettings) "Autoriser" else "Réessayer"
        btnOpen.visibility = if (s.isConnected) View.VISIBLE else View.GONE

        val shown = s.peers.filter { it.state != PeerState.CONNECTED }
        adapter.submit(shown)
        tvEmpty.visibility = if (shown.isEmpty()) View.VISIBLE else View.GONE

        // Demande de connexion entrante.
        val pc = s.pending
        if (pc != null) {
            if (pendingDialog?.isShowing != true || shownPendingCode != pc.code) {
                pendingDialog?.dismiss()
                shownPendingCode = pc.code
                pendingDialog = MaterialAlertDialogBuilder(this)
                    .setTitle("Demande de connexion")
                    .setMessage(
                        "« ${pc.name} » veut se connecter à votre appareil (Wi-Fi Direct).\n\n" +
                                "Code : ${pc.code}\nVérifiez que le même code s’affiche sur l’autre appareil."
                    )
                    .setCancelable(false)
                    .setPositiveButton("Accepter") { _, _ -> p2p.acceptPending() }
                    .setNegativeButton("Refuser") { _, _ -> p2p.rejectPending() }
                    .show()
            }
        } else {
            pendingDialog?.dismiss()
            pendingDialog = null
            shownPendingCode = null
        }

        // Session ouverte automatiquement une fois par connexion.
        if (s.connectedId != null) {
            if (s.connectedId != lastOpenedId) {
                lastOpenedId = s.connectedId
                startActivity(Intent(this, SessionActivity::class.java))
            }
        } else {
            lastOpenedId = null
        }
    }

    override fun onDestroy() {
        pendingDialog?.dismiss()
        super.onDestroy()
    }
}
