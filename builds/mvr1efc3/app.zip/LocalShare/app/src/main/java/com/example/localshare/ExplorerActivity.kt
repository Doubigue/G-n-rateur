package com.example.localshare

import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.util.LruCache
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.view.GravityCompat
import androidx.core.view.WindowCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Écran d'accueil : explorateur de fichiers (Récents, Catégories, Collections, Stockage).
 * L'interface Local Share (appareils à proximité, partage) s'ouvre avec l'icône de partage.
 */
class ExplorerActivity : AppCompatActivity() {

    private lateinit var drawer: DrawerLayout
    private lateinit var etSearch: EditText
    private lateinit var bannerAccess: View
    private lateinit var tvNoRecents: TextView
    private lateinit var recentAdapter: RecentAdapter
    private lateinit var categoryAdapter: ExTileAdapter
    private lateinit var collectionAdapter: ExTileAdapter
    private lateinit var storageAdapter: ExTileAdapter

    private var scan: Explorer.Scan? = null
    private var scanJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        val savedMode = getSharedPreferences("settings", MODE_PRIVATE)
            .getInt("night_mode", AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        AppCompatDelegate.setDefaultNightMode(savedMode)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_explorer)

        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                Configuration.UI_MODE_NIGHT_YES
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = !night
            isAppearanceLightNavigationBars = !night
        }

        drawer = findViewById(R.id.drawer)
        etSearch = findViewById(R.id.etSearch)
        bannerAccess = findViewById(R.id.bannerAccess)
        tvNoRecents = findViewById(R.id.tvNoRecents)

        findViewById<View>(R.id.btnMenu).setOnClickListener { drawer.openDrawer(GravityCompat.START) }
        findViewById<View>(R.id.btnSearch).setOnClickListener { openSearch() }
        etSearch.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_DONE) {
                openSearch()
            }
            true
        }
        bannerAccess.setOnClickListener { Storage.requestAccess(this) }
        findViewById<View>(R.id.tvAllRecents).setOnClickListener { openBrowser("Récents", kind = Explorer.RECENT) }

        // Icône de partage : affiche l'interface Local Share.
        findViewById<View>(R.id.btnShare).setOnClickListener { startActivity(Intent(this, MainActivity::class.java)) }
        findViewById<View>(R.id.btnQr).setOnClickListener { startActivity(Intent(this, WebServerActivity::class.java)) }

        // Tiroir latéral.
        findViewById<View>(R.id.drawerShare).setOnClickListener { closeThen { startActivity(Intent(this, MainActivity::class.java)) } }
        findViewById<View>(R.id.drawerVault).setOnClickListener { closeThen { startActivity(Intent(this, VaultActivity::class.java)) } }
        findViewById<View>(R.id.drawerAccess).setOnClickListener { closeThen { Storage.requestAccess(this) } }
        findViewById<View>(R.id.drawerTheme).setOnClickListener { closeThen { chooseAppearance() } }
        findViewById<View>(R.id.drawerQuit).setOnClickListener {
            app.p2p.shutdown()
            stopService(Intent(this, P2pService::class.java))
            finishAffinity()
        }

        recentAdapter = RecentAdapter(lifecycleScope) { f -> Storage.open(this, f) }
        findViewById<RecyclerView>(R.id.recents).apply {
            layoutManager = LinearLayoutManager(this@ExplorerActivity, LinearLayoutManager.HORIZONTAL, false)
            adapter = recentAdapter
        }

        categoryAdapter = ExTileAdapter()
        collectionAdapter = ExTileAdapter()
        storageAdapter = ExTileAdapter()
        findViewById<RecyclerView>(R.id.categories).apply {
            layoutManager = GridLayoutManager(this@ExplorerActivity, 2)
            adapter = categoryAdapter
            itemAnimator = null
        }
        findViewById<RecyclerView>(R.id.collections).apply {
            layoutManager = GridLayoutManager(this@ExplorerActivity, 2)
            adapter = collectionAdapter
            itemAnimator = null
        }
        findViewById<RecyclerView>(R.id.storages).apply {
            layoutManager = GridLayoutManager(this@ExplorerActivity, 2)
            adapter = storageAdapter
            itemAnimator = null
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (drawer.isDrawerOpen(GravityCompat.START)) drawer.closeDrawer(GravityCompat.START)
                else finish()
            }
        })

        buildLists()
    }

    override fun onStart() {
        super.onStart()
        refresh()
    }

    private fun closeThen(action: () -> Unit) {
        drawer.closeDrawer(GravityCompat.START)
        action()
    }

    private fun scanRoot(): File = if (Storage.hasAccess(this)) Storage.root else Storage.shareDir(this)

    private fun refresh() {
        bannerAccess.visibility = if (Storage.hasAccess(this)) View.GONE else View.VISIBLE
        val root = scanRoot()
        scanJob?.cancel()
        scanJob = lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) { Explorer.scan(root) }
            scan = result
            buildLists()
            recentAdapter.submit(result.recents)
            tvNoRecents.text = "Aucun fichier récent"
            tvNoRecents.visibility = if (result.recents.isEmpty()) View.VISIBLE else View.GONE
        }
    }

    private fun sizeLabel(kind: String): String {
        val s = scan ?: return "…"
        return Fmt.bytes(s.sizes[kind] ?: 0L)
    }

    private fun buildLists() {
        val s = scan
        categoryAdapter.submit(
            listOf(
                ExTile(R.drawable.ex_download, "Téléchargements", if (s == null) "…" else Fmt.bytes(s.downloads)) {
                    openBrowser("Téléchargements", root = File(Storage.root, Environment.DIRECTORY_DOWNLOADS))
                },
                ExTile(R.drawable.ex_image, "Images", sizeLabel(Explorer.IMAGES)) {
                    openBrowser("Images", kind = Explorer.IMAGES)
                },
                ExTile(R.drawable.ex_video, "Vidéos", sizeLabel(Explorer.VIDEOS)) {
                    openBrowser("Vidéos", kind = Explorer.VIDEOS)
                },
                ExTile(R.drawable.ex_audio, "Audio", sizeLabel(Explorer.AUDIO)) {
                    openBrowser("Audio", kind = Explorer.AUDIO)
                },
                ExTile(R.drawable.ex_doc, "Documents", sizeLabel(Explorer.DOCUMENTS)) {
                    openBrowser("Documents", kind = Explorer.DOCUMENTS)
                },
                ExTile(R.drawable.ex_apps, "Applications", sizeLabel(Explorer.APK)) {
                    openBrowser("Applications", kind = Explorer.APK)
                }
            )
        )
        collectionAdapter.submit(
            listOf(
                ExTile(R.drawable.ex_star, "Favoris", "") {
                    openBrowser("Favoris", kind = Explorer.FAVORITES)
                },
                ExTile(R.drawable.ex_lock, "Dossier sécurisé", "") {
                    startActivity(Intent(this, VaultActivity::class.java))
                }
            )
        )
        val free = try { StatFs(Storage.root.path).availableBytes } catch (_: Exception) { 0L }
        storageAdapter.submit(
            listOf(
                ExTile(R.drawable.ex_phone, "Stockage interne", "Espace libre : ${Fmt.bytes(free)}") {
                    if (Storage.hasAccess(this)) openBrowser("Stockage interne", root = Storage.root)
                    else Storage.requestAccess(this)
                },
                ExTile(R.drawable.ex_storage, "Dossier Local Share", "Fichiers reçus") {
                    openBrowser("Local Share", root = Storage.shareDir(this))
                }
            )
        )
    }

    private fun openSearch() {
        val q = etSearch.text.toString().trim()
        if (q.isEmpty()) return
        startActivity(
            Intent(this, BrowserActivity::class.java)
                .putExtra(BrowserActivity.EXTRA_MODE, BrowserActivity.MODE_LOCAL)
                .putExtra(BrowserActivity.EXTRA_ROOT, scanRoot().path)
                .putExtra(BrowserActivity.EXTRA_TITLE, "Résultats")
                .putExtra(BrowserActivity.EXTRA_QUERY, q)
        )
    }

    private fun openBrowser(title: String, kind: String? = null, root: File? = null) {
        val i = Intent(this, BrowserActivity::class.java)
            .putExtra(BrowserActivity.EXTRA_MODE, BrowserActivity.MODE_LOCAL)
            .putExtra(BrowserActivity.EXTRA_TITLE, title)
            .putExtra(BrowserActivity.EXTRA_ROOT, (root ?: scanRoot()).path)
        if (kind != null) i.putExtra(BrowserActivity.EXTRA_KIND, kind)
        startActivity(i)
    }

    private fun chooseAppearance() {
        val modes = arrayOf("Système", "Clair", "Sombre")
        val current = when (getSharedPreferences("settings", MODE_PRIVATE).getInt("night_mode", -1)) {
            AppCompatDelegate.MODE_NIGHT_NO -> 1
            AppCompatDelegate.MODE_NIGHT_YES -> 2
            else -> 0
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Apparence")
            .setSingleChoiceItems(modes, current) { dialog, which ->
                val mode = when (which) {
                    1 -> AppCompatDelegate.MODE_NIGHT_NO
                    2 -> AppCompatDelegate.MODE_NIGHT_YES
                    else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
                }
                getSharedPreferences("settings", MODE_PRIVATE).edit().putInt("night_mode", mode).apply()
                AppCompatDelegate.setDefaultNightMode(mode)
                dialog.dismiss()
            }
            .setNegativeButton("Annuler", null)
            .show()
    }
}

// ------------------------------------------------------------------ cartes catégories / collections / stockage

data class ExTile(val icon: Int, val title: String, val sub: String, val onClick: () -> Unit)

class ExTileAdapter : RecyclerView.Adapter<ExTileAdapter.H>() {
    class H(v: View) : RecyclerView.ViewHolder(v) {
        val tile: View = v.findViewById(R.id.tile)
        val icon: ImageView = v.findViewById(R.id.tileIcon)
        val title: TextView = v.findViewById(R.id.tileTitle)
        val sub: TextView = v.findViewById(R.id.tileSub)
    }

    private var items = emptyList<ExTile>()

    fun submit(list: List<ExTile>) {
        items = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int): H =
        H(LayoutInflater.from(p.context).inflate(R.layout.item_ex_tile, p, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: H, pos: Int) {
        val x = items[pos]
        h.icon.setImageResource(x.icon)
        h.title.text = x.title
        h.sub.text = x.sub
        h.sub.visibility = if (x.sub.isEmpty()) View.GONE else View.VISIBLE
        h.tile.setOnClickListener { x.onClick() }
    }
}

// ------------------------------------------------------------------ fichiers récents (vignettes)

class RecentAdapter(
    private val scope: CoroutineScope,
    private val onClick: (File) -> Unit
) : RecyclerView.Adapter<RecentAdapter.H>() {

    class H(v: View) : RecyclerView.ViewHolder(v) {
        val thumb: ImageView = v.findViewById(R.id.recentThumb)
        val icon: ImageView = v.findViewById(R.id.recentIcon)
        val name: TextView = v.findViewById(R.id.recentName)
        val sub: TextView = v.findViewById(R.id.recentSub)
        var job: Job? = null
    }

    private var items = emptyList<File>()
    private val cache = LruCache<String, Bitmap>(24)

    fun submit(list: List<File>) {
        items = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int): H =
        H(LayoutInflater.from(p.context).inflate(R.layout.item_ex_recent, p, false))

    override fun getItemCount() = items.size

    override fun onViewRecycled(h: H) {
        h.job?.cancel()
        super.onViewRecycled(h)
    }

    override fun onBindViewHolder(h: H, pos: Int) {
        val f = items[pos]
        val kind = Explorer.kindOf(f.name)
        h.job?.cancel()
        h.name.text = f.name
        h.sub.text = "${Fmt.bytes(f.length())} · ${Fmt.day(f.lastModified())}"
        h.itemView.setOnClickListener { onClick(f) }
        h.thumb.setImageDrawable(null)
        h.icon.visibility = View.VISIBLE
        h.icon.setImageResource(
            when (kind) {
                Explorer.IMAGES -> R.drawable.ex_image
                Explorer.VIDEOS -> R.drawable.ex_video
                Explorer.AUDIO -> R.drawable.ex_audio
                Explorer.APK -> R.drawable.ex_apps
                else -> R.drawable.ex_doc
            }
        )
        if (kind != Explorer.IMAGES && kind != Explorer.VIDEOS) return
        val cached = cache.get(f.path)
        if (cached != null) {
            h.thumb.setImageBitmap(cached)
            h.icon.visibility = View.GONE
            return
        }
        h.job = scope.launch {
            val bmp = withContext(Dispatchers.IO) { loadThumb(f, kind) }
            if (bmp != null) {
                cache.put(f.path, bmp)
                h.thumb.setImageBitmap(bmp)
                h.icon.visibility = View.GONE
            }
        }
    }

    private fun loadThumb(f: File, kind: String?): Bitmap? = try {
        if (kind == Explorer.IMAGES) {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.path, bounds)
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= 400 && bounds.outHeight / (sample * 2) >= 400) sample *= 2
            BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = sample })
        } else {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(f.path)
                r.getFrameAtTime(0)
            } finally {
                r.release()
            }
        }
    } catch (_: Throwable) {
        null
    }
}
