DOUBIGUE AI V7 — Conversation locale et historique. Voir V7_NOTES.md pour les fonctionnalités et limites.
