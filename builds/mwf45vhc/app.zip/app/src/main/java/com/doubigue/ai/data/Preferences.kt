package com.doubigue.ai.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "doubigue_settings")
class Preferences(private val context: Context) {
    companion object { val HOLOGRAM = booleanPreferencesKey("hologram_enabled"); val NEON = booleanPreferencesKey("neon_enabled"); val BUBBLE = booleanPreferencesKey("bubble_enabled") }
    val hologram = context.dataStore.data.map { it[HOLOGRAM] ?: true }
    val neon = context.dataStore.data.map { it[NEON] ?: false }
    val bubble = context.dataStore.data.map { it[BUBBLE] ?: false }
    suspend fun set(key: Preferences.Key<Boolean>, value: Boolean) { context.dataStore.edit { it[key] = value } }
}
