package com.doubigue.ai.audio

import android.content.Context
import android.net.Uri
import java.io.File
import java.util.UUID

/** Copies MP3/WAV selected through Android's document picker into private app storage. */
class LocalAudioLibrary(private val context: Context) {
    private val directory: File by lazy {
        File(context.filesDir, "announcements").apply { if (!exists()) mkdirs() }
    }

    fun import(uri: Uri, suggestedName: String? = null): File {
        val mime = context.contentResolver.getType(uri).orEmpty()
        val ext = when {
            mime.contains("wav", true) -> "wav"
            mime.contains("mpeg", true) || mime.contains("mp3", true) -> "mp3"
            else -> {
                val tail = uri.lastPathSegment.orEmpty().substringAfterLast('.', "")
                if (tail.equals("wav", true)) "wav" else "mp3"
            }
        }
        val safe = suggestedName.orEmpty().replace("[^A-Za-z0-9_-]".toRegex(), "_").take(32)
        val target = File(directory, (if (safe.isBlank()) UUID.randomUUID().toString() else safe) + "_" + UUID.randomUUID().toString().take(8) + "." + ext)
        val input = context.contentResolver.openInputStream(uri)
            ?: throw IllegalArgumentException("Impossible de lire le fichier audio sélectionné.")
        input.use { stream -> target.outputStream().use { output -> stream.copyTo(output) } }
        return target
    }

    fun delete(path: String?) {
        if (path.isNullOrBlank()) return
        val file = File(path).canonicalFile
        if (file.parentFile == directory.canonicalFile) file.delete()
    }

    fun list(): List<File> =
        directory.listFiles()?.filter { it.isFile && (it.extension.equals("mp3", true) || it.extension.equals("wav", true)) }?.sortedBy { it.name } ?: emptyList()
}
