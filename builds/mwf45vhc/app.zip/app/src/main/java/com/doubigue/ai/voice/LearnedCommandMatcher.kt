package com.doubigue.ai.voice

import com.doubigue.ai.data.LearnedCommand

/** Exact normalized matching only: no fuzzy or unintended command execution. */
object LearnedCommandMatcher {
    fun find(spoken: String, commands: List<LearnedCommand>): LearnedCommand? {
        val key = CommandRouter.normalize(spoken)
        if (key.isBlank()) return null
        return commands.firstOrNull { CommandRouter.normalize(it.triggerPhrase) == key }
    }
}
