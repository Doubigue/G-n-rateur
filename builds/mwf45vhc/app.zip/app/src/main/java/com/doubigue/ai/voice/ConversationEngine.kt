package com.doubigue.ai.voice

/** Offline fallback conversation layer. It does not pretend to be a cloud LLM. */
object ConversationEngine {
    fun reply(input: String, recentUserMessages: List<String> = emptyList()): String {
        val text = CommandRouter.normalize(input).trim()
        if (text.isBlank()) return "Je t'écoute. Que souhaites-tu faire ?"
        return when {
            listOf("bonjour", "salut", "bonsoir", "coucou").any { text == it || text.startsWith("$it ") } ->
                "Bonjour ! Je suis DOUBIGUE AI. Que puis-je faire pour toi ?"
            text.contains("quepeuxtufaire") || text.contains("quetupeuxfaire") || text.contains("tesfonctions") || text.contains("aidemoi") || text == "aide" ->
                "Je peux ouvrir les applications configurées, reconnaître leurs alias, lancer tes sons associés, gérer la lampe torche et certains paramètres du téléphone. Dis-moi ce que tu souhaites faire."
            text.contains("commenttutappelles") || text.contains("quiestu") ->
                "Je suis DOUBIGUE AI, ton assistant personnel Android."
            text.contains("merci") -> "Avec plaisir ! Je suis là si tu as besoin de moi."
            text.contains("rappelle") || text.contains("souviens") || text.contains("historique") ->
                if (recentUserMessages.isEmpty()) "Je n'ai pas encore de conversation précédente à rappeler." else
                    "Voici un sujet récent : ${recentUserMessages.first()}. Tu peux consulter l'historique enregistré dans cette version."
            text.contains("quelleheure") -> "Je ne dispose pas encore d'une horloge conversationnelle intégrée. Consulte l'heure affichée par ton téléphone."
            else -> "J'ai compris ta phrase, mais ma réponse intelligente en ligne n'est pas encore connectée. Je peux déjà exécuter les commandes locales prises en charge."
        }
    }
}
