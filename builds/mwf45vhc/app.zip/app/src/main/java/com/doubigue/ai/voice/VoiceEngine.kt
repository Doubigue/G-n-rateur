package com.doubigue.ai.voice

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import java.util.Locale

/**
 * Voice engine deliberately restricted to on-device speech recognition.
 * It never falls back to the general recognizer, which may send audio to a server.
 */
class VoiceEngine(
    context: Context,
    private val onText: (String) -> Unit,
    private val onState: (String) -> Unit
) {
    private val appContext = context.applicationContext
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsOfflineReady = false

    init {
        tts = TextToSpeech(appContext) { status ->
            val engine = tts
            if (status != TextToSpeech.SUCCESS || engine == null) {
                ttsOfflineReady = false
                onState("Synthèse vocale indisponible")
                return@TextToSpeech
            }

            // Select a French voice that explicitly does not require a network connection.
            val offlineFrenchVoice: Voice? = engine.voices
                ?.filter { it.locale.language == "fr" && !it.isNetworkConnectionRequired }
                ?.sortedByDescending { it.locale == Locale.FRANCE }
                ?.firstOrNull()

            if (offlineFrenchVoice != null) {
                val result = engine.setVoice(offlineFrenchVoice)
                ttsOfflineReady = result == TextToSpeech.SUCCESS
                onState(if (ttsOfflineReady) "Voix française hors ligne prête" else "Voix hors ligne indisponible")
            } else {
                ttsOfflineReady = false
                onState("Installe une voix française hors ligne dans les paramètres Android")
            }
        }
    }

    fun listen() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            onState("Reconnaissance vocale hors ligne : Android 12 ou supérieur requis")
            return
        }

        if (!SpeechRecognizer.isOnDeviceRecognitionAvailable(appContext)) {
            onState("Moteur vocal hors ligne indisponible. Installe le modèle français hors ligne dans Android.")
            return
        }

        stopListening()
        try {
            recognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(appContext).also { sr ->
                sr.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) { onState("Écoute hors ligne…") }
                    override fun onBeginningOfSpeech() { onState("Je t'écoute…") }
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() { onState("Analyse locale…") }
                    override fun onError(error: Int) {
                        onState("Reconnaissance locale interrompue (${errorLabel(error)})")
                        stopListening()
                    }
                    override fun onResults(results: Bundle?) {
                        val text = results
                            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull()
                        if (!text.isNullOrBlank()) onText(text)
                        onState("Prêt · mode hors ligne")
                        stopListening()
                    }
                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "fr-FR")
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                }
                sr.startListening(intent)
            }
        } catch (security: SecurityException) {
            onState("Autorisation microphone nécessaire")
            stopListening()
        } catch (error: Exception) {
            onState("Impossible de démarrer le moteur vocal hors ligne")
            stopListening()
        }
    }

    fun speak(message: String) {
        if (ttsOfflineReady) {
            tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "doubigue-${System.currentTimeMillis()}")
        } else {
            onState("Voix française hors ligne non installée")
        }
    }

    fun stopListening() {
        recognizer?.cancel()
        recognizer?.destroy()
        recognizer = null
    }

    fun release() {
        stopListening()
        tts?.stop()
        tts?.shutdown()
        tts = null
        ttsOfflineReady = false
    }

    private fun errorLabel(error: Int): String = when (error) {
        SpeechRecognizer.ERROR_AUDIO -> "audio"
        SpeechRecognizer.ERROR_CLIENT -> "client"
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "permission microphone"
        SpeechRecognizer.ERROR_NETWORK,
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "service local ou modèle indisponible"
        SpeechRecognizer.ERROR_NO_MATCH -> "aucune phrase reconnue"
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "moteur occupé"
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "aucune parole détectée"
        else -> "code $error"
    }
}
