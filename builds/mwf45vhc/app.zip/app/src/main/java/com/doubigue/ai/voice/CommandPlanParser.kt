package com.doubigue.ai.voice

/** A conservative, deterministic interpretation of a multi-action French utterance. */
object CommandPlanParser {
    fun parse(input: String): CommandPlan {
        val cleaned = input.trim()
        if (cleaned.isBlank()) return CommandPlan(emptyList(), "Commande vide")
        val segments = cleaned
            .replace(Regex("\\s+et\\s+ensuite\\s+", RegexOption.IGNORE_CASE), "|")
            .replace(Regex("\\s+puis\\s+", RegexOption.IGNORE_CASE), "|")
            .replace(Regex("\\s+ensuite\\s+", RegexOption.IGNORE_CASE), "|")
            .split('|')
            .map { it.trim().trim(',', '.', ';') }
            .filter { it.isNotBlank() }
        if (segments.size > 5) return CommandPlan(emptyList(), "Trop d'actions dans une seule commande")
        val actions = segments.map { segment ->
            val normalized = CommandRouter.normalize(segment)
            when {
                normalized.startsWith("ouvre") || normalized.startsWith("lance") || normalized.startsWith("ouvre") -> {
                    val target = segment.replace(Regex("(?i)^(ouvre|lance|ouvrir|démarre|demarre)\\s+"), "").trim()
                    if (target.isBlank()) null else PlannedAction.OpenTarget(target)
                }
                normalized.startsWith("allume") && (normalized.contains("lampe") || normalized.contains("torche")) -> PlannedAction.Flashlight(true)
                (normalized.startsWith("eteins") || normalized.startsWith("eteindre")) && (normalized.contains("lampe") || normalized.contains("torche")) -> PlannedAction.Flashlight(false)
                normalized.startsWith("joue") || normalized.startsWith("mets") -> {
                    val target = segment.replace(Regex("(?i)^(joue|mets)\\s+"), "").trim()
                    if (target.isBlank()) null else PlannedAction.PlayAudio(target)
                }
                else -> PlannedAction.OpenTarget(segment)
            }
        }
        if (actions.any { it == null }) return CommandPlan(emptyList(), "Une action n'a pas de cible")
        return CommandPlan(actions.filterNotNull(), null)
    }
}

data class CommandPlan(val actions: List<PlannedAction>, val error: String?)

sealed interface PlannedAction {
    data class OpenTarget(val name: String) : PlannedAction
    data class PlayAudio(val query: String) : PlannedAction
    data class Flashlight(val enabled: Boolean) : PlannedAction
}
