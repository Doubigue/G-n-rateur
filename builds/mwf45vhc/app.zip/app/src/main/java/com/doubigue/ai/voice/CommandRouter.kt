package com.doubigue.ai.voice

import java.text.Normalizer
import java.util.Locale

/** Normalizes French speech and routes system commands before app-name matching. */
object CommandRouter {
    fun normalize(input: String): String {
        val noMarks = Normalizer.normalize(input.lowercase(Locale.FRENCH), Normalizer.Form.NFD)
            .replace("\\p{Mn}+".toRegex(), "")
        return noMarks.replace("[^a-z0-9]+".toRegex(), "")
    }

    fun matchApplication(spoken: String, labels: List<String>): String? {
        val key = normalize(spoken)
        if (key.isBlank()) return null
        return labels.firstOrNull { normalize(it) == key }
    }

    /** Matches an app label, its configured spoken name, or any comma/semicolon/pipe alias. */
    fun matchConfiguredApplication(spoken: String, label: String, spokenName: String, aliases: String): Boolean {
        val key = normalize(spoken)
        if (key.isBlank()) return false
        return (listOf(label, spokenName) + aliases.split(',', ';', '|'))
            .any { normalize(it) == key }
    }

    fun classify(input: String): Command {
        val value = normalize(input)
        return when {
            value.contains("allume") && (value.contains("lampe") || value.contains("torche")) -> Command.Flashlight(true)
            (value.contains("eteins") || value.contains("eteindre")) && (value.contains("lampe") || value.contains("torche")) -> Command.Flashlight(false)
            value.contains("wifi") -> Command.OpenWifi
            value.contains("bluetooth") -> Command.OpenBluetooth
            value.contains("internet") || value.contains("connexion") -> Command.ConnectionStatus
            else -> Command.ApplicationName(input.trim())
        }
    }
}

sealed interface Command {
    data class Flashlight(val enabled: Boolean) : Command
    data object OpenWifi : Command
    data object OpenBluetooth : Command
    data object ConnectionStatus : Command
    data class ApplicationName(val spokenName: String) : Command
}
