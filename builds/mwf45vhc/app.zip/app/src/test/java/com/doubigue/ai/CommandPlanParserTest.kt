package com.doubigue.ai

import com.doubigue.ai.voice.CommandPlanParser
import com.doubigue.ai.voice.PlannedAction
import org.junit.Assert.*
import org.junit.Test

class CommandPlanParserTest {
    @Test fun parsesSequentialAppAndAudioRequest() {
        val plan = CommandPlanParser.parse("Ouvre WhatsApp puis joue ma musique")
        assertNull(plan.error)
        assertEquals(2, plan.actions.size)
        assertEquals(PlannedAction.OpenTarget("WhatsApp"), plan.actions[0])
        assertEquals(PlannedAction.PlayAudio("ma musique"), plan.actions[1])
    }

    @Test fun parsesFlashlightAction() {
        assertEquals(listOf(PlannedAction.Flashlight(true)), CommandPlanParser.parse("Allume la lampe").actions)
    }

    @Test fun rejectsTooManyActions() {
        assertNotNull(CommandPlanParser.parse("ouvre A puis ouvre B puis ouvre C puis ouvre D puis ouvre E puis ouvre F").error)
    }
}
