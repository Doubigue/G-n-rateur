package com.doubigue.ai

import com.doubigue.ai.voice.ConversationEngine
import org.junit.Assert.assertTrue
import org.junit.Test

class ConversationEngineTest {
    @Test fun greetsInFrench() { assertTrue(ConversationEngine.reply("Bonjour").contains("Bonjour")) }
    @Test fun explainsCapabilities() { assertTrue(ConversationEngine.reply("Que peux-tu faire ?").contains("ouvrir")) }
    @Test fun isHonestAboutCloudAiNotBeingConnected() { assertTrue(ConversationEngine.reply("Explique la relativité").contains("pas encore connectée")) }
}
