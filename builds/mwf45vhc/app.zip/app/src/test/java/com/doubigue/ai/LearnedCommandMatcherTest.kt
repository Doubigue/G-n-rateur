package com.doubigue.ai

import com.doubigue.ai.data.LearnedCommand
import com.doubigue.ai.voice.LearnedCommandMatcher
import org.junit.Assert.*
import org.junit.Test

class LearnedCommandMatcherTest {
    @Test fun matchesCaseAndAccentsWithoutFuzzyGuessing() {
        val command = LearnedCommand(id = 1, triggerPhrase = "Mode Étude", commandText = "ouvre WhatsApp")
        assertEquals(command, LearnedCommandMatcher.find("mode etude", listOf(command)))
        assertNull(LearnedCommandMatcher.find("mode", listOf(command)))
    }

    @Test fun blankInputNeverMatches() {
        val command = LearnedCommand(id = 1, triggerPhrase = "Travail", commandText = "ouvre WhatsApp")
        assertNull(LearnedCommandMatcher.find("   ", listOf(command)))
    }
}
