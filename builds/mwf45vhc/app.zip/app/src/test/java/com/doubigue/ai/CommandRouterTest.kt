package com.doubigue.ai

import com.doubigue.ai.voice.Command
import com.doubigue.ai.voice.CommandRouter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class CommandRouterTest {
    @Test fun removesAccentsAndSeparators() {
        assertEquals("eteinslatorche", CommandRouter.normalize("Éteins la torche !"))
    }
    @Test fun exactAppNameMatching() {
        assertEquals("WhatsApp", CommandRouter.matchApplication("whats app", listOf("WhatsApp", "WhatsApp Business")))
        assertNull(CommandRouter.matchApplication("what", listOf("WhatsApp", "WhatsApp Business")))
    }
    @Test fun matchesConfiguredAliases() {
        assertEquals(true, CommandRouter.matchConfiguredApplication("wa pro", "WhatsApp", "WhatsApp", "WA Pro, messagerie"))
        assertEquals(true, CommandRouter.matchConfiguredApplication("MESSAGERIE", "WhatsApp", "WhatsApp", "WA Pro; messagerie"))
        assertEquals(false, CommandRouter.matchConfiguredApplication("what", "WhatsApp", "WhatsApp", "WA Pro, messagerie"))
    }
    @Test fun routesSystemCommands() {
        assertEquals(Command.Flashlight(true), CommandRouter.classify("Allume la lampe"))
        assertEquals(Command.OpenWifi, CommandRouter.classify("Ouvre les paramètres Wi-Fi"))
        assertEquals(Command.OpenBluetooth, CommandRouter.classify("Bluetooth"))
        assertEquals(Command.Flashlight(false), CommandRouter.classify("Éteins la torche"))
    }
    @Test fun appNameIsFallback() {
        assertEquals(Command.ApplicationName("WhatsApp"), CommandRouter.classify("WhatsApp"))
    }
}
