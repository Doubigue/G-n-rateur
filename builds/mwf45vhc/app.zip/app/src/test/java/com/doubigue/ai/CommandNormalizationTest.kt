package com.doubigue.ai

import org.junit.Assert.assertEquals
import org.junit.Test
import java.text.Normalizer
import java.util.Locale

class CommandNormalizationTest {
    private fun normalize(value: String) = Normalizer.normalize(value.lowercase(Locale.FRENCH).trim(), Normalizer.Form.NFD)
        .replace("\\p{Mn}+".toRegex(), "").replace(" ", "").replace("-", "")
    @Test fun applicationNamesIgnoreCaseAndSpaces() {
        assertEquals(normalize("WhatsApp"), normalize("whats app"))
    }
    @Test fun frenchAccentsNormalize() {
        assertEquals("eteinslal ampe".replace(" ", ""), normalize("Éteins la lampe"))
    }
}
