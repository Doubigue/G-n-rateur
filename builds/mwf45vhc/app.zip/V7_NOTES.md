# DOUBIGUE AI V7 — Conversation locale et historique

## Inclus
- Couche de conversation hors-ligne en français (`ConversationEngine`).
- Réponses vocales via le moteur Android déjà présent.
- Historique utilisateur/assistant stocké dans Room.
- Migration Room 2 vers 3, sans effacer les configurations d'applications.
- Tests unitaires de base.
- Version Android 1.5.0 / versionCode 6.

## Limites honnêtes
Cette V7 fournit une conversation locale à intentions limitées, pas un grand modèle de langage. La connexion à un service IA en ligne nécessite de choisir un fournisseur, créer un backend sécurisé et gérer la clé API côté serveur (jamais dans l'APK). Les réponses aux questions générales restent donc limitées.

## Vérifications requises
- Ouvrir le projet dans Android Studio et synchroniser Gradle.
- Exécuter les tests unitaires.
- Compiler et tester sur un téléphone Android.
- Vérifier la migration d'une installation V6 existante.
