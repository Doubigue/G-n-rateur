# DOUBIGUE AI — Android Studio

Assistant Android natif en Kotlin + Jetpack Compose. Cette livraison est une **base MVP réelle et extensible**, pas une prétention à couvrir toutes les fonctions du cahier des charges. Elle comprend une interface Compose, une sphère holographique dessinée en Canvas, reconnaissance vocale Android, synthèse vocale française, inventaire d'applications, ouverture/bascule prudente d'applications, lampe torche, raccourcis vers les réglages Wi-Fi/Bluetooth/affichage, création d'alarme via l'application Horloge, service de bulle superposée, Room et DataStore.

## Ouvrir le projet

1. Installer Android Studio (version récente) et Android SDK Platform 35.
2. Ouvrir le dossier `DOUBIGUE_AI` dans Android Studio.
3. Laisser Gradle synchroniser les dépendances depuis Google Maven Central.
4. Connecter un téléphone Android 8.0+ ou démarrer un émulateur.
5. Lancer la configuration `app`.

Le projet cible API 35, minimum API 26, JVM 17. Un APK n'est pas joint : l'environnement de préparation ne dispose ni d'Android SDK, ni de Gradle installé, ni d'un appareil/émulateur. La compilation et les tests instrumentés doivent donc être exécutés dans Android Studio.

## Commandes vocales MVP

- Dire le nom d'une application installée (ex. « WhatsApp ») pour la lancer.
- Dire « allume la lampe » / « éteins la lampe ».
- Dire « Wi-Fi », « Bluetooth », « Internet » ou « connexion » pour consulter/ouvrir les réglages associés.

La reconnaissance dépend du service de reconnaissance installé sur le téléphone et peut nécessiter Internet selon le moteur vocal du fabricant. L'interface demande l'autorisation microphone à la première activation.

## Autorisations et limites Android

- **Liste des applications** : `QUERY_ALL_PACKAGES` est déclaré. Google Play limite fortement cette permission; une publication doit justifier son usage comme fonctionnalité centrale et peut devoir adopter une liste de packages ciblée.
- **État premier plan** : l'accès aux statistiques d'utilisation doit être activé manuellement dans les paramètres Android. Sans cet accès, l'état est `UNKNOWN` et l'application lance l'application cible au lieu de prétendre la fermer.
- **Fermeture** : Android n'autorise pas une application ordinaire à forcer l'arrêt d'une autre application. Lorsque la cible est au premier plan, le MVP renvoie à l'accueil. Il ne tue aucun processus.
- **Bulle flottante** : le service n'est utilisable qu'après autorisation « Afficher par-dessus les autres applications ». L'utilisateur doit démarrer le service depuis un écran d'activation dans une itération UI dédiée; le service est fourni mais n'est pas démarré automatiquement.
- **Wi-Fi/Bluetooth** : le MVP ouvre les panneaux/réglages Android; il ne contourne pas les restrictions de bascule directe.
- **Luminosité** : ouvre les réglages d'affichage. La modification directe nécessite `WRITE_SETTINGS` et une demande d'accès spéciale.
- **Alarmes** : délègue à `AlarmClock.ACTION_SET_ALARM` et laisse l'utilisateur confirmer dans Horloge.
- **Capture d'écran / enregistrement** : nécessite MediaProjection avec consentement visible à chaque session. Non implémenté dans cette base.
- **Échecs PIN, schéma, mot de passe, biométrie** : inaccessibles aux applications ordinaires. Aucun écran de verrouillage ni aucune donnée d'authentification n'est intercepté.
- **Audio personnalisé** : sélecteur local MP3/WAV inclus dans l'écran de configuration. L'association persistante, lecture par événement et bibliothèque audio complète restent à terminer.
- **Sphère 3D** : rendu 2D volumétrique Canvas animé pour ce MVP. Une vraie scène OpenGL/Filament n'est pas encore incluse.

## Architecture

- `ui/` : écrans Jetpack Compose et sphère.
- `voice/` : SpeechRecognizer et TextToSpeech.
- `apps/` : inventaire, résolution vocale et état d'application.
- `system/` : outils Android autorisés.
- `overlay/` : service de bulle flottante.
- `data/` : entité/DAO Room et préférences DataStore.

## Avant publication

1. Compléter les écrans de permissions et le démarrage/arrêt explicite de la bulle.
2. Persister les réglages d'applications et les URI audio dans Room; créer un lecteur Media3/ExoPlayer.
3. Ajouter MediaProjection, scanner QR/document, caméra, minuteur, volume et mode Ne pas déranger avec les flux de consentement requis.
4. Remplacer le rendu Canvas par Filament/OpenGL si une véritable géométrie 3D est indispensable.
5. Ajouter tests UI, tests sur appareils de plusieurs fabricants, gestion des interruptions audio et politique de confidentialité.
6. Vérifier la politique Google Play pour `QUERY_ALL_PACKAGES`, overlay et services au premier plan.

## Version

`1.0.0` — base MVP de développement. Non certifiée pour publication et non validée sur appareil physique.

## Itération 1.1 — tiroir circulaire

L'écran **Raccourcis** présente maintenant jusqu'à dix applications installées sur un anneau autour de la sphère DOUBIGUE. L'anneau peut être tourné par glissement horizontal et chaque icône lance l'application correspondante. Les icônes réelles du système sont affichées. Cette première version du tiroir est intégrée à l'écran de l'application; l'ouverture depuis une bulle au-dessus des autres applications et la synchronisation de sa sélection restent à connecter dans une itération suivante.


## V4
Voir `V4_NOTES.md` pour les fonctionnalités ajoutées, la configuration des alias et les essais à effectuer sur téléphone.

## V5 — bulle flottante interactive
La bulle peut être déplacée et ouverte par toucher. Une notification persistante permet d'arrêter explicitement le service. La bulle n'écoute pas le microphone en continu : l'activation vocale reste déclenchée depuis l'application au premier plan pour respecter les restrictions Android.
Voir `V5_NOTES.md`.

## V8 — mode vocal hors ligne strict
La reconnaissance vocale est désormais limitée à l'API Android on-device (Android 12+). Aucun repli vers un service de reconnaissance distant n'est effectué. La synthèse vocale sélectionne uniquement une voix française installée qui ne requiert pas de connexion réseau. Il faut télécharger au préalable le modèle de langue et la voix hors ligne dans les paramètres Android. Voir `V8_NOTES.md` et `README_V8.txt`.

## V9 — Apprentissage local

Ouvrir **Paramètres > Apprentissage** pour enregistrer une phrase déclencheuse et une commande que l'assistant sait déjà exécuter. Exemple : `Travail` -> `ouvre WhatsApp`. Les règles peuvent être supprimées individuellement et sont conservées dans la base Room locale. Cette fonction n'utilise aucune API IA.

Voir `V9_NOTES.md` et `BUILD_STATUS.txt` pour les détails et limites de validation.

## V10 — profils et routines locales
Dans **Paramètres > Apprentissage**, sélectionner un profil (Général, Travail, Maison ou Nuit), puis créer une commande simple ou une routine de cinq actions maximum. Les actions peuvent être séparées par `puis` ou `ensuite`. L'apprentissage vocal accepte la formule explicite : « Apprends que quand je dis [phrase], fais [action] ». Les commandes Général restent disponibles dans tous les profils.

Les fichiers MP3/WAV doivent être importés localement avant lecture. « Joue ma musique » lance le premier fichier importé ; un nom de fichier peut aussi être précisé. Les données et profils restent locaux, sans API IA. La reconnaissance vocale hors ligne dépend toujours du service Android et du modèle français installé.

Voir `V10_NOTES.md`, `README_V10.txt` et `BUILD_STATUS.txt`. La compilation et les tests sur téléphone restent à effectuer dans Android Studio.
