# DOUBIGUE AI — V5 (1.3.0)

## Objectif
Rendre la bulle flottante utilisable et contrôlable pendant l'utilisation d'autres applications, sans démarrer une écoute micro permanente.

## Changements
- Bulle flottante déplaçable au doigt.
- Un toucher (sans déplacement) ouvre l'écran principal DOUBIGUE AI.
- Notification persistante avec action explicite « Arrêter ».
- Arrêt du service si l'autorisation de superposition n'est pas accordée.
- Gestion défensive des erreurs d'ajout/retrait de la fenêtre.
- Service non relancé automatiquement après destruction (`START_NOT_STICKY`).
- Version Android : `versionCode 4`, `versionName 1.3.0`.

## Limites Android
- L'utilisateur doit activer manuellement l'autorisation « Afficher par-dessus les autres applications ».
- Le service au premier plan affiche une notification persistante.
- La bulle ne capte pas le microphone. L'écoute vocale est lancée depuis l'application au premier plan, où Android peut présenter les permissions et l'indicateur micro.
- Les règles Android et Google Play sur les services au premier plan, les superpositions et `QUERY_ALL_PACKAGES` doivent être vérifiées avant publication.

## Vérification
La compilation Gradle, les tests unitaires et les essais sur téléphone doivent encore être exécutés dans Android Studio avec Android SDK installé. Cette archive contient le code source, pas un APK validé.
