# Matrice des fonctions Android

| Fonction demandée | Statut MVP | Implémentation / limite |
|---|---|---|
| Reconnaissance vocale | Partielle | SpeechRecognizer, français; disponibilité selon le téléphone |
| Synthèse vocale | Oui | TextToSpeech local/service système |
| Applications installées | Oui, sous réserve | PackageManager + QUERY_ALL_PACKAGES soumis à politique |
| Toggle nom d'application | Partiel | UsageStats si autorisé; sinon lancement prudent |
| Fermer une autre application | Remplacement | Retour à l'accueil; pas de force-stop |
| Lampe torche | Oui | CameraManager et permission caméra à obtenir au runtime (à finaliser dans l'écran permissions) |
| Wi-Fi/Bluetooth | Remplacement | Ouvre les réglages Android |
| Luminosité | Remplacement | Ouvre les réglages d'affichage |
| Alarme | Oui, déléguée | Intent système, confirmation utilisateur |
| Bulle flottante | Base de service | Autorisation overlay + notification de service au premier plan; activation depuis Actions |
| Audio ElevenLabs local | Partiel | Import URI; gestionnaire d'événements à finaliser |
| Sphère 3D | Partiel | Effet volumétrique Canvas, pas une vraie scène 3D |
| Enregistrement écran | Non | MediaProjection et consentement à ajouter |
| QR/document/caméra | Non | Modules à ajouter |
| Bienvenue au déverrouillage | Non | Restrictions de diffusion et comportement constructeur; notification/annonce au lancement comme alternative |
| Échecs PIN/schéma/biométrie | Non autorisé | Non accessibles aux applications ordinaires |
