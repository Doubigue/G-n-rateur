DOUBIGUE AI V9
Apprentissage local des commandes personnalisées.
Ouvrir Paramètres > Apprentissage.
Créer une phrase (ex. Travail) et l'action correspondante (ex. ouvre WhatsApp).
Prononcer ou saisir ensuite la phrase pour lancer l'action mémorisée.
Aucune API IA ni connexion Internet n'est ajoutée.
Consulter V9_NOTES.md et BUILD_STATUS.txt.
