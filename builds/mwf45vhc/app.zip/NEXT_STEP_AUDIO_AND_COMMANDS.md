# DOUBIGUE AI — étape suivante

Ajouts de cette itération :
- `CommandRouter` : normalisation du français (accents/espaces), classification des commandes système et correspondance exacte du nom d'application.
- Tests unitaires des commandes et du routage par nom d'application.
- `LocalAudioLibrary` : copie MP3/WAV depuis le sélecteur Android vers le stockage privé local.
- Colonne Room `aliases` et migration 1→2 pour conserver les variantes vocales.

## Intégration UI restante
- Construire Room avec `.addMigrations(MIGRATION_1_2)`.
- Relier l'écran Mes applications au DAO pour enregistrer nom, alias et chemins audio.
- Lire les annonces importées avec MediaPlayer/ExoPlayer lors des événements.
- Connecter `CommandRouter.classify()` à l'exécuteur, avec clarification si le nom est ambigu.

Les fichiers audio sont stockés dans `filesDir/announcements`, sans permission générale de stockage.
APK et compilation non vérifiés dans cet environnement.
