# DOUBIGUE AI V6 — compréhension et préparation des séquences

## Inclus dans cette étape
- Ajout de `CommandPlanParser`, un interpréteur déterministe pour les demandes françaises simples en plusieurs étapes.
- Reconnaissance des connecteurs « puis », « ensuite » et « et ensuite ».
- Types d'actions préparés : ouverture d'application/cible, lecture audio et lampe torche.
- Limite de cinq actions par phrase et rejet des segments incomplets.
- Tests unitaires pour les séquences, la lampe et la limite de sécurité.
- Mise à jour de la version Android : code 5, version 1.4.0.
- Correction de la séparation des alias dans la recherche d'applications.

## Important
Le parseur produit un plan structuré ; l'orchestration complète de ces plans dans l'interface et l'exécution réelle de chaque action reste à intégrer et tester. Les commandes sensibles doivent demander confirmation. La lecture audio doit réutiliser la bibliothèque locale et les autorisations Android déjà présentes.

## Compilation et tests
Ouvrir le dossier dans Android Studio, synchroniser Gradle, exécuter les tests `testDebugUnitTest`, puis compiler et tester sur un appareil Android. Cette archive n'est pas un APK validé ; aucune compilation réelle n'a été effectuée dans cet environnement.
