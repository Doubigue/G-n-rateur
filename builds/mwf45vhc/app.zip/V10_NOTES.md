# DOUBIGUE AI V10 — Profils et routines locales

## Nouveautés
- Profils locaux `Général`, `Travail`, `Maison` et `Nuit` dans Paramètres > Apprentissage.
- Le profil actif est mémorisé dans les préférences privées Android.
- Les commandes du profil Général restent disponibles dans tous les profils ; les autres commandes ne sont exécutées que dans le profil actif.
- Une commande apprise peut contenir une séquence de plusieurs actions séparées par `puis` ou `ensuite` (maximum cinq étapes, parseur déterministe).
- Apprentissage vocal explicite : « Apprends que quand je dis Routine matin, fais ouvre WhatsApp puis joue ma musique ».
- Lecture d'un fichier MP3/WAV importé localement par son nom ; « joue ma musique » lance le premier fichier audio importé.
- Migration Room 4 -> 5 ajoutant le profil à chaque commande sans supprimer les commandes V9.

## Utilisation
1. Ouvrir Paramètres > Apprentissage.
2. Choisir Général, Travail, Maison ou Nuit.
3. Enregistrer une phrase et une ou plusieurs actions, ou dicter la formule d'apprentissage vocal.
4. Dire la phrase déclencheuse pour lancer la routine.

## Hors ligne et confidentialité
- Pas d'API IA, de modèle distant, de serveur ni de connexion réseau ajoutée.
- Les profils, commandes et règles restent dans le stockage privé local de l'application.
- La reconnaissance vocale reste soumise au moteur Android on-device et au modèle français téléchargé, comme décrit dans V8.

## Sécurité et limites
- Les routines sont limitées à cinq actions et utilisent le parseur de commandes déterministe existant.
- Les actions restent limitées aux fonctions déjà prises en charge par l'application. Les réglages système sensibles restent soumis aux autorisations Android.
- La lecture audio ne joue que les MP3/WAV importés dans la bibliothèque locale de l'application.
- L'apprentissage vocal ne comprend que la formule explicite documentée ; il ne s'agit pas d'un apprentissage autonome par modèle IA.
- Android peut limiter l'ouverture d'applications et l'accès à certaines informations système.

## Vérification
- Le projet source a été mis à jour et l'archive V10 créée.
- Compilation Gradle, tests unitaires et essais physiques : non exécutés dans cet environnement faute d'Android SDK/Gradle et d'appareil de test.
