DOUBIGUE AI V8 — MODE HORS LIGNE STRICT

Cette version n'ajoute aucune API IA ni aucun serveur distant.
La reconnaissance vocale utilise uniquement l'API Android on-device (Android 12+).
La synthèse vocale ne sélectionne qu'une voix française locale, sans dépendance réseau.

Avant l'essai, installer le modèle français hors ligne et la voix française hors ligne dans les paramètres Android du téléphone.
Pour vérifier le mode hors ligne, couper Wi-Fi et données mobiles, puis tester la commande vocale.
Si le moteur local ou son modèle n'est pas disponible, l'application affiche un message et ne fait aucun repli vers Internet.

Voir V8_NOTES.md pour les prérequis, limites et protocole de test.
Compilation Gradle et essais physiques à effectuer dans Android Studio.
