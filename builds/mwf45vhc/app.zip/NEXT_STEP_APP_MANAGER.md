# DOUBIGUE AI — gestionnaire des applications (itération suivante)

## Ajouts
- Écran Mes applications avec icône, nom et package Android.
- Éditeur de configuration individuel par application.
- Nom de commande vocale modifiable.
- Variantes/alias vocaux enregistrables (séparés par des virgules dans l'interface, stockés séparés par `|`).
- Activation/désactivation de la logique intelligente par application.
- Import séparé des annonces d'ouverture et de retour à l'accueil.
- Copie des MP3/WAV dans le stockage privé de l'application.
- Préécoute locale des deux annonces.
- Enregistrement et suppression des configurations via Room.
- Migration Room 1→2 conservée et utilisée lors de l'ouverture de la base.
- Version Android du module passée à 1.1.0 / versionCode 2.

## Vérifications et limites
- Le projet est une source Android Studio, pas un APK certifié.
- La compilation n'a pas été exécutée : aucun wrapper Gradle/SDK Android n'est fourni dans cet environnement.
- L'éditeur persiste les alias et sons ; leur consommation automatique par le moteur vocal (résolution d'alias + lecture au lancement/retour) reste l'étape d'intégration suivante.
- La détection foreground/background dépend de l'accès spécial « Accès aux données d'utilisation » et reste limitée par les événements exposés par Android.
- « Fermer » une application tierce signifie revenir à l'accueil ; aucune fermeture forcée n'est tentée.
