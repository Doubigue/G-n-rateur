# DOUBIGUE AI — V4 (1.2.0)

## Fonctions intégrées
- Résolution des applications installées par libellé, nom vocal personnalisé et alias (virgules, points-virgules ou retours à la ligne).
- Lecture automatique du fichier MP3/WAV configuré après une ouverture ou un retour à l'accueil réussi.
- Réponse vocale explicite si aucune application installée ne correspond.
- Protection contre la répétition immédiate d'une même commande (1,8 seconde).
- Détection de l'application au premier plan si l'accès aux données d'utilisation est accordé.
- Version Android portée à 1.2.0 / versionCode 3.

## Configuration
1. Ouvrir Paramètres > Mes applications.
2. Sélectionner WhatsApp ou l'application souhaitée.
3. Saisir le nom prononcé et les alias, par exemple `wa, whatsapp perso, messagerie`.
4. Associer un fichier MP3/WAV à l'ouverture et/ou au retour à l'accueil.
5. Enregistrer, revenir à l'accueil et prononcer l'un des alias.

Les fichiers audio importés sont copiés dans le stockage privé de l'application et lus localement.

## Restrictions Android
- Android ne permet pas à une application ordinaire de forcer l'arrêt d'une autre. « Fermer » signifie revenir à l'écran d'accueil.
- Sans accès aux données d'utilisation, l'état est inconnu et l'assistant ouvre l'application.
- Le lancement d'une activité peut être limité en arrière-plan : déclencher la commande avec DOUBIGUE AI au premier plan.
- La visibilité des applications dépend des règles Android, de QUERY_ALL_PACKAGES et des règles Google Play.

## Vérifications nécessaires
Le code V4 et les tests unitaires d'alias sont intégrés. Compilation Gradle, tests Android et validation sur téléphone restent à effectuer dans Android Studio : cet environnement ne dispose pas de l'Android SDK/Gradle.
Tester les alias, ouverture/retour accueil, MP3/WAV, application inconnue, fichiers audio invalides, commandes répétées et interruptions audio.
