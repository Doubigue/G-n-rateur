DOUBIGUE AI V10 — Profils et routines locales

1. Ouvrir Paramètres > Apprentissage.
2. Sélectionner le profil Général, Travail, Maison ou Nuit.
3. Ajouter une phrase déclencheuse et une ou plusieurs actions séparées par « puis » ou « ensuite ».
4. Pour l'apprentissage vocal, utiliser la formule : « Apprends que quand je dis [phrase], fais [action] ».
5. Prononcer la phrase déclencheuse pour exécuter la routine.

Exemple : « Routine matin » -> « ouvre WhatsApp puis joue ma musique ».
Les MP3/WAV doivent d'abord être importés dans l'application. « Joue ma musique » lance le premier fichier importé.

Tout reste local. Pas d'API IA ni de connexion Internet obligatoire. La reconnaissance vocale hors ligne exige un service Android compatible et un modèle français installé.
Voir V10_NOTES.md et BUILD_STATUS.txt. Compilation et tests sur téléphone à effectuer dans Android Studio.
