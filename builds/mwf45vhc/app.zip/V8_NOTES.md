# DOUBIGUE AI V8 — mode vocal hors ligne strict

## Décision d'architecture

La reconnaissance vocale est maintenant limitée au service Android de reconnaissance **sur l'appareil** (`SpeechRecognizer.createOnDeviceSpeechRecognizer`, Android 12 / API 31 minimum). Le code ne revient jamais à `createSpeechRecognizer`, car ce dernier peut utiliser un service distant selon le téléphone et sa configuration.

L'intention de reconnaissance est configurée en français (`fr-FR`) et demande explicitement le mode hors ligne (`EXTRA_PREFER_OFFLINE`). Si Android ne signale aucun moteur local, l'écoute est refusée avec un message explicite : aucune tentative réseau de secours n'est lancée.

La synthèse vocale sélectionne uniquement une voix française dont `Voice.isNetworkConnectionRequired` vaut `false`. Si aucune voix française locale n'est installée, DOUBIGUE AI l'indique et ne lance pas une voix réseau à sa place.

## Pré-requis sur le téléphone

- Android 12 ou supérieur pour l'API système de reconnaissance locale utilisée ici.
- Autorisation microphone accordée.
- Un service de reconnaissance Android qui expose la reconnaissance sur l'appareil.
- Modèle de langue français téléchargé dans les réglages du service vocal du téléphone.
- Voix française hors ligne installée pour la synthèse vocale.

Les intitulés des réglages changent selon le fabricant et la version Android. Sur un téléphone Pixel, vérifier les paramètres de l'application Google / Recherche vocale et les données linguistiques hors connexion, ainsi que les paramètres de synthèse vocale.

## Limites assumées

- Android 8 à Android 11 : le reste de l'application peut fonctionner, mais cette implémentation refuse la reconnaissance vocale car l'API système on-device dédiée n'y est pas disponible.
- Android peut ne pas proposer de modèle français local malgré la présence d'un service vocal. Dans ce cas, l'application explique le prérequis et n'utilise pas Internet comme solution de repli.
- Le code ne garantit pas que tous les fabricants respectent le mode hors ligne de la même manière. Il faut valider le comportement réel sur le téléphone cible, en coupant les données mobiles et le Wi-Fi pendant le test.
- L'intelligence conversationnelle et le routage des commandes restent locaux : aucune API IA n'est ajoutée dans cette version.

## Vérifications à effectuer

1. Installer le modèle français hors ligne et une voix TTS française locale.
2. Désactiver Wi-Fi et données mobiles.
3. Accorder l'autorisation microphone.
4. Dire « WhatsApp » et vérifier la transcription puis l'action.
5. Désinstaller temporairement le modèle local ou désactiver le service on-device : l'application doit afficher un message et ne doit pas basculer vers Internet.
6. Vérifier que la synthèse vocale fonctionne sans réseau.

## Version

- `versionCode`: 7
- `versionName`: 1.6.0
- Base : V7
- Compilation Android et essais sur appareil non effectués dans cet environnement.
