# DOUBIGUE AI V9 — Apprentissage local des commandes

## Nouveautés
- Nouvel écran **Paramètres > Apprentissage**.
- Création d'une règle : phrase déclencheuse -> commande existante.
- Liste des règles apprises et suppression individuelle.
- Correspondance stricte après normalisation (majuscules, accents et ponctuation ignorés) ; aucune correspondance approximative.
- Les commandes apprises sont stockées localement dans Room/SQLite.
- Migration Room 3 -> 4 pour préserver les configurations et conversations V8.
- Le déclencheur réutilise le routeur existant : application, lampe, Wi-Fi, Bluetooth, etc.
- Les commandes apprises ne sont pas exécutées si la phrase ne correspond pas exactement après normalisation.

## Exemple
Dans Paramètres > Apprentissage :
- Phrase à reconnaître : `Travail`
- Action : `ouvre WhatsApp`

Puis prononcer ou saisir `Travail`.

## Hors ligne et confidentialité
- Aucun SDK d'IA cloud, aucune API distante ajoutée.
- Le stockage des règles est local.
- La reconnaissance vocale reste soumise au moteur Android embarqué / modèle français hors ligne configuré sur le téléphone (V8).

## Limites
- Ce n'est pas un modèle qui apprend librement ou qui comprend toutes les formulations : l'utilisateur définit explicitement chaque association.
- Les actions restent limitées aux capacités Android déjà prises en charge par le projet.
- Android peut restreindre la visibilité ou le lancement de certaines applications selon la version et les autorisations.

## Vérification
- Tests unitaires ajoutés pour la correspondance exacte normalisée.
- Compilation Gradle et tests Android sur appareil : non exécutés dans cet environnement, faute de SDK Android/outil Gradle configuré.
