@file:OptIn(ExperimentalMaterial3Api::class)

package com.dlvibestudio.dlturbo.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.dlvibestudio.dlturbo.App
import com.dlvibestudio.dlturbo.engine.Links
import com.dlvibestudio.dlturbo.util.Format
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Coffre privé : dossier interne à l'appli (invisible dans la galerie et les autres applis), protégé par le code. */
object Vault {
    fun dir(app: App): File = File(app.filesDir, "vault").also { it.mkdirs() }

    /** Déplace un fichier dans le coffre. */
    fun put(app: App, file: File): Boolean = runCatching {
        val target = Links.uniqueFile(dir(app), file.name)
        file.copyTo(target)
        file.delete()
        true
    }.getOrDefault(false)

    /** Remet un fichier dans Téléchargements/Turbo Download/Restauré. */
    fun restore(app: App, file: File): Boolean = runCatching {
        val out = File(app.manager.baseDir, "Restauré").also { it.mkdirs() }
        val target = Links.uniqueFile(out, file.name)
        file.copyTo(target)
        file.delete()
        android.media.MediaScannerConnection.scanFile(app, arrayOf(target.path), null, null)
        true
    }.getOrDefault(false)
}

@Composable
fun VaultScreen(app: App, onClose: () -> Unit) {
    val context = LocalContext.current
    val pinSet = app.settings.value.pinHash.isNotEmpty()
    var unlocked by remember { mutableStateOf(false) }
    BackHandler(enabled = true) { onClose() }

    if (!pinSet) {
        Scaffold(topBar = { VaultBar(onClose, 0) }) { p ->
            Column(
                Modifier.fillMaxSize().padding(p).padding(28.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    "Le coffre est protégé par votre code. Définissez d'abord un code dans " +
                        "Paramètres → Sécurité → « Verrouiller l'application par code ».",
                    textAlign = TextAlign.Center,
                )
                Button(onClick = onClose, modifier = Modifier.padding(top = 16.dp)) { Text("Compris") }
            }
        }
        return
    }
    if (!unlocked) {
        LockScreen(app, onUnlock = { unlocked = true })
        return
    }

    var version by remember { mutableIntStateOf(0) }
    var files by remember { mutableStateOf<List<File>>(emptyList()) }
    var deleting by remember { mutableStateOf<File?>(null) }
    LaunchedEffect(version) {
        files = withContext(Dispatchers.IO) { Vault.dir(app).listFiles()?.filter { it.isFile }?.sortedBy { it.name.lowercase() } ?: emptyList() }
    }

    Scaffold(topBar = { VaultBar(onClose, files.size) }) { padding ->
        if (files.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text(
                    "Le coffre est vide.\nDans « Fichiers », menu ⋮ → « Mettre au coffre ».",
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        } else {
            LazyColumn(Modifier.fillMaxSize().padding(padding)) {
                items(files, key = { it.path }) { f ->
                    Row(
                        Modifier.fillMaxWidth().clickable { FileOpener.open(context, app, f) }
                            .padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(f.name, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                            Text(
                                Format.bytes(f.length()),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        IconButton(onClick = {
                            val ok = Vault.restore(app, f)
                            Toast.makeText(
                                context,
                                if (ok) "Remis dans Téléchargements/Turbo Download/Restauré" else "Échec",
                                Toast.LENGTH_SHORT,
                            ).show()
                            version++
                        }) { Icon(Icons.Filled.LockOpen, contentDescription = "Sortir du coffre") }
                        IconButton(onClick = { deleting = f }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Supprimer", tint = MaterialTheme.colorScheme.error)
                        }
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                }
            }
        }
    }

    deleting?.let { f ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Supprimer ?") },
            text = { Text(f.name) },
            confirmButton = {
                TextButton(onClick = { f.delete(); deleting = null; version++ }) {
                    Text("Supprimer", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Annuler") } },
        )
    }
}

@Composable
private fun VaultBar(onClose: () -> Unit, count: Int) {
    TopAppBar(
        title = { Text(if (count > 0) "Coffre ($count)" else "Coffre", fontWeight = FontWeight.Bold) },
        navigationIcon = {
            IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour") }
        },
    )
}
