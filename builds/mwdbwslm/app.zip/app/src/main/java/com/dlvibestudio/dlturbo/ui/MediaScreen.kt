@file:OptIn(UnstableApi::class)

package com.dlvibestudio.dlturbo.ui

import android.app.Activity
import android.content.ComponentName
import android.content.pm.ActivityInfo
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PictureInPictureAlt
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.runtime.collectAsState
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.common.util.RepeatModeUtil
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.dlvibestudio.dlturbo.service.PlaybackService
import java.io.File

private val SPEEDS = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)

/**
 * Lecteur vidéo et audio avec liste de lecture (tous les fichiers du même dossier).
 * La lecture passe par un service : la musique continue écran éteint ou si l'on quitte l'écran.
 */
@Composable
fun MediaScreen(files: List<File>, startIndex: Int, pip: Boolean = false, onClose: () -> Unit) {
    val context = LocalContext.current
    val activity = context as? Activity
    var controller by remember { mutableStateOf<MediaController?>(null) }
    var current by remember { mutableIntStateOf(startIndex.coerceIn(0, files.size - 1)) }
    var landscape by remember { mutableStateOf(false) }
    val app = context.applicationContext as com.dlvibestudio.dlturbo.App
    val timerEnd by com.dlvibestudio.dlturbo.service.SleepTimer.endAt.collectAsState()
    var timerMenu by remember { mutableStateOf(false) }
    var speedIndex by remember { mutableIntStateOf(SPEEDS.indexOf(1f)) }
    val isVideo = FileKinds.isVideo(files[current.coerceIn(0, files.size - 1)])

    DisposableEffect(files) {
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        var ctrl: MediaController? = null
        var listener: Player.Listener? = null
        var lastWasVideo = FileKinds.isVideo(files[startIndex.coerceIn(0, files.size - 1)])

        future.addListener({
            val c = try {
                future.get()
            } catch (_: Exception) {
                null
            } ?: return@addListener
            ctrl = c
            controller = c
            val items = files.map { f ->
                MediaItem.Builder()
                    .setUri(Uri.fromFile(f))
                    .setMediaId(f.path)
                    .setMediaMetadata(MediaMetadata.Builder().setTitle(FileKinds.realName(f).substringBeforeLast('.')).build())
                    .build()
            }
            c.setMediaItems(items, startIndex.coerceIn(0, files.size - 1), 0L)
            c.prepare()
            c.play()
            val l = object : Player.Listener {
                override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                    val i = c.currentMediaItemIndex
                    if (i in files.indices) {
                        current = i
                        lastWasVideo = FileKinds.isVideo(files[i])
                    }
                }
            }
            listener = l
            c.addListener(l)
        }, ContextCompat.getMainExecutor(context))

        onDispose {
            listener?.let { ctrl?.removeListener(it) }
            // Une vidéo ne doit pas continuer à jouer le son en cachette ; la musique, si.
            if (lastWasVideo) ctrl?.pause()
            MediaController.releaseFuture(future)
            controller = null
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    // Une vidéo à l'écran : l'activité peut passer en fenêtre flottante quand on quitte l'appli.
    DisposableEffect(isVideo) {
        app.videoOnScreen = isVideo
        onDispose { app.videoOnScreen = false }
    }

    Surface(Modifier.fillMaxSize(), color = Color.Black) {
        Column(Modifier.fillMaxSize()) {
            if (!pip) ViewerBar(
                title = files[current.coerceIn(0, files.size - 1)].nameWithoutExtension,
                onClose = onClose,
                modifier = Modifier.background(Color(0xFF111114)),
                actions = {
                    Box {
                        IconButton(onClick = { timerMenu = true }) {
                            Icon(
                                Icons.Filled.Timer, contentDescription = "Minuteur d'arrêt",
                                tint = if (timerEnd > 0) Color(0xFFF5B301) else Color.White,
                            )
                        }
                        DropdownMenu(expanded = timerMenu, onDismissRequest = { timerMenu = false }) {
                            if (timerEnd > 0) {
                                val left = ((timerEnd - System.currentTimeMillis()) / 60_000 + 1).coerceAtLeast(1)
                                DropdownMenuItem(
                                    text = { Text("Arrêt dans $left min · désactiver") },
                                    onClick = { timerMenu = false; com.dlvibestudio.dlturbo.service.SleepTimer.cancel() },
                                )
                            }
                            listOf(15, 30, 45, 60, 90).forEach { m ->
                                DropdownMenuItem(
                                    text = { Text("Arrêter dans $m min") },
                                    onClick = {
                                        timerMenu = false
                                        com.dlvibestudio.dlturbo.service.SleepTimer.start(m)
                                    },
                                )
                            }
                        }
                    }
                    if (isVideo && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                        IconButton(onClick = {
                            runCatching {
                                activity?.enterPictureInPictureMode(
                                    android.app.PictureInPictureParams.Builder()
                                        .setAspectRatio(android.util.Rational(16, 9)).build()
                                )
                            }
                        }) {
                            Icon(Icons.Filled.PictureInPictureAlt, contentDescription = "Fenêtre flottante", tint = Color.White)
                        }
                    }
                    TextButton(onClick = {
                        speedIndex = (speedIndex + 1) % SPEEDS.size
                        controller?.setPlaybackSpeed(SPEEDS[speedIndex])
                    }) {
                        Text(SPEEDS[speedIndex].toString().removeSuffix(".0") + "x", color = Color.White)
                    }
                    IconButton(onClick = {
                        landscape = !landscape
                        activity?.requestedOrientation =
                            if (landscape) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                            else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                    }) {
                        Icon(Icons.Filled.ScreenRotation, contentDescription = "Pivoter", tint = Color.White)
                    }
                },
            )

            Box(
                modifier = Modifier.fillMaxWidth().then(
                    if (isVideo) Modifier.weight(1f) else Modifier.height(300.dp)
                ),
            ) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        PlayerView(ctx).apply {
                            setShowShuffleButton(true)
                            setShowNextButton(true)
                            setShowPreviousButton(true)
                            setRepeatToggleModes(
                                RepeatModeUtil.REPEAT_TOGGLE_MODE_ONE or RepeatModeUtil.REPEAT_TOGGLE_MODE_ALL
                            )
                            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                            setShowSubtitleButton(true)
                        }
                    },
                    update = { view ->
                        view.player = controller
                        // Audio : les commandes restent affichées en permanence.
                        view.useController = !pip
                        view.controllerShowTimeoutMs = if (isVideo) 3000 else 0
                        view.setControllerHideOnTouch(isVideo)
                        if (!pip) view.showController()
                    },
                    onRelease = { it.player = null },
                )
                if (!isVideo) {
                    Icon(
                        Icons.Filled.MusicNote,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.35f),
                        modifier = Modifier.align(Alignment.TopCenter).padding(top = 40.dp).size(96.dp),
                    )
                }
            }

            if (files.size > 1 && !pip) {
                Text(
                    "Liste de lecture · ${files.size} fichiers",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                )
                val listState = rememberLazyListState()
                LaunchedEffect(current) { listState.animateScrollToItem(current.coerceAtLeast(0)) }
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxWidth().then(if (isVideo) Modifier.height(150.dp) else Modifier.weight(1f)),
                ) {
                    itemsIndexed(files) { index, f ->
                        val playing = index == current
                        Row(
                            modifier = Modifier.fillMaxWidth()
                                .clickable {
                                    controller?.seekToDefaultPosition(index)
                                    controller?.play()
                                }
                                .background(if (playing) Color(0x22F5B301) else Color.Transparent)
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(
                                if (FileKinds.isVideo(f)) Icons.Filled.Movie else Icons.Filled.MusicNote,
                                contentDescription = null,
                                tint = if (playing) MaterialTheme.colorScheme.primary else Color.Gray,
                                modifier = Modifier.size(20.dp),
                            )
                            Text(
                                f.nameWithoutExtension,
                                modifier = Modifier.weight(1f).padding(start = 12.dp),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                color = if (playing) MaterialTheme.colorScheme.primary else Color.White,
                                fontWeight = if (playing) FontWeight.Bold else FontWeight.Normal,
                            )
                        }
                    }
                }
            }
        }
    }
}
