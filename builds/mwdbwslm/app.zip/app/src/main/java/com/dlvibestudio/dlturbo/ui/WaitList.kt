@file:OptIn(ExperimentalMaterial3Api::class)

package com.dlvibestudio.dlturbo.ui

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.PlaylistAdd
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.dlvibestudio.dlturbo.engine.Links
import org.json.JSONArray
import org.json.JSONObject

/** Titre de page sans « streaming », « VF », nom du site… (sert de nom de fichier). */
fun cleanPageTitle(t: String): String =
    t.replace(Regex("""\s*[|\-–—]\s*[^|\-–—]*(streaming|voir|regarder|gratuit|torrent)[^|\-–—]*$""", RegexOption.IGNORE_CASE), "")
        .replace(Regex("""(?i)^\s*(regarder|voir|télécharger)\s+(gratuitement\s+)?(la série|le film|l'anime)?\s*"""), "")
        .replace(Regex("""(?i)\b(en streaming|streaming|vf et vostfr|vostfr|vf|gratuit|gratuitement)\b"""), "")
        .replace(Regex("""\s+"""), " ")
        .trim(' ', '-', '|', '–')
        .take(90)

/**
 * Liste d'attente du navigateur : pages d'épisodes ou de films ajoutées au fil de la navigation, puis
 * téléchargées en groupe (la vidéo de chaque page est repérée automatiquement). Conservée sur le téléphone.
 */
class WaitList(context: Context) {
    private val prefs = context.getSharedPreferences("dlturbo_waitlist", Context.MODE_PRIVATE)
    val items = mutableStateListOf<EpisodeItem>()

    init {
        runCatching {
            val arr = JSONArray(prefs.getString("list", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                items.add(EpisodeItem(o.getString("t"), o.getString("u"), 0))
            }
        }
    }

    fun contains(url: String) = items.any { it.url == url }

    /** Renvoie false si la page y était déjà. */
    fun add(title: String, url: String): Boolean {
        if (!url.startsWith("http") || contains(url)) return false
        items.add(EpisodeItem(title.ifBlank { url }.take(120), url, 0))
        save()
        return true
    }

    fun addAll(list: List<EpisodeItem>): Int {
        var n = 0
        list.forEach { if (it.url.startsWith("http") && !contains(it.url)) { items.add(it); n++ } }
        save()
        return n
    }

    fun removeAt(index: Int) {
        if (index in items.indices) items.removeAt(index)
        save()
    }

    fun moveUp(index: Int) {
        if (index <= 0 || index >= items.size) return
        val e = items.removeAt(index)
        items.add(index - 1, e)
        save()
    }

    fun clear() {
        items.clear()
        save()
    }

    private fun save() {
        val arr = JSONArray()
        items.forEach { arr.put(JSONObject().put("t", it.title).put("u", it.url)) }
        prefs.edit().putString("list", arr.toString()).apply()
    }
}

/** Bandeau du navigateur : nombre de pages en attente + accès à la liste. */
@Composable
fun WaitListBar(hub: WebHub) {
    val n = hub.waitList.items.size
    if (n == 0) return
    Surface(color = MaterialTheme.colorScheme.secondaryContainer, modifier = Modifier.fillMaxWidth()) {
        Row(
            Modifier.padding(start = 16.dp, end = 8.dp, top = 2.dp, bottom = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.AutoMirrored.Filled.PlaylistAdd, null, modifier = Modifier.size(20.dp))
            Text(
                "  $n page(s) dans la liste d'attente",
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
            )
            Button(onClick = { hub.waitOpen.value = true }) { Text("Télécharger") }
        }
    }
}

/** Liste d'attente : un format choisi ici (vidéo ou audio) s'applique à toutes les pages. */
@Composable
fun WaitListSheet(hub: WebHub, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val sheet = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var tab by remember { mutableIntStateOf(0) }
    var prefix by remember { mutableStateOf("") }
    val list = hub.waitList

    fun start(key: String) {
        val items = list.items.toList()
        if (items.isEmpty()) return
        if (hub.crawler.state.value?.running == true) {
            Toast.makeText(context, "Une recherche est déjà en cours : attendez la fin ou annulez-la.", Toast.LENGTH_LONG).show()
            return
        }
        hub.crawler.start(prefix.trim(), items, key)
        Toast.makeText(context, "Téléchargement groupé de ${items.size} page(s) lancé", Toast.LENGTH_LONG).show()
        list.clear()
        onDismiss()
    }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheet) {
        Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(bottom = 8.dp)) {
            Text(
                "Liste d'attente (${list.items.size})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
            )
            Text(
                "Chaque page est ouverte à tour de rôle : sa vidéo est repérée puis téléchargée.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 20.dp),
            )
            if (list.items.isEmpty()) {
                Text(
                    "La liste est vide. Sur une page d'épisode ou de film, ouvrez le bouton de téléchargement " +
                        "puis « Ajouter à la liste d'attente » (ou appui long sur un lien).",
                    modifier = Modifier.padding(20.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                return@Column
            }
            OutlinedTextField(
                value = prefix,
                onValueChange = { prefix = it },
                label = { Text("Préfixe des noms de fichiers (facultatif)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
            )
            LazyColumn(Modifier.heightIn(max = 240.dp)) {
                itemsIndexed(list.items.toList(), key = { _, e -> e.url }) { i, e ->
                    Row(
                        Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("${i + 1}.", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.width(32.dp))
                        Column(Modifier.weight(1f)) {
                            Text(e.title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                            Text(
                                Links.hostOf(e.url), maxLines = 1, style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        if (i > 0) {
                            IconButton(onClick = { list.moveUp(i) }) {
                                Icon(Icons.Filled.KeyboardArrowUp, contentDescription = "Monter")
                            }
                        }
                        IconButton(onClick = { list.removeAt(i) }) {
                            Icon(Icons.Filled.Close, contentDescription = "Retirer")
                        }
                    }
                }
            }
            HorizontalDivider(Modifier.padding(top = 4.dp))
            Text(
                "Choisissez le format : il sera appliqué à toutes les pages.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp),
            )
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Vidéo") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Audio (MP3…)") })
            }
            if (tab == 0) {
                listOf(
                    "best" to "Meilleure qualité", "1080" to "1080p (Full HD)", "720" to "720p (HD)",
                    "480" to "480p", "360" to "360p (plus léger)",
                ).forEach { (k, label) ->
                    OptionRow("MP4 · $label", "") { start(k) }
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                }
            } else {
                listOf(
                    Triple("mp3", "MP3", "Compatible partout"),
                    Triple("m4a", "M4A", "AAC · plus léger"),
                    Triple("wav", "WAV", "Sans compression · très volumineux"),
                ).forEach { (k, label, d) ->
                    OptionRow(label, d) { start(k) }
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                }
            }
            Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = { list.clear() }) { Text("Vider la liste") }
            }
        }
    }
}
