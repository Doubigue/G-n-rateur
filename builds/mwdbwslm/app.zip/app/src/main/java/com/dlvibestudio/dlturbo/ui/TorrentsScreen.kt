@file:OptIn(ExperimentalMaterial3Api::class)

package com.dlvibestudio.dlturbo.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.dlvibestudio.dlturbo.App
import com.dlvibestudio.dlturbo.data.DlStatus
import com.dlvibestudio.dlturbo.data.DlType
import com.dlvibestudio.dlturbo.data.DownloadItem
import com.dlvibestudio.dlturbo.engine.TorrentEngine
import com.dlvibestudio.dlturbo.util.Format
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DateFormat
import java.util.Date

private fun eta(seconds: Long): String = when {
    seconds < 0 -> ""
    seconds < 60 -> "${seconds} s"
    seconds < 3600 -> "${seconds / 60} min ${seconds % 60} s"
    else -> "${seconds / 3600} h ${(seconds % 3600) / 60} min"
}

/** Onglet « Torrents » : liste (Tous / En cours / Terminés), ajout d'un magnet ou .torrent, détail avec choix des fichiers. */
@Composable
fun TorrentsScreen(app: App) {
    val all by app.repo.items.collectAsState()
    val torrents = all.filter { it.type == DlType.TORRENT }
    var detailId by remember { mutableStateOf<String?>(null) }
    var tab by remember { mutableIntStateOf(0) }
    var adding by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<DownloadItem?>(null) }
    val settings by app.settings.data.collectAsState()
    val context = LocalContext.current

    val detail = torrents.firstOrNull { it.id == detailId }
    if (detail != null) {
        TorrentDetail(app, detail, onBack = { detailId = null })
        return
    }

    val shown = when (tab) {
        1 -> torrents.filter { it.status != DlStatus.COMPLETED }
        2 -> torrents.filter { it.status == DlStatus.COMPLETED }
        else -> torrents
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Torrents", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = { app.manager.pauseAll() }) { Icon(Icons.Filled.Pause, contentDescription = "Tout mettre en pause") }
                    IconButton(onClick = { app.manager.resumeAll() }) { Icon(Icons.Filled.PlayArrow, contentDescription = "Tout reprendre") }
                },
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { adding = true }) { Icon(Icons.Filled.Add, contentDescription = "Ajouter un torrent") }
        },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            TabRow(selectedTabIndex = tab) {
                listOf("Tous (${torrents.size})", "En cours", "Terminés").forEachIndexed { i, l ->
                    Tab(selected = tab == i, onClick = { tab = i }, text = { Text(l) })
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Partager après le téléchargement", modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                Switch(checked = settings.torrentSeed, onCheckedChange = { v -> app.settings.update { it.copy(torrentSeed = v) } })
            }
            HorizontalDivider()
            if (shown.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        "Aucun torrent.\nAppuyez sur + pour coller un lien magnet ou choisir un fichier .torrent.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(32.dp),
                    )
                }
            } else {
                LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp, 8.dp, 12.dp, 88.dp)) {
                    items(shown, key = { it.id }) { t ->
                        TorrentCard(
                            t,
                            onOpen = { detailId = t.id },
                            onToggle = { if (t.status.isActive) app.manager.pause(t.id) else app.manager.resume(t.id) },
                            onDelete = { deleting = t },
                        )
                    }
                }
            }
        }
    }

    if (adding) AddTorrentDialog(app, onDismiss = { adding = false })

    deleting?.let { t ->
        var withFiles by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Supprimer ce torrent ?") },
            text = {
                Column {
                    Text(t.fileName, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Row(Modifier.clickable { withFiles = !withFiles }.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(withFiles, { withFiles = it })
                        Text("Supprimer aussi les fichiers téléchargés")
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    app.manager.remove(t.id, withFiles)
                    deleting = null
                    Toast.makeText(context, "Torrent supprimé", Toast.LENGTH_SHORT).show()
                }) { Text("Supprimer", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Annuler") } },
        )
    }
}

@Composable
private fun TorrentCard(t: DownloadItem, onOpen: () -> Unit, onToggle: () -> Unit, onDelete: () -> Unit) {
    val done = t.status == DlStatus.COMPLETED
    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable(onClick = onOpen)) {
        Column(Modifier.padding(start = 14.dp, top = 10.dp, bottom = 8.dp, end = 4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(t.fileName, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                    val line = buildList {
                        if (t.totalBytes > 0) add(Format.bytes(t.totalBytes))
                        when {
                            done -> add("Terminé")
                            t.status == DlStatus.PAUSED -> add("En pause")
                            t.status == DlStatus.ERROR -> add(t.error ?: "Erreur")
                            t.status == DlStatus.WAITING_NETWORK -> add("En attente du réseau")
                            else -> {
                                if (t.speed > 0) add(Format.bytes(t.speed) + "/s")
                                val e = eta(t.etaSeconds)
                                if (e.isNotEmpty()) add(e)
                            }
                        }
                    }.joinToString(" · ")
                    Text(line, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (t.info.isNotBlank() && !done) {
                        Text(t.info, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                    }
                }
                if (!done) {
                    IconButton(onClick = onToggle) {
                        Icon(
                            if (t.status.isActive) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            contentDescription = if (t.status.isActive) "Pause" else "Reprendre",
                        )
                    }
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Filled.Delete, contentDescription = "Supprimer", tint = MaterialTheme.colorScheme.error)
                }
            }
            if (!done) {
                LinearProgressIndicator(
                    progress = { t.progress },
                    modifier = Modifier.fillMaxWidth().padding(end = 10.dp, top = 4.dp).height(5.dp),
                )
                Text(
                    "${t.percentInt} %",
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.padding(top = 2.dp),
                )
            }
        }
    }
}

@Composable
private fun AddTorrentDialog(app: App, onDismiss: () -> Unit) {
    val context = LocalContext.current
    var text by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("vide")
                val name = uri.lastPathSegment?.substringAfterLast('/')?.removeSuffix(".torrent") ?: "torrent"
                app.manager.enqueueTorrentFile(bytes, name)
                Toast.makeText(context, "Torrent ajouté", Toast.LENGTH_SHORT).show()
                onDismiss()
            }.onFailure { Toast.makeText(context, "Fichier .torrent illisible", Toast.LENGTH_SHORT).show() }
        }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Ajouter un torrent") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = text, onValueChange = { text = it },
                    label = { Text("Lien magnet ou adresse .torrent") },
                    modifier = Modifier.fillMaxWidth(), minLines = 2,
                )
                OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth()) {
                    Text("Choisir un fichier .torrent")
                }
            }
        },
        confirmButton = {
            TextButton(enabled = text.isNotBlank(), onClick = {
                app.manager.enqueueText(text)
                Toast.makeText(context, "Torrent ajouté", Toast.LENGTH_SHORT).show()
                onDismiss()
            }) { Text("Ajouter") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } },
    )
}

/** Détail d'un torrent : fichiers (cases à cocher, lecture), lecture dans l'ordre, informations. */
@Composable
internal fun TorrentDetail(app: App, item: DownloadItem, onBack: () -> Unit) {
    val context = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var live by remember { mutableStateOf<TorrentEngine.Live?>(null) }
    val files by produceFiles(app, item.id, item.fileName)
    val details by produceDetails(app, item.id, item.fileName)
    val skip = remember(item.ignored) { item.ignored.split(',').mapNotNull { it.trim().toIntOrNull() }.toSet() }
    BackHandler(enabled = true) { onBack() }

    LaunchedEffect(item.id) {
        while (true) {
            live = withContext(Dispatchers.IO) { app.manager.torrents.live(item.id) }
            delay(1000)
        }
    }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(item.fileName, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour") } },
        )
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Fichiers (${files.size})") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Détails") })
            }
            if (tab == 0) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Lire pendant le téléchargement")
                        Text(
                            "Télécharge dans l'ordre pour pouvoir lancer une vidéo avant la fin.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Switch(checked = item.sequential, onCheckedChange = { app.manager.torrents.setSequential(item.id, it) })
                }
                HorizontalDivider()
                if (files.isEmpty()) {
                    Text(
                        "La liste des fichiers apparaît dès que les métadonnées sont récupérées.",
                        modifier = Modifier.padding(24.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                } else {
                    LazyColumn(Modifier.fillMaxSize()) {
                        items(files, key = { it.index }) { f ->
                            val wanted = f.index !in skip
                            val got = live?.fileProgress?.getOrNull(f.index) ?: if (item.status == DlStatus.COMPLETED && wanted) f.size else 0L
                            val frac = if (f.size > 0) (got.toFloat() / f.size).coerceIn(0f, 1f) else 0f
                            val disk = File(item.dir, f.path)
                            Row(
                                Modifier.fillMaxWidth().clickable(enabled = disk.isFile && disk.length() > 0) {
                                    FileOpener.open(context, app, disk)
                                }.padding(start = 8.dp, end = 12.dp, top = 6.dp, bottom = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Checkbox(wanted, {
                                    app.manager.torrents.setFileWanted(item.id, f.index, it)
                                    if (it && !item.status.isActive) app.manager.restartTorrent(item.id)
                                })
                                Column(Modifier.weight(1f)) {
                                    Text(f.path.substringAfterLast('/'), maxLines = 2, overflow = TextOverflow.Ellipsis)
                                    Text(
                                        Format.bytes(f.size) + if (wanted) " · ${(frac * 100).toInt()} %" else " · ignoré",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                    if (wanted && frac < 1f) {
                                        LinearProgressIndicator(progress = { frac }, modifier = Modifier.fillMaxWidth().padding(top = 3.dp).height(3.dp))
                                    }
                                }
                            }
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                        }
                    }
                }
            } else {
                Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    val d = details
                    val l = live
                    Info("Nom", item.fileName)
                    Info("Taille", if (item.totalBytes > 0) Format.bytes(item.totalBytes) else "?")
                    Info("Avancement", "${item.percentInt} %")
                    Info("Dossier", item.dir)
                    if (d != null) {
                        Info("Empreinte (hash)", d.hash)
                        Info("Pièces", "${d.pieces} × ${Format.bytes(d.pieceLength.toLong())}")
                        if (d.createdAt > 0) Info("Créé le", DateFormat.getDateInstance().format(Date(d.createdAt * 1000)))
                        if (d.creator.isNotBlank()) Info("Créé avec", d.creator)
                        if (d.comment.isNotBlank()) Info("Commentaire", d.comment)
                    }
                    if (l != null) {
                        Info("Sources / pairs", "${l.seeds} / ${l.peers}")
                        Info("Trackers", l.trackers.toString())
                        Info("Envoi", Format.bytes(l.uploadRate) + "/s")
                        val ratio = if (l.downloaded > 0) l.uploaded.toFloat() / l.downloaded else 0f
                        Info("Partage", Format.bytes(l.uploaded) + String.format(" (ratio %.2f)", ratio))
                    }
                    Button(onClick = { app.openFolder.value = File(item.dir) }, modifier = Modifier.fillMaxWidth()) {
                        Text("Ouvrir le dossier")
                    }
                }
            }
        }
    }
}

@Composable
private fun produceFiles(app: App, id: String, key: String) =
    androidx.compose.runtime.produceState(emptyList<TorrentEngine.TorrentFile>(), id, key) {
        // Les métadonnées peuvent arriver après l'ouverture : on réessaie jusqu'à les avoir.
        while (value.isEmpty()) {
            value = withContext(Dispatchers.IO) { app.manager.torrents.files(id) }
            if (value.isEmpty()) delay(1500)
        }
    }

@Composable
private fun produceDetails(app: App, id: String, key: String) =
    androidx.compose.runtime.produceState<TorrentEngine.Details?>(null, id, key) {
        while (value == null) {
            value = withContext(Dispatchers.IO) { app.manager.torrents.details(id) }
            if (value == null) delay(1500)
        }
    }

@Composable
private fun Info(label: String, value: String) {
    Column {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}
