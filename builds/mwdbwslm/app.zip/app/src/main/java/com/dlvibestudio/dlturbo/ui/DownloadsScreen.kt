@file:OptIn(ExperimentalMaterial3Api::class)

package com.dlvibestudio.dlturbo.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DeviceHub
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.dlvibestudio.dlturbo.App
import com.dlvibestudio.dlturbo.R
import com.dlvibestudio.dlturbo.data.DlStatus
import com.dlvibestudio.dlturbo.data.DlType
import com.dlvibestudio.dlturbo.data.DownloadItem
import com.dlvibestudio.dlturbo.engine.Links
import com.dlvibestudio.dlturbo.util.Format
import java.io.File

@Composable
fun DownloadsScreen(app: App, pendingText: MutableState<String?>, onOpenSettings: () -> Unit) {
    val items by app.repo.items.collectAsState()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var showAdd by rememberSaveable { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }

    val active = items.filter { it.status != DlStatus.COMPLETED }
    val completed = items.filter { it.status == DlStatus.COMPLETED }
    val running = items.count { it.status.isActive }
    val totalSpeed = items.sumOf { it.speed }
    var searchOpen by rememberSaveable { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    var sort by rememberSaveable { mutableIntStateOf(0) } // 0 récents, 1 nom, 2 taille
    var statsOpen by remember { mutableStateOf(false) }
    val torrentItems = items.filter { it.type == DlType.TORRENT }
    var torrentDetail by rememberSaveable { mutableStateOf<String?>(null) }
    val base = when (tab) {
        1 -> active
        2 -> completed
        3 -> torrentItems
        else -> items
    }
    val filtered = if (query.isBlank()) base else base.filter { it.fileName.contains(query.trim(), ignoreCase = true) }
    val visible = when (sort) {
        1 -> filtered.sortedBy { it.fileName.lowercase() }
        2 -> filtered.sortedByDescending { maxOf(it.totalBytes, it.downloadedBytes) }
        else -> filtered
    }

    val openTorrent = items.firstOrNull { it.id == torrentDetail && it.type == DlType.TORRENT }
    if (openTorrent != null) {
        TorrentDetail(app, openTorrent, onBack = { torrentDetail = null })
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painter = painterResource(R.drawable.logo),
                            contentDescription = null,
                            modifier = Modifier.size(34.dp).clip(RoundedCornerShape(9.dp)),
                        )
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("Turbo Download", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                            Text(
                                text = if (running > 0) "$running en cours · ${Format.speed(totalSpeed)}"
                                else "${items.size} téléchargement" + if (items.size > 1) "s" else "",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                },
                actions = {
                    IconButton(onClick = { searchOpen = !searchOpen; if (!searchOpen) query = "" }) {
                        Icon(
                            if (searchOpen) Icons.Filled.Close else Icons.Filled.Search,
                            contentDescription = "Rechercher",
                        )
                    }
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Filled.Settings, contentDescription = "Paramètres")
                    }
                    Box {
                        IconButton(onClick = { menuOpen = true }) {
                            Icon(Icons.Filled.MoreVert, contentDescription = "Plus d'actions")
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(
                                text = { Text("Tout suspendre") },
                                onClick = { menuOpen = false; app.manager.pauseAll() },
                            )
                            DropdownMenuItem(
                                text = { Text("Tout reprendre") },
                                onClick = { menuOpen = false; app.manager.resumeAll() },
                            )
                            DropdownMenuItem(
                                text = { Text(if (sort == 0) "✓ Trier : récents" else "Trier : récents") },
                                onClick = { menuOpen = false; sort = 0 },
                            )
                            DropdownMenuItem(
                                text = { Text(if (sort == 1) "✓ Trier : nom" else "Trier : nom") },
                                onClick = { menuOpen = false; sort = 1 },
                            )
                            DropdownMenuItem(
                                text = { Text(if (sort == 2) "✓ Trier : taille" else "Trier : taille") },
                                onClick = { menuOpen = false; sort = 2 },
                            )
                            DropdownMenuItem(
                                text = { Text("Statistiques") },
                                onClick = { menuOpen = false; statsOpen = true },
                            )
                            DropdownMenuItem(
                                text = { Text("Vider la liste des terminés") },
                                onClick = { menuOpen = false; app.manager.clearCompleted() },
                            )
                        }
                    }
                },
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAdd = true },
                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                text = { Text("Ajouter") },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
            )
        },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            if (searchOpen) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Rechercher un téléchargement…") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
                )
            }
            ScrollableTabRow(selectedTabIndex = tab, edgePadding = 4.dp) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Tous (${items.size})") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("En cours (${active.size})") })
                Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("Terminés (${completed.size})") })
                Tab(selected = tab == 3, onClick = { tab = 3 }, text = { Text("Torrents (${torrentItems.size})") })
            }
            if (visible.isEmpty()) {
                EmptyState()
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    items(visible, key = { it.id }) { item ->
                        DownloadCard(item, app, expandedDefault = tab == 3, onOpenTorrent = { torrentDetail = item.id })
                    }
                }
            }
        }
    }

    if (statsOpen) StatsDialog(items, onDismiss = { statsOpen = false })

    val shared = pendingText.value
    if (showAdd || shared != null) {
        AddDialog(
            app = app,
            initialText = shared ?: "",
            onDismiss = {
                showAdd = false
                pendingText.value = null
            },
        )
    }
}

@Composable
private fun EmptyState() {
    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(
            Icons.Filled.CloudDownload,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(72.dp),
        )
        Spacer(Modifier.height(16.dp))
        Text("Aucun téléchargement", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Text(
            "Appuyez sur « Ajouter » pour coller un lien, un magnet ou choisir un fichier .torrent.\n" +
                "Vous pouvez aussi utiliser « Partager » depuis YouTube, Instagram, TikTok, Facebook, " +
                "Pinterest ou votre navigateur.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
    }
}

private fun iconFor(item: DownloadItem): ImageVector = when {
    item.type == DlType.TORRENT -> Icons.Filled.DeviceHub
    item.type == DlType.VIDEO && item.quality == "audio" -> Icons.Filled.MusicNote
    item.type == DlType.VIDEO -> Icons.Filled.Movie
    else -> when (Links.category(item.fileName)) {
        "Vidéos" -> Icons.Filled.Movie
        "Musique" -> Icons.Filled.MusicNote
        "Images" -> Icons.Filled.Image
        "APK" -> Icons.Filled.Android
        else -> Icons.Filled.Description
    }
}

@Composable
private fun DownloadCard(
    item: DownloadItem,
    app: App,
    expandedDefault: Boolean = false,
    onOpenTorrent: () -> Unit = {},
) {
    val context = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    val colors = MaterialTheme.colorScheme
    // Logo de l'application : lu dans l'APK une fois téléchargé (pendant le téléchargement, icône Android).
    val apkFile = remember(item.dir, item.fileName) { File(item.dir, item.fileName) }
    val isApk = item.type == DlType.HTTP && com.dlvibestudio.dlturbo.engine.ApkInstaller.isApk(apkFile)
    var appIcon by remember(apkFile.path, item.status) { mutableStateOf<android.graphics.Bitmap?>(null) }
    if (isApk && item.status == DlStatus.COMPLETED) {
        LaunchedEffect(apkFile.path, item.status) {
            appIcon = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { Thumbs.apk(context, apkFile) }
        }
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = colors.surfaceContainer),
        shape = RoundedCornerShape(16.dp),
        // Terminé : ouverture ; en cours ou en pause : lecture de la partie déjà téléchargée.
        onClick = {
            when {
                // Torrent (saison entière…) : ouverture du torrent, avec la liste de ses épisodes.
                item.type == DlType.TORRENT -> onOpenTorrent()
                item.status == DlStatus.COMPLETED -> openItem(context, app, item)
                else -> openPartial(context, app, item)
            }
        },
    ) {
        Row(Modifier.padding(start = 12.dp, top = 12.dp, bottom = 12.dp, end = 4.dp)) {
            Box(
                modifier = Modifier.size(42.dp).clip(if (appIcon != null) RoundedCornerShape(10.dp) else CircleShape)
                    .background(if (appIcon != null) androidx.compose.ui.graphics.Color.Transparent else colors.primaryContainer),
                contentAlignment = Alignment.Center,
            ) {
                val icon = appIcon
                if (icon != null) {
                    Image(bitmap = icon.asImageBitmap(), contentDescription = null, modifier = Modifier.fillMaxSize())
                } else {
                    Icon(iconFor(item), contentDescription = null, tint = colors.onPrimaryContainer)
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    item.fileName,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(6.dp))

                if (item.status != DlStatus.COMPLETED) {
                    val indeterminate = (item.status == DlStatus.CONNECTING) ||
                        (item.status == DlStatus.RUNNING && item.totalBytes <= 0 && item.percent < 0f)
                    val barColor = when (item.status) {
                        DlStatus.ERROR -> colors.error
                        DlStatus.PAUSED, DlStatus.QUEUED, DlStatus.WAITING_NETWORK -> colors.outline
                        else -> colors.primary
                    }
                    if (indeterminate) {
                        LinearProgressIndicator(
                            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                            color = barColor,
                            trackColor = colors.surfaceContainerHighest,
                        )
                    } else {
                        LinearProgressIndicator(
                            progress = { item.progress },
                            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                            color = barColor,
                            trackColor = colors.surfaceContainerHighest,
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                }

                Text(
                    statusLine(item),
                    style = MaterialTheme.typography.bodySmall,
                    color = if (item.status == DlStatus.ERROR) colors.error else colors.onSurfaceVariant,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                )
                val detail = detailLine(item)
                if (detail.isNotBlank()) {
                    Text(
                        detail,
                        style = MaterialTheme.typography.labelSmall,
                        color = colors.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                when {
                    item.status.isActive -> FilledTonalIconButton(onClick = { app.manager.pause(item.id) }) {
                        Icon(Icons.Filled.Pause, contentDescription = "Pause")
                    }
                    item.status == DlStatus.PAUSED -> FilledTonalIconButton(onClick = { app.manager.resume(item.id) }) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = "Reprendre")
                    }
                    item.status == DlStatus.ERROR -> FilledTonalIconButton(onClick = { app.manager.resume(item.id) }) {
                        Icon(Icons.Filled.Refresh, contentDescription = "Réessayer")
                    }
                }
                Box {
                    IconButton(onClick = { menu = true }) {
                        Icon(Icons.Filled.MoreVert, contentDescription = "Options")
                    }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        if (item.status != DlStatus.COMPLETED) {
                            DropdownMenuItem(
                                text = { Text("Lire la partie téléchargée") },
                                onClick = { menu = false; openPartial(context, app, item) },
                            )
                            DropdownMenuItem(
                                text = { Text("Voir dans les fichiers") },
                                onClick = {
                                    menu = false
                                    app.openFolder.value = partialFileFor(item, app)?.takeIf { it.path.startsWith(item.dir) } ?: File(item.dir)
                                },
                            )
                        }
                        if (item.status == DlStatus.COMPLETED) {
                            DropdownMenuItem(
                                text = { Text("Ouvrir") },
                                onClick = { menu = false; openItem(context, app, item) },
                            )
                            DropdownMenuItem(
                                text = { Text("Partager") },
                                onClick = { menu = false; shareItem(context, item) },
                            )
                        }
                        DropdownMenuItem(
                            text = { Text("Copier le lien") },
                            onClick = {
                                menu = false
                                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                cm.setPrimaryClip(ClipData.newPlainText("lien", item.url))
                                Toast.makeText(context, "Lien copié", Toast.LENGTH_SHORT).show()
                            },
                        )
                        HorizontalDivider()
                        DropdownMenuItem(
                            text = { Text("Retirer de la liste") },
                            onClick = { menu = false; app.manager.remove(item.id, deleteFile = false) },
                        )
                        DropdownMenuItem(
                            text = { Text("Supprimer le fichier", color = colors.error) },
                            leadingIcon = { Icon(Icons.Filled.Delete, contentDescription = null, tint = colors.error) },
                            onClick = { menu = false; app.manager.remove(item.id, deleteFile = true) },
                        )
                    }
                }
            }
        }
        // Torrent : épisodes de la saison (ou fichiers) directement dans la liste des téléchargements.
        if (item.type == DlType.TORRENT) {
            var showFiles by remember(item.id) { mutableStateOf(expandedDefault) }
            TextButton(
                onClick = { showFiles = !showFiles },
                modifier = Modifier.padding(start = 4.dp),
            ) {
                Text(if (showFiles) "Masquer les épisodes / fichiers" else "Voir les épisodes / fichiers")
            }
            if (showFiles) TorrentEpisodes(app, item)
        }
    }
}

private fun statusLine(item: DownloadItem): String {
    val sizes = when {
        item.totalBytes > 0 -> "${Format.bytes(item.downloadedBytes)} / ${Format.bytes(item.totalBytes)}"
        item.downloadedBytes > 0 -> Format.bytes(item.downloadedBytes)
        else -> ""
    }
    val known = item.totalBytes > 0 || item.percent >= 0f
    val parts = ArrayList<String>()
    when (item.status) {
        DlStatus.QUEUED -> parts.add("En file d'attente")
        DlStatus.CONNECTING -> parts.add(item.info.ifBlank { "Connexion…" })
        DlStatus.WAITING_NETWORK -> {
            parts.add(item.info.ifBlank { "En attente du réseau" })
            if (known) parts.add("${item.percentInt} %")
        }
        DlStatus.RUNNING -> {
            if (known) parts.add("${item.percentInt} %")
            if (sizes.isNotBlank()) parts.add(sizes)
            if (item.speed > 0) parts.add(Format.speed(item.speed))
            if (item.etaSeconds >= 0) parts.add("reste ${Format.duration(item.etaSeconds)}")
            if (parts.isEmpty()) parts.add(item.info.ifBlank { "Téléchargement…" })
        }
        DlStatus.PAUSED -> {
            parts.add("En pause")
            if (known) parts.add("${item.percentInt} %")
            if (sizes.isNotBlank()) parts.add(sizes)
        }
        DlStatus.ERROR -> parts.add(item.error ?: "Erreur")
        DlStatus.COMPLETED -> {
            parts.add("Terminé")
            if (item.totalBytes > 0) parts.add(Format.bytes(item.totalBytes))
        }
    }
    return parts.joinToString(" · ")
}

private fun detailLine(item: DownloadItem): String = when (item.status) {
    DlStatus.RUNNING -> item.info
    DlStatus.ERROR -> item.info
    DlStatus.COMPLETED -> File(item.dir).name
    else -> ""
}

private fun openItem(context: Context, app: App, item: DownloadItem) {
    FileOpener.open(context, app, File(item.dir, item.fileName))
}

/**
 * Fichier partiel d'un téléchargement en cours ou en pause : « nom.dlpart » (liens directs), « nom.part »
 * (extracteur vidéo, flux HLS…), ou le fichier lui-même (torrents).
 */
internal fun partialFileFor(item: DownloadItem, app: App): File? {
    val dir = File(item.dir)
    val name = item.fileName
    listOf(File(dir, name + com.dlvibestudio.dlturbo.engine.Links.PART_SUFFIX), File(dir, "$name.part"), File(dir, name))
        .firstOrNull { it.isFile && it.length() > 0 }?.let { return it }
    if (item.type != DlType.VIDEO) return null
    // Extracteur vidéo : « Titre [id].f137.mp4.part », « Titre.mp4.part »… dans son dossier de travail privé.
    val stem = name.substringBeforeLast('.').replace(Regex("""\.f\d+$"""), "")
    if (stem.length < 4) return null
    return app.manager.videos.tempDir(item.id).walkTopDown().maxDepth(3)
        .filter { it.isFile && it.name.startsWith(stem) && it.length() > 0 && !FileKinds.isHelper(it) && FileKinds.isMedia(it) }
        .maxByOrNull { it.length() }
}

private fun openPartial(context: Context, app: App, item: DownloadItem) {
    val f = partialFileFor(item, app)
    when {
        f == null -> Toast.makeText(
            context, "Rien à lire pour l'instant : le début de la vidéo n'est pas encore arrivé", Toast.LENGTH_SHORT,
        ).show()
        FileKinds.isMedia(f) -> {
            if (FileKinds.isPartial(f)) {
                Toast.makeText(context, "Lecture de la partie déjà téléchargée", Toast.LENGTH_SHORT).show()
            }
            app.viewer.value = ViewerRequest.Media(listOf(f), 0)
        }
        else -> FileOpener.open(context, app, f)
    }
}

private fun shareItem(context: Context, item: DownloadItem) {
    val file = File(item.dir, item.fileName)
    if (!file.isFile) {
        Toast.makeText(context, "Impossible de partager (dossier ou fichier introuvable)", Toast.LENGTH_SHORT).show()
        return
    }
    FileOpener.share(context, file)
}
