package com.dlvibestudio.dlturbo.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dlvibestudio.dlturbo.R
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val SplashGold = Color(0xFFF5B301)

/**
 * Écran de démarrage : logo de l'appli au centre, puis « Created by » et le logo DL VIBE STUDIO en bas
 * (fond transparent, apparition animée + reflet doré qui passe dessus). Un appui le passe.
 */
@Composable
fun SplashScreen(onDone: () -> Unit) {
    val appLogo = remember { Animatable(0f) }
    val credit = remember { Animatable(0f) }
    val exit = remember { Animatable(1f) }

    LaunchedEffect(Unit) {
        launch { appLogo.animateTo(1f, spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessLow)) }
        delay(450)
        credit.animateTo(1f, tween(900, easing = FastOutSlowInEasing))
        delay(900)
        exit.animateTo(0f, tween(350))
        onDone()
    }

    val loop = rememberInfiniteTransition(label = "splash")
    // Reflet qui balaie le logo DL VIBE STUDIO
    val shine by loop.animateFloat(
        initialValue = -0.4f, targetValue = 1.4f,
        animationSpec = infiniteRepeatable(tween(1600, easing = LinearEasing), RepeatMode.Restart),
        label = "shine",
    )
    // Léger « souffle » du logo
    val pulse by loop.animateFloat(
        initialValue = 0.97f, targetValue = 1.03f,
        animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse",
    )

    Box(
        Modifier.fillMaxSize()
            .graphicsLayer { alpha = exit.value }
            .background(Brush.verticalGradient(listOf(Color(0xFF0E0E14), Color(0xFF17130A), Color(0xFF0E0E14))))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onDone() },
    ) {
        // Centre : logo et nom de l'appli
        Column(
            Modifier.align(Alignment.Center).padding(bottom = 80.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Image(
                painter = painterResource(R.drawable.logo),
                contentDescription = null,
                modifier = Modifier
                    .size(112.dp)
                    .graphicsLayer {
                        val v = appLogo.value
                        scaleX = 0.4f + 0.6f * v
                        scaleY = 0.4f + 0.6f * v
                        alpha = v.coerceIn(0f, 1f)
                        rotationZ = (1f - v) * -25f
                    }
                    .clip(RoundedCornerShape(28.dp)),
            )
            Spacer(Modifier.height(18.dp))
            Text(
                "Turbo Download",
                color = Color.White,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.graphicsLayer {
                    alpha = appLogo.value.coerceIn(0f, 1f)
                    translationY = (1f - appLogo.value) * 40f
                },
            )
            Text(
                "Téléchargez tout, vite.",
                color = SplashGold,
                fontSize = 14.sp,
                modifier = Modifier.graphicsLayer { alpha = credit.value },
            )
        }

        // Bas : « Created by » puis le logo DL VIBE STUDIO (transparent, animé)
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(bottom = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Bottom,
        ) {
            Text(
                "Created by",
                color = Color.White.copy(alpha = 0.75f),
                fontSize = 13.sp,
                letterSpacing = 3.sp,
                modifier = Modifier.graphicsLayer { alpha = credit.value },
            )
            Spacer(Modifier.height(6.dp))
            Image(
                painter = painterResource(R.drawable.dl_vibe_logo),
                contentDescription = "DL VIBE STUDIO – Doubigue Loubikoa",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .widthIn(max = 230.dp)
                    .fillMaxWidth(0.6f)
                    .graphicsLayer {
                        val v = credit.value
                        alpha = v
                        val s = (0.7f + 0.3f * v) * pulse
                        scaleX = s
                        scaleY = s
                        translationY = (1f - v) * 60f
                        compositingStrategy = CompositingStrategy.Offscreen
                    }
                    .drawWithContent {
                        drawContent()
                        // Reflet doré limité aux zones visibles du logo (BlendMode.SrcAtop).
                        val x = size.width * shine
                        drawRect(
                            brush = Brush.linearGradient(
                                colors = listOf(Color.Transparent, Color.White.copy(alpha = 0.55f), Color.Transparent),
                                start = Offset(x - size.width * 0.25f, 0f),
                                end = Offset(x + size.width * 0.25f, size.height),
                            ),
                            blendMode = BlendMode.SrcAtop,
                        )
                    },
            )
        }
    }
}
