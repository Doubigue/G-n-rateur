package com.dlvibestudio.dlturbo.ui

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.FileProvider
import com.dlvibestudio.dlturbo.App
import com.dlvibestudio.dlturbo.engine.ApkInstaller
import com.dlvibestudio.dlturbo.engine.ArchiveManager
import com.dlvibestudio.dlturbo.engine.Links
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Ce que l'on peut afficher en plein écran par-dessus l'application. */
sealed interface ViewerRequest {
    data class Media(val files: List<File>, val index: Int) : ViewerRequest
    data class Images(val files: List<File>, val index: Int) : ViewerRequest
    data class WebFile(val file: File) : ViewerRequest
    data class TextFile(val file: File) : ViewerRequest
    data class Archive(val file: File) : ViewerRequest
}

object FileKinds {
    val VIDEO = setOf("mp4", "mkv", "webm", "avi", "mov", "flv", "3gp", "m4v", "ts", "wmv", "mpg", "mpeg")
    val AUDIO = setOf("mp3", "m4a", "aac", "flac", "wav", "ogg", "opus", "wma", "amr", "mka")
    val IMAGE = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif", "avif")
    val WEB = setOf("html", "htm", "xhtml", "mhtml", "mht", "svg")
    val TEXT = setOf(
        "txt", "log", "md", "json", "xml", "csv", "ini", "conf", "yml", "yaml", "srt", "vtt", "nfo", "js", "css",
    )

    private val FRAGMENT = Regex("""(?i)\.part-frag\d+|\.ytdl$|\.temp$|\.f\d+\.\w+\.part-""")

    /** Fichier en cours de téléchargement (ou en pause) : « .dlpart » de l'appli, « .part » de l'extracteur vidéo. */
    fun isPartial(f: File): Boolean {
        val n = f.name.lowercase()
        return n.endsWith(com.dlvibestudio.dlturbo.engine.Links.PART_SUFFIX) || (n.endsWith(".part") && !isHelper(f))
    }

    /** Morceaux techniques de l'extracteur (fragments, état de reprise) : jamais affichés. */
    fun isHelper(f: File): Boolean = FRAGMENT.containsMatchIn(f.name)

    /** Nom du fichier une fois terminé (sans « .part » / « .dlpart »). */
    fun realName(f: File): String {
        val n = f.name.removeSuffix(com.dlvibestudio.dlturbo.engine.Links.PART_SUFFIX)
        return if (n.endsWith(".part", ignoreCase = true)) n.dropLast(5) else n
    }

    private fun ext(f: File) = realName(f).substringAfterLast('.', "").lowercase()

    fun isVideo(f: File) = ext(f) in VIDEO
    fun isAudio(f: File) = ext(f) in AUDIO
    fun isMedia(f: File) = isVideo(f) || isAudio(f)
    fun isImage(f: File) = ext(f) in IMAGE
}

/** Ouvre un fichier avec la bonne visionneuse intégrée, ou une autre application en dernier recours. */
object FileOpener {

    fun open(context: Context, app: App, file: File) {
        if (!file.exists()) {
            Toast.makeText(context, "Fichier introuvable (déplacé ou supprimé)", Toast.LENGTH_SHORT).show()
            return
        }
        if (file.isDirectory) {
            app.openFolder.value = file
            return
        }
        val ext = file.extension.lowercase()
        when {
            FileKinds.isMedia(file) -> {
                val video = FileKinds.isVideo(file)
                val siblings = (file.parentFile?.listFiles() ?: emptyArray())
                    .filter { it.isFile && (if (video) FileKinds.isVideo(it) else FileKinds.isAudio(it)) }
                    .sortedBy { it.name.lowercase() }
                    .ifEmpty { listOf(file) }
                app.viewer.value = ViewerRequest.Media(siblings, siblings.indexOf(file).coerceAtLeast(0))
            }

            FileKinds.isImage(file) -> {
                val siblings = (file.parentFile?.listFiles() ?: emptyArray())
                    .filter { it.isFile && FileKinds.isImage(it) }
                    .sortedBy { it.name.lowercase() }
                    .ifEmpty { listOf(file) }
                app.viewer.value = ViewerRequest.Images(siblings, siblings.indexOf(file).coerceAtLeast(0))
            }

            ApkInstaller.canInstall(file) -> app.scope.launch(Dispatchers.Main) {
                try {
                    ApkInstaller.install(context, file)
                } catch (e: Exception) {
                    Toast.makeText(context, "Installation impossible : ${e.message}", Toast.LENGTH_LONG).show()
                }
            }

            ArchiveManager.isArchive(file) -> app.viewer.value = ViewerRequest.Archive(file)
            ext in FileKinds.WEB -> app.viewer.value = ViewerRequest.WebFile(file)
            ext in FileKinds.TEXT -> app.viewer.value = ViewerRequest.TextFile(file)
            else -> openExternal(context, file)
        }
    }

    fun openExternal(context: Context, file: File) {
        try {
            val uri = FileProvider.getUriForFile(context, context.packageName + ".files", file)
            val intent = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, Links.mimeOf(FileKinds.realName(file)))
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(context, "Aucune application pour ouvrir ce fichier", Toast.LENGTH_SHORT).show()
        }
    }

    fun share(context: Context, file: File) {
        try {
            val uri = FileProvider.getUriForFile(context, context.packageName + ".files", file)
            val intent = Intent(Intent.ACTION_SEND)
                .setType(Links.mimeOf(FileKinds.realName(file)))
                .putExtra(Intent.EXTRA_STREAM, uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            context.startActivity(Intent.createChooser(intent, "Partager").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
            Toast.makeText(context, "Partage impossible", Toast.LENGTH_SHORT).show()
        }
    }
}

/** Barre supérieure commune aux visionneuses. */
@Composable
fun ViewerBar(
    title: String,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
    actions: @Composable RowScope.() -> Unit = {},
) {
    Row(
        modifier = modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 4.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = onClose) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
        }
        Text(
            title,
            modifier = Modifier.weight(1f).padding(horizontal = 4.dp),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
        )
        actions()
    }
}

/** Lecture d'un fichier web local : .html, .htm, .mhtml (pages enregistrées), .svg. */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebFileScreen(file: File, onClose: () -> Unit) {
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize()) {
            ViewerBar(file.name, onClose)
            AndroidView(
                modifier = Modifier.fillMaxWidth().weight(1f),
                factory = { ctx ->
                    WebView(ctx).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.allowFileAccess = true
                        settings.allowContentAccess = false
                        settings.allowFileAccessFromFileURLs = false
                        settings.allowUniversalAccessFromFileURLs = false
                        settings.builtInZoomControls = true
                        settings.displayZoomControls = false
                        settings.useWideViewPort = true
                        settings.loadWithOverviewMode = true
                        webViewClient = WebViewClient()
                        loadUrl(Uri.fromFile(file).toString())
                    }
                },
                onRelease = { it.destroy() },
            )
        }
    }
}

/** Lecture d'un fichier texte (jusqu'à 2 Mo). */
@Composable
fun TextFileScreen(file: File, onClose: () -> Unit) {
    var text by remember(file) { mutableStateOf<String?>(null) }
    LaunchedEffect(file) {
        text = withContext(Dispatchers.IO) {
            try {
                val limit = 2 * 1024 * 1024
                val buffer = ByteArray(limit)
                var read = 0
                file.inputStream().use { input ->
                    while (read < limit) {
                        val n = input.read(buffer, read, limit - read)
                        if (n < 0) break
                        read += n
                    }
                }
                String(buffer, 0, read, Charsets.UTF_8) +
                    if (file.length() > read) "\n\n… fichier tronqué (affichage limité à 2 Mo)" else ""
            } catch (e: Exception) {
                "Lecture impossible : ${e.message}"
            }
        }
    }
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize()) {
            ViewerBar(file.name, onClose)
            val content = text
            if (content == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            } else {
                SelectionContainer {
                    Column(
                        Modifier.fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .horizontalScroll(rememberScrollState())
                            .padding(12.dp),
                    ) {
                        Text(content, fontFamily = FontFamily.Monospace, fontSize = 13.sp, softWrap = false)
                    }
                }
            }
        }
    }
}
