package com.dlvibestudio.dlturbo.ui

import android.net.Uri

/**
 * Règles anti-pub reprises de MyDM : régies publicitaires connues, adresses qui trahissent une publicité,
 * et sites de connexion (seul cas où une fenêtre vers un autre site est permise).
 */
object AdRules {
    private val adHosts = listOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
        "google-analytics.com", "taboola.com", "outbrain.com", "adnxs.com", "criteo.com", "criteo.net", "popads.net",
        "propellerads.com", "exoclick.com", "adsterra.com", "mgid.com", "ads.yahoo.com", "scorecardresearch.com", "hotjar.com",
        "popcash.net", "juicyads.com", "trafficjunky.net", "amazon-adsystem.com", "moatads.com", "adform.net", "rubiconproject.com",
        "onclickads.net", "clickadu.com", "hilltopads.net", "adcash.com", "richpush.co", "a-ads.com", "ad-maven.com", "admaven.com",
        "tsyndicate.com", "bidvertiser.com", "revcontent.com", "yllix.com", "usrpubtrk.com", "popunder.net", "adspyglass.com",
        "adskeeper.com", "ero-advertising.com", "trafficstars.com", "realsrv.com", "syndication.exdynsrv.com", "pushwhy.com",
        "notifpush.com", "cloudfront-ads.com", "highperformanceformat.com", "profitablecpmrate.com", "effectivegatecpm.com",
        "pubmatic.com", "openx.net", "casalemedia.com", "smartadserver.com", "adsrvr.org", "3lift.com", "sharethrough.com", "teads.tv",
        "adtelligent.com", "sovrn.com", "quantserve.com", "zedo.com", "serving-sys.com", "bidswitch.net", "inmobi.com", "mopub.com",
        "applovin.com", "adcolony.com", "vungle.com", "chartboost.com", "adsco.re", "onclkds.com", "clickaine.com", "magsrv.com",
        "exosrv.com", "exdynsrv.com", "2mdn.net", "googletagservices.com", "advertising.com", "adition.com",
        "contextweb.com", "lijit.com", "krxd.net", "rlcdn.com", "bluekai.com", "yandexadexchange.net", "an.yandex.ru",
        "adsafeprotected.com", "doubleverify.com", "outbrainimg.com", "taboolasyndication.com", "smartclip.net", "adform.com",
        "tapad.com", "everesttech.net", "demdex.net", "adblade.com", "monetag.com",
        // Régies très présentes sur les sites de streaming / torrent
        "histats.com", "dtscout.com", "dtscdn.com", "clickadilla.com", "galaksion.com", "aclib.net", "acscdn.com",
        "pemsrv.com", "rtmark.net", "adexchangeclear.com", "popmyads.com", "whos.amung.us", "kueezrtb.com",
        "vidazoo.com", "adsterratools.com", "adstera.com", "push-sdk.com", "pushnest.com", "pushprofit.net",
        "lnkvv.com", "clkrev.com", "ptmnts.com", "onclickperformance.com", "onclickalgo.com", "trafficforce.com",
    )

    /** Régies de paris / casino (bannières « 1xBet », « Linebet »…) : bloquées quand on n'est pas sur leur site. */
    private val gambling = Regex(
        """(?i)(1xbet|linebet|melbet|betwinner|mostbet|22bet|paripesa|megapari|premierbet|betpawa|bet365|1win|pin-?up|casino|betandyou|888starz|helabet|dbbet)"""
    )

    fun isGamblingHost(host: String?): Boolean = host != null && gambling.containsMatchIn(host)

    private val authHosts = listOf(
        "accounts.google.com", "accounts.youtube.com", "appleid.apple.com", "login.microsoftonline.com", "login.live.com",
        "github.com", "facebook.com", "paypal.com", "discord.com", "twitter.com", "x.com",
    )

    /** Sous-ressource (script, iframe, image…) dont l'adresse trahit une régie publicitaire, même sur un hôte inconnu. */
    private val adResource = Regex(
        """(?i)(/|[._-])(popunder|pop-under|popads|adsbygoogle|adserver|adserving|ad-?frame|ad_?banner|prebid|vast\.xml|ads?\.js|pagead|show_ads|adsense|sponsored-?ads)([/._?&-]|${'$'})"""
    )

    fun isAdHost(host: String?): Boolean {
        val h = host?.lowercase() ?: return false
        return adHosts.any { h == it || h.endsWith(".$it") }
    }

    fun isAdUrl(url: String): Boolean = isAdHost(runCatching { Uri.parse(url).host }.getOrNull())

    fun looksLikeAdResource(uri: Uri): Boolean =
        adResource.containsMatchIn((uri.path ?: "") + "?" + (uri.query ?: "").take(120))

    /** Connexion « Se connecter avec Google / Apple / Facebook… ». */
    fun isAuthHost(host: String?): Boolean {
        val h = host?.lowercase() ?: return false
        return authHosts.any { h == it || h.endsWith(".$it") }
    }

    private fun base(h: String): String =
        h.lowercase().removePrefix("www.").split('.').let { if (it.size > 2) it.takeLast(2).joinToString(".") else it.joinToString(".") }

    fun sameSite(a: String?, b: String?): Boolean {
        val ha = a?.let { runCatching { Uri.parse(it).host }.getOrNull() } ?: return false
        val hb = b?.let { runCatching { Uri.parse(it).host }.getOrNull() } ?: return false
        return base(ha) == base(hb)
    }
}

object AdGuard {

    /**
     * Script anti-pub de MyDM, injecté dans toutes les pages et leurs iframes au tout début du chargement :
     *  - window.open sans geste réel de l'utilisateur ou vers un autre site : refusé (sauf connexion Google / Apple…) ;
     *  - clic sur un calque transparent plein écran (pub « cliquez n'importe où ») : annulé et calque supprimé ;
     *  - liens target=_blank vers un autre site, posés par un script sans clic : neutralisés ;
     *  - bannières et emplacements publicitaires courants : masqués.
     */
    const val JS = """
(function(){
  if (window.__dltAds) return; window.__dltAds = true;
  var AUTH = /(^|\.)(accounts\.google\.com|appleid\.apple\.com|login\.microsoftonline\.com|login\.live\.com|github\.com|twitter\.com|x\.com|facebook\.com|paypal\.com|discord\.com)${'$'}/i;
  function base(h){ h = (h||'').toLowerCase().replace(/^www\./,'').split('.'); return h.length>2 ? h.slice(-2).join('.') : h.join('.'); }
  function sameSite(u){ try { return base(new URL(u, location.href).hostname) === base(location.hostname); } catch(e){ return false; } }
  function active(){ try { return navigator.userActivation ? navigator.userActivation.isActive : true; } catch(e){ return true; } }
  var realOpen = window.open;
  window.open = function(u){
    try {
      var host = ''; try { host = new URL(u || 'about:blank', location.href).hostname; } catch(e){}
      if (host && AUTH.test(host) && active()) return realOpen.apply(window, arguments);
      if (!active() || (u && !sameSite(u))) return null;
    } catch(e){ return null; }
    return realOpen.apply(window, arguments);
  };
  function isOverlay(el){
    try {
      if (!el || el === document.body || el === document.documentElement) return false;
      if (el.id === '__dlt_media_root' || (el.closest && el.closest('#__dlt_media_root'))) return false;
      if (/^(VIDEO|AUDIO|CANVAS|INPUT|BUTTON|SELECT|TEXTAREA)${'$'}/.test(el.tagName)) return false;
      var cs = getComputedStyle(el);
      if (cs.position !== 'fixed' && cs.position !== 'absolute') return false;
      var r = el.getBoundingClientRect();
      if (r.width < innerWidth * 0.85 || r.height < innerHeight * 0.85) return false;
      var z = parseInt(cs.zIndex, 10) || 0;
      var transparent = parseFloat(cs.opacity) < 0.15 || cs.backgroundColor === 'rgba(0, 0, 0, 0)' || cs.backgroundColor === 'transparent';
      return z >= 100 && transparent && (el.textContent || '').trim().length < 3;
    } catch(e){ return false; }
  }
  document.addEventListener('click', function(e){
    var t = e.target;
    var a = t && t.closest ? t.closest('a[href]') : null;
    if (isOverlay(t) || (a && isOverlay(a))) {
      e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
      try { (a && isOverlay(a) ? a : t).remove(); } catch(x){}
      return;
    }
    if (a && a.target === '_blank' && !sameSite(a.href) && !e.isTrusted) { e.preventDefault(); e.stopPropagation(); }
  }, true);
  var realClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function(){
    try { if (/^https?:/i.test(this.href) && !sameSite(this.href) && (!active() || !this.isConnected)) return; } catch(e){}
    return realClick.apply(this, arguments);
  };
  var css = '.adsbygoogle,ins.adsbygoogle,[id^="google_ads"],[id^="div-gpt-ad"],[id*="ad-container"],[id*="adcontainer"],' +
    '[class*="ad-banner"],[class*="adbanner"],[class*="ad_banner"],[class*="advert"],[class*="popunder"],[class*="pop-under"],' +
    'iframe[src*="doubleclick"],iframe[src*="googlesyndication"],iframe[src*="adsterra"],iframe[src*="exoclick"],iframe[src*="propeller"],' +
    'iframe[id^="google_ads"],a[href*="doubleclick.net"],a[href*="adsterra"],a[href*="exoclick"],a[href*="popads"]{display:none!important;visibility:hidden!important}';
  function addCss(){
    try { var st = document.createElement('style'); st.textContent = css; (document.head || document.documentElement).appendChild(st); } catch(e){}
  }
  if (document.head || document.documentElement) addCss(); else document.addEventListener('DOMContentLoaded', addCss);
})();
"""

    /**
     * YouTube mobile : masque les invites « Ouvrir l'application / Télécharger l'application YouTube »
     * et referme celles qui s'affichent en plein écran.
     */
    const val YOUTUBE_APP_PROMO_SCRIPT = """
(function(){
  if (window.__dltNoApp) return; window.__dltNoApp = true;
  var css = 'ytm-mealbar-promo-renderer,ytm-app-promo-renderer,ytm-open-app-promo-renderer,.mealbar-promo-renderer,' +
    'ytm-statement-banner-renderer,ytm-companion-slot,.open-app-button,.ytm-open-app-button,[class*="open-app"],' +
    '[class*="app-promo"],[class*="AppPromo"],[class*="upsell-dialog"],ytm-upsell-dialog-renderer,' +
    'a[href^="intent://"],a[href^="vnd.youtube"],a[href*="play.google.com/store/apps/details?id=com.google.android.youtube"]' +
    '{display:none!important}';
  function addCss(){
    if (document.getElementById('__dlt_noapp')) return;
    try { var st = document.createElement('style'); st.id = '__dlt_noapp'; st.textContent = css; (document.head || document.documentElement).appendChild(st); } catch(e){}
  }
  var WORDS = /^(non merci|pas maintenant|plus tard|no thanks|not now|continuer sur le navigateur|continuer dans le navigateur|rester sur le web|continue in browser|stay in browser)${'$'}/i;
  var APP = /(application youtube|youtube app|ouvrir l.application|open app|t.l.charger l.application|get the app)/i;
  function dismiss(){
    addCss();
    try {
      var boxes = document.querySelectorAll('ytm-upsell-dialog-renderer, ytm-mealbar-promo-renderer, ytm-bottom-sheet-renderer, [role="dialog"], .dialog-container, ytm-app-promo-renderer');
      for (var i = 0; i < boxes.length; i++) {
        var box = boxes[i];
        if (!APP.test(box.textContent || '')) continue;
        var bs = box.querySelectorAll('button, a, [role="button"]');
        var done = false;
        for (var j = 0; j < bs.length; j++) {
          if (WORDS.test((bs[j].textContent || '').trim())) { bs[j].click(); done = true; break; }
        }
        if (!done) { try { box.style.setProperty('display', 'none', 'important'); } catch(x){} }
      }
      if (document.body && document.body.style.overflow === 'hidden' && !document.querySelector('[role="dialog"]:not([style*="display: none"])')) {
        document.body.style.overflow = '';
      }
    } catch(e){}
  }
  setInterval(dismiss, 800);
  document.addEventListener('DOMContentLoaded', dismiss);
})();
"""
}


/**
 * Sites « difficiles » (streaming, torrent) : fenêtres pop-up et pop-under, redirections au clic,
 * bannières de paris… Un blocage renforcé y est appliqué, ainsi que dans les lecteurs vidéo qu'ils intègrent.
 */
object StrictSites {
    /** Mots repérés dans le nom du site (les adresses changent souvent : papadustreami.skin, .lol…). */
    private val SITES = Regex("""(?i)(torrent9|cinezzz|papadustream)""")

    /** Lecteurs vidéo intégrés par ces sites (iframes) : mêmes règles à l'intérieur. */
    private val PLAYERS = Regex(
        """(?i)(uqload|voe\.|dood|d0000d|ds2play|filemoon|streamtape|vidoza|netu|hqq\.|upstream|vidmoly|mixdrop|streamwish|lulustream|vidguard|luluvdo)"""
    )

    fun isStrict(host: String?): Boolean = host != null && (SITES.containsMatchIn(host) || PLAYERS.containsMatchIn(host))

    fun isStrictUrl(url: String?): Boolean = isStrict(runCatching { Uri.parse(url ?: "").host }.getOrNull())

    /**
     * Injecté dans toutes les pages et iframes ; ne s'active que sur ces sites et leurs lecteurs :
     *  - window.open toujours refusé (pop-under) ;
     *  - clic ou faux clic vers un autre site : annulé (les liens magnet restent permis) ;
     *  - bannières (paris, casino…), iframes publicitaires et calques collés en haut / bas : supprimés.
     */
    val JS: String = """
(function(){
  if (window.__dltStrict) return;
  if (/(^|\.)(challenges\.cloudflare\.com|hcaptcha\.com|recaptcha\.net)$/i.test(location.hostname)) return;
  var RE = /(torrent9|cinezzz|papadustream|uqload|voe\.|dood|d0000d|ds2play|filemoon|streamtape|vidoza|netu|hqq\.|upstream|vidmoly|mixdrop|streamwish|lulustream|vidguard|luluvdo)/i;
  var anc = [];
  try { var ao = location.ancestorOrigins; for (var i = 0; i < ao.length; i++) anc.push(ao[i]); } catch(e){}
  var inFrame = false; try { inFrame = window !== window.top; } catch(e){ inFrame = true; }
  var hosts = [location.hostname].concat(anc);
  if (inFrame) hosts.push(document.referrer || '');
  if (!hosts.some(function(h){ return RE.test(h || ''); })) return;
  window.__dltStrict = true;
  function hostOf(u){ try { return new URL(u, location.href).hostname; } catch(e){ return ''; } }
  function base(h){ h = (h||'').toLowerCase().replace(/^www\./,'').split('.'); return h.length>2 ? h.slice(-2).join('.') : h.join('.'); }
  var topHost = anc.length ? hostOf(anc[anc.length - 1]) : location.hostname;
  var mine = [base(topHost), base(location.hostname)];
  function foreign(u){
    try {
      var x = new URL(u, location.href);
      if (x.protocol !== 'http:' && x.protocol !== 'https:') return false;
      return mine.indexOf(base(x.hostname)) < 0;
    } catch(e){ return false; }
  }
  var BET = /(1xbet|linebet|melbet|betwinner|mostbet|22bet|paripesa|megapari|premierbet|betpawa|bet365|1win|pin-?up|casino|888starz|helabet|bonus|first deposit|promo ?code)/i;
  // 1) Pop-up / pop-under : jamais
  var fake = { closed: true, close: function(){}, focus: function(){}, blur: function(){}, postMessage: function(){},
    location: { href: '', replace: function(){}, assign: function(){} }, document: { write: function(){}, open: function(){}, close: function(){} } };
  try { Object.defineProperty(window, 'open', { value: function(){ return fake; }, writable: false, configurable: false }); }
  catch(e){ try { window.open = function(){ return fake; }; } catch(x){} }
  // 2) Clics vers un autre site (vrais ou simulés)
  function stop(e){
    var t = e.target, a = t && t.closest ? t.closest('a[href]') : null;
    if (a && foreign(a.href)) { e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation(); return; }
    var f = t && t.closest ? t.closest('form') : null;
    if (f && f.target === '_blank' && foreign(f.action)) { e.preventDefault(); e.stopImmediatePropagation(); }
  }
  window.addEventListener('click', stop, true);
  window.addEventListener('auxclick', stop, true);
  var aClick = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function(){ if (foreign(this.href)) return; return aClick.apply(this, arguments); };
  var fSubmit = HTMLFormElement.prototype.submit;
  HTMLFormElement.prototype.submit = function(){ if (foreign(this.action) && this.target) return; return fSubmit.apply(this, arguments); };
  // 3) Nettoyage visuel
  function hide(el){ try { el.style.setProperty('display','none','important'); el.setAttribute('data-dlt-hidden','1'); } catch(e){} }
  function isPlayer(el){ try { return !!(el.querySelector && el.querySelector('video')); } catch(e){ return false; } }
  function clean(){
    try {
      var as = document.querySelectorAll('a[href]:not([data-dlt-hidden])');
      for (var i = 0; i < as.length; i++) {
        var a = as[i];
        if (!foreign(a.href)) continue;
        if (a.querySelector('img,picture,video,iframe,svg,canvas') || BET.test(a.href + ' ' + (a.textContent||''))) hide(a);
      }
      var imgs = document.querySelectorAll('img:not([data-dlt-hidden])');
      for (var j = 0; j < imgs.length; j++) {
        var im = imgs[j];
        if (BET.test((im.src||'') + ' ' + (im.alt||''))) hide(im.closest('a') || im);
      }
      var fs = document.querySelectorAll('iframe:not([data-dlt-hidden])');
      for (var k = 0; k < fs.length; k++) {
        var f = fs[k], r = f.getBoundingClientRect(), src = f.src || '';
        if (/challenges\.cloudflare\.com|turnstile|hcaptcha|recaptcha/i.test(src)) continue;
        if (/ads?[\/._-]|banner|pop|bet|casino|promo/i.test(src) && !RE.test(src)) { hide(f); continue; }
        if (src && foreign(src) && !RE.test(src) && r.height > 0 && r.height <= 130) { hide(f); continue; }
        if ((!src || src === 'about:blank') && r.height > 0 && r.height <= 300) {
          var inner = null; try { inner = f.contentDocument; } catch(e){}
          if (!inner || !inner.querySelector('video')) hide(f);
        }
      }
      var all = document.body ? document.body.querySelectorAll('div,section,aside,ins,span') : [];
      for (var m = 0; m < all.length && m < 2500; m++) {
        var el = all[m];
        if (el.id === '__dlt_media_root' || el.getAttribute('data-dlt-hidden')) continue;
        var cs = getComputedStyle(el);
        if (cs.position !== 'fixed' && cs.position !== 'sticky') continue;
        if (isPlayer(el)) continue;
        var z = parseInt(cs.zIndex, 10) || 0;
        var txt = (el.textContent || '');
        var hasForeign = false, links = el.querySelectorAll('a[href],iframe');
        for (var n = 0; n < links.length; n++) {
          var l = links[n], u = l.href || l.src || '';
          if (!foreign(u) || RE.test(u)) continue;
          if (l.tagName === 'IFRAME' || l.querySelector('img,picture,video,iframe,canvas')) { hasForeign = true; break; }
        }
        var rr = el.getBoundingClientRect();
        var overlay = rr.width >= innerWidth * 0.85 && rr.height >= innerHeight * 0.85 && txt.trim().length < 3 && z >= 100;
        if (hasForeign || BET.test(txt) || overlay) hide(el);
      }
    } catch(e){}
  }
  var pending = false;
  function soon(){ if (pending) return; pending = true; setTimeout(function(){ pending = false; clean(); }, 250); }
  document.addEventListener('DOMContentLoaded', clean);
  try { new MutationObserver(soon).observe(document.documentElement, { childList: true, subtree: true }); } catch(e){}
  setInterval(clean, 2500);
})();
""".trimIndent()
}
