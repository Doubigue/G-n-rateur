package com.dlvibestudio.dlturbo.ui

import android.content.Context

/**
 * Vérification Cloudflare (« Un instant… », case « Je suis humain ») :
 *  - nos scripts (anti-pub, anti-pop-up, bouton de téléchargement) ne s'exécutent jamais sur la page de
 *    vérification ni dans le cadre Turnstile : Cloudflare refuse un navigateur dont les fonctions sont modifiées ;
 *  - un site qui présente une vérification passe en « mode compatible » : identité exacte du moteur du
 *    téléphone (User-Agent d'origine, cohérent avec les en-têtes envoyés) et cookies tiers autorisés.
 *    Le cookie obtenu (cf_clearance) étant lié à cette identité, le navigateur invisible (épisodes,
 *    recherche de flux) l'utilise aussi pour ce site.
 */
class Cloudflare(context: Context) {
    private val prefs = context.getSharedPreferences("dlturbo_cloudflare", Context.MODE_PRIVATE)
    private val sites: MutableSet<String> = prefs.getStringSet("sites", emptySet())!!.toHashSet()

    fun isCompat(site: String) = site in sites

    /** Renvoie true si le site vient d'être ajouté. */
    fun add(site: String): Boolean {
        if (site.isBlank() || !sites.add(site)) return false
        prefs.edit().putStringSet("sites", HashSet(sites)).apply()
        return true
    }

    companion object {
        /** Entoure un script injecté : il ne s'exécute pas sur une page de vérification ni dans un cadre captcha. */
        fun guard(script: String): String = """
(function(){
  try {
    var h = location.hostname;
    if (/(^|\.)(challenges\.cloudflare\.com|hcaptcha\.com|recaptcha\.net)${'$'}/i.test(h)) return;
    if (location.pathname.indexOf('/cdn-cgi/') === 0 || location.search.indexOf('__cf_chl') >= 0) return;
    var n = performance.getEntriesByType && performance.getEntriesByType('navigation')[0];
    if (n && (n.responseStatus === 403 || n.responseStatus === 503 || n.responseStatus === 429)) return;
  } catch(e) {}
""" + script + "\n})();"

        /** Renvoie "1" si la page affichée est une vérification Cloudflare. */
        const val DETECT = """
(function(){
  try {
    var t = (document.title || '').toLowerCase();
    if (/just a moment|un instant|attention required|checking your browser|vérification|verify you are human|un momento/.test(t)) return '1';
    if (window._cf_chl_opt) return '1';
    if (document.querySelector('#challenge-form, #cf-challenge-running, #challenge-stage, [name="cf-turnstile-response"], script[src*="/cdn-cgi/challenge-platform/"]')) return '1';
  } catch(e) {}
  return '0';
})();
"""
    }
}
