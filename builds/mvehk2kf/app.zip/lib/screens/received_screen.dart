import 'dart:io';
import 'package:flutter/material.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path/path.dart' as p;
import '../services/storage_service.dart';
import '../utils/file_utils.dart';
import '../widgets/day_filter_bar.dart';
import 'file_viewer_screen.dart';

/// Contenu du dossier DoubigueShare.
class ReceivedScreen extends StatefulWidget {
  const ReceivedScreen({super.key});
  @override
  State<ReceivedScreen> createState() => _ReceivedScreenState();
}

class _ReceivedScreenState extends State<ReceivedScreen> {
  late Future<(Directory, List<File>)> _future = _load();
  DateTime? _day; // filtre par jour (null = tout)

  Future<(Directory, List<File>)> _load() async {
    final dir = await StorageService.shareDir();
    final files = dir.listSync().whereType<File>().toList()
      ..sort((a, b) => b.statSync().modified.compareTo(a.statSync().modified));
    return (dir, files);
  }

  Future<void> _delete(File f) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Supprimer ce fichier ?'),
        content: Text(p.basename(f.path)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Supprimer')),
        ],
      ),
    );
    if (ok == true) {
      await f.delete();
      setState(() => _future = _load());
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text(StorageService.folderName)),
      body: FutureBuilder<(Directory, List<File>)>(
        future: _future,
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final (dir, all) = snap.data!;
          final files = _day == null
              ? all
              : all.where((f) => sameDay(f.statSync().modified, _day!)).toList();
          return RefreshIndicator(
            onRefresh: () async {
              setState(() => _future = _load());
              await _future;
            },
            child: ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.all(16),
              children: [
                Text(displayPath(dir.path), style: TextStyle(color: cs.outline, fontSize: 12)),
                const SizedBox(height: 4),
                DayFilterBar(value: _day, onChanged: (d) => setState(() => _day = d)),
                const SizedBox(height: 4),
                if (files.isEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 80),
                    child: Column(children: [
                      Icon(Icons.inbox_outlined, size: 72, color: cs.outline),
                      const SizedBox(height: 12),
                      Text(_day == null ? 'Aucun fichier reçu' : 'Aucun fichier à cette date',
                          style: TextStyle(color: cs.outline)),
                    ]),
                  ),
                for (final f in files)
                  Card(
                    elevation: 0,
                    color: cs.surfaceContainerHigh,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundColor: cs.primaryContainer,
                        child: Icon(iconForKind(kindOf(f.path)), color: cs.onPrimaryContainer),
                      ),
                      title: Text(p.basename(f.path), overflow: TextOverflow.ellipsis),
                      subtitle: Text('${formatBytes(f.lengthSync())} · ${formatDate(f.statSync().modified)}'),
                      onTap: () => openInApp(context, f.path),
                      trailing: PopupMenuButton<String>(
                        onSelected: (v) {
                          if (v == 'ext') OpenFilex.open(f.path);
                          if (v == 'del') _delete(f);
                        },
                        itemBuilder: (_) => const [
                          PopupMenuItem(value: 'ext', child: Text('Ouvrir avec…')),
                          PopupMenuItem(value: 'del', child: Text('Supprimer')),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          );
        },
      ),
    );
  }
}
