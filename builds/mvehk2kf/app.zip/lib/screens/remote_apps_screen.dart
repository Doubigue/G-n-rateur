import 'package:flutter/material.dart';
import '../services/remote_fs_service.dart';

/// Écran des applications installées sur l'autre téléphone (comme son tiroir d'applis).
class RemoteAppsScreen extends StatefulWidget {
  const RemoteAppsScreen({super.key, required this.remote, required this.peerName});
  final RemoteFsService remote;
  final String peerName;

  @override
  State<RemoteAppsScreen> createState() => _RemoteAppsScreenState();
}

class _RemoteAppsScreenState extends State<RemoteAppsScreen> {
  RemoteFsService get r => widget.remote;
  final _search = TextEditingController();
  bool _showSystem = false;

  @override
  void initState() {
    super.initState();
    if (r.access == RemoteAccess.granted && r.apps.isEmpty) {
      r.loadApps();
    } else if (r.access != RemoteAccess.granted) {
      r.loadApps(); // demande l'autorisation, puis charge la liste
    }
    _search.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  void _details(RemoteApp a) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => Padding(
        padding: const EdgeInsets.fromLTRB(24, 0, 24, 32),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          _Icon(a, size: 72),
          const SizedBox(height: 12),
          Text(a.name, style: Theme.of(ctx).textTheme.titleLarge, textAlign: TextAlign.center),
          const SizedBox(height: 4),
          SelectableText(a.package, style: TextStyle(color: Theme.of(ctx).colorScheme.outline)),
          const SizedBox(height: 8),
          Text('${a.version.isEmpty ? 'Version inconnue' : 'Version ${a.version}'}'
              '${a.system ? ' · application système' : ''}'),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return ListenableBuilder(
      listenable: r,
      builder: (context, _) {
        final q = _search.text.trim().toLowerCase();
        final list = r.apps
            .where((a) => (_showSystem || !a.system) &&
                (q.isEmpty ||
                    a.name.toLowerCase().contains(q) ||
                    a.package.toLowerCase().contains(q)))
            .toList();

        Widget body;
        if (r.access == RemoteAccess.denied) {
          body = Center(
            child: Padding(
              padding: const EdgeInsets.all(32),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.lock_outline, size: 64, color: cs.outline),
                const SizedBox(height: 12),
                const Text('Accès refusé ou révoqué.', textAlign: TextAlign.center),
                const SizedBox(height: 16),
                FilledButton(onPressed: r.loadApps, child: const Text('Redemander l\u2019accès')),
              ]),
            ),
          );
        } else if (r.access != RemoteAccess.granted) {
          body = Center(
            child: Padding(
              padding: const EdgeInsets.all(32),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                const CircularProgressIndicator(),
                const SizedBox(height: 20),
                Text('En attente de l\u2019autorisation de ${widget.peerName}…',
                    textAlign: TextAlign.center),
              ]),
            ),
          );
        } else if (r.appsError != null) {
          body = Center(child: Text(r.appsError!, style: TextStyle(color: cs.error)));
        } else if (list.isEmpty && !r.appsLoading) {
          body = Center(child: Text('Aucune application', style: TextStyle(color: cs.outline)));
        } else {
          body = GridView.builder(
            padding: const EdgeInsets.fromLTRB(8, 4, 8, 24),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 4,
              childAspectRatio: 0.8,
            ),
            itemCount: list.length,
            itemBuilder: (_, i) {
              final a = list[i];
              return InkWell(
                borderRadius: BorderRadius.circular(12),
                onTap: () => _details(a),
                child: Padding(
                  padding: const EdgeInsets.all(6),
                  child: Column(children: [
                    _Icon(a, size: 52),
                    const SizedBox(height: 6),
                    Text(a.name,
                        maxLines: 2,
                        textAlign: TextAlign.center,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 11)),
                  ]),
                ),
              );
            },
          );
        }

        return Scaffold(
          appBar: AppBar(
            title: Text('Applications de ${widget.peerName}'),
            actions: [
              if (r.access == RemoteAccess.granted)
                IconButton(
                  tooltip: 'Actualiser',
                  icon: const Icon(Icons.refresh),
                  onPressed: r.loadApps,
                ),
            ],
          ),
          body: Column(children: [
            if (r.access == RemoteAccess.granted) ...[
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
                child: TextField(
                  controller: _search,
                  decoration: InputDecoration(
                    hintText: 'Rechercher une application',
                    prefixIcon: const Icon(Icons.search),
                    isDense: true,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(24)),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(children: [
                  Expanded(
                    child: Text('${list.length} application(s)',
                        style: TextStyle(color: cs.outline)),
                  ),
                  const Text('Apps système', style: TextStyle(fontSize: 12)),
                  Switch(
                    value: _showSystem,
                    onChanged: (v) => setState(() => _showSystem = v),
                  ),
                ]),
              ),
              if (r.appsLoading) const LinearProgressIndicator(),
            ],
            Expanded(child: body),
          ]),
        );
      },
    );
  }
}

class _Icon extends StatelessWidget {
  const _Icon(this.app, {required this.size});
  final RemoteApp app;
  final double size;

  @override
  Widget build(BuildContext context) {
    if (app.icon != null) {
      return Image.memory(app.icon!, width: size, height: size, gaplessPlayback: true);
    }
    return Icon(Icons.android, size: size, color: Theme.of(context).colorScheme.primary);
  }
}
