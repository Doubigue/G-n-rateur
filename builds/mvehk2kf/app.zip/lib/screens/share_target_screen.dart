import 'package:flutter/material.dart';
import '../models/peer.dart';
import '../services/file_transfer_service.dart';
import '../services/nearby_service.dart';

/// Ouvert quand on partage des fichiers vers LocalShare depuis une autre appli
/// (appui long → Partager). Cherche les téléphones proches ; en toucher un
/// lance la connexion, et les fichiers partent automatiquement dès l'accord.
class ShareTargetScreen extends StatefulWidget {
  const ShareTargetScreen({super.key, required this.nearby, required this.files});
  final NearbyService nearby;
  final FileTransferService files;

  @override
  State<ShareTargetScreen> createState() => _ShareTargetScreenState();
}

class _ShareTargetScreenState extends State<ShareTargetScreen> {
  NearbyService get n => widget.nearby;

  @override
  void initState() {
    super.initState();
    // Recherche immédiate d'un téléphone à qui envoyer.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!n.isConnected && (!n.isDiscovering || !n.isAdvertising)) n.start();
    });
  }

  void _cancel() {
    widget.files.clearQueue();
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _cancel();
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Envoyer à…'),
          leading: IconButton(icon: const Icon(Icons.close), onPressed: _cancel),
          actions: [
            IconButton(
              tooltip: 'Actualiser',
              icon: const Icon(Icons.refresh),
              onPressed: n.restart,
            ),
          ],
        ),
        body: ListenableBuilder(
          listenable: Listenable.merge([n, widget.files]),
          builder: (context, _) {
            final peers = n.peers.where((p) => p.state != PeerState.connected).toList();
            final q = widget.files.queued;
            return Column(children: [
              Container(
                width: double.infinity,
                margin: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: cs.primaryContainer,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Row(children: [
                  Icon(Icons.upload_file, color: cs.onPrimaryContainer),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      q.isEmpty
                          ? 'Connexion en cours…'
                          : q.length == 1
                              ? (q.first['kind'] == 'text'
                                  ? 'Texte à envoyer'
                                  : (q.first['name'] ?? 'Fichier') as String)
                              : '${q.length} éléments à envoyer',
                      style: TextStyle(color: cs.onPrimaryContainer, fontWeight: FontWeight.w600),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ]),
              ),
              if (n.status != null)
                Container(
                  width: double.infinity,
                  margin: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: cs.errorContainer,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Text(n.status!, style: TextStyle(color: cs.onErrorContainer, fontSize: 13)),
                ),
              if (n.info != null || n.outgoingCode != null)
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                  child: Text(
                    n.outgoingCode != null
                        ? 'En attente de l\u2019accord de l\u2019autre appareil · code ${n.outgoingCode}'
                        : n.info!,
                    textAlign: TextAlign.center,
                    style: TextStyle(color: cs.outline),
                  ),
                ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 20, 16, 8),
                child: Row(children: [
                  if (n.isDiscovering)
                    const SizedBox(
                        width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)),
                  if (n.isDiscovering) const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      peers.isEmpty
                          ? 'Recherche d\u2019un téléphone… Ouvrez LocalShare sur l\u2019autre.'
                          : 'Touchez le téléphone destinataire',
                      style: const TextStyle(fontWeight: FontWeight.w600),
                    ),
                  ),
                ]),
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: peers.length,
                  itemBuilder: (_, i) {
                    final p = peers[i];
                    final busy = p.state == PeerState.connecting;
                    return ListTile(
                      leading: CircleAvatar(
                        backgroundColor: cs.primaryContainer,
                        child: busy
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(strokeWidth: 2))
                            : Icon(Icons.smartphone, color: cs.onPrimaryContainer),
                      ),
                      title: Text(p.name),
                      subtitle: Text(busy ? 'En attente d\u2019acceptation…' : 'Touchez pour envoyer'),
                      onTap: busy ? null : () => n.connectTo(p),
                    );
                  },
                ),
              ),
            ]);
          },
        ),
      ),
    );
  }
}
