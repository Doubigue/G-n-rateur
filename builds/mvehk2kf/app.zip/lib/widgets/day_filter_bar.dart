import 'package:flutter/material.dart';

bool sameDay(DateTime a, DateTime b) =>
    a.year == b.year && a.month == b.month && a.day == b.day;

String dayLabel(DateTime d) =>
    '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';

/// Filtre par jour : Tout · Aujourd'hui · Hier · un jour choisi au calendrier.
class DayFilterBar extends StatelessWidget {
  const DayFilterBar({super.key, required this.value, required this.onChanged});
  final DateTime? value;
  final ValueChanged<DateTime?> onChanged;

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final yesterday = now.subtract(const Duration(days: 1));
    final isToday = value != null && sameDay(value!, now);
    final isYesterday = value != null && sameDay(value!, yesterday);
    final custom = value != null && !isToday && !isYesterday;

    return SizedBox(
      height: 48,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        children: [
          ChoiceChip(
            label: const Text('Tout'),
            selected: value == null,
            onSelected: (_) => onChanged(null),
          ),
          const SizedBox(width: 8),
          ChoiceChip(
            label: const Text('Aujourd\u2019hui'),
            selected: isToday,
            onSelected: (_) => onChanged(DateTime(now.year, now.month, now.day)),
          ),
          const SizedBox(width: 8),
          ChoiceChip(
            label: const Text('Hier'),
            selected: isYesterday,
            onSelected: (_) =>
                onChanged(DateTime(yesterday.year, yesterday.month, yesterday.day)),
          ),
          const SizedBox(width: 8),
          ChoiceChip(
            avatar: const Icon(Icons.calendar_month, size: 18),
            label: Text(custom ? dayLabel(value!) : 'Choisir un jour'),
            selected: custom,
            onSelected: (_) async {
              final d = await showDatePicker(
                context: context,
                initialDate: value ?? now,
                firstDate: DateTime(2000),
                lastDate: now,
                helpText: 'Afficher les fichiers de ce jour',
              );
              if (d != null) onChanged(DateTime(d.year, d.month, d.day));
            },
          ),
        ],
      ),
    );
  }
}
