import 'dart:async';
import 'dart:convert';

import 'package:flutter/services.dart';

/// Aides fournies par APK Studio : partages reçus (menu Android « Partager »).
/// Chaque élément partagé est une Map : {kind: 'file', name, mime, path, size} ou {kind: 'text', text}.
/// (APK Studio réécrit ce fichier à la compilation avec la même interface.)
class BaobabSystem {
  static const _partage = MethodChannel('baobab/share');
  static const _secure = MethodChannel('baobab/secure');
  static final _flux = StreamController<List<Map<String, dynamic>>>.broadcast();

  static List<Map<String, dynamic>> _lire(dynamic s) =>
      s == null ? [] : (jsonDecode(s as String) as List).cast<Map<String, dynamic>>();

  /// Éléments reçus via « Partager » (à appeler au démarrage de l'application).
  static Future<List<Map<String, dynamic>>> partagesRecus() async {
    try {
      return _lire(await _partage.invokeMethod('take'));
    } catch (_) {
      return [];
    }
  }

  /// Nouveaux partages reçus pendant que l'application est ouverte.
  static Stream<List<Map<String, dynamic>>> get partages {
    _partage.setMethodCallHandler((c) async {
      if (c.method == 'shared') _flux.add(_lire(c.arguments));
    });
    return _flux.stream;
  }

  static Future<void> bloquerCaptures(bool on) async {
    try {
      await _secure.invokeMethod(on ? 'on' : 'off');
    } catch (_) {}
  }
}
