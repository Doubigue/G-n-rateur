import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import 'nearby_service.dart';
import 'notification_service.dart';
import 'storage_service.dart';

enum TransferStatus { inProgress, done, failed }

/// Un transfert. Chaque transfert notifie SES propres écouteurs (sa ligne dans
/// la liste), de façon limitée (≈5 fois/s).
class TransferItem extends ChangeNotifier {
  TransferItem({
    required this.payloadId,
    required this.name,
    required this.outgoing,
    this.total = 0,
  }) : uid = _uidCounter++;
  static int _uidCounter = 0;

  /// Identifiant unique (clé d'affichage) ; [payloadId] est celui de l'expéditeur.
  final int uid;
  final int payloadId;
  String name;
  final bool outgoing;
  int total;
  int transferred = 0;
  TransferStatus status = TransferStatus.inProgress;
  String? savedPath; // destination finale dans DoubigueShare (réception)
  final DateTime created = DateTime.now();

  double get speed {
    final ms = DateTime.now().difference(created).inMilliseconds;
    if (ms < 700 || transferred <= 0) return 0;
    return transferred * 1000 / ms;
  }

  Duration? get eta {
    final s = speed;
    if (s <= 0 || total <= transferred) return null;
    return Duration(seconds: ((total - transferred) / s).ceil());
  }

  int _lastNotify = 0;

  double get progress => total == 0 ? 0 : (transferred / total).clamp(0.0, 1.0);

  void setProgress(int done, int tot, {bool force = false}) {
    if (tot > 0) total = tot;
    transferred = done;
    final now = DateTime.now().millisecondsSinceEpoch;
    if (force || now - _lastNotify >= 200) {
      _lastNotify = now;
      notifyListeners();
    }
  }

  void touch() => notifyListeners();
}

class TextItem {
  TextItem(this.text, {required this.outgoing});
  final String text;
  final bool outgoing;
  final DateTime created = DateTime.now();
}

class _Rx {
  _Rx(this.item);
  final TransferItem item;
  String tmp = '';
  String dest = '';
  RandomAccessFile? raf;
  Future<void> chain = Future.value();
  int received = 0;
  bool failed = false;
}

/// Envoi / réception de fichiers sur le lien Wi-Fi Direct.
/// Les fichiers reçus sont écrits directement dans <stockage>/DoubigueShare
/// (aucune copie finale : plus de gel sur les gros fichiers).
class FileTransferService extends ChangeNotifier {
  FileTransferService(this._nearby) {
    _subs.add(_nearby.onMessage.listen(_onMessage));
    _subs.add(_nearby.onChunk.listen((e) => _onChunk(e.$1, e.$2)));
    _subs.add(_nearby.onFileEnd.listen(_onEnd));
    _subs.add(_nearby.onFileCancel.listen(_onCancelFrame));
    _nearby.addListener(_onNearby);
  }

  final NearbyService _nearby;
  final List<StreamSubscription> _subs = [];
  final List<TransferItem> _all = [];
  final Map<int, TransferItem> _out = {};
  final Map<int, _Rx> _in = {};
  final Set<int> _cancelled = {};
  final Set<String> _temps = {};
  final List<TextItem> _texts = [];
  final List<Map<String, dynamic>> _queued = [];
  bool _flushing = false;
  int _nextId = 1;

  final Map<bool, List<TransferItem>> _batch = {true: [], false: []};
  Timer? _notifTimer;

  List<TransferItem> get items => _all.reversed.toList();

  List<Object> get feed {
    final all = <Object>[..._all, ..._texts];
    DateTime t(Object o) => o is TransferItem ? o.created : (o as TextItem).created;
    all.sort((a, b) => t(b).compareTo(t(a)));
    return all;
  }

  // ------------------------------------------------ partages (menu « Partager »)
  int get queuedCount => _queued.length;
  List<Map<String, dynamic>> get queued => List.unmodifiable(_queued);

  /// Éléments reçus du menu Android « Partager » : envoyés dès qu'un appareil est connecté.
  void queueShared(List<Map<String, dynamic>> items) {
    for (final it in items) {
      if (it['kind'] == 'file' && it['path'] is String) {
        _temps.add(it['path'] as String);
        _queued.add(it);
      } else if (it['kind'] == 'text' && it['text'] is String) {
        _queued.add(it);
      }
    }
    notifyListeners();
  }

  void clearQueue() {
    for (final q in _queued) {
      if (q['kind'] == 'file') _deleteQuiet(q['path'] as String);
    }
    _queued.clear();
    notifyListeners();
  }

  Future<void> flushQueue() async {
    if (_flushing || !_nearby.isConnected || _queued.isEmpty) return;
    _flushing = true;
    try {
      final q = List<Map<String, dynamic>>.of(_queued);
      _queued.clear();
      notifyListeners();
      for (final it in q) {
        if (it['kind'] == 'text') {
          await sendText(it['text'] as String);
        } else {
          await sendPath(it['path'] as String, displayName: it['name'] as String?);
        }
      }
    } finally {
      _flushing = false;
    }
  }

  void _onNearby() {
    if (!_nearby.isConnected) {
      if (_in.isNotEmpty || _out.isNotEmpty) _failAll();
      return;
    }
    if (_queued.isNotEmpty) flushQueue();
  }

  void _failAll() {
    for (final rx in _in.values.toList()) {
      _abortRx(rx);
    }
    for (final it in _out.values) {
      if (it.status == TransferStatus.inProgress) it.status = TransferStatus.failed;
      it.touch();
    }
    notifyListeners();
    _pushNotifications();
  }

  // ------------------------------------------------------------------ texte
  Future<void> sendText(String raw) async {
    var text = raw.trim();
    if (text.isEmpty) return;
    if (text.length > 6000) text = text.substring(0, 6000);
    await _nearby.send({'t': 'text', 'm': text});
    _texts.add(TextItem(text, outgoing: true));
    notifyListeners();
  }

  Future<void> cancel(TransferItem item) async {
    if (item.status != TransferStatus.inProgress) return;
    if (item.outgoing) {
      _cancelled.add(item.payloadId);
    } else {
      final rx = _in[item.payloadId];
      await _nearby.sendCancel(item.payloadId);
      if (rx != null) _abortRx(rx);
    }
    item.status = TransferStatus.failed;
    item.touch();
    notifyListeners();
    _pushNotifications();
  }

  // ------------------------------------------------------------------ envoi
  Future<void> pickAndSend() async {
    final res = await FilePicker.platform.pickFiles(allowMultiple: true);
    if (res == null) return;
    for (final f in res.files) {
      final path = f.path;
      if (path != null) await sendPath(path);
    }
  }

  /// Envoie un fichier local (utilisé aussi quand l'autre appareil en télécharge un).
  Future<void> sendPath(String path, {String? displayName}) async {
    final file = File(path);
    if (!await file.exists() || !_nearby.isConnected) return;
    final size = await file.length();
    final name = (displayName != null && displayName.trim().isNotEmpty)
        ? displayName
        : p.basename(path);
    final id = _nextId++;

    final item = TransferItem(payloadId: id, name: name, outgoing: true, total: size);
    _all.add(item);
    _out[id] = item;
    _batch[true]!.add(item);
    notifyListeners();
    _pushNotifications();

    await _nearby.send({'t': 'file', 'id': id, 'name': name, 'size': size});
    unawaited(_pump(item, file, path));
  }

  Future<void> _pump(TransferItem item, File file, String path) async {
    final id = item.payloadId;
    RandomAccessFile? raf;
    var sent = 0;
    try {
      raf = await file.open();
      while (true) {
        if (_cancelled.contains(id) || !_nearby.isConnected) throw 'annulé';
        final data = await raf.read(64 * 1024);
        if (data.isEmpty) break;
        await _nearby.sendChunk(id, data);
        sent += data.length;
        item.setProgress(sent, item.total);
        _scheduleNotifications();
      }
      await _nearby.sendEnd(id);
      item.setProgress(item.total, item.total, force: true);
      if (item.status == TransferStatus.inProgress) item.status = TransferStatus.done;
    } catch (e) {
      if (item.status == TransferStatus.inProgress) item.status = TransferStatus.failed;
      if (_nearby.isConnected) unawaited(_nearby.sendCancel(id));
    } finally {
      try {
        await raf?.close();
      } catch (_) {}
      _cancelled.remove(id);
      _out.remove(id);
      if (_temps.remove(path)) _deleteQuiet(path);
      item.touch();
      notifyListeners();
      _pushNotifications();
    }
  }

  // -------------------------------------------------------------- réception
  void _onMessage(Map<String, dynamic> msg) {
    try {
      switch (msg['t']) {
        case 'text':
          final m = msg['m'];
          if (m is String && m.trim().isNotEmpty) {
            _texts.add(TextItem(m, outgoing: false));
            HapticFeedback.mediumImpact();
            NotificationService.showDone(
              outgoing: false,
              title: 'Message reçu',
              body: m.length > 120 ? '${m.substring(0, 120)}…' : m,
              payload: 'transfer',
            );
            notifyListeners();
          }
        case 'file':
          _startRx(msg);
      }
    } catch (e, st) {
      debugPrint('onMessage error: $e\n$st');
    }
  }

  void _startRx(Map<String, dynamic> m) {
    final idRaw = m['id'];
    final nameRaw = m['name'];
    if (idRaw is! num || nameRaw is! String) return;
    final id = idRaw.toInt();
    final sz = m['size'];
    final name = _safeName(nameRaw);
    final item = TransferItem(
      payloadId: id,
      name: name,
      outgoing: false,
      total: sz is num ? sz.toInt() : 0,
    );
    final rx = _Rx(item);
    _in[id] = rx; // enregistré AVANT toute attente : les morceaux arrivent aussitôt
    _all.add(item);
    _batch[false]!.add(item);
    notifyListeners();
    _pushNotifications();

    rx.chain = () async {
      try {
        final dir = await StorageService.shareDir();
        rx.dest = _uniquePath(dir.path, name);
        rx.tmp = '${rx.dest}.part';
        rx.raf = await File(rx.tmp).open(mode: FileMode.write);
      } catch (e) {
        debugPrint('open rx error: $e');
        rx.failed = true;
      }
    }();
  }

  void _onChunk(int id, Uint8List data) {
    final rx = _in[id];
    if (rx == null || rx.failed) return;
    rx.chain = rx.chain.then((_) async {
      if (rx.failed || rx.raf == null) return;
      await rx.raf!.writeFrom(data);
      rx.received += data.length;
      rx.item.setProgress(rx.received, rx.item.total);
      _scheduleNotifications();
    }).catchError((Object e) {
      debugPrint('write rx error: $e');
      rx.failed = true;
    });
  }

  void _onEnd(int id) {
    final rx = _in[id];
    if (rx == null) return;
    rx.chain = rx.chain.then((_) async {
      final item = rx.item;
      try {
        await rx.raf?.close();
      } catch (_) {}
      final hadFile = rx.raf != null;
      rx.raf = null;
      final complete = item.total == 0 || rx.received == item.total;
      if (rx.failed || !hadFile || !complete) {
        await _deleteQuiet(rx.tmp);
        item.status = TransferStatus.failed;
      } else {
        try {
          await File(rx.tmp).rename(rx.dest);
          item.savedPath = rx.dest;
          item.setProgress(rx.received, rx.received, force: true);
          item.status = TransferStatus.done;
          HapticFeedback.mediumImpact();
        } catch (e) {
          debugPrint('rename error: $e');
          await _deleteQuiet(rx.tmp);
          item.status = TransferStatus.failed;
        }
      }
    }).whenComplete(() {
      _in.remove(id);
      rx.item.touch();
      notifyListeners();
      _pushNotifications();
    });
  }

  void _onCancelFrame(int id) {
    final rx = _in[id];
    if (rx != null) {
      _abortRx(rx);
      notifyListeners();
      _pushNotifications();
    }
    final out = _out[id];
    if (out != null) {
      _cancelled.add(id);
      out.status = TransferStatus.failed;
      out.touch();
    }
  }

  void _abortRx(_Rx rx) {
    rx.failed = true;
    rx.item.status = TransferStatus.failed;
    rx.item.touch();
    final id = rx.item.payloadId;
    rx.chain = rx.chain.then((_) async {
      try {
        await rx.raf?.close();
      } catch (_) {}
      rx.raf = null;
      await _deleteQuiet(rx.tmp);
    }).whenComplete(() => _in.remove(id));
  }

  Future<void> _deleteQuiet(String path) async {
    if (path.isEmpty) return;
    try {
      final f = File(path);
      if (await f.exists()) await f.delete();
    } catch (_) {}
  }

  // ---------------------------------------------------------- notifications
  void _scheduleNotifications() {
    if (_notifTimer != null) return;
    _notifTimer = Timer(const Duration(milliseconds: 700), () {
      _notifTimer = null;
      _pushNotifications();
    });
  }

  void _pushNotifications() {
    for (final outgoing in const [true, false]) {
      final batch = _batch[outgoing]!;
      if (batch.isEmpty) continue;
      final progressId =
          outgoing ? NotificationService.idSendProgress : NotificationService.idReceiveProgress;
      final active = batch.where((i) => i.status == TransferStatus.inProgress).toList();

      if (active.isNotEmpty) {
        final total = batch.fold<int>(0, (a, i) => a + i.total);
        final done = batch.fold<int>(0, (a, i) => a + i.transferred);
        final pct = total > 0 ? (done * 100 ~/ total) : 0;
        final title = outgoing ? 'Envoi en cours' : 'Réception en cours';
        final what = batch.length == 1 ? batch.first.name : '${batch.length} fichiers';
        NotificationService.showProgress(
          outgoing: outgoing,
          title: title,
          body: total > 0 ? '$what · $pct %' : what,
          percent: pct,
          indeterminate: total == 0,
        );
        continue;
      }

      NotificationService.cancel(progressId);
      final ok = batch.where((i) => i.status == TransferStatus.done).toList();
      final failed = batch.length - ok.length;
      final single = batch.length == 1;
      final title = failed == batch.length
          ? (outgoing ? 'Échec de l\u2019envoi' : 'Échec de la réception')
          : (outgoing ? 'Envoi terminé' : 'Réception terminée');
      final body = single
          ? batch.first.name
          : '${ok.length} fichier(s)${failed > 0 ? ' · $failed en échec' : ''}';
      final path = (!outgoing && single) ? batch.first.savedPath : null;
      NotificationService.showDone(
        outgoing: outgoing,
        title: title,
        body: body,
        payload: path != null ? 'open:$path' : 'transfer',
      );
      batch.clear();
      if (outgoing) {
        FilePicker.platform.clearTemporaryFiles().catchError((_) => null);
      }
    }
  }

  // ------------------------------------------------------------------ fichiers
  String _safeName(String raw) {
    var n = p
        .basename(raw.replaceAll('\\', '/'))
        .replaceAll(RegExp(r'[<>:"|?*\x00-\x1F]'), '_')
        .trim();
    if (n.isEmpty || n == '.' || n == '..') n = 'fichier';
    return n;
  }

  String _uniquePath(String dir, String name) {
    var path = '$dir/$name';
    var i = 1;
    final dot = name.lastIndexOf('.');
    final stem = dot > 0 ? name.substring(0, dot) : name;
    final ext = dot > 0 ? name.substring(dot) : '';
    while (File(path).existsSync() || File('$path.part').existsSync()) {
      path = '$dir/$stem ($i)$ext';
      i++;
    }
    return path;
  }

  @override
  void dispose() {
    _notifTimer?.cancel();
    _nearby.removeListener(_onNearby);
    for (final s in _subs) {
      s.cancel();
    }
    super.dispose();
  }
}
