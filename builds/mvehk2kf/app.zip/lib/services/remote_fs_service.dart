import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:wifi_direct/wifi_direct.dart';
import 'file_transfer_service.dart';
import 'nearby_service.dart';
import 'notification_service.dart';
import 'storage_service.dart';

enum RemoteAccess { none, requesting, granted, denied }

class RemoteEntry {
  RemoteEntry(this.name, this.isDir, this.size, this.modified);
  final String name;
  final bool isDir;
  final int size;
  final DateTime modified;

  factory RemoteEntry.fromJson(Map<String, dynamic> j) => RemoteEntry(
        j['n'] as String,
        (j['d'] as int) == 1,
        (j['s'] as num).toInt(),
        DateTime.fromMillisecondsSinceEpoch((j['m'] as num).toInt()),
      );
}

/// Une application installée sur l'autre téléphone.
class RemoteApp {
  RemoteApp(this.name, this.package, this.version, this.system, this.icon);
  final String name;
  final String package;
  final String version;
  final bool system;
  final Uint8List? icon;

  factory RemoteApp.fromJson(Map<String, dynamic> j) {
    Uint8List? icon;
    final i = j['i'];
    if (i is String && i.isNotEmpty) {
      try {
        icon = base64Decode(i);
      } catch (_) {}
    }
    return RemoteApp(
      (j['n'] ?? '') as String,
      (j['p'] ?? '') as String,
      (j['v'] ?? '') as String,
      j['s'] == true,
      icon,
    );
  }
}

/// Accès aux fichiers et applications de l'autre téléphone, comme un téléphone branché à un PC.
///
/// - Côté « serveur » (mon téléphone exposé) : l'accès doit être AUTORISÉ
///   explicitement, il est limité au stockage interne, par session, et révocable.
/// - Côté « client » : navigation dossier par dossier + téléchargement dans
///   DoubigueShare (via le même canal que l'envoi de fichiers).
class RemoteFsService extends ChangeNotifier {
  RemoteFsService(this._nearby, this._files) {
    _sub = _nearby.onMessage.listen(_onMessage);
    _nearby.addListener(_onNearby);
  }

  final NearbyService _nearby;
  final FileTransferService _files;
  late final StreamSubscription _sub;

  static const root = StorageService.rootPath;

  // ----------------------------------------------------- état « serveur »
  bool accessGranted = false; // l'autre peut parcourir MES fichiers
  bool pendingRequest = false; // il demande l'autorisation

  // ------------------------------------------------------ état « client »
  RemoteAccess access = RemoteAccess.none;
  String currentPath = root;
  List<RemoteEntry> entries = [];
  bool loading = false;
  String? error;
  int _req = 0;

  bool get atRoot => currentPath == root;

  // ------------------------------------------------- applications de l'autre
  List<RemoteApp> apps = [];
  bool appsLoading = false;
  String? appsError;
  bool _appsWanted = false;

  void _onNearby() {
    if (!_nearby.isConnected && (access != RemoteAccess.none || accessGranted || pendingRequest)) {
      _reset();
    }
  }

  void _reset() {
    NotificationService.cancel(NotificationService.idFsRequest);
    accessGranted = false;
    pendingRequest = false;
    access = RemoteAccess.none;
    currentPath = root;
    entries = [];
    loading = false;
    error = null;
    apps = [];
    appsLoading = false;
    appsError = null;
    _appsWanted = false;
    notifyListeners();
  }

  // ------------------------------------------------------------- client
  Future<void> requestAccess() async {
    access = RemoteAccess.requesting;
    error = null;
    notifyListeners();
    await _nearby.send({'t': 'fs_req'});
  }

  /// Affiche les applications installées de l'autre téléphone (même autorisation que les fichiers).
  Future<void> loadApps() async {
    if (access != RemoteAccess.granted) {
      _appsWanted = true;
      if (access != RemoteAccess.requesting) await requestAccess();
      return;
    }
    apps = [];
    appsLoading = true;
    appsError = null;
    notifyListeners();
    await _nearby.send({'t': 'apps'});
  }

  Future<void> list(String path) async {
    _req++;
    loading = true;
    error = null;
    entries = [];
    currentPath = path;
    notifyListeners();
    await _nearby.send({'t': 'ls', 'r': _req, 'p': path});
  }

  Future<void> up() async {
    if (atRoot) return;
    await list(p.dirname(currentPath));
  }

  Future<void> refresh() => list(currentPath);

  Future<void> download(Iterable<String> remotePaths) async {
    for (final path in remotePaths) {
      await _nearby.send({'t': 'get', 'p': path});
    }
  }

  // ------------------------------------------------------------ serveur
  /// Autoriser : demande d'abord « Accès à tous les fichiers » si nécessaire.
  Future<void> allow() async {
    await StorageService.ensureAccess();
    await respond(await StorageService.hasAccess());
  }

  Future<void> respond(bool ok) async {
    NotificationService.cancel(NotificationService.idFsRequest);
    pendingRequest = false;
    accessGranted = ok;
    notifyListeners();
    await _nearby.send({'t': 'fs_grant', 'ok': ok});
  }

  Future<void> revoke() async {
    accessGranted = false;
    notifyListeners();
    await _nearby.send({'t': 'fs_revoke'});
  }

  /// Refuse tout chemin hors du stockage interne (« .. », autre racine…).
  String? _safe(String path) {
    final norm = p.normalize(path);
    if (norm == root || p.isWithin(root, norm)) return norm;
    return null;
  }

  Future<void> _serveList(int r, String path) async {
    Future<void> reply(Map<String, dynamic> extra) => _nearby.send({
          't': 'ls_r',
          'r': r,
          'p': path,
          'pg': 0,
          'more': false,
          'e': <Map<String, dynamic>>[],
          ...extra,
        });

    final safe = _safe(path);
    if (!accessGranted || safe == null) {
      await reply({'err': 'Accès refusé'});
      return;
    }
    try {
      final list = <Map<String, dynamic>>[];
      await for (final ent in Directory(safe).list(followLinks: false)) {
        final name = p.basename(ent.path);
        if (name.startsWith('.')) continue; // fichiers cachés masqués
        try {
          final st = await ent.stat();
          list.add({
            'n': name,
            'd': ent is Directory ? 1 : 0,
            's': st.size,
            'm': st.modified.millisecondsSinceEpoch,
          });
        } catch (_) {}
      }
      list.sort((a, b) {
        if (a['d'] != b['d']) return (b['d'] as int).compareTo(a['d'] as int);
        return (a['n'] as String).toLowerCase().compareTo((b['n'] as String).toLowerCase());
      });

      // Pagination : messages de taille raisonnable.
      var page = <Map<String, dynamic>>[];
      var size = 0;
      var pg = 0;
      Future<void> flush(bool more) async {
        await reply({'p': safe, 'pg': pg++, 'more': more, 'e': page});
        page = [];
        size = 0;
      }

      for (final e in list) {
        final approx = utf8.encode(e['n'] as String).length + 60;
        if (size + approx > 20000) await flush(true);
        page.add(e);
        size += approx;
      }
      await flush(false);
    } catch (e) {
      await reply({'err': 'Dossier illisible'});
    }
  }

  Future<void> _serveApps() async {
    Future<void> reply(Map<String, dynamic> extra) => _nearby.send({
          't': 'apps_r',
          'pg': 0,
          'more': false,
          'e': <Map<String, dynamic>>[],
          ...extra,
        });
    if (!accessGranted) {
      await reply({'err': 'Accès refusé'});
      return;
    }
    try {
      final list = await WifiDirect.listApps();
      const page = 25;
      var pg = 0;
      for (var i = 0; i < list.length; i += page) {
        final chunk = list.sublist(i, i + page > list.length ? list.length : i + page);
        await reply({
          'pg': pg++,
          'more': i + page < list.length,
          'e': [
            for (final a in chunk)
              {
                'n': a['n'],
                'p': a['p'],
                'v': a['v'],
                's': a['s'] == true ? 1 : 0,
                'i': a['i'] is Uint8List ? base64Encode(a['i'] as Uint8List) : '',
              }
          ],
        });
      }
      if (list.isEmpty) await reply({});
    } catch (e) {
      await reply({'err': 'Liste des applications indisponible'});
    }
  }

  Future<void> _serveGet(String path) async {
    final safe = _safe(path);
    if (!accessGranted || safe == null) return;
    if (await File(safe).exists()) await _files.sendPath(safe);
  }

  // ------------------------------------------------------------ réception
  void _onMessage(Map<String, dynamic> m) {
    try {
    switch (m['t']) {
      // ----- côté serveur
      case 'fs_req':
        if (accessGranted) {
          respond(true);
        } else {
          pendingRequest = true;
          NotificationService.showFsRequest(_nearby.connectedName);
          notifyListeners();
        }
        break;
      case 'ls':
        _serveList(m['r'] as int, m['p'] as String);
        break;
      case 'get':
        _serveGet(m['p'] as String);
        break;
      case 'apps':
        _serveApps();
        break;

      // ----- côté client
      case 'fs_grant':
        if (m['ok'] == true) {
          access = RemoteAccess.granted;
          notifyListeners();
          if (_appsWanted) {
            _appsWanted = false;
            loadApps();
          } else {
            list(root);
          }
        } else {
          _appsWanted = false;
          appsLoading = false;
          access = RemoteAccess.denied;
          notifyListeners();
        }
        break;
      case 'fs_revoke':
        access = RemoteAccess.denied;
        entries = [];
        apps = [];
        appsLoading = false;
        currentPath = root;
        loading = false;
        notifyListeners();
        break;
      case 'apps_r':
        if (m['err'] != null) {
          appsError = m['err'] as String;
          appsLoading = false;
        } else {
          apps = [
            ...apps,
            ...(m['e'] as List).map((x) => RemoteApp.fromJson(x as Map<String, dynamic>)),
          ];
          appsLoading = m['more'] == true;
        }
        notifyListeners();
        break;
      case 'ls_r':
        if (m['r'] != _req) return; // réponse périmée
        if (m['err'] != null) {
          error = m['err'] as String;
          loading = false;
        } else {
          if (m['pg'] == 0) currentPath = m['p'] as String;
          entries = [
            ...entries,
            ...(m['e'] as List).map((x) => RemoteEntry.fromJson(x as Map<String, dynamic>)),
          ];
          loading = m['more'] == true;
        }
        notifyListeners();
        break;
    }
    } catch (e) {
      // Message mal formé venant de l'autre appareil : on l'ignore.
    }
  }

  @override
  void dispose() {
    _nearby.removeListener(_onNearby);
    _sub.cancel();
    super.dispose();
  }
}
