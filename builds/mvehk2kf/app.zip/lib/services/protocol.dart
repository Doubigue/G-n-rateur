/// Protocole LocalShare sur le lien TCP Wi-Fi Direct (voir direct_link.dart).
///
/// Chaque message JSON ({"t": ...}) :
///   hello     {"t":"hello","name","nonce","v":1}   présentation (les deux sens)
///   accept    {"t":"accept"} / reject {"t":"reject"}   réponse à la demande de connexion
///   text      {"t":"text","m":"…"}
///   file      {"t":"file","id":n,"name":"x.mp4","size":123}   suivi de trames « chunk »/« end »
///   fs_req    demande d'accès aux fichiers et applications
///   fs_grant  {"t":"fs_grant","ok":true|false}
///   fs_revoke accès révoqué par le propriétaire
///   ls / ls_r lister un dossier (pagination)
///   get       télécharger un fichier
///   apps      demander la liste des applications installées
///   apps_r    {"t":"apps_r","pg":0,"more":true,"e":[{n,p,v,s,i(base64)}],"err":"…"}
class Protocol {
  static const int port = 8988;
}
