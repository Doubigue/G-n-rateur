/// Ancienne « protection anti-plantage » : supprimée (plus d'alerte ni de
/// désactivation automatique). Conservée comme simple passe-plat pour que le
/// reste du code n'ait pas à changer.
class CrashGuard {
  CrashGuard._();
  static String? notice;
  static String? report;

  static Future<void> init() async {}

  static Future<T?> run<T>(String step, Future<T> Function() fn) => fn();
}
