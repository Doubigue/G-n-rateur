import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

typedef NotifActionHandler = void Function(String? actionId, String? payload);

/// Toutes les notifications de l'appli :
///  - demande de connexion (boutons Accepter / Refuser)
///  - demande d'accès aux fichiers (boutons Autoriser / Refuser)
///  - progression d'envoi / de réception (barre de progression dans la barre d'état)
///  - fin de transfert
class NotificationService {
  NotificationService._();

  static final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  static NotifActionHandler? onAction;
  static bool _ready = false;

  static const idRequest = 2001;
  static const idFsRequest = 2002;
  static const idSendProgress = 3001;
  static const idReceiveProgress = 3002;
  static const idSendDone = 3011;
  static const idReceiveDone = 3012;

  static const _chRequests = 'ls_requests';
  static const _chProgress = 'ls_progress';
  static const _chDone = 'ls_done';

  static Future<void> init() async {
    if (!Platform.isAndroid || _ready) return;
    await _plugin.initialize(
      const InitializationSettings(
        android: AndroidInitializationSettings('@mipmap/ic_launcher'),
      ),
      onDidReceiveNotificationResponse: (r) => onAction?.call(r.actionId, r.payload),
    );
    _ready = true;
  }

  /// Android 13+ : autorisation d'afficher les notifications.
  static Future<void> requestPermission() async {
    if (!Platform.isAndroid) return;
    await _plugin
        .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.requestNotificationsPermission();
  }

  static Future<void> _show(
    int id,
    String title,
    String body,
    AndroidNotificationDetails details, {
    String? payload,
  }) async {
    if (!_ready) return;
    try {
      await _plugin.show(id, title, body, NotificationDetails(android: details), payload: payload);
    } catch (e) {
      debugPrint('notification error: $e');
    }
  }

  static Future<void> cancel(int id) async {
    if (!_ready) return;
    try {
      await _plugin.cancel(id);
    } catch (_) {}
  }

  static Future<void> cancelAll() async {
    if (!_ready) return;
    try {
      await _plugin.cancelAll();
    } catch (_) {}
  }

  // ------------------------------------------------------------ demandes
  static Future<void> showConnectionRequest(String name, String code) => _show(
        idRequest,
        'Demande de connexion',
        '« $name » veut se connecter · code $code',
        AndroidNotificationDetails(
          _chRequests,
          'Demandes de connexion',
          channelDescription: 'Un appareil proche veut se connecter à vous',
          importance: Importance.max,
          priority: Priority.high,
          autoCancel: true,
          timeoutAfter: 60000,
          styleInformation: BigTextStyleInformation(
            '« $name » veut se connecter à votre appareil.\n'
            'Vérifiez que le code $code est identique sur son écran.',
          ),
          actions: const [
            AndroidNotificationAction('conn_accept', 'Accepter',
                showsUserInterface: true, cancelNotification: true),
            AndroidNotificationAction('conn_reject', 'Refuser',
                showsUserInterface: true, cancelNotification: true),
          ],
        ),
        payload: 'conn',
      );

  static Future<void> showFsRequest(String name) => _show(
        idFsRequest,
        'Accès à vos fichiers et applications',
        '« $name » demande à parcourir vos fichiers et applications',
        AndroidNotificationDetails(
          _chRequests,
          'Demandes de connexion',
          channelDescription: 'Un appareil proche veut se connecter à vous',
          importance: Importance.max,
          priority: Priority.high,
          autoCancel: true,
          timeoutAfter: 60000,
          actions: const [
            AndroidNotificationAction('fs_allow', 'Autoriser',
                showsUserInterface: true, cancelNotification: true),
            AndroidNotificationAction('fs_deny', 'Refuser',
                showsUserInterface: true, cancelNotification: true),
          ],
        ),
        payload: 'fs',
      );

  // ----------------------------------------------------------- progression
  /// [percent] 0..100. [indeterminate] si la taille totale n'est pas encore connue.
  static Future<void> showProgress({
    required bool outgoing,
    required String title,
    required String body,
    required int percent,
    bool indeterminate = false,
  }) =>
      _show(
        outgoing ? idSendProgress : idReceiveProgress,
        title,
        body,
        AndroidNotificationDetails(
          _chProgress,
          'Transferts en cours',
          channelDescription: 'Progression des envois et réceptions',
          importance: Importance.low,
          priority: Priority.low,
          onlyAlertOnce: true,
          showProgress: true,
          maxProgress: 100,
          progress: percent.clamp(0, 100),
          indeterminate: indeterminate,
          ongoing: true,
          autoCancel: false,
          playSound: false,
          enableVibration: false,
        ),
        payload: 'transfer',
      );

  static Future<void> showDone({
    required bool outgoing,
    required String title,
    required String body,
    String? payload,
  }) =>
      _show(
        outgoing ? idSendDone : idReceiveDone,
        title,
        body,
        AndroidNotificationDetails(
          _chDone,
          'Transferts terminés',
          channelDescription: 'Fin des envois et réceptions',
          importance: Importance.defaultImportance,
          priority: Priority.defaultPriority,
          autoCancel: true,
        ),
        payload: payload ?? 'transfer',
      );
}
