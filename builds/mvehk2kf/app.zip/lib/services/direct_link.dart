import 'dart:async';
import 'dart:collection';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';

/// File d'octets pour reconstituer les trames reçues par morceaux.
class _ByteQueue {
  final Queue<Uint8List> _q = Queue();
  int _off = 0;
  int length = 0;

  void add(Uint8List d) {
    if (d.isEmpty) return;
    _q.add(d);
    length += d.length;
  }

  Uint8List read(int n) {
    final out = Uint8List(n);
    var w = 0;
    while (w < n) {
      final f = _q.first;
      final take = min(f.length - _off, n - w);
      out.setRange(w, w + take, f, _off);
      w += take;
      _off += take;
      if (_off == f.length) {
        _q.removeFirst();
        _off = 0;
      }
    }
    length -= n;
    return out;
  }
}

/// Lien TCP bidirectionnel sur le réseau Wi-Fi Direct.
/// Trame : [type:1][id:4][longueur:4][données]
///   1 = message JSON, 2 = morceau de fichier (id), 3 = fin de fichier,
///   4 = annulation de fichier, 5 = ping (détection de coupure).
class DirectLink {
  DirectLink(
    this._socket, {
    required this.onJson,
    required this.onChunk,
    required this.onEnd,
    required this.onCancel,
    required this.onClosed,
  }) {
    _sub = _socket.listen(
      _onData,
      onError: (_) => close(),
      onDone: close,
      cancelOnError: true,
    );
    _ping = Timer.periodic(const Duration(seconds: 8), (_) {
      _write(_tPing, 0, null);
    });
    _watch = Timer.periodic(const Duration(seconds: 5), (_) {
      if (DateTime.now().difference(_lastRx) > const Duration(seconds: 30)) close();
    });
  }

  static const _tJson = 1, _tChunk = 2, _tEnd = 3, _tCancel = 4, _tPing = 5;
  static const _maxFrame = 4 * 1024 * 1024;

  final Socket _socket;
  final void Function(Map<String, dynamic>) onJson;
  final void Function(int id, Uint8List data) onChunk;
  final void Function(int id) onEnd;
  final void Function(int id) onCancel;
  final void Function() onClosed;

  late final StreamSubscription<Uint8List> _sub;
  Timer? _ping;
  Timer? _watch;
  final _ByteQueue _q = _ByteQueue();
  DateTime _lastRx = DateTime.now();
  bool _closed = false;
  int? _hType;
  int _hId = 0;
  int _hLen = 0;
  Future<void> _tail = Future.value();

  bool get closed => _closed;

  // ------------------------------------------------------------ réception
  void _onData(Uint8List data) {
    _lastRx = DateTime.now();
    _q.add(data);
    while (!_closed) {
      if (_hType == null) {
        if (_q.length < 9) return;
        final h = _q.read(9);
        final bd = ByteData.sublistView(h);
        _hType = h[0];
        _hId = bd.getUint32(1);
        _hLen = bd.getUint32(5);
        if (_hLen > _maxFrame) {
          close();
          return;
        }
      }
      if (_q.length < _hLen) return;
      final body = _hLen == 0 ? Uint8List(0) : _q.read(_hLen);
      final t = _hType!;
      _hType = null;
      try {
        switch (t) {
          case _tJson:
            final m = jsonDecode(utf8.decode(body));
            if (m is Map<String, dynamic>) onJson(m);
          case _tChunk:
            onChunk(_hId, body);
          case _tEnd:
            onEnd(_hId);
          case _tCancel:
            onCancel(_hId);
        }
      } catch (_) {
        // Trame illisible : ignorée, le lien reste ouvert.
      }
    }
  }

  // --------------------------------------------------------------- envoi
  Future<void> _write(int type, int id, Uint8List? body) {
    if (_closed) return Future.value();
    final len = body?.length ?? 0;
    final out = Uint8List(9 + len);
    final bd = ByteData.sublistView(out);
    out[0] = type;
    bd.setUint32(1, id);
    bd.setUint32(5, len);
    if (body != null) out.setRange(9, 9 + len, body);
    final next = _tail.then<void>((_) async {
      if (_closed) return;
      _socket.add(out);
      await _socket.flush();
    }).catchError((_) {
      close();
    });
    _tail = next;
    return next;
  }

  Future<void> sendJson(Map<String, dynamic> m) =>
      _write(_tJson, 0, Uint8List.fromList(utf8.encode(jsonEncode(m))));

  Future<void> sendChunk(int id, Uint8List data) => _write(_tChunk, id, data);
  Future<void> sendEnd(int id) => _write(_tEnd, id, null);
  Future<void> sendCancel(int id) => _write(_tCancel, id, null);

  void close() {
    if (_closed) return;
    _closed = true;
    _ping?.cancel();
    _watch?.cancel();
    _sub.cancel();
    try {
      _socket.destroy();
    } catch (_) {}
    onClosed();
  }
}
