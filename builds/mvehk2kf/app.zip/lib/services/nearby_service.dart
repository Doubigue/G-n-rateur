import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';
import 'package:crypto/crypto.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:wifi_direct/wifi_direct.dart';
import '../models/peer.dart';
import 'background_service.dart';
import 'direct_link.dart';
import 'notification_service.dart';
import 'protocol.dart';

/// Rôle de cet appareil dans la session.
enum NearbyRole { none, host, client }

/// Demande de connexion entrante à valider manuellement.
class PendingConnection {
  PendingConnection(this.id, this.name, this.code);
  final String id;
  final String name;
  final String code; // identique des deux côtés
}

/// Découverte, connexion et échanges en **Wi-Fi Direct uniquement** (aucun Bluetooth).
///
/// - Visible + recherche automatiques dès l'ouverture (annonce DNS-SD Wi-Fi Direct).
/// - Toucher un appareil lance l'invitation Wi-Fi Direct ; l'autre téléphone
///   l'accepte (bouton poussoir : AUCUN mot de passe), puis LocalShare demande
///   une confirmation avec un code à 4 chiffres identique des deux côtés.
/// - Le groupe Wi-Fi Direct est créé automatiquement, même si le téléphone est
///   déjà connecté à un Wi-Fi ; le transfert passe ensuite par un lien TCP direct.
///
/// (Le nom de classe « NearbyService » est conservé pour limiter les changements.)
class NearbyService extends ChangeNotifier {
  final Map<String, Peer> _peers = {};
  final Map<String, DateTime> _seen = {};
  NearbyRole role = NearbyRole.none;
  bool isAdvertising = false;
  bool isDiscovering = false;
  bool wantDiscover = true;
  bool wantVisible = true;
  String? connectedId;
  String deviceName = 'Appareil';

  /// Problème à corriger par l'utilisateur (permission, Wi-Fi, localisation…).
  String? status;
  bool statusNeedsSettings = false;

  /// Information neutre (connexion en cours…).
  String? info;

  PendingConnection? pending;
  String? outgoingCode;

  String? _rid;
  Timer? _connectTimer;
  Timer? _restartTimer;
  Timer? _refreshTimer;
  bool _starting = false;
  bool _initDone = false;
  bool _linking = false;
  bool _ready = false;
  bool _p2pOn = true;
  bool _hasP2p = true;
  int _sdk = 0;
  Peer? _initiated;
  DirectLink? _link;
  ServerSocket? _server;
  StreamSubscription? _evSub;
  String _myNonce = '';
  String? _peerName;
  String? _code;

  final _msgCtrl = StreamController<Map<String, dynamic>>.broadcast();
  final _chunkCtrl = StreamController<(int, Uint8List)>.broadcast();
  final _endCtrl = StreamController<int>.broadcast();
  final _cancelCtrl = StreamController<int>.broadcast();
  Stream<Map<String, dynamic>> get onMessage => _msgCtrl.stream;
  Stream<(int, Uint8List)> get onChunk => _chunkCtrl.stream;
  Stream<int> get onFileEnd => _endCtrl.stream;
  Stream<int> get onFileCancel => _cancelCtrl.stream;

  List<Peer> get peers => _peers.values.toList();
  bool get isConnected => connectedId != null;
  String get connectedName => _peers[connectedId]?.name ?? _peerName ?? 'Appareil';

  static bool get supported => Platform.isAndroid;

  // ---------------------------------------------------------------- init
  Future<void> init() async {
    if (_initDone || !supported) return;
    final a = await DeviceInfoPlugin().androidInfo;
    String? custom;
    try {
      custom = (await SharedPreferences.getInstance()).getString('device_name');
    } catch (_) {}
    deviceName = (custom != null && custom.trim().isNotEmpty)
        ? custom
        : '${a.brand} ${a.model}'.replaceAll('#', '');
    _sdk = a.version.sdkInt;
    _evSub = WifiDirect.events.listen(_onEvent, onError: (_) {});
    try {
      final r = await WifiDirect.init();
      _hasP2p = r['hasP2p'] != false;
      _p2pOn = r['wifiEnabled'] != false;
    } catch (e) {
      debugPrint('WifiDirect.init: $e');
    }
    _initDone = true;
    notifyListeners();
  }

  Future<void> renameDevice(String raw) async {
    var name = raw.replaceAll('#', '').trim();
    if (name.length > 30) name = name.substring(0, 30);
    if (name.isEmpty) return;
    deviceName = name;
    try {
      (await SharedPreferences.getInstance()).setString('device_name', name);
    } catch (_) {}
    notifyListeners();
    if (!isConnected) await restart();
  }

  void _setStatus(String? msg, {bool settings = false}) {
    status = msg;
    statusNeedsSettings = settings;
    notifyListeners();
  }

  String _explain(Object e) {
    final s = e.toString();
    if (s.contains('p2p_1') || s.contains('p2p_unsupported')) {
      return 'Ce téléphone ne gère pas le Wi-Fi Direct.';
    }
    if (s.contains('p2p_2')) {
      return 'Wi-Fi Direct occupé. Patientez quelques secondes puis touchez « Réessayer ».';
    }
    if (s.toLowerCase().contains('permission')) {
      return 'Une permission manque : ouvrez les réglages de l\u2019appli.';
    }
    return 'Erreur Wi-Fi Direct : $e';
  }

  // ------------------------------------------------------- permissions
  Future<bool> ensureReady() async {
    if (!supported) return false;
    await init();
    if (!_hasP2p) {
      _setStatus('Ce téléphone ne gère pas le Wi-Fi Direct.');
      return false;
    }

    final perm = _sdk >= 33 ? Permission.nearbyWifiDevices : Permission.location;
    final st = await perm.request();
    if (!st.isGranted) {
      final blocked = st.isPermanentlyDenied;
      _setStatus(
        blocked
            ? 'Permission bloquée. Ouvrez les réglages de l\u2019appli → Autorisations, puis activez '
                '« ${_sdk >= 33 ? 'Appareils Wi-Fi à proximité' : 'Localisation'} ».'
            : 'LocalShare a besoin de la permission '
                '« ${_sdk >= 33 ? 'Appareils Wi-Fi à proximité' : 'Localisation'} » '
                'pour trouver les appareils en Wi-Fi Direct.',
        settings: blocked,
      );
      return false;
    }
    if (_sdk < 33 && !await Permission.location.serviceStatus.isEnabled) {
      _setStatus(
        'Activez la localisation (GPS) dans les réglages rapides : Android l\u2019exige pour le '
        'Wi-Fi Direct (aucune position n\u2019est utilisée). Puis touchez « Réessayer ».',
      );
      return false;
    }
    if (!_p2pOn) {
      _setStatus(
        'Activez le Wi-Fi (inutile d\u2019être connecté à un réseau) : le Wi-Fi Direct en a besoin. '
        'Puis touchez « Réessayer ».',
      );
      return false;
    }
    return true;
  }

  static String _randomHex(int n) {
    final r = Random.secure();
    return List.generate(n, (_) => r.nextInt(16).toRadixString(16)).join();
  }

  // ------------------------------------------------- démarrage automatique
  Future<void> start() async {
    if (!supported || _starting || isConnected || _linking) return;
    _starting = true;
    try {
      if (!await ensureReady()) return;
      status = null;
      statusNeedsSettings = false;
      if (wantVisible && !isAdvertising) await _advertise();
      if (wantDiscover && !isDiscovering) await _discover();
      if (isAdvertising || isDiscovering) {
        await BackgroundService.start(
          isAdvertising ? 'Visible comme « $deviceName »' : 'Recherche d\u2019appareils…',
        );
      }
    } finally {
      _starting = false;
      notifyListeners();
    }
  }

  Future<void> restart() async {
    if (isConnected || _linking) return;
    await WifiDirect.stopAdvertising();
    await WifiDirect.stopDiscovery();
    isAdvertising = false;
    isDiscovering = false;
    wantDiscover = true;
    _peers.removeWhere((_, p) => p.state != PeerState.connected);
    notifyListeners();
    await start();
  }

  void _scheduleRestart() {
    _restartTimer?.cancel();
    _restartTimer = Timer(const Duration(milliseconds: 1200), start);
  }

  // ------------------------------------------------------- annonce (visible)
  Future<void> _advertise() async {
    _rid = _randomHex(4);
    try {
      isAdvertising = await WifiDirect.startAdvertising(deviceName, _rid!);
    } catch (e) {
      debugPrint('startAdvertising error: $e');
      isAdvertising = false;
      _setStatus(_explain(e));
    }
    if (!isAdvertising) _rid = null;
    notifyListeners();
  }

  Future<void> setVisible(bool v) async {
    wantVisible = v;
    if (v) {
      if (await ensureReady()) await _advertise();
    } else {
      await WifiDirect.stopAdvertising();
      isAdvertising = false;
      _rid = null;
    }
    notifyListeners();
  }

  Future<void> stopAdvertising() => setVisible(false);

  // --------------------------------------------------------- recherche
  Future<void> _discover() async {
    try {
      isDiscovering = await WifiDirect.startDiscovery();
    } catch (e) {
      debugPrint('startDiscovery error: $e');
      isDiscovering = false;
      _setStatus(_explain(e));
    }
    _refreshTimer ??= Timer.periodic(const Duration(seconds: 20), (_) => _refreshDiscovery());
    notifyListeners();
  }

  /// Android arrête la découverte au bout de ~2 min : on la relance et on
  /// retire les appareils qui ne répondent plus.
  void _refreshDiscovery() {
    if (isConnected || _linking || !isDiscovering) return;
    final now = DateTime.now();
    _peers.removeWhere((id, p) =>
        p.state == PeerState.discovered &&
        now.difference(_seen[id] ?? now) > const Duration(seconds: 75));
    notifyListeners();
    WifiDirect.startDiscovery().catchError((_) => false);
  }

  void _onEvent(dynamic raw) {
    if (raw is! Map) return;
    final e = Map<String, dynamic>.from(raw);
    switch (e['e']) {
      case 'found':
        _onFound(e);
      case 'state':
        _p2pOn = e['enabled'] == true;
        if (!_p2pOn) {
          isAdvertising = isDiscovering = false;
          _setStatus('Wi-Fi désactivé : activez-le pour utiliser le Wi-Fi Direct.');
        } else if (status != null && status!.contains('Wi-Fi désactivé')) {
          status = null;
          _scheduleRestart();
        }
        notifyListeners();
      case 'connected':
        _onGroupFormed(e['owner'] == true, e['ownerAddress'] as String?);
      case 'disconnected':
        if (_link != null || connectedId != null) _onLinkClosed();
    }
  }

  void _onFound(Map<String, dynamic> e) {
    if (isConnected || _linking) return;
    final addr = e['addr'] as String? ?? '';
    if (addr.isEmpty) return;
    final name = ((e['name'] as String?) ?? '').replaceAll('#', '').trim();
    final rid = (e['rid'] as String?) ?? '';
    final ex = _peers[addr];
    if (ex == null) {
      _peers[addr] = Peer(addr, name.isEmpty ? 'Appareil' : name, rid: rid);
    } else if (ex.state == PeerState.discovered && name.isNotEmpty && ex.name != name) {
      _peers[addr] = Peer(addr, name, rid: rid);
    }
    _seen[addr] = DateTime.now();
    notifyListeners();
  }

  // ------------------------------------------------------------- connexion
  Future<void> connectTo(Peer peer) async {
    if (peer.state == PeerState.connecting || isConnected || _linking) return;
    peer.state = PeerState.connecting;
    status = null;
    info = 'Invitation Wi-Fi Direct envoyée à ${peer.name}… '
        'L\u2019autre téléphone doit toucher « Accepter ».';
    _initiated = peer;
    notifyListeners();

    _connectTimer?.cancel();
    _connectTimer = Timer(const Duration(seconds: 60), () {
      if (!isConnected && _initiated != null) {
        _failConnect('${peer.name} n\u2019a pas répondu.');
      }
    });

    try {
      isDiscovering = false;
      await WifiDirect.stopDiscovery();
      await WifiDirect.connect(peer.id);
      role = NearbyRole.client;
    } catch (e) {
      debugPrint('connect error: $e');
      _failConnect(_explain(e));
    }
  }

  void _failConnect(String msg) {
    _cleanupSession();
    WifiDirect.disconnect();
    _setStatus(msg);
    _scheduleRestart();
  }

  /// Groupe Wi-Fi Direct formé : le propriétaire ouvre un serveur TCP, l'autre s'y connecte.
  Future<void> _onGroupFormed(bool owner, String? addr) async {
    if (_linking || _link != null || isConnected) return;
    _linking = true;
    isDiscovering = false;
    WifiDirect.stopDiscovery();
    // Même connecté à un Wi-Fi / aux données mobiles : on force le trafic sur le Wi-Fi Direct.
    await WifiDirect.bindNetwork(true);
    notifyListeners();
    try {
      Socket sock;
      if (owner) {
        _server = await ServerSocket.bind(InternetAddress.anyIPv4, Protocol.port, shared: true);
        sock = await _server!.first.timeout(const Duration(seconds: 50));
        await _server?.close();
        _server = null;
      } else {
        if (addr == null) {
          _linking = false;
          return;
        }
        sock = await _connectWithRetry(addr);
      }
      _attach(sock);
    } catch (e) {
      debugPrint('link error: $e');
      _failConnect('Connexion Wi-Fi Direct impossible. Réessayez des deux côtés.');
    }
  }

  Future<Socket> _connectWithRetry(String addr) async {
    Object? last;
    for (var i = 0; i < 25; i++) {
      try {
        return await Socket.connect(addr, Protocol.port, timeout: const Duration(seconds: 4));
      } catch (e) {
        last = e;
        await Future.delayed(const Duration(milliseconds: 600));
      }
    }
    throw last ?? 'connexion impossible';
  }

  void _attach(Socket s) {
    try {
      s.setOption(SocketOption.tcpNoDelay, true);
    } catch (_) {}
    _myNonce = _randomHex(16);
    _ready = false;
    _peerName = null;
    _code = null;
    _link = DirectLink(
      s,
      onJson: _onLinkJson,
      onChunk: (id, d) => _chunkCtrl.add((id, d)),
      onEnd: (id) => _endCtrl.add(id),
      onCancel: (id) => _cancelCtrl.add(id),
      onClosed: _onLinkClosed,
    );
    _link!.sendJson({'t': 'hello', 'name': deviceName, 'nonce': _myNonce, 'v': 1});
  }

  void _onLinkJson(Map<String, dynamic> m) {
    switch (m['t']) {
      case 'hello':
        _onHello(m);
      case 'accept':
        if (_initiated != null && !_ready) _markConnected(_peerName ?? _initiated!.name);
      case 'bye':
        _onLinkClosed();
      case 'reject':
        _failConnect('${_peerName ?? 'L\u2019autre appareil'} a refusé la connexion.');
      default:
        if (_ready) _msgCtrl.add(m);
    }
  }

  void _onHello(Map<String, dynamic> m) {
    final nonce = m['nonce'] as String? ?? '';
    if (nonce.isEmpty || _peerName != null) return;
    final raw = (m['name'] as String? ?? '').replaceAll('#', '').trim();
    _peerName = raw.isEmpty ? 'Appareil' : raw;
    final pair = [_myNonce, nonce]..sort();
    final d = sha256.convert(utf8.encode(pair.join(':'))).bytes;
    _code = (((d[0] << 8) | d[1]) % 10000).toString().padLeft(4, '0');

    final incoming = _initiated == null;
    if (incoming) {
      role = NearbyRole.host;
      _peers['link'] = Peer('link', _peerName!, state: PeerState.connecting);
      pending = PendingConnection('link', _peerName!, _code!);
      NotificationService.showConnectionRequest(_peerName!, _code!);
      _connectTimer?.cancel();
      _connectTimer = Timer(const Duration(seconds: 60), () {
        if (pending != null) rejectPending();
      });
    } else {
      outgoingCode = _code;
      info = 'En attente de l\u2019accord de $_peerName…';
    }
    notifyListeners();
  }

  void acceptPending() {
    final pc = pending;
    if (pc == null) return;
    pending = null;
    NotificationService.cancel(NotificationService.idRequest);
    _link?.sendJson({'t': 'accept'});
    _markConnected(pc.name);
  }

  Future<void> rejectPending() async {
    final pc = pending;
    if (pc == null) return;
    pending = null;
    NotificationService.cancel(NotificationService.idRequest);
    await _link?.sendJson({'t': 'reject'});
    _cleanupSession();
    WifiDirect.disconnect();
    _scheduleRestart();
  }

  void _markConnected(String name) {
    _connectTimer?.cancel();
    _ready = true;
    _linking = false;
    final id = _initiated?.id ?? 'link';
    _peers
      ..clear()
      ..[id] = Peer(id, name, state: PeerState.connected);
    connectedId = id;
    pending = null;
    outgoingCode = null;
    info = null;
    status = null;
    statusNeedsSettings = false;
    isAdvertising = isDiscovering = false;
    _rid = null;
    WifiDirect.stopAdvertising();
    BackgroundService.start('Connecté à $name');
    BackgroundService.requestBatteryExemption();
    notifyListeners();
  }

  void _onLinkClosed() {
    final wasConnected = connectedId != null;
    final wasLinking = _initiated != null || _link != null;
    if (!wasConnected && !wasLinking) return;
    _cleanupSession();
    WifiDirect.disconnect();
    if (wasConnected) BackgroundService.start('Reconnexion…');
    _scheduleRestart();
    notifyListeners();
  }

  void _cleanupSession() {
    _connectTimer?.cancel();
    try {
      _server?.close();
    } catch (_) {}
    _server = null;
    final l = _link;
    _link = null;
    _ready = false;
    _linking = false;
    _initiated = null;
    pending = null;
    outgoingCode = null;
    connectedId = null;
    role = NearbyRole.none;
    info = null;
    isAdvertising = isDiscovering = false;
    _rid = null;
    _peerName = null;
    _peers.clear();
    NotificationService.cancel(NotificationService.idRequest);
    l?.close(); // état déjà remis à zéro : _onLinkClosed ne fait donc rien
    notifyListeners();
  }

  Future<void> disconnect() async {
    try {
      await _link?.sendJson({'t': 'bye'});
    } catch (_) {}
    _cleanupSession();
    await WifiDirect.disconnect();
    _scheduleRestart();
  }

  /// Arrêt complet (menu « Quitter »).
  Future<void> shutdown() async {
    _restartTimer?.cancel();
    _refreshTimer?.cancel();
    _refreshTimer = null;
    _cleanupSession();
    await WifiDirect.stopAdvertising();
    await WifiDirect.stopDiscovery();
    await WifiDirect.disconnect();
    notifyListeners();
  }

  // --------------------------------------------------------------- envoi
  Future<void> send(Map<String, dynamic> m) async {
    if (_ready) await _link?.sendJson(m);
  }

  Future<void> sendChunk(int id, Uint8List d) async {
    if (_ready) await _link?.sendChunk(id, d);
  }

  Future<void> sendEnd(int id) async {
    if (_ready) await _link?.sendEnd(id);
  }

  Future<void> sendCancel(int id) async {
    if (_ready) await _link?.sendCancel(id);
  }

  @override
  void dispose() {
    _connectTimer?.cancel();
    _restartTimer?.cancel();
    _refreshTimer?.cancel();
    _evSub?.cancel();
    _msgCtrl.close();
    _chunkCtrl.close();
    _endCtrl.close();
    _cancelCtrl.close();
    super.dispose();
  }
}
