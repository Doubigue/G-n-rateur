package com.doubigue.wifi_direct;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.LinkProperties;
import android.net.Network;
import android.net.wifi.WifiManager;
import android.net.wifi.WpsInfo;
import android.net.wifi.p2p.WifiP2pConfig;
import android.net.wifi.p2p.WifiP2pDevice;
import android.net.wifi.p2p.WifiP2pInfo;
import android.net.wifi.p2p.WifiP2pManager;
import android.net.wifi.p2p.nsd.WifiP2pDnsSdServiceInfo;
import android.net.wifi.p2p.nsd.WifiP2pDnsSdServiceRequest;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.NonNull;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import io.flutter.embedding.engine.plugins.FlutterPlugin;
import io.flutter.plugin.common.EventChannel;
import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;
import io.flutter.plugin.common.MethodChannel.MethodCallHandler;
import io.flutter.plugin.common.MethodChannel.Result;

/**
 * Wi-Fi Direct (WifiP2pManager) : annonce et découverte via DNS-SD, invitation
 * par bouton poussoir (aucun mot de passe), infos du groupe, liste des applis.
 * Le transfert lui-même se fait ensuite en TCP côté Dart.
 */
public class WifiDirectPlugin implements FlutterPlugin, MethodCallHandler, EventChannel.StreamHandler {
    private static final String TAG = "wifi_direct";
    private static final String SERVICE_TYPE = "_localshare._tcp";

    private Context ctx;
    private MethodChannel method;
    private EventChannel events;
    private EventChannel.EventSink sink;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    private WifiP2pManager manager;
    private WifiP2pManager.Channel channel;
    private BroadcastReceiver receiver;
    private boolean boundToP2p = false;

    // ------------------------------------------------------------ plugin
    @Override
    public void onAttachedToEngine(@NonNull FlutterPluginBinding b) {
        ctx = b.getApplicationContext();
        method = new MethodChannel(b.getBinaryMessenger(), "wifi_direct");
        method.setMethodCallHandler(this);
        events = new EventChannel(b.getBinaryMessenger(), "wifi_direct/events");
        events.setStreamHandler(this);
    }

    @Override
    public void onDetachedFromEngine(@NonNull FlutterPluginBinding b) {
        method.setMethodCallHandler(null);
        events.setStreamHandler(null);
        unregister();
        unbind();
    }

    @Override
    public void onListen(Object args, EventChannel.EventSink s) {
        sink = s;
    }

    @Override
    public void onCancel(Object args) {
        sink = null;
    }

    private void emit(final Map<String, Object> m) {
        main.post(new Runnable() {
            @Override
            public void run() {
                if (sink != null) sink.success(m);
            }
        });
    }

    // ----------------------------------------------------------- helpers
    private interface Done {
        void run(boolean ok, int reason);
    }

    private static class L implements WifiP2pManager.ActionListener {
        private final Done d;

        L(Done d) {
            this.d = d;
        }

        @Override
        public void onSuccess() {
            d.run(true, 0);
        }

        @Override
        public void onFailure(int reason) {
            d.run(false, reason);
        }
    }

    private boolean ensure() {
        if (ctx == null) return false;
        if (manager == null) {
            manager = (WifiP2pManager) ctx.getSystemService(Context.WIFI_P2P_SERVICE);
        }
        if (manager == null) return false;
        if (channel == null) {
            channel = manager.initialize(ctx, Looper.getMainLooper(), new WifiP2pManager.ChannelListener() {
                @Override
                public void onChannelDisconnected() {
                    channel = null;
                }
            });
        }
        registerReceiverOnce();
        return channel != null;
    }

    private void registerReceiverOnce() {
        if (receiver != null) return;
        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent i) {
                String a = i.getAction();
                if (WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION.equals(a)) {
                    int st = i.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE, -1);
                    Map<String, Object> m = new HashMap<>();
                    m.put("e", "state");
                    m.put("enabled", st == WifiP2pManager.WIFI_P2P_STATE_ENABLED);
                    emit(m);
                } else if (WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION.equals(a)) {
                    requestInfo();
                }
            }
        };
        IntentFilter f = new IntentFilter();
        f.addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION);
        f.addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION);
        if (Build.VERSION.SDK_INT >= 33) {
            ctx.registerReceiver(receiver, f, Context.RECEIVER_EXPORTED);
        } else {
            ctx.registerReceiver(receiver, f);
        }
    }

    private void unregister() {
        if (receiver != null && ctx != null) {
            try {
                ctx.unregisterReceiver(receiver);
            } catch (Exception ignored) {
            }
        }
        receiver = null;
    }

    private void requestInfo() {
        if (manager == null || channel == null) return;
        try {
            manager.requestConnectionInfo(channel, new WifiP2pManager.ConnectionInfoListener() {
                @Override
                public void onConnectionInfoAvailable(WifiP2pInfo info) {
                    Map<String, Object> m = new HashMap<>();
                    if (info != null && info.groupFormed && info.groupOwnerAddress != null) {
                        m.put("e", "connected");
                        m.put("owner", info.isGroupOwner);
                        m.put("ownerAddress", info.groupOwnerAddress.getHostAddress());
                    } else {
                        m.put("e", "disconnected");
                    }
                    emit(m);
                }
            });
        } catch (SecurityException e) {
            Log.w(TAG, "requestConnectionInfo: " + e);
        }
    }

    // --------------------------------------------------- découverte DNS-SD
    private final WifiP2pManager.DnsSdServiceResponseListener serviceListener =
            new WifiP2pManager.DnsSdServiceResponseListener() {
                @Override
                public void onDnsSdServiceAvailable(String instanceName, String regType, WifiP2pDevice device) {
                    if (regType == null || !regType.startsWith(SERVICE_TYPE) || device == null) return;
                    Map<String, Object> m = new HashMap<>();
                    m.put("e", "found");
                    m.put("addr", device.deviceAddress);
                    m.put("name", "");
                    m.put("rid", instanceName != null && instanceName.startsWith("ls") ? instanceName.substring(2) : "");
                    emit(m);
                }
            };

    private final WifiP2pManager.DnsSdTxtRecordListener txtListener =
            new WifiP2pManager.DnsSdTxtRecordListener() {
                @Override
                public void onDnsSdTxtRecordAvailable(String fullDomain, Map<String, String> txt, WifiP2pDevice device) {
                    if (txt == null || device == null || !txt.containsKey("r")) return;
                    Map<String, Object> m = new HashMap<>();
                    m.put("e", "found");
                    m.put("addr", device.deviceAddress);
                    m.put("name", txt.containsKey("n") ? txt.get("n") : "");
                    m.put("rid", txt.get("r"));
                    emit(m);
                }
            };

    // ------------------------------------------------------------ appels
    @Override
    public void onMethodCall(@NonNull MethodCall call, @NonNull final Result result) {
        try {
            switch (call.method) {
                case "init": {
                    boolean has = ctx.getPackageManager().hasSystemFeature(PackageManager.FEATURE_WIFI_DIRECT);
                    boolean ok = has && ensure();
                    WifiManager wm = (WifiManager) ctx.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                    Map<String, Object> r = new HashMap<>();
                    r.put("hasP2p", ok);
                    r.put("wifiEnabled", wm != null && wm.isWifiEnabled());
                    r.put("sdk", Build.VERSION.SDK_INT);
                    result.success(r);
                    break;
                }
                case "startAdvertising":
                    startAdvertising(call, result);
                    break;
                case "stopAdvertising":
                    if (ensure()) manager.clearLocalServices(channel, null);
                    result.success(true);
                    break;
                case "startDiscovery":
                    startDiscovery(result);
                    break;
                case "stopDiscovery":
                    if (ensure()) {
                        manager.clearServiceRequests(channel, null);
                        manager.stopPeerDiscovery(channel, null);
                    }
                    result.success(true);
                    break;
                case "connect":
                    connect(call, result);
                    break;
                case "disconnect":
                    if (ensure()) {
                        manager.cancelConnect(channel, null);
                        manager.removeGroup(channel, null);
                    }
                    unbind();
                    result.success(true);
                    break;
                case "bindNetwork": {
                    Boolean on = call.argument("on");
                    result.success(on != null && on ? bindToP2p() : unbind());
                    break;
                }
                case "listApps":
                    listApps(result);
                    break;
                default:
                    result.notImplemented();
            }
        } catch (SecurityException e) {
            result.error("permission", "Permission manquante : " + e.getMessage(), null);
        } catch (Throwable t) {
            result.error("p2p_error", String.valueOf(t), null);
        }
    }

    private void startAdvertising(MethodCall call, final Result result) {
        String name = call.argument("name");
        String rid = call.argument("rid");
        if (!ensure()) {
            result.error("p2p_unsupported", "Wi-Fi Direct indisponible", null);
            return;
        }
        Map<String, String> txt = new HashMap<>();
        txt.put("n", name == null ? "" : name);
        txt.put("r", rid == null ? "" : rid);
        txt.put("v", "1");
        final WifiP2pDnsSdServiceInfo info =
                WifiP2pDnsSdServiceInfo.newInstance("ls" + rid, SERVICE_TYPE, txt);
        manager.clearLocalServices(channel, new L(new Done() {
            @Override
            public void run(boolean ok, int reason) {
                manager.addLocalService(channel, info, new L(new Done() {
                    @Override
                    public void run(boolean ok2, int r2) {
                        if (ok2) result.success(true);
                        else result.error("p2p_" + r2, "addLocalService " + r2, null);
                    }
                }));
            }
        }));
    }

    private void startDiscovery(final Result result) {
        if (!ensure()) {
            result.error("p2p_unsupported", "Wi-Fi Direct indisponible", null);
            return;
        }
        manager.setDnsSdResponseListeners(channel, serviceListener, txtListener);
        manager.clearServiceRequests(channel, new L(new Done() {
            @Override
            public void run(boolean ok, int reason) {
                manager.addServiceRequest(channel, WifiP2pDnsSdServiceRequest.newInstance(), new L(new Done() {
                    @Override
                    public void run(boolean ok2, int r2) {
                        if (!ok2) {
                            result.error("p2p_" + r2, "addServiceRequest " + r2, null);
                            return;
                        }
                        // discoverPeers d'abord : sur beaucoup de téléphones, discoverServices seul ne trouve rien.
                        manager.discoverPeers(channel, new L(new Done() {
                            @Override
                            public void run(boolean ok3, int r3) {
                                manager.discoverServices(channel, new L(new Done() {
                                    @Override
                                    public void run(boolean ok4, int r4) {
                                        if (ok4 || r4 == WifiP2pManager.BUSY) result.success(true);
                                        else result.error("p2p_" + r4, "discoverServices " + r4, null);
                                    }
                                }));
                            }
                        }));
                    }
                }));
            }
        }));
    }

    private void connect(MethodCall call, final Result result) {
        String addr = call.argument("address");
        if (addr == null || !ensure()) {
            result.error("p2p_unsupported", "Wi-Fi Direct indisponible", null);
            return;
        }
        WifiP2pConfig cfg = new WifiP2pConfig();
        cfg.deviceAddress = addr;
        cfg.wps.setup = WpsInfo.PBC; // bouton poussoir : aucun mot de passe ni PIN
        manager.connect(channel, cfg, new L(new Done() {
            @Override
            public void run(boolean ok, int reason) {
                if (ok) result.success(true);
                else result.error("p2p_" + reason, "connect " + reason, null);
            }
        }));
    }

    // ------------------------------------------- trafic sur le Wi-Fi Direct
    private boolean bindToP2p() {
        try {
            if (Build.VERSION.SDK_INT < 23) return false;
            ConnectivityManager cm = (ConnectivityManager) ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
            for (Network n : cm.getAllNetworks()) {
                LinkProperties lp = cm.getLinkProperties(n);
                if (lp != null && lp.getInterfaceName() != null && lp.getInterfaceName().contains("p2p")) {
                    boundToP2p = cm.bindProcessToNetwork(n);
                    return boundToP2p;
                }
            }
        } catch (Throwable t) {
            Log.w(TAG, "bind: " + t);
        }
        return false;
    }

    private boolean unbind() {
        try {
            if (boundToP2p && Build.VERSION.SDK_INT >= 23 && ctx != null) {
                ConnectivityManager cm = (ConnectivityManager) ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
                cm.bindProcessToNetwork(null);
            }
        } catch (Throwable ignored) {
        }
        boundToP2p = false;
        return true;
    }

    // ------------------------------------------------ applications installées
    private void listApps(final Result result) {
        io.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    PackageManager pm = ctx.getPackageManager();
                    List<ApplicationInfo> apps = pm.getInstalledApplications(0);
                    final List<Map<String, Object>> out = new ArrayList<>();
                    for (ApplicationInfo ai : apps) {
                        Map<String, Object> m = new HashMap<>();
                        boolean system = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0
                                && (ai.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0;
                        String ver = "";
                        try {
                            PackageInfo pi = pm.getPackageInfo(ai.packageName, 0);
                            if (pi.versionName != null) ver = pi.versionName;
                        } catch (Exception ignored) {
                        }
                        m.put("n", String.valueOf(pm.getApplicationLabel(ai)));
                        m.put("p", ai.packageName);
                        m.put("v", ver);
                        m.put("s", system);
                        m.put("i", iconPng(pm.getApplicationIcon(ai)));
                        out.add(m);
                    }
                    Collections.sort(out, new Comparator<Map<String, Object>>() {
                        @Override
                        public int compare(Map<String, Object> a, Map<String, Object> b) {
                            return ((String) a.get("n")).compareToIgnoreCase((String) b.get("n"));
                        }
                    });
                    main.post(new Runnable() {
                        @Override
                        public void run() {
                            result.success(out);
                        }
                    });
                } catch (final Throwable t) {
                    main.post(new Runnable() {
                        @Override
                        public void run() {
                            result.error("apps", String.valueOf(t), null);
                        }
                    });
                }
            }
        });
    }

    private byte[] iconPng(Drawable d) {
        try {
            int sz = 64;
            Bitmap bmp = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(bmp);
            d.setBounds(0, 0, sz, sz);
            d.draw(c);
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            bmp.compress(Bitmap.CompressFormat.PNG, 100, bo);
            bmp.recycle();
            return bo.toByteArray();
        } catch (Throwable t) {
            return null;
        }
    }
}
