import 'dart:async';
import 'package:flutter/services.dart';

/// Pont vers WifiP2pManager (Wi-Fi Direct). Aucun Bluetooth.
///
/// Événements (Map) reçus via [events] :
///  {e:'found', addr, name, rid}                appareil LocalShare détecté
///  {e:'state', enabled}                        Wi-Fi Direct activé / désactivé
///  {e:'connected', owner, ownerAddress}        groupe Wi-Fi Direct formé
///  {e:'disconnected'}                          groupe dissous
class WifiDirect {
  WifiDirect._();
  static const _m = MethodChannel('wifi_direct');
  static const _e = EventChannel('wifi_direct/events');
  static Stream<dynamic>? _stream;
  static Stream<dynamic> get events => _stream ??= _e.receiveBroadcastStream();

  static Future<Map<String, dynamic>> init() async {
    final r = await _m.invokeMethod<Map<dynamic, dynamic>>('init');
    return Map<String, dynamic>.from(r ?? {});
  }

  static Future<bool> startAdvertising(String name, String rid) async =>
      await _m.invokeMethod<bool>('startAdvertising', {'name': name, 'rid': rid}) ?? false;

  static Future<void> stopAdvertising() async {
    try {
      await _m.invokeMethod('stopAdvertising');
    } catch (_) {}
  }

  static Future<bool> startDiscovery() async =>
      await _m.invokeMethod<bool>('startDiscovery') ?? false;

  static Future<void> stopDiscovery() async {
    try {
      await _m.invokeMethod('stopDiscovery');
    } catch (_) {}
  }

  /// Lance l'invitation Wi-Fi Direct (bouton poussoir, aucun mot de passe).
  static Future<bool> connect(String address) async =>
      await _m.invokeMethod<bool>('connect', {'address': address}) ?? false;

  static Future<void> disconnect() async {
    try {
      await _m.invokeMethod('disconnect');
    } catch (_) {}
  }

  /// Force le trafic de l'appli sur l'interface Wi-Fi Direct (même si le
  /// téléphone est connecté à un Wi-Fi ou aux données mobiles).
  static Future<bool> bindNetwork(bool on) async {
    try {
      return await _m.invokeMethod<bool>('bindNetwork', {'on': on}) ?? false;
    } catch (_) {
      return false;
    }
  }

  /// Applications installées : [{n: nom, p: paquet, v: version, s: système, i: icône PNG}]
  static Future<List<Map<String, dynamic>>> listApps() async {
    final r = await _m.invokeMethod<List<dynamic>>('listApps');
    return (r ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }
}
