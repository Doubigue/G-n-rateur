# LocalShare 2.0 — Wi-Fi Direct uniquement

Partage local style Quick Share, **sans Bluetooth** :
- **Wi-Fi Direct automatique** : le groupe est créé tout seul, même si le téléphone est connecté à un Wi-Fi ;
- envoi de fichiers (reçus dans **`DoubigueShare`**) et de texte ;
- **Ses fichiers** : parcourir les fichiers de l'autre téléphone, avec **filtre par jour** ;
- **Ses applications** : voir l'écran des applications installées de l'autre téléphone ;
- **Menu « Partager » d'Android** : appui long sur un fichier → Partager → LocalShare → l'appli s'ouvre,
  cherche les téléphones proches, et envoie dès que l'autre accepte ;
- plus d'alerte de plantage.

## Utilisation
1. Ouvrez LocalShare sur les **deux** téléphones (Wi-Fi activé ; localisation activée sur Android 12 et moins).
2. Touchez l'autre téléphone. **Aucun mot de passe** :
   - l'autre téléphone affiche l'invitation Wi-Fi Direct d'Android → **Accepter** ;
   - puis LocalShare affiche un code à 4 chiffres identique des deux côtés → **Accepter**.
   Si un PIN est quand même demandé (certains Samsung/Xiaomi), c'est celui affiché sur l'autre téléphone.
3. Envoyer, Texte, Ses fichiers, Ses applications.

## Construire avec APK Studio
- Importez le ZIP comme projet **Flutter** (`pubspec.yaml`, `lib/`, `packages/` à la racine).
- Laissez **Partage** activé (c'est lui qui ajoute LocalShare au menu « Partager »).
- **Décochez Bluetooth** dans les autorisations ; gardez Localisation, Notifications, Tous les fichiers.
- Testez sur **deux téléphones physiques**.

## Notes techniques
- Découverte : Wi-Fi Direct DNS-SD (`_localshare._tcp`) ; connexion : WifiP2pManager (bouton poussoir) ;
  transfert : TCP direct (port 8988) sur le groupe Wi-Fi Direct, trames multiplexées (fichiers + commandes).
- Les fichiers sont écrits directement dans `DoubigueShare` (plus de copie finale).
- Accès aux fichiers/applications : consentement explicite, stockage interne, révocable, remis à zéro à la déconnexion.
- Limites : Android uniquement ; certains téléphones coupent le Wi-Fi classique pendant le Wi-Fi Direct
  (ils le rétablissent à la déconnexion) ; l'invitation Wi-Fi Direct d'Android ne peut pas être supprimée.
