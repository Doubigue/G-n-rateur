package com.virtuelmix.ui

import android.Manifest
import android.app.Application
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import com.virtuelmix.audio.*

class MixViewModel(app: Application) : AndroidViewModel(app) {
    val engine = MixEngine(app, viewModelScope)
    override fun onCleared() = engine.release()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Surface { MixScreen() } } }
    }
}

@Composable
fun MixScreen(vm: MixViewModel = viewModel()) {
    val e = vm.engine
    val ctx = LocalContext.current
    var started by remember { mutableStateOf(false) }
    var rec by remember { mutableStateOf(false) }
    var talk by remember { mutableStateOf(false) }

    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) { e.mic.start(); talk = true }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach {
            runCatching { ctx.contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            e.playlist.enqueue(MediaItem.fromUri(it))
        }
        if (!started && uris.isNotEmpty()) { e.playlist.startFirst(); started = true }
    }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Virtuel Mix", style = MaterialTheme.typography.headlineMedium)
        Button({ picker.launch(arrayOf("audio/*")) }, Modifier.fillMaxWidth()) { Text("Ajouter des morceaux (file d'attente)") }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(
                onClick = { if (rec) e.recorder.stop() else e.recorder.start(); rec = !rec },
                colors = ButtonDefaults.buttonColors(containerColor = if (rec) Color.Red else MaterialTheme.colorScheme.primary),
                modifier = Modifier.weight(1f)
            ) { Text(if (rec) "■ STOP" else "● REC") }
            Button(
                onClick = {
                    if (talk) { e.mic.stop(); talk = false }
                    else if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        e.mic.start(); talk = true
                    } else micPerm.launch(Manifest.permission.RECORD_AUDIO)
                },
                colors = ButtonDefaults.buttonColors(containerColor = if (talk) Color(0xFF2E7D32) else MaterialTheme.colorScheme.primary),
                modifier = Modifier.weight(1f)
            ) { Text(if (talk) "TALK ON" else "TALK") }
        }
        DeckEq("Deck A") { e.setEq(e.procA, it) }
        DeckEq("Deck B") { e.setEq(e.procB, it) }
        Text("Les enregistrements vont dans Music/Virtuelmix.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun DeckEq(title: String, onChange: (EqPreset) -> Unit) {
    var low by remember { mutableFloatStateOf(0f) }
    var mid by remember { mutableFloatStateOf(0f) }
    var high by remember { mutableFloatStateOf(0f) }
    fun push() = onChange(EqPreset("Custom", low, mid, high))
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                EqPreset.ALL.forEach { p ->
                    OutlinedButton({ low = p.lowDb; mid = p.midDb; high = p.highDb; onChange(p) }) { Text(p.name) }
                }
            }
            Text("Basses ${"%.1f".format(low)} dB"); Slider(low, { low = it; push() }, valueRange = -12f..12f)
            Text("Médiums ${"%.1f".format(mid)} dB"); Slider(mid, { mid = it; push() }, valueRange = -12f..12f)
            Text("Aigus ${"%.1f".format(high)} dB"); Slider(high, { high = it; push() }, valueRange = -12f..12f)
        }
    }
}
