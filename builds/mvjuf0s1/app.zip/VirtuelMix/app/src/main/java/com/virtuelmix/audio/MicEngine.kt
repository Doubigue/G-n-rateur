package com.virtuelmix.audio

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.media.*
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import androidx.media3.common.*
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import kotlinx.coroutines.*
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*
import com.virtuelmix.data.*

class MicEngine(
    private val bus: MixBus,
    private val ducker: Ducker,
    private val sampleRate: Int = 44100
) {
    private var record: AudioRecord? = null
    private var aec: AcousticEchoCanceler? = null
    private var ns: NoiseSuppressor? = null
    @Volatile private var running = false

    @SuppressLint("MissingPermission")
    fun start() {
        val min = AudioRecord.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        // VOICE_COMMUNICATION active le traitement voix du système (AEC/NS/AGC)
        val rec = AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION, sampleRate,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, min * 2)
        record = rec

        if (AcousticEchoCanceler.isAvailable())
            aec = AcousticEchoCanceler.create(rec.audioSessionId)?.apply { enabled = true }
        if (NoiseSuppressor.isAvailable())
            ns = NoiseSuppressor.create(rec.audioSessionId)?.apply { enabled = true }

        running = true
        rec.startRecording()
        Thread {
            val shorts = ShortArray(512)
            val stereo = FloatArray(shorts.size * 2)
            while (running) {
                val n = rec.read(shorts, 0, shorts.size)
                if (n <= 0) continue
                var sum = 0.0
                for (i in 0 until n) {
                    val f = shorts[i] / 32768f
                    stereo[2 * i] = f; stereo[2 * i + 1] = f   // mono -> stéréo
                    sum += f * f
                }
                ducker.onMicLevel(sqrt(sum / n).toFloat())
                bus.push("mic", stereo, n * 2)
            }
        }.start()
    }

    fun stop() {
        running = false
        aec?.release(); ns?.release()
        record?.stop(); record?.release()
        aec = null; ns = null; record = null
    }
}
