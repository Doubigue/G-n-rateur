package com.virtuelmix.audio

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.media.*
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import androidx.media3.common.*
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import kotlinx.coroutines.*
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*
import com.virtuelmix.data.*

class DeckProcessor(
    private val id: String,
    private val bus: MixBus,
    private val ducker: Ducker
) : BaseAudioProcessor() {

    @Volatile var deckGain = 1f
    @Volatile var preset: EqPreset = EqPreset.FLAT
    private var eq: EqProcessor? = null
    fun eq() = eq

    override fun onConfigure(f: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (f.encoding != C.ENCODING_PCM_16BIT || f.channelCount != 2)
            throw AudioProcessor.UnhandledAudioFormatException(f)
        eq = EqProcessor(f.sampleRate).also { it.apply(preset) }
        return f
    }

    override fun queueInput(input: ByteBuffer) {
        val out = replaceOutputBuffer(input.remaining())
        val tap = FloatArray(input.remaining() / 2)
        var i = 0; var ch = 0
        val g = deckGain * ducker.musicGain
        while (input.hasRemaining()) {
            val s = input.short / 32768f
            val y = (eq!!.process(s, ch) * g).coerceIn(-1f, 1f)
            out.putShort((y * 32767f).toInt().toShort())
            tap[i++] = y; ch = ch xor 1
        }
        out.flip()
        bus.push(id, tap, tap.size)
    }
}
