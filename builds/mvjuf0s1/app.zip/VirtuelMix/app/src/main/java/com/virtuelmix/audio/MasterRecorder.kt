package com.virtuelmix.audio

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.media.*
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import androidx.media3.common.*
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import kotlinx.coroutines.*
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*
import com.virtuelmix.data.*

class MasterRecorder(
    private val storage: RecordingStorage,
    private val bus: MixBus,
    private val sampleRate: Int = 44100,
    private val channels: Int = 2
) {
    @Volatile private var running = false
    private var thread: Thread? = null

    fun start() {
        if (running) return
        running = true
        thread = Thread {
            val target = storage.create()
            val channel = FileOutputStream(target.pfd.fileDescriptor).channel
            channel.write(ByteBuffer.wrap(wavHeader(0)))      // en-tête provisoire
            val frames = 1024
            val mixed = FloatArray(frames * channels)
            val bytes = ByteBuffer.allocate(frames * channels * 2).order(ByteOrder.LITTLE_ENDIAN)
            var dataLen = 0L

            while (running) {
                bus.pullMixed(mixed)                           // somme decks + micro
                bytes.clear()
                for (s in mixed) {
                    bytes.putShort((s.coerceIn(-1f, 1f) * 32767f).toInt().toShort())
                }
                bytes.flip()
                dataLen += channel.write(bytes)
                Thread.sleep(frames * 1000L / sampleRate)
            }
            channel.position(0)                                // corrige l'en-tête
            channel.write(ByteBuffer.wrap(wavHeader(dataLen)))
            channel.close(); target.pfd.close()
            storage.finish(target.uri)
        }.also { it.start() }
    }

    fun stop() { running = false; thread?.join() }

    private fun wavHeader(dataLen: Long): ByteArray {
        val byteRate = sampleRate * channels * 2
        return ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN).apply {
            put("RIFF".toByteArray()); putInt((36 + dataLen).toInt())
            put("WAVEfmt ".toByteArray()); putInt(16)
            putShort(1); putShort(channels.toShort())
            putInt(sampleRate); putInt(byteRate)
            putShort((channels * 2).toShort()); putShort(16)
            put("data".toByteArray()); putInt(dataLen.toInt())
        }.array()
    }
}
