package com.virtuelmix.audio

import android.content.Context
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import com.virtuelmix.data.PlaylistManager
import com.virtuelmix.data.RecordingStorage
import kotlinx.coroutines.CoroutineScope

class MixEngine(private val ctx: Context, scope: CoroutineScope) {
    val bus = MixBus()
    val ducker = Ducker()
    val procA = DeckProcessor("A", bus, ducker)
    val procB = DeckProcessor("B", bus, ducker)
    val deckA = newDeck(procA)
    val deckB = newDeck(procB)
    val playlist = PlaylistManager(deckA, procA, deckB, procB, scope)
    val recorder = MasterRecorder(RecordingStorage(ctx), bus)
    val mic = MicEngine(bus, ducker)

    private fun newDeck(p: DeckProcessor): ExoPlayer =
        ExoPlayer.Builder(ctx).setRenderersFactory(object : DefaultRenderersFactory(ctx) {
            override fun buildAudioSink(
                context: Context, enableFloatOutput: Boolean, enableAudioTrackPlaybackParams: Boolean
            ): AudioSink = DefaultAudioSink.Builder(context).setAudioProcessors(arrayOf(p)).build()
        }).build()

    fun setEq(p: DeckProcessor, preset: EqPreset) { p.preset = preset; p.eq()?.apply(preset) }

    fun release() { mic.stop(); recorder.stop(); deckA.release(); deckB.release() }
}
