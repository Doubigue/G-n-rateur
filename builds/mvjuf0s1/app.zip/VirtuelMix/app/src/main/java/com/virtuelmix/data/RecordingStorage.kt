package com.virtuelmix.data

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.media.*
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import androidx.media3.common.*
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import kotlinx.coroutines.*
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*
import com.virtuelmix.audio.*

class RecordingStorage(private val context: Context) {

    data class Target(val uri: Uri, val pfd: ParcelFileDescriptor)

    fun create(): Target {
        val name = "VirtuelMix_" +
            SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".wav"
        val resolver = context.contentResolver

        val values = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, name)
            put(MediaStore.Audio.Media.MIME_TYPE, "audio/wav")
            if (Build.VERSION.SDK_INT >= 29) {
                put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/Virtuelmix")
                put(MediaStore.Audio.Media.IS_PENDING, 1)
            } else {
                val dir = File(Environment.getExternalStorageDirectory(), "Virtuelmix")
                dir.mkdirs()
                @Suppress("DEPRECATION")
                put(MediaStore.Audio.Media.DATA, File(dir, name).absolutePath)
            }
        }
        val uri = resolver.insert(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values
        ) ?: error("MediaStore insert failed")
        val pfd = resolver.openFileDescriptor(uri, "rw") ?: error("open failed")
        return Target(uri, pfd)
    }

    fun finish(uri: Uri) {
        if (Build.VERSION.SDK_INT >= 29) {
            val v = ContentValues().apply { put(MediaStore.Audio.Media.IS_PENDING, 0) }
            context.contentResolver.update(uri, v, null, null)
        }
    }
}
