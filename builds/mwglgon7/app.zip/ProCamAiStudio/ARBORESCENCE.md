# Arborescence

```
ProCamAiStudio/
├── settings.gradle.kts · build.gradle.kts · gradle.properties · gradle/wrapper/gradle-wrapper.properties
└── app/
    ├── build.gradle.kts · proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── res/values/ (strings.xml, themes.xml)
        └── java/com/procam/studio/
            ├── ProCamApp.kt · MainActivity.kt
            ├── core/ (Result.kt, di/ServiceLocator.kt)
            ├── domain/
            │   ├── model/Models.kt            (presets, LUT, grilles, DTO d'analyse)
            │   └── usecase/StudioUseCases.kt
            ├── data/
            │   ├── ml/ (LocalSubjectSegmenter.kt : ML Kit général + repli ; BundledSelfieSegmenter.kt : Selfie embarqué ; U2NetSegmenter.kt : U²-Net embarqué)
            │   ├── (assets/u2netp.onnx : modèle tous sujets, 4,6 Mo)
            │   ├── remote/ (OpenAiApi.kt, OpenAiModels.kt, OpenAiClientFactory.kt)
            │   ├── local/ (SecureKeyStore.kt, SettingsDataStore.kt)
            │   ├── camera/ (ProCameraManager.kt, ManualControls.kt, CameraCapabilities.kt)
            │   ├── media/MediaStoreExporter.kt
            │   └── repository/OpenAiStudioRepository.kt
            ├── ui/
            │   ├── theme/Theme.kt
            │   ├── navigation/AppNavHost.kt
            │   ├── camera/ (CameraScreen.kt, CameraViewModel.kt, CameraOverlays.kt, ManualDial.kt)
            │   ├── studio/ (StudioScreen.kt, StudioViewModel.kt, BeforeAfterSlider.kt)
            │   └── settings/ (ApiKeyDialog.kt, ApiKeyViewModel.kt)
            └── imaging/   ── JAVA
                ├── ImageProcessorHelper.java  (PNG alpha, resize, crop, base64, formats)
                ├── BitmapUtils.java           (décodage échantillonné + EXIF)
                ├── FastFilters.java           (matrices couleur / LUT photo)
                └── LumaAnalyzer.java          (histogramme, focus peaking)
```

Hors `app/` : `branding/` (logo_512.png, make_logo.py), `tools/generate-keystore.sh`, `keystore.properties.example`.
