"""Régénère le logo : icônes vectorielles Android + branding/logo_512.png (même géométrie)."""
import math, os
from PIL import Image, ImageDraw
R='app/src/main/res/'
cx=cy=54; ring=25; hexr=10; spoke_end=21
def pt(r,a): return (cx+r*math.cos(math.radians(a)), cy+r*math.sin(math.radians(a)))
f=lambda p:f"{p[0]:.2f},{p[1]:.2f}"
hexv=[pt(hexr,60*k) for k in range(6)]
spokes=[(pt(hexr,60*k), pt(spoke_end,60*k+35)) for k in range(6)]
hexpath="M"+" L".join(f(p) for p in hexv)+" Z"
spokepath=" ".join(f"M{f(a)} L{f(b)}" for a,b in spokes)
ringpath=f"M{cx-ring},{cy} a{ring},{ring} 0 1,0 {2*ring},0 a{ring},{ring} 0 1,0 {-2*ring},0 Z"
sx,sy,s=74,34,8
spark=f"M{sx},{sy-s} L{sx+2.2},{sy-2.2} L{sx+s},{sy} L{sx+2.2},{sy+2.2} L{sx},{sy+s} L{sx-2.2},{sy+2.2} L{sx-s},{sy} L{sx-2.2},{sy-2.2} Z"
def vec(ring_c,spk_c,fill_c,spark_c,spark_stroke):
    st=f'android:strokeColor="{spark_stroke}" android:strokeWidth="2"' if spark_stroke else ''
    return f'''<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp" android:height="108dp"
    android:viewportWidth="108" android:viewportHeight="108">
    <path android:pathData="{ringpath}" android:strokeColor="{ring_c}" android:strokeWidth="4.5" android:fillColor="#00000000"/>
    <path android:pathData="{spokepath}" android:strokeColor="{spk_c}" android:strokeWidth="3.5" android:strokeLineCap="round" android:fillColor="#00000000"/>
    <path android:pathData="{hexpath}" android:strokeColor="{spk_c}" android:strokeWidth="2" android:strokeLineJoin="round" android:fillColor="{fill_c}"/>
    <path android:pathData="{spark}" android:fillColor="{spark_c}" {st}/>
</vector>
'''
open(R+'drawable/ic_launcher_foreground.xml','w').write(vec('#ECECEC','#FFB300','#FFB300','#FFB300','#121214'))
open(R+'drawable/ic_launcher_monochrome.xml','w').write(vec('#000000','#000000','#000000','#000000',None))
S=4; N=512*S; k=N/108
im=Image.new('RGB',(N,N),(10,10,12)); d=ImageDraw.Draw(im)
for i in range(60,0,-1):
    r=N*0.70*i/60; c=int(10+32*(1-i/60)); d.ellipse((N/2-r,N/2-r,N/2+r,N/2+r),fill=(c,c,c+2))
P=lambda p:(p[0]*k,p[1]*k)
d.ellipse(((cx-ring)*k,(cy-ring)*k,(cx+ring)*k,(cy+ring)*k),outline=(236,236,236),width=int(4.5*k))
for a,b in spokes:
    d.line([P(a),P(b)],fill=(255,179,0),width=int(3.5*k))
    for q in (a,b): d.ellipse((q[0]*k-1.75*k,q[1]*k-1.75*k,q[0]*k+1.75*k,q[1]*k+1.75*k),fill=(255,179,0))
d.polygon([P(p) for p in hexv],fill=(255,179,0))
sp=[(sx,sy-s),(sx+2.2,sy-2.2),(sx+s,sy),(sx+2.2,sy+2.2),(sx,sy+s),(sx-2.2,sy+2.2),(sx-s,sy),(sx-2.2,sy-2.2)]
big=[(sx+(x-sx)*1.25,sy+(y-sy)*1.25) for x,y in sp]
d.polygon([P(p) for p in big],fill=(18,18,20))
d.polygon([P(p) for p in sp],fill=(255,179,0))
im.resize((512,512),Image.LANCZOS).save('branding/logo_512.png')
