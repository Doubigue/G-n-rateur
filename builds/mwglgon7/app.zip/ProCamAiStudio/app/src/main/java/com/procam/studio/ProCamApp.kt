package com.procam.studio

import android.app.Application
import com.procam.studio.core.di.ServiceLocator

class ProCamApp : Application() {
    lateinit var locator: ServiceLocator
        private set

    override fun onCreate() {
        super.onCreate()
        locator = ServiceLocator(this)
    }
}
