package com.procam.studio.core

sealed class AppError(val userMessage: String) {
    object MissingKey : AppError("Aucune clé API configurée. Ouvrez les réglages (⚙) pour en ajouter une.")
    object InvalidKey : AppError("Clé API invalide ou révoquée. Vérifiez qu'elle commence par « sk- ».")
    object QuotaExceeded : AppError("Quota dépassé ou crédits insuffisants sur votre compte OpenAI.")
    object RateLimited : AppError("Trop de requêtes. Patientez quelques secondes puis réessayez.")
    object NoNetwork : AppError("Pas de connexion réseau. Vérifiez votre Wi-Fi ou vos données mobiles.")
    object Timeout : AppError("Le serveur met trop de temps à répondre. Réessayez.")
    object ModelUnavailable : AppError(
        "Modèle de détourage local indisponible. Connectez-vous une première fois pour le télécharger " +
            "(Google Play Services requis) ou utilisez le mode Cloud."
    )
    class Forbidden(detail: String) : AppError("Accès refusé : $detail")
    class BadRequest(detail: String) : AppError("Requête refusée par OpenAI : $detail")
    class Server(code: Int) : AppError("Erreur serveur OpenAI ($code). Réessayez plus tard.")
    class Unknown(detail: String) : AppError("Erreur inattendue : $detail")
}

sealed class AppResult<out T> {
    data class Success<out T>(val data: T) : AppResult<T>()
    data class Failure(val error: AppError) : AppResult<Nothing>()
}

inline fun <T, R> AppResult<T>.map(transform: (T) -> R): AppResult<R> = when (this) {
    is AppResult.Success -> AppResult.Success(transform(data))
    is AppResult.Failure -> this
}
