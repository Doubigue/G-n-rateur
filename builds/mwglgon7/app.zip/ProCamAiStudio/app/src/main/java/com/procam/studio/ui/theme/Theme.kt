package com.procam.studio.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val CineBlack = Color(0xFF000000)
val CineSurface = Color(0xFF121214)
val CineSurfaceHigh = Color(0xFF1E1E22)
val CineAccent = Color(0xFFFFB300)
val CineRec = Color(0xFFE53935)
val CineText = Color(0xFFECECEC)
val CineMuted = Color(0xFF8E8E96)

private val Scheme = darkColorScheme(
    primary = CineAccent,
    onPrimary = Color.Black,
    secondary = CineAccent,
    background = CineBlack,
    surface = CineSurface,
    surfaceVariant = CineSurfaceHigh,
    onBackground = CineText,
    onSurface = CineText,
    onSurfaceVariant = CineMuted,
    error = CineRec
)

private val Type = Typography(
    labelSmall = TextStyle(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Medium, fontSize = 11.sp),
    labelMedium = TextStyle(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Medium, fontSize = 12.sp),
    bodyMedium = TextStyle(fontSize = 14.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
)

@Composable
fun ProCamTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, typography = Type, content = content)
}
