package com.procam.studio.data.remote

import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part

interface OpenAiApi {

    /** Test de connexion : l'en-tête Authorization explicite permet de tester une clé non encore enregistrée. */
    @GET("v1/models")
    suspend fun listModels(@Header("Authorization") authorization: String?): Response<ModelsResponse>

    @POST("v1/chat/completions")
    suspend fun chat(@Body request: ChatRequest): Response<ChatResponse>

    /** Édition d'image gpt-image-1 en multipart/form-data. */
    @Multipart
    @POST("v1/images/edits")
    suspend fun editImage(
        @Part image: MultipartBody.Part,
        @Part("prompt") prompt: RequestBody,
        @Part("model") model: RequestBody,
        @Part("size") size: RequestBody,
        @Part("quality") quality: RequestBody,
        @Part("output_format") outputFormat: RequestBody,
        @Part("background") background: RequestBody?
    ): Response<ImageEditResponse>
}
