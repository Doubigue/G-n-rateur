package com.procam.studio.core.di

import android.app.Application
import android.graphics.Bitmap
import com.procam.studio.data.local.SecureKeyStore
import com.procam.studio.data.local.SettingsDataStore
import com.procam.studio.data.media.MediaStoreExporter
import com.procam.studio.data.ml.LocalSubjectSegmenter
import com.procam.studio.data.remote.OpenAiClientFactory
import com.procam.studio.data.repository.OpenAiStudioRepository
import com.procam.studio.domain.usecase.AnalyzePhotoUseCase
import com.procam.studio.domain.usecase.ApplyPresetUseCase
import com.procam.studio.domain.usecase.EnhancePromptUseCase
import com.procam.studio.domain.usecase.LocalCutoutUseCase
import com.procam.studio.domain.usecase.VerifyApiKeyUseCase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.serialization.json.Json

/** Photo en cours d'édition, partagée entre l'écran caméra et le Studio IA. */
class StudioSession {
    val original = MutableStateFlow<Bitmap?>(null)
}

/** Injection de dépendances manuelle (sans Hilt) pour garder le projet autonome. */
class ServiceLocator(app: Application) {
    val json = Json { ignoreUnknownKeys = true }
    val keyStore: SecureKeyStore by lazy { SecureKeyStore(app) }
    val settings = SettingsDataStore(app)
    val exporter = MediaStoreExporter(app)
    val session = StudioSession()

    private val api by lazy { OpenAiClientFactory.create(json) { keyStore.get() } }
    val repository: OpenAiStudioRepository by lazy { OpenAiStudioRepository(keyStore, api, json) }

    val localSegmenter by lazy { LocalSubjectSegmenter(app) }
    val localCutout by lazy { LocalCutoutUseCase(localSegmenter) }
    val verifyApiKey by lazy { VerifyApiKeyUseCase(repository) }
    val applyPreset by lazy { ApplyPresetUseCase(repository) }
    val enhancePrompt by lazy { EnhancePromptUseCase(repository) }
    val analyzePhoto by lazy { AnalyzePhotoUseCase(repository) }
}
