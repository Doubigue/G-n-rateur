package com.procam.studio.data.ml

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.graphics.Bitmap
import java.nio.FloatBuffer

/**
 * Détourage TOUS SUJETS (objets, animaux, produits, personnes) avec U²-Net-P (Apache-2.0, ~4,6 Mo),
 * embarqué dans l'APK (assets/u2netp.onnx) et exécuté par ONNX Runtime : aucun réseau, aucun Play Services.
 *
 * Pré-traitement identique à rembg (vérifié) : 320×320, valeurs / max, normalisation ImageNet, NCHW.
 * Sortie : probabilité 0..1 (sigmoïde déjà appliquée) ; première sortie = masque final.
 */
class U2NetSegmenter(private val context: Context) {

    private companion object {
        const val SIZE = 320
        const val ASSET = "u2netp.onnx"
        val MEAN = floatArrayOf(0.485f, 0.456f, 0.406f)
        val STD = floatArrayOf(0.229f, 0.224f, 0.225f)
    }

    private val env: OrtEnvironment by lazy { OrtEnvironment.getEnvironment() }

    private val session: OrtSession by lazy {
        val bytes = context.assets.open(ASSET).use { it.readBytes() }
        val options = OrtSession.SessionOptions().apply {
            setIntraOpNumThreads(Runtime.getRuntime().availableProcessors().coerceIn(2, 4))
        }
        env.createSession(bytes, options)
    }

    /** Renvoie une Bitmap ARGB_8888 de la taille de l'entrée dont l'alpha est le masque ; null si aucun sujet. */
    fun segment(bitmap: Bitmap): Bitmap? {
        val scaled = Bitmap.createScaledBitmap(bitmap, SIZE, SIZE, true)
        val px = IntArray(SIZE * SIZE)
        scaled.getPixels(px, 0, SIZE, 0, 0, SIZE, SIZE)
        if (scaled !== bitmap) scaled.recycle()

        var maxVal = 1f
        for (p in px) {
            maxVal = maxOf(maxVal, ((p shr 16) and 0xFF).toFloat(), ((p shr 8) and 0xFF).toFloat(), (p and 0xFF).toFloat())
        }
        val plane = SIZE * SIZE
        val data = FloatArray(3 * plane)
        for (i in 0 until plane) {
            val p = px[i]
            data[i] = (((p shr 16) and 0xFF) / maxVal - MEAN[0]) / STD[0]
            data[plane + i] = (((p shr 8) and 0xFF) / maxVal - MEAN[1]) / STD[1]
            data[2 * plane + i] = ((p and 0xFF) / maxVal - MEAN[2]) / STD[2]
        }

        val inputName = session.inputNames.first()
        val mask = FloatArray(plane)
        OnnxTensor.createTensor(env, FloatBuffer.wrap(data), longArrayOf(1, 3, SIZE.toLong(), SIZE.toLong())).use { input ->
            session.run(mapOf(inputName to input)).use { result ->
                @Suppress("UNCHECKED_CAST")
                val out = result[0].value as Array<Array<Array<FloatArray>>> // [1][1][320][320]
                val m = out[0][0]
                for (y in 0 until SIZE) System.arraycopy(m[y], 0, mask, y * SIZE, SIZE)
            }
        }

        var lo = Float.MAX_VALUE
        var hi = -Float.MAX_VALUE
        for (v in mask) { if (v < lo) lo = v; if (v > hi) hi = v }
        val range = (hi - lo).coerceAtLeast(1e-6f)
        val alpha = IntArray(plane)
        var covered = 0
        for (i in 0 until plane) {
            val n = (mask[i] - lo) / range
            // smoothstep 0.15 → 0.85 : retire le voile, garde des bords doux
            val t = ((n - 0.15f) / 0.70f).coerceIn(0f, 1f)
            val a = (t * t * (3f - 2f * t) * 255f).toInt()
            if (a > 128) covered++
            alpha[i] = a shl 24
        }
        if (covered < plane * 0.005f) return null

        val low = Bitmap.createBitmap(alpha, SIZE, SIZE, Bitmap.Config.ARGB_8888)
        val full = Bitmap.createScaledBitmap(low, bitmap.width, bitmap.height, true)
        if (full !== low) low.recycle()
        return full
    }
}
