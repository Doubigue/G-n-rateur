package com.procam.studio.domain.usecase

import android.graphics.Bitmap
import com.procam.studio.core.AppError
import com.procam.studio.core.AppResult
import com.procam.studio.data.ml.LocalSubjectSegmenter
import com.procam.studio.data.repository.OpenAiStudioRepository
import com.procam.studio.domain.model.AiPreset
import com.procam.studio.domain.model.LocalEngine
import com.procam.studio.domain.model.PhotoAnalysis

class VerifyApiKeyUseCase(private val repo: OpenAiStudioRepository) {
    suspend operator fun invoke(key: String): AppResult<Unit> = repo.verifyConnection(key)
}

class EnhancePromptUseCase(private val repo: OpenAiStudioRepository) {
    suspend operator fun invoke(idea: String): AppResult<String> {
        if (idea.isBlank()) return AppResult.Failure(AppError.BadRequest("Écrivez d'abord une idée à améliorer."))
        return repo.enhancePrompt(idea.trim())
    }
}

class AnalyzePhotoUseCase(private val repo: OpenAiStudioRepository) {
    suspend operator fun invoke(photo: Bitmap): AppResult<PhotoAnalysis> = repo.analyzePhoto(photo)
}

class ApplyPresetUseCase(private val repo: OpenAiStudioRepository) {
    suspend operator fun invoke(photo: Bitmap, preset: AiPreset, userPrompt: String): AppResult<Bitmap> {
        val extra = userPrompt.trim()
        val prompt = when {
            preset == AiPreset.CUSTOM && extra.isEmpty() ->
                return AppResult.Failure(AppError.BadRequest("Saisissez un prompt pour le mode libre."))
            preset == AiPreset.CUSTOM -> extra
            extra.isEmpty() -> preset.prompt
            else -> "${preset.prompt} Additional instructions: $extra"
        }
        return repo.editImage(photo, prompt, preset.transparent)
    }
}

/** Détourage PNG transparent / fond blanc 100 % local : gratuit, sans clé API, sans envoi de la photo. */
class LocalCutoutUseCase(private val segmenter: LocalSubjectSegmenter) {
    suspend operator fun invoke(photo: Bitmap, preset: AiPreset, engine: LocalEngine = LocalEngine.AUTO): AppResult<Bitmap> = when (preset) {
        AiPreset.TRANSPARENT_PNG -> segmenter.cutoutTransparent(photo, engine)
        AiPreset.WHITE_BACKGROUND -> segmenter.cutoutOnWhite(photo, engine)
        else -> AppResult.Failure(AppError.BadRequest("Ce preset nécessite le mode Cloud."))
    }
}
