package com.procam.studio.domain.model

import android.graphics.ColorMatrix
import kotlinx.serialization.Serializable

/**
 * Moteur de détourage local.
 * AUTO : Google (Play Services, meilleure qualité) puis repli sur U²-Net embarqué ;
 * BUNDLED_GENERAL : U²-Net embarqué (tous sujets, 100 % hors-ligne) ;
 * BUNDLED_PEOPLE : Selfie Segmentation embarqué (personnes, rapide, 100 % hors-ligne).
 */
enum class LocalEngine(val label: String) {
    AUTO("Auto"),
    BUNDLED_GENERAL("Intégré · tous sujets"),
    BUNDLED_PEOPLE("Intégré · personnes")
}

/** Moteur réellement utilisé lors du dernier détourage. */
enum class LocalBackend { GOOGLE_PLAY, U2NET, SELFIE }

enum class CaptureMode { PHOTO, VIDEO }

enum class VideoResolution(val label: String) { FHD("1080p"), UHD("4K") }

enum class GridType(val label: String) { NONE("Grille: Off"), THIRDS("Tiers"), CENTER("Centre") }

/** Cadre de composition. ratio = largeur/hauteur de l'image finale (null = format natif). */
enum class AspectGuide(val label: String, val ratio: Float?) {
    NATIVE("Natif", null),
    R16_9("16:9", 16f / 9f),
    R9_16("9:16", 9f / 16f),
    CINEMA("2.39:1", 2.39f)
}

/** Profils colorimétriques appliqués en temps réel à l'aperçu (GPU) et incrustés dans les photos. */
enum class LutProfile(val label: String) {
    NONE("LUT: Off"),
    TEAL_ORANGE("Teal & Orange"),
    LOG_FLAT("Log / Flat"),
    BW_CONTRAST("N&B contrasté"),
    STUDIO_WARM("Studio chaud");

    fun colorMatrix(): ColorMatrix = when (this) {
        NONE -> ColorMatrix()
        TEAL_ORANGE -> ColorMatrix(
            floatArrayOf(
                1.15f, 0f, -0.05f, 0f, -6f,
                -0.02f, 1.00f, 0.06f, 0f, 0f,
                -0.12f, 0.10f, 1.12f, 0f, 8f,
                0f, 0f, 0f, 1f, 0f
            )
        ).also { it.postConcat(contrast(1.08f)) }
        LOG_FLAT -> ColorMatrix().also {
            it.setSaturation(0.72f)
            it.postConcat(contrast(0.68f))
        }
        BW_CONTRAST -> ColorMatrix().also {
            it.setSaturation(0f)
            it.postConcat(contrast(1.35f))
        }
        STUDIO_WARM -> ColorMatrix(
            floatArrayOf(
                1.08f, 0.02f, 0f, 0f, 4f,
                0f, 1.02f, 0f, 0f, 0f,
                0f, 0f, 0.90f, 0f, -4f,
                0f, 0f, 0f, 1f, 0f
            )
        ).also { it.postConcat(contrast(1.05f)) }
    }

    private fun contrast(c: Float): ColorMatrix {
        val t = (1f - c) * 127.5f
        return ColorMatrix(
            floatArrayOf(
                c, 0f, 0f, 0f, t,
                0f, c, 0f, 0f, t,
                0f, 0f, c, 0f, t,
                0f, 0f, 0f, 1f, 0f
            )
        )
    }
}

enum class AiPreset(val label: String, val prompt: String, val transparent: Boolean) {
    PORTRAIT_STUDIO(
        "Portrait Studio",
        "Retouch this photo into a professional studio portrait: soft flattering key light with gentle fill, " +
            "natural skin texture with subtle blemish cleanup (no plastic smoothing), cinematic shallow depth of " +
            "field with creamy bokeh, balanced editorial color grading. Keep the subject's identity, facial " +
            "features, pose, clothing and composition exactly the same.",
        false
    ),
    CINEMATIC(
        "Cinématographique",
        "Apply a 35mm film cinematic grade: deep shadows, rich contrast, subtle film grain, teal and orange " +
            "palette, anamorphic horizontal lens flares on highlights, dramatic moody atmosphere. Keep the " +
            "subject, identity and composition unchanged.",
        false
    ),
    WHITE_BACKGROUND(
        "Fond blanc pur",
        "Precisely cut out the main subject with clean edges (preserve hair and fine details) and place it on a " +
            "pure white #FFFFFF seamless background with a soft, realistic contact shadow beneath it. Even " +
            "catalog / e-commerce lighting. Do not alter the subject's colors, shape or details.",
        false
    ),
    TRANSPARENT_PNG(
        "PNG transparent",
        "Precisely isolate the main subject with clean high-precision edges, preserving hair and fine details, " +
            "and remove the entire background so that it is fully transparent. Do not alter the subject's " +
            "colors, shape or details, and add no shadow or border.",
        true
    ),
    CUSTOM("Prompt libre", "", false);

    /** Détourage et fond blanc peuvent être faits sur l'appareil (ML Kit), sans API. */
    val supportsLocal: Boolean get() = this == WHITE_BACKGROUND || this == TRANSPARENT_PNG
}

@Serializable
data class Suggestion(val title: String = "", val prompt: String = "")

@Serializable
data class PhotoAnalysis(val summary: String = "", val suggestions: List<Suggestion> = emptyList())
