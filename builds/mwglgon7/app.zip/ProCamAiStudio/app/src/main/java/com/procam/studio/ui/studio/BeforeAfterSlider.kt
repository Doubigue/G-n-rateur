package com.procam.studio.ui.studio

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp

/** Damier pour visualiser la transparence (PNG détouré). */
private fun Modifier.checkerboard(): Modifier = drawBehind {
    val cell = 18.dp.toPx()
    drawRect(Color(0xFF2B2B2B))
    var y = 0f
    var row = 0
    while (y < size.height) {
        var x = if (row % 2 == 0) 0f else cell
        while (x < size.width) {
            drawRect(Color(0xFF3C3C3C), Offset(x, y), Size(cell, cell))
            x += cell * 2
        }
        y += cell
        row++
    }
}

/** Comparateur avant / après : le curseur découvre l'original (gauche) sur le résultat IA (droite). */
@Composable
fun BeforeAfterSlider(before: Bitmap, after: Bitmap, modifier: Modifier = Modifier) {
    var fraction by remember { mutableFloatStateOf(0.5f) }
    val ratio = before.width.toFloat() / before.height.toFloat()

    Box(
        modifier
            .fillMaxWidth()
            .aspectRatio(ratio)
            .clip(RoundedCornerShape(12.dp))
            .checkerboard()
            .pointerInput(Unit) {
                detectHorizontalDragGestures { change, drag ->
                    change.consume()
                    fraction = (fraction + drag / size.width).coerceIn(0f, 1f)
                }
            }
    ) {
        Image(
            bitmap = after.asImageBitmap(),
            contentDescription = "Résultat IA",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Image(
            bitmap = before.asImageBitmap(),
            contentDescription = "Original",
            modifier = Modifier
                .fillMaxSize()
                .drawWithContent {
                    clipRect(right = size.width * fraction) {
                        this@drawWithContent.drawContent()
                    }
                },
            contentScale = ContentScale.Crop
        )
        // Poignée + ligne de séparation
        Box(
            Modifier
                .fillMaxSize()
                .drawBehind {
                    val x = size.width * fraction
                    drawLine(Color.White, Offset(x, 0f), Offset(x, size.height), 3f)
                    drawCircle(Color.White, 18.dp.toPx(), Offset(x, size.height / 2f))
                    drawCircle(Color.Black, 14.dp.toPx(), Offset(x, size.height / 2f))
                    drawLine(Color.White, Offset(x - 6.dp.toPx(), size.height / 2f), Offset(x + 6.dp.toPx(), size.height / 2f), 3f)
                }
        )
        Label("AVANT", Modifier.align(Alignment.TopStart))
        Label("APRÈS", Modifier.align(Alignment.TopEnd))
    }
}

@Composable
private fun Label(text: String, modifier: Modifier) {
    Text(
        text,
        modifier = modifier
            .padding(8.dp)
            .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp),
        color = Color.White,
        style = MaterialTheme.typography.labelSmall
    )
}
