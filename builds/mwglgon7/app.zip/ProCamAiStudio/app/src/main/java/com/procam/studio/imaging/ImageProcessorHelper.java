package com.procam.studio.imaging;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.Base64;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;

/**
 * Moteur de traitement d'image bas niveau : conversion de formats, redimensionnement,
 * recadrage, export PNG avec canal alpha (ARGB_8888), base64.
 */
public final class ImageProcessorHelper {

    private ImageProcessorHelper() { }

    /** Garantit une Bitmap logicielle ARGB_8888 (nécessaire pour l'alpha et les opérations Canvas). */
    public static Bitmap ensureArgb8888(Bitmap src) {
        if (src.getConfig() == Bitmap.Config.ARGB_8888) {
            return src;
        }
        Bitmap copy = src.copy(Bitmap.Config.ARGB_8888, false);
        if (copy == null) {
            throw new IllegalStateException("Impossible de convertir la bitmap en ARGB_8888");
        }
        return copy;
    }

    /** Réduit l'image pour que son plus grand côté ne dépasse pas maxSide (conserve le ratio). */
    public static Bitmap scaleToMaxSide(Bitmap src, int maxSide) {
        int w = src.getWidth();
        int h = src.getHeight();
        int longest = Math.max(w, h);
        if (longest <= maxSide) {
            return src;
        }
        float scale = (float) maxSide / (float) longest;
        int nw = Math.max(1, Math.round(w * scale));
        int nh = Math.max(1, Math.round(h * scale));
        return Bitmap.createScaledBitmap(src, nw, nh, true);
    }

    /** Rotation en degrés (multiples de 90 typiquement). */
    public static Bitmap rotate(Bitmap src, int degrees) {
        int d = ((degrees % 360) + 360) % 360;
        if (d == 0) {
            return src;
        }
        Matrix m = new Matrix();
        m.postRotate(d);
        return Bitmap.createBitmap(src, 0, 0, src.getWidth(), src.getHeight(), m, true);
    }

    /** Recadre au centre pour obtenir le ratio largeur/hauteur demandé. */
    public static Bitmap cropToAspect(Bitmap src, float targetRatio) {
        if (targetRatio <= 0f) {
            return src;
        }
        int w = src.getWidth();
        int h = src.getHeight();
        float current = (float) w / (float) h;
        if (Math.abs(current - targetRatio) < 0.005f) {
            return src;
        }
        int cw = w;
        int ch = h;
        if (current > targetRatio) {
            cw = Math.round(h * targetRatio);
        } else {
            ch = Math.round(w / targetRatio);
        }
        int x = (w - cw) / 2;
        int y = (h - ch) / 2;
        return Bitmap.createBitmap(src, x, y, cw, ch);
    }

    /** Applique la couleur de fond (ex: blanc) sous une image potentiellement transparente. */
    public static Bitmap compositeOnColor(Bitmap src, int color) {
        Bitmap out = Bitmap.createBitmap(src.getWidth(), src.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(out);
        canvas.drawColor(color);
        canvas.drawBitmap(src, 0f, 0f, null);
        return out;
    }

    /** Vrai si au moins un pixel échantillonné n'est pas totalement opaque. */
    public static boolean hasTransparentPixels(Bitmap src) {
        if (!src.hasAlpha()) {
            return false;
        }
        Bitmap s = ensureArgb8888(src);
        int w = s.getWidth();
        int h = s.getHeight();
        int stepY = Math.max(1, h / 128);
        int stepX = Math.max(1, w / 128);
        int[] row = new int[w];
        for (int y = 0; y < h; y += stepY) {
            s.getPixels(row, 0, w, 0, y, w, 1);
            for (int x = 0; x < w; x += stepX) {
                if ((row[x] >>> 24) < 250) {
                    return true;
                }
            }
        }
        return false;
    }

    /** Rogne la bitmap à la boîte englobante des pixels non transparents (+ marge). */
    public static Bitmap trimTransparentBounds(Bitmap src, int padding) {
        Bitmap s = ensureArgb8888(src);
        int w = s.getWidth();
        int h = s.getHeight();
        int minX = w, minY = h, maxX = -1, maxY = -1;
        int[] row = new int[w];
        for (int y = 0; y < h; y++) {
            s.getPixels(row, 0, w, 0, y, w, 1);
            for (int x = 0; x < w; x++) {
                if ((row[x] >>> 24) > 8) {
                    if (x < minX) minX = x;
                    if (x > maxX) maxX = x;
                    if (y < minY) minY = y;
                    if (y > maxY) maxY = y;
                }
            }
        }
        if (maxX < 0) {
            return s;
        }
        minX = Math.max(0, minX - padding);
        minY = Math.max(0, minY - padding);
        maxX = Math.min(w - 1, maxX + padding);
        maxY = Math.min(h - 1, maxY + padding);
        return Bitmap.createBitmap(s, minX, minY, maxX - minX + 1, maxY - minY + 1);
    }


    /**
     * Applique le canal alpha d'un détourage (potentiellement basse résolution) à l'image d'origine
     * pleine résolution : le sujet garde tous ses détails, le fond devient transparent (ARGB_8888).
     */
    public static Bitmap applyMaskFromForeground(Bitmap original, Bitmap foreground) {
        Bitmap src = ensureArgb8888(original);
        Bitmap out = Bitmap.createBitmap(src.getWidth(), src.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(out);
        canvas.drawBitmap(src, 0f, 0f, null);
        Bitmap alpha = ensureArgb8888(foreground).extractAlpha();
        Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        canvas.drawBitmap(alpha, null, new Rect(0, 0, out.getWidth(), out.getHeight()), paint);
        alpha.recycle();
        return out;
    }

    /** Pose un sujet détouré sur fond blanc pur #FFFFFF avec une ombre de contact douce. */
    public static Bitmap compositeOnWhiteWithShadow(Bitmap cutout) {
        Bitmap s = ensureArgb8888(cutout);
        Bitmap out = Bitmap.createBitmap(s.getWidth(), s.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(out);
        canvas.drawColor(0xFFFFFFFF);

        int[] box = alphaBounds(s, 16);
        if (box != null) {
            float bw = box[2] - box[0];
            float bh = box[3] - box[1];
            float cx = (box[0] + box[2]) / 2f;
            float baseY = box[3];
            float blur = Math.max(6f, bw * 0.035f);

            Paint shadow = new Paint(Paint.ANTI_ALIAS_FLAG);
            shadow.setColor(0x73000000);
            shadow.setMaskFilter(new BlurMaskFilter(blur, BlurMaskFilter.Blur.NORMAL));
            // Ombre de contact : ellipse plate sous la base du sujet.
            canvas.drawOval(new RectF(cx - bw * 0.40f, baseY - bh * 0.018f,
                    cx + bw * 0.40f, baseY + bh * 0.03f), shadow);

            // Ombre diffuse légère dérivée de la silhouette.
            Paint soft = new Paint(Paint.ANTI_ALIAS_FLAG);
            soft.setMaskFilter(new BlurMaskFilter(blur * 2f, BlurMaskFilter.Blur.NORMAL));
            int[] offset = new int[2];
            Bitmap silhouette = s.extractAlpha(soft, offset);
            Paint tint = new Paint(Paint.ANTI_ALIAS_FLAG);
            tint.setColor(0x24000000);
            canvas.drawBitmap(silhouette, offset[0], offset[1] + bh * 0.012f, tint);
            silhouette.recycle();
        }
        canvas.drawBitmap(s, 0f, 0f, null);
        return out;
    }

    /** Boîte englobante {minX, minY, maxX, maxY} des pixels dont l'alpha dépasse le seuil, ou null. */
    private static int[] alphaBounds(Bitmap s, int threshold) {
        int w = s.getWidth();
        int h = s.getHeight();
        int minX = w, minY = h, maxX = -1, maxY = -1;
        int[] row = new int[w];
        for (int y = 0; y < h; y++) {
            s.getPixels(row, 0, w, 0, y, w, 1);
            for (int x = 0; x < w; x++) {
                if ((row[x] >>> 24) > threshold) {
                    if (x < minX) minX = x;
                    if (x > maxX) maxX = x;
                    if (y < minY) minY = y;
                    if (y > maxY) maxY = y;
                }
            }
        }
        return maxX < 0 ? null : new int[]{minX, minY, maxX, maxY};
    }

    /** Encode en PNG (alpha conservé). */
    public static byte[] toPngBytes(Bitmap src) {
        ByteArrayOutputStream out = new ByteArrayOutputStream(1 << 20);
        ensureArgb8888(src).compress(Bitmap.CompressFormat.PNG, 100, out);
        return out.toByteArray();
    }

    /** Encode en JPEG ; si l'image a de la transparence, elle est aplatie sur fond blanc. */
    public static byte[] toJpegBytes(Bitmap src, int quality) {
        Bitmap s = ensureArgb8888(src);
        if (s.hasAlpha()) {
            s = compositeOnColor(s, 0xFFFFFFFF);
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream(1 << 20);
        s.compress(Bitmap.CompressFormat.JPEG, quality, out);
        return out.toByteArray();
    }

    /** JPEG redimensionné encodé en Base64 sans retour à la ligne (pour GPT-4o Vision). */
    public static String toBase64Jpeg(Bitmap src, int maxSide, int quality) {
        Bitmap scaled = scaleToMaxSide(src, maxSide);
        return Base64.encodeToString(toJpegBytes(scaled, quality), Base64.NO_WRAP);
    }

    /** Décode une image Base64 (PNG/JPEG/WebP) en ARGB_8888. */
    public static Bitmap decodeBase64ToBitmap(String base64) throws IOException {
        byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
        Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length, opts);
        if (bmp == null) {
            throw new IOException("Image renvoyée illisible");
        }
        return bmp;
    }

    /** Écrit un PNG avec canal alpha dans le flux fourni. */
    public static boolean writePng(Bitmap src, OutputStream out) {
        return ensureArgb8888(src).compress(Bitmap.CompressFormat.PNG, 100, out);
    }

    /** Écrit un JPEG dans le flux fourni. */
    public static boolean writeJpeg(Bitmap src, int quality, OutputStream out) {
        Bitmap s = ensureArgb8888(src);
        if (s.hasAlpha()) {
            s = compositeOnColor(s, 0xFFFFFFFF);
        }
        return s.compress(Bitmap.CompressFormat.JPEG, quality, out);
    }

    /** Détection du format via les "magic bytes". */
    public static String detectFormat(byte[] data) {
        if (data == null || data.length < 12) {
            return "unknown";
        }
        if ((data[0] & 0xFF) == 0x89 && data[1] == 'P' && data[2] == 'N' && data[3] == 'G') {
            return "png";
        }
        if ((data[0] & 0xFF) == 0xFF && (data[1] & 0xFF) == 0xD8) {
            return "jpeg";
        }
        if (data[0] == 'R' && data[1] == 'I' && data[2] == 'F' && data[3] == 'F'
                && data[8] == 'W' && data[9] == 'E' && data[10] == 'B' && data[11] == 'P') {
            return "webp";
        }
        return "unknown";
    }
}
