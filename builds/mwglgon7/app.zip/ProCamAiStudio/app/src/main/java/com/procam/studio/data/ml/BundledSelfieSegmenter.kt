package com.procam.studio.data.ml

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import kotlinx.coroutines.tasks.await

/**
 * Détourage de PERSONNES avec le modèle ML Kit Selfie Segmentation, lié à l'APK au build :
 * aucun téléchargement, aucun Play Services requis, fonctionne dès le premier lancement en mode avion.
 * Limite : ne reconnaît que les personnes (pas les objets/animaux).
 */
class BundledSelfieSegmenter {

    private val segmenter by lazy {
        Segmentation.getClient(
            SelfieSegmenterOptions.Builder()
                .setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE)
                .build()
        )
    }

    /** Renvoie une Bitmap ARGB_8888 de la taille de l'entrée dont l'alpha est le masque ; null si personne. */
    suspend fun segment(bitmap: Bitmap): Bitmap? {
        val mask = segmenter.process(InputImage.fromBitmap(bitmap, 0)).await()
        val w = mask.width
        val h = mask.height
        val buf = mask.buffer
        buf.rewind()
        val pixels = IntArray(w * h)
        var covered = 0
        for (i in pixels.indices) {
            val c = buf.float
            // smoothstep 0.30 → 0.70 : bords plus nets, sans escalier
            val t = ((c - 0.30f) / 0.40f).coerceIn(0f, 1f)
            val a = (t * t * (3f - 2f * t) * 255f).toInt()
            if (a > 128) covered++
            pixels[i] = a shl 24
        }
        if (covered < pixels.size * 0.002f) return null
        return Bitmap.createBitmap(pixels, w, h, Bitmap.Config.ARGB_8888)
    }
}
