package com.procam.studio.ui.settings

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.procam.studio.ProCamApp
import com.procam.studio.core.AppResult
import com.procam.studio.data.local.SecureKeyStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed class KeyStatus {
    object Idle : KeyStatus()
    object Checking : KeyStatus()
    object Valid : KeyStatus()
    class Error(val message: String) : KeyStatus()
}

data class ApiKeyUiState(
    val input: String = "",
    val savedMasked: String? = null,
    val status: KeyStatus = KeyStatus.Idle,
    val info: String? = null
)

class ApiKeyViewModel(app: Application) : AndroidViewModel(app) {
    private val locator = (app as ProCamApp).locator
    private val _ui = MutableStateFlow(ApiKeyUiState())
    val ui: StateFlow<ApiKeyUiState> = _ui.asStateFlow()

    init { refreshSaved() }

    private fun refreshSaved() {
        _ui.update { it.copy(savedMasked = locator.keyStore.get()?.let(SecureKeyStore::mask)) }
    }

    fun onInput(value: String) {
        _ui.update { it.copy(input = value, status = KeyStatus.Idle, info = null) }
    }

    /** Teste la clé saisie (ou, à défaut, la clé déjà enregistrée). */
    fun verify() {
        val candidate = _ui.value.input.ifBlank { locator.keyStore.get().orEmpty() }
        _ui.update { it.copy(status = KeyStatus.Checking, info = null) }
        viewModelScope.launch {
            val status = when (val r = locator.verifyApiKey(candidate)) {
                is AppResult.Success -> KeyStatus.Valid
                is AppResult.Failure -> KeyStatus.Error(r.error.userMessage)
            }
            _ui.update { it.copy(status = status) }
        }
    }

    fun save() {
        val key = _ui.value.input.trim()
        if (!key.startsWith("sk-")) {
            _ui.update { it.copy(status = KeyStatus.Error("La clé doit commencer par « sk- ».")) }
            return
        }
        locator.keyStore.save(key)
        _ui.update { it.copy(input = "", info = "Clé enregistrée (chiffrée sur cet appareil).") }
        refreshSaved()
    }

    fun delete() {
        locator.keyStore.clear()
        _ui.update { it.copy(input = "", status = KeyStatus.Idle, info = "Clé supprimée.") }
        refreshSaved()
    }
}
