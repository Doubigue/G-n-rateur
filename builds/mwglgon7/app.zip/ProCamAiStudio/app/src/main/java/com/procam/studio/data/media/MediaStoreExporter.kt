package com.procam.studio.data.media

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.camera.video.MediaStoreOutputOptions
import com.procam.studio.imaging.ImageProcessorHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Export haute qualité dans la galerie (MediaStore) : JPEG, PNG alpha et vidéo. */
class MediaStoreExporter(private val context: Context) {

    private fun stamp(): String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    suspend fun saveJpeg(bitmap: Bitmap, quality: Int = 95, prefix: String = "PROCAM"): Uri =
        save(bitmap, "${prefix}_${stamp()}.jpg", "image/jpeg") { out ->
            ImageProcessorHelper.writeJpeg(bitmap, quality, out)
        }

    /** PNG avec canal alpha préservé (ARGB_8888). */
    suspend fun savePng(bitmap: Bitmap, prefix: String = "PROCAM_AI"): Uri =
        save(bitmap, "${prefix}_${stamp()}.png", "image/png") { out ->
            ImageProcessorHelper.writePng(bitmap, out)
        }

    private suspend fun save(
        bitmap: Bitmap,
        fileName: String,
        mime: String,
        writer: (java.io.OutputStream) -> Boolean
    ): Uri = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Images.Media.MIME_TYPE, mime)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ProCam")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
        }
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("Création du fichier impossible")
        try {
            resolver.openOutputStream(uri)?.use { out ->
                if (!writer(out)) throw IOException("Écriture impossible")
            } ?: throw IOException("Flux de sortie introuvable")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val done = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
                resolver.update(uri, done, null, null)
            }
            uri
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
    }

    fun videoOutputOptions(): MediaStoreOutputOptions {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "PROCAM_${stamp()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ProCam")
            }
        }
        return MediaStoreOutputOptions.Builder(
            context.contentResolver,
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        ).setContentValues(values).build()
    }
}
