package com.procam.studio.data.camera

import android.hardware.camera2.CameraMetadata

enum class WhiteBalanceMode(val label: String, val awbMode: Int?) {
    AUTO("Auto", CameraMetadata.CONTROL_AWB_MODE_AUTO),
    DAYLIGHT("Jour", CameraMetadata.CONTROL_AWB_MODE_DAYLIGHT),
    CLOUDY("Nuageux", CameraMetadata.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT),
    TUNGSTEN("Tungstène", CameraMetadata.CONTROL_AWB_MODE_INCANDESCENT),
    FLUORESCENT("Fluo", CameraMetadata.CONTROL_AWB_MODE_FLUORESCENT),
    SHADE("Ombre", CameraMetadata.CONTROL_AWB_MODE_SHADE),
    KELVIN("Kelvin", null)
}

/** État complet des réglages manuels. Les valeurs "auto" laissent la main au capteur. */
data class ManualControls(
    val isoAuto: Boolean = true,
    val iso: Int = 100,
    val shutterAuto: Boolean = true,
    val shutterNs: Long = 1_000_000_000L / 60,
    val focusAuto: Boolean = true,
    val focusDistance: Float = 0f, // dioptries : 0 = infini
    val wbMode: WhiteBalanceMode = WhiteBalanceMode.AUTO,
    val kelvin: Int = 5500,
    val evIndex: Int = 0,
    val aeLock: Boolean = false,
    val afLock: Boolean = false
)

/** Valeurs réellement utilisées par le capteur (lues dans les TotalCaptureResult). */
data class Readout(
    val iso: Int = 100,
    val shutterNs: Long = 1_000_000_000L / 60,
    val focusDistance: Float = 0f
)
