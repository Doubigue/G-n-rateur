package com.procam.studio.ui.camera

import android.app.Application
import android.net.Uri
import androidx.camera.view.PreviewView
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.viewModelScope
import com.procam.studio.ProCamApp
import com.procam.studio.core.AppResult
import com.procam.studio.data.camera.ManualControls
import com.procam.studio.data.camera.ProCameraManager
import com.procam.studio.data.local.CameraPrefs
import com.procam.studio.domain.model.AspectGuide
import com.procam.studio.domain.model.CaptureMode
import com.procam.studio.domain.model.GridType
import com.procam.studio.domain.model.LutProfile
import com.procam.studio.domain.model.VideoResolution
import com.procam.studio.imaging.BitmapUtils
import com.procam.studio.imaging.FastFilters
import com.procam.studio.imaging.ImageProcessorHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class Dial(val label: String) { NONE(""), ISO("ISO"), SHUTTER("VITESSE"), FOCUS("MAP"), WB("BALANCE"), EV("EV") }

data class CameraUiState(
    val mode: CaptureMode = CaptureMode.PHOTO,
    val frontLens: Boolean = false,
    val controls: ManualControls = ManualControls(),
    val activeDial: Dial = Dial.NONE,
    val lut: LutProfile = LutProfile.NONE,
    val grid: GridType = GridType.THIRDS,
    val aspect: AspectGuide = AspectGuide.NATIVE,
    val resolution: VideoResolution = VideoResolution.FHD,
    val fps: Int = 30,
    val peaking: Boolean = false,
    val showHistogram: Boolean = true,
    val isRecording: Boolean = false,
    val recordSeconds: Int = 0,
    val busy: Boolean = false,
    val showApiDialog: Boolean = false,
    val message: String? = null
)

private inline fun <reified T : Enum<T>> T.next(): T {
    val all = enumValues<T>()
    return all[(ordinal + 1) % all.size]
}

class CameraViewModel(app: Application) : AndroidViewModel(app) {

    private val locator = (app as ProCamApp).locator
    val camera = ProCameraManager(app)

    private val _ui = MutableStateFlow(CameraUiState())
    val ui: StateFlow<CameraUiState> = _ui.asStateFlow()
    private var timerJob: Job? = null

    init {
        viewModelScope.launch {
            val p = locator.settings.prefs.first()
            _ui.update { it.copy(lut = p.lut, grid = p.grid, aspect = p.aspect, fps = p.fps, peaking = p.peaking) }
            camera.setLut(p.lut)
            camera.setPeaking(p.peaking)
        }
    }

    fun bind(owner: LifecycleOwner, view: PreviewView) {
        val s = _ui.value
        camera.bind(owner, view, s.mode, s.frontLens, s.resolution, s.fps) {
            camera.applyManual(_ui.value.controls)
            camera.setLut(_ui.value.lut)
        }
    }

    // ----------------------------------------------------------- Réglages d'interface

    fun setMode(mode: CaptureMode) {
        if (_ui.value.isRecording) return
        _ui.update { it.copy(mode = mode) }
    }

    fun flipLens() {
        if (_ui.value.isRecording) return
        _ui.update { it.copy(frontLens = !it.frontLens, controls = ManualControls()) }
    }

    fun cycleResolution() {
        if (_ui.value.isRecording) return
        val supportsUhd = camera.capabilities.value?.supportsUhd == true
        _ui.update {
            val next = it.resolution.next()
            if (next == VideoResolution.UHD && !supportsUhd) {
                it.copy(message = "4K non supportée par cet appareil")
            } else it.copy(resolution = next)
        }
    }

    fun cycleFps() {
        if (_ui.value.isRecording) return
        val list = camera.capabilities.value?.supportedFps ?: listOf(24, 30, 60)
        _ui.update {
            val idx = list.indexOf(it.fps)
            it.copy(fps = list[(idx + 1) % list.size])
        }
        persist()
    }

    fun cycleGrid() { _ui.update { it.copy(grid = it.grid.next()) }; persist() }
    fun cycleAspect() { _ui.update { it.copy(aspect = it.aspect.next()) }; persist() }

    fun cycleLut() {
        _ui.update { it.copy(lut = it.lut.next()) }
        camera.setLut(_ui.value.lut)
        persist()
    }

    fun togglePeaking() {
        _ui.update { it.copy(peaking = !it.peaking) }
        camera.setPeaking(_ui.value.peaking)
        persist()
    }

    fun toggleHistogram() { _ui.update { it.copy(showHistogram = !it.showHistogram) } }

    fun selectDial(dial: Dial) {
        _ui.update { it.copy(activeDial = if (it.activeDial == dial) Dial.NONE else dial) }
    }

    fun updateControls(transform: (ManualControls) -> ManualControls) {
        _ui.update { it.copy(controls = transform(it.controls)) }
        camera.applyManual(_ui.value.controls)
    }

    fun toggleLocks() {
        updateControls {
            val lock = !(it.aeLock && it.afLock)
            it.copy(aeLock = lock, afLock = lock)
        }
    }

    fun showApiDialog(show: Boolean) { _ui.update { it.copy(showApiDialog = show) } }
    fun clearMessage() { _ui.update { it.copy(message = null) } }

    private fun persist() {
        val s = _ui.value
        viewModelScope.launch {
            locator.settings.save(CameraPrefs(s.lut, s.grid, s.aspect, s.fps, s.peaking))
        }
    }

    // ----------------------------------------------------------- Capture

    fun onShutter(onOpenStudio: () -> Unit) {
        val s = _ui.value
        if (s.busy) return
        when (s.mode) {
            CaptureMode.PHOTO -> takePhoto(onOpenStudio)
            CaptureMode.VIDEO -> if (s.isRecording) camera.stopRecording() else startVideo()
        }
    }

    private fun takePhoto(onOpenStudio: () -> Unit) {
        _ui.update { it.copy(busy = true) }
        camera.takePhoto { result ->
            viewModelScope.launch(Dispatchers.Default) {
                when (result) {
                    is AppResult.Failure -> _ui.update { it.copy(busy = false, message = result.error.userMessage) }
                    is AppResult.Success -> try {
                        val s = _ui.value
                        var bmp = result.data
                        if (s.lut != LutProfile.NONE) {
                            bmp = FastFilters.applyColorMatrix(bmp, s.lut.colorMatrix().array)
                        }
                        s.aspect.ratio?.let { bmp = ImageProcessorHelper.cropToAspect(bmp, it) }
                        locator.exporter.saveJpeg(bmp, 95)
                        locator.session.original.value = bmp
                        _ui.update { it.copy(busy = false) }
                        withContext(Dispatchers.Main) { onOpenStudio() }
                    } catch (e: Exception) {
                        _ui.update { it.copy(busy = false, message = "Sauvegarde impossible : ${e.message}") }
                    }
                }
            }
        }
    }

    private fun startVideo() {
        _ui.update { it.copy(isRecording = true, recordSeconds = 0) }
        timerJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                _ui.update { it.copy(recordSeconds = it.recordSeconds + 1) }
            }
        }
        camera.startRecording(locator.exporter.videoOutputOptions()) { result ->
            timerJob?.cancel()
            _ui.update {
                it.copy(
                    isRecording = false,
                    message = when (result) {
                        is AppResult.Success -> "Vidéo enregistrée dans Movies/ProCam"
                        is AppResult.Failure -> result.error.userMessage
                    }
                )
            }
        }
    }

    // ----------------------------------------------------------- Import galerie

    fun importFromGallery(uri: Uri, onOpenStudio: () -> Unit) {
        viewModelScope.launch {
            try {
                val bmp = withContext(Dispatchers.IO) { BitmapUtils.decodeUri(getApplication(), uri, 2048) }
                locator.session.original.value = bmp
                onOpenStudio()
            } catch (e: Exception) {
                _ui.update { it.copy(message = "Import impossible : ${e.message}") }
            }
        }
    }

    override fun onCleared() {
        timerJob?.cancel()
        camera.release()
        super.onCleared()
    }
}
