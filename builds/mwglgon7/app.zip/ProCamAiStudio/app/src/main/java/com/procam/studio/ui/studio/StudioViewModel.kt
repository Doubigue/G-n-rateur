package com.procam.studio.ui.studio

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.procam.studio.ProCamApp
import com.procam.studio.core.AppResult
import com.procam.studio.domain.model.AiPreset
import com.procam.studio.domain.model.LocalBackend
import com.procam.studio.domain.model.LocalEngine
import com.procam.studio.domain.model.Suggestion
import com.procam.studio.imaging.ImageProcessorHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class Busy(val label: String) {
    GENERATE("Génération en cours… (peut prendre jusqu'à 1 minute)"),
    ENHANCE("Amélioration du prompt…"),
    ANALYZE("Analyse de la photo…"),
    LOCAL("Détourage sur l'appareil… (1er usage : téléchargement unique du modèle)"),
    SAVE("Sauvegarde…")
}

data class StudioUiState(
    val preset: AiPreset = AiPreset.PORTRAIT_STUDIO,
    val useLocal: Boolean = true,
    val localEngine: LocalEngine = LocalEngine.AUTO,
    val prompt: String = "",
    val busy: Busy? = null,
    val result: Bitmap? = null,
    val analysisSummary: String? = null,
    val suggestions: List<Suggestion> = emptyList(),
    val error: String? = null,
    val info: String? = null,
    val savedUri: Uri? = null
)

class StudioViewModel(app: Application) : AndroidViewModel(app) {

    private val locator = (app as ProCamApp).locator
    val original: StateFlow<Bitmap?> = locator.session.original

    private val _ui = MutableStateFlow(StudioUiState())
    val ui: StateFlow<StudioUiState> = _ui.asStateFlow()

    fun selectPreset(preset: AiPreset) {
        _ui.update { it.copy(preset = preset, error = null) }
    }

    fun setUseLocal(enabled: Boolean) {
        _ui.update { it.copy(useLocal = enabled) }
    }

    fun setLocalEngine(engine: LocalEngine) {
        _ui.update { it.copy(localEngine = engine) }
    }

    fun onPrompt(text: String) {
        _ui.update { it.copy(prompt = text) }
    }

    fun useSuggestion(s: Suggestion) {
        _ui.update { it.copy(prompt = s.prompt, preset = AiPreset.CUSTOM, error = null) }
    }

    fun generate() {
        val src = original.value ?: return
        val s = _ui.value
        if (s.busy != null) return
        // Détourage / fond blanc : traitement local gratuit (ML Kit) si activé, sinon API OpenAI.
        val local = s.preset.supportsLocal && s.useLocal
        _ui.update {
            it.copy(busy = if (local) Busy.LOCAL else Busy.GENERATE, error = null, info = null, savedUri = null)
        }
        viewModelScope.launch {
            val outcome = if (local) locator.localCutout(src, s.preset, s.localEngine)
            else locator.applyPreset(src, s.preset, s.prompt)
            when (val r = outcome) {
                is AppResult.Success -> _ui.update {
                    it.copy(
                        busy = null,
                        result = r.data,
                        info = if (local && s.localEngine == LocalEngine.AUTO && locator.localSegmenter.lastBackend != LocalBackend.GOOGLE_PLAY)
                            "Modèle Google indisponible : détourage réalisé avec le modèle intégré U²-Net (hors-ligne)."
                        else null
                    )
                }
                is AppResult.Failure -> _ui.update { it.copy(busy = null, error = r.error.userMessage) }
            }
        }
    }

    fun enhancePrompt() {
        val s = _ui.value
        if (s.busy != null) return
        _ui.update { it.copy(busy = Busy.ENHANCE, error = null) }
        viewModelScope.launch {
            when (val r = locator.enhancePrompt(s.prompt)) {
                is AppResult.Success -> _ui.update {
                    it.copy(busy = null, prompt = r.data, preset = AiPreset.CUSTOM)
                }
                is AppResult.Failure -> _ui.update { it.copy(busy = null, error = r.error.userMessage) }
            }
        }
    }

    fun analyze() {
        val src = original.value ?: return
        if (_ui.value.busy != null) return
        _ui.update { it.copy(busy = Busy.ANALYZE, error = null) }
        viewModelScope.launch {
            when (val r = locator.analyzePhoto(src)) {
                is AppResult.Success -> _ui.update {
                    it.copy(busy = null, analysisSummary = r.data.summary, suggestions = r.data.suggestions.take(3))
                }
                is AppResult.Failure -> _ui.update { it.copy(busy = null, error = r.error.userMessage) }
            }
        }
    }

    /** PNG (alpha conservé) si le résultat est transparent, JPEG qualité 95 sinon. */
    fun saveResult() {
        val bmp = _ui.value.result ?: return
        if (_ui.value.busy != null) return
        _ui.update { it.copy(busy = Busy.SAVE, error = null) }
        viewModelScope.launch {
            try {
                val uri = withContext(Dispatchers.IO) {
                    if (ImageProcessorHelper.hasTransparentPixels(bmp)) {
                        val trimmed = ImageProcessorHelper.trimTransparentBounds(bmp, 8)
                        locator.exporter.savePng(trimmed)
                    } else {
                        locator.exporter.saveJpeg(bmp, 95, "PROCAM_AI")
                    }
                }
                _ui.update { it.copy(busy = null, savedUri = uri, info = "Enregistré dans Pictures/ProCam") }
            } catch (e: Exception) {
                _ui.update { it.copy(busy = null, error = "Sauvegarde impossible : ${e.message}") }
            }
        }
    }

    fun clearError() { _ui.update { it.copy(error = null) } }
}
