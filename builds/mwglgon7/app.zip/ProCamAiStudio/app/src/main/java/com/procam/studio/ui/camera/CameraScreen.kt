package com.procam.studio.ui.camera

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.view.PreviewView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FlipCameraAndroid
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.procam.studio.data.camera.CameraCapabilities
import com.procam.studio.data.camera.Readout
import com.procam.studio.data.camera.WhiteBalanceMode
import com.procam.studio.domain.model.CaptureMode
import com.procam.studio.domain.model.LutProfile
import com.procam.studio.ui.settings.ApiKeyDialog
import com.procam.studio.ui.theme.CineAccent
import com.procam.studio.ui.theme.CineRec
import com.procam.studio.ui.theme.CineSurface
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.roundToInt

private fun hasPermission(context: Context, permission: String) =
    ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

@Composable
fun CameraScreen(onOpenStudio: () -> Unit, vm: CameraViewModel = viewModel()) {
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val ui by vm.ui.collectAsStateWithLifecycle()
    val caps by vm.camera.capabilities.collectAsStateWithLifecycle()
    val readout by vm.camera.readout.collectAsStateWithLifecycle()
    val histogram by vm.camera.histogram.collectAsStateWithLifecycle()
    val peaking by vm.camera.peaking.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }

    var permissionOk by remember { mutableStateOf(hasPermission(context, Manifest.permission.CAMERA)) }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        permissionOk = hasPermission(context, Manifest.permission.CAMERA)
    }
    val galleryPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.importFromGallery(uri, onOpenStudio)
    }

    LaunchedEffect(Unit) {
        if (!permissionOk) permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
    }
    LaunchedEffect(Unit) { vm.camera.errors.collect { snackbar.showSnackbar(it) } }
    LaunchedEffect(ui.message) {
        ui.message?.let {
            snackbar.showSnackbar(it)
            vm.clearMessage()
        }
    }

    val previewView = remember {
        PreviewView(context).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE // requis pour le filtre LUT GPU
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
    }
    LaunchedEffect(permissionOk, ui.mode, ui.frontLens, ui.resolution, ui.fps) {
        if (permissionOk) vm.bind(owner, previewView)
    }

    Scaffold(
        containerColor = Color.Black,
        snackbarHost = { SnackbarHost(snackbar) }
    ) { padding ->
        if (!permissionOk) {
            Column(
                Modifier.fillMaxSize().padding(padding),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("L'accès à la caméra est nécessaire.", color = Color.White)
                TextButton(onClick = {
                    permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
                }) { Text("Autoriser") }
            }
            return@Scaffold
        }

        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            TopBar(ui, onKey = { vm.showApiDialog(true) }, onMode = vm::setMode)

            // ---------------- Viseur
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                val ratio = if (ui.mode == CaptureMode.PHOTO) 3f / 4f else 9f / 16f
                Box(
                    Modifier
                        .fillMaxHeight()
                        .aspectRatio(ratio, matchHeightConstraintsFirst = true)
                        .clipToBounds()
                        .pointerInput(Unit) {
                            detectTapGestures { offset ->
                                vm.camera.tapToFocus(previewView.meteringPointFactory.createPoint(offset.x, offset.y))
                            }
                        }
                ) {
                    AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
                    peaking?.let {
                        Image(
                            bitmap = it.asImageBitmap(),
                            contentDescription = null,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.FillBounds
                        )
                    }
                    GridOverlay(ui.grid, ui.aspect, Modifier.fillMaxSize())
                    LevelIndicator(Modifier.align(Alignment.Center))
                    if (ui.showHistogram) {
                        HistogramView(
                            histogram,
                            Modifier.align(Alignment.TopEnd).padding(8.dp).size(120.dp, 56.dp)
                        )
                    }
                    ReadoutLabel(readout, ui.controls.evIndex, caps, Modifier.align(Alignment.BottomStart).padding(8.dp))
                    if (ui.isRecording) {
                        RecIndicator(ui.recordSeconds, Modifier.align(Alignment.TopStart).padding(8.dp))
                    }
                }
            }

            ToolsRow(ui, caps, vm)
            DialSelector(ui, vm)
            if (ui.activeDial != Dial.NONE) {
                DialPanel(ui, caps, readout, vm)
            }

            BottomBar(
                mode = ui.mode,
                recording = ui.isRecording,
                busy = ui.busy,
                onGallery = { galleryPicker.launch("image/*") },
                onShutter = { vm.onShutter(onOpenStudio) },
                onFlip = vm::flipLens
            )
        }
    }

    if (ui.showApiDialog) ApiKeyDialog(onDismiss = { vm.showApiDialog(false) })
}

// ---------------------------------------------------------------------------------------------

@Composable
private fun TopBar(ui: CameraUiState, onKey: () -> Unit, onMode: (CaptureMode) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        IconButton(onClick = onKey) {
            Icon(Icons.Filled.VpnKey, contentDescription = "Configuration API", tint = CineAccent)
        }
        Row {
            CaptureMode.values().forEach { m ->
                TextButton(onClick = { onMode(m) }, enabled = !ui.isRecording) {
                    Text(
                        if (m == CaptureMode.PHOTO) "PHOTO" else "VIDÉO",
                        color = if (ui.mode == m) CineAccent else Color.Gray,
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            }
        }
        Box(Modifier.size(48.dp))
    }
}

@Composable
private fun ReadoutLabel(r: Readout, ev: Int, caps: CameraCapabilities?, modifier: Modifier) {
    val ns = r.shutterNs
    val shutter = if (ns >= 500_000_000L) "%.1fs".format(ns / 1e9) else "1/${(1e9 / ns).roundToInt()}"
    val focus = if (r.focusDistance <= 0.01f) "∞" else "%.2fm".format(1f / r.focusDistance)
    Text(
        "ISO ${r.iso} · $shutter · $focus",
        modifier = modifier
            .background(Color.Black.copy(alpha = 0.45f), RoundedCornerShape(6.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp),
        color = Color.White,
        style = MaterialTheme.typography.labelSmall
    )
}

@Composable
private fun RecIndicator(seconds: Int, modifier: Modifier) {
    Row(
        modifier.background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(6.dp)).padding(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(10.dp).clip(CircleShape).background(CineRec))
        Spacer(Modifier.width(6.dp))
        Text("%02d:%02d".format(seconds / 60, seconds % 60), color = Color.White, style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun ToolsRow(ui: CameraUiState, caps: CameraCapabilities?, vm: CameraViewModel) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        ToolChip(ui.grid.label, onClick = vm::cycleGrid)
        ToolChip("Cadre ${ui.aspect.label}", onClick = vm::cycleAspect)
        ToolChip(ui.lut.label, highlight = ui.lut != LutProfile.NONE, onClick = vm::cycleLut)
        ToolChip("Peaking", highlight = ui.peaking, onClick = vm::togglePeaking)
        ToolChip("Histo", highlight = ui.showHistogram, onClick = vm::toggleHistogram)
        val locked = ui.controls.aeLock && ui.controls.afLock
        AssistChip(
            onClick = vm::toggleLocks,
            label = { Text("AE/AF") },
            leadingIcon = {
                Icon(if (locked) Icons.Filled.Lock else Icons.Filled.LockOpen, null, Modifier.size(16.dp))
            },
            colors = AssistChipDefaults.assistChipColors(
                containerColor = if (locked) CineAccent else CineSurface,
                labelColor = if (locked) Color.Black else Color.White,
                leadingIconContentColor = if (locked) Color.Black else Color.White
            )
        )
        if (ui.mode == CaptureMode.VIDEO) {
            ToolChip(ui.resolution.label, onClick = vm::cycleResolution)
            ToolChip("${ui.fps} fps", onClick = vm::cycleFps)
        }
    }
}

@Composable
private fun ToolChip(label: String, highlight: Boolean = false, onClick: () -> Unit) {
    AssistChip(
        onClick = onClick,
        label = { Text(label, style = MaterialTheme.typography.labelMedium) },
        colors = AssistChipDefaults.assistChipColors(
            containerColor = if (highlight) CineAccent else CineSurface,
            labelColor = if (highlight) Color.Black else Color.White
        ),
        border = BorderStroke(0.dp, Color.Transparent)
    )
}

@Composable
private fun DialSelector(ui: CameraUiState, vm: CameraViewModel) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Dial.values().filter { it != Dial.NONE }.forEach { d ->
            FilterChip(
                selected = ui.activeDial == d,
                onClick = { vm.selectDial(d) },
                label = { Text(d.label, style = MaterialTheme.typography.labelMedium) }
            )
        }
    }
}

@Composable
private fun DialPanel(ui: CameraUiState, caps: CameraCapabilities?, readout: Readout, vm: CameraViewModel) {
    val c = ui.controls
    Column(Modifier.fillMaxWidth().background(CineSurface)) {
        when (ui.activeDial) {
            Dial.ISO -> {
                val range = caps?.isoRange ?: 100..3200
                ManualDial(
                    title = "ISO",
                    valueText = if (c.isoAuto) "AUTO (${readout.iso})" else c.iso.toString(),
                    value = c.iso.toFloat(),
                    range = range.first.toFloat()..range.last.toFloat(),
                    onValueChange = { v -> vm.updateControls { it.copy(iso = v.roundToInt()) } },
                    auto = c.isoAuto,
                    onAutoChange = { auto ->
                        vm.updateControls { it.copy(isoAuto = auto, iso = if (!auto) readout.iso else it.iso) }
                    },
                    enabled = caps?.manualSensorSupported == true
                )
            }
            Dial.SHUTTER -> {
                val minNs = (caps?.shutterRangeNs?.first ?: 125_000L).coerceAtLeast(125_000L)
                val maxNs = (caps?.shutterRangeNs?.last ?: 500_000_000L).coerceAtMost(1_000_000_000L)
                val lo = ln(minNs.toDouble())
                val hi = ln(maxNs.toDouble())
                val t = ((ln(c.shutterNs.toDouble().coerceIn(minNs.toDouble(), maxNs.toDouble())) - lo) / (hi - lo)).toFloat()
                ManualDial(
                    title = "VITESSE D'OBTURATION",
                    valueText = if (c.shutterAuto) "AUTO" else formatShutter(c.shutterNs),
                    value = t,
                    range = 0f..1f,
                    onValueChange = { v ->
                        val ns = exp(lo + (hi - lo) * v).toLong()
                        vm.updateControls { it.copy(shutterNs = ns) }
                    },
                    auto = c.shutterAuto,
                    onAutoChange = { auto ->
                        vm.updateControls {
                            it.copy(shutterAuto = auto, shutterNs = if (!auto) readout.shutterNs else it.shutterNs)
                        }
                    },
                    enabled = caps?.manualSensorSupported == true
                )
            }
            Dial.FOCUS -> {
                val maxD = caps?.minFocusDistance ?: 0f
                ManualDial(
                    title = "MISE AU POINT",
                    valueText = if (c.focusAuto) "AUTO" else if (c.focusDistance <= 0.01f) "∞" else "%.2f m".format(1f / c.focusDistance),
                    value = c.focusDistance,
                    range = 0f..maxOf(maxD, 0.1f),
                    onValueChange = { v -> vm.updateControls { it.copy(focusDistance = v) } },
                    auto = c.focusAuto,
                    onAutoChange = { auto ->
                        vm.updateControls {
                            it.copy(focusAuto = auto, focusDistance = if (!auto) readout.focusDistance else it.focusDistance)
                        }
                    },
                    enabled = caps?.manualFocusSupported == true
                )
            }
            Dial.WB -> {
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    WhiteBalanceMode.values().forEach { m ->
                        FilterChip(
                            selected = c.wbMode == m,
                            onClick = { vm.updateControls { it.copy(wbMode = m) } },
                            label = { Text(m.label) },
                            enabled = m != WhiteBalanceMode.KELVIN || caps?.manualWbSupported == true
                        )
                    }
                }
                if (c.wbMode == WhiteBalanceMode.KELVIN) {
                    ManualDial(
                        title = "TEMPÉRATURE",
                        valueText = "${c.kelvin} K",
                        value = c.kelvin.toFloat(),
                        range = 2000f..10000f,
                        onValueChange = { v -> vm.updateControls { it.copy(kelvin = (v / 50).roundToInt() * 50) } }
                    )
                }
            }
            Dial.EV -> {
                val range = caps?.evRange ?: 0..0
                val step = caps?.evStep ?: 0f
                ManualDial(
                    title = "EXPOSITION (EV)",
                    valueText = "%+.1f".format(c.evIndex * step),
                    value = c.evIndex.toFloat(),
                    range = range.first.toFloat()..maxOf(range.last.toFloat(), range.first + 1f),
                    onValueChange = { v -> vm.updateControls { it.copy(evIndex = v.roundToInt()) } },
                    enabled = range.last > range.first && c.isoAuto && c.shutterAuto
                )
            }
            Dial.NONE -> Unit
        }
    }
}

private fun formatShutter(ns: Long): String =
    if (ns >= 500_000_000L) "%.1f s".format(ns / 1e9) else "1/${(1e9 / ns).roundToInt()}"

@Composable
private fun BottomBar(
    mode: CaptureMode,
    recording: Boolean,
    busy: Boolean,
    onGallery: () -> Unit,
    onShutter: () -> Unit,
    onFlip: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onGallery, enabled = !recording) {
            Icon(Icons.Filled.PhotoLibrary, "Galerie", tint = Color.White, modifier = Modifier.size(28.dp))
        }
        val inner = if (mode == CaptureMode.VIDEO) CineRec else Color.White
        Box(
            Modifier
                .size(76.dp)
                .border(4.dp, Color.White, CircleShape)
                .padding(7.dp)
                .clip(if (recording) RoundedCornerShape(10.dp) else CircleShape)
                .background(if (busy) Color.Gray else inner)
                .clickable(enabled = !busy, onClick = onShutter)
        )
        IconButton(onClick = onFlip, enabled = !recording) {
            Icon(Icons.Filled.FlipCameraAndroid, "Changer de caméra", tint = Color.White, modifier = Modifier.size(28.dp))
        }
    }
}
