package com.procam.studio.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.procam.studio.ui.camera.CameraScreen
import com.procam.studio.ui.studio.StudioScreen

@Composable
fun AppNavHost() {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = "camera") {
        composable("camera") {
            CameraScreen(onOpenStudio = { nav.navigate("studio") })
        }
        composable("studio") {
            StudioScreen(onBack = { nav.popBackStack() })
        }
    }
}
