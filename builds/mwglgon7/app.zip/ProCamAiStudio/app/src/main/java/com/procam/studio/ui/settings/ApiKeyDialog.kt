package com.procam.studio.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel

@Composable
fun ApiKeyDialog(onDismiss: () -> Unit, vm: ApiKeyViewModel = viewModel()) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    var visible by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Configuration API OpenAI") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    "Collez votre clé personnelle. Elle est stockée chiffrée (AES-256) uniquement sur cet appareil.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                ui.savedMasked?.let {
                    Text("Clé enregistrée : $it", style = MaterialTheme.typography.labelMedium)
                }
                OutlinedTextField(
                    value = ui.input,
                    onValueChange = vm::onInput,
                    label = { Text("sk-...") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    trailingIcon = {
                        IconButton(onClick = { visible = !visible }) {
                            Icon(
                                if (visible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                contentDescription = "Afficher / masquer"
                            )
                        }
                    }
                )
                OutlinedButton(
                    onClick = vm::verify,
                    enabled = ui.status != KeyStatus.Checking && (ui.input.isNotBlank() || ui.savedMasked != null),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Vérifier la connexion") }

                when (val s = ui.status) {
                    KeyStatus.Checking -> Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                        Text("Vérification…")
                    }
                    KeyStatus.Valid -> Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.CheckCircle, null, tint = Color(0xFF4CAF50))
                        Spacer(Modifier.width(8.dp))
                        Text("Connexion réussie", color = Color(0xFF4CAF50))
                    }
                    is KeyStatus.Error -> Text(s.message, color = MaterialTheme.colorScheme.error)
                    KeyStatus.Idle -> Spacer(Modifier.height(0.dp))
                }
                ui.info?.let { Text(it, style = MaterialTheme.typography.labelMedium) }
            }
        },
        confirmButton = {
            Button(onClick = vm::save, enabled = ui.input.isNotBlank()) { Text("Enregistrer") }
        },
        dismissButton = {
            Row {
                if (ui.savedMasked != null) {
                    TextButton(onClick = vm::delete) { Text("Supprimer", color = MaterialTheme.colorScheme.error) }
                }
                TextButton(onClick = onDismiss) { Text("Fermer") }
            }
        }
    )
}
