package com.procam.studio.data.repository

import android.graphics.Bitmap
import com.procam.studio.core.AppError
import com.procam.studio.core.AppResult
import com.procam.studio.data.local.SecureKeyStore
import com.procam.studio.data.remote.ApiErrorEnvelope
import com.procam.studio.data.remote.ChatMessage
import com.procam.studio.data.remote.ChatRequest
import com.procam.studio.data.remote.OpenAiApi
import com.procam.studio.data.remote.ResponseFormat
import com.procam.studio.domain.model.PhotoAnalysis
import com.procam.studio.imaging.ImageProcessorHelper
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.Response
import java.io.IOException
import java.net.SocketTimeoutException

class OpenAiStudioRepository(
    private val keyStore: SecureKeyStore,
    private val api: OpenAiApi,
    private val json: Json
) {

    // ---------------------------------------------------------------- Connexion

    suspend fun verifyConnection(candidateKey: String): AppResult<Unit> = withContext(Dispatchers.IO) {
        val key = candidateKey.trim()
        if (!key.startsWith("sk-") || key.length < 20) {
            return@withContext AppResult.Failure(AppError.InvalidKey)
        }
        when (val r = call { api.listModels("Bearer $key") }) {
            is AppResult.Success -> AppResult.Success(Unit)
            is AppResult.Failure -> r
        }
    }

    // ---------------------------------------------------------------- gpt-image-1 : /v1/images/edits

    suspend fun editImage(
        source: Bitmap,
        prompt: String,
        transparentBackground: Boolean
    ): AppResult<Bitmap> = withContext(Dispatchers.IO) {
        if (keyStore.get() == null) return@withContext AppResult.Failure(AppError.MissingKey)
        try {
            val prepared = ImageProcessorHelper.scaleToMaxSide(source, 1536)
            val png = ImageProcessorHelper.toPngBytes(prepared)
            val imagePart = MultipartBody.Part.createFormData(
                "image", "photo.png", png.toRequestBody("image/png".toMediaType())
            )
            val size = when {
                prepared.width > prepared.height * 1.15f -> "1536x1024"
                prepared.height > prepared.width * 1.15f -> "1024x1536"
                else -> "1024x1024"
            }
            val result = call {
                api.editImage(
                    image = imagePart,
                    prompt = text(prompt),
                    model = text("gpt-image-1"),
                    size = text(size),
                    quality = text("high"),
                    outputFormat = text("png"),
                    background = if (transparentBackground) text("transparent") else null
                )
            }
            when (result) {
                is AppResult.Failure -> result
                is AppResult.Success -> {
                    val b64 = result.data.data.firstOrNull()?.b64Json
                        ?: return@withContext AppResult.Failure(AppError.Unknown("Aucune image renvoyée"))
                    val decoded = ImageProcessorHelper.decodeBase64ToBitmap(b64)
                    // Même ratio que l'original pour que le comparateur avant/après s'aligne.
                    val aligned = ImageProcessorHelper.cropToAspect(
                        decoded, source.width.toFloat() / source.height.toFloat()
                    )
                    AppResult.Success(aligned)
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: OutOfMemoryError) {
            AppResult.Failure(AppError.Unknown("Mémoire insuffisante pour traiter l'image"))
        } catch (e: Exception) {
            AppResult.Failure(mapException(e))
        }
    }

    // ---------------------------------------------------------------- GPT-4o : amélioration de prompt

    suspend fun enhancePrompt(idea: String): AppResult<String> = withContext(Dispatchers.IO) {
        if (keyStore.get() == null) return@withContext AppResult.Failure(AppError.MissingKey)
        val request = ChatRequest(
            model = "gpt-4o",
            messages = listOf(
                ChatMessage("system", JsonPrimitive(ENHANCE_SYSTEM)),
                ChatMessage("user", JsonPrimitive(idea))
            ),
            maxTokens = 400,
            temperature = 0.7
        )
        when (val r = call { api.chat(request) }) {
            is AppResult.Failure -> r
            is AppResult.Success -> {
                val content = r.data.choices.firstOrNull()?.message?.content?.trim()
                if (content.isNullOrBlank()) AppResult.Failure(AppError.Unknown("Réponse vide"))
                else AppResult.Success(content.trim('"'))
            }
        }
    }

    // ---------------------------------------------------------------- GPT-4o Vision : analyse (JSON Base64)

    suspend fun analyzePhoto(photo: Bitmap): AppResult<PhotoAnalysis> = withContext(Dispatchers.IO) {
        if (keyStore.get() == null) return@withContext AppResult.Failure(AppError.MissingKey)
        try {
            val b64 = ImageProcessorHelper.toBase64Jpeg(photo, 1024, 85)
            val userContent = buildJsonArray {
                add(buildJsonObject {
                    put("type", "text")
                    put("text", "Analyse cette photo et propose 3 améliorations.")
                })
                add(buildJsonObject {
                    put("type", "image_url")
                    put("image_url", buildJsonObject {
                        put("url", "data:image/jpeg;base64,$b64")
                        put("detail", "low")
                    })
                })
            }
            val request = ChatRequest(
                model = "gpt-4o",
                messages = listOf(
                    ChatMessage("system", JsonPrimitive(ANALYZE_SYSTEM)),
                    ChatMessage("user", userContent)
                ),
                maxTokens = 800,
                temperature = 0.4,
                responseFormat = ResponseFormat("json_object")
            )
            when (val r = call { api.chat(request) }) {
                is AppResult.Failure -> r
                is AppResult.Success -> {
                    val content = r.data.choices.firstOrNull()?.message?.content
                        ?: return@withContext AppResult.Failure(AppError.Unknown("Réponse vide"))
                    AppResult.Success(json.decodeFromString<PhotoAnalysis>(content))
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            AppResult.Failure(mapException(e))
        }
    }

    // ---------------------------------------------------------------- Utilitaires

    private fun text(value: String): RequestBody = value.toRequestBody("text/plain".toMediaType())

    private suspend fun <T> call(block: suspend () -> Response<T>): AppResult<T> = try {
        val response = block()
        if (response.isSuccessful) {
            response.body()?.let { AppResult.Success(it) }
                ?: AppResult.Failure(AppError.Unknown("Réponse vide du serveur"))
        } else {
            AppResult.Failure(mapHttp(response.code(), response.errorBody()?.string()))
        }
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        AppResult.Failure(mapException(e))
    }

    private fun mapException(e: Exception): AppError = when (e) {
        is SocketTimeoutException -> AppError.Timeout
        is IOException -> AppError.NoNetwork
        else -> AppError.Unknown(e.message ?: e.javaClass.simpleName)
    }

    private fun mapHttp(code: Int, body: String?): AppError {
        val err = body?.let { runCatching { json.decodeFromString<ApiErrorEnvelope>(it).error }.getOrNull() }
        val detail = err?.message ?: "HTTP $code"
        return when {
            code == 401 -> AppError.InvalidKey
            code == 429 && (err?.code == "insufficient_quota" || err?.type == "insufficient_quota") ->
                AppError.QuotaExceeded
            code == 429 -> AppError.RateLimited
            code == 403 -> AppError.Forbidden(
                "$detail (gpt-image-1 peut exiger la vérification de votre organisation OpenAI)"
            )
            code in 400..499 -> AppError.BadRequest(detail)
            code >= 500 -> AppError.Server(code)
            else -> AppError.Unknown(detail)
        }
    }

    private companion object {
        const val ENHANCE_SYSTEM =
            "You are an expert photography retoucher and prompt engineer. Rewrite the user's short idea " +
                "(French or English) into ONE detailed English image-editing prompt for gpt-image-1. Specify " +
                "lighting, lens and depth of field, color grading, mood and texture, and explicitly state what " +
                "must be preserved (subject identity, pose, composition). Return only the prompt, without " +
                "quotes or commentary, 120 words maximum."

        const val ANALYZE_SYSTEM =
            "Tu es un directeur photo expert. Analyse la lumière, la composition, la couleur et la netteté de " +
                "la photo. Réponds UNIQUEMENT avec un objet JSON de la forme " +
                "{\"summary\": \"analyse en 2 phrases, en français\", \"suggestions\": [{\"title\": \"titre " +
                "court en français\", \"prompt\": \"prompt de retouche détaillé en anglais pour gpt-image-1, " +
                "qui préserve l'identité et la composition\"}]} avec exactement 3 suggestions distinctes."
    }
}
