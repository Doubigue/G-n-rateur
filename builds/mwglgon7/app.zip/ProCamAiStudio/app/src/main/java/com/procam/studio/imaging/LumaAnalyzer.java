package com.procam.studio.imaging;

import android.graphics.Bitmap;
import android.graphics.Matrix;

import java.nio.ByteBuffer;

/** Analyse temps réel du plan Y (luminance) : histogramme et focus peaking. */
public final class LumaAnalyzer {

    private LumaAnalyzer() { }

    /** Histogramme 256 bins, échantillonné tous les `step` pixels. */
    public static int[] histogram(ByteBuffer y, int width, int height, int rowStride, int pixelStride, int step) {
        int[] bins = new int[256];
        int s = Math.max(1, step);
        for (int row = 0; row < height; row += s) {
            int base = row * rowStride;
            for (int col = 0; col < width; col += s) {
                bins[y.get(base + col * pixelStride) & 0xFF]++;
            }
        }
        return bins;
    }

    /**
     * Focus peaking : carte rouge sur les zones à fort gradient (netteté).
     * Résolution réduite de moitié ; l'image est pivotée de rotationDegrees pour coller à l'aperçu.
     */
    public static Bitmap focusPeaking(ByteBuffer y, int width, int height, int rowStride,
                                      int pixelStride, int rotationDegrees, int threshold) {
        final int s = 2;
        int ow = width / s;
        int oh = height / s;
        if (ow < 3 || oh < 3) {
            return null;
        }
        int[] px = new int[ow * oh];
        for (int oy = 1; oy < oh - 1; oy++) {
            for (int ox = 1; ox < ow - 1; ox++) {
                int cx = ox * s;
                int cy = oy * s;
                int left = y.get(cy * rowStride + (cx - s) * pixelStride) & 0xFF;
                int right = y.get(cy * rowStride + (cx + s) * pixelStride) & 0xFF;
                int up = y.get((cy - s) * rowStride + cx * pixelStride) & 0xFF;
                int down = y.get((cy + s) * rowStride + cx * pixelStride) & 0xFF;
                int mag = Math.abs(right - left) + Math.abs(down - up);
                if (mag > threshold) {
                    px[oy * ow + ox] = 0xCCFF2D2D;
                }
            }
        }
        Bitmap bmp = Bitmap.createBitmap(px, ow, oh, Bitmap.Config.ARGB_8888);
        int d = ((rotationDegrees % 360) + 360) % 360;
        if (d == 0) {
            return bmp;
        }
        Matrix m = new Matrix();
        m.postRotate(d);
        return Bitmap.createBitmap(bmp, 0, 0, ow, oh, m, true);
    }
}
