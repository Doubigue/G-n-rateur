package com.procam.studio.data.remote

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonElement

@Serializable
data class ChatRequest(
    val model: String,
    val messages: List<ChatMessage>,
    @SerialName("max_tokens") val maxTokens: Int? = null,
    val temperature: Double? = null,
    @SerialName("response_format") val responseFormat: ResponseFormat? = null
)

@Serializable
data class ResponseFormat(val type: String)

/** content = JsonPrimitive (texte) ou JsonArray (parties texte + image_url pour la Vision). */
@Serializable
data class ChatMessage(val role: String, val content: JsonElement)

@Serializable
data class ChatResponse(val choices: List<ChatChoice> = emptyList())

@Serializable
data class ChatChoice(val message: ChatResponseMessage = ChatResponseMessage())

@Serializable
data class ChatResponseMessage(val content: String? = null)

@Serializable
data class ImageEditResponse(val data: List<ImageData> = emptyList())

@Serializable
data class ImageData(
    @SerialName("b64_json") val b64Json: String? = null,
    val url: String? = null
)

@Serializable
data class ModelsResponse(val data: List<ModelItem> = emptyList())

@Serializable
data class ModelItem(val id: String = "")

@Serializable
data class ApiErrorEnvelope(val error: ApiErrorBody? = null)

@Serializable
data class ApiErrorBody(
    val message: String? = null,
    val type: String? = null,
    val code: String? = null
)
