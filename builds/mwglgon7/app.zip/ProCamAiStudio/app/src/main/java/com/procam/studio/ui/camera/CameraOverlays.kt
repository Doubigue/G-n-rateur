package com.procam.studio.ui.camera

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.procam.studio.domain.model.AspectGuide
import com.procam.studio.domain.model.GridType
import kotlin.math.atan2
import kotlin.math.abs
import kotlin.math.max

/** Grille de composition + masque de cadrage (16:9, 9:16, 2.39:1). */
@Composable
fun GridOverlay(grid: GridType, aspect: AspectGuide, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val line = Color.White.copy(alpha = 0.55f)
        var left = 0f
        var top = 0f
        var w = size.width
        var h = size.height

        aspect.ratio?.let { target ->
            val current = w / h
            if (target > current) {
                val newH = w / target
                top = (h - newH) / 2f
                h = newH
            } else {
                val newW = h * target
                left = (w - newW) / 2f
                w = newW
            }
            val mask = Color.Black.copy(alpha = 0.6f)
            drawRect(mask, Offset.Zero, Size(size.width, top))
            drawRect(mask, Offset(0f, top + h), Size(size.width, size.height - top - h))
            drawRect(mask, Offset(0f, top), Size(left, h))
            drawRect(mask, Offset(left + w, top), Size(size.width - left - w, h))
            drawRect(line, Offset(left, top), Size(w, h), style = androidx.compose.ui.graphics.drawscope.Stroke(1.5f))
        }

        when (grid) {
            GridType.THIRDS -> {
                for (i in 1..2) {
                    val x = left + w * i / 3f
                    val y = top + h * i / 3f
                    drawLine(line, Offset(x, top), Offset(x, top + h), 1f)
                    drawLine(line, Offset(left, y), Offset(left + w, y), 1f)
                }
            }
            GridType.CENTER -> {
                val cx = left + w / 2f
                val cy = top + h / 2f
                drawLine(line, Offset(cx - 24f, cy), Offset(cx + 24f, cy), 2f)
                drawLine(line, Offset(cx, cy - 24f), Offset(cx, cy + 24f), 2f)
            }
            GridType.NONE -> Unit
        }
    }
}

/** Histogramme de luminance en direct. */
@Composable
fun HistogramView(bins: IntArray, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        drawRect(Color.Black.copy(alpha = 0.45f))
        var peak = 1
        for (i in 1..254) peak = max(peak, bins[i]) // ignore les bins extrêmes (clipping)
        val barW = size.width / 256f
        for (i in 0..255) {
            val v = (bins[i].toFloat() / peak).coerceAtMost(1f)
            val color = when {
                i < 8 -> Color(0xFF5C6BC0)
                i > 247 -> Color(0xFFE53935)
                else -> Color.White.copy(alpha = 0.85f)
            }
            drawRect(color, Offset(i * barW, size.height * (1f - v)), Size(barW + 0.5f, size.height * v))
        }
    }
}

/** Niveau à bulle basé sur l'accéléromètre (portrait). */
@Composable
fun LevelIndicator(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var roll by remember { mutableFloatStateOf(0f) }

    DisposableEffect(Unit) {
        val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val listener = object : SensorEventListener {
            private var smooth = 0f
            override fun onSensorChanged(e: SensorEvent) {
                val angle = Math.toDegrees(atan2(e.values[0].toDouble(), e.values[1].toDouble())).toFloat()
                smooth += (angle - smooth) * 0.15f
                roll = smooth
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
        }
        if (sensor != null) sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_UI)
        onDispose { sm.unregisterListener(listener) }
    }

    val level = abs(roll) < 1.2f
    val color = if (level) Color(0xFF66BB6A) else Color.White.copy(alpha = 0.8f)
    Canvas(modifier.size(140.dp, 24.dp)) {
        val cy = size.height / 2f
        drawLine(color.copy(alpha = 0.4f), Offset(0f, cy), Offset(size.width * 0.2f, cy), 2f)
        drawLine(color.copy(alpha = 0.4f), Offset(size.width * 0.8f, cy), Offset(size.width, cy), 2f)
        rotate(degrees = -roll, pivot = Offset(size.width / 2f, cy)) {
            drawLine(color, Offset(size.width * 0.25f, cy), Offset(size.width * 0.75f, cy), 3f)
        }
    }
}

@Composable
fun Spacer12(size: Dp = 12.dp) = Box(Modifier.size(size))
