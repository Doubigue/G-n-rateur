package com.procam.studio.data.local

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** Stockage chiffré (AES-256) de la clé API OpenAI de l'utilisateur. */
class SecureKeyStore(private val context: Context) {

    private val prefs: SharedPreferences = createPrefs()

    private fun createPrefs(): SharedPreferences = try {
        open()
    } catch (e: Exception) {
        // Keystore corrompu (restauration d'appareil, etc.) : on repart de zéro.
        context.deleteSharedPreferences(FILE)
        open()
    }

    private fun open(): SharedPreferences {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        return EncryptedSharedPreferences.create(
            context,
            FILE,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    fun get(): String? = prefs.getString(KEY, null)?.takeIf { it.isNotBlank() }

    fun save(apiKey: String) {
        prefs.edit().putString(KEY, apiKey.trim()).apply()
    }

    fun clear() {
        prefs.edit().remove(KEY).apply()
    }

    companion object {
        private const val FILE = "openai_secure_prefs"
        private const val KEY = "openai_api_key"

        fun mask(key: String): String =
            if (key.length <= 8) "••••" else key.take(3) + "••••••••" + key.takeLast(4)
    }
}
