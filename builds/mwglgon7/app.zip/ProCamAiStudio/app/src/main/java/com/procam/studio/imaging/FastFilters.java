package com.procam.studio.imaging;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;

/** Filtres rapides pour incruster un profil colorimétrique dans une photo. */
public final class FastFilters {

    private FastFilters() { }

    /** Applique une matrice couleur 4x5 (format android.graphics.ColorMatrix) et retourne une nouvelle bitmap. */
    public static Bitmap applyColorMatrix(Bitmap src, float[] matrix) {
        Bitmap in = ImageProcessorHelper.ensureArgb8888(src);
        Bitmap out = Bitmap.createBitmap(in.getWidth(), in.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(out);
        Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);
        paint.setColorFilter(new ColorMatrixColorFilter(new ColorMatrix(matrix)));
        canvas.drawBitmap(in, 0f, 0f, paint);
        return out;
    }

    /** Contraste (1 = neutre). */
    public static Bitmap adjustContrast(Bitmap src, float contrast) {
        float t = (1f - contrast) * 127.5f;
        float[] m = {
                contrast, 0, 0, 0, t,
                0, contrast, 0, 0, t,
                0, 0, contrast, 0, t,
                0, 0, 0, 1, 0
        };
        return applyColorMatrix(src, m);
    }

    /** Noir et blanc. */
    public static Bitmap toGrayscale(Bitmap src) {
        ColorMatrix cm = new ColorMatrix();
        cm.setSaturation(0f);
        return applyColorMatrix(src, cm.getArray());
    }
}
