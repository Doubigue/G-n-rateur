package com.procam.studio.data.local

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.procam.studio.domain.model.AspectGuide
import com.procam.studio.domain.model.GridType
import com.procam.studio.domain.model.LutProfile
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "procam_settings")

data class CameraPrefs(
    val lut: LutProfile = LutProfile.NONE,
    val grid: GridType = GridType.THIRDS,
    val aspect: AspectGuide = AspectGuide.NATIVE,
    val fps: Int = 30,
    val peaking: Boolean = false
)

class SettingsDataStore(private val context: Context) {

    private object Keys {
        val LUT = stringPreferencesKey("lut")
        val GRID = stringPreferencesKey("grid")
        val ASPECT = stringPreferencesKey("aspect")
        val FPS = intPreferencesKey("fps")
        val PEAKING = booleanPreferencesKey("peaking")
    }

    val prefs: Flow<CameraPrefs> = context.dataStore.data.map { p ->
        CameraPrefs(
            lut = p[Keys.LUT].toEnum(LutProfile.NONE),
            grid = p[Keys.GRID].toEnum(GridType.THIRDS),
            aspect = p[Keys.ASPECT].toEnum(AspectGuide.NATIVE),
            fps = p[Keys.FPS] ?: 30,
            peaking = p[Keys.PEAKING] ?: false
        )
    }

    suspend fun save(prefs: CameraPrefs) {
        context.dataStore.edit { p: androidx.datastore.preferences.core.MutablePreferences ->
            p[Keys.LUT] = prefs.lut.name
            p[Keys.GRID] = prefs.grid.name
            p[Keys.ASPECT] = prefs.aspect.name
            p[Keys.FPS] = prefs.fps
            p[Keys.PEAKING] = prefs.peaking
        }
    }

    private inline fun <reified T : Enum<T>> String?.toEnum(default: T): T =
        this?.let { name -> enumValues<T>().firstOrNull { it.name == name } } ?: default
}
