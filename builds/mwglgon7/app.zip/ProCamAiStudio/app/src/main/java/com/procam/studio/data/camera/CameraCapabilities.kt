package com.procam.studio.data.camera

data class CameraCapabilities(
    val isoRange: IntRange?,
    val shutterRangeNs: LongRange?,
    val minFocusDistance: Float,
    val manualSensorSupported: Boolean,
    val manualWbSupported: Boolean,
    val evRange: IntRange,
    val evStep: Float,
    val supportsUhd: Boolean,
    val supportedFps: List<Int>
) {
    val manualFocusSupported: Boolean get() = minFocusDistance > 0f
}
