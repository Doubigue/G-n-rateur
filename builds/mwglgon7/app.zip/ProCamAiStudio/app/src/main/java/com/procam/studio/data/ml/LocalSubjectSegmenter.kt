package com.procam.studio.data.ml

import android.content.Context
import android.graphics.Bitmap
import com.google.android.gms.common.moduleinstall.InstallStatusListener
import com.google.android.gms.common.moduleinstall.ModuleInstall
import com.google.android.gms.common.moduleinstall.ModuleInstallRequest
import com.google.android.gms.common.moduleinstall.ModuleInstallStatusUpdate
import com.google.mlkit.common.MlKitException
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.subject.SubjectSegmentation
import com.google.mlkit.vision.segmentation.subject.SubjectSegmenterOptions
import com.procam.studio.core.AppError
import com.procam.studio.core.AppResult
import com.procam.studio.domain.model.LocalBackend
import com.procam.studio.domain.model.LocalEngine
import com.procam.studio.imaging.ImageProcessorHelper
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Détourage 100 % sur l'appareil via Google ML Kit Subject Segmentation : gratuit, sans clé API,
 * la photo ne quitte pas le téléphone. Le modèle (quelques Mo) est fourni par Google Play Services
 * et téléchargé une seule fois ; ensuite tout fonctionne hors-ligne.
 */
class LocalSubjectSegmenter(private val context: Context) {

    private val selfie by lazy { BundledSelfieSegmenter() }
    private val u2net by lazy { U2NetSegmenter(context) }

    /** Moteur utilisé lors du dernier détourage. */
    @Volatile var lastBackend: LocalBackend = LocalBackend.GOOGLE_PLAY
        private set

    private val segmenter by lazy {
        SubjectSegmentation.getClient(
            SubjectSegmenterOptions.Builder()
                .enableForegroundBitmap()
                .build()
        )
    }

    /** PNG transparent : sujet pleine résolution (max 4096 px), fond entièrement transparent. */
    suspend fun cutoutTransparent(source: Bitmap, engine: LocalEngine = LocalEngine.AUTO): AppResult<Bitmap> = run(source, engine) { full, foreground ->
        ImageProcessorHelper.applyMaskFromForeground(full, foreground)
    }

    /** Fond blanc pur #FFFFFF avec ombre de contact réaliste. */
    suspend fun cutoutOnWhite(source: Bitmap, engine: LocalEngine = LocalEngine.AUTO): AppResult<Bitmap> = run(source, engine) { full, foreground ->
        val cutout = ImageProcessorHelper.applyMaskFromForeground(full, foreground)
        ImageProcessorHelper.compositeOnWhiteWithShadow(cutout)
    }

    private suspend fun run(
        source: Bitmap,
        engine: LocalEngine,
        build: (full: Bitmap, foreground: Bitmap) -> Bitmap
    ): AppResult<Bitmap> = withContext(Dispatchers.Default) {
        try {
            val full = ImageProcessorHelper.scaleToMaxSide(ImageProcessorHelper.ensureArgb8888(source), 4096)
            // La segmentation tourne sur une version réduite (rapide, peu gourmande en mémoire).
            val small = ImageProcessorHelper.scaleToMaxSide(full, 1536)
            val foreground = segment(small, engine)
                ?: return@withContext AppResult.Failure(
                    AppError.Unknown(
                        if (lastBackend == LocalBackend.SELFIE) "Aucune personne détectée (ce moteur ne gère que les personnes)"
                        else "Aucun sujet détecté dans l'image"
                    )
                )
            AppResult.Success(build(full, foreground))
        } catch (e: CancellationException) {
            throw e
        } catch (e: MlKitException) {
            AppResult.Failure(
                if (e.errorCode == MlKitException.UNAVAILABLE || e.errorCode == MlKitException.NETWORK_ISSUE)
                    AppError.ModelUnavailable
                else AppError.Unknown(e.message ?: "ML Kit")
            )
        } catch (e: OutOfMemoryError) {
            AppResult.Failure(AppError.Unknown("Mémoire insuffisante pour détourer cette image"))
        } catch (e: Exception) {
            AppResult.Failure(AppError.Unknown(e.message ?: e.javaClass.simpleName))
        }
    }

    /**
     * AUTO : Google (Play Services) puis repli automatique sur U²-Net embarqué si indisponible
     * (hors-ligne au 1er usage, pas de Play Services, échec). Sinon moteur intégré choisi.
     */
    private suspend fun segment(bitmap: Bitmap, engine: LocalEngine): Bitmap? {
        when (engine) {
            LocalEngine.AUTO -> {
                val general = try {
                    segmentGeneral(bitmap)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    null
                }
                if (general != null) {
                    lastBackend = LocalBackend.GOOGLE_PLAY
                    return general
                }
                lastBackend = LocalBackend.U2NET
                return u2net.segment(bitmap)
            }
            LocalEngine.BUNDLED_GENERAL -> {
                lastBackend = LocalBackend.U2NET
                return u2net.segment(bitmap)
            }
            LocalEngine.BUNDLED_PEOPLE -> {
                lastBackend = LocalBackend.SELFIE
                return selfie.segment(bitmap)
            }
        }
    }

    private suspend fun segmentGeneral(bitmap: Bitmap): Bitmap? {
        ensureModelReady()
        val image = InputImage.fromBitmap(bitmap, 0)
        return segmenter.process(image).await().foregroundBitmap
    }

    /** Vérifie la présence du modèle via Google Play Services ; sinon demande son installation. */
    private suspend fun ensureModelReady() {
        val client = ModuleInstall.getClient(context)
        val available = try {
            client.areModulesAvailable(segmenter).await().areModulesAvailable()
        } catch (e: Exception) {
            return // Play Services ne répond pas : on tente directement, l'erreur sera remontée.
        }
        if (available) return

        val done = CompletableDeferred<Boolean>()
        val listener = InstallStatusListener { update ->
            when (update.installState) {
                ModuleInstallStatusUpdate.InstallState.STATE_COMPLETED -> done.complete(true)
                ModuleInstallStatusUpdate.InstallState.STATE_FAILED,
                ModuleInstallStatusUpdate.InstallState.STATE_CANCELED -> done.complete(false)
                else -> Unit
            }
        }
        val request = ModuleInstallRequest.newBuilder()
            .addApi(segmenter)
            .setListener(listener)
            .build()
        val response = client.installModules(request).await()
        if (response.areModulesAlreadyInstalled()) return
        val ok = withTimeoutOrNull(120_000L) { done.await() } ?: false
        if (!ok) throw MlKitException("Téléchargement du modèle impossible", MlKitException.NETWORK_ISSUE)
    }
}
