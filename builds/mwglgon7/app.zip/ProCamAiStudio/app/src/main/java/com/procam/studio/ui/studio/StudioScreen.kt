package com.procam.studio.ui.studio

import android.content.Intent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.procam.studio.domain.model.AiPreset
import com.procam.studio.domain.model.LocalEngine
import com.procam.studio.ui.theme.CineSurface
import com.procam.studio.ui.theme.CineSurfaceHigh

@Composable
fun StudioScreen(onBack: () -> Unit, vm: StudioViewModel = viewModel()) {
    val context = LocalContext.current
    val original by vm.original.collectAsStateWithLifecycle()
    val ui by vm.ui.collectAsStateWithLifecycle()
    val busy = ui.busy != null

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 16.dp)
    ) {
        // ---------------- Barre du haut
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour", tint = Color.White)
            }
            Text("Studio IA", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            IconButton(onClick = vm::saveResult, enabled = ui.result != null && !busy) {
                Icon(Icons.Filled.Save, "Enregistrer", tint = if (ui.result != null) MaterialTheme.colorScheme.primary else Color.Gray)
            }
            IconButton(
                onClick = {
                    ui.savedUri?.let { uri ->
                        val type = context.contentResolver.getType(uri) ?: "image/*"
                        val send = Intent(Intent.ACTION_SEND).apply {
                            this.type = type
                            putExtra(Intent.EXTRA_STREAM, uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(Intent.createChooser(send, "Partager"))
                    }
                },
                enabled = ui.savedUri != null
            ) {
                Icon(Icons.Filled.Share, "Partager", tint = if (ui.savedUri != null) MaterialTheme.colorScheme.primary else Color.Gray)
            }
        }

        // ---------------- Image / comparateur
        val src = original
        if (src == null) {
            Text("Aucune photo. Prenez-en une ou importez-en depuis la galerie.", Modifier.padding(16.dp))
        } else {
            Column(Modifier.padding(horizontal = 12.dp)) {
                val result = ui.result
                if (result != null) {
                    BeforeAfterSlider(before = src, after = result)
                } else {
                    Image(
                        bitmap = src.asImageBitmap(),
                        contentDescription = "Photo originale",
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(src.width.toFloat() / src.height.toFloat())
                            .let { it },
                        contentScale = ContentScale.Crop
                    )
                }
            }
        }

        if (busy) {
            Row(
                Modifier.fillMaxWidth().padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(10.dp))
                Text(ui.busy!!.label, style = MaterialTheme.typography.bodyMedium)
            }
        }

        ui.error?.let {
            Text(
                it,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )
        }
        ui.info?.let {
            Text(it, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(horizontal = 16.dp))
        }

        // ---------------- Presets
        Text("PRESETS", style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(start = 16.dp, top = 12.dp))
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AiPreset.values().forEach { p ->
                FilterChip(
                    selected = ui.preset == p,
                    onClick = { vm.selectPreset(p) },
                    label = { Text(p.label) },
                    enabled = !busy
                )
            }
        }

        // ---------------- Traitement local (gratuit, hors-ligne)
        val localMode = ui.preset.supportsLocal && ui.useLocal
        if (ui.preset.supportsLocal) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Traitement local (gratuit)", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "ML Kit sur l'appareil : sans API, hors-ligne, la photo ne quitte pas le téléphone.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(checked = ui.useLocal, onCheckedChange = vm::setUseLocal, enabled = !busy)
            }
            if (ui.useLocal) {
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    LocalEngine.values().forEach { e ->
                        FilterChip(
                            selected = ui.localEngine == e,
                            onClick = { vm.setLocalEngine(e) },
                            label = { Text(e.label) },
                            enabled = !busy
                        )
                    }
                }
            }
        }

        // ---------------- Prompt libre
        OutlinedTextField(
            value = ui.prompt,
            onValueChange = vm::onPrompt,
            label = { Text("Instructions de retouche (optionnel)") },
            placeholder = { Text("Ex : ajoute une lumière néon bleue sur le côté et floute l'arrière-plan") },
            minLines = 3,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            enabled = !busy && !localMode
        )
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(onClick = vm::enhancePrompt, enabled = !busy, modifier = Modifier.weight(1f)) {
                Text("Améliorer mon prompt")
            }
            OutlinedButton(onClick = vm::analyze, enabled = !busy && src != null, modifier = Modifier.weight(1f)) {
                Text("Analyser & Suggérer")
            }
        }
        Button(
            onClick = vm::generate,
            enabled = !busy && src != null,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Icon(Icons.Filled.AutoAwesome, null)
            Spacer(Modifier.width(8.dp))
            Text(if (localMode) "Détourer sur l'appareil (gratuit)" else "Générer avec l'IA")
        }

        // ---------------- Suggestions GPT-4o Vision
        ui.analysisSummary?.let {
            Text(it, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        }
        ui.suggestions.forEach { s ->
            Card(
                colors = CardDefaults.cardColors(containerColor = CineSurfaceHigh),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 4.dp)
                    .clickable(enabled = !busy) { vm.useSuggestion(s) }
            ) {
                Column(Modifier.padding(12.dp)) {
                    Text(s.title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.height(4.dp))
                    Text(s.prompt, style = MaterialTheme.typography.bodyMedium, color = Color.LightGray)
                    Spacer(Modifier.height(4.dp))
                    Text("Touchez pour utiliser ce prompt", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}
