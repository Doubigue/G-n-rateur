package com.procam.studio.data.camera

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.TotalCaptureResult
import android.hardware.camera2.params.ColorSpaceTransform
import android.hardware.camera2.params.RggbChannelVector
import android.net.Uri
import android.util.Range
import android.util.Size
import android.view.Surface
import android.view.View
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.MeteringPoint
import androidx.camera.core.Preview
import androidx.camera.core.UseCase
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.procam.studio.core.AppError
import com.procam.studio.core.AppResult
import com.procam.studio.domain.model.CaptureMode
import com.procam.studio.domain.model.LutProfile
import com.procam.studio.domain.model.VideoResolution
import com.procam.studio.imaging.ImageProcessorHelper
import com.procam.studio.imaging.LumaAnalyzer
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.ln
import kotlin.math.pow

/**
 * Gestionnaire caméra : CameraX (Preview / ImageCapture / VideoCapture / ImageAnalysis)
 * + Camera2 Interop pour les contrôles manuels (ISO, vitesse, MAP, balance des blancs, verrous AE/AF/AWB).
 */
@OptIn(ExperimentalCamera2Interop::class)
class ProCameraManager(private val context: Context) {

    private val mainExecutor = ContextCompat.getMainExecutor(context)
    private val analysisExecutor: ExecutorService = Executors.newSingleThreadExecutor()

    private var provider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var activeRecording: Recording? = null
    private var previewView: PreviewView? = null

    private var currentMode = CaptureMode.PHOTO
    private var currentFps = 30
    private var controls = ManualControls()
    private var lut = LutProfile.NONE
    @Volatile private var peakingEnabled = false
    @Volatile private var lastFocusDistance = 0f
    private var resultCounter = 0
    private var frameCounter = 0

    private val _capabilities = MutableStateFlow<CameraCapabilities?>(null)
    val capabilities: StateFlow<CameraCapabilities?> = _capabilities.asStateFlow()

    private val _histogram = MutableStateFlow(IntArray(256))
    val histogram: StateFlow<IntArray> = _histogram.asStateFlow()

    private val _peaking = MutableStateFlow<Bitmap?>(null)
    val peaking: StateFlow<Bitmap?> = _peaking.asStateFlow()

    private val _readout = MutableStateFlow(Readout())
    val readout: StateFlow<Readout> = _readout.asStateFlow()

    private val _errors = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val errors: SharedFlow<String> = _errors.asSharedFlow()

    private val captureCallback = object : CameraCaptureSession.CaptureCallback() {
        override fun onCaptureCompleted(
            session: CameraCaptureSession,
            request: CaptureRequest,
            result: TotalCaptureResult
        ) {
            result.get(CaptureResult.LENS_FOCUS_DISTANCE)?.let { lastFocusDistance = it }
            if (++resultCounter % 6 != 0) return
            val iso = result.get(CaptureResult.SENSOR_SENSITIVITY) ?: return
            val time = result.get(CaptureResult.SENSOR_EXPOSURE_TIME) ?: return
            _readout.value = Readout(iso, time, lastFocusDistance)
        }
    }

    // ------------------------------------------------------------------ Liaison

    fun bind(
        owner: LifecycleOwner,
        view: PreviewView,
        mode: CaptureMode,
        frontLens: Boolean,
        resolution: VideoResolution,
        fps: Int,
        onBound: () -> Unit
    ) {
        previewView = view
        currentMode = mode
        currentFps = fps
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            try {
                val p = future.get()
                provider = p
                p.unbindAll()

                val selector = if (frontLens) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
                if (!p.hasCamera(selector)) {
                    _errors.tryEmit("Cet appareil n'a pas la caméra demandée.")
                    return@addListener
                }

                val ratio = if (mode == CaptureMode.PHOTO)
                    AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY
                else AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY

                val previewBuilder = Preview.Builder()
                    .setResolutionSelector(ResolutionSelector.Builder().setAspectRatioStrategy(ratio).build())
                Camera2Interop.Extender(previewBuilder).setSessionCaptureCallback(captureCallback)
                val preview = previewBuilder.build().also { it.surfaceProvider = view.surfaceProvider }

                val analysis = buildAnalysis(ratio)
                val useCases = mutableListOf<UseCase>(preview, analysis)

                if (mode == CaptureMode.PHOTO) {
                    videoCapture = null
                    val capture = ImageCapture.Builder()
                        .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                        .setResolutionSelector(
                            ResolutionSelector.Builder()
                                .setAspectRatioStrategy(ratio)
                                .setResolutionStrategy(
                                    ResolutionStrategy(
                                        Size(4000, 3000),
                                        ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER
                                    )
                                )
                                .build()
                        )
                        .build()
                    imageCapture = capture
                    useCases += capture
                } else {
                    imageCapture = null
                    val quality = if (resolution == VideoResolution.UHD) Quality.UHD else Quality.FHD
                    val recorder = Recorder.Builder()
                        .setQualitySelector(
                            QualitySelector.from(quality, FallbackStrategy.lowerQualityOrHigherThan(Quality.HD))
                        )
                        .build()
                    val vc = VideoCapture.Builder(recorder)
                        .setTargetFrameRate(Range(fps, fps))
                        .build()
                    videoCapture = vc
                    useCases += vc
                }

                val bound = p.bindToLifecycle(owner, selector, *useCases.toTypedArray())
                camera = bound
                _capabilities.value = readCapabilities(bound)
                applyLutToView()
                onBound()
            } catch (e: Exception) {
                _errors.tryEmit("Impossible d'ouvrir la caméra : ${e.message}")
            }
        }, mainExecutor)
    }

    private fun buildAnalysis(ratio: AspectRatioStrategy): ImageAnalysis {
        val analysis = ImageAnalysis.Builder()
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888)
            .setResolutionSelector(
                ResolutionSelector.Builder()
                    .setAspectRatioStrategy(ratio)
                    .setResolutionStrategy(
                        ResolutionStrategy(Size(640, 480), ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER)
                    )
                    .build()
            )
            .build()
        analysis.setAnalyzer(analysisExecutor) { image -> analyze(image) }
        return analysis
    }

    private fun analyze(image: ImageProxy) {
        try {
            val plane = image.planes[0]
            val w = image.width
            val h = image.height
            _histogram.value = LumaAnalyzer.histogram(plane.buffer, w, h, plane.rowStride, plane.pixelStride, 4)
            if (peakingEnabled && ++frameCounter % 3 == 0) {
                _peaking.value = LumaAnalyzer.focusPeaking(
                    plane.buffer, w, h, plane.rowStride, plane.pixelStride,
                    image.imageInfo.rotationDegrees, 60
                )
            }
        } catch (_: Exception) {
            // Une frame ratée ne doit jamais faire planter l'aperçu.
        } finally {
            image.close()
        }
    }

    // ------------------------------------------------------------------ Capacités matérielles

    private fun readCapabilities(cam: Camera): CameraCapabilities {
        val c2 = Camera2CameraInfo.from(cam.cameraInfo)
        val iso = c2.getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
        val exp = c2.getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
        val minFocus = c2.getCameraCharacteristic(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
        val caps = c2.getCameraCharacteristic(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)
        val manualSensor = caps?.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR) == true
        val manualPost = caps?.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_POST_PROCESSING) == true

        val ev = cam.cameraInfo.exposureState
        val evRange = ev.exposureCompensationRange
        val ranges = cam.cameraInfo.supportedFrameRateRanges
        val fps = listOf(24, 30, 60).filter { f -> ranges.any { it.contains(f) } }
        val uhd = QualitySelector.getSupportedQualities(cam.cameraInfo).contains(Quality.UHD)

        return CameraCapabilities(
            isoRange = iso?.let { it.lower..it.upper },
            shutterRangeNs = exp?.let { it.lower..it.upper },
            minFocusDistance = minFocus,
            manualSensorSupported = manualSensor,
            manualWbSupported = manualPost,
            evRange = evRange.lower..evRange.upper,
            evStep = ev.exposureCompensationStep.toFloat(),
            supportsUhd = uhd,
            supportedFps = fps.ifEmpty { listOf(30) }
        )
    }

    // ------------------------------------------------------------------ Contrôles manuels (Camera2 Interop)

    /** Ré-applique l'ensemble des réglages manuels (les options Camera2 sont remplacées en bloc). */
    fun applyManual(c: ManualControls) {
        controls = c
        val cam = camera ?: return
        val caps = _capabilities.value
        val b = CaptureRequestOptions.Builder()

        // Exposition
        val manualExposure = caps?.manualSensorSupported == true && (!c.isoAuto || !c.shutterAuto)
        if (manualExposure) {
            val live = _readout.value
            val isoRange = caps!!.isoRange
            val expRange = caps.shutterRangeNs
            var iso = if (c.isoAuto) live.iso else c.iso
            var time = if (c.shutterAuto) live.shutterNs else c.shutterNs
            if (isoRange != null) iso = iso.coerceIn(isoRange.first, isoRange.last)
            if (expRange != null) time = time.coerceIn(expRange.first, expRange.last)
            val frameNs = 1_000_000_000L / currentFps
            if (currentMode == CaptureMode.VIDEO && time > frameNs) time = frameNs
            b.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_OFF)
            b.setCaptureRequestOption(CaptureRequest.SENSOR_SENSITIVITY, iso)
            b.setCaptureRequestOption(CaptureRequest.SENSOR_EXPOSURE_TIME, time)
            if (currentMode == CaptureMode.VIDEO) {
                b.setCaptureRequestOption(CaptureRequest.SENSOR_FRAME_DURATION, frameNs)
            }
        } else if (c.aeLock) {
            b.setCaptureRequestOption(CaptureRequest.CONTROL_AE_LOCK, true)
        }

        // Mise au point
        if (caps?.manualFocusSupported == true && !c.focusAuto) {
            b.setCaptureRequestOption(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_OFF)
            b.setCaptureRequestOption(
                CaptureRequest.LENS_FOCUS_DISTANCE,
                c.focusDistance.coerceIn(0f, caps.minFocusDistance)
            )
        } else if (c.afLock && caps?.manualFocusSupported == true) {
            b.setCaptureRequestOption(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_OFF)
            b.setCaptureRequestOption(
                CaptureRequest.LENS_FOCUS_DISTANCE,
                lastFocusDistance.coerceIn(0f, caps.minFocusDistance)
            )
        }

        // Balance des blancs
        if (c.wbMode == WhiteBalanceMode.KELVIN && caps?.manualWbSupported == true) {
            b.setCaptureRequestOption(CaptureRequest.CONTROL_AWB_MODE, CameraMetadata.CONTROL_AWB_MODE_OFF)
            b.setCaptureRequestOption(
                CaptureRequest.COLOR_CORRECTION_MODE, CameraMetadata.COLOR_CORRECTION_MODE_TRANSFORM_MATRIX
            )
            b.setCaptureRequestOption(CaptureRequest.COLOR_CORRECTION_GAINS, kelvinToGains(c.kelvin))
            b.setCaptureRequestOption(CaptureRequest.COLOR_CORRECTION_TRANSFORM, IDENTITY_TRANSFORM)
        } else {
            val mode = c.wbMode.awbMode ?: CameraMetadata.CONTROL_AWB_MODE_AUTO
            b.setCaptureRequestOption(CaptureRequest.CONTROL_AWB_MODE, mode)
            if (c.aeLock) b.setCaptureRequestOption(CaptureRequest.CONTROL_AWB_LOCK, true)
        }

        try {
            Camera2CameraControl.from(cam.cameraControl).setCaptureRequestOptions(b.build())
            if (!manualExposure) cam.cameraControl.setExposureCompensationIndex(c.evIndex)
        } catch (e: Exception) {
            _errors.tryEmit("Réglage refusé par le matériel : ${e.message}")
        }
    }

    /** Autofocus par toucher (ignoré si la mise au point est manuelle). */
    fun tapToFocus(point: MeteringPoint) {
        if (!controls.focusAuto) return
        val action = FocusMeteringAction.Builder(point).build()
        camera?.cameraControl?.startFocusAndMetering(action)
    }

    /** Conversion Kelvin → gains RGGB (approximation d'un corps noir, algorithme de Tanner Helland). */
    private fun kelvinToGains(kelvin: Int): RggbChannelVector {
        val t = kelvin.coerceIn(1500, 15000) / 100.0
        val r = if (t <= 66) 255.0 else 329.698727446 * (t - 60).pow(-0.1332047592)
        val g = if (t <= 66) 99.4708025861 * ln(t) - 161.1195681661
        else 288.1221695283 * (t - 60).pow(-0.0755148492)
        val b = when {
            t >= 66 -> 255.0
            t <= 19 -> 1.0
            else -> 138.5177312231 * ln(t - 10) - 305.0447927307
        }
        val rr = r.coerceIn(1.0, 255.0)
        val gg = g.coerceIn(1.0, 255.0)
        val bb = b.coerceIn(1.0, 255.0)
        // Le gain compense la dominante de l'illuminant.
        val rGain = (gg / rr).toFloat().coerceIn(0.3f, 4f)
        val bGain = (gg / bb).toFloat().coerceIn(0.3f, 4f)
        return RggbChannelVector(rGain, 1f, 1f, bGain)
    }

    // ------------------------------------------------------------------ LUT temps réel (GPU)

    fun setLut(profile: LutProfile) {
        lut = profile
        applyLutToView()
    }

    /** Filtre couleur matériel appliqué à la couche de rendu de l'aperçu (mode COMPATIBLE / TextureView). */
    private fun applyLutToView() {
        val view = previewView ?: return
        view.post {
            if (lut == LutProfile.NONE) {
                view.setLayerType(View.LAYER_TYPE_NONE, null)
            } else {
                val paint = Paint().apply { colorFilter = ColorMatrixColorFilter(lut.colorMatrix()) }
                view.setLayerType(View.LAYER_TYPE_HARDWARE, paint)
            }
        }
    }

    fun setPeaking(enabled: Boolean) {
        peakingEnabled = enabled
        if (!enabled) _peaking.value = null
    }

    // ------------------------------------------------------------------ Photo

    fun takePhoto(onResult: (AppResult<Bitmap>) -> Unit) {
        val capture = imageCapture
            ?: return onResult(AppResult.Failure(AppError.Unknown("Le mode photo n'est pas actif")))
        capture.targetRotation = previewView?.display?.rotation ?: Surface.ROTATION_0
        capture.takePicture(analysisExecutor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                try {
                    val rotation = image.imageInfo.rotationDegrees
                    val bitmap = ImageProcessorHelper.rotate(image.toBitmap(), rotation)
                    onResult(AppResult.Success(bitmap))
                } catch (e: Exception) {
                    onResult(AppResult.Failure(AppError.Unknown(e.message ?: "Traitement de la photo")))
                } finally {
                    image.close()
                }
            }

            override fun onError(exception: ImageCaptureException) {
                onResult(AppResult.Failure(AppError.Unknown(exception.message ?: "Capture impossible")))
            }
        })
    }

    // ------------------------------------------------------------------ Vidéo

    val isRecording: Boolean get() = activeRecording != null

    @SuppressLint("MissingPermission")
    fun startRecording(options: MediaStoreOutputOptions, onFinished: (AppResult<Uri>) -> Unit) {
        val vc = videoCapture
            ?: return onFinished(AppResult.Failure(AppError.Unknown("Le mode vidéo n'est pas actif")))
        var pending = vc.output.prepareRecording(context, options)
        val hasAudio = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (hasAudio) pending = pending.withAudioEnabled()
        activeRecording = pending.start(mainExecutor) { event ->
            if (event is VideoRecordEvent.Finalize) {
                activeRecording = null
                if (event.hasError()) {
                    onFinished(AppResult.Failure(AppError.Unknown("Enregistrement interrompu (code ${event.error})")))
                } else {
                    onFinished(AppResult.Success(event.outputResults.outputUri))
                }
            }
        }
    }

    fun stopRecording() {
        activeRecording?.stop()
    }

    fun release() {
        activeRecording?.stop()
        provider?.unbindAll()
        analysisExecutor.shutdown()
    }

    private companion object {
        /** Matrice identité 3x3 en rationnels (numérateur, dénominateur). */
        val IDENTITY_TRANSFORM = ColorSpaceTransform(
            intArrayOf(
                1, 1, 0, 1, 0, 1,
                0, 1, 1, 1, 0, 1,
                0, 1, 0, 1, 1, 1
            )
        )
    }
}
