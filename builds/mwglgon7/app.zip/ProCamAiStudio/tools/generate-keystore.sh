#!/usr/bin/env bash
# Génère la clé de signature dédiée de ProCam AI Studio (à exécuter UNE fois, sur votre machine).
# Les mots de passe sont saisis par vous : rien n'est écrit en clair dans le dépôt.
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p keystore
OUT="keystore/procam-release.jks"
[ -e "$OUT" ] && { echo "Existe déjà : $OUT (refus d'écraser)"; exit 1; }

keytool -genkeypair -v \
  -keystore "$OUT" -alias procam \
  -keyalg RSA -keysize 4096 -validity 10000 \
  -dname "CN=ProCam AI Studio, O=ProCam, C=FR"

read -rsp "Rappel du mot de passe du keystore : " PW; echo
cat > keystore.properties <<PROPS
storeFile=$OUT
storePassword=$PW
keyAlias=procam
keyPassword=$PW
PROPS
chmod 600 keystore.properties "$OUT"
echo "OK. Sauvegardez keystore/ et gardez-le HORS du dépôt : perdre cette clé = impossible de mettre à jour l'app."
echo "Build signé : ./gradlew assembleRelease   (ou bundleRelease pour le Play Store)"
