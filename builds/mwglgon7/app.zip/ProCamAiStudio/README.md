# ProCam AI Studio

Application Android native : caméra pro (CameraX + Camera2 Interop) et Studio IA (OpenAI gpt-image-1 / GPT-4o).

## Ouvrir et compiler
1. Android Studio Ladybug (2024.2) ou plus récent, JDK 17.
2. `File > Open` sur ce dossier. Au premier sync, Android Studio propose de configurer Gradle : acceptez
   (le projet cible Gradle 8.9 / AGP 8.7.3 / Kotlin 2.0.21). Le `gradle-wrapper.jar` n'est pas inclus :
   si besoin, `gradle wrapper` depuis la racine, ou laissez Android Studio le générer.
3. Appareil physique recommandé (Android 8.0+, API 26+). Les contrôles manuels exigent un appareil dont
   le niveau Camera2 expose MANUAL_SENSOR ; sinon les molettes concernées sont désactivées.
4. Dans l'app : icône clé (haut gauche) → coller la clé `sk-...` → « Vérifier la connexion » → « Enregistrer ».

## Traitement local gratuit (ML Kit)
Les presets **PNG transparent** et **Fond blanc pur** peuvent s'exécuter sur le téléphone avec
Google ML Kit Subject Segmentation : aucune clé API, aucun coût, la photo n'est pas envoyée.
- Un interrupteur « Traitement local (gratuit) » apparaît dans le Studio IA (activé par défaut).
- Le masque est calculé sur une version réduite puis appliqué à l'image **pleine résolution** (max 4096 px).
- Le fond blanc ajoute une ombre de contact et une ombre diffuse légère.
- Le modèle est fourni par Google Play Services : téléchargé **une seule fois** (demandé à l'installation via
  le manifeste, ou au premier usage si besoin), puis 100 % hors-ligne. Appareil sans Play Services : utilisez le mode Cloud.
- **Modèle embarqué (100 % hors-ligne)** : Subject Segmentation n'existe qu'en version Play Services (aucune
  variante « bundled » chez Google). L'APK embarque donc en plus ML Kit **Selfie Segmentation** (+ ~4,5 Mo) :
  fonctionne sans réseau ni Play Services dès le premier lancement, mais **uniquement pour les personnes**.
  - **Modèle embarqué tous sujets (U²-Net-P)** : `assets/u2netp.onnx` (4,6 Mo, SHA-256
  `309c8469258dda742793dce0ebea8e6dd393174f89934733ecc8b14c76f4ddd8`) exécuté par ONNX Runtime
  (+ ~15–20 Mo d'APK selon les ABI ; ajoutez `ndk { abiFilters += listOf("arm64-v8a") }` pour réduire).
  Objets, animaux, produits, personnes ; qualité des bords inférieure au modèle Google et à gpt-image-1.
  Licences : U²-Net (X. Qin et al.) Apache-2.0 ; ONNX Runtime MIT ; fichier .onnx issu des releases de rembg (MIT).
  « Auto » = Google puis repli U²-Net ; « Intégré · tous sujets » = U²-Net seul ; « Intégré · personnes » = Selfie.
- ML Kit Subject Segmentation est en version bêta ; la qualité des bords (cheveux, poils) est inférieure à gpt-image-1.

## Clé de signature dédiée et logo
- **Logo** : icône adaptative (objectif à diaphragme + éclat IA, fond sombre, variante monochrome Android 13+)
  dans `res/drawable` et `res/mipmap-anydpi-v26`. `branding/logo_512.png` sert pour la fiche Play Store ;
  `python3 branding/make_logo.py` régénère le tout.
- **Clé release** : lancez une fois `tools/generate-keystore.sh` (crée `keystore/procam-release.jks` et
  `keystore.properties`, tous deux ignorés par git), puis `./gradlew assembleRelease` ou `bundleRelease`.
  En CI, utilisez les variables `PROCAM_KEYSTORE_FILE`, `PROCAM_KEYSTORE_PASSWORD`, `PROCAM_KEY_ALIAS`,
  `PROCAM_KEY_PASSWORD`. **Sauvegardez le keystore** : sans lui, plus aucune mise à jour possible.
  Sans clé configurée, le build release reste simplement non signé.

## Notes importantes
- **gpt-image-1** exige en général une organisation OpenAI vérifiée (erreur 403 sinon, affichée clairement).
- Les LUT sont appliquées **en temps réel à l'aperçu** (filtre matriciel GPU sur la couche de rendu) et
  **incrustées dans les photos** (Java `FastFilters`). Elles ne sont **pas incrustées dans les vidéos
  enregistrées** : cela demanderait un pipeline OpenGL/CameraEffect dédié (non inclus).
- « Log/Flat » est un rendu plat simulé par matrice, pas un vrai profil log du capteur.
- Les cadres 16:9, 9:16 et 2.39:1 recadrent les photos ; en vidéo ils servent de guide visuel.
- Le focus peaking, l'histogramme et le niveau à bulle sont calculés en direct (plan Y de ImageAnalysis, accéléromètre).
- La clé API est stockée via `EncryptedSharedPreferences` (AES-256) et n'est jamais journalisée
  (en-tête `Authorization` masqué dans les logs de debug).
- Code non compilé ni testé sur appareil au moment de la livraison : prévoyez un premier cycle de
  corrections mineures (versions de dépendances, API selon votre SDK).
