package com.example.mydm

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Modifier
import com.example.mydm.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MyDMTheme { Root() } }
    }
}

private val tabs = listOf("🌐" to "Navigateur", "⬇️" to "Téléchargements", "💬" to "Statuts", "🧲" to "Torrent")

@Composable
private fun Root() {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) notif.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Bg) {
                tabs.forEachIndexed { i, (icon, label) ->
                    NavigationBarItem(tab == i, { tab = i }, icon = { Text(icon) }, label = { Text(label) })
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            // Le navigateur reste composé pour conserver la page et la détection en cours
            Box(Modifier.fillMaxSize().then(if (tab == 0) Modifier else Modifier.size(0.dp))) { BrowserScreen() }
            when (tab) {
                1 -> DownloadsScreen()
                2 -> StatusScreen()
                3 -> TorrentScreen()
            }
        }
    }
}
