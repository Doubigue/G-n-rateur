# MyDM — Navigateur & Gestionnaire de téléchargements (Kotlin / Compose)

Ouvrir le dossier dans **Android Studio (Ladybug+)**, laisser la synchro Gradle se faire (génère le wrapper), puis Run sur un appareil Android 10+ (API 29).

- `browser/` WebView + sniffer (shouldInterceptRequest + JS injecté)
- `downloader/` moteur multi-segments (Range) + Foreground Service
- `whatsapp/` statuts via Storage Access Framework
- `ui/` thème sombre « glass » + écrans Compose

Limites connues : HLS (.m3u8) détecté mais pas téléchargé ; pas de DRM.

## Version 2.2 — correctifs
- **Torrent** : un magnet / `.torrent` (fichier, lien http, hash, partage, clic dans une page web) démarre **tout de suite** — plus d'étape « Analyser ». Les fichiers se décochent ensuite (bouton *Fichiers*). Le clic sur un lien `magnet:` dans le navigateur était ignoré : corrigé. Trackers publics ajoutés aux magnets, 8 essais de recherche de pairs, erreurs affichées dans la carte du torrent, torrents mémorisés (reprise après redémarrage), fin signalée par notification.
- **Coupure de connexion** : les téléchargements (directs, yt-dlp) et torrents se mettent en pause automatiquement (« ⏸ En pause : pas de connexion ») et repartent seuls au retour du réseau (Wi-Fi uniquement respecté).
- **Téléphone éteint / appli tuée** : les tâches interrompues sont relancées au prochain démarrage (service redémarré par Android, ou au lancement de l'appli).
- **Arrière-plan** : services au premier plan de type `specialUse` (pas de limite de 6 h d'Android 15), verrou CPU + Wi-Fi pendant les transferts, demande « sans restriction de batterie » (une fois, puis dans Paramètres).
- **Liens partagés** : un lien partagé vers MyDM est téléchargé directement (fichier direct, vidéo YouTube/Facebook/TikTok en meilleure qualité, magnet, .torrent). Une simple page web s'ouvre dans le navigateur comme avant. Réglable dans Paramètres. Le bandeau du presse-papiers propose « Télécharger » et « Analyser ».
- **Barre d'onglets** : icônes agrandies.

## Téléchargeur (pastille ⬇)
- Détection par extension, balises vidéo/audio **et Content-Type** (fichiers sans extension).
- Pastille « ⬇ » sur le navigateur : liste des médias, taille au clic, bouton Télécharger.
- Liens YouTube / Facebook / TikTok / HLS (m3u8) : analyse par yt-dlp (qualités + tailles), MP4 / M4A / MP3.
- Statuts WhatsApp : tous les dossiers `.Statuses` sont fusionnés et triés du plus récent au plus ancien.

## Onglets & paramètres
- Onglets : bouton compteur dans la barre d'adresse → grille d'onglets (miniatures, fermer, nouvel onglet). Les liens `target=_blank` / `window.open` ouvrent un nouvel onglet. Chaque onglet a sa propre liste de médias détectés.
- Paramètres (menu ⋮ du navigateur) : page d'accueil, moteur de recherche, mode ordinateur, blocage des pop-ups, restauration des onglets, nombre de connexions par téléchargement, effacement cookies/cache/médias.

## Version 2 — nouveautés
- **Page Téléchargements** : 3 onglets — *À télécharger* (médias détectés dans tous les onglets, taille, « Tout télécharger »), *Téléchargements* (en cours / terminés), *Dossiers*.
- **Pastille** sur l'onglet Téléchargements (nombre en cours, sinon médias détectés) et sur Torrent.
- **Dossiers** : `Download/MyDM/` → `Vidéo made/Statuts` (photos, vidéos), `Vidéo`, `Torrent/<Vidéos|Applications|Logiciels|Jeux|Documents|…>`, `Documents`, `Images`, `Musiques`, `Autres` (+ `Autres/Sites` pour les ZIP de sites). Classement automatique par type de fichier.
- **Notification** : « N en cours • % • vitesse », 5 premières lignes (nom • % • taille), « +N autres », pastille (setNumber), bouton « Tout mettre en pause ».
- **ZIP d'un site** (menu ⋮ du navigateur) : index.html (DOM rendu, liens réécrits en local), source.html, CSS/JS/images/polices, console.txt, _info.txt.
- **Console** (menu ⋮) : console.log / erreurs de la page, exécution de JavaScript, copie du HTML.
- **Liens externes** : http/https (navigateur par défaut), partage de texte/lien, `magnet:`, fichiers `.torrent`, partage d'une photo (recherche par image).
- **Recherche par photo** : Google Lens / Bing Visual / TinEye / Yandex ; la photo choisie est envoyée automatiquement au bouton « importer » de la page.
- **Extensions** : scripts utilisateur (type Tampermonkey) — Paramètres > Développeur. Les extensions Chrome (.crx) ne tournent pas dans une WebView.
- **Paramètres** : limite de vitesse, téléchargements simultanés, Wi-Fi uniquement, dossier principal, JS/images/zoom, blocage pubs, types détectés, etc.

## Version 2.1 — nouveautés
- **Analyse de liens plus rapide** (YouTube / Facebook / TikTok) : pré-analyse dès l'ouverture de la page vidéo, cache 15 min, analyse automatique à l'ouverture de la fenêtre, options yt-dlp « rapides », mise à jour de yt-dlp au plus 1×/jour et différée (elle ne concurrence plus la 1re analyse), 8 fragments simultanés au téléchargement.
- **Télécharger sans lire la vidéo** (cinezzz, papadustream…) : « Analyser » charge la page dans une WebView invisible, lance les lecteurs en sourdine, écoute le réseau, lit le DOM et teste les lecteurs intégrés (iframes) ; repli yt-dlp pour les hébergeurs connus (voe, streamtape, doodstream, uqload, vidoza…).
- **Séries d'un coup** : menu ⋮ → « 📺 Série », ou détection automatique dans « Analyser ». Choix des épisodes, nom de série, puis analyse en arrière-plan de chaque épisode et mise en file des téléchargements dans `Vidéo/<Série>/` (S01E05…).
- **Lecteur intégré** : vidéo / audio (Media3 ExoPlayer, reprise de position, lecture suivante auto), images (balayage, zoom), PDF, texte, **installation d'APK**.
- **Fichiers externes** : MyDM apparaît dans « Ouvrir avec » pour vidéo, audio, image, PDF, texte, APK ; partage de fichiers vers MyDM ; bouton « Ouvrir un fichier du téléphone » (Dossiers).
- **Bibliothèque** : miniatures, recherche, tri, espace disque, confirmation de suppression.
- **Nouveau design** : thèmes Auto / Sombre / Noir pur / Clair, 6 couleurs d'accent, cartes arrondies.
- **Paramètres** : Apparence, Analyse & séries, Lecteur intégré, bandeau « lien copié », mise à jour yt-dlp.

Limites : les sites protégés (Cloudflare, captcha, DRM) peuvent bloquer l'analyse automatique ; ouvrez la page une fois dans le navigateur pour valider le contrôle, puis relancez. Le lecteur ne gère pas AVI/WMV (bouton « Ouvrir avec… »).

## Version 2.2 — correctifs
- **Séries** : seuls les épisodes de la série affichée sont proposés (les « derniers épisodes » d'autres séries sont écartés) ; à la racine d'une saison, seule cette saison est listée ; un épisode en double garde sa version française ; épisodes VOSTFR/VO décochés par défaut (puces 🇫🇷 Français et S1, S2… dans la feuille Série).
- **Pop-ups / pages bizarres** : blocage activé par défaut. Pop-ups et redirections automatiques vers d'autres sites ignorés ; un lien du même site cliqué par vous s'ouvre dans l'onglet courant ; schémas intent:// / market:// refusés ; liste de régies publicitaires étendue ; la WebView d'analyse ne suit aucune fenêtre ni détournement.
- **Analyse d'un épisode** : lecteurs triés (hébergeurs connus d'abord), lecteurs imbriqués explorés, 5 lecteurs / 10 s par défaut ; plus de téléchargement yt-dlp lancé sur un lecteur inconnu (message clair à la place de « flux vidéo absent »).
- **Plus d'ajout automatique** à « À télécharger » : Paramètres > Types détectés > « Détection automatique en naviguant » (désactivé par défaut). Le bouton ⬇ lance l'analyse de la page.
- **Choix du lecteur (cinezzz…)** : sur une page d'épisode, la liste des lecteurs est lue (nom + drapeau). Ordre d'essai : **Uqload en français**, sinon le **premier lecteur français** (VOE…), puis les suivants si rien n'est trouvé (3 lecteurs au plus) ; la version VO/anglaise n'est utilisée qu'en dernier.
- **Séries** : le téléchargement de plusieurs épisodes est désactivé (menu retiré, carte « épisodes détectés » masquée). L'application ne propose que la vidéo en cours de lecture sur la page.
- **Plus de choix automatique de lecteur** : vous choisissez le lecteur dans la page. La fenêtre ⬇ affiche uniquement **la vidéo en cours de lecture** (la dernière détectée dans l'onglet, effacée au changement de page). Aucune analyse automatique à l'ouverture sur les sites de séries ; « Analyser » ne sert plus que pour un lien collé.
- **Durée / minutage** : la durée de la vidéo est lue (playlist HLS ou métadonnées du fichier). Les vidéos de **2 min ou moins** détectées en navigation sont ignorées (publicités) — pas sur YouTube, Facebook, TikTok, Instagram, X/Twitter, Vimeo, Dailymotion, Twitch. La durée et le temps restant s'affichent dans la liste des téléchargements et **dans la notification**.
- **Qualité** : si le flux HLS en propose plusieurs (720p, 1080p…), la fenêtre ⬇ liste les qualités ; sinon un seul bouton Télécharger.
- **Onglet « Vidéos »** (à côté du navigateur, comme VidMate) : recherche YouTube (Vidéos / Listes de lecture) ou collage d'un lien de vidéo, playlist, chaîne ou compte. La liste est lue « à plat » par yt-dlp (des centaines d'entrées en quelques secondes) ; cochez une par une ou « Tout », choisissez la qualité commune (meilleure, 1080p…360p, MP3, M4A) et téléchargez en un seul geste. Une liste ouverte crée un dossier du nom de la playlist. Les téléchargements respectent le nombre de simultanés réglé dans les paramètres (3 par défaut) ; les autres attendent en file.

## Version 2.3 — capture « comme 1DM »
- **Capture complète pendant la lecture** : dès que vous lancez la vidéo dans le lecteur de la page, tout ce qu'il charge est listé par onglet — flux HLS (une ligne **par qualité** : résolution 1916x1076 / 1280x720 / 640x360, taille estimée, nombre de pièces, durée), fichiers vidéo et **sous-titres** (.vtt / .srt). La pastille ⬇ affiche « N fichier(s) détecté(s) ».
- **Fenêtre « Fichier(s) détectés ! »** : cases à cocher + « Tout sélectionner », menu ⋮ (copier le lien, retirer), TOUT EFFACER, TRIER (arrivée / type / nom), FERMER.
- **Fenêtre « Télécharger le(s) fichier(s) ! »** : lien (copiable), nom = titre de la page (modifiable), extension, taille (pièces, durée), stockage libre, dossier de destination, COMMENCER. Plusieurs fichiers cochés = un seul geste.
- La liste se vide au changement de page ; les vidéos de 2 min ou moins (publicités) restent ignorées.

### Onglet « Vidéos » refait comme VidMate (v2.3)
- Barre : ‹ retour, recherche arrondie, ⬇ (téléchargements). Onglets : **Tout / Liste de lecture / Instagram / Facebook / Image / Google**.
- **Tout** : grandes cartes 16:9 (miniature, durée, ▶), ligne titre + chaîne + bouton ⬇ (choix de la qualité) ; playlists en carte « pile » avec « N Vidéos » ; puces Durée et Pertinence/Durée.
- **Liste de lecture** : lignes compactes (miniature + nombre de vidéos + ⬇).
- **Écran « Sélectionné »** (playlist, chaîne ou lien collé) : toutes les vidéos cochées, « Tout Sélectionner », compteur 100/100, bouton rouge **FAIT** → qualité → file de téléchargement dans un dossier du nom de la liste.
- Instagram / Facebook / Image / Google : recherche ouverte dans un onglet du navigateur.
- **Sites de streaming (cinezzz, papadustream…)** : (1) le téléchargement rejoue maintenant le **Referer / Origin réel du lecteur** (uqload, voe… refusaient l'adresse de la page) ; (2) le script de détection est injecté **dans les iframes** (androidx.webkit) et repère aussi les playlists/vidéos sans extension via leur Content-Type ; (3) les **pubs** (hôtes publicitaires, adresses vast / preroll / ads, fichiers < 3 Mo sans durée, ≤ 2 min) ne sont plus captées ; (4) la vidéo affichée n'est plus « la dernière détectée » mais **la meilleure** (durée longue, flux maître HLS, gros fichier, hébergeur connu) et passe en tête de « Fichier(s) détectés ».
- **Clip « Direct HLS needs Premium » (uqload)** : c'est le message que l'hébergeur renvoie quand la requête n'a pas les en-têtes de son vrai lecteur. Le téléchargement rejoue désormais Referer + Origin + **cookies** + User-Agent du lecteur (aussi pour les flux HLS via yt-dlp) ; si le script de l'iframe connaît un référent plus précis que la requête, il remplace l'ancien.
- **Nom des fichiers** : le titre de la page est nettoyé (« Regarder Mon Film (2023) en streaming VF complet HD - Cinezzz : synopsis… » → « Mon Film (2023) »), en s'aidant de l'adresse de la page ; saison/épisode ajoutés au format `Ma Série S02E05`. Utilisé dans la fenêtre « Télécharger le(s) fichier(s) », la liste des fichiers détectés et les téléchargements.
- **Séries par saison** : menu ⋮ → « 📺 Série : télécharger une saison » (ou carte « Série » dans l'analyse de page). Une carte par saison avec un seul bouton ; l'analyse choisit le lecteur de chaque épisode (Uqload en français, sinon le premier, jusqu'à 3 essais) et classe dans `Série/Saison 02/`. Les épisodes VOSTFR sont ignorés par défaut.

## Version 2.4 — programmation des téléchargements & taille des flux

- **Programmer un téléchargement** : dans la fenêtre « Télécharger » et dans « À télécharger », la barre **⏰ Début du téléchargement** permet de choisir l'heure de départ (dans 1 h, ce soir 23:00, cette nuit 03:00, ou date + heure précises). Les boutons ⬇ / « Télécharger » programment alors au lieu de démarrer.
- **Dans « Téléchargements »** : bouton **⏰ Programmer** sur chaque téléchargement non terminé ; **☑ Sélectionner** pour cocher plusieurs fichiers puis **⏰ Programmer (n)** ou **▶ Démarrer**. Un téléchargement programmé affiche « ⏰ Programmé demain à 03:00 » avec **Démarrer maintenant**, **Modifier**, **Annuler l'heure**.
- **Fonctionnement** : alarme système (heure exacte, même téléphone en veille) ; les alarmes sont remises après un redémarrage du téléphone ou une mise à jour de l'appli. Les réglages « Wi-Fi uniquement » et « téléchargements simultanés » restent respectés au départ.
- **Taille avant de télécharger** : la taille s'affiche maintenant aussi pour les flux HLS (vidéo en cours de lecture, fichiers trouvés, chaque qualité). Elle est **estimée** (précédée de « ~ ») : débit annoncé × durée, ou mesure de quelques segments. Cette taille est conservée dans la liste des téléchargements, puis remplacée par la taille réelle à la fin.
- **Onglets** : l'écran Téléchargements a maintenant **À télécharger • En cours • Terminés • Dossiers**. « En cours » regroupe les téléchargements actifs, en pause, programmés ou en échec ; « Terminés » les fichiers finis (avec « Effacer les terminés »).

## Version 2.5 — liens partagés, styles, simplification
- **Lien partagé = téléchargement automatique** : partagez une vidéo Facebook (y compris `facebook.com/share/v/…`, `fb.watch`, `fb.me`), TikTok (`vm.tiktok.com`, `vt.tiktok.com`), Instagram, YouTube, X, Reddit, Pinterest, Snapchat, Threads, Dailymotion, Vimeo, Twitch, Rumble, Streamable… vers MyDM : la meilleure qualité démarre aussitôt (onglet Téléchargements). Pour tout autre site, yt-dlp est tenté automatiquement (≈1000 sites) ; sinon la page s'ouvre dans le navigateur avec un message.
- **Barre d'onglets** : icônes beaucoup plus grandes (40 sp), pastille de sélection et compteur.
- **Styles complets** (Paramètres > Apparence) : 14 styles qui changent le **fond, les cartes, la couleur du texte et l'accent** — Auto, Sombre, Noir pur, Clair, Océan, Forêt, Crépuscule, Minuit, Café, Graphite, Rose bonbon, Menthe, Papier, Ciel. Aperçu de chaque style dans le sélecteur ; la couleur d'accent reste réglable à part (« Selon le style » par défaut). Les icônes de la barre d'état suivent le style.
- **Retiré** : le téléchargement par saison / série (menu ⋮, carte « Série », réglages) et tout **Torrent** (onglet, moteur, service, magnet / .torrent, dossier Torrent, bibliothèque jlibtorrent → APK plus léger).

## Version 2.6 — relance automatique des téléchargements
- **Plus besoin d'appuyer sur « Reprendre »** : une erreur temporaire (serveur indisponible 503, trop de requêtes 429, erreurs 500/502/504, délai dépassé, coupure) ne met plus le téléchargement en échec. MyDM patiente puis recommence là où il s'était arrêté (les morceaux déjà reçus sont conservés).
- **Attente progressive** : 15 s, 30 s, 1 min, 2 min, 5 min, puis 10 min, jusqu'à 12 nouvelles tentatives (≈ 2 h). La carte affiche « ⟳ Serveur indisponible (503) — nouvel essai dans 2 min (vers 11:42) • 3/12 » ; la place est rendue aux autres téléchargements pendant l'attente.
- **Moins de pression sur le serveur** : pour les vidéos yt-dlp, 8 fragments en parallèle au 1er essai, puis 4, 2 et 1 aux relances suivantes ; 15 essais par fragment avec pauses croissantes.
- **Pas de relance inutile** : lien expiré ou refusé (403), introuvable (404/410), vidéo privée ou protégée, disque plein → échec immédiat avec un message clair.
- Réglable dans Paramètres > Téléchargements : « Relancer automatiquement en cas d'échec » (activé par défaut). « Pause » arrête aussi l'attente.

## Version 2.7 — écran d'analyse pour les liens partagés
- **Lien partagé = analyse + choix du format** : un lien Facebook, TikTok, YouTube, Instagram, X, Reddit… (et autres sites) partagé vers MyDM ouvre l'écran **« Analyse en cours… »**, puis liste les formats disponibles (qualités vidéo, Audio M4A / MP3) avec leur taille ; vous touchez « Télécharger » sur celui voulu (programmation possible).
- Autre site : la page est analysée, et si elle ne donne rien, yt-dlp est tenté automatiquement.
- Un **fichier direct** (apk, zip, mp4, pdf…) partagé reste téléchargé tout de suite.
- Paramètres > « Télécharger directement les liens partagés » : désactivé par défaut ; activé = ancien comportement (meilleure qualité sans écran).
- Le bandeau du presse-papiers (« Analyser ») ouvre aussi l'analyse automatiquement.

## Version 2.7.1
- **Onglet Vidéos** : nouvel onglet « YouTube » juste à côté de « Tout » ; la recherche s'ouvre sur YouTube dans le navigateur, où la vidéo est captée dès sa lecture (un lien collé est analysé comme avant).

- **Onglet Vidéos > YouTube** : la recherche s'affiche désormais directement dans l'application (cartes en bas, filtres durée/tri, « Plus de résultats »), sans ouvrir le navigateur. Chaque vidéo a deux petites icônes : « ajouter à la liste » (lignes + plus, devient une coche une fois ajoutée) et « télécharger ». Une barre « N en attente » apparaît en bas avec « Vider » et « TÉLÉCHARGER » pour lancer tout le lot dans une même qualité.

## Version 2.7.3
- **Onglet Vidéos** : toucher la miniature d'une vidéo (résultats, listes, écran « Sélectionné ») la **lit** dans le lecteur intégré, sans la télécharger (flux direct via yt-dlp). Le bouton ⬇ reste pour télécharger.
- **Pubs** : liste d'hôtes publicitaires étendue ; blocage des scripts/iframes aux adresses typiques de pubs (popunder, adserver, pagead…) ; script anti-pub injecté dans toutes les pages et iframes : `window.open` sans geste réel ou vers un autre site refusé, calques invisibles plein écran (« cliquez n'importe où ») neutralisés, emplacements publicitaires masqués. Les fenêtres de connexion Google / Apple / Facebook restent permises.
- **Navigateur** : tirer la page vers le bas (quand elle est tout en haut) pour l'actualiser.
- **Noms de fichiers** : les vidéos Facebook, TikTok et Instagram sans titre prennent la légende, sinon « Plateforme - auteur - identifiant » au lieu de « video ».

## Version 2.8.0 — mise à jour automatique (OTA)
- **MyDM se met à jour tout seul** : au démarrage (au plus toutes les 6 h) l'appli lit les releases d'un dépôt GitHub public (celles du générateur d'APK) ou un fichier `update.json`, et si une version plus récente existe, propose « Mettre à jour » : téléchargement avec progression, vérification SHA-256 (facultative), installation par Android.
- Réglages : Paramètres > Téléchargements > « Mise à jour automatique de MyDM », adresse de mise à jour, bouton « Rechercher une mise à jour de MyDM ». « Ignorer » masque une version.
- Mode d'emploi et modèle : dossier `Update/`. L'APK doit être signé avec la même clé que l'appli installée.
- Nouvelle icône (M + flèche de téléchargement).

## Version 2.9.1
- **Nom du fichier modifiable** : dans la fenêtre « Télécharger », le champ « Nom du fichier » est pré-rempli avec le titre ; modifiez-le avant de choisir la qualité (↺ pour revenir au nom proposé). L'extension est ajoutée automatiquement ; si vous avez modifié le nom, le suffixe de qualité [720p] n'est pas ajouté.
- **Lecture des vidéos plus rapide** (onglet Vidéos) : adresse du flux gardée 20 min (relecture immédiate), extraction yt-dlp allégée, lecteur qui démarre avec moins de tampon (0,8 s) et barre de chargement pendant la préparation.

## Version 2.9.2
- **Onglet Vidéos** : historique des recherches (liste « Recherches récentes » quand on touche la barre, ✕ pour en retirer une, « Effacer l'historique »). Le dernier résultat (vidéos, listes, miniatures) est enregistré et reste affiché même sans connexion, jusqu'à « Vider le résultat ».
- **Nouvelle icône** : nuage blanc + flèche de téléchargement cyan sur fond dégradé violet (icône adaptative + monochrome Android 13+).

## Version 2.9.3
- **Pause immédiate** : « Pause » (et « Tout mettre en pause ») arrête vraiment le téléchargement en cours, y compris les vidéos YouTube/Facebook/TikTok/HLS gérées par yt-dlp, qui continuaient jusqu'au bout. Le processus yt-dlp et les connexions de la tâche sont coupés, la carte passe tout de suite à « En pause » ; « Reprendre » repart du point atteint.
- Une tâche restée « en cours » sans téléchargement actif (après un redémarrage) peut aussi être mise en pause.

## Version 2.9.4 — téléchargements accélérés
- **Vraies connexions multiples** : les segments passent en HTTP/1.1, une connexion TCP chacun. En HTTP/2 (la plupart des CDN) ils partageaient UNE seule connexion, et le découpage ne servait presque à rien.
- **Découpage dynamique** : quand une connexion a fini son morceau, elle prend la moitié du plus gros reste d'une autre. Toutes les connexions travaillent jusqu'au bout, plus de fin de téléchargement au ralenti. Marche aussi à la reprise après une pause.
- **16 connexions par fichier par défaut** (réglable 4 / 8 / 16 / 32 dans Paramètres), lecture par blocs de 256 Ko, vitesse affichée lissée.
- **yt-dlp (YouTube, Facebook, TikTok, HLS…)** : 16 fragments en parallèle au premier essai, morceaux de 10 Mo (`--http-chunk-size`) pour éviter le bridage de YouTube, tampon de 1 Mo.

## Version 2.9.5 — vidéos YouTube / Facebook / TikTok beaucoup plus rapides
- **aria2c intégré à yt-dlp** : les vidéos YouTube, Facebook, TikTok, Instagram… (fichiers non fragmentés) se téléchargent sur **16 connexions** au lieu d'une seule. Avant, `-N 16` n'agissait que sur les flux HLS/DASH ; les vidéos YouTube passaient par une connexion unique, bridée par le serveur. Le nombre de connexions suit le réglage « Connexions simultanées par fichier » (16 maximum pour aria2c).
- **Repli automatique** : si un site refuse aria2c, la tâche repart aussitôt avec le téléchargeur interne de yt-dlp (« Mode compatible… »).
- **Vitesse affichée** aussi pour les vidéos yt-dlp (lue dans la sortie de yt-dlp / aria2c).
- **Liens directs** : pool de 256 fils (avant, 64 au total : avec 3 téléchargements × 32 connexions, une partie des connexions attendait), écriture disque par blocs de 512 Ko au lieu de ~8 Ko.
- La limite de vitesse des Paramètres s'applique aussi aux vidéos yt-dlp.

