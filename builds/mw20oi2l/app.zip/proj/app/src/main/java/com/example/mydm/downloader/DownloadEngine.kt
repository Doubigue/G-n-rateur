package com.example.mydm.downloader

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.core.app.NotificationCompat
import com.example.mydm.MainActivity
import com.example.mydm.core.*
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import okhttp3.*
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import kotlinx.coroutines.sync.withLock
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** [real] = false : « total » est fictif (yt-dlp, archive de site) → on affiche le % mais pas de taille. */
data class Progress(val downloaded: Long, val total: Long, val speedBps: Long, val real: Boolean = true)

class DownloadEngine(
    private val context: Context,
    private val dao: DownloadDao,
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build()
) {
    /**
     * Dispatchers.IO plafonne à 64 fils : avec 3 téléchargements × 32 connexions (lectures bloquantes), une partie des
     * connexions attendait un fil libre. Pool élargi à 256 → chaque connexion lit vraiment en parallèle.
     */
    @OptIn(ExperimentalCoroutinesApi::class)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO.limitedParallelism(256))
    private val jobs = ConcurrentHashMap<String, Job>()
    private val _progress = MutableStateFlow<Map<String, Progress>>(emptyMap())
    val progress: StateFlow<Map<String, Progress>> = _progress
    val activeCount get() = jobs.values.count { it.isActive }

    /**
     * Client des segments : HTTP/1.1 forcé. En HTTP/2, tous les segments d'un même serveur passent par UNE seule
     * connexion TCP (multiplexage) : le découpage ne servait presque à rien. En HTTP/1.1, chaque segment a sa propre
     * connexion → la bande passante s'additionne (comme IDM / ADM).
     */
    private val fastClient: OkHttpClient = client.newBuilder()
        .protocols(listOf(Protocol.HTTP_1_1))
        .connectionPool(ConnectionPool(64, 5, TimeUnit.MINUTES))
        .retryOnConnectionFailure(true)
        .build()

    /** Segment en cours : sa fin peut reculer quand un autre segment vient l'aider (découpage dynamique). */
    private class LiveSeg(val idx: Int, val start: Long, @Volatile var end: Long) {
        @Volatile var active = false
    }
    private val MIN_SPLIT = 2L * 1024 * 1024          // on ne découpe pas un reste de moins de 2 × 2 Mo

    companion object {
        /** aria2c embarqué prêt (initialisé dans App). Sinon yt-dlp garde son téléchargeur interne. */
        @Volatile var aria2Ready = false
    }
    /** Tâches pour lesquelles aria2c a échoué : on repasse au téléchargeur interne de yt-dlp. */
    private val noAria = ConcurrentHashMap.newKeySet<String>()
    private val ariaPct = Regex("\\((\\d{1,3})%\\)")                                   // [#a1b2c3 3.2MiB/45MiB(7%) CN:16 DL:4.1MiB]
    private val ariaSpeed = Regex("DL:([\\d.]+)([KMG]i)?B")
    private val ytPct = Regex("\\[download]\\s+([\\d.]+)%")
    private val ytSpeed = Regex("\\bat\\s+([\\d.]+)([KMG]i)?B/s")
    private fun toBps(v: String, unit: String?): Long {
        val m = when (unit) { "Ki" -> 1024.0; "Mi" -> 1048576.0; "Gi" -> 1073741824.0; else -> 1.0 }
        return ((v.toDoubleOrNull() ?: 0.0) * m).toLong()
    }

    private val partsDir get() = File(context.getExternalFilesDir(null), "parts").apply { mkdirs() }
    private fun part(id: String, i: Int) = File(partsDir, "$id.part$i")

    // ── File d'attente : N téléchargements simultanés max, option « Wi-Fi uniquement »
    private val lock = Any()
    private var running = 0
    private fun tryAcquire() = synchronized(lock) { if (running < Prefs.maxParallel) { running++; true } else false }
    private fun release() = synchronized(lock) { if (running > 0) running-- }

    private fun networkState(): String? = NetworkMonitor.waitReason()   // null = OK, sinon raison de l'attente

    // ── Coupure de connexion : pause automatique, reprise toute seule au retour du réseau
    private val calls = ConcurrentHashMap<Call, String>()                 // connexion en cours -> id de la tâche
    private val stopping = ConcurrentHashMap<String, Job>()               // tâches mises en pause dont l'arrêt n'est pas encore fini
    private val ytRunning = ConcurrentHashMap.newKeySet<String>()
    private val netWaiting = ConcurrentHashMap.newKeySet<String>()

    init {
        scope.launch {
            NetworkMonitor.changes.collect {
                if (!NetworkMonitor.usable()) {
                    // On coupe tout de suite les connexions en cours : la liste passe en « pause » sans attendre les délais d'expiration
                    calls.keys.toList().forEach { it.cancel() }
                    ytRunning.toList().forEach { runCatching { YoutubeDL.getInstance().destroyProcessById(it) } }
                }
            }
        }
    }

    /** Si le réseau est coupé : marque la tâche en pause, attend le retour (sans limite), puis la remet en route. */
    private suspend fun awaitNetwork(id: String) {
        if (NetworkMonitor.usable()) return
        if (netWaiting.add(id)) dao.setStatus(id, Status.QUEUED, NetworkMonitor.pausedText())
        while (!NetworkMonitor.usable()) delay(1000)
        delay(1500)                                   // laisse la connexion se stabiliser
        if (netWaiting.remove(id)) dao.setStatus(id, Status.RUNNING, null)
    }

    /** Exécute [block] ; en cas d'erreur réseau, attend le retour de la connexion avant de réessayer. */
    private suspend fun <T> retryNet(id: String, block: () -> T): T {
        var attempt = 0
        while (true) {
            awaitNetwork(id)
            try { return block() }
            catch (e: CancellationException) { throw e }
            catch (e: IOException) {
                currentCoroutineContext().ensureActive()
                if (NetworkMonitor.usable() && ++attempt >= 5) throw e
                delay(2000)
            }
        }
    }

    /** Tâches restées « en cours » quand l'appli ou le téléphone s'est arrêté : à relancer. */
    suspend fun resumeInterrupted(): List<String> = dao.active().map { it.id }.filter { jobs[it]?.isActive != true }

    // ── Relance automatique : une erreur « temporaire » (503, 429, délai, coupure…) ne laisse plus la tâche en échec
    private val MAX_AUTO_RETRIES = 12
    private val autoAttempt = ConcurrentHashMap<String, Int>()      // n° de la relance en cours (0 = 1er essai)

    /** Erreurs inutiles à retenter : lien expiré/refusé, introuvable, vidéo privée, disque plein, format non pris en charge… */
    private fun isPermanent(e: Throwable): Boolean {
        val m = (e.message ?: "").lowercase()
        return listOf("http 404", "http error 404", "http 403", "http error 403", "http 410", "http error 410",
            "unsupported url", "no video formats", "no space left", "enospc", "private video", "sign in", "log in", "login required",
            "drm", "copyright", "fichier de sortie introuvable", "video unavailable", "this video is unavailable", "has been removed",
            "age-restricted", "members-only", "requested format is not available").any { it in m }
    }

    private fun shortReason(e: Throwable): String {
        val m = (e.message ?: "").lowercase()
        return when {
            "503" in m -> "serveur indisponible (503)"
            "429" in m -> "trop de requêtes (429)"
            "502" in m || "504" in m || "500" in m -> "erreur du serveur"
            "timeout" in m || "timed out" in m -> "délai dépassé"
            "resolve" in m || "errno 7" in m || "no address" in m -> "pas d'accès Internet"
            else -> "erreur réseau"
        }
    }

    /** Attente avant la relance n° [n] : 15 s, 30 s, 1 min, 2 min, 5 min, puis 10 min. */
    private fun backoffSec(n: Int) = intArrayOf(15, 30, 60, 120, 300, 600)[(n - 1).coerceIn(0, 5)]

    private fun fmtWait(sec: Int) = if (sec < 60) "$sec s" else "${sec / 60} min"

    fun start(id: String) {
        if (jobs[id]?.isActive == true) return
        Scheduler.disarm(context, id)          // démarrage manuel d'un téléchargement programmé : l'alarme n'a plus lieu d'être
        jobs[id] = scope.launch {
            var acquired = false
            stopping.remove(id)?.join()            // « Reprendre » juste après « Pause » : on attend que l'ancien arrêt soit fini
            try {
                dao.clearSchedule(id)
                dao.setStatus(id, Status.QUEUED, null)
                var auto = 0
                while (true) {
                    // 1) attendre le réseau et une place libre dans la file
                    var lastMsg: String? = null
                    while (true) {
                        val wait = networkState()
                        if (wait == null && tryAcquire()) { acquired = true; break }
                        val msg = wait ?: "En file d'attente…"
                        if (msg != lastMsg) { dao.setStatus(id, Status.QUEUED, msg); lastMsg = msg }
                        delay(700)
                    }
                    autoAttempt[id] = auto
                    // 2) télécharger ; sur une erreur temporaire on patiente puis on recommence là où on s'était arrêté (.part conservés)
                    try { runTask(id); break }
                    catch (e: CancellationException) { throw e }
                    catch (e: Exception) {
                        if (!Prefs.autoRetry || isPermanent(e) || ++auto > MAX_AUTO_RETRIES) {
                            val extra = if (auto > MAX_AUTO_RETRIES) " (après $MAX_AUTO_RETRIES nouvelles tentatives)" else ""
                            throw if (extra.isEmpty()) e else RuntimeException((e.message ?: "Erreur") + extra, e)
                        }
                        release(); acquired = false                       // la place est rendue aux autres pendant l'attente
                        _progress.update { it - id }
                        val sec = backoffSec(auto)
                        val at = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date(System.currentTimeMillis() + sec * 1000L))
                        dao.setStatus(id, Status.QUEUED, "⟳ ${shortReason(e).replaceFirstChar { it.uppercase() }} — nouvel essai dans ${fmtWait(sec)} (vers $at) • $auto/$MAX_AUTO_RETRIES")
                        delay(sec * 1000L)
                    }
                }
            } catch (e: CancellationException) {
                withContext(NonCancellable) { dao.setStatus(id, Status.PAUSED, null) }
                _progress.update { it - id }
                throw e
            } catch (e: Exception) {
                dao.setStatus(id, Status.FAILED, friendlyError(e.message))
                _progress.update { it - id }
            } finally { netWaiting.remove(id); autoAttempt.remove(id); if (acquired) release() }
        }
    }

    /**
     * Pause immédiate (les .part restent => reprise possible).
     * L'annulation seule ne suffisait pas : yt-dlp et les lectures réseau sont bloquants et continuaient jusqu'au bout.
     * On coupe donc directement le processus yt-dlp et les connexions de la tâche, et on affiche « En pause » tout de suite.
     */
    fun pause(id: String) {
        val job = jobs.remove(id)
        if (job != null) { stopping[id] = job; job.cancel() }
        runCatching { YoutubeDL.getInstance().destroyProcessById(id) }
        calls.entries.filter { it.value == id }.forEach { it.key.cancel() }
        _progress.update { it - id }
        scope.launch {
            withContext(NonCancellable) {
                val t = dao.task(id)
                if (t != null && (t.status == Status.RUNNING || t.status == Status.QUEUED)) dao.setStatus(id, Status.PAUSED, null)
            }
            job?.join(); stopping.remove(id, job)
        }
    }
    fun pauseAll() {
        jobs.keys.toList().forEach(::pause)
        // tâches marquées « en cours / en attente » sans travail actif (ex. après un redémarrage) : en pause aussi
        scope.launch { dao.active().filter { it.status != Status.MERGING && jobs[it.id] == null }.forEach { pause(it.id) } }
    }

    fun cancel(id: String) {
        pause(id)
        Scheduler.disarm(context, id)
        scope.launch {
            partsDir.listFiles { f -> f.name.startsWith(id) }?.forEach { it.delete() }
            File(context.getExternalFilesDir(null), "ytdlp/$id").deleteRecursively()
            File(context.getExternalFilesDir(null), "site/$id").deleteRecursively()
            dao.deleteSegments(id); dao.delete(id)
        }
    }

    suspend fun activeTasks(): List<DownloadTask> = dao.active()

    // ── Programmation : le téléchargement démarre tout seul à l'heure choisie (alarme système)
    /** Programme (ou reprogramme) la tâche [id] à l'heure [at] (ms). Si elle tourne ou attend, elle est d'abord mise à l'arrêt. */
    suspend fun schedule(id: String, at: Long) {
        jobs.remove(id)?.cancelAndJoin()       // attend la fin du « catch » qui remet PAUSED, pour ne pas écraser SCHEDULED
        _progress.update { it - id }
        val t = dao.task(id) ?: return
        if (t.status == Status.COMPLETED || t.status == Status.MERGING) return
        dao.upsert(t.copy(status = Status.SCHEDULED, scheduledAt = at, error = null))
        Scheduler.arm(context, id, at)
    }

    /** Annule la programmation : la tâche reste en pause (bouton « Reprendre »). */
    suspend fun unschedule(id: String) {
        Scheduler.disarm(context, id)
        val t = dao.task(id) ?: return
        if (t.status == Status.SCHEDULED) dao.upsert(t.copy(status = Status.PAUSED, scheduledAt = 0, error = null))
    }

    /** Remet les alarmes (perdues au redémarrage du téléphone, à la mise à jour de l'appli ou après un arrêt forcé). */
    suspend fun rearmSchedules() {
        val soon = System.currentTimeMillis() + 3_000
        dao.scheduled().forEach { Scheduler.arm(context, it.id, maxOf(it.scheduledAt, soon)) }
    }

    private fun friendlyError(m: String?): String {
        val s = m ?: return "Erreur inconnue"
        return when {
            "Errno 7" in s || "No address associated" in s || "UnknownHost" in s || "Unable to resolve host" in s ->
                "Pas d'accès Internet (DNS). Vérifiez le Wi-Fi / les données (ou le DNS privé / VPN), puis « Reprendre »."
            "timeout" in s.lowercase() || "timed out" in s.lowercase() -> "Délai dépassé : connexion trop lente. Réessayez."
            "HTTP 403" in s -> "Accès refusé par le serveur (403). Rouvrez la page puis relancez le téléchargement."
            "HTTP 404" in s -> "Fichier introuvable (404)."
            "503" in s -> "Serveur indisponible (503) : le site est surchargé. Les nouvelles tentatives automatiques n'ont pas suffi — « Reprendre » plus tard."
            "Unsupported URL" in s || "No video formats" in s || "no video" in s.lowercase() ->
                "Aucun flux vidéo exploitable dans ce lecteur. Utilisez « Analyser » sur la page de l'épisode, ou essayez un autre lecteur (voe, streamtape…)."
            else -> s.take(300)
        }
    }

    // ───────────── Création des tâches
    /** Crée la tâche en base (headers rejoués : UA, cookies, referer). */
    suspend fun enqueue(m: DetectedMedia, subFolder: String? = null, nameOverride: String? = null, durationSec: Long = 0): String {
        val headers = JSONObject().apply {
            put("User-Agent", m.userAgent)
            m.cookies?.let { put("Cookie", it) }
            m.referer?.let { put("Referer", it); com.example.mydm.browser.UrlRules.originOf(it)?.let { o -> put("Origin", o) } }
        }.toString()
        val auto = fileNameFor(m)
        val name = nameOverride?.let { cleanName(it) + "." + auto.substringAfterLast('.', "mp4") } ?: auto
        val task = DownloadTask(url = m.url, fileName = name, mimeType = null, headersJson = headers,
            maxSegments = Prefs.maxSegments, subFolder = subFolder, durationSec = durationSec)
        dao.upsert(task)
        return task.id
    }

    /** Fichier direct (apk, zip, iso, pdf…) : nom et type d'origine conservés, aucune analyse. */
    suspend fun enqueueFile(url: String, fileName: String, mime: String?, ua: String, referer: String? = null, cookies: String? = null): String {
        val headers = JSONObject().apply {
            put("User-Agent", ua)
            cookies?.let { put("Cookie", it) }
            referer?.let { put("Referer", it) }
        }.toString()
        val task = DownloadTask(url = url, fileName = cleanName(fileName).ifBlank { "fichier" }, mimeType = mime,
            headersJson = headers, maxSegments = Prefs.maxSegments)
        dao.upsert(task)
        return task.id
    }

    /** Tâche gérée par yt-dlp : page YouTube/Facebook/TikTok ou flux HLS. */
    suspend fun enqueueYt(pageUrl: String, title: String, opt: QualityOption, referer: String? = null,
                          ua: String? = null, subFolder: String? = null, durationSec: Long = 0, cookies: String? = null,
                          sizeBytes: Long? = null, exactName: Boolean = false): String {
        val h = JSONObject().put("ytdlpFormat", opt.selector).put("ytdlpMp3", opt.mp3)
        referer?.let { h.put("ytdlpReferer", it) }
        ua?.let { h.put("ytdlpUa", it) }
        cookies?.takeIf { it.isNotBlank() }?.let { h.put("ytdlpCookie", it) }
        val q = opt.label.substringBefore(" •")
        val full = if (exactName || q.isBlank() || q == "HLS") title else "$title [$q]"
        val task = DownloadTask(url = pageUrl, fileName = cleanName(full).ifBlank { "video" },
            mimeType = null, headersJson = h.toString(), subFolder = subFolder, durationSec = durationSec,
            totalBytes = sizeBytes?.takeIf { it > 0 } ?: -1)      // taille estimée à l'analyse : affichée dans la liste
        dao.upsert(task)
        return task.id
    }

    /** Archive ZIP d'un site : HTML (source + DOM rendu), CSS, JS, images, polices… + journal de la console. */
    suspend fun enqueueSite(pageUrl: String, title: String, ua: String, cookies: String?, dom: String, console: String): String =
        withContext(Dispatchers.IO) {
            val host = pageUrl.toHttpUrlOrNull()?.host ?: "site"
            val task = DownloadTask(url = pageUrl, fileName = cleanName("Site $host - ${title.ifBlank { "page" }}").take(100) + ".zip",
                mimeType = "application/zip",
                headersJson = JSONObject().put("siteZip", true).put("User-Agent", ua).apply { cookies?.let { put("Cookie", it) } }.toString())
            val dir = File(context.getExternalFilesDir(null), "site/${task.id}").apply { mkdirs() }
            File(dir, "rendered.html").writeText(dom)
            File(dir, "console.txt").writeText(console)
            dao.upsert(task)
            task.id
        }

    // ───────────── yt-dlp
    private suspend fun runYtDlp(task: DownloadTask) {
        val id = task.id
        val o = JSONObject(task.headersJson)
        val dir = File(context.getExternalFilesDir(null), "ytdlp/$id").apply { mkdirs() }
        dao.setStatus(id, Status.RUNNING, null)

        // aria2c : 16 connexions sur les fichiers « simples » (YouTube, Facebook, TikTok, Instagram…), là où yt-dlp n'en
        // ouvre qu'une seule (-N ne joue que sur les fragments HLS/DASH). HLS/DASH restent au téléchargeur interne.
        val useAria = aria2Ready && id !in noAria
        fun buildReq(aria: Boolean) = YoutubeDLRequest(task.url).apply {
            addOption("-f", o.getString("ytdlpFormat"))
            addOption("--no-playlist")
            // 8 fragments en parallèle au 1er essai, puis 4, 2, 1 : un serveur qui répond 503 par surcharge tient mieux ainsi
            addOption("-N", when (autoAttempt[id] ?: 0) { 0 -> 16; 1 -> 8; 2 -> 4; 3 -> 2; else -> 1 })
            // YouTube bride une connexion qui lit un gros fichier d'un trait : des morceaux de 10 Mo gardent la pleine vitesse
            addOption("--http-chunk-size", "10M")
            addOption("--buffer-size", "1M")
            addOption("--retries", 15)
            addOption("--fragment-retries", 30)
            if (aria) {
                val n = Prefs.maxSegments.coerceIn(1, 16)                          // aria2c : 16 connexions max par serveur
                addOption("--downloader", "libaria2c.so")
                addOption("--downloader", "dash,m3u8:native")
                addOption("--external-downloader-args",
                    "aria2c:-x$n -s$n -j$n -k1M --summary-interval=1 --max-tries=10 --retry-wait=2 --connect-timeout=15 --timeout=30")
            }
            if (Prefs.speedLimitKbps > 0) addOption("-r", "${Prefs.speedLimitKbps}K")
            addOption("--retry-sleep", "http:exp=1:20")
            addOption("--retry-sleep", "fragment:exp=1:20")
            addOption("-o", dir.absolutePath + "/out.%(ext)s")
            if (o.optBoolean("ytdlpMp3")) { addOption("-x"); addOption("--audio-format", "mp3") }
            else addOption("--merge-output-format", "mp4")
            o.optString("ytdlpReferer").takeIf { it.isNotEmpty() }?.let { ref ->
                addOption("--referer", ref)
                runCatching { Uri.parse(ref).let { u -> "${u.scheme}://${u.host}" } }.getOrNull()
                    ?.let { origin -> addOption("--add-header", "Origin:$origin") }
            }
            o.optString("ytdlpUa").takeIf { it.isNotEmpty() }?.let { addOption("--user-agent", it) }
            o.optString("ytdlpCookie").takeIf { it.isNotEmpty() }?.let { addOption("--add-header", "Cookie:$it") }
        }
        var req = buildReq(useAria)
        var lastPct = 0f
        var lastSpeed = 0L
        val handle = currentCoroutineContext()[Job]!!.invokeOnCompletion { YoutubeDL.getInstance().destroyProcessById(id) }
        ytRunning.add(id)
        try {
            var attempt = 0
            while (true) {
                awaitNetwork(id)
                try {
                    YoutubeDL.getInstance().execute(req, id) { p, _, line ->
                        // % et vitesse lus dans la ligne (format yt-dlp ou aria2c) ; à défaut, le % fourni par la bibliothèque
                        val pct = (ariaPct.find(line) ?: ytPct.find(line))?.groupValues?.get(1)?.toFloatOrNull()
                            ?: p.takeIf { it > 0f } ?: lastPct
                        (ariaSpeed.find(line) ?: ytSpeed.find(line))?.let { lastSpeed = toBps(it.groupValues[1], it.groupValues[2].ifEmpty { null }) }
                        lastPct = pct
                        _progress.update { it + (id to Progress((pct.coerceIn(0f, 100f) * 10).toLong(), 1000, lastSpeed, real = false)) }
                    }
                    break
                } catch (e: Exception) {
                    if (!currentCoroutineContext().isActive) throw CancellationException("pause")
                    if (!NetworkMonitor.usable()) continue          // connexion coupée : on attend son retour (yt-dlp reprend le .part)
                    val m = e.message.orEmpty().lowercase()
                    // aria2c refusé par ce serveur (ou indisponible) : on repasse aussitôt au téléchargeur interne de yt-dlp
                    if (useAria && id !in noAria && "no space" !in m && "enospc" !in m) {
                        noAria.add(id); req = buildReq(false)
                        // les .part d'aria2c sont « troués » (écrits à plusieurs endroits à la fois) : inutilisables par yt-dlp seul
                        dir.listFiles()?.filter { it.name.endsWith(".aria2") || it.name.endsWith(".part") }?.forEach { it.delete() }
                        dao.setStatus(id, Status.RUNNING, "Mode compatible…")
                        continue
                    }
                    val netLike = listOf("errno 7", "no address associated", "timed out", "timeout", "connection", "unable to download",
                        "network", "ssl", "temporary failure", "reset by peer", "broken pipe", "http error 5", "http error 429", "service unavailable").any { it in m }
                    if (!netLike || ++attempt > 5) throw e
                    dao.setStatus(id, Status.RUNNING, "Nouvelle tentative ($attempt/5)…")
                    delay(3000L * attempt)
                }
            }
        } finally { ytRunning.remove(id); handle.dispose() }
        noAria.remove(id)

        val out = dir.listFiles()
            ?.filter { it.isFile && it.name.startsWith("out.") && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") && !it.name.endsWith(".aria2") }
            ?.maxByOrNull { it.length() } ?: error("Fichier de sortie introuvable")
        dao.setStatus(id, Status.MERGING, null)
        val name = cleanName(task.fileName) + "." + out.extension
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(out.extension)
        val uri = saveToLibrary(out, name, mime, task.subFolder)
        dao.upsert(dao.task(id)!!.copy(fileName = name, mimeType = mime, totalBytes = out.length(), status = Status.COMPLETED, resultUri = uri.toString(), error = null))
        dir.deleteRecursively()
        _progress.update { it - id }
        done(name, true)
    }

    /** Copie un fichier terminé dans Download/<racine>/<catégorie>. */
    private fun saveToLibrary(file: File, name: String, mime: String?, sub: String? = null): Uri {
        val uri = Storage.create(context, name, mime, Storage.rel(categoryFor(name, mime), sub))
        context.contentResolver.openOutputStream(uri)!!.use { out -> file.inputStream().use { it.copyTo(out, 256 * 1024) } }
        Storage.finish(context, uri)
        return uri
    }

    // ───────────── Téléchargement direct multi-segments
    private suspend fun runTask(id: String) {
        val task = dao.task(id) ?: return
        if (task.headersJson.contains("ytdlpFormat")) { runYtDlp(task); return }
        if (task.headersJson.contains("siteZip")) { runSite(task); return }
        val headers = task.headersJson.toHeaders()
        dao.setStatus(id, Status.RUNNING, null)

        var segs = dao.segments(id)
        var total = task.totalBytes
        if (segs.isEmpty()) {
            val pr = retryNet(id) { probe(task.url, headers) }
            total = pr.length
            segs = plan(id, pr, task.maxSegments)
            dao.insertSegments(segs)
            dao.upsert(task.copy(totalBytes = total, status = Status.RUNNING))
        }
        val ranged = total > 0 && segs.first().end >= 0

        // Découpage dynamique : quand une connexion a fini son morceau, elle « vole » la moitié du plus gros reste
        // d'une autre. Toutes les connexions travaillent jusqu'à la dernière seconde (pas de fin au ralenti).
        val live = java.util.Collections.synchronizedList(segs.map { LiveSeg(it.idx, it.start, it.end) }.toMutableList())
        val splitLock = kotlinx.coroutines.sync.Mutex()
        fun doneOf(l: LiveSeg) = part(id, l.idx).let { if (it.exists()) it.length() else 0L }
        fun remaining(l: LiveSeg) = l.end - (l.start + doneOf(l)) + 1

        suspend fun steal(): LiveSeg? = splitLock.withLock {
            if (!ranged) return@withLock null
            val victim = synchronized(live) { live.filter { it.active }.maxByOrNull { remaining(it) } } ?: return@withLock null
            val rest = remaining(victim)
            if (rest < 2 * MIN_SPLIT) return@withLock null
            val cur = victim.start + doneOf(victim)
            val mid = cur + rest / 2
            val oldEnd = victim.end
            val nIdx = synchronized(live) { live.maxOf { it.idx } + 1 }
            val fresh = LiveSeg(nIdx, mid, oldEnd)
            victim.end = mid - 1                                   // la connexion d'origine s'arrêtera à mi-chemin
            part(id, nIdx).delete()
            dao.insertSegments(listOf(Segment(id, victim.idx, victim.start, victim.end), Segment(id, nIdx, mid, oldEnd)))
            live.add(fresh)
            fresh
        }

        val ticker = scope.launch {
            var last = synchronized(live) { live.sumOf { doneOf(it) } }; var lastT = System.nanoTime()
            var smooth = 0L
            while (isActive) {
                delay(500)
                val done = synchronized(live) { live.sumOf { doneOf(it) } }
                val now = System.nanoTime()
                val speed = ((done - last) * 1_000_000_000L) / (now - lastT).coerceAtLeast(1)
                smooth = if (smooth == 0L) speed else (smooth * 6 + speed * 4) / 10       // vitesse lissée (moins de sauts)
                last = done; lastT = now
                _progress.update { it + (id to Progress(done, total, smooth)) }
            }
        }
        try {
            val workers = if (ranged) maxOf(task.maxSegments, Prefs.maxSegments).coerceIn(1, 32) else 1
            val queue = ArrayDeque(synchronized(live) { live.filter { remaining(it) > 0 || !ranged } })
            coroutineScope {
                repeat(workers) {
                    launch {
                        var seg: LiveSeg? = splitLock.withLock { queue.removeFirstOrNull() } ?: steal()
                        while (seg != null) {
                            seg.active = true
                            try { downloadSegment(task.url, headers, id, seg, ranged) } finally { seg.active = false }
                            seg = splitLock.withLock { queue.removeFirstOrNull() } ?: steal()
                        }
                    }
                }
            }
        } finally { ticker.cancel() }

        segs = synchronized(live) { live.map { Segment(id, it.idx, it.start, it.end) } }
        dao.setStatus(id, Status.MERGING, null)
        val uri = merge(task, segs)
        dao.upsert(dao.task(id)!!.copy(status = Status.COMPLETED, resultUri = uri.toString(), error = null))
        _progress.update { it - id }
        done(task.fileName, true)
    }

    private data class Probe(val length: Long, val acceptsRanges: Boolean)

    private fun probe(url: String, headers: Headers): Probe {
        val req = Request.Builder().url(url).headers(headers).header("Range", "bytes=0-0").build()
        client.newCall(req).execute().use { r ->
            return when {
                r.code == 206 -> {
                    val total = r.header("Content-Range")?.substringAfter('/')?.toLongOrNull() ?: -1
                    Probe(total, total > 0)
                }
                r.isSuccessful -> Probe(r.header("Content-Length")?.toLongOrNull() ?: -1, false)
                else -> throw IOException("HTTP ${r.code}")
            }
        }
    }

    private fun plan(id: String, p: Probe, maxSeg: Int): List<Segment> {
        if (!p.acceptsRanges || p.length <= 0) return listOf(Segment(id, 0, 0, -1))
        val n = if (p.length < 1_000_000) 1 else maxSeg
        val size = p.length / n
        return (0 until n).map { i ->
            Segment(id, i, i * size, if (i == n - 1) p.length - 1 else (i + 1) * size - 1)
        }
    }

    private suspend fun downloadSegment(url: String, headers: Headers, id: String, s: LiveSeg, ranged: Boolean) {
        val file = part(id, s.idx)
        var attempt = 0
        while (true) {
            val sizeBefore = if (file.exists()) file.length() else 0L
            try {
                awaitNetwork(id)                                     // pas de réseau : pause, puis reprise automatique
                val already = if (ranged && file.exists()) file.length() else 0L
                if (ranged && s.start + already > s.end) return          // segment déjà complet
                if (!ranged && file.exists()) file.delete()              // serveur sans reprise : on recommence ce morceau

                val rb = Request.Builder().url(url).headers(headers)
                if (ranged) rb.header("Range", "bytes=${s.start + already}-${s.end}")
                val call = fastClient.newCall(rb.build())
                calls[call] = id
                val h = currentCoroutineContext()[Job]!!.invokeOnCompletion { call.cancel() }
                try {
                    call.execute().use { r ->
                        if (ranged && r.code != 206) throw IOException("Range non respecté (${r.code})")
                        if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
                        // Limite de vitesse : budget réparti entre les connexions
                        val cap = if (Prefs.speedLimitKbps > 0) Prefs.speedLimitKbps * 1024L / Prefs.maxSegments.coerceAtLeast(1) else 0L
                        val t0 = System.nanoTime(); var sent = 0L
                        // Tampon de 512 Ko : le réseau livre des paquets de ~8 Ko ; on écrit sur le disque par gros blocs
                        // (des milliers d'écritures en moins par seconde → moins de CPU, plus de débit sur les petits téléphones)
                        java.io.BufferedOutputStream(FileOutputStream(file, ranged), 512 * 1024).use { out ->
                            val buf = ByteArray(256 * 1024)
                            val input = r.body!!.byteStream()
                            var pos = s.start + already                  // prochain octet à écrire
                            while (true) {
                                currentCoroutineContext().ensureActive()
                                val n = input.read(buf); if (n < 0) break
                                if (ranged) {
                                    val allowed = s.end - pos + 1        // la fin a pu reculer (une autre connexion a pris la suite)
                                    if (allowed <= 0) break
                                    val w = minOf(n.toLong(), allowed).toInt()
                                    out.write(buf, 0, w); pos += w
                                    if (w < n || pos > s.end) break
                                } else out.write(buf, 0, n)
                                if (cap > 0) {
                                    sent += n
                                    val wait = sent * 1000 / cap - (System.nanoTime() - t0) / 1_000_000
                                    if (wait > 0) delay(wait)
                                }
                            }
                        }
                    }
                } finally { h.dispose(); calls.remove(call) }
                if (ranged && s.start + file.length() <= s.end) continue  // connexion fermée trop tôt : on reprend la suite
                return
            } catch (e: CancellationException) { throw e }
            catch (e: IOException) {
                currentCoroutineContext().ensureActive()
                if (!NetworkMonitor.usable()) continue                   // coupure : aucun essai décompté, on attend le retour du réseau
                if (file.exists() && file.length() > sizeBefore) attempt = 0   // des octets sont arrivés : la connexion marche
                if (++attempt >= 8) throw e
                delay(minOf(1000L * attempt, 8000L))
            }
        }
    }

    private fun merge(task: DownloadTask, segs: List<Segment>): Uri {
        val uri = Storage.create(context, task.fileName, task.mimeType, Storage.rel(categoryFor(task.fileName, task.mimeType), task.subFolder))
        context.contentResolver.openOutputStream(uri)!!.use { out ->
            val buf = ByteArray(256 * 1024)
            segs.sortedBy { it.start }.forEach { s ->
                val f = part(task.id, s.idx)
                if (!f.exists()) return@forEach
                var left = if (s.end >= 0) s.end - s.start + 1 else Long.MAX_VALUE   // on ne copie jamais au-delà de la fin
                f.inputStream().use { inp ->
                    while (left > 0) {
                        val n = inp.read(buf, 0, minOf(buf.size.toLong(), left).toInt()); if (n < 0) break
                        out.write(buf, 0, n); left -= n
                    }
                }
            }
        }
        Storage.finish(context, uri)
        partsDir.listFiles { f -> f.name.startsWith(task.id + ".part") }?.forEach { it.delete() }
        return uri
    }

    // ───────────── Archive ZIP d'un site web
    private val tagRe = Regex("<(script|link|img|source|video|audio|iframe)\\b[^>]*>", RegexOption.IGNORE_CASE)
    private val attrRe = Regex("\\b(src|href|data-src|poster|srcset)\\s*=\\s*([\"'])(.*?)\\2", RegexOption.IGNORE_CASE)
    private val cssUrlRe = Regex("url\\(\\s*['\"]?([^)'\"]+?)['\"]?\\s*\\)", RegexOption.IGNORE_CASE)
    private val cssImportRe = Regex("@import\\s+['\"]([^'\"]+)['\"]", RegexOption.IGNORE_CASE)

    private fun resolveUrl(base: String, raw: String): String? {
        val r = raw.trim()
        if (r.isEmpty() || r.startsWith("#") || r.startsWith("data:") || r.startsWith("javascript:") ||
            r.startsWith("mailto:") || r.startsWith("blob:") || r.startsWith("about:")) return null
        return base.toHttpUrlOrNull()?.resolve(r)?.toString()?.substringBefore('#')
    }

    /** Applique [f] à chaque URL de ressource trouvée dans les balises (src, href des <link>, srcset, poster). */
    private fun mapTags(html: String, f: (String) -> String): String = tagRe.replace(html) { tag ->
        val isLink = tag.groupValues[1].equals("link", true)
        val relOk = !isLink || Regex("rel\\s*=\\s*[\"'][^\"']*(stylesheet|icon|preload|manifest)", RegexOption.IGNORE_CASE).containsMatchIn(tag.value)
        val isMedia = tag.groupValues[1].lowercase().let { it == "video" || it == "audio" || it == "iframe" }
        if (!relOk) tag.value else attrRe.replace(tag.value) { a ->
            val name = a.groupValues[1].lowercase(); val q = a.groupValues[2]; val v = a.groupValues[3]
            when {
                isMedia && name != "poster" -> a.value                      // pas de vidéo/iframe dans l'archive
                name == "srcset" -> "srcset=$q" + v.split(",").joinToString(",") { c ->
                    val t = c.trim().split(Regex("\\s+"), 2); " " + f(t[0]) + (t.getOrNull(1)?.let { " $it" } ?: "")
                }.trim() + q
                else -> "${a.groupValues[1]}=$q${f(v)}$q"
            }
        }
    }

    private fun localPath(abs: String, taken: MutableSet<String>): String {
        val u = abs.toHttpUrlOrNull()!!
        var p = u.encodedPath.trim('/').ifEmpty { "index" }
        if (u.encodedPath.endsWith("/")) p += "/index"
        var name = Uri.decode(u.host + "/" + p)
        u.query?.let { q ->
            val ext = name.substringAfterLast('.', "").takeIf { it.length in 1..5 && '/' !in it }
            val h = Integer.toHexString(q.hashCode())
            name = if (ext != null) name.removeSuffix(".$ext") + "_$h.$ext" else name + "_$h"
        }
        name = name.replace(Regex("[^A-Za-z0-9._/-]"), "_")
        if (name.substringAfterLast('/').let { !it.contains('.') }) name += ".bin"
        var path = "assets/$name"; var n = 1
        while (!taken.add(path)) path = "assets/" + name.substringBeforeLast('.') + "_${n++}." + name.substringAfterLast('.')
        return path
    }

    private fun relative(fromFile: String, toFile: String): String {
        val from = java.nio.file.Paths.get(fromFile).parent ?: java.nio.file.Paths.get("")
        return from.relativize(java.nio.file.Paths.get(toFile)).toString().replace('\\', '/')
    }

    private suspend fun runSite(task: DownloadTask) {
        val id = task.id
        val o = JSONObject(task.headersJson)
        val ua = o.optString("User-Agent"); val cookie = o.optString("Cookie")
        val base = task.url
        val work = File(context.getExternalFilesDir(null), "site/$id")
        dao.setStatus(id, Status.RUNNING, null)

        fun req(u: String) = Request.Builder().url(u).header("User-Agent", ua)
            .header("Referer", base).apply { if (cookie.isNotEmpty()) header("Cookie", cookie) }.build()

        val source = client.newCall(req(base)).execute().use { r ->
            if (!r.isSuccessful) throw IOException("HTTP ${r.code}"); r.body!!.string()
        }
        val dom = File(work, "rendered.html").takeIf { it.exists() }?.readText()?.takeIf { it.length > 200 } ?: source
        val consoleLog = File(work, "console.txt").takeIf { it.exists() }?.readText().orEmpty()

        // 1) Découverte des ressources du DOM rendu (JS exécuté) + url() des styles inline
        val found = LinkedHashMap<String, String>()          // url absolue -> chemin local
        val taken = HashSet<String>()
        fun register(abs: String?): String? {
            abs ?: return null
            return found.getOrPut(abs) { localPath(abs, taken) }
        }
        mapTags(dom) { v -> register(resolveUrl(base, v)); v }
        cssUrlRe.findAll(dom).forEach { register(resolveUrl(base, it.groupValues[1])) }

        // 2) Téléchargement (8 en parallèle), CSS analysés pour leurs url()/@import
        val maxBytes = Prefs.siteMaxMb * 1_048_576L
        val files = LinkedHashMap<String, ByteArray>()        // chemin local -> contenu
        val failed = mutableListOf<String>()
        var totalBytes = 0L
        var processed = 0
        val queue = ArrayDeque(found.keys.toList())
        val seenAbs = HashSet(found.keys)
        val gate = kotlinx.coroutines.sync.Semaphore(8)
        val startT = System.nanoTime()
        while (queue.isNotEmpty() && files.size < 500 && totalBytes < maxBytes) {
            val batch = List(minOf(16, queue.size)) { queue.removeFirst() }
            coroutineScope {
                batch.map { abs ->
                    async {
                        gate.acquire()
                        try {
                            val bytes = runCatching {
                                client.newCall(req(abs)).execute().use { r ->
                                    if (!r.isSuccessful) error("HTTP ${r.code}")
                                    r.body!!.bytes() to (r.header("Content-Type") ?: "")
                                }
                            }.getOrNull()
                            synchronized(files) {
                                if (bytes == null) failed += abs
                                else {
                                    val (data, ct) = bytes
                                    var out = data
                                    val local = found[abs]!!
                                    if (local.endsWith(".css") || ct.contains("text/css")) {
                                        // découvrir puis réécrire les url() du CSS
                                        var css = data.toString(Charsets.UTF_8)
                                        val refs = (cssUrlRe.findAll(css).map { it.groupValues[1] } + cssImportRe.findAll(css).map { it.groupValues[1] }).toSet()
                                        refs.forEach { raw ->
                                            val a = resolveUrl(abs, raw) ?: return@forEach
                                            val lp = register(a)!!
                                            if (seenAbs.add(a)) queue.addLast(a)
                                            css = css.replace(raw, relative(local, lp))
                                        }
                                        out = css.toByteArray(Charsets.UTF_8)
                                    }
                                    files[local] = out; totalBytes += out.size
                                }
                                processed++
                            }
                        } finally { gate.release() }
                    }
                }.awaitAll()
            }
            val all = processed + queue.size
            val speed = (totalBytes * 1_000_000_000L) / (System.nanoTime() - startT).coerceAtLeast(1)
            _progress.update { it + (id to Progress((processed * 1000L / all.coerceAtLeast(1)), 1000, speed, real = false)) }
        }

        // 3) Réécriture du HTML puis écriture du ZIP
        dao.setStatus(id, Status.MERGING, null)
        var index = mapTags(dom) { v -> resolveUrl(base, v)?.let { found[it] }?.takeIf { it in files } ?: v }
        index = cssUrlRe.replace(index) { m ->
            val local = resolveUrl(base, m.groupValues[1])?.let { found[it] }?.takeIf { it in files }
            if (local != null) "url($local)" else m.value
        }
        val uri = Storage.create(context, task.fileName, "application/zip", Storage.rel(Category.AUTRES, "Sites"))
        ZipOutputStream(context.contentResolver.openOutputStream(uri)!!.buffered()).use { z ->
            fun put(name: String, data: ByteArray) { z.putNextEntry(ZipEntry(name)); z.write(data); z.closeEntry() }
            put("index.html", index.toByteArray())
            put("source.html", source.toByteArray())
            if (consoleLog.isNotBlank()) put("console.txt", consoleLog.toByteArray())
            files.forEach { (n, d) -> put(n, d) }
            put("_info.txt", ("URL : $base\nFichiers : ${files.size}\nTaille : ${formatSize(totalBytes)}\n" +
                "Échecs : ${failed.size}\n" + failed.joinToString("\n")).toByteArray())
        }
        Storage.finish(context, uri)
        dao.upsert(dao.task(id)!!.copy(status = Status.COMPLETED, resultUri = uri.toString(), totalBytes = totalBytes, error = null))
        work.deleteRecursively()
        _progress.update { it - id }
        done(task.fileName, true)
    }

    // ───────────── Notification de fin
    private fun done(name: String, ok: Boolean) {
        if (!Prefs.notifyDone) return
        val nm = context.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("done", "Téléchargements terminés", NotificationManager.IMPORTANCE_DEFAULT))
        val pi = PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        nm.notify(name.hashCode(), NotificationCompat.Builder(context, "done").setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle(if (ok) "Téléchargement terminé" else "Échec").setContentText(name)
            .setContentIntent(pi).setAutoCancel(true).build())
    }

    private fun String.toHeaders(): Headers {
        val b = Headers.Builder(); val o = JSONObject(this)
        o.keys().forEach { k -> if (!k.startsWith("ytdlp") && k != "siteZip") b.add(k, o.getString(k)) }; return b.build()
    }
}
