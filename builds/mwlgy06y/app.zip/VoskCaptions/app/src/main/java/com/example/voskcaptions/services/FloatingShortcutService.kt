package com.example.voskcaptions.services

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.ImageView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.voskcaptions.HistoryActivity
import com.example.voskcaptions.CaptureShortcuts
import com.example.voskcaptions.R
import com.example.voskcaptions.VoskApp
import com.example.voskcaptions.screen.ScreenTranslation
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * Petite bulle flottante collée au bord de l'écran.
 * Appui = traduire le texte de l'écran · double appui = démarrer/arrêter le sous-titrage ·
 * appui long = historique · glisser = déplacer (aimantée au bord).
 */
class FloatingShortcutService : Service() {

    companion object {
        const val ACTION_STOP = "com.example.voskcaptions.action.STOP_SHORTCUT"
        private const val CHANNEL_ID = "shortcut_bubble"
        private const val NOTIFICATION_ID = 1003
        private val _running = MutableStateFlow(false)
        val running: StateFlow<Boolean> = _running.asStateFlow()

        fun start(ctx: Context) =
            ContextCompat.startForegroundService(ctx, Intent(ctx, FloatingShortcutService::class.java))

        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, FloatingShortcutService::class.java)) }
    }

    private val app: VoskApp get() = applicationContext as VoskApp
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var params: WindowManager.LayoutParams
    private lateinit var circle: GradientDrawable
    private var bubble: ImageView? = null
    private var size = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(NOTIFICATION_ID, n)

        if (intent?.action == ACTION_STOP || !Settings.canDrawOverlays(this)) {
            stopSelf(); return START_NOT_STICKY
        }
        if (bubble == null) setup()
        return START_NOT_STICKY
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setup() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dm = resources.displayMetrics
        size = (48 * dm.density).toInt()
        val pad = (12 * dm.density).toInt()

        circle = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFF1976D2.toInt()) }
        val view = ImageView(this).apply {
            setImageResource(R.drawable.ic_translate)
            imageTintList = ColorStateList.valueOf(Color.WHITE)
            setPadding(pad, pad, pad, pad)
            background = circle
            alpha = 0.8f
            contentDescription = "Traduire l'écran (double appui : sous-titrage)"
            elevation = 6 * dm.density
        }

        val s = app.settings.state.value
        params = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = if (s.shortcutRight) dm.widthPixels - size else 0
            y = if (s.shortcutY >= 0) s.shortcutY else (dm.heightPixels * 0.4f).toInt()
        }

        val slop = ViewConfiguration.get(this).scaledTouchSlop
        view.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
            var moved = false; var longFired = false
            var tapPending = false
            val singleTap = Runnable {
                tapPending = false
                ScreenTranslation.trigger(applicationContext)
            }
            val longPress = Runnable {
                if (!moved) {
                    longFired = true
                    view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                    startActivity(Intent(this@FloatingShortcutService, HistoryActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = params.x; sy = params.y; tx = e.rawX; ty = e.rawY
                        moved = false; longFired = false
                        handler.postDelayed(longPress, 600)
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - tx; val dy = e.rawY - ty
                        if (!moved && (abs(dx) > slop || abs(dy) > slop)) {
                            moved = true; handler.removeCallbacks(longPress)
                        }
                        if (moved) {
                            val d = resources.displayMetrics
                            params.x = (sx + dx).toInt().coerceIn(0, d.widthPixels - size)
                            params.y = (sy + dy).toInt().coerceIn(0, d.heightPixels - size)
                            wm.updateViewLayout(v, params)
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        handler.removeCallbacks(longPress)
                        if (moved) snapToEdge(v)
                        else if (!longFired) {
                            if (tapPending) {                       // double appui
                                handler.removeCallbacks(singleTap)
                                tapPending = false
                                CaptureShortcuts.toggle(applicationContext)
                            } else {
                                tapPending = true
                                handler.postDelayed(singleTap, ViewConfiguration.getDoubleTapTimeout().toLong())
                            }
                        }
                    }
                    MotionEvent.ACTION_CANCEL -> handler.removeCallbacks(longPress)
                }
                return true
            }
        })

        wm.addView(view, params)
        bubble = view
        _running.value = true

        scope.launch {
            AudioCaptureService.running.collect { on ->
                circle.setColor(if (on) 0xFFD32F2F.toInt() else 0xFF1976D2.toInt())
                view.alpha = if (on) 1f else 0.8f
            }
        }
    }

    private fun snapToEdge(v: View) {
        val sw = resources.displayMetrics.widthPixels
        val right = params.x + size / 2 > sw / 2
        val target = if (right) sw - size else 0
        ValueAnimator.ofInt(params.x, target).apply {
            duration = 180
            addUpdateListener {
                if (bubble != null) {
                    params.x = it.animatedValue as Int
                    runCatching { wm.updateViewLayout(v, params) }
                }
            }
            start()
        }
        app.settings.update { it.copy(shortcutY = params.y, shortcutRight = right) }
    }

    private fun buildNotification(): Notification {
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Icône de raccourci", NotificationManager.IMPORTANCE_MIN)
        )
        val stopPi = PendingIntent.getService(
            this, 3,
            Intent(this, FloatingShortcutService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Bulle de traduction active")
            .setContentText("Appui : traduire l'écran · double appui : sous-titrage")
            .setOngoing(true)
            .addAction(0, "Masquer", stopPi)
            .build()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        scope.cancel()
        bubble?.let { runCatching { wm.removeView(it) } }
        bubble = null
        _running.value = false
        super.onDestroy()
    }
}
