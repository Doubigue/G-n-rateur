package com.example.voskcaptions.translation

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.util.JsonReader
import org.json.JSONObject
import java.io.Closeable
import java.io.File
import java.io.IOException
import java.nio.LongBuffer

/** Fichiers d'un pack OPUS-MT (export ONNX « optimum » / Xenova). */
data class PackFiles(val spm: File, val vocab: File, val config: File?, val encoder: File, val decoder: File) {
    companion object {
        /** Cherche les fichiers dans le dossier et dans son sous-dossier onnx/. */
        fun find(dir: File): PackFiles? {
            val roots = listOf(dir, File(dir, "onnx")).filter { it.isDirectory }
            val all = roots.flatMap { r -> r.listFiles()?.filter { it.isFile }.orEmpty() }
            fun named(n: String) = all.firstOrNull { it.name == n }
            val spm = named("source.spm") ?: all.firstOrNull { it.name.endsWith(".spm") } ?: return null
            val vocab = named("vocab.json") ?: return null
            val onnx = all.filter { it.name.endsWith(".onnx") }
            val enc = listOf("encoder_model_quantized.onnx", "encoder_model.onnx").firstNotNullOfOrNull { n -> onnx.firstOrNull { it.name == n } }
                ?: onnx.firstOrNull { it.name.startsWith("encoder") } ?: return null
            val decCandidates = onnx.filter { it.name.startsWith("decoder") && "merged" !in it.name && "with_past" !in it.name }
            val dec = listOf("decoder_model_quantized.onnx", "decoder_model.onnx").firstNotNullOfOrNull { n -> decCandidates.firstOrNull { it.name == n } }
                ?: decCandidates.firstOrNull() ?: return null
            return PackFiles(spm, vocab, named("config.json"), enc, dec)
        }
    }
}

/**
 * Traducteur Marian (OPUS-MT) hors ligne : encodeur + décodeur ONNX, décodage glouton.
 * Thread-safe (un appel à la fois).
 */
class MarianTranslator(files: PackFiles, private val env: OrtEnvironment) : Closeable {
    private val spm = SentencePieceModel(files.spm)
    private val vocab = HashMap<String, Int>(70_000)
    private val idToToken: Array<String?>
    private val eosId: Int
    private val padId: Int
    private val unkId: Int
    private val decoderStartId: Long
    private val encoder: OrtSession
    private val decoder: OrtSession
    private val logitsName: String

    init {
        JsonReader(files.vocab.reader(Charsets.UTF_8).buffered()).use { r ->
            r.beginObject()
            while (r.hasNext()) vocab[r.nextName()] = r.nextInt()
            r.endObject()
        }
        val max = vocab.values.maxOrNull() ?: throw IOException("vocab.json vide")
        idToToken = arrayOfNulls(max + 1)
        vocab.forEach { (t, id) -> idToToken[id] = t }

        val cfg = files.config?.let { runCatching { JSONObject(it.readText()) }.getOrNull() }
        padId = cfg?.optInt("pad_token_id", -1)?.takeIf { it >= 0 } ?: vocab["<pad>"] ?: max
        eosId = cfg?.optInt("eos_token_id", -1)?.takeIf { it >= 0 } ?: vocab["</s>"] ?: 0
        unkId = vocab["<unk>"] ?: 1
        decoderStartId = (cfg?.optInt("decoder_start_token_id", -1)?.takeIf { it >= 0 } ?: padId).toLong()

        val opts = OrtSession.SessionOptions().apply {
            setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
            setIntraOpNumThreads(Runtime.getRuntime().availableProcessors().coerceIn(1, 4))
        }
        encoder = env.createSession(files.encoder.absolutePath, opts)
        decoder = try {
            env.createSession(files.decoder.absolutePath, opts)
        } catch (t: Throwable) {
            encoder.close(); throw t
        }
        logitsName = decoder.outputNames.firstOrNull { it == "logits" } ?: decoder.outputNames.first()
    }

    @Synchronized
    fun translate(text: String): String {
        val sentences = splitSentences(text)
        return sentences.joinToString(" ") { translateSentence(it) }.trim()
    }

    private fun splitSentences(text: String): List<String> {
        val t = text.trim()
        if (t.length < 200) return listOf(t)
        return t.split(Regex("(?<=[.!?…。！？])\\s+")).map { it.trim() }.filter { it.isNotEmpty() }
    }

    private fun translateSentence(sentence: String): String {
        if (sentence.isBlank()) return ""
        val ids = spm.encode(sentence).map { vocab[it] ?: unkId }.take(MAX_INPUT - 1) + eosId
        val n = ids.size.toLong()
        val inputIds = OnnxTensor.createTensor(env, LongBuffer.wrap(LongArray(ids.size) { ids[it].toLong() }), longArrayOf(1, n))
        val mask = OnnxTensor.createTensor(env, LongBuffer.wrap(LongArray(ids.size) { 1L }), longArrayOf(1, n))
        return inputIds.use {
            mask.use {
                val encInputs = HashMap<String, OnnxTensor>()
                for (name in encoder.inputNames) encInputs[name] = if ("mask" in name) mask else inputIds
                encoder.run(encInputs).use { encOut ->
                    generate(encOut.get(0) as OnnxTensor, mask, ids.size)
                }
            }
        }
    }

    private fun generate(hidden: OnnxTensor, mask: OnnxTensor, inputLen: Int): String {
        val out = ArrayList<Long>()
        out.add(decoderStartId)
        val maxOut = minOf(MAX_OUTPUT, inputLen * 2 + 16)
        var repeats = 0
        while (out.size <= maxOut) {
            val dec = OnnxTensor.createTensor(env, LongBuffer.wrap(out.toLongArray()), longArrayOf(1, out.size.toLong()))
            val next = dec.use {
                val inputs = HashMap<String, OnnxTensor>()
                for (name in decoder.inputNames) {
                    inputs[name] = when {
                        name == "input_ids" || name == "decoder_input_ids" -> dec
                        "hidden" in name -> hidden
                        "mask" in name -> mask
                        else -> throw IOException("Modèle de décodeur non pris en charge (entrée « $name »). Utilisez decoder_model*.onnx.")
                    }
                }
                decoder.run(inputs, setOf(logitsName)).use { r -> argmaxLast(r.get(0) as OnnxTensor) }
            }
            if (next == eosId) break
            repeats = if (out.size > 1 && out.last() == next.toLong()) repeats + 1 else 0
            if (repeats >= 4) break               // garde-fou contre les boucles
            out.add(next.toLong())
        }
        return decode(out)
    }

    private fun argmaxLast(logits: OnnxTensor): Int {
        val shape = logits.info.shape                // [1, longueur, vocabulaire]
        val v = shape[shape.size - 1].toInt()
        val len = if (shape.size >= 3) shape[shape.size - 2].toInt() else 1
        val buf = logits.floatBuffer
        val off = (len - 1) * v
        var best = eosId
        var bestScore = Float.NEGATIVE_INFINITY
        for (k in 0 until v) {
            if (k == padId) continue
            val x = buf.get(off + k)
            if (x > bestScore) { bestScore = x; best = k }
        }
        return best
    }

    private fun decode(ids: List<Long>): String {
        val sb = StringBuilder()
        for (k in 1 until ids.size) {
            val id = ids[k].toInt()
            if (id == padId || id == eosId || id == unkId) continue
            val tok = idToToken.getOrNull(id) ?: continue
            if (tok.startsWith("<") && tok.endsWith(">")) continue
            sb.append(tok)
        }
        return sb.toString().replace('▁', ' ').replace(Regex("\\s+"), " ").trim()
    }

    override fun close() {
        runCatching { encoder.close() }
        runCatching { decoder.close() }
    }

    companion object {
        private const val MAX_INPUT = 256
        private const val MAX_OUTPUT = 256
    }
}
