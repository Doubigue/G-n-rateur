package com.example.voskcaptions

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.voskcaptions.managers.ModelState
import com.example.voskcaptions.managers.VoskModelManager
import com.example.voskcaptions.services.AudioCaptureService
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as VoskApp
    private val models = app.modelManager
    private val translation = app.translationManager

    val modelState = models.state
    val installedModels = models.installed
    val settings = app.settings.state
    val downloadedLangs = translation.downloaded

    private val _langBusy = MutableStateFlow<String?>(null)
    val langBusy: StateFlow<String?> = _langBusy.asStateFlow()

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    init {
        viewModelScope.launch {
            models.refreshInstalled()
            runCatching { translation.refreshDownloaded() }
        }
    }

    private fun capturing() = AudioCaptureService.running.value

    // ---- Modèles Vosk
    fun importModels(uris: List<Uri>) {
        if (uris.isEmpty()) return
        if (capturing()) { _messages.tryEmit("Arrêtez le sous-titrage avant de changer de modèle"); return }
        viewModelScope.launch { report(models.importZips(uris)) }
    }

    fun importFolder(treeUri: Uri) {
        if (capturing()) { _messages.tryEmit("Arrêtez le sous-titrage avant de changer de modèle"); return }
        viewModelScope.launch { report(models.importFolder(treeUri)) }
    }

    private fun report(r: VoskModelManager.ImportResult) {
        val msg = when {
            r.imported.isEmpty() -> r.errors.firstOrNull() ?: "Aucun modèle importé"
            r.errors.isEmpty() -> if (r.imported.size > 1) "${r.imported.size} modèles importés" else null
            else -> "${r.imported.size} modèle(s) importé(s), ${r.errors.size} échec(s) :\n" + r.errors.joinToString("\n")
        }
        msg?.let { _messages.tryEmit(it) }
    }

    val persistentStorage = models.persistent
    fun hasSharedAccess() = models.hasSharedAccess()

    /** À appeler au retour dans l'appli (ex. après avoir accordé l'accès aux fichiers). */
    fun refreshStorage() {
        if (capturing()) return
        viewModelScope.launch {
            val wasPersistent = models.persistent.value
            models.refreshInstalled()
            runCatching { translation.refreshDownloaded() }
            if (!wasPersistent && models.persistent.value) {
                _messages.tryEmit("Modèles rangés dans /VoskCaptions : ils resteront après une désinstallation")
            }
            if (models.state.value is ModelState.Idle) models.restoreLastModel()
        }
    }

    fun loadModel(name: String) {
        if (capturing()) { _messages.tryEmit("Arrêtez le sous-titrage avant de changer de modèle"); return }
        viewModelScope.launch { models.loadModel(name).onFailure { _messages.tryEmit(it.message ?: "Échec du chargement") } }
    }

    fun deleteModel(name: String) {
        if (capturing()) { _messages.tryEmit("Arrêtez le sous-titrage avant de supprimer un modèle"); return }
        viewModelScope.launch { models.deleteModel(name) }
    }

    // ---- Traduction
    fun setSourceLang(tag: String) { app.settings.update { it.copy(sourceLang = tag) }; translation.closeAll() }
    fun setTargetLang(tag: String) { app.settings.update { it.copy(targetLang = tag) }; translation.closeAll() }

    val packProgress = translation.progress

    /** Télécharge ce qu'il faut pour traduire source → cible (paire directe ou via l'anglais). */
    fun downloadForCurrent() {
        val s = settings.value
        val pairs = translation.neededPairs(s.sourceLang, s.targetLang)
        when {
            pairs == null -> _messages.tryEmit(
                "Aucun modèle disponible pour ${translation.displayName(s.sourceLang)} → ${translation.displayName(s.targetLang)}, même en passant par l'anglais"
            )
            pairs.all { it in translation.downloaded.value } -> _messages.tryEmit("Déjà installé : " + pairs.joinToString(" + ") { translation.displayName(it) })
            else -> downloadPairs(pairs)
        }
    }

    fun downloadPairs(pairs: List<String>) {
        if (_langBusy.value != null) return
        viewModelScope.launch {
            for (pair in pairs.distinct()) {
                if (pair in translation.downloaded.value) continue
                _langBusy.value = pair
                try {
                    translation.downloadPair(pair)
                    _messages.tryEmit("Installé : ${translation.displayName(pair)}")
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    _messages.tryEmit("Téléchargement impossible (${translation.displayName(pair)}) : ${e.message}")
                    break
                }
            }
            _langBusy.value = null
        }
    }

    fun deletePair(pair: String) {
        viewModelScope.launch {
            try { translation.deletePair(pair) }
            catch (e: Exception) { _messages.tryEmit("Suppression impossible : ${e.message}") }
        }
    }

    // ---- Overlay
    fun setTextSize(sp: Int) = app.settings.update { it.copy(textSizeSp = sp) }
    fun setOpacity(percent: Int) = app.settings.update { it.copy(bgOpacity = percent) }
    fun setShowOriginal(v: Boolean) = app.settings.update { it.copy(showOriginal = v) }
    fun setTranslateNotifications(v: Boolean) = app.settings.update { it.copy(translateNotifications = v) }
    fun setColorMode(key: String) = app.settings.update { it.copy(colorMode = key) }
    fun setAutoClear(on: Boolean) = app.settings.update { it.copy(autoClearSeconds = if (on) 10 else 0) }
    fun setShortcutEnabled(on: Boolean) = app.settings.update { it.copy(shortcutEnabled = on) }
}
