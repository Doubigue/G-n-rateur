package com.example.voskcaptions

import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.os.Build
import com.example.voskcaptions.services.AudioCaptureService

/** Action unique « démarrer / arrêter » utilisée par la bulle flottante et le bouton d'accessibilité. */
object CaptureShortcuts {
    /**
     * Demande de capture : sur Android 14+, seule l'option « Tout l'écran » est proposée
     * (pas de choix d'appli). Android impose toujours la confirmation, elle ne peut pas être supprimée.
     */
    fun captureIntent(context: Context): Intent {
        val mpm = context.getSystemService(MediaProjectionManager::class.java)
        return if (Build.VERSION.SDK_INT >= 34) mpm.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
        else mpm.createScreenCaptureIntent()
    }

    fun toggle(context: Context) {
        val app = context.applicationContext
        if (AudioCaptureService.running.value) {
            app.stopService(Intent(app, AudioCaptureService::class.java))
            return
        }
        app.startActivity(
            Intent(app, CaptureLauncherActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
        )
    }
}
