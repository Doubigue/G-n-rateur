package com.example.voskcaptions.services

import android.accessibilityservice.AccessibilityButtonController
import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import com.example.voskcaptions.CaptureShortcuts

/**
 * Service d'accessibilité :
 *  - lit le texte affiché à l'écran quand vous appuyez sur la bulle (traduction de l'écran) ;
 *  - fournit le bouton d'accessibilité système pour démarrer/arrêter le sous-titrage.
 * Rien n'est lu en arrière-plan : le contenu n'est consulté qu'au moment de l'appui.
 */
class ShortcutAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ShortcutAccessibilityService? = null
            private set
    }

    private var callback: AccessibilityButtonController.AccessibilityButtonCallback? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        val cb = object : AccessibilityButtonController.AccessibilityButtonCallback() {
            override fun onClicked(controller: AccessibilityButtonController) {
                CaptureShortcuts.toggle(applicationContext)
            }
        }
        callback = cb
        accessibilityButtonController.registerAccessibilityButtonCallback(cb)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        callback?.let { accessibilityButtonController.unregisterAccessibilityButtonCallback(it) }
        super.onDestroy()
    }
}
