package com.example.voskcaptions.managers

import ai.onnxruntime.OrtEnvironment
import android.content.Context
import com.example.voskcaptions.data.AppStorage
import com.example.voskcaptions.data.SettingsRepository
import com.example.voskcaptions.translation.MarianTranslator
import com.example.voskcaptions.translation.PackFiles
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.languageid.LanguageIdentificationOptions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/** [lang] = paire manquante, ex. "en-fr". */
class LanguageModelMissingException(val lang: String) : Exception("Pack de langue manquant : $lang")

data class AutoTranslation(val sourceLang: String, val translated: String?)

data class PackProgress(val pair: String, val percent: Int, val message: String)

/**
 * Traduction hors ligne avec les modèles OPUS-MT (Marian) au format ONNX.
 * Un « pack » = une paire orientée (ex. en-fr). Les packs sont rangés dans
 * /VoskCaptions/traduction/<paire>/ quand l'accès aux fichiers est accordé :
 * ils survivent alors à une désinstallation.
 * Sans paire directe, on passe par l'anglais (ex. fr → en → de).
 */
class TranslationManager(
    private val context: Context,
    private val settings: SettingsRepository
) {
    companion object {
        /** Paires disponibles en ONNX sur Hugging Face (dépôts Xenova/opus-mt-*). */
        val CATALOG: List<String> = buildList {
            listOf("fr", "es", "de", "it", "nl", "ru", "uk", "pl", "cs", "ar", "zh", "ja", "ko", "hi", "tr",
                "id", "vi", "th", "sv", "da", "fi", "et", "hu", "af", "xh")
                .forEach { add("$it-en") }
            listOf("fr", "es", "de", "it", "nl", "ru", "uk", "ar", "zh", "ja", "hi", "id", "vi", "ro", "sv", "da",
                "fi", "hu", "cs", "af", "xh")
                .forEach { add("en-$it") }
            addAll(listOf("fr-de", "fr-es", "fr-ro", "fr-ru", "de-fr", "de-es", "es-fr", "es-de", "es-it", "es-ru",
                "it-fr", "it-es", "nl-fr", "ro-fr", "ru-fr", "ru-es", "ru-uk", "uk-ru", "da-de", "no-de", "fi-de"))
        }.distinct()

        val LANGUAGES: List<String> = CATALOG.flatMap { it.split('-') }.distinct()

        /** Nom du dépôt quand il diffère de opus-mt-<src>-<tgt>. */
        private val REPO_OVERRIDE = mapOf("en-ja" to "opus-mt-en-jap")

        private const val HF_BASE = "https://huggingface.co/Xenova/"
        private val DOWNLOAD_FILES = listOf(
            "config.json" to "configuration",
            "vocab.json" to "vocabulaire",
            "source.spm" to "découpage",
            "onnx/encoder_model_quantized.onnx" to "encodeur",
            "onnx/decoder_model_quantized.onnx" to "décodeur"
        )
        private const val DL_PREFIX = ".dl_"
        private const val MAX_CACHED = 2
        private val PAIR_REGEX = Regex("^[a-z]{2,3}-[a-z]{2,3}$")
    }

    private val identifier by lazy {
        LanguageIdentification.getClient(LanguageIdentificationOptions.Builder().setConfidenceThreshold(0.5f).build())
    }
    private val env: OrtEnvironment by lazy { OrtEnvironment.getEnvironment() }

    /** Paires installées (ex. "en-fr"). */
    private val _downloaded = MutableStateFlow<Set<String>>(emptySet())
    val downloaded: StateFlow<Set<String>> = _downloaded.asStateFlow()

    private val _progress = MutableStateFlow<PackProgress?>(null)
    val progress: StateFlow<PackProgress?> = _progress.asStateFlow()

    private val _persistent = MutableStateFlow(false)
    val persistent: StateFlow<Boolean> = _persistent.asStateFlow()

    private val engineLock = Mutex()
    private val fileLock = Mutex()
    private val engines = LinkedHashMap<String, MarianTranslator>(4, 0.75f, true)   // LRU

    private val packsDir: File get() = AppStorage.dir(context, "traduction", "translation_packs")
    private val internalDir: File get() = AppStorage.internalDir(context, "translation_packs")

    // ---------------------------------------------------------------- noms

    fun allLanguages(): List<String> = LANGUAGES.sortedBy { displayName(it).lowercase() }

    fun allPairs(): List<String> = CATALOG.sortedBy { displayName(it).lowercase() }

    /** "fr" → « Français » ; "en-fr" → « Anglais → Français ». */
    fun displayName(tag: String): String {
        if (PAIR_REGEX.matches(tag)) {
            val (a, b) = tag.split('-')
            return "${langName(a)} → ${langName(b)}"
        }
        return langName(tag)
    }

    private fun langName(tag: String): String =
        Locale.forLanguageTag(tag).getDisplayLanguage(Locale.getDefault())
            .ifBlank { tag }.replaceFirstChar { it.uppercase() }

    // ---------------------------------------------------------------- packs installés

    suspend fun refreshDownloaded() = fileLock.withLock {
        withContext(Dispatchers.IO) {
            migrateToShared()
            val dir = packsDir
            _persistent.value = dir.absolutePath != internalDir.absolutePath
            _downloaded.value = dir.listFiles { f -> f.isDirectory && PAIR_REGEX.matches(f.name) }
                .orEmpty()
                .filter { PackFiles.find(it) != null }
                .map { it.name }
                .toSet()
        }
    }

    /** Paires à installer pour traduire src → tgt (directe, sinon via l'anglais). null = impossible. */
    fun neededPairs(src: String, tgt: String): List<String>? {
        if (src == tgt) return emptyList()
        return route(src, tgt, _downloaded.value) ?: route(src, tgt, CATALOG.toSet())
    }

    private fun route(src: String, tgt: String, avail: Set<String>): List<String>? {
        if ("$src-$tgt" in avail) return listOf("$src-$tgt")
        if (src != "en" && tgt != "en" && "$src-en" in avail && "en-$tgt" in avail) return listOf("$src-en", "en-$tgt")
        return null
    }

    /** Télécharge une paire depuis Hugging Face (reprise possible si la connexion coupe). */
    suspend fun downloadPair(pair: String) = withContext(Dispatchers.IO) {
        require(PAIR_REGEX.matches(pair)) { "Paire invalide : $pair" }
        val repo = REPO_OVERRIDE[pair] ?: "opus-mt-$pair"
        val root = packsDir
        val tmp = File(root, DL_PREFIX + pair).apply { mkdirs() }
        if (root.usableSpace < 200L shl 20) throw IOException("Espace de stockage insuffisant (environ 120 Mo nécessaires).")
        try {
            DOWNLOAD_FILES.forEachIndexed { i, (path, label) ->
                currentCoroutineContext().ensureActive()
                val dest = File(tmp, path)
                if (dest.isFile && dest.length() > 0) return@forEachIndexed
                val step = "(${i + 1}/${DOWNLOAD_FILES.size}) $label"
                downloadFile("$HF_BASE$repo/resolve/main/$path", dest) { pct ->
                    _progress.value = PackProgress(pair, pct, "${displayName(pair)} : $step${if (pct >= 0) " $pct %" else ""}")
                }
            }
            if (PackFiles.find(tmp) == null) throw IOException("Pack incomplet après téléchargement.")
            fileLock.withLock {
                closeEngines()
                val target = File(root, pair)
                if (target.exists()) target.deleteRecursively()
                if (!tmp.renameTo(target)) {
                    tmp.copyRecursively(target, overwrite = true)
                    tmp.deleteRecursively()
                }
            }
        } finally {
            _progress.value = null
        }
        refreshDownloaded()
    }

    private suspend fun downloadFile(url: String, dest: File, onProgress: (Int) -> Unit) {
        dest.parentFile?.mkdirs()
        val part = File(dest.parentFile, dest.name + ".part")
        val already = if (part.isFile) part.length() else 0L
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20_000
            readTimeout = 60_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "VoskCaptions/1.0 (Android)")
            if (already > 0) setRequestProperty("Range", "bytes=$already-")
        }
        try {
            val code = conn.responseCode
            if (code == 416 && already > 0) { part.renameTo(dest); return }
            if (code == 404) throw IOException("Ce modèle n'existe pas sur Hugging Face (${url.substringAfter("Xenova/").substringBefore("/resolve")}).")
            if (code !in 200..299) throw IOException("Erreur HTTP $code")
            val append = code == 206
            val total = conn.contentLengthLong.let { if (it > 0) it + (if (append) already else 0L) else -1L }
            var done = if (append) already else 0L
            var last = -2
            conn.inputStream.use { ins ->
                FileOutputStream(part, append).use { fos ->
                    val buf = ByteArray(1 shl 16)
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val n = ins.read(buf)
                        if (n < 0) break
                        fos.write(buf, 0, n)
                        done += n
                        val pct = if (total > 0) (done * 100 / total).toInt().coerceIn(0, 100) else -1
                        if (pct != last) { last = pct; onProgress(pct) }
                    }
                }
            }
            if (total > 0 && done < total) throw IOException("Téléchargement interrompu, relancez pour reprendre.")
            if (!part.renameTo(dest)) throw IOException("Impossible d'enregistrer ${dest.name}")
        } finally {
            conn.disconnect()
        }
    }

    suspend fun deletePair(pair: String) {
        engineLock.withLock { closeEngines() }
        fileLock.withLock {
            withContext(Dispatchers.IO) {
                File(packsDir, pair).deleteRecursively()
                File(packsDir, DL_PREFIX + pair).deleteRecursively()
            }
        }
        refreshDownloaded()
    }

    /** Déplace les packs internes vers /VoskCaptions/traduction dès que l'accès est accordé. */
    private fun migrateToShared() {
        val target = packsDir
        val internal = internalDir
        if (target.absolutePath == internal.absolutePath) return
        val olds = internal.listFiles { f -> f.isDirectory }.orEmpty()
        if (olds.isEmpty()) return
        for (d in olds) {
            val dest = File(target, d.name)
            runCatching {
                if (!dest.exists()) {
                    val tmp = File(target, ".mv_" + d.name)
                    tmp.deleteRecursively()
                    d.copyRecursively(tmp, overwrite = true)
                    if (!tmp.renameTo(dest)) { tmp.deleteRecursively(); return@runCatching }
                }
                d.deleteRecursively()
            }
        }
    }

    // ---------------------------------------------------------------- traduction

    /** Traduit hors ligne. Lève [LanguageModelMissingException] si une paire n'est pas installée. */
    suspend fun translate(text: String, src: String, tgt: String): String {
        if (text.isBlank() || src == tgt) return text
        val path = route(src, tgt, _downloaded.value)
            ?: throw LanguageModelMissingException(
                neededPairs(src, tgt)?.firstOrNull { it !in _downloaded.value } ?: "$src-$tgt"
            )
        return engineLock.withLock {
            withContext(Dispatchers.Default) {
                var cur = text
                for (pair in path) {
                    currentCoroutineContext().ensureActive()
                    cur = engine(pair).translate(cur)
                }
                cur
            }
        }
    }

    /** Précharge les modèles (évite l'attente au premier sous-titre). */
    suspend fun prepare(src: String, tgt: String) {
        val path = route(src, tgt, _downloaded.value) ?: return
        try {
            engineLock.withLock { withContext(Dispatchers.Default) { path.forEach { engine(it) } } }
        } catch (e: CancellationException) {
            throw e
        } catch (_: Throwable) {
        }
    }

    private fun engine(pair: String): MarianTranslator {
        engines[pair]?.let { return it }
        val files = PackFiles.find(File(packsDir, pair)) ?: throw LanguageModelMissingException(pair)
        val t = try {
            MarianTranslator(files, env)
        } catch (e: OutOfMemoryError) {
            closeEngines()
            throw IOException("Mémoire insuffisante pour charger ${displayName(pair)}")
        }
        engines[pair] = t
        while (engines.size > MAX_CACHED) {
            val oldest = engines.keys.first()
            engines.remove(oldest)?.let { runCatching { it.close() } }
        }
        return t
    }

    private fun closeEngines() {
        engines.values.forEach { runCatching { it.close() } }
        engines.clear()
    }

    /** Détecte la langue (modèle ML Kit embarqué, hors ligne) puis traduit vers [target]. */
    suspend fun translateAuto(text: String, target: String): AutoTranslation {
        val detected = detectLanguage(text) ?: settings.state.value.sourceLang
        if (detected == target) return AutoTranslation(detected, null)
        return AutoTranslation(detected, translate(text, detected, target))
    }

    suspend fun detectLanguage(text: String): String? {
        val tag = identifier.identifyLanguage(text).await()
        if (tag == "und") return null
        val base = when (val b = tag.substringBefore('-').lowercase()) {
            "nb", "nn" -> "no"
            else -> b
        }
        return base.takeIf { it in LANGUAGES }
    }

    /** Libère les modèles en mémoire (changement de paire de langues). */
    fun closeAll() {
        if (engineLock.tryLock()) {
            try { closeEngines() } finally { engineLock.unlock() }
        }
    }
}
