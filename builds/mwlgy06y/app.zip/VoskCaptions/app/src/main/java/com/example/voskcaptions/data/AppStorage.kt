package com.example.voskcaptions.data

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import java.io.File

/** Emplacements de stockage : /VoskCaptions (survit à la désinstallation) si l'accès aux fichiers est accordé. */
object AppStorage {
    val sharedRoot: File get() = File(Environment.getExternalStorageDirectory(), "VoskCaptions")

    fun hasSharedAccess(context: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else context.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    fun internalDir(context: Context, name: String): File = File(context.filesDir, name).apply { mkdirs() }

    /** Dossier permanent /VoskCaptions/<sub> si possible, sinon dossier interne <internalName>. */
    fun dir(context: Context, sub: String, internalName: String): File {
        if (hasSharedAccess(context)) {
            val d = File(sharedRoot, sub)
            d.mkdirs()
            if (d.isDirectory && d.canWrite()) {
                runCatching { File(sharedRoot, ".nomedia").takeIf { !it.exists() }?.createNewFile() }
                return d
            }
        }
        return internalDir(context, internalName)
    }
}
