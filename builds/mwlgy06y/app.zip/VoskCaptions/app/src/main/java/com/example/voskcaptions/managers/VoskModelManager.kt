package com.example.voskcaptions.managers

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import com.example.voskcaptions.data.SettingsRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.vosk.Model
import org.vosk.Recognizer
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.FilterInputStream
import java.io.IOException
import java.io.InputStream
import java.util.Locale
import java.util.zip.ZipInputStream

data class ModelInfo(
    val name: String,
    val path: String,
    val sizeBytes: Long,
    val voskLangCode: String?,
    val languageName: String,
    val mlKitLang: String?
)

sealed interface ModelState {
    data object Idle : ModelState
    /** percent = -1 si la taille de l'archive est inconnue. */
    data class Extracting(val percent: Int, val message: String) : ModelState
    data class Loading(val name: String) : ModelState
    data class Ready(val info: ModelInfo) : ModelState
    data class Error(val message: String) : ModelState
}

class VoskModelManager(
    private val context: Context,
    private val settings: SettingsRepository
) {
    companion object {
        const val SAMPLE_RATE = 16_000f
        private const val BUFFER_SIZE = 1 shl 16          // 64 Kio : RAM constante quelle que soit la taille du zip
        private const val IMPORT_PREFIX = ".import_"
    }

    /** Stockage interne : effacé à la désinstallation (utilisé seulement sans l'accès aux fichiers). */
    private val internalDir = File(context.filesDir, "vosk_models").apply { mkdirs() }

    /** Dossier permanent /VoskCaptions/models : survit à la désinstallation de l'appli. */
    val sharedRoot: File get() = File(Environment.getExternalStorageDirectory(), "VoskCaptions")
    private val sharedDir: File get() = File(sharedRoot, "models")
    private val lastModelFile: File get() = File(sharedRoot, "dernier_modele.txt")

    fun hasSharedAccess(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else context.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    /** Dossier actif des modèles : permanent si l'accès aux fichiers est accordé, interne sinon. */
    private val modelsDir: File
        get() {
            if (hasSharedAccess()) {
                val d = sharedDir
                d.mkdirs()
                if (d.isDirectory && d.canWrite()) {
                    runCatching { File(sharedRoot, ".nomedia").takeIf { !it.exists() }?.createNewFile() }
                    return d
                }
            }
            return internalDir
        }

    private val _persistent = MutableStateFlow(false)
    /** true quand les modèles sont rangés dans le dossier permanent. */
    val persistent: StateFlow<Boolean> = _persistent.asStateFlow()

    private val _state = MutableStateFlow<ModelState>(ModelState.Idle)
    val state: StateFlow<ModelState> = _state.asStateFlow()

    private val _installed = MutableStateFlow<List<ModelInfo>>(emptyList())
    val installed: StateFlow<List<ModelInfo>> = _installed.asStateFlow()

    private val mutex = Mutex()
    private val modelLock = Any()
    private var model: Model? = null
    private var currentPath: String? = null

    // ---------------------------------------------------------------- API publique

    /**
     * Rafraîchit la liste. Si l'accès aux fichiers vient d'être accordé, déplace les modèles
     * internes vers le dossier permanent (une seule fois).
     */
    suspend fun refreshInstalled() = mutex.withLock {
        withContext(Dispatchers.IO) {
            migrateToSharedBlocking()
            refreshInstalledBlocking()
        }
    }

    /** Recharge automatiquement le dernier modèle utilisé (même après une réinstallation). */
    suspend fun restoreLastModel() {
        val name = withContext(Dispatchers.IO) {
            listOfNotNull(settings.state.value.lastModel, readSharedLastModel())
                .firstOrNull { File(modelsDir, it).isDirectory }
        } ?: return
        loadModel(name)
    }

    /** Importe une ou plusieurs archives .zip de modèles Vosk (sélection multiple). */
    suspend fun importZips(uris: List<Uri>): ImportResult = mutex.withLock {
        withContext(Dispatchers.IO) {
            val sources = uris.map { Source.Zip(it, queryDisplayName(it), querySize(it)) }
            runBatch(sources)
        }
    }

    /**
     * Importe tous les modèles d'un dossier choisi (et de ses sous-dossiers) :
     * archives .zip ET modèles déjà décompressés (dossiers am/conf/graph).
     */
    suspend fun importFolder(treeUri: Uri): ImportResult = mutex.withLock {
        withContext(Dispatchers.IO) {
            try {
                _state.value = ModelState.Extracting(-1, "Analyse du dossier…")
                val rootId = DocumentsContract.getTreeDocumentId(treeUri)
                val rootName = queryDocName(treeUri, rootId) ?: "modele"
                val sources = mutableListOf<Source>()
                scanTree(treeUri, rootId, rootName, 0, sources)
                if (sources.isEmpty()) {
                    restoreState()
                    ImportResult(emptyList(), listOf("Aucun modèle Vosk (.zip ou dossier décompressé) trouvé dans ce dossier."))
                } else runBatch(sources)
            } catch (e: CancellationException) {
                restoreState(); throw e
            } catch (t: Throwable) {
                restoreState()
                ImportResult(emptyList(), listOf("Lecture du dossier impossible : ${friendly(t)}"))
            }
        }
    }

    // ---------------------------------------------------------------- import groupé

    data class ImportResult(val imported: List<String>, val errors: List<String>)

    private sealed interface Source {
        val name: String
        data class Zip(val uri: Uri, override val name: String, val size: Long) : Source
        data class Dir(val treeUri: Uri, val docId: String, override val name: String) : Source
    }

    private suspend fun runBatch(sources: List<Source>): ImportResult {
        val imported = mutableListOf<String>()
        val errors = mutableListOf<String>()
        sources.forEachIndexed { i, src ->
            currentCoroutineContext().ensureActive()
            val label = if (sources.size > 1) "(${i + 1}/${sources.size}) ${src.name}" else src.name
            try {
                imported += when (src) {
                    is Source.Zip -> installZip(src.uri, src.name, src.size, label)
                    is Source.Dir -> installDir(src, label)
                }
            } catch (e: CancellationException) {
                restoreState(); throw e
            } catch (t: Throwable) {
                errors += "${src.name} : ${friendly(t)}"
            }
        }
        refreshInstalledBlocking()
        try {
            when {
                imported.size == 1 -> loadBlocking(imported[0])                       // comportement d'avant : on charge le modèle importé
                currentPath == null && imported.isNotEmpty() -> loadBlocking(imported[0])
                imported.isEmpty() && errors.isNotEmpty() -> _state.value = ModelState.Error(errors.first())
                else -> restoreState()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (t: Throwable) {
            _state.value = ModelState.Error(friendly(t))
            errors += friendly(t)
        }
        return ImportResult(imported.distinct(), errors)
    }

    private fun restoreState() {
        _state.value = currentPath?.let { ModelState.Ready(describe(File(it))) } ?: ModelState.Idle
    }

    private suspend fun installZip(uri: Uri, displayName: String, size: Long, label: String): String {
        val tmp = File(modelsDir, IMPORT_PREFIX + System.nanoTime())
        try {
            _state.value = ModelState.Extracting(0, label)
            extractZip(uri, tmp, size, label)
            return finalizeInstall(tmp, sanitize(displayName.replace(Regex("(?i)\\.zip$"), "")))
        } finally {
            if (tmp.exists()) tmp.deleteRecursively()
        }
    }

    private suspend fun installDir(src: Source.Dir, label: String): String {
        val tmp = File(modelsDir, IMPORT_PREFIX + System.nanoTime())
        try {
            _state.value = ModelState.Extracting(-1, label)
            val total = treeSize(src.treeUri, src.docId)
            if (total > 0 && modelsDir.usableSpace < total + (50L shl 20)) {
                throw IOException("Espace de stockage insuffisant pour copier ce modèle.")
            }
            val progress = LongArray(1)
            copyTree(src.treeUri, src.docId, tmp, total, progress, label)
            return finalizeInstall(tmp, sanitize(src.name))
        } finally {
            if (tmp.exists()) tmp.deleteRecursively()
        }
    }

    /** Détecte la racine, valide, puis déplace le modèle dans vosk_models/<baseName>. */
    private fun finalizeInstall(tmp: File, baseName: String): String {
        val root = findModelRoot(tmp)
            ?: error("Aucune racine de modèle Vosk valide trouvée (dossiers am/conf/graph ou final.mdl introuvables).")
        validate(root)
        val target = File(modelsDir, baseName)
        if (target.exists()) {
            if (currentPath == target.absolutePath) closeModelBlocking()
            target.deleteRecursively()
        }
        if (!root.renameTo(target)) {
            root.copyRecursively(target, overwrite = true)
        }
        return target.name
    }

    // ---------------------------------------------------------------- parcours d'un dossier (SAF)

    private data class DocEntry(val id: String, val name: String, val mime: String?, val size: Long) {
        val isDir get() = mime == DocumentsContract.Document.MIME_TYPE_DIR
    }

    private fun listChildren(treeUri: Uri, docId: String): List<DocEntry> {
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, docId)
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE
        )
        val out = mutableListOf<DocEntry>()
        context.contentResolver.query(childrenUri, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0) ?: continue
                out += DocEntry(id, c.getString(1) ?: id, c.getString(2), if (c.isNull(3)) -1L else c.getLong(3))
            }
        }
        return out
    }

    private fun queryDocName(treeUri: Uri, docId: String): String? =
        context.contentResolver.query(
            DocumentsContract.buildDocumentUriUsingTree(treeUri, docId),
            arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null
        )?.use { c -> if (c.moveToFirst()) c.getString(0) else null }

    private fun looksLikeModel(children: List<DocEntry>): Boolean {
        val dirs = children.filter { it.isDir }.map { it.name }.toSet()
        val files = children.filter { !it.isDir }.map { it.name }.toSet()
        return "final.mdl" in files ||
            ("am" in dirs && ("conf" in dirs || "graph" in dirs)) ||
            ("conf" in dirs && "graph" in dirs)
    }

    private suspend fun scanTree(treeUri: Uri, docId: String, name: String, depth: Int, out: MutableList<Source>) {
        currentCoroutineContext().ensureActive()
        val children = listChildren(treeUri, docId)
        if (looksLikeModel(children)) {
            out += Source.Dir(treeUri, docId, name)
            return
        }
        for (c in children.sortedBy { it.name.lowercase() }) {
            if (c.name.startsWith(".") || c.name == "__MACOSX") continue
            if (c.isDir) {
                if (depth < 6) scanTree(treeUri, c.id, c.name, depth + 1, out)
            } else if (c.name.endsWith(".zip", ignoreCase = true)) {
                out += Source.Zip(DocumentsContract.buildDocumentUriUsingTree(treeUri, c.id), c.name, c.size)
            }
        }
    }

    private suspend fun treeSize(treeUri: Uri, docId: String): Long {
        currentCoroutineContext().ensureActive()
        return listChildren(treeUri, docId).sumOf { c ->
            if (c.isDir) treeSize(treeUri, c.id) else c.size.coerceAtLeast(0)
        }
    }

    private suspend fun copyTree(treeUri: Uri, docId: String, dest: File, total: Long, done: LongArray, label: String) {
        dest.mkdirs()
        val buf = ByteArray(BUFFER_SIZE)
        var lastPercent = -2
        for (c in listChildren(treeUri, docId)) {
            currentCoroutineContext().ensureActive()
            if (c.name.contains('/') || c.name == ".." ) continue
            val out = File(dest, c.name)
            if (c.isDir) {
                copyTree(treeUri, c.id, out, total, done, label)
                continue
            }
            val uri = DocumentsContract.buildDocumentUriUsingTree(treeUri, c.id)
            val input = context.contentResolver.openInputStream(uri) ?: throw IOException("Impossible de lire ${c.name}")
            input.use { ins ->
                FileOutputStream(out).use { fos ->
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        fos.write(buf, 0, n)
                        done[0] = done[0] + n.toLong()
                        val pct = if (total > 0) (done[0] * 100 / total).toInt().coerceIn(0, 99) else -1
                        if (pct != lastPercent) {
                            lastPercent = pct
                            _state.value = ModelState.Extracting(pct, label)
                        }
                    }
                }
            }
        }
    }

    /** Charge (de façon asynchrone sur Dispatchers.IO) un modèle déjà installé. */
    suspend fun loadModel(name: String): Result<ModelInfo> = mutex.withLock {
        withContext(Dispatchers.IO) {
            try {
                Result.success(loadBlocking(name))
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                _state.value = ModelState.Error(friendly(t))
                Result.failure(Exception(friendly(t), t))
            }
        }
    }

    suspend fun deleteModel(name: String) = mutex.withLock {
        withContext(Dispatchers.IO) {
            val dir = File(modelsDir, name)
            if (currentPath == dir.absolutePath) {
                closeModelBlocking()
                _state.value = ModelState.Idle
                settings.update { it.copy(lastModel = null) }
            }
            if (readSharedLastModel() == name) runCatching { lastModelFile.delete() }
            dir.deleteRecursively()
            refreshInstalledBlocking()
        }
    }

    /** Crée un Recognizer 16 kHz mono sur le modèle courant (null si aucun modèle chargé). */
    fun createRecognizer(): Recognizer? = synchronized(modelLock) {
        model?.let { Recognizer(it, SAMPLE_RATE) }
    }

    /** Libère le modèle natif (Model.close()). Le Recognizer doit être fermé par son propriétaire. */
    fun release() {
        synchronized(modelLock) { closeModelBlocking() }
        _state.value = ModelState.Idle
    }

    // ---------------------------------------------------------------- chargement

    private fun loadBlocking(name: String): ModelInfo {
        val dir = File(modelsDir, name)
        require(dir.isDirectory) { "Modèle introuvable : $name" }
        _state.value = ModelState.Loading(name)
        closeModelBlocking()                    // libère l'ancien modèle AVANT d'allouer le nouveau
        val info = describe(dir)
        val loaded = Model(dir.absolutePath)    // peut durer plusieurs dizaines de secondes (gros modèles)
        synchronized(modelLock) {
            model = loaded
            currentPath = dir.absolutePath
        }
        settings.update { s ->
            s.copy(lastModel = name, sourceLang = info.mlKitLang ?: s.sourceLang)
        }
        if (dir.parentFile?.absolutePath == sharedDir.absolutePath) {
            runCatching { lastModelFile.writeText(name) }
        }
        _state.value = ModelState.Ready(info)
        return info
    }

    private fun closeModelBlocking() {
        synchronized(modelLock) {
            model?.let { runCatching { it.close() } }
            model = null
            currentPath = null
        }
        System.gc()
    }

    // ---------------------------------------------------------------- extraction ZIP en flux

    private class CountingInputStream(input: InputStream) : FilterInputStream(input) {
        var count = 0L
        override fun read(): Int = super.read().also { if (it >= 0) count++ }
        override fun read(b: ByteArray, off: Int, len: Int): Int =
            super.read(b, off, len).also { if (it > 0) count += it }
    }

    private suspend fun extractZip(uri: Uri, destDir: File, totalBytes: Long, label: String) {
        destDir.mkdirs()
        if (totalBytes > 0 && destDir.usableSpace < totalBytes * 2) {
            throw IOException("Espace de stockage insuffisant pour extraire ce modèle.")
        }
        val destCanonical = destDir.canonicalPath + File.separator
        val raw = context.contentResolver.openInputStream(uri) ?: throw IOException("Impossible d'ouvrir l'archive.")
        val counting = CountingInputStream(raw)
        val buf = ByteArray(BUFFER_SIZE)
        var lastPercent = -2

        ZipInputStream(BufferedInputStream(counting, BUFFER_SIZE)).use { zis ->
            while (true) {
                currentCoroutineContext().ensureActive()
                val entry = zis.nextEntry ?: break
                val entryName = entry.name.replace('\\', '/')
                if (entryName.startsWith("__MACOSX/") || entryName.endsWith(".DS_Store")) continue

                val out = File(destDir, entryName)
                if (!out.canonicalPath.startsWith(destCanonical)) {
                    throw SecurityException("Entrée ZIP invalide : $entryName")   // zip-slip
                }
                if (entry.isDirectory) {
                    out.mkdirs()
                    continue
                }
                out.parentFile?.mkdirs()
                FileOutputStream(out).use { fos ->
                    while (true) {
                        val n = zis.read(buf)
                        if (n < 0) break
                        fos.write(buf, 0, n)
                        val pct = if (totalBytes > 0) (counting.count * 100 / totalBytes).toInt().coerceIn(0, 99) else -1
                        if (pct != lastPercent) {
                            lastPercent = pct
                            _state.value = ModelState.Extracting(pct, label)
                        }
                    }
                }
                zis.closeEntry()
            }
        }
    }

    // ---------------------------------------------------------------- détection / validation

    private fun isModelRoot(d: File): Boolean {
        val hasAm = File(d, "am").isDirectory
        val hasConf = File(d, "conf").isDirectory
        val hasGraph = File(d, "graph").isDirectory
        val hasFinal = File(d, "am/final.mdl").isFile || File(d, "final.mdl").isFile
        return hasFinal || (hasAm && (hasConf || hasGraph)) || (hasConf && hasGraph)
    }

    /** Parcours en largeur : retourne le répertoire le moins profond qui ressemble à une racine de modèle Vosk. */
    fun findModelRoot(start: File): File? {
        val queue = ArrayDeque<File>()
        queue.add(start)
        while (queue.isNotEmpty()) {
            val dir = queue.removeFirst()
            if (isModelRoot(dir)) return dir
            dir.listFiles()?.filter { it.isDirectory }?.sortedBy { it.name }?.let { queue.addAll(it) }
        }
        return null
    }

    private fun validate(root: File) {
        val hasFinal = File(root, "am/final.mdl").isFile || File(root, "final.mdl").isFile
        if (!hasFinal) throw IOException("Modèle invalide : fichier final.mdl absent.")
        val conf = File(root, "conf")
        if (!conf.isDirectory || !(File(conf, "model.conf").isFile || File(conf, "mfcc.conf").isFile)) {
            throw IOException("Modèle invalide : dossier conf/ incomplet.")
        }
        if (!File(root, "graph").isDirectory && !File(root, "HCLG.fst").isFile) {
            throw IOException("Modèle invalide : dossier graph/ absent.")
        }
    }

    // ---------------------------------------------------------------- métadonnées

    private fun readSharedLastModel(): String? =
        if (hasSharedAccess()) runCatching { lastModelFile.readText().trim() }.getOrNull()?.takeIf { it.isNotEmpty() } else null

    /** Copie les modèles du stockage interne vers le dossier permanent puis supprime l'original. */
    private fun migrateToSharedBlocking() {
        val target = modelsDir
        if (target.absolutePath == internalDir.absolutePath) return
        // restes d'imports interrompus
        target.listFiles { f -> f.name.startsWith(IMPORT_PREFIX) }?.forEach { it.deleteRecursively() }
        val olds = internalDir.listFiles { f -> f.isDirectory }.orEmpty()
        if (olds.isEmpty()) return
        for (d in olds) {
            if (d.name.startsWith(IMPORT_PREFIX)) { d.deleteRecursively(); continue }
            val dest = File(target, d.name)
            try {
                if (!dest.exists()) {
                    _state.value = ModelState.Extracting(-1, "Déplacement vers le stockage permanent : ${d.name}")
                    val tmp = File(target, IMPORT_PREFIX + System.nanoTime())
                    try {
                        d.copyRecursively(tmp, overwrite = true)
                        if (!tmp.renameTo(dest)) throw IOException("Déplacement impossible")
                    } finally {
                        if (tmp.exists()) tmp.deleteRecursively()
                    }
                }
                synchronized(modelLock) {
                    if (currentPath == d.absolutePath) currentPath = dest.absolutePath
                }
                if (settings.state.value.lastModel == d.name) runCatching { lastModelFile.writeText(d.name) }
                d.deleteRecursively()
            } catch (t: Throwable) {
                // on garde la copie interne ; nouvel essai au prochain rafraîchissement
            }
        }
        restoreState()
    }

    private fun refreshInstalledBlocking() {
        _persistent.value = modelsDir.absolutePath != internalDir.absolutePath
        _installed.value = modelsDir.listFiles { f -> f.isDirectory && !f.name.startsWith(IMPORT_PREFIX) }
            .orEmpty()
            .sortedBy { it.name.lowercase() }
            .map { describe(it) }
    }

    private fun describe(dir: File): ModelInfo {
        val code = detectLangCode(dir.name)
        val iso = code?.substringBefore('-')?.let { mapOf("cn" to "zh", "vn" to "vi", "kz" to "kk").getOrDefault(it, it) }
        return ModelInfo(
            name = dir.name,
            path = dir.absolutePath,
            sizeBytes = dir.walkTopDown().filter { it.isFile }.sumOf { it.length() },
            voskLangCode = code,
            languageName = languageName(iso, code),
            mlKitLang = iso?.takeIf { it in TranslationManager.LANGUAGES }
        )
    }

    private val nameRegex = Regex("(?i)vosk-model(?:-small|-big|-spk|-lgraph)*-([a-z]{2,3}(?:-[a-z]{2,3})?)(?:-|$)")

    private fun detectLangCode(name: String): String? =
        nameRegex.find(name)?.groupValues?.get(1)?.lowercase()

    private fun languageName(iso: String?, code: String?): String {
        if (iso == null) return "Inconnue"
        val n = Locale.forLanguageTag(iso).getDisplayLanguage(Locale.getDefault())
        return if (n.isBlank() || n.equals(iso, true)) (code ?: iso) else n.replaceFirstChar { it.uppercase() }
    }

    private fun sanitize(s: String) = s.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "model_${System.currentTimeMillis()}" }

    private fun queryDisplayName(uri: Uri): String =
        context.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) c.getString(i) else null
        } ?: uri.lastPathSegment ?: "model.zip"

    private fun querySize(uri: Uri): Long =
        context.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.SIZE)
            if (i >= 0 && c.moveToFirst() && !c.isNull(i)) c.getLong(i) else -1L
        } ?: -1L

    private fun friendly(t: Throwable): String = when (t) {
        is OutOfMemoryError -> "Mémoire insuffisante pour charger ce modèle. Essayez un modèle plus léger."
        else -> t.message ?: t.javaClass.simpleName
    }
}
