package com.example.voskcaptions.translation

import java.io.File
import java.text.Normalizer

/**
 * Découpage SentencePiece « unigram » (fichiers .spm des modèles OPUS-MT / Marian),
 * lu directement depuis le protobuf, sans bibliothèque native.
 */
class SentencePieceModel(file: File) {
    private val scores = HashMap<String, Float>(80_000)
    private var maxPieceLen = 1          // en points de code
    private var minScore = 0f

    init {
        val bytes = file.readBytes()
        val r = Reader(bytes, 0, bytes.size)
        while (r.hasMore()) {
            val key = r.varint()
            val field = (key ushr 3).toInt()
            val wire = (key and 7).toInt()
            if (field == 1 && wire == 2) {
                val len = r.varint().toInt()
                parsePiece(Reader(bytes, r.pos, r.pos + len))
                r.pos += len
            } else r.skip(wire)
        }
        require(scores.isNotEmpty()) { "Fichier SentencePiece vide ou invalide : ${file.name}" }
    }

    private fun parsePiece(r: Reader) {
        var piece: String? = null
        var score = 0f
        var type = 1 // NORMAL
        while (r.hasMore()) {
            val key = r.varint()
            val field = (key ushr 3).toInt()
            val wire = (key and 7).toInt()
            when {
                field == 1 && wire == 2 -> piece = r.string()
                field == 2 && wire == 5 -> score = Float.fromBits(r.fixed32())
                field == 3 && wire == 0 -> type = r.varint().toInt()
                else -> r.skip(wire)
            }
        }
        val p = piece ?: return
        if (type != 1 && type != 4) return       // on ignore <unk>, <s>, </s>, octets…
        val s = if (type == 4) 0f else score
        scores[p] = s
        if (type == 1 && s < minScore) minScore = s
        maxPieceLen = maxOf(maxPieceLen, p.codePointCount(0, p.length))
    }

    /** Renvoie les morceaux (ex. « ▁Bon », « jour »). Les caractères inconnus donnent "<unk>". */
    fun encode(text: String): List<String> {
        val norm = Normalizer.normalize(text, Normalizer.Form.NFKC).trim().replace(Regex("\\s+"), " ")
        if (norm.isEmpty()) return emptyList()
        val s = "▁" + norm.replace(' ', '▁')

        // limites des points de code
        val bounds = ArrayList<Int>(s.length + 1)
        var i = 0
        while (i < s.length) { bounds.add(i); i += Character.charCount(s.codePointAt(i)) }
        bounds.add(s.length)
        val m = bounds.size - 1

        val best = FloatArray(m + 1) { Float.NEGATIVE_INFINITY }
        val back = IntArray(m + 1)
        val unk = BooleanArray(m + 1)
        best[0] = 0f
        val unkScore = minScore - 10f
        for (a in 0 until m) {
            if (best[a] == Float.NEGATIVE_INFINITY) continue
            var single = false
            val maxB = minOf(m, a + maxPieceLen)
            for (b in a + 1..maxB) {
                val sc = scores[s.substring(bounds[a], bounds[b])] ?: continue
                if (b == a + 1) single = true
                val c = best[a] + sc
                if (c > best[b]) { best[b] = c; back[b] = a; unk[b] = false }
            }
            if (!single) {
                val c = best[a] + unkScore
                if (c > best[a + 1]) { best[a + 1] = c; back[a + 1] = a; unk[a + 1] = true }
            }
        }
        val out = ArrayList<String>()
        var e = m
        while (e > 0) {
            val a = back[e]
            out.add(if (unk[e]) UNK else s.substring(bounds[a], bounds[e]))
            e = a
        }
        out.reverse()
        // plusieurs inconnus d'affilée = un seul <unk>, comme SentencePiece
        return out.filterIndexed { k, p -> !(p == UNK && k > 0 && out[k - 1] == UNK) }
    }

    companion object { const val UNK = "<unk>" }

    private class Reader(val b: ByteArray, var pos: Int, val end: Int) {
        fun hasMore() = pos < end
        fun varint(): Long {
            var result = 0L
            var shift = 0
            while (true) {
                val x = b[pos++].toInt() and 0xff
                result = result or ((x and 0x7f).toLong() shl shift)
                if (x < 0x80) return result
                shift += 7
            }
        }
        fun fixed32(): Int {
            val v = (b[pos].toInt() and 0xff) or ((b[pos + 1].toInt() and 0xff) shl 8) or
                ((b[pos + 2].toInt() and 0xff) shl 16) or ((b[pos + 3].toInt() and 0xff) shl 24)
            pos += 4
            return v
        }
        fun string(): String {
            val len = varint().toInt()
            val s = String(b, pos, len, Charsets.UTF_8)
            pos += len
            return s
        }
        fun skip(wire: Int) {
            when (wire) {
                0 -> varint()
                1 -> pos += 8
                2 -> { val len = varint().toInt(); pos += len }
                5 -> pos += 4
                else -> throw IllegalStateException("Protobuf : type $wire non géré")
            }
        }
    }
}
