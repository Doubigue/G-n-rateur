package com.example.voskcaptions.screen

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo

data class ScreenSection(val text: String, val top: Int, val left: Int)

/**
 * Lit le texte affiché à l'écran grâce au service d'accessibilité (aucune capture d'écran)
 * et le regroupe par section : un message WhatsApp/SMS = un élément de liste = une section.
 */
object ScreenTextExtractor {
    private const val MAX_DEPTH = 80
    private const val MAX_SECTIONS = 150
    private const val MAX_CHARS = 20_000
    private val TIME = Regex("^\\d{1,2}[:h.]\\d{2}( ?[AaPp]\\.? ?[Mm]\\.?)?$")
    private val LIST_CLASSES = listOf("RecyclerView", "ListView", "GridView", "ScrollView", "ViewPager", "LazyColumn")

    private class Piece(val text: String, val top: Int, val left: Int)

    /** Renvoie (nom de l'appli lue, sections dans l'ordre de lecture). */
    fun extract(service: AccessibilityService): Pair<String, List<ScreenSection>> {
        val own = service.packageName
        val roots = runCatching {
            service.windows
                .filter { it.type == AccessibilityWindowInfo.TYPE_APPLICATION }
                .mapNotNull { it.root }
                .filter { it.packageName?.toString() != own }
        }.getOrDefault(emptyList())
            .ifEmpty { listOfNotNull(service.rootInActiveWindow).filter { it.packageName?.toString() != own } }

        val pkg = roots.firstOrNull()?.packageName?.toString().orEmpty()
        val groups = LinkedHashMap<Int, MutableList<Piece>>()
        var nextGroup = 0
        val rect = Rect()

        fun walk(node: AccessibilityNodeInfo, depth: Int, group: Int?) {
            if (depth > MAX_DEPTH || !node.isVisibleToUser) return
            var g = group
            val cls = node.className?.toString().orEmpty()
            val isList = node.collectionInfo != null || LIST_CLASSES.any { cls.endsWith(it) }

            if (!node.isPassword) {
                val t = clean(node.text?.toString())
                if (t != null) {
                    node.getBoundsInScreen(rect)
                    val key = g ?: nextGroup++
                    groups.getOrPut(key) { mutableListOf() }.add(Piece(t, rect.top, rect.left))
                }
            }
            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                // chaque élément d'une liste (bulle de message, conversation…) devient sa propre section
                val childGroup = if (isList) nextGroup++ else g
                walk(child, depth + 1, childGroup)
            }
        }
        roots.forEach { walk(it, 0, null) }

        var chars = 0
        val sections = groups.values
            .mapNotNull { pieces ->
                val lines = pieces.map { it.text }.fold(mutableListOf<String>()) { acc, s ->
                    if (acc.lastOrNull() != s) acc.add(s); acc
                }
                val text = lines.joinToString("\n").trim()
                if (text.isEmpty()) null
                else ScreenSection(text, pieces.minOf { it.top }, pieces.minOf { it.left })
            }
            .distinctBy { it.text }
            .sortedWith(compareBy({ it.top }, { it.left }))
            .takeWhile { chars += it.text.length; chars <= MAX_CHARS }
            .take(MAX_SECTIONS)

        return appLabel(service, pkg) to sections
    }

    private fun clean(raw: String?): String? {
        val t = raw?.trim()?.replace(Regex("[ \\t]+"), " ") ?: return null
        if (t.length < 2) return null
        if (TIME.matches(t)) return null
        if (t.none { it.isLetter() }) return null        // chiffres, ponctuation, emojis seuls
        return t
    }

    @Suppress("DEPRECATION")
    private fun appLabel(service: AccessibilityService, pkg: String): String = runCatching {
        val pm = service.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    }.getOrDefault(pkg)
}
