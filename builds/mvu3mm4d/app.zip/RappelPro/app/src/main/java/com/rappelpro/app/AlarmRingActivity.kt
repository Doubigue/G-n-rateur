package com.rappelpro.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.rappelpro.app.databinding.ActivityAlarmRingBinding

class AlarmRingActivity : AppCompatActivity() {
    private lateinit var b: ActivityAlarmRingBinding
    private var reminderId = -1

    private val stopReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) = finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        b = ActivityAlarmRingBinding.inflate(layoutInflater)
        setContentView(b.root)
        bind(intent)

        b.btnStop.setOnClickListener {
            startService(Intent(this, AlarmService::class.java).setAction(AlarmService.ACTION_STOP))
            finish()
        }
        b.btnSnooze.setOnClickListener {
            startService(
                Intent(this, AlarmService::class.java)
                    .setAction(AlarmService.ACTION_SNOOZE)
                    .putExtra(AlarmScheduler.EXTRA_ID, reminderId)
            )
            finish()
        }
        ContextCompat.registerReceiver(
            this, stopReceiver, IntentFilter(AlarmService.ACTION_STOPPED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        bind(intent)
    }

    private fun bind(i: Intent) {
        reminderId = i.getIntExtra(AlarmScheduler.EXTRA_ID, -1)
        val r = ReminderStore.get(this, reminderId)
        b.tvRingTime.text = r?.let { Utils.time(it.hour, it.minute) } ?: "--:--"
        b.tvRingName.text = r?.name ?: "Rappel"
        b.tvRingInfo.text = r?.info?.takeIf { it.isNotBlank() }
            ?: "Vous avez programmé ce rappel pour cette heure."
        b.btnSnooze.text = "Répéter dans ${AlarmService.SNOOZE_MINUTES} min"
    }

    override fun onDestroy() {
        try { unregisterReceiver(stopReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }
}
