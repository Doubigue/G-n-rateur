package com.rappelpro.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra(AlarmScheduler.EXTRA_ID, -1)
        if (id < 0) return
        val snooze = intent.getBooleanExtra(AlarmScheduler.EXTRA_SNOOZE, false)
        val r = ReminderStore.get(context, id) ?: return

        if (!snooze) {
            if (r.repeat == Reminder.REPEAT_ONCE) {
                r.enabled = false                       // rappel unique : s'éteint après sonnerie
                ReminderStore.upsert(context, r)
            } else {
                AlarmScheduler.schedule(context, r)     // reprogramme la prochaine occurrence
            }
        }

        val svc = Intent(context, AlarmService::class.java).apply {
            action = AlarmService.ACTION_START
            putExtra(AlarmScheduler.EXTRA_ID, id)
        }
        ContextCompat.startForegroundService(context, svc)
    }
}
