package com.rappelpro.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Reprogramme toutes les alarmes après un redémarrage du téléphone,
 * une mise à jour de l'appli ou un changement d'heure / de fuseau.
 */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (action == null) return;
        boolean isBoot = Intent.ACTION_BOOT_COMPLETED.equals(action)
                || Intent.ACTION_LOCKED_BOOT_COMPLETED.equals(action)
                || "android.intent.action.QUICKBOOT_POWERON".equals(action);
        // Après un démarrage : on signale aussi les rappels tombés pendant que le téléphone était éteint.
        AlarmScheduler.rescheduleAll(context, isBoot);
    }
}
