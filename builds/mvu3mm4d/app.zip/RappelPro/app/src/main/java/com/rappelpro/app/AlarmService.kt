package com.rappelpro.app

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

class AlarmService : Service() {

    companion object {
        const val ACTION_START = "com.rappelpro.app.START"
        const val ACTION_STOP = "com.rappelpro.app.STOP"
        const val ACTION_SNOOZE = "com.rappelpro.app.SNOOZE"
        const val ACTION_STOPPED = "com.rappelpro.app.ALARM_STOPPED"
        const val NOTIF_ID = 4242
        const val SNOOZE_MINUTES = 10
        private const val MAX_RING_MS = 2 * 60 * 1000L
    }

    private var player: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val handler = Handler(Looper.getMainLooper())
    private var currentId = -1
    private val timeout = Runnable { onTimeout() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopAlarm()
            ACTION_SNOOZE -> {
                val id = intent.getIntExtra(AlarmScheduler.EXTRA_ID, currentId)
                ReminderStore.get(this, id)?.let { AlarmScheduler.snooze(this, it, SNOOZE_MINUTES) }
                stopAlarm()
            }
            else -> startAlarm(intent?.getIntExtra(AlarmScheduler.EXTRA_ID, -1) ?: -1)
        }
        return START_NOT_STICKY
    }

    private fun startAlarm(id: Int) {
        stopMedia()
        currentId = id
        val r = ReminderStore.get(this, id)
        NotificationHelper.ensureChannels(this)
        val notif = NotificationHelper.buildAlarmNotification(this, id, r)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIF_ID, notif)
        }

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "RappelPro:alarm").apply {
            acquire(MAX_RING_MS + 30_000L)
        }

        playSound(r?.ringtoneUri)
        if (r?.vibrate != false) vibrate()

        handler.removeCallbacks(timeout)
        handler.postDelayed(timeout, MAX_RING_MS)
    }

    private fun playSound(uriStr: String?) {
        val candidates = listOfNotNull(
            uriStr?.let { Uri.parse(it) },
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        )
        for (u in candidates) {
            var mp: MediaPlayer? = null
            try {
                mp = MediaPlayer().apply {
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    setDataSource(applicationContext, u)
                    isLooping = true
                    prepare()
                    start()
                }
                player = mp
                return
            } catch (_: Exception) {
                try { mp?.release() } catch (_: Exception) {}
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun vibrate() {
        val v: Vibrator = if (Build.VERSION.SDK_INT >= 31) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        vibrator = v
        val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build()
        v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 700, 500), 0), attrs)
    }

    private fun stopMedia() {
        try { player?.stop() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        player = null
        vibrator?.cancel()
        vibrator = null
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
    }

    private fun onTimeout() {
        ReminderStore.get(this, currentId)?.let {
            NotificationHelper.notifyMissed(this, it, "La sonnerie n'a pas été arrêtée.")
        }
        stopAlarm()
    }

    private fun stopAlarm() {
        handler.removeCallbacks(timeout)
        stopMedia()
        sendBroadcast(Intent(ACTION_STOPPED).setPackage(packageName))
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacks(timeout)
        stopMedia()
        super.onDestroy()
    }
}
