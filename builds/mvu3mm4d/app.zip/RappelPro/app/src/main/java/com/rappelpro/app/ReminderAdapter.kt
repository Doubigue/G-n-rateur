package com.rappelpro.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.rappelpro.app.databinding.ItemReminderBinding

class ReminderAdapter(
    private val onToggle: (Reminder, Boolean) -> Unit,
    private val onClick: (Reminder) -> Unit,
    private val onDelete: (Reminder) -> Unit
) : RecyclerView.Adapter<ReminderAdapter.VH>() {

    private var items: List<Reminder> = emptyList()

    fun submit(list: List<Reminder>) {
        items = list
        notifyDataSetChanged()
    }

    inner class VH(val b: ItemReminderBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemReminderBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val r = items[position]
        val b = h.b
        b.tvTime.text = Utils.time(r.hour, r.minute)
        b.tvName.text = r.name
        val whenText = if (r.repeat == Reminder.REPEAT_ONCE) Utils.date(r.dateMillis) else r.repeatLabel()
        b.tvMeta.text = "$whenText  ·  🎵 ${r.ringtoneTitle}"
        b.tvInfo.text = r.info
        b.tvInfo.visibility = if (r.info.isBlank()) View.GONE else View.VISIBLE
        b.root.alpha = if (r.enabled) 1f else 0.55f

        b.switchEnabled.setOnCheckedChangeListener(null)
        b.switchEnabled.isChecked = r.enabled
        b.switchEnabled.setOnCheckedChangeListener { _, checked -> onToggle(r, checked) }

        b.root.setOnClickListener { onClick(r) }
        b.btnDelete.setOnClickListener { onDelete(r) }
    }
}
