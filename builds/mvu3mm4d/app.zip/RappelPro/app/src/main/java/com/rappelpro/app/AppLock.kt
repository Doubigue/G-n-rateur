package com.rappelpro.app

import android.os.SystemClock
import android.widget.Toast
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

/**
 * Verrouillage de l'appli : empreinte / visage, ou à défaut code, schéma ou mot de passe du téléphone.
 * Seule l'ouverture de l'appli est protégée : les sonneries et leur écran d'arrêt ne sont jamais bloqués.
 */
object AppLock {
    private const val TIMEOUT_MS = 30_000L   // pas de nouvelle demande si on revient en moins de 30 s
    private const val AUTH = BiometricManager.Authenticators.BIOMETRIC_WEAK or
        BiometricManager.Authenticators.DEVICE_CREDENTIAL

    private var unlocked = false
    private var leftAt = 0L
    private var warned = false

    fun isUnlocked() = unlocked && SystemClock.elapsedRealtime() - leftAt < TIMEOUT_MS

    fun markLeft() {
        leftAt = SystemClock.elapsedRealtime()
    }

    private fun unlock() {
        unlocked = true
        leftAt = SystemClock.elapsedRealtime()
    }

    /** [onFailure] reçoit true si l'invite a été interrompue par le système (on réessaiera au retour). */
    fun authenticate(activity: FragmentActivity, onSuccess: () -> Unit, onFailure: (Boolean) -> Unit) {
        val can = BiometricManager.from(activity).canAuthenticate(AUTH)
        if (can != BiometricManager.BIOMETRIC_SUCCESS) {
            // Aucun verrouillage défini sur le téléphone : rien à vérifier.
            unlock()
            if (!warned) {
                warned = true
                Toast.makeText(
                    activity,
                    "Aucun verrouillage défini sur le téléphone : l'appli n'est pas protégée.",
                    Toast.LENGTH_LONG
                ).show()
            }
            onSuccess()
            return
        }
        val prompt = BiometricPrompt(
            activity, ContextCompat.getMainExecutor(activity),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    unlock()
                    onSuccess()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    onFailure(errorCode == BiometricPrompt.ERROR_CANCELED)
                }
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("RappelPro est verrouillé")
            .setSubtitle("Empreinte ou verrouillage du téléphone")
            .setAllowedAuthenticators(AUTH)
            .build()
        prompt.authenticate(info)
    }
}
