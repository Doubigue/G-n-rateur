package com.rappelpro.app

import org.json.JSONObject
import java.util.Calendar

data class Reminder(
    val id: Int,
    var name: String,
    var info: String = "",
    var ringtoneUri: String? = null,
    var ringtoneTitle: String = "Sonnerie par défaut",
    var hour: Int,
    var minute: Int,
    var dateMillis: Long,
    var repeat: Int = REPEAT_ONCE,
    var enabled: Boolean = true,
    var vibrate: Boolean = true
) {
    /** Premier déclenchement : date choisie + heure choisie. */
    private fun firstTrigger(): Calendar = Calendar.getInstance().apply {
        timeInMillis = dateMillis
        set(Calendar.HOUR_OF_DAY, hour)
        set(Calendar.MINUTE, minute)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }

    /** Prochain déclenchement strictement après [now], ou null si le rappel est passé. */
    fun nextTrigger(now: Long = System.currentTimeMillis()): Long? {
        val first = firstTrigger()
        if (first.timeInMillis > now) return first.timeInMillis
        return when (repeat) {
            REPEAT_DAILY -> {
                val c = Calendar.getInstance().apply {
                    timeInMillis = now
                    set(Calendar.HOUR_OF_DAY, hour)
                    set(Calendar.MINUTE, minute)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                if (c.timeInMillis <= now) c.add(Calendar.DAY_OF_YEAR, 1)
                c.timeInMillis
            }
            REPEAT_WEEKLY -> {
                while (first.timeInMillis <= now) first.add(Calendar.DAY_OF_YEAR, 7)
                first.timeInMillis
            }
            else -> null
        }
    }

    fun repeatLabel(): String = when (repeat) {
        REPEAT_DAILY -> "Tous les jours"
        REPEAT_WEEKLY -> "Chaque semaine"
        else -> "Une seule fois"
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id); put("name", name); put("info", info)
        put("ringtoneUri", ringtoneUri ?: JSONObject.NULL)
        put("ringtoneTitle", ringtoneTitle)
        put("hour", hour); put("minute", minute)
        put("dateMillis", dateMillis); put("repeat", repeat)
        put("enabled", enabled); put("vibrate", vibrate)
    }

    companion object {
        const val REPEAT_ONCE = 0
        const val REPEAT_DAILY = 1
        const val REPEAT_WEEKLY = 2

        fun fromJson(o: JSONObject) = Reminder(
            id = o.getInt("id"),
            name = o.getString("name"),
            info = o.optString("info", ""),
            ringtoneUri = if (o.isNull("ringtoneUri")) null else o.getString("ringtoneUri"),
            ringtoneTitle = o.optString("ringtoneTitle", "Sonnerie par défaut"),
            hour = o.getInt("hour"),
            minute = o.getInt("minute"),
            dateMillis = o.getLong("dateMillis"),
            repeat = o.optInt("repeat", REPEAT_ONCE),
            enabled = o.optBoolean("enabled", true),
            vibrate = o.optBoolean("vibrate", true)
        )
    }
}
