package com.rappelpro.app

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray

/**
 * Stockage dans le "device protected storage" : les rappels restent lisibles
 * dès le redémarrage du téléphone, même avant le déverrouillage.
 */
object ReminderStore {
    private const val FILE = "reminders_store"
    private const val KEY = "list"

    private fun prefs(ctx: Context): SharedPreferences {
        val base = ctx.applicationContext ?: ctx
        return base.createDeviceProtectedStorageContext()
            .getSharedPreferences(FILE, Context.MODE_PRIVATE)
    }

    @Synchronized
    fun getAll(ctx: Context): MutableList<Reminder> {
        val raw = prefs(ctx).getString(KEY, null) ?: return mutableListOf()
        val out = mutableListOf<Reminder>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) out.add(Reminder.fromJson(arr.getJSONObject(i)))
        } catch (_: Exception) {
        }
        return out
    }

    @Synchronized
    fun saveAll(ctx: Context, list: List<Reminder>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        prefs(ctx).edit().putString(KEY, arr.toString()).apply()
    }

    fun get(ctx: Context, id: Int): Reminder? = getAll(ctx).firstOrNull { it.id == id }

    @Synchronized
    fun upsert(ctx: Context, r: Reminder) {
        val list = getAll(ctx)
        val idx = list.indexOfFirst { it.id == r.id }
        if (idx >= 0) list[idx] = r else list.add(r)
        saveAll(ctx, list)
    }

    @Synchronized
    fun delete(ctx: Context, id: Int) {
        saveAll(ctx, getAll(ctx).filter { it.id != id })
    }

    fun nextId(ctx: Context): Int = (getAll(ctx).maxOfOrNull { it.id } ?: 0) + 1
}
