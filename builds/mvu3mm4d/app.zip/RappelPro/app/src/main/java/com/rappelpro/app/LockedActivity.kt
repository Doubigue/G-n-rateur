package com.rappelpro.app

import android.view.View
import androidx.appcompat.app.AppCompatActivity

/** Écran protégé : le contenu reste masqué tant que l'utilisateur ne s'est pas authentifié. */
abstract class LockedActivity : AppCompatActivity() {
    private var prompting = false

    private fun content(): View = findViewById(android.R.id.content)

    override fun onResume() {
        super.onResume()
        checkLock()
    }

    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations) AppLock.markLeft()
    }

    private fun checkLock() {
        if (AppLock.isUnlocked()) {
            content().visibility = View.VISIBLE
            return
        }
        content().visibility = View.INVISIBLE
        if (prompting) return
        prompting = true
        AppLock.authenticate(
            this,
            onSuccess = {
                prompting = false
                content().visibility = View.VISIBLE
            },
            onFailure = { systemCancel ->
                prompting = false
                if (!systemCancel) finishAffinity()
            }
        )
    }
}
