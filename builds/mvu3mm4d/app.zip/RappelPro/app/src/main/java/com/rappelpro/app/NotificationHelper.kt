package com.rappelpro.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat

object NotificationHelper {
    const val CH_ALARM = "rappel_alarm_v1"
    const val CH_MISSED = "rappel_missed_v1"

    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val alarm = NotificationChannel(CH_ALARM, "Rappels qui sonnent", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Notification affichée pendant la sonnerie d'un rappel"
            setSound(null, null)          // le son est joué par le service (flux alarme)
            enableVibration(false)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        val missed = NotificationChannel(CH_MISSED, "Rappels manqués", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Rappels non arrêtés ou manqués pendant que le téléphone était éteint"
        }
        nm.createNotificationChannel(alarm)
        nm.createNotificationChannel(missed)
    }

    fun buildAlarmNotification(ctx: Context, id: Int, r: Reminder?): Notification {
        val name = r?.name ?: "Rappel"
        val time = r?.let { Utils.time(it.hour, it.minute) } ?: ""
        val reason = if (r != null && r.info.isNotBlank()) r.info else "Vous l'avez programmé pour cette heure."
        val big = "Ce rappel sonne car vous l'avez programmé pour $time.\nMotif : $reason"

        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val ring = Intent(ctx, AlarmRingActivity::class.java).apply {
            putExtra(AlarmScheduler.EXTRA_ID, id)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        val fullPi = PendingIntent.getActivity(ctx, id, ring, flags)
        val stopPi = PendingIntent.getService(
            ctx, 1, Intent(ctx, AlarmService::class.java).setAction(AlarmService.ACTION_STOP), flags
        )
        val snoozePi = PendingIntent.getService(
            ctx, 2,
            Intent(ctx, AlarmService::class.java).setAction(AlarmService.ACTION_SNOOZE)
                .putExtra(AlarmScheduler.EXTRA_ID, id),
            flags
        )

        return NotificationCompat.Builder(ctx, CH_ALARM)
            .setSmallIcon(R.drawable.ic_notif_bell)
            .setContentTitle("⏰ $name")
            .setContentText("Il sonne parce que : $reason")
            .setStyle(NotificationCompat.BigTextStyle().bigText(big))
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setAutoCancel(false)
            .setColor(0xFF6C4DFF.toInt())
            .setFullScreenIntent(fullPi, true)
            .setContentIntent(fullPi)
            .addAction(0, "Arrêter", stopPi)
            .addAction(0, "Répéter ${AlarmService.SNOOZE_MINUTES} min", snoozePi)
            .build()
    }

    fun notifyMissed(ctx: Context, r: Reminder, reason: String) {
        ensureChannels(ctx)
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val text = "$reason" + if (r.info.isNotBlank()) "\nMotif : ${r.info}" else ""
        val n = NotificationCompat.Builder(ctx, CH_MISSED)
            .setSmallIcon(R.drawable.ic_notif_bell)
            .setContentTitle("Rappel manqué : ${r.name}")
            .setContentText(reason)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        try {
            (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                .notify(5000 + r.id, n)
        } catch (_: SecurityException) {
        }
    }
}
