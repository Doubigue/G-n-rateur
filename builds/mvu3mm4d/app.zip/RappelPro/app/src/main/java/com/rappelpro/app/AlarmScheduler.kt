package com.rappelpro.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri

object AlarmScheduler {
    const val ACTION_ALARM = "com.rappelpro.app.ACTION_ALARM"
    const val EXTRA_ID = "reminder_id"
    const val EXTRA_SNOOZE = "is_snooze"
    private const val SNOOZE_OFFSET = 1_000_000

    private fun am(ctx: Context) = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    private fun alarmPi(ctx: Context, id: Int, snooze: Boolean): PendingIntent {
        val i = Intent(ctx, AlarmReceiver::class.java).apply {
            action = ACTION_ALARM
            data = Uri.parse("rappel://${if (snooze) "snooze" else "alarm"}/$id")
            putExtra(EXTRA_ID, id)
            putExtra(EXTRA_SNOOZE, snooze)
        }
        return PendingIntent.getBroadcast(
            ctx, if (snooze) id + SNOOZE_OFFSET else id, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun showPi(ctx: Context): PendingIntent = PendingIntent.getActivity(
        ctx, 0, Intent(ctx, MainActivity::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun setAt(ctx: Context, at: Long, pi: PendingIntent) {
        try {
            // setAlarmClock : l'alarme la plus fiable d'Android (traverse le mode Doze,
            // réveille l'appareil, affiche l'icône d'alarme).
            am(ctx).setAlarmClock(AlarmManager.AlarmClockInfo(at, showPi(ctx)), pi)
        } catch (e: SecurityException) {
            am(ctx).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    @JvmStatic
    fun schedule(ctx: Context, r: Reminder) {
        val next = if (r.enabled) r.nextTrigger() else null
        if (next == null) {
            cancel(ctx, r.id)
            return
        }
        setAt(ctx, next, alarmPi(ctx, r.id, false))
    }

    @JvmStatic
    fun cancel(ctx: Context, id: Int) {
        am(ctx).cancel(alarmPi(ctx, id, false))
        am(ctx).cancel(alarmPi(ctx, id, true))
    }

    @JvmStatic
    fun snooze(ctx: Context, r: Reminder, minutes: Int) {
        setAt(ctx, System.currentTimeMillis() + minutes * 60_000L, alarmPi(ctx, r.id, true))
    }

    /** Reprogramme tout (démarrage, changement d'heure…). Signale les rappels manqués si demandé. */
    @JvmStatic
    @JvmOverloads
    fun rescheduleAll(ctx: Context, notifyMissed: Boolean = false) {
        val now = System.currentTimeMillis()
        for (r in ReminderStore.getAll(ctx)) {
            if (!r.enabled) continue
            if (r.nextTrigger(now) == null) {
                // Rappel unique dont l'heure est passée (ex. téléphone éteint à ce moment-là)
                r.enabled = false
                ReminderStore.upsert(ctx, r)
                if (notifyMissed) NotificationHelper.notifyMissed(
                    ctx, r, "Le téléphone était éteint à l'heure prévue (${Utils.time(r.hour, r.minute)})."
                )
            } else {
                schedule(ctx, r)
            }
        }
    }
}
