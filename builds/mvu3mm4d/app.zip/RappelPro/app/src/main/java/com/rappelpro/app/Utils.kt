package com.rappelpro.app

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

object Utils {
    fun startOfDay(millis: Long): Long = Calendar.getInstance().apply {
        timeInMillis = millis
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    fun time(h: Int, m: Int): String = String.format(Locale.getDefault(), "%02d:%02d", h, m)

    fun date(millis: Long): String =
        SimpleDateFormat("EEE d MMM yyyy", Locale.getDefault()).format(Date(millis))

    fun delay(ms: Long): String {
        val totalMin = (ms / 60000).coerceAtLeast(0)
        val d = totalMin / 1440
        val h = (totalMin % 1440) / 60
        val m = totalMin % 60
        return when {
            d > 0 -> "$d j $h h"
            h > 0 -> "$h h $m min"
            m > 0 -> "$m min"
            else -> "moins d'une minute"
        }
    }

    /** Le sélecteur de date Material travaille en UTC : conversions local <-> UTC. */
    fun localToUtc(localMidnight: Long): Long {
        val l = Calendar.getInstance().apply { timeInMillis = localMidnight }
        return Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
            clear()
            set(l.get(Calendar.YEAR), l.get(Calendar.MONTH), l.get(Calendar.DAY_OF_MONTH))
        }.timeInMillis
    }

    fun utcToLocal(utc: Long): Long {
        val u = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply { timeInMillis = utc }
        return Calendar.getInstance().apply {
            clear()
            set(u.get(Calendar.YEAR), u.get(Calendar.MONTH), u.get(Calendar.DAY_OF_MONTH))
        }.timeInMillis
    }
}
