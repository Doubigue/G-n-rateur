package com.linkshare.ui

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.Dp

/** Un thème complet de l'appli (fond, cartes, textes, accent par défaut). */
class Palette(
    val name: String,
    val light: Boolean,
    val accent: Color,
    val bg: Color,
    val card: Color,
    val cardTop: Color,
    val card2: Color,
    val text: Color,
    val muted: Color,
    val pill: Color,
    val sheet: Color,
    val line: Color,
    /** Décor dessiné derrière les écrans ([Decor]). */
    val decor: Int = Decor.NONE,
    /** Police du style ([Fonts]) : 0 Système, 1 Poppins, 2 Lora, 3 Condensée. */
    val font: Int = 0,
    /** Seconde couleur du fond (dégradé vertical). */
    val bg2: Color = Color.Unspecified,
    /** Couleur secondaire du décor. */
    val accent2: Color = Color.Unspecified,
)

/**
 * Styles réglables dans Paramètres › Apparence (mémorisés). Toutes les valeurs sont des états Compose :
 * changer un réglage redessine aussitôt toute l'appli.
 */
object UiStyle {
    val themes = listOf(
        Palette("Graphite", false, Color(0xFF8AB4F8), Color(0xFF262626), Color(0xFF151515), Color(0xFF1E1E1E), Color(0xFF343434), Color(0xFFF2F2F2), Color(0xFFA9A9A9), Color(0xFFD9D9D9), Color(0xFF1D1D1D), Color(0x1AFFFFFF)),
        Palette("Noir AMOLED", false, Color(0xFF8AB4F8), Color(0xFF000000), Color(0xFF0D0D0D), Color(0xFF161616), Color(0xFF262626), Color(0xFFF2F2F2), Color(0xFF9E9E9E), Color(0xFFD9D9D9), Color(0xFF0F0F0F), Color(0x17FFFFFF)),
        Palette("Nuit bleue", false, Color(0xFF7AA2FF), Color(0xFF0F1626), Color(0xFF0A101C), Color(0xFF141E33), Color(0xFF1F2A42), Color(0xFFEAF0FF), Color(0xFF93A0BD), Color(0xFFD6E0FF), Color(0xFF121A2C), Color(0x1F9DB4FF)),
        Palette("Forêt", false, Color(0xFF7FD69B), Color(0xFF14201A), Color(0xFF0C1510), Color(0xFF16251C), Color(0xFF22342A), Color(0xFFEAF5EE), Color(0xFF98B1A2), Color(0xFFD3EEDC), Color(0xFF101A14), Color(0x1F9BE0B4)),
        Palette("Prune", false, Color(0xFFD69BFF), Color(0xFF1E1526), Color(0xFF140D1A), Color(0xFF22182C), Color(0xFF33263F), Color(0xFFF4ECFA), Color(0xFFB09DBF), Color(0xFFEADBF6), Color(0xFF1A1221), Color(0x1FE0B4FF)),
        Palette("Or DL Vibe", false, Color(0xFFE8C163), Color(0xFF17140E), Color(0xFF0E0C08), Color(0xFF1F1B12), Color(0xFF2E281B), Color(0xFFFFF7E6), Color(0xFFBDAF8F), Color(0xFFF0DFB0), Color(0xFF15120C), Color(0x24E8C163)),
        Palette("Braise", false, Color(0xFFFF8A65), Color(0xFF1F1513), Color(0xFF140D0B), Color(0xFF261915), Color(0xFF382621), Color(0xFFFFEFEA), Color(0xFFBFA39B), Color(0xFFF6D9CF), Color(0xFF1A110E), Color(0x1FFF8A65)),
        Palette("Clair", true, Color(0xFF1A73E8), Color(0xFFF1F3F7), Color(0xFFFFFFFF), Color(0xFFFFFFFF), Color(0xFFE2E6EE), Color(0xFF1B1D21), Color(0xFF5F6670), Color(0xFFD6DEEA), Color(0xFFFFFFFF), Color(0x14000000)),
        Palette("Sable", true, Color(0xFFB7791F), Color(0xFFF6F0E6), Color(0xFFFFFCF6), Color(0xFFFFFCF6), Color(0xFFEADFCB), Color(0xFF2A2218), Color(0xFF6E6252), Color(0xFFE6D9C2), Color(0xFFFFFCF6), Color(0x14000000)),
        // ── Styles « affiche » : fond, décor et police propres (tirés au hasard à l'ouverture si « Style aléatoire »)
        Palette("Orange Studio", false, Color(0xFFFF7A00), Color(0xFF0A0A0A), Color(0xFF141414), Color(0xFF1E1E1E), Color(0xFF282828), Color(0xFFF5F5F5), Color(0xFFA8A8A8), Color(0xFFF2F2F2), Color(0xFF121212), Color(0x29FF7A00), Decor.WAVES, 1, Color(0xFF151515), Color(0xFFBDBDBD)),
        Palette("Mamba", false, Color(0xFFE9F23A), Color(0xFF0F3D27), Color(0xFF0B2E1D), Color(0xFF15452D), Color(0xFF1D5236), Color(0xFFF1F7F2), Color(0xFFA3C2AE), Color(0xFFE9F23A), Color(0xFF0D3321), Color(0x26E9F23A), Decor.CURVE, 1, Color(0xFF1B5E3A), Color.White),
        Palette("Émeraude", false, Color(0xFFF5A623), Color(0xFF0D5446), Color(0xFF0A3B31), Color(0xFF0F4D40), Color(0xFF15604F), Color(0xFFF2FBF8), Color(0xFF9CC7BB), Color(0xFFF2F2F2), Color(0xFF0B4639), Color(0x22FFFFFF), Decor.SWOOSH, 1, Color(0xFF093E33), Color.White),
        Palette("Festin", false, Color(0xFFFFC72C), Color(0xFF7A1A0E), Color(0xFF5E130A), Color(0xFF7E2012), Color(0xFF8F2A17), Color(0xFFFFF4EC), Color(0xFFE8B8A8), Color(0xFFFFC72C), Color(0xFF66150B), Color(0x26FFC72C), Decor.FESTIVE, 1, Color(0xFFB8321A), Color(0xFF2E9E4F)),
        Palette("Crépuscule", true, Color(0xFF1E7B3C), Color(0xFFFFA726), Color(0xFFFFF3DC), Color(0xFFFFFAEE), Color(0xFFFFE3B0), Color(0xFF2B1A07), Color(0xFF6E4F24), Color(0xFFFFFFFF), Color(0xFFFFF5E2), Color(0x1F000000), Decor.SKY, 1, Color(0xFFFFD54F), Color(0xFFC62828)),
        Palette("Portfolio", true, Color(0xFFE8590C), Color(0xFFFFF8EF), Color(0xFFFFFFFF), Color(0xFFFFFFFF), Color(0xFFF6E6D3), Color(0xFF3A0E05), Color(0xFF7D5A4A), Color(0xFFF6E6D3), Color(0xFFFFFFFF), Color(0x1A3A0E05), Decor.GRID, 2, Color(0xFFFFEEDD), Color(0xFFC2410C)),
        Palette("Losanges", false, Color(0xFFA9DCF5), Color(0xFF223D52), Color(0xFF182E3F), Color(0xFF22405A), Color(0xFF2A4A63), Color(0xFFEAF5FC), Color(0xFF9DB6C8), Color(0xFFD6EEFA), Color(0xFF1A3245), Color(0x26A9DCF5), Decor.DIAMONDS, 0, Color(0xFF152A3A), Color.White),
        Palette("Cramoisi", false, Color(0xFFFF3B5C), Color(0xFF3A0B16), Color(0xFF2A0710), Color(0xFF451020), Color(0xFF551629), Color(0xFFFFEEF1), Color(0xFFD199A6), Color(0xFFF6D3DA), Color(0xFF330A14), Color(0x26FF3B5C), Decor.GLOW, 3, Color(0xFF1C050B), Color(0xFF1ED760)),
        Palette("Black Friday", false, Color(0xFFA6E22E), Color(0xFF0E0F0D), Color(0xFF151713), Color(0xFF1E211B), Color(0xFF262A22), Color(0xFFF4F7EE), Color(0xFFA4AA98), Color(0xFFA6E22E), Color(0xFF121410), Color(0x29A6E22E), Decor.BAND, 3, Color(0xFF1A1C18), Color.White),
    )

    /** Polices proposées dans Paramètres › Apparence (0 = celle du style). */
    val fontNames = listOf("Style", "Système", "Poppins", "Lora", "Condensée")
    /** Dispositions de l'accueil : titres de sections et forme des cartes. */
    val layoutNames = listOf("Barre", "Pastille", "Signature")

    /** Couleurs d'accent proposées (index 0 = celle du thème). */
    val accents = listOf(
        "Thème" to Color.Unspecified,
        "Bleu" to Color(0xFF8AB4F8),
        "Violet" to Color(0xFFC58AF9),
        "Rose" to Color(0xFFFF8BCB),
        "Rouge" to Color(0xFFF28B82),
        "Orange" to Color(0xFFFCAD70),
        "Or" to Color(0xFFE8C163),
        "Vert" to Color(0xFF81C995),
        "Turquoise" to Color(0xFF78D9EC),
    )

    val cornerNames = listOf("Arrondis", "Très ronds", "Carrés")
    val cardNames = listOf("Dégradé", "Plat", "Contour")
    val audioNames = listOf("Vinyle", "Pochette", "Minimal")
    val carouselNames = listOf("Rapide", "Normal", "Lent")
    private val carouselSeconds = listOf(3, 5, 8)
    val seekSteps = listOf(5, 10, 15, 30)

    // ── Apparence
    var themeIndex by mutableIntStateOf(0)
    var accentIndex by mutableIntStateOf(0)
    var corner by mutableIntStateOf(0)
    var cardStyle by mutableIntStateOf(0)
    var denseGrid by mutableStateOf(false)
    /** Vrai : un nouveau style (couleurs, décor, police, disposition) est tiré au hasard à chaque ouverture. */
    var randomStyle by mutableStateOf(true)
    var fontIndex by mutableIntStateOf(0)
    var layout by mutableIntStateOf(0)
    var decorOn by mutableStateOf(true)
    var showOcrPdf by mutableStateOf(true)
    /** Sections de l'accueil dépliées / repliées (mémorisées). */
    private var randomized = false
    private val sections = androidx.compose.runtime.mutableStateMapOf<String, Boolean>()
    // ── Animations
    var animations by mutableStateOf(true)
    var carouselSpeed by mutableIntStateOf(1)
    var videoPreview by mutableStateOf(true)
    // ── Accueil
    var showRecents by mutableStateOf(true)
    var showTools by mutableStateOf(true)
    // ── Fichiers
    var showHidden by mutableStateOf(false)
    var deepScan by mutableStateOf(true)
    var defaultGrid by mutableStateOf(true)
    var confirmDelete by mutableStateOf(true)
    /** Vrai : le menu Studio est affiché dans l'écran « Action » (cadre « Studio »). Faux : bouton Studio séparé, comme avant. */
    var studioInActions by mutableStateOf(true)
    // ── Lecteur
    var resumePlayback by mutableStateOf(true)
    var seekStep by mutableIntStateOf(10)
    var audioStyle by mutableIntStateOf(0)
    var keepScreenOn by mutableStateOf(true)

    val pal: Palette get() = themes[themeIndex.coerceIn(0, themes.lastIndex)]

    val accent: Color
        get() {
            val p = pal
            val c = accents.getOrNull(accentIndex)?.second?.takeIf { it != Color.Unspecified } ?: return p.accent
            // Les accents pastel manquent de contraste sur fond clair : on les fonce
            return if (p.light) lerp(c, Color.Black, 0.38f) else c
        }

    val onAccent: Color
        get() = if (accent.luminance() > 0.45f) lerp(accent, Color.Black, 0.78f) else Color.White

    /** Couleurs de contenu (images, vidéos…) adaptées au thème clair. */
    fun tone(c: Color): Color = if (pal.light) lerp(c, Color.Black, 0.35f) else c

    /** Rayon des coins selon le réglage « Forme des coins ». */
    fun r(d: Dp): Dp = when (corner) {
        1 -> d * 1.4f
        2 -> d * 0.4f
        else -> d
    }

    /** Police effective : celle choisie, ou celle du style. */
    val font: Int get() = if (fontIndex <= 0) pal.font else fontIndex - 1

    fun isOpen(key: String, default: Boolean = true): Boolean = sections[key] ?: default

    fun toggle(ctx: Context, key: String, default: Boolean = true) {
        val v = !isOpen(key, default)
        sections[key] = v
        prefs(ctx).edit().putBoolean("sec_$key", v).apply()
    }

    /** Tire un nouveau style au hasard parmi les styles « affiche » (différent du style actuel). */
    fun randomize() {
        val pool = themes.indices.filter { themes[it].decor != Decor.NONE && it != themeIndex }
        if (pool.isNotEmpty()) themeIndex = pool.random()
        accentIndex = 0
        fontIndex = 0
        corner = (0..2).random()
        cardStyle = (0..2).random()
        layout = layoutNames.indices.random()
    }

    /** Nouveau style tout de suite (bouton « Changer de style »). */
    fun shuffle(ctx: Context) { randomize(); save(ctx) }

    val carouselMs: Long get() = carouselSeconds.getOrElse(carouselSpeed) { 5 } * 1000L

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("linkshare", Context.MODE_PRIVATE)

    fun load(ctx: Context) {
        val p = prefs(ctx)
        themeIndex = p.getInt("st_theme", 0)
        accentIndex = p.getInt("st_accent", 0)
        corner = p.getInt("st_corner", 0)
        cardStyle = p.getInt("st_card", 0)
        denseGrid = p.getBoolean("st_dense", false)
        randomStyle = p.getBoolean("st_random", true)
        fontIndex = p.getInt("st_font", 0)
        layout = p.getInt("st_layout", 0)
        decorOn = p.getBoolean("st_decor", true)
        showOcrPdf = p.getBoolean("st_ocrpdf", true)
        p.all.forEach { (k, v) -> if (k.startsWith("sec_") && v is Boolean) sections[k.removePrefix("sec_")] = v }
        animations = p.getBoolean("st_anim", true)
        carouselSpeed = p.getInt("st_carousel", 1)
        videoPreview = p.getBoolean("st_vprev", true)
        showRecents = p.getBoolean("st_recents", true)
        showTools = p.getBoolean("st_tools", true)
        showHidden = p.getBoolean("st_hidden", false)
        deepScan = p.getBoolean("st_deep", true)
        defaultGrid = p.getBoolean("st_grid", true)
        confirmDelete = p.getBoolean("st_confirm", true)
        studioInActions = p.getBoolean("st_studio_inline", true)
        resumePlayback = p.getBoolean("st_resume", true)
        seekStep = p.getInt("st_seek", 10)
        audioStyle = p.getInt("st_audio", 0)
        keepScreenOn = p.getBoolean("st_screen", true)
        // Un seul tirage par lancement de l'appli (pas à chaque rotation de l'écran)
        if (randomStyle && !randomized) { randomized = true; randomize(); save(ctx) }
    }

    fun save(ctx: Context) {
        prefs(ctx).edit()
            .putInt("st_theme", themeIndex).putInt("st_accent", accentIndex).putInt("st_corner", corner)
            .putInt("st_card", cardStyle).putBoolean("st_dense", denseGrid).putBoolean("st_anim", animations)
            .putInt("st_carousel", carouselSpeed).putBoolean("st_vprev", videoPreview).putBoolean("st_recents", showRecents)
            .putBoolean("st_tools", showTools).putBoolean("st_hidden", showHidden).putBoolean("st_deep", deepScan)
            .putBoolean("st_grid", defaultGrid).putBoolean("st_confirm", confirmDelete).putBoolean("st_resume", resumePlayback)
            .putInt("st_seek", seekStep).putInt("st_audio", audioStyle).putBoolean("st_screen", keepScreenOn).putBoolean("st_studio_inline", studioInActions)
            .putBoolean("st_random", randomStyle).putInt("st_font", fontIndex).putInt("st_layout", layout)
            .putBoolean("st_decor", decorOn).putBoolean("st_ocrpdf", showOcrPdf)
            .apply()
    }

    /** Modifie un réglage puis l'enregistre. */
    fun edit(ctx: Context, block: UiStyle.() -> Unit) { block(); save(ctx) }

    fun reset(ctx: Context) {
        prefs(ctx).edit().apply { prefs(ctx).all.keys.filter { it.startsWith("st_") }.forEach { remove(it) } }.apply()
        load(ctx)
    }
}
