package com.linkshare.ui

import android.graphics.Typeface as AndroidTypeface
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.Typography
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linkshare.R
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

/** Décors dessinés derrière les écrans, inspirés d'affiches (vagues, losanges, grille…). */
object Decor {
    const val NONE = 0
    const val WAVES = 1      // vagues orange + argent, grilles de points (Orange Studio)
    const val DIAMONDS = 2   // losanges en contour (Losanges)
    const val GRID = 3       // papier quadrillé + bande diagonale (Portfolio)
    const val CURVE = 4      // grande courbe claire en haut (Mamba)
    const val SWOOSH = 5     // cercles concentriques + trait griffonné (Émeraude)
    const val BAND = 6       // bande verticale + double cadre (Black Friday)
    const val GLOW = 7       // halo central + vignette (Cramoisi)
    const val SKY = 8        // nuages, oiseaux et route (Crépuscule)
    const val FESTIVE = 9    // cercles, flèche en pointillés, bandeau (Festin)
}

/** Polices de l'appli : Poppins et Lora sont embarquées, la condensée et la manuscrite viennent d'Android. */
object Fonts {
    val poppins: FontFamily by lazy {
        FontFamily(
            Font(R.font.poppins_regular, FontWeight.Normal),
            Font(R.font.poppins_medium, FontWeight.Medium),
            Font(R.font.poppins_bold, FontWeight.Bold),
        )
    }
    val lora: FontFamily by lazy { FontFamily(Font(R.font.lora, FontWeight.Normal)) }
    val condensed: FontFamily by lazy { FontFamily(AndroidTypeface.create("sans-serif-condensed", AndroidTypeface.NORMAL)) }
    /** Écriture « signature » des titres (comme « Vôtre image », « officielle »…). */
    val script: FontFamily get() = FontFamily.Cursive

    fun of(i: Int): FontFamily = when (i) {
        1 -> poppins
        2 -> lora
        3 -> condensed
        else -> FontFamily.Default
    }
}

/** Typographie Material : tous les textes de l'appli prennent la police du style. */
fun appTypography(f: FontFamily): Typography {
    val b = Typography()
    return b.copy(
        displayLarge = b.displayLarge.copy(fontFamily = f),
        displayMedium = b.displayMedium.copy(fontFamily = f),
        displaySmall = b.displaySmall.copy(fontFamily = f),
        headlineLarge = b.headlineLarge.copy(fontFamily = f),
        headlineMedium = b.headlineMedium.copy(fontFamily = f),
        headlineSmall = b.headlineSmall.copy(fontFamily = f),
        titleLarge = b.titleLarge.copy(fontFamily = f),
        titleMedium = b.titleMedium.copy(fontFamily = f),
        titleSmall = b.titleSmall.copy(fontFamily = f),
        bodyLarge = b.bodyLarge.copy(fontFamily = f),
        bodyMedium = b.bodyMedium.copy(fontFamily = f),
        bodySmall = b.bodySmall.copy(fontFamily = f),
        labelLarge = b.labelLarge.copy(fontFamily = f),
        labelMedium = b.labelMedium.copy(fontFamily = f),
        labelSmall = b.labelSmall.copy(fontFamily = f),
    )
}

// ═══════════════════════════ Fond décoré ═══════════════════════════

/**
 * Fond du style courant : dégradé + décor. [compact] : version discrète pour l'intérieur d'une carte
 * (pas de dégradé de fond, décor atténué).
 */
@Composable
fun StyleBackdrop(modifier: Modifier = Modifier, compact: Boolean = false) {
    val p = UiStyle.pal
    val decor = if (UiStyle.decorOn) p.decor else Decor.NONE
    val accent = UiStyle.accent
    val a2 = if (p.accent2 == Color.Unspecified) p.text else p.accent2
    val bg2 = if (p.bg2 == Color.Unspecified) p.bg else p.bg2
    val text = p.text
    Canvas(modifier) {
        if (!compact && bg2 != p.bg) drawRect(Brush.verticalGradient(listOf(p.bg, bg2)))
        val k = if (compact) 0.7f else 1f
        when (decor) {
            Decor.WAVES -> waves(accent, a2, k, compact)
            Decor.DIAMONDS -> diamonds(accent, k, compact)
            Decor.GRID -> grid(accent, a2, text, k, compact)
            Decor.CURVE -> curve(accent, a2, k)
            Decor.SWOOSH -> swoosh(a2, k, compact)
            Decor.BAND -> band(accent, k, compact)
            Decor.GLOW -> glow(accent, k)
            Decor.SKY -> sky(text, k, compact)
            Decor.FESTIVE -> festive(accent, a2, k, compact)
        }
    }
}

private fun DrawScope.dots(o: Offset, cols: Int, rows: Int, gap: Float, r: Float, c: Color) {
    for (i in 0 until cols) for (j in 0 until rows) drawCircle(c, r, Offset(o.x + i * gap, o.y + j * gap))
}

private fun DrawScope.waves(accent: Color, silver: Color, k: Float, compact: Boolean) {
    val w = size.width
    val h = size.height
    if (!compact) {
        // traînée lumineuse en haut à gauche + anneau
        val streak = Path().apply { moveTo(0f, h * 0.02f); lineTo(w * 0.38f, 0f); lineTo(w * 0.56f, 0f); lineTo(0f, h * 0.20f); close() }
        drawPath(streak, Brush.linearGradient(listOf(accent.copy(alpha = 0.55f), Color.Transparent), Offset(0f, 0f), Offset(w * 0.45f, h * 0.2f)))
        drawCircle(accent.copy(alpha = 0.45f), w * 0.15f, Offset(-w * 0.03f, h * 0.015f), style = Stroke(9.dp.toPx()))
    }
    // bande argentée puis vague d'accent, en bas à droite
    val band = Path().apply {
        moveTo(0f, h * 0.975f); cubicTo(w * 0.4f, h * 0.93f, w * 0.62f, h * 0.80f, w, h * 0.55f)
        lineTo(w, h * 0.62f); cubicTo(w * 0.62f, h * 0.85f, w * 0.4f, h * 0.965f, 0f, h); close()
    }
    drawPath(band, Brush.linearGradient(listOf(silver.copy(alpha = 0.04f), silver.copy(alpha = 0.32f * k), silver.copy(alpha = 0.08f)), Offset(0f, h), Offset(w, h * 0.55f)))
    val wave = Path().apply { moveTo(w * 0.08f, h); cubicTo(w * 0.45f, h * 0.97f, w * 0.64f, h * 0.87f, w, h * 0.67f); lineTo(w, h); close() }
    drawPath(wave, Brush.linearGradient(listOf(accent.copy(alpha = 0.78f * k), accent.copy(alpha = 0.32f * k)), Offset(w, h * 0.67f), Offset(w * 0.2f, h)))
    val g = 14.dp.toPx()
    val r = 1.8.dp.toPx()
    if (compact) dots(Offset(w * 0.80f, h * 0.16f), 4, 3, g, r, accent.copy(alpha = 0.45f))
    else {
        dots(Offset(w * 0.80f, h * 0.36f), 5, 8, g, r, accent.copy(alpha = 0.45f))
        dots(Offset(w * 0.04f, h * 0.55f), 4, 7, g, r, silver.copy(alpha = 0.22f))
    }
}

private fun DrawScope.diamonds(accent: Color, k: Float, compact: Boolean) {
    val w = size.width
    val h = size.height
    val rnd = Random(7)
    val n = if (compact) 12 else 28
    repeat(n) {
        val t = rnd.nextFloat()
        val cx = w * (0.05f + 0.95f * t) + (rnd.nextFloat() - 0.5f) * w * 0.35f
        val cy = h * (1.0f - 0.78f * t) + (rnd.nextFloat() - 0.5f) * h * 0.18f
        val s = if (compact) h * (0.10f + rnd.nextFloat() * 0.28f) else w * (0.035f + rnd.nextFloat() * 0.13f)
        val sw = (1f + rnd.nextFloat() * 2.2f).dp.toPx()
        val a = (0.16f + rnd.nextFloat() * 0.46f) * k
        val d = Path().apply { moveTo(cx, cy - s); lineTo(cx + s, cy); lineTo(cx, cy + s); lineTo(cx - s, cy); close() }
        drawPath(d, accent.copy(alpha = a), style = Stroke(sw, join = StrokeJoin.Round))
    }
    if (!compact) drawRect(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.22f)), startY = h * 0.55f, endY = h))
}

private fun DrawScope.grid(accent: Color, a2: Color, text: Color, k: Float, compact: Boolean) {
    val w = size.width
    val h = size.height
    val step = 26.dp.toPx()
    val c = text.copy(alpha = 0.06f * k)
    var x = 0f
    while (x < w) { drawLine(c, Offset(x, 0f), Offset(x, h), 1f); x += step }
    var y = 0f
    while (y < h) { drawLine(c, Offset(0f, y), Offset(w, y), 1f); y += step }
    val band = if (compact) Path().apply { moveTo(w * 0.45f, h); lineTo(w, h * 0.15f); lineTo(w, h * 0.55f); lineTo(w * 0.72f, h); close() }
    else Path().apply { moveTo(0f, h * 0.30f); lineTo(w, h * 0.13f); lineTo(w, h * 0.29f); lineTo(0f, h * 0.50f); close() }
    drawPath(band, Brush.linearGradient(listOf(accent.copy(alpha = 0.22f * k), a2.copy(alpha = 0.08f * k)), Offset(0f, h * 0.4f), Offset(w, h * 0.2f)))
    if (!compact) rotate(-28f, Offset(w * 0.2f, h * 0.84f)) {
        drawRoundRect(accent.copy(alpha = 0.14f), Offset(-w * 0.2f, h * 0.80f), Size(w * 0.85f, h * 0.07f), CornerRadius(h * 0.035f))
    }
}

private fun DrawScope.curve(accent: Color, a2: Color, k: Float) {
    val w = size.width
    val h = size.height
    val top = Path().apply {
        moveTo(0f, 0f); lineTo(w, 0f); lineTo(w, h * 0.26f)
        cubicTo(w * 0.7f, h * 0.36f, w * 0.35f, h * 0.30f, 0f, h * 0.44f); close()
    }
    drawPath(top, Brush.verticalGradient(listOf(a2.copy(alpha = 0.11f * k), a2.copy(alpha = 0.03f * k)), 0f, h * 0.44f))
    val edge = Path().apply { moveTo(w, h * 0.26f); cubicTo(w * 0.7f, h * 0.36f, w * 0.35f, h * 0.30f, 0f, h * 0.44f) }
    drawPath(edge, accent.copy(alpha = 0.38f * k), style = Stroke(2.dp.toPx(), cap = StrokeCap.Round))
    val bottom = Path().apply {
        moveTo(0f, h * 0.86f); cubicTo(w * 0.3f, h * 0.80f, w * 0.6f, h * 0.94f, w, h * 0.84f); lineTo(w, h); lineTo(0f, h); close()
    }
    drawPath(bottom, a2.copy(alpha = 0.05f * k))
}

private fun DrawScope.swoosh(a2: Color, k: Float, compact: Boolean) {
    val w = size.width
    val h = size.height
    val c = Offset(w * 0.02f, h * 0.32f)
    drawCircle(a2.copy(alpha = 0.05f * k), if (compact) h * 0.9f else w * 0.55f, c, style = Stroke((if (compact) 18 else 34).dp.toPx()))
    drawCircle(a2.copy(alpha = 0.04f * k), if (compact) h * 0.5f else w * 0.30f, c, style = Stroke((if (compact) 10 else 18).dp.toPx()))
    val x = if (compact) w * 0.62f else w * 0.12f
    val y = if (compact) h * 0.22f else h * 0.62f
    val zig = Path().apply {
        moveTo(x, y); lineTo(x + w * 0.26f, y - 6.dp.toPx()); lineTo(x + w * 0.05f, y + 10.dp.toPx()); lineTo(x + w * 0.22f, y + 9.dp.toPx())
    }
    drawPath(zig, a2.copy(alpha = 0.32f * k), style = Stroke(2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
    if (!compact) {
        val bottom = Path().apply { moveTo(0f, h * 0.90f); cubicTo(w * 0.35f, h * 0.84f, w * 0.7f, h * 0.97f, w, h * 0.88f); lineTo(w, h); lineTo(0f, h); close() }
        drawPath(bottom, a2.copy(alpha = 0.07f))
    }
}

private fun DrawScope.band(accent: Color, k: Float, compact: Boolean) {
    val w = size.width
    val h = size.height
    drawRect(accent.copy(alpha = 0.09f * k), Offset(w * 0.29f, 0f), Size(w * 0.42f, h))
    val i1 = 12.dp.toPx()
    val i2 = 18.dp.toPx()
    drawRect(accent.copy(alpha = 0.35f * k), Offset(i1, i1), Size(w - 2 * i1, h - 2 * i1), style = Stroke(1.dp.toPx()))
    drawRect(accent.copy(alpha = 0.18f * k), Offset(i2, i2), Size(w - 2 * i2, h - 2 * i2), style = Stroke(1.dp.toPx()))
    if (!compact) {
        val rnd = Random(3)
        val dot = Color.White.copy(alpha = 0.03f)
        repeat(450) { drawCircle(dot, (0.5f + rnd.nextFloat()).dp.toPx(), Offset(rnd.nextFloat() * w, rnd.nextFloat() * h)) }
    }
}

private fun DrawScope.glow(accent: Color, k: Float) {
    val w = size.width
    val h = size.height
    drawRect(Brush.radialGradient(listOf(accent.copy(alpha = 0.28f * k), Color.Transparent), Offset(w * 0.5f, h * 0.30f), maxOf(w, h) * 0.6f))
    drawRect(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.35f * k)), startY = h * 0.6f, endY = h))
}

private fun DrawScope.sky(text: Color, k: Float, compact: Boolean) {
    val w = size.width
    val h = size.height
    val rnd = Random(11)
    val white = Color.White
    repeat(if (compact) 4 else 9) {
        val cx = w * rnd.nextFloat()
        val cy = h * (0.02f + 0.35f * rnd.nextFloat())
        val r = (if (compact) h else w) * (0.12f + 0.18f * rnd.nextFloat())
        drawCircle(white.copy(alpha = 0.14f * k), r, Offset(cx, cy))
    }
    drawCircle(white.copy(alpha = 0.20f * k), if (compact) h * 0.4f else w * 0.22f, Offset(w * 0.35f, h * 0.12f), style = Stroke(3.dp.toPx()))
    repeat(if (compact) 3 else 7) {
        val bx = w * (0.1f + 0.8f * rnd.nextFloat())
        val by = h * (0.08f + (if (compact) 0.5f else 0.45f) * rnd.nextFloat())
        val s = (5f + rnd.nextFloat() * 5f).dp.toPx()
        val bird = Path().apply {
            moveTo(bx - s, by - s * 0.4f)
            quadraticBezierTo(bx - s * 0.4f, by - s * 0.6f, bx, by)
            quadraticBezierTo(bx + s * 0.4f, by - s * 0.6f, bx + s, by - s * 0.4f)
        }
        drawPath(bird, text.copy(alpha = 0.5f * k), style = Stroke(1.6.dp.toPx(), cap = StrokeCap.Round))
    }
    if (!compact) {
        val road = Path().apply { moveTo(w * 0.40f, h * 0.86f); lineTo(w * 0.60f, h * 0.86f); lineTo(w, h); lineTo(0f, h); close() }
        drawPath(road, Color(0xFF2B2B2B).copy(alpha = 0.22f))
        drawLine(
            Color(0xFFFFE082).copy(alpha = 0.7f), Offset(w * 0.5f, h * 0.87f), Offset(w * 0.5f, h), 3.dp.toPx(),
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(14.dp.toPx(), 10.dp.toPx())),
        )
    }
}

private fun DrawScope.festive(accent: Color, green: Color, k: Float, compact: Boolean) {
    val w = size.width
    val h = size.height
    drawRect(Brush.radialGradient(listOf(accent.copy(alpha = 0.12f * k), Color.Transparent), Offset(w * 0.9f, h * 0.08f), maxOf(w, h) * 0.5f))
    if (compact) {
        val strip = Path().apply { moveTo(w * 0.55f, h); lineTo(w, h * 0.35f); lineTo(w, h * 0.55f); lineTo(w * 0.70f, h); close() }
        drawPath(strip, accent.copy(alpha = 0.18f))
    } else {
        val strip = Path().apply { moveTo(0f, h * 0.70f); lineTo(w * 0.58f, h * 0.66f); lineTo(w * 0.53f, h * 0.72f); lineTo(0f, h * 0.76f); close() }
        drawPath(strip, accent.copy(alpha = 0.18f))
        listOf(0.12f to 0.40f, 0.30f to 0.36f, 0.14f to 0.52f, 0.32f to 0.50f).forEach { (x, y) ->
            drawCircle(accent.copy(alpha = 0.26f), w * 0.11f, Offset(w * x, h * y), style = Stroke(3.dp.toPx()))
        }
        val arrow = Path().apply { moveTo(w * 0.55f, h * 0.08f); cubicTo(w * 0.8f, h * 0.04f, w * 0.95f, h * 0.14f, w * 0.78f, h * 0.22f) }
        drawPath(
            arrow, Color.White.copy(alpha = 0.32f),
            style = Stroke(2.dp.toPx(), cap = StrokeCap.Round, pathEffect = PathEffect.dashPathEffect(floatArrayOf(8.dp.toPx(), 6.dp.toPx()))),
        )
    }
    drawRect(green.copy(alpha = 0.45f * k), Offset(0f, h - 5.dp.toPx()), Size(w, 3.dp.toPx()))
}

// ═══════════════════════════ Titres de section ═══════════════════════════

/**
 * Titre de section de l'accueil, selon la disposition du style : barre d'accent, pastille ou signature manuscrite.
 * Avec [onToggle], toucher le titre déroule ou cache la section (chevron).
 */
@Composable
internal fun StyledHeading(title: String, trailing: String? = null, expanded: Boolean? = null, onToggle: (() -> Unit)? = null) {
    val accent = LS.Blue
    Row(
        Modifier.fillMaxWidth()
            .then(if (onToggle != null) Modifier.clip(RoundedCornerShape(12.dp)).clickable { onToggle() } else Modifier)
            .padding(top = 8.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        when (UiStyle.layout) {
            1 -> Box(Modifier.weight(1f)) {
                Text(
                    title,
                    Modifier.clip(RoundedCornerShape(UiStyle.r(14.dp))).background(accent).padding(horizontal = 14.dp, vertical = 5.dp),
                    color = LS.OnBlue, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
                )
            }
            2 -> Column(Modifier.weight(1f)) {
                Text(title, color = accent, fontSize = 27.sp, lineHeight = 32.sp, fontFamily = Fonts.script, fontWeight = FontWeight.Bold, maxLines = 1)
                Box(Modifier.size(width = 52.dp, height = 3.dp).clip(CircleShape).background(accent.copy(alpha = 0.55f)))
            }
            else -> {
                Box(Modifier.size(width = 4.dp, height = 18.dp).clip(CircleShape).background(accent))
                Spacer(Modifier.width(10.dp))
                Text(title, Modifier.weight(1f), color = LS.Text.copy(alpha = 0.94f), fontSize = 19.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            }
        }
        if (trailing != null) Text(trailing, Modifier.padding(start = 8.dp), color = LS.Muted, fontSize = 12.sp, maxLines = 1)
        if (expanded != null) {
            val angle by animateFloatAsState(if (expanded) 90f else 0f, label = "chev")
            Icon(
                Ic.Chevron, if (expanded) "Cacher" else "Dérouler",
                Modifier.padding(start = 4.dp).size(26.dp).graphicsLayer { rotationZ = angle }, tint = if (expanded) accent else LS.Muted,
            )
        }
    }
}

// ═══════════════════════════ Écran de démarrage ═══════════════════════════

/** Écran de démarrage : il prend le fond, le décor, la police et la disposition du style tiré au lancement. */
@Composable
fun SplashScreen(onDone: () -> Unit) {
    val p = UiStyle.pal
    val accent = UiStyle.accent
    val onAccent = UiStyle.onAccent
    val layout = UiStyle.layout
    val scale = remember { Animatable(0.5f) }
    val logoAlpha = remember { Animatable(0f) }
    val credit = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        launch { scale.animateTo(1f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow)) }
        launch { logoAlpha.animateTo(1f, tween(700)) }
        delay(500)
        credit.animateTo(1f, tween(700))
        delay(1300)
        onDone()
    }
    val title = buildAnnotatedString {
        withStyle(SpanStyle(color = p.text)) { append("Link") }
        withStyle(SpanStyle(color = accent)) { append("Share") }
    }

    @Composable
    fun Logo(size: Int) {
        Box(
            Modifier.size(size.dp).scale(scale.value).alpha(logoAlpha.value).clip(CircleShape)
                .background(Brush.linearGradient(listOf(accent.copy(alpha = 0.38f), p.card)))
                .border(2.dp, accent.copy(alpha = 0.7f), CircleShape),
            contentAlignment = Alignment.Center,
        ) { Image(painterResource(R.drawable.ic_launcher_foreground), null, Modifier.size((size * 0.9f).dp)) }
    }

    Box(Modifier.fillMaxSize().background(p.bg)) {
        StyleBackdrop(Modifier.fillMaxSize())
        Box(Modifier.fillMaxSize().systemBarsPadding()) {
            when (layout) {
                // Affiche : logo en haut à gauche, gros titre, signature manuscrite
                1 -> Column(Modifier.align(Alignment.CenterStart).padding(horizontal = 32.dp)) {
                    Logo(110)
                    Spacer(Modifier.height(26.dp))
                    Text("Partage", Modifier.alpha(logoAlpha.value), color = accent, fontSize = 40.sp, lineHeight = 44.sp, fontFamily = Fonts.script, fontWeight = FontWeight.Bold)
                    Text(title, Modifier.alpha(logoAlpha.value), fontSize = 46.sp, lineHeight = 50.sp, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "Explorateur · Transfert ultra-rapide", Modifier.alpha(logoAlpha.value).clip(RoundedCornerShape(UiStyle.r(12.dp)))
                            .background(accent).padding(horizontal = 12.dp, vertical = 6.dp),
                        color = onAccent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                    )
                }
                // Bandeau : mot d'accueil manuscrit, logo, titre dans une pastille d'accent
                2 -> Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Bienvenue", Modifier.alpha(logoAlpha.value), color = accent, fontSize = 38.sp, fontFamily = Fonts.script, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(14.dp))
                    Logo(150)
                    Spacer(Modifier.height(22.dp))
                    Text(
                        "LINKSHARE", Modifier.alpha(logoAlpha.value).clip(RoundedCornerShape(UiStyle.r(14.dp))).background(accent)
                            .padding(horizontal = 22.dp, vertical = 8.dp),
                        color = onAccent, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 4.sp,
                    )
                    Spacer(Modifier.height(10.dp))
                    Text("Partage ultra-rapide", Modifier.alpha(logoAlpha.value), color = p.muted, fontSize = 15.sp)
                }
                // Classique : logo centré
                else -> Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    Logo(180)
                    Spacer(Modifier.height(20.dp))
                    Text(title, Modifier.alpha(logoAlpha.value), fontSize = 38.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Partage ultra-rapide", Modifier.alpha(logoAlpha.value), color = p.muted, fontSize = 15.sp)
                }
            }
            Column(
                Modifier.align(Alignment.BottomCenter).padding(bottom = 36.dp).alpha(credit.value),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("Created by", color = p.muted, fontSize = 12.sp)
                Text("DL VIBE STUDIO", color = p.text, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 3.sp)
                Box(Modifier.padding(vertical = 4.dp).size(width = 44.dp, height = 3.dp).clip(CircleShape).background(accent))
                Text("Doubigue Loubikoa", color = p.text.copy(alpha = 0.85f), fontSize = 14.sp)
            }
        }
    }
}

/** Petite pastille d'action (carte de sélection) : icône + libellé, pleine ou discrète. */
@Composable
internal fun DockChip(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, primary: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(UiStyle.r(16.dp))
    val bg = if (primary) LS.Blue else LS.Card2.copy(alpha = 0.85f)
    val fg = if (primary) LS.OnBlue else LS.Text
    Row(
        Modifier.clip(shape).background(bg).then(if (primary) Modifier else Modifier.border(1.dp, LS.Line, shape))
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(7.dp),
    ) {
        Icon(icon, null, Modifier.size(18.dp), tint = if (primary) fg else LS.Blue)
        Text(label, color = fg, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}
