import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("org.jetbrains.kotlin.plugin.serialization")
}

android {
    namespace = "com.linkshare"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.doubigue.linkshareexplorer"
        minSdk = 30
        targetSdk = 35
        versionCode = 18
        versionName = "1.8"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }
    // Clé de signature dédiée à LinkShare (app/linkshare-release.jks, mots de passe dans app/keystore.properties).
    // Toutes les versions (debug comme release) sont signées avec elle : chaque nouvel APK s'installe par-dessus
    // l'ancien sans désinstaller, quel que soit l'ordinateur ou le serveur qui compile.
    val keyProps = Properties().apply {
        val f = file("keystore.properties")
        if (f.exists()) f.inputStream().use { load(it) }
    }
    val hasKey = keyProps.getProperty("storeFile")?.let { file(it).exists() } == true
    signingConfigs {
        if (hasKey) create("linkshare") {
            storeFile = file(keyProps.getProperty("storeFile"))
            storePassword = keyProps.getProperty("storePassword")
            keyAlias = keyProps.getProperty("keyAlias")
            keyPassword = keyProps.getProperty("keyPassword")
            enableV1Signing = true
            enableV2Signing = true
        }
    }
    buildTypes {
        debug { if (hasKey) signingConfig = signingConfigs.getByName("linkshare") }
        release {
            isMinifyEnabled = false
            if (hasKey) signingConfig = signingConfigs.getByName("linkshare")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    packaging {
        resources.excludes += setOf("/META-INF/{AL2.0,LGPL2.1}", "META-INF/INDEX.LIST", "META-INF/io.netty.versions.properties")
    }
}

val ktor = "2.3.12"

dependencies {

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.core:core-splashscreen:1.0.1")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")

    // Serveur + client HTTP
    implementation("io.ktor:ktor-server-core:$ktor")
    implementation("io.ktor:ktor-server-cio:$ktor")
    implementation("io.ktor:ktor-server-content-negotiation:$ktor")
    implementation("io.ktor:ktor-server-partial-content:$ktor")
    implementation("io.ktor:ktor-server-auto-head-response:$ktor")
    implementation("io.ktor:ktor-serialization-kotlinx-json:$ktor")
    implementation("io.ktor:ktor-client-core:$ktor")
    implementation("io.ktor:ktor-client-cio:$ktor")
    implementation("io.ktor:ktor-client-content-negotiation:$ktor")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.3")
    implementation("org.slf4j:slf4j-android:1.7.36")

    // Lecture média / images
    implementation("androidx.media3:media3-exoplayer:1.4.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.4.1") // flux web .m3u8
    implementation("androidx.media3:media3-exoplayer-dash:1.4.1") // flux web .mpd
    implementation("androidx.media3:media3-ui:1.4.1")
    implementation("androidx.media3:media3-session:1.4.1") // lecture en arrière-plan, notification, écran verrouillé
    implementation("com.google.guava:guava:33.0.0-android")
    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("io.coil-kt:coil-video:2.7.0") // miniatures des vidéos
    implementation("io.coil-kt:coil-gif:2.7.0") // lecture des GIF animés (visionneuse d'images)

    // QR
    implementation("com.google.zxing:core:3.5.3")
    implementation("com.google.android.gms:play-services-code-scanner:16.1.0")
    // Scan de documents (recadrage, filtres, export PDF)
    implementation("com.google.android.gms:play-services-mlkit-document-scanner:16.0.0-beta1")

    // Tests unitaires (JVM) : analyse de plugin.json, correspondance accepts / fichiers
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test:runner:1.6.2")
    testImplementation("org.json:json:20240303") // vraie implémentation d'org.json (celle d'Android est une coquille vide en test JVM)
}
