# Clé de signature dédiée (V17)
Fichiers : `keystore/doubigue-release.jks` + `keystore.properties` (mots de passe). Alias : `doubigue`.
Les builds **debug ET release** sont signés avec cette clé : Android Studio (Run) et un APK release s'installent
l'un par-dessus l'autre, sans désinstaller.

## Règles pour que les mises à jour passent
1. Garde TOUJOURS la même clé (copie le dossier `keystore/` et `keystore.properties` dans un endroit sûr : cloud privé + clé USB). Si elle est perdue, plus aucune mise à jour possible par-dessus.
2. Ne la publie jamais (GitHub public, etc.).
3. Augmente `versionCode` (app/build.gradle.kts) à chaque nouvelle version (actuel : 13).
4. UNE SEULE désinstallation, pour passer de l'ancienne clé (debug de Android Studio) à celle-ci. Avant : Paramètres > Sauvegarde (dossier « Doubigue Ai Database »). Ensuite plus jamais.

## APK release
Android Studio : Build > Generate Signed App Bundle / APK > APK > choisir `keystore/doubigue-release.jks`, alias `doubigue`.
Ou en terminal : `./gradlew assembleRelease` → `app/build/outputs/apk/release/`.
