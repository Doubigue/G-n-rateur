# V16 — Sons d'événements
Nouveau : Paramètres > Sons d'événements (un MP3/WAV par situation, importé comme pour les applications).

Événements : bienvenue (ouverture de l'appli), écran verrouillé, écran allumé, empreinte acceptée,
PIN accepté/refusé, mot de passe accepté/refusé, schéma accepté/refusé, après déverrouillage, empreinte refusée.

Comment ça marche (et limites Android) :
- Service au premier plan `EventSoundService` : SCREEN_OFF / SCREEN_ON / USER_PRESENT (activer le switch).
- Échecs/réussites PIN, mot de passe, schéma : `LockAdminReceiver` (administrateur d'appareil, politique « watch-login » seulement).
- Empreinte acceptée : DÉDUITE (déverrouillage sans signal PIN/mot de passe juste avant).
- Empreinte refusée : EXPÉRIMENTAL, via service d'accessibilité qui lit le message de l'écran de verrouillage. Dépend du constructeur/langue.
- PIN / mot de passe / schéma ne se distinguent pas côté Android : choisir son type de verrouillage dans l'écran.
- WhatsApp : l'état ouvert/fermé tient maintenant compte du fait que DOUBIGUE est au premier plan quand on lui parle.
Compilation et tests sur téléphone : NON FAITS ici.
