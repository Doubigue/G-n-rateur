# V13
- Reconnaissance vocale : Vosk hors ligne (modèle vosk-model-small-fr-0.22.zip importé dans Paramètres > Voix hors ligne).
- Plus de synthèse vocale.
- Paramètres > Sauvegarde : zip de toutes les données dans Documents/Doubigue Ai Database.
