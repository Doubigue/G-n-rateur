# V15
- Paramètres > Sauvegarde : ajout de la RESTAURATION depuis un zip (choisi dans Documents/Doubigue Ai Database).
- Option « Inclure le modèle vocal Vosk » dans la sauvegarde.
- La restauration est appliquée au redémarrage (avant l'ouverture de la base) pour éviter toute corruption.
- Import du modèle : Paramètres > Voix hors ligne > Importer le modèle (zip) -> vosk-model-small-fr-0.22.zip
