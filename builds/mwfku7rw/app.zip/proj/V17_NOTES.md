# V17
- Tiroir en arc au bord (Paramètres > Raccourcis) : poignée sur le bord, tirer = arc d'apps ; toucher une icône = ouvre ; sphère = écoute directe (Vosk) puis exécute la commande ; tirer encore depuis le bord ou toucher « Assistant IA » = ouvre l'assistant.
- Choix du côté (gauche/droite) et des apps (16 max, sinon défaut). Redémarre au boot si activé.
- Icône adaptative (+ monochrome Android 13) ; clé de signature dédiée (voir SIGNATURE_ET_MISES_A_JOUR.md). versionCode 12 / 1.11.0.
- Compilation et tests sur téléphone : NON FAITS ici.
- V17.1 : ouvrir/fermer par la voix depuis le tiroir : l'app « au premier plan » est retrouvée sur 6 h (avant 60 s), fermeture directe vers l'accueil, son de fermeture joué. Nécessite l'accès « Données d'utilisation ».
